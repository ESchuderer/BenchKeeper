# Weingut Kieselbrunnen – tasting bookings

A small web app where guests book wine tastings and staff see and cancel bookings.

## Running

Requires Node.js 22.

```sh
npm install
STAFF_PASSWORD='choose-a-password' npm start   # serves on PORT (default 3000)
npm test
```

| Variable         | Purpose                                                                 |
|------------------|-------------------------------------------------------------------------|
| `STAFF_PASSWORD` | Password for `/staff`. If unset, staff sign-in is refused.              |
| `PORT`           | Port to listen on. Defaults to 3000.                                    |

## Pages

- `/` – tastings with price per guest and seats left; each has a "Book <title>" link.
- `/tastings/<id>/book` – booking form (Name, Email, Guests 1–8).
- `/bookings/<reference>` – booking confirmation.
- `/staff` – staff sign-in, then all bookings grouped by tasting, with Cancel.

## Notes

- Bookings are held in memory. The app starts with none, and a restart clears them.
- Tastings are defined in `src/tastings.js`. Times are Europe/Berlin (UTC+1 on these dates).
- A tasting whose start time has passed can no longer be booked.
- The staff session lasts 8 hours and is kept in memory.
