const crypto = require('node:crypto');
const path = require('node:path');
const express = require('express');
const { TASTINGS, startsAt } = require('./tastings');
const { BookingStore, BookingError } = require('./bookings');
const views = require('./views');

const MAX_GUESTS = 8;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const STAFF_COOKIE = 'staff_session';
const STAFF_SESSION_MS = 8 * 60 * 60 * 1000;

const str = (value) => (typeof value === 'string' ? value : '');

function validateBooking({ name, email, guests }) {
  if (!name) return 'Please enter your name.';
  if (name.length > 100) return 'Name must be 100 characters or fewer.';
  if (!email) return 'Please enter your email address.';
  if (email.length > 254 || !EMAIL_PATTERN.test(email)) return 'Please enter a valid email address.';
  const count = Number(guests);
  if (!/^\d+$/.test(guests) || count < 1 || count > MAX_GUESTS) {
    return `Guests must be a whole number from 1 to ${MAX_GUESTS}.`;
  }
  return null;
}

function createApp({
  staffPassword = '',
  tastings = TASTINGS,
  bookings = new BookingStore(),
  now = () => Date.now(),
} = {}) {
  const app = express();
  const staffSessions = new Map(); // token -> expiry time in ms

  const tastingById = (id) => tastings.find((t) => t.id === id);
  const seatsLeft = (tasting) => bookings.seatsLeft(tasting);
  const hasStarted = (tasting) => startsAt(tasting).getTime() <= now();

  function sessionToken(req) {
    for (const part of (req.headers.cookie || '').split(';')) {
      const [name, ...value] = part.trim().split('=');
      if (name === STAFF_COOKIE) return value.join('=');
    }
    return null;
  }

  function isStaff(req) {
    const token = sessionToken(req);
    const expiry = token ? staffSessions.get(token) : undefined;
    if (expiry === undefined) return false;
    if (expiry < Date.now()) {
      staffSessions.delete(token);
      return false;
    }
    return true;
  }

  // Compare SHA-256 digests so the comparison takes constant time whatever the input length.
  function passwordMatches(given) {
    if (!staffPassword) return false;
    const digest = (text) => crypto.createHash('sha256').update(text).digest();
    return crypto.timingSafeEqual(digest(given), digest(staffPassword));
  }

  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.setHeader('Content-Security-Policy', "default-src 'self'; form-action 'self'; frame-ancestors 'none'");
    res.setHeader('X-Content-Type-Options', 'nosniff');
    next();
  });
  app.use(express.urlencoded({ extended: false }));
  app.use(express.static(path.join(__dirname, '..', 'public')));

  // Guest pages

  app.get('/', (req, res) => {
    res.send(views.homePage({ tastings, seatsLeft }));
  });

  app.get('/tastings/:id/book', (req, res) => {
    const tasting = tastingById(req.params.id);
    if (!tasting) return res.status(404).send(views.notFoundPage());
    res.send(
      views.bookingPage({ tasting, seatsLeft: seatsLeft(tasting), past: hasStarted(tasting) }),
    );
  });

  app.post('/tastings/:id/book', (req, res) => {
    const tasting = tastingById(req.params.id);
    if (!tasting) return res.status(404).send(views.notFoundPage());

    const values = {
      name: str(req.body.name).trim(),
      email: str(req.body.email).trim(),
      guests: str(req.body.guests).trim(),
    };
    const reject = (error) =>
      res.status(400).send(
        views.bookingPage({
          tasting,
          seatsLeft: seatsLeft(tasting),
          past: hasStarted(tasting),
          values,
          error,
        }),
      );

    if (hasStarted(tasting)) return reject('This tasting has already taken place.');
    const error = validateBooking(values);
    if (error) return reject(error);

    try {
      const booking = bookings.create({
        tasting,
        name: values.name,
        email: values.email,
        guests: Number(values.guests),
      });
      res.redirect(303, `/bookings/${booking.reference}`);
    } catch (err) {
      if (!(err instanceof BookingError)) throw err;
      reject(err.message);
    }
  });

  app.get('/bookings/:reference', (req, res) => {
    const booking = bookings.findByReference(req.params.reference);
    const tasting = booking && tastingById(booking.tastingId);
    if (!booking || !tasting) return res.status(404).send(views.notFoundPage());
    res.send(views.confirmationPage({ booking, tasting }));
  });

  // Staff pages

  app.get('/staff', (req, res) => {
    if (!isStaff(req)) return res.send(views.staffLoginPage());
    const groups = tastings.map((tasting) => ({
      tasting,
      bookings: bookings.forTasting(tasting.id),
      booked: bookings.seatsBooked(tasting.id),
    }));
    res.send(views.staffPage({ groups }));
  });

  app.post('/staff/login', (req, res) => {
    if (!passwordMatches(str(req.body.password))) {
      return res.status(401).send(views.staffLoginPage('Incorrect password.'));
    }
    const token = crypto.randomBytes(32).toString('hex');
    staffSessions.set(token, Date.now() + STAFF_SESSION_MS);
    res.setHeader(
      'Set-Cookie',
      `${STAFF_COOKIE}=${token}; Path=/staff; HttpOnly; SameSite=Strict; Max-Age=${STAFF_SESSION_MS / 1000}`,
    );
    res.redirect(303, '/staff');
  });

  app.post('/staff/logout', (req, res) => {
    const token = sessionToken(req);
    if (token) staffSessions.delete(token);
    res.setHeader('Set-Cookie', `${STAFF_COOKIE}=; Path=/staff; HttpOnly; SameSite=Strict; Max-Age=0`);
    res.redirect(303, '/staff');
  });

  app.post('/staff/bookings/:reference/cancel', (req, res) => {
    if (!isStaff(req)) return res.redirect(303, '/staff');
    bookings.cancel(req.params.reference);
    res.redirect(303, '/staff');
  });

  // Fallbacks

  app.use((req, res) => {
    res.status(404).send(views.notFoundPage());
  });

  app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).type('text/plain').send('Something went wrong. Please try again.');
  });

  return app;
}

module.exports = { createApp };
