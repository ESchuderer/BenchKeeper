const crypto = require('node:crypto');

// Unambiguous characters only (no 0/O, 1/I), so references can be read out loud.
const REFERENCE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

class BookingError extends Error {}

// Bookings are kept in memory: the app starts with none and loses them on restart.
class BookingStore {
  constructor() {
    this.bookings = new Map(); // reference -> booking
  }

  seatsBooked(tastingId) {
    let total = 0;
    for (const booking of this.bookings.values()) {
      if (booking.tastingId === tastingId) total += booking.guests;
    }
    return total;
  }

  seatsLeft(tasting) {
    return tasting.seats - this.seatsBooked(tasting.id);
  }

  // Throws BookingError if the tasting does not have enough seats left.
  // The check and the insert run synchronously, so two requests cannot both take the last seat.
  create({ tasting, name, email, guests }) {
    const left = this.seatsLeft(tasting);
    if (guests > left) {
      throw new BookingError(
        left === 0
          ? 'Sorry, this tasting is fully booked.'
          : `Only ${left} ${left === 1 ? 'seat is' : 'seats are'} left for this tasting.`,
      );
    }
    const booking = {
      reference: this.newReference(),
      tastingId: tasting.id,
      name,
      email,
      guests,
      createdAt: new Date(),
    };
    this.bookings.set(booking.reference, booking);
    return booking;
  }

  findByReference(reference) {
    return this.bookings.get(String(reference).toUpperCase());
  }

  forTasting(tastingId) {
    return [...this.bookings.values()]
      .filter((booking) => booking.tastingId === tastingId)
      .sort((a, b) => a.createdAt - b.createdAt);
  }

  // Returns true if a booking was removed. Its seats become free again.
  cancel(reference) {
    return this.bookings.delete(String(reference).toUpperCase());
  }

  newReference() {
    let reference;
    do {
      const bytes = crypto.randomBytes(6);
      reference = 'KB-' + Array.from(bytes, (b) => REFERENCE_CHARS[b % REFERENCE_CHARS.length]).join('');
    } while (this.bookings.has(reference));
    return reference;
  }
}

module.exports = { BookingStore, BookingError };
