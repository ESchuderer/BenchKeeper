const { createApp } = require('./app');

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD || '';

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in will be refused until it is.');
}

createApp({ staffPassword }).listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
});
