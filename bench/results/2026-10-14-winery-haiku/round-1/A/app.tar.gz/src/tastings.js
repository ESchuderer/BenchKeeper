// Tastings on offer. Times are winery local time (Europe/Berlin). All three
// dates fall in CET (UTC+1), so the offset is fixed in startsAt().
const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', pricePerGuest: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', date: '2026-11-14', time: '15:00', pricePerGuest: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', date: '2026-12-05', time: '17:00', pricePerGuest: 28, seats: 10 },
];

function startsAt(tasting) {
  return new Date(`${tasting.date}T${tasting.time}:00+01:00`);
}

module.exports = { TASTINGS, startsAt };
