const esc = (value) =>
  String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const when = (tasting) => `${tasting.date} ${tasting.time}`;

function layout(title, body) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} · Weingut Kieselbrunnen</title>
<link rel="stylesheet" href="/style.css">
</head>
<body>
<header class="site-header"><a href="/">Weingut Kieselbrunnen</a></header>
<main>
${body}
</main>
</body>
</html>`;
}

function homePage({ tastings, seatsLeft }) {
  const cards = tastings
    .map(
      (t) => `
<article class="tasting">
  <h2>${esc(t.title)}</h2>
  <p class="meta">${esc(when(t))}</p>
  <p>EUR ${esc(t.pricePerGuest)} per guest</p>
  <p>${esc(seatsLeft(t))} seats left</p>
  <p><a class="button" href="/tastings/${esc(t.id)}/book">Book ${esc(t.title)}</a></p>
</article>`,
    )
    .join('');
  return layout('Tastings', `<h1>Tastings</h1>\n<div class="tastings">${cards}</div>`);
}

function bookingPage({ tasting, seatsLeft, past, values = {}, error = null }) {
  const form = past
    ? '<p class="notice">This tasting has already taken place.</p>'
    : `<form method="post" action="/tastings/${esc(tasting.id)}/book" class="booking-form" novalidate>
  ${error ? `<p class="error" role="alert">${esc(error)}</p>` : ''}
  <div class="field">
    <label for="name">Name</label>
    <input id="name" name="name" type="text" autocomplete="name" maxlength="100" value="${esc(values.name ?? '')}">
  </div>
  <div class="field">
    <label for="email">Email</label>
    <input id="email" name="email" type="email" autocomplete="email" maxlength="254" value="${esc(values.email ?? '')}">
  </div>
  <div class="field">
    <label for="guests">Guests</label>
    <input id="guests" name="guests" type="number" inputmode="numeric" min="1" max="8" step="1" aria-describedby="guests-hint" value="${esc(values.guests ?? '')}">
    <p class="hint" id="guests-hint">1 to 8 guests</p>
  </div>
  <button type="submit">Book</button>
</form>`;
  return layout(
    `Book ${tasting.title}`,
    `<h1>Book ${esc(tasting.title)}</h1>
<p class="meta">${esc(when(tasting))} · EUR ${esc(tasting.pricePerGuest)} per guest · ${esc(seatsLeft)} seats left</p>
${form}
<p><a href="/">Back to all tastings</a></p>`,
  );
}

function confirmationPage({ booking, tasting }) {
  return layout(
    'Booking confirmed',
    `<h1>Booking confirmed</h1>
<dl class="confirmation">
  <dt>Tasting</dt><dd>${esc(tasting.title)}</dd>
  <dt>Date and time</dt><dd>${esc(when(tasting))}</dd>
  <dt>Guests</dt><dd>${esc(booking.guests)}</dd>
  <dt>Total price</dt><dd>EUR ${esc(tasting.pricePerGuest * booking.guests)}</dd>
  <dt>Booking reference</dt><dd class="reference">${esc(booking.reference)}</dd>
</dl>
<p>Please quote your booking reference when you arrive.</p>
<p><a href="/">Back to all tastings</a></p>`,
  );
}

function staffLoginPage(error = null) {
  return layout(
    'Staff sign in',
    `<h1>Staff sign in</h1>
<form method="post" action="/staff/login" class="staff-login">
  ${error ? `<p class="error" role="alert">${esc(error)}</p>` : ''}
  <div class="field">
    <label for="password">Password</label>
    <input id="password" name="password" type="password" autocomplete="current-password" required>
  </div>
  <button type="submit">Sign in</button>
</form>`,
  );
}

function staffPage({ groups }) {
  const sections = groups
    .map(
      ({ tasting, bookings, booked }) => `
<section class="staff-group">
  <h2>${esc(tasting.title)}</h2>
  <p class="meta">${esc(when(tasting))} · ${esc(booked)} of ${esc(tasting.seats)} seats booked</p>
  ${
    bookings.length === 0
      ? '<p>No bookings yet.</p>'
      : `<table>
    <thead><tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th></th></tr></thead>
    <tbody>${bookings
      .map(
        (b) => `
      <tr>
        <td>${esc(b.name)}</td>
        <td>${esc(b.email)}</td>
        <td>${esc(b.guests)}</td>
        <td class="reference">${esc(b.reference)}</td>
        <td>
          <form method="post" action="/staff/bookings/${esc(b.reference)}/cancel">
            <button type="submit" class="danger">Cancel</button>
          </form>
        </td>
      </tr>`,
      )
      .join('')}
    </tbody>
  </table>`
  }
</section>`,
    )
    .join('');
  return layout(
    'Bookings',
    `<div class="staff-header">
  <h1>Bookings</h1>
  <form method="post" action="/staff/logout"><button type="submit" class="secondary">Sign out</button></form>
</div>
${sections}`,
  );
}

function notFoundPage() {
  return layout('Not found', '<h1>Page not found</h1>\n<p><a href="/">Back to all tastings</a></p>');
}

module.exports = {
  homePage,
  bookingPage,
  confirmationPage,
  staffLoginPage,
  staffPage,
  notFoundPage,
};
