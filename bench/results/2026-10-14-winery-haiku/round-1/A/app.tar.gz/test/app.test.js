const { test } = require('node:test');
const assert = require('node:assert/strict');
const { once } = require('node:events');
const { createApp } = require('../src/app');

const STAFF_PASSWORD = 'correct horse battery';
const REFERENCE = '[A-HJ-NP-Z2-9]{6}';

async function withServer(options, fn) {
  const server = createApp(options).listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    await fn(base);
  } finally {
    server.closeAllConnections();
    server.close();
  }
}

const get = (base, path, headers = {}) => fetch(base + path, { headers, redirect: 'manual' });

const post = (base, path, fields, headers = {}) =>
  fetch(base + path, { method: 'POST', body: new URLSearchParams(fields), headers, redirect: 'manual' });

const book = (base, tastingId, fields = {}) =>
  post(base, `/tastings/${tastingId}/book`, { name: 'Anna Keller', email: 'anna@example.com', guests: '2', ...fields });

async function staffCookie(base, password = STAFF_PASSWORD) {
  const res = await post(base, '/staff/login', { password });
  assert.equal(res.status, 303, 'login should succeed');
  return res.headers.getSetCookie()[0].split(';')[0];
}

const seatsText = async (base, count) => {
  const html = await (await get(base, '/')).text();
  assert.ok(html.includes(`>${count} seats left<`), `expected "${count} seats left" on start page`);
};

test('start page lists the tastings with price, seats left and booking links', () =>
  withServer({}, async (base) => {
    const res = await get(base, '/');
    assert.equal(res.status, 200);
    const html = await res.text();
    for (const line of [
      'Riesling Evening',
      '2026-11-06 18:00',
      'EUR 25 per guest',
      '>12 seats left<',
      'Red Wine Cellar Tour',
      '2026-11-14 15:00',
      'EUR 32 per guest',
      '>8 seats left<',
      'Winter Tasting',
      '2026-12-05 17:00',
      'EUR 28 per guest',
      '>10 seats left<',
      '>Book Riesling Evening<',
      '>Book Red Wine Cellar Tour<',
      '>Book Winter Tasting<',
    ]) {
      assert.ok(html.includes(line), `start page should contain ${line}`);
    }
  }));

test('booking form has Name, Email and Guests fields and a Book button', () =>
  withServer({}, async (base) => {
    const res = await get(base, '/tastings/riesling-evening/book');
    assert.equal(res.status, 200);
    const html = await res.text();
    assert.match(html, /<label for="name">Name<\/label>/);
    assert.match(html, /<label for="email">Email<\/label>/);
    assert.match(html, /<label for="guests">Guests<\/label>/);
    assert.match(html, /<button type="submit">Book<\/button>/);
    assert.match(html, /<h1>Book Riesling Evening<\/h1>/);
  }));

test('a valid booking shows the confirmation and takes seats', () =>
  withServer({}, async (base) => {
    const res = await book(base, 'riesling-evening', { guests: '3' });
    assert.equal(res.status, 303);
    const location = res.headers.get('location');
    assert.match(location, new RegExp(`^/bookings/KB-${REFERENCE}$`));

    const html = await (await get(base, location)).text();
    assert.match(html, /<h1>Booking confirmed<\/h1>/);
    assert.match(html, /<dd>Riesling Evening<\/dd>/);
    assert.match(html, /<dd>3<\/dd>/);
    assert.match(html, /<dd>EUR 75<\/dd>/);
    assert.ok(html.includes(location.replace('/bookings/', '')), 'confirmation shows the reference');

    await seatsText(base, 9);
  }));

test('guests can fill a tasting exactly but not exceed its seats', () =>
  withServer({}, async (base) => {
    assert.equal((await book(base, 'red-wine-cellar-tour', { guests: '6' })).status, 303);

    const over = await book(base, 'red-wine-cellar-tour', { guests: '3' });
    assert.equal(over.status, 400);
    assert.ok((await over.text()).includes('Only 2 seats are left for this tasting.'));

    assert.equal((await book(base, 'red-wine-cellar-tour', { guests: '2' })).status, 303);
    await seatsText(base, 0);

    const full = await book(base, 'red-wine-cellar-tour', { guests: '1' });
    assert.equal(full.status, 400);
    assert.ok((await full.text()).includes('Sorry, this tasting is fully booked.'));
  }));

test('a party of eight is accepted on a tasting with enough seats', () =>
  withServer({}, async (base) => {
    const res = await book(base, 'winter-tasting', { guests: '8' });
    assert.equal(res.status, 303);
    const html = await (await get(base, res.headers.get('location'))).text();
    assert.match(html, /<dd>EUR 224<\/dd>/);
  }));

test('invalid guest counts are rejected with a message and create no booking', () =>
  withServer({}, async (base) => {
    for (const guests of ['0', '9', '-1', '2.5', '', 'abc', '1e1', '99999999999999999999']) {
      const res = await book(base, 'riesling-evening', { guests });
      assert.equal(res.status, 400, `guests=${JSON.stringify(guests)} should be rejected`);
      const html = await res.text();
      assert.ok(html.includes('Guests must be a whole number from 1 to 8.'), `message for guests=${guests}`);
      assert.ok(html.includes('class="error"'), 'error is shown next to the form');
    }
    await seatsText(base, 12);
  }));

test('missing or invalid name and email are rejected and keep what was typed', () =>
  withServer({}, async (base) => {
    let res = await book(base, 'riesling-evening', { name: '   ' });
    assert.equal(res.status, 400);
    assert.ok((await res.text()).includes('Please enter your name.'));

    res = await book(base, 'riesling-evening', { email: 'anna@' });
    assert.equal(res.status, 400);
    let html = await res.text();
    assert.ok(html.includes('Please enter a valid email address.'));
    assert.ok(html.includes('value="Anna Keller"'), 'name is kept after an error');

    res = await book(base, 'riesling-evening', { email: '' });
    assert.equal(res.status, 400);
    assert.ok((await res.text()).includes('Please enter your email address.'));

    await seatsText(base, 12);
  }));

test('unknown tastings and bookings return 404', () =>
  withServer({}, async (base) => {
    assert.equal((await get(base, '/tastings/nope/book')).status, 404);
    assert.equal((await book(base, 'nope')).status, 404);
    assert.equal((await get(base, '/bookings/KB-ZZZZZZ')).status, 404);
    assert.equal((await get(base, '/no-such-page')).status, 404);
  }));

test('a tasting that has already started cannot be booked', () =>
  withServer({ now: () => Date.parse('2026-11-07T00:00:00+01:00') }, async (base) => {
    const form = await (await get(base, '/tastings/riesling-evening/book')).text();
    assert.ok(form.includes('This tasting has already taken place.'));
    assert.ok(!form.includes('<form'), 'no form for a past tasting');

    const res = await book(base, 'riesling-evening');
    assert.equal(res.status, 400);
    await seatsText(base, 12);
  }));

test('staff page asks for the password and rejects a wrong one', () =>
  withServer({ staffPassword: STAFF_PASSWORD }, async (base) => {
    const page = await (await get(base, '/staff')).text();
    assert.match(page, /<label for="password">Password<\/label>/);
    assert.match(page, /<button type="submit">Sign in<\/button>/);

    const res = await post(base, '/staff/login', { password: 'wrong' });
    assert.equal(res.status, 401);
    assert.ok((await res.text()).includes('Incorrect password.'));
    assert.equal(res.headers.getSetCookie().length, 0);
  }));

test('staff see bookings grouped by tasting and can cancel one to free its seats', () =>
  withServer({ staffPassword: STAFF_PASSWORD }, async (base) => {
    await book(base, 'riesling-evening', { name: 'Anna Keller', guests: '4' });
    await book(base, 'winter-tasting', { name: 'Ben Hofer', email: 'ben@example.com', guests: '1' });

    const cookie = await staffCookie(base);
    const page = await (await get(base, '/staff', { cookie })).text();
    const riesling = page.slice(page.indexOf('<h2>Riesling Evening</h2>'), page.indexOf('<h2>Red Wine Cellar Tour</h2>'));
    const winter = page.slice(page.indexOf('<h2>Winter Tasting</h2>'));
    assert.ok(riesling.includes('Anna Keller') && riesling.includes('anna@example.com'));
    assert.ok(!riesling.includes('Ben Hofer'));
    assert.ok(winter.includes('Ben Hofer') && winter.includes('ben@example.com'));
    assert.ok(riesling.includes('>Cancel<'));

    const reference = riesling.match(new RegExp(`KB-${REFERENCE}`))[0];
    const res = await post(base, `/staff/bookings/${reference}/cancel`, {}, { cookie });
    assert.equal(res.status, 303);

    const after = await (await get(base, '/staff', { cookie })).text();
    assert.ok(!after.includes('Anna Keller'));
    assert.ok(after.includes('Ben Hofer'));
    await seatsText(base, 12);
    assert.equal((await get(base, `/bookings/${reference}`)).status, 404);
  }));

test('cancelling needs a staff session', () =>
  withServer({ staffPassword: STAFF_PASSWORD }, async (base) => {
    const res = await book(base, 'riesling-evening', { guests: '4' });
    const location = res.headers.get('location');
    const reference = location.replace('/bookings/', '');

    const attempt = await post(base, `/staff/bookings/${reference}/cancel`, {});
    assert.equal(attempt.status, 303);
    assert.equal((await get(base, location)).status, 200, 'booking still exists');
    await seatsText(base, 8);
  }));

test('staff session ends on sign out', () =>
  withServer({ staffPassword: STAFF_PASSWORD }, async (base) => {
    const cookie = await staffCookie(base);
    assert.match(await (await get(base, '/staff', { cookie })).text(), /<h1>Bookings<\/h1>/);

    await post(base, '/staff/logout', {}, { cookie });
    assert.match(await (await get(base, '/staff', { cookie })).text(), /Staff sign in/);
  }));

test('a made-up session cookie does not show the staff area', () =>
  withServer({ staffPassword: STAFF_PASSWORD }, async (base) => {
    const page = await (await get(base, '/staff', { cookie: 'staff_session=forged' })).text();
    assert.match(page, /Staff sign in/);
    assert.ok(!page.includes('<h1>Bookings</h1>'));
  }));

test('staff sign-in is refused when STAFF_PASSWORD is not set', () =>
  withServer({ staffPassword: '' }, async (base) => {
    const res = await post(base, '/staff/login', { password: '' });
    assert.equal(res.status, 401);
  }));

test('guest-entered text is escaped on every page', () =>
  withServer({ staffPassword: STAFF_PASSWORD }, async (base) => {
    const evil = '<script>alert("x")</script>';
    const res = await book(base, 'winter-tasting', { name: evil, guests: '1' });
    assert.equal(res.status, 303);

    const cookie = await staffCookie(base);
    const page = await (await get(base, '/staff', { cookie })).text();
    assert.ok(!page.includes('<script>alert'));
    assert.ok(page.includes('&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;'));

    const echoed = await book(base, 'winter-tasting', { name: evil, email: 'bad', guests: '1' });
    assert.ok(!(await echoed.text()).includes('<script>alert'));
  }));
