const http = require('node:http');
const crypto = require('node:crypto');

const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', when: '2026-11-06 18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', when: '2026-11-14 15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', when: '2026-12-05 17:00', price: 28, seats: 10 },
];

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);

const page = (title, body) => `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} · Weingut Kieselbrunnen</title>
<style>body{font-family:system-ui,sans-serif;max-width:52rem;margin:2rem auto;padding:0 1rem}table{border-collapse:collapse}td,th{padding:.4rem .8rem;border-bottom:1px solid #ddd;text-align:left}</style>
</head>
<body>
<header><a href="/">Weingut Kieselbrunnen</a></header>
<main>
<h1>${esc(title)}</h1>
${body}
</main>
</body>
</html>`;

// Reads a urlencoded form body; the 10 kB cap protects against oversized posts.
async function readForm(req) {
  req.setEncoding('utf8');
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (body.length > 10_000) throw Object.assign(new Error('Form too large'), { status: 413 });
  }
  return Object.fromEntries(new URLSearchParams(body));
}

function safeEqual(a = '', b) {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

function validate({ name, email, guests }, seatsLeft) {
  if (!name || name.length > 100) return 'Please enter your name.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 200) return 'Please enter a valid email address.';
  if (!/^\d+$/.test(guests) || Number(guests) < 1 || Number(guests) > 8) return 'Guests must be a whole number from 1 to 8.';
  if (Number(guests) > seatsLeft) return seatsLeft === 0 ? 'This tasting is sold out.' : `Only ${seatsLeft} seats are left.`;
  return null;
}

function createServer(staffPassword) {
  const bookings = [];
  const sessions = new Set();

  const seatsLeft = (t) => t.seats - bookings.filter((b) => b.tastingId === t.id).reduce((n, b) => n + b.guests, 0);
  const isStaff = (req) => {
    const m = /(?:^|;\s*)staff=([0-9a-f]{64})/.exec(req.headers.cookie ?? '');
    return Boolean(m && sessions.has(m[1]));
  };

  const tastingList = () => `<table>
<tr><th>Tasting</th><th>Date and time</th><th>Price per guest</th><th>Seats</th><th></th></tr>
${TASTINGS.map((t) => `<tr><td>${esc(t.title)}</td><td>${esc(t.when)}</td><td>EUR ${t.price}</td><td>${seatsLeft(t)} seats left</td><td><a href="/book/${t.id}">Book ${esc(t.title)}</a></td></tr>`).join('\n')}
</table>`;

  const bookingPage = (t, values = {}, error = '') => page(t.title, `<p>${esc(t.when)} · EUR ${t.price} per guest · ${seatsLeft(t)} seats left</p>
${error ? `<p role="alert">${esc(error)}</p>` : ''}
<form method="post" novalidate>
<p><label>Name <input name="name" value="${esc(values.name ?? '')}"></label></p>
<p><label>Email <input name="email" type="email" value="${esc(values.email ?? '')}"></label></p>
<p><label>Guests <input name="guests" type="number" min="1" max="8" value="${esc(values.guests ?? '')}"></label></p>
<button>Book</button>
</form>`);

  const confirmPage = (b) => {
    const t = TASTINGS.find((x) => x.id === b.tastingId);
    return page('Booking confirmed', `<dl>
<dt>Tasting</dt><dd>${esc(t.title)} · ${esc(t.when)}</dd>
<dt>Guests</dt><dd>${b.guests}</dd>
<dt>Total price</dt><dd>EUR ${b.guests * t.price}</dd>
<dt>Booking reference</dt><dd>${b.ref}</dd>
</dl>
<p><a href="/">Back to tastings</a></p>`);
  };

  const loginPage = (error = '') => page('Staff sign in', `${error ? `<p role="alert">${esc(error)}</p>` : ''}
<form method="post" action="/staff/login">
<p><label>Password <input name="password" type="password"></label></p>
<button>Sign in</button>
</form>`);

  const staffPage = () => page('Bookings', TASTINGS.map((t) => {
    const list = bookings.filter((b) => b.tastingId === t.id);
    return `<h2>${esc(t.title)} · ${esc(t.when)}</h2>
<p>${seatsLeft(t)} seats left</p>
${list.length ? `<table>
<tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th></th></tr>
${list.map((b) => `<tr><td>${esc(b.name)}</td><td>${esc(b.email)}</td><td>${b.guests}</td><td>${b.ref}</td><td><form method="post" action="/staff/bookings/${b.ref}/cancel"><button>Cancel</button></form></td></tr>`).join('\n')}
</table>` : '<p>No bookings.</p>'}`;
  }).join('\n'));

  async function handle(req, res) {
    const { pathname } = new URL(req.url, 'http://localhost');
    const { method } = req;
    const send = (status, html, headers = {}) => {
      res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', ...headers });
      res.end(html);
    };
    const redirect = (location, headers = {}) => {
      res.writeHead(303, { Location: location, ...headers });
      res.end();
    };
    let m;

    if (method === 'GET' && pathname === '/') return send(200, page('Tastings', tastingList()));

    if ((m = /^\/book\/([\w-]+)$/.exec(pathname))) {
      const t = TASTINGS.find((x) => x.id === m[1]);
      if (t && method === 'GET') return send(200, bookingPage(t));
      if (t && method === 'POST') {
        const f = await readForm(req);
        const input = { name: (f.name ?? '').trim(), email: (f.email ?? '').trim(), guests: (f.guests ?? '').trim() };
        const error = validate(input, seatsLeft(t));
        if (error) return send(400, bookingPage(t, input, error));
        const booking = {
          ref: crypto.randomBytes(4).toString('hex').toUpperCase(),
          tastingId: t.id,
          name: input.name,
          email: input.email,
          guests: Number(input.guests),
        };
        bookings.push(booking);
        return redirect(`/booking/${booking.ref}`);
      }
    }

    if ((m = /^\/booking\/([A-F0-9]{8})$/.exec(pathname)) && method === 'GET') {
      const b = bookings.find((x) => x.ref === m[1]);
      if (b) return send(200, confirmPage(b));
    }

    if (pathname === '/staff' && method === 'GET') return send(200, isStaff(req) ? staffPage() : loginPage());

    if (pathname === '/staff/login' && method === 'POST') {
      const f = await readForm(req);
      if (!staffPassword || !safeEqual(f.password, staffPassword)) return send(401, loginPage('Wrong password.'));
      const token = crypto.randomBytes(32).toString('hex');
      sessions.add(token);
      return redirect('/staff', { 'Set-Cookie': `staff=${token}; HttpOnly; SameSite=Strict; Path=/` });
    }

    if ((m = /^\/staff\/bookings\/([A-F0-9]{8})\/cancel$/.exec(pathname)) && method === 'POST') {
      const i = bookings.findIndex((b) => b.ref === m[1]);
      if (isStaff(req) && i >= 0) bookings.splice(i, 1);
      return redirect('/staff');
    }

    send(404, page('Not found', '<p>Page not found.</p>'));
  }

  return http.createServer((req, res) => {
    handle(req, res).catch((err) => {
      if (!err.status) console.error(err);
      const status = err.status ?? 500;
      if (!res.headersSent) res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end(http.STATUS_CODES[status]);
    });
  });
}

if (require.main === module) {
  const port = Number(process.env.PORT ?? 3000);
  if (!process.env.STAFF_PASSWORD) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
  createServer(process.env.STAFF_PASSWORD).listen(port, () => console.log(`Listening on http://localhost:${port}`));
}

module.exports = { createServer };
