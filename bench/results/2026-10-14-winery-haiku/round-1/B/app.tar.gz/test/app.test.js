const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../server');

async function start(password = 'secret') {
  const server = createServer(password);
  await new Promise((resolve) => server.listen(0, resolve));
  const base = `http://localhost:${server.address().port}`;
  return { base, close: () => new Promise((resolve) => server.close(resolve)) };
}

const body = (fields) => ({ method: 'POST', body: new URLSearchParams(fields), redirect: 'manual' });

test('booking reduces seats left and shows the confirmation', async () => {
  const app = await start();
  try {
    const res = await fetch(`${app.base}/book/winter-tasting`, body({ name: 'Anna', email: 'anna@example.com', guests: '3' }));
    assert.equal(res.status, 303);
    const confirmation = await (await fetch(app.base + res.headers.get('location'))).text();
    assert.match(confirmation, /Booking confirmed/);
    assert.match(confirmation, /EUR 84/);
    assert.match(await (await fetch(app.base + '/')).text(), /7 seats left/);
  } finally {
    await app.close();
  }
});

test('invalid input and overbooking are rejected with a message', async () => {
  const app = await start();
  try {
    const post = (fields) => fetch(`${app.base}/book/red-wine-cellar-tour`, body(fields));
    const invalid = [
      [{ name: '', email: 'a@example.com', guests: '1' }, 'Please enter your name.'],
      [{ name: 'A', email: 'nope', guests: '1' }, 'valid email'],
      [{ name: 'A', email: 'a@example.com', guests: '0' }, 'from 1 to 8'],
      [{ name: 'A', email: 'a@example.com', guests: '9' }, 'from 1 to 8'],
      [{ name: 'A', email: 'a@example.com', guests: '1.5' }, 'from 1 to 8'],
    ];
    for (const [fields, message] of invalid) {
      const res = await post(fields);
      assert.equal(res.status, 400);
      assert.match(await res.text(), new RegExp(message));
    }

    assert.equal((await post({ name: 'A', email: 'a@example.com', guests: '5' })).status, 303);
    const tooMany = await post({ name: 'B', email: 'b@example.com', guests: '4' });
    assert.equal(tooMany.status, 400);
    assert.match(await tooMany.text(), /Only 3 seats are left/);
    assert.equal((await post({ name: 'C', email: 'c@example.com', guests: '3' })).status, 303);
    const soldOut = await post({ name: 'D', email: 'd@example.com', guests: '1' });
    assert.match(await soldOut.text(), /sold out/);
  } finally {
    await app.close();
  }
});

test('staff must sign in, and cancelling a booking frees its seats', async () => {
  const app = await start();
  try {
    const booked = await fetch(`${app.base}/book/riesling-evening`, body({ name: 'Ben <i>', email: 'ben@example.com', guests: '8' }));
    const ref = booked.headers.get('location').split('/').pop();

    assert.doesNotMatch(await (await fetch(`${app.base}/staff`)).text(), /ben@example.com/);
    assert.equal((await fetch(`${app.base}/staff/login`, body({ password: 'wrong' }))).status, 401);

    const login = await fetch(`${app.base}/staff/login`, body({ password: 'secret' }));
    const cookie = login.headers.get('set-cookie').split(';')[0];
    const staffView = await (await fetch(`${app.base}/staff`, { headers: { cookie } })).text();
    assert.match(staffView, /ben@example.com/);
    assert.match(staffView, /Ben &#60;i&#62;/);

    await fetch(`${app.base}/staff/bookings/${ref}/cancel`, { method: 'POST', redirect: 'manual' });
    assert.match(await (await fetch(`${app.base}/`)).text(), /4 seats left/);

    await fetch(`${app.base}/staff/bookings/${ref}/cancel`, { method: 'POST', headers: { cookie }, redirect: 'manual' });
    assert.match(await (await fetch(`${app.base}/`)).text(), /12 seats left/);
  } finally {
    await app.close();
  }
});
