# Design

## Context

The repository has no application code yet. The runtime is Node.js 22 (`.devcontainer/devcontainer.json`). Requirements are in `specs/tasting-bookings/spec.md` and `specs/staff-bookings/spec.md`. See `proposal.md` - Why for motivation.

## Goals / Non-Goals

**Goals:**
- Run with `npm install` (no dependencies) and `npm start`.
- Keep the seat rule in one place, so every booking and cancellation goes through the same check.

**Non-Goals:**
- Persistence across restarts, user accounts, payments, email, admin editing of tastings, sign-out, rate limiting.
- Client-side JavaScript. All pages work without it.

## Decisions

- **Node built-ins only.** `node:http` for routing, `node:test` for tests, `node:crypto` for password comparison and session tokens. Alternative: Express. Rejected: one dependency for about five routes.
- **Server-rendered HTML.** Each page is a string built by a small `html` helper that escapes every interpolated value. Alternative: a template engine. Rejected: no templates are needed at this size.
- **Post-redirect-get for bookings.** `POST /tastings/:id/book` on success responds `303` to `/bookings/:reference`, which renders the confirmation. A page reload then does not book twice.
- **Seats computed, not stored.** Seats left = seats of the tasting minus the guests of its current bookings. Cancelling deletes the booking, so its seats return without extra bookkeeping.
- **Single-threaded check and insert.** The seat check and the insert run synchronously in one function, so two concurrent requests cannot both take the last seat.
- **References from a counter.** `KB-<n>`, n starting at 1. Unique for the process lifetime, as the spec requires. Alternative: random tokens. Rejected: a counter cannot collide.
- **Staff session.** A random 32-byte token (`crypto.randomBytes`) held in memory and sent in an `HttpOnly; SameSite=Strict; Path=/` cookie. Cross-site POSTs are rejected by an Origin check (`sameOrigin` in `src/app.js`). `SameSite=Strict` alone does not cover requests from another port on the same site, so it is not relied on for this.
- **Password check.** `crypto.timingSafeEqual` on SHA-256 digests of the submitted and configured password, so lengths can differ without a leak.
- **Missing `STAFF_PASSWORD` stops the app.** `server.js` exits with an error at startup. Alternative: refuse staff sign-in only. Rejected: a silent misconfiguration would then go unnoticed until staff try to sign in.
- **Module layout.** `src/store.js` (tastings, bookings, seat rule, validation), `src/app.js` (`createApp({ staffPassword })` returning a request handler), `src/server.js` (reads `PORT` and `STAFF_PASSWORD`, listens), `test/*.test.js`.

## Risks / Trade-offs

- [Bookings lost on restart] → Accepted by the proposal. Storage sits behind `store.js`, so a file or database can replace it later without touching routes.
- [Cookie without `Secure` flag] → The app serves plain HTTP on `PORT`. A deployment behind TLS must set `Secure`; the design does not add it because the app has no TLS of its own.
- [Shared staff password] → One password for all staff, as specified. No audit trail of who cancelled.
- [Guessable references] → A counter reveals the order of bookings. References are not credentials; cancellation requires staff sign-in.
- [Sessions never expire] → A copied cookie stays valid until the process restarts. Not implemented; no session lifetime is specified.
- [Public booking pages] → `/bookings/KB-<n>` shows tasting, date, guests and total to anyone with the reference, and references are sequential. Accepted; no guest name or email is shown there.
- [Staff password over HTTP] → Staff sign-in sends the password in plain text unless TLS terminates in front of the app.
- [Unbounded memory] → Each booking is small and the tastings are fixed, so growth is limited to bookings made in one process lifetime.
