# Proposal

## Why

Guests of Weingut Kieselbrunnen have no way to book a wine tasting online, and staff have no single view of who is coming. A small web app replaces manual booking.

## What Changes

- Add a guest-facing site that lists three fixed tastings with date, time, price per guest and seats left.
- Add a booking form per tasting (Name, Email, Guests 1 to 8). A booking is rejected when it exceeds the seats left or when input is invalid.
- Show a booking confirmation with reference, tasting, guests and total price.
- Add a staff page protected by a password from `STAFF_PASSWORD`. Staff see bookings grouped by tasting and cancel bookings, which frees their seats.
- Bookings are held in memory; the app starts with none.

## Capabilities

### New Capabilities
- `tasting-bookings`: guest listing of tastings, seat availability, booking and booking confirmation.
- `staff-bookings`: staff sign-in with a shared password, listing of bookings by tasting, and cancellation.

### Modified Capabilities
- None (greenfield repository).

## Impact

- New Node.js 22 application at the repository root: HTTP server, pages, and in-memory booking store.
- New dependencies: none expected beyond the Node.js standard library.
- Environment variables: `PORT` (default 3000), `STAFF_PASSWORD` (required for staff sign-in).
- No external services, no database, no persistence across restarts.
