# Spec Delta

## Purpose

Lets winery staff sign in with a shared password, see all bookings grouped by tasting, and cancel bookings to free their seats.

## ADDED Requirements

### Requirement: Staff sign-in
The system SHALL show a sign-in page at /staff with a field labelled "Password" and a button labelled "Sign in". The system SHALL grant staff access only when the submitted password equals the value of the environment variable `STAFF_PASSWORD`. The system SHALL NOT start when `STAFF_PASSWORD` is not set.

#### Scenario: Correct password
- **WHEN** staff submit the correct password on /staff
- **THEN** the booking overview is shown

#### Scenario: Wrong password
- **WHEN** staff submit a password that does not match `STAFF_PASSWORD`
- **THEN** the sign-in page shows an error message and the booking overview is not shown

#### Scenario: Missing configuration
- **WHEN** the app is started without `STAFF_PASSWORD` set
- **THEN** the app exits with an error message naming `STAFF_PASSWORD`

### Requirement: Booking overview
The system SHALL show signed-in staff all current bookings grouped by tasting. Each booking SHALL show the guest name, email, number of guests, and booking reference. A tasting with no bookings SHALL still be shown with a message stating there are no bookings.

#### Scenario: Bookings grouped by tasting
- **WHEN** staff are signed in and bookings exist for Riesling Evening and Winter Tasting
- **THEN** the overview shows a Riesling Evening group and a Winter Tasting group, each listing its bookings with name, email, guests and reference

#### Scenario: Overview without access
- **WHEN** a request for the booking overview arrives without a valid staff sign-in
- **THEN** the system does not show any booking data and shows the sign-in page

### Requirement: Cancel booking
The system SHALL show a button labelled "Cancel" next to each booking in the staff overview. Activating it SHALL remove the booking and free its guests' seats for that tasting. Cancellation SHALL require a valid staff sign-in.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 3 guests for Riesling Evening that had 9 seats left
- **THEN** the booking no longer appears in the overview and the start page shows "12 seats left" for Riesling Evening

#### Scenario: Cancel without sign-in
- **WHEN** a cancellation request arrives without a valid staff sign-in
- **THEN** no booking is removed
