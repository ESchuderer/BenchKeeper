# Spec Delta

## Purpose

Lets guests see the winery's tastings with remaining seats and book seats for a tasting online, receiving a booking reference.

## ADDED Requirements

### Requirement: Tasting listing
The system SHALL list the following tastings on the start page, each with its title, date and time, price per guest and seats left: Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats), Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats).

#### Scenario: Start page with no bookings
- **WHEN** a guest opens the start page and no bookings exist
- **THEN** each tasting is listed with its title, date and time, price per guest, and "<seats> seats left" equal to its full seat count

#### Scenario: Seats left after a booking
- **WHEN** a booking for 3 guests exists for Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening

### Requirement: Booking form per tasting
The system SHALL provide a button or link labelled "Book <tasting title>" for each tasting. It SHALL open a booking form for that tasting with fields labelled "Name", "Email" and "Guests", and a button labelled "Book".

#### Scenario: Open booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** a form for Riesling Evening with fields "Name", "Email" and "Guests" and a "Book" button is shown

#### Scenario: Unknown tasting
- **WHEN** a guest requests a booking form for a tasting that does not exist
- **THEN** the system responds with HTTP status 404

### Requirement: Booking input validation
The system SHALL reject a booking whose Name is empty, whose Email is not a syntactically valid email address, or whose Guests value is not a whole number from 1 to 8. A rejected booking SHALL show an error message next to the form and SHALL NOT create a booking or change seats left.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty Name
- **THEN** the form shows an error message next to the form and no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits the form with Email "not-an-email"
- **THEN** the form shows an error message and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits Guests as 0, 9, or "two"
- **THEN** the form shows an error message and no booking is created

### Requirement: Seat limit
The system SHALL NOT accept a booking whose Guests value is greater than the seats left for that tasting. A rejected booking SHALL show an error message next to the form stating the seats left, and SHALL NOT change seats left.

#### Scenario: More guests than seats left
- **WHEN** Red Wine Cellar Tour has 2 seats left and a guest books 3 guests
- **THEN** the form shows an error message stating 2 seats left and no booking is created

#### Scenario: Booking the last seats
- **WHEN** Red Wine Cellar Tour has 2 seats left and a guest books 2 guests
- **THEN** the booking is accepted and the tasting shows "0 seats left"

### Requirement: Booking confirmation
The system SHALL show, after a successful booking, a page with the heading "Booking confirmed", the tasting title, the number of guests, the total price (guests multiplied by price per guest, shown as "EUR <amount>"), and a booking reference.

#### Scenario: Successful booking
- **WHEN** a guest books 2 guests for Winter Tasting
- **THEN** the page has the heading "Booking confirmed", shows "Winter Tasting", "2", "EUR 56", and a booking reference

### Requirement: Booking reference
The system SHALL assign each accepted booking a reference that is unique among all bookings made since the app started.

#### Scenario: Two bookings get different references
- **WHEN** two bookings are accepted
- **THEN** their booking references differ
