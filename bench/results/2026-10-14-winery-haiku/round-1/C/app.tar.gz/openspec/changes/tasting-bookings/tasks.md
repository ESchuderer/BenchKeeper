# Tasks

## 1. Store and seat rule

- [x] 1.1 Write `test/store.test.js` cases for: three seeded tastings with the specified titles, dates, prices and seats; seats left equals seats minus booked guests; booking with Guests above seats left is rejected and seats unchanged; booking with empty Name, invalid Email, or Guests outside 1 to 8 or not a whole number is rejected; accepted bookings get distinct `KB-<n>` references; cancelling a booking restores its seats. Verify: tests fail before `src/store.js` exists.
- [x] 1.2 Implement `src/store.js` (tastings, `createBooking`, `cancelBooking`, `seatsLeft`, `listBookingsByTasting`, `getBooking`, validation) until 1.1 passes. Verify: `npm test` passes the store tests.

## 2. Guest pages

- [x] 2.1 Write `test/guest.test.js` against `createApp({ staffPassword })` on an ephemeral port: start page lists all three tastings with "<n> seats left" and a "Book <title>" link per tasting; `/tastings/:id/book` shows Name, Email, Guests fields and a Book button; unknown tasting returns 404; POST with valid data returns 303 to `/bookings/KB-<n>`; the confirmation page shows "Booking confirmed", the title, guests, "EUR <total>" and the reference; invalid or over-limit POST returns 400 with the error message and the entered values; user-entered text containing `<script>` is escaped in every page. Verify: tests fail before `src/app.js` exists.
- [x] 2.2 Implement `src/app.js` guest routes and the `html` escaping helper until 2.1 passes. Verify: `npm test` passes the guest tests.

## 3. Staff pages

- [x] 3.1 Write `test/staff.test.js`: `GET /staff` without session shows "Password" field and "Sign in" button; wrong password returns 401 with an error and no booking data; correct password sets an `HttpOnly; SameSite=Strict` session cookie and shows bookings grouped by tasting with name, email, guests and reference; a tasting without bookings shows a "no bookings" message; `POST /staff/bookings/:ref/cancel` with session removes the booking and the start page shows the freed seats; the same request without session changes nothing and shows the sign-in page; cancelling an unknown reference returns 404. Verify: tests fail before the staff routes exist.
- [x] 3.2 Implement staff routes in `src/app.js` (sign-in with `timingSafeEqual` on SHA-256 digests, in-memory session tokens, overview, cancel) until 3.1 passes. Verify: `npm test` passes all tests.

## 4. Server entry

- [x] 4.1 Write `test/server.test.js`: starting `src/server.js` without `STAFF_PASSWORD` exits with a non-zero code and a message containing `STAFF_PASSWORD`; with `STAFF_PASSWORD` and `PORT=<free port>` it serves `GET /` with HTTP 200. Verify: tests fail before `src/server.js` exists.
- [x] 4.2 Implement `src/server.js` (reads `PORT`, default 3000, and `STAFF_PASSWORD`) and `package.json` (`start`, `test` scripts, no dependencies) until 4.1 passes. Verify: `npm install` succeeds and `npm start` serves the start page.

## 5. Browser verification

- [x] 5.1 Run `npm start` with `STAFF_PASSWORD` set and walk the flow in Playwright MCP: book Riesling Evening for 2 guests, confirm the confirmation page; book 8 guests on Red Wine Cellar Tour (fills it), then book 1 guest and confirm the seat-limit rejection shows "0 seats left"; sign in at /staff, confirm the booking appears under Riesling Evening, cancel it, confirm the start page shows 12 seats left again. Verify: each step matches the scenarios in the specs, and no console errors appear.
