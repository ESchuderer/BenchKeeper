const { createHash, randomBytes, timingSafeEqual } = require('node:crypto');
const { createStore } = require('./store');

const MAX_BODY_BYTES = 10_000;

const esc = (value) =>
  String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const layout = (title, body) => `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="icon" href="data:,"><title>${esc(title)}</title></head>
<body>
<header><a href="/">Weingut Kieselbrunnen</a></header>
<main>${body}</main>
</body>
</html>`;

const startPage = (tastings) =>
  layout('Wine tastings', `<h1>Wine tastings</h1>
<ul>
${tastings
  .map(
    (t) => `<li>
<h2>${esc(t.title)}</h2>
<p>${esc(t.date)} ${esc(t.time)}</p>
<p>EUR ${esc(t.price)} per guest</p>
<p>${esc(t.seatsLeft)} seats left</p>
<a href="/tastings/${esc(t.id)}/book">Book ${esc(t.title)}</a>
</li>`,
  )
  .join('\n')}
</ul>`);

const bookingForm = (tasting, values = {}, error = '') =>
  layout(`Book ${tasting.title}`, `<h1>Book ${esc(tasting.title)}</h1>
<p>${esc(tasting.date)} ${esc(tasting.time)}, EUR ${esc(tasting.price)} per guest, ${esc(tasting.seatsLeft)} seats left</p>
${error ? `<p role="alert">${esc(error)}</p>` : ''}
<form method="post" action="/tastings/${esc(tasting.id)}/book" novalidate>
<p><label for="name">Name</label> <input id="name" name="name" type="text" value="${esc(values.name ?? '')}"></p>
<p><label for="email">Email</label> <input id="email" name="email" type="email" value="${esc(values.email ?? '')}"></p>
<p><label for="guests">Guests</label> <input id="guests" name="guests" type="number" min="1" max="8" value="${esc(values.guests ?? '')}"></p>
<button type="submit">Book</button>
</form>`);

const signInPage = (error = '') =>
  layout('Staff sign-in', `<h1>Staff sign-in</h1>
${error ? `<p role="alert">${esc(error)}</p>` : ''}
<form method="post" action="/staff/sign-in" novalidate>
<p><label for="password">Password</label> <input id="password" name="password" type="password"></p>
<button type="submit">Sign in</button>
</form>`);

const overviewPage = (groups) =>
  layout('Bookings', `<h1>Bookings</h1>
${groups
  .map(
    ({ tasting, bookings }) => `<section>
<h2>${esc(tasting.title)}</h2>
${
  bookings.length
    ? `<table>
<thead><tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th></th></tr></thead>
<tbody>
${bookings
  .map(
    (b) => `<tr>
<td>${esc(b.name)}</td><td>${esc(b.email)}</td><td>${esc(b.guests)}</td><td>${esc(b.reference)}</td>
<td><form method="post" action="/staff/bookings/${esc(b.reference)}/cancel"><button type="submit">Cancel</button></form></td>
</tr>`,
  )
  .join('\n')}
</tbody>
</table>`
    : '<p>No bookings yet.</p>'
}
</section>`,
  )
  .join('\n')}`);

const confirmationPage = (booking, tasting) =>
  layout('Booking confirmed', `<h1>Booking confirmed</h1>
<dl>
<dt>Tasting</dt><dd>${esc(tasting.title)}</dd>
<dt>Date and time</dt><dd>${esc(tasting.date)} ${esc(tasting.time)}</dd>
<dt>Guests</dt><dd>${esc(booking.guests)}</dd>
<dt>Total price</dt><dd>EUR ${esc(booking.total)}</dd>
<dt>Booking reference</dt><dd>${esc(booking.reference)}</dd>
</dl>
<p><a href="/">Back to tastings</a></p>`);

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function readForm(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new HttpError(413, 'Request body too large.');
    chunks.push(chunk);
  }
  return Object.fromEntries(new URLSearchParams(Buffer.concat(chunks).toString()));
}

function send(res, status, body) {
  res.writeHead(status, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
  res.end(body);
}

// Browsers send Origin on cross-site POSTs; same-site requests from other ports are caught here too.
function sameOrigin(req) {
  const origin = req.headers.origin;
  if (origin === undefined) return true;
  try {
    return new URL(origin).host === req.headers.host;
  } catch {
    return false;
  }
}

function createApp({ staffPassword }) {
  const store = createStore();
  const sessions = new Set();

  const passwordMatches = (given) => {
    const digest = (s) => createHash('sha256').update(String(s)).digest();
    return timingSafeEqual(digest(given ?? ''), digest(staffPassword));
  };

  const isStaff = (req) => {
    const match = (req.headers.cookie ?? '').match(/(?:^|;\s*)staff_session=([0-9a-f]+)/);
    return Boolean(match && sessions.has(match[1]));
  };

  return async (req, res) => {
    try {
      if (req.method === 'POST' && !sameOrigin(req)) throw new HttpError(403, 'Cross-site request rejected.');
      const { pathname } = new URL(req.url, 'http://localhost');
      let m;

      if (req.method === 'GET' && pathname === '/') {
        return send(res, 200, startPage(store.listTastings()));
      }

      if (pathname === '/staff' && req.method === 'GET') {
        if (!isStaff(req)) return send(res, 200, signInPage());
        return send(res, 200, overviewPage(store.listBookingsByTasting()));
      }

      if (req.method === 'POST' && pathname === '/staff/sign-in') {
        const { password } = await readForm(req);
        if (!passwordMatches(password)) return send(res, 401, signInPage('Wrong password.'));
        const token = randomBytes(32).toString('hex');
        sessions.add(token);
        res.writeHead(303, {
          location: '/staff',
          'set-cookie': `staff_session=${token}; HttpOnly; SameSite=Strict; Path=/`,
        });
        return res.end();
      }

      if (req.method === 'POST' && (m = pathname.match(/^\/staff\/bookings\/([^/]+)\/cancel$/))) {
        if (!isStaff(req)) return send(res, 401, signInPage());
        if (!store.getBooking(m[1])) throw new HttpError(404, 'Not found');
        store.cancelBooking(m[1]);
        res.writeHead(303, { location: '/staff' });
        return res.end();
      }

      if ((m = pathname.match(/^\/tastings\/([^/]+)\/book$/))) {
        const tasting = store.getTasting(m[1]);
        if (!tasting) throw new HttpError(404, 'Not found');
        if (req.method === 'GET') return send(res, 200, bookingForm(tasting));
        if (req.method === 'POST') {
          const form = await readForm(req);
          const result = store.createBooking({ ...form, tastingId: tasting.id });
          if (result.error) {
            return send(res, 400, bookingForm(store.getTasting(tasting.id), form, result.error));
          }
          res.writeHead(303, { location: `/bookings/${result.booking.reference}` });
          return res.end();
        }
      }

      if (req.method === 'GET' && (m = pathname.match(/^\/bookings\/([^/]+)$/))) {
        const booking = store.getBooking(m[1]);
        if (!booking) throw new HttpError(404, 'Not found');
        return send(res, 200, confirmationPage(booking, store.getTasting(booking.tastingId)));
      }

      throw new HttpError(404, 'Not found');
    } catch (err) {
      if (err instanceof HttpError) {
        return send(res, err.status, layout(err.status === 404 ? 'Not found' : 'Error', `<h1>${esc(err.message)}</h1>`));
      }
      console.error(err);
      return send(res, 500, layout('Error', '<h1>Something went wrong</h1>'));
    }
  };
}

module.exports = { createApp };
