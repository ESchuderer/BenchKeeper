const http = require('node:http');
const { createApp } = require('./app');

const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) {
  console.error('STAFF_PASSWORD must be set.');
  process.exit(1);
}

const port = Number(process.env.PORT || 3000);
if (!Number.isInteger(port) || port < 0 || port > 65535) {
  console.error('PORT must be an integer from 0 to 65535.');
  process.exit(1);
}
http.createServer(createApp({ staffPassword })).listen(port, () => {
  console.log(`Listening on http://localhost:${port}`);
});
