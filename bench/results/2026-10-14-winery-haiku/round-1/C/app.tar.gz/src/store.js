const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', date: '2026-11-14', time: '15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', date: '2026-12-05', time: '17:00', price: 28, seats: 10 },
];

const EMAIL = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;

function createStore() {
  const bookings = new Map();
  let counter = 0;

  const guestsBooked = (tastingId) =>
    [...bookings.values()]
      .filter((b) => b.tastingId === tastingId)
      .reduce((sum, b) => sum + b.guests, 0);

  const withSeats = (t) => ({ ...t, seatsLeft: t.seats - guestsBooked(t.id) });

  const validate = ({ name, email, guests }) => {
    if (typeof name !== 'string' || !name.trim()) return 'Name is required.';
    if (typeof email !== 'string' || !EMAIL.test(email.trim())) return 'Enter a valid email address.';
    const text = String(guests).trim();
    const n = Number(text);
    if (!/^\d+$/.test(text) || n < 1 || n > 8) return 'Guests must be a whole number from 1 to 8.';
    return null;
  };

  return {
    listTastings: () => TASTINGS.map(withSeats),

    getTasting: (id) => {
      const t = TASTINGS.find((x) => x.id === id);
      return t && withSeats(t);
    },

    createBooking({ tastingId, name, email, guests }) {
      const tasting = TASTINGS.find((x) => x.id === tastingId);
      if (!tasting) return { error: 'Unknown tasting.' };
      const invalid = validate({ name, email, guests });
      if (invalid) return { error: invalid };
      const count = Number(String(guests).trim());
      const seatsLeft = tasting.seats - guestsBooked(tastingId);
      if (count > seatsLeft) return { error: `Not enough seats: ${seatsLeft} seats left.` };
      counter += 1;
      const booking = {
        reference: `KB-${counter}`,
        tastingId,
        name: name.trim(),
        email: email.trim(),
        guests: count,
        total: count * tasting.price,
      };
      bookings.set(booking.reference, booking);
      return { booking };
    },

    getBooking: (reference) => bookings.get(reference),

    cancelBooking: (reference) => bookings.delete(reference),

    listBookingsByTasting: () =>
      TASTINGS.map((t) => ({
        tasting: withSeats(t),
        bookings: [...bookings.values()].filter((b) => b.tastingId === t.id),
      })),
  };
}

module.exports = { createStore };
