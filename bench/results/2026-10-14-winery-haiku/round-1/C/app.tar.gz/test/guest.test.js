const { test } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createApp } = require('../src/app');

async function withApp(fn) {
  const server = http.createServer(createApp({ staffPassword: 'secret' }));
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    await fn(base);
  } finally {
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
  }
}

const get = (base, path) => fetch(base + path, { redirect: 'manual' });

const post = (base, path, fields) =>
  fetch(base + path, {
    method: 'POST',
    redirect: 'manual',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(fields),
  });

test('start page lists tastings with price, date, time, seats left and booking links', () =>
  withApp(async (base) => {
    const res = await get(base, '/');
    assert.equal(res.status, 200);
    const html = await res.text();
    for (const text of [
      'Riesling Evening', '2026-11-06', '18:00', 'EUR 25',
      'Red Wine Cellar Tour', '2026-11-14', '15:00', 'EUR 32',
      'Winter Tasting', '2026-12-05', '17:00', 'EUR 28',
      '12 seats left', '8 seats left', '10 seats left',
      'Book Riesling Evening', 'Book Red Wine Cellar Tour', 'Book Winter Tasting',
    ]) {
      assert.ok(html.includes(text), `start page should include "${text}"`);
    }
    assert.ok(html.includes('href="/tastings/riesling-evening/book"'));
  }));

test('booking form has Name, Email, Guests fields and a Book button', () =>
  withApp(async (base) => {
    const res = await get(base, '/tastings/riesling-evening/book');
    assert.equal(res.status, 200);
    const html = await res.text();
    assert.ok(html.includes('Riesling Evening'));
    assert.match(html, /<label[^>]*>\s*Name/);
    assert.match(html, /<label[^>]*>\s*Email/);
    assert.match(html, /<label[^>]*>\s*Guests/);
    assert.match(html, /<button[^>]*>\s*Book\s*<\/button>/);
    assert.ok(html.includes('action="/tastings/riesling-evening/book"'));
  }));

test('unknown tasting returns 404 for form and for booking', () =>
  withApp(async (base) => {
    assert.equal((await get(base, '/tastings/nope/book')).status, 404);
    assert.equal((await post(base, '/tastings/nope/book', { name: 'Ana', email: 'ana@example.com', guests: '1' })).status, 404);
  }));

test('valid booking redirects to a confirmation page', () =>
  withApp(async (base) => {
    const res = await post(base, '/tastings/winter-tasting/book', { name: 'Ana', email: 'ana@example.com', guests: '2' });
    assert.equal(res.status, 303);
    assert.equal(res.headers.get('location'), '/bookings/KB-1');

    const page = await get(base, '/bookings/KB-1');
    assert.equal(page.status, 200);
    const html = await page.text();
    assert.ok(html.includes('Booking confirmed'));
    assert.ok(html.includes('Winter Tasting'));
    assert.ok(html.includes('EUR 56'));
    assert.ok(html.includes('KB-1'));
    assert.match(html, />\s*2\s*</);
  }));

test('unknown booking reference returns 404', () =>
  withApp(async (base) => {
    assert.equal((await get(base, '/bookings/KB-99')).status, 404);
  }));

test('invalid booking returns 400 with an error and keeps the entered values', () =>
  withApp(async (base) => {
    const res = await post(base, '/tastings/riesling-evening/book', { name: 'Ana', email: 'bad-email', guests: '2' });
    assert.equal(res.status, 400);
    const html = await res.text();
    assert.ok(html.includes('Enter a valid email address.'));
    assert.match(html, /name="name"[^>]*value="Ana"/);
    assert.match(html, /name="email"[^>]*value="bad-email"/);
  }));

test('booking over the seats left returns 400 with the seats left', () =>
  withApp(async (base) => {
    await post(base, '/tastings/red-wine-cellar-tour/book', { name: 'Ana', email: 'ana@example.com', guests: '7' });
    const res = await post(base, '/tastings/red-wine-cellar-tour/book', { name: 'Ben', email: 'ben@example.com', guests: '3' });
    assert.equal(res.status, 400);
    assert.ok((await res.text()).includes('Not enough seats: 1 seats left.'));
  }));

test('user text is escaped when the form is shown again', () =>
  withApp(async (base) => {
    const name = '<script>alert(1)</script>';
    const res = await post(base, '/tastings/riesling-evening/book', { name, email: 'bad', guests: '1' });
    const html = await res.text();
    assert.ok(!html.includes(name));
    assert.ok(html.includes('&lt;script&gt;alert(1)&lt;/script&gt;'));
  }));

test('oversize form body is rejected with 413', () =>
  withApp(async (base) => {
    const res = await post(base, '/tastings/riesling-evening/book', { name: 'a'.repeat(20000), email: 'ana@example.com', guests: '1' });
    assert.equal(res.status, 413);
  }));

test('two simultaneous requests for the last seats: one succeeds, one is rejected', () =>
  withApp(async (base) => {
    const [a, b] = await Promise.all([
      post(base, '/tastings/red-wine-cellar-tour/book', { name: 'Ana', email: 'ana@example.com', guests: '8' }),
      post(base, '/tastings/red-wine-cellar-tour/book', { name: 'Ben', email: 'ben@example.com', guests: '8' }),
    ]);
    assert.deepEqual([a.status, b.status].sort(), [303, 400]);
  }));
