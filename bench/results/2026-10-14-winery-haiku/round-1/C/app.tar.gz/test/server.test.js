const { test } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const net = require('node:net');
const path = require('node:path');

const SERVER = path.join(__dirname, '..', 'src', 'server.js');

function freePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, '127.0.0.1', () => {
      const { port } = srv.address();
      srv.close(() => resolve(port));
    });
  });
}

function runServer(env) {
  const child = spawn(process.execPath, [SERVER], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  let stderr = '';
  child.stderr.on('data', (d) => (stderr += d));
  const exited = new Promise((resolve) => child.on('exit', (code) => resolve({ code, stderr })));
  return { child, exited };
}

test('refuses to start without STAFF_PASSWORD', async () => {
  const env = { ...process.env, PORT: String(await freePort()) };
  delete env.STAFF_PASSWORD;
  const { exited } = runServer(env);
  const { code, stderr } = await exited;
  assert.notEqual(code, 0);
  assert.match(stderr, /STAFF_PASSWORD/);
});

test('refuses an invalid PORT', async () => {
  const env = { ...process.env, STAFF_PASSWORD: 'pw', PORT: 'abc' };
  const { exited } = runServer(env);
  const { code, stderr } = await exited;
  assert.notEqual(code, 0);
  assert.match(stderr, /PORT/);
});

test('serves the start page on PORT when STAFF_PASSWORD is set', async () => {
  const port = await freePort();
  const { child } = runServer({ ...process.env, STAFF_PASSWORD: 'pw', PORT: String(port) });
  try {
    let res;
    for (let i = 0; i < 50 && !res; i++) {
      try {
        res = await fetch(`http://127.0.0.1:${port}/`);
      } catch {
        await new Promise((r) => setTimeout(r, 100));
      }
    }
    assert.ok(res, 'server did not respond');
    assert.equal(res.status, 200);
    assert.ok((await res.text()).includes('Riesling Evening'));
  } finally {
    child.kill();
  }
});
