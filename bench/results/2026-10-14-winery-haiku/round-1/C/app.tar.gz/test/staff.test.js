const { test } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createApp } = require('../src/app');

const PASSWORD = 'correct-horse';

async function withApp(fn) {
  const server = http.createServer(createApp({ staffPassword: PASSWORD }));
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    await fn(base);
  } finally {
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
  }
}

const get = (base, path, cookie) =>
  fetch(base + path, { redirect: 'manual', headers: cookie ? { cookie } : {} });

const post = (base, path, fields, cookie) =>
  fetch(base + path, {
    method: 'POST',
    redirect: 'manual',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      ...(cookie ? { cookie } : {}),
    },
    body: new URLSearchParams(fields ?? {}),
  });

async function signIn(base, password = PASSWORD) {
  const res = await post(base, '/staff/sign-in', { password });
  const setCookie = res.headers.get('set-cookie') ?? '';
  return { res, cookie: setCookie.split(';')[0], setCookie };
}

test('sign-in page has Password field and Sign in button', () =>
  withApp(async (base) => {
    const res = await get(base, '/staff');
    assert.equal(res.status, 200);
    const html = await res.text();
    assert.match(html, /<label[^>]*>\s*Password/);
    assert.match(html, /<button[^>]*>\s*Sign in\s*<\/button>/);
  }));

test('wrong password shows an error and no booking data', () =>
  withApp(async (base) => {
    await post(base, '/tastings/riesling-evening/book', { name: 'Secret Guest', email: 'sg@example.com', guests: '1' });
    const { res, cookie } = await signIn(base, 'wrong');
    assert.equal(res.status, 401);
    assert.equal(cookie, '');
    const html = await res.text();
    assert.ok(html.includes('Wrong password.'));
    assert.ok(!html.includes('Secret Guest'));
  }));

test('correct password sets an HttpOnly SameSite=Strict session cookie and redirects to the overview', () =>
  withApp(async (base) => {
    const { res, cookie, setCookie } = await signIn(base);
    assert.equal(res.status, 303);
    assert.equal(res.headers.get('location'), '/staff');
    assert.ok(cookie.startsWith('staff_session='));
    assert.ok(setCookie.includes('HttpOnly'));
    assert.ok(setCookie.includes('SameSite=Strict'));
  }));

test('overview groups bookings by tasting with name, email, guests and reference', () =>
  withApp(async (base) => {
    await post(base, '/tastings/riesling-evening/book', { name: 'Ana Weber', email: 'ana@example.com', guests: '3' });
    await post(base, '/tastings/winter-tasting/book', { name: 'Ben Ruiz', email: 'ben@example.com', guests: '2' });
    const { cookie } = await signIn(base);
    const html = await (await get(base, '/staff', cookie)).text();

    const riesling = html.indexOf('Riesling Evening');
    const cellar = html.indexOf('Red Wine Cellar Tour');
    const winter = html.indexOf('Winter Tasting');
    assert.ok(riesling >= 0 && cellar > riesling && winter > cellar, 'groups in tasting order');

    const rieslingGroup = html.slice(riesling, cellar);
    assert.ok(rieslingGroup.includes('Ana Weber'));
    assert.ok(rieslingGroup.includes('ana@example.com'));
    assert.ok(rieslingGroup.includes('KB-1'));
    assert.ok(!rieslingGroup.includes('Ben Ruiz'));

    const winterGroup = html.slice(winter);
    assert.ok(winterGroup.includes('Ben Ruiz'));
    assert.ok(winterGroup.includes('KB-2'));
  }));

test('tasting without bookings shows a no-bookings message', () =>
  withApp(async (base) => {
    const { cookie } = await signIn(base);
    const html = await (await get(base, '/staff', cookie)).text();
    assert.ok(html.includes('No bookings'));
  }));

test('staff-entered names are escaped in the overview', () =>
  withApp(async (base) => {
    await post(base, '/tastings/riesling-evening/book', { name: '<script>x</script>', email: 'ana@example.com', guests: '1' });
    const { cookie } = await signIn(base);
    const html = await (await get(base, '/staff', cookie)).text();
    assert.ok(!html.includes('<script>x</script>'));
    assert.ok(html.includes('&lt;script&gt;x&lt;/script&gt;'));
  }));

test('overview without a session shows the sign-in page and no booking data', () =>
  withApp(async (base) => {
    await post(base, '/tastings/riesling-evening/book', { name: 'Ana Weber', email: 'ana@example.com', guests: '1' });
    const res = await get(base, '/staff');
    const html = await res.text();
    assert.match(html, /<button[^>]*>\s*Sign in\s*<\/button>/);
    assert.ok(!html.includes('Ana Weber'));
  }));

test('cancel removes the booking and frees its seats on the start page', () =>
  withApp(async (base) => {
    await post(base, '/tastings/riesling-evening/book', { name: 'Ana Weber', email: 'ana@example.com', guests: '3' });
    const { cookie } = await signIn(base);
    const res = await post(base, '/staff/bookings/KB-1/cancel', {}, cookie);
    assert.equal(res.status, 303);
    assert.equal(res.headers.get('location'), '/staff');

    const overview = await (await get(base, '/staff', cookie)).text();
    assert.ok(!overview.includes('Ana Weber'));

    const start = await (await get(base, '/')).text();
    assert.ok(start.includes('12 seats left'));
  }));

test('cancel without a session changes nothing and shows the sign-in page', () =>
  withApp(async (base) => {
    await post(base, '/tastings/riesling-evening/book', { name: 'Ana Weber', email: 'ana@example.com', guests: '3' });
    const res = await post(base, '/staff/bookings/KB-1/cancel', {});
    assert.equal(res.status, 401);
    assert.ok((await res.text()).includes('Sign in'));

    const start = await (await get(base, '/')).text();
    assert.ok(start.includes('9 seats left'));
  }));

test('cancel of an unknown reference returns 404', () =>
  withApp(async (base) => {
    const { cookie } = await signIn(base);
    assert.equal((await post(base, '/staff/bookings/KB-99/cancel', {}, cookie)).status, 404);
  }));

test('forged session cookie is treated as signed out', () =>
  withApp(async (base) => {
    await post(base, '/tastings/riesling-evening/book', { name: 'Ana Weber', email: 'ana@example.com', guests: '1' });
    const cookie = 'staff_session=' + 'ab'.repeat(32);
    assert.ok(!(await (await get(base, '/staff', cookie)).text()).includes('Ana Weber'));
    assert.equal((await post(base, '/staff/bookings/KB-1/cancel', {}, cookie)).status, 401);
  }));

test('cancel from another origin is rejected even with a valid session', () =>
  withApp(async (base) => {
    await post(base, '/tastings/riesling-evening/book', { name: 'Ana Weber', email: 'ana@example.com', guests: '1' });
    const { cookie } = await signIn(base);
    const res = await fetch(base + '/staff/bookings/KB-1/cancel', {
      method: 'POST',
      redirect: 'manual',
      headers: { cookie, origin: 'http://evil.example' },
    });
    assert.equal(res.status, 403);
    const start = await (await get(base, '/')).text();
    assert.ok(start.includes('11 seats left'));
  }));
