const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createStore } = require('../src/store');

test('seeds three tastings with title, date, time, price and seats', () => {
  const tastings = createStore().listTastings();
  assert.deepEqual(
    tastings.map(({ title, date, time, price, seats }) => [title, date, time, price, seats]),
    [
      ['Riesling Evening', '2026-11-06', '18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14', '15:00', 32, 8],
      ['Winter Tasting', '2026-12-05', '17:00', 28, 10],
    ],
  );
});

test('seats left equal seats minus booked guests', () => {
  const store = createStore();
  const riesling = store.listTastings()[0];
  assert.equal(riesling.seatsLeft, 12);
  store.createBooking({ tastingId: riesling.id, name: 'Ana', email: 'ana@example.com', guests: 3 });
  assert.equal(store.getTasting(riesling.id).seatsLeft, 9);
});

test('accepted booking returns reference, guests, total and tasting', () => {
  const store = createStore();
  const winter = store.listTastings()[2];
  const { booking } = store.createBooking({ tastingId: winter.id, name: 'Ana', email: 'ana@example.com', guests: '2' });
  assert.equal(booking.reference, 'KB-1');
  assert.equal(booking.tastingId, winter.id);
  assert.equal(booking.name, 'Ana');
  assert.equal(booking.email, 'ana@example.com');
  assert.equal(booking.guests, 2);
  assert.equal(booking.total, 56);
});

test('rejects more guests than seats left and leaves seats unchanged', () => {
  const store = createStore();
  const cellar = store.listTastings()[1];
  store.createBooking({ tastingId: cellar.id, name: 'Ana', email: 'ana@example.com', guests: 6 });
  const result = store.createBooking({ tastingId: cellar.id, name: 'Ben', email: 'ben@example.com', guests: 3 });
  assert.match(result.error, /2 seats left/);
  assert.equal(result.booking, undefined);
  assert.equal(store.getTasting(cellar.id).seatsLeft, 2);
});

test('accepts a booking that takes the last seats', () => {
  const store = createStore();
  const cellar = store.listTastings()[1];
  const result = store.createBooking({ tastingId: cellar.id, name: 'Ana', email: 'ana@example.com', guests: 8 });
  assert.equal(result.error, undefined);
  assert.equal(store.getTasting(cellar.id).seatsLeft, 0);
});

test('rejects invalid input and creates no booking', () => {
  const store = createStore();
  const riesling = store.listTastings()[0];
  const invalid = [
    { name: '', email: 'ana@example.com', guests: 2 },
    { name: '   ', email: 'ana@example.com', guests: 2 },
    { name: 'Ana', email: 'not-an-email', guests: 2 },
    { name: 'Ana', email: '', guests: 2 },
    { name: 'Ana', email: 'ana@example..com', guests: 2 },
    { name: 'Ana', email: 'ana@example.com', guests: 0 },
    { name: 'Ana', email: 'ana@example.com', guests: 9 },
    { name: 'Ana', email: 'ana@example.com', guests: '2.5' },
    { name: 'Ana', email: 'ana@example.com', guests: 'two' },
    { name: 'Ana', email: 'ana@example.com', guests: '' },
  ];
  for (const input of invalid) {
    const result = store.createBooking({ tastingId: riesling.id, ...input });
    assert.ok(result.error, `expected error for ${JSON.stringify(input)}`);
    assert.equal(result.booking, undefined);
  }
  assert.equal(store.getTasting(riesling.id).seatsLeft, 12);
  assert.deepEqual(store.listBookingsByTasting()[0].bookings, []);
});

test('rejects an unknown tasting', () => {
  const result = createStore().createBooking({ tastingId: 'nope', name: 'Ana', email: 'ana@example.com', guests: 1 });
  assert.ok(result.error);
});

test('gives each accepted booking a distinct reference', () => {
  const store = createStore();
  const riesling = store.listTastings()[0];
  const first = store.createBooking({ tastingId: riesling.id, name: 'Ana', email: 'ana@example.com', guests: 1 });
  const second = store.createBooking({ tastingId: riesling.id, name: 'Ben', email: 'ben@example.com', guests: 1 });
  assert.notEqual(first.booking.reference, second.booking.reference);
});

test('lists bookings grouped by tasting', () => {
  const store = createStore();
  const [riesling, cellar] = store.listTastings();
  store.createBooking({ tastingId: riesling.id, name: 'Ana', email: 'ana@example.com', guests: 1 });
  const groups = store.listBookingsByTasting();
  assert.equal(groups.length, 3);
  assert.equal(groups[0].tasting.id, riesling.id);
  assert.equal(groups[0].bookings.length, 1);
  assert.equal(groups[1].tasting.id, cellar.id);
  assert.deepEqual(groups[1].bookings, []);
});

test('cancelling a booking frees its seats', () => {
  const store = createStore();
  const riesling = store.listTastings()[0];
  const { booking } = store.createBooking({ tastingId: riesling.id, name: 'Ana', email: 'ana@example.com', guests: 3 });
  assert.equal(store.getTasting(riesling.id).seatsLeft, 9);
  assert.equal(store.cancelBooking(booking.reference), true);
  assert.equal(store.getTasting(riesling.id).seatsLeft, 12);
  assert.equal(store.getBooking(booking.reference), undefined);
  assert.equal(store.cancelBooking(booking.reference), false);
});
