const http = require('node:http');
const crypto = require('node:crypto');

const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', when: '2026-11-06 18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', when: '2026-11-14 15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', when: '2026-12-05 17:00', price: 28, seats: 10 },
];

const CSS = `body{font-family:system-ui,sans-serif;max-width:52rem;margin:0 auto;padding:1rem;color:#2d2230;background:#fbf8f5}
header{display:flex;gap:1.5rem;border-bottom:1px solid #d8cdd5;padding-bottom:.5rem}
header a{color:#6b1d3a;font-weight:600;text-decoration:none}
table{border-collapse:collapse;width:100%}
th,td{text-align:left;padding:.5rem;border-bottom:1px solid #e6dde3}
a.button,button{background:#6b1d3a;color:#fff;border:0;border-radius:4px;padding:.5rem 1rem;font:inherit;text-decoration:none;cursor:pointer}
label{display:block;margin:.75rem 0}
input{display:block;margin-top:.25rem;padding:.4rem;font:inherit;width:100%;max-width:20rem;box-sizing:border-box}
.error{color:#a4161a;font-weight:600}`;

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
const sha256 = (s) => crypto.createHash('sha256').update(s).digest();

function seatsLeft(tasting, bookings) {
  const booked = bookings.filter((b) => b.tastingId === tasting.id).reduce((n, b) => n + b.guests, 0);
  return tasting.seats - booked;
}

function newRef(bookings) {
  let ref;
  do ref = crypto.randomBytes(4).toString('hex').toUpperCase();
  while (bookings.some((b) => b.ref === ref));
  return ref;
}

function validate({ name, email, guests }, tasting, bookings) {
  if (!name || name.length > 100) return 'Enter your name (up to 100 characters).';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return 'Enter a valid email address.';
  if (!/^\d+$/.test(guests) || Number(guests) < 1 || Number(guests) > 8) return 'Guests must be a whole number from 1 to 8.';
  const left = seatsLeft(tasting, bookings);
  if (Number(guests) > left) return left ? `Only ${left} seat${left === 1 ? '' : 's'} left.` : 'This tasting is fully booked.';
  return '';
}

async function readForm(req) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (body.length > 10_000) throw Object.assign(new Error('Request too large'), { status: 413 });
  }
  return new URLSearchParams(body);
}

const layout = (title, body) => `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} | Weingut Kieselbrunnen</title>
<style>${CSS}</style>
</head>
<body>
<header><a href="/">Weingut Kieselbrunnen</a><a href="/staff">Staff</a></header>
<main>${body}</main>
</body>
</html>`;

const listPage = (bookings) => `<h1>Wine tastings</h1>
<table>
<tr><th>Tasting</th><th>Date and time</th><th>Price</th><th>Seats</th><th></th></tr>
${TASTINGS.map((t) => `<tr>
<td>${esc(t.title)}</td><td>${esc(t.when)}</td><td>EUR ${t.price} per guest</td><td>${seatsLeft(t, bookings)} seats left</td>
<td><a class="button" href="/tastings/${t.id}/book">Book ${esc(t.title)}</a></td>
</tr>`).join('')}
</table>`;

const formPage = (t, v, error) => `<h1>Book ${esc(t.title)}</h1>
<p>${esc(t.when)}, EUR ${t.price} per guest</p>
<form method="post" novalidate>
${error ? `<p class="error" role="alert">${esc(error)}</p>` : ''}
<label>Name<input name="name" value="${esc(v.name)}" required></label>
<label>Email<input type="email" name="email" value="${esc(v.email)}" required></label>
<label>Guests<input type="number" name="guests" min="1" max="8" value="${esc(v.guests)}" required></label>
<button>Book</button>
</form>`;

const confirmPage = (t, b) => `<h1>Booking confirmed</h1>
<dl>
<dt>Tasting</dt><dd>${esc(t.title)}</dd>
<dt>Date and time</dt><dd>${esc(t.when)}</dd>
<dt>Guests</dt><dd>${b.guests}</dd>
<dt>Total price</dt><dd>EUR ${t.price * b.guests}</dd>
<dt>Booking reference</dt><dd>${b.ref}</dd>
</dl>`;

const loginPage = (error) => `<h1>Staff sign in</h1>
<form method="post" action="/staff/sign-in">
${error ? `<p class="error" role="alert">${esc(error)}</p>` : ''}
<label>Password<input type="password" name="password" required></label>
<button>Sign in</button>
</form>`;

const staffPage = (bookings) => `<h1>Bookings</h1>
${TASTINGS.map((t) => {
  const list = bookings.filter((b) => b.tastingId === t.id);
  const rows = list.map((b) => `<tr><td>${esc(b.name)}</td><td>${esc(b.email)}</td><td>${b.guests}</td><td>${b.ref}</td>
<td><form method="post" action="/staff/bookings/${b.ref}/cancel"><button>Cancel</button></form></td></tr>`).join('');
  return `<section>
<h2>${esc(t.title)}, ${esc(t.when)}</h2>
${list.length ? `<table>
<tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th></th></tr>
${rows}
</table>` : '<p>No bookings.</p>'}
</section>`;
}).join('')}`;

function createServer({ staffPassword }) {
  const bookings = [];
  const sessions = new Set();

  // An empty or unset password disables staff sign-in.
  const passwordMatches = (given) => Boolean(staffPassword) && crypto.timingSafeEqual(sha256(given), sha256(staffPassword));
  const isStaff = (req) => {
    const m = (req.headers.cookie || '').match(/(?:^|;\s*)staff=([0-9a-f]{32})/);
    return Boolean(m && sessions.has(m[1]));
  };

  async function route(req, res) {
    const { pathname } = new URL(req.url, 'http://localhost');
    const { method } = req;
    const send = (status, html, headers = {}) => {
      res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', ...headers });
      res.end(html);
    };
    const redirect = (location, headers = {}) => {
      res.writeHead(303, { Location: location, ...headers });
      res.end();
    };

    if (method === 'GET' && pathname === '/') return send(200, layout('Tastings', listPage(bookings)));

    const bookMatch = pathname.match(/^\/tastings\/([\w-]+)\/book$/);
    const tasting = bookMatch && TASTINGS.find((t) => t.id === bookMatch[1]);
    if (tasting && method === 'GET') {
      return send(200, layout(`Book ${tasting.title}`, formPage(tasting, { name: '', email: '', guests: '1' }, '')));
    }
    if (tasting && method === 'POST') {
      const form = await readForm(req);
      const values = {
        name: (form.get('name') || '').trim(),
        email: (form.get('email') || '').trim(),
        guests: (form.get('guests') || '').trim(),
      };
      const error = validate(values, tasting, bookings);
      if (error) return send(400, layout(`Book ${tasting.title}`, formPage(tasting, values, error)));
      const booking = { ref: newRef(bookings), tastingId: tasting.id, name: values.name, email: values.email, guests: Number(values.guests) };
      bookings.push(booking);
      return redirect(`/bookings/${booking.ref}`);
    }

    const confirmMatch = pathname.match(/^\/bookings\/(\w+)$/);
    const booking = method === 'GET' && confirmMatch && bookings.find((b) => b.ref === confirmMatch[1]);
    if (booking) {
      const t = TASTINGS.find((x) => x.id === booking.tastingId);
      return send(200, layout('Booking confirmed', confirmPage(t, booking)));
    }

    if (method === 'GET' && pathname === '/staff') {
      return send(200, layout('Staff', isStaff(req) ? staffPage(bookings) : loginPage('')));
    }
    if (method === 'POST' && pathname === '/staff/sign-in') {
      const form = await readForm(req);
      if (!passwordMatches(form.get('password') || '')) {
        return send(401, layout('Staff', loginPage('Wrong password.')));
      }
      const token = crypto.randomBytes(16).toString('hex');
      sessions.add(token);
      return redirect('/staff', { 'Set-Cookie': `staff=${token}; HttpOnly; SameSite=Strict; Path=/` });
    }

    const cancelMatch = pathname.match(/^\/staff\/bookings\/(\w+)\/cancel$/);
    if (method === 'POST' && cancelMatch) {
      if (!isStaff(req)) return send(401, layout('Staff', loginPage('Sign in to cancel bookings.')));
      const i = bookings.findIndex((b) => b.ref === cancelMatch[1]);
      if (i !== -1) bookings.splice(i, 1);
      return redirect('/staff');
    }

    send(404, layout('Not found', '<h1>Not found</h1>'));
  }

  return http.createServer((req, res) => {
    route(req, res).catch((err) => {
      if (!err.status) console.error(err);
      res.writeHead(err.status || 500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end(err.status ? err.message : 'Server error');
    });
  });
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  if (!process.env.STAFF_PASSWORD) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
  createServer({ staffPassword: process.env.STAFF_PASSWORD }).listen(port, () => {
    console.log(`Listening on port ${port}`);
  });
}

module.exports = { createServer };
