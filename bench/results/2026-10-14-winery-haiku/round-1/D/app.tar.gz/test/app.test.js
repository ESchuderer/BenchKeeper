const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../server');

async function start(staffPassword) {
  const server = createServer({ staffPassword });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { base, close: () => new Promise((resolve) => server.close(resolve)) };
}

const post = (url, fields, headers = {}) => fetch(url, {
  method: 'POST',
  redirect: 'manual',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...headers },
  body: new URLSearchParams(fields),
});

const guest = { name: 'Anna', email: 'anna@example.com', guests: '1' };

test('seats are reduced by bookings and never overbooked', async () => {
  const { base, close } = await start('secret');
  try {
    assert.match(await (await fetch(base)).text(), /12 seats left/);

    const first = await post(`${base}/tastings/riesling-evening/book`, { ...guest, guests: '5' });
    assert.equal(first.status, 303);
    assert.match(await (await fetch(base)).text(), /7 seats left/);

    const tooMany = await post(`${base}/tastings/riesling-evening/book`, { ...guest, guests: '8' });
    assert.equal(tooMany.status, 400);
    assert.match(await tooMany.text(), /Only 7 seats left\./);

    const exact = await post(`${base}/tastings/riesling-evening/book`, { ...guest, guests: '7' });
    assert.equal(exact.status, 303);

    const full = await post(`${base}/tastings/riesling-evening/book`, guest);
    assert.equal(full.status, 400);
    assert.match(await full.text(), /This tasting is fully booked\./);
  } finally {
    await close();
  }
});

test('invalid booking input is rejected', async () => {
  const { base, close } = await start('secret');
  try {
    const bad = [
      { ...guest, name: '   ' },
      { ...guest, email: 'not-an-email' },
      { ...guest, guests: '0' },
      { ...guest, guests: '9' },
      { ...guest, guests: '1.5' },
      { ...guest, guests: '' },
    ];
    for (const fields of bad) {
      const res = await post(`${base}/tastings/winter-tasting/book`, fields);
      assert.equal(res.status, 400, JSON.stringify(fields));
      assert.match(await res.text(), /class="error"/);
    }
    assert.match(await (await fetch(base)).text(), /10 seats left/);
  } finally {
    await close();
  }
});

test('confirmation shows the booking and total price', async () => {
  const { base, close } = await start('secret');
  try {
    const res = await post(`${base}/tastings/red-wine-cellar-tour/book`, { ...guest, guests: '3' });
    const location = res.headers.get('location');
    const page = await (await fetch(`${base}${location}`)).text();
    assert.match(page, /Booking confirmed/);
    assert.match(page, /Red Wine Cellar Tour/);
    assert.match(page, /EUR 96/);
    const ref = location.split('/').pop();
    assert.match(page, new RegExp(ref));
  } finally {
    await close();
  }
});

test('staff sign in, see and cancel bookings', async () => {
  const { base, close } = await start('secret');
  try {
    assert.match(await (await fetch(`${base}/staff`)).text(), /Password/);
    await post(`${base}/tastings/winter-tasting/book`, { ...guest, name: 'Ben Berg', guests: '4' });

    const wrong = await post(`${base}/staff/sign-in`, { password: 'nope' });
    assert.equal(wrong.status, 401);

    const ok = await post(`${base}/staff/sign-in`, { password: 'secret' });
    assert.equal(ok.status, 303);
    const cookie = ok.headers.get('set-cookie').split(';')[0];

    const list = await (await fetch(`${base}/staff`, { headers: { Cookie: cookie } })).text();
    assert.match(list, /Winter Tasting/);
    assert.match(list, /Ben Berg/);
    const ref = list.match(/action="\/staff\/bookings\/(\w+)\/cancel"/)[1];

    const anon = await post(`${base}/staff/bookings/${ref}/cancel`, {});
    assert.equal(anon.status, 401);
    assert.match(await (await fetch(base)).text(), /6 seats left/);

    const cancel = await post(`${base}/staff/bookings/${ref}/cancel`, {}, { Cookie: cookie });
    assert.equal(cancel.status, 303);
    assert.match(await (await fetch(base)).text(), /10 seats left/);
  } finally {
    await close();
  }
});

test('staff sign in is disabled when no password is configured', async () => {
  const { base, close } = await start(undefined);
  try {
    const res = await post(`${base}/staff/sign-in`, { password: '' });
    assert.equal(res.status, 401);
  } finally {
    await close();
  }
});
