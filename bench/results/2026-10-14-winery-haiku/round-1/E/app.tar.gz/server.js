import { createServer } from 'node:http';
import { createApp } from './src/app.js';
import { createStore } from './src/store.js';

const port = Number(process.env.PORT || 3000);
const staffPassword = process.env.STAFF_PASSWORD || '';

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

const store = createStore();

createServer(createApp({ store, staffPassword })).listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on port ${port}`);
});
