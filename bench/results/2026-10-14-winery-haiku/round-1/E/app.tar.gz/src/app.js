import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import {
  renderBookingForm,
  renderConfirmation,
  renderMessage,
  renderStaffBookings,
  renderStaffLogin,
  renderTastingList,
} from './views.js';

const MAX_BODY_BYTES = 16 * 1024;
const MAX_GUESTS = 8;
const MAX_NAME_LENGTH = 100;
const MAX_EMAIL_LENGTH = 254;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const SESSION_COOKIE = 'staff_session';

const readCookie = (header = '', name) =>
  header
    .split(';')
    .map((part) => part.trim())
    .find((part) => part.startsWith(`${name}=`))
    ?.slice(name.length + 1);

const readForm = async (req) => {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw Object.assign(new Error('Request body too large'), { status: 413 });
    chunks.push(chunk);
  }
  return new URLSearchParams(Buffer.concat(chunks).toString('utf8'));
};

// Returns the first problem with the form, or null when the booking may be stored.
function validateBooking({ name, email, guests }, seatsLeft) {
  if (!name || name.length > MAX_NAME_LENGTH) return `Enter your name (up to ${MAX_NAME_LENGTH} characters).`;
  if (!EMAIL_PATTERN.test(email) || email.length > MAX_EMAIL_LENGTH) return 'Enter a valid email address.';
  if (!/^\d+$/.test(guests) || Number(guests) < 1 || Number(guests) > MAX_GUESTS) {
    return `Guests must be a whole number from 1 to ${MAX_GUESTS}.`;
  }
  if (Number(guests) > seatsLeft) return `Only ${seatsLeft} seats left for this tasting.`;
  return null;
}

export function createApp({ store, staffPassword }) {
  const sessions = new Set();

  const send = (res, status, html, headers = {}) => {
    res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', ...headers });
    res.end(html);
  };
  const redirect = (res, location, headers = {}) => {
    res.writeHead(303, { Location: location, ...headers });
    res.end();
  };

  const passwordMatches = (given) => {
    // Hashing both values gives equal lengths for timingSafeEqual.
    const digest = (value) => createHash('sha256').update(value).digest();
    return timingSafeEqual(digest(given), digest(staffPassword));
  };
  const isStaff = (req) => sessions.has(readCookie(req.headers.cookie, SESSION_COOKIE));

  const listTastings = (req, res) => send(res, 200, renderTastingList(store.tastings()));

  const showBookingForm = (req, res, id) => {
    const tasting = store.tasting(id);
    if (!tasting) return send(res, 404, renderMessage('Not found', 'This tasting does not exist.'));
    return send(res, 200, renderBookingForm(tasting));
  };

  const submitBooking = async (req, res, id) => {
    // Read the body before the seat count: the await lets other bookings land first.
    const fields = await readForm(req);
    const tasting = store.tasting(id);
    if (!tasting) return send(res, 404, renderMessage('Not found', 'This tasting does not exist.'));
    const values = {
      name: (fields.get('name') ?? '').trim(),
      email: (fields.get('email') ?? '').trim(),
      guests: (fields.get('guests') ?? '').trim(),
    };
    const error = validateBooking(values, tasting.seatsLeft);
    if (error) return send(res, 400, renderBookingForm(tasting, values, error));
    // Validation and insert run without an await in between, so no other booking can take the seats.
    const booking = store.add({ tastingId: tasting.id, name: values.name, email: values.email, guests: Number(values.guests) });
    return redirect(res, `/booking/${booking.reference}`);
  };

  const showConfirmation = (req, res, reference) => {
    const booking = store.booking(reference);
    if (!booking) return send(res, 404, renderMessage('Not found', 'This booking does not exist.'));
    return send(res, 200, renderConfirmation(booking, store.tasting(booking.tastingId)));
  };

  const showStaff = (req, res) =>
    isStaff(req)
      ? send(res, 200, renderStaffBookings(store.tastings(), store.bookings()))
      : send(res, 200, renderStaffLogin());

  const signIn = async (req, res) => {
    if (!staffPassword) return send(res, 503, renderStaffLogin('Staff sign-in is not configured.'));
    const fields = await readForm(req);
    if (!passwordMatches(fields.get('password') ?? '')) {
      return send(res, 401, renderStaffLogin('Wrong password.'));
    }
    const token = randomBytes(32).toString('hex');
    sessions.add(token);
    return redirect(res, '/staff', { 'Set-Cookie': `${SESSION_COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/` });
  };

  const cancelBooking = (req, res, reference) => {
    if (isStaff(req)) store.cancel(reference);
    return redirect(res, '/staff');
  };

  const routes = [
    ['GET', /^\/$/, listTastings],
    ['GET', /^\/book\/([\w-]+)$/, showBookingForm],
    ['POST', /^\/book\/([\w-]+)$/, submitBooking],
    ['GET', /^\/booking\/(\w+)$/, showConfirmation],
    ['GET', /^\/staff$/, showStaff],
    ['POST', /^\/staff\/login$/, signIn],
    ['POST', /^\/staff\/bookings\/(\w+)\/cancel$/, cancelBooking],
  ];

  return async function handle(req, res) {
    try {
      const { pathname } = new URL(req.url, 'http://localhost');
      const route = routes.find(([method, pattern]) => method === req.method && pattern.test(pathname));
      if (!route) return send(res, 404, renderMessage('Not found', 'This page does not exist.'));
      const [, pattern, handler] = route;
      const [, ...params] = pathname.match(pattern);
      await handler(req, res, ...params);
    } catch (error) {
      const status = error.status ?? 500;
      if (status === 500) console.error(error);
      if (res.headersSent) return res.end();
      const message = status === 413 ? 'The request is too large.' : 'Something went wrong. Please try again.';
      send(res, status, renderMessage('Error', message));
    }
  };
}
