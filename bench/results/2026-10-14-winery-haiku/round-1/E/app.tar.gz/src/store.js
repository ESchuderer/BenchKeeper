import { randomBytes } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

export const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', dateTime: '2026-11-06 18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', dateTime: '2026-11-14 15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', dateTime: '2026-12-05 17:00', price: 28, seats: 10 },
];

const DEFAULT_FILE = fileURLToPath(new URL('../data/bookings.json', import.meta.url));

const newReference = () => randomBytes(4).toString('hex').toUpperCase();

export function createStore(file = DEFAULT_FILE) {
  mkdirSync(dirname(file), { recursive: true });
  // A corrupt file throws here instead of being overwritten with an empty list.
  let bookings = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : [];

  const save = (next) => {
    const tmp = `${file}.tmp`;
    writeFileSync(tmp, JSON.stringify(next, null, 2));
    renameSync(tmp, file);
    bookings = next;
  };

  const seatsTaken = (tastingId) =>
    bookings.filter((booking) => booking.tastingId === tastingId).reduce((sum, booking) => sum + booking.guests, 0);

  const withSeatsLeft = (tasting) => ({ ...tasting, seatsLeft: tasting.seats - seatsTaken(tasting.id) });

  return {
    tastings: () => TASTINGS.map(withSeatsLeft),
    tasting: (id) => {
      const tasting = TASTINGS.find((item) => item.id === id);
      return tasting && withSeatsLeft(tasting);
    },
    bookings: () => bookings,
    booking: (reference) => bookings.find((booking) => booking.reference === reference),
    add({ tastingId, name, email, guests }) {
      let reference;
      do {
        reference = newReference();
      } while (bookings.some((booking) => booking.reference === reference));
      const booking = { reference, tastingId, name, email, guests };
      save([...bookings, booking]);
      return booking;
    },
    cancel(reference) {
      const next = bookings.filter((booking) => booking.reference !== reference);
      if (next.length === bookings.length) return false;
      save(next);
      return true;
    },
  };
}
