const HTML_ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

const esc = (value) => String(value).replace(/[&<>"']/g, (char) => HTML_ESCAPES[char]);

const errorBox = (error) => (error ? `<p class="error" role="alert">${esc(error)}</p>` : '');

const page = (title, body) => `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} | Weingut Kieselbrunnen</title>
<style>
body { font-family: system-ui, sans-serif; max-width: 52rem; margin: 2rem auto; padding: 0 1rem; color: #222; }
table { border-collapse: collapse; width: 100%; margin-bottom: 2rem; }
th, td { text-align: left; padding: .4rem .6rem; border-bottom: 1px solid #ddd; }
.error { color: #a00; }
</style>
</head>
<body>
<header><a href="/">Weingut Kieselbrunnen</a></header>
<main>
${body}
</main>
</body>
</html>`;

export const renderMessage = (title, text) =>
  page(title, `<h1>${esc(title)}</h1>\n<p>${esc(text)}</p>\n<p><a href="/">Back to tastings</a></p>`);

export const renderTastingList = (tastings) =>
  page(
    'Tastings',
    `<h1>Wine tastings</h1>
<table>
<thead><tr><th>Tasting</th><th>Date and time</th><th>Price per guest</th><th>Seats</th><th></th></tr></thead>
<tbody>
${tastings
  .map(
    (tasting) => `<tr>
<td>${esc(tasting.title)}</td>
<td>${esc(tasting.dateTime)}</td>
<td>EUR ${esc(tasting.price)}</td>
<td>${esc(tasting.seatsLeft)} seats left</td>
<td><a href="/book/${esc(tasting.id)}">Book ${esc(tasting.title)}</a></td>
</tr>`,
  )
  .join('\n')}
</tbody>
</table>`,
  );

export const renderBookingForm = (tasting, values = {}, error = null) =>
  page(
    `Book ${tasting.title}`,
    `<h1>${esc(tasting.title)}</h1>
<p>${esc(tasting.dateTime)}, EUR ${esc(tasting.price)} per guest, ${esc(tasting.seatsLeft)} seats left</p>
<form method="post" action="/book/${esc(tasting.id)}" novalidate>
${errorBox(error)}
<p><label>Name <input name="name" value="${esc(values.name ?? '')}" maxlength="100" required></label></p>
<p><label>Email <input name="email" type="email" value="${esc(values.email ?? '')}" required></label></p>
<p><label>Guests <input name="guests" type="number" min="1" max="8" step="1" value="${esc(values.guests ?? 1)}" required></label></p>
<button type="submit">Book</button>
</form>`,
  );

export const renderConfirmation = (booking, tasting) =>
  page(
    'Booking confirmed',
    `<h1>Booking confirmed</h1>
<dl>
<dt>Tasting</dt><dd>${esc(tasting.title)}, ${esc(tasting.dateTime)}</dd>
<dt>Guests</dt><dd>${esc(booking.guests)}</dd>
<dt>Total price</dt><dd>EUR ${esc(tasting.price * booking.guests)}</dd>
<dt>Booking reference</dt><dd>${esc(booking.reference)}</dd>
</dl>
<p><a href="/">Back to tastings</a></p>`,
  );

export const renderStaffLogin = (error = null) =>
  page(
    'Staff sign in',
    `<h1>Staff sign in</h1>
${errorBox(error)}
<form method="post" action="/staff/login">
<p><label>Password <input name="password" type="password" required></label></p>
<button type="submit">Sign in</button>
</form>`,
  );

const renderBookingRows = (bookings) =>
  bookings
    .map(
      (booking) => `<tr>
<td>${esc(booking.name)}</td>
<td>${esc(booking.email)}</td>
<td>${esc(booking.guests)}</td>
<td>${esc(booking.reference)}</td>
<td>
<form method="post" action="/staff/bookings/${esc(booking.reference)}/cancel">
<button type="submit">Cancel</button>
</form>
</td>
</tr>`,
    )
    .join('\n');

const renderTastingBookings = (tasting, bookings) => {
  const own = bookings.filter((booking) => booking.tastingId === tasting.id);
  if (own.length === 0) return '<p>No bookings.</p>';
  return `<table>
<thead><tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th></th></tr></thead>
<tbody>
${renderBookingRows(own)}
</tbody>
</table>`;
};

export const renderStaffBookings = (tastings, bookings) =>
  page(
    'Staff',
    `<h1>Bookings</h1>
${tastings
  .map((tasting) => `<h2>${esc(tasting.title)}, ${esc(tasting.dateTime)}</h2>\n${renderTastingBookings(tasting, bookings)}`)
  .join('\n')}`,
  );
