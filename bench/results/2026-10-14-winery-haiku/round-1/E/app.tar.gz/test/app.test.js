import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../src/app.js';
import { createStore } from '../src/store.js';

const STAFF_PASSWORD = 'test-password';

async function startApp({ staffPassword = STAFF_PASSWORD } = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'kieselbrunnen-'));
  const file = join(dir, 'bookings.json');
  const server = createServer(createApp({ store: createStore(file), staffPassword }));
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  return {
    base: `http://127.0.0.1:${server.address().port}`,
    file,
    close: async () => {
      server.close();
      rmSync(dir, { recursive: true, force: true });
    },
  };
}

const post = (app, path, fields, headers = {}) =>
  fetch(app.base + path, {
    method: 'POST',
    redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...headers },
    body: new URLSearchParams(fields),
  });

const book = (app, tastingId, fields) =>
  post(app, `/book/${tastingId}`, { name: 'Ada Kern', email: 'ada@example.com', guests: '2', ...fields });

const signIn = async (app, password = STAFF_PASSWORD) => {
  const res = await post(app, '/staff/login', { password });
  return res.headers.get('set-cookie')?.split(';')[0];
};

const bookingReference = (res) => res.headers.get('location').split('/').pop();

test('lists tastings with seats left and a booking link', async (t) => {
  const app = await startApp();
  t.after(app.close);

  const html = await (await fetch(app.base + '/')).text();

  assert.match(html, /Book Riesling Evening/);
  assert.match(html, /12 seats left/);
  assert.match(html, /EUR 32/);
});

test('books seats and shows the confirmation', async (t) => {
  const app = await startApp();
  t.after(app.close);

  const res = await book(app, 'riesling-evening', { guests: '3' });
  assert.equal(res.status, 303);

  const confirmation = await (await fetch(app.base + res.headers.get('location'))).text();
  assert.match(confirmation, /Booking confirmed/);
  assert.match(confirmation, /Riesling Evening/);
  assert.match(confirmation, /EUR 75/);
  assert.match(confirmation, new RegExp(bookingReference(res)));

  const html = await (await fetch(app.base + '/')).text();
  assert.match(html, /9 seats left/);
});

test('rejects bookings above the seats left', async (t) => {
  const app = await startApp();
  t.after(app.close);
  assert.equal((await book(app, 'riesling-evening', { guests: '8' })).status, 303);

  const rejected = await book(app, 'riesling-evening', { guests: '5' });
  assert.equal(rejected.status, 400);
  assert.match(await rejected.text(), /Only 4 seats left for this tasting\./);

  const accepted = await book(app, 'riesling-evening', { guests: '4' });
  assert.equal(accepted.status, 303);
});

test('rejects invalid booking input next to the form', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const cases = [
    [{ name: '   ' }, 'Enter your name'],
    [{ email: 'ada@' }, 'Enter a valid email address.'],
    [{ guests: '0' }, 'Guests must be a whole number from 1 to 8.'],
    [{ guests: '9' }, 'Guests must be a whole number from 1 to 8.'],
    [{ guests: '2.5' }, 'Guests must be a whole number from 1 to 8.'],
    [{ guests: '' }, 'Guests must be a whole number from 1 to 8.'],
  ];

  for (const [fields, message] of cases) {
    const res = await book(app, 'winter-tasting', fields);
    assert.equal(res.status, 400, JSON.stringify(fields));
    assert.match(await res.text(), new RegExp(message), JSON.stringify(fields));
  }
});

test('unknown tasting returns 404', async (t) => {
  const app = await startApp();
  t.after(app.close);

  assert.equal((await fetch(app.base + '/book/no-such-tasting')).status, 404);
});

test('staff sign-in requires the configured password', async (t) => {
  const app = await startApp();
  t.after(app.close);

  assert.equal(await signIn(app, 'wrong'), undefined);
  const staffPage = await (await fetch(app.base + '/staff')).text();
  assert.match(staffPage, /name="password"/);
  assert.doesNotMatch(staffPage, /<h2>/);
});

test('staff sign-in is refused when STAFF_PASSWORD is not set', async (t) => {
  const app = await startApp({ staffPassword: '' });
  t.after(app.close);

  const res = await post(app, '/staff/login', { password: '' });
  assert.equal(res.status, 503);
});

test('staff see bookings by tasting with escaped names', async (t) => {
  const app = await startApp();
  t.after(app.close);
  await book(app, 'red-wine-cellar-tour', { name: '<script>alert(1)</script>', guests: '1' });
  const cookie = await signIn(app);

  const html = await (await fetch(app.base + '/staff', { headers: { Cookie: cookie } })).text();

  assert.match(html, /<h2>Red Wine Cellar Tour/);
  assert.match(html, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);
  assert.doesNotMatch(html, /<script>alert/);
});

test('cancelling a booking frees its seats', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const booked = await book(app, 'riesling-evening', { guests: '5' });
  const cookie = await signIn(app);

  const res = await post(app, `/staff/bookings/${bookingReference(booked)}/cancel`, {}, { Cookie: cookie });
  assert.equal(res.status, 303);

  const html = await (await fetch(app.base + '/')).text();
  assert.match(html, /12 seats left/);
});

test('cancelling requires a staff session', async (t) => {
  const app = await startApp();
  t.after(app.close);
  const booked = await book(app, 'riesling-evening', { guests: '5' });

  await post(app, `/staff/bookings/${bookingReference(booked)}/cancel`, {});

  const html = await (await fetch(app.base + '/')).text();
  assert.match(html, /7 seats left/);
});

test('bookings survive a restart', async (t) => {
  const app = await startApp();
  t.after(app.close);
  await book(app, 'winter-tasting', { guests: '4' });

  const restarted = createStore(app.file);

  assert.equal(restarted.tasting('winter-tasting').seatsLeft, 6);
});
