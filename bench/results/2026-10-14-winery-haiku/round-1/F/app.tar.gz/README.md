# Weingut Kieselbrunnen: tasting bookings

A small web app where guests book wine tastings online and staff see and cancel bookings.

## Running it

Requires Node.js 22 or newer. There are no external dependencies.

```sh
npm install
STAFF_PASSWORD='choose-a-password' npm start
```

Then open http://localhost:3000.

| Variable         | Default | Purpose                                                        |
|------------------|---------|----------------------------------------------------------------|
| `PORT`           | `3000`  | Port the app listens on.                                       |
| `STAFF_PASSWORD` | none    | Password for the staff area at `/staff`. If unset, staff sign-in is disabled. |

Run the tests with `npm test`.

## Pages

| Path                                   | Who        | What                                                         |
|----------------------------------------|------------|--------------------------------------------------------------|
| `/`                                    | Guests     | Lists the tastings with date, time, price and seats left.    |
| `/book/<tasting>`                      | Guests     | Booking form: Name, Email, Guests (1 to 8), Book.            |
| `/booking/<reference>`                 | Guests     | Confirmation: tasting, guests, total price, reference.       |
| `/staff`                               | Staff      | Sign-in form, then all bookings grouped by tasting.          |
| `/staff/bookings/<reference>/cancel`   | Staff      | Cancels a booking and frees its seats.                       |

Tasting ids are `riesling-evening`, `red-wine-cellar-tour` and `winter-tasting`.

## Design notes

- **Storage is in memory.** Bookings and staff sessions are lost when the app restarts. The app starts with no bookings. To keep bookings across restarts, replace the store in `src/store.js` with a file or database.
- **Seats are checked on the server.** A booking is refused if it asks for more guests than are left, and the check runs in the same synchronous step as the insert, so two bookings cannot oversell a tasting.
- **Staff sessions** use a random token in an `HttpOnly`, `SameSite=Strict` cookie. Sessions last 8 hours.
- **Tastings** are defined in `src/tastings.js`. Changing a title, date, price or seat count there takes effect on restart.

## Layout

```
src/index.js        entry point: reads PORT and STAFF_PASSWORD, starts the server
src/server.js       routes, staff sessions, form parsing, security headers
src/store.js        tastings and bookings held in memory
src/tastings.js     the tastings on offer
src/validation.js   booking form validation
src/views.js        HTML pages (all user input is escaped here)
public/style.css    stylesheet
test/app.test.js    tests run against a live server on a random port
```

## Before going live

- Serve the app over HTTPS and add the `Secure` attribute to the staff session cookie in `src/server.js`.
- Sign-in attempts are not rate-limited. Add a limit in front of `/staff/login` (for example at the reverse proxy) if the site is public.
