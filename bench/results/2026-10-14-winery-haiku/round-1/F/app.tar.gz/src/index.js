import { createAppServer } from './server.js';

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD ?? '';

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

const server = createAppServer({ staffPassword });

server.listen(port, () => {
  console.log(`Weingut Kieselbrunnen listening on port ${port}`);
});
