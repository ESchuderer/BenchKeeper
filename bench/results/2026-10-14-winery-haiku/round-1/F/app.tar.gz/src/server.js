import { createServer } from 'node:http';
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createStore } from './store.js';
import { validateBooking } from './validation.js';
import {
  bookingFormPage,
  confirmationPage,
  errorPage,
  indexPage,
  notFoundPage,
  staffBookingsPage,
  staffLoginPage,
} from './views.js';

const STYLE_CSS = readFileSync(new URL('../public/style.css', import.meta.url), 'utf8');
const SESSION_COOKIE = 'staff_session';
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const MAX_FORM_BYTES = 16 * 1024;

const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; style-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Cache-Control': 'no-store',
};

// Builds the HTTP server. Options:
//   staffPassword - the staff password; an empty value disables staff sign-in
//   store         - booking store (in memory by default)
//   now           - clock, injectable for tests
export function createAppServer({
  staffPassword = '',
  store = createStore(),
  now = () => Date.now(),
} = {}) {
  // Compare SHA-256 digests so the comparison takes the same time whatever
  // the length of the guess.
  const passwordDigest = staffPassword ? sha256(staffPassword) : null;
  const sessions = new Map(); // token -> expiry time in ms

  function checkPassword(candidate) {
    if (passwordDigest === null) return false;
    return timingSafeEqual(sha256(candidate), passwordDigest);
  }

  function startSession() {
    const token = randomBytes(32).toString('base64url');
    sessions.set(token, now() + SESSION_TTL_MS);
    return token;
  }

  function endSession(req) {
    const token = readCookie(req, SESSION_COOKIE);
    if (token) sessions.delete(token);
  }

  function isSignedIn(req) {
    const token = readCookie(req, SESSION_COOKIE);
    if (!token || !sessions.has(token)) return false;
    if (sessions.get(token) <= now()) {
      sessions.delete(token);
      return false;
    }
    return true;
  }

  function indexGroups() {
    return store.listTastings().map((tasting) => ({
      tasting,
      seatsLeft: store.seatsLeft(tasting.id),
    }));
  }

  function staffGroups() {
    return store.listTastings().map((tasting) => ({
      tasting,
      seatsLeft: store.seatsLeft(tasting.id),
      bookings: store.bookingsForTasting(tasting.id),
    }));
  }

  async function handle(req, res) {
    const url = new URL(req.url, 'http://localhost');
    const { pathname } = url;
    const { method } = req;

    if (pathname === '/style.css') {
      return method === 'GET'
        ? send(res, 200, STYLE_CSS, 'text/css; charset=utf-8')
        : sendMethodNotAllowed(res, 'GET');
    }

    if (pathname === '/') {
      return method === 'GET'
        ? sendHtml(res, 200, indexPage(indexGroups()))
        : sendMethodNotAllowed(res, 'GET');
    }

    const bookMatch = pathname.match(/^\/book\/([a-z0-9-]+)$/);
    if (bookMatch) {
      const tasting = store.getTasting(bookMatch[1]);
      if (!tasting) return sendNotFound(res);
      if (method === 'GET') {
        return sendHtml(res, 200, bookingFormPage(tasting, store.seatsLeft(tasting.id)));
      }
      if (method === 'POST') return handleBooking(req, res, tasting);
      return sendMethodNotAllowed(res, 'GET, POST');
    }

    const bookingMatch = pathname.match(/^\/booking\/(KB-[A-Z2-9]{6})$/);
    if (bookingMatch) {
      if (method !== 'GET') return sendMethodNotAllowed(res, 'GET');
      const booking = store.getBooking(bookingMatch[1]);
      if (!booking) return sendNotFound(res);
      const tasting = store.getTasting(booking.tastingId);
      return sendHtml(res, 200, confirmationPage(booking, tasting));
    }

    if (pathname === '/staff') {
      if (method !== 'GET') return sendMethodNotAllowed(res, 'GET');
      if (!isSignedIn(req)) return sendHtml(res, 200, staffLoginPage());
      return sendHtml(res, 200, staffBookingsPage(staffGroups()));
    }

    if (pathname === '/staff/login') {
      if (method !== 'POST') return sendMethodNotAllowed(res, 'POST');
      const form = await readForm(req);
      if (passwordDigest === null) {
        return sendHtml(res, 401, staffLoginPage({ error: 'Staff sign-in is not available.' }));
      }
      if (!checkPassword(form.get('password') ?? '')) {
        return sendHtml(res, 401, staffLoginPage({ error: 'Incorrect password.' }));
      }
      const token = startSession();
      const maxAge = Math.floor(SESSION_TTL_MS / 1000);
      return redirect(res, '/staff', {
        'Set-Cookie': `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}`,
      });
    }

    if (pathname === '/staff/logout') {
      if (method !== 'POST') return sendMethodNotAllowed(res, 'POST');
      endSession(req);
      return redirect(res, '/staff', {
        'Set-Cookie': `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`,
      });
    }

    const cancelMatch = pathname.match(/^\/staff\/bookings\/(KB-[A-Z2-9]{6})\/cancel$/);
    if (cancelMatch) {
      if (method !== 'POST') return sendMethodNotAllowed(res, 'POST');
      if (!isSignedIn(req)) return redirect(res, '/staff');
      store.cancelBooking(cancelMatch[1]);
      return redirect(res, '/staff');
    }

    return sendNotFound(res);
  }

  async function handleBooking(req, res, tasting) {
    const form = await readForm(req);
    const seatsLeft = store.seatsLeft(tasting.id);
    const result = validateBooking(
      {
        name: form.get('name') ?? '',
        email: form.get('email') ?? '',
        guests: form.get('guests') ?? '',
      },
      seatsLeft,
    );
    if (result.errors.length > 0) {
      return sendHtml(res, 400, bookingFormPage(tasting, seatsLeft, {
        values: result.values,
        errors: result.errors,
      }));
    }
    const booking = store.book({
      tastingId: tasting.id,
      name: result.values.name,
      email: result.values.email,
      guests: result.guests,
    });
    return redirect(res, `/booking/${booking.reference}`);
  }

  return createServer(async (req, res) => {
    try {
      await handle(req, res);
    } catch (error) {
      if (error.status) {
        return sendHtml(res, error.status, errorPage());
      }
      console.error(error);
      if (!res.headersSent) sendHtml(res, 500, errorPage());
    }
  });
}

function sha256(text) {
  return createHash('sha256').update(text, 'utf8').digest();
}

function readCookie(req, name) {
  const header = req.headers.cookie ?? '';
  for (const part of header.split(';')) {
    const [key, ...rest] = part.trim().split('=');
    if (key === name) return rest.join('=');
  }
  return null;
}

// Reads an urlencoded form body, refusing bodies over MAX_FORM_BYTES.
async function readForm(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_FORM_BYTES) {
      const error = new Error('Request body too large');
      error.status = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  return new URLSearchParams(Buffer.concat(chunks).toString('utf8'));
}

function send(res, status, body, contentType, extraHeaders = {}) {
  res.writeHead(status, {
    'Content-Type': contentType,
    'Content-Length': Buffer.byteLength(body),
    ...extraHeaders,
  });
  res.end(body);
}

function sendHtml(res, status, html, extraHeaders = {}) {
  send(res, status, html, 'text/html; charset=utf-8', { ...SECURITY_HEADERS, ...extraHeaders });
}

function redirect(res, location, extraHeaders = {}) {
  res.writeHead(303, { Location: location, ...SECURITY_HEADERS, ...extraHeaders });
  res.end();
}

function sendNotFound(res) {
  sendHtml(res, 404, notFoundPage());
}

function sendMethodNotAllowed(res, allow) {
  res.writeHead(405, { Allow: allow, 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Method not allowed');
}
