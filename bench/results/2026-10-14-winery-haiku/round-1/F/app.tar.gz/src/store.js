import { randomInt } from 'node:crypto';
import { TASTINGS } from './tastings.js';

// No 0/O or 1/I so references can be read out loud without confusion.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const REFERENCE_LENGTH = 6;

// Holds bookings in memory. Node runs JavaScript on a single thread and
// every method here is synchronous, so a seat check and the insert that
// follows it cannot interleave with another request.
export function createStore(tastings = TASTINGS) {
  const tastingsById = new Map(tastings.map((tasting) => [tasting.id, tasting]));
  const bookings = new Map(); // reference -> booking

  function getTasting(tastingId) {
    return tastingsById.get(tastingId) ?? null;
  }

  function listTastings() {
    return [...tastingsById.values()];
  }

  function seatsLeft(tastingId) {
    const tasting = tastingsById.get(tastingId);
    if (!tasting) throw new Error(`Unknown tasting: ${tastingId}`);
    let taken = 0;
    for (const booking of bookings.values()) {
      if (booking.tastingId === tastingId) taken += booking.guests;
    }
    return tasting.seats - taken;
  }

  function newReference() {
    let reference;
    do {
      const chars = Array.from({ length: REFERENCE_LENGTH }, () =>
        REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)],
      );
      reference = `KB-${chars.join('')}`;
    } while (bookings.has(reference));
    return reference;
  }

  // Callers validate the input first. The seat check here is a guard that
  // keeps the invariant even if a caller forgets to validate.
  function book({ tastingId, name, email, guests }) {
    const left = seatsLeft(tastingId);
    if (!Number.isInteger(guests) || guests < 1 || guests > left) {
      throw new RangeError(`Cannot book ${guests} guests, ${left} seats left`);
    }
    const booking = {
      reference: newReference(),
      tastingId,
      name,
      email,
      guests,
      createdAt: new Date().toISOString(),
    };
    bookings.set(booking.reference, booking);
    return booking;
  }

  function getBooking(reference) {
    return bookings.get(reference) ?? null;
  }

  // Removing the booking frees its seats.
  function cancelBooking(reference) {
    return bookings.delete(reference);
  }

  // Bookings for one tasting, in the order they were made.
  function bookingsForTasting(tastingId) {
    return [...bookings.values()].filter((booking) => booking.tastingId === tastingId);
  }

  return {
    listTastings,
    getTasting,
    seatsLeft,
    book,
    getBooking,
    cancelBooking,
    bookingsForTasting,
  };
}
