// The tastings on offer. Seats are the total capacity; seats left is
// calculated from the bookings held by the store.
export const TASTINGS = Object.freeze([
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    date: '2026-11-06',
    time: '18:00',
    pricePerGuest: 25,
    seats: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    date: '2026-11-14',
    time: '15:00',
    pricePerGuest: 32,
    seats: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    date: '2026-12-05',
    time: '17:00',
    pricePerGuest: 28,
    seats: 10,
  },
]);
