export const MIN_GUESTS = 1;
export const MAX_GUESTS = 8;

const NAME_MAX_LENGTH = 100;
const EMAIL_MAX_LENGTH = 254;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Checks a booking form against the seats still free for the tasting.
// Returns the trimmed values (for re-filling the form), the error messages,
// and the guest count as a number when the input is valid.
export function validateBooking(form, seatsLeft) {
  const values = {
    name: form.name.trim(),
    email: form.email.trim(),
    guests: form.guests.trim(),
  };
  const errors = [];

  if (values.name === '') {
    errors.push('Please enter your name.');
  } else if (values.name.length > NAME_MAX_LENGTH) {
    errors.push(`Name must be at most ${NAME_MAX_LENGTH} characters.`);
  }

  if (!EMAIL_PATTERN.test(values.email) || values.email.length > EMAIL_MAX_LENGTH) {
    errors.push('Please enter a valid email address.');
  }

  const guests = /^\d+$/.test(values.guests) ? Number(values.guests) : NaN;
  const guestsValid = guests >= MIN_GUESTS && guests <= MAX_GUESTS;
  if (!guestsValid) {
    errors.push(`Guests must be a whole number from ${MIN_GUESTS} to ${MAX_GUESTS}.`);
  } else if (seatsLeft <= 0) {
    errors.push('This tasting is fully booked.');
  } else if (guests > seatsLeft) {
    const seatWord = seatsLeft === 1 ? 'seat is' : 'seats are';
    errors.push(`Only ${seatsLeft} ${seatWord} left, so you cannot book ${guests} guests.`);
  }

  return {
    values,
    errors,
    guests: errors.length === 0 ? guests : null,
  };
}
