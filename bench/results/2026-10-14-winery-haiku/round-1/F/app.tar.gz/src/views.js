import { MAX_GUESTS, MIN_GUESTS } from './validation.js';

// Escapes text for HTML element content and quoted attribute values.
export function esc(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[char]);
}

const formatWhen = (tasting) => `${tasting.date} ${tasting.time}`;
const formatPrice = (amount) => `EUR ${amount}`;
const seatsText = (seats) => `${seats} seats left`;

function layout({ title, body }) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} - Weingut Kieselbrunnen</title>
<link rel="stylesheet" href="/style.css">
</head>
<body>
<header class="site-header">
<a href="/" class="brand">Weingut Kieselbrunnen</a>
</header>
<main>
${body}
</main>
</body>
</html>
`;
}

function errorList(errors) {
  return `<div class="error" role="alert">
<ul>
${errors.map((error) => `<li>${esc(error)}</li>`).join('\n')}
</ul>
</div>`;
}

export function indexPage(tastings) {
  const items = tastings.map(({ tasting, seatsLeft }) => `<li class="tasting">
<h2>${esc(tasting.title)}</h2>
<dl>
<dt>Date and time</dt>
<dd>${esc(formatWhen(tasting))}</dd>
<dt>Price per guest</dt>
<dd>${esc(formatPrice(tasting.pricePerGuest))}</dd>
<dt>Availability</dt>
<dd>${esc(seatsText(seatsLeft))}</dd>
</dl>
<a class="button" href="/book/${esc(tasting.id)}">Book ${esc(tasting.title)}</a>
</li>`);

  return layout({
    title: 'Wine tastings',
    body: `<h1>Wine tastings</h1>
<ul class="tastings">
${items.join('\n')}
</ul>`,
  });
}

export function bookingFormPage(tasting, seatsLeft, { values = { name: '', email: '', guests: '' }, errors = [] } = {}) {
  const errorBlock = errors.length > 0 ? errorList(errors) : '';
  return layout({
    title: `Book ${tasting.title}`,
    body: `<p><a href="/">&larr; All tastings</a></p>
<h1>Book ${esc(tasting.title)}</h1>
<p class="summary">${esc(formatWhen(tasting))} &middot; ${esc(formatPrice(tasting.pricePerGuest))} per guest &middot; ${esc(seatsText(seatsLeft))}</p>
${errorBlock}
<form method="post" action="/book/${esc(tasting.id)}" class="stacked">
<div class="field">
<label for="name">Name</label>
<input id="name" name="name" type="text" autocomplete="name" maxlength="100" required value="${esc(values.name)}">
</div>
<div class="field">
<label for="email">Email</label>
<input id="email" name="email" type="email" autocomplete="email" maxlength="254" required value="${esc(values.email)}">
</div>
<div class="field">
<label for="guests">Guests</label>
<input id="guests" name="guests" type="number" min="${MIN_GUESTS}" max="${MAX_GUESTS}" step="1" required value="${esc(values.guests)}">
</div>
<button type="submit">Book</button>
</form>`,
  });
}

export function confirmationPage(booking, tasting) {
  return layout({
    title: 'Booking confirmed',
    body: `<h1>Booking confirmed</h1>
<p>Thank you for booking. Please keep your booking reference for your visit.</p>
<dl class="confirmation">
<dt>Tasting</dt>
<dd>${esc(tasting.title)}</dd>
<dt>Date and time</dt>
<dd>${esc(formatWhen(tasting))}</dd>
<dt>Guests</dt>
<dd>${esc(booking.guests)}</dd>
<dt>Total price</dt>
<dd>${esc(formatPrice(tasting.pricePerGuest * booking.guests))}</dd>
<dt>Booking reference</dt>
<dd><strong>${esc(booking.reference)}</strong></dd>
</dl>
<p><a href="/">Back to all tastings</a></p>`,
  });
}

export function notFoundPage() {
  return layout({
    title: 'Not found',
    body: `<h1>Page not found</h1>
<p><a href="/">Back to all tastings</a></p>`,
  });
}

export function errorPage() {
  return layout({
    title: 'Something went wrong',
    body: `<h1>Something went wrong</h1>
<p>Please try again. <a href="/">Back to all tastings</a></p>`,
  });
}

export function staffLoginPage({ error = null } = {}) {
  const errorBlock = error ? errorList([error]) : '';
  return layout({
    title: 'Staff sign in',
    body: `<h1>Staff sign in</h1>
${errorBlock}
<form method="post" action="/staff/login" class="stacked">
<div class="field">
<label for="password">Password</label>
<input id="password" name="password" type="password" autocomplete="current-password" required>
</div>
<button type="submit">Sign in</button>
</form>`,
  });
}

// groups: [{ tasting, seatsLeft, bookings: [booking, ...] }]
export function staffBookingsPage(groups) {
  const sections = groups.map(({ tasting, seatsLeft, bookings }) => {
    const guestsBooked = bookings.reduce((sum, booking) => sum + booking.guests, 0);
    const content = bookings.length === 0
      ? '<p class="empty">No bookings yet.</p>'
      : `<table>
<thead>
<tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th><span class="visually-hidden">Actions</span></th></tr>
</thead>
<tbody>
${bookings.map((booking) => `<tr>
<td>${esc(booking.name)}</td>
<td>${esc(booking.email)}</td>
<td>${esc(booking.guests)}</td>
<td>${esc(booking.reference)}</td>
<td>
<form method="post" action="/staff/bookings/${esc(booking.reference)}/cancel">
<button type="submit" class="danger">Cancel</button>
</form>
</td>
</tr>`).join('\n')}
</tbody>
</table>`;
    return `<section class="group" data-tasting="${esc(tasting.id)}">
<h2>${esc(tasting.title)}</h2>
<p class="summary">${esc(formatWhen(tasting))} &middot; ${guestsBooked} guests booked &middot; ${esc(seatsText(seatsLeft))}</p>
${content}
</section>`;
  });

  return layout({
    title: 'Bookings',
    body: `<div class="staff-bar">
<h1>Bookings</h1>
<form method="post" action="/staff/logout">
<button type="submit" class="secondary">Sign out</button>
</form>
</div>
${sections.join('\n')}`,
  });
}
