import { after, afterEach, beforeEach, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createAppServer } from '../src/server.js';

const PASSWORD = 'correct horse battery';

let server;
let base;

async function start(options = {}) {
  server = createAppServer({ staffPassword: PASSWORD, ...options });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  base = `http://127.0.0.1:${port}`;
}

async function stop() {
  if (!server) return;
  server.closeAllConnections();
  await new Promise((resolve) => server.close(resolve));
  server = null;
}

function request(path, { method = 'GET', form, cookie } = {}) {
  const headers = {};
  if (form) headers['Content-Type'] = 'application/x-www-form-urlencoded';
  if (cookie) headers.Cookie = cookie;
  return fetch(base + path, {
    method,
    headers,
    body: form ? new URLSearchParams(form) : undefined,
    redirect: 'manual',
  });
}

async function book(tastingId, { name = 'Anna Keller', email = 'anna@example.com', guests = '2' } = {}) {
  return request(`/book/${tastingId}`, { method: 'POST', form: { name, email, guests } });
}

async function signIn(password = PASSWORD) {
  const res = await request('/staff/login', { method: 'POST', form: { password } });
  const cookie = res.headers.get('set-cookie');
  return cookie ? cookie.split(';')[0] : null;
}

// Returns the HTML of one staff section, e.g. the one for a tasting id.
function staffSection(html, tastingId) {
  const start = html.indexOf(`data-tasting="${tastingId}"`);
  assert.notEqual(start, -1, `no section for ${tastingId}`);
  const end = html.indexOf('</section>', start);
  return html.slice(start, end);
}

function referenceFrom(res) {
  return res.headers.get('location').replace('/booking/', '');
}

describe('guest pages', () => {
  beforeEach(start);
  afterEach(stop);

  it('lists the tastings with price, date, time and seats left', async () => {
    const html = await (await request('/')).text();

    assert.match(html, /Riesling Evening/);
    assert.match(html, /2026-11-06 18:00/);
    assert.match(html, /EUR 25/);
    assert.match(html, /12 seats left/);

    assert.match(html, /Red Wine Cellar Tour/);
    assert.match(html, /2026-11-14 15:00/);
    assert.match(html, /EUR 32/);
    assert.match(html, /8 seats left/);

    assert.match(html, /Winter Tasting/);
    assert.match(html, /2026-12-05 17:00/);
    assert.match(html, /EUR 28/);
    assert.match(html, /10 seats left/);
  });

  it('links each tasting to its booking form', async () => {
    const html = await (await request('/')).text();
    assert.match(html, /<a class="button" href="\/book\/riesling-evening">Book Riesling Evening<\/a>/);
    assert.match(html, /<a class="button" href="\/book\/red-wine-cellar-tour">Book Red Wine Cellar Tour<\/a>/);
    assert.match(html, /<a class="button" href="\/book\/winter-tasting">Book Winter Tasting<\/a>/);
  });

  it('shows a booking form with Name, Email, Guests and a Book button', async () => {
    const res = await request('/book/riesling-evening');
    const html = await res.text();

    assert.equal(res.status, 200);
    assert.match(html, /<h1>Book Riesling Evening<\/h1>/);
    assert.match(html, /<label for="name">Name<\/label>/);
    assert.match(html, /<label for="email">Email<\/label>/);
    assert.match(html, /<label for="guests">Guests<\/label>/);
    assert.match(html, /name="guests" type="number" min="1" max="8"/);
    assert.match(html, /<button type="submit">Book<\/button>/);
  });

  it('returns 404 for an unknown tasting', async () => {
    const res = await request('/book/no-such-tasting');
    assert.equal(res.status, 404);
  });

  it('books a tasting and shows the confirmation', async () => {
    const res = await book('riesling-evening', { guests: '2' });
    assert.equal(res.status, 303);
    const reference = referenceFrom(res);
    assert.match(reference, /^KB-[A-Z2-9]{6}$/);

    const confirmation = await request(`/booking/${reference}`);
    const html = await confirmation.text();
    assert.equal(confirmation.status, 200);
    assert.match(html, /<h1>Booking confirmed<\/h1>/);
    assert.match(html, /Riesling Evening/);
    assert.match(html, /<dt>Guests<\/dt>\s*<dd>2<\/dd>/);
    assert.match(html, /<dt>Total price<\/dt>\s*<dd>EUR 50<\/dd>/);
    assert.match(html, new RegExp(reference));

    const index = await (await request('/')).text();
    assert.match(index, /10 seats left/);
  });

  it('rejects invalid input with an error next to the form and books nothing', async () => {
    const cases = [
      { name: '', email: 'anna@example.com', guests: '2', message: 'Please enter your name.' },
      { name: 'Anna', email: 'not-an-email', guests: '2', message: 'Please enter a valid email address.' },
      { name: 'Anna', email: 'anna@example.com', guests: '0', message: 'Guests must be a whole number from 1 to 8.' },
      { name: 'Anna', email: 'anna@example.com', guests: '9', message: 'Guests must be a whole number from 1 to 8.' },
      { name: 'Anna', email: 'anna@example.com', guests: 'two', message: 'Guests must be a whole number from 1 to 8.' },
      { name: 'Anna', email: 'anna@example.com', guests: '2.5', message: 'Guests must be a whole number from 1 to 8.' },
      { name: 'Anna', email: 'anna@example.com', guests: '', message: 'Guests must be a whole number from 1 to 8.' },
    ];

    for (const { message, ...fields } of cases) {
      const res = await book('riesling-evening', fields);
      const html = await res.text();
      assert.equal(res.status, 400, `status for ${JSON.stringify(fields)}`);
      assert.match(html, /role="alert"/);
      assert.ok(html.includes(message), `message "${message}" for ${JSON.stringify(fields)}`);
    }

    const index = await (await request('/')).text();
    assert.match(index, /12 seats left/);
  });

  it('keeps the entered values when the form is rejected', async () => {
    const res = await book('winter-tasting', { name: 'Ben Fischer', email: 'ben@example.com', guests: '9' });
    const html = await res.text();
    assert.match(html, /value="Ben Fischer"/);
    assert.match(html, /value="ben@example.com"/);
    assert.match(html, /value="9"/);
  });

  it('never books more seats than are left', async () => {
    const first = await book('riesling-evening', { guests: '8' });
    assert.equal(first.status, 303);

    const tooMany = await book('riesling-evening', { guests: '5' });
    assert.equal(tooMany.status, 400);
    assert.match(await tooMany.text(), /Only 4 seats are left/);

    const exact = await book('riesling-evening', { guests: '4' });
    assert.equal(exact.status, 303);

    const full = await book('riesling-evening', { guests: '1' });
    assert.equal(full.status, 400);
    assert.match(await full.text(), /This tasting is fully booked\./);

    const index = await (await request('/')).text();
    assert.match(index, /0 seats left/);
  });

  it('escapes guest input in the HTML', async () => {
    const res = await book('winter-tasting', { name: '<script>alert(1)</script>', guests: '2' });
    assert.equal(res.status, 303);
    const confirmation = await request(res.headers.get('location'));
    const html = await confirmation.text();
    assert.doesNotMatch(html, /<script>alert/);

    const errorRes = await book('winter-tasting', { name: '"><img src=x onerror=1>', guests: '99' });
    const errorHtml = await errorRes.text();
    assert.doesNotMatch(errorHtml, /<img src=x/);
    assert.match(errorHtml, /&quot;&gt;&lt;img/);
  });
});

describe('fully booked tasting', () => {
  beforeEach(start);
  afterEach(stop);

  it('shows 0 seats left and refuses further bookings', async () => {
    const res = await book('red-wine-cellar-tour', { guests: '8' });
    assert.equal(res.status, 303);

    const index = await (await request('/')).text();
    assert.match(index, /0 seats left/);

    const next = await book('red-wine-cellar-tour', { guests: '1' });
    assert.equal(next.status, 400);
    assert.match(await next.text(), /This tasting is fully booked\./);
  });
});

describe('staff area', () => {
  beforeEach(start);
  afterEach(stop);

  it('asks for the password before showing bookings', async () => {
    await book('riesling-evening', { name: 'Clara Vogt', guests: '3' });

    const res = await request('/staff');
    const html = await res.text();
    assert.equal(res.status, 200);
    assert.match(html, /<label for="password">Password<\/label>/);
    assert.match(html, /type="password"/);
    assert.match(html, /<button type="submit">Sign in<\/button>/);
    assert.doesNotMatch(html, /Clara Vogt/);
  });

  it('rejects a wrong password', async () => {
    const res = await request('/staff/login', { method: 'POST', form: { password: 'wrong' } });
    const html = await res.text();
    assert.equal(res.status, 401);
    assert.match(html, /Incorrect password\./);
    assert.equal(res.headers.get('set-cookie'), null);
  });

  it('refuses every sign-in when no staff password is configured', async () => {
    await stop();
    await start({ staffPassword: '' });

    const res = await request('/staff/login', { method: 'POST', form: { password: '' } });
    assert.equal(res.status, 401);
    assert.equal(res.headers.get('set-cookie'), null);
  });

  it('shows bookings grouped by tasting after sign-in', async () => {
    await book('riesling-evening', { name: 'Clara Vogt', email: 'clara@example.com', guests: '3' });
    await book('winter-tasting', { name: 'Dan Roth', email: 'dan@example.com', guests: '4' });

    const cookie = await signIn();
    assert.ok(cookie, 'sign-in sets a session cookie');

    const res = await request('/staff', { cookie });
    const html = await res.text();
    assert.equal(res.status, 200);
    assert.match(html, /<h1>Bookings<\/h1>/);

    const riesling = staffSection(html, 'riesling-evening');
    assert.match(riesling, /Clara Vogt/);
    assert.match(riesling, /clara@example\.com/);
    assert.match(riesling, /<td>3<\/td>/);
    assert.match(riesling, /KB-[A-Z2-9]{6}/);
    assert.match(riesling, />Cancel</);
    assert.doesNotMatch(riesling, /Dan Roth/);

    const winter = staffSection(html, 'winter-tasting');
    assert.match(winter, /Dan Roth/);
    assert.doesNotMatch(winter, /Clara Vogt/);

    const redWine = staffSection(html, 'red-wine-cellar-tour');
    assert.match(redWine, /No bookings yet\./);
  });

  it('cancels a booking and frees its seats', async () => {
    const booked = await book('riesling-evening', { guests: '5' });
    const reference = referenceFrom(booked);
    const cookie = await signIn();

    const cancel = await request(`/staff/bookings/${reference}/cancel`, { method: 'POST', cookie });
    assert.equal(cancel.status, 303);
    assert.equal(cancel.headers.get('location'), '/staff');

    const staffHtml = await (await request('/staff', { cookie })).text();
    assert.doesNotMatch(staffHtml, new RegExp(reference));

    const index = await (await request('/')).text();
    assert.match(index, /12 seats left/);

    const confirmation = await request(`/booking/${reference}`);
    assert.equal(confirmation.status, 404);
  });

  it('does not cancel a booking without a staff session', async () => {
    const booked = await book('riesling-evening', { guests: '2' });
    const reference = referenceFrom(booked);

    const res = await request(`/staff/bookings/${reference}/cancel`, { method: 'POST' });
    assert.equal(res.status, 303);
    assert.equal(res.headers.get('location'), '/staff');

    const index = await (await request('/')).text();
    assert.match(index, /10 seats left/);
  });

  it('ignores a forged session cookie', async () => {
    await book('riesling-evening', { name: 'Clara Vogt', guests: '2' });

    const html = await (await request('/staff', { cookie: 'staff_session=forged' })).text();
    assert.doesNotMatch(html, /Clara Vogt/);
    assert.match(html, /Sign in/);
  });

  it('ends the session on sign-out', async () => {
    await book('riesling-evening', { name: 'Clara Vogt', guests: '2' });
    const cookie = await signIn();

    const logout = await request('/staff/logout', { method: 'POST', cookie });
    assert.equal(logout.status, 303);
    assert.match(logout.headers.get('set-cookie'), /staff_session=;.*Max-Age=0/);

    const html = await (await request('/staff', { cookie })).text();
    assert.doesNotMatch(html, /Clara Vogt/);
  });

  it('sets a session cookie that scripts cannot read and that is not sent cross-site', async () => {
    const res = await request('/staff/login', { method: 'POST', form: { password: PASSWORD } });
    const cookie = res.headers.get('set-cookie');
    assert.match(cookie, /HttpOnly/);
    assert.match(cookie, /SameSite=Strict/);
    assert.match(cookie, /Path=\//);
  });
});

describe('staff sessions expire', () => {
  afterEach(stop);

  it('requires a new sign-in after the session lifetime', async () => {
    let clock = Date.parse('2026-10-14T10:00:00Z');
    await start({ now: () => clock });
    await book('riesling-evening', { name: 'Clara Vogt', guests: '2' });
    const cookie = await signIn();

    clock += 7 * 60 * 60 * 1000;
    assert.match(await (await request('/staff', { cookie })).text(), /Clara Vogt/);

    clock += 2 * 60 * 60 * 1000;
    assert.doesNotMatch(await (await request('/staff', { cookie })).text(), /Clara Vogt/);
  });
});

describe('request handling', () => {
  beforeEach(start);
  afterEach(stop);

  it('rejects oversized form bodies', async () => {
    const res = await request('/book/riesling-evening', {
      method: 'POST',
      form: { name: 'x'.repeat(20000), email: 'a@example.com', guests: '1' },
    });
    assert.equal(res.status, 413);
  });

  it('answers unknown paths with 404', async () => {
    assert.equal((await request('/nope')).status, 404);
  });

  it('rejects wrong methods', async () => {
    const res = await request('/', { method: 'POST' });
    assert.equal(res.status, 405);
    assert.equal(res.headers.get('allow'), 'GET');
  });

  it('sends security headers on HTML pages', async () => {
    const res = await request('/');
    assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(res.headers.get('x-frame-options'), 'DENY');
  });

  it('serves the stylesheet', async () => {
    const res = await request('/style.css');
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /text\/css/);
  });
});

after(stop);
