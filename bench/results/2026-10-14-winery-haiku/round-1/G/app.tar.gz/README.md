# Weingut Kieselbrunnen: tasting bookings

A small web app where guests book wine tastings and staff see and cancel bookings.
Plain Node.js 22 with no runtime dependencies.

## Running

```sh
npm install
STAFF_PASSWORD='choose-a-password' npm start
```

The app listens on `PORT` (default 3000). Open http://localhost:3000.

- `STAFF_PASSWORD`: password for the staff page at `/staff`. If it is not set, staff sign-in is refused.

## Tests

```sh
npm test
```

## Notes

- Bookings are kept in memory. They are lost when the server restarts, and the app starts with no bookings.
- Staff sessions are also in memory and last eight hours.
- The staff session cookie is `HttpOnly` and `SameSite=Strict`. Add `Secure` when serving over HTTPS.
- The tastings are defined in `src/store.js`.
