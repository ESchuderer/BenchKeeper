const crypto = require('node:crypto');
const views = require('./views');

const SESSION_COOKIE = 'staff_session';
const SESSION_LIFETIME_MS = 8 * 60 * 60 * 1000;
const MAX_BODY_BYTES = 8 * 1024;

class PayloadTooLarge extends Error {}

function readForm(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let tooLarge = false;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        tooLarge = true;
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (tooLarge) reject(new PayloadTooLarge());
      else resolve(new URLSearchParams(Buffer.concat(chunks).toString('utf8')));
    });
    req.on('error', reject);
  });
}

function readCookie(req, name) {
  for (const part of (req.headers.cookie || '').split(';')) {
    const [key, ...value] = part.trim().split('=');
    if (key === name) return value.join('=');
  }
  return undefined;
}

function sendHtml(res, status, html, headers = {}) {
  res.writeHead(status, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'",
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(html);
}

function redirect(res, location, headers = {}) {
  res.writeHead(303, { Location: location, ...headers });
  res.end();
}

function createApp({ store, staffPassword }) {
  // Session token -> expiry time. Sessions are lost when the server restarts.
  const sessions = new Map();

  function passwordMatches(candidate) {
    if (!staffPassword) return false;
    // Hash both sides so the comparison takes the same time for any length.
    const given = crypto.createHash('sha256').update(String(candidate ?? '')).digest();
    const expected = crypto.createHash('sha256').update(staffPassword).digest();
    return crypto.timingSafeEqual(given, expected);
  }

  function startSession() {
    const token = crypto.randomBytes(32).toString('hex');
    sessions.set(token, Date.now() + SESSION_LIFETIME_MS);
    return token;
  }

  function isSignedIn(req) {
    const token = readCookie(req, SESSION_COOKIE);
    const expiresAt = token && sessions.get(token);
    if (!expiresAt) return false;
    if (expiresAt < Date.now()) {
      sessions.delete(token);
      return false;
    }
    return true;
  }

  async function bookingForm(req, res, tastingId) {
    const tasting = store.getTasting(tastingId);
    if (!tasting) return sendHtml(res, 404, views.notFoundPage());

    if (req.method === 'GET') {
      return sendHtml(res, 200, views.bookingFormPage(tasting));
    }

    const form = await readForm(req);
    const values = {
      name: form.get('name') ?? '',
      email: form.get('email') ?? '',
      guests: form.get('guests') ?? '',
    };
    const result = store.createBooking({ tastingId, ...values });
    if (result.error) {
      return sendHtml(res, 400, views.bookingFormPage(tasting, values, result.error));
    }
    return redirect(res, `/booking/${result.booking.reference}`);
  }

  async function route(req, res) {
    const { pathname } = new URL(req.url, 'http://localhost');
    const bookMatch = pathname.match(/^\/book\/([a-z0-9-]+)$/);
    const confirmationMatch = pathname.match(/^\/booking\/([A-Z0-9]{6})$/);
    const cancelMatch = pathname.match(/^\/staff\/bookings\/([A-Z0-9]{6})\/cancel$/);

    if (req.method === 'GET' && pathname === '/') {
      return sendHtml(res, 200, views.listPage(store.listTastings()));
    }

    if (bookMatch && (req.method === 'GET' || req.method === 'POST')) {
      return bookingForm(req, res, bookMatch[1]);
    }

    if (req.method === 'GET' && confirmationMatch) {
      const booking = store.getBooking(confirmationMatch[1]);
      if (!booking) return sendHtml(res, 404, views.notFoundPage());
      const tasting = store.getTasting(booking.tastingId);
      return sendHtml(res, 200, views.confirmationPage(booking, tasting));
    }

    if (req.method === 'GET' && pathname === '/staff') {
      if (!isSignedIn(req)) return sendHtml(res, 200, views.staffLoginPage());
      return sendHtml(res, 200, views.staffPage(store.bookingsByTasting()));
    }

    if (req.method === 'POST' && pathname === '/staff/login') {
      const form = await readForm(req);
      if (!passwordMatches(form.get('password'))) {
        return sendHtml(res, 401, views.staffLoginPage('Wrong password.'));
      }
      const token = startSession();
      return redirect(res, '/staff', {
        'Set-Cookie': `${SESSION_COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_LIFETIME_MS / 1000}`,
      });
    }

    if (req.method === 'POST' && cancelMatch) {
      if (!isSignedIn(req)) return sendHtml(res, 401, views.staffLoginPage());
      store.cancelBooking(cancelMatch[1]);
      return redirect(res, '/staff');
    }

    return sendHtml(res, 404, views.notFoundPage());
  }

  return async function app(req, res) {
    try {
      await route(req, res);
    } catch (err) {
      if (err instanceof PayloadTooLarge) {
        return sendHtml(res, 413, views.payloadTooLargePage(), { Connection: 'close' });
      }
      console.error(err);
      if (!res.headersSent) sendHtml(res, 500, views.serverErrorPage());
    }
  };
}

module.exports = { createApp };
