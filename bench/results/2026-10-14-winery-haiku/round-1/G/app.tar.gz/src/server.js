const http = require('node:http');
const { createStore } = require('./store');
const { createApp } = require('./app');

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled until it is.');
}

const server = http.createServer(createApp({ store: createStore(), staffPassword }));

server.listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings listening on http://localhost:${port}`);
});
