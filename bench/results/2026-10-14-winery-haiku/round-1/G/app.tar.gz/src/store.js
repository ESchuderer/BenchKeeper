const crypto = require('node:crypto');

const MAX_GUESTS = 8;
const REFERENCE_LENGTH = 6;
// No 0/O or 1/I so references read clearly when staff type them.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06 18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05 17:00', price: 28, seats: 10 },
];

function parseGuests(value) {
  const text = typeof value === 'number' ? String(value) : typeof value === 'string' ? value.trim() : '';
  if (!/^\d+$/.test(text)) return null;
  const guests = Number(text);
  return guests >= 1 && guests <= MAX_GUESTS ? guests : null;
}

function validateContact({ name, email }) {
  if (typeof name !== 'string' || name.trim() === '') {
    return { error: 'Please enter your name.' };
  }
  const trimmedEmail = typeof email === 'string' ? email.trim() : '';
  if (trimmedEmail.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
    return { error: 'Please enter a valid email address.' };
  }
  return { name: name.trim(), email: trimmedEmail };
}

function seatsMessage(seatsLeft) {
  if (seatsLeft === 0) return 'This tasting is fully booked.';
  return `Only ${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left for this tasting.`;
}

function newReference() {
  let reference = '';
  for (let i = 0; i < REFERENCE_LENGTH; i++) {
    reference += REFERENCE_ALPHABET[crypto.randomInt(REFERENCE_ALPHABET.length)];
  }
  return reference;
}

function createStore() {
  const bookings = new Map();

  function seatsTaken(tastingId) {
    let taken = 0;
    for (const booking of bookings.values()) {
      if (booking.tastingId === tastingId) taken += booking.guests;
    }
    return taken;
  }

  function withSeatsLeft(tasting) {
    return { ...tasting, seatsLeft: tasting.seats - seatsTaken(tasting.id) };
  }

  function createBooking({ tastingId, name, email, guests }) {
    const tasting = TASTINGS.find((t) => t.id === tastingId);
    if (!tasting) return { error: 'This tasting does not exist.' };

    const parsedGuests = parseGuests(guests);
    if (parsedGuests === null) return { error: `Guests must be a whole number from 1 to ${MAX_GUESTS}.` };

    const contact = validateContact({ name, email });
    if (contact.error) return { error: contact.error };

    const seatsLeft = withSeatsLeft(tasting).seatsLeft;
    if (parsedGuests > seatsLeft) return { error: seatsMessage(seatsLeft) };

    let reference = newReference();
    while (bookings.has(reference)) reference = newReference();

    const booking = {
      reference,
      tastingId,
      name: contact.name,
      email: contact.email,
      guests: parsedGuests,
      total: tasting.price * parsedGuests,
    };
    bookings.set(reference, booking);
    return { booking };
  }

  return {
    listTastings: () => TASTINGS.map(withSeatsLeft),
    getTasting: (id) => {
      const tasting = TASTINGS.find((t) => t.id === id);
      return tasting && withSeatsLeft(tasting);
    },
    createBooking,
    getBooking: (reference) => bookings.get(reference),
    cancelBooking: (reference) => bookings.delete(reference),
    bookingsByTasting: () =>
      TASTINGS.map((tasting) => ({
        tasting: withSeatsLeft(tasting),
        bookings: [...bookings.values()].filter((b) => b.tastingId === tasting.id),
      })),
  };
}

module.exports = { createStore, TASTINGS, MAX_GUESTS };
