const { MAX_GUESTS } = require('./store');

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[char]);
}

const STYLE = `
  body { font-family: system-ui, sans-serif; margin: 0; color: #222; background: #fbf8f4; }
  header { background: #4a1d2e; padding: 1rem 2rem; }
  header a { color: #fff; text-decoration: none; font-weight: 600; font-size: 1.2rem; }
  main { max-width: 760px; margin: 2rem auto; padding: 0 1rem; }
  .tasting { background: #fff; border-radius: 6px; padding: 1rem 1.25rem; margin-bottom: 1rem; }
  .meta { color: #555; margin: 0.25rem 0 0.75rem; }
  .error { color: #9b1c1c; background: #fde8e8; padding: 0.5rem 0.75rem; border-radius: 4px; }
  form label { display: block; margin-bottom: 0.75rem; font-weight: 600; }
  form input { display: block; margin-top: 0.25rem; padding: 0.4rem; font-size: 1rem; width: 100%; max-width: 20rem; box-sizing: border-box; }
  button { background: #4a1d2e; color: #fff; border: 0; border-radius: 4px; padding: 0.5rem 1rem; font-size: 1rem; cursor: pointer; }
  table { border-collapse: collapse; width: 100%; background: #fff; margin-bottom: 2rem; }
  th, td { text-align: left; padding: 0.5rem; border-bottom: 1px solid #eee; }
  dl { display: grid; grid-template-columns: max-content 1fr; gap: 0.4rem 1rem; }
  dt { font-weight: 600; }
  dd { margin: 0; }
`;

function layout(title, body) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)} | Weingut Kieselbrunnen</title>
<style>${STYLE}</style>
</head>
<body>
<header><a href="/">Weingut Kieselbrunnen</a></header>
<main>
${body}
</main>
</body>
</html>
`;
}

function tastingDetails(tasting) {
  return `${escapeHtml(tasting.startsAt)} &middot; EUR ${escapeHtml(tasting.price)} per guest &middot; ${escapeHtml(tasting.seatsLeft)} seats left`;
}

function listPage(tastings) {
  const items = tastings
    .map(
      (t) => `<section class="tasting">
<h2>${escapeHtml(t.title)}</h2>
<p class="meta">${tastingDetails(t)}</p>
<a href="/book/${escapeHtml(t.id)}">Book ${escapeHtml(t.title)}</a>
</section>`,
    )
    .join('\n');
  return layout('Wine tastings', `<h1>Wine tastings</h1>\n${items}`);
}

function errorBox(message) {
  return message ? `<p class="error" role="alert">${escapeHtml(message)}</p>` : '';
}

function bookingFormPage(tasting, values = {}, error = null) {
  return layout(
    `Book ${tasting.title}`,
    `<h1>Book ${escapeHtml(tasting.title)}</h1>
<p class="meta">${tastingDetails(tasting)}</p>
${errorBox(error)}
<form method="post" action="/book/${escapeHtml(tasting.id)}">
<label>Name
  <input name="name" type="text" required value="${escapeHtml(values.name ?? '')}">
</label>
<label>Email
  <input name="email" type="email" required value="${escapeHtml(values.email ?? '')}">
</label>
<label>Guests
  <input name="guests" type="number" min="1" max="${MAX_GUESTS}" step="1" required value="${escapeHtml(values.guests ?? '1')}">
</label>
<button type="submit">Book</button>
</form>`,
  );
}

function confirmationPage(booking, tasting) {
  return layout(
    'Booking confirmed',
    `<h1>Booking confirmed</h1>
<dl>
  <dt>Tasting</dt><dd>${escapeHtml(tasting.title)}</dd>
  <dt>Date and time</dt><dd>${escapeHtml(tasting.startsAt)}</dd>
  <dt>Guests</dt><dd>${escapeHtml(booking.guests)}</dd>
  <dt>Total price</dt><dd>EUR ${escapeHtml(booking.total)}</dd>
  <dt>Booking reference</dt><dd>${escapeHtml(booking.reference)}</dd>
</dl>
<p><a href="/">Back to all tastings</a></p>`,
  );
}

function notFoundPage() {
  return layout('Not found', '<h1>Page not found</h1>\n<p><a href="/">Back to all tastings</a></p>');
}

function payloadTooLargePage() {
  return layout('Request too large', '<h1>Request too large</h1>\n<p>Please check the form and try again.</p>');
}

function serverErrorPage() {
  return layout('Error', '<h1>Something went wrong</h1>\n<p>Please try again.</p>');
}

function staffLoginPage(error = null) {
  return layout(
    'Staff sign in',
    `<h1>Staff sign in</h1>
${errorBox(error)}
<form method="post" action="/staff/login">
<label>Password
  <input name="password" type="password" required autocomplete="current-password">
</label>
<button type="submit">Sign in</button>
</form>`,
  );
}

function staffPage(groups) {
  const sections = groups
    .map(({ tasting, bookings }) => {
      const rows = bookings.length
        ? bookings
            .map(
              (b) => `<tr>
  <td>${escapeHtml(b.name)}</td>
  <td>${escapeHtml(b.email)}</td>
  <td>${escapeHtml(b.guests)}</td>
  <td>${escapeHtml(b.reference)}</td>
  <td>
    <form method="post" action="/staff/bookings/${escapeHtml(b.reference)}/cancel">
      <button type="submit">Cancel</button>
    </form>
  </td>
</tr>`,
            )
            .join('\n')
        : '<tr><td colspan="5">No bookings yet.</td></tr>';
      return `<section>
<h2>${escapeHtml(tasting.title)}</h2>
<p class="meta">${tastingDetails(tasting)}</p>
<table>
<thead><tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th></th></tr></thead>
<tbody>
${rows}
</tbody>
</table>
</section>`;
    })
    .join('\n');
  return layout('Bookings', `<h1>Bookings</h1>\n${sections}`);
}

module.exports = {
  listPage,
  bookingFormPage,
  confirmationPage,
  notFoundPage,
  payloadTooLargePage,
  serverErrorPage,
  staffLoginPage,
  staffPage,
};
