const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createStore } = require('../src/store');
const { createApp } = require('../src/app');

const PASSWORD = 'correct horse battery';

async function startServer({ staffPassword = PASSWORD } = {}) {
  const store = createStore();
  const server = http.createServer(createApp({ store, staffPassword }));
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  return {
    store,
    base,
    close: () => new Promise((resolve) => server.close(resolve)),
    get: (path, headers = {}) => fetch(base + path, { redirect: 'manual', headers }),
    post: (path, fields, headers = {}) =>
      fetch(base + path, {
        method: 'POST',
        redirect: 'manual',
        headers,
        body: new URLSearchParams(fields),
      }),
  };
}

async function withServer(options, fn) {
  const server = await startServer(options);
  try {
    await fn(server);
  } finally {
    await server.close();
  }
}

// Signs in as staff and returns the Cookie header value to send with later requests.
async function staffCookie(server) {
  const res = await server.post('/staff/login', { password: PASSWORD });
  assert.equal(res.status, 303, 'successful sign-in redirects');
  return res.headers.get('set-cookie').split(';')[0];
}

test('start page lists each tasting with title, date and time, price and seats left', async () => {
  await withServer({}, async (server) => {
    const res = await server.get('/');
    const html = await res.text();

    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /text\/html/);
    for (const text of [
      'Riesling Evening', '2026-11-06 18:00', 'EUR 25', '12 seats left',
      'Red Wine Cellar Tour', '2026-11-14 15:00', 'EUR 32', '8 seats left',
      'Winter Tasting', '2026-12-05 17:00', 'EUR 28', '10 seats left',
    ]) {
      assert.ok(html.includes(text), `start page should contain "${text}"`);
    }
  });
});

test('each tasting has a "Book <title>" link to its booking form', async () => {
  await withServer({}, async (server) => {
    const html = await (await server.get('/')).text();
    assert.ok(html.includes('href="/book/riesling-evening"'));
    assert.ok(html.includes('Book Riesling Evening'));
    assert.ok(html.includes('href="/book/red-wine-cellar-tour"'));
    assert.ok(html.includes('Book Red Wine Cellar Tour'));
    assert.ok(html.includes('href="/book/winter-tasting"'));
    assert.ok(html.includes('Book Winter Tasting'));
  });
});

test('the booking form has Name, Email and Guests (1 to 8) fields and a Book button', async () => {
  await withServer({}, async (server) => {
    const res = await server.get('/book/riesling-evening');
    const html = await res.text();

    assert.equal(res.status, 200);
    assert.ok(html.includes('Riesling Evening'));
    assert.match(html, /<label[^>]*>\s*Name/);
    assert.match(html, /<label[^>]*>\s*Email/);
    assert.match(html, /<label[^>]*>\s*Guests/);
    assert.match(html, /name="name"/);
    assert.match(html, /name="email"/);
    assert.match(html, /name="guests"[^>]*min="1"[^>]*max="8"|name="guests"[^>]*max="8"[^>]*min="1"/);
    assert.match(html, /<button[^>]*>\s*Book\s*<\/button>/);
  });
});

test('an unknown tasting gives 404 for both the form and the booking', async () => {
  await withServer({}, async (server) => {
    assert.equal((await server.get('/book/no-such-tasting')).status, 404);
    assert.equal((await server.post('/book/no-such-tasting', { name: 'A', email: 'a@example.com', guests: '1' })).status, 404);
  });
});

test('a valid booking redirects to a confirmation that shows the details', async () => {
  await withServer({}, async (server) => {
    const res = await server.post('/book/red-wine-cellar-tour', {
      name: 'Maria Klein',
      email: 'maria@example.com',
      guests: '3',
    });
    assert.equal(res.status, 303);
    const location = res.headers.get('location');
    assert.match(location, /^\/booking\/[A-Z0-9]{6}$/);

    const confirmation = await server.get(location);
    const html = await confirmation.text();
    const reference = location.split('/').pop();

    assert.equal(confirmation.status, 200);
    assert.match(html, /<h1[^>]*>\s*Booking confirmed\s*<\/h1>/);
    assert.ok(html.includes('Red Wine Cellar Tour'));
    assert.ok(html.includes('3'));
    assert.ok(html.includes('EUR 96'), 'total is 3 guests x EUR 32');
    assert.ok(html.includes(reference));
  });
});

test('a booking reduces the seats shown on the start page', async () => {
  await withServer({}, async (server) => {
    await server.post('/book/winter-tasting', { name: 'Lena', email: 'lena@example.com', guests: '4' });
    const html = await (await server.get('/')).text();
    assert.ok(html.includes('6 seats left'));
  });
});

test('a booking for more guests than seats left is rejected next to the form', async () => {
  await withServer({}, async (server) => {
    await server.post('/book/red-wine-cellar-tour', { name: 'A', email: 'a@example.com', guests: '6' });

    const res = await server.post('/book/red-wine-cellar-tour', { name: 'Ben', email: 'ben@example.com', guests: '3' });
    const html = await res.text();

    assert.equal(res.status, 400);
    assert.ok(html.includes('Only 2 seats left for this tasting.'));
    assert.match(html, /name="guests"/, 'the form is shown again');
    assert.ok(html.includes('value="Ben"'), 'the name is kept');
    assert.equal(server.store.getTasting('red-wine-cellar-tour').seatsLeft, 2);
  });
});

test('invalid input is rejected with an error message and keeps what was typed', async () => {
  await withServer({}, async (server) => {
    const res = await server.post('/book/winter-tasting', { name: 'Ina', email: 'not-an-email', guests: '2' });
    const html = await res.text();

    assert.equal(res.status, 400);
    assert.ok(html.includes('Please enter a valid email address.'));
    assert.ok(html.includes('value="Ina"'));
    assert.equal(server.store.getTasting('winter-tasting').seatsLeft, 10);
  });
});

test('guests outside 1 to 8 are rejected', async () => {
  await withServer({}, async (server) => {
    for (const guests of ['0', '9', '2.5', 'many', '']) {
      const res = await server.post('/book/winter-tasting', { name: 'A', email: 'a@example.com', guests });
      assert.equal(res.status, 400, `guests="${guests}"`);
      assert.ok((await res.text()).includes('Guests must be a whole number from 1 to 8.'));
    }
    assert.equal(server.store.getTasting('winter-tasting').seatsLeft, 10);
  });
});

test('an unknown booking reference gives 404', async () => {
  await withServer({}, async (server) => {
    assert.equal((await server.get('/booking/ZZZZZZ')).status, 404);
  });
});

test('staff page asks for the password when not signed in', async () => {
  await withServer({}, async (server) => {
    server.store.createBooking({ tastingId: 'winter-tasting', name: 'Secret Guest', email: 's@example.com', guests: 1 });

    const res = await server.get('/staff');
    const html = await res.text();

    assert.equal(res.status, 200);
    assert.match(html, /<label[^>]*>\s*Password/);
    assert.match(html, /name="password"[^>]*type="password"|type="password"[^>]*name="password"/);
    assert.match(html, /<button[^>]*>\s*Sign in\s*<\/button>/);
    assert.ok(!html.includes('Secret Guest'), 'bookings are not shown before sign-in');
  });
});

test('a wrong password is refused and no session is started', async () => {
  await withServer({}, async (server) => {
    const res = await server.post('/staff/login', { password: 'guess' });
    const html = await res.text();

    assert.equal(res.status, 401);
    assert.ok(html.includes('Wrong password.'));
    assert.equal(res.headers.get('set-cookie'), null);
  });
});

test('no password is accepted when STAFF_PASSWORD is not set', async () => {
  await withServer({ staffPassword: undefined }, async (server) => {
    assert.equal((await server.post('/staff/login', { password: '' })).status, 401);
    assert.equal((await server.post('/staff/login', { password: 'undefined' })).status, 401);
  });
});

test('signed-in staff see bookings grouped by tasting with name, email, guests and reference', async () => {
  await withServer({}, async (server) => {
    const { booking } = server.store.createBooking({
      tastingId: 'riesling-evening',
      name: 'Felix Braun',
      email: 'felix@example.com',
      guests: 2,
    });
    const cookie = await staffCookie(server);

    const res = await server.get('/staff', { cookie });
    const html = await res.text();

    assert.equal(res.status, 200);
    assert.ok(html.includes('Riesling Evening'));
    assert.ok(html.includes('Felix Braun'));
    assert.ok(html.includes('felix@example.com'));
    assert.ok(html.includes(booking.reference));
    assert.ok(html.indexOf('Felix Braun') > html.indexOf('Riesling Evening'), 'booking appears under its tasting');
    assert.ok(html.indexOf('Felix Braun') < html.indexOf('Red Wine Cellar Tour'), 'and before the next tasting');
    assert.match(html, /<button[^>]*>\s*Cancel\s*<\/button>/);
  });
});

test('staff can cancel a booking, which frees its seats', async () => {
  await withServer({}, async (server) => {
    const { booking } = server.store.createBooking({
      tastingId: 'winter-tasting',
      name: 'Gerda',
      email: 'gerda@example.com',
      guests: 6,
    });
    const cookie = await staffCookie(server);

    const res = await server.post(`/staff/bookings/${booking.reference}/cancel`, {}, { cookie });
    assert.equal(res.status, 303);
    assert.equal(res.headers.get('location'), '/staff');

    assert.equal(server.store.getBooking(booking.reference), undefined);
    assert.equal(server.store.getTasting('winter-tasting').seatsLeft, 10);
    assert.ok(!(await (await server.get('/staff', { cookie })).text()).includes('gerda@example.com'));
  });
});

test('cancelling without signing in does not cancel the booking', async () => {
  await withServer({}, async (server) => {
    const { booking } = server.store.createBooking({
      tastingId: 'winter-tasting',
      name: 'Hans',
      email: 'hans@example.com',
      guests: 2,
    });

    const res = await server.post(`/staff/bookings/${booking.reference}/cancel`, {});
    assert.notEqual(res.status, 200);
    assert.ok(server.store.getBooking(booking.reference), 'booking still exists');
    assert.equal(server.store.getTasting('winter-tasting').seatsLeft, 8);
  });
});

test('guest-supplied text is HTML-escaped on the staff page', async () => {
  await withServer({}, async (server) => {
    const payload = '<script>alert(1)</script>';
    await server.post('/book/winter-tasting', { name: payload, email: 'x@example.com', guests: '1' });

    const cookie = await staffCookie(server);
    const staffHtml = await (await server.get('/staff', { cookie })).text();
    assert.ok(!staffHtml.includes(payload));
    assert.ok(staffHtml.includes('&lt;script&gt;'));
  });
});

test('oversized request bodies are refused', async () => {
  await withServer({}, async (server) => {
    const res = await server.post('/book/winter-tasting', { name: 'A'.repeat(100000), email: 'a@example.com', guests: '1' });
    assert.equal(res.status, 413);
    assert.equal(server.store.getTasting('winter-tasting').seatsLeft, 10);
  });
});
