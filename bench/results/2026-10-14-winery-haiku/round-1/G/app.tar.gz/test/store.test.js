const test = require('node:test');
const assert = require('node:assert/strict');
const { createStore } = require('../src/store');

const RIESLING = 'riesling-evening';
const CELLAR = 'red-wine-cellar-tour';
const WINTER = 'winter-tasting';

test('lists the three tastings with all seats free at the start', () => {
  const store = createStore();
  const tastings = store.listTastings();

  assert.deepEqual(
    tastings.map((t) => [t.id, t.title, t.startsAt, t.price, t.seats, t.seatsLeft]),
    [
      [RIESLING, 'Riesling Evening', '2026-11-06 18:00', 25, 12, 12],
      [CELLAR, 'Red Wine Cellar Tour', '2026-11-14 15:00', 32, 8, 8],
      [WINTER, 'Winter Tasting', '2026-12-05 17:00', 28, 10, 10],
    ],
  );
});

test('a booking takes its guests out of the seats left', () => {
  const store = createStore();
  const result = store.createBooking({ tastingId: RIESLING, name: 'Anna', email: 'anna@example.com', guests: 3 });

  assert.ok(result.booking, `expected a booking, got error: ${result.error}`);
  assert.equal(store.getTasting(RIESLING).seatsLeft, 9);
});

test('booking returns a reference, the total price and the guest details', () => {
  const store = createStore();
  const { booking } = store.createBooking({
    tastingId: CELLAR,
    name: '  Jonas Weber ',
    email: ' jonas@example.com ',
    guests: 2,
  });

  assert.match(booking.reference, /^[A-Z0-9]{6}$/);
  assert.equal(booking.tastingId, CELLAR);
  assert.equal(booking.name, 'Jonas Weber');
  assert.equal(booking.email, 'jonas@example.com');
  assert.equal(booking.guests, 2);
  assert.equal(booking.total, 64);
});

test('booking references are unique', () => {
  const store = createStore();
  const refs = new Set();
  for (let i = 0; i < 10; i++) {
    const { booking } = store.createBooking({ tastingId: WINTER, name: 'A', email: 'a@example.com', guests: 1 });
    refs.add(booking.reference);
  }
  assert.equal(refs.size, 10);
});

test('a booking can fill a tasting exactly, but not go beyond its seats', () => {
  const store = createStore();
  assert.ok(store.createBooking({ tastingId: CELLAR, name: 'A', email: 'a@example.com', guests: 8 }).booking);
  assert.equal(store.getTasting(CELLAR).seatsLeft, 0);

  const result = store.createBooking({ tastingId: CELLAR, name: 'B', email: 'b@example.com', guests: 1 });
  assert.equal(result.booking, undefined);
  assert.equal(result.error, 'This tasting is fully booked.');
  assert.equal(store.getTasting(CELLAR).seatsLeft, 0);
});

test('a request for more guests than seats left is rejected and changes nothing', () => {
  const store = createStore();
  store.createBooking({ tastingId: CELLAR, name: 'A', email: 'a@example.com', guests: 6 });

  const result = store.createBooking({ tastingId: CELLAR, name: 'B', email: 'b@example.com', guests: 3 });
  assert.equal(result.error, 'Only 2 seats left for this tasting.');
  assert.equal(store.getTasting(CELLAR).seatsLeft, 2);
});

test('the seat count message uses the singular for one seat', () => {
  const store = createStore();
  store.createBooking({ tastingId: CELLAR, name: 'A', email: 'a@example.com', guests: 7 });

  const result = store.createBooking({ tastingId: CELLAR, name: 'B', email: 'b@example.com', guests: 2 });
  assert.equal(result.error, 'Only 1 seat left for this tasting.');
});

test('guests must be a whole number from 1 to 8', () => {
  const store = createStore();
  for (const guests of [0, -1, 9, 1.5, NaN, '', 'abc', null, undefined]) {
    const result = store.createBooking({ tastingId: WINTER, name: 'A', email: 'a@example.com', guests });
    assert.equal(result.booking, undefined, `guests=${String(guests)} should be rejected`);
    assert.equal(result.error, 'Guests must be a whole number from 1 to 8.', `guests=${String(guests)}`);
  }
  assert.equal(store.getTasting(WINTER).seatsLeft, 10);
});

test('guests given as numeric strings from a form are accepted', () => {
  const store = createStore();
  const result = store.createBooking({ tastingId: WINTER, name: 'A', email: 'a@example.com', guests: '4' });
  assert.equal(result.booking.guests, 4);
});

test('name and email are required and the email must look like one', () => {
  const store = createStore();
  const base = { tastingId: RIESLING, guests: 1 };

  assert.equal(store.createBooking({ ...base, name: '   ', email: 'a@example.com' }).error, 'Please enter your name.');
  assert.equal(store.createBooking({ ...base, name: 'A', email: '' }).error, 'Please enter a valid email address.');
  assert.equal(store.createBooking({ ...base, name: 'A', email: 'not-an-email' }).error, 'Please enter a valid email address.');
  assert.equal(store.createBooking({ ...base, name: 'A', email: 'a b@example.com' }).error, 'Please enter a valid email address.');
  assert.equal(store.getTasting(RIESLING).seatsLeft, 12);
});

test('booking an unknown tasting is rejected', () => {
  const store = createStore();
  const result = store.createBooking({ tastingId: 'no-such-tasting', name: 'A', email: 'a@example.com', guests: 1 });
  assert.equal(result.error, 'This tasting does not exist.');
});

test('cancelling a booking frees its seats again', () => {
  const store = createStore();
  const { booking } = store.createBooking({ tastingId: CELLAR, name: 'A', email: 'a@example.com', guests: 5 });
  assert.equal(store.getTasting(CELLAR).seatsLeft, 3);

  assert.equal(store.cancelBooking(booking.reference), true);
  assert.equal(store.getTasting(CELLAR).seatsLeft, 8);
  assert.equal(store.getBooking(booking.reference), undefined);
});

test('cancelling an unknown or already cancelled reference returns false', () => {
  const store = createStore();
  const { booking } = store.createBooking({ tastingId: CELLAR, name: 'A', email: 'a@example.com', guests: 1 });

  assert.equal(store.cancelBooking('ZZZZZZ'), false);
  assert.equal(store.cancelBooking(booking.reference), true);
  assert.equal(store.cancelBooking(booking.reference), false);
});

test('bookings are grouped by tasting for staff, in booking order', () => {
  const store = createStore();
  const first = store.createBooking({ tastingId: WINTER, name: 'First', email: 'f@example.com', guests: 2 }).booking;
  store.createBooking({ tastingId: RIESLING, name: 'Second', email: 's@example.com', guests: 1 });
  const third = store.createBooking({ tastingId: WINTER, name: 'Third', email: 't@example.com', guests: 4 }).booking;

  const groups = store.bookingsByTasting();
  const winter = groups.find((g) => g.tasting.id === WINTER);
  const riesling = groups.find((g) => g.tasting.id === RIESLING);
  const cellar = groups.find((g) => g.tasting.id === CELLAR);

  assert.deepEqual(winter.bookings.map((b) => b.reference), [first.reference, third.reference]);
  assert.equal(riesling.bookings.length, 1);
  assert.deepEqual(cellar.bookings, []);
});
