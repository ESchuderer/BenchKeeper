# Weingut Kieselbrunnen: tasting bookings

A small web app where guests book wine tastings online and staff see and cancel bookings.

## Requirements

- Node.js 22 or newer

## Running it

```bash
npm install
STAFF_PASSWORD='choose-a-strong-password' npm start
```

Then open http://localhost:3000 (or the port set in `PORT`).

| Variable         | Default | Purpose                                                                 |
|------------------|---------|-------------------------------------------------------------------------|
| `PORT`           | `3000`  | Port the server listens on.                                             |
| `STAFF_PASSWORD` | none    | Password for `/staff`. If unset, staff sign-in is unavailable.          |
| `NODE_ENV`       | none    | Set to `production` to mark the staff session cookie `Secure` (HTTPS only). |

To run the tests:

```bash
npm test
```

## Pages

- `/` lists the tastings with date and time, price per guest and seats left. Each tasting has a "Book <title>" link.
- `/tastings/<id>/book` is the booking form (Name, Email, Guests 1 to 8).
- `/bookings/<reference>` shows "Booking confirmed" with the tasting, guests, total price and reference.
- `/staff` asks for the password. Once signed in, it lists bookings grouped by tasting with a "Cancel" button per booking. Cancelling frees the seats.

## Design notes

- **Storage is in memory.** The app starts with no bookings, and a restart clears all bookings and staff sessions. There is no database and no external service.
- **Seat accounting is in one place.** `src/bookings.js` owns the seat count. The store refuses any booking that exceeds the seats left, and the form reports the same rule before it reaches the store.
- **Prices are stored in cents** to avoid floating-point rounding. The catalogue is in `src/tastings.js`.
- **Staff security:**
  - The password is compared in constant time.
  - Sessions use random tokens in an `HttpOnly`, `SameSite=Strict` cookie scoped to `/staff`.
  - Cancelling requires a per-session CSRF token.
  - Sign-in attempts are limited to 10 per 15 minutes per client.
  - Staff pages are sent with `Cache-Control: no-store`.
- **Output is escaped.** All dynamic values go through `escapeHtml` in `src/views.js`. The Content-Security-Policy allows only same-origin resources, and there are no inline scripts or styles.

## Layout

```
src/
  server.js        entry point: reads PORT and STAFF_PASSWORD, starts the server
  app.js           routes, security headers, rate limit
  tastings.js      the tastings on offer
  bookings.js      in-memory booking store and seat accounting
  booking-rules.js booking form validation
  staff-auth.js    staff password check, sessions, cookie handling
  views.js         HTML templates
  format.js        money, seat and date formatting
public/styles.css
test/              unit tests (rules, store) and HTTP tests (app)
```

## Known limitations

- Bookings and staff sessions are lost on restart.
- There is no staff sign-out; a session expires after 8 hours.
- Cancelling is immediate, with no confirmation step.
- Serve behind HTTPS in production and set `NODE_ENV=production` so the cookie is marked `Secure`.
