'use strict';

const crypto = require('node:crypto');
const path = require('node:path');
const express = require('express');
const rateLimit = require('express-rate-limit');
const { TASTINGS, findTasting } = require('./tastings');
const { createBookingStore } = require('./bookings');
const { validateBooking } = require('./booking-rules');
const { createStaffAuth } = require('./staff-auth');
const views = require('./views');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_ATTEMPTS_PER_WINDOW = 10;
const FORM_BODY_LIMIT = '10kb';

const CONTENT_SECURITY_POLICY = [
  "default-src 'self'",
  "style-src 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  "base-uri 'none'",
].join('; ');

function securityHeaders(req, res, next) {
  res.set({
    'Content-Security-Policy': CONTENT_SECURITY_POLICY,
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  });
  next();
}

function noStore(req, res, next) {
  res.set('Cache-Control', 'no-store');
  next();
}

/** Constant-time comparison of the submitted CSRF token with the session's. */
function csrfTokenMatches(submitted, expected) {
  if (typeof submitted !== 'string') return false;
  const a = Buffer.from(submitted);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/**
 * @param {{ staffPassword?: string, store?: ReturnType<typeof createBookingStore>, secureCookies?: boolean }} options
 */
function createApp({ staffPassword, store = createBookingStore(TASTINGS), secureCookies = false } = {}) {
  const app = express();
  const staffAuth = createStaffAuth({ password: staffPassword, secureCookies });

  const loginLimiter = rateLimit({
    windowMs: LOGIN_WINDOW_MS,
    limit: LOGIN_ATTEMPTS_PER_WINDOW,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res) => {
      res.status(429).send(views.staffLoginPage({
        error: 'Too many sign-in attempts. Please wait 15 minutes and try again.',
      }));
    },
  });

  app.disable('x-powered-by');
  app.use(securityHeaders);
  app.use(express.urlencoded({ extended: false, limit: FORM_BODY_LIMIT }));
  app.use(express.static(PUBLIC_DIR, { index: false }));

  app.get('/', (req, res) => {
    const listings = TASTINGS.map((tasting) => ({ tasting, seatsLeft: store.seatsLeft(tasting.id) }));
    res.send(views.tastingsPage(listings));
  });

  app.get('/tastings/:id/book', (req, res) => {
    const tasting = findTasting(req.params.id);
    if (!tasting) {
      res.status(404).send(views.messagePage({ title: 'Tasting not found', message: 'This tasting does not exist.' }));
      return;
    }
    const values = { name: '', email: '', guests: '' };
    res.send(views.bookingFormPage({ tasting, seatsLeft: store.seatsLeft(tasting.id), values, errors: {} }));
  });

  app.post('/tastings/:id/book', (req, res) => {
    const tasting = findTasting(req.params.id);
    if (!tasting) {
      res.status(404).send(views.messagePage({ title: 'Tasting not found', message: 'This tasting does not exist.' }));
      return;
    }
    const seatsLeft = store.seatsLeft(tasting.id);
    const { errors, values, data } = validateBooking(req.body, seatsLeft);
    if (data === null) {
      res.status(400).send(views.bookingFormPage({ tasting, seatsLeft, values, errors }));
      return;
    }
    const booking = store.addBooking({ tastingId: tasting.id, ...data });
    res.redirect(303, `/bookings/${encodeURIComponent(booking.reference)}`);
  });

  app.get('/bookings/:reference', (req, res) => {
    const booking = store.findByReference(req.params.reference);
    if (!booking) {
      res.status(404).send(views.messagePage({ title: 'Booking not found', message: 'No booking matches this reference.' }));
      return;
    }
    res.send(views.confirmationPage({ booking, tasting: findTasting(booking.tastingId) }));
  });

  app.get('/staff', noStore, (req, res) => {
    const session = staffAuth.sessionFor(req);
    if (!session) {
      res.send(views.staffLoginPage());
      return;
    }
    res.send(views.staffBookingsPage({ listings: store.listByTasting(), csrfToken: session.csrfToken }));
  });

  app.post('/staff/login', noStore, loginLimiter, (req, res) => {
    if (!staffAuth.isConfigured()) {
      res.status(503).send(views.staffLoginPage({ error: 'Staff sign-in is not available right now.' }));
      return;
    }
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!staffAuth.checkPassword(password)) {
      res.status(401).send(views.staffLoginPage({ error: 'Incorrect password.' }));
      return;
    }
    const { token } = staffAuth.startSession();
    staffAuth.setSessionCookie(res, token);
    res.redirect(303, '/staff');
  });

  app.post('/staff/bookings/:reference/cancel', noStore, (req, res) => {
    const session = staffAuth.sessionFor(req);
    if (!session) {
      res.redirect(303, '/staff');
      return;
    }
    if (!csrfTokenMatches(req.body?._csrf, session.csrfToken)) {
      res.status(403).send(views.messagePage({
        title: 'Request rejected',
        message: 'This form has expired. Please reload the staff page and try again.',
      }));
      return;
    }
    store.cancel(req.params.reference);
    res.redirect(303, '/staff');
  });

  app.use((req, res) => {
    res.status(404).send(views.messagePage({ title: 'Page not found', message: 'The page you asked for does not exist.' }));
  });

  // Express 5 forwards errors from malformed or oversized bodies here as well.
  app.use((err, req, res, next) => {
    if (res.headersSent) {
      next(err);
      return;
    }
    const status = err.status ?? err.statusCode ?? 500;
    if (status >= 500) {
      console.error(err);
      res.status(500).send(views.messagePage({ title: 'Something went wrong', message: 'Please try again later.' }));
      return;
    }
    res.status(status).send(views.messagePage({ title: 'Request not accepted', message: 'The request could not be processed.' }));
  });

  return app;
}

module.exports = { createApp };
