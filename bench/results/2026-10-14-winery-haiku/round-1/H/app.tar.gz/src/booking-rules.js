'use strict';

const { formatSeatsLeft } = require('./format');

const MAX_GUESTS_PER_BOOKING = 8;
const MAX_NAME_LENGTH = 100;
const MAX_EMAIL_LENGTH = 254;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const WHOLE_NUMBER_PATTERN = /^\d+$/;

const MESSAGES = Object.freeze({
  name: 'Please enter your name.',
  nameTooLong: `Name must be at most ${MAX_NAME_LENGTH} characters.`,
  email: 'Please enter your email address.',
  emailInvalid: 'Please enter a valid email address.',
  guestsRange: `Guests must be a whole number from 1 to ${MAX_GUESTS_PER_BOOKING}.`,
  fullyBooked: 'This tasting is fully booked.',
});

/** Form fields arrive as strings, or as arrays when a field is repeated. */
function asTrimmedString(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function checkName(name) {
  if (name === '') return MESSAGES.name;
  if (name.length > MAX_NAME_LENGTH) return MESSAGES.nameTooLong;
  return null;
}

function checkEmail(email) {
  if (email === '') return MESSAGES.email;
  if (email.length > MAX_EMAIL_LENGTH || !EMAIL_PATTERN.test(email)) return MESSAGES.emailInvalid;
  return null;
}

function checkGuests(rawGuests, seatsLeft) {
  if (!WHOLE_NUMBER_PATTERN.test(rawGuests)) return { message: MESSAGES.guestsRange };
  const guests = Number(rawGuests);
  if (guests < 1 || guests > MAX_GUESTS_PER_BOOKING) return { message: MESSAGES.guestsRange };
  if (seatsLeft === 0) return { message: MESSAGES.fullyBooked };
  if (guests > seatsLeft) {
    return { message: `Only ${formatSeatsLeft(seatsLeft)} for this tasting.` };
  }
  return { guests };
}

/**
 * Checks a booking form against the rules and the seats still free.
 *
 * @param {Record<string, unknown> | undefined} input the submitted form fields
 * @param {number} seatsLeft
 * @returns {{
 *   errors: { name?: string, email?: string, guests?: string },
 *   values: { name: string, email: string, guests: string },
 *   data: { name: string, email: string, guests: number } | null,
 * }} data is null whenever there are errors
 */
function validateBooking(input = {}, seatsLeft) {
  const values = {
    name: asTrimmedString(input.name),
    email: asTrimmedString(input.email),
    guests: asTrimmedString(input.guests),
  };

  const errors = {};
  const nameError = checkName(values.name);
  if (nameError) errors.name = nameError;

  const emailError = checkEmail(values.email);
  if (emailError) errors.email = emailError;

  const guestsCheck = checkGuests(values.guests, seatsLeft);
  if (guestsCheck.message) errors.guests = guestsCheck.message;

  if (Object.keys(errors).length > 0) {
    return { errors, values, data: null };
  }
  return {
    errors,
    values,
    data: { name: values.name, email: values.email, guests: guestsCheck.guests },
  };
}

module.exports = { validateBooking, MAX_GUESTS_PER_BOOKING };
