'use strict';

const crypto = require('node:crypto');

/** No 0/O or 1/I, so references read clearly over the phone. */
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const REFERENCE_SUFFIX_LENGTH = 6;

function randomReference() {
  let suffix = '';
  for (let i = 0; i < REFERENCE_SUFFIX_LENGTH; i += 1) {
    suffix += REFERENCE_ALPHABET[crypto.randomInt(REFERENCE_ALPHABET.length)];
  }
  return `KB-${suffix}`;
}

/**
 * In-memory booking store. Node runs JavaScript on one thread and every
 * method here is synchronous, so the seat check and the insert cannot interleave.
 *
 * @param {ReadonlyArray<{ id: string, priceCents: number, seats: number }>} tastings
 */
function createBookingStore(tastings) {
  const tastingsById = new Map(tastings.map((tasting) => [tasting.id, tasting]));
  const bookingsByReference = new Map();

  function requireTasting(tastingId) {
    const tasting = tastingsById.get(tastingId);
    if (!tasting) {
      throw new Error(`Unknown tasting: ${tastingId}`);
    }
    return tasting;
  }

  function seatsTaken(tastingId) {
    let total = 0;
    for (const booking of bookingsByReference.values()) {
      if (booking.tastingId === tastingId) {
        total += booking.guests;
      }
    }
    return total;
  }

  function seatsLeft(tastingId) {
    return requireTasting(tastingId).seats - seatsTaken(tastingId);
  }

  function newUniqueReference() {
    let reference = randomReference();
    while (bookingsByReference.has(reference)) {
      reference = randomReference();
    }
    return reference;
  }

  /**
   * @param {{ tastingId: string, name: string, email: string, guests: number }} details
   */
  function addBooking({ tastingId, name, email, guests }) {
    const tasting = requireTasting(tastingId);
    const free = seatsLeft(tastingId);
    if (guests < 1 || guests > free) {
      throw new RangeError(`Only ${free} seats left for ${tasting.id}`);
    }

    const booking = Object.freeze({
      reference: newUniqueReference(),
      tastingId,
      name,
      email,
      guests,
      totalCents: guests * tasting.priceCents,
      createdAt: new Date().toISOString(),
    });
    bookingsByReference.set(booking.reference, booking);
    return booking;
  }

  function findByReference(reference) {
    return bookingsByReference.get(reference);
  }

  /** @returns {boolean} true when a booking was removed */
  function cancel(reference) {
    return bookingsByReference.delete(reference);
  }

  /**
   * Every tasting, in catalogue order, with its bookings in the order they were made.
   */
  function listByTasting() {
    const all = [...bookingsByReference.values()];
    return tastings.map((tasting) => ({
      tasting,
      bookings: all.filter((booking) => booking.tastingId === tasting.id),
      seatsLeft: seatsLeft(tasting.id),
    }));
  }

  return { seatsLeft, addBooking, findByReference, cancel, listByTasting };
}

module.exports = { createBookingStore };
