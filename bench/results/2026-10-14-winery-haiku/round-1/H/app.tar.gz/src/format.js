'use strict';

const MONTH_NAMES = Object.freeze([
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
]);

/**
 * @param {number} cents
 * @returns {string} e.g. "EUR 25.00"
 */
function formatEuros(cents) {
  return `EUR ${(cents / 100).toFixed(2)}`;
}

/**
 * @param {number} seatsLeft
 * @returns {string} e.g. "12 seats left" or "1 seat left"
 */
function formatSeatsLeft(seatsLeft) {
  return seatsLeft === 1 ? '1 seat left' : `${seatsLeft} seats left`;
}

/**
 * @param {string} startsAt "YYYY-MM-DD HH:MM"
 * @returns {string} e.g. "6 November 2026, 18:00"
 */
function formatStartsAt(startsAt) {
  const [date, time] = startsAt.split(' ');
  const [year, month, day] = date.split('-').map(Number);
  return `${day} ${MONTH_NAMES[month - 1]} ${year}, ${time}`;
}

/**
 * @param {string} startsAt "YYYY-MM-DD HH:MM"
 * @returns {string} e.g. "2026-11-06T18:00", for the <time> element
 */
function toMachineDateTime(startsAt) {
  return startsAt.replace(' ', 'T');
}

module.exports = { formatEuros, formatSeatsLeft, formatStartsAt, toMachineDateTime };
