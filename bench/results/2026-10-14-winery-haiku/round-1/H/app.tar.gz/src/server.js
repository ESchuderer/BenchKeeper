'use strict';

const { createApp } = require('./app');

const DEFAULT_PORT = 3000;
const MAX_PORT = 65535;

function readPort(value) {
  if (value === undefined || value === '') return DEFAULT_PORT;
  const port = Number(value);
  if (!Number.isInteger(port) || port < 0 || port > MAX_PORT) {
    throw new Error(`PORT must be an integer from 0 to ${MAX_PORT}, got "${value}"`);
  }
  return port;
}

function main() {
  const port = readPort(process.env.PORT);
  const staffPassword = process.env.STAFF_PASSWORD;
  if (!staffPassword) {
    console.error('STAFF_PASSWORD is not set: staff sign-in will be unavailable.');
  }

  const app = createApp({
    staffPassword,
    secureCookies: process.env.NODE_ENV === 'production',
  });
  app.listen(port, (error) => {
    if (error) {
      console.error(`Could not listen on port ${port}: ${error.message}`);
      process.exitCode = 1;
      return;
    }
    console.info(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
  });
}

try {
  main();
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
