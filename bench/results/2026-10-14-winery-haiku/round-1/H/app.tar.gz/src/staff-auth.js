'use strict';

const crypto = require('node:crypto');

const SESSION_COOKIE = 'staff_session';
const SESSION_LIFETIME_MS = 8 * 60 * 60 * 1000;

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest();
}

function randomToken() {
  return crypto.randomBytes(32).toString('base64url');
}

/**
 * Reads one cookie value from a request's Cookie header.
 *
 * @param {import('node:http').IncomingMessage} req
 * @param {string} name
 * @returns {string | undefined}
 */
function readCookie(req, name) {
  const header = req.headers.cookie ?? '';
  for (const pair of header.split(';')) {
    const separator = pair.indexOf('=');
    if (separator !== -1 && pair.slice(0, separator).trim() === name) {
      return pair.slice(separator + 1).trim();
    }
  }
  return undefined;
}

/**
 * Staff sign-in backed by the STAFF_PASSWORD secret. Sessions live in memory,
 * so a restart signs everyone out.
 *
 * @param {{ password?: string, now?: () => number, secureCookies?: boolean }} options
 */
function createStaffAuth({ password, now = Date.now, secureCookies = false }) {
  // Hash both sides so the comparison has equal-length buffers for timingSafeEqual.
  const passwordDigest = password ? sha256(password) : null;
  const sessions = new Map();

  function isConfigured() {
    return passwordDigest !== null;
  }

  function checkPassword(candidate) {
    if (passwordDigest === null) return false;
    return crypto.timingSafeEqual(passwordDigest, sha256(String(candidate ?? '')));
  }

  /** @returns {{ token: string, csrfToken: string }} */
  function startSession() {
    const token = randomToken();
    const csrfToken = randomToken();
    sessions.set(token, { csrfToken, expiresAt: now() + SESSION_LIFETIME_MS });
    return { token, csrfToken };
  }

  /** @returns {{ csrfToken: string } | null} */
  function sessionFor(req) {
    const token = readCookie(req, SESSION_COOKIE);
    if (!token) return null;
    const session = sessions.get(token);
    if (!session) return null;
    if (session.expiresAt <= now()) {
      sessions.delete(token);
      return null;
    }
    return { csrfToken: session.csrfToken };
  }

  function setSessionCookie(res, token) {
    const parts = [
      `${SESSION_COOKIE}=${token}`,
      'Path=/staff',
      'HttpOnly',
      'SameSite=Strict',
      `Max-Age=${SESSION_LIFETIME_MS / 1000}`,
    ];
    if (secureCookies) parts.push('Secure');
    res.append('Set-Cookie', parts.join('; '));
  }

  return { isConfigured, checkPassword, startSession, sessionFor, setSessionCookie };
}

module.exports = { createStaffAuth };
