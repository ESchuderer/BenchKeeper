'use strict';

/**
 * The tastings on offer. Prices are whole cents to avoid floating-point rounding.
 * startsAt is local winery time, formatted "YYYY-MM-DD HH:MM".
 */
const TASTINGS = Object.freeze([
  Object.freeze({
    id: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06 18:00',
    priceCents: 2500,
    seats: 12,
  }),
  Object.freeze({
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    startsAt: '2026-11-14 15:00',
    priceCents: 3200,
    seats: 8,
  }),
  Object.freeze({
    id: 'winter-tasting',
    title: 'Winter Tasting',
    startsAt: '2026-12-05 17:00',
    priceCents: 2800,
    seats: 10,
  }),
]);

/**
 * @param {string} id
 * @returns {(typeof TASTINGS)[number] | undefined}
 */
function findTasting(id) {
  return TASTINGS.find((tasting) => tasting.id === id);
}

module.exports = { TASTINGS, findTasting };
