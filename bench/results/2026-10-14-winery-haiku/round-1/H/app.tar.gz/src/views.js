'use strict';

const { formatEuros, formatSeatsLeft, formatStartsAt, toMachineDateTime } = require('./format');
const { MAX_GUESTS_PER_BOOKING } = require('./booking-rules');

const HTML_ESCAPES = Object.freeze({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
});

/** Every dynamic value in a template must pass through here. */
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => HTML_ESCAPES[character]);
}

function layout({ title, body }) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)} | Weingut Kieselbrunnen</title>
  <link rel="stylesheet" href="/styles.css">
</head>
<body>
  <header class="site-header">
    <a class="brand" href="/">Weingut Kieselbrunnen</a>
    <nav>
      <a href="/">Tastings</a>
      <a href="/staff">Staff</a>
    </nav>
  </header>
  <main>
${body}
  </main>
</body>
</html>
`;
}

function whenHtml(startsAt) {
  return `<time datetime="${escapeHtml(toMachineDateTime(startsAt))}">${escapeHtml(formatStartsAt(startsAt))}</time>`;
}

function messagePage({ title, message }) {
  return layout({
    title,
    body: `    <h1>${escapeHtml(title)}</h1>
    <p>${escapeHtml(message)}</p>
    <p><a href="/">Back to all tastings</a></p>`,
  });
}

/** @param {Array<{ tasting: object, seatsLeft: number }>} listings */
function tastingsPage(listings) {
  const cards = listings
    .map(({ tasting, seatsLeft }) => `      <li class="tasting">
        <h2>${escapeHtml(tasting.title)}</h2>
        <dl>
          <dt>Date and time</dt>
          <dd>${whenHtml(tasting.startsAt)}</dd>
          <dt>Price per guest</dt>
          <dd>${escapeHtml(formatEuros(tasting.priceCents))}</dd>
          <dt>Availability</dt>
          <dd>${escapeHtml(formatSeatsLeft(seatsLeft))}</dd>
        </dl>
        <a class="button" href="/tastings/${encodeURIComponent(tasting.id)}/book">Book ${escapeHtml(tasting.title)}</a>
      </li>`)
    .join('\n');

  return layout({
    title: 'Tastings',
    body: `    <h1>Wine tastings</h1>
    <ul class="tastings">
${cards}
    </ul>`,
  });
}

function fieldErrorHtml(errors, field) {
  if (!errors[field]) return '';
  return `\n        <p class="field-error" id="${field}-error">${escapeHtml(errors[field])}</p>`;
}

/**
 * @param {{
 *   tasting: object,
 *   seatsLeft: number,
 *   values: { name: string, email: string, guests: string },
 *   errors: Record<string, string>,
 * }} page
 */
function bookingFormPage({ tasting, seatsLeft, values, errors }) {
  const hasErrors = Object.keys(errors).length > 0;
  const alert = hasErrors
    ? `\n      <div class="alert" role="alert">Your booking was not made. Please check the highlighted fields.</div>`
    : '';
  const describedBy = (field) => (errors[field] ? ` aria-describedby="${field}-error" aria-invalid="true"` : '');
  const action = `/tastings/${encodeURIComponent(tasting.id)}/book`;

  return layout({
    title: `Book ${tasting.title}`,
    body: `    <h1>Book ${escapeHtml(tasting.title)}</h1>
    <dl class="summary">
      <dt>Date and time</dt>
      <dd>${whenHtml(tasting.startsAt)}</dd>
      <dt>Price per guest</dt>
      <dd>${escapeHtml(formatEuros(tasting.priceCents))}</dd>
      <dt>Availability</dt>
      <dd>${escapeHtml(formatSeatsLeft(seatsLeft))}</dd>
    </dl>${alert}
    <form class="booking-form" method="post" action="${escapeHtml(action)}">
      <div class="field">
        <label for="name">Name</label>
        <input id="name" name="name" type="text" autocomplete="name" maxlength="100" required value="${escapeHtml(values.name)}"${describedBy('name')}>${fieldErrorHtml(errors, 'name')}
      </div>
      <div class="field">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" autocomplete="email" maxlength="254" required value="${escapeHtml(values.email)}"${describedBy('email')}>${fieldErrorHtml(errors, 'email')}
      </div>
      <div class="field">
        <label for="guests">Guests</label>
        <input id="guests" name="guests" type="number" inputmode="numeric" min="1" max="${MAX_GUESTS_PER_BOOKING}" step="1" required value="${escapeHtml(values.guests)}"${describedBy('guests')}>${fieldErrorHtml(errors, 'guests')}
      </div>
      <button class="button" type="submit">Book</button>
    </form>
    <p><a href="/">Back to all tastings</a></p>`,
  });
}

/**
 * @param {{ booking: { reference: string, guests: number, totalCents: number }, tasting: object }} page
 */
function confirmationPage({ booking, tasting }) {
  return layout({
    title: 'Booking confirmed',
    body: `    <h1>Booking confirmed</h1>
    <p>Thank you. We look forward to welcoming you. Please quote your booking reference on arrival.</p>
    <dl class="summary">
      <dt>Tasting</dt>
      <dd>${escapeHtml(tasting.title)}</dd>
      <dt>Date and time</dt>
      <dd>${whenHtml(tasting.startsAt)}</dd>
      <dt>Guests</dt>
      <dd>${escapeHtml(booking.guests)}</dd>
      <dt>Total price</dt>
      <dd>${escapeHtml(formatEuros(booking.totalCents))}</dd>
      <dt>Booking reference</dt>
      <dd class="reference">${escapeHtml(booking.reference)}</dd>
    </dl>
    <p><a href="/">Back to all tastings</a></p>`,
  });
}

/** @param {{ error?: string }} page */
function staffLoginPage({ error } = {}) {
  const alert = error ? `\n    <div class="alert" role="alert">${escapeHtml(error)}</div>` : '';
  return layout({
    title: 'Staff sign-in',
    body: `    <h1>Staff sign-in</h1>${alert}
    <form class="booking-form" method="post" action="/staff/login">
      <div class="field">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
      </div>
      <button class="button" type="submit">Sign in</button>
    </form>`,
  });
}

/**
 * @param {{
 *   listings: Array<{ tasting: object, bookings: Array<object>, seatsLeft: number }>,
 *   csrfToken: string,
 * }} page
 */
function staffBookingsPage({ listings, csrfToken }) {
  const sections = listings
    .map(({ tasting, bookings, seatsLeft }) => {
      const rows = bookings
        .map((booking) => `            <tr>
              <td>${escapeHtml(booking.name)}</td>
              <td>${escapeHtml(booking.email)}</td>
              <td>${escapeHtml(booking.guests)}</td>
              <td class="reference">${escapeHtml(booking.reference)}</td>
              <td>
                <form method="post" action="/staff/bookings/${encodeURIComponent(booking.reference)}/cancel">
                  <input type="hidden" name="_csrf" value="${escapeHtml(csrfToken)}">
                  <button class="button danger" type="submit">Cancel</button>
                </form>
              </td>
            </tr>`)
        .join('\n');
      const table = bookings.length === 0
        ? '      <p>No bookings yet.</p>'
        : `      <table>
        <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Guests</th>
            <th scope="col">Reference</th>
            <th scope="col"><span class="visually-hidden">Actions</span></th>
          </tr>
        </thead>
        <tbody>
${rows}
        </tbody>
      </table>`;

      return `    <section class="tasting-bookings" aria-labelledby="tasting-${escapeHtml(tasting.id)}">
      <h2 id="tasting-${escapeHtml(tasting.id)}">${escapeHtml(tasting.title)}</h2>
      <p>${whenHtml(tasting.startsAt)} &middot; ${escapeHtml(formatSeatsLeft(seatsLeft))}</p>
${table}
    </section>`;
    })
    .join('\n');

  return layout({
    title: 'Bookings',
    body: `    <h1>Bookings</h1>
${sections}`,
  });
}

module.exports = {
  escapeHtml,
  messagePage,
  tastingsPage,
  bookingFormPage,
  confirmationPage,
  staffLoginPage,
  staffBookingsPage,
};
