'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../src/app');
const { createBookingStore } = require('../src/bookings');
const { TASTINGS } = require('../src/tastings');

const STAFF_PASSWORD = 'correct horse battery staple';

/** Starts the app on an ephemeral port and returns a helper for requests against it. */
async function startApp(options = {}) {
  const store = options.store ?? createBookingStore(TASTINGS);
  const app = createApp({ staffPassword: STAFF_PASSWORD, ...options, store });
  const server = await new Promise((resolve) => {
    const listening = app.listen(0, '127.0.0.1', () => resolve(listening));
  });
  const { port } = server.address();
  const base = `http://127.0.0.1:${port}`;

  return {
    store,
    base,
    close: () => new Promise((resolve) => server.close(resolve)),
    get: (path, headers = {}) => fetch(base + path, { redirect: 'manual', headers }),
    post: (path, fields = {}, headers = {}) => fetch(base + path, {
      method: 'POST',
      redirect: 'manual',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...headers },
      body: new URLSearchParams(fields).toString(),
    }),
  };
}

/** Extracts "name=value" from the first Set-Cookie header, for sending back. */
function sessionCookieFrom(response) {
  const header = response.headers.getSetCookie().find((cookie) => cookie.startsWith('staff_session='));
  return header ? header.split(';')[0] : undefined;
}

async function signIn(app, password = STAFF_PASSWORD) {
  const response = await app.post('/staff/login', { password });
  return sessionCookieFrom(response);
}

function csrfTokenFrom(html) {
  const match = html.match(/name="_csrf" value="([^"]+)"/);
  assert.ok(match, 'staff page should contain a CSRF token');
  return match[1];
}

test('start page lists every tasting with its price and seats left', async () => {
  const app = await startApp();
  try {
    const response = await app.get('/');
    const html = await response.text();

    assert.equal(response.status, 200);
    for (const tasting of TASTINGS) {
      assert.match(html, new RegExp(`<h2>${tasting.title}</h2>`));
      assert.match(html, new RegExp(`Book ${tasting.title}`));
    }
    assert.match(html, /EUR 25\.00/);
    assert.match(html, /12 seats left/);
    assert.match(html, /8 seats left/);
    assert.match(html, /10 seats left/);
    assert.match(html, /6 November 2026, 18:00/);
  } finally {
    await app.close();
  }
});

test('seats left on the start page drop after a booking', async () => {
  const app = await startApp();
  try {
    await app.post('/tastings/winter-tasting/book', { name: 'Anna', email: 'anna@example.com', guests: '4' });

    const html = await (await app.get('/')).text();

    assert.match(html, /6 seats left/);
  } finally {
    await app.close();
  }
});

test('each booking link opens a form with Name, Email and Guests fields and a Book button', async () => {
  const app = await startApp();
  try {
    const response = await app.get('/tastings/riesling-evening/book');
    const html = await response.text();

    assert.equal(response.status, 200);
    assert.match(html, /<h1>Book Riesling Evening<\/h1>/);
    assert.match(html, /<label for="name">Name<\/label>/);
    assert.match(html, /<label for="email">Email<\/label>/);
    assert.match(html, /<label for="guests">Guests<\/label>/);
    assert.match(html, /<button class="button" type="submit">Book<\/button>/);
    assert.match(html, /name="guests"[^>]*min="1"[^>]*max="8"/);
  } finally {
    await app.close();
  }
});

test('an unknown tasting returns 404', async () => {
  const app = await startApp();
  try {
    assert.equal((await app.get('/tastings/nope/book')).status, 404);
    assert.equal((await app.post('/tastings/nope/book', {})).status, 404);
  } finally {
    await app.close();
  }
});

test('a valid booking redirects to a confirmation with heading, tasting, guests, total and reference', async () => {
  const app = await startApp();
  try {
    const submitted = await app.post('/tastings/red-wine-cellar-tour/book', {
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: '3',
    });
    assert.equal(submitted.status, 303);
    const location = submitted.headers.get('location');
    assert.match(location, /^\/bookings\/KB-[A-Z2-9]{6}$/);

    const response = await app.get(location);
    const html = await response.text();

    assert.equal(response.status, 200);
    assert.match(html, /<h1>Booking confirmed<\/h1>/);
    assert.match(html, /Red Wine Cellar Tour/);
    assert.match(html, /<dt>Guests<\/dt>\s*<dd>3<\/dd>/);
    assert.match(html, /EUR 96\.00/);
    assert.match(html, new RegExp(`<dd class="reference">${location.split('/').pop()}</dd>`));
    assert.equal(app.store.seatsLeft('red-wine-cellar-tour'), 5);
  } finally {
    await app.close();
  }
});

test('an unknown booking reference returns 404', async () => {
  const app = await startApp();
  try {
    assert.equal((await app.get('/bookings/KB-AAAAAA')).status, 404);
  } finally {
    await app.close();
  }
});

test('invalid input is rejected with messages next to the form and nothing is booked', async () => {
  const app = await startApp();
  try {
    const response = await app.post('/tastings/winter-tasting/book', {
      name: '',
      email: 'not-an-email',
      guests: '9',
    });
    const html = await response.text();

    assert.equal(response.status, 400);
    assert.match(html, /Please enter your name\./);
    assert.match(html, /Please enter a valid email address\./);
    assert.match(html, /Guests must be a whole number from 1 to 8\./);
    assert.match(html, /<h1>Book Winter Tasting<\/h1>/);
    assert.equal(app.store.seatsLeft('winter-tasting'), 10);
  } finally {
    await app.close();
  }
});

test('the form keeps what the guest typed when it is rejected', async () => {
  const app = await startApp();
  try {
    const html = await (await app.post('/tastings/winter-tasting/book', {
      name: 'Anna',
      email: 'bad',
      guests: '2',
    })).text();

    assert.match(html, /value="Anna"/);
    assert.match(html, /value="bad"/);
    assert.match(html, /value="2"/);
  } finally {
    await app.close();
  }
});

test('a booking cannot take more seats than are left', async () => {
  const app = await startApp();
  try {
    await app.post('/tastings/red-wine-cellar-tour/book', { name: 'First', email: 'first@example.com', guests: '6' });

    const response = await app.post('/tastings/red-wine-cellar-tour/book', {
      name: 'Second',
      email: 'second@example.com',
      guests: '3',
    });
    const html = await response.text();

    assert.equal(response.status, 400);
    assert.match(html, /Only 2 seats left for this tasting\./);
    assert.equal(app.store.seatsLeft('red-wine-cellar-tour'), 2);
  } finally {
    await app.close();
  }
});

test('a fully booked tasting rejects further bookings', async () => {
  const app = await startApp();
  try {
    await app.post('/tastings/red-wine-cellar-tour/book', { name: 'Full', email: 'full@example.com', guests: '8' });

    const html = await (await app.post('/tastings/red-wine-cellar-tour/book', {
      name: 'Late',
      email: 'late@example.com',
      guests: '1',
    })).text();

    assert.match(html, /This tasting is fully booked\./);
  } finally {
    await app.close();
  }
});

test('user input is HTML-escaped wherever it is shown', async () => {
  const app = await startApp();
  try {
    const attack = '<script>alert(1)</script>';
    const rejected = await (await app.post('/tastings/winter-tasting/book', {
      name: attack,
      email: `${attack}@example.com`,
      guests: '99',
    })).text();
    assert.doesNotMatch(rejected, /<script>alert/);
    assert.match(rejected, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);

    const submitted = await app.post('/tastings/winter-tasting/book', {
      name: attack,
      email: 'safe@example.com',
      guests: '1',
    });
    const confirmation = await (await app.get(submitted.headers.get('location'))).text();
    assert.doesNotMatch(confirmation, /<script>/);
  } finally {
    await app.close();
  }
});

test('staff page asks for the password when signed out', async () => {
  const app = await startApp();
  try {
    const response = await app.get('/staff');
    const html = await response.text();

    assert.equal(response.status, 200);
    assert.match(html, /<label for="password">Password<\/label>/);
    assert.match(html, /type="password"/);
    assert.match(html, /<button class="button" type="submit">Sign in<\/button>/);
    assert.equal(response.headers.get('cache-control'), 'no-store');
  } finally {
    await app.close();
  }
});

test('a wrong password does not sign staff in', async () => {
  const app = await startApp();
  try {
    const response = await app.post('/staff/login', { password: 'guess' });
    const html = await response.text();

    assert.equal(response.status, 401);
    assert.match(html, /Incorrect password\./);
    assert.equal(sessionCookieFrom(response), undefined);
  } finally {
    await app.close();
  }
});

test('sign-in is refused when STAFF_PASSWORD is not configured', async () => {
  const store = createBookingStore(TASTINGS);
  const app = await startApp({ store, staffPassword: undefined });
  try {
    const response = await app.post('/staff/login', { password: '' });

    assert.equal(response.status, 503);
    assert.match(await response.text(), /Staff sign-in is not available right now\./);
  } finally {
    await app.close();
  }
});

test('signed-in staff see bookings grouped by tasting with name, email, guests and reference', async () => {
  const app = await startApp();
  try {
    const booking = app.store.addBooking({
      tastingId: 'riesling-evening',
      name: 'Hannah Weber',
      email: 'hannah@example.com',
      guests: 4,
    });
    const cookie = await signIn(app);

    const response = await app.get('/staff', { Cookie: cookie });
    const html = await response.text();

    assert.equal(response.status, 200);
    assert.match(html, /<h1>Bookings<\/h1>/);
    assert.match(html, /<h2 id="tasting-riesling-evening">Riesling Evening<\/h2>/);
    assert.match(html, /Hannah Weber/);
    assert.match(html, /hannah@example\.com/);
    assert.ok(html.includes(booking.reference));
    assert.match(html, /<button class="button danger" type="submit">Cancel<\/button>/);
    assert.match(html, /<p>No bookings yet\.<\/p>/);
  } finally {
    await app.close();
  }
});

test('a staff cookie is HttpOnly and SameSite=Strict and limited to /staff', async () => {
  const app = await startApp();
  try {
    const response = await app.post('/staff/login', { password: STAFF_PASSWORD });
    const header = response.headers.getSetCookie().find((cookie) => cookie.startsWith('staff_session='));

    assert.equal(response.status, 303);
    assert.equal(response.headers.get('location'), '/staff');
    assert.match(header, /; Path=\/staff/);
    assert.match(header, /; HttpOnly/);
    assert.match(header, /; SameSite=Strict/);
  } finally {
    await app.close();
  }
});

test('cancelling a booking as staff frees its seats', async () => {
  const app = await startApp();
  try {
    const booking = app.store.addBooking({
      tastingId: 'winter-tasting',
      name: 'Jonas',
      email: 'jonas@example.com',
      guests: 7,
    });
    const cookie = await signIn(app);
    const page = await (await app.get('/staff', { Cookie: cookie })).text();

    const response = await app.post(
      `/staff/bookings/${booking.reference}/cancel`,
      { _csrf: csrfTokenFrom(page) },
      { Cookie: cookie },
    );

    assert.equal(response.status, 303);
    assert.equal(response.headers.get('location'), '/staff');
    assert.equal(app.store.seatsLeft('winter-tasting'), 10);
    assert.equal(app.store.findByReference(booking.reference), undefined);
    assert.equal((await app.get(`/bookings/${booking.reference}`)).status, 404);
  } finally {
    await app.close();
  }
});

test('cancelling without the CSRF token is rejected and keeps the booking', async () => {
  const app = await startApp();
  try {
    const booking = app.store.addBooking({
      tastingId: 'winter-tasting',
      name: 'Jonas',
      email: 'jonas@example.com',
      guests: 2,
    });
    const cookie = await signIn(app);

    const response = await app.post(`/staff/bookings/${booking.reference}/cancel`, {}, { Cookie: cookie });

    assert.equal(response.status, 403);
    assert.ok(app.store.findByReference(booking.reference));
  } finally {
    await app.close();
  }
});

test('cancelling is refused without a staff session', async () => {
  const app = await startApp();
  try {
    const booking = app.store.addBooking({
      tastingId: 'winter-tasting',
      name: 'Jonas',
      email: 'jonas@example.com',
      guests: 2,
    });

    const response = await app.post(`/staff/bookings/${booking.reference}/cancel`, { _csrf: 'anything' });

    assert.equal(response.status, 303);
    assert.equal(response.headers.get('location'), '/staff');
    assert.ok(app.store.findByReference(booking.reference));
  } finally {
    await app.close();
  }
});

test('a forged staff cookie does not reveal the bookings page', async () => {
  const app = await startApp();
  try {
    const response = await app.get('/staff', { Cookie: 'staff_session=forged-token' });
    const html = await response.text();

    assert.match(html, /<h1>Staff sign-in<\/h1>/);
    assert.doesNotMatch(html, /<h1>Bookings<\/h1>/);
  } finally {
    await app.close();
  }
});

test('repeated failed sign-ins are rate limited', async () => {
  const app = await startApp();
  try {
    let last;
    for (let attempt = 0; attempt < 11; attempt += 1) {
      last = await app.post('/staff/login', { password: 'wrong' });
    }

    assert.equal(last.status, 429);
    assert.match(await last.text(), /Too many sign-in attempts/);
  } finally {
    await app.close();
  }
});

test('security headers are sent on pages', async () => {
  const app = await startApp();
  try {
    const response = await app.get('/');

    assert.match(response.headers.get('content-security-policy'), /default-src 'self'/);
    assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(response.headers.get('x-frame-options'), 'DENY');
    assert.match(response.headers.get('permissions-policy'), /camera=\(\)/);
    assert.equal(response.headers.get('x-powered-by'), null);
  } finally {
    await app.close();
  }
});

test('the stylesheet is served from /styles.css', async () => {
  const app = await startApp();
  try {
    const response = await app.get('/styles.css');

    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type'), /text\/css/);
  } finally {
    await app.close();
  }
});

test('unknown pages return a 404 page', async () => {
  const app = await startApp();
  try {
    const response = await app.get('/does-not-exist');

    assert.equal(response.status, 404);
    assert.match(await response.text(), /Page not found/);
  } finally {
    await app.close();
  }
});
