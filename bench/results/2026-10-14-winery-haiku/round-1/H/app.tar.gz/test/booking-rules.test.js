'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { validateBooking } = require('../src/booking-rules');

const VALID_INPUT = { name: 'Anna Keller', email: 'anna@example.com', guests: '2' };

test('accepts valid input and returns normalised data', () => {
  // Arrange
  const input = { name: '  Anna Keller  ', email: ' anna@example.com ', guests: '2' };

  // Act
  const result = validateBooking(input, 5);

  // Assert
  assert.deepEqual(result.errors, {});
  assert.deepEqual(result.data, { name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
});

test('rejects a missing name and a missing email', () => {
  const result = validateBooking({ ...VALID_INPUT, name: '   ', email: '' }, 5);

  assert.equal(result.data, null);
  assert.equal(result.errors.name, 'Please enter your name.');
  assert.equal(result.errors.email, 'Please enter your email address.');
});

test('rejects a name longer than 100 characters', () => {
  const result = validateBooking({ ...VALID_INPUT, name: 'x'.repeat(101) }, 5);

  assert.equal(result.errors.name, 'Name must be at most 100 characters.');
});

test('rejects malformed email addresses', () => {
  for (const email of ['anna', 'anna@', '@example.com', 'anna@example', 'a b@example.com']) {
    const result = validateBooking({ ...VALID_INPUT, email }, 5);

    assert.equal(result.errors.email, 'Please enter a valid email address.', email);
  }
});

test('rejects guest counts that are not whole numbers from 1 to 8', () => {
  for (const guests of ['', '0', '9', '-1', '2.5', 'two', '1e1', '']) {
    const result = validateBooking({ ...VALID_INPUT, guests }, 12);

    assert.equal(result.errors.guests, 'Guests must be a whole number from 1 to 8.', `guests=${guests}`);
  }
});

test('accepts the boundaries 1 and 8 when enough seats are left', () => {
  assert.deepEqual(validateBooking({ ...VALID_INPUT, guests: '1' }, 8).data.guests, 1);
  assert.deepEqual(validateBooking({ ...VALID_INPUT, guests: '8' }, 8).data.guests, 8);
});

test('rejects more guests than seats left and names the seats left', () => {
  const result = validateBooking({ ...VALID_INPUT, guests: '4' }, 3);

  assert.equal(result.data, null);
  assert.equal(result.errors.guests, 'Only 3 seats left for this tasting.');
});

test('uses singular wording when one seat is left', () => {
  const result = validateBooking({ ...VALID_INPUT, guests: '2' }, 1);

  assert.equal(result.errors.guests, 'Only 1 seat left for this tasting.');
});

test('reports a fully booked tasting when no seats are left', () => {
  const result = validateBooking({ ...VALID_INPUT, guests: '1' }, 0);

  assert.equal(result.errors.guests, 'This tasting is fully booked.');
});

test('treats missing or non-string fields as empty', () => {
  const result = validateBooking({ name: ['a', 'b'], email: undefined }, 5);

  assert.equal(result.errors.name, 'Please enter your name.');
  assert.equal(result.errors.email, 'Please enter your email address.');
  assert.equal(result.errors.guests, 'Guests must be a whole number from 1 to 8.');
});

test('keeps the raw values so the form can be redisplayed', () => {
  const result = validateBooking({ name: ' Anna ', email: 'bad', guests: '9' }, 5);

  assert.deepEqual(result.values, { name: 'Anna', email: 'bad', guests: '9' });
});
