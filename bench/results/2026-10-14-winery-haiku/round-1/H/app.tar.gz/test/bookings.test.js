'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { createBookingStore } = require('../src/bookings');

const TASTINGS = [
  { id: 'small', title: 'Small', startsAt: '2026-11-06 18:00', priceCents: 2500, seats: 8 },
  { id: 'large', title: 'Large', startsAt: '2026-12-05 17:00', priceCents: 2800, seats: 10 },
];

function bookingFor(tastingId, guests, name = 'Anna') {
  return { tastingId, name, email: 'anna@example.com', guests };
}

test('a new store has every seat free', () => {
  const store = createBookingStore(TASTINGS);

  assert.equal(store.seatsLeft('small'), 8);
  assert.equal(store.seatsLeft('large'), 10);
});

test('seatsLeft throws for an unknown tasting', () => {
  const store = createBookingStore(TASTINGS);

  assert.throws(() => store.seatsLeft('nope'), /Unknown tasting/);
});

test('addBooking reduces the seats left and returns the total price', () => {
  const store = createBookingStore(TASTINGS);

  const booking = store.addBooking(bookingFor('small', 3));

  assert.equal(store.seatsLeft('small'), 5);
  assert.equal(booking.totalCents, 7500);
  assert.equal(booking.guests, 3);
  assert.equal(store.findByReference(booking.reference), booking);
});

test('addBooking refuses more guests than seats left', () => {
  const store = createBookingStore(TASTINGS);
  store.addBooking(bookingFor('small', 6));

  assert.throws(() => store.addBooking(bookingFor('small', 3)), /seats left/);
  assert.equal(store.seatsLeft('small'), 2);
});

test('addBooking refuses a booking once the tasting is full', () => {
  const store = createBookingStore(TASTINGS);
  store.addBooking(bookingFor('small', 8));

  assert.throws(() => store.addBooking(bookingFor('small', 1)), /seats left/);
});

test('each booking gets a unique reference of the form KB-XXXXXX', () => {
  const store = createBookingStore([{ id: 'big', priceCents: 100, seats: 50 }]);

  const references = new Set();
  for (let i = 0; i < 50; i += 1) {
    references.add(store.addBooking(bookingFor('big', 1)).reference);
  }

  assert.equal(references.size, 50);
  for (const reference of references) {
    assert.match(reference, /^KB-[A-HJ-NP-Z2-9]{6}$/);
  }
});

test('cancel frees the seats and removes the booking', () => {
  const store = createBookingStore(TASTINGS);
  const booking = store.addBooking(bookingFor('small', 5));

  assert.equal(store.cancel(booking.reference), true);

  assert.equal(store.seatsLeft('small'), 8);
  assert.equal(store.findByReference(booking.reference), undefined);
});

test('cancel returns false for an unknown reference', () => {
  const store = createBookingStore(TASTINGS);

  assert.equal(store.cancel('KB-000000'), false);
});

test('listByTasting groups bookings under their tasting in booking order', () => {
  const store = createBookingStore(TASTINGS);
  const first = store.addBooking(bookingFor('large', 2, 'First'));
  const second = store.addBooking(bookingFor('large', 4, 'Second'));

  const groups = store.listByTasting();

  assert.deepEqual(groups.map((group) => group.tasting.id), ['small', 'large']);
  assert.deepEqual(groups[0].bookings, []);
  assert.deepEqual(groups[1].bookings.map((b) => b.reference), [first.reference, second.reference]);
  assert.equal(groups[1].seatsLeft, 4);
});
