# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online. Staff sign in to see and cancel bookings.
The product spec and the decisions behind it are in [docs/SPEC.md](docs/SPEC.md).

## Run it

Requires Node.js 22.

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' PORT=3000 npm start
```

Open http://localhost:3000. Staff sign-in is at http://localhost:3000/staff.

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | `3000` | Port the server listens on |
| `STAFF_PASSWORD` | none | Password for `/staff`. If unset, staff sign-in is disabled and the server logs a warning |

Bookings are kept in memory. The app starts with none, and a restart clears them
and signs staff out.

## Develop

```sh
npm run dev:api   # API on PORT (default 3000), reloads on change
npm run dev       # Vite dev server on http://localhost:5173, proxies /api to the API
```

## Test

```sh
npm run typecheck   # TypeScript, client and server
npm test            # Unit and API tests (Vitest)
npm run test:e2e    # Browser tests (Playwright); builds and starts the app on port 3101
```

The end-to-end tests need a Chromium: `npx playwright install chromium`. On a
container without the browser's system libraries or any fonts, the page renders no
text. Install the libraries and a font package first.

## Layout

```
src/shared/       rules and types used by both sides (booking validation with zod)
src/server/       Express app: JSON API, staff session, booking book, catalogue
src/client/       React app: routes and loaders (React Router), pages, forms (react-hook-form)
tests/server/     API tests (supertest)
tests/shared/     validation rules
tests/client/     form and page tests (Testing Library)
tests/e2e/        full guest and staff journey (Playwright)
```

Tastings are defined in `src/server/catalogue.ts`.
