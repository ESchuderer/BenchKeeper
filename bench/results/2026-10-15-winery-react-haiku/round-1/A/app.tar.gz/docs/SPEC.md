# Weingut Kieselbrunnen: tasting bookings

A small web app for the winery. Guests book wine tastings online; staff sign in
to see and cancel bookings.

## Scope

- Guest pages: tasting list, booking form, booking confirmation.
- Staff page: password sign-in, bookings grouped by tasting, cancel a booking.
- Single Node process. One server serves the JSON API and the built React app.
- Interface language: English.

## Tastings (fixed catalogue)

| id | Title | Date and time (local) | Price per guest | Seats |
|---|---|---|---|---|
| `riesling-evening` | Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| `red-wine-cellar-tour` | Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| `winter-tasting` | Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

Date and time are winery-local wall-clock values. They are displayed as written,
with no time zone conversion.

## Decisions

| Area | Choice | Why |
|---|---|---|
| Server | Express 5, TypeScript, compiled with `tsc` | Established, handles async errors, one process serves API and SPA |
| UI | React 19, React Router 7, Vite build | Requested React; Vite gives a small static build |
| Forms | react-hook-form with a zod resolver | Established forms library; same zod schema validates on server |
| Validation | zod schemas in `src/shared`, used by client and server | One definition of the rules, so the client's messages match the server's |
| Styling | Tailwind CSS 4 | Utility classes, responsive by default |
| Fonts | `@fontsource-variable` packages, self-hosted | No external requests at runtime |
| Storage | In memory | Spec allows it. The app starts with no bookings. Restarting clears bookings (known limitation) |
| Staff session | `cookie-session` holds an opaque session id. The id maps to a sign-in time in server memory | Sign-out and the 12-hour limit are enforced on the server, so a copied cookie stops working. A restart signs staff out |
| Sign-in protection | `express-rate-limit` on the sign-in endpoint | Limits password guessing |
| Headers | `helmet` | Standard security headers |
| Booking reference | `KB-` plus 6 characters from `ABCDEFGHJKMNPQRSTUVWXYZ23456789` | Easy to read aloud; no ambiguous `0/O` or `1/I/L` |
| Staff password unset | Sign-in returns 503 "not configured" and a warning is logged at start | Fails closed; the server still starts so guests can book |
| CSRF | State-changing endpoints accept only JSON bodies; cookie is `SameSite=Lax` | Cross-site forms cannot send `application/json` without a CORS preflight, which this app does not allow |
| Cancel | Booking is removed; its seats return to the pool. No confirmation step | Matches "a Cancel button". Staff can re-book if needed |
| Seats wording | "1 seat left", "N seats left" otherwise | Correct English for singular |
| Price wording | "EUR 25" per guest; total "EUR 50" | Matches the brief; all prices are whole euros |

## API

All bodies and responses are JSON. Errors use `{ "message": string }`, or
`{ "errors": { "<field>": string } }` for validation problems.

| Method | Path | Success | Errors |
|---|---|---|---|
| GET | `/api/tastings` | 200 `Tasting[]` | |
| GET | `/api/tastings/:id` | 200 `Tasting` | 404 |
| POST | `/api/tastings/:id/bookings` body `{name,email,guests}` | 201 `Confirmation` | 400 `errors` (invalid input, or more guests than seats left), 404 |
| GET | `/api/bookings/:reference` | 200 `Confirmation` | 404 |
| POST | `/api/staff/session` body `{password}` | 200 `{authenticated:true}` | 400 (no password), 401, 429, 503 |
| GET | `/api/staff/session` | 200 `{authenticated}` | |
| DELETE | `/api/staff/session` | 204 | |
| GET | `/api/staff/bookings` | 200 `{tastings: StaffTasting[]}` | 401 |
| DELETE | `/api/staff/bookings/:reference` | 204 | 401, 404 |

Types:

- `Tasting`: `{ id, title, dateTime, pricePerGuest, seats, seatsLeft }`
- `Confirmation`: `{ reference, guests, totalPrice, tasting: { id, title, dateTime, pricePerGuest } }`
- `StaffTasting`: `{ id, title, dateTime, seats, seatsLeft, bookings: { reference, name, email, guests }[] }`

The public confirmation omits the guest's name and email.

## Booking rules

- Name: required, trimmed, at most 100 characters.
- Email: required, trimmed, valid email format, at most 254 characters.
- Guests: whole number from 1 to 8. Must not exceed the seats left.
  - Empty or not a number: "Enter the number of guests (1 to 8)".
  - Outside 1 to 8: "Guests must be between 1 and 8".
  - More than seats left: "Only N seat(s) left".
- A tasting with 0 seats left shows "Fully booked" on the list. The booking form is not offered,
  and the API rejects any booking with "This tasting is fully booked" on Guests.
- The server is authoritative. The client runs the same schema with the current seats left, so
  the user sees the error before submitting.
- Seats are checked and reserved in one synchronous step on the server, so two bookings
  cannot oversell a tasting.

## Pages

| Route | Page |
|---|---|
| `/` | Tasting list. Each card: title, date and time, price per guest, "N seats left". Button "Book <title>" or "Fully booked" |
| `/tastings/:id/book` | Booking form. Fields "Name", "Email", "Guests". Button "Book" |
| `/bookings/:reference` | Confirmation: heading "Booking confirmed", tasting, guests, total price, reference |
| `/staff` | Sign-in form ("Password", "Sign in") or, when signed in, bookings grouped by tasting with "Cancel" |

Unknown routes show a "Page not found" message with a link back to the tastings.

## Acceptance criteria

1. Start page lists all three tastings with title, date and time, price per guest, and seats left.
2. Each tasting has a link "Book <title>" that opens its booking form.
3. Booking form has "Name", "Email", "Guests" (1 to 8) and "Book". Invalid input shows an error
   next to the field.
4. A booking is rejected if it needs more seats than are left. The error is shown on Guests.
5. A successful booking shows "Booking confirmed" with the tasting, guests, total price and reference.
6. `/staff` requires the `STAFF_PASSWORD` password. A wrong password is rejected.
7. Signed in, staff see every booking grouped by tasting with name, email, guests and reference.
8. "Cancel" removes the booking and frees its seats immediately.
9. A fully booked tasting is clearly marked and cannot be booked.
10. Layout works on a phone-width screen (360 px) and on desktop.
11. `npm install`, `npm run build`, `npm start` run in the dev container on Node 22.
    The server listens on `PORT` (default 3000).
12. The app starts with no bookings.
