import { defineConfig, devices } from '@playwright/test';

const PORT = 3101;

export default defineConfig({
  testDir: 'tests/e2e',
  // All specs share one in-memory server, so they run one after another.
  workers: 1,
  reporter: 'list',
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: 'retain-on-failure',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'npm run build && npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    reuseExistingServer: false,
    timeout: 120_000,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-password' },
  },
});
