import type { BookingInput } from '../shared/booking-schema.js';
import type { Confirmation, ErrorBody, StaffTasting, Tasting } from '../shared/types.js';

export class ApiError extends Error {
  readonly status: number;
  readonly body: ErrorBody;

  constructor(status: number, body: ErrorBody) {
    super(body.message ?? `Request failed with status ${status}`);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (init.body !== undefined) headers['Content-Type'] = 'application/json';

  const res = await fetch(path, { ...init, headers, credentials: 'same-origin' });
  if (res.status === 204) return undefined as T;

  const body = (await res.json().catch(() => ({}))) as ErrorBody & T;
  if (!res.ok) throw new ApiError(res.status, body);
  return body;
}

const json = (value: unknown) => JSON.stringify(value);

export const api = {
  listTastings: () => request<Tasting[]>('/api/tastings'),

  getTasting: (id: string) => request<Tasting>(`/api/tastings/${encodeURIComponent(id)}`),

  createBooking: (tastingId: string, input: BookingInput) =>
    request<Confirmation>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
      method: 'POST',
      body: json(input),
    }),

  getConfirmation: (reference: string) =>
    request<Confirmation>(`/api/bookings/${encodeURIComponent(reference)}`),

  staffSession: () => request<{ authenticated: boolean }>('/api/staff/session'),

  signIn: (password: string) =>
    request<{ authenticated: boolean }>('/api/staff/session', {
      method: 'POST',
      body: json({ password }),
    }),

  signOut: () => request<void>('/api/staff/session', { method: 'DELETE' }),

  staffBookings: () => request<{ tastings: StaffTasting[] }>('/api/staff/bookings'),

  cancelBooking: (reference: string) =>
    request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, {
      method: 'DELETE',
    }),
};
