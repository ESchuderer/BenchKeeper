import type { ReactNode } from 'react';
import { Link, Outlet } from 'react-router';

export function Layout({ children }: { children?: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-md focus:bg-paper focus:px-4 focus:py-2 focus:text-ink focus:shadow-lg"
      >
        Skip to content
      </a>

      <header className="bg-wine text-cream">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-x-6 gap-y-3 px-5 py-6 sm:px-8">
          <Link to="/" className="group flex flex-col no-underline">
            <span className="font-display text-3xl leading-none font-semibold tracking-tight group-hover:text-gold-light">
              Weingut Kieselbrunnen
            </span>
            <span className="mt-1 text-xs tracking-[0.2em] text-gold-light uppercase">
              Family winery
            </span>
          </Link>
          <nav aria-label="Main" className="flex gap-6 text-sm font-medium">
            <Link to="/" className="text-cream/90 hover:text-cream">
              Tastings
            </Link>
          </nav>
        </div>
        <div aria-hidden="true" className="h-1 bg-gold" />
      </header>

      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-5 py-10 sm:px-8 sm:py-14">
        {children ?? <Outlet />}
      </main>

      <footer className="border-t border-line bg-paper/70">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-5 py-6 text-sm text-muted sm:px-8">
          <p className="font-display text-base text-ink">Weingut Kieselbrunnen</p>
          <Link to="/staff" className="text-wine underline-offset-4 hover:underline">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}
