import { Link } from 'react-router';
import type { Tasting } from '../../shared/types.js';
import { formatDate, formatPrice, formatTime, seatsLeftLabel } from '../format.js';

/** Seats below this count are highlighted, so guests know to book soon. */
const FEW_SEATS = 3;

export function TastingCard({ tasting }: { tasting: Tasting }) {
  const { id, title, dateTime, pricePerGuest, seatsLeft } = tasting;
  const titleId = `tasting-${id}`;
  const soldOut = seatsLeft === 0;

  return (
    <article
      aria-labelledby={titleId}
      className={`flex h-full flex-col rounded-xl border border-line border-t-4 bg-paper p-6 shadow-sm ${
        soldOut ? 'border-t-muted/50' : 'border-t-gold'
      }`}
    >
      <p className="text-sm font-medium text-gold-deep">{formatDate(dateTime)}</p>
      <p className="text-sm text-muted">
        <span>{formatTime(dateTime)}</span>
      </p>

      <h2 id={titleId} className="mt-3 font-display text-3xl leading-tight font-semibold text-wine">
        {title}
      </h2>

      <p className="mt-4 text-base text-ink">
        <span className="font-semibold">{formatPrice(pricePerGuest)}</span>{' '}
        <span className="text-muted">per guest</span>
      </p>

      <div className="mt-2 flex flex-wrap items-center gap-2">
        <p className={`text-sm ${soldOut ? 'text-muted' : 'text-ink'}`}>
          {seatsLeftLabel(seatsLeft)}
        </p>
        {!soldOut && seatsLeft <= FEW_SEATS && (
          <span className="rounded-full bg-warn-soft px-2.5 py-0.5 text-xs font-semibold text-warn">
            Few seats left
          </span>
        )}
      </div>

      <div className="mt-auto pt-6">
        {soldOut ? (
          <span className="inline-flex items-center rounded-md border border-muted/40 bg-stone px-4 py-2.5 text-sm font-semibold tracking-wide text-muted uppercase">
            Fully booked
          </span>
        ) : (
          <Link
            to={`/tastings/${id}/book`}
            className="inline-flex items-center rounded-md bg-wine px-5 py-2.5 text-sm font-semibold text-cream no-underline transition hover:bg-wine-deep"
          >
            Book {title}
          </Link>
        )}
      </div>
    </article>
  );
}
