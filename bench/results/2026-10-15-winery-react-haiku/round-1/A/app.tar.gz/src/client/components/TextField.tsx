import type { InputHTMLAttributes } from 'react';
import type { UseFormRegisterReturn } from 'react-hook-form';

interface TextFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'name'> {
  id: string;
  label: string;
  /** From react-hook-form's register(). */
  field: UseFormRegisterReturn;
  error?: string;
  hint?: string;
}

/** A labelled input. Its error (or hint) is linked to it with aria-describedby. */
export function TextField({ id, label, field, error, hint, ...inputProps }: TextFieldProps) {
  const messageId = `${id}-message`;
  const message = error ?? hint;

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium text-ink">
        {label}
      </label>
      <input
        id={id}
        {...inputProps}
        {...field}
        aria-invalid={error ? true : undefined}
        aria-describedby={message ? messageId : undefined}
        className={`w-full rounded-md border bg-paper px-3.5 py-2.5 text-base text-ink placeholder:text-muted/70 transition outline-none focus:border-wine focus:ring-3 focus:ring-wine/20 ${
          error ? 'border-danger bg-danger-soft' : 'border-line'
        }`}
      />
      {message && (
        <p id={messageId} className={`text-sm ${error ? 'font-medium text-danger' : 'text-muted'}`}>
          {message}
        </p>
      )}
    </div>
  );
}
