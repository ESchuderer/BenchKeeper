/** Prices are whole euros, shown as "EUR 25". */
export function formatPrice(amount: number): string {
  return `EUR ${amount}`;
}

export function seatsLeftLabel(seatsLeft: number): string {
  return seatsLeft === 1 ? '1 seat left' : `${seatsLeft} seats left`;
}

/**
 * Formats a winery-local value such as "2026-11-06T18:00" as shown on the wall clock.
 * Parsed as UTC and formatted as UTC, so no time zone of the viewer shifts it.
 */
export function formatDate(dateTime: string): string {
  const date = new Date(`${dateTime}:00Z`);
  return new Intl.DateTimeFormat('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(date);
}

export function formatTime(dateTime: string): string {
  return dateTime.slice(11, 16);
}
