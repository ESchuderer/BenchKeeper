import { useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useLoaderData, useNavigate, Link } from 'react-router';
import { zodResolver } from '@hookform/resolvers/zod';
import { api, ApiError } from '../api.js';
import { TextField } from '../components/TextField.js';
import { MAX_GUESTS, bookingSchema, type BookingInput } from '../../shared/booking-schema.js';
import type { Tasting } from '../../shared/types.js';
import { formatDate, formatPrice, formatTime, seatsLeftLabel } from '../format.js';

export function BookingPage() {
  const tasting = useLoaderData() as Tasting;

  return (
    <div className="grid gap-10 md:grid-cols-[1fr_1.1fr] md:gap-14">
      <section className="flex flex-col gap-4">
        <Link to="/" className="text-sm font-medium text-wine underline-offset-4 hover:underline">
          ← All tastings
        </Link>
        <p className="mt-2 text-sm font-medium text-gold-deep">
          {formatDate(tasting.dateTime)} · {formatTime(tasting.dateTime)}
        </p>
        <h1 className="font-display text-5xl leading-[1.05] font-semibold text-wine">
          {tasting.title}
        </h1>
        <p className="text-base text-ink">
          <span className="font-semibold">{formatPrice(tasting.pricePerGuest)}</span>{' '}
          <span className="text-muted">per guest</span>
        </p>
        <p className="text-base text-ink">{seatsLeftLabel(tasting.seatsLeft)}</p>
      </section>

      <section className="rounded-xl border border-line bg-paper p-6 shadow-sm sm:p-8">
        {tasting.seatsLeft === 0 ? (
          <div className="flex flex-col gap-3">
            <h2 className="font-display text-3xl font-semibold text-wine">Fully booked</h2>
            <p className="text-ink/80">
              All places for this tasting are taken. Please choose another date.
            </p>
          </div>
        ) : (
          <BookingForm tasting={tasting} />
        )}
      </section>
    </div>
  );
}

function BookingForm({ tasting }: { tasting: Tasting }) {
  const navigate = useNavigate();
  const [submitError, setSubmitError] = useState<string>();
  const schema = useMemo(() => bookingSchema(tasting.seatsLeft), [tasting.seatsLeft]);

  const {
    register,
    handleSubmit,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(schema),
    defaultValues: { name: '', email: '', guests: 1 },
    mode: 'onTouched',
  });

  const guests = watch('guests');
  const guestCount = Number.isInteger(guests) ? guests : 0;
  const maxGuests = Math.min(MAX_GUESTS, tasting.seatsLeft);

  const onSubmit = async (values: BookingInput) => {
    setSubmitError(undefined);
    try {
      const confirmation = await api.createBooking(tasting.id, values);
      navigate(`/bookings/${confirmation.reference}`);
    } catch (error) {
      if (error instanceof ApiError && error.status === 400 && error.body.errors) {
        for (const [field, message] of Object.entries(error.body.errors)) {
          setError(field as keyof BookingInput, { message });
        }
        return;
      }
      setSubmitError('We could not complete your booking. Please try again.');
    }
  };

  return (
    <form noValidate onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6">
      <h2 className="font-display text-3xl font-semibold text-wine">Your details</h2>

      <TextField
        id="name"
        label="Name"
        autoComplete="name"
        field={register('name')}
        error={errors.name?.message}
      />
      <TextField
        id="email"
        label="Email"
        type="email"
        inputMode="email"
        autoComplete="email"
        field={register('email')}
        error={errors.email?.message}
      />
      <TextField
        id="guests"
        label="Guests"
        type="number"
        inputMode="numeric"
        min={1}
        max={maxGuests}
        step={1}
        field={register('guests', { valueAsNumber: true })}
        error={errors.guests?.message}
        hint={`1 to ${MAX_GUESTS} guests. ${seatsLeftLabel(tasting.seatsLeft)}.`}
      />

      <div className="flex items-baseline justify-between gap-4 border-t border-line pt-5">
        <span className="text-sm text-muted">Total</span>
        <span className="font-display text-3xl font-semibold text-wine">
          {guestCount > 0 ? formatPrice(guestCount * tasting.pricePerGuest) : '—'}
        </span>
      </div>

      {submitError && (
        <p role="alert" className="rounded-md bg-danger-soft px-4 py-3 text-sm font-medium text-danger">
          {submitError}
        </p>
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="inline-flex items-center justify-center rounded-md bg-wine px-6 py-3 text-base font-semibold text-cream transition hover:bg-wine-deep disabled:cursor-wait disabled:opacity-70"
      >
        Book
      </button>
    </form>
  );
}
