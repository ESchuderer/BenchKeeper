import { useLoaderData, Link } from 'react-router';
import type { Confirmation } from '../../shared/types.js';
import { formatDate, formatPrice, formatTime } from '../format.js';

export function ConfirmationPage() {
  const confirmation = useLoaderData() as Confirmation;
  const { tasting, guests, totalPrice, reference } = confirmation;

  return (
    <section className="mx-auto max-w-2xl">
      <div className="rounded-xl border border-line border-t-4 border-t-success bg-paper p-6 shadow-sm sm:p-10">
        <p className="text-sm font-semibold tracking-[0.2em] text-success uppercase">
          Thank you
        </p>
        <h1 className="mt-3 font-display text-5xl leading-[1.05] font-semibold text-wine">
          Booking confirmed
        </h1>

        <dl className="mt-8 grid gap-x-8 gap-y-5 border-y border-line py-7 sm:grid-cols-2">
          <div>
            <dt className="text-sm text-muted">Tasting</dt>
            <dd className="mt-1 font-display text-2xl font-semibold text-ink">{tasting.title}</dd>
          </div>
          <div>
            <dt className="text-sm text-muted">Date and time</dt>
            <dd className="mt-1 text-base text-ink">
              {formatDate(tasting.dateTime)}, {formatTime(tasting.dateTime)}
            </dd>
          </div>
          <div>
            <dt className="text-sm text-muted">Guests</dt>
            <dd className="mt-1 text-base text-ink">{guests}</dd>
          </div>
          <div>
            <dt className="text-sm text-muted">Total price</dt>
            <dd className="mt-1 text-base font-semibold text-ink">{formatPrice(totalPrice)}</dd>
          </div>
        </dl>

        <div className="mt-7 rounded-lg bg-cream p-5">
          <p className="text-sm text-muted">Booking reference</p>
          <p className="mt-1 font-mono text-2xl font-semibold tracking-widest text-wine">
            {reference}
          </p>
          <p className="mt-2 text-sm text-ink/70">Please keep this reference for your records.</p>
        </div>
      </div>

      <div className="mt-8">
        <Link to="/" className="text-sm font-medium text-wine underline-offset-4 hover:underline">
          ← Back to all tastings
        </Link>
      </div>
    </section>
  );
}
