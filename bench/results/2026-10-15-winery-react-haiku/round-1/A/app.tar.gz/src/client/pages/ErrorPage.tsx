import { isRouteErrorResponse, Link, useRouteError } from 'react-router';
import { NotFoundPage } from './NotFoundPage.js';

export function ErrorPage() {
  const error = useRouteError();
  if (isRouteErrorResponse(error) && error.status === 404) return <NotFoundPage />;

  return (
    <section className="mx-auto max-w-xl text-center">
      <h1 className="font-display text-4xl font-semibold text-wine">Something went wrong</h1>
      <p className="mt-4 text-ink/80">Please try again in a moment.</p>
      <Link to="/" className="mt-8 inline-block text-sm font-medium text-wine underline-offset-4 hover:underline">
        Back to the tastings
      </Link>
    </section>
  );
}
