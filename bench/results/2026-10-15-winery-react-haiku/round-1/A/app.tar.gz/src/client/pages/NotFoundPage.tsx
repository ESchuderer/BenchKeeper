import { Link } from 'react-router';

export function NotFoundPage() {
  return (
    <section className="mx-auto max-w-xl text-center">
      <p className="font-display text-7xl font-semibold text-gold">404</p>
      <h1 className="mt-2 font-display text-4xl font-semibold text-wine">Page not found</h1>
      <p className="mt-4 text-ink/80">The page you are looking for does not exist or has moved.</p>
      <Link
        to="/"
        className="mt-8 inline-flex rounded-md bg-wine px-5 py-2.5 text-sm font-semibold text-cream no-underline hover:bg-wine-deep"
      >
        See the tastings
      </Link>
    </section>
  );
}
