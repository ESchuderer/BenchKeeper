import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useLoaderData, useRevalidator } from 'react-router';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { api, ApiError } from '../api.js';
import { TextField } from '../components/TextField.js';
import type { StaffTasting } from '../../shared/types.js';
import { formatDate, formatTime, seatsLeftLabel } from '../format.js';

export type StaffData =
  | { authenticated: false }
  | { authenticated: true; tastings: StaffTasting[] };

export function StaffPage() {
  const data = useLoaderData() as StaffData;
  return data.authenticated ? <StaffBookings tastings={data.tastings} /> : <SignInForm />;
}

const signInSchema = z.object({
  password: z.string().min(1, 'Enter the password'),
});
type SignInValues = z.infer<typeof signInSchema>;

function SignInForm() {
  const revalidator = useRevalidator();
  const [formError, setFormError] = useState<string>();
  const {
    register,
    handleSubmit,
    setError,
    setFocus,
    formState: { errors, isSubmitting },
  } = useForm<SignInValues>({
    resolver: zodResolver(signInSchema),
    defaultValues: { password: '' },
  });

  const onSubmit = async ({ password }: SignInValues) => {
    setFormError(undefined);
    try {
      await api.signIn(password);
      revalidator.revalidate();
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        setError('password', { message: 'Wrong password' });
        setFocus('password');
      } else if (error instanceof ApiError && error.status === 429) {
        setFormError(error.message);
      } else if (error instanceof ApiError && error.status === 503) {
        setFormError('Staff sign-in is not set up on this server yet.');
      } else {
        setFormError('Sign-in failed. Please try again.');
      }
    }
  };

  return (
    <section className="mx-auto max-w-md">
      <p className="text-sm font-semibold tracking-[0.2em] text-gold-deep uppercase">Staff only</p>
      <h1 className="mt-3 font-display text-5xl leading-[1.05] font-semibold text-wine">
        Staff sign-in
      </h1>

      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="mt-8 flex flex-col gap-6 rounded-xl border border-line bg-paper p-6 shadow-sm sm:p-8"
      >
        <TextField
          id="password"
          label="Password"
          type="password"
          autoComplete="current-password"
          field={register('password')}
          error={errors.password?.message}
        />

        {formError && (
          <p role="alert" className="rounded-md bg-danger-soft px-4 py-3 text-sm font-medium text-danger">
            {formError}
          </p>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex items-center justify-center rounded-md bg-wine px-6 py-3 text-base font-semibold text-cream transition hover:bg-wine-deep disabled:cursor-wait disabled:opacity-70"
        >
          Sign in
        </button>
      </form>
    </section>
  );
}

function StaffBookings({ tastings }: { tastings: StaffTasting[] }) {
  const revalidator = useRevalidator();
  const [actionError, setActionError] = useState<string>();
  const [busyReference, setBusyReference] = useState<string>();

  const cancel = async (reference: string) => {
    setActionError(undefined);
    setBusyReference(reference);
    try {
      await api.cancelBooking(reference);
    } catch {
      setActionError(`Booking ${reference} could not be cancelled. Please try again.`);
    } finally {
      // Reload either way: the booking may already be gone, or the session may have ended.
      setBusyReference(undefined);
      revalidator.revalidate();
    }
  };

  const signOut = async () => {
    try {
      await api.signOut();
    } catch {
      setActionError('Sign-out failed. Please try again.');
    } finally {
      revalidator.revalidate();
    }
  };

  const totalBookings = tastings.reduce((sum, t) => sum + t.bookings.length, 0);

  return (
    <div className="flex flex-col gap-10">
      <section className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold tracking-[0.2em] text-gold-deep uppercase">Staff</p>
          <h1 className="mt-2 font-display text-5xl leading-[1.05] font-semibold text-wine">
            Bookings
          </h1>
          <p className="mt-3 text-ink/80">
            {totalBookings === 1 ? '1 booking' : `${totalBookings} bookings`} across{' '}
            {tastings.length} tastings.
          </p>
        </div>
        <button
          type="button"
          onClick={signOut}
          className="rounded-md border border-wine px-4 py-2 text-sm font-semibold text-wine transition hover:bg-wine hover:text-cream"
        >
          Sign out
        </button>
      </section>

      {actionError && (
        <p role="alert" className="rounded-md bg-danger-soft px-4 py-3 text-sm font-medium text-danger">
          {actionError}
        </p>
      )}

      {tastings.map((tasting) => {
        const booked = tasting.seats - tasting.seatsLeft;
        return (
          <section
            key={tasting.id}
            aria-labelledby={`staff-${tasting.id}`}
            className="rounded-xl border border-line bg-paper shadow-sm"
          >
            <header className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-2 border-b border-line px-5 py-5 sm:px-7">
              <div>
                <h2 id={`staff-${tasting.id}`} className="font-display text-3xl font-semibold text-wine">
                  {tasting.title}
                </h2>
                <p className="mt-1 text-sm text-muted">
                  {formatDate(tasting.dateTime)}, {formatTime(tasting.dateTime)}
                </p>
              </div>
              <p className="text-sm text-ink">
                {booked} of {tasting.seats} seats booked · {seatsLeftLabel(tasting.seatsLeft)}
              </p>
            </header>

            {tasting.bookings.length === 0 ? (
              <p className="px-5 py-6 text-sm text-muted sm:px-7">No bookings yet.</p>
            ) : (
              <div className="relative">
                <table className="block w-full text-left text-sm sm:table">
                  <caption className="sr-only">Bookings for {tasting.title}</caption>
                  <thead className="max-sm:sr-only sm:table-header-group">
                    <tr className="text-xs tracking-wide text-muted uppercase">
                      <th scope="col" className="py-3 pr-3 pl-7 font-semibold">Name</th>
                      <th scope="col" className="px-3 py-3 font-semibold">Email</th>
                      <th scope="col" className="px-3 py-3 font-semibold">Guests</th>
                      <th scope="col" className="px-3 py-3 font-semibold">Reference</th>
                      <th scope="col" className="py-3 pr-7 pl-3 text-right font-semibold">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="block divide-y divide-line sm:table-row-group">
                    {tasting.bookings.map((booking) => (
                      <tr key={booking.reference} className="block px-5 py-4 sm:table-row sm:p-0">
                        <td
                          data-label="Name"
                          className="block py-1 font-medium text-ink before:block before:text-xs before:font-semibold before:tracking-wide before:text-muted before:uppercase before:content-[attr(data-label)] sm:table-cell sm:py-3.5 sm:pr-3 sm:pl-7 sm:before:hidden"
                        >
                          {booking.name}
                        </td>
                        <td
                          data-label="Email"
                          className="block py-1 break-all text-ink/80 before:block before:text-xs before:font-semibold before:tracking-wide before:text-muted before:uppercase before:content-[attr(data-label)] sm:table-cell sm:px-3 sm:py-3.5 sm:before:hidden"
                        >
                          {booking.email}
                        </td>
                        <td
                          data-label="Guests"
                          className="block py-1 tabular-nums before:block before:text-xs before:font-semibold before:tracking-wide before:text-muted before:uppercase before:content-[attr(data-label)] sm:table-cell sm:px-3 sm:py-3.5 sm:before:hidden"
                        >
                          {booking.guests}
                        </td>
                        <td
                          data-label="Reference"
                          className="block py-1 font-mono text-wine before:block before:font-sans before:text-xs before:font-semibold before:tracking-wide before:text-muted before:uppercase before:content-[attr(data-label)] sm:table-cell sm:px-3 sm:py-3.5 sm:before:hidden"
                        >
                          {booking.reference}
                        </td>
                        <td className="block pt-2 sm:table-cell sm:py-3.5 sm:pr-7 sm:pl-3 sm:text-right sm:align-middle">
                          <button
                            type="button"
                            disabled={busyReference === booking.reference}
                            onClick={() => cancel(booking.reference)}
                            className="rounded-md border border-danger/40 px-3 py-1.5 text-sm font-semibold text-danger transition hover:bg-danger-soft disabled:opacity-60"
                          >
                            Cancel
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
