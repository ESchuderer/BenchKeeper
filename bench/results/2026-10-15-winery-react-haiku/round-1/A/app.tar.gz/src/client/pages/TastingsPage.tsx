import { useLoaderData } from 'react-router';
import type { Tasting } from '../../shared/types.js';
import { TastingCard } from '../components/TastingCard.js';

export function TastingsPage() {
  const tastings = useLoaderData() as Tasting[];

  return (
    <div className="flex flex-col gap-10">
      <section className="max-w-2xl">
        <p className="text-sm font-semibold tracking-[0.2em] text-gold-deep uppercase">
          Tastings at the estate
        </p>
        <h1 className="mt-3 font-display text-5xl leading-[1.05] font-semibold text-wine sm:text-6xl">
          Reserve your place
        </h1>
        <p className="mt-5 text-lg text-ink/80">
          Choose a tasting and book your seats online. Prices are per guest.
        </p>
      </section>

      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {tastings.map((tasting) => (
          <li key={tasting.id}>
            <TastingCard tasting={tasting} />
          </li>
        ))}
      </ul>
    </div>
  );
}
