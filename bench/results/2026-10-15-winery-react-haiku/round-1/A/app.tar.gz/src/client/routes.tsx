import type { RouteObject } from 'react-router';
import { api, ApiError } from './api.js';
import { Layout } from './components/Layout.js';
import { BookingPage } from './pages/BookingPage.js';
import { ConfirmationPage } from './pages/ConfirmationPage.js';
import { ErrorPage } from './pages/ErrorPage.js';
import { NotFoundPage } from './pages/NotFoundPage.js';
import { StaffPage, type StaffData } from './pages/StaffPage.js';
import { TastingsPage } from './pages/TastingsPage.js';

/** Turns an API 404 into a router 404, so the page shows "Page not found". */
async function orNotFound<T>(load: () => Promise<T>): Promise<T> {
  try {
    return await load();
  } catch (error) {
    if (error instanceof ApiError && error.status === 404) {
      throw new Response('Not found', { status: 404 });
    }
    throw error;
  }
}

async function loadStaff(): Promise<StaffData> {
  const { authenticated } = await api.staffSession();
  if (!authenticated) return { authenticated: false };
  try {
    const { tastings } = await api.staffBookings();
    return { authenticated: true, tastings };
  } catch (error) {
    // The session expired between the two calls.
    if (error instanceof ApiError && error.status === 401) return { authenticated: false };
    throw error;
  }
}

export const routes: RouteObject[] = [
  {
    path: '/',
    element: <Layout />,
    errorElement: (
      <Layout>
        <ErrorPage />
      </Layout>
    ),
    children: [
      {
        index: true,
        loader: () => api.listTastings(),
        Component: TastingsPage,
      },
      {
        path: 'tastings/:id/book',
        loader: ({ params }) => orNotFound(() => api.getTasting(params.id ?? '')),
        Component: BookingPage,
      },
      {
        path: 'bookings/:reference',
        loader: ({ params }) =>
          orNotFound(() => api.getConfirmation(params.reference ?? '')),
        Component: ConfirmationPage,
      },
      {
        path: 'staff',
        loader: loadStaff,
        Component: StaffPage,
      },
      {
        path: '*',
        Component: NotFoundPage,
      },
    ],
  },
];
