import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import cookieSession from 'cookie-session';
import express, {
  type NextFunction,
  type Request,
  type RequestHandler,
  type Response,
} from 'express';
import { rateLimit } from 'express-rate-limit';
import helmet from 'helmet';
import type { ZodError } from 'zod';
import type { BookingBook } from './bookings.js';
import { bookingSchema } from '../shared/booking-schema.js';
import type { FieldErrors } from '../shared/types.js';

export interface AppOptions {
  bookings: BookingBook;
  /** Staff password. When unset or empty, staff sign-in is disabled. */
  staffPassword?: string;
  /** Folder with the built React app. When it has no index.html, only the API is served. */
  clientDir?: string;
  /** Sign-in attempts allowed per 15 minutes. */
  signInLimit?: number;
}

const SIGN_IN_WINDOW_MS = 15 * 60 * 1000;
const SESSION_MAX_AGE_MS = 12 * 60 * 60 * 1000;

export function createApp({
  bookings,
  staffPassword,
  clientDir,
  signInLimit = 10,
}: AppOptions) {
  const app = express();
  const staffSessions = new Map<string, number>(); // session id -> signed-in time

  app.use(helmet());
  app.use(express.json({ limit: '10kb' }));
  app.use(
    cookieSession({
      name: 'kb_staff',
      // A new random key on every start: staff are signed out when the server restarts.
      keys: [randomBytes(32).toString('hex')],
      httpOnly: true,
      sameSite: 'lax',
      maxAge: SESSION_MAX_AGE_MS,
    }),
  );

  const requireStaff: RequestHandler = (req, res, next) => {
    if (isStaff(req, staffSessions)) return next();
    res.status(401).json({ message: 'Sign in to see the bookings' });
  };

  const api = express.Router();

  api.get('/tastings', (_req, res) => {
    res.json(bookings.listTastings());
  });

  api.get('/tastings/:id', (req, res) => {
    const tasting = bookings.findTasting(req.params.id);
    if (!tasting) return notFound(res, 'Tasting not found');
    res.json(tasting);
  });

  api.post('/tastings/:id/bookings', (req, res) => {
    const tasting = bookings.findTasting(req.params.id);
    if (!tasting) return notFound(res, 'Tasting not found');

    const parsed = bookingSchema(tasting.seatsLeft).safeParse(req.body ?? {});
    if (!parsed.success) {
      const errors = fieldErrors(parsed.error);
      // A body that is not an object has no field errors to show.
      if (Object.keys(errors).length === 0) {
        return res.status(400).json({ message: 'Booking details are required' });
      }
      return res.status(400).json({ errors });
    }
    res.status(201).json(bookings.reserve(tasting.id, parsed.data));
  });

  api.get('/bookings/:reference', (req, res) => {
    const confirmation = bookings.findConfirmation(req.params.reference);
    if (!confirmation) return notFound(res, 'Booking not found');
    res.json(confirmation);
  });

  const signInLimiter = rateLimit({
    windowMs: SIGN_IN_WINDOW_MS,
    limit: signInLimit,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { message: 'Too many sign-in attempts. Try again in a few minutes.' },
  });

  api.post('/staff/session', signInLimiter, (req, res) => {
    if (!staffPassword) {
      return res.status(503).json({ message: 'Staff sign-in is not configured' });
    }
    const password = req.body?.password;
    if (typeof password !== 'string' || password === '') {
      return res.status(400).json({ message: 'Password is required' });
    }
    if (!passwordMatches(password, staffPassword)) {
      return res.status(401).json({ message: 'Wrong password' });
    }
    const id = randomBytes(24).toString('hex');
    pruneStaffSessions(staffSessions);
    staffSessions.set(id, Date.now());
    req.session = { staffSession: id };
    res.json({ authenticated: true });
  });

  api.get('/staff/session', (req, res) => {
    res.json({ authenticated: isStaff(req, staffSessions) });
  });

  api.delete('/staff/session', (req, res) => {
    const id = req.session?.staffSession;
    if (typeof id === 'string') staffSessions.delete(id);
    req.session = null;
    res.status(204).end();
  });

  api.get('/staff/bookings', requireStaff, (_req, res) => {
    res.json({ tastings: bookings.staffView() });
  });

  api.delete('/staff/bookings/:reference', requireStaff, (req: Request<{ reference: string }>, res) => {
    if (!bookings.cancel(req.params.reference)) return notFound(res, 'Booking not found');
    res.status(204).end();
  });

  app.use('/api', api);
  app.use('/api', (_req, res) => notFound(res, 'Not found'));

  if (clientDir && existsSync(join(clientDir, 'index.html'))) {
    app.use(express.static(clientDir, { index: false }));
    app.use('/assets', (_req, res) => notFound(res, 'Not found'));
    // Client-side routes such as /staff all receive the app shell.
    app.use((req, res, next) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') return next();
      res.sendFile(join(clientDir, 'index.html'));
    });
  }

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    const status = (err as { status?: unknown }).status;
    if (typeof status === 'number' && status >= 400 && status < 500) {
      return res.status(status).json({ message: 'Invalid request' });
    }
    console.error(err);
    res.status(500).json({ message: 'Something went wrong' });
  });

  return app;
}

/**
 * The cookie only holds an id. The sign-in time and the sign-out live on the server, so a
 * copied cookie stops working after sign-out or after the session's 12 hours.
 */
function isStaff(req: Request, sessions: Map<string, number>): boolean {
  const id = req.session?.staffSession;
  if (typeof id !== 'string') return false;
  const signedInAt = sessions.get(id);
  if (signedInAt === undefined) return false;
  if (Date.now() - signedInAt < SESSION_MAX_AGE_MS) return true;
  sessions.delete(id);
  return false;
}

function pruneStaffSessions(sessions: Map<string, number>) {
  const now = Date.now();
  for (const [id, signedInAt] of sessions) {
    if (now - signedInAt >= SESSION_MAX_AGE_MS) sessions.delete(id);
  }
}

function notFound(res: Response, message: string) {
  return res.status(404).json({ message });
}

/** The first message for each field, which is the one the form shows. */
function fieldErrors(error: ZodError): FieldErrors {
  const errors: FieldErrors = {};
  for (const issue of error.issues) {
    const field = issue.path[0];
    if (field === 'name' || field === 'email' || field === 'guests') {
      errors[field] ??= issue.message;
    }
  }
  return errors;
}

/** Compares digests so the check takes the same time whatever the guess looks like. */
function passwordMatches(given: string, expected: string): boolean {
  const givenDigest = createHash('sha256').update(given).digest();
  const expectedDigest = createHash('sha256').update(expected).digest();
  return timingSafeEqual(givenDigest, expectedDigest);
}
