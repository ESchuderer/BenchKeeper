import { randomInt } from 'node:crypto';
import type { BookingInput } from '../shared/booking-schema.js';
import type {
  Confirmation,
  StaffBooking,
  StaffTasting,
  Tasting,
  TastingDefinition,
} from '../shared/types.js';

// Leaves out easily confused characters (0/O, 1/I/L) so a reference can be read aloud.
const REFERENCE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const REFERENCE_LENGTH = 6;

interface StoredBooking extends BookingInput {
  reference: string;
  tastingId: string;
}

/**
 * Tastings and their bookings, kept in memory. Node runs JavaScript on one thread and
 * the methods here do not await, so a seat check and the matching reservation cannot interleave.
 */
export class BookingBook {
  private readonly tastings = new Map<string, TastingDefinition>();
  private readonly bookings = new Map<string, StoredBooking>();

  constructor(definitions: readonly TastingDefinition[]) {
    for (const definition of definitions) {
      this.tastings.set(definition.id, definition);
    }
  }

  listTastings(): Tasting[] {
    return [...this.tastings.values()].map((definition) => this.withSeatsLeft(definition));
  }

  findTasting(id: string): Tasting | undefined {
    const definition = this.tastings.get(id);
    return definition && this.withSeatsLeft(definition);
  }

  /** Adds a booking. The caller must have checked that enough seats are left. */
  reserve(tastingId: string, input: BookingInput): Confirmation {
    const tasting = this.findTasting(tastingId);
    if (!tasting) throw new Error(`Unknown tasting: ${tastingId}`);
    if (input.guests > tasting.seatsLeft) {
      throw new Error(`Only ${tasting.seatsLeft} seats left for ${tastingId}`);
    }

    const booking: StoredBooking = { ...input, reference: this.newReference(), tastingId };
    this.bookings.set(booking.reference, booking);
    return this.confirmation(booking);
  }

  findConfirmation(reference: string): Confirmation | undefined {
    const booking = this.bookings.get(reference);
    return booking && this.confirmation(booking);
  }

  /** Removes a booking and frees its seats. Returns false if there was no such booking. */
  cancel(reference: string): boolean {
    return this.bookings.delete(reference);
  }

  staffView(): StaffTasting[] {
    return this.listTastings().map((tasting) => ({
      ...tasting,
      bookings: this.bookingsFor(tasting.id),
    }));
  }

  private withSeatsLeft(definition: TastingDefinition): Tasting {
    const taken = this.bookingsFor(definition.id).reduce((sum, b) => sum + b.guests, 0);
    return { ...definition, seatsLeft: definition.seats - taken };
  }

  private bookingsFor(tastingId: string): StaffBooking[] {
    return [...this.bookings.values()]
      .filter((booking) => booking.tastingId === tastingId)
      .map(({ reference, name, email, guests }) => ({ reference, name, email, guests }));
  }

  private confirmation(booking: StoredBooking): Confirmation {
    const definition = this.tastings.get(booking.tastingId);
    if (!definition) throw new Error(`Unknown tasting: ${booking.tastingId}`);
    return {
      reference: booking.reference,
      guests: booking.guests,
      totalPrice: definition.pricePerGuest * booking.guests,
      tasting: {
        id: definition.id,
        title: definition.title,
        dateTime: definition.dateTime,
        pricePerGuest: definition.pricePerGuest,
      },
    };
  }

  private newReference(): string {
    for (;;) {
      let code = '';
      for (let i = 0; i < REFERENCE_LENGTH; i++) {
        code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
      }
      const reference = `KB-${code}`;
      if (!this.bookings.has(reference)) return reference;
    }
  }
}
