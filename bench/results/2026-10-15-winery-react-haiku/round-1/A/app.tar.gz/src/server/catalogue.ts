import type { TastingDefinition } from '../shared/types.js';

export const TASTINGS: readonly TastingDefinition[] = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    dateTime: '2026-11-06T18:00',
    pricePerGuest: 25,
    seats: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    dateTime: '2026-11-14T15:00',
    pricePerGuest: 32,
    seats: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    dateTime: '2026-12-05T17:00',
    pricePerGuest: 28,
    seats: 10,
  },
];
