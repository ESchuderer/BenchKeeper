import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { BookingBook } from './bookings.js';
import { TASTINGS } from './catalogue.js';

const port = Number(process.env.PORT || 3000);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error(`PORT must be a whole number from 1 to 65535, got "${process.env.PORT}"`);
  process.exit(1);
}

const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set. Staff sign-in is disabled until it is set.');
}

// Compiled to dist/server/server/index.js, so the built app is at dist/client.
const clientDir = fileURLToPath(new URL('../../client', import.meta.url));
if (!existsSync(clientDir)) {
  console.warn('No client build found. Run "npm run build". Serving the API only.');
}

const app = createApp({
  bookings: new BookingBook(TASTINGS),
  staffPassword,
  clientDir,
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen is running on http://localhost:${port}`);
});
