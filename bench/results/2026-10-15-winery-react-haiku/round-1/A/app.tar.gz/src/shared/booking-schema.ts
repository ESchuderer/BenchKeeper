import { z } from 'zod';

export const MAX_GUESTS = 8;

const NAME_MAX = 100;
const EMAIL_MAX = 254;

/**
 * Rules for a booking, given how many seats are still free.
 * Used by the booking form (to show errors before submitting) and by the API (the final check).
 */
export function bookingSchema(seatsLeft: number) {
  return z.object({
    name: z
      .string({ error: 'Enter your name' })
      .trim()
      .min(1, 'Enter your name')
      .max(NAME_MAX, `Name must be ${NAME_MAX} characters or fewer`),
    email: z
      .string({ error: 'Enter your email address' })
      .trim()
      .min(1, 'Enter your email address')
      .max(EMAIL_MAX, `Email must be ${EMAIL_MAX} characters or fewer`)
      .pipe(z.email({ error: 'Enter a valid email address' })),
    guests: guestsRule(seatsLeft),
  });
}

export type BookingInput = z.output<ReturnType<typeof bookingSchema>>;

function guestsRule(seatsLeft: number) {
  const base = z.number({ error: `Enter the number of guests (1 to ${MAX_GUESTS})` });
  // A full tasting gets one clear message, whatever the guest count.
  if (seatsLeft === 0) {
    return base.refine(() => false, { message: 'This tasting is fully booked' });
  }
  return base
    .int('Guests must be a whole number')
    .min(1, `Guests must be between 1 and ${MAX_GUESTS}`)
    .max(MAX_GUESTS, `Guests must be between 1 and ${MAX_GUESTS}`)
    .refine((guests) => guests <= seatsLeft, {
      message: seatsLeft === 1 ? 'Only 1 seat left' : `Only ${seatsLeft} seats left`,
    });
}
