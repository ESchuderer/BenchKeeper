/** A tasting as the server defines it. Date and time are winery-local, e.g. "2026-11-06T18:00". */
export interface TastingDefinition {
  id: string;
  title: string;
  dateTime: string;
  pricePerGuest: number;
  seats: number;
}

export interface Tasting extends TastingDefinition {
  seatsLeft: number;
}

export interface TastingSummary {
  id: string;
  title: string;
  dateTime: string;
  pricePerGuest: number;
}

/** What a guest sees after booking. Name and email are left out on purpose. */
export interface Confirmation {
  reference: string;
  guests: number;
  totalPrice: number;
  tasting: TastingSummary;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTasting {
  id: string;
  title: string;
  dateTime: string;
  seats: number;
  seatsLeft: number;
  bookings: StaffBooking[];
}

export type FieldErrors = Partial<Record<'name' | 'email' | 'guests', string>>;

export interface ErrorBody {
  message?: string;
  errors?: FieldErrors;
}
