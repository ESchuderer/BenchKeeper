import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createMemoryRouter, RouterProvider } from 'react-router';
import { routes } from '../../src/client/routes.js';
import type { Confirmation, Tasting } from '../../src/shared/types.js';

const riesling: Tasting = {
  id: 'riesling-evening',
  title: 'Riesling Evening',
  dateTime: '2026-11-06T18:00',
  pricePerGuest: 25,
  seats: 12,
  seatsLeft: 12,
};

const cellar: Tasting = {
  id: 'red-wine-cellar-tour',
  title: 'Red Wine Cellar Tour',
  dateTime: '2026-11-14T15:00',
  pricePerGuest: 32,
  seats: 8,
  seatsLeft: 3,
};

const winter: Tasting = {
  id: 'winter-tasting',
  title: 'Winter Tasting',
  dateTime: '2026-12-05T17:00',
  pricePerGuest: 28,
  seats: 10,
  seatsLeft: 0,
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

type Handler = (method: string, path: string, body: unknown) => Response;

/** Fake the API. The handler gets the method, path and parsed JSON body of each call. */
function fakeApi(handler: Handler) {
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const method = init?.method ?? 'GET';
    const body = init?.body ? JSON.parse(String(init.body)) : undefined;
    return handler(method, String(input), body);
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

function renderAt(path: string) {
  const router = createMemoryRouter(routes, { initialEntries: [path] });
  render(<RouterProvider router={router} />);
  return router;
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('tastings page', () => {
  it('lists each tasting with its date, price, seats left and a booking link', async () => {
    fakeApi((_m, path) => {
      if (path === '/api/tastings') return json([riesling, cellar, winter]);
      return json({ message: 'Not found' }, 404);
    });
    renderAt('/');

    const rieslingCard = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(rieslingCard).getByText(/Friday, 6 November 2026/)).toBeInTheDocument();
    expect(within(rieslingCard).getByText('18:00')).toBeInTheDocument();
    expect(within(rieslingCard).getByText('EUR 25')).toBeInTheDocument();
    expect(within(rieslingCard).getByText('12 seats left')).toBeInTheDocument();
    expect(
      within(rieslingCard).getByRole('link', { name: 'Book Riesling Evening' }),
    ).toHaveAttribute('href', '/tastings/riesling-evening/book');
  });

  it('uses the singular for one seat left', async () => {
    fakeApi(() => json([{ ...cellar, seatsLeft: 1 }]));
    renderAt('/');
    expect(await screen.findByText('1 seat left')).toBeInTheDocument();
  });

  it('marks a fully booked tasting and offers no booking link', async () => {
    fakeApi(() => json([winter]));
    renderAt('/');

    const card = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(within(card).getByText('0 seats left')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Winter Tasting' })).toBeNull();
  });
});

describe('booking form', () => {
  it('shows the labelled fields and the Book button', async () => {
    fakeApi((_m, path) => (path.endsWith('/riesling-evening') ? json(riesling) : json({}, 404)));
    renderAt('/tastings/riesling-evening/book');

    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows each error next to the field it concerns and does not call the API', async () => {
    const user = userEvent.setup();
    const fetchMock = fakeApi((_m, path) =>
      path.endsWith('/riesling-evening') ? json(riesling) : json({}, 404),
    );
    renderAt('/tastings/riesling-evening/book');
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.clear(screen.getByLabelText('Guests'));
    await user.click(screen.getByRole('button', { name: 'Book' }));

    const name = await screen.findByLabelText('Name');
    expect(name).toHaveAttribute('aria-invalid', 'true');
    expect(name).toHaveAccessibleDescription('Enter your name');
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription(
      'Enter your email address',
    );
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(
      'Enter the number of guests (1 to 8)',
    );
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'POST')).toBe(false);
  });

  it('rejects an invalid email and a guest count outside 1 to 8', async () => {
    const user = userEvent.setup();
    fakeApi((_m, path) => (path.endsWith('/riesling-evening') ? json(riesling) : json({}, 404)));
    renderAt('/tastings/riesling-evening/book');
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Enter a valid email address')).toBeInTheDocument();
    expect(screen.getByText('Guests must be between 1 and 8')).toBeInTheDocument();
  });

  it('refuses more guests than seats left, before submitting', async () => {
    const user = userEvent.setup();
    const fetchMock = fakeApi((_m, path) =>
      path.endsWith('/red-wine-cellar-tour') ? json(cellar) : json({}, 404),
    );
    renderAt('/tastings/red-wine-cellar-tour/book');
    await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' });

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Only 3 seats left')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Only 3 seats left');
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'POST')).toBe(false);
  });

  it('books, then shows the confirmation with the total price and reference', async () => {
    const user = userEvent.setup();
    const confirmation: Confirmation = {
      reference: 'KB-7H3QX2',
      guests: 2,
      totalPrice: 50,
      tasting: {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        dateTime: '2026-11-06T18:00',
        pricePerGuest: 25,
      },
    };
    const fetchMock = fakeApi((method, path, body) => {
      if (method === 'POST' && path === '/api/tastings/riesling-evening/bookings') {
        expect(body).toEqual({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
        return json(confirmation, 201);
      }
      if (path === '/api/bookings/KB-7H3QX2') return json(confirmation);
      if (path.endsWith('/riesling-evening')) return json(riesling);
      return json({}, 404);
    });
    const router = renderAt('/tastings/riesling-evening/book');
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(router.state.location.pathname).toBe('/bookings/KB-7H3QX2');
    expect(screen.getByText('KB-7H3QX2')).toBeInTheDocument();
    expect(screen.getByText('EUR 50')).toBeInTheDocument();
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalled();
  });

  it('shows a server-side seat rejection next to the Guests field', async () => {
    const user = userEvent.setup();
    fakeApi((method, path) => {
      if (method === 'POST') {
        return json({ errors: { guests: 'Only 1 seat left' } }, 400);
      }
      return json(cellar);
    });
    renderAt('/tastings/red-wine-cellar-tour/book');
    await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' });

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    await waitFor(() =>
      expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Only 1 seat left'),
    );
  });

  it('shows fully booked tastings without a form', async () => {
    fakeApi(() => json(winter));
    renderAt('/tastings/winter-tasting/book');

    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).toBeNull();
    expect(screen.queryByLabelText('Guests')).toBeNull();
  });

  it('shows a friendly page for an unknown tasting', async () => {
    fakeApi(() => json({ message: 'Tasting not found' }, 404));
    renderAt('/tastings/unknown/book');
    expect(await screen.findByRole('heading', { name: 'Page not found' })).toBeInTheDocument();
  });
});

describe('staff sign-in', () => {
  it('shows the password form and rejects a wrong password', async () => {
    const user = userEvent.setup();
    fakeApi((method, path) => {
      if (path === '/api/staff/session' && method === 'GET') return json({ authenticated: false });
      if (path === '/api/staff/session' && method === 'POST') {
        return json({ message: 'Wrong password' }, 401);
      }
      return json({}, 404);
    });
    renderAt('/staff');

    await user.type(await screen.findByLabelText('Password'), 'guess');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByText('Wrong password')).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Bookings' })).toBeNull();
  });
});
