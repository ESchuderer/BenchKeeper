import { expect, test, type Page } from '@playwright/test';

const PASSWORD = 'e2e-password';
const SCREENSHOTS = 'test-results/screenshots';

// The server keeps bookings in memory and all tests share it, so the steps run in order.
test.describe.configure({ mode: 'serial' });

async function openBookingForm(page: Page, title: string) {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${title}` }).click();
  await expect(page).toHaveURL(/\/tastings\/.+\/book$/);
  await expect(page.getByRole('heading', { level: 1, name: title })).toBeVisible();
}

async function fillBooking(page: Page, name: string, email: string, guests: string) {
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Guests').fill(guests);
}

test('the start page lists the tastings with price and seats left', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { level: 1, name: 'Reserve your place' })).toBeVisible();

  const riesling = page.getByRole('article', { name: 'Riesling Evening' });
  await expect(riesling.getByText('EUR 25')).toBeVisible();
  await expect(riesling.getByText('18:00')).toBeVisible();
  await expect(riesling.getByText('12 seats left')).toBeVisible();

  await expect(page.getByRole('article', { name: 'Red Wine Cellar Tour' }).getByText('8 seats left')).toBeVisible();
  await expect(page.getByRole('article', { name: 'Winter Tasting' }).getByText('10 seats left')).toBeVisible();
});

test('a guest sees each error next to the field it concerns', async ({ page }) => {
  await openBookingForm(page, 'Riesling Evening');
  await page.getByLabel('Guests').fill('');
  await page.getByRole('button', { name: 'Book', exact: true }).click();

  await expect(page.getByLabel('Name')).toHaveAccessibleDescription('Enter your name');
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Enter your email address');
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(
    'Enter the number of guests (1 to 8)',
  );

  await page.getByLabel('Email').fill('anna@example');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Enter a valid email address');
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(
    'Guests must be between 1 and 8',
  );
  await expect(page).toHaveURL(/\/book$/);
});

test('a guest books a tasting and sees the confirmation', async ({ page }) => {
  await openBookingForm(page, 'Riesling Evening');
  await fillBooking(page, 'Anna Keller', 'anna@example.com', '2');
  await expect(page.getByText('EUR 50').first()).toBeVisible();
  await page.getByRole('button', { name: 'Book', exact: true }).click();

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(page.getByText('Riesling Evening', { exact: true })).toBeVisible();
  await expect(page.getByText('EUR 50', { exact: true })).toBeVisible();
  await expect(page.getByText(/^KB-[A-Z2-9]{6}$/)).toBeVisible();

  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Riesling Evening' }).getByText('10 seats left')).toBeVisible();
});

test('a booking cannot take more seats than are left', async ({ page }) => {
  await openBookingForm(page, 'Red Wine Cellar Tour');
  await fillBooking(page, 'Ben Weber', 'ben@example.com', '6');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await openBookingForm(page, 'Red Wine Cellar Tour');
  await fillBooking(page, 'Clara Vogt', 'clara@example.com', '3');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('Only 2 seats left');
  await expect(page).toHaveURL(/\/book$/);
});

test('a fully booked tasting is marked and cannot be booked', async ({ page }) => {
  await openBookingForm(page, 'Winter Tasting');
  await fillBooking(page, 'Dora Lenz', 'dora@example.com', '8');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await openBookingForm(page, 'Winter Tasting');
  await fillBooking(page, 'Emil Roth', 'emil@example.com', '2');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  const winter = page.getByRole('article', { name: 'Winter Tasting' });
  await expect(winter.getByText('Fully booked')).toBeVisible();
  await expect(winter.getByText('0 seats left')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Book Winter Tasting' })).toHaveCount(0);

  await page.goto('/tastings/winter-tasting/book');
  await expect(page.getByRole('heading', { name: 'Fully booked' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Book', exact: true })).toHaveCount(0);
});

test('staff sign in, see bookings grouped by tasting, and cancel one', async ({ page }) => {
  await page.goto('/staff');
  await page.getByLabel('Password').fill('not-the-password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByText('Wrong password')).toBeVisible();

  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { level: 1, name: 'Bookings' })).toBeVisible();

  const riesling = page.getByRole('region', { name: 'Riesling Evening' });
  await expect(riesling.getByRole('columnheader', { name: 'Email' })).toBeVisible();
  const annaRow = riesling.getByRole('row', { name: /Anna Keller/ });
  await expect(annaRow).toContainText('anna@example.com');
  await expect(annaRow).toContainText(/KB-[A-Z2-9]{6}/);
  await expect(annaRow).toContainText('2');

  const winter = page.getByRole('region', { name: 'Winter Tasting' });
  await expect(winter.getByRole('row', { name: /Dora Lenz/ })).toBeVisible();

  await annaRow.getByRole('button', { name: 'Cancel' }).click();
  await expect(riesling.getByRole('row', { name: /Anna Keller/ })).toHaveCount(0);

  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Riesling Evening' }).getByText('12 seats left')).toBeVisible();
});

test('staff can sign out and the bookings are hidden again', async ({ page }) => {
  await page.goto('/staff');
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();

  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByRole('heading', { name: 'Staff sign-in' })).toBeVisible();
  await expect(page.getByText('Dora Lenz')).toHaveCount(0);
});

test('the pages fit a phone screen and show a not-found page', async ({ page }) => {
  await page.setViewportSize({ width: 360, height: 740 });

  for (const path of ['/', '/tastings/riesling-evening/book', '/staff']) {
    await page.goto(path);
    await expect(page.locator('h1').first()).toBeVisible();
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
    );
    expect(overflow, `horizontal overflow on ${path}`).toBeLessThanOrEqual(0);
  }

  await page.goto('/');
  await page.screenshot({ path: `${SCREENSHOTS}/phone-tastings.png`, fullPage: true });
  await page.goto('/tastings/riesling-evening/book');
  await page.screenshot({ path: `${SCREENSHOTS}/phone-booking.png`, fullPage: true });

  await page.goto('/no-such-page');
  await expect(page.getByRole('heading', { name: 'Page not found' })).toBeVisible();
});
