import request from 'supertest';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { Express } from 'express';
import { createApp } from '../../src/server/app.js';
import { BookingBook } from '../../src/server/bookings.js';
import { TASTINGS } from '../../src/server/catalogue.js';

const PASSWORD = 'correct horse';
const RIESLING = 'riesling-evening';
const CELLAR = 'red-wine-cellar-tour';
const REFERENCE_PATTERN = /^KB-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}$/;

let app: Express;
let book: BookingBook;

function bookingBody(overrides: Record<string, unknown> = {}) {
  return { name: 'Anna Keller', email: 'anna@example.com', guests: 2, ...overrides };
}

async function signIn(agent = request.agent(app)) {
  const res = await agent.post('/api/staff/session').send({ password: PASSWORD });
  expect(res.status).toBe(200);
  return agent;
}

async function seatsLeft(id: string) {
  const res = await request(app).get(`/api/tastings/${id}`);
  return res.body.seatsLeft as number;
}

beforeEach(() => {
  book = new BookingBook(TASTINGS);
  app = createApp({ bookings: book, staffPassword: PASSWORD });
});

describe('GET /api/tastings', () => {
  it('lists the three tastings with all seats free at the start', async () => {
    const res = await request(app).get('/api/tastings');
    expect(res.status).toBe(200);
    expect(res.body).toEqual([
      {
        id: RIESLING,
        title: 'Riesling Evening',
        dateTime: '2026-11-06T18:00',
        pricePerGuest: 25,
        seats: 12,
        seatsLeft: 12,
      },
      {
        id: CELLAR,
        title: 'Red Wine Cellar Tour',
        dateTime: '2026-11-14T15:00',
        pricePerGuest: 32,
        seats: 8,
        seatsLeft: 8,
      },
      {
        id: 'winter-tasting',
        title: 'Winter Tasting',
        dateTime: '2026-12-05T17:00',
        pricePerGuest: 28,
        seats: 10,
        seatsLeft: 10,
      },
    ]);
  });

  it('returns 404 for an unknown tasting', async () => {
    const res = await request(app).get('/api/tastings/no-such-tasting');
    expect(res.status).toBe(404);
    expect(res.body.message).toBeTypeOf('string');
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('books seats and returns a confirmation with reference and total', async () => {
    const res = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send(bookingBody({ guests: 2 }));

    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(REFERENCE_PATTERN),
      guests: 2,
      totalPrice: 50,
      tasting: {
        id: RIESLING,
        title: 'Riesling Evening',
        dateTime: '2026-11-06T18:00',
        pricePerGuest: 25,
      },
    });
    expect(await seatsLeft(RIESLING)).toBe(10);
  });

  it('does not expose the guest name or email in the confirmation', async () => {
    const res = await request(app)
      .post(`/api/tastings/${CELLAR}/bookings`)
      .send(bookingBody());
    expect(res.body).not.toHaveProperty('name');
    expect(res.body).not.toHaveProperty('email');
  });

  it('gives every booking its own reference', async () => {
    const roomy = new BookingBook([{ ...TASTINGS[0], seats: 100 }]);
    const roomyApp = createApp({ bookings: roomy, staffPassword: PASSWORD });
    const refs = new Set<string>();
    for (let i = 0; i < 50; i++) {
      const res = await request(roomyApp)
        .post(`/api/tastings/${RIESLING}/bookings`)
        .send(bookingBody({ guests: 1 }))
        .expect(201);
      refs.add(res.body.reference);
    }
    expect(refs.size).toBe(50);
  });

  it('rejects invalid input with an error for each field', async () => {
    const res = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send({ name: '', email: 'not-an-email', guests: 9 });

    expect(res.status).toBe(400);
    expect(res.body).toEqual({
      errors: {
        name: 'Enter your name',
        email: 'Enter a valid email address',
        guests: 'Guests must be between 1 and 8',
      },
    });
    expect(await seatsLeft(RIESLING)).toBe(12);
  });

  it('explains a booking body that is not an object', async () => {
    const res = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send([1, 2]);
    expect(res.status).toBe(400);
    expect(res.body).toEqual({ message: 'Booking details are required' });
  });

  it('rejects a string guest count', async () => {
    const res = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send(bookingBody({ guests: '2' }));
    expect(res.status).toBe(400);
    expect(res.body.errors).toHaveProperty('guests');
  });

  it('never takes more seats than are left', async () => {
    await request(app)
      .post(`/api/tastings/${CELLAR}/bookings`)
      .send(bookingBody({ guests: 6 }))
      .expect(201);

    const res = await request(app)
      .post(`/api/tastings/${CELLAR}/bookings`)
      .send(bookingBody({ guests: 3 }));

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ errors: { guests: 'Only 2 seats left' } });
    expect(await seatsLeft(CELLAR)).toBe(2);
  });

  it('allows booking exactly the seats left, then marks the tasting fully booked', async () => {
    await request(app)
      .post(`/api/tastings/${CELLAR}/bookings`)
      .send(bookingBody({ guests: 8 }))
      .expect(201);
    expect(await seatsLeft(CELLAR)).toBe(0);

    const res = await request(app)
      .post(`/api/tastings/${CELLAR}/bookings`)
      .send(bookingBody({ guests: 1 }));
    expect(res.status).toBe(400);
    expect(res.body).toEqual({ errors: { guests: 'This tasting is fully booked' } });
  });

  it('returns 404 for an unknown tasting', async () => {
    const res = await request(app)
      .post('/api/tastings/nope/bookings')
      .send(bookingBody());
    expect(res.status).toBe(404);
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the public confirmation for a booking', async () => {
    const created = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send(bookingBody({ guests: 3 }));

    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual(created.body);
  });

  it('returns 404 for an unknown reference', async () => {
    const res = await request(app).get('/api/bookings/KB-ZZZZZZ');
    expect(res.status).toBe(404);
  });
});

describe('staff sign-in', () => {
  it('reports signed-out by default', async () => {
    const res = await request(app).get('/api/staff/session');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ authenticated: false });
  });

  it('rejects a wrong password', async () => {
    const res = await request(app).post('/api/staff/session').send({ password: 'wrong' });
    expect(res.status).toBe(401);
    expect(res.body.message).toBeTypeOf('string');
  });

  it('rejects a request without a password', async () => {
    const res = await request(app).post('/api/staff/session').send({});
    expect(res.status).toBe(400);
  });

  it('signs in with the right password and reports signed-in', async () => {
    const agent = request.agent(app);
    const res = await agent.post('/api/staff/session').send({ password: PASSWORD });
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ authenticated: true });

    const check = await agent.get('/api/staff/session');
    expect(check.body).toEqual({ authenticated: true });
  });

  it('ends a staff session after 12 hours even if the cookie is still held', async () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    try {
      const agent = await signIn();
      await agent.get('/api/staff/bookings').expect(200);

      vi.setSystemTime(Date.now() + 13 * 60 * 60 * 1000);
      await agent.get('/api/staff/bookings').expect(401);
      const check = await agent.get('/api/staff/session');
      expect(check.body).toEqual({ authenticated: false });
    } finally {
      vi.useRealTimers();
    }
  });

  it('a copied session cookie stops working after sign-out', async () => {
    const first = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    const setCookies = first.headers['set-cookie'] as unknown as string[];
    const cookie = setCookies.map((c) => c.split(';')[0]).join('; ');

    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);
    await request(app).delete('/api/staff/session').set('Cookie', cookie).expect(204);
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(401);
  });

  it('signs out', async () => {
    const agent = await signIn();
    await agent.delete('/api/staff/session').expect(204);
    const check = await agent.get('/api/staff/session');
    expect(check.body).toEqual({ authenticated: false });
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('answers 503 when no staff password is configured', async () => {
    app = createApp({ bookings: book, staffPassword: undefined });
    const res = await request(app).post('/api/staff/session').send({ password: '' });
    expect(res.status).toBe(503);
    expect(res.body.message).toMatch(/not configured/i);
  });

  it('limits repeated sign-in attempts', async () => {
    app = createApp({ bookings: book, staffPassword: PASSWORD, signInLimit: 3 });
    for (let i = 0; i < 3; i++) {
      await request(app).post('/api/staff/session').send({ password: 'wrong' }).expect(401);
    }
    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    expect(res.status).toBe(429);
  });
});

describe('staff bookings', () => {
  it('refuses the list without a staff session', async () => {
    const res = await request(app).get('/api/staff/bookings');
    expect(res.status).toBe(401);
    expect(res.body).toEqual({ message: expect.any(String) });
  });

  it('refuses cancellation without a staff session and keeps the booking', async () => {
    const created = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send(bookingBody());
    await request(app).delete(`/api/staff/bookings/${created.body.reference}`).expect(401);
    expect(await seatsLeft(RIESLING)).toBe(10);
  });

  it('lists every booking grouped by tasting, with name, email, guests and reference', async () => {
    const first = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send(bookingBody({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 }));
    const second = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send(bookingBody({ name: 'Ben Weber', email: 'ben@example.com', guests: 4 }));
    await request(app)
      .post(`/api/tastings/${CELLAR}/bookings`)
      .send(bookingBody({ name: 'Clara Vogt', email: 'clara@example.com', guests: 1 }));

    const agent = await signIn();
    const res = await agent.get('/api/staff/bookings');
    expect(res.status).toBe(200);

    const riesling = res.body.tastings.find((t: { id: string }) => t.id === RIESLING);
    expect(riesling).toMatchObject({
      title: 'Riesling Evening',
      seats: 12,
      seatsLeft: 6,
    });
    expect(riesling.bookings).toEqual([
      {
        reference: first.body.reference,
        name: 'Anna Keller',
        email: 'anna@example.com',
        guests: 2,
      },
      {
        reference: second.body.reference,
        name: 'Ben Weber',
        email: 'ben@example.com',
        guests: 4,
      },
    ]);

    const cellar = res.body.tastings.find((t: { id: string }) => t.id === CELLAR);
    expect(cellar.bookings).toHaveLength(1);
    expect(cellar.bookings[0]).toMatchObject({ name: 'Clara Vogt', guests: 1 });

    const winter = res.body.tastings.find((t: { id: string }) => t.id === 'winter-tasting');
    expect(winter.bookings).toEqual([]);
  });

  it('cancels a booking, frees its seats and removes it from the list', async () => {
    const created = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send(bookingBody({ guests: 5 }));
    expect(await seatsLeft(RIESLING)).toBe(7);

    const agent = await signIn();
    await agent.delete(`/api/staff/bookings/${created.body.reference}`).expect(204);

    expect(await seatsLeft(RIESLING)).toBe(12);
    const list = await agent.get('/api/staff/bookings');
    const riesling = list.body.tastings.find((t: { id: string }) => t.id === RIESLING);
    expect(riesling.bookings).toEqual([]);
    await request(app).get(`/api/bookings/${created.body.reference}`).expect(404);
  });

  it('returns 404 when cancelling an unknown reference', async () => {
    const agent = await signIn();
    const res = await agent.delete('/api/staff/bookings/KB-ZZZZZZ');
    expect(res.status).toBe(404);
  });

  it('lets a freed seat be booked again', async () => {
    const created = await request(app)
      .post(`/api/tastings/${CELLAR}/bookings`)
      .send(bookingBody({ guests: 8 }));
    const agent = await signIn();
    await agent.delete(`/api/staff/bookings/${created.body.reference}`).expect(204);

    await request(app)
      .post(`/api/tastings/${CELLAR}/bookings`)
      .send(bookingBody({ guests: 8 }))
      .expect(201);
  });
});

describe('unknown API routes', () => {
  it('returns a JSON 404', async () => {
    const res = await request(app).get('/api/does-not-exist');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
});
