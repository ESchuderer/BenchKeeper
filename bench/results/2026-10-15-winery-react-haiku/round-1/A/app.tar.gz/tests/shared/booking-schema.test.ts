import { describe, expect, it } from 'vitest';
import { bookingSchema } from '../../src/shared/booking-schema.js';

const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function errorsFor(input: unknown, seatsLeft = 12) {
  const result = bookingSchema(seatsLeft).safeParse(input);
  if (result.success) return {};
  const errors: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const field = String(issue.path[0]);
    errors[field] ??= issue.message;
  }
  return errors;
}

describe('bookingSchema', () => {
  it('accepts a valid booking and trims the name and email', () => {
    const result = bookingSchema(12).safeParse({
      name: '  Anna Keller ',
      email: ' anna@example.com ',
      guests: 8,
    });
    expect(result.success).toBe(true);
    expect(result.success && result.data).toEqual({
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: 8,
    });
  });

  it('accepts exactly the seats left', () => {
    expect(errorsFor({ ...valid, guests: 3 }, 3)).toEqual({});
  });

  it('requires a name', () => {
    expect(errorsFor({ ...valid, name: '   ' })).toEqual({ name: 'Enter your name' });
  });

  it('limits the name to 100 characters', () => {
    expect(errorsFor({ ...valid, name: 'x'.repeat(101) })).toEqual({
      name: 'Name must be 100 characters or fewer',
    });
  });

  it('requires a valid email address', () => {
    expect(errorsFor({ ...valid, email: '' })).toEqual({
      email: 'Enter your email address',
    });
    expect(errorsFor({ ...valid, email: 'anna@' })).toEqual({
      email: 'Enter a valid email address',
    });
  });

  it('accepts guests from 1 to 8', () => {
    for (const guests of [1, 8]) {
      expect(errorsFor({ ...valid, guests })).toEqual({});
    }
  });

  it('rejects guests outside 1 to 8', () => {
    for (const guests of [0, -1, 9]) {
      expect(errorsFor({ ...valid, guests })).toEqual({
        guests: 'Guests must be between 1 and 8',
      });
    }
  });

  it('rejects fractional and missing guest counts', () => {
    expect(errorsFor({ ...valid, guests: 1.5 })).toEqual({
      guests: 'Guests must be a whole number',
    });
    expect(errorsFor({ ...valid, guests: Number.NaN })).toEqual({
      guests: 'Enter the number of guests (1 to 8)',
    });
    expect(errorsFor({ ...valid, guests: undefined })).toEqual({
      guests: 'Enter the number of guests (1 to 8)',
    });
  });

  it('rejects more guests than seats left', () => {
    expect(errorsFor({ ...valid, guests: 3 }, 2)).toEqual({
      guests: 'Only 2 seats left',
    });
  });

  it('uses the singular for one seat left', () => {
    expect(errorsFor({ ...valid, guests: 2 }, 1)).toEqual({
      guests: 'Only 1 seat left',
    });
  });

  it('rejects every booking when the tasting is fully booked', () => {
    expect(errorsFor({ ...valid, guests: 1 }, 0)).toEqual({
      guests: 'This tasting is fully booked',
    });
    expect(errorsFor({ ...valid, guests: 9 }, 0)).toEqual({
      guests: 'This tasting is fully booked',
    });
  });
});
