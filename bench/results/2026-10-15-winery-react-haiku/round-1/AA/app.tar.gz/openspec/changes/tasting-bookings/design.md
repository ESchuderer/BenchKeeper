# Design

## Context

The repository is empty apart from OpenSpec and agent configuration, so the application is greenfield. See proposal.md for motivation and the three capability specs for the required behaviour (`tasting-catalog`, `guest-booking`, `staff-bookings`).

Constraints that shape the approach:
- Runs on Node.js 22 with `npm install`, optional `npm run build`, and `npm start` serving on `PORT` (default 3000).
- No external services, no database. Bookings live in process memory and start empty.
- The interface is React. Server, routing, forms and styling use established libraries rather than custom replacements.
- Single Node process, so synchronous check-and-insert code paths are atomic with respect to other requests.

## Goals / Non-Goals

**Goals:**
- One deployable process that serves the React single-page app and a JSON API under `/api`.
- Domain rules (seat limits, validation, cancellation, reference generation) live in one place and are tested without HTTP or React.
- Validation rules are written once and used by both the browser form and the server.
- Mobile-first, coherent winery styling with explicit loading, error, success and fully-booked states.

**Non-Goals:**
- Persistence across restarts, multi-instance deployment, payments, email, admin editing of the catalog, multiple staff accounts, i18n.
- Server-side rendering. The app is a client-rendered SPA, which keeps the build and runtime simple.

## Decisions

### Stack

| Concern | Choice | Why / alternatives |
|---|---|---|
| Language | TypeScript 5.9 (strict) | Shared types between server and client. TypeScript 7 (native rewrite) not chosen yet because of config breakage risk. |
| Server | Express 5 | Mature, minimal, the default Node HTTP framework. Alternative Fastify was not needed for a small API. |
| Security headers | helmet | Standard Express middleware; CSP defaults adjusted only if they break the Vite build. |
| Staff session | cookie-session (signed, HttpOnly, SameSite=Lax) | Stateless signed cookie; avoids a server-side session store. Signing key is random per process, so a restart signs staff out (acceptable with in-memory data). |
| Brute-force guard | express-rate-limit on `POST /api/staff/session` | Only one shared password exists, so online guessing must be limited. |
| UI | React 19 + React Router 7 (declarative `BrowserRouter`) | Routing for `/`, `/tastings/:id/book`, `/bookings/:reference`, `/staff`. |
| Forms | react-hook-form + @hookform/resolvers + zod 4 | Standard form state with per-field errors; `setError` maps server errors onto the same fields. |
| Styling | Tailwind CSS 4 via `@tailwindcss/vite` | Utility classes plus theme tokens in one CSS entry point; no runtime CSS-in-JS. |
| Build | Vite 7 (client), `tsc` (server) | Vite is the standard React build tool; server compiled with `tsc` so `npm start` needs only `node`. |
| Tests | Vitest 5, supertest, React Testing Library + user-event, jsdom | Vitest runs both node and jsdom tests; supertest exercises the real Express app. Vitest 3 was replaced by 5 to clear critical advisories in its tooling (dev-only). |

**Alternatives rejected:** Next.js or React Router framework mode (SSR frameworks add a second server model and a larger build for a three-page app); Redux or TanStack Query (data needs are a few fetches; route loaders and local state are enough); a database (out of scope and forbidden by "no external services").

### Repository layout

```
src/
  shared/      zod schemas, tasting date formatting, API types (used by both sides)
  server/
    catalog.ts         the three tastings (static data)
    bookings.ts        BookingStore: in-memory state, atomic reserve/cancel
    service.ts         domain operations used by routes (listTastings, book, cancel, ...)
    app.ts             createApp(options): Express app, routes, static + SPA fallback
    staff-auth.ts      password check, cookie session, 8h expiry
    config.ts          reads PORT, STAFF_PASSWORD and NODE_ENV (validated)
    index.ts           entry point: loads config, serves the client build, listens
  client/
    main.tsx, router.tsx, api.ts, components/, pages/
tests/ or colocated *.test.ts(x)
```

Server and client tests are colocated with the module they cover (`*.test.ts` / `*.test.tsx`). Client tests opt into jsdom with a file-level `@vitest-environment jsdom` pragma.

### Domain model and atomic seat reservation

`BookingStore` holds `Map<reference, Booking>` and `Booking = { reference, tastingId, name, email, guests, createdAt }`. Seats left are never stored; they are derived as `capacity - sum(guests)` over bookings for that tasting. This makes cancellation free seats automatically and prevents drift.

`book()` performs validation, capacity check and insertion in one synchronous function with no `await` between them. Node runs JavaScript on one thread, so two concurrent HTTP requests cannot interleave inside that function. This is the mechanism behind the "concurrent bookings cannot oversell" scenario. It would need a transaction if persistence were added later; the `BookingStore` interface is the seam for that.

Booking references use `KB-` followed by 6 characters from an alphabet without look-alikes (no `0`, `O`, `1`, `I`), generated with `crypto.randomInt`. The store retries on collision, so references are unique.

Money is whole euros in the catalog (25, 32, 28), so totals are integers and need no rounding. Totals display as `EUR <amount>`.

### Validation shared by client and server

`bookingInputSchema` (zod) validates `name`, `email` and `guests`. Guests is validated as a string so that the raw form value and a JSON body are handled identically. Messages match the specs exactly (for example "Guests must be between 1 and 8", "Guests must be a whole number"). The browser uses it through `zodResolver` and, when seats are known, a seats-aware variant adds "Only N seats left" for quicker feedback. The server always runs the full check, including seats, because the browser is not trusted.

Errors are returned as `{ errors: { name?, email?, guests?, form? } }`. `form` carries errors that belong to no single field, such as "This tasting is fully booked" and "Staff sign-in is not configured".

### HTTP API

| Method and path | Purpose | Success | Errors |
|---|---|---|---|
| `GET /api/tastings` | catalog with `seatsLeft` | 200 | — |
| `GET /api/tastings/:id` | one tasting | 200 | 404 |
| `POST /api/tastings/:id/bookings` | create booking `{name,email,guests}` | 201 `{reference}` | 404 unknown tasting, 422 validation/seat/fully-booked |
| `GET /api/bookings/:reference` | confirmation data | 200 | 404 |
| `POST /api/staff/session` `{password}` | sign in | 204 + cookie | 401 wrong password, 422 empty, 503 not configured, 429 rate-limited |
| `DELETE /api/staff/session` | sign out | 204 | — |
| `GET /api/staff/bookings` | bookings grouped by tasting | 200 | 401 |
| `DELETE /api/staff/bookings/:reference` | cancel | 204 | 401, 404 |

The 503 for an unconfigured password is returned instead of silently accepting anything. The error shape stays the same for all endpoints.

Staff session checks happen in one middleware (`requireStaff`). It verifies the cookie signature (cookie-session), that the session is marked staff, and that `issuedAt` is less than 8 hours old. Expiry is checked server-side as well as by cookie `maxAge`, so a copied cookie cannot be used after 8 hours.

Password comparison hashes both values with SHA-256 and compares with `crypto.timingSafeEqual`, so the comparison does not leak length or prefix information.

### Serving and routing

In production `createApp` serves the built client from `dist/client` with `express.static`, and falls back to `index.html` for any non-`/api` GET so deep links work. The client directory is a parameter so tests can point at a temporary directory.

The client uses `BrowserRouter` with `<Routes>`. Pages fetch through a small hook over `fetch` that exposes loading, error and data states. Route definitions stay readable and no data-router API is needed.

### Cookie security

`secure` is true only when `NODE_ENV=production`, so local `npm start` over plain HTTP still works for staff. Operators behind TLS should set `NODE_ENV=production`. This trade-off is documented in the summary.

### Visual design

A warm, paper-like cream background, deep burgundy primary (wine), muted gold accent, and a serif display face from the system stack (Georgia, "Times New Roman") for headings. No web-font requests, so the app works offline and makes no third-party calls. Cards on the start page; a single-column form on mobile that widens to a card on larger screens; each staff booking is a row that stacks into name/email and guests/reference blocks below 640px, so no horizontal scrolling is needed. States:
- Error: red border on the field, message text beside it, `role="alert"` for form-level errors.
- Success: green confirmation panel with the heading "Booking confirmed".
- Fully booked: grey badge, muted card and title, no booking action.
- Loading: a text placeholder, not a spinner, to keep the markup simple.

## Risks / Trade-offs

- **Data loss on restart** → Accepted by the brief ("starts with no bookings"). Mitigation: all access goes through `BookingStore` so a file or database store can replace it without touching routes.
- **Single-process assumption for atomicity** → Two server processes would oversell. Mitigation: documented; the app runs as one process by design.
- **Staff sessions reset on restart** because the signing key is random per process → Acceptable trade-off for in-memory data; avoids a fixed secret in the repository.
- **Shared password with rate limiting** → Rate limiting slows guessing but does not replace a strong password. The operator sets `STAFF_PASSWORD`.
- **Cookie `secure` tied to `NODE_ENV`** → Misconfiguration over HTTPS leaves the cookie non-secure. Mitigation: documented in the run notes.
- **Tailwind and Vite major versions are new** → Lockfile pins the resolved versions; verification runs the full build and tests.

## Test seams (agreed scope for TDD)

1. `BookingStore` / `service`: domain rules: seat arithmetic, capacity, concurrency-by-construction, cancellation, references, unknown tasting. Plain unit tests, no HTTP.
2. `createApp` via supertest: status codes, error shape, staff authentication, 8-hour expiry, rate limiting, SPA fallback.
3. Client pages rendered with jsdom, with `fetch` stubbed at the network boundary: catalog states, form validation messages next to fields, server error mapping, confirmation content, staff sign-in and grouped list with cancel.
4. End-to-end browser smoke against a real `npm start` process, if a browser can be installed in the container. Otherwise, HTTP-level smoke with curl.

Mocks are limited to `fetch` in client tests and the clock in expiry tests. Server tests use the real store and real Express.

## Open Questions

None that change the specs or task breakdown. Items decided here for the record: total price is shown as whole euros; "1 seats left" is shown literally as "<n> seats left" per the brief.
