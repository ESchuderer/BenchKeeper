# Proposal

## Why

Weingut Kieselbrunnen runs wine tastings for guests but has no online way to book them. Guests need to see what is on offer and reserve seats themselves, and staff need one place to see who is coming and to cancel bookings.

## What Changes

- A public start page listing the upcoming tastings with title, date and time, price per guest and seats left.
- A booking form per tasting (Name, Email, Guests 1-8) that can never take more seats than are left.
- A booking confirmation page showing the heading "Booking confirmed", the tasting, guest count, total price and booking reference.
- A staff area at `/staff`, protected by a password read from the `STAFF_PASSWORD` environment variable, listing all bookings grouped by tasting and allowing a booking to be cancelled, which frees its seats.
- The three tastings from the brief are the initial catalog. Bookings start empty on every process start (in-memory storage).

## Capabilities

### New Capabilities

- `tasting-catalog`: The published list of tastings (title, date and time, price per guest, seat capacity) and the seats-left figure and fully-booked state derived from it.
- `guest-booking`: Guest booking of a tasting: the booking form, validation rules, the seat limit, booking reference, and the confirmation page.
- `staff-bookings`: Staff sign-in with the shared password, the grouped list of bookings, and cancellation of a booking.

### Modified Capabilities

None (no existing specs).

## Impact

- New application: Node.js 22 server (Express) serving a React single-page app (Vite build) and a small JSON API under `/api`.
- New dependencies: express, react, react-dom, react-router, react-hook-form, zod, tailwindcss, vite, typescript, vitest, testing-library, supertest and related tooling.
- No external services, no database. Bookings are held in process memory.
- Configuration: `PORT` (default 3000), `STAFF_PASSWORD` (staff sign-in is disabled when unset).
- Out of scope: payments, email notifications, editing or creating tastings from the UI, multi-user staff accounts, persistence across restarts, internationalisation.
