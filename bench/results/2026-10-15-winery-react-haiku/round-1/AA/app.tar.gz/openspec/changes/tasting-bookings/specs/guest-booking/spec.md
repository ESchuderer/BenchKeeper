# Spec Delta

## Purpose

Lets a guest reserve seats on a tasting through an online form, with validation that keeps every booking within the seats available, and gives the guest a booking reference and confirmation.

## ADDED Requirements

### Requirement: Booking action per tasting
Each tasting with seats left SHALL offer a link or button labelled "Book <tasting title>" (for example "Book Riesling Evening"). Activating it SHALL open the booking form for that tasting.

#### Scenario: Open the booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for "Riesling Evening" is shown

### Requirement: Booking form fields
The booking form SHALL have three fields labelled "Name", "Email" and "Guests", and a button labelled "Book". The Guests field SHALL accept whole numbers from 1 to 8.

#### Scenario: Form shows its fields
- **WHEN** the booking form for any tasting is shown
- **THEN** it shows a field labelled "Name", a field labelled "Email", a field labelled "Guests" and a button labelled "Book"

### Requirement: Input validation with field errors
The system SHALL reject a booking whose input is invalid and SHALL show an error message next to the field it concerns. An invalid booking SHALL NOT be stored and SHALL NOT change the seats left. Name is required and SHALL be at most 100 characters. Email is required and SHALL be a well-formed email address. Guests is required and SHALL be a whole number from 1 to 8.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty Name
- **THEN** the message "Enter your name" is shown next to the Name field
- **AND** no booking is created

#### Scenario: Malformed email
- **WHEN** a guest submits the form with Email "anna@example"
- **THEN** the message "Enter a valid email address" is shown next to the Email field
- **AND** no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits the form with Guests set to 0 or 9
- **THEN** the message "Guests must be between 1 and 8" is shown next to the Guests field
- **AND** no booking is created

#### Scenario: Guests not a whole number
- **WHEN** a guest submits the form with Guests set to "2.5" or "abc"
- **THEN** the message "Guests must be a whole number" is shown next to the Guests field
- **AND** no booking is created

### Requirement: Booking never exceeds seats left
A booking SHALL NOT take more seats than are left for its tasting at the moment the booking is made. When the requested number of guests is greater than the seats left, the system SHALL reject the booking with an error next to the Guests field, and SHALL NOT store it. Two bookings submitted at the same time SHALL NOT together take more seats than are available.

#### Scenario: Request more seats than left
- **WHEN** "Winter Tasting" has 4 seats left and a guest submits 5 guests
- **THEN** the message "Only 4 seats left" is shown next to the Guests field
- **AND** no booking is created and the seats left stay at 4

#### Scenario: Request exactly the seats left
- **WHEN** "Winter Tasting" has 4 seats left and a guest books 4 guests
- **THEN** the booking is confirmed
- **AND** the tasting then shows "0 seats left"

#### Scenario: Booking a fully booked tasting
- **WHEN** a booking is submitted for a tasting with 0 seats left
- **THEN** the booking is rejected with the message "This tasting is fully booked"
- **AND** no booking is created

#### Scenario: Concurrent bookings cannot oversell
- **WHEN** two bookings for 2 guests each are submitted at the same time for a tasting with 3 seats left
- **THEN** exactly one booking is confirmed
- **AND** the other is rejected because only 1 seat is left

### Requirement: Booking reference
Every confirmed booking SHALL receive a booking reference that is unique among all bookings and is shown to the guest.

#### Scenario: Reference issued
- **WHEN** a booking is confirmed
- **THEN** the guest is shown a booking reference
- **AND** no other booking has the same reference

### Requirement: Booking confirmation
After a booking is confirmed, the guest SHALL see a confirmation page with the heading "Booking confirmed", the tasting title, the number of guests, the total price and the booking reference. The total price SHALL be the price per guest multiplied by the number of guests, shown as "EUR <amount>".

#### Scenario: Confirmation content
- **WHEN** a guest books 2 guests for "Red Wine Cellar Tour"
- **THEN** the confirmation page shows the heading "Booking confirmed"
- **AND** it shows "Red Wine Cellar Tour", "2" guests, the total "EUR 64" and the booking reference

#### Scenario: Confirmation can be reopened
- **WHEN** a guest opens the confirmation page for an existing booking reference
- **THEN** the same confirmation details are shown

#### Scenario: Unknown reference
- **WHEN** a guest opens the confirmation page for a reference that does not exist or was cancelled
- **THEN** the page shows the message "Booking not found" and no booking details
