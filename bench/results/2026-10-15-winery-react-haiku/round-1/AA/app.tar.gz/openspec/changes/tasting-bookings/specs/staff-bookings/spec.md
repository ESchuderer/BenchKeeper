# Spec Delta

## Purpose

Gives Weingut Kieselbrunnen staff a password-protected area where they see every booking grouped by tasting and can cancel a booking, freeing its seats.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL show a "Password" field and a "Sign in" button to anyone who is not signed in as staff. The expected password SHALL come from the environment variable `STAFF_PASSWORD`. A correct password SHALL start a staff session, and the staff bookings view SHALL be shown.

#### Scenario: Sign-in page shown
- **WHEN** an unauthenticated visitor opens `/staff`
- **THEN** a "Password" field and a "Sign in" button are shown
- **AND** no booking data is shown

#### Scenario: Correct password
- **WHEN** a visitor submits the correct `STAFF_PASSWORD`
- **THEN** the staff bookings view is shown
- **AND** the staff session survives a page reload

#### Scenario: Wrong password
- **WHEN** a visitor submits a password that does not match `STAFF_PASSWORD`
- **THEN** the message "Incorrect password" is shown next to the Password field
- **AND** no booking data is shown

#### Scenario: Empty password
- **WHEN** a visitor submits an empty Password field
- **THEN** the message "Enter the staff password" is shown next to the Password field

#### Scenario: Sign-in disabled without configuration
- **WHEN** `STAFF_PASSWORD` is not set and a visitor submits any password
- **THEN** the message "Staff sign-in is not configured" is shown
- **AND** no staff session is started

### Requirement: Staff session expiry and sign-out
A staff session SHALL end after 8 hours. Staff SHALL be able to sign out, which ends the session immediately.

#### Scenario: Sign out
- **WHEN** a signed-in staff member activates "Sign out"
- **THEN** the sign-in page is shown
- **AND** reopening `/staff` requires the password again

#### Scenario: Session expired
- **WHEN** a staff session is older than 8 hours
- **THEN** the sign-in page is shown instead of the bookings

### Requirement: Bookings grouped by tasting
The staff bookings view SHALL list all active bookings grouped under their tasting. Each booking SHALL show the guest's name, email, number of guests and booking reference. A tasting with no bookings SHALL show "No bookings yet".

#### Scenario: Bookings grouped
- **WHEN** a signed-in staff member opens the bookings view and bookings exist for two tastings
- **THEN** each booking appears under its own tasting heading
- **AND** each booking shows the name, email, guests and reference

#### Scenario: Tasting without bookings
- **WHEN** a tasting has no bookings
- **THEN** the view shows "No bookings yet" under that tasting

### Requirement: Cancel a booking
Each booking in the staff bookings view SHALL have a "Cancel" button. Cancelling SHALL remove the booking from the view and from the seats-left figure, freeing its seats. The guest's confirmation page for a cancelled booking SHALL no longer show it.

#### Scenario: Cancellation frees seats
- **WHEN** staff cancel a booking for 3 guests on "Winter Tasting" that had 10 seats left
- **THEN** the booking disappears from the staff view
- **AND** "Winter Tasting" shows "10 seats left" on the start page

#### Scenario: Cancelled booking is not reopened
- **WHEN** staff cancel a booking and the guest opens its confirmation page
- **THEN** the page shows "Booking not found"

### Requirement: Staff data requires a session
Staff booking data and the cancel action SHALL be available only with a valid staff session. Requests without a valid session SHALL be refused.

#### Scenario: Unauthenticated list request
- **WHEN** a request for the staff bookings data arrives without a valid staff session
- **THEN** the request is refused with status 401 and no booking data is returned

#### Scenario: Unauthenticated cancel request
- **WHEN** a cancel request arrives without a valid staff session
- **THEN** the request is refused with status 401 and the booking is kept

### Requirement: Sign-in attempts are limited
The system SHALL limit failed staff sign-in attempts per client address to 10 in any 15-minute window. Successful sign-ins SHALL NOT count toward the limit. When the limit is reached, further sign-in attempts from that address SHALL be refused with the message "Too many sign-in attempts. Try again later." until the window passes.

#### Scenario: Repeated wrong passwords are refused
- **WHEN** a client has made 10 failed sign-in attempts within 15 minutes
- **THEN** the next sign-in attempt from that client is refused with the message "Too many sign-in attempts. Try again later."
- **AND** no staff session is started even if the password is correct

#### Scenario: Successful sign-ins do not count
- **WHEN** a client signs in successfully several times within 15 minutes
- **THEN** the client is not refused
