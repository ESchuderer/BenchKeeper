# Spec Delta

## Purpose

Lets guests see the wine tastings Weingut Kieselbrunnen offers, with date, price and the seats still available, so they can choose one to book.

## ADDED Requirements

### Requirement: Start page lists the tastings
The start page SHALL list every tasting in the catalog. For each tasting it SHALL show the title, the date and time, the price per guest and the seats left.

#### Scenario: Catalog shown on the start page
- **WHEN** a guest opens the start page
- **THEN** the page lists "Riesling Evening", "Red Wine Cellar Tour" and "Winter Tasting"
- **AND** each tasting shows its title, date and time, price per guest and seats left

#### Scenario: Dates and prices shown for the initial catalog
- **WHEN** a guest opens the start page
- **THEN** "Riesling Evening" shows Friday, 6 November 2026 at 18:00 and "EUR 25" per guest
- **AND** "Red Wine Cellar Tour" shows Saturday, 14 November 2026 at 15:00 and "EUR 32" per guest
- **AND** "Winter Tasting" shows Saturday, 5 December 2026 at 17:00 and "EUR 28" per guest

### Requirement: Seats left reflects bookings
Each tasting SHALL start with the seat capacity given in the catalog. The seats-left figure SHALL equal capacity minus the total number of guests in active (not cancelled) bookings for that tasting. The figure SHALL be displayed as "<n> seats left".

#### Scenario: Full capacity before any booking
- **WHEN** no bookings exist for "Riesling Evening"
- **THEN** the tasting shows "12 seats left"

#### Scenario: Seats reduced by a booking
- **WHEN** a booking for 3 guests exists for "Riesling Evening"
- **THEN** the tasting shows "9 seats left"

#### Scenario: Seats restored by a cancellation
- **WHEN** the booking for 3 guests is cancelled by staff
- **THEN** the tasting shows "12 seats left" again

### Requirement: Fully booked tastings
When a tasting has zero seats left, the start page SHALL mark it as fully booked and SHALL NOT offer a booking action for it.

#### Scenario: Fully booked tasting shown
- **WHEN** a tasting has 0 seats left
- **THEN** the start page shows the tasting with a "Fully booked" state
- **AND** no "Book <tasting title>" action is offered for that tasting
