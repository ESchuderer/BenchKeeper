# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` (ESM, Node >= 22) with scripts `build`, `start`, `dev`, `test`, `typecheck`, and install runtime dependencies (express, cookie-session, express-rate-limit, helmet, react, react-dom, react-router, react-hook-form, @hookform/resolvers, zod) and dev dependencies (typescript, vite, @vitejs/plugin-react, tailwindcss, @tailwindcss/vite, vitest, jsdom, @testing-library/react, @testing-library/user-event, @testing-library/jest-dom, supertest, and @types packages); verify `npm install` completes without errors
- [x] 1.2 Add `tsconfig.json` (client and tests, `bundler` resolution), `tsconfig.server.json` (emits to `dist/server`, NodeNext), `vite.config.ts` (react and tailwind plugins, output `dist/client`, vitest config), and `src/client/index.css` with Tailwind import; verify `npm run typecheck` and `npm run build` pass on the empty scaffold
- [x] 1.3 Add a smoke test that imports the server and client entry modules' placeholders and runs under `npm test`; verify `npm test` runs and passes

## 2. Shared catalog and validation rules

- [x] 2.1 Implement the static tasting catalog (three tastings with id, title, `startsAt` local date-time, price per guest in whole euros, capacity) and a date formatter producing e.g. "Friday, 6 November 2026 · 18:00"; verify tests check the three tastings against the brief table and the formatter output for each date
- [x] 2.2 Implement `bookingInputSchema` (zod) for name, email and guests with the exact messages from the guest-booking spec (name required and max 100, email format, guests required / whole number / range 1-8) and `createBookingSchema({ seatsLeft })` adding "Only N seats left"; verify a test per message from the spec scenarios, including "0", "9", "2.5", "abc" and empty input

## 3. Booking domain (server)

- [x] 3.1 Implement `BookingStore` with `reserve` (validation, seat check and insertion in one synchronous step), `cancel`, `findByReference`, `listByTasting`, and derived `seatsLeft`; verify tests cover: full capacity at start, seats reduced by a booking, exact fill to 0, rejection of too many guests with the seat count and no change to seats, fully booked rejection, cancellation restoring seats, and two back-to-back reservations that cannot exceed capacity
- [x] 3.2 Implement booking references (`KB-` + 6 unambiguous characters, collision retry) and total price calculation; verify tests check the reference format, uniqueness over at least 1000 generated references, and the total for 2 x EUR 32 = EUR 64
- [x] 3.3 Implement service functions used by routes: list tastings with seats left, get tasting, book (including unknown tasting), get confirmation view, list bookings grouped by tasting (tastings with no bookings included), cancel; verify tests cover each function's result for the initial catalog and after bookings and cancellations

## 4. HTTP API

- [x] 4.1 Implement `GET /api/tastings`, `GET /api/tastings/:id`, `POST /api/tastings/:id/bookings` (201 with reference, 404 unknown, 422 with `errors` object), and `GET /api/bookings/:reference` (404 for unknown or cancelled); verify supertest tests assert status codes, JSON shapes, the `errors` field mapping (name, email, guests, form) and that invalid or over-capacity requests create no booking
- [x] 4.2 Implement staff sign-in: `POST /api/staff/session` (401 wrong password with `errors.password` "Incorrect password", 422 empty with "Enter the staff password", 503 with `errors.form` "Staff sign-in is not configured" when `STAFF_PASSWORD` is unset, 204 with signed HttpOnly cookie on success), `DELETE /api/staff/session`, timing-safe password comparison, and rate limiting on sign-in; verify supertest tests cover each status, that the cookie is HttpOnly, sign-out ends the session, and repeated wrong passwords return 429
- [x] 4.3 Implement `requireStaff` middleware with 8-hour expiry checked against `issuedAt`, and the staff routes `GET /api/staff/bookings` and `DELETE /api/staff/bookings/:reference` (401 without session, 404 for unknown reference, 204 on cancel); verify tests use a faked `Date` to show a session works at 7h59m and is refused at 8h01m, that the unauthenticated list and cancel requests return 401 with no data, and that a successful cancel removes the booking and restores seats in `GET /api/tastings`
- [x] 4.4 Implement server entry (`src/server/index.ts`): read `PORT` (default 3000) and `STAFF_PASSWORD`, log a warning when it is unset, serve `dist/client` with SPA fallback for non-`/api` GET requests, apply helmet, set `secure` cookies when `NODE_ENV=production`; verify tests check that `/tastings/anything` returns `index.html` when the client directory exists, that `/api/unknown` returns 404 JSON rather than HTML, and that `npm start` listens on `PORT`

## 5. Client shell and data access

- [x] 5.1 Implement the API client (`fetch` wrappers returning typed data or a parsed `errors` object) and the `useApi` hook with loading, error and data states; verify tests with stubbed `fetch` check success, network failure and error-body handling
- [x] 5.2 Implement the app shell: router with routes `/`, `/tastings/:id/book`, `/bookings/:reference`, `/staff` and a not-found page; header with the wordmark "Weingut Kieselbrunnen" and footer; Tailwind theme (cream, wine, gold, serif headings) and mobile-first layout; verify tests render each route and a not-found page with a link back to the start page

## 6. Guest pages

- [x] 6.1 Implement the start page: list all tastings with title, date and time, "EUR <n> per guest" and "<n> seats left", a "Book <title>" link for tastings with seats, and a "Fully booked" state with no booking link; verify component tests against stubbed catalog data cover the three tastings, the seat count text (including after a booking reduces it), and the fully-booked state
- [x] 6.2 Implement the booking page: summary of the tasting, fields "Name", "Email", "Guests" (1 to 8) and button "Book"; client validation messages next to each field; server `errors` mapped with `setError` onto the same fields; "This tasting is fully booked" shown instead of the form when seats are 0; navigation to the confirmation on success; verify tests cover each validation message, a server error mapped to the Guests field, the seats-left rejection message, the fully-booked state, and successful submission navigating to `/bookings/<reference>`
- [x] 6.3 Implement the confirmation page: heading "Booking confirmed", tasting title, guest count, total "EUR <amount>", booking reference; "Booking not found" for unknown or cancelled references; verify tests render the confirmation from stubbed data and the not-found state

## 7. Staff pages

- [x] 7.1 Implement the staff sign-in form: "Password" field, "Sign in" button, field error "Incorrect password" or "Enter the staff password" next to the field, form-level error "Staff sign-in is not configured"; on success show the bookings view; verify tests cover each message, that no booking data is rendered before sign-in, and that a successful sign-in shows the bookings view
- [x] 7.2 Implement the staff bookings view: bookings grouped under each tasting heading with name, email, guests and reference; "No bookings yet" for empty tastings; "Cancel" button per booking that removes it from the list; "Sign out"; expired or missing session returns to sign-in; verify tests cover grouping, the empty message, cancel updating the list, sign-out, and the expired-session return to sign-in

## 8. Responsive design and states

- [x] 8.1 Apply responsive styles: single column below 640px, cards and two-column layout above; staff table becomes stacked rows on mobile; visible focus rings and sufficient touch targets (min 44px); verify with a viewport check in a browser at 375px and 1280px widths (or a documented HTTP-level check if no browser is available)

## 9. Integration and verification

- [x] 9.1 Run `npm run typecheck`, `npm test` and `npm run build` from a clean `node_modules`; verify all pass with zero failures
- [x] 9.2 Start the app with `PORT=<free port> STAFF_PASSWORD=<test value> npm start`; verify end-to-end: a guest books Riesling Evening for 3, the start page shows "9 seats left", the confirmation shows "Booking confirmed" with EUR 75; staff signs in, sees the booking under Riesling Evening, cancels it; the start page shows "12 seats left" again
- [x] 9.3 Browser verification of the guest and staff flows (mobile and desktop widths) if a browser can be installed; otherwise verify the same flows over HTTP and record the limitation in the summary

## 10. Review follow-up

- [x] 10.1 Make the client API return a failure, not a rejected promise, when a success response has an unreadable body; verify the api test "returns a failure instead of rejecting when a 200 body is not JSON" passes
- [x] 10.2 Show "We could not sign you out. Please try again." when sign-out fails instead of switching to sign-in; verify the staff page test "does not show sign-in when signing out failed" passes
- [x] 10.3 Count only failed sign-in attempts toward the rate limit and state the limit in the staff-bookings spec; verify staff.test "does not count successful sign-ins toward the limit" passes
- [x] 10.4 Treat an empty PORT as unset and refuse to start, with a message, when the client build is missing; verify config.test and client-build.test pass and that the built server exits with the message when dist/client is absent
- [x] 10.5 Remove unused options and types, rename unclear helpers, drop a stale lint directive; verify typecheck and the full test suite pass

## Workflow follow-up

- Run `openspec validate tasting-bookings --strict` before review.
- Run the code-review skill over the change.
- Archive the change with `openspec archive tasting-bookings` once verification and review are complete.
