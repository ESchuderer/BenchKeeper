import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  cancelBooking,
  createBooking,
  getConfirmation,
  listStaffBookings,
  listTastings,
  signIn,
  signOut,
} from "./api.js";

const NETWORK_MESSAGE =
  "We could not reach the server. Check your connection and try again.";
const GENERIC_MESSAGE = "Something went wrong. Please try again.";

function jsonResponse(status: number, body?: unknown): Response {
  if (body === undefined) return new Response(null, { status });
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

let fetchMock: ReturnType<typeof vi.fn<typeof fetch>>;

beforeEach(() => {
  fetchMock = vi.fn<typeof fetch>();
  vi.stubGlobal("fetch", fetchMock);
});

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("listTastings", () => {
  it("returns the tastings from GET /api/tastings", async () => {
    const tastings = [{ id: "winter-tasting", title: "Winter Tasting", seatsLeft: 10 }];
    fetchMock.mockResolvedValueOnce(jsonResponse(200, tastings));

    const result = await listTastings();

    expect(fetchMock).toHaveBeenCalledWith("/api/tastings", expect.anything());
    expect(result).toEqual({ ok: true, status: 200, data: tastings });
  });
});

describe("responses that cannot be read", () => {
  it("returns a failure instead of rejecting when a 200 body is not JSON", async () => {
    fetchMock.mockResolvedValueOnce(new Response("<html>proxy page</html>", { status: 200 }));

    const result = await listTastings();

    expect(result).toEqual({
      ok: false,
      status: 200,
      errors: { form: GENERIC_MESSAGE },
    });
  });
});

describe("createBooking", () => {
  it("posts the guest details as JSON and returns the reference on 201", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(201, { reference: "KB-7QF3HN" }));

    const result = await createBooking("riesling-evening", {
      name: "Anna",
      email: "anna@example.com",
      guests: "2",
    });

    const [url, init] = fetchMock.mock.calls[0] ?? [];
    expect(url).toBe("/api/tastings/riesling-evening/bookings");
    expect(init?.method).toBe("POST");
    expect(JSON.parse(String(init?.body))).toEqual({
      name: "Anna",
      email: "anna@example.com",
      guests: "2",
    });
    expect(result).toEqual({ ok: true, status: 201, data: { reference: "KB-7QF3HN" } });
  });

  it("returns field errors from a 422 response", async () => {
    fetchMock.mockResolvedValueOnce(
      jsonResponse(422, { errors: { guests: "Only 4 seats left" } }),
    );

    const result = await createBooking("winter-tasting", {
      name: "Anna",
      email: "anna@example.com",
      guests: "5",
    });

    expect(result).toEqual({
      ok: false,
      status: 422,
      errors: { guests: "Only 4 seats left" },
    });
  });

  it("reports a network failure as a form-level error", async () => {
    fetchMock.mockRejectedValueOnce(new TypeError("Failed to fetch"));

    const result = await createBooking("winter-tasting", {
      name: "Anna",
      email: "anna@example.com",
      guests: "2",
    });

    expect(result).toEqual({
      ok: false,
      status: 0,
      errors: { form: NETWORK_MESSAGE },
    });
  });

  it("falls back to a generic message when the error body is not JSON", async () => {
    fetchMock.mockResolvedValueOnce(new Response("<html>oops</html>", { status: 500 }));

    const result = await createBooking("winter-tasting", {
      name: "Anna",
      email: "anna@example.com",
      guests: "2",
    });

    expect(result).toEqual({
      ok: false,
      status: 500,
      errors: { form: GENERIC_MESSAGE },
    });
  });
});

describe("getConfirmation", () => {
  it("reports 404 so the page can show Booking not found", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(404, { error: "Booking not found" }));

    const result = await getConfirmation("KB-NOPE00");

    expect(result).toEqual({
      ok: false,
      status: 404,
      errors: { form: "Booking not found" },
    });
  });
});

describe("staff calls", () => {
  it("signs in with 204 as success", async () => {
    fetchMock.mockResolvedValueOnce(new Response(null, { status: 204 }));
    expect(await signIn("vineyard")).toEqual({ ok: true, status: 204, data: null });
    expect(JSON.parse(String(fetchMock.mock.calls[0]?.[1]?.body))).toEqual({
      password: "vineyard",
    });
  });

  it("returns the password error from a 401 sign-in", async () => {
    fetchMock.mockResolvedValueOnce(
      jsonResponse(401, { errors: { password: "Incorrect password" } }),
    );
    expect(await signIn("wrong")).toEqual({
      ok: false,
      status: 401,
      errors: { password: "Incorrect password" },
    });
  });

  it("signs out with DELETE /api/staff/session", async () => {
    fetchMock.mockResolvedValueOnce(new Response(null, { status: 204 }));
    await signOut();
    expect(fetchMock.mock.calls[0]?.[0]).toBe("/api/staff/session");
    expect(fetchMock.mock.calls[0]?.[1]?.method).toBe("DELETE");
  });

  it("reports 401 when the staff list is requested without a session", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(401, { error: "Staff sign-in required" }));
    const result = await listStaffBookings();
    expect(result.ok).toBe(false);
    expect(result.status).toBe(401);
  });

  it("returns the grouped staff bookings", async () => {
    const groups = [{ tasting: { id: "winter-tasting" }, bookings: [] }];
    fetchMock.mockResolvedValueOnce(jsonResponse(200, groups));
    expect(await listStaffBookings()).toEqual({ ok: true, status: 200, data: groups });
  });

  it("cancels a booking with DELETE and treats 204 as success", async () => {
    fetchMock.mockResolvedValueOnce(new Response(null, { status: 204 }));
    expect(await cancelBooking("KB-7QF3HN")).toEqual({
      ok: true,
      status: 204,
      data: null,
    });
    expect(fetchMock.mock.calls[0]?.[0]).toBe("/api/staff/bookings/KB-7QF3HN");
    expect(fetchMock.mock.calls[0]?.[1]?.method).toBe("DELETE");
  });
});
