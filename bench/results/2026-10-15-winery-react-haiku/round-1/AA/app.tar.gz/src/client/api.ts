import type {
  ApiErrorBody,
  Confirmation,
  FieldErrors,
  StaffTastingBookings,
  TastingView,
} from "../shared/api-types.js";

export type ApiResult<T> =
  | { ok: true; status: number; data: T }
  | { ok: false; status: number; errors: FieldErrors };

const NETWORK_MESSAGE = "We could not reach the server. Check your connection and try again.";
const GENERIC_MESSAGE = "Something went wrong. Please try again.";

async function request<T>(
  path: string,
  init: { method?: string; body?: unknown } = {},
  parse: (res: Response) => Promise<T>,
): Promise<ApiResult<T>> {
  const headers: Record<string, string> = { Accept: "application/json" };
  let body: string | undefined;
  if (init.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(init.body);
  }

  let res: Response;
  try {
    res = await fetch(path, { method: init.method ?? "GET", headers, body });
  } catch {
    return { ok: false, status: 0, errors: { form: NETWORK_MESSAGE } };
  }

  if (res.ok) {
    try {
      return { ok: true, status: res.status, data: await parse(res) };
    } catch {
      // A success status with an unreadable body is still a failure for the page.
      return { ok: false, status: res.status, errors: { form: GENERIC_MESSAGE } };
    }
  }
  return { ok: false, status: res.status, errors: await readErrors(res) };
}

/** Field errors from the body when present, otherwise a single form message. */
async function readErrors(res: Response): Promise<FieldErrors> {
  try {
    const body = (await res.json()) as ApiErrorBody;
    if (body.errors) return body.errors;
    if (body.error) return { form: body.error };
  } catch {
    // Not JSON (for example a proxy error page): fall through to the generic text.
  }
  return { form: GENERIC_MESSAGE };
}

const parseJson = <T>(res: Response) => res.json() as Promise<T>;
const noContent = async () => null;

export function listTastings() {
  return request<TastingView[]>("/api/tastings", {}, parseJson);
}

export function getTasting(id: string) {
  return request<TastingView>(`/api/tastings/${encodeURIComponent(id)}`, {}, parseJson);
}

export function createBooking(
  tastingId: string,
  input: { name: string; email: string; guests: string | number },
) {
  return request<{ reference: string }>(
    `/api/tastings/${encodeURIComponent(tastingId)}/bookings`,
    { method: "POST", body: input },
    parseJson,
  );
}

export function getConfirmation(reference: string) {
  return request<Confirmation>(
    `/api/bookings/${encodeURIComponent(reference)}`,
    {},
    parseJson,
  );
}

export function signIn(password: string) {
  return request<null>(
    "/api/staff/session",
    { method: "POST", body: { password } },
    noContent,
  );
}

export function signOut() {
  return request<null>("/api/staff/session", { method: "DELETE" }, noContent);
}

export function listStaffBookings() {
  return request<StaffTastingBookings[]>("/api/staff/bookings", {}, parseJson);
}

export function cancelBooking(reference: string) {
  return request<null>(
    `/api/staff/bookings/${encodeURIComponent(reference)}`,
    { method: "DELETE" },
    noContent,
  );
}
