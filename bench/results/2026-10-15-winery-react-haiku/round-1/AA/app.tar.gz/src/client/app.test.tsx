/** @vitest-environment jsdom */
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router";
import { describe, expect, it } from "vitest";
import { AppRoutes } from "./router.js";

function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <AppRoutes />
    </MemoryRouter>,
  );
}

describe("app shell", () => {
  it("shows the winery name in the header with a link to the start page", () => {
    renderAt("/no-such-page");

    const brand = screen.getByRole("link", { name: /weingut kieselbrunnen/i });
    expect(brand).toHaveAttribute("href", "/");
    expect(screen.getByText("Family winery")).toBeInTheDocument();
  });

  it("shows a page-not-found message with a way back to the tastings", () => {
    renderAt("/no-such-page");

    expect(screen.getByRole("heading", { name: "Page not found" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Back to the tastings" })).toHaveAttribute(
      "href",
      "/",
    );
  });

  it("offers the staff area from the footer", () => {
    renderAt("/no-such-page");
    expect(screen.getByRole("link", { name: "Staff" })).toHaveAttribute("href", "/staff");
  });
});
