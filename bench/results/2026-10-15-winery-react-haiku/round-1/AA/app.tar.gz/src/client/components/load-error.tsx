type LoadErrorProps = {
  message: string;
  onRetry?: () => void;
};

export function LoadError({ message, onRetry }: LoadErrorProps) {
  return (
    <div role="alert" className="rounded-lg border border-danger/30 bg-danger-soft p-5 text-danger">
      <p className="font-medium">{message}</p>
      {onRetry ? (
        <button
          type="button"
          onClick={onRetry}
          className="mt-3 inline-flex min-h-11 items-center rounded-md border border-danger/40 bg-white px-4 text-sm font-medium text-danger hover:bg-danger-soft"
        >
          Try again
        </button>
      ) : null}
    </div>
  );
}
