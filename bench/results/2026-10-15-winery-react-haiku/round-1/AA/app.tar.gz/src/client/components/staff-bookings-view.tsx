import { useId, useState } from "react";
import { cancelBooking, signOut } from "../api.js";
import type { StaffTastingBookings } from "../../shared/api-types.js";
import { formatSeatsLeft, formatStartsAt } from "../../shared/format.js";

type StaffBookingsViewProps = {
  groups: StaffTastingBookings[];
  /** A booking was cancelled (or was already gone): reload the list. */
  onChanged: () => void;
  /** The session ended while using the page: show sign-in with a notice. */
  onSessionEnded: () => void;
  /** The guest signed out: show sign-in. */
  onSignedOut: () => void;
};

export function StaffBookingsView({
  groups,
  onChanged,
  onSessionEnded,
  onSignedOut,
}: StaffBookingsViewProps) {
  const [pending, setPending] = useState<string>();
  const [actionError, setActionError] = useState<string>();

  async function cancel(reference: string) {
    setPending(reference);
    setActionError(undefined);
    const result = await cancelBooking(reference);
    setPending(undefined);

    if (result.ok || result.status === 404) {
      onChanged();
    } else if (result.status === 401) {
      onSessionEnded();
    } else {
      setActionError("The booking could not be cancelled. Please try again.");
    }
  }

  async function signOutNow() {
    setActionError(undefined);
    const result = await signOut();
    // 401 means the session is already gone, so signing out is complete.
    if (result.ok || result.status === 401) {
      onSignedOut();
      return;
    }
    setActionError("We could not sign you out. Please try again.");
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl text-wine sm:text-4xl">Staff bookings</h1>
          <p className="mt-1 text-sm text-muted">Bookings grouped by tasting.</p>
        </div>
        <button
          type="button"
          onClick={signOutNow}
          className="inline-flex min-h-11 items-center rounded-md border border-line bg-paper px-4 text-sm font-medium text-ink hover:border-gold"
        >
          Sign out
        </button>
      </div>

      {actionError ? (
        <div role="alert" className="rounded-md border border-danger/30 bg-danger-soft px-4 py-3 text-sm font-medium text-danger">
          {actionError}
        </div>
      ) : null}

      {groups.map((group) => (
        <TastingGroup
          key={group.tasting.id}
          group={group}
          pending={pending}
          onCancel={cancel}
        />
      ))}
    </div>
  );
}

function TastingGroup({
  group,
  pending,
  onCancel,
}: {
  group: StaffTastingBookings;
  pending: string | undefined;
  onCancel: (reference: string) => void;
}) {
  const headingId = useId();
  const { tasting, bookings } = group;

  return (
    <section aria-labelledby={headingId} className="space-y-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-line pb-2">
        <h2 id={headingId} className="font-display text-2xl text-wine">
          {tasting.title}
        </h2>
        <p className="text-sm text-muted">
          {formatStartsAt(tasting.startsAt)} · {formatSeatsLeft(tasting.seatsLeft)}
        </p>
      </div>

      {bookings.length === 0 ? (
        <p className="text-muted">No bookings yet</p>
      ) : (
        <ul aria-label={`Bookings for ${tasting.title}`} className="space-y-3">
          {bookings.map((booking) => (
            <li
              key={booking.reference}
              className="grid gap-3 rounded-lg border border-line bg-paper p-4 sm:grid-cols-[1fr_1fr_auto] sm:items-center sm:gap-6"
            >
              <div className="min-w-0">
                <p className="font-medium text-ink">{booking.name}</p>
                <p className="truncate text-sm text-muted">{booking.email}</p>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
                <span className="text-ink">
                  {booking.guests} {booking.guests === 1 ? "guest" : "guests"}
                </span>
                <span className="font-mono text-xs tracking-wide text-muted">{booking.reference}</span>
              </div>
              <div>
                <button
                  type="button"
                  onClick={() => onCancel(booking.reference)}
                  disabled={pending === booking.reference}
                  className="inline-flex min-h-11 w-full items-center justify-center rounded-md border border-danger/40 px-4 text-sm font-medium text-danger hover:bg-danger-soft disabled:cursor-wait disabled:opacity-60 sm:w-auto"
                >
                  Cancel
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
