import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { signIn } from "../api.js";
import { TextField } from "./text-field.js";

const signInSchema = z.object({
  password: z.string().refine((value) => value.trim() !== "", "Enter the staff password"),
});

type SignInValues = z.infer<typeof signInSchema>;

type StaffSignInFormProps = {
  /** Explains why the guest is seeing sign-in again, e.g. an ended session. */
  notice?: string | undefined;
  onSignedIn: () => void;
};

export function StaffSignInForm({ notice, onSignedIn }: StaffSignInFormProps) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<SignInValues>({
    resolver: zodResolver(signInSchema),
    defaultValues: { password: "" },
  });

  const onSubmit = async (values: SignInValues) => {
    const result = await signIn(values.password);
    if (result.ok) {
      onSignedIn();
      return;
    }
    if (result.errors.password) {
      setError("password", { type: "server", message: result.errors.password });
      return;
    }
    setError("root", {
      type: "server",
      message: result.errors.form ?? "We could not sign you in. Please try again.",
    });
  };

  return (
    <section className="mx-auto max-w-sm space-y-6">
      <div className="space-y-2">
        <h1 className="font-display text-3xl text-wine">Staff sign-in</h1>
        <p className="text-sm text-muted">For Weingut Kieselbrunnen staff only.</p>
      </div>

      {notice ? (
        <p role="status" className="rounded-md border border-gold/40 bg-paper px-4 py-3 text-sm text-ink">
          {notice}
        </p>
      ) : null}

      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="space-y-6 rounded-xl border border-line bg-paper p-6 shadow-sm"
      >
        {errors.root?.message ? (
          <div role="alert" className="rounded-md border border-danger/30 bg-danger-soft px-4 py-3 text-sm font-medium text-danger">
            {errors.root.message}
          </div>
        ) : null}

        <TextField
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          {...register("password")}
        />

        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex min-h-11 w-full items-center justify-center rounded-md bg-wine px-6 font-medium text-paper transition hover:bg-wine-dark disabled:cursor-wait disabled:opacity-70"
        >
          {isSubmitting ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </section>
  );
}
