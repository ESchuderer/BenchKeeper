import { Link } from "react-router";
import type { TastingView } from "../../shared/api-types.js";
import { formatEuro, formatSeatsLeft, formatStartsAt } from "../../shared/format.js";

export function TastingCard({ tasting }: { tasting: TastingView }) {
  const soldOut = tasting.seatsLeft === 0;
  const titleId = `tasting-${tasting.id}-title`;

  return (
    <article
      aria-labelledby={titleId}
      className={`flex h-full flex-col rounded-xl border p-6 ${
        soldOut ? "border-line bg-paper/60" : "border-line bg-paper shadow-sm"
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <h2
          id={titleId}
          className={`font-display text-2xl leading-snug ${soldOut ? "text-muted" : "text-wine"}`}
        >
          {tasting.title}
        </h2>
        {soldOut ? (
          <span className="shrink-0 rounded-full bg-muted/15 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-muted">
            Fully booked
          </span>
        ) : null}
      </div>

      <dl className="mt-4 space-y-2 text-sm text-ink">
        <div>
          <dt className="sr-only">Date and time</dt>
          <dd className="font-medium">{formatStartsAt(tasting.startsAt)}</dd>
        </div>
        <div>
          <dt className="sr-only">Price</dt>
          <dd>{formatEuro(tasting.pricePerGuest)} per guest</dd>
        </div>
        <div>
          <dt className="sr-only">Availability</dt>
          <dd className={soldOut ? "text-muted" : "text-success"}>
            {formatSeatsLeft(tasting.seatsLeft)}
          </dd>
        </div>
      </dl>

      <div className="mt-auto pt-6">
        {soldOut ? (
          <p className="text-sm text-muted">This tasting has no seats left.</p>
        ) : (
          <Link
            to={`/tastings/${tasting.id}/book`}
            className="inline-flex min-h-11 w-full items-center justify-center rounded-md bg-wine px-5 font-medium text-paper transition hover:bg-wine-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold sm:w-auto"
          >
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
