import { forwardRef, useId, type InputHTMLAttributes } from "react";

type TextFieldProps = InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  /** Shown under the input while there is no error. */
  hint?: string;
  /** Message for this field; replaces the hint and is announced with the input. */
  error?: string;
};

/**
 * A labelled input with its message wired up: the error (or hint) is the
 * input's accessible description, so screen readers announce it on focus.
 */
export const TextField = forwardRef<HTMLInputElement, TextFieldProps>(function TextField(
  { label, hint, error, id: idProp, className = "", ...inputProps },
  ref,
) {
  const generatedId = useId();
  const id = idProp ?? generatedId;
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = error ? errorId : hint ? hintId : undefined;

  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium text-ink">
        {label}
      </label>
      <input
        ref={ref}
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        className={`block w-full min-h-11 rounded-md border bg-white px-3 py-2 text-base text-ink shadow-sm placeholder:text-muted/70 focus:border-gold focus:outline-none focus:ring-2 focus:ring-gold/40 ${
          error ? "border-danger ring-1 ring-danger/30" : "border-line"
        } ${className}`}
        {...inputProps}
      />
      {error ? (
        <p id={errorId} className="text-sm font-medium text-danger">
          {error}
        </p>
      ) : hint ? (
        <p id={hintId} className="text-sm text-muted">
          {hint}
        </p>
      ) : null}
    </div>
  );
});
