import { Link, Outlet } from "react-router";

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b border-gold/40 bg-paper">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <Link to="/" className="group rounded-sm focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold">
            <span className="font-display block text-xl leading-tight text-wine group-hover:text-wine-dark sm:text-2xl">
              Weingut Kieselbrunnen
            </span>
            <span className="block text-[0.7rem] uppercase tracking-[0.22em] text-muted">
              Family winery
            </span>
          </Link>
          <nav aria-label="Main" className="text-sm font-medium text-ink">
            <Link to="/" className="inline-flex min-h-11 items-center rounded-sm px-2 hover:text-wine focus-visible:outline-2 focus-visible:outline-gold">
              Tastings
            </Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        <Outlet />
      </main>

      <footer className="border-t border-gold/40 bg-paper">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-6 text-sm text-muted sm:px-6">
          <p>Weingut Kieselbrunnen · Wine tastings by reservation</p>
          <Link to="/staff" className="inline-flex min-h-11 items-center rounded-sm underline underline-offset-4 hover:text-wine focus-visible:outline-2 focus-visible:outline-gold">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
