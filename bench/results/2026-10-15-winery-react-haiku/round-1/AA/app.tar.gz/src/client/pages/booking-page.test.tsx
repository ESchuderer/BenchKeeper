/** @vitest-environment jsdom */
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderAppAt } from "../../test/render-app.js";
import { stubApi, tastingFixture } from "../../test/api-stub.js";

const TASTING_PATH = "/api/tastings/riesling-evening";
const BOOKINGS_PATH = "/api/tastings/riesling-evening/bookings";

async function openForm(seatsLeft = 12) {
  stubApi({ [`GET ${TASTING_PATH}`]: { status: 200, body: tastingFixture({ seatsLeft }) } });
  renderAppAt("/tastings/riesling-evening/book");
  await screen.findByRole("heading", { name: "Book Riesling Evening" });
}

async function fill(name: string, email: string, guests: string) {
  const user = userEvent.setup();
  await user.clear(screen.getByLabelText("Name"));
  await user.type(screen.getByLabelText("Name"), name);
  await user.clear(screen.getByLabelText("Email"));
  await user.type(screen.getByLabelText("Email"), email);
  await user.clear(screen.getByLabelText("Guests"));
  await user.type(screen.getByLabelText("Guests"), guests);
  return user;
}

describe("booking page", () => {
  it("shows the tasting summary and the form fields", async () => {
    await openForm(9);

    expect(screen.getByText("Friday, 6 November 2026 at 18:00")).toBeInTheDocument();
    expect(screen.getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(screen.getByText("9 seats left")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("shows a message next to each empty required field", async () => {
    await openForm();
    await userEvent.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Enter your name")).toBeInTheDocument();
    expect(screen.getByText("Enter your email address")).toBeInTheDocument();
    expect(screen.getByText("Enter the number of guests")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toHaveAccessibleDescription("Enter your name");
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription(
      "Enter your email address",
    );
    expect(screen.getByLabelText("Guests")).toHaveAttribute("aria-invalid", "true");
  });

  it("rejects a malformed email next to the Email field", async () => {
    await openForm();
    const user = await fill("Anna Keller", "anna@example", "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Enter a valid email address")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription(
      "Enter a valid email address",
    );
  });

  it.each([
    ["0", "Guests must be between 1 and 8"],
    ["9", "Guests must be between 1 and 8"],
    ["2.5", "Guests must be a whole number"],
  ])("rejects guests %s next to the Guests field", async (guests, message) => {
    await openForm();
    const user = await fill("Anna Keller", "anna@example.com", guests);
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText(message)).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription(message);
  });

  it("does not send a booking that asks for more seats than are left", async () => {
    const { calls } = stubApi({
      [`GET ${TASTING_PATH}`]: { status: 200, body: tastingFixture({ seatsLeft: 4 }) },
    });
    renderAppAt("/tastings/riesling-evening/book");
    await screen.findByRole("heading", { name: "Book Riesling Evening" });

    const user = await fill("Anna Keller", "anna@example.com", "5");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Only 4 seats left")).toBeInTheDocument();
    expect(calls.filter((c) => c.method === "POST")).toHaveLength(0);
  });

  it("shows the server's seat error next to the Guests field", async () => {
    stubApi({
      [`GET ${TASTING_PATH}`]: { status: 200, body: tastingFixture({ seatsLeft: 12 }) },
      [`POST ${BOOKINGS_PATH}`]: { status: 422, body: { errors: { guests: "Only 2 seats left" } } },
    });
    renderAppAt("/tastings/riesling-evening/book");
    await screen.findByRole("heading", { name: "Book Riesling Evening" });

    const user = await fill("Anna Keller", "anna@example.com", "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Only 2 seats left")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription("Only 2 seats left");
  });

  it("shows a form-level error when the tasting filled up while the guest was booking", async () => {
    stubApi({
      [`GET ${TASTING_PATH}`]: { status: 200, body: tastingFixture({ seatsLeft: 12 }) },
      [`POST ${BOOKINGS_PATH}`]: {
        status: 422,
        body: { errors: { form: "This tasting is fully booked" } },
      },
    });
    renderAppAt("/tastings/riesling-evening/book");
    await screen.findByRole("heading", { name: "Book Riesling Evening" });

    const user = await fill("Anna Keller", "anna@example.com", "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "This tasting is fully booked",
    );
  });

  it("sends the guest details and opens the confirmation on success", async () => {
    const { calls } = stubApi({
      [`GET ${TASTING_PATH}`]: { status: 200, body: tastingFixture() },
      [`POST ${BOOKINGS_PATH}`]: { status: 201, body: { reference: "KB-7QF3HN" } },
      "GET /api/bookings/KB-7QF3HN": {
        status: 200,
        body: {
          reference: "KB-7QF3HN",
          tastingId: "riesling-evening",
          tastingTitle: "Riesling Evening",
          startsAt: "2026-11-06T18:00",
          guests: 2,
          pricePerGuest: 25,
          total: 50,
        },
      },
    });
    renderAppAt("/tastings/riesling-evening/book");
    await screen.findByRole("heading", { name: "Book Riesling Evening" });

    const user = await fill("Anna Keller", "anna@example.com", "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(calls.find((c) => c.method === "POST")?.body).toEqual({
      name: "Anna Keller",
      email: "anna@example.com",
      guests: 2,
    });
    expect(screen.getByText("KB-7QF3HN")).toBeInTheDocument();
  });

  it("does not show the form for a fully booked tasting", async () => {
    stubApi({
      [`GET ${TASTING_PATH}`]: { status: 200, body: tastingFixture({ seatsLeft: 0 }) },
    });
    renderAppAt("/tastings/riesling-evening/book");

    expect(await screen.findByText("This tasting is fully booked")).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Book" })).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Back to the tastings" })).toHaveAttribute(
      "href",
      "/",
    );
  });

  it("says so when the tasting does not exist", async () => {
    stubApi({
      "GET /api/tastings/nope": { status: 404, body: { error: "Tasting not found" } },
    });
    renderAppAt("/tastings/nope/book");

    expect(await screen.findByRole("heading", { name: "Tasting not found" })).toBeInTheDocument();
  });

  it("disables the Book button while the booking is being sent", async () => {
    let release: (value: void) => void = () => {};
    const gate = new Promise<void>((resolve) => (release = resolve));
    stubApi({
      [`GET ${TASTING_PATH}`]: { status: 200, body: tastingFixture() },
      [`POST ${BOOKINGS_PATH}`]: async () => {
        await gate;
        return { status: 422, body: { errors: { form: "held" } } };
      },
    });
    renderAppAt("/tastings/riesling-evening/book");
    await screen.findByRole("heading", { name: "Book Riesling Evening" });

    const user = await fill("Anna Keller", "anna@example.com", "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("button", { name: "Booking…" })).toBeDisabled();
    release();
    await waitFor(() => expect(screen.getByRole("button", { name: "Book" })).toBeEnabled());
  });
});
