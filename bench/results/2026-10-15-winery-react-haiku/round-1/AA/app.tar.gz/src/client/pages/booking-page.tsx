import { useMemo } from "react";
import { useForm } from "react-hook-form";
import type { z } from "zod";
import { Link, useNavigate, useParams } from "react-router";
import { zodResolver } from "@hookform/resolvers/zod";
import { createBooking, getTasting } from "../api.js";
import { LoadError } from "../components/load-error.js";
import { TextField } from "../components/text-field.js";
import { createBookingSchema, MAX_GUESTS } from "../../shared/booking-input.js";
import type { FieldErrors, TastingView } from "../../shared/api-types.js";
import { formatEuro, formatSeatsLeft, formatStartsAt } from "../../shared/format.js";
import { useAsync } from "../use-async.js";

export function BookingPage() {
  const { id = "" } = useParams();
  const tasting = useAsync(() => getTasting(id), [id]);

  if (tasting.loading) {
    return <p role="status" className="text-muted">Loading tasting…</p>;
  }
  if (!tasting.result?.ok) {
    if (tasting.result?.status === 404) {
      return (
        <section className="mx-auto max-w-xl space-y-4 text-center">
          <h1 className="font-display text-3xl text-wine">Tasting not found</h1>
          <p className="text-muted">This tasting is not on offer.</p>
          <Link to="/" className="inline-block font-medium text-wine underline underline-offset-4">
            Back to the tastings
          </Link>
        </section>
      );
    }
    return <LoadError message="We could not load this tasting." onRetry={tasting.reload} />;
  }

  return <BookingDetails tasting={tasting.result.data} />;
}

function BookingDetails({ tasting }: { tasting: TastingView }) {
  return (
    <div className="mx-auto max-w-2xl space-y-8">
      <Link to="/" className="inline-block text-sm font-medium text-wine underline underline-offset-4 hover:text-wine-dark">
        Back to the tastings
      </Link>

      <header className="space-y-4">
        <h1 className="font-display text-3xl text-wine sm:text-4xl">Book {tasting.title}</h1>
        <dl className="grid gap-3 rounded-xl border border-line bg-paper p-5 text-sm sm:grid-cols-3">
          <div>
            <dt className="text-muted">Date and time</dt>
            <dd className="font-medium">{formatStartsAt(tasting.startsAt)}</dd>
          </div>
          <div>
            <dt className="text-muted">Price</dt>
            <dd className="font-medium">{formatEuro(tasting.pricePerGuest)} per guest</dd>
          </div>
          <div>
            <dt className="text-muted">Availability</dt>
            <dd className="font-medium text-success">{formatSeatsLeft(tasting.seatsLeft)}</dd>
          </div>
        </dl>
      </header>

      {tasting.seatsLeft === 0 ? (
        <div role="status" className="rounded-xl border border-line bg-paper p-6 text-ink">
          <p className="font-medium">This tasting is fully booked</p>
          <p className="mt-1 text-muted">Please choose another tasting.</p>
        </div>
      ) : (
        <BookingForm tasting={tasting} />
      )}
    </div>
  );
}

type BookingSchema = ReturnType<typeof createBookingSchema>;
/** What the inputs hold (raw strings) and what a valid submission looks like. */
type FormInput = z.input<BookingSchema>;
type FormOutput = z.output<BookingSchema>;

const FIELD_NAMES = ["name", "email", "guests"] as const;
type FieldName = (typeof FIELD_NAMES)[number];

function isFieldName(value: string): value is FieldName {
  return (FIELD_NAMES as readonly string[]).includes(value);
}

function BookingForm({ tasting }: { tasting: TastingView }) {
  const navigate = useNavigate();
  const schema = useMemo(
    () => createBookingSchema({ seatsLeft: tasting.seatsLeft }),
    [tasting.seatsLeft],
  );

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormInput, unknown, FormOutput>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", email: "", guests: "" },
  });

  /** Shows server-side field errors on the same fields as the browser checks. */
  function showServerErrors(serverErrors: FieldErrors) {
    for (const [field, message] of Object.entries(serverErrors)) {
      if (!message) continue;
      if (field === "form") {
        setError("root", { type: "server", message });
      } else if (isFieldName(field)) {
        setError(field, { type: "server", message });
      }
    }
  }

  const onSubmit = async (values: FormOutput) => {
    const result = await createBooking(tasting.id, values);
    if (result.ok) {
      navigate(`/bookings/${result.data.reference}`);
      return;
    }
    showServerErrors(result.errors);
  };

  return (
    <form
      noValidate
      onSubmit={handleSubmit(onSubmit)}
      aria-labelledby="booking-form-title"
      className="space-y-6 rounded-xl border border-line bg-paper p-6 shadow-sm sm:p-8"
    >
      <h2 id="booking-form-title" className="font-display text-xl text-wine">
        Your details
      </h2>

      {errors.root?.message ? (
        <div role="alert" className="rounded-md border border-danger/30 bg-danger-soft px-4 py-3 text-sm font-medium text-danger">
          {errors.root.message}
        </div>
      ) : null}

      <TextField
        label="Name"
        autoComplete="name"
        error={errors.name?.message}
        {...register("name")}
      />
      <TextField
        label="Email"
        type="email"
        autoComplete="email"
        inputMode="email"
        error={errors.email?.message}
        {...register("email")}
      />
      <TextField
        label="Guests"
        inputMode="numeric"
        autoComplete="off"
        hint={`Between 1 and ${MAX_GUESTS} guests`}
        error={errors.guests?.message}
        {...register("guests")}
      />

      <button
        type="submit"
        disabled={isSubmitting}
        className="inline-flex min-h-11 w-full items-center justify-center rounded-md bg-wine px-6 text-base font-medium text-paper transition hover:bg-wine-dark disabled:cursor-wait disabled:opacity-70 sm:w-auto"
      >
        {isSubmitting ? "Booking…" : "Book"}
      </button>
    </form>
  );
}
