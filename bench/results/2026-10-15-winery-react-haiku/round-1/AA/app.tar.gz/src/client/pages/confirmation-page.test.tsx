/** @vitest-environment jsdom */
import { screen, within } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { renderAppAt } from "../../test/render-app.js";
import { stubApi } from "../../test/api-stub.js";

const confirmation = {
  reference: "KB-7QF3HN",
  tastingId: "red-wine-cellar-tour",
  tastingTitle: "Red Wine Cellar Tour",
  startsAt: "2026-11-14T15:00",
  guests: 2,
  pricePerGuest: 32,
  total: 64,
};

describe("confirmation page", () => {
  it("shows the heading, tasting, guests, total price and booking reference", async () => {
    stubApi({
      "GET /api/bookings/KB-7QF3HN": { status: 200, body: confirmation },
    });

    renderAppAt("/bookings/KB-7QF3HN");

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    const details = screen.getByRole("list", { name: "Booking details" });
    expect(within(details).getByText("Red Wine Cellar Tour")).toBeInTheDocument();
    expect(within(details).getByText("Saturday, 14 November 2026 at 15:00")).toBeInTheDocument();
    expect(within(details).getByText("2")).toBeInTheDocument();
    expect(within(details).getByText("EUR 64")).toBeInTheDocument();
    expect(within(details).getByText("KB-7QF3HN")).toBeInTheDocument();
  });

  it("says Booking not found for an unknown or cancelled reference", async () => {
    stubApi({
      "GET /api/bookings/KB-NOPE00": { status: 404, body: { error: "Booking not found" } },
    });

    renderAppAt("/bookings/KB-NOPE00");

    expect(await screen.findByRole("heading", { name: "Booking not found" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Booking confirmed" })).not.toBeInTheDocument();
    expect(screen.queryByText("EUR 64")).not.toBeInTheDocument();
  });

  it("offers a way back to the tastings", async () => {
    stubApi({
      "GET /api/bookings/KB-7QF3HN": { status: 200, body: confirmation },
    });

    renderAppAt("/bookings/KB-7QF3HN");

    await screen.findByRole("heading", { name: "Booking confirmed" });
    expect(screen.getByRole("link", { name: "Back to the tastings" })).toHaveAttribute(
      "href",
      "/",
    );
  });
});
