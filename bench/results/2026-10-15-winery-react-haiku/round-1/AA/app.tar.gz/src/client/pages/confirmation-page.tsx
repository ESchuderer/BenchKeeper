import { Link, useParams } from "react-router";
import { getConfirmation } from "../api.js";
import { LoadError } from "../components/load-error.js";
import { formatEuro, formatStartsAt } from "../../shared/format.js";
import { useAsync } from "../use-async.js";

export function ConfirmationPage() {
  const { reference = "" } = useParams();
  const booking = useAsync(() => getConfirmation(reference), [reference]);

  if (booking.loading) {
    return <p role="status" className="text-muted">Loading your booking…</p>;
  }

  if (!booking.result?.ok) {
    if (booking.result?.status === 404) {
      return (
        <section className="mx-auto max-w-xl space-y-4 text-center">
          <h1 className="font-display text-3xl text-wine">Booking not found</h1>
          <p className="text-muted">
            We could not find a booking with this reference. It may have been cancelled.
          </p>
          <Link to="/" className="inline-block font-medium text-wine underline underline-offset-4">
            Back to the tastings
          </Link>
        </section>
      );
    }
    return <LoadError message="We could not load your booking." onRetry={booking.reload} />;
  }

  const details = booking.result.data;
  const rows: Array<[string, string]> = [
    ["Tasting", details.tastingTitle],
    ["Date and time", formatStartsAt(details.startsAt)],
    ["Guests", String(details.guests)],
    ["Total price", formatEuro(details.total)],
    ["Booking reference", details.reference],
  ];

  return (
    <section className="mx-auto max-w-xl space-y-8">
      <div className="space-y-3 rounded-xl border border-success/30 bg-success-soft p-6 sm:p-8">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-success">Thank you</p>
        <h1 className="font-display text-3xl text-wine sm:text-4xl">Booking confirmed</h1>
        <p className="text-ink">
          We look forward to welcoming you. Please keep your booking reference.
        </p>
      </div>

      <ul aria-label="Booking details" className="divide-y divide-line rounded-xl border border-line bg-paper">
        {rows.map(([label, value]) => (
          <li key={label} className="flex flex-wrap items-baseline justify-between gap-2 px-5 py-4">
            <span className="text-sm text-muted">{label}</span>
            <span className="font-medium text-ink">{value}</span>
          </li>
        ))}
      </ul>

      <p>
        <Link to="/" className="font-medium text-wine underline underline-offset-4 hover:text-wine-dark">
          Back to the tastings
        </Link>
      </p>
    </section>
  );
}
