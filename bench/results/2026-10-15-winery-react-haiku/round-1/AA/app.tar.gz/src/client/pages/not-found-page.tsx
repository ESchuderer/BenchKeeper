import { Link } from "react-router";

export function NotFoundPage() {
  return (
    <section className="mx-auto max-w-xl text-center">
      <h1 className="font-display text-3xl text-wine sm:text-4xl">Page not found</h1>
      <p className="mt-4 text-muted">The page you were looking for does not exist.</p>
      <p className="mt-8">
        <Link to="/" className="font-medium text-wine underline underline-offset-4 hover:text-wine-dark">
          Back to the tastings
        </Link>
      </p>
    </section>
  );
}
