/** @vitest-environment jsdom */
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderAppAt } from "../../test/render-app.js";
import { stubApi, tastingFixture, type StubRoute } from "../../test/api-stub.js";

const SIGNED_OUT: StubRoute = {
  status: 401,
  body: { error: "Staff sign-in required" },
};

const groupsWithBookings = [
  {
    tasting: tastingFixture({ seatsLeft: 9 }),
    bookings: [
      {
        reference: "KB-7QF3HN",
        name: "Anna Keller",
        email: "anna@example.com",
        guests: 3,
      },
    ],
  },
  {
    tasting: tastingFixture({
      id: "winter-tasting",
      title: "Winter Tasting",
      startsAt: "2026-12-05T17:00",
      pricePerGuest: 28,
      capacity: 10,
      seatsLeft: 10,
    }),
    bookings: [],
  },
];

function signInPage(overrides: Record<string, StubRoute> = {}) {
  return stubApi({
    "GET /api/staff/bookings": SIGNED_OUT,
    ...overrides,
  });
}

async function signIn(password: string) {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText("Password"), password);
  await user.click(screen.getByRole("button", { name: "Sign in" }));
  return user;
}

describe("staff sign-in", () => {
  it("asks for the password and shows no booking data", async () => {
    signInPage();

    renderAppAt("/staff");

    expect(await screen.findByRole("heading", { name: "Staff sign-in" })).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toHaveAttribute("type", "password");
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
    expect(screen.queryByText("Riesling Evening")).not.toBeInTheDocument();
  });

  it("shows sign-in, not the bookings, when the session has expired before the page loads", async () => {
    stubApi({
      "GET /api/staff/bookings": SIGNED_OUT,
    });

    renderAppAt("/staff");

    expect(await screen.findByRole("heading", { name: "Staff sign-in" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Staff bookings" })).not.toBeInTheDocument();
    expect(screen.queryByText("Riesling Evening")).not.toBeInTheDocument();
  });

  it("asks for a password when the field is empty, without contacting the server", async () => {
    const { calls } = signInPage();
    renderAppAt("/staff");

    await screen.findByLabelText("Password");
    await userEvent.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByText("Enter the staff password")).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toHaveAccessibleDescription(
      "Enter the staff password",
    );
    expect(calls.filter((c) => c.method === "POST")).toHaveLength(0);
  });

  it("shows Incorrect password next to the Password field", async () => {
    signInPage({
      "POST /api/staff/session": {
        status: 401,
        body: { errors: { password: "Incorrect password" } },
      },
    });
    renderAppAt("/staff");

    await signIn("guess");

    expect(await screen.findByText("Incorrect password")).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toHaveAccessibleDescription("Incorrect password");
  });

  it("explains when staff sign-in is not configured", async () => {
    signInPage({
      "POST /api/staff/session": {
        status: 503,
        body: { errors: { form: "Staff sign-in is not configured" } },
      },
    });
    renderAppAt("/staff");

    await signIn("anything");

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Staff sign-in is not configured",
    );
  });

  it("shows the bookings after a correct password", async () => {
    let signedIn = false;
    stubApi({
      "GET /api/staff/bookings": () =>
        signedIn ? { status: 200, body: groupsWithBookings } : SIGNED_OUT,
      "POST /api/staff/session": () => {
        signedIn = true;
        return { status: 204 };
      },
    });
    renderAppAt("/staff");

    await signIn("vineyard");

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
  });
});

describe("staff bookings", () => {
  it("shows each booking under its tasting with name, email, guests and reference", async () => {
    stubApi({
      "GET /api/staff/bookings": { status: 200, body: groupsWithBookings },
    });

    renderAppAt("/staff");

    const list = await screen.findByRole("list", { name: "Bookings for Riesling Evening" });
    const row = within(list).getByRole("listitem");
    expect(within(row).getByText("Anna Keller")).toBeInTheDocument();
    expect(within(row).getByText("anna@example.com")).toBeInTheDocument();
    expect(within(row).getByText("3 guests")).toBeInTheDocument();
    expect(within(row).getByText("KB-7QF3HN")).toBeInTheDocument();
    expect(within(row).getByRole("button", { name: "Cancel" })).toBeInTheDocument();
  });

  it("says No bookings yet for a tasting without bookings", async () => {
    stubApi({
      "GET /api/staff/bookings": { status: 200, body: groupsWithBookings },
    });

    renderAppAt("/staff");

    const winter = await screen.findByRole("region", { name: "Winter Tasting" });
    expect(within(winter).getByText("No bookings yet")).toBeInTheDocument();
  });

  it("removes a booking when it is cancelled, which frees its seats", async () => {
    let groups = structuredClone(groupsWithBookings);
    const { calls } = stubApi({
      "GET /api/staff/bookings": () => ({ status: 200, body: groups }),
      "DELETE /api/staff/bookings/KB-7QF3HN": () => {
        groups = structuredClone(groupsWithBookings).map((group) =>
          group.tasting.id === "riesling-evening"
            ? { ...group, bookings: [] }
            : group,
        );
        return { status: 204 };
      },
    });
    renderAppAt("/staff");

    const list = await screen.findByRole("list", { name: "Bookings for Riesling Evening" });
    await userEvent.click(within(list).getByRole("button", { name: "Cancel" }));

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    await waitFor(() =>
      expect(within(riesling).getByText("No bookings yet")).toBeInTheDocument(),
    );
    expect(screen.queryByText("Anna Keller")).not.toBeInTheDocument();
    expect(calls.some((c) => c.method === "DELETE")).toBe(true);
  });

  it("returns to sign-in with a notice when the session ended during cancellation", async () => {
    let sessionActive = true;
    stubApi({
      "GET /api/staff/bookings": () =>
        sessionActive ? { status: 200, body: groupsWithBookings } : SIGNED_OUT,
      "DELETE /api/staff/bookings/KB-7QF3HN": () => {
        sessionActive = false;
        return { status: 401, body: { error: "Staff sign-in required" } };
      },
    });
    renderAppAt("/staff");

    const list = await screen.findByRole("list", { name: "Bookings for Riesling Evening" });
    await userEvent.click(within(list).getByRole("button", { name: "Cancel" }));

    expect(await screen.findByRole("heading", { name: "Staff sign-in" })).toBeInTheDocument();
    expect(
      screen.getByText("Your staff session has ended. Please sign in again."),
    ).toBeInTheDocument();
  });

  it("shows an error when a booking cannot be cancelled", async () => {
    stubApi({
      "GET /api/staff/bookings": { status: 200, body: groupsWithBookings },
      "DELETE /api/staff/bookings/KB-7QF3HN": { status: 500, body: {} },
    });
    renderAppAt("/staff");

    const list = await screen.findByRole("list", { name: "Bookings for Riesling Evening" });
    await userEvent.click(within(list).getByRole("button", { name: "Cancel" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "The booking could not be cancelled. Please try again.",
    );
    expect(within(list).getByRole("listitem")).toBeInTheDocument();
  });

  it("stays signed in after a reload while the session is valid", async () => {
    const { calls } = stubApi({
      "GET /api/staff/bookings": { status: 200, body: groupsWithBookings },
    });

    renderAppAt("/staff");

    expect(await screen.findByRole("heading", { name: "Staff bookings" })).toBeInTheDocument();
    expect(screen.queryByLabelText("Password")).not.toBeInTheDocument();
    expect(calls.some((c) => c.method === "POST")).toBe(false);
  });

  it("does not show sign-in when signing out failed, because the session may still be valid", async () => {
    stubApi({
      "GET /api/staff/bookings": { status: 200, body: groupsWithBookings },
      "DELETE /api/staff/session": () => {
        throw new TypeError("Failed to fetch");
      },
    });
    renderAppAt("/staff");

    await userEvent.click(await screen.findByRole("button", { name: "Sign out" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "We could not sign you out. Please try again.",
    );
    expect(screen.getByRole("heading", { name: "Staff bookings" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Staff sign-in" })).not.toBeInTheDocument();
  });

  it("signs out and returns to the sign-in page", async () => {
    let signedIn = true;
    stubApi({
      "GET /api/staff/bookings": () =>
        signedIn ? { status: 200, body: groupsWithBookings } : SIGNED_OUT,
      "DELETE /api/staff/session": () => {
        signedIn = false;
        return { status: 204 };
      },
    });
    renderAppAt("/staff");

    await userEvent.click(await screen.findByRole("button", { name: "Sign out" }));

    expect(await screen.findByRole("heading", { name: "Staff sign-in" })).toBeInTheDocument();
    expect(screen.queryByText("Riesling Evening")).not.toBeInTheDocument();
  });
});
