import { useState } from "react";
import { listStaffBookings } from "../api.js";
import { LoadError } from "../components/load-error.js";
import { StaffBookingsView } from "../components/staff-bookings-view.js";
import { StaffSignInForm } from "../components/staff-sign-in-form.js";
import { useAsync } from "../use-async.js";

const SESSION_ENDED = "Your staff session has ended. Please sign in again.";

export function StaffPage() {
  const [notice, setNotice] = useState<string>();
  const bookings = useAsync(listStaffBookings, []);
  const result = bookings.result;

  // Keep showing the list while it reloads, so cancelling does not flicker.
  if (result?.ok) {
    return (
      <StaffBookingsView
        groups={result.data}
        onChanged={bookings.reload}
        onSessionEnded={() => {
          setNotice(SESSION_ENDED);
          bookings.reload();
        }}
        onSignedOut={() => {
          setNotice(undefined);
          bookings.reload();
        }}
      />
    );
  }

  if (result?.status === 401) {
    return (
      <StaffSignInForm
        notice={notice}
        onSignedIn={() => {
          setNotice(undefined);
          bookings.reload();
        }}
      />
    );
  }

  if (bookings.loading) {
    return <p role="status" className="text-muted">Loading…</p>;
  }

  return <LoadError message="We could not load the bookings." onRetry={bookings.reload} />;
}
