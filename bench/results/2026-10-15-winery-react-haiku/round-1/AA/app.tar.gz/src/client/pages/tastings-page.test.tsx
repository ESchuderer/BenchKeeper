/** @vitest-environment jsdom */
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderAppAt } from "../../test/render-app.js";
import { stubApi, tastingFixture } from "../../test/api-stub.js";

const catalog = [
  tastingFixture(),
  tastingFixture({
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00",
    pricePerGuest: 32,
    capacity: 8,
    seatsLeft: 8,
  }),
  tastingFixture({
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00",
    pricePerGuest: 28,
    capacity: 10,
    seatsLeft: 10,
  }),
];

describe("start page", () => {
  it("lists each tasting with date and time, price per guest and seats left", async () => {
    stubApi({ "GET /api/tastings": { status: 200, body: catalog } });

    renderAppAt("/");

    const riesling = await screen.findByRole("article", { name: "Riesling Evening" });
    expect(within(riesling).getByText("Friday, 6 November 2026 at 18:00")).toBeInTheDocument();
    expect(within(riesling).getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(within(riesling).getByText("12 seats left")).toBeInTheDocument();

    const red = screen.getByRole("article", { name: "Red Wine Cellar Tour" });
    expect(within(red).getByText("Saturday, 14 November 2026 at 15:00")).toBeInTheDocument();
    expect(within(red).getByText("EUR 32 per guest")).toBeInTheDocument();
    expect(within(red).getByText("8 seats left")).toBeInTheDocument();

    const winter = screen.getByRole("article", { name: "Winter Tasting" });
    expect(within(winter).getByText("Saturday, 5 December 2026 at 17:00")).toBeInTheDocument();
    expect(within(winter).getByText("EUR 28 per guest")).toBeInTheDocument();
    expect(within(winter).getByText("10 seats left")).toBeInTheDocument();
  });

  it("offers a Book link for each tasting with seats left", async () => {
    stubApi({ "GET /api/tastings": { status: 200, body: catalog } });

    renderAppAt("/");

    expect(
      await screen.findByRole("link", { name: "Book Riesling Evening" }),
    ).toHaveAttribute("href", "/tastings/riesling-evening/book");
    expect(screen.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Book Winter Tasting" })).toBeInTheDocument();
  });

  it("opens the booking form for a tasting when its Book link is activated", async () => {
    stubApi({
      "GET /api/tastings": { status: 200, body: catalog },
      "GET /api/tastings/riesling-evening": { status: 200, body: catalog[0] },
    });

    renderAppAt("/");
    await userEvent.click(await screen.findByRole("link", { name: "Book Riesling Evening" }));

    expect(await screen.findByRole("heading", { name: "Book Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toBeInTheDocument();
  });

  it("shows a fully booked tasting without any booking action", async () => {
    stubApi({
      "GET /api/tastings": {
        status: 200,
        body: [tastingFixture({ seatsLeft: 0 })],
      },
    });

    renderAppAt("/");

    const card = await screen.findByRole("article", { name: "Riesling Evening" });
    expect(within(card).getByText("Fully booked")).toBeInTheDocument();
    expect(within(card).getByText("0 seats left")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /^Book / })).not.toBeInTheDocument();
  });

  it("shows a loading message while the catalog loads", async () => {
    stubApi({ "GET /api/tastings": { status: 200, body: catalog } });

    renderAppAt("/");

    expect(screen.getByText("Loading tastings…")).toBeInTheDocument();
    await screen.findByRole("article", { name: "Riesling Evening" });
    expect(screen.queryByText("Loading tastings…")).not.toBeInTheDocument();
  });

  it("shows an error with a retry button when the catalog cannot load", async () => {
    let attempts = 0;
    const { calls } = stubApi({
      "GET /api/tastings": () => {
        attempts++;
        return attempts === 1
          ? { status: 500, body: { error: "boom" } }
          : { status: 200, body: catalog };
      },
    });

    renderAppAt("/");

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "We could not load the tastings.",
    );
    await userEvent.click(screen.getByRole("button", { name: "Try again" }));

    await screen.findByRole("article", { name: "Riesling Evening" });
    await waitFor(() => expect(calls).toHaveLength(2));
  });
});
