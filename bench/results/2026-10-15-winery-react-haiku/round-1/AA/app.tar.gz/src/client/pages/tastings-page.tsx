import { listTastings } from "../api.js";
import { LoadError } from "../components/load-error.js";
import { TastingCard } from "../components/tasting-card.js";
import { useAsync } from "../use-async.js";

export function TastingsPage() {
  const catalog = useAsync(listTastings, []);

  return (
    <div className="space-y-8">
      <header className="max-w-2xl space-y-3">
        <h1 className="font-display text-3xl text-wine sm:text-4xl">Wine tastings</h1>
        <p className="text-muted">
          Reserve your seats online for an evening or an afternoon at the estate.
        </p>
      </header>

      {catalog.loading ? (
        <p role="status" className="text-muted">
          Loading tastings…
        </p>
      ) : catalog.result?.ok ? (
        <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {catalog.result.data.map((tasting) => (
            <li key={tasting.id}>
              <TastingCard tasting={tasting} />
            </li>
          ))}
        </ul>
      ) : (
        <LoadError message="We could not load the tastings." onRetry={catalog.reload} />
      )}
    </div>
  );
}
