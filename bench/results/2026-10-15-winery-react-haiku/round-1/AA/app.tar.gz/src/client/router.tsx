import { Route, Routes } from "react-router";
import { Layout } from "./layout.js";
import { BookingPage } from "./pages/booking-page.js";
import { ConfirmationPage } from "./pages/confirmation-page.js";
import { NotFoundPage } from "./pages/not-found-page.js";
import { StaffPage } from "./pages/staff-page.js";
import { TastingsPage } from "./pages/tastings-page.js";

/** All client routes. */
export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingsPage />} />
        <Route path="tastings/:id/book" element={<BookingPage />} />
        <Route path="bookings/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
