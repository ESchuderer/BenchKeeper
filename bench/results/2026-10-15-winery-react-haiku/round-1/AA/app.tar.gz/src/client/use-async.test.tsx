/** @vitest-environment jsdom */
import { act, renderHook, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import type { ApiResult } from "./api.js";
import { useAsync } from "./use-async.js";

const ok = (data: string): ApiResult<string> => ({ ok: true, status: 200, data });

describe("useAsync", () => {
  it("starts loading, then exposes the result", async () => {
    const load = vi.fn(async () => ok("tastings"));

    const { result } = renderHook(() => useAsync(load, []));

    expect(result.current.loading).toBe(true);
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.result).toEqual(ok("tastings"));
  });

  it("loads again when reload is called", async () => {
    let call = 0;
    const load = vi.fn(async () => ok(`value ${++call}`));

    const { result } = renderHook(() => useAsync(load, []));
    await waitFor(() => expect(result.current.result).toEqual(ok("value 1")));

    act(() => result.current.reload());

    await waitFor(() => expect(result.current.result).toEqual(ok("value 2")));
    expect(load).toHaveBeenCalledTimes(2);
  });

  it("ignores a response that arrives after the inputs changed", async () => {
    let resolveFirst: (value: ApiResult<string>) => void = () => {};
    const first = new Promise<ApiResult<string>>((resolve) => (resolveFirst = resolve));
    const { result, rerender } = renderHook(
      ({ id }: { id: string }) =>
        useAsync(() => (id === "a" ? first : Promise.resolve(ok("b"))), [id]),
      { initialProps: { id: "a" } },
    );

    rerender({ id: "b" });
    await waitFor(() => expect(result.current.result).toEqual(ok("b")));

    await act(async () => resolveFirst(ok("stale")));
    expect(result.current.result).toEqual(ok("b"));
  });
});
