import { useCallback, useEffect, useState, type DependencyList } from "react";
import type { ApiResult } from "./api.js";

export type AsyncState<T> = {
  loading: boolean;
  result: ApiResult<T> | undefined;
  reload: () => void;
};

/**
 * Runs an API call when `deps` change and exposes its result. A response that
 * arrives after the inputs changed (or after unmount) is discarded.
 */
export function useAsync<T>(
  load: () => Promise<ApiResult<T>>,
  deps: DependencyList,
): AsyncState<T> {
  const [version, setVersion] = useState(0);
  const [state, setState] = useState<{ loading: boolean; result?: ApiResult<T> }>({
    loading: true,
  });

  useEffect(() => {
    let active = true;
    setState((previous) => ({ ...previous, loading: true }));
    load().then((result) => {
      if (active) setState({ loading: false, result });
    });
    return () => {
      active = false;
    };
    // The caller controls when the request reruns through `deps` and `reload`.
  }, [...deps, version]);

  const reload = useCallback(() => setVersion((v) => v + 1), []);
  return { loading: state.loading, result: state.result, reload };
}
