import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "./app.js";

const guest = (overrides: Record<string, unknown> = {}) => ({
  name: "Anna Keller",
  email: "anna@example.com",
  guests: 2,
  ...overrides,
});

describe("GET /api/tastings", () => {
  it("lists the three tastings with seats left", async () => {
    const res = await request(createApp()).get("/api/tastings");

    expect(res.status).toBe(200);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body.map((t: { title: string }) => t.title)).toEqual([
      "Riesling Evening",
      "Red Wine Cellar Tour",
      "Winter Tasting",
    ]);
    expect(res.body[0]).toMatchObject({
      id: "riesling-evening",
      startsAt: "2026-11-06T18:00",
      pricePerGuest: 25,
      capacity: 12,
      seatsLeft: 12,
    });
  });
});

describe("GET /api/tastings/:id", () => {
  it("returns one tasting", async () => {
    const res = await request(createApp()).get("/api/tastings/winter-tasting");
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ title: "Winter Tasting", seatsLeft: 10 });
  });

  it("returns 404 JSON for an unknown tasting", async () => {
    const res = await request(createApp()).get("/api/tastings/nope");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Tasting not found" });
  });
});

describe("POST /api/tastings/:id/bookings", () => {
  it("creates a booking and returns its reference with 201", async () => {
    const app = createApp();
    const res = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send(guest({ guests: 3 }));

    expect(res.status).toBe(201);
    expect(res.body.reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);

    const catalog = await request(app).get("/api/tastings/riesling-evening");
    expect(catalog.body.seatsLeft).toBe(9);
  });

  it("accepts guests sent as a string, as the form does", async () => {
    const res = await request(createApp())
      .post("/api/tastings/riesling-evening/bookings")
      .send(guest({ guests: "2" }));
    expect(res.status).toBe(201);
  });

  it("returns 422 with field errors and stores nothing for invalid input", async () => {
    const app = createApp();
    const res = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send(guest({ name: " ", email: "anna@example", guests: 0 }));

    expect(res.status).toBe(422);
    expect(res.body).toEqual({
      errors: {
        name: "Enter your name",
        email: "Enter a valid email address",
        guests: "Guests must be between 1 and 8",
      },
    });
    const catalog = await request(app).get("/api/tastings/riesling-evening");
    expect(catalog.body.seatsLeft).toBe(12);
  });

  it("rejects more guests than seats left with the message on guests", async () => {
    const app = createApp();
    await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send(guest({ guests: 6 }));

    const res = await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send(guest({ guests: 5 }));

    expect(res.status).toBe(422);
    expect(res.body).toEqual({ errors: { guests: "Only 4 seats left" } });
  });

  it("rejects a booking for a fully booked tasting with a form-level error", async () => {
    const app = createApp();
    await request(app)
      .post("/api/tastings/red-wine-cellar-tour/bookings")
      .send(guest({ guests: 8 }));

    const res = await request(app)
      .post("/api/tastings/red-wine-cellar-tour/bookings")
      .send(guest({ guests: 1 }));

    expect(res.status).toBe(422);
    expect(res.body).toEqual({
      errors: { form: "This tasting is fully booked" },
    });
  });

  it("returns 404 for an unknown tasting", async () => {
    const res = await request(createApp())
      .post("/api/tastings/nope/bookings")
      .send(guest());
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Tasting not found" });
  });

  it("lets only one of two simultaneous requests take the last seats", async () => {
    const app = createApp();
    await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send(guest({ guests: 7 }));

    const [a, b] = await Promise.all([
      request(app).post("/api/tastings/winter-tasting/bookings").send(guest({ guests: 2 })),
      request(app).post("/api/tastings/winter-tasting/bookings").send(guest({ guests: 2 })),
    ]);

    expect([a.status, b.status].sort()).toEqual([201, 422]);
    const catalog = await request(app).get("/api/tastings/winter-tasting");
    expect(catalog.body.seatsLeft).toBe(1);
  });

  it("returns JSON 400 for a body that is not valid JSON", async () => {
    const res = await request(createApp())
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "application/json")
      .send("{not json");
    expect(res.status).toBe(400);
    expect(res.body).toEqual({ error: "Request body is not valid JSON" });
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the confirmation details", async () => {
    const app = createApp();
    const created = await request(app)
      .post("/api/tastings/red-wine-cellar-tour/bookings")
      .send(guest({ guests: 2 }));

    const res = await request(app).get(`/api/bookings/${created.body.reference}`);

    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      reference: created.body.reference,
      tastingId: "red-wine-cellar-tour",
      tastingTitle: "Red Wine Cellar Tour",
      startsAt: "2026-11-14T15:00",
      guests: 2,
      pricePerGuest: 32,
      total: 64,
    });
  });

  it("returns 404 for an unknown reference", async () => {
    const res = await request(createApp()).get("/api/bookings/KB-NOPE00");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Booking not found" });
  });
});

describe("unknown API routes", () => {
  it("return JSON 404, not an HTML page", async () => {
    const res = await request(createApp()).get("/api/does-not-exist");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Not found" });
  });
});
