import { randomBytes } from "node:crypto";
import { join } from "node:path";
import express, { type NextFunction, type Request, type Response } from "express";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import { BookingStore } from "./bookings.js";
import { createBookingService } from "./service.js";
import {
  createStaffSessionMiddleware,
  endStaffSession,
  passwordMatches,
  requireStaff,
  startStaffSession,
} from "./staff-auth.js";

export type AppOptions = {
  /** The staff password. When empty or undefined, staff sign-in is refused. */
  staffPassword?: string | undefined;
  /** Mark the staff cookie Secure (use over HTTPS). */
  secureCookies?: boolean;
  /** Directory with the built React app. Omit to serve the API only. */
  clientDir?: string;
  /** Sign-in attempts allowed per window, per client address. */
  loginRateLimit?: { limit: number; windowMs: number };
};

const DEFAULT_LOGIN_RATE_LIMIT = { limit: 10, windowMs: 15 * 60 * 1000 };

export function createApp(options: AppOptions = {}) {
  const service = createBookingService({ store: new BookingStore() });
  const staffPassword = options.staffPassword ?? "";
  // Signing key for the staff cookie: random per process, so a restart signs staff out.
  const sessionKeys = [randomBytes(32).toString("hex")];
  const loginLimit = options.loginRateLimit ?? DEFAULT_LOGIN_RATE_LIMIT;

  const app = express();
  app.disable("x-powered-by");
  app.use(helmet());
  app.use(express.json({ limit: "10kb" }));

  app.get("/api/tastings", (_req, res) => {
    res.json(service.listTastings());
  });

  app.get("/api/tastings/:id", (req, res) => {
    const tasting = service.getTasting(String(req.params.id));
    if (!tasting) {
      res.status(404).json({ error: "Tasting not found" });
      return;
    }
    res.json(tasting);
  });

  app.post("/api/tastings/:id/bookings", (req, res) => {
    const result = service.book(String(req.params.id), req.body);
    switch (result.status) {
      case "created":
        res.status(201).json({ reference: result.confirmation.reference });
        return;
      case "invalid":
        res.status(422).json({ errors: result.errors });
        return;
      case "not-found":
        res.status(404).json({ error: "Tasting not found" });
        return;
    }
  });

  app.get("/api/bookings/:reference", (req, res) => {
    const confirmation = service.getConfirmation(String(req.params.reference));
    if (!confirmation) {
      res.status(404).json({ error: "Booking not found" });
      return;
    }
    res.json(confirmation);
  });

  // Staff area: cookie session scoped to /api/staff.
  app.use(
    "/api/staff",
    createStaffSessionMiddleware({
      keys: sessionKeys,
      secureCookies: options.secureCookies ?? false,
    }),
  );

  const signInLimiter = rateLimit({
    windowMs: loginLimit.windowMs,
    limit: loginLimit.limit,
    standardHeaders: "draft-8",
    legacyHeaders: false,
    // Only failed attempts count, so staff who sign in normally are never locked out.
    skipSuccessfulRequests: true,
    message: { errors: { form: "Too many sign-in attempts. Try again later." } },
  });

  app.post("/api/staff/session", signInLimiter, (req, res) => {
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (password.trim() === "") {
      res.status(422).json({ errors: { password: "Enter the staff password" } });
      return;
    }
    if (staffPassword === "") {
      res.status(503).json({
        errors: { form: "Staff sign-in is not configured" },
      });
      return;
    }
    if (!passwordMatches(password, staffPassword)) {
      res.status(401).json({ errors: { password: "Incorrect password" } });
      return;
    }
    startStaffSession(req, Date.now());
    res.status(204).end();
  });

  app.delete("/api/staff/session", (req, res) => {
    endStaffSession(req);
    res.status(204).end();
  });

  app.get("/api/staff/bookings", requireStaff(), (_req, res) => {
    res.json(service.listBookingsByTasting());
  });

  app.delete("/api/staff/bookings/:reference", requireStaff(), (req, res) => {
    const removed = service.cancel(String(req.params.reference));
    if (!removed) {
      res.status(404).json({ error: "Booking not found" });
      return;
    }
    res.status(204).end();
  });

  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Not found" });
  });

  if (options.clientDir) {
    const clientDir = options.clientDir;
    app.use(express.static(clientDir));
    // Deep links (for example /bookings/KB-...) are handled by the React router.
    app.get("/{*splat}", (_req, res) => {
      res.sendFile(join(clientDir, "index.html"));
    });
  }

  // Keep errors in the JSON contract instead of Express's HTML pages.
  app.use((err: unknown, _req: Request, res: Response, next: NextFunction) => {
    if (res.headersSent) {
      next(err);
      return;
    }
    if (isBodyParseError(err)) {
      res.status(400).json({ error: "Request body is not valid JSON" });
      return;
    }
    console.error(err);
    res.status(500).json({ error: "Something went wrong" });
  });

  return app;
}

function isBodyParseError(err: unknown): boolean {
  return (
    typeof err === "object" &&
    err !== null &&
    (err as { type?: unknown }).type === "entity.parse.failed"
  );
}
