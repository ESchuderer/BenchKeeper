import { describe, expect, it } from "vitest";
import { BookingStore, generateReference } from "./bookings.js";
import { createBookingService } from "./service.js";

const guest = (overrides: Record<string, unknown> = {}) => ({
  name: "Anna Keller",
  email: "anna@example.com",
  guests: "2",
  ...overrides,
});

function newService() {
  return createBookingService({ store: new BookingStore() });
}

describe("catalog with seats left", () => {
  it("starts with full capacity for every tasting", () => {
    const seats = newService()
      .listTastings()
      .map((t) => [t.title, t.seatsLeft]);
    expect(seats).toEqual([
      ["Riesling Evening", 12],
      ["Red Wine Cellar Tour", 8],
      ["Winter Tasting", 10],
    ]);
  });

  it("returns undefined for an unknown tasting id", () => {
    expect(newService().getTasting("no-such-tasting")).toBeUndefined();
  });
});

describe("booking a tasting", () => {
  it("confirms a booking and reduces the seats left", () => {
    const service = newService();
    const result = service.book("riesling-evening", guest({ guests: "3" }));

    expect(result.status).toBe("created");
    if (result.status !== "created") return;
    expect(result.confirmation).toMatchObject({
      tastingTitle: "Riesling Evening",
      guests: 3,
      pricePerGuest: 25,
      total: 75,
    });
    expect(result.confirmation.reference).toMatch(/^KB-/);
    expect(service.getTasting("riesling-evening")?.seatsLeft).toBe(9);
  });

  it("computes the total as price per guest times guests", () => {
    const service = newService();
    const result = service.book("red-wine-cellar-tour", guest({ guests: "2" }));
    expect(result.status === "created" && result.confirmation.total).toBe(64);
  });

  it("rejects more guests than seats left, with the message on the Guests field", () => {
    const service = newService();
    service.book("winter-tasting", guest({ guests: "6" }));

    const result = service.book("winter-tasting", guest({ guests: "5" }));

    expect(result).toEqual({
      status: "invalid",
      errors: { guests: "Only 4 seats left" },
    });
    expect(service.getTasting("winter-tasting")?.seatsLeft).toBe(4);
  });

  it("accepts a booking that takes exactly the seats left, then reports fully booked", () => {
    const service = newService();
    service.book("winter-tasting", guest({ guests: "8" }));

    const exact = service.book("winter-tasting", guest({ guests: "2" }));
    expect(exact.status).toBe("created");
    expect(service.getTasting("winter-tasting")?.seatsLeft).toBe(0);

    const late = service.book("winter-tasting", guest({ guests: "1" }));
    expect(late).toEqual({
      status: "invalid",
      errors: { form: "This tasting is fully booked" },
    });
  });

  it("keeps two consecutive requests within capacity", () => {
    const service = newService();
    // 3 seats left after booking 7; the first request of 2 fits, the second cannot.
    service.book("winter-tasting", guest({ guests: "7" }));
    const first = service.book("winter-tasting", guest({ guests: "2" }));
    const second = service.book("winter-tasting", guest({ guests: "2" }));

    expect(first.status).toBe("created");
    expect(second).toEqual({
      status: "invalid",
      errors: { guests: "Only 1 seats left" },
    });
    expect(service.getTasting("winter-tasting")?.seatsLeft).toBe(1);
  });

  it("stores nothing and leaves seats unchanged when input is invalid", () => {
    const service = newService();
    const result = service.book(
      "riesling-evening",
      guest({ name: "", email: "anna@example", guests: "0" }),
    );

    expect(result).toEqual({
      status: "invalid",
      errors: {
        name: "Enter your name",
        email: "Enter a valid email address",
        guests: "Guests must be between 1 and 8",
      },
    });
    expect(service.getTasting("riesling-evening")?.seatsLeft).toBe(12);
    expect(service.listBookingsByTasting()[0]?.bookings).toHaveLength(0);
  });

  it("reports an unknown tasting as not found", () => {
    expect(newService().book("no-such-tasting", guest())).toEqual({
      status: "not-found",
    });
  });

  it("issues a different reference for every booking", () => {
    const service = newService();
    const refs = [
      service.book("riesling-evening", guest()),
      service.book("riesling-evening", guest()),
      service.book("winter-tasting", guest()),
    ].map((r) => (r.status === "created" ? r.confirmation.reference : ""));
    expect(new Set(refs).size).toBe(3);
  });
});

describe("confirmation lookup", () => {
  it("returns the same details for a booking reference", () => {
    const service = newService();
    const created = service.book("red-wine-cellar-tour", guest({ guests: "4" }));
    if (created.status !== "created") throw new Error("expected booking");

    expect(service.getConfirmation(created.confirmation.reference)).toEqual(
      created.confirmation,
    );
  });

  it("returns undefined for an unknown reference", () => {
    expect(newService().getConfirmation("KB-NOPE00")).toBeUndefined();
  });
});

describe("cancelling a booking", () => {
  it("removes the booking and frees its seats", () => {
    const service = newService();
    const created = service.book("winter-tasting", guest({ guests: "3" }));
    if (created.status !== "created") throw new Error("expected booking");

    expect(service.cancel(created.confirmation.reference)).toBe(true);
    expect(service.getTasting("winter-tasting")?.seatsLeft).toBe(10);
    expect(service.getConfirmation(created.confirmation.reference)).toBeUndefined();
  });

  it("returns false for an unknown reference", () => {
    expect(newService().cancel("KB-NOPE00")).toBe(false);
  });

  it("does not cancel a second time", () => {
    const service = newService();
    const created = service.book("winter-tasting", guest());
    if (created.status !== "created") throw new Error("expected booking");
    service.cancel(created.confirmation.reference);
    expect(service.cancel(created.confirmation.reference)).toBe(false);
  });
});

describe("bookings grouped by tasting for staff", () => {
  it("groups bookings under their tasting and keeps tastings without bookings", () => {
    const service = newService();
    service.book("riesling-evening", guest({ name: "Anna", guests: "2" }));
    service.book("riesling-evening", guest({ name: "Ben", guests: "1" }));

    const groups = service.listBookingsByTasting();

    expect(groups.map((g) => g.tasting.title)).toEqual([
      "Riesling Evening",
      "Red Wine Cellar Tour",
      "Winter Tasting",
    ]);
    expect(groups[0]?.bookings.map((b) => [b.name, b.guests])).toEqual([
      ["Anna", 2],
      ["Ben", 1],
    ]);
    expect(groups[0]?.bookings[0]).toMatchObject({
      email: "anna@example.com",
      reference: expect.stringMatching(/^KB-/),
    });
    expect(groups[1]?.bookings).toEqual([]);
  });

  it("no longer lists a cancelled booking", () => {
    const service = newService();
    const created = service.book("winter-tasting", guest({ name: "Cara" }));
    if (created.status !== "created") throw new Error("expected booking");
    service.cancel(created.confirmation.reference);

    const winter = service
      .listBookingsByTasting()
      .find((g) => g.tasting.id === "winter-tasting");
    expect(winter?.bookings).toEqual([]);
  });
});

describe("booking references", () => {
  it("uses the KB- prefix and six unambiguous characters", () => {
    for (let i = 0; i < 200; i++) {
      expect(generateReference()).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
    }
  });

  it("produces distinct references in practice", () => {
    const refs = new Set(Array.from({ length: 1000 }, () => generateReference()));
    expect(refs.size).toBe(1000);
  });

  it("retries when a generated reference is already taken", () => {
    const sequence = ["KB-AAAAAA", "KB-AAAAAA", "KB-BBBBBB"];
    const store = new BookingStore({
      generateReference: () => sequence.shift() ?? "KB-ZZZZZZ",
    });
    const service = createBookingService({ store });

    const first = service.book("riesling-evening", guest());
    const second = service.book("riesling-evening", guest());

    expect(first.status === "created" && first.confirmation.reference).toBe(
      "KB-AAAAAA",
    );
    expect(second.status === "created" && second.confirmation.reference).toBe(
      "KB-BBBBBB",
    );
  });
});
