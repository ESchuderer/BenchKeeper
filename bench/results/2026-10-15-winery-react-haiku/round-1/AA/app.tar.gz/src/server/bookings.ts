import { randomInt } from "node:crypto";

export type Booking = {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
};

export type NewBooking = Omit<Booking, "reference">;

/** 32 symbols without look-alikes (no 0/O, no 1/I). */
const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

/** A reference such as "KB-7QF3HN". */
export function generateReference(): string {
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  }
  return `KB-${code}`;
}

export type BookingStoreOptions = {
  generateReference?: () => string;
};

/**
 * In-memory booking storage. Seats are never stored: the seats taken for a
 * tasting are summed from the bookings, so cancelling a booking frees its
 * seats without any extra bookkeeping.
 *
 * Node runs JavaScript on one thread, so the synchronous operations here are
 * atomic with respect to HTTP requests. The seat check and the insert must
 * stay in one synchronous step (see service.ts).
 */
export class BookingStore {
  private readonly bookings = new Map<string, Booking>();
  private readonly generate: () => string;

  constructor(options: BookingStoreOptions = {}) {
    this.generate = options.generateReference ?? generateReference;
  }

  add(input: NewBooking): Booking {
    let reference = this.generate();
    while (this.bookings.has(reference)) {
      reference = this.generate();
    }
    const booking: Booking = { ...input, reference };
    this.bookings.set(reference, booking);
    return booking;
  }

  findByReference(reference: string): Booking | undefined {
    return this.bookings.get(reference);
  }

  /** Removes the booking. Returns false when no such booking exists. */
  remove(reference: string): boolean {
    return this.bookings.delete(reference);
  }

  list(): Booking[] {
    return [...this.bookings.values()];
  }

  seatsTaken(tastingId: string): number {
    let taken = 0;
    for (const booking of this.bookings.values()) {
      if (booking.tastingId === tastingId) taken += booking.guests;
    }
    return taken;
  }
}
