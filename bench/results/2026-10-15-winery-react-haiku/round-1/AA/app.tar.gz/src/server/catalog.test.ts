import { describe, expect, it } from "vitest";
import { TASTINGS } from "./catalog.js";

describe("tasting catalog", () => {
  // Expected values come straight from the brief's table, not from the code.
  it("offers exactly the three tastings from the brief", () => {
    expect(
      TASTINGS.map(({ title, startsAt, pricePerGuest, capacity }) => ({
        title,
        startsAt,
        pricePerGuest,
        capacity,
      })),
    ).toEqual([
      {
        title: "Riesling Evening",
        startsAt: "2026-11-06T18:00",
        pricePerGuest: 25,
        capacity: 12,
      },
      {
        title: "Red Wine Cellar Tour",
        startsAt: "2026-11-14T15:00",
        pricePerGuest: 32,
        capacity: 8,
      },
      {
        title: "Winter Tasting",
        startsAt: "2026-12-05T17:00",
        pricePerGuest: 28,
        capacity: 10,
      },
    ]);
  });

  it("gives every tasting a unique URL-safe id", () => {
    const ids = TASTINGS.map((tasting) => tasting.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const id of ids) expect(id).toMatch(/^[a-z0-9-]+$/);
  });
});
