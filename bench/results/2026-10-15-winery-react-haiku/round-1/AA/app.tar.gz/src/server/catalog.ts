/** A tasting on offer. Times are local wall-clock values; prices are whole euros. */
export type Tasting = {
  id: string;
  title: string;
  /** Local start time, "YYYY-MM-DDTHH:mm". */
  startsAt: string;
  pricePerGuest: number;
  capacity: number;
};

export const TASTINGS: readonly Tasting[] = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00",
    pricePerGuest: 25,
    capacity: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00",
    pricePerGuest: 32,
    capacity: 8,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00",
    pricePerGuest: 28,
    capacity: 10,
  },
];
