import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { checkClientBuild } from "./client-build.js";

let dir: string;

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), "kb-build-"));
});

afterEach(() => {
  rmSync(dir, { recursive: true, force: true });
});

describe("checkClientBuild", () => {
  it("reports the missing build and the command that creates it", () => {
    const problem = checkClientBuild(join(dir, "missing"));
    expect(problem).toMatch(/npm run build/);
  });

  it("reports a directory without index.html", () => {
    expect(checkClientBuild(dir)).toMatch(/npm run build/);
  });

  it("accepts a directory with index.html", () => {
    writeFileSync(join(dir, "index.html"), "<!doctype html>");
    expect(checkClientBuild(dir)).toBeUndefined();
  });
});
