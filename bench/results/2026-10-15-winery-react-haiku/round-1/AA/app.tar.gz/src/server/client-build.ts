import { existsSync } from "node:fs";
import { join } from "node:path";

/**
 * Returns a message explaining why the React app cannot be served, or
 * undefined when the build output is present.
 */
export function checkClientBuild(clientDir: string): string | undefined {
  if (existsSync(join(clientDir, "index.html"))) return undefined;
  return `The web app has not been built (no index.html in ${clientDir}). Run "npm run build" first.`;
}
