import { describe, expect, it } from "vitest";
import { loadConfig } from "./config.js";

describe("loadConfig", () => {
  it("defaults to port 3000 with staff sign-in disabled", () => {
    const config = loadConfig({});
    expect(config.port).toBe(3000);
    expect(config.staffPassword).toBeUndefined();
    expect(config.secureCookies).toBe(false);
  });

  it("reads PORT", () => {
    expect(loadConfig({ PORT: "8080" }).port).toBe(8080);
  });

  it("treats an empty PORT as unset", () => {
    expect(loadConfig({ PORT: "" }).port).toBe(3000);
  });

  it.each(["abc", "0", "70000", "3000.5", " 3000"])("rejects PORT %j", (port) => {
    expect(() => loadConfig({ PORT: port })).toThrow(/PORT/);
  });

  it("reads STAFF_PASSWORD", () => {
    expect(loadConfig({ STAFF_PASSWORD: "vineyard" }).staffPassword).toBe("vineyard");
  });

  it("marks cookies secure only in production", () => {
    expect(loadConfig({ NODE_ENV: "production" }).secureCookies).toBe(true);
    expect(loadConfig({ NODE_ENV: "development" }).secureCookies).toBe(false);
  });
});
