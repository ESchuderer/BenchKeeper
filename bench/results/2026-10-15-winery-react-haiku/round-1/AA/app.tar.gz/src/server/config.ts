export type Config = {
  port: number;
  /** undefined (or empty) disables staff sign-in. */
  staffPassword: string | undefined;
  /** Staff cookies are Secure only in production, so plain-HTTP local runs still work. */
  secureCookies: boolean;
};

const DEFAULT_PORT = 3000;

/** Reads the runtime configuration from environment variables. */
export function loadConfig(env: NodeJS.ProcessEnv): Config {
  return {
    port: parsePort(env.PORT),
    staffPassword: env.STAFF_PASSWORD || undefined,
    secureCookies: env.NODE_ENV === "production",
  };
}

function parsePort(value: string | undefined): number {
  if (value === undefined || value === "") return DEFAULT_PORT;
  if (!/^\d+$/.test(value)) {
    throw new Error(`PORT must be a whole number between 1 and 65535, got "${value}"`);
  }
  const port = Number(value);
  if (port < 1 || port > 65535) {
    throw new Error(`PORT must be a whole number between 1 and 65535, got "${value}"`);
  }
  return port;
}
