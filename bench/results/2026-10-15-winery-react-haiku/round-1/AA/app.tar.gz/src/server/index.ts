import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";
import { checkClientBuild } from "./client-build.js";
import { loadConfig } from "./config.js";

function main(): void {
  let config: ReturnType<typeof loadConfig>;
  try {
    config = loadConfig(process.env);
  } catch (error) {
    console.error(error instanceof Error ? error.message : error);
    process.exit(1);
  }

  if (config.staffPassword === undefined) {
    console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
  }

  const clientDir = fileURLToPath(new URL("../client", import.meta.url));
  const buildProblem = checkClientBuild(clientDir);
  if (buildProblem) {
    console.error(buildProblem);
    process.exit(1);
  }

  const app = createApp({
    staffPassword: config.staffPassword,
    secureCookies: config.secureCookies,
    clientDir,
  });

  app.listen(config.port, () => {
    console.log(`Weingut Kieselbrunnen tastings on http://localhost:${config.port}`);
  });
}

main();
