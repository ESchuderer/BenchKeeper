import { createBookingSchema, fieldErrorsFrom } from "../shared/booking-input.js";
import type {
  Confirmation,
  FieldErrors,
  StaffTastingBookings,
  TastingView,
} from "../shared/api-types.js";
import { BookingStore } from "./bookings.js";
import { TASTINGS, type Tasting } from "./catalog.js";

export type BookResult =
  | { status: "created"; confirmation: Confirmation }
  | { status: "invalid"; errors: FieldErrors }
  | { status: "not-found" };


export type BookingService = ReturnType<typeof createBookingService>;

export function createBookingService(options: { store: BookingStore }) {
  const { store } = options;
  const tastings = TASTINGS;
  const byId = new Map(tastings.map((t) => [t.id, t]));

  function seatsLeftFor(tasting: Tasting): number {
    return tasting.capacity - store.seatsTaken(tasting.id);
  }

  function toTastingView(tasting: Tasting): TastingView {
    return { ...tasting, seatsLeft: seatsLeftFor(tasting) };
  }

  function confirmationFor(
    booking: { reference: string; tastingId: string; guests: number },
    tasting: Tasting,
  ): Confirmation {
    return {
      reference: booking.reference,
      tastingId: tasting.id,
      tastingTitle: tasting.title,
      startsAt: tasting.startsAt,
      guests: booking.guests,
      pricePerGuest: tasting.pricePerGuest,
      total: booking.guests * tasting.pricePerGuest,
    };
  }

  return {
    listTastings(): TastingView[] {
      return tastings.map(toTastingView);
    },

    getTasting(tastingId: string): TastingView | undefined {
      const tasting = byId.get(tastingId);
      return tasting && toTastingView(tasting);
    },

    /**
     * Books seats for a tasting. Reading the seats left, validating the
     * request and inserting the booking all happen in this one synchronous
     * function, so no other request can take the seats in between.
     */
    book(tastingId: string, raw: unknown): BookResult {
      const tasting = byId.get(tastingId);
      if (!tasting) return { status: "not-found" };

      const seatsLeft = seatsLeftFor(tasting);
      if (seatsLeft <= 0) {
        return {
          status: "invalid",
          errors: { form: "This tasting is fully booked" },
        };
      }

      const input = typeof raw === "object" && raw !== null ? raw : {};
      const parsed = createBookingSchema({ seatsLeft }).safeParse(input);
      if (!parsed.success) {
        return { status: "invalid", errors: fieldErrorsFrom(parsed.error.issues) };
      }

      const booking = store.add({
        tastingId: tasting.id,
        name: parsed.data.name,
        email: parsed.data.email,
        guests: parsed.data.guests,
      });
      return { status: "created", confirmation: confirmationFor(booking, tasting) };
    },

    getConfirmation(reference: string): Confirmation | undefined {
      const booking = store.findByReference(reference);
      if (!booking) return undefined;
      const tasting = byId.get(booking.tastingId);
      return tasting && confirmationFor(booking, tasting);
    },

    /** Cancels a booking, freeing its seats. Returns false if it does not exist. */
    cancel(reference: string): boolean {
      return store.remove(reference);
    },

    listBookingsByTasting(): StaffTastingBookings[] {
      const active = store.list();
      return tastings.map((tasting) => ({
        tasting: toTastingView(tasting),
        bookings: active
          .filter((b) => b.tastingId === tasting.id)
          .map(({ reference, name, email, guests }) => ({
            reference,
            name,
            email,
            guests,
          })),
      }));
    },
  };
}
