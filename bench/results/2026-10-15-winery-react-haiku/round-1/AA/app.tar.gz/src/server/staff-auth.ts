import { createHash, timingSafeEqual } from "node:crypto";
import cookieSession from "cookie-session";
import type { NextFunction, Request, Response } from "express";

export const STAFF_SESSION_MAX_AGE_MS = 8 * 60 * 60 * 1000;
export const STAFF_COOKIE_NAME = "kb_staff";

/**
 * Compares two passwords without leaking length or content through timing.
 * Both sides are hashed first so the buffers always have the same length.
 */
export function passwordMatches(given: string, expected: string): boolean {
  const a = createHash("sha256").update(given, "utf8").digest();
  const b = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(a, b);
}

/** Signed, HttpOnly session cookie limited to the staff API path. */
export function createStaffSessionMiddleware(options: {
  keys: string[];
  secureCookies: boolean;
}) {
  return cookieSession({
    name: STAFF_COOKIE_NAME,
    keys: options.keys,
    path: "/api/staff",
    maxAge: STAFF_SESSION_MAX_AGE_MS,
    httpOnly: true,
    sameSite: "lax",
    secure: options.secureCookies,
  });
}

/** The session payload stored in the cookie. */
export type StaffSession = { staffSignedInAt: number };

export function startStaffSession(req: Request, now: number): void {
  req.session = { staffSignedInAt: now } satisfies StaffSession;
}

export function endStaffSession(req: Request): void {
  req.session = null;
}

/**
 * Lets the request through only with a staff session younger than 8 hours.
 * The age is checked here, on the server, as well as by the cookie max age.
 */
export function requireStaff(now: () => number = () => Date.now()) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const signedInAt = req.session?.staffSignedInAt;
    if (
      typeof signedInAt === "number" &&
      now() - signedInAt < STAFF_SESSION_MAX_AGE_MS
    ) {
      next();
      return;
    }
    res.status(401).json({ error: "Staff sign-in required" });
  };
}
