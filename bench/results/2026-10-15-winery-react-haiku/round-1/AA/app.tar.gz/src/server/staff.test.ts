import request from "supertest";
import { afterEach, describe, expect, it, vi } from "vitest";
import { createApp } from "./app.js";

const PASSWORD = "vineyard-secret";
const EIGHT_HOURS_MS = 8 * 60 * 60 * 1000;

const guest = (overrides: Record<string, unknown> = {}) => ({
  name: "Anna Keller",
  email: "anna@example.com",
  guests: 2,
  ...overrides,
});

/** A signed-in agent (keeps the session cookie between requests). */
async function signedInAgent(app: ReturnType<typeof createApp>) {
  const agent = request.agent(app);
  const res = await agent.post("/api/staff/session").send({ password: PASSWORD });
  expect(res.status).toBe(204);
  return agent;
}

afterEach(() => {
  vi.useRealTimers();
});

describe("POST /api/staff/session", () => {
  it("starts a session with a HttpOnly cookie for the correct password", async () => {
    const res = await request(createApp({ staffPassword: PASSWORD }))
      .post("/api/staff/session")
      .send({ password: PASSWORD });

    expect(res.status).toBe(204);
    const cookie = [res.headers["set-cookie"]].flat().find((c) => c?.includes("="));
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Lax/i);
  });

  it("rejects a wrong password with the message on the Password field", async () => {
    const res = await request(createApp({ staffPassword: PASSWORD }))
      .post("/api/staff/session")
      .send({ password: "guess" });

    expect(res.status).toBe(401);
    expect(res.body).toEqual({ errors: { password: "Incorrect password" } });
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("rejects an empty password", async () => {
    const res = await request(createApp({ staffPassword: PASSWORD }))
      .post("/api/staff/session")
      .send({ password: "" });

    expect(res.status).toBe(422);
    expect(res.body).toEqual({
      errors: { password: "Enter the staff password" },
    });
  });

  it("refuses sign-in when STAFF_PASSWORD is not configured", async () => {
    const res = await request(createApp({ staffPassword: undefined }))
      .post("/api/staff/session")
      .send({ password: "anything" });

    expect(res.status).toBe(503);
    expect(res.body).toEqual({
      errors: { form: "Staff sign-in is not configured" },
    });
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("treats an empty configured password as not configured", async () => {
    const res = await request(createApp({ staffPassword: "" }))
      .post("/api/staff/session")
      .send({ password: "anything" });
    expect(res.status).toBe(503);
  });

  it("does not count successful sign-ins toward the limit", async () => {
    const app = createApp({
      staffPassword: PASSWORD,
      loginRateLimit: { limit: 2, windowMs: 60_000 },
    });
    for (let i = 0; i < 3; i++) {
      const ok = await request(app).post("/api/staff/session").send({ password: PASSWORD });
      expect(ok.status).toBe(204);
    }
    for (let i = 0; i < 2; i++) {
      const wrong = await request(app).post("/api/staff/session").send({ password: "guess" });
      expect(wrong.status).toBe(401);
    }
    const refused = await request(app).post("/api/staff/session").send({ password: PASSWORD });
    expect(refused.status).toBe(429);
    expect(refused.body).toEqual({
      errors: { form: "Too many sign-in attempts. Try again later." },
    });
  });

  it("limits repeated sign-in attempts", async () => {
    const app = createApp({
      staffPassword: PASSWORD,
      loginRateLimit: { limit: 3, windowMs: 60_000 },
    });
    for (let i = 0; i < 3; i++) {
      await request(app).post("/api/staff/session").send({ password: "guess" });
    }
    const res = await request(app)
      .post("/api/staff/session")
      .send({ password: PASSWORD });

    expect(res.status).toBe(429);
  });
});

describe("staff bookings view", () => {
  it("refuses the list without a session, with no booking data", async () => {
    const res = await request(createApp({ staffPassword: PASSWORD })).get(
      "/api/staff/bookings",
    );
    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: "Staff sign-in required" });
  });

  it("lists bookings grouped by tasting for a signed-in staff member", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send(guest({ name: "Anna", guests: 2 }));

    const agent = await signedInAgent(app);
    const res = await agent.get("/api/staff/bookings");

    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(3);
    expect(res.body[0].tasting.title).toBe("Riesling Evening");
    expect(res.body[0].bookings).toEqual([
      {
        reference: expect.stringMatching(/^KB-/),
        name: "Anna",
        email: "anna@example.com",
        guests: 2,
      },
    ]);
    expect(res.body[1].bookings).toEqual([]);
  });

  it("keeps the session across requests (a page reload)", async () => {
    const agent = await signedInAgent(createApp({ staffPassword: PASSWORD }));
    expect((await agent.get("/api/staff/bookings")).status).toBe(200);
    expect((await agent.get("/api/staff/bookings")).status).toBe(200);
  });

  it("ends the session on sign-out", async () => {
    const agent = await signedInAgent(createApp({ staffPassword: PASSWORD }));
    expect((await agent.delete("/api/staff/session")).status).toBe(204);
    expect((await agent.get("/api/staff/bookings")).status).toBe(401);
  });

  it("refuses a session older than 8 hours, checked on the server", async () => {
    vi.useFakeTimers({ toFake: ["Date"] });
    vi.setSystemTime(new Date("2026-10-15T10:00:00Z"));
    const app = createApp({ staffPassword: PASSWORD });

    const signIn = await request(app)
      .post("/api/staff/session")
      .send({ password: PASSWORD });
    const cookie = [signIn.headers["set-cookie"]]
      .flat()
      .map((c) => String(c).split(";")[0])
      .join("; ");

    vi.setSystemTime(new Date(Date.parse("2026-10-15T10:00:00Z") + EIGHT_HOURS_MS - 60_000));
    const almostExpired = await request(app)
      .get("/api/staff/bookings")
      .set("Cookie", cookie);
    expect(almostExpired.status).toBe(200);

    vi.setSystemTime(new Date(Date.parse("2026-10-15T10:00:00Z") + EIGHT_HOURS_MS + 60_000));
    const expired = await request(app)
      .get("/api/staff/bookings")
      .set("Cookie", cookie);
    expect(expired.status).toBe(401);
  });
});

describe("cancelling a booking", () => {
  it("removes the booking, frees its seats and keeps the reference unusable", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const created = await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send(guest({ guests: 3 }));
    const reference: string = created.body.reference;

    const agent = await signedInAgent(app);
    const res = await agent.delete(`/api/staff/bookings/${reference}`);
    expect(res.status).toBe(204);

    const tasting = await request(app).get("/api/tastings/winter-tasting");
    expect(tasting.body.seatsLeft).toBe(10);
    expect((await request(app).get(`/api/bookings/${reference}`)).status).toBe(404);
    const list = await agent.get("/api/staff/bookings");
    expect(list.body[2].bookings).toEqual([]);
  });

  it("returns 404 for an unknown reference", async () => {
    const agent = await signedInAgent(createApp({ staffPassword: PASSWORD }));
    const res = await agent.delete("/api/staff/bookings/KB-NOPE00");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Booking not found" });
  });

  it("refuses without a session and keeps the booking", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const created = await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send(guest({ guests: 3 }));
    const reference: string = created.body.reference;

    const res = await request(app).delete(`/api/staff/bookings/${reference}`);

    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: "Staff sign-in required" });
    expect((await request(app).get(`/api/bookings/${reference}`)).status).toBe(200);
  });
});
