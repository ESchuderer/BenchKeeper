import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import request from "supertest";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { createApp } from "./app.js";

let clientDir: string;

beforeEach(() => {
  clientDir = mkdtempSync(join(tmpdir(), "kb-client-"));
  mkdirSync(join(clientDir, "assets"));
  writeFileSync(join(clientDir, "index.html"), "<!doctype html><div id=\"root\"></div>");
  writeFileSync(join(clientDir, "assets", "app.js"), "console.log('kb');");
});

afterEach(() => {
  rmSync(clientDir, { recursive: true, force: true });
});

describe("serving the client build", () => {
  it("serves index.html at the root", async () => {
    const res = await request(createApp({ clientDir })).get("/");
    expect(res.status).toBe(200);
    expect(res.text).toContain('<div id="root">');
  });

  it("serves static assets with their content type", async () => {
    const res = await request(createApp({ clientDir })).get("/assets/app.js");
    expect(res.status).toBe(200);
    expect(res.headers["content-type"]).toMatch(/javascript/);
  });

  it("falls back to index.html for client-side routes", async () => {
    const app = createApp({ clientDir });
    for (const path of ["/tastings/winter-tasting/book", "/bookings/KB-7QF3HN", "/staff"]) {
      const res = await request(app).get(path);
      expect(res.status).toBe(200);
      expect(res.text).toContain('<div id="root">');
    }
  });

  it("does not serve index.html for unknown API paths", async () => {
    const res = await request(createApp({ clientDir })).get("/api/unknown");
    expect(res.status).toBe(404);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body).toEqual({ error: "Not found" });
  });

  it("sends security headers", async () => {
    const res = await request(createApp({ clientDir })).get("/");
    expect(res.headers["content-security-policy"]).toBeDefined();
    expect(res.headers["x-powered-by"]).toBeUndefined();
    expect(res.headers["x-content-type-options"]).toBe("nosniff");
  });
});
