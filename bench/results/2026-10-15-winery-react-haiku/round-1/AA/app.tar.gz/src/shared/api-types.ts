/** Messages keyed by the form field they concern; "form" is for the whole form. */
export type FieldErrors = Partial<
  Record<"name" | "email" | "guests" | "password" | "form", string>
>;

/** A tasting as the API returns it, with the seats still available. */
export type TastingView = {
  id: string;
  title: string;
  /** Local start time, "YYYY-MM-DDTHH:mm". */
  startsAt: string;
  pricePerGuest: number;
  capacity: number;
  seatsLeft: number;
};

/** What a guest sees after booking, and when reopening the reference. */
export type Confirmation = {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  pricePerGuest: number;
  total: number;
};

export type StaffBooking = {
  reference: string;
  name: string;
  email: string;
  guests: number;
};

export type StaffTastingBookings = {
  tasting: TastingView;
  bookings: StaffBooking[];
};

/** Error bodies returned by the API. */
export type ApiErrorBody = {
  error?: string;
  errors?: FieldErrors;
};
