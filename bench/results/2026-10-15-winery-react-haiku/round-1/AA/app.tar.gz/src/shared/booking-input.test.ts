import { describe, expect, it } from "vitest";
import { createBookingSchema, MAX_GUESTS } from "./booking-input.js";

const schema = createBookingSchema();

/** Returns the first message per field for an input, or {} when valid. */
function errorsFor(input: Record<string, unknown>, seatsLeft?: number) {
  const result = createBookingSchema(
    seatsLeft === undefined ? undefined : { seatsLeft },
  ).safeParse(input);
  if (result.success) return {};
  const out: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const field = String(issue.path[0]);
    out[field] ??= issue.message;
  }
  return out;
}

const valid = { name: "Anna Keller", email: "anna@example.com", guests: "2" };

describe("booking input validation", () => {
  it("accepts a complete booking and returns typed values", () => {
    const result = schema.safeParse(valid);
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data).toEqual({
        name: "Anna Keller",
        email: "anna@example.com",
        guests: 2,
      });
    }
  });

  it("accepts guests sent as a JSON number", () => {
    expect(schema.safeParse({ ...valid, guests: 3 }).success).toBe(true);
  });

  it("trims surrounding whitespace from name and email", () => {
    const result = schema.safeParse({
      ...valid,
      name: "  Anna  ",
      email: " anna@example.com ",
    });
    expect(result.success && result.data.name).toBe("Anna");
    expect(result.success && result.data.email).toBe("anna@example.com");
  });

  it("requires a name", () => {
    expect(errorsFor({ ...valid, name: "   " })).toEqual({
      name: "Enter your name",
    });
    expect(errorsFor({ ...valid, name: undefined })).toEqual({
      name: "Enter your name",
    });
  });

  it("rejects names longer than 100 characters", () => {
    expect(errorsFor({ ...valid, name: "a".repeat(101) })).toEqual({
      name: "Name must be 100 characters or fewer",
    });
    expect(errorsFor({ ...valid, name: "a".repeat(100) })).toEqual({});
  });

  it("requires an email address", () => {
    expect(errorsFor({ ...valid, email: "" })).toEqual({
      email: "Enter your email address",
    });
  });

  it.each(["anna@example", "anna.example.com", "anna @example.com"])(
    "rejects the malformed email %s",
    (email) => {
      expect(errorsFor({ ...valid, email })).toEqual({
        email: "Enter a valid email address",
      });
    },
  );

  it("requires the number of guests", () => {
    expect(errorsFor({ ...valid, guests: "" })).toEqual({
      guests: "Enter the number of guests",
    });
  });

  it.each(["0", "9", "-1", String(MAX_GUESTS + 1)])(
    "rejects guests %s as out of range",
    (guests) => {
      expect(errorsFor({ ...valid, guests })).toEqual({
        guests: "Guests must be between 1 and 8",
      });
    },
  );

  it.each(["2.5", "abc", "2 guests", "1e1"])(
    "rejects guests %s as not a whole number",
    (guests) => {
      expect(errorsFor({ ...valid, guests })).toEqual({
        guests: "Guests must be a whole number",
      });
    },
  );

  it("accepts every whole number from 1 to 8", () => {
    for (let n = 1; n <= 8; n++) {
      expect(errorsFor({ ...valid, guests: String(n) })).toEqual({});
    }
  });

  it("reports all invalid fields together", () => {
    expect(errorsFor({ name: "", email: "x", guests: "0" })).toEqual({
      name: "Enter your name",
      email: "Enter a valid email address",
      guests: "Guests must be between 1 and 8",
    });
  });

  it("limits guests to the seats left when seats are known", () => {
    expect(errorsFor({ ...valid, guests: "5" }, 4)).toEqual({
      guests: "Only 4 seats left",
    });
    expect(errorsFor({ ...valid, guests: "4" }, 4)).toEqual({});
  });

  it("does not add a seat limit when none is given", () => {
    expect(errorsFor({ ...valid, guests: "8" })).toEqual({});
  });
});
