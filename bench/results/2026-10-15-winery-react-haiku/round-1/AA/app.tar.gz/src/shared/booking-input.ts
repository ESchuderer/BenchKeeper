import { z } from "zod";
import type { FieldErrors } from "./api-types.js";

export const MIN_GUESTS = 1;
export const MAX_GUESTS = 8;
export const MAX_NAME_LENGTH = 100;

/**
 * Raw values may be missing, numbers (from JSON) or strings (from a form).
 * Everything is normalised to a string first so both sources behave the same.
 */
const asText = (value: unknown): string =>
  value == null ? "" : typeof value === "string" ? value : String(value);

const nameField = z.preprocess(
  asText,
  z
    .string()
    .trim()
    .min(1, "Enter your name")
    .max(MAX_NAME_LENGTH, `Name must be ${MAX_NAME_LENGTH} characters or fewer`),
);

const emailField = z.preprocess(
  asText,
  z
    .string()
    .trim()
    .min(1, "Enter your email address")
    .pipe(z.email("Enter a valid email address")),
);

const guestsRange = z
  .number()
  .int("Guests must be a whole number")
  .min(MIN_GUESTS, `Guests must be between ${MIN_GUESTS} and ${MAX_GUESTS}`)
  .max(MAX_GUESTS, `Guests must be between ${MIN_GUESTS} and ${MAX_GUESTS}`);

const guestsField = z.preprocess(
  asText,
  z
    .string()
    .trim()
    .min(1, "Enter the number of guests")
    .regex(/^-?\d+$/, "Guests must be a whole number")
    .transform((text) => Number(text))
    .pipe(guestsRange),
);

export type BookingSchemaOptions = {
  /** When known, guests above this count are rejected with "Only N seats left". */
  seatsLeft?: number;
};

/**
 * Validates a booking request. Pass `seatsLeft` on the client for early
 * feedback; the server always checks seats again against the live count.
 */
export function createBookingSchema(options: BookingSchemaOptions = {}) {
  const guestsWithSeatLimit = guestsField.superRefine((guests, ctx) => {
    const seatsLeft = options.seatsLeft;
    if (seatsLeft !== undefined && guests > seatsLeft) {
      ctx.addIssue({
        code: "custom",
        message: `Only ${seatsLeft} seats left`,
      });
    }
  });

  return z.object({
    name: nameField,
    email: emailField,
    guests: guestsWithSeatLimit,
  });
}

/**
 * Converts zod issues into one message per field. The first message for a
 * field wins, so "Enter the number of guests" is kept over the format message.
 */
export function fieldErrorsFrom(issues: readonly z.core.$ZodIssue[]): FieldErrors {
  const errors: FieldErrors = {};
  for (const issue of issues) {
    const field = issue.path[0];
    if (field === "name" || field === "email" || field === "guests") {
      errors[field] ??= issue.message;
    }
  }
  return errors;
}
