import { describe, expect, it } from "vitest";
import { formatEuro, formatSeatsLeft, formatStartsAt } from "./format.js";

describe("formatStartsAt", () => {
  it("formats the Riesling Evening start as a weekday, date and time", () => {
    expect(formatStartsAt("2026-11-06T18:00")).toBe(
      "Friday, 6 November 2026 at 18:00",
    );
  });

  it("formats the Red Wine Cellar Tour start", () => {
    expect(formatStartsAt("2026-11-14T15:00")).toBe(
      "Saturday, 14 November 2026 at 15:00",
    );
  });

  it("formats the Winter Tasting start", () => {
    expect(formatStartsAt("2026-12-05T17:00")).toBe(
      "Saturday, 5 December 2026 at 17:00",
    );
  });

  it("does not depend on the machine time zone", () => {
    // The local wall-clock time is shown as written, never shifted.
    expect(formatStartsAt("2026-11-06T00:05")).toContain("at 00:05");
  });
});

describe("formatEuro", () => {
  it("prefixes whole euro amounts with EUR", () => {
    expect(formatEuro(25)).toBe("EUR 25");
    expect(formatEuro(64)).toBe("EUR 64");
  });
});

describe("formatSeatsLeft", () => {
  it("shows the seat count in the brief's format", () => {
    expect(formatSeatsLeft(12)).toBe("12 seats left");
    expect(formatSeatsLeft(0)).toBe("0 seats left");
  });
});
