const WEEKDAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
] as const;

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
] as const;

const LOCAL_DATE_TIME = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/;

/**
 * Formats a local wall-clock start time such as "2026-11-06T18:00" as
 * "Friday, 6 November 2026 at 18:00". The weekday is derived with UTC
 * arithmetic so the output never shifts with the machine's time zone.
 */
export function formatStartsAt(startsAt: string): string {
  const match = LOCAL_DATE_TIME.exec(startsAt);
  if (!match) throw new Error(`Invalid tasting start time: ${startsAt}`);
  const [, yearText, monthText, dayText, hourText, minuteText] = match;
  const year = Number(yearText);
  const month = Number(monthText);
  const day = Number(dayText);
  const weekday = WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()];
  const monthName = MONTHS[month - 1];
  return `${weekday}, ${day} ${monthName} ${year} at ${hourText}:${minuteText}`;
}

/** Whole-euro amount as shown to guests, e.g. "EUR 64". */
export function formatEuro(amount: number): string {
  return `EUR ${amount}`;
}

/** Seats-left label in the format given by the brief: "<n> seats left". */
export function formatSeatsLeft(seatsLeft: number): string {
  return `${seatsLeft} seats left`;
}
