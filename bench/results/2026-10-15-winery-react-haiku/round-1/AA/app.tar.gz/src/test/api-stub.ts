import { vi } from "vitest";

export type StubResponse = { status: number; body?: unknown };
/** A fixed response, or a function of the parsed request body (for stateful flows). */
export type StubRoute =
  | StubResponse
  | ((body: unknown) => StubResponse | Promise<StubResponse>);

export type RecordedCall = { method: string; path: string; body: unknown };

/**
 * Replaces `fetch` at the network boundary. Routes are keyed by "METHOD /path".
 * Any request without a route is recorded and answered with 599 so the test
 * fails visibly on the assertion that checks the calls.
 */
export function stubApi(routes: Record<string, StubRoute>) {
  const calls: RecordedCall[] = [];

  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const method = (init?.method ?? "GET").toUpperCase();
    const path = String(input);
    const body = init?.body ? JSON.parse(String(init.body)) : undefined;
    calls.push({ method, path, body });

    const route = routes[`${method} ${path}`];
    const response: StubResponse = !route
      ? { status: 599, body: { error: `Unexpected request ${method} ${path}` } }
      : typeof route === "function"
        ? await route(body)
        : route;

    if (response.status === 204) return new Response(null, { status: 204 });
    return new Response(JSON.stringify(response.body ?? null), {
      status: response.status,
      headers: { "Content-Type": "application/json" },
    });
  });

  vi.stubGlobal("fetch", fetchMock);
  return { calls, fetchMock };
}

/** Tasting fixture matching the server's catalog shape. */
export function tastingFixture(overrides: Record<string, unknown> = {}) {
  return {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00",
    pricePerGuest: 25,
    capacity: 12,
    seatsLeft: 12,
    ...overrides,
  };
}
