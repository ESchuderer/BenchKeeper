# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff sign in to see every booking and cancel any of them.

The app is a React single-page frontend served by one Node.js process (Express), which also provides the JSON API. Bookings are kept in a local JSON file, so no external services or database are needed.

## Running it

Requires Node.js 22.12 or newer.

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password PORT=3000 npm start
```

Then open http://localhost:3000. Staff sign in at http://localhost:3000/staff.

### Configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `3000` | Port the app listens on. |
| `STAFF_PASSWORD` | not set | Password for `/staff`. When it is not set the app still starts, but staff sign-in is refused. |
| `DATA_FILE` | `data/bookings.json` | Where bookings are saved, relative to the directory the app is started from. The file is created on the first booking. |

If `DATA_FILE` exists but cannot be parsed, the server refuses to start and leaves the file unchanged. Fix or move it first.

The three tastings are defined in `server/catalog.ts`. Changing them needs a restart.

## Operating notes

- **Run one process per bookings file.** Bookings are held in memory and written to `DATA_FILE`, so two servers sharing a file would overwrite each other.
- **Put the app behind HTTPS.** The staff password and session cookie travel in clear text over plain HTTP. The cookie is `HttpOnly` and `SameSite=Strict` but not `Secure`, so that `http://localhost` keeps working; set `Secure` at the TLS proxy if you terminate TLS there.
- **Staff sessions end on restart**, and after eight hours or on sign-out. Staff sign-in is limited to 10 failed attempts per client every 15 minutes.

## Development

```sh
npm run dev:server   # API on PORT (default 3000), restarts on change
npm run dev          # Vite dev server on http://localhost:5173, forwards /api to PORT
```

If you set `PORT`, set it for both commands, because the Vite proxy reads it when Vite starts.

Tests and checks:

```sh
npm run typecheck    # TypeScript for the client and the server
npm test             # unit and API tests (Vitest, Supertest, React Testing Library)
npm run test:e2e     # builds the app, then runs the browser tests (Playwright)
```

The browser tests need Chromium once: `npx playwright install chromium`.

## Layout

- `src/`: React app (pages, components, API client, Tailwind styles)
- `server/`: Express app (`app.ts`), staff sign-in and session (`staffAuth.ts`), booking store with JSON persistence (`store.ts`), tasting catalogue (`catalog.ts`), entry point (`index.ts`)
- `shared/`: validation schemas and API types used by both the browser and the server
- `test/`: unit, API and component tests (`test/**/*.test.*`), and browser tests (`test/e2e/`)
- `openspec/`: the specification and change history for this app (see `openspec/changes/add-tasting-bookings`)
