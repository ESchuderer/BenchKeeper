# Design

## Context

The repository is empty apart from the OpenSpec setup, so there are no existing conventions to follow. The app is small and single-tenant: one winery, three fixed tastings, a handful of staff, and no external services. See proposal.md - Why for the motivation and specs/ for the observable behavior. The runtime target is Node.js 22 (the spec says plain "Node.js 22", so dependencies are pinned to majors that support Node 22.12 or older patches).

## Goals / Non-Goals

**Goals:**
- One process that serves the React frontend, the JSON API and the staff area, started with `npm start`.
- A seat check that cannot be bypassed: the server is the only authority on seats left, and it checks and records a booking in one synchronous step.
- Bookings survive a restart, with no database to install.
- Validation rules live in one place and are shared by the browser and the server, so both show the same messages.

**Non-Goals:**
- Payments, email, and multi-user staff accounts (see proposal.md - Impact).
- Multi-process deployment. The in-memory state assumes one server process owns the bookings file.
- Making the tasting catalogue editable at runtime. It is fixed in code.
- HTTPS termination. The app is designed to run behind the winery's own TLS proxy if one is used.

## Decisions

**Stack.** Express 5 serves the API and the built frontend. React 19 with React Router 7 handles pages and routes. React Hook Form with Zod (through @hookform/resolvers) handles the booking and sign-in forms. Tailwind CSS 4 handles styling. TypeScript is used throughout. Alternatives considered: Next.js (adds a second framework and a heavier runtime than a three-page site needs), Fastify (fine, but Express is the more common choice for a small server with cookie and rate-limit middleware), and plain CSS (would mean writing our own layout and form-state primitives, which the brief asks us not to do).

**Shared validation.** A Zod schema for the booking input and the staff sign-in lives in `shared/schemas.ts`. The client uses it as the form resolver; the server uses it to parse request bodies. This keeps messages identical and means a request that bypasses the browser is still validated. The seat check is not in the schema, because it needs server state; the server adds it after the schema passes.

**Seat accounting in one place.** A `BookingStore` owns the bookings. `createBooking` reads the seats left, compares it with the requested guests and appends the booking in the same synchronous block. Node runs JavaScript on one thread, so two requests cannot interleave inside that block. Seats left is always derived (total seats minus guests across bookings); it is never stored, so cancelling a booking frees its seats with no extra bookkeeping. Alternative considered: a database with row locks. Rejected because the brief rules out external services and the single-process model already gives the needed guarantee.

**Persistence.** The store writes the full booking list to a JSON file after every change. Each write goes to a temporary file, is flushed to disk, and is then renamed over the target (the directory is flushed too), so a crash cannot leave half a file. The response is sent only after the write succeeds; if the write fails the in-memory change is reverted and the request fails, so a confirmation is never shown for an unsaved booking. Every change (check, record, save, and any rollback) runs as one turn in a queue, so a rollback never interleaves with another booking or cancellation. Alternative considered: keeping bookings in memory only. Rejected because a restart would wipe bookings the winery has taken, which is worse than the small cost of a file.

**Corrupt file handling.** On startup the store parses the file with a Zod schema. If the file exists but is unreadable or invalid, the server exits with an error naming the file and leaves it alone. Silently starting empty would let the next write destroy the real data.

**Booking references.** `KB-` plus six characters from the 34-character alphabet A to Z and 2 to 9, as tasting-bookings requires. These are generated with `crypto.randomInt`, checked against existing references, and retried on collision. They are not guessable in practice, so the public confirmation lookup needs no login.

**Guest confirmation.** The API returns the booking details, and the confirmation page fetches them by reference. Navigating to `/bookings/<reference>` after booking uses the same path as a reload or a shared link, so there is one code path. The confirmation shows no email address.

**Staff sign-in.** The password is compared to `STAFF_PASSWORD` with `crypto.timingSafeEqual` over SHA-256 digests, which avoids leaking the length. A successful sign-in sets a signed cookie (cookie-session) with `httpOnly`, `sameSite=strict` and an 8-hour lifetime. The signing key is random per process start, so sessions end on restart as the spec requires. The cookie only names a session: the server keeps each live session with its expiry, so sign-out and the 8-hour limit are enforced on the server too, not only by the browser. Every response carries Helmet's standard headers, including a Content-Security-Policy limited to the app's own origin. `sameSite=strict` also blocks cross-site form posts, so the cancel and sign-out endpoints need no separate CSRF token. Wrong passwords are rate limited per client with express-rate-limit (10 per 15 minutes). Successful sign-ins and empty or malformed submissions do not count.

**Staff password missing.** The server starts and warns, and sign-in returns 503 with a message. Refusing to start would stop the guest booking pages too, and the staff area is a secondary concern.

**Routing and build.** The client is built with Vite into `dist/client`; the server is compiled with `tsc` into `dist/server`. In production Express serves the built client and falls back to `index.html` for any non-API GET, so deep links work on reload. In development Vite proxies `/api` to the Node server.

**Presentation.** A serif heading face from the system font stack and a warm cream background with a wine-red accent. No web fonts are loaded from third-party hosts, which keeps the app free of external requests. Layout is mobile-first: single column at 360 pixels, with a grid for tasting cards from the `sm` breakpoint up.

## Risks / Trade-offs

- **Staff password over plain HTTP.** Without TLS the password and session cookie travel in clear text. → Run the app behind the winery's HTTPS proxy and set `Secure` on the cookie there; the README calls this out. We do not set `secure` unconditionally because that would make the app unusable on `http://localhost`.
- **Single-process assumption.** Two server processes writing the same file would overwrite each other's bookings. → `npm start` runs one process; the README says not to run two against the same `DATA_FILE`.
- **Bookings file grows with every write.** The full list is rewritten each time. → At the winery's scale (three tastings, tens of bookings) this is negligible; revisit if the volume grows.
- **Staff sessions end on restart.** Staff must sign in again after a deployment. → Acceptable for an eight-hour session, and it is what the spec says.
- **Rate limiter keyed on the client address.** Behind a proxy every client may share one address, so a few staff mistyping can lock others out for 15 minutes. → Set `trust proxy` appropriately when the proxy is known; the limit is generous (10 failures).
- **Tasting catalogue in code.** Changing a tasting needs a code change and a restart. → Acceptable for three fixed events; bookings already made keep their tasting id and the catalogue must not remove a tasting that has bookings.
