# Proposal

## Why

Weingut Kieselbrunnen runs wine tastings but has no way for guests to book them online, and staff have no single place to see who is coming. Bookings are currently handled by hand, which makes it easy to overbook a tasting and hard to see the guest list per event.

## What Changes

- Add a public web app for the winery with a start page that lists the three upcoming tastings (title, date and time, price per guest, seats left).
- Each tasting gets a "Book <tasting title>" action that opens a booking form (Name, Email, Guests 1 to 8).
- Bookings are validated on the server; a booking can never exceed the seats left. Errors appear next to the field they concern.
- After a successful booking the guest sees a "Booking confirmed" page with the tasting, number of guests, total price and booking reference.
- Add a staff area at `/staff`, protected by a password taken from the `STAFF_PASSWORD` environment variable. Signed-in staff see all bookings grouped by tasting and can cancel a booking, which frees its seats.
- Bookings are stored in a local JSON file so they survive a restart. No external services are used.
- Introduce a React frontend and a Node.js server, built with `npm run build` and started with `npm start` on `PORT` (default 3000).

Nothing exists in the repository yet, so there is no breaking change.

## Capabilities

### New Capabilities

- `tasting-catalog`: The list of tastings on offer, with date and time, price per guest, seats left and fully-booked state, shown on the start page.
- `tasting-bookings`: Guests booking seats on a tasting through a validated form and receiving a booking confirmation.
- `staff-bookings`: Staff signing in with the staff password, viewing bookings grouped by tasting, and cancelling bookings.
- `site-presentation`: The winery-branded look and feel, clear success, error and fully-booked states, and phone-friendly layout.
- `app-runtime`: How the app is built, started, configured through `PORT` and `STAFF_PASSWORD`, and where bookings are persisted.

### Modified Capabilities

None. The repository has no existing specs.

## Impact

- New code: a React single-page frontend (Vite, React Router, React Hook Form with Zod validation, Tailwind CSS) and an Express server that exposes a JSON API and serves the built frontend.
- New dependencies: express, react, react-dom, react-router, react-hook-form, zod, @hookform/resolvers, tailwindcss, vite, cookie-session, express-rate-limit, typescript, vitest, supertest, @testing-library/react, jsdom.
- Data: bookings are kept in a JSON file (`DATA_FILE`, default `data/bookings.json`). The tasting catalogue is fixed in code.
- Out of scope: payment, email confirmations, editing tastings from the UI, multiple staff accounts, and tasting capacity changes after launch.
