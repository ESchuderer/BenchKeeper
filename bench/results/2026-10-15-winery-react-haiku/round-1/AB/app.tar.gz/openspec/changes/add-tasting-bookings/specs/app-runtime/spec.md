# Spec Delta

## Purpose

Defines how the app is installed, built and started, which environment variables configure it, and how bookings are kept between restarts. Keeps the app self-contained, with no external services.

## ADDED Requirements

### Requirement: Single process serves the whole app
After `npm run build`, `npm start` SHALL start one server process that serves the guest pages, the staff page and the JSON API. The app SHALL make no calls to external services at runtime.

#### Scenario: Guest page served
- **WHEN** the app is started and a browser requests `/`
- **THEN** the start page is returned

#### Scenario: Deep link served on reload
- **WHEN** a browser requests `/bookings/KB-ABC234` directly
- **THEN** the app shell is returned so that the client-side page can render

#### Scenario: Unknown API route
- **WHEN** a request is made to an `/api/` path that does not exist
- **THEN** the response has status 404 and a JSON body

### Requirement: Port configuration
The server SHALL listen on the port given by the environment variable `PORT`, and on port 3000 when `PORT` is not set.

#### Scenario: Default port
- **WHEN** the app is started without `PORT` set
- **THEN** it listens on port 3000

#### Scenario: Custom port
- **WHEN** the app is started with `PORT=4100`
- **THEN** it listens on port 4100 and does not listen on port 3000

### Requirement: Staff password configuration
The staff password SHALL be read from the environment variable `STAFF_PASSWORD` when the server starts. When that variable is not set, the server SHALL still start, SHALL log a warning, and staff sign-in SHALL be refused as not configured.

#### Scenario: Password missing at startup
- **WHEN** the app starts without `STAFF_PASSWORD`
- **THEN** the server starts and logs a warning that staff sign-in is not configured

### Requirement: Fresh start has no bookings
When no bookings file exists, the app SHALL start with no bookings and every tasting SHALL show its full number of seats.

#### Scenario: First start
- **GIVEN** no bookings file exists at the configured data location
- **WHEN** the app starts
- **THEN** every tasting shows its full number of seats left

### Requirement: Bookings survive a restart
Bookings SHALL be stored in a local JSON file at the path given by the environment variable `DATA_FILE`, or at `data/bookings.json` relative to the working directory when `DATA_FILE` is not set. Bookings and cancellations SHALL be written to that file before the request that made them is answered, so a guest's confirmation is never issued for a booking that is not saved.

#### Scenario: Booking kept after restart
- **GIVEN** a booking for 2 guests exists for "Riesling Evening"
- **WHEN** the app is stopped and started again
- **THEN** the booking is still listed for staff and "Riesling Evening" shows 10 seats left

#### Scenario: Cancellation kept after restart
- **GIVEN** a booking was cancelled by staff
- **WHEN** the app is stopped and started again
- **THEN** the booking is not listed and its seats remain free

### Requirement: Bookings file is private
The bookings file SHALL be readable and writable only by the account that runs the server, because it holds guest names and email addresses.

#### Scenario: File permissions
- **WHEN** a booking is saved on a POSIX system
- **THEN** the bookings file has mode 0600

### Requirement: Standard security headers
Every response SHALL carry the standard hardening headers, including a Content-Security-Policy that restricts content to the app's own origin, and the server SHALL NOT advertise its framework.

#### Scenario: Headers on an API response
- **WHEN** any API request is answered
- **THEN** the response includes X-Content-Type-Options nosniff and a Content-Security-Policy with default-src 'self'
- **AND** the X-Powered-By header is absent

### Requirement: Unreadable bookings file is not overwritten
If the bookings file exists but cannot be read or parsed, the server SHALL refuse to start with an error that names the file, and SHALL NOT overwrite it.

#### Scenario: Corrupt bookings file
- **GIVEN** the bookings file contains text that is not valid JSON
- **WHEN** the app starts
- **THEN** the server exits with an error naming the bookings file
- **AND** the file's contents are unchanged
