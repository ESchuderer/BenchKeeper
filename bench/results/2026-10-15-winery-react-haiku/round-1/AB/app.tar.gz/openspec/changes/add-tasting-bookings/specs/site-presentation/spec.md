# Spec Delta

## Purpose

Defines how the winery's pages look and behave for guests and staff: a recognisable family-winery identity, clear success, error and fully-booked states, accessible forms, and a layout that works on phones.

## ADDED Requirements

### Requirement: Winery identity on every page
Every page SHALL show the name "Weingut Kieselbrunnen" in a header that links back to the start page, SHALL use a warm, restrained visual style with a wine-red accent and serif headings, and SHALL set a browser tab title that names the page and the winery.

#### Scenario: Header on the start page
- **WHEN** a guest opens the start page
- **THEN** the header shows "Weingut Kieselbrunnen"
- **AND** selecting it returns the guest to the start page
- **AND** the browser tab title contains "Weingut Kieselbrunnen"

#### Scenario: Header on the staff page
- **WHEN** a visitor opens `/staff`
- **THEN** the header shows "Weingut Kieselbrunnen"

### Requirement: Clear error states
Validation errors SHALL be displayed in red text directly beneath the field they concern, and the affected field SHALL be visually marked as invalid. Errors SHALL be announced to assistive technology and linked to their field.

#### Scenario: Invalid field marked
- **WHEN** a guest submits a booking with an invalid Email
- **THEN** the Email field is visually marked as invalid
- **AND** the error message is linked to the Email field so that screen readers read it with the field

### Requirement: Clear success state
The booking confirmation SHALL be visually distinct from the booking form, with a success heading "Booking confirmed" and a visible confirmation mark, so that a guest can tell at a glance that the booking succeeded.

#### Scenario: Confirmation is distinct
- **WHEN** a booking succeeds
- **THEN** the page shows the success heading "Booking confirmed" and a confirmation mark
- **AND** no booking form is shown

### Requirement: Clear fully-booked state
A fully booked tasting SHALL be visually distinct from tastings with seats left, using a "Fully booked" badge and a muted presentation, and SHALL NOT look like it can be booked.

#### Scenario: Fully booked card
- **WHEN** a guest views a fully booked tasting on the start page
- **THEN** its card shows a "Fully booked" badge
- **AND** the card is presented in a muted style with no booking action

### Requirement: Phone-friendly layout
All guest pages and the staff page SHALL remain fully usable at a viewport width of 360 CSS pixels: content SHALL NOT require horizontal scrolling, form fields and buttons SHALL span the available width, and tappable controls SHALL be at least 44 CSS pixels high.

#### Scenario: Booking form on a small phone
- **WHEN** a guest opens the booking form for a tasting on a 360 pixel wide screen
- **THEN** all fields and the "Book" button are fully visible without horizontal scrolling
- **AND** each tappable control is at least 44 pixels high

#### Scenario: Staff bookings on a small phone
- **WHEN** staff view the bookings list on a 360 pixel wide screen
- **THEN** each booking's name, email, guests, reference and "Cancel" button are readable without horizontal scrolling

### Requirement: Accessible forms
Every form field SHALL have a visible label, every interactive element SHALL show a visible focus indicator, and text SHALL meet a contrast ratio of at least 4.5 to 1 against its background.

#### Scenario: Keyboard focus
- **WHEN** a keyboard user tabs through the booking form
- **THEN** each field and button shows a visible focus indicator
