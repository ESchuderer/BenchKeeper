# Spec Delta

## Purpose

Lets winery staff sign in with a shared staff password, see every booking grouped by tasting, and cancel bookings so their seats become available again. Keeps booking details away from anyone who has not signed in.

## ADDED Requirements

### Requirement: Staff sign-in page
The page at `/staff` SHALL show a sign-in form with a field labelled "Password" and a button labelled "Sign in" until staff are signed in. The booking list MUST NOT be visible before sign-in.

#### Scenario: Visiting the staff page signed out
- **WHEN** a visitor who is not signed in opens `/staff`
- **THEN** the page shows the "Password" field and the "Sign in" button
- **AND** no booking details are shown

### Requirement: Password is checked against STAFF_PASSWORD
The system SHALL sign staff in only when the submitted password exactly matches the value of the environment variable `STAFF_PASSWORD`. A wrong password SHALL NOT sign anyone in.

#### Scenario: Correct password
- **GIVEN** `STAFF_PASSWORD` is set to "vine-2026"
- **WHEN** a visitor submits "vine-2026" in the Password field
- **THEN** the visitor is signed in and sees the bookings page

#### Scenario: Wrong password
- **GIVEN** `STAFF_PASSWORD` is set to "vine-2026"
- **WHEN** a visitor submits "vine-2027"
- **THEN** the visitor is not signed in
- **AND** the message "Incorrect password" is shown next to the Password field

#### Scenario: Empty password
- **WHEN** a visitor submits the sign-in form with the Password field empty
- **THEN** the message "Enter the staff password" is shown next to the Password field
- **AND** the visitor is not signed in

#### Scenario: Staff password not configured
- **GIVEN** `STAFF_PASSWORD` is not set
- **WHEN** a visitor submits any password
- **THEN** the visitor is not signed in
- **AND** the message "Staff sign-in is not configured" is shown

### Requirement: Sign-in attempts are limited
After 10 sign-in attempts with a wrong password within 15 minutes from the same client, further sign-in attempts from that client SHALL be refused for the rest of that window with the message "Too many attempts. Try again later."

#### Scenario: Eleventh attempt refused
- **GIVEN** a client has made 10 failed sign-in attempts in the last 15 minutes
- **WHEN** the client submits the correct password
- **THEN** the client is not signed in
- **AND** the message "Too many attempts. Try again later." is shown

### Requirement: Staff session
A successful sign-in SHALL keep the staff member signed in for 8 hours, until they sign out, or until the server restarts. A "Sign out" button SHALL end the session and return the page to the sign-in form.

#### Scenario: Session persists across page loads
- **GIVEN** a staff member signed in 1 hour ago
- **WHEN** they reload `/staff`
- **THEN** the bookings page is shown without asking for the password again

#### Scenario: Sign out
- **WHEN** a signed-in staff member selects "Sign out"
- **THEN** the sign-in form is shown
- **AND** reloading `/staff` still shows the sign-in form

#### Scenario: Copied session stops working at sign-out
- **GIVEN** a staff member signed in and then selected "Sign out"
- **WHEN** a request is made with the session cookie that was held before sign-out
- **THEN** the request is refused with status 401

#### Scenario: Session expires on the server
- **GIVEN** a session that was started more than 8 hours ago
- **WHEN** a request is made with that session cookie
- **THEN** the request is refused with status 401

#### Scenario: Booking data requires a session
- **WHEN** a request for the bookings data arrives without a valid staff session
- **THEN** the request is refused with status 401 and no booking data is returned

### Requirement: Bookings grouped by tasting
Signed-in staff SHALL see every active booking, grouped under the title of its tasting. Each booking SHALL show the guest's name, email, number of guests and booking reference. Bookings within a group SHALL be listed in the order they were made.

#### Scenario: Bookings for two tastings
- **GIVEN** "Riesling Evening" has bookings from "Anna Berger" (2 guests) and "Lukas Weiss" (1 guest)
- **AND** "Winter Tasting" has a booking from "Mia Klein" (4 guests)
- **WHEN** staff sign in
- **THEN** the page shows a "Riesling Evening" group listing Anna Berger and Lukas Weiss in that order
- **AND** a "Winter Tasting" group listing Mia Klein
- **AND** each booking shows its email, number of guests and reference

#### Scenario: Tasting without bookings
- **WHEN** staff sign in and "Red Wine Cellar Tour" has no bookings
- **THEN** its group shows "No bookings yet"

### Requirement: Cancelling a booking
Each booking on the staff page SHALL have a "Cancel" button. Selecting it SHALL remove the booking, free its guests' seats for that tasting and remove it from the staff list. A cancelled booking's reference SHALL no longer open a confirmation.

#### Scenario: Cancel frees seats
- **GIVEN** "Riesling Evening" has 12 seats, and Anna Berger has booked 2 of them
- **WHEN** staff select "Cancel" for Anna Berger's booking
- **THEN** Anna Berger's booking is no longer listed
- **AND** "Riesling Evening" shows "12 seats left" on the start page

#### Scenario: Cancelled reference
- **GIVEN** staff have cancelled the booking with reference "KB-7H2QK9"
- **WHEN** a guest opens the confirmation for "KB-7H2QK9"
- **THEN** the page shows "We could not find this booking. It may have been cancelled."

#### Scenario: Cancel request without a session
- **WHEN** a request to cancel a booking arrives without a valid staff session
- **THEN** the request is refused with status 401 and the booking is kept

#### Scenario: Cancel unknown booking
- **WHEN** staff request to cancel a reference that does not exist
- **THEN** the request is refused with status 404
