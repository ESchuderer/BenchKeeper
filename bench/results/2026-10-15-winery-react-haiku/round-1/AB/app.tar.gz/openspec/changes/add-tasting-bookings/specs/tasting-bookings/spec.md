# Spec Delta

## Purpose

Lets guests reserve seats on a wine tasting by submitting a validated booking form, and gives them a booking confirmation with a reference. Guarantees that no tasting is ever booked beyond its seats.

## ADDED Requirements

### Requirement: Booking form fields
The booking form for a tasting SHALL show the tasting title as its heading and SHALL contain three labelled fields, "Name", "Email" and "Guests", and a submit button labelled "Book".

#### Scenario: Form opened for a tasting
- **WHEN** a guest opens the booking form for "Riesling Evening"
- **THEN** the page heading is "Riesling Evening"
- **AND** the form shows the fields "Name", "Email" and "Guests" and a "Book" button

#### Scenario: Unknown tasting
- **WHEN** a guest opens the booking form for a tasting that does not exist
- **THEN** the page shows "Tasting not found" and no booking form

### Requirement: Guests field range
The Guests field SHALL accept a whole number from 1 to 8 only.

#### Scenario: Valid guest count
- **WHEN** a guest enters 2 in the Guests field and submits a valid form
- **THEN** the booking is accepted

#### Scenario: Zero guests rejected
- **WHEN** a guest enters 0 in the Guests field and submits
- **THEN** the booking is rejected
- **AND** the message "Choose between 1 and 8 guests" is shown next to the Guests field

#### Scenario: More than eight guests rejected
- **WHEN** a guest enters 9 in the Guests field and submits
- **THEN** the booking is rejected
- **AND** the message "Choose between 1 and 8 guests" is shown next to the Guests field

#### Scenario: Non-numeric guest count rejected
- **WHEN** a guest enters "two" or 2.5 in the Guests field and submits
- **THEN** the booking is rejected
- **AND** the message "Choose between 1 and 8 guests" is shown next to the Guests field

### Requirement: Name and email validation
The Name field SHALL be required, SHALL contain at most 100 characters after leading and trailing spaces are removed, and SHALL NOT be blank. The Email field SHALL be required and SHALL be a syntactically valid email address of at most 254 characters.

#### Scenario: Empty name
- **WHEN** a guest submits the form with the Name field empty or containing only spaces
- **THEN** the booking is rejected
- **AND** the message "Enter your name" is shown next to the Name field

#### Scenario: Name too long
- **WHEN** a guest submits a Name of 101 characters
- **THEN** the booking is rejected
- **AND** the message "Name must be at most 100 characters" is shown next to the Name field

#### Scenario: Empty email
- **WHEN** a guest submits the form with the Email field empty
- **THEN** the booking is rejected
- **AND** the message "Enter your email address" is shown next to the Email field

#### Scenario: Invalid email
- **WHEN** a guest submits the Email value "guest@example"
- **THEN** the booking is rejected
- **AND** the message "Enter a valid email address" is shown next to the Email field

### Requirement: Errors shown next to their field
Each validation error SHALL be shown next to the field it concerns, and every invalid field SHALL be reported in the same submission. A valid field SHALL NOT show an error.

#### Scenario: Several invalid fields
- **WHEN** a guest submits with an empty Name, an invalid Email and 0 guests
- **THEN** the Name, Email and Guests fields each show their own error message
- **AND** no booking is created

### Requirement: Booking never exceeds seats left
The system SHALL accept a booking only if the number of guests is less than or equal to the seats left for that tasting at the moment the booking is made. A rejected booking SHALL NOT change the seats left.

#### Scenario: Booking exactly the seats left
- **GIVEN** "Red Wine Cellar Tour" has 3 seats left
- **WHEN** a guest books 3 guests
- **THEN** the booking is accepted
- **AND** the tasting has 0 seats left afterwards

#### Scenario: Booking more than seats left
- **GIVEN** "Red Wine Cellar Tour" has 3 seats left
- **WHEN** a guest books 4 guests
- **THEN** the booking is rejected
- **AND** the message "Only 3 seats left for this tasting" is shown next to the Guests field
- **AND** the tasting still has 3 seats left

#### Scenario: Single seat left
- **GIVEN** "Red Wine Cellar Tour" has 1 seat left
- **WHEN** a guest books 2 guests
- **THEN** the booking is rejected
- **AND** the message "Only 1 seat left for this tasting" is shown next to the Guests field

#### Scenario: Competing bookings
- **GIVEN** "Winter Tasting" has 10 seats, of which 8 are booked, so 2 seats are left
- **AND** guest A has the booking form open with 2 guests selected
- **WHEN** guest B books 1 guest and that booking is accepted, and then guest A submits
- **THEN** guest A's booking is rejected with "Only 1 seat left for this tasting" next to the Guests field
- **AND** the tasting has 9 guests booked and 1 seat left

#### Scenario: Fully booked tasting
- **GIVEN** "Riesling Evening" has no seats left
- **WHEN** a guest submits the booking form for it
- **THEN** the booking is rejected
- **AND** the message "This tasting is fully booked" is shown above the form, not next to a field

### Requirement: Booking reference
Every accepted booking SHALL receive a unique booking reference that the guest can use to find the booking. The reference SHALL consist of the prefix "KB-" followed by six characters drawn from the uppercase letters A to Z and the digits 2 to 9.

#### Scenario: Reference format
- **WHEN** a booking is accepted
- **THEN** its reference matches the pattern "KB-" followed by six characters from A to Z and 2 to 9

#### Scenario: References are unique
- **WHEN** two bookings are accepted
- **THEN** they receive different booking references

### Requirement: Booking confirmation
After an accepted booking, the guest SHALL see a page headed "Booking confirmed" that shows the tasting title, the number of guests, the total price and the booking reference. The total price SHALL be the price per guest multiplied by the number of guests, in euros.

#### Scenario: Confirmation for two guests
- **GIVEN** the price per guest of "Riesling Evening" is EUR 25
- **WHEN** a guest books 2 guests for "Riesling Evening" with a valid form
- **THEN** the confirmation page is headed "Booking confirmed"
- **AND** it shows "Riesling Evening", "2 guests", "EUR 50" as the total and the booking reference

#### Scenario: Confirmation is reachable again
- **WHEN** a guest opens the confirmation address of a booking reference that exists
- **THEN** the same confirmation details are shown

#### Scenario: Unknown reference
- **WHEN** a guest opens the confirmation address for a reference that does not exist or was cancelled
- **THEN** the page shows "We could not find this booking. It may have been cancelled."

### Requirement: Rejected booking keeps the entered details
When a booking is rejected, the form SHALL keep the values the guest entered so they can correct them.

#### Scenario: Correcting a rejected booking
- **WHEN** a guest submits a valid name and email with 0 guests and receives the guests error
- **THEN** the Name and Email fields still contain the values the guest entered
