# Spec Delta

## Purpose

Lets guests see which wine tastings Weingut Kieselbrunnen offers, when they take place, what they cost and how many seats remain. This is the entry point to booking.

## ADDED Requirements

### Requirement: Start page lists all tastings
The start page SHALL list every tasting on offer. Each listed tasting SHALL show its title, its date and start time, its price per guest in euros, and its number of seats left.

#### Scenario: Three tastings listed
- **WHEN** a guest opens the start page of a fresh installation
- **THEN** the page lists "Riesling Evening", "Red Wine Cellar Tour" and "Winter Tasting"
- **AND** "Riesling Evening" shows the date 6 November 2026, the time 18:00, the price "EUR 25" per guest and "12 seats left"
- **AND** "Red Wine Cellar Tour" shows the date 14 November 2026, the time 15:00, the price "EUR 32" per guest and "8 seats left"
- **AND** "Winter Tasting" shows the date 5 December 2026, the time 17:00, the price "EUR 28" per guest and "10 seats left"

### Requirement: Seats left reflect current bookings
The number of seats left shown for a tasting SHALL equal the tasting's total seats minus the number of guests across all of its active bookings.

#### Scenario: Seats left after a booking
- **GIVEN** a booking for 3 guests exists for "Riesling Evening"
- **WHEN** a guest opens the start page
- **THEN** "Riesling Evening" shows "9 seats left"

#### Scenario: Seats left after a cancellation
- **GIVEN** a booking for 3 guests for "Riesling Evening" was cancelled by staff
- **WHEN** a guest opens the start page
- **THEN** "Riesling Evening" shows "12 seats left"

### Requirement: Singular wording for one seat
When exactly one seat is left, the page SHALL show "1 seat left" instead of "1 seats left".

#### Scenario: One seat left
- **GIVEN** 11 guests are booked on "Riesling Evening"
- **WHEN** a guest opens the start page
- **THEN** "Riesling Evening" shows "1 seat left"

### Requirement: Fully booked tastings
A tasting with no seats left SHALL be shown as fully booked. The page MUST NOT offer a booking action for a fully booked tasting and MUST show the text "Fully booked" for it.

#### Scenario: Last seat taken
- **GIVEN** 8 guests are booked on "Red Wine Cellar Tour"
- **WHEN** a guest opens the start page
- **THEN** "Red Wine Cellar Tour" shows "Fully booked"
- **AND** no "Book Red Wine Cellar Tour" action is shown

### Requirement: Booking action per tasting
Each tasting that has seats left SHALL have an action labelled "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open booking form from the list
- **WHEN** a guest selects "Book Winter Tasting" on the start page
- **THEN** the booking form for "Winter Tasting" opens
