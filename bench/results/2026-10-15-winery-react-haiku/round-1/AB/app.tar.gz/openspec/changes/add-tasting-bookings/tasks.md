# Tasks

## 1. Project setup

- [x] 1.1 Create package.json (ESM, engines node >=22.12, scripts dev, dev:server, typecheck, test, build, start) with the pinned dependencies from design.md and verify `npm install` completes with no errors
- [x] 1.2 Add tsconfig.json (client, shared, tests), tsconfig.server.json (server to dist/server), vite.config.ts (React, Tailwind, /api proxy to the server in dev, Vitest config with node default and jsdom for client tests), and index.html; verify `npm run typecheck` runs without configuration errors

## 2. Shared validation contract

- [x] 2.1 Write test/shared/schemas.test.ts covering the booking input rules (name required, trimmed, max 100; email required, valid, max 254; guests whole number 1 to 8 including "two", 2.5 and 0) and the staff password rule (empty rejected with "Enter the staff password"); verify it fails because the module does not exist yet
- [x] 2.2 Implement shared/schemas.ts and shared/types.ts so that the messages match the tasting-bookings and staff-bookings specs exactly; verify test/shared/schemas.test.ts passes

## 3. Booking store

- [x] 3.1 Write test/server/store.test.ts covering: seats left for the three tastings and the fresh state; seats left after a booking and after a cancellation; booking exactly the seats left; rejecting more guests than seats left with the remaining count and no change; fully booked rejection; competing bookings; unique references matching KB- plus six characters from A to Z and 2 to 9; cancellation removing the booking and its seats; persistence round trip through a file; startup refusing an unreadable file without overwriting it; a failed write reverting the booking; verify it fails before implementation
- [x] 3.2 Implement server/catalog.ts (the three tastings with ids, titles, start times, prices and seats), server/references.ts, and server/store.ts (synchronous seat check and record, atomic JSON persistence with serialised writes and rollback on failure, loading with validation); verify test/server/store.test.ts passes

## 4. HTTP API and staff session

- [x] 4.1 Write test/server/api.test.ts with supertest covering: GET /api/tastings with seatsLeft; POST /api/tastings/:id/bookings returning the confirmation details; 400 with field errors; 409 with a guests error for too many guests; 409 with a fully booked message; 404 for an unknown tasting; GET /api/bookings/:reference for an existing, unknown and cancelled reference; a JSON 404 for an unknown /api path; index.html served for /bookings/KB-ABC234 and not for /api paths; verify it fails before implementation
- [x] 4.2 Write test/server/staff.test.ts covering: correct password sets the session cookie; wrong password returns 401 with the "Incorrect password" error on password; empty password returns 400; missing STAFF_PASSWORD returns 503 with the not-configured message; the eleventh failed attempt in 15 minutes returns 429 even with the correct password; GET /api/staff/bookings returns 401 without a session and bookings grouped by tasting in booking order with a session; DELETE /api/staff/bookings/:reference returns 204 and frees seats, 401 without a session keeps the booking, 404 for an unknown reference; POST /api/staff/logout ends the session; verify it fails before implementation
- [x] 4.3 Implement server/app.ts (createApp with injected store, staff password, session secret and client directory), server/staff.ts (password check with timingSafeEqual, cookie-session, express-rate-limit), the guest and staff routes, and server/index.ts (reads PORT, STAFF_PASSWORD and DATA_FILE, logs the unconfigured warning, serves the built client with an index.html fallback for non-API GET requests); verify test/server/api.test.ts and test/server/staff.test.ts pass

## 5. Frontend pages

- [x] 5.1 Write test/client/startPage.test.tsx, test/client/bookingPage.test.tsx, test/client/confirmationPage.test.tsx and test/client/staffPage.test.tsx with mocked fetch, covering: the three tastings with title, date and time, price and seats left; "1 seat left" wording; no Book action and a "Fully booked" badge for a full tasting; the Book form fields and button; client-side errors next to their fields and linked with aria-describedby; a server guests error shown next to the Guests field; a fully booked message above the form; entered values kept after a rejection; the confirmation heading, tasting, guests, total and reference; the not-found message; the staff sign-in form, the "Incorrect password" error, the grouped list, Cancel, and Sign out; verify they fail before implementation
- [x] 5.2 Implement src/api.ts (typed fetch wrappers that map server field errors), src/format.ts (weekday, date and time from the stored start time; EUR price formatting; seat wording), src/main.tsx, src/App.tsx (React Router routes for /, /book/:tastingId, /bookings/:reference, /staff and a not-found page), the shared layout and form components, and the four pages, with the Tailwind theme in src/index.css; verify all tests in test/client pass

## 6. Presentation and end-to-end behaviour

- [x] 6.1 Add test/e2e/booking.spec.ts with Playwright covering a guest booking from the start page to the confirmation, a rejected booking that exceeds the seats left, and a staff cancel that frees the seats; verify it passes against the built app, or record the exact reason it cannot run here
- [x] 6.2 Check the site-presentation requirements in the browser at 360 pixels and at desktop width: no horizontal scrolling, tappable controls at least 44 pixels high, visible focus rings, and distinct error, success and fully-booked states; verify with screenshots reviewed by reading them and with the Playwright run from 6.1

## 7. Build, start and documentation

- [x] 7.1 Add the build script that runs the Vite client build into dist/client and the TypeScript server build into dist/server, and the start script that runs dist/server/server/index.js; verify `npm run build` followed by `PORT=4100 npm start` serves the start page on port 4100
- [x] 7.2 Write README.md covering install, build, start, the PORT, STAFF_PASSWORD and DATA_FILE variables, the dev workflow, the single-process limit, and the note to run behind HTTPS; verify each command in it runs as written from a clean checkout of the project

## 8. Integration checks

- [x] 8.1 Run the full test suite, the typecheck and the production build together; verify all pass with no skipped tests
- [x] 8.2 Run the built app and exercise it end to end over HTTP: book seats, confirm seats left changed, restart and confirm the booking persisted, cancel as staff and confirm the seats were freed; verify each observable result

## 9. Review findings

- [x] 9.1 Serialise every booking change and cancellation in one queue so a failed save rolls back before anything else reads the bookings; verify test/server/store.test.ts covers a booking requested during a failed cancellation
- [x] 9.2 Clamp seats left at zero when the catalogue shrinks below the booked guests; verify test/server/store.test.ts covers the shrunk catalogue
- [x] 9.3 Accept only strings and numbers for guests (reject true and arrays); verify test/shared/schemas.test.ts covers both
- [x] 9.4 Answer 404 for a missing built asset instead of the app shell; verify test/server/api.test.ts covers it
- [x] 9.5 Count only wrong passwords toward the sign-in limit; verify test/server/staff.test.ts covers empty submissions
- [x] 9.6 Show a connection error with Try again when the staff bookings cannot be loaded; verify test/client/staffPage.test.tsx covers it
- [x] 9.7 Flush the bookings file and its directory to disk before a booking is confirmed; verify the write path in server/store.ts and the store tests still pass

## 10. Security review findings

- [x] 10.1 Enforce sign-out and the 8-hour session limit on the server, so a copied cookie stops working; verify test/server/staff.test.ts covers a copied cookie after sign-out and an expired session
- [x] 10.2 Write the bookings file readable only by its owner (mode 0600, directory 0700); verify test/server/store.test.ts checks the file mode
- [x] 10.3 Send standard security headers with Helmet and keep the built app working under its Content-Security-Policy; verify test/server/api.test.ts and the browser suite still pass

## Workflow follow-up

- Run a code review over the change and fix the findings that are confirmed.
- Archive the change with openspec-archive-change once the tasks are complete and the user has reviewed it.
