import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { defineConfig, devices } from '@playwright/test';

const PORT = 4180;

// Runs the built app against a fresh bookings file, so every run starts with no bookings.
export default defineConfig({
  testDir: 'test/e2e',
  workers: 1,
  reporter: 'list',
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: 'retain-on-failure',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'node dist/server/server/index.js',
    url: `http://localhost:${PORT}/api/tastings`,
    env: {
      PORT: String(PORT),
      STAFF_PASSWORD: 'vine-2026',
      DATA_FILE: join(tmpdir(), `kieselbrunnen-e2e-${Date.now()}.json`),
    },
    reuseExistingServer: false,
    timeout: 30_000,
  },
});
