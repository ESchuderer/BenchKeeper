import express, { type ErrorRequestHandler } from 'express';
import helmet from 'helmet';
import { extname, join, resolve } from 'node:path';
import { z } from 'zod';
import { bookingInputSchema, staffLoginSchema } from '../shared/schemas.js';
import type { ApiErrorBody, BookingConfirmation, Tasting } from '../shared/types.js';
import { createLoginRateLimit, createStaffSessions, passwordMatches, requireStaff, staffCookieSession } from './staffAuth.js';
import type { BookingStore, StoredBooking } from './store.js';

const NOT_FOUND_BOOKING = 'We could not find this booking. It may have been cancelled.';
const TASTING_NOT_FOUND = 'Tasting not found';

export interface AppOptions {
  store: BookingStore;
  // Undefined means staff sign-in is switched off.
  staffPassword?: string;
  // Directory with the built React app. When omitted only the API is served.
  clientDir?: string;
  // Cookie signing keys. Random per process when omitted.
  sessionKeys?: string[];
  // Clock for staff session expiry. Tests inject their own.
  now?: () => number;
}

export function createApp({ store, staffPassword, clientDir, sessionKeys, now }: AppOptions) {
  const app = express();
  const staff = createStaffSessions(now);
  app.use(helmet());
  app.disable('x-powered-by');
  app.use(express.json({ limit: '10kb' }));
  app.use('/api/staff', staffCookieSession(sessionKeys));

  app.get('/api/tastings', (_req, res) => {
    res.json(store.listTastings());
  });

  app.post('/api/tastings/:tastingId/bookings', async (req, res) => {
    const tasting = store.findTasting(req.params.tastingId);
    if (!tasting) {
      res.status(404).json({ message: TASTING_NOT_FOUND } satisfies ApiErrorBody);
      return;
    }

    const parsed = bookingInputSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error) } satisfies ApiErrorBody);
      return;
    }

    const result = await store.createBooking({ tastingId: tasting.id, ...parsed.data });
    if (result.ok) {
      res.status(201).json(confirmationFor(result.booking, tasting));
    } else if (result.reason === 'fully-booked') {
      res.status(409).json({ message: 'This tasting is fully booked' } satisfies ApiErrorBody);
    } else if (result.reason === 'not-enough-seats') {
      const seats = result.seatsLeft === 1 ? '1 seat' : `${result.seatsLeft} seats`;
      res.status(409).json({
        errors: { guests: `Only ${seats} left for this tasting` },
      } satisfies ApiErrorBody);
    } else {
      res.status(404).json({ message: TASTING_NOT_FOUND } satisfies ApiErrorBody);
    }
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const booking = store.getBooking(req.params.reference);
    const tasting = booking && store.findTasting(booking.tastingId);
    if (!booking || !tasting) {
      res.status(404).json({ message: NOT_FOUND_BOOKING } satisfies ApiErrorBody);
      return;
    }
    res.json(confirmationFor(booking, tasting));
  });

  app.post('/api/staff/login', createLoginRateLimit(), (req, res) => {
    const parsed = staffLoginSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error) } satisfies ApiErrorBody);
      return;
    }
    if (!staffPassword) {
      res.status(503).json({ message: 'Staff sign-in is not configured' } satisfies ApiErrorBody);
      return;
    }
    if (!passwordMatches(parsed.data.password, staffPassword)) {
      res.status(401).json({ errors: { password: 'Incorrect password' } } satisfies ApiErrorBody);
      return;
    }
    staff.start(req);
    res.json({ signedIn: true });
  });

  app.get('/api/staff/session', (req, res) => {
    res.json({ signedIn: staff.isSignedIn(req) });
  });

  app.post('/api/staff/logout', (req, res) => {
    staff.end(req);
    res.status(204).end();
  });

  app.use('/api/staff/bookings', requireStaff(staff));

  app.get('/api/staff/bookings', (_req, res) => {
    res.json({ groups: store.listBookingsByTasting() });
  });

  app.delete('/api/staff/bookings/:reference', async (req, res) => {
    const cancelled = await store.cancelBooking(req.params.reference);
    if (!cancelled) {
      res.status(404).json({ message: 'Booking not found' } satisfies ApiErrorBody);
      return;
    }
    res.status(204).end();
  });

  // Any other /api path is a real 404, not the app shell.
  app.use('/api', (_req, res) => {
    res.status(404).json({ message: 'Not found' } satisfies ApiErrorBody);
  });

  if (clientDir) {
    const root = resolve(clientDir);
    app.use(express.static(root));
    // Deep links such as /bookings/KB-ABC234 load the app, which then renders the right page.
    app.use((req, res, next) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        next();
        return;
      }
      // A path with a file extension names an asset. If it is missing, say so rather than sending HTML.
      if (extname(req.path)) {
        res.status(404).type('text/plain').send('Not found');
        return;
      }
      res.sendFile(join(root, 'index.html'));
    });
  }

  app.use(handleError);
  return app;
}

function fieldErrors(error: z.ZodError): NonNullable<ApiErrorBody['errors']> {
  const errors: NonNullable<ApiErrorBody['errors']> = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0]) as keyof NonNullable<ApiErrorBody['errors']>;
    errors[field] ??= issue.message;
  }
  return errors;
}

function confirmationFor(booking: StoredBooking, tasting: Tasting): BookingConfirmation {
  return {
    reference: booking.reference,
    tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt, priceEuro: tasting.priceEuro },
    guests: booking.guests,
    totalEuro: tasting.priceEuro * booking.guests,
  };
}

const handleError: ErrorRequestHandler = (error, _req, res, _next) => {
  const status = (error as { status?: number }).status;
  if (status && status < 500) {
    res.status(status).json({ message: 'The request could not be processed' } satisfies ApiErrorBody);
    return;
  }
  console.error(error);
  res.status(500).json({ message: 'Something went wrong. Please try again.' } satisfies ApiErrorBody);
};
