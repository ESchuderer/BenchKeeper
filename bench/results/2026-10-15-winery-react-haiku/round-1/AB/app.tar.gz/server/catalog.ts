import type { Tasting } from '../shared/types.js';

// The tastings on offer. Fixed in code: changing them needs a restart.
export const TASTINGS: readonly Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEuro: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceEuro: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceEuro: 28, seats: 10 },
];
