import { join, resolve } from 'node:path';
import { createApp } from './app.js';
import { BookingFileError, BookingStore } from './store.js';

const port = Number(process.env.PORT ?? 3000);
// An empty STAFF_PASSWORD counts as not set.
const staffPassword = process.env.STAFF_PASSWORD || undefined;
const dataFile = process.env.DATA_FILE || join(process.cwd(), 'data', 'bookings.json');
// Compiled to dist/server/server/index.js, so the built client sits two levels up in dist/.
const clientDir = resolve(import.meta.dirname, '../../client');

async function main() {
  if (!staffPassword) {
    console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled until it is set.');
  }
  const store = await BookingStore.open({ dataFile });
  const app = createApp({ store, staffPassword, clientDir });
  app.listen(port, () => {
    console.log(`Weingut Kieselbrunnen tastings listening on port ${port}`);
  });
}

main().catch((error: unknown) => {
  console.error(error instanceof BookingFileError ? error.message : error);
  process.exit(1);
});
