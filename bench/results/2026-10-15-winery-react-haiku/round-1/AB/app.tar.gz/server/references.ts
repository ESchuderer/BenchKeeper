import { randomInt } from 'node:crypto';

// A to Z and 2 to 9, as the tasting-bookings spec requires.
const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ23456789';

export function generateReference(): string {
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += ALPHABET[randomInt(ALPHABET.length)];
  }
  return `KB-${code}`;
}
