import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import type { Request, RequestHandler } from 'express';
import cookieSession from 'cookie-session';
import rateLimit from 'express-rate-limit';

export const SESSION_MAX_AGE_MS = 8 * 60 * 60 * 1000;
const LOGIN_ATTEMPT_LIMIT = 10;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

// The signing key is random per process, so every staff session ends when the server restarts.
export function staffCookieSession(keys: string[] = [randomBytes(32).toString('hex')]) {
  return cookieSession({
    name: 'kb_staff',
    keys,
    maxAge: SESSION_MAX_AGE_MS,
    httpOnly: true,
    // Strict also stops other sites from making staff requests with the cookie, so no CSRF token is needed.
    sameSite: 'strict',
  });
}

// The cookie only names a session. The server keeps the live sessions and their expiry, so a copied
// cookie stops working at sign-out and after 8 hours, not only in the browser.
export function createStaffSessions(now: () => number = Date.now) {
  const expiresAt = new Map<string, number>();

  function forgetExpired() {
    for (const [id, expiry] of expiresAt) {
      if (expiry <= now()) expiresAt.delete(id);
    }
  }

  return {
    start(req: Request) {
      forgetExpired();
      const id = randomUUID();
      expiresAt.set(id, now() + SESSION_MAX_AGE_MS);
      req.session!.staffSessionId = id;
    },

    end(req: Request) {
      const id = req.session?.staffSessionId;
      if (typeof id === 'string') expiresAt.delete(id);
      req.session = null;
    },

    isSignedIn(req: Request): boolean {
      const id = req.session?.staffSessionId;
      if (typeof id !== 'string') return false;
      const expiry = expiresAt.get(id);
      if (expiry === undefined || expiry <= now()) {
        expiresAt.delete(id);
        return false;
      }
      return true;
    },
  };
}

export function requireStaff(sessions: ReturnType<typeof createStaffSessions>): RequestHandler {
  return (req, res, next) => {
    if (sessions.isSignedIn(req)) {
      next();
      return;
    }
    res.status(401).json({ message: 'Sign in to view bookings' });
  };
}

// Counts wrong passwords only, so a correct password is never blocked by empty or malformed submissions.
export function createLoginRateLimit() {
  return rateLimit({
    windowMs: LOGIN_WINDOW_MS,
    limit: LOGIN_ATTEMPT_LIMIT,
    skipSuccessfulRequests: true,
    requestWasSuccessful: (_req, res) => res.statusCode !== 401,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { message: 'Too many attempts. Try again later.' },
  });
}

// Compares digests so the check takes the same time whatever the length of the guess.
export function passwordMatches(given: string, expected: string): boolean {
  const givenDigest = createHash('sha256').update(given).digest();
  const expectedDigest = createHash('sha256').update(expected).digest();
  return timingSafeEqual(givenDigest, expectedDigest);
}
