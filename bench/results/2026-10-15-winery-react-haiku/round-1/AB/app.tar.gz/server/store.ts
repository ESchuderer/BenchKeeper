import { mkdir, open, readFile, rename } from 'node:fs/promises';
import { dirname } from 'node:path';
import { z } from 'zod';
import type { StaffBookingGroup, Tasting, TastingListing } from '../shared/types.js';
import { TASTINGS } from './catalog.js';
import { generateReference } from './references.js';

export interface StoredBooking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface NewBooking {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export type CreateBookingResult =
  | { ok: true; booking: StoredBooking }
  | { ok: false; reason: 'unknown-tasting' }
  | { ok: false; reason: 'fully-booked' }
  | { ok: false; reason: 'not-enough-seats'; seatsLeft: number };

export interface BookingStoreOptions {
  tastings?: readonly Tasting[];
  // When omitted the bookings live in memory only.
  dataFile?: string;
  // Replaces the default file write. Tests use it to simulate a failing disk.
  write?: (file: string, contents: string) => Promise<void>;
}

const storedBookingSchema = z.object({
  reference: z.string(),
  tastingId: z.string(),
  name: z.string(),
  email: z.string(),
  guests: z.number().int().min(1),
  createdAt: z.string(),
});

const bookingsFileSchema = z.object({
  version: z.literal(1),
  bookings: z.array(storedBookingSchema),
});

export class BookingFileError extends Error {
  constructor(file: string, reason: string) {
    super(`Bookings file ${file} ${reason}. Fix or move it before starting the server; it has not been changed.`);
    this.name = 'BookingFileError';
  }
}

// Owns every booking. Seats left are derived from the bookings, so cancelling a booking frees its seats
// without any extra bookkeeping.
//
// Every change (check, record, save) runs as one turn in a queue, one after another. A booking can therefore
// never be checked against seats that a cancellation is about to give back, and a change that fails to save
// can be undone before anything else looks at the bookings.
export class BookingStore {
  private bookings: StoredBooking[];
  private readonly tastings: readonly Tasting[];
  private readonly dataFile?: string;
  private readonly write: (file: string, contents: string) => Promise<void>;
  private turns: Promise<unknown> = Promise.resolve();

  private constructor(bookings: StoredBooking[], options: BookingStoreOptions) {
    this.bookings = bookings;
    this.tastings = options.tastings ?? TASTINGS;
    this.dataFile = options.dataFile;
    this.write = options.write ?? writeBookingsFile;
  }

  static async open(options: BookingStoreOptions = {}): Promise<BookingStore> {
    const bookings = options.dataFile ? await loadBookings(options.dataFile) : [];
    return new BookingStore(bookings, options);
  }

  listTastings(): TastingListing[] {
    return this.tastings.map((tasting) => ({ ...tasting, seatsLeft: this.seatsLeft(tasting.id) }));
  }

  findTasting(tastingId: string): Tasting | undefined {
    return this.tastings.find((tasting) => tasting.id === tastingId);
  }

  seatsLeft(tastingId: string): number {
    const tasting = this.findTasting(tastingId);
    if (!tasting) return 0;
    const guestsBooked = this.bookings
      .filter((booking) => booking.tastingId === tastingId)
      .reduce((sum, booking) => sum + booking.guests, 0);
    // A smaller catalogue can leave fewer seats than guests already booked. That is still no seats left.
    return Math.max(0, tasting.seats - guestsBooked);
  }

  createBooking(input: NewBooking): Promise<CreateBookingResult> {
    return this.inTurn(async () => {
      if (!this.findTasting(input.tastingId)) {
        return { ok: false, reason: 'unknown-tasting' };
      }
      const seatsLeft = this.seatsLeft(input.tastingId);
      if (seatsLeft === 0) {
        return { ok: false, reason: 'fully-booked' };
      }
      if (input.guests > seatsLeft) {
        return { ok: false, reason: 'not-enough-seats', seatsLeft };
      }

      const booking: StoredBooking = {
        ...input,
        reference: this.newReference(),
        createdAt: new Date().toISOString(),
      };
      this.bookings.push(booking);
      try {
        await this.save();
      } catch (error) {
        // Not saved, so it must not count: no seats taken and no confirmation issued.
        this.bookings.splice(this.bookings.indexOf(booking), 1);
        throw error;
      }
      return { ok: true, booking };
    });
  }

  cancelBooking(reference: string): Promise<boolean> {
    return this.inTurn(async () => {
      const index = this.bookings.findIndex((booking) => booking.reference === reference);
      if (index === -1) return false;

      const [removed] = this.bookings.splice(index, 1);
      try {
        await this.save();
      } catch (error) {
        this.bookings.splice(index, 0, removed);
        throw error;
      }
      return true;
    });
  }

  getBooking(reference: string): StoredBooking | undefined {
    return this.bookings.find((booking) => booking.reference === reference);
  }

  listBookingsByTasting(): StaffBookingGroup[] {
    return this.tastings.map((tasting) => ({
      tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt },
      bookings: this.bookings
        .filter((booking) => booking.tastingId === tasting.id)
        .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
    }));
  }

  private inTurn<T>(task: () => Promise<T>): Promise<T> {
    const turn = this.turns.then(task);
    // A failed turn must not stop the turns queued after it.
    this.turns = turn.catch(() => undefined);
    return turn;
  }

  private newReference(): string {
    let reference = generateReference();
    while (this.bookings.some((booking) => booking.reference === reference)) {
      reference = generateReference();
    }
    return reference;
  }

  private async save(): Promise<void> {
    if (!this.dataFile) return;
    const payload = JSON.stringify({ version: 1, bookings: this.bookings }, null, 2) + '\n';
    await this.write(this.dataFile, payload);
  }
}

// Writes beside the target, flushes it to disk and renames it over the target, so a crash or power cut
// never leaves a half-written file.
export async function writeBookingsFile(file: string, contents: string): Promise<void> {
  // The file holds guest names and emails, so only its owner may read it.
  await mkdir(dirname(file), { recursive: true, mode: 0o700 });
  const temporary = `${file}.tmp`;
  const handle = await open(temporary, 'w', 0o600);
  try {
    await handle.writeFile(contents);
    await handle.sync();
  } finally {
    await handle.close();
  }
  await rename(temporary, file);
  await syncDirectory(dirname(file));
}

// Makes the rename itself durable. Not every platform lets a directory be opened, so failure here is ignored;
// the file contents have already been flushed.
async function syncDirectory(directory: string): Promise<void> {
  try {
    const handle = await open(directory, 'r');
    try {
      await handle.sync();
    } finally {
      await handle.close();
    }
  } catch {
    // Directory sync is not supported here.
  }
}

async function loadBookings(file: string): Promise<StoredBooking[]> {
  let text: string;
  try {
    text = await readFile(file, 'utf8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return [];
    throw error;
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new BookingFileError(file, 'is not valid JSON');
  }
  const result = bookingsFileSchema.safeParse(parsed);
  if (!result.success) {
    throw new BookingFileError(file, 'does not have the expected structure');
  }
  return result.data.bookings;
}
