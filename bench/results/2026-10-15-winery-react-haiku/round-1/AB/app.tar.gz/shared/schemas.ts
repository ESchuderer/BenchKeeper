import { z } from 'zod';

export const MAX_GUESTS = 8;
const GUESTS_MESSAGE = `Choose between 1 and ${MAX_GUESTS} guests`;

function toNumberIfString(value: unknown): unknown {
  if (typeof value !== 'string') return value;
  return value.trim() === '' ? Number.NaN : Number(value);
}

// Shared by the booking form (client) and the booking endpoint (server), so both show the same messages.
export const bookingInputSchema = z.object({
  name: z
    .string({ error: 'Enter your name' })
    .trim()
    .min(1, 'Enter your name')
    .max(100, 'Name must be at most 100 characters'),
  email: z
    .string({ error: 'Enter your email address' })
    .trim()
    .min(1, 'Enter your email address')
    .max(254, 'Enter a valid email address')
    .email('Enter a valid email address'),
  // Form fields arrive as strings, so "2" becomes 2. Other types are not converted: true, [2] and "two" are rejected.
  guests: z.preprocess(
    toNumberIfString,
    z.number({ error: GUESTS_MESSAGE }).int(GUESTS_MESSAGE).min(1, GUESTS_MESSAGE).max(MAX_GUESTS, GUESTS_MESSAGE),
  ),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;

export const staffLoginSchema = z.object({
  password: z.string({ error: 'Enter the staff password' }).min(1, 'Enter the staff password'),
});

export type StaffLoginInput = z.infer<typeof staffLoginSchema>;
