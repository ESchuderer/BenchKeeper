// Shapes exchanged between the Node server and the React client.

export interface Tasting {
  id: string;
  title: string;
  // Local winery time without a time zone, for example "2026-11-06T18:00".
  startsAt: string;
  priceEuro: number;
  seats: number;
}

export interface TastingListing extends Tasting {
  seatsLeft: number;
}

export interface BookingConfirmation {
  reference: string;
  tasting: Pick<Tasting, 'id' | 'title' | 'startsAt' | 'priceEuro'>;
  guests: number;
  totalEuro: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffBookingGroup {
  tasting: Pick<Tasting, 'id' | 'title' | 'startsAt'>;
  bookings: StaffBooking[];
}

// Error body for every rejected request. `errors` maps a form field to its message;
// `message` is for problems that are not tied to one field.
export interface ApiErrorBody {
  message?: string;
  errors?: Partial<Record<'name' | 'email' | 'guests' | 'password', string>>;
}
