import { Route, Routes } from 'react-router';
import { Layout } from './components/Layout.js';
import { BookingPage } from './pages/BookingPage.js';
import { ConfirmationPage } from './pages/ConfirmationPage.js';
import { NotFoundPage } from './pages/NotFoundPage.js';
import { StaffPage } from './pages/StaffPage.js';
import { StartPage } from './pages/StartPage.js';

// The route table, separate from the router so tests can mount it with a memory history.
export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<StartPage />} />
        <Route path="book/:tastingId" element={<BookingPage />} />
        <Route path="bookings/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
