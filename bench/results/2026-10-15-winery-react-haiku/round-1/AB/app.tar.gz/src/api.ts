import type {
  ApiErrorBody,
  BookingConfirmation,
  StaffBookingGroup,
  TastingListing,
} from '../shared/types.js';
import type { BookingInput } from '../shared/schemas.js';

// A rejected request, with the body the server sent (field errors or a message).
export class ApiRequestError extends Error {
  readonly status: number;
  readonly body: ApiErrorBody;

  constructor(status: number, body: ApiErrorBody) {
    super(body.message ?? `Request failed with status ${status}`);
    this.name = 'ApiRequestError';
    this.status = status;
    this.body = body;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: { Accept: 'application/json', 'Content-Type': 'application/json', ...init.headers },
  });
  if (response.status === 204) return undefined as T;

  const body: unknown = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new ApiRequestError(response.status, body as ApiErrorBody);
  }
  return body as T;
}

const json = (value: unknown): string => JSON.stringify(value);

export const api = {
  listTastings: () => request<TastingListing[]>('/api/tastings'),

  createBooking: (tastingId: string, input: BookingInput) =>
    request<BookingConfirmation>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
      method: 'POST',
      body: json(input),
    }),

  getBooking: (reference: string) =>
    request<BookingConfirmation>(`/api/bookings/${encodeURIComponent(reference)}`),

  staffSession: () => request<{ signedIn: boolean }>('/api/staff/session'),

  staffLogin: (password: string) =>
    request<{ signedIn: boolean }>('/api/staff/login', { method: 'POST', body: json({ password }) }),

  staffLogout: () => request<void>('/api/staff/logout', { method: 'POST' }),

  staffBookings: () => request<{ groups: StaffBookingGroup[] }>('/api/staff/bookings'),

  cancelBooking: (reference: string) =>
    request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' }),
};
