import type { ComponentProps } from 'react';

type FieldProps = ComponentProps<'input'> & {
  label: string;
  error?: string;
};

// A labelled input with its error message underneath. The message is linked to the input
// with aria-describedby, so assistive technology reads the two together.
export function Field({ label, error, id, ...input }: FieldProps) {
  const errorId = `${id}-error`;
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium text-ink-900">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className="block min-h-11 w-full rounded-md border border-cream-300 bg-white px-3 py-2 text-base text-ink-900 shadow-sm focus:border-wine-700 focus:ring-2 focus:ring-wine-700/25 focus:outline-none aria-invalid:border-error-700 aria-invalid:ring-error-700/20"
        {...input}
      />
      {error && (
        <p id={errorId} className="text-sm font-medium text-error-700">
          {error}
        </p>
      )}
    </div>
  );
}
