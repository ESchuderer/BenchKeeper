import { Link, Outlet } from 'react-router';

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b-4 border-wine-700 bg-cream-50">
        <div className="mx-auto flex max-w-5xl flex-col gap-1 px-4 py-5 sm:flex-row sm:items-end sm:justify-between sm:px-6">
          <Link to="/" className="inline-flex min-h-11 items-center font-serif text-2xl font-semibold text-wine-800 hover:text-wine-700 sm:text-3xl">
            Weingut Kieselbrunnen
          </Link>
          <p className="font-serif text-sm italic text-ink-600">Family winery · Wine tastings</p>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        <Outlet />
      </main>

      <footer className="border-t border-cream-300 bg-cream-50">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-6 text-sm text-ink-600 sm:px-6">
          <span>© Weingut Kieselbrunnen</span>
          <Link to="/staff" className="inline-flex min-h-11 items-center rounded-sm text-ink-600 underline underline-offset-4 hover:text-wine-700">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}
