import type { ReactNode } from 'react';

type NoticeProps = {
  tone: 'error' | 'info';
  children: ReactNode;
};

// Form-level and page-level messages. role="alert" makes the message announced when it appears.
export function Notice({ tone, children }: NoticeProps) {
  const styles =
    tone === 'error'
      ? 'border-error-700/30 bg-error-50 text-error-700'
      : 'border-cream-300 bg-cream-50 text-ink-700';
  return (
    <div role="alert" className={`rounded-md border px-4 py-3 text-sm font-medium ${styles}`}>
      {children}
    </div>
  );
}
