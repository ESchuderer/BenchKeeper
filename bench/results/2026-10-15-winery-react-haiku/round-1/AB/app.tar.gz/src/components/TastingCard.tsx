import { Link } from 'react-router';
import type { TastingListing } from '../../shared/types.js';
import { formatEuro, formatStartsAt, seatsLeftLabel } from '../format.js';
import { primaryButton } from './buttons.js';

export function TastingCard({ tasting }: { tasting: TastingListing }) {
  const fullyBooked = tasting.seatsLeft === 0;
  const titleId = `tasting-${tasting.id}`;

  return (
    <article
      aria-labelledby={titleId}
      className={`flex flex-col rounded-lg border p-6 shadow-sm ${
        fullyBooked ? 'border-cream-300 bg-cream-200/60' : 'border-cream-300 bg-cream-50'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <h2 id={titleId} className={`font-serif text-2xl font-semibold ${fullyBooked ? 'text-ink-600' : 'text-wine-800'}`}>
          {tasting.title}
        </h2>
        {fullyBooked && (
          <span className="shrink-0 rounded-full bg-ink-600 px-3 py-1 text-xs font-semibold tracking-wide text-white uppercase">
            Fully booked
          </span>
        )}
      </div>

      <dl className="mt-4 space-y-2 text-sm text-ink-700">
        <div>
          <dt className="sr-only">Date and time</dt>
          <dd>
            <time dateTime={tasting.startsAt}>{formatStartsAt(tasting.startsAt)}</time>
          </dd>
        </div>
        <div>
          <dt className="sr-only">Price</dt>
          <dd>
            <span className="font-semibold text-ink-900">{formatEuro(tasting.priceEuro)}</span> per guest
          </dd>
        </div>
        <div>
          <dt className="sr-only">Seats</dt>
          <dd className={fullyBooked ? 'font-medium text-ink-600' : 'font-medium text-success-700'}>
            {fullyBooked ? 'No seats left' : seatsLeftLabel(tasting.seatsLeft)}
          </dd>
        </div>
      </dl>

      <div className="mt-6 flex-1 content-end">
        {fullyBooked ? (
          <p className="text-sm text-ink-600">We are sorry, this tasting is sold out.</p>
        ) : (
          <Link to={`/book/${tasting.id}`} className={`${primaryButton} w-full sm:w-auto`}>
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
