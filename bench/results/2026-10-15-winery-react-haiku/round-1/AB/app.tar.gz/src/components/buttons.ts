const base =
  'inline-flex min-h-11 items-center justify-center rounded-md px-5 py-2.5 text-base font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-wine-700 disabled:cursor-not-allowed disabled:opacity-60';

export const primaryButton = `${base} bg-wine-700 text-white shadow-sm hover:bg-wine-800`;

export const secondaryButton = `${base} border border-wine-700 bg-transparent text-wine-700 hover:bg-wine-700/5`;

export const dangerButton = `${base} border border-error-700 bg-white px-4 text-error-700 hover:bg-error-50`;

// Text links that are used as controls (back links, footer links) keep the same 44px minimum height.
export const textLink = 'inline-flex min-h-11 items-center font-medium text-wine-700 underline underline-offset-4';
