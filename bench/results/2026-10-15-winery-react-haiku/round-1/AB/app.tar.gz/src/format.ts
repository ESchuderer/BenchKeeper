// The winery works in local time, so dates are formatted from their parts in UTC to avoid any shift.
export function formatStartsAt(startsAt: string): string {
  const [datePart, timePart] = startsAt.split('T');
  const [year, month, day] = datePart.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  const weekday = date.toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
  const monthName = date.toLocaleDateString('en-GB', { month: 'long', timeZone: 'UTC' });
  return `${weekday} ${day} ${monthName} ${year}, ${timePart}`;
}

export function formatEuro(amount: number): string {
  return `EUR ${amount}`;
}

export function seatsLeftLabel(seatsLeft: number): string {
  return seatsLeft === 1 ? '1 seat left' : `${seatsLeft} seats left`;
}

export function guestsLabel(guests: number): string {
  return guests === 1 ? '1 guest' : `${guests} guests`;
}
