// Wording shared by more than one page, so the same failure reads the same everywhere.
export const CONNECTION_ERROR = 'We could not reach the server. Please check your connection and try again.';
export const UNEXPECTED_ERROR = 'Something went wrong. Please try again.';
