import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import type { z } from 'zod';
import { bookingInputSchema, type BookingInput } from '../../shared/schemas.js';
import type { TastingListing } from '../../shared/types.js';
import { api, ApiRequestError } from '../api.js';
import { Field } from '../components/Field.js';
import { Notice } from '../components/Notice.js';
import { primaryButton, textLink } from '../components/buttons.js';
import { formatEuro, formatStartsAt, seatsLeftLabel } from '../format.js';
import { CONNECTION_ERROR, UNEXPECTED_ERROR } from '../messages.js';
import { useDocumentTitle } from '../useDocumentTitle.js';


export function BookingPage() {
  const { tastingId = '' } = useParams();
  const navigate = useNavigate();
  // undefined while loading, null when the tasting does not exist.
  const [tasting, setTasting] = useState<TastingListing | null | undefined>(undefined);
  const [loadFailed, setLoadFailed] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  useDocumentTitle(tasting ? `Book ${tasting.title}` : undefined);

  // Form values hold what the inputs produce (guests may still be a string); the schema turns them into BookingInput.
  const { register, handleSubmit, setError, formState } = useForm<z.input<typeof bookingInputSchema>, unknown, BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '', guests: 2 },
  });

  const refreshTasting = useCallback(async () => {
    try {
      const all = await api.listTastings();
      setTasting(all.find((item) => item.id === tastingId) ?? null);
    } catch {
      setLoadFailed(true);
    }
  }, [tastingId]);

  useEffect(() => {
    void refreshTasting();
  }, [refreshTasting]);

  async function onSubmit(values: BookingInput) {
    if (!tasting) return;
    setFormError(null);
    try {
      const confirmation = await api.createBooking(tasting.id, values);
      navigate(`/bookings/${confirmation.reference}`);
    } catch (error) {
      if (!(error instanceof ApiRequestError)) {
        setFormError(CONNECTION_ERROR);
        return;
      }
      for (const [field, message] of Object.entries(error.body.errors ?? {})) {
        setError(field as keyof BookingInput, { type: 'server', message });
      }
      if (error.body.message) setFormError(error.body.message);
      if (!error.body.errors && !error.body.message) setFormError(UNEXPECTED_ERROR);
      // The seats may have changed, so show the current count.
      if (error.status === 409) void refreshTasting();
    }
  }

  if (loadFailed) {
    return <Notice tone="error">We could not load this tasting. Please refresh the page to try again.</Notice>;
  }
  if (tasting === undefined) {
    return <p className="text-ink-600">Loading…</p>;
  }
  if (tasting === null) {
    return (
      <div className="space-y-4">
        <h1 className="font-serif text-3xl font-semibold text-ink-900">Tasting not found</h1>
        <Link to="/" className={textLink}>
          Back to all tastings
        </Link>
      </div>
    );
  }

  const fullyBooked = tasting.seatsLeft === 0;

  return (
    <div className="mx-auto max-w-xl space-y-8">
      <Link to="/" className={textLink}>
        ← All tastings
      </Link>

      <header className="space-y-2">
        <h1 className="font-serif text-3xl font-semibold text-wine-800">{tasting.title}</h1>
        <p className="text-ink-700">
          {formatStartsAt(tasting.startsAt)} · {formatEuro(tasting.priceEuro)} per guest
        </p>
        {!fullyBooked && <p className="font-medium text-success-700">{seatsLeftLabel(tasting.seatsLeft)}</p>}
      </header>

      {fullyBooked ? (
        <Notice tone="info">
          <span className="block">This tasting is fully booked</span>
          <span className="block font-normal">Choose another tasting from the list.</span>
        </Notice>
      ) : (
        <form
          noValidate
          onSubmit={handleSubmit(onSubmit)}
          className="space-y-6 rounded-lg border border-cream-300 bg-cream-50 p-6 shadow-sm sm:p-8"
        >
          {formError && <Notice tone="error">{formError}</Notice>}

          <Field
            id="name"
            label="Name"
            autoComplete="name"
            error={formState.errors.name?.message}
            {...register('name')}
          />
          <Field
            id="email"
            label="Email"
            type="email"
            inputMode="email"
            autoComplete="email"
            error={formState.errors.email?.message}
            {...register('email')}
          />
          <Field
            id="guests"
            label="Guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={8}
            step={1}
            error={formState.errors.guests?.message}
            {...register('guests')}
          />

          <button type="submit" disabled={formState.isSubmitting} className={`${primaryButton} w-full`}>
            Book
          </button>
        </form>
      )}
    </div>
  );
}
