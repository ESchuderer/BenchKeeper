import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import type { BookingConfirmation } from '../../shared/types.js';
import { api, ApiRequestError } from '../api.js';
import { Notice } from '../components/Notice.js';
import { textLink } from '../components/buttons.js';
import { formatEuro, formatStartsAt, guestsLabel } from '../format.js';
import { useDocumentTitle } from '../useDocumentTitle.js';

type State =
  | { status: 'loading' }
  | { status: 'found'; booking: BookingConfirmation }
  | { status: 'missing'; message: string }
  | { status: 'failed' };

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const [state, setState] = useState<State>({ status: 'loading' });
  useDocumentTitle(state.status === 'found' ? 'Booking confirmed' : undefined);

  useEffect(() => {
    let active = true;
    api
      .getBooking(reference)
      .then((booking) => active && setState({ status: 'found', booking }))
      .catch((error: unknown) => {
        if (!active) return;
        if (error instanceof ApiRequestError && error.status === 404) {
          setState({ status: 'missing', message: error.body.message ?? 'This booking could not be found.' });
        } else {
          setState({ status: 'failed' });
        }
      });
    return () => {
      active = false;
    };
  }, [reference]);

  if (state.status === 'loading') {
    return <p className="text-ink-600">Loading your booking…</p>;
  }

  if (state.status === 'failed') {
    return <Notice tone="error">We could not load this booking. Please refresh the page to try again.</Notice>;
  }

  if (state.status === 'missing') {
    return (
      <div className="mx-auto max-w-xl space-y-4">
        <h1 className="font-serif text-3xl font-semibold text-ink-900">Booking not found</h1>
        <p className="text-ink-700">{state.message}</p>
        <Link to="/" className={textLink}>
          Back to all tastings
        </Link>
      </div>
    );
  }

  const { booking } = state;
  return (
    <section className="mx-auto max-w-xl space-y-8 rounded-lg border border-cream-300 bg-white p-6 shadow-sm sm:p-8">
      <div className="flex items-center gap-3">
        <span
          aria-hidden="true"
          className="flex size-10 shrink-0 items-center justify-center rounded-full bg-success-50 text-success-700"
        >
          <svg viewBox="0 0 20 20" fill="currentColor" className="size-5">
            <path
              fillRule="evenodd"
              d="M16.7 5.3a1 1 0 0 1 0 1.4l-7.5 7.5a1 1 0 0 1-1.4 0L3.3 9.7a1 1 0 1 1 1.4-1.4l3.8 3.8 6.8-6.8a1 1 0 0 1 1.4 0Z"
              clipRule="evenodd"
            />
          </svg>
        </span>
        <h1 className="font-serif text-3xl font-semibold text-success-700">Booking confirmed</h1>
      </div>

      <p className="leading-relaxed text-ink-700">
        Thank you. We look forward to welcoming you. Please keep your booking reference in case you need to reach us.
      </p>

      <dl className="divide-y divide-cream-200 border-y border-cream-200">
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-sm text-ink-600">Tasting</dt>
          <dd className="font-semibold text-ink-900">{booking.tasting.title}</dd>
        </div>
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-sm text-ink-600">Date and time</dt>
          <dd className="text-ink-900">{formatStartsAt(booking.tasting.startsAt)}</dd>
        </div>
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-sm text-ink-600">Guests</dt>
          <dd className="text-ink-900">{guestsLabel(booking.guests)}</dd>
        </div>
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-sm text-ink-600">Total</dt>
          <dd className="font-semibold text-ink-900">{formatEuro(booking.totalEuro)}</dd>
        </div>
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-sm text-ink-600">Booking reference</dt>
          <dd className="font-mono text-lg font-semibold tracking-widest text-wine-800">{booking.reference}</dd>
        </div>
      </dl>

      <Link to="/" className={textLink}>
        Back to all tastings
      </Link>
    </section>
  );
}
