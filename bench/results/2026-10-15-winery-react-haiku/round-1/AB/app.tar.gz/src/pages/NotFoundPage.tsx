import { Link } from 'react-router';
import { textLink } from '../components/buttons.js';
import { useDocumentTitle } from '../useDocumentTitle.js';

export function NotFoundPage() {
  useDocumentTitle('Page not found');
  return (
    <div className="mx-auto max-w-xl space-y-4">
      <h1 className="font-serif text-3xl font-semibold text-ink-900">Page not found</h1>
      <p className="text-ink-700">The page you were looking for does not exist.</p>
      <Link to="/" className={textLink}>
        Back to all tastings
      </Link>
    </div>
  );
}
