import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { staffLoginSchema, type StaffLoginInput } from '../../shared/schemas.js';
import type { StaffBookingGroup } from '../../shared/types.js';
import { api, ApiRequestError } from '../api.js';
import { Field } from '../components/Field.js';
import { Notice } from '../components/Notice.js';
import { dangerButton, primaryButton, secondaryButton } from '../components/buttons.js';
import { formatStartsAt, guestsLabel } from '../format.js';
import { CONNECTION_ERROR } from '../messages.js';
import { useDocumentTitle } from '../useDocumentTitle.js';

type View =
  | { status: 'loading' }
  | { status: 'failed' }
  | { status: 'signed-out' }
  | { status: 'signed-in'; groups: StaffBookingGroup[] };

export function StaffPage() {
  useDocumentTitle('Staff');
  const [view, setView] = useState<View>({ status: 'loading' });
  const [actionError, setActionError] = useState<string | null>(null);

  const loadBookings = useCallback(async () => {
    try {
      const { groups } = await api.staffBookings();
      setActionError(null);
      setView({ status: 'signed-in', groups });
    } catch (error) {
      // A 401 means the session has ended, so ask for the password again.
      if (error instanceof ApiRequestError && error.status === 401) {
        setView({ status: 'signed-out' });
        return;
      }
      // A failed refresh keeps the list on screen and reports the problem; a failed first load has nothing to show.
      setActionError(CONNECTION_ERROR);
      setView((current) => (current.status === 'signed-in' ? current : { status: 'failed' }));
    }
  }, []);

  const start = useCallback(async () => {
    try {
      const { signedIn } = await api.staffSession();
      if (signedIn) {
        await loadBookings();
      } else {
        setView({ status: 'signed-out' });
      }
    } catch {
      setView({ status: 'failed' });
    }
  }, [loadBookings]);

  useEffect(() => {
    void start();
  }, [start]);

  async function cancel(reference: string) {
    setActionError(null);
    try {
      await api.cancelBooking(reference);
      await loadBookings();
    } catch {
      setActionError('The booking could not be cancelled. Please try again.');
    }
  }

  async function signOut() {
    await api.staffLogout().catch(() => undefined);
    setActionError(null);
    setView({ status: 'signed-out' });
  }

  if (view.status === 'loading') {
    return <p className="text-ink-600">Loading…</p>;
  }

  if (view.status === 'failed') {
    return (
      <div className="mx-auto max-w-md space-y-4">
        <Notice tone="error">{CONNECTION_ERROR}</Notice>
        <button
          type="button"
          onClick={() => {
            setView({ status: 'loading' });
            void start();
          }}
          className={secondaryButton}
        >
          Try again
        </button>
      </div>
    );
  }

  if (view.status === 'signed-out') {
    return (
      <div className="mx-auto max-w-md space-y-6">
        <header className="space-y-2">
          <h1 className="font-serif text-3xl font-semibold text-ink-900">Staff sign-in</h1>
          <p className="text-ink-700">Enter the staff password to see the bookings.</p>
        </header>
        <SignInForm onSignedIn={loadBookings} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <header className="space-y-2">
          <h1 className="font-serif text-3xl font-semibold text-ink-900">Bookings</h1>
          <p className="text-ink-700">Every booking, grouped by tasting.</p>
        </header>
        <button type="button" onClick={signOut} className={secondaryButton}>
          Sign out
        </button>
      </div>

      {actionError && <Notice tone="error">{actionError}</Notice>}

      {view.groups.map((group) => {
        const headingId = `group-${group.tasting.id}`;
        return (
          <section key={group.tasting.id} aria-labelledby={headingId} className="rounded-lg border border-cream-300 bg-white p-6 shadow-sm">
            <header className="border-b border-cream-200 pb-4">
              <h2 id={headingId} className="font-serif text-2xl font-semibold text-wine-800">
                {group.tasting.title}
              </h2>
              <p className="text-sm text-ink-600">{formatStartsAt(group.tasting.startsAt)}</p>
            </header>

            {group.bookings.length === 0 ? (
              <p className="py-6 text-ink-600">No bookings yet</p>
            ) : (
              <ul className="divide-y divide-cream-200">
                {group.bookings.map((booking) => (
                  <li
                    key={booking.reference}
                    className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6"
                  >
                    <div className="min-w-0">
                      <p className="font-semibold text-ink-900">{booking.name}</p>
                      <p className="break-all text-sm text-ink-600">{booking.email}</p>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-ink-700">
                      <span>{guestsLabel(booking.guests)}</span>
                      <span className="font-mono font-semibold tracking-wider text-wine-800">{booking.reference}</span>
                    </div>
                    <button type="button" onClick={() => cancel(booking.reference)} className={dangerButton}>
                      Cancel
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        );
      })}
    </div>
  );
}

function SignInForm({ onSignedIn }: { onSignedIn: () => Promise<void> }) {
  const [formError, setFormError] = useState<string | null>(null);
  const { register, handleSubmit, setError, formState } = useForm<StaffLoginInput>({
    resolver: zodResolver(staffLoginSchema),
    defaultValues: { password: '' },
  });

  async function onSubmit(values: StaffLoginInput) {
    setFormError(null);
    try {
      await api.staffLogin(values.password);
    } catch (error) {
      if (!(error instanceof ApiRequestError)) {
        setFormError(CONNECTION_ERROR);
        return;
      }
      if (error.body.errors?.password) {
        setError('password', { type: 'server', message: error.body.errors.password });
      }
      if (error.body.message) setFormError(error.body.message);
      if (!error.body.errors && !error.body.message) {
        setFormError('Sign-in failed. Please try again.');
      }
      return;
    }
    // Signed in. Loading the bookings can fail on its own, and the page shows that failure in its own view.
    await onSignedIn();
  }

  return (
    <form
      noValidate
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-6 rounded-lg border border-cream-300 bg-cream-50 p-6 shadow-sm sm:p-8"
    >
      {formError && <Notice tone="error">{formError}</Notice>}
      <Field
        id="password"
        label="Password"
        type="password"
        autoComplete="current-password"
        error={formState.errors.password?.message}
        {...register('password')}
      />
      <button type="submit" disabled={formState.isSubmitting} className={`${primaryButton} w-full`}>
        Sign in
      </button>
    </form>
  );
}
