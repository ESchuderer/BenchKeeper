import { useEffect, useState } from 'react';
import type { TastingListing } from '../../shared/types.js';
import { api } from '../api.js';
import { TastingCard } from '../components/TastingCard.js';
import { Notice } from '../components/Notice.js';
import { useDocumentTitle } from '../useDocumentTitle.js';

export function StartPage() {
  useDocumentTitle();
  const [tastings, setTastings] = useState<TastingListing[] | null>(null);
  const [loadFailed, setLoadFailed] = useState(false);

  useEffect(() => {
    let active = true;
    api
      .listTastings()
      .then((result) => active && setTastings(result))
      .catch(() => active && setLoadFailed(true));
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="space-y-10">
      <section className="max-w-2xl space-y-4">
        <h1 className="font-serif text-3xl font-semibold text-ink-900 sm:text-4xl">Taste our wines with us</h1>
        <p className="text-lg leading-relaxed text-ink-700">
          Join the winemakers in our cellar for an evening or an afternoon of tasting. Choose a tasting below and reserve
          your seats. Prices are per guest.
        </p>
      </section>

      {loadFailed && <Notice tone="error">We could not load the tastings. Please refresh the page to try again.</Notice>}

      {!loadFailed && !tastings && <p className="text-ink-600">Loading tastings…</p>}

      {tastings && (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {tastings.map((tasting) => (
            <TastingCard key={tasting.id} tasting={tasting} />
          ))}
        </div>
      )}
    </div>
  );
}
