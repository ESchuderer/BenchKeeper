// @vitest-environment jsdom
import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { api, ApiRequestError } from '../../src/api.js';
import { renderAt } from './renderApp.js';
import { confirmation, listing } from './fixtures.js';

afterEach(() => {
  vi.restoreAllMocks();
});

async function openRiesling() {
  vi.spyOn(api, 'listTastings').mockResolvedValue(listing);
  renderAt('/book/riesling-evening');
  return screen.findByRole('heading', { name: 'Riesling Evening' });
}

describe('booking form', () => {
  it('shows the tasting title and the Name, Email and Guests fields with a Book button', async () => {
    await openRiesling();
    expect(screen.getByLabelText('Name')).toBeTruthy();
    expect(screen.getByLabelText('Email')).toBeTruthy();
    expect(screen.getByLabelText('Guests')).toBeTruthy();
    expect(screen.getByRole('button', { name: 'Book' })).toBeTruthy();
  });

  it('shows "Tasting not found" for an unknown tasting', async () => {
    vi.spyOn(api, 'listTastings').mockResolvedValue(listing);
    renderAt('/book/no-such-tasting');
    expect(await screen.findByText('Tasting not found')).toBeTruthy();
    expect(screen.queryByRole('button', { name: 'Book' })).toBeNull();
  });

  it('shows each invalid field error next to its field and does not book', async () => {
    await openRiesling();
    const createBooking = vi.spyOn(api, 'createBooking');
    const user = userEvent.setup();

    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '0');
    await user.type(screen.getByLabelText('Email'), 'guest@example');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    const name = screen.getByLabelText('Name');
    const email = screen.getByLabelText('Email');
    const guests = screen.getByLabelText('Guests');

    expect(await screen.findByText('Enter your name')).toBeTruthy();
    expect(screen.getByText('Enter a valid email address')).toBeTruthy();
    expect(screen.getByText('Choose between 1 and 8 guests')).toBeTruthy();
    expect(createBooking).not.toHaveBeenCalled();

    // Each message is linked to its own field, so screen readers announce them together.
    expect(name.getAttribute('aria-invalid')).toBe('true');
    expect(document.getElementById(name.getAttribute('aria-describedby')!)?.textContent).toBe('Enter your name');
    expect(document.getElementById(email.getAttribute('aria-describedby')!)?.textContent).toBe('Enter a valid email address');
    expect(document.getElementById(guests.getAttribute('aria-describedby')!)?.textContent).toBe(
      'Choose between 1 and 8 guests',
    );
  });

  it('shows the seat limit from the server next to the Guests field and keeps what the guest typed', async () => {
    await openRiesling();
    vi.spyOn(api, 'createBooking').mockRejectedValue(
      new ApiRequestError(409, { errors: { guests: 'Only 1 seat left for this tasting' } }),
    );
    const user = userEvent.setup();
    await user.type(screen.getByLabelText('Name'), 'Anna Berger');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Only 1 seat left for this tasting')).toBeTruthy();
    expect((screen.getByLabelText('Name') as HTMLInputElement).value).toBe('Anna Berger');
    expect((screen.getByLabelText('Email') as HTMLInputElement).value).toBe('anna@example.com');
  });

  it('navigates to the confirmation after a successful booking', async () => {
    await openRiesling();
    vi.spyOn(api, 'createBooking').mockResolvedValue(confirmation);
    vi.spyOn(api, 'getBooking').mockResolvedValue(confirmation);
    const user = userEvent.setup();
    await user.type(screen.getByLabelText('Name'), 'Anna Berger');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeTruthy();
    expect(screen.getByText('KB-ABC234')).toBeTruthy();
  });

  it('shows the fully booked message above the form when the server rejects a booking', async () => {
    await openRiesling();
    vi.spyOn(api, 'createBooking').mockRejectedValue(new ApiRequestError(409, { message: 'This tasting is fully booked' }));
    const user = userEvent.setup();
    await user.type(screen.getByLabelText('Name'), 'Anna Berger');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    const alert = await screen.findByRole('alert');
    expect(alert.textContent).toBe('This tasting is fully booked');
  });

  it('does not offer the form for a fully booked tasting', async () => {
    vi.spyOn(api, 'listTastings').mockResolvedValue(listing);
    renderAt('/book/winter-tasting');
    expect(await screen.findByText('This tasting is fully booked')).toBeTruthy();
    await waitFor(() => expect(screen.queryByLabelText('Name')).toBeNull());
  });
});
