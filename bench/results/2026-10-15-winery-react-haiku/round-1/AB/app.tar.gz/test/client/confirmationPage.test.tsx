// @vitest-environment jsdom
import { screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { api, ApiRequestError } from '../../src/api.js';
import { renderAt } from './renderApp.js';
import { confirmation } from './fixtures.js';

afterEach(() => {
  vi.restoreAllMocks();
});

describe('confirmation page', () => {
  it('shows the heading, tasting, guests, total price and booking reference', async () => {
    vi.spyOn(api, 'getBooking').mockResolvedValue(confirmation);
    renderAt('/bookings/KB-ABC234');

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeTruthy();
    expect(screen.getByText('Riesling Evening')).toBeTruthy();
    expect(screen.getByText('2 guests')).toBeTruthy();
    expect(screen.getByText('EUR 50')).toBeTruthy();
    expect(screen.getByText('KB-ABC234')).toBeTruthy();
  });

  it('uses the singular for one guest', async () => {
    vi.spyOn(api, 'getBooking').mockResolvedValue({ ...confirmation, guests: 1, totalEuro: 25 });
    renderAt('/bookings/KB-ABC234');
    expect(await screen.findByText('1 guest')).toBeTruthy();
  });

  it('explains when the booking cannot be found', async () => {
    vi.spyOn(api, 'getBooking').mockRejectedValue(
      new ApiRequestError(404, { message: 'We could not find this booking. It may have been cancelled.' }),
    );
    renderAt('/bookings/KB-ZZZZZZ');
    expect(
      await screen.findByText('We could not find this booking. It may have been cancelled.'),
    ).toBeTruthy();
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).toBeNull();
  });
});
