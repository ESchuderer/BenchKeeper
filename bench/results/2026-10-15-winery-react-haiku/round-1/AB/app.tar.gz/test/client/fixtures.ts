import type { BookingConfirmation, StaffBookingGroup, TastingListing } from '../../shared/types.js';

export const listing: TastingListing[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEuro: 25, seats: 12, seatsLeft: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceEuro: 32, seats: 8, seatsLeft: 1 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceEuro: 28, seats: 10, seatsLeft: 0 },
];

export const confirmation: BookingConfirmation = {
  reference: 'KB-ABC234',
  tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEuro: 25 },
  guests: 2,
  totalEuro: 50,
};

export const staffGroups: StaffBookingGroup[] = [
  {
    tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00' },
    bookings: [
      { reference: 'KB-ABC234', name: 'Anna Berger', email: 'anna@example.com', guests: 2 },
      { reference: 'KB-DEF567', name: 'Lukas Weiss', email: 'lukas@example.com', guests: 1 },
    ],
  },
  {
    tasting: { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00' },
    bookings: [],
  },
];
