// @vitest-environment jsdom
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { api, ApiRequestError } from '../../src/api.js';
import { renderAt } from './renderApp.js';
import { staffGroups } from './fixtures.js';

const CONNECTION_ERROR = 'We could not reach the server. Please check your connection and try again.';

afterEach(() => {
  vi.restoreAllMocks();
});

function signedOut() {
  vi.spyOn(api, 'staffSession').mockResolvedValue({ signedIn: false });
}

function signedIn(groups = staffGroups) {
  vi.spyOn(api, 'staffSession').mockResolvedValue({ signedIn: true });
  vi.spyOn(api, 'staffBookings').mockResolvedValue({ groups });
}

describe('staff sign-in', () => {
  it('shows a Password field and a Sign in button, and no bookings, when signed out', async () => {
    signedOut();
    const staffBookings = vi.spyOn(api, 'staffBookings');
    renderAt('/staff');
    expect(await screen.findByLabelText('Password')).toBeTruthy();
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeTruthy();
    expect(staffBookings).not.toHaveBeenCalled();
  });

  it('shows "Incorrect password" next to the Password field', async () => {
    signedOut();
    vi.spyOn(api, 'staffLogin').mockRejectedValue(new ApiRequestError(401, { errors: { password: 'Incorrect password' } }));
    renderAt('/staff');
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Password'), 'vine-2027');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    const password = screen.getByLabelText('Password');
    expect(await screen.findByText('Incorrect password')).toBeTruthy();
    expect(password.getAttribute('aria-invalid')).toBe('true');
  });

  it('shows the not-configured message when no staff password is set on the server', async () => {
    signedOut();
    vi.spyOn(api, 'staffLogin').mockRejectedValue(
      new ApiRequestError(503, { message: 'Staff sign-in is not configured' }),
    );
    renderAt('/staff');
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Password'), 'anything');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    expect((await screen.findByRole('alert')).textContent).toBe('Staff sign-in is not configured');
  });
});

describe('staff bookings', () => {
  it('lists bookings grouped by tasting with name, email, guests and reference', async () => {
    signedIn();
    renderAt('/staff');

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    expect(within(riesling).getByText('Anna Berger')).toBeTruthy();
    expect(within(riesling).getByText('anna@example.com')).toBeTruthy();
    expect(within(riesling).getByText('2 guests')).toBeTruthy();
    expect(within(riesling).getByText('KB-ABC234')).toBeTruthy();
    expect(within(riesling).getByText('Lukas Weiss')).toBeTruthy();
  });

  it('shows "No bookings yet" for a tasting without bookings', async () => {
    signedIn();
    renderAt('/staff');
    const red = await screen.findByRole('region', { name: 'Red Wine Cellar Tour' });
    expect(within(red).getByText('No bookings yet')).toBeTruthy();
  });

  it('cancels a booking with the Cancel button and refreshes the list', async () => {
    signedIn();
    const cancel = vi.spyOn(api, 'cancelBooking').mockResolvedValue(undefined);
    const afterCancel = [
      { ...staffGroups[0], bookings: [staffGroups[0].bookings[1]] },
      staffGroups[1],
    ];
    vi.spyOn(api, 'staffBookings')
      .mockResolvedValueOnce({ groups: staffGroups })
      .mockResolvedValueOnce({ groups: afterCancel });

    renderAt('/staff');
    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    const user = userEvent.setup();
    await user.click(within(riesling).getAllByRole('button', { name: 'Cancel' })[0]);

    expect(cancel).toHaveBeenCalledWith('KB-ABC234');
    await waitFor(() => expect(screen.queryByText('Anna Berger')).toBeNull());
    expect(screen.getByText('Lukas Weiss')).toBeTruthy();
  });

  it('shows a connection error with a retry when the bookings cannot be loaded', async () => {
    signedIn();
    vi.spyOn(api, 'staffBookings')
      .mockRejectedValueOnce(new TypeError('Failed to fetch'))
      .mockResolvedValueOnce({ groups: staffGroups });
    renderAt('/staff');

    expect(await screen.findByText(CONNECTION_ERROR)).toBeTruthy();
    const user = userEvent.setup();
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByRole('region', { name: 'Riesling Evening' })).toBeTruthy();
  });

  it('signs out and returns to the sign-in form', async () => {
    signedIn();
    const logout = vi.spyOn(api, 'staffLogout').mockResolvedValue(undefined);
    renderAt('/staff');
    const user = userEvent.setup();
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(logout).toHaveBeenCalled();
    expect(await screen.findByLabelText('Password')).toBeTruthy();
  });
});
