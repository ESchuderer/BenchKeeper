// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { api } from '../../src/api.js';
import { renderAt } from './renderApp.js';
import { listing } from './fixtures.js';

afterEach(() => {
  vi.restoreAllMocks();
});

describe('start page', () => {
  it('lists each tasting with title, date and time, price per guest and seats left', async () => {
    vi.spyOn(api, 'listTastings').mockResolvedValue(listing);
    renderAt('/');

    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(riesling).getByText(/6 November 2026/)).toBeTruthy();
    expect(within(riesling).getByText(/18:00/)).toBeTruthy();
    expect(within(riesling).getByText('EUR 25')).toBeTruthy();
    expect(within(riesling).getByText('12 seats left')).toBeTruthy();

    const winter = screen.getByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText(/5 December 2026/)).toBeTruthy();
    expect(within(winter).getByText(/17:00/)).toBeTruthy();
    expect(within(winter).getByText('EUR 28')).toBeTruthy();
  });

  it('uses the singular for one seat left', async () => {
    vi.spyOn(api, 'listTastings').mockResolvedValue(listing);
    renderAt('/');
    const red = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(red).getByText('1 seat left')).toBeTruthy();
  });

  it('shows a fully booked tasting with a badge and no booking action', async () => {
    vi.spyOn(api, 'listTastings').mockResolvedValue(listing);
    renderAt('/');
    const winter = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText('Fully booked')).toBeTruthy();
    expect(within(winter).queryByRole('link', { name: 'Book Winter Tasting' })).toBeNull();
  });

  it('gives each tasting with seats a "Book <title>" link to its booking form', async () => {
    vi.spyOn(api, 'listTastings').mockResolvedValue(listing);
    renderAt('/');
    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link.getAttribute('href')).toBe('/book/riesling-evening');
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeTruthy();
  });
});
