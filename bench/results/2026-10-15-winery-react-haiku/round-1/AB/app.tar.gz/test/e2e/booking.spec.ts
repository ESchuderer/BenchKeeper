import { expect, test, type Locator, type Page } from '@playwright/test';

// The steps run in order against one server, so later steps see the bookings made by earlier ones.
test.describe.configure({ mode: 'serial' });

async function bookTasting(page: Page, title: string, guests: number, name = 'Anna Berger') {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${title}` }).click();
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill(String(guests));
  await page.getByRole('button', { name: 'Book', exact: true }).click();
}

function rieslingCard(page: Page) {
  return page.getByRole('article', { name: 'Riesling Evening' });
}

// Lists the page's visible tappable controls that are shorter than 44 CSS pixels.
async function shortTapTargets(locator: Locator) {
  return locator.evaluateAll((elements) =>
    elements
      .filter((element) => (element as HTMLElement).offsetParent !== null)
      .map((element) => ({
        text: element.textContent?.trim() ?? '',
        height: Math.round(element.getBoundingClientRect().height),
      }))
      .filter((target) => target.height < 44),
  );
}

test('the start page lists the three tastings with seats left', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
  await expect(page.getByText('12 seats left')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Red Wine Cellar Tour' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Winter Tasting' })).toBeVisible();
});

test('a booking form rejects invalid input next to each field', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'Book Riesling Evening' }).click();
  await page.getByLabel('Guests').fill('0');
  await page.getByRole('button', { name: 'Book', exact: true }).click();

  await expect(page.getByText('Enter your name')).toBeVisible();
  await expect(page.getByText('Enter your email address')).toBeVisible();
  await expect(page.getByText('Choose between 1 and 8 guests')).toBeVisible();
  await expect(page.getByLabel('Name')).toHaveAttribute('aria-invalid', 'true');
});

test('a guest books two seats and sees the confirmation', async ({ page }) => {
  await bookTasting(page, 'Riesling Evening', 2);

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(page.getByText('2 guests')).toBeVisible();
  await expect(page.getByText('EUR 50')).toBeVisible();
  await expect(page.getByText(/^KB-[A-Z2-9]{6}$/)).toBeVisible();

  await page.goto('/');
  await expect(rieslingCard(page).getByText('10 seats left')).toBeVisible();
});

test('a booking larger than the seats left is rejected next to the Guests field', async ({ page }) => {
  await bookTasting(page, 'Red Wine Cellar Tour', 6);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await bookTasting(page, 'Red Wine Cellar Tour', 3, 'Lukas Weiss');
  const guests = page.getByLabel('Guests');
  await expect(page.getByText('Only 2 seats left for this tasting')).toBeVisible();
  await expect(guests).toHaveAttribute('aria-invalid', 'true');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
});

test('staff sign in, see bookings by tasting, and cancel one to free its seats', async ({ page }) => {
  await page.goto('/staff');
  await page.getByLabel('Password').fill('wrong-password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByText('Incorrect password')).toBeVisible();

  await page.getByLabel('Password').fill('vine-2026');
  await page.getByRole('button', { name: 'Sign in' }).click();
  const riesling = page.getByRole('region', { name: 'Riesling Evening' });
  await expect(riesling.getByText('anna@example.com')).toBeVisible();
  await expect(riesling.getByText('2 guests')).toBeVisible();

  await riesling.getByRole('button', { name: 'Cancel' }).click();
  await expect(riesling.getByText('No bookings yet')).toBeVisible();

  await page.goto('/');
  await expect(rieslingCard(page).getByText('12 seats left')).toBeVisible();
});

test.describe('on a 360 pixel wide phone', () => {
  test.use({ viewport: { width: 360, height: 780 }, isMobile: true, hasTouch: true });

  test('pages fit the screen and tappable controls are at least 44 pixels high', async ({ page }) => {
    const pages = ['/', '/book/riesling-evening', '/staff'];
    for (const path of pages) {
      await page.goto(path);
      await expect(page.locator('main')).toBeVisible();
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
      );
      expect(overflow, `horizontal overflow on ${path}`).toBeLessThanOrEqual(0);
      expect(await shortTapTargets(page.locator('header a, main a, main button, footer a'))).toEqual([]);
    }
  });

  test('the booking form and confirmation are usable on a phone', async ({ page }) => {
    await bookTasting(page, 'Winter Tasting', 2);
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
    );
    expect(overflow).toBeLessThanOrEqual(0);
    expect(await shortTapTargets(page.locator('header a, main a, footer a'))).toEqual([]);
  });
});
