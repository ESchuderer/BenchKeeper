import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../server/app.js';
import { BookingStore } from '../../server/store.js';

const RIESLING = 'riesling-evening';
const RED = 'red-wine-cellar-tour';
const WINTER = 'winter-tasting';

const NOT_FOUND_MESSAGE = 'We could not find this booking. It may have been cancelled.';

// A small client build so the app-shell fallback can be tested without running Vite.
const clientDir = mkdtempSync(join(tmpdir(), 'kieselbrunnen-client-'));
mkdirSync(join(clientDir, 'assets'));
writeFileSync(join(clientDir, 'index.html'), '<!doctype html><title>APP SHELL</title>');
writeFileSync(join(clientDir, 'assets', 'app.js'), 'console.log("app");');

afterAll(() => {
  rmSync(clientDir, { recursive: true, force: true });
});

let store: BookingStore;
let app: ReturnType<typeof createApp>;

beforeEach(async () => {
  store = await BookingStore.open({});
  app = createApp({ store, staffPassword: 'vine-2026', clientDir });
});

const validBooking = { name: 'Anna Berger', email: 'anna@example.com', guests: 2 };

describe('GET /api/tastings', () => {
  it('lists the three tastings with their seats left', async () => {
    const response = await request(app).get('/api/tastings');
    expect(response.status).toBe(200);
    expect(response.body).toEqual([
      expect.objectContaining({ id: RIESLING, title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEuro: 25, seats: 12, seatsLeft: 12 }),
      expect.objectContaining({ id: RED, title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceEuro: 32, seats: 8, seatsLeft: 8 }),
      expect.objectContaining({ id: WINTER, title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceEuro: 28, seats: 10, seatsLeft: 10 }),
    ]);
  });

  it('shows the reduced seats after a booking', async () => {
    await request(app).post(`/api/tastings/${RIESLING}/bookings`).send(validBooking).expect(201);
    const response = await request(app).get('/api/tastings');
    expect(response.body.find((t: { id: string }) => t.id === RIESLING).seatsLeft).toBe(10);
  });
});

describe('POST /api/tastings/:tastingId/bookings', () => {
  it('accepts a valid booking and returns the confirmation details', async () => {
    const response = await request(app).post(`/api/tastings/${RIESLING}/bookings`).send(validBooking);
    expect(response.status).toBe(201);
    expect(response.body).toEqual({
      reference: expect.stringMatching(/^KB-[A-Z2-9]{6}$/),
      tasting: { id: RIESLING, title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEuro: 25 },
      guests: 2,
      totalEuro: 50,
    });
  });

  it('returns field errors for invalid input and takes no seats', async () => {
    const response = await request(app)
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send({ name: '', email: 'guest@example', guests: 0 });
    expect(response.status).toBe(400);
    expect(response.body).toEqual({
      errors: {
        name: 'Enter your name',
        email: 'Enter a valid email address',
        guests: 'Choose between 1 and 8 guests',
      },
    });
    expect(store.seatsLeft(RIESLING)).toBe(12);
  });

  it('rejects more guests than seats left with a message for the guests field', async () => {
    await request(app).post(`/api/tastings/${RED}/bookings`).send({ ...validBooking, guests: 5 }).expect(201);
    const response = await request(app).post(`/api/tastings/${RED}/bookings`).send({ ...validBooking, guests: 4 });
    expect(response.status).toBe(409);
    expect(response.body).toEqual({ errors: { guests: 'Only 3 seats left for this tasting' } });
    expect(store.seatsLeft(RED)).toBe(3);
  });

  it('uses the singular for a single seat left', async () => {
    await request(app).post(`/api/tastings/${WINTER}/bookings`).send({ ...validBooking, guests: 8 }).expect(201);
    await request(app).post(`/api/tastings/${WINTER}/bookings`).send({ ...validBooking, guests: 1 }).expect(201);
    const response = await request(app).post(`/api/tastings/${WINTER}/bookings`).send({ ...validBooking, guests: 2 });
    expect(response.status).toBe(409);
    expect(response.body).toEqual({ errors: { guests: 'Only 1 seat left for this tasting' } });
  });

  it('rejects a booking for a fully booked tasting with a message for the whole form', async () => {
    await request(app).post(`/api/tastings/${RIESLING}/bookings`).send({ ...validBooking, guests: 8 }).expect(201);
    await request(app).post(`/api/tastings/${RIESLING}/bookings`).send({ ...validBooking, guests: 4 }).expect(201);
    const response = await request(app).post(`/api/tastings/${RIESLING}/bookings`).send(validBooking);
    expect(response.status).toBe(409);
    expect(response.body).toEqual({ message: 'This tasting is fully booked' });
  });

  it('returns 404 for a tasting that does not exist', async () => {
    const response = await request(app).post('/api/tastings/no-such-tasting/bookings').send(validBooking);
    expect(response.status).toBe(404);
    expect(response.body).toEqual({ message: 'Tasting not found' });
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the confirmation without the guest email', async () => {
    const created = await request(app).post(`/api/tastings/${RIESLING}/bookings`).send(validBooking);
    const response = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(response.status).toBe(200);
    expect(response.body).toEqual({
      reference: created.body.reference,
      tasting: { id: RIESLING, title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEuro: 25 },
      guests: 2,
      totalEuro: 50,
    });
    expect(JSON.stringify(response.body)).not.toContain('anna@example.com');
  });

  it('returns 404 with the not-found message for an unknown reference', async () => {
    const response = await request(app).get('/api/bookings/KB-AAAAAA');
    expect(response.status).toBe(404);
    expect(response.body).toEqual({ message: NOT_FOUND_MESSAGE });
  });

  it('returns 404 once the booking has been cancelled', async () => {
    const created = await request(app).post(`/api/tastings/${RIESLING}/bookings`).send(validBooking);
    await store.cancelBooking(created.body.reference);
    const response = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(response.status).toBe(404);
    expect(response.body).toEqual({ message: NOT_FOUND_MESSAGE });
  });
});

describe('routing', () => {
  it('returns JSON 404 for an unknown API path', async () => {
    const response = await request(app).get('/api/no-such-route');
    expect(response.status).toBe(404);
    expect(response.headers['content-type']).toMatch(/application\/json/);
  });

  it('serves the app shell for a deep link so the page renders on reload', async () => {
    const response = await request(app).get('/bookings/KB-ABC234');
    expect(response.status).toBe(200);
    expect(response.text).toContain('APP SHELL');
  });

  it('answers 404 for a missing built asset instead of the app shell', async () => {
    const response = await request(app).get('/assets/missing-old-hash.js');
    expect(response.status).toBe(404);
    expect(response.text).not.toContain('APP SHELL');
  });

  it('serves built static assets', async () => {
    const response = await request(app).get('/assets/app.js');
    expect(response.status).toBe(200);
    expect(response.text).toContain('console.log');
  });
});

describe('security headers', () => {
  it('sends the standard hardening headers on every response', async () => {
    const response = await request(app).get('/api/tastings');
    expect(response.headers['x-content-type-options']).toBe('nosniff');
    expect(response.headers['x-frame-options']).toBeDefined();
    expect(response.headers['content-security-policy']).toContain("default-src 'self'");
    expect(response.headers['x-powered-by']).toBeUndefined();
  });
});
