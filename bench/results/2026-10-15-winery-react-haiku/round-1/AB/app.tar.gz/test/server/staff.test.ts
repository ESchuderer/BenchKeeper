import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../server/app.js';
import { BookingStore } from '../../server/store.js';

const PASSWORD = 'vine-2026';
const RIESLING = 'riesling-evening';

let store: BookingStore;
let app: ReturnType<typeof createApp>;

beforeEach(async () => {
  store = await BookingStore.open({});
  app = createApp({ store, staffPassword: PASSWORD });
});

async function signedInAgent() {
  const agent = request.agent(app);
  const response = await agent.post('/api/staff/login').send({ password: PASSWORD });
  expect(response.status).toBe(200);
  return agent;
}

describe('POST /api/staff/login', () => {
  it('signs in with the correct password and sets a session', async () => {
    const agent = request.agent(app);
    const response = await agent.post('/api/staff/login').send({ password: PASSWORD });
    expect(response.status).toBe(200);
    expect(response.headers['set-cookie']?.[0]).toMatch(/HttpOnly/i);
    const session = await agent.get('/api/staff/session');
    expect(session.body).toEqual({ signedIn: true });
  });

  it('refuses a wrong password with the error next to the password field', async () => {
    const agent = request.agent(app);
    const response = await agent.post('/api/staff/login').send({ password: 'vine-2027' });
    expect(response.status).toBe(401);
    expect(response.body).toEqual({ errors: { password: 'Incorrect password' } });
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: false });
  });

  it('rejects an empty password with "Enter the staff password"', async () => {
    const response = await request(app).post('/api/staff/login').send({ password: '' });
    expect(response.status).toBe(400);
    expect(response.body).toEqual({ errors: { password: 'Enter the staff password' } });
  });

  it('reports that sign-in is not configured when STAFF_PASSWORD is not set', async () => {
    const unconfigured = createApp({ store, staffPassword: undefined });
    const response = await request(unconfigured).post('/api/staff/login').send({ password: 'anything' });
    expect(response.status).toBe(503);
    expect(response.body).toEqual({ message: 'Staff sign-in is not configured' });
  });

  it('does not count an empty submission as a failed sign-in attempt', async () => {
    for (let i = 0; i < 10; i++) {
      expect((await request(app).post('/api/staff/login').send({ password: '' })).status).toBe(400);
    }
    const agent = request.agent(app);
    expect((await agent.post('/api/staff/login').send({ password: PASSWORD })).status).toBe(200);
  });

  it('refuses sign-in for the rest of the window after 10 failed attempts', async () => {
    for (let i = 0; i < 10; i++) {
      const failed = await request(app).post('/api/staff/login').send({ password: 'wrong' });
      expect(failed.status).toBe(401);
    }
    const agent = request.agent(app);
    const blocked = await agent.post('/api/staff/login').send({ password: PASSWORD });
    expect(blocked.status).toBe(429);
    expect(blocked.body).toEqual({ message: 'Too many attempts. Try again later.' });
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: false });
  });
});

describe('GET /api/staff/bookings', () => {
  it('refuses without a session and returns no booking data', async () => {
    await store.createBooking({ tastingId: RIESLING, name: 'Anna Berger', email: 'anna@example.com', guests: 2 });
    const response = await request(app).get('/api/staff/bookings');
    expect(response.status).toBe(401);
    expect(response.body.groups).toBeUndefined();
    expect(JSON.stringify(response.body)).not.toContain('Anna Berger');
  });

  it('returns every booking grouped by tasting, with name, email, guests and reference', async () => {
    const anna = await store.createBooking({ tastingId: RIESLING, name: 'Anna Berger', email: 'anna@example.com', guests: 2 });
    const lukas = await store.createBooking({ tastingId: RIESLING, name: 'Lukas Weiss', email: 'lukas@example.com', guests: 1 });
    const mia = await store.createBooking({ tastingId: 'winter-tasting', name: 'Mia Klein', email: 'mia@example.com', guests: 4 });
    if (!anna.ok || !lukas.ok || !mia.ok) throw new Error('bookings should be accepted');

    const agent = await signedInAgent();
    const response = await agent.get('/api/staff/bookings');
    expect(response.status).toBe(200);
    expect(response.body.groups.map((g: { tasting: { id: string } }) => g.tasting.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(response.body.groups[0].bookings).toEqual([
      { reference: anna.booking.reference, name: 'Anna Berger', email: 'anna@example.com', guests: 2 },
      { reference: lukas.booking.reference, name: 'Lukas Weiss', email: 'lukas@example.com', guests: 1 },
    ]);
    expect(response.body.groups[1].bookings).toEqual([]);
    expect(response.body.groups[2].bookings).toEqual([
      { reference: mia.booking.reference, name: 'Mia Klein', email: 'mia@example.com', guests: 4 },
    ]);
  });
});

describe('DELETE /api/staff/bookings/:reference', () => {
  it('refuses without a session and keeps the booking', async () => {
    const created = await store.createBooking({ tastingId: RIESLING, name: 'Anna Berger', email: 'anna@example.com', guests: 2 });
    if (!created.ok) throw new Error('booking should be accepted');
    const response = await request(app).delete(`/api/staff/bookings/${created.booking.reference}`);
    expect(response.status).toBe(401);
    expect(store.getBooking(created.booking.reference)).toBeDefined();
  });

  it('cancels the booking with 204 and frees its seats', async () => {
    const created = await store.createBooking({ tastingId: RIESLING, name: 'Anna Berger', email: 'anna@example.com', guests: 2 });
    if (!created.ok) throw new Error('booking should be accepted');
    expect(store.seatsLeft(RIESLING)).toBe(10);

    const agent = await signedInAgent();
    const response = await agent.delete(`/api/staff/bookings/${created.booking.reference}`);
    expect(response.status).toBe(204);
    expect(store.getBooking(created.booking.reference)).toBeUndefined();

    const tastings = await request(app).get('/api/tastings');
    expect(tastings.body.find((t: { id: string }) => t.id === RIESLING).seatsLeft).toBe(12);
  });

  it('returns 404 for a reference that does not exist', async () => {
    const agent = await signedInAgent();
    const response = await agent.delete('/api/staff/bookings/KB-AAAAAA');
    expect(response.status).toBe(404);
  });
});

describe('session revocation', () => {
  // The cookie a browser would hold after signing in.
  async function sessionCookie(target = app) {
    const response = await request(target).post('/api/staff/login').send({ password: PASSWORD });
    const cookies = response.headers['set-cookie'] as unknown as string[];
    return cookies.map((cookie) => cookie.split(';')[0]).join('; ');
  }

  it('refuses a copied session cookie after sign-out', async () => {
    const cookie = await sessionCookie();
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(200);

    await request(app).post('/api/staff/logout').set('Cookie', cookie).expect(204);
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });

  it('refuses a session once the 8 hour window has passed, even if the cookie is still valid', async () => {
    let now = Date.parse('2026-11-01T09:00:00Z');
    const timed = createApp({ store, staffPassword: PASSWORD, now: () => now });
    const cookie = await sessionCookie(timed);
    expect((await request(timed).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(200);

    now += 8 * 60 * 60 * 1000 + 1000;
    expect((await request(timed).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
    expect((await request(timed).get('/api/staff/session').set('Cookie', cookie)).body).toEqual({ signedIn: false });
  });
});

describe('POST /api/staff/logout', () => {
  it('ends the session so booking data is no longer available', async () => {
    const agent = await signedInAgent();
    expect((await agent.get('/api/staff/bookings')).status).toBe(200);

    const response = await agent.post('/api/staff/logout');
    expect(response.status).toBe(204);
    expect((await agent.get('/api/staff/bookings')).status).toBe(401);
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: false });
  });
});
