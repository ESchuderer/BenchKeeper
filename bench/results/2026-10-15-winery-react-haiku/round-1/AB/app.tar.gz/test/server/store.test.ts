import { mkdtempSync, readFileSync, rmSync, statSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { BookingStore, writeBookingsFile } from '../../server/store.js';

const REFERENCE_PATTERN = /^KB-[A-Z2-9]{6}$/;

let dir: string;
let dataFile: string;

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), 'kieselbrunnen-store-'));
  dataFile = join(dir, 'bookings.json');
});

afterEach(() => {
  rmSync(dir, { recursive: true, force: true });
});

const RIESLING = 'riesling-evening';
const RED = 'red-wine-cellar-tour';
const WINTER = 'winter-tasting';

function booking(tastingId: string, guests: number, name = 'Anna Berger') {
  return { tastingId, name, email: 'anna@example.com', guests };
}

function seatsByTasting(store: BookingStore) {
  return Object.fromEntries(store.listTastings().map((t) => [t.id, t.seatsLeft]));
}

describe('seats left', () => {
  it('shows the full seats for each tasting in a fresh store', async () => {
    const store = await BookingStore.open({});
    expect(seatsByTasting(store)).toEqual({ [RIESLING]: 12, [RED]: 8, [WINTER]: 10 });
  });

  it('subtracts the guests of an accepted booking', async () => {
    const store = await BookingStore.open({});
    await store.createBooking(booking(RIESLING, 3));
    expect(store.seatsLeft(RIESLING)).toBe(9);
  });

  it('gives the seats back when a booking is cancelled', async () => {
    const store = await BookingStore.open({});
    const result = await store.createBooking(booking(RIESLING, 3));
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    await store.cancelBooking(result.booking.reference);
    expect(store.seatsLeft(RIESLING)).toBe(12);
  });
});

describe('createBooking seat limit', () => {
  it('accepts a booking that takes exactly the seats left', async () => {
    const store = await BookingStore.open({});
    await store.createBooking(booking(RED, 5));
    const result = await store.createBooking(booking(RED, 3));
    expect(result.ok).toBe(true);
    expect(store.seatsLeft(RED)).toBe(0);
  });

  it('rejects more guests than seats left and leaves the seats unchanged', async () => {
    const store = await BookingStore.open({});
    await store.createBooking(booking(RED, 5));
    const result = await store.createBooking(booking(RED, 4));
    expect(result).toEqual({ ok: false, reason: 'not-enough-seats', seatsLeft: 3 });
    expect(store.seatsLeft(RED)).toBe(3);
  });

  it('reports the single seat left when only one is free', async () => {
    const store = await BookingStore.open({});
    await store.createBooking(booking(RED, 7));
    const result = await store.createBooking(booking(RED, 2));
    expect(result).toEqual({ ok: false, reason: 'not-enough-seats', seatsLeft: 1 });
  });

  it('rejects a booking for a fully booked tasting', async () => {
    const store = await BookingStore.open({});
    await store.createBooking(booking(RIESLING, 8));
    await store.createBooking(booking(RIESLING, 4));
    expect(store.seatsLeft(RIESLING)).toBe(0);
    const result = await store.createBooking(booking(RIESLING, 1));
    expect(result).toEqual({ ok: false, reason: 'fully-booked' });
  });

  it('lets only one of two competing bookings through when they race for the last seats', async () => {
    const store = await BookingStore.open({});
    await store.createBooking(booking(WINTER, 8));
    const [first, second] = await Promise.all([
      store.createBooking(booking(WINTER, 2, 'Guest A')),
      store.createBooking(booking(WINTER, 2, 'Guest B')),
    ]);
    const outcomes = [first.ok, second.ok].sort();
    expect(outcomes).toEqual([false, true]);
    expect(store.seatsLeft(WINTER)).toBe(0);
    expect(store.listBookingsByTasting().find((g) => g.tasting.id === WINTER)?.bookings).toHaveLength(2);
  });

  it('never reports negative seats when the catalogue shrinks below the booked guests', async () => {
    const dataFile = join(dir, 'bookings.json');
    const before = await BookingStore.open({ dataFile });
    await before.createBooking(booking(WINTER, 8));

    const smaller = [{ id: WINTER, title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceEuro: 28, seats: 6 }];
    const store = await BookingStore.open({ dataFile, tastings: smaller });
    expect(store.seatsLeft(WINTER)).toBe(0);
    expect(await store.createBooking(booking(WINTER, 1))).toEqual({ ok: false, reason: 'fully-booked' });
  });

  it('rejects an unknown tasting', async () => {
    const store = await BookingStore.open({});
    expect(await store.createBooking(booking('no-such-tasting', 1))).toEqual({
      ok: false,
      reason: 'unknown-tasting',
    });
  });
});

describe('booking references', () => {
  it('match KB- followed by six characters from A to Z and 2 to 9, and are unique', async () => {
    const store = await BookingStore.open({});
    const references = new Set<string>();
    // 12 + 8 + 10 seats, one guest per booking, so every seat gets its own reference.
    for (const [tastingId, seats] of [[RIESLING, 12], [RED, 8], [WINTER, 10]] as const) {
      for (let i = 0; i < seats; i++) {
        const result = await store.createBooking(booking(tastingId, 1));
        expect(result.ok).toBe(true);
        if (result.ok) references.add(result.booking.reference);
      }
    }
    expect(references.size).toBe(30);
    for (const reference of references) expect(reference).toMatch(REFERENCE_PATTERN);
  });
});

describe('cancelBooking', () => {
  it('removes the booking so its reference no longer resolves', async () => {
    const store = await BookingStore.open({});
    const result = await store.createBooking(booking(RIESLING, 2));
    if (!result.ok) throw new Error('booking should be accepted');
    expect(await store.cancelBooking(result.booking.reference)).toBe(true);
    expect(store.getBooking(result.booking.reference)).toBeUndefined();
  });

  it('returns false for an unknown reference', async () => {
    const store = await BookingStore.open({});
    expect(await store.cancelBooking('KB-AAAAAA')).toBe(false);
  });
});

describe('listBookingsByTasting', () => {
  it('groups bookings under their tasting in booking order and includes tastings with no bookings', async () => {
    const store = await BookingStore.open({});
    await store.createBooking(booking(RIESLING, 2, 'Anna Berger'));
    await store.createBooking(booking(RIESLING, 1, 'Lukas Weiss'));
    await store.createBooking(booking(WINTER, 4, 'Mia Klein'));

    const groups = store.listBookingsByTasting();
    expect(groups.map((g) => g.tasting.id)).toEqual([RIESLING, RED, WINTER]);
    expect(groups[0].bookings.map((b) => b.name)).toEqual(['Anna Berger', 'Lukas Weiss']);
    expect(groups[1].bookings).toEqual([]);
    expect(groups[2].bookings).toEqual([expect.objectContaining({ name: 'Mia Klein', guests: 4 })]);
  });
});

describe('persistence', () => {
  it('starts empty when no bookings file exists and does not create one until a change is made', async () => {
    const store = await BookingStore.open({ dataFile });
    expect(seatsByTasting(store)[RIESLING]).toBe(12);
    expect(existsSync(dataFile)).toBe(false);
  });

  it('keeps bookings and cancellations across a restart', async () => {
    const first = await BookingStore.open({ dataFile });
    const kept = await first.createBooking(booking(RIESLING, 2, 'Anna Berger'));
    const removed = await first.createBooking(booking(WINTER, 3, 'Mia Klein'));
    if (!kept.ok || !removed.ok) throw new Error('bookings should be accepted');
    await first.cancelBooking(removed.booking.reference);

    const second = await BookingStore.open({ dataFile });
    expect(second.seatsLeft(RIESLING)).toBe(10);
    expect(second.seatsLeft(WINTER)).toBe(10);
    expect(second.getBooking(kept.booking.reference)?.name).toBe('Anna Berger');
    expect(second.getBooking(removed.booking.reference)).toBeUndefined();
  });

  it('refuses to start on an unreadable file and leaves the file unchanged', async () => {
    const corrupt = '{ "bookings": [ not json';
    writeFileSync(dataFile, corrupt);
    await expect(BookingStore.open({ dataFile })).rejects.toThrow(dataFile);
    expect(readFileSync(dataFile, 'utf8')).toBe(corrupt);
  });

  it('makes a booking requested during a failed cancellation wait, so seats are not double-booked', async () => {
    // The first write fails, as a full disk would. Later writes succeed.
    let failuresLeft = 0;
    const write = async (file: string, contents: string) => {
      if (failuresLeft > 0) {
        failuresLeft--;
        throw new Error('disk full');
      }
      await writeBookingsFile(file, contents);
    };
    const store = await BookingStore.open({ dataFile, write });
    const created = await store.createBooking(booking(RIESLING, 12));
    if (!created.ok) throw new Error('booking should be accepted');

    failuresLeft = 1;
    const [cancelled, next] = await Promise.allSettled([
      store.cancelBooking(created.booking.reference),
      store.createBooking(booking(RIESLING, 12, 'Guest B')),
    ]);

    expect(cancelled.status).toBe('rejected');
    expect(store.getBooking(created.booking.reference)).toBeDefined();
    expect(store.seatsLeft(RIESLING)).toBe(0);
    expect(next.status === 'fulfilled' && next.value.ok).toBe(false);
  });

  it('rolls back a booking when it cannot be saved, so no seats are taken and no confirmation is issued', async () => {
    const store = await BookingStore.open({ dataFile: join(dir, 'data', 'bookings.json') });
    // Turn the data directory into a plain file so the next save fails.
    rmSync(join(dir, 'data'), { recursive: true, force: true });
    writeFileSync(join(dir, 'data'), 'blocked');

    await expect(store.createBooking(booking(RIESLING, 2))).rejects.toThrow();
    expect(store.seatsLeft(RIESLING)).toBe(12);
    expect(store.listBookingsByTasting()[0].bookings).toEqual([]);
  });
});

describe('bookings file privacy', () => {
  it.skipIf(process.platform === 'win32')('saves the bookings file readable only by its owner', async () => {
    const store = await BookingStore.open({ dataFile });
    await store.createBooking(booking(RIESLING, 2));
    expect(statSync(dataFile).mode & 0o777).toBe(0o600);
  });
});
