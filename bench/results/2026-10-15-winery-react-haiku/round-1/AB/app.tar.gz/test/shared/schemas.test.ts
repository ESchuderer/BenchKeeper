import { describe, expect, it } from 'vitest';
import { bookingInputSchema, staffLoginSchema } from '../../shared/schemas.js';

// Returns the first error message for each field that failed validation.
function fieldErrors(input: unknown, schema: typeof bookingInputSchema | typeof staffLoginSchema) {
  const result = schema.safeParse(input);
  if (result.success) return {};
  const errors: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const field = String(issue.path[0] ?? '');
    errors[field] ??= issue.message;
  }
  return errors;
}

const validBooking = { name: 'Anna Berger', email: 'anna@example.com', guests: 2 };

describe('bookingInputSchema', () => {
  it('accepts a valid booking and trims the name', () => {
    const result = bookingInputSchema.safeParse({ ...validBooking, name: '  Anna Berger  ' });
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.name).toBe('Anna Berger');
  });

  it('rejects a blank name with "Enter your name"', () => {
    expect(fieldErrors({ ...validBooking, name: '   ' }, bookingInputSchema)).toEqual({ name: 'Enter your name' });
    expect(fieldErrors({ ...validBooking, name: undefined }, bookingInputSchema)).toEqual({ name: 'Enter your name' });
  });

  it('allows a name of exactly 100 characters and rejects 101', () => {
    expect(bookingInputSchema.safeParse({ ...validBooking, name: 'a'.repeat(100) }).success).toBe(true);
    expect(fieldErrors({ ...validBooking, name: 'a'.repeat(101) }, bookingInputSchema)).toEqual({
      name: 'Name must be at most 100 characters',
    });
  });

  it('rejects an empty email with "Enter your email address"', () => {
    expect(fieldErrors({ ...validBooking, email: '' }, bookingInputSchema)).toEqual({
      email: 'Enter your email address',
    });
  });

  it('rejects an invalid email with "Enter a valid email address"', () => {
    expect(fieldErrors({ ...validBooking, email: 'guest@example' }, bookingInputSchema)).toEqual({
      email: 'Enter a valid email address',
    });
  });

  it.each([0, 9, -1, 'two', 2.5, '', true, false, [2]])('rejects guests value %j with the 1 to 8 message', (guests) => {
    expect(fieldErrors({ ...validBooking, guests }, bookingInputSchema)).toEqual({
      guests: 'Choose between 1 and 8 guests',
    });
  });

  it.each([1, 8, '2', '8'])('accepts guests value %j', (guests) => {
    expect(bookingInputSchema.safeParse({ ...validBooking, guests }).success).toBe(true);
  });

  it('reports every invalid field in one pass', () => {
    expect(fieldErrors({ name: '', email: 'nope', guests: 0 }, bookingInputSchema)).toEqual({
      name: 'Enter your name',
      email: 'Enter a valid email address',
      guests: 'Choose between 1 and 8 guests',
    });
  });
});

describe('staffLoginSchema', () => {
  it('rejects an empty password with "Enter the staff password"', () => {
    expect(fieldErrors({ password: '' }, staffLoginSchema)).toEqual({ password: 'Enter the staff password' });
  });

  it('accepts any non-empty password without trimming it', () => {
    const result = staffLoginSchema.safeParse({ password: ' vine-2026 ' });
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.password).toBe(' vine-2026 ');
  });
});
