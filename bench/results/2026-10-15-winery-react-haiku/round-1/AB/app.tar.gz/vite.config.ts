import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    outDir: 'dist/client',
    emptyOutDir: true,
  },
  server: {
    // In development the Vite dev server forwards API calls to the Node server (npm run dev:server).
    proxy: {
      '/api': `http://localhost:${process.env.PORT ?? 3000}`,
    },
  },
  test: {
    globals: true,
    include: ['test/**/*.test.{ts,tsx}'],
    environment: 'node',
  },
});
