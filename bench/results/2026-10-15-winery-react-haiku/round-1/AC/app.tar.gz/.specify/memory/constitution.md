<!--
Sync Impact Report
- Version change: (template) → 1.0.0
- Modified principles: none (initial ratification; template placeholders replaced)
- Added sections: Technology & Security Constraints, Development Workflow & Quality Gates
- Removed sections: none (template placeholder sections SECTION_2/SECTION_3 renamed to the above)
- Follow-up TODOs: none
-->

# Weingut Kieselbrunnen Tastings Constitution

## Core Principles

### I. Seats Are Never Oversold

The number of seats a tasting can sell MUST be enforced on the server, inside the same
synchronous step that records the booking. A booking MUST be rejected when its guest count is
greater than the seats left at that moment. Seats left MUST be derived from the tasting's
capacity minus the guests of all active (not cancelled) bookings. Cancelling a booking MUST
free its seats immediately. Client-side checks are a convenience only and MUST NOT be relied on.

**Why:** Overbooking a tasting is a direct, customer-visible failure that the winery cannot
fix after the fact.

### II. Test-First (NON-NEGOTIABLE)

For every behavior change, a failing test MUST be written before the implementation that makes
it pass. The red-green-refactor order MUST be observed and the failing run SHOULD be seen before
the implementation exists. Bug fixes MUST start with a regression test that reproduces the bug.

**Why:** The booking rules (seat limits, input validation, authentication) are the highest-risk
parts of the app, and they are easy to break silently.

### III. Validate at the Boundary

Every request body and query parameter MUST be validated on the server against a schema before
it reaches booking or staff logic. Validation failures MUST return field-specific messages that
the interface can show next to the field concerned. Schemas SHOULD be shared between client and
server so that the rules cannot drift apart.

**Why:** Guests and staff will send unexpected input; the server must stay correct even when the
client is bypassed.

### IV. Established Libraries Over Homegrown Replacements

Infrastructure concerns — HTTP server, routing, forms, validation, styling, testing, and
build — MUST use established, actively maintained libraries. Hand-written replacements for
these concerns MUST NOT be added. Dependencies MUST be kept to what the features need.

**Why:** A small winery's site needs to stay maintainable by people who did not write it.

### V. Secrets and Credentials Stay Out of Code and Logs

The staff password MUST come only from the `STAFF_PASSWORD` environment variable. It MUST NOT
be committed, hard-coded, returned by any API, or written to logs. Password comparison MUST be
constant-time. Staff session tokens MUST be unguessable and sent as `HttpOnly` cookies.

**Why:** The staff area exposes guest names and email addresses (personal data).

## Technology & Security Constraints

- Runtime: Node.js 22. The app MUST run with `npm install`, `npm run build`, and `npm start`,
  with the HTTP port taken from `PORT` (default 3000).
- Interface: React, written in TypeScript.
- No external services are used at runtime. Booking data is kept in memory or in a local file.
- Guest-facing and staff-facing pages MUST be usable on phone-sized screens.
- The interface language is English.

## Development Workflow & Quality Gates

- Work follows the spec-kit cycle: specification → plan → tasks → implementation, with
  Principle II applied inside the implementation step.
- A change is not complete until the test suite, the type check and the production build all pass.
- Every user story MUST have at least one automated test covering its acceptance scenarios.
- Reviews MUST check compliance with Principles I–V before merge.

## Governance

This constitution supersedes other practices in this repository. Amendments require a written
change to this file, a description of the reason for the change, and a plan for any existing code
that no longer complies.

Versioning follows semantic versioning:
- MAJOR: a principle is removed or its meaning is reversed.
- MINOR: a principle or section is added, or existing guidance is materially expanded.
- PATCH: wording or clarification changes that do not alter obligations.

Every plan and review MUST state whether it complies with the Core Principles. Any deviation MUST
be recorded in the plan's Complexity Tracking table with a justification.

**Version**: 1.0.0 | **Ratified**: 2026-10-14 | **Last Amended**: 2026-10-14
