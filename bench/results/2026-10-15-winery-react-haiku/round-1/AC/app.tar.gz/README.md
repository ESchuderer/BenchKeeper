# Weingut Kieselbrunnen · Wine Tastings

Online booking for the winery's tastings. Guests see the upcoming tastings with the seats left, book
1 to 8 guests, and get a booking reference. Staff sign in with a shared password to see all bookings
by tasting and to cancel them.

The specification, plan and task list are in [`specs/001-tasting-bookings/`](specs/001-tasting-bookings/).

## Requirements

- Node.js 22
- For the end-to-end tests only: Chromium and its system libraries (see [End-to-end tests](#end-to-end-tests))

## Run it

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' PORT=3000 npm start
```

Then open http://localhost:3000. Staff sign in at http://localhost:3000/staff.

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | Port the server listens on |
| `STAFF_PASSWORD` | none | Password for `/staff`. Without it, staff sign-in is refused and a warning is logged at startup. |
| `DATA_FILE` | `data/bookings.json` | JSON file holding the bookings. Created on the first booking. |

The app starts with no bookings. Bookings survive restarts because they are written to `DATA_FILE`.
Staff sessions are kept in memory and last 8 hours or until the app restarts.

### Development

Run the API and the React dev server in two terminals:

```sh
npm run dev:server   # API on PORT (default 3000)
npm run dev:client   # Vite dev server, proxies /api to port 3000
```

## Scripts

| Script | What it does |
|---|---|
| `npm run build` | Builds the React app to `dist/client` and compiles the server to `dist/` |
| `npm start` | Runs the built server (`node dist/server/index.js`) |
| `npm run typecheck` | TypeScript checks for the client, tests and server |
| `npm test` | Unit, API and component tests (Vitest) |
| `npm run test:e2e` | Browser tests against the built app (Playwright) |

## Project layout

```text
shared/     Code used by both sides: tasting catalogue, validation schemas, response types
server/     Express app: JSON API, booking rules, booking file store, staff sign-in
src/        React app (React Router, react-hook-form, Tailwind CSS)
tests/      server/ (Vitest + Supertest), client/ (Testing Library), e2e/ (Playwright)
specs/      Specification, plan, research, data model, API contract, quickstart, tasks
```

The API is described in [`specs/001-tasting-bookings/contracts/api.md`](specs/001-tasting-bookings/contracts/api.md).

## Operating notes

- **One server process.** Seat safety relies on the seat check and the save happening in one step
  inside a single Node.js process. Do not run two servers against the same `DATA_FILE`.
- **Staff access.** Staff sign in with one shared password. There is no lockout after failed attempts,
  so use a long password and keep the site behind the winery's usual HTTPS setup. The staff cookie is
  marked `Secure` when the request arrives over HTTPS.
- **Payment and email.** Nothing is charged online and no confirmation emails are sent. Guests pay at
  the winery.

## End-to-end tests

The Playwright tests start the built app on port 3100 with a fresh bookings file and run in Chromium.

```sh
npx playwright install chromium
npx playwright install-deps chromium   # needs root; installs the browser's system libraries
npm run test:e2e
```

Without root access, the browser's system libraries and a font package must already be present on
the machine (`install-deps` is what normally provides them).
