import { defineConfig, devices } from "@playwright/test";

const PORT = 3100;

export default defineConfig({
  testDir: "tests/e2e",
  use: {
    baseURL: `http://localhost:${PORT}`,
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  webServer: {
    // A fresh bookings file for every run, so the seat counts start from the catalogue values.
    command: "rm -f test-results/e2e-bookings.json && npm run build && npm start",
    url: `http://localhost:${PORT}/api/tastings`,
    reuseExistingServer: false,
    timeout: 180_000,
    env: {
      PORT: String(PORT),
      STAFF_PASSWORD: "e2e-staff-password",
      DATA_FILE: "test-results/e2e-bookings.json",
    },
  },
});
