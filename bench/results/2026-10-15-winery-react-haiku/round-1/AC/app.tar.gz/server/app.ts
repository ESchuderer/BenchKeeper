import { existsSync } from "node:fs";
import { join } from "node:path";
import cookieParser from "cookie-parser";
import express, { type NextFunction, type Request, type Response } from "express";
import type { BookingService } from "./booking-service.js";
import { bookingsRouter } from "./routes/bookings.js";
import { staffRouter } from "./routes/staff.js";
import { tastingsRouter } from "./routes/tastings.js";
import type { StaffAuth } from "./staff-auth.js";

export interface AppOptions {
  bookingService: BookingService;
  staffAuth: StaffAuth;
  /** Folder with the built single-page app (index.html and assets). */
  clientDir: string;
}

export function createApp({ bookingService, staffAuth, clientDir }: AppOptions) {
  const app = express();
  app.disable("x-powered-by");
  app.use(cookieParser());

  // The API only accepts JSON. Browsers cannot send a JSON body from a cross-site form,
  // so this also blocks form-based cross-site requests.
  app.use("/api", (req: Request, res: Response, next: NextFunction) => {
    const hasBody = ["POST", "PUT", "PATCH"].includes(req.method);
    if (hasBody && !req.is("application/json")) {
      res.status(415).json({ error: "unsupported_media_type", message: "Send the request body as JSON." });
      return;
    }
    next();
  });
  app.use("/api", express.json({ limit: "16kb" }));

  // Route modules are mounted here, one per user-story phase.
  app.use("/api", tastingsRouter(bookingService));
  app.use("/api", bookingsRouter(bookingService));
  app.use("/api", staffRouter(bookingService, staffAuth));

  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "not_found" });
  });

  // Built client files, then the single-page app for every other GET (client-side routes).
  app.use(express.static(clientDir));
  app.use((req: Request, res: Response, next: NextFunction) => {
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    const indexPath = join(clientDir, "index.html");
    if (!existsSync(indexPath)) {
      res.status(404).type("text/plain").send("The website has not been built yet. Run npm run build.");
      return;
    }
    res.sendFile(indexPath);
  });

  // Error handler: JSON for every failure. Details go to the server log only, never to the response.
  app.use((error: Error & { type?: string; status?: number }, _req: Request, res: Response, _next: NextFunction) => {
    if (error.type === "entity.parse.failed") {
      res.status(400).json({ error: "invalid_json", message: "The request body is not valid JSON." });
      return;
    }
    // Body and URL problems caused by the client are answered with their 4xx status, not a 500.
    if (error.type === "charset.unsupported" || error.status === 415) {
      res.status(415).json({ error: "unsupported_media_type", message: "Send the request body as JSON." });
      return;
    }
    if (error.status === 400) {
      res.status(400).json({ error: "bad_request", message: "The request could not be understood." });
      return;
    }
    if (error.type === "entity.too.large") {
      res.status(413).json({ error: "payload_too_large", message: "The request is too large." });
      return;
    }
    console.error("Unhandled error:", error);
    res.status(500).json({ error: "internal_error", message: "Something went wrong. Please try again." });
  });

  return app;
}
