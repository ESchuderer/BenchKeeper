import { randomInt } from "node:crypto";
import type { BookingReceipt, Confirmation, StaffTastingGroup, TastingView } from "../shared/api-types.js";
import { TASTINGS, type Tasting } from "../shared/tastings.js";
import type { BookingStore } from "./booking-store.js";

export interface BookingServiceOptions {
  store: BookingStore;
  /** Current time in epoch milliseconds; injected so tests can move the clock. */
  now?: () => number;
  /** The tasting catalogue; defaults to the fixed catalogue for this release. */
  tastings?: readonly Tasting[];
}

export type BookingResult =
  | { ok: true; booking: BookingReceipt }
  | { ok: false; error: "tasting_not_found" }
  | { ok: false; error: "fully_booked" }
  | { ok: false; error: "insufficient_seats"; seatsLeft: number };

// Grows with each user story. Methods are added together with their tests.
export interface BookingService {
  listTastings(): TastingView[];
  getTasting(id: string): TastingView | undefined;
  book(request: { tastingId: string; name: string; email: string; guests: number }): BookingResult;
  getConfirmation(reference: string): Confirmation | undefined;
  listForStaff(): StaffTastingGroup[];
  cancel(reference: string): boolean;
}

// No look-alike characters (0/O, 1/I/L), so references can be read out over the phone.
const REFERENCE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

function newReference(): string {
  let reference = "KB-";
  for (let i = 0; i < 6; i++) {
    reference += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  }
  return reference;
}

export function createBookingService({
  store,
  now = Date.now,
  tastings = TASTINGS,
}: BookingServiceOptions): BookingService {
  // Guests booked on a tasting, counting only active bookings. Cancelled bookings are removed from the store.
  function guestsBooked(tastingId: string): number {
    return store
      .list()
      .filter((booking) => booking.tastingId === tastingId)
      .reduce((sum, booking) => sum + booking.guests, 0);
  }

  function view(tasting: Tasting): TastingView {
    const seatsLeft = Math.max(0, tasting.seats - guestsBooked(tasting.id));
    const started = Date.parse(tasting.startsAt) <= now();
    return {
      ...tasting,
      seatsLeft,
      status: seatsLeft === 0 || started ? "fully_booked" : "open",
    };
  }

  function findTasting(id: string): Tasting | undefined {
    return tastings.find((candidate) => candidate.id === id);
  }

  return {
    listTastings: () => tastings.map(view),

    getTasting: (id) => {
      const tasting = findTasting(id);
      return tasting ? view(tasting) : undefined;
    },

    // Checking the seats and adding the booking happen in one synchronous call. Node runs one
    // JavaScript thread, so no other request can change the seat count in between.
    book({ tastingId, name, email, guests }) {
      const tasting = findTasting(tastingId);
      if (!tasting) return { ok: false, error: "tasting_not_found" };

      const current = view(tasting);
      if (current.status === "fully_booked") return { ok: false, error: "fully_booked" };
      if (guests > current.seatsLeft) return { ok: false, error: "insufficient_seats", seatsLeft: current.seatsLeft };

      let reference = newReference();
      while (store.findByReference(reference)) reference = newReference();

      const createdAt = new Date(now()).toISOString();
      store.add({ reference, tastingId, name, email, guests, createdAt });

      return {
        ok: true,
        booking: {
          reference,
          tastingId,
          tastingTitle: tasting.title,
          startsAt: tasting.startsAt,
          guests,
          pricePerGuest: tasting.pricePerGuest,
          totalPrice: guests * tasting.pricePerGuest,
          name,
          email,
          createdAt,
        },
      };
    },

    listForStaff: () =>
      tastings.map((tasting) => ({
        tasting: view(tasting),
        bookings: store
          .list()
          .filter((booking) => booking.tastingId === tasting.id)
          .map(({ reference, name, email, guests, createdAt }) => ({ reference, name, email, guests, createdAt })),
      })),

    // Cancelling removes the booking, so its seats count as free again on the next read.
    cancel: (reference) => store.remove(reference),

    getConfirmation(reference) {
      const booking = store.findByReference(reference);
      const tasting = booking && findTasting(booking.tastingId);
      if (!booking || !tasting) return undefined;
      return {
        reference: booking.reference,
        tastingTitle: tasting.title,
        startsAt: tasting.startsAt,
        guests: booking.guests,
        pricePerGuest: tasting.pricePerGuest,
        totalPrice: booking.guests * tasting.pricePerGuest,
      };
    },
  };
}
