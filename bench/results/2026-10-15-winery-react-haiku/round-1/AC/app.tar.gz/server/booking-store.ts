import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import { dirname } from "node:path";

export interface StoredBooking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface BookingStore {
  list(): StoredBooking[];
  findByReference(reference: string): StoredBooking | undefined;
  add(booking: StoredBooking): void;
  remove(reference: string): boolean;
}

export interface BookingStoreOptions {
  /** When set, bookings are loaded from and saved to this JSON file. */
  filePath?: string;
}

const FILE_VERSION = 1;

function readBookingsFile(filePath: string): StoredBooking[] {
  if (!existsSync(filePath)) return [];
  let parsed: unknown;
  try {
    parsed = JSON.parse(readFileSync(filePath, "utf8"));
  } catch (error) {
    throw new Error(`Could not read bookings file ${filePath}: ${(error as Error).message}`);
  }
  const file = parsed as { version?: unknown; bookings?: unknown };
  if (file?.version !== FILE_VERSION || !Array.isArray(file.bookings)) {
    throw new Error(`Bookings file ${filePath} has an unexpected format.`);
  }
  return file.bookings as StoredBooking[];
}

export function createBookingStore({ filePath }: BookingStoreOptions = {}): BookingStore {
  const bookings = new Map<string, StoredBooking>();
  if (filePath) {
    for (const booking of readBookingsFile(filePath)) bookings.set(booking.reference, booking);
  }

  // Write to a temporary file and rename it over the target, so a crash never leaves a half-written file.
  function save() {
    if (!filePath) return;
    // Guest names and emails are personal data: the folder and file are private to the server's user.
    mkdirSync(dirname(filePath), { recursive: true, mode: 0o700 });
    const tempPath = `${filePath}.${randomBytes(6).toString("hex")}.tmp`;
    const content = { version: FILE_VERSION, bookings: [...bookings.values()] };
    writeFileSync(tempPath, `${JSON.stringify(content, null, 2)}\n`, { mode: 0o600 });
    renameSync(tempPath, filePath);
  }

  return {
    list: () => [...bookings.values()],
    findByReference: (reference) => bookings.get(reference),
    add(booking) {
      bookings.set(booking.reference, booking);
      try {
        save();
      } catch (error) {
        bookings.delete(booking.reference);
        throw error;
      }
    },
    remove(reference) {
      const existing = bookings.get(reference);
      if (!existing) return false;
      bookings.delete(reference);
      try {
        save();
      } catch (error) {
        bookings.set(reference, existing);
        throw error;
      }
      return true;
    },
  };
}
