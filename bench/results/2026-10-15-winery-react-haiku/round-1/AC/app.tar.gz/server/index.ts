import { resolve } from "node:path";
import { createApp } from "./app.js";
import { createBookingService } from "./booking-service.js";
import { createBookingStore } from "./booking-store.js";
import { createStaffAuth } from "./staff-auth.js";

const port = Number(process.env.PORT ?? 3000);
if (!Number.isInteger(port) || port < 0 || port > 65535) {
  throw new Error(`PORT must be a port number, got "${process.env.PORT}".`);
}

const staffAuth = createStaffAuth({ password: process.env.STAFF_PASSWORD });
if (!staffAuth.configured) {
  console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
}

const store = createBookingStore({ filePath: process.env.DATA_FILE ?? "data/bookings.json" });
const app = createApp({
  bookingService: createBookingService({ store }),
  staffAuth,
  clientDir: resolve("dist/client"),
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
});
