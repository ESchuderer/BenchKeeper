import { Router } from "express";
import type { ZodError } from "zod";
import { bookingRequestSchema } from "../../shared/booking-schema.js";
import type { BookingService } from "../booking-service.js";

const MESSAGE_VALIDATION = "Please correct the highlighted fields.";

// The first message for each field, keyed by field name, for the form to show beside that field.
function fieldErrorsFrom(error: ZodError): Record<string, string> {
  const fieldErrors: Record<string, string> = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0] ?? "form");
    fieldErrors[field] ??= issue.message;
  }
  return fieldErrors;
}

function seatsLeftMessage(seatsLeft: number): string {
  return seatsLeft === 1
    ? "Only 1 seat is left for this tasting."
    : `Only ${seatsLeft} seats are left for this tasting.`;
}

export function bookingsRouter(bookingService: BookingService): Router {
  const router = Router();

  router.post("/bookings", (req, res) => {
    const parsed = bookingRequestSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({
        error: "validation_failed",
        message: MESSAGE_VALIDATION,
        fieldErrors: fieldErrorsFrom(parsed.error),
      });
      return;
    }

    const result = bookingService.book(parsed.data);
    if (!result.ok) {
      if (result.error === "tasting_not_found") {
        res.status(404).json({ error: "tasting_not_found", message: "This tasting does not exist." });
      } else if (result.error === "fully_booked") {
        res.status(409).json({ error: "fully_booked", message: "This tasting is fully booked." });
      } else {
        const message = seatsLeftMessage(result.seatsLeft);
        res.status(409).json({
          error: "insufficient_seats",
          message,
          seatsLeft: result.seatsLeft,
          fieldErrors: { guests: message },
        });
      }
      return;
    }

    res.status(201).json(result.booking);
  });

  router.get("/bookings/:reference", (req, res) => {
    const confirmation = bookingService.getConfirmation(req.params.reference);
    if (!confirmation) {
      res.status(404).json({ error: "booking_not_found", message: "No booking matches this reference." });
      return;
    }
    res.json(confirmation);
  });

  return router;
}
