import { Router, type NextFunction, type Request, type RequestHandler, type Response } from "express";
import { staffSignInSchema } from "../../shared/booking-schema.js";
import type { BookingService } from "../booking-service.js";
import { STAFF_SESSION_MS, type StaffAuth } from "../staff-auth.js";

export const STAFF_COOKIE = "kb_staff";

export function staffRouter(bookingService: BookingService, staffAuth: StaffAuth): Router {
  const router = Router();

  const requireStaff: RequestHandler = (req: Request, res: Response, next: NextFunction) => {
    if (!staffAuth.verify(req.cookies?.[STAFF_COOKIE])) {
      res.status(401).json({ error: "staff_sign_in_required", message: "Sign in to see bookings." });
      return;
    }
    next();
  };

  router.post("/staff/session", (req, res) => {
    const parsed = staffSignInSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({
        error: "validation_failed",
        message: "Please correct the highlighted fields.",
        fieldErrors: { password: parsed.error.issues[0]?.message ?? "Enter the staff password." },
      });
      return;
    }

    const token = staffAuth.signIn(parsed.data.password);
    if (!token) {
      res.status(401).json({
        error: "invalid_password",
        message: "Incorrect password.",
        fieldErrors: { password: "Incorrect password." },
      });
      return;
    }

    res.cookie(STAFF_COOKIE, token, {
      httpOnly: true,
      sameSite: "strict",
      path: "/",
      maxAge: STAFF_SESSION_MS,
      secure: req.secure,
    });
    res.json({ signedIn: true });
  });

  router.get("/staff/bookings", requireStaff, (_req, res) => {
    res.json(bookingService.listForStaff());
  });

  router.delete("/staff/bookings/:reference", requireStaff, (req: Request<{ reference: string }>, res: Response) => {
    if (!bookingService.cancel(req.params.reference)) {
      res.status(404).json({ error: "booking_not_found", message: "No booking matches this reference." });
      return;
    }
    res.status(204).end();
  });

  return router;
}
