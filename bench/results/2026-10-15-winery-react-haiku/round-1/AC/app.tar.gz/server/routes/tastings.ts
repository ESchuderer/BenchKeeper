import { Router } from "express";
import type { BookingService } from "../booking-service.js";

export function tastingsRouter(bookingService: BookingService): Router {
  const router = Router();

  router.get("/tastings", (_req, res) => {
    res.json(bookingService.listTastings());
  });

  router.get("/tastings/:id", (req, res) => {
    const tasting = bookingService.getTasting(req.params.id);
    if (!tasting) {
      res.status(404).json({ error: "tasting_not_found", message: "This tasting does not exist." });
      return;
    }
    res.json(tasting);
  });

  return router;
}
