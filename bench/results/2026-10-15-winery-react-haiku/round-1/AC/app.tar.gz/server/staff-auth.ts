import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export const STAFF_SESSION_MS = 8 * 60 * 60 * 1000;

export interface StaffAuthOptions {
  /** The configured staff password; undefined or empty means staff sign-in is disabled. */
  password: string | undefined;
  now?: () => number;
}

export interface StaffAuth {
  readonly configured: boolean;
  /** Returns a session token for the right password, otherwise undefined. */
  signIn(password: string): string | undefined;
  verify(token: string | undefined): boolean;
}

// Hashing both sides first makes the comparison constant-length, so timingSafeEqual is safe to use.
function digest(value: string): Buffer {
  return createHash("sha256").update(value, "utf8").digest();
}

export function createStaffAuth({ password, now = Date.now }: StaffAuthOptions): StaffAuth {
  const expected = password ? digest(password) : undefined;
  const sessions = new Map<string, number>();

  function purgeExpired() {
    for (const [token, expiresAt] of sessions) {
      if (now() >= expiresAt) sessions.delete(token);
    }
  }

  return {
    configured: expected !== undefined,
    signIn(attempt) {
      if (!expected || !timingSafeEqual(digest(attempt), expected)) return undefined;
      purgeExpired();
      const token = randomBytes(32).toString("base64url");
      sessions.set(token, now() + STAFF_SESSION_MS);
      return token;
    },
    verify(token) {
      if (!token) return false;
      const expiresAt = sessions.get(token);
      if (expiresAt === undefined) return false;
      if (now() >= expiresAt) {
        sessions.delete(token);
        return false;
      }
      return true;
    },
  };
}
