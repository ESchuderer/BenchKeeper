// Response shapes shared by the API (server) and the React app (client). See specs/001-tasting-bookings/contracts/api.md.
import type { Tasting } from "./tastings.js";

export type TastingStatus = "open" | "fully_booked";

export interface TastingView extends Tasting {
  seatsLeft: number;
  status: TastingStatus;
}

export interface BookingReceipt {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  pricePerGuest: number;
  totalPrice: number;
  name: string;
  email: string;
  createdAt: string;
}

/** What a guest may see on the confirmation page: no name or email. */
export interface Confirmation {
  reference: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  pricePerGuest: number;
  totalPrice: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface StaffTastingGroup {
  tasting: TastingView;
  bookings: StaffBooking[];
}
