import { z } from "zod";

export const MAX_GUESTS = 8;

// Messages shown next to the field they concern. Shared by the server and the booking form.
export const MESSAGES = {
  tastingRequired: "Choose a tasting.",
  nameRequired: "Please enter your name.",
  nameTooLong: "Name must be at most 100 characters.",
  emailRequired: "Please enter your email address.",
  emailInvalid: "Please enter a valid email address, e.g. name@example.com.",
  emailTooLong: "Email must be at most 254 characters.",
  guests: `Guests must be a whole number from 1 to ${MAX_GUESTS}.`,
  staffPasswordRequired: "Enter the staff password.",
} as const;

// Guests are numbers, not strings: the client sends a number and the server rejects anything else.
export const bookingRequestSchema = z.object({
  tastingId: z.string({ error: MESSAGES.tastingRequired }).min(1, MESSAGES.tastingRequired),
  name: z
    .string({ error: MESSAGES.nameRequired })
    .trim()
    .min(1, MESSAGES.nameRequired)
    .max(100, MESSAGES.nameTooLong),
  email: z
    .string({ error: MESSAGES.emailRequired })
    .trim()
    .min(1, MESSAGES.emailRequired)
    .max(254, MESSAGES.emailTooLong)
    .pipe(z.email(MESSAGES.emailInvalid)),
  guests: z
    .number({ error: MESSAGES.guests })
    .int(MESSAGES.guests)
    .min(1, MESSAGES.guests)
    .max(MAX_GUESTS, MESSAGES.guests),
});

export type BookingRequest = z.infer<typeof bookingRequestSchema>;

export const staffSignInSchema = z.object({
  password: z.string({ error: MESSAGES.staffPasswordRequired }).min(1, MESSAGES.staffPasswordRequired),
});

export type StaffSignIn = z.infer<typeof staffSignInSchema>;
