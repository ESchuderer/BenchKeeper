# HTTP API Contract: Wine Tasting Bookings

**Base path**: `/api`. All bodies are JSON (`Content-Type: application/json`). Errors use one shape:

```json
{ "error": "<code>", "message": "<text for the user>", "fieldErrors": { "<field>": "<text>" } }
```

`fieldErrors` appears only for validation problems. Codes are listed per endpoint.

Money is whole euros. Dates are ISO 8601 with offset.

---

## GET /api/tastings

List all tastings with live seat counts.

**200 OK**

```json
[
  { "id": "riesling-evening", "title": "Riesling Evening", "startsAt": "2026-11-06T18:00:00+01:00",
    "pricePerGuest": 25, "seats": 12, "seatsLeft": 12, "status": "open" }
]
```

`status` is `"open"` or `"fully_booked"` (see data-model.md).

## GET /api/tastings/:id

**200 OK**: one tasting, same shape as above.
**404**: `{ "error": "tasting_not_found", "message": "This tasting does not exist." }`

## POST /api/bookings

Book seats for one tasting.

**Request**

```json
{ "tastingId": "riesling-evening", "name": "Anna Weber", "email": "anna@example.com", "guests": 2 }
```

**201 Created**: the booking, with the reference and totals for the confirmation.

```json
{ "reference": "KB-7KQ2M9", "tastingId": "riesling-evening", "tastingTitle": "Riesling Evening",
  "startsAt": "2026-11-06T18:00:00+01:00", "guests": 2, "pricePerGuest": 25, "totalPrice": 50,
  "name": "Anna Weber", "email": "anna@example.com", "createdAt": "2026-10-14T10:02:11.000Z" }
```

**400 Bad Request**: `{ "error": "validation_failed", "message": "Please correct the highlighted fields.", "fieldErrors": { "guests": "Guests must be a whole number from 1 to 8." } }`
Possible `fieldErrors` keys: `name`, `email`, `guests`. Each field reports at most one message.

**404 Not Found**: `{ "error": "tasting_not_found", ... }`

**409 Conflict**:
- `insufficient_seats`: guests exceed seats left. Adds `"seatsLeft": <n>` and `fieldErrors.guests` = "Only {n} seats are left for this tasting."
- `fully_booked`: seats left is 0 or the tasting has started. No seats are taken.

A rejected request never changes the number of seats left.

## GET /api/bookings/:reference

Confirmation lookup for a guest. Returns only what the confirmation page shows: no name or email.

**200 OK**

```json
{ "reference": "KB-7KQ2M9", "tastingTitle": "Riesling Evening", "startsAt": "2026-11-06T18:00:00+01:00",
  "guests": 2, "pricePerGuest": 25, "totalPrice": 50 }
```

**404 Not Found**: `{ "error": "booking_not_found", "message": "No booking matches this reference." }`
(Also returned for cancelled bookings.)

---

## POST /api/staff/session

Staff sign-in.

**Request**: `{ "password": "..." }`

**200 OK**: sets the cookie `kb_staff=<token>; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`
(`Secure` when the request is HTTPS). Body: `{ "signedIn": true }`.

**400 Bad Request**: `{ "error": "validation_failed", "fieldErrors": { "password": "Enter the staff password." } }`

**401 Unauthorized**: `{ "error": "invalid_password", "message": "Incorrect password.", "fieldErrors": { "password": "Incorrect password." } }`
Returned for a wrong password and when no staff password is configured.

## GET /api/staff/bookings

Every active booking, grouped by tasting. Requires a valid `kb_staff` cookie.

**200 OK**

```json
[
  { "tasting": { "id": "riesling-evening", "title": "Riesling Evening", "startsAt": "2026-11-06T18:00:00+01:00",
                 "pricePerGuest": 25, "seats": 12, "seatsLeft": 10 },
    "bookings": [ { "reference": "KB-7KQ2M9", "name": "Anna Weber", "email": "anna@example.com",
                    "guests": 2, "createdAt": "2026-10-14T10:02:11.000Z" } ] }
]
```

Every tasting is included, even with no bookings (`"bookings": []`). Order follows the catalogue.

**401 Unauthorized**: `{ "error": "staff_sign_in_required", "message": "Sign in to see bookings." }`

## DELETE /api/staff/bookings/:reference

Cancel a booking. The booking is removed and its seats are freed immediately. Requires a staff session.

**204 No Content**
**401 Unauthorized**: `{ "error": "staff_sign_in_required", ... }`
**404 Not Found**: `{ "error": "booking_not_found", ... }`

---

## Cross-cutting rules

- Any `/api/*` path not listed above returns **404** `{ "error": "not_found" }`.
- Unexpected failures return **500** `{ "error": "internal_error", "message": "Something went wrong. Please try again." }` and log the error on the server, never the password or the cookie.
- Requests with a body that is not JSON return **415** `{ "error": "unsupported_media_type" }`.
- A malformed URL parameter, or any other client-caused 400, returns **400** `{ "error": "bad_request", "message": "The request could not be understood." }`.
- Data files are created readable only by the server's user (mode 600; folder 700).
