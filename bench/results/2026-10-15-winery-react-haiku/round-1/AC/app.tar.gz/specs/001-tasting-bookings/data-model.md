# Data Model: Wine Tasting Bookings

**Feature**: [spec.md](./spec.md) | **Plan**: [plan.md](./plan.md) | **Date**: 2026-10-14

## Tasting (fixed catalogue, `shared/tastings.ts`)

Not stored. Defined in code and identical on server and client.

| Field | Type | Rule |
|---|---|---|
| `id` | string | URL slug, unique: `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting` |
| `title` | string | `Riesling Evening`, `Red Wine Cellar Tour`, `Winter Tasting` |
| `startsAt` | string | ISO 8601 with offset: `2026-11-06T18:00:00+01:00`, `2026-11-14T15:00:00+01:00`, `2026-12-05T17:00:00+01:00` |
| `pricePerGuest` | integer | Whole euros: 25, 32, 28 |
| `seats` | integer | Capacity: 12, 8, 10 |

**Derived (not stored)**:

- `seatsLeft` = `seats` − Σ `guests` of all active bookings for this tasting. Always ≥ 0.
- `status` = `fully_booked` when `seatsLeft` is 0 or `startsAt` is in the past; otherwise `open`.

## Booking (persisted)

| Field | Type | Rule |
|---|---|---|
| `reference` | string | Unique. Format `KB-` + 6 characters from `ABCDEFGHJKMNPQRSTUVWXYZ23456789`. Assigned by the server. |
| `tastingId` | string | Must match a `Tasting.id`. |
| `name` | string | Trimmed. 1–100 characters. Required. |
| `email` | string | Trimmed. 1–254 characters. Valid email syntax (Zod `email`). Required. |
| `guests` | integer | 1–8. Must be ≤ `seatsLeft` of the tasting when the booking is recorded. |
| `createdAt` | string | ISO 8601 UTC instant the booking was recorded. Set by the server. |

**Lifecycle**: `created` (by POST) → `removed` (by staff cancel). There is no separate cancelled state:
a cancelled booking is deleted, which frees its seats (FR-019). A booking is never edited.

**Uniqueness**: `reference` is unique across all bookings. Two bookings may share a name, email or tasting.

**Persistence file** (`DATA_FILE`, default `data/bookings.json`):

```json
{
  "version": 1,
  "bookings": [
    { "reference": "KB-7KQ2M9", "tastingId": "riesling-evening", "name": "Anna Weber",
      "email": "anna@example.com", "guests": 2, "createdAt": "2026-10-14T10:02:11.000Z" }
  ]
}
```

- A missing file means `{ "version": 1, "bookings": [] }`.
- An unreadable or malformed file stops startup with a clear error. The app must not silently discard data.

## Staff session (in memory only)

| Field | Type | Rule |
|---|---|---|
| `token` | string | 32 random bytes, base64url. Key of the in-memory map. |
| `expiresAt` | number | Epoch milliseconds. `createdAt + 8 h`. Expired entries are removed when checked. |

Sessions are not persisted, so a restart signs staff out.

## Validation rules (single source: `shared/booking-schema.ts`)

| Input | Rule | Error text shown next to the field |
|---|---|---|
| `name` | trimmed; 1–100 characters | "Please enter your name." / "Name must be at most 100 characters." |
| `email` | trimmed; 1–254 characters; valid email | "Please enter your email address." / "Email must be at most 254 characters." / "Please enter a valid email address, e.g. name@example.com." |
| `guests` | whole number 1–8 | "Guests must be a whole number from 1 to 8." |
| `guests` vs seats | ≤ seats left (server only) | "Only {n} seats are left for this tasting." or "This tasting is fully booked." |
| `password` | non-empty | "Enter the staff password." |

## State transitions

```text
Tasting open ──POST /api/bookings (guests ≤ seatsLeft)──► Booking recorded ─► seatsLeft ↓
Booking recorded ──DELETE /api/staff/bookings/:ref──► Booking removed ───────► seatsLeft ↑
Tasting open ──seatsLeft = 0, or startsAt passes──► fully_booked (no new bookings)
```
