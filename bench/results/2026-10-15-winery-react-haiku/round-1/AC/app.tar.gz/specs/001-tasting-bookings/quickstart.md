# Quickstart: Wine Tasting Bookings

**Feature**: [spec.md](./spec.md) | **Contract**: [contracts/api.md](./contracts/api.md)

Use this guide to run the app and check that each user story works as described in the spec.

## Prerequisites

- Node.js 22
- A staff password of your choice

## Setup and run

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' PORT=3000 npm start
```

Open http://localhost:3000. Without `STAFF_PASSWORD`, the server starts and logs a warning, and staff
sign-in is refused.

Optional: `DATA_FILE=/path/to/bookings.json` changes where bookings are stored (default
`data/bookings.json`, created on the first booking).

For development with hot reload, run `npm run dev:server` and `npm run dev:client` in two terminals.
The Vite dev server proxies `/api` to the server on port 3000.

## Test and check

```sh
npm run typecheck    # TypeScript for server, shared and client
npm test             # Vitest unit, API and component tests
npm run test:e2e     # Playwright flows (needs: npx playwright install chromium)
```

## Validation scenarios

Each scenario maps to a user story in the spec.

### 1. Tastings and seats left (Story 1)

1. Open http://localhost:3000.
2. Expect three cards: Riesling Evening ("Fri, 6 Nov 2026, 18:00", "EUR 25 per guest", "12 seats left"),
   Red Wine Cellar Tour ("Sat, 14 Nov 2026, 15:00", "EUR 32", "8 seats left"), Winter Tasting
   ("Sat, 5 Dec 2026, 17:00", "EUR 28", "10 seats left").
3. Check with curl:

   ```sh
   curl -s localhost:3000/api/tastings | jq '.[] | {id, seatsLeft, status}'
   ```

### 2. Booking and validation (Story 2)

1. Click "Book Riesling Evening". The form has Name, Email, Guests and a "Book" button.
2. Submit with empty fields: each field shows its own error; nothing is booked.
3. Enter Email `anna@example`, Guests `0`, then `9`, then `2.5`: each shows the matching error beside its field.
4. Enter Name "Anna Weber", Email "anna@example.com", Guests `2`, press "Book".
5. Expect the heading "Booking confirmed", "Riesling Evening", 2 guests, "EUR 50" and a reference `KB-…`.
6. Return to the start page: Riesling Evening shows "10 seats left".
7. Check the seat rule with the API (should return 409 with `seatsLeft`):

   ```sh
   curl -s -X POST localhost:3000/api/bookings -H 'Content-Type: application/json' \
     -d '{"tastingId":"red-wine-cellar-tour","name":"Ben","email":"ben@example.com","guests":9}'
   ```

   Expect 400 for guests 9 (out of range). For the 8-seat cellar tour, book 5 guests, then 4: the
   second request returns 409 `insufficient_seats` with `"seatsLeft": 3`.

### 3. Staff sign-in and bookings (Story 3)

1. Open http://localhost:3000/staff. Expect a "Password" field and "Sign in" button.
2. Enter a wrong password: expect "Incorrect password." beside the field.
3. Enter the `STAFF_PASSWORD`: expect bookings grouped by tasting, each with name, email, guests and reference.

### 4. Staff cancellation (Story 4)

1. While signed in, press "Cancel" on a booking. It disappears from the list.
2. Start page: the seats left for that tasting go back up by the booking's guest count.
3. Open the old confirmation link (`/bookings/KB-…`): expect "Booking not found".

### 5. Persistence

1. Make a booking, stop the server (Ctrl+C), start it again.
2. The booking is still listed in the staff area and the seats left are unchanged.

### 6. Phone layout

Open the start page and the booking form at a 375 px wide viewport (browser developer tools). There
is no horizontal scrolling, and the "Book" buttons are easy to tap.
