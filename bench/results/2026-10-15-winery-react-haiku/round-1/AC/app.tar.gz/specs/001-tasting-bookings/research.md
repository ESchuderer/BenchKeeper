# Research: Wine Tasting Bookings

**Feature**: [spec.md](./spec.md) | **Date**: 2026-10-14

No `NEEDS CLARIFICATION` markers remain in the specification or the technical context. The
decisions below resolve the technology and design choices the brief left open.

## 1. Application shape: Express server with a Vite-built React app

- **Decision**: One Express 5 process serves `/api/*` as JSON and serves the Vite-built React
  single-page app (`dist/client`) for every other path. Staff access needs a secret that the browser
  must not see, so server-side code is required.
- **Rationale**: The staff password from `STAFF_PASSWORD` has to be checked on the server. One
  process means one `npm start`, one `PORT`, and no CORS setup.
- **Alternatives considered**:
  - *Vite SPA with no server*: rejected, because the password would have to be shipped to the browser.
  - *Next.js*: a full framework for a three-page site; more moving parts (its own server, caching
    rules, build output) than this app needs. Rejected as heavier than the problem.
  - *Fastify instead of Express*: equally maintained, but Express 5 is the most widely understood
    choice for a small team to maintain. Chosen for familiarity.

## 2. Client routing: React Router 7

- **Decision**: `react-router` 7 with `BrowserRouter` and a route table in `src/App.tsx`.
- **Rationale**: The standard React routing library, maintained, with `useParams` and `Link` for the
  tasting and booking URLs the spec requires.
- **Alternatives considered**: TanStack Router (capable, but less common, more setup); hand-written
  `window.location` switching (rejected by Constitution IV).

## 3. Forms and validation: react-hook-form with a shared Zod schema

- **Decision**: `react-hook-form` for form state and `@hookform/resolvers/zod` for the client
  resolver. `shared/booking-schema.ts` defines the rules once in Zod 4; the Express route parses
  the same schema.
- **Rationale**: Constitution III needs field-specific errors on both sides with one set of rules.
  Sharing the schema prevents the client and server from disagreeing (for example, on the Guests
  range).
- **Alternatives considered**: Formik (less maintained than react-hook-form); validating only on the
  server (rejected: slower feedback and worse UX); separate hand-written checks on each side
  (rejected: they drift).

## 4. Styling: Tailwind CSS 4

- **Decision**: Tailwind CSS 4 through `@tailwindcss/vite`, with theme tokens for the winery palette
  (cream background, wine-red accent, gold highlight) defined in `src/index.css`.
- **Rationale**: Utility classes keep the design system small and consistent, and they make the
  phone layout (mobile-first breakpoints) easy to get right. Maintained by its authors and widely used.
- **Alternatives considered**: Plain CSS modules (fine, but more code to keep consistent); a component
  library such as MUI (too heavy and too "app-like" for a winery site).

## 5. Persistence: in memory with a JSON file

- **Decision**: `server/booking-store.ts` keeps bookings in a `Map` and writes the whole list to
  `DATA_FILE` (default `data/bookings.json`) after every change. Writes go to a temporary file in the
  same directory and are then renamed over the target, so a crash cannot leave half a file. A missing
  file means no bookings, which satisfies "the app starts with no bookings".
- **Rationale**: The spec allows memory or a local file. Bookings are needed after a restart, so a
  file is the better choice. The data volume is small, so rewriting the whole file is simple and fast.
- **Alternatives considered**: SQLite via `better-sqlite3` (safe and concurrent, but a native build
  step for a three-tasting site is more than needed); pure memory (loses bookings on restart, which
  is not acceptable for a shop).

## 6. Seat safety under concurrency

- **Decision**: `booking-service.ts` computes seats left and adds the booking in one synchronous
  function. Node runs one JavaScript thread, so no other request can run between the check and the
  insert. The app runs as a single process.
- **Rationale**: This gives the strongest guarantee with no locking code. Constitution I requires that
  seats are never oversold.
- **Alternatives considered**: database transactions (needed only if the app ran in several processes,
  which the constraints rule out); optimistic version checks (unnecessary for one process).
- **Limit**: Running more than one server process against the same data file would break this
  guarantee. The quickstart and README state the single-process constraint.

## 7. Staff authentication

- **Decision**: `server/staff-auth.ts` compares the submitted password with `STAFF_PASSWORD` by hashing
  both values with SHA-256 and using `crypto.timingSafeEqual`. On success it issues a random 32-byte
  token, held in memory with an 8-hour expiry and sent as the `kb_staff` cookie (`HttpOnly`,
  `SameSite=Strict`, `Path=/`, `Secure` when the request is HTTPS). With no password configured, every
  attempt fails, and a warning is logged at startup.
- **Rationale**: Constitution V. Hashing first makes the comparison safe even when the lengths differ.
  Sessions live in memory, so a restart signs staff out, which the spec accepts.
- **CSRF**: The API accepts only `application/json` request bodies, and the session cookie is
  `SameSite=Strict`. A cross-site form cannot send either.
- **Alternatives considered**: `express-session` with a store (an extra dependency and store for a
  single password); JWT (not needed for one secret and one server).

## 8. Time zones and dates

- **Decision**: Each tasting in `shared/tastings.ts` stores its start with an explicit offset
  (`2026-11-06T18:00:00+01:00`). The client formats dates with `Intl.DateTimeFormat` and
  `timeZone: "Europe/Berlin"`, for example "Fri 6 Nov 2026, 18:00".
- **Rationale**: The winery is in Germany, and all three dates fall in CET (+01:00), so a fixed offset
  is exact. It also lets the server decide whether a tasting has started without depending on the
  container's time zone.
- **Alternatives considered**: naive local strings (ambiguous on a server in another time zone).

## 9. Testing tools

- **Decision**: Vitest 4 for all unit, API and component tests; Supertest for HTTP-level tests of the
  Express app; `@testing-library/react` with `@testing-library/user-event` and jsdom for component
  tests; Playwright for end-to-end flows and the 375 px phone check.
- **Rationale**: All established, and all work with the same TypeScript setup. Playwright is the only
  one that needs a browser download; it is confined to `npm run test:e2e`.
- **Alternatives considered**: Jest (slower ESM support with this stack); Cypress (heavier to run in a
  container than Playwright).

## 10. Booking reference

- **Decision**: `KB-` followed by six characters from an alphabet without look-alikes (no 0, O, 1, I, L),
  generated with `crypto.randomInt`. Generation repeats if the reference already exists.
- **Rationale**: Short, readable over the phone, and hard to guess. Guests can look up a confirmation
  with it, so it must not be guessable in bulk. The lookup returns only the tasting, guests and total,
  not the guest's name or email.
- **Alternatives considered**: sequential numbers (guessable, which exposes booking volume and
  invites enumeration).
