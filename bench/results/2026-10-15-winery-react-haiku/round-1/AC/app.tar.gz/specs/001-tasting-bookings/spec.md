# Feature Specification: Wine Tasting Bookings for Weingut Kieselbrunnen

**Feature Branch**: `001-tasting-bookings` (no branch created; spec directory only)

**Created**: 2026-10-14

**Status**: Draft

**Input**: User description: "Build a web app for Weingut Kieselbrunnen, a family winery, so guests can book wine tastings online and staff can see the bookings."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - See Upcoming Tastings and Seats Left (Priority: P1)

A guest opens the winery's page and sees the three upcoming tastings: Riesling Evening (2026-11-06 18:00, EUR 25 per guest, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32 per guest, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28 per guest, 10 seats). Each tasting shows how many seats are still free, so the guest knows whether it is worth booking.

**Why this priority**: Without a clear list of tastings and their availability, no booking can be made. It is the entry point of the whole guest experience.

**Independent Test**: Open the start page with no bookings made and check that all three tastings appear with the exact title, date and time, price per guest, and "<n> seats left" text from the table above.

**Acceptance Scenarios**:

1. **Given** no bookings exist, **When** a guest opens the start page, **Then** the three tastings are listed with title, date and time, price per guest, and "12 seats left", "8 seats left" and "10 seats left" respectively.
2. **Given** 3 guests have booked the Riesling Evening, **When** a guest opens the start page, **Then** the Riesling Evening shows "9 seats left".
3. **Given** the Red Wine Cellar Tour has 0 seats left, **When** a guest opens the start page, **Then** the tasting is marked as fully booked and has no "Book" button.

---

### User Story 2 - Book a Tasting (Priority: P1)

A guest chooses a tasting, clicks "Book <tasting title>", fills in Name, Email and Guests (1 to 8), and presses "Book". If the input is valid and enough seats remain, the booking is recorded and the guest sees a "Booking confirmed" page with the tasting, the number of guests, the total price and a booking reference. If something is wrong, the guest sees an error next to the field concerned and nothing is booked.

**Why this priority**: Booking is the core transaction the winery needs. Together with Story 1 it is the minimum viable product.

**Independent Test**: From the start page, open "Book Riesling Evening", submit a valid form with 2 guests, and check that the confirmation shows "Booking confirmed", "Riesling Evening", 2 guests, "EUR 50" and a booking reference; then check that the start page now shows "10 seats left".

**Acceptance Scenarios**:

1. **Given** the Riesling Evening has 12 seats left, **When** a guest submits Name "Anna Weber", Email "anna@example.com", Guests 2, **Then** a booking is recorded, the confirmation shows the tasting, 2 guests, total "EUR 50" and a booking reference, and the tasting now shows "10 seats left".
2. **Given** the Winter Tasting has 10 seats left, **When** a guest books 8 guests, **Then** the booking succeeds and the tasting shows "2 seats left".
3. **Given** the Red Wine Cellar Tour has 3 seats left, **When** a guest submits Guests 4, **Then** no booking is recorded, the Guests field shows an error saying that only 3 seats are left, and the seats left count stays at 3.
4. **Given** the Name field is empty, **When** the guest presses "Book", **Then** the Name field shows an error and no booking is recorded.
5. **Given** the Email field contains "anna@example", **When** the guest presses "Book", **Then** the Email field shows an error and no booking is recorded.
6. **Given** the Guests field contains 0, 9, 2.5 or "two", **When** the guest presses "Book", **Then** the Guests field shows an error explaining that Guests must be a whole number from 1 to 8, and no booking is recorded.

---

### User Story 3 - Staff Sign In and See All Bookings (Priority: P2)

A staff member opens `/staff`, types the staff password into the "Password" field and presses "Sign in". Once signed in, they see every booking grouped by tasting, with the guest's name, email, number of guests and booking reference.

**Why this priority**: Staff need the list to prepare each tasting, but guests can already book without it, so this comes second.

**Independent Test**: Make two bookings for different tastings, sign in at `/staff` with the configured password, and check that each booking appears under the correct tasting with name, email, guests and reference.

**Acceptance Scenarios**:

1. **Given** staff are not signed in, **When** someone opens `/staff`, **Then** they see a "Password" field and a "Sign in" button and no booking data.
2. **Given** the configured staff password is "correct-horse", **When** staff enter "wrong" and press "Sign in", **Then** an error is shown next to the Password field and no booking data is shown.
3. **Given** the correct password is entered, **When** staff press "Sign in", **Then** all active bookings are shown grouped by tasting, each with name, email, guests and reference.
4. **Given** no bookings exist for a tasting, **When** staff view the list, **Then** that tasting is still shown with a note that it has no bookings yet.

---

### User Story 4 - Staff Cancel a Booking (Priority: P2)

A signed-in staff member finds a booking and presses "Cancel" next to it. The booking disappears from the staff list and its seats become free again, so the tasting's seats left on the start page go up by the booking's guest count.

**Why this priority**: Cancellations are needed to correct mistakes and to release seats, but bookings can be handled without them in the first release.

**Independent Test**: Book 4 guests on the Winter Tasting, sign in as staff, press "Cancel" on that booking, and check that it disappears from the staff list and that the start page shows "10 seats left" again.

**Acceptance Scenarios**:

1. **Given** a booking of 4 guests for the Winter Tasting, **When** staff press "Cancel" on it, **Then** the booking is removed from the staff list and the Winter Tasting shows "10 seats left".
2. **Given** a cancelled booking, **When** a guest opens the confirmation link for its reference, **Then** the guest sees a "Booking not found" message.
3. **Given** a booking was cancelled, **When** a guest books the freed seats, **Then** the booking succeeds if enough seats are left.

---

### Edge Cases

- A guest books the last seats after another guest has already used them: the second guest gets the "only N seats left" error, and the seats are never oversold.
- A guest opens the booking page of a fully booked tasting: the page shows that the tasting is fully booked and no booking form.
- A guest opens the booking page of an unknown tasting: the page shows "Tasting not found".
- A guest opens a confirmation link with an unknown reference: the page shows "Booking not found".
- A guest double-clicks "Book": only one booking is recorded.
- Name or Email has leading or trailing spaces: they are trimmed before validation and saving.
- Name or Email is longer than the limits in the Assumptions section: the field shows an error.
- A booking is submitted while the seats left shown on the page are out of date: the server's current seat count decides (see Story 2, scenario 3).
- Staff open `/staff` with a wrong password several times: every attempt is refused; no lockout is required (see Assumptions).
- The app is restarted: bookings already made are still listed (see Assumptions).

## Requirements *(mandatory)*

### Functional Requirements

**Tastings and availability**

- **FR-001**: The start page MUST list the three tastings (Riesling Evening, Red Wine Cellar Tour, Winter Tasting), each showing its title, date and time, price per guest, and seats left as "<n> seats left".
- **FR-002**: A tasting with 0 seats left, or whose start time has passed, MUST be shown as "Fully booked", and it MUST NOT offer a booking form.
- **FR-003**: Each tasting MUST have a link or button labelled "Book <tasting title>" (for example "Book Riesling Evening") that opens that tasting's booking form.
- **FR-004**: The seats left for a tasting MUST equal its seat capacity minus the guests of all of its active (not cancelled) bookings.

**Booking form and validation**

- **FR-005**: The booking form MUST have fields labelled "Name", "Email" and "Guests", and a button labelled "Book".
- **FR-006**: "Name" MUST be required, MUST NOT be blank after trimming spaces, and MUST be at most 100 characters.
- **FR-007**: "Email" MUST be required, MUST be a syntactically valid email address, and MUST be at most 254 characters.
- **FR-008**: "Guests" MUST be a whole number from 1 to 8 and MUST NOT be greater than the seats left for the tasting at the time of booking.
- **FR-009**: Every invalid field MUST show its error message next to that field. An invalid form MUST NOT create a booking.
- **FR-010**: If the requested guests exceed the seats left when the booking is recorded, the booking MUST be rejected with a message saying how many seats are left, and the seats left MUST NOT change.
- **FR-011**: A booking MUST be recorded only once per submission, including when "Book" is pressed twice in quick succession.

**Confirmation**

- **FR-012**: After a successful booking, the guest MUST see a page with the heading "Booking confirmed", the tasting title, the number of guests, the total price (guests × price per guest, shown as "EUR <amount>"), and a unique booking reference.
- **FR-013**: The confirmation MUST be viewable again at an address that includes the booking reference, so that reloading the page does not lose it.

**Staff access**

- **FR-014**: The page `/staff` MUST show a "Password" field and a "Sign in" button while staff are not signed in.
- **FR-015**: The staff password MUST be checked against the configured staff password. A wrong password MUST show an error and grant no access to booking data.
- **FR-016**: If no staff password is configured, staff sign-in MUST be refused for every password, and the app MUST log a warning at startup.
- **FR-017**: While signed in, staff MUST see all active bookings grouped by tasting, each showing the guest's name, email, number of guests and booking reference.
- **FR-018**: Booking data and staff actions MUST NOT be available to anyone who is not signed in.
- **FR-019**: Staff MUST be able to cancel any active booking with a "Cancel" button. A cancelled booking MUST be removed from the staff list and its seats MUST become available immediately.

**Data and persistence**

- **FR-020**: The app MUST start with no bookings.
- **FR-021**: Bookings MUST survive an app restart. They MUST be stored in a local file, and the app MUST NOT depend on any external service.
- **FR-022**: The tasting list is fixed for this release: the three tastings above. Staff cannot add, edit or remove tastings.

**Errors and presentation**

- **FR-023**: Unknown tasting addresses, unknown booking references and other unknown addresses MUST show a clear "not found" message in the same visual style as the rest of the site.
- **FR-024**: Every page MUST have clear visual states for loading, errors, success, and fully booked tastings.
- **FR-025**: The guest and staff pages MUST be usable on a phone-sized screen without horizontal scrolling.
- **FR-026**: All interface text MUST be in English.

### Key Entities

- **Tasting**: A wine experience offered by the winery. Attributes: title, date and time, price per guest, seat capacity. Fixed for this release.
- **Booking**: A guest's reservation for one tasting. Attributes: booking reference, tasting, guest name, guest email, number of guests, time of booking, and status (active or cancelled). A cancelled booking no longer counts toward seats or appears in the staff list.
- **Staff session**: The state of a signed-in staff member. Created after a correct password; ends when the session expires or the app restarts.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A first-time guest can find a tasting and complete a booking in under 2 minutes.
- **SC-002**: In every test of simultaneous bookings for the last seats of a tasting, the number of guests booked never exceeds the tasting's seat capacity.
- **SC-003**: 100% of invalid booking inputs are rejected with a message beside the field concerned, and none of them creates a booking.
- **SC-004**: Staff can find and cancel a given booking in under 30 seconds.
- **SC-005**: A guest sees the correct seats left figure on the start page within one page load after a booking is made or cancelled.
- **SC-006**: All guest and staff pages can be used on a phone-width screen (375 pixels wide) without horizontal scrolling.

## Assumptions

- **Payment**: No payment is taken online. The total price is shown on confirmation and paid at the winery. No payment provider is involved.
- **Email**: No confirmation email is sent. The confirmation page and its reference are the only proof of booking. The email address is stored only to contact the guest and is never shown to other guests.
- **Currency and amounts**: Prices are whole euros, shown as "EUR 25" as in the brief. Totals are whole euros as well.
- **Time zone**: Dates and times are the winery's local time and are shown as given, without conversion.
- **Booking cut-off**: Bookings may be made until the tasting starts. No other cut-off applies. Tastings that have already started are shown as fully booked, not as available.
- **Guests**: There are no guest accounts. Guests cannot cancel or change their own bookings; they contact the winery for changes.
- **Staff accounts**: A single shared staff password is used. There are no individual staff accounts and no staff roles.
- **Staff password configuration**: The password is supplied through the environment variable `STAFF_PASSWORD`. It is never shown in the interface.
- **Staff session length**: A staff sign-in lasts 8 hours or until the app restarts, whichever comes first.
- **Brute-force protection**: No lockout or rate limit is applied to the staff sign-in in this release.
- **Field limits**: Name at most 100 characters, Email at most 254 characters, Guests 1 to 8 (as in the brief).
- **Booking reference**: A short, unique code that guests can read out or type. Its exact format is not specified.
- **Persistence**: Bookings are stored in a single local file that the app creates when missing. Concurrent use by many users at the same time is not a goal beyond the seat rule in FR-010.
- **Out of scope**: Payments, emails, guest accounts, guest self-service cancellations, staff accounts, adding or editing tastings, reporting or exports, and multi-language support.
