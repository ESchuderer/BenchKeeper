# Tasks: Wine Tasting Bookings for Weingut Kieselbrunnen

**Input**: Design documents from `/specs/001-tasting-bookings/`

**Prerequisites**: plan.md (required), spec.md (required), research.md, data-model.md, contracts/api.md, quickstart.md

**Tests**: REQUIRED. Constitution II (Test-First, NON-NEGOTIABLE) and the process brief both require
the test task for each behavior to be written and run (and seen failing) before the implementation task
that makes it pass. Test tasks are marked **(red)**; the task after them is the implementation that turns
them **(green)**.

**Organization**: Grouped by user story (US1–US4 from spec.md) after a Setup and a Foundational phase.

## Format: `[ID] [P?] [Story?] Description`

- **[P]**: Can run in parallel (different files, no dependency on an incomplete task)
- **[Story]**: US1 … US4 for user-story phases only
- Every task names its file path(s)

## Path Conventions

Single repository (plan.md › Project Structure): `shared/`, `server/`, `src/`, `tests/`.

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project skeleton, tooling and the end-to-end test written first.

- [X] T001 Create `package.json` (name `weingut-kieselbrunnen-tastings`, `"type": "module"`, `engines.node` `>=22`, scripts `dev:server`, `dev:client`, `build`, `start`, `typecheck`, `test`, `test:e2e`) with the dependencies named in plan.md and research.md (express, cookie-parser, zod, react, react-dom, react-router, react-hook-form, @hookform/resolvers, typescript, vite, @vitejs/plugin-react, tailwindcss, @tailwindcss/vite, tsx, vitest, supertest, jsdom, @testing-library/react, @testing-library/user-event, @testing-library/jest-dom, @playwright/test, and their @types packages); run `npm install`
- [X] T002 [P] Create `tsconfig.json` for the client (`moduleResolution: bundler`, `jsx: react-jsx`, `strict`, includes `src/`, `shared/`, `tests/client/`) in `tsconfig.json`
- [X] T003 [P] Create `tsconfig.server.json` (`module` and `moduleResolution` `NodeNext`, `strict`, `rootDir: "."`, `outDir: "dist"`, includes `server/`, `shared/`) in `tsconfig.server.json`
- [X] T004 [P] Create `vite.config.ts` (React and Tailwind plugins, dev proxy `/api` → `http://localhost:3000`, `build.outDir: "dist/client"`) and `index.html` (title "Weingut Kieselbrunnen · Wine Tastings") in `vite.config.ts`, `index.html`
- [X] T005 [P] Create `vitest.config.ts` including `tests/server/**/*.test.ts` and `tests/client/**/*.test.{ts,tsx}`, excluding `tests/e2e/` in `vitest.config.ts`
- [X] T006 [P] Create `.gitignore` (`node_modules/`, `dist/`, `data/`, `test-results/`, `playwright-report/`) in `.gitignore`
- [X] T007 [P] Create `src/index.css` (Tailwind import and theme tokens: cream background, wine accent, gold highlight, ink text, serif headings) and `src/main.tsx` (React root wrapped in `BrowserRouter`, rendering `App`) in `src/index.css`, `src/main.tsx`
- [X] T008 [P] **(red)** Write `playwright.config.ts` and the end-to-end flow spec `tests/e2e/booking-flow.spec.ts` covering Stories 1–4 and a 375 px no-horizontal-scroll check on the start page and booking form. It is expected to FAIL until US1–US4 are implemented. Run it once to confirm the failure.

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Shared rules, storage, app shell, staff auth primitives, client building blocks. MUST be
complete before any user story.

- [X] T009 **(red)** Write `tests/server/tastings-catalogue.test.ts`: `TASTINGS` has exactly three entries with the ids, titles, `startsAt` values (with `+01:00`), prices (25, 32, 28) and seats (12, 8, 10) from data-model.md
- [X] T010 Implement `shared/tastings.ts` (`Tasting` type, `TASTINGS` constant, `getTasting(id)`) so T009 passes
- [X] T011 **(red)** Write `tests/server/booking-schema.test.ts`: name trimmed, required ("Please enter your name.") and max 100 ("Name must be at most 100 characters."); email trimmed, required, valid (`anna@example` → "Please enter a valid email address, e.g. name@example.com.") and max 254; guests `0`, `9`, `2.5`, `"two"`, `""` and `NaN` all → "Guests must be a whole number from 1 to 8."; valid request parses; staff password empty → "Enter the staff password."
- [X] T012 Implement `shared/booking-schema.ts` (`bookingRequestSchema`, `staffSignInSchema`, message constants) using Zod 4 so T011 passes; guests use `z.number()` (not coerce) on the server
- [X] T013 [P] **(red)** Write `tests/server/booking-store.test.ts`: memory mode add/find/remove/list; file mode with a missing file starts empty; a booking added through one store instance is loaded by a new instance on the same file; file content matches data-model.md's JSON shape; malformed JSON throws an error naming the file; no `.tmp` files remain after a write
- [X] T014 [P] Implement `server/booking-store.ts` (`createBookingStore({ filePath? })` with in-memory `Map` and atomic JSON write via temp file + rename) so T013 passes
- [X] T015 **(red)** Write `tests/server/staff-auth.test.ts`: correct password accepted and returns a 32-byte base64url token; wrong, empty and near-miss passwords refused; no configured password refuses every attempt; token valid until 8 h, invalid after (injected clock); unknown token invalid
- [X] T016 Implement `server/staff-auth.ts` (`createStaffAuth({ password, now })`: SHA-256 digests + `crypto.timingSafeEqual`, token map with expiry) so T015 passes
- [X] T017 **(red)** Write `tests/server/app-shell.test.ts` (Supertest): `GET /api/nope` → 404 `{"error":"not_found"}`; `POST /api/bookings` with `text/plain` → 415 `unsupported_media_type`; malformed JSON → 400 `invalid_json`; `GET /bookings/KB-TEST` and `GET /staff` return `index.html` when `clientDir` contains one
- [X] T018 Implement `server/app.ts` (`createApp({ bookingService, staffAuth, clientDir })`: `express.json`, `cookie-parser`, JSON 404/415/400/500 handlers, static `clientDir` with SPA fallback for non-API GETs) and `server/index.ts` (reads `PORT` default 3000, `STAFF_PASSWORD` (warn if empty), `DATA_FILE` default `data/bookings.json`, `clientDir` `dist/client`, listens) so T017 passes. Route modules are mounted in their story phases; `server/index.ts` is written in T028, once there is a booking service to wire in
- [X] T019 [P] **(red)** Write `tests/client/format.test.ts`: `formatStartsAt("2026-11-06T18:00:00+01:00")` → "Fri 6 Nov 2026, 18:00" (Europe/Berlin); `formatPrice(50)` → "EUR 50"; `seatsLeftLabel(12)` → "12 seats left", `seatsLeftLabel(1)` → "1 seat left"
- [X] T020 [P] Implement `src/format.ts` so T019 passes
- [X] T021 [P] **(red)** Write `tests/client/api-client.test.ts`: `requestJson` returns parsed JSON; 204 returns `undefined`; a non-2xx response throws `ApiError` carrying `status`, `code`, `message` and `fieldErrors`; a network failure throws `ApiError` with code `network_error`
- [X] T022 [P] Implement `src/api/client.ts` (`requestJson`, `ApiError`) so T021 passes
- [X] T023 **(red)** Write `tests/client/field.test.tsx`: `Field` renders a label bound to its input, shows error text with `role="alert"`, and links the error via `aria-describedby`; `Alert` renders tone-specific classes for `success`, `error`, `info`
- [X] T024 Implement `src/components/Field.tsx`, `src/components/Alert.tsx` and `src/components/Layout.tsx` (header with winery name, main container, footer) so T023 passes
- [X] T025 Implement `src/App.tsx` (route table: `/`, `/tastings/:tastingId/book`, `/bookings/:reference`, `/staff`, `*`) with placeholder page components, and `src/pages/NotFoundPage.tsx` ("Page not found" message with a link home)

**Checkpoint**: Foundation complete. Story work can start. Only T001–T025 are shared; each story below touches its own files.

---

## Phase 3: User Story 1 - See Upcoming Tastings and Seats Left (Priority: P1) 🎯 MVP

**Goal**: Start page lists the three tastings with title, date and time, price, and "<n> seats left" or "Fully booked".

**Independent Test**: Open `/` with no bookings → three cards with 12/8/10 seats left; no "Book" link on a fully booked tasting.

- [X] T026 [US1] **(red)** Write `tests/server/api-tastings.test.ts` (Supertest): `GET /api/tastings` returns three tastings with `seatsLeft` equal to seats and `status: "open"`; `GET /api/tastings/winter-tasting` returns it; `GET /api/tastings/unknown` → 404 `tasting_not_found`
- [X] T027 [US1] **(red)** Write `tests/client/tastings-page.test.tsx` and `tests/client/tasting-card.test.tsx`: card shows title, formatted date, "EUR 25 per guest", "12 seats left" and a link named "Book Riesling Evening" to `/tastings/riesling-evening/book`; a tasting with `seatsLeft: 0` shows "Fully booked" and no link; the page shows a loading state, an error with a retry button, and the list
- [X] T028 [US1] Implement `server/index.ts` (reads `PORT`, `STAFF_PASSWORD` (warns if empty), `DATA_FILE` default `data/bookings.json`, `clientDir` `dist/client`; listens) and `server/booking-service.ts` with `listTastings()` and `getTasting(id)`, computing `seatsLeft` as seats minus active bookings (store-backed) and `status` (fully booked when 0 seats left or `startsAt` passed); implement `server/routes/tastings.ts` and mount it in `server/app.ts`, so T026 passes
- [X] T029 [US1] Implement `src/components/TastingCard.tsx` and `src/pages/TastingsPage.tsx` (fetch `/api/tastings`, loading skeleton, error alert with retry, grid of cards) and wire `/` in `src/App.tsx`, so T027 passes

**Checkpoint**: US1 works alone. `npm test` passes for US1 files.

---

## Phase 4: User Story 2 - Book a Tasting (Priority: P1)

**Goal**: Guests book 1–8 seats via the form; invalid input gets field errors; seats are never oversold; confirmation page with reference.

**Independent Test**: Book 2 guests on Riesling Evening → "Booking confirmed", "EUR 50", reference; seats left drops to 10.

- [X] T030 [US2] **(red)** Write `tests/server/booking-service.test.ts` (book section): valid booking records reference `KB-` + 6 characters from the allowed alphabet and reduces seats; guests greater than seats left → `insufficient_seats` with `seatsLeft` and no change; 0 seats left → `fully_booked`; started tasting → `fully_booked`; unknown tasting → `tasting_not_found`; sequential bookings totalling more than capacity: the first that exceeds seats is rejected, the sum never exceeds capacity; `getConfirmation(ref)` returns no name or email
- [X] T031 [US2] **(red)** Write `tests/server/api-bookings.test.ts` (Supertest): `POST /api/bookings` → 201 with `totalPrice` = guests × price; 400 `validation_failed` with `fieldErrors` for each bad field; 409 `insufficient_seats` with `seatsLeft`; 409 `fully_booked`; 404 `tasting_not_found`; `GET /api/bookings/:ref` → 200 without name/email, 404 `booking_not_found` otherwise; **concurrency**: 12 parallel `POST`s of 1 guest on Riesling Evening → exactly 12 × 201 and seats left 0; 13th → 409
- [X] T032 [US2] **(red)** Write `tests/client/booking-form.test.tsx`: fields labelled "Name", "Email", "Guests" and a "Book" button; submitting empty shows an error beside each field and sends no request; `anna@example`, `0`, `9`, `2.5` show their messages beside their fields; a server 409 `insufficient_seats` shows its message beside Guests; the button is disabled while submitting and a double click sends one request; success navigates to `/bookings/KB-…`; a fully booked tasting shows "Fully booked" and no form; unknown tasting shows "Tasting not found"
- [X] T033 [US2] **(red)** Write `tests/client/confirmation-page.test.tsx`: shows heading "Booking confirmed", tasting title, "2 guests", "EUR 50" and reference; unknown reference shows "Booking not found" with a link home
- [X] T034 [US2] Implement `server/booking-service.ts` `book(input)` (tasting lookup → status check → seat check → add booking, all in one synchronous call; reference generation with collision retry via `crypto.randomInt`) and `getConfirmation(ref)`; implement `server/routes/bookings.ts` (`POST /api/bookings` using `bookingRequestSchema.safeParse` → field errors; `GET /api/bookings/:reference`) and mount it, so T030 and T031 pass
- [X] T035 [US2] Implement `src/api/bookings.ts` (`createBooking`, `getConfirmation`) and `src/pages/BookingPage.tsx` (react-hook-form + `zodResolver(bookingFormSchema)`, `Field` components, server `fieldErrors` mapped with `setError`, submit disabled while pending, navigate on success, "Tasting not found" and "Fully booked" states); wire `/tastings/:tastingId/book` in `src/App.tsx`, so T032 passes
- [X] T036 [US2] Implement `src/pages/ConfirmationPage.tsx` (fetch by reference; heading "Booking confirmed"; tasting, guests, total "EUR n", reference; "Booking not found" state) and wire `/bookings/:reference`, so T033 passes

**Checkpoint**: US1 + US2 work. Guests can book end to end.

---

## Phase 5: User Story 3 - Staff Sign In and See All Bookings (Priority: P2)

**Goal**: `/staff` shows a password sign-in; signed-in staff see all bookings grouped by tasting.

**Independent Test**: With two bookings for different tastings, sign in with the password → each booking appears under the right tasting with name, email, guests, reference.

- [X] T037 [US3] **(red)** Write `tests/server/api-staff.test.ts` (sign-in part): `POST /api/staff/session` with the right password → 200, `Set-Cookie` contains `kb_staff=`, `HttpOnly`, `SameSite=Strict`, `Path=/`, `Max-Age=28800`; wrong password → 401 `invalid_password` with `fieldErrors.password` "Incorrect password."; empty → 400 with "Enter the staff password."; no configured password → 401; `GET /api/staff/bookings` without cookie → 401 `staff_sign_in_required`; with cookie → 200 grouped by tasting, all tastings present (empty ones with `bookings: []`), includes email; expired cookie → 401
- [X] T038 [US3] **(red)** Write `tests/client/staff-page.test.tsx` (sign-in part): shows "Password" field and "Sign in" button when signed out; a wrong password shows "Incorrect password." beside the field; after sign-in shows grouped bookings with name, email, guests and reference; a tasting with no bookings shows "No bookings yet"
- [X] T039 [US3] Implement `server/booking-service.ts` `listForStaff()` (active bookings grouped by tasting in catalogue order), `server/routes/staff.ts` (`POST /api/staff/session` sets the cookie via `res.cookie` with the contract's options and `secure: req.secure`; `GET /api/staff/bookings` checks the cookie through `staffAuth.verify`), and mount it in `server/app.ts`, so T037 passes
- [X] T040 [US3] Implement `src/api/staff.ts` and `src/pages/StaffPage.tsx` (sign-in form with `Field` "Password" and "Sign in"; grouped list with tasting heading, date, seats left, booking rows; "No bookings yet"; session check on load) and wire `/staff`, so T038 passes

**Checkpoint**: US1–US3 work. Staff can review bookings.

---

## Phase 6: User Story 4 - Staff Cancel a Booking (Priority: P2)

**Goal**: Staff can cancel a booking; seats are freed immediately; the confirmation link stops working.

**Independent Test**: Book 4 on Winter Tasting → cancel as staff → list no longer shows it, seats back to 10.

- [X] T041 [US4] **(red)** Add cancel tests to `tests/server/booking-service.test.ts`: `cancel(ref)` removes the booking, returns `true`, frees seats (seats left goes up by the guest count); an unknown reference returns `false`; after cancel, `getConfirmation(ref)` returns `undefined`; a freed seat can be booked again
- [X] T042 [US4] **(red)** Add cancel tests to `tests/server/api-staff.test.ts`: `DELETE /api/staff/bookings/:ref` → 204 and the public tasting `seatsLeft` goes back up; without a session → 401; unknown reference → 404 `booking_not_found`; the confirmation link then returns 404. Add to `tests/client/staff-page.test.tsx`: pressing "Cancel" calls `DELETE` for that reference and removes the row; a failed cancel shows an error alert
- [X] T043 [US4] Implement `cancel(ref)` in `server/booking-service.ts`, `DELETE /api/staff/bookings/:reference` in `server/routes/staff.ts` (session check, 204 / 404), so T041 and T042 (server) pass
- [X] T044 [US4] Add the "Cancel" button per booking row in `src/pages/StaffPage.tsx` (disabled while pending, calls `cancelBooking` in `src/api/staff.ts`, refreshes the list, shows an error alert on failure), so the client part of T042 passes

**Checkpoint**: All four user stories work independently and together.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Visual quality, documentation, full verification.

- [X] T045 [P] Visual polish across pages in `src/components/*.tsx`, `src/pages/*.tsx`, `src/index.css`: winery-style header and hero on the start page, cards with clear states (open, fully booked badge, focus rings), success banner styling on confirmation, error styling next to fields, phone-first spacing with no horizontal overflow
- [X] T046 [P] Write `README.md` (setup, `STAFF_PASSWORD`, `PORT`, `DATA_FILE`, scripts, the single-process note from research.md §6)
- [X] T047 Run `npm run typecheck`, `npm test` and `npm run build`; fix every failure found; record the output in the final report
- [X] T048 Run `npx playwright install chromium` then `npm run test:e2e`; T008's spec must pass, including the 375 px check; attach failure details if any remain
- [X] T049 Smoke-test the built app per `quickstart.md`: `STAFF_PASSWORD=… npm start`, then the curl and browser steps; confirm restart persistence (scenario 5)

---

## Dependencies & Execution Order

### Phase dependencies

- **Setup (Phase 1)**: No dependencies. T001 first; T002–T008 can follow in parallel.
- **Foundational (Phase 2)**: After Phase 1. Blocks every story. Within it, each red test precedes its implementation: T009→T010, T011→T012, T013→T014, T015→T016, T017→T018, T019→T020, T021→T022, T023→T024, then T025.
- **US1 (Phase 3)**: After Phase 2. Creates `booking-service.ts` (T028).
- **US2 (Phase 4)**: After US1 (`booking-service.ts` and `App.tsx` exist). T034 extends the service and routes.
- **US3 (Phase 5)**: After US2 (bookings must exist to be listed). T039 extends the service.
- **US4 (Phase 6)**: After US3 (cancel lives on the staff page).
- **Polish (Phase 7)**: After all stories. T047 and T048 are last.

### Within each story

Red test tasks → implementation tasks that make them pass → checkpoint.

### Parallel opportunities

- Phase 1: T002, T003, T004, T005, T006, T007, T008 touch different files.
- Phase 2: the store (T013/T014), date formatting (T019/T020) and API client (T021/T022) pairs are independent of each other.
- Phase 7: T045 and T046 touch different files.
- Within a story, the red tests for server and client (for example T030/T032) can be written in parallel.

## Implementation Strategy

### MVP first (US1 + US2)

1. Phases 1–2, then Phase 3 (US1) and Phase 4 (US2).
2. Stop and check: a guest can see the tastings and book them end to end.

### Incremental delivery

1. Add US3 (staff view) → check.
2. Add US4 (cancel) → check.
3. Polish, then full verification (T047–T049).

---

## Summary

- **Total tasks**: 49 (T001–T049), all complete
- **Per story**: US1 4 (T026–T029) · US2 7 (T030–T036) · US3 4 (T037–T040) · US4 4 (T041–T044)
- **Setup 8, Foundational 17, Polish 5**
- **Suggested MVP scope**: US1 + US2 (Phases 3–4)

## Implementation notes

- Dates use the platform's en-GB format, which puts a comma after the weekday: "Fri, 6 Nov 2026, 18:00".
- Email has a length rule (254) with its own message, "Email must be at most 254 characters.", in addition to the format rule.
- `server/index.ts` was written with T028 rather than T018 (see the T018 and T028 notes above).
- The dev dependency tree pins `@vitest/mocker` to 4.1.11 through an npm `overrides` entry, because earlier versions carry an advisory. A plain `npm install` hit an npm resolver bug while adding vitest; `npm ci` from the committed lockfile installs cleanly.
