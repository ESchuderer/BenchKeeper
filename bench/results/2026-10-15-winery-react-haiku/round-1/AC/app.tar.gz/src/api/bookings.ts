import type { BookingReceipt, Confirmation } from "../../shared/api-types.js";
import { requestJson } from "./client.js";

export interface NewBooking {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export function createBooking(booking: NewBooking) {
  return requestJson<BookingReceipt>("/api/bookings", { method: "POST", body: JSON.stringify(booking) });
}

export function getConfirmation(reference: string) {
  return requestJson<Confirmation>(`/api/bookings/${encodeURIComponent(reference)}`);
}
