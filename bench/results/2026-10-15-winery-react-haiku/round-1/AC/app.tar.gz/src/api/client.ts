export interface ErrorBody {
  error?: string;
  message?: string;
  fieldErrors?: Record<string, string>;
}

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly fieldErrors: Record<string, string>;

  constructor({
    status,
    code,
    message,
    fieldErrors = {},
  }: {
    status: number;
    code: string;
    message: string;
    fieldErrors?: Record<string, string>;
  }) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.fieldErrors = fieldErrors;
  }
}

/** Calls the JSON API. Resolves with the parsed body, or undefined for 204. Rejects with ApiError. */
export async function requestJson<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Accept", "application/json");
  if (init.body !== undefined) headers.set("Content-Type", "application/json");

  let response: Response;
  try {
    response = await fetch(path, { ...init, headers, credentials: "same-origin" });
  } catch {
    throw new ApiError({
      status: 0,
      code: "network_error",
      message: "We could not reach the server. Check your connection and try again.",
    });
  }

  if (response.status === 204) return undefined as T;

  const text = await response.text();
  let body: unknown;
  try {
    body = text ? JSON.parse(text) : undefined;
  } catch {
    body = undefined;
  }

  if (!response.ok) {
    const errorBody = (body ?? {}) as ErrorBody;
    throw new ApiError({
      status: response.status,
      code: errorBody.error ?? "unknown_error",
      message: errorBody.message ?? "Something went wrong. Please try again.",
      fieldErrors: errorBody.fieldErrors,
    });
  }

  return body as T;
}
