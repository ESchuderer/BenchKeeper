import type { StaffTastingGroup } from "../../shared/api-types.js";
import { requestJson } from "./client.js";

export function signIn(password: string) {
  return requestJson<{ signedIn: boolean }>("/api/staff/session", {
    method: "POST",
    body: JSON.stringify({ password }),
  });
}

export function cancelBooking(reference: string) {
  return requestJson<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: "DELETE" });
}

export function getStaffBookings() {
  return requestJson<StaffTastingGroup[]>("/api/staff/bookings");
}
