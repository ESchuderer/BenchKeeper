import type { TastingView } from "../../shared/api-types.js";
import { requestJson } from "./client.js";

export function getTasting(tastingId: string) {
  return requestJson<TastingView>(`/api/tastings/${encodeURIComponent(tastingId)}`);
}
