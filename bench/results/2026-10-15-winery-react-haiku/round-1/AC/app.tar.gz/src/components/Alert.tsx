import type { ReactNode } from "react";

type Tone = "success" | "error" | "info";

const toneClasses: Record<Tone, string> = {
  success: "border-success/30 bg-success/10 text-success",
  error: "border-error/30 bg-error/10 text-error",
  info: "border-gold/40 bg-gold/10 text-ink",
};

// Errors are announced at once (role="alert"); other messages are polite status updates.
export function Alert({ tone, children }: { tone: Tone; children: ReactNode }) {
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      data-tone={tone}
      className={`rounded-lg border px-4 py-3 text-sm font-medium ${toneClasses[tone]}`}
    >
      {children}
    </div>
  );
}
