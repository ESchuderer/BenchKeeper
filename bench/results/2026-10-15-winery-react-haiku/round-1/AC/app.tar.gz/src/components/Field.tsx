import { cloneElement, type ReactElement } from "react";

interface InputProps {
  id?: string;
  className?: string;
  "aria-invalid"?: boolean;
  "aria-describedby"?: string;
}

interface FieldProps {
  id: string;
  label: string;
  error?: string;
  children: ReactElement<InputProps>;
}

// Wires the label, the error text and the input's accessibility attributes together.
export function Field({ id, label, error, children }: FieldProps) {
  const errorId = `${id}-error`;
  const input = cloneElement(children, {
    id,
    "aria-invalid": error ? true : undefined,
    "aria-describedby": error ? errorId : undefined,
    className: [
      "w-full rounded-lg border bg-paper px-3.5 py-2.5 text-base text-ink shadow-sm outline-none focus:ring-2 focus:ring-wine/40",
      error ? "border-error" : "border-ink/20",
      children.props.className,
    ]
      .filter(Boolean)
      .join(" "),
  });

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-semibold text-ink">
        {label}
      </label>
      {input}
      {error && (
        <p id={errorId} role="alert" className="text-sm font-medium text-error">
          {error}
        </p>
      )}
    </div>
  );
}
