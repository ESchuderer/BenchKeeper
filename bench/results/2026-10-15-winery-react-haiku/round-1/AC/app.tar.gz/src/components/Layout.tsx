import { Link, Outlet } from "react-router";

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b border-gold/30 bg-wine text-cream">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-4 py-5">
          <Link to="/" className="font-serif text-xl tracking-wide sm:text-2xl">
            Weingut Kieselbrunnen
          </Link>
          <span className="hidden text-sm italic text-cream/80 sm:block">Family winery · Wine tastings</span>
        </div>
      </header>
      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-8 sm:py-12">
        <Outlet />
      </main>
      <footer className="border-t border-ink/10 py-6 text-center text-sm text-ink/60">
        Weingut Kieselbrunnen · Family winery
      </footer>
    </div>
  );
}
