import { Link } from "react-router";
import type { TastingView } from "../../shared/api-types.js";
import { formatPrice, formatStartsAt, seatsLeftLabel } from "../format.js";

export function TastingCard({ tasting }: { tasting: TastingView }) {
  const fullyBooked = tasting.status === "fully_booked";

  return (
    <article className="flex flex-col rounded-2xl border border-gold/30 bg-paper p-6 shadow-sm">
      <h2 className="font-serif text-2xl text-wine">{tasting.title}</h2>
      <p className="mt-1 text-sm text-ink/70">{formatStartsAt(tasting.startsAt)}</p>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
        <p className="font-semibold">{formatPrice(tasting.pricePerGuest)} per guest</p>
        {fullyBooked ? (
          <span className="rounded-full bg-ink/10 px-3 py-1 text-sm font-semibold text-ink/70">Fully booked</span>
        ) : (
          <span className="rounded-full bg-success/10 px-3 py-1 text-sm font-semibold text-success">
            {seatsLeftLabel(tasting.seatsLeft)}
          </span>
        )}
      </div>

      <div className="mt-6">
        {fullyBooked ? (
          <p className="text-sm text-ink/60">No seats are available for this tasting.</p>
        ) : (
          <Link
            to={`/tastings/${tasting.id}/book`}
            className="inline-flex w-full items-center justify-center rounded-lg bg-wine px-5 py-3 font-semibold text-cream shadow-sm transition hover:bg-wine/90 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold sm:w-auto"
          >
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
