// Dates are shown in the winery's time zone, whatever the visitor's own time zone is.
const dateFormatter = new Intl.DateTimeFormat("en-GB", {
  timeZone: "Europe/Berlin",
  weekday: "short",
  day: "numeric",
  month: "short",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
});

export function formatStartsAt(startsAt: string): string {
  return dateFormatter.format(new Date(startsAt));
}

export function formatPrice(euros: number): string {
  return `EUR ${euros}`;
}

export function seatsLeftLabel(seatsLeft: number): string {
  return seatsLeft === 1 ? "1 seat left" : `${seatsLeft} seats left`;
}
