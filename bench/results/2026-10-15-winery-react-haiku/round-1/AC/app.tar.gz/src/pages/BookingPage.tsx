import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useNavigate, useParams } from "react-router";
import { zodResolver } from "@hookform/resolvers/zod";
import type { TastingView } from "../../shared/api-types.js";
import { bookingRequestSchema, MAX_GUESTS } from "../../shared/booking-schema.js";
import { ApiError } from "../api/client.js";
import { createBooking } from "../api/bookings.js";
import { getTasting } from "../api/tastings.js";
import { Alert } from "../components/Alert.js";
import { Field } from "../components/Field.js";
import { formatPrice, formatStartsAt, seatsLeftLabel } from "../format.js";

// The same rules the server applies, minus the tasting id (taken from the URL).
const formSchema = bookingRequestSchema.omit({ tastingId: true });
type FormValues = ReturnType<typeof formSchema.parse>;

type TastingState =
  | { status: "loading" }
  | { status: "not_found" }
  | { status: "error"; message: string }
  | { status: "ready"; tasting: TastingView };

const FORM_FIELDS = ["name", "email", "guests"] as const;

export function BookingPage() {
  const { tastingId = "" } = useParams();
  const navigate = useNavigate();
  const [tastingState, setTastingState] = useState<TastingState>({ status: "loading" });
  const [formError, setFormError] = useState<string>();
  const sending = useRef(false);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: "", email: "" },
  });

  useEffect(() => {
    let active = true;
    setTastingState({ status: "loading" });
    getTasting(tastingId)
      .then((tasting) => active && setTastingState({ status: "ready", tasting }))
      .catch((error: unknown) => {
        if (!active) return;
        if (error instanceof ApiError && error.code === "tasting_not_found") {
          setTastingState({ status: "not_found" });
        } else {
          setTastingState({ status: "error", message: "We could not load this tasting. Please try again." });
        }
      });
    return () => {
      active = false;
    };
  }, [tastingId]);

  // Submitting sets `sending` before any await, so a second click is ignored even before the button is disabled.
  async function onValid(values: FormValues) {
    if (sending.current) return;
    sending.current = true;
    setFormError(undefined);
    try {
      const receipt = await createBooking({ tastingId, ...values });
      navigate(`/bookings/${receipt.reference}`);
    } catch (error) {
      if (error instanceof ApiError && Object.keys(error.fieldErrors).length > 0) {
        for (const field of FORM_FIELDS) {
          const message = error.fieldErrors[field];
          if (message) setError(field, { type: "server", message });
        }
      } else {
        setFormError(error instanceof ApiError ? error.message : "Something went wrong. Please try again.");
      }
    } finally {
      sending.current = false;
    }
  }

  if (tastingState.status === "loading") {
    return <p className="text-ink/70">Loading tasting…</p>;
  }

  if (tastingState.status === "not_found") {
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-3xl text-wine">Tasting not found</h1>
        <p className="text-ink/80">This tasting does not exist or is no longer offered.</p>
        <Link to="/" className="font-semibold text-wine underline underline-offset-4">
          Back to the tastings
        </Link>
      </section>
    );
  }

  if (tastingState.status === "error") {
    return <Alert tone="error">{tastingState.message}</Alert>;
  }

  const { tasting } = tastingState;
  const fullyBooked = tasting.status === "fully_booked";

  return (
    <section className="mx-auto max-w-lg space-y-6">
      <header className="space-y-2">
        <h1 className="font-serif text-3xl text-wine">{tasting.title}</h1>
        <p className="text-ink/80">
          {formatStartsAt(tasting.startsAt)} · {formatPrice(tasting.pricePerGuest)} per guest
        </p>
        {!fullyBooked && <p className="text-sm font-semibold text-success">{seatsLeftLabel(tasting.seatsLeft)}</p>}
      </header>

      {fullyBooked ? (
        <div className="space-y-4">
          <Alert tone="info">Fully booked</Alert>
          <Link to="/" className="font-semibold text-wine underline underline-offset-4">
            See the other tastings
          </Link>
        </div>
      ) : (
        <form
          noValidate
          onSubmit={handleSubmit(onValid)}
          className="space-y-5 rounded-2xl border border-gold/30 bg-paper p-6 shadow-sm"
        >
          {formError && <Alert tone="error">{formError}</Alert>}

          <Field id="name" label="Name" error={errors.name?.message}>
            <input {...register("name")} type="text" autoComplete="name" />
          </Field>

          <Field id="email" label="Email" error={errors.email?.message}>
            <input {...register("email")} type="email" autoComplete="email" inputMode="email" />
          </Field>

          <Field id="guests" label="Guests" error={errors.guests?.message}>
            <input
              {...register("guests", { valueAsNumber: true })}
              type="number"
              inputMode="numeric"
              min={1}
              max={MAX_GUESTS}
              step={1}
            />
          </Field>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full rounded-lg bg-wine px-5 py-3 font-semibold text-cream shadow-sm transition hover:bg-wine/90 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold disabled:cursor-wait disabled:opacity-60"
          >
            Book
          </button>
        </form>
      )}
    </section>
  );
}
