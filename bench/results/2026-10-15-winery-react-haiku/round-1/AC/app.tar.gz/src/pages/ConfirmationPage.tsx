import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import type { Confirmation } from "../../shared/api-types.js";
import { ApiError } from "../api/client.js";
import { getConfirmation } from "../api/bookings.js";
import { Alert } from "../components/Alert.js";
import { formatPrice, formatStartsAt } from "../format.js";

type LoadState =
  | { status: "loading" }
  | { status: "not_found" }
  | { status: "error"; message: string }
  | { status: "ready"; confirmation: Confirmation };

export function ConfirmationPage() {
  const { reference = "" } = useParams();
  const [state, setState] = useState<LoadState>({ status: "loading" });

  useEffect(() => {
    let active = true;
    getConfirmation(reference)
      .then((confirmation) => active && setState({ status: "ready", confirmation }))
      .catch((error: unknown) => {
        if (!active) return;
        if (error instanceof ApiError && error.code === "booking_not_found") {
          setState({ status: "not_found" });
        } else {
          setState({ status: "error", message: "We could not load this booking. Please try again." });
        }
      });
    return () => {
      active = false;
    };
  }, [reference]);

  if (state.status === "loading") return <p className="text-ink/70">Loading your booking…</p>;

  if (state.status === "not_found") {
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-3xl text-wine">Booking not found</h1>
        <p className="text-ink/80">No booking matches this reference. Check the reference and try again.</p>
        <Link to="/" className="font-semibold text-wine underline underline-offset-4">
          Back to the tastings
        </Link>
      </section>
    );
  }

  if (state.status === "error") return <Alert tone="error">{state.message}</Alert>;

  const { confirmation } = state;
  return (
    <section className="mx-auto max-w-lg space-y-6">
      <Alert tone="success">Thank you! Your seats are reserved.</Alert>
      <h1 className="font-serif text-3xl text-wine">Booking confirmed</h1>

      <dl className="divide-y divide-ink/10 rounded-2xl border border-gold/30 bg-paper px-6 py-2 shadow-sm">
        <div className="flex justify-between gap-4 py-3">
          <dt className="text-ink/70">Tasting</dt>
          <dd className="text-right font-semibold">{confirmation.tastingTitle}</dd>
        </div>
        <div className="flex justify-between gap-4 py-3">
          <dt className="text-ink/70">When</dt>
          <dd className="text-right font-semibold">{formatStartsAt(confirmation.startsAt)}</dd>
        </div>
        <div className="flex justify-between gap-4 py-3">
          <dt className="text-ink/70">Guests</dt>
          <dd className="text-right font-semibold">
            {confirmation.guests === 1 ? "1 guest" : `${confirmation.guests} guests`}
          </dd>
        </div>
        <div className="flex justify-between gap-4 py-3">
          <dt className="text-ink/70">Total</dt>
          <dd className="text-right font-semibold">{formatPrice(confirmation.totalPrice)}</dd>
        </div>
        <div className="flex justify-between gap-4 py-3">
          <dt className="text-ink/70">Booking reference</dt>
          <dd className="text-right font-mono font-semibold tracking-wider">{confirmation.reference}</dd>
        </div>
      </dl>

      <p className="text-sm text-ink/70">
        Please show this reference when you arrive. Payment is made at the winery.
      </p>
      <Link to="/" className="font-semibold text-wine underline underline-offset-4">
        Back to the tastings
      </Link>
    </section>
  );
}
