import { Link } from "react-router";

export function NotFoundPage() {
  return (
    <section className="space-y-4">
      <h1 className="font-serif text-3xl text-wine">Page not found</h1>
      <p className="text-ink/80">The page you are looking for does not exist.</p>
      <Link to="/" className="font-semibold text-wine underline underline-offset-4">
        Back to the tastings
      </Link>
    </section>
  );
}
