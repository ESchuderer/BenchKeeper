import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { StaffTastingGroup } from "../../shared/api-types.js";
import { staffSignInSchema, type StaffSignIn } from "../../shared/booking-schema.js";
import { ApiError } from "../api/client.js";
import { cancelBooking, getStaffBookings, signIn } from "../api/staff.js";
import { Alert } from "../components/Alert.js";
import { Field } from "../components/Field.js";
import { formatStartsAt, seatsLeftLabel } from "../format.js";

type ViewState =
  | { status: "checking" }
  | { status: "signed_out" }
  | { status: "signed_in"; groups: StaffTastingGroup[] }
  | { status: "error"; message: string };

export function StaffPage() {
  const [view, setView] = useState<ViewState>({ status: "checking" });
  const [signInError, setSignInError] = useState<string>();
  const [actionError, setActionError] = useState<string>();
  const [cancelling, setCancelling] = useState<string>();
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<StaffSignIn>({ resolver: zodResolver(staffSignInSchema), defaultValues: { password: "" } });

  async function loadBookings() {
    try {
      const groups = await getStaffBookings();
      setView({ status: "signed_in", groups });
    } catch (error) {
      if (error instanceof ApiError && error.code === "staff_sign_in_required") {
        setView({ status: "signed_out" });
      } else {
        setView({ status: "error", message: "We could not load the bookings. Please try again." });
      }
    }
  }

  useEffect(() => {
    void loadBookings();
  }, []);

  async function onSignIn({ password }: StaffSignIn) {
    setSignInError(undefined);
    try {
      await signIn(password);
      await loadBookings();
    } catch (error) {
      if (error instanceof ApiError && error.fieldErrors.password) {
        setError("password", { type: "server", message: error.fieldErrors.password });
      } else {
        setSignInError(error instanceof ApiError ? error.message : "Something went wrong. Please try again.");
      }
    }
  }

  async function onCancel(reference: string) {
    setActionError(undefined);
    setCancelling(reference);
    try {
      await cancelBooking(reference);
      await loadBookings();
    } catch (error) {
      setActionError(error instanceof ApiError ? error.message : "Something went wrong. Please try again.");
    } finally {
      setCancelling(undefined);
    }
  }

  if (view.status === "checking") return <p className="text-ink/70">Loading…</p>;

  if (view.status === "error") return <Alert tone="error">{view.message}</Alert>;

  if (view.status === "signed_out") {
    return (
      <section className="mx-auto max-w-sm space-y-6">
        <h1 className="font-serif text-3xl text-wine">Staff sign in</h1>
        <form
          noValidate
          onSubmit={handleSubmit(onSignIn)}
          className="space-y-5 rounded-2xl border border-gold/30 bg-paper p-6 shadow-sm"
        >
          {signInError && <Alert tone="error">{signInError}</Alert>}
          <Field id="password" label="Password" error={errors.password?.message}>
            <input {...register("password")} type="password" autoComplete="current-password" />
          </Field>
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full rounded-lg bg-wine px-5 py-3 font-semibold text-cream shadow-sm transition hover:bg-wine/90 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold disabled:cursor-wait disabled:opacity-60"
          >
            Sign in
          </button>
        </form>
      </section>
    );
  }

  return (
    <section className="space-y-10">
      <h1 className="font-serif text-3xl text-wine">Bookings</h1>

      {actionError && <Alert tone="error">{actionError}</Alert>}

      {view.groups.map(({ tasting, bookings }) => (
        <section key={tasting.id} aria-labelledby={`tasting-${tasting.id}`} className="space-y-4">
          <header>
            <h2 id={`tasting-${tasting.id}`} className="font-serif text-2xl text-wine">
              {tasting.title}
            </h2>
            <p className="text-sm text-ink/70">
              {formatStartsAt(tasting.startsAt)} · {seatsLeftLabel(tasting.seatsLeft)}
            </p>
          </header>

          {bookings.length === 0 ? (
            <p className="rounded-lg border border-dashed border-ink/20 px-4 py-6 text-center text-ink/60">
              No bookings yet
            </p>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-gold/30 bg-paper shadow-sm">
              <table className="w-full min-w-[32rem] text-left text-sm">
                <thead className="bg-cream text-ink/70">
                  <tr>
                    <th scope="col" className="px-4 py-3 font-semibold">Name</th>
                    <th scope="col" className="px-4 py-3 font-semibold">Email</th>
                    <th scope="col" className="px-4 py-3 font-semibold">Guests</th>
                    <th scope="col" className="px-4 py-3 font-semibold">Reference</th>
                    <th scope="col" className="px-4 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {bookings.map((booking) => (
                    <tr key={booking.reference} className="border-t border-ink/10">
                      <td className="px-4 py-3 font-semibold">{booking.name}</td>
                      <td className="px-4 py-3">{booking.email}</td>
                      <td className="px-4 py-3">{booking.guests}</td>
                      <td className="px-4 py-3 font-mono tracking-wider">{booking.reference}</td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          disabled={cancelling === booking.reference}
                          onClick={() => void onCancel(booking.reference)}
                          className="rounded-md border border-error/40 px-3 py-1.5 font-semibold text-error hover:bg-error/5 disabled:cursor-wait disabled:opacity-60"
                        >
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      ))}
    </section>
  );
}
