import { useCallback, useEffect, useState } from "react";
import type { TastingView } from "../../shared/api-types.js";
import { ApiError, requestJson } from "../api/client.js";
import { Alert } from "../components/Alert.js";
import { TastingCard } from "../components/TastingCard.js";

type LoadState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; tastings: TastingView[] };

export function TastingsPage() {
  const [state, setState] = useState<LoadState>({ status: "loading" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const tastings = await requestJson<TastingView[]>("/api/tastings");
      setState({ status: "ready", tastings });
    } catch (error) {
      const message = error instanceof ApiError ? error.message : "Something went wrong. Please try again.";
      setState({ status: "error", message });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <section className="space-y-8">
      <header className="space-y-3 text-center sm:text-left">
        <h1 className="font-serif text-3xl text-wine sm:text-4xl">Wine tastings</h1>
        <p className="max-w-2xl text-ink/80">
          Join us at the cellar door for an evening or an afternoon with our wines. Choose a tasting and reserve
          your seats online.
        </p>
      </header>

      {state.status === "loading" && <p className="text-ink/70">Loading tastings…</p>}

      {state.status === "error" && (
        <div className="space-y-4">
          <Alert tone="error">{state.message}</Alert>
          <button
            type="button"
            onClick={() => void load()}
            className="rounded-lg border border-wine px-4 py-2 font-semibold text-wine hover:bg-wine/5"
          >
            Try again
          </button>
        </div>
      )}

      {state.status === "ready" && (
        <div className="grid gap-6 sm:grid-cols-2">
          {state.tastings.map((tasting) => (
            <TastingCard key={tasting.id} tasting={tasting} />
          ))}
        </div>
      )}
    </section>
  );
}
