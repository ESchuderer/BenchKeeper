import { afterEach, describe, expect, it, vi } from "vitest";
import { ApiError, requestJson } from "../../src/api/client.js";

afterEach(() => {
  vi.unstubAllGlobals();
});

function mockFetch(result: Response | Error) {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => {
      if (result instanceof Error) throw result;
      return result;
    }),
  );
}

function jsonResponse(body: unknown, status: number) {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
}

describe("requestJson", () => {
  it("returns the parsed JSON body for a successful response", async () => {
    mockFetch(jsonResponse({ ok: true }, 200));
    await expect(requestJson<{ ok: boolean }>("/api/x")).resolves.toEqual({ ok: true });
  });

  it("returns undefined for 204 No Content", async () => {
    mockFetch(new Response(null, { status: 204 }));
    await expect(requestJson("/api/x", { method: "DELETE" })).resolves.toBeUndefined();
  });

  it("throws an ApiError carrying the status, code, message and field errors", async () => {
    mockFetch(
      jsonResponse(
        {
          error: "validation_failed",
          message: "Please correct the highlighted fields.",
          fieldErrors: { guests: "Guests must be a whole number from 1 to 8." },
        },
        400,
      ),
    );
    const error = await requestJson("/api/x").catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({
      status: 400,
      code: "validation_failed",
      message: "Please correct the highlighted fields.",
      fieldErrors: { guests: "Guests must be a whole number from 1 to 8." },
    });
  });

  it("gives a usable error when the failure body is not JSON", async () => {
    mockFetch(new Response("<html>oops</html>", { status: 500 }));
    await expect(requestJson("/api/x")).rejects.toMatchObject({ status: 500, code: "unknown_error" });
  });

  it("reports network failures as network_error", async () => {
    mockFetch(new TypeError("Failed to fetch"));
    await expect(requestJson("/api/x")).rejects.toMatchObject({ code: "network_error" });
  });
});
