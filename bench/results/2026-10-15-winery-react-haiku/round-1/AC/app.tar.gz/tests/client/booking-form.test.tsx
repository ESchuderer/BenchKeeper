// @vitest-environment jsdom
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/vitest";
import { MemoryRouter, Route, Routes, useParams } from "react-router";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { BookingPage } from "../../src/pages/BookingPage.js";

const tasting = {
  id: "riesling-evening",
  title: "Riesling Evening",
  startsAt: "2026-11-06T18:00:00+01:00",
  pricePerGuest: 25,
  seats: 12,
  seatsLeft: 12,
  status: "open",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
}

function Confirmation() {
  const { reference } = useParams();
  return <p>Landed on confirmation {reference}</p>;
}

function renderBookingPage(path = "/tastings/riesling-evening/book") {
  render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/tastings/:tastingId/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<Confirmation />} />
      </Routes>
    </MemoryRouter>,
  );
}

// Serves the tasting, and answers the booking request with the given response.
function mockApi(booking: () => Promise<Response> | Response = () => json({}, 201), tastingBody = tasting) {
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    if (init?.method === "POST") return booking();
    return json(tastingBody);
  });
  vi.stubGlobal("fetch", fetchMock);
  return fetchMock;
}

const postCalls = (fetchMock: ReturnType<typeof mockApi>) =>
  fetchMock.mock.calls.filter(([, init]) => init?.method === "POST");

async function fillForm({ name = "Anna Weber", email = "anna@example.com", guests = "2" } = {}) {
  await userEvent.type(await screen.findByLabelText("Name"), name);
  await userEvent.type(screen.getByLabelText("Email"), email);
  await userEvent.clear(screen.getByLabelText("Guests"));
  await userEvent.type(screen.getByLabelText("Guests"), guests);
}

beforeEach(() => {
  vi.stubGlobal("fetch", vi.fn());
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("booking form", () => {
  it("shows the tasting and the Name, Email and Guests fields with a Book button", async () => {
    mockApi();
    renderBookingPage();
    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("shows each missing field's error beside it and sends nothing", async () => {
    const fetchMock = mockApi();
    renderBookingPage();
    await screen.findByLabelText("Name");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Please enter your name.")).toHaveAttribute("id", "name-error");
    expect(screen.getByText("Please enter your email address.")).toHaveAttribute("id", "email-error");
    expect(postCalls(fetchMock)).toHaveLength(0);
  });

  it.each([
    ["Email", "anna@example", "Please enter a valid email address, e.g. name@example.com."],
    ["Guests", "0", "Guests must be a whole number from 1 to 8."],
    ["Guests", "9", "Guests must be a whole number from 1 to 8."],
    ["Guests", "2.5", "Guests must be a whole number from 1 to 8."],
  ])("rejects %s = %s with a message next to the field", async (field, value, message) => {
    const fetchMock = mockApi();
    renderBookingPage();
    await screen.findByLabelText("Name");
    await fillForm(field === "Email" ? { email: value } : { guests: value });
    await userEvent.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText(message)).toBeInTheDocument();
    expect(screen.getByLabelText(field)).toHaveAttribute("aria-invalid", "true");
    expect(postCalls(fetchMock)).toHaveLength(0);
  });

  it("shows the server's seats message beside Guests", async () => {
    mockApi(() =>
      json(
        {
          error: "insufficient_seats",
          message: "Only 3 seats are left for this tasting.",
          seatsLeft: 3,
          fieldErrors: { guests: "Only 3 seats are left for this tasting." },
        },
        409,
      ),
    );
    renderBookingPage();
    await fillForm();
    await userEvent.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Only 3 seats are left for this tasting.")).toHaveAttribute("id", "guests-error");
  });

  it("disables the button while sending and sends one request for a double click", async () => {
    let finish: (response: Response) => void = () => {};
    const fetchMock = mockApi(() => new Promise<Response>((resolve) => (finish = resolve)));
    renderBookingPage();
    await fillForm();

    const button = screen.getByRole("button", { name: "Book" });
    await userEvent.dblClick(button);
    await waitFor(() => expect(button).toBeDisabled());
    expect(postCalls(fetchMock)).toHaveLength(1);

    finish(json({ reference: "KB-ABC234" }, 201));
  });

  it("goes to the confirmation page with the reference after a successful booking", async () => {
    mockApi(() => json({ reference: "KB-ABC234" }, 201));
    renderBookingPage();
    await fillForm();
    await userEvent.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Landed on confirmation KB-ABC234")).toBeInTheDocument();
  });

  it("shows Fully booked and no form for a tasting with no seats left", async () => {
    mockApi(undefined, { ...tasting, seatsLeft: 0, status: "fully_booked" });
    renderBookingPage();
    expect(await screen.findByText("Fully booked")).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).toBeNull();
  });

  it("shows Tasting not found for an unknown tasting", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => json({ error: "tasting_not_found", message: "This tasting does not exist." }, 404)));
    renderBookingPage("/tastings/unknown/book");
    expect(await screen.findByText("Tasting not found")).toBeInTheDocument();
  });
});
