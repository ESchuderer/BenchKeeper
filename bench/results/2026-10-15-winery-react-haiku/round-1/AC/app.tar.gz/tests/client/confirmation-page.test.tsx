// @vitest-environment jsdom
import { cleanup, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/vitest";
import { MemoryRouter, Route, Routes } from "react-router";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ConfirmationPage } from "../../src/pages/ConfirmationPage.js";

function renderAt(path: string) {
  render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
        <Route path="/" element={<p>Start page</p>} />
      </Routes>
    </MemoryRouter>,
  );
}

beforeEach(() => {
  vi.stubGlobal("fetch", vi.fn());
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("ConfirmationPage", () => {
  it("confirms the booking with its tasting, guests, total and reference", async () => {
    vi.mocked(fetch).mockResolvedValue(
      new Response(
        JSON.stringify({
          reference: "KB-ABC234",
          tastingTitle: "Riesling Evening",
          startsAt: "2026-11-06T18:00:00+01:00",
          guests: 2,
          pricePerGuest: 25,
          totalPrice: 50,
        }),
        { status: 200 },
      ),
    );
    renderAt("/bookings/KB-ABC234");

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(screen.getByText("Riesling Evening")).toBeInTheDocument();
    expect(screen.getByText("Fri, 6 Nov 2026, 18:00")).toBeInTheDocument();
    expect(screen.getByText("2 guests")).toBeInTheDocument();
    expect(screen.getByText("EUR 50")).toBeInTheDocument();
    expect(screen.getByText("KB-ABC234")).toBeInTheDocument();
    expect(fetch).toHaveBeenCalledWith("/api/bookings/KB-ABC234", expect.anything());
  });

  it("says so when the reference does not match a booking", async () => {
    vi.mocked(fetch).mockResolvedValue(
      new Response(JSON.stringify({ error: "booking_not_found", message: "No booking matches this reference." }), {
        status: 404,
      }),
    );
    renderAt("/bookings/KB-NOPE00");

    expect(await screen.findByRole("heading", { name: "Booking not found" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Back to the tastings" })).toHaveAttribute("href", "/");
  });
});
