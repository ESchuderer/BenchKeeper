// @vitest-environment jsdom
import { cleanup, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/vitest";
import { afterEach, describe, expect, it } from "vitest";
import { Alert } from "../../src/components/Alert.js";
import { Field } from "../../src/components/Field.js";

afterEach(cleanup);

describe("Field", () => {
  it("labels its input", () => {
    render(
      <Field id="guests" label="Guests">
        <input type="number" />
      </Field>,
    );
    expect(screen.getByLabelText("Guests")).toHaveAttribute("id", "guests");
  });

  it("shows the error text as an alert and links it to the input", () => {
    render(
      <Field id="guests" label="Guests" error="Guests must be a whole number from 1 to 8.">
        <input type="number" />
      </Field>,
    );
    const input = screen.getByLabelText("Guests");
    const error = screen.getByRole("alert");
    expect(error).toHaveTextContent("Guests must be a whole number from 1 to 8.");
    expect(error).toHaveAttribute("id", "guests-error");
    expect(input).toHaveAttribute("aria-invalid", "true");
    expect(input).toHaveAttribute("aria-describedby", "guests-error");
  });

  it("shows no alert and no invalid state without an error", () => {
    render(
      <Field id="name" label="Name">
        <input />
      </Field>,
    );
    expect(screen.queryByRole("alert")).toBeNull();
    expect(screen.getByLabelText("Name")).not.toHaveAttribute("aria-invalid");
  });
});

describe("Alert", () => {
  it("uses an alert role for errors", () => {
    render(<Alert tone="error">Something went wrong.</Alert>);
    expect(screen.getByRole("alert")).toHaveAttribute("data-tone", "error");
  });

  it("uses a status role for success", () => {
    render(<Alert tone="success">Booking confirmed</Alert>);
    expect(screen.getByRole("status")).toHaveAttribute("data-tone", "success");
  });
});
