import { describe, expect, it } from "vitest";
import { formatPrice, formatStartsAt, seatsLeftLabel } from "../../src/format.js";

describe("formatStartsAt", () => {
  it("shows the winery's local date and time", () => {
    expect(formatStartsAt("2026-11-06T18:00:00+01:00")).toBe("Fri, 6 Nov 2026, 18:00");
  });

  it("uses Berlin time for winter dates too", () => {
    expect(formatStartsAt("2026-12-05T17:00:00+01:00")).toBe("Sat, 5 Dec 2026, 17:00");
  });
});

describe("formatPrice", () => {
  it("formats whole euros", () => {
    expect(formatPrice(50)).toBe("EUR 50");
  });
});

describe("seatsLeftLabel", () => {
  it("uses the plural for other counts", () => {
    expect(seatsLeftLabel(12)).toBe("12 seats left");
    expect(seatsLeftLabel(0)).toBe("0 seats left");
  });

  it("uses the singular for exactly one seat", () => {
    expect(seatsLeftLabel(1)).toBe("1 seat left");
  });
});
