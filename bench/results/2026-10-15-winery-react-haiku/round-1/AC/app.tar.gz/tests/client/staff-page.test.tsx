// @vitest-environment jsdom
import { cleanup, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/vitest";
import { MemoryRouter } from "react-router";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { StaffTastingGroup } from "../../shared/api-types.js";
import { StaffPage } from "../../src/pages/StaffPage.js";

const groups: StaffTastingGroup[] = [
  {
    tasting: { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00:00+01:00", pricePerGuest: 25, seats: 12, seatsLeft: 10, status: "open" },
    bookings: [{ reference: "KB-ABC234", name: "Anna Weber", email: "anna@example.com", guests: 2, createdAt: "2026-10-14T10:02:11.000Z" }],
  },
  {
    tasting: { id: "winter-tasting", title: "Winter Tasting", startsAt: "2026-12-05T17:00:00+01:00", pricePerGuest: 28, seats: 10, seatsLeft: 10, status: "open" },
    bookings: [],
  },
];

const json = (body: unknown, status = 200) =>
  new Response(body === undefined ? null : JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });

// A tiny fake of the staff API. Signing in with the right password unlocks the bookings,
// and cancelling removes a booking from the list.
function fakeStaffApi({ cancelFails = false } = {}) {
  let signedIn = false;
  let current: StaffTastingGroup[] = structuredClone(groups);
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    if (url === "/api/staff/session" && init?.method === "POST") {
      if (JSON.parse(String(init.body)).password === "correct-horse") {
        signedIn = true;
        return json({ signedIn: true });
      }
      return json(
        { error: "invalid_password", message: "Incorrect password.", fieldErrors: { password: "Incorrect password." } },
        401,
      );
    }
    if (url === "/api/staff/bookings") {
      return signedIn ? json(current) : json({ error: "staff_sign_in_required", message: "Sign in to see bookings." }, 401);
    }
    if (url.startsWith("/api/staff/bookings/") && init?.method === "DELETE") {
      if (cancelFails) return json({ error: "internal_error", message: "Something went wrong. Please try again." }, 500);
      const reference = url.split("/").pop();
      current = current.map((group) => ({
        ...group,
        bookings: group.bookings.filter((booking) => booking.reference !== reference),
      }));
      return new Response(null, { status: 204 });
    }
    throw new Error(`Unexpected request ${init?.method ?? "GET"} ${url}`);
  });
  vi.stubGlobal("fetch", fetchMock);
  return fetchMock;
}

function renderStaffPage() {
  render(
    <MemoryRouter>
      <StaffPage />
    </MemoryRouter>,
  );
}

async function signInAsStaff() {
  await userEvent.type(await screen.findByLabelText("Password"), "correct-horse");
  await userEvent.click(screen.getByRole("button", { name: "Sign in" }));
}

beforeEach(() => {
  vi.stubGlobal("fetch", vi.fn());
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("StaffPage sign-in", () => {
  it("asks for the password until staff are signed in", async () => {
    fakeStaffApi();
    renderStaffPage();
    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
    expect(screen.queryByText("Anna Weber")).toBeNull();
  });

  it("shows 'Incorrect password.' beside the field for a wrong password", async () => {
    fakeStaffApi();
    renderStaffPage();
    await userEvent.type(await screen.findByLabelText("Password"), "wrong");
    await userEvent.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByText("Incorrect password.")).toHaveAttribute("id", "password-error");
    expect(screen.getByLabelText("Password")).toHaveAttribute("aria-invalid", "true");
  });

  it("shows bookings grouped by tasting after signing in", async () => {
    fakeStaffApi();
    renderStaffPage();
    await signInAsStaff();

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    expect(within(riesling).getByText("Anna Weber")).toBeInTheDocument();
    expect(within(riesling).getByText("anna@example.com")).toBeInTheDocument();
    expect(within(riesling).getByText("2")).toBeInTheDocument();
    expect(within(riesling).getByText("KB-ABC234")).toBeInTheDocument();
  });

  it("notes a tasting that has no bookings yet", async () => {
    fakeStaffApi();
    renderStaffPage();
    await signInAsStaff();

    const winter = await screen.findByRole("region", { name: "Winter Tasting" });
    expect(within(winter).getByText("No bookings yet")).toBeInTheDocument();
  });
});

describe("StaffPage cancelling", () => {
  it("removes the booking when Cancel is pressed and cancels by its reference", async () => {
    const fetchMock = fakeStaffApi();
    renderStaffPage();
    await signInAsStaff();

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    await userEvent.click(within(riesling).getByRole("button", { name: "Cancel" }));

    expect(await within(riesling).findByText("No bookings yet")).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledWith("/api/staff/bookings/KB-ABC234", expect.objectContaining({ method: "DELETE" }));
  });

  it("keeps the booking and shows an alert when cancelling fails", async () => {
    fakeStaffApi({ cancelFails: true });
    renderStaffPage();
    await signInAsStaff();

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    await userEvent.click(within(riesling).getByRole("button", { name: "Cancel" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("Something went wrong. Please try again.");
    expect(within(riesling).getByText("Anna Weber")).toBeInTheDocument();
  });
});
