// @vitest-environment jsdom
import { cleanup, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/vitest";
import { MemoryRouter } from "react-router";
import { afterEach, describe, expect, it } from "vitest";
import type { TastingView } from "../../shared/api-types.js";
import { TastingCard } from "../../src/components/TastingCard.js";

afterEach(cleanup);

const riesling: TastingView = {
  id: "riesling-evening",
  title: "Riesling Evening",
  startsAt: "2026-11-06T18:00:00+01:00",
  pricePerGuest: 25,
  seats: 12,
  seatsLeft: 12,
  status: "open",
};

function renderCard(tasting: TastingView) {
  render(
    <MemoryRouter>
      <TastingCard tasting={tasting} />
    </MemoryRouter>,
  );
}

describe("TastingCard", () => {
  it("shows the title, date, price and seats left", () => {
    renderCard(riesling);
    expect(screen.getByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByText("Fri, 6 Nov 2026, 18:00")).toBeInTheDocument();
    expect(screen.getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(screen.getByText("12 seats left")).toBeInTheDocument();
  });

  it("links to that tasting's booking form", () => {
    renderCard(riesling);
    expect(screen.getByRole("link", { name: "Book Riesling Evening" })).toHaveAttribute(
      "href",
      "/tastings/riesling-evening/book",
    );
  });

  it("shows a fully booked tasting without a booking link", () => {
    renderCard({ ...riesling, seatsLeft: 0, status: "fully_booked" });
    expect(screen.getByText("Fully booked")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /Book/ })).toBeNull();
  });
});
