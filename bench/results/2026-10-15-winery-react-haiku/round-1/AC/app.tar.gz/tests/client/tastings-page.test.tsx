// @vitest-environment jsdom
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/vitest";
import { MemoryRouter } from "react-router";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TastingsPage } from "../../src/pages/TastingsPage.js";

const tastings = [
  { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00:00+01:00", pricePerGuest: 25, seats: 12, seatsLeft: 12, status: "open" },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00:00+01:00", pricePerGuest: 32, seats: 8, seatsLeft: 0, status: "fully_booked" },
  { id: "winter-tasting", title: "Winter Tasting", startsAt: "2026-12-05T17:00:00+01:00", pricePerGuest: 28, seats: 10, seatsLeft: 10, status: "open" },
];

function renderPage() {
  render(
    <MemoryRouter>
      <TastingsPage />
    </MemoryRouter>,
  );
}

beforeEach(() => {
  vi.stubGlobal("fetch", vi.fn());
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("TastingsPage", () => {
  it("shows a loading message while the tastings load", () => {
    vi.mocked(fetch).mockReturnValue(new Promise(() => {}));
    renderPage();
    expect(screen.getByText("Loading tastings…")).toBeInTheDocument();
  });

  it("lists every tasting with its seats left", async () => {
    vi.mocked(fetch).mockResolvedValue(new Response(JSON.stringify(tastings), { status: 200 }));
    renderPage();
    expect(await screen.findByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();
    expect(screen.getByText("10 seats left")).toBeInTheDocument();
    expect(screen.getByText("Fully booked")).toBeInTheDocument();
  });

  it("shows an error with a retry button, and retries on click", async () => {
    vi.mocked(fetch)
      .mockRejectedValueOnce(new TypeError("Failed to fetch"))
      .mockResolvedValueOnce(new Response(JSON.stringify(tastings), { status: 200 }));
    renderPage();

    expect(await screen.findByRole("alert")).toHaveTextContent("We could not reach the server");
    await userEvent.click(screen.getByRole("button", { name: "Try again" }));
    await waitFor(() => expect(screen.getByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument());
    expect(fetch).toHaveBeenCalledTimes(2);
  });
});
