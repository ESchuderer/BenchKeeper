import { test, expect, type Page } from "@playwright/test";

const STAFF_PASSWORD = "e2e-staff-password";

// The tests share one bookings file, so they run in order and build on each other.
test.describe.configure({ mode: "serial" });

// The card for one tasting on the start page. Scoped checks avoid matching another card with the same count.
function tastingCard(page: Page, title: string) {
  return page.getByRole("article").filter({ has: page.getByRole("heading", { name: title }) });
}

async function bookTasting(page: Page, tasting: string, name: string, email: string, guests: string) {
  await page.goto("/");
  await page.getByRole("link", { name: `Book ${tasting}` }).click();
  await page.getByLabel("Name").fill(name);
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Guests").fill(guests);
  await page.getByRole("button", { name: "Book", exact: true }).click();
}

test("Story 1: the start page lists the three tastings with seats left", async ({ page }) => {
  await page.goto("/");
  for (const title of ["Riesling Evening", "Red Wine Cellar Tour", "Winter Tasting"]) {
    await expect(page.getByRole("heading", { name: title })).toBeVisible();
  }
  await expect(page.getByText("EUR 25 per guest")).toBeVisible();
  await expect(page.getByText("12 seats left")).toBeVisible();
  await expect(page.getByText("8 seats left")).toBeVisible();
  await expect(page.getByText("10 seats left")).toBeVisible();
  await expect(page.getByRole("link", { name: "Book Riesling Evening" })).toBeVisible();
});

test("Story 2: the booking form rejects invalid input next to each field", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Book Riesling Evening" }).click();
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByText("Please enter your name.")).toBeVisible();
  await expect(page.getByText("Please enter your email address.")).toBeVisible();

  await page.getByLabel("Email").fill("anna@example");
  await page.getByLabel("Guests").fill("0");
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByText("Please enter a valid email address, e.g. name@example.com.")).toBeVisible();
  await expect(page.getByText("Guests must be a whole number from 1 to 8.")).toBeVisible();
});

test("Story 2: a valid booking shows the confirmation and reduces the seats left", async ({ page }) => {
  await bookTasting(page, "Riesling Evening", "Anna Weber", "anna@example.com", "2");
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  await expect(page.getByText("Riesling Evening")).toBeVisible();
  await expect(page.getByText("2 guests")).toBeVisible();
  await expect(page.getByText("EUR 50")).toBeVisible();
  await expect(page.getByText(/KB-[A-Z2-9]{6}/)).toBeVisible();

  await page.goto("/");
  await expect(tastingCard(page, "Riesling Evening").getByText("10 seats left")).toBeVisible();
});

test("Story 2: the server refuses more guests than seats left", async ({ page }) => {
  await bookTasting(page, "Red Wine Cellar Tour", "Ben Koch", "ben@example.com", "5");
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await bookTasting(page, "Red Wine Cellar Tour", "Carla Neu", "carla@example.com", "4");
  await expect(page.getByText("Only 3 seats are left for this tasting.")).toBeVisible();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toHaveCount(0);

  await page.goto("/");
  await expect(tastingCard(page, "Red Wine Cellar Tour").getByText("3 seats left")).toBeVisible();
});

test("Story 1: a fully booked tasting has no Book link", async ({ page }) => {
  await bookTasting(page, "Red Wine Cellar Tour", "Dora Fels", "dora@example.com", "3");
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await page.goto("/");
  await expect(page.getByText("Fully booked")).toBeVisible();
  await expect(page.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toHaveCount(0);
});

test("Story 3: staff sign in with the password and see bookings grouped by tasting", async ({ page }) => {
  await page.goto("/staff");
  await expect(page.getByLabel("Password")).toBeVisible();
  await expect(page.getByRole("button", { name: "Sign in" })).toBeVisible();

  await page.getByLabel("Password").fill("wrong-password");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByText("Incorrect password.")).toBeVisible();

  await page.getByLabel("Password").fill(STAFF_PASSWORD);
  await page.getByRole("button", { name: "Sign in" }).click();
  const riesling = page.getByRole("region", { name: "Riesling Evening" });
  await expect(riesling).toBeVisible();
  await expect(riesling.getByText("Anna Weber")).toBeVisible();
  await expect(riesling.getByText("anna@example.com")).toBeVisible();
  await expect(riesling.getByText(/KB-[A-Z2-9]{6}/)).toBeVisible();
});

test("Story 4: cancelling a booking frees its seats and ends its confirmation", async ({ page }) => {
  await page.goto("/staff");
  await page.getByLabel("Password").fill(STAFF_PASSWORD);
  await page.getByRole("button", { name: "Sign in" }).click();

  const riesling = page.getByRole("region", { name: "Riesling Evening" });
  await riesling.getByRole("row", { name: /Anna Weber/ }).getByRole("button", { name: "Cancel" }).click();
  await expect(riesling.getByText("Anna Weber")).toHaveCount(0);

  await page.goto("/");
  await expect(tastingCard(page, "Riesling Evening").getByText("12 seats left")).toBeVisible();
});

test("Phone width: the start page and booking form fit a 375 px screen", async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 812 });
  for (const path of ["/", "/tastings/winter-tasting/book"]) {
    await page.goto(path);
    await expect(page.getByRole("heading").first()).toBeVisible();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    expect(overflow, `horizontal overflow on ${path}`).toBeLessThanOrEqual(0);
  }
});
