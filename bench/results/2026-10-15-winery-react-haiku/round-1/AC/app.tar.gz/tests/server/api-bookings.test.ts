import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../../server/app.js";
import { createBookingService } from "../../server/booking-service.js";
import { createBookingStore } from "../../server/booking-store.js";
import { createStaffAuth } from "../../server/staff-auth.js";

function setup() {
  const store = createBookingStore();
  const bookingService = createBookingService({ store, now: () => Date.parse("2026-10-14T10:00:00Z") });
  const app = createApp({
    bookingService,
    staffAuth: createStaffAuth({ password: "correct-horse" }),
    clientDir: "/nonexistent-client-dir",
  });
  return { app, store };
}

const valid = { tastingId: "riesling-evening", name: "Anna Weber", email: "anna@example.com", guests: 2 };

describe("POST /api/bookings", () => {
  it("returns 201 with the reference and totals", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/bookings").send(valid);
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      guests: 2,
      pricePerGuest: 25,
      totalPrice: 50,
      name: "Anna Weber",
      email: "anna@example.com",
    });
    expect(res.body.reference).toMatch(/^KB-/);
  });

  it("returns field errors for every invalid field at once", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/bookings").send({ ...valid, name: " ", email: "anna@example", guests: 9 });
    expect(res.status).toBe(400);
    expect(res.body).toMatchObject({
      error: "validation_failed",
      fieldErrors: {
        name: "Please enter your name.",
        email: "Please enter a valid email address, e.g. name@example.com.",
        guests: "Guests must be a whole number from 1 to 8.",
      },
    });
  });

  it("rejects guests sent as text", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/bookings").send({ ...valid, guests: "2" });
    expect(res.status).toBe(400);
    expect(res.body.fieldErrors.guests).toBe("Guests must be a whole number from 1 to 8.");
  });

  it("returns 409 insufficient_seats with the seats left", async () => {
    const { app } = setup();
    await request(app).post("/api/bookings").send({ ...valid, tastingId: "red-wine-cellar-tour", guests: 5 });
    const res = await request(app).post("/api/bookings").send({ ...valid, tastingId: "red-wine-cellar-tour", guests: 4 });
    expect(res.status).toBe(409);
    expect(res.body).toMatchObject({
      error: "insufficient_seats",
      seatsLeft: 3,
      fieldErrors: { guests: "Only 3 seats are left for this tasting." },
    });
  });

  it("returns 409 fully_booked when no seats are left", async () => {
    const { app } = setup();
    await request(app).post("/api/bookings").send({ ...valid, tastingId: "red-wine-cellar-tour", guests: 8 });
    const res = await request(app).post("/api/bookings").send({ ...valid, tastingId: "red-wine-cellar-tour", guests: 1 });
    expect(res.status).toBe(409);
    expect(res.body).toMatchObject({ error: "fully_booked", message: "This tasting is fully booked." });
  });

  it("returns 404 for an unknown tasting", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/bookings").send({ ...valid, tastingId: "unknown" });
    expect(res.status).toBe(404);
    expect(res.body.error).toBe("tasting_not_found");
  });

  it("never oversells when many requests arrive at the same time", async () => {
    const { app, store } = setup();
    const attempts = Array.from({ length: 20 }, () =>
      request(app).post("/api/bookings").send({ ...valid, tastingId: "red-wine-cellar-tour", guests: 1 }),
    );
    const responses = await Promise.all(attempts);
    const accepted = responses.filter((res) => res.status === 201);
    expect(accepted).toHaveLength(8);
    expect(responses.filter((res) => res.status === 409)).toHaveLength(12);
    expect(store.list().reduce((sum, booking) => sum + booking.guests, 0)).toBe(8);
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the confirmation without the guest's name or email", async () => {
    const { app } = setup();
    const created = await request(app).post("/api/bookings").send(valid);
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      reference: created.body.reference,
      tastingTitle: "Riesling Evening",
      startsAt: "2026-11-06T18:00:00+01:00",
      guests: 2,
      pricePerGuest: 25,
      totalPrice: 50,
    });
  });

  it("returns 404 booking_not_found for an unknown reference", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/bookings/KB-NOPE00");
    expect(res.status).toBe(404);
    expect(res.body.error).toBe("booking_not_found");
  });
});
