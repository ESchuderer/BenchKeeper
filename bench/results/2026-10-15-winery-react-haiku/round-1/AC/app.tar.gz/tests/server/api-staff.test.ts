import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../../server/app.js";
import { createBookingService } from "../../server/booking-service.js";
import { createBookingStore, type StoredBooking } from "../../server/booking-store.js";
import { createStaffAuth, STAFF_SESSION_MS } from "../../server/staff-auth.js";

const START = Date.parse("2026-10-14T10:00:00Z");

function setup({ password = "correct-horse", bookings = [] as StoredBooking[] } = {}) {
  let now = START;
  const store = createBookingStore();
  bookings.forEach((booking) => store.add(booking));
  const app = createApp({
    bookingService: createBookingService({ store, now: () => now }),
    staffAuth: createStaffAuth({ password, now: () => now }),
    clientDir: "/nonexistent-client-dir",
  });
  return {
    app,
    store,
    advance: (ms: number) => {
      now += ms;
    },
  };
}

const booking = (overrides: Partial<StoredBooking>): StoredBooking => ({
  reference: "KB-TEST01",
  tastingId: "riesling-evening",
  name: "Anna Weber",
  email: "anna@example.com",
  guests: 2,
  createdAt: "2026-10-14T10:02:11.000Z",
  ...overrides,
});

async function signIn(app: ReturnType<typeof setup>["app"], password = "correct-horse") {
  const res = await request(app).post("/api/staff/session").send({ password });
  const cookie = res.headers["set-cookie"]?.[0] ?? "";
  return { res, cookie: cookie.split(";")[0] };
}

describe("POST /api/staff/session", () => {
  it("signs in with the right password and sets a locked-down session cookie", async () => {
    const { app } = setup();
    const { res, cookie } = await signIn(app);
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ signedIn: true });
    expect(cookie).toMatch(/^kb_staff=[A-Za-z0-9_-]{43}$/);
    const setCookie = res.headers["set-cookie"]?.[0] ?? "";
    expect(setCookie).toContain("HttpOnly");
    expect(setCookie).toContain("SameSite=Strict");
    expect(setCookie).toContain("Path=/");
    expect(setCookie).toContain("Max-Age=28800");
  });

  it("refuses a wrong password with a message for the password field and no cookie", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/staff/session").send({ password: "wrong" });
    expect(res.status).toBe(401);
    expect(res.body).toMatchObject({
      error: "invalid_password",
      fieldErrors: { password: "Incorrect password." },
    });
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("refuses an empty password with a 400 and the field message", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/staff/session").send({ password: "" });
    expect(res.status).toBe(400);
    expect(res.body.fieldErrors).toEqual({ password: "Enter the staff password." });
  });

  it("refuses every password when no staff password is configured", async () => {
    const { app } = setup({ password: undefined as unknown as string });
    const res = await request(app).post("/api/staff/session").send({ password: "anything" });
    expect(res.status).toBe(401);
  });
});

describe("GET /api/staff/bookings", () => {
  it("requires a staff session", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/staff/bookings");
    expect(res.status).toBe(401);
    expect(res.body.error).toBe("staff_sign_in_required");
  });

  it("rejects an unknown session cookie", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/staff/bookings").set("Cookie", "kb_staff=not-a-real-token");
    expect(res.status).toBe(401);
  });

  it("lists active bookings grouped by tasting, including tastings with no bookings", async () => {
    const { app } = setup({
      bookings: [
        booking({ reference: "KB-AAA111", name: "Anna Weber", email: "anna@example.com", guests: 2 }),
        booking({ reference: "KB-BBB222", tastingId: "red-wine-cellar-tour", name: "Ben Koch", email: "ben@example.com", guests: 5 }),
      ],
    });
    const { cookie } = await signIn(app);
    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);

    expect(res.status).toBe(200);
    expect(res.body.map((group: { tasting: { id: string } }) => group.tasting.id)).toEqual([
      "riesling-evening",
      "red-wine-cellar-tour",
      "winter-tasting",
    ]);
    expect(res.body[0]).toEqual({
      tasting: expect.objectContaining({ id: "riesling-evening", seatsLeft: 10 }),
      bookings: [
        {
          reference: "KB-AAA111",
          name: "Anna Weber",
          email: "anna@example.com",
          guests: 2,
          createdAt: "2026-10-14T10:02:11.000Z",
        },
      ],
    });
    expect(res.body[2].bookings).toEqual([]);
  });

  it("ends the session after 8 hours", async () => {
    const { app, advance } = setup();
    const { cookie } = await signIn(app);
    advance(STAFF_SESSION_MS - 1);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(200);
    advance(1);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(401);
  });
});

describe("DELETE /api/staff/bookings/:reference", () => {
  it("cancels the booking with 204 and frees its seats on the public tasting list", async () => {
    const { app } = setup();
    const created = await request(app).post("/api/bookings").send({
      tastingId: "winter-tasting",
      name: "Anna Weber",
      email: "anna@example.com",
      guests: 4,
    });
    const { cookie } = await signIn(app);

    const res = await request(app).delete(`/api/staff/bookings/${created.body.reference}`).set("Cookie", cookie);
    expect(res.status).toBe(204);
    expect((await request(app).get("/api/tastings/winter-tasting")).body.seatsLeft).toBe(10);
  });

  it("requires a staff session and keeps the booking", async () => {
    const { app, store } = setup({ bookings: [booking({ reference: "KB-KEEP01", tastingId: "winter-tasting" })] });
    const res = await request(app).delete("/api/staff/bookings/KB-KEEP01");
    expect(res.status).toBe(401);
    expect(res.body.error).toBe("staff_sign_in_required");
    expect(store.findByReference("KB-KEEP01")).toBeDefined();
  });

  it("returns 404 for an unknown reference", async () => {
    const { app } = setup();
    const { cookie } = await signIn(app);
    const res = await request(app).delete("/api/staff/bookings/KB-NOPE00").set("Cookie", cookie);
    expect(res.status).toBe(404);
    expect(res.body.error).toBe("booking_not_found");
  });

  it("ends the guest's confirmation link once cancelled", async () => {
    const { app } = setup({ bookings: [booking({ reference: "KB-GONE01", tastingId: "winter-tasting" })] });
    const { cookie } = await signIn(app);
    expect((await request(app).get("/api/bookings/KB-GONE01")).status).toBe(200);

    await request(app).delete("/api/staff/bookings/KB-GONE01").set("Cookie", cookie);
    expect((await request(app).get("/api/bookings/KB-GONE01")).status).toBe(404);
  });
});
