import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../../server/app.js";
import { createBookingService } from "../../server/booking-service.js";
import { createBookingStore, type StoredBooking } from "../../server/booking-store.js";
import { createStaffAuth } from "../../server/staff-auth.js";

const NOW_BEFORE_ALL_TASTINGS = Date.parse("2026-10-14T10:00:00Z");

function setup({ now = NOW_BEFORE_ALL_TASTINGS, bookings = [] as StoredBooking[] } = {}) {
  const store = createBookingStore();
  bookings.forEach((booking) => store.add(booking));
  const bookingService = createBookingService({ store, now: () => now });
  const app = createApp({
    bookingService,
    staffAuth: createStaffAuth({ password: "correct-horse" }),
    clientDir: "/nonexistent-client-dir",
  });
  return { app, store };
}

const booking = (overrides: Partial<StoredBooking>): StoredBooking => ({
  reference: "KB-TEST01",
  tastingId: "riesling-evening",
  name: "Anna Weber",
  email: "anna@example.com",
  guests: 1,
  createdAt: "2026-10-14T10:00:00.000Z",
  ...overrides,
});

describe("GET /api/tastings", () => {
  it("lists the three tastings with all seats free", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/tastings");
    expect(res.status).toBe(200);
    expect(res.body.map((t: { id: string }) => t.id)).toEqual([
      "riesling-evening",
      "red-wine-cellar-tour",
      "winter-tasting",
    ]);
    expect(res.body[0]).toEqual({
      id: "riesling-evening",
      title: "Riesling Evening",
      startsAt: "2026-11-06T18:00:00+01:00",
      pricePerGuest: 25,
      seats: 12,
      seatsLeft: 12,
      status: "open",
    });
  });

  it("subtracts the guests of active bookings from the seats left", async () => {
    const { app } = setup({ bookings: [booking({ guests: 3 }), booking({ reference: "KB-TEST02", guests: 2 })] });
    const res = await request(app).get("/api/tastings");
    expect(res.body[0].seatsLeft).toBe(7);
    expect(res.body[1].seatsLeft).toBe(8);
  });

  it("marks a tasting fully booked when no seats are left", async () => {
    const { app } = setup({ bookings: [booking({ tastingId: "red-wine-cellar-tour", guests: 8 })] });
    const res = await request(app).get("/api/tastings");
    expect(res.body[1]).toMatchObject({ seatsLeft: 0, status: "fully_booked" });
  });

  it("marks tastings that have already started as fully booked", async () => {
    const { app } = setup({ now: Date.parse("2026-12-06T10:00:00Z") });
    const res = await request(app).get("/api/tastings");
    expect(res.body.every((t: { status: string }) => t.status === "fully_booked")).toBe(true);
  });
});

describe("GET /api/tastings/:id", () => {
  it("returns one tasting", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/tastings/winter-tasting");
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ id: "winter-tasting", title: "Winter Tasting", seatsLeft: 10 });
  });

  it("returns 404 for an unknown tasting", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/tastings/unknown");
    expect(res.status).toBe(404);
    expect(res.body).toMatchObject({ error: "tasting_not_found" });
  });
});
