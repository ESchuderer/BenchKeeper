import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import request from "supertest";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createApp } from "../../server/app.js";
import { createStaffAuth } from "../../server/staff-auth.js";

let clientDir: string;
let app: ReturnType<typeof createApp>;

beforeAll(async () => {
  clientDir = await mkdtemp(join(tmpdir(), "kb-client-"));
  await writeFile(join(clientDir, "index.html"), "<html><body>KB app shell</body></html>");
  app = createApp({
    bookingService: {} as never, // routes are not exercised by this test
    staffAuth: createStaffAuth({ password: "correct-horse" }),
    clientDir,
  });
});

afterAll(async () => {
  await rm(clientDir, { recursive: true, force: true });
});

describe("API error handling", () => {
  it("answers unknown API paths with a JSON 404", async () => {
    const res = await request(app).get("/api/nope");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "not_found" });
  });

  it("rejects request bodies that are not JSON with 415", async () => {
    const res = await request(app).post("/api/bookings").set("Content-Type", "text/plain").send("hello");
    expect(res.status).toBe(415);
    expect(res.body.error).toBe("unsupported_media_type");
  });

  it("rejects malformed JSON with a JSON 400", async () => {
    const res = await request(app).post("/api/bookings").set("Content-Type", "application/json").send("{bad");
    expect(res.status).toBe(400);
    expect(res.body.error).toBe("invalid_json");
  });
});

describe("single-page app", () => {
  it("serves index.html for client routes", async () => {
    const res = await request(app).get("/bookings/KB-ABC234");
    expect(res.status).toBe(200);
    expect(res.text).toContain("KB app shell");
  });

  it("serves index.html for the staff page", async () => {
    const res = await request(app).get("/staff");
    expect(res.status).toBe(200);
    expect(res.text).toContain("KB app shell");
  });
});

describe("client errors are reported as client errors", () => {
  it("answers a malformed URL-encoded path parameter with 400, not 500", async () => {
    const res = await request(app).get("/api/tastings/%E0%A4%A");
    expect(res.status).toBe(400);
    expect(res.body.error).toBe("bad_request");
  });

  it("answers an unsupported charset on a JSON body with 415, not 500", async () => {
    const res = await request(app)
      .post("/api/bookings")
      .set("Content-Type", "application/json; charset=bogus-x")
      .send("{}");
    expect(res.status).toBe(415);
    expect(res.body.error).toBe("unsupported_media_type");
  });
});
