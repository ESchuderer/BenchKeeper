import { describe, expect, it } from "vitest";
import { bookingRequestSchema, staffSignInSchema } from "../../shared/booking-schema.js";

const valid = { tastingId: "riesling-evening", name: "Anna Weber", email: "anna@example.com", guests: 2 };

// Every message the schema reports for one field.
function messagesFor(input: unknown, field: string): string[] {
  const result = bookingRequestSchema.safeParse(input);
  if (result.success) return [];
  return result.error.issues.filter((issue) => issue.path[0] === field).map((issue) => issue.message);
}

describe("bookingRequestSchema", () => {
  it("accepts a valid request", () => {
    expect(bookingRequestSchema.parse(valid)).toEqual(valid);
  });

  it("trims name and email before checking them", () => {
    const parsed = bookingRequestSchema.parse({ ...valid, name: "  Anna Weber ", email: " anna@example.com " });
    expect(parsed.name).toBe("Anna Weber");
    expect(parsed.email).toBe("anna@example.com");
  });

  it("requires a tasting", () => {
    expect(messagesFor({ ...valid, tastingId: "" }, "tastingId")).toContain("Choose a tasting.");
  });

  it("requires a name that is not blank", () => {
    expect(messagesFor({ ...valid, name: "   " }, "name")).toContain("Please enter your name.");
  });

  it("limits the name to 100 characters", () => {
    expect(messagesFor({ ...valid, name: "a".repeat(101) }, "name")).toContain("Name must be at most 100 characters.");
    expect(messagesFor({ ...valid, name: "a".repeat(100) }, "name")).toEqual([]);
  });

  it("requires an email address", () => {
    expect(messagesFor({ ...valid, email: "" }, "email")).toContain("Please enter your email address.");
  });

  it("rejects an email address that is not valid", () => {
    expect(messagesFor({ ...valid, email: "anna@example" }, "email")).toContain(
      "Please enter a valid email address, e.g. name@example.com.",
    );
  });

  it("limits the email address to 254 characters", () => {
    const longEmail = `${"a".repeat(243)}@example.com`;
    expect(longEmail).toHaveLength(255);
    expect(messagesFor({ ...valid, email: longEmail }, "email")).toContain("Email must be at most 254 characters.");
  });

  it.each([1, 8])("accepts %i guest(s)", (guests) => {
    expect(messagesFor({ ...valid, guests }, "guests")).toEqual([]);
  });

  it.each([0, 9, 2.5, "two", "", NaN, null])("rejects guests %j with the guest message", (guests) => {
    expect(messagesFor({ ...valid, guests }, "guests")).toContain("Guests must be a whole number from 1 to 8.");
  });
});

describe("staffSignInSchema", () => {
  it("requires a password", () => {
    const result = staffSignInSchema.safeParse({ password: "" });
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.issues[0]?.message).toBe("Enter the staff password.");
  });

  it("accepts any non-empty password", () => {
    expect(staffSignInSchema.safeParse({ password: "x" }).success).toBe(true);
  });
});
