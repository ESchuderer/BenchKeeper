import { describe, expect, it } from "vitest";
import { createBookingService } from "../../server/booking-service.js";
import { createBookingStore } from "../../server/booking-store.js";

const BEFORE_TASTINGS = Date.parse("2026-10-14T10:00:00Z");

function setup({ now = BEFORE_TASTINGS, tastings }: { now?: number; tastings?: Parameters<typeof createBookingService>[0]["tastings"] } = {}) {
  const store = createBookingStore();
  const service = createBookingService({ store, now: () => now, tastings });
  return { store, service };
}

const request = (overrides: Partial<{ tastingId: string; name: string; email: string; guests: number }> = {}) => ({
  tastingId: "riesling-evening",
  name: "Anna Weber",
  email: "anna@example.com",
  guests: 2,
  ...overrides,
});

describe("book", () => {
  it("records the booking with a reference, the totals, and reduces the seats left", () => {
    const { service, store } = setup();
    const result = service.book(request());

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.booking).toMatchObject({
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      startsAt: "2026-11-06T18:00:00+01:00",
      guests: 2,
      pricePerGuest: 25,
      totalPrice: 50,
      name: "Anna Weber",
      email: "anna@example.com",
    });
    expect(result.booking.reference).toMatch(/^KB-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}$/);
    expect(service.getTasting("riesling-evening")?.seatsLeft).toBe(10);
    expect(store.list()).toHaveLength(1);
  });

  it("gives every booking its own reference", () => {
    const { service } = setup({
      tastings: [{ id: "big", title: "Big", startsAt: "2026-11-06T18:00:00+01:00", pricePerGuest: 1, seats: 500 }],
    });
    const refs = new Set<string>();
    for (let i = 0; i < 300; i++) {
      const result = service.book(request({ tastingId: "big", guests: 1 }));
      if (result.ok) refs.add(result.booking.reference);
    }
    expect(refs.size).toBe(300);
  });

  it("refuses more guests than seats left and changes nothing", () => {
    const { service, store } = setup();
    expect(service.book(request({ tastingId: "red-wine-cellar-tour", guests: 5 })).ok).toBe(true);

    expect(service.book(request({ tastingId: "red-wine-cellar-tour", guests: 4 }))).toEqual({
      ok: false,
      error: "insufficient_seats",
      seatsLeft: 3,
    });
    expect(service.getTasting("red-wine-cellar-tour")?.seatsLeft).toBe(3);
    expect(store.list()).toHaveLength(1);
  });

  it("accepts a booking for exactly the seats left", () => {
    const { service } = setup();
    const result = service.book(request({ tastingId: "red-wine-cellar-tour", guests: 8 }));
    expect(result.ok).toBe(true);
    expect(service.getTasting("red-wine-cellar-tour")).toMatchObject({ seatsLeft: 0, status: "fully_booked" });
  });

  it("refuses any booking on a fully booked tasting", () => {
    const { service } = setup();
    service.book(request({ tastingId: "red-wine-cellar-tour", guests: 8 }));
    expect(service.book(request({ tastingId: "red-wine-cellar-tour", guests: 1 }))).toEqual({
      ok: false,
      error: "fully_booked",
    });
  });

  it("refuses bookings once the tasting has started", () => {
    const { service } = setup({ now: Date.parse("2026-11-06T18:00:00+01:00") });
    expect(service.book(request())).toEqual({ ok: false, error: "fully_booked" });
  });

  it("reports an unknown tasting", () => {
    const { service } = setup();
    expect(service.book(request({ tastingId: "nope" }))).toEqual({ ok: false, error: "tasting_not_found" });
  });

  it("never sells more seats than the tasting has across sequential requests", () => {
    const { service } = setup();
    const outcomes = [3, 3, 3].map((guests) => service.book(request({ tastingId: "red-wine-cellar-tour", guests })));
    expect(outcomes.map((o) => o.ok)).toEqual([true, true, false]);
    expect(outcomes[2]).toEqual({ ok: false, error: "insufficient_seats", seatsLeft: 2 });
    expect(service.getTasting("red-wine-cellar-tour")?.seatsLeft).toBe(2);
  });
});

describe("getConfirmation", () => {
  it("returns the tasting, guests and total, but not the guest's name or email", () => {
    const { service } = setup();
    const result = service.book(request({ guests: 2 }));
    if (!result.ok) throw new Error("booking should succeed");

    expect(service.getConfirmation(result.booking.reference)).toEqual({
      reference: result.booking.reference,
      tastingTitle: "Riesling Evening",
      startsAt: "2026-11-06T18:00:00+01:00",
      guests: 2,
      pricePerGuest: 25,
      totalPrice: 50,
    });
  });

  it("returns undefined for an unknown reference", () => {
    const { service } = setup();
    expect(service.getConfirmation("KB-NOPE00")).toBeUndefined();
  });
});

describe("cancel", () => {
  it("removes the booking and frees its seats", () => {
    const { service } = setup();
    const result = service.book(request({ tastingId: "winter-tasting", guests: 4 }));
    if (!result.ok) throw new Error("booking should succeed");
    expect(service.getTasting("winter-tasting")?.seatsLeft).toBe(6);

    expect(service.cancel(result.booking.reference)).toBe(true);
    expect(service.getTasting("winter-tasting")?.seatsLeft).toBe(10);
    expect(service.getConfirmation(result.booking.reference)).toBeUndefined();
  });

  it("returns false for an unknown reference", () => {
    const { service } = setup();
    expect(service.cancel("KB-NOPE00")).toBe(false);
  });

  it("lets the freed seats be booked again", () => {
    const { service } = setup();
    const first = service.book(request({ tastingId: "red-wine-cellar-tour", guests: 8 }));
    if (!first.ok) throw new Error("booking should succeed");
    service.cancel(first.booking.reference);

    expect(service.book(request({ tastingId: "red-wine-cellar-tour", guests: 8 })).ok).toBe(true);
  });
});
