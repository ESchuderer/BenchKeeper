import { statSync } from "node:fs";
import { mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { createBookingStore } from "../../server/booking-store.js";

const booking = {
  reference: "KB-ABC234",
  tastingId: "riesling-evening",
  name: "Anna Weber",
  email: "anna@example.com",
  guests: 2,
  createdAt: "2026-10-14T10:02:11.000Z",
};

let dir: string;

beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), "kb-store-"));
});

afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

describe("in-memory store", () => {
  it("adds, finds, lists and removes bookings", () => {
    const store = createBookingStore();
    store.add(booking);
    expect(store.findByReference("KB-ABC234")).toEqual(booking);
    expect(store.list()).toEqual([booking]);
    expect(store.remove("KB-ABC234")).toBe(true);
    expect(store.findByReference("KB-ABC234")).toBeUndefined();
    expect(store.remove("KB-ABC234")).toBe(false);
  });
});

describe("file-backed store", () => {
  it("starts empty when the file does not exist", () => {
    const store = createBookingStore({ filePath: join(dir, "missing.json") });
    expect(store.list()).toEqual([]);
  });

  it("keeps bookings across instances that use the same file", () => {
    const filePath = join(dir, "bookings.json");
    createBookingStore({ filePath }).add(booking);
    expect(createBookingStore({ filePath }).list()).toEqual([booking]);
  });

  it("writes the documented JSON shape, creating the folder if needed", async () => {
    const filePath = join(dir, "data", "bookings.json");
    createBookingStore({ filePath }).add(booking);
    expect(JSON.parse(await readFile(filePath, "utf8"))).toEqual({ version: 1, bookings: [booking] });
  });

  it("persists removals", () => {
    const filePath = join(dir, "bookings.json");
    const store = createBookingStore({ filePath });
    store.add(booking);
    store.remove("KB-ABC234");
    expect(createBookingStore({ filePath }).list()).toEqual([]);
  });

  it("refuses to start on a malformed file and names it in the error", async () => {
    const filePath = join(dir, "bookings.json");
    await writeFile(filePath, "{not json");
    expect(() => createBookingStore({ filePath })).toThrow(/bookings\.json/);
  });

  it("leaves no temporary files behind after a write", async () => {
    const filePath = join(dir, "bookings.json");
    createBookingStore({ filePath }).add(booking);
    expect(await readdir(dir)).toEqual(["bookings.json"]);
  });
});

describe("file permissions", () => {
  it("keeps the bookings file private to its owner", () => {
    const filePath = join(dir, "bookings.json");
    createBookingStore({ filePath }).add(booking);
    expect(statSync(filePath).mode & 0o777).toBe(0o600);
  });
});
