import { describe, expect, it } from "vitest";
import { createStaffAuth } from "../../server/staff-auth.js";

const EIGHT_HOURS_MS = 8 * 60 * 60 * 1000;

function fakeClock(start = Date.parse("2026-10-14T10:00:00Z")) {
  let current = start;
  return {
    now: () => current,
    advance: (ms: number) => {
      current += ms;
    },
  };
}

describe("staff password check", () => {
  it("accepts the configured password and returns an unguessable token", () => {
    const auth = createStaffAuth({ password: "correct-horse", now: fakeClock().now });
    const token = auth.signIn("correct-horse");
    expect(token).toMatch(/^[A-Za-z0-9_-]{43}$/); // 32 random bytes, base64url
    expect(auth.verify(token)).toBe(true);
  });

  it.each(["wrong", "", "correct-horse ", "Correct-horse", "correct-hors"])("refuses the password %j", (attempt) => {
    const auth = createStaffAuth({ password: "correct-horse", now: fakeClock().now });
    expect(auth.signIn(attempt)).toBeUndefined();
  });

  it("refuses every attempt when no password is configured", () => {
    const auth = createStaffAuth({ password: undefined, now: fakeClock().now });
    expect(auth.configured).toBe(false);
    expect(auth.signIn("")).toBeUndefined();
    expect(auth.signIn("anything")).toBeUndefined();
  });

  it("issues a different token on every sign-in", () => {
    const auth = createStaffAuth({ password: "correct-horse", now: fakeClock().now });
    expect(auth.signIn("correct-horse")).not.toBe(auth.signIn("correct-horse"));
  });
});

describe("staff sessions", () => {
  it("is valid for 8 hours and then expires", () => {
    const clock = fakeClock();
    const auth = createStaffAuth({ password: "correct-horse", now: clock.now });
    const token = auth.signIn("correct-horse");
    clock.advance(EIGHT_HOURS_MS - 1);
    expect(auth.verify(token)).toBe(true);
    clock.advance(1);
    expect(auth.verify(token)).toBe(false);
  });

  it("rejects unknown and missing tokens", () => {
    const auth = createStaffAuth({ password: "correct-horse", now: fakeClock().now });
    expect(auth.verify("not-a-token")).toBe(false);
    expect(auth.verify(undefined)).toBe(false);
  });
});
