import { describe, expect, it } from "vitest";
import { TASTINGS } from "../../shared/tastings.js";

describe("tasting catalogue", () => {
  it("lists the three tastings from the brief", () => {
    expect(TASTINGS).toEqual([
      { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00:00+01:00", pricePerGuest: 25, seats: 12 },
      { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00:00+01:00", pricePerGuest: 32, seats: 8 },
      { id: "winter-tasting", title: "Winter Tasting", startsAt: "2026-12-05T17:00:00+01:00", pricePerGuest: 28, seats: 10 },
    ]);
  });
});
