import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  test: {
    include: ["tests/server/**/*.test.ts", "tests/client/**/*.test.{ts,tsx}"],
  },
});
