# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings online; staff sign in to see and cancel bookings.
Spec: [docs/SPEC.md](docs/SPEC.md).

## Running

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start   # http://localhost:3000
```

Environment variables:

| Variable | Default | Purpose |
|---|---|---|
| `STAFF_PASSWORD` | – | Staff sign-in password. Unset or empty means staff sign-in is refused. |
| `PORT` | `3000` | HTTP port. |
| `DATA_FILE` | `data/bookings.json` | JSON file holding the bookings. Created on first booking. |

Development: `npm run dev` starts Vite (port 5173, `/api` proxied to `localhost:3000`, so run `npm start` alongside it).

## Checks

```sh
npm test            # API tests (vitest + supertest) and booking form tests (Testing Library)
npm run typecheck
```

## Layout

- `server/` – Express API (`app.ts`), JSON-file booking store (`store.ts`), tasting catalogue (`tastings.ts`), entry point (`index.ts`).
- `shared/` – validation schema (zod) and API types, used by both server and browser.
- `src/` – React app: tastings list, booking form and confirmation, staff page.
- `docs/SPEC.md` – requirements, API contract and test plan.

## Notes and limits

- The tasting catalogue is fixed in `server/tastings.ts`; changing it means editing that file.
- Staff sessions live in server memory, so a restart signs staff out. Cookies are `HttpOnly` and `SameSite=Strict`; they are not marked `Secure`, so put the app behind HTTPS in production and add `Secure` there.
- Staff sign-in is limited to 10 failed attempts per IP per 15 minutes. Behind a reverse proxy, set Express's `trust proxy` so the limit applies per client.
- Bookings are stored in one JSON file for a single server process. That suits a small winery; it is not for running several instances.
