# Weingut Kieselbrunnen – Tasting Bookings: Specification

## Goal

A small web app where guests book wine tastings online and staff see and cancel bookings.
English UI, mobile-friendly, styled like a small family winery's own site.

## Tastings (fixed catalogue, server-side)

| id | Title | Starts | Price per guest | Seats |
|---|---|---|---|---|
| `riesling-evening` | Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| `red-wine-cellar-tour` | Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| `winter-tasting` | Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

## Guest requirements

- G1. Start page `/` lists every tasting with title, date and time, price per guest and seats left, shown as `<n> seats left` (`1 seat left` for one, `Fully booked` at zero).
- G2. Each tasting has a button/link `Book <title>` opening `/tastings/:id/book`.
- G3. Booking form fields: `Name`, `Email`, `Guests` (integer 1–8), and a `Book` button.
- G4. A booking may never take more seats than are left (checked on the server; the client mirrors it for display).
- G5. Invalid input is rejected with an error shown next to the field it concerns.
- G6. After a successful booking the guest sees heading `Booking confirmed` with tasting, number of guests, total price and booking reference.
- G7. A fully booked tasting shows a clear "Fully booked" state; no booking is possible.

## Staff requirements

- S1. `/staff` shows a `Password` field and a `Sign in` button. The password is `STAFF_PASSWORD` from the environment.
- S2. Signed in, staff see all bookings grouped by tasting (name, email, guests, reference) and can cancel any booking with a `Cancel` button.
- S3. Cancelling frees the booking's seats immediately.
- S4. If `STAFF_PASSWORD` is not set, staff sign-in is refused (fails closed) and the server logs a warning at startup.
- S5. Staff API endpoints reject requests without a valid staff session (401).
- S6. Repeated wrong passwords are rate-limited.

## Operations

- O1. `npm install`, `npm run build`, `npm start`. Serves app and API on `PORT` (default 3000).
- O2. Starts with zero bookings. Bookings persist to a local JSON file (`DATA_FILE`, default `data/bookings.json`), written atomically.
- O3. No external services; no CDN fonts or scripts.

## API contract

| Method | Path | Auth | Request | Success | Errors |
|---|---|---|---|---|---|
| GET | `/api/tastings` | – | – | 200 `Tasting[]` with `seatsLeft` | – |
| POST | `/api/tastings/:id/bookings` | – | JSON `{name, email, guests}` | 201 `Confirmation` | 400 `{errors}` field map; 404 unknown tasting; 409 `{errors}` when too many guests |
| POST | `/api/staff/login` | – | `{password}` | 204 + session cookie | 401; 429 rate-limited; 503 not configured |
| POST | `/api/staff/logout` | – | – | 204, cookie cleared | – |
| GET | `/api/staff/bookings` | staff | – | 200 `{tastings: TastingWithBookings[]}` | 401 |
| DELETE | `/api/staff/bookings/:reference` | staff | – | 204 | 401; 404 unknown reference |

`Confirmation = {reference, tastingTitle, starts, guests, total}` (total in whole EUR).
Field map: `{errors: {name?: string, email?: string, guests?: string}}`.

Session: random token in an `HttpOnly`, `SameSite=Strict` cookie `staff_session`, 8-hour lifetime, held in server memory (sign-in is lost on restart).

## Validation rules

- `name`: trimmed, 1–100 characters.
- `email`: trimmed, valid email format, at most 254 characters.
- `guests`: integer, 1–8, and not more than seats left at booking time.

## Test plan (written before the implementation)

- Server (vitest + supertest): catalogue and `seatsLeft`; booking happy path and confirmation shape; each validation error on its field; over-capacity rejected with 409 and no seats taken; fully booked rejected; unknown tasting 404; staff auth (401 without cookie, 401 wrong password, 204 right password, 503 unset password, 429 after too many attempts); grouped staff listing; cancel frees seats and unknown reference 404; persistence round-trip through the JSON file.
- Client (vitest + Testing Library): booking form shows field-level error messages and the confirmation view after success.
- Manual verification: production build served by `npm start`, exercised over HTTP and in a headless browser where available.

## Decisions taken without asking

- React + Vite (SPA) with an Express server for the API and static files: established, small, no framework lock-in.
- TypeScript throughout; zod schemas shared by client and server so validation matches.
- Tailwind CSS for styling; react-hook-form + zodResolver for forms; react-router for routing.
- `1 seat left` (singular) rather than the literal `1 seats left`.
- Booking reference format `KB-XXXXXX` (6 characters from an unambiguous alphabet).
