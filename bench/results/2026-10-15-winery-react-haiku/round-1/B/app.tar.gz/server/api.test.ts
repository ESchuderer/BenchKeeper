import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import request from "supertest";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { createApp } from "./app.js";

const PASSWORD = "correct horse battery";

describe("API", () => {
  let dir: string;
  let dataFile: string;
  let app: ReturnType<typeof createApp>;

  beforeEach(() => {
    dir = fs.mkdtempSync(path.join(os.tmpdir(), "kieselbrunnen-"));
    dataFile = path.join(dir, "bookings.json");
    app = createApp({ dataFile, staffPassword: PASSWORD });
  });

  afterEach(() => {
    fs.rmSync(dir, { recursive: true, force: true });
  });

  const book = (id: string, body: unknown) =>
    request(app).post(`/api/tastings/${id}/bookings`).send(body as object);

  const signIn = async (password = PASSWORD) => {
    const res = await request(app).post("/api/staff/login").send({ password });
    return res.headers["set-cookie"]?.[0]?.split(";")[0] ?? "";
  };

  const seatsLeftOf = async (id: string) => {
    const res = await request(app).get("/api/tastings");
    return res.body.find((t: { id: string }) => t.id === id).seatsLeft;
  };

  describe("tastings", () => {
    it("lists the three tastings with seats left and price", async () => {
      const res = await request(app).get("/api/tastings");

      expect(res.status).toBe(200);
      expect(
        res.body.map((t: { id: string; title: string; starts: string; pricePerGuest: number; seats: number; seatsLeft: number }) => [
          t.id, t.title, t.starts, t.pricePerGuest, t.seats, t.seatsLeft,
        ]),
      ).toEqual([
        ["riesling-evening", "Riesling Evening", "2026-11-06T18:00", 25, 12, 12],
        ["red-wine-cellar-tour", "Red Wine Cellar Tour", "2026-11-14T15:00", 32, 8, 8],
        ["winter-tasting", "Winter Tasting", "2026-12-05T17:00", 28, 10, 10],
      ]);
    });
  });

  describe("booking", () => {
    it("creates a booking and returns a confirmation with total and reference", async () => {
      const res = await book("winter-tasting", { name: "Anna Schmidt", email: "anna@example.com", guests: 3 });

      expect(res.status).toBe(201);
      expect(res.body).toEqual({
        reference: expect.stringMatching(/^KB-[A-HJ-NP-Z2-9]{6}$/),
        tastingTitle: "Winter Tasting",
        starts: "2026-12-05T17:00",
        guests: 3,
        total: 84,
      });
      expect(await seatsLeftOf("winter-tasting")).toBe(7);
    });

    it("trims name and email", async () => {
      const res = await book("riesling-evening", { name: "  Jo  ", email: " jo@example.com ", guests: 1 });
      expect(res.status).toBe(201);
    });

    it.each([
      ["missing name", { email: "a@example.com", guests: 1 }, "name"],
      ["blank name", { name: "   ", email: "a@example.com", guests: 1 }, "name"],
      ["name too long", { name: "x".repeat(101), email: "a@example.com", guests: 1 }, "name"],
      ["missing email", { name: "Anna", guests: 1 }, "email"],
      ["malformed email", { name: "Anna", email: "anna@", guests: 1 }, "email"],
      ["zero guests", { name: "Anna", email: "a@example.com", guests: 0 }, "guests"],
      ["nine guests", { name: "Anna", email: "a@example.com", guests: 9 }, "guests"],
      ["fractional guests", { name: "Anna", email: "a@example.com", guests: 2.5 }, "guests"],
      ["guests as text", { name: "Anna", email: "a@example.com", guests: "2" }, "guests"],
    ])("rejects %s with an error on the %s field", async (_label, body, field) => {
      const res = await book("red-wine-cellar-tour", body);

      expect(res.status).toBe(400);
      expect(res.body.errors).toHaveProperty(field);
      expect(typeof res.body.errors[field]).toBe("string");
      expect(await seatsLeftOf("red-wine-cellar-tour")).toBe(8);
    });

    it("reports every required field when the request has no body", async () => {
      const res = await request(app).post("/api/tastings/winter-tasting/bookings");

      expect(res.status).toBe(400);
      expect(Object.keys(res.body.errors).sort()).toEqual(["email", "guests", "name"]);
    });

    it("counts a name of 100 emoji as 100 characters", async () => {
      const res = await book("winter-tasting", { name: "🍇".repeat(100), email: "a@example.com", guests: 1 });
      expect(res.status).toBe(201);
    });

    it("rejects more guests than seats left and takes no seats", async () => {
      await book("winter-tasting", { name: "A", email: "a@example.com", guests: 8 });

      const res = await book("winter-tasting", { name: "B", email: "b@example.com", guests: 3 });

      expect(res.status).toBe(409);
      expect(res.body.errors.guests).toMatch(/2 seats left/);
      expect(await seatsLeftOf("winter-tasting")).toBe(2);
    });

    it("accepts a booking for exactly the seats left", async () => {
      await book("winter-tasting", { name: "A", email: "a@example.com", guests: 8 });

      const res = await book("winter-tasting", { name: "B", email: "b@example.com", guests: 2 });

      expect(res.status).toBe(201);
      expect(await seatsLeftOf("winter-tasting")).toBe(0);
    });

    it("refuses bookings for a fully booked tasting", async () => {
      await book("riesling-evening", { name: "A", email: "a@example.com", guests: 8 });
      await book("riesling-evening", { name: "B", email: "b@example.com", guests: 4 });

      const res = await book("riesling-evening", { name: "C", email: "c@example.com", guests: 1 });

      expect(res.status).toBe(409);
      expect(res.body.errors.guests).toMatch(/fully booked/i);
    });

    it("returns 404 for an unknown tasting", async () => {
      const res = await book("no-such-tasting", { name: "A", email: "a@example.com", guests: 1 });
      expect(res.status).toBe(404);
    });

    it("hands out a different reference for each booking", async () => {
      const first = await book("winter-tasting", { name: "A", email: "a@example.com", guests: 1 });
      const second = await book("winter-tasting", { name: "B", email: "b@example.com", guests: 1 });
      expect(first.body.reference).not.toBe(second.body.reference);
    });
  });

  describe("staff sign-in", () => {
    it("refuses the staff listing without a session", async () => {
      const res = await request(app).get("/api/staff/bookings");
      expect(res.status).toBe(401);
    });

    it("refuses a wrong password", async () => {
      const res = await request(app).post("/api/staff/login").send({ password: "nope" });
      expect(res.status).toBe(401);
      expect(res.headers["set-cookie"]).toBeUndefined();
    });

    it("sets an HttpOnly, SameSite=Strict session cookie for the right password", async () => {
      const res = await request(app).post("/api/staff/login").send({ password: PASSWORD });

      expect(res.status).toBe(204);
      const cookie = res.headers["set-cookie"][0];
      expect(cookie).toMatch(/^staff_session=/);
      expect(cookie).toMatch(/HttpOnly/i);
      expect(cookie).toMatch(/SameSite=Strict/i);
    });

    it("fails closed when no staff password is configured", async () => {
      const closed = createApp({ dataFile, staffPassword: undefined });
      const res = await request(closed).post("/api/staff/login").send({ password: "" });
      expect(res.status).toBe(503);
    });

    it("rate-limits repeated wrong passwords", async () => {
      let last = 0;
      for (let i = 0; i < 12; i++) {
        last = (await request(app).post("/api/staff/login").send({ password: "wrong" })).status;
      }
      expect(last).toBe(429);
    });

    it("signs out and invalidates the session", async () => {
      const cookie = await signIn();
      const out = await request(app).post("/api/staff/logout").set("Cookie", cookie);
      expect(out.status).toBe(204);

      const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
      expect(res.status).toBe(401);
    });
  });

  describe("staff bookings", () => {
    it("lists bookings grouped by tasting, including empty tastings", async () => {
      await book("winter-tasting", { name: "Anna", email: "anna@example.com", guests: 2 });
      await book("winter-tasting", { name: "Ben", email: "ben@example.com", guests: 1 });
      const cookie = await signIn();

      const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);

      expect(res.status).toBe(200);
      expect(res.body.tastings.map((t: { id: string }) => t.id)).toEqual([
        "riesling-evening", "red-wine-cellar-tour", "winter-tasting",
      ]);
      const winter = res.body.tastings[2];
      expect(winter.seatsLeft).toBe(7);
      expect(winter.bookings.map((b: { name: string }) => b.name)).toEqual(["Anna", "Ben"]);
      expect(winter.bookings[0]).toEqual({
        reference: expect.stringMatching(/^KB-/),
        name: "Anna",
        email: "anna@example.com",
        guests: 2,
      });
      expect(res.body.tastings[0].bookings).toEqual([]);
    });

    it("cancelling a booking frees its seats", async () => {
      const created = await book("red-wine-cellar-tour", { name: "Anna", email: "a@example.com", guests: 5 });
      const cookie = await signIn();
      expect(await seatsLeftOf("red-wine-cellar-tour")).toBe(3);

      const res = await request(app)
        .delete(`/api/staff/bookings/${created.body.reference}`)
        .set("Cookie", cookie);

      expect(res.status).toBe(204);
      expect(await seatsLeftOf("red-wine-cellar-tour")).toBe(8);
      const listing = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
      expect(listing.body.tastings[1].bookings).toEqual([]);
    });

    it("cancel needs a staff session", async () => {
      const created = await book("red-wine-cellar-tour", { name: "Anna", email: "a@example.com", guests: 1 });

      const res = await request(app).delete(`/api/staff/bookings/${created.body.reference}`);

      expect(res.status).toBe(401);
      expect(await seatsLeftOf("red-wine-cellar-tour")).toBe(7);
    });

    it("returns 404 when cancelling an unknown reference", async () => {
      const cookie = await signIn();
      const res = await request(app).delete("/api/staff/bookings/KB-ZZZZZZ").set("Cookie", cookie);
      expect(res.status).toBe(404);
    });
  });

  describe("persistence", () => {
    it("keeps bookings in the data file across app restarts", async () => {
      await book("winter-tasting", { name: "Anna", email: "anna@example.com", guests: 4 });

      const restarted = createApp({ dataFile, staffPassword: PASSWORD });
      const res = await request(restarted).get("/api/tastings");

      expect(res.body.find((t: { id: string }) => t.id === "winter-tasting").seatsLeft).toBe(6);
    });

    it("starts with no bookings when no data file exists", async () => {
      expect(fs.existsSync(dataFile)).toBe(false);
      expect(await seatsLeftOf("winter-tasting")).toBe(10);
    });
  });
});
