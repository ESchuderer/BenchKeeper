import crypto from "node:crypto";
import path from "node:path";
import cookieParser from "cookie-parser";
import express, { type NextFunction, type Request, type Response } from "express";
import { rateLimit } from "express-rate-limit";
import { bookingSchema } from "../shared/booking.js";
import type { Confirmation, FieldErrors, Tasting, TastingWithBookings } from "../shared/types.js";
import { createBookingStore } from "./store.js";
import { TASTINGS, type TastingDefinition } from "./tastings.js";

export interface AppOptions {
  dataFile: string;
  /** Staff sign-in is disabled when this is empty. */
  staffPassword: string | undefined;
  /** Built React app to serve; omitted in tests. */
  clientDir?: string;
}

const SESSION_COOKIE = "staff_session";
const SESSION_MS = 8 * 60 * 60 * 1000;

export function createApp({ dataFile, staffPassword, clientDir }: AppOptions) {
  const store = createBookingStore(dataFile);
  const sessions = new Map<string, number>(); // token -> expiry time (ms)

  // Per app instance, so each test gets a fresh counter.
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 10,
    skipSuccessfulRequests: true,
    standardHeaders: "draft-8",
    legacyHeaders: false,
    message: { error: "Too many sign-in attempts. Try again in 15 minutes." },
  });

  const seatsLeft = (t: TastingDefinition) => t.seats - store.seatsTaken(t.id);

  const toTasting = (t: TastingDefinition): Tasting => ({
    id: t.id,
    title: t.title,
    starts: t.starts,
    pricePerGuest: t.pricePerGuest,
    seats: t.seats,
    seatsLeft: seatsLeft(t),
  });

  // Hash both sides first so the comparison length does not leak the password's length.
  const passwordMatches = (given: unknown) => {
    if (!staffPassword || typeof given !== "string") return false;
    const digest = (s: string) => crypto.createHash("sha256").update(s).digest();
    return crypto.timingSafeEqual(digest(given), digest(staffPassword));
  };

  const isStaff = (req: Request) => {
    const token = req.cookies?.[SESSION_COOKIE];
    const expires = typeof token === "string" ? sessions.get(token) : undefined;
    if (expires === undefined) return false;
    if (expires < Date.now()) {
      sessions.delete(token);
      return false;
    }
    return true;
  };

  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    if (isStaff(req)) return next();
    res.status(401).json({ error: "Please sign in as staff" });
  };

  const app = express();
  app.use(express.json({ limit: "10kb" }));
  app.use(cookieParser());

  app.get("/api/tastings", (_req, res) => {
    res.json(TASTINGS.map(toTasting));
  });

  app.post("/api/tastings/:id/bookings", (req, res) => {
    const tasting = TASTINGS.find((t) => t.id === req.params.id);
    if (!tasting) return res.status(404).json({ error: "Unknown tasting" });

    // A missing body reports every field as required, instead of an unnamed error.
    const parsed = bookingSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      const errors: FieldErrors = {};
      for (const issue of parsed.error.issues) {
        const field = issue.path[0] as keyof FieldErrors;
        errors[field] ??= issue.message;
      }
      return res.status(400).json({ errors });
    }

    const { name, email, guests } = parsed.data;
    const left = seatsLeft(tasting);
    if (guests > left) {
      const message =
        left === 0
          ? "This tasting is fully booked"
          : `Only ${left} ${left === 1 ? "seat" : "seats"} left for this tasting`;
      return res.status(409).json({ errors: { guests: message } satisfies FieldErrors });
    }

    const booking = store.add({ tastingId: tasting.id, name, email, guests });
    const confirmation: Confirmation = {
      reference: booking.reference,
      tastingTitle: tasting.title,
      starts: tasting.starts,
      guests,
      total: guests * tasting.pricePerGuest,
    };
    res.status(201).json(confirmation);
  });

  app.post("/api/staff/login", loginLimiter, (req, res) => {
    if (!staffPassword) {
      return res.status(503).json({ error: "Staff sign-in is not configured" });
    }
    if (!passwordMatches(req.body?.password)) {
      return res.status(401).json({ error: "Wrong password" });
    }
    const token = crypto.randomBytes(32).toString("base64url");
    sessions.set(token, Date.now() + SESSION_MS);
    res.cookie(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: "strict",
      maxAge: SESSION_MS,
      path: "/",
    });
    res.status(204).end();
  });

  app.post("/api/staff/logout", (req, res) => {
    const token = req.cookies?.[SESSION_COOKIE];
    if (typeof token === "string") sessions.delete(token);
    res.clearCookie(SESSION_COOKIE, { path: "/" });
    res.status(204).end();
  });

  app.get("/api/staff/bookings", requireStaff, (_req, res) => {
    const tastings: TastingWithBookings[] = TASTINGS.map((t) => ({
      ...toTasting(t),
      bookings: store
        .all()
        .filter((b) => b.tastingId === t.id)
        .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
    }));
    res.json({ tastings });
  });

  app.delete("/api/staff/bookings/:reference", requireStaff, (req: Request<{ reference: string }>, res) => {
    if (!store.remove(req.params.reference)) {
      return res.status(404).json({ error: "Booking not found" });
    }
    res.status(204).end();
  });

  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Not found" });
  });

  if (clientDir) {
    app.use(express.static(clientDir));
    // Client-side routes such as /staff load the app shell.
    app.use((req, res, next) => {
      if (req.method !== "GET" && req.method !== "HEAD") return next();
      res.sendFile(path.join(clientDir, "index.html"));
    });
  }

  app.use((err: Error & { status?: number }, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status ?? 500;
    res.status(status).json({ error: status < 500 ? err.message : "Something went wrong" });
  });

  return app;
}
