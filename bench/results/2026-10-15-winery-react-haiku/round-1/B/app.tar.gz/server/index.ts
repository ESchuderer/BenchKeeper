import path from "node:path";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT ?? 3000);
// A blank or whitespace-only password counts as unset, so sign-in fails closed.
const staffPassword = process.env.STAFF_PASSWORD?.trim() ? process.env.STAFF_PASSWORD : undefined;

if (!staffPassword) {
  console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled until it is.");
}

const app = createApp({
  dataFile: path.resolve(process.env.DATA_FILE ?? "data/bookings.json"),
  staffPassword,
  clientDir: path.resolve(here, "../client"),
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
});
