import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export interface StoredBooking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

// No 0/O or 1/I, so references can be read out over the phone.
const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

/**
 * Bookings kept in memory and written to a JSON file after every change.
 * Node runs this synchronously, so a check-then-add cannot interleave.
 */
export function createBookingStore(dataFile: string) {
  let bookings: StoredBooking[] = fs.existsSync(dataFile)
    ? (JSON.parse(fs.readFileSync(dataFile, "utf8")) as StoredBooking[])
    : [];

  // Write to a temp file and rename, so a crash mid-write cannot corrupt the file.
  function persist(next: StoredBooking[]) {
    fs.mkdirSync(path.dirname(dataFile), { recursive: true });
    const tmp = `${dataFile}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2));
    fs.renameSync(tmp, dataFile);
  }

  function newReference() {
    for (;;) {
      const chars = Array.from({ length: 6 }, () =>
        REFERENCE_ALPHABET[crypto.randomInt(REFERENCE_ALPHABET.length)],
      );
      const reference = `KB-${chars.join("")}`;
      if (!bookings.some((b) => b.reference === reference)) return reference;
    }
  }

  return {
    all: (): readonly StoredBooking[] => bookings,

    seatsTaken: (tastingId: string) =>
      bookings.filter((b) => b.tastingId === tastingId).reduce((sum, b) => sum + b.guests, 0),

    add(booking: Omit<StoredBooking, "reference">): StoredBooking {
      const created = { reference: newReference(), ...booking };
      const next = [...bookings, created];
      persist(next);
      bookings = next;
      return created;
    },

    remove(reference: string): boolean {
      if (!bookings.some((b) => b.reference === reference)) return false;
      const next = bookings.filter((b) => b.reference !== reference);
      persist(next);
      bookings = next;
      return true;
    },
  };
}
