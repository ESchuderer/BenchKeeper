export interface TastingDefinition {
  id: string;
  title: string;
  starts: string;
  pricePerGuest: number;
  seats: number;
}

// The catalogue is fixed by the winery; it is not edited through the app.
export const TASTINGS: readonly TastingDefinition[] = [
  { id: "riesling-evening", title: "Riesling Evening", starts: "2026-11-06T18:00", pricePerGuest: 25, seats: 12 },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", starts: "2026-11-14T15:00", pricePerGuest: 32, seats: 8 },
  { id: "winter-tasting", title: "Winter Tasting", starts: "2026-12-05T17:00", pricePerGuest: 28, seats: 10 },
];
