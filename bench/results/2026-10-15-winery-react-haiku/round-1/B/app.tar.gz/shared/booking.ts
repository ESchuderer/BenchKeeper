import { z } from "zod";

// Shared by the browser form and the API, so both enforce the same rules.
export const MAX_GUESTS_PER_BOOKING = 8;

export const bookingSchema = z.object({
  name: z
    .string("Please enter your name")
    .trim()
    .min(1, "Please enter your name")
    // Count code points, so an emoji is one character as a guest would count it.
    .refine((s) => [...s].length <= 100, "Name must be 100 characters or fewer"),
  email: z
    .string("Please enter your email")
    .trim()
    .min(1, "Please enter your email")
    .max(254, "Email must be 254 characters or fewer")
    .pipe(z.email("Please enter a valid email address")),
  guests: z
    .number("Please enter the number of guests")
    .int("Please enter a whole number of guests")
    .min(1, "At least 1 guest is required")
    .max(MAX_GUESTS_PER_BOOKING, `At most ${MAX_GUESTS_PER_BOOKING} guests per booking`),
});

export type BookingInput = z.infer<typeof bookingSchema>;
