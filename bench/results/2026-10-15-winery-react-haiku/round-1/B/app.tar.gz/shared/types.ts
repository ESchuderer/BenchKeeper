// Response shapes of the JSON API, shared by server and client.

export interface Tasting {
  id: string;
  title: string;
  /** Local start time, e.g. "2026-11-06T18:00" */
  starts: string;
  pricePerGuest: number;
  seats: number;
  seatsLeft: number;
}

export interface Confirmation {
  reference: string;
  tastingTitle: string;
  starts: string;
  guests: number;
  /** Whole euros */
  total: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface TastingWithBookings extends Tasting {
  bookings: StaffBooking[];
}

export type FieldErrors = Partial<Record<"name" | "email" | "guests", string>>;
