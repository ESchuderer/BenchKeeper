import { Route, Routes } from "react-router";
import Layout from "./components/Layout";
import BookingPage from "./pages/BookingPage";
import StaffPage from "./pages/StaffPage";
import TastingsPage from "./pages/TastingsPage";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingsPage />} />
        <Route path="tastings/:id/book" element={<BookingPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route
          path="*"
          element={
            <div className="card text-center">
              <h1 className="text-3xl">Page not found</h1>
              <p className="mt-3 text-muted">That page does not exist.</p>
            </div>
          }
        />
      </Route>
    </Routes>
  );
}
