import type { BookingInput } from "../shared/booking";
import type { Confirmation, Tasting, TastingWithBookings } from "../shared/types";

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly body: { error?: string; errors?: Record<string, string> },
  ) {
    super(body.error ?? `Request failed with status ${status}`);
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json" },
  });
  if (res.status === 204) return undefined as T;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, body);
  return body as T;
}

export const api = {
  tastings: () => request<Tasting[]>("/api/tastings"),

  book: (tastingId: string, input: BookingInput) =>
    request<Confirmation>(`/api/tastings/${tastingId}/bookings`, {
      method: "POST",
      body: JSON.stringify(input),
    }),

  staffBookings: () => request<{ tastings: TastingWithBookings[] }>("/api/staff/bookings"),

  signIn: (password: string) =>
    request<void>("/api/staff/login", { method: "POST", body: JSON.stringify({ password }) }),

  signOut: () => request<void>("/api/staff/logout", { method: "POST" }),

  cancelBooking: (reference: string) =>
    request<void>(`/api/staff/bookings/${reference}`, { method: "DELETE" }),
};
