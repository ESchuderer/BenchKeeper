import { Link, Outlet } from "react-router";

export default function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-wine text-cream">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-5">
          <Link to="/" className="font-display text-xl tracking-wide sm:text-2xl">
            Weingut Kieselbrunnen
          </Link>
          <nav className="text-sm font-medium">
            <Link to="/" className="rounded px-2 py-1 hover:text-gold-light">
              Tastings
            </Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-10">
        <Outlet />
      </main>

      <footer className="border-t border-line px-4 py-6 text-center text-sm text-muted">
        <p>
          Weingut Kieselbrunnen · Family winery ·{" "}
          <Link to="/staff" className="underline underline-offset-2 hover:text-wine">
            Staff sign-in
          </Link>
        </p>
      </footer>
    </div>
  );
}
