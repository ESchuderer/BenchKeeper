// Start times are local wall-clock strings ("2026-11-06T18:00"), so they are shown as written.
export function formatWhen(starts: string) {
  const date = new Date(starts);
  const day = date.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const time = date.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false });
  return `${day}, ${time}`;
}

export const formatPrice = (euros: number) => `EUR ${euros}`;

export function seatsLeftLabel(seatsLeft: number) {
  if (seatsLeft === 0) return "Fully booked";
  return seatsLeft === 1 ? "1 seat left" : `${seatsLeft} seats left`;
}
