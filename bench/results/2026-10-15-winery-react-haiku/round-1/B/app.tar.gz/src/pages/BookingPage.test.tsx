// @vitest-environment jsdom
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import BookingPage from "./BookingPage";

const tastings = [
  { id: "winter-tasting", title: "Winter Tasting", starts: "2026-12-05T17:00", pricePerGuest: 28, seats: 10, seatsLeft: 3 },
];

function renderPage() {
  return render(
    <MemoryRouter initialEntries={["/tastings/winter-tasting/book"]}>
      <Routes>
        <Route path="/tastings/:id/book" element={<BookingPage />} />
      </Routes>
    </MemoryRouter>,
  );
}

function mockApi(booking: Response) {
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    if (String(input) === "/api/tastings") {
      return new Response(JSON.stringify(tastings), { status: 200 });
    }
    expect(init?.method).toBe("POST");
    return booking;
  });
  vi.stubGlobal("fetch", fetchMock);
  return fetchMock;
}

describe("BookingPage", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it("shows an error next to each invalid field", async () => {
    mockApi(new Response("{}", { status: 201 }));
    renderPage();
    const user = userEvent.setup();

    await user.click(await screen.findByRole("button", { name: "Book" }));

    expect(await screen.findByText("Please enter your name")).toBeTruthy();
    expect(screen.getByText("Please enter your email")).toBeTruthy();
    expect(screen.getByLabelText("Name").getAttribute("aria-invalid")).toBe("true");
  });

  it("shows the server's seat limit message on the Guests field", async () => {
    mockApi(new Response(JSON.stringify({ errors: { guests: "Only 3 seats left for this tasting." } }), { status: 409 }));
    renderPage();
    const user = userEvent.setup();

    await user.type(await screen.findByLabelText("Name"), "Anna Schmidt");
    await user.type(screen.getByLabelText("Email"), "anna@example.com");
    await user.clear(screen.getByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), "5");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Only 3 seats left for this tasting.")).toBeTruthy();
    expect(screen.queryByText("Booking confirmed")).toBeNull();
  });

  it("shows the confirmation after a successful booking", async () => {
    const fetchMock = mockApi(
      new Response(
        JSON.stringify({
          reference: "KB-A7K9QF",
          tastingTitle: "Winter Tasting",
          starts: "2026-12-05T17:00",
          guests: 2,
          total: 56,
        }),
        { status: 201 },
      ),
    );
    renderPage();
    const user = userEvent.setup();

    await user.type(await screen.findByLabelText("Name"), "Anna Schmidt");
    await user.type(screen.getByLabelText("Email"), "anna@example.com");
    await user.clear(screen.getByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeTruthy();
    expect(screen.getByText("KB-A7K9QF")).toBeTruthy();
    expect(screen.getByText("EUR 56")).toBeTruthy();
    await waitFor(() => expect(fetchMock).toHaveBeenCalledWith(
      "/api/tastings/winter-tasting/bookings",
      expect.objectContaining({ method: "POST" }),
    ));
  });
});
