import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState, type ComponentProps } from "react";
import { useForm } from "react-hook-form";
import { Link, useParams } from "react-router";
import { api, ApiError } from "../api";
import { bookingSchema, MAX_GUESTS_PER_BOOKING, type BookingInput } from "../../shared/booking";
import type { Confirmation, Tasting } from "../../shared/types";
import { formatPrice, formatWhen, seatsLeftLabel } from "../format";

export default function BookingPage() {
  const { id = "" } = useParams();
  const [tasting, setTasting] = useState<Tasting | null | undefined>(undefined);
  const [loadFailed, setLoadFailed] = useState(false);
  const [confirmation, setConfirmation] = useState<Confirmation | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: "", email: "", guests: 1 },
  });

  const loadTasting = () =>
    api
      .tastings()
      .then((list) => {
        setLoadFailed(false);
        setTasting(list.find((t) => t.id === id) ?? null);
      })
      .catch(() => setLoadFailed(true));

  useEffect(() => {
    loadTasting();
  }, [id]);

  if (loadFailed) {
    return (
      <p role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
        We could not load this tasting. Please refresh the page to try again.
      </p>
    );
  }

  if (tasting === undefined) return <p className="text-muted">Loading…</p>;

  if (tasting === null) {
    return (
      <div className="card text-center">
        <h1 className="text-3xl">Tasting not found</h1>
        <p className="mt-3 text-muted">This tasting is not on our programme.</p>
        <Link to="/" className="btn btn-primary mt-6">
          Back to tastings
        </Link>
      </div>
    );
  }

  if (confirmation) {
    return (
      <section className="card mx-auto max-w-xl" aria-labelledby="confirmed-heading">
        <h1 id="confirmed-heading" className="text-3xl text-success">
          Booking confirmed
        </h1>
        <p className="mt-3 text-muted">Thank you. We look forward to welcoming you to the cellar.</p>
        <dl className="mt-6 divide-y divide-line">
          <Row label="Tasting" value={confirmation.tastingTitle} />
          <Row label="When" value={formatWhen(confirmation.starts)} />
          <Row label="Guests" value={String(confirmation.guests)} />
          <Row label="Total" value={formatPrice(confirmation.total)} />
          <Row label="Booking reference" value={confirmation.reference} strong />
        </dl>
        <p className="mt-6 text-sm text-muted">Please quote your booking reference when you arrive.</p>
        <Link to="/" className="btn btn-secondary mt-6">
          Back to tastings
        </Link>
      </section>
    );
  }

  const full = tasting.seatsLeft === 0;

  const onSubmit = handleSubmit(async (values) => {
    setSubmitError(null);
    try {
      setConfirmation(await api.book(tasting.id, values));
    } catch (err) {
      if (err instanceof ApiError && err.body.errors) {
        for (const [field, message] of Object.entries(err.body.errors)) {
          setError(field as keyof BookingInput, { type: "server", message });
        }
        if (err.status === 409) loadTasting();
      } else {
        // The request may have reached the server, so do not assume the booking failed.
        setSubmitError("Something went wrong. Your booking may not have been made, so check before trying again.");
      }
    }
  });

  return (
    <div className="grid gap-8 md:grid-cols-5">
      <section className="card md:col-span-2 md:self-start">
        <p className="text-sm font-semibold uppercase tracking-wider text-gold-dark">Tasting</p>
        <h1 className="mt-1 text-3xl">{tasting.title}</h1>
        <dl className="mt-5 space-y-3 text-sm">
          <Row label="When" value={formatWhen(tasting.starts)} />
          <Row label="Price per guest" value={formatPrice(tasting.pricePerGuest)} />
          <Row label="Availability" value={seatsLeftLabel(tasting.seatsLeft)} />
        </dl>
      </section>

      <section className="card md:col-span-3" aria-labelledby="booking-heading">
        <h2 id="booking-heading" className="text-2xl">
          Your booking
        </h2>

        {full ? (
          <p role="status" className="mt-4 rounded-lg bg-danger/5 p-4 text-danger">
            This tasting is fully booked. Please choose another date.
          </p>
        ) : (
          <form onSubmit={onSubmit} noValidate className="mt-6 space-y-5">
            <Field id="name" label="Name" autoComplete="name" error={errors.name?.message} {...register("name")} />
            <Field
              id="email"
              label="Email"
              type="email"
              autoComplete="email"
              inputMode="email"
              error={errors.email?.message}
              {...register("email")}
            />
            <Field
              id="guests"
              label="Guests"
              hint={`Between 1 and ${MAX_GUESTS_PER_BOOKING} guests per booking`}
              type="number"
              min={1}
              max={MAX_GUESTS_PER_BOOKING}
              step={1}
              inputMode="numeric"
              error={errors.guests?.message}
              {...register("guests", { valueAsNumber: true })}
            />

            {submitError && (
              <p role="alert" className="rounded-lg bg-danger/5 p-3 text-sm text-danger">
                {submitError}
              </p>
            )}

            <button type="submit" className="btn btn-primary w-full" disabled={isSubmitting}>
              {isSubmitting ? "Booking…" : "Book"}
            </button>
          </form>
        )}
      </section>
    </div>
  );
}

function Field({
  id,
  label,
  hint,
  error,
  ...input
}: { id: string; label: string; hint?: string; error?: string } & ComponentProps<"input">) {
  const describedBy = [hint && `${id}-hint`, error && `${id}-error`].filter(Boolean).join(" ");
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-semibold text-ink">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy || undefined}
        className="field-input mt-1.5"
        {...input}
      />
      {hint && (
        <p id={`${id}-hint`} className="mt-1.5 text-sm text-muted">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${id}-error`} className="mt-1.5 text-sm font-medium text-danger">
          {error}
        </p>
      )}
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex justify-between gap-4 py-2.5">
      <dt className="text-muted">{label}</dt>
      <dd className={strong ? "font-mono text-lg font-bold tracking-wider text-wine" : "text-right font-medium"}>
        {value}
      </dd>
    </div>
  );
}
