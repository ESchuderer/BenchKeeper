import { useEffect, useState, type FormEvent } from "react";
import { api, ApiError } from "../api";
import { formatPrice, formatWhen } from "../format";
import type { TastingWithBookings } from "../../shared/types";

type State =
  | { status: "checking" }
  | { status: "signed-out" }
  | { status: "signed-in"; tastings: TastingWithBookings[] }
  | { status: "error" };

export default function StaffPage() {
  const [state, setState] = useState<State>({ status: "checking" });

  const load = () =>
    api
      .staffBookings()
      .then(({ tastings }) => setState({ status: "signed-in", tastings }))
      .catch((err) => {
        if (err instanceof ApiError && err.status === 401) setState({ status: "signed-out" });
        else setState({ status: "error" });
      });

  useEffect(() => {
    load();
  }, []);

  if (state.status === "checking") return <p className="text-muted">Loading…</p>;
  if (state.status === "signed-out") return <SignIn onSignedIn={load} />;
  if (state.status === "error") {
    return (
      <p role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
        The bookings could not be loaded. Please refresh the page to try again.
      </p>
    );
  }

  return <Bookings tastings={state.tastings} onChanged={load} />;
}

function SignIn({ onSignedIn }: { onSignedIn: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.signIn(password);
      onSignedIn();
    } catch (err) {
      setError(err instanceof ApiError && err.body.error ? err.body.error : "Could not sign in. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="card mx-auto max-w-md">
      <h1 className="text-3xl">Staff sign-in</h1>
      <form onSubmit={submit} className="mt-6 space-y-5">
        <div>
          <label htmlFor="password" className="block text-sm font-semibold">
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            aria-invalid={error ? true : undefined}
            aria-describedby={error ? "password-error" : undefined}
            className="field-input mt-1.5"
          />
          {error && (
            <p id="password-error" className="mt-1.5 text-sm font-medium text-danger">
              {error}
            </p>
          )}
        </div>
        <button type="submit" className="btn btn-primary w-full" disabled={busy}>
          Sign in
        </button>
      </form>
    </section>
  );
}

function Bookings({ tastings, onChanged }: { tastings: TastingWithBookings[]; onChanged: () => void }) {
  const [error, setError] = useState<string | null>(null);

  async function cancel(booking: TastingWithBookings["bookings"][number]) {
    if (!window.confirm(`Cancel the booking for ${booking.name} (${booking.guests} guests, ${booking.reference})?`)) {
      return;
    }
    setError(null);
    try {
      await api.cancelBooking(booking.reference);
      onChanged();
    } catch (err) {
      // 401: the session has ended, so reloading shows the sign-in form.
      if (err instanceof ApiError && err.status === 401) return onChanged();
      if (err instanceof ApiError && err.status === 404) {
        setError(`The booking for ${booking.name} was already cancelled.`);
        return onChanged();
      }
      setError(`The booking for ${booking.name} could not be cancelled. Please try again.`);
    }
  }

  async function signOut() {
    try {
      await api.signOut();
    } catch {
      setError("Could not sign out. Please try again.");
      return;
    }
    onChanged();
  }

  return (
    <div className="space-y-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-4xl">Bookings</h1>
        <button type="button" onClick={signOut} className="btn btn-secondary">
          Sign out
        </button>
      </div>

      {error && (
        <p role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
          {error}
        </p>
      )}

      {tastings.map((t) => {
        const booked = t.seats - t.seatsLeft;
        return (
          <section key={t.id} aria-labelledby={`tasting-${t.id}`} className="card">
            <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-line pb-4">
              <div>
                <h2 id={`tasting-${t.id}`} className="text-2xl">
                  {t.title}
                </h2>
                <p className="text-sm text-muted">
                  {formatWhen(t.starts)} · {formatPrice(t.pricePerGuest)} per guest
                </p>
              </div>
              <p className="text-sm font-semibold text-ink">
                {booked} of {t.seats} seats booked
              </p>
            </div>

            {t.bookings.length === 0 ? (
              <p className="py-6 text-muted">No bookings yet.</p>
            ) : (
              <div className="relative -mx-2 mt-2 overflow-x-auto">
                <table className="w-full min-w-[32rem] text-left text-sm">
                  <thead className="text-muted">
                    <tr>
                      <th scope="col" className="px-2 py-2.5 font-semibold">Name</th>
                      <th scope="col" className="px-2 py-2.5 font-semibold">Email</th>
                      <th scope="col" className="px-2 py-2.5 font-semibold">Guests</th>
                      <th scope="col" className="px-2 py-2.5 font-semibold">Reference</th>
                      <th scope="col" className="px-2 py-2.5">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {t.bookings.map((b) => (
                      <tr key={b.reference}>
                        <td className="px-2 py-3 font-medium">{b.name}</td>
                        <td className="px-2 py-3 break-all">{b.email}</td>
                        <td className="px-2 py-3">{b.guests}</td>
                        <td className="px-2 py-3 font-mono tracking-wide">{b.reference}</td>
                        <td className="px-2 py-3 text-right">
                          <button
                            type="button"
                            onClick={() => cancel(b)}
                            aria-label={`Cancel booking ${b.reference} for ${b.name}`}
                            className="btn btn-danger px-3 py-1.5 text-sm"
                          >
                            Cancel
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
