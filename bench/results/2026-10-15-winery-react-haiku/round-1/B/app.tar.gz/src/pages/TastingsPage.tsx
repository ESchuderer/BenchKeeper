import { useEffect, useState } from "react";
import { Link } from "react-router";
import { api } from "../api";
import { formatPrice, formatWhen, seatsLeftLabel } from "../format";
import type { Tasting } from "../../shared/types";

type State = { status: "loading" } | { status: "error" } | { status: "ready"; tastings: Tasting[] };

export default function TastingsPage() {
  const [state, setState] = useState<State>({ status: "loading" });

  useEffect(() => {
    api
      .tastings()
      .then((tastings) => setState({ status: "ready", tastings }))
      .catch(() => setState({ status: "error" }));
  }, []);

  return (
    <>
      <section className="mb-10 max-w-2xl">
        <h1 className="text-4xl sm:text-5xl">Wine tastings</h1>
        <p className="mt-4 text-lg text-muted">
          Join us in the cellar for an evening or an afternoon with our family's wines. Choose a tasting and
          reserve your seats online.
        </p>
      </section>

      {state.status === "loading" && <p className="text-muted">Loading tastings…</p>}

      {state.status === "error" && (
        <p role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
          We could not load the tastings. Please refresh the page to try again.
        </p>
      )}

      {state.status === "ready" && (
        <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {state.tastings.map((t) => {
            const full = t.seatsLeft === 0;
            return (
              <li key={t.id} className="card flex flex-col">
                <h2 className="text-2xl">{t.title}</h2>
                <dl className="mt-4 space-y-2 text-sm">
                  <div>
                    <dt className="sr-only">Date and time</dt>
                    <dd className="font-medium text-ink">{formatWhen(t.starts)}</dd>
                  </div>
                  <div className="flex justify-between gap-4">
                    <dt className="text-muted">Price per guest</dt>
                    <dd className="font-semibold">{formatPrice(t.pricePerGuest)}</dd>
                  </div>
                  <div className="flex justify-between gap-4">
                    <dt className="text-muted">Availability</dt>
                    <dd>
                      <span
                        className={
                          full
                            ? "rounded-full bg-danger/10 px-2.5 py-0.5 font-semibold text-danger"
                            : t.seatsLeft <= 3
                              ? "rounded-full bg-gold/15 px-2.5 py-0.5 font-semibold text-gold-dark"
                              : "rounded-full bg-success/10 px-2.5 py-0.5 font-semibold text-success"
                        }
                      >
                        {seatsLeftLabel(t.seatsLeft)}
                      </span>
                    </dd>
                  </div>
                </dl>

                <div className="mt-auto pt-6">
                  {full ? (
                    <p className="btn w-full bg-line text-muted">Fully booked</p>
                  ) : (
                    <Link to={`/tastings/${t.id}/book`} className="btn btn-primary w-full">
                      Book {t.title}
                    </Link>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
