import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: { outDir: "dist/client", emptyOutDir: true },
  server: { proxy: { "/api": `http://localhost:${process.env.PORT ?? 3000}` } },
  test: { include: ["src/**/*.test.tsx", "server/**/*.test.ts"] },
});
