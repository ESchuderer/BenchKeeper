import { BrowserRouter, Link, Route, Routes } from 'react-router';
import TastingList from './pages/TastingList.jsx';
import BookingForm from './pages/BookingForm.jsx';
import Confirmation from './pages/Confirmation.jsx';
import StaffPage from './pages/StaffPage.jsx';

export default function App() {
  return (
    <BrowserRouter>
      <div className="flex min-h-screen flex-col">
        <header className="border-b border-wine/15 bg-parchment">
          <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-5 py-5">
            <Link to="/" className="font-serif text-2xl text-wine">
              Weingut Kieselbrunnen
            </Link>
            <Link to="/staff" className="text-sm font-medium text-ink/70 hover:text-wine">
              Staff
            </Link>
          </div>
        </header>
        <main className="mx-auto w-full max-w-4xl flex-1 px-5 py-10">
          <Routes>
            <Route path="/" element={<TastingList />} />
            <Route path="/tastings/:id/book" element={<BookingForm />} />
            <Route path="/bookings/:reference" element={<Confirmation />} />
            <Route path="/staff" element={<StaffPage />} />
          </Routes>
        </main>
        <footer className="border-t border-wine/15 px-5 py-6 text-center text-sm text-ink/60">
          Weingut Kieselbrunnen
        </footer>
      </div>
    </BrowserRouter>
  );
}
