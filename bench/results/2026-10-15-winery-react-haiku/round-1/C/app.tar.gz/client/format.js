const dateFormat = new Intl.DateTimeFormat('en-GB', {
  weekday: 'long',
  day: 'numeric',
  month: 'long',
  year: 'numeric',
  timeZone: 'UTC',
});

// Times are the winery's local time, so they are formatted without a time zone conversion.
export function formatDate(startsAt) {
  const [year, month, day] = startsAt.split('T')[0].split('-').map(Number);
  return dateFormat.format(new Date(Date.UTC(year, month - 1, day)));
}

export function formatTime(startsAt) {
  return startsAt.split('T')[1];
}
