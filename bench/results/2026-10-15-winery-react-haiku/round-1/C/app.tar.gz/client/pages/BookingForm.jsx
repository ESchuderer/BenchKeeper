import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { bookingSchema } from '../../shared/booking-schema.js';
import { api } from '../api.js';
import { formatDate, formatTime } from '../format.js';

function FieldError({ id, message }) {
  return message ? (
    <p id={id} role="alert" className="error-text">
      {message}
    </p>
  ) : null;
}

export default function BookingForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tasting, setTasting] = useState(undefined);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  });

  const loadTasting = () =>
    api('/tastings').then(({ ok, data }) => setTasting(ok ? (data.find((item) => item.id === id) ?? null) : null));

  useEffect(() => {
    loadTasting().catch(() => setTasting(null));
  }, [id]);

  if (tasting === undefined) return <p className="text-ink/70">Loading…</p>;

  if (tasting === null) {
    return (
      <section>
        <h1 className="font-serif text-3xl text-wine">Tasting not found</h1>
        <Link to="/" className="btn-secondary mt-6">
          Back to all tastings
        </Link>
      </section>
    );
  }

  const soldOut = tasting.seatsLeft === 0;

  const onSubmit = async (values) => {
    const { ok, data } = await api(`/tastings/${id}/bookings`, { method: 'POST', body: values });
    if (ok) return navigate(`/bookings/${data.reference}`);
    if (data?.errors) {
      for (const [field, message] of Object.entries(data.errors)) setError(field, { message });
    } else {
      setError('root', { message: data?.error ?? 'Something went wrong. Please try again.' });
    }
    loadTasting();
  };

  return (
    <section className="mx-auto max-w-xl">
      <Link to="/" className="text-sm font-medium text-wine hover:underline">
        ← All tastings
      </Link>
      <h1 className="mt-4 font-serif text-4xl text-wine">Book {tasting.title}</h1>
      <p className="mt-3 text-ink/75">
        {formatDate(tasting.startsAt)} at {formatTime(tasting.startsAt)} · EUR {tasting.pricePerGuest} per guest ·{' '}
        {tasting.seatsLeft} seats left
      </p>

      {soldOut ? (
        <p className="notice mt-8">This tasting is fully booked.</p>
      ) : (
        <form noValidate onSubmit={handleSubmit(onSubmit)} className="mt-8 space-y-6 rounded-lg border border-wine/15 bg-parchment p-6 shadow-sm">
          {errors.root && <p className="notice">{errors.root.message}</p>}

          <div>
            <label htmlFor="name" className="block text-sm font-semibold">Name</label>
            <input
              id="name"
              type="text"
              autoComplete="name"
              className="field mt-1.5"
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
              {...register('name')}
            />
            <FieldError id="name-error" message={errors.name?.message} />
          </div>

          <div>
            <label htmlFor="email" className="block text-sm font-semibold">Email</label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              className="field mt-1.5"
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
              {...register('email')}
            />
            <FieldError id="email-error" message={errors.email?.message} />
          </div>

          <div>
            <label htmlFor="guests" className="block text-sm font-semibold">Guests</label>
            <input
              id="guests"
              type="number"
              inputMode="numeric"
              min={1}
              max={8}
              className="field mt-1.5 sm:w-32"
              aria-invalid={Boolean(errors.guests)}
              aria-describedby={errors.guests ? 'guests-error' : undefined}
              {...register('guests')}
            />
            <FieldError id="guests-error" message={errors.guests?.message} />
          </div>

          <button type="submit" className="btn w-full sm:w-auto" disabled={isSubmitting}>
            Book
          </button>
        </form>
      )}
    </section>
  );
}
