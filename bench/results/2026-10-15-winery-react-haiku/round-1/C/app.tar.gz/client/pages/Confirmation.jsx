import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { api } from '../api.js';
import { formatDate, formatTime } from '../format.js';

export default function Confirmation() {
  const { reference } = useParams();
  const [booking, setBooking] = useState(undefined);

  useEffect(() => {
    api(`/bookings/${reference}`)
      .then(({ ok, data }) => setBooking(ok ? data : null))
      .catch(() => setBooking(null));
  }, [reference]);

  if (booking === undefined) return <p className="text-ink/70">Loading…</p>;

  if (booking === null) {
    return (
      <section>
        <h1 className="font-serif text-3xl text-wine">Booking not found</h1>
        <p className="mt-3 text-ink/75">No booking exists for this reference.</p>
        <Link to="/" className="btn-secondary mt-6">
          Back to all tastings
        </Link>
      </section>
    );
  }

  const { tasting } = booking;
  return (
    <section className="mx-auto max-w-xl">
      <h1 className="font-serif text-4xl text-wine">Booking confirmed</h1>
      <p className="mt-3 text-ink/75">Please keep your booking reference for your visit.</p>

      <dl className="mt-8 divide-y divide-wine/10 rounded-lg border border-wine/15 bg-parchment px-6 shadow-sm">
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-ink/60">Tasting</dt>
          <dd className="font-semibold">{tasting.title}</dd>
        </div>
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-ink/60">Date and time</dt>
          <dd>
            {formatDate(tasting.startsAt)}, {formatTime(tasting.startsAt)}
          </dd>
        </div>
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-ink/60">Guests</dt>
          <dd>{booking.guests}</dd>
        </div>
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-ink/60">Total</dt>
          <dd className="font-semibold">EUR {booking.total}</dd>
        </div>
        <div className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
          <dt className="text-ink/60">Booking reference</dt>
          <dd className="font-mono text-lg tracking-wider">{booking.reference}</dd>
        </div>
      </dl>

      <Link to="/" className="btn-secondary mt-8">
        Back to all tastings
      </Link>
    </section>
  );
}
