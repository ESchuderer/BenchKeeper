import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { formatDate, formatTime } from '../format.js';

function SignInForm({ onSignedIn }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const { ok, status, data } = await api('/staff/sign-in', { method: 'POST', body: { password } });
    setBusy(false);
    if (ok) return onSignedIn();
    if (status === 401) setError('Incorrect password');
    else if (status === 429) setError(data?.error);
    else setError('Sign-in failed. Please try again.');
    setPassword('');
  }

  return (
    <section className="mx-auto max-w-sm">
      <h1 className="font-serif text-4xl text-wine">Staff sign in</h1>
      <form noValidate onSubmit={submit} className="mt-8 space-y-6 rounded-lg border border-wine/15 bg-parchment p-6 shadow-sm">
        <div>
          <label htmlFor="password" className="block text-sm font-semibold">Password</label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className="field mt-1.5"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            aria-invalid={Boolean(error)}
            aria-describedby={error ? 'password-error' : undefined}
            required
          />
          {error && (
            <p id="password-error" role="alert" className="error-text">
              {error}
            </p>
          )}
        </div>
        <button type="submit" className="btn w-full" disabled={busy}>
          Sign in
        </button>
      </form>
    </section>
  );
}

export default function StaffPage() {
  const [groups, setGroups] = useState(undefined);
  const [notice, setNotice] = useState('');

  const load = () =>
    api('/staff/bookings')
      .then(({ ok, data }) => setGroups(ok ? data : null))
      .catch(() => setGroups(null));

  useEffect(() => {
    load();
  }, []);

  async function cancel(reference) {
    const { ok } = await api(`/staff/bookings/${reference}`, { method: 'DELETE' });
    setNotice(ok ? '' : 'The booking could not be cancelled.');
    load();
  }

  async function signOut() {
    await api('/staff/sign-out', { method: 'POST' });
    setGroups(null);
  }

  if (groups === undefined) return <p className="text-ink/70">Loading…</p>;
  if (groups === null) return <SignInForm onSignedIn={load} />;

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-serif text-4xl text-wine">Bookings</h1>
        <button type="button" className="btn-secondary" onClick={signOut}>
          Sign out
        </button>
      </div>

      {notice && <p className="notice mt-6">{notice}</p>}

      <div className="mt-8 space-y-8">
        {groups.map(({ tasting, bookings }) => (
          <section key={tasting.id} className="rounded-lg border border-wine/15 bg-parchment p-6 shadow-sm">
            <h2 className="font-serif text-2xl text-wine">{tasting.title}</h2>
            <p className="mt-1 text-sm text-ink/70">
              {formatDate(tasting.startsAt)}, {formatTime(tasting.startsAt)} · {tasting.seatsLeft} seats left
            </p>

            {bookings.length === 0 ? (
              <p className="mt-5 text-ink/65">No bookings yet.</p>
            ) : (
              <ul className="mt-5 divide-y divide-wine/10">
                {bookings.map((booking) => (
                  <li key={booking.reference} className="flex flex-wrap items-center justify-between gap-4 py-4">
                    <div className="min-w-0">
                      <p className="font-semibold">
                        {booking.name} <span className="font-normal text-ink/65">· {booking.guests} guests</span>
                      </p>
                      <p className="break-all text-sm text-ink/70">{booking.email}</p>
                      <p className="mt-1 font-mono text-sm tracking-wider text-wine">{booking.reference}</p>
                    </div>
                    <button type="button" className="btn-secondary" onClick={() => cancel(booking.reference)}>
                      Cancel
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </div>
    </section>
  );
}
