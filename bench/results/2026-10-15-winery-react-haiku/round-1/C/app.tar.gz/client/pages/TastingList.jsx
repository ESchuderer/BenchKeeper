import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { api } from '../api.js';
import { formatDate, formatTime } from '../format.js';

export default function TastingList() {
  const [tastings, setTastings] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api('/tastings')
      .then(({ ok, data }) => (ok ? setTastings(data) : setError('Tastings could not be loaded.')))
      .catch(() => setError('Tastings could not be loaded.'));
  }, []);

  return (
    <section>
      <h1 className="font-serif text-4xl text-wine">Wine tastings</h1>
      <p className="mt-3 max-w-prose text-ink/75">Choose a tasting and reserve your seats online.</p>

      {error && <p className="notice mt-8">{error}</p>}

      <ul className="mt-10 grid gap-6 sm:grid-cols-2">
        {tastings?.map((tasting) => {
          const soldOut = tasting.seatsLeft === 0;
          const fewLeft = !soldOut && tasting.seatsLeft <= 3;
          return (
            <li key={tasting.id} className="flex flex-col rounded-lg border border-wine/15 bg-parchment p-6 shadow-sm">
              <h2 className="font-serif text-2xl text-wine">{tasting.title}</h2>
              <dl className="mt-4 space-y-1.5 text-sm text-ink/80">
                <div className="flex gap-2">
                  <dt className="w-16 shrink-0 text-ink/55">Date</dt>
                  <dd>{formatDate(tasting.startsAt)}</dd>
                </div>
                <div className="flex gap-2">
                  <dt className="w-16 shrink-0 text-ink/55">Time</dt>
                  <dd>{formatTime(tasting.startsAt)}</dd>
                </div>
                <div className="flex gap-2">
                  <dt className="w-16 shrink-0 text-ink/55">Price</dt>
                  <dd>EUR {tasting.pricePerGuest} per guest</dd>
                </div>
              </dl>
              <div className="mt-5">
                <span
                  className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${
                    soldOut
                      ? 'bg-stone-200 text-stone-700'
                      : fewLeft
                        ? 'bg-amber-100 text-amber-900'
                        : 'bg-vine/10 text-vine'
                  }`}
                >
                  {tasting.seatsLeft} seats left
                </span>
              </div>
              <div className="mt-auto pt-6">
                {soldOut ? (
                  <button type="button" className="btn w-full" disabled>
                    Fully booked
                  </button>
                ) : (
                  <Link to={`/tastings/${tasting.id}/book`} className="btn w-full">
                    Book {tasting.title}
                  </Link>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
