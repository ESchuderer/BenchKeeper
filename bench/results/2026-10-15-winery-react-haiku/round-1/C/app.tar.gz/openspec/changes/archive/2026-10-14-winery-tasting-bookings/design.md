# Design

## Context

The repository has no application code yet, only `AGENTS.md`, the OpenSpec setup and the devcontainer (Node.js 22). The app must run with `npm install`, `npm run build`, `npm start`, serve on `PORT`, and use no external services. See proposal.md for motivation and specs/ for the behavior contract.

## Goals / Non-Goals

**Goals:**
- One Node process serves the JSON API and the built React client.
- Validation rules are written once and used by both the form and the server.
- Seat accounting is correct under concurrent requests.

**Non-Goals:**
- Persistence across restarts, payments, email, accounts for guests, admin editing of tastings, internationalization.

## Decisions

- **Server: Express 5.** Serves `/api/*` and the static `dist/` build, with a fallback to `index.html` for client routes. Alternative: Next.js, rejected because it adds a second framework layer for a three-page app.
- **Client: React 19 with Vite 8 and react-router.** Vite builds the SPA. react-router maps `/`, `/tastings/:id/book`, `/bookings/:reference` and `/staff`.
- **Forms: react-hook-form with `@hookform/resolvers` and zod.** The zod schema for a booking lives in `shared/booking-schema.js` and is imported by both client and server. The seat limit cannot be in the shared schema because it needs server state; the server checks it in the same synchronous step as the reservation.
- **Styling: Tailwind CSS 4 via `@tailwindcss/vite`.** Theme colors and fonts are defined once in the CSS entry file.
- **Storage: in-memory array in `server/store.js`.** Node runs JavaScript on one thread, so the check "guests <= seats left" followed by the push is atomic without locks. The store is created per app instance so tests start empty.
- **Staff sessions: random 32-byte tokens in a `Map` with an expiry time.** Cookie name `staff_session`, set with `httpOnly: true`, `sameSite: 'strict'`, `secure: req.secure`. `req.secure` depends on the `trust proxy` setting. The environment variable `TRUST_PROXY` is the number of reverse proxies in front of the app (default 0). Set it to 1 behind one TLS-terminating proxy; a higher value is needed only for a chain of proxies. A non-zero value makes the client address and protocol come from headers the proxy appends.
- **Failed sign-in limit: in-memory counter per client IP** (`req.ip`), 5 failures within 15 minutes starts a 15-minute lockout. The counter entry is removed when the lockout ends or the window expires.
- **Password comparison: `crypto.timingSafeEqual` on SHA-256 digests** so the comparison time does not depend on the password length.
- **Booking reference: `KB-` plus 6 characters** from an alphabet without 0, O, 1, I, drawn with `crypto.randomInt`. Regenerated on the rare collision.
- **Time handling: tasting times are stored as written in the winery's local time** (`2026-11-06T18:00`, no time zone). They are formatted in UTC with no conversion, which keeps the displayed time identical to the stored time.
- **Errors:** validation failures return `400 { errors: { <field>: message } }`. Seat-limit and fully-booked failures return `409 { errors: { guests: message } }`. Unknown tasting or booking returns `404 { error }`.
- **Security headers: helmet.** Request bodies are limited with `express.json({ limit: '4kb' })`.
- **Cookies: cookie-parser** (Express 5 does not parse cookies).

## API

| Method | Path | Auth | Response |
|---|---|---|---|
| GET | `/api/tastings` | none | list with `seatsLeft` |
| POST | `/api/tastings/:id/bookings` | none | `201 { reference }`; `400 { errors }`; `409 { errors: { guests } }` |
| GET | `/api/bookings/:reference` | none | `{ reference, tasting, guests, total }` without name or email |
| POST | `/api/staff/sign-in` | none | `204` and cookie; `401` wrong or unset password; `429` locked out |
| POST | `/api/staff/sign-out` | cookie | `204` |
| GET | `/api/staff/bookings` | staff | tastings with their bookings; `401` otherwise |
| DELETE | `/api/staff/bookings/:reference` | staff | `204`; `404` if unknown; `401` otherwise |

## Risks / Trade-offs

- [Restart loses all bookings] → Accepted by the requirement that the app starts with no bookings; a file store can be added later behind `server/store.js`.
- [Per-IP lockout behind a shared proxy locks out all staff] → `TRUST_PROXY` makes `req.ip` the forwarded client address; without it all clients share the proxy address.
- [Sessions are lost on restart] → Staff sign in again after a restart; acceptable for a single-process app.
- [Shared password for all staff] → Matches the requirement; no per-person accounts.

## Migration Plan

None. The repository has no existing application to migrate. Rollback is removing the commit.

## Open Questions

None.
