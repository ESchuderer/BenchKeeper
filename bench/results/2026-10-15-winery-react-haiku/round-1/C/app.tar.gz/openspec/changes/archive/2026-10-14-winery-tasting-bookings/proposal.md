# Proposal

## Why

Guests of Weingut Kieselbrunnen cannot book wine tastings online, and staff have no place to see who is coming. This change adds a booking web app for the three scheduled tastings, with a staff page to review and cancel bookings.

## What Changes

- Start page lists the tastings with title, date and time, price per guest and seats left.
- Each tasting has a "Book <tasting title>" link that opens a booking form (Name, Email, Guests 1 to 8).
- A booking cannot exceed the seats left. Invalid input is rejected with a message next to the field.
- After booking, the guest sees "Booking confirmed" with the tasting, guest count, total price and booking reference.
- `/staff` asks for the password from `STAFF_PASSWORD`. Signed-in staff see bookings grouped by tasting and can cancel a booking, which frees its seats.
- Bookings are kept in memory. The app starts with no bookings.

## Capabilities

### New Capabilities

- `tasting-bookings`: Listing tastings with seat availability, and guests booking seats with validation and a confirmation.
- `staff-access`: Staff sign-in with a shared password, session expiry, sign-out and a limit on failed sign-in attempts.
- `staff-bookings`: Staff view of all bookings grouped by tasting, and cancellation of a booking.

### Modified Capabilities

None. `openspec/specs/` is empty.

## Impact

- New application code: an Express server (JSON API and static file serving) and a React single-page client.
- New dependencies: express, react, react-dom, react-router, react-hook-form, zod, @hookform/resolvers, vite, @vitejs/plugin-react, tailwindcss, @tailwindcss/vite.
- New environment variables: `STAFF_PASSWORD` (required for staff sign-in), `PORT` (default 3000).
- No external services, no database, no payments.
