# Spec Delta

## Purpose

Restricts the staff area to people who know the staff password, keeps staff sessions short-lived, and slows down password guessing. Staff sign-in is the only access control in the application.

## ADDED Requirements

### Requirement: Staff sign-in page
The system SHALL show a sign-in form at `/staff` with a "Password" field and a "Sign in" button to any visitor who is not signed in.

#### Scenario: Signed-out visitor
- **WHEN** a visitor without a staff session opens `/staff`
- **THEN** the page shows the "Password" field and the "Sign in" button and no booking data

### Requirement: Password check
The system SHALL compare the submitted password with the value of the environment variable `STAFF_PASSWORD`. A correct password SHALL start a staff session. An incorrect password SHALL show the error message "Incorrect password" next to the "Password" field and SHALL NOT start a session. When `STAFF_PASSWORD` is unset or empty, every sign-in SHALL be refused.

#### Scenario: Correct password
- **WHEN** a visitor submits the value of `STAFF_PASSWORD`
- **THEN** a staff session is started and the bookings page is shown

#### Scenario: Wrong password
- **WHEN** a visitor submits a password that differs from `STAFF_PASSWORD`
- **THEN** the error message "Incorrect password" is shown next to the "Password" field and no session is started

#### Scenario: Password not configured
- **WHEN** `STAFF_PASSWORD` is unset and a visitor submits any password
- **THEN** the sign-in is refused and no session is started

### Requirement: Session expiry
The system SHALL end a staff session 8 hours after it was started. After expiry, staff pages and staff data SHALL require signing in again.

#### Scenario: Session expires
- **WHEN** a staff session was started 8 hours and 1 second ago and the visitor opens `/staff`
- **THEN** the sign-in form is shown and no booking data is returned

### Requirement: Sign out
The system SHALL end the staff session when the staff user activates "Sign out", and the session SHALL NOT be usable afterwards.

#### Scenario: Sign out
- **WHEN** a signed-in staff user activates "Sign out"
- **THEN** the sign-in form is shown and a request that presents the former session cookie is refused

### Requirement: Failed sign-in limit
The system SHALL refuse sign-in attempts from a client for 15 minutes after 5 failed attempts from that client within 15 minutes, and SHALL show the message "Too many failed attempts. Try again later." Attempts refused for this reason SHALL NOT be checked against the password.

#### Scenario: Lockout after five failures
- **WHEN** a client submits 5 wrong passwords within 15 minutes
- **THEN** the client's next sign-in attempt, even with the correct password, is refused with "Too many failed attempts. Try again later."

#### Scenario: Lockout ends
- **WHEN** 15 minutes have passed since the lockout started and the client submits the correct password
- **THEN** a staff session is started

### Requirement: Session cookie attributes
The system SHALL set the staff session cookie with the attributes HttpOnly and SameSite=Strict. The system SHALL also set the Secure attribute when the request was served over HTTPS.

#### Scenario: Cookie over HTTPS
- **WHEN** a staff user signs in over HTTPS
- **THEN** the session cookie is sent with HttpOnly, SameSite=Strict and Secure

#### Scenario: Cookie over HTTP
- **WHEN** a staff user signs in over plain HTTP on localhost
- **THEN** the session cookie is sent with HttpOnly and SameSite=Strict and without Secure
