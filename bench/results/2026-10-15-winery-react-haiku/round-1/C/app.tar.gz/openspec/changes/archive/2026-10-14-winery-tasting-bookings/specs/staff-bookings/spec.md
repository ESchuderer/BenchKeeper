# Spec Delta

## Purpose

Lets signed-in staff see every booking grouped by tasting and cancel a booking, so the seats it held become available to guests again.

## ADDED Requirements

### Requirement: Booking overview
The system SHALL show signed-in staff all bookings grouped by tasting. Each booking SHALL show the guest's name, email, number of guests and booking reference. Tastings without bookings SHALL still be shown with an empty list.

#### Scenario: Bookings grouped by tasting
- **WHEN** staff are signed in and "Anna Keller" booked 2 guests for "Riesling Evening" with reference "KB-7F3K9Q"
- **THEN** under the heading "Riesling Evening" the page shows "Anna Keller", her email, "2" guests and reference "KB-7F3K9Q"

#### Scenario: Tasting without bookings
- **WHEN** staff are signed in and no booking exists for "Winter Tasting"
- **THEN** the page shows the "Winter Tasting" heading with no bookings listed under it

### Requirement: Cancel a booking
The system SHALL show a "Cancel" button for every booking on the staff page. Activating it SHALL remove the booking, and the seats it held SHALL become available for new bookings immediately.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 3 guests for "Riesling Evening" that was made when 9 seats were left
- **THEN** the booking no longer appears on the staff page and the start page shows "12 seats left" for "Riesling Evening"

#### Scenario: Cancelled booking reference
- **WHEN** staff cancel a booking and a guest later requests its confirmation by reference
- **THEN** the system reports that no such booking exists

### Requirement: Staff data requires sign-in
The system SHALL return booking data and accept cancellations only from a request with a valid staff session. Other requests SHALL be refused without revealing any booking data.

#### Scenario: Unauthenticated request for bookings
- **WHEN** a request without a valid staff session asks for the staff booking data
- **THEN** the request is refused and no booking data is returned

#### Scenario: Unauthenticated cancellation
- **WHEN** a request without a valid staff session tries to cancel a booking
- **THEN** the request is refused and the booking still exists
