# Tasks

## 1. Project setup
- [x] 1.1 Add `package.json` with scripts `build` (vite build), `start` (node server/index.js), `test` (node --test on test/**/*.test.js); install the dependencies listed in design.md
- [x] 1.2 Add `vite.config.js` (React plugin, Tailwind plugin), `index.html`, `.gitignore` (node_modules, dist)

## 2. Shared rules and catalog
- [x] 2.1 Write failing tests for `shared/booking-schema.js`: empty name, invalid email, guests 0, 9, 1.5, valid input
- [x] 2.2 Implement `shared/booking-schema.js` (zod) and make 2.1 pass
- [x] 2.3 Add `server/tastings.js` with the three tastings (id, title, date, time, price, seats)

## 3. Bookings store and API (tasting-bookings, staff-bookings)
- [x] 3.1 Write failing tests: list shows seats left; booking reduces seats; seat limit rejects with 409 and no booking; last seats book; fully booked returns 409 "This tasting is fully booked"; invalid input returns 400 with field errors; concurrent bookings (two `Promise.all` requests) create exactly one; confirmation by reference has no name or email; unknown tasting 404
- [x] 3.2 Implement `server/store.js` (in-memory bookings, seats left, unique reference generation) and the public routes in `server/app.js`; make 3.1 pass
- [x] 3.3 Write failing tests: cancel frees seats and the reference then returns 404
- [x] 3.4 Implement `DELETE /api/staff/bookings/:reference` and `GET /api/staff/bookings` (grouped) behind the staff guard; make 3.3 pass

## 4. Staff access (staff-access)
- [x] 4.1 Write failing tests with injected clock: correct password sets cookie with HttpOnly and SameSite=Strict; wrong password 401; unset password refuses; session expires after 8 hours; sign-out invalidates the cookie; 5 failures lock out for 15 minutes including correct password; lockout ends; Secure set only over HTTPS (set `TRUST_PROXY` in the test app and send `X-Forwarded-Proto: https`); staff routes return 401 without a session
- [x] 4.2 Implement `server/staff-auth.js` (sessions, lockout, digest comparison) and the sign-in, sign-out and guard middleware in `server/app.js`; make 4.1 pass
- [x] 4.3 Add `server/index.js`: reads `PORT` (default 3000), `STAFF_PASSWORD` (warn at startup when unset), `TRUST_PROXY`; serves `dist/` with `index.html` fallback; unknown `/api` paths return 404 JSON; helmet and body limit

## 5. Client (tasting-bookings, staff-access, staff-bookings)
- [x] 5.1 Add `client/main.jsx`, `client/App.jsx` (routes, header with "Weingut Kieselbrunnen", footer), `client/api.js` (fetch wrapper), `client/index.css` (Tailwind import, theme colors, fonts)
- [x] 5.2 Add `client/pages/TastingList.jsx`: cards with title, date and time, price per guest, "<n> seats left", "Book <title>" link or "Fully booked" state
- [x] 5.3 Add `client/pages/BookingForm.jsx`: Name, Email, Guests fields via react-hook-form with zodResolver; field errors next to each field (aria-invalid, aria-describedby); server errors mapped to fields; "Book" button; fully booked state
- [x] 5.4 Add `client/pages/Confirmation.jsx`: "Booking confirmed" heading, tasting, guests, total "EUR <n>", reference; loads by reference so reload works
- [x] 5.5 Add `client/pages/StaffPage.jsx`: sign-in form ("Password", "Sign in"), error messages, bookings grouped by tasting with name, email, guests, reference and "Cancel" buttons, "Sign out"

## 6. Verify
- [x] 6.1 `npm test` and `npm run build` pass
- [x] 6.2 `npm start` with `PORT` and `STAFF_PASSWORD` set; check each page and flow in the browser with Playwright MCP (desktop and 375 px width): booking, errors, fully booked, confirmation, staff sign-in, cancel, sign-out
- [x] 6.3 `openspec validate winery-tasting-bookings --strict` passes

## 7. Review and archive
- [x] 7.1 Review the diff for correctness and security (`code-review-and-quality`, `security-and-hardening`) and fix findings
- [x] 7.2 Commit by task group with Conventional Commits messages
- [x] 7.3 Archive the change with `openspec-archive-change` on this branch
