# tasting-bookings Specification

## Purpose
Lets guests see the scheduled wine tastings with their seat availability and book seats for one of them online, with a confirmation that carries the booking reference.

## Requirements

### Requirement: Tasting list
The system SHALL show every tasting on the start page with its title, date and time, price per guest in EUR, and seats left shown as "<n> seats left".

#### Scenario: Tastings listed with seats left
- **WHEN** a guest opens the start page and no bookings exist
- **THEN** the page lists "Riesling Evening" on Friday 6 November 2026 at 18:00 for EUR 25 with "12 seats left", "Red Wine Cellar Tour" on Saturday 14 November 2026 at 15:00 for EUR 32 with "8 seats left", and "Winter Tasting" on Saturday 5 December 2026 at 17:00 for EUR 28 with "10 seats left"

#### Scenario: Seats left reflect bookings
- **WHEN** a booking for 3 guests exists for "Riesling Evening"
- **THEN** the start page shows "9 seats left" for "Riesling Evening"

### Requirement: Booking link per tasting
The system SHALL give each tasting with seats left a "Book <tasting title>" link that opens the booking form for that tasting.

#### Scenario: Open booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for "Riesling Evening" opens, with the fields "Name", "Email" and "Guests" and a "Book" button

#### Scenario: Fully booked tasting
- **WHEN** a tasting has 0 seats left
- **THEN** the start page shows "Fully booked" for that tasting instead of a booking link, and the booking form for that tasting does not accept a booking

### Requirement: Input validation
The system SHALL reject a booking with an error message shown next to the field it concerns when the name is empty, the email is not a valid address, or the guests value is not a whole number from 1 to 8. A rejected booking SHALL NOT reserve any seats.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty "Name"
- **THEN** the error message is shown next to the "Name" field and no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits "Email" with the value "anna@"
- **THEN** the error message is shown next to the "Email" field and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits "Guests" with the value 0 or 9
- **THEN** the error message is shown next to the "Guests" field and no booking is created

### Requirement: Seat limit
The system SHALL reject a booking whose guests value is greater than the seats left for that tasting, with an error message shown next to the "Guests" field stating the seats left. The seat check and the reservation SHALL be applied atomically, so concurrent bookings never exceed the seats of a tasting.

#### Scenario: More guests than seats left
- **WHEN** 2 seats are left for a tasting and a guest submits 3 guests
- **THEN** the error message "Only 2 seats left" is shown next to the "Guests" field and no booking is created

#### Scenario: Last seats booked
- **WHEN** 2 seats are left for a tasting and a guest submits 2 guests
- **THEN** the booking is created and the tasting shows "Fully booked" afterwards

#### Scenario: Concurrent bookings
- **WHEN** two bookings of 2 guests each are submitted at the same time for a tasting with 3 seats left
- **THEN** exactly one booking is created and the other is rejected with an error next to the "Guests" field

### Requirement: Booking confirmation
The system SHALL show, after a successful booking, a page with the heading "Booking confirmed", the tasting title, the number of guests, the total price in EUR (guests multiplied by the price per guest) and a booking reference that is unique among all bookings.

#### Scenario: Confirmation shown
- **WHEN** a guest books 2 guests for "Winter Tasting"
- **THEN** the page shows the heading "Booking confirmed", "Winter Tasting", 2 guests, a total of "EUR 56" and a booking reference

#### Scenario: Confirmation after reload
- **WHEN** a guest reloads the confirmation page
- **THEN** the same tasting, guests, total and booking reference are shown
