import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: 'test/e2e',
  workers: 1,
  use: { baseURL: 'http://127.0.0.1:3200' },
  webServer: {
    command: 'npm run build && npm start',
    url: 'http://127.0.0.1:3200/api/tastings',
    env: { PORT: '3200', STAFF_PASSWORD: 'e2e-staff-pass' },
    reuseExistingServer: false,
  },
});
