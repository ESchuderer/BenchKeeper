import path from 'node:path';
import express from 'express';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { bookingSchema } from '../shared/booking-schema.js';
import { tastings as catalog } from './tastings.js';
import { createStore } from './store.js';
import { SESSION_MS, createStaffAuth } from './staff-auth.js';

const SESSION_COOKIE = 'staff_session';

function fieldErrors(error) {
  const errors = {};
  for (const issue of error.issues) {
    errors[issue.path[0]] ??= issue.message;
  }
  return errors;
}

// trustProxy is the number of reverse proxies in front of the app (0 = none).
export function createApp({ staffPassword, now = Date.now, trustProxy = 0, tastings = catalog, distDir } = {}) {
  const app = express();
  const store = createStore(tastings);
  const auth = createStaffAuth({ password: staffPassword, now });
  const cookieOptions = (req) => ({ httpOnly: true, sameSite: 'strict', secure: req.secure, path: '/' });

  app.set('trust proxy', trustProxy);
  app.use(helmet());
  app.use(express.json({ limit: '4kb' }));
  app.use(cookieParser());

  const requireStaff = (req, res, next) => {
    if (auth.isValidSession(req.cookies[SESSION_COOKIE])) return next();
    res.status(401).json({ error: 'Sign in as staff first' });
  };

  app.get('/api/tastings', (req, res) => {
    res.json(store.listTastings());
  });

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const tasting = store.findTasting(req.params.id);
    if (!tasting) return res.status(404).json({ error: 'Tasting not found' });

    const parsed = bookingSchema.safeParse(req.body ?? {});
    if (!parsed.success) return res.status(400).json({ errors: fieldErrors(parsed.error) });

    const result = store.book(tasting, parsed.data);
    if (result.error) return res.status(409).json({ errors: { guests: result.error } });
    res.status(201).json({ reference: result.booking.reference });
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const booking = store.findBooking(req.params.reference);
    if (!booking) return res.status(404).json({ error: 'Booking not found' });
    const { id, title, startsAt, pricePerGuest } = store.findTasting(booking.tastingId);
    res.json({
      reference: booking.reference,
      tasting: { id, title, startsAt },
      guests: booking.guests,
      total: booking.guests * pricePerGuest,
    });
  });

  app.post('/api/staff/sign-in', (req, res) => {
    const result = auth.signIn(req.ip, req.body?.password);
    if (result.error === 'locked') {
      return res.status(429).json({ error: 'Too many failed attempts. Try again later.' });
    }
    if (result.error === 'wrong') return res.status(401).json({ error: 'Incorrect password' });
    res.cookie(SESSION_COOKIE, result.token, { ...cookieOptions(req), maxAge: SESSION_MS });
    res.status(204).end();
  });

  app.post('/api/staff/sign-out', (req, res) => {
    auth.endSession(req.cookies[SESSION_COOKIE]);
    res.clearCookie(SESSION_COOKIE, cookieOptions(req));
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (req, res) => {
    res.json(
      store.listTastings().map((tasting) => ({
        tasting,
        bookings: store.bookingsFor(tasting.id).map(({ reference, name, email, guests }) => ({
          reference,
          name,
          email,
          guests,
        })),
      })),
    );
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(req.params.reference)) return res.status(404).json({ error: 'Booking not found' });
    res.status(204).end();
  });

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

  if (distDir) {
    app.use(express.static(distDir));
    app.get(/^(?!\/api\/).*/, (req, res) => res.sendFile(path.join(distDir, 'index.html')));
  }

  app.use((err, req, res, next) => {
    res.status(err.status ?? 500).json({ error: err.status < 500 ? 'Invalid request' : 'Server error' });
  });

  return app;
}
