import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';

const distDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');
const staffPassword = process.env.STAFF_PASSWORD;
const port = Number(process.env.PORT ?? 3000);

if (!staffPassword) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
if (!existsSync(distDir)) console.warn('dist/ not found: run npm run build before npm start.');

const app = createApp({
  staffPassword,
  trustProxy: Number(process.env.TRUST_PROXY ?? 0),
  distDir,
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen listening on port ${port}`);
});
