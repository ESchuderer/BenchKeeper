import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const SESSION_MS = 8 * 60 * 60 * 1000;
const LOCKOUT_WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILURES = 5;

// Hashing both sides gives equal-length buffers for timingSafeEqual.
const digest = (value) => createHash('sha256').update(value).digest();

export function createStaffAuth({ password, now }) {
  const sessions = new Map(); // token -> expiry time
  const failures = new Map(); // client address -> { failedAt: [], lockedUntil }

  function checkPassword(submitted) {
    if (!password || typeof submitted !== 'string') return false;
    return timingSafeEqual(digest(submitted), digest(password));
  }

  function isLockedOut(client) {
    const record = failures.get(client);
    return Boolean(record && now() < record.lockedUntil);
  }

  return {
    signIn(client, submitted) {
      if (isLockedOut(client)) return { error: 'locked' };
      if (!checkPassword(submitted)) {
        const time = now();
        for (const [address, old] of failures) {
          if (time >= old.lockedUntil && old.failedAt.every((at) => at <= time - LOCKOUT_WINDOW_MS)) {
            failures.delete(address);
          }
        }
        const record = failures.get(client) ?? { failedAt: [], lockedUntil: 0 };
        record.failedAt = record.failedAt.filter((at) => at > time - LOCKOUT_WINDOW_MS).concat(time);
        if (record.failedAt.length >= MAX_FAILURES) {
          record.lockedUntil = time + LOCKOUT_WINDOW_MS;
          record.failedAt = [];
        }
        failures.set(client, record);
        return { error: 'wrong' };
      }
      failures.delete(client);
      const token = randomBytes(32).toString('base64url');
      for (const [expired, expiresAt] of sessions) {
        if (now() >= expiresAt) sessions.delete(expired);
      }
      sessions.set(token, now() + SESSION_MS);
      return { token };
    },

    isValidSession(token) {
      const expiresAt = sessions.get(token);
      if (expiresAt === undefined) return false;
      if (now() < expiresAt) return true;
      sessions.delete(token);
      return false;
    },

    endSession(token) {
      sessions.delete(token);
    },
  };
}
