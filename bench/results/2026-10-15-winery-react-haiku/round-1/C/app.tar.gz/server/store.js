import { randomInt } from 'node:crypto';

// Letters and digits without I, O, 0 and 1, so references read unambiguously.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function randomReference() {
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += ALPHABET[randomInt(ALPHABET.length)];
  }
  return `KB-${code}`;
}

export function createStore(tastings) {
  const bookings = [];
  const issued = new Set(); // includes cancelled references, so a reference is never reused

  const seatsBooked = (tastingId) =>
    bookings.filter((booking) => booking.tastingId === tastingId).reduce((sum, booking) => sum + booking.guests, 0);

  const seatsLeft = (tasting) => tasting.seats - seatsBooked(tasting.id);

  return {
    listTastings: () => tastings.map((tasting) => ({ ...tasting, seatsLeft: seatsLeft(tasting) })),
    findTasting: (id) => tastings.find((tasting) => tasting.id === id),
    findBooking: (reference) => bookings.find((booking) => booking.reference === reference),
    bookingsFor: (tastingId) => bookings.filter((booking) => booking.tastingId === tastingId),

    // Check and insert run in one synchronous step, so concurrent requests cannot oversell.
    book(tasting, { name, email, guests }) {
      const left = seatsLeft(tasting);
      if (guests > left) {
        return { error: left === 0 ? 'This tasting is fully booked' : `Only ${left} seats left` };
      }
      let reference = randomReference();
      while (issued.has(reference)) {
        reference = randomReference();
      }
      issued.add(reference);
      const booking = { reference, tastingId: tasting.id, name, email, guests };
      bookings.push(booking);
      return { booking };
    },

    cancel(reference) {
      const index = bookings.findIndex((booking) => booking.reference === reference);
      if (index === -1) return false;
      bookings.splice(index, 1);
      return true;
    },
  };
}
