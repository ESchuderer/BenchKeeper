import { z } from 'zod';

const guestsMessage = 'Choose 1 to 8 guests';

export const bookingSchema = z.object({
  name: z.string('Enter your name').trim().min(1, 'Enter your name').max(100, 'Use at most 100 characters'),
  email: z.string('Enter a valid email address').trim().pipe(z.email('Enter a valid email address')),
  // Only plain decimal digits are converted from strings, so "0x3" or "1e0" are rejected.
  guests: z.preprocess(
    (value) => (typeof value === 'string' && /^\s*\d+\s*$/.test(value) ? Number(value) : value),
    z.number(guestsMessage).int(guestsMessage).min(1, guestsMessage).max(8, guestsMessage),
  ),
});
