import { test } from 'node:test';
import assert from 'node:assert/strict';
import { bookingSchema } from '../shared/booking-schema.js';

const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function errorPaths(input) {
  const result = bookingSchema.safeParse(input);
  assert.equal(result.success, false);
  return result.error.issues.map((issue) => issue.path[0]);
}

test('accepts a complete booking', () => {
  const result = bookingSchema.safeParse(valid);
  assert.equal(result.success, true);
  assert.equal(result.data.guests, 2);
});

test('accepts guests sent as a string from a form field', () => {
  const result = bookingSchema.safeParse({ ...valid, guests: '8' });
  assert.equal(result.success, true);
  assert.equal(result.data.guests, 8);
});

test('rejects an empty or blank name', () => {
  assert.deepEqual(errorPaths({ ...valid, name: '' }), ['name']);
  assert.deepEqual(errorPaths({ ...valid, name: '   ' }), ['name']);
});

test('rejects an invalid email address', () => {
  assert.deepEqual(errorPaths({ ...valid, email: 'anna@' }), ['email']);
  assert.deepEqual(errorPaths({ ...valid, email: '' }), ['email']);
});

test('rejects guests that are not plain whole numbers', () => {
  assert.deepEqual(errorPaths({ ...valid, guests: '0x3' }), ['guests']);
  assert.deepEqual(errorPaths({ ...valid, guests: '1e0' }), ['guests']);
  assert.deepEqual(errorPaths({ ...valid, guests: true }), ['guests']);
  assert.deepEqual(errorPaths({ ...valid, guests: [2] }), ['guests']);
});

test('rejects guests outside 1 to 8 and non-whole numbers', () => {
  assert.deepEqual(errorPaths({ ...valid, guests: 0 }), ['guests']);
  assert.deepEqual(errorPaths({ ...valid, guests: 9 }), ['guests']);
  assert.deepEqual(errorPaths({ ...valid, guests: 1.5 }), ['guests']);
  assert.deepEqual(errorPaths({ ...valid, guests: '' }), ['guests']);
});
