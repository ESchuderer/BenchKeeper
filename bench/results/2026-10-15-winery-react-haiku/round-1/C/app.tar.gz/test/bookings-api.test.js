import { test } from 'node:test';
import assert from 'node:assert/strict';
import { request, startServer } from './helpers.js';

async function start(t, options = {}) {
  const { base, close } = await startServer({ staffPassword: 'test-password', ...options });
  t.after(close);
  return base;
}

function book(base, tastingId, body) {
  return request(base, `/api/tastings/${tastingId}/bookings`, { method: 'POST', body });
}

const guest = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

test('lists the tastings with their seats left', async (t) => {
  const base = await start(t);
  const res = await request(base, '/api/tastings');
  assert.equal(res.status, 200);
  assert.deepEqual(
    res.body.map((tasting) => [tasting.title, tasting.startsAt, tasting.pricePerGuest, tasting.seatsLeft]),
    [
      ['Riesling Evening', '2026-11-06T18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14T15:00', 32, 8],
      ['Winter Tasting', '2026-12-05T17:00', 28, 10],
    ],
  );
});

test('a booking reduces the seats left', async (t) => {
  const base = await start(t);
  const res = await book(base, 'riesling-evening', { ...guest, guests: 3 });
  assert.equal(res.status, 201);
  const tastings = await request(base, '/api/tastings');
  assert.equal(tastings.body[0].seatsLeft, 9);
});

test('rejects more guests than seats left and books nothing', async (t) => {
  const base = await start(t);
  await book(base, 'winter-tasting', { ...guest, guests: 8 });
  const res = await book(base, 'winter-tasting', { ...guest, guests: 3 });
  assert.equal(res.status, 409);
  assert.deepEqual(res.body, { errors: { guests: 'Only 2 seats left' } });
  const tastings = await request(base, '/api/tastings');
  assert.equal(tastings.body[2].seatsLeft, 2);
});

test('books the last seats and then reports the tasting as fully booked', async (t) => {
  const base = await start(t);
  assert.equal((await book(base, 'red-wine-cellar-tour', { ...guest, guests: 8 })).status, 201);
  const res = await book(base, 'red-wine-cellar-tour', { ...guest, guests: 1 });
  assert.equal(res.status, 409);
  assert.deepEqual(res.body, { errors: { guests: 'This tasting is fully booked' } });
});

test('concurrent bookings never exceed the seats of a tasting', async (t) => {
  const base = await start(t);
  await book(base, 'winter-tasting', { ...guest, guests: 7 });
  const results = await Promise.all([
    book(base, 'winter-tasting', { ...guest, guests: 2 }),
    book(base, 'winter-tasting', { ...guest, guests: 2 }),
  ]);
  assert.deepEqual(results.map((res) => res.status).sort(), [201, 409]);
  const tastings = await request(base, '/api/tastings');
  assert.equal(tastings.body[2].seatsLeft, 1);
});

test('invalid input returns an error for each field and books nothing', async (t) => {
  const base = await start(t);
  const res = await book(base, 'riesling-evening', { name: '', email: 'anna@', guests: 9 });
  assert.equal(res.status, 400);
  assert.deepEqual(Object.keys(res.body.errors).sort(), ['email', 'guests', 'name']);
  const tastings = await request(base, '/api/tastings');
  assert.equal(tastings.body[0].seatsLeft, 12);
});

test('an unknown tasting returns 404', async (t) => {
  const base = await start(t);
  const res = await book(base, 'no-such-tasting', guest);
  assert.equal(res.status, 404);
});

test('the confirmation carries the tasting, guests, total and reference without personal data', async (t) => {
  const base = await start(t);
  const created = await book(base, 'winter-tasting', guest);
  assert.equal(created.status, 201);
  assert.match(created.body.reference, /^KB-[A-HJ-NP-Z2-9]{6}$/);

  const res = await request(base, `/api/bookings/${created.body.reference}`);
  assert.equal(res.status, 200);
  assert.deepEqual(res.body, {
    reference: created.body.reference,
    tasting: { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00' },
    guests: 2,
    total: 56,
  });
  assert.ok(!JSON.stringify(res.body).includes('anna@example.com'));
});

test('an unknown booking reference returns 404', async (t) => {
  const base = await start(t);
  const res = await request(base, '/api/bookings/KB-AAAAAA');
  assert.equal(res.status, 404);
});
