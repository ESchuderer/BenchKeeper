import { test, expect } from '@playwright/test';

// Serial: the steps share one server, so later steps depend on earlier bookings.
test.describe.configure({ mode: 'serial' });

test('start page lists tastings with seats left', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
  await expect(page.getByText('12 seats left')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Book Riesling Evening' })).toBeVisible();
});

test('invalid input shows an error next to each field', async ({ page }) => {
  await page.goto('/tastings/riesling-evening/book');
  await page.getByLabel('Email').fill('anna@');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Name')).toHaveAttribute('aria-invalid', 'true');
  await expect(page.getByRole('alert').filter({ hasText: 'Enter your name' })).toBeVisible();
  await expect(page.getByRole('alert').filter({ hasText: 'Enter a valid email address' })).toBeVisible();
  await expect(page.getByRole('alert').filter({ hasText: 'Choose 1 to 8 guests' })).toBeVisible();
});

test('a booking beyond the seats left shows the message next to Guests', async ({ page, request }) => {
  const filled = await request.post('/api/tastings/red-wine-cellar-tour/bookings', {
    data: { name: 'Ben Vogel', email: 'ben@example.com', guests: 6 },
  });
  expect(filled.status()).toBe(201);

  await page.goto('/tastings/red-wine-cellar-tour/book');
  await page.getByLabel('Name').fill('Carla Stein');
  await page.getByLabel('Email').fill('carla@example.com');
  await page.getByLabel('Guests').fill('3');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByRole('alert').filter({ hasText: 'Only 2 seats left' })).toBeVisible();

  await page.getByLabel('Guests').fill('2');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(page.getByText('EUR 64')).toBeVisible();
});

test('a fully booked tasting shows no booking link', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('0 seats left', { exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Fully booked' })).toBeDisabled();
});

test('staff sign in, see grouped bookings and cancel to free seats', async ({ page }) => {
  await page.goto('/staff');
  await page.getByLabel('Password').fill('wrong-guess');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('alert').filter({ hasText: 'Incorrect password' })).toBeVisible();

  await page.getByLabel('Password').fill('e2e-staff-pass');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  await expect(page.getByText('Ben Vogel')).toBeVisible();

  await page.getByRole('listitem').filter({ hasText: 'Ben Vogel' }).getByRole('button', { name: 'Cancel' }).click();
  await expect(page.getByText('Ben Vogel')).toHaveCount(0);
  await expect(page.getByText(/6 seats left/)).toBeVisible();
});
