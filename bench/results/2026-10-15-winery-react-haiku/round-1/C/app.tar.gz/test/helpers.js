import { createApp } from '../server/app.js';

export async function startServer(options = {}) {
  const app = createApp(options);
  const server = await new Promise((resolve) => {
    const listening = app.listen(0, '127.0.0.1', () => resolve(listening));
  });
  const { port } = server.address();
  return {
    base: `http://127.0.0.1:${port}`,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

export async function request(base, path, { method = 'GET', body, cookie, headers = {} } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: {
      ...(body ? { 'content-type': 'application/json' } : {}),
      ...(cookie ? { cookie } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
    redirect: 'manual',
  });
  const text = await res.text();
  const setCookie = res.headers.getSetCookie().find((value) => value.startsWith('staff_session='));
  return {
    status: res.status,
    body: text ? JSON.parse(text) : null,
    setCookie,
    sessionCookie: setCookie?.split(';')[0],
  };
}

export async function signIn(base, password = 'test-password', headers) {
  const res = await request(base, '/api/staff/sign-in', { method: 'POST', body: { password }, headers });
  return res.sessionCookie;
}
