import { test } from 'node:test';
import assert from 'node:assert/strict';
import { request, signIn, startServer } from './helpers.js';

const HOUR = 60 * 60 * 1000;
const MINUTE = 60 * 1000;

function clock(start = Date.parse('2026-10-14T10:00:00Z')) {
  let now = start;
  return { now: () => now, advance: (ms) => (now += ms) };
}

async function start(t, options = {}) {
  const { base, close } = await startServer({ staffPassword: 'test-password', ...options });
  t.after(close);
  return base;
}

function attempt(base, password, headers) {
  return request(base, '/api/staff/sign-in', { method: 'POST', body: { password }, headers });
}

test('a wrong password is refused and starts no session', async (t) => {
  const base = await start(t);
  const res = await attempt(base, 'guess');
  assert.equal(res.status, 401);
  assert.deepEqual(res.body, { error: 'Incorrect password' });
  assert.equal(res.sessionCookie, undefined);
});

test('the correct password starts a session with HttpOnly and SameSite=Strict', async (t) => {
  const base = await start(t);
  const res = await attempt(base, 'test-password');
  assert.equal(res.status, 204);
  assert.match(res.setCookie, /HttpOnly/i);
  assert.match(res.setCookie, /SameSite=Strict/i);
  assert.doesNotMatch(res.setCookie, /;\s*Secure/i);
  const bookings = await request(base, '/api/staff/bookings', { cookie: res.sessionCookie });
  assert.equal(bookings.status, 200);
});

test('the cookie is marked Secure when the request came over HTTPS behind a trusted proxy', async (t) => {
  const base = await start(t, { trustProxy: 1 });
  const res = await attempt(base, 'test-password', { 'x-forwarded-proto': 'https' });
  assert.match(res.setCookie, /;\s*Secure/i);
});

test('X-Forwarded-Proto is ignored unless the proxy is trusted', async (t) => {
  const base = await start(t);
  const res = await attempt(base, 'test-password', { 'x-forwarded-proto': 'https' });
  assert.doesNotMatch(res.setCookie, /;\s*Secure/i);
});

test('the lockout keys on the address added by the trusted proxy, not on forged forwarded addresses', async (t) => {
  const base = await start(t, { trustProxy: 1 });
  // The proxy appends the real client address last; leftmost entries are client-controlled.
  for (let i = 0; i < 5; i++) {
    assert.equal((await attempt(base, 'guess', { 'x-forwarded-for': `10.0.0.${i}, 203.0.113.7` })).status, 401);
  }
  assert.equal((await attempt(base, 'test-password', { 'x-forwarded-for': '10.0.0.99, 203.0.113.7' })).status, 429);
});

test('forged forwarded headers do not evade the lockout when no proxy is trusted', async (t) => {
  const base = await start(t);
  for (let i = 0; i < 5; i++) {
    await attempt(base, 'guess', { 'x-forwarded-for': `10.0.0.${i}` });
  }
  assert.equal((await attempt(base, 'test-password', { 'x-forwarded-for': '10.0.0.99' })).status, 429);
});

test('every sign-in is refused when no staff password is configured', async (t) => {
  const base = await start(t, { staffPassword: undefined });
  for (const password of ['', 'test-password', 'anything']) {
    const res = await attempt(base, password);
    assert.equal(res.status, 401);
    assert.equal(res.sessionCookie, undefined);
  }
});

test('a staff session expires 8 hours after it started', async (t) => {
  const time = clock();
  const base = await start(t, { now: time.now });
  const cookie = await signIn(base);

  time.advance(8 * HOUR - 1000);
  assert.equal((await request(base, '/api/staff/bookings', { cookie })).status, 200);

  time.advance(1000 + 1);
  assert.equal((await request(base, '/api/staff/bookings', { cookie })).status, 401);
});

test('sign-out ends the session', async (t) => {
  const base = await start(t);
  const cookie = await signIn(base);
  const out = await request(base, '/api/staff/sign-out', { method: 'POST', cookie });
  assert.equal(out.status, 204);
  assert.equal((await request(base, '/api/staff/bookings', { cookie })).status, 401);
});

test('staff data is refused without a valid session cookie', async (t) => {
  const base = await start(t);
  assert.equal((await request(base, '/api/staff/bookings')).status, 401);
  assert.equal((await request(base, '/api/staff/bookings', { cookie: 'staff_session=forged' })).status, 401);
});

test('five failed attempts lock out the client for 15 minutes, even with the correct password', async (t) => {
  const time = clock();
  const base = await start(t, { now: time.now });
  for (let i = 0; i < 5; i++) {
    assert.equal((await attempt(base, 'guess')).status, 401);
  }
  const locked = await attempt(base, 'test-password');
  assert.equal(locked.status, 429);
  assert.deepEqual(locked.body, { error: 'Too many failed attempts. Try again later.' });
  assert.equal(locked.sessionCookie, undefined);

  time.advance(15 * MINUTE);
  assert.equal((await attempt(base, 'test-password')).status, 204);
});

test('failures older than 15 minutes do not count toward the lockout', async (t) => {
  const time = clock();
  const base = await start(t, { now: time.now });
  for (let i = 0; i < 4; i++) {
    await attempt(base, 'guess');
  }
  time.advance(15 * MINUTE + 1);
  assert.equal((await attempt(base, 'guess')).status, 401);
  assert.equal((await attempt(base, 'test-password')).status, 204);
});

test('four failed attempts do not lock out the client', async (t) => {
  const base = await start(t);
  for (let i = 0; i < 4; i++) {
    await attempt(base, 'guess');
  }
  assert.equal((await attempt(base, 'test-password')).status, 204);
});
