import { test } from 'node:test';
import assert from 'node:assert/strict';
import { request, signIn, startServer } from './helpers.js';

async function start(t) {
  const { base, close } = await startServer({ staffPassword: 'test-password' });
  t.after(close);
  return base;
}

const guest = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

test('staff see all bookings grouped by tasting', async (t) => {
  const base = await start(t);
  const created = await request(base, '/api/tastings/riesling-evening/bookings', { method: 'POST', body: guest });
  const cookie = await signIn(base);

  const res = await request(base, '/api/staff/bookings', { cookie });
  assert.equal(res.status, 200);
  assert.deepEqual(
    res.body.map((group) => group.tasting.title),
    ['Riesling Evening', 'Red Wine Cellar Tour', 'Winter Tasting'],
  );
  assert.deepEqual(res.body[0].bookings, [
    { reference: created.body.reference, name: 'Anna Keller', email: 'anna@example.com', guests: 2 },
  ]);
  assert.deepEqual(res.body[1].bookings, []);
});

test('cancelling a booking frees its seats and removes the reference', async (t) => {
  const base = await start(t);
  const created = await request(base, '/api/tastings/riesling-evening/bookings', {
    method: 'POST',
    body: { ...guest, guests: 3 },
  });
  const cookie = await signIn(base);

  const cancelled = await request(base, `/api/staff/bookings/${created.body.reference}`, {
    method: 'DELETE',
    cookie,
  });
  assert.equal(cancelled.status, 204);

  const tastings = await request(base, '/api/tastings');
  assert.equal(tastings.body[0].seatsLeft, 12);
  const confirmation = await request(base, `/api/bookings/${created.body.reference}`);
  assert.equal(confirmation.status, 404);
});

test('cancelling an unknown reference returns 404', async (t) => {
  const base = await start(t);
  const cookie = await signIn(base);
  const res = await request(base, '/api/staff/bookings/KB-AAAAAA', { method: 'DELETE', cookie });
  assert.equal(res.status, 404);
});

test('booking data and cancellation require a staff session', async (t) => {
  const base = await start(t);
  const created = await request(base, '/api/tastings/riesling-evening/bookings', { method: 'POST', body: guest });

  const list = await request(base, '/api/staff/bookings');
  assert.equal(list.status, 401);
  assert.ok(!JSON.stringify(list.body).includes('anna@example.com'));

  const cancel = await request(base, `/api/staff/bookings/${created.body.reference}`, { method: 'DELETE' });
  assert.equal(cancel.status, 401);

  const confirmation = await request(base, `/api/bookings/${created.body.reference}`);
  assert.equal(confirmation.status, 200);
});
