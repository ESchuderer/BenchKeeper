# Weingut Kieselbrunnen tastings

Online booking for wine tastings, with a staff page to view and cancel bookings.

## Run

Requires Node.js 22.

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password PORT=3000 npm start
```

Open http://localhost:3000 for guests and http://localhost:3000/staff for staff.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | Port the app listens on. |
| `STAFF_PASSWORD` | none | Password for `/staff`. If unset, staff sign-in is refused and a warning is logged at startup. |
| `TRUST_PROXY` | unset | Set to `true` only when a reverse proxy in front of the app overwrites `X-Forwarded-For` and `X-Forwarded-Proto`. Enables the `Secure` cookie behind TLS and per-client sign-in limits. |

## Notes

- Bookings and staff sessions are kept in memory. A restart clears them.
- Run one process only. Seat counts are not shared between processes.
- Staff sessions last 8 hours. Five failed sign-ins per client IP within 15 minutes lock sign-in for the rest of that window.

## Scripts

- `npm run build`: type-compiles the server to `dist/server` and bundles the interface to `dist/client`.
- `npm start`: serves the built app.
- `npm test`: runs the Vitest suite.
- `npm run typecheck`: runs TypeScript without emitting files.
- `npm run lint`: runs ESLint.
