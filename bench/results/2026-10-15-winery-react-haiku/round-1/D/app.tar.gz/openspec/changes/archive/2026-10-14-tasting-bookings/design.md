# Design

## Context

The repository has no application code yet (`openspec/specs/` is empty). Node.js 22 is the runtime. No external services are available at run time. See proposal.md for motivation and the delta specs for the required behavior.

## Goals / Non-Goals

**Goals:**
- One Node process serves the React interface and the JSON API on `PORT` (default 3000).
- Seat accounting cannot oversell, including under concurrent requests.
- Validation rules are defined once and applied on the client and on the server.

**Non-Goals:**
- Persistence across restarts, multiple server instances, or a database.
- Email delivery, payments, editing a booking, or changing tastings at run time.
- Multiple staff accounts or roles. There is one shared staff password.
- Internationalization. The interface is in English only.
- Reverse proxy or TLS termination configuration.

## Decisions

**Single Express 5 server with a React SPA.** Express serves `/api/*` as JSON and serves the Vite build for every other GET request, falling back to `index.html` for client-side routes. Alternatives: Next.js (own runtime and build pipeline, more than this app needs) and server-side rendering with `react-dom/server` (custom routing and data loading to maintain).

**React Router for routing.** Routes: `/` (tasting list), `/tastings/:id/book` (booking form), `/bookings/:reference` (confirmation), `/staff` (sign-in or bookings view). Unknown tastings and references render their "not found" states.

**Bookings in memory.** Tastings are a constant list in shared code. Bookings live in a `Map` keyed by reference. Alternative considered: a JSON file. Rejected because no requirement asks for persistence and a file adds write and locking concerns.

**Seat accounting in one synchronous step.** `seatsLeft = seats - sum(guests of bookings for the tasting)`. Validation, the seat check and the insert run in one synchronous function with no `await` in between. Node.js runs one JavaScript task at a time, so two requests cannot both pass the check for the same seats.

**Booking reference.** `KB-` followed by 8 characters from an unambiguous uppercase letter and digit set, generated with `crypto.randomInt`. A collision with an existing reference is regenerated.

**Shared validation with zod.** One zod schema in shared code defines Name (required, trimmed), Email (valid address) and Guests (integer 1 to 8). The client uses it through `react-hook-form` with `@hookform/resolvers/zod`. The server uses it for every booking request and responds `400` with `{ "errors": { "<field>": "<message>" } }`. The seat check is server-only and responds `409` with the same body shape, using the `guests` key.

**Prices and dates as stored.** Prices are whole euros. The total is `guests * price`. Dates and times are shown as stored (`2026-11-06 18:00`). No time zone conversion is applied, so the times are the winery's local times.

**Staff sign-in with express-session.** Session cookie: `httpOnly: true`, `sameSite: "strict"`, `secure: "auto"` (set when the request is HTTPS), `maxAge` 8 hours, `rolling: false` so the expiry is absolute from sign-in. The session secret is random per process. Sessions use the default in-memory store, so a restart signs staff out.

**Password comparison.** The submitted and configured passwords are hashed with SHA-256 and compared with `crypto.timingSafeEqual`. If `STAFF_PASSWORD` is unset, every sign-in is refused and a warning is logged at startup.

**Failed sign-in limit with express-rate-limit.** `POST /api/staff/sign-in` allows 5 requests per 15 minutes per client IP with `skipSuccessfulRequests: true`. A refused request gets status `429` and the message "Too many attempts. Try again later.".

**Cross-site protection.** Cookies are `SameSite=Strict`, so a browser does not send the session with a cross-site request, and those requests get 401. The mutating staff endpoints (`DELETE /api/staff/bookings/:reference`, `POST /api/staff/sign-out`) also refuse, with 403, any request whose `Origin` header names another origin. This covers same-site sibling subdomains, which `SameSite` does not block.

**Styling with Tailwind CSS v4.** Theme tokens (wine red, cream, slate text) are defined once with `@theme`. Headings use a system serif font stack and body text a system sans-serif stack, so no external font service is needed. Layout is mobile-first with one column below 640 px.

**Build and run.** `npm run build` compiles the server with `tsc` to `dist/server` and bundles the client with Vite to `dist/client`. `npm start` runs `node dist/server/index.js`.

**Module layout.**
- `src/shared/tastings.ts`: the tasting list.
- `src/shared/booking.ts`: the zod schema and error type.
- `src/server/app.ts`: `createApp({ staffPassword, trustProxy })` returning the Express app, so tests can build it without a port. `trustProxy` defaults to `false`; tests set it to `true` to exercise the `Secure` cookie over HTTPS.
- `src/server/bookings.ts`: the in-memory store and seat accounting.
- `src/server/index.ts`: reads `PORT`, `STAFF_PASSWORD` and `TRUST_PROXY` and listens.
- `src/client/`: React pages and components.

**Tests.** Vitest covers the shared schema, the store (seat accounting and the concurrency rule) and the API through supertest (validation, seat limit, sign-in, sign-out, rate limit, cookie attributes, cancel). The interface is checked in a browser through Playwright MCP.

## Risks / Trade-offs

- **Restart loses bookings and staff sessions** → Accepted by the requirements ("starts with no bookings"). Upgrade: persist the store to a file if the winery needs history.
- **Single process only** → Two instances would hold separate seat counts. Run one instance.
- **Rate limit keys on the socket IP** → Behind a reverse proxy, all clients share the proxy IP, so one client can lock out everyone. Mitigation: set `TRUST_PROXY=true` when a reverse proxy overwrites `X-Forwarded-For` and `X-Forwarded-Proto`. Without a proxy, leave it unset, since otherwise clients can spoof those headers.
- **Secure cookie depends on `req.secure`** → Behind a TLS-terminating proxy without `TRUST_PROXY=true`, the cookie is not marked Secure. Same mitigation as above.
- **One shared staff password** → No per-person accountability. Accepted by the requirements.

## Migration Plan

New application. No existing data or deployment to migrate. Rollback: stop the process and remove the change.

## Open Questions

None.
