# Proposal

## Why

Weingut Kieselbrunnen takes tasting bookings only by phone or in person. Guests need to book online, and staff need one place to see who is coming.

## What Changes

- Add a public start page listing the three tastings with date, time, price per guest and seats left.
- Add a booking form per tasting (Name, Email, Guests 1 to 8) that rejects invalid input and never books more seats than are left.
- Add a booking confirmation page showing the tasting, number of guests, total price and booking reference.
- Add a staff page at `/staff`, protected by a password from the `STAFF_PASSWORD` environment variable, that lists bookings grouped by tasting and cancels a booking, freeing its seats.
- Bookings are kept in memory. The app starts with no bookings.
- Tastings are fixed in code: Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats), Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats).

## Capabilities

### New Capabilities

- `tasting-booking`: Guests view tastings with seats left, book seats for one tasting, and receive a booking reference. Covers validation and seat accounting.
- `staff-booking-management`: Staff sign in with the shared staff password, view all bookings grouped by tasting, and cancel bookings. Covers sign-in limits, session expiry and sign-out.

### Modified Capabilities

None. The `openspec/specs/` directory is empty.

## Impact

- New code: Express 5 server with a JSON API, React single-page frontend built with Vite, React Router, react-hook-form with zod validation, Tailwind CSS, express-session, express-rate-limit.
- New runtime requirement: Node.js 22, `PORT` (default 3000), `STAFF_PASSWORD`.
- No external services, no database, no persisted files.
