# Spec Delta

## Purpose

Lets winery staff sign in with a shared password to see all tasting bookings and cancel them, freeing their seats.

## ADDED Requirements

### Requirement: Staff sign-in page
The page `/staff` SHALL show a "Password" field and a "Sign in" button to visitors who are not signed in, and SHALL show no booking data to them.

#### Scenario: Visitor without session
- **WHEN** a visitor opens `/staff` without a valid staff session
- **THEN** the page shows a "Password" field and a "Sign in" button and no bookings

### Requirement: Password check
The system SHALL accept a sign-in only when the submitted password equals the value of the `STAFF_PASSWORD` environment variable.

#### Scenario: Correct password
- **WHEN** a visitor submits the value of `STAFF_PASSWORD` in the Password field
- **THEN** the visitor is signed in and sees the bookings view

#### Scenario: Wrong password
- **WHEN** a visitor submits any other password
- **THEN** the message "Incorrect password" is shown and no staff session is created

#### Scenario: STAFF_PASSWORD not set
- **WHEN** the app starts without `STAFF_PASSWORD` set
- **THEN** the app logs a warning at startup, every sign-in attempt is refused with "Incorrect password", and the rest of the app works

### Requirement: Failed sign-in limit
The system MUST refuse further sign-in attempts from the same client after 5 failed attempts within 15 minutes, until the 15 minutes have passed.

#### Scenario: Sixth attempt refused
- **WHEN** a client has failed 5 sign-in attempts within 15 minutes and sends a sixth attempt, even with the correct password
- **THEN** the sign-in is refused with the message "Too many attempts. Try again later." and no staff session is created

#### Scenario: Successful sign-ins do not count
- **WHEN** a client signs in successfully 6 times within 15 minutes
- **THEN** none of the sign-ins is refused

### Requirement: Session expiry
A staff session SHALL expire 8 hours after sign-in, after which the visitor sees the sign-in page again.

#### Scenario: Expired session
- **WHEN** a staff member opens `/staff` more than 8 hours after signing in
- **THEN** the page shows the sign-in form and no bookings

### Requirement: Sign-out
The bookings view SHALL show a "Sign out" button that ends the staff session.

#### Scenario: Sign out
- **WHEN** a signed-in staff member activates "Sign out"
- **THEN** the staff session ends, the sign-in form is shown, and reloading the page does not show bookings

### Requirement: Bookings grouped by tasting
The bookings view SHALL show all bookings grouped by tasting, with name, email, number of guests and booking reference for each booking, and a "Cancel" button for each booking.

#### Scenario: Grouped list
- **WHEN** a signed-in staff member opens `/staff` and two bookings exist for Riesling Evening and one for Winter Tasting
- **THEN** the page shows a Riesling Evening group with its two bookings and a Winter Tasting group with its one booking, each with name, email, guests, reference and a "Cancel" button

#### Scenario: Tasting without bookings
- **WHEN** a tasting has no bookings
- **THEN** its group shows "No bookings yet"

### Requirement: Cancel booking
Activating "Cancel" SHALL remove that booking and free its seats for guests immediately.

#### Scenario: Cancel frees seats
- **WHEN** a staff member cancels a booking of 4 guests for Red Wine Cellar Tour
- **THEN** the booking disappears from the bookings view and the start page shows 4 more seats left for Red Wine Cellar Tour

### Requirement: Protected staff endpoints
The system MUST refuse requests to list bookings, cancel a booking and sign out when the request has no valid staff session, with status 401.

#### Scenario: Unauthenticated cancel
- **WHEN** a request without a staff session tries to cancel a booking
- **THEN** the request is refused with status 401 and the booking remains

### Requirement: Session cookie attributes
The staff session cookie SHALL be set with the HttpOnly and SameSite=Strict attributes, and with the Secure attribute when the app is served over HTTPS.

#### Scenario: Cookie over HTTPS
- **WHEN** a staff member signs in over an HTTPS connection
- **THEN** the session cookie has the HttpOnly, SameSite=Strict and Secure attributes

#### Scenario: Cookie over HTTP
- **WHEN** a staff member signs in over plain HTTP, for example on localhost
- **THEN** the session cookie has the HttpOnly and SameSite=Strict attributes and is still sent by the browser

#### Scenario: Cross-site state change refused
- **WHEN** a staff-changing request (cancel or sign out) is sent from another site without the staff session cookie
- **THEN** the request is refused with status 401

#### Scenario: Cross-site request with a session refused
- **WHEN** a staff-changing request carries the staff session cookie and an `Origin` header naming another origin
- **THEN** the request is refused with status 403 and the session stays valid
