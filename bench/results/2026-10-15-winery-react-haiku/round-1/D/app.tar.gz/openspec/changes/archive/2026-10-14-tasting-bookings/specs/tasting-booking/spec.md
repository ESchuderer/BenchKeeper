# Spec Delta

## Purpose

Lets guests see the wine tastings of Weingut Kieselbrunnen with the seats still available, and book seats for one tasting online.

## ADDED Requirements

### Requirement: Tasting list
The start page SHALL list every tasting with its title, date and time, price per guest in EUR, and seats left shown as "<n> seats left".

#### Scenario: Fresh tastings
- **WHEN** a guest opens the start page and no bookings exist
- **THEN** the page lists Riesling Evening (2026-11-06 18:00, EUR 25, "12 seats left"), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, "8 seats left") and Winter Tasting (2026-12-05 17:00, EUR 28, "10 seats left")

#### Scenario: Seats left after a booking
- **WHEN** a booking for 3 guests exists for Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening

### Requirement: Booking entry per tasting
Each tasting SHALL have a link or button labelled "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open booking form
- **WHEN** a guest activates "Book Red Wine Cellar Tour"
- **THEN** the booking form for Red Wine Cellar Tour opens, showing the tasting title

#### Scenario: Unknown tasting
- **WHEN** a guest opens a booking form for a tasting id that does not exist
- **THEN** the app shows a "Tasting not found" page with a link back to the start page

### Requirement: Booking form fields
The booking form SHALL have the fields "Name", "Email" and "Guests", and a "Book" button.

#### Scenario: Form layout
- **WHEN** the booking form is shown for a tasting with seats left
- **THEN** it shows a field labelled "Name", a field labelled "Email", a field labelled "Guests" that accepts whole numbers from 1 to 8, and a button labelled "Book"

### Requirement: Field validation
The system SHALL reject a booking with an invalid field and show the error message next to that field. The system SHALL NOT create a booking when any field is invalid.

#### Scenario: Empty name
- **WHEN** a guest submits the form with an empty Name
- **THEN** the message "Please enter your name" is shown next to the Name field and no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits an Email value that is not a valid email address
- **THEN** the message "Please enter a valid email address" is shown next to the Email field and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits a Guests value of 0, 9, a non-number, or a fraction
- **THEN** the message "Please enter a number of guests from 1 to 8" is shown next to the Guests field and no booking is created

### Requirement: Seat limit
The system MUST NOT accept a booking whose number of guests is greater than the seats left for that tasting.

#### Scenario: More guests than seats left
- **WHEN** 3 seats are left for a tasting and a guest submits 4 guests
- **THEN** the message "Only 3 seats left" is shown next to the Guests field and no booking is created

#### Scenario: Exactly the seats left
- **WHEN** 3 seats are left for a tasting and a guest submits 3 guests
- **THEN** the booking is created and the tasting shows 0 seats left

### Requirement: Fully booked tasting
When a tasting has 0 seats left, the start page SHALL show it as "Fully booked" and SHALL NOT offer its booking form for submission.

#### Scenario: Fully booked state
- **WHEN** the last seat of Winter Tasting is booked
- **THEN** the start page shows "Fully booked" for Winter Tasting, the "Book Winter Tasting" action is not offered, and the booking form for Winter Tasting shows that the tasting is fully booked

### Requirement: Concurrent bookings respect the seat limit
The system MUST keep the total booked guests of a tasting at or below its seat count, including when several booking requests arrive at the same time.

#### Scenario: Simultaneous requests
- **WHEN** two requests for 2 guests each arrive for a tasting with 3 seats left
- **THEN** exactly one booking is created and the other request is refused with the seat limit message

### Requirement: Server-side validation
The server SHALL apply the same validation rules as the booking form to every booking request, regardless of the client that sent it.

#### Scenario: Request bypassing the form
- **WHEN** a request to book with 9 guests is sent directly to the server
- **THEN** the server responds with status 400 and an error for the guests field, and no booking is created

### Requirement: Booking confirmation
After a successful booking, the guest SHALL see a page with the heading "Booking confirmed", the tasting title, the number of guests, the total price in EUR (guests multiplied by the price per guest), and the booking reference.

#### Scenario: Confirmation content
- **WHEN** a guest books 2 guests for Riesling Evening
- **THEN** the page shows the heading "Booking confirmed", "Riesling Evening", 2 guests, "EUR 50" as the total, and a booking reference

#### Scenario: Booking reference is unique
- **WHEN** two bookings are created
- **THEN** each booking has a different booking reference

#### Scenario: Confirmation can be opened again
- **WHEN** a guest opens the confirmation page for an existing booking reference
- **THEN** the same confirmation content is shown

#### Scenario: Unknown booking reference
- **WHEN** a guest opens the confirmation page for a reference that does not exist
- **THEN** the app shows a "Booking not found" page with a link back to the start page
