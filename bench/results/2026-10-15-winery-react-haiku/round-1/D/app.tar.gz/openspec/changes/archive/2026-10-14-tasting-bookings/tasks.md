# Tasks

## 1. Project setup

- [x] 1.1 Add `package.json` with npm scripts `build`, `start`, `test`, `typecheck` and `lint`, the TypeScript, Vite, Tailwind CSS and ESLint configs, and `.gitignore` for `node_modules` and `dist`; verify `npm install` and `npm run build` succeed on an empty entry point
- [x] 1.2 Add `README.md` with the run steps (`npm install`, `npm run build`, `STAFF_PASSWORD=... PORT=3000 npm start`) and the note that bookings are kept in memory; verify each command in the README runs as written

## 2. Shared tastings and validation

- [x] 2.1 Write Vitest tests for the booking schema: empty Name, invalid Email, Guests of 0, 9, 1.5 and "abc", and a valid input; verify the tests fail before implementation
- [x] 2.2 Implement `src/shared/tastings.ts` with the three tastings and `src/shared/booking.ts` with the zod schema and the field messages from the spec; verify the tests from 2.1 pass
- [x] 2.3 Write Vitest tests for `total` (guests times price) and for the tasting list contents; implement them in `src/shared/tastings.ts`; verify the tests pass

## 3. Booking store

- [x] 3.1 Write Vitest tests for the store: seats left starts at the seat count, a booking reduces it, exactly the remaining seats is accepted, one more guest is refused with "Only N seats left", and a cancelled booking restores its seats; verify the tests fail before implementation
- [x] 3.2 Implement `src/server/bookings.ts` with in-memory seat accounting, a single synchronous check-and-insert, booking reference generation with collision retry, and cancel; verify the tests from 3.1 pass
- [x] 3.3 Add a store test that calls `book` twice in a row for a tasting with 3 seats left with 2 guests each and expects one success and one refusal; verify it passes

## 4. Public API

- [x] 4.1 Write supertest tests for `GET /api/tastings` (fields and seats left), `POST /api/tastings/:id/bookings` (201 with reference and total; 400 with `errors` for invalid fields; 409 with `errors.guests` for the seat limit; 404 for an unknown tasting; 400 for 9 guests sent directly) and `GET /api/bookings/:reference` (200, and 404 when unknown); verify the tests fail before implementation
- [x] 4.2 Implement `src/server/app.ts` (`createApp({ staffPassword, trustProxy })`) and the public routes in it, with JSON body parsing, the `400`/`409`/`404` responses and the static file fallback for the client build; verify the tests from 4.1 pass
- [x] 4.3 Add a supertest test that sends 2 requests for 2 guests in parallel (`Promise.all`) for a tasting with 3 seats left and expects one `201` and one `409`; verify it passes

## 5. Staff API

- [x] 5.1 Write supertest tests for sign-in: correct password returns 204 with a `Set-Cookie` header; wrong password returns 401 with "Incorrect password"; with `STAFF_PASSWORD` unset every sign-in returns 401; verify the tests fail before implementation
- [x] 5.2 Implement `POST /api/staff/sign-in` with the SHA-256 digest comparison through `crypto.timingSafeEqual`, the express-session setup (`httpOnly`, `sameSite: "strict"`, `secure: "auto"`, `maxAge` 8 hours, `rolling: false`), and the startup warning when `STAFF_PASSWORD` is unset; verify the tests from 5.1 pass
- [x] 5.3 Write supertest tests for the failed sign-in limit: 5 wrong passwords then the correct password returns 429 with "Too many attempts. Try again later."; 6 correct sign-ins in a row all return 204; verify the tests fail before implementation
- [x] 5.4 Add `express-rate-limit` to `POST /api/staff/sign-in` (5 per 15 minutes, `skipSuccessfulRequests: true`, 429 message); verify the tests from 5.3 pass
- [x] 5.5 Write supertest tests for the session cookie: `HttpOnly` and `SameSite=Strict` are present, `Max-Age=28800`, `Secure` is present when the request is sent with `X-Forwarded-Proto: https` and `trustProxy: true`, and absent over plain HTTP; verify the tests pass against 5.2
- [x] 5.6 Write supertest tests for the protected endpoints: `GET /api/staff/bookings`, `DELETE /api/staff/bookings/:reference` and `POST /api/staff/sign-out` return 401 without a session; a signed-in cancel removes the booking and frees its seats; sign-out ends the session; a `text/plain` sign-out request without a session returns 401; verify the tests fail before implementation
- [x] 5.7 Implement `GET /api/staff/bookings` (grouped by tasting, with name, email, guests and reference), `DELETE /api/staff/bookings/:reference`, `POST /api/staff/sign-out` and the session guard for them; verify the tests from 5.6 pass

## 6. Client shell and visual design

- [x] 6.1 Configure Tailwind CSS v4 with `@theme` tokens for wine red, cream and slate text, and the serif heading and sans-serif body font stacks; verify `npm run build` produces the CSS and the page background is cream in a browser check
- [x] 6.2 Implement the React entry, React Router routes (`/`, `/tastings/:id/book`, `/bookings/:reference`, `/staff`), the header with "Weingut Kieselbrunnen", the footer and the not-found pages; verify each route renders in the browser through Playwright MCP at 390 px and 1280 px width

## 7. Start page

- [x] 7.1 Implement the tasting list fetched from `GET /api/tastings`, with title, date and time as stored ("2026-11-06 18:00"), "EUR <price>" per guest, "<n> seats left", and the "Book <tasting title>" link; verify in the browser that the three tastings and their seat counts match the spec
- [x] 7.2 Implement the "Fully booked" state (no booking link) and the loading and error states of the list; verify in the browser by booking all seats of Winter Tasting through the API and reloading the page

## 8. Booking form and confirmation

- [x] 8.1 Implement the booking form with `react-hook-form` and `@hookform/resolvers/zod` on the shared schema: fields "Name", "Email", "Guests" and the "Book" button; errors shown next to each field; verify in the browser that an empty Name and an invalid Email show their messages next to the fields (Guests defaults to 1)
- [x] 8.2 Map the server `400` and `409` error bodies onto the matching fields, and redirect to `/bookings/:reference` on `201`; verify in the browser that an overbooking attempt shows "Only N seats left" next to Guests and that a valid booking opens the confirmation
- [x] 8.3 Implement the confirmation page with the heading "Booking confirmed", the tasting, guests, "EUR <total>" and the reference, plus the "Booking not found" state; verify in the browser that a reload of the confirmation page shows the same content

## 9. Staff page

- [x] 9.1 Implement the sign-in form ("Password" field, "Sign in" button) with the "Incorrect password" and "Too many attempts. Try again later." messages; verify in the browser with a wrong and a correct password
- [x] 9.2 Implement the bookings view grouped by tasting with name, email, guests, reference, "Cancel" buttons, "No bookings yet" and the "Sign out" button; verify in the browser that cancelling a booking frees its seats on the start page and that sign-out returns to the sign-in form

## 10. Integration checks

- [x] 10.1 Run `npm run typecheck`, `npm run lint`, `npm test` and `npm run build`; verify all four exit with status 0
- [x] 10.2 Run `npm start` with `PORT` unset and with `STAFF_PASSWORD` unset; verify the app serves on port 3000 and logs the staff warning
- [x] 10.3 Walk through the full flow in the browser at 390 px width: book Riesling Evening for 2 guests, see the confirmation, sign in to `/staff`, see the booking under Riesling Evening, cancel it, and see 12 seats left again; verify each step and capture screenshots of the start page, the form error state and the staff page

## Workflow follow-up

- Run `openspec-archive-change` on the branch after review and before any pull request is merged.
- Verify the archived specs in `openspec/specs/` after archive.
