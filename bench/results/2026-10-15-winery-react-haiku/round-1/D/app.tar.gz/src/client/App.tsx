import { Route, Routes } from "react-router";
import { Layout } from "./Layout.js";
import { StartPage } from "./pages/StartPage.js";
import { BookingPage } from "./pages/BookingPage.js";
import { ConfirmationPage } from "./pages/ConfirmationPage.js";
import { StaffPage } from "./pages/StaffPage.js";
import { NotFoundPage } from "./pages/NotFoundPage.js";

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<StartPage />} />
        <Route path="tastings/:id/book" element={<BookingPage />} />
        <Route path="bookings/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage message="Page not found" />} />
      </Route>
    </Routes>
  );
}
