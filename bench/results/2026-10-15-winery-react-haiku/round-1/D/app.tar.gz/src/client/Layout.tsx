import { Link, Outlet } from "react-router";

export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-wine-deep text-cream">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-5">
          <Link to="/" className="font-serif text-2xl tracking-wide">
            Weingut Kieselbrunnen
          </Link>
          <nav className="flex gap-5 text-sm">
            <Link to="/" className="hover:underline">
              Tastings
            </Link>
            <Link to="/staff" className="hover:underline">
              Staff
            </Link>
          </nav>
        </div>
        <div className="h-0.5 bg-gold" />
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-10">
        <Outlet />
      </main>
      <footer className="border-t border-gold/40 py-6 text-center text-sm text-muted">
        Weingut Kieselbrunnen, family winery
      </footer>
    </div>
  );
}
