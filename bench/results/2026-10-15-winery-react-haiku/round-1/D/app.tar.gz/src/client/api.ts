export type ApiResult<T> = { ok: true; status: number; data: T } | { ok: false; status: number; data: unknown };

export async function apiRequest<T>(url: string, init?: RequestInit): Promise<ApiResult<T>> {
  const response = await fetch(url, {
    ...init,
    headers: { Accept: "application/json", ...(init?.body ? { "Content-Type": "application/json" } : {}) },
  });
  const text = await response.text();
  const data: unknown = text ? JSON.parse(text) : undefined;
  if (response.ok) return { ok: true, status: response.status, data: data as T };
  return { ok: false, status: response.status, data };
}
