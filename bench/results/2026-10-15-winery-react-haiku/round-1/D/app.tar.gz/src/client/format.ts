export function seatsLeftLabel(seatsLeft: number): string {
  return `${seatsLeft} ${seatsLeft === 1 ? "seat" : "seats"} left`;
}
