import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useNavigate, useParams } from "react-router";
import { apiRequest } from "../api.js";
import { seatsLeftLabel } from "../format.js";
import { NotFoundPage } from "./NotFoundPage.js";
import { bookingSchema, type BookingErrors, type BookingInput } from "../../shared/booking.js";

type TastingSummary = {
  id: string;
  title: string;
  startsAt: string;
  price: number;
  seatsLeft: number;
};

export function BookingPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tasting, setTasting] = useState<TastingSummary | null | undefined>(undefined);
  const [formError, setFormError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: "", email: "", guests: 1 },
  });

  const loadTasting = useCallback(
    () =>
      apiRequest<TastingSummary[]>("/api/tastings")
        .then((result) => {
          setTasting(result.ok ? result.data.find((t) => t.id === id) ?? null : null);
        })
        .catch(() => setTasting(null)),
    [id],
  );

  useEffect(() => {
    void loadTasting();
  }, [loadTasting]);

  if (tasting === undefined) return <p className="text-muted">Loading...</p>;
  if (tasting === null) return <NotFoundPage message="Tasting not found" />;
  if (tasting.seatsLeft === 0) {
    return (
      <NotFoundPage message={`${tasting.title} is fully booked`} />
    );
  }

  async function onSubmit(values: BookingInput) {
    setFormError(null);
    try {
      const result = await apiRequest<{ reference: string }>(`/api/tastings/${tasting!.id}/bookings`, {
        method: "POST",
        body: JSON.stringify(values),
      });
      if (result.ok) {
        navigate(`/bookings/${result.data.reference}`);
        return;
      }
      const body = result.data as { errors?: BookingErrors; error?: string } | undefined;
      if (body?.errors) {
        for (const [field, message] of Object.entries(body.errors)) {
          setError(field as keyof BookingInput, { message });
        }
        void loadTasting();
        return;
      }
      setFormError(body?.error ?? "The booking could not be completed. Please try again.");
    } catch {
      setFormError("The booking could not be completed. Please check your connection and try again.");
    }
  }

  const inputClass =
    "mt-1 w-full rounded border bg-cream px-3 py-2 text-base focus:outline-2 focus:outline-wine";

  return (
    <div className="mx-auto max-w-xl">
      <Link to="/" className="text-sm text-wine underline">
        Back to the tastings
      </Link>
      <h1 className="mt-4 text-3xl">Book {tasting.title}</h1>
      <p className="mt-2 text-muted">
        {tasting.startsAt} · EUR {tasting.price} per guest · {seatsLeftLabel(tasting.seatsLeft)}
      </p>

      <form noValidate onSubmit={handleSubmit(onSubmit)} className="mt-8 space-y-6 rounded-lg border border-gold/50 bg-parchment p-6">
        <div>
          <label htmlFor="name" className="block text-sm font-semibold">
            Name
          </label>
          <input
            id="name"
            type="text"
            autoComplete="name"
            aria-invalid={errors.name ? true : undefined}
            aria-describedby={errors.name ? "name-error" : undefined}
            className={`${inputClass} ${errors.name ? "border-danger" : "border-gold/60"}`}
            {...register("name")}
          />
          {errors.name && (
            <p id="name-error" className="mt-1 text-sm text-danger">
              {errors.name.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-semibold">
            Email
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            aria-invalid={errors.email ? true : undefined}
            aria-describedby={errors.email ? "email-error" : undefined}
            className={`${inputClass} ${errors.email ? "border-danger" : "border-gold/60"}`}
            {...register("email")}
          />
          {errors.email && (
            <p id="email-error" className="mt-1 text-sm text-danger">
              {errors.email.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="guests" className="block text-sm font-semibold">
            Guests
          </label>
          <input
            id="guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={8}
            step={1}
            aria-invalid={errors.guests ? true : undefined}
            aria-describedby={errors.guests ? "guests-error" : undefined}
            className={`${inputClass} ${errors.guests ? "border-danger" : "border-gold/60"}`}
            {...register("guests", { valueAsNumber: true })}
          />
          {errors.guests && (
            <p id="guests-error" className="mt-1 text-sm text-danger">
              {errors.guests.message}
            </p>
          )}
        </div>

        {formError && (
          <p role="alert" className="rounded bg-danger/10 px-3 py-2 text-sm text-danger">
            {formError}
          </p>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full rounded bg-wine px-4 py-3 font-semibold text-cream hover:bg-wine-deep disabled:opacity-60"
        >
          Book
        </button>
      </form>
    </div>
  );
}
