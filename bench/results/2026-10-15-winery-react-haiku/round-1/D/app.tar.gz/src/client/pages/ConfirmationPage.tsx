import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import { apiRequest } from "../api.js";
import type { BookingConfirmation } from "../../shared/booking.js";
import { NotFoundPage } from "./NotFoundPage.js";

export function ConfirmationPage() {
  const { reference } = useParams();
  const [booking, setBooking] = useState<BookingConfirmation | null | undefined>(undefined);

  useEffect(() => {
    apiRequest<BookingConfirmation>(`/api/bookings/${reference}`)
      .then((result) => setBooking(result.ok ? result.data : null))
      .catch(() => setBooking(null));
  }, [reference]);

  if (booking === undefined) return <p className="text-muted">Loading...</p>;
  if (booking === null) return <NotFoundPage message="Booking not found" />;

  return (
    <section className="mx-auto max-w-xl rounded-lg border border-gold/50 bg-parchment p-6 sm:p-8">
      <h1 className="text-3xl">Booking confirmed</h1>
      <dl className="mt-6 grid grid-cols-[auto_1fr] gap-x-6 gap-y-3">
        <dt className="text-muted">Tasting</dt>
        <dd className="font-semibold">{booking.tasting.title}</dd>
        <dt className="text-muted">When</dt>
        <dd>{booking.tasting.startsAt}</dd>
        <dt className="text-muted">Guests</dt>
        <dd>{booking.guests}</dd>
        <dt className="text-muted">Total</dt>
        <dd>EUR {booking.total}</dd>
        <dt className="text-muted">Reference</dt>
        <dd className="font-mono tracking-wider">{booking.reference}</dd>
      </dl>
      <Link to="/" className="mt-8 inline-block text-wine underline">
        Back to the tastings
      </Link>
    </section>
  );
}
