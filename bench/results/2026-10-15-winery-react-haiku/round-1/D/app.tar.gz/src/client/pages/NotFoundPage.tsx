import { Link } from "react-router";

export function NotFoundPage({ message }: { message: string }) {
  return (
    <section className="mx-auto max-w-md text-center">
      <h1 className="text-3xl">{message}</h1>
      <Link to="/" className="mt-6 inline-block text-wine underline">
        Back to the tastings
      </Link>
    </section>
  );
}
