import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "../api.js";

type StaffBooking = { reference: string; name: string; email: string; guests: number };
type StaffGroup = { tastingId: string; title: string; startsAt: string; bookings: StaffBooking[] };

const signInSchema = z.object({
  password: z.string().min(1, "Please enter the password"),
});
type SignInInput = z.infer<typeof signInSchema>;

const inputClass = "mt-1 w-full rounded border border-gold/60 bg-cream px-3 py-2 text-base focus:outline-2 focus:outline-wine";
const buttonClass = "rounded bg-wine px-4 py-2 text-sm font-semibold text-cream hover:bg-wine-deep disabled:opacity-60";

type Loaded =
  | { kind: "ok"; groups: StaffGroup[] }
  | { kind: "signed-out" }
  | { kind: "error" };

async function fetchBookings(): Promise<Loaded> {
  try {
    const result = await apiRequest<StaffGroup[]>("/api/staff/bookings");
    if (result.ok) return { kind: "ok", groups: result.data };
    return result.status === 401 ? { kind: "signed-out" } : { kind: "error" };
  } catch {
    return { kind: "error" };
  }
}

export function StaffPage() {
  const [loaded, setLoaded] = useState<Loaded | null>(null);

  const loadBookings = useCallback(() => fetchBookings().then(setLoaded), []);

  useEffect(() => {
    fetchBookings().then(setLoaded);
  }, []);

  if (loaded === null) return <p className="text-muted">Loading...</p>;
  if (loaded.kind === "error") {
    return <p role="alert" className="text-danger">The bookings could not be loaded. Please try again later.</p>;
  }
  if (loaded.kind === "signed-out") return <SignInForm onSignedIn={loadBookings} />;
  return (
    <BookingsView
      groups={loaded.groups}
      onChanged={loadBookings}
      onSignedOut={() => setLoaded({ kind: "signed-out" })}
    />
  );
}

function SignInForm({ onSignedIn }: { onSignedIn: () => Promise<void> }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<SignInInput>({
    resolver: zodResolver(signInSchema),
    defaultValues: { password: "" },
  });

  async function onSubmit({ password }: SignInInput) {
    const result = await apiRequest("/api/staff/sign-in", {
      method: "POST",
      body: JSON.stringify({ password }),
    });
    if (result.ok) {
      await onSignedIn();
      return;
    }
    const message =
      result.status === 429
        ? "Too many attempts. Try again later."
        : result.status === 401
          ? "Incorrect password"
          : "Sign-in failed. Please try again.";
    setError("password", { message });
  }

  return (
    <section className="mx-auto max-w-sm">
      <h1 className="text-3xl">Staff sign in</h1>
      <form noValidate onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4 rounded-lg border border-gold/50 bg-parchment p-6">
        <div>
          <label htmlFor="password" className="block text-sm font-semibold">
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            aria-invalid={errors.password ? true : undefined}
            aria-describedby={errors.password ? "password-error" : undefined}
            className={`${inputClass} ${errors.password ? "border-danger" : ""}`}
            {...register("password")}
          />
          {errors.password && (
            <p id="password-error" className="mt-1 text-sm text-danger">
              {errors.password.message}
            </p>
          )}
        </div>
        <button type="submit" disabled={isSubmitting} className={`${buttonClass} w-full py-3`}>
          Sign in
        </button>
      </form>
    </section>
  );
}

function BookingsView({
  groups,
  onChanged,
  onSignedOut,
}: {
  groups: StaffGroup[];
  onChanged: () => Promise<void>;
  onSignedOut: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function cancel(reference: string) {
    setBusy(true);
    setMessage(null);
    try {
      const result = await apiRequest(`/api/staff/bookings/${reference}`, { method: "DELETE" });
      if (result.ok || result.status === 404) {
        await onChanged();
      } else if (result.status === 401) {
        onSignedOut();
      } else {
        setMessage("The booking could not be cancelled. Please try again.");
      }
    } catch {
      setMessage("The booking could not be cancelled. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  async function signOut() {
    try {
      const result = await apiRequest("/api/staff/sign-out", { method: "POST" });
      if (!result.ok && result.status !== 401) {
        setMessage("Sign-out failed. Please try again.");
        return;
      }
    } catch {
      setMessage("Sign-out failed. Please try again.");
      return;
    }
    onSignedOut();
  }

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-3xl">Bookings</h1>
        <button type="button" onClick={signOut} className={buttonClass}>
          Sign out
        </button>
      </div>
      {message && (
        <p role="alert" className="mt-4 rounded bg-danger/10 px-3 py-2 text-sm text-danger">
          {message}
        </p>
      )}
      <div className="mt-8 space-y-8">
        {groups.map((group) => (
          <article key={group.tastingId} className="rounded-lg border border-gold/50 bg-parchment p-5">
            <h2 className="text-2xl">{group.title}</h2>
            <p className="text-sm text-muted">{group.startsAt}</p>
            {group.bookings.length === 0 ? (
              <p className="mt-4 text-muted">No bookings yet</p>
            ) : (
              <div className="relative mt-4 overflow-x-auto">
                <table className="w-full min-w-[32rem] text-left text-sm">
                  <thead className="border-b border-gold/60 text-muted">
                    <tr>
                      <th className="py-2 pr-4 font-semibold">Name</th>
                      <th className="py-2 pr-4 font-semibold">Email</th>
                      <th className="py-2 pr-4 font-semibold">Guests</th>
                      <th className="py-2 pr-4 font-semibold">Reference</th>
                      <th className="py-2 font-semibold">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {group.bookings.map((booking) => (
                      <tr key={booking.reference} className="border-b border-gold/30">
                        <td className="py-2 pr-4">{booking.name}</td>
                        <td className="py-2 pr-4">{booking.email}</td>
                        <td className="py-2 pr-4">{booking.guests}</td>
                        <td className="py-2 pr-4 font-mono">{booking.reference}</td>
                        <td className="py-2 text-right">
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => cancel(booking.reference)}
                            className="rounded border border-wine px-3 py-1 text-wine hover:bg-wine hover:text-cream disabled:opacity-60"
                          >
                            Cancel
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </article>
        ))}
      </div>
    </section>
  );
}
