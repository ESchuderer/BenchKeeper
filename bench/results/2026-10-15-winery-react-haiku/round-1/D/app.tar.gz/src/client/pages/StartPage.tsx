import { useEffect, useState } from "react";
import { Link } from "react-router";
import { apiRequest } from "../api.js";
import { seatsLeftLabel } from "../format.js";

type TastingSummary = {
  id: string;
  title: string;
  startsAt: string;
  price: number;
  seats: number;
  seatsLeft: number;
};

export function StartPage() {
  const [tastings, setTastings] = useState<TastingSummary[] | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    apiRequest<TastingSummary[]>("/api/tastings")
      .then((result) => {
        if (result.ok) setTastings(result.data);
        else setFailed(true);
      })
      .catch(() => setFailed(true));
  }, []);

  if (failed) {
    return <p role="alert" className="text-danger">The tastings could not be loaded. Please try again later.</p>;
  }
  if (!tastings) {
    return <p className="text-muted">Loading tastings...</p>;
  }

  return (
    <section>
      <h1 className="text-3xl">Wine tastings</h1>
      <p className="mt-2 text-muted">Choose a tasting and book your seats online.</p>
      <ul className="mt-8 grid gap-6 md:grid-cols-2">
        {tastings.map((tasting) => (
          <li key={tasting.id} className="flex flex-col rounded-lg border border-gold/50 bg-parchment p-6 shadow-sm">
            <h2 className="text-2xl">{tasting.title}</h2>
            <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
              <dt className="text-muted">When</dt>
              <dd>{tasting.startsAt}</dd>
              <dt className="text-muted">Price</dt>
              <dd>EUR {tasting.price} per guest</dd>
              <dt className="text-muted">Seats</dt>
              <dd>{seatsLeftLabel(tasting.seatsLeft)}</dd>
            </dl>
            <div className="mt-auto pt-6">
              {tasting.seatsLeft === 0 ? (
                <span className="inline-block rounded bg-danger px-3 py-2 text-sm font-semibold text-cream">Fully booked</span>
              ) : (
                <Link
                  to={`/tastings/${tasting.id}/book`}
                  className="inline-block rounded bg-wine px-4 py-2 text-sm font-semibold text-cream hover:bg-wine-deep"
                >
                  Book {tasting.title}
                </Link>
              )}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
