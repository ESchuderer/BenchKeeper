import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express, {
  type ErrorRequestHandler,
  type Request,
  type RequestHandler,
} from "express";
import session from "express-session";
import rateLimit from "express-rate-limit";
import { createBookingStore } from "./bookings.js";
import { bookingSchema, type BookingErrors } from "../shared/booking.js";
import {
  findTasting,
  tastings,
  totalPrice,
  type Tasting,
} from "../shared/tastings.js";

export type AppOptions = {
  staffPassword?: string;
  trustProxy?: boolean;
};

declare module "express-session" {
  interface SessionData {
    staff?: true;
  }
}

const clientDir = fileURLToPath(new URL("../client", import.meta.url));
const staffSessionMs = 8 * 60 * 60 * 1000;
const signInWindowMs = 15 * 60 * 1000;

function hash(value: string): Buffer {
  return createHash("sha256").update(value).digest();
}

function seatMessage(seatsLeft: number): string {
  if (seatsLeft === 0) return "This tasting is fully booked";
  return `Only ${seatsLeft} seat${seatsLeft === 1 ? "" : "s"} left`;
}

function fieldErrors(error: { issues: { path: PropertyKey[]; message: string }[] }) {
  const errors: BookingErrors = {};
  for (const issue of error.issues) {
    const field = issue.path[0];
    if (typeof field === "string") errors[field as keyof BookingErrors] ??= issue.message;
  }
  return errors;
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function confirmation(tasting: Tasting, reference: string, guests: number) {
  return {
    reference,
    tasting: {
      id: tasting.id,
      title: tasting.title,
      startsAt: tasting.startsAt,
      price: tasting.price,
    },
    guests,
    total: totalPrice(tasting, guests),
  };
}

export function createApp({ staffPassword, trustProxy = false }: AppOptions = {}) {
  const app = express();
  const store = createBookingStore();
  app.set("trust proxy", trustProxy);
  app.use(express.json());
  app.use(
    session({
      secret: randomBytes(32).toString("hex"),
      resave: false,
      saveUninitialized: false,
      rolling: false,
      cookie: {
        httpOnly: true,
        sameSite: "strict",
        secure: "auto",
        maxAge: staffSessionMs,
      },
    }),
  );

  const signInLimiter = rateLimit({
    windowMs: signInWindowMs,
    limit: 5,
    skipSuccessfulRequests: true,
    legacyHeaders: false,
    message: { error: "Too many attempts. Try again later." },
  });

  function passwordMatches(input: unknown): boolean {
    if (!staffPassword || typeof input !== "string") return false;
    return timingSafeEqual(hash(input), hash(staffPassword));
  }

  app.post("/api/staff/sign-in", signInLimiter, (req, res, next) => {
    if (!passwordMatches(req.body?.password)) {
      res.status(401).json({ error: "Incorrect password" });
      return;
    }
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.staff = true;
      res.sendStatus(204);
    });
  });

  app.get("/api/tastings", (_req, res) => {
    res.json(
      tastings.map((tasting) => ({
        ...tasting,
        seatsLeft: store.seatsLeft(tasting),
      })),
    );
  });

  app.post("/api/tastings/:id/bookings", (req, res) => {
    const tasting = findTasting(req.params.id);
    if (!tasting) {
      res.status(404).json({ error: "Tasting not found" });
      return;
    }
    const body = isPlainObject(req.body) ? req.body : {};
    const parsed = bookingSchema.safeParse(body);
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error) });
      return;
    }
    const result = store.book(tasting, parsed.data);
    if (!result.ok) {
      res.status(409).json({ errors: { guests: seatMessage(result.seatsLeft) } });
      return;
    }
    res
      .status(201)
      .json(confirmation(tasting, result.booking.reference, result.booking.guests));
  });

  app.get("/api/bookings/:reference", (req, res) => {
    const booking = store.get(req.params.reference);
    const tasting = booking && findTasting(booking.tastingId);
    if (!booking || !tasting) {
      res.status(404).json({ error: "Booking not found" });
      return;
    }
    res.json(confirmation(tasting, booking.reference, booking.guests));
  });

  const requireStaff: RequestHandler = (req, res, next) => {
    if (!req.session.staff) {
      res.status(401).json({ error: "Not signed in" });
      return;
    }
    next();
  };

  // Cross-site browser requests carry no session cookie (SameSite=Strict); this also refuses one that does.
  const requireSameOrigin: RequestHandler = (req, res, next) => {
    const origin = req.get("origin");
    if (origin && origin !== `${req.protocol}://${req.get("host")}`) {
      res.status(403).json({ error: "Cross-site request refused" });
      return;
    }
    next();
  };

  app.post("/api/staff/sign-out", requireStaff, requireSameOrigin, (req, res, next) => {
    req.session.destroy((err) => {
      if (err) return next(err);
      res.sendStatus(204);
    });
  });

  app.get("/api/staff/bookings", requireStaff, (_req, res) => {
    const bookings = store.list();
    res.json(
      tastings.map((tasting) => ({
        tastingId: tasting.id,
        title: tasting.title,
        startsAt: tasting.startsAt,
        bookings: bookings
          .filter((booking) => booking.tastingId === tasting.id)
          .map(({ reference, name, email, guests }) => ({
            reference,
            name,
            email,
            guests,
          })),
      })),
    );
  });

  app.delete(
    "/api/staff/bookings/:reference",
    requireStaff,
    requireSameOrigin,
    (req: Request<{ reference: string }>, res) => {
      if (!store.cancel(req.params.reference)) {
        res.status(404).json({ error: "Booking not found" });
        return;
      }
      res.sendStatus(204);
    },
  );

  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Not found" });
  });

  app.use(express.static(clientDir));
  app.use((req, res, next) => {
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    res.sendFile(path.join(clientDir, "index.html"), next);
  });

  const errorHandler: ErrorRequestHandler = (err, _req, res, next) => {
    if (res.headersSent) return next(err);
    const status = (err as { status?: number }).status ?? 500;
    if (status >= 500) console.error(err);
    res.status(status).json({
      error: status >= 500 ? "Internal server error" : "Invalid request",
    });
  };
  app.use(errorHandler);

  return app;
}
