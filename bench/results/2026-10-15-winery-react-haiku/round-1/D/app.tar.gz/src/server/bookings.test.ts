import { describe, expect, it } from "vitest";
import { createBookingStore } from "./bookings.js";
import { findTasting } from "../shared/tastings.js";

const riesling = findTasting("riesling-evening")!;
const winter = findTasting("winter-tasting")!;
const guest = { name: "Anna Keller", email: "anna@example.com" };

describe("booking store", () => {
  it("starts with all seats of a tasting left", () => {
    const store = createBookingStore();
    expect(store.seatsLeft(riesling)).toBe(12);
  });

  it("reduces the seats left by the booked guests", () => {
    const store = createBookingStore();
    const result = store.book(riesling, { ...guest, guests: 3 });
    expect(result.ok).toBe(true);
    expect(store.seatsLeft(riesling)).toBe(9);
  });

  it("accepts exactly the seats left and then shows 0", () => {
    const store = createBookingStore();
    store.book(winter, { ...guest, guests: 7 });
    const result = store.book(winter, { ...guest, guests: 3 });
    expect(result.ok).toBe(true);
    expect(store.seatsLeft(winter)).toBe(0);
  });

  it("refuses one guest more than the seats left and books nothing", () => {
    const store = createBookingStore();
    store.book(winter, { ...guest, guests: 7 });
    const result = store.book(winter, { ...guest, guests: 4 });
    expect(result).toEqual({ ok: false, seatsLeft: 3 });
    expect(store.seatsLeft(winter)).toBe(3);
  });

  it("restores the seats of a cancelled booking", () => {
    const store = createBookingStore();
    const result = store.book(riesling, { ...guest, guests: 4 });
    if (!result.ok) throw new Error("expected booking");
    expect(store.cancel(result.booking.reference)).toBe(true);
    expect(store.seatsLeft(riesling)).toBe(12);
    expect(store.cancel(result.booking.reference)).toBe(false);
  });

  it("gives each booking a reference in the KB-XXXXXXXX format, unique per booking", () => {
    const store = createBookingStore();
    const roomy = { ...riesling, seats: 50 };
    const references = new Set<string>();
    for (let i = 0; i < 50; i++) {
      const result = store.book(roomy, { ...guest, guests: 1 });
      if (!result.ok) throw new Error("expected booking");
      expect(result.booking.reference).toMatch(/^KB-[A-Z2-9]{8}$/);
      references.add(result.booking.reference);
    }
    expect(references.size).toBe(50);
  });

  it("accepts one of two simultaneous requests that together exceed the seats", () => {
    const store = createBookingStore();
    store.book(winter, { ...guest, guests: 7 });
    const first = store.book(winter, { ...guest, guests: 2 });
    const second = store.book(winter, { ...guest, guests: 2 });
    expect([first.ok, second.ok].sort()).toEqual([false, true]);
    expect(store.seatsLeft(winter)).toBe(1);
  });
});
