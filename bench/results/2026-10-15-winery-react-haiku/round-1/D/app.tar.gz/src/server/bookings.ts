import { randomInt } from "node:crypto";
import type { BookingInput } from "../shared/booking.js";
import type { Tasting } from "../shared/tastings.js";

export type Booking = BookingInput & { reference: string; tastingId: string };

export type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; seatsLeft: number };

const referenceAlphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function newReference(): string {
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += referenceAlphabet[randomInt(referenceAlphabet.length)];
  }
  return `KB-${code}`;
}

export function createBookingStore() {
  const bookings = new Map<string, Booking>();

  function seatsLeft(tasting: Tasting): number {
    let booked = 0;
    for (const booking of bookings.values()) {
      if (booking.tastingId === tasting.id) booked += booking.guests;
    }
    return tasting.seats - booked;
  }

  // Check and insert run without an await in between, so concurrent requests cannot both pass the check.
  function book(tasting: Tasting, input: BookingInput): BookResult {
    const left = seatsLeft(tasting);
    if (input.guests > left) return { ok: false, seatsLeft: left };
    let reference = newReference();
    while (bookings.has(reference)) reference = newReference();
    const booking: Booking = { ...input, tastingId: tasting.id, reference };
    bookings.set(reference, booking);
    return { ok: true, booking };
  }

  return {
    seatsLeft,
    book,
    get: (reference: string) => bookings.get(reference),
    list: (): Booking[] => [...bookings.values()],
    cancel: (reference: string): boolean => bookings.delete(reference),
  };
}

export type BookingStore = ReturnType<typeof createBookingStore>;
