import { createApp } from "./app.js";

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;
const trustProxy = process.env.TRUST_PROXY === "true";

if (!staffPassword) {
  console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
}

createApp({ staffPassword, trustProxy }).listen(port, () => {
  console.log(`Weingut Kieselbrunnen listening on port ${port}`);
});
