import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "./app.js";

const guest = { name: "Anna Keller", email: "anna@example.com" };

function newApp() {
  return createApp({ staffPassword: "secret", trustProxy: false });
}

async function seatsLeft(app: ReturnType<typeof newApp>, id: string) {
  const res = await request(app).get("/api/tastings");
  return res.body.find((t: { id: string }) => t.id === id).seatsLeft;
}

describe("GET /api/tastings", () => {
  it("lists the tastings with seats left", async () => {
    const res = await request(newApp()).get("/api/tastings");
    expect(res.status).toBe(200);
    expect(
      res.body.map((t: { id: string; seatsLeft: number }) => [t.id, t.seatsLeft]),
    ).toEqual([
      ["riesling-evening", 12],
      ["red-wine-cellar-tour", 8],
      ["winter-tasting", 10],
    ]);
    expect(res.body[0]).toEqual({
      id: "riesling-evening",
      title: "Riesling Evening",
      startsAt: "2026-11-06 18:00",
      price: 25,
      seats: 12,
      seatsLeft: 12,
    });
  });
});

describe("POST /api/tastings/:id/bookings", () => {
  it("creates a booking and returns the confirmation details", async () => {
    const app = newApp();
    const res = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ ...guest, guests: 2 });
    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(/^KB-[A-Z2-9]{8}$/),
      tasting: {
        id: "riesling-evening",
        title: "Riesling Evening",
        startsAt: "2026-11-06 18:00",
        price: 25,
      },
      guests: 2,
      total: 50,
    });
    expect(await seatsLeft(app, "riesling-evening")).toBe(10);
  });

  it("returns 400 with a message per invalid field and creates nothing", async () => {
    const app = newApp();
    const res = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ name: "", email: "anna@", guests: 9 });
    expect(res.status).toBe(400);
    expect(res.body).toEqual({
      errors: {
        name: "Please enter your name",
        email: "Please enter a valid email address",
        guests: "Please enter a number of guests from 1 to 8",
      },
    });
    expect(await seatsLeft(app, "riesling-evening")).toBe(12);
  });

  it("treats a non-object JSON body as empty and reports every field", async () => {
    const res = await request(newApp())
      .post("/api/tastings/riesling-evening/bookings")
      .send([1, 2]);
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(["email", "guests", "name"]);
  });

  it("returns 409 with the seats left when guests exceed them", async () => {
    const app = newApp();
    await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send({ ...guest, guests: 8 });
    const res = await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send({ ...guest, guests: 3 });
    expect(res.status).toBe(409);
    expect(res.body).toEqual({ errors: { guests: "Only 2 seats left" } });
    expect(await seatsLeft(app, "winter-tasting")).toBe(2);
  });

  it("returns 409 when the tasting is fully booked", async () => {
    const app = newApp();
    await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send({ ...guest, guests: 8 });
    await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send({ ...guest, guests: 2 });
    const res = await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send({ ...guest, guests: 1 });
    expect(res.status).toBe(409);
    expect(res.body).toEqual({
      errors: { guests: "This tasting is fully booked" },
    });
  });

  it("returns 404 for an unknown tasting", async () => {
    const res = await request(newApp())
      .post("/api/tastings/unknown/bookings")
      .send({ ...guest, guests: 1 });
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Tasting not found" });
  });

  it("accepts one of two simultaneous requests that together exceed the seats", async () => {
    const app = newApp();
    await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send({ ...guest, guests: 7 });
    const [a, b] = await Promise.all([
      request(app).post("/api/tastings/winter-tasting/bookings").send({ ...guest, guests: 2 }),
      request(app).post("/api/tastings/winter-tasting/bookings").send({ ...guest, guests: 2 }),
    ]);
    expect([a.status, b.status].sort()).toEqual([201, 409]);
    expect(await seatsLeft(app, "winter-tasting")).toBe(1);
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the same confirmation details as the booking response", async () => {
    const app = newApp();
    const created = await request(app)
      .post("/api/tastings/red-wine-cellar-tour/bookings")
      .send({ ...guest, guests: 3 });
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual(created.body);
    expect(res.body.total).toBe(96);
  });

  it("does not expose the guest name or email", async () => {
    const app = newApp();
    const created = await request(app)
      .post("/api/tastings/red-wine-cellar-tour/bookings")
      .send({ ...guest, guests: 1 });
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(JSON.stringify(res.body)).not.toContain("anna@example.com");
  });

  it("returns 404 for an unknown reference", async () => {
    const res = await request(newApp()).get("/api/bookings/KB-NOPE0000");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Booking not found" });
  });
});
