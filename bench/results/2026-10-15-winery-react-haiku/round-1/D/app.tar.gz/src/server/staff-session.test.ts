import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "./app.js";

const password = "correct horse";
const guest = { name: "Anna Keller", email: "anna@example.com" };

async function signIn(app: ReturnType<typeof createApp>) {
  const res = await request(app).post("/api/staff/sign-in").send({ password });
  return (res.headers["set-cookie"] as unknown as string[]).map((c) => c.split(";")[0]).join("; ");
}

describe("staff session cookie", () => {
  it("is HttpOnly, SameSite=Strict and expires after 8 hours over plain HTTP", async () => {
    const app = createApp({ staffPassword: password });
    const res = await request(app).post("/api/staff/sign-in").send({ password });
    const cookie = res.headers["set-cookie"][0];
    expect(cookie).toContain("HttpOnly");
    expect(cookie).toContain("SameSite=Strict");
    const expires = Date.parse(/Expires=([^;]+)/.exec(cookie)![1]);
    expect(Math.abs(expires - Date.now() - 8 * 60 * 60 * 1000)).toBeLessThan(60_000);
    expect(cookie).not.toContain("Secure");
  });

  it("is also Secure when the request arrives over HTTPS", async () => {
    const app = createApp({ staffPassword: password, trustProxy: true });
    const res = await request(app)
      .post("/api/staff/sign-in")
      .set("X-Forwarded-Proto", "https")
      .send({ password });
    expect(res.headers["set-cookie"][0]).toContain("Secure");
  });
});

describe("protected staff endpoints", () => {
  it("refuse requests without a session with 401", async () => {
    const app = createApp({ staffPassword: password });
    expect((await request(app).get("/api/staff/bookings")).status).toBe(401);
    expect((await request(app).post("/api/staff/sign-out")).status).toBe(401);
    expect(
      (await request(app).delete("/api/staff/bookings/KB-NOPE0000")).status,
    ).toBe(401);
  });

  it("refuse a cross-site text/plain sign-out without a session", async () => {
    const app = createApp({ staffPassword: password });
    const res = await request(app)
      .post("/api/staff/sign-out")
      .set("Content-Type", "text/plain")
      .send("x");
    expect(res.status).toBe(401);
  });

  it("refuse a cancel without a session and keep the booking", async () => {
    const app = createApp({ staffPassword: password });
    const created = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ ...guest, guests: 2 });
    const del = await request(app).delete(`/api/staff/bookings/${created.body.reference}`);
    expect(del.status).toBe(401);
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
  });

  it("refuse a cross-site cancel or sign-out with a session cookie (403) and keep the session", async () => {
    const app = createApp({ staffPassword: password });
    const created = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ ...guest, guests: 2 });
    const cookie = await signIn(app);
    const cross = { Origin: "https://evil.example", Cookie: cookie };

    const del = await request(app)
      .delete(`/api/staff/bookings/${created.body.reference}`)
      .set(cross);
    expect(del.status).toBe(403);
    const out = await request(app).post("/api/staff/sign-out").set(cross);
    expect(out.status).toBe(403);

    const list = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(list.status).toBe(200);
    expect(list.body[0].bookings).toHaveLength(1);
  });

  it("list bookings grouped by tasting, including tastings without bookings", async () => {
    const app = createApp({ staffPassword: password });
    await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ ...guest, guests: 2 });
    await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ name: "Jonas Weber", email: "jonas@example.com", guests: 1 });
    await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send({ ...guest, guests: 4 });
    const cookie = await signIn(app);

    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(res.status).toBe(200);
    expect(
      res.body.map((g: { tastingId: string; bookings: unknown[] }) => [
        g.tastingId,
        g.bookings.length,
      ]),
    ).toEqual([
      ["riesling-evening", 2],
      ["red-wine-cellar-tour", 0],
      ["winter-tasting", 1],
    ]);
    expect(res.body[0].title).toBe("Riesling Evening");
    expect(res.body[0].bookings[0]).toEqual({
      reference: expect.stringMatching(/^KB-[A-Z2-9]{8}$/),
      name: "Anna Keller",
      email: "anna@example.com",
      guests: 2,
    });
  });

  it("cancel a booking with a session, free its seats and remove it from the list", async () => {
    const app = createApp({ staffPassword: password });
    const created = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ ...guest, guests: 4 });
    const cookie = await signIn(app);

    const del = await request(app)
      .delete(`/api/staff/bookings/${created.body.reference}`)
      .set("Cookie", cookie);
    expect(del.status).toBe(204);

    const tastings = await request(app).get("/api/tastings");
    expect(tastings.body[0].seatsLeft).toBe(12);
    const list = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(list.body[0].bookings).toEqual([]);
  });

  it("return 404 when cancelling an unknown reference", async () => {
    const app = createApp({ staffPassword: password });
    const cookie = await signIn(app);
    const res = await request(app)
      .delete("/api/staff/bookings/KB-NOPE0000")
      .set("Cookie", cookie);
    expect(res.status).toBe(404);
  });

  it("end the session on sign-out", async () => {
    const app = createApp({ staffPassword: password });
    const cookie = await signIn(app);
    const out = await request(app).post("/api/staff/sign-out").set("Cookie", cookie);
    expect(out.status).toBe(204);
    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(res.status).toBe(401);
  });
});
