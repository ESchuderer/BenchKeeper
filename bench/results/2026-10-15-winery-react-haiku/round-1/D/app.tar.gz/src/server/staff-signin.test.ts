import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "./app.js";

const password = "correct horse";

describe("POST /api/staff/sign-in", () => {
  it("signs in with the correct password and sets a session cookie", async () => {
    const app = createApp({ staffPassword: password });
    const res = await request(app).post("/api/staff/sign-in").send({ password });
    expect(res.status).toBe(204);
    expect(res.headers["set-cookie"]).toBeDefined();
  });

  it("refuses a wrong password with 'Incorrect password' and sets no cookie", async () => {
    const app = createApp({ staffPassword: password });
    const res = await request(app)
      .post("/api/staff/sign-in")
      .send({ password: "wrong" });
    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: "Incorrect password" });
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("refuses every sign-in when STAFF_PASSWORD is not set", async () => {
    const app = createApp({});
    const res = await request(app).post("/api/staff/sign-in").send({ password: "" });
    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: "Incorrect password" });
  });

  it("refuses a sign-in without a password field", async () => {
    const app = createApp({ staffPassword: password });
    const res = await request(app).post("/api/staff/sign-in").send({});
    expect(res.status).toBe(401);
  });

  it("refuses the 6th sign-in after 5 failed attempts, even with the correct password", async () => {
    const app = createApp({ staffPassword: password });
    for (let i = 0; i < 5; i++) {
      const res = await request(app)
        .post("/api/staff/sign-in")
        .send({ password: "wrong" });
      expect(res.status).toBe(401);
    }
    const res = await request(app).post("/api/staff/sign-in").send({ password });
    expect(res.status).toBe(429);
    expect(res.body).toEqual({ error: "Too many attempts. Try again later." });
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("does not count successful sign-ins towards the limit", async () => {
    const app = createApp({ staffPassword: password });
    for (let i = 0; i < 6; i++) {
      const res = await request(app).post("/api/staff/sign-in").send({ password });
      expect(res.status).toBe(204);
    }
  });
});
