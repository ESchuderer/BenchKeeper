import { describe, expect, it } from "vitest";
import { bookingSchema } from "./booking.js";

const valid = { name: "Anna Keller", email: "anna@example.com", guests: 2 };

function errorsFor(input: unknown) {
  const result = bookingSchema.safeParse(input);
  if (result.success) return {};
  const errors: Record<string, string> = {};
  for (const issue of result.error.issues) {
    errors[String(issue.path[0])] ??= issue.message;
  }
  return errors;
}

describe("bookingSchema", () => {
  it("accepts a valid booking", () => {
    expect(bookingSchema.safeParse(valid).success).toBe(true);
  });

  it("rejects an empty name", () => {
    expect(errorsFor({ ...valid, name: "   " })).toEqual({
      name: "Please enter your name",
    });
  });

  it("rejects an invalid email", () => {
    expect(errorsFor({ ...valid, email: "anna@" })).toEqual({
      email: "Please enter a valid email address",
    });
  });

  it.each([0, 9, 1.5, "abc"])("rejects guests %s", (guests) => {
    expect(errorsFor({ ...valid, guests })).toEqual({
      guests: "Please enter a number of guests from 1 to 8",
    });
  });

  it("rejects a name longer than 100 characters", () => {
    expect(errorsFor({ ...valid, name: "A".repeat(101) })).toEqual({
      name: "Please use 100 characters or fewer",
    });
  });

  it("rejects an email longer than 254 characters", () => {
    const email = `${"a".repeat(250)}@x.io`;
    expect(errorsFor({ ...valid, email })).toEqual({
      email: "Please enter a valid email address",
    });
  });

  it("accepts the guests bounds 1 and 8", () => {
    expect(bookingSchema.safeParse({ ...valid, guests: 1 }).success).toBe(true);
    expect(bookingSchema.safeParse({ ...valid, guests: 8 }).success).toBe(true);
  });

  it("trims the name before storing it", () => {
    const result = bookingSchema.parse({ ...valid, name: "  Anna Keller " });
    expect(result.name).toBe("Anna Keller");
  });
});
