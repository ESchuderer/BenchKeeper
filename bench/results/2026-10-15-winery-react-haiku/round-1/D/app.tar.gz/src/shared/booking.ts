import { z } from "zod";

const nameMessage = "Please enter your name";
const nameLengthMessage = "Please use 100 characters or fewer";
const emailMessage = "Please enter a valid email address";
const guestsMessage = "Please enter a number of guests from 1 to 8";

export const bookingSchema = z.object({
  name: z.string(nameMessage).trim().min(1, nameMessage).max(100, nameLengthMessage),
  email: z.email(emailMessage).max(254, emailMessage),
  guests: z
    .number(guestsMessage)
    .int(guestsMessage)
    .min(1, guestsMessage)
    .max(8, guestsMessage),
});

export type BookingInput = z.infer<typeof bookingSchema>;

export type BookingErrors = Partial<Record<keyof BookingInput, string>>;

export type BookingConfirmation = {
  reference: string;
  tasting: { id: string; title: string; startsAt: string; price: number };
  guests: number;
  total: number;
};
