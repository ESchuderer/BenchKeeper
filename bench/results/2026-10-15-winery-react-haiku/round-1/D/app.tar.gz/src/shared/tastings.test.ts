import { describe, expect, it } from "vitest";
import { findTasting, tastings, totalPrice } from "./tastings.js";

describe("tastings", () => {
  it("lists the three tastings with date, price and seats", () => {
    expect(
      tastings.map(({ id, title, startsAt, price, seats }) => ({
        id,
        title,
        startsAt,
        price,
        seats,
      })),
    ).toEqual([
      {
        id: "riesling-evening",
        title: "Riesling Evening",
        startsAt: "2026-11-06 18:00",
        price: 25,
        seats: 12,
      },
      {
        id: "red-wine-cellar-tour",
        title: "Red Wine Cellar Tour",
        startsAt: "2026-11-14 15:00",
        price: 32,
        seats: 8,
      },
      {
        id: "winter-tasting",
        title: "Winter Tasting",
        startsAt: "2026-12-05 17:00",
        price: 28,
        seats: 10,
      },
    ]);
  });

  it("finds a tasting by id and returns undefined for an unknown id", () => {
    expect(findTasting("winter-tasting")?.title).toBe("Winter Tasting");
    expect(findTasting("unknown")).toBeUndefined();
  });

  it("totals guests times the price per guest", () => {
    const riesling = findTasting("riesling-evening")!;
    expect(totalPrice(riesling, 2)).toBe(50);
    expect(totalPrice(riesling, 8)).toBe(200);
  });
});
