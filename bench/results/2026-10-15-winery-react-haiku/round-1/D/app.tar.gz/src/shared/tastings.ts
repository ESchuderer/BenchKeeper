export type Tasting = {
  id: string;
  title: string;
  startsAt: string;
  price: number;
  seats: number;
};

export const tastings: Tasting[] = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06 18:00",
    price: 25,
    seats: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14 15:00",
    price: 32,
    seats: 8,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05 17:00",
    price: 28,
    seats: 10,
  },
];

export function findTasting(id: string): Tasting | undefined {
  return tastings.find((tasting) => tasting.id === id);
}

export function totalPrice(tasting: Tasting, guests: number): number {
  return tasting.price * guests;
}
