# Design

## Context

The repository is empty apart from the OpenSpec and devcontainer setup. Node.js 22 is the runtime. The app must run with `npm install`, `npm run build` and `npm start` with no external services. See proposal.md for motivation and specs/ for the requirements.

## Goals / Non-Goals

**Goals:**
- One process serves the API and the React client on `PORT`.
- Seat counts stay correct under concurrent requests.
- Staff sign-in meets the session, cookie and failed-attempt requirements in specs/staff-sign-in.

**Non-Goals:**
- Horizontal scaling and shared session storage.
- Database, ORM or migrations.
- Internationalisation. The UI is English only.

## Decisions

**Server: Express 5.** It is the most widely used Node HTTP framework with a stable middleware model. Alternatives: Fastify (faster, but adds a plugin model the app does not need), Koa (smaller core, but needs more middleware for the same features).

**Client: React with Vite and react-router.** The app is a small set of pages. Vite builds static files that Express serves, which keeps one process and one port. Alternative: Next.js, which adds a second server model that the requirements do not need.

**Forms: react-hook-form with zod.** Field-level errors and touched state come from the library. The zod schema in `src/shared/booking.ts` is imported by the client (for `zodResolver`) and the server (for request validation), so both enforce the same rules. The server maps its field errors onto the same field names.

**Styling: Tailwind CSS v4 through `@tailwindcss/vite`.** Utility classes keep the layout responsive with breakpoints and avoid a separate stylesheet system. The palette (wine red, cream, dark green text) is defined as theme tokens.

**Persistence: one JSON file, written atomically.** `BOOKINGS_FILE` (default `data/bookings.json`) holds the bookings list. Writes go to a temporary file in the same directory and are renamed over the original, so a crash never leaves a partly written file. The in-memory array is the working copy; a booking is checked and inserted in one synchronous block, so two requests cannot both take the last seat. If the file write fails, the insert is rolled back and the request returns 500. Alternative: SQLite, which is a native dependency and not needed for three tastings.

**Tastings are code, not data.** `src/shared/tastings.ts` holds the three tastings. Seats left are computed from the bookings (seats minus the sum of guests), so cancelling a booking frees its seats without any stored counter that could drift.

**Prices and times.** Prices are whole euros, and a total is `pricePerGuest * guests`. Start times are wall-clock strings without a time zone, because the winery's local time is what guests expect to see.

**Booking references.** Eight characters from an unambiguous alphabet, generated with `crypto.randomBytes`. A collision retries generation. Guests look up confirmations by reference, which is why the public confirmation response omits name and email.

**Staff session: express-session with the default in-memory store.** Cookie: `httpOnly`, `sameSite: 'lax'`, `secure: 'auto'`, `maxAge` 2 hours, `rolling: true`. `rolling` renews the cookie expiry on each request. express-session does not expire sessions on the server, so the server stores `lastSeenAt` and `signedInAt` in the session and rejects a session idle for more than 2 hours or older than 12 hours. Every staff response carries `Cache-Control: no-store`. The session secret is random per process start, so a restart signs staff out. Alternative: a stored secret in an env var, which adds configuration for no gain with one process.
`// shortcut: MemoryStore keeps sessions in one process, upgrade to a shared store before running more than one process`

**Session fixation.** `req.session.regenerate` runs before the staff flag is set on sign-in. Sign-out calls `req.session.destroy` and clears the cookie.

**Password check.** The submitted and configured passwords are hashed with SHA-256 and compared with `crypto.timingSafeEqual`, which needs equal-length inputs. Hashing first makes the lengths equal. If `STAFF_PASSWORD` is unset or empty, sign-in returns 503 and nothing is compared.

**Failed-attempt limit.** `express-rate-limit` on the sign-in route with `limit: 5`, `windowMs: 15 minutes` and `skipSuccessfulRequests: true`. Successful sign-ins do not count toward the limit. The default limiter key is the client IP.

**Security headers and input limits.** `helmet` with default settings. Client code is built into external module scripts, so the default Content-Security-Policy holds without inline scripts. `express.json({ limit: '10kb' })` caps request bodies.

**Behind a proxy.** The app does not trust proxy headers by default. `TRUST_PROXY_HOPS` (a number) sets `trust proxy` to that hop count, so `secure` and the rate-limit key use the client address. `true` is not used, because it lets a direct client spoof `X-Forwarded-For`.

**Errors.** Validation errors return 400 with `{ errors: { field: message } }`. Seat-limit errors return 409 with the same shape on `guests`. Unexpected errors return 500 with a generic message, and the details go to the server log only.

**Routes.**
- `GET /api/tastings`: each tasting with `seatsLeft`.
- `POST /api/tastings/:id/bookings`: create a booking, returns 201 with the reference.
- `GET /api/bookings/:ref`: confirmation data without name or email, 404 when unknown.
- `POST /api/staff/session` (sign in), `DELETE /api/staff/session` (sign out), `GET /api/staff/session` (current state).
- `GET /api/staff/bookings`: bookings grouped by tasting, requires session.
- `DELETE /api/staff/bookings/:ref`: cancel, requires session, 404 when unknown.
- Any other `/api/*` path returns JSON 404. Every other GET serves the client `index.html`, so react-router handles the page.

## Risks / Trade-offs

- **Booking abuse** → Guests can book unlimited seats with any email address, and staff clear fake bookings by hand. No rate limit is applied to booking requests; a limit is a product decision left for later.
- **Session loss on restart** → Staff sign in again after a restart. Accepted for a single-process app; see the shortcut comment above.
- **Plain HTTP behind no proxy** → `secure: 'auto'` sends no Secure flag over HTTP. Behind a TLS-terminating proxy, set `TRUST_PROXY_HOPS` to the number of proxies, or the cookie is sent without Secure and all clients share one rate-limit bucket.
- **Bookings file corruption from manual edits** → If the file is not valid JSON, startup fails with a clear error and nothing is overwritten.
- **Shared staff password** → One password for all staff, with no per-person audit trail. Accepted by the requirements.
- **Concurrent processes** → Two processes writing the same file would overwrite each other. Mitigation: `npm start` runs one process, and the design says so.
