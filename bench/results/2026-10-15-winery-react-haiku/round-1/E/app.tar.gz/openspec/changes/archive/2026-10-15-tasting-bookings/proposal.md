# Proposal

## Why

Weingut Kieselbrunnen has no online way for guests to book wine tastings, and staff have no list of who is coming. This change adds a booking web app for the three tastings on offer.

## What Changes

- Guests see the tastings with date, time, price per guest and seats left, and book a tasting with a name, email and guest count (1 to 8).
- Bookings never exceed the seats left. Invalid input is rejected with a message next to the field.
- A confirmation page shows the tasting, guest count, total price and booking reference.
- Staff sign in at `/staff` with the password from `STAFF_PASSWORD`, see all bookings grouped by tasting, and cancel a booking, which frees its seats.
- Bookings are stored in a local JSON file (`BOOKINGS_FILE`, default `data/bookings.json`). The app starts with no bookings when that file does not exist.
- The app runs as one Node.js process: `npm run build`, then `npm start` on `PORT` (default 3000).

### Out of scope

- Past-date handling: bookings are accepted for any listed tasting.
- Sending confirmation emails, payments and price discounts.
- Editing a booking, changing a guest count, or changing a tasting.
- Multiple server processes sharing one bookings file.
- Multiple staff accounts. There is one shared password.
- Admin management of tastings. The three tastings are defined in code.

## Capabilities

### New Capabilities

- `tasting-booking`: the guest-facing tasting catalogue, booking form, seat limit, validation and booking confirmation.
- `staff-sign-in`: staff sign-in with the shared password, session expiry, sign-out and the failed-attempt limit.
- `staff-booking-admin`: the staff booking list grouped by tasting, and cancelling a booking.

### Modified Capabilities

None. `openspec/specs/` is empty.

## Impact

- New application code: an Express 5 server with express-session, express-rate-limit and helmet; a React client built with Vite, react-router, react-hook-form, zod and Tailwind CSS v4; a shared zod schema in `src/shared/`.
- New dependencies: the packages listed in `package.json`.
- New runtime file: `data/bookings.json` (git-ignored).
- New environment variables: `STAFF_PASSWORD` (required for staff sign-in), `PORT`, `BOOKINGS_FILE`.
- Security-relevant: staff authentication and session handling, and validation of guest input.
