# Spec Delta

## Purpose

Lets guests see the winery's tastings with their seats left, and book guests onto a tasting with a confirmed booking reference.

## ADDED Requirements

### Requirement: Tasting list shows seats left
The system SHALL list the three tastings with title, date and time, price per guest in EUR, and the number of seats left as "<n> seats left".

#### Scenario: No bookings yet
- **WHEN** a guest opens the start page and no bookings exist
- **THEN** each tasting shows its full seat count, for example "12 seats left" for Riesling Evening

#### Scenario: Seats taken by bookings
- **WHEN** bookings totalling 5 guests exist for Riesling Evening
- **THEN** Riesling Evening shows "7 seats left"

### Requirement: Fully booked tasting
The system SHALL mark a tasting with no seats left as fully booked and SHALL NOT offer a booking form for it.

#### Scenario: Last seat taken
- **WHEN** a guest opens the start page and Winter Tasting has 0 seats left
- **THEN** Winter Tasting shows a "Fully booked" state and no "Book Winter Tasting" link is shown

### Requirement: Booking form
The system SHALL provide, for each tasting with seats left, a link labelled "Book <tasting title>" that opens a form with the fields "Name", "Email" and "Guests" and a "Book" button.

#### Scenario: Open booking form
- **WHEN** a guest selects "Book Riesling Evening"
- **THEN** the form for Riesling Evening opens with the fields "Name", "Email" and "Guests"

### Requirement: Booking is accepted within the seat limit
The system SHALL create a booking when name, email and guest count are valid and the guest count does not exceed the seats left, and SHALL reduce the seats left by the guest count.

#### Scenario: Valid booking
- **WHEN** a guest books 3 guests on Red Wine Cellar Tour, which has 8 seats left
- **THEN** a booking is stored and the tasting shows "5 seats left"

#### Scenario: Booking more guests than seats left
- **WHEN** a guest books 4 guests on a tasting with 3 seats left
- **THEN** no booking is stored, the seats left stay at 3, and the "Guests" field shows an error that names the seats left

#### Scenario: Last seats booked
- **WHEN** a guest books exactly the seats left
- **THEN** the booking is stored and the tasting shows "Fully booked"

### Requirement: Guest count limits
The system SHALL accept a guest count only when it is a whole number from 1 to 8.

#### Scenario: Guest count out of range
- **WHEN** a guest enters 0 or 9 in "Guests"
- **THEN** the booking is rejected and the "Guests" field shows an error

#### Scenario: Guest count not a whole number
- **WHEN** a guest enters 2.5 in "Guests"
- **THEN** the booking is rejected and the "Guests" field shows an error

### Requirement: Contact details validation
The system SHALL require a non-empty name of at most 100 characters and a valid email address of at most 254 characters, and SHALL show each error next to the field it concerns.

#### Scenario: Missing name
- **WHEN** a guest submits a form whose name is empty or only spaces
- **THEN** the booking is rejected and the "Name" field shows an error

#### Scenario: Invalid email
- **WHEN** a guest submits "guest@example" as the email
- **THEN** the booking is rejected and the "Email" field shows an error

#### Scenario: Control characters in the name
- **WHEN** a guest submits a name containing a line break or an invisible formatting character
- **THEN** the booking is rejected and the "Name" field shows an error

### Requirement: Server enforces the seat limit
The system SHALL check the seat limit on the server for every booking request, independent of what the form shows.

#### Scenario: Stale form
- **WHEN** a guest submits a booking for 2 guests after another guest has taken the last seat
- **THEN** the server rejects the booking with an error on the "Guests" field and stores nothing

#### Scenario: Concurrent bookings
- **WHEN** 20 booking requests for 1 guest each arrive at once for a tasting with 8 seats left
- **THEN** exactly 8 bookings are stored and no more than 8 seats are taken

### Requirement: Booking confirmation
The system SHALL show a confirmation page with the heading "Booking confirmed", the tasting, the number of guests, the total price and the booking reference after a successful booking.

#### Scenario: Confirmation after booking
- **WHEN** a booking for 3 guests on Riesling Evening (EUR 25 per guest) succeeds
- **THEN** the page shows the heading "Booking confirmed", "Riesling Evening", 3 guests, a total of EUR 75 and a booking reference

#### Scenario: Reopening a confirmation
- **WHEN** a guest opens the confirmation URL for a valid booking reference
- **THEN** the same tasting, guest count, total and reference are shown

#### Scenario: Unknown reference
- **WHEN** a guest opens the confirmation URL for a reference that does not exist
- **THEN** the page shows a "Booking not found" message

### Requirement: Public confirmation hides personal data
The confirmation page and its API response SHALL NOT show the guest's name or email address.

#### Scenario: Confirmation data
- **WHEN** the confirmation data for a booking is requested by reference
- **THEN** the response contains the tasting, guest count, total and reference, and no name or email

### Requirement: Booking reference
The system SHALL give each booking a reference of 8 characters from an unambiguous alphanumeric set, generated with a cryptographically secure random source and unique among bookings.

#### Scenario: Reference format
- **WHEN** a booking is created
- **THEN** its reference is 8 characters, each one of the letters A to Z without I and O, or a digit from 2 to 9

### Requirement: Failed submissions show an error state
The system SHALL show an error message on the form, next to the affected field, when a booking is rejected, and SHALL keep the entered values.

#### Scenario: Server error
- **WHEN** the booking request fails because the server cannot store the booking
- **THEN** the form shows a general error message and keeps the name, email and guest count the guest entered
