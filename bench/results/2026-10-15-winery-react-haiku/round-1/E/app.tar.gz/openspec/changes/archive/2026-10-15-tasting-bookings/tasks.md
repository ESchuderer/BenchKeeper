# Tasks

## 1. Project setup

- [x] 1.1 Confirm `package.json` scripts `build`, `start`, `test` and `typecheck` exist and that `npm run typecheck` passes on an empty `src/server/index.ts` and `src/client/main.tsx`
- [x] 1.2 Confirm `npm test` runs vitest in the devcontainer and that the first test file added in 2.1 is discovered by it
- [x] 1.3 Add `index.html` and a Tailwind v4 `src/client/index.css` with the wine-palette theme tokens, and confirm `npm run build` produces `dist/client/index.html`

## 2. Shared tasting catalogue and booking schema

- [x] 2.1 Write failing tests in `src/shared/booking.test.ts` for the schema: name required and at most 100 characters, whitespace-only name rejected, email trimmed and validated, email at most 254 characters, guests an integer from 1 to 8, NaN rejected with "Enter the number of guests"; run `npm test` and see them fail
- [x] 2.2 Implement `src/shared/booking.ts` until the tests from 2.1 pass
- [x] 2.3 Write a test in `src/shared/tastings.test.ts` that the catalogue has the three tastings with the titles, start times, prices and seat counts from the request, and that `findTasting` returns undefined for an unknown id; implement `src/shared/tastings.ts` until it passes

## 3. Booking store

- [x] 3.1 Write failing tests in `src/server/bookings.test.ts` for `createBooking`: it stores the booking with a reference of 8 characters from the spec alphabet; it returns a seat-limit error and stores nothing when guests exceed seats left; it reduces seats left by guests; `seatsLeft` equals seats minus the sum of guests; run `npm test` and see them fail
- [x] 3.2 Implement `src/server/bookings.ts` (in-memory working copy, synchronous check and insert, `crypto.randomBytes` references) until the tests from 3.1 pass
- [x] 3.3 Add failing tests for persistence: a store created with a missing `BOOKINGS_FILE` starts empty; bookings written by one store instance are loaded by a new instance on the same file with the same seats left; a file write failure rolls back the insert and throws; then implement atomic write (temp file then rename) until they pass
- [x] 3.4 Add a failing test that 20 concurrent `createBooking` calls for 1 guest on a tasting with 8 seats store exactly 8 bookings; confirm it passes with the synchronous implementation from 3.2
- [x] 3.5 Add `cancelBooking(ref)`: a failing test that it removes the booking, frees its seats and returns false for an unknown reference; implement until it passes

## 4. Guest API

- [x] 4.1 Write failing supertest tests in `src/server/api.guest.test.ts` for `GET /api/tastings`: each tasting has `seatsLeft` equal to seats when no bookings exist; run and see them fail
- [x] 4.2 Write failing tests for `POST /api/tastings/:id/bookings`: valid input returns 201 with reference and total (3 guests at EUR 25 gives 75), and seats left drop by 3; guests 0, 9, 2.5 and "3" each return 400 with an error on `guests`; a bad email, empty name and whitespace-only name each return 400 with an error on that field; an unknown tasting id returns 404; guests above seats left return 409 with an error on `guests` and store nothing
- [x] 4.3 Write failing tests for malformed JSON (400), a body over 10 kB (413), and a store error forced by a test double (500 with a generic message and no stack in the body)
- [x] 4.4 Write failing tests for `GET /api/bookings/:ref`: returns tasting, guests, total and reference with no name or email; unknown reference returns 404
- [x] 4.5 Implement the guest routes, `express.json({ limit: '10kb' })`, helmet, the JSON 404 for unknown `/api` paths and the error handler in `src/server/app.ts` until 4.1 to 4.4 pass

## 5. Staff API

- [x] 5.1 Write failing tests in `src/server/api.staff.test.ts` for sign-in: correct password returns 200 and sets a cookie with HttpOnly and SameSite=Lax and no Secure over HTTP; wrong password returns 401; `STAFF_PASSWORD` unset returns 503 for every attempt
- [x] 5.2 Write failing tests for the failed-attempt limit: the sixth failed attempt within 15 minutes returns 429; ten successful sign-ins followed by four failures are not refused
- [x] 5.3 Write failing tests for session fixation: the session identifier after a successful sign-in differs from the one sent with the request
- [x] 5.4 Write failing tests for sign-out: after `DELETE /api/staff/session`, the old cookie gets 401 on `GET /api/staff/bookings`
- [x] 5.5 Write failing tests that `GET /api/staff/bookings` and `DELETE /api/staff/bookings/:ref` return 401 without a session; that the list groups bookings by tasting with name, email, guests and reference and a "No bookings yet" marker for empty tastings; that cancel removes the booking and frees its seats; and that cancelling an unknown reference returns 404
- [x] 5.6 Implement the staff routes, `express-session` with `httpOnly`, `sameSite: 'lax'`, `secure: 'auto'`, `maxAge` 2 hours, `rolling: true`, a random secret per process start, `express-rate-limit` with `skipSuccessfulRequests: true`, and the SHA-256 plus `timingSafeEqual` password check in `src/server/staff.ts`, until 5.1 to 5.5 pass
- [x] 5.7 Add a shortcut comment on the session store that states the single-process limit and the upgrade condition

## 6. Server entry point

- [x] 6.1 Write a failing test that `GET /` returns the client `index.html` and an unknown non-API path returns it too, then serve `dist/client` with `express.static` and the fallback until it passes
- [x] 6.2 Implement `src/server/index.ts`: read `PORT` (default 3000) and `BOOKINGS_FILE`, log a startup warning when `STAFF_PASSWORD` is unset, listen, and confirm `npm run build && PORT=3100 npm start` serves the app and `GET /api/tastings` returns 200

## 7. Guest interface

- [x] 7.1 Implement `src/client/api.ts` with typed fetch wrappers for the guest and staff routes, returning parsed JSON and the status code
- [x] 7.2 Implement the start page: a card per tasting with title, date and time (for example "Friday 6 November 2026, 18:00"), price per guest, "<n> seats left", a "Fully booked" state with no link when seats left is 0, and a "Book <title>" link otherwise; verify with `npm run typecheck` and a Playwright snapshot
- [x] 7.3 Implement the booking form page with react-hook-form and `zodResolver(bookingInputSchema)`: fields "Name", "Email" and "Guests" (number input, 1 to 8), a "Book" button, an error message under each invalid field linked with `aria-describedby`, and a general error message on server failure; map 400 and 409 field errors from the server with `setError`; verify each error case with a Playwright run
- [x] 7.4 Implement the fully-booked booking page: the form is not shown and the page says the tasting is fully booked
- [x] 7.5 Implement the confirmation page at `/confirmation/:ref`: heading "Booking confirmed", tasting, guests, total in EUR and the reference; a "Booking not found" message for unknown references; verify with a Playwright run that completes a booking and reaches the confirmation
- [x] 7.6 Verify the guest pages in Playwright at 1280px and 390px width: no horizontal scroll, touch targets at least 44px high, and visible focus states

## 8. Staff interface

- [x] 8.1 Implement the `/staff` page: when `GET /api/staff/session` returns 401, show the "Password" field, the "Sign in" button, "Wrong password" for 401, "Too many attempts" for 429 and "Staff sign-in is not configured" for 503
- [x] 8.2 Implement the bookings view: groups per tasting with "<n> of <seats> seats booked", each booking with name, email, guests and reference, a "Cancel" button per booking, "No bookings yet" for empty groups, and a "Sign out" button that calls `DELETE /api/staff/session`
- [x] 8.3 Verify in Playwright: sign in with the right password, cancel a booking and see its seats freed on the guest start page, sign out and see the sign-in form again, and sign in at 390px width

## 9. Integration checks

- [x] 9.1 Run `npm run typecheck`, `npm test` and `npm run build`; all must pass with no skipped tests
- [x] 9.2 Start the app with `STAFF_PASSWORD` and `BOOKINGS_FILE` set to a temp path, complete one booking in the browser, restart the server, and confirm the booking and seats left survive
- [x] 9.3 Run the code-reviewer agent on the branch diff and the security-reviewer agent on the staff sign-in, session and input handling; fix CRITICAL and HIGH findings and report MEDIUM ones

## Workflow follow-up

- Archive the change on branch `feat/tasting-bookings` after the checks above pass, and never on `main`.
