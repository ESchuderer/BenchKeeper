# staff-booking-admin Specification

## Purpose

Lets signed-in staff see every booking grouped by tasting and cancel a booking so its seats become available to guests again.

## Requirements

### Requirement: Bookings grouped by tasting
The system SHALL show signed-in staff all bookings grouped by tasting, with each booking's name, email, guest count and reference.

#### Scenario: Grouped list
- **WHEN** staff open the bookings view and bookings exist for two tastings
- **THEN** the view shows one group per tasting and each booking appears under its own tasting with name, email, guests and reference

#### Scenario: Tasting without bookings
- **WHEN** staff open the bookings view and a tasting has no bookings
- **THEN** that tasting's group shows "No bookings yet"

#### Scenario: No bookings at all
- **WHEN** staff open the bookings view and no bookings exist
- **THEN** every tasting group shows "No bookings yet"

### Requirement: Seats summary per tasting
The system SHALL show, for each tasting group, the number of seats booked out of the seat count.

#### Scenario: Summary
- **WHEN** 5 guests are booked on Riesling Evening, which has 12 seats
- **THEN** its group shows "5 of 12 seats booked"

### Requirement: Cancel a booking
The system SHALL cancel a booking when staff select its "Cancel" button, and SHALL remove it from the list.

#### Scenario: Cancel
- **WHEN** staff select "Cancel" on a booking for 3 guests
- **THEN** the booking is removed from the list and the tasting's seats left increase by 3

#### Scenario: Cancelled booking reference
- **WHEN** a cancelled booking's reference is used on the guest confirmation page
- **THEN** the page shows "Booking not found"

### Requirement: Cancel of an unknown booking
The system SHALL reject a cancel request for a reference that does not exist with HTTP 404 and SHALL change no booking.

#### Scenario: Already cancelled
- **WHEN** staff send a cancel request for a reference that was already cancelled
- **THEN** the response is HTTP 404 and the other bookings are unchanged

### Requirement: Bookings survive restarts
The system SHALL keep bookings in the file at `BOOKINGS_FILE` (default `data/bookings.json`) and SHALL load them at startup. When the file does not exist, the system SHALL start with no bookings.

#### Scenario: Restart
- **WHEN** the server restarts with the same `BOOKINGS_FILE`
- **THEN** all bookings and seat counts are the same as before the restart

#### Scenario: First start
- **WHEN** the server starts and `BOOKINGS_FILE` does not exist
- **THEN** no bookings exist and all seats are available
