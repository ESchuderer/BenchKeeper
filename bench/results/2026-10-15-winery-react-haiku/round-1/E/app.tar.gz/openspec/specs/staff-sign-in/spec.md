# staff-sign-in Specification

## Purpose

Lets winery staff prove they know the shared staff password and keeps the staff area closed to everyone else, with sessions that expire and can be ended.

## Requirements

### Requirement: Staff sign-in page
The system SHALL show a sign-in page at `/staff` with a "Password" field and a "Sign in" button while no staff session exists.

#### Scenario: Signed out visitor
- **WHEN** a visitor opens `/staff` without a staff session
- **THEN** the page shows the "Password" field and the "Sign in" button

### Requirement: Password check
The system SHALL sign staff in only when the submitted password equals the value of the `STAFF_PASSWORD` environment variable.

#### Scenario: Correct password
- **WHEN** staff submit the correct password
- **THEN** a staff session is created and the bookings view is shown

#### Scenario: Wrong password
- **WHEN** staff submit a wrong password
- **THEN** no session is created and the page shows "Wrong password"

#### Scenario: Password not configured
- **WHEN** `STAFF_PASSWORD` is unset or empty
- **THEN** every sign-in attempt fails and the page shows that staff sign-in is not configured

### Requirement: Constant-time password comparison
The system SHALL compare the submitted password with the configured password in constant time.

#### Scenario: Comparison
- **WHEN** a password is checked
- **THEN** the comparison time does not depend on how many leading characters match

### Requirement: Failed sign-in limit
The system SHALL refuse further sign-in attempts from the same client with HTTP 429 after 5 failed attempts within 15 minutes, and SHALL NOT count successful sign-ins toward that limit.

#### Scenario: Sixth failed attempt
- **WHEN** a client makes 5 failed sign-in attempts and then a sixth attempt within 15 minutes
- **THEN** the sixth attempt is refused with HTTP 429 and the page shows a "Too many attempts" message

#### Scenario: Successful sign-in does not count
- **WHEN** a client signs in successfully 10 times and then makes 4 failed attempts
- **THEN** the client is not refused

### Requirement: Session cookie
The system SHALL send the staff session cookie with the HttpOnly and SameSite=Lax attributes, and SHALL add the Secure attribute when the request is served over HTTPS.

#### Scenario: Cookie attributes over HTTP
- **WHEN** a staff session is created over plain HTTP
- **THEN** the cookie has HttpOnly and SameSite=Lax and no Secure attribute

#### Scenario: Cookie attributes over HTTPS
- **WHEN** a staff session is created over HTTPS
- **THEN** the cookie has HttpOnly, SameSite=Lax and Secure

#### Scenario: Script access
- **WHEN** page script reads the cookies
- **THEN** the staff session cookie is not visible to it

### Requirement: Session fixation protection
The system SHALL issue a new session identifier at each successful sign-in.

#### Scenario: Identifier changes on sign-in
- **WHEN** a visitor with an existing session identifier signs in successfully
- **THEN** the response sets a session identifier different from the one sent with the request

### Requirement: Session expiry
The system SHALL end a staff session after 2 hours without activity, and SHALL end every staff session 12 hours after sign-in even when it stays active.

#### Scenario: Absolute lifetime
- **WHEN** a staff member makes a request every hour for 12 hours after signing in and then makes another request
- **THEN** the request is treated as signed out

#### Scenario: Idle session
- **WHEN** a staff session receives no requests for 2 hours
- **THEN** the next request to a staff endpoint is treated as signed out

#### Scenario: Active session
- **WHEN** a staff member makes a request every 30 minutes
- **THEN** the session stays signed in

### Requirement: Sign-out
The system SHALL end the staff session when staff sign out, and SHALL NOT accept the old session identifier afterwards.

#### Scenario: Sign out
- **WHEN** staff select "Sign out"
- **THEN** the session is destroyed, the bookings view is hidden and the sign-in page is shown

#### Scenario: Reusing an old session after sign-out
- **WHEN** a request is sent with the session identifier from before sign-out
- **THEN** the request is treated as signed out

### Requirement: Staff endpoints require a session
The system SHALL reject every request to a staff booking endpoint that has no valid staff session with HTTP 401.

#### Scenario: Unauthenticated list request
- **WHEN** a request without a staff session asks for the bookings list
- **THEN** the response is HTTP 401 and contains no booking data
