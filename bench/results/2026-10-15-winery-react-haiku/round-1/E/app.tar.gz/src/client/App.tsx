import { Route, Routes } from "react-router";
import { Layout } from "./components/Layout";
import { BookingPage } from "./pages/BookingPage";
import { ConfirmationPage } from "./pages/ConfirmationPage";
import { StaffPage } from "./pages/StaffPage";
import { TastingsPage } from "./pages/TastingsPage";

export function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<TastingsPage />} />
        <Route path="/book/:id" element={<BookingPage />} />
        <Route path="/confirmation/:ref" element={<ConfirmationPage />} />
        <Route path="/staff" element={<StaffPage />} />
        <Route path="*" element={<p className="text-muted">Page not found.</p>} />
      </Routes>
    </Layout>
  );
}
