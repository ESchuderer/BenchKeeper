import type { BookingInput, FieldErrors } from "../shared/booking.js";

export type Tasting = {
  id: string;
  title: string;
  startsAt: string;
  pricePerGuest: number;
  seats: number;
  seatsLeft: number;
};

export type Confirmation = {
  reference: string;
  tasting: { id: string; title: string; startsAt: string };
  guests: number;
  total: number;
};

export type StaffBooking = { reference: string; name: string; email: string; guests: number };

export type StaffGroup = {
  tasting: { id: string; title: string; startsAt: string; seats: number };
  seatsBooked: number;
  bookings: StaffBooking[];
};

export type ApiResult<T> =
  | { ok: true; status: number; data: T }
  | { ok: false; status: number; error?: string; errors?: FieldErrors };

async function request<T>(url: string, init?: RequestInit): Promise<ApiResult<T>> {
  try {
    const response = await fetch(url, init);
    const body: unknown = await response.json().catch(() => ({}));
    if (response.ok) return { ok: true, status: response.status, data: body as T };
    const failure = body as { error?: string; errors?: FieldErrors };
    return { ok: false, status: response.status, error: failure.error, errors: failure.errors };
  } catch {
    return { ok: false, status: 0, error: "Network error. Check your connection and try again." };
  }
}

function postJson(url: string, body: unknown): RequestInit {
  return {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
}

const json = { headers: { Accept: "application/json" } };

export const listTastings = () => request<Tasting[]>("/api/tastings", json);

export const createBooking = (tastingId: string, input: BookingInput) =>
  request<Confirmation>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, postJson("/", input));

export const getBooking = (reference: string) =>
  request<Confirmation>(`/api/bookings/${encodeURIComponent(reference)}`, json);

export const getStaffSession = () => request<{ signedIn: true }>("/api/staff/session", json);

export const signIn = (password: string) =>
  request<{ signedIn: true }>("/api/staff/session", postJson("/", { password }));

export const signOut = () => request<null>("/api/staff/session", { method: "DELETE" });

export const listStaffBookings = () => request<StaffGroup[]>("/api/staff/bookings", json);

export const cancelBooking = (reference: string) =>
  request<null>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: "DELETE" });
