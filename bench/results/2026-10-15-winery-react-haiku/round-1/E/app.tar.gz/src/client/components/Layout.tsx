import type { ReactNode } from "react";
import { Link } from "react-router";

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-wine text-cream">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-5 py-5">
          <Link to="/" className="inline-flex min-h-11 items-center font-serif text-2xl tracking-wide hover:underline">
            Weingut Kieselbrunnen
          </Link>
          <p className="text-sm uppercase tracking-[0.2em] text-parchment">Family winery</p>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-10">{children}</main>
      <footer className="border-t border-parchment bg-parchment/60">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-5 py-5 text-sm text-muted">
          <span>Weingut Kieselbrunnen, family winery</span>
          <Link to="/staff" className="inline-flex min-h-11 items-center font-medium text-wine underline-offset-4 hover:underline">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
