export function LoadingMessage({ children }: { children: string }) {
  return (
    <p role="status" className="py-12 text-center text-muted">
      {children}
    </p>
  );
}

export function ErrorMessage({ children }: { children: string }) {
  return (
    <p role="alert" className="rounded-md border border-alert/30 bg-red-50 px-4 py-3 text-alert">
      {children}
    </p>
  );
}
