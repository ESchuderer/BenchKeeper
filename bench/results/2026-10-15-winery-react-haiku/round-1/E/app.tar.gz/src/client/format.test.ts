import { describe, expect, it } from "vitest";
import { formatStart, seatsLeftLabel } from "./format.js";

describe("formatStart", () => {
  it("prints the weekday, date and wall-clock time without shifting the day", () => {
    expect(formatStart("2026-11-06T18:00")).toBe("Friday, 6 November 2026, 18:00");
    expect(formatStart("2026-12-05T17:00")).toBe("Saturday, 5 December 2026, 17:00");
  });
});

describe("seatsLeftLabel", () => {
  it("uses the seat or seats form for the count", () => {
    expect(seatsLeftLabel(7)).toBe("7 seats left");
    expect(seatsLeftLabel(1)).toBe("1 seat left");
    expect(seatsLeftLabel(0)).toBe("0 seats left");
  });
});
