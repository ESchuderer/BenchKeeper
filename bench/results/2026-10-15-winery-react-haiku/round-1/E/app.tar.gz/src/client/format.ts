// startsAt is wall-clock time at the winery ("2026-11-06T18:00"), so dates are formatted in UTC to keep the printed day stable.
export function formatStart(startsAt: string): string {
  const [date, time] = startsAt.split("T");
  const [year, month, day] = date.split("-").map(Number);
  const dayLabel = new Date(Date.UTC(year, month - 1, day)).toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  });
  return `${dayLabel}, ${time}`;
}

export function formatEur(amount: number): string {
  return `EUR ${amount}`;
}

export function seatsLeftLabel(seatsLeft: number): string {
  return `${seatsLeft} ${seatsLeft === 1 ? "seat" : "seats"} left`;
}
