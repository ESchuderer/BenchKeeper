import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useNavigate, useParams } from "react-router";
import { type ApiResult, createBooking, listTastings, type Tasting } from "../api";
import { ErrorMessage, LoadingMessage } from "../components/Status";
import { Field, inputClass } from "../components/Field";
import { bookingInputSchema, type BookingInput } from "../../shared/booking";
import { formatEur, formatStart, seatsLeftLabel } from "../format";

const GENERIC_ERROR = "Something went wrong. Please try again.";

export function BookingPage() {
  const { id = "" } = useParams();
  const [result, setResult] = useState<ApiResult<Tasting[]> | null>(null);

  useEffect(() => {
    let active = true;
    listTastings().then((next) => {
      if (active) setResult(next);
    });
    return () => {
      active = false;
    };
  }, []);

  if (!result) return <LoadingMessage>Loading tasting…</LoadingMessage>;
  if (!result.ok) return <ErrorMessage>The tasting could not be loaded. Please reload the page.</ErrorMessage>;

  const tasting = result.data.find((item) => item.id === id);
  if (!tasting) {
    return (
      <section className="grid gap-6">
        <ErrorMessage>That tasting does not exist.</ErrorMessage>
        <Link to="/" className="font-medium text-wine underline underline-offset-4">
          Back to the tastings
        </Link>
      </section>
    );
  }
  if (tasting.seatsLeft === 0) return <FullyBooked tasting={tasting} />;
  return <BookingForm tasting={tasting} />;
}

function FullyBooked({ tasting }: { tasting: Tasting }) {
  return (
    <section className="grid max-w-xl gap-6">
      <h1 className="font-serif text-3xl text-wine-dark">{tasting.title} is fully booked</h1>
      <p className="text-muted">There are no seats left for this tasting.</p>
      <Link
        to="/"
        className="inline-flex min-h-11 w-fit items-center rounded-md bg-wine px-5 font-medium text-white hover:bg-wine-dark"
      >
        See other tastings
      </Link>
    </section>
  );
}

function BookingForm({ tasting }: { tasting: Tasting }) {
  const navigate = useNavigate();
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: "", email: "", guests: 1 },
  });

  async function onSubmit(values: BookingInput) {
    setFormError(null);
    const result = await createBooking(tasting.id, values);
    if (result.ok) {
      navigate(`/confirmation/${result.data.reference}`);
      return;
    }
    if (result.errors) {
      for (const [field, message] of Object.entries(result.errors)) {
        setError(field as keyof BookingInput, { type: "server", message });
      }
      return;
    }
    setFormError(result.error ?? GENERIC_ERROR);
  }

  return (
    <section className="grid max-w-xl gap-6">
      <div>
        <h1 className="font-serif text-3xl text-wine-dark">Book {tasting.title}</h1>
        <p className="mt-2 text-ink">{formatStart(tasting.startsAt)}</p>
        <p className="text-ink">
          {formatEur(tasting.pricePerGuest)} per guest · <span className="font-medium text-vine">{seatsLeftLabel(tasting.seatsLeft)}</span>
        </p>
      </div>

      {formError ? <ErrorMessage>{formError}</ErrorMessage> : null}

      <form noValidate onSubmit={handleSubmit(onSubmit)} className="grid gap-5 rounded-lg bg-white p-6 shadow-sm ring-1 ring-parchment">
        <Field id="name" label="Name" error={errors.name?.message}>
          <input
            id="name"
            type="text"
            autoComplete="name"
            className={inputClass}
            aria-invalid={errors.name ? true : undefined}
            aria-describedby={errors.name ? "name-error" : undefined}
            {...register("name")}
          />
        </Field>
        <Field id="email" label="Email" error={errors.email?.message}>
          <input
            id="email"
            type="email"
            autoComplete="email"
            inputMode="email"
            className={inputClass}
            aria-invalid={errors.email ? true : undefined}
            aria-describedby={errors.email ? "email-error" : undefined}
            {...register("email")}
          />
        </Field>
        <Field id="guests" label="Guests" error={errors.guests?.message}>
          <input
            id="guests"
            type="number"
            inputMode="numeric"
            className={inputClass}
            aria-invalid={errors.guests ? true : undefined}
            aria-describedby={errors.guests ? "guests-error" : undefined}
            {...register("guests", { valueAsNumber: true })}
          />
          <span className="text-sm text-muted">Between 1 and 8 guests.</span>
        </Field>
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex min-h-11 items-center justify-center rounded-md bg-wine px-5 py-2 font-medium text-white hover:bg-wine-dark disabled:opacity-60"
        >
          {isSubmitting ? "Booking…" : "Book"}
        </button>
      </form>
    </section>
  );
}
