import { useEffect, useState } from "react";
import { useParams, Link } from "react-router";
import { type ApiResult, type Confirmation, getBooking } from "../api";
import { ErrorMessage, LoadingMessage } from "../components/Status";
import { formatEur, formatStart } from "../format";

export function ConfirmationPage() {
  const { ref = "" } = useParams();
  const [result, setResult] = useState<ApiResult<Confirmation> | null>(null);

  useEffect(() => {
    let active = true;
    setResult(null);
    getBooking(ref).then((next) => {
      if (active) setResult(next);
    });
    return () => {
      active = false;
    };
  }, [ref]);

  if (!result) return <LoadingMessage>Loading your booking…</LoadingMessage>;
  if (!result.ok) {
    const message =
      result.status === 404
        ? "Booking not found. Check the reference and try again."
        : "Your booking could not be loaded. Please reload the page.";
    return (
      <section className="grid gap-6">
        <ErrorMessage>{message}</ErrorMessage>
        <Link to="/" className="font-medium text-wine underline underline-offset-4">
          Back to the tastings
        </Link>
      </section>
    );
  }

  const booking = result.data;
  return (
    <section aria-labelledby="confirmed-heading" className="mx-auto max-w-xl">
      <div className="rounded-lg bg-white p-8 shadow-sm ring-1 ring-vine/30">
        <p className="text-sm font-semibold uppercase tracking-wide text-vine">Thank you</p>
        <h1 id="confirmed-heading" className="mt-2 font-serif text-3xl text-wine-dark">
          Booking confirmed
        </h1>
        <dl className="mt-6 grid gap-4 sm:grid-cols-2">
          <Detail label="Tasting" value={booking.tasting.title} />
          <Detail label="Date and time" value={formatStart(booking.tasting.startsAt)} />
          <Detail label="Guests" value={String(booking.guests)} />
          <Detail label="Total" value={formatEur(booking.total)} />
          <Detail label="Booking reference" value={booking.reference} className="sm:col-span-2" />
        </dl>
        <p className="mt-6 text-sm text-muted">Please keep this reference for your visit.</p>
      </div>
      <Link to="/" className="mt-6 inline-block font-medium text-wine underline underline-offset-4">
        Back to the tastings
      </Link>
    </section>
  );
}

function Detail({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return (
    <div className={className}>
      <dt className="text-sm text-muted">{label}</dt>
      <dd className="font-medium text-ink">{value}</dd>
    </div>
  );
}
