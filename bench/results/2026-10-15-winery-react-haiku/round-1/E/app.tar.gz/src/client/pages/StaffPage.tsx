import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  type ApiResult,
  cancelBooking,
  getStaffSession,
  listStaffBookings,
  type StaffGroup,
  signIn,
  signOut,
} from "../api";
import { Field, inputClass } from "../components/Field";
import { ErrorMessage, LoadingMessage } from "../components/Status";
import { formatStart } from "../format";

const SIGN_IN_ERRORS: Record<number, string> = {
  401: "Wrong password",
  429: "Too many attempts. Try again later.",
  503: "Staff sign-in is not configured",
};

const passwordSchema = z.object({ password: z.string().min(1, "Enter the password") });
type PasswordInput = z.infer<typeof passwordSchema>;

export function StaffPage() {
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  const markSignedOut = useCallback(() => setSignedIn(false), []);

  useEffect(() => {
    let active = true;
    getStaffSession().then((result) => {
      if (active) setSignedIn(result.ok);
    });
    return () => {
      active = false;
    };
  }, []);

  if (signedIn === null) return <LoadingMessage>Checking your sign-in…</LoadingMessage>;
  if (!signedIn) return <SignInForm onSignedIn={() => setSignedIn(true)} />;
  return <BookingsView onSignedOut={markSignedOut} />;
}

function SignInForm({ onSignedIn }: { onSignedIn: () => void }) {
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<PasswordInput>({ resolver: zodResolver(passwordSchema), defaultValues: { password: "" } });

  async function onSubmit({ password }: PasswordInput) {
    setFormError(null);
    const result = await signIn(password);
    if (result.ok) {
      onSignedIn();
      return;
    }
    setFormError(SIGN_IN_ERRORS[result.status] ?? result.error ?? "Sign-in failed. Please try again.");
  }

  return (
    <section className="mx-auto grid max-w-sm gap-6">
      <h1 className="font-serif text-3xl text-wine-dark">Staff sign-in</h1>
      {formError ? <ErrorMessage>{formError}</ErrorMessage> : null}
      <form noValidate onSubmit={handleSubmit(onSubmit)} className="grid gap-5 rounded-lg bg-white p-6 shadow-sm ring-1 ring-parchment">
        <Field id="password" label="Password" error={errors.password?.message}>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className={inputClass}
            aria-invalid={errors.password ? true : undefined}
            aria-describedby={errors.password ? "password-error" : undefined}
            {...register("password")}
          />
        </Field>
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex min-h-11 items-center justify-center rounded-md bg-wine px-5 py-2 font-medium text-white hover:bg-wine-dark disabled:opacity-60"
        >
          Sign in
        </button>
      </form>
    </section>
  );
}

function BookingsView({ onSignedOut }: { onSignedOut: () => void }) {
  const [result, setResult] = useState<ApiResult<StaffGroup[]> | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const loadBookings = useCallback(async () => {
    const next = await listStaffBookings();
    if (!next.ok && next.status === 401) {
      onSignedOut();
      return;
    }
    setResult(next);
  }, [onSignedOut]);

  useEffect(() => {
    loadBookings();
  }, [loadBookings]);

  async function cancel(reference: string) {
    setActionError(null);
    const response = await cancelBooking(reference);
    if (!response.ok) setActionError(response.error ?? "The booking could not be cancelled. Please try again.");
    await loadBookings();
  }

  async function endSession() {
    setActionError(null);
    const response = await signOut();
    if (!response.ok) {
      setActionError("Could not sign out. Please try again.");
      return;
    }
    onSignedOut();
  }

  if (!result) return <LoadingMessage>Loading bookings…</LoadingMessage>;
  if (!result.ok) return <ErrorMessage>The bookings could not be loaded. Please reload the page.</ErrorMessage>;

  return (
    <section className="grid gap-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-serif text-3xl text-wine-dark">Bookings</h1>
        <button
          type="button"
          onClick={endSession}
          className="inline-flex min-h-11 items-center rounded-md border border-wine px-4 font-medium text-wine hover:bg-parchment"
        >
          Sign out
        </button>
      </div>
      {actionError ? <ErrorMessage>{actionError}</ErrorMessage> : null}
      {result.data.map((group) => (
        <article key={group.tasting.id} className="rounded-lg bg-white shadow-sm ring-1 ring-parchment">
          <header className="flex flex-wrap items-baseline justify-between gap-2 border-b border-parchment px-6 py-4">
            <h2 className="font-serif text-2xl text-wine-dark">{group.tasting.title}</h2>
            <p className="text-sm text-muted">
              {formatStart(group.tasting.startsAt)} · {group.seatsBooked} of {group.tasting.seats} seats booked
            </p>
          </header>
          {group.bookings.length === 0 ? (
            <p className="px-6 py-5 text-muted">No bookings yet</p>
          ) : (
            <ul className="divide-y divide-parchment">
              {group.bookings.map((booking) => (
                <li key={booking.reference} className="flex flex-wrap items-center justify-between gap-3 px-6 py-4">
                  <div className="grid gap-0.5">
                    <span className="font-medium">{booking.name}</span>
                    <span className="text-sm text-muted">{booking.email}</span>
                    <span className="text-sm text-muted">
                      {booking.guests} {booking.guests === 1 ? "guest" : "guests"} · Reference{" "}
                      <span className="font-mono text-ink">{booking.reference}</span>
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => cancel(booking.reference)}
                    className="inline-flex min-h-11 items-center rounded-md border border-alert px-4 font-medium text-alert hover:bg-red-50"
                  >
                    Cancel
                  </button>
                </li>
              ))}
            </ul>
          )}
        </article>
      ))}
    </section>
  );
}
