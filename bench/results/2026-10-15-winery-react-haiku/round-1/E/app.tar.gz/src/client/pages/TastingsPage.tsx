import { useEffect, useState } from "react";
import { Link } from "react-router";
import { type ApiResult, listTastings, type Tasting } from "../api";
import { ErrorMessage, LoadingMessage } from "../components/Status";
import { formatEur, formatStart, seatsLeftLabel } from "../format";

export function TastingsPage() {
  const [result, setResult] = useState<ApiResult<Tasting[]> | null>(null);

  useEffect(() => {
    let active = true;
    listTastings().then((next) => {
      if (active) setResult(next);
    });
    return () => {
      active = false;
    };
  }, []);

  if (!result) return <LoadingMessage>Loading tastings…</LoadingMessage>;
  if (!result.ok) return <ErrorMessage>The tastings could not be loaded. Please reload the page.</ErrorMessage>;

  return (
    <section aria-labelledby="tastings-heading">
      <h1 id="tastings-heading" className="font-serif text-3xl text-wine-dark sm:text-4xl">
        Wine tastings
      </h1>
      <p className="mt-2 max-w-2xl text-muted">Choose a tasting and book your seats online.</p>
      <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {result.data.map((tasting) => (
          <TastingCard key={tasting.id} tasting={tasting} />
        ))}
      </ul>
    </section>
  );
}

function TastingCard({ tasting }: { tasting: Tasting }) {
  const fullyBooked = tasting.seatsLeft === 0;
  return (
    <li className="flex flex-col gap-4 rounded-lg bg-white p-6 shadow-sm ring-1 ring-parchment">
      <div className="flex items-start justify-between gap-3">
        <h2 className="font-serif text-2xl text-wine-dark">{tasting.title}</h2>
        {fullyBooked ? (
          <span className="shrink-0 rounded-full bg-alert px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white">
            Fully booked
          </span>
        ) : null}
      </div>
      <dl className="grid gap-1 text-ink">
        <div>
          <dt className="sr-only">Date and time</dt>
          <dd>{formatStart(tasting.startsAt)}</dd>
        </div>
        <div>
          <dt className="sr-only">Price per guest</dt>
          <dd>{formatEur(tasting.pricePerGuest)} per guest</dd>
        </div>
        <div>
          <dt className="sr-only">Seats</dt>
          <dd className={fullyBooked ? "font-medium text-alert" : "text-vine font-medium"}>
            {seatsLeftLabel(tasting.seatsLeft)}
          </dd>
        </div>
      </dl>
      {fullyBooked ? null : (
        <Link
          to={`/book/${tasting.id}`}
          className="mt-auto inline-flex min-h-11 items-center justify-center rounded-md bg-wine px-5 py-2 font-medium text-white hover:bg-wine-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-wine"
        >
          Book {tasting.title}
        </Link>
      )}
    </li>
  );
}
