import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "./app.js";
import { createBookingStore } from "./bookings.js";

function setup(bookings = createBookingStore(path.join(fs.mkdtempSync(path.join(os.tmpdir(), "api-")), "bookings.json"))) {
  return { app: createApp({ bookings, staffPassword: "guest-tests-unused" }), bookings };
}

const riesling = { name: "Ada Weiss", email: "ada@example.de", guests: 3 };

describe("GET /api/tastings", () => {
  it("lists each tasting with its full seat count when nothing is booked", async () => {
    const { app } = setup();
    const response = await request(app).get("/api/tastings");
    expect(response.status).toBe(200);
    expect(response.body.map((item: { id: string; seatsLeft: number }) => [item.id, item.seatsLeft])).toEqual([
      ["riesling-evening", 12],
      ["red-wine-cellar-tour", 8],
      ["winter-tasting", 10],
    ]);
  });
});

describe("POST /api/tastings/:id/bookings", () => {
  it("returns 201 with a reference and the total, and lowers the seats left", async () => {
    const { app } = setup();
    const created = await request(app).post("/api/tastings/riesling-evening/bookings").send(riesling);
    expect(created.status).toBe(201);
    expect(created.body).toMatchObject({ tasting: { id: "riesling-evening" }, guests: 3, total: 75 });
    expect(created.body.reference).toMatch(/^[A-HJ-NP-Z2-9]{8}$/);
    const list = await request(app).get("/api/tastings");
    expect(list.body[0].seatsLeft).toBe(9);
  });

  it("rejects guest counts 0, 9, 2.5 and \"3\" with an error on guests", async () => {
    const { app, bookings } = setup();
    for (const guests of [0, 9, 2.5, "3"]) {
      const response = await request(app).post("/api/tastings/riesling-evening/bookings").send({ ...riesling, guests });
      expect(response.status, String(guests)).toBe(400);
      expect(response.body.errors.guests).toBeTruthy();
    }
    expect(bookings.listBookings()).toEqual([]);
  });

  it("rejects an invalid email, an empty name and a whitespace-only name with an error on that field", async () => {
    const { app } = setup();
    const badEmail = await request(app).post("/api/tastings/riesling-evening/bookings").send({ ...riesling, email: "guest@example" });
    expect(badEmail.status).toBe(400);
    expect(badEmail.body.errors.email).toBe("Enter a valid email address");
    for (const name of ["", "   "]) {
      const response = await request(app).post("/api/tastings/riesling-evening/bookings").send({ ...riesling, name });
      expect(response.status).toBe(400);
      expect(response.body.errors.name).toBe("Enter your name");
    }
  });

  it("returns 404 for an unknown tasting id", async () => {
    const { app } = setup();
    const response = await request(app).post("/api/tastings/unknown/bookings").send(riesling);
    expect(response.status).toBe(404);
  });

  it("returns 409 with an error on guests when more guests than seats are requested, and stores nothing", async () => {
    const { app, bookings } = setup();
    const response = await request(app)
      .post("/api/tastings/red-wine-cellar-tour/bookings")
      .send({ ...riesling, guests: 8 });
    expect(response.status).toBe(201);
    const tooMany = await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...riesling, guests: 1 });
    expect(tooMany.status).toBe(409);
    expect(tooMany.body.errors.guests).toBe("This tasting is fully booked");
    expect(bookings.listBookings()).toHaveLength(1);
  });

  it("names the seats left in the 409 error when some seats remain", async () => {
    const { app } = setup();
    await request(app).post("/api/tastings/winter-tasting/bookings").send({ ...riesling, guests: 8 });
    const response = await request(app).post("/api/tastings/winter-tasting/bookings").send({ ...riesling, guests: 3 });
    expect(response.status).toBe(409);
    expect(response.body.errors.guests).toBe("Only 2 seats left");
  });
});

describe("request handling", () => {
  it("returns 400 for malformed JSON", async () => {
    const { app } = setup();
    const response = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "application/json")
      .send('{"name":');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe("Malformed JSON");
  });

  it("returns 413 for a body over 10 kB", async () => {
    const { app } = setup();
    const response = await request(app).post("/api/tastings/riesling-evening/bookings").send({ ...riesling, name: "a".repeat(20000) });
    expect(response.status).toBe(413);
  });

  it("returns a generic 500 without stack details when the store fails", async () => {
    const bookings = createBookingStore(null);
    const failing = { ...bookings, createBooking: () => { throw new Error("disk full at /secret/path"); } };
    const response = await request(createApp({ bookings: failing, staffPassword: undefined })).post("/api/tastings/riesling-evening/bookings").send(riesling);
    expect(response.status).toBe(500);
    expect(response.body).toEqual({ error: "Something went wrong. Please try again." });
    expect(response.text).not.toContain("/secret/path");
  });

  it("returns JSON 404 for unknown API paths", async () => {
    const { app } = setup();
    const response = await request(app).get("/api/nope");
    expect(response.status).toBe(404);
    expect(response.body).toEqual({ error: "Not found" });
  });
});

describe("GET /api/bookings/:ref", () => {
  it("returns the confirmation without name or email", async () => {
    const { app, bookings } = setup();
    const created = bookings.createBooking({ tastingId: "winter-tasting", name: "Ada Weiss", email: "ada@example.de", guests: 2 });
    const response = await request(app).get(`/api/bookings/${created.reference}`);
    expect(response.status).toBe(200);
    expect(response.body).toEqual({
      reference: created.reference,
      tasting: expect.objectContaining({ id: "winter-tasting", title: "Winter Tasting" }),
      guests: 2,
      total: 56,
    });
    expect(response.text).not.toContain("Ada Weiss");
    expect(response.text).not.toContain("ada@example.de");
  });

  it("returns 404 for an unknown reference", async () => {
    const { app } = setup();
    const response = await request(app).get("/api/bookings/ZZZZZZZZ");
    expect(response.status).toBe(404);
  });
});
