import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import request from "supertest";
import { afterEach, describe, expect, it, vi } from "vitest";
import { createApp } from "./app.js";
import { createBookingStore } from "./bookings.js";

const PASSWORD = "s3cret-winery-pass";

function setup(staffPassword: string | undefined = PASSWORD): { app: ReturnType<typeof createApp>; bookings: ReturnType<typeof createBookingStore> } {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "staff-")), "bookings.json");
  const bookings = createBookingStore(file);
  return { app: createApp({ bookings, staffPassword }), bookings };
}

function sessionCookie(response: request.Response): string | undefined {
  const cookies = response.headers["set-cookie"] as unknown as string[] | undefined;
  return cookies?.find((cookie) => cookie.startsWith("connect.sid="))?.split(";")[0];
}

async function signIn(app: ReturnType<typeof createApp>, password = PASSWORD) {
  return request(app).post("/api/staff/session").send({ password });
}

describe("staff sign-in", () => {
  it("returns 200 and a session cookie with HttpOnly and SameSite=Lax, without Secure over HTTP", async () => {
    const { app } = setup();
    const response = await signIn(app);
    expect(response.status).toBe(200);
    const header = (response.headers["set-cookie"] as unknown as string[]).find((cookie) => cookie.startsWith("connect.sid="));
    expect(header).toBeDefined();
    expect(header).toMatch(/HttpOnly/);
    expect(header).toMatch(/SameSite=Lax/i);
    expect(header).not.toMatch(/Secure/);
  });

  it("adds Secure when the request is served over HTTPS behind one trusted proxy", async () => {
    const app = createApp({ bookings: createBookingStore(null), staffPassword: PASSWORD, trustProxyHops: 1 });
    const response = await request(app)
      .post("/api/staff/session")
      .set("X-Forwarded-Proto", "https")
      .send({ password: PASSWORD });
    const header = (response.headers["set-cookie"] as unknown as string[]).find((cookie) => cookie.startsWith("connect.sid="));
    expect(header).toMatch(/Secure/);
  });

  it("expires the session cookie 2 hours after the last request", async () => {
    const { app } = setup();
    const before = Date.now();
    const response = await signIn(app);
    const header = (response.headers["set-cookie"] as unknown as string[]).find((cookie) => cookie.startsWith("connect.sid="));
    const expires = Date.parse(/Expires=([^;]+)/.exec(header ?? "")?.[1] ?? "");
    expect(expires - before).toBeGreaterThan(2 * 60 * 60 * 1000 - 5000);
    expect(expires - before).toBeLessThanOrEqual(2 * 60 * 60 * 1000 + 5000);
  });

  it("returns 401 for a wrong password and creates no session", async () => {
    const { app } = setup();
    const response = await signIn(app, "wrong");
    expect(response.status).toBe(401);
    expect(response.body.error).toBe("Wrong password");
    expect(sessionCookie(response)).toBeUndefined();
  });

  it("refuses every sign-in with 503 when STAFF_PASSWORD is not configured", async () => {
    const app = createApp({ bookings: createBookingStore(null), staffPassword: undefined });
    const response = await signIn(app, PASSWORD);
    expect(response.status).toBe(503);
    expect(response.body.error).toBe("Staff sign-in is not configured");
  });

  it("returns 401 without a session for the staff bookings list", async () => {
    const { app } = setup();
    const response = await request(app).get("/api/staff/bookings");
    expect(response.status).toBe(401);
    expect(response.body).not.toHaveProperty("tastings");
  });

  it("gives a new session identifier when a visitor with an existing session signs in again", async () => {
    const { app } = setup();
    const first = sessionCookie(await signIn(app));
    const second = await request(app).post("/api/staff/session").set("Cookie", first ?? "").send({ password: PASSWORD });
    expect(sessionCookie(second)).toBeDefined();
    expect(sessionCookie(second)).not.toBe(first);
  });

  it("returns 429 on the sixth failed attempt within 15 minutes", async () => {
    const { app } = setup();
    for (let attempt = 1; attempt <= 5; attempt += 1) {
      expect((await signIn(app, "wrong")).status).toBe(401);
    }
    const sixth = await signIn(app, "wrong");
    expect(sixth.status).toBe(429);
    expect(sixth.body.error).toBe("Too many attempts. Try again later.");
  });

  it("does not count successful sign-ins toward the failed-attempt limit", async () => {
    const { app } = setup();
    for (let attempt = 1; attempt <= 10; attempt += 1) {
      expect((await signIn(app)).status).toBe(200);
    }
    for (let attempt = 1; attempt <= 4; attempt += 1) {
      expect((await signIn(app, "wrong")).status).toBe(401);
    }
  });
});

describe("staff session end", () => {
  it("rejects the old cookie after sign-out", async () => {
    const { app } = setup();
    const cookie = sessionCookie(await signIn(app)) ?? "";
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(200);
    const signOut = await request(app).delete("/api/staff/session").set("Cookie", cookie);
    expect(signOut.status).toBe(204);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(401);
  });
});

describe("staff session lifetime", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  function startClock(): number {
    vi.useFakeTimers({ toFake: ["Date"] });
    return Date.now();
  }

  it("ends the session after 2 hours without staff activity", async () => {
    const { app } = setup();
    const start = startClock();
    const cookie = sessionCookie(await signIn(app)) ?? "";
    vi.setSystemTime(start + 2 * 60 * 60 * 1000 + 60 * 1000);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(401);
  });

  it("keeps the session alive while staff make a request at least every 2 hours", async () => {
    const { app } = setup();
    const start = startClock();
    const cookie = sessionCookie(await signIn(app)) ?? "";
    vi.setSystemTime(start + 90 * 60 * 1000);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(200);
    vi.setSystemTime(start + 3 * 60 * 60 * 1000);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(200);
  });

  it("ends any session 12 hours after sign-in, even when it stays active", async () => {
    const { app } = setup();
    const start = startClock();
    const cookie = sessionCookie(await signIn(app)) ?? "";
    for (let hour = 1; hour <= 11; hour += 1) {
      vi.setSystemTime(start + hour * 60 * 60 * 1000);
      expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(200);
    }
    vi.setSystemTime(start + 12 * 60 * 60 * 1000 + 60 * 1000);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(401);
  });

  it("marks staff responses as not cacheable", async () => {
    const { app } = setup();
    const cookie = sessionCookie(await signIn(app)) ?? "";
    const response = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(response.headers["cache-control"]).toBe("no-store");
  });
});

describe("staff bookings", () => {
  it("lists bookings grouped by tasting, with empty tastings included", async () => {
    const { app, bookings } = setup();
    const created = bookings.createBooking({ tastingId: "riesling-evening", name: "Ada Weiss", email: "ada@example.de", guests: 3 });
    const cookie = sessionCookie(await signIn(app)) ?? "";
    const response = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(response.status).toBe(200);
    expect(response.body).toEqual([
      {
        tasting: { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00", seats: 12 },
        seatsBooked: 3,
        bookings: [{ reference: created.reference, name: "Ada Weiss", email: "ada@example.de", guests: 3 }],
      },
      { tasting: expect.objectContaining({ id: "red-wine-cellar-tour" }), seatsBooked: 0, bookings: [] },
      { tasting: expect.objectContaining({ id: "winter-tasting" }), seatsBooked: 0, bookings: [] },
    ]);
  });

  it("cancels a booking, frees its seats and returns 404 for an unknown reference", async () => {
    const { app, bookings } = setup();
    const created = bookings.createBooking({ tastingId: "winter-tasting", name: "Ada Weiss", email: "ada@example.de", guests: 4 });
    const cookie = sessionCookie(await signIn(app)) ?? "";
    const cancelled = await request(app).delete(`/api/staff/bookings/${created.reference}`).set("Cookie", cookie);
    expect(cancelled.status).toBe(204);
    const tastings = await request(app).get("/api/tastings");
    expect(tastings.body.find((tasting: { id: string }) => tasting.id === "winter-tasting").seatsLeft).toBe(10);
    const unknown = await request(app).delete("/api/staff/bookings/ZZZZZZZZ").set("Cookie", cookie);
    expect(unknown.status).toBe(404);
  });

  it("returns 401 for cancel without a session and keeps the booking", async () => {
    const { app, bookings } = setup();
    const created = bookings.createBooking({ tastingId: "winter-tasting", name: "Ada Weiss", email: "ada@example.de", guests: 1 });
    const response = await request(app).delete(`/api/staff/bookings/${created.reference}`);
    expect(response.status).toBe(401);
    expect(bookings.findBooking(created.reference)).toBeDefined();
  });
});
