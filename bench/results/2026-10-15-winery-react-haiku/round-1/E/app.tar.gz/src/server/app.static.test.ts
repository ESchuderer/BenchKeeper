import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "./app.js";
import { createBookingStore } from "./bookings.js";

function clientBuild(): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "client-"));
  fs.writeFileSync(path.join(dir, "index.html"), "<!doctype html><div id=\"root\"></div>");
  fs.mkdirSync(path.join(dir, "assets"));
  fs.writeFileSync(path.join(dir, "assets", "app.js"), "console.log(1);");
  return dir;
}

describe("client files", () => {
  it("serves index.html at the root and for any page path, so react-router can handle it", async () => {
    const app = createApp({ bookings: createBookingStore(null), staffPassword: "x", clientDir: clientBuild() });
    expect((await request(app).get("/")).text).toContain('id="root"');
    expect((await request(app).get("/book/riesling-evening")).text).toContain('id="root"');
    expect((await request(app).get("/staff")).text).toContain('id="root"');
  });

  it("serves built assets from the client directory", async () => {
    const app = createApp({ bookings: createBookingStore(null), staffPassword: "x", clientDir: clientBuild() });
    const response = await request(app).get("/assets/app.js");
    expect(response.status).toBe(200);
    expect(response.text).toContain("console.log");
  });

  it("keeps unknown API paths as JSON 404 instead of returning the page", async () => {
    const app = createApp({ bookings: createBookingStore(null), staffPassword: "x", clientDir: clientBuild() });
    const response = await request(app).get("/api/unknown");
    expect(response.status).toBe(404);
    expect(response.body).toEqual({ error: "Not found" });
  });
});
