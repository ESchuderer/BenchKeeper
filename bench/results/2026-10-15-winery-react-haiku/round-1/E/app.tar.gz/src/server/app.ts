import path from "node:path";
import express, { type ErrorRequestHandler } from "express";
import helmet from "helmet";
import { bookingInputSchema, type FieldErrors } from "../shared/booking.js";
import { findTasting, tastings } from "../shared/tastings.js";
import { type Booking, type BookingStore, SeatLimitError } from "./bookings.js";
import { createStaffRouter } from "./staff.js";

export type AppOptions = {
  bookings: BookingStore;
  staffPassword: string | undefined;
  // Built client directory; when omitted, only the API is served.
  clientDir?: string;
  // Number of proxy hops in front of the app; sets req.secure and req.ip. Zero trusts no proxy.
  trustProxyHops?: number;
};

const JSON_BODY_ERRORS: Record<string, { status: number; message: string }> = {
  "entity.parse.failed": { status: 400, message: "Malformed JSON" },
  "entity.too.large": { status: 413, message: "Request body is too large" },
};

const GENERIC_ERROR = "Something went wrong. Please try again.";

function seatsLeftMessage(seatsLeft: number): string {
  if (seatsLeft === 0) return "This tasting is fully booked";
  return `Only ${seatsLeft} ${seatsLeft === 1 ? "seat" : "seats"} left`;
}

function confirmationOf(booking: Booking) {
  const tasting = findTasting(booking.tastingId);
  if (!tasting) throw new Error(`Booking ${booking.reference} refers to unknown tasting ${booking.tastingId}`);
  return {
    reference: booking.reference,
    tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt },
    guests: booking.guests,
    total: tasting.pricePerGuest * booking.guests,
  };
}

function isJsonObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function createApp({ bookings, staffPassword, clientDir, trustProxyHops = 0 }: AppOptions) {
  const app = express();
  if (trustProxyHops > 0) app.set("trust proxy", trustProxyHops);
  app.use(helmet());
  app.use(express.json({ limit: "10kb" }));

  app.get("/api/tastings", (_request, response) => {
    response.json(
      tastings.map((tasting) => ({ ...tasting, seatsLeft: bookings.seatsLeft(tasting.id) })),
    );
  });

  app.post("/api/tastings/:id/bookings", (request, response) => {
    const tasting = findTasting(request.params.id);
    if (!tasting) {
      response.status(404).json({ error: "Tasting not found" });
      return;
    }
    const parsed = bookingInputSchema.safeParse(isJsonObject(request.body) ? request.body : {});
    if (!parsed.success) {
      const errors: FieldErrors = {};
      for (const issue of parsed.error.issues) {
        const field = issue.path[0] as keyof FieldErrors;
        errors[field] ??= issue.message;
      }
      response.status(400).json({ errors });
      return;
    }
    try {
      const booking = bookings.createBooking({ tastingId: tasting.id, ...parsed.data });
      response.status(201).json(confirmationOf(booking));
    } catch (error) {
      if (!(error instanceof SeatLimitError)) throw error;
      response.status(409).json({ errors: { guests: seatsLeftMessage(error.seatsLeft) } });
    }
  });

  app.get("/api/bookings/:ref", (request, response) => {
    const booking = bookings.findBooking(request.params.ref);
    if (!booking) {
      response.status(404).json({ error: "Booking not found" });
      return;
    }
    response.json(confirmationOf(booking));
  });

  app.use("/api/staff", createStaffRouter({ bookings, staffPassword }));

  app.use("/api", (_request, response) => {
    response.status(404).json({ error: "Not found" });
  });

  if (clientDir) {
    app.use(express.static(clientDir));
    app.get("/{*splat}", (_request, response) => {
      response.sendFile(path.join(clientDir, "index.html"));
    });
  }

  const handleError: ErrorRequestHandler = (error, _request, response, next) => {
    if (response.headersSent) {
      next(error);
      return;
    }
    const known = JSON_BODY_ERRORS[(error as { type?: string }).type ?? ""];
    if (known) {
      response.status(known.status).json({ error: known.message });
      return;
    }
    const status = (error as { status?: number }).status;
    if (status !== undefined && status >= 400 && status < 500) {
      response.status(status).json({ error: "Bad request" });
      return;
    }
    console.error(error);
    response.status(500).json({ error: GENERIC_ERROR });
  };
  app.use(handleError);

  return app;
}
