import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { createBookingStore, SeatLimitError } from "./bookings.js";

const REFERENCE_PATTERN = /^[A-HJ-NP-Z2-9]{8}$/;

function booking(guests: number, tastingId = "riesling-evening") {
  return { tastingId, name: "Ada Weiss", email: "ada@example.de", guests };
}

describe("booking store", () => {
  it("stores a booking with a reference from the spec alphabet", () => {
    const store = createBookingStore(null);
    const created = store.createBooking(booking(3));
    expect(created.reference).toMatch(REFERENCE_PATTERN);
    expect(store.findBooking(created.reference)?.guests).toBe(3);
  });

  it("reduces the seats left by the guest count", () => {
    const store = createBookingStore(null);
    store.createBooking(booking(3));
    expect(store.seatsLeft("riesling-evening")).toBe(9);
  });

  it("rejects a booking above the seats left and stores nothing", () => {
    const store = createBookingStore(null);
    store.createBooking(booking(10));
    expect(() => store.createBooking(booking(3))).toThrow(SeatLimitError);
    expect(store.listBookings()).toHaveLength(1);
    expect(store.seatsLeft("riesling-evening")).toBe(2);
  });

  it("reports the seats left in the error", () => {
    const store = createBookingStore(null);
    store.createBooking(booking(10));
    try {
      store.createBooking(booking(3));
      expect.unreachable();
    } catch (error) {
      expect(error).toBeInstanceOf(SeatLimitError);
      expect((error as SeatLimitError).seatsLeft).toBe(2);
    }
  });
});

describe("booking store persistence", () => {
  function tempFile(name: string): string {
    return path.join(fs.mkdtempSync(path.join(os.tmpdir(), "bookings-")), name);
  }

  it("starts empty when the file does not exist", () => {
    const store = createBookingStore(tempFile("bookings.json"));
    expect(store.listBookings()).toEqual([]);
    expect(store.seatsLeft("riesling-evening")).toBe(12);
  });

  it("loads bookings and seats left from the file in a new store instance", () => {
    const file = tempFile("bookings.json");
    const first = createBookingStore(file);
    const created = first.createBooking(booking(5));
    const second = createBookingStore(file);
    expect(second.findBooking(created.reference)?.guests).toBe(5);
    expect(second.seatsLeft("riesling-evening")).toBe(7);
  });

  it("rolls back the insert and throws when the file cannot be written", () => {
    // A regular file as the parent directory makes every write fail.
    const blocker = tempFile("blocker");
    fs.writeFileSync(blocker, "");
    const store = createBookingStore(path.join(blocker, "bookings.json"));
    expect(() => store.createBooking(booking(2))).toThrow();
    expect(store.listBookings()).toEqual([]);
    expect(store.seatsLeft("riesling-evening")).toBe(12);
  });
});

describe("booking store concurrency and cancel", () => {
  it("never stores more guests than seats when 20 bookings arrive at once", async () => {
    const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "bookings-")), "bookings.json");
    const store = createBookingStore(file);
    store.createBooking(booking(4, "red-wine-cellar-tour"));
    const results = await Promise.allSettled(
      Array.from({ length: 20 }, () => Promise.resolve().then(() => store.createBooking(booking(1, "red-wine-cellar-tour")))),
    );
    const stored = results.filter((result) => result.status === "fulfilled").length;
    expect(stored).toBe(4);
    expect(store.listBookings().reduce((sum, item) => sum + item.guests, 0)).toBe(8);
    expect(createBookingStore(file).listBookings()).toHaveLength(5);
  });

  it("cancels a booking, frees its seats and reports unknown references", () => {
    const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "bookings-")), "bookings.json");
    const store = createBookingStore(file);
    const created = store.createBooking(booking(3));
    expect(store.cancelBooking(created.reference)).toBe(true);
    expect(store.findBooking(created.reference)).toBeUndefined();
    expect(store.seatsLeft("riesling-evening")).toBe(12);
    expect(store.cancelBooking(created.reference)).toBe(false);
    expect(createBookingStore(file).listBookings()).toEqual([]);
  });
});
