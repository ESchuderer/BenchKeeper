import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { findTasting } from "../shared/tastings.js";

export type Booking = {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
};

export type NewBooking = Omit<Booking, "reference">;

export class SeatLimitError extends Error {
  constructor(readonly seatsLeft: number) {
    super(`Only ${seatsLeft} seats left`);
  }
}

const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const REFERENCE_LENGTH = 8;

function newReference(): string {
  const bytes = crypto.randomBytes(REFERENCE_LENGTH);
  let reference = "";
  for (const byte of bytes) {
    reference += REFERENCE_ALPHABET[byte % REFERENCE_ALPHABET.length];
  }
  return reference;
}

function loadBookings(file: string): Booking[] {
  if (!fs.existsSync(file)) return [];
  const parsed: unknown = JSON.parse(fs.readFileSync(file, "utf8"));
  if (!Array.isArray(parsed)) throw new Error(`${file} does not contain a list of bookings`);
  return parsed as Booking[];
}

function saveBookings(file: string, bookings: readonly Booking[]): void {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  const temp = `${file}.${crypto.randomBytes(6).toString("hex")}.tmp`;
  try {
    const fd = fs.openSync(temp, "w", 0o600);
    try {
      fs.writeSync(fd, JSON.stringify(bookings, null, 2));
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(temp, file);
  } catch (error) {
    fs.rmSync(temp, { force: true });
    throw error;
  }
}

// file is null for an in-memory store (tests only).
export function createBookingStore(file: string | null) {
  const bookings: Booking[] = file ? loadBookings(file) : [];

  function persist(): void {
    if (file) saveBookings(file, bookings);
  }

  function seatsTaken(tastingId: string): number {
    return bookings
      .filter((booking) => booking.tastingId === tastingId)
      .reduce((sum, booking) => sum + booking.guests, 0);
  }

  function seatsLeft(tastingId: string): number {
    const tasting = findTasting(tastingId);
    if (!tasting) throw new Error(`Unknown tasting ${tastingId}`);
    return Math.max(0, tasting.seats - seatsTaken(tastingId));
  }

  function createBooking(input: NewBooking): Booking {
    const left = seatsLeft(input.tastingId);
    if (input.guests > left) throw new SeatLimitError(left);
    let reference = newReference();
    while (findBooking(reference)) reference = newReference();
    const booking = { ...input, reference };
    bookings.push(booking);
    try {
      persist();
    } catch (error) {
      bookings.pop();
      throw error;
    }
    return booking;
  }

  function cancelBooking(reference: string): boolean {
    const index = bookings.findIndex((booking) => booking.reference === reference);
    if (index === -1) return false;
    const [removed] = bookings.splice(index, 1);
    try {
      persist();
    } catch (error) {
      bookings.splice(index, 0, removed);
      throw error;
    }
    return true;
  }

  function findBooking(reference: string): Booking | undefined {
    return bookings.find((booking) => booking.reference === reference);
  }

  function listBookings(): Booking[] {
    return [...bookings];
  }

  return { createBooking, cancelBooking, findBooking, listBookings, seatsLeft };
}

export type BookingStore = ReturnType<typeof createBookingStore>;
