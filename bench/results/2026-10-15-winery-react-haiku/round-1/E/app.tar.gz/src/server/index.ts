import path from "node:path";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";
import { createBookingStore } from "./bookings.js";

const port = Number(process.env.PORT || 3000);
const bookingsFile = process.env.BOOKINGS_FILE || path.join("data", "bookings.json");
const staffPassword = process.env.STAFF_PASSWORD || undefined;

if (!staffPassword) {
  console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
}

const app = createApp({
  bookings: createBookingStore(bookingsFile),
  staffPassword,
  clientDir: fileURLToPath(new URL("../client", import.meta.url)),
  trustProxyHops: Number(process.env.TRUST_PROXY_HOPS || 0),
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings on http://localhost:${port}`);
});
