import crypto from "node:crypto";
import express from "express";
import { rateLimit } from "express-rate-limit";
import session from "express-session";
import { tastings } from "../shared/tastings.js";
import type { BookingStore } from "./bookings.js";

declare module "express-session" {
  interface SessionData {
    staff?: boolean;
    signedInAt?: number;
    lastSeenAt?: number;
  }
}

const SESSION_IDLE_MS = 2 * 60 * 60 * 1000;
const SESSION_MAX_MS = 12 * 60 * 60 * 1000;
const FAILED_ATTEMPT_WINDOW_MS = 15 * 60 * 1000;
const FAILED_ATTEMPT_LIMIT = 5;

export type StaffOptions = {
  bookings: BookingStore;
  staffPassword: string | undefined;
};

function digest(value: string): Buffer {
  return crypto.createHash("sha256").update(value).digest();
}

// Digests have equal length, so timingSafeEqual can compare them.
function passwordMatches(submitted: unknown, expected: string): boolean {
  if (typeof submitted !== "string") return false;
  return crypto.timingSafeEqual(digest(submitted), digest(expected));
}

function regenerateSession(request: express.Request): Promise<void> {
  return new Promise((resolve, reject) => {
    request.session.regenerate((error) => (error ? reject(error) : resolve()));
  });
}

function destroySession(request: express.Request): Promise<void> {
  return new Promise((resolve, reject) => {
    request.session.destroy((error) => (error ? reject(error) : resolve()));
  });
}

// Idle timeout and absolute lifetime are enforced here because express-session does not expire sessions server-side.
function isStaffSession(request: express.Request): boolean {
  const { staff, signedInAt, lastSeenAt } = request.session;
  const now = Date.now();
  if (!staff || signedInAt === undefined || lastSeenAt === undefined) return false;
  if (now - lastSeenAt > SESSION_IDLE_MS || now - signedInAt > SESSION_MAX_MS) return false;
  request.session.lastSeenAt = now;
  return true;
}

function requireStaff(request: express.Request, response: express.Response, next: express.NextFunction): void {
  if (!isStaffSession(request)) {
    response.status(401).json({ error: "Not signed in" });
    return;
  }
  next();
}

export function createStaffRouter({ bookings, staffPassword }: StaffOptions): express.Router {
  const router = express.Router();

  router.use((_request, response, next) => {
    response.set("Cache-Control", "no-store");
    next();
  });

  // shortcut: sessions live in express-session's MemoryStore, so they end on restart and only one process can serve them; upgrade to a shared store before running more than one process.
  router.use(
    session({
      secret: crypto.randomBytes(32).toString("hex"),
      resave: false,
      saveUninitialized: false,
      rolling: true,
      cookie: { httpOnly: true, sameSite: "lax", secure: "auto", maxAge: SESSION_IDLE_MS },
    }),
  );

  const signInLimiter = rateLimit({
    windowMs: FAILED_ATTEMPT_WINDOW_MS,
    limit: FAILED_ATTEMPT_LIMIT,
    skipSuccessfulRequests: true,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { error: "Too many attempts. Try again later." },
  });

  router.post("/session", signInLimiter, async (request, response) => {
    if (!staffPassword) {
      response.status(503).json({ error: "Staff sign-in is not configured" });
      return;
    }
    if (!passwordMatches(request.body?.password, staffPassword)) {
      response.status(401).json({ error: "Wrong password" });
      return;
    }
    await regenerateSession(request);
    request.session.staff = true;
    request.session.signedInAt = Date.now();
    request.session.lastSeenAt = request.session.signedInAt;
    response.json({ signedIn: true });
  });

  router.delete("/session", async (request, response) => {
    await destroySession(request);
    response.clearCookie("connect.sid");
    response.status(204).end();
  });

  router.get("/session", (request, response) => {
    if (!isStaffSession(request)) {
      response.status(401).json({ error: "Not signed in" });
      return;
    }
    response.json({ signedIn: true });
  });

  router.get("/bookings", requireStaff, (_request, response) => {
    response.json(
      tastings.map((tasting) => {
        const tastingBookings = bookings.listBookings().filter((booking) => booking.tastingId === tasting.id);
        return {
          tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt, seats: tasting.seats },
          seatsBooked: tastingBookings.reduce((sum, booking) => sum + booking.guests, 0),
          bookings: tastingBookings.map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
        };
      }),
    );
  });

  router.delete("/bookings/:ref", requireStaff, (request: express.Request<{ ref: string }>, response) => {
    if (!bookings.cancelBooking(request.params.ref)) {
      response.status(404).json({ error: "Booking not found" });
      return;
    }
    response.status(204).end();
  });

  return router;
}
