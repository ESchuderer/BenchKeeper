import { describe, expect, it } from "vitest";
import { bookingInputSchema } from "./booking.js";

const valid = { name: "Ada Weiss", email: "ada@example.de", guests: 2 };

function firstError(input: unknown, field: string): string | undefined {
  const result = bookingInputSchema.safeParse(input);
  if (result.success) return undefined;
  return result.error.issues.find((issue) => issue.path[0] === field)?.message;
}

describe("bookingInputSchema", () => {
  it("accepts a valid booking", () => {
    expect(bookingInputSchema.safeParse(valid).success).toBe(true);
  });

  it("rejects an empty name and a whitespace-only name", () => {
    expect(firstError({ ...valid, name: "" }, "name")).toBe("Enter your name");
    expect(firstError({ ...valid, name: "   " }, "name")).toBe("Enter your name");
  });

  it("rejects control and invisible format characters in the name", () => {
    expect(firstError({ ...valid, name: "Ada\nWeiss" }, "name")).toBe("Name contains characters that are not allowed");
    expect(firstError({ ...valid, name: "Ada\u202eWeiss" }, "name")).toBe("Name contains characters that are not allowed");
  });

  it("rejects a name longer than 100 characters", () => {
    expect(firstError({ ...valid, name: "a".repeat(101) }, "name")).toBe(
      "Name must be at most 100 characters",
    );
  });

  it("trims the name and the email before checking them", () => {
    const result = bookingInputSchema.parse({ ...valid, name: "  Ada  ", email: " ada@example.de " });
    expect(result.name).toBe("Ada");
    expect(result.email).toBe("ada@example.de");
  });

  it("rejects an invalid email", () => {
    expect(firstError({ ...valid, email: "guest@example" }, "email")).toBe("Enter a valid email address");
  });

  it("rejects an email longer than 254 characters", () => {
    const email = `${"a".repeat(250)}@b.de`;
    expect(firstError({ ...valid, email }, "email")).toBe("Email must be at most 254 characters");
  });

  it("accepts guest counts 1 to 8 and rejects 0, 9, 2.5 and NaN", () => {
    for (const guests of [1, 8]) {
      expect(bookingInputSchema.safeParse({ ...valid, guests }).success).toBe(true);
    }
    expect(firstError({ ...valid, guests: 0 }, "guests")).toBe("Enter at least 1 guest");
    expect(firstError({ ...valid, guests: 9 }, "guests")).toBe("You can book for at most 8 guests");
    expect(firstError({ ...valid, guests: 2.5 }, "guests")).toBe("Enter a whole number of guests");
    expect(firstError({ ...valid, guests: Number.NaN }, "guests")).toBe("Enter the number of guests");
  });

  it("rejects a guest count sent as a string", () => {
    expect(firstError({ ...valid, guests: "3" }, "guests")).toBe("Enter the number of guests");
  });
});
