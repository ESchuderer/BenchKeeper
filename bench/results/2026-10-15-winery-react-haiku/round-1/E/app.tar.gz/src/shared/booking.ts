import { z } from "zod";
import { MAX_GUESTS_PER_BOOKING } from "./tastings.js";

export const bookingInputSchema = z.object({
  name: z
    .string({ error: "Enter your name" })
    .trim()
    .min(1, "Enter your name")
    .max(100, "Name must be at most 100 characters")
    .refine((name) => !/[\p{Cc}\p{Cf}]/u.test(name), "Name contains characters that are not allowed"),
  email: z
    .string({ error: "Enter your email address" })
    .trim()
    .min(1, "Enter your email address")
    .max(254, "Email must be at most 254 characters")
    .pipe(z.email({ error: "Enter a valid email address" })),
  guests: z
    .number({ error: "Enter the number of guests" })
    .int("Enter a whole number of guests")
    .min(1, "Enter at least 1 guest")
    .max(MAX_GUESTS_PER_BOOKING, `You can book for at most ${MAX_GUESTS_PER_BOOKING} guests`),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;

export type FieldErrors = Partial<Record<keyof BookingInput, string>>;
