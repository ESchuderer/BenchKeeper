import { describe, expect, it } from "vitest";
import { findTasting, tastings } from "./tastings.js";

describe("tastings catalogue", () => {
  it("lists the three tastings from the brief", () => {
    expect(tastings.map(({ title, startsAt, pricePerGuest, seats }) => ({ title, startsAt, pricePerGuest, seats }))).toEqual([
      { title: "Riesling Evening", startsAt: "2026-11-06T18:00", pricePerGuest: 25, seats: 12 },
      { title: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00", pricePerGuest: 32, seats: 8 },
      { title: "Winter Tasting", startsAt: "2026-12-05T17:00", pricePerGuest: 28, seats: 10 },
    ]);
  });

  it("finds a tasting by id and returns undefined for an unknown id", () => {
    expect(findTasting("winter-tasting")?.title).toBe("Winter Tasting");
    expect(findTasting("unknown")).toBeUndefined();
  });
});
