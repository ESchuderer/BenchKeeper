# Weingut Kieselbrunnen · Tasting bookings

A small web app for the winery. Guests book wine tastings online. Staff sign in
with a shared password to see every booking and cancel where needed.

- Spec: [`SPEC.md`](SPEC.md)
- Plan and task list: [`tasks/plan.md`](tasks/plan.md), [`tasks/todo.md`](tasks/todo.md)

## Requirements

- Node.js 22

## Running it

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' PORT=3000 npm start
```

Then open http://localhost:3000. Guests use `/`. Staff use `/staff`.

| Variable         | Default | Purpose                                                                 |
|------------------|---------|-------------------------------------------------------------------------|
| `PORT`           | `3000`  | Port the server listens on.                                             |
| `STAFF_PASSWORD` | unset   | Shared password for `/staff`. When unset, staff sign-in is refused.     |
| `TRUST_PROXY`    | unset   | Number of reverse proxies in front of the app. Set it so rate limits see real client addresses. |

### Development

```sh
npm run dev   # API on :3000 (tsx watch) and Vite on :5173, with /api proxied
```

## Scripts

| Command                 | What it does                                            |
|-------------------------|---------------------------------------------------------|
| `npm run build`         | Builds the client (Vite) to `dist/client` and the server (tsc) to `dist/server` and `dist/shared`. |
| `npm start`             | Serves the built app. Needs `npm run build` first.      |
| `npm test`              | Unit, API and component tests (Vitest).                 |
| `npm run typecheck`     | TypeScript checks for client and server code.           |
| `npm run lint`          | ESLint.                                                 |
| `npm run test:e2e`      | Playwright end-to-end tests (desktop and phone). Builds, then starts the server on port 3200. |

For `test:e2e`, Playwright needs a Chromium. Run `npx playwright install chromium`
to fetch the bundled browser. If that browser cannot start (for example in a
container without its system libraries), set `KB_CHROMIUM` to the path of a
Chromium binary you already have.

## How it works

- **Tastings** are a fixed list in `src/shared/tastings.ts`. Dates are local
  times in Europe/Berlin.
- **Bookings** are kept in memory by `src/server/store.ts`. Seat checks and
  inserts run in one synchronous step, so two people cannot take the same seat.
- **Validation** uses zod schemas in `src/shared/schemas.ts`. The same schema
  checks the form in the browser and the request on the server. The server's
  answer is the one that counts.
- **Staff sessions** use a random token in an httpOnly, SameSite=Strict cookie,
  valid for 8 hours. Failed sign-ins are rate limited to 10 per 15 minutes per
  client address. Booking attempts are limited to 20 per 15 minutes per address.
- **Pages** are React with React Router, forms use react-hook-form, and styles
  use Tailwind CSS.

## Limitations

- **Bookings do not survive a restart.** They are held in memory, as the brief
  allows. Adding a file or database store would mean changing `store.ts` only.
- **Staff access is one shared password.** There are no separate staff accounts.
- **Cookies are not marked `Secure`,** so plain-HTTP access on a local network
  works. Put the app behind HTTPS in production. If a reverse proxy sits in
  front of the app, set `TRUST_PROXY` to the number of proxy hops so the rate
  limits see real client addresses.
- **Reference lookups are not rate limited.** A reference has 30 bits of
  entropy and the public response carries no name or email. Scanning is
  impractical, but add a limit if this becomes a concern.
- **No per-person booking limit and no email confirmations.** Neither was in the brief.
