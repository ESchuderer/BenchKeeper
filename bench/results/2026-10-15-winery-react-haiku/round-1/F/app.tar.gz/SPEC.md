# Spec: Weingut Kieselbrunnen Tasting Bookings

## Objective

A small web app for a family winery. Guests browse wine tastings, book seats online and see a booking confirmation. Staff sign in with a shared password, see every booking grouped by tasting and can cancel bookings, which frees the seats.

Success means a guest can book a tasting on a phone without help, the app never over-sells seats, and staff can see and cancel every booking.

### Users
- **Guests** — anonymous visitors on mobile or desktop. No accounts.
- **Staff** — winery employees with the shared staff password (`STAFF_PASSWORD`).

### Tastings (fixed catalogue, held in code)

| id | Title | Starts (Europe/Berlin) | Price per guest | Seats |
|---|---|---|---|---|
| `riesling-evening` | Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| `red-wine-cellar-tour` | Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| `winter-tasting` | Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

### Guest flows
1. **Start page `/`** — lists the tastings with title, date and time, price per guest and `<n> seats left`. Each has a "Book <title>" link. A tasting with no seats left shows "Fully booked" and no booking link.
2. **Booking form `/book/:tastingId`** — fields "Name", "Email", "Guests" (whole number 1–8), button "Book". Invalid input shows an error next to the field it concerns. Guests may not exceed the seats left.
3. **Confirmation `/bookings/:reference`** — heading "Booking confirmed", tasting title, number of guests, total price, booking reference. The page can be reloaded or revisited with the reference.

### Staff flows
4. **Sign in `/staff`** — "Password" field and "Sign in" button. Wrong password shows an error.
5. **Bookings view** — signed in, staff see all active bookings grouped by tasting: name, email, guests, reference, and a "Cancel" button per booking. Cancelling frees its seats. Staff can also sign out.

### Assumptions (made without human review)
- A1. Storage is in memory. Bookings reset when the server restarts, which matches "the app starts with no bookings".
- A2. Times are Europe/Berlin local time. All three dates fall in CET (+01:00).
- A3. A tasting whose start time has passed cannot be booked. It shows as "Tasting has passed". All current tastings are in the future.
- A4. Singular copy for one seat: "1 seat left". The spec template says "<n> seats left"; plural forms for n ≠ 1 follow it.
- A5. Prices are whole euros. Totals display as "EUR 75".
- A6. Staff authentication is one shared password, compared in constant time. A successful sign-in creates a random session token in an httpOnly, SameSite=Strict cookie, held in memory. Sign-in attempts are rate limited.
- A7. If `STAFF_PASSWORD` is unset, staff sign-in is refused and the server logs a warning at startup. The rest of the app still works.
- A8. Cancelling asks the staff member to confirm in the browser (`window.confirm`).
- A9. Cancelled bookings are kept with status `cancelled` (not counted for seats). Guests opening a cancelled reference see "This booking has been cancelled."
- A10. TLS is terminated outside the app. Cookies are not marked `Secure`, so plain-HTTP LAN access works. This is noted in the README.

## Tech Stack

- **Runtime:** Node.js 22
- **Server:** Express 5 (JSON API, static files, SPA fallback), helmet (security headers), cookie-parser, express-rate-limit
- **Client:** React 19, React Router 7, Vite 6 build, TypeScript
- **Forms and validation:** react-hook-form with @hookform/resolvers/zod. Zod schemas are shared between client and server.
- **Styling:** Tailwind CSS 4 via @tailwindcss/vite
- **Tests:** Vitest; supertest for API; React Testing Library with jsdom for components; Playwright for one end-to-end smoke test if a browser can be installed
- **Dev tooling:** tsx (dev server), concurrently (dev script)
- **Storage:** in-memory `Map`. No database, no external service.

## Commands

```
Install:    npm install
Build:      npm run build        # vite build (client) + tsc (server)
Start:      npm start            # node dist/server/index.js, PORT (default 3000)
Dev:        npm run dev          # vite on 5173 with /api proxied to the server on 3000
Test:       npm test             # vitest run (unit, component, API)
Typecheck:  npm run typecheck
Lint:       npm run lint         # eslint
E2E:        npm run test:e2e     # playwright, requires a chromium install
```

## Project Structure

```
SPEC.md                    → this spec
tasks/plan.md              → implementation plan
tasks/todo.md              → task list
src/shared/                → catalogue, zod schemas, formatting (used by client and server)
src/server/                → Express app, booking store, staff auth, entry point
src/client/                → React app: pages, components, API client, styles
tests/server/              → API and store tests (vitest + supertest)
tests/client/              → component and page tests (vitest + jsdom)
e2e/                       → Playwright smoke test
dist/                      → build output (not committed)
```

## Code Style

Plain TypeScript, ES modules, two-space indent, single quotes, semicolons. Names are descriptive. Functions are small and pure where possible. Errors are returned as `{ error: string, fields?: Record<string, string> }`.

```ts
// src/shared/schemas.ts
export const bookingInput = z.object({
  name: z.string().trim().min(1, 'Please enter your name').max(100),
  email: z.string().trim().email('Please enter a valid email address'),
  guests: z.coerce.number().int('Please enter a whole number').min(1, 'Choose 1 to 8 guests').max(8, 'Choose 1 to 8 guests'),
});
```

## Testing Strategy

- **Store and rules (unit):** seat accounting, overbooking refusal, cancellation frees seats, reference uniqueness, past-tasting refusal. Written first (TDD).
- **API (integration):** supertest against the Express app factory. Covers validation errors, seat limits, staff auth gate, rate limit, cancel.
- **Components (jsdom):** form labels, inline errors, fully booked and passed states, confirmation content, staff sign-in flow.
- **End-to-end (Playwright, if available):** guest books a tasting and sees confirmation; staff sees and cancels it.
- Coverage target: ≥ 85% lines on `src/server` and `src/shared`. The client is covered by component tests.

## Boundaries

- **Always:** validate on the server as well as in the browser; keep seat checks and inserts in one synchronous step; run tests before declaring work done; escape output (React does this by default).
- **Ask first:** adding a database, adding an auth provider, changing the tasting catalogue, sending email.
- **Never:** commit secrets or the `STAFF_PASSWORD` value; log passwords or session tokens; remove failing tests to get green; expose guest emails outside the staff area.

## Success Criteria

1. `npm install && npm run build && PORT=3000 npm start` serves the app.
2. `/` lists all three tastings with title, date and time, price per guest and `<n> seats left`.
3. Each tasting has a "Book <title>" link that opens a form with "Name", "Email", "Guests" and "Book".
4. Guests outside 1–8, empty name, and invalid email are rejected with a message next to that field. No booking is created.
5. A booking for more guests than seats left is rejected with a message next to "Guests" showing the seats left. Seats left never goes negative.
6. A valid booking shows "Booking confirmed" with the tasting, guest count, total price and reference.
7. A fully booked tasting shows "Fully booked" and no booking link. Directly opening its form shows a fully-booked message, not a form.
8. `/staff` refuses wrong passwords and accepts `STAFF_PASSWORD`. Signed in, the bookings are grouped by tasting with name, email, guests and reference.
9. Cancelling a booking removes it from the list and increases seats left by its guest count.
10. The layout is usable at 375px wide: no horizontal scrolling, touch targets ≥ 44px.
11. `npm test` and `npm run typecheck` pass.

## Open Questions

- Should bookings survive a server restart? (A1 says no. A file-backed store is a small follow-up if the winery wants that.)
- Is a shared staff password acceptable long-term, or will staff accounts be needed?
