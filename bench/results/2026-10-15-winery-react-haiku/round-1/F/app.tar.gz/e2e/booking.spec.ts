import { expect, test, type Locator, type Page } from '@playwright/test';

const STAFF_PASSWORD = 'e2e-cellar-password';
const SHOTS = process.env.SCREENSHOT_DIR;

test.describe.configure({ mode: 'serial' });

test('guest books a tasting and sees the confirmation', async ({ page }, testInfo) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Tastings at the cellar door' })).toBeVisible();
  await expect(page.getByRole('article', { name: 'Winter Tasting' }).getByText('10 seats left')).toBeVisible();
  if (SHOTS) await page.screenshot({ path: `${SHOTS}/${testInfo.project.name}-home.png`, fullPage: true });

  await page.getByRole('link', { name: 'Book Winter Tasting' }).click();
  await expect(page).toHaveURL(/\/book\/winter-tasting$/);

  await page.getByLabel('Name').fill('Ben Tester');
  await page.getByLabel('Email').fill('not-an-email');
  await page.getByLabel('Guests').fill('2');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Please enter a valid email address');
  if (SHOTS) await page.screenshot({ path: `${SHOTS}/${testInfo.project.name}-form-errors.png`, fullPage: true });

  await page.getByLabel('Email').fill('ben@example.com');
  await page.getByRole('button', { name: 'Book' }).click();

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(page.getByText('EUR 56')).toBeVisible();
  const reference = await page.locator('dd.font-mono').innerText();
  expect(reference).toMatch(/^KB-[A-Z2-9]{6}$/);
  if (SHOTS) await page.screenshot({ path: `${SHOTS}/${testInfo.project.name}-confirmation.png`, fullPage: true });
});

test('staff sign in, see the booking and cancel it', async ({ page }, testInfo) => {
  await page.goto('/staff');
  await page.getByLabel('Password').fill('wrong-password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByText('Incorrect password.')).toBeVisible();

  await page.getByLabel('Password').fill(STAFF_PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();

  const section = page.getByRole('region', { name: 'Winter Tasting' });
  await expect(section.getByText('Ben Tester')).toBeVisible();
  await expect(section.getByText('ben@example.com')).toBeVisible();
  if (SHOTS) await page.screenshot({ path: `${SHOTS}/${testInfo.project.name}-staff.png`, fullPage: true });

  page.once('dialog', (dialog) => dialog.accept());
  await section.getByRole('button', { name: 'Cancel' }).click();
  await expect(section.getByText('Ben Tester')).toHaveCount(0);
  await expect(section.getByText('10 seats left')).toBeVisible();

  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Winter Tasting' }).getByText('10 seats left')).toBeVisible();
});

async function expectNoSidewaysScroll(page: Page, path: string) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow, `horizontal overflow on ${path}`).toBeLessThanOrEqual(0);
}

async function expectTouchTarget(locator: Locator, name: string) {
  const box = await locator.boundingBox();
  expect(box, `${name} is on screen`).not.toBeNull();
  expect(box!.height, `${name} is at least 44px tall`).toBeGreaterThanOrEqual(44);
}

test('pages fit a phone screen and keep touch targets large', async ({ page, request }) => {
  // A long name and email make the hardest case for the staff list layout.
  const booked = await request.post('/api/tastings/riesling-evening/bookings', {
    data: { name: 'Maximilian Konstantinopoulos-Smith', email: 'a.very.long.address.for.layout.checks@winery-visitors.example.com', guests: 1 },
  });
  expect(booked.status()).toBe(201);

  for (const path of ['/', '/book/riesling-evening']) {
    await page.goto(path);
    await page.waitForLoadState('networkidle');
    await expectNoSidewaysScroll(page, path);
  }
  await page.goto('/');
  await expectTouchTarget(page.getByRole('link', { name: 'Staff' }), 'Staff link');

  await page.goto('/staff');
  await page.getByLabel('Password').fill(STAFF_PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  const section = page.getByRole('region', { name: 'Riesling Evening' });
  await expect(section.getByText('Maximilian Konstantinopoulos-Smith')).toBeVisible();

  await expectNoSidewaysScroll(page, '/staff (signed in)');
  await expectTouchTarget(page.getByRole('button', { name: 'Sign out' }), 'Sign out button');
  await expectTouchTarget(section.getByRole('button', { name: 'Cancel' }), 'Cancel button');

  // Remove the layout-check booking so later runs start from a clean list.
  page.once('dialog', (dialog) => dialog.accept());
  await section.getByRole('button', { name: 'Cancel' }).click();
  await expect(section.getByText('Maximilian Konstantinopoulos-Smith')).toHaveCount(0);
});
