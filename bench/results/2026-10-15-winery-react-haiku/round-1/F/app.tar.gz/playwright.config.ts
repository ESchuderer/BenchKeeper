import { defineConfig, devices } from '@playwright/test';

const PORT = 3200;

// Optional: use a Chromium binary you already have (for example in a container without Playwright's bundled browser deps).
const executablePath = process.env.KB_CHROMIUM || undefined;

export default defineConfig({
  testDir: 'e2e',
  fullyParallel: false,
  workers: 1,
  reporter: [['list']],
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: 'retain-on-failure',
    launchOptions: executablePath ? { executablePath } : {},
  },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'phone', use: { ...devices['Pixel 7'] } },
    { name: 'small-phone', use: { ...devices['Desktop Chrome'], viewport: { width: 375, height: 667 }, isMobile: true, hasTouch: true } },
  ],
  webServer: {
    command: 'npm run build && npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-cellar-password' },
    reuseExistingServer: false,
    timeout: 30_000,
  },
});
