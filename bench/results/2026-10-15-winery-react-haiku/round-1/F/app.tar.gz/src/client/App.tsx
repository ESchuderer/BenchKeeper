import { Route, Routes } from 'react-router';
import { Layout } from './components/Layout.js';
import { BookingPage } from './pages/BookingPage.js';
import { ConfirmationPage } from './pages/ConfirmationPage.js';
import { HomePage } from './pages/HomePage.js';
import { StaffPage } from './pages/StaffPage.js';

export function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/book/:tastingId" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
        <Route path="/staff" element={<StaffPage />} />
      </Routes>
    </Layout>
  );
}
