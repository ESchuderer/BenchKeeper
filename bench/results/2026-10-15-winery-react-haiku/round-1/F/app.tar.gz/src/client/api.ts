import type { BookingInput } from '../shared/schemas.js';

export interface TastingView {
  id: string;
  title: string;
  startsAt: string;
  priceEur: number;
  seats: number;
  seatsLeft: number;
  passed: boolean;
}

export interface BookingView {
  reference: string;
  status: 'confirmed' | 'cancelled';
  guests: number;
  totalEur: number;
  tasting: { id: string; title: string; startsAt: string; priceEur: number };
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface StaffGroup {
  tasting: { id: string; title: string; startsAt: string; priceEur: number; seats: number };
  seatsLeft: number;
  bookings: StaffBooking[];
}

export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
    readonly fields: Record<string, string> = {},
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

const GENERIC_ERROR = 'Something went wrong. Please try again.';

async function request<T>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (init.body !== undefined) headers['Content-Type'] = 'application/json';

  let res: Response;
  try {
    res = await fetch(path, {
      method: init.method ?? 'GET',
      headers,
      body: init.body === undefined ? undefined : JSON.stringify(init.body),
      credentials: 'same-origin',
    });
  } catch {
    throw new ApiError(0, "We couldn't reach the server. Check your connection and try again.");
  }

  const payload = await res.json().catch(() => null);
  if (!res.ok) {
    throw new ApiError(res.status, payload?.error ?? GENERIC_ERROR, payload?.fields ?? {});
  }
  return payload as T;
}

export const api = {
  listTastings: () => request<{ tastings: TastingView[] }>('/api/tastings'),

  createBooking: (tastingId: string, input: BookingInput) =>
    request<{ booking: BookingView }>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
      method: 'POST',
      body: input,
    }),

  getBooking: (reference: string) =>
    request<{ booking: BookingView }>(`/api/bookings/${encodeURIComponent(reference)}`),

  staffSignIn: (password: string) =>
    request<{ ok: true }>('/api/staff/login', { method: 'POST', body: { password } }),

  staffSignOut: () => request<{ ok: true }>('/api/staff/logout', { method: 'POST' }),

  staffBookings: () => request<{ groups: StaffGroup[] }>('/api/staff/bookings'),

  cancelBooking: (reference: string) =>
    request<{ booking: { reference: string; status: string } }>(
      `/api/staff/bookings/${encodeURIComponent(reference)}`,
      { method: 'DELETE' },
    ),
};
