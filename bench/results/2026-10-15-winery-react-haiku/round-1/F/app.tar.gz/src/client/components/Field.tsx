import type { ReactNode } from 'react';

export function errorIdFor(id: string) {
  return `${id}-error`;
}

/** ARIA wiring so screen readers announce the field's error with the field. */
export function fieldProps(id: string, error?: string) {
  return {
    id,
    'aria-invalid': error ? true : undefined,
    'aria-describedby': error ? errorIdFor(id) : undefined,
  } as const;
}

export function inputClass(invalid: boolean) {
  const border = invalid ? 'border-danger-700 focus-visible:ring-danger-200' : 'border-cream-300';
  return `min-h-11 w-full rounded-lg border bg-cream-50 px-3.5 py-2.5 text-base text-ink shadow-inner ${border}`;
}

export function Field({ id, label, error, children }: { id: string; label: string; error?: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-semibold text-ink">
        {label}
      </label>
      {children}
      {error && (
        <p id={errorIdFor(id)} className="text-sm font-medium text-danger-700">
          {error}
        </p>
      )}
    </div>
  );
}
