import type { ReactNode } from 'react';
import { Link } from 'react-router';

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-wine-800 text-cream-50">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-5 sm:px-6">
          <Link to="/" className="group flex flex-col no-underline">
            <span className="font-serif text-2xl tracking-wide group-hover:text-gold-300">Weingut Kieselbrunnen</span>
            <span className="text-sm text-cream-200/80">Family vineyard · Wine tastings</span>
          </Link>
          <Link to="/staff" className="inline-flex min-h-11 items-center rounded-md px-3 py-2 text-sm text-cream-200 no-underline hover:bg-wine-700 hover:text-cream-50">
            Staff
          </Link>
        </div>
        <div className="h-1 bg-gold-500" aria-hidden="true" />
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">{children}</main>

      <footer className="border-t border-cream-300 bg-cream-100">
        <div className="mx-auto max-w-5xl px-4 py-6 text-sm text-ink-muted sm:px-6">
          Weingut Kieselbrunnen · Tasting bookings
        </div>
      </footer>
    </div>
  );
}
