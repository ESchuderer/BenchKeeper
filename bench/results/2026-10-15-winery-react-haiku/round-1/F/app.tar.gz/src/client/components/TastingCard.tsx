import { useId } from 'react';
import { Link } from 'react-router';
import type { TastingView } from '../api.js';
import { formatPrice, formatStartsAt, seatsLeftLabel } from '../format.js';

export function TastingCard({ tasting }: { tasting: TastingView }) {
  const titleId = useId();
  const fullyBooked = !tasting.passed && tasting.seatsLeft === 0;
  const bookable = !tasting.passed && tasting.seatsLeft > 0;

  return (
    <article
      aria-labelledby={titleId}
      className="flex flex-col rounded-2xl border border-cream-300 bg-cream-50 p-6 shadow-sm"
    >
      <div className="flex items-start justify-between gap-3">
        <h2 id={titleId} className="font-serif text-2xl leading-tight text-wine-800">
          {tasting.title}
        </h2>
        {fullyBooked && (
          <span className="shrink-0 rounded-full bg-danger-50 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-danger-700">
            Fully booked
          </span>
        )}
      </div>

      <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
        <div>
          <dt className="text-ink-muted">When</dt>
          <dd className="font-medium text-ink">{formatStartsAt(tasting.startsAt)}</dd>
        </div>
        <div>
          <dt className="text-ink-muted">Price per guest</dt>
          <dd className="font-medium text-ink">{formatPrice(tasting.priceEur)}</dd>
        </div>
        <div>
          <dt className="text-ink-muted">Availability</dt>
          <dd className={fullyBooked ? 'font-medium text-danger-700' : 'font-medium text-success-700'}>
            {seatsLeftLabel(tasting.seatsLeft)}
          </dd>
        </div>
      </dl>

      <div className="mt-6 flex flex-1 items-end">
        {bookable && (
          <Link
            to={`/book/${tasting.id}`}
            className="inline-flex min-h-11 w-full items-center justify-center rounded-lg bg-wine-700 px-5 py-2.5 text-center font-semibold text-cream-50 no-underline shadow-sm transition hover:bg-wine-800 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-300 sm:w-auto"
          >
            Book {tasting.title}
          </Link>
        )}
        {fullyBooked && (
          <p className="text-sm italic text-ink-muted">This tasting has no seats left.</p>
        )}
        {tasting.passed && <p className="text-sm italic text-ink-muted">This tasting has taken place.</p>}
      </div>
    </article>
  );
}
