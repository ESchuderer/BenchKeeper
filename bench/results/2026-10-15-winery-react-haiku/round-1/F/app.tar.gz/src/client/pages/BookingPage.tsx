import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useNavigate, useParams } from 'react-router';
import type { z } from 'zod';
import { api, ApiError, type TastingView } from '../api.js';
import { Field, fieldProps, inputClass } from '../components/Field.js';
import { formatPrice, formatStartsAt, seatsLeftLabel } from '../format.js';
import { bookingInput, type BookingInput } from '../../shared/schemas.js';

type FormValues = z.input<typeof bookingInput>;

type LoadState =
  | { status: 'loading' }
  | { status: 'ready'; tasting: TastingView }
  | { status: 'missing' }
  | { status: 'error'; message: string };

export function BookingPage() {
  const { tastingId = '' } = useParams();
  const [state, setState] = useState<LoadState>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    setState({ status: 'loading' });
    api
      .listTastings()
      .then(({ tastings }) => {
        if (!active) return;
        const tasting = tastings.find((t) => t.id === tastingId);
        setState(tasting ? { status: 'ready', tasting } : { status: 'missing' });
      })
      .catch((error: unknown) => {
        if (!active) return;
        const message = error instanceof ApiError ? error.message : 'Something went wrong.';
        setState({ status: 'error', message: `We couldn't load this tasting. ${message}` });
      });
    return () => {
      active = false;
    };
  }, [tastingId]);

  // Seats can run out while the guest fills in the form. Refresh the numbers, but keep the form mounted so typed values survive.
  const refreshTasting = useCallback(() => {
    api
      .listTastings()
      .then(({ tastings }) => {
        const tasting = tastings.find((t) => t.id === tastingId);
        if (tasting) setState({ status: 'ready', tasting });
      })
      .catch(() => undefined);
  }, [tastingId]);

  return (
    <div className="mx-auto max-w-2xl space-y-8">
      <Link to="/" className="inline-flex min-h-11 items-center text-sm font-medium text-wine-700 underline-offset-4 hover:underline">
        ← All tastings
      </Link>

      {state.status === 'loading' && <p className="text-ink-muted">Loading…</p>}

      {state.status === 'missing' && (
        <div role="alert" className="rounded-xl border border-danger-200 bg-danger-50 p-5 text-danger-800">
          We couldn&apos;t find that tasting. It may have been removed.
        </div>
      )}

      {state.status === 'error' && (
        <div role="alert" className="rounded-xl border border-danger-200 bg-danger-50 p-5 text-danger-800">
          {state.message}
        </div>
      )}

      {state.status === 'ready' && <TastingBooking tasting={state.tasting} onSeatsChanged={refreshTasting} />}
    </div>
  );
}

function TastingBooking({ tasting, onSeatsChanged }: { tasting: TastingView; onSeatsChanged: () => void }) {
  const details = (
    <header className="space-y-2">
      <h1 className="font-serif text-4xl leading-tight text-wine-800">{tasting.title}</h1>
      <p className="text-lg text-ink-muted">
        {formatStartsAt(tasting.startsAt)} · {formatPrice(tasting.priceEur)} per guest ·{' '}
        {seatsLeftLabel(tasting.seatsLeft)}
      </p>
    </header>
  );

  if (tasting.passed) {
    return (
      <>
        {details}
        <p className="rounded-xl border border-cream-300 bg-cream-50 p-5 text-ink-muted">
          This tasting has already taken place, so it can no longer be booked.
        </p>
      </>
    );
  }

  if (tasting.seatsLeft === 0) {
    return (
      <>
        {details}
        <p className="rounded-xl border border-danger-200 bg-danger-50 p-5 text-danger-800">
          This tasting is fully booked.
        </p>
      </>
    );
  }

  return (
    <>
      {details}
      <BookingForm tasting={tasting} onSeatsChanged={onSeatsChanged} />
    </>
  );
}

function BookingForm({ tasting, onSeatsChanged }: { tasting: TastingView; onSeatsChanged: () => void }) {
  const navigate = useNavigate();
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<FormValues, unknown, BookingInput>({
    resolver: zodResolver(bookingInput),
    defaultValues: { name: '', email: '', guests: 2 },
  });

  const guests = Number(watch('guests'));
  const validGuests = Number.isInteger(guests) && guests >= 1 && guests <= 8;

  const onSubmit = async (input: BookingInput) => {
    setFormError(null);
    try {
      const { booking } = await api.createBooking(tasting.id, input);
      navigate(`/bookings/${encodeURIComponent(booking.reference)}`);
    } catch (error) {
      if (error instanceof ApiError && Object.keys(error.fields).length > 0) {
        for (const [field, message] of Object.entries(error.fields)) {
          setError(field as keyof FormValues, { type: 'server', message });
        }
        if (error.status === 409) onSeatsChanged();
      } else {
        setFormError(error instanceof ApiError ? error.message : 'Something went wrong. Please try again.');
      }
    }
  };

  return (
    <form
      aria-label="Booking form"
      noValidate
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-6 rounded-2xl border border-cream-300 bg-cream-50 p-6 shadow-sm sm:p-8"
    >
      {formError && (
        <div role="alert" className="rounded-lg border border-danger-200 bg-danger-50 p-3 text-sm text-danger-800">
          {formError}
        </div>
      )}

      <Field id="name" label="Name" error={errors.name?.message}>
        <input
          type="text"
          autoComplete="name"
          className={inputClass(!!errors.name)}
          {...register('name')}
          {...fieldProps('name', errors.name?.message)}
        />
      </Field>

      <Field id="email" label="Email" error={errors.email?.message}>
        <input
          type="email"
          autoComplete="email"
          inputMode="email"
          className={inputClass(!!errors.email)}
          {...register('email')}
          {...fieldProps('email', errors.email?.message)}
        />
      </Field>

      <Field id="guests" label="Guests" error={errors.guests?.message}>
        <input
          type="number"
          inputMode="numeric"
          min={1}
          max={8}
          step={1}
          className={inputClass(!!errors.guests)}
          {...register('guests')}
          {...fieldProps('guests', errors.guests?.message)}
        />
      </Field>

      <div className="flex flex-col gap-4 border-t border-cream-300 pt-6 sm:flex-row sm:items-center sm:justify-between">
        <p aria-live="polite" className="text-ink">
          Total{' '}
          <span data-testid="total" className="font-serif text-2xl font-semibold text-wine-800">
            {validGuests ? formatPrice(tasting.priceEur * guests) : '—'}
          </span>
        </p>
        <button
          type="submit"
          disabled={isSubmitting}
          aria-busy={isSubmitting || undefined}
          className="inline-flex min-h-11 items-center justify-center rounded-lg bg-wine-700 px-8 py-2.5 font-semibold text-cream-50 shadow-sm transition hover:bg-wine-800 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-300 disabled:cursor-wait disabled:opacity-70"
        >
          Book
        </button>
      </div>
    </form>
  );
}
