import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { api, ApiError, type BookingView } from '../api.js';
import { formatPrice, formatStartsAt } from '../format.js';

type LoadState =
  | { status: 'loading' }
  | { status: 'ready'; booking: BookingView }
  | { status: 'missing' }
  | { status: 'error'; message: string };

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const [state, setState] = useState<LoadState>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    setState({ status: 'loading' });
    api
      .getBooking(reference)
      .then(({ booking }) => active && setState({ status: 'ready', booking }))
      .catch((error: unknown) => {
        if (!active) return;
        if (error instanceof ApiError && error.status === 404) {
          setState({ status: 'missing' });
        } else {
          const message = error instanceof ApiError ? error.message : 'Something went wrong.';
          setState({ status: 'error', message: `We couldn't load this booking. ${message}` });
        }
      });
    return () => {
      active = false;
    };
  }, [reference]);

  if (state.status === 'loading') return <p className="text-ink-muted">Loading…</p>;

  if (state.status === 'missing') {
    return (
      <div className="mx-auto max-w-2xl space-y-4">
        <h1 className="font-serif text-3xl text-wine-800">Booking not found</h1>
        <p role="alert" className="rounded-xl border border-danger-200 bg-danger-50 p-5 text-danger-800">
          We couldn&apos;t find a booking with reference <strong>{reference}</strong>. Check the reference and try again.
        </p>
        <BackToTastings />
      </div>
    );
  }

  if (state.status === 'error') {
    return (
      <div role="alert" className="mx-auto max-w-2xl rounded-xl border border-danger-200 bg-danger-50 p-5 text-danger-800">
        {state.message}
      </div>
    );
  }

  const { booking } = state;
  const cancelled = booking.status === 'cancelled';

  return (
    <div className="mx-auto max-w-2xl space-y-8">
      {cancelled ? (
        <header className="space-y-2">
          <h1 className="font-serif text-4xl leading-tight text-wine-800">Booking cancelled</h1>
          <p className="text-lg text-ink-muted">This booking has been cancelled. Its seats have been released.</p>
        </header>
      ) : (
        <header className="space-y-2">
          <p className="text-sm font-semibold uppercase tracking-widest text-gold-500">Thank you</p>
          <h1 className="font-serif text-4xl leading-tight text-wine-800">Booking confirmed</h1>
          <p className="text-lg text-ink-muted">Your seats are reserved. Keep your booking reference for your records.</p>
        </header>
      )}

      <section aria-label="Booking details" className="rounded-2xl border border-cream-300 bg-cream-50 p-6 shadow-sm sm:p-8">
        <dl className="grid gap-5 sm:grid-cols-2">
          <div>
            <dt className="text-sm text-ink-muted">Tasting</dt>
            <dd className="font-serif text-xl text-wine-800">{booking.tasting.title}</dd>
          </div>
          <div>
            <dt className="text-sm text-ink-muted">Date and time</dt>
            <dd className="font-medium">{formatStartsAt(booking.tasting.startsAt)}</dd>
          </div>
          <div>
            <dt className="text-sm text-ink-muted">Guests</dt>
            <dd className="font-medium">{booking.guests}</dd>
          </div>
          <div>
            <dt className="text-sm text-ink-muted">Total price</dt>
            <dd className="font-medium">{formatPrice(booking.totalEur)}</dd>
          </div>
          <div className="sm:col-span-2">
            <dt className="text-sm text-ink-muted">Booking reference</dt>
            <dd className="font-mono text-2xl font-semibold tracking-wider text-ink">{booking.reference}</dd>
          </div>
        </dl>
      </section>

      <BackToTastings />
    </div>
  );
}

function BackToTastings() {
  return (
    <Link to="/" className="inline-flex min-h-11 items-center text-sm font-medium text-wine-700 underline-offset-4 hover:underline">
      ← Back to all tastings
    </Link>
  );
}
