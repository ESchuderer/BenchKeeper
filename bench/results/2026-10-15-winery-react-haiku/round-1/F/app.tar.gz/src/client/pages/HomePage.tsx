import { useEffect, useState } from 'react';
import { api, ApiError, type TastingView } from '../api.js';
import { TastingCard } from '../components/TastingCard.js';

type State =
  | { status: 'loading' }
  | { status: 'ready'; tastings: TastingView[] }
  | { status: 'error'; message: string };

export function HomePage() {
  const [state, setState] = useState<State>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    api
      .listTastings()
      .then(({ tastings }) => active && setState({ status: 'ready', tastings }))
      .catch((error: unknown) => {
        if (!active) return;
        const message = error instanceof ApiError ? error.message : 'Something went wrong.';
        setState({ status: 'error', message: `We couldn't load the tastings. ${message}` });
      });
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="space-y-8">
      <section className="max-w-2xl">
        <h1 className="font-serif text-4xl leading-tight text-wine-800 sm:text-5xl">Tastings at the cellar door</h1>
        <p className="mt-4 text-lg text-ink-muted">
          Choose a tasting, pick the number of guests and book your seats online. You will see your confirmation
          straight away.
        </p>
      </section>

      {state.status === 'loading' && <p className="text-ink-muted">Loading tastings…</p>}

      {state.status === 'error' && (
        <div role="alert" className="rounded-xl border border-danger-200 bg-danger-50 p-4 text-danger-800">
          {state.message}
        </div>
      )}

      {state.status === 'ready' && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {state.tastings.map((tasting) => (
            <TastingCard key={tasting.id} tasting={tasting} />
          ))}
        </div>
      )}
    </div>
  );
}
