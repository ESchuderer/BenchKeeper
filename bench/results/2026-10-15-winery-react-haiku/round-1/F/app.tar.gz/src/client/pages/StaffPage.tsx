import { useCallback, useEffect, useId, useState } from 'react';
import { useForm } from 'react-hook-form';
import { api, ApiError, type StaffBooking, type StaffGroup } from '../api.js';
import { Field, fieldProps, inputClass } from '../components/Field.js';
import { formatStartsAt, seatsLeftLabel } from '../format.js';

type View =
  | { status: 'checking' }
  | { status: 'signed-out' }
  | { status: 'signed-in'; groups: StaffGroup[] }
  | { status: 'error'; message: string };

const GENERIC_ERROR = 'Something went wrong. Please try again.';

export function StaffPage() {
  const [view, setView] = useState<View>({ status: 'checking' });
  const [actionError, setActionError] = useState<string | null>(null);

  const loadBookings = useCallback(async () => {
    try {
      const { groups } = await api.staffBookings();
      setView({ status: 'signed-in', groups });
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        setView({ status: 'signed-out' });
      } else {
        setView({ status: 'error', message: error instanceof ApiError ? error.message : GENERIC_ERROR });
      }
    }
  }, []);

  useEffect(() => {
    loadBookings();
  }, [loadBookings]);

  const signOut = async () => {
    await api.staffSignOut().catch(() => undefined);
    setActionError(null);
    setView({ status: 'signed-out' });
  };

  const cancelBooking = async (booking: StaffBooking) => {
    const confirmed = window.confirm(
      `Cancel booking ${booking.reference} for ${booking.name} (${booking.guests} ${booking.guests === 1 ? 'guest' : 'guests'})?`,
    );
    if (!confirmed) return;

    setActionError(null);
    try {
      await api.cancelBooking(booking.reference);
      await loadBookings();
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        setView({ status: 'signed-out' });
        return;
      }
      setActionError(`We couldn't cancel booking ${booking.reference}. ${error instanceof ApiError ? error.message : GENERIC_ERROR}`);
    }
  };

  if (view.status === 'checking') return <p className="text-ink-muted">Loading…</p>;

  if (view.status === 'error') {
    return (
      <div role="alert" className="rounded-xl border border-danger-200 bg-danger-50 p-5 text-danger-800">
        We couldn&apos;t load the bookings. {view.message}
      </div>
    );
  }

  if (view.status === 'signed-out') {
    return <SignInForm onSignedIn={loadBookings} />;
  }

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-widest text-gold-500">Staff</p>
          <h1 className="font-serif text-4xl text-wine-800">Bookings</h1>
        </div>
        <button
          type="button"
          onClick={signOut}
          className="inline-flex min-h-11 items-center rounded-lg border border-wine-700 px-5 py-2 font-semibold text-wine-700 hover:bg-wine-700 hover:text-cream-50 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-300"
        >
          Sign out
        </button>
      </header>

      {actionError && (
        <div role="alert" className="rounded-lg border border-danger-200 bg-danger-50 p-3 text-sm text-danger-800">
          {actionError}
        </div>
      )}

      {view.groups.map((group) => (
        <TastingGroup key={group.tasting.id} group={group} onCancel={cancelBooking} />
      ))}
    </div>
  );
}

function TastingGroup({ group, onCancel }: { group: StaffGroup; onCancel: (booking: StaffBooking) => void }) {
  const headingId = useId();
  const booked = group.tasting.seats - group.seatsLeft;

  return (
    <section aria-labelledby={headingId} className="rounded-2xl border border-cream-300 bg-cream-50 p-6 shadow-sm">
      <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-cream-300 pb-4">
        <h2 id={headingId} className="font-serif text-2xl text-wine-800">
          {group.tasting.title}
        </h2>
        <p className="text-sm text-ink-muted">
          {formatStartsAt(group.tasting.startsAt)} · <span>{seatsLeftLabel(group.seatsLeft)}</span> ·{' '}
          <span>{booked} booked</span>
        </p>
      </div>

      {group.bookings.length === 0 ? (
        <p className="py-6 text-ink-muted">No bookings yet.</p>
      ) : (
        <ul className="divide-y divide-cream-300">
          {group.bookings.map((booking) => (
            <li
              key={booking.reference}
              className="grid gap-3 py-4 sm:grid-cols-[minmax(0,1.4fr)_minmax(0,1.6fr)_auto_auto] sm:items-center sm:gap-6"
            >
              <div className="min-w-0">
                <p className="font-semibold text-ink">{booking.name}</p>
                <p className="break-all text-sm text-ink-muted">{booking.email}</p>
              </div>
              <p className="font-mono text-sm tracking-wider">{booking.reference}</p>
              <p className="text-sm font-medium">
                {booking.guests} {booking.guests === 1 ? 'guest' : 'guests'}
              </p>
              <button
                type="button"
                onClick={() => onCancel(booking)}
                className="inline-flex min-h-11 items-center justify-center rounded-lg border border-danger-700 px-4 py-2 text-sm font-semibold text-danger-700 hover:bg-danger-50 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-danger-200"
              >
                Cancel
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function SignInForm({ onSignedIn }: { onSignedIn: () => Promise<void> }) {
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } });

  const submit = async ({ password }: { password: string }) => {
    setFormError(null);
    try {
      await api.staffSignIn(password);
      await onSignedIn();
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        setError('password', { type: 'server', message: 'Incorrect password.' });
      } else {
        setFormError(error instanceof ApiError ? error.message : GENERIC_ERROR);
      }
    }
  };

  return (
    <div className="mx-auto max-w-md space-y-6">
      <header className="space-y-2">
        <h1 className="font-serif text-4xl text-wine-800">Staff sign-in</h1>
        <p className="text-ink-muted">Enter the staff password to see today&apos;s bookings.</p>
      </header>

      <form
        aria-label="Staff sign in"
        noValidate
        onSubmit={handleSubmit(submit)}
        className="space-y-6 rounded-2xl border border-cream-300 bg-cream-50 p-6 shadow-sm sm:p-8"
      >
        {formError && (
          <div role="alert" className="rounded-lg border border-danger-200 bg-danger-50 p-3 text-sm text-danger-800">
            {formError}
          </div>
        )}

        <Field id="password" label="Password" error={errors.password?.message}>
          <input
            type="password"
            autoComplete="current-password"
            className={inputClass(!!errors.password)}
            {...register('password', { required: 'Please enter the staff password' })}
            {...fieldProps('password', errors.password?.message)}
          />
        </Field>

        <button
          type="submit"
          disabled={isSubmitting}
          aria-busy={isSubmitting || undefined}
          className="inline-flex min-h-11 w-full items-center justify-center rounded-lg bg-wine-700 px-6 py-2.5 font-semibold text-cream-50 shadow-sm hover:bg-wine-800 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-300 disabled:opacity-70"
        >
          Sign in
        </button>
      </form>
    </div>
  );
}
