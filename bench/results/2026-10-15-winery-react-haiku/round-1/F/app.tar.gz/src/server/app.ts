import { join } from 'node:path';
import cookieParser from 'cookie-parser';
import express, { type ErrorRequestHandler, type Request, type RequestHandler, type Response } from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { findTasting, TASTINGS, type Tasting } from '../shared/tastings.js';
import { bookingInput } from '../shared/schemas.js';
import { BookingError, type Booking, type BookingStore } from './store.js';
import { createStaffSessions, DEFAULT_SESSION_MS, passwordMatches, STAFF_COOKIE } from './staff-auth.js';

export interface AppOptions {
  store: BookingStore;
  /** Shared staff password. When unset, staff sign-in is refused. */
  staffPassword?: string;
  sessionTtlMs?: number;
  /** Absolute path to the built client. When set, it is served with an SPA fallback. */
  clientDir?: string;
  /** Hops of reverse proxy in front of the app, so rate limits see real client addresses. */
  trustProxy?: number;
}

const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_FAILURES_ALLOWED = 10;
const BOOKING_ATTEMPTS_PER_WINDOW = 20;

/** Public view of a booking. Name and email are left out: anyone with a reference can read this. */
function publicBooking(booking: Booking, tasting: Tasting) {
  return {
    reference: booking.reference,
    status: booking.status,
    guests: booking.guests,
    totalEur: tasting.priceEur * booking.guests,
    tasting: {
      id: tasting.id,
      title: tasting.title,
      startsAt: tasting.startsAt,
      priceEur: tasting.priceEur,
    },
  };
}

export function createApp({ store, staffPassword, sessionTtlMs = DEFAULT_SESSION_MS, clientDir, trustProxy }: AppOptions) {
  const app = express();
  if (trustProxy !== undefined) app.set('trust proxy', trustProxy);
  app.use(
    helmet({
      // The app is often served over plain HTTP on a local network (see README), so do not ask browsers to upgrade requests to HTTPS.
      contentSecurityPolicy: {
        useDefaults: true,
        directives: { 'upgrade-insecure-requests': null },
      },
    }),
  );
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  const sessions = createStaffSessions({ ttlMs: sessionTtlMs });
  const loginLimiter = rateLimit({
    windowMs: LOGIN_WINDOW_MS,
    limit: LOGIN_FAILURES_ALLOWED,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    // Only failed attempts count, so staff who sign in successfully are never locked out.
    skipSuccessfulRequests: true,
    message: { error: 'Too many failed sign-in attempts. Try again in 15 minutes.' },
  });
  const bookingLimiter = rateLimit({
    windowMs: LOGIN_WINDOW_MS,
    limit: BOOKING_ATTEMPTS_PER_WINDOW,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many booking attempts. Please wait a few minutes and try again.' },
  });
  const requireStaff: RequestHandler = (req, res, next) => {
    if (!sessions.isValid(req.cookies?.[STAFF_COOKIE])) {
      res.status(401).json({ error: 'Please sign in.' });
      return;
    }
    next();
  };

  const api = express.Router();

  api.get('/tastings', (_req, res) => {
    res.json({
      tastings: TASTINGS.map((tasting) => ({
        ...tasting,
        seatsLeft: store.seatsLeft(tasting.id),
        passed: store.hasPassed(tasting),
      })),
    });
  });

  api.post('/tastings/:tastingId/bookings', bookingLimiter, (req: Request<{ tastingId: string }>, res: Response) => {
    const tasting = findTasting(req.params.tastingId);
    if (!tasting) {
      res.status(404).json({ error: 'That tasting does not exist.' });
      return;
    }

    const parsed = bookingInput.safeParse(req.body ?? {});
    if (!parsed.success) {
      const fields: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        fields[String(issue.path[0])] ??= issue.message;
      }
      res.status(400).json({ error: 'Please correct the highlighted fields.', fields });
      return;
    }

    try {
      const booking = store.create(tasting.id, parsed.data);
      res.status(201).json({ booking: publicBooking(booking, tasting) });
    } catch (error) {
      if (!(error instanceof BookingError)) throw error;
      switch (error.code) {
        case 'tasting_passed':
          res.status(422).json({ error: error.message });
          return;
        case 'fully_booked':
        case 'not_enough_seats':
          res.status(409).json({ error: error.message, fields: { guests: error.message } });
          return;
        default:
          res.status(404).json({ error: error.message });
      }
    }
  });

  api.get('/bookings/:reference', (req: Request<{ reference: string }>, res: Response) => {
    const booking = store.get(req.params.reference);
    const tasting = booking && findTasting(booking.tastingId);
    if (!booking || !tasting) {
      res.status(404).json({ error: 'No booking found for that reference.' });
      return;
    }
    res.json({ booking: publicBooking(booking, tasting) });
  });

  api.post(
    '/staff/login',
    loginLimiter,
    (req: Request, res: Response) => {
      if (!staffPassword) {
        res.status(503).json({ error: 'Staff sign-in is not configured.' });
        return;
      }
      const password = typeof req.body?.password === 'string' ? req.body.password : '';
      if (!password || !passwordMatches(password, staffPassword)) {
        res.status(401).json({ error: 'Incorrect password.' });
        return;
      }
      res.cookie(STAFF_COOKIE, sessions.start(), {
        httpOnly: true,
        sameSite: 'strict',
        path: '/',
        maxAge: sessionTtlMs,
      });
      res.json({ ok: true });
    },
  );

  api.post('/staff/logout', (req: Request, res: Response) => {
    sessions.end(req.cookies?.[STAFF_COOKIE]);
    res.clearCookie(STAFF_COOKIE, { httpOnly: true, sameSite: 'strict', path: '/' });
    res.json({ ok: true });
  });

  api.get('/staff/bookings', requireStaff, (_req: Request, res: Response) => {
    res.json({
      groups: store.listByTasting().map(({ tasting, bookings }) => ({
        tasting,
        seatsLeft: store.seatsLeft(tasting.id),
        bookings: bookings.map((b) => ({
          reference: b.reference,
          name: b.name,
          email: b.email,
          guests: b.guests,
          createdAt: b.createdAt,
        })),
      })),
    });
  });

  api.delete('/staff/bookings/:reference', requireStaff, (req: Request<{ reference: string }>, res: Response) => {
    const booking = store.cancel(req.params.reference);
    if (!booking) {
      res.status(404).json({ error: 'No booking found for that reference.' });
      return;
    }
    res.json({ booking: { reference: booking.reference, status: booking.status } });
  });

  api.use((_req, res) => {
    res.status(404).json({ error: 'Not found.' });
  });

  app.use('/api', api);

  if (clientDir) {
    app.use(express.static(clientDir));
    // Client-side routes such as /book/:id and /staff load the app shell.
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(join(clientDir, 'index.html'));
    });
  }

  const errorHandler: ErrorRequestHandler = (error, _req, res, _next) => {
    if (error?.type === 'entity.parse.failed') {
      res.status(400).json({ error: 'The request body is not valid JSON.' });
      return;
    }
    if (error?.type === 'entity.too.large') {
      res.status(413).json({ error: 'The request is too large.' });
      return;
    }
    console.error(error);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  };
  app.use(errorHandler);

  return app;
}
