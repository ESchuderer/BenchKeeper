import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { BookingStore } from './store.js';

function readPort(value: string | undefined): number {
  if (value === undefined || value === '') return 3000;
  const port = Number(value);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`PORT must be a whole number between 1 and 65535, got "${value}"`);
  }
  return port;
}

/** TRUST_PROXY is the number of reverse proxies in front of the app. Unset means none. */
function readTrustProxy(value: string | undefined): number | undefined {
  if (value === undefined || value === '') return undefined;
  const hops = Number(value);
  if (!Number.isInteger(hops) || hops < 0) {
    throw new Error(`TRUST_PROXY must be a whole number of proxy hops, got "${value}"`);
  }
  return hops;
}

const port = readPort(process.env.PORT);
const trustProxy = readTrustProxy(process.env.TRUST_PROXY);
const staffPassword = process.env.STAFF_PASSWORD || undefined;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled until it is set.');
}

// Compiled to dist/server, so the client build sits in dist/client next to it.
const clientDir = fileURLToPath(new URL('../client', import.meta.url));
const hasClientBuild = existsSync(join(clientDir, 'index.html'));
if (!hasClientBuild) {
  console.warn(`No client build found in ${clientDir}. Run "npm run build" to serve the web app.`);
}

const app = createApp({
  store: new BookingStore(),
  staffPassword,
  clientDir: hasClientBuild ? clientDir : undefined,
  trustProxy,
});

const server = app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
});

function shutdown() {
  server.close(() => process.exit(0));
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
