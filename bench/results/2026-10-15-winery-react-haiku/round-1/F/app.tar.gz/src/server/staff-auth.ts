import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const STAFF_COOKIE = 'kb_staff';
export const DEFAULT_SESSION_MS = 8 * 60 * 60 * 1000;

/**
 * Compares two passwords without leaking how much of them matched. Hashing
 * first gives both sides the same length, which `timingSafeEqual` requires.
 */
export function passwordMatches(candidate: string, expected: string): boolean {
  const a = createHash('sha256').update(candidate).digest();
  const b = createHash('sha256').update(expected).digest();
  return timingSafeEqual(a, b);
}

export interface StaffSessions {
  start(): string;
  isValid(token: string | undefined): boolean;
  end(token: string | undefined): void;
}

export interface StaffSessionOptions {
  ttlMs?: number;
  now?: () => number;
}

/** Random tokens held in memory. Sessions are lost on restart, which is acceptable for a small staff group. */
export function createStaffSessions({ ttlMs = DEFAULT_SESSION_MS, now = Date.now }: StaffSessionOptions = {}): StaffSessions {
  const expiresAt = new Map<string, number>();

  const prune = () => {
    const time = now();
    for (const [token, expiry] of expiresAt) {
      if (expiry <= time) expiresAt.delete(token);
    }
  };

  return {
    start() {
      prune();
      const token = randomBytes(32).toString('base64url');
      expiresAt.set(token, now() + ttlMs);
      return token;
    },
    isValid(token) {
      if (!token) return false;
      const expiry = expiresAt.get(token);
      if (expiry === undefined) return false;
      if (expiry <= now()) {
        expiresAt.delete(token);
        return false;
      }
      return true;
    },
    end(token) {
      if (token) expiresAt.delete(token);
    },
  };
}
