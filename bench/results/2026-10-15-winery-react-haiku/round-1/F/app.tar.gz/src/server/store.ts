import { randomInt } from 'node:crypto';
import { findTasting, TASTINGS, type Tasting } from '../shared/tastings.js';
import { startsAtToUtcMs } from '../shared/format.js';
import type { BookingInput } from '../shared/schemas.js';

export type BookingStatus = 'confirmed' | 'cancelled';

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  status: BookingStatus;
  createdAt: string;
}

export type BookingErrorCode = 'unknown_tasting' | 'tasting_passed' | 'fully_booked' | 'not_enough_seats';

export class BookingError extends Error {
  constructor(
    readonly code: BookingErrorCode,
    message: string,
    readonly seatsLeft?: number,
  ) {
    super(message);
    this.name = 'BookingError';
  }
}

export interface BookingStoreOptions {
  now?: () => number;
}

// No look-alike characters (0/O, 1/I) so references are easy to read aloud.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const REFERENCE_LENGTH = 6;

function newReference(): string {
  let code = '';
  for (let i = 0; i < REFERENCE_LENGTH; i++) {
    code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  }
  return `KB-${code}`;
}

/**
 * In-memory booking store. Node runs JavaScript on one thread and the seat
 * check and the insert in `create` run without an `await` between them, so two
 * requests can never both take the last seat.
 */
export class BookingStore {
  private readonly now: () => number;
  private readonly bookings = new Map<string, Booking>();

  constructor(options: BookingStoreOptions = {}) {
    this.now = options.now ?? Date.now;
  }

  /** True once a tasting's start time is no longer in the future. */
  hasPassed(tasting: Tasting): boolean {
    return startsAtToUtcMs(tasting.startsAt) <= this.now();
  }

  seatsLeft(tastingId: string): number {
    const tasting = findTasting(tastingId);
    if (!tasting) return 0;
    return Math.max(0, tasting.seats - this.seatsTaken(tastingId));
  }

  create(tastingId: string, input: BookingInput): Booking {
    const tasting = this.requireBookableTasting(tastingId);
    const seatsLeft = this.seatsLeft(tastingId);
    if (seatsLeft === 0) {
      throw new BookingError('fully_booked', 'This tasting is fully booked.', 0);
    }
    if (input.guests > seatsLeft) {
      throw new BookingError(
        'not_enough_seats',
        seatsLeft === 1 ? 'Only 1 seat is left.' : `Only ${seatsLeft} seats are left.`,
        seatsLeft,
      );
    }

    const booking: Booking = {
      reference: this.freshReference(),
      tastingId: tasting.id,
      name: input.name,
      email: input.email,
      guests: input.guests,
      status: 'confirmed',
      createdAt: new Date(this.now()).toISOString(),
    };
    this.bookings.set(booking.reference, booking);
    return booking;
  }

  get(reference: string): Booking | undefined {
    return this.bookings.get(normalizeReference(reference));
  }

  cancel(reference: string): Booking | undefined {
    const booking = this.get(reference);
    if (!booking) return undefined;
    booking.status = 'cancelled';
    return booking;
  }

  /** Active (not cancelled) bookings per tasting, in catalogue order. */
  listByTasting(): Array<{ tasting: Tasting; bookings: Booking[] }> {
    return TASTINGS.map((tasting) => ({
      tasting,
      bookings: [...this.bookings.values()].filter(
        (b) => b.tastingId === tasting.id && b.status === 'confirmed',
      ),
    }));
  }

  private seatsTaken(tastingId: string): number {
    let taken = 0;
    for (const booking of this.bookings.values()) {
      if (booking.tastingId === tastingId && booking.status === 'confirmed') {
        taken += booking.guests;
      }
    }
    return taken;
  }

  private requireBookableTasting(tastingId: string): Tasting {
    const tasting = findTasting(tastingId);
    if (!tasting) {
      throw new BookingError('unknown_tasting', 'That tasting does not exist.');
    }
    if (this.hasPassed(tasting)) {
      throw new BookingError('tasting_passed', 'This tasting has already taken place.');
    }
    return tasting;
  }

  private freshReference(): string {
    let reference = newReference();
    while (this.bookings.has(reference)) {
      reference = newReference();
    }
    return reference;
  }
}

export function normalizeReference(reference: string): string {
  return reference.trim().toUpperCase();
}
