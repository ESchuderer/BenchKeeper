export const TIME_ZONE = 'Europe/Berlin';

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Parses `YYYY-MM-DDTHH:mm` into numeric parts. */
function parseLocal(startsAt: string) {
  const [date, time] = startsAt.split('T');
  const [year, month, day] = date.split('-').map(Number);
  const [hour, minute] = time.split(':').map(Number);
  return { year, month, day, hour, minute };
}

/** Shows e.g. `Fri 6 Nov 2026, 18:00`. The start time is already local, so no zone conversion is needed. */
export function formatStartsAt(startsAt: string): string {
  const { year, month, day, hour, minute } = parseLocal(startsAt);
  const weekday = WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()];
  const time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  return `${weekday} ${day} ${MONTHS[month - 1]} ${year}, ${time}`;
}

/** Offset of `timeZone` from UTC at the given instant, in milliseconds. */
function zoneOffsetMs(utcMs: number, timeZone: string): number {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone,
    hourCycle: 'h23',
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric',
  }).formatToParts(new Date(utcMs));
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value);
  const asUtc = Date.UTC(get('year'), get('month') - 1, get('day'), get('hour'), get('minute'), get('second'));
  return asUtc - Math.floor(utcMs / 1000) * 1000;
}

/** Converts a local `YYYY-MM-DDTHH:mm` time in Europe/Berlin to a UTC timestamp in milliseconds. */
export function startsAtToUtcMs(startsAt: string): number {
  const { year, month, day, hour, minute } = parseLocal(startsAt);
  const asIfUtc = Date.UTC(year, month - 1, day, hour, minute);
  const offset = zoneOffsetMs(asIfUtc, TIME_ZONE);
  const utc = asIfUtc - offset;
  // Re-check at the corrected instant, in case the offset changed across the boundary.
  return asIfUtc - zoneOffsetMs(utc, TIME_ZONE);
}

export function formatPrice(priceEur: number): string {
  return `EUR ${priceEur}`;
}

export function seatsLeftLabel(seatsLeft: number): string {
  return seatsLeft === 1 ? '1 seat left' : `${seatsLeft} seats left`;
}
