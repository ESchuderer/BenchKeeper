import { z } from 'zod';

export const MAX_GUESTS = 8;
export const GUESTS_MESSAGE = `Choose 1 to ${MAX_GUESTS} guests`;

/** Input for a new booking. Shared by the browser form and the API. */
export const bookingInput = z.object({
  name: z
    .string()
    .trim()
    .min(1, 'Please enter your name')
    .max(100, 'Name must be 100 characters or fewer'),
  email: z.string().trim().pipe(z.email('Please enter a valid email address')),
  guests: z.coerce
    .number({ error: GUESTS_MESSAGE })
    .int(GUESTS_MESSAGE)
    .min(1, GUESTS_MESSAGE)
    .max(MAX_GUESTS, GUESTS_MESSAGE),
});

export type BookingInput = z.infer<typeof bookingInput>;
