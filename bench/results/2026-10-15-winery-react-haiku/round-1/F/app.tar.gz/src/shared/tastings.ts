export interface Tasting {
  id: string;
  title: string;
  /** Local start time in Europe/Berlin, `YYYY-MM-DDTHH:mm`. */
  startsAt: string;
  priceEur: number;
  seats: number;
}

export const TASTINGS: readonly Tasting[] = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06T18:00',
    priceEur: 25,
    seats: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    startsAt: '2026-11-14T15:00',
    priceEur: 32,
    seats: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    startsAt: '2026-12-05T17:00',
    priceEur: 28,
    seats: 10,
  },
];

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((tasting) => tasting.id === id);
}
