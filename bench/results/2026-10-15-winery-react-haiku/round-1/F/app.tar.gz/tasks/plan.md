# Implementation Plan: Weingut Kieselbrunnen Tasting Bookings

## Overview
A single Node 22 app: an Express 5 server exposes a JSON API and serves a React 19 SPA built with Vite. Bookings live in memory. Shared TypeScript code (catalogue, zod schemas, formatting) is used by both sides. The spec is in `SPEC.md`.

## Architecture Decisions
- **Vertical slices.** Each task delivers one user-visible path (API + UI + tests) where possible. Foundations come first.
- **Single source of validation.** Zod schemas in `src/shared` validate on the server and drive the client form through `@hookform/resolvers/zod`. Server validation is authoritative.
- **Synchronous seat check and insert.** Node is single-threaded, so the check and the insert in `BookingStore.create` cannot interleave. No locks needed.
- **Store as a plain class with injected clock.** Tests can control "now" for the past-tasting rule.
- **App factory.** `createApp({ store, staffPassword, now })` returns an Express app, so supertest can test it without listening on a port. `src/server/index.ts` only reads env and listens.
- **Staff sessions in memory.** Random 32-byte token in an httpOnly, SameSite=Strict cookie. Sessions expire after 8 hours.
- **Build outputs.** Client to `dist/client` (Vite). Server compiled with `tsc` to `dist/server`. `npm start` runs the compiled server, which serves `dist/client` and the API.
- **Routing.** Client routes: `/`, `/book/:tastingId`, `/bookings/:reference`, `/staff`. API under `/api`.
- **Styling.** Tailwind 4 with custom theme tokens (wine, cream, gold) in `src/client/styles.css`. Serif headings, system sans body. No external fonts or CDNs.

## Task List

### Phase 1: Foundation (server and shared logic)
- [ ] T1: Project scaffold (package.json scripts, tsconfigs, vite, tailwind, vitest, eslint, README skeleton)
- [ ] T2: Shared catalogue, zod schemas and formatting helpers
- [ ] T3: Booking store (create with seat check, cancel, lookup, list, seats left)
- [ ] T4: Express API for guests (tastings, create booking, get booking)
- [ ] T5: Staff API (login with rate limit, logout, list grouped bookings, cancel) and server entry with static serving and SPA fallback

### Checkpoint: Foundation
- [ ] `npm test` and `npm run typecheck` pass
- [ ] API works end-to-end with curl against `npm start`

### Phase 2: Guest UI
- [ ] T6: Client shell (router, layout, theme, API client) and start page listing tastings
- [ ] T7: Booking form page with inline validation and server error mapping
- [ ] T8: Confirmation page (and cancelled state)

### Checkpoint: Guest flow
- [ ] A guest can book in the browser and see the confirmation

### Phase 3: Staff UI and polish
- [ ] T9: Staff sign-in and bookings view with cancel
- [ ] T10: Responsive and accessibility pass (375px, focus states, error live regions)
- [ ] T11: End-to-end smoke test (Playwright) if a browser can be installed

### Checkpoint: Complete
- [ ] All SPEC success criteria verified
- [ ] Build, test, typecheck and lint pass
- [ ] Code review completed and findings addressed

## Risks and Mitigations
| Risk | Impact | Mitigation |
|------|--------|------------|
| Express 5 wildcard syntax changed from Express 4 | Med | Use `/{*splat}` and cover the SPA fallback with a test |
| Tailwind 4 and Vite plugin version mismatch | Med | Install matching versions, verify with the first build (T1) |
| No browser for Playwright | Low | Check in T11; if unavailable, rely on jsdom component tests and a curl-driven API smoke test, and say so |
| Seat race between two concurrent requests | High | Single synchronous critical section in the store; test with concurrent `Promise.all` |
| Staff password leaking into logs or repo | High | Only read from env; never log it; `.gitignore` covers `.env` |

## Open Questions
- None blocking. Assumptions A1–A10 in `SPEC.md` apply.
