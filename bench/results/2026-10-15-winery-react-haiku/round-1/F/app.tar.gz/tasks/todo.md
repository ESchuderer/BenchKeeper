# Task List: Weingut Kieselbrunnen Tasting Bookings

Source: `tasks/plan.md`. Spec: `SPEC.md`.

## Phase 1: Foundation

- [x] **T1: Project scaffold**
  - Acceptance: `npm install` succeeds; `npm run build`, `npm run typecheck`, `npm test` and `npm run lint` run (empty suites allowed).
  - Verify: each command exits 0.
  - Files: `package.json`, `tsconfig.json`, `tsconfig.server.json`, `vite.config.ts`, `vitest.config.ts`, `eslint.config.js`, `index.html`, `.gitignore`, `src/client/main.tsx` stub.

- [x] **T2: Shared catalogue, schemas, formatting**
  - Acceptance: three tastings with the spec data; `bookingInput` rejects empty name, bad email, guests outside 1–8 or non-integer with the spec messages; formatting gives "25 Nov…" style date/time strings and `EUR n`; `seatsLeftLabel(n)` gives "1 seat left" / "n seats left".
  - Verify: `tests/shared/*.test.ts` pass (written first).
  - Dependencies: T1. Files: `src/shared/*.ts`, `tests/shared/*`.

- [x] **T3: Booking store**
  - Acceptance: `create` refuses guests > seats left and past tastings, returns a booking with a unique reference; `cancel` marks status cancelled and frees seats; `seatsLeft` never negative; `list` by tasting excludes cancelled; concurrent `create` calls cannot oversell.
  - Verify: `tests/server/store.test.ts` pass (written first).
  - Dependencies: T2. Files: `src/server/store.ts`, `tests/server/store.test.ts`.

- [x] **T4: Guest API**
  - Acceptance: `GET /api/tastings` returns tastings with `seatsLeft`; `POST /api/tastings/:id/bookings` returns 201 with the booking, 400 with `fields` on invalid input, 409 with a field error when seats are short, 404 for unknown tasting, 422 for a passed tasting; `GET /api/bookings/:ref` returns the booking or 404.
  - Verify: `tests/server/api-guest.test.ts` (supertest) pass.
  - Dependencies: T3. Files: `src/server/app.ts`, `tests/server/api-guest.test.ts`.

- [x] **T5: Staff API and server entry**
  - Acceptance: `POST /api/staff/login` gives 401 on wrong password, 503 when unset, 200 with an httpOnly SameSite=Strict cookie on success; rate limit returns 429 after 10 failures per 15 minutes; `GET /api/staff/bookings` gives 401 without a session, otherwise bookings grouped by tasting; `DELETE /api/staff/bookings/:ref` cancels; `POST /api/staff/logout` clears the session; static files and SPA fallback serve `index.html` for unknown non-API paths; `src/server/index.ts` reads `PORT` (default 3000) and `STAFF_PASSWORD`, warns when unset.
  - Verify: `tests/server/api-staff.test.ts` and `tests/server/static.test.ts` pass; `PORT=3100 npm start` with curl checks.
  - Dependencies: T4. Files: `src/server/app.ts`, `src/server/staff-auth.ts`, `src/server/index.ts`, tests.

### Checkpoint: Foundation
- [x] `npm test`, `npm run typecheck`, `npm run build` pass
- [x] curl smoke against `npm start` passes

## Phase 2: Guest UI

- [x] **T6: Client shell and start page**
  - Acceptance: routes render; layout header "Weingut Kieselbrunnen"; start page lists three tastings with title, date and time, price and seats-left label; "Book <title>" link present for bookable tastings; "Fully booked" state with no link when seats left = 0.
  - Verify: `tests/client/home.test.tsx` (jsdom + RTL) passes.
  - Dependencies: T5. Files: `src/client/*`.

- [x] **T7: Booking form page**
  - Acceptance: fields "Name", "Email", "Guests" and button "Book"; client-side zod errors appear next to the field; server 400 and 409 field errors appear next to the field; success navigates to `/bookings/:ref`; fully booked or passed tasting shows a message instead of the form.
  - Verify: `tests/client/book.test.tsx` passes.
  - Dependencies: T6.

- [x] **T8: Confirmation page**
  - Acceptance: heading "Booking confirmed", tasting title, guest count, total price, reference; cancelled booking shows "This booking has been cancelled."; unknown reference shows not-found message.
  - Verify: `tests/client/confirmation.test.tsx` passes.
  - Dependencies: T7.

### Checkpoint: Guest flow
- [x] Guest books in the browser (jsdom test plus manual curl) and sees confirmation

## Phase 3: Staff UI and polish

- [x] **T9: Staff page**
  - Acceptance: "Password" field, "Sign in" button; wrong password shows error next to the field; signed in shows bookings grouped by tasting with name, email, guests, reference and "Cancel"; cancel asks `window.confirm`, then removes the row and updates seats; "Sign out" button.
  - Verify: `tests/client/staff.test.tsx` passes.
  - Dependencies: T8.

- [x] **T10: Responsive and accessibility pass**
  - Acceptance: no horizontal scroll at 375px; touch targets ≥ 44px; visible focus rings; error messages linked to fields with `aria-describedby` and `role="alert"`; form inputs labelled.
  - Verify: component tests check ARIA wiring; visual check by screenshot if a browser is available.
  - Dependencies: T9.

- [x] **T11: End-to-end smoke (Playwright)**
  - Acceptance: one spec books a tasting and checks the confirmation; one spec signs in as staff and cancels it.
  - Verify: `npm run test:e2e` passes, or the blocker is recorded if chromium cannot be installed.
  - Dependencies: T10.

### Checkpoint: Complete
- [x] SPEC success criteria 1–11 verified
- [x] Build, test, typecheck and lint pass
- [x] Review done and findings addressed
- [x] README documents setup, env vars, limitations (in-memory, cookie over HTTP)
