// @vitest-environment jsdom
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { mockApi, renderAt, TASTING_LIST } from './helpers.js';

const CONFIRMED = {
  reference: 'KB-7Y8CMJ',
  status: 'confirmed',
  guests: 3,
  totalEur: 75,
  tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEur: 25 },
};

afterEach(() => {
  vi.unstubAllGlobals();
});

function routes(post: (body: unknown) => { status: number; body?: unknown }) {
  return mockApi((method, path, body) => {
    if (method === 'POST' && path === '/api/tastings/riesling-evening/bookings') return post(body);
    if (path === '/api/bookings/KB-7Y8CMJ') return { status: 200, body: { booking: CONFIRMED } };
    return { status: 200, body: TASTING_LIST };
  });
}

async function openForm() {
  renderAt('/book/riesling-evening');
  return screen.findByRole('form', { name: 'Booking form' });
}

describe('booking form', () => {
  it('shows the tasting and a form with Name, Email, Guests and Book', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }));
    await openForm();

    expect(screen.getByRole('heading', { level: 1, name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toHaveAttribute('type', 'email');
    const guests = screen.getByLabelText('Guests');
    expect(guests).toHaveAttribute('type', 'number');
    expect(guests).toHaveAttribute('min', '1');
    expect(guests).toHaveAttribute('max', '8');
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows the price and the running total for the chosen guests', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }));
    const user = userEvent.setup();
    await openForm();

    const guests = screen.getByLabelText('Guests');
    await user.clear(guests);
    await user.type(guests, '3');
    expect(screen.getByText('EUR 75', { selector: '[data-testid="total"]' })).toBeInTheDocument();
  });

  it('shows missing name and invalid email next to their fields and sends nothing', async () => {
    const fetchMock = mockApi(() => ({ status: 200, body: TASTING_LIST }));
    const user = userEvent.setup();
    await openForm();

    await user.click(screen.getByRole('button', { name: 'Book' }));

    const name = screen.getByLabelText('Name');
    const email = screen.getByLabelText('Email');
    expect(await screen.findByText('Please enter your name')).toBeInTheDocument();
    expect(screen.getByText('Please enter a valid email address')).toBeInTheDocument();
    expect(name).toHaveAccessibleDescription('Please enter your name');
    expect(name).toHaveAttribute('aria-invalid', 'true');
    expect(email).toHaveAccessibleDescription('Please enter a valid email address');
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'POST')).toBe(false);
  });

  it('rejects guests outside 1 to 8 next to the Guests field', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }));
    const user = userEvent.setup();
    await openForm();

    const guests = screen.getByLabelText('Guests');
    await user.clear(guests);
    await user.type(guests, '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Choose 1 to 8 guests')).toBeInTheDocument();
    expect(guests).toHaveAccessibleDescription('Choose 1 to 8 guests');
  });

  it('submits a valid booking and opens the confirmation', async () => {
    let sent: unknown;
    const fetchMock = routes((body) => {
      sent = body;
      return { status: 201, body: { booking: CONFIRMED } };
    });
    const user = userEvent.setup();
    await openForm();

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    await waitFor(() => expect(screen.getByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument());
    expect(sent).toEqual({ name: 'Anna Keller', email: 'anna@example.com', guests: 3 });
    expect(fetchMock).toHaveBeenCalledWith('/api/bookings/KB-7Y8CMJ', expect.anything());
  });

  it('shows a server seat error next to the Guests field', async () => {
    routes(() => ({
      status: 409,
      body: { error: 'Only 2 seats are left.', fields: { guests: 'Only 2 seats are left.' } },
    }));
    const user = userEvent.setup();
    await openForm();

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Only 2 seats are left.')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Only 2 seats are left.');
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
  });

  it('shows a general error when the booking cannot be made for another reason', async () => {
    routes(() => ({ status: 422, body: { error: 'This tasting has already taken place.' } }));
    const user = userEvent.setup();
    await openForm();

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('This tasting has already taken place.');
  });

  it('shows the fully booked message instead of the form', async () => {
    mockApi(() => ({
      status: 200,
      body: { tastings: [{ ...TASTING_LIST.tastings[0], seatsLeft: 0 }] },
    }));
    renderAt('/book/riesling-evening');

    expect(await screen.findByText('This tasting is fully booked.')).toBeInTheDocument();
    expect(screen.queryByRole('form', { name: 'Booking form' })).not.toBeInTheDocument();
  });

  it('explains when the tasting does not exist', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }));
    renderAt('/book/does-not-exist');

    const alert = await screen.findByRole('alert');
    expect(within(alert).getByText(/couldn't find that tasting/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /all tastings/i })).toHaveAttribute('href', '/');
  });
});

describe('booking form states', () => {
  it('explains that a passed tasting can no longer be booked', async () => {
    mockApi(() => ({
      status: 200,
      body: { tastings: [{ ...TASTING_LIST.tastings[0], passed: true }] },
    }));
    renderAt('/book/riesling-evening');

    expect(await screen.findByText(/already taken place/i)).toBeInTheDocument();
    expect(screen.queryByRole('form', { name: 'Booking form' })).not.toBeInTheDocument();
  });

  it('updates the seats shown when a booking is refused because seats ran out', async () => {
    let seatsLeft = 2;
    const user = userEvent.setup();
    mockApi((method) => {
      if (method === 'POST') {
        seatsLeft = 0;
        return { status: 409, body: { error: 'This tasting is fully booked.', fields: { guests: 'This tasting is fully booked.' } } };
      }
      return {
        status: 200,
        body: { tastings: [{ ...TASTING_LIST.tastings[0], seatsLeft }] },
      };
    });
    renderAt('/book/riesling-evening');
    expect(await screen.findByText(/2 seats left/)).toBeInTheDocument();

    await user.type(await screen.findByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('This tasting is fully booked.', { selector: 'p' })).toBeInTheDocument();
    expect(screen.queryByRole('form', { name: 'Booking form' })).not.toBeInTheDocument();
  });
});
