// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { mockApi, renderAt } from './helpers.js';

const BOOKING = {
  reference: 'KB-7Y8CMJ',
  status: 'confirmed',
  guests: 3,
  totalEur: 75,
  tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEur: 25 },
};

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('confirmation page', () => {
  it('shows the heading, tasting, guests, total price and booking reference', async () => {
    mockApi(() => ({ status: 200, body: { booking: BOOKING } }));
    renderAt('/bookings/KB-7Y8CMJ');

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const details = screen.getByRole('region', { name: 'Booking details' });
    expect(within(details).getByText('Riesling Evening')).toBeInTheDocument();
    expect(within(details).getByText('Fri 6 Nov 2026, 18:00')).toBeInTheDocument();
    expect(within(details).getByText('Guests').nextElementSibling).toHaveTextContent('3');
    expect(within(details).getByText('Total price').nextElementSibling).toHaveTextContent('EUR 75');
    expect(within(details).getByText('KB-7Y8CMJ')).toBeInTheDocument();
  });

  it('says so when the booking has been cancelled', async () => {
    mockApi(() => ({ status: 200, body: { booking: { ...BOOKING, status: 'cancelled' } } }));
    renderAt('/bookings/KB-7Y8CMJ');

    expect(await screen.findByRole('heading', { name: 'Booking cancelled' })).toBeInTheDocument();
    expect(screen.getByText('This booking has been cancelled. Its seats have been released.')).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
  });

  it('explains when no booking has that reference', async () => {
    mockApi(() => ({ status: 404, body: { error: 'No booking found for that reference.' } }));
    renderAt('/bookings/KB-000000');

    expect(await screen.findByRole('heading', { name: 'Booking not found' })).toBeInTheDocument();
    expect(screen.getByRole('alert')).toHaveTextContent('KB-000000');
  });

  it('shows an alert when the booking cannot be loaded', async () => {
    mockApi(() => ({ status: 500, body: { error: 'Something went wrong. Please try again.' } }));
    renderAt('/bookings/KB-7Y8CMJ');

    expect(await screen.findByRole('alert')).toHaveTextContent("We couldn't load this booking");
  });
});
