import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { vi } from 'vitest';
import { App } from '../../src/client/App.js';

export interface FakeResponse {
  status: number;
  body?: unknown;
}

type Handler = (method: string, path: string, body: Record<string, unknown> | undefined) => FakeResponse;

/** Replaces `fetch` with a handler that answers API calls in tests. */
export function mockApi(handler: Handler) {
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const method = init?.method ?? 'GET';
    const body = init?.body ? JSON.parse(String(init.body)) : undefined;
    const response = handler(method, String(input), body);
    return new Response(response.body === undefined ? null : JSON.stringify(response.body), {
      status: response.status,
      headers: { 'Content-Type': 'application/json' },
    });
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

export function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}

export const TASTING_LIST = {
  tastings: [
    {
      id: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      priceEur: 25,
      seats: 12,
      seatsLeft: 12,
      passed: false,
    },
    {
      id: 'red-wine-cellar-tour',
      title: 'Red Wine Cellar Tour',
      startsAt: '2026-11-14T15:00',
      priceEur: 32,
      seats: 8,
      seatsLeft: 0,
      passed: false,
    },
    {
      id: 'winter-tasting',
      title: 'Winter Tasting',
      startsAt: '2026-12-05T17:00',
      priceEur: 28,
      seats: 10,
      seatsLeft: 1,
      passed: false,
    },
  ],
};
