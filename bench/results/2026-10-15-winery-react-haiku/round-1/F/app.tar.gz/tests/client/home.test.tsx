// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { mockApi, renderAt, TASTING_LIST } from './helpers.js';

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('start page', () => {
  it('lists each tasting with date, time, price and seats left', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }));
    renderAt('/');

    const card = (await screen.findByRole('article', { name: 'Riesling Evening' })) as HTMLElement;
    expect(within(card).getByText('Fri 6 Nov 2026, 18:00')).toBeInTheDocument();
    expect(within(card).getByText('EUR 25')).toBeInTheDocument();
    expect(within(card).getByText('12 seats left')).toBeInTheDocument();
  });

  it('shows the singular for one seat left', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }));
    renderAt('/');
    const card = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(card).getByText('1 seat left')).toBeInTheDocument();
  });

  it('links each bookable tasting with "Book <title>"', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }));
    renderAt('/');
    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link).toHaveAttribute('href', '/book/riesling-evening');
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toHaveAttribute('href', '/book/winter-tasting');
  });

  it('marks a fully booked tasting and offers no booking link', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }));
    renderAt('/');
    const card = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(within(card).getByText('0 seats left')).toBeInTheDocument();
    expect(within(card).queryByRole('link')).not.toBeInTheDocument();
  });

  it('does not offer booking for a tasting that has already taken place', async () => {
    mockApi(() => ({
      status: 200,
      body: { tastings: [{ ...TASTING_LIST.tastings[0], passed: true }] },
    }));
    renderAt('/');
    const card = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(card).getByText('This tasting has taken place.')).toBeInTheDocument();
    expect(within(card).queryByRole('link')).not.toBeInTheDocument();
  });

  it('shows an alert when the tastings cannot be loaded', async () => {
    mockApi(() => ({ status: 500, body: { error: 'Something went wrong. Please try again.' } }));
    renderAt('/');
    expect(await screen.findByRole('alert')).toHaveTextContent("We couldn't load the tastings");
  });
});
