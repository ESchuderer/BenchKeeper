// @vitest-environment jsdom
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { mockApi, renderAt } from './helpers.js';

const PASSWORD = 'cellar-door-2026';

function makeGroups() {
  return [
    {
      tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEur: 25, seats: 12 },
      seatsLeft: 9,
      bookings: [
        { reference: 'KB-7Y8CMJ', name: 'Anna Keller', email: 'anna@example.com', guests: 3, createdAt: '2026-10-14T10:00:00.000Z' },
      ],
    },
    {
      tasting: { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceEur: 32, seats: 8 },
      seatsLeft: 8,
      bookings: [],
    },
  ];
}

/** A small fake staff backend: sign-in state and bookings live in closures. */
function staffBackend(options: { loginStatus?: number } = {}) {
  let signedIn = false;
  let groups = makeGroups();
  const fetchMock = mockApi((method, path, body) => {
    if (path === '/api/staff/login') {
      if (options.loginStatus) {
        return { status: options.loginStatus, body: { error: 'Staff sign-in is not configured.' } };
      }
      if (body?.password === PASSWORD) {
        signedIn = true;
        return { status: 200, body: { ok: true } };
      }
      return { status: 401, body: { error: 'Incorrect password.' } };
    }
    if (path === '/api/staff/logout') {
      signedIn = false;
      return { status: 200, body: { ok: true } };
    }
    if (path === '/api/staff/bookings' && method === 'GET') {
      return signedIn ? { status: 200, body: { groups } } : { status: 401, body: { error: 'Please sign in.' } };
    }
    if (method === 'DELETE' && path.startsWith('/api/staff/bookings/')) {
      if (!signedIn) return { status: 401, body: { error: 'Please sign in.' } };
      const reference = path.split('/').pop();
      groups = groups.map((g) => {
        const bookings = g.bookings.filter((b) => b.reference !== reference);
        const freed = g.bookings.length - bookings.length;
        return { ...g, bookings, seatsLeft: g.seatsLeft + (freed ? g.bookings.find((b) => b.reference === reference)!.guests : 0) };
      });
      return { status: 200, body: { booking: { reference, status: 'cancelled' } } };
    }
    return { status: 404, body: { error: 'Not found.' } };
  });
  return { fetchMock, setSignedIn: (value: boolean) => (signedIn = value) };
}

beforeEach(() => {
  vi.spyOn(window, 'confirm').mockReturnValue(true);
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('staff sign-in', () => {
  it('asks for the password when nobody is signed in', async () => {
    staffBackend();
    renderAt('/staff');

    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });

  it('shows an incorrect password error next to the Password field', async () => {
    staffBackend();
    const user = userEvent.setup();
    renderAt('/staff');

    await user.type(await screen.findByLabelText('Password'), 'guess');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    const password = screen.getByLabelText('Password');
    expect(await screen.findByText('Incorrect password.')).toBeInTheDocument();
    expect(password).toHaveAccessibleDescription('Incorrect password.');
    expect(screen.queryByRole('heading', { name: 'Bookings' })).not.toBeInTheDocument();
  });

  it('asks for a password before sending anything', async () => {
    const { fetchMock } = staffBackend();
    const user = userEvent.setup();
    renderAt('/staff');

    await user.click(await screen.findByRole('button', { name: 'Sign in' }));

    expect(await screen.findByText('Please enter the staff password')).toBeInTheDocument();
    expect(fetchMock.mock.calls.some(([path]) => path === '/api/staff/login')).toBe(false);
  });

  it('explains when staff sign-in is not configured on the server', async () => {
    staffBackend({ loginStatus: 503 });
    const user = userEvent.setup();
    renderAt('/staff');

    await user.type(await screen.findByLabelText('Password'), PASSWORD);
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Staff sign-in is not configured.');
  });
});

describe('staff bookings', () => {
  it('shows bookings grouped by tasting with name, email, guests and reference', async () => {
    staffBackend();
    const user = userEvent.setup();
    renderAt('/staff');
    await user.type(await screen.findByLabelText('Password'), PASSWORD);
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    expect(within(riesling).getByText('Anna Keller')).toBeInTheDocument();
    expect(within(riesling).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(riesling).getByText('KB-7Y8CMJ')).toBeInTheDocument();
    expect(within(riesling).getByText('3 guests')).toBeInTheDocument();
    expect(within(riesling).getByRole('button', { name: 'Cancel' })).toBeInTheDocument();

    const cellar = screen.getByRole('region', { name: 'Red Wine Cellar Tour' });
    expect(within(cellar).getByText('No bookings yet.')).toBeInTheDocument();
  });

  it('cancels a booking after confirmation and frees its seats', async () => {
    const { fetchMock } = staffBackend();
    const user = userEvent.setup();
    renderAt('/staff');
    await user.type(await screen.findByLabelText('Password'), PASSWORD);
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    await user.click(within(riesling).getByRole('button', { name: 'Cancel' }));

    await waitFor(() => expect(screen.queryByText('KB-7Y8CMJ')).not.toBeInTheDocument());
    expect(window.confirm).toHaveBeenCalled();
    expect(fetchMock).toHaveBeenCalledWith('/api/staff/bookings/KB-7Y8CMJ', expect.objectContaining({ method: 'DELETE' }));
    expect(within(screen.getByRole('region', { name: 'Riesling Evening' })).getByText('No bookings yet.')).toBeInTheDocument();
    expect(within(screen.getByRole('region', { name: 'Riesling Evening' })).getByText('12 seats left')).toBeInTheDocument();
  });

  it('keeps the booking when the cancellation is declined', async () => {
    vi.mocked(window.confirm).mockReturnValue(false);
    const { fetchMock } = staffBackend();
    const user = userEvent.setup();
    renderAt('/staff');
    await user.type(await screen.findByLabelText('Password'), PASSWORD);
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    await user.click(within(riesling).getByRole('button', { name: 'Cancel' }));

    expect(screen.getByText('KB-7Y8CMJ')).toBeInTheDocument();
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'DELETE')).toBe(false);
  });

  it('signs out and returns to the password prompt', async () => {
    staffBackend();
    const user = userEvent.setup();
    renderAt('/staff');
    await user.type(await screen.findByLabelText('Password'), PASSWORD);
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });

  it('returns to the password prompt when the session has expired', async () => {
    const backend = staffBackend();
    const user = userEvent.setup();
    renderAt('/staff');
    await user.type(await screen.findByLabelText('Password'), PASSWORD);
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    await screen.findByRole('region', { name: 'Riesling Evening' });

    backend.setSignedIn(false);
    await user.click(screen.getByRole('button', { name: 'Cancel' }));

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });
});
