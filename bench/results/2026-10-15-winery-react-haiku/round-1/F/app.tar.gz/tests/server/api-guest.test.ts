import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';

const BEFORE = Date.UTC(2026, 9, 14, 12, 0);
const AFTER_RIESLING = Date.UTC(2026, 10, 7, 12, 0);
const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function setup(now = BEFORE) {
  const store = new BookingStore({ now: () => now });
  const app = createApp({ store, staffPassword: 'secret' });
  return { store, app };
}

describe('GET /api/tastings', () => {
  it('lists every tasting with its seats left', async () => {
    const { app, store } = setup();
    store.create('riesling-evening', { ...valid, guests: 3 });

    const res = await request(app).get('/api/tastings');

    expect(res.status).toBe(200);
    expect(res.body.tastings.map((t: { id: string; seatsLeft: number }) => [t.id, t.seatsLeft])).toEqual([
      ['riesling-evening', 9],
      ['red-wine-cellar-tour', 8],
      ['winter-tasting', 10],
    ]);
    expect(res.body.tastings[0]).toMatchObject({
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      priceEur: 25,
      seats: 12,
      passed: false,
    });
  });

  it('marks tastings whose start time has passed', async () => {
    const { app } = setup(AFTER_RIESLING);
    const res = await request(app).get('/api/tastings');
    expect(res.body.tastings[0].passed).toBe(true);
    expect(res.body.tastings[1].passed).toBe(false);
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and returns it with status 201', async () => {
    const { app, store } = setup();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(valid);

    expect(res.status).toBe(201);
    expect(res.body.booking.reference).toMatch(/^KB-/);
    expect(res.body.booking).toMatchObject({ guests: 2, status: 'confirmed', totalEur: 50 });
    expect(store.seatsLeft('riesling-evening')).toBe(10);
  });

  it('accepts guests sent as a string, as a form would', async () => {
    const { app } = setup();
    const res = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ ...valid, guests: '3' });
    expect(res.status).toBe(201);
    expect(res.body.booking.guests).toBe(3);
  });

  it.each([
    [{ ...valid, name: '' }, 'name', 'Please enter your name'],
    [{ ...valid, email: 'nope' }, 'email', 'Please enter a valid email address'],
    [{ ...valid, guests: 0 }, 'guests', 'Choose 1 to 8 guests'],
    [{ ...valid, guests: 9 }, 'guests', 'Choose 1 to 8 guests'],
  ])('rejects invalid input %j with a message for the field', async (body, field, message) => {
    const { app, store } = setup();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(body);

    expect(res.status).toBe(400);
    expect(res.body.fields).toEqual({ [field]: message });
    expect(store.seatsLeft('riesling-evening')).toBe(12);
  });

  it('refuses more guests than seats left, with the message on the guests field', async () => {
    const { app, store } = setup();
    store.create('red-wine-cellar-tour', { ...valid, guests: 5 });

    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...valid, guests: 4 });

    expect(res.status).toBe(409);
    expect(res.body.fields).toEqual({ guests: 'Only 3 seats are left.' });
    expect(store.seatsLeft('red-wine-cellar-tour')).toBe(3);
  });

  it('refuses a fully booked tasting', async () => {
    const { app, store } = setup();
    store.create('red-wine-cellar-tour', { ...valid, guests: 8 });

    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send(valid);

    expect(res.status).toBe(409);
    expect(res.body.fields).toEqual({ guests: 'This tasting is fully booked.' });
  });

  it('returns 404 for an unknown tasting', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/tastings/nope/bookings').send(valid);
    expect(res.status).toBe(404);
    expect(res.body.error).toBeTruthy();
  });

  it('returns 422 for a tasting that has already taken place', async () => {
    const { app } = setup(AFTER_RIESLING);
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(valid);
    expect(res.status).toBe(422);
    expect(res.body.error).toBe('This tasting has already taken place.');
  });

  it('returns a JSON 400 for a malformed request body', async () => {
    const { app } = setup();
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ');
    expect(res.status).toBe(400);
    expect(res.body.error).toBeTruthy();
  });
});

describe('POST /api/tastings/:id/bookings limits', () => {
  it('returns 413 for an oversized body', async () => {
    const { app } = setup();
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...valid, name: 'x'.repeat(20_000) });
    expect(res.status).toBe(413);
    expect(res.body.error).toBe('The request is too large.');
  });

  it('rate limits booking attempts from one address', async () => {
    const { app } = setup();
    for (let i = 0; i < 20; i++) {
      const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...valid, guests: 1 });
      expect(res.status).not.toBe(429);
    }
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...valid, guests: 1 });
    expect(res.status).toBe(429);
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the booking with tasting details and total price, without personal contact details', async () => {
    const { app, store } = setup();
    const booking = store.create('riesling-evening', valid);

    const res = await request(app).get(`/api/bookings/${booking.reference}`);

    expect(res.status).toBe(200);
    expect(res.body.booking).toEqual({
      reference: booking.reference,
      status: 'confirmed',
      guests: 2,
      totalEur: 50,
      tasting: {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        startsAt: '2026-11-06T18:00',
        priceEur: 25,
      },
    });
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
  });

  it('shows cancelled bookings as cancelled', async () => {
    const { app, store } = setup();
    const booking = store.create('riesling-evening', valid);
    store.cancel(booking.reference);
    const res = await request(app).get(`/api/bookings/${booking.reference}`);
    expect(res.body.booking.status).toBe('cancelled');
  });

  it('returns 404 for an unknown reference', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/bookings/KB-000000');
    expect(res.status).toBe(404);
  });
});
