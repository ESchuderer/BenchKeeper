import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';

const BEFORE = Date.UTC(2026, 9, 14, 12, 0);
const PASSWORD = 'cellar-door-2026';
const anna = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function setup(staffPassword: string | undefined = PASSWORD) {
  const store = new BookingStore({ now: () => BEFORE });
  const app = createApp({ store, staffPassword });
  return { store, app };
}

async function signIn(app: ReturnType<typeof createApp>, password = PASSWORD) {
  const res = await request(app).post('/api/staff/login').send({ password });
  expect(res.status).toBe(200);
  const cookie = res.headers['set-cookie']?.[0] ?? '';
  return cookie.split(';')[0];
}

describe('POST /api/staff/login', () => {
  it('rejects a wrong password without setting a cookie', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/staff/login').send({ password: 'guess' });
    expect(res.status).toBe(401);
    expect(res.body.error).toBe('Incorrect password.');
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('rejects a request without a password', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/staff/login').send({});
    expect(res.status).toBe(401);
  });

  it('refuses sign-in when no staff password is configured', async () => {
    const app = createApp({ store: new BookingStore({ now: () => BEFORE }) });
    const res = await request(app).post('/api/staff/login').send({ password: 'guess' });
    expect(res.status).toBe(503);
    expect(res.body.error).toBe('Staff sign-in is not configured.');
  });

  it('sets an httpOnly, SameSite=Strict session cookie on success', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/staff/login').send({ password: PASSWORD });
    expect(res.status).toBe(200);
    const cookie = res.headers['set-cookie']?.[0] ?? '';
    expect(cookie).toMatch(/^kb_staff=[^;]+/);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    expect(cookie).toMatch(/Path=\//i);
  });

  it('locks out after 10 failed attempts', async () => {
    const { app } = setup();
    for (let i = 0; i < 10; i++) {
      expect((await request(app).post('/api/staff/login').send({ password: 'wrong' })).status).toBe(401);
    }
    const res = await request(app).post('/api/staff/login').send({ password: 'wrong' });
    expect(res.status).toBe(429);
    expect(res.body.error).toMatch(/too many/i);
  });
});

describe('staff bookings', () => {
  it('requires a session to list bookings', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/staff/bookings');
    expect(res.status).toBe(401);
    expect(res.body.error).toBe('Please sign in.');
  });

  it('rejects a forged session cookie', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/staff/bookings').set('Cookie', 'kb_staff=forged');
    expect(res.status).toBe(401);
  });

  it('lists active bookings grouped by tasting with contact details and seats', async () => {
    const { app, store } = setup();
    store.create('riesling-evening', anna);
    const cancelled = store.create('riesling-evening', { ...anna, name: 'Ben' });
    store.cancel(cancelled.reference);
    const cookie = await signIn(app);

    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie);

    expect(res.status).toBe(200);
    expect(res.body.groups).toHaveLength(3);
    const riesling = res.body.groups[0];
    expect(riesling.tasting).toMatchObject({ id: 'riesling-evening', title: 'Riesling Evening', seats: 12 });
    expect(riesling.seatsLeft).toBe(10);
    expect(riesling.bookings).toHaveLength(1);
    expect(riesling.bookings[0]).toMatchObject({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
    expect(riesling.bookings[0].reference).toMatch(/^KB-/);
    expect(res.body.groups[2].bookings).toEqual([]);
  });

  it('cancels a booking and frees its seats', async () => {
    const { app, store } = setup();
    const booking = store.create('riesling-evening', anna);
    const cookie = await signIn(app);

    const res = await request(app).delete(`/api/staff/bookings/${booking.reference}`).set('Cookie', cookie);

    expect(res.status).toBe(200);
    expect(res.body.booking).toMatchObject({ reference: booking.reference, status: 'cancelled' });
    expect(store.seatsLeft('riesling-evening')).toBe(12);
  });

  it('returns 404 when cancelling an unknown reference', async () => {
    const { app } = setup();
    const cookie = await signIn(app);
    const res = await request(app).delete('/api/staff/bookings/KB-000000').set('Cookie', cookie);
    expect(res.status).toBe(404);
  });

  it('refuses to cancel without a session and leaves the booking alone', async () => {
    const { app, store } = setup();
    const booking = store.create('riesling-evening', anna);
    const res = await request(app).delete(`/api/staff/bookings/${booking.reference}`);
    expect(res.status).toBe(401);
    expect(store.get(booking.reference)?.status).toBe('confirmed');
  });

  it('ends the session on sign-out', async () => {
    const { app } = setup();
    const cookie = await signIn(app);
    const out = await request(app).post('/api/staff/logout').set('Cookie', cookie);
    expect(out.status).toBe(200);
    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(res.status).toBe(401);
  });
});

describe('sign-in rate limit behind a proxy', () => {
  it('counts failures per forwarded client address when trustProxy is set', async () => {
    const store = new BookingStore({ now: () => BEFORE });
    const app = createApp({ store, staffPassword: PASSWORD, trustProxy: 1 });
    const attempt = (address: string, password: string) =>
      request(app).post('/api/staff/login').set('X-Forwarded-For', address).send({ password });

    for (let i = 0; i < 10; i++) {
      await attempt('203.0.113.5', 'wrong');
    }
    expect((await attempt('203.0.113.5', 'wrong')).status).toBe(429);
    expect((await attempt('198.51.100.7', 'wrong')).status).toBe(401);
  });
});
