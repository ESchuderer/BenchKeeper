import { describe, expect, it } from 'vitest';
import { createStaffSessions, passwordMatches } from '../../src/server/staff-auth.js';

describe('passwordMatches', () => {
  it('accepts the exact password only', () => {
    expect(passwordMatches('cellar-door-2026', 'cellar-door-2026')).toBe(true);
    expect(passwordMatches('cellar-door-2025', 'cellar-door-2026')).toBe(false);
    expect(passwordMatches('cellar-door-2026 ', 'cellar-door-2026')).toBe(false);
    expect(passwordMatches('', 'cellar-door-2026')).toBe(false);
  });
});

describe('createStaffSessions', () => {
  it('issues a token that is valid until it expires', () => {
    let now = 1_000;
    const sessions = createStaffSessions({ ttlMs: 500, now: () => now });
    const token = sessions.start();

    expect(token.length).toBeGreaterThanOrEqual(32);
    expect(sessions.isValid(token)).toBe(true);
    now = 1_499;
    expect(sessions.isValid(token)).toBe(true);
    now = 1_500;
    expect(sessions.isValid(token)).toBe(false);
  });

  it('rejects unknown and missing tokens', () => {
    const sessions = createStaffSessions({ ttlMs: 500 });
    expect(sessions.isValid(undefined)).toBe(false);
    expect(sessions.isValid('made-up')).toBe(false);
  });

  it('ends a session when asked', () => {
    const sessions = createStaffSessions({ ttlMs: 500 });
    const token = sessions.start();
    sessions.end(token);
    expect(sessions.isValid(token)).toBe(false);
  });

  it('gives each session a different token', () => {
    const sessions = createStaffSessions({ ttlMs: 500 });
    expect(sessions.start()).not.toBe(sessions.start());
  });
});
