import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';

let clientDir: string;

beforeAll(() => {
  clientDir = mkdtempSync(join(tmpdir(), 'kb-client-'));
  mkdirSync(join(clientDir, 'assets'));
  writeFileSync(join(clientDir, 'index.html'), '<!doctype html><div id="root"></div>');
  writeFileSync(join(clientDir, 'assets', 'app.js'), 'console.log("app");');
});

afterAll(() => {
  rmSync(clientDir, { recursive: true, force: true });
});

function app() {
  return createApp({ store: new BookingStore(), staffPassword: 'x', clientDir });
}

describe('static client and SPA fallback', () => {
  it('serves the app shell at the root', async () => {
    const res = await request(app()).get('/');
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/text\/html/);
    expect(res.text).toContain('id="root"');
  });

  it('serves built assets', async () => {
    const res = await request(app()).get('/assets/app.js');
    expect(res.status).toBe(200);
    expect(res.text).toContain('console.log');
  });

  it.each(['/book/winter-tasting', '/bookings/KB-ABCDEF', '/staff'])(
    'serves the app shell for client route %s',
    async (path) => {
      const res = await request(app()).get(path);
      expect(res.status).toBe(200);
      expect(res.text).toContain('id="root"');
    },
  );

  it('keeps unknown API paths as JSON 404s instead of the app shell', async () => {
    const res = await request(app()).get('/api/does-not-exist');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/application\/json/);
  });

  it('sends security headers', async () => {
    const res = await request(app()).get('/api/tastings');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });
});

describe('plain-HTTP deployment', () => {
  it('does not ask browsers to upgrade requests to HTTPS', async () => {
    const res = await request(app()).get('/');
    expect(res.headers['content-security-policy']).toBeDefined();
    expect(res.headers['content-security-policy']).not.toContain('upgrade-insecure-requests');
  });
});
