import { describe, expect, it } from 'vitest';
import { BookingError, BookingStore } from '../../src/server/store.js';

const ANNA = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };
const BEFORE_ALL_TASTINGS = Date.UTC(2026, 9, 14, 12, 0);
const AFTER_RIESLING = Date.UTC(2026, 10, 7, 12, 0);

function newStore(now = BEFORE_ALL_TASTINGS) {
  return new BookingStore({ now: () => now });
}

function expectError(fn: () => unknown, code: string) {
  try {
    fn();
  } catch (error) {
    expect(error).toBeInstanceOf(BookingError);
    expect((error as BookingError).code).toBe(code);
    return error as BookingError;
  }
  throw new Error(`expected BookingError ${code}`);
}

describe('BookingStore seats', () => {
  it('starts with every seat free', () => {
    expect(newStore().seatsLeft('riesling-evening')).toBe(12);
    expect(newStore().seatsLeft('red-wine-cellar-tour')).toBe(8);
  });

  it('reduces seats left by the number of guests booked', () => {
    const store = newStore();
    store.create('riesling-evening', ANNA);
    expect(store.seatsLeft('riesling-evening')).toBe(10);
  });

  it('allows booking exactly the seats left', () => {
    const store = newStore();
    store.create('red-wine-cellar-tour', { ...ANNA, guests: 5 });
    expect(() => store.create('red-wine-cellar-tour', { ...ANNA, guests: 3 })).not.toThrow();
    expect(store.seatsLeft('red-wine-cellar-tour')).toBe(0);
  });

  it('refuses more guests than seats left, with the seats left in the error', () => {
    const store = newStore();
    store.create('red-wine-cellar-tour', { ...ANNA, guests: 5 });
    const error = expectError(
      () => store.create('red-wine-cellar-tour', { ...ANNA, guests: 4 }),
      'not_enough_seats',
    );
    expect(error.seatsLeft).toBe(3);
    expect(store.seatsLeft('red-wine-cellar-tour')).toBe(3);
  });

  it('reports a fully booked tasting as fully_booked', () => {
    const store = newStore();
    store.create('red-wine-cellar-tour', { ...ANNA, guests: 8 });
    expectError(() => store.create('red-wine-cellar-tour', { ...ANNA, guests: 1 }), 'fully_booked');
  });

  it('refuses unknown tastings', () => {
    expectError(() => newStore().create('nope', ANNA), 'unknown_tasting');
  });

  it('refuses tastings whose start time has passed', () => {
    expectError(() => newStore(AFTER_RIESLING).create('riesling-evening', ANNA), 'tasting_passed');
  });

  it('refuses a tasting at the exact moment it starts', () => {
    const start = Date.UTC(2026, 10, 6, 17, 0); // 18:00 in Europe/Berlin
    expectError(() => newStore(start).create('riesling-evening', ANNA), 'tasting_passed');
    expect(() => newStore(start - 1).create('riesling-evening', ANNA)).not.toThrow();
  });

  it('never oversells with mixed party sizes arriving together', async () => {
    const store = newStore();
    const parties = [5, 4, 3, 2, 1];
    const results = await Promise.allSettled(
      parties.map((guests) => Promise.resolve().then(() => store.create('red-wine-cellar-tour', { ...ANNA, guests }))),
    );
    const bookedGuests = results.reduce((sum, r) => (r.status === 'fulfilled' ? sum + r.value.guests : sum), 0);
    expect(bookedGuests).toBeLessThanOrEqual(8);
    expect(store.seatsLeft('red-wine-cellar-tour')).toBe(8 - bookedGuests);
  });

  it('keeps bookings for different tastings separate', () => {
    const store = newStore();
    store.create('riesling-evening', { ...ANNA, guests: 12 });
    expect(store.seatsLeft('winter-tasting')).toBe(10);
  });
});

describe('BookingStore bookings', () => {
  it('returns a confirmed booking with a reference in KB-XXXXXX form', () => {
    const booking = newStore().create('riesling-evening', ANNA);
    expect(booking).toMatchObject({
      tastingId: 'riesling-evening',
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: 2,
      status: 'confirmed',
    });
    expect(booking.reference).toMatch(/^KB-[23456789A-HJ-NP-Z]{6}$/);
  });

  it('gives every booking a unique reference', () => {
    const store = newStore();
    const refs = new Set<string>();
    for (let i = 0; i < 200; i++) {
      // Cancel each one so the seats free up; cancelled references stay in the store.
      const booking = store.create('winter-tasting', { ...ANNA, guests: 1 });
      refs.add(booking.reference);
      store.cancel(booking.reference);
    }
    expect(refs.size).toBe(200);
  });

  it('finds a booking by reference, ignoring case and spaces', () => {
    const store = newStore();
    const booking = store.create('riesling-evening', ANNA);
    expect(store.get(booking.reference)?.name).toBe('Anna Keller');
    expect(store.get(` ${booking.reference.toLowerCase()} `)?.name).toBe('Anna Keller');
    expect(store.get('KB-000000')).toBeUndefined();
  });

  it('cancels a booking and frees its seats', () => {
    const store = newStore();
    const booking = store.create('riesling-evening', ANNA);
    const cancelled = store.cancel(booking.reference);
    expect(cancelled?.status).toBe('cancelled');
    expect(store.seatsLeft('riesling-evening')).toBe(12);
  });

  it('returns undefined when cancelling an unknown reference and keeps cancelling idempotent', () => {
    const store = newStore();
    const booking = store.create('riesling-evening', ANNA);
    expect(store.cancel('KB-000000')).toBeUndefined();
    store.cancel(booking.reference);
    expect(store.cancel(booking.reference)?.status).toBe('cancelled');
    expect(store.seatsLeft('riesling-evening')).toBe(12);
  });

  it('lists active bookings grouped by tasting in catalogue order, including empty tastings', () => {
    const store = newStore();
    const winter = store.create('winter-tasting', { ...ANNA, name: 'Ben' });
    const cancelled = store.create('winter-tasting', { ...ANNA, name: 'Cara' });
    store.create('riesling-evening', ANNA);
    store.cancel(cancelled.reference);

    const groups = store.listByTasting();
    expect(groups.map((g) => g.tasting.id)).toEqual(['riesling-evening', 'red-wine-cellar-tour', 'winter-tasting']);
    expect(groups[1].bookings).toEqual([]);
    expect(groups[2].bookings.map((b) => b.reference)).toEqual([winter.reference]);
  });

  it('never oversells when many requests arrive at once', async () => {
    const store = newStore();
    const attempts = Array.from({ length: 20 }, () =>
      Promise.resolve().then(() => store.create('red-wine-cellar-tour', { ...ANNA, guests: 1 })),
    );
    const results = await Promise.allSettled(attempts);
    const booked = results.filter((r) => r.status === 'fulfilled').length;
    expect(booked).toBe(8);
    expect(store.seatsLeft('red-wine-cellar-tour')).toBe(0);
  });
});
