import { describe, expect, it } from 'vitest';
import { formatPrice, formatStartsAt, seatsLeftLabel, startsAtToUtcMs } from '../../src/shared/format.js';

describe('formatStartsAt', () => {
  it('shows weekday, date and time of the local start time', () => {
    expect(formatStartsAt('2026-11-06T18:00')).toBe('Fri 6 Nov 2026, 18:00');
    expect(formatStartsAt('2026-11-14T15:00')).toBe('Sat 14 Nov 2026, 15:00');
    expect(formatStartsAt('2026-12-05T17:00')).toBe('Sat 5 Dec 2026, 17:00');
  });
});

describe('startsAtToUtcMs', () => {
  it('converts winter local time in Europe/Berlin (UTC+1)', () => {
    expect(startsAtToUtcMs('2026-11-06T18:00')).toBe(Date.UTC(2026, 10, 6, 17, 0));
    expect(startsAtToUtcMs('2026-12-05T17:00')).toBe(Date.UTC(2026, 11, 5, 16, 0));
  });

  it('converts summer local time in Europe/Berlin (UTC+2)', () => {
    expect(startsAtToUtcMs('2026-07-01T12:00')).toBe(Date.UTC(2026, 6, 1, 10, 0));
  });
});

describe('formatPrice', () => {
  it('formats whole euros as the brief does', () => {
    expect(formatPrice(25)).toBe('EUR 25');
    expect(formatPrice(75)).toBe('EUR 75');
  });
});

describe('seatsLeftLabel', () => {
  it('uses the spec wording and the singular for one seat', () => {
    expect(seatsLeftLabel(0)).toBe('0 seats left');
    expect(seatsLeftLabel(1)).toBe('1 seat left');
    expect(seatsLeftLabel(5)).toBe('5 seats left');
  });
});
