import { describe, expect, it } from 'vitest';
import { bookingInput } from '../../src/shared/schemas.js';

const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

describe('bookingInput', () => {
  it('accepts a valid booking and trims the name and email', () => {
    const result = bookingInput.safeParse({ ...valid, name: '  Anna Keller  ', email: ' anna@example.com ' });
    expect(result.success).toBe(true);
    expect(result.data).toEqual({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
  });

  it('accepts guests sent as a numeric string from a form', () => {
    const result = bookingInput.safeParse({ ...valid, guests: '8' });
    expect(result.success).toBe(true);
    expect(result.data?.guests).toBe(8);
  });

  it('rejects an empty or blank name with a message for the name field', () => {
    for (const name of ['', '   ']) {
      const result = bookingInput.safeParse({ ...valid, name });
      expect(result.success).toBe(false);
      expect(result.error?.issues[0]).toMatchObject({ path: ['name'], message: 'Please enter your name' });
    }
  });

  it('rejects an overlong name', () => {
    const result = bookingInput.safeParse({ ...valid, name: 'x'.repeat(101) });
    expect(result.error?.issues[0]).toMatchObject({ path: ['name'] });
  });

  it('rejects an invalid email with a message for the email field', () => {
    for (const email of ['', 'not-an-email', 'a@b']) {
      const result = bookingInput.safeParse({ ...valid, email });
      expect(result.success).toBe(false);
      expect(result.error?.issues[0]).toMatchObject({
        path: ['email'],
        message: 'Please enter a valid email address',
      });
    }
  });

  it.each([0, 9, 2.5, -1, '', 'abc', null])('rejects guests %p with a message for the guests field', (guests) => {
    const result = bookingInput.safeParse({ ...valid, guests });
    expect(result.success).toBe(false);
    expect(result.error?.issues[0]).toMatchObject({ path: ['guests'], message: 'Choose 1 to 8 guests' });
  });
});
