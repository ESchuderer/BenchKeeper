import { describe, expect, it } from 'vitest';
import { TASTINGS, findTasting } from '../../src/shared/tastings.js';

describe('tasting catalogue', () => {
  it('lists the three tastings from the brief', () => {
    expect(TASTINGS.map((t) => [t.id, t.title, t.priceEur, t.seats])).toEqual([
      ['riesling-evening', 'Riesling Evening', 25, 12],
      ['red-wine-cellar-tour', 'Red Wine Cellar Tour', 32, 8],
      ['winter-tasting', 'Winter Tasting', 28, 10],
    ]);
  });

  it('keeps the local start times from the brief', () => {
    expect(TASTINGS.map((t) => t.startsAt)).toEqual([
      '2026-11-06T18:00',
      '2026-11-14T15:00',
      '2026-12-05T17:00',
    ]);
  });

  it('finds a tasting by id and returns undefined for an unknown id', () => {
    expect(findTasting('winter-tasting')?.title).toBe('Winter Tasting');
    expect(findTasting('does-not-exist')).toBeUndefined();
  });
});
