# SDD ledger — plan: docs/superpowers/plans/2026-10-14-kieselbrunnen-tastings.md
Setup: /work is not a git repository; no commits requested. Git-based scripts (sdd-workspace, task-start, task-done, review-package) do not apply; this ledger is kept by hand. "Commit" steps are checkpoints (suite output recorded).
Setup: spec read: docs/superpowers/specs/2026-10-14-kieselbrunnen-tastings-design.md (sections 6 and 11 carry author rulings on closing rule, deployment, durability).
Pre-flight: shared interfaces are the Shared Interfaces block + Task 1 Produces; consumers in Tasks 2-8 read them. No conflicts found in the scan.
Ruling: no git commits; checkpoints replace commits — user did not request commits; /work not a repo — cost if wrong: history missing.
Task 1: complete (no commits; checkpoint — tests: npx vitest run → 11/11 pass; tsc client+server exit 0). Ruling: server tsconfig uses NodeNext, so relative imports in src/shared carry .js extensions — cost if wrong: none for tests.
Ruling: TypeScript 7.0.2 installed by npm (latest); typecheck passes with it — cost if wrong: swap to typescript@5 if tooling complains.
Task 2: complete (no commits; checkpoint — tests: npx vitest run → 25/25 pass incl. 14 booking store; server tsc ok). Ruling: "RED" for Task 2 was module-not-found, not a behaviour failure, because the whole module was new — cost if wrong: none.
Task 3: complete (no commits; checkpoint — tests: npx vitest run → staffAuth 5/5 pass; server tsc ok).
Task 3: complete (checkpoint — staffAuth 5/5).
Ruling: zero seats left answers 409 with "This tasting is fully booked." instead of "Only 0 seats left." — "Only 0 seats left" reads badly — cost if wrong: one string.
Ruling: malformed JSON answers 400 {error:"Invalid JSON."}; oversize 413 — plan left wording open — cost if wrong: one string.
Ruling: cancel route typed Request<{reference:string}> to satisfy strict params typing — cost if wrong: none.
Task 4: complete (checkpoint — tests: npx vitest run → 54/54 pass incl. 24 API; server tsc ok).
Task 5: complete (checkpoint — format+api 5/5 pass). Ruling: formatStartsAt uses Intl in UTC to show start as written — cost if wrong: none.
Task 6: complete (checkpoint — tests: npx vitest run → 65/65 pass; vite build OK).
Ruling: added tests/setup.ts (jest-dom matchers + RTL cleanup) and @testing-library/jest-dom — plan did not list them; without them the component tests cannot run — cost if wrong: none.
Ruling: fully-booked card shows one disabled "Fully booked" button and no separate badge (the label would appear twice) — cost if wrong: visual only.
Ruling: winery name in header is a link, not a heading; the page h1 is "Wine tastings" — cost if wrong: heading-role test wording.
Task 7: complete (checkpoint — tests: npx vitest run → 76/76 pass; client tsc ok). Ruling: removed a payment sentence I had written into the booking form — the brief says nothing about payment — cost if wrong: copy only.
Ruling: test "unknown tasting" routes to /tastings/nope/book (booking URL), the plan had /tastings/nope — cost if wrong: none.
Task 8: complete (checkpoint — tests: npx vitest run → 84/84 pass; both tsc exit 0). Ruling: staff seats line asserted with a pattern because date and seats share one line — cost if wrong: none.
Task 9: complete (checkpoint — npm test 84/84; npm run build exit 0; README written).
Task 10: partial — API end-to-end via Node fetch script PASSED (all listed API behaviours, pages return shell, asset 200). Browser screenshots NOT done: Chromium downloaded but needs system libs (libglib, libnss3, ...) and there is no root/sudo here. Ruling: visual check reported as not done rather than substituted.
Final review (fresh opus reviewer): no Critical. Triage:
Final: fixed booking spam — rate limit on POST bookings (10 per 15 min per IP) — test "limits booking attempts" RED→GREEN.
Final: fixed full card missing "0 seats left" (brief requires seat count) — HomePage test RED→GREEN.
Final: fixed empty start page with no message — HomePage test RED→GREEN.
Final: fixed sign-out failure shown as success — StaffPage test RED→GREEN.
Final: fixed zero-width-only names accepted (Review Focus item 3) — schema test RED→GREEN.
Final: minor (deferred): cancel double-click / no success status line.
Final: minor (deferred): error handler labels every 400 "Invalid JSON."; body-parser non-400 errors become 500.
Final: minor (deferred): unknown /assets paths return index.html with 200.
Final: minor (deferred): focus not moved to first server-side field error.
Final: minor (deferred): icons on error states not added (spec 8.7 deviation).
Final: minor (deferred): no per-page document title, no focus management on navigation.
Final: minor (deferred): no helmet / security headers (SameSite=Strict cookie and no inline scripts limit exposure).
Final: minor (deferred): repeated markup (guestsLabel twice, BackLink copied, alert box six times).
Final: Ruling: reviewer's "Declined to judge" items (visual look unseen, brand fit, in-memory bookings, Berlin offset near DST switch, npm versions) — stand as documented calls; visual check still not performed — cost if wrong: layout defects on phones.
Fix pass complete: booking rate limit (10/15min/IP) — api test RED→GREEN; full card "0 seats left" — HomePage test RED→GREEN; empty start page message — HomePage test RED→GREEN; sign-out failure keeps signed-in view with alert — StaffPage test RED→GREEN; zero-width-only name rejected — schema test RED→GREEN. Suite 92/92, both tsc exit 0, npm run build exit 0. Live probe: 11 quick bookings from one client → 5 accepted then 429 (after the e2e script's 5 posts, same window).
Ruling: ledger kept in /work/.superpowers (not deleted) because there is no git history to hold the record — cost if wrong: none.
Ruling: finishing-a-development-branch not run — no git repository, so there is no branch to merge or PR; the user decides delivery — cost if wrong: none.
