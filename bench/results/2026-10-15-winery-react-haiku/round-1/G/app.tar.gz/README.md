# Weingut Kieselbrunnen: tasting bookings

A small web app where guests book wine tastings online and staff see and cancel bookings.

- Guests: the start page lists the open tastings with seats left. Each tasting has a "Book <title>" link to a form (Name, Email, Guests 1 to 8). Booking shows a "Booking confirmed" page with the reference.
- Staff: `/staff` asks for the password from `STAFF_PASSWORD`. Signed in, staff see all bookings grouped by tasting and can cancel them, which frees the seats.

Stack: TypeScript, Express 5 (server and API), React 19 with React Router, React Hook Form with Zod (validation shared by client and server), Tailwind CSS v4, Vite.

## Running it

Requires Node.js 22.

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start
```

Open http://localhost:3000. `npm start` serves the guest pages, the staff page and the API from one process.

### Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | Port to listen on |
| `HOST` | `0.0.0.0` | Interface to bind to |
| `STAFF_PASSWORD` | unset | Staff sign-in password. When unset, staff sign-in is refused. |
| `TRUST_PROXY` | unset | Number of reverse-proxy hops to trust (e.g. `1`). Set this behind a proxy: it sets the client IP used for the sign-in rate limit and makes the staff cookie `Secure` when the proxy terminates HTTPS. |

## Things to know

- **Bookings are kept in memory.** Restarting the server clears every booking. This is deliberate for now (the app starts with no bookings and there is no database), but it means a restart or redeploy loses bookings. Store them in a file or a database before real guests rely on it.
- **Closing rule.** A tasting stops taking bookings once its start time has passed. Start times are read as Europe/Berlin local time. Closed tastings are hidden from the start page; their booking URL says the tasting has already taken place. Staff still see their bookings.
- **Staff sign-in** lasts 8 hours and is limited to 10 attempts per 15 minutes per client IP. Sessions are held in memory, so a restart signs staff out.
- The public booking-confirmation URL (`/bookings/<reference>`) shows the tasting, date, guests, total and reference. It does not show a name or email.

## Tests

```sh
npm test
npm run typecheck
```

Tests live in `tests/`: server units (booking store, staff auth), API tests against the Express app with supertest, and React tests with Testing Library for the home, booking, confirmation and staff pages.

## Layout

```
src/shared/    tastings catalogue, types, Zod schemas (used by client and server)
src/server/    booking store, staff auth, Express app, entry point
src/client/    React app: pages, components, API helper, formatting, theme
tests/         Vitest tests
docs/superpowers/   design spec and implementation plan
```
