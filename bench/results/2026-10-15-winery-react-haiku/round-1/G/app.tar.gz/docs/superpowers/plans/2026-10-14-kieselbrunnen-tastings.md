# Weingut Kieselbrunnen Tasting Booking Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A React web app where guests book wine tastings (seat-limited, validated) and staff sign in to see and cancel bookings, served by one Node process on `PORT`.

**Architecture:** One TypeScript repo. `src/shared` holds the catalogue, types and Zod schemas used by both sides. `src/server` is an Express 5 app built from injected parts (in-memory booking store, staff auth) so tests can construct it directly. `src/client` is a Vite-built React SPA with React Router, React Hook Form + Zod, and Tailwind CSS v4.

**Tech Stack:** TypeScript, Node 22, Express 5, React 19, React Router 7, Vite, React Hook Form, Zod, @hookform/resolvers, Tailwind CSS v4, cookie-parser, express-rate-limit, Vitest, React Testing Library, jsdom, supertest.

**Spec:** `docs/superpowers/specs/2026-10-14-kieselbrunnen-tastings-design.md`

## Global Constraints

- Node.js 22; `npm install`, `npm run build`, `npm start`. `npm start` serves everything on `PORT` (default `3000`).
- Staff password comes only from env `STAFF_PASSWORD`; unset means sign-in refused.
- Tastings and prices are exactly: Riesling Evening 2026-11-06 18:00 EUR 25 / 12 seats; Red Wine Cellar Tour 2026-11-14 15:00 EUR 32 / 8 seats; Winter Tasting 2026-12-05 17:00 EUR 28 / 10 seats.
- Guests field: integer 1 to 8. Name: 1 to 100 characters after trim. Email: valid format, max 254.
- Labels and buttons verbatim: "Name", "Email", "Guests", "Book", "Book <title>", "Password", "Sign in", "Cancel", "Booking confirmed", "<n> seats left", "Fully booked".
- No external network at runtime; no web fonts; interface in English.
- Bookings are in memory only.
- A tasting is closed for booking once its start time has passed; start times are read as Europe/Berlin local time (`isTastingOpen`). Closed tastings are hidden from the home page; their booking URL shows "This tasting has already taken place."
- Cookie `kb_staff` carries `Secure` when `req.secure` is true. `TRUST_PROXY` env (hop count) is optional and unset by default. `HOST` env defaults to `0.0.0.0`.
- `/work` is not a git repository and no commit was requested: the plan's commit steps are replaced by a checkpoint (run the suite and record the result). No commits are made.

## Review Focus

1. Two requests for the last seat at the same moment: exactly one succeeds; the other gets 409 with `fieldErrors.guests`; seats never go negative.
2. Guests submitted blank, `0`, `9`, `2.5`, or non-numeric: rejected with a message next to the Guests field, no request reaches the store.
3. Name of only spaces, or 101 characters; email with spaces, no `@`, or no domain: rejected next to the right field.
4. Public booking lookup `GET /api/bookings/:reference` never returns name or email.
5. Staff endpoints with no cookie, a made-up cookie, or after sign-out: 401; wrong password: 401 with no session cookie set; `STAFF_PASSWORD` unset: 503 and no login possible.

## File Structure

- `package.json`, `tsconfig.json` (client + shared), `tsconfig.server.json`, `vite.config.ts`, `vitest.config.ts`, `index.html`, `README.md`
- `src/shared/types.ts` — shared TypeScript types
- `src/shared/catalogue.ts` — the three tastings
- `src/shared/schemas.ts` — `bookingInputSchema` (Zod), `FIELD_MESSAGES`
- `src/server/bookingStore.ts` — seat arithmetic, booking create/lookup/cancel, grouping
- `src/server/staffAuth.ts` — password check, sessions
- `src/server/app.ts` — Express app factory: API routes, rate limit, static files
- `src/server/index.ts` — entry: reads env, listens on `PORT`
- `src/client/main.tsx`, `src/client/App.tsx` — bootstrap and routes
- `src/client/api.ts` — fetch helpers and `ApiError`
- `src/client/format.ts` — date, price, seats formatting
- `src/client/index.css` — Tailwind import and theme
- `src/client/components/Layout.tsx`, `TastingCard.tsx`, `FormField.tsx`
- `src/client/pages/HomePage.tsx`, `BookingPage.tsx`, `ConfirmationPage.tsx`, `StaffPage.tsx`, `NotFoundPage.tsx`
- `tests/server/bookingStore.test.ts`, `tests/server/staffAuth.test.ts`, `tests/server/api.test.ts`, `tests/shared/schemas.test.ts`
- `tests/client/format.test.ts`, `tests/client/HomePage.test.tsx`, `tests/client/BookingPage.test.tsx`, `tests/client/StaffPage.test.tsx`

## Shared Interfaces (defined in Task 1, used everywhere)

```ts
// src/shared/types.ts
export interface Tasting { id: string; title: string; startsAt: string; /* "2026-11-06T18:00" */ pricePerGuest: number; capacity: number }
export interface TastingWithSeats extends Tasting { seatsLeft: number; open: boolean /* start time not yet passed */ }
export interface BookingInput { name: string; email: string; guests: number }
export interface BookingSummary { reference: string; tastingId: string; tastingTitle: string; startsAt: string; guests: number; pricePerGuest: number; total: number }
export interface StaffBooking { reference: string; name: string; email: string; guests: number; createdAt: string }
export interface StaffTastingGroup { tasting: TastingWithSeats; bookings: StaffBooking[] }
export type FieldErrors = Partial<Record<'name' | 'email' | 'guests', string>>
export interface ApiErrorBody { error: string; fieldErrors?: FieldErrors }
```

---

### Task 1: Project scaffold and shared catalogue, types and schemas

**Files:**
- Create: `package.json`, `tsconfig.json`, `tsconfig.server.json`, `vite.config.ts`, `vitest.config.ts`, `index.html`
- Create: `src/shared/types.ts`, `src/shared/catalogue.ts`, `src/shared/schemas.ts`
- Test: `tests/shared/schemas.test.ts`

**Interfaces:**
- Consumes: nothing.
- Produces: the types above; `TASTINGS: Tasting[]` (exactly the three from Global Constraints, ids `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`); `bookingInputSchema: z.ZodType<BookingInput>`; `FIELD_MESSAGES` (the strings in the test below).

Scaffold: `"type": "module"`; scripts `dev`, `build` (`vite build && tsc -p tsconfig.server.json`), `start` (`node dist/server/index.js`), `test` (`vitest run`), `typecheck`. Dependencies as listed in Tech Stack, with `vitest`, `typescript`, `vite`, `@vitejs/plugin-react`, `@tailwindcss/vite`, `tailwindcss` in dev. Client tsconfig includes `src/client` and `src/shared`; server tsconfig emits `src/server` and `src/shared` to `dist/`. Vitest runs `tests/**/*.test.ts(x)`.

- [ ] **Step 1: Write the failing test**

```ts
// tests/shared/schemas.test.ts
import { describe, it, expect } from 'vitest';
import { bookingInputSchema, FIELD_MESSAGES } from '../../src/shared/schemas';

describe('bookingInputSchema', () => {
  const valid = { name: 'Anna Berg', email: 'anna@example.com', guests: 2 };

  it('accepts a valid booking', () => {
    expect(bookingInputSchema.safeParse(valid).success).toBe(true);
  });

  it('trims the name and email', () => {
    const r = bookingInputSchema.parse({ ...valid, name: '  Anna  ', email: ' a@b.de ' });
    expect(r.name).toBe('Anna');
    expect(r.email).toBe('a@b.de');
  });

  it.each([
    ['name', { name: '   ' }, FIELD_MESSAGES.nameRequired],
    ['name', { name: 'x'.repeat(101) }, FIELD_MESSAGES.nameTooLong],
    ['email', { email: '' }, FIELD_MESSAGES.emailRequired],
    ['email', { email: 'anna example.com' }, FIELD_MESSAGES.emailInvalid],
    ['email', { email: 'anna@' }, FIELD_MESSAGES.emailInvalid],
    ['guests', { guests: 0 }, FIELD_MESSAGES.guestsMin],
    ['guests', { guests: 9 }, FIELD_MESSAGES.guestsMax],
    ['guests', { guests: 2.5 }, FIELD_MESSAGES.guestsWhole],
    ['guests', { guests: Number.NaN }, FIELD_MESSAGES.guestsWhole],
  ])('rejects bad %s with its message', (field, patch, message) => {
    const r = bookingInputSchema.safeParse({ ...valid, ...patch });
    expect(r.success).toBe(false);
    const issue = r.error!.issues.find((i) => i.path[0] === field);
    expect(issue?.message).toBe(message);
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npx vitest run tests/shared/schemas.test.ts`
Expected: FAIL, module `src/shared/schemas` not found.

- [ ] **Step 3: Implement the scaffold, types, catalogue and schema**

`FIELD_MESSAGES` keys: `nameRequired` "Please enter your name.", `nameTooLong` "Your name can be at most 100 characters.", `emailRequired` "Please enter your email address.", `emailInvalid` "Please enter a valid email address.", `guestsRequired` "Choose how many guests.", `guestsMin` "Choose at least 1 guest.", `guestsMax` "You can book for up to 8 guests.", `guestsWhole` "Choose a whole number of guests.". `guests` is `z.number()` with a custom message for NaN (`guestsWhole`). Email uses Zod `.email()`, max 254. Writing the Zod chain and file layout is up to you.

- [ ] **Step 4: Run test and typecheck**

Run: `npx vitest run tests/shared/schemas.test.ts && npx tsc -p tsconfig.json --noEmit`
Expected: all PASS, no type errors.

- [ ] **Step 5: Checkpoint** — record the passing output; no commit (see Global Constraints).

---

### Task 2: Booking store

**Files:**
- Create: `src/server/bookingStore.ts`
- Test: `tests/server/bookingStore.test.ts`

**Interfaces:**
- Consumes: `Tasting`, `TastingWithSeats`, `BookingInput`, `BookingSummary`, `StaffTastingGroup` from `src/shared/types.ts`; `TASTINGS` from `src/shared/catalogue.ts`.
- Produces:

```ts
export interface BookingStore {
  listTastings(): TastingWithSeats[];
  getTasting(id: string): TastingWithSeats | undefined;
  createBooking(tastingId: string, input: BookingInput):
    | { ok: true; reference: string }
    | { ok: false; reason: 'unknown-tasting' }
    | { ok: false; reason: 'closed' }
    | { ok: false; reason: 'not-enough-seats'; seatsLeft: number };
  getBookingSummary(reference: string): BookingSummary | undefined;
  listBookingsGrouped(): StaffTastingGroup[];   // one group per tasting, in catalogue order
  cancelBooking(reference: string): boolean;
}
export function createBookingStore(options?: { tastings?: Tasting[]; random?: (n: number) => number; now?: () => Date }): BookingStore;
// Start time is "YYYY-MM-DDTHH:mm" in Europe/Berlin. Compute the UTC instant with Intl
// (Intl.DateTimeFormat with timeZone 'Europe/Berlin' to read the offset for that moment).
export function isTastingOpen(startsAt: string, now: Date): boolean;
```

`random` defaults to `crypto.randomInt`. `now` defaults to `() => new Date()`. `open` on each tasting is `isTastingOpen(startsAt, now())`. `createBooking` checks the closing rule before the seat check, so a closed tasting never reports seats. References: `KB-` + 6 chars from `23456789ABCDEFGHJKMNPQRSTUVWXYZ`, unique (regenerate on collision). `total = guests * pricePerGuest`. `listBookingsGrouped` returns bookings with `createdAt` ISO strings, sorted by createdAt.

- [ ] **Step 1: Write the failing tests**

```ts
// tests/server/bookingStore.test.ts (key cases; write each as its own it())
const tastings = [{ id: 't1', title: 'T', startsAt: '2026-11-06T18:00', pricePerGuest: 25, capacity: 3 }];
// listTastings: fresh store → seatsLeft 3
// createBooking ok, then listTastings → seatsLeft 1 after guests 2
// createBooking guests 2 when 1 left → { ok:false, reason:'not-enough-seats', seatsLeft:1 }, seats unchanged
// createBooking to 'nope' → { ok:false, reason:'unknown-tasting' }
// isTastingOpen('2026-11-06T18:00', new Date('2026-11-06T16:59:00Z')) → true (18:00 Berlin is 17:00 UTC)
// isTastingOpen('2026-11-06T18:00', new Date('2026-11-06T17:01:00Z')) → false
// isTastingOpen('2026-12-05T17:00', new Date('2026-12-05T15:59:00Z')) → true (CET, +01:00)
// createBooking on a tasting whose start has passed (now injected) → { ok:false, reason:'closed' }, seats untouched
// fill to 0; next booking refused
// cancelBooking(ref) → true, seats freed; cancelBooking again → false
// getBookingSummary(ref) → { tastingTitle:'T', guests:2, total:50, reference:ref } and has no name/email keys
// getBookingSummary('KB-NOPE00') → undefined
// reference format matches /^KB-[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{6}$/
// random that always returns 0 forces a collision → second booking gets a different reference (use a sequence of random values, first two equal, then different)
// listBookingsGrouped → one group per tasting even if empty; bookings contain name and email
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npx vitest run tests/server/bookingStore.test.ts`
Expected: FAIL, module not found.

- [ ] **Step 3: Implement `createBookingStore` in `src/server/bookingStore.ts`**

Keep bookings in a `Map<reference, StoredBooking>`. Seat check and insert happen in one synchronous method with no `await` between them (this is the no-overbooking guarantee; say so in a comment). Use `crypto.randomInt` as the default `random`.

- [ ] **Step 4: Run test to verify it passes**

Run: `npx vitest run tests/server/bookingStore.test.ts`
Expected: all PASS.

- [ ] **Step 5: Checkpoint** — record output.

---

### Task 3: Staff authentication

**Files:**
- Create: `src/server/staffAuth.ts`
- Test: `tests/server/staffAuth.test.ts`

**Interfaces:**
- Consumes: nothing from other tasks.
- Produces:

```ts
export const STAFF_COOKIE = 'kb_staff';
export interface StaffAuth {
  readonly configured: boolean;            // false when password is undefined or empty
  checkPassword(candidate: string): boolean;
  createSession(): string;                 // returns opaque token
  isValidSession(token: string | undefined): boolean;
  endSession(token: string | undefined): void;
}
export function createStaffAuth(options: { password: string | undefined; now?: () => number; sessionMs?: number /* default 8h */ }): StaffAuth;
```

`checkPassword` compares SHA-256 digests with `crypto.timingSafeEqual` and returns false if not configured. Tokens: `crypto.randomBytes(32).toString('base64url')`, stored in a `Map<token, expiresAt>`; expired tokens are invalid.

- [ ] **Step 1: Write the failing tests**

```ts
// key cases
// createStaffAuth({password:'secret'}).checkPassword('secret') → true
// checkPassword('Secret') / '' / 'secret ' → false
// createStaffAuth({password: undefined}).configured → false, checkPassword('') → false
// createStaffAuth({password: ''}).configured → false
// createSession() → isValidSession(token) true; isValidSession('made-up') false; isValidSession(undefined) false
// endSession(token) → isValidSession(token) false
// with now advanced past sessionMs → isValidSession false
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npx vitest run tests/server/staffAuth.test.ts`
Expected: FAIL, module not found.

- [ ] **Step 3: Implement `createStaffAuth` in `src/server/staffAuth.ts`**

- [ ] **Step 4: Run test to verify it passes**

Run: `npx vitest run tests/server/staffAuth.test.ts`
Expected: all PASS.

- [ ] **Step 5: Checkpoint** — record output.

---

### Task 4: HTTP API

**Files:**
- Create: `src/server/app.ts`, `src/server/index.ts`
- Test: `tests/server/api.test.ts`

**Interfaces:**
- Consumes: `BookingStore` (Task 2), `StaffAuth` and `STAFF_COOKIE` (Task 3), `bookingInputSchema` and `FIELD_MESSAGES` (Task 1), shared types.
- Produces: `export function createApp(deps: { store: BookingStore; staffAuth: StaffAuth; staticDir?: string; loginLimit?: number /* default 10 */; loginWindowMs?: number /* default 15 min */ }): Express`. `index.ts` reads `PORT` (default 3000) and `STAFF_PASSWORD`, logs a warning when the password is unset, builds the app with `staticDir` set to `dist/client` (resolved relative to the compiled file), and listens.

Routes exactly as in the design section 8.6. Rules:
- `POST /api/tastings/:id/bookings`: validate body with `bookingInputSchema.safeParse`; on failure 400 `{ error: 'Please check the highlighted fields.', fieldErrors }` where each field's first message is used. Unknown tasting 404 `{ error: 'Tasting not found.' }`. Closed (`reason: 'closed'`) 409 `{ error: 'This tasting has already taken place.' }`. Not enough seats 409 `{ error: 'Not enough seats left.', fieldErrors: { guests: 'Only N seats left.' } }` (use "1 seat left" when N is 1). Success 201 with `BookingSummary`.
- `GET /api/bookings/:reference`: 404 `{ error: 'We could not find this booking.' }` when unknown.
- `POST /api/staff/session`: rate limiter (express-rate-limit, `loginLimit` per `loginWindowMs`, JSON error body). If `!staffAuth.configured` → 503 `{ error: 'Staff sign-in is not configured.' }`. Wrong password → 401 `{ error: 'Incorrect password.' }`, no cookie. Correct → `Set-Cookie: kb_staff=<token>; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`, plus `Secure` when `req.secure`; 204.
- App setup: `app.set('trust proxy', ...)` from the `TRUST_PROXY` option (a number of hops; unset means `false`). `index.ts` parses `TRUST_PROXY` and `HOST` (default `0.0.0.0`) and passes them in.
- `DELETE /api/staff/session`: endSession, clear cookie, 204.
- `GET /api/staff/bookings` and `DELETE /api/staff/bookings/:reference`: require valid session (`cookie-parser`); otherwise 401 `{ error: 'Please sign in.' }`. DELETE: 204 or 404.
- Static: serve `staticDir` and fall back to `index.html` for non-`/api` GET requests (so deep links like `/staff` work). Express 5 path syntax: use `app.get('/{*splat}', ...)`.
- Unknown `/api/*` → 404 JSON. Malformed JSON → 400 JSON, not an HTML stack trace.

- [ ] **Step 1: Write the failing tests (supertest against `createApp` with a store built on a one-tasting catalogue and `staffAuth` with password `'pw'`)**

```ts
// key assertions
// GET /api/tastings → 200, array with seatsLeft
// POST booking {name:'A', email:'a@b.de', guests:2} → 201, body.total === 50, body.reference matches /^KB-/
// POST booking guests 9 → 400, fieldErrors.guests === FIELD_MESSAGES.guestsMax
// POST booking name '' email 'x' → 400, both fieldErrors present
// POST booking too many guests (capacity exceeded) → 409, fieldErrors.guests === 'Only 1 seat left.' (given 1 left)
// POST to unknown tasting → 404
// GET /api/bookings/:ref → 200, body has no name/email keys
// GET /api/bookings/KB-NOPE00 → 404
// POST /api/staff/session {password:'wrong'} → 401, no set-cookie
// POST /api/staff/session {password:'pw'} → 204, set-cookie contains HttpOnly and SameSite=Strict
// GET /api/staff/bookings without cookie → 401; with cookie → 200 grouped, includes name and email
// DELETE /api/staff/bookings/:ref with cookie → 204, then tasting seatsLeft increases by the guests
// DELETE after cancel → 404
// DELETE /api/staff/session then GET /api/staff/bookings with old cookie → 401
// app built with password undefined: POST /api/staff/session → 503
// 11th login attempt within window → 429
// POST booking on a closed tasting (injected now after its start) → 409, error 'This tasting has already taken place.'
// login over HTTPS-marked request (X-Forwarded-Proto: https with trust proxy 1) → Set-Cookie contains 'Secure'; without → does not
// GET /api/tastings returns "open" on each tasting
// GET /staff (deep link) with staticDir containing index.html → 200 html
// malformed JSON body → 400 JSON
```

- [ ] **Step 2: Run test to verify it fails**

Run: `npx vitest run tests/server/api.test.ts`
Expected: FAIL, module not found.

- [ ] **Step 3: Implement `createApp` in `src/server/app.ts` and the entry in `src/server/index.ts`**

Use `express.json({ limit: '10kb' })`, `cookieParser()`, and a small `requireStaff` middleware. The static `index.html` fallback is skipped when the request path starts with `/api` and when `staticDir` is undefined.

- [ ] **Step 4: Run test to verify it passes**

Run: `npx vitest run tests/server/api.test.ts`
Expected: all PASS.

- [ ] **Step 5: Checkpoint** — record output, then run `npm run build` (server part compiles).

---

### Task 5: Client API helper and formatting

**Files:**
- Create: `src/client/api.ts`, `src/client/format.ts`
- Test: `tests/client/format.test.ts`

**Interfaces:**
- Consumes: shared types and the endpoints in Task 4.
- Produces:

```ts
// src/client/api.ts
export class ApiError extends Error { status: number; fieldErrors?: FieldErrors }
export function listTastings(): Promise<TastingWithSeats[]>;
export function getTasting(id: string): Promise<TastingWithSeats>;     // throws ApiError status 404 when unknown
export function createBooking(tastingId: string, input: BookingInput): Promise<BookingSummary>;
export function getBookingSummary(reference: string): Promise<BookingSummary>;
export function staffSignIn(password: string): Promise<void>;
export function staffSignOut(): Promise<void>;
export function listStaffBookings(): Promise<StaffTastingGroup[]>;   // throws ApiError 401 when signed out
export function cancelStaffBooking(reference: string): Promise<void>;
// src/client/format.ts
export function formatStartsAt(startsAt: string): string;  // e.g. "Fri 6 Nov 2026, 18:00"; use Intl with timeZone 'UTC' on startsAt + 'Z' so no shift
export function formatEur(amount: number): string;         // "EUR 25"
export function seatsLabel(n: number): string;             // "12 seats left" / "1 seat left"
```

All functions use `fetch` with `credentials: 'same-origin'`, send/parse JSON, and throw `ApiError` with the server's `error` message on non-2xx.

- [ ] **Step 1: Write the failing tests** — `formatStartsAt('2026-11-06T18:00')` contains `6 Nov 2026` and `18:00`; `formatEur(25)` === `'EUR 25'`; `seatsLabel(1)` === `'1 seat left'`, `seatsLabel(12)` === `'12 seats left'`; `createBooking` with a stubbed `fetch` returning 409 rejects with `ApiError` whose `fieldErrors.guests` is set (stub `globalThis.fetch` with `vi.fn`; Node environment).

- [ ] **Step 2: Run test to verify it fails** — `npx vitest run tests/client/format.test.ts`; expected FAIL.

- [ ] **Step 3: Implement both files.**

- [ ] **Step 4: Run test to verify it passes** — expected PASS.

- [ ] **Step 5: Checkpoint** — record output.

---

### Task 6: Layout, theme, and home page

**Files:**
- Create: `src/client/index.css`, `src/client/components/Layout.tsx`, `src/client/components/TastingCard.tsx`, `src/client/pages/HomePage.tsx`, `src/client/App.tsx`, `src/client/main.tsx`
- Test: `tests/client/HomePage.test.tsx`

**Interfaces:**
- Consumes: `listTastings` (Task 5), `formatStartsAt`, `formatEur`, `seatsLabel` (Task 5), shared types.
- Produces: `<Layout>` (header with "Weingut Kieselbrunnen", a nav link to "Home"; children in a main landmark), `<TastingCard tasting={TastingWithSeats} />` (renders title, date and time, price, seats label; the button "Book <title>" links to `/tastings/<id>/book`; when `seatsLeft === 0` it renders a disabled button "Fully booked" instead and marks the card), `HomePage` (fetches the list, shows loading text, an error alert on failure, and the cards for tastings with `open: true` only), `App` (routes: `/` Home, `/tastings/:id/book` Booking, `/bookings/:reference` Confirmation, `/staff` Staff, `*` NotFound; the Booking/Confirmation/Staff/NotFound routes are placeholders in this task that Tasks 7 and 8 replace).

Theme in `index.css` via Tailwind v4 `@theme`: colors `wine` (deep red, headings and primary buttons), `gold` (accent), `cream` (background), `ink` (body text); font `serif` (Georgia stack) for headings. Primary button: wine background, cream text, visible focus ring. Layout is mobile first: single column, `max-w-4xl`, cards stack on phones and go to a 3-column grid from `md`.

- [ ] **Step 1: Write the failing test** (`// @vitest-environment jsdom` pragma; stub `fetch` to return the three tastings with seat counts 12, 8 and 0 for the Winter one... use seats 12, 8, 0)

```tsx
// renders heading "Weingut Kieselbrunnen"
// renders "Riesling Evening", "Red Wine Cellar Tour", "Winter Tasting"
// renders text "12 seats left", "8 seats left"
// link named "Book Riesling Evening" has href "/tastings/riesling-evening/book"
// Winter Tasting shows "Fully booked" and no link named "Book Winter Tasting"
// fetch failure renders role "alert"
```

Wrap render in `MemoryRouter`.

- [ ] **Step 2: Run test to verify it fails** — `npx vitest run tests/client/HomePage.test.tsx`; expected FAIL.

- [ ] **Step 3: Implement the files.** `main.tsx` uses `createRoot` and `BrowserRouter`.

- [ ] **Step 4: Run test to verify it passes**; then run `npm run build` (client build must succeed) — expected PASS and a built `dist/client`.

- [ ] **Step 5: Checkpoint** — record output.

---

### Task 7: Booking form and confirmation pages

**Files:**
- Create: `src/client/components/FormField.tsx`, `src/client/pages/BookingPage.tsx`, `src/client/pages/ConfirmationPage.tsx`, `src/client/pages/NotFoundPage.tsx`
- Modify: `src/client/App.tsx` (wire the real pages, replace placeholders)
- Test: `tests/client/BookingPage.test.tsx`

**Interfaces:**
- Consumes: `getTasting`, `createBooking`, `getBookingSummary` (Task 5); `bookingInputSchema` (Task 1); `formatStartsAt`, `formatEur`, `seatsLabel` (Task 5); `ApiError`.
- Produces: `<FormField id label error children>` — renders the label, the control, and `<p id="{id}-error" role="alert">` with the message, linked by `aria-describedby`. `BookingPage` (route param `id`): loads the tasting; "Tasting not found" with a link to `/` for 404; "This tasting has already taken place." with a link back when `open` is false; "Fully booked" with a link back when seats are 0; otherwise a React Hook Form with `zodResolver(bookingInputSchema)`, fields **Name** (text), **Email** (email), **Guests** (select, options 1..min(8, seatsLeft), default 1), button **Book** (disabled and reads "Booking…" while submitting). Server 400 field errors are set with `setError`; a server 409 sets `guests` error and reloads the tasting for fresh seats; other errors show in a top alert. On 201 navigate to `/bookings/<reference>`. `ConfirmationPage` loads `getBookingSummary(reference)` and shows heading "Booking confirmed", tasting title, date and time, guests, total (`formatEur`), and the reference. Unknown reference → "We could not find this booking." with a link home. `NotFoundPage` → heading "Page not found" with a link home.

- [ ] **Step 1: Write the failing tests** (jsdom; stub `fetch` per URL; `MemoryRouter` with routes `/tastings/:id/book`, `/bookings/:reference`, `/`)

```tsx
// shows labelled fields "Name", "Email", "Guests" and button "Book"
// Guests options are 1..8 when 12 seats left, and 1..3 when 3 seats left
// submitting empty form shows "Please enter your name." next to Name and "Please enter your email address." next to Email (role alert within the field)
// submitting Email "anna example.com" shows "Please enter a valid email address." next to Email
// successful submit posts JSON {name, email, guests} and shows the confirmation at /bookings/KB-... → heading "Booking confirmed", "EUR 50"
// server 409 shows "Only 1 seat left." next to Guests
// unknown tasting shows "Tasting not found"
// fully booked tasting shows "Fully booked" and no "Book" button
```

- [ ] **Step 2: Run test to verify it fails** — `npx vitest run tests/client/BookingPage.test.tsx`; expected FAIL.

- [ ] **Step 3: Implement the pages, FormField and the App wiring.** Use `reset`-free flow; the form keeps user input on error.

- [ ] **Step 4: Run test to verify it passes** — expected PASS.

- [ ] **Step 5: Checkpoint** — record output.

---

### Task 8: Staff page

**Files:**
- Create: `src/client/pages/StaffPage.tsx`
- Modify: `src/client/App.tsx` (wire the staff route)
- Test: `tests/client/StaffPage.test.tsx`

**Interfaces:**
- Consumes: `staffSignIn`, `staffSignOut`, `listStaffBookings`, `cancelStaffBooking` (Task 5); `FormField` (Task 7); `formatStartsAt`, `seatsLabel`, `formatEur` not needed.
- Produces: `StaffPage`: on mount calls `listStaffBookings`; on `ApiError` 401 shows the sign-in form (heading "Staff sign in", field **Password** type password, button **Sign in**, errors "Incorrect password." or "Staff sign-in is not configured." from the server message, shown in the alert next to the field). Signed in: heading "Bookings", a "Sign out" button, then per tasting group: title, `formatStartsAt`, `seatsLabel(tasting.seatsLeft)`, and a table or list (name, email, guests, reference, **Cancel** button). `Cancel` calls `window.confirm('Cancel booking <reference> for <name>?')`; if confirmed, `cancelStaffBooking` then reloads the list. Empty group → "No bookings yet." Group list on phones stacks each booking as a card; from `md` a table.

- [ ] **Step 1: Write the failing tests**

```tsx
// signed out (listStaffBookings 401) → heading "Staff sign in", field "Password", button "Sign in"
// wrong password (sign-in 401 'Incorrect password.') → shows "Incorrect password." and no bookings
// correct password → shows group "Riesling Evening" with booking name, email, guests, reference
// empty group shows "No bookings yet."
// Cancel: window.confirm stubbed true → DELETE called with reference, list refreshed without the booking
// Cancel: confirm false → no DELETE call
```

- [ ] **Step 2: Run test to verify it fails** — expected FAIL.

- [ ] **Step 3: Implement `StaffPage` and wire the route.**

- [ ] **Step 4: Run test to verify it passes** — expected PASS.

- [ ] **Step 5: Checkpoint** — record output.

---

### Task 9: Full suite, production build, README

**Files:**
- Create: `README.md`

**Interfaces:**
- Consumes: everything above.
- Produces: a README covering install, build, run, `PORT`, `STAFF_PASSWORD`, the in-memory caveat (restart clears bookings), and the test commands.

- [ ] **Step 1: Run the full suite** — `npm test`; expected: all test files PASS.

- [ ] **Step 2: Run the production build from clean** — `rm -rf dist && npm run build`; expected: exit 0, `dist/client/index.html` and `dist/server/index.js` exist.

- [ ] **Step 3: Write README.md** with the sections above.

- [ ] **Step 4: Checkpoint** — record the suite and build output.

---

### Task 10: Verification in the running app

**Files:** none modified unless a defect is found (then fix and re-run the relevant task's tests first).

**Interfaces:** consumes the built app.

- [ ] **Step 1: Start the app**: `STAFF_PASSWORD=test-pass PORT=3000 npm start` (background); expected: listening log on 3000.
- [ ] **Step 2: Exercise the API with curl** — list tastings; book 8 guests on Red Wine Cellar Tour (8 seats) → 201; book 1 more → 409 with `Only 0 seats left` wording not reached: expect "Not enough seats left." because 0 remain — confirm response; sign in with `test-pass` → 204; list bookings with the cookie; cancel one → 204; list tastings again shows seats freed. Expected outputs recorded.
- [ ] **Step 3: Check the HTML shell** — `curl /`, `curl /staff`, `curl /bookings/KB-XXXXXX` return the index HTML (200).
- [ ] **Step 4: Visual check at phone width** — if a headless Chromium is available (try `npx playwright install chromium`; if the download is blocked, report that and skip), screenshot `/`, `/tastings/winter-tasting/book` and `/staff` at 390px width and look at them. If not available, say so explicitly in the final report.
- [ ] **Step 5: Stop the server** and record the results.

---

### Task 11: Independent review

**Files:** none; the review produces findings.

- [ ] **Step 1: Dispatch one fresh reviewer** (general-purpose subagent) with the spec, this plan's Review Focus and Global Constraints, and the repo path. It checks spec coverage, the five Review Focus items, and the code quality. It must not edit files.
- [ ] **Step 2: Fix every confirmed finding** with a failing test first where it is a behaviour defect, then re-run `npm test` and `npm run build`.
- [ ] **Step 3: Final checkpoint** — run `npm test` and `npm run build` and record both outputs.

---

## Self-Review Notes (author)

- Spec coverage: G1 → Task 6; G2 → Tasks 4, 7; G3 → Tasks 2, 4; G4 → Tasks 1, 4, 7; G5 → Tasks 3, 4, 8; G6 → Tasks 6, 7, 8, 10; G7 → Global Constraints and Tech Stack; G8 → Tasks 1, 9, 10.
- Review Focus items map to: 1 → Tasks 2, 4 tests; 2 → Tasks 1, 4, 7; 3 → Tasks 1, 4; 4 → Task 4; 5 → Tasks 3, 4.
- Names consistent: `createBookingStore`, `createStaffAuth`, `STAFF_COOKIE`, `createApp`, `ApiError`, `bookingInputSchema`, `FIELD_MESSAGES`.
