# Weingut Kieselbrunnen: Tasting Booking App — Design

Date: 2026-10-14
Status: Approved by the requester's written brief (the request itself is the approval; choices marked **[my call]** were made by the author, not by the requester).

## 1. Intent and why

Weingut Kieselbrunnen is a small family winery. Guests should be able to book wine tastings online without phoning the winery, and staff should be able to see who is coming and cancel bookings when needed. The app should look like the winery's own website, not like a generic booking tool.

## 2. Goals

- G1. Guests see the three upcoming tastings with title, date and time, price per guest and "<n> seats left".
- G2. Guests book a tasting for 1 to 8 guests with name and email, and receive a confirmation with heading "Booking confirmed", tasting, number of guests, total price and booking reference.
- G3. A booking can never take more seats than are left.
- G4. Invalid input is rejected with an error shown next to the field it concerns.
- G5. Staff sign in with a password from `STAFF_PASSWORD`, see all bookings grouped by tasting, and cancel bookings; cancelling frees the seats.
- G6. The interface looks polished and coherent, shows clear error, success and fully-booked states, and works on a phone.
- G7. Built with React, using established maintained libraries for server, routing, forms and styling.
- G8. Runs with `npm install`, `npm run build`, `npm start`, serving on `PORT` (default 3000). English only.

## 3. Non-goals

- No payments. The total is shown, not charged.
- No guest accounts, no login for guests, no email sending.
- No admin editing of tastings (the three tastings are fixed in code).
- No external services (no database, no CDN fonts, no analytics).
- No internationalisation.

## 4. Anti-goals (would make this a failure even if it technically works)

- Overbooking, even by a race between two guests booking the last seat.
- Staff password checked on the client only, or staff data visible without signing in.
- Guest email addresses or names exposed to people who merely know a booking reference.
- A page that looks like a developer demo (default fonts, unstyled forms, raw error text).

## 5. Constraints

- Node.js 22. Work happens inside this folder (`/work`).
- Port from `PORT`, default 3000. One process serves both the API and the React app.
- Bookings live in memory **[my call]**: the brief allows memory or a local file. Memory is chosen because the brief says the app "starts with no bookings", which a persisted file would contradict on restart. Restarting the server clears bookings; this is documented in the README and is the first thing the requester should decide (see section 11).
- No external network calls at runtime.
- Listens on `HOST` (default `0.0.0.0`, so it works in a container) and `PORT` (default 3000) **[my call]**.
- Reverse proxy: optional `TRUST_PROXY` env (a hop count, e.g. `1`) sets Express `trust proxy`; unset means no proxy trust **[my call]**. This decides the client IP used for the staff login rate limit and whether `req.secure` is true.

## 6. The tastings (fixed catalogue)

| id | Title | Starts (local winery time) | Price per guest (EUR) | Seats |
|---|---|---|---|---|
| `riesling-evening` | Riesling Evening | 2026-11-06 18:00 | 25 | 12 |
| `red-wine-cellar-tour` | Red Wine Cellar Tour | 2026-11-14 15:00 | 32 | 8 |
| `winter-tasting` | Winter Tasting | 2026-12-05 17:00 | 28 | 10 |

Times are shown as written, without time-zone conversion for display **[my call]**: the winery's local time is the only time that matters to guests. For the closing rule below, start times are read as **Europe/Berlin** local time **[my call]**; the brief gives no location, and the German-style winery name, euro prices and German-speaking setting make this the most likely reading.

**Closing rule [my call]:** a tasting stops taking bookings once its start time has passed. The home page lists only tastings that have not started yet. Visiting a closed tasting's booking URL shows "This tasting has already taken place." Staff still see its bookings.

## 7. How it is built (my choices, within the brief)

**[my call]** Stack:
- Language: TypeScript throughout.
- Server: Express 5 (serves `/api/*` and the built React app).
- Client: React 19 + Vite, built to static files.
- Routing: React Router (client routes).
- Forms: React Hook Form with Zod validation (`@hookform/resolvers/zod`). The same Zod schemas are used on the server, so the rules live in one place.
- Styling: Tailwind CSS v4 (Vite plugin).
- Security helpers: `cookie-parser` for the staff session cookie, `express-rate-limit` on the staff login.
- Tests: Vitest; React Testing Library for the client; supertest for the API.

**[my call]** Architecture: `src/shared` (catalogue and Zod schemas used by both sides), `src/server` (store, staff auth, routes, `app` factory and `index` entry), `src/client` (pages, components, API helper).

## 8. Behaviour in detail

### 8.1 Seats

- `seatsLeft(tasting) = capacity − sum(guests of active bookings for that tasting)`.
- A booking is accepted only if `guests <= seatsLeft`, checked and inserted in one synchronous step on the server (Node runs JS on one thread, so there is no race).
- Cancelling removes the booking and frees its seats immediately.

### 8.2 Guest booking form (`/tastings/:id/book`)

- Fields, in order: **Name** (text, required, 1–100 characters after trimming), **Email** (required, valid email format, max 254), **Guests** (select, 1 to 8, options limited to `min(8, seatsLeft)`).
- Button **Book**. While submitting, the button is disabled and reads "Booking…".
- Errors show under the field they concern, linked with `aria-describedby`. A server error that is not field-specific shows in an alert above the form.
- If the server says the seats are gone (409), the Guests field shows "Only N seats left" and the options are refreshed.
- A fully-booked tasting: the booking form shows "Fully booked" and no form. The Book link on the home page becomes a disabled "Fully booked" button.
- Unknown tasting id: a "Tasting not found" page with a link back to the list.
- Heading shows the tasting title, date and time, price and seats left.

### 8.3 Confirmation (`/bookings/:reference`)

- Heading **Booking confirmed**, then tasting title, date and time, number of guests, total price (guests × price, e.g. "EUR 50"), and booking reference (e.g. `KB-7K2M9Q`).
- Shows only tasting, guests, total and reference. Name and email are **not** returned for this public URL (anti-goal 4.2).
- Unknown reference: "We could not find this booking" with a link back to the list.

### 8.4 Staff (`/staff`)

- Signed out: heading "Staff sign in", field **Password** (type password), button **Sign in**. Wrong password: "Incorrect password." If `STAFF_PASSWORD` is not set, sign-in is refused with a clear message in the page ("Staff sign-in is not configured.") — fail closed.
- Password compared with `crypto.timingSafeEqual`. Login attempts rate-limited (10 per 15 minutes per IP) **[my call]**.
- On success: a random session token in an `HttpOnly`, `SameSite=Strict` cookie, valid for 8 hours **[my call]**. The cookie also carries `Secure` whenever the request is HTTPS (`req.secure`, which respects `TRUST_PROXY`), so it is never sent in clear text when the app sits behind TLS, while local plain-HTTP use still works. Sessions are held in memory.
- Signed in: a "Sign out" button; bookings grouped by tasting, each group with title, date and time and "<n> seats left". Each booking row: name, email, guests, reference, and a **Cancel** button. Clicking Cancel asks for confirmation (`window.confirm`) **[my call]** to avoid accidental cancellations, then removes the booking from the list.
- Empty tasting: "No bookings yet."
- Unauthenticated API calls return 401 and the page returns to the sign-in form.

### 8.5 Home (`/`)

- Heading and short intro line. Three cards, one per tasting: title, date and time, price per guest, "<n> seats left", and **Book <title>** button linking to the booking form. Fully booked cards are visibly marked.

### 8.6 API

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/tastings` | — | List tastings with `seatsLeft` and `open` (start time not yet passed) |
| GET | `/api/tastings/:id` | — | One tasting with `seatsLeft` and `open` |
| POST | `/api/tastings/:id/bookings` | — | Body `{name, email, guests}`. 201 with booking summary. 400 with `fieldErrors`. 404 unknown tasting. 409 with `error: "This tasting has already taken place."` when closed. 409 with `fieldErrors.guests` when too many guests. |
| GET | `/api/bookings/:reference` | — | Public summary: tasting, guests, total, reference (no name/email) |
| POST | `/api/staff/session` | — | Body `{password}`. Sets session cookie. 401 wrong password. 503 not configured. Rate-limited. |
| DELETE | `/api/staff/session` | — | Sign out |
| GET | `/api/staff/bookings` | staff | Grouped by tasting, including name and email |
| DELETE | `/api/staff/bookings/:reference` | staff | Cancel. 204, or 404. |

Errors are JSON `{ "error": string, "fieldErrors"?: { name?, email?, guests? } }`.

### 8.7 Visual design **[my call]**

- Palette: warm cream background, deep wine red for headings and primary buttons, muted gold accent, dark text on cream. Contrast meets WCAG AA for body text.
- Typography: serif for headings (Georgia-based stack), system sans for body. No web-font downloads.
- Header with the winery name; the app is a single column, max width about 960px, mobile first.
- States: error (red border and text with icon), success (green-tinted panel), fully booked (grey badge).
- Focus rings visible on all interactive elements.

### 8.8 Booking reference

- Format `KB-` followed by 6 characters from the alphabet `23456789ABCDEFGHJKMNPQRSTUVWXYZ` (no look-alike characters), generated with `crypto.randomInt`, unique within the store.

## 9. Testing approach

- Server: store unit tests (seat arithmetic, overbooking refused, cancel frees seats, reference uniqueness), API tests via supertest (validation errors, 404, 409, public lookup hides PII, staff auth required, wrong password, rate limit present, cancel).
- Client: component/page tests with React Testing Library for: home list and fully-booked state, booking form validation messages next to fields, successful booking navigates to confirmation, 409 refresh, staff sign-in and grouped list, cancel.
- Verification: build, run the server, exercise the flow with HTTP calls, and check the pages render at phone width (screenshot via a headless browser if one is available).

## 10. What is left to the builder

- Exact component breakdown, file names beyond those in section 7, and the Tailwind theme values, within section 8.7.
- Exact wording of minor messages not quoted above (keep them plain and specific).

## 11. Open calls I made (for review)

1. In-memory bookings; restart clears them.
2. Times shown as written, no time zones.
3. Staff session 8 hours, in-memory; login rate limit 10 per 15 minutes.
4. Cancel asks for a browser confirmation.
5. Confirmation page does not show name or email.
6. Fail-closed staff login when `STAFF_PASSWORD` is unset.
7. Brand: the brief asks for "the winery's own site" but gives no logo, colours, fonts or URL. Section 8.7 is my design, not a match to an existing brand.
8. Restart durability: because bookings are in memory, a crash or redeploy loses them. This is the single biggest thing to decide before real guests use it. A JSON file in a data directory would fix it at modest cost.
9. Closing rule: bookings close at start time, read as Europe/Berlin time (see section 6).
10. Deployment: `HOST` defaults to all interfaces; `TRUST_PROXY` is unset by default; `Secure` cookies follow `req.secure`.
