import type {
  ApiErrorBody,
  BookingInput,
  BookingSummary,
  FieldErrors,
  StaffTastingGroup,
  TastingWithSeats,
} from '../shared/types.js';

export class ApiError extends Error {
  readonly status: number;
  readonly fieldErrors?: FieldErrors;

  constructor(status: number, message: string, fieldErrors?: FieldErrors) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

async function request<T>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  if (init.body !== undefined) headers['Content-Type'] = 'application/json';

  const res = await fetch(path, {
    method: init.method ?? 'GET',
    credentials: 'same-origin',
    headers,
    body: init.body === undefined ? undefined : JSON.stringify(init.body),
  });
  if (res.status === 204) return undefined as T;

  const body = (await res.json().catch(() => ({}))) as Partial<ApiErrorBody>;
  if (!res.ok) {
    throw new ApiError(res.status, body.error ?? 'Something went wrong. Please try again.', body.fieldErrors);
  }
  return body as T;
}

export const listTastings = () => request<TastingWithSeats[]>('/api/tastings');

export const getTasting = (id: string) => request<TastingWithSeats>(`/api/tastings/${encodeURIComponent(id)}`);

export const createBooking = (tastingId: string, input: BookingInput) =>
  request<BookingSummary>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
    method: 'POST',
    body: input,
  });

export const getBookingSummary = (reference: string) =>
  request<BookingSummary>(`/api/bookings/${encodeURIComponent(reference)}`);

export const staffSignIn = (password: string) =>
  request<void>('/api/staff/session', { method: 'POST', body: { password } });

export const staffSignOut = () => request<void>('/api/staff/session', { method: 'DELETE' });

export const listStaffBookings = () => request<StaffTastingGroup[]>('/api/staff/bookings');

export const cancelStaffBooking = (reference: string) =>
  request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' });
