import type { ReactNode } from 'react';

export interface FieldA11y {
  id: string;
  'aria-describedby'?: string;
  'aria-invalid': boolean;
}

/** Label, control and error message, linked with aria-describedby so the message is announced with its field. */
export function FormField({
  id,
  label,
  error,
  children,
}: {
  id: string;
  label: string;
  error?: string;
  children: (a11y: FieldA11y) => ReactNode;
}) {
  const errorId = `${id}-error`;
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium text-ink">
        {label}
      </label>
      {children({
        id,
        'aria-describedby': error ? errorId : undefined,
        'aria-invalid': Boolean(error),
      })}
      {error && (
        <p id={errorId} role="alert" className="text-sm font-medium text-danger">
          {error}
        </p>
      )}
    </div>
  );
}
