import type { ReactNode } from 'react';
import { Link } from 'react-router';

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b border-wine/15 bg-parchment">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-5 py-5">
          <Link to="/" className="font-serif text-xl tracking-wide text-wine no-underline sm:text-2xl">
            Weingut Kieselbrunnen
          </Link>
          <span className="hidden text-sm text-muted sm:block">Family winery</span>
        </div>
      </header>

      <main className="mx-auto w-full max-w-4xl flex-1 px-5 py-10">{children}</main>

      <footer className="border-t border-wine/15 bg-parchment">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-2 px-5 py-6 text-sm text-muted">
          <span>© Weingut Kieselbrunnen</span>
          <Link to="/staff" className="text-wine underline-offset-4 hover:underline">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}
