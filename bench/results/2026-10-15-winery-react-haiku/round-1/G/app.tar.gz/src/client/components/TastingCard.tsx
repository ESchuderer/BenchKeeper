import { Link } from 'react-router';
import type { TastingWithSeats } from '../../shared/types.js';
import { formatEur, formatStartsAt, seatsLabel } from '../format.js';

export function TastingCard({ tasting }: { tasting: TastingWithSeats }) {
  const fullyBooked = tasting.seatsLeft === 0;

  return (
    <article
      className={`flex flex-col rounded-2xl border bg-parchment p-6 shadow-sm ${
        fullyBooked ? 'border-muted/20' : 'border-wine/15'
      }`}
    >
      <h2 className="font-serif text-2xl text-wine">{tasting.title}</h2>
      <p className="mt-3 text-base">{formatStartsAt(tasting.startsAt)}</p>
      <p className="mt-1 text-base">{formatEur(tasting.pricePerGuest)} per guest</p>

      <p
        className={`mt-3 inline-flex w-fit rounded-full px-3 py-1 text-sm font-medium ${
          fullyBooked ? 'bg-muted/15 text-muted' : 'bg-success/10 text-success'
        }`}
      >
        {seatsLabel(tasting.seatsLeft)}
      </p>

      <div className="mt-auto pt-6">
        {fullyBooked ? (
          <button
            type="button"
            disabled
            className="w-full cursor-not-allowed rounded-lg bg-muted/20 px-4 py-3 text-center font-medium text-muted"
          >
            Fully booked
          </button>
        ) : (
          <Link
            to={`/tastings/${tasting.id}/book`}
            className="block w-full rounded-lg bg-wine px-4 py-3 text-center font-medium text-cream no-underline transition hover:bg-wine-deep"
          >
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
