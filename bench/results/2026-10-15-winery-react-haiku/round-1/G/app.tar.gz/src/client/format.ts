const dateTime = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'UTC',
  weekday: 'short',
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});

/** Shows the local winery time as written: parsing as UTC and formatting as UTC keeps it unshifted. */
export function formatStartsAt(startsAt: string): string {
  return dateTime.format(new Date(`${startsAt}:00Z`));
}

export function formatEur(amount: number): string {
  return `EUR ${amount}`;
}

export function seatsLabel(seatsLeft: number): string {
  return `${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left`;
}
