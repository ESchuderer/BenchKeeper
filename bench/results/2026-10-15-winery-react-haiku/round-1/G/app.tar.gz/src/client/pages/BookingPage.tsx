import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useNavigate, useParams } from 'react-router';
import { ApiError, createBooking, getTasting } from '../api.js';
import { FormField } from '../components/FormField.js';
import { formatEur, formatStartsAt, seatsLabel } from '../format.js';
import { bookingInputSchema } from '../../shared/schemas.js';
import type { BookingInput, TastingWithSeats } from '../../shared/types.js';

type Loaded =
  | { status: 'loading' }
  | { status: 'notfound' }
  | { status: 'error' }
  | { status: 'ready'; tasting: TastingWithSeats };

const guestOptions = (seatsLeft: number) => Array.from({ length: Math.min(8, seatsLeft) }, (_, i) => i + 1);

const guestsLabel = (n: number) => (n === 1 ? '1 guest' : `${n} guests`);

function BackLink() {
  return (
    <p className="mt-8">
      <Link to="/" className="font-medium text-wine underline-offset-4 hover:underline">
        ← Back to all tastings
      </Link>
    </p>
  );
}

export function BookingPage() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const [loaded, setLoaded] = useState<Loaded>({ status: 'loading' });
  const [formError, setFormError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    setValue,
    getValues,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  });

  useEffect(() => {
    let active = true;
    getTasting(id)
      .then((tasting) => active && setLoaded({ status: 'ready', tasting }))
      .catch((err: unknown) => {
        if (!active) return;
        setLoaded(err instanceof ApiError && err.status === 404 ? { status: 'notfound' } : { status: 'error' });
      });
    return () => {
      active = false;
    };
  }, [id]);

  const refreshSeats = async () => {
    const tasting = await getTasting(id);
    setLoaded({ status: 'ready', tasting });
    // Keep the chosen guest count within the seats that are now left.
    if (getValues('guests') > tasting.seatsLeft) setValue('guests', Math.max(1, tasting.seatsLeft));
  };

  const onSubmit = async (values: BookingInput) => {
    setFormError(null);
    try {
      const summary = await createBooking(id, values);
      navigate(`/bookings/${summary.reference}`);
    } catch (err) {
      if (!(err instanceof ApiError)) {
        setFormError('Something went wrong. Please try again.');
        return;
      }
      const fieldErrors = err.fieldErrors ?? {};
      const fields = Object.keys(fieldErrors) as (keyof BookingInput)[];
      for (const field of fields) {
        setError(field, { type: 'server', message: fieldErrors[field] });
      }
      if (fields.length === 0) setFormError(err.message);
      if (err.status === 409) await refreshSeats().catch(() => undefined);
    }
  };

  if (loaded.status === 'loading') {
    return <p role="status" className="text-muted">Loading…</p>;
  }

  if (loaded.status === 'notfound') {
    return (
      <section>
        <h1 className="font-serif text-4xl text-wine">Tasting not found</h1>
        <p className="mt-4 text-muted">This tasting does not exist or the link is out of date.</p>
        <BackLink />
      </section>
    );
  }

  if (loaded.status === 'error') {
    return (
      <div role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
        We could not load this tasting. Please refresh the page to try again.
      </div>
    );
  }

  const { tasting } = loaded;
  const header = (
    <>
      <h1 className="font-serif text-4xl text-wine sm:text-5xl">{tasting.title}</h1>
      <p className="mt-4 text-lg">
        {formatStartsAt(tasting.startsAt)} · {formatEur(tasting.pricePerGuest)} per guest
      </p>
    </>
  );

  if (!tasting.open) {
    return (
      <section>
        {header}
        <p className="mt-6 rounded-lg border border-muted/30 bg-parchment p-4 text-muted">
          This tasting has already taken place.
        </p>
        <BackLink />
      </section>
    );
  }

  if (tasting.seatsLeft === 0) {
    return (
      <section>
        {header}
        <p className="mt-6 rounded-lg border border-muted/30 bg-parchment p-4 font-medium text-muted">
          Fully booked
        </p>
        <BackLink />
      </section>
    );
  }

  return (
    <section>
      {header}
      <p className="mt-2 text-muted">{seatsLabel(tasting.seatsLeft)}</p>

      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="mt-8 max-w-xl space-y-6 rounded-2xl border border-wine/15 bg-parchment p-6 shadow-sm sm:p-8"
      >
        {formError && (
          <div role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
            {formError}
          </div>
        )}

        <FormField id="name" label="Name" error={errors.name?.message}>
          {(a11y) => (
            <input
              {...a11y}
              {...register('name')}
              type="text"
              autoComplete="name"
              className="w-full rounded-lg border border-wine/25 bg-white px-4 py-3 aria-[invalid=true]:border-danger"
            />
          )}
        </FormField>

        <FormField id="email" label="Email" error={errors.email?.message}>
          {(a11y) => (
            <input
              {...a11y}
              {...register('email')}
              type="email"
              inputMode="email"
              autoComplete="email"
              className="w-full rounded-lg border border-wine/25 bg-white px-4 py-3 aria-[invalid=true]:border-danger"
            />
          )}
        </FormField>

        <FormField id="guests" label="Guests" error={errors.guests?.message}>
          {(a11y) => (
            <select
              {...a11y}
              {...register('guests', { valueAsNumber: true })}
              className="w-full rounded-lg border border-wine/25 bg-white px-4 py-3 aria-[invalid=true]:border-danger"
            >
              {guestOptions(tasting.seatsLeft).map((n) => (
                <option key={n} value={n}>
                  {guestsLabel(n)}
                </option>
              ))}
            </select>
          )}
        </FormField>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full rounded-lg bg-wine px-4 py-3 font-medium text-cream transition hover:bg-wine-deep disabled:cursor-wait disabled:opacity-70"
        >
          {isSubmitting ? 'Booking…' : 'Book'}
        </button>
      </form>

      <BackLink />
    </section>
  );
}
