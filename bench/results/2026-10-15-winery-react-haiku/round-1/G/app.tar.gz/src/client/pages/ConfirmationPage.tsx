import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { ApiError, getBookingSummary } from '../api.js';
import { formatEur, formatStartsAt } from '../format.js';
import type { BookingSummary } from '../../shared/types.js';

type Loaded =
  | { status: 'loading' }
  | { status: 'notfound' }
  | { status: 'error' }
  | { status: 'ready'; booking: BookingSummary };

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const [loaded, setLoaded] = useState<Loaded>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    getBookingSummary(reference)
      .then((booking) => active && setLoaded({ status: 'ready', booking }))
      .catch((err: unknown) => {
        if (!active) return;
        setLoaded(err instanceof ApiError && err.status === 404 ? { status: 'notfound' } : { status: 'error' });
      });
    return () => {
      active = false;
    };
  }, [reference]);

  if (loaded.status === 'loading') {
    return <p role="status" className="text-muted">Loading your booking…</p>;
  }

  if (loaded.status === 'notfound') {
    return (
      <section>
        <h1 className="font-serif text-4xl text-wine">Booking not found</h1>
        <p className="mt-4 text-muted">We could not find this booking.</p>
        <p className="mt-8">
          <Link to="/" className="font-medium text-wine underline-offset-4 hover:underline">
            ← Back to all tastings
          </Link>
        </p>
      </section>
    );
  }

  if (loaded.status === 'error') {
    return (
      <div role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
        We could not load this booking. Please refresh the page to try again.
      </div>
    );
  }

  const { booking } = loaded;
  return (
    <section>
      <div className="rounded-2xl border border-success/30 bg-success/5 p-6 sm:p-8">
        <h1 className="font-serif text-4xl text-wine sm:text-5xl">Booking confirmed</h1>
        <p className="mt-3 text-lg">Thank you. We look forward to welcoming you.</p>

        <dl className="mt-8 grid gap-5 sm:grid-cols-2">
          <div>
            <dt className="text-sm text-muted">Tasting</dt>
            <dd className="text-lg font-medium">{booking.tastingTitle}</dd>
          </div>
          <div>
            <dt className="text-sm text-muted">Date and time</dt>
            <dd className="text-lg font-medium">{formatStartsAt(booking.startsAt)}</dd>
          </div>
          <div>
            <dt className="text-sm text-muted">Guests</dt>
            <dd className="text-lg font-medium">{booking.guests}</dd>
          </div>
          <div>
            <dt className="text-sm text-muted">Total</dt>
            <dd className="text-lg font-medium">{formatEur(booking.total)}</dd>
          </div>
          <div className="sm:col-span-2">
            <dt className="text-sm text-muted">Booking reference</dt>
            <dd className="font-mono text-2xl tracking-widest">{booking.reference}</dd>
          </div>
        </dl>
      </div>

      <p className="mt-8">
        <Link to="/" className="font-medium text-wine underline-offset-4 hover:underline">
          ← Back to all tastings
        </Link>
      </p>
    </section>
  );
}
