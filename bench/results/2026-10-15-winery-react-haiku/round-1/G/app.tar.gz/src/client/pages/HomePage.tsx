import { useEffect, useState } from 'react';
import { listTastings } from '../api.js';
import { TastingCard } from '../components/TastingCard.js';
import type { TastingWithSeats } from '../../shared/types.js';

type State =
  | { status: 'loading' }
  | { status: 'error' }
  | { status: 'ready'; tastings: TastingWithSeats[] };

export function HomePage() {
  const [state, setState] = useState<State>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    listTastings()
      .then((tastings) => active && setState({ status: 'ready', tastings }))
      .catch(() => active && setState({ status: 'error' }));
    return () => {
      active = false;
    };
  }, []);

  const openTastings = state.status === 'ready' ? state.tastings.filter((t) => t.open) : [];

  return (
    <section>
      <h1 className="font-serif text-4xl text-wine sm:text-5xl">Wine tastings</h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">
        Choose a tasting and reserve your seats online. Prices are per guest.
      </p>

      <div className="mt-10">
        {state.status === 'loading' && <p role="status" className="text-muted">Loading tastings…</p>}

        {state.status === 'error' && (
          <div role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
            We could not load the tastings. Please refresh the page to try again.
          </div>
        )}

        {state.status === 'ready' && openTastings.length === 0 && (
          <p className="text-muted">No upcoming tastings at the moment. Please check back soon.</p>
        )}

        {state.status === 'ready' && openTastings.length > 0 && (
          <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {openTastings.map((t) => (
              <li key={t.id}>
                <TastingCard tasting={t} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
