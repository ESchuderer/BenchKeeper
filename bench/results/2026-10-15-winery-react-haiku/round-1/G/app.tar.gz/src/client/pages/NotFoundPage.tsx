import { Link } from 'react-router';

export function NotFoundPage() {
  return (
    <section>
      <h1 className="font-serif text-4xl text-wine">Page not found</h1>
      <p className="mt-4 text-muted">The page you are looking for does not exist.</p>
      <p className="mt-8">
        <Link to="/" className="font-medium text-wine underline-offset-4 hover:underline">
          ← Back to all tastings
        </Link>
      </p>
    </section>
  );
}
