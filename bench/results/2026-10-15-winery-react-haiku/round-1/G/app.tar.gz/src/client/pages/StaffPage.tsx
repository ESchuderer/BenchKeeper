import { useEffect, useState, type FormEvent } from 'react';
import { ApiError, cancelStaffBooking, listStaffBookings, staffSignIn, staffSignOut } from '../api.js';
import { FormField } from '../components/FormField.js';
import { formatStartsAt, seatsLabel } from '../format.js';
import type { StaffTastingGroup } from '../../shared/types.js';

type View =
  | { status: 'loading' }
  | { status: 'signedOut'; error?: string }
  | { status: 'signedIn'; groups: StaffTastingGroup[]; actionError?: string }
  | { status: 'error' };

const guestsLabel = (n: number) => (n === 1 ? '1 guest' : `${n} guests`);

export function StaffPage() {
  const [view, setView] = useState<View>({ status: 'loading' });
  const [password, setPassword] = useState('');
  const [signingIn, setSigningIn] = useState(false);

  const loadBookings = async () => {
    try {
      const groups = await listStaffBookings();
      setView({ status: 'signedIn', groups });
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setView({ status: 'signedOut' });
      } else {
        setView({ status: 'error' });
      }
    }
  };

  useEffect(() => {
    let active = true;
    listStaffBookings()
      .then((groups) => active && setView({ status: 'signedIn', groups }))
      .catch((err: unknown) => {
        if (!active) return;
        setView(err instanceof ApiError && err.status === 401 ? { status: 'signedOut' } : { status: 'error' });
      });
    return () => {
      active = false;
    };
  }, []);

  const onSignIn = async (event: FormEvent) => {
    event.preventDefault();
    setSigningIn(true);
    try {
      await staffSignIn(password);
      setPassword('');
      await loadBookings();
    } catch (err) {
      setView({ status: 'signedOut', error: err instanceof ApiError ? err.message : 'Something went wrong.' });
    } finally {
      setSigningIn(false);
    }
  };

  const onSignOut = async () => {
    try {
      await staffSignOut();
      setView({ status: 'signedOut' });
    } catch (err) {
      // Only show the sign-in form once the server has ended the session.
      if (err instanceof ApiError && err.status === 401) {
        setView({ status: 'signedOut' });
      } else {
        setView((v) =>
          v.status === 'signedIn' ? { ...v, actionError: 'Sign-out failed. Please try again.' } : v,
        );
      }
    }
  };

  const onCancel = async (reference: string, name: string) => {
    if (!window.confirm(`Cancel booking ${reference} for ${name}?`)) return;
    try {
      await cancelStaffBooking(reference);
      await loadBookings();
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setView({ status: 'signedOut' });
      } else {
        setView((v) => (v.status === 'signedIn' ? { ...v, actionError: 'The booking could not be cancelled. Please try again.' } : v));
      }
    }
  };

  if (view.status === 'loading') {
    return <p role="status" className="text-muted">Loading…</p>;
  }

  if (view.status === 'error') {
    return (
      <div role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
        We could not load the bookings. Please refresh the page to try again.
      </div>
    );
  }

  if (view.status === 'signedOut') {
    return (
      <section className="max-w-md">
        <h1 className="font-serif text-4xl text-wine">Staff sign in</h1>
        <form onSubmit={onSignIn} noValidate className="mt-8 space-y-6 rounded-2xl border border-wine/15 bg-parchment p-6 shadow-sm">
          {view.error && (
            <div role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
              {view.error}
            </div>
          )}
          <FormField id="password" label="Password">
            {(a11y) => (
              <input
                {...a11y}
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-wine/25 bg-white px-4 py-3"
              />
            )}
          </FormField>
          <button
            type="submit"
            disabled={signingIn}
            className="w-full rounded-lg bg-wine px-4 py-3 font-medium text-cream transition hover:bg-wine-deep disabled:cursor-wait disabled:opacity-70"
          >
            Sign in
          </button>
        </form>
      </section>
    );
  }

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-serif text-4xl text-wine">Bookings</h1>
        <button
          type="button"
          onClick={onSignOut}
          className="rounded-lg border border-wine/30 px-4 py-2 font-medium text-wine transition hover:bg-wine/5"
        >
          Sign out
        </button>
      </div>

      {view.actionError && (
        <div role="alert" className="mt-6 rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
          {view.actionError}
        </div>
      )}

      <div className="mt-8 space-y-10">
        {view.groups.map(({ tasting, bookings }) => (
          <section key={tasting.id} aria-labelledby={`group-${tasting.id}`}>
            <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-wine/15 pb-2">
              <h2 id={`group-${tasting.id}`} className="font-serif text-2xl text-wine">
                {tasting.title}
              </h2>
              <p className="text-sm text-muted">
                {formatStartsAt(tasting.startsAt)} · {seatsLabel(tasting.seatsLeft)}
              </p>
            </div>

            {bookings.length === 0 ? (
              <p className="mt-4 text-muted">No bookings yet.</p>
            ) : (
              <ul className="mt-4 divide-y divide-wine/10 rounded-2xl border border-wine/15 bg-parchment">
                {bookings.map((b) => (
                  <li key={b.reference} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                      <p className="font-medium">{b.name}</p>
                      <p className="break-all text-sm text-muted">{b.email}</p>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
                      <span>{guestsLabel(b.guests)}</span>
                      <span className="font-mono tracking-wider">{b.reference}</span>
                      <button
                        type="button"
                        onClick={() => onCancel(b.reference, b.name)}
                        className="rounded-lg border border-danger/40 px-3 py-1.5 font-medium text-danger transition hover:bg-danger/5"
                      >
                        Cancel
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </div>
    </section>
  );
}
