import express, { type ErrorRequestHandler, type Express, type Request, type RequestHandler } from 'express';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import fs from 'node:fs';
import path from 'node:path';
import type { BookingStore } from './bookingStore.js';
import { STAFF_COOKIE, type StaffAuth } from './staffAuth.js';
import { bookingInputSchema } from '../shared/schemas.js';
import type { FieldErrors } from '../shared/types.js';

const EIGHT_HOURS_MS = 8 * 60 * 60 * 1000;
const FIFTEEN_MINUTES_MS = 15 * 60 * 1000;

export interface AppDeps {
  store: BookingStore;
  staffAuth: StaffAuth;
  /** Built React app. When set, non-API GET requests get index.html so deep links work. */
  staticDir?: string;
  /** Sign-in attempts allowed per window, per client IP. */
  loginLimit?: number;
  loginWindowMs?: number;
  /** Booking requests allowed per window, per client IP. Stops one client filling a tasting. */
  bookingLimit?: number;
  bookingWindowMs?: number;
  /** Number of reverse-proxy hops to trust for client IP and `req.secure`. Unset means none. */
  trustProxy?: number | false;
}

const seatsMessage = (seatsLeft: number) => {
  if (seatsLeft === 0) return 'This tasting is fully booked.';
  return seatsLeft === 1 ? 'Only 1 seat left.' : `Only ${seatsLeft} seats left.`;
};

function fieldErrorsFrom(issues: { path: PropertyKey[]; message: string }[]): FieldErrors {
  const errors: FieldErrors = {};
  for (const issue of issues) {
    const field = issue.path[0];
    if ((field === 'name' || field === 'email' || field === 'guests') && !errors[field]) {
      errors[field] = issue.message;
    }
  }
  return errors;
}

export function createApp(deps: AppDeps): Express {
  const { store, staffAuth } = deps;
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', deps.trustProxy ?? false);
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  const loginLimiter = rateLimit({
    windowMs: deps.loginWindowMs ?? FIFTEEN_MINUTES_MS,
    limit: deps.loginLimit ?? 10,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Too many sign-in attempts. Try again later.' },
  });

  const bookingLimiter = rateLimit({
    windowMs: deps.bookingWindowMs ?? FIFTEEN_MINUTES_MS,
    limit: deps.bookingLimit ?? 10,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Too many booking attempts. Try again later.' },
  });

  const requireStaff: RequestHandler = (req, res, next) => {
    if (!staffAuth.isValidSession(req.cookies?.[STAFF_COOKIE])) {
      res.status(401).json({ error: 'Please sign in.' });
      return;
    }
    next();
  };

  const cookieOptions = (req: Request) => ({
    httpOnly: true,
    sameSite: 'strict' as const,
    path: '/',
    secure: req.secure,
  });

  app.get('/api/tastings', (_req, res) => {
    res.json(store.listTastings());
  });

  app.get('/api/tastings/:id', (req, res) => {
    const tasting = store.getTasting(req.params.id);
    if (!tasting) {
      res.status(404).json({ error: 'Tasting not found.' });
      return;
    }
    res.json(tasting);
  });

  app.post('/api/tastings/:id/bookings', bookingLimiter, (req: Request<{ id: string }>, res) => {
    const parsed = bookingInputSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({
        error: 'Please check the highlighted fields.',
        fieldErrors: fieldErrorsFrom(parsed.error.issues),
      });
      return;
    }

    const result = store.createBooking(req.params.id, parsed.data);
    if (!result.ok) {
      if (result.reason === 'unknown-tasting') {
        res.status(404).json({ error: 'Tasting not found.' });
      } else if (result.reason === 'closed') {
        res.status(409).json({ error: 'This tasting has already taken place.' });
      } else {
        res.status(409).json({
          error: 'Not enough seats left.',
          fieldErrors: { guests: seatsMessage(result.seatsLeft) },
        });
      }
      return;
    }
    res.status(201).json(store.getBookingSummary(result.reference));
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const summary = store.getBookingSummary(req.params.reference);
    if (!summary) {
      res.status(404).json({ error: 'We could not find this booking.' });
      return;
    }
    res.json(summary);
  });

  app.post('/api/staff/session', loginLimiter, (req, res) => {
    if (!staffAuth.configured) {
      res.status(503).json({ error: 'Staff sign-in is not configured.' });
      return;
    }
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!staffAuth.checkPassword(password)) {
      res.status(401).json({ error: 'Incorrect password.' });
      return;
    }
    const token = staffAuth.createSession();
    res.cookie(STAFF_COOKIE, token, { ...cookieOptions(req), maxAge: EIGHT_HOURS_MS });
    res.status(204).end();
  });

  app.delete('/api/staff/session', (req, res) => {
    staffAuth.endSession(req.cookies?.[STAFF_COOKIE]);
    res.clearCookie(STAFF_COOKIE, cookieOptions(req));
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    res.json(store.listBookingsGrouped());
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req: Request<{ reference: string }>, res) => {
    if (!store.cancelBooking(req.params.reference)) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }
    res.status(204).end();
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found.' });
  });

  if (deps.staticDir) {
    const indexHtml = path.join(deps.staticDir, 'index.html');
    app.use(express.static(deps.staticDir));
    if (fs.existsSync(indexHtml)) {
      app.get('/{*splat}', (_req, res) => {
        res.sendFile(indexHtml);
      });
    }
  }

  const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
    const status: number = err.status ?? err.statusCode ?? 500;
    if (status === 400) {
      res.status(400).json({ error: 'Invalid JSON.' });
    } else if (status === 413) {
      res.status(413).json({ error: 'Request is too large.' });
    } else {
      console.error(err);
      res.status(500).json({ error: 'Something went wrong.' });
    }
  };
  app.use(errorHandler);

  return app;
}
