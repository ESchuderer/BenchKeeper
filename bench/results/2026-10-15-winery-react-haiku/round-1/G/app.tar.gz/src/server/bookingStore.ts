import { randomInt } from 'node:crypto';
import { TASTINGS } from '../shared/catalogue.js';
import type {
  BookingInput,
  BookingSummary,
  StaffBooking,
  StaffTastingGroup,
  Tasting,
  TastingWithSeats,
} from '../shared/types.js';

/** No 0/O, 1/I/L look-alikes. */
const REFERENCE_ALPHABET = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
const REFERENCE_LENGTH = 6;
const TASTING_TIME_ZONE = 'Europe/Berlin';

export type CreateBookingResult =
  | { ok: true; reference: string }
  | { ok: false; reason: 'unknown-tasting' }
  | { ok: false; reason: 'closed' }
  | { ok: false; reason: 'not-enough-seats'; seatsLeft: number };

export interface BookingStore {
  listTastings(): TastingWithSeats[];
  getTasting(id: string): TastingWithSeats | undefined;
  createBooking(tastingId: string, input: BookingInput): CreateBookingResult;
  getBookingSummary(reference: string): BookingSummary | undefined;
  listBookingsGrouped(): StaffTastingGroup[];
  cancelBooking(reference: string): boolean;
}

interface StoredBooking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

/**
 * True while the tasting's start time (Europe/Berlin wall-clock) is still ahead of `now`.
 */
export function isTastingOpen(startsAt: string, now: Date): boolean {
  return tastingStartInstant(startsAt).getTime() > now.getTime();
}

function tastingStartInstant(startsAt: string): Date {
  // Read the wall-clock as if it were UTC, then subtract the Berlin offset at that moment.
  const wallAsUtc = Date.parse(`${startsAt}:00Z`);
  const offset = berlinOffsetMs(wallAsUtc);
  return new Date(wallAsUtc - offset);
}

/** Berlin wall-clock minus UTC at the given instant, in milliseconds (+1h in winter). */
function berlinOffsetMs(instant: number): number {
  const whole = Math.floor(instant / 1000) * 1000;
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: TASTING_TIME_ZONE,
    hourCycle: 'h23',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).formatToParts(new Date(whole));
  const part = (type: string) => Number(parts.find((p) => p.type === type)!.value);
  const wallAsUtc = Date.UTC(
    part('year'),
    part('month') - 1,
    part('day'),
    part('hour'),
    part('minute'),
    part('second'),
  );
  return wallAsUtc - whole;
}

export function createBookingStore(
  options: { tastings?: Tasting[]; random?: (n: number) => number; now?: () => Date } = {},
): BookingStore {
  const tastings = options.tastings ?? TASTINGS;
  const random = options.random ?? ((n: number) => randomInt(n));
  const now = options.now ?? (() => new Date());
  const bookings = new Map<string, StoredBooking>();

  const seatsTaken = (tastingId: string) => {
    let taken = 0;
    for (const b of bookings.values()) {
      if (b.tastingId === tastingId) taken += b.guests;
    }
    return taken;
  };

  const withSeats = (t: Tasting): TastingWithSeats => ({
    ...t,
    seatsLeft: t.capacity - seatsTaken(t.id),
    open: isTastingOpen(t.startsAt, now()),
  });

  const newReference = (): string => {
    for (;;) {
      let reference = 'KB-';
      for (let i = 0; i < REFERENCE_LENGTH; i++) {
        reference += REFERENCE_ALPHABET[random(REFERENCE_ALPHABET.length)];
      }
      if (!bookings.has(reference)) return reference;
    }
  };

  const findTasting = (id: string) => tastings.find((t) => t.id === id);

  return {
    listTastings() {
      return tastings.map(withSeats);
    },

    getTasting(id) {
      const t = findTasting(id);
      return t ? withSeats(t) : undefined;
    },

    createBooking(tastingId, input) {
      const t = findTasting(tastingId);
      if (!t) return { ok: false, reason: 'unknown-tasting' };
      if (!isTastingOpen(t.startsAt, now())) return { ok: false, reason: 'closed' };

      // Synchronous from the seat check to the insert: no other request can run in between.
      const seatsLeft = t.capacity - seatsTaken(t.id);
      if (input.guests > seatsLeft) return { ok: false, reason: 'not-enough-seats', seatsLeft };

      const reference = newReference();
      bookings.set(reference, {
        reference,
        tastingId: t.id,
        name: input.name,
        email: input.email,
        guests: input.guests,
        createdAt: now().toISOString(),
      });
      return { ok: true, reference };
    },

    getBookingSummary(reference) {
      const b = bookings.get(reference);
      const t = b && findTasting(b.tastingId);
      if (!b || !t) return undefined;
      return {
        reference: b.reference,
        tastingId: t.id,
        tastingTitle: t.title,
        startsAt: t.startsAt,
        guests: b.guests,
        pricePerGuest: t.pricePerGuest,
        total: b.guests * t.pricePerGuest,
      };
    },

    listBookingsGrouped() {
      return tastings.map((t): StaffTastingGroup => {
        const own: StaffBooking[] = [...bookings.values()]
          .filter((b) => b.tastingId === t.id)
          .map(({ reference, name, email, guests, createdAt }) => ({
            reference,
            name,
            email,
            guests,
            createdAt,
          }));
        return { tasting: withSeats(t), bookings: own };
      });
    },

    cancelBooking(reference) {
      return bookings.delete(reference);
    },
  };
}
