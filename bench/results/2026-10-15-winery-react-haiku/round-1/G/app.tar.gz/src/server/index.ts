import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { createBookingStore } from './bookingStore.js';
import { createStaffAuth } from './staffAuth.js';

const here = path.dirname(fileURLToPath(import.meta.url));

const port = Number(process.env.PORT ?? 3000);
if (!Number.isInteger(port) || port < 0 || port > 65535) {
  throw new Error(`PORT must be a port number, got "${process.env.PORT}"`);
}

const host = process.env.HOST ?? '0.0.0.0';

const trustProxyHops = process.env.TRUST_PROXY ? Number(process.env.TRUST_PROXY) : undefined;
if (trustProxyHops !== undefined && (!Number.isInteger(trustProxyHops) || trustProxyHops < 0)) {
  throw new Error(`TRUST_PROXY must be a whole number of hops, got "${process.env.TRUST_PROXY}"`);
}

const password = process.env.STAFF_PASSWORD;
if (!password) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

const app = createApp({
  store: createBookingStore(),
  staffAuth: createStaffAuth({ password }),
  staticDir: path.join(here, '../client'),
  trustProxy: trustProxyHops ?? false,
});

app.listen(port, host, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://${host}:${port}`);
});
