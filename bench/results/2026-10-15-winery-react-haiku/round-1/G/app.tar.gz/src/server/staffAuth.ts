import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const STAFF_COOKIE = 'kb_staff';

const DEFAULT_SESSION_MS = 8 * 60 * 60 * 1000;

export interface StaffAuth {
  /** False when no password is set; sign-in is then refused. */
  readonly configured: boolean;
  checkPassword(candidate: string): boolean;
  createSession(): string;
  isValidSession(token: string | undefined): boolean;
  endSession(token: string | undefined): void;
}

const digest = (value: string) => createHash('sha256').update(value).digest();

export function createStaffAuth(options: {
  password: string | undefined;
  now?: () => number;
  sessionMs?: number;
}): StaffAuth {
  const now = options.now ?? (() => Date.now());
  const sessionMs = options.sessionMs ?? DEFAULT_SESSION_MS;
  const configured = typeof options.password === 'string' && options.password.length > 0;
  // Compare fixed-length digests so the comparison does not depend on the candidate's length.
  const expected = configured ? digest(options.password!) : undefined;
  const sessions = new Map<string, number>();

  return {
    configured,

    checkPassword(candidate) {
      if (!expected) return false;
      return timingSafeEqual(digest(candidate), expected);
    },

    createSession() {
      const token = randomBytes(32).toString('base64url');
      sessions.set(token, now() + sessionMs);
      return token;
    },

    isValidSession(token) {
      if (!token) return false;
      const expiresAt = sessions.get(token);
      if (expiresAt === undefined) return false;
      if (now() >= expiresAt) {
        sessions.delete(token);
        return false;
      }
      return true;
    },

    endSession(token) {
      if (token) sessions.delete(token);
    },
  };
}
