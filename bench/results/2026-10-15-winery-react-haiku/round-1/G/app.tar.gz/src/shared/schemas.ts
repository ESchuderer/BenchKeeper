import { z } from 'zod';

export const FIELD_MESSAGES = {
  nameRequired: 'Please enter your name.',
  nameTooLong: 'Your name can be at most 100 characters.',
  emailRequired: 'Please enter your email address.',
  emailInvalid: 'Please enter a valid email address.',
  guestsRequired: 'Choose how many guests.',
  guestsMin: 'Choose at least 1 guest.',
  guestsMax: 'You can book for up to 8 guests.',
  guestsWhole: 'Choose a whole number of guests.',
} as const;

export const bookingInputSchema = z.object({
  name: z
    .string({ error: FIELD_MESSAGES.nameRequired })
    .trim()
    .min(1, FIELD_MESSAGES.nameRequired)
    .max(100, FIELD_MESSAGES.nameTooLong)
    // Rejects names made only of spaces, punctuation or invisible characters such as zero-width spaces.
    .refine((name) => /[\p{L}\p{N}]/u.test(name), FIELD_MESSAGES.nameRequired),
  email: z
    .string({ error: FIELD_MESSAGES.emailRequired })
    .trim()
    .min(1, FIELD_MESSAGES.emailRequired)
    .max(254, FIELD_MESSAGES.emailInvalid)
    .email(FIELD_MESSAGES.emailInvalid),
  guests: z
    .number({
      error: (issue) =>
        issue.input === undefined ? FIELD_MESSAGES.guestsRequired : FIELD_MESSAGES.guestsWhole,
    })
    .int(FIELD_MESSAGES.guestsWhole)
    .min(1, FIELD_MESSAGES.guestsMin)
    .max(8, FIELD_MESSAGES.guestsMax),
});
