export interface Tasting {
  id: string;
  title: string;
  /** Local winery time, "YYYY-MM-DDTHH:mm" (Europe/Berlin). */
  startsAt: string;
  pricePerGuest: number;
  capacity: number;
}

export interface TastingWithSeats extends Tasting {
  seatsLeft: number;
  /** False once the start time has passed. */
  open: boolean;
}

export interface BookingInput {
  name: string;
  email: string;
  guests: number;
}

export interface BookingSummary {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  pricePerGuest: number;
  total: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface StaffTastingGroup {
  tasting: TastingWithSeats;
  bookings: StaffBooking[];
}

export type FieldErrors = Partial<Record<'name' | 'email' | 'guests', string>>;

export interface ApiErrorBody {
  error: string;
  fieldErrors?: FieldErrors;
}
