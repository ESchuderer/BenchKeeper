// @vitest-environment jsdom
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, within, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { App } from '../../src/client/App';
import { FIELD_MESSAGES } from '../../src/shared/schemas';
import type { BookingSummary, TastingWithSeats } from '../../src/shared/types';

type Handler = (init?: RequestInit) => Response;

function tastingWith(seatsLeft: number, overrides: Partial<TastingWithSeats> = {}): TastingWithSeats {
  return {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06T18:00',
    pricePerGuest: 25,
    capacity: 12,
    seatsLeft,
    open: true,
    ...overrides,
  };
}

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status });

/** Routes fetch calls by "METHOD /path". Calls to unknown routes fail the test. */
function mockApi(routes: Record<string, Handler | (() => Response)>) {
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    const key = `${init?.method ?? 'GET'} ${url}`;
    const handler = routes[key];
    if (!handler) throw new Error(`Unexpected request: ${key}`);
    return handler(init);
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('booking page', () => {
  it('shows the tasting and the Name, Email and Guests fields with a Book button', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': () => json(tastingWith(12)) });
    renderAt('/tastings/riesling-evening/book');

    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('offers 1 to 8 guests when plenty of seats are left', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': () => json(tastingWith(12)) });
    renderAt('/tastings/riesling-evening/book');
    const options = within(await screen.findByLabelText('Guests')).getAllByRole('option');
    expect(options.map((o) => o.getAttribute('value'))).toEqual(['1', '2', '3', '4', '5', '6', '7', '8']);
  });

  it('offers only the seats that are left', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': () => json(tastingWith(3)) });
    renderAt('/tastings/riesling-evening/book');
    const options = within(await screen.findByLabelText('Guests')).getAllByRole('option');
    expect(options.map((o) => o.getAttribute('value'))).toEqual(['1', '2', '3']);
  });

  it('shows the required-name message next to the Name field', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': () => json(tastingWith(12)) });
    renderAt('/tastings/riesling-evening/book');
    await userEvent.click(await screen.findByRole('button', { name: 'Book' }));

    const name = screen.getByLabelText('Name');
    const message = await screen.findByText(FIELD_MESSAGES.nameRequired);
    expect(name).toHaveAttribute('aria-describedby', expect.stringContaining(message.id));
    expect(name).toHaveAttribute('aria-invalid', 'true');
  });

  it('shows the invalid-email message next to the Email field', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': () => json(tastingWith(12)) });
    renderAt('/tastings/riesling-evening/book');
    await userEvent.type(await screen.findByLabelText('Name'), 'Anna Berg');
    await userEvent.type(screen.getByLabelText('Email'), 'anna example.com');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    const message = await screen.findByText(FIELD_MESSAGES.emailInvalid);
    expect(screen.getByLabelText('Email')).toHaveAttribute('aria-describedby', expect.stringContaining(message.id));
  });

  it('books, then shows the confirmation at the booking URL', async () => {
    const summary: BookingSummary = {
      reference: 'KB-ABCDEF',
      tastingId: 'riesling-evening',
      tastingTitle: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      guests: 2,
      pricePerGuest: 25,
      total: 50,
    };
    const fetchMock = mockApi({
      'GET /api/tastings/riesling-evening': () => json(tastingWith(12)),
      'POST /api/tastings/riesling-evening/bookings': () => json(summary, 201),
      'GET /api/bookings/KB-ABCDEF': () => json(summary),
    });
    renderAt('/tastings/riesling-evening/book');

    await userEvent.type(await screen.findByLabelText('Name'), 'Anna Berg');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.selectOptions(screen.getByLabelText('Guests'), '2');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('EUR 50')).toBeInTheDocument();
    expect(screen.getByText('KB-ABCDEF')).toBeInTheDocument();
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument();
    expect(screen.getByText(/6 Nov 2026/)).toBeInTheDocument();
    expect(screen.getByText('Guests').nextElementSibling).toHaveTextContent('2');

    const post = fetchMock.mock.calls.find(([, init]) => init?.method === 'POST');
    expect(JSON.parse(post![1]!.body as string)).toEqual({
      name: 'Anna Berg',
      email: 'anna@example.com',
      guests: 2,
    });
  });

  it('shows the seats-left message next to Guests when the server has fewer seats, and refreshes the choice', async () => {
    let seats = 12;
    mockApi({
      'GET /api/tastings/riesling-evening': () => json(tastingWith(seats)),
      'POST /api/tastings/riesling-evening/bookings': () => {
        seats = 1;
        return json({ error: 'Not enough seats left.', fieldErrors: { guests: 'Only 1 seat left.' } }, 409);
      },
    });
    renderAt('/tastings/riesling-evening/book');

    await userEvent.type(await screen.findByLabelText('Name'), 'Anna Berg');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.selectOptions(screen.getByLabelText('Guests'), '4');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    const message = await screen.findByText('Only 1 seat left.');
    expect(screen.getByLabelText('Guests')).toHaveAttribute('aria-describedby', expect.stringContaining(message.id));
    await waitFor(() => {
      const values = within(screen.getByLabelText('Guests')).getAllByRole('option').map((o) => o.getAttribute('value'));
      expect(values).toEqual(['1']);
    });
  });

  it('says so when the tasting has already taken place', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': () => json(tastingWith(12, { open: false })) });
    renderAt('/tastings/riesling-evening/book');
    expect(await screen.findByText('This tasting has already taken place.')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });

  it('says so when the tasting is fully booked and offers no form', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': () => json(tastingWith(0)) });
    renderAt('/tastings/riesling-evening/book');
    expect(await screen.findByText('Fully booked')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });

  it('says so for an unknown tasting', async () => {
    mockApi({ 'GET /api/tastings/nope': () => json({ error: 'Tasting not found.' }, 404) });
    renderAt('/tastings/nope/book');
    expect(await screen.findByRole('heading', { name: 'Tasting not found' })).toBeInTheDocument();
  });
});

describe('confirmation page', () => {
  it('says so when the reference is unknown', async () => {
    mockApi({ 'GET /api/bookings/KB-NOPE00': () => json({ error: 'We could not find this booking.' }, 404) });
    renderAt('/bookings/KB-NOPE00');
    expect(await screen.findByText('We could not find this booking.')).toBeInTheDocument();
  });
});
