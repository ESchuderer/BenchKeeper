// @vitest-environment jsdom
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { App } from '../../src/client/App';
import type { TastingWithSeats } from '../../src/shared/types';

const tastings: TastingWithSeats[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuest: 25, capacity: 12, seatsLeft: 12, open: true },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuest: 32, capacity: 8, seatsLeft: 8, open: true },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuest: 28, capacity: 10, seatsLeft: 0, open: true },
  { id: 'spring', title: 'Spring Tasting', startsAt: '2026-04-01T17:00', pricePerGuest: 20, capacity: 10, seatsLeft: 10, open: false },
];

function renderHome(list: TastingWithSeats[] | 'fail') {
  vi.stubGlobal(
    'fetch',
    vi.fn(async () =>
      list === 'fail' ? new Response('boom', { status: 500 }) : new Response(JSON.stringify(list), { status: 200 }),
    ),
  );
  return render(
    <MemoryRouter initialEntries={['/']}>
      <App />
    </MemoryRouter>,
  );
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('home page', () => {
  it('links the winery name in the header to the start page', async () => {
    renderHome(tastings);
    expect(screen.getByRole('link', { name: 'Weingut Kieselbrunnen' })).toHaveAttribute('href', '/');
  });

  it('lists each open tasting with its title, price and seats left', async () => {
    renderHome(tastings);
    const card = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('article')!;
    expect(within(card).getByText(/EUR 25/)).toBeInTheDocument();
    expect(within(card).getByText('12 seats left')).toBeInTheDocument();
    expect(screen.getByText('8 seats left')).toBeInTheDocument();
  });

  it('gives each tasting a "Book <title>" link to its booking form', async () => {
    renderHome(tastings);
    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link).toHaveAttribute('href', '/tastings/riesling-evening/book');
  });

  it('marks a full tasting as fully booked and offers no booking link', async () => {
    renderHome(tastings);
    await screen.findByRole('heading', { name: 'Winter Tasting' });
    expect(screen.getByText('Fully booked')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Winter Tasting' })).not.toBeInTheDocument();
  });

  it('does not list tastings whose start time has passed', async () => {
    renderHome(tastings);
    await screen.findByRole('heading', { name: 'Riesling Evening' });
    expect(screen.queryByRole('heading', { name: 'Spring Tasting' })).not.toBeInTheDocument();
  });

  it('keeps the seats line on a fully booked tasting', async () => {
    renderHome(tastings);
    const card = (await screen.findByRole('heading', { name: 'Winter Tasting' })).closest('article')!;
    expect(within(card).getByText('0 seats left')).toBeInTheDocument();
  });

  it('says when no tasting is open for booking', async () => {
    renderHome(tastings.filter((t) => !t.open));
    expect(await screen.findByText(/No upcoming tastings at the moment/)).toBeInTheDocument();
  });

  it('shows an alert when the tastings cannot be loaded', async () => {
    renderHome('fail');
    expect(await screen.findByRole('alert')).toHaveTextContent('We could not load the tastings');
  });
});
