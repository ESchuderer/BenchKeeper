// @vitest-environment jsdom
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, within, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { App } from '../../src/client/App';
import type { StaffTastingGroup, TastingWithSeats } from '../../src/shared/types';

const tasting: TastingWithSeats = {
  id: 'riesling-evening',
  title: 'Riesling Evening',
  startsAt: '2026-11-06T18:00',
  pricePerGuest: 25,
  capacity: 12,
  seatsLeft: 10,
  open: true,
};

const groups = (bookings: StaffTastingGroup['bookings']): StaffTastingGroup[] => [
  { tasting: { ...tasting, seatsLeft: tasting.capacity - bookings.reduce((n, b) => n + b.guests, 0) }, bookings },
  { tasting: { ...tasting, id: 'winter-tasting', title: 'Winter Tasting', seatsLeft: 10 }, bookings: [] },
];

const anna = {
  reference: 'KB-ABCDEF',
  name: 'Anna Berg',
  email: 'anna@example.com',
  guests: 2,
  createdAt: '2026-10-14T10:00:00.000Z',
};

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status });

/** A stateful fake of the staff endpoints: sign-in flips the session, cancel removes the booking. */
function fakeStaffApi(
  options: { password?: string; configured?: boolean; initial?: StaffTastingGroup['bookings']; failSignOut?: boolean } = {},
) {
  const { password = 'pw', configured = true, failSignOut = false } = options;
  let signedIn = false;
  let bookings = options.initial ?? [anna];
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    const method = init?.method ?? 'GET';
    if (url === '/api/staff/session' && method === 'POST') {
      if (!configured) return json({ error: 'Staff sign-in is not configured.' }, 503);
      const body = JSON.parse(init!.body as string) as { password: string };
      if (body.password !== password) return json({ error: 'Incorrect password.' }, 401);
      signedIn = true;
      return new Response(null, { status: 204 });
    }
    if (url === '/api/staff/session' && method === 'DELETE') {
      if (failSignOut) return json({ error: 'Server error' }, 500);
      signedIn = false;
      return new Response(null, { status: 204 });
    }
    if (url === '/api/staff/bookings' && method === 'GET') {
      return signedIn ? json(groups(bookings)) : json({ error: 'Please sign in.' }, 401);
    }
    if (url.startsWith('/api/staff/bookings/') && method === 'DELETE') {
      const ref = url.split('/').pop()!;
      bookings = bookings.filter((b) => b.reference !== ref);
      return new Response(null, { status: 204 });
    }
    throw new Error(`Unexpected request: ${method} ${url}`);
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

function renderStaff() {
  return render(
    <MemoryRouter initialEntries={['/staff']}>
      <App />
    </MemoryRouter>,
  );
}

async function signIn(password: string) {
  await userEvent.type(await screen.findByLabelText('Password'), password);
  await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('staff page', () => {
  it('asks for the password when signed out', async () => {
    fakeStaffApi();
    renderStaff();
    expect(await screen.findByRole('heading', { name: 'Staff sign in' })).toBeInTheDocument();
    expect(screen.getByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });

  it('shows the wrong-password message and no bookings', async () => {
    fakeStaffApi();
    renderStaff();
    await signIn('nope');
    expect(await screen.findByText('Incorrect password.')).toBeInTheDocument();
    expect(screen.queryByText('Anna Berg')).not.toBeInTheDocument();
  });

  it('shows a clear message when staff sign-in is not configured', async () => {
    fakeStaffApi({ configured: false });
    renderStaff();
    await signIn('anything');
    expect(await screen.findByText('Staff sign-in is not configured.')).toBeInTheDocument();
  });

  it('after signing in, lists bookings grouped by tasting with name, email, guests and reference', async () => {
    fakeStaffApi();
    renderStaff();
    await signIn('pw');

    const group = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section')!;
    expect(within(group).getByText('Anna Berg')).toBeInTheDocument();
    expect(within(group).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(group).getByText('2 guests')).toBeInTheDocument();
    expect(within(group).getByText('KB-ABCDEF')).toBeInTheDocument();
    expect(within(group).getByText(/10 seats left/)).toBeInTheDocument();
  });

  it('says when a tasting has no bookings yet', async () => {
    fakeStaffApi();
    renderStaff();
    await signIn('pw');
    const winter = (await screen.findByRole('heading', { name: 'Winter Tasting' })).closest('section')!;
    expect(within(winter).getByText('No bookings yet.')).toBeInTheDocument();
  });

  it('cancels a booking after confirmation, and the booking disappears', async () => {
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const fetchMock = fakeStaffApi();
    renderStaff();
    await signIn('pw');

    await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }));

    await waitFor(() => expect(screen.queryByText('Anna Berg')).not.toBeInTheDocument());
    const del = fetchMock.mock.calls.find(([, init]) => init?.method === 'DELETE');
    expect(del?.[0]).toBe('/api/staff/bookings/KB-ABCDEF');
  });

  it('does not cancel when the confirmation is declined', async () => {
    vi.spyOn(window, 'confirm').mockReturnValue(false);
    const fetchMock = fakeStaffApi();
    renderStaff();
    await signIn('pw');

    await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }));

    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'DELETE')).toBe(false);
    expect(screen.getByText('Anna Berg')).toBeInTheDocument();
  });

  it('keeps the bookings on screen and says so when sign-out fails', async () => {
    fakeStaffApi({ failSignOut: true });
    renderStaff();
    await signIn('pw');
    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Sign-out failed');
    expect(screen.getByText('Anna Berg')).toBeInTheDocument();
  });

  it('signs out and returns to the password form', async () => {
    fakeStaffApi();
    renderStaff();
    await signIn('pw');
    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });
});
