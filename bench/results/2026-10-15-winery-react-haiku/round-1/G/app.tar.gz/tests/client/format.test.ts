import { describe, it, expect, vi, afterEach } from 'vitest';
import { formatStartsAt, formatEur, seatsLabel } from '../../src/client/format';
import { ApiError, createBooking, listStaffBookings } from '../../src/client/api';

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('formatting', () => {
  it('shows the start as written, without time-zone shift', () => {
    const text = formatStartsAt('2026-11-06T18:00');
    expect(text).toContain('6 Nov 2026');
    expect(text).toContain('18:00');
  });

  it('formats euros and seats', () => {
    expect(formatEur(25)).toBe('EUR 25');
    expect(seatsLabel(12)).toBe('12 seats left');
    expect(seatsLabel(1)).toBe('1 seat left');
  });
});

describe('api helpers', () => {
  it('posts the booking as JSON and returns the summary on 201', async () => {
    const summary = { reference: 'KB-ABCDEF', total: 50 };
    const fetchMock = vi.fn(async () => new Response(JSON.stringify(summary), { status: 201 }));
    vi.stubGlobal('fetch', fetchMock);

    const result = await createBooking('t1', { name: 'Anna', email: 'a@b.de', guests: 2 });

    expect(result).toEqual(summary);
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe('/api/tastings/t1/bookings');
    expect(init.method).toBe('POST');
    expect(JSON.parse(init.body as string)).toEqual({ name: 'Anna', email: 'a@b.de', guests: 2 });
  });

  it('rejects with the field errors the server sent on 409', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(
          JSON.stringify({ error: 'Not enough seats left.', fieldErrors: { guests: 'Only 1 seat left.' } }),
          { status: 409 },
        ),
      ),
    );

    const error = await createBooking('t1', { name: 'Anna', email: 'a@b.de', guests: 3 }).catch((e) => e);

    expect(error).toBeInstanceOf(ApiError);
    expect(error.status).toBe(409);
    expect(error.fieldErrors).toEqual({ guests: 'Only 1 seat left.' });
  });

  it('rejects with status 401 when staff are signed out', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'Please sign in.' }), { status: 401 })));
    const error = await listStaffBookings().catch((e) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect(error.status).toBe(401);
    expect(error.message).toBe('Please sign in.');
  });
});
