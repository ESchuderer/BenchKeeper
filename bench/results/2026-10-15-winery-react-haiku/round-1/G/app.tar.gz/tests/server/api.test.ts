import { describe, it, expect, beforeEach, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../../src/server/app';
import { createBookingStore } from '../../src/server/bookingStore';
import { createStaffAuth, STAFF_COOKIE } from '../../src/server/staffAuth';
import { FIELD_MESSAGES } from '../../src/shared/schemas';
import type { Tasting } from '../../src/shared/types';

const NOW = new Date('2026-10-14T12:00:00Z');
const tastings: Tasting[] = [
  { id: 't1', title: 'Test Tasting', startsAt: '2026-11-06T18:00', pricePerGuest: 25, capacity: 3 },
  { id: 'old', title: 'Old Tasting', startsAt: '2026-10-01T10:00', pricePerGuest: 10, capacity: 5 },
];

const staticDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kb-static-'));
fs.writeFileSync(path.join(staticDir, 'index.html'), '<!doctype html><div id="root"></div>');
afterAll(() => fs.rmSync(staticDir, { recursive: true, force: true }));

function buildApp(overrides: Partial<Parameters<typeof createApp>[0]> = {}) {
  const store = createBookingStore({ tastings, now: () => NOW });
  const staffAuth = createStaffAuth({ password: 'pw', now: () => NOW.getTime() });
  return createApp({ store, staffAuth, ...overrides });
}

const booking = { name: 'Anna Berg', email: 'anna@example.com', guests: 2 };

async function signIn(app: ReturnType<typeof buildApp>): Promise<string> {
  const res = await request(app).post('/api/staff/session').send({ password: 'pw' });
  expect(res.status).toBe(204);
  const cookies = res.headers['set-cookie'] as unknown as string[];
  const cookie = cookies.find((c) => c.startsWith(`${STAFF_COOKIE}=`))!;
  return cookie.split(';')[0];
}

describe('GET /api/tastings', () => {
  it('lists tastings with seats left and whether they are open', async () => {
    const res = await request(buildApp()).get('/api/tastings');
    expect(res.status).toBe(200);
    expect(res.body.map((t: { id: string; seatsLeft: number; open: boolean }) => [t.id, t.seatsLeft, t.open])).toEqual([
      ['t1', 3, true],
      ['old', 5, false],
    ]);
  });

  it('returns 404 JSON for an unknown tasting id', async () => {
    const res = await request(buildApp()).get('/api/tastings/nope');
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: 'Tasting not found.' });
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and returns the summary with total', async () => {
    const res = await request(buildApp()).post('/api/tastings/t1/bookings').send(booking);
    expect(res.status).toBe(201);
    expect(res.body.total).toBe(50);
    expect(res.body.reference).toMatch(/^KB-/);
  });

  it('rejects an out-of-range guest count with the message next to guests', async () => {
    const res = await request(buildApp()).post('/api/tastings/t1/bookings').send({ ...booking, guests: 9 });
    expect(res.status).toBe(400);
    expect(res.body.fieldErrors.guests).toBe(FIELD_MESSAGES.guestsMax);
  });

  it('reports every invalid field at once', async () => {
    const res = await request(buildApp()).post('/api/tastings/t1/bookings').send({ name: '', email: 'x', guests: 1 });
    expect(res.status).toBe(400);
    expect(res.body.fieldErrors).toEqual({
      name: FIELD_MESSAGES.nameRequired,
      email: FIELD_MESSAGES.emailInvalid,
    });
  });

  it('answers 409 with the seats left when the guests do not fit', async () => {
    const app = buildApp();
    await request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 2 });
    const res = await request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 2 });
    expect(res.status).toBe(409);
    expect(res.body.fieldErrors.guests).toBe('Only 1 seat left.');
  });

  it('answers 409 with a fully-booked message when no seats are left', async () => {
    const app = buildApp();
    await request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 3 });
    const res = await request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 1 });
    expect(res.status).toBe(409);
    expect(res.body.fieldErrors.guests).toBe('This tasting is fully booked.');
  });

  it('lets exactly one of two simultaneous requests take the last seat', async () => {
    const app = buildApp();
    await request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 2 }); // 1 seat left
    const [a, b] = await Promise.all([
      request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 1 }),
      request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 1 }),
    ]);
    expect([a.status, b.status].sort()).toEqual([201, 409]);
    expect((await request(app).get('/api/tastings/t1')).body.seatsLeft).toBe(0);
  });

  it('answers 409 for a tasting whose start time has passed', async () => {
    const res = await request(buildApp()).post('/api/tastings/old/bookings').send(booking);
    expect(res.status).toBe(409);
    expect(res.body).toEqual({ error: 'This tasting has already taken place.' });
  });

  it('limits booking attempts per client and answers 429 past the limit', async () => {
    const app = buildApp({ bookingLimit: 2, bookingWindowMs: 60_000 });
    await request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 1 });
    await request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 1 });
    const res = await request(app).post('/api/tastings/t1/bookings').send({ ...booking, guests: 1 });
    expect(res.status).toBe(429);
    expect(res.body.error).toMatch(/Too many booking attempts/);
  });

  it('answers 404 for an unknown tasting', async () => {
    const res = await request(buildApp()).post('/api/tastings/nope/bookings').send(booking);
    expect(res.status).toBe(404);
  });
});

describe('GET /api/bookings/:reference (public)', () => {
  it('returns the summary without name or email', async () => {
    const app = buildApp();
    const created = await request(app).post('/api/tastings/t1/bookings').send(booking);
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ tastingTitle: 'Test Tasting', guests: 2, total: 50 });
    expect(res.body).not.toHaveProperty('name');
    expect(res.body).not.toHaveProperty('email');
  });

  it('returns 404 for an unknown reference', async () => {
    const res = await request(buildApp()).get('/api/bookings/KB-NOPE00');
    expect(res.status).toBe(404);
  });
});

describe('staff session', () => {
  it('refuses a wrong password without setting a cookie', async () => {
    const res = await request(buildApp()).post('/api/staff/session').send({ password: 'wrong' });
    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: 'Incorrect password.' });
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('sets an HttpOnly, SameSite=Strict session cookie on the right password', async () => {
    const res = await request(buildApp()).post('/api/staff/session').send({ password: 'pw' });
    expect(res.status).toBe(204);
    const cookie: string = res.headers['set-cookie'][0];
    expect(cookie).toMatch(new RegExp(`^${STAFF_COOKIE}=`));
    expect(cookie).toMatch(/HttpOnly/);
    expect(cookie).toMatch(/SameSite=Strict/);
    expect(cookie).toMatch(/Path=\//);
    expect(cookie).not.toMatch(/Secure/);
  });

  it('marks the cookie Secure when the request is HTTPS through a trusted proxy', async () => {
    const app = buildApp({ trustProxy: 1 });
    const res = await request(app)
      .post('/api/staff/session')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: 'pw' });
    expect(res.headers['set-cookie'][0]).toMatch(/Secure/);
  });

  it('answers 503 when no staff password is configured', async () => {
    const app = buildApp({ staffAuth: createStaffAuth({ password: undefined }) });
    const res = await request(app).post('/api/staff/session').send({ password: '' });
    expect(res.status).toBe(503);
    expect(res.body).toEqual({ error: 'Staff sign-in is not configured.' });
  });

  it('limits sign-in attempts per window and answers 429', async () => {
    const app = buildApp({ loginLimit: 10, loginWindowMs: 60_000 });
    for (let i = 0; i < 10; i++) {
      const res = await request(app).post('/api/staff/session').send({ password: 'wrong' });
      expect(res.status).toBe(401);
    }
    const res = await request(app).post('/api/staff/session').send({ password: 'pw' });
    expect(res.status).toBe(429);
    expect(res.body.error).toMatch(/Too many/);
  });
});

describe('staff bookings', () => {
  let app: ReturnType<typeof buildApp>;
  beforeEach(() => {
    app = buildApp();
  });

  it('requires a valid session to list bookings', async () => {
    expect((await request(app).get('/api/staff/bookings')).status).toBe(401);
    expect((await request(app).get('/api/staff/bookings').set('Cookie', `${STAFF_COOKIE}=made-up`)).status).toBe(401);
  });

  it('lists bookings grouped by tasting, with name and email, for a signed-in member of staff', async () => {
    await request(app).post('/api/tastings/t1/bookings').send(booking);
    const cookie = await signIn(app);
    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(2);
    expect(res.body[0].tasting.id).toBe('t1');
    expect(res.body[0].bookings[0]).toMatchObject({ name: 'Anna Berg', email: 'anna@example.com', guests: 2 });
  });

  it('cancels a booking, freeing its seats', async () => {
    const created = await request(app).post('/api/tastings/t1/bookings').send(booking);
    const cookie = await signIn(app);
    const del = await request(app).delete(`/api/staff/bookings/${created.body.reference}`).set('Cookie', cookie);
    expect(del.status).toBe(204);
    const list = await request(app).get('/api/tastings');
    expect(list.body[0].seatsLeft).toBe(3);
    const again = await request(app).delete(`/api/staff/bookings/${created.body.reference}`).set('Cookie', cookie);
    expect(again.status).toBe(404);
  });

  it('refuses cancellation without a session', async () => {
    const created = await request(app).post('/api/tastings/t1/bookings').send(booking);
    const res = await request(app).delete(`/api/staff/bookings/${created.body.reference}`);
    expect(res.status).toBe(401);
  });

  it('ends the session on sign-out, so the old cookie stops working', async () => {
    const cookie = await signIn(app);
    const out = await request(app).delete('/api/staff/session').set('Cookie', cookie);
    expect(out.status).toBe(204);
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });
});

describe('HTTP details', () => {
  it('answers malformed JSON with 400 JSON, not an HTML stack trace', async () => {
    const res = await request(buildApp())
      .post('/api/tastings/t1/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ');
    expect(res.status).toBe(400);
    expect(res.headers['content-type']).toMatch(/application\/json/);
    expect(res.body).toEqual({ error: 'Invalid JSON.' });
  });

  it('answers unknown API paths with 404 JSON', async () => {
    const res = await request(buildApp()).get('/api/nothing-here');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/application\/json/);
  });

  it('serves the app shell for deep links such as /staff and /bookings/KB-XXXXXX', async () => {
    const app = buildApp({ staticDir });
    const staff = await request(app).get('/staff');
    expect(staff.status).toBe(200);
    expect(staff.text).toContain('id="root"');
    const deep = await request(app).get('/bookings/KB-ABCDEF');
    expect(deep.status).toBe(200);
  });
});
