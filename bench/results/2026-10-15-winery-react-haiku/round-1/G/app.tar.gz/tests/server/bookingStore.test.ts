import { describe, it, expect } from 'vitest';
import { createBookingStore, isTastingOpen } from '../../src/server/bookingStore';
import type { Tasting } from '../../src/shared/types';

const tastings: Tasting[] = [
  { id: 't1', title: 'Test Tasting', startsAt: '2026-11-06T18:00', pricePerGuest: 25, capacity: 3 },
  { id: 't2', title: 'Other Tasting', startsAt: '2026-12-05T17:00', pricePerGuest: 30, capacity: 2 },
];
const BEFORE = new Date('2026-10-14T12:00:00Z');
const AFTER_T1 = new Date('2026-11-07T00:00:00Z');
const anna = { name: 'Anna Berg', email: 'anna@example.com', guests: 2 };

function makeStore(now: Date = BEFORE) {
  return createBookingStore({ tastings, now: () => now });
}

describe('isTastingOpen', () => {
  it('is open until the Berlin start time, read as CET in November', () => {
    // 18:00 Berlin (UTC+1) is 17:00 UTC
    expect(isTastingOpen('2026-11-06T18:00', new Date('2026-11-06T16:59:00Z'))).toBe(true);
    expect(isTastingOpen('2026-11-06T18:00', new Date('2026-11-06T17:01:00Z'))).toBe(false);
  });

  it('reads December start times as CET too', () => {
    expect(isTastingOpen('2026-12-05T17:00', new Date('2026-12-05T15:59:00Z'))).toBe(true);
    expect(isTastingOpen('2026-12-05T17:00', new Date('2026-12-05T16:01:00Z'))).toBe(false);
  });
});

describe('createBookingStore', () => {
  it('lists every tasting with all seats free and open before its start', () => {
    const list = makeStore().listTastings();
    expect(list.map((t) => [t.id, t.seatsLeft, t.open])).toEqual([
      ['t1', 3, true],
      ['t2', 2, true],
    ]);
  });

  it('reduces seats left by the guests of an accepted booking', () => {
    const store = makeStore();
    const result = store.createBooking('t1', anna);
    expect(result.ok).toBe(true);
    expect(store.getTasting('t1')!.seatsLeft).toBe(1);
  });

  it('refuses a booking larger than the seats left and changes nothing', () => {
    const store = makeStore();
    store.createBooking('t1', anna); // 2 of 3 taken
    const result = store.createBooking('t1', { ...anna, guests: 2 });
    expect(result).toEqual({ ok: false, reason: 'not-enough-seats', seatsLeft: 1 });
    expect(store.getTasting('t1')!.seatsLeft).toBe(1);
  });

  it('refuses a booking for an unknown tasting', () => {
    expect(makeStore().createBooking('nope', anna)).toEqual({ ok: false, reason: 'unknown-tasting' });
  });

  it('refuses every booking once the tasting is full', () => {
    const store = makeStore();
    store.createBooking('t2', { ...anna, guests: 2 });
    expect(store.getTasting('t2')!.seatsLeft).toBe(0);
    expect(store.createBooking('t2', { ...anna, guests: 1 })).toEqual({
      ok: false,
      reason: 'not-enough-seats',
      seatsLeft: 0,
    });
  });

  it('refuses bookings for a tasting whose start time has passed, without reporting seats', () => {
    const store = makeStore(AFTER_T1);
    expect(store.getTasting('t1')!.open).toBe(false);
    expect(store.createBooking('t1', anna)).toEqual({ ok: false, reason: 'closed' });
    expect(store.getTasting('t1')!.seatsLeft).toBe(3);
  });

  it('cancelling frees the seats and reports whether a booking existed', () => {
    const store = makeStore();
    const ref = (store.createBooking('t1', anna) as { ok: true; reference: string }).reference;
    expect(store.cancelBooking(ref)).toBe(true);
    expect(store.getTasting('t1')!.seatsLeft).toBe(3);
    expect(store.cancelBooking(ref)).toBe(false);
  });

  it('gives the public summary tasting, guests, total and reference, without name or email', () => {
    const store = makeStore();
    const { reference } = store.createBooking('t1', anna) as { ok: true; reference: string };
    const summary = store.getBookingSummary(reference)!;
    expect(summary).toEqual({
      reference,
      tastingId: 't1',
      tastingTitle: 'Test Tasting',
      startsAt: '2026-11-06T18:00',
      guests: 2,
      pricePerGuest: 25,
      total: 50,
    });
    expect(Object.keys(summary)).not.toContain('name');
    expect(Object.keys(summary)).not.toContain('email');
  });

  it('returns no summary for an unknown reference', () => {
    expect(makeStore().getBookingSummary('KB-NOPE00')).toBeUndefined();
  });

  it('issues references in the KB-XXXXXX format without look-alike characters', () => {
    const store = makeStore();
    const { reference } = store.createBooking('t1', anna) as { ok: true; reference: string };
    expect(reference).toMatch(/^KB-[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{6}$/);
  });

  it('issues a different reference when a random draw collides with an existing one', () => {
    // First booking draws six 0s (reference KB-222222). The next six draws are 0s again,
    // so the store must regenerate; the following draws are 1s, giving KB-333333.
    let calls = 0;
    const store = createBookingStore({
      tastings,
      now: () => BEFORE,
      random: () => (calls++ < 12 ? 0 : 1),
    });
    const first = (store.createBooking('t1', { ...anna, guests: 1 }) as { reference: string }).reference;
    const second = (store.createBooking('t1', { ...anna, guests: 1 }) as { reference: string }).reference;
    expect(second).not.toBe(first);
  });

  it('groups bookings by tasting, including empty tastings, with name and email for staff', () => {
    const store = makeStore();
    store.createBooking('t1', anna);
    const groups = store.listBookingsGrouped();
    expect(groups.map((g) => g.tasting.id)).toEqual(['t1', 't2']);
    expect(groups[0].bookings).toHaveLength(1);
    expect(groups[0].bookings[0]).toMatchObject({ name: 'Anna Berg', email: 'anna@example.com', guests: 2 });
    expect(groups[1].bookings).toEqual([]);
  });
});
