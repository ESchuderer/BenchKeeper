import { describe, it, expect } from 'vitest';
import { createStaffAuth } from '../../src/server/staffAuth';

describe('createStaffAuth', () => {
  it('accepts exactly the configured password', () => {
    const auth = createStaffAuth({ password: 'secret' });
    expect(auth.configured).toBe(true);
    expect(auth.checkPassword('secret')).toBe(true);
    expect(auth.checkPassword('Secret')).toBe(false);
    expect(auth.checkPassword('secret ')).toBe(false);
    expect(auth.checkPassword('')).toBe(false);
  });

  it('is not configured when the password is unset or empty, and then accepts nothing', () => {
    for (const password of [undefined, '']) {
      const auth = createStaffAuth({ password });
      expect(auth.configured).toBe(false);
      expect(auth.checkPassword('')).toBe(false);
      expect(auth.checkPassword('anything')).toBe(false);
    }
  });

  it('issues a session that is valid until it is ended', () => {
    const auth = createStaffAuth({ password: 'secret' });
    const token = auth.createSession();
    expect(auth.isValidSession(token)).toBe(true);
    expect(auth.isValidSession('made-up')).toBe(false);
    expect(auth.isValidSession(undefined)).toBe(false);
    auth.endSession(token);
    expect(auth.isValidSession(token)).toBe(false);
  });

  it('expires a session after its lifetime', () => {
    let clock = 1_000;
    const auth = createStaffAuth({ password: 'secret', now: () => clock, sessionMs: 500 });
    const token = auth.createSession();
    clock = 1_499;
    expect(auth.isValidSession(token)).toBe(true);
    clock = 1_500;
    expect(auth.isValidSession(token)).toBe(false);
  });

  it('issues unguessable, distinct tokens', () => {
    const auth = createStaffAuth({ password: 'secret' });
    const a = auth.createSession();
    const b = auth.createSession();
    expect(a).not.toBe(b);
    expect(a.length).toBeGreaterThanOrEqual(40);
  });
});
