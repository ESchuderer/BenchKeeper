import { describe, it, expect } from 'vitest';
import { bookingInputSchema, FIELD_MESSAGES } from '../../src/shared/schemas';

describe('bookingInputSchema', () => {
  const valid = { name: 'Anna Berg', email: 'anna@example.com', guests: 2 };

  it('accepts a valid booking', () => {
    expect(bookingInputSchema.safeParse(valid).success).toBe(true);
  });

  it('trims the name and email', () => {
    const r = bookingInputSchema.parse({ ...valid, name: '  Anna  ', email: ' a@b.de ' });
    expect(r.name).toBe('Anna');
    expect(r.email).toBe('a@b.de');
  });

  it.each([
    ['name', { name: '   ' }, FIELD_MESSAGES.nameRequired],
    ['name', { name: '​​' }, FIELD_MESSAGES.nameRequired],
    ['name', { name: 'x'.repeat(101) }, FIELD_MESSAGES.nameTooLong],
    ['email', { email: '' }, FIELD_MESSAGES.emailRequired],
    ['email', { email: 'anna example.com' }, FIELD_MESSAGES.emailInvalid],
    ['email', { email: 'anna@' }, FIELD_MESSAGES.emailInvalid],
    ['guests', { guests: 0 }, FIELD_MESSAGES.guestsMin],
    ['guests', { guests: 9 }, FIELD_MESSAGES.guestsMax],
    ['guests', { guests: 2.5 }, FIELD_MESSAGES.guestsWhole],
    ['guests', { guests: Number.NaN }, FIELD_MESSAGES.guestsWhole],
    ['guests', { guests: undefined }, FIELD_MESSAGES.guestsRequired],
    ['guests', { guests: '2' }, FIELD_MESSAGES.guestsWhole],
  ])('rejects bad %s with its message', (field, patch, message) => {
    const r = bookingInputSchema.safeParse({ ...valid, ...patch });
    expect(r.success).toBe(false);
    const issue = r.error!.issues.find((i) => i.path[0] === field);
    expect(issue?.message).toBe(message);
  });
});
