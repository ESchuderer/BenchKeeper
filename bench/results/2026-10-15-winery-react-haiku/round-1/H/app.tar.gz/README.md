# Weingut Kieselbrunnen – wine tasting bookings

A small web app where guests book wine tastings online and winery staff see and manage the bookings.

- **Guests** see the tastings with date, price per guest and seats left, book seats with a form, and get a confirmation with a booking reference.
- **Staff** sign in at `/staff` with a shared password, see all bookings grouped by tasting, and cancel bookings to free their seats.

Stack: React 19 with React Router and React Hook Form, Tailwind CSS, Express 5 for the JSON API, Zod for validation shared by browser and server, and a JSON file for storage. No external services.

## Requirements

- Node.js 22

## Install, build, run

```bash
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start
```

Then open http://localhost:3000.

## Configuration

| Variable | Required | Default | Purpose |
|---|---|---|---|
| `STAFF_PASSWORD` | yes | – | Password for `/staff`. The server refuses to start without it. |
| `PORT` | no | `3000` | Port the app listens on. |
| `DATA_FILE` | no | `data/bookings.json` | Where bookings are stored. Created on the first booking. |
| `TRUST_PROXY` | no | off | Set to `true` when running behind a reverse proxy, so rate limits use the client address the proxy forwards. |
| `NODE_ENV` | no | – | `production` marks the staff cookie `Secure` (serve the app over HTTPS). |

The app starts with no bookings. Bookings survive restarts through `DATA_FILE`. Staff sessions are kept in memory, so staff sign in again after a restart.

## Development

```bash
STAFF_PASSWORD=dev npm run dev:server   # API on PORT (default 3000)
npm run dev:client                      # Vite on 5173, proxies /api to the API
```

## Tests and checks

```bash
npm test                 # unit, API, and component tests
npm run test:coverage    # coverage for server and shared code (threshold 80%)
npm run typecheck        # TypeScript for the browser and server code
```

## Layout

```
client/     React app (pages, components, API client)
server/     Express app: routes, booking store, staff sessions
shared/     Tasting catalogue, booking validation schema, API types
tests/      Vitest suites for shared, server, and client code
openspec/   Specification and change history (OpenSpec)
```

The tasting catalogue is in `shared/tastings.ts`. Edit it there to change titles, dates, prices or seat counts.

## Behaviour notes

- Bookings are checked against the seats left on the server at the moment they are made, so two guests cannot take the same last seats.
- Booking references look like `KB-7QXM2D` and avoid look-alike characters.
- Guests can only see the reference, tasting, guest count and total on their confirmation. Names and emails are only visible to staff.
- Login attempts are limited to 10 failed attempts per 15 minutes per client; bookings to 30 per 15 minutes per client.
- Cancellation is final: a cancelled booking is removed and its seats are released.
- The JSON file is written atomically (temporary file, then rename). The store is single-process; run one server instance.

## Specification

The requirements and scenarios are in `openspec/changes/tasting-bookings/`: the proposal, the two capability specs under `specs/`, the design, and the task list.

## Known gaps

Found in review and not yet addressed. Each needs a product decision before it is built:

- **Seat hoarding:** anyone can book seats with any email address, and staff can only free them by hand. Email confirmation, expiring unconfirmed holds, or per-email limits would address this.
- **Retry after a lost response:** if the connection drops after the server has booked, a retry books again. An idempotency key per form submission would prevent it.
- **Staff password:** only a non-empty value is required. Use a long, random value.
- **Staff cookie:** `Secure` is set only when `NODE_ENV=production`. Set `NODE_ENV=production` for any HTTPS deployment.
- **Audit trail:** logins and cancellations are not logged, and staff sessions cannot be revoked individually.
- **Durability:** the JSON file is replaced atomically but not fsynced, so a power loss during a write can leave an empty file. Startup then refuses to run, so no bookings are silently lost.
- **Browser testing:** the component tests and HTTP smoke tests pass, but the layout at phone and desktop widths has not been checked in a real browser.
