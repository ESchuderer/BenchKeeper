import type {
  ApiFieldErrors,
  BookingConfirmation,
  StaffSessionState,
  StaffTastingGroup,
  TastingView,
} from "../shared/api.js";
import type { BookingInput } from "../shared/bookingSchema.js";

export const NETWORK_ERROR_CODE = "NETWORK_ERROR";
const NETWORK_ERROR_MESSAGE = "We could not reach the server. Check your connection and try again.";
const UNEXPECTED_ERROR_MESSAGE = "Something went wrong. Please try again.";

export class ApiRequestError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly fields: ApiFieldErrors = {},
  ) {
    super(message);
    this.name = "ApiRequestError";
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Accept", "application/json");
  if (init.body !== undefined) headers.set("Content-Type", "application/json");

  let response: Response;
  try {
    response = await fetch(path, { ...init, headers, credentials: "same-origin" });
  } catch {
    throw new ApiRequestError(0, NETWORK_ERROR_CODE, NETWORK_ERROR_MESSAGE);
  }

  if (response.status === 204) return undefined as T;

  const payload: unknown = await response.json().catch(() => null);
  if (!response.ok) {
    const error = readError(payload);
    throw new ApiRequestError(
      response.status,
      error?.code ?? "UNKNOWN",
      error?.message ?? UNEXPECTED_ERROR_MESSAGE,
      error?.fields,
    );
  }
  if (typeof payload !== "object" || payload === null || !("data" in payload)) {
    throw new ApiRequestError(response.status, "INVALID_RESPONSE", UNEXPECTED_ERROR_MESSAGE);
  }
  return payload.data as T;
}

function readError(payload: unknown): { code?: string; message?: string; fields?: ApiFieldErrors } | undefined {
  if (typeof payload !== "object" || payload === null || !("error" in payload)) return undefined;
  return payload.error as { code?: string; message?: string; fields?: ApiFieldErrors };
}

const segment = encodeURIComponent;

export const api = {
  listTastings: () => request<TastingView[]>("/api/tastings"),

  getTasting: (id: string) => request<TastingView>(`/api/tastings/${segment(id)}`),

  createBooking: (tastingId: string, input: BookingInput) =>
    request<BookingConfirmation>(`/api/tastings/${segment(tastingId)}/bookings`, {
      method: "POST",
      body: JSON.stringify(input),
    }),

  getBooking: (reference: string) => request<BookingConfirmation>(`/api/bookings/${segment(reference)}`),

  getStaffSession: () => request<StaffSessionState>("/api/staff/session"),

  signIn: (password: string) =>
    request<StaffSessionState>("/api/staff/session", {
      method: "POST",
      body: JSON.stringify({ password }),
    }),

  signOut: () => request<void>("/api/staff/session", { method: "DELETE" }),

  listStaffBookings: () => request<StaffTastingGroup[]>("/api/staff/bookings"),

  cancelBooking: (reference: string) =>
    request<void>(`/api/staff/bookings/${segment(reference)}`, { method: "DELETE" }),
};
