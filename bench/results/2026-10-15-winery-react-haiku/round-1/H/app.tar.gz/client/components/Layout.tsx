import { Link, Outlet } from "react-router";

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b border-gold-500/40 bg-wine-900 text-cream-50">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-5">
          <Link to="/" className="group flex flex-col no-underline">
            <span className="font-serif text-2xl tracking-wide group-hover:text-gold-300">Weingut Kieselbrunnen</span>
            <span className="text-xs uppercase tracking-[0.2em] text-gold-300">Family winery · Wine tastings</span>
          </Link>
          <nav aria-label="Main">
            <Link to="/" className="text-sm font-semibold text-cream-50 hover:text-gold-300">
              All tastings
            </Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-10">
        <Outlet />
      </main>

      <footer className="border-t border-gold-500/30 bg-cream-100">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-5 py-6 text-sm text-ink-600">
          <span>Weingut Kieselbrunnen · Family winery</span>
          <Link to="/staff" className="font-medium text-wine-700 hover:underline">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}
