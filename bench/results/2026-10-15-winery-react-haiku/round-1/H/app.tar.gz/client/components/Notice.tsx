import type { ReactNode } from "react";

interface NoticeProps {
  tone: "error" | "info";
  children: ReactNode;
}

/** Errors use role="alert" so screen readers announce them at once. */
export function Notice({ tone, children }: NoticeProps) {
  const styles =
    tone === "error"
      ? "border-danger-700/30 bg-danger-50 text-danger-700"
      : "border-wine-600/20 bg-cream-100 text-ink-800";
  return (
    <div role={tone === "error" ? "alert" : "status"} className={`rounded-lg border px-4 py-3 text-sm font-medium ${styles}`}>
      {children}
    </div>
  );
}
