import type { ReactNode } from "react";

export function PageHeading({ children, lead }: { children: ReactNode; lead?: ReactNode }) {
  return (
    <header className="mb-8">
      <h1 className="font-serif text-3xl text-wine-900 sm:text-4xl">{children}</h1>
      {lead && <p className="mt-2 max-w-2xl text-base text-ink-600">{lead}</p>}
    </header>
  );
}
