import { useId } from "react";
import { Link } from "react-router";
import type { TastingView } from "../../shared/api.js";
import { formatEuros, formatSeatsLeft, formatTastingDate, formatTastingTime } from "../../shared/tastings.js";

export function TastingCard({ tasting }: { tasting: TastingView }) {
  const titleId = useId();
  const isFullyBooked = tasting.seatsLeft === 0;

  return (
    <article
      aria-labelledby={titleId}
      className="flex h-full flex-col rounded-2xl border border-cream-200 bg-white p-6 shadow-sm"
    >
      <div className="flex items-start justify-between gap-3">
        <h2 id={titleId} className="font-serif text-2xl text-wine-900">
          {tasting.title}
        </h2>
        {isFullyBooked && (
          <span className="shrink-0 rounded-full bg-cream-200 px-3 py-1 text-xs font-bold uppercase tracking-wide text-ink-600">
            Fully booked
          </span>
        )}
      </div>

      <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm text-ink-800">
        <dt className="text-ink-600">When</dt>
        <dd>
          <time dateTime={tasting.startsAt}>{formatTastingDate(tasting.startsAt)}</time>,{" "}
          <span>{formatTastingTime(tasting.startsAt)}</span>
        </dd>
        <dt className="text-ink-600">Price</dt>
        <dd className="font-semibold">{`${formatEuros(tasting.pricePerGuest)} per guest`}</dd>
        {!isFullyBooked && (
          <>
            <dt className="text-ink-600">Availability</dt>
            <dd className="font-semibold text-success-700">{formatSeatsLeft(tasting.seatsLeft)}</dd>
          </>
        )}
      </dl>

      <div className="mt-auto pt-6">
        {isFullyBooked ? (
          <p className="text-sm text-ink-600">No seats are available for this tasting.</p>
        ) : (
          <Link
            to={`/tastings/${tasting.id}/book`}
            className="inline-flex w-full items-center justify-center rounded-lg bg-wine-700 px-5 py-3 text-base font-semibold text-cream-50 no-underline shadow-sm transition hover:bg-wine-600 focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-gold-500 sm:w-auto"
          >
            {`Book ${tasting.title}`}
          </Link>
        )}
      </div>
    </article>
  );
}
