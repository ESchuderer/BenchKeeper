import { useId, type ComponentProps } from "react";

interface TextFieldProps extends ComponentProps<"input"> {
  label: string;
  error?: string;
}

/** A labelled input whose error message is announced with the field. */
export function TextField({ label, error, ...inputProps }: TextFieldProps) {
  const id = useId();
  const errorId = `${id}-error`;
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-semibold text-ink-800">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className={`rounded-lg border bg-white px-3.5 py-2.5 text-base text-ink-800 shadow-sm outline-none transition focus:ring-4 ${
          error
            ? "border-danger-700 focus:border-danger-700 focus:ring-danger-100"
            : "border-cream-200 focus:border-wine-600 focus:ring-wine-100"
        }`}
        {...inputProps}
      />
      {error && (
        <p id={errorId} className="text-sm font-medium text-danger-700">
          {error}
        </p>
      )}
    </div>
  );
}
