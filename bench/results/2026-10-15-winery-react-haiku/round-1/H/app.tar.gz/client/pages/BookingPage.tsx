import { zodResolver } from "@hookform/resolvers/zod";
import { useRef, useState } from "react";
import { useForm, type Resolver, type SubmitHandler } from "react-hook-form";
import { Link, useNavigate, useParams } from "react-router";
import type { TastingView } from "../../shared/api.js";
import { bookingSchemaForSeats, type BookingInput } from "../../shared/bookingSchema.js";
import { formatEuros, formatSeatsLeft, formatTastingDate, formatTastingTime } from "../../shared/tastings.js";
import { ApiRequestError, api } from "../api.js";
import { Notice } from "../components/Notice.js";
import { PageHeading } from "../components/PageHeading.js";
import { TextField } from "../components/TextField.js";
import { useLoad } from "../useLoad.js";

type FormValues = {
  name: string;
  email: string;
  guests: string;
};

const FORM_FIELDS: readonly (keyof FormValues)[] = ["name", "email", "guests"];
const UNEXPECTED_ERROR = "Something went wrong. Please try again.";

export function BookingPage() {
  const { id = "" } = useParams();
  const tasting = useLoad(() => api.getTasting(id), id);

  return (
    <>
      {tasting.status === "loading" && <p role="status" className="text-ink-600">Loading tasting…</p>}
      {tasting.status === "error" && (
        <>
          <Notice tone="error">{tasting.error.message}</Notice>
          <BackToTastings />
        </>
      )}
      {tasting.status === "ready" && <BookingForm tasting={tasting.data} onSeatsChanged={tasting.reload} />}
    </>
  );
}

function BookingForm({ tasting, onSeatsChanged }: { tasting: TastingView; onSeatsChanged: () => void }) {
  const navigate = useNavigate();
  const [formError, setFormError] = useState<string | null>(null);
  const isFullyBooked = tasting.seatsLeft === 0;

  // The resolver reads the latest seat count, so a refetch after a seat conflict updates the limit.
  const seatsLeftRef = useRef(tasting.seatsLeft);
  seatsLeftRef.current = tasting.seatsLeft;
  const seatAwareResolver: Resolver<FormValues, undefined, BookingInput> = (values, context, options) =>
    (zodResolver(bookingSchemaForSeats(seatsLeftRef.current)) as unknown as Resolver<FormValues, undefined, BookingInput>)(
      values,
      context,
      options,
    );

  const {
    register,
    handleSubmit,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<FormValues, undefined, BookingInput>({
    // The seat limit is part of the schema, so the browser refuses impossible bookings before sending them.
    resolver: seatAwareResolver,
    defaultValues: { name: "", email: "", guests: "1" },
  });

  const guestCount = Number(watch("guests"));
  const total = Number.isInteger(guestCount) && guestCount > 0 ? guestCount * tasting.pricePerGuest : null;

  const onValid: SubmitHandler<BookingInput> = async (input) => {
    setFormError(null);
    try {
      const booking = await api.createBooking(tasting.id, input);
      navigate(`/bookings/${encodeURIComponent(booking.reference)}`);
    } catch (error) {
      showSubmitError(error, setError, setFormError, onSeatsChanged);
    }
  };

  return (
    <>
      <PageHeading lead={`${formatTastingDate(tasting.startsAt)}, ${formatTastingTime(tasting.startsAt)} · ${formatEuros(tasting.pricePerGuest)} per guest`}>
        {tasting.title}
      </PageHeading>

      {isFullyBooked ? (
        <>
          <Notice tone="info">This tasting is fully booked. Please choose another tasting.</Notice>
          <BackToTastings />
        </>
      ) : (
        <div className="grid gap-8 md:grid-cols-[1fr_18rem]">
          <form
            noValidate
            onSubmit={handleSubmit(onValid)}
            aria-label={`Booking form for ${tasting.title}`}
            className="flex flex-col gap-5 rounded-2xl border border-cream-200 bg-white p-6 shadow-sm"
          >
            {formError && <Notice tone="error">{formError}</Notice>}

            <TextField
              label="Name"
              autoComplete="name"
              error={errors.name?.message}
              {...register("name")}
            />
            <TextField
              label="Email"
              type="email"
              inputMode="email"
              autoComplete="email"
              error={errors.email?.message}
              {...register("email")}
            />
            <TextField
              label="Guests"
              type="number"
              inputMode="numeric"
              min={1}
              max={8}
              step={1}
              error={errors.guests?.message}
              {...register("guests")}
            />

            <button
              type="submit"
              disabled={isSubmitting}
              className="mt-2 inline-flex items-center justify-center rounded-lg bg-wine-700 px-5 py-3 text-base font-semibold text-cream-50 shadow-sm transition hover:bg-wine-600 disabled:cursor-not-allowed disabled:opacity-60 focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-gold-500"
            >
              Book
            </button>
          </form>

          <aside className="h-fit rounded-2xl border border-gold-500/40 bg-gold-100 p-6 text-sm text-ink-800">
            <h2 className="font-serif text-xl text-wine-900">Your visit</h2>
            <p className="mt-3">{formatSeatsLeft(tasting.seatsLeft)}</p>
            <p className="mt-2">{total === null ? "Total: enter a number of guests" : `Total: ${formatEuros(total)}`}</p>
            <p className="mt-4 text-ink-600">Up to 8 guests can book together.</p>
          </aside>
        </div>
      )}

      {!isFullyBooked && <BackToTastings />}
    </>
  );
}

function BackToTastings() {
  return (
    <p className="mt-8">
      <Link to="/" className="font-semibold text-wine-700 hover:underline">
        ← Back to all tastings
      </Link>
    </p>
  );
}

function isFormField(field: string): field is keyof FormValues {
  return (FORM_FIELDS as readonly string[]).includes(field);
}

/** Field problems appear next to their field; anything else appears at the top of the form. */
function showSubmitError(
  error: unknown,
  setError: (field: keyof FormValues, issue: { type: string; message: string }) => void,
  setFormError: (message: string) => void,
  onSeatsChanged: () => void,
): void {
  if (!(error instanceof ApiRequestError)) {
    setFormError(UNEXPECTED_ERROR);
    return;
  }
  if (error.code === "SEATS_UNAVAILABLE") onSeatsChanged();
  const fieldNames = Object.keys(error.fields).filter(isFormField);
  if (fieldNames.length === 0) {
    setFormError(error.message);
    return;
  }
  for (const field of fieldNames) {
    setError(field, { type: "server", message: error.fields[field] });
  }
}

