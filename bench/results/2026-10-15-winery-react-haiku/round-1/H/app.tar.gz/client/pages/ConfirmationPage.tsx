import { Link, useParams } from "react-router";
import { formatEuros, formatTastingDate, formatTastingTime } from "../../shared/tastings.js";
import { api } from "../api.js";
import { Notice } from "../components/Notice.js";
import { useLoad } from "../useLoad.js";
import { useId } from "react";

export function ConfirmationPage() {
  const { reference = "" } = useParams();
  const booking = useLoad(() => api.getBooking(reference), reference);
  const headingId = useId();

  if (booking.status === "loading") return <p role="status" className="text-ink-600">Loading your booking…</p>;

  if (booking.status === "error") {
    return (
      <>
        <Notice tone="error">{booking.error.message}</Notice>
        <p className="mt-8">
          <Link to="/" className="font-semibold text-wine-700 hover:underline">
            ← Back to all tastings
          </Link>
        </p>
      </>
    );
  }

  const { data } = booking;
  return (
    <section aria-labelledby={headingId} className="mx-auto max-w-2xl rounded-2xl border border-cream-200 bg-white p-8 shadow-sm">
      <p className="text-sm font-bold uppercase tracking-[0.2em] text-success-700">Thank you</p>
      <h1 id={headingId} className="mt-2 font-serif text-3xl text-wine-900 sm:text-4xl">
        Booking confirmed
      </h1>
      <p className="mt-3 text-ink-600">
        We look forward to welcoming you. Please keep your booking reference for your visit.
      </p>

      <dl className="mt-8 grid grid-cols-[auto_1fr] gap-x-6 gap-y-4 border-t border-cream-200 pt-6 text-base">
        <dt className="text-ink-600">Tasting</dt>
        <dd className="font-semibold text-ink-800">{data.tastingTitle}</dd>
        <dt className="text-ink-600">When</dt>
        <dd className="text-ink-800">
          {formatTastingDate(data.startsAt)}, {formatTastingTime(data.startsAt)}
        </dd>
        <dt className="text-ink-600">Guests</dt>
        <dd className="text-ink-800">{data.guests}</dd>
        <dt className="text-ink-600">Total</dt>
        <dd className="font-semibold text-ink-800">{formatEuros(data.total)}</dd>
        <dt className="text-ink-600">Booking reference</dt>
        <dd className="font-mono text-lg font-semibold tracking-wider text-wine-900">{data.reference}</dd>
      </dl>

      <p className="mt-8">
        <Link to="/" className="font-semibold text-wine-700 hover:underline">
          ← Back to all tastings
        </Link>
      </p>
    </section>
  );
}
