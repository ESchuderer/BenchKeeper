import { Link } from "react-router";

export function NotFoundPage() {
  return (
    <section className="mx-auto max-w-md text-center">
      <h1 className="font-serif text-3xl text-wine-900">Page not found</h1>
      <p className="mt-3 text-ink-600">The page you are looking for does not exist.</p>
      <Link to="/" className="mt-6 inline-block font-semibold text-wine-700 hover:underline">
        Back to all tastings
      </Link>
    </section>
  );
}
