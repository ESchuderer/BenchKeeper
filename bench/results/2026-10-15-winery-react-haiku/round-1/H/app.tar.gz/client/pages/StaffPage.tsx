import { useEffect, useId, useState } from "react";
import { useForm } from "react-hook-form";
import type { StaffTastingGroup } from "../../shared/api.js";
import { formatSeatsLeft, formatTastingDate, formatTastingTime } from "../../shared/tastings.js";
import { ApiRequestError, api } from "../api.js";
import { Notice } from "../components/Notice.js";
import { PageHeading } from "../components/PageHeading.js";
import { TextField } from "../components/TextField.js";
import { useLoad } from "../useLoad.js";

/** A 401 means the session has ended (expired, or the server restarted). */
function isSessionEnded(error: unknown): boolean {
  return error instanceof ApiRequestError && error.status === 401;
}

export function StaffPage() {
  const session = useLoad(api.getStaffSession, "staff-session");

  if (session.status === "loading") return <p role="status" className="text-ink-600">Loading…</p>;
  if (session.status === "error") return <Notice tone="error">{session.error.message}</Notice>;
  return <StaffArea initiallySignedIn={session.data.authenticated} />;
}

function StaffArea({ initiallySignedIn }: { initiallySignedIn: boolean }) {
  const [signedIn, setSignedIn] = useState(initiallySignedIn);
  return signedIn ? (
    <StaffBookings onSignedOut={() => setSignedIn(false)} />
  ) : (
    <SignInForm onSignedIn={() => setSignedIn(true)} />
  );
}

function SignInForm({ onSignedIn }: { onSignedIn: () => void }) {
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({ defaultValues: { password: "" } });

  const submit = handleSubmit(async ({ password }) => {
    setFormError(null);
    try {
      await api.signIn(password);
      onSignedIn();
    } catch (error) {
      const passwordError = error instanceof ApiRequestError ? error.fields.password : undefined;
      if (passwordError) {
        setError("password", { type: "server", message: passwordError });
      } else {
        setFormError(error instanceof Error ? error.message : "Something went wrong. Please try again.");
      }
    }
  });

  return (
    <>
      <PageHeading lead="Staff only. Enter the staff password to see and manage bookings.">Staff sign-in</PageHeading>
      <form
        noValidate
        onSubmit={submit}
        aria-label="Staff sign-in"
        className="mx-auto flex max-w-sm flex-col gap-5 rounded-2xl border border-cream-200 bg-white p-6 shadow-sm"
      >
        {formError && <Notice tone="error">{formError}</Notice>}
        <TextField
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          {...register("password", { required: "Please enter the password." })}
        />
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex items-center justify-center rounded-lg bg-wine-700 px-5 py-3 text-base font-semibold text-cream-50 shadow-sm transition hover:bg-wine-600 disabled:opacity-60 focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-gold-500"
        >
          Sign in
        </button>
      </form>
    </>
  );
}

function StaffBookings({ onSignedOut }: { onSignedOut: () => void }) {
  const groups = useLoad(api.listStaffBookings, "staff-bookings");
  const [actionError, setActionError] = useState<string | null>(null);
  const sessionEnded = groups.status === "error" && isSessionEnded(groups.error);

  useEffect(() => {
    if (sessionEnded) onSignedOut();
  }, [sessionEnded, onSignedOut]);

  const cancel = async (reference: string, guestName: string) => {
    if (!window.confirm(`Cancel the booking for ${guestName} (${reference})? Its seats will be released.`)) return;
    setActionError(null);
    try {
      await api.cancelBooking(reference);
      groups.reload();
    } catch (error) {
      if (isSessionEnded(error)) {
        onSignedOut();
        return;
      }
      // Someone else may already have cancelled it: refresh so the list matches the server.
      if (error instanceof ApiRequestError && error.status === 404) groups.reload();
      setActionError(error instanceof Error ? error.message : "The booking could not be cancelled.");
    }
  };

  const signOut = async () => {
    setActionError(null);
    try {
      await api.signOut();
      onSignedOut();
    } catch (error) {
      setActionError(error instanceof Error ? error.message : "Could not sign out. Please try again.");
    }
  };

  return (
    <>
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <PageHeading lead="All bookings, grouped by tasting.">Staff bookings</PageHeading>
        <button
          type="button"
          onClick={signOut}
          className="mb-8 rounded-lg border border-wine-700 px-4 py-2 text-sm font-semibold text-wine-700 transition hover:bg-wine-700 hover:text-cream-50"
        >
          Sign out
        </button>
      </div>

      {actionError && <Notice tone="error">{actionError}</Notice>}
      {groups.refreshError && (
        <Notice tone="error">
          The list could not be refreshed: {groups.refreshError.message} The seats shown may be out of date.
        </Notice>
      )}
      {groups.status === "loading" && <p role="status" className="text-ink-600">Loading bookings…</p>}
      {groups.status === "error" && <Notice tone="error">{groups.error.message}</Notice>}
      {groups.status === "ready" && (
        <div className="flex flex-col gap-8">
          {groups.data.map((group) => (
            <TastingBookings key={group.id} group={group} onCancel={cancel} />
          ))}
        </div>
      )}
    </>
  );
}

function TastingBookings({
  group,
  onCancel,
}: {
  group: StaffTastingGroup;
  onCancel: (reference: string, guestName: string) => void;
}) {
  const headingId = useId();
  return (
    <section aria-labelledby={headingId} className="rounded-2xl border border-cream-200 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 id={headingId} className="font-serif text-2xl text-wine-900">
          {group.title}
        </h2>
        <p className="text-sm text-ink-600">
          {formatTastingDate(group.startsAt)}, {formatTastingTime(group.startsAt)}
        </p>
      </div>
      <p className="mt-1 text-sm font-semibold text-success-700">{formatSeatsLeft(group.seatsLeft)}</p>

      {group.bookings.length === 0 ? (
        <p className="mt-5 text-ink-600">No bookings yet.</p>
      ) : (
        <div className="mt-5 overflow-x-auto">
          <table className="w-full min-w-[32rem] text-left text-sm">
            <thead className="border-b border-cream-200 text-ink-600">
              <tr>
                <th scope="col" className="py-2 pr-4 font-semibold">Name</th>
                <th scope="col" className="py-2 pr-4 font-semibold">Email</th>
                <th scope="col" className="py-2 pr-4 font-semibold">Guests</th>
                <th scope="col" className="py-2 pr-4 font-semibold">Reference</th>
                <th scope="col" className="py-2"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cream-100">
              {group.bookings.map((booking) => (
                <tr key={booking.reference}>
                  <td className="py-3 pr-4 font-medium text-ink-800">{booking.name}</td>
                  <td className="py-3 pr-4 text-ink-800">{booking.email}</td>
                  <td className="py-3 pr-4">{booking.guests}</td>
                  <td className="py-3 pr-4 font-mono text-ink-800">{booking.reference}</td>
                  <td className="py-3 text-right">
                    <button
                      type="button"
                      onClick={() => onCancel(booking.reference, booking.name)}
                      className="rounded-md border border-danger-700 px-3 py-1.5 text-xs font-semibold text-danger-700 transition hover:bg-danger-700 hover:text-white"
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
