import { api } from "../api.js";
import { Notice } from "../components/Notice.js";
import { PageHeading } from "../components/PageHeading.js";
import { TastingCard } from "../components/TastingCard.js";
import { useLoad } from "../useLoad.js";

export function TastingsPage() {
  const tastings = useLoad(api.listTastings, "tastings");

  return (
    <>
      <PageHeading lead="Join us at the cellar door for an evening or an afternoon with our wines. Choose a tasting and reserve your seats online.">
        Wine tastings
      </PageHeading>

      {tastings.status === "loading" && <p role="status" className="text-ink-600">Loading tastings…</p>}

      {tastings.status === "error" && (
        <Notice tone="error">
          We could not load the tastings. {tastings.error.message} Please refresh the page to try again.
        </Notice>
      )}

      {tastings.status === "ready" && (
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {tastings.data.map((tasting) => (
            <li key={tasting.id} className="flex">
              <TastingCard tasting={tasting} />
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
