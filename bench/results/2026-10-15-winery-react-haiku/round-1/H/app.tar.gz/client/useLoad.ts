import { useCallback, useEffect, useState } from "react";

export type LoadState<T> =
  | { status: "loading" }
  | { status: "ready"; data: T }
  | { status: "error"; error: Error };

interface Tracked<T> {
  key: string;
  load: LoadState<T>;
  /** Set when a refetch fails; the data on screen is kept. */
  refreshError: Error | null;
}

function toError(error: unknown): Error {
  return error instanceof Error ? error : new Error(String(error));
}

/**
 * Loads data for `key`. Changing `key` always starts a fresh load.
 * `reload` refetches and keeps the data already on screen; a failed refetch is reported in `refreshError`.
 */
export function useLoad<T>(
  load: () => Promise<T>,
  key: string,
): LoadState<T> & { refreshError: Error | null; reload: () => void } {
  const [version, setVersion] = useState(0);
  const [tracked, setTracked] = useState<Tracked<T>>({ key, load: { status: "loading" }, refreshError: null });

  useEffect(() => {
    let active = true;
    setTracked((previous) => {
      const canKeepData = previous.key === key && previous.load.status === "ready";
      return { key, load: canKeepData ? previous.load : { status: "loading" }, refreshError: null };
    });
    load().then(
      (data) => active && setTracked({ key, load: { status: "ready", data }, refreshError: null }),
      (error: unknown) =>
        active &&
        setTracked((previous) => {
          const canKeepData = previous.key === key && previous.load.status === "ready";
          return canKeepData
            ? { ...previous, refreshError: toError(error) }
            : { key, load: { status: "error", error: toError(error) }, refreshError: null };
        }),
    );
    return () => {
      active = false;
    };
    // `load` is an inline closure; `key` and `version` identify the request.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, version]);

  const reload = useCallback(() => setVersion((current) => current + 1), []);
  const current = tracked.key === key ? tracked : { key, load: { status: "loading" } as const, refreshError: null };
  return { ...current.load, refreshError: current.refreshError, reload };
}
