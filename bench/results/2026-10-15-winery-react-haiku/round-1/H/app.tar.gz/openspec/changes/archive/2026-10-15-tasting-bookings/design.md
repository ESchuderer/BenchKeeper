# Design

## Context

Greenfield app. One Node.js 22 process serves the React front end and a small JSON API. Traffic is low (one winery's guests), data volume is tiny, and there are no external services. The deliverable must run with `npm install`, `npm run build`, `npm start`.

## Goals / Non-Goals

**Goals**
- Never overbook a tasting, including under simultaneous requests.
- Clear validation feedback next to each field; mobile-friendly, winery-style visual design.
- Staff access protected by the configured password, with brute-force throttling and CSRF-resistant cookies.
- Small code base built on established libraries.

**Non-Goals**
- Payments, email, guest accounts, multi-language, editing tastings in the UI, horizontal scaling.
- Blocking bookings for tastings that have already started (not in the brief; noted as a follow-up).

## Decisions

1. **Stack.** Express 5 for HTTP and JSON API; React 19 with React Router for the single-page UI; Vite to build the client; React Hook Form with Zod (via `@hookform/resolvers`) for forms; Tailwind CSS v4 for styling; `express-rate-limit` for throttling; Vitest with Testing Library and Supertest for tests. Server is compiled with `tsc` so `npm start` runs plain Node.
2. **Shared validation.** One Zod schema for the booking input in `shared/` is used by the client (instant field errors) and by the server (authoritative). Trust boundary is the server.
3. **Catalogue in code.** The three tastings live in `shared/tastings.ts` with stable slug ids, ISO dates with the Berlin offset (`+01:00`, winter time for all three dates), prices and seat counts. Seats left = seats − sum of guests of stored bookings.
4. **Storage.** A `BookingStore` class wraps a JSON file (`DATA_FILE`, default `data/bookings.json`). Reads happen at startup; every change is written to a temporary file and renamed over the original. All mutations are synchronous, so the capacity check and insert run without interleaving within the Node process. The check is repeated inside the store (not only in the route) so no caller can bypass it.
5. **Booking reference.** 6 characters from an alphabet without look-alikes (no 0/O, 1/I), generated with `crypto.randomInt`, re-drawn on collision. Format `KB-XXXXXX`.
6. **Staff auth.** `POST /api/staff/session` compares SHA-256 digests of the submitted and configured password with `crypto.timingSafeEqual`. On success a random 32-byte token is stored in memory with an 8-hour expiry and sent as an `HttpOnly; SameSite=Strict` cookie (`Secure` in production). `DELETE /api/staff/session` ends it. Login is rate-limited (10 failures per 15 minutes). The API only accepts `application/json` bodies, which browsers cannot send cross-site without a CORS preflight, giving a second CSRF barrier.
7. **Startup.** `STAFF_PASSWORD` must be non-empty; otherwise the process exits with a message naming the variable.
8. **Errors.** Every API error uses one envelope: `{ error: { code, message, fields? } }`. Field errors map to form fields; seat errors use code `SEATS_UNAVAILABLE` with the seats left. Stack traces and internal messages are logged server-side only.
9. **Routing.** API under `/api`; everything else falls back to `index.html` so deep links such as `/bookings/KB-…` and `/staff` work. Static assets come from `dist/client`.
10. **Seat text.** "N seats left" with "1 seat left" for one seat, which is the only plural deviation from the brief's wording.

## Risks / Trade-offs

- In-memory staff sessions are lost on restart; staff sign in again. Acceptable for one site.
- JSON file storage is single-process only. Running two replicas would need a real database; out of scope.
- Rate limiting keys on the socket address; behind a reverse proxy `trust proxy` must be configured. Documented in README.
