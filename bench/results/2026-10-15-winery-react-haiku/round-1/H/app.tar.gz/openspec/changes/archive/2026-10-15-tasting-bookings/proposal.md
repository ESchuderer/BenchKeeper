# Proposal

## Why

Weingut Kieselbrunnen has no way for guests to book wine tastings online, so bookings arrive by phone and email and staff track seats by hand. A small web app that shows the tastings, takes bookings within the available seats, and gives staff a list they can manage removes that manual work.

## What Changes

- New public start page listing the three tastings with date, time, price per guest and seats left.
- New booking flow per tasting: a form with Name, Email and Guests (1 to 8), validated on the client and on the server, that never books more seats than are left.
- New confirmation page with heading "Booking confirmed", the tasting, guest count, total price and a booking reference. It is reachable by its own URL so a reload keeps working.
- New staff area at `/staff`: password sign-in against the `STAFF_PASSWORD` environment variable, a list of all bookings grouped by tasting, and a Cancel action that frees the booked seats.
- Bookings are stored in a local JSON file; the app starts with no bookings.
- The tasting catalogue is fixed in code (three tastings from the winery's brief); there is no admin UI to edit it.

## Capabilities

### New Capabilities

- `guest-tasting-booking`: Guests browse the tastings, see live seat availability, and book seats for one tasting, receiving a booking reference.
- `staff-booking-management`: Staff sign in with a shared password and review all bookings per tasting, cancelling bookings to free seats.

### Modified Capabilities

None (greenfield project; no existing specs).

## Impact

- New application: React single-page front end served by an Express server (Node.js 22).
- New runtime configuration: `PORT` (default 3000), `STAFF_PASSWORD` (required, the server refuses to start without it), optional `DATA_FILE` for the bookings file.
- No external services. Data lives in one local JSON file.
- Out of scope: payments, guest accounts, email notifications, editing tastings, multiple languages, booking changes by guests (guests cancel by contacting the winery).
