# Spec Delta

## Purpose

Lets guests of Weingut Kieselbrunnen see the available wine tastings, book seats for one tasting, and receive a confirmation with a booking reference. Seat availability is enforced so no tasting is ever overbooked.

## ADDED Requirements

### Requirement: Start page lists tastings

The system SHALL show the start page with every offered tasting, each with its title, date and time, price per guest and the number of seats left.

#### Scenario: Tastings are listed with availability

- **WHEN** a guest opens the start page of a fresh installation
- **THEN** the page lists "Riesling Evening" (6 Nov 2026, 18:00, EUR 25 per guest, 12 seats left), "Red Wine Cellar Tour" (14 Nov 2026, 15:00, EUR 32 per guest, 8 seats left) and "Winter Tasting" (5 Dec 2026, 17:00, EUR 28 per guest, 10 seats left)

#### Scenario: Seats left reflect bookings

- **WHEN** a booking for 3 guests exists for "Riesling Evening"
- **THEN** the start page shows "9 seats left" for "Riesling Evening"

### Requirement: Fully booked tastings cannot be booked

The system SHALL show a tasting with no seats left as fully booked and SHALL NOT offer a booking form for it.

#### Scenario: Fully booked tasting

- **WHEN** a tasting has 0 seats left
- **THEN** the start page shows "Fully booked" for that tasting instead of a "Book" link
- **AND** opening its booking page shows that the tasting is fully booked and offers no booking form

### Requirement: Booking form per tasting

The system SHALL provide a booking page for each tasting, reached from a "Book <tasting title>" link or button, with the fields "Name", "Email" and "Guests" and a "Book" button.

#### Scenario: Opening the booking form

- **WHEN** a guest activates the link "Book Riesling Evening"
- **THEN** the booking page for "Riesling Evening" opens with the fields "Name", "Email" and "Guests" and a "Book" button

### Requirement: Guests field accepts 1 to 8 guests

The system SHALL accept only a whole number of guests from 1 to 8.

#### Scenario: Guest count out of range

- **WHEN** a guest submits 0 or 9 in the "Guests" field
- **THEN** the booking is rejected and an error message is shown next to the "Guests" field
- **AND** no seats are reserved

#### Scenario: Guest count not a whole number

- **WHEN** a guest submits 2.5 in the "Guests" field
- **THEN** the booking is rejected and an error message is shown next to the "Guests" field

### Requirement: Name and email are required and validated

The system SHALL require a non-empty name of at most 100 characters and a syntactically valid email address of at most 254 characters.

#### Scenario: Missing name

- **WHEN** a guest submits the form with an empty "Name"
- **THEN** the booking is rejected and an error message is shown next to the "Name" field

#### Scenario: Invalid email

- **WHEN** a guest submits "anna@" in the "Email" field
- **THEN** the booking is rejected and an error message is shown next to the "Email" field

### Requirement: Bookings never exceed available seats

The system SHALL reject any booking whose guest count is greater than the seats left for that tasting, and SHALL check this on the server at the moment the booking is made.

#### Scenario: Booking more guests than seats left

- **WHEN** a guest books 5 guests for "Winter Tasting" while 4 seats are left
- **THEN** the booking is rejected with an error message next to the "Guests" field stating that only 4 seats are left
- **AND** the seats left for "Winter Tasting" remain 4

#### Scenario: Booking exactly the seats left

- **WHEN** a guest books 4 guests for "Winter Tasting" while 4 seats are left
- **THEN** the booking succeeds and the seats left for "Winter Tasting" become 0

#### Scenario: Concurrent bookings cannot overbook

- **WHEN** two bookings of 3 guests each for a tasting with 4 seats left are submitted at the same time
- **THEN** exactly one booking succeeds and the other is rejected because only 4 seats are left

### Requirement: Booking confirmation

The system SHALL show a confirmation after a successful booking, with the heading "Booking confirmed", the tasting, the number of guests, the total price and a booking reference, at a URL that shows the same confirmation when reloaded.

#### Scenario: Successful booking

- **WHEN** a guest books 2 guests for "Red Wine Cellar Tour" with a valid name and email
- **THEN** the page shows the heading "Booking confirmed"
- **AND** shows the tasting "Red Wine Cellar Tour", 2 guests, a total of "EUR 64" and a booking reference
- **AND** the booking reference is unique among all bookings

#### Scenario: Confirmation survives reload

- **WHEN** a guest reloads the confirmation page
- **THEN** the same confirmation is shown

#### Scenario: Unknown booking reference

- **WHEN** a guest opens the confirmation for a reference that does not exist
- **THEN** the page states that the booking was not found and does not reveal other bookings

### Requirement: Error display

The system SHALL show validation and seat errors next to the field they concern and SHALL show any other failure as a message at the top of the form, without losing the values the guest entered.

#### Scenario: Server unavailable

- **WHEN** the booking request fails because the server cannot be reached
- **THEN** a message at the top of the form asks the guest to try again
- **AND** the entered name, email and guest count are kept

### Requirement: Booking data is kept locally

The system SHALL store bookings in a local file so that they survive a restart, and SHALL start with no bookings when the file does not exist.

#### Scenario: Bookings survive restart

- **WHEN** a booking is made and the server is restarted
- **THEN** the booking is still listed as a booking and its seats are still taken
