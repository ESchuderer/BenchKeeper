# Spec Delta

## Purpose

Lets winery staff sign in with a shared password to see every booking grouped by tasting and to cancel bookings, freeing their seats. Guests cannot reach any staff function.

## ADDED Requirements

### Requirement: Staff sign-in with shared password

The system SHALL provide a sign-in page at `/staff` with a "Password" field and a "Sign in" button, and SHALL grant access to staff functions only when the password equals the value of the `STAFF_PASSWORD` environment variable.

#### Scenario: Correct password

- **WHEN** staff enter the configured password and activate "Sign in"
- **THEN** the staff bookings view is shown

#### Scenario: Wrong password

- **WHEN** staff enter a wrong password and activate "Sign in"
- **THEN** access is refused and an error message is shown next to the "Password" field
- **AND** the password is not shown back to the user

#### Scenario: Empty password

- **WHEN** staff activate "Sign in" with an empty "Password" field
- **THEN** access is refused and an error message is shown next to the "Password" field

#### Scenario: Repeated wrong passwords are throttled

- **WHEN** more than 10 sign-in attempts fail within 15 minutes from the same client
- **THEN** further attempts are refused until the window passes

### Requirement: Server refuses to start without staff password

The system SHALL NOT start when `STAFF_PASSWORD` is unset or empty.

#### Scenario: Missing password at startup

- **WHEN** the server is started without `STAFF_PASSWORD`
- **THEN** it exits with an error message naming the missing variable

### Requirement: Staff session

The system SHALL keep a signed-in staff session in an HTTP-only cookie that is not sent on cross-site requests, and SHALL end the session on sign-out or after 8 hours.

#### Scenario: Session persists across page reloads

- **WHEN** a signed-in member of staff reloads the `/staff` page
- **THEN** the staff bookings view is still shown

#### Scenario: Sign out

- **WHEN** staff activate "Sign out"
- **THEN** the session ends and the sign-in form is shown again

#### Scenario: Staff data requires a session

- **WHEN** a request for staff booking data arrives without a valid session
- **THEN** the request is refused with an authentication error and no booking data is returned

### Requirement: Bookings grouped by tasting

The system SHALL show all bookings to signed-in staff, grouped by tasting, with each booking's name, email, number of guests and booking reference.

#### Scenario: Grouped view

- **WHEN** signed-in staff open the bookings view and bookings exist for two tastings
- **THEN** each tasting is shown as its own group with its title and date
- **AND** each booking in the group shows name, email, guests and reference

#### Scenario: Tasting without bookings

- **WHEN** a tasting has no bookings
- **THEN** its group states that there are no bookings

### Requirement: Cancel a booking

The system SHALL let signed-in staff cancel any booking with a "Cancel" button, after which the booking is removed and its seats become available to guests again.

#### Scenario: Cancelling frees seats

- **WHEN** staff cancel a booking of 3 guests for "Winter Tasting" that had 6 seats left
- **THEN** the booking disappears from the staff view
- **AND** "Winter Tasting" shows 9 seats left on the start page

#### Scenario: Cancel requires confirmation

- **WHEN** staff activate "Cancel" for a booking
- **THEN** staff are asked to confirm before the booking is removed
- **AND** the booking is kept if staff decline

#### Scenario: Cancelling an unknown booking

- **WHEN** a cancel request names a booking reference that does not exist
- **THEN** the request is refused with a not-found error and nothing else changes
