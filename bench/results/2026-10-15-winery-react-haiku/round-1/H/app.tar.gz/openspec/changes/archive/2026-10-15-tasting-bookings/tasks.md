# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` (Node 22 engines), TypeScript configs for client/shared and server, Vite config, Vitest config, `index.html`
- [x] 1.2 Add dependencies: react, react-dom, react-router, react-hook-form, @hookform/resolvers, zod, express, express-rate-limit; dev: vite, @vitejs/plugin-react, tailwindcss, @tailwindcss/vite, typescript, tsx, vitest, jsdom, @testing-library/react, @testing-library/user-event, @testing-library/jest-dom, supertest, and @types packages
- [x] 1.3 Scripts: `build` (client + server), `start` (runs compiled server), `dev`, `test`, `typecheck`

## 2. Shared domain (tests first)

- [x] 2.1 Test: catalogue has the three tastings with the brief's titles, dates, prices and seats; ids are stable
- [x] 2.2 Implement `shared/tastings.ts` (catalogue, formatting helpers for date, price, "N seats left")
- [x] 2.3 Test: booking schema accepts valid input and rejects empty name, long name, invalid email, guests 0, 9, 2.5, empty guests
- [x] 2.4 Implement `shared/bookingSchema.ts` (Zod)

## 3. Booking store (tests first)

- [x] 3.1 Test: fresh store with no file has no bookings; store creates the file on first write
- [x] 3.2 Test: seats left = seats − booked guests; create succeeds up to exact capacity and rejects beyond it with the seats left
- [x] 3.3 Test: cancel removes booking and frees seats; cancel unknown reference reports not found
- [x] 3.4 Test: bookings persist across a new store instance on the same file; corrupt file makes startup fail
- [x] 3.5 Test: references match `KB-XXXXXX` from the unambiguous alphabet and are unique
- [x] 3.6 Implement `server/bookingStore.ts` with atomic file writes

## 4. Staff auth (tests first)

- [x] 4.1 Test: correct password issues HttpOnly SameSite=Strict cookie; wrong and empty passwords are refused without echoing input
- [x] 4.2 Test: staff data endpoints return 401 without a valid cookie; sign out invalidates the cookie; expired session refused
- [x] 4.3 Test: 11th failed login within the window is refused with 429
- [x] 4.4 Test: startup without `STAFF_PASSWORD` throws naming the variable
- [x] 4.5 Implement `server/staffAuth.ts`

## 5. HTTP API (tests first)

- [x] 5.1 Test: `GET /api/tastings` returns tastings with seats left, updating after a booking
- [x] 5.2 Test: `POST /api/tastings/:id/bookings` returns 201 with booking details and total; 400 with field errors for invalid input; 409 `SEATS_UNAVAILABLE` when over capacity; 404 for unknown tasting; rejects non-JSON content type
- [x] 5.3 Test: `GET /api/bookings/:reference` returns the booking; 404 for unknown reference
- [x] 5.4 Test: staff bookings list is grouped by tasting; `DELETE /api/staff/bookings/:reference` cancels and frees seats; 404 for unknown reference
- [x] 5.5 Test: unknown `/api/*` path returns 404 JSON; other paths serve `index.html` when the client build exists
- [x] 5.6 Implement `server/app.ts` (routes, error envelope, rate limit on booking and login endpoints, JSON body limit) and `server/index.ts` (reads `PORT`, `DATA_FILE`, `STAFF_PASSWORD`)

## 6. Guest UI (tests first)

- [x] 6.1 Test: start page lists three tastings with title, date/time, price per guest, "N seats left"; "Book <title>" link present; fully booked shows "Fully booked" and no link
- [x] 6.2 Test: booking page shows fields Name, Email, Guests and "Book" button; shows per-field error messages for invalid input and seat overflow without losing entered values; shows form-level message on network failure
- [x] 6.3 Test: successful booking navigates to confirmation showing "Booking confirmed", tasting, guests, total and reference
- [x] 6.4 Test: confirmation page loads by reference and shows "not found" for unknown references
- [x] 6.5 Implement pages, API client, layout, and Tailwind theme (winery palette, responsive, visible focus states)

## 7. Staff UI (tests first)

- [x] 7.1 Test: `/staff` shows sign-in form with "Password" and "Sign in"; wrong password shows error next to field
- [x] 7.2 Test: signed-in view shows bookings grouped by tasting with name, email, guests, reference, and "Cancel"; cancel asks for confirmation and removes the row; "Sign out" returns to sign-in
- [x] 7.3 Implement staff page

## 8. Verification

- [x] 8.1 `npm run typecheck`, `npm test` with coverage ≥ 80% for server and shared code
- [x] 8.2 `npm run build` and `npm start` with `PORT` and `STAFF_PASSWORD`; HTTP smoke test of guest and staff API flows done. Browser test at phone and desktop widths NOT done: no browser system libraries in this container
- [x] 8.3 Review pass (code review and security review); no CRITICAL or HIGH findings; MEDIUM and LOW fixes applied where cheap, others recorded in README as known gaps
- [x] 8.4 README with setup, configuration, and run instructions
