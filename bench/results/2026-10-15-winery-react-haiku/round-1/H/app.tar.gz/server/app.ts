import { existsSync } from "node:fs";
import path from "node:path";
import cookieParser from "cookie-parser";
import express, { type Request, type Response } from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import { ApiError, errorHandler } from "./errors.js";
import type { BookingStore } from "./bookingStore.js";
import { StaffSessions } from "./staffAuth.js";
import { staffRouter } from "./routes/staff.js";
import { tastingRouter } from "./routes/tastings.js";

const FIFTEEN_MINUTES_MS = 15 * 60 * 1000;
const JSON_BODY_LIMIT = "10kb";

export interface AppOptions {
  store: BookingStore;
  staffPassword: string;
  /** Directory with the built front end. When it has no index.html, only the API is served. */
  clientDir?: string;
  limits?: Partial<{ login: number; booking: number; lookup: number }>;
  trustProxy?: number | false;
  secureCookies?: boolean;
}

export function createApp(options: AppOptions): express.Express {
  const app = express();
  const limits = { login: 10, booking: 30, lookup: 60, ...options.limits };
  const sessions = new StaffSessions({ password: options.staffPassword });

  app.disable("x-powered-by");
  app.set("trust proxy", options.trustProxy ?? false);
  app.use(helmet());
  app.use(express.json({ limit: JSON_BODY_LIMIT }));
  app.use(cookieParser());

  const loginLimiter = rateLimiter(limits.login, { skipSuccessfulRequests: true });
  const bookingLimiter = rateLimiter(limits.booking);
  const lookupLimiter = rateLimiter(limits.lookup);

  app.use(
    "/api",
    tastingRouter({ store: options.store, bookingLimiter, lookupLimiter }),
    staffRouter({
      store: options.store,
      sessions,
      loginLimiter,
      secureCookies: options.secureCookies ?? false,
    }),
  );
  app.use("/api", (_req, _res, next) => next(new ApiError(404, "NOT_FOUND", "Not found.")));

  if (options.clientDir && existsSync(path.join(options.clientDir, "index.html"))) {
    serveClient(app, options.clientDir);
  }

  app.use(errorHandler);
  return app;
}

function rateLimiter(limit: number, extra: { skipSuccessfulRequests?: boolean } = {}) {
  return rateLimit({
    windowMs: FIFTEEN_MINUTES_MS,
    limit,
    standardHeaders: "draft-8",
    legacyHeaders: false,
    message: { error: { code: "TOO_MANY_REQUESTS", message: "Too many attempts. Please wait a few minutes and try again." } },
    ...extra,
  });
}

function serveClient(app: express.Express, clientDir: string): void {
  const indexPath = path.join(clientDir, "index.html");
  app.use(express.static(clientDir, { index: false, maxAge: "1h" }));
  // Single-page app: any other GET (e.g. /bookings/KB-XXXXXX, /staff) gets the app shell.
  app.get(/^\/(?!api\/).*/, (_req: Request, res: Response) => {
    res.sendFile(indexPath);
  });
}
