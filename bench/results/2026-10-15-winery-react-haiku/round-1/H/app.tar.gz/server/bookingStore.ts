import { randomInt } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import path from "node:path";
import { z } from "zod";
import { MAX_GUESTS_PER_BOOKING } from "../shared/bookingSchema.js";
import { findTasting } from "../shared/tastings.js";

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface NewBooking {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export class SeatsUnavailableError extends Error {
  readonly seatsLeft: number;

  constructor(seatsLeft: number) {
    super(`Only ${seatsLeft} seats are left.`);
    this.name = "SeatsUnavailableError";
    this.seatsLeft = seatsLeft;
  }
}

/** Guest names and emails are personal data: only the owner may read the file. */
const PRIVATE_FILE_MODE = 0o600;
const PRIVATE_DIRECTORY_MODE = 0o700;

const REFERENCE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no 0/O or 1/I/L look-alikes
const REFERENCE_LENGTH = 6;

const bookingsFileSchema = z.object({
  bookings: z.array(
    z.object({
      reference: z.string(),
      tastingId: z.string(),
      name: z.string(),
      email: z.string(),
      guests: z.number().int().min(1),
      createdAt: z.string(),
    }),
  ),
});

/**
 * Bookings kept in memory and written through to one JSON file.
 * All mutations are synchronous, so the seat check and the insert cannot interleave.
 */
export class BookingStore {
  private bookings: readonly Booking[];

  private constructor(
    private readonly filePath: string,
    bookings: readonly Booking[],
  ) {
    this.bookings = bookings;
  }

  static open(filePath: string): BookingStore {
    return new BookingStore(filePath, existsSync(filePath) ? readBookingsFile(filePath) : []);
  }

  list(): readonly Booking[] {
    return this.bookings;
  }

  find(reference: string): Booking | undefined {
    return this.bookings.find((booking) => booking.reference === reference);
  }

  seatsLeft(tastingId: string): number {
    const tasting = findTasting(tastingId);
    if (!tasting) throw new Error(`Unknown tasting: ${tastingId}`);
    const taken = this.bookings
      .filter((booking) => booking.tastingId === tastingId)
      .reduce((sum, booking) => sum + booking.guests, 0);
    return tasting.seats - taken;
  }

  create(input: NewBooking): Booking {
    if (!Number.isInteger(input.guests) || input.guests < 1 || input.guests > MAX_GUESTS_PER_BOOKING) {
      throw new RangeError(`Guests must be a whole number from 1 to ${MAX_GUESTS_PER_BOOKING}.`);
    }
    const seatsLeft = this.seatsLeft(input.tastingId);
    if (input.guests > seatsLeft) throw new SeatsUnavailableError(seatsLeft);

    const booking: Booking = {
      ...input,
      reference: this.newReference(),
      createdAt: new Date().toISOString(),
    };
    this.commit([...this.bookings, booking]);
    return booking;
  }

  cancel(reference: string): boolean {
    const remaining = this.bookings.filter((booking) => booking.reference !== reference);
    if (remaining.length === this.bookings.length) return false;
    this.commit(remaining);
    return true;
  }

  private newReference(): string {
    for (;;) {
      const candidate = `KB-${Array.from({ length: REFERENCE_LENGTH }, () =>
        REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)],
      ).join("")}`;
      if (!this.find(candidate)) return candidate;
    }
  }

  /** Writes to a temporary file and renames it, so a crash never leaves a half-written file. */
  private commit(next: readonly Booking[]): void {
    mkdirSync(path.dirname(this.filePath), { recursive: true, mode: PRIVATE_DIRECTORY_MODE });
    const temporaryPath = `${this.filePath}.tmp`;
    writeFileSync(temporaryPath, JSON.stringify({ bookings: next }, null, 2), { mode: PRIVATE_FILE_MODE });
    renameSync(temporaryPath, this.filePath);
    this.bookings = next;
  }
}

function readBookingsFile(filePath: string): readonly Booking[] {
  let parsed: unknown;
  try {
    parsed = JSON.parse(readFileSync(filePath, "utf8"));
  } catch (error) {
    throw new Error(`Could not read the bookings file at ${filePath}. Fix or move it before starting.`, {
      cause: error,
    });
  }
  const result = bookingsFileSchema.safeParse(parsed);
  if (!result.success) {
    throw new Error(`The bookings file at ${filePath} has an unexpected format.`);
  }
  return result.data.bookings;
}
