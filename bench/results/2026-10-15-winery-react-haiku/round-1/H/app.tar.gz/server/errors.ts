import type { NextFunction, Request, Response } from "express";
import type { ZodError } from "zod";
import type { ApiFieldErrors } from "../shared/api.js";

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly fields?: ApiFieldErrors,
    readonly seatsLeft?: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

/** Turns thrown errors into the JSON error envelope. Details of unexpected errors stay on the server. */
export function errorHandler(error: unknown, _req: Request, res: Response, next: NextFunction): void {
  if (res.headersSent) {
    next(error);
    return;
  }
  if (error instanceof ApiError) {
    res.status(error.status).json({
      error: { code: error.code, message: error.message, fields: error.fields, seatsLeft: error.seatsLeft },
    });
    return;
  }
  if (isBodyParserError(error, "entity.parse.failed")) {
    res.status(400).json({ error: { code: "INVALID_JSON", message: "The request body is not valid JSON." } });
    return;
  }
  if (isBodyParserError(error, "entity.too.large")) {
    res.status(413).json({ error: { code: "PAYLOAD_TOO_LARGE", message: "The request is too large." } });
    return;
  }
  console.error("Unexpected error while handling request:", error);
  res.status(500).json({
    error: { code: "INTERNAL_ERROR", message: "Something went wrong. Please try again." },
  });
}

function isBodyParserError(error: unknown, type: string): boolean {
  return typeof error === "object" && error !== null && (error as { type?: string }).type === type;
}

/** Keeps the first message per form field, so each field shows one clear error. */
export function fieldErrorsFrom(error: ZodError): ApiFieldErrors {
  const fields: ApiFieldErrors = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0] ?? "form");
    fields[field] ??= issue.message;
  }
  return fields;
}
