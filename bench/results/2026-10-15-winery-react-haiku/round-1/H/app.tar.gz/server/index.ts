import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";
import { BookingStore } from "./bookingStore.js";
import { requireStaffPassword } from "./staffAuth.js";

const DEFAULT_PORT = 3000;
const here = path.dirname(fileURLToPath(import.meta.url));

function fail(message: string): never {
  console.error(message);
  process.exit(1);
}

const port = Number(process.env.PORT ?? DEFAULT_PORT);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  fail(`PORT must be a whole number between 1 and 65535, got "${process.env.PORT}".`);
}

let staffPassword: string;
try {
  staffPassword = requireStaffPassword(process.env);
} catch (error) {
  fail(error instanceof Error ? error.message : String(error));
}

const trustProxy = parseTrustProxy(process.env.TRUST_PROXY);

const dataFile = process.env.DATA_FILE ?? path.resolve("data", "bookings.json");
const clientDir = path.resolve(here, "..", "client");
if (!existsSync(path.join(clientDir, "index.html"))) {
  console.warn("The front end has not been built. Run `npm run build` first; the API still works.");
}

const app = createApp({
  store: BookingStore.open(dataFile),
  staffPassword,
  clientDir,
  trustProxy,
  secureCookies: process.env.NODE_ENV === "production",
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings on http://localhost:${port} (bookings: ${dataFile})`);
});

/**
 * Number of proxy hops in front of the app, or false when there is no proxy.
 * "true" is refused: it would trust a client-supplied X-Forwarded-For and let anyone evade rate limits.
 */
function parseTrustProxy(value: string | undefined): number | false {
  if (value === undefined || value === "" || value === "0") return false;
  if (!/^[1-9]\d*$/.test(value)) {
    fail(`TRUST_PROXY must be the number of proxies in front of the app (for example 1) or unset, got "${value}".`);
  }
  return Number(value);
}
