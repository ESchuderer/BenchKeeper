import { Router, type NextFunction, type Request, type Response, type RequestHandler } from "express";
import { z } from "zod";
import type { StaffSessionState, StaffTastingGroup } from "../../shared/api.js";
import { TASTINGS } from "../../shared/tastings.js";
import type { BookingStore } from "../bookingStore.js";
import { ApiError } from "../errors.js";
import { STAFF_SESSION_TTL_MS, type StaffSessions } from "../staffAuth.js";
import { bookingNotFound } from "./tastings.js";

export const STAFF_COOKIE = "kb_staff";

interface StaffRouteOptions {
  store: BookingStore;
  sessions: StaffSessions;
  loginLimiter: RequestHandler;
  secureCookies: boolean;
}

const loginSchema = z.object({
  password: z
    .string({ error: "Please enter the password." })
    .min(1, "Please enter the password."),
});

export function staffRouter({ store, sessions, loginLimiter, secureCookies }: StaffRouteOptions): Router {
  const router = Router();
  const requireSession = staffSessionGuard(sessions);
  const cookieOptions = { httpOnly: true, sameSite: "strict" as const, secure: secureCookies, path: "/" };

  router.get("/staff/session", (req, res) => {
    const state: StaffSessionState = { authenticated: sessions.isValid(req.cookies?.[STAFF_COOKIE]) };
    res.json({ data: state });
  });

  router.post("/staff/session", loginLimiter, (req, res) => {
    const parsed = loginSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      throw new ApiError(400, "VALIDATION_FAILED", "Please enter the password.", {
        password: "Please enter the password.",
      });
    }
    if (!sessions.verifyPassword(parsed.data.password)) {
      const message = "That password is not correct.";
      throw new ApiError(401, "INVALID_PASSWORD", message, { password: message });
    }
    const token = sessions.createSession();
    res.cookie(STAFF_COOKIE, token, { ...cookieOptions, maxAge: STAFF_SESSION_TTL_MS });
    res.json({ data: { authenticated: true } satisfies StaffSessionState });
  });

  router.delete("/staff/session", (req, res) => {
    const token = req.cookies?.[STAFF_COOKIE];
    if (typeof token === "string") sessions.end(token);
    res.clearCookie(STAFF_COOKIE, cookieOptions);
    res.status(204).end();
  });

  router.get("/staff/bookings", requireSession, (_req, res) => {
    const groups: StaffTastingGroup[] = TASTINGS.map((tasting) => ({
      id: tasting.id,
      title: tasting.title,
      startsAt: tasting.startsAt,
      seats: tasting.seats,
      seatsLeft: store.seatsLeft(tasting.id),
      bookings: store
        .list()
        .filter((booking) => booking.tastingId === tasting.id)
        .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
    }));
    res.json({ data: groups });
  });

  router.delete("/staff/bookings/:reference", requireSession, (req, res) => {
    if (!store.cancel(String(req.params.reference))) throw bookingNotFound();
    res.status(204).end();
  });

  return router;
}

function staffSessionGuard(sessions: StaffSessions) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (sessions.isValid(req.cookies?.[STAFF_COOKIE])) {
      next();
      return;
    }
    next(new ApiError(401, "UNAUTHENTICATED", "Please sign in to see bookings."));
  };
}
