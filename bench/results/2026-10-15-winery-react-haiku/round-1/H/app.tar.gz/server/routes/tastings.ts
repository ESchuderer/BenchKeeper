import { Router, type Request, type RequestHandler } from "express";
import type { BookingConfirmation, TastingView } from "../../shared/api.js";
import { bookingInputSchema } from "../../shared/bookingSchema.js";
import { TASTINGS, findTasting, seatsShortageMessage } from "../../shared/tastings.js";
import type { Booking, BookingStore } from "../bookingStore.js";
import { SeatsUnavailableError } from "../bookingStore.js";
import { ApiError, fieldErrorsFrom } from "../errors.js";

interface TastingRouteOptions {
  store: BookingStore;
  bookingLimiter: RequestHandler;
  lookupLimiter: RequestHandler;
}

export function tastingRouter({ store, bookingLimiter, lookupLimiter }: TastingRouteOptions): Router {
  const router = Router();

  router.get("/tastings", (_req, res) => {
    res.json({ data: TASTINGS.map((tasting) => tastingView(store, tasting.id)) });
  });

  router.get("/tastings/:id", (req, res) => {
    res.json({ data: tastingView(store, requireTastingId(req)) });
  });

  router.post("/tastings/:id/bookings", bookingLimiter, (req, res) => {
    const tastingId = requireTastingId(req);
    requireJson(req);
    const input = parseBookingInput(req.body);

    try {
      const booking = store.create({ tastingId, ...input });
      res.status(201).json({ data: toConfirmation(booking) });
    } catch (error) {
      if (error instanceof SeatsUnavailableError) throw seatsError(error);
      throw error;
    }
  });

  router.get("/bookings/:reference", lookupLimiter, (req, res) => {
    const booking = store.find(String(req.params.reference));
    if (!booking) throw bookingNotFound();
    res.json({ data: toConfirmation(booking) });
  });

  return router;
}

export function tastingView(store: BookingStore, tastingId: string): TastingView {
  const tasting = findTasting(tastingId);
  if (!tasting) throw new ApiError(404, "TASTING_NOT_FOUND", "That tasting does not exist.");
  return { ...tasting, seatsLeft: store.seatsLeft(tastingId) };
}

export function toConfirmation(booking: Booking): BookingConfirmation {
  const tasting = findTasting(booking.tastingId);
  if (!tasting) throw new Error(`Booking ${booking.reference} refers to an unknown tasting`);
  return {
    reference: booking.reference,
    tastingId: tasting.id,
    tastingTitle: tasting.title,
    startsAt: tasting.startsAt,
    guests: booking.guests,
    total: booking.guests * tasting.pricePerGuest,
  };
}

export function bookingNotFound(): ApiError {
  return new ApiError(404, "BOOKING_NOT_FOUND", "We could not find that booking.");
}

function requireTastingId(req: Request): string {
  const tastingId = String(req.params.id);
  if (!findTasting(tastingId)) throw new ApiError(404, "TASTING_NOT_FOUND", "That tasting does not exist.");
  return tastingId;
}

function requireJson(req: Request): void {
  if (!req.is("application/json")) {
    throw new ApiError(415, "UNSUPPORTED_MEDIA_TYPE", "Send the booking as JSON.");
  }
}

function parseBookingInput(body: unknown) {
  const result = bookingInputSchema.safeParse(body ?? {});
  if (!result.success) {
    throw new ApiError(400, "VALIDATION_FAILED", "Please correct the highlighted fields.", fieldErrorsFrom(result.error));
  }
  return result.data;
}

function seatsError(error: SeatsUnavailableError): ApiError {
  const message = seatsShortageMessage(error.seatsLeft);
  return new ApiError(409, "SEATS_UNAVAILABLE", message, { guests: message }, error.seatsLeft);
}
