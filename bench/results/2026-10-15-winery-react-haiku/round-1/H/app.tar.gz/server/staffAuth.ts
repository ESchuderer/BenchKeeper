import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export const STAFF_SESSION_TTL_MS = 8 * 60 * 60 * 1000;

/** Reads the staff password from the environment. Refuses to run without one. */
export function requireStaffPassword(env: { STAFF_PASSWORD?: string }): string {
  const password = env.STAFF_PASSWORD;
  if (password === undefined || password.trim() === "") {
    throw new Error("STAFF_PASSWORD must be set to a non-empty value before starting the server.");
  }
  return password;
}

interface StaffSessionsOptions {
  password: string;
  now?: () => number;
  ttlMs?: number;
}

/** In-memory staff sessions guarded by one shared password. */
export class StaffSessions {
  private readonly expiresAt = new Map<string, number>();
  private readonly now: () => number;
  private readonly ttlMs: number;
  private readonly passwordDigest: Buffer;

  constructor(options: StaffSessionsOptions) {
    this.now = options.now ?? Date.now;
    this.ttlMs = options.ttlMs ?? STAFF_SESSION_TTL_MS;
    this.passwordDigest = sha256(options.password);
  }

  /** Compares digests in constant time so the password's contents do not leak through timing. */
  verifyPassword(candidate: string): boolean {
    return timingSafeEqual(this.passwordDigest, sha256(candidate));
  }

  createSession(): string {
    this.discardExpired();
    const token = randomBytes(32).toString("base64url");
    this.expiresAt.set(token, this.now() + this.ttlMs);
    return token;
  }

  isValid(token: string | undefined): boolean {
    if (token === undefined) return false;
    const expiry = this.expiresAt.get(token);
    if (expiry === undefined) return false;
    if (this.now() >= expiry) {
      this.expiresAt.delete(token);
      return false;
    }
    return true;
  }

  end(token: string): void {
    this.expiresAt.delete(token);
  }

  private discardExpired(): void {
    const current = this.now();
    for (const [token, expiry] of this.expiresAt) {
      if (current >= expiry) this.expiresAt.delete(token);
    }
  }
}

function sha256(value: string): Buffer {
  return createHash("sha256").update(value, "utf8").digest();
}
