/** Shapes exchanged between the browser and the JSON API. */

export interface ApiFieldErrors {
  [field: string]: string;
}

export interface ApiErrorBody {
  error: {
    code: string;
    message: string;
    fields?: ApiFieldErrors;
    seatsLeft?: number;
  };
}

export interface TastingView {
  id: string;
  title: string;
  startsAt: string;
  pricePerGuest: number;
  seats: number;
  seatsLeft: number;
}

/** Public view of a booking: what a guest sees on their confirmation. */
export interface BookingConfirmation {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  total: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTastingGroup {
  id: string;
  title: string;
  startsAt: string;
  seats: number;
  seatsLeft: number;
  bookings: StaffBooking[];
}

export interface StaffSessionState {
  authenticated: boolean;
}
