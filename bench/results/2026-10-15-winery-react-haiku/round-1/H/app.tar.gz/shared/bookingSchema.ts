import { z } from "zod";
import { seatsShortageMessage } from "./tastings.js";

export const MAX_GUESTS_PER_BOOKING = 8;
export const MAX_NAME_LENGTH = 100;
export const MAX_EMAIL_LENGTH = 254;

const EMAIL_INVALID = "Please enter a valid email address.";

/**
 * Booking form input, shared by the browser (instant field errors) and the server
 * (authoritative check). Guests may arrive as a string from a form or a number from JSON.
 */
export const bookingInputSchema = z.object({
  name: z
    .string({ error: "Please enter your name." })
    .trim()
    .min(1, "Please enter your name.")
    .max(MAX_NAME_LENGTH, `Name must be ${MAX_NAME_LENGTH} characters or fewer.`),
  email: z
    .string({ error: "Please enter your email address." })
    .trim()
    .min(1, "Please enter your email address.")
    .max(MAX_EMAIL_LENGTH, `Email must be ${MAX_EMAIL_LENGTH} characters or fewer.`)
    .pipe(z.email({ error: EMAIL_INVALID })),
  guests: z.preprocess(
    (value) => (value === "" || value === null || value === undefined ? undefined : Number(value)),
    z
      .number({ error: "Please enter the number of guests." })
      .int({ error: "Guests must be a whole number." })
      .min(1, "At least 1 guest is required.")
      .max(MAX_GUESTS_PER_BOOKING, `You can book for at most ${MAX_GUESTS_PER_BOOKING} guests.`),
  ),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;

/** The booking schema plus the seat limit for one tasting, used by the browser form. */
export function bookingSchemaForSeats(seatsLeft: number) {
  return bookingInputSchema.superRefine((input, context) => {
    if (input.guests > seatsLeft) {
      context.addIssue({
        code: "custom",
        path: ["guests"],
        message: seatsShortageMessage(seatsLeft),
      });
    }
  });
}
