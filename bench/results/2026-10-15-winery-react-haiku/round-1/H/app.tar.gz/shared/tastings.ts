export interface Tasting {
  id: string;
  title: string;
  /** ISO 8601 start time with the Berlin offset (winter time for all dates offered). */
  startsAt: string;
  pricePerGuest: number;
  seats: number;
}

export const TASTINGS: readonly Tasting[] = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00:00+01:00",
    pricePerGuest: 25,
    seats: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00:00+01:00",
    pricePerGuest: 32,
    seats: 8,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00:00+01:00",
    pricePerGuest: 28,
    seats: 10,
  },
];

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((tasting) => tasting.id === id);
}

const BERLIN = "Europe/Berlin";

const TASTING_DAY_FORMAT = new Intl.DateTimeFormat("en-GB", {
  weekday: "short",
  day: "numeric",
  month: "short",
  year: "numeric",
  timeZone: BERLIN,
});

const TASTING_TIME_FORMAT = new Intl.DateTimeFormat("en-GB", {
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
  timeZone: BERLIN,
});

export function formatTastingDate(startsAt: string): string {
  return TASTING_DAY_FORMAT.format(new Date(startsAt));
}

export function formatTastingTime(startsAt: string): string {
  return TASTING_TIME_FORMAT.format(new Date(startsAt));
}

/** Shown when a guest asks for more seats than are left; also used by the server. */
export function seatsShortageMessage(seatsLeft: number): string {
  if (seatsLeft === 0) return "This tasting is fully booked.";
  return seatsLeft === 1 ? "Only 1 seat is left for this tasting." : `Only ${seatsLeft} seats are left for this tasting.`;
}

export function formatSeatsLeft(seatsLeft: number): string {
  return seatsLeft === 1 ? "1 seat left" : `${seatsLeft} seats left`;
}

export function formatEuros(amount: number): string {
  return `EUR ${amount}`;
}
