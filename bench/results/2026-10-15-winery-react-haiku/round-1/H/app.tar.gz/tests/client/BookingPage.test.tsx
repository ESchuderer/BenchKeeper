// @vitest-environment jsdom
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { BookingPage } from "../../client/pages/BookingPage.js";
import { ConfirmationPage } from "../../client/pages/ConfirmationPage.js";
import { MemoryRouter, Route, Routes } from "react-router";
import { TASTING_LIST, mockFetch } from "./helpers.js";

const riesling = TASTING_LIST[0];
const winter = TASTING_LIST[2];

afterEach(() => {
  vi.restoreAllMocks();
});

function renderBookingFlow(path = "/tastings/riesling-evening/book") {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/tastings/:id/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
      </Routes>
    </MemoryRouter>,
  );
}


function tastingRoutes(tasting = riesling, extra: Parameters<typeof mockFetch>[0] = []) {
  return [{ path: `/api/tastings/${tasting.id}`, body: { data: tasting } }, ...extra];
}

describe("BookingPage", () => {
  it("shows the tasting with Name, Email and Guests fields and a Book button", async () => {
    mockFetch(tastingRoutes());

    renderBookingFlow();

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAttribute("min", "1");
    expect(screen.getByLabelText("Guests")).toHaveAttribute("max", "8");
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("shows a message next to each field that is invalid, and keeps the other values", async () => {
    mockFetch(tastingRoutes());
    const user = userEvent.setup();
    renderBookingFlow();
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await user.type(screen.getByLabelText("Email"), "anna@");
    await user.clear(screen.getByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), "9");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Please enter your name.")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toHaveAccessibleDescription("Please enter your name.");
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription(
      "Please enter a valid email address.",
    );
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription(
      "You can book for at most 8 guests.",
    );
    expect(screen.getByLabelText("Email")).toHaveValue("anna@");
    expect(screen.getByLabelText("Email")).toHaveAttribute("aria-invalid", "true");
  });

  it("shows a seat error next to Guests when the server has fewer seats left", async () => {
    mockFetch(
      tastingRoutes(winter, [
        {
          method: "POST",
          path: `/api/tastings/${winter.id}/bookings`,
          status: 409,
          body: {
            error: {
              code: "SEATS_UNAVAILABLE",
              message: "Only 4 seats are left for this tasting.",
              fields: { guests: "Only 4 seats are left for this tasting." },
              seatsLeft: 4,
            },
          },
        },
      ]),
    );
    const user = userEvent.setup();
    renderBookingFlow("/tastings/winter-tasting/book");
    await screen.findByRole("heading", { name: "Winter Tasting" });

    await user.type(screen.getByLabelText("Name"), "Ben Ort");
    await user.type(screen.getByLabelText("Email"), "ben@example.com");
    await user.clear(screen.getByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), "5");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Only 4 seats are left for this tasting.")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription(
      "Only 4 seats are left for this tasting.",
    );
    expect(screen.getByLabelText("Name")).toHaveValue("Ben Ort");
  });

  it("submits the booking and shows the confirmation", async () => {
    const spy = mockFetch([
      ...tastingRoutes(),
      {
        method: "POST",
        path: `/api/tastings/${riesling.id}/bookings`,
        status: 201,
        body: {
          data: {
            reference: "KB-7QXM2D",
            tastingId: riesling.id,
            tastingTitle: "Riesling Evening",
            startsAt: riesling.startsAt,
            guests: 2,
            total: 50,
          },
        },
      },
      {
        path: "/api/bookings/KB-7QXM2D",
        body: {
          data: {
            reference: "KB-7QXM2D",
            tastingId: riesling.id,
            tastingTitle: "Riesling Evening",
            startsAt: riesling.startsAt,
            guests: 2,
            total: 50,
          },
        },
      },
    ]);
    const user = userEvent.setup();
    renderBookingFlow();
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await user.type(screen.getByLabelText("Name"), "Anna Keller");
    await user.type(screen.getByLabelText("Email"), "anna@example.com");
    await user.clear(screen.getByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(screen.getByText("KB-7QXM2D")).toBeInTheDocument();
    expect(screen.getByText("EUR 50")).toBeInTheDocument();

    const post = spy.mock.calls.find(([, init]) => init?.method === "POST");
    expect(JSON.parse(String(post?.[1]?.body))).toEqual({
      name: "Anna Keller",
      email: "anna@example.com",
      guests: 2,
    });
  });

  it("keeps the entered values and explains a lost connection at the top of the form", async () => {
    mockFetch([
      ...tastingRoutes(),
      { method: "POST", path: `/api/tastings/${riesling.id}/bookings`, networkError: true },
    ]);
    const user = userEvent.setup();
    renderBookingFlow();
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await user.type(screen.getByLabelText("Name"), "Anna Keller");
    await user.type(screen.getByLabelText("Email"), "anna@example.com");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(/could not reach the server/i);
    expect(screen.getByLabelText("Name")).toHaveValue("Anna Keller");
  });

  it("does not offer a form for a fully booked tasting", async () => {
    mockFetch(tastingRoutes(TASTING_LIST[1]));

    renderBookingFlow("/tastings/red-wine-cellar-tour/book");

    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Book" })).not.toBeInTheDocument();
  });

  it("shows a not-found message for an unknown tasting", async () => {
    mockFetch([{ path: "/api/tastings/nope", status: 404, body: { error: { code: "TASTING_NOT_FOUND", message: "That tasting does not exist." } } }]);

    renderBookingFlow("/tastings/nope/book");

    expect(await screen.findByText("That tasting does not exist.")).toBeInTheDocument();
  });
});

describe("ConfirmationPage", () => {
  it("shows an unknown reference as not found without other details", async () => {
    mockFetch([{ path: "/api/bookings/KB-NOPE00", status: 404, body: { error: { code: "BOOKING_NOT_FOUND", message: "We could not find that booking." } } }]);

    renderBookingFlow("/bookings/KB-NOPE00");

    expect(await screen.findByText("We could not find that booking.")).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Booking confirmed" })).not.toBeInTheDocument();
  });
});
