// @vitest-environment jsdom
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router";
import { afterEach, describe, expect, it, vi } from "vitest";
import { StaffPage } from "../../client/pages/StaffPage.js";
import { jsonResponse, mockFetch } from "./helpers.js";

afterEach(() => {
  vi.restoreAllMocks();
});

function renderStaff() {
  return render(
    <MemoryRouter initialEntries={["/staff"]}>
      <Routes>
        <Route path="/staff" element={<StaffPage />} />
      </Routes>
    </MemoryRouter>,
  );
}

const groups = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00:00+01:00",
    seats: 12,
    seatsLeft: 9,
    bookings: [{ reference: "KB-7QXM2D", name: "Anna Keller", email: "anna@example.com", guests: 3 }],
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00:00+01:00",
    seats: 10,
    seatsLeft: 10,
    bookings: [],
  },
];

describe("StaffPage sign-in", () => {
  it("asks for the password before showing any bookings", async () => {
    mockFetch([{ path: "/api/staff/session", body: { data: { authenticated: false } } }]);

    renderStaff();

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
    expect(screen.queryByText("Anna Keller")).not.toBeInTheDocument();
  });

  it("shows a wrong password as an error next to the Password field", async () => {
    mockFetch([
      { path: "/api/staff/session", body: { data: { authenticated: false } } },
      {
        method: "POST",
        path: "/api/staff/session",
        status: 401,
        body: {
          error: {
            code: "INVALID_PASSWORD",
            message: "That password is not correct.",
            fields: { password: "That password is not correct." },
          },
        },
      },
    ]);
    const user = userEvent.setup();
    renderStaff();
    await user.type(await screen.findByLabelText("Password"), "guess-123");

    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByText("That password is not correct.")).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toHaveAccessibleDescription("That password is not correct.");
    expect(screen.getByLabelText("Password")).toHaveValue("guess-123");
  });

  it("shows bookings grouped by tasting after a correct password", async () => {
    mockFetch([
      { path: "/api/staff/session", body: { data: { authenticated: false } } },
      { method: "POST", path: "/api/staff/session", body: { data: { authenticated: true } } },
      { path: "/api/staff/bookings", body: { data: groups } },
    ]);
    const user = userEvent.setup();
    renderStaff();
    await user.type(await screen.findByLabelText("Password"), "vintage-2026");

    await user.click(screen.getByRole("button", { name: "Sign in" }));

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    expect(within(riesling).getByText("Anna Keller")).toBeInTheDocument();
    expect(within(riesling).getByText("anna@example.com")).toBeInTheDocument();
    expect(within(riesling).getByText("3")).toBeInTheDocument();
    expect(within(riesling).getByText("KB-7QXM2D")).toBeInTheDocument();
    expect(within(riesling).getByRole("button", { name: "Cancel" })).toBeInTheDocument();
    const winter = screen.getByRole("region", { name: "Winter Tasting" });
    expect(within(winter).getByText("No bookings yet.")).toBeInTheDocument();
  });
});

describe("StaffPage booking management", () => {
  function signedInFetch(initialGroups = groups) {
    let current = structuredClone(initialGroups);
    const spy = vi.spyOn(globalThis, "fetch").mockImplementation(async (input, init) => {
      const url = String(input);
      const method = init?.method ?? "GET";
      if (url === "/api/staff/session" && method === "GET") return jsonResponse(200, { data: { authenticated: true } });
      if (url === "/api/staff/bookings") return jsonResponse(200, { data: current });
      if (url === "/api/staff/bookings/KB-7QXM2D" && method === "DELETE") {
        current = current.map((group) =>
          group.id === "riesling-evening"
            ? { ...group, seatsLeft: 12, bookings: [] }
            : group,
        );
        return new Response(null, { status: 204 });
      }
      if (url === "/api/staff/session" && method === "DELETE") return new Response(null, { status: 204 });
      return jsonResponse(404, { error: { code: "NOT_FOUND", message: "Not found." } });
    });
    return spy;
  }

  it("cancels a booking after confirmation and frees its seats in the list", async () => {
    const spy = signedInFetch();
    vi.spyOn(window, "confirm").mockReturnValue(true);
    const user = userEvent.setup();
    renderStaff();

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    await user.click(within(riesling).getByRole("button", { name: "Cancel" }));

    expect(window.confirm).toHaveBeenCalled();
    expect(await within(riesling).findByText("No bookings yet.")).toBeInTheDocument();
    expect(within(riesling).getByText("12 seats left")).toBeInTheDocument();
    expect(spy).toHaveBeenCalledWith("/api/staff/bookings/KB-7QXM2D", expect.objectContaining({ method: "DELETE" }));
  });

  it("keeps the booking when the cancellation is declined", async () => {
    const spy = signedInFetch();
    vi.spyOn(window, "confirm").mockReturnValue(false);
    const user = userEvent.setup();
    renderStaff();

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    await user.click(within(riesling).getByRole("button", { name: "Cancel" }));

    expect(within(riesling).getByText("Anna Keller")).toBeInTheDocument();
    expect(spy).not.toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ method: "DELETE" }));
  });

  it("returns to the password form when the session has ended", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation(async (input, init) => {
      const url = String(input);
      const method = init?.method ?? "GET";
      if (url === "/api/staff/session" && method === "GET") return jsonResponse(200, { data: { authenticated: true } });
      if (url === "/api/staff/bookings") {
        return jsonResponse(401, { error: { code: "UNAUTHENTICATED", message: "Please sign in to see bookings." } });
      }
      return jsonResponse(404, { error: { code: "NOT_FOUND", message: "Not found." } });
    });

    renderStaff();

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });

  it("signs out and returns to the password form", async () => {
    signedInFetch();
    const user = userEvent.setup();
    renderStaff();

    await user.click(await screen.findByRole("button", { name: "Sign out" }));

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
  });
});
