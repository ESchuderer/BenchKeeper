// @vitest-environment jsdom
import { screen, within } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { TastingsPage } from "../../client/pages/TastingsPage.js";
import { TASTING_LIST, mockFetch, renderAt } from "./helpers.js";

afterEach(() => {
  vi.restoreAllMocks();
});

describe("TastingsPage", () => {
  it("lists each tasting with date, price per guest and seats left", async () => {
    mockFetch([{ path: "/api/tastings", body: { data: TASTING_LIST } }]);

    renderAt(<TastingsPage />, "/", "/");

    const card = await screen.findByRole("article", { name: "Riesling Evening" });
    expect(within(card).getByText(/6 Nov 2026/)).toBeInTheDocument();
    expect(within(card).getByText("18:00")).toBeInTheDocument();
    expect(within(card).getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(within(card).getByText("12 seats left")).toBeInTheDocument();
  });

  it("offers a Book link for each tasting with seats left", async () => {
    mockFetch([{ path: "/api/tastings", body: { data: TASTING_LIST } }]);

    renderAt(<TastingsPage />, "/", "/");

    const link = await screen.findByRole("link", { name: "Book Riesling Evening" });
    expect(link).toHaveAttribute("href", "/tastings/riesling-evening/book");
    expect(screen.getByRole("link", { name: "Book Winter Tasting" })).toBeInTheDocument();
  });

  it("marks a fully booked tasting and offers no booking link for it", async () => {
    mockFetch([{ path: "/api/tastings", body: { data: TASTING_LIST } }]);

    renderAt(<TastingsPage />, "/", "/");

    const card = await screen.findByRole("article", { name: "Red Wine Cellar Tour" });
    expect(within(card).getByText("Fully booked")).toBeInTheDocument();
    expect(within(card).queryByRole("link")).not.toBeInTheDocument();
    expect(within(card).queryByText(/seats left/)).not.toBeInTheDocument();
  });

  it("shows a friendly message when the tastings cannot be loaded", async () => {
    mockFetch([{ path: "/api/tastings", networkError: true }]);

    renderAt(<TastingsPage />, "/", "/");

    expect(await screen.findByRole("alert")).toHaveTextContent(/could not load the tastings/i);
  });
});
