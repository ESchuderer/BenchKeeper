import type { ReactElement } from "react";
import { render } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router";
import { vi } from "vitest";

export interface MockRoute {
  method?: string;
  path: string;
  status?: number;
  body?: unknown;
  /** Thrown instead of returning a response, to simulate the server being unreachable. */
  networkError?: boolean;
}

export function jsonResponse(status: number, body?: unknown): Response {
  if (body === undefined) return new Response(null, { status });
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

/** Replaces fetch with a router of canned responses; returns the spy for assertions. */
export function mockFetch(routes: MockRoute[]) {
  return vi.spyOn(globalThis, "fetch").mockImplementation(async (input, init) => {
    const url = new URL(String(input), "http://localhost");
    const method = init?.method ?? "GET";
    const route = routes.find((candidate) => (candidate.method ?? "GET") === method && candidate.path === url.pathname);
    if (!route) return jsonResponse(404, { error: { code: "NOT_FOUND", message: "Not found." } });
    if (route.networkError) throw new TypeError("Failed to fetch");
    return jsonResponse(route.status ?? 200, route.body);
  });
}

export function renderAt(ui: ReactElement, path: string, routePattern: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path={routePattern} element={ui} />
      </Routes>
    </MemoryRouter>,
  );
}

export const TASTING_LIST = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00:00+01:00",
    pricePerGuest: 25,
    seats: 12,
    seatsLeft: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00:00+01:00",
    pricePerGuest: 32,
    seats: 8,
    seatsLeft: 0,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00:00+01:00",
    pricePerGuest: 28,
    seats: 10,
    seatsLeft: 4,
  },
];
