import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import request from "supertest";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createApp } from "../../server/app.js";
import { BookingStore } from "../../server/bookingStore.js";

const PASSWORD = "vintage-2026";
const RIESLING = "riesling-evening";
const CELLAR = "red-wine-cellar-tour";

let dir: string;

beforeEach(() => {
  dir = mkdtempSync(path.join(tmpdir(), "kb-api-"));
});

afterEach(() => {
  rmSync(dir, { recursive: true, force: true });
});

function setup(options: { loginLimit?: number; bookingLimit?: number; clientDir?: string } = {}) {
  const store = BookingStore.open(path.join(dir, "bookings.json"));
  const app = createApp({
    store,
    staffPassword: PASSWORD,
    limits: { login: options.loginLimit ?? 1000, booking: options.bookingLimit ?? 1000 },
    clientDir: options.clientDir,
  });
  return request(app);
}

const guest = { name: "Anna Keller", email: "anna@example.com", guests: 2 };

async function signIn(api: ReturnType<typeof setup>) {
  const response = await api.post("/api/staff/session").send({ password: PASSWORD });
  const cookie = response.headers["set-cookie"]?.[0] ?? "";
  return cookie.split(";")[0];
}

describe("GET /api/tastings", () => {
  it("lists tastings with seats left", async () => {
    const api = setup();

    const response = await api.get("/api/tastings");

    expect(response.status).toBe(200);
    expect(response.body.data).toHaveLength(3);
    expect(response.body.data[0]).toMatchObject({
      id: RIESLING,
      title: "Riesling Evening",
      pricePerGuest: 25,
      seats: 12,
      seatsLeft: 12,
    });
  });

  it("reduces seats left after a booking", async () => {
    const api = setup();
    await api.post(`/api/tastings/${RIESLING}/bookings`).send({ ...guest, guests: 3 });

    const response = await api.get(`/api/tastings/${RIESLING}`);

    expect(response.body.data.seatsLeft).toBe(9);
  });

  it("returns 404 for an unknown tasting", async () => {
    const response = await setup().get("/api/tastings/nope");

    expect(response.status).toBe(404);
    expect(response.body.error.code).toBe("TASTING_NOT_FOUND");
  });
});

describe("POST /api/tastings/:id/bookings", () => {
  it("creates a booking and returns the confirmation details", async () => {
    const api = setup();

    const response = await api.post(`/api/tastings/${CELLAR}/bookings`).send(guest);

    expect(response.status).toBe(201);
    expect(response.body.data).toEqual({
      reference: expect.stringMatching(/^KB-[A-Z2-9]{6}$/),
      tastingId: CELLAR,
      tastingTitle: "Red Wine Cellar Tour",
      startsAt: "2026-11-14T15:00:00+01:00",
      guests: 2,
      total: 64,
    });
  });

  it("accepts guests as a string, as sent by the form", async () => {
    const response = await setup()
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send({ ...guest, guests: "4" });

    expect(response.status).toBe(201);
    expect(response.body.data.guests).toBe(4);
    expect(response.body.data.total).toBe(100);
  });

  it("returns field errors next to the fields that are wrong", async () => {
    const response = await setup()
      .post(`/api/tastings/${RIESLING}/bookings`)
      .send({ name: "", email: "anna@", guests: 9 });

    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe("VALIDATION_FAILED");
    expect(Object.keys(response.body.error.fields).sort()).toEqual(["email", "guests", "name"]);
  });

  it("refuses more guests than seats left and says how many are left", async () => {
    const api = setup();
    await api.post(`/api/tastings/${CELLAR}/bookings`).send({ ...guest, guests: 5 });

    const response = await api.post(`/api/tastings/${CELLAR}/bookings`).send({ ...guest, guests: 4 });

    expect(response.status).toBe(409);
    expect(response.body.error.code).toBe("SEATS_UNAVAILABLE");
    expect(response.body.error.seatsLeft).toBe(3);
    expect(response.body.error.fields.guests).toBe("Only 3 seats are left for this tasting.");
  });

  it("says a tasting is fully booked when no seats are left", async () => {
    const api = setup();
    await api.post(`/api/tastings/${CELLAR}/bookings`).send({ ...guest, guests: 8 });

    const response = await api.post(`/api/tastings/${CELLAR}/bookings`).send(guest);

    expect(response.status).toBe(409);
    expect(response.body.error.message).toBe("This tasting is fully booked.");
  });

  it("returns 404 for an unknown tasting", async () => {
    const response = await setup().post("/api/tastings/nope/bookings").send(guest);

    expect(response.status).toBe(404);
  });

  it("rejects bodies that are not JSON", async () => {
    const response = await setup()
      .post(`/api/tastings/${RIESLING}/bookings`)
      .set("Content-Type", "text/plain")
      .send("name=Anna");

    expect(response.status).toBe(415);
    expect(response.body.error.code).toBe("UNSUPPORTED_MEDIA_TYPE");
  });

  it("rejects malformed JSON with a 400", async () => {
    const response = await setup()
      .post(`/api/tastings/${RIESLING}/bookings`)
      .set("Content-Type", "application/json")
      .send("{ broken");

    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe("INVALID_JSON");
  });

  it("is rate limited per client", async () => {
    const api = setup({ bookingLimit: 2 });
    await api.post(`/api/tastings/${RIESLING}/bookings`).send(guest);
    await api.post(`/api/tastings/${RIESLING}/bookings`).send(guest);

    const response = await api.post(`/api/tastings/${RIESLING}/bookings`).send(guest);

    expect(response.status).toBe(429);
    expect(response.body.error.code).toBe("TOO_MANY_REQUESTS");
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the confirmation without personal details", async () => {
    const api = setup();
    const created = await api.post(`/api/tastings/${RIESLING}/bookings`).send(guest);

    const response = await api.get(`/api/bookings/${created.body.data.reference}`);

    expect(response.status).toBe(200);
    expect(response.body.data).toEqual(created.body.data);
    expect(response.body.data).not.toHaveProperty("email");
    expect(response.body.data).not.toHaveProperty("name");
  });

  it("returns 404 for an unknown reference", async () => {
    const response = await setup().get("/api/bookings/KB-ZZZZZZ");

    expect(response.status).toBe(404);
    expect(response.body.error.code).toBe("BOOKING_NOT_FOUND");
  });
});

describe("staff sign-in", () => {
  it("sets an HttpOnly, SameSite=Strict session cookie for the right password", async () => {
    const response = await setup().post("/api/staff/session").send({ password: PASSWORD });

    expect(response.status).toBe(200);
    const cookie = response.headers["set-cookie"][0];
    expect(cookie).toMatch(/^kb_staff=[^;]+/);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
  });

  it("refuses a wrong password without echoing it", async () => {
    const response = await setup().post("/api/staff/session").send({ password: "guess-123" });

    expect(response.status).toBe(401);
    expect(response.body.error.fields.password).toBe("That password is not correct.");
    expect(JSON.stringify(response.body)).not.toContain("guess-123");
    expect(response.headers["set-cookie"]).toBeUndefined();
  });

  it("refuses an empty password as a field error", async () => {
    const response = await setup().post("/api/staff/session").send({ password: "" });

    expect(response.status).toBe(400);
    expect(response.body.error.fields.password).toBe("Please enter the password.");
  });

  it("throttles repeated failed sign-ins", async () => {
    const api = setup({ loginLimit: 3 });
    for (let attempt = 0; attempt < 3; attempt += 1) {
      await api.post("/api/staff/session").send({ password: "wrong" });
    }

    const response = await api.post("/api/staff/session").send({ password: PASSWORD });

    expect(response.status).toBe(429);
  });

  it("reports whether the caller is signed in", async () => {
    const api = setup();
    const cookie = await signIn(api);

    expect((await api.get("/api/staff/session")).body.data).toEqual({ authenticated: false });
    expect((await api.get("/api/staff/session").set("Cookie", cookie)).body.data).toEqual({
      authenticated: true,
    });
  });

  it("ends the session on sign-out", async () => {
    const api = setup();
    const cookie = await signIn(api);

    const signOut = await api.delete("/api/staff/session").set("Cookie", cookie);
    const after = await api.get("/api/staff/bookings").set("Cookie", cookie);

    expect(signOut.status).toBe(204);
    expect(after.status).toBe(401);
  });
});

describe("staff booking management", () => {
  it("refuses booking data without a valid session", async () => {
    const response = await setup().get("/api/staff/bookings");

    expect(response.status).toBe(401);
    expect(response.body.error.code).toBe("UNAUTHENTICATED");
    expect(response.body.data).toBeUndefined();
  });

  it("lists every tasting with its bookings, including people's details", async () => {
    const api = setup();
    await api.post(`/api/tastings/${RIESLING}/bookings`).send(guest);
    const cookie = await signIn(api);

    const response = await api.get("/api/staff/bookings").set("Cookie", cookie);

    expect(response.status).toBe(200);
    const groups = response.body.data;
    expect(groups.map((group: { id: string }) => group.id)).toEqual([
      RIESLING,
      CELLAR,
      "winter-tasting",
    ]);
    expect(groups[0].bookings).toEqual([
      expect.objectContaining({ name: "Anna Keller", email: "anna@example.com", guests: 2 }),
    ]);
    expect(groups[1].bookings).toEqual([]);
  });

  it("cancels a booking and frees its seats", async () => {
    const api = setup();
    const created = await api.post(`/api/tastings/${RIESLING}/bookings`).send({ ...guest, guests: 3 });
    const cookie = await signIn(api);

    const response = await api
      .delete(`/api/staff/bookings/${created.body.data.reference}`)
      .set("Cookie", cookie);

    expect(response.status).toBe(204);
    expect((await api.get(`/api/tastings/${RIESLING}`)).body.data.seatsLeft).toBe(12);
    expect((await api.get(`/api/bookings/${created.body.data.reference}`)).status).toBe(404);
  });

  it("refuses to cancel without a session", async () => {
    const api = setup();
    const created = await api.post(`/api/tastings/${RIESLING}/bookings`).send(guest);

    const response = await api.delete(`/api/staff/bookings/${created.body.data.reference}`);

    expect(response.status).toBe(401);
    expect((await api.get(`/api/tastings/${RIESLING}`)).body.data.seatsLeft).toBe(10);
  });

  it("returns 404 when cancelling an unknown reference", async () => {
    const api = setup();
    const cookie = await signIn(api);

    const response = await api.delete("/api/staff/bookings/KB-ZZZZZZ").set("Cookie", cookie);

    expect(response.status).toBe(404);
    expect(response.body.error.code).toBe("BOOKING_NOT_FOUND");
  });
});

describe("routing", () => {
  it("returns JSON 404 for unknown API paths", async () => {
    const response = await setup().get("/api/unknown");

    expect(response.status).toBe(404);
    expect(response.body.error.code).toBe("NOT_FOUND");
  });

  it("serves the client build and falls back to index.html for app routes", async () => {
    const clientDir = path.join(dir, "client");
    const { mkdirSync, writeFileSync } = await import("node:fs");
    mkdirSync(clientDir);
    writeFileSync(path.join(clientDir, "index.html"), "<div id=\"root\"></div>");
    const api = setup({ clientDir });

    const home = await api.get("/");
    const deep = await api.get("/bookings/KB-ABCDEF");

    expect(home.status).toBe(200);
    expect(home.text).toContain('id="root"');
    expect(deep.status).toBe(200);
    expect(deep.text).toContain('id="root"');
  });
});

describe("error handling", () => {
  it("rejects oversized request bodies with 413", async () => {
    const response = await setup()
      .post(`/api/tastings/${RIESLING}/bookings`)
      .set("Content-Type", "application/json")
      .send(JSON.stringify({ name: "x".repeat(20_000), email: "a@b.de", guests: 1 }));

    expect(response.status).toBe(413);
    expect(response.body.error.code).toBe("PAYLOAD_TOO_LARGE");
  });

  it("hides internal failures behind a generic 500 and logs the details", async () => {
    const store = BookingStore.open(path.join(dir, "bookings.json"));
    vi.spyOn(store, "seatsLeft").mockImplementation(() => {
      throw new Error("disk on fire");
    });
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => undefined);
    const api = request(createApp({ store, staffPassword: PASSWORD }));

    const response = await api.get("/api/tastings");

    expect(response.status).toBe(500);
    expect(response.body.error).toEqual({
      code: "INTERNAL_ERROR",
      message: "Something went wrong. Please try again.",
    });
    expect(JSON.stringify(response.body)).not.toContain("disk on fire");
    expect(errorSpy).toHaveBeenCalledWith(expect.any(String), expect.any(Error));
    errorSpy.mockRestore();
  });

  it("marks the staff cookie Secure when cookies are configured for HTTPS", async () => {
    const store = BookingStore.open(path.join(dir, "bookings.json"));
    const api = request(createApp({ store, staffPassword: PASSWORD, secureCookies: true }));

    const response = await api.post("/api/staff/session").send({ password: PASSWORD });

    expect(response.headers["set-cookie"][0]).toMatch(/; Secure/);
  });
});

describe("public reference lookup", () => {
  it("is rate limited so references cannot be enumerated quickly", async () => {
    const store = BookingStore.open(path.join(dir, "bookings.json"));
    const api = request(createApp({ store, staffPassword: PASSWORD, limits: { lookup: 2 } }));

    const statuses: number[] = [];
    for (let attempt = 0; attempt < 3; attempt += 1) {
      statuses.push((await api.get("/api/bookings/KB-ZZZZZZ")).status);
    }

    expect(statuses).toEqual([404, 404, 429]);
  });
});
