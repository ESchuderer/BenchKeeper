import { existsSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { BookingStore, SeatsUnavailableError } from "../../server/bookingStore.js";

const RIESLING = "riesling-evening"; // 12 seats
const CELLAR = "red-wine-cellar-tour"; // 8 seats
const REFERENCE_PATTERN = /^KB-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}$/;

let dir: string;
let filePath: string;

beforeEach(() => {
  dir = mkdtempSync(path.join(tmpdir(), "kieselbrunnen-"));
  filePath = path.join(dir, "bookings.json");
});

afterEach(() => {
  rmSync(dir, { recursive: true, force: true });
});

function book(store: BookingStore, tastingId: string, guests: number, name = "Anna") {
  return store.create({ tastingId, name, email: "anna@example.com", guests });
}

describe("BookingStore", () => {
  it("starts with no bookings when the file does not exist", () => {
    const store = BookingStore.open(filePath);

    expect(store.list()).toEqual([]);
    expect(store.seatsLeft(RIESLING)).toBe(12);
    expect(existsSync(filePath)).toBe(false);
  });

  it("creates the file on the first booking", () => {
    const store = BookingStore.open(filePath);

    book(store, RIESLING, 2);

    expect(existsSync(filePath)).toBe(true);
    expect(JSON.parse(readFileSync(filePath, "utf8")).bookings).toHaveLength(1);
  });

  it("reduces seats left by the guests of each booking", () => {
    const store = BookingStore.open(filePath);

    book(store, RIESLING, 3);
    book(store, RIESLING, 4);

    expect(store.seatsLeft(RIESLING)).toBe(5);
    expect(store.seatsLeft(CELLAR)).toBe(8);
  });

  it("accepts a booking for exactly the seats left", () => {
    const store = BookingStore.open(filePath);
    book(store, CELLAR, 5);

    book(store, CELLAR, 3);

    expect(store.seatsLeft(CELLAR)).toBe(0);
  });

  it("rejects a booking larger than the seats left and reports how many are left", () => {
    const store = BookingStore.open(filePath);
    book(store, CELLAR, 5);

    const attempt = () => book(store, CELLAR, 4);

    expect(attempt).toThrow(SeatsUnavailableError);
    expect(attempt).toThrow(expect.objectContaining({ seatsLeft: 3 }));
    expect(store.seatsLeft(CELLAR)).toBe(3);
    expect(store.list()).toHaveLength(1);
  });

  it("rejects bookings for an unknown tasting", () => {
    const store = BookingStore.open(filePath);

    const attempt = () => store.create({ tastingId: "unknown", name: "Anna", email: "a@b.de", guests: 1 });

    expect(attempt).toThrow(/unknown tasting/i);
  });

  it("issues unique references in the KB-XXXXXX format", () => {
    const store = BookingStore.open(filePath);

    const references = Array.from({ length: 200 }, () => {
      const { reference } = book(store, RIESLING, 1);
      store.cancel(reference);
      return reference;
    });

    expect(new Set(references).size).toBe(references.length);
    for (const reference of references) {
      expect(reference).toMatch(REFERENCE_PATTERN);
    }
  });

  it("finds a booking by reference", () => {
    const store = BookingStore.open(filePath);
    const created = book(store, RIESLING, 2, "Ben");

    expect(store.find(created.reference)).toEqual(created);
    expect(store.find("KB-NOPE00")).toBeUndefined();
  });

  it("cancels a booking and frees its seats", () => {
    const store = BookingStore.open(filePath);
    const created = book(store, RIESLING, 3);

    const cancelled = store.cancel(created.reference);

    expect(cancelled).toBe(true);
    expect(store.find(created.reference)).toBeUndefined();
    expect(store.seatsLeft(RIESLING)).toBe(12);
  });

  it("reports nothing cancelled for an unknown reference", () => {
    const store = BookingStore.open(filePath);

    expect(store.cancel("KB-NOPE00")).toBe(false);
  });

  it("keeps bookings and seat counts after reopening the file", () => {
    const first = BookingStore.open(filePath);
    const created = book(first, RIESLING, 4, "Clara");

    const reopened = BookingStore.open(filePath);

    expect(reopened.find(created.reference)?.name).toBe("Clara");
    expect(reopened.seatsLeft(RIESLING)).toBe(8);
  });

  it("refuses to start from a corrupt file instead of losing bookings", () => {
    writeFileSync(filePath, "{ not json");

    expect(() => BookingStore.open(filePath)).toThrow(/bookings file/i);
  });

  it("keeps the bookings file private to its owner", () => {
    const store = BookingStore.open(filePath);

    book(store, RIESLING, 1);

    expect(statSync(filePath).mode & 0o777).toBe(0o600);
  });

  it("leaves only the bookings file behind after writing", () => {
    const store = BookingStore.open(filePath);

    book(store, RIESLING, 1);

    expect(readdirSync(dir)).toEqual(["bookings.json"]);
  });
});
