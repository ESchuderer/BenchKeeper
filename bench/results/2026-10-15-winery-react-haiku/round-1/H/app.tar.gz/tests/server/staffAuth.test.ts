import { describe, expect, it } from "vitest";
import { StaffSessions, requireStaffPassword } from "../../server/staffAuth.js";

const EIGHT_HOURS_MS = 8 * 60 * 60 * 1000;

describe("requireStaffPassword", () => {
  it("returns the configured password", () => {
    expect(requireStaffPassword({ STAFF_PASSWORD: "vintage-2026" })).toBe("vintage-2026");
  });

  it.each([[undefined], [""], ["   "]])("refuses to start when STAFF_PASSWORD is %j", (value) => {
    expect(() => requireStaffPassword({ STAFF_PASSWORD: value })).toThrow(/STAFF_PASSWORD/);
  });
});

describe("StaffSessions", () => {
  it("accepts only the exact configured password", () => {
    const sessions = new StaffSessions({ password: "vintage-2026" });

    expect(sessions.verifyPassword("vintage-2026")).toBe(true);
    expect(sessions.verifyPassword("vintage-2025")).toBe(false);
    expect(sessions.verifyPassword("vintage-2026 ")).toBe(false);
    expect(sessions.verifyPassword("")).toBe(false);
  });

  it("issues unguessable tokens that are valid until they expire", () => {
    let clock = 1_000;
    const sessions = new StaffSessions({ password: "x", now: () => clock });

    const token = sessions.createSession();

    expect(token).toMatch(/^[A-Za-z0-9_-]{43}$/);
    expect(sessions.isValid(token)).toBe(true);
    clock += EIGHT_HOURS_MS - 1;
    expect(sessions.isValid(token)).toBe(true);
    clock += 1;
    expect(sessions.isValid(token)).toBe(false);
  });

  it("rejects unknown and missing tokens", () => {
    const sessions = new StaffSessions({ password: "x" });

    expect(sessions.isValid("made-up")).toBe(false);
    expect(sessions.isValid(undefined)).toBe(false);
  });

  it("ends a session when asked", () => {
    const sessions = new StaffSessions({ password: "x" });
    const token = sessions.createSession();

    sessions.end(token);

    expect(sessions.isValid(token)).toBe(false);
  });
});
