import { describe, expect, it } from "vitest";
import { bookingInputSchema } from "../../shared/bookingSchema.js";

const validInput = { name: "Anna Keller", email: "anna@example.com", guests: "2" };

function fieldErrors(input: unknown): Record<string, string> {
  const result = bookingInputSchema.safeParse(input);
  if (result.success) return {};
  const errors: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const field = String(issue.path[0]);
    errors[field] ??= issue.message;
  }
  return errors;
}

describe("bookingInputSchema", () => {
  it("accepts a valid booking and converts guests to a number", () => {
    const result = bookingInputSchema.parse(validInput);

    expect(result).toEqual({ name: "Anna Keller", email: "anna@example.com", guests: 2 });
  });

  it("accepts guests sent as a JSON number", () => {
    expect(bookingInputSchema.parse({ ...validInput, guests: 8 }).guests).toBe(8);
  });

  it("trims name and email", () => {
    const result = bookingInputSchema.parse({ ...validInput, name: "  Anna  ", email: " a@b.de " });

    expect(result.name).toBe("Anna");
    expect(result.email).toBe("a@b.de");
  });

  it("requires a name", () => {
    expect(fieldErrors({ ...validInput, name: "   " }).name).toBe("Please enter your name.");
  });

  it("rejects names longer than 100 characters", () => {
    expect(fieldErrors({ ...validInput, name: "x".repeat(101) }).name).toMatch(/100/);
  });

  it("requires an email and rejects malformed addresses", () => {
    expect(fieldErrors({ ...validInput, email: "" }).email).toBe("Please enter your email address.");
    expect(fieldErrors({ ...validInput, email: "anna@" }).email).toBe(
      "Please enter a valid email address.",
    );
  });

  it.each([
    ["0", "At least 1 guest is required."],
    ["9", "You can book for at most 8 guests."],
    ["2.5", "Guests must be a whole number."],
    ["", "Please enter the number of guests."],
    ["many", "Please enter the number of guests."],
  ])("rejects guests %j with a clear message", (guests, message) => {
    expect(fieldErrors({ ...validInput, guests }).guests).toBe(message);
  });
});
