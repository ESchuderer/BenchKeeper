import { describe, expect, it } from "vitest";
import {
  TASTINGS,
  findTasting,
  formatEuros,
  formatSeatsLeft,
  formatTastingDate,
  formatTastingTime,
  seatsShortageMessage,
} from "../../shared/tastings.js";

describe("tasting catalogue", () => {
  it("offers the three tastings from the winery brief", () => {
    // Arrange
    const summary = TASTINGS.map((t) => [t.title, t.startsAt, t.pricePerGuest, t.seats]);

    // Act / Assert
    expect(summary).toEqual([
      ["Riesling Evening", "2026-11-06T18:00:00+01:00", 25, 12],
      ["Red Wine Cellar Tour", "2026-11-14T15:00:00+01:00", 32, 8],
      ["Winter Tasting", "2026-12-05T17:00:00+01:00", 28, 10],
    ]);
  });

  it("gives every tasting a unique, URL-safe id", () => {
    const ids = TASTINGS.map((t) => t.id);

    expect(new Set(ids).size).toBe(ids.length);
    expect(ids).toEqual(["riesling-evening", "red-wine-cellar-tour", "winter-tasting"]);
  });

  it("finds a tasting by id and returns undefined for unknown ids", () => {
    expect(findTasting("winter-tasting")?.title).toBe("Winter Tasting");
    expect(findTasting("does-not-exist")).toBeUndefined();
  });
});

describe("formatting helpers", () => {
  it("shows the date and time in Berlin time", () => {
    expect(formatTastingDate("2026-11-06T18:00:00+01:00")).toBe("Fri, 6 Nov 2026");
    expect(formatTastingTime("2026-11-06T18:00:00+01:00")).toBe("18:00");
    expect(formatTastingTime("2026-11-06T17:00:00Z")).toBe("18:00");
  });

  it("explains how many seats are left when a request is too large", () => {
    expect(seatsShortageMessage(4)).toBe("Only 4 seats are left for this tasting.");
    expect(seatsShortageMessage(1)).toBe("Only 1 seat is left for this tasting.");
    expect(seatsShortageMessage(0)).toBe("This tasting is fully booked.");
  });

  it("uses singular for one seat and plural otherwise", () => {
    expect(formatSeatsLeft(1)).toBe("1 seat left");
    expect(formatSeatsLeft(12)).toBe("12 seats left");
  });

  it("formats euro amounts as whole euros", () => {
    expect(formatEuros(64)).toBe("EUR 64");
  });
});
