# Weingut Kieselbrunnen: tasting bookings

A small web app where guests book wine tastings online and staff see and cancel the bookings.

- Guests: `/` lists the tastings, `/tastings/<id>/book` takes a booking, `/bookings/<reference>` shows the confirmation.
- Staff: `/staff` asks for the staff password, then lists all bookings grouped by tasting, with a Cancel button per booking.

The specification is in `openspec/changes/tasting-bookings/`.

## Requirements

- Node.js 22 or newer

## Running it

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start
```

The app is then served at `http://localhost:3000`. Use `PORT` to choose another port.

| Variable         | Required | Purpose                                                                 |
|------------------|----------|-------------------------------------------------------------------------|
| `STAFF_PASSWORD` | yes, for staff | Password for `/staff`. When unset, staff sign-in is refused.       |
| `PORT`           | no       | Port to listen on. Defaults to `3000`.                                  |
| `TRUST_PROXY`    | behind a TLS proxy | Number of proxies in front of the app. Makes the staff cookie `Secure` and the per-client limits see the real client. |

## Development

```sh
npm run build && npm start        # terminal 1: API and built interface on port 3000
npm run dev                       # terminal 2: Vite dev server, proxies /api to port 3000
```

## Checks

```sh
npm run typecheck   # TypeScript, client and server
npm run lint        # ESLint
npm test            # unit and API tests (Vitest, Testing Library, Supertest)
npm run e2e         # builds, then runs the browser journeys against `npm start`
```

`npm run e2e` needs a Chromium that Playwright can start. Install it with
`npx playwright install chromium`. On a machine without the system libraries that
Chromium needs, `npx playwright install-deps chromium` installs them (requires root).

## Things to know

- **Bookings are kept in memory.** Restarting the server clears all bookings and signs staff out. The tastings themselves are fixed in `src/shared/tastings.ts`.
- **Seat limits are enforced on the server.** A booking that would take more seats than are left is refused, even if two guests submit at the same moment. This holds for one server process; a second process would need a shared store.
- **Limits are per client IP.** Sign-in allows 10 failed attempts per 15-minute window, booking requests 20 per window, and the API overall 300 per window. Behind a reverse proxy set `TRUST_PROXY`, otherwise every visitor shares the proxy's address.
- **Use a long staff password** (20 characters or more). Sign-in limits are per client, so a large set of addresses could still guess a short password.
- **Serve the app over HTTPS.** The app does not redirect HTTP to HTTPS; do that at the proxy.
- **No payments or e-mails are sent.** Booking confirms immediately and the total is shown for information only.

## Layout

```
src/shared/   tasting catalogue and booking validation, used by both sides
src/server/   Express app: guest API, staff API, in-memory booking store
src/client/   React interface: pages, components, API client
e2e/          Playwright journeys against the built server
openspec/     specification, design and task list for this change
```
