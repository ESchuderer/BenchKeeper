import { expect, test, type Page } from '@playwright/test'

const STAFF_PASSWORD = 'e2e-staff-password'
const REFERENCE = /^KB-[A-Z2-9]{6}$/

async function bookTasting(page: Page, title: string, guests: string, name = 'Anna Keller') {
  await page.goto('/')
  await page.getByRole('link', { name: `Book ${title}` }).click()
  await page.getByLabel('Name').fill(name)
  await page.getByLabel('Email').fill('anna@example.de')
  await page.getByLabel('Guests').fill(guests)
  await page.getByRole('button', { name: 'Book', exact: true }).click()
}

/** Seats left shown on the start page for one tasting, read from its card. */
async function seatsLeft(page: Page, title: string): Promise<number> {
  await page.goto('/')
  const text = await page.getByRole('article', { name: title }).getByText(/seats? left/).textContent()
  return Number(text?.match(/\d+/)?.[0])
}

async function horizontalOverflow(page: Page): Promise<number> {
  return page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)
}

test('a guest books a tasting and sees the confirmation', async ({ page }) => {
  await page.goto('/')
  await expect(page.getByRole('heading', { name: 'Book a tasting' })).toBeVisible()
  await expect(page.getByText('12 seats left').first()).toBeVisible()

  await bookTasting(page, 'Riesling Evening', '2')

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
  await expect(page.getByText('Riesling Evening')).toBeVisible()
  await expect(page.getByText('2 guests')).toBeVisible()
  await expect(page.getByText('EUR 50')).toBeVisible()
  await expect(page.getByText(REFERENCE)).toBeVisible()

  // The confirmation survives a reload.
  await page.reload()
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
})

test('invalid input is reported next to the field it concerns', async ({ page }) => {
  await page.goto('/tastings/winter-tasting/book')
  await page.getByLabel('Email').fill('anna@')
  await page.getByLabel('Guests').fill('9')
  await page.getByRole('button', { name: 'Book', exact: true }).click()

  await expect(page.getByLabel('Name')).toHaveAccessibleDescription('Enter your name')
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Enter a valid email address')
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('Enter between 1 and 8 guests')
  await expect(page).toHaveURL(/\/tastings\/winter-tasting\/book$/)
})

test('a booking larger than the seats left is refused', async ({ page }) => {
  // Winter Tasting has 10 seats; take 8 so only 2 are left.
  await bookTasting(page, 'Winter Tasting', '8', 'Earlier Guest')
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()

  await page.goto('/tastings/winter-tasting/book')
  await page.getByLabel('Name').fill('Ben Ortiz')
  await page.getByLabel('Email').fill('ben@example.de')
  await page.getByLabel('Guests').fill('3')
  await page.getByRole('button', { name: 'Book', exact: true }).click()
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('Only 2 seats left for this tasting')
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0)

  // Taking exactly the seats left is accepted.
  await page.getByLabel('Guests').fill('2')
  await page.getByRole('button', { name: 'Book', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
})

test('a fully booked tasting cannot be booked', async ({ page }) => {
  await bookTasting(page, 'Red Wine Cellar Tour', '8', 'Full Table')
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()

  await page.goto('/')
  await expect(page.getByRole('article', { name: 'Red Wine Cellar Tour' }).getByText('Fully booked')).toBeVisible()

  await page.goto('/tastings/red-wine-cellar-tour/book')
  await expect(page.getByText('This tasting is fully booked')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Book', exact: true })).toBeDisabled()
})

test('staff sign in, see the booking, cancel it and free the seats', async ({ page }) => {
  // This journey books its own guest, so it does not depend on the others having run.
  await bookTasting(page, 'Riesling Evening', '1', 'Staff Check Guest')
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
  const reference = (await page.getByText(REFERENCE).textContent())?.trim() ?? ''
  const before = await seatsLeft(page, 'Riesling Evening')

  await page.goto('/staff')
  await page.getByLabel('Password').fill('wrong-password')
  await page.getByRole('button', { name: 'Sign in' }).click()
  await expect(page.getByLabel('Password')).toHaveAccessibleDescription('Incorrect password')

  await page.getByLabel('Password').fill(STAFF_PASSWORD)
  await page.getByRole('button', { name: 'Sign in' }).click()
  const group = page.getByRole('region', { name: 'Riesling Evening' })
  const row = group.getByRole('row', { name: new RegExp(reference) })
  await expect(row).toBeVisible()

  page.once('dialog', (dialog) => dialog.accept())
  await row.getByRole('button', { name: 'Cancel' }).click()
  await expect(row).toHaveCount(0)

  expect(await seatsLeft(page, 'Riesling Evening')).toBe(before + 1)
})

test.describe('on a 360 px wide phone', () => {
  test.use({ viewport: { width: 360, height: 780 } })

  test('the start page, booking form, confirmation and staff overview fit without sideways scrolling', async ({
    page,
    request,
  }) => {
    await page.goto('/')
    await expect(page.getByRole('article', { name: 'Winter Tasting' })).toBeVisible()
    expect(await horizontalOverflow(page)).toBe(0)

    await page.goto('/tastings/winter-tasting/book')
    await expect(page.getByLabel('Guests')).toBeVisible()
    expect(await horizontalOverflow(page)).toBe(0)

    const created = await request.post('/api/tastings/riesling-evening/bookings', {
      data: { name: 'Phone Guest', email: 'phone@example.de', guests: 1 },
    })
    const { reference } = await created.json()
    await page.goto(`/bookings/${reference}`)
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
    expect(await horizontalOverflow(page)).toBe(0)

    await page.goto('/staff')
    await page.getByLabel('Password').fill(STAFF_PASSWORD)
    await page.getByRole('button', { name: 'Sign in' }).click()
    await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible()
    expect(await horizontalOverflow(page)).toBe(0)
  })
})
