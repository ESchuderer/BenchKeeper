# Design

## Context

The repository is empty apart from OpenSpec scaffolding and agent configuration, so there is no existing code to conform to. The app runs in the project's development container with Node.js 22, must start with `npm start` on `PORT`, and must not depend on external services. See `proposal.md` for motivation and the `specs/` deltas for the required behaviour.

## Goals / Non-Goals

**Goals:**
- One process serves both the React interface and the JSON API, so `npm start` is the whole deployment.
- Seat limits hold under concurrent bookings.
- Validation rules are written once and produce the same messages in the browser and on the server.
- Staff access is protected by a password from the environment, with session cookies and sign-in throttling.
- The interface looks like a small winery's own site and works on a 360 px wide screen.

**Non-Goals:**
- Payments, email confirmations, guest-side cancellation or editing of bookings.
- An admin screen for tastings; the three tastings are fixed in code.
- Handling of tastings whose date has passed (none of the three is in the past).
- Multi-instance deployment, accounts for guests, internationalisation (English only).

## Decisions

**Stack.** TypeScript throughout. Client: React 19 with Vite, React Router for routes, TanStack Query for server state, React Hook Form with a Zod resolver for forms, Tailwind CSS v4 for styling. Server: Express 5 with `express-session`, `express-rate-limit`, `helmet` and Zod. Tests: Vitest, Testing Library, Supertest. Alternatives considered: Next.js (server rendering adds a second runtime and build model that this app does not need); a separate static host plus API (contradicts the single `npm start` requirement).

**Build and run.** `vite build` writes the client to `dist/client`; `tsc -p tsconfig.server.json` compiles the server to `dist/server`. `npm start` runs `dist/server/index.js`, which serves `dist/client` and falls back to `index.html` for non-API routes. Alternative: run TypeScript with `tsx` at runtime; rejected to avoid a runtime dependency on a loader.

**Persistence: in memory.** Bookings live in a `Map` keyed by reference inside the booking store. The app therefore starts with no bookings, as required, and restarting the process clears them. Alternative: a JSON file. Rejected for now because a file that survives restarts contradicts "starts with no bookings" unless the file is reset on start, and it adds write-ordering work for no requirement. The store is a small module with a narrow interface so a file or database store can replace it later.

**Seat enforcement.** The store checks the remaining seats and inserts the booking in one synchronous block with no `await` in between. Node runs that block to completion before handling another request, so two simultaneous bookings cannot both pass the check. This holds only while there is one process and the store stays synchronous; the design note for any future store is that the check and insert must share a transaction.

**Booking reference.** `KB-` followed by six characters from an alphabet without look-alikes (no 0/O, 1/I/L), generated with `crypto.randomInt`. A collision with an existing reference is retried. The reference is the only identifier the guest confirmation and staff cancellation use.

**Confirmation data.** `GET /api/bookings/:reference` returns the tasting, guest count, total and reference only. The guest's name and email are not exposed by this endpoint, so a leaked or guessed reference reveals no personal data.

**Dates and prices.** Start times are stored as local wall-clock strings (`2026-11-06T18:00`) and formatted with `timeZone: "UTC"` so the server and the browser cannot shift them. Prices are whole euros, so the total is `guests × price` with no rounding.

**Validation.** Zod schemas in `src/shared` define the booking input and the messages. The client uses them for immediate field errors, and the server re-runs them as the authority. Seat checks are server-only, with the client mirroring the seats-left number it was given to show "Only <n> seats left" before submitting. Error responses are `{ errors: { <field>: message } }` for field errors and `{ error: message }` for form-level errors (fully booked, not found).

**Staff authentication.** `POST /api/staff/session` compares SHA-256 digests of the submitted and expected passwords with `crypto.timingSafeEqual`, which avoids leaking the password through timing and avoids the length check that a direct comparison would need. On success the session ID is regenerated and `staff: true` is stored in the server-side session. The cookie is `httpOnly`, `sameSite: strict`, and `secure` when the request is HTTPS. The session secret is random per process start, so restarting also signs staff out. If `STAFF_PASSWORD` is unset, sign-in returns 503 and a single warning is logged at startup. Alternative: a hashed password in the environment; rejected because the environment variable is already a secret and the hash adds configuration without protecting anything more.

**Sign-in throttling.** `express-rate-limit` on the sign-in route allows 10 failed attempts per client IP in a fixed 15-minute window that starts with the client's first sign-in attempt (`skipSuccessfulRequests`), in memory. A block therefore ends when that window ends, which can be less than 15 minutes after the tenth failure; the spec was worded to match, rather than replacing the library with a hand-written lockout. The client IP is `req.ip`; the `TRUST_PROXY` setting (Express `trust proxy`) must be set when a TLS proxy sits in front, so that the secure cookie and the per-client limits see the real client.

**Headers.** `helmet` sets the default security headers, including a Content-Security-Policy that allows only same-origin scripts. No inline scripts or external fonts are used, so the policy stays strict.

**Visual design.** A cream background, dark wine accent, vine-green for success states and a muted gold rule for separators, with a serif heading stack (Iowan Old Style, Palatino, Georgia) and a system sans for body text. Corners are 4 px and there are no gradients or heavy shadows. Fonts are system fonts, so nothing is fetched from a third-party host.

## Risks / Trade-offs

- **Bookings are lost on restart.** → Documented in the README and the proposal; the store interface allows a durable store later without changing routes.
- **Single-process assumption.** Seat enforcement and rate limiting are in memory. → Run one instance; the design note above states what a second instance would break.
- **Staff sessions end on restart.** → Acceptable for a small app; staff sign in again.
- **Rate limit keyed by IP behind a proxy would throttle all staff together.** → Set `TRUST_PROXY` in the deployment that puts a proxy in front; noted in the README.
- **No global sign-in ceiling.** A per-IP limit can be evaded by a large set of addresses, but a global ceiling would let anyone lock staff out. → Accepted: rely on a long staff password (20+ characters, recommended in the README) and proxy-level rate limiting.
- **Booking and API limits.** 20 booking requests per client IP per 15 minutes, and 300 API requests per client IP per 15 minutes overall. → Generous for a family booking; a shared IP (an office, a hotel) could reach them, so the numbers are constants to revisit.
- **Per-process random session secret.** → No cross-restart sessions; avoids storing a secret in the repository.
