# Proposal

## Why

Weingut Kieselbrunnen runs wine tastings but has no online way for guests to book a place, and staff have no single view of who is coming. This change adds a small web app for guests to book tastings and for staff to see and cancel bookings.

## What Changes

- Guests see the upcoming tastings with date, time, price per guest and seats left, and can book any tasting that still has seats.
- Guests book through a form (Name, Email, Guests 1–8). The booking is rejected if it asks for more seats than are left, and invalid input is reported next to the field it concerns.
- A successful booking shows a confirmation page with the tasting, number of guests, total price and a booking reference.
- Staff sign in at `/staff` with a password taken from the `STAFF_PASSWORD` environment variable. Signed in, they see all bookings grouped by tasting and can cancel any booking; cancelling frees its seats.
- The app is served by a single process (`npm start`, port from `PORT`, default 3000). It has no external services and starts with no bookings.

Assumptions recorded in `design.md`: bookings are held in memory and are lost when the process restarts; the tastings are fixed in code; no payment is taken.

## Capabilities

### New Capabilities

- `tasting-bookings`: guest-facing listing of tastings, the booking flow with seat checks and validation, and the booking confirmation.
- `staff-bookings`: staff sign-in with a shared password, the bookings overview grouped by tasting, and cancellation of bookings.

### Modified Capabilities

None. The repository has no existing specs.

## Impact

- New application code in `src/` (React client, Express server, shared validation), build and test tooling in `package.json`, `README.md`.
- New runtime dependencies: React, React Router, Express, zod, express-session, express-rate-limit. No database, no external services.
- Environment variables: `STAFF_PASSWORD` (required for staff sign-in), `PORT` (optional, default 3000).
