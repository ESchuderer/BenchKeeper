## ADDED Requirements

### Requirement: Staff sign-in

The page `/staff` SHALL ask for a password in a field labelled "Password", with a button labelled "Sign in". The expected password SHALL come from the environment variable `STAFF_PASSWORD`. A correct password SHALL start a staff session; an incorrect password SHALL show "Incorrect password" and grant no access. The system MUST NOT reveal the expected password, and MUST NOT allow sign-in when `STAFF_PASSWORD` is not set.

#### Scenario: Password prompt

- **WHEN** a visitor without a staff session opens `/staff`
- **THEN** the page shows a "Password" field and a "Sign in" button and no booking data

#### Scenario: Correct password

- **GIVEN** `STAFF_PASSWORD` is set to a known value
- **WHEN** staff enter that value and select "Sign in"
- **THEN** the bookings overview is shown

#### Scenario: Incorrect password

- **WHEN** staff enter a wrong password and select "Sign in"
- **THEN** the message "Incorrect password" is shown and no bookings are visible

#### Scenario: Password not configured

- **GIVEN** `STAFF_PASSWORD` is not set
- **WHEN** anyone attempts to sign in at `/staff`
- **THEN** sign-in is refused with the message "Staff sign-in is currently unavailable" and no session is started

### Requirement: Sign-in protection

After 10 failed sign-in attempts from the same client within a 15-minute window, the system SHALL refuse further sign-in attempts from that client until that window ends. The window starts with the client's first sign-in attempt, whether or not it succeeds. Successful sign-ins do not count towards the limit.

#### Scenario: Too many failed attempts

- **WHEN** a client makes 10 failed sign-in attempts within 15 minutes
- **THEN** further sign-in attempts from that client are refused with "Too many sign-in attempts. Please try again later." even when the password is correct

### Requirement: Staff session

The staff session SHALL be held in a cookie that is not readable by page scripts. Staff SHALL be able to sign out, which ends the session. Requests to staff bookings data without a valid staff session SHALL be refused with an unauthorised response and reveal no booking data.

#### Scenario: Session cookie is protected

- **WHEN** staff sign in successfully
- **THEN** the session cookie is marked as not readable by page scripts and as same-site restricted

#### Scenario: Sign out

- **GIVEN** staff are signed in
- **WHEN** staff select "Sign out"
- **THEN** the sign-in page is shown again and the previous session no longer returns booking data

#### Scenario: Bookings request without session

- **WHEN** a request for the bookings list arrives without a valid staff session
- **THEN** the response is an unauthorised status and contains no booking data

### Requirement: Bookings overview

Signed in, staff SHALL see all bookings grouped by tasting. Each booking SHALL show the guest's name, email, number of guests and booking reference. Each tasting group SHALL show how many seats are booked out of its total. A tasting with no bookings SHALL show that there are no bookings.

#### Scenario: Bookings grouped by tasting

- **GIVEN** two bookings exist for Riesling Evening and one for Winter Tasting
- **WHEN** staff open the bookings overview
- **THEN** Riesling Evening lists its two bookings with name, email, guests and reference, and Winter Tasting lists its one booking

#### Scenario: Empty tasting

- **WHEN** staff open the bookings overview and Red Wine Cellar Tour has no bookings
- **THEN** its group shows "No bookings yet"

### Requirement: Cancelling a booking

Each booking in the overview SHALL have a button labelled "Cancel". Before a booking is cancelled, staff SHALL confirm the cancellation. Once cancelled, the booking SHALL disappear from the overview and its seats SHALL become available for new bookings.

#### Scenario: Cancel frees seats

- **GIVEN** a booking for 4 guests exists for Riesling Evening, which has 8 seats left
- **WHEN** staff cancel that booking
- **THEN** the booking no longer appears in the overview and Riesling Evening shows "12 seats left" on the start page

#### Scenario: Cancellation needs confirmation

- **WHEN** staff select "Cancel" on a booking
- **THEN** the booking is only cancelled after staff confirm; declining leaves the booking unchanged

#### Scenario: Booking already cancelled

- **GIVEN** a booking was cancelled in another browser session
- **WHEN** staff try to cancel the same booking from a stale page
- **THEN** the message "This booking no longer exists" is shown and the overview refreshes
