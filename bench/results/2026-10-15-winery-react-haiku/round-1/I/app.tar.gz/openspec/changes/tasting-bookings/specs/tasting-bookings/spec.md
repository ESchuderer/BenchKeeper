## ADDED Requirements

### Requirement: Tasting listing

The start page SHALL list every tasting with its title, date and time, price per guest and the number of seats left, shown as "<n> seats left". The tastings offered are Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats). When one seat is left the label SHALL read "1 seat left". Date and time SHALL be shown as the winery's local time, without conversion.

#### Scenario: Tastings are listed with their details

- **WHEN** a guest opens the start page
- **THEN** the page shows the three tastings with title, date and time, price per guest and "<n> seats left" for each

#### Scenario: Seats left reflect bookings

- **GIVEN** 5 guests have booked Riesling Evening
- **WHEN** a guest opens the start page
- **THEN** Riesling Evening shows "7 seats left"

#### Scenario: Fully booked tasting is marked

- **GIVEN** all 8 seats of Red Wine Cellar Tour are booked
- **WHEN** a guest opens the start page
- **THEN** Red Wine Cellar Tour shows "0 seats left" and a "Fully booked" label

### Requirement: Booking entry point

Each tasting SHALL have a link or button labelled "Book <tasting title>" (for example "Book Riesling Evening") that opens the booking form for that tasting at its own address.

#### Scenario: Book link opens the form for its tasting

- **WHEN** a guest selects "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens, showing the tasting title, date and time and price per guest

#### Scenario: Fully booked tasting still shows its form

- **GIVEN** Winter Tasting has 0 seats left
- **WHEN** a guest opens its booking form
- **THEN** the page states that the tasting is fully booked, and the form cannot be submitted

### Requirement: Booking form fields

The booking form SHALL have the fields "Name", "Email" and "Guests" (whole number from 1 to 8), and a button labelled "Book".

#### Scenario: Form shows the required fields

- **WHEN** a guest opens the booking form for any tasting with seats left
- **THEN** the form shows a "Name" field, an "Email" field, a "Guests" field accepting 1 to 8, and a "Book" button

### Requirement: Input validation

The system SHALL reject invalid booking input and SHALL show each error as a message next to the field it concerns. The system MUST NOT create a booking when any field is invalid.

- Name is required and SHALL be at most 100 characters after trimming surrounding whitespace.
- Email is required and SHALL be a syntactically valid email address of at most 254 characters.
- Guests is required and SHALL be a whole number from 1 to 8.

#### Scenario: Missing name

- **WHEN** a guest submits the form with an empty Name
- **THEN** the message "Enter your name" appears next to the Name field and no booking is created

#### Scenario: Invalid email

- **WHEN** a guest submits an Email value without a valid address format, for example "anna@"
- **THEN** the message "Enter a valid email address" appears next to the Email field and no booking is created

#### Scenario: Guests outside the allowed range

- **WHEN** a guest submits 0 or 9 as Guests
- **THEN** the message "Enter between 1 and 8 guests" appears next to the Guests field and no booking is created

#### Scenario: Guests is not a whole number

- **WHEN** a guest submits 2.5 as Guests
- **THEN** the message "Enter a whole number of guests" appears next to the Guests field and no booking is created

### Requirement: Seat limit

A booking SHALL NOT take more seats than are left for its tasting at the moment the booking is made. When the requested number of guests is greater than the seats left, the system SHALL reject the booking, show "Only <n> seats left for this tasting" next to the Guests field, and leave the seat count unchanged. Two bookings made at the same time SHALL NOT together exceed the seats of a tasting.

#### Scenario: Request exceeds seats left

- **GIVEN** 3 seats are left for Riesling Evening
- **WHEN** a guest books 4 guests
- **THEN** the message "Only 3 seats left for this tasting" appears next to the Guests field, no booking is created and the tasting still shows "3 seats left"

#### Scenario: Request fits the seats left

- **GIVEN** 3 seats are left for Riesling Evening
- **WHEN** a guest books 3 guests
- **THEN** the booking is created and the tasting shows "0 seats left"

#### Scenario: Concurrent bookings cannot oversell

- **GIVEN** 8 seats are left for Red Wine Cellar Tour
- **WHEN** two guests submit bookings for 5 guests each at the same time
- **THEN** exactly one booking is created, and the second receives "Only 3 seats left for this tasting"

### Requirement: Booking confirmation

After a successful booking the guest SHALL see a confirmation page with the heading "Booking confirmed", the tasting title, the number of guests, the total price (guests multiplied by the price per guest, shown as EUR) and the booking reference. The confirmation SHALL remain available at its own address for the booking reference, so that it survives a page reload. The confirmation SHALL NOT show the guest's email address.

#### Scenario: Successful booking shows confirmation

- **WHEN** a guest books 2 guests for Riesling Evening with a valid name and email
- **THEN** the page shows the heading "Booking confirmed", "Riesling Evening", "2 guests", "EUR 50" as the total, and a booking reference

#### Scenario: Confirmation survives reload

- **GIVEN** a guest has received the confirmation with reference "KB-ABC123"
- **WHEN** the guest reloads the confirmation page
- **THEN** the same confirmation is shown

#### Scenario: Unknown reference

- **WHEN** a guest opens the confirmation for a reference that does not exist or was cancelled
- **THEN** the page shows "Booking not found" and a link back to the tastings

### Requirement: Error and loading states

While a booking is being submitted the Book button SHALL be disabled and show that the request is in progress. If the booking cannot be completed because of a server or network error, the form SHALL show "Something went wrong. Please try again." and keep the guest's entered values.

#### Scenario: Server error keeps input

- **GIVEN** the server is unreachable
- **WHEN** a guest submits a valid booking
- **THEN** the message "Something went wrong. Please try again." is shown and the entered name, email and guests are still filled in

### Requirement: Usable on a phone

The start page, the booking form and the confirmation page SHALL be usable on a phone-sized screen of 360 px width: all content and controls are reachable without horizontal scrolling and text remains readable.

#### Scenario: Booking on a narrow screen

- **WHEN** a guest opens the booking form on a 360 px wide screen
- **THEN** all fields and the Book button are visible and usable without horizontal scrolling
