# Tasks

Order follows dependencies: each group leaves the app building and its tests passing. Tests for a behaviour are written before the code that implements it.

## 1. Project setup

- [x] 1.1 Add `package.json` with scripts `build`, `start`, `test`, `typecheck`, `lint`, plus TypeScript configs for client and server and a Vitest config; verify `npm install` succeeds and `npm run typecheck` passes on the empty source tree.
- [x] 1.2 Add `index.html`, the React entry point and a Tailwind v4 stylesheet with the winery theme tokens; verify `npm run build` writes `dist/client/index.html` and `dist/server/server/index.js`.
- [x] 1.3 Add an ESLint flat config for TypeScript and React hooks; verify `npm run lint` passes.

## 2. Shared tasting and validation rules

- [x] 2.1 Write failing tests, then add the tasting catalogue (three tastings with the title, start time, price and seats from the request) and a UTC-based date and time formatter; verify the tests in `src/shared` pass and cover the exact titles, dates and prices.
- [x] 2.2 Write failing tests, then add the booking input schema with the messages "Enter your name", "Enter a valid email address", "Enter between 1 and 8 guests", "Enter a whole number of guests", and the seats-left check "Only <n> seats left for this tasting"; verify each message from the `tasting-bookings` spec has a test and passes.

## 3. Booking store and guest API

- [x] 3.1 Write failing tests, then add the in-memory booking store: create with synchronous seat check and reference generation, get by reference, cancel, list grouped by tasting, seats left; verify tests cover the seat limit, exact fit, cancel freeing seats and unique references.
- [x] 3.2 Write failing Supertest tests, then add `GET /api/tastings`, `GET /api/tastings/:id`, `POST /api/tastings/:id/bookings` (201 with reference; 400 with field errors; 404 unknown tasting; 409 with seat or fully-booked messages) and `GET /api/bookings/:reference` (no name or email in the response); verify all status codes and response shapes are covered by passing tests.
- [x] 3.3 Write failing Supertest tests, then add the Express app with JSON parsing, `helmet` headers, static serving of `dist/client` and an `index.html` fallback for non-API GET requests, and `src/server/index.ts` listening on `PORT` (default 3000); verify the security header and fallback tests pass and `npm start` serves the built page.

## 4. Guest interface

- [x] 4.1 Write failing Testing Library tests, then add the app shell, React Router routes (`/`, `/tastings/:tastingId/book`, `/bookings/:reference`, `/staff`, not-found), the header with the winery name, and a typed API client; verify the shell renders and unknown routes show "Page not found".
- [x] 4.2 Write failing tests, then add the tastings list: each card shows title, date and time, price per guest, "<n> seats left" and a "Book <title>" link, with a "Fully booked" label when no seats remain; verify the list test covers the normal and fully-booked states.
- [x] 4.3 Write failing tests, then add the booking form with Name, Email, Guests and a Book button: field errors next to each field (React Hook Form with the shared schema), the seats-left error, disabled button while submitting, the fully-booked notice that disables the form, and the server error message that keeps entered values; verify each spec scenario in `tasting-bookings` has a passing test.
- [x] 4.4 Write failing tests, then add the confirmation page with the heading "Booking confirmed", tasting, guests, total in EUR and reference, plus "Booking not found" for unknown references; verify the tests cover both states and that no email address is rendered.

## 5. Staff API

- [x] 5.1 Write failing Supertest tests, then add `POST /api/staff/session` (timing-safe password check, session regeneration, 401 for wrong password, 503 when `STAFF_PASSWORD` is unset), `DELETE /api/staff/session`, and the `requireStaff` guard; verify the tests cover correct, wrong, unset and signed-out cases and that the cookie is `httpOnly` and `sameSite=strict`.
- [x] 5.2 Write failing Supertest tests, then add the sign-in throttle (10 failed attempts per 15 minutes per IP, successes not counted) returning 429 with the message from the spec; verify a correct password is refused after the limit is reached.
- [x] 5.3 Write failing Supertest tests, then add `GET /api/staff/bookings` (grouped by tasting, seats booked, bookings with name, email, guests, reference; 401 without session) and `DELETE /api/staff/bookings/:reference` (204, freed seats visible on the public tasting endpoint, 404 when already gone); verify the tests pass.

## 6. Staff interface

- [x] 6.1 Write failing Testing Library tests, then add the `/staff` sign-in page with a "Password" field, "Sign in" button, "Incorrect password" and "Staff sign-in is currently unavailable" messages; verify each message has a passing test.
- [x] 6.2 Write failing tests, then add the bookings overview grouped by tasting with "No bookings yet" for empty groups, a "Cancel" button per booking with a confirmation step, the "This booking no longer exists" message, and a "Sign out" button; verify the tests cover grouping, cancelling, declining the confirmation and signing out.

## 7. Visual design and phone layout

- [x] 7.1 Apply the winery design to all pages (header, cards, badges, success and error panels, focus styles, spacing scale), keeping the existing tests green; verify `npm test` still passes and the pages render at 360 px width without horizontal scrolling in a headless browser check.

## 8. Integration checks and documentation

- [x] 8.1 Write `README.md` with the environment variables (`STAFF_PASSWORD`, `PORT`), the commands and the in-memory persistence note; verify the documented commands run as written from a clean `npm install`.
- [x] 8.2 Add an end-to-end check that books a tasting, opens the confirmation, signs in as staff, cancels the booking and sees the seats freed on the start page; verify it passes against the built `npm start` server.
- [x] 8.3 Run the full `npm run typecheck`, `npm run lint`, `npm test` and `npm run build`, then `npm start` with a curl walk-through of every API route; verify all pass and record the results.
