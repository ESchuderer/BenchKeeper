import { defineConfig, devices } from '@playwright/test'

const PORT = Number(process.env.E2E_PORT ?? 3123)
const STAFF_PASSWORD = 'e2e-staff-password'

export default defineConfig({
  testDir: 'e2e',
  // Bookings live in memory in one server process, so the scenarios run in order against it.
  fullyParallel: false,
  workers: 1,
  reporter: 'list',
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: 'retain-on-failure',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    env: { PORT: String(PORT), STAFF_PASSWORD },
    reuseExistingServer: false,
    timeout: 20_000,
  },
})
