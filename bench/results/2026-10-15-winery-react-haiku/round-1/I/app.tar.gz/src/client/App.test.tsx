// @vitest-environment jsdom
import { screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { App } from './App.js'
import { mockApi, TASTING_LIST } from '../test/mock-api.js'
import { renderApp } from '../test/render.js'

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('application shell', () => {
  it('shows the winery name in the header on every page', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }))
    renderApp(<App />, '/')

    expect(screen.getByRole('banner')).toHaveTextContent('Weingut Kieselbrunnen')
    expect(await screen.findByRole('link', { name: 'Book Riesling Evening' })).toBeInTheDocument()
  })

  it('shows a page-not-found message with a way back for unknown addresses', () => {
    renderApp(<App />, '/no/such/page')

    expect(screen.getByRole('heading', { name: 'Page not found' })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Back to tastings' })).toHaveAttribute('href', '/')
  })
})
