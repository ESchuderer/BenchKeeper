import { Route, Routes } from 'react-router'
import { Layout } from './components/Layout.js'
import { BookingPage } from './pages/BookingPage.js'
import { ConfirmationPage } from './pages/ConfirmationPage.js'
import { NotFoundPage } from './pages/NotFoundPage.js'
import { StaffPage } from './pages/StaffPage.js'
import { TastingsPage } from './pages/TastingsPage.js'

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingsPage />} />
        <Route path="tastings/:tastingId/book" element={<BookingPage />} />
        <Route path="bookings/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  )
}
