// @vitest-environment jsdom
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { App } from './App.js'
import { mockApi, TASTING_LIST } from '../test/mock-api.js'
import { renderApp } from '../test/render.js'

const RIESLING = '/tastings/riesling-evening/book'

afterEach(() => {
  vi.unstubAllGlobals()
})

async function fillIn(user: ReturnType<typeof userEvent.setup>, { name, email, guests }: {
  name?: string
  email?: string
  guests?: string
}) {
  if (name !== undefined) await user.type(screen.getByLabelText('Name'), name)
  if (email !== undefined) await user.type(screen.getByLabelText('Email'), email)
  if (guests !== undefined) {
    const field = screen.getByLabelText('Guests')
    await user.clear(field)
    await user.type(field, guests)
  }
}

describe('booking form', () => {
  it('shows the tasting, its date, price and seats left above the form', async () => {
    mockApi((method, path) => {
      if (method === 'GET' && path === '/api/tastings/riesling-evening') {
        return { status: 200, body: { ...TASTING_LIST[0], seatsLeft: 12 } }
      }
      return { status: 404, body: { error: 'Not found' } }
    })
    renderApp(<App />, RIESLING)

    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument()
    expect(screen.getByText('Fri, 6 Nov 2026, 18:00', { exact: false })).toBeInTheDocument()
    expect(screen.getByText('EUR 25 per guest', { exact: false })).toBeInTheDocument()
    expect(screen.getByText('12 seats left')).toBeInTheDocument()
  })

  it('has Name, Email and Guests fields and a Book button', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST[0] }))
    renderApp(<App />, RIESLING)

    expect(await screen.findByLabelText('Name')).toBeInTheDocument()
    expect(screen.getByLabelText('Email')).toHaveAttribute('type', 'email')
    expect(screen.getByLabelText('Guests')).toHaveAttribute('type', 'number')
    expect(screen.getByLabelText('Guests')).toHaveAttribute('min', '1')
    expect(screen.getByLabelText('Guests')).toHaveAttribute('max', '8')
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument()
  })

  it('shows each missing or invalid field error next to its own field', async () => {
    const fetchMock = mockApi(() => ({ status: 200, body: TASTING_LIST[0] }))
    renderApp(<App />, RIESLING)
    const user = userEvent.setup()
    await screen.findByLabelText('Name')

    await fillIn(user, { email: 'anna@', guests: '0' })
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByLabelText('Name')).toHaveAccessibleDescription('Enter your name')
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Enter a valid email address')
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Enter between 1 and 8 guests')
    expect(screen.getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true')
    // Only the tasting itself was requested; no booking was sent.
    expect(fetchMock.mock.calls.map(([, init]) => init?.method ?? 'GET')).not.toContain('POST')
  })

  it('rejects a guest count above the seats left before sending anything', async () => {
    const fetchMock = mockApi(() => ({ status: 200, body: TASTING_LIST[2] }))
    renderApp(<App />, '/tastings/winter-tasting/book')
    const user = userEvent.setup()
    await screen.findByLabelText('Guests')

    await fillIn(user, { name: 'Anna Keller', email: 'anna@example.de', guests: '5' })
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(
      'Only 3 seats left for this tasting',
    )
    expect(fetchMock.mock.calls.map(([, init]) => init?.method ?? 'GET')).not.toContain('POST')
  })

  it('shows the seat message from the server next to Guests and keeps what the guest typed', async () => {
    mockApi((method) => {
      if (method === 'POST') {
        return { status: 409, body: { errors: { guests: 'Only 1 seat left for this tasting' } } }
      }
      return { status: 200, body: TASTING_LIST[0] }
    })
    renderApp(<App />, RIESLING)
    const user = userEvent.setup()
    await screen.findByLabelText('Name')

    await fillIn(user, { name: 'Anna Keller', email: 'anna@example.de', guests: '2' })
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(
      'Only 1 seat left for this tasting',
    )
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Keller')
    expect(screen.getByLabelText('Email')).toHaveValue('anna@example.de')
  })

  it('sends the booking, then shows the confirmation', async () => {
    const fetchMock = mockApi((method, path) => {
      if (method === 'POST') return { status: 201, body: { reference: 'KB-ABC123' } }
      if (path === '/api/bookings/KB-ABC123') {
        return {
          status: 200,
          body: {
            reference: 'KB-ABC123',
            tastingTitle: 'Riesling Evening',
            startsAt: '2026-11-06T18:00',
            guests: 2,
            totalEur: 50,
          },
        }
      }
      return { status: 200, body: TASTING_LIST[0] }
    })
    renderApp(<App />, RIESLING)
    const user = userEvent.setup()
    await screen.findByLabelText('Name')

    await fillIn(user, { name: 'Anna Keller', email: 'anna@example.de', guests: '2' })
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument()
    const post = fetchMock.mock.calls.find(([, init]) => init?.method === 'POST')
    expect(post?.[0]).toBe('/api/tastings/riesling-evening/bookings')
    expect(JSON.parse(post?.[1]?.body as string)).toEqual({
      name: 'Anna Keller',
      email: 'anna@example.de',
      guests: 2,
    })
  })

  it('disables the Book button and says so while the booking is sent', async () => {
    let finish: () => void = () => {}
    mockApi((method) => {
      if (method === 'POST') {
        return new Promise((resolve) => {
          finish = () => resolve({ status: 201, body: { reference: 'KB-ABC123' } })
        })
      }
      return { status: 200, body: TASTING_LIST[0] }
    })
    renderApp(<App />, RIESLING)
    const user = userEvent.setup()
    await screen.findByLabelText('Name')

    await fillIn(user, { name: 'Anna Keller', email: 'anna@example.de', guests: '2' })
    await user.click(screen.getByRole('button', { name: 'Book' }))

    const pending = await screen.findByRole('button', { name: 'Booking…' })
    expect(pending).toBeDisabled()
    finish()
    await waitFor(() => expect(screen.queryByRole('button', { name: 'Booking…' })).not.toBeInTheDocument())
  })

  it('keeps the entered values and shows a retry message when the server cannot be reached', async () => {
    mockApi((method) => {
      if (method === 'POST') return { status: 500, body: { error: 'Something went wrong' } }
      return { status: 200, body: TASTING_LIST[0] }
    })
    renderApp(<App />, RIESLING)
    const user = userEvent.setup()
    await screen.findByLabelText('Name')

    await fillIn(user, { name: 'Anna Keller', email: 'anna@example.de', guests: '2' })
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByRole('alert')).toHaveTextContent('Something went wrong. Please try again.')
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Keller')
    expect(screen.getByLabelText('Guests')).toHaveValue(2)
  })

  it('keeps the entered values and shows a retry message when the server is unreachable', async () => {
    mockApi((method) => {
      if (method === 'POST') throw new TypeError('Failed to fetch')
      return { status: 200, body: TASTING_LIST[0] }
    })
    renderApp(<App />, RIESLING)
    const user = userEvent.setup()
    await screen.findByLabelText('Name')

    await fillIn(user, { name: 'Anna Keller', email: 'anna@example.de', guests: '2' })
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByRole('alert')).toHaveTextContent('Something went wrong. Please try again.')
    expect(screen.getByLabelText('Email')).toHaveValue('anna@example.de')
  })

  it('states that a fully booked tasting cannot be booked and disables the form', async () => {
    mockApi(() => ({ status: 200, body: { ...TASTING_LIST[1], seatsLeft: 0 } }))
    renderApp(<App />, '/tastings/red-wine-cellar-tour/book')

    expect(await screen.findByText('This tasting is fully booked')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Book' })).toBeDisabled()
    expect(screen.getByLabelText('Name')).toBeDisabled()
  })

  it('shows a not-found message for an unknown tasting', async () => {
    mockApi(() => ({ status: 404, body: { error: 'Tasting not found' } }))
    renderApp(<App />, '/tastings/no-such-tasting/book')

    expect(await screen.findByRole('heading', { name: 'Tasting not found' })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Back to tastings' })).toHaveAttribute('href', '/')
  })
})
