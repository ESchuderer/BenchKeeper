// @vitest-environment jsdom
import { screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { App } from './App.js'
import { mockApi } from '../test/mock-api.js'
import { renderApp } from '../test/render.js'

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('booking confirmation', () => {
  it('shows the heading, tasting, number of guests, total price and reference', async () => {
    mockApi(() => ({
      status: 200,
      body: {
        reference: 'KB-ABC123',
        tastingTitle: 'Riesling Evening',
        startsAt: '2026-11-06T18:00',
        guests: 2,
        totalEur: 50,
        // Defensive: even if the API ever sent it, the page must not show the guest's email.
        email: 'anna@example.de',
      },
    }))
    renderApp(<App />, '/bookings/KB-ABC123')

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument()
    expect(screen.queryByText(/anna@example\.de/)).not.toBeInTheDocument()
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument()
    expect(screen.getByText('Fri, 6 Nov 2026, 18:00', { exact: false })).toBeInTheDocument()
    expect(screen.getByText('2 guests')).toBeInTheDocument()
    expect(screen.getByText('EUR 50')).toBeInTheDocument()
    expect(screen.getByText('KB-ABC123')).toBeInTheDocument()
  })

  it('uses the singular for a single guest', async () => {
    mockApi(() => ({
      status: 200,
      body: {
        reference: 'KB-ABC123',
        tastingTitle: 'Winter Tasting',
        startsAt: '2026-12-05T17:00',
        guests: 1,
        totalEur: 28,
      },
    }))
    renderApp(<App />, '/bookings/KB-ABC123')

    expect(await screen.findByText('1 guest')).toBeInTheDocument()
  })

  it('shows "Booking not found" for an unknown reference, with a link back to the tastings', async () => {
    mockApi(() => ({ status: 404, body: { error: 'Booking not found' } }))
    renderApp(<App />, '/bookings/KB-NOPE00')

    expect(await screen.findByRole('heading', { name: 'Booking not found' })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Back to tastings' })).toHaveAttribute('href', '/')
  })
})
