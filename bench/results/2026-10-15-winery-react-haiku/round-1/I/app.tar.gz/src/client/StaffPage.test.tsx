// @vitest-environment jsdom
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { App } from './App.js'
import { mockApi } from '../test/mock-api.js'
import { renderApp } from '../test/render.js'

afterEach(() => {
  vi.unstubAllGlobals()
  vi.restoreAllMocks()
})

interface FakeBooking {
  reference: string
  name: string
  email: string
  guests: number
}

/** A small stateful stand-in for the staff API. */
function fakeStaffApi(options: { signedIn?: boolean; password?: string; bookings?: FakeBooking[] } = {}) {
  const state = {
    signedIn: options.signedIn ?? false,
    bookings: options.bookings ?? [],
  }
  const password = options.password ?? 'correct-horse'
  const groups = () => [
    {
      tastingId: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      seats: 12,
      seatsBooked: state.bookings.reduce((sum, b) => sum + b.guests, 0),
      bookings: state.bookings,
    },
    {
      tastingId: 'red-wine-cellar-tour',
      title: 'Red Wine Cellar Tour',
      startsAt: '2026-11-14T15:00',
      seats: 8,
      seatsBooked: 0,
      bookings: [],
    },
  ]

  const fetchMock = mockApi((method, path, body) => {
    if (path === '/api/staff/session' && method === 'GET') return { status: 200, body: { signedIn: state.signedIn } }
    if (path === '/api/staff/session' && method === 'POST') {
      if ((body as { password?: string }).password !== password) {
        return { status: 401, body: { error: 'Incorrect password' } }
      }
      state.signedIn = true
      return { status: 204 }
    }
    if (path === '/api/staff/session' && method === 'DELETE') {
      state.signedIn = false
      return { status: 204 }
    }
    if (path === '/api/staff/bookings') {
      if (!state.signedIn) return { status: 401, body: { error: 'Sign in to see bookings' } }
      return { status: 200, body: groups() }
    }
    if (path.startsWith('/api/staff/bookings/') && method === 'DELETE') {
      const reference = path.split('/').pop()
      const before = state.bookings.length
      state.bookings = state.bookings.filter((booking) => booking.reference !== reference)
      return before === state.bookings.length
        ? { status: 404, body: { error: 'This booking no longer exists' } }
        : { status: 204 }
    }
    return { status: 404, body: { error: 'Not found' } }
  })
  return { fetchMock, state }
}

/** The Cancel button in the row for one booking. Its accessible description names the booking. */
async function cancelButtonFor(reference: string) {
  const row = await screen.findByRole('row', { name: new RegExp(reference) })
  return within(row).getByRole('button', { name: 'Cancel' })
}

const ANNA: FakeBooking = { reference: 'KB-ABC123', name: 'Anna Keller', email: 'anna@example.de', guests: 2 }

describe('staff sign-in', () => {
  it('asks for the password with a Password field and a Sign in button', async () => {
    fakeStaffApi()
    renderApp(<App />, '/staff')

    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password')
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument()
    expect(screen.queryByRole('heading', { name: 'Bookings' })).not.toBeInTheDocument()
  })

  it('shows the bookings overview after the correct password', async () => {
    fakeStaffApi()
    renderApp(<App />, '/staff')
    const user = userEvent.setup()

    await user.type(await screen.findByLabelText('Password'), 'correct-horse')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))

    expect(await screen.findByRole('heading', { name: 'Bookings' })).toBeInTheDocument()
  })

  it('shows "Incorrect password" next to the field and grants no access', async () => {
    fakeStaffApi()
    renderApp(<App />, '/staff')
    const user = userEvent.setup()

    await user.type(await screen.findByLabelText('Password'), 'wrong')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))

    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription('Incorrect password')
    expect(screen.queryByRole('heading', { name: 'Bookings' })).not.toBeInTheDocument()
  })

  it('asks for a password before sending an empty sign-in', async () => {
    const { fetchMock } = fakeStaffApi()
    renderApp(<App />, '/staff')
    const user = userEvent.setup()

    await user.click(await screen.findByRole('button', { name: 'Sign in' }))

    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription('Enter the password')
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'POST')).toBe(false)
  })

  it('says sign-in is unavailable when the password is not configured', async () => {
    mockApi((method, path) => {
      if (path === '/api/staff/session' && method === 'GET') return { status: 200, body: { signedIn: false } }
      return { status: 503, body: { error: 'Staff sign-in is currently unavailable' } }
    })
    renderApp(<App />, '/staff')
    const user = userEvent.setup()

    await user.type(await screen.findByLabelText('Password'), 'anything')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))

    expect(await screen.findByRole('alert')).toHaveTextContent('Staff sign-in is currently unavailable')
  })

  it('says so when too many sign-in attempts have been made', async () => {
    mockApi((method, path) => {
      if (path === '/api/staff/session' && method === 'GET') return { status: 200, body: { signedIn: false } }
      return { status: 429, body: { error: 'Too many sign-in attempts. Please try again later.' } }
    })
    renderApp(<App />, '/staff')
    const user = userEvent.setup()

    await user.type(await screen.findByLabelText('Password'), 'anything')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))

    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Too many sign-in attempts. Please try again later.',
    )
  })
})

describe('bookings overview', () => {
  it('groups bookings by tasting with name, email, guests and reference', async () => {
    fakeStaffApi({ signedIn: true, bookings: [ANNA] })
    renderApp(<App />, '/staff')

    const group = await screen.findByRole('region', { name: 'Riesling Evening' })
    const row = within(group).getByRole('row', { name: /Anna Keller/ })
    expect(within(row).getByText('anna@example.de')).toBeInTheDocument()
    expect(within(row).getByText('2')).toBeInTheDocument()
    expect(within(row).getByText('KB-ABC123')).toBeInTheDocument()
    expect(within(group).getByText(/2 of 12 seats booked/)).toBeInTheDocument()
  })

  it('shows "No bookings yet" for a tasting without bookings', async () => {
    fakeStaffApi({ signedIn: true })
    renderApp(<App />, '/staff')

    const group = await screen.findByRole('region', { name: 'Red Wine Cellar Tour' })
    expect(within(group).getByText('No bookings yet')).toBeInTheDocument()
  })

  it('cancels a booking after confirmation and removes it from the overview', async () => {
    const { fetchMock } = fakeStaffApi({ signedIn: true, bookings: [ANNA] })
    vi.spyOn(window, 'confirm').mockReturnValue(true)
    renderApp(<App />, '/staff')
    const user = userEvent.setup()

    await user.click(await cancelButtonFor('KB-ABC123'))

    await waitFor(() => expect(screen.queryByText('KB-ABC123')).not.toBeInTheDocument())
    expect(window.confirm).toHaveBeenCalled()
    expect(fetchMock.mock.calls.some(([path, init]) => path === '/api/staff/bookings/KB-ABC123' && init?.method === 'DELETE')).toBe(true)
  })

  it('keeps the booking when the cancellation is declined', async () => {
    const { fetchMock } = fakeStaffApi({ signedIn: true, bookings: [ANNA] })
    vi.spyOn(window, 'confirm').mockReturnValue(false)
    renderApp(<App />, '/staff')
    const user = userEvent.setup()

    const cancelButton = await cancelButtonFor('KB-ABC123')
    expect(cancelButton).toHaveAccessibleDescription('KB-ABC123')

    await user.click(cancelButton)

    expect(screen.getByText('KB-ABC123')).toBeInTheDocument()
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'DELETE')).toBe(false)
  })

  it('explains a booking that was already cancelled elsewhere, and refreshes the list', async () => {
    fakeStaffApi({ signedIn: true, bookings: [ANNA] })
    vi.spyOn(window, 'confirm').mockReturnValue(true)
    renderApp(<App />, '/staff')
    const user = userEvent.setup()
    const button = await cancelButtonFor('KB-ABC123')

    // Another browser session cancels the booking first; this page still shows it.
    await fetch('/api/staff/bookings/KB-ABC123', { method: 'DELETE' })
    await user.click(button)

    expect(await screen.findByRole('alert')).toHaveTextContent('This booking no longer exists')
    await waitFor(() => expect(screen.queryByText('KB-ABC123')).not.toBeInTheDocument())
  })

  it('signs out and returns to the sign-in page', async () => {
    fakeStaffApi({ signedIn: true, bookings: [ANNA] })
    renderApp(<App />, '/staff')
    const user = userEvent.setup()

    await user.click(await screen.findByRole('button', { name: 'Sign out' }))

    expect(await screen.findByLabelText('Password')).toBeInTheDocument()
    expect(screen.queryByText('KB-ABC123')).not.toBeInTheDocument()
  })

  it('returns to sign-in with a message when the session has ended', async () => {
    mockApi((_method, path) => {
      if (path === '/api/staff/session') return { status: 200, body: { signedIn: true } }
      if (path === '/api/staff/bookings') return { status: 401, body: { error: 'Sign in to see bookings' } }
      return { status: 404, body: {} }
    })
    renderApp(<App />, '/staff')

    expect(await screen.findByRole('alert')).toHaveTextContent('Your session has ended. Please sign in again.')
    expect(screen.getByLabelText('Password')).toBeInTheDocument()
  })
})
