// @vitest-environment jsdom
import { screen, within } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { App } from './App.js'
import { mockApi, TASTING_LIST } from '../test/mock-api.js'
import { renderApp } from '../test/render.js'

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('tastings list', () => {
  it('shows each tasting with date and time, price per guest and seats left', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }))
    renderApp(<App />, '/')

    const card = await screen.findByRole('article', { name: /Winter Tasting/ })
    expect(within(card).getByText('Sat, 5 Dec 2026, 17:00', { exact: false })).toBeInTheDocument()
    expect(within(card).getByText('EUR 28 per guest', { exact: false })).toBeInTheDocument()
    expect(within(card).getByText('3 seats left')).toBeInTheDocument()
  })

  it('lists the three tastings', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }))
    renderApp(<App />, '/')

    expect(await screen.findAllByRole('listitem')).toHaveLength(3)
  })

  it('gives each tasting a "Book <title>" link to its booking form', async () => {
    mockApi(() => ({ status: 200, body: TASTING_LIST }))
    renderApp(<App />, '/')

    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' })
    expect(link).toHaveAttribute('href', '/tastings/riesling-evening/book')
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveAttribute(
      'href',
      '/tastings/red-wine-cellar-tour/book',
    )
  })

  it('marks a fully booked tasting with "0 seats left" and a "Fully booked" label', async () => {
    const full = TASTING_LIST.map((tasting) =>
      tasting.id === 'red-wine-cellar-tour' ? { ...tasting, seatsLeft: 0 } : tasting,
    )
    mockApi(() => ({ status: 200, body: full }))
    renderApp(<App />, '/')

    const card = await screen.findByRole('article', { name: /Red Wine Cellar Tour/ })
    expect(within(card).getByText('0 seats left')).toBeInTheDocument()
    expect(within(card).getByText('Fully booked')).toBeInTheDocument()
  })

  it('shows a loading message while the tastings load', () => {
    mockApi(() => new Promise(() => {}))
    renderApp(<App />, '/')

    expect(screen.getByRole('status')).toHaveTextContent('Loading tastings')
  })

  it('shows an error message when the tastings cannot be loaded', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Failed to fetch')))
    renderApp(<App />, '/')

    expect(await screen.findByRole('alert')).toHaveTextContent('Something went wrong. Please try again.')
  })

})
