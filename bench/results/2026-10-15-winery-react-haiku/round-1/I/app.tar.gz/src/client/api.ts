import type { BookingInput } from '../shared/booking.js'

export interface TastingSummary {
  id: string
  title: string
  startsAt: string
  pricePerGuestEur: number
  seats: number
  seatsLeft: number
}

export interface BookingConfirmation {
  reference: string
  tastingTitle: string
  startsAt: string
  guests: number
  totalEur: number
}

export interface ApiErrorBody {
  error?: string
  errors?: Record<string, string>
}

/** A response the server answered with an error status. Network failures are not wrapped. */
export class ApiError extends Error {
  readonly status: number
  readonly body: ApiErrorBody

  constructor(status: number, body: ApiErrorBody) {
    super(body.error ?? `Request failed with status ${status}`)
    this.name = 'ApiError'
    this.status = status
    this.body = body
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: {
      Accept: 'application/json',
      ...(init.body ? { 'Content-Type': 'application/json' } : {}),
    },
  })
  if (response.status === 204) return undefined as T

  const body = await response.json().catch(() => ({}))
  if (!response.ok) throw new ApiError(response.status, body)
  return body as T
}

export const api = {
  listTastings: () => request<TastingSummary[]>('/api/tastings'),

  getTasting: (id: string) => request<TastingSummary>(`/api/tastings/${encodeURIComponent(id)}`),

  createBooking: (tastingId: string, input: BookingInput) =>
    request<{ reference: string }>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
      method: 'POST',
      body: JSON.stringify(input),
    }),

  getBooking: (reference: string) =>
    request<BookingConfirmation>(`/api/bookings/${encodeURIComponent(reference)}`),
}

export interface StaffBooking {
  reference: string
  name: string
  email: string
  guests: number
}

export interface StaffTastingGroup {
  tastingId: string
  title: string
  startsAt: string
  seats: number
  seatsBooked: number
  bookings: StaffBooking[]
}

export const staffApi = {
  session: () => request<{ signedIn: boolean }>('/api/staff/session'),

  signIn: (password: string) =>
    request<undefined>('/api/staff/session', { method: 'POST', body: JSON.stringify({ password }) }),

  signOut: () => request<undefined>('/api/staff/session', { method: 'DELETE' }),

  bookings: () => request<StaffTastingGroup[]>('/api/staff/bookings'),

  cancelBooking: (reference: string) =>
    request<undefined>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' }),
}
