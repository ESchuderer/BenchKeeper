import type { ComponentProps } from 'react'

type FormFieldProps = ComponentProps<'input'> & {
  id: string
  label: string
  error?: string
}

/** A labelled input whose error message is linked to it with aria-describedby. */
export function FormField({ id, label, error, ...inputProps }: FormFieldProps) {
  const errorId = `${id}-error`
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-semibold text-ink">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className="w-full rounded-card border border-gold bg-paper px-3.5 py-2.5 text-base text-ink placeholder:text-muted/70 aria-invalid:border-danger aria-invalid:bg-danger-soft disabled:cursor-not-allowed disabled:opacity-60"
        {...inputProps}
      />
      {error && (
        <p id={errorId} className="text-sm font-medium text-danger">
          {error}
        </p>
      )}
    </div>
  )
}
