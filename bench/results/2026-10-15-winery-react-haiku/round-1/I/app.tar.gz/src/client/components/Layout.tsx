import { Link, Outlet } from 'react-router'

export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b border-gold/60 bg-paper">
        <div className="mx-auto flex max-w-4xl flex-wrap items-baseline justify-between gap-x-6 gap-y-1 px-5 py-6">
          <Link to="/" className="font-serif text-2xl text-wine-dark no-underline">
            Weingut Kieselbrunnen
          </Link>
          <span className="text-sm uppercase tracking-[0.18em] text-muted">Wine tastings</span>
        </div>
      </header>

      <main className="mx-auto w-full max-w-4xl flex-1 px-5 py-10">
        <Outlet />
      </main>

      <footer className="border-t border-gold/60 bg-paper">
        <div className="mx-auto flex max-w-4xl flex-wrap justify-between gap-3 px-5 py-6 text-sm text-muted">
          <span>Weingut Kieselbrunnen · Family winery</span>
          <Link to="/staff" className="text-wine">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  )
}
