import type { ReactNode } from 'react'

type Tone = 'error' | 'success' | 'neutral'

const TONES: Record<Tone, string> = {
  error: 'border-danger bg-danger-soft text-danger',
  success: 'border-vine bg-vine-soft text-vine',
  neutral: 'border-gold bg-gold-soft text-ink',
}

/** A status panel. Errors use role="alert" so screen readers announce them at once. */
export function Notice({ tone = 'neutral', children }: { tone?: Tone; children: ReactNode }) {
  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={`rounded-card border-l-4 px-4 py-3 text-base ${TONES[tone]}`}
    >
      {children}
    </div>
  )
}
