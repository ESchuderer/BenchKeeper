import { formatStartsAt, seatsLeftLabel, type Tasting } from '../../shared/tastings.js'

type TastingDetailsProps = Pick<Tasting, 'startsAt' | 'pricePerGuestEur'> & { seatsLeft: number }

export function TastingDetails({ startsAt, pricePerGuestEur, seatsLeft }: TastingDetailsProps) {
  return (
    <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-2 text-base">
      <dt className="text-muted">Date and time</dt>
      <dd className="m-0 font-medium">{formatStartsAt(startsAt)}</dd>
      <dt className="text-muted">Price</dt>
      <dd className="m-0 font-medium">EUR {pricePerGuestEur} per guest</dd>
      <dt className="text-muted">Availability</dt>
      <dd className="m-0 font-medium">{seatsLeftLabel(seatsLeft)}</dd>
    </dl>
  )
}
