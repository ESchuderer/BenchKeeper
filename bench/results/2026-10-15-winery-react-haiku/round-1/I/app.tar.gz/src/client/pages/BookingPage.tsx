import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm, type Path } from 'react-hook-form'
import { Link, useNavigate, useParams } from 'react-router'
import { api, ApiError, type TastingSummary } from '../api.js'
import { FormField } from '../components/FormField.js'
import { Notice } from '../components/Notice.js'
import { TastingDetails } from '../components/TastingDetails.js'
import { createBookingSchema, type BookingInput } from '../../shared/booking.js'

const GENERIC_ERROR = 'Something went wrong. Please try again.'

export function BookingPage() {
  const { tastingId = '' } = useParams()
  const tasting = useQuery({
    queryKey: ['tasting', tastingId],
    queryFn: () => api.getTasting(tastingId),
  })

  if (tasting.isPending) return <Notice>Loading tasting…</Notice>

  if (tasting.isError) {
    if (tasting.error instanceof ApiError && tasting.error.status === 404) {
      return (
        <section>
          <h1 className="text-3xl">Tasting not found</h1>
          <p className="mt-4">
            <Link to="/">Back to tastings</Link>
          </p>
        </section>
      )
    }
    return <Notice tone="error">{GENERIC_ERROR}</Notice>
  }

  return <BookingForm tasting={tasting.data} />
}

function BookingForm({ tasting }: { tasting: TastingSummary }) {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const fullyBooked = tasting.seatsLeft === 0

  // Rebuilt on every render so the seat limit follows the latest seats-left count.
  const form = useForm<BookingInput>({
    resolver: zodResolver(createBookingSchema({ seatsLeft: tasting.seatsLeft })),
    defaultValues: { name: '', email: '', guests: 1 },
  })

  const booking = useMutation({
    mutationFn: (input: BookingInput) => api.createBooking(tasting.id, input),
    onSuccess: ({ reference }) => {
      void queryClient.invalidateQueries({ queryKey: ['tastings'] })
      navigate(`/bookings/${reference}`)
    },
    onError: (error) => {
      // The seat count may have changed since the page loaded; refresh it.
      if (error instanceof ApiError && error.status === 409) {
        void queryClient.invalidateQueries({ queryKey: ['tasting', tasting.id] })
      }
    },
  })

  const { errors } = form.formState
  const submitting = booking.isPending

  const onSubmit = form.handleSubmit(async (values) => {
    form.clearErrors('root')
    try {
      await booking.mutateAsync(values)
    } catch (error) {
      showServerError(error)
    }
  })

  function showServerError(error: unknown) {
    if (error instanceof ApiError && error.body.errors) {
      for (const [field, message] of Object.entries(error.body.errors)) {
        form.setError(field as Path<BookingInput>, { type: 'server', message })
      }
      return
    }
    // Only client errors carry a message fit for the guest; server errors get the generic text.
    const message =
      error instanceof ApiError && error.status < 500 && error.body.error ? error.body.error : GENERIC_ERROR
    form.setError('root', { type: 'server', message })
  }

  return (
    <>
      <section className="mb-8">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-muted">Book your places</p>
        <h1 className="mt-2 text-4xl">{tasting.title}</h1>
      </section>

      <div className="mb-8 max-w-md">
        <TastingDetails
          startsAt={tasting.startsAt}
          pricePerGuestEur={tasting.pricePerGuestEur}
          seatsLeft={tasting.seatsLeft}
        />
      </div>

      {fullyBooked && (
        <div className="mb-8 max-w-md">
          <Notice tone="error">This tasting is fully booked</Notice>
        </div>
      )}

      <form onSubmit={onSubmit} noValidate className="flex max-w-md flex-col gap-5" aria-labelledby="booking-heading">
        <h2 id="booking-heading" className="sr-only">
          Your booking
        </h2>
        <fieldset disabled={fullyBooked || submitting} className="flex flex-col gap-5 border-0 p-0">
          <FormField
            id="name"
            label="Name"
            autoComplete="name"
            error={errors.name?.message}
            {...form.register('name')}
          />
          <FormField
            id="email"
            label="Email"
            type="email"
            inputMode="email"
            autoComplete="email"
            error={errors.email?.message}
            {...form.register('email')}
          />
          <FormField
            id="guests"
            label="Guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={8}
            step={1}
            error={errors.guests?.message}
            {...form.register('guests', { valueAsNumber: true })}
          />

          {errors.root && !fullyBooked && <Notice tone="error">{errors.root.message}</Notice>}

          <button
            type="submit"
            disabled={fullyBooked || submitting}
            className="inline-flex min-h-12 items-center justify-center rounded-card bg-wine px-6 py-3 font-semibold text-paper hover:bg-wine-dark disabled:cursor-not-allowed disabled:opacity-60"
          >
            {submitting ? 'Booking…' : 'Book'}
          </button>
        </fieldset>
      </form>
    </>
  )
}
