import { useQuery } from '@tanstack/react-query'
import { Link, useParams } from 'react-router'
import { api, ApiError } from '../api.js'
import { Notice } from '../components/Notice.js'
import { formatStartsAt } from '../../shared/tastings.js'

export function ConfirmationPage() {
  const { reference = '' } = useParams()
  const booking = useQuery({
    queryKey: ['booking', reference],
    queryFn: () => api.getBooking(reference),
  })

  if (booking.isPending) return <Notice>Loading your booking…</Notice>

  if (booking.isError) {
    if (booking.error instanceof ApiError && booking.error.status === 404) {
      return (
        <section>
          <h1 className="text-3xl">Booking not found</h1>
          <p className="mt-4">
            <Link to="/">Back to tastings</Link>
          </p>
        </section>
      )
    }
    return <Notice tone="error">Something went wrong. Please try again.</Notice>
  }

  const { tastingTitle, startsAt, guests, totalEur } = booking.data
  return (
    <section className="max-w-xl">
      <p className="text-sm font-semibold uppercase tracking-[0.18em] text-vine">Thank you</p>
      <h1 className="mt-2 text-4xl">Booking confirmed</h1>

      <dl className="mt-8 grid grid-cols-[auto_1fr] gap-x-6 gap-y-3 rounded-card border border-gold/60 bg-paper p-6 text-base">
        <dt className="text-muted">Tasting</dt>
        <dd className="m-0 font-semibold">{tastingTitle}</dd>
        <dt className="text-muted">Date and time</dt>
        <dd className="m-0 font-medium">{formatStartsAt(startsAt)}</dd>
        <dt className="text-muted">Guests</dt>
        <dd className="m-0 font-medium">{guests === 1 ? '1 guest' : `${guests} guests`}</dd>
        <dt className="text-muted">Total</dt>
        <dd className="m-0 font-medium">EUR {totalEur}</dd>
        <dt className="text-muted">Booking reference</dt>
        <dd className="m-0 font-mono text-lg font-semibold tracking-wider">{reference}</dd>
      </dl>

      <p className="mt-6 text-muted">Please keep this reference. Show it when you arrive.</p>
      <p className="mt-6">
        <Link to="/">Back to tastings</Link>
      </p>
    </section>
  )
}
