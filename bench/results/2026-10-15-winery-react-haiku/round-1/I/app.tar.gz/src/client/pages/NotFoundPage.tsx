import { Link } from 'react-router'

export function NotFoundPage() {
  return (
    <section>
      <h1 className="text-3xl">Page not found</h1>
      <p className="mt-4">
        <Link to="/">Back to tastings</Link>
      </p>
    </section>
  )
}
