import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { ApiError, staffApi, type StaffTastingGroup } from '../api.js'
import { FormField } from '../components/FormField.js'
import { Notice } from '../components/Notice.js'
import { formatStartsAt } from '../../shared/tastings.js'

const GENERIC_ERROR = 'Something went wrong. Please try again.'

export function StaffPage() {
  const session = useQuery({ queryKey: ['staff', 'session'], queryFn: staffApi.session })

  if (session.isPending) return <Notice>Loading…</Notice>
  if (session.isError) return <Notice tone="error">{GENERIC_ERROR}</Notice>

  return session.data.signedIn ? <BookingsOverview /> : <SignInForm />
}

function SignInForm({ sessionEnded = false }: { sessionEnded?: boolean }) {
  const queryClient = useQueryClient()
  const form = useForm<{ password: string }>({ defaultValues: { password: '' } })
  const { errors } = form.formState

  const signIn = useMutation({
    mutationFn: (password: string) => staffApi.signIn(password),
    onSuccess: () => {
      // Refreshes the session and everything that depends on it.
      void queryClient.invalidateQueries({ queryKey: ['staff'] })
    },
  })

  const onSubmit = form.handleSubmit(async ({ password }) => {
    form.clearErrors('root')
    try {
      await signIn.mutateAsync(password)
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        form.setError('password', { type: 'server', message: 'Incorrect password' })
        form.setValue('password', '')
        return
      }
      const message = error instanceof ApiError && error.body.error ? error.body.error : GENERIC_ERROR
      form.setError('root', { type: 'server', message })
    }
  })

  return (
    <section className="max-w-sm">
      <h1 className="text-3xl">Staff sign-in</h1>
      {sessionEnded && (
        <div className="mt-6">
          <Notice tone="error">Your session has ended. Please sign in again.</Notice>
        </div>
      )}
      <form onSubmit={onSubmit} noValidate className="mt-8 flex flex-col gap-5">
        <FormField
          id="password"
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          {...form.register('password', { required: 'Enter the password' })}
        />
        {errors.root && <Notice tone="error">{errors.root.message}</Notice>}
        <button
          type="submit"
          disabled={signIn.isPending}
          className="inline-flex min-h-12 items-center justify-center rounded-card bg-wine px-6 py-3 font-semibold text-paper hover:bg-wine-dark disabled:cursor-not-allowed disabled:opacity-60"
        >
          Sign in
        </button>
      </form>
    </section>
  )
}

function BookingsOverview() {
  const queryClient = useQueryClient()

  const bookings = useQuery({
    queryKey: ['staff', 'bookings'],
    queryFn: staffApi.bookings,
    retry: false,
  })

  const signOut = useMutation({
    mutationFn: staffApi.signOut,
    onSuccess: () => {
      // Switch straight to sign-in. Refetching would race the bookings request into a "session ended" message.
      queryClient.setQueryData(['staff', 'session'], { signedIn: false })
    },
  })

  const cancel = useMutation({
    mutationFn: (reference: string) => staffApi.cancelBooking(reference),
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ['staff', 'bookings'] })
      void queryClient.invalidateQueries({ queryKey: ['tastings'] })
    },
  })

  if (bookings.isError && bookings.error instanceof ApiError && bookings.error.status === 401) {
    // The server no longer knows this session; show sign-in again rather than an error.
    return <SignInForm sessionEnded />
  }

  function confirmCancel(group: StaffTastingGroup, guest: string, reference: string) {
    if (window.confirm(`Cancel booking ${reference} for ${guest} (${group.title})?`)) {
      cancel.mutate(reference)
    }
  }

  const cancelMessage = cancel.isError
    ? cancel.error instanceof ApiError && cancel.error.status === 404
      ? 'This booking no longer exists'
      : GENERIC_ERROR
    : null

  return (
    <section>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-4xl">Bookings</h1>
        <button
          type="button"
          onClick={() => signOut.mutate()}
          className="rounded-card border border-wine px-4 py-2 font-semibold text-wine hover:bg-wine hover:text-paper"
        >
          Sign out
        </button>
      </div>

      {cancelMessage && (
        <div className="mb-6">
          <Notice tone="error">{cancelMessage}</Notice>
        </div>
      )}

      {bookings.isPending && <Notice>Loading bookings…</Notice>}
      {bookings.isError && <Notice tone="error">{GENERIC_ERROR}</Notice>}

      {bookings.data?.map((group) => (
        <section
          key={group.tastingId}
          aria-labelledby={`group-${group.tastingId}`}
          className="mb-10 border-t border-gold/60 pt-6"
        >
          <div className="mb-4 flex flex-wrap items-baseline justify-between gap-2">
            <h2 id={`group-${group.tastingId}`} className="text-2xl">
              {group.title}
            </h2>
            <p className="text-sm text-muted">
              {formatStartsAt(group.startsAt)} · {group.seatsBooked} of {group.seats} seats booked
            </p>
          </div>

          {group.bookings.length === 0 ? (
            <p className="text-muted">No bookings yet</p>
          ) : (
            // Stacks into labelled blocks on phones and becomes a table from md up.
            <table className="block w-full border-collapse text-left text-sm md:table">
              <thead className="sr-only md:not-sr-only md:table-header-group">
                <tr className="border-b border-gold text-muted">
                  <th scope="col" className="py-2 pr-4 font-semibold">Name</th>
                  <th scope="col" className="py-2 pr-4 font-semibold">Email</th>
                  <th scope="col" className="py-2 pr-4 font-semibold">Guests</th>
                  <th scope="col" className="py-2 pr-4 font-semibold">Reference</th>
                  <th scope="col" className="py-2 font-semibold">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody className="block md:table-row-group">
                {group.bookings.map((booking) => (
                  <tr key={booking.reference} className="block border-b border-gold/40 py-3 md:table-row md:py-0">
                    <td data-label="Name" className="flex justify-between gap-4 py-1 font-medium before:font-normal before:text-muted before:content-[attr(data-label)] md:table-cell md:py-3 md:pr-4 md:before:content-none">
                      {booking.name}
                    </td>
                    <td data-label="Email" className="flex justify-between gap-4 py-1 before:text-muted before:content-[attr(data-label)] md:table-cell md:py-3 md:pr-4 md:before:content-none">
                      <span className="break-all">{booking.email}</span>
                    </td>
                    <td data-label="Guests" className="flex justify-between gap-4 py-1 before:text-muted before:content-[attr(data-label)] md:table-cell md:py-3 md:pr-4 md:before:content-none">
                      {booking.guests}
                    </td>
                    <td id={`ref-${booking.reference}`} data-label="Reference" className="flex justify-between gap-4 py-1 font-mono before:font-sans before:text-muted before:content-[attr(data-label)] md:table-cell md:py-3 md:pr-4 md:before:content-none">
                      {booking.reference}
                    </td>
                    <td className="py-2 md:table-cell md:py-3">
                      <button
                        type="button"
                        onClick={() => confirmCancel(group, booking.name, booking.reference)}
                        disabled={cancel.isPending}
                        aria-describedby={`ref-${booking.reference}`}
                        className="w-full rounded-card border border-danger px-3 py-2 font-semibold text-danger hover:bg-danger hover:text-paper disabled:opacity-60 md:w-auto md:py-1.5"
                      >
                        Cancel
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      ))}
    </section>
  )
}
