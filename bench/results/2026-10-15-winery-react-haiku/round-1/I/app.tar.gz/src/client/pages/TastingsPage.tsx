import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router'
import { api } from '../api.js'
import { Notice } from '../components/Notice.js'
import { formatStartsAt, seatsLeftLabel } from '../../shared/tastings.js'

export function TastingsPage() {
  const tastings = useQuery({ queryKey: ['tastings'], queryFn: api.listTastings })

  return (
    <>
      <section className="mb-10 max-w-2xl">
        <h1 className="text-4xl">Book a tasting</h1>
        <p className="mt-3 text-base text-muted">
          Choose a tasting and reserve your places. Prices are per guest.
        </p>
      </section>

      {tastings.isPending && <Notice>Loading tastings…</Notice>}
      {tastings.isError && <Notice tone="error">Something went wrong. Please try again.</Notice>}

      {tastings.data && (
        <ul className="grid list-none gap-6 p-0 md:grid-cols-2">
          {tastings.data.map((tasting) => {
            const fullyBooked = tasting.seatsLeft === 0
            return (
              <li key={tasting.id}>
                <article
                  aria-labelledby={`tasting-${tasting.id}`}
                  className="flex h-full flex-col gap-5 rounded-card border border-gold/60 border-t-4 border-t-wine bg-paper p-6"
                >
                  <div className="flex items-start justify-between gap-3">
                    <h2 id={`tasting-${tasting.id}`} className="text-2xl">
                      {tasting.title}
                    </h2>
                    {fullyBooked && (
                      <span className="shrink-0 rounded-card bg-ink px-2.5 py-1 text-xs font-semibold uppercase tracking-wider text-paper">
                        Fully booked
                      </span>
                    )}
                  </div>

                  <dl className="grid grid-cols-[auto_1fr] gap-x-5 gap-y-2 text-base">
                    <dt className="text-muted">When</dt>
                    <dd className="m-0 font-medium">{formatStartsAt(tasting.startsAt)}</dd>
                    <dt className="text-muted">Price</dt>
                    <dd className="m-0 font-medium">EUR {tasting.pricePerGuestEur} per guest</dd>
                    <dt className="text-muted">Seats</dt>
                    <dd className={`m-0 font-medium ${fullyBooked ? 'text-danger' : ''}`}>
                      {seatsLeftLabel(tasting.seatsLeft)}
                    </dd>
                  </dl>

                  <Link
                    to={`/tastings/${tasting.id}/book`}
                    className="mt-auto inline-flex min-h-11 items-center justify-center rounded-card bg-wine px-5 py-3 text-center font-semibold text-paper no-underline hover:bg-wine-dark"
                  >
                    Book {tasting.title}
                  </Link>
                </article>
              </li>
            )
          })}
        </ul>
      )}
    </>
  )
}
