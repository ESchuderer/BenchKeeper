import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import request from 'supertest'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { createApp } from './app.js'
import { createBookingStore } from './booking-store.js'

let clientDir: string

beforeAll(() => {
  clientDir = mkdtempSync(join(tmpdir(), 'kieselbrunnen-client-'))
  mkdirSync(join(clientDir, 'assets'))
  writeFileSync(join(clientDir, 'index.html'), '<!doctype html><div id="root"></div>')
  writeFileSync(join(clientDir, 'assets', 'app.js'), 'console.log("app")')
})

afterAll(() => {
  rmSync(clientDir, { recursive: true, force: true })
})

function app() {
  return createApp({ store: createBookingStore(), clientDir })
}

describe('security headers', () => {
  it('sends a restrictive Content-Security-Policy and no framework banner', async () => {
    const response = await request(app()).get('/').expect(200)

    const policy = response.headers['content-security-policy']
    expect(policy).toContain("default-src 'self'")
    expect(policy).toMatch(/style-src 'self'(;|$)/)
    expect(policy).toMatch(/font-src 'self'(;|$)/)
    expect(response.headers['x-content-type-options']).toBe('nosniff')
    expect(response.headers['x-powered-by']).toBeUndefined()
  })
})

describe('serving the interface', () => {
  it('serves the built assets', async () => {
    const response = await request(app()).get('/assets/app.js').expect(200)
    expect(response.text).toContain('console.log')
  })

  it.each(['/', '/staff', '/tastings/winter-tasting/book', '/bookings/KB-ABC123'])(
    'serves the page shell for the client route %s',
    async (path) => {
      const response = await request(app()).get(path).expect(200)
      expect(response.text).toContain('<div id="root">')
    },
  )

  it('does not serve the page shell for an unknown API path', async () => {
    const response = await request(app()).get('/api/unknown').expect(404)
    expect(response.body).toEqual({ error: 'Not found' })
  })

  it('does not answer a POST to a page path with the page shell', async () => {
    await request(app()).post('/staff').expect(404)
  })
})
