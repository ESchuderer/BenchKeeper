import { join } from 'node:path'
import express, { type ErrorRequestHandler } from 'express'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import type { BookingStore } from './booking-store.js'
import { createStaffRouter } from './routes/staff.js'
import { createTastingsRouter } from './routes/tastings.js'

export interface AppOptions {
  store: BookingStore
  /**
   * Number of reverse proxies in front of the app, as for Express's `trust proxy`.
   * Set it when TLS is terminated by a proxy, so the secure cookie and the per-client limits see the real client.
   */
  trustProxy?: number
  /** Shared password for staff sign-in. Staff sign-in is refused when unset. */
  staffPassword?: string
  /** Directory with the built interface. When omitted, only the API is served. */
  clientDir?: string
}

export function createApp({ store, staffPassword, trustProxy, clientDir }: AppOptions): express.Express {
  const app = express()
  if (trustProxy !== undefined) app.set('trust proxy', trustProxy)

  app.use(
    helmet({
      contentSecurityPolicy: {
        // Only the stylesheet and fonts are served by this app, so no other origin is needed.
        directives: { 'style-src': ["'self'"], 'font-src': ["'self'"] },
      },
    }),
  )
  app.use(express.json({ limit: '10kb' }))

  // A general ceiling for the API; booking creation has a tighter limit of its own.
  app.use(
    '/api',
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: 300,
      standardHeaders: 'draft-7',
      legacyHeaders: false,
      handler: (_req, res) => {
        res.status(429).json({ error: 'Too many requests. Please try again later.' })
      },
    }),
  )
  app.use('/api', createTastingsRouter(store))
  app.use('/api/staff', createStaffRouter({ store, staffPassword }))
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found' })
  })

  if (clientDir) {
    app.use(express.static(clientDir))
    // Client-side routes such as /staff and /bookings/:reference are answered with the app shell.
    app.use((req, res, next) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        next()
        return
      }
      res.sendFile(join(clientDir, 'index.html'), (error) => {
        if (error) next(error)
      })
    })
  }

  // Malformed JSON and oversized bodies are client errors; never leak internal details.
  const errorHandler: ErrorRequestHandler = (error, _req, res, next) => {
    const status = typeof error?.status === 'number' ? error.status : 500
    if (res.headersSent) {
      next(error)
      return
    }
    if (status >= 400 && status < 500) {
      res.status(status).json({ error: 'Invalid request' })
      return
    }
    console.error(error)
    res.status(500).json({ error: 'Something went wrong' })
  }
  app.use(errorHandler)

  return app
}
