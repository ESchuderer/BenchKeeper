import { describe, expect, it } from 'vitest'
import { createBookingStore } from './booking-store.js'
import type { Tasting } from '../shared/tastings.js'

const TWO_SEATS: Tasting = {
  id: 'small-tasting',
  title: 'Small Tasting',
  startsAt: '2026-11-06T18:00',
  pricePerGuestEur: 25,
  seats: 4,
}

const BOOKING = { name: 'Anna Keller', email: 'anna@example.de' }

describe('booking store', () => {
  it('reports every seat of a tasting as left before any booking', () => {
    const store = createBookingStore({ tastings: [TWO_SEATS] })
    expect(store.seatsLeft('small-tasting')).toBe(4)
  })

  it('stores a booking, returns its reference and reduces the seats left', () => {
    const store = createBookingStore({ tastings: [TWO_SEATS] })

    const result = store.create('small-tasting', { ...BOOKING, guests: 3 })

    expect(result.status).toBe('created')
    if (result.status !== 'created') throw new Error('expected a booking')
    expect(result.booking).toMatchObject({ tastingId: 'small-tasting', guests: 3, ...BOOKING })
    expect(store.seatsLeft('small-tasting')).toBe(1)
    expect(store.findByReference(result.booking.reference)).toEqual(result.booking)
  })

  it('accepts a booking that takes exactly the seats left and then has none left', () => {
    const store = createBookingStore({ tastings: [TWO_SEATS] })

    expect(store.create('small-tasting', { ...BOOKING, guests: 4 }).status).toBe('created')
    expect(store.seatsLeft('small-tasting')).toBe(0)
  })

  it('rejects a booking larger than the seats left and changes nothing', () => {
    const store = createBookingStore({ tastings: [TWO_SEATS] })
    store.create('small-tasting', { ...BOOKING, guests: 2 })

    const result = store.create('small-tasting', { ...BOOKING, guests: 3 })

    expect(result).toEqual({ status: 'not-enough-seats', seatsLeft: 2 })
    expect(store.seatsLeft('small-tasting')).toBe(2)
    expect(store.bookingsFor('small-tasting')).toHaveLength(1)
  })

  it('reports an unknown tasting without storing anything', () => {
    const store = createBookingStore({ tastings: [TWO_SEATS] })
    expect(store.create('no-such-tasting', { ...BOOKING, guests: 1 })).toEqual({
      status: 'unknown-tasting',
    })
  })

  it('frees the seats of a cancelled booking', () => {
    const store = createBookingStore({ tastings: [TWO_SEATS] })
    const { booking } = store.create('small-tasting', { ...BOOKING, guests: 4 }) as {
      booking: { reference: string }
    }

    expect(store.cancel(booking.reference)).toBe(true)

    expect(store.seatsLeft('small-tasting')).toBe(4)
    expect(store.findByReference(booking.reference)).toBeUndefined()
  })

  it('returns false when cancelling a reference that does not exist', () => {
    const store = createBookingStore({ tastings: [TWO_SEATS] })
    expect(store.cancel('KB-NOPE00')).toBe(false)
  })

  it('gives every booking a distinct reference in the form KB-XXXXXX without look-alike characters', () => {
    const big: Tasting = { ...TWO_SEATS, id: 'big', seats: 1000 }
    const store = createBookingStore({ tastings: [big] })

    const references = Array.from({ length: 500 }, () => {
      const result = store.create('big', { ...BOOKING, guests: 1 })
      if (result.status !== 'created') throw new Error('expected a booking')
      return result.booking.reference
    })

    expect(new Set(references).size).toBe(500)
    for (const reference of references) {
      expect(reference).toMatch(/^KB-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}$/)
    }
  })

  it('lists the bookings of one tasting in the order they were made', () => {
    const store = createBookingStore({ tastings: [TWO_SEATS] })
    store.create('small-tasting', { name: 'First Guest', email: 'first@example.de', guests: 1 })
    store.create('small-tasting', { name: 'Second Guest', email: 'second@example.de', guests: 2 })

    expect(store.bookingsFor('small-tasting').map((booking) => booking.name)).toEqual([
      'First Guest',
      'Second Guest',
    ])
    expect(store.bookingsFor('no-such-tasting')).toEqual([])
  })
})
