import { randomInt } from 'node:crypto'
import { TASTINGS, type Tasting } from '../shared/tastings.js'
import type { BookingInput } from '../shared/booking.js'

export interface Booking {
  reference: string
  tastingId: string
  name: string
  email: string
  guests: number
  createdAt: Date
}

export type CreateBookingResult =
  | { status: 'created'; booking: Booking }
  | { status: 'unknown-tasting' }
  | { status: 'not-enough-seats'; seatsLeft: number }

export interface BookingStore {
  /** The tastings this store takes bookings for. */
  readonly tastings: readonly Tasting[]
  findTasting(tastingId: string): Tasting | undefined
  seatsLeft(tastingId: string): number
  create(tastingId: string, input: BookingInput): CreateBookingResult
  findByReference(reference: string): Booking | undefined
  cancel(reference: string): boolean
  bookingsFor(tastingId: string): Booking[]
}

// Upper-case letters and digits without look-alikes (no 0/O, 1/I/L), so references can be read aloud.
const REFERENCE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'
const REFERENCE_LENGTH = 6

/**
 * In-memory booking store. `create` checks the seats and records the booking in one
 * synchronous block with no `await`, so two requests can never both take the last seat.
 * This holds for a single process; a store shared across processes would need a transaction.
 */
export function createBookingStore({ tastings = TASTINGS }: { tastings?: readonly Tasting[] } = {}): BookingStore {
  const catalogue = new Map(tastings.map((tasting) => [tasting.id, tasting]))
  const bookings = new Map<string, Booking>()

  function bookedSeats(tastingId: string): number {
    let total = 0
    for (const booking of bookings.values()) {
      if (booking.tastingId === tastingId) total += booking.guests
    }
    return total
  }

  function seatsLeft(tastingId: string): number {
    const tasting = catalogue.get(tastingId)
    return tasting ? tasting.seats - bookedSeats(tastingId) : 0
  }

  function newReference(): string {
    let reference: string
    do {
      const letters = Array.from({ length: REFERENCE_LENGTH }, () =>
        REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)],
      )
      reference = `KB-${letters.join('')}`
    } while (bookings.has(reference))
    return reference
  }

  return {
    tastings,

    findTasting(tastingId) {
      return catalogue.get(tastingId)
    },

    seatsLeft,

    create(tastingId, input) {
      if (!catalogue.has(tastingId)) return { status: 'unknown-tasting' }

      const left = seatsLeft(tastingId)
      if (input.guests > left) return { status: 'not-enough-seats', seatsLeft: left }

      const booking: Booking = {
        reference: newReference(),
        tastingId,
        name: input.name,
        email: input.email,
        guests: input.guests,
        createdAt: new Date(),
      }
      bookings.set(booking.reference, booking)
      return { status: 'created', booking }
    },

    findByReference(reference) {
      return bookings.get(reference)
    },

    cancel(reference) {
      return bookings.delete(reference)
    },

    bookingsFor(tastingId) {
      return [...bookings.values()].filter((booking) => booking.tastingId === tastingId)
    },
  }
}
