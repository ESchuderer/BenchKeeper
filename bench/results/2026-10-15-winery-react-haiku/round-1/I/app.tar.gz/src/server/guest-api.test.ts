import request from 'supertest'
import { describe, expect, it } from 'vitest'
import { createApp } from './app.js'
import { createBookingStore } from './booking-store.js'
import { TASTINGS, type Tasting } from '../shared/tastings.js'

function setup(tastings: readonly Tasting[] = TASTINGS) {
  const store = createBookingStore({ tastings })
  const app = createApp({ store })
  return { app, store }
}

const VALID_BOOKING = { name: 'Anna Keller', email: 'anna@example.de', guests: 2 }

describe('GET /api/tastings', () => {
  it('lists the three tastings with their seats left', async () => {
    const { app } = setup()

    const response = await request(app).get('/api/tastings').expect(200)

    expect(response.body).toEqual([
      {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        startsAt: '2026-11-06T18:00',
        pricePerGuestEur: 25,
        seats: 12,
        seatsLeft: 12,
      },
      {
        id: 'red-wine-cellar-tour',
        title: 'Red Wine Cellar Tour',
        startsAt: '2026-11-14T15:00',
        pricePerGuestEur: 32,
        seats: 8,
        seatsLeft: 8,
      },
      {
        id: 'winter-tasting',
        title: 'Winter Tasting',
        startsAt: '2026-12-05T17:00',
        pricePerGuestEur: 28,
        seats: 10,
        seatsLeft: 10,
      },
    ])
  })

  it('reports fewer seats left after a booking', async () => {
    const { app } = setup()
    await request(app).post('/api/tastings/riesling-evening/bookings').send(VALID_BOOKING).expect(201)

    const response = await request(app).get('/api/tastings').expect(200)

    expect(response.body[0].seatsLeft).toBe(10)
  })
})

describe('GET /api/tastings/:id', () => {
  it('returns one tasting', async () => {
    const { app } = setup()
    const response = await request(app).get('/api/tastings/winter-tasting').expect(200)
    expect(response.body).toMatchObject({ id: 'winter-tasting', title: 'Winter Tasting', seatsLeft: 10 })
  })

  it('returns 404 for an unknown tasting', async () => {
    const { app } = setup()
    const response = await request(app).get('/api/tastings/no-such-tasting').expect(404)
    expect(response.body).toEqual({ error: 'Tasting not found' })
  })
})

describe('POST /api/tastings/:id/bookings', () => {
  it('creates the booking and returns its reference', async () => {
    const { app, store } = setup()

    const response = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send(VALID_BOOKING)
      .expect(201)

    expect(response.body.reference).toMatch(/^KB-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}$/)
    expect(store.seatsLeft('riesling-evening')).toBe(10)
  })

  it('returns field errors and stores nothing when the input is invalid', async () => {
    const { app, store } = setup()

    const response = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: '', email: 'anna@', guests: 9 })
      .expect(400)

    expect(response.body).toEqual({
      errors: {
        name: 'Enter your name',
        email: 'Enter a valid email address',
        guests: 'Enter between 1 and 8 guests',
      },
    })
    expect(store.seatsLeft('riesling-evening')).toBe(12)
  })

  it('rejects more guests than seats left with the seat message on the guests field', async () => {
    const { app, store } = setup()
    store.create('riesling-evening', { name: 'Earlier Guest', email: 'earlier@example.de', guests: 10 })

    const response = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...VALID_BOOKING, guests: 3 })
      .expect(409)

    expect(response.body).toEqual({ errors: { guests: 'Only 2 seats left for this tasting' } })
    expect(store.seatsLeft('riesling-evening')).toBe(2)
  })

  it('reports a fully booked tasting', async () => {
    const { app, store } = setup()
    store.create('red-wine-cellar-tour', { name: 'Earlier Guest', email: 'earlier@example.de', guests: 8 })

    const response = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send(VALID_BOOKING)
      .expect(409)

    expect(response.body).toEqual({ error: 'This tasting is fully booked' })
  })

  it('never lets simultaneous bookings take more seats than the tasting has', async () => {
    const { app, store } = setup()
    store.create('red-wine-cellar-tour', { name: 'Earlier Guest', email: 'earlier@example.de', guests: 3 })

    // Five seats are left; two requests for three guests race each other.
    const responses = await Promise.all([
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...VALID_BOOKING, guests: 3 }),
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...VALID_BOOKING, guests: 3 }),
    ])

    expect(responses.map((response) => response.status).sort()).toEqual([201, 409])
    expect(store.seatsLeft('red-wine-cellar-tour')).toBe(2)
  })

  it('returns 404 for an unknown tasting', async () => {
    const { app } = setup()
    await request(app).post('/api/tastings/no-such-tasting/bookings').send(VALID_BOOKING).expect(404)
  })

  it('returns a JSON error for a body that is not valid JSON', async () => {
    const { app } = setup()

    const response = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ')
      .expect(400)

    expect(response.body).toEqual({ error: 'Invalid request' })
  })
})

describe('GET /api/bookings/:reference', () => {
  it('returns the booking details without the guest name or email', async () => {
    const { app } = setup()
    const created = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send(VALID_BOOKING)
      .expect(201)

    const response = await request(app).get(`/api/bookings/${created.body.reference}`).expect(200)

    expect(response.body).toEqual({
      reference: created.body.reference,
      tastingTitle: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      guests: 2,
      totalEur: 50,
    })
    expect(JSON.stringify(response.body)).not.toContain('anna@example.de')
  })

  it('returns 404 for a reference that does not exist', async () => {
    const { app } = setup()
    const response = await request(app).get('/api/bookings/KB-NOPE00').expect(404)
    expect(response.body).toEqual({ error: 'Booking not found' })
  })
})

describe('booking attempts per client', () => {
  it('refuses booking requests beyond 20 in 15 minutes from one client', async () => {
    const { app } = setup()
    for (let attempt = 0; attempt < 20; attempt++) {
      await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...VALID_BOOKING, guests: 1 })
    }

    const response = await request(app).post('/api/tastings/winter-tasting/bookings').send(VALID_BOOKING).expect(429)

    expect(response.body).toEqual({ error: 'Too many booking attempts. Please try again later.' })
  })
})

describe('unknown API routes', () => {
  it('answers with JSON 404 rather than the page', async () => {
    const { app } = setup()
    const response = await request(app).get('/api/no-such-route').expect(404)
    expect(response.body).toEqual({ error: 'Not found' })
  })
})
