import { fileURLToPath } from 'node:url'
import { createApp } from './app.js'
import { createBookingStore } from './booking-store.js'

const port = Number(process.env.PORT ?? 3000)
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error(`PORT must be a port number, got "${process.env.PORT}"`)
}

const trustProxy = process.env.TRUST_PROXY === undefined ? undefined : Number(process.env.TRUST_PROXY)
if (trustProxy !== undefined && (!Number.isInteger(trustProxy) || trustProxy < 0)) {
  throw new Error(`TRUST_PROXY must be the number of proxies in front of the app, got "${process.env.TRUST_PROXY}"`)
}

const staffPassword = process.env.STAFF_PASSWORD
if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled until it is set.')
}

// Compiled to dist/server/server/index.js; the built interface is in dist/client.
const clientDir = fileURLToPath(new URL('../../client', import.meta.url))

const app = createApp({ store: createBookingStore(), staffPassword, trustProxy, clientDir })

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on port ${port}`)
})
