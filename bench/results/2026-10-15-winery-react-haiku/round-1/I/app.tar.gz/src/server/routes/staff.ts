import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'
import { Router, type Request, type RequestHandler } from 'express'
import session from 'express-session'
import rateLimit from 'express-rate-limit'
import type { BookingStore } from '../booking-store.js'

declare module 'express-session' {
  interface SessionData {
    staff?: boolean
  }
}

const SIGN_IN_WINDOW_MS = 15 * 60 * 1000
const MAX_FAILED_SIGN_INS = 10
const SESSION_MAX_AGE_MS = 8 * 60 * 60 * 1000

export interface StaffOptions {
  store: BookingStore
  /** The shared staff password. When unset or empty, staff sign-in is refused. */
  staffPassword?: string
}

export function createStaffRouter({ store, staffPassword }: StaffOptions): Router {
  const router = Router()

  // Staff responses hold guests' names and emails; never keep them in a browser or proxy cache.
  router.use((_req, res, next) => {
    res.set('Cache-Control', 'no-store')
    next()
  })

  router.use(
    session({
      // A fresh random secret per start: restarting the server signs staff out.
      secret: randomBytes(32).toString('hex'),
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: 'strict',
        secure: 'auto',
        maxAge: SESSION_MAX_AGE_MS,
      },
    }),
  )

  const signInLimiter = rateLimit({
    windowMs: SIGN_IN_WINDOW_MS,
    limit: MAX_FAILED_SIGN_INS,
    // Only failed attempts count, so a correct password is never blocked by earlier successes.
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => {
      res.status(429).json({ error: 'Too many sign-in attempts. Please try again later.' })
    },
  })

  const requireStaff: RequestHandler = (req, res, next) => {
    if (req.session.staff === true) {
      next()
      return
    }
    res.status(401).json({ error: 'Sign in to see bookings' })
  }

  router.get('/session', (req, res) => {
    res.json({ signedIn: req.session.staff === true })
  })

  router.post('/session', signInLimiter, async (req, res, next) => {
    try {
      if (!staffPassword) {
        res.status(503).json({ error: 'Staff sign-in is currently unavailable' })
        return
      }
      const candidate = typeof req.body?.password === 'string' ? req.body.password : ''
      if (!passwordMatches(candidate, staffPassword)) {
        res.status(401).json({ error: 'Incorrect password' })
        return
      }
      // A new session ID on sign-in prevents session fixation.
      await regenerateSession(req)
      req.session.staff = true
      await saveSession(req)
      res.status(204).end()
    } catch (error) {
      next(error)
    }
  })

  router.delete('/session', async (req, res, next) => {
    try {
      await destroySession(req)
      res.status(204).end()
    } catch (error) {
      next(error)
    }
  })

  router.get('/bookings', requireStaff, (_req, res) => {
    res.json(
      store.tastings.map((tasting) => ({
        tastingId: tasting.id,
        title: tasting.title,
        startsAt: tasting.startsAt,
        seats: tasting.seats,
        seatsBooked: tasting.seats - store.seatsLeft(tasting.id),
        bookings: store.bookingsFor(tasting.id).map((booking) => ({
          reference: booking.reference,
          name: booking.name,
          email: booking.email,
          guests: booking.guests,
        })),
      })),
    )
  })

  router.delete('/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(String(req.params.reference))) {
      res.status(404).json({ error: 'This booking no longer exists' })
      return
    }
    res.status(204).end()
  })

  return router
}

/** Compares digests so the comparison takes the same time whatever the guess. */
function passwordMatches(candidate: string, expected: string): boolean {
  const candidateDigest = createHash('sha256').update(candidate).digest()
  const expectedDigest = createHash('sha256').update(expected).digest()
  return timingSafeEqual(candidateDigest, expectedDigest)
}

function regenerateSession(req: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    req.session.regenerate((error) => (error ? reject(error) : resolve()))
  })
}

function saveSession(req: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    req.session.save((error) => (error ? reject(error) : resolve()))
  })
}

function destroySession(req: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    req.session.destroy((error) => (error ? reject(error) : resolve()))
  })
}
