import { Router } from 'express'
import rateLimit from 'express-rate-limit'
import { createBookingSchema, MESSAGES } from '../../shared/booking.js'
import type { BookingStore } from '../booking-store.js'
import { fieldErrors } from '../http.js'

const BOOKING_WINDOW_MS = 15 * 60 * 1000
// Generous for a family booking, but stops one client from taking every seat.
const MAX_BOOKING_REQUESTS_PER_WINDOW = 20

export function createTastingsRouter(store: BookingStore): Router {
  const router = Router()

  const bookingLimiter = rateLimit({
    windowMs: BOOKING_WINDOW_MS,
    limit: MAX_BOOKING_REQUESTS_PER_WINDOW,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => {
      res.status(429).json({ error: 'Too many booking attempts. Please try again later.' })
    },
  })

  router.get('/tastings', (_req, res) => {
    res.json(store.tastings.map((tasting) => ({ ...tasting, seatsLeft: store.seatsLeft(tasting.id) })))
  })

  router.get('/tastings/:id', (req, res) => {
    const tasting = store.findTasting(req.params.id)
    if (!tasting) {
      res.status(404).json({ error: 'Tasting not found' })
      return
    }
    res.json({ ...tasting, seatsLeft: store.seatsLeft(tasting.id) })
  })

  router.post('/tastings/:id/bookings', bookingLimiter, (req, res) => {
    const tasting = store.findTasting(String(req.params.id))
    if (!tasting) {
      res.status(404).json({ error: 'Tasting not found' })
      return
    }

    const input = createBookingSchema().safeParse(req.body)
    if (!input.success) {
      res.status(400).json({ errors: fieldErrors(input.error) })
      return
    }

    const result = store.create(tasting.id, input.data)
    switch (result.status) {
      case 'created':
        res.status(201).json({ reference: result.booking.reference })
        return
      case 'unknown-tasting':
        res.status(404).json({ error: 'Tasting not found' })
        return
      case 'not-enough-seats':
        if (result.seatsLeft === 0) {
          res.status(409).json({ error: MESSAGES.fullyBooked })
        } else {
          res.status(409).json({ errors: { guests: MESSAGES.seatsLeft(result.seatsLeft) } })
        }
    }
  })

  router.get('/bookings/:reference', (req, res) => {
    const booking = store.findByReference(req.params.reference)
    const tasting = booking && store.findTasting(booking.tastingId)
    if (!booking || !tasting) {
      res.status(404).json({ error: 'Booking not found' })
      return
    }
    res.json({
      reference: booking.reference,
      tastingTitle: tasting.title,
      startsAt: tasting.startsAt,
      guests: booking.guests,
      totalEur: booking.guests * tasting.pricePerGuestEur,
    })
  })

  return router
}
