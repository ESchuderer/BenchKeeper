import request from 'supertest'
import { describe, expect, it } from 'vitest'
import { createApp } from './app.js'
import { createBookingStore } from './booking-store.js'

const PASSWORD = 'correct-horse-battery'

function setup(options: { staffPassword?: string } = {}) {
  // An explicit undefined means "not configured", so only fall back when the key is absent.
  const staffPassword = 'staffPassword' in options ? options.staffPassword : PASSWORD
  const store = createBookingStore()
  const app = createApp({ store, staffPassword })
  return { app, store }
}

/** Signs in with an agent that keeps the session cookie between requests. */
async function signedInAgent(app: ReturnType<typeof createApp>) {
  const agent = request.agent(app)
  await agent.post('/api/staff/session').send({ password: PASSWORD }).expect(204)
  return agent
}

describe('staff responses', () => {
  it('are never cached, because they include guests\' personal details', async () => {
    const { app } = setup()
    const agent = await signedInAgent(app)

    const response = await agent.get('/api/staff/bookings').expect(200)

    expect(response.headers['cache-control']).toBe('no-store')
  })
})

describe('POST /api/staff/session', () => {
  it('marks the session cookie Secure when a TLS proxy reports HTTPS', async () => {
    const store = createBookingStore()
    const app = createApp({ store, staffPassword: PASSWORD, trustProxy: 1 })

    const response = await request(app)
      .post('/api/staff/session')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD })
      .expect(204)

    expect(response.headers['set-cookie']?.[0]).toMatch(/;\s*Secure/i)
  })

  it('starts a session for the correct password and sets an httpOnly, same-site cookie', async () => {
    const { app } = setup()

    const response = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(204)

    const cookie = response.headers['set-cookie']?.[0] ?? ''
    expect(cookie).toMatch(/HttpOnly/i)
    expect(cookie).toMatch(/SameSite=Strict/i)
  })

  it('refuses a wrong password without starting a session', async () => {
    const { app } = setup()

    const response = await request(app).post('/api/staff/session').send({ password: 'guess' }).expect(401)

    expect(response.body).toEqual({ error: 'Incorrect password' })
    expect(response.headers['set-cookie']).toBeUndefined()
  })

  it('refuses a request with no password', async () => {
    const { app } = setup()
    await request(app).post('/api/staff/session').send({}).expect(401)
  })

  it('refuses all sign-in when STAFF_PASSWORD is not configured, even for a guessed password', async () => {
    const { app } = setup({ staffPassword: undefined })

    const response = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(503)

    expect(response.body).toEqual({ error: 'Staff sign-in is currently unavailable' })
  })

  it('refuses all sign-in when STAFF_PASSWORD is empty', async () => {
    const { app } = setup({ staffPassword: '' })
    await request(app).post('/api/staff/session').send({ password: '' }).expect(503)
  })
})

describe('GET /api/staff/session', () => {
  it('reports signed out before sign-in and signed in afterwards', async () => {
    const { app } = setup()
    const agent = request.agent(app)

    expect((await agent.get('/api/staff/session').expect(200)).body).toEqual({ signedIn: false })

    await agent.post('/api/staff/session').send({ password: PASSWORD }).expect(204)

    expect((await agent.get('/api/staff/session').expect(200)).body).toEqual({ signedIn: true })
  })
})

describe('DELETE /api/staff/session', () => {
  it('ends the session so booking data is no longer returned', async () => {
    const { app } = setup()
    const agent = await signedInAgent(app)
    await agent.get('/api/staff/bookings').expect(200)

    await agent.delete('/api/staff/session').expect(204)

    const response = await agent.get('/api/staff/bookings').expect(401)
    expect(response.body).toEqual({ error: 'Sign in to see bookings' })
  })
})

describe('sign-in protection', () => {
  it('refuses further attempts after 10 failures in 15 minutes, even with the correct password', async () => {
    const { app } = setup()
    for (let attempt = 0; attempt < 10; attempt++) {
      await request(app).post('/api/staff/session').send({ password: 'guess' }).expect(401)
    }

    const response = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(429)

    expect(response.body).toEqual({ error: 'Too many sign-in attempts. Please try again later.' })
  })

  it('does not count successful sign-ins towards the limit', async () => {
    const { app } = setup()
    for (let attempt = 0; attempt < 9; attempt++) {
      await request(app).post('/api/staff/session').send({ password: 'guess' }).expect(401)
    }
    await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(204)

    await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(204)
  })
})

describe('GET /api/staff/bookings', () => {
  it('refuses to return booking data without a staff session', async () => {
    const { app, store } = setup()
    store.create('riesling-evening', { name: 'Anna Keller', email: 'anna@example.de', guests: 2 })

    const response = await request(app).get('/api/staff/bookings').expect(401)

    expect(JSON.stringify(response.body)).not.toContain('Anna Keller')
  })

  it('lists every tasting with its bookings grouped under it', async () => {
    const { app, store } = setup()
    store.create('riesling-evening', { name: 'Anna Keller', email: 'anna@example.de', guests: 2 })
    store.create('riesling-evening', { name: 'Ben Ortiz', email: 'ben@example.de', guests: 1 })
    store.create('winter-tasting', { name: 'Carla Weiss', email: 'carla@example.de', guests: 4 })
    const agent = await signedInAgent(app)

    const response = await agent.get('/api/staff/bookings').expect(200)

    expect(response.body.map((group: { tastingId: string }) => group.tastingId)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ])
    const [riesling, redWine, winter] = response.body
    expect(riesling).toMatchObject({ title: 'Riesling Evening', seats: 12, seatsBooked: 3 })
    expect(riesling.bookings.map((b: { name: string }) => b.name)).toEqual(['Anna Keller', 'Ben Ortiz'])
    expect(riesling.bookings[0]).toEqual({
      reference: expect.stringMatching(/^KB-/),
      name: 'Anna Keller',
      email: 'anna@example.de',
      guests: 2,
    })
    expect(redWine).toMatchObject({ title: 'Red Wine Cellar Tour', seats: 8, seatsBooked: 0, bookings: [] })
    expect(winter).toMatchObject({ title: 'Winter Tasting', seats: 10, seatsBooked: 4 })
  })
})

describe('DELETE /api/staff/bookings/:reference', () => {
  it('refuses to cancel without a staff session and keeps the booking', async () => {
    const { app, store } = setup()
    const { booking } = store.create('riesling-evening', {
      name: 'Anna Keller',
      email: 'anna@example.de',
      guests: 2,
    }) as { booking: { reference: string } } & { status: 'created' }

    await request(app).delete(`/api/staff/bookings/${booking.reference}`).expect(401)

    expect(store.findByReference(booking.reference)).toBeDefined()
  })

  it('cancels the booking and frees its seats for guests', async () => {
    const { app, store } = setup()
    const created = store.create('riesling-evening', { name: 'Anna Keller', email: 'anna@example.de', guests: 4 })
    if (created.status !== 'created') throw new Error('expected a booking')
    const agent = await signedInAgent(app)

    await agent.delete(`/api/staff/bookings/${created.booking.reference}`).expect(204)

    expect(store.findByReference(created.booking.reference)).toBeUndefined()
    const tastings = await request(app).get('/api/tastings').expect(200)
    expect(tastings.body[0].seatsLeft).toBe(12)
  })

  it('reports a booking that was already cancelled', async () => {
    const { app, store } = setup()
    const created = store.create('riesling-evening', { name: 'Anna Keller', email: 'anna@example.de', guests: 1 })
    if (created.status !== 'created') throw new Error('expected a booking')
    const agent = await signedInAgent(app)
    await agent.delete(`/api/staff/bookings/${created.booking.reference}`).expect(204)

    const response = await agent.delete(`/api/staff/bookings/${created.booking.reference}`).expect(404)

    expect(response.body).toEqual({ error: 'This booking no longer exists' })
  })
})
