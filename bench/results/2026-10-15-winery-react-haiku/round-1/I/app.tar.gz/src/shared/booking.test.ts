import { describe, expect, it } from 'vitest'
import { createBookingSchema, MESSAGES } from './booking.js'

function firstErrorFor(
  field: string,
  input: Record<string, unknown>,
  options?: { seatsLeft?: number },
): string | undefined {
  const result = createBookingSchema(options).safeParse({
    name: 'Anna Keller',
    email: 'anna@example.de',
    guests: 2,
    ...input,
  })
  if (result.success) return undefined
  return result.error.issues.find((issue) => issue.path[0] === field)?.message
}

describe('booking input', () => {
  it('accepts a valid booking and trims the name and email', () => {
    const result = createBookingSchema().safeParse({
      name: '  Anna Keller ',
      email: ' anna@example.de ',
      guests: 2,
    })
    expect(result.success).toBe(true)
    expect(result.data).toEqual({ name: 'Anna Keller', email: 'anna@example.de', guests: 2 })
  })

  it('requires a name', () => {
    expect(firstErrorFor('name', { name: '' })).toBe('Enter your name')
    expect(firstErrorFor('name', { name: '   ' })).toBe('Enter your name')
  })

  it('limits the name to 100 characters', () => {
    expect(firstErrorFor('name', { name: 'a'.repeat(100) })).toBeUndefined()
    expect(firstErrorFor('name', { name: 'a'.repeat(101) })).toBe(MESSAGES.nameTooLong)
  })

  it('rejects an email address that is not valid', () => {
    expect(firstErrorFor('email', { email: 'anna@' })).toBe('Enter a valid email address')
    expect(firstErrorFor('email', { email: '' })).toBe('Enter a valid email address')
  })

  it('limits the email address to 254 characters', () => {
    const label = 'a'.repeat(63)
    const tooLong = `anna@${[label, label, label, label].join('.')}.de`
    expect(tooLong.length).toBeGreaterThan(254)
    expect(firstErrorFor('email', { email: tooLong })).toBe('Enter a valid email address')
  })

  it.each([0, 9, -1])('rejects %i guests as outside 1 to 8', (guests) => {
    expect(firstErrorFor('guests', { guests })).toBe('Enter between 1 and 8 guests')
  })

  it.each([1, 8])('accepts %i guests', (guests) => {
    expect(firstErrorFor('guests', { guests })).toBeUndefined()
  })

  it.each([2.5, Number.NaN])('rejects %s guests as not a whole number', (guests) => {
    expect(firstErrorFor('guests', { guests })).toBe('Enter a whole number of guests')
  })
})

describe('seat limit in the form schema', () => {
  it('rejects more guests than seats left and states how many are left', () => {
    expect(firstErrorFor('guests', { guests: 4 }, { seatsLeft: 3 })).toBe(
      'Only 3 seats left for this tasting',
    )
  })

  it('accepts exactly the seats left', () => {
    expect(firstErrorFor('guests', { guests: 3 }, { seatsLeft: 3 })).toBeUndefined()
  })

  it('uses the singular for one seat left', () => {
    expect(firstErrorFor('guests', { guests: 2 }, { seatsLeft: 1 })).toBe(
      'Only 1 seat left for this tasting',
    )
  })

  it('does not apply a seat limit when no seat count is given (the server enforces it atomically)', () => {
    expect(firstErrorFor('guests', { guests: 8 })).toBeUndefined()
  })
})
