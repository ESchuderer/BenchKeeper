import { z } from 'zod'

export const MAX_GUESTS = 8
export const MAX_NAME_LENGTH = 100
export const MAX_EMAIL_LENGTH = 254

/** Every user-facing validation message. Shared so the browser and the server say the same thing. */
export const MESSAGES = {
  name: 'Enter your name',
  nameTooLong: 'Use 100 characters or fewer',
  email: 'Enter a valid email address',
  guestRange: `Enter between 1 and ${MAX_GUESTS} guests`,
  guestWhole: 'Enter a whole number of guests',
  fullyBooked: 'This tasting is fully booked',
  seatsLeft: (seats: number) => `Only ${seats} ${seats === 1 ? 'seat' : 'seats'} left for this tasting`,
} as const

export interface BookingInput {
  name: string
  email: string
  guests: number
}

/**
 * Builds the booking input schema. Pass `seatsLeft` in the browser to show the seat
 * limit before submitting; the server omits it and enforces the limit when it stores the booking.
 */
export function createBookingSchema(options: { seatsLeft?: number } = {}) {
  const { seatsLeft } = options

  let guests = z
    .number({ error: MESSAGES.guestWhole })
    .int(MESSAGES.guestWhole)
    .min(1, MESSAGES.guestRange)
    .max(MAX_GUESTS, MESSAGES.guestRange)
  if (seatsLeft !== undefined) {
    guests = guests.refine((count) => count <= seatsLeft, { message: MESSAGES.seatsLeft(seatsLeft) })
  }

  return z.object({
    name: z
      .string({ error: MESSAGES.name })
      .trim()
      .min(1, MESSAGES.name)
      .max(MAX_NAME_LENGTH, MESSAGES.nameTooLong),
    email: z
      .string({ error: MESSAGES.email })
      .trim()
      .max(MAX_EMAIL_LENGTH, MESSAGES.email)
      .pipe(z.email({ error: MESSAGES.email })),
    guests,
  })
}
