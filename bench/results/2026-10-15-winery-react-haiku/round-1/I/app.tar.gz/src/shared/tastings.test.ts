import { describe, expect, it } from 'vitest'
import { TASTINGS, findTasting, formatStartsAt, seatsLeftLabel } from './tastings.js'

describe('tasting catalogue', () => {
  it('offers the three tastings with the titles, start times, prices and seats from the brief', () => {
    expect(
      TASTINGS.map(({ title, startsAt, pricePerGuestEur, seats }) => ({
        title,
        startsAt,
        pricePerGuestEur,
        seats,
      })),
    ).toEqual([
      { title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuestEur: 25, seats: 12 },
      { title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuestEur: 32, seats: 8 },
      { title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuestEur: 28, seats: 10 },
    ])
  })

  it('gives every tasting a distinct URL-safe id', () => {
    const ids = TASTINGS.map((tasting) => tasting.id)
    expect(new Set(ids).size).toBe(ids.length)
    expect(ids).toEqual(['riesling-evening', 'red-wine-cellar-tour', 'winter-tasting'])
  })

  it('finds a tasting by id and returns undefined for an unknown id', () => {
    expect(findTasting('winter-tasting')?.title).toBe('Winter Tasting')
    expect(findTasting('no-such-tasting')).toBeUndefined()
  })
})

describe('formatStartsAt', () => {
  it('shows the date and time as the winery wrote them, without shifting for the viewer time zone', () => {
    expect(formatStartsAt('2026-11-06T18:00')).toBe('Fri, 6 Nov 2026, 18:00')
  })
})

describe('seatsLeftLabel', () => {
  it.each([
    [0, '0 seats left'],
    [1, '1 seat left'],
    [7, '7 seats left'],
  ])('labels %i seats as %j', (seats, label) => {
    expect(seatsLeftLabel(seats)).toBe(label)
  })
})
