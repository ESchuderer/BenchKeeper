export interface Tasting {
  id: string
  title: string
  /** Local wall-clock start time, e.g. "2026-11-06T18:00". No time zone: the winery's own time. */
  startsAt: string
  pricePerGuestEur: number
  seats: number
}

export const TASTINGS: readonly Tasting[] = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06T18:00',
    pricePerGuestEur: 25,
    seats: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    startsAt: '2026-11-14T15:00',
    pricePerGuestEur: 32,
    seats: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    startsAt: '2026-12-05T17:00',
    pricePerGuestEur: 28,
    seats: 10,
  },
]

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((tasting) => tasting.id === id)
}

const startsAtFormat = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'UTC',
  weekday: 'short',
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
})

/**
 * Formats a local start time for display. Formatting in UTC keeps the wall-clock
 * time exactly as entered, whatever the time zone of the server or the browser.
 */
export function formatStartsAt(startsAt: string): string {
  return startsAtFormat.format(new Date(`${startsAt}:00Z`))
}

export function seatsLeftLabel(seatsLeft: number): string {
  return `${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left`
}
