import { vi } from 'vitest'

export interface MockResponse {
  status: number
  body?: unknown
}

export type ApiHandler = (method: string, path: string, body: unknown) => MockResponse | Promise<MockResponse>

/** Replaces `fetch` with a handler that answers API calls, so component tests need no server. */
export function mockApi(handler: ApiHandler) {
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const method = init?.method ?? 'GET'
    const path = String(input)
    const body = typeof init?.body === 'string' ? JSON.parse(init.body) : undefined
    const { status, body: responseBody } = await handler(method, path, body)
    return new Response(responseBody === undefined ? null : JSON.stringify(responseBody), {
      status,
      headers: { 'Content-Type': 'application/json' },
    })
  })
  vi.stubGlobal('fetch', fetchMock)
  return fetchMock
}

export const TASTING_LIST = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06T18:00',
    pricePerGuestEur: 25,
    seats: 12,
    seatsLeft: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    startsAt: '2026-11-14T15:00',
    pricePerGuestEur: 32,
    seats: 8,
    seatsLeft: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    startsAt: '2026-12-05T17:00',
    pricePerGuestEur: 28,
    seats: 10,
    seatsLeft: 3,
  },
]
