# Weingut Kieselbrunnen — wine tasting bookings

A small web app where guests book seats in the winery's tastings and staff see and cancel bookings.

- **Guests** see the tastings with date, price and seats left, and book through a form. A booking gets a confirmation with a reference.
- **Staff** sign in at `/staff` with a password and see every booking grouped by tasting. Cancelling a booking frees its seats.

The server is Node.js with Express. The interface is React, built with Vite. Bookings are kept in a local JSON file, so no external service is needed.

## Requirements

- Node.js 22 or newer

## Install, build and start

```bash
npm install
npm run build
PORT=3000 STAFF_PASSWORD='choose-a-long-password' npm start
```

Open http://localhost:3000 for the guest pages and http://localhost:3000/staff for staff sign-in.

`npm start` serves the API and the built interface from one process.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | Port the server listens on. |
| `STAFF_PASSWORD` | _(unset)_ | Password for staff sign-in. If unset, the guest pages still work and `/staff` reports that sign-in is not configured. |
| `DATA_FILE` | `data/bookings.json` | JSON file that stores the bookings. It is created on the first booking. |
| `TRUST_PROXY` | `0` | Number of reverse proxies in front of the app, for example `1`. Leave it unset when clients connect to the app directly. With a proxy, the staff cookie is marked `Secure` over HTTPS and the sign-in limit applies to the real client address. Any other value, such as `true`, stops startup. |

The app starts with no bookings. Each change is written to `DATA_FILE` before the response is sent. If the file exists but cannot be read, the server refuses to start and names the file. It does not overwrite it.

**Keep `DATA_FILE` and `staff-sessions.json` on storage that survives restarts and redeploys.** On a host with an ephemeral filesystem, every deploy would delete the bookings.

## Behaviour to know about

- **Staff sessions last 12 hours and survive a restart.** They are kept in `staff-sessions.json` next to `DATA_FILE`, with only a hash of each token. Signing out or the 12-hour limit ends a session.
- **Sign-in is limited** to 10 failed attempts per 15 minutes per client. Successful sign-ins do not count.
- **Bookings close when the tasting starts.** A tasting that has started stays listed, but takes no new bookings. Times are shown in Europe/Berlin.
- **Cancelling deletes the booking.** No cancellation history is kept, so the reference of a cancelled booking then shows "Booking not found".
- **Seat counts refresh when a page loads.** There is no live update.

## Development

```bash
npm run dev          # API server with restart on change (port 3000)
npm run dev:client   # Vite dev server for the interface, proxies /api to port 3000
```

## Tests and checks

```bash
npm run typecheck    # TypeScript for the interface and the server
npm test             # unit, API and component tests
npm run build        # build the interface and compile the server
```

The tests cover the tasting catalogue, seat limits under simultaneous bookings, validation messages, the file store, staff sign-in and its rate limit, and the pages.

## Project layout

```
src/shared/   validation schema and types used by both the browser and the server
src/server/   Express app, booking store, staff sessions, server entry point
src/client/   React pages (start, booking, confirmation, staff) and routing
openspec/     OpenSpec change records: proposal, specs, design and tasks
```
