# Design

## Context

The repository is empty apart from the OpenSpec scaffolding, so the stack is chosen here. See proposal.md for motivation and the three delta specs (`tasting-catalog`, `guest-booking`, `staff-bookings`) for the observable behavior. The app is small: three fixed tastings, a few hundred bookings at most, one winery, one process. It must run with `npm install`, `npm run build`, and `npm start` on Node 22 with no external services.

## Goals / Non-Goals

**Goals:**
- One Node process serves both the JSON API and the built React interface on `PORT`.
- Seat limits hold under concurrent bookings.
- Validation rules are defined once and enforced on the server; the client uses the same rules for immediate feedback.
- Pages look like a small winery site and work on phones.

**Non-Goals:**
- Payment, invoices, email confirmations, guest accounts, or editing a booking.
- Managing tastings in the UI; the three tastings are fixed in code.
- Horizontal scaling or multiple server instances sharing one data file.
- Internationalisation; the UI is English only.

## Decisions

**Server: Express 5, TypeScript compiled to `dist/server`.** Express is the established, minimal Node server; it serves `/api/*` and the built static files with a fallback to `index.html` for client routes. The server is compiled ahead of time with `tsc`, so `npm start` runs plain `node` with no runtime loader. Alternative considered: Next.js. Rejected because it brings a large framework and its own build and routing model for a three-page app; a plain SPA plus a small API fits the brief better.

**Front end: React 19 with Vite and TypeScript.** Vite builds the static bundle into `dist/client`. Alternative: Create React App, which is deprecated.

**Routing: React Router (library mode).** Client routes are `/` (start page), `/tastings/:slug/book` (booking form), `/bookings/:reference` (confirmation), and `/staff`. Tasting slugs are `riesling-evening`, `red-wine-cellar-tour`, and `winter-tasting`.

**Forms and validation: react-hook-form with Zod.** One Zod schema per form lives in `src/shared` and is imported by both the browser and the server. Server errors use the same field names, so each message lands next to the field it concerns. Alternative: hand-written validation, which would duplicate rules and drift.

**Styling: Tailwind CSS v4 via the Vite plugin.** Utility classes give responsive layout and a consistent palette without writing a CSS system from scratch. Design tokens (wine red, cream, oak neutrals, a serif heading face) are defined once in the theme.

**Storage: an in-memory store persisted to a JSON file.** The store keeps the bookings in memory and writes the whole file atomically (write to a temporary file, then rename) after every change. The file path comes from `DATA_FILE`, defaulting to `data/bookings.json`, which is git-ignored. The seat check and the insert happen in one synchronous function, so two requests cannot both see the same free seats in a single Node process. If the file exists but cannot be parsed, startup fails with a clear message rather than silently discarding bookings. Alternative: SQLite via `node:sqlite` or `better-sqlite3`. Rejected for now: the data is tiny and the JSON store has no native build step; the store sits behind a small interface so it can be swapped later.

**Booking reference: 8 characters from an unambiguous alphabet** (`A–Z` and `2–9`, excluding easily confused letters), generated with `crypto.randomInt`, retried on the rare collision. The confirmation page loads by reference and returns only tasting, guests, total, and reference, not the guest's name or email.

**Money and time.** Prices are whole euros, so totals are integers. Start times are stored with their offset (`+01:00` for November and December 2026) and formatted in `Europe/Berlin`, the winery's time zone.

**Staff authentication: password from `STAFF_PASSWORD`, opaque session token in an `HttpOnly`, `SameSite=Strict` cookie.** The password is compared with `crypto.timingSafeEqual` on SHA-256 digests of both values. Sessions are random 256-bit tokens with a 12-hour expiry. Only the SHA-256 hash of each token is stored, in `staff-sessions.json` next to `DATA_FILE`, so sessions survive a restart as the spec requires. Sign-in is rate-limited with `express-rate-limit` (10 attempts per 15 minutes per IP) to slow down guessing. If `STAFF_PASSWORD` is unset, the server still starts and the staff page reports that sign-in is not configured. This is my call: a missing staff setting should not stop guests from booking.

**API surface:**

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/tastings` | Tastings with `seatsLeft` |
| POST | `/api/tastings/:slug/bookings` | Create booking `{ name, email, guests }` → `201` with reference, or `400` (field errors), `404` (unknown tasting), `409` (not enough seats, includes `seatsLeft`) |
| GET | `/api/bookings/:reference` | Public confirmation details |
| POST | `/api/staff/session` | Sign in `{ password }` → `204` and cookie, or `401`, or `429` |
| DELETE | `/api/staff/session` | Sign out |
| GET | `/api/staff/bookings` | Bookings grouped by tasting, staff session required |
| DELETE | `/api/staff/bookings/:reference` | Cancel booking, staff session required; `404` if missing |

**Sign-out.** The spec only requires sessions to persist until sign-out or expiry; the sign-out endpoint and button are added so staff can end a session on a shared computer. This is my call and is listed for review.

**Cancellation has no confirmation dialog.** Cancelling deletes the booking immediately and the overview updates. Adding a dialog is a small change if the winery prefers it.

**Calls made during review (my decisions, for the winery to confirm):**
- **Seat counts refresh on page load.** No polling or push. The specs describe values as of a page view.
- **Bookings close at a tasting's start time.** The tasting stays listed (with its state shown as started) but accepts no new bookings from that moment. None of the three tastings is in the past at the time of writing.
- **Cancellation deletes the booking.** The reference of a cancelled booking then returns "Booking not found". No cancellation history is kept, because the specs do not require one.
- **Hosting and disk.** The app writes to `DATA_FILE`, so the winery's host must keep that path on persistent storage across restarts and redeploys. The README states this requirement.
- **Reverse proxy.** `TRUST_PROXY` is a count of proxies (for example `1`), not a boolean. With `true`, Express would take the client-supplied leftmost `X-Forwarded-For` entry as the client address, which lets a client bypass the sign-in limit, so such a value stops startup. With a count, the address the proxy appends is used. Without `TRUST_PROXY`, the socket address is used, which is correct for direct deployment.
- **Sign-in limit counts failed attempts only** (`skipSuccessfulRequests`), so staff who sign in correctly are never locked out.

## Risks / Trade-offs

- **The sessions file holds hashes of live tokens.** → The tokens are random and only hashes are stored, so the file cannot be used to sign in; it is written atomically like the bookings file.
- **A single JSON file is not suitable for multiple instances.** → Deployment is a single process; the store interface keeps a later move to a database contained.
- **A crash between an in-memory change and the file write could lose the last booking.** → Writes happen before the response is sent, so a guest never sees a confirmation that is not on disk; the window is limited to the write itself.
- **Brute-force against the staff password.** → Rate limit, timing-safe comparison, and a long random-looking password recommended in the README. Passwords are not hashed at rest because they live only in the environment variable.
- **Time zone assumptions.** → Fixed offsets are correct for these dates. If tastings move into a different season, the offset must be derived from the zone, which the formatter already does.

## Migration Plan

This is a new application, so there is no data to migrate. Deploying means running `npm install`, `npm run build`, and `npm start` with `PORT` and `STAFF_PASSWORD` set. Rollback is stopping the process and, if needed, deleting `data/bookings.json`; the app then starts with no bookings.
