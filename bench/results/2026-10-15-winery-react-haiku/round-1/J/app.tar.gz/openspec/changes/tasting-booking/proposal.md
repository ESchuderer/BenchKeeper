# Proposal

## Why

Weingut Kieselbrunnen runs wine tastings but has no way for guests to reserve a place online, and no single view for staff of who is coming. A small web app lets guests book a seat for a scheduled tasting and lets staff see and manage those bookings, so seat counts stay correct and nobody has to handle reservations by phone or by hand.

## What Changes

- Add a public start page that lists the three scheduled tastings (Riesling Evening, Red Wine Cellar Tour, Winter Tasting) with title, date and time, price per guest, and seats left. A fully booked tasting is clearly marked and cannot be booked.
- Add a booking form per tasting with Name, Email, and Guests (1 to 8) and a "Book" button. The booking is rejected if it asks for more seats than remain, and invalid input is reported next to the field it concerns.
- Show a "Booking confirmed" page after a successful booking with the tasting, number of guests, total price, and a booking reference.
- Add a staff page at `/staff` protected by a password read from the `STAFF_PASSWORD` environment variable. Signed-in staff see all bookings grouped by tasting (name, email, guests, reference) and can cancel any booking; cancelling frees its seats.
- The app starts with no bookings. Bookings are stored locally (in memory or in a local file); no external service is used.
- The interface is in English and designed as a polished, responsive site that works on phones.

## Capabilities

### New Capabilities

- `tasting-catalog`: The list of scheduled tastings shown to guests, with price, date and time, and seats-left counts current as of each page load, including the fully-booked state.
- `guest-booking`: Booking a seat in a tasting through the guest form, including capacity limits, input validation with per-field errors, and the booking confirmation with its reference.
- `staff-bookings`: Staff sign-in with the configured password, the bookings overview grouped by tasting, and cancellation of bookings that frees seats.

### Modified Capabilities

None. The repository has no existing specs.

## Impact

- New application code: a Node 22 server that serves the API and the built React interface, and a React single-page front end.
- New dependencies from the npm registry, limited to established, maintained libraries for the server, routing, forms, validation, and styling.
- Runtime configuration: `PORT` (default 3000) and `STAFF_PASSWORD` environment variables.
- Data: a local store for bookings, starting empty on each fresh install. No external systems, accounts, or payment processing are involved; the price is shown and totalled but not charged.
