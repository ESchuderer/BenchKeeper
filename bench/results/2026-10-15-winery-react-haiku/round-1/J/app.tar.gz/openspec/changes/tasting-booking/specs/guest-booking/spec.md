# Spec Delta

## Purpose

Lets a guest reserve seats in a chosen tasting through an online form, with the seat limit enforced, invalid input explained next to the field it concerns, and a confirmation with a booking reference.

## ADDED Requirements

### Requirement: Booking form
The booking form for a tasting SHALL have three fields labelled "Name", "Email", and "Guests", and a button labelled "Book". The Guests field SHALL accept whole numbers from 1 to 8.

#### Scenario: Form opened for a tasting
- **WHEN** a guest opens the booking form for Red Wine Cellar Tour
- **THEN** the form shows the fields "Name", "Email", and "Guests" and a "Book" button
- **AND** the form identifies the tasting as Red Wine Cellar Tour

### Requirement: Input validation
The system SHALL reject a booking whose input is invalid and SHALL show an error message next to each field that is invalid. Name SHALL be required and SHALL NOT exceed 100 characters after surrounding whitespace is removed. Email SHALL be required and SHALL be a syntactically valid email address. Guests SHALL be a whole number from 1 to 8. The same rules SHALL be enforced by the server regardless of client checks.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty Name
- **THEN** the error "Please enter your name" is shown next to the Name field
- **AND** no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits the form with the Email "anna@example"
- **THEN** the error "Please enter a valid email address" is shown next to the Email field
- **AND** no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits the form with Guests set to 0 or 9
- **THEN** the error "Please choose between 1 and 8 guests" is shown next to the Guests field
- **AND** no booking is created

#### Scenario: Server rejects input the client did not check
- **WHEN** a request reaches the server with an empty Name or Guests outside 1 to 8
- **THEN** the server responds with a validation error naming the invalid field
- **AND** no booking is created

### Requirement: Seat limit
A booking SHALL NOT take more seats than the tasting has left at the moment the booking is made. A booking that asks for more seats than are left SHALL be rejected with an error next to the Guests field stating how many seats are left, and the seats left SHALL NOT change. Concurrent booking requests SHALL NOT together take more seats than are available.

#### Scenario: More guests than seats left
- **WHEN** a guest books 4 guests for Winter Tasting and only 3 seats are left
- **THEN** the error "Only 3 seats left for this tasting" is shown next to the Guests field
- **AND** no booking is created and the seats left stay at 3

#### Scenario: Last seats booked by two guests at once
- **WHEN** two bookings of 2 guests each for a tasting with 3 seats left are submitted at the same time
- **THEN** exactly one booking is confirmed
- **AND** the other is rejected with the seats-left error

#### Scenario: Fully booked tasting
- **WHEN** a booking is submitted for a tasting with zero seats left
- **THEN** the booking is rejected with the message "This tasting is fully booked"
- **AND** no booking is created

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a page with the heading "Booking confirmed", the tasting title, the number of guests, the total price in EUR (guests multiplied by the price per guest), and a booking reference. The booking reference SHALL be unique among bookings and SHALL consist of 8 uppercase letters and digits.

#### Scenario: Successful booking
- **WHEN** a guest books 2 guests for Riesling Evening
- **THEN** the page heading reads "Booking confirmed"
- **AND** the page shows "Riesling Evening", "2 guests", "EUR 50" as the total, and a booking reference of 8 uppercase letters and digits

#### Scenario: References are unique
- **WHEN** two bookings are confirmed
- **THEN** each has a different booking reference

### Requirement: Bookings close at start time
A booking SHALL NOT be accepted once the tasting's start time has passed. A tasting whose start time has passed SHALL remain listed as started, with no booking action. The start time is evaluated in the Europe/Berlin time zone.

#### Scenario: Booking after the start time
- **WHEN** a booking is submitted for Riesling Evening at 18:01 on 2026-11-06
- **THEN** the booking is rejected with the message "This tasting has already started"
- **AND** no booking is created

### Requirement: Unknown tasting
A booking form or booking request for a tasting that does not exist SHALL show a "Tasting not found" page or response and SHALL NOT create a booking.

#### Scenario: Unknown tasting address
- **WHEN** a guest opens the booking form for a tasting identifier that is not on offer
- **THEN** the page shows "Tasting not found"
