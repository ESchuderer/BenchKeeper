# Spec Delta

## Purpose

Gives winery staff a password-protected page where they can see every booking grouped by tasting and cancel a booking, which frees its seats for other guests.

## ADDED Requirements

### Requirement: Staff sign-in
The page at `/staff` SHALL show a "Password" field and a "Sign in" button until staff are signed in. The password SHALL be checked against the value of the `STAFF_PASSWORD` environment variable. A correct password SHALL sign the staff member in; an incorrect or empty password SHALL show an error and SHALL NOT sign anyone in.

#### Scenario: Wrong password
- **WHEN** a visitor submits "guess123" on the staff page and it does not match STAFF_PASSWORD
- **THEN** the error "Incorrect password" is shown
- **AND** the bookings are not shown

#### Scenario: Correct password
- **WHEN** a visitor submits the value of STAFF_PASSWORD
- **THEN** the staff bookings overview is shown

#### Scenario: Password not configured
- **WHEN** the server starts without a STAFF_PASSWORD value
- **THEN** the server still starts and serves the guest pages
- **AND** the staff page shows "Staff sign-in is not configured" and no sign-in succeeds

### Requirement: Staff session
A signed-in staff session SHALL persist across page reloads in the same browser until the staff member signs out or the session expires after 12 hours. Staff-only data and actions SHALL be refused for requests without a valid staff session.

#### Scenario: Reload keeps the session
- **WHEN** a signed-in staff member reloads the staff page
- **THEN** the bookings overview is still shown without a new sign-in

#### Scenario: Unauthenticated request
- **WHEN** a request for the bookings list or a cancellation arrives without a valid staff session
- **THEN** the server responds with status 401
- **AND** no booking data is returned

### Requirement: Bookings overview
The staff overview SHALL group all active bookings by tasting and SHALL show each booking's name, email, number of guests, and booking reference. A tasting without bookings SHALL show "No bookings yet".

#### Scenario: Bookings grouped by tasting
- **WHEN** staff open the overview and Riesling Evening has two bookings
- **THEN** Riesling Evening is listed as a group containing both bookings with name, email, guests, and reference

#### Scenario: Empty tasting
- **WHEN** staff open the overview and Winter Tasting has no bookings
- **THEN** the Winter Tasting group shows "No bookings yet"

### Requirement: Cancel booking
Each booking in the overview SHALL have a "Cancel" button. Cancelling a booking SHALL remove it from the overview and SHALL free its guests' seats for that tasting, so the seats left on the guest pages increase by the booking's guest count.

#### Scenario: Cancelling a booking
- **WHEN** staff select "Cancel" on a booking for 2 guests for Red Wine Cellar Tour
- **THEN** the booking disappears from the overview
- **AND** the seats left for Red Wine Cellar Tour increase by 2

#### Scenario: Booking already cancelled
- **WHEN** staff try to cancel a booking that no longer exists
- **THEN** the error "This booking no longer exists" is shown
- **AND** the overview is refreshed
