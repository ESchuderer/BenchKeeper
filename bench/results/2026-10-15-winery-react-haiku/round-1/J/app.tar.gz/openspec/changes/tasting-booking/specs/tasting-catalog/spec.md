# Spec Delta

## Purpose

Lets guests see which wine tastings are scheduled, when they take place, what they cost per guest, and how many seats are still free before they choose one to book.

## ADDED Requirements

### Requirement: Tasting list on the start page
The start page SHALL list every scheduled tasting in chronological order. Each entry SHALL show the tasting title, its date and time, its price per guest in EUR, and its seats left. The scheduled tastings are the three defined by the winery: Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats), and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats).

#### Scenario: Guest opens the start page
- **WHEN** a guest opens the start page of a fresh installation
- **THEN** the page lists Riesling Evening, Red Wine Cellar Tour, and Winter Tasting in that order
- **AND** each entry shows its date and time, its price per guest, and "<n> seats left" with n equal to its full seat count

### Requirement: Seats left reflect bookings
The seats left shown for a tasting SHALL equal its seat count minus the number of guests in its active bookings. Cancelled bookings SHALL NOT count against the seats left.

#### Scenario: Seats left after a booking
- **WHEN** a booking for 3 guests is confirmed for Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening

#### Scenario: Seats returned by a cancellation
- **WHEN** a booking for 3 guests for Riesling Evening is cancelled
- **THEN** the start page shows "12 seats left" for Riesling Evening again

### Requirement: Fully booked tastings
A tasting with zero seats left SHALL be marked as fully booked. A fully booked tasting SHALL NOT offer a booking action, and the page SHALL show its state clearly.

#### Scenario: Last seats are taken
- **WHEN** the last free seat of Winter Tasting is booked
- **THEN** the Winter Tasting entry shows "Fully booked" instead of "0 seats left"
- **AND** the entry offers no "Book Winter Tasting" link or button

### Requirement: Booking action per tasting
Each tasting that still has seats left SHALL offer a link or button labelled "Book <tasting title>" that opens that tasting's booking form.

#### Scenario: Opening a booking form from the list
- **WHEN** a guest selects "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens
