# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` (Node 22 engine, scripts `build`, `start`, `dev`, `test`, `typecheck`) and `.gitignore` (`node_modules`, `dist`, `data`); verify `npm install` completes without errors
- [x] 1.2 Add TypeScript configs for the client (`tsconfig.json`) and server (`tsconfig.server.json` → `dist/server`), plus Vite with React and Tailwind CSS v4; verify `npm run typecheck` passes on an empty `src/`
- [x] 1.3 Add test tooling (Vitest with jsdom, Testing Library, supertest) and a placeholder test; verify `npm test` runs and passes
- [x] 1.4 Add the app shell: `index.html`, React entry point, router with placeholder routes for `/`, `/tastings/:slug/book`, `/bookings/:reference`, `/staff`, and a not-found page; verify `npm run build` produces `dist/client` and `dist/server/index.js`

## 2. Tasting catalog

- [x] 2.1 Write tests for the tasting definitions (three tastings, slugs, dates with `+01:00` offset, prices, seat counts) and for `seatsLeft` (seat count minus active guests; cancelled bookings ignored), then implement `src/server/tastings.ts` and `src/server/bookingStore.ts` read paths until they pass
- [x] 2.2 Write API tests for `GET /api/tastings` (chronological order, `seatsLeft` values, fully booked state), then implement the route until they pass
- [x] 2.3 Write component tests for the start page (title, Europe/Berlin date and time, "EUR n per guest", "<n> seats left", "Fully booked" with no booking action, "Book <title>" links), then implement the start page against the API until they pass
- [x] 2.4 Verify in the browser that the start page lists the three tastings in order on a 375 px-wide viewport and on desktop

## 3. Guest booking

- [x] 3.1 Write tests for the shared Zod booking schema (required name ≤100 characters after trimming, valid email, guests integer 1–8, rejection messages from the spec), then implement `src/shared/bookingSchema.ts` until they pass
- [x] 3.2 Write store tests for capacity: a booking within the seats left is confirmed; a booking above the seats left is rejected and leaves seats unchanged; two parallel requests for the last seats confirm exactly one; zero seats left rejects with "fully booked"; a booking after the start time (Europe/Berlin) is rejected with "already started"; then implement `createBooking` in the store until they pass
- [x] 3.3 Write store tests for references (8 characters from the unambiguous alphabet, unique across bookings) and for the file store (bookings written atomically to `DATA_FILE`, reloaded on start, startup fails on a corrupt file), then implement them until they pass
- [x] 3.4 Write API tests for `POST /api/tastings/:slug/bookings` (201 with reference; 400 with field errors for name, email, guests; 409 with `seatsLeft`; 404 for unknown slug) and for `GET /api/bookings/:reference` (returns tasting, guests, total, reference, and no name or email; 404 when unknown), then implement the routes until they pass
- [x] 3.5 Write component tests for the booking form (fields "Name", "Email", "Guests", button "Book"; field-level errors shown next to each field; server 409 shown on the Guests field; "Tasting not found" for an unknown slug), then implement the form page until they pass
- [x] 3.6 Write component tests for the confirmation page (heading "Booking confirmed", tasting, guests, "EUR" total, reference; "Booking not found" for an unknown reference), then implement it until they pass
- [x] 3.7 Verify end to end in the browser: book two guests for Riesling Evening, see the confirmation, then see the seats left drop by two on the start page; try an over-limit booking and see the error next to Guests

## 4. Staff bookings

- [x] 4.1 Write tests for the password check (correct password accepted; wrong or empty rejected; comparison uses timing-safe digests; `STAFF_PASSWORD` unset means sign-in reports not configured) and for session tokens (random, 12-hour expiry, invalid after sign-out), then implement `src/server/staffAuth.ts` until they pass
- [x] 4.2 Write API tests for `POST /api/staff/session` (204 and `HttpOnly`, `SameSite=Strict` cookie on success; 401 on wrong password; 429 after 10 attempts in 15 minutes), `DELETE /api/staff/session`, and the staff-only routes returning 401 without a session, then implement the routes until they pass
- [x] 4.3 Write store tests for `listBookingsByTasting` (grouped by tasting in chronological order, empty groups included) and `cancelBooking` (removes the booking, frees seats, returns 404 when the reference is unknown), then implement them until they pass
- [x] 4.4 Write API tests for `GET /api/staff/bookings` and `DELETE /api/staff/bookings/:reference` with a valid session, then implement the routes until they pass
- [x] 4.5 Write component tests for the staff page (sign-in form with "Password" field and "Sign in" button; "Incorrect password" error; "Staff sign-in is not configured" notice; grouped overview with name, email, guests, reference; "No bookings yet"; "Cancel" removes the row; "This booking no longer exists" error), then implement the page until they pass
- [x] 4.6 Verify end to end in the browser: sign in with the password, cancel a booking, and see its seats return on the start page; confirm that `/api/staff/bookings` returns 401 when signed out

## 5. Look, feel, and documentation

- [x] 5.1 Apply the winery visual design (palette, typography, header and footer, cards with fully-booked and seat-count states, form error styles, success state) and verify on 375 px and 1280 px viewports with screenshots reviewed for legibility and contrast
- [x] 5.2 Serve the built client from Express with a fallback to `index.html` for client routes, and verify `npm run build && npm start` with `PORT=4567` serves `/`, `/tastings/winter-tasting/book`, and `/staff` directly
- [x] 5.3 Write `README.md` covering install, build, start, `PORT` (default 3000), `STAFF_PASSWORD`, `DATA_FILE`, the staff session behaviour on restart, and how to run the tests; verify each command in the README runs as written

## 6. Integration checks

- [x] 6.1 Run `npm run typecheck`, `npm test`, and `npm run build` from a clean checkout (`rm -rf node_modules dist data`) and verify all pass
- [x] 6.2 Verify the full guest journey and the full staff journey against the running server on a fresh data file, covering every scenario in the three delta specs

## Workflow follow-up

- Review the implementation against the specs in `openspec/changes/tasting-booking/specs/` before archiving.
- Archive the change with `openspec archive tasting-booking` once the review is complete.
