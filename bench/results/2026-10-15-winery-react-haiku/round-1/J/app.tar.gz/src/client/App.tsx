import { BrowserRouter, Route, Routes } from 'react-router';
import { BookingPage } from './BookingPage';
import { ConfirmationPage } from './ConfirmationPage';
import { NotFoundPage } from './NotFoundPage';
import { StaffPage } from './StaffPage';
import { StartPage } from './StartPage';

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<StartPage />} />
        <Route path="/tastings/:slug/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
        <Route path="/staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
}
