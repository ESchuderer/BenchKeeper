import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes } from 'react-router';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { BookingPage } from './BookingPage';
import type { TastingSummary } from '../shared/types';

const riesling: TastingSummary = {
  slug: 'riesling-evening',
  title: 'Riesling Evening',
  startsAt: '2026-11-06T18:00:00+01:00',
  pricePerGuest: 25,
  seats: 12,
  seatsLeft: 3,
  status: 'open',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
}

function renderBookingPage() {
  return render(
    <MemoryRouter initialEntries={['/tastings/riesling-evening/book']}>
      <Routes>
        <Route path="/tastings/:slug/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<p>Confirmation route reached</p>} />
      </Routes>
    </MemoryRouter>,
  );
}

function fieldFor(label: string): HTMLElement {
  return screen.getByLabelText(label).closest('div') as HTMLElement;
}

describe('BookingPage', () => {
  let fetchMock: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    fetchMock = vi.fn(async (_url: string, init?: RequestInit) => {
      if (init?.method === 'POST') return json({ reference: 'ABCD2345' }, 201);
      return json(riesling);
    });
    vi.stubGlobal('fetch', fetchMock);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('shows the tasting and a form with Name, Email, Guests and a Book button', async () => {
    renderBookingPage();

    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows field errors next to the fields and does not send an invalid booking', async () => {
    const user = userEvent.setup();
    renderBookingPage();
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Email'), 'anna@example');
    await user.type(screen.getByLabelText('Guests'), '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await within(fieldFor('Name')).findByText('Please enter your name')).toBeInTheDocument();
    expect(within(fieldFor('Email')).getByText('Please enter a valid email address')).toBeInTheDocument();
    expect(within(fieldFor('Guests')).getByText('Please choose between 1 and 8 guests')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/1 to 8 guests/);
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'POST')).toBe(false);
  });

  it('books and moves to the confirmation page', async () => {
    const user = userEvent.setup();
    renderBookingPage();
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Confirmation route reached')).toBeInTheDocument();
    const post = fetchMock.mock.calls.find(([, init]) => init?.method === 'POST');
    expect(JSON.parse(post![1].body)).toEqual({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
  });

  it('shows the seat limit from the server next to the Guests field and keeps the entered values', async () => {
    fetchMock.mockImplementation(async (_url: string, init?: RequestInit) => {
      if (init?.method === 'POST') {
        return json({ message: 'Only 3 seats left for this tasting', errors: { guests: 'Only 3 seats left for this tasting' }, seatsLeft: 3 }, 409);
      }
      return json(riesling);
    });
    const user = userEvent.setup();
    renderBookingPage();
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.type(screen.getByLabelText('Guests'), '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await within(fieldFor('Guests')).findByText('Only 3 seats left for this tasting')).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Keller');
  });

  it('stops offering the form when the last seat goes while the form is open', async () => {
    const user = userEvent.setup();
    let booked = false;
    fetchMock.mockImplementation(async (_url: string, init?: RequestInit) => {
      if (init?.method === 'POST') {
        booked = true;
        return json({ message: 'This tasting is fully booked', seatsLeft: 0 }, 409);
      }
      return json(booked ? { ...riesling, seatsLeft: 0, status: 'fully_booked' } : riesling);
    });
    renderBookingPage();
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('This tasting is fully booked')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });

  it('says a fully booked tasting cannot be booked', async () => {
    fetchMock.mockImplementation(async () => json({ ...riesling, seatsLeft: 0, status: 'fully_booked' }));

    renderBookingPage();

    expect(await screen.findByText('This tasting is fully booked')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });

  it('shows "Tasting not found" for an unknown tasting', async () => {
    fetchMock.mockImplementation(async () => json({ message: 'Tasting not found' }, 404));

    renderBookingPage();

    await waitFor(() => expect(screen.getByText('Tasting not found')).toBeInTheDocument());
  });
});
