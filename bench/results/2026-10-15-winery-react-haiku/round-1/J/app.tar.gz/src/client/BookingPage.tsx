import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useNavigate, useParams } from 'react-router';
import { api, ApiError } from './api';
import { Field, inputClass } from './Field';
import { Layout } from './Layout';
import { bookingFormSchema, MAX_GUESTS, type BookingFormValues } from '../shared/bookingSchema';
import { formatEur, formatSeatsLeft, formatStartsAt } from '../shared/format';
import type { TastingSummary } from '../shared/types';

type LoadState =
  | { kind: 'loading' }
  | { kind: 'not_found' }
  | { kind: 'error' }
  | { kind: 'ready'; tasting: TastingSummary };

export function BookingPage() {
  const { slug = '' } = useParams();
  const [state, setState] = useState<LoadState>({ kind: 'loading' });

  const refreshTasting = () =>
    api
      .getTasting(slug)
      .then((tasting) => setState({ kind: 'ready', tasting }))
      .catch(() => undefined);

  useEffect(() => {
    let active = true;
    setState({ kind: 'loading' });
    api
      .getTasting(slug)
      .then((tasting) => active && setState({ kind: 'ready', tasting }))
      .catch((error: unknown) => {
        if (!active) return;
        const notFound = error instanceof ApiError && error.status === 404;
        setState({ kind: notFound ? 'not_found' : 'error' });
      });
    return () => {
      active = false;
    };
  }, [slug]);

  return (
    <Layout>
      {state.kind === 'loading' && <p className="text-oak">Loading…</p>}
      {state.kind === 'not_found' && <NotFound message="Tasting not found" />}
      {state.kind === 'error' && <NotFound message="We could not load this tasting. Please try again in a moment." />}
      {state.kind === 'ready' && (
        <BookingDetails key={state.tasting.slug} slug={slug} tasting={state.tasting} onConflict={refreshTasting} />
      )}
    </Layout>
  );
}

function BookingDetails({
  slug,
  tasting,
  onConflict,
}: {
  slug: string;
  tasting: TastingSummary;
  onConflict: () => Promise<void>;
}) {
  const navigate = useNavigate();
  const [rootError, setRootError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: { name: '', email: '' },
  });

  const onSubmit = async (values: BookingFormValues) => {
    setRootError(null);
    try {
      const confirmation = await api.createBooking(slug, values);
      navigate(`/bookings/${confirmation.reference}`);
    } catch (error) {
      if (!(error instanceof ApiError)) {
        setRootError('Something went wrong. Please try again.');
        return;
      }
      // Someone else may have taken seats or the tasting may have started: show the current state.
      if (error.status === 409) await onConflict();
      const fieldMessages = error.body.errors ?? {};
      const fields = Object.keys(fieldMessages) as (keyof BookingFormValues)[];
      if (fields.length === 0) {
        setRootError(error.body.message);
        return;
      }
      for (const field of fields) setError(field, { message: fieldMessages[field] });
    }
  };

  const bookable = tasting.status === 'open';

  return (
    <section aria-labelledby="booking-title" className="mx-auto max-w-xl">
      <Link to="/" className="text-sm font-medium text-oak underline-offset-4 hover:underline">
        Back to all tastings
      </Link>
      <h1 id="booking-title" className="mt-4 font-serif text-4xl text-wine">
        {tasting.title}
      </h1>
      <p className="mt-2 text-oak">
        {formatStartsAt(tasting.startsAt)} · {formatEur(tasting.pricePerGuest)} per guest
      </p>

      {!bookable && (
        <p role="status" className="mt-8 rounded-md bg-oak/10 p-4 font-medium text-oak">
          {tasting.status === 'started' ? 'This tasting has already started.' : 'This tasting is fully booked'}
        </p>
      )}

      {bookable && (
        <form
          noValidate
          onSubmit={handleSubmit(onSubmit)}
          className="mt-8 flex flex-col gap-5 rounded-lg border border-oak/25 bg-white p-6 shadow-sm"
        >
          <p className="text-sm text-ink/80">{formatSeatsLeft(tasting.seatsLeft)}</p>
          {rootError && (
            <p role="alert" className="rounded-md bg-red-50 p-3 text-sm font-medium text-red-800">
              {rootError}
            </p>
          )}
          <Field id="name" label="Name" error={errors.name?.message}>
            <input
              id="name"
              type="text"
              autoComplete="name"
              className={inputClass}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
              {...register('name')}
            />
          </Field>
          <Field id="email" label="Email" error={errors.email?.message}>
            <input
              id="email"
              type="email"
              autoComplete="email"
              className={inputClass}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
              {...register('email')}
            />
          </Field>
          <Field id="guests" label="Guests" hint={`1 to ${MAX_GUESTS} guests`} error={errors.guests?.message}>
            <input
              id="guests"
              type="number"
              inputMode="numeric"
              min={1}
              max={MAX_GUESTS}
              step={1}
              className={inputClass}
              aria-invalid={Boolean(errors.guests)}
              aria-describedby={['guests-hint', errors.guests && 'guests-error'].filter(Boolean).join(' ')}
              {...register('guests', { valueAsNumber: true })}
            />
          </Field>
          <button
            type="submit"
            disabled={isSubmitting}
            className="rounded-md bg-wine px-4 py-3 font-semibold text-cream hover:bg-wine-dark disabled:opacity-60"
          >
            Book
          </button>
        </form>
      )}
    </section>
  );
}

function NotFound({ message }: { message: string }) {
  return (
    <section className="mx-auto max-w-xl">
      <h1 className="font-serif text-3xl text-wine">Tasting</h1>
      <p role="alert" className="mt-6 rounded-md bg-red-50 p-4 text-red-800">
        {message}
      </p>
      <Link to="/" className="mt-6 inline-block text-oak underline-offset-4 hover:underline">
        Back to all tastings
      </Link>
    </section>
  );
}
