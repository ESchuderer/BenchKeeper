import { render, screen } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ConfirmationPage } from './ConfirmationPage';

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
}

function renderAt(reference: string) {
  return render(
    <MemoryRouter initialEntries={[`/bookings/${reference}`]}>
      <Routes>
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
      </Routes>
    </MemoryRouter>,
  );
}

describe('ConfirmationPage', () => {
  beforeEach(() => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        json({
          reference: 'ABCD2345',
          tasting: { slug: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00:00+01:00' },
          guests: 2,
          pricePerGuest: 25,
          total: 50,
        }),
      ),
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('confirms the booking with the tasting, guests, total and reference', async () => {
    renderAt('ABCD2345');

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument();
    expect(screen.getByText('2 guests')).toBeInTheDocument();
    expect(screen.getByText('EUR 50')).toBeInTheDocument();
    expect(screen.getByText('ABCD2345')).toBeInTheDocument();
  });

  it('says so when the booking reference is unknown', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => json({ message: 'Booking not found' }, 404)));

    renderAt('ZZZZZZZZ');

    expect(await screen.findByText('Booking not found')).toBeInTheDocument();
  });
});
