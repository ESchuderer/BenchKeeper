import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { api, ApiError } from './api';
import { Layout } from './Layout';
import { formatEur, formatStartsAt } from '../shared/format';
import type { BookingConfirmation } from '../shared/types';

type LoadState =
  | { kind: 'loading' }
  | { kind: 'not_found' }
  | { kind: 'error' }
  | { kind: 'ready'; booking: BookingConfirmation };

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const [state, setState] = useState<LoadState>({ kind: 'loading' });

  useEffect(() => {
    let active = true;
    api
      .getBooking(reference)
      .then((booking) => active && setState({ kind: 'ready', booking }))
      .catch((error: unknown) => {
        if (!active) return;
        const notFound = error instanceof ApiError && error.status === 404;
        setState({ kind: notFound ? 'not_found' : 'error' });
      });
    return () => {
      active = false;
    };
  }, [reference]);

  return (
    <Layout>
      {state.kind === 'loading' && <p className="text-oak">Loading…</p>}
      {state.kind === 'not_found' && (
        <p role="alert" className="rounded-md bg-red-50 p-4 text-red-800">
          Booking not found
        </p>
      )}
      {state.kind === 'error' && (
        <p role="alert" className="rounded-md bg-red-50 p-4 text-red-800">
          We could not load this booking. Please try again in a moment.
        </p>
      )}
      {state.kind === 'ready' && <Confirmation booking={state.booking} />}
    </Layout>
  );
}

function Confirmation({ booking }: { booking: BookingConfirmation }) {
  return (
    <section aria-labelledby="confirmation-title" className="mx-auto max-w-xl rounded-lg border border-oak/25 bg-white p-8 shadow-sm">
      <p className="text-sm font-semibold uppercase tracking-widest text-oak">Thank you</p>
      <h1 id="confirmation-title" className="mt-2 font-serif text-4xl text-wine">
        Booking confirmed
      </h1>
      <dl className="mt-8 grid grid-cols-[auto_1fr] gap-x-6 gap-y-4 text-ink">
        <dt className="font-semibold text-oak">Tasting</dt>
        <dd>{booking.tasting.title}</dd>
        <dt className="font-semibold text-oak">When</dt>
        <dd>{formatStartsAt(booking.tasting.startsAt)}</dd>
        <dt className="font-semibold text-oak">Guests</dt>
        <dd>{booking.guests === 1 ? '1 guest' : `${booking.guests} guests`}</dd>
        <dt className="font-semibold text-oak">Total</dt>
        <dd>{formatEur(booking.total)}</dd>
        <dt className="font-semibold text-oak">Booking reference</dt>
        <dd className="font-mono tracking-wider">{booking.reference}</dd>
      </dl>
      <p className="mt-8 text-sm text-oak">
        Please keep your booking reference.{' '}
        <Link to="/" className="font-medium underline-offset-4 hover:underline">
          Back to all tastings
        </Link>
      </p>
    </section>
  );
}
