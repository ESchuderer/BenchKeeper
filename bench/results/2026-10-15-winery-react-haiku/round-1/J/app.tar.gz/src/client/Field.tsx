import type { ReactNode } from 'react';

interface FieldProps {
  id: string;
  label: string;
  hint?: string;
  error?: string;
  children: ReactNode;
}

/** A labelled form field with its error message shown directly beneath the input. */
export function Field({ id, label, hint, error, children }: FieldProps) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-semibold text-ink">
        {label}
      </label>
      {hint && (
        <span id={`${id}-hint`} className="-mt-1 text-sm text-oak">
          {hint}
        </span>
      )}
      {children}
      {error && (
        <p id={`${id}-error`} role="alert" className="text-sm font-medium text-red-800">
          {error}
        </p>
      )}
    </div>
  );
}

export const inputClass =
  'w-full rounded-md border border-oak/40 bg-white px-3 py-2.5 text-ink shadow-sm focus:border-wine focus:outline-none focus:ring-2 focus:ring-wine/30 aria-[invalid=true]:border-red-700';
