import type { ReactNode } from 'react';
import { Link } from 'react-router';

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col bg-cream text-ink">
      <header className="border-b border-wine/20 bg-wine text-cream">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <Link to="/" className="font-serif text-xl tracking-wide">
            Weingut Kieselbrunnen
          </Link>
          <Link to="/staff" className="text-sm text-cream/80 hover:text-cream">
            Staff
          </Link>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-10">{children}</main>
      <footer className="border-t border-oak/30 py-6 text-center text-sm text-oak">
        Weingut Kieselbrunnen · Family winery · Wine tastings
      </footer>
    </div>
  );
}
