import { Link } from 'react-router';
import { Layout } from './Layout';

export function NotFoundPage() {
  return (
    <Layout>
      <section className="mx-auto max-w-xl">
        <h1 className="font-serif text-4xl text-wine">Page not found</h1>
        <p className="mt-4 text-oak">The page you are looking for does not exist.</p>
        <Link to="/" className="mt-6 inline-block font-medium text-wine underline-offset-4 hover:underline">
          Back to all tastings
        </Link>
      </section>
    </Layout>
  );
}
