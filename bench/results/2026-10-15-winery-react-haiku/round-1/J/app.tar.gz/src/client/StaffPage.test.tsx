import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { StaffPage } from './StaffPage';
import type { StaffBookingGroup } from '../shared/types';

const tastingSummary = (slug: string, title: string, seatsLeft: number) => ({
  slug,
  title,
  startsAt: '2026-11-06T18:00:00+01:00',
  pricePerGuest: 25,
  seats: 12,
  seatsLeft,
  status: 'open' as const,
});

const groups: StaffBookingGroup[] = [
  {
    tasting: tastingSummary('riesling-evening', 'Riesling Evening', 9),
    bookings: [
      { reference: 'ABCD2345', name: 'Anna Keller', email: 'anna@example.com', guests: 3, createdAt: '2026-10-14T12:00:00.000Z' },
    ],
  },
  { tasting: tastingSummary('winter-tasting', 'Winter Tasting', 10), bookings: [] },
];

interface Route {
  status?: number;
  body?: unknown;
}

/** Answers API calls by "METHOD path" and records every call. */
function mockApi(routes: Record<string, Route | (() => Route)>) {
  const calls: { key: string; body?: string }[] = [];
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    const key = `${init?.method ?? 'GET'} ${url}`;
    calls.push({ key, body: typeof init?.body === 'string' ? init.body : undefined });
    const route = routes[key];
    if (!route) throw new Error(`Unexpected request: ${key}`);
    const { status = 200, body } = typeof route === 'function' ? route() : route;
    if (status === 204) return new Response(null, { status });
    return new Response(JSON.stringify(body ?? {}), { status, headers: { 'Content-Type': 'application/json' } });
  });
  vi.stubGlobal('fetch', fetchMock);
  return calls;
}

function renderStaffPage() {
  return render(
    <MemoryRouter>
      <StaffPage />
    </MemoryRouter>,
  );
}

describe('StaffPage', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('says so when staff sign-in is not configured', async () => {
    mockApi({ 'GET /api/staff/session': { body: { configured: false, signedIn: false } } });

    renderStaffPage();

    expect(await screen.findByText('Staff sign-in is not configured')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Sign in' })).not.toBeInTheDocument();
  });

  it('asks for the password and shows "Incorrect password" for a wrong one', async () => {
    const user = userEvent.setup();
    mockApi({
      'GET /api/staff/session': { body: { configured: true, signedIn: false } },
      'POST /api/staff/session': { status: 401, body: { message: 'Incorrect password' } },
    });
    renderStaffPage();

    await user.type(await screen.findByLabelText('Password'), 'guess123');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByText('Incorrect password')).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Riesling Evening' })).not.toBeInTheDocument();
  });

  it('shows bookings grouped by tasting after a correct password', async () => {
    const user = userEvent.setup();
    mockApi({
      'GET /api/staff/session': { body: { configured: true, signedIn: false } },
      'POST /api/staff/session': { status: 204 },
      'GET /api/staff/bookings': { body: groups },
    });
    renderStaffPage();

    await user.type(await screen.findByLabelText('Password'), 'cellar-door-2026');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    const row = within(riesling).getByRole('row', { name: /Anna Keller/ });
    expect(within(row).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(row).getByText('3')).toBeInTheDocument();
    expect(within(row).getByText('ABCD2345')).toBeInTheDocument();
    expect(within(screen.getByRole('region', { name: 'Winter Tasting' })).getByText('No bookings yet')).toBeInTheDocument();
  });

  it('removes a booking when it is cancelled', async () => {
    const user = userEvent.setup();
    const current = { groups: structuredClone(groups) };
    mockApi({
      'GET /api/staff/session': { body: { configured: true, signedIn: true } },
      'GET /api/staff/bookings': () => ({ body: current.groups }),
      'DELETE /api/staff/bookings/ABCD2345': () => {
        current.groups[0].bookings = [];
        return { status: 204 };
      },
    });
    renderStaffPage();

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    await user.click(within(riesling).getByRole('button', { name: 'Cancel' }));

    expect(await within(riesling).findByText('No bookings yet')).toBeInTheDocument();
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
  });

  it('explains when the booking was already cancelled and refreshes the list', async () => {
    const user = userEvent.setup();
    mockApi({
      'GET /api/staff/session': { body: { configured: true, signedIn: true } },
      'GET /api/staff/bookings': { body: groups },
      'DELETE /api/staff/bookings/ABCD2345': { status: 404, body: { message: 'This booking no longer exists' } },
    });
    renderStaffPage();

    await user.click(await screen.findByRole('button', { name: 'Cancel' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('This booking no longer exists');
  });

  it('signs out and returns to the password form', async () => {
    const user = userEvent.setup();
    mockApi({
      'GET /api/staff/session': { body: { configured: true, signedIn: true } },
      'GET /api/staff/bookings': { body: groups },
      'DELETE /api/staff/session': { status: 204 },
    });
    renderStaffPage();

    await user.click(await screen.findByRole('button', { name: 'Sign out' }));

    expect(await screen.findByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });
});
