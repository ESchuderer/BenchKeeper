import { useEffect, useId, useState, type FormEvent } from 'react';
import { api, ApiError } from './api';
import { Field, inputClass } from './Field';
import { Layout } from './Layout';
import { formatStartsAt } from '../shared/format';
import type { StaffBookingGroup } from '../shared/types';

type View =
  | { kind: 'loading' }
  | { kind: 'error' }
  | { kind: 'not_configured' }
  | { kind: 'signed_out'; message?: string }
  | { kind: 'signed_in'; groups: StaffBookingGroup[]; notice?: string };

export function StaffPage() {
  const [view, setView] = useState<View>({ kind: 'loading' });

  const showOverview = async (notice?: string) => {
    try {
      const groups = await api.listStaffBookings();
      setView({ kind: 'signed_in', groups, notice });
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        setView({ kind: 'signed_out', message: 'Your session has ended. Please sign in again.' });
      } else {
        setView({ kind: 'error' });
      }
    }
  };

  useEffect(() => {
    let active = true;
    api
      .getStaffSession()
      .then(async (session) => {
        if (!active) return;
        if (!session.configured) return setView({ kind: 'not_configured' });
        if (session.signedIn) return showOverview();
        setView({ kind: 'signed_out' });
      })
      .catch(() => active && setView({ kind: 'error' }));
    return () => {
      active = false;
    };
  }, []);

  return (
    <Layout>
      <h1 className="font-serif text-4xl text-wine">Staff</h1>
      {view.kind === 'loading' && <p className="mt-6 text-oak">Loading…</p>}
      {view.kind === 'error' && (
        <p role="alert" className="mt-6 rounded-md bg-red-50 p-4 text-red-800">
          We could not load the staff area. Please try again in a moment.
        </p>
      )}
      {view.kind === 'not_configured' && (
        <p role="alert" className="mt-6 rounded-md bg-oak/10 p-4 font-medium text-oak">
          Staff sign-in is not configured
        </p>
      )}
      {view.kind === 'signed_out' && (
        <SignInForm message={view.message} onSignedIn={() => showOverview()} />
      )}
      {view.kind === 'signed_in' && (
        <Overview
          groups={view.groups}
          notice={view.notice}
          onChanged={(notice) => showOverview(notice)}
          onSignedOut={() => setView({ kind: 'signed_out' })}
          onSessionEnded={() =>
            setView({ kind: 'signed_out', message: 'Your session has ended. Please sign in again.' })
          }
        />
      )}
    </Layout>
  );
}

function SignInForm({ message, onSignedIn }: { message?: string; onSignedIn: () => void }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!password) {
      setError('Please enter the password');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await api.signIn(password);
      onSignedIn();
    } catch (caught) {
      setError(caught instanceof ApiError ? caught.body.message : 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section aria-labelledby="sign-in-title" className="mt-6 max-w-sm">
      <h2 id="sign-in-title" className="sr-only">
        Sign in
      </h2>
      {message && <p className="mb-4 text-sm text-oak">{message}</p>}
      <form noValidate onSubmit={submit} className="flex flex-col gap-5 rounded-lg border border-oak/25 bg-white p-6 shadow-sm">
        <Field id="password" label="Password" error={error ?? undefined}>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className={inputClass}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            aria-invalid={Boolean(error)}
            aria-describedby={error ? 'password-error' : undefined}
          />
        </Field>
        <button
          type="submit"
          disabled={submitting}
          className="rounded-md bg-wine px-4 py-3 font-semibold text-cream hover:bg-wine-dark disabled:opacity-60"
        >
          Sign in
        </button>
      </form>
    </section>
  );
}

function Overview({
  groups,
  notice,
  onChanged,
  onSignedOut,
  onSessionEnded,
}: {
  groups: StaffBookingGroup[];
  notice?: string;
  onChanged: (notice?: string) => void;
  onSignedOut: () => void;
  onSessionEnded: () => void;
}) {
  const signOut = async () => {
    await api.signOut().catch(() => undefined);
    onSignedOut();
  };

  const cancel = async (reference: string) => {
    try {
      await api.cancelBooking(reference);
      onChanged('Booking cancelled. Its seats are free again.');
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) return onSessionEnded();
      onChanged(error instanceof ApiError ? error.body.message : 'Something went wrong. Please try again.');
    }
  };

  return (
    <div className="mt-6 flex flex-col gap-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="text-oak">Bookings by tasting</p>
        <button
          type="button"
          onClick={signOut}
          className="rounded-md border border-wine px-4 py-2 text-sm font-semibold text-wine hover:bg-wine hover:text-cream"
        >
          Sign out
        </button>
      </div>
      {notice && (
        <p role="alert" className="rounded-md bg-oak/10 p-4 font-medium text-ink">
          {notice}
        </p>
      )}
      {groups.map((group) => (
        <TastingGroup key={group.tasting.slug} group={group} onCancel={cancel} />
      ))}
    </div>
  );
}

function TastingGroup({ group, onCancel }: { group: StaffBookingGroup; onCancel: (reference: string) => void }) {
  const headingId = useId();
  const { tasting, bookings } = group;
  const guests = tasting.seats - tasting.seatsLeft;

  return (
    <section aria-labelledby={headingId} className="rounded-lg border border-oak/25 bg-white p-6 shadow-sm">
      <h2 id={headingId} className="font-serif text-2xl text-wine">
        {tasting.title}
      </h2>
      <p className="mt-1 text-sm text-oak">
        {formatStartsAt(tasting.startsAt)} · {guests} of {tasting.seats} seats booked
      </p>
      {bookings.length === 0 ? (
        <p className="mt-4 text-ink/70">No bookings yet</p>
      ) : (
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[32rem] text-left text-sm">
            <thead className="border-b border-oak/30 text-oak">
              <tr>
                <th scope="col" className="py-2 pr-4 font-semibold">Name</th>
                <th scope="col" className="py-2 pr-4 font-semibold">Email</th>
                <th scope="col" className="py-2 pr-4 font-semibold">Guests</th>
                <th scope="col" className="py-2 pr-4 font-semibold">Reference</th>
                <th scope="col" className="py-2 font-semibold">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr key={booking.reference} className="border-b border-oak/15">
                  <td className="py-3 pr-4">{booking.name}</td>
                  <td className="py-3 pr-4">{booking.email}</td>
                  <td className="py-3 pr-4">{booking.guests}</td>
                  <td className="py-3 pr-4 font-mono tracking-wider">{booking.reference}</td>
                  <td className="py-3 text-right">
                    <button
                      type="button"
                      onClick={() => onCancel(booking.reference)}
                      className="rounded-md px-3 py-1.5 font-semibold text-red-800 hover:bg-red-50"
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
