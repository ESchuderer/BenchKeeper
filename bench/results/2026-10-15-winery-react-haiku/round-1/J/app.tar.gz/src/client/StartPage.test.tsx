import { render, screen, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { StartPage } from './StartPage';
import type { TastingSummary } from '../shared/types';

const tastings: TastingSummary[] = [
  {
    slug: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06T18:00:00+01:00',
    pricePerGuest: 25,
    seats: 12,
    seatsLeft: 12,
    status: 'open',
  },
  {
    slug: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    startsAt: '2026-11-14T15:00:00+01:00',
    pricePerGuest: 32,
    seats: 8,
    seatsLeft: 0,
    status: 'fully_booked',
  },
  {
    slug: 'winter-tasting',
    title: 'Winter Tasting',
    startsAt: '2026-12-05T17:00:00+01:00',
    pricePerGuest: 28,
    seats: 10,
    seatsLeft: 4,
    status: 'open',
  },
];

function renderStartPage() {
  return render(
    <MemoryRouter>
      <StartPage />
    </MemoryRouter>,
  );
}

function cardFor(title: string): HTMLElement {
  return screen.getByRole('heading', { name: title }).closest('article') as HTMLElement;
}

describe('StartPage', () => {
  beforeEach(() => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(JSON.stringify(tastings), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        }),
      ),
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('lists each tasting with its date and time, price per guest and seats left', async () => {
    renderStartPage();

    const card = await screen.findByRole('heading', { name: 'Riesling Evening' });
    const article = card.closest('article') as HTMLElement;
    expect(within(article).getByText('Fri 6 Nov 2026, 18:00')).toBeInTheDocument();
    expect(within(article).getByText('EUR 25 per guest')).toBeInTheDocument();
    expect(within(article).getByText('12 seats left')).toBeInTheDocument();
    expect(cardFor('Winter Tasting')).toHaveTextContent('4 seats left');
  });

  it('offers a "Book <title>" link for tastings with seats left', async () => {
    renderStartPage();

    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link).toHaveAttribute('href', '/tastings/riesling-evening/book');
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toHaveAttribute(
      'href',
      '/tastings/winter-tasting/book',
    );
  });

  it('marks a fully booked tasting and offers no booking action for it', async () => {
    renderStartPage();

    await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' });
    expect(within(cardFor('Red Wine Cellar Tour')).getByText('Fully booked')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).not.toBeInTheDocument();
  });

  it('uses the singular for a single seat left', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify([{ ...tastings[2], seatsLeft: 1 }]), { status: 200, headers: { 'Content-Type': 'application/json' } })));

    renderStartPage();

    expect(await screen.findByText('1 seat left')).toBeInTheDocument();
  });

  it('shows an error when the tastings cannot be loaded', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{}', { status: 500 })));

    renderStartPage();

    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load the tastings/i);
  });
});
