import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { api } from './api';
import { Layout } from './Layout';
import { formatEur, formatSeatsLeft, formatStartsAt } from '../shared/format';
import type { TastingSummary } from '../shared/types';

type LoadState =
  | { kind: 'loading' }
  | { kind: 'error' }
  | { kind: 'ready'; tastings: TastingSummary[] };

export function StartPage() {
  const [state, setState] = useState<LoadState>({ kind: 'loading' });

  useEffect(() => {
    let active = true;
    api
      .listTastings()
      .then((tastings) => active && setState({ kind: 'ready', tastings }))
      .catch(() => active && setState({ kind: 'error' }));
    return () => {
      active = false;
    };
  }, []);

  return (
    <Layout>
      <section aria-labelledby="page-title">
        <h1 id="page-title" className="font-serif text-4xl text-wine">
          Wine tastings
        </h1>
        <p className="mt-3 max-w-2xl text-oak">
          Choose a tasting, reserve your seats and we will see you at the cellar door.
        </p>

        {state.kind === 'loading' && <p className="mt-10 text-oak">Loading tastings…</p>}
        {state.kind === 'error' && (
          <p role="alert" className="mt-10 rounded-md bg-red-50 p-4 text-red-800">
            We could not load the tastings. Please try again in a moment.
          </p>
        )}
        {state.kind === 'ready' && (
          <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {state.tastings.map((tasting) => (
              <li key={tasting.slug}>
                <TastingCard tasting={tasting} />
              </li>
            ))}
          </ul>
        )}
      </section>
    </Layout>
  );
}

function TastingCard({ tasting }: { tasting: TastingSummary }) {
  const titleId = `${tasting.slug}-title`;
  return (
    <article aria-labelledby={titleId} className="flex h-full flex-col rounded-lg border border-oak/25 bg-white p-6 shadow-sm">
      <h2 id={titleId} className="font-serif text-2xl text-wine">
        {tasting.title}
      </h2>
      <p className="mt-2 text-sm font-medium text-oak">{formatStartsAt(tasting.startsAt)}</p>
      <p className="mt-1 text-sm text-ink/80">{formatEur(tasting.pricePerGuest)} per guest</p>
      <p className="mt-4">
        {tasting.status === 'fully_booked' ? (
          <span className="inline-block rounded-full bg-oak/15 px-3 py-1 text-sm font-semibold text-oak">
            Fully booked
          </span>
        ) : (
          <span className="text-sm text-ink/80">{formatSeatsLeft(tasting.seatsLeft)}</span>
        )}
      </p>
      <div className="mt-auto pt-6">
        {tasting.status === 'open' && (
          <Link
            to={`/tastings/${tasting.slug}/book`}
            className="inline-flex w-full items-center justify-center rounded-md bg-wine px-4 py-2.5 font-semibold text-cream hover:bg-wine-dark"
          >
            Book {tasting.title}
          </Link>
        )}
        {tasting.status === 'started' && <p className="text-sm text-oak">This tasting has started.</p>}
      </div>
    </article>
  );
}
