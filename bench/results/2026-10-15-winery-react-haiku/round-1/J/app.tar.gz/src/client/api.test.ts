import { afterEach, describe, expect, it, vi } from 'vitest';
import { api } from './api';

describe('api', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('reports a successful response that is not JSON as an error', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('<html>oops</html>', { status: 200 })));

    await expect(api.getTasting('riesling-evening')).rejects.toMatchObject({ name: 'ApiError', status: 200 });
  });
});
