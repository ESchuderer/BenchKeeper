import type {
  ApiErrorBody,
  BookingConfirmation,
  StaffBookingGroup,
  TastingSummary,
} from '../shared/types';

export class ApiError extends Error {
  readonly status: number;
  readonly body: ApiErrorBody;

  constructor(status: number, body: ApiErrorBody) {
    super(body.message);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

async function request<T>(url: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(url, {
    ...init,
    headers: {
      Accept: 'application/json',
      ...(init.body ? { 'Content-Type': 'application/json' } : {}),
    },
  });
  if (response.status === 204) return undefined as T;
  const body: unknown = await response.json().catch(() => null);
  if (body === null) {
    throw new ApiError(response.status, { message: 'Unexpected response from the server' });
  }
  if (!response.ok) throw new ApiError(response.status, body as ApiErrorBody);
  return body as T;
}

export interface BookingInput {
  name: string;
  email: string;
  guests: number;
}

export interface StaffSession {
  configured: boolean;
  signedIn: boolean;
}

export const api = {
  listTastings: () => request<TastingSummary[]>('/api/tastings'),
  getTasting: (slug: string) => request<TastingSummary>(`/api/tastings/${encodeURIComponent(slug)}`),
  createBooking: (slug: string, input: BookingInput) =>
    request<BookingConfirmation>(`/api/tastings/${encodeURIComponent(slug)}/bookings`, {
      method: 'POST',
      body: JSON.stringify(input),
    }),
  getBooking: (reference: string) =>
    request<BookingConfirmation>(`/api/bookings/${encodeURIComponent(reference)}`),
  getStaffSession: () => request<StaffSession>('/api/staff/session'),
  signIn: (password: string) =>
    request<void>('/api/staff/session', { method: 'POST', body: JSON.stringify({ password }) }),
  signOut: () => request<void>('/api/staff/session', { method: 'DELETE' }),
  listStaffBookings: () => request<StaffBookingGroup[]>('/api/staff/bookings'),
  cancelBooking: (reference: string) =>
    request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' }),
};
