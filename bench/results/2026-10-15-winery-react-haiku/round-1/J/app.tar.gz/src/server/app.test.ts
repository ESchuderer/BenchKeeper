import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from './app.js';
import { BookingStore } from './bookingStore.js';

const now = () => new Date('2026-10-14T12:00:00Z');

describe('GET /api/tastings', () => {
  it('lists the tastings in chronological order with seats left', async () => {
    const app = createApp({ store: new BookingStore({ now }) });

    const res = await request(app).get('/api/tastings').expect(200);

    expect(res.body.map((t: { slug: string }) => t.slug)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(res.body[0]).toEqual({
      slug: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00:00+01:00',
      pricePerGuest: 25,
      seats: 12,
      seatsLeft: 12,
      status: 'open',
    });
  });

  it('reports a fully booked tasting with zero seats left', async () => {
    const app = createApp({
      store: new BookingStore({
        now,
        bookings: [
          {
            reference: 'AAAAAAAA',
            tastingSlug: 'red-wine-cellar-tour',
            name: 'Ben',
            email: 'ben@example.com',
            guests: 8,
            createdAt: '2026-10-14T12:00:00.000Z',
          },
        ],
      }),
    });

    const res = await request(app).get('/api/tastings').expect(200);

    expect(res.body[1]).toMatchObject({ slug: 'red-wine-cellar-tour', seatsLeft: 0, status: 'fully_booked' });
  });
});

const validBooking = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function appWith(options: { now?: () => Date } = {}) {
  return createApp({ store: new BookingStore({ now: options.now ?? now }) });
}

describe('POST /api/tastings/:slug/bookings', () => {
  it('creates a booking and returns the confirmation with a reference', async () => {
    const app = appWith();

    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(validBooking).expect(201);

    expect(res.body).toMatchObject({
      reference: expect.stringMatching(/^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/),
      tasting: { slug: 'riesling-evening', title: 'Riesling Evening' },
      guests: 2,
      pricePerGuest: 25,
      total: 50,
    });
    const tastings = await request(app).get('/api/tastings');
    expect(tastings.body[0].seatsLeft).toBe(10);
  });

  it('returns field errors next to each invalid field', async () => {
    const app = appWith();

    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: '', email: 'anna@example', guests: 9 })
      .expect(400);

    expect(res.body.errors).toEqual({
      name: 'Please enter your name',
      email: 'Please enter a valid email address',
      guests: 'Please choose between 1 and 8 guests',
    });
  });

  it('rejects a booking above the seats left with the seats left on the Guests field', async () => {
    const app = appWith();
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...validBooking, guests: 8 }).expect(201);

    const res = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ ...validBooking, guests: 4 })
      .expect(409);

    expect(res.body).toMatchObject({
      errors: { guests: 'Only 2 seats left for this tasting' },
      seatsLeft: 2,
    });
  });

  it('rejects a booking for a fully booked tasting', async () => {
    const app = appWith();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...validBooking, guests: 8 }).expect(201);

    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send(validBooking)
      .expect(409);

    expect(res.body).toMatchObject({ message: 'This tasting is fully booked', seatsLeft: 0 });
  });

  it('rejects a booking after the tasting has started', async () => {
    const app = appWith({ now: () => new Date('2026-11-06T18:30:00+01:00') });

    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send(validBooking)
      .expect(409);

    expect(res.body.message).toBe('This tasting has already started');
  });

  it('returns 404 for an unknown tasting', async () => {
    const res = await request(appWith()).post('/api/tastings/nope/bookings').send(validBooking).expect(404);

    expect(res.body.message).toBe('Tasting not found');
  });

  it('confirms exactly one of two simultaneous requests for the last seats', async () => {
    const app = appWith();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...validBooking, guests: 6 }).expect(201);

    const responses = await Promise.all([
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...validBooking, guests: 2 }),
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...validBooking, guests: 2, name: 'Ben' }),
    ]);

    expect(responses.map((r) => r.status).sort()).toEqual([201, 409]);
  });

  it('rejects a body that is not valid JSON', async () => {
    const res = await request(appWith())
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{ nope')
      .expect(400);

    expect(res.body.message).toBe('Invalid request body');
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the confirmation without the guest name or email', async () => {
    const app = appWith();
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send(validBooking).expect(201);

    const res = await request(app).get(`/api/bookings/${created.body.reference}`).expect(200);

    expect(res.body).toEqual({
      reference: created.body.reference,
      tasting: { slug: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00:00+01:00' },
      guests: 2,
      pricePerGuest: 28,
      total: 56,
    });
    expect(res.body).not.toHaveProperty('name');
    expect(res.body).not.toHaveProperty('email');
  });

  it('returns 404 for an unknown reference', async () => {
    const res = await request(appWith()).get('/api/bookings/ZZZZZZZZ').expect(404);

    expect(res.body.message).toBe('Booking not found');
  });
});

describe('GET /api/tastings/:slug', () => {
  it('returns one tasting with its seats left', async () => {
    const res = await request(appWith()).get('/api/tastings/winter-tasting').expect(200);

    expect(res.body).toMatchObject({ slug: 'winter-tasting', title: 'Winter Tasting', seatsLeft: 10, status: 'open' });
  });

  it('returns 404 for an unknown tasting', async () => {
    const res = await request(appWith()).get('/api/tastings/nope').expect(404);

    expect(res.body.message).toBe('Tasting not found');
  });
});

describe('request limits and headers', () => {
  it('answers an oversized body with 413', async () => {
    const res = await request(appWith())
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: 'x'.repeat(20000), email: 'anna@example.com', guests: 1 })
      .expect(413);

    expect(res.body.message).toBe('Request is too large');
  });

  it('sends basic security headers', async () => {
    const res = await request(appWith()).get('/api/tastings').expect(200);

    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });
});
