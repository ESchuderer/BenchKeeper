import cookieParser from 'cookie-parser';
import express from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import path from 'node:path';
import type { ZodError } from 'zod';
import { bookingFormSchema } from '../shared/bookingSchema.js';
import { formatSeatsLeft } from '../shared/format.js';
import type { ApiErrorBody } from '../shared/types.js';
import { BookingStore, type BookingFailure } from './bookingStore.js';
import { passwordMatches, STAFF_COOKIE, SESSION_TTL_MS, StaffSessions } from './staffAuth.js';

export interface AppOptions {
  store?: BookingStore;
  /** Password for staff sign-in. Without it, staff sign-in reports that it is not configured. */
  staffPassword?: string;
  /** Number of reverse proxies in front of the app whose X-Forwarded-* headers are trusted. */
  trustProxy?: number;
  /** File that keeps staff sessions across restarts. Sessions are kept in memory when not set. */
  sessionsFile?: string;
  /** Directory with the built client. When set, it is served with a fallback to index.html for client routes. */
  clientDir?: string;
}

export function createApp(options: AppOptions = {}): express.Express {
  const store = options.store ?? new BookingStore();
  const staffPassword = options.staffPassword || undefined;
  const sessions = new StaffSessions({ filePath: options.sessionsFile });
  const app = express();

  app.set('trust proxy', options.trustProxy ?? 0);
  app.use(helmet());
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  const requireStaff = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (sessions.isValid(req.cookies?.[STAFF_COOKIE])) {
      next();
      return;
    }
    res.status(401).json({ message: 'Please sign in to see the bookings' } satisfies ApiErrorBody);
  };

  const signInLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 10,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { message: 'Too many sign-in attempts. Try again in 15 minutes.' } satisfies ApiErrorBody,
  });

  app.get('/api/tastings', (_req, res) => {
    res.json(store.listTastings());
  });

  app.get('/api/tastings/:slug', (req, res) => {
    const tasting = store.getTasting(req.params.slug);
    if (!tasting) {
      res.status(404).json({ message: 'Tasting not found' } satisfies ApiErrorBody);
      return;
    }
    res.json(tasting);
  });

  app.post('/api/tastings/:slug/bookings', (req, res) => {
    const slug = req.params.slug;
    if (!store.getTasting(slug)) {
      res.status(404).json({ message: 'Tasting not found' } satisfies ApiErrorBody);
      return;
    }

    const parsed = bookingFormSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({
        message: 'Please check the highlighted fields',
        errors: fieldErrors(parsed.error),
      } satisfies ApiErrorBody);
      return;
    }

    const result = store.createBooking({ tastingSlug: slug, ...parsed.data });
    if (!result.ok) {
      sendFailure(res, result.failure);
      return;
    }
    res.status(201).json(store.getBookingConfirmation(result.booking.reference));
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const confirmation = store.getBookingConfirmation(req.params.reference);
    if (!confirmation) {
      res.status(404).json({ message: 'Booking not found' } satisfies ApiErrorBody);
      return;
    }
    res.json(confirmation);
  });

  app.get('/api/staff/session', (req, res) => {
    res.json({ configured: Boolean(staffPassword), signedIn: sessions.isValid(req.cookies?.[STAFF_COOKIE]) });
  });

  app.post('/api/staff/session', signInLimiter, (req, res) => {
    if (!staffPassword) {
      res.status(503).json({ message: 'Staff sign-in is not configured' } satisfies ApiErrorBody);
      return;
    }
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!passwordMatches(password, staffPassword)) {
      res.status(401).json({ message: 'Incorrect password' } satisfies ApiErrorBody);
      return;
    }
    res.cookie(STAFF_COOKIE, sessions.create(), {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure,
      path: '/',
      maxAge: SESSION_TTL_MS,
    });
    res.status(204).end();
  });

  app.delete('/api/staff/session', (req, res) => {
    sessions.revoke(req.cookies?.[STAFF_COOKIE]);
    res.clearCookie(STAFF_COOKIE, { httpOnly: true, sameSite: 'strict', secure: req.secure, path: '/' });
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    res.json(store.listBookingsByTasting());
  });

  app.delete<'/api/staff/bookings/:reference'>('/api/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancelBooking(req.params.reference)) {
      res.status(404).json({ message: 'This booking no longer exists' } satisfies ApiErrorBody);
      return;
    }
    res.status(204).end();
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ message: 'Not found' } satisfies ApiErrorBody);
  });

  if (options.clientDir) {
    const indexFile = path.join(options.clientDir, 'index.html');
    app.use(express.static(options.clientDir));
    // Client routes such as /staff get the app shell; a missing file such as /assets/x.js stays a 404.
    app.get('/{*splat}', (req, res, next) => {
      if (path.extname(req.path)) {
        next();
        return;
      }
      res.sendFile(indexFile);
    });
  }

  app.use(
    (error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
      if (isJsonSyntaxError(error)) {
        res.status(400).json({ message: 'Invalid request body' } satisfies ApiErrorBody);
        return;
      }
      if (isBodyTooLarge(error)) {
        res.status(413).json({ message: 'Request is too large' } satisfies ApiErrorBody);
        return;
      }
      console.error(error);
      res.status(500).json({ message: 'Something went wrong. Please try again.' } satisfies ApiErrorBody);
    },
  );

  return app;
}

function fieldErrors(error: ZodError): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0]);
    errors[field] ??= issue.message;
  }
  return errors;
}

function sendFailure(res: express.Response, failure: BookingFailure): void {
  switch (failure.kind) {
    case 'not_found':
      res.status(404).json({ message: 'Tasting not found' } satisfies ApiErrorBody);
      return;
    case 'started':
      res.status(409).json({ message: 'This tasting has already started' } satisfies ApiErrorBody);
      return;
    case 'fully_booked':
      res.status(409).json({ message: 'This tasting is fully booked', seatsLeft: 0 } satisfies ApiErrorBody);
      return;
    case 'not_enough_seats':
      res.status(409).json({
        message: 'Not enough seats left for this tasting',
        errors: { guests: `Only ${formatSeatsLeft(failure.seatsLeft)} for this tasting` },
        seatsLeft: failure.seatsLeft,
      } satisfies ApiErrorBody);
      return;
  }
}

function isJsonSyntaxError(error: unknown): boolean {
  return error instanceof Error && 'type' in error && error.type === 'entity.parse.failed';
}

function isBodyTooLarge(error: unknown): boolean {
  return error instanceof Error && 'type' in error && error.type === 'entity.too.large';
}
