import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { writeFileAtomic } from './atomicFile.js';

describe('writeFileAtomic', () => {
  let dir: string;

  beforeEach(() => {
    dir = fs.mkdtempSync(path.join(os.tmpdir(), 'atomic-'));
  });

  afterEach(() => {
    fs.rmSync(dir, { recursive: true, force: true });
  });

  it('writes the content and replaces an existing file', () => {
    const file = path.join(dir, 'data.json');
    fs.writeFileSync(file, 'old');

    writeFileAtomic(file, 'new');

    expect(fs.readFileSync(file, 'utf8')).toBe('new');
    expect(fs.readdirSync(dir)).toEqual(['data.json']);
  });

  it('creates missing parent folders', () => {
    const file = path.join(dir, 'nested', 'data.json');

    writeFileAtomic(file, '{}');

    expect(fs.readFileSync(file, 'utf8')).toBe('{}');
  });
});
