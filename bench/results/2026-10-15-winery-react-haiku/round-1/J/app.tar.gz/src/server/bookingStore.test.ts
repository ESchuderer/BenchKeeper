import { describe, expect, it } from 'vitest';
import { BookingStore, type StoredBooking } from './bookingStore.js';

const beforeAnyTasting = () => new Date('2026-10-14T12:00:00Z');

function booking(overrides: Partial<StoredBooking>): StoredBooking {
  return {
    reference: 'AAAAAAAA',
    tastingSlug: 'riesling-evening',
    name: 'Anna Keller',
    email: 'anna@example.com',
    guests: 1,
    createdAt: '2026-10-14T12:00:00.000Z',
    ...overrides,
  };
}

describe('BookingStore reads', () => {
  it('lists every tasting in order with all seats left when there are no bookings', () => {
    const store = new BookingStore({ now: beforeAnyTasting });

    expect(store.listTastings().map((t) => [t.slug, t.seatsLeft, t.status])).toEqual([
      ['riesling-evening', 12, 'open'],
      ['red-wine-cellar-tour', 8, 'open'],
      ['winter-tasting', 10, 'open'],
    ]);
  });

  it('subtracts the guests of each booking from the seats left', () => {
    const store = new BookingStore({
      now: beforeAnyTasting,
      bookings: [
        booking({ guests: 3 }),
        booking({ reference: 'BBBBBBBB', tastingSlug: 'winter-tasting', guests: 2 }),
      ],
    });

    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(9);
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(8);
  });

  it('marks a tasting with no seats left as fully booked', () => {
    const store = new BookingStore({
      now: beforeAnyTasting,
      bookings: [booking({ tastingSlug: 'red-wine-cellar-tour', guests: 8 })],
    });

    expect(store.getTasting('red-wine-cellar-tour')).toMatchObject({
      seatsLeft: 0,
      status: 'fully_booked',
    });
  });

  it('marks a tasting as started once its start time has passed', () => {
    const store = new BookingStore({ now: () => new Date('2026-11-06T17:30:00Z') });

    expect(store.getTasting('riesling-evening')?.status).toBe('started');
    expect(store.getTasting('winter-tasting')?.status).toBe('open');
  });

  it('returns undefined for an unknown tasting', () => {
    const store = new BookingStore({ now: beforeAnyTasting });

    expect(store.getTasting('no-such-tasting')).toBeUndefined();
  });
});

describe('BookingStore staff reads and cancellation', () => {
  it('groups bookings by tasting in chronological order, including empty groups', () => {
    const store = new BookingStore({
      now: beforeAnyTasting,
      bookings: [
        booking({ reference: 'CCCCCCCC', tastingSlug: 'winter-tasting', name: 'Winter Guest', guests: 2 }),
        booking({ reference: 'DDDDDDDD', tastingSlug: 'riesling-evening', name: 'Riesling Guest', guests: 1 }),
      ],
    });

    const groups = store.listBookingsByTasting();

    expect(groups.map((group) => group.tasting.slug)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(groups[0].bookings.map((b) => b.reference)).toEqual(['DDDDDDDD']);
    expect(groups[1].bookings).toEqual([]);
    expect(groups[2].bookings[0]).toMatchObject({ name: 'Winter Guest', guests: 2, reference: 'CCCCCCCC' });
  });

  it('cancels a booking, frees its seats, and reports unknown references', () => {
    const store = new BookingStore({
      now: beforeAnyTasting,
      bookings: [booking({ reference: 'EEEEEEEE', tastingSlug: 'red-wine-cellar-tour', guests: 2 })],
    });

    expect(store.cancelBooking('EEEEEEEE')).toBe(true);
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(8);
    expect(store.cancelBooking('EEEEEEEE')).toBe(false);
  });

  it('returns confirmation details without the guest name or email', () => {
    const store = new BookingStore({
      now: beforeAnyTasting,
      bookings: [booking({ reference: 'FFFFFFFF', tastingSlug: 'winter-tasting', guests: 3 })],
    });

    expect(store.getBookingConfirmation('FFFFFFFF')).toEqual({
      reference: 'FFFFFFFF',
      tasting: { slug: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00:00+01:00' },
      guests: 3,
      pricePerGuest: 28,
      total: 84,
    });
    expect(store.getBookingConfirmation('ZZZZZZZZ')).toBeUndefined();
  });
});
