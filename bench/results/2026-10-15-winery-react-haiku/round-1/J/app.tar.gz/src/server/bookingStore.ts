import crypto from 'node:crypto';
import fs from 'node:fs';
import { z } from 'zod';
import { writeFileAtomic } from './atomicFile.js';
import { findTasting, TASTINGS, type TastingDefinition } from './tastings.js';
import type {
  BookingConfirmation,
  StaffBookingGroup,
  TastingStatus,
  TastingSummary,
} from '../shared/types.js';

export interface StoredBooking {
  reference: string;
  tastingSlug: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface NewBooking {
  tastingSlug: string;
  name: string;
  email: string;
  guests: number;
}

export type BookingFailure =
  | { kind: 'not_found' }
  | { kind: 'started' }
  | { kind: 'fully_booked' }
  | { kind: 'not_enough_seats'; seatsLeft: number };

export type CreateBookingResult =
  | { ok: true; booking: StoredBooking }
  | { ok: false; failure: BookingFailure };

export interface BookingStoreOptions {
  now?: () => Date;
  /** Bookings held in memory when no file is given. Ignored when `filePath` is set. */
  bookings?: StoredBooking[];
  /** JSON file that keeps the bookings between restarts. Created on first write. */
  filePath?: string;
}

// Letters and digits without the easily confused I, O, 0 and 1.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const REFERENCE_LENGTH = 8;

const storedBookingSchema = z.object({
  reference: z.string(),
  tastingSlug: z.string(),
  name: z.string(),
  email: z.string(),
  guests: z.number().int(),
  createdAt: z.string(),
});
const storeFileSchema = z.object({
  version: z.literal(1),
  bookings: z.array(storedBookingSchema),
});

export class BookingStore {
  private readonly bookings: StoredBooking[];
  private readonly now: () => Date;
  private readonly filePath: string | undefined;

  constructor(options: BookingStoreOptions = {}) {
    this.now = options.now ?? (() => new Date());
    this.filePath = options.filePath;
    this.bookings = options.filePath ? loadFile(options.filePath) : [...(options.bookings ?? [])];
  }

  listTastings(): TastingSummary[] {
    return TASTINGS.map((definition) => this.summarize(definition));
  }

  getTasting(slug: string): TastingSummary | undefined {
    const definition = findTasting(slug);
    return definition && this.summarize(definition);
  }

  createBooking(input: NewBooking): CreateBookingResult {
    const tasting = this.getTasting(input.tastingSlug);
    if (!tasting) return { ok: false, failure: { kind: 'not_found' } };
    if (tasting.status === 'started') return { ok: false, failure: { kind: 'started' } };
    if (tasting.seatsLeft === 0) return { ok: false, failure: { kind: 'fully_booked' } };
    if (input.guests > tasting.seatsLeft) {
      return { ok: false, failure: { kind: 'not_enough_seats', seatsLeft: tasting.seatsLeft } };
    }

    const booking: StoredBooking = {
      reference: this.newReference(),
      tastingSlug: input.tastingSlug,
      name: input.name,
      email: input.email,
      guests: input.guests,
      createdAt: this.now().toISOString(),
    };
    this.bookings.push(booking);
    try {
      this.save();
    } catch (error) {
      this.bookings.pop();
      throw error;
    }
    return { ok: true, booking };
  }

  getBookingConfirmation(reference: string): BookingConfirmation | undefined {
    const booking = this.bookings.find((candidate) => candidate.reference === reference);
    const definition = booking && findTasting(booking.tastingSlug);
    if (!booking || !definition) return undefined;
    return {
      reference: booking.reference,
      tasting: { slug: definition.slug, title: definition.title, startsAt: definition.startsAt },
      guests: booking.guests,
      pricePerGuest: definition.pricePerGuest,
      total: booking.guests * definition.pricePerGuest,
    };
  }

  listBookingsByTasting(): StaffBookingGroup[] {
    return this.listTastings().map((tasting) => ({
      tasting,
      bookings: this.bookings
        .filter((booking) => booking.tastingSlug === tasting.slug)
        .map(({ reference, name, email, guests, createdAt }) => ({ reference, name, email, guests, createdAt })),
    }));
  }

  /** Removes a booking, which frees its seats. Returns false when no booking has the reference. */
  cancelBooking(reference: string): boolean {
    const index = this.bookings.findIndex((booking) => booking.reference === reference);
    if (index === -1) return false;
    const [removed] = this.bookings.splice(index, 1);
    try {
      this.save();
    } catch (error) {
      this.bookings.splice(index, 0, removed);
      throw error;
    }
    return true;
  }

  private summarize(definition: TastingDefinition): TastingSummary {
    const guests = this.bookings
      .filter((booking) => booking.tastingSlug === definition.slug)
      .reduce((total, booking) => total + booking.guests, 0);
    const seatsLeft = definition.seats - guests;
    return { ...definition, seatsLeft, status: statusOf(definition, seatsLeft, this.now()) };
  }

  private newReference(): string {
    for (;;) {
      let reference = '';
      for (let i = 0; i < REFERENCE_LENGTH; i += 1) {
        reference += REFERENCE_ALPHABET[crypto.randomInt(REFERENCE_ALPHABET.length)];
      }
      if (!this.bookings.some((booking) => booking.reference === reference)) return reference;
    }
  }

  private save(): void {
    if (!this.filePath) return;
    writeFileAtomic(this.filePath, JSON.stringify({ version: 1, bookings: this.bookings }, null, 2));
  }
}

function statusOf(definition: TastingDefinition, seatsLeft: number, now: Date): TastingStatus {
  if (now.getTime() >= Date.parse(definition.startsAt)) return 'started';
  if (seatsLeft === 0) return 'fully_booked';
  return 'open';
}

function loadFile(filePath: string): StoredBooking[] {
  if (!fs.existsSync(filePath)) return [];
  try {
    return storeFileSchema.parse(JSON.parse(fs.readFileSync(filePath, 'utf8'))).bookings;
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    throw new Error(`Could not read bookings file ${filePath}: ${reason}. Fix or move the file, then start again.`);
  }
}
