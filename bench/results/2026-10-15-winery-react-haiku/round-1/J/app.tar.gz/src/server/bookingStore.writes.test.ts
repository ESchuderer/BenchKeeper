import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { BookingStore } from './bookingStore.js';

const REFERENCE_PATTERN = /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/;
const at = (iso: string) => () => new Date(iso);
const BEFORE_SALES = at('2026-10-14T12:00:00Z');

describe('BookingStore.createBooking', () => {
  it('confirms a booking within the seats left and reduces the seats left', () => {
    const store = new BookingStore({ now: BEFORE_SALES });

    const result = store.createBooking({
      tastingSlug: 'riesling-evening',
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: 3,
    });

    expect(result.ok).toBe(true);
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(9);
  });

  it('rejects a booking above the seats left and leaves the seats unchanged', () => {
    const store = new BookingStore({ now: BEFORE_SALES });

    const result = store.createBooking({
      tastingSlug: 'winter-tasting',
      name: 'Ben',
      email: 'ben@example.com',
      guests: 11,
    });

    expect(result).toEqual({ ok: false, failure: { kind: 'not_enough_seats', seatsLeft: 10 } });
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(10);
  });

  it('confirms exactly one of two requests that together exceed the last seats', () => {
    const store = new BookingStore({ now: BEFORE_SALES });
    const request = { tastingSlug: 'red-wine-cellar-tour', name: 'Cara', email: 'cara@example.com', guests: 2 };
    store.createBooking({ ...request, guests: 6 });

    const first = store.createBooking(request);
    const second = store.createBooking({ ...request, name: 'Dan' });

    expect([first.ok, second.ok]).toEqual([true, false]);
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(0);
  });

  it('rejects any booking for a fully booked tasting with "fully booked"', () => {
    const store = new BookingStore({ now: BEFORE_SALES });
    store.createBooking({ tastingSlug: 'winter-tasting', name: 'Eve', email: 'eve@example.com', guests: 10 });

    const result = store.createBooking({
      tastingSlug: 'winter-tasting',
      name: 'Fay',
      email: 'fay@example.com',
      guests: 1,
    });

    expect(result).toEqual({ ok: false, failure: { kind: 'fully_booked' } });
  });

  it('rejects a booking once the start time has passed', () => {
    const store = new BookingStore({ now: at('2026-11-06T17:00:00Z') });

    const result = store.createBooking({
      tastingSlug: 'riesling-evening',
      name: 'Gus',
      email: 'gus@example.com',
      guests: 1,
    });

    expect(result).toEqual({ ok: false, failure: { kind: 'started' } });
  });

  it('rejects an unknown tasting', () => {
    const store = new BookingStore({ now: BEFORE_SALES });

    const result = store.createBooking({ tastingSlug: 'nope', name: 'Hal', email: 'hal@example.com', guests: 1 });

    expect(result).toEqual({ ok: false, failure: { kind: 'not_found' } });
  });

  it('issues references of 8 characters from the unambiguous alphabet, unique across bookings', () => {
    const store = new BookingStore({ now: BEFORE_SALES });
    const references = new Set<string>();

    for (let i = 0; i < 10; i += 1) {
      const result = store.createBooking({
        tastingSlug: 'winter-tasting',
        name: `Guest ${i}`,
        email: 'guest@example.com',
        guests: 1,
      });
      if (!result.ok) throw new Error('expected booking to succeed');
      expect(result.booking.reference).toMatch(REFERENCE_PATTERN);
      references.add(result.booking.reference);
    }

    expect(references.size).toBe(10);
  });
});

describe('BookingStore file persistence', () => {
  let dir: string;
  let file: string;

  beforeEach(() => {
    dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kieselbrunnen-'));
    file = path.join(dir, 'nested', 'bookings.json');
  });

  afterEach(() => {
    fs.rmSync(dir, { recursive: true, force: true });
  });

  it('starts empty when the file does not exist yet', () => {
    const store = new BookingStore({ now: BEFORE_SALES, filePath: file });

    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });

  it('writes each change to the file and reloads it in a new store', () => {
    const first = new BookingStore({ now: BEFORE_SALES, filePath: file });
    const result = first.createBooking({
      tastingSlug: 'riesling-evening',
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: 4,
    });
    if (!result.ok) throw new Error('expected booking to succeed');

    const reloaded = new BookingStore({ now: BEFORE_SALES, filePath: file });

    expect(reloaded.getTasting('riesling-evening')?.seatsLeft).toBe(8);
    expect(reloaded.getBookingConfirmation(result.booking.reference)?.guests).toBe(4);
  });

  it('leaves no temporary files behind after writing', () => {
    const store = new BookingStore({ now: BEFORE_SALES, filePath: file });
    store.createBooking({ tastingSlug: 'winter-tasting', name: 'Ivy', email: 'ivy@example.com', guests: 2 });

    expect(fs.readdirSync(path.dirname(file))).toEqual(['bookings.json']);
  });

  it('refuses to start from a corrupt file and names the file in the error', () => {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, '{ not json');

    expect(() => new BookingStore({ now: BEFORE_SALES, filePath: file })).toThrow(/bookings\.json/);
  });
});
