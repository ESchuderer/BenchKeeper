import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from './app.js';

describe('serving the built client', () => {
  let clientDir: string;

  beforeEach(() => {
    clientDir = fs.mkdtempSync(path.join(os.tmpdir(), 'client-'));
    fs.mkdirSync(path.join(clientDir, 'assets'));
    fs.writeFileSync(path.join(clientDir, 'index.html'), '<!doctype html><div id="root"></div>');
    fs.writeFileSync(path.join(clientDir, 'assets', 'app.js'), 'console.log(1);');
  });

  afterEach(() => {
    fs.rmSync(clientDir, { recursive: true, force: true });
  });

  it('serves the app shell for direct visits to client routes', async () => {
    const app = createApp({ clientDir });

    for (const route of ['/', '/tastings/winter-tasting/book', '/bookings/ABCD2345', '/staff']) {
      const res = await request(app).get(route).expect(200);
      expect(res.text).toContain('<div id="root">');
    }
  });

  it('serves built assets as files', async () => {
    const res = await request(createApp({ clientDir })).get('/assets/app.js').expect(200);

    expect(res.text).toBe('console.log(1);');
  });

  it('answers a missing asset with 404 rather than the app shell', async () => {
    await request(createApp({ clientDir })).get('/assets/missing.js').expect(404);
  });

  it('keeps unknown API paths as JSON 404s rather than the app shell', async () => {
    const res = await request(createApp({ clientDir })).get('/api/nothing-here').expect(404);

    expect(res.body).toEqual({ message: 'Not found' });
  });
});
