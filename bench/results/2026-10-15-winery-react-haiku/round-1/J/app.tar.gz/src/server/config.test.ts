import { describe, expect, it } from 'vitest';
import { readConfig } from './config.js';

describe('readConfig', () => {
  it('uses defaults when nothing is set', () => {
    expect(readConfig({}, '/srv/app')).toEqual({
      port: 3000,
      dataFile: '/srv/app/data/bookings.json',
      sessionsFile: '/srv/app/data/staff-sessions.json',
      staffPassword: undefined,
      trustProxy: 0,
    });
  });

  it('reads PORT, DATA_FILE, STAFF_PASSWORD and TRUST_PROXY', () => {
    expect(
      readConfig({ PORT: '4567', DATA_FILE: '/var/kb/bookings.json', STAFF_PASSWORD: 'secret-pass', TRUST_PROXY: '1' }, '/srv/app'),
    ).toEqual({
      port: 4567,
      dataFile: '/var/kb/bookings.json',
      sessionsFile: '/var/kb/staff-sessions.json',
      staffPassword: 'secret-pass',
      trustProxy: 1,
    });
  });

  it('treats an empty STAFF_PASSWORD as not set', () => {
    expect(readConfig({ STAFF_PASSWORD: '' }, '/srv/app').staffPassword).toBeUndefined();
  });

  it('rejects TRUST_PROXY values that are not a count of proxies', () => {
    expect(() => readConfig({ TRUST_PROXY: 'true' }, '/srv/app')).toThrow(/TRUST_PROXY/);
  });

  it('rejects a PORT that is not a port number', () => {
    expect(() => readConfig({ PORT: 'abc' }, '/srv/app')).toThrow(/PORT/);
  });
});
