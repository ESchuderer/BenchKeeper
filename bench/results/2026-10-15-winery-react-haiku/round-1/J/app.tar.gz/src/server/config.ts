import path from 'node:path';

export interface AppConfig {
  port: number;
  dataFile: string;
  sessionsFile: string;
  staffPassword: string | undefined;
  /** Number of reverse proxies in front of the app. 0 means the app is reached directly. */
  trustProxy: number;
}

/** Reads the configuration from environment variables. Throws with a readable message for invalid values. */
export function readConfig(env: NodeJS.ProcessEnv, cwd: string = process.cwd()): AppConfig {
  const dataFile = env.DATA_FILE ? path.resolve(cwd, env.DATA_FILE) : path.resolve(cwd, 'data', 'bookings.json');
  return {
    port: parsePort(env.PORT ?? '3000'),
    dataFile,
    sessionsFile: path.join(path.dirname(dataFile), 'staff-sessions.json'),
    staffPassword: env.STAFF_PASSWORD || undefined,
    trustProxy: parseTrustProxy(env.TRUST_PROXY),
  };
}

function parsePort(value: string): number {
  const port = Number(value);
  if (!/^\d+$/.test(value) || port > 65535) {
    throw new Error(`PORT must be a port number between 0 and 65535, got "${value}"`);
  }
  return port;
}

function parseTrustProxy(value: string | undefined): number {
  if (value === undefined || value === '') return 0;
  if (!/^\d+$/.test(value)) {
    throw new Error(
      `TRUST_PROXY must be the number of proxies in front of the app, for example 1, got "${value}"`,
    );
  }
  return Number(value);
}
