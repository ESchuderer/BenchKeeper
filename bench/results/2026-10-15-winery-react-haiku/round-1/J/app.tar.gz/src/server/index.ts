import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { BookingStore } from './bookingStore.js';
import { readConfig } from './config.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const clientDir = path.resolve(here, '../client');

let config: ReturnType<typeof readConfig>;
try {
  config = readConfig(process.env);
} catch (error) {
  console.error((error as Error).message);
  process.exit(1);
}

if (!config.staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

const app = createApp({
  store: new BookingStore({ filePath: config.dataFile }),
  clientDir,
  staffPassword: config.staffPassword,
  trustProxy: config.trustProxy,
  sessionsFile: config.sessionsFile,
});

app.listen(config.port, () => console.log(`Weingut Kieselbrunnen tastings listening on port ${config.port}`));
