import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from './app.js';
import { BookingStore } from './bookingStore.js';

const now = () => new Date('2026-10-14T12:00:00Z');
const PASSWORD = 'cellar-door-2026';

function setup() {
  const store = new BookingStore({ now });
  const app = createApp({ store, staffPassword: PASSWORD });
  return { app, store };
}

function setupWithoutPassword() {
  return { app: createApp({ store: new BookingStore({ now }) }) };
}

async function signIn(app: ReturnType<typeof createApp>, password = PASSWORD) {
  const res = await request(app).post('/api/staff/session').send({ password });
  const cookie = res.headers['set-cookie']?.[0]?.split(';')[0] ?? '';
  return { res, cookie };
}

describe('POST /api/staff/session', () => {
  it('signs staff in with a cookie that is HttpOnly and SameSite=Strict', async () => {
    const { app } = setup();

    const { res } = await signIn(app);

    expect(res.status).toBe(204);
    const cookie = res.headers['set-cookie'][0];
    expect(cookie).toMatch(/^kieselbrunnen_staff=/);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    expect(cookie).toMatch(/Max-Age=43200/);
    expect(cookie).not.toMatch(/Secure/);
  });

  it('refuses a wrong password with 401 and sets no cookie', async () => {
    const { app } = setup();

    const { res } = await signIn(app, 'guess123');

    expect(res.status).toBe(401);
    expect(res.body.message).toBe('Incorrect password');
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('refuses an empty password with 401', async () => {
    const { app } = setup();

    const { res } = await signIn(app, '');

    expect(res.status).toBe(401);
  });

  it('reports that sign-in is not configured when STAFF_PASSWORD is unset', async () => {
    const { app } = setupWithoutPassword();

    const { res } = await signIn(app);

    expect(res.status).toBe(503);
    expect(res.body.message).toBe('Staff sign-in is not configured');
  });

  it('does not count successful sign-ins against the limit', async () => {
    const { app } = setup();
    for (let i = 0; i < 12; i += 1) {
      await signIn(app).then(({ res }) => expect(res.status).toBe(204));
    }
  });

  it('limits sign-in attempts to 10 per 15 minutes per client', async () => {
    const { app } = setup();
    for (let i = 0; i < 10; i += 1) {
      await signIn(app, 'wrong');
    }

    const { res } = await signIn(app, PASSWORD);

    expect(res.status).toBe(429);
  });
});

describe('GET /api/staff/session', () => {
  it('reports whether sign-in is configured and whether the caller is signed in', async () => {
    const { app } = setup();
    const before = await request(app).get('/api/staff/session').expect(200);
    const { cookie } = await signIn(app);
    const after = await request(app).get('/api/staff/session').set('Cookie', cookie).expect(200);

    expect(before.body).toEqual({ configured: true, signedIn: false });
    expect(after.body).toEqual({ configured: true, signedIn: true });
  });

  it('reports not configured without a password', async () => {
    const res = await request(setupWithoutPassword().app).get('/api/staff/session').expect(200);

    expect(res.body).toEqual({ configured: false, signedIn: false });
  });
});

describe('DELETE /api/staff/session', () => {
  it('signs out so the session cookie no longer opens the staff routes', async () => {
    const { app } = setup();
    const { cookie } = await signIn(app);

    const out = await request(app).delete('/api/staff/session').set('Cookie', cookie).expect(204);
    const after = await request(app).get('/api/staff/bookings').set('Cookie', cookie);

    expect(out.headers['set-cookie'][0]).toMatch(/kieselbrunnen_staff=;/);
    expect(after.status).toBe(401);
  });
});

describe('staff-only routes', () => {
  it('return 401 and no booking data without a session', async () => {
    const { app } = setup();

    const list = await request(app).get('/api/staff/bookings').expect(401);
    const cancel = await request(app).delete('/api/staff/bookings/ABCDEFGH').expect(401);

    expect(list.body).not.toHaveProperty('groups');
    expect(list.body).not.toHaveProperty('0');
    expect(cancel.body.message).toMatch(/sign in/i);
  });

  it('list bookings grouped by tasting for a signed-in member of staff', async () => {
    const { app } = setup();
    await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 })
      .expect(201);
    const { cookie } = await signIn(app);

    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);

    expect(res.body).toHaveLength(3);
    expect(res.body[0].tasting.slug).toBe('riesling-evening');
    expect(res.body[0].bookings).toEqual([
      expect.objectContaining({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 }),
    ]);
    expect(res.body[1].bookings).toEqual([]);
  });

  it('cancel a booking, freeing its seats', async () => {
    const { app } = setup();
    const created = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 })
      .expect(201);
    const { cookie } = await signIn(app);

    await request(app).delete(`/api/staff/bookings/${created.body.reference}`).set('Cookie', cookie).expect(204);
    const tastings = await request(app).get('/api/tastings');

    expect(tastings.body[0].seatsLeft).toBe(12);
  });

  it('answer 404 when the booking to cancel no longer exists', async () => {
    const { app } = setup();
    const { cookie } = await signIn(app);

    const res = await request(app).delete('/api/staff/bookings/ZZZZZZZZ').set('Cookie', cookie).expect(404);

    expect(res.body.message).toBe('This booking no longer exists');
  });
});

describe('behind a reverse proxy', () => {
  it('limits sign-in per real client and ignores forwarded addresses the client supplies', async () => {
    const app = createApp({ store: new BookingStore({ now }), staffPassword: PASSWORD, trustProxy: 1 });
    for (let i = 0; i < 10; i += 1) {
      await request(app)
        .post('/api/staff/session')
        .set('X-Forwarded-For', `198.51.100.${i}, 203.0.113.7`)
        .send({ password: 'wrong' })
        .expect(401);
    }

    await request(app)
      .post('/api/staff/session')
      .set('X-Forwarded-For', '198.51.100.200, 203.0.113.7')
      .send({ password: 'wrong' })
      .expect(429);
  });

  it('marks the staff cookie Secure when the proxy reports HTTPS', async () => {
    const app = createApp({ store: new BookingStore({ now }), staffPassword: PASSWORD, trustProxy: 1 });

    const res = await request(app)
      .post('/api/staff/session')
      .set('X-Forwarded-For', '203.0.113.7')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD })
      .expect(204);

    expect(res.headers['set-cookie'][0]).toMatch(/;\s*Secure/i);
  });
});
