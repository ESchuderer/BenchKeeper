import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { passwordMatches, StaffSessions, SESSION_TTL_MS } from './staffAuth.js';

describe('passwordMatches', () => {
  it('accepts the configured password', () => {
    expect(passwordMatches('cellar-door-2026', 'cellar-door-2026')).toBe(true);
  });

  it('rejects a wrong, empty, or prefix password', () => {
    expect(passwordMatches('guess123', 'cellar-door-2026')).toBe(false);
    expect(passwordMatches('', 'cellar-door-2026')).toBe(false);
    expect(passwordMatches('cellar-door', 'cellar-door-2026')).toBe(false);
  });

  it('never matches when no password is configured', () => {
    expect(passwordMatches('', undefined)).toBe(false);
    expect(passwordMatches('anything', '')).toBe(false);
  });
});

describe('StaffSessions', () => {
  it('issues random, unguessable tokens', () => {
    const sessions = new StaffSessions();
    const first = sessions.create();
    const second = sessions.create();

    expect(first).toMatch(/^[A-Za-z0-9_-]{40,}$/);
    expect(first).not.toBe(second);
  });

  it('accepts a session until it has lasted 12 hours', () => {
    let current = new Date('2026-10-14T12:00:00Z');
    const sessions = new StaffSessions({ now: () => current });
    const token = sessions.create();

    current = new Date(current.getTime() + SESSION_TTL_MS - 1000);
    expect(sessions.isValid(token)).toBe(true);

    current = new Date(current.getTime() + 2000);
    expect(sessions.isValid(token)).toBe(false);
  });

  it('stops accepting a token after sign-out', () => {
    const sessions = new StaffSessions();
    const token = sessions.create();

    sessions.revoke(token);

    expect(sessions.isValid(token)).toBe(false);
  });

  it('rejects unknown and missing tokens', () => {
    const sessions = new StaffSessions();

    expect(sessions.isValid('not-a-session')).toBe(false);
    expect(sessions.isValid(undefined)).toBe(false);
  });
});

describe('StaffSessions persistence', () => {
  let dir: string;
  let file: string;

  beforeEach(() => {
    dir = fs.mkdtempSync(path.join(os.tmpdir(), 'staff-'));
    file = path.join(dir, 'staff-sessions.json');
  });

  afterEach(() => {
    fs.rmSync(dir, { recursive: true, force: true });
  });

  it('keeps a signed-in session across a restart', () => {
    const token = new StaffSessions({ filePath: file }).create();

    expect(new StaffSessions({ filePath: file }).isValid(token)).toBe(true);
  });

  it('stores a hash of each token rather than the token itself', () => {
    const token = new StaffSessions({ filePath: file }).create();

    expect(fs.readFileSync(file, 'utf8')).not.toContain(token);
  });

  it('does not restore a session once its 12 hours have passed', () => {
    let current = new Date('2026-10-14T12:00:00Z');
    const token = new StaffSessions({ now: () => current, filePath: file }).create();
    current = new Date(current.getTime() + SESSION_TTL_MS);

    expect(new StaffSessions({ now: () => current, filePath: file }).isValid(token)).toBe(false);
  });

  it('forgets a session after sign-out, including after a restart', () => {
    const sessions = new StaffSessions({ filePath: file });
    const token = sessions.create();

    sessions.revoke(token);

    expect(new StaffSessions({ filePath: file }).isValid(token)).toBe(false);
  });

  it('starts with no sessions when the sessions file cannot be read', () => {
    fs.writeFileSync(file, '{ broken');

    expect(new StaffSessions({ filePath: file }).isValid('anything')).toBe(false);
  });
});
