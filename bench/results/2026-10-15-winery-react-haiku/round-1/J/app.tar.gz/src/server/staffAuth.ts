import crypto from 'node:crypto';
import fs from 'node:fs';
import { z } from 'zod';
import { writeFileAtomic } from './atomicFile.js';

export const STAFF_COOKIE = 'kieselbrunnen_staff';
export const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

function digest(value: string): Buffer {
  return crypto.createHash('sha256').update(value).digest();
}

/** Compares digests of both values in constant time, so the comparison leaks neither content nor length. */
export function passwordMatches(provided: string, expected: string | undefined): boolean {
  if (!expected) return false;
  return crypto.timingSafeEqual(digest(provided), digest(expected));
}

export interface StaffSessionsOptions {
  now?: () => Date;
  /** File that keeps sessions across restarts. Only hashes of the tokens are written. */
  filePath?: string;
}

const sessionFileSchema = z.object({
  version: z.literal(1),
  sessions: z.array(z.object({ tokenHash: z.string(), expiresAt: z.number() })),
});

/** Signed-in staff sessions. Each token is random and only its SHA-256 hash is stored. */
export class StaffSessions {
  /** Maps the SHA-256 hash of each token to the time (ms) at which the session ends. */
  private readonly expiresAt: Map<string, number>;
  private readonly now: () => Date;
  private readonly filePath: string | undefined;

  constructor(options: StaffSessionsOptions = {}) {
    this.now = options.now ?? (() => new Date());
    this.filePath = options.filePath;
    this.expiresAt = new Map(this.filePath ? loadSessions(this.filePath, this.now().getTime()) : []);
  }

  create(): string {
    this.prune();
    const token = crypto.randomBytes(32).toString('base64url');
    this.expiresAt.set(hashToken(token), this.now().getTime() + SESSION_TTL_MS);
    this.save();
    return token;
  }

  isValid(token: string | undefined): boolean {
    if (!token) return false;
    const key = hashToken(token);
    const expiry = this.expiresAt.get(key);
    if (expiry === undefined) return false;
    if (this.now().getTime() >= expiry) {
      this.expiresAt.delete(key);
      return false;
    }
    return true;
  }

  revoke(token: string | undefined): void {
    if (token && this.expiresAt.delete(hashToken(token))) this.save();
  }

  private prune(): void {
    const current = this.now().getTime();
    for (const [key, expiry] of this.expiresAt) {
      if (current >= expiry) this.expiresAt.delete(key);
    }
  }

  private save(): void {
    if (!this.filePath) return;
    this.prune();
    const sessions = [...this.expiresAt].map(([tokenHash, expiresAt]) => ({ tokenHash, expiresAt }));
    writeFileAtomic(this.filePath, JSON.stringify({ version: 1, sessions }, null, 2));
  }
}

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/** Sessions are not critical data: if the file cannot be read, staff simply sign in again. */
function loadSessions(filePath: string, nowMs: number): [string, number][] {
  if (!fs.existsSync(filePath)) return [];
  try {
    const parsed = sessionFileSchema.parse(JSON.parse(fs.readFileSync(filePath, 'utf8')));
    return parsed.sessions
      .filter((session) => nowMs < session.expiresAt)
      .map((session): [string, number] => [session.tokenHash, session.expiresAt]);
  } catch (error) {
    console.warn(`Ignoring unreadable staff sessions file ${filePath}: ${(error as Error).message}`);
    return [];
  }
}
