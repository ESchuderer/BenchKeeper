import { describe, expect, it } from 'vitest';
import { TASTINGS, findTasting } from './tastings.js';

describe('tasting definitions', () => {
  it('offers the three scheduled tastings in chronological order', () => {
    expect(TASTINGS.map((tasting) => tasting.title)).toEqual([
      'Riesling Evening',
      'Red Wine Cellar Tour',
      'Winter Tasting',
    ]);
  });

  it('has the agreed slugs, start times with the Berlin offset, prices and seats', () => {
    expect(TASTINGS).toEqual([
      {
        slug: 'riesling-evening',
        title: 'Riesling Evening',
        startsAt: '2026-11-06T18:00:00+01:00',
        pricePerGuest: 25,
        seats: 12,
      },
      {
        slug: 'red-wine-cellar-tour',
        title: 'Red Wine Cellar Tour',
        startsAt: '2026-11-14T15:00:00+01:00',
        pricePerGuest: 32,
        seats: 8,
      },
      {
        slug: 'winter-tasting',
        title: 'Winter Tasting',
        startsAt: '2026-12-05T17:00:00+01:00',
        pricePerGuest: 28,
        seats: 10,
      },
    ]);
  });

  it('finds a tasting by slug and returns undefined for an unknown slug', () => {
    expect(findTasting('winter-tasting')?.title).toBe('Winter Tasting');
    expect(findTasting('no-such-tasting')).toBeUndefined();
  });
});
