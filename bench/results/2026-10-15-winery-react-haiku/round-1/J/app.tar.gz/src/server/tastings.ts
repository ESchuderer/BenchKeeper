export interface TastingDefinition {
  slug: string;
  title: string;
  /** Start time with its UTC offset; Europe/Berlin is +01:00 in November and December 2026. */
  startsAt: string;
  pricePerGuest: number;
  seats: number;
}

/** The tastings on offer, in chronological order. */
export const TASTINGS: readonly TastingDefinition[] = [
  {
    slug: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06T18:00:00+01:00',
    pricePerGuest: 25,
    seats: 12,
  },
  {
    slug: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    startsAt: '2026-11-14T15:00:00+01:00',
    pricePerGuest: 32,
    seats: 8,
  },
  {
    slug: 'winter-tasting',
    title: 'Winter Tasting',
    startsAt: '2026-12-05T17:00:00+01:00',
    pricePerGuest: 28,
    seats: 10,
  },
];

export function findTasting(slug: string): TastingDefinition | undefined {
  return TASTINGS.find((tasting) => tasting.slug === slug);
}
