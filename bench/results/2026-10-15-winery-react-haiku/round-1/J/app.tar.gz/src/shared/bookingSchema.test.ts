import { describe, expect, it } from 'vitest';
import { bookingFormSchema } from './bookingSchema.js';

const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function firstError(input: unknown, field: string): string | undefined {
  const result = bookingFormSchema.safeParse(input);
  if (result.success) return undefined;
  return result.error.issues.find((issue) => issue.path[0] === field)?.message;
}

describe('bookingFormSchema', () => {
  it('accepts a complete booking', () => {
    expect(bookingFormSchema.safeParse(valid).success).toBe(true);
  });

  it('requires a name and trims surrounding whitespace', () => {
    expect(firstError({ ...valid, name: '' }, 'name')).toBe('Please enter your name');
    expect(firstError({ ...valid, name: '   ' }, 'name')).toBe('Please enter your name');
    expect(bookingFormSchema.parse({ ...valid, name: '  Anna  ' }).name).toBe('Anna');
  });

  it('allows a name of exactly 100 characters and rejects 101', () => {
    expect(firstError({ ...valid, name: 'a'.repeat(100) }, 'name')).toBeUndefined();
    expect(firstError({ ...valid, name: 'a'.repeat(101) }, 'name')).toBe(
      'Name must be 100 characters or fewer',
    );
  });

  it('requires a syntactically valid email address', () => {
    expect(firstError({ ...valid, email: '' }, 'email')).toBe('Please enter your email address');
    expect(firstError({ ...valid, email: 'anna@example' }, 'email')).toBe(
      'Please enter a valid email address',
    );
  });

  it('accepts whole numbers of guests from 1 to 8 only', () => {
    expect(firstError({ ...valid, guests: 1 }, 'guests')).toBeUndefined();
    expect(firstError({ ...valid, guests: 8 }, 'guests')).toBeUndefined();
    expect(firstError({ ...valid, guests: 0 }, 'guests')).toBe('Please choose between 1 and 8 guests');
    expect(firstError({ ...valid, guests: 9 }, 'guests')).toBe('Please choose between 1 and 8 guests');
    expect(firstError({ ...valid, guests: 2.5 }, 'guests')).toBe('Please choose between 1 and 8 guests');
    expect(firstError({ ...valid, guests: Number.NaN }, 'guests')).toBe(
      'Please choose between 1 and 8 guests',
    );
  });
});
