import { z } from 'zod';

export const MAX_GUESTS = 8;
export const MAX_NAME_LENGTH = 100;

const GUESTS_MESSAGE = `Please choose between 1 and ${MAX_GUESTS} guests`;

/** The guest booking form. Shared by the browser form and the server, so both enforce the same rules. */
export const bookingFormSchema = z.object({
  name: z
    .string({ error: 'Please enter your name' })
    .trim()
    .min(1, 'Please enter your name')
    .max(MAX_NAME_LENGTH, `Name must be ${MAX_NAME_LENGTH} characters or fewer`),
  email: z
    .string({ error: 'Please enter your email address' })
    .trim()
    .min(1, 'Please enter your email address')
    .pipe(z.email({ error: 'Please enter a valid email address' })),
  guests: z
    .number({ error: GUESTS_MESSAGE })
    .int(GUESTS_MESSAGE)
    .min(1, GUESTS_MESSAGE)
    .max(MAX_GUESTS, GUESTS_MESSAGE),
});

export type BookingFormValues = z.input<typeof bookingFormSchema>;
