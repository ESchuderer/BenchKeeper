import { describe, expect, it } from 'vitest';
import { formatEur, formatSeatsLeft, formatStartsAt } from './format.js';

describe('formatStartsAt', () => {
  it('shows the start time in Europe/Berlin', () => {
    expect(formatStartsAt('2026-11-06T18:00:00+01:00')).toBe('Fri 6 Nov 2026, 18:00');
  });

  it('uses Berlin time even when the instant falls on another UTC day', () => {
    expect(formatStartsAt('2026-12-05T17:00:00+01:00')).toBe('Sat 5 Dec 2026, 17:00');
  });
});

describe('formatEur', () => {
  it('prefixes the amount with EUR', () => {
    expect(formatEur(25)).toBe('EUR 25');
  });
});

describe('formatSeatsLeft', () => {
  it('uses the singular for one seat', () => {
    expect(formatSeatsLeft(1)).toBe('1 seat left');
  });

  it('uses the plural otherwise', () => {
    expect(formatSeatsLeft(0)).toBe('0 seats left');
    expect(formatSeatsLeft(12)).toBe('12 seats left');
  });
});
