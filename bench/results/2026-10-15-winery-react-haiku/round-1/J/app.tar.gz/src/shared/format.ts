const startsAtFormatter = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'Europe/Berlin',
  weekday: 'short',
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});

/** Formats a tasting start time for display in the winery's time zone, e.g. "Fri 6 Nov 2026, 18:00". */
export function formatStartsAt(startsAt: string): string {
  const parts = Object.fromEntries(
    startsAtFormatter.formatToParts(new Date(startsAt)).map((part) => [part.type, part.value]),
  );
  return `${parts.weekday} ${parts.day} ${parts.month} ${parts.year}, ${parts.hour}:${parts.minute}`;
}

/** Formats an amount in euros, e.g. "EUR 25". */
export function formatEur(amount: number): string {
  return `EUR ${amount}`;
}

/** Formats the seats still free, e.g. "1 seat left" or "12 seats left". */
export function formatSeatsLeft(count: number): string {
  return `${count} ${count === 1 ? 'seat' : 'seats'} left`;
}
