export type TastingStatus = 'open' | 'fully_booked' | 'started';

export interface TastingSummary {
  slug: string;
  title: string;
  startsAt: string;
  pricePerGuest: number;
  seats: number;
  seatsLeft: number;
  status: TastingStatus;
}

export interface BookingConfirmation {
  reference: string;
  tasting: { slug: string; title: string; startsAt: string };
  guests: number;
  pricePerGuest: number;
  total: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface StaffBookingGroup {
  tasting: TastingSummary;
  bookings: StaffBooking[];
}

export interface ApiErrorBody {
  message: string;
  errors?: Record<string, string>;
  seatsLeft?: number;
}
