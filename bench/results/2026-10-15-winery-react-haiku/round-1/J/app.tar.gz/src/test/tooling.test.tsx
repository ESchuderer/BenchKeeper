import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

describe('test tooling', () => {
  it('renders React in jsdom with jest-dom matchers', () => {
    render(<p>tooling works</p>);
    expect(screen.getByText('tooling works')).toBeInTheDocument();
  });
});
