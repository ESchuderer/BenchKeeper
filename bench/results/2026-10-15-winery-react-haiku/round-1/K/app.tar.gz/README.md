# Weingut Kieselbrunnen: wine tasting bookings

A small web app for Weingut Kieselbrunnen. Guests book seats on wine tastings online. Staff sign in to see every booking grouped by tasting and to cancel bookings.

## Requirements

- Node.js 22
- No external services. Bookings are kept in memory.

## Run it

```bash
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start
```

Then open <http://localhost:3000>. `npm start` serves the guest pages, the staff area and the JSON API from one process.

| Variable | Default | Purpose |
|---|---|---|
| `STAFF_PASSWORD` | none | Password for `/staff`, at least 12 characters. Without it the server still starts and serves guest pages, but staff sign-in is refused with "Staff sign-in is not configured" and a warning is logged at startup. |
| `PORT` | `3000` | Port to listen on. |
| `SESSION_SECRET` | random at each start | Signs the staff session cookie so others cannot forge one. It does not keep staff signed in across restarts, because live sessions are held in memory. |
| `COOKIE_SECURE` | `false` | Set to `true` when the site is served over HTTPS, so the session cookie is only sent over HTTPS. |
| `TRUST_PROXY` | none | Number of reverse proxies in front of the app (for example `1`). Set it behind a proxy so rate limits see each visitor’s own address. Do not set it when the app is reached directly. |

## Pages

| Path | What it shows |
|---|---|
| `/` | The three tastings with date and time, price per guest and seats left. |
| `/tastings/<id>/book` | The booking form for one tasting: Name, Email and Guests (1 to 8). |
| `/bookings/<reference>` | The confirmation, which can be reopened from its reference. |
| `/staff` | Staff sign-in, then bookings grouped by tasting, with Cancel and Sign out. |

## Develop

```bash
npm run dev:api     # API on PORT (default 3000), restarts on change
npm run dev:web     # Vite on port 5173, proxies /api to the API
```

## Test and check

```bash
npm run typecheck        # TypeScript for the interface and the server
npm test                 # unit and integration tests
npm run test:coverage    # same, with coverage (80% minimum enforced)
npm run test:e2e         # browser tests against a built app (needs Chromium)
```

## Limits to know before going live

- **Bookings are lost on restart.** They are kept in memory, as the brief allows. Replacing the in-memory repository in `src/server/bookingRepository.ts` is the place to add a database.
- **Run one instance only.** The seat limit is enforced in one process. Two instances would each keep their own bookings and could oversell.
- **Behind a reverse proxy, set `TRUST_PROXY`.** Sign-in and request rate limits are per client IP. Without it, every visitor behind the proxy shares one limit.
- **Anyone can take seats.** Booking needs no email confirmation, and only staff can cancel. Limit this in front of the app or add guest verification before a busy season.
- **Staff sessions last 12 hours.** Signing out revokes that session at once. The server forgets live sessions on restart, so staff sign in again after a restart.
- **Use HTTPS and `COOKIE_SECURE=true` in production.**

## Layout

```
src/shared/   rules and types used by both the server and the interface
src/server/   Express app, booking service, in-memory repository, configuration
src/client/   React interface (pages, components, API client)
openspec/     the specification and the change this app was built from
e2e/          browser tests
```

The design and requirements are in `openspec/changes/winery-tasting-bookings/` (or, once archived, `openspec/specs/`).
