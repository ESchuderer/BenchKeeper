import { expect, test } from "@playwright/test";
import { E2E_STAFF_PASSWORD } from "../playwright.config.js";

interface TastingSummary {
  id: string;
  seatsLeft: number;
}

async function seatsLeft(request: import("@playwright/test").APIRequestContext, tastingId: string) {
  const tastings = (await (await request.get("/api/tastings")).json()) as TastingSummary[];
  return tastings.find((tasting) => tasting.id === tastingId)?.seatsLeft ?? -1;
}

test("a guest books a tasting and sees the confirmation", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "Riesling Evening" })).toBeVisible();

  await page.getByRole("link", { name: "Book Riesling Evening" }).click();
  await expect(page).toHaveURL(/\/tastings\/riesling-evening\/book$/);
  await page.getByLabel("Name").fill("Anna Keller");
  await page.getByLabel("Email").fill("anna@example.de");
  await page.getByLabel("Guests").fill("3");
  await page.getByRole("button", { name: "Book" }).click();

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  await expect(page.getByText("Riesling Evening", { exact: true })).toBeVisible();
  await expect(page.getByText("3 guests", { exact: true })).toBeVisible();
  await expect(page.getByText("EUR 75", { exact: true })).toBeVisible();
  await expect(page.getByText(/^KB-[2-9A-HJ-NP-Z]{8}$/)).toBeVisible();
});

test("invalid input is explained next to the field and nothing is booked", async ({ page, request }) => {
  const before = await seatsLeft(request, "winter-tasting");

  await page.goto("/tastings/winter-tasting/book");
  await page.getByLabel("Email").fill("anna@");
  await page.getByLabel("Guests").fill("9");
  await page.getByRole("button", { name: "Book" }).click();

  await expect(page.getByLabel("Email")).toHaveAccessibleDescription("Enter a valid email address");
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription("Enter between 1 and 8 guests");
  expect(await seatsLeft(request, "winter-tasting")).toBe(before);
});

test("staff sign in, see the bookings, and cancel one to free its seats", async ({ page, request }) => {
  const seatsBefore = await seatsLeft(request, "red-wine-cellar-tour");
  const created = await request.post("/api/tastings/red-wine-cellar-tour/bookings", {
    data: { name: "Ben Ruf", email: "ben@example.de", guests: 2 },
  });
  const booking = (await created.json()) as { reference: string };

  await page.goto("/staff");
  await page.getByLabel("Password").fill("not-the-password");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByRole("alert")).toHaveText("Incorrect password");

  await page.getByLabel("Password").fill(E2E_STAFF_PASSWORD);
  await page.getByRole("button", { name: "Sign in" }).click();
  const group = page.getByRole("region", { name: "Red Wine Cellar Tour" });
  // Match on the reference: earlier runs may have left bookings with the same name.
  const row = group.getByRole("listitem").filter({ hasText: booking.reference });
  await expect(row).toContainText("Ben Ruf");

  await row.getByRole("button", { name: "Cancel" }).click();
  await expect(row.getByText("Cancelled", { exact: true })).toBeVisible();
  expect(await seatsLeft(request, "red-wine-cellar-tour")).toBe(seatsBefore);
});

test("pages fit the screen width without horizontal scrolling", async ({ page }) => {
  for (const path of ["/", "/tastings/riesling-evening/book", "/staff"]) {
    await page.goto(path);
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
    );
    expect(overflow, `horizontal overflow on ${path}`).toBeLessThanOrEqual(0);
  }
});
