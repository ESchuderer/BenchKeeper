# Design

## Context

The repository is empty apart from OpenSpec scaffolding. See proposal.md for motivation. The app runs as one Node.js 22 process on `PORT`, with no external services. Only three tastings exist, with fixed titles, times, prices and capacities, and bookings are not persisted between restarts. Guests use phones as well as desktops, and staff use the same site with a shared password.

## Goals / Non-Goals

**Goals:**

- One process serves both the JSON API and the React interface, so `npm start` is the only run command.
- Seat limits hold under concurrent requests, not just in the happy path.
- Validation rules are written once and enforced on both the form and the server.
- Use maintained libraries for the server, routing, forms, validation, styling and security headers rather than local replacements.

**Non-Goals:**

- Persistent storage, multi-instance deployment, or horizontal scaling.
- Payment, email, accounts for guests, or a staff user database.
- Server-side rendering. The interface is a client-rendered single-page app.

## Decisions

### Stack

- **Server: Express 5 with TypeScript.** Maintained, minimal, and well understood. Fastify was an alternative, but Express covers the need with less configuration and is the most common choice for Node servers.
- **Interface: React 19 built with Vite 8, served as static files by Express.** Vite gives a fast, standard build. A separate static host was rejected because it would need CORS and a second deploy target.
- **Routing: react-router.** Declarative routes for `/`, `/tastings/:tastingId/book`, `/bookings/:reference` and `/staff`. A hand-written router was rejected.
- **Forms and validation: react-hook-form with zod through @hookform/resolvers.** The zod schemas live in `src/shared` and are imported by both the browser form and the server route, so the rules cannot drift apart. The server always re-validates, because client checks can be bypassed.
- **Styling: Tailwind CSS v4 through its Vite plugin.** Utility classes keep the mobile-first layout and state styles (error, success, fully booked) consistent with minimal custom CSS.
- **Security middleware: helmet for headers, express-rate-limit (a stricter sign-in limit and a general limit for all `/api` routes), cookie-session for the staff session.** Each is a small, established package. Hand-rolled alternatives were rejected.
- **Language: TypeScript 5.9 everywhere.** TypeScript 7 (native port) was rejected for now because the Vite, Vitest and Testing Library toolchain is validated against the 5.x line.

### Booking storage: in-memory repository behind an interface

Bookings sit in a `BookingRepository` with methods such as `findByTasting`, `findByReference`, `insert`, and `cancel`. The only implementation keeps them in a `Map`. The brief permits memory, and it says the app starts with no bookings, which a JSON file would contradict on the next start. The seat check and the insert run in one synchronous function, so Node's single thread gives the concurrency guarantee without locks. A JSON file or SQLite database was rejected: both add write-ordering and file-locking concerns, and SQLite adds a native build step. The repository interface keeps a later move to a database a local change.

### Catalogue as code

Tastings are constants in `src/server/catalogue.ts` with stable slugs as ids (`riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`). The client receives them from the API. Seats left are computed from active bookings and never stored, so they cannot drift from the booking list.

### Money and dates

- Prices are whole euros, so totals are integers (`price * guests`) and no floating-point rounding applies.
- Start times are stored as wall-clock strings without a timezone (`2026-11-06T18:00`), which matches how the brief states them. The date part is formatted with `Intl.DateTimeFormat('en-GB', { weekday, day, month, year, timeZone: 'UTC' })` on a UTC date built from the parts, and the time is appended as `, HH:mm`. This gives the same text on the server, in the browser and in any test environment.

### API shape

All routes are under `/api`. Successful responses return the resource as JSON. Errors return `{ "error": { "message": string, "fields"?: { [field]: string } } }`, where `fields` carries the per-field messages the form displays next to each input. Status codes: 400 for validation failures, 401 for missing staff session, 404 for unknown tastings or references, 409 for a booking that exceeds seats left and for cancelling an already-cancelled booking, 429 for rate limits.

Endpoints:

- `GET /api/tastings`, `GET /api/tastings/:tastingId`
- `POST /api/tastings/:tastingId/bookings`, body `{ name, email, guests }`, returns 201 with the booking
- `GET /api/bookings/:reference`, returns tasting, guests, total, reference and status (`confirmed` or `cancelled`). The guest's name and email are not returned.
- `GET /api/staff/session`, `POST /api/staff/session` (body `{ password }`), `DELETE /api/staff/session`
- `GET /api/staff/bookings`, grouped by tasting, staff only
- `POST /api/staff/bookings/:reference/cancel`, staff only

### Staff authentication

`STAFF_PASSWORD` is read at startup. If it is missing or empty, the server logs a warning and still starts, so the guest pages keep working; staff sign-in then answers "Staff sign-in is not configured". This is a deliberate departure from the usual fail-fast rule: the brief requires `npm start` to serve the whole app, and a crash would take the guest booking site down with it. Comparison uses `crypto.timingSafeEqual` on SHA-256 digests of both values, which gives equal lengths and avoids timing leaks. A successful sign-in sets a signed cookie session holding a random session id, with `httpOnly` and `sameSite: 'strict'`. The `TRUST_PROXY` setting, when present, is passed to Express so rate limits see the visitor's own address behind a proxy. Staff routes are checked by the same session test, and a 12-hour cap applies to every session. The session secret comes from `SESSION_SECRET` when set, otherwise a random value generated at startup. The cookie holds only a random session id; the server keeps live session ids in memory with their issue time, and sign-out removes the id at once, so a copied cookie stops working. Sessions expire after 12 hours, and a restart ends every session. The `secure` cookie flag is controlled by `COOKIE_SECURE=true`, because it must be off for plain-HTTP local use. Failed sign-in attempts are limited per client IP (10 per 15 minutes, successful attempts do not count).

### Build and start

`npm run build` runs `vite build` (client, to `dist/client`) and `tsc -p tsconfig.server.json` (server and shared code, to `dist/server` and `dist/shared`). `npm start` runs `node dist/server/server.js` from the project root; the server finds the built interface at `dist/client` relative to the working directory. Development runs `tsx watch` for the API and Vite for the interface, with Vite proxying `/api`.

### Booking references

References are 8 characters from an alphabet without look-alike characters (no 0, O, 1, I), generated with `crypto.randomInt`, and shown in upper case with a `KB-` prefix. A repository check retries on collision. Collisions are astronomically unlikely, but the retry keeps uniqueness a guarantee rather than a probability.

### Error display

Field errors come from the same zod schema on the client and the server, and are mapped to inputs by name. A network or 5xx failure shows a general message above the form and leaves the entered values in place.

## Risks / Trade-offs

- **Data is lost on restart.** → Accepted by the brief. The repository interface keeps a database change local. The README states that restarts clear bookings.
- **The seat guarantee holds only inside one process.** → Running two instances would break it. The README states the single-instance assumption.
- **Rate limits use the connecting IP.** Behind a reverse proxy every client would share one IP. → Set `TRUST_PROXY` to the proxy hop count in that deployment (documented in the README) before relying on the limit.
- **Missing `STAFF_PASSWORD` is a running-but-degraded state.** → The startup warning is loud, and staff sign-in refuses every attempt, so nobody gets in without the password. Operators must read the log; the README says so.
- **Cookie `secure` is off by default.** → Production deployments must set `COOKIE_SECURE=true` behind HTTPS. The README says so.
- **Sessions do not survive restarts** (live session ids are held in memory). → Staff sign in again after a restart. This is acceptable with in-memory state.
- **Client-side SPA means no content for crawlers or no-JS clients.** → Acceptable for a booking tool; the tasting list is simple to add to SSR later.

## Migration Plan

This is a new project, so there is nothing to migrate. Deploy by running `npm install`, `npm run build` and `npm start` with `STAFF_PASSWORD` set. Rollback is stopping the process, because no data is written to disk.

## Open Questions

None that change the specs or task breakdown.
