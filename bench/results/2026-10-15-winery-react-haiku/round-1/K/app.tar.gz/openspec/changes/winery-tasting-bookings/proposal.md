# Proposal

## Why

Weingut Kieselbrunnen runs wine tastings but has no way for guests to book them online, and staff have no single view of who is coming. A small web app lets guests reserve seats for the three published tastings and lets staff see and manage those bookings from one place.

## What Changes

- Add a public start page that lists the three tastings with date and time, price per guest and seats left, and marks fully booked tastings clearly.
- Add a booking form per tasting ("Book <tasting title>") with Name, Email and Guests (1 to 8) fields. Invalid input is rejected with an error next to the field it concerns. A booking can never exceed the seats left.
- Add a booking confirmation page with the heading "Booking confirmed", the tasting, number of guests, total price and booking reference.
- Add a staff area at `/staff`, protected by a password read from the `STAFF_PASSWORD` environment variable. Signed-in staff see all bookings grouped by tasting and can cancel a booking; a cancelled booking frees its seats.
- Bookings are held in memory. The app starts with no bookings and nothing is written to disk or to an external service.
- The tasting catalogue is fixed in code: the three tastings listed in the brief.

Out of scope:

- Payment, deposits or price changes at booking time.
- Editing or rescheduling a booking, guest-initiated cancellation, and email notifications.
- Persistence across restarts, multiple staff accounts, and any admin editing of tastings.
- Internationalisation: the interface is English only.

## Capabilities

### New Capabilities

- `tasting-catalogue`: the public list of tastings with their schedule, price per guest, seat capacity and seats left.
- `tasting-booking`: guest booking of seats for one tasting, including validation, the seat limit and the confirmation.
- `staff-bookings`: staff sign-in with the shared password, the grouped booking overview, and cancellation of bookings.

### Modified Capabilities

None. The repository has no existing specs.

## Impact

- New project from an empty repository: a Node.js 22 TypeScript server (Express) serving a React single-page app built with Vite.
- New dependencies: express, react, react-dom, react-router, react-hook-form, @hookform/resolvers, zod, tailwindcss, cookie-session, helmet, express-rate-limit, and development tooling (vite, vitest, supertest, testing-library, typescript, tsx).
- Runtime configuration: `PORT` (default 3000) and `STAFF_PASSWORD` (required; the server refuses to start without it).
- No external services, databases or network calls beyond serving HTTP.
