# Spec Delta

## Purpose

Lets winery staff sign in with a shared password to see every booking grouped by tasting and to cancel a booking, which frees its seats again, so that the team always knows who is coming.

## ADDED Requirements

### Requirement: Staff sign in with the shared password
The page `/staff` SHALL show a sign-in form with a "Password" field and a "Sign in" button until staff are signed in. A correct password SHALL open the staff overview. An incorrect password SHALL show an error message and keep the staff signed out. The expected password SHALL come from the environment variable `STAFF_PASSWORD`.

#### Scenario: Correct password
- **WHEN** staff enter the correct password and activate "Sign in"
- **THEN** the staff overview of bookings is shown

#### Scenario: Wrong password
- **WHEN** staff enter an incorrect password and activate "Sign in"
- **THEN** an error message says that the password is incorrect
- **AND** the bookings are not shown

#### Scenario: Empty password
- **WHEN** staff activate "Sign in" without entering a password
- **THEN** an error message appears next to the Password field

### Requirement: Missing STAFF_PASSWORD disables staff sign-in only
When `STAFF_PASSWORD` is not set or is empty, the application SHALL still start and serve the guest pages. It SHALL write a startup warning that names `STAFF_PASSWORD`, and every staff sign-in attempt SHALL be refused with the message "Staff sign-in is not configured".

#### Scenario: Started without the password variable
- **WHEN** the application is started without `STAFF_PASSWORD`
- **THEN** the start page and the booking pages are served
- **AND** the startup warning names `STAFF_PASSWORD`
- **AND** a sign-in attempt at `/staff` shows "Staff sign-in is not configured" and the bookings stay hidden

### Requirement: Failed sign-in attempts are limited
The application SHALL reject sign-in attempts from a client once that client has made 10 failed sign-in attempts within 15 minutes, and SHALL tell the client that too many attempts were made. Successful sign-ins do not count as failures.

#### Scenario: Too many failed attempts
- **WHEN** a client has made 10 failed sign-in attempts within 15 minutes
- **THEN** its next sign-in attempt is rejected with a "Too many attempts" message, even with the correct password, until the window has passed

### Requirement: Booking overview is available only to signed-in staff
The staff overview and the booking data behind it SHALL be available only to staff who are signed in. Requests for the data without a valid staff session SHALL be refused.

#### Scenario: Data requested without signing in
- **WHEN** a request for the bookings arrives without a valid staff session
- **THEN** the request is refused as unauthorised
- **AND** no booking data is returned

### Requirement: Overview lists all bookings grouped by tasting
The staff overview SHALL list every booking grouped under its tasting, and SHALL show the guest's name, email, number of guests and booking reference for each booking. A tasting without bookings SHALL show "No bookings yet".

#### Scenario: Bookings grouped by tasting
- **WHEN** staff are signed in and the Riesling Evening has two bookings and the Winter Tasting has none
- **THEN** the overview has a Riesling Evening group listing both bookings with name, email, guests and reference
- **AND** the Winter Tasting group shows "No bookings yet"

### Requirement: Staff can cancel a booking
Each active booking in the staff overview SHALL have a "Cancel" button. Activating it SHALL cancel that booking so that its seats become available again for guests.

#### Scenario: Cancelling frees the seats
- **WHEN** staff cancel a booking of 3 guests for the Red Wine Cellar Tour, which had 5 seats left
- **THEN** the booking is shown as cancelled in the overview
- **AND** the Red Wine Cellar Tour shows "8 seats left" on the start page

#### Scenario: Cancelled bookings stay visible but cannot be cancelled again
- **WHEN** a booking has been cancelled
- **THEN** it remains listed in the overview marked "Cancelled"
- **AND** it no longer has a "Cancel" button

#### Scenario: Cancelling without signing in
- **WHEN** a cancel request for a booking arrives without a valid staff session
- **THEN** the request is refused as unauthorised
- **AND** the booking remains active and its seats stay taken

### Requirement: Staff can sign out
The staff overview SHALL offer a "Sign out" action that ends the staff session and returns to the sign-in form.

#### Scenario: Sign out
- **WHEN** staff activate "Sign out"
- **THEN** the sign-in form is shown again
- **AND** the bookings are no longer available until staff sign in again
