# Spec Delta

## Purpose

Lets a guest reserve seats for one wine tasting through an online form, never beyond the seats still available, and receive a booking reference as confirmation of the reservation.

## ADDED Requirements

### Requirement: Booking form for a tasting
The booking form for a tasting SHALL have the fields labelled "Name", "Email" and "Guests", a button labelled "Book", and SHALL show the tasting it books together with its date and time and price per guest.

#### Scenario: Form opened from a tasting
- **WHEN** a guest activates "Book Winter Tasting"
- **THEN** a form opens with the fields "Name", "Email" and "Guests" and a "Book" button
- **AND** the form shows "Winter Tasting", its date and time, and "EUR 28 per guest"

### Requirement: Guests field accepts 1 to 8 whole guests
The Guests field SHALL accept only whole numbers from 1 to 8. Any other value SHALL be rejected with an error message shown next to the Guests field, and no booking SHALL be created.

#### Scenario: Guests above the limit
- **WHEN** a guest enters 9 in the Guests field and submits
- **THEN** the message appears next to the Guests field
- **AND** no booking is created

#### Scenario: Guests below the limit or not a whole number
- **WHEN** a guest enters 0, -1, 2.5 or leaves the Guests field empty and submits
- **THEN** an error message appears next to the Guests field
- **AND** no booking is created

#### Scenario: Guests value that is not a number
- **WHEN** a request arrives whose guests value is text such as "3" or a boolean
- **THEN** the request is rejected with an error on the guests field
- **AND** no booking is created

### Requirement: Name and email are required and checked
The Name field SHALL be required, SHALL contain at most 100 characters after surrounding spaces are removed, and SHALL NOT be only spaces. The Email field SHALL be required, SHALL contain a syntactically valid email address of at most 254 characters. Invalid values SHALL be rejected with an error message shown next to the field concerned, and no booking SHALL be created.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty Name
- **THEN** an error message appears next to the Name field
- **AND** the Email and Guests values the guest entered are kept

#### Scenario: Invalid email
- **WHEN** a guest submits the form with the Email "anna@"
- **THEN** an error message appears next to the Email field
- **AND** no booking is created

#### Scenario: Email too long
- **WHEN** a guest submits an Email of 255 characters
- **THEN** an error message appears next to the Email field
- **AND** no booking is created

### Requirement: A booking never exceeds the seats left
A booking SHALL be accepted only if its number of guests is no more than the seats left for that tasting at the moment the booking is made. A booking that would exceed the seats left SHALL be rejected with an error message next to the Guests field stating how many seats are left, and no seats SHALL be taken.

#### Scenario: Request exceeds the seats left
- **WHEN** 2 seats are left for the Red Wine Cellar Tour and a guest books 3 guests
- **THEN** an error next to the Guests field says that only 2 seats are left
- **AND** the seats left stay at 2

#### Scenario: Request takes the last seats
- **WHEN** 2 seats are left for the Red Wine Cellar Tour and a guest books 2 guests
- **THEN** the booking is confirmed
- **AND** the Red Wine Cellar Tour then shows "Fully booked"

#### Scenario: Simultaneous requests for the last seat
- **WHEN** two guests submit a booking for 1 guest for the last seat of a tasting at the same time
- **THEN** exactly one booking is confirmed
- **AND** the other guest is told that the tasting is fully booked or that the seats left are fewer than requested

### Requirement: Successful booking shows a confirmation
After a successful booking the guest SHALL see a confirmation page with the heading "Booking confirmed", the tasting title, the number of guests, the total price and the booking reference. The total price SHALL be the price per guest multiplied by the number of guests, shown as "EUR <amount>".

#### Scenario: Confirmation content
- **WHEN** a guest books 3 guests for the Riesling Evening
- **THEN** the page has the heading "Booking confirmed"
- **AND** the page shows "Riesling Evening", "3 guests", "EUR 75" as the total price and a booking reference

#### Scenario: Confirmation can be reopened
- **WHEN** a guest opens the confirmation page for a booking reference again
- **THEN** the same confirmation content is shown

#### Scenario: Confirmation of a cancelled booking
- **WHEN** a guest opens the confirmation page for a booking that staff have cancelled
- **THEN** the page says "This booking has been cancelled"
- **AND** the page does not show the heading "Booking confirmed"

#### Scenario: Unknown booking reference
- **WHEN** a guest opens a confirmation page for a booking reference that does not exist
- **THEN** the page says that the booking was not found

### Requirement: Booking references are unique
Each confirmed booking SHALL receive a booking reference that no other booking has.

#### Scenario: Two bookings get different references
- **WHEN** two bookings are confirmed
- **THEN** their booking references are different

### Requirement: Failures are reported without losing input
If a booking cannot be completed because of a server or network error, the guest SHALL see a general error message on the form and the entered values SHALL be kept.

#### Scenario: Server error
- **WHEN** the booking request fails with a server error
- **THEN** the form shows a general error message that the booking could not be made
- **AND** the Name, Email and Guests values are still filled in

### Requirement: Unknown tasting
A booking form for a tasting that does not exist SHALL show a "Tasting not found" message instead of a form.

#### Scenario: Unknown tasting address
- **WHEN** a guest opens the booking form for a tasting that does not exist
- **THEN** the page says that the tasting was not found and offers a way back to the start page

### Requirement: Fully booked tasting has no booking form
The booking page for a tasting with no seats left SHALL show "Fully booked" and SHALL NOT show the Name, Email, Guests fields or the "Book" button.

#### Scenario: Opening the form of a fully booked tasting
- **WHEN** a guest opens the booking page for a tasting with 0 seats left
- **THEN** the page shows "Fully booked" and a way back to the start page
- **AND** no booking form is shown
