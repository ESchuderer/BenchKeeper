# Spec Delta

## Purpose

Lets guests see which wine tastings Weingut Kieselbrunnen offers, when they take place, what they cost and how many seats are still free, so that they can choose one and book it.

## ADDED Requirements

### Requirement: Start page lists every tasting
The start page SHALL list every offered tasting with its title, its date and time, its price per guest and its seats left.

#### Scenario: Three tastings are listed
- **WHEN** a guest opens the start page
- **THEN** the page shows "Riesling Evening", "Red Wine Cellar Tour" and "Winter Tasting"
- **AND** each tasting shows its date and time in readable form, for example "Friday 6 November 2026, 18:00"
- **AND** each tasting shows its price as "EUR 25 per guest", "EUR 32 per guest" or "EUR 28 per guest" respectively

#### Scenario: Seats left are shown as a count
- **WHEN** a guest opens the start page and a tasting has 9 seats left
- **THEN** that tasting shows "9 seats left"
- **AND** a tasting with exactly one seat left shows "1 seat left"

### Requirement: Seats left reflect current bookings
The seats left for a tasting SHALL equal its seat capacity minus the guests of all of its bookings that are not cancelled.

#### Scenario: Booked guests reduce seats left
- **WHEN** 3 guests have booked the Riesling Evening (capacity 12)
- **THEN** the start page shows "9 seats left" for the Riesling Evening

#### Scenario: Cancelled bookings free seats
- **WHEN** a booking of 3 guests for the Riesling Evening is cancelled
- **THEN** the start page shows "12 seats left" for the Riesling Evening again

#### Scenario: Fresh start has all seats free
- **WHEN** the application starts with no bookings
- **THEN** the Riesling Evening shows "12 seats left", the Red Wine Cellar Tour shows "8 seats left" and the Winter Tasting shows "10 seats left"

### Requirement: Fully booked tastings are clearly marked
A tasting with no seats left SHALL be shown as fully booked and SHALL NOT offer a booking action.

#### Scenario: Last seat taken
- **WHEN** the bookings for a tasting fill all of its seats
- **THEN** the tasting shows "0 seats left" together with a "Fully booked" label
- **AND** no "Book <tasting title>" link or button is shown for that tasting

### Requirement: Each tasting links to its booking form
Every tasting that still has seats left SHALL offer a link or button labelled "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Book link for an open tasting
- **WHEN** a guest views a tasting with seats left
- **THEN** the page shows a link or button labelled "Book Riesling Evening" (or the title of that tasting)
- **AND** activating it opens the booking form for that tasting
