## 1. Project setup

- [x] 1.1 Create `package.json` (Node 22 engines, `"type": "module"`, scripts: `dev:api`, `dev:web`, `build`, `start`, `test`, `test:coverage`, `typecheck`), `tsconfig.json` (shared), `tsconfig.server.json` (emits `dist/server`), `vite.config.ts` (React plugin, Tailwind plugin, `/api` proxy for dev), `vitest.config.ts` (jsdom for client tests, v8 coverage with 80% threshold)
- [x] 1.2 Install runtime dependencies (express, react, react-dom, react-router, react-hook-form, @hookform/resolvers, zod, cookie-session, helmet, express-rate-limit) and development dependencies (typescript, vite, @vitejs/plugin-react, tailwindcss, @tailwindcss/vite, vitest, @vitest/coverage-v8, supertest, jsdom, @testing-library/react, @testing-library/user-event, @testing-library/jest-dom, tsx, and the @types packages)
- [x] 1.3 Add `.gitignore` (node_modules, dist, coverage, test artefacts) and a `README.md` that covers install, build, start, environment variables (`PORT`, `STAFF_PASSWORD`, `SESSION_SECRET`, `COOKIE_SECURE`), the in-memory storage limit and the single-instance assumption

## 2. Shared rules (tests first)

- [x] 2.1 Write tests for the shared booking input schema in `src/shared/booking.test.ts`: accepts a valid name, email and guest count; rejects empty, spaces-only or over-100-character names, malformed emails and emails over 254 characters, and guest values 0, 9, 2.5, -1, "3", a boolean and empty input with a message keyed to the right field
- [x] 2.2 Write tests for the shared formatting helpers in `src/shared/format.test.ts`: formats a start time as "Friday 6 November 2026, 18:00" independent of the process time zone, formats a price as "EUR 25 per guest", and formats a total as "EUR 75"
- [x] 2.3 Implement `src/shared/booking.ts` (zod schema, field error mapping) and `src/shared/format.ts`, plus the shared types used by both sides

## 3. Catalogue, repository and booking rules (tests first)

- [x] 3.1 Write tests in `src/server/bookingService.test.ts` for: the three catalogue entries with their fixed title, time, price and capacity; seats left equal capacity minus active bookings; a booking that exceeds seats left is rejected and takes no seats; a booking that uses exactly the seats left is accepted; cancelling frees seats; cancelling twice is rejected with a conflict; references are unique over many bookings; an unknown tasting is reported as not found
- [x] 3.2 Write a test that two requests for the last seat issued in the same tick result in exactly one booking
- [x] 3.3 Implement `src/server/catalogue.ts`, `src/server/bookingRepository.ts` (in-memory, behind an interface) and `src/server/bookingService.ts` so the tests from 3.1 and 3.2 pass

## 4. HTTP API (tests first)

- [x] 4.1 Write supertest tests in `src/server/api.test.ts` for the public endpoints: `GET /api/tastings` lists three tastings with seats left; `GET /api/tastings/:id` returns 404 for an unknown id; `POST /api/tastings/:id/bookings` returns 201 with reference and total, 400 with `fields` for invalid input, 409 when guests exceed seats left, and 404 for an unknown tasting; `GET /api/bookings/:reference` never returns the guest's email; and concurrent last-seat posts yield one 201 and one 409
- [x] 4.2 Write supertest tests for the staff endpoints: `GET /api/staff/bookings` returns 401 without a session; a wrong password returns 401 with a message; the correct password returns 200 and sets a session cookie; the grouped list includes every tasting; cancel frees seats and marks the booking cancelled; cancelling twice returns 409; sign-out ends the session; more than 10 failed sign-ins in 15 minutes returns 429
- [x] 4.3 Write tests for `loadConfig`: with `STAFF_PASSWORD` missing or empty it does not throw, reports staff sign-in as disabled and lists `STAFF_PASSWORD` among the warnings; with it set, sign-in is enabled and the defaults (port 3000, cookies without the secure flag, random session secret) apply
- [x] 4.4 Implement `src/server/config.ts`, `src/server/app.ts` (`createApp` with helmet, cookie-session, JSON parsing, rate limiters, routes, JSON error handler, static files and SPA fallback for non-API GET requests; staff sign-in answers "Staff sign-in is not configured" when no password is set) and `src/server/server.ts` (entry point that reads `PORT` with default 3000, logs the startup warning when needed, and listens), so the tests in 4.1 to 4.3 pass

## 5. Interface (tests first)

- [x] 5.1 Write Testing Library tests for the start page in `src/client/pages/StartPage.test.tsx`: shows the three tastings with title, date and time, price per guest and "<n> seats left"; shows "Fully booked" with no booking link for a full tasting; shows "Book <title>" links for open tastings
- [x] 5.2 Write tests for the booking page in `src/client/pages/BookingPage.test.tsx`: shows fields "Name", "Email", "Guests" and a "Book" button; shows errors next to the field concerned for invalid input and sends nothing; shows the server's seat limit message next to Guests; keeps input and shows a general message on a server failure; navigates to confirmation on success; shows "Fully booked" with no form for a tasting with 0 seats left
- [x] 5.3 Write tests for the confirmation page in `src/client/pages/ConfirmationPage.test.tsx`: heading "Booking confirmed", tasting, guests, total and reference; "This booking has been cancelled" instead of the heading for a cancelled booking; a "not found" message for an unknown reference
- [x] 5.4 Write tests for the staff page in `src/client/pages/StaffPage.test.tsx`: sign-in form with "Password" and "Sign in"; wrong password message; grouped overview with name, email, guests and reference; "No bookings yet" for empty groups; "Cancel" marks a booking cancelled; "Sign out" returns to the form; "Staff sign-in is not configured" when the server has no password
- [x] 5.5 Implement `src/client/api.ts` (typed fetch wrapper that maps error envelopes), `src/client/App.tsx` with react-router routes and a not-found page, the four pages, and shared UI components (layout header, form field with error text, status message, tasting card), styled with Tailwind for a winery look and mobile-first layout, so the tests in 5.1 to 5.4 pass

## 6. Verification

- [x] 6.1 Run `npm run typecheck`, `npm run test:coverage` and `npm run build`; all must pass and coverage must be at least 80% lines, branches, functions and statements
- [x] 6.2 From a clean state (remove `node_modules` and `dist`), run `npm install`, `npm run build` and `npm start` with `STAFF_PASSWORD` set; confirm `/`, `/tastings/riesling-evening/book`, `/staff` and `/api/tastings` respond. Then start without `STAFF_PASSWORD`: confirm the warning is logged, guest pages still load, and staff sign-in shows "Staff sign-in is not configured"
- [x] 6.3 Check the flows in a real browser at a phone width and a desktop width: book a tasting, see the confirmation, sign in as staff, cancel, and see seats free up; take screenshots and review the layout
- [x] 6.4 Add Playwright end-to-end tests for the main guest booking flow and the staff sign-in and cancel flow, if a Chromium browser can be installed in the container; otherwise record the reason in the final report

## 7. Review and delivery

- [x] 7.1 Run a code review and a security review of the diff; fix CRITICAL and HIGH findings and re-run the tests
- [x] 7.2 Leave the work uncommitted in the working tree for the user to review; committing is done only on request
