import { defineConfig, devices } from "@playwright/test";

const PORT = Number(process.env.E2E_PORT ?? 3100);
export const E2E_STAFF_PASSWORD = "e2e-staff-password";

export default defineConfig({
  testDir: "e2e",
  // All projects share one in-memory server, so run one test at a time.
  workers: 1,
  fullyParallel: false,
  reporter: [["list"]],
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: "retain-on-failure",
  },
  projects: [
    { name: "phone", use: { ...devices["Pixel 5"] } },
    { name: "desktop", use: { ...devices["Desktop Chrome"] } },
  ],
  webServer: {
    command: "npm run build && npm start",
    url: `http://localhost:${PORT}/api/tastings`,
    env: { PORT: String(PORT), STAFF_PASSWORD: E2E_STAFF_PASSWORD },
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
