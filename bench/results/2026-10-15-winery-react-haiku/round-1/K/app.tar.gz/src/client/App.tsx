import { Route, Routes } from "react-router";
import { SiteLayout } from "./components/SiteLayout.js";
import { BookingPage } from "./pages/BookingPage.js";
import { ConfirmationPage } from "./pages/ConfirmationPage.js";
import { NotFoundPage } from "./pages/NotFoundPage.js";
import { StaffPage } from "./pages/StaffPage.js";
import { StartPage } from "./pages/StartPage.js";

/** Routes only. The router itself is supplied by main.tsx, or by the tests. */
export function App() {
  return (
    <Routes>
      <Route element={<SiteLayout />}>
        <Route index element={<StartPage />} />
        <Route path="tastings/:tastingId/book" element={<BookingPage />} />
        <Route path="bookings/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
