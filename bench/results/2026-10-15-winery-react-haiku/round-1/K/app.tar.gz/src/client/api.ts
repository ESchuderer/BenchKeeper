import type {
  ApiErrorBody,
  BookingConfirmation,
  StaffBooking,
  StaffTastingBookings,
  Tasting,
} from "../shared/types.js";
import type { BookingInput } from "../shared/booking.js";
import type { StaffLogin } from "../shared/staff.js";

export class ApiRequestError extends Error {
  readonly status: number;
  readonly fields: Partial<Record<string, string>>;

  constructor(status: number, message: string, fields: Partial<Record<string, string>> = {}) {
    super(message);
    this.name = "ApiRequestError";
    this.status = status;
    this.fields = fields;
  }
}

async function readErrorBody(response: Response): Promise<ApiErrorBody | undefined> {
  try {
    return (await response.json()) as ApiErrorBody;
  } catch {
    return undefined;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (init.body !== undefined) {
    headers["Content-Type"] = "application/json";
  }
  const response = await fetch(path, { ...init, headers });
  if (response.status === 204) {
    return undefined as T;
  }
  if (!response.ok) {
    const body = await readErrorBody(response);
    throw new ApiRequestError(
      response.status,
      body?.error.message ?? "Something went wrong. Please try again.",
      body?.error.fields,
    );
  }
  return (await response.json()) as T;
}

export const api = {
  listTastings: () => request<Tasting[]>("/api/tastings"),

  getTasting: (tastingId: string) => request<Tasting>(`/api/tastings/${encodeURIComponent(tastingId)}`),

  createBooking: (tastingId: string, input: BookingInput) =>
    request<BookingConfirmation>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
      method: "POST",
      body: JSON.stringify(input),
    }),

  getBooking: (reference: string) =>
    request<BookingConfirmation>(`/api/bookings/${encodeURIComponent(reference)}`),

  getStaffSession: () => request<{ signedIn: boolean }>("/api/staff/session"),

  signIn: (login: StaffLogin) =>
    request<{ signedIn: boolean }>("/api/staff/session", {
      method: "POST",
      body: JSON.stringify(login),
    }),

  signOut: () => request<void>("/api/staff/session", { method: "DELETE" }),

  listStaffBookings: () => request<StaffTastingBookings[]>("/api/staff/bookings"),

  cancelBooking: (reference: string) =>
    request<StaffBooking>(`/api/staff/bookings/${encodeURIComponent(reference)}/cancel`, {
      method: "POST",
    }),
};
