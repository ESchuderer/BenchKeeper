import { Link } from "react-router";

export function BackToTastings() {
  return (
    <Link to="/" className="w-fit text-oxblood underline underline-offset-4">
      Back to all tastings
    </Link>
  );
}
