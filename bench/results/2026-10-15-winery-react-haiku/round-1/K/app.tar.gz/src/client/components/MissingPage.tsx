import type { ReactNode } from "react";
import { BackToTastings } from "./BackToTastings.js";

/** A page that cannot show its usual content: a title, optional detail, and a way back. */
export function MissingPage({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <section className="flex flex-col gap-6">
      <h1 className="font-display text-4xl font-semibold text-ink">{title}</h1>
      {children}
      <BackToTastings />
    </section>
  );
}
