import type { ReactNode } from "react";

type NoticeTone = "error" | "success" | "info";

const TONE_CLASSES: Record<NoticeTone, string> = {
  error: "border-alert bg-alert-soft text-alert",
  success: "border-vine bg-vine/10 text-vine",
  info: "border-gold bg-paper text-ink",
};

/** Errors are announced as alerts; other notices as status messages. */
export function Notice({ tone, children }: { tone: NoticeTone; children: ReactNode }) {
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={`rounded-md border-l-4 px-4 py-3 text-base font-semibold ${TONE_CLASSES[tone]}`}
    >
      {children}
    </div>
  );
}
