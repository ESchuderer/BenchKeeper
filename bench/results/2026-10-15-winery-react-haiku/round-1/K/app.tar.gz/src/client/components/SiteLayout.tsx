import { Link, Outlet } from "react-router";

export function SiteLayout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-oxblood text-parchment">
        <div className="mx-auto flex max-w-4xl items-end justify-between gap-4 px-5 pt-6 pb-5">
          <Link to="/" className="rounded-sm outline-none focus-visible:ring-4 focus-visible:ring-gold/60">
            <span className="block font-display text-sm tracking-[0.3em] text-gold-light uppercase">
              Weingut
            </span>
            <span className="block font-display text-3xl leading-none font-semibold md:text-4xl">
              Kieselbrunnen
            </span>
          </Link>
          <p className="hidden font-display text-lg text-parchment/85 italic sm:block">Wine tastings</p>
        </div>
        <div className="h-1 bg-gold" aria-hidden="true" />
      </header>

      <main className="mx-auto w-full max-w-4xl flex-1 px-5 py-10 md:py-14">
        <Outlet />
      </main>

      <footer className="border-t border-gold/40 px-5 py-6 text-center text-sm text-muted">
        <p>Weingut Kieselbrunnen, a family winery</p>
        <Link
          to="/staff"
          className="mt-2 inline-flex min-h-11 items-center rounded-sm px-2 underline underline-offset-4 hover:text-oxblood focus-visible:ring-4 focus-visible:ring-oxblood/20 focus-visible:outline-none"
        >
          Staff sign-in
        </Link>
      </footer>
    </div>
  );
}
