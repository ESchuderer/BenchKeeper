import { Link } from "react-router";
import { formatPricePerGuest, formatSeatsLeft, formatStartTime } from "../../shared/format.js";
import type { Tasting } from "../../shared/types.js";

export function TastingCard({ tasting }: { tasting: Tasting }) {
  const isFullyBooked = tasting.seatsLeft === 0;

  return (
    <article
      className={`flex h-full flex-col gap-4 rounded-lg border p-6 shadow-sm ${
        isFullyBooked ? "border-stone/40 bg-parchment" : "border-gold/50 bg-paper"
      }`}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <h2 className={`font-display text-2xl leading-tight font-semibold ${isFullyBooked ? "text-muted" : "text-ink"}`}>
          {tasting.title}
        </h2>
        {isFullyBooked && (
          <span className="rounded-full bg-stone px-3 py-1 text-xs font-semibold tracking-wider text-paper uppercase">
            Fully booked
          </span>
        )}
      </div>

      <div className="flex flex-col gap-1 text-base">
        <p className="text-muted">{formatStartTime(tasting.startsAt)}</p>
        <p className="font-semibold text-ink">{formatPricePerGuest(tasting.pricePerGuestEur)}</p>
        <p className={isFullyBooked ? "font-semibold text-alert" : "text-vine"}>
          {formatSeatsLeft(tasting.seatsLeft)}
        </p>
      </div>

      {!isFullyBooked && (
        <Link
          to={`/tastings/${tasting.id}/book`}
          className="mt-auto inline-flex min-h-12 items-center justify-center rounded-md bg-oxblood px-5 font-semibold text-parchment transition hover:bg-oxblood-dark focus-visible:ring-4 focus-visible:ring-gold/60 focus-visible:outline-none"
        >
          Book {tasting.title}
        </Link>
      )}
    </article>
  );
}
