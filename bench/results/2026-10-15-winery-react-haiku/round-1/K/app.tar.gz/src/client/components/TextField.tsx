import { useId, type ComponentProps } from "react";

type TextFieldProps = ComponentProps<"input"> & {
  label: string;
  error?: string;
};

/** A labelled input that shows its error text next to it and links the two for screen readers. */
export function TextField({ label, error, id, ...inputProps }: TextFieldProps) {
  const generatedId = useId();
  const inputId = id ?? generatedId;
  const errorId = `${inputId}-error`;
  const stateClasses = error
    ? "border-alert ring-alert/20"
    : "border-stone/50 focus:border-oxblood focus:ring-oxblood/20";

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={inputId} className="text-sm font-semibold text-ink">
        {label}
      </label>
      <input
        id={inputId}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className={`min-h-12 rounded-md border bg-paper px-3.5 py-2.5 text-base text-ink outline-none transition focus:ring-4 ${stateClasses}`}
        {...inputProps}
      />
      {error && (
        <p id={errorId} className="text-sm font-semibold text-alert">
          {error}
        </p>
      )}
    </div>
  );
}
