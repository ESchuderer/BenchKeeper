export const PRIMARY_BUTTON =
  "inline-flex min-h-12 items-center justify-center rounded-md bg-oxblood px-6 font-semibold text-parchment transition hover:bg-oxblood-dark focus-visible:ring-4 focus-visible:ring-gold/60 focus-visible:outline-none disabled:cursor-wait disabled:opacity-70";
