// @vitest-environment jsdom
import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { confirmationFixture, tastingFixtures } from "../../test/fixtures.js";
import { mockFetch, requestsWithMethod } from "../../test/fetchMock.js";
import { renderApp } from "../../test/renderApp.js";

const RISLING_PATH = "/tastings/riesling-evening/book";

function serveRiesling(extra: Record<string, unknown> = {}) {
  return mockFetch((method, path) => {
    if (method === "GET" && path === "/api/tastings/riesling-evening") {
      return { status: 200, body: { ...tastingFixtures.riesling, ...extra } };
    }
    return { status: 404, body: { error: { message: "Not found" } } };
  });
}

async function fillInForm(name: string, email: string, guests: string) {
  const user = userEvent.setup();
  if (name !== "") await user.type(screen.getByLabelText("Name"), name);
  await user.type(screen.getByLabelText("Email"), email);
  await user.type(screen.getByLabelText("Guests"), guests);
  await user.click(screen.getByRole("button", { name: "Book" }));
}

describe("BookingPage", () => {
  it("shows the tasting and a form with Name, Email, Guests and a Book button", async () => {
    serveRiesling();

    renderApp(RISLING_PATH);

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByText("Friday 6 November 2026, 18:00")).toBeInTheDocument();
    expect(screen.getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("shows the error next to the field concerned and sends nothing", async () => {
    const fetchMock = serveRiesling();
    renderApp(RISLING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillInForm("Anna Keller", "anna@", "9");

    expect(await screen.findByText("Enter a valid email address")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription("Enter a valid email address");
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription("Enter between 1 and 8 guests");
    expect(requestsWithMethod(fetchMock, "POST")).toHaveLength(0);
  });

  it("shows the confirmation after a successful booking", async () => {
    const sentBodies: unknown[] = [];
    const fetchMock = mockFetch((method, path, body) => {
      if (method === "GET" && path === "/api/tastings/riesling-evening") {
        return { status: 200, body: tastingFixtures.riesling };
      }
      if (method === "POST" && path === "/api/tastings/riesling-evening/bookings") {
        sentBodies.push(body);
        return { status: 201, body: confirmationFixture };
      }
      if (method === "GET" && path === `/api/bookings/${confirmationFixture.reference}`) {
        return { status: 200, body: confirmationFixture };
      }
      return { status: 404, body: { error: { message: "Not found" } } };
    });
    renderApp(RISLING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillInForm("Anna Keller", "anna@example.de", "3");

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(sentBodies).toEqual([{ name: "Anna Keller", email: "anna@example.de", guests: 3 }]);
    expect(requestsWithMethod(fetchMock, "POST")).toHaveLength(1);
  });

  it("shows the seat limit next to the Guests field", async () => {
    mockFetch((method) => {
      if (method === "GET") return { status: 200, body: tastingFixtures.riesling };
      return {
        status: 409,
        body: {
          error: {
            message: "Only 2 seats left for this tasting",
            fields: { guests: "Only 2 seats left for this tasting" },
          },
        },
      };
    });
    renderApp(RISLING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillInForm("Anna Keller", "anna@example.de", "3");

    expect(await screen.findByText("Only 2 seats left for this tasting")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription("Only 2 seats left for this tasting");
    expect(screen.queryByRole("heading", { name: "Booking confirmed" })).not.toBeInTheDocument();
  });

  it("keeps what the guest typed and shows a general message when the server fails", async () => {
    mockFetch((method) => {
      if (method === "GET") return { status: 200, body: tastingFixtures.riesling };
      return { status: 500, body: { error: { message: "Something went wrong" } } };
    });
    renderApp(RISLING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillInForm("Anna Keller", "anna@example.de", "3");

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "We could not complete your booking. Please try again.",
    );
    expect(screen.getByLabelText("Name")).toHaveValue("Anna Keller");
    expect(screen.getByLabelText("Guests")).toHaveValue(3);
  });

  it("keeps the other values when the name is missing", async () => {
    const fetchMock = serveRiesling();
    renderApp(RISLING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillInForm("", "anna@example.de", "2");

    expect(await screen.findByText("Enter your name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toHaveValue("anna@example.de");
    expect(screen.getByLabelText("Guests")).toHaveValue(2);
    expect(requestsWithMethod(fetchMock, "POST")).toHaveLength(0);
  });

  it("rejects a fractional number of guests with a message on the Guests field", async () => {
    serveRiesling();
    renderApp(RISLING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillInForm("Anna Keller", "anna@example.de", "2.5");

    expect(await screen.findByText("Guests must be a whole number")).toBeInTheDocument();
  });

  it("reloads the tasting and shows Fully booked when the last seat goes during submission", async () => {
    let tastingReads = 0;
    mockFetch((method, path) => {
      if (method === "GET" && path === "/api/tastings/riesling-evening") {
        tastingReads += 1;
        return { status: 200, body: { ...tastingFixtures.riesling, seatsLeft: tastingReads === 1 ? 1 : 0 } };
      }
      return { status: 409, body: { error: { message: "This tasting is fully booked" } } };
    });
    renderApp(RISLING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillInForm("Anna Keller", "anna@example.de", "1");

    expect(await screen.findByText("Fully booked")).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).not.toBeInTheDocument();
  });

  it("shows Fully booked instead of the form for a tasting without seats", async () => {
    serveRiesling({ seatsLeft: 0 });

    renderApp(RISLING_PATH);

    expect(await screen.findByText("Fully booked")).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Book" })).not.toBeInTheDocument();
  });

  it("shows a not-found message for a tasting that does not exist", async () => {
    mockFetch(() => ({ status: 404, body: { error: { message: "Tasting not found" } } }));

    renderApp("/tastings/nope/book");

    expect(await screen.findByText("Tasting not found")).toBeInTheDocument();
  });
});
