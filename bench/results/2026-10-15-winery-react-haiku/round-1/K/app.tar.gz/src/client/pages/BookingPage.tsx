import { useState } from "react";
import { useForm, type FieldErrors as FormFieldErrors, type UseFormRegister } from "react-hook-form";
import { useNavigate, useParams } from "react-router";
import { zodResolver } from "@hookform/resolvers/zod";
import { api, ApiRequestError } from "../api.js";
import { BackToTastings } from "../components/BackToTastings.js";
import { MissingPage } from "../components/MissingPage.js";
import { Notice } from "../components/Notice.js";
import { PRIMARY_BUTTON } from "../components/buttonStyles.js";
import { TextField } from "../components/TextField.js";
import { bookingInputSchema, type BookingInput } from "../../shared/booking.js";
import { formatPricePerGuest, formatSeatsLeft, formatStartTime } from "../../shared/format.js";
import type { Tasting } from "../../shared/types.js";
import { useResource } from "../useResource.js";

const BOOKING_FAILED_MESSAGE = "We could not complete your booking. Please try again.";

export function BookingPage() {
  const { tastingId = "" } = useParams();
  const [version, setVersion] = useState(0);
  const tasting = useResource(`tasting:${tastingId}:${version}`, () => api.getTasting(tastingId));
  const navigate = useNavigate();

  if (tasting.status === "loading") {
    return <p className="text-muted">Loading tasting…</p>;
  }
  if (tasting.status === "not-found") {
    return <MissingPage title="Tasting not found" />;
  }
  if (tasting.status === "failed") {
    return <Notice tone="error">We could not load this tasting. Please try again later.</Notice>;
  }
  if (tasting.data.seatsLeft === 0) {
    return (
      <MissingPage title={tasting.data.title}>
        <Notice tone="error">Fully booked</Notice>
        <p className="text-muted">{formatStartTime(tasting.data.startsAt)}</p>
      </MissingPage>
    );
  }

  return (
    <div className="grid gap-10 md:grid-cols-[1fr_1.2fr]">
      <TastingSummary tasting={tasting.data} />
      <BookingForm
        tasting={tasting.data}
        onBooked={(reference) => navigate(`/bookings/${reference}`)}
        // Seats can run out while the form is open, so reload the tasting to show the current count.
        onSeatsChanged={() => setVersion((current) => current + 1)}
      />
    </div>
  );
}

function TastingSummary({ tasting }: { tasting: Tasting }) {
  return (
    <section className="flex flex-col gap-3 border-l-4 border-gold pl-5">
      <p className="font-display text-lg tracking-widest text-gold uppercase">Your tasting</p>
      <h1 className="font-display text-4xl leading-tight font-semibold text-ink">{tasting.title}</h1>
      <p className="text-lg text-muted">{formatStartTime(tasting.startsAt)}</p>
      <p className="text-lg font-semibold text-ink">{formatPricePerGuest(tasting.pricePerGuestEur)}</p>
      <p className="text-vine">{formatSeatsLeft(tasting.seatsLeft)}</p>
      <div className="pt-2">
        <BackToTastings />
      </div>
    </section>
  );
}

interface BookingFormProps {
  tasting: Tasting;
  onBooked: (reference: string) => void;
  onSeatsChanged: () => void;
}

function BookingForm({ tasting, onBooked, onSeatsChanged }: BookingFormProps) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({ resolver: zodResolver(bookingInputSchema) });
  const [formError, setFormError] = useState<string | null>(null);

  async function submitBooking(values: BookingInput) {
    setFormError(null);
    try {
      const confirmation = await api.createBooking(tasting.id, values);
      onBooked(confirmation.reference);
    } catch (error) {
      showBookingError(error);
    }
  }

  function showBookingError(error: unknown) {
    if (!(error instanceof ApiRequestError)) {
      setFormError(BOOKING_FAILED_MESSAGE);
      return;
    }
    const fieldNames = Object.keys(error.fields) as (keyof BookingInput)[];
    for (const name of fieldNames) {
      setError(name, { type: "server", message: error.fields[name] });
    }
    if (fieldNames.length === 0) {
      setFormError(error.status < 500 ? error.message : BOOKING_FAILED_MESSAGE);
    }
    if (error.status === 409) {
      onSeatsChanged();
    }
  }

  return (
    <form
      noValidate
      onSubmit={handleSubmit(submitBooking)}
      className="flex flex-col gap-5 rounded-lg border border-gold/50 bg-paper p-6 shadow-sm md:p-8"
    >
      <h2 className="font-display text-2xl font-semibold text-ink">Your details</h2>

      {formError && <Notice tone="error">{formError}</Notice>}

      <BookingFields register={register} errors={errors} />

      <button type="submit" disabled={isSubmitting} className={`${PRIMARY_BUTTON} mt-2`}>
        Book
      </button>
    </form>
  );
}

function BookingFields({
  register,
  errors,
}: {
  register: UseFormRegister<BookingInput>;
  errors: FormFieldErrors<BookingInput>;
}) {
  return (
    <>
      <TextField label="Name" autoComplete="name" error={errors.name?.message} {...register("name")} />
      <TextField
        label="Email"
        type="email"
        autoComplete="email"
        inputMode="email"
        error={errors.email?.message}
        {...register("email")}
      />
      <TextField
        label="Guests"
        type="number"
        inputMode="numeric"
        min={1}
        max={8}
        step={1}
        error={errors.guests?.message}
        {...register("guests", { valueAsNumber: true })}
      />
    </>
  );
}
