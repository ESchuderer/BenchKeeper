// @vitest-environment jsdom
import { screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { confirmationFixture } from "../../test/fixtures.js";
import { mockFetch } from "../../test/fetchMock.js";
import { renderApp } from "../../test/renderApp.js";

const CONFIRMATION_PATH = `/bookings/${confirmationFixture.reference}`;

describe("ConfirmationPage", () => {
  it("shows the heading, tasting, number of guests, total price and reference", async () => {
    mockFetch(() => ({ status: 200, body: confirmationFixture }));

    renderApp(CONFIRMATION_PATH);

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(screen.getByText("Riesling Evening")).toBeInTheDocument();
    expect(screen.getByText("3 guests")).toBeInTheDocument();
    expect(screen.getByText("EUR 75")).toBeInTheDocument();
    expect(screen.getByText(confirmationFixture.reference)).toBeInTheDocument();
  });

  it("says so when the booking has been cancelled", async () => {
    mockFetch(() => ({ status: 200, body: { ...confirmationFixture, status: "cancelled" } }));

    renderApp(CONFIRMATION_PATH);

    expect(await screen.findByText("This booking has been cancelled")).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Booking confirmed" })).not.toBeInTheDocument();
  });

  it("shows a not-found message for an unknown reference", async () => {
    mockFetch(() => ({ status: 404, body: { error: { message: "Booking not found" } } }));

    renderApp("/bookings/KB-NOPE0000");

    expect(await screen.findByText("Booking not found")).toBeInTheDocument();
  });
});
