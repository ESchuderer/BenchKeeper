import type { ReactNode } from "react";
import { useParams } from "react-router";
import { api } from "../api.js";
import { BackToTastings } from "../components/BackToTastings.js";
import { MissingPage } from "../components/MissingPage.js";
import { Notice } from "../components/Notice.js";
import { formatGuests, formatStartTime, formatTotal } from "../../shared/format.js";
import type { BookingConfirmation } from "../../shared/types.js";
import { useResource } from "../useResource.js";

export function ConfirmationPage() {
  const { reference = "" } = useParams();
  const booking = useResource(`booking:${reference}`, () => api.getBooking(reference));

  if (booking.status === "loading") {
    return <p className="text-muted">Loading your booking…</p>;
  }
  if (booking.status === "not-found") {
    return <MissingPage title="Booking not found" />;
  }
  if (booking.status === "failed") {
    return <Notice tone="error">We could not load this booking. Please try again later.</Notice>;
  }
  if (booking.data.status === "cancelled") {
    return <CancelledBooking booking={booking.data} />;
  }
  return <ConfirmedBooking booking={booking.data} />;
}

function ConfirmedBooking({ booking }: { booking: BookingConfirmation }) {
  return (
    <section className="flex flex-col gap-8">
      <div className="flex flex-col gap-3">
        <p className="font-display text-lg tracking-widest text-vine uppercase">Thank you</p>
        <h1 className="font-display text-4xl leading-tight font-semibold text-ink md:text-5xl">Booking confirmed</h1>
        <p className="text-lg text-muted">We look forward to welcoming you to the cellar.</p>
      </div>

      <dl className="grid gap-5 rounded-lg border border-gold/50 bg-paper p-6 shadow-sm sm:grid-cols-2 md:p-8">
        <Detail label="Tasting">{booking.tastingTitle}</Detail>
        <Detail label="When">{formatStartTime(booking.startsAt)}</Detail>
        <Detail label="Guests">{formatGuests(booking.guests)}</Detail>
        <Detail label="Total price">{formatTotal(booking.totalEur)}</Detail>
        <div className="sm:col-span-2">
          <Detail label="Booking reference">
            <span className="font-mono text-xl tracking-wider whitespace-nowrap">{booking.reference}</span>
          </Detail>
        </div>
      </dl>

      <p className="text-muted">Please quote your booking reference if you need to contact us about this visit.</p>
      <BackToTastings />
    </section>
  );
}

function CancelledBooking({ booking }: { booking: BookingConfirmation }) {
  return (
    <section className="flex flex-col gap-6">
      <h1 className="font-display text-4xl leading-tight font-semibold text-ink">Booking cancelled</h1>
      <Notice tone="error">This booking has been cancelled</Notice>
      <p className="text-muted">
        Booking reference <span className="font-mono">{booking.reference}</span> for {booking.tastingTitle} is no
        longer active. Please contact the winery if you think this is a mistake.
      </p>
      <BackToTastings />
    </section>
  );
}

function Detail({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <dt className="text-sm font-semibold tracking-wider text-muted uppercase">{label}</dt>
      <dd className="text-lg text-ink">{children}</dd>
    </div>
  );
}
