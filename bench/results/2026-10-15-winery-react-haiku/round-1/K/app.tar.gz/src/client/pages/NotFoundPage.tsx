import { MissingPage } from "../components/MissingPage.js";

export function NotFoundPage() {
  return (
    <MissingPage title="Page not found">
      <p className="text-muted">The page you are looking for does not exist.</p>
    </MissingPage>
  );
}
