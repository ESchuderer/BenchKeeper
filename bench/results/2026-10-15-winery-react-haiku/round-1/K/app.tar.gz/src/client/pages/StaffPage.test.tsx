// @vitest-environment jsdom
import { screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { mockFetch, requestsWithMethod } from "../../test/fetchMock.js";
import { tastingFixtures } from "../../test/fixtures.js";
import { renderApp } from "../../test/renderApp.js";
import type { StaffTastingBookings } from "../../shared/types.js";

function bookingsFixture(): StaffTastingBookings[] {
  return [
    {
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      startsAt: "2026-11-06T18:00",
      bookings: [
        { reference: "KB-AAAA2222", name: "Anna Keller", email: "anna@example.de", guests: 3, status: "confirmed" },
      ],
    },
    { ...groupFor(tastingFixtures.redWine), bookings: [] },
    { ...groupFor(tastingFixtures.winter), bookings: [] },
  ];
}

function groupFor(tasting: { id: string; title: string; startsAt: string }) {
  return { tastingId: tasting.id, tastingTitle: tasting.title, startsAt: tasting.startsAt };
}

async function signInWith(password: string) {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText("Password"), password);
  await user.click(screen.getByRole("button", { name: "Sign in" }));
}

describe("StaffPage sign-in", () => {
  it("asks for the password when staff are signed out", async () => {
    mockFetch(() => ({ status: 200, body: { signedIn: false } }));

    renderApp("/staff");

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
  });

  it("shows an error when the password is incorrect and shows no bookings", async () => {
    mockFetch((method) => {
      if (method === "GET") return { status: 200, body: { signedIn: false } };
      return { status: 401, body: { error: { message: "Incorrect password" } } };
    });
    renderApp("/staff");

    await signInWith("guess");

    expect(await screen.findByRole("alert")).toHaveTextContent("Incorrect password");
    expect(screen.queryByText("No bookings yet")).not.toBeInTheDocument();
  });

  it("asks for a password instead of sending an empty sign-in", async () => {
    const fetchMock = mockFetch(() => ({ status: 200, body: { signedIn: false } }));
    renderApp("/staff");

    await userEvent.setup().click(await screen.findByRole("button", { name: "Sign in" }));

    expect(await screen.findByText("Enter the password")).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toHaveAccessibleDescription("Enter the password");
    expect(requestsWithMethod(fetchMock, "POST")).toHaveLength(0);
  });

  it("explains that sign-in is not configured when the server has no password", async () => {
    mockFetch((method) => {
      if (method === "GET") return { status: 200, body: { signedIn: false } };
      return { status: 503, body: { error: { message: "Staff sign-in is not configured" } } };
    });
    renderApp("/staff");

    await signInWith("anything");

    expect(await screen.findByRole("alert")).toHaveTextContent("Staff sign-in is not configured");
  });
});

describe("StaffPage overview", () => {
  it("lists bookings grouped by tasting with name, email, guests and reference", async () => {
    mockFetch((_method, path) => {
      if (path === "/api/staff/session") return { status: 200, body: { signedIn: true } };
      if (path === "/api/staff/bookings") return { status: 200, body: bookingsFixture() };
      return { status: 404, body: { error: { message: "Not found" } } };
    });

    renderApp("/staff");

    const group = (await screen.findByRole("region", { name: "Riesling Evening" })) as HTMLElement;
    expect(within(group).getByText("Anna Keller")).toBeInTheDocument();
    expect(within(group).getByText("anna@example.de")).toBeInTheDocument();
    expect(within(group).getByText("3")).toBeInTheDocument();
    expect(within(group).getByText("KB-AAAA2222")).toBeInTheDocument();
  });

  it("shows No bookings yet for a tasting without bookings", async () => {
    mockFetch((_method, path) => {
      if (path === "/api/staff/session") return { status: 200, body: { signedIn: true } };
      return { status: 200, body: bookingsFixture() };
    });

    renderApp("/staff");

    const winterGroup = (await screen.findByRole("region", { name: "Winter Tasting" })) as HTMLElement;
    expect(within(winterGroup).getByText("No bookings yet")).toBeInTheDocument();
  });

  it("cancels a booking and marks it cancelled", async () => {
    const state = bookingsFixture();
    const fetchMock = mockFetch((method, path) => {
      if (path === "/api/staff/session") return { status: 200, body: { signedIn: true } };
      if (method === "GET" && path === "/api/staff/bookings") return { status: 200, body: state };
      if (method === "POST" && path === "/api/staff/bookings/KB-AAAA2222/cancel") {
        state[0].bookings[0] = { ...state[0].bookings[0], status: "cancelled" };
        return { status: 200, body: state[0].bookings[0] };
      }
      return { status: 404, body: { error: { message: "Not found" } } };
    });
    renderApp("/staff");
    const group = (await screen.findByRole("region", { name: "Riesling Evening" })) as HTMLElement;

    await userEvent.setup().click(within(group).getByRole("button", { name: "Cancel" }));

    expect(await within(group).findByText("Cancelled")).toBeInTheDocument();
    expect(within(group).queryByRole("button", { name: "Cancel" })).not.toBeInTheDocument();
    expect(requestsWithMethod(fetchMock, "POST")).toHaveLength(1);
  });

  it("returns to the sign-in form when the session has expired while loading bookings", async () => {
    mockFetch((_method, path) => {
      if (path === "/api/staff/session") return { status: 200, body: { signedIn: true } };
      if (path === "/api/staff/bookings") return { status: 401, body: { error: { message: "Sign in required" } } };
      return { status: 404, body: { error: { message: "Not found" } } };
    });

    renderApp("/staff");

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
  });

  it("reloads the list and shows the server state when a cancel is refused", async () => {
    const state = bookingsFixture();
    mockFetch((method, path) => {
      if (path === "/api/staff/session") return { status: 200, body: { signedIn: true } };
      if (method === "GET" && path === "/api/staff/bookings") return { status: 200, body: state };
      if (method === "POST" && path === "/api/staff/bookings/KB-AAAA2222/cancel") {
        // Another member of staff cancelled it a moment earlier.
        state[0].bookings[0] = { ...state[0].bookings[0], status: "cancelled" };
        return { status: 409, body: { error: { message: "This booking is already cancelled" } } };
      }
      return { status: 404, body: { error: { message: "Not found" } } };
    });
    renderApp("/staff");
    const group = (await screen.findByRole("region", { name: "Riesling Evening" })) as HTMLElement;

    await userEvent.setup().click(within(group).getByRole("button", { name: "Cancel" }));

    expect(await screen.findByText("This booking is already cancelled")).toBeInTheDocument();
    expect(await within(group).findByText("Cancelled")).toBeInTheDocument();
    expect(within(group).queryByRole("button", { name: "Cancel" })).not.toBeInTheDocument();
  });

  it("signs out and returns to the sign-in form", async () => {
    mockFetch((method, path) => {
      if (method === "DELETE" && path === "/api/staff/session") return { status: 204 };
      if (path === "/api/staff/session") return { status: 200, body: { signedIn: true } };
      if (path === "/api/staff/bookings") return { status: 200, body: bookingsFixture() };
      return { status: 404, body: { error: { message: "Not found" } } };
    });
    renderApp("/staff");
    await screen.findByRole("region", { name: "Riesling Evening" });

    await userEvent.setup().click(screen.getByRole("button", { name: "Sign out" }));

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.queryByRole("region", { name: "Riesling Evening" })).not.toBeInTheDocument();
  });
});
