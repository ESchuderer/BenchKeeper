import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { api, ApiRequestError } from "../api.js";
import { Notice } from "../components/Notice.js";
import { PRIMARY_BUTTON } from "../components/buttonStyles.js";
import { TextField } from "../components/TextField.js";
import { formatStartTime } from "../../shared/format.js";
import { staffLoginSchema, type StaffLogin } from "../../shared/staff.js";
import type { StaffBooking, StaffTastingBookings } from "../../shared/types.js";
import { useResource } from "../useResource.js";

type StaffAuth = "checking" | "signedOut" | "signedIn";

function isUnauthorised(error: unknown): boolean {
  return error instanceof ApiRequestError && error.status === 401;
}

export function StaffPage() {
  const [auth, setAuth] = useState<StaffAuth>("checking");

  useEffect(() => {
    let isCurrent = true;
    api.getStaffSession().then(
      (session) => {
        if (isCurrent) setAuth(session.signedIn ? "signedIn" : "signedOut");
      },
      () => {
        if (isCurrent) setAuth("signedOut");
      },
    );
    return () => {
      isCurrent = false;
    };
  }, []);

  if (auth === "checking") {
    return <p className="text-muted">Checking your sign-in…</p>;
  }
  if (auth === "signedOut") {
    return <SignInForm onSignedIn={() => setAuth("signedIn")} />;
  }
  return <BookingOverview onSessionEnded={() => setAuth("signedOut")} />;
}

function SignInForm({ onSignedIn }: { onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<StaffLogin>({ resolver: zodResolver(staffLoginSchema) });
  const [formError, setFormError] = useState<string | null>(null);

  async function submitPassword(values: StaffLogin) {
    setFormError(null);
    try {
      await api.signIn(values);
      onSignedIn();
    } catch (error) {
      if (error instanceof ApiRequestError && error.fields.password) {
        setError("password", { type: "server", message: error.fields.password });
        return;
      }
      setFormError(error instanceof ApiRequestError ? error.message : "We could not sign you in. Please try again.");
    }
  }

  return (
    <div className="mx-auto flex max-w-md flex-col gap-6">
      <div className="flex flex-col gap-2">
        <p className="font-display text-lg tracking-widest text-gold uppercase">Staff only</p>
        <h1 className="font-display text-4xl font-semibold text-ink">Sign in to view bookings</h1>
      </div>

      <form
        noValidate
        onSubmit={handleSubmit(submitPassword)}
        className="flex flex-col gap-5 rounded-lg border border-gold/50 bg-paper p-6 shadow-sm"
      >
        {formError && <Notice tone="error">{formError}</Notice>}
        <TextField
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          {...register("password")}
        />
        <button type="submit" disabled={isSubmitting} className={PRIMARY_BUTTON}>
          Sign in
        </button>
      </form>
    </div>
  );
}

function BookingOverview({ onSessionEnded }: { onSessionEnded: () => void }) {
  const [version, setVersion] = useState(0);
  const [isCancelling, setIsCancelling] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  // An expired session sends the staff back to sign-in instead of an error message.
  const bookings = useResource(`staff-bookings:${version}`, () =>
    api.listStaffBookings().catch((error: unknown) => {
      if (isUnauthorised(error)) onSessionEnded();
      throw error;
    }),
  );

  async function cancelBooking(reference: string) {
    setIsCancelling(true);
    setActionError(null);
    try {
      await api.cancelBooking(reference);
    } catch (error) {
      if (isUnauthorised(error)) {
        onSessionEnded();
        return;
      }
      setActionError(error instanceof ApiRequestError ? error.message : "We could not cancel this booking. Please try again.");
    }
    setIsCancelling(false);
    // Reload either way, so the list shows what the server now holds.
    setVersion((current) => current + 1);
  }

  async function signOut() {
    setActionError(null);
    try {
      await api.signOut();
      onSessionEnded();
    } catch {
      setActionError("We could not sign you out. Please try again.");
    }
  }

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-col gap-2">
          <p className="font-display text-lg tracking-widest text-gold uppercase">Staff</p>
          <h1 className="font-display text-4xl font-semibold text-ink">Bookings by tasting</h1>
        </div>
        <button
          type="button"
          onClick={signOut}
          className="min-h-11 rounded-md border border-oxblood px-5 font-semibold text-oxblood hover:bg-oxblood hover:text-parchment focus-visible:ring-4 focus-visible:ring-gold/60 focus-visible:outline-none"
        >
          Sign out
        </button>
      </header>

      {actionError && <Notice tone="error">{actionError}</Notice>}
      {bookings.status === "loading" && <p className="text-muted">Loading bookings…</p>}
      {bookings.status === "failed" && (
        <Notice tone="error">We could not load the bookings. Please try again.</Notice>
      )}
      {bookings.status === "ready" &&
        bookings.data.map((group) => (
          <TastingGroup key={group.tastingId} group={group} isCancelling={isCancelling} onCancel={cancelBooking} />
        ))}
    </div>
  );
}

function TastingGroup({
  group,
  isCancelling,
  onCancel,
}: {
  group: StaffTastingBookings;
  isCancelling: boolean;
  onCancel: (reference: string) => void;
}) {
  return (
    <section aria-label={group.tastingTitle} className="rounded-lg border border-gold/50 bg-paper shadow-sm">
      <header className="flex flex-wrap items-baseline justify-between gap-2 border-b border-gold/30 px-5 py-4">
        <h2 className="font-display text-2xl font-semibold text-ink">{group.tastingTitle}</h2>
        <p className="text-sm text-muted">{formatStartTime(group.startsAt)}</p>
      </header>

      {group.bookings.length === 0 ? (
        <p className="px-5 py-4 text-muted">No bookings yet</p>
      ) : (
        <ul className="divide-y divide-stone/20">
          {group.bookings.map((booking) => (
            <BookingRow
              key={booking.reference}
              booking={booking}
              isDisabled={isCancelling}
              onCancel={() => onCancel(booking.reference)}
            />
          ))}
        </ul>
      )}
    </section>
  );
}

function BookingRow({
  booking,
  isDisabled,
  onCancel,
}: {
  booking: StaffBooking;
  isDisabled: boolean;
  onCancel: () => void;
}) {
  const isCancelled = booking.status === "cancelled";

  return (
    <li className="flex flex-col gap-4 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <p className="font-semibold text-ink">{booking.name}</p>
        <p className="break-all text-sm text-muted">{booking.email}</p>
      </div>

      <dl className="grid grid-cols-3 gap-x-6 gap-y-2 text-sm sm:flex sm:items-center sm:gap-8">
        <div>
          <dt className="text-xs font-semibold tracking-wider text-muted uppercase">Guests</dt>
          <dd className="font-medium text-ink">{booking.guests}</dd>
        </div>
        <div>
          <dt className="text-xs font-semibold tracking-wider text-muted uppercase">Reference</dt>
          <dd className="font-mono font-medium whitespace-nowrap text-ink">{booking.reference}</dd>
        </div>
        <div>
          <dt className="text-xs font-semibold tracking-wider text-muted uppercase">Status</dt>
          <dd>
            <span
              className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                isCancelled ? "bg-stone/20 text-muted" : "bg-vine/15 text-vine"
              }`}
            >
              {isCancelled ? "Cancelled" : "Confirmed"}
            </span>
          </dd>
        </div>
      </dl>

      {!isCancelled && (
        <button
          type="button"
          disabled={isDisabled}
          onClick={onCancel}
          className="min-h-11 rounded-md border border-alert px-4 font-semibold text-alert hover:bg-alert-soft focus-visible:ring-4 focus-visible:ring-alert/20 focus-visible:outline-none disabled:opacity-60"
        >
          Cancel
        </button>
      )}
    </li>
  );
}
