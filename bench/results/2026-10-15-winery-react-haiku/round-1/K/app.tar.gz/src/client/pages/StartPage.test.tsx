// @vitest-environment jsdom
import { screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { mockFetch } from "../../test/fetchMock.js";
import { tastingFixtures } from "../../test/fixtures.js";
import { renderApp } from "../../test/renderApp.js";

const allTastings = [tastingFixtures.riesling, tastingFixtures.redWine, tastingFixtures.winter];

describe("StartPage", () => {
  it("lists each tasting with its date and time, price per guest and seats left", async () => {
    mockFetch(() => ({ status: 200, body: allTastings }));

    renderApp("/");

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Red Wine Cellar Tour" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();
    expect(screen.getByText("Friday 6 November 2026, 18:00")).toBeInTheDocument();
    expect(screen.getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(screen.getByText("9 seats left")).toBeInTheDocument();
    expect(screen.getByText("10 seats left")).toBeInTheDocument();
  });

  it("marks a fully booked tasting and offers no booking link for it", async () => {
    mockFetch(() => ({ status: 200, body: allTastings }));

    renderApp("/");

    expect(await screen.findByText("Fully booked")).toBeInTheDocument();
    expect(screen.getByText("0 seats left")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Red Wine Cellar Tour" })).not.toBeInTheDocument();
  });

  it("links each open tasting to its booking form", async () => {
    mockFetch(() => ({ status: 200, body: allTastings }));

    renderApp("/");

    const link = await screen.findByRole("link", { name: "Book Riesling Evening" });
    expect(link).toHaveAttribute("href", "/tastings/riesling-evening/book");
    expect(screen.getByRole("link", { name: "Book Winter Tasting" })).toHaveAttribute(
      "href",
      "/tastings/winter-tasting/book",
    );
  });

  it("explains when the tastings cannot be loaded", async () => {
    mockFetch(() => ({ status: 500, body: { error: { message: "boom" } } }));

    renderApp("/");

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "We could not load the tastings. Please try again later.",
    );
  });
});
