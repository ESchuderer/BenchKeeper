import { api } from "../api.js";
import { Notice } from "../components/Notice.js";
import { TastingCard } from "../components/TastingCard.js";
import { useResource } from "../useResource.js";

export function StartPage() {
  const tastings = useResource("tastings", () => api.listTastings());

  return (
    <div className="flex flex-col gap-10">
      <section className="max-w-2xl">
        <p className="font-display text-lg tracking-widest text-gold uppercase">Cellar tastings</p>
        <h1 className="mt-2 font-display text-4xl leading-tight font-semibold text-ink md:text-5xl">
          Reserve your seats for an evening in the cellar
        </h1>
        <p className="mt-4 text-lg text-muted">
          Choose a tasting, tell us who is coming, and we will confirm your places with a booking reference.
        </p>
      </section>

      {tastings.status === "loading" && <p className="text-muted">Loading tastings…</p>}

      {tastings.status === "failed" && (
        <Notice tone="error">We could not load the tastings. Please try again later.</Notice>
      )}

      {tastings.status === "ready" && (
        <ul className="grid gap-6 md:grid-cols-3">
          {tastings.data.map((tasting) => (
            <li key={tasting.id}>
              <TastingCard tasting={tasting} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
