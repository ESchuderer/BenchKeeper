import { useEffect, useState } from "react";
import { ApiRequestError } from "./api.js";

export type Resource<T> =
  | { status: "loading" }
  | { status: "ready"; data: T }
  | { status: "not-found" }
  | { status: "failed" };

/**
 * Loads data whenever `key` changes. While a reload is running, the previous
 * data stays on screen, so a refresh does not flash the page back to loading.
 */
export function useResource<T>(key: string, load: () => Promise<T>): Resource<T> {
  const [resource, setResource] = useState<Resource<T>>({ status: "loading" });

  useEffect(() => {
    let isCurrent = true;
    load().then(
      (data) => {
        if (isCurrent) setResource({ status: "ready", data });
      },
      (error: unknown) => {
        if (!isCurrent) return;
        const isMissing = error instanceof ApiRequestError && error.status === 404;
        setResource(isMissing ? { status: "not-found" } : { status: "failed" });
      },
    );
    return () => {
      isCurrent = false;
    };
    // The loader is rebuilt on every render; only the key decides when to reload.
  }, [key]);

  return resource;
}
