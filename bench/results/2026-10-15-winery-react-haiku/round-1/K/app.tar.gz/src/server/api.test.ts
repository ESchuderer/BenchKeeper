import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import request from "supertest";
import { beforeEach, describe, expect, it } from "vitest";
import { createApp } from "./app.js";
import { createInMemoryBookingRepository } from "./bookingRepository.js";
import { createBookingService } from "./bookingService.js";

const STAFF_PASSWORD = "correct horse battery staple";

const anna = { name: "Anna Keller", email: "anna@example.de", guests: 3 };

let app: ReturnType<typeof createApp>;

function buildApp(clientDir?: string) {
  const service = createBookingService(createInMemoryBookingRepository());
  return createApp({
    service,
    staffPassword: STAFF_PASSWORD,
    sessionSecret: "test-session-secret",
    cookieSecure: false,
    clientDir,
  });
}

async function signedInAgent() {
  const agent = request.agent(app);
  await agent.post("/api/staff/session").send({ password: STAFF_PASSWORD }).expect(200);
  return agent;
}

beforeEach(() => {
  app = buildApp();
});

describe("public tasting endpoints", () => {
  it("lists the three tastings with seats left", async () => {
    const response = await request(app).get("/api/tastings").expect(200);

    expect(response.body).toHaveLength(3);
    expect(response.body[0]).toMatchObject({ id: "riesling-evening", seatsLeft: 12 });
  });

  it("returns one tasting by id and 404 for an unknown id", async () => {
    const found = await request(app).get("/api/tastings/winter-tasting").expect(200);
    const missing = await request(app).get("/api/tastings/nope").expect(404);

    expect(found.body).toMatchObject({ title: "Winter Tasting", pricePerGuestEur: 28 });
    expect(missing.body.error.message).toBe("Tasting not found");
  });
});

describe("POST /api/tastings/:tastingId/bookings", () => {
  it("confirms the booking with reference, guests and total, and reduces seats left", async () => {
    const response = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send(anna)
      .expect(201);

    expect(response.body).toMatchObject({
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      guests: 3,
      totalEur: 75,
    });
    expect(response.body.reference).toMatch(/^KB-/);
    const tastings = await request(app).get("/api/tastings").expect(200);
    expect(tastings.body[0].seatsLeft).toBe(9);
  });

  it("answers 404 for an unknown tasting even when the booking details are invalid", async () => {
    await request(app).post("/api/tastings/nope/bookings").send({ name: "", email: "x", guests: 0 }).expect(404);
  });

  it("returns 400 with a message for every invalid field", async () => {
    const response = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ name: "", email: "anna@", guests: 9 })
      .expect(400);

    expect(response.body.error.fields).toEqual({
      name: "Enter your name",
      email: "Enter a valid email address",
      guests: "Enter between 1 and 8 guests",
    });
  });

  it("answers a body with a bad encoding with a client error and no server error", async () => {
    const response = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "application/json")
      .set("Content-Encoding", "gzip")
      .send("not gzip data")
      .expect(400);

    expect(response.body.error.message).toBe("The request could not be processed");
  });

  it("returns 400 when the body is not a JSON object", async () => {
    const response = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "application/json")
      .send("[1,2]")
      .expect(400);

    expect(response.body.error.message).toBeTypeOf("string");
  });

  it("returns 409 with the seats left when guests exceed them", async () => {
    await request(app)
      .post("/api/tastings/red-wine-cellar-tour/bookings")
      .send({ ...anna, guests: 7 })
      .expect(201);

    const response = await request(app)
      .post("/api/tastings/red-wine-cellar-tour/bookings")
      .send({ ...anna, guests: 2 })
      .expect(409);

    expect(response.body.error.message).toBe("Only 1 seat left for this tasting");
    expect(response.body.error.fields).toEqual({
      guests: "Only 1 seat left for this tasting",
    });
  });

  it("returns 404 for a tasting that does not exist", async () => {
    await request(app).post("/api/tastings/nope/bookings").send(anna).expect(404);
  });

  it("lets exactly one of two concurrent requests take the last seat", async () => {
    await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ ...anna, guests: 8 })
      .expect(201);
    await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ ...anna, guests: 3 })
      .expect(201);

    const responses = await Promise.all([
      request(app).post("/api/tastings/riesling-evening/bookings").send({ ...anna, guests: 1 }),
      request(app).post("/api/tastings/riesling-evening/bookings").send({ ...anna, guests: 1 }),
    ]);

    expect(responses.map((response) => response.status).sort()).toEqual([201, 409]);
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the confirmation without the guest's email", async () => {
    const created = await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send(anna)
      .expect(201);

    const response = await request(app)
      .get(`/api/bookings/${created.body.reference}`)
      .expect(200);

    expect(response.body).toMatchObject({ tastingTitle: "Winter Tasting", guests: 3, totalEur: 84 });
    expect(response.body).not.toHaveProperty("email");
    expect(response.body).not.toHaveProperty("name");
  });

  it("shows the status of a booking that staff have cancelled", async () => {
    const created = await request(app)
      .post("/api/tastings/winter-tasting/bookings")
      .send(anna)
      .expect(201);
    const agent = await signedInAgent();
    await agent.post(`/api/staff/bookings/${created.body.reference}/cancel`).expect(200);

    const response = await request(app)
      .get(`/api/bookings/${created.body.reference}`)
      .expect(200);

    expect(response.body.status).toBe("cancelled");
  });

  it("returns 404 for an unknown reference", async () => {
    await request(app).get("/api/bookings/KB-NOPE0000").expect(404);
  });
});

describe("booking input limits", () => {
  it("rejects an email of 255 characters", async () => {
    const longEmail = `${"a".repeat(244)}@example.de`;
    expect(longEmail).toHaveLength(255);

    const response = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ ...anna, email: longEmail })
      .expect(400);

    expect(response.body.error.fields).toEqual({ email: "Enter a valid email address" });
  });
});

describe("staff session", () => {
  it("reports signed out until the correct password is given", async () => {
    const before = await request(app).get("/api/staff/session").expect(200);
    const agent = request.agent(app);
    await agent.post("/api/staff/session").send({ password: "wrong" }).expect(401);
    const after = await agent.get("/api/staff/session").expect(200);

    expect(before.body).toEqual({ signedIn: false });
    expect(after.body).toEqual({ signedIn: false });
  });

  it("rejects an incorrect password with a message", async () => {
    const response = await request(app)
      .post("/api/staff/session")
      .send({ password: "guess" })
      .expect(401);

    expect(response.body.error.message).toBe("Incorrect password");
  });

  it("answers that sign-in is not configured when no staff password is set", async () => {
    const unconfigured = createApp({
      service: createBookingService(createInMemoryBookingRepository()),
      staffPassword: undefined,
      sessionSecret: "test-session-secret",
      cookieSecure: false,
    });

    const response = await request(unconfigured)
      .post("/api/staff/session")
      .send({ password: "anything" })
      .expect(503);

    expect(response.body.error.message).toBe("Staff sign-in is not configured");
  });

  it("rejects an empty password with a message on the password field", async () => {
    const response = await request(app).post("/api/staff/session").send({ password: "" }).expect(400);

    expect(response.body.error.fields).toEqual({ password: "Enter the password" });
  });

  it("sets a session cookie on success and reports signed in", async () => {
    const agent = request.agent(app);

    const signIn = await agent.post("/api/staff/session").send({ password: STAFF_PASSWORD }).expect(200);
    const session = await agent.get("/api/staff/session").expect(200);

    expect(signIn.headers["set-cookie"]?.[0]).toMatch(/HttpOnly/i);
    expect(signIn.headers["set-cookie"]?.[0]).toMatch(/SameSite=Strict/i);
    expect(session.body).toEqual({ signedIn: true });
  });

  it("ends the session on sign out", async () => {
    const agent = await signedInAgent();

    await agent.delete("/api/staff/session").expect(204);

    await agent.get("/api/staff/bookings").expect(401);
  });

  it("revokes a copied session cookie when staff sign out", async () => {
    const signIn = await request(app)
      .post("/api/staff/session")
      .send({ password: STAFF_PASSWORD })
      .expect(200);
    const setCookies = [signIn.headers["set-cookie"]].flat();
    const copiedCookie = setCookies.map((cookie) => cookie.split(";")[0]).join("; ");
    await request(app).get("/api/staff/bookings").set("Cookie", copiedCookie).expect(200);

    await request(app).delete("/api/staff/session").set("Cookie", copiedCookie).expect(204);

    await request(app).get("/api/staff/bookings").set("Cookie", copiedCookie).expect(401);
  });

  it("limits failed sign-in attempts to 10 per 15 minutes", async () => {
    for (let attempt = 0; attempt < 10; attempt += 1) {
      await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(401);
    }

    const response = await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(429);

    expect(response.body.error.message).toMatch(/Too many attempts/);
  });

  it("refuses the correct password once the limit is reached, but does not count successful sign-ins", async () => {
    for (let attempt = 0; attempt < 9; attempt += 1) {
      await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(401);
    }
    await request(app).post("/api/staff/session").send({ password: STAFF_PASSWORD }).expect(200);
    await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(401);

    await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(429);
    await request(app).post("/api/staff/session").send({ password: STAFF_PASSWORD }).expect(429);
  });

  it("explains a sign-in request that has no details", async () => {
    const response = await request(app).post("/api/staff/session").expect(400);

    expect(response.body.error.message).toBe("Sign-in details are missing.");
  });
});

describe("staff booking endpoints", () => {
  it("refuses the booking overview without a staff session", async () => {
    const response = await request(app).get("/api/staff/bookings").expect(401);

    expect(response.body.error.message).toBe("Sign in required");
  });

  it("lists all bookings grouped by tasting for signed-in staff", async () => {
    await request(app).post("/api/tastings/riesling-evening/bookings").send(anna).expect(201);
    const agent = await signedInAgent();

    const response = await agent.get("/api/staff/bookings").expect(200);

    expect(response.body).toHaveLength(3);
    expect(response.body[0]).toMatchObject({
      tastingTitle: "Riesling Evening",
      bookings: [
        expect.objectContaining({
          name: "Anna Keller",
          email: "anna@example.de",
          guests: 3,
          status: "confirmed",
        }),
      ],
    });
    expect(response.body[1].bookings).toEqual([]);
  });

  it("cancels a booking, frees its seats and refuses a second cancellation", async () => {
    const created = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send(anna)
      .expect(201);
    const agent = await signedInAgent();

    const cancelled = await agent
      .post(`/api/staff/bookings/${created.body.reference}/cancel`)
      .expect(200);
    const again = await agent
      .post(`/api/staff/bookings/${created.body.reference}/cancel`)
      .expect(409);
    const tastings = await request(app).get("/api/tastings").expect(200);

    expect(cancelled.body).toMatchObject({ reference: created.body.reference, status: "cancelled" });
    expect(again.body.error.message).toBe("This booking is already cancelled");
    expect(tastings.body[0].seatsLeft).toBe(12);
  });

  it("returns 404 when cancelling an unknown booking", async () => {
    const agent = await signedInAgent();

    await agent.post("/api/staff/bookings/KB-NOPE0000/cancel").expect(404);
  });

  it("refuses to cancel without a staff session", async () => {
    const created = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send(anna)
      .expect(201);

    await request(app).post(`/api/staff/bookings/${created.body.reference}/cancel`).expect(401);
  });
});

describe("serving the interface", () => {
  it("returns JSON 404 for unknown API paths", async () => {
    const response = await request(app).get("/api/unknown").expect(404);

    expect(response.body.error.message).toBe("Not found");
  });

  it("serves the built interface and falls back to index.html for app routes", async () => {
    const clientDir = mkdtempSync(join(tmpdir(), "kieselbrunnen-client-"));
    writeFileSync(join(clientDir, "index.html"), "<!doctype html><title>Kieselbrunnen</title>");
    const withClient = buildApp(clientDir);

    const home = await request(withClient).get("/").expect(200);
    const deepLink = await request(withClient).get("/tastings/riesling-evening/book").expect(200);

    expect(home.text).toContain("Kieselbrunnen");
    expect(deepLink.text).toContain("Kieselbrunnen");
  });

  it("sends security headers", async () => {
    const response = await request(app).get("/api/tastings").expect(200);

    expect(response.headers["x-content-type-options"]).toBe("nosniff");
    expect(response.headers["x-frame-options"]).toBeDefined();
  });
});
