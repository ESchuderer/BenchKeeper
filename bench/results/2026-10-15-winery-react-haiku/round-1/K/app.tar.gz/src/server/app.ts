import { existsSync } from "node:fs";
import { join } from "node:path";
import cookieSession from "cookie-session";
import express, { type RequestHandler } from "express";
import { rateLimit } from "express-rate-limit";
import helmet from "helmet";
import type { BookingService } from "./bookingService.js";
import { handleUnexpectedError, sendError } from "./http.js";
import { createStaffSessions } from "./staffSessions.js";
import { createPublicRouter } from "./routes/publicRoutes.js";
import { createStaffRouter } from "./routes/staffRoutes.js";

export interface AppOptions {
  service: BookingService;
  /** Undefined disables staff sign-in; every attempt is then answered with 503. */
  staffPassword: string | undefined;
  sessionSecret: string;
  cookieSecure: boolean;
  /** Number of reverse proxies in front of the app. Undefined leaves the client address as seen. */
  trustProxy?: number;
  /** Folder with the built interface. Omit it to serve the API only. */
  clientDir?: string;
}

const FIFTEEN_MINUTES_MS = 15 * 60 * 1000;
const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000;
const FAILED_SIGN_IN_LIMIT = 10;
const API_REQUEST_LIMIT = 300;
const JSON_BODY_LIMIT = "10kb";

function createApiLimiter(): RequestHandler {
  return rateLimit({
    windowMs: FIFTEEN_MINUTES_MS,
    limit: API_REQUEST_LIMIT,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { error: { message: "Too many requests. Please wait a few minutes and try again." } },
  });
}

// Only failed attempts count, so staff who sign in normally are never locked out.
function createSignInLimiter(): RequestHandler {
  return rateLimit({
    windowMs: FIFTEEN_MINUTES_MS,
    limit: FAILED_SIGN_IN_LIMIT,
    skipSuccessfulRequests: true,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { error: { message: "Too many attempts. Please wait 15 minutes and try again." } },
  });
}

function createApiRouter(options: AppOptions): express.Router {
  const api = express.Router();
  api.use(createPublicRouter(options.service));
  api.use(
    "/staff",
    createStaffRouter({
      service: options.service,
      staffPassword: options.staffPassword,
      sessions: createStaffSessions(TWELVE_HOURS_MS),
      signInLimiter: createSignInLimiter(),
    }),
  );
  api.use((_req, res) => {
    sendError(res, 404, "Not found");
  });
  return api;
}

export function createApp(options: AppOptions) {
  const app = express();
  if (options.trustProxy !== undefined) {
    app.set("trust proxy", options.trustProxy);
  }
  app.use(helmet());
  // Rate limiting runs before body parsing, so malformed requests count too.
  app.use("/api", createApiLimiter());
  app.use(express.json({ limit: JSON_BODY_LIMIT }));
  app.use(
    cookieSession({
      name: "kb_staff",
      keys: [options.sessionSecret],
      httpOnly: true,
      sameSite: "strict",
      secure: options.cookieSecure,
      maxAge: TWELVE_HOURS_MS,
    }),
  );
  app.use("/api", createApiRouter(options));

  if (options.clientDir && existsSync(join(options.clientDir, "index.html"))) {
    const indexFile = join(options.clientDir, "index.html");
    app.use(express.static(options.clientDir));
    // Client-side routes such as /staff load the same page as the start page.
    app.get("/{*path}", (_req, res) => {
      res.sendFile(indexFile);
    });
  }

  app.use(handleUnexpectedError);
  return app;
}
