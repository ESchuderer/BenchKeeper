import type { BookingStatus } from "../shared/types.js";

export interface StoredBooking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  status: BookingStatus;
}

export interface BookingRepository {
  findByReference(reference: string): StoredBooking | undefined;
  findAll(): StoredBooking[];
  /** Adds a booking, or replaces the stored booking with the same reference. */
  save(booking: StoredBooking): void;
}

/**
 * Keeps bookings in process memory. Lost on restart, which the brief accepts.
 * Callers must check seats and save in the same synchronous step; Node runs
 * one request handler at a time, so that keeps the seat limit exact.
 */
export function createInMemoryBookingRepository(): BookingRepository {
  const bookings = new Map<string, StoredBooking>();

  return {
    findByReference: (reference) => bookings.get(reference),
    findAll: () => [...bookings.values()],
    save: (booking) => {
      bookings.set(booking.reference, booking);
    },
  };
}
