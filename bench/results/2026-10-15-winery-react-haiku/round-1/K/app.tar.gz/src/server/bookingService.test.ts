import { describe, expect, it } from "vitest";
import { createInMemoryBookingRepository } from "./bookingRepository.js";
import { createBookingService } from "./bookingService.js";

const anna = { name: "Anna Keller", email: "anna@example.de" };

function setup(createReference?: () => string) {
  return createBookingService(createInMemoryBookingRepository(), { createReference });
}

function seatsLeftOf(service: ReturnType<typeof setup>, tastingId: string): number {
  const tasting = service.getTasting(tastingId);
  if (!tasting) throw new Error(`unknown tasting ${tastingId}`);
  return tasting.seatsLeft;
}

describe("catalogue", () => {
  it("lists the three tastings with their fixed titles, times, prices and seats", () => {
    const tastings = setup().listTastings();

    expect(tastings).toEqual([
      {
        id: "riesling-evening",
        title: "Riesling Evening",
        startsAt: "2026-11-06T18:00",
        pricePerGuestEur: 25,
        seats: 12,
        seatsLeft: 12,
      },
      {
        id: "red-wine-cellar-tour",
        title: "Red Wine Cellar Tour",
        startsAt: "2026-11-14T15:00",
        pricePerGuestEur: 32,
        seats: 8,
        seatsLeft: 8,
      },
      {
        id: "winter-tasting",
        title: "Winter Tasting",
        startsAt: "2026-12-05T17:00",
        pricePerGuestEur: 28,
        seats: 10,
        seatsLeft: 10,
      },
    ]);
  });

  it("returns undefined for a tasting that does not exist", () => {
    expect(setup().getTasting("no-such-tasting")).toBeUndefined();
  });
});

describe("createBooking", () => {
  it("confirms a booking with its reference, tasting and total price", () => {
    const service = setup();

    const result = service.createBooking("riesling-evening", { ...anna, guests: 3 });

    expect(result).toMatchObject({
      ok: true,
      value: {
        tastingId: "riesling-evening",
        tastingTitle: "Riesling Evening",
        startsAt: "2026-11-06T18:00",
        guests: 3,
        totalEur: 75,
      },
    });
    if (!result.ok) throw new Error("expected success");
    expect(result.value.reference).toMatch(/^KB-[2-9A-HJ-NP-Z]{8}$/);
  });

  it("reduces the seats left by the guests booked", () => {
    const service = setup();

    service.createBooking("riesling-evening", { ...anna, guests: 3 });

    expect(seatsLeftOf(service, "riesling-evening")).toBe(9);
  });

  it("rejects more guests than seats left and takes no seats", () => {
    const service = setup();
    service.createBooking("red-wine-cellar-tour", { ...anna, guests: 6 });

    const result = service.createBooking("red-wine-cellar-tour", { ...anna, guests: 3 });

    expect(result).toEqual({ ok: false, error: { code: "NOT_ENOUGH_SEATS", seatsLeft: 2 } });
    expect(seatsLeftOf(service, "red-wine-cellar-tour")).toBe(2);
  });

  it("accepts a booking for exactly the seats left and leaves the tasting full", () => {
    const service = setup();
    service.createBooking("red-wine-cellar-tour", { ...anna, guests: 6 });

    const result = service.createBooking("red-wine-cellar-tour", { ...anna, guests: 2 });

    expect(result.ok).toBe(true);
    expect(seatsLeftOf(service, "red-wine-cellar-tour")).toBe(0);
  });

  it("rejects a booking for a tasting that does not exist", () => {
    const result = setup().createBooking("no-such-tasting", { ...anna, guests: 1 });

    expect(result).toEqual({ ok: false, error: { code: "TASTING_NOT_FOUND" } });
  });

  it("gives every booking a different reference", () => {
    const service = setup();

    const references = new Set<string>();
    for (let index = 0; index < 200; index += 1) {
      const result = service.createBooking("winter-tasting", { ...anna, guests: 1 });
      if (!result.ok) throw new Error("expected success");
      references.add(result.value.reference);
      service.cancelBooking(result.value.reference);
    }

    expect(references.size).toBe(200);
  });

  it("draws another reference when the first one is already taken", () => {
    const generated = ["KB-AAAAAAAA", "KB-AAAAAAAA", "KB-BBBBBBBB"];
    const service = setup(() => generated.shift() ?? "KB-CCCCCCCC");

    const first = service.createBooking("winter-tasting", { ...anna, guests: 1 });
    const second = service.createBooking("winter-tasting", { ...anna, guests: 1 });

    expect(first).toMatchObject({ ok: true, value: { reference: "KB-AAAAAAAA" } });
    expect(second).toMatchObject({ ok: true, value: { reference: "KB-BBBBBBBB" } });
  });

  it("lets only one of two back-to-back requests take the last seat", () => {
    const service = setup();
    service.createBooking("riesling-evening", { ...anna, guests: 11 });

    const first = service.createBooking("riesling-evening", { ...anna, guests: 1 });
    const second = service.createBooking("riesling-evening", { ...anna, guests: 1 });

    expect([first.ok, second.ok].sort()).toEqual([false, true]);
    expect(second).toEqual({ ok: false, error: { code: "NOT_ENOUGH_SEATS", seatsLeft: 0 } });
    expect(seatsLeftOf(service, "riesling-evening")).toBe(0);
  });
});

describe("getBooking", () => {
  it("returns the confirmation view without the guest's personal details", () => {
    const service = setup();
    const created = service.createBooking("winter-tasting", { ...anna, guests: 2 });
    if (!created.ok) throw new Error("expected success");

    const view = service.getBooking(created.value.reference);

    expect(view).toEqual({
      reference: created.value.reference,
      tastingId: "winter-tasting",
      tastingTitle: "Winter Tasting",
      startsAt: "2026-12-05T17:00",
      guests: 2,
      totalEur: 56,
      status: "confirmed",
    });
    expect(view).not.toHaveProperty("email");
    expect(view).not.toHaveProperty("name");
  });

  it("returns undefined for a reference that does not exist", () => {
    expect(setup().getBooking("KB-NOSUCHREF")).toBeUndefined();
  });
});

describe("cancelBooking", () => {
  it("marks the booking cancelled and frees its seats", () => {
    const service = setup();
    const created = service.createBooking("red-wine-cellar-tour", { ...anna, guests: 3 });
    if (!created.ok) throw new Error("expected success");

    const result = service.cancelBooking(created.value.reference);

    expect(result).toMatchObject({
      ok: true,
      value: { reference: created.value.reference, status: "cancelled" },
    });
    expect(seatsLeftOf(service, "red-wine-cellar-tour")).toBe(8);
  });

  it("reports a booking that is already cancelled", () => {
    const service = setup();
    const created = service.createBooking("winter-tasting", { ...anna, guests: 1 });
    if (!created.ok) throw new Error("expected success");
    service.cancelBooking(created.value.reference);

    const result = service.cancelBooking(created.value.reference);

    expect(result).toEqual({ ok: false, error: { code: "ALREADY_CANCELLED" } });
  });

  it("reports a reference that does not exist", () => {
    expect(setup().cancelBooking("KB-NOSUCHREF")).toEqual({
      ok: false,
      error: { code: "BOOKING_NOT_FOUND" },
    });
  });
});

describe("listBookingsByTasting", () => {
  it("groups bookings under their tasting, keeps cancelled ones and lists empty tastings", () => {
    const service = setup();
    const annaBooking = service.createBooking("riesling-evening", { ...anna, guests: 2 });
    service.createBooking("riesling-evening", { name: "Ben Ruf", email: "ben@example.de", guests: 4 });
    if (!annaBooking.ok) throw new Error("expected success");
    service.cancelBooking(annaBooking.value.reference);

    const groups = service.listBookingsByTasting();

    expect(groups.map((group) => group.tastingId)).toEqual([
      "riesling-evening",
      "red-wine-cellar-tour",
      "winter-tasting",
    ]);
    expect(groups[0].bookings).toEqual([
      expect.objectContaining({ name: "Anna Keller", email: "anna@example.de", guests: 2, status: "cancelled" }),
      expect.objectContaining({ name: "Ben Ruf", email: "ben@example.de", guests: 4, status: "confirmed" }),
    ]);
    expect(groups[1].bookings).toEqual([]);
  });
});
