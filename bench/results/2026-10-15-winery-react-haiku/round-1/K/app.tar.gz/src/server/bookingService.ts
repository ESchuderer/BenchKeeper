import { randomInt } from "node:crypto";
import { findTastingDefinition, TASTINGS, type TastingDefinition } from "./catalogue.js";
import type { BookingRepository, StoredBooking } from "./bookingRepository.js";
import type { BookingInput } from "../shared/booking.js";
import type {
  BookingConfirmation,
  StaffBooking,
  StaffTastingBookings,
  Tasting,
} from "../shared/types.js";

export type ServiceError =
  | { code: "TASTING_NOT_FOUND" }
  | { code: "NOT_ENOUGH_SEATS"; seatsLeft: number }
  | { code: "BOOKING_NOT_FOUND" }
  | { code: "ALREADY_CANCELLED" };

export type ServiceResult<T> = { ok: true; value: T } | { ok: false; error: ServiceError };

export interface BookingServiceOptions {
  /** Produces candidate references. Defaults to a random code; tests inject their own. */
  createReference?: () => string;
}

export interface BookingService {
  listTastings(): Tasting[];
  getTasting(tastingId: string): Tasting | undefined;
  createBooking(tastingId: string, input: BookingInput): ServiceResult<BookingConfirmation>;
  getBooking(reference: string): BookingConfirmation | undefined;
  cancelBooking(reference: string): ServiceResult<StaffBooking>;
  listBookingsByTasting(): StaffTastingBookings[];
}

interface ServiceContext {
  repository: BookingRepository;
  createReference: () => string;
}

// No 0, O, 1 or I, so references read clearly when spoken or typed.
const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const REFERENCE_LENGTH = 8;
const MAX_REFERENCE_ATTEMPTS = 10;

function randomReference(): string {
  let code = "";
  for (let index = 0; index < REFERENCE_LENGTH; index += 1) {
    code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  }
  return `KB-${code}`;
}

function seatsTaken(ctx: ServiceContext, tastingId: string): number {
  return ctx.repository
    .findAll()
    .filter((booking) => booking.tastingId === tastingId && booking.status === "confirmed")
    .reduce((total, booking) => total + booking.guests, 0);
}

function seatsLeft(ctx: ServiceContext, tasting: TastingDefinition): number {
  return tasting.seats - seatsTaken(ctx, tasting.id);
}

function toTasting(ctx: ServiceContext, tasting: TastingDefinition): Tasting {
  return { ...tasting, seatsLeft: seatsLeft(ctx, tasting) };
}

function toConfirmation(booking: StoredBooking, tasting: TastingDefinition): BookingConfirmation {
  return {
    reference: booking.reference,
    tastingId: tasting.id,
    tastingTitle: tasting.title,
    startsAt: tasting.startsAt,
    guests: booking.guests,
    totalEur: booking.guests * tasting.pricePerGuestEur,
    status: booking.status,
  };
}

function toStaffBooking(booking: StoredBooking): StaffBooking {
  return {
    reference: booking.reference,
    name: booking.name,
    email: booking.email,
    guests: booking.guests,
    status: booking.status,
  };
}

function freeReference(ctx: ServiceContext): string {
  for (let attempt = 0; attempt < MAX_REFERENCE_ATTEMPTS; attempt += 1) {
    const candidate = ctx.createReference();
    if (!ctx.repository.findByReference(candidate)) {
      return candidate;
    }
  }
  throw new Error("Could not allocate a free booking reference");
}

// Check and save happen in one synchronous step, so two requests cannot both take the last seat.
function placeBooking(ctx: ServiceContext, tastingId: string, input: BookingInput): ServiceResult<BookingConfirmation> {
  const tasting = findTastingDefinition(tastingId);
  if (!tasting) {
    return { ok: false, error: { code: "TASTING_NOT_FOUND" } };
  }
  const available = seatsLeft(ctx, tasting);
  if (input.guests > available) {
    return { ok: false, error: { code: "NOT_ENOUGH_SEATS", seatsLeft: available } };
  }
  const booking: StoredBooking = {
    reference: freeReference(ctx),
    tastingId,
    name: input.name,
    email: input.email,
    guests: input.guests,
    status: "confirmed",
  };
  ctx.repository.save(booking);
  return { ok: true, value: toConfirmation(booking, tasting) };
}

function findBooking(ctx: ServiceContext, reference: string): BookingConfirmation | undefined {
  const booking = ctx.repository.findByReference(reference);
  const tasting = booking && findTastingDefinition(booking.tastingId);
  return booking && tasting ? toConfirmation(booking, tasting) : undefined;
}

function cancelStoredBooking(ctx: ServiceContext, reference: string): ServiceResult<StaffBooking> {
  const booking = ctx.repository.findByReference(reference);
  if (!booking) {
    return { ok: false, error: { code: "BOOKING_NOT_FOUND" } };
  }
  if (booking.status === "cancelled") {
    return { ok: false, error: { code: "ALREADY_CANCELLED" } };
  }
  const cancelled: StoredBooking = { ...booking, status: "cancelled" };
  ctx.repository.save(cancelled);
  return { ok: true, value: toStaffBooking(cancelled) };
}

function bookingsByTasting(ctx: ServiceContext): StaffTastingBookings[] {
  const all = ctx.repository.findAll();
  return TASTINGS.map((tasting) => ({
    tastingId: tasting.id,
    tastingTitle: tasting.title,
    startsAt: tasting.startsAt,
    bookings: all.filter((booking) => booking.tastingId === tasting.id).map(toStaffBooking),
  }));
}

export function createBookingService(
  repository: BookingRepository,
  options: BookingServiceOptions = {},
): BookingService {
  const ctx: ServiceContext = {
    repository,
    createReference: options.createReference ?? randomReference,
  };

  return {
    listTastings: () => TASTINGS.map((tasting) => toTasting(ctx, tasting)),
    getTasting(tastingId) {
      const tasting = findTastingDefinition(tastingId);
      return tasting ? toTasting(ctx, tasting) : undefined;
    },
    createBooking: (tastingId, input) => placeBooking(ctx, tastingId, input),
    getBooking: (reference) => findBooking(ctx, reference),
    cancelBooking: (reference) => cancelStoredBooking(ctx, reference),
    listBookingsByTasting: () => bookingsByTasting(ctx),
  };
}
