export interface TastingDefinition {
  id: string;
  title: string;
  startsAt: string;
  pricePerGuestEur: number;
  seats: number;
}

/** The tastings the winery offers. Fixed in code; changing them needs a deploy. */
export const TASTINGS: readonly TastingDefinition[] = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00",
    pricePerGuestEur: 25,
    seats: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00",
    pricePerGuestEur: 32,
    seats: 8,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00",
    pricePerGuestEur: 28,
    seats: 10,
  },
];

export function findTastingDefinition(tastingId: string): TastingDefinition | undefined {
  return TASTINGS.find((tasting) => tasting.id === tastingId);
}
