import { describe, expect, it } from "vitest";
import { loadConfig } from "./config.js";

describe("loadConfig", () => {
  it.each([{}, { STAFF_PASSWORD: "" }])(
    "still loads, disables staff sign-in and warns by name when STAFF_PASSWORD is missing or empty (%j)",
    (env) => {
      const config = loadConfig(env);

      expect(config.staffPassword).toBeUndefined();
      expect(config.warnings).toEqual([expect.stringContaining("STAFF_PASSWORD")]);
    },
  );

  it("uses port 3000 and cookies without the secure flag by default", () => {
    const config = loadConfig({ STAFF_PASSWORD: "a-long-enough-pw" });

    expect(config.port).toBe(3000);
    expect(config.cookieSecure).toBe(false);
    expect(config.staffPassword).toBe("a-long-enough-pw");
    expect(config.trustProxy).toBeUndefined();
    expect(config.warnings).toEqual([]);
  });

  it("warns when the staff password is shorter than 12 characters", () => {
    const config = loadConfig({ STAFF_PASSWORD: "short-pw" });

    expect(config.staffPassword).toBe("short-pw");
    expect(config.warnings).toEqual([expect.stringMatching(/shorter than 12 characters/)]);
  });

  it("reads TRUST_PROXY as a hop count", () => {
    expect(loadConfig({ STAFF_PASSWORD: "a-long-enough-pw", TRUST_PROXY: "1" }).trustProxy).toBe(1);
    expect(loadConfig({ STAFF_PASSWORD: "a-long-enough-pw", TRUST_PROXY: "0" }).trustProxy).toBe(0);
  });

  it.each(["true", "-1", "1.5"])("rejects the invalid TRUST_PROXY %s", (value) => {
    expect(() => loadConfig({ STAFF_PASSWORD: "a-long-enough-pw", TRUST_PROXY: value })).toThrow(/TRUST_PROXY/);
  });

  it("reads PORT, SESSION_SECRET and COOKIE_SECURE when given", () => {
    const config = loadConfig({
      STAFF_PASSWORD: "a-long-enough-pw",
      PORT: "8080",
      SESSION_SECRET: "secret",
      COOKIE_SECURE: "true",
    });

    expect(config.port).toBe(8080);
    expect(config.sessionSecret).toBe("secret");
    expect(config.cookieSecure).toBe(true);
  });

  it("generates a session secret when none is configured", () => {
    const first = loadConfig({ STAFF_PASSWORD: "pw" });
    const second = loadConfig({ STAFF_PASSWORD: "pw" });

    expect(first.sessionSecret).toMatch(/^[0-9a-f]{64}$/);
    expect(second.sessionSecret).not.toBe(first.sessionSecret);
  });

  it.each(["abc", "0", "70000"])("rejects the invalid PORT %s", (port) => {
    expect(() => loadConfig({ STAFF_PASSWORD: "pw", PORT: port })).toThrow(/PORT/);
  });
});
