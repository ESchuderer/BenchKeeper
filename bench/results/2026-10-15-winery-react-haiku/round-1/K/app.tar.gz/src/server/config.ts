import { randomBytes } from "node:crypto";
import { resolve } from "node:path";

export const DEFAULT_PORT = 3000;
export const MIN_STAFF_PASSWORD_LENGTH = 12;

export interface AppConfig {
  port: number;
  /** Undefined when STAFF_PASSWORD is unset or empty; staff sign-in is then disabled. */
  staffPassword: string | undefined;
  sessionSecret: string;
  cookieSecure: boolean;
  /** Reverse proxies in front of the app, as a hop count. Undefined when no proxy is used. */
  trustProxy: number | undefined;
  clientDir: string;
  /** Problems that do not stop the server, such as a missing staff password. */
  warnings: string[];
}

function parsePort(raw: string | undefined): number {
  if (raw === undefined || raw === "") {
    return DEFAULT_PORT;
  }
  const port = Number(raw);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`PORT must be a whole number between 1 and 65535, got "${raw}"`);
  }
  return port;
}

function parseTrustProxy(raw: string | undefined): number | undefined {
  if (raw === undefined || raw === "") {
    return undefined;
  }
  const hops = Number(raw);
  if (!Number.isInteger(hops) || hops < 0) {
    throw new Error(`TRUST_PROXY must be a whole number of proxy hops, got "${raw}"`);
  }
  return hops;
}

/** Reads settings from the environment. Throws only for values that are present but invalid. */
export function loadConfig(env: NodeJS.ProcessEnv): AppConfig {
  const staffPassword = env.STAFF_PASSWORD ? env.STAFF_PASSWORD : undefined;
  const warnings: string[] = [];
  if (staffPassword === undefined) {
    warnings.push("STAFF_PASSWORD is not set, so staff sign-in is disabled. Guest booking still works.");
  } else if (staffPassword.length < MIN_STAFF_PASSWORD_LENGTH) {
    warnings.push(`STAFF_PASSWORD is shorter than ${MIN_STAFF_PASSWORD_LENGTH} characters; choose a longer one.`);
  }

  return {
    port: parsePort(env.PORT),
    staffPassword,
    sessionSecret: env.SESSION_SECRET || randomBytes(32).toString("hex"),
    cookieSecure: env.COOKIE_SECURE === "true",
    trustProxy: parseTrustProxy(env.TRUST_PROXY),
    clientDir: resolve(process.cwd(), "dist", "client"),
    warnings,
  };
}
