import type { ErrorRequestHandler, Response } from "express";
import { formatSeatsLeft } from "../shared/format.js";
import type { ApiErrorBody } from "../shared/types.js";

export function sendError(res: Response, status: number, message: string, fields?: Partial<Record<string, string>>) {
  const body: ApiErrorBody = fields ? { error: { message, fields } } : { error: { message } };
  res.status(status).json(body);
}

export function sendSeatsError(res: Response, seatsLeft: number) {
  if (seatsLeft === 0) {
    sendError(res, 409, "This tasting is fully booked");
    return;
  }
  const message = `Only ${formatSeatsLeft(seatsLeft)} for this tasting`;
  sendError(res, 409, message, { guests: message });
}

export const handleUnexpectedError: ErrorRequestHandler = (error: unknown, _req, res, next) => {
  if (res.headersSent) {
    next(error);
    return;
  }
  const type = (error as { type?: unknown } | null)?.type;
  if (type === "entity.parse.failed") {
    sendError(res, 400, "Request body is not valid JSON");
    return;
  }
  if (type === "entity.too.large") {
    sendError(res, 413, "Request is too large");
    return;
  }
  const status = (error as { status?: unknown } | null)?.status;
  if (typeof status === "number" && status >= 400 && status < 500) {
    // Malformed encodings and similar client faults: not a server error, so no stack trace.
    sendError(res, status, "The request could not be processed");
    return;
  }
  console.error(error);
  sendError(res, 500, "Something went wrong. Please try again.");
};
