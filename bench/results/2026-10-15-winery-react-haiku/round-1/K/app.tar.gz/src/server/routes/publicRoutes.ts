import express from "express";
import { validateBookingInput } from "../../shared/booking.js";
import type { BookingService } from "../bookingService.js";
import { sendError, sendSeatsError } from "../http.js";

function sendInvalidBooking(res: express.Response, fields: Partial<Record<string, string>>) {
  const hasFieldErrors = Object.keys(fields).length > 0;
  sendError(
    res,
    400,
    hasFieldErrors ? "Please check the highlighted fields." : "Booking details are missing or malformed.",
    fields,
  );
}

export function createPublicRouter(service: BookingService): express.Router {
  const router = express.Router();

  router.get("/tastings", (_req, res) => {
    res.json(service.listTastings());
  });

  router.get("/tastings/:tastingId", (req, res) => {
    const tasting = service.getTasting(req.params.tastingId);
    if (!tasting) {
      sendError(res, 404, "Tasting not found");
      return;
    }
    res.json(tasting);
  });

  router.post("/tastings/:tastingId/bookings", (req, res) => {
    if (!service.getTasting(req.params.tastingId)) {
      sendError(res, 404, "Tasting not found");
      return;
    }
    const validation = validateBookingInput(req.body);
    if (!validation.ok) {
      sendInvalidBooking(res, validation.fields);
      return;
    }
    const result = service.createBooking(req.params.tastingId, validation.value);
    if (result.ok) {
      res.status(201).json(result.value);
      return;
    }
    if (result.error.code === "NOT_ENOUGH_SEATS") {
      sendSeatsError(res, result.error.seatsLeft);
      return;
    }
    sendError(res, 404, "Tasting not found");
  });

  router.get("/bookings/:reference", (req, res) => {
    const booking = service.getBooking(req.params.reference);
    if (!booking) {
      sendError(res, 404, "Booking not found");
      return;
    }
    res.json(booking);
  });

  return router;
}
