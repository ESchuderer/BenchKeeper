import { createHash, timingSafeEqual } from "node:crypto";
import express, { type NextFunction, type Request, type RequestHandler, type Response } from "express";
import { firstFieldErrors } from "../../shared/validation.js";
import { staffLoginSchema } from "../../shared/staff.js";
import type { BookingService } from "../bookingService.js";
import { sendError } from "../http.js";
import type { StaffSessions } from "../staffSessions.js";

export interface StaffRouterOptions {
  service: BookingService;
  /** Undefined disables staff sign-in; every attempt is then answered with 503. */
  staffPassword: string | undefined;
  sessions: StaffSessions;
  signInLimiter: RequestHandler;
}

function passwordMatches(candidate: string, expected: string): boolean {
  // Hashing first gives both sides the same length, which timingSafeEqual requires.
  const candidateDigest = createHash("sha256").update(candidate).digest();
  const expectedDigest = createHash("sha256").update(expected).digest();
  return timingSafeEqual(candidateDigest, expectedDigest);
}

function signIn(req: Request, res: Response, options: StaffRouterOptions) {
  if (!options.staffPassword) {
    sendError(res, 503, "Staff sign-in is not configured");
    return;
  }
  const login = staffLoginSchema.safeParse(req.body);
  if (!login.success) {
    const fields = firstFieldErrors(login.error);
    const hasFieldErrors = Object.keys(fields).length > 0;
    sendError(
      res,
      400,
      hasFieldErrors ? "Please check the highlighted fields." : "Sign-in details are missing.",
      fields,
    );
    return;
  }
  if (!passwordMatches(login.data.password, options.staffPassword)) {
    sendError(res, 401, "Incorrect password");
    return;
  }
  req.session = { ...req.session, staffSession: options.sessions.open() };
  res.json({ signedIn: true });
}

export function createStaffRouter(options: StaffRouterOptions): express.Router {
  const { service, sessions } = options;
  const router = express.Router();

  function requireStaff(req: Request, res: Response, next: NextFunction) {
    if (!sessions.isLive(req.session?.staffSession)) {
      sendError(res, 401, "Sign in required");
      return;
    }
    next();
  }

  router.get("/session", (req, res) => {
    res.json({ signedIn: sessions.isLive(req.session?.staffSession) });
  });

  router.post("/session", options.signInLimiter, (req, res) => {
    signIn(req, res, options);
  });

  router.delete("/session", (req, res) => {
    sessions.close(req.session?.staffSession);
    req.session = null;
    res.status(204).end();
  });

  router.get("/bookings", requireStaff, (_req, res) => {
    res.json(service.listBookingsByTasting());
  });

  router.post("/bookings/:reference/cancel", requireStaff, (req: Request<{ reference: string }>, res) => {
    const result = service.cancelBooking(req.params.reference);
    if (result.ok) {
      res.json(result.value);
      return;
    }
    if (result.error.code === "BOOKING_NOT_FOUND") {
      sendError(res, 404, "Booking not found");
      return;
    }
    sendError(res, 409, "This booking is already cancelled");
  });

  return router;
}
