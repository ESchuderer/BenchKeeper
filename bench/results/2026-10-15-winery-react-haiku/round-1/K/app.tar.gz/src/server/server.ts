import { createApp } from "./app.js";
import { createInMemoryBookingRepository } from "./bookingRepository.js";
import { createBookingService } from "./bookingService.js";
import { loadConfig } from "./config.js";

const config = loadConfig(process.env);

for (const warning of config.warnings) {
  console.warn(`Warning: ${warning}`);
}

const app = createApp({
  service: createBookingService(createInMemoryBookingRepository()),
  staffPassword: config.staffPassword,
  sessionSecret: config.sessionSecret,
  cookieSecure: config.cookieSecure,
  trustProxy: config.trustProxy,
  clientDir: config.clientDir,
});

app.listen(config.port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${config.port}`);
});
