import { randomUUID } from "node:crypto";

export interface StaffSessions {
  /** Starts a session and returns the id to store in the cookie. */
  open(): string;
  close(sessionId: unknown): void;
  isLive(sessionId: unknown): boolean;
}

/**
 * The cookie carries only a random id. The server remembers which ids are live,
 * so sign-out revokes a copied cookie at once, and sessions end after `maxAgeMs`.
 */
export function createStaffSessions(maxAgeMs: number): StaffSessions {
  const issuedAt = new Map<string, number>();

  return {
    open() {
      const now = Date.now();
      for (const [id, started] of issuedAt) {
        if (now - started >= maxAgeMs) issuedAt.delete(id);
      }
      const id = randomUUID();
      issuedAt.set(id, now);
      return id;
    },

    close(sessionId) {
      if (typeof sessionId === "string") issuedAt.delete(sessionId);
    },

    isLive(sessionId) {
      const started = typeof sessionId === "string" ? issuedAt.get(sessionId) : undefined;
      return started !== undefined && Date.now() - started < maxAgeMs;
    },
  };
}
