import { describe, expect, it } from "vitest";
import { validateBookingInput } from "./booking.js";

const validInput = { name: "Anna Keller", email: "anna@example.de", guests: 2 };

describe("validateBookingInput", () => {
  it("accepts a complete booking and trims the text fields", () => {
    const result = validateBookingInput({
      name: "  Anna Keller ",
      email: " anna@example.de ",
      guests: 2,
    });

    expect(result).toEqual({ ok: true, value: validInput });
  });

  it("rejects an empty name with a message on the name field", () => {
    const result = validateBookingInput({ ...validInput, name: "   " });

    expect(result).toEqual({ ok: false, fields: { name: "Enter your name" } });
  });

  it("accepts a name of exactly 100 characters and rejects 101", () => {
    expect(validateBookingInput({ ...validInput, name: "a".repeat(100) }).ok).toBe(true);
    expect(validateBookingInput({ ...validInput, name: "a".repeat(101) })).toEqual({
      ok: false,
      fields: { name: "Name must be 100 characters or fewer" },
    });
  });

  it("rejects an empty email with a message on the email field", () => {
    const result = validateBookingInput({ ...validInput, email: "" });

    expect(result).toEqual({ ok: false, fields: { email: "Enter your email address" } });
  });

  it.each(["anna@", "anna", "@example.de", "anna example@x.de"])(
    "rejects the malformed email %s",
    (email) => {
      const result = validateBookingInput({ ...validInput, email });

      expect(result).toEqual({ ok: false, fields: { email: "Enter a valid email address" } });
    },
  );

  it.each([1, 8])("accepts %i guests", (guests) => {
    expect(validateBookingInput({ ...validInput, guests }).ok).toBe(true);
  });

  it.each([0, -1, 9])("rejects %i guests as out of range", (guests) => {
    const result = validateBookingInput({ ...validInput, guests });

    expect(result).toEqual({ ok: false, fields: { guests: "Enter between 1 and 8 guests" } });
  });

  it("rejects a fractional number of guests as not a whole number", () => {
    const result = validateBookingInput({ ...validInput, guests: 2.5 });

    expect(result).toEqual({ ok: false, fields: { guests: "Guests must be a whole number" } });
  });

  it.each([Number.NaN, "3", null, undefined])(
    "rejects guests value %s with the range message",
    (guests) => {
      const result = validateBookingInput({ ...validInput, guests });

      expect(result).toEqual({ ok: false, fields: { guests: "Enter between 1 and 8 guests" } });
    },
  );

  it("reports every invalid field at once", () => {
    const result = validateBookingInput({ name: "", email: "x", guests: 0 });

    expect(result).toEqual({
      ok: false,
      fields: {
        name: "Enter your name",
        email: "Enter a valid email address",
        guests: "Enter between 1 and 8 guests",
      },
    });
  });
});
