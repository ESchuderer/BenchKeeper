import { z } from "zod";
import { firstFieldErrors } from "./validation.js";

export const MAX_GUESTS = 8;
export const MAX_NAME_LENGTH = 100;
export const MAX_EMAIL_LENGTH = 254;

const GUESTS_RANGE_MESSAGE = `Enter between 1 and ${MAX_GUESTS} guests`;

export const bookingInputSchema = z.object({
  name: z
    .string({ error: "Enter your name" })
    .trim()
    .min(1, "Enter your name")
    .max(MAX_NAME_LENGTH, `Name must be ${MAX_NAME_LENGTH} characters or fewer`),
  email: z
    .string({ error: "Enter your email address" })
    .trim()
    .min(1, "Enter your email address")
    .max(MAX_EMAIL_LENGTH, "Enter a valid email address")
    .email("Enter a valid email address"),
  guests: z
    .number({ error: GUESTS_RANGE_MESSAGE })
    .int("Guests must be a whole number")
    .min(1, GUESTS_RANGE_MESSAGE)
    .max(MAX_GUESTS, GUESTS_RANGE_MESSAGE),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;
export type BookingField = keyof BookingInput;
export type FieldErrors = Partial<Record<BookingField, string>>;

export type BookingValidation =
  | { ok: true; value: BookingInput }
  | { ok: false; fields: FieldErrors };

/** Checks booking input and returns the first message for each invalid field. */
export function validateBookingInput(input: unknown): BookingValidation {
  const result = bookingInputSchema.safeParse(input);
  if (result.success) {
    return { ok: true, value: result.data };
  }
  return { ok: false, fields: firstFieldErrors<BookingField>(result.error) };
}
