import { afterEach, describe, expect, it } from "vitest";
import {
  formatGuests,
  formatPricePerGuest,
  formatSeatsLeft,
  formatStartTime,
  formatTotal,
} from "./format.js";

const originalTimeZone = process.env.TZ;

afterEach(() => {
  if (originalTimeZone === undefined) {
    delete process.env.TZ;
  } else {
    process.env.TZ = originalTimeZone;
  }
});

describe("formatStartTime", () => {
  it("shows weekday, date and time of a wall-clock start time", () => {
    expect(formatStartTime("2026-11-06T18:00")).toBe("Friday 6 November 2026, 18:00");
  });

  it("formats the other two tastings", () => {
    expect(formatStartTime("2026-11-14T15:00")).toBe("Saturday 14 November 2026, 15:00");
    expect(formatStartTime("2026-12-05T17:00")).toBe("Saturday 5 December 2026, 17:00");
  });

  it("gives the same text whatever the process time zone is", () => {
    process.env.TZ = "America/Los_Angeles";
    const inLosAngeles = formatStartTime("2026-11-06T18:00");
    process.env.TZ = "Pacific/Auckland";
    const inAuckland = formatStartTime("2026-11-06T18:00");

    expect(inLosAngeles).toBe("Friday 6 November 2026, 18:00");
    expect(inAuckland).toBe(inLosAngeles);
  });
});

describe("price, guest and seat wording", () => {
  it("uses the singular for one guest", () => {
    expect(formatGuests(1)).toBe("1 guest");
    expect(formatGuests(3)).toBe("3 guests");
  });

  it("formats the price per guest", () => {
    expect(formatPricePerGuest(25)).toBe("EUR 25 per guest");
  });

  it("formats a total", () => {
    expect(formatTotal(75)).toBe("EUR 75");
  });

  it("uses the singular for exactly one seat", () => {
    expect(formatSeatsLeft(1)).toBe("1 seat left");
  });

  it("uses the plural for any other count", () => {
    expect(formatSeatsLeft(9)).toBe("9 seats left");
    expect(formatSeatsLeft(12)).toBe("12 seats left");
  });
});
