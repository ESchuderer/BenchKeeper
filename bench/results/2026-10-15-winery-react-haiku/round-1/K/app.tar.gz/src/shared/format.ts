const START_TIME_PATTERN = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/;

// Built in UTC so the same wall-clock time reads the same on every machine.
const DATE_FORMAT = new Intl.DateTimeFormat("en-GB", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
  timeZone: "UTC",
});

/** "2026-11-06T18:00" -> "Friday 6 November 2026, 18:00" */
export function formatStartTime(startsAt: string): string {
  const match = START_TIME_PATTERN.exec(startsAt);
  if (!match) {
    throw new Error(`Invalid start time: ${startsAt}`);
  }
  const [, year, month, day, hour, minute] = match;
  const date = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)));
  const parts = Object.fromEntries(DATE_FORMAT.formatToParts(date).map((part) => [part.type, part.value]));
  return `${parts.weekday} ${parts.day} ${parts.month} ${parts.year}, ${hour}:${minute}`;
}

export function formatPricePerGuest(priceEur: number): string {
  return `EUR ${priceEur} per guest`;
}

export function formatTotal(totalEur: number): string {
  return `EUR ${totalEur}`;
}

export function formatSeatsLeft(seatsLeft: number): string {
  return seatsLeft === 1 ? "1 seat left" : `${seatsLeft} seats left`;
}

export function formatGuests(guests: number): string {
  return guests === 1 ? "1 guest" : `${guests} guests`;
}
