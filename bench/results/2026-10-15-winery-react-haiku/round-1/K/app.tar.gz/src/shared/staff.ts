import { z } from "zod";

export const staffLoginSchema = z.object({
  password: z.string({ error: "Enter the password" }).min(1, "Enter the password"),
});

export type StaffLogin = z.infer<typeof staffLoginSchema>;
