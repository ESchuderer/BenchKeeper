/** Shared between the API and the interface. Keep this file free of runtime code. */

export type BookingStatus = "confirmed" | "cancelled";

export interface Tasting {
  id: string;
  title: string;
  /** Wall-clock start time without a time zone, e.g. "2026-11-06T18:00". */
  startsAt: string;
  pricePerGuestEur: number;
  seats: number;
  seatsLeft: number;
}

/** What a guest sees after booking, and when reopening a confirmation. */
export interface BookingConfirmation {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  totalEur: number;
  status: BookingStatus;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
  status: BookingStatus;
}

export interface StaffTastingBookings {
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  bookings: StaffBooking[];
}

export interface ApiErrorBody {
  error: {
    message: string;
    fields?: Partial<Record<string, string>>;
  };
}
