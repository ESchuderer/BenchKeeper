import { z } from "zod";

/** Returns the first message for each invalid field, keyed by field name. */
export function firstFieldErrors<Field extends string>(error: z.ZodError): Partial<Record<Field, string>> {
  const { fieldErrors } = z.flattenError(error);
  const fields: Partial<Record<Field, string>> = {};
  for (const field of Object.keys(fieldErrors) as Field[]) {
    const [firstMessage] = fieldErrors[field] ?? [];
    if (firstMessage) {
      fields[field] = firstMessage;
    }
  }
  return fields;
}
