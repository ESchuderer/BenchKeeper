import { vi } from "vitest";

export interface Reply {
  status: number;
  body?: unknown;
}

export type Handler = (method: string, path: string, body: unknown) => Reply | Promise<Reply>;

/**
 * Replaces global fetch with a stub that answers API calls through `handler`.
 * Returns the mock so tests can inspect the requests that were sent.
 */
export function mockFetch(handler: Handler) {
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const method = init?.method ?? "GET";
    const path = String(input);
    const body = typeof init?.body === "string" ? JSON.parse(init.body) : undefined;
    const reply = await handler(method, path, body);
    return new Response(reply.body === undefined ? null : JSON.stringify(reply.body), {
      status: reply.status,
      headers: { "content-type": "application/json" },
    });
  });
  vi.stubGlobal("fetch", fetchMock);
  return fetchMock;
}

export function requestsWithMethod(fetchMock: ReturnType<typeof mockFetch>, method: string) {
  return fetchMock.mock.calls.filter(([, init]) => (init?.method ?? "GET") === method);
}
