import type { BookingConfirmation, Tasting } from "../shared/types.js";

export const tastingFixtures = {
  riesling: {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00",
    pricePerGuestEur: 25,
    seats: 12,
    seatsLeft: 9,
  },
  redWine: {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00",
    pricePerGuestEur: 32,
    seats: 8,
    seatsLeft: 0,
  },
  winter: {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00",
    pricePerGuestEur: 28,
    seats: 10,
    seatsLeft: 10,
  },
} satisfies Record<string, Tasting>;

export const confirmationFixture: BookingConfirmation = {
  reference: "KB-7K4QX9MA",
  tastingId: "riesling-evening",
  tastingTitle: "Riesling Evening",
  startsAt: "2026-11-06T18:00",
  guests: 3,
  totalEur: 75,
  status: "confirmed",
};
