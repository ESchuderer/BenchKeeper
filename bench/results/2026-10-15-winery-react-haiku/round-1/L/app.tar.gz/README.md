# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff sign in to see and cancel bookings.

## Run

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start
```

Open `http://localhost:3000` (or the port in `PORT`). Staff sign-in: `/staff`.

## Environment

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | HTTP port |
| `STAFF_PASSWORD` | unset | Staff password. Unset disables staff sign-in. |
| `TRUST_PROXY` | unset | Set to `1` only when every request reaches the app through one reverse proxy that terminates HTTPS. Otherwise clients can spoof `X-Forwarded-For` and bypass the sign-in limit. |

## Behaviour

- Bookings are kept in memory: a restart clears them.
- Staff sessions last 8 hours and end on sign-out.
- Five failed sign-in attempts from one IP lock sign-in for 15 minutes.

## Scripts

- `npm run build`: client bundle to `dist/client`, server to `dist/`
- `npm start`: run the built server
- `npm test`: API tests (Vitest)
- `npm run typecheck`: TypeScript check for server and client
