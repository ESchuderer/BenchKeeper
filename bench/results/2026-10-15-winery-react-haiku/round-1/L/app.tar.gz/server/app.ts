import { randomInt } from 'node:crypto';
import cookieParser from 'cookie-parser';
import express from 'express';
import { rateLimit } from 'express-rate-limit';
import {
  bookingInput,
  fieldErrors,
  staffLogin,
  type BookingView,
  type StaffBookingGroup,
  type TastingView,
} from '../shared/api.js';
import { createSessions, passwordMatches, SESSION_COOKIE } from './staff.js';
import { tastings, type Tasting } from './tastings.js';

export type AppOptions = {
  staffPassword?: string;
  sessionTtlMs?: number;
  // Set when a reverse proxy terminates TLS and sets X-Forwarded-Proto.
  trustProxy?: boolean;
};

type Booking = {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  reference: string;
};

const HOUR_MS = 60 * 60 * 1000;
// No 0, O, 1 or I, so references read unambiguously.
const REFERENCE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function createApp({ staffPassword, sessionTtlMs = 8 * HOUR_MS, trustProxy = false }: AppOptions = {}) {
  const app = express();
  if (trustProxy) app.set('trust proxy', 1);
  app.use(express.json());
  app.use(cookieParser());

  const bookings: Booking[] = [];
  const sessions = createSessions(sessionTtlMs);

  const findTasting = (id: string) => tastings.find((t) => t.id === id);
  const seatsTaken = (tastingId: string) =>
    bookings.filter((b) => b.tastingId === tastingId).reduce((sum, b) => sum + b.guests, 0);
  const tastingView = (t: Tasting): TastingView => ({ ...t, seatsLeft: t.seats - seatsTaken(t.id) });
  const bookingView = (b: Booking): BookingView => {
    const t = findTasting(b.tastingId)!;
    return {
      reference: b.reference,
      tastingTitle: t.title,
      startsAt: t.startsAt,
      guests: b.guests,
      total: b.guests * t.pricePerGuest,
    };
  };
  const newReference = () => {
    let reference: string;
    do {
      reference = 'KB-' + Array.from({ length: 6 }, () => REFERENCE_CHARS[randomInt(REFERENCE_CHARS.length)]).join('');
    } while (bookings.some((b) => b.reference === reference));
    return reference;
  };
  const cookieOptions = (req: express.Request) => ({ httpOnly: true, sameSite: 'strict' as const, secure: req.secure, path: '/' });

  app.get('/api/tastings', (_req, res) => {
    res.json(tastings.map(tastingView));
  });

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const tasting = findTasting(req.params.id);
    if (!tasting) return res.status(404).json({ error: 'Tasting not found' });

    const input = bookingInput.safeParse(req.body);
    if (!input.success) return res.status(400).json({ errors: fieldErrors(input.error) });

    const left = tasting.seats - seatsTaken(tasting.id);
    if (left < 1) return res.status(409).json({ errors: { guests: 'This tasting is fully booked' } });
    if (input.data.guests > left) {
      return res.status(409).json({ errors: { guests: `Only ${left} ${left === 1 ? 'seat' : 'seats'} left` } });
    }

    const booking: Booking = { ...input.data, tastingId: tasting.id, reference: newReference() };
    bookings.push(booking);
    res.status(201).json(bookingView(booking));
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const booking = bookings.find((b) => b.reference === req.params.reference);
    if (!booking) return res.status(404).json({ error: 'Booking not found' });
    res.json(bookingView(booking));
  });

  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many failed attempts. Try again in 15 minutes.' },
  });

  app.post('/api/staff/session', loginLimiter, (req, res) => {
    const input = staffLogin.safeParse(req.body);
    if (!input.success || !passwordMatches(input.data.password, staffPassword)) {
      return res.status(401).json({ error: 'Wrong password' });
    }
    const token = sessions.create();
    res.cookie(SESSION_COOKIE, token, { ...cookieOptions(req), maxAge: sessionTtlMs }).status(204).end();
  });

  app.delete('/api/staff/session', (req, res) => {
    sessions.end(req.cookies[SESSION_COOKIE]);
    res.clearCookie(SESSION_COOKIE, cookieOptions(req)).status(204).end();
  });

  const requireStaff: express.RequestHandler = (req, res, next) => {
    if (sessions.isValid(req.cookies[SESSION_COOKIE])) return next();
    res.status(401).json({ error: 'Sign in to continue' });
  };

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    const groups: StaffBookingGroup[] = tastings.map((t) => ({
      tasting: tastingView(t),
      bookings: bookings
        .filter((b) => b.tastingId === t.id)
        .map(({ name, email, guests, reference }) => ({ name, email, guests, reference })),
    }));
    res.json(groups);
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => {
    const index = bookings.findIndex((b) => b.reference === req.params.reference);
    if (index === -1) return res.status(404).json({ error: 'Booking not found' });
    bookings.splice(index, 1);
    res.status(204).end();
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found' });
  });

  app.use((err: { status?: number }, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    if (!err.status || err.status >= 500) console.error(err);
    res.status(err.status ?? 500).json({ error: err.status && err.status < 500 ? 'Invalid request' : 'Server error' });
  });

  return app;
}
