import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { createApp } from './app.js';

const clientDir = join(dirname(fileURLToPath(import.meta.url)), '..', 'client');
if (!existsSync(join(clientDir, 'index.html'))) throw new Error('Client build missing: run npm run build first');

const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled');

const app = createApp({ staffPassword, trustProxy: process.env.TRUST_PROXY === '1' });
app.use(express.static(clientDir));
app.get('/{*path}', (_req, res) => {
  res.sendFile(join(clientDir, 'index.html'));
});

const port = Number(process.env.PORT ?? 3000);
app.listen(port, () => console.log(`Weingut Kieselbrunnen listening on port ${port}`));
