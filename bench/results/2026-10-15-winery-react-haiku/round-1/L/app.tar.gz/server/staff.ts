import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const SESSION_COOKIE = 'staff_session';

export function passwordMatches(given: string, expected: string | undefined): boolean {
  // Refuse all sign-ins when no password is configured.
  if (!expected) return false;
  // Hashing both sides gives equal lengths for timingSafeEqual.
  const a = createHash('sha256').update(given).digest();
  const b = createHash('sha256').update(expected).digest();
  return timingSafeEqual(a, b);
}

export function createSessions(ttlMs: number) {
  const expiresAt = new Map<string, number>();

  return {
    create(): string {
      const now = Date.now();
      for (const [token, expiry] of expiresAt) if (expiry <= now) expiresAt.delete(token);
      const token = randomBytes(32).toString('base64url');
      expiresAt.set(token, now + ttlMs);
      return token;
    },
    isValid(token: string | undefined): boolean {
      if (!token) return false;
      const expiry = expiresAt.get(token);
      if (expiry === undefined) return false;
      if (expiry <= Date.now()) {
        expiresAt.delete(token);
        return false;
      }
      return true;
    },
    end(token: string | undefined) {
      if (token) expiresAt.delete(token);
    },
  };
}
