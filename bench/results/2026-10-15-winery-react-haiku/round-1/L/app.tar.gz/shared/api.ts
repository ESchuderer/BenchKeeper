import { z } from 'zod';

export const MAX_GUESTS = 8;

export const bookingInput = z.object({
  name: z
    .string({ error: 'Enter your name' })
    .trim()
    .min(1, 'Enter your name')
    .max(100, 'Use at most 100 characters'),
  email: z
    .string({ error: 'Enter your email address' })
    .trim()
    .min(1, 'Enter your email address')
    .pipe(z.email({ error: 'Enter a valid email address' })),
  guests: z
    .number({ error: 'Enter the number of guests' })
    .int('Use a whole number of guests')
    .min(1, 'Book at least 1 guest')
    .max(MAX_GUESTS, `You can book up to ${MAX_GUESTS} guests`),
});

export type BookingInput = z.infer<typeof bookingInput>;

export const staffLogin = z.object({
  password: z.string().min(1),
});

export type TastingView = {
  id: string;
  title: string;
  startsAt: string;
  pricePerGuest: number;
  seats: number;
  seatsLeft: number;
};

export type BookingView = {
  reference: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  total: number;
};

export type StaffBooking = {
  name: string;
  email: string;
  guests: number;
  reference: string;
};

export type StaffBookingGroup = {
  tasting: TastingView;
  bookings: StaffBooking[];
};

export function fieldErrors(error: z.ZodError): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0] ?? '');
    if (field && !(field in errors)) errors[field] = issue.message;
  }
  return errors;
}
