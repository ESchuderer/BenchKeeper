import { Link, Outlet } from 'react-router';

export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b-4 border-wine bg-paper">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-4 px-4 py-5">
          <Link to="/" className="font-serif text-2xl font-bold text-wine no-underline">
            Weingut Kieselbrunnen
          </Link>
          <nav>
            <Link to="/" className="font-semibold text-ink">
              Tastings
            </Link>
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-10">
        <Outlet />
      </main>
      <footer className="border-t border-line bg-paper">
        <div className="mx-auto flex max-w-5xl justify-end px-4 py-4 text-sm">
          <Link to="/staff" className="text-muted underline-offset-4 hover:underline">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}

export function ErrorPage() {
  return (
    <p role="alert" className="mx-auto max-w-xl p-10 text-center text-danger">
      Something went wrong. Reload the page to try again.
    </p>
  );
}
