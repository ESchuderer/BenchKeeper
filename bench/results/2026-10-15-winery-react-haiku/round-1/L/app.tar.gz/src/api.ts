import type { BookingInput, BookingView, StaffBookingGroup, TastingView } from '../shared/api.js';

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly body?: { error?: string; errors?: Record<string, string> },
  ) {
    super(`Request failed with status ${status}`);
  }
}

async function request<T>(path: string, method = 'GET', json?: unknown): Promise<T> {
  const res = await fetch(path, {
    method,
    headers: json === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: json === undefined ? undefined : JSON.stringify(json),
  });
  const body = res.status === 204 ? undefined : await res.json();
  if (!res.ok) throw new ApiError(res.status, body);
  return body as T;
}

const enc = encodeURIComponent;

export const api = {
  tastings: () => request<TastingView[]>('/api/tastings'),
  book: (tastingId: string, input: BookingInput) =>
    request<BookingView>(`/api/tastings/${enc(tastingId)}/bookings`, 'POST', input),
  booking: (reference: string) => request<BookingView>(`/api/bookings/${enc(reference)}`),
  staffBookings: () => request<StaffBookingGroup[]>('/api/staff/bookings'),
  signIn: (password: string) => request<void>('/api/staff/session', 'POST', { password }),
  signOut: () => request<void>('/api/staff/session', 'DELETE'),
  cancel: (reference: string) => request<void>(`/api/staff/bookings/${enc(reference)}`, 'DELETE'),
};
