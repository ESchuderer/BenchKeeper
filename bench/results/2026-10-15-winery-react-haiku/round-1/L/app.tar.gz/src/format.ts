export function formatStart(startsAt: string) {
  const [date, time] = startsAt.split('T');
  // Noon UTC keeps the calendar day stable in every time zone.
  const day = new Date(`${date}T12:00:00Z`).toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    timeZone: 'UTC',
  });
  return `${day}, ${time}`;
}

export const formatEur = (amount: number) => `EUR ${amount}`;

export const seatsLeftLabel = (n: number) => (n === 1 ? '1 seat left' : `${n} seats left`);
