import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router';
import './index.css';
import { ErrorPage, Layout } from './Layout';
import { BookingPage, loader as bookingLoader } from './pages/BookingPage';
import { ConfirmationPage, loader as confirmationLoader } from './pages/ConfirmationPage';
import { loader as tastingsLoader, TastingsPage } from './pages/TastingsPage';
import { loader as staffLoader, StaffPage } from './pages/StaffPage';

const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    errorElement: <ErrorPage />,
    HydrateFallback: () => <p className="p-10 text-center text-muted">Loading...</p>,
    children: [
      { index: true, loader: tastingsLoader, Component: TastingsPage },
      { path: 'tastings/:id/book', loader: bookingLoader, Component: BookingPage },
      { path: 'bookings/:reference', loader: confirmationLoader, Component: ConfirmationPage },
      { path: 'staff', loader: staffLoader, Component: StaffPage },
    ],
  },
]);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);
