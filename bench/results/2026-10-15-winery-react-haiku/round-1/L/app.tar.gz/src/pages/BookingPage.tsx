import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Link, useLoaderData, useNavigate, useRevalidator, type LoaderFunctionArgs } from 'react-router';
import { api, ApiError } from '../api';
import { bookingInput, MAX_GUESTS, type BookingInput } from '../../shared/api.js';
import { formatEur, formatStart, seatsLeftLabel } from '../format';
import { describedBy, Field, inputClass } from '../Field';

export async function loader({ params }: LoaderFunctionArgs) {
  const tastings = await api.tastings();
  return tastings.find((t) => t.id === params.id) ?? null;
}

export function BookingPage() {
  const tasting = useLoaderData<typeof loader>();
  const navigate = useNavigate();
  const revalidator = useRevalidator();
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingInput),
    defaultValues: { name: '', email: '', guests: 1 },
  });

  if (!tasting) {
    return (
      <div>
        <h1 className="font-serif text-3xl text-wine">Tasting not found</h1>
        <Link to="/" className="mt-4 inline-block font-semibold">
          Back to tastings
        </Link>
      </div>
    );
  }

  const onSubmit = async (values: BookingInput) => {
    try {
      const booking = await api.book(tasting.id, values);
      navigate(`/bookings/${booking.reference}`);
    } catch (error) {
      if (error instanceof ApiError && error.body?.errors) {
        for (const [field, message] of Object.entries(error.body.errors)) {
          setError(field as keyof BookingInput, { message });
        }
        // Refresh seats left so the form limits and messages match the server.
        revalidator.revalidate();
      } else {
        setError('root', { message: 'Booking failed. Please try again.' });
      }
    }
  };

  const guestsHint = tasting.seatsLeft > 0 ? seatsLeftLabel(tasting.seatsLeft) : undefined;

  return (
    <div className="mx-auto max-w-xl">
      <h1 className="font-serif text-4xl text-wine">{tasting.title}</h1>
      <p className="mt-2 text-ink">{formatStart(tasting.startsAt)}</p>
      <p className="text-ink">{formatEur(tasting.pricePerGuest)} per guest</p>

      {tasting.seatsLeft === 0 ? (
        <p role="status" className="mt-8 rounded-md bg-sold-out-bg p-4 font-semibold text-muted">
          This tasting is fully booked.
        </p>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)} noValidate className="mt-8 space-y-5 rounded-lg border border-line bg-paper p-6">
          {errors.root && (
            <p role="alert" className="rounded-md bg-danger-bg p-3 font-medium text-danger">
              {errors.root.message}
            </p>
          )}
          <Field id="name" label="Name" error={errors.name?.message}>
            <input
              id="name"
              type="text"
              autoComplete="name"
              className={inputClass(!!errors.name)}
              aria-invalid={!!errors.name}
              aria-describedby={describedBy('name', errors.name?.message)}
              {...register('name')}
            />
          </Field>
          <Field id="email" label="Email" error={errors.email?.message}>
            <input
              id="email"
              type="email"
              autoComplete="email"
              className={inputClass(!!errors.email)}
              aria-invalid={!!errors.email}
              aria-describedby={describedBy('email', errors.email?.message)}
              {...register('email')}
            />
          </Field>
          <Field id="guests" label="Guests" error={errors.guests?.message} hint={guestsHint}>
            <input
              id="guests"
              type="number"
              inputMode="numeric"
              min={1}
              max={Math.min(MAX_GUESTS, tasting.seatsLeft)}
              step={1}
              className={inputClass(!!errors.guests)}
              aria-invalid={!!errors.guests}
              aria-describedby={describedBy('guests', errors.guests?.message, guestsHint)}
              {...register('guests', { valueAsNumber: true })}
            />
          </Field>
          <button type="submit" className="btn-primary w-full" disabled={isSubmitting}>
            Book
          </button>
        </form>
      )}
    </div>
  );
}
