import { Link, useLoaderData, type LoaderFunctionArgs } from 'react-router';
import { api, ApiError } from '../api';
import { formatEur, formatStart } from '../format';

export async function loader({ params }: LoaderFunctionArgs) {
  try {
    return await api.booking(params.reference ?? '');
  } catch (error) {
    if (error instanceof ApiError && error.status === 404) return null;
    throw error;
  }
}

export function ConfirmationPage() {
  const booking = useLoaderData<typeof loader>();

  if (!booking) {
    return (
      <div>
        <h1 className="font-serif text-3xl text-wine">Booking not found</h1>
        <Link to="/" className="mt-4 inline-block font-semibold">
          Back to tastings
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-xl rounded-lg border border-success bg-success-bg p-8">
      <h1 className="font-serif text-3xl text-success">Booking confirmed</h1>
      <dl className="mt-6 grid grid-cols-[auto_1fr] gap-x-6 gap-y-3">
        <dt className="font-semibold">Tasting</dt>
        <dd>{booking.tastingTitle}</dd>
        <dt className="font-semibold">Date and time</dt>
        <dd>{formatStart(booking.startsAt)}</dd>
        <dt className="font-semibold">Guests</dt>
        <dd>{booking.guests}</dd>
        <dt className="font-semibold">Total</dt>
        <dd>{formatEur(booking.total)}</dd>
        <dt className="font-semibold">Booking reference</dt>
        <dd className="font-mono text-lg font-bold">{booking.reference}</dd>
      </dl>
      <Link to="/" className="mt-8 inline-block font-semibold text-wine">
        Back to tastings
      </Link>
    </div>
  );
}
