import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useLoaderData, useRevalidator } from 'react-router';
import { api, ApiError } from '../api';
import type { StaffBookingGroup } from '../../shared/api.js';
import { formatStart, seatsLeftLabel } from '../format';
import { describedBy, Field, inputClass } from '../Field';

export async function loader() {
  try {
    return await api.staffBookings();
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) return null;
    throw error;
  }
}

export function StaffPage() {
  const groups = useLoaderData<typeof loader>();
  const revalidator = useRevalidator();
  const [notice, setNotice] = useState('');

  const refresh = () => revalidator.revalidate();

  if (!groups) {
    return (
      <SignIn
        notice={notice}
        onSignedIn={() => {
          setNotice('');
          refresh();
        }}
      />
    );
  }

  const signOut = async () => {
    await api.signOut();
    setNotice('');
    refresh();
  };

  const cancel = async (reference: string) => {
    try {
      await api.cancel(reference);
      setNotice('');
    } catch (error) {
      // 404 means a previous click already cancelled it, so the refreshed list is the truth.
      if (error instanceof ApiError && error.status === 404) setNotice('');
      else if (error instanceof ApiError && error.status === 401) setNotice('Your session has ended. Sign in again.');
      else setNotice('The booking could not be cancelled. Try again.');
    }
    refresh();
  };

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-serif text-4xl text-wine">Bookings</h1>
        <button type="button" className="btn-secondary" onClick={signOut}>
          Sign out
        </button>
      </div>
      {notice && (
        <p role="alert" className="mt-6 rounded-md bg-danger-bg p-3 font-medium text-danger">
          {notice}
        </p>
      )}
      <div className="mt-8 space-y-10">
        {groups.map((group) => (
          <TastingBookings key={group.tasting.id} group={group} onCancel={cancel} />
        ))}
      </div>
    </>
  );
}

function TastingBookings({ group, onCancel }: { group: StaffBookingGroup; onCancel: (reference: string) => void }) {
  const { tasting, bookings } = group;
  const booked = tasting.seats - tasting.seatsLeft;

  return (
    <section aria-labelledby={`tasting-${tasting.id}`}>
      <h2 id={`tasting-${tasting.id}`} className="font-serif text-2xl text-wine">
        {tasting.title}
      </h2>
      <p className="mt-1 text-ink">{formatStart(tasting.startsAt)}</p>
      <p className="text-muted">
        {booked} of {tasting.seats} seats booked, {seatsLeftLabel(tasting.seatsLeft)}
      </p>
      {bookings.length === 0 ? (
        <p className="mt-4 text-muted">No bookings yet.</p>
      ) : (
        <div className="mt-4 overflow-x-auto rounded-lg border border-line bg-paper">
          <table className="w-full min-w-[36rem] text-left text-sm">
            <thead className="bg-parchment">
              <tr>
                <th scope="col" className="px-4 py-3 font-semibold">Name</th>
                <th scope="col" className="px-4 py-3 font-semibold">Email</th>
                <th scope="col" className="px-4 py-3 font-semibold">Guests</th>
                <th scope="col" className="px-4 py-3 font-semibold">Reference</th>
                <th scope="col" className="px-4 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b.reference} className="border-t border-line">
                  <td className="px-4 py-3">{b.name}</td>
                  <td className="px-4 py-3">{b.email}</td>
                  <td className="px-4 py-3">{b.guests}</td>
                  <td className="px-4 py-3 font-mono">{b.reference}</td>
                  <td className="px-4 py-3 text-right">
                    <button type="button" className="btn-danger" onClick={() => onCancel(b.reference)}>
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function SignIn({ notice, onSignedIn }: { notice: string; onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } });

  const onSubmit = async ({ password }: { password: string }) => {
    try {
      await api.signIn(password);
      onSignedIn();
    } catch (error) {
      const message = error instanceof ApiError ? error.body?.error : undefined;
      setError('password', { message: message ?? 'Sign-in failed. Try again.' });
    }
  };

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="font-serif text-4xl text-wine">Staff sign-in</h1>
      {notice && (
        <p role="alert" className="mt-6 rounded-md bg-danger-bg p-3 font-medium text-danger">
          {notice}
        </p>
      )}
      <form onSubmit={handleSubmit(onSubmit)} noValidate className="mt-8 space-y-5 rounded-lg border border-line bg-paper p-6">
        <Field id="password" label="Password" error={errors.password?.message}>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className={inputClass(!!errors.password)}
            aria-invalid={!!errors.password}
            aria-describedby={describedBy('password', errors.password?.message)}
            {...register('password', { required: 'Enter the password' })}
          />
        </Field>
        <button type="submit" className="btn-primary w-full" disabled={isSubmitting}>
          Sign in
        </button>
      </form>
    </div>
  );
}
