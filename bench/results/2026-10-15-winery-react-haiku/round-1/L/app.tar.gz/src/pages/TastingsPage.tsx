import { Link, useLoaderData } from 'react-router';
import { api } from '../api';
import { formatEur, formatStart, seatsLeftLabel } from '../format';

export function loader() {
  return api.tastings();
}

export function TastingsPage() {
  const tastings = useLoaderData<typeof loader>();

  return (
    <>
      <h1 className="font-serif text-4xl text-wine">Tastings</h1>
      <p className="mt-2 max-w-2xl text-muted">Choose a tasting and reserve your seats.</p>
      <ul className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {tastings.map((t) => {
          const full = t.seatsLeft === 0;
          return (
            <li key={t.id} className="flex flex-col rounded-lg border border-line bg-paper p-6 shadow-sm">
              <h2 className="font-serif text-2xl text-wine">{t.title}</h2>
              <p className="mt-3 text-ink">{formatStart(t.startsAt)}</p>
              <p className="mt-1 text-ink">{formatEur(t.pricePerGuest)} per guest</p>
              <p className="mt-4">
                {full ? (
                  <span className="inline-block rounded-full bg-sold-out-bg px-3 py-1 text-sm font-semibold text-muted">
                    Fully booked
                  </span>
                ) : (
                  <span className="font-semibold text-vine">{seatsLeftLabel(t.seatsLeft)}</span>
                )}
              </p>
              {!full && (
                <div className="mt-auto pt-6">
                  <Link to={`/tastings/${t.id}/book`} className="btn-primary w-full">
                    Book {t.title}
                  </Link>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </>
  );
}
