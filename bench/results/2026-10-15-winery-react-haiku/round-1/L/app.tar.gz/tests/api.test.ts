import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../server/app.js';

const PASSWORD = 'correct-horse';

function setup(options: Parameters<typeof createApp>[0] = { staffPassword: PASSWORD }) {
  return createApp(options);
}

async function signIn(app: ReturnType<typeof setup>, password = PASSWORD) {
  const res = await request(app).post('/api/staff/session').send({ password });
  expect(res.status).toBe(204);
  const cookie = res.headers['set-cookie'][0].split(';')[0];
  return cookie;
}

async function book(app: ReturnType<typeof setup>, tastingId: string, guests: number) {
  return request(app)
    .post(`/api/tastings/${tastingId}/bookings`)
    .send({ name: 'Ada Lovelace', email: 'ada@example.com', guests });
}

async function seatsLeft(app: ReturnType<typeof setup>, tastingId: string) {
  const res = await request(app).get('/api/tastings');
  return res.body.find((t: { id: string }) => t.id === tastingId).seatsLeft;
}

describe('tastings', () => {
  it('lists the three tastings with all seats free', async () => {
    const res = await request(setup()).get('/api/tastings');
    expect(res.status).toBe(200);
    expect(res.body).toEqual([
      expect.objectContaining({ id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuest: 25, seats: 12, seatsLeft: 12 }),
      expect.objectContaining({ id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuest: 32, seats: 8, seatsLeft: 8 }),
      expect.objectContaining({ id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuest: 28, seats: 10, seatsLeft: 10 }),
    ]);
  });

  it('confirms a booking with a reference, guests and total', async () => {
    const app = setup();
    const res = await book(app, 'riesling-evening', 2);
    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(/^KB-[A-HJ-NP-Z2-9]{6}$/),
      tastingTitle: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      guests: 2,
      total: 50,
    });
    expect(await seatsLeft(app, 'riesling-evening')).toBe(10);
  });

  it('serves a booking by reference without the guest email', async () => {
    const app = setup();
    const created = await book(app, 'winter-tasting', 3);
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual(created.body);
    expect(JSON.stringify(res.body)).not.toContain('ada@example.com');
    expect((await request(app).get('/api/bookings/KB-NOPE00')).status).toBe(404);
  });

  it('rejects more guests than seats left and keeps the seats unchanged', async () => {
    const app = setup();
    await book(app, 'red-wine-cellar-tour', 6);
    const res = await book(app, 'red-wine-cellar-tour', 3);
    expect(res.status).toBe(409);
    expect(res.body.errors).toEqual({ guests: 'Only 2 seats left' });
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(2);
  });

  it('uses the singular for a single seat left', async () => {
    const app = setup();
    await book(app, 'red-wine-cellar-tour', 7);
    const res = await book(app, 'red-wine-cellar-tour', 2);
    expect(res.body.errors).toEqual({ guests: 'Only 1 seat left' });
  });

  it('refuses bookings for a fully booked tasting', async () => {
    const app = setup();
    await book(app, 'red-wine-cellar-tour', 8);
    const res = await book(app, 'red-wine-cellar-tour', 1);
    expect(res.status).toBe(409);
    expect(res.body.errors).toEqual({ guests: 'This tasting is fully booked' });
  });

  it('returns a message for each invalid field', async () => {
    const app = setup();
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: '   ', email: 'not-an-email', guests: 0 });
    expect(res.status).toBe(400);
    expect(res.body.errors).toEqual({
      name: 'Enter your name',
      email: 'Enter a valid email address',
      guests: 'Book at least 1 guest',
    });
  });

  it.each([
    [{ guests: 9 }, 'You can book up to 8 guests'],
    [{ guests: 2.5 }, 'Use a whole number of guests'],
    [{ guests: null }, 'Enter the number of guests'],
    [{ guests: '2' }, 'Enter the number of guests'],
    [{ email: '' }, 'Enter your email address'],
    [{ name: 'x'.repeat(101) }, 'Use at most 100 characters'],
  ])('rejects %j', async (override, message) => {
    const app = setup();
    const body = { name: 'Ada', email: 'ada@example.com', guests: 2, ...override };
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(body);
    expect(res.status).toBe(400);
    expect(Object.values(res.body.errors)).toContain(message);
  });

  it('returns 404 for an unknown tasting', async () => {
    const res = await book(setup(), 'no-such-tasting', 1);
    expect(res.status).toBe(404);
  });

  it('answers malformed JSON with a JSON error', async () => {
    const res = await request(setup())
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ');
    expect(res.status).toBe(400);
    expect(res.headers['content-type']).toMatch(/application\/json/);
    expect(res.body.error).toEqual(expect.any(String));
  });

  it('returns a JSON 404 for unknown API paths', async () => {
    const res = await request(setup()).get('/api/no-such-route');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/application\/json/);
  });
});

describe('staff', () => {
  it('requires a session to list bookings', async () => {
    expect((await request(setup()).get('/api/staff/bookings')).status).toBe(401);
  });

  it('refuses a wrong password and sets no cookie', async () => {
    const res = await request(setup()).post('/api/staff/session').send({ password: 'nope' });
    expect(res.status).toBe(401);
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('refuses every sign-in when no staff password is configured', async () => {
    const app = setup({});
    const res = await request(app).post('/api/staff/session').send({ password: '' });
    expect(res.status).toBe(401);
  });

  it('sets an HttpOnly, SameSite=Strict session cookie without Secure over plain HTTP', async () => {
    const res = await request(setup()).post('/api/staff/session').send({ password: PASSWORD });
    const cookie: string = res.headers['set-cookie'][0];
    expect(cookie).toMatch(/^staff_session=/);
    expect(cookie).toMatch(/; HttpOnly/);
    expect(cookie).toMatch(/; SameSite=Strict/);
    expect(cookie).toMatch(/; Path=\//);
    expect(cookie).not.toMatch(/; Secure/);
  });

  it('sets Secure when the request arrives over HTTPS behind a trusted proxy', async () => {
    const app = setup({ staffPassword: PASSWORD, trustProxy: true });
    const res = await request(app)
      .post('/api/staff/session')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD });
    expect(res.headers['set-cookie'][0]).toMatch(/; Secure/);
  });

  it('lists bookings grouped by tasting with name, email, guests and reference', async () => {
    const app = setup();
    await book(app, 'winter-tasting', 4);
    const cookie = await signIn(app);
    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(3);
    const winter = res.body.find((g: { tasting: { id: string } }) => g.tasting.id === 'winter-tasting');
    expect(winter.tasting.seatsLeft).toBe(6);
    expect(winter.bookings).toEqual([
      expect.objectContaining({ name: 'Ada Lovelace', email: 'ada@example.com', guests: 4, reference: expect.stringMatching(/^KB-/) }),
    ]);
    const riesling = res.body.find((g: { tasting: { id: string } }) => g.tasting.id === 'riesling-evening');
    expect(riesling.bookings).toEqual([]);
  });

  it('cancels a booking and frees its seats', async () => {
    const app = setup();
    await book(app, 'riesling-evening', 5);
    const cookie = await signIn(app);
    const listed = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    const reference = listed.body[0].bookings[0].reference;

    const res = await request(app).delete(`/api/staff/bookings/${reference}`).set('Cookie', cookie);
    expect(res.status).toBe(204);
    expect(await seatsLeft(app, 'riesling-evening')).toBe(12);
    expect((await request(app).delete(`/api/staff/bookings/${reference}`).set('Cookie', cookie)).status).toBe(404);
  });

  it('does not cancel bookings without a session', async () => {
    const app = setup();
    await book(app, 'riesling-evening', 5);
    const cookie = await signIn(app);
    const reference = (await request(app).get('/api/staff/bookings').set('Cookie', cookie)).body[0].bookings[0].reference;
    expect((await request(app).delete(`/api/staff/bookings/${reference}`)).status).toBe(401);
    expect(await seatsLeft(app, 'riesling-evening')).toBe(7);
  });

  it('ends the session on sign-out', async () => {
    const app = setup();
    const cookie = await signIn(app);
    const out = await request(app).delete('/api/staff/session').set('Cookie', cookie);
    expect(out.status).toBe(204);
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });

  it('expires the session after its lifetime', async () => {
    const app = setup({ staffPassword: PASSWORD, sessionTtlMs: 20 });
    const cookie = await signIn(app);
    await new Promise((resolve) => setTimeout(resolve, 40));
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });

  it('locks sign-in after five failed attempts', async () => {
    const app = setup();
    for (let i = 0; i < 5; i++) {
      expect((await request(app).post('/api/staff/session').send({ password: 'wrong' })).status).toBe(401);
    }
    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    expect(res.status).toBe(429);
    expect(res.headers['set-cookie']).toBeUndefined();
  });
});
