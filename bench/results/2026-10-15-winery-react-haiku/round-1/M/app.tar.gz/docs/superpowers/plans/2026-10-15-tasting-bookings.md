# Tasting Bookings Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A winery website where guests book wine tastings and staff see and cancel bookings.

**Architecture:** Express 5 serves a JSON API under `/api` and the Vite-built React app from `dist/`. Bookings live in memory in a store with synchronous check-and-insert. Staff sessions are server-side random tokens in an HttpOnly cookie.

**Tech Stack:** Node.js 22, Express 5, express-rate-limit, zod 4, React 19, Vite, react-router, react-hook-form with @hookform/resolvers, node:test.

**Spec:** `docs/superpowers/specs/2026-10-15-tasting-bookings-design.md`

## Global Constraints

- Node.js 22; npm; `npm install`, `npm run build`, `npm start`; `PORT` default 3000.
- `STAFF_PASSWORD` from the environment; never sent to the browser or logged.
- Interface text in English; currency `EUR`; guests integer 1 to 8.
- Tasting ids and data exactly as in the spec table.
- Texts: "Booking confirmed", "Book <title>", "<n> seats left", "Password", "Sign in", "Cancel", "Book".

## Review Focus

- Two guests book the last seats at the same time; the total must never exceed seats. Test in Task 1.
- Name or email that is only spaces is rejected with a message next to the field. Test in Task 2.
- Guests of 0, 9, 2.5 or "abc" are rejected next to the Guests field. Test in Task 2.
- Repeated wrong staff passwords stop being accepted for a while. Test in Task 3.
- Cancelling an unknown or already cancelled reference returns 404 and frees no seats twice. Test in Task 3.

## Task 1: Tastings data and booking store

**Files:**
- Create: `package.json`, `.gitignore`
- Create: `server/tastings.js`, `server/bookings.js`
- Test: `test/bookings.test.js`

**Interfaces:**
- Produces: `TASTINGS` (array of `{id, title, starts, pricePerGuest, seats}`) and `getTasting(id)` from `server/tastings.js`.
- Produces: `createBookingStore()` returning `{ seatsLeft(tastingId), book({tastingId, name, email, guests}), cancel(reference), list() }`. `book` returns `{booking}` or `{error: 'unknown-tasting'}` or `{error: 'seats', seatsLeft}`. `booking` is `{reference, tastingId, name, email, guests}`. `cancel` returns true or false. `list()` returns bookings in creation order.

- [ ] **Step 1: Write the failing tests**

Create `package.json` with `"type": "module"`, `"scripts": {"test": "node --test"}` and `.gitignore` with `node_modules`, `dist`. Then in `test/bookings.test.js` assert: `seatsLeft('riesling-evening') === 12`; after booking 5 guests it is 7; booking 8 when 7 are left returns `error: 'seats'` and `seatsLeft: 7`; cancelling the reference restores seats; booking `'nope'` returns `error: 'unknown-tasting'`; references match `/^KB-[0-9A-F]{8}$/` and are unique over 1000 bookings; the store's `book` is a plain synchronous call.

- [ ] **Step 2: Run tests to verify they fail**

Run: `npm test`
Expected: FAIL, modules not found.

- [ ] **Step 3: Implement `server/tastings.js` and `server/bookings.js`**

`book` computes seats left, checks `guests <= seatsLeft`, and pushes the booking in the same synchronous call. Reference: `'KB-' + crypto.randomBytes(4).toString('hex').toUpperCase()`, regenerated while it collides.

- [ ] **Step 4: Run tests to verify they pass**

Run: `npm install && npm test`
Expected: all tests PASS.

- [ ] **Step 5: Commit**

```bash
git add package.json package-lock.json .gitignore server test
git commit -m "feat: add tastings data and booking store"
```

## Task 2: Guest API and shared validation

**Files:**
- Create: `shared/schemas.js`, `server/app.js`
- Test: `test/guest-api.test.js`

**Interfaces:**
- Consumes: `TASTINGS`, `getTasting`, `createBookingStore` from Task 1.
- Produces: `bookingSchema` (zod object with `name`, `email`, `guests`) from `shared/schemas.js`, used by the client form too.
- Produces: `createApp({staffPassword, sessionTtlMs, now, store})` from `server/app.js`, returning an Express app. This task adds `GET /api/tastings` and `POST /api/tastings/:id/bookings`.

- [ ] **Step 1: Write the failing tests**

Start the app on port 0 with `app.listen(0)` and use `fetch`. Assert: `GET /api/tastings` returns 3 items with `seatsLeft` 12, 8, 10; posting `{name:'Ana', email:'ana@example.com', guests:2}` returns 201 with `reference` matching `/^KB-/`, `tastingTitle:'Riesling Evening'`, `guests:2`, `total:50`; posting `{name:'  ', email:'x', guests:0}` returns 400 with `errors.name`, `errors.email`, `errors.guests` set; guests `9`, `2.5`, `'abc'` each return 400 with `errors.guests`; posting to `/api/tastings/nope/bookings` returns 404; posting 9 guests to a tasting with 8 seats left returns 409 with `error` "Only 8 seats left"; two concurrent posts for 8 guests to Red Wine Cellar Tour (8 seats) yield exactly one 201.

- [ ] **Step 2: Run tests to verify they fail**

Run: `npm test`
Expected: FAIL, `server/app.js` missing.

- [ ] **Step 3: Implement**

`shared/schemas.js` uses zod: name trimmed, 1 to 100 characters; email trimmed, valid e-mail, at most 254; guests `z.coerce.number()` integer 1 to 8. Messages: "Enter your name", "Enter a valid email", "Choose 1 to 8 guests". Server validates with `bookingSchema.safeParse` and maps `issue.path[0]` to `errors`. Use `express.json({limit: '10kb'})`. Map store errors: unknown tasting 404, seats 409 with the message from the spec.

- [ ] **Step 4: Run tests to verify they pass**

Run: `npm test`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add shared server/app.js test/guest-api.test.js
git commit -m "feat: add guest booking API with validation"
```

## Task 3: Staff sign-in and bookings API

**Files:**
- Modify: `server/app.js`
- Create: `server/staff-auth.js`
- Test: `test/staff-api.test.js`

**Interfaces:**
- Consumes: `createApp` options from Task 2.
- Produces: `createStaffSessions({ttlMs, now})` from `server/staff-auth.js` returning `{create(), valid(token), revoke(token)}`; `create` returns a 32-byte hex token.
- Adds routes: `POST /api/staff/session`, `DELETE /api/staff/session`, `GET /api/staff/bookings`, `DELETE /api/staff/bookings/:reference`.

- [ ] **Step 1: Write the failing tests**

Tests (app with `staffPassword: 'pw-test'`): wrong password returns 401; correct returns 204 with `Set-Cookie` containing `kb_staff=`, `HttpOnly`, `SameSite=Strict`, `Path=/` and no `Secure` over HTTP; the sixth failed login within 15 minutes returns 429 even with the correct password; `GET /api/staff/bookings` without cookie returns 401; with cookie returns groups per tasting with `reference`, `name`, `email`, `guests`; `DELETE /api/staff/bookings/<ref>` returns 204 and the seats come back in `GET /api/tastings`; deleting it again returns 404; `DELETE /api/staff/session` returns 204 and the old cookie gets 401; with `sessionTtlMs: 50` the cookie is 401 after 60 ms; with no `staffPassword`, sign-in returns 503.

- [ ] **Step 2: Run tests to verify they fail**

Run: `npm test`
Expected: FAIL.

- [ ] **Step 3: Implement**

Password check: `crypto.timingSafeEqual` on SHA-256 digests. Rate limit: `express-rate-limit` on the login route, `windowMs: 15*60*1000`, `limit: 5`, `skipSuccessfulRequests: true`, JSON 429 body `{error: "Too many attempts. Try again later."}`. Cookie `kb_staff`, `Max-Age` equal to the TTL in seconds, `Secure` only when `req.secure`. Login errors: "Incorrect password". Guest-facing errors do not reveal anything about staff.

- [ ] **Step 4: Run tests to verify they pass**

Run: `npm test`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add server test/staff-api.test.js package.json package-lock.json
git commit -m "feat: add staff sign-in and booking management API"
```

## Task 4: Server entry point and static app

**Files:**
- Create: `server/index.js`
- Modify: `server/app.js`
- Test: `test/server.test.js`

**Interfaces:**
- Consumes: `createApp` from Task 3.
- Produces: `npm start` runs `node server/index.js`, reads `PORT` (default 3000) and `STAFF_PASSWORD`, and serves `dist/`.

- [ ] **Step 1: Write the failing test**

Assert: `GET /` with a built `dist/index.html` returns 200 and HTML; `GET /staff` returns the same HTML; `GET /api/unknown` returns 404 JSON, not HTML; `GET /assets/missing.js` returns 404.

- [ ] **Step 2: Run tests to verify they fail**

Run: `npm test`
Expected: FAIL.

- [ ] **Step 3: Implement**

In `createApp`, after the API routes, `express.static('dist')` and a GET fallback to `dist/index.html` for paths not starting with `/api`. `server/index.js` starts `createApp({staffPassword: process.env.STAFF_PASSWORD})` on `Number(process.env.PORT) || 3000`. Test with a temporary `dist` directory: the test creates `dist/index.html` in a temp path passed as an option `staticDir`.

- [ ] **Step 4: Run tests to verify they pass**

Run: `npm test`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add server test/server.test.js
git commit -m "feat: serve API and built React app from one process"
```

## Task 5: React app shell and tastings page

**Files:**
- Create: `index.html`, `vite.config.js`, `src/main.jsx`, `src/App.jsx`, `src/api.js`, `src/pages/Tastings.jsx`, `src/styles.css`
- Modify: `package.json` (add react, react-dom, react-router, vite, @vitejs/plugin-react, scripts `build` as `vite build`)

**Interfaces:**
- Consumes: `GET /api/tastings` from Task 2.
- Produces: `api.js` exports `getTastings()`, `bookTasting(id, values)`, `staffSignIn(password)`, `staffSignOut()`, `getStaffBookings()`, `cancelBooking(reference)`. Each returns parsed JSON or throws `ApiError` with `status` and `body`.
- Produces: routes `/` (Tastings), `/book/:id` (Book, Task 6), `/staff` (Staff, Task 7).

- [ ] **Step 1: Write the failing check**

Run `npm run build` before the files exist; expected: failure (no `index.html`). Then add the Playwright MCP check: navigate to `http://localhost:3000/`, expect the heading "Weingut Kieselbrunnen" and three cards with text "12 seats left", "8 seats left", "10 seats left", and "Book Riesling Evening".

- [ ] **Step 2: Implement**

Layout: header with the winery name and nav, main, footer. Cards show title, date and time formatted from `starts` with `Intl.DateTimeFormat` in UTC, price "EUR 25 per guest", seats left "<n> seats left"; when `seatsLeft` is 0, show "Fully booked" instead of the link. Link text "Book <title>" goes to `/book/<id>`. Styles: cream background, wine-red accents, serif headings, single column below 640 px, `prefers-reduced-motion` respected.

- [ ] **Step 3: Verify**

Run: `npm install && npm run build`
Expected: build succeeds. Then `npm start` and the Playwright check from Step 1 passes.

- [ ] **Step 4: Commit**

```bash
git add index.html vite.config.js src package.json package-lock.json
git commit -m "feat: add React app shell and tastings page"
```

## Task 6: Booking page and confirmation

**Files:**
- Create: `src/pages/Book.jsx`
- Modify: `src/App.jsx` (route `/book/:id`)

**Interfaces:**
- Consumes: `getTastings()`, `bookTasting(id, values)`, `bookingSchema` from `shared/schemas.js`.
- Uses `react-hook-form` with `zodResolver(bookingSchema)`; on a server 400, set field errors with `setError`; on 409 show the message in an alert.

- [ ] **Step 1: Write the failing check**

Playwright MCP: open `/book/riesling-evening`; submit empty; expect messages next to Name, Email and Guests with `aria-describedby`; fill valid values, submit; expect heading "Booking confirmed", the tasting title, "2" guests, "EUR 50", and a reference matching `KB-` followed by 8 hex digits. Open `/book/unknown`; expect "Tasting not found".

- [ ] **Step 2: Implement**

Fields: `Name` (text, autocomplete name), `Email` (email, autocomplete email), `Guests` (number input, min 1, max 8, inputmode numeric), `Book` (submit). Disable the form and show "Fully booked" when `seatsLeft` is 0. Confirmation replaces the form: heading "Booking confirmed", tasting, guests, total, reference.

- [ ] **Step 3: Verify**

Run: `npm run build`; then the Playwright checks from Step 1 against `npm start`.

- [ ] **Step 4: Commit**

```bash
git add src/pages/Book.jsx src/App.jsx
git commit -m "feat: add booking form and confirmation"
```

## Task 7: Staff page

**Files:**
- Create: `src/pages/Staff.jsx`
- Modify: `src/App.jsx` (route `/staff`)

**Interfaces:**
- Consumes: `staffSignIn`, `staffSignOut`, `getStaffBookings`, `cancelBooking` from `src/api.js`.

- [ ] **Step 1: Write the failing check**

Playwright MCP: open `/staff`; expect fields "Password" and button "Sign in"; submit a wrong password, expect "Incorrect password"; submit the configured password (set `STAFF_PASSWORD=test-pass` for the browser run), expect a section per tasting with a table (Name, Email, Guests, Reference, Cancel); click "Cancel" on one row, expect the row removed and "Sign out" returns to the form.

- [ ] **Step 2: Implement**

Sign-in form with `Password` input and `Sign in` button. Signed-in view: one section per tasting, table with name, email, guests, reference, Cancel button; "No bookings yet" when empty; "Sign out" button. A 401 on any staff call returns to the form with "Your session has ended. Sign in again." A 429 shows "Too many attempts. Try again later."

- [ ] **Step 3: Verify**

Run: `npm run build`; then the Step 1 check with `STAFF_PASSWORD=test-pass npm start`.

- [ ] **Step 4: Commit**

```bash
git add src/pages/Staff.jsx src/App.jsx
git commit -m "feat: add staff sign-in and booking list with cancel"
```

## Task 8: Full verification and review

**Files:** none changed unless a check fails.

- [ ] **Step 1: Clean install and checks**

Run: `rm -rf node_modules dist && npm install && npm run build && npm test`
Expected: all succeed; tests all pass.

- [ ] **Step 2: Run the app**

Run: `STAFF_PASSWORD=test-pass PORT=3000 npm start`
Expected: server listens on 3000.

- [ ] **Step 3: Browser pass**

Playwright MCP at 390 px and 1280 px wide: start page, booking of 2 guests on Riesling Evening, a booking that exceeds seats left (error next to Guests), fully booked state (book Red Wine Cellar Tour to 8 guests first), staff sign-in, cancel, seats freed. Take screenshots for review.

- [ ] **Step 4: Review and commit any fixes**

Run `requesting-code-review` on the branch diff against `main`; fix findings with new commits.
