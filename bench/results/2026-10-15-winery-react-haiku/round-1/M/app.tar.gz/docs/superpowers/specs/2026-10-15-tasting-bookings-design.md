# Weingut Kieselbrunnen: Tasting Bookings Design

Date: 2026-10-15
Status: approved in the request; choices marked "(call)" were made by the builder.

## Intent

Guests book wine tastings online. Staff see all bookings and cancel them.
The pages look like a small family winery's own site.

## Goals

- Guests list tastings, see seats left, and book a tasting for 1 to 8 guests.
- Bookings never exceed the seats of a tasting.
- Guests get a confirmation with heading "Booking confirmed", tasting, guests, total price, and reference.
- Staff sign in with the password from `STAFF_PASSWORD`, see bookings grouped by tasting, and cancel a booking; a cancel frees its seats.
- Usable on a phone. All UI text in English.

## Non-goals

- Payments, e-mail sending, tasting administration (tastings are fixed in code).
- Accounts for guests, multiple staff users, internationalisation.

## Anti-goals

- Overbooking a tasting, including with concurrent requests.
- The staff password or any secret reaching the browser bundle or a log.
- Staff session token readable from JavaScript.

## Tastings (fixed data)

| id | Title | Starts | Price per guest | Seats |
|---|---|---|---|---|
| riesling-evening | Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| red-wine-cellar-tour | Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| winter-tasting | Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

Times are shown as written; no time zone conversion.

## Constraints

- Node.js 22, npm. No external services.
- `npm install`, then `npm run build` (builds the React app), then `npm start` serves the whole app on `PORT` (default 3000).
- Storage: in memory (call). The app starts with no bookings; a restart clears them.

## Decisions (calls)

- Server: Express 5 serves the JSON API under `/api` and the built React app (`dist/`) for all other GET requests.
- Client: React 19, built with Vite; routing with `react-router`; forms with `react-hook-form` and `zod` (validation schema shared by client and server).
- Styling: one hand-written CSS file with CSS custom properties. No CSS framework.
- Staff login rate limit: `express-rate-limit`, 5 failed attempts per IP per 15 minutes; successful logins do not count.
- Staff session: random 32-byte token, held server-side in memory, expires 8 hours after sign-in, removed by sign-out. Cookie `kb_staff`: `HttpOnly`, `SameSite=Strict`, `Path=/`, `Max-Age` 8 h, `Secure` when the request is HTTPS.
- Password check: SHA-256 digests of the submitted and configured password compared with `crypto.timingSafeEqual`.
- `STAFF_PASSWORD` unset: staff sign-in returns 503 "Staff sign-in is not configured"; guest pages still work.
- Booking reference: `KB-` followed by 8 random hex digits, unique among bookings.
- Seats left = seats minus the guests of all bookings for that tasting. A booking is accepted only if `guests <= seats left`, checked and stored in one synchronous step.
- Total price = price per guest times guests, shown as `EUR <total>`.
- Booking form: the Guests field is a number input, 1 to 8. After a successful booking the same page shows the confirmation (no separate URL).
- Fully booked tasting: the card shows "Fully booked" instead of the booking link; the booking page shows a notice instead of the form.
- Seat counter text is "<n> seats left" for every n greater than 0, as specified.

## API

| Method | Path | Body or result |
|---|---|---|
| GET | `/api/tastings` | `[{id, title, starts, pricePerGuest, seats, seatsLeft}]` |
| POST | `/api/tastings/:id/bookings` | body `{name, email, guests}`; 201 `{reference, tastingTitle, guests, total}`; 400 `{errors: {name?, email?, guests?}}`; 404 unknown tasting; 409 `{error}` when seats are short |
| POST | `/api/staff/session` | body `{password}`; 204 and sets cookie; 401 wrong password; 429 rate limited; 503 not configured |
| DELETE | `/api/staff/session` | 204, clears cookie and session |
| GET | `/api/staff/bookings` | 200 `[{id, title, bookings: [{reference, name, email, guests}]}]`; 401 without a valid session |
| DELETE | `/api/staff/bookings/:reference` | 204; 401 without a valid session; 404 unknown reference |

## Validation

- Name: required after trimming, at most 100 characters.
- Email: required after trimming, valid e-mail format, at most 254 characters.
- Guests: integer from 1 to 8.
- Seats: a booking that exceeds seats left is rejected with 409 and the message "Only <n> seats left".
- Errors are shown next to the field they concern (`aria-describedby`, `role="alert"`).

## Screens

- Start (`/`): heading, one card per tasting with title, date and time, price per guest, seats left, and "Book <title>" link.
- Booking (`/book/:id`): tasting summary, form with Name, Email, Guests and "Book" button; confirmation replaces the form on success.
- Staff (`/staff`): sign-in form ("Password", "Sign in") when signed out; when signed in, one section per tasting with a table (Name, Email, Guests, Reference, "Cancel") and a "Sign out" button. Expired session returns to the sign-in form with the message "Your session has ended. Sign in again."

## What is left to the builder

- Exact layout and colours, within the winery look (cream background, wine-red accents, serif headings).
- Test structure, provided server behaviour is covered by automated tests.
