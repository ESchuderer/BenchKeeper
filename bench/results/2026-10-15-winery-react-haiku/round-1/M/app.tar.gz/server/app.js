import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { rateLimit } from 'express-rate-limit';
import { createBookingStore } from './bookings.js';
import { TASTINGS, getTasting } from './tastings.js';
import { bookingSchema } from '../shared/schemas.js';
import { STAFF_COOKIE, createStaffSessions, passwordMatches, readCookie } from './staff-auth.js';

const DEFAULT_STATIC_DIR = fileURLToPath(new URL('../dist', import.meta.url));

export function createApp({ store = createBookingStore(), staffPassword, sessionTtlMs, now, trustProxy = false, staticDir = DEFAULT_STATIC_DIR } = {}) {
  const app = express();
  app.set('trust proxy', trustProxy);
  app.use(express.json({ limit: '10kb' }));

  const sessions = createStaffSessions({ ttlMs: sessionTtlMs, now });
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many attempts. Try again later.' },
  });

  function requireStaff(req, res, next) {
    const token = readCookie(req, STAFF_COOKIE);
    if (!token || !sessions.valid(token)) return res.status(401).json({ error: 'Sign in required' });
    next();
  }

  app.get('/api/tastings', (req, res) => {
    res.json(TASTINGS.map((tasting) => ({ ...tasting, seatsLeft: store.seatsLeft(tasting.id) })));
  });

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const tasting = getTasting(req.params.id);
    if (!tasting) return res.status(404).json({ error: 'Tasting not found' });

    const parsed = bookingSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      const errors = {};
      for (const issue of parsed.error.issues) errors[issue.path[0]] ??= issue.message;
      return res.status(400).json({ errors });
    }

    const { guests } = parsed.data;
    const result = store.book({ tastingId: tasting.id, ...parsed.data });
    if (result.error === 'seats') {
      return res.status(409).json({ error: `Only ${result.seatsLeft} seats left` });
    }
    res.status(201).json({
      reference: result.booking.reference,
      tastingTitle: tasting.title,
      guests,
      total: tasting.pricePerGuest * guests,
    });
  });

  app.post('/api/staff/session', loginLimiter, (req, res) => {
    if (!staffPassword) return res.status(503).json({ error: 'Staff sign-in is not configured' });
    const given = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!passwordMatches(given, staffPassword)) return res.status(401).json({ error: 'Incorrect password' });
    res.cookie(STAFF_COOKIE, sessions.create(), {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure,
      path: '/',
      maxAge: sessions.ttlMs,
    });
    res.status(204).end();
  });

  app.delete('/api/staff/session', (req, res) => {
    const token = readCookie(req, STAFF_COOKIE);
    if (token) sessions.revoke(token);
    res.clearCookie(STAFF_COOKIE, { httpOnly: true, sameSite: 'strict', secure: req.secure, path: '/' });
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (req, res) => {
    const bookings = store.list();
    res.json(TASTINGS.map((tasting) => ({
      id: tasting.id,
      title: tasting.title,
      bookings: bookings
        .filter((booking) => booking.tastingId === tasting.id)
        .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
    })));
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(req.params.reference)) return res.status(404).json({ error: 'Booking not found' });
    res.status(204).end();
  });

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

  // Answers malformed JSON without passing the error on, because the default handler logs the message, which can echo the body.
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
    next(err);
  });

  app.use(express.static(staticDir));
  // Client-side routes fall back to the app shell; paths with a file extension get a plain 404.
  app.get('/{*splat}', (req, res, next) => {
    if (path.extname(req.path)) return next();
    res.sendFile(path.join(staticDir, 'index.html'));
  });

  return app;
}
