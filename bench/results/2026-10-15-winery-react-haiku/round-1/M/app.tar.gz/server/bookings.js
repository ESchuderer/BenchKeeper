import crypto from 'node:crypto';
import { TASTINGS } from './tastings.js';

// shortcut: bookings live in memory and are lost on restart, persist to a file when restarts must keep bookings
export function createBookingStore(tastings = TASTINGS) {
  const bookings = [];

  function findTasting(tastingId) {
    return tastings.find((tasting) => tasting.id === tastingId);
  }

  function seatsLeft(tastingId) {
    const taken = bookings
      .filter((booking) => booking.tastingId === tastingId)
      .reduce((sum, booking) => sum + booking.guests, 0);
    return (findTasting(tastingId)?.seats ?? 0) - taken;
  }

  function newReference() {
    let reference;
    do {
      reference = 'KB-' + crypto.randomBytes(4).toString('hex').toUpperCase();
    } while (bookings.some((booking) => booking.reference === reference));
    return reference;
  }

  // Synchronous check and insert: no await between the seat check and the push, so concurrent requests cannot overbook.
  function book({ tastingId, name, email, guests }) {
    if (!findTasting(tastingId)) return { error: 'unknown-tasting' };
    const left = seatsLeft(tastingId);
    if (guests > left) return { error: 'seats', seatsLeft: left };
    const booking = { reference: newReference(), tastingId, name, email, guests };
    bookings.push(booking);
    return { booking };
  }

  function cancel(reference) {
    const index = bookings.findIndex((booking) => booking.reference === reference);
    if (index === -1) return false;
    bookings.splice(index, 1);
    return true;
  }

  function list() {
    return [...bookings];
  }

  return { seatsLeft, book, cancel, list };
}
