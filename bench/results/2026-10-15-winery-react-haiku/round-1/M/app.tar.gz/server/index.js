import { createApp } from './app.js';

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;
// Set TRUST_PROXY to the number of proxies in front of the app (e.g. 1) so HTTPS and client IPs are read from forwarded headers.
const trustProxy = Number(process.env.TRUST_PROXY) || false;

createApp({ staffPassword, trustProxy }).listen(port, () => {
  console.log(`Weingut Kieselbrunnen listening on http://localhost:${port}`);
  if (!staffPassword) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
});
