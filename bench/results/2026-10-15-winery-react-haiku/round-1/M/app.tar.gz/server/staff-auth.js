import crypto from 'node:crypto';

export const STAFF_COOKIE = 'kb_staff';

const EIGHT_HOURS_MS = 8 * 60 * 60 * 1000;

export function createStaffSessions({ ttlMs = EIGHT_HOURS_MS, now = Date.now } = {}) {
  const expiry = new Map();

  function create() {
    const token = crypto.randomBytes(32).toString('hex');
    expiry.set(token, now() + ttlMs);
    return token;
  }

  function valid(token) {
    const until = expiry.get(token);
    if (until === undefined) return false;
    if (until > now()) return true;
    expiry.delete(token);
    return false;
  }

  function revoke(token) {
    expiry.delete(token);
  }

  return { create, valid, revoke, ttlMs };
}

// SHA-256 digests make both inputs the same length, as timingSafeEqual requires.
export function passwordMatches(given, expected) {
  const digest = (text) => crypto.createHash('sha256').update(text).digest();
  return crypto.timingSafeEqual(digest(given), digest(expected));
}

export function readCookie(req, name) {
  const pair = req.headers.cookie?.split(';').map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return pair?.slice(name.length + 1);
}
