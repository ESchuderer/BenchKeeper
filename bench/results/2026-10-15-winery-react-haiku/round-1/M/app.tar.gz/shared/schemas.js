import { z } from 'zod';

const EMAIL_MESSAGE = 'Enter a valid email';

export const bookingSchema = z.object({
  name: z.string().trim().min(1, 'Enter your name').max(100, 'Name is too long'),
  email: z.string().trim().min(1, EMAIL_MESSAGE).max(254, EMAIL_MESSAGE).pipe(z.email(EMAIL_MESSAGE)),
  // Form fields arrive as strings; only those are converted, so booleans and arrays stay invalid.
  guests: z.preprocess(
    (value) => (typeof value === 'string' && value.trim() !== '' ? Number(value) : value),
    z.number({ error: 'Choose 1 to 8 guests' }).int('Choose 1 to 8 guests').min(1, 'Choose 1 to 8 guests').max(8, 'Choose 1 to 8 guests'),
  ),
});
