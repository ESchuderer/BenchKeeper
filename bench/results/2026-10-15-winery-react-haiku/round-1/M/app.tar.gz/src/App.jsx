import { Link, Route, Routes } from 'react-router';
import Tastings from './pages/Tastings.jsx';
import Book from './pages/Book.jsx';
import Staff from './pages/Staff.jsx';

export default function App() {
  return (
    <div className="site">
      <header className="site-header">
        <Link to="/" className="brand">Weingut Kieselbrunnen</Link>
        <nav>
          <Link to="/staff">Staff</Link>
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Tastings />} />
          <Route path="/book/:id" element={<Book />} />
          <Route path="/staff" element={<Staff />} />
        </Routes>
      </main>
      <footer className="site-footer">Weingut Kieselbrunnen, family winery</footer>
    </div>
  );
}
