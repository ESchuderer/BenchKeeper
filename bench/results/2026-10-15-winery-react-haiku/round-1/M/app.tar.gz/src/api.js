export class ApiError extends Error {
  constructor(status, body) {
    super(body?.error ?? `Request failed with status ${status}`);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

async function request(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body === undefined ? {} : { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}

export const getTastings = () => request('/api/tastings');
export const bookTasting = (id, values) => request(`/api/tastings/${id}/bookings`, { method: 'POST', body: values });
export const staffSignIn = (password) => request('/api/staff/session', { method: 'POST', body: { password } });
export const staffSignOut = () => request('/api/staff/session', { method: 'DELETE' });
export const getStaffBookings = () => request('/api/staff/bookings');
export const cancelBooking = (reference) => request(`/api/staff/bookings/${reference}`, { method: 'DELETE' });
