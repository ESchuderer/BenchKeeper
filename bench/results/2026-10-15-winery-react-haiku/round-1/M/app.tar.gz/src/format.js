// starts is a wall-clock time without zone (e.g. "2026-11-06T18:00"); UTC formatting shows it as written.
export function formatStart(starts) {
  return new Intl.DateTimeFormat('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
    timeZone: 'UTC',
  }).format(new Date(`${starts}Z`));
}
