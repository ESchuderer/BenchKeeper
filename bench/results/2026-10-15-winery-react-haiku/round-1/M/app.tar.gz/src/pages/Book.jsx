import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { bookingSchema } from '../../shared/schemas.js';
import { ApiError, bookTasting, getTastings } from '../api.js';
import { formatStart } from '../format.js';

export default function Book() {
  const { id } = useParams();
  const [state, setState] = useState({ status: 'loading' });

  useEffect(() => {
    getTastings()
      .then((list) => {
        const tasting = list.find((item) => item.id === id);
        setState(tasting ? { status: 'ready', tasting } : { status: 'notFound' });
      })
      .catch(() => setState({ status: 'error' }));
  }, [id]);

  if (state.status === 'loading') return <p className="notice">Loading…</p>;
  if (state.status === 'notFound') {
    return (
      <>
        <p className="notice notice-error" role="alert">Tasting not found</p>
        <Link to="/">Back to tastings</Link>
      </>
    );
  }
  if (state.status === 'error') {
    return <p className="notice notice-error" role="alert">Could not load the tasting. Please try again.</p>;
  }
  return <BookingForm tasting={state.tasting} />;
}

function BookingForm({ tasting }) {
  const [confirmation, setConfirmation] = useState(null);
  const [formError, setFormError] = useState('');
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  });

  async function onSubmit(values) {
    setFormError('');
    try {
      setConfirmation(await bookTasting(tasting.id, values));
    } catch (error) {
      if (error instanceof ApiError && error.status === 400 && error.body?.errors) {
        for (const [field, message] of Object.entries(error.body.errors)) {
          setError(field, { type: 'server', message });
        }
      } else if (error instanceof ApiError && error.status === 409) {
        setError('guests', { type: 'server', message: error.message });
      } else {
        setFormError(error instanceof ApiError ? error.message : 'Your booking could not be sent. Please try again.');
      }
    }
  }

  if (confirmation) {
    return (
      <section className="panel">
        <h1>Booking confirmed</h1>
        <dl className="summary">
          <dt>Tasting</dt>
          <dd>{confirmation.tastingTitle}</dd>
          <dt>Date and time</dt>
          <dd>{formatStart(tasting.starts)}</dd>
          <dt>Guests</dt>
          <dd>{confirmation.guests}</dd>
          <dt>Total</dt>
          <dd>EUR {confirmation.total}</dd>
          <dt>Booking reference</dt>
          <dd className="reference">{confirmation.reference}</dd>
        </dl>
        <Link className="button button-secondary" to="/">Back to tastings</Link>
      </section>
    );
  }

  if (tasting.seatsLeft === 0) {
    return (
      <section className="panel">
        <h1>{tasting.title}</h1>
        <p className="notice notice-error">Fully booked</p>
        <Link to="/">Back to tastings</Link>
      </section>
    );
  }

  return (
    <section className="panel">
      <h1>{tasting.title}</h1>
      <p className="meta">{formatStart(tasting.starts)} · EUR {tasting.pricePerGuest} per guest · {tasting.seatsLeft} seats left</p>
      {formError && <p className="notice notice-error" role="alert">{formError}</p>}
      <form onSubmit={handleSubmit(onSubmit)} noValidate style={{ marginTop: '1.25rem' }}>
        <div className="field">
          <label htmlFor="name">Name</label>
          <input
            id="name"
            autoComplete="name"
            aria-invalid={errors.name ? 'true' : 'false'}
            aria-describedby={errors.name ? 'name-error' : undefined}
            {...register('name')}
          />
          {errors.name && <span id="name-error" className="field-error" role="alert">{errors.name.message}</span>}
        </div>
        <div className="field">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            aria-invalid={errors.email ? 'true' : 'false'}
            aria-describedby={errors.email ? 'email-error' : undefined}
            {...register('email')}
          />
          {errors.email && <span id="email-error" className="field-error" role="alert">{errors.email.message}</span>}
        </div>
        <div className="field">
          <label htmlFor="guests">Guests</label>
          <input
            id="guests"
            type="number"
            min="1"
            max="8"
            inputMode="numeric"
            aria-invalid={errors.guests ? 'true' : 'false'}
            aria-describedby={errors.guests ? 'guests-error' : undefined}
            {...register('guests')}
          />
          {errors.guests && <span id="guests-error" className="field-error" role="alert">{errors.guests.message}</span>}
        </div>
        <button type="submit" className="button" disabled={isSubmitting}>Book</button>
      </form>
    </section>
  );
}
