import { useEffect, useState } from 'react';
import { ApiError, cancelBooking, getStaffBookings, staffSignIn, staffSignOut } from '../api.js';

const SESSION_ENDED = 'Your session has ended. Sign in again.';

export default function Staff() {
  const [view, setView] = useState('loading');
  const [groups, setGroups] = useState([]);
  const [notice, setNotice] = useState(null);
  const [password, setPassword] = useState('');

  function showSignedOut(message) {
    setGroups([]);
    setView('signedOut');
    setNotice(message ? { tone: 'error', text: message } : null);
  }

  function handleStaffError(error) {
    if (error instanceof ApiError && error.status === 401) return showSignedOut(SESSION_ENDED);
    setNotice({ tone: 'error', text: error instanceof ApiError ? error.message : 'Something went wrong. Please try again.' });
  }

  async function loadBookings() {
    try {
      setGroups(await getStaffBookings());
      setView('signedIn');
    } catch (error) {
      handleStaffError(error);
    }
  }

  useEffect(() => {
    getStaffBookings()
      .then((data) => {
        setGroups(data);
        setView('signedIn');
      })
      .catch(() => setView('signedOut'));
  }, []);

  async function handleSignIn(event) {
    event.preventDefault();
    setNotice(null);
    try {
      await staffSignIn(password);
      setPassword('');
      await loadBookings();
    } catch (error) {
      setNotice({ tone: 'error', text: error instanceof ApiError ? error.message : 'Could not sign in. Please try again.' });
    }
  }

  async function handleSignOut() {
    try {
      await staffSignOut();
    } finally {
      showSignedOut(null);
    }
  }

  async function handleCancel(reference) {
    setNotice(null);
    try {
      await cancelBooking(reference);
      setNotice({ tone: 'success', text: `Booking ${reference} cancelled.` });
      await loadBookings();
    } catch (error) {
      handleStaffError(error);
    }
  }

  if (view === 'loading') return <p className="notice">Loading…</p>;

  if (view === 'signedOut') {
    return (
      <section className="panel">
        <h1>Staff sign-in</h1>
        {notice && <p className={`notice notice-${notice.tone}`} role="alert">{notice.text}</p>}
        <form onSubmit={handleSignIn} style={{ marginTop: '1.25rem' }}>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          <button type="submit" className="button">Sign in</button>
        </form>
      </section>
    );
  }

  return (
    <section>
      <div className="toolbar">
        <h1>Bookings</h1>
        <button type="button" className="button button-secondary" onClick={handleSignOut}>Sign out</button>
      </div>
      {notice && <p className={`notice notice-${notice.tone}`} role="status">{notice.text}</p>}
      {groups.map((group) => (
        <section key={group.id}>
          <h2 className="group-title">{group.title}</h2>
          {group.bookings.length === 0 ? (
            <p className="meta">No bookings yet</p>
          ) : (
            <div className="table-wrap">
              <table className="bookings-table">
                <thead>
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Guests</th>
                    <th scope="col">Reference</th>
                    <th scope="col"><span className="sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody>
                  {group.bookings.map((booking) => (
                    <tr key={booking.reference}>
                      <td>{booking.name}</td>
                      <td>{booking.email}</td>
                      <td>{booking.guests}</td>
                      <td className="reference">{booking.reference}</td>
                      <td>
                        <button
                          type="button"
                          className="button button-secondary"
                          aria-label={`Cancel booking ${booking.reference}`}
                          onClick={() => handleCancel(booking.reference)}
                        >
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      ))}
    </section>
  );
}
