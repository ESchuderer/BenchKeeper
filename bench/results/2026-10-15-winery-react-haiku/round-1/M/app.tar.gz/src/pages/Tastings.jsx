import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { getTastings } from '../api.js';
import { formatStart } from '../format.js';

export default function Tastings() {
  const [tastings, setTastings] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    getTastings().then(setTastings).catch(() => setError('Could not load the tastings. Please try again.'));
  }, []);

  if (error) return <p className="notice notice-error" role="alert">{error}</p>;
  if (!tastings) return <p className="notice">Loading tastings…</p>;

  return (
    <>
      <h1>Weingut Kieselbrunnen</h1>
      <p className="intro">Wine tastings at our family cellar. Choose a tasting and book your places.</p>
      <ul className="tasting-list">
        {tastings.map((tasting) => (
          <li key={tasting.id} className="tasting-card">
            <h2>{tasting.title}</h2>
            <p className="meta">{formatStart(tasting.starts)}</p>
            <p className="price">EUR {tasting.pricePerGuest} per guest</p>
            {tasting.seatsLeft > 0 ? (
              <>
                <p className="seats">{tasting.seatsLeft} seats left</p>
                <Link className="button" to={`/book/${tasting.id}`}>{`Book ${tasting.title}`}</Link>
              </>
            ) : (
              <p className="seats sold-out">Fully booked</p>
            )}
          </li>
        ))}
      </ul>
    </>
  );
}
