import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createBookingStore } from '../server/bookings.js';

const guest = { name: 'Ana', email: 'ana@example.com' };

test('seats left start at the tasting seat count', () => {
  assert.equal(createBookingStore().seatsLeft('riesling-evening'), 12);
});

test('a booking reduces seats left by its guest count', () => {
  const store = createBookingStore();
  store.book({ tastingId: 'riesling-evening', ...guest, guests: 5 });
  assert.equal(store.seatsLeft('riesling-evening'), 7);
});

test('book is synchronous and returns the stored booking', () => {
  const result = createBookingStore().book({ tastingId: 'riesling-evening', ...guest, guests: 2 });
  assert.equal(typeof result.then, 'undefined');
  assert.deepEqual(result.booking, {
    reference: result.booking.reference,
    tastingId: 'riesling-evening',
    name: 'Ana',
    email: 'ana@example.com',
    guests: 2,
  });
});

test('rejects a booking above seats left and reports seats left', () => {
  const store = createBookingStore();
  store.book({ tastingId: 'riesling-evening', ...guest, guests: 5 });
  const result = store.book({ tastingId: 'riesling-evening', ...guest, guests: 8 });
  assert.deepEqual(result, { error: 'seats', seatsLeft: 7 });
  assert.equal(store.seatsLeft('riesling-evening'), 7);
});

test('cancelling a booking frees its seats and a second cancel finds nothing', () => {
  const store = createBookingStore();
  const { booking } = store.book({ tastingId: 'riesling-evening', ...guest, guests: 5 });
  assert.equal(store.cancel(booking.reference), true);
  assert.equal(store.seatsLeft('riesling-evening'), 12);
  assert.equal(store.cancel(booking.reference), false);
});

test('list returns bookings in creation order', () => {
  const store = createBookingStore();
  const first = store.book({ tastingId: 'riesling-evening', ...guest, guests: 1 }).booking;
  const second = store.book({ tastingId: 'winter-tasting', ...guest, guests: 1 }).booking;
  assert.deepEqual(store.list(), [first, second]);
});

test('rejects an unknown tasting', () => {
  assert.deepEqual(
    createBookingStore().book({ tastingId: 'nope', ...guest, guests: 1 }),
    { error: 'unknown-tasting' },
  );
});

test('references have the KB-XXXXXXXX form and are unique', () => {
  const store = createBookingStore([{ id: 'big', title: 'Big', starts: '2026-11-06T18:00', pricePerGuest: 1, seats: 1000 }]);
  const references = new Set();
  for (let i = 0; i < 1000; i++) {
    const { booking } = store.book({ tastingId: 'big', ...guest, guests: 1 });
    assert.match(booking.reference, /^KB-[0-9A-F]{8}$/);
    references.add(booking.reference);
  }
  assert.equal(references.size, 1000);
});
