import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createApp } from '../server/app.js';

async function withServer(fn) {
  const server = createApp().listen(0);
  await once(server, 'listening');
  try {
    await fn(`http://127.0.0.1:${server.address().port}`);
  } finally {
    server.close();
  }
}

function book(base, id, body) {
  return fetch(`${base}/api/tastings/${id}/bookings`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
}

const ana = { name: 'Ana', email: 'ana@example.com', guests: 2 };

test('lists the three tastings with seats left', () => withServer(async (base) => {
  const res = await fetch(`${base}/api/tastings`);
  assert.equal(res.status, 200);
  const list = await res.json();
  assert.deepEqual(list.map((tasting) => tasting.seatsLeft), [12, 8, 10]);
}));

test('a valid booking returns 201 with reference, title, guests and total', () => withServer(async (base) => {
  const res = await book(base, 'riesling-evening', ana);
  assert.equal(res.status, 201);
  const body = await res.json();
  assert.match(body.reference, /^KB-/);
  assert.equal(body.tastingTitle, 'Riesling Evening');
  assert.equal(body.guests, 2);
  assert.equal(body.total, 50);
}));

test('a blank name, an invalid email and 0 guests are each rejected next to their field', () => withServer(async (base) => {
  const res = await book(base, 'riesling-evening', { name: '  ', email: 'x', guests: 0 });
  assert.equal(res.status, 400);
  const { errors } = await res.json();
  assert.ok(errors.name);
  assert.ok(errors.email);
  assert.ok(errors.guests);
}));

test('guests of 9, 2.5 or "abc" are rejected at the guests field', () => withServer(async (base) => {
  for (const guests of [9, 2.5, 'abc']) {
    const res = await book(base, 'riesling-evening', { ...ana, guests });
    assert.equal(res.status, 400, `guests=${guests}`);
    const { errors } = await res.json();
    assert.ok(errors.guests, `guests=${guests}`);
  }
}));

test('guests given as a boolean or an array are rejected at the guests field', () => withServer(async (base) => {
  for (const guests of [true, [3]]) {
    const res = await book(base, 'riesling-evening', { ...ana, guests });
    assert.equal(res.status, 400, `guests=${JSON.stringify(guests)}`);
    const { errors } = await res.json();
    assert.ok(errors.guests, `guests=${JSON.stringify(guests)}`);
  }
}));

test('an unknown tasting returns 404', () => withServer(async (base) => {
  const res = await book(base, 'nope', ana);
  assert.equal(res.status, 404);
}));

test('a booking above seats left returns 409 with the seats left', () => withServer(async (base) => {
  await book(base, 'riesling-evening', { ...ana, guests: 5 });
  const res = await book(base, 'riesling-evening', { ...ana, guests: 8 });
  assert.equal(res.status, 409);
  assert.deepEqual(await res.json(), { error: 'Only 7 seats left' });
}));

test('two concurrent bookings for the last 8 seats: exactly one succeeds', () => withServer(async (base) => {
  const statuses = await Promise.all([
    book(base, 'red-wine-cellar-tour', { ...ana, guests: 8 }),
    book(base, 'red-wine-cellar-tour', { ...ana, guests: 8 }),
  ]).then((responses) => responses.map((res) => res.status));
  assert.deepEqual(statuses.sort(), [201, 409]);
}));
