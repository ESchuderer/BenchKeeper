import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../server/app.js';

const INDEX_HTML = '<!doctype html><title>Weingut Kieselbrunnen</title><div id="root"></div>';

async function withBuiltApp(fn) {
  const staticDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kb-dist-'));
  fs.writeFileSync(path.join(staticDir, 'index.html'), INDEX_HTML);
  const server = createApp({ staticDir }).listen(0);
  await once(server, 'listening');
  try {
    await fn(`http://127.0.0.1:${server.address().port}`);
  } finally {
    server.close();
    fs.rmSync(staticDir, { recursive: true, force: true });
  }
}

test('the root path serves the built app', () => withBuiltApp(async (base) => {
  const res = await fetch(`${base}/`);
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /text\/html/);
  assert.equal(await res.text(), INDEX_HTML);
}));

test('a client-side route such as /staff serves the built app', () => withBuiltApp(async (base) => {
  const res = await fetch(`${base}/staff`);
  assert.equal(res.status, 200);
  assert.equal(await res.text(), INDEX_HTML);
}));

test('an unknown API path returns a JSON 404', () => withBuiltApp(async (base) => {
  const res = await fetch(`${base}/api/unknown`);
  assert.equal(res.status, 404);
  assert.match(res.headers.get('content-type'), /application\/json/);
  assert.deepEqual(await res.json(), { error: 'Not found' });
}));

test('a missing static asset returns 404 and not the app shell', () => withBuiltApp(async (base) => {
  const res = await fetch(`${base}/assets/missing.js`);
  assert.equal(res.status, 404);
  assert.notEqual(await res.text(), INDEX_HTML);
}));
