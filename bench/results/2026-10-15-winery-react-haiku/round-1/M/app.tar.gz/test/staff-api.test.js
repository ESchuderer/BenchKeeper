import { mock, test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createApp } from '../server/app.js';

async function withServer(options, fn) {
  const server = createApp(options).listen(0);
  await once(server, 'listening');
  try {
    await fn(`http://127.0.0.1:${server.address().port}`);
  } finally {
    server.close();
  }
}

const withStaff = (fn) => withServer({ staffPassword: 'pw-test' }, fn);

function login(base, password) {
  return fetch(`${base}/api/staff/session`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ password }),
  });
}

function sessionCookie(res) {
  return res.headers.getSetCookie()[0].split(';')[0];
}

async function signedInCookie(base) {
  return sessionCookie(await login(base, 'pw-test'));
}

function book(base, id, body) {
  return fetch(`${base}/api/tastings/${id}/bookings`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
}

const ana = { name: 'Ana', email: 'ana@example.com', guests: 2 };

test('a wrong password returns 401', () => withStaff(async (base) => {
  const res = await login(base, 'nope');
  assert.equal(res.status, 401);
  assert.deepEqual(await res.json(), { error: 'Incorrect password' });
}));

test('the correct password returns 204 with an HttpOnly, SameSite=Strict cookie and no Secure over HTTP', () => withStaff(async (base) => {
  const res = await login(base, 'pw-test');
  assert.equal(res.status, 204);
  const cookie = res.headers.getSetCookie()[0];
  assert.match(cookie, /^kb_staff=[0-9a-f]{64};/);
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Strict/);
  assert.match(cookie, /Path=\//);
  assert.doesNotMatch(cookie, /Secure/);
}));

test('with trustProxy set, a request forwarded as HTTPS gets a Secure cookie', () => withServer({ staffPassword: 'pw-test', trustProxy: 1 }, async (base) => {
  const res = await fetch(`${base}/api/staff/session`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-forwarded-proto': 'https' },
    body: JSON.stringify({ password: 'pw-test' }),
  });
  assert.match(res.headers.getSetCookie()[0], /Secure/);
}));

test('without trustProxy, a forwarded-HTTPS header does not make the cookie Secure', () => withStaff(async (base) => {
  const res = await fetch(`${base}/api/staff/session`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-forwarded-proto': 'https' },
    body: JSON.stringify({ password: 'pw-test' }),
  });
  assert.doesNotMatch(res.headers.getSetCookie()[0], /Secure/);
}));

test('a malformed sign-in body returns a JSON 400 and its text is not logged', () => withStaff(async (base) => {
  const logged = [];
  mock.method(console, 'error', (...args) => logged.push(args.map(String).join(' ')));
  try {
    const res = await fetch(`${base}/api/staff/session`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: '{"password": "secret-xyz"',
    });
    assert.equal(res.status, 400);
    assert.deepEqual(await res.json(), { error: 'Invalid JSON' });
    assert.equal(logged.some((line) => line.includes('secret-xyz')), false);
  } finally {
    mock.restoreAll();
  }
}));

test('after 5 failed logins even the correct password returns 429', () => withStaff(async (base) => {
  for (let i = 0; i < 5; i++) {
    assert.equal((await login(base, 'wrong')).status, 401);
  }
  const res = await login(base, 'pw-test');
  assert.equal(res.status, 429);
  assert.deepEqual(await res.json(), { error: 'Too many attempts. Try again later.' });
}));

test('the staff bookings list requires a session', () => withStaff(async (base) => {
  assert.equal((await fetch(`${base}/api/staff/bookings`)).status, 401);
}));

test('the staff bookings list groups bookings per tasting', () => withStaff(async (base) => {
  await book(base, 'riesling-evening', ana);
  const res = await fetch(`${base}/api/staff/bookings`, { headers: { cookie: await signedInCookie(base) } });
  assert.equal(res.status, 200);
  const groups = await res.json();
  const riesling = groups.find((group) => group.id === 'riesling-evening');
  assert.equal(riesling.title, 'Riesling Evening');
  assert.equal(riesling.bookings.length, 1);
  assert.deepEqual(
    { name: riesling.bookings[0].name, email: riesling.bookings[0].email, guests: riesling.bookings[0].guests },
    { name: 'Ana', email: 'ana@example.com', guests: 2 },
  );
  assert.match(riesling.bookings[0].reference, /^KB-/);
  assert.equal(groups.find((group) => group.id === 'winter-tasting').bookings.length, 0);
}));

test('cancelling a booking frees its seats; cancelling it again returns 404', () => withStaff(async (base) => {
  const { reference } = await (await book(base, 'riesling-evening', ana)).json();
  const cookie = await signedInCookie(base);
  const cancel = () => fetch(`${base}/api/staff/bookings/${reference}`, { method: 'DELETE', headers: { cookie } });

  assert.equal((await cancel()).status, 204);
  const tastings = await (await fetch(`${base}/api/tastings`)).json();
  assert.equal(tastings[0].seatsLeft, 12);
  assert.equal((await cancel()).status, 404);
}));

test('signing out makes the old cookie stop working', () => withStaff(async (base) => {
  const cookie = await signedInCookie(base);
  const out = await fetch(`${base}/api/staff/session`, { method: 'DELETE', headers: { cookie } });
  assert.equal(out.status, 204);
  assert.equal((await fetch(`${base}/api/staff/bookings`, { headers: { cookie } })).status, 401);
}));

test('a session expires after sessionTtlMs', () => withServer({ staffPassword: 'pw-test', sessionTtlMs: 50 }, async (base) => {
  const cookie = await signedInCookie(base);
  await new Promise((resolve) => setTimeout(resolve, 60));
  assert.equal((await fetch(`${base}/api/staff/bookings`, { headers: { cookie } })).status, 401);
}));

test('without STAFF_PASSWORD sign-in returns 503', () => withServer({}, async (base) => {
  const res = await login(base, 'anything');
  assert.equal(res.status, 503);
  assert.deepEqual(await res.json(), { error: 'Staff sign-in is not configured' });
}));
