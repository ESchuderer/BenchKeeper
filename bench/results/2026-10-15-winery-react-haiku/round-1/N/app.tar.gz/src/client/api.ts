import type { BookingConfirmation, StaffGroup, TastingView } from "../shared/tastings.js";
import type { BookingInput, SignInInput } from "../shared/schemas.js";

const UNREACHABLE_MESSAGE = "Could not reach the server. Please try again.";

type ApiReply = { status: number; body: unknown };

/** Status 0 means the request never reached the server. */
async function send(path: string, init: RequestInit = {}): Promise<ApiReply> {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (init.body !== undefined) headers["Content-Type"] = "application/json";
  try {
    const response = await fetch(path, { ...init, headers });
    return { status: response.status, body: parseJson(await response.text()) };
  } catch {
    return { status: 0, body: undefined };
  }
}

function parseJson(text: string): unknown {
  if (!text) return undefined;
  try {
    return JSON.parse(text);
  } catch {
    return undefined;
  }
}

function errorMessage(body: unknown): string | undefined {
  return (body as { error?: string } | undefined)?.error;
}

export async function fetchTastings(): Promise<TastingView[]> {
  const { status, body } = await send("/api/tastings");
  if (status !== 200) throw new Error(`Could not load tastings (${status})`);
  return body as TastingView[];
}

export type BookingOutcome =
  | { ok: true; booking: BookingConfirmation }
  | { ok: false; errors: Record<string, string>; message: string };

export async function createBooking(tastingId: string, input: BookingInput): Promise<BookingOutcome> {
  const { status, body } = await send(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
    method: "POST",
    body: JSON.stringify(input),
  });
  if (status === 201) return { ok: true, booking: body as BookingConfirmation };
  const errors = (body as { errors?: Record<string, string> } | undefined)?.errors ?? {};
  const message = status === 0 ? UNREACHABLE_MESSAGE : (errorMessage(body) ?? "Booking failed. Please try again.");
  return { ok: false, errors, message };
}

export async function fetchStaffBookings(): Promise<StaffGroup[] | null> {
  const { status, body } = await send("/api/staff/bookings");
  if (status === 401) return null;
  if (status !== 200) throw new Error(`Could not load bookings (${status})`);
  return body as StaffGroup[];
}

export type SignInOutcome =
  | { ok: true }
  | { ok: false; reason: "incorrect" | "locked" | "unavailable"; message: string };

export async function signIn(input: SignInInput): Promise<SignInOutcome> {
  const { status, body } = await send("/api/staff/session", { method: "POST", body: JSON.stringify(input) });
  if (status === 204) return { ok: true };
  if (status === 401) return { ok: false, reason: "incorrect", message: "Incorrect password" };
  if (status === 429) {
    return { ok: false, reason: "locked", message: errorMessage(body) ?? "Too many failed attempts. Please wait and try again." };
  }
  return { ok: false, reason: "unavailable", message: status === 0 ? UNREACHABLE_MESSAGE : "Could not sign in. Please try again." };
}

export async function signOut(): Promise<void> {
  await send("/api/staff/session", { method: "DELETE" });
}

export async function cancelBooking(reference: string): Promise<boolean> {
  const { status } = await send(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: "DELETE" });
  return status === 204;
}
