import { Link, Outlet } from "react-router";

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-wine text-cream shadow-md">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-5">
          <Link to="/" className="font-display text-2xl tracking-wide no-underline">
            Weingut Kieselbrunnen
          </Link>
          <nav aria-label="Main">
            <Link to="/" className="rounded px-2 py-1 text-cream/90 no-underline hover:text-white">
              Tastings
            </Link>
          </nav>
        </div>
        <div className="h-1 bg-gold" />
      </header>

      <main className="mx-auto w-full min-w-0 max-w-5xl flex-1 px-4 py-10">
        <Outlet />
      </main>

      <footer className="border-t border-line bg-paper">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-6 text-sm text-muted">
          <span className="font-display">Weingut Kieselbrunnen, a family winery</span>
          <Link to="/staff" className="text-wine underline-offset-4 hover:underline">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}
