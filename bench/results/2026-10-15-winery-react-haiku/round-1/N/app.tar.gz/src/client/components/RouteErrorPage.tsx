import { Link } from "react-router";
import { primaryButton } from "../ui.js";

export function RouteErrorPage() {
  return (
    <section role="alert" className="mx-auto max-w-xl text-center">
      <h1 className="font-display text-3xl text-wine">Something went wrong</h1>
      <p className="mt-3 text-muted">The page could not be loaded. Please try again in a moment.</p>
      <Link to="/" className={`${primaryButton} mt-6 no-underline`}>
        Back to tastings
      </Link>
    </section>
  );
}
