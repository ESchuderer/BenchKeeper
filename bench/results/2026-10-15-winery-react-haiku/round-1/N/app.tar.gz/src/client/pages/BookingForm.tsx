import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLoaderData, useNavigate, useRevalidator } from "react-router";
import type { TastingView } from "../../shared/tastings.js";
import { bookingSchema, type BookingInput } from "../../shared/schemas.js";
import { formatDateTime, formatPrice, formatSeatsLeft } from "../../shared/format.js";
import { createBooking } from "../api.js";
import { errorText, inputClass, primaryButton } from "../ui.js";

export type BookingPageData = { tasting: TastingView | null };

export function BookingForm() {
  const { tasting } = useLoaderData() as BookingPageData;

  if (!tasting) {
    return <p className="text-lg text-ink">This tasting does not exist.</p>;
  }

  return (
    <div className="grid gap-8 md:grid-cols-[1fr_1.2fr]">
      <TastingSummary tasting={tasting} />
      {tasting.seatsLeft === 0 ? (
        <p role="status" className="rounded-2xl border border-line bg-paper p-6 text-lg font-medium text-muted">
          Fully booked
        </p>
      ) : (
        <BookingFields tasting={tasting} />
      )}
    </div>
  );
}

function TastingSummary({ tasting }: { tasting: TastingView }) {
  return (
    <section aria-labelledby="tasting-title" className="rounded-2xl bg-wine p-6 text-cream shadow-md">
      <p className="text-sm uppercase tracking-wider text-gold">Tasting</p>
      <h1 id="tasting-title" className="mt-1 font-display text-3xl">
        {tasting.title}
      </h1>
      <p className="mt-4">{formatDateTime(tasting.date, tasting.time)}</p>
      <p className="mt-1">{formatPrice(tasting.price)} per guest</p>
      <p className="mt-1">{formatSeatsLeft(tasting.seatsLeft)}</p>
    </section>
  );
}

type FormValues = BookingInput;

function BookingFields({ tasting }: { tasting: TastingView }) {
  const navigate = useNavigate();
  const revalidator = useRevalidator();
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(bookingSchema), defaultValues: { name: "", email: "", guests: Number.NaN } });

  const onSubmit = async (values: FormValues) => {
    const outcome = await createBooking(tasting.id, values);
    if (outcome.ok) {
      navigate("/confirmation", { state: outcome.booking });
      return;
    }
    for (const [field, message] of Object.entries(outcome.errors)) {
      setError(field as keyof FormValues, { type: "server", message });
    }
    if (Object.keys(outcome.errors).length === 0) {
      setError("root", { type: "server", message: outcome.message });
    }
    if (outcome.errors.guests) revalidator.revalidate();
  };

  return (
    <form noValidate onSubmit={handleSubmit(onSubmit)} className="rounded-2xl border border-line bg-paper p-6 shadow-sm">
      <h2 className="font-display text-2xl text-ink">Your details</h2>

      <div className="mt-6 space-y-5">
        <div>
          <label htmlFor="name" className="block font-medium text-ink">
            Name
          </label>
          <input
            id="name"
            type="text"
            autoComplete="name"
            className={inputClass}
            aria-invalid={errors.name ? true : undefined}
            aria-describedby={errors.name ? "name-error" : undefined}
            {...register("name")}
          />
          {errors.name && (
            <p id="name-error" role="alert" className={errorText}>
              {errors.name.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="email" className="block font-medium text-ink">
            Email
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            inputMode="email"
            className={inputClass}
            aria-invalid={errors.email ? true : undefined}
            aria-describedby={errors.email ? "email-error" : undefined}
            {...register("email")}
          />
          {errors.email && (
            <p id="email-error" role="alert" className={errorText}>
              {errors.email.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="guests" className="block font-medium text-ink">
            Guests
          </label>
          <input
            id="guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={8}
            step={1}
            className={inputClass}
            aria-invalid={errors.guests ? true : undefined}
            aria-describedby={errors.guests ? "guests-error" : "guests-hint"}
            {...register("guests", { valueAsNumber: true })}
          />
          <p id="guests-hint" className="mt-1 text-sm text-muted">
            1 to 8 guests
          </p>
          {errors.guests && (
            <p id="guests-error" role="alert" className={errorText}>
              {errors.guests.message}
            </p>
          )}
        </div>
      </div>

      {errors.root && (
        <p role="alert" className={`${errorText} mt-5`}>
          {errors.root.message}
        </p>
      )}

      <div className="mt-8">
        <button type="submit" disabled={isSubmitting} className={`${primaryButton} w-full`}>
          Book
        </button>
      </div>
    </form>
  );
}
