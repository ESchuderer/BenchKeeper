import { Link, useLocation } from "react-router";
import type { BookingConfirmation } from "../../shared/tastings.js";
import { formatDateTime, formatPrice } from "../../shared/format.js";
import { primaryButton } from "../ui.js";

export function Confirmation() {
  const booking = useLocation().state as BookingConfirmation | null;

  if (!booking) {
    return (
      <section className="mx-auto max-w-xl text-center">
        <h1 className="font-display text-3xl text-wine">No booking to show</h1>
        <p className="mt-3 text-muted">Booking details are shown only directly after booking. Book again from the tastings page.</p>
        <Link to="/" className={`${primaryButton} mt-6 no-underline`}>
          Back to tastings
        </Link>
      </section>
    );
  }

  return (
    <section aria-labelledby="confirmation-heading" className="mx-auto max-w-xl rounded-2xl border border-line bg-paper p-8 shadow-md">
      <p className="text-sm uppercase tracking-wider text-success">Thank you</p>
      <h1 id="confirmation-heading" className="mt-1 font-display text-3xl text-wine">
        Booking confirmed
      </h1>

      <dl className="mt-6 grid grid-cols-[auto_1fr] gap-x-6 gap-y-3 text-ink">
        <dt className="text-muted">Tasting</dt>
        <dd className="font-medium">{booking.tastingTitle}</dd>
        <dt className="text-muted">Date and time</dt>
        <dd>{formatDateTime(booking.date, booking.time)}</dd>
        <dt className="text-muted">Guests</dt>
        <dd>{booking.guests}</dd>
        <dt className="text-muted">Total</dt>
        <dd className="font-display text-xl">{formatPrice(booking.total)}</dd>
        <dt className="text-muted">Booking reference</dt>
        <dd className="font-mono tracking-wider">{booking.reference}</dd>
      </dl>

      <p className="mt-8 text-sm text-muted">Please keep the booking reference. Show it when you arrive.</p>
    </section>
  );
}
