import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLoaderData, useRevalidator } from "react-router";
import type { StaffGroup } from "../../shared/tastings.js";
import { signInSchema, type SignInInput } from "../../shared/schemas.js";
import { formatDateTime } from "../../shared/format.js";
import { cancelBooking, signIn, signOut } from "../api.js";
import { errorText, inputClass, primaryButton, secondaryButton } from "../ui.js";

export function StaffPage() {
  const groups = useLoaderData() as StaffGroup[] | null;
  const revalidator = useRevalidator();

  if (!groups) {
    return <SignInForm onSignedIn={() => revalidator.revalidate()} />;
  }
  return <StaffBookings groups={groups} onChange={() => revalidator.revalidate()} />;
}

function SignInForm({ onSignedIn }: { onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<SignInInput>({ resolver: zodResolver(signInSchema), defaultValues: { password: "" } });

  const onSubmit = async (values: SignInInput) => {
    const outcome = await signIn(values);
    if (outcome.ok) {
      onSignedIn();
      return;
    }
    if (outcome.reason === "incorrect") {
      setError("password", { type: "server", message: outcome.message });
    } else {
      setError("root", { type: "server", message: outcome.message });
    }
  };

  return (
    <section aria-labelledby="staff-sign-in" className="mx-auto max-w-md">
      <h1 id="staff-sign-in" className="font-display text-3xl text-wine">
        Staff sign-in
      </h1>
      <form noValidate onSubmit={handleSubmit(onSubmit)} className="mt-6 rounded-2xl border border-line bg-paper p-6 shadow-sm">
        <label htmlFor="password" className="block font-medium text-ink">
          Password
        </label>
        <input
          id="password"
          type="password"
          autoComplete="current-password"
          className={inputClass}
          aria-invalid={errors.password ? true : undefined}
          aria-describedby={errors.password ? "password-error" : undefined}
          {...register("password")}
        />
        {errors.password && (
          <p id="password-error" role="alert" className={errorText}>
            {errors.password.message}
          </p>
        )}
        {errors.root && (
          <p role="alert" className={`${errorText} mt-4`}>
            {errors.root.message}
          </p>
        )}
        <button type="submit" disabled={isSubmitting} className={`${primaryButton} mt-6 w-full`}>
          Sign in
        </button>
      </form>
    </section>
  );
}

function StaffBookings({ groups, onChange }: { groups: StaffGroup[]; onChange: () => void }) {
  const [status, setStatus] = useState("");
  const [cancelling, setCancelling] = useState<string | null>(null);

  const handleCancel = async (reference: string) => {
    if (cancelling) return;
    setCancelling(reference);
    const cancelled = await cancelBooking(reference);
    setCancelling(null);
    setStatus(cancelled ? "Booking cancelled." : "Could not cancel the booking. The list has been refreshed.");
    onChange();
  };

  const handleSignOut = async () => {
    await signOut();
    onChange();
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-3xl text-wine">Bookings</h1>
        <button type="button" onClick={handleSignOut} className={secondaryButton}>
          Sign out
        </button>
      </div>

      <p role="status" className="mt-3 min-h-6 text-sm font-medium text-success">
        {status}
      </p>

      <div className="mt-6 space-y-8">
        {groups.map(({ tasting, bookings }) => {
          const guests = bookings.reduce((sum, booking) => sum + booking.guests, 0);
          return (
            <section key={tasting.id} aria-labelledby={`tasting-${tasting.id}`} className="rounded-2xl border border-line bg-paper p-6 shadow-sm">
              <h2 id={`tasting-${tasting.id}`} className="font-display text-2xl text-ink">
                {tasting.title}
              </h2>
              <p className="mt-1 text-sm text-muted">
                {formatDateTime(tasting.date, tasting.time)}, {guests} of {tasting.seats} seats booked
              </p>

              {bookings.length === 0 ? (
                <p className="mt-4 italic text-muted">No bookings yet</p>
              ) : (
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full min-w-[32rem] text-left text-sm">
                    <thead className="border-b border-line text-muted">
                      <tr>
                        <th scope="col" className="py-2 pr-4 font-medium">Name</th>
                        <th scope="col" className="py-2 pr-4 font-medium">Email</th>
                        <th scope="col" className="py-2 pr-4 font-medium">Guests</th>
                        <th scope="col" className="py-2 pr-4 font-medium">Reference</th>
                        <th scope="col" className="py-2 font-medium">
                          <span className="sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {bookings.map((booking) => (
                        <tr key={booking.reference} className="border-b border-line/60">
                          <td className="py-3 pr-4">{booking.name}</td>
                          <td className="py-3 pr-4">{booking.email}</td>
                          <td className="py-3 pr-4">{booking.guests}</td>
                          <td className="py-3 pr-4 font-mono">{booking.reference}</td>
                          <td className="py-3">
                            <button
                              type="button"
                              disabled={cancelling !== null}
                              onClick={() => handleCancel(booking.reference)}
                              className="min-h-11 rounded-full px-4 font-medium text-danger underline-offset-4 hover:underline disabled:text-muted disabled:no-underline"
                            >
                              Cancel
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}
