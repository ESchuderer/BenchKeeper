import { Link, useLoaderData } from "react-router";
import type { TastingView } from "../../shared/tastings.js";
import { formatDateTime, formatPrice, formatSeatsLeft } from "../../shared/format.js";
import { primaryButton } from "../ui.js";

export function TastingList() {
  const tastings = useLoaderData() as TastingView[];

  return (
    <section aria-labelledby="tastings-heading">
      <h1 id="tastings-heading" className="font-display text-4xl text-wine">
        Tastings at the estate
      </h1>
      <p className="mt-2 max-w-2xl text-muted">Choose a tasting, then reserve your places online.</p>

      <ul className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {tastings.map((tasting) => {
          const isFull = tasting.seatsLeft === 0;
          const isLow = !isFull && tasting.seatsLeft <= 3;
          const seatClass = isFull
            ? "bg-line text-muted"
            : isLow
              ? "bg-amber-100 text-amber-900"
              : "bg-green-50 text-success";
          return (
            <li key={tasting.id} className="flex">
              <article className="flex w-full flex-col rounded-2xl border border-line bg-paper p-6 shadow-sm">
                <h2 className="font-display text-2xl text-ink">{tasting.title}</h2>
                <p className="mt-2 text-sm font-medium uppercase tracking-wider text-gold">{formatDateTime(tasting.date, tasting.time)}</p>
                <p className="mt-3 text-ink">{formatPrice(tasting.price)} per guest</p>

                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <span className={`inline-block rounded-full px-3 py-1 text-sm font-semibold ${seatClass}`}>
                    {formatSeatsLeft(tasting.seatsLeft)}
                  </span>
                  {isFull && <span className="text-sm font-semibold uppercase tracking-wide text-wine">Fully booked</span>}
                </div>

                <div className="mt-auto pt-6">
                  {isFull ? (
                    <button type="button" disabled className={`${primaryButton} w-full`}>
                      Book {tasting.title}
                    </button>
                  ) : (
                    <Link to={`/tastings/${tasting.id}/book`} className={`${primaryButton} w-full no-underline`}>
                      Book {tasting.title}
                    </Link>
                  )}
                </div>
              </article>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
