import type { RouteObject } from "react-router";
import { Layout } from "./components/Layout.js";
import { RouteErrorPage } from "./components/RouteErrorPage.js";
import { BookingForm, type BookingPageData } from "./pages/BookingForm.js";
import { Confirmation } from "./pages/Confirmation.js";
import { StaffPage } from "./pages/StaffPage.js";
import { TastingList } from "./pages/TastingList.js";
import { fetchStaffBookings, fetchTastings } from "./api.js";

const loadingFallback = <p className="py-16 text-center text-muted">Loading</p>;

export const routes: RouteObject[] = [
  {
    path: "/",
    element: <Layout />,
    errorElement: <RouteErrorPage />,
    children: [
      { index: true, element: <TastingList />, loader: () => fetchTastings(), hydrateFallbackElement: loadingFallback },
      {
        path: "tastings/:id/book",
        element: <BookingForm />,
        hydrateFallbackElement: loadingFallback,
        loader: async ({ params }): Promise<BookingPageData> => {
          const tastings = await fetchTastings();
          return { tasting: tastings.find((tasting) => tasting.id === params.id) ?? null };
        },
      },
      { path: "confirmation", element: <Confirmation /> },
      { path: "staff", element: <StaffPage />, loader: () => fetchStaffBookings(), hydrateFallbackElement: loadingFallback },
    ],
  },
];
