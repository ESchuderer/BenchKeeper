export const primaryButton =
  "inline-flex min-h-11 items-center justify-center rounded-full bg-wine px-6 py-2.5 font-medium text-cream shadow-sm transition hover:bg-wine-dark disabled:cursor-not-allowed disabled:bg-line disabled:text-muted";

export const secondaryButton =
  "inline-flex min-h-11 items-center justify-center rounded-full border border-wine px-5 py-2 font-medium text-wine transition hover:bg-wine hover:text-cream";

export const inputClass =
  "mt-1 block w-full min-h-11 rounded-lg border border-line bg-paper px-3 py-2 text-ink shadow-sm focus:border-gold focus:outline-none aria-invalid:border-danger";

export const errorText = "mt-1 text-sm font-medium text-danger";
