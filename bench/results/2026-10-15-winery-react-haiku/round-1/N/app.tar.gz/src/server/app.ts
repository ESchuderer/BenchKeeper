import path from "node:path";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import express, { type ErrorRequestHandler, type Request, type RequestHandler, type Response } from "express";
import type { ZodError } from "zod";
import { bookingSchema, signInSchema } from "../shared/schemas.js";
import { createStaffAuth, SESSION_MAX_AGE_MS } from "./auth.js";
import { createStore } from "./store.js";

const SESSION_COOKIE = "kb_staff";

export type AppOptions = {
  staffPassword: string;
  clientDir: string;
  trustProxy?: boolean | number;
  now?: () => number;
};

function fieldErrors(error: ZodError): Record<string, string> {
  const messages = error.flatten().fieldErrors;
  return Object.fromEntries(
    Object.entries(messages).flatMap(([field, list]) => (list?.[0] ? [[field, list[0]]] : [])),
  );
}

function seatsMessage(seatsLeft: number): string {
  if (seatsLeft === 0) return "This tasting is fully booked";
  return `Only ${seatsLeft} ${seatsLeft === 1 ? "seat" : "seats"} left`;
}

function sessionCookieOptions(req: Request) {
  return { httpOnly: true, sameSite: "strict" as const, secure: req.secure, path: "/" };
}

export function createApp(options: AppOptions) {
  const app = express();
  const clientDir = path.resolve(options.clientDir);
  const store = createStore();
  const auth = createStaffAuth({ password: options.staffPassword, now: options.now });

  app.set("trust proxy", options.trustProxy ?? false);
  app.use(helmet());
  app.use(express.json());
  app.use(cookieParser());
  app.use("/api/staff", (_req, res, next) => {
    res.set("Cache-Control", "no-store");
    next();
  });

  const requireStaff: RequestHandler = (req, res, next) => {
    if (!auth.isValidSession(req.cookies?.[SESSION_COOKIE])) {
      res.status(401).json({ error: "Sign in required" });
      return;
    }
    next();
  };

  app.get("/api/tastings", (_req, res) => {
    res.json(store.listTastings());
  });

  app.post("/api/tastings/:id/bookings", (req, res) => {
    const parsed = bookingSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error) });
      return;
    }

    const result = store.book(req.params.id, parsed.data);
    if (!result.ok && result.reason === "not_found") {
      res.status(404).json({ error: "Tasting not found" });
      return;
    }
    if (!result.ok) {
      res.status(409).json({ errors: { guests: seatsMessage(result.seatsLeft) } });
      return;
    }

    const { booking, tasting } = result;
    res.status(201).json({
      reference: booking.reference,
      tastingId: tasting.id,
      tastingTitle: tasting.title,
      date: tasting.date,
      time: tasting.time,
      guests: booking.guests,
      total: tasting.price * booking.guests,
    });
  });

  app.post("/api/staff/session", (req, res) => {
    const parsed = signInSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error) });
      return;
    }

    const result = auth.signIn(req.ip ?? "unknown", parsed.data.password);
    if (result.ok) {
      res.cookie(SESSION_COOKIE, result.token, { ...sessionCookieOptions(req), maxAge: SESSION_MAX_AGE_MS });
      res.status(204).end();
      return;
    }
    if (result.reason === "locked") {
      const minutes = Math.ceil(result.retryAfterSeconds / 60);
      res.set("Retry-After", String(result.retryAfterSeconds));
      res.status(429).json({ error: `Too many failed attempts. Try again in ${minutes} ${minutes === 1 ? "minute" : "minutes"}` });
      return;
    }
    res.status(401).json({ error: "Incorrect password" });
  });

  app.delete("/api/staff/session", (req: Request, res: Response) => {
    auth.endSession(req.cookies?.[SESSION_COOKIE]);
    res.clearCookie(SESSION_COOKIE, sessionCookieOptions(req));
    res.status(204).end();
  });

  app.get("/api/staff/bookings", requireStaff, (_req, res) => {
    res.json(store.bookingsByTasting());
  });

  app.delete<{ reference: string }>("/api/staff/bookings/:reference", requireStaff, (req, res) => {
    if (!store.cancel(req.params.reference)) {
      res.status(404).json({ error: "Booking not found" });
      return;
    }
    res.status(204).end();
  });

  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Not found" });
  });

  const invalidJson: ErrorRequestHandler = (error, _req, res, next) => {
    if (error?.type === "entity.parse.failed") {
      res.status(400).json({ error: "Invalid JSON" });
      return;
    }
    next(error);
  };
  app.use(invalidJson);

  app.use(express.static(clientDir));
  app.get("/{*splat}", (_req, res) => {
    res.sendFile(path.join(clientDir, "index.html"));
  });

  const serverError: ErrorRequestHandler = (error, _req, res, next) => {
    if (res.headersSent) {
      next(error);
      return;
    }
    const isClientError = typeof error?.status === "number" && error.status >= 400 && error.status < 500;
    if (!isClientError) console.error(error);
    res.status(isClientError ? error.status : 500).json({
      error: isClientError ? "Invalid request" : "Something went wrong. Please try again.",
    });
  };
  app.use(serverError);

  return app;
}
