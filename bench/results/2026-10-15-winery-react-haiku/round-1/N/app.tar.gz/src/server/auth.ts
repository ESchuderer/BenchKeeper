import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export const SESSION_MAX_AGE_MS = 8 * 60 * 60 * 1000;
const WINDOW_MS = 15 * 60 * 1000;
const LOCK_MS = 15 * 60 * 1000;
const MAX_FAILURES = 5;

type Attempts = { failures: number; windowStart: number; lockedUntil: number };

export type SignInResult =
  | { ok: true; token: string }
  | { ok: false; reason: "invalid" }
  | { ok: false; reason: "locked"; retryAfterSeconds: number };

export type StaffAuth = {
  signIn(clientKey: string, password: string): SignInResult;
  isValidSession(token: string | undefined): boolean;
  endSession(token: string | undefined): void;
};

function digest(value: string): Buffer {
  return createHash("sha256").update(value).digest();
}

export function createStaffAuth(options: { password: string; now?: () => number }): StaffAuth {
  const now = options.now ?? Date.now;
  const expected = digest(options.password);
  const sessions = new Map<string, number>();
  const attempts = new Map<string, Attempts>();

  function pruneAttempts(current: number): void {
    for (const [key, record] of attempts) {
      if (record.lockedUntil <= current && current - record.windowStart > WINDOW_MS) attempts.delete(key);
    }
  }

  function issueSession(): string {
    const current = now();
    for (const [token, expiresAt] of sessions) {
      if (current >= expiresAt) sessions.delete(token);
    }
    const token = randomBytes(32).toString("base64url");
    sessions.set(token, current + SESSION_MAX_AGE_MS);
    return token;
  }

  return {
    signIn(clientKey, password) {
      const current = now();
      pruneAttempts(current);
      const record = attempts.get(clientKey) ?? { failures: 0, windowStart: current, lockedUntil: 0 };
      if (record.lockedUntil > current) {
        return { ok: false, reason: "locked", retryAfterSeconds: Math.ceil((record.lockedUntil - current) / 1000) };
      }

      if (timingSafeEqual(digest(password), expected)) {
        attempts.delete(clientKey);
        return { ok: true, token: issueSession() };
      }

      const windowExpired = current - record.windowStart > WINDOW_MS;
      const failures = (windowExpired ? 0 : record.failures) + 1;
      if (failures >= MAX_FAILURES) {
        attempts.set(clientKey, { failures: 0, windowStart: current, lockedUntil: current + LOCK_MS });
      } else {
        attempts.set(clientKey, { failures, windowStart: windowExpired ? current : record.windowStart, lockedUntil: 0 });
      }
      return { ok: false, reason: "invalid" };
    },

    isValidSession(token) {
      if (!token) return false;
      const expiresAt = sessions.get(token);
      if (expiresAt === undefined) return false;
      if (now() >= expiresAt) {
        sessions.delete(token);
        return false;
      }
      return true;
    },

    endSession(token) {
      if (token) sessions.delete(token);
    },
  };
}
