import path from "node:path";
import { createApp } from "./app.js";

const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) {
  console.error("STAFF_PASSWORD must be set to a non-empty value");
  process.exit(1);
}

function parseTrustProxy(value: string | undefined): boolean | number {
  if (!value) return false;
  if (/^\d+$/.test(value)) return Number(value);
  console.error("TRUST_PROXY must be unset or a number of proxy hops, for example 1");
  process.exit(1);
}

const port = Number(process.env.PORT || 3000);

createApp({
  staffPassword,
  clientDir: path.resolve(import.meta.dirname, "../client"),
  trustProxy: parseTrustProxy(process.env.TRUST_PROXY),
}).listen(port, () => {
  console.log(`Weingut Kieselbrunnen booking app listening on port ${port}`);
});
