import { randomInt } from "node:crypto";
import type { BookingInput } from "../shared/schemas.js";
import { TASTINGS, type Booking, type Tasting, type TastingView } from "../shared/tastings.js";

const REFERENCE_PREFIX = "KB-";
const REFERENCE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
const REFERENCE_LENGTH = 6;

export type BookResult =
  | { ok: true; booking: Booking; tasting: TastingView }
  | { ok: false; reason: "not_found" }
  | { ok: false; reason: "insufficient_seats"; seatsLeft: number };

export type Store = {
  listTastings(): TastingView[];
  getTasting(id: string): TastingView | undefined;
  book(tastingId: string, input: BookingInput): BookResult;
  bookingsByTasting(): { tasting: TastingView; bookings: Booking[] }[];
  cancel(reference: string): boolean;
};

/** In-memory store. Check and insert in book() run without an await, so concurrent requests cannot overbook. */
export function createStore(): Store {
  const bookings: Booking[] = [];

  function view(tasting: Tasting): TastingView {
    const booked = bookings
      .filter((booking) => booking.tastingId === tasting.id)
      .reduce((sum, booking) => sum + booking.guests, 0);
    return { ...tasting, seatsLeft: tasting.seats - booked };
  }

  function newReference(): string {
    let reference: string;
    do {
      const suffix = Array.from({ length: REFERENCE_LENGTH }, () => REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)]).join("");
      reference = REFERENCE_PREFIX + suffix;
    } while (bookings.some((booking) => booking.reference === reference));
    return reference;
  }

  return {
    listTastings: () => TASTINGS.map(view),

    getTasting(id) {
      const tasting = TASTINGS.find((candidate) => candidate.id === id);
      return tasting && view(tasting);
    },

    book(tastingId, input) {
      const tasting = TASTINGS.find((candidate) => candidate.id === tastingId);
      if (!tasting) return { ok: false, reason: "not_found" };

      const current = view(tasting);
      if (input.guests > current.seatsLeft) {
        return { ok: false, reason: "insufficient_seats", seatsLeft: current.seatsLeft };
      }

      const booking: Booking = { reference: newReference(), tastingId, name: input.name, email: input.email, guests: input.guests };
      bookings.push(booking);
      return { ok: true, booking, tasting: view(tasting) };
    },

    bookingsByTasting: () =>
      TASTINGS.map((tasting) => ({
        tasting: view(tasting),
        bookings: bookings.filter((booking) => booking.tastingId === tasting.id),
      })),

    cancel(reference) {
      const index = bookings.findIndex((booking) => booking.reference === reference);
      if (index === -1) return false;
      bookings.splice(index, 1);
      return true;
    },
  };
}
