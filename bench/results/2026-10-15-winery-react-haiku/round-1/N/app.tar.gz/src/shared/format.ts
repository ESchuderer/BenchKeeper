const DATE_TIME = new Intl.DateTimeFormat("en-GB", {
  weekday: "short",
  day: "numeric",
  month: "short",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
  timeZone: "UTC",
});

/** Formats the wall-clock date and time as entered; UTC is used only to avoid host time-zone shifts. */
export function formatDateTime(date: string, time: string): string {
  const [year, month, day] = date.split("-").map(Number);
  const [hour, minute] = time.split(":").map(Number);
  return DATE_TIME.format(new Date(Date.UTC(year, month - 1, day, hour, minute)));
}

export function formatPrice(eur: number): string {
  return `EUR ${eur}`;
}

export function formatSeatsLeft(seatsLeft: number): string {
  return `${seatsLeft} ${seatsLeft === 1 ? "seat" : "seats"} left`;
}
