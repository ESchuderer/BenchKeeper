import { z } from "zod";

const GUESTS_MESSAGE = "Guests must be a whole number from 1 to 8";

export const bookingSchema = z.object({
  name: z.string().trim().min(1, "Enter your name").max(100, "Name must be 100 characters or fewer"),
  email: z.string().trim().max(254, "Enter a valid email address").email("Enter a valid email address"),
  guests: z
    .number({ required_error: GUESTS_MESSAGE, invalid_type_error: GUESTS_MESSAGE })
    .int(GUESTS_MESSAGE)
    .min(1, GUESTS_MESSAGE)
    .max(8, GUESTS_MESSAGE),
});

export const signInSchema = z.object({
  password: z.string().min(1, "Enter the password"),
});

export type BookingInput = z.infer<typeof bookingSchema>;
export type SignInInput = z.infer<typeof signInSchema>;
