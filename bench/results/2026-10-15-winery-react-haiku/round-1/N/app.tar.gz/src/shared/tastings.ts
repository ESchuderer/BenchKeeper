export type Tasting = {
  id: string;
  title: string;
  date: string;
  time: string;
  price: number;
  seats: number;
};

export type TastingView = Tasting & { seatsLeft: number };

export type Booking = {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
};

export type BookingConfirmation = {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  date: string;
  time: string;
  guests: number;
  total: number;
};

export type StaffGroup = { tasting: TastingView; bookings: Booking[] };

export const TASTINGS: readonly Tasting[] = [
  { id: "riesling-evening", title: "Riesling Evening", date: "2026-11-06", time: "18:00", price: 25, seats: 12 },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", date: "2026-11-14", time: "15:00", price: 32, seats: 8 },
  { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00", price: 28, seats: 10 },
];
