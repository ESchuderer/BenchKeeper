// @vitest-environment jsdom
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { json, renderApp, stubFetch, tastingViews, type Handlers } from "./helpers.js";

const BOOK_PATH = "/tastings/riesling-evening/book";
const POST_KEY = "POST /api/tastings/riesling-evening/bookings";

const baseHandlers = (): Handlers => ({ "GET /api/tastings": () => json(200, tastingViews()) });

async function openForm() {
  const user = userEvent.setup();
  renderApp(BOOK_PATH);
  await screen.findByLabelText("Name");
  return user;
}

async function fillForm(user: ReturnType<typeof userEvent.setup>, guests = "3") {
  await user.type(screen.getByLabelText("Name"), "Ann Example");
  await user.type(screen.getByLabelText("Email"), "ann@example.com");
  await user.type(screen.getByLabelText("Guests"), guests);
}

describe("booking form", () => {
  it("shows an error next to Name, Email and Guests on empty submit and sends nothing", async () => {
    const { calls } = stubFetch(baseHandlers());
    const user = await openForm();

    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Enter your name")).toBeInTheDocument();
    expect(screen.getByText("Enter a valid email address")).toBeInTheDocument();
    expect(screen.getByText("Guests must be a whole number from 1 to 8")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByLabelText("Email")).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByLabelText("Guests")).toHaveAttribute("aria-invalid", "true");
    expect(calls.some((c) => c.key === POST_KEY)).toBe(false);
  });

  it("shows the server message on Guests when the tasting lacks seats", async () => {
    stubFetch({ ...baseHandlers(), [POST_KEY]: () => json(409, { errors: { guests: "Only 2 seats left" } }) });
    const user = await openForm();
    await fillForm(user);

    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Only 2 seats left")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByLabelText("Name")).not.toHaveAttribute("aria-invalid", "true");
  });

  it("shows server field errors from a 400 response on the matching field", async () => {
    stubFetch({ ...baseHandlers(), [POST_KEY]: () => json(400, { errors: { email: "Enter a valid email address" } }) });
    const user = await openForm();
    await fillForm(user);

    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Enter a valid email address")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toHaveAttribute("aria-invalid", "true");
  });

  it("sends the booking and shows the confirmation", async () => {
    const reply = {
      reference: "KB-ABC234",
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      date: "2026-11-06",
      time: "18:00",
      guests: 3,
      total: 75,
    };
    const { calls } = stubFetch({ ...baseHandlers(), [POST_KEY]: () => json(201, reply) });
    const user = await openForm();
    await fillForm(user);

    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(screen.getByText(/KB-ABC234/)).toBeInTheDocument();
    expect(screen.getByText(/EUR 75/)).toBeInTheDocument();
    expect(screen.getByText("Riesling Evening")).toBeInTheDocument();
    expect(screen.getByText("3")).toBeInTheDocument();
    await waitFor(() => expect(calls.find((c) => c.key === POST_KEY)?.body).toEqual({
      name: "Ann Example",
      email: "ann@example.com",
      guests: 3,
    }));
  });

  it("tells the guest when the server cannot be reached", async () => {
    stubFetch({
      ...baseHandlers(),
      [POST_KEY]: () => {
        throw new TypeError("Failed to fetch");
      },
    });
    const user = await openForm();
    await fillForm(user);

    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Could not reach the server. Please try again.")).toBeInTheDocument();
  });

  it("refreshes the tasting after a 409 so the seat count is current", async () => {
    let seatsLeft = 5;
    stubFetch({
      "GET /api/tastings": () => json(200, tastingViews({ "riesling-evening": seatsLeft })),
      [POST_KEY]: () => json(409, { errors: { guests: "Only 2 seats left" } }),
    });
    const user = await openForm();
    seatsLeft = 2;
    await fillForm(user);

    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Only 2 seats left")).toBeInTheDocument();
    expect(await screen.findByText("2 seats left")).toBeInTheDocument();
  });
});
