import { cleanup, render } from "@testing-library/react";
import { createMemoryRouter, RouterProvider } from "react-router";
import { afterEach, vi } from "vitest";
import { routes } from "../../src/client/routes.js";

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

export type Handler = (call: { body: unknown }) => Response;
export type Handlers = Record<string, Handler>;

export const json = (status: number, body: unknown, headers: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", ...headers } });

export const noContent = () => new Response(null, { status: 204 });

/** Stubs fetch; handlers are keyed "METHOD /api/path". Unhandled calls fail the request. */
export function stubFetch(handlers: Handlers) {
  const calls: { key: string; body: unknown }[] = [];
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const request = input instanceof Request ? input : undefined;
    const url = request?.url ?? String(input);
    const method = (init?.method ?? request?.method ?? "GET").toUpperCase();
    const key = `${method} ${new URL(url, "http://localhost").pathname}`;
    const rawBody = init?.body ?? (request ? await request.clone().text() : undefined);
    const body = typeof rawBody === "string" && rawBody ? JSON.parse(rawBody) : undefined;
    calls.push({ key, body });
    const handler = handlers[key];
    if (!handler) throw new Error(`Unexpected fetch: ${key}`);
    return handler({ body });
  });
  vi.stubGlobal("fetch", fetchMock);
  return { calls, fetchMock };
}

export function renderApp(path: string) {
  const router = createMemoryRouter(routes, { initialEntries: [path] });
  return render(<RouterProvider router={router} />);
}

export const tastingViews = (seatsLeft: Record<string, number> = {}) => [
  { id: "riesling-evening", title: "Riesling Evening", date: "2026-11-06", time: "18:00", price: 25, seats: 12, seatsLeft: seatsLeft["riesling-evening"] ?? 12 },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", date: "2026-11-14", time: "15:00", price: 32, seats: 8, seatsLeft: seatsLeft["red-wine-cellar-tour"] ?? 8 },
  { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00", price: 28, seats: 10, seatsLeft: seatsLeft["winter-tasting"] ?? 10 },
];
