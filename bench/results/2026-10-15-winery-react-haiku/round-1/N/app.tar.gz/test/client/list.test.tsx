// @vitest-environment jsdom
import { screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { json, renderApp, stubFetch, tastingViews } from "./helpers.js";

describe("start page", () => {
  it("lists every tasting with date, time, price and seats left", async () => {
    stubFetch({ "GET /api/tastings": () => json(200, tastingViews()) });

    renderApp("/");

    expect(await screen.findByText("Riesling Evening")).toBeInTheDocument();
    expect(screen.getByText("Red Wine Cellar Tour")).toBeInTheDocument();
    expect(screen.getByText("Winter Tasting")).toBeInTheDocument();
    expect(screen.getByText(/6 Nov 2026/)).toBeInTheDocument();
    expect(screen.getByText(/18:00/)).toBeInTheDocument();
    expect(screen.getByText(/EUR 25 per guest/)).toBeInTheDocument();
    expect(screen.getByText(/EUR 32 per guest/)).toBeInTheDocument();
    expect(screen.getByText(/12 seats left/)).toBeInTheDocument();
    expect(screen.getByText(/8 seats left/)).toBeInTheDocument();
  });

  it("links each tasting to its booking form", async () => {
    stubFetch({ "GET /api/tastings": () => json(200, tastingViews()) });

    renderApp("/");

    const link = await screen.findByRole("link", { name: "Book Riesling Evening" });
    expect(link).toHaveAttribute("href", "/tastings/riesling-evening/book");
    expect(screen.getByRole("link", { name: "Book Winter Tasting" })).toHaveAttribute("href", "/tastings/winter-tasting/book");
  });

  it("shows Fully booked and no enabled Book link for a tasting without seats", async () => {
    stubFetch({ "GET /api/tastings": () => json(200, tastingViews({ "red-wine-cellar-tour": 0 })) });

    renderApp("/");

    expect(await screen.findByText("Fully booked")).toBeInTheDocument();
    expect(screen.getByText("0 seats left")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Red Wine Cellar Tour" })).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book Red Wine Cellar Tour" })).toBeDisabled();
    expect(screen.getByRole("link", { name: "Book Riesling Evening" })).toBeInTheDocument();
  });
});
