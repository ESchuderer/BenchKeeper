// @vitest-environment jsdom
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { json, noContent, renderApp, stubFetch, tastingViews, type Handlers } from "./helpers.js";

const tastings = tastingViews();
const ann = { reference: "KB-AAAAA2", tastingId: "riesling-evening", name: "Ann Example", email: "ann@example.com", guests: 2 };
const bo = { reference: "KB-BBBBB3", tastingId: "riesling-evening", name: "Bo Tester", email: "bo@example.com", guests: 1 };

function staffHandlers(options: { signedIn: boolean }) {
  const state = { signedIn: options.signedIn, bookings: [ann, bo] };
  const handlers: Handlers = {
    "GET /api/staff/bookings": () =>
      state.signedIn
        ? json(200, [
            { tasting: tastings[0], bookings: state.bookings },
            { tasting: tastings[1], bookings: [] },
            { tasting: tastings[2], bookings: [] },
          ])
        : json(401, { error: "Sign in required" }),
    "POST /api/staff/session": ({ body }) => {
      if ((body as { password: string }).password !== "right") return json(401, { error: "Incorrect password" });
      state.signedIn = true;
      return noContent();
    },
    "DELETE /api/staff/bookings/KB-AAAAA2": () => {
      state.bookings = state.bookings.filter((b) => b !== ann);
      return noContent();
    },
  };
  return { state, handlers };
}

async function signInAs(password: string) {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText("Password"), password);
  await user.click(screen.getByRole("button", { name: "Sign in" }));
  return user;
}

describe("staff page", () => {
  it("asks for the password when not signed in", async () => {
    stubFetch(staffHandlers({ signedIn: false }).handlers);

    renderApp("/staff");

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
    expect(screen.queryByText("Ann Example")).not.toBeInTheDocument();
  });

  it("shows Incorrect password for a wrong password", async () => {
    stubFetch(staffHandlers({ signedIn: false }).handlers);
    renderApp("/staff");

    await signInAs("wrong");

    expect(await screen.findByText("Incorrect password")).toBeInTheDocument();
    expect(screen.queryByText("Ann Example")).not.toBeInTheDocument();
  });

  it("shows the lockout message on a 429 response", async () => {
    const { handlers } = staffHandlers({ signedIn: false });
    handlers["POST /api/staff/session"] = () =>
      json(429, { error: "Too many failed attempts. Try again in 15 minutes" }, { "Retry-After": "900" });
    stubFetch(handlers);
    renderApp("/staff");

    await signInAs("right");

    expect(await screen.findByText(/Too many failed attempts/)).toBeInTheDocument();
  });

  it("lists bookings grouped by tasting after sign in", async () => {
    stubFetch(staffHandlers({ signedIn: false }).handlers);
    renderApp("/staff");

    await signInAs("right");

    expect(await screen.findByText("Ann Example")).toBeInTheDocument();
    expect(screen.getByText("ann@example.com")).toBeInTheDocument();
    expect(screen.getByText(/KB-AAAAA2/)).toBeInTheDocument();
    expect(screen.getByText("Bo Tester")).toBeInTheDocument();
    expect(screen.getByText(/KB-BBBBB3/)).toBeInTheDocument();
    expect(screen.getByText("Riesling Evening")).toBeInTheDocument();
    expect(screen.getByText("Winter Tasting")).toBeInTheDocument();
    expect(screen.getAllByText("No bookings yet")).toHaveLength(2);
    expect(screen.getAllByRole("button", { name: "Cancel" })).toHaveLength(2);
  });

  it("shows bookings straight away when the session is still valid", async () => {
    stubFetch(staffHandlers({ signedIn: true }).handlers);

    renderApp("/staff");

    expect(await screen.findByText("Ann Example")).toBeInTheDocument();
    expect(screen.queryByLabelText("Password")).not.toBeInTheDocument();
  });

  it("removes a row after Cancel and calls DELETE for that reference", async () => {
    const { calls } = stubFetch(staffHandlers({ signedIn: true }).handlers);
    const user = userEvent.setup();
    renderApp("/staff");
    await screen.findByText("Ann Example");

    await user.click(screen.getAllByRole("button", { name: "Cancel" })[0]);

    await waitFor(() => expect(screen.queryByText("Ann Example")).not.toBeInTheDocument());
    expect(calls.some((c) => c.key === "DELETE /api/staff/bookings/KB-AAAAA2")).toBe(true);
    expect(screen.getByText("Bo Tester")).toBeInTheDocument();
  });
});
