import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import request from "supertest";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { createApp } from "../../src/server/app.js";

const PASSWORD = "winery-secret";
const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const REFERENCE = /^KB-[A-HJKMNP-Z2-9]{6}$/;
const MARKER = "<!-- client-index-marker -->";

let clientDir: string;
const clock = { time: 1_700_000_000_000 };

beforeAll(() => {
  clientDir = mkdtempSync(join(tmpdir(), "kb-client-"));
  writeFileSync(join(clientDir, "index.html"), `<!doctype html><html><body><div id="root"></div>${MARKER}</body></html>`);
  mkdirSync(join(clientDir, "assets"));
  writeFileSync(join(clientDir, "assets", "app.js"), "console.log('static-file-marker');");
});

afterAll(() => rmSync(clientDir, { recursive: true, force: true }));

beforeEach(() => {
  clock.time = 1_700_000_000_000;
});

function makeApp(options: { trustProxy?: boolean | number } = {}) {
  return createApp({ staffPassword: PASSWORD, clientDir, now: () => clock.time, ...options });
}

const booking = (guests: number, overrides: Record<string, unknown> = {}) => ({
  name: "Ann Example",
  email: "ann@example.com",
  guests,
  ...overrides,
});

async function signIn(app: ReturnType<typeof makeApp>): Promise<string> {
  const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });
  const cookie = (res.headers["set-cookie"] as unknown as string[] | undefined)?.find((c) => c.startsWith("kb_staff="));
  if (res.status !== 204 || !cookie) throw new Error(`sign in failed with ${res.status}`);
  return cookie.split(";")[0];
}

async function seatsLeft(app: ReturnType<typeof makeApp>, id: string): Promise<number> {
  const res = await request(app).get("/api/tastings");
  return res.body.find((t: { id: string }) => t.id === id).seatsLeft;
}

describe("GET /api/tastings", () => {
  it("returns the three tastings with seatsLeft", async () => {
    const res = await request(makeApp()).get("/api/tastings");

    expect(res.status).toBe(200);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body).toHaveLength(3);
    expect(res.body[0]).toEqual({
      id: "riesling-evening",
      title: "Riesling Evening",
      date: "2026-11-06",
      time: "18:00",
      price: 25,
      seats: 12,
      seatsLeft: 12,
    });
  });
});

describe("POST /api/tastings/:id/bookings", () => {
  it("creates a booking and returns the confirmation with the total", async () => {
    const app = makeApp();

    const res = await request(app).post("/api/tastings/riesling-evening/bookings").send(booking(3));

    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(REFERENCE),
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      date: "2026-11-06",
      time: "18:00",
      guests: 3,
      total: 75,
    });
    expect(await seatsLeft(app, "riesling-evening")).toBe(9);
  });

  it("trims name and email before storing", async () => {
    const app = makeApp();
    const cookie = await signIn(app);

    await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send(booking(1, { name: "  Ann  ", email: " ann@example.com " }));

    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(res.body[0].bookings[0]).toMatchObject({ name: "Ann", email: "ann@example.com" });
  });

  it("returns one message per invalid field and stores nothing", async () => {
    const app = makeApp();

    const res = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .send({ name: "", email: "nope", guests: 0 });

    expect(res.status).toBe(400);
    expect(res.body).toEqual({
      errors: {
        name: "Enter your name",
        email: "Enter a valid email address",
        guests: "Guests must be a whole number from 1 to 8",
      },
    });
    expect(await seatsLeft(app, "riesling-evening")).toBe(12);
  });

  it("returns only the errors of the invalid fields", async () => {
    const res = await request(makeApp()).post("/api/tastings/riesling-evening/bookings").send(booking(9));

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ errors: { guests: "Guests must be a whole number from 1 to 8" } });
  });

  it.each([{}, { name: "Ann" }, { guests: "3" }, { guests: 2.5 }])("rejects the incomplete or mistyped body %j", async (body) => {
    const res = await request(makeApp()).post("/api/tastings/riesling-evening/bookings").send(body);

    expect(res.status).toBe(400);
    expect(res.body.errors).toBeDefined();
  });

  it("returns 400 with Invalid JSON for a malformed body", async () => {
    const res = await request(makeApp())
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "application/json")
      .send("{not json");

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ error: "Invalid JSON" });
  });

  it("returns 413 JSON for a body over the size limit", async () => {
    const res = await request(makeApp())
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "application/json")
      .send(JSON.stringify({ name: "a".repeat(150_000) }));

    expect(res.status).toBe(413);
    expect(res.body).toEqual({ error: "Invalid request" });
  });

  it("returns 400 JSON for an undecodable path parameter", async () => {
    const res = await request(makeApp()).post("/api/tastings/%E0%A4%A/bookings").send(booking(1));

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ error: "Invalid request" });
  });

  it("returns 404 JSON for an unknown tasting", async () => {
    const res = await request(makeApp()).post("/api/tastings/nope/bookings").send(booking(1));

    expect(res.status).toBe(404);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(typeof res.body.error).toBe("string");
  });

  it("accepts exactly the remaining seats", async () => {
    const app = makeApp();
    await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send(booking(5));

    const res = await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send(booking(3));

    expect(res.status).toBe(201);
    expect(await seatsLeft(app, "red-wine-cellar-tour")).toBe(0);
  });

  it("returns 409 with the seats left when over capacity and stores nothing", async () => {
    const app = makeApp();
    await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send(booking(6));

    const res = await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send(booking(3));

    expect(res.status).toBe(409);
    expect(res.body).toEqual({ errors: { guests: "Only 2 seats left" } });
    expect(await seatsLeft(app, "red-wine-cellar-tour")).toBe(2);
  });

  it("uses the singular when one seat is left", async () => {
    const app = makeApp();
    await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send(booking(7));

    const res = await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send(booking(2));

    expect(res.status).toBe(409);
    expect(res.body).toEqual({ errors: { guests: "Only 1 seat left" } });
  });

  it("returns the fully booked message when no seats are left", async () => {
    const app = makeApp();
    await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send(booking(8));

    const res = await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send(booking(1));

    expect(res.status).toBe(409);
    expect(res.body).toEqual({ errors: { guests: "This tasting is fully booked" } });
  });

  it("lets exactly one of two parallel over-capacity requests succeed", async () => {
    const app = makeApp();
    const send = () => request(app).post("/api/tastings/winter-tasting/bookings").send(booking(8));

    const responses = await Promise.all([send(), send()]);

    expect(responses.map((r) => r.status).sort()).toEqual([201, 409]);
    expect(await seatsLeft(app, "winter-tasting")).toBe(2);
  });

  it("never overbooks under many parallel requests", async () => {
    const app = makeApp();
    const send = () => request(app).post("/api/tastings/riesling-evening/bookings").send(booking(5));

    const responses = await Promise.all(Array.from({ length: 6 }, send));

    expect(responses.filter((r) => r.status === 201)).toHaveLength(2);
    expect(responses.filter((r) => r.status === 409)).toHaveLength(4);
    expect(await seatsLeft(app, "riesling-evening")).toBe(2);
  });
});

describe("POST /api/staff/session", () => {
  it("returns 204 and a hardened session cookie", async () => {
    const res = await request(makeApp()).post("/api/staff/session").send({ password: PASSWORD });

    expect(res.status).toBe(204);
    const cookie = (res.headers["set-cookie"] as unknown as string[]).join("\n");
    expect(cookie).toMatch(/kb_staff=[^;\s]+/);
    expect(cookie).toContain("HttpOnly");
    expect(cookie).toContain("SameSite=Strict");
    expect(cookie).toContain("Path=/");
    expect(cookie).toContain("Max-Age=28800");
    expect(cookie).not.toContain("Secure");
  });

  it("adds Secure when the proxy reports HTTPS and trustProxy is on", async () => {
    const app = makeApp({ trustProxy: true });

    const res = await request(app).post("/api/staff/session").set("X-Forwarded-Proto", "https").send({ password: PASSWORD });

    expect((res.headers["set-cookie"] as unknown as string[]).join("\n")).toContain("Secure");
  });

  it("omits Secure for plain HTTP behind a trusted proxy", async () => {
    const app = makeApp({ trustProxy: true });

    const res = await request(app).post("/api/staff/session").set("X-Forwarded-Proto", "http").send({ password: PASSWORD });

    expect((res.headers["set-cookie"] as unknown as string[]).join("\n")).not.toContain("Secure");
  });

  it("ignores X-Forwarded-Proto when trustProxy is off", async () => {
    const res = await request(makeApp()).post("/api/staff/session").set("X-Forwarded-Proto", "https").send({ password: PASSWORD });

    expect((res.headers["set-cookie"] as unknown as string[]).join("\n")).not.toContain("Secure");
  });

  it("returns 401 without a cookie for a wrong password", async () => {
    const res = await request(makeApp()).post("/api/staff/session").send({ password: "wrong" });

    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: "Incorrect password" });
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it.each([{}, { password: "" }, { password: 42 }])("rejects the body %j without a session", async (body) => {
    const res = await request(makeApp()).post("/api/staff/session").send(body);

    expect([400, 401]).toContain(res.status);
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("locks out after 5 wrong passwords with Retry-After and a message", async () => {
    const app = makeApp();
    for (let i = 0; i < 5; i += 1) {
      const res = await request(app).post("/api/staff/session").send({ password: "wrong" });
      expect(res.status).toBe(401);
    }

    const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });

    expect(res.status).toBe(429);
    expect(res.headers["retry-after"]).toBe("900");
    expect(res.body.error).toMatch(/^Too many failed attempts\. Try again in \d+ minutes?$/);
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("accepts the correct password again after the lock expires", async () => {
    const app = makeApp();
    for (let i = 0; i < 5; i += 1) await request(app).post("/api/staff/session").send({ password: "wrong" });

    clock.time += 15 * MINUTE;
    const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });

    expect(res.status).toBe(204);
  });
});

describe("staff routes", () => {
  it.each([
    ["get", "/api/staff/bookings"],
    ["delete", "/api/staff/bookings/KB-AAAAAA"],
  ] as const)("%s %s returns 401 without a cookie", async (method, path) => {
    const res = await request(makeApp())[method](path);

    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: "Sign in required" });
  });

  it("returns 401 for an unknown session cookie", async () => {
    const res = await request(makeApp()).get("/api/staff/bookings").set("Cookie", "kb_staff=forged");

    expect(res.status).toBe(401);
  });

  it("lists bookings grouped by tasting, including empty tastings", async () => {
    const app = makeApp();
    const cookie = await signIn(app);
    await request(app).post("/api/tastings/winter-tasting/bookings").send(booking(2));

    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);

    expect(res.status).toBe(200);
    expect(res.body.map((g: { tasting: { id: string } }) => g.tasting.id)).toEqual([
      "riesling-evening",
      "red-wine-cellar-tour",
      "winter-tasting",
    ]);
    expect(res.body[0].bookings).toEqual([]);
    expect(res.body[2].tasting.seatsLeft).toBe(8);
    expect(res.body[2].bookings).toEqual([
      {
        reference: expect.stringMatching(REFERENCE),
        tastingId: "winter-tasting",
        name: "Ann Example",
        email: "ann@example.com",
        guests: 2,
      },
    ]);
  });

  it("cancels a booking, frees its seats and removes it from the list", async () => {
    const app = makeApp();
    const cookie = await signIn(app);
    const created = await request(app).post("/api/tastings/riesling-evening/bookings").send(booking(4));
    expect(await seatsLeft(app, "riesling-evening")).toBe(8);

    const res = await request(app).delete(`/api/staff/bookings/${created.body.reference}`).set("Cookie", cookie);

    expect(res.status).toBe(204);
    expect(await seatsLeft(app, "riesling-evening")).toBe(12);
    const list = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(list.body[0].bookings).toEqual([]);
  });

  it("keeps the booking when cancelling without a session", async () => {
    const app = makeApp();
    const created = await request(app).post("/api/tastings/riesling-evening/bookings").send(booking(4));

    const res = await request(app).delete(`/api/staff/bookings/${created.body.reference}`);

    expect(res.status).toBe(401);
    expect(await seatsLeft(app, "riesling-evening")).toBe(8);
  });

  it("returns 404 JSON when cancelling an unknown reference", async () => {
    const app = makeApp();
    const cookie = await signIn(app);

    const res = await request(app).delete("/api/staff/bookings/KB-AAAAAA").set("Cookie", cookie);

    expect(res.status).toBe(404);
    expect(typeof res.body.error).toBe("string");
  });

  it("rejects the cookie after 8 hours", async () => {
    const app = makeApp();
    const cookie = await signIn(app);

    clock.time += 8 * HOUR + 1000;
    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);

    expect(res.status).toBe(401);
  });
});

describe("DELETE /api/staff/session", () => {
  it("returns 204, clears the cookie and invalidates the session", async () => {
    const app = makeApp();
    const cookie = await signIn(app);

    const res = await request(app).delete("/api/staff/session").set("Cookie", cookie);

    expect(res.status).toBe(204);
    expect((res.headers["set-cookie"] as unknown as string[]).join("\n")).toMatch(/kb_staff=;/);
    const after = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(after.status).toBe(401);
  });

  it("returns 204 even without a session", async () => {
    const res = await request(makeApp()).delete("/api/staff/session");

    expect(res.status).toBe(204);
  });
});

describe("unknown API paths", () => {
  it.each(["get", "post", "delete"] as const)("%s /api/nope returns JSON 404", async (method) => {
    const res = await request(makeApp())[method]("/api/nope");

    expect(res.status).toBe(404);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body).toEqual({ error: "Not found" });
  });
});

describe("client files", () => {
  it.each(["/", "/staff", "/tastings/riesling-evening/book", "/confirmation"])("serves index.html for %s", async (path) => {
    const res = await request(makeApp()).get(path);

    expect(res.status).toBe(200);
    expect(res.headers["content-type"]).toMatch(/text\/html/);
    expect(res.text).toContain(MARKER);
  });

  it("serves static files as they are", async () => {
    const res = await request(makeApp()).get("/assets/app.js");

    expect(res.status).toBe(200);
    expect(res.text).toContain("static-file-marker");
  });
});
