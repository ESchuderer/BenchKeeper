import { beforeEach, describe, expect, it } from "vitest";
import { createStaffAuth } from "../../src/server/auth.js";

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const PASSWORD = "correct horse";

let time: number;
let auth: ReturnType<typeof createStaffAuth>;

beforeEach(() => {
  time = 1_700_000_000_000;
  auth = createStaffAuth({ password: PASSWORD, now: () => time });
});

function failTimes(count: number, key = "client-a") {
  for (let i = 0; i < count; i += 1) auth.signIn(key, "wrong");
}

describe("sign in", () => {
  it("returns a session token for the correct password", () => {
    const result = auth.signIn("client-a", PASSWORD);

    expect(result.ok).toBe(true);
    expect(result.ok && result.token.length).toBeGreaterThan(0);
  });

  it("rejects a wrong password as invalid", () => {
    const result = auth.signIn("client-a", "wrong");

    expect(result.ok).toBe(false);
    expect(!result.ok && result.reason).toBe("invalid");
  });

  it("rejects a password of a different length without throwing", () => {
    expect(auth.signIn("client-a", "x")).toMatchObject({ ok: false, reason: "invalid" });
    expect(auth.signIn("client-a", "x".repeat(10_000))).toMatchObject({ ok: false, reason: "invalid" });
  });

  it("issues a different token for every sign in", () => {
    const a = auth.signIn("client-a", PASSWORD);
    const b = auth.signIn("client-a", PASSWORD);

    expect(a.ok && b.ok && a.token !== b.token).toBe(true);
  });
});

describe("lockout", () => {
  it("returns invalid for the 5th wrong attempt and locked from the 6th", () => {
    failTimes(4);

    const fifth = auth.signIn("client-a", "wrong");
    const sixth = auth.signIn("client-a", "wrong");

    expect(fifth).toMatchObject({ ok: false, reason: "invalid" });
    expect(sixth).toMatchObject({ ok: false, reason: "locked", retryAfterSeconds: 900 });
  });

  it("stays locked even for the correct password", () => {
    failTimes(5);

    const result = auth.signIn("client-a", PASSWORD);

    expect(result).toMatchObject({ ok: false, reason: "locked" });
  });

  it("reports the remaining lock time as retryAfterSeconds", () => {
    failTimes(5);
    time += 10 * MINUTE;

    const result = auth.signIn("client-a", PASSWORD);

    expect(result).toMatchObject({ ok: false, reason: "locked", retryAfterSeconds: 300 });
  });

  it("does not extend the lock while locked", () => {
    failTimes(5);
    time += 14 * MINUTE;
    auth.signIn("client-a", "wrong");
    time += 1 * MINUTE;

    expect(auth.signIn("client-a", PASSWORD).ok).toBe(true);
  });

  it("unlocks after 15 minutes", () => {
    failTimes(5);
    time += 15 * MINUTE - 1000;
    expect(auth.signIn("client-a", PASSWORD)).toMatchObject({ reason: "locked" });

    time += 1000;

    expect(auth.signIn("client-a", PASSWORD).ok).toBe(true);
  });

  it("counts failures again from zero after a lock expires", () => {
    failTimes(5);
    time += 15 * MINUTE;

    failTimes(4);

    expect(auth.signIn("client-a", PASSWORD).ok).toBe(true);
  });

  it("resets the failure count after a correct password", () => {
    failTimes(4);
    expect(auth.signIn("client-a", PASSWORD).ok).toBe(true);

    failTimes(4);

    expect(auth.signIn("client-a", PASSWORD).ok).toBe(true);
  });

  it("only counts failures inside the 15 minute window", () => {
    failTimes(4);
    time += 16 * MINUTE;

    failTimes(4);

    expect(auth.signIn("client-a", PASSWORD).ok).toBe(true);
  });

  it("locks each client key separately", () => {
    failTimes(5, "client-a");

    expect(auth.signIn("client-a", PASSWORD)).toMatchObject({ reason: "locked" });
    expect(auth.signIn("client-b", PASSWORD).ok).toBe(true);
  });
});

describe("sessions", () => {
  function signIn(key = "client-a"): string {
    const result = auth.signIn(key, PASSWORD);
    if (!result.ok) throw new Error("sign in failed");
    return result.token;
  }

  it("accepts a fresh token", () => {
    expect(auth.isValidSession(signIn())).toBe(true);
  });

  it("rejects undefined, empty and unknown tokens", () => {
    expect(auth.isValidSession(undefined)).toBe(false);
    expect(auth.isValidSession("")).toBe(false);
    expect(auth.isValidSession("not-a-token")).toBe(false);
  });

  it("is valid just before 8 hours and invalid after", () => {
    const token = signIn();

    time += 8 * HOUR - 1000;
    expect(auth.isValidSession(token)).toBe(true);

    time += 2000;
    expect(auth.isValidSession(token)).toBe(false);
  });

  it("endSession invalidates only that token", () => {
    const first = signIn();
    const second = signIn("client-b");

    auth.endSession(first);

    expect(auth.isValidSession(first)).toBe(false);
    expect(auth.isValidSession(second)).toBe(true);
  });

  it("endSession ignores undefined and unknown tokens", () => {
    expect(() => auth.endSession(undefined)).not.toThrow();
    expect(() => auth.endSession("unknown")).not.toThrow();
  });
});
