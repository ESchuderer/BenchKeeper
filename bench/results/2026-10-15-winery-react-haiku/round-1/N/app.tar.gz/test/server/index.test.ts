import { spawnSync } from "node:child_process";
import { describe, expect, it } from "vitest";

function runServer(staffPassword: string | undefined, extraEnv: NodeJS.ProcessEnv = {}) {
  const env: NodeJS.ProcessEnv = { ...process.env, PORT: "0", ...extraEnv };
  delete env.STAFF_PASSWORD;
  if (staffPassword !== undefined) env.STAFF_PASSWORD = staffPassword;
  return spawnSync(process.execPath, ["--import", "tsx", "src/server/index.ts"], {
    cwd: process.cwd(),
    env,
    encoding: "utf8",
    timeout: 20_000,
  });
}

describe("server entry point", () => {
  it("exits with code 1 and names the variable when STAFF_PASSWORD is unset", { timeout: 30_000 }, () => {
    const result = runServer(undefined);

    expect(result.status).toBe(1);
    expect(result.stdout + result.stderr).toContain("STAFF_PASSWORD");
  });

  it("exits with code 1 when STAFF_PASSWORD is empty", { timeout: 30_000 }, () => {
    const result = runServer("");

    expect(result.status).toBe(1);
  });

  it("exits with code 1 when TRUST_PROXY is true, since it lets clients spoof their address", { timeout: 30_000 }, () => {
    const result = runServer("test-password", { TRUST_PROXY: "true" });

    expect(result.status).toBe(1);
    expect(result.stderr).toContain("TRUST_PROXY");
  });
});
