import { describe, expect, it } from "vitest";
import { createStore } from "../../src/server/store.js";

const REFERENCE = /^KB-[A-HJKMNP-Z2-9]{6}$/;
const guest = (guests: number, name = "Ann") => ({ name, email: "ann@example.com", guests });

describe("store", () => {
  it("lists the three tastings with all seats free", () => {
    const store = createStore();

    const list = store.listTastings();

    expect(list.map((t) => [t.id, t.seats, t.seatsLeft])).toEqual([
      ["riesling-evening", 12, 12],
      ["red-wine-cellar-tour", 8, 8],
      ["winter-tasting", 10, 10],
    ]);
  });

  it("starts empty for every createStore call", () => {
    const first = createStore();
    first.book("riesling-evening", guest(3));

    const second = createStore();

    expect(second.getTasting("riesling-evening")?.seatsLeft).toBe(12);
  });

  it("returns undefined for an unknown tasting", () => {
    expect(createStore().getTasting("nope")).toBeUndefined();
  });

  it("decrements seats left by the guest count and stores the booking", () => {
    const store = createStore();

    const result = store.book("riesling-evening", guest(3));

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.booking).toMatchObject({ tastingId: "riesling-evening", name: "Ann", email: "ann@example.com", guests: 3 });
    expect(result.booking.reference).toMatch(REFERENCE);
    expect(store.getTasting("riesling-evening")?.seatsLeft).toBe(9);
  });

  it("accepts a booking for exactly the remaining seats", () => {
    const store = createStore();
    store.book("red-wine-cellar-tour", guest(5));

    const result = store.book("red-wine-cellar-tour", guest(3));

    expect(result.ok).toBe(true);
    expect(store.getTasting("red-wine-cellar-tour")?.seatsLeft).toBe(0);
  });

  it("rejects one guest over the remaining seats and changes nothing", () => {
    const store = createStore();
    store.book("red-wine-cellar-tour", guest(5));

    const result = store.book("red-wine-cellar-tour", guest(4, "Bo"));

    expect(result).toEqual({ ok: false, reason: "insufficient_seats", seatsLeft: 3 });
    expect(store.getTasting("red-wine-cellar-tour")?.seatsLeft).toBe(3);
    const group = store.bookingsByTasting().find((g) => g.tasting.id === "red-wine-cellar-tour");
    expect(group?.bookings).toHaveLength(1);
  });

  it("rejects a booking on a full tasting with zero seats left", () => {
    const store = createStore();
    store.book("red-wine-cellar-tour", guest(8));

    const result = store.book("red-wine-cellar-tour", guest(1));

    expect(result).toEqual({ ok: false, reason: "insufficient_seats", seatsLeft: 0 });
  });

  it("reports not_found for an unknown tasting", () => {
    const result = createStore().book("nope", guest(1));

    expect(result.ok).toBe(false);
    expect(!result.ok && result.reason).toBe("not_found");
  });

  it("groups bookings by tasting, including tastings without bookings", () => {
    const store = createStore();
    store.book("winter-tasting", guest(2, "Ann"));
    store.book("winter-tasting", guest(1, "Bo"));

    const groups = store.bookingsByTasting();

    expect(groups.map((g) => g.tasting.id)).toEqual(["riesling-evening", "red-wine-cellar-tour", "winter-tasting"]);
    expect(groups.map((g) => g.bookings.length)).toEqual([0, 0, 2]);
    expect(groups[2].bookings.map((b) => b.name)).toEqual(["Ann", "Bo"]);
    expect(groups[2].tasting.seatsLeft).toBe(7);
  });

  it("cancel removes the booking and frees its seats", () => {
    const store = createStore();
    const result = store.book("riesling-evening", guest(4));
    if (!result.ok) throw new Error("booking failed");

    const cancelled = store.cancel(result.booking.reference);

    expect(cancelled).toBe(true);
    expect(store.getTasting("riesling-evening")?.seatsLeft).toBe(12);
    expect(store.bookingsByTasting()[0].bookings).toEqual([]);
  });

  it("cancel returns false for an unknown or already cancelled reference", () => {
    const store = createStore();
    const result = store.book("riesling-evening", guest(1));
    if (!result.ok) throw new Error("booking failed");
    store.cancel(result.booking.reference);

    expect(store.cancel(result.booking.reference)).toBe(false);
    expect(store.cancel("KB-AAAAAA")).toBe(false);
    expect(store.getTasting("riesling-evening")?.seatsLeft).toBe(12);
  });

  it("frees seats so a previously rejected booking now succeeds", () => {
    const store = createStore();
    const full = store.book("red-wine-cellar-tour", guest(8));
    if (!full.ok) throw new Error("booking failed");
    expect(store.book("red-wine-cellar-tour", guest(2)).ok).toBe(false);

    store.cancel(full.booking.reference);

    expect(store.book("red-wine-cellar-tour", guest(2)).ok).toBe(true);
  });

  it("issues 200 unique references in the KB-XXXXXX format", () => {
    const store = createStore();
    const references = new Set<string>();

    for (let i = 0; i < 200; i += 1) {
      const result = store.book("riesling-evening", guest(1));
      if (!result.ok) throw new Error("booking failed");
      references.add(result.booking.reference);
      store.cancel(result.booking.reference);
    }

    expect(references.size).toBe(200);
    for (const ref of references) expect(ref).toMatch(REFERENCE);
  });
});
