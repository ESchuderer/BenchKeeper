import { describe, expect, it } from "vitest";
import { formatDateTime, formatPrice, formatSeatsLeft } from "../../src/shared/format.js";

describe("formatDateTime", () => {
  it("contains the en-GB short date and the time", () => {
    const text = formatDateTime("2026-11-06", "18:00");

    expect(text).toContain("6 Nov 2026");
    expect(text).toContain("18:00");
  });

  it("does not shift the date across time zones", () => {
    const text = formatDateTime("2026-12-05", "00:30");

    expect(text).toContain("5 Dec 2026");
    expect(text).toContain("00:30");
  });
});

describe("formatPrice", () => {
  it("formats whole euros with the EUR prefix", () => {
    expect(formatPrice(25)).toBe("EUR 25");
    expect(formatPrice(96)).toBe("EUR 96");
  });
});

describe("formatSeatsLeft", () => {
  it("uses the singular only for exactly one seat", () => {
    expect(formatSeatsLeft(1)).toBe("1 seat left");
    expect(formatSeatsLeft(2)).toBe("2 seats left");
    expect(formatSeatsLeft(0)).toBe("0 seats left");
  });
});
