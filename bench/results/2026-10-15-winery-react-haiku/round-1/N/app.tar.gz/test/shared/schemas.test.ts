import { describe, expect, it } from "vitest";
import { bookingSchema, signInSchema } from "../../src/shared/schemas.js";

const valid = { name: "Ann Example", email: "ann@example.com", guests: 2 };

function fieldErrors(input: unknown): Record<string, string[] | undefined> {
  const result = bookingSchema.safeParse(input);
  if (result.success) throw new Error("expected validation to fail");
  return result.error.flatten().fieldErrors;
}

describe("bookingSchema", () => {
  it("accepts a valid booking", () => {
    const result = bookingSchema.safeParse(valid);

    expect(result.success).toBe(true);
  });

  it("trims name and email", () => {
    const result = bookingSchema.safeParse({ ...valid, name: "  Ann  ", email: "  ann@example.com  " });

    expect(result.success && result.data).toEqual({ ...valid, name: "Ann", email: "ann@example.com" });
  });

  it("rejects an empty or whitespace-only name", () => {
    expect(fieldErrors({ ...valid, name: "" }).name).toEqual(["Enter your name"]);
    expect(fieldErrors({ ...valid, name: "   " }).name).toEqual(["Enter your name"]);
  });

  it("accepts a name of 100 characters and rejects 101", () => {
    expect(bookingSchema.safeParse({ ...valid, name: "a".repeat(100) }).success).toBe(true);
    expect(fieldErrors({ ...valid, name: "a".repeat(101) }).name).toEqual(["Name must be 100 characters or fewer"]);
  });

  it.each(["", "nope", "a@", "@b.com", "a b@c.com"])("rejects email %j", (email) => {
    expect(fieldErrors({ ...valid, email }).email).toEqual(["Enter a valid email address"]);
  });

  it.each([1, 8])("accepts %d guests", (guests) => {
    expect(bookingSchema.safeParse({ ...valid, guests }).success).toBe(true);
  });

  it.each([0, 9, -1, 2.5, Number.NaN, "abc", null, undefined])("rejects guests %j", (guests) => {
    expect(fieldErrors({ ...valid, guests }).guests).toEqual(["Guests must be a whole number from 1 to 8"]);
  });

  it("reports every invalid field at once", () => {
    const errors = fieldErrors({ name: "", email: "x", guests: 0 });

    expect(Object.keys(errors).sort()).toEqual(["email", "guests", "name"]);
  });

  it.each([undefined, null, "text", 5])("rejects non-object input %j", (input) => {
    expect(bookingSchema.safeParse(input).success).toBe(false);
  });
});

describe("signInSchema", () => {
  it("accepts a non-empty password", () => {
    expect(signInSchema.safeParse({ password: "secret" }).success).toBe(true);
  });

  it("rejects an empty password with a message", () => {
    const result = signInSchema.safeParse({ password: "" });

    expect(result.success).toBe(false);
    expect(!result.success && result.error.flatten().fieldErrors.password).toEqual(["Enter the password"]);
  });
});
