import { describe, expect, it } from "vitest";
import { TASTINGS } from "../../src/shared/tastings.js";

describe("TASTINGS", () => {
  it("lists the three tastings with their ids, dates, times, prices and seats", () => {
    expect(TASTINGS).toEqual([
      { id: "riesling-evening", title: "Riesling Evening", date: "2026-11-06", time: "18:00", price: 25, seats: 12 },
      { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", date: "2026-11-14", time: "15:00", price: 32, seats: 8 },
      { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00", price: 28, seats: 10 },
    ]);
  });

  it("uses unique ids", () => {
    expect(new Set(TASTINGS.map((t) => t.id)).size).toBe(TASTINGS.length);
  });
});
