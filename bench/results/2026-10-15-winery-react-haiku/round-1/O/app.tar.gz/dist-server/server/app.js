import { join } from 'node:path';
import express from 'express';
import { rateLimit } from 'express-rate-limit';
import { bookingSchema } from '../shared/booking.js';
import { createStore } from './store.js';
import { createStaffSessions, passwordMatches, readCookie, SESSION_COOKIE, SESSION_MS } from './staff.js';
// One error per field, keyed the way the front end names its inputs.
function fieldErrors(error) {
    const errors = {};
    for (const issue of error.issues)
        errors[String(issue.path[0] ?? 'form')] ??= issue.message;
    return errors;
}
export function createApp(options = {}) {
    const store = createStore();
    const sessions = createStaffSessions(options.now ?? Date.now);
    const app = express();
    app.use(express.json());
    function confirmation(booking) {
        const tasting = store.getTasting(booking.tastingId);
        return {
            reference: booking.reference,
            tastingId: booking.tastingId,
            tastingTitle: tasting?.title,
            guests: booking.guests,
            totalCents: booking.guests * (tasting?.priceCents ?? 0),
        };
    }
    function notFound(res, message) {
        res.status(404).json({ message });
    }
    app.get('/api/tastings', (_req, res) => {
        res.json(store.listTastings());
    });
    app.get('/api/tastings/:id', (req, res) => {
        const tasting = store.getTasting(req.params.id);
        if (!tasting)
            return notFound(res, 'Tasting not found.');
        res.json(tasting);
    });
    app.post('/api/tastings/:id/bookings', (req, res) => {
        const parsed = bookingSchema.safeParse(req.body ?? {});
        if (!parsed.success)
            return res.status(400).json({ errors: fieldErrors(parsed.error) });
        const result = store.createBooking(req.params.id, parsed.data);
        if (result.ok)
            return res.status(201).json(confirmation(result.booking));
        if (result.reason === 'not_found')
            return notFound(res, 'Tasting not found.');
        if (result.reason === 'fully_booked')
            return res.status(409).json({ message: 'This tasting is fully booked.' });
        const left = result.seatsLeft;
        return res.status(409).json({
            errors: { guests: left === 1 ? 'Only 1 seat is left.' : `Only ${left} seats are left.` },
        });
    });
    app.get('/api/bookings/:reference', (req, res) => {
        const booking = store.getBooking(req.params.reference);
        if (!booking)
            return notFound(res, 'Booking not found.');
        res.json(confirmation(booking));
    });
    // Counts failed sign-ins per client; a successful sign-in does not use up the budget.
    const signInLimiter = rateLimit({
        windowMs: 15 * 60 * 1000,
        limit: 10,
        skipSuccessfulRequests: true,
        standardHeaders: 'draft-7',
        legacyHeaders: false,
        message: { message: 'Too many sign-in attempts. Try again later.' },
    });
    function requireStaff(req, res, next) {
        if (!sessions.isValid(readCookie(req.headers.cookie, SESSION_COOKIE))) {
            return res.status(401).json({ message: 'Please sign in.' });
        }
        next();
    }
    app.post('/api/staff/session', signInLimiter, (req, res) => {
        const password = typeof req.body?.password === 'string' ? req.body.password : '';
        if (!passwordMatches(password, options.staffPassword)) {
            return res.status(401).json({ message: 'The password is wrong.' });
        }
        res.cookie(SESSION_COOKIE, sessions.start(), {
            httpOnly: true,
            sameSite: 'strict',
            path: '/',
            maxAge: SESSION_MS,
            secure: req.secure,
        });
        res.status(204).end();
    });
    app.get('/api/staff/bookings', requireStaff, (_req, res) => {
        res.json(store.listBookingsByTasting().map(({ tasting, bookings }) => ({ ...tasting, bookings })));
    });
    app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => {
        const reference = req.params.reference;
        if (!store.cancelBooking(reference)) {
            return notFound(res, 'This booking no longer exists.');
        }
        res.status(204).end();
    });
    app.use('/api', (_req, res) => notFound(res, 'Not found.'));
    const { clientDir } = options;
    if (clientDir) {
        app.use(express.static(clientDir));
        app.get('/{*path}', (_req, res) => res.sendFile(join(clientDir, 'index.html')));
    }
    const errorHandler = (err, _req, res, _next) => {
        const status = typeof err?.status === 'number' ? err.status : 500;
        if (status >= 500)
            console.error(err);
        res.status(status).json({ message: status >= 500 ? 'Something went wrong.' : err.message });
    };
    app.use(errorHandler);
    return app;
}
