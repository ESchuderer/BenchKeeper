import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
export const SESSION_COOKIE = 'staff_session';
export const SESSION_MS = 8 * 60 * 60 * 1000;
// Compares digests so the length of the password does not leak through timing.
export function passwordMatches(given, expected) {
    if (!expected)
        return false;
    const digest = (value) => createHash('sha256').update(value).digest();
    return timingSafeEqual(digest(given), digest(expected));
}
// In memory: a server restart signs every staff member out.
export function createStaffSessions(now) {
    const expiresAt = new Map();
    return {
        start() {
            for (const [old, expiry] of expiresAt)
                if (now() >= expiry)
                    expiresAt.delete(old);
            const token = randomBytes(32).toString('base64url');
            expiresAt.set(token, now() + SESSION_MS);
            return token;
        },
        isValid(token) {
            if (!token)
                return false;
            const expiry = expiresAt.get(token);
            if (expiry === undefined)
                return false;
            if (now() >= expiry) {
                expiresAt.delete(token);
                return false;
            }
            return true;
        },
    };
}
export function readCookie(header, name) {
    return header
        ?.split(';')
        .map((part) => part.trim())
        .find((part) => part.startsWith(`${name}=`))
        ?.slice(name.length + 1);
}
