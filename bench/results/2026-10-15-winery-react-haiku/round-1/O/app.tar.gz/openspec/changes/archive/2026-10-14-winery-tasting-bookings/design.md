# Design

## Stack

- **Server:** Express 5 in TypeScript. It serves the JSON API under `/api` and the built React app from `dist/`, with an SPA fallback for every other GET. One process, one port (`PORT`, default 3000).
- **Front end:** React 19 with React Router 7 (`react-router`) and Vite. Forms use React Hook Form with `@hookform/resolvers` and Zod.
- **Shared validation:** one Zod schema in `shared/booking.ts`, used by the form in the browser and re-checked by the server. The server never trusts the client.
- **Styling:** Tailwind CSS v4 through `@tailwindcss/vite`. Theme colours and fonts are defined once in the CSS `@theme` block.
- **Staff login rate limit:** `express-rate-limit`.
- **Build output:** `npm run build` runs `vite build` (client to `dist/`) and `tsc -p tsconfig.server.json` (server to `dist-server/`). `npm start` runs `node dist-server/server/index.js`.
- **Tests:** Vitest. Supertest for the API, Testing Library with jsdom for the React pages.

## Data

- **Tastings** are seeded in code (`server/tastings.ts`) with a stable id slug, title, date (`YYYY-MM-DD`), time (`HH:mm`, winery local time, no time zone conversion), `priceCents` and `seats`.
- **Money** is stored and computed in integer cents. The total is `guests * priceCents`. The UI formats it as euros.
- **Bookings** are kept in memory in a `Map` keyed by tasting id. A booking holds reference, name, email, guests and creation time. Cancelling removes the booking.
- **Known limit:** bookings are lost on restart and the store only works inside one process. Upgrade path: a JSON file behind the same store interface, or SQLite if the winery needs several instances.
- **Seats left** is computed on each read: `seats - sum(guests of bookings)`. There is no counter to drift out of sync.
- **Booking references** are `KB-` plus six characters from an alphabet without look-alikes (no 0, O, 1, I). Generation retries on the rare collision.

## Seat safety

The check "guests <= seats left" and the insert happen in one synchronous function with no `await` between them. Node runs that without interleaving, so two requests cannot both take the last seat. This holds for one process only; it is the reason the store is single-instance.

## API

| Method and path | Purpose | Responses |
|---|---|---|
| `GET /api/tastings` | All tastings with `seatsLeft`, sorted by date and time | 200 |
| `GET /api/tastings/:id` | One tasting | 200, 404 |
| `POST /api/tastings/:id/bookings` body `{name, email, guests}` | Create a booking | 201 `{reference, tastingId, tastingTitle, guests, totalCents}`; 400 `{errors}`; 404; 409 |
| `GET /api/bookings/:reference` | Confirmation details (no email) | 200, 404 |
| `POST /api/staff/session` body `{password}` | Staff sign-in, sets the session cookie | 204; 401; 429 |
| `GET /api/staff/bookings` | All bookings grouped by tasting (needs session) | 200, 401 |
| `DELETE /api/staff/bookings/:reference` | Cancel a booking (needs session) | 204; 401; 404 |

- Validation errors are `400 {"errors": {"name"|"email"|"guests": "message"}}`. The client maps each key to its field.
- A booking that asks for more guests than are left gets `409 {"errors": {"guests": "Only 3 seats are left."}}`.
- A booking for a tasting with no seats left gets `409 {"message": "This tasting is fully booked."}`. The form shows it as a form-level alert.
- Unknown `/api/*` routes return JSON 404. Other errors return JSON with a generic message.

## Staff sign-in

- The password is compared with `crypto.timingSafeEqual` on SHA-256 digests. If `STAFF_PASSWORD` is unset, every attempt is refused and the server logs a warning at start-up.
- A successful sign-in creates a random 32-byte token held in memory with an 8-hour expiry. It is sent as the cookie `staff_session` with `HttpOnly`, `SameSite=Strict`, `Path=/`, and `Secure` when the request is HTTPS.
- `SameSite=Strict` and JSON-only bodies keep the staff endpoints out of reach of cross-site forms. No separate CSRF token is needed.
- Failed sign-ins are limited to 10 per client IP per 15 minutes. Successful ones are not counted. Restarting the server ends all sessions.
- Time is injected into the app factory so the expiry and rate-limit windows can be tested without waiting.

## Front end

- **Routes:** `/` tastings list; `/tastings/:id/book` booking form; `/bookings/:reference` confirmation; `/staff` sign-in and overview; `*` not found.
- **Data loading:** plain `fetch` in `useEffect` with loading, error and empty states. No client cache library, because each page loads once.
- **Booking form:** Name, Email and Guests (number input, 1 to 8). Each error is shown under its field with `aria-describedby` and `aria-invalid`. The first invalid field receives focus. Server field errors are set with `setError`, so the same display path covers both.
- **Confirmation:** heading "Booking confirmed", then tasting, guests, total and reference. The reference is shown in a monospace style so it can be read out.
- **Staff overview:** one section per tasting. Each booking is a table row with a Cancel button labelled "Cancel booking KB-…" for screen readers. On narrow screens the table scrolls horizontally inside its card.
- **States:** "N seats left" with a warning tone at 3 or fewer seats; "1 seat left"; "Fully booked" badge that disables the book action; "No bookings yet" for an empty group.
- **Look:** cream background, deep wine accents, a serif display face from the system stack (`ui-serif, Georgia`), so no web fonts or external requests. Visible focus rings. Contrast of text and buttons at least 4.5:1. Motion is limited to a short fade that respects `prefers-reduced-motion`.

## Decisions taken without asking

- In-memory storage, not a file. The brief says the app starts with no bookings; a file would keep them across restarts.
- Prices show as euros with two decimals (for example "€25.00"). The brief writes "EUR 25".
- Singular text "1 seat left" instead of "1 seats left".
- Staff sessions expire after 8 hours. There is no sign-out button; a session ends when its time runs out or the server restarts.
- The booking form's Guests field is a number input, not a dropdown, so out-of-range values reach the validation messages as the brief requires.

## Review notes

Fixed after the review:
- Guests accepted `true`, `[2]`, `"0x2"` and `"2e0"` because of coercion. Now only a number or plain digits count (`shared/booking.ts`, tested).
- A double-click on Cancel could send two requests and show a misleading "no longer exists" notice. Cancel is now disabled while a request is pending (tested with two clicks).

Not changed, with reasons:
- Sign-in limit and the `Secure` cookie flag use the client IP as the socket sees it. If the app runs behind a TLS-terminating proxy, add `app.set('trust proxy', 1)` before deploying. Left out because the deployment setup is not known.
- Booking references can be guessed, which reveals only the tasting title and party size. Accepted; no name or email is exposed.
- Malformed JSON returns the parser's message. Harmless; not changed.
- A JSON body that is an array gets its error under `form`, which the browser never sends. Not changed.
