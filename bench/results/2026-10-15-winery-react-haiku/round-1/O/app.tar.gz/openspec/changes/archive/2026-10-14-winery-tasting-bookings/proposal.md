# Proposal

## Why

Weingut Kieselbrunnen takes tasting reservations by phone and email only, so guests cannot see what is still open and staff have no single list of who is coming. An online booking flow with seat limits and a staff view fixes both.

## What Changes

- Add a public start page that lists the upcoming tastings with date, time, price per guest and seats left.
- Add a booking form per tasting (Name, Email, Guests 1–8). Bookings can never exceed the seats left; invalid input is rejected next to the field it concerns.
- Add a booking confirmation page with the booking reference, tasting, guest count and total price.
- Add a staff area at `/staff`, protected by a password from the `STAFF_PASSWORD` environment variable, that lists all bookings grouped by tasting and lets staff cancel a booking, which frees its seats.
- Bookings are kept in memory. The app starts with no bookings and a restart clears them. **Known limit**, see design.md.
- The three tastings from the winery's programme are seeded at start-up.

No existing capabilities exist in this repository, so nothing is modified or removed.

## Capabilities

### New Capabilities

- `tasting-catalog`: the list of tastings with their details and live seat availability, including the fully booked state.
- `guest-booking`: booking a tasting as a guest, validation rules, seat enforcement and the booking confirmation.
- `staff-bookings`: staff sign-in with the shared password, the booking overview grouped by tasting, and cancellation.

### Modified Capabilities

None.

## Impact

- New application: React single-page front end (Vite build), Node.js server (Express) serving the API and the built front end on `PORT` (default 3000).
- New dependencies: React, React Router, React Hook Form, Zod, Tailwind CSS, Express, express-rate-limit, Vitest, Testing Library, Supertest.
- No external services, no database, no network calls from the browser beyond the app's own API.
