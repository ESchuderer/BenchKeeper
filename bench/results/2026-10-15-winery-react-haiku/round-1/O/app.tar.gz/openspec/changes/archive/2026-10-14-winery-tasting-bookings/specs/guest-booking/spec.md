# Spec Delta

## Purpose

Lets guests reserve seats on a wine tasting online and receive a booking reference, while guaranteeing that no tasting is sold beyond its seat capacity.

## ADDED Requirements

### Requirement: Booking form fields
The booking form for a tasting SHALL have the fields "Name", "Email" and "Guests" and a submit button labelled "Book".

#### Scenario: Form shown for a tasting
- **WHEN** a guest opens the booking form for Winter Tasting
- **THEN** the form shows the fields "Name", "Email" and "Guests" and a "Book" button, together with the tasting title, date, time and price per guest

### Requirement: Input validation next to the field
The system SHALL reject a booking whose input is invalid and SHALL show the error message next to the field it concerns. Name SHALL be required, at most 100 characters. Email SHALL be required and a valid email address, at most 254 characters. Guests SHALL be a whole number from 1 to 8.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty Name
- **THEN** the Name field shows an error message, no booking is created and the other entered values are kept

#### Scenario: Invalid email
- **WHEN** a guest submits an Email value without a valid address format
- **THEN** the Email field shows an error message and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits 0 or 9 as Guests
- **THEN** the Guests field shows an error message and no booking is created

#### Scenario: Guests not a whole number
- **WHEN** a guest submits 2.5 or a non-numeric value as Guests
- **THEN** the Guests field shows an error message and no booking is created

### Requirement: Bookings never exceed seats left
A booking SHALL be accepted only if its guests are less than or equal to the seats left at the moment of booking. When two bookings race for the last seats, the system SHALL accept bookings in order until the seats are used up and reject the others.

#### Scenario: More guests than seats left
- **WHEN** a guest books 4 guests for a tasting with 3 seats left
- **THEN** the Guests field shows an error that only 3 seats are left and no booking is created

#### Scenario: Concurrent bookings for the last seats
- **WHEN** two guests each book 2 guests for a tasting with 3 seats left at the same time
- **THEN** exactly one booking is accepted, the other guest sees the seats-left error, and the tasting shows 1 seat left

### Requirement: Booking confirmation
After a booking is accepted, the system SHALL show a confirmation with the heading "Booking confirmed", the tasting title, the number of guests, the total price in euros (guests times price per guest) and a booking reference that is unique among all bookings. The confirmation SHALL be reachable again through its booking reference.

#### Scenario: Successful booking
- **WHEN** a guest books 2 guests for Red Wine Cellar Tour (EUR 32 per guest)
- **THEN** the page shows the heading "Booking confirmed", "Red Wine Cellar Tour", 2 guests, a total of EUR 64.00 and a booking reference

#### Scenario: Reopening a confirmation
- **WHEN** a guest opens the confirmation address that contains a valid booking reference
- **THEN** the same confirmation details are shown

#### Scenario: Unknown booking reference
- **WHEN** a guest opens a confirmation address with a reference that does not exist
- **THEN** the page states that the booking was not found

### Requirement: Booking a fully booked tasting
The system SHALL reject any booking for a tasting with no seats left, and the booking form SHALL say that the tasting is fully booked.

#### Scenario: Form for a fully booked tasting
- **WHEN** a guest submits a booking for a tasting with 0 seats left
- **THEN** the form shows that the tasting is fully booked and no booking is created
