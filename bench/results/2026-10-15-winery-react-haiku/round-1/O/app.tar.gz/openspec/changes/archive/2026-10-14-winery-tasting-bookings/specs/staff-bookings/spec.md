# Spec Delta

## Purpose

Lets winery staff sign in with a shared password to see every tasting booking and cancel bookings, so the winery can run its tastings from one list.

## ADDED Requirements

### Requirement: Staff sign-in with shared password
The page at `/staff` SHALL show a "Password" field and a "Sign in" button until staff are signed in. The password SHALL be checked against the value of the environment variable `STAFF_PASSWORD`. If that variable is not set, no sign-in SHALL succeed.

#### Scenario: Correct password
- **WHEN** staff enter the configured password and activate "Sign in"
- **THEN** the staff overview with all bookings is shown

#### Scenario: Wrong password
- **WHEN** staff enter a wrong password and activate "Sign in"
- **THEN** the page shows an error that the password is wrong and no booking data is shown

#### Scenario: No password configured
- **WHEN** the server runs without `STAFF_PASSWORD` set and staff enter any password
- **THEN** the sign-in is refused

### Requirement: Sign-in attempts are limited
The system SHALL refuse further sign-in attempts from the same client for 15 minutes after 10 failed attempts within that window.

#### Scenario: Too many failed attempts
- **WHEN** a client has 10 failed sign-in attempts within 15 minutes and makes another attempt with the correct password
- **THEN** the sign-in is refused and the page asks the client to try again later

### Requirement: Staff session lifetime
A staff session SHALL end after 8 hours or when the server restarts, after which the sign-in form is shown again. Booking data SHALL NOT be returned to a request without a valid staff session.

#### Scenario: Request without session
- **WHEN** a request for the staff booking list arrives without a valid staff session
- **THEN** the request is refused and no booking data is returned

#### Scenario: Session expired
- **WHEN** a staff session is more than 8 hours old and staff reload `/staff`
- **THEN** the sign-in form is shown again

### Requirement: Bookings grouped by tasting
The staff overview SHALL list all bookings grouped under their tasting, and each booking SHALL show the guest name, email, number of guests and booking reference. A tasting without bookings SHALL show that it has no bookings.

#### Scenario: Overview with bookings
- **WHEN** staff open the overview and Riesling Evening has a booking by "Anna Weber", anna@example.com, 3 guests, reference KB-7F3K2Q
- **THEN** under Riesling Evening the row shows "Anna Weber", "anna@example.com", "3" and "KB-7F3K2Q"

#### Scenario: Tasting without bookings
- **WHEN** staff open the overview and Winter Tasting has no bookings
- **THEN** the Winter Tasting group states that there are no bookings yet

### Requirement: Cancel a booking
Staff SHALL be able to cancel any booking with a "Cancel" button. A cancelled booking SHALL be removed and its seats SHALL become free immediately for new bookings.

#### Scenario: Cancelling frees seats
- **WHEN** staff cancel a booking of 3 guests for Winter Tasting, which had 0 seats left
- **THEN** the booking disappears from the overview and Winter Tasting shows "3 seats left" on the start page

#### Scenario: Cancelling an unknown booking
- **WHEN** staff try to cancel a booking that no longer exists, for example after it was cancelled in another browser
- **THEN** the page shows that the booking no longer exists and the overview is refreshed
