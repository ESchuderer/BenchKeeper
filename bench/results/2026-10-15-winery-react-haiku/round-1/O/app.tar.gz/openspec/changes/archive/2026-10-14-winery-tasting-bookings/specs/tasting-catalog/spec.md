# Spec Delta

## Purpose

Lets guests see which wine tastings Weingut Kieselbrunnen offers, when they take place, what they cost and how many seats are still free.

## ADDED Requirements

### Requirement: Start page lists all tastings
The start page SHALL list every offered tasting with its title, date and time, price per guest and seats left, in order of date and time.

#### Scenario: Three tastings are listed
- **WHEN** a guest opens the start page
- **THEN** the page shows "Riesling Evening" (2026-11-06 18:00, EUR 25 per guest), "Red Wine Cellar Tour" (2026-11-14 15:00, EUR 32 per guest) and "Winter Tasting" (2026-12-05 17:00, EUR 28 per guest), in that order

### Requirement: Seats left are shown per tasting
Each tasting SHALL show its seats left as "<n> seats left", where n is the tasting's seat capacity minus the guests of all active bookings. When exactly one seat is left the text SHALL read "1 seat left".

#### Scenario: Seats left after bookings
- **WHEN** Riesling Evening has 12 seats and bookings for 5 guests exist
- **THEN** the tasting shows "7 seats left"

#### Scenario: One seat left
- **WHEN** Winter Tasting has exactly one seat left
- **THEN** the tasting shows "1 seat left"

### Requirement: Fully booked tastings are marked and cannot be booked
A tasting with no seats left SHALL be marked as "Fully booked" in place of a seats count, and its booking action SHALL NOT lead to a booking form that accepts guests.

#### Scenario: Last seat is taken
- **WHEN** the last free seat of Red Wine Cellar Tour is booked
- **THEN** its card shows "Fully booked" and offers no "Book Red Wine Cellar Tour" action that accepts a booking

### Requirement: Each tasting links to its booking form
Each tasting SHALL have a button or link labelled "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open booking form from the start page
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens

#### Scenario: Unknown tasting address
- **WHEN** a guest opens the address of a tasting that does not exist
- **THEN** the page states that the tasting was not found and links back to the start page
