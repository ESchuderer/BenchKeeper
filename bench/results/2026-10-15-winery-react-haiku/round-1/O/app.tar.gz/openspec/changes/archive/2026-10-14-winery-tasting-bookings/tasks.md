# Tasks

Test-first: for each group, write the failing tests named in the first task, then implement until they pass.

## 1. Project setup

- [x] 1.1 Add `package.json` (type module, scripts `build`, `start`, `test`, `typecheck`), `tsconfig.json` (client, shared, tests), `tsconfig.server.json` (server and shared, emits `dist-server/`), `vite.config.ts` and `index.html`. Verify: `npm install` succeeds and `npm run typecheck` runs with no source files yet.
- [x] 1.2 Add Vitest config with the jsdom environment for `src/**` tests and node for the rest. Verify: `npm test` runs and reports no test files.

## 2. Shared booking rules

- [x] 2.1 Write `shared/booking.test.ts` covering name (required, trimmed, max 100), email (required, valid, max 254) and guests (whole number 1 to 8, empty and non-numeric rejected) with the messages from the spec. Verify: tests fail.
- [x] 2.2 Implement `shared/booking.ts` with the Zod schema and the `BookingInput` type until 2.1 passes. Verify: `npm test -- shared` passes.

## 3. Tasting catalogue and seat store

- [x] 3.1 Write `server/store.test.ts`: seats left is seats minus guests; a booking over the seats left is rejected with the seats left count; a booking for 0 seats left is rejected as fully booked; cancel frees seats; references are unique over 1000 bookings and match `KB-` plus six allowed characters; unknown tasting and unknown reference return not found. Verify: tests fail.
- [x] 3.2 Implement `server/tastings.ts` (the three seeded tastings) and `server/store.ts` (in-memory store, synchronous check-and-insert) until 3.1 passes. Verify: `npm test -- server/store` passes.
- [x] 3.3 Add a store test that 50 concurrent `createBooking` calls for a tasting with 3 seats accept exactly 3 bookings. Verify: passes, because the check and insert share one synchronous call.

## 4. HTTP API

- [x] 4.1 Write `server/api.test.ts` (Supertest) for the guest endpoints: list with `seatsLeft` in date order; single tasting and 404; booking 201 with total in cents; 400 with `errors` per field; 409 for too many guests with the seats-left message; 409 `message` for a fully booked tasting; confirmation by reference without email; unknown reference 404; JSON 404 for unknown `/api` paths. Verify: tests fail.
- [x] 4.2 Implement `server/app.ts` (`createApp({ staffPassword, now })`) with the guest routes, body parsing, the shared-schema validation and the JSON error handler until 4.1 passes. Verify: `npm test -- server/api` passes for guest routes.
- [x] 4.3 Add to `server/api.test.ts` the staff tests: no `STAFF_PASSWORD` refuses every sign-in; wrong password 401 with no data; correct password 204 with an `HttpOnly`, `SameSite=Strict` cookie; bookings list and cancel refused without a session; the list groups bookings by tasting; cancel returns 204 and frees the seats in `GET /api/tastings`; cancel of an unknown reference returns 404; a session older than 8 hours is refused (using the `now` option); 10 failed sign-ins then the correct password gets 429. Verify: tests fail.
- [x] 4.4 Implement the staff routes in `server/staff.ts` (password digest comparison, in-memory sessions with expiry, cookie) and wire `express-rate-limit` to failed sign-ins only, until 4.3 passes. Verify: `npm test -- server/api` passes entirely.
- [x] 4.5 Implement `server/index.ts`: read `PORT` (default 3000) and `STAFF_PASSWORD`, warn at start-up when the password is unset, serve `dist/` with an SPA fallback for non-API GET requests. Verify: `npm run build && PORT=3100 npm start` serves `/` and `/api/tastings` with curl.

## 5. Front end foundation

- [x] 5.1 Write `src/api.test.ts` for the typed fetch wrapper: JSON parse, error body passed through, 401 returned as a value the page can handle. Verify: tests fail.
- [x] 5.2 Implement `src/api.ts` and `src/format.ts` (euro price, date and time text) until 5.1 passes. Verify: `npm test -- src/api src/format` passes.
- [x] 5.3 Add `src/index.css` with the Tailwind import and `@theme` tokens (wine, cream, ink, success and error tones, serif display stack, focus ring), `src/main.tsx`, `src/App.tsx` routes and `src/components/Layout.tsx` (header wordmark "Weingut Kieselbrunnen", navigation, footer). Verify: `npm run build` produces `dist/index.html` with the CSS.

## 6. Guest pages

- [x] 6.1 Write `src/pages/TastingsPage.test.tsx`: three cards with title, date and time, price and "N seats left" (singular for 1); a fully booked card shows "Fully booked" and no enabled "Book <title>" button; "Book Riesling Evening" links to its booking form. Verify: tests fail.
- [x] 6.2 Implement `src/pages/TastingsPage.tsx` until 6.1 passes. Verify: `npm test -- TastingsPage` passes.
- [x] 6.3 Write `src/pages/BookingPage.test.tsx`: heading and fields Name, Email, Guests and "Book"; submitting empty shows each error next to its field and does not call the API; a server 400 error shows under the matching field; a server 409 seats message shows under Guests; a fully booked tasting shows the form-level message; success navigates to `/bookings/<reference>`. Verify: tests fail.
- [x] 6.4 Implement `src/pages/BookingPage.tsx` with React Hook Form and the shared schema until 6.3 passes. Verify: `npm test -- BookingPage` passes.
- [x] 6.5 Write and implement `src/pages/ConfirmationPage.tsx` with its test: heading "Booking confirmed", tasting, guests, total in euros and reference; unknown reference shows the not-found message. Verify: `npm test -- ConfirmationPage` passes.

## 7. Staff page

- [x] 7.1 Write `src/pages/StaffPage.test.tsx`: sign-in form with "Password" and "Sign in" when no session; wrong password shows an error and no bookings; correct password shows bookings grouped by tasting with name, email, guests and reference; "Cancel" removes the row; an empty tasting says "No bookings yet"; a 401 after the session expires returns to the sign-in form. Verify: tests fail.
- [x] 7.2 Implement `src/pages/StaffPage.tsx` and the not-found page until 7.1 passes. Verify: `npm test -- StaffPage` passes.

## 8. Look, accessibility and responsive check

- [x] 8.1 Style all pages against the design: cards with clear states (warning at 3 or fewer seats, fully booked badge, error and success banners), visible focus rings, `prefers-reduced-motion` respected. Verify: `npm run build` succeeds and screenshots at 375px and 1280px width look right (see 9.2).
- [x] 8.2 Check keyboard use: every action reachable with Tab, errors announced (`role="alert"`), inputs labelled, first invalid field focused on submit. Verify: covered by the Testing Library tests in 6.3 and 7.1 plus a manual review of the markup.

## 9. Verification

- [x] 9.1 Run the full suite: `npm run typecheck`, `npm test`, `npm run build`, then start with `npm start` on a free port and walk the guest flow and staff flow against the running server with curl. Verify: all green, output recorded in the final report.
- [x] 9.2 Check the running app in a real browser at 375px and 1280px width if a browser can be launched in this container; otherwise state that it was not checked. Verify: screenshots reviewed, or the limitation stated.

## 10. Review

- [x] 10.1 Run a ponytail-review of the change and a security review of the server routes. Fix findings that are real; record the rest with reasons. Verify: findings list in the change notes and tests still green.

## Workflow follow-up

- Archive the change with `/openspec-archive-change` once all tracked tasks are done, so its delta specs sync into `openspec/specs/`.
