import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from './app.js';

const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

describe('guest API', () => {
  it('lists tastings in date order with seats left', async () => {
    const res = await request(createApp()).get('/api/tastings');
    expect(res.status).toBe(200);
    expect(res.body.map((t: { id: string }) => t.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(res.body[0]).toMatchObject({
      title: 'Riesling Evening',
      date: '2026-11-06',
      time: '18:00',
      priceCents: 2500,
      seats: 12,
      seatsLeft: 12,
    });
  });

  it('returns one tasting and 404 for an unknown id', async () => {
    const app = createApp();
    expect((await request(app).get('/api/tastings/winter-tasting')).body).toMatchObject({ title: 'Winter Tasting' });
    expect((await request(app).get('/api/tastings/nope')).status).toBe(404);
  });

  it('creates a booking and returns the reference with the total in cents', async () => {
    const app = createApp();
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send(guest);
    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(/^KB-[A-Z2-9]{6}$/),
      tastingId: 'red-wine-cellar-tour',
      tastingTitle: 'Red Wine Cellar Tour',
      guests: 2,
      totalCents: 6400,
    });
    const after = await request(app).get('/api/tastings/red-wine-cellar-tour');
    expect(after.body.seatsLeft).toBe(6);
  });

  it('rejects invalid input with one error per field and creates nothing', async () => {
    const app = createApp();
    const res = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ name: '', email: 'nope', guests: 9 });
    expect(res.status).toBe(400);
    expect(res.body.errors).toEqual({
      name: 'Please enter your name.',
      email: 'Please enter a valid email address.',
      guests: 'You can book for at most 8 guests.',
    });
    expect((await request(app).get('/api/tastings/winter-tasting')).body.seatsLeft).toBe(10);
  });

  it('treats a request without a body as invalid input', async () => {
    const res = await request(createApp()).post('/api/tastings/winter-tasting/bookings');
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it('refuses more guests than seats left and says how many are left', async () => {
    const app = createApp();
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 8 });
    const res = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 3 });
    expect(res.status).toBe(409);
    expect(res.body.errors).toEqual({ guests: 'Only 2 seats are left.' });
  });

  it('uses the singular for one seat left', async () => {
    const app = createApp();
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 8 });
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 1 });
    const res = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 2 });
    expect(res.body.errors).toEqual({ guests: 'Only 1 seat is left.' });
  });

  it('refuses bookings for a fully booked tasting with a form message', async () => {
    const app = createApp();
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 8 });
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 2 });
    const res = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 1 });
    expect(res.status).toBe(409);
    expect(res.body).toEqual({ message: 'This tasting is fully booked.' });
  });

  it('returns 404 when booking an unknown tasting', async () => {
    const res = await request(createApp()).post('/api/tastings/nope/bookings').send(guest);
    expect(res.status).toBe(404);
  });

  it('returns confirmation details by reference without the email address', async () => {
    const app = createApp();
    const created = await request(app).post('/api/tastings/riesling-evening/bookings').send(guest);
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual(created.body);
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
    expect((await request(app).get('/api/bookings/KB-NOPE00')).status).toBe(404);
  });

  it('answers unknown API paths with JSON 404', async () => {
    const res = await request(createApp()).get('/api/unknown');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
});

describe('staff API', () => {
  const password = 'correct horse battery';

  // Returns the cookie header value for a signed-in staff session.
  async function signIn(app: ReturnType<typeof createApp>) {
    const res = await request(app).post('/api/staff/session').send({ password });
    return res.headers['set-cookie'][0].split(';')[0];
  }

  it('refuses every sign-in when no staff password is configured', async () => {
    const app = createApp();
    for (const attempt of ['', 'anything']) {
      const res = await request(app).post('/api/staff/session').send({ password: attempt });
      expect(res.status).toBe(401);
      expect(res.headers['set-cookie']).toBeUndefined();
    }
  });

  it('refuses a wrong password without returning any booking data', async () => {
    const app = createApp({ staffPassword: password });
    const res = await request(app).post('/api/staff/session').send({ password: 'wrong' });
    expect(res.status).toBe(401);
    expect(res.body.message).toBe('The password is wrong.');
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('issues an HttpOnly, SameSite=Strict session cookie for the right password', async () => {
    const res = await request(createApp({ staffPassword: password })).post('/api/staff/session').send({ password });
    expect(res.status).toBe(204);
    expect(res.headers['set-cookie'][0]).toMatch(/^staff_session=[A-Za-z0-9_-]{43};/);
    expect(res.headers['set-cookie'][0]).toMatch(/HttpOnly/);
    expect(res.headers['set-cookie'][0]).toMatch(/SameSite=Strict/i);
  });

  it('keeps the booking list behind the session', async () => {
    const app = createApp({ staffPassword: password });
    expect((await request(app).get('/api/staff/bookings')).status).toBe(401);
    expect((await request(app).get('/api/staff/bookings').set('Cookie', 'staff_session=forged')).status).toBe(401);
  });

  it('lists bookings grouped by tasting for a signed-in member of staff', async () => {
    const app = createApp({ staffPassword: password });
    await request(app).post('/api/tastings/riesling-evening/bookings').send({
      name: 'Anna Weber',
      email: 'anna@example.com',
      guests: 3,
    });
    const res = await request(app).get('/api/staff/bookings').set('Cookie', await signIn(app));
    expect(res.status).toBe(200);
    expect(res.body.map((g: { id: string }) => g.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(res.body[0].bookings).toEqual([
      expect.objectContaining({ name: 'Anna Weber', email: 'anna@example.com', guests: 3, reference: expect.any(String) }),
    ]);
    expect(res.body[1].bookings).toEqual([]);
  });

  it('cancels a booking, frees its seats and refuses cancellation without a session', async () => {
    const app = createApp({ staffPassword: password });
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send({
      name: 'Anna Weber',
      email: 'anna@example.com',
      guests: 4,
    });
    const url = `/api/staff/bookings/${created.body.reference}`;
    expect((await request(app).delete(url)).status).toBe(401);

    const cookie = await signIn(app);
    expect((await request(app).delete(url).set('Cookie', cookie)).status).toBe(204);
    expect((await request(app).get('/api/tastings/winter-tasting')).body.seatsLeft).toBe(10);
    expect((await request(app).delete(url).set('Cookie', cookie)).status).toBe(404);
  });

  it('ends a session after 8 hours', async () => {
    let clock = 1_000_000;
    const app = createApp({ staffPassword: password, now: () => clock });
    const cookie = await signIn(app);
    clock += 8 * 60 * 60 * 1000 - 1;
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(200);
    clock += 1;
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });

  it('locks sign-in for a client after 10 failed attempts, even with the right password', async () => {
    const app = createApp({ staffPassword: password });
    for (let i = 0; i < 10; i++) {
      expect((await request(app).post('/api/staff/session').send({ password: 'wrong' })).status).toBe(401);
    }
    const res = await request(app).post('/api/staff/session').send({ password });
    expect(res.status).toBe(429);
    expect(res.body.message).toMatch(/try again later/i);
  });
});
