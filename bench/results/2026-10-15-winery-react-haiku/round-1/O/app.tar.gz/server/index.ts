import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled until it is.');
}

// Compiled to dist-server/server/index.js, so dist/ is two levels up.
const clientDir = fileURLToPath(new URL('../../dist', import.meta.url));

createApp({ staffPassword, clientDir }).listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on port ${port}`);
});
