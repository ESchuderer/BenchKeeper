import { describe, expect, it } from 'vitest';
import { createStore, type BookingResult } from './store.js';

const definitions = [
  { id: 'late', title: 'Late', date: '2026-12-05', time: '17:00', priceCents: 2800, seats: 3 },
  { id: 'early', title: 'Early', date: '2026-11-06', time: '18:00', priceCents: 2500, seats: 12 },
];
const guest = { name: 'Anna Weber', email: 'anna@example.com' };

function bookedOk(result: BookingResult) {
  if (!result.ok) throw new Error(`expected a booking, got ${result.reason}`);
  return result.booking;
}

describe('store', () => {
  it('lists tastings in date and time order with seats left', () => {
    const store = createStore(definitions);
    expect(store.listTastings().map((t) => [t.id, t.seatsLeft])).toEqual([
      ['early', 12],
      ['late', 3],
    ]);
  });

  it('subtracts the guests of every booking from the seats left', () => {
    const store = createStore(definitions);
    bookedOk(store.createBooking('early', { ...guest, guests: 5 }));
    bookedOk(store.createBooking('early', { ...guest, guests: 2 }));
    expect(store.getTasting('early')?.seatsLeft).toBe(5);
  });

  it('rejects more guests than seats left and reports the seats left', () => {
    const store = createStore(definitions);
    bookedOk(store.createBooking('late', { ...guest, guests: 2 }));
    expect(store.createBooking('late', { ...guest, guests: 2 })).toEqual({
      ok: false,
      reason: 'not_enough_seats',
      seatsLeft: 1,
    });
    expect(store.getTasting('late')?.seatsLeft).toBe(1);
  });

  it('rejects any booking for a fully booked tasting', () => {
    const store = createStore(definitions);
    bookedOk(store.createBooking('late', { ...guest, guests: 3 }));
    expect(store.createBooking('late', { ...guest, guests: 1 })).toEqual({ ok: false, reason: 'fully_booked' });
  });

  it('frees the seats of a cancelled booking', () => {
    const store = createStore(definitions);
    const booking = bookedOk(store.createBooking('late', { ...guest, guests: 3 }));
    expect(store.cancelBooking(booking.reference)).toBe(true);
    expect(store.getTasting('late')?.seatsLeft).toBe(3);
    expect(store.cancelBooking(booking.reference)).toBe(false);
  });

  it('returns not_found for an unknown tasting and for an unknown reference', () => {
    const store = createStore(definitions);
    expect(store.createBooking('nope', { ...guest, guests: 1 })).toEqual({ ok: false, reason: 'not_found' });
    expect(store.getBooking('KB-NOPE00')).toBeUndefined();
    expect(store.getTasting('nope')).toBeUndefined();
  });

  it('gives every booking a unique KB- reference from an unambiguous alphabet', () => {
    const store = createStore([{ id: 'big', title: 'Big', date: '2026-11-06', time: '18:00', priceCents: 1, seats: 1000 }]);
    const references = Array.from({ length: 1000 }, () =>
      bookedOk(store.createBooking('big', { ...guest, guests: 1 })).reference,
    );
    expect(new Set(references).size).toBe(1000);
    for (const reference of references) {
      expect(reference).toMatch(/^KB-[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{6}$/);
    }
  });

  it('groups bookings by tasting for the staff overview', () => {
    const store = createStore(definitions);
    bookedOk(store.createBooking('early', { ...guest, guests: 2 }));
    const groups = store.listBookingsByTasting();
    expect(groups.map((g) => [g.tasting.id, g.bookings.length])).toEqual([
      ['early', 1],
      ['late', 0],
    ]);
    expect(groups[0].bookings[0]).toMatchObject({ name: 'Anna Weber', email: 'anna@example.com', guests: 2 });
  });
});

describe('store under concurrent requests', () => {
  it('accepts exactly as many bookings as there are seats', async () => {
    const store = createStore(definitions);
    const attempts = Array.from({ length: 50 }, () =>
      Promise.resolve().then(() => store.createBooking('late', { ...guest, guests: 1 })),
    );
    const results = await Promise.all(attempts);
    expect(results.filter((r) => r.ok)).toHaveLength(3);
    expect(store.getTasting('late')?.seatsLeft).toBe(0);
  });
});
