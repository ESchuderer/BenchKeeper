import { randomInt } from 'node:crypto';
import { tastings as seedTastings, type TastingDefinition } from './tastings.js';

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export interface TastingView extends TastingDefinition {
  seatsLeft: number;
}

export type BookingResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: 'not_found' }
  | { ok: false; reason: 'fully_booked' }
  | { ok: false; reason: 'not_enough_seats'; seatsLeft: number };

// No 0/O or 1/I, so references read out loud without confusion.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// In memory and single-process: the check and the insert in createBooking run
// without an await in between, so two requests cannot take the same last seat.
// shortcut: bookings are lost on restart and this does not work across several processes, upgrade to a file or SQLite store behind this same interface if that is needed.
export function createStore(definitions: TastingDefinition[] = seedTastings) {
  const tastingsById = new Map(definitions.map((t) => [t.id, t]));
  const bookingsByTasting = new Map<string, Booking[]>(definitions.map((t) => [t.id, []]));
  const bookingsByReference = new Map<string, Booking>();

  function seatsLeft(tastingId: string): number {
    const tasting = tastingsById.get(tastingId);
    if (!tasting) return 0;
    const booked = (bookingsByTasting.get(tastingId) ?? []).reduce((sum, b) => sum + b.guests, 0);
    return tasting.seats - booked;
  }

  function view(tasting: TastingDefinition): TastingView {
    return { ...tasting, seatsLeft: seatsLeft(tasting.id) };
  }

  function newReference(): string {
    let reference: string;
    do {
      const chars = Array.from({ length: 6 }, () => REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)]);
      reference = `KB-${chars.join('')}`;
    } while (bookingsByReference.has(reference));
    return reference;
  }

  function listTastings(): TastingView[] {
    return [...tastingsById.values()]
      .sort((a, b) => `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`))
      .map(view);
  }

  return {
    listTastings,

    getTasting(id: string): TastingView | undefined {
      const tasting = tastingsById.get(id);
      return tasting && view(tasting);
    },

    createBooking(tastingId: string, input: { name: string; email: string; guests: number }): BookingResult {
      const tasting = tastingsById.get(tastingId);
      if (!tasting) return { ok: false, reason: 'not_found' };

      const left = seatsLeft(tastingId);
      if (left === 0) return { ok: false, reason: 'fully_booked' };
      if (input.guests > left) return { ok: false, reason: 'not_enough_seats', seatsLeft: left };

      const booking: Booking = { reference: newReference(), tastingId, ...input };
      bookingsByTasting.get(tastingId)?.push(booking);
      bookingsByReference.set(booking.reference, booking);
      return { ok: true, booking };
    },

    getBooking(reference: string): Booking | undefined {
      return bookingsByReference.get(reference);
    },

    listBookingsByTasting(): { tasting: TastingView; bookings: Booking[] }[] {
      return listTastings().map((tasting) => ({
        tasting,
        bookings: bookingsByTasting.get(tasting.id) ?? [],
      }));
    },

    cancelBooking(reference: string): boolean {
      const booking = bookingsByReference.get(reference);
      if (!booking) return false;
      bookingsByReference.delete(reference);
      const list = bookingsByTasting.get(booking.tastingId) ?? [];
      bookingsByTasting.set(
        booking.tastingId,
        list.filter((b) => b !== booking),
      );
      return true;
    },
  };
}
