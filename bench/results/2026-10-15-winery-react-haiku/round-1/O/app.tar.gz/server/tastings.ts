export interface TastingDefinition {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD, winery local time
  time: string; // HH:mm, winery local time
  priceCents: number;
  seats: number;
}

export const tastings: TastingDefinition[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', priceCents: 2500, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', date: '2026-11-14', time: '15:00', priceCents: 3200, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', date: '2026-12-05', time: '17:00', priceCents: 2800, seats: 10 },
];
