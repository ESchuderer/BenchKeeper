import { describe, expect, it } from 'vitest';
import { bookingSchema } from './booking.js';

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

// Returns the first message per field, or {} when the input is valid.
function errorsFor(input: unknown): Record<string, string> {
  const result = bookingSchema.safeParse(input);
  if (result.success) return {};
  return Object.fromEntries(result.error.issues.map((issue) => [String(issue.path[0]), issue.message]));
}

describe('bookingSchema', () => {
  it('accepts a complete booking', () => {
    expect(errorsFor(valid)).toEqual({});
  });

  it('trims the name and requires it', () => {
    expect(errorsFor({ ...valid, name: '   ' })).toEqual({ name: 'Please enter your name.' });
    expect(bookingSchema.parse({ ...valid, name: '  Anna  ' }).name).toBe('Anna');
  });

  it('limits the name to 100 characters', () => {
    expect(errorsFor({ ...valid, name: 'a'.repeat(101) })).toEqual({ name: 'Name must be at most 100 characters.' });
    expect(errorsFor({ ...valid, name: 'a'.repeat(100) })).toEqual({});
  });

  it('requires a valid email address', () => {
    expect(errorsFor({ ...valid, email: '' })).toEqual({ email: 'Please enter your email address.' });
    expect(errorsFor({ ...valid, email: 'anna@' })).toEqual({ email: 'Please enter a valid email address.' });
    expect(errorsFor({ ...valid, email: 'not an email' })).toEqual({ email: 'Please enter a valid email address.' });
  });

  it('limits the email to 254 characters', () => {
    expect(errorsFor({ ...valid, email: `${'a'.repeat(250)}@example.com` })).toEqual({
      email: 'Email must be at most 254 characters.',
    });
    expect(errorsFor({ ...valid, email: `${'a'.repeat(190)}@example.com` })).toEqual({});
  });

  it('accepts guests from 1 to 8, given as numbers or numeric text', () => {
    expect(errorsFor({ ...valid, guests: 1 })).toEqual({});
    expect(errorsFor({ ...valid, guests: 8 })).toEqual({});
    expect(errorsFor({ ...valid, guests: '3' })).toEqual({});
    expect(bookingSchema.parse({ ...valid, guests: '3' }).guests).toBe(3);
  });

  it('rejects guests outside 1 to 8', () => {
    expect(errorsFor({ ...valid, guests: 0 })).toEqual({ guests: 'At least 1 guest is required.' });
    expect(errorsFor({ ...valid, guests: 9 })).toEqual({ guests: 'You can book for at most 8 guests.' });
  });

  it('rejects guests that are not whole numbers', () => {
    expect(errorsFor({ ...valid, guests: 2.5 })).toEqual({ guests: 'Guests must be a whole number.' });
  });

  it('rejects guests that are not numeric', () => {
    expect(errorsFor({ ...valid, guests: 'two' })).toEqual({ guests: 'Please enter the number of guests.' });
  });

  it('rejects booleans, arrays, hex and exponent text as guests', () => {
    for (const guests of [true, [2], '0x2', '2e0', NaN]) {
      expect(errorsFor({ ...valid, guests })).toEqual({ guests: 'Please enter the number of guests.' });
    }
  });

  it('reports every invalid field at once', () => {
    expect(Object.keys(errorsFor({ name: '', email: '', guests: 0 })).sort()).toEqual(['email', 'guests', 'name']);
  });
});
