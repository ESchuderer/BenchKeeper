import { z } from 'zod';

// Shared by the guest form and the API, so both enforce the same rules.
export const bookingSchema = z.object({
  name: z
    .string({ error: 'Please enter your name.' })
    .trim()
    .min(1, 'Please enter your name.')
    .max(100, 'Name must be at most 100 characters.'),
  email: z
    .string({ error: 'Please enter your email address.' })
    .trim()
    .min(1, 'Please enter your email address.')
    .max(254, 'Email must be at most 254 characters.')
    .pipe(z.email({ error: 'Please enter a valid email address.' })),
  // Only a number or plain digits count as a number; true, [2] or "0x2" do not.
  guests: z.preprocess(
    (value) => (typeof value === 'number' || (typeof value === 'string' && /^\s*\d+\s*$/.test(value)) ? Number(value) : value),
    z
      .number({ error: 'Please enter the number of guests.' })
      .int('Guests must be a whole number.')
      .min(1, 'At least 1 guest is required.')
      .max(8, 'You can book for at most 8 guests.'),
  ),
});

export type BookingInput = z.infer<typeof bookingSchema>;
