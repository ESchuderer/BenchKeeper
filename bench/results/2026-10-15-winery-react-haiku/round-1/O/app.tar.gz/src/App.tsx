import { Route, Routes } from 'react-router';
import { Layout } from './components/Layout';
import { BookingPage } from './pages/BookingPage';
import { ConfirmationPage } from './pages/ConfirmationPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { StaffPage } from './pages/StaffPage';
import { TastingsPage } from './pages/TastingsPage';

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingsPage />} />
        <Route path="tastings/:id/book" element={<BookingPage />} />
        <Route path="bookings/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
