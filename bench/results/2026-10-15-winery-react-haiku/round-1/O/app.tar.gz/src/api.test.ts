import { afterEach, describe, expect, it, vi } from 'vitest';
import { ApiError, cancelBooking, listTastings, staffBookings, staffSignIn } from './api';

function jsonResponse(status: number, body?: unknown) {
  return new Response(body === undefined ? null : JSON.stringify(body), {
    status,
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
  });
}

describe('api client', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('returns the parsed JSON of a successful request', async () => {
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse(200, [{ id: 'winter-tasting' }]));
    vi.stubGlobal('fetch', fetchMock);
    await expect(listTastings()).resolves.toEqual([{ id: 'winter-tasting' }]);
    expect(fetchMock).toHaveBeenCalledWith('/api/tastings', expect.anything());
  });

  it('returns nothing for a 204 response', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(jsonResponse(204)));
    await expect(cancelBooking('KB-ABC234')).resolves.toBeUndefined();
  });

  it('throws an ApiError carrying the status and the server field errors', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(jsonResponse(400, { errors: { email: 'Bad email.' } })));
    const error = await staffSignIn('x').catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ status: 400, body: { errors: { email: 'Bad email.' } } });
  });

  it('gives a 401 as an ApiError with status 401 so the page can show the sign-in form', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(jsonResponse(401, { message: 'Please sign in.' })));
    const error = await staffBookings().catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect((error as ApiError).status).toBe(401);
    expect((error as ApiError).message).toBe('Please sign in.');
  });

  it('survives a non-JSON error body', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('<html>', { status: 502 })));
    const error = await listTastings().catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect((error as ApiError).status).toBe(502);
  });
});
