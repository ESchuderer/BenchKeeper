// Typed client for the server API. Non-2xx responses throw ApiError.

export interface Tasting {
  id: string;
  title: string;
  date: string;
  time: string;
  priceCents: number;
  seats: number;
  seatsLeft: number;
}

export interface Confirmation {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  guests: number;
  totalCents: number;
}

export interface StaffBooking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTasting extends Tasting {
  bookings: StaffBooking[];
}

export interface ErrorBody {
  message?: string;
  errors?: Record<string, string>;
}

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly body: ErrorBody,
  ) {
    super(body.message ?? `Request failed with status ${status}.`);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: { Accept: 'application/json', ...(init?.body ? { 'Content-Type': 'application/json' } : {}) },
  });
  if (response.status === 204) return undefined as T;
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(response.status, body);
  return body as T;
}

const post = (body: unknown): RequestInit => ({ method: 'POST', body: JSON.stringify(body) });

export const listTastings = () => request<Tasting[]>('/api/tastings');

export const getTasting = (id: string) => request<Tasting>(`/api/tastings/${encodeURIComponent(id)}`);

export const createBooking = (tastingId: string, input: { name: string; email: string; guests: number }) =>
  request<Confirmation>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, post(input));

export const getBooking = (reference: string) =>
  request<Confirmation>(`/api/bookings/${encodeURIComponent(reference)}`);

export const staffSignIn = (password: string) => request<void>('/api/staff/session', post({ password }));

export const staffBookings = () => request<StaffTasting[]>('/api/staff/bookings');

export const cancelBooking = (reference: string) =>
  request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' });
