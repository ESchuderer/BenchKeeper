import { Link, Outlet } from 'react-router';

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-10 focus:rounded-md focus:bg-parchment focus:px-4 focus:py-2 focus:text-wine-900"
      >
        Skip to content
      </a>
      <header className="bg-wine-900 text-cream">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-4 sm:py-5">
          <Link to="/" className="font-display text-xl tracking-wide sm:text-2xl">
            Weingut Kieselbrunnen
          </Link>
          <nav aria-label="Main">
            <Link to="/" className="rounded-md px-3 py-2 text-sm hover:bg-wine-800">
              Tastings
            </Link>
          </nav>
        </div>
      </header>

      <main id="main" className="fade-in mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:py-12">
        <Outlet />
      </main>

      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-5xl flex-col gap-2 px-4 py-6 text-sm text-muted sm:flex-row sm:justify-between">
          <p>Family winery · Tastings by reservation</p>
          <Link to="/staff" className="underline underline-offset-4 hover:text-wine-800">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}
