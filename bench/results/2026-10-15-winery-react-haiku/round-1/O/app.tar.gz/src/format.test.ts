import { describe, expect, it } from 'vitest';
import { formatDateTime, formatPrice, seatsLabel } from './format';

describe('format', () => {
  it('formats cents as euros with two decimals', () => {
    expect(formatPrice(2500)).toBe('€25.00');
    expect(formatPrice(6400)).toBe('€64.00');
  });

  it('formats the date with weekday and the time as written', () => {
    expect(formatDateTime('2026-11-06', '18:00')).toBe('Friday, 6 November 2026 · 18:00');
  });

  it('names the seats left, using the singular for one', () => {
    expect(seatsLabel(12)).toBe('12 seats left');
    expect(seatsLabel(1)).toBe('1 seat left');
    expect(seatsLabel(0)).toBe('Fully booked');
  });
});
