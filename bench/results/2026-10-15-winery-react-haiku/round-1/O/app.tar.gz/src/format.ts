const euros = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'EUR' });

export function formatPrice(cents: number): string {
  return euros.format(cents / 100);
}

// The winery's wall-clock date and time are shown as written, so the date is formatted in UTC.
export function formatDateTime(date: string, time: string): string {
  const day = new Date(`${date}T00:00:00Z`).toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  });
  return `${day} · ${time}`;
}

export function seatsLabel(seatsLeft: number): string {
  if (seatsLeft === 0) return 'Fully booked';
  return seatsLeft === 1 ? '1 seat left' : `${seatsLeft} seats left`;
}
