import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes } from 'react-router';
import { BookingPage } from './BookingPage';
import type { Tasting } from '../api';

const winter: Tasting = {
  id: 'winter-tasting',
  title: 'Winter Tasting',
  date: '2026-12-05',
  time: '17:00',
  priceCents: 2800,
  seats: 10,
  seatsLeft: 10,
};

function json(status: number, body?: unknown) {
  return new Response(body === undefined ? null : JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

// Answers the page's requests; `book` decides the response to the booking POST.
function mockApi({ tasting = winter, book }: { tasting?: Tasting | 'missing'; book?: () => Response | Promise<Response> }) {
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    if (url === `/api/tastings/${winter.id}` && (!init || !init.method)) {
      return tasting === 'missing' ? json(404, { message: 'Tasting not found.' }) : json(200, tasting);
    }
    if (url === `/api/tastings/${winter.id}/bookings` && init?.method === 'POST') {
      return book ? book() : json(201, { reference: 'KB-ABC234' });
    }
    return json(500, { message: `unexpected ${url}` });
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

const bookingPosts = (fetchMock: ReturnType<typeof mockApi>) =>
  fetchMock.mock.calls.filter(([, init]) => init?.method === 'POST');

// The message is shown next to the field the input describes.
function errorFor(label: string): string | null {
  const input = screen.getByLabelText(label);
  if (input.getAttribute('aria-invalid') !== 'true') return null;
  const describedBy = input.getAttribute('aria-describedby') ?? '';
  return describedBy
    .split(' ')
    .map((id) => document.getElementById(id)?.textContent ?? '')
    .join(' ')
    .trim();
}

function renderAt(path = `/tastings/${winter.id}/book`) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/tastings/:id/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<h1>Reached the confirmation</h1>} />
        <Route path="/" element={<h1>Start page</h1>} />
      </Routes>
    </MemoryRouter>,
  );
}

describe('BookingPage', () => {
  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it('shows the tasting and the Name, Email and Guests fields with a Book button', async () => {
    mockApi({});
    renderAt();

    expect(await screen.findByRole('heading', { name: 'Winter Tasting' })).toBeTruthy();
    expect(screen.getByLabelText('Name')).toBeTruthy();
    expect(screen.getByLabelText('Email')).toBeTruthy();
    expect(screen.getByLabelText('Guests')).toBeTruthy();
    expect(screen.getByRole('button', { name: 'Book' })).toBeTruthy();
  });

  it('shows each empty field error next to its field and sends nothing', async () => {
    const fetchMock = mockApi({});
    renderAt();
    await userEvent.setup().click(await screen.findByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Please enter your name.')).toBeTruthy();
    expect(errorFor('Name')).toBe('Please enter your name.');
    expect(errorFor('Email')).toBe('Please enter your email address.');
    expect(bookingPosts(fetchMock)).toHaveLength(0);
  });

  it('rejects an invalid email address next to the Email field', async () => {
    mockApi({});
    renderAt();
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Please enter a valid email address.')).toBeTruthy();
    expect(errorFor('Email')).toBe('Please enter a valid email address.');
    expect(errorFor('Name')).toBeNull();
  });

  it('rejects 9 guests next to the Guests field', async () => {
    mockApi({});
    renderAt();
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('You can book for at most 8 guests.')).toBeTruthy();
    expect(errorFor('Guests')).toContain('You can book for at most 8 guests.');
  });

  it('shows the server seats-left message next to the Guests field', async () => {
    mockApi({
      book: () => json(409, { errors: { guests: 'Only 2 seats are left.' } }),
    });
    renderAt();
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '5');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Only 2 seats are left.')).toBeTruthy();
    expect(errorFor('Guests')).toContain('Only 2 seats are left.');
  });

  it('shows a fully booked message from the server above the form', async () => {
    mockApi({ book: () => json(409, { message: 'This tasting is fully booked.' }) });
    renderAt();
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect((await screen.findByRole('alert')).textContent).toContain('This tasting is fully booked.');
  });

  it('shows a connection problem when the booking cannot be sent', async () => {
    mockApi({ book: () => Promise.reject(new TypeError('Failed to fetch')) });
    renderAt();
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect((await screen.findByRole('alert')).textContent).toContain('We could not send your booking.');
  });

  it('goes to the confirmation of the new booking', async () => {
    mockApi({});
    renderAt();
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Reached the confirmation' })).toBeTruthy();
  });

  it('says so when the tasting does not exist', async () => {
    mockApi({ tasting: 'missing' });
    renderAt(`/tastings/${winter.id}/book`);

    expect(await screen.findByText('This tasting was not found.')).toBeTruthy();
    expect(screen.getByRole('link', { name: 'Back to the tastings' }).getAttribute('href')).toBe('/');
  });

  it('shows that a fully booked tasting cannot be booked', async () => {
    mockApi({ tasting: { ...winter, seatsLeft: 0 } });
    renderAt();

    expect(await screen.findByText('This tasting is fully booked.')).toBeTruthy();
    expect((screen.getByRole('button', { name: 'Book' }) as HTMLButtonElement).disabled).toBe(true);
  });
});
