import { useEffect, useState } from 'react';
import { useForm, type FieldPath } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useNavigate, useParams } from 'react-router';
import { bookingSchema, type BookingInput } from '../../shared/booking';
import type { z } from 'zod';
import { ApiError, createBooking, getTasting, type Tasting } from '../api';
import { formatDateTime, formatPrice, seatsLabel } from '../format';

type Load = { status: 'loading' } | { status: 'ready'; tasting: Tasting } | { status: 'missing' } | { status: 'failed' };

export function BookingPage() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const [load, setLoad] = useState<Load>({ status: 'loading' });

  useEffect(() => {
    let current = true;
    getTasting(id)
      .then((tasting) => {
        if (current) setLoad({ status: 'ready', tasting });
      })
      .catch((error: unknown) => {
        if (!current) return;
        const notFound = error instanceof ApiError && error.status === 404;
        setLoad({ status: notFound ? 'missing' : 'failed' });
      });
    return () => {
      current = false;
    };
  }, [id]);

  if (load.status === 'loading') return <p role="status" className="text-muted">Loading the tasting…</p>;
  if (load.status === 'missing') {
    return (
      <section>
        <h1 className="font-display text-3xl text-wine-900">This tasting was not found.</h1>
        <p className="mt-3">
          <Link to="/" className="underline underline-offset-4">
            Back to the tastings
          </Link>
        </p>
      </section>
    );
  }
  if (load.status === 'failed') {
    return (
      <p role="alert" className="rounded-lg bg-danger-bg p-4 text-danger">
        We could not load this tasting. Please refresh the page.
      </p>
    );
  }
  return <BookingForm tasting={load.tasting} onBooked={(reference) => navigate(`/bookings/${reference}`)} />;
}

function BookingForm({ tasting, onBooked }: { tasting: Tasting; onBooked: (reference: string) => void }) {
  const soldOut = tasting.seatsLeft === 0;
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<z.input<typeof bookingSchema>, unknown, BookingInput>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  });
  const [formError, setFormError] = useState<string | null>(null);

  const onSubmit = async (values: BookingInput) => {
    setFormError(null);
    try {
      const confirmation = await createBooking(tasting.id, values);
      onBooked(confirmation.reference);
    } catch (error) {
      if (!(error instanceof ApiError)) {
        setFormError('We could not send your booking. Please check your connection and try again.');
      } else if (error.body.errors) {
        for (const [field, message] of Object.entries(error.body.errors)) {
          setError(field as FieldPath<z.input<typeof bookingSchema>>, { message });
        }
      } else if (error.status === 404) {
        setFormError('This tasting was not found.');
      } else {
        setFormError(error.message);
      }
    }
  };

  const fieldClass = (invalid: boolean) =>
    `mt-1 w-full rounded-lg border bg-white px-4 py-3 text-ink ${invalid ? 'border-danger' : 'border-line'}`;

  return (
    <section className="grid gap-10 md:grid-cols-[1fr_1.2fr]">
      <div>
        <h1 className="font-display text-4xl text-wine-900">{tasting.title}</h1>
        <p className="mt-3 text-ink">{formatDateTime(tasting.date, tasting.time)}</p>
        <p className="mt-1 text-muted">{formatPrice(tasting.priceCents)} per guest</p>
        <p className="mt-4 text-sm text-muted">{seatsLabel(tasting.seatsLeft)}</p>
      </div>

      <div className="rounded-2xl border border-line bg-parchment p-6 shadow-sm sm:p-8">
        {soldOut && (
          <p role="status" className="mb-6 rounded-lg bg-line p-4 text-ink">
            This tasting is fully booked.
          </p>
        )}
        {formError && (
          <p role="alert" className="mb-6 rounded-lg bg-danger-bg p-4 text-danger">
            {formError}
          </p>
        )}

        <form noValidate onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <div>
            <label htmlFor="name" className="block font-medium">
              Name
            </label>
            <input
              id="name"
              type="text"
              autoComplete="name"
              aria-invalid={errors.name ? true : undefined}
              aria-describedby={errors.name ? 'name-error' : undefined}
              className={fieldClass(!!errors.name)}
              {...register('name')}
            />
            {errors.name && <FieldError id="name-error" message={errors.name.message} />}
          </div>

          <div>
            <label htmlFor="email" className="block font-medium">
              Email
            </label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              aria-invalid={errors.email ? true : undefined}
              aria-describedby={errors.email ? 'email-error' : undefined}
              className={fieldClass(!!errors.email)}
              {...register('email')}
            />
            {errors.email && <FieldError id="email-error" message={errors.email.message} />}
          </div>

          <div>
            <label htmlFor="guests" className="block font-medium">
              Guests
            </label>
            <input
              id="guests"
              type="number"
              inputMode="numeric"
              min={1}
              max={8}
              aria-invalid={errors.guests ? true : undefined}
              aria-describedby={errors.guests ? 'guests-error guests-hint' : 'guests-hint'}
              className={fieldClass(!!errors.guests)}
              {...register('guests', { valueAsNumber: true })}
            />
            <p id="guests-hint" className="mt-1 text-sm text-muted">
              1 to 8 guests
            </p>
            {errors.guests && <FieldError id="guests-error" message={errors.guests.message} />}
          </div>

          <button
            type="submit"
            disabled={soldOut || isSubmitting}
            className="w-full rounded-lg bg-wine-700 px-6 py-3 font-medium text-cream hover:bg-wine-800 disabled:cursor-not-allowed disabled:bg-line disabled:text-muted"
          >
            Book
          </button>
        </form>
      </div>
    </section>
  );
}

function FieldError({ id, message }: { id: string; message?: string }) {
  return (
    <p id={id} className="mt-1 text-sm font-medium text-danger">
      {message}
    </p>
  );
}
