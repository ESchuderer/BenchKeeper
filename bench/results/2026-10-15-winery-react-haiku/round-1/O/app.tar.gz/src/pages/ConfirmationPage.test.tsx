import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router';
import { ConfirmationPage } from './ConfirmationPage';

function renderAt(reference: string) {
  return render(
    <MemoryRouter initialEntries={[`/bookings/${reference}`]}>
      <Routes>
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
      </Routes>
    </MemoryRouter>,
  );
}

describe('ConfirmationPage', () => {
  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it('shows the booking confirmed with tasting, guests, total and reference', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify({
            reference: 'KB-ABC234',
            tastingId: 'red-wine-cellar-tour',
            tastingTitle: 'Red Wine Cellar Tour',
            guests: 2,
            totalCents: 6400,
          }),
          { status: 200 },
        ),
      ),
    );
    renderAt('KB-ABC234');

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeTruthy();
    expect(screen.getByText('Red Wine Cellar Tour')).toBeTruthy();
    expect(screen.getByText('2')).toBeTruthy();
    expect(screen.getByText('€64.00')).toBeTruthy();
    expect(screen.getByText('KB-ABC234')).toBeTruthy();
  });

  it('says so when the reference is unknown', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('{"message":"Booking not found."}', { status: 404 })));
    renderAt('KB-NOPE00');

    expect(await screen.findByRole('heading', { name: 'Booking not found' })).toBeTruthy();
  });
});
