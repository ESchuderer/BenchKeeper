import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { ApiError, getBooking, type Confirmation } from '../api';
import { formatPrice } from '../format';

type Load = { status: 'loading' } | { status: 'ready'; booking: Confirmation } | { status: 'missing' } | { status: 'failed' };

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const [load, setLoad] = useState<Load>({ status: 'loading' });

  useEffect(() => {
    let current = true;
    getBooking(reference)
      .then((booking) => {
        if (current) setLoad({ status: 'ready', booking });
      })
      .catch((error: unknown) => {
        if (!current) return;
        const notFound = error instanceof ApiError && error.status === 404;
        setLoad({ status: notFound ? 'missing' : 'failed' });
      });
    return () => {
      current = false;
    };
  }, [reference]);

  if (load.status === 'loading') return <p role="status" className="text-muted">Loading your booking…</p>;
  if (load.status === 'missing') {
    return (
      <section>
        <h1 className="font-display text-4xl text-wine-900">Booking not found</h1>
        <p className="mt-3 text-muted">We could not find a booking with this reference.</p>
        <p className="mt-6">
          <Link to="/" className="underline underline-offset-4">
            Back to the tastings
          </Link>
        </p>
      </section>
    );
  }
  if (load.status === 'failed') {
    return (
      <p role="alert" className="rounded-lg bg-danger-bg p-4 text-danger">
        We could not load this booking. Please try again later.
      </p>
    );
  }

  const { booking } = load;
  return (
    <section className="mx-auto max-w-xl rounded-2xl border border-line bg-parchment p-6 shadow-sm sm:p-10">
      <p className="text-sm font-medium uppercase tracking-widest text-success">Thank you</p>
      <h1 className="mt-2 font-display text-4xl text-wine-900">Booking confirmed</h1>

      <dl className="mt-8 divide-y divide-line">
        <Detail label="Tasting">{booking.tastingTitle}</Detail>
        <Detail label="Guests">{booking.guests}</Detail>
        <Detail label="Total">{formatPrice(booking.totalCents)}</Detail>
        <Detail label="Booking reference">
          <span className="font-mono text-lg tracking-wider">{booking.reference}</span>
        </Detail>
      </dl>

      <p className="mt-8 text-sm text-muted">
        Please keep this booking reference. The cellar team can find your booking with it.
      </p>
      <p className="mt-6">
        <Link to="/" className="underline underline-offset-4">
          Back to the tastings
        </Link>
      </p>
    </section>
  );
}

function Detail({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-3">
      <dt className="text-muted">{label}</dt>
      <dd className="text-right font-medium">{children}</dd>
    </div>
  );
}
