import { Link } from 'react-router';

export function NotFoundPage() {
  return (
    <section>
      <h1 className="font-display text-4xl text-wine-900">Page not found</h1>
      <p className="mt-3 text-muted">
        <Link to="/" className="underline underline-offset-4">
          Back to the tastings
        </Link>
      </p>
    </section>
  );
}
