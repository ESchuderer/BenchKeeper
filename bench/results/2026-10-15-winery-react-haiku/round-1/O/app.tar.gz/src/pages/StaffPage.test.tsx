import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { StaffPage } from './StaffPage';

function json(status: number, body?: unknown) {
  return new Response(body === undefined ? null : JSON.stringify(body), {
    status,
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
  });
}

const booking = { reference: 'KB-ABC234', tastingId: 'riesling-evening', name: 'Anna Weber', email: 'anna@example.com', guests: 3 };

// A tiny stand-in for the server: `signedIn` decides whether the session cookie is accepted.
function fakeServer(options: { password?: string; signIn?: () => Response; signedIn?: boolean } = {}) {
  const state = {
    signedIn: options.signedIn ?? false,
    bookings: [booking],
  };
  const groups = () => [
    { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', priceCents: 2500, seats: 12, seatsLeft: 12 - state.bookings.reduce((s, b) => s + b.guests, 0), bookings: state.bookings },
    { id: 'winter-tasting', title: 'Winter Tasting', date: '2026-12-05', time: '17:00', priceCents: 2800, seats: 10, seatsLeft: 10, bookings: [] },
  ];
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    const method = init?.method ?? 'GET';
    if (url === '/api/staff/session' && method === 'POST') {
      if (options.signIn) return options.signIn();
      const { password } = JSON.parse(String(init?.body));
      if (options.password && password === options.password) {
        state.signedIn = true;
        return json(204);
      }
      return json(401, { message: 'The password is wrong.' });
    }
    if (url === '/api/staff/bookings' && method === 'GET') {
      return state.signedIn ? json(200, groups()) : json(401, { message: 'Please sign in.' });
    }
    if (url.startsWith('/api/staff/bookings/') && method === 'DELETE') {
      if (!state.signedIn) return json(401, { message: 'Please sign in.' });
      const reference = url.split('/').pop();
      const before = state.bookings.length;
      state.bookings = state.bookings.filter((b) => b.reference !== reference);
      return before === state.bookings.length ? json(404, { message: 'This booking no longer exists.' }) : json(204);
    }
    return json(500, { message: `unexpected ${method} ${url}` });
  });
  vi.stubGlobal('fetch', fetchMock);
  return { fetchMock, state };
}

function renderPage() {
  return render(
    <MemoryRouter>
      <StaffPage />
    </MemoryRouter>,
  );
}

async function signIn(password: string) {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
}

describe('StaffPage', () => {
  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it('asks for the password until staff are signed in', async () => {
    fakeServer({ password: 'secret' });
    renderPage();

    expect(await screen.findByLabelText('Password')).toBeTruthy();
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeTruthy();
    expect(screen.queryByText('Anna Weber')).toBeNull();
  });

  it('rejects a wrong password and shows no booking data', async () => {
    fakeServer({ password: 'secret' });
    renderPage();
    await signIn('wrong');

    expect((await screen.findByRole('alert')).textContent).toContain('The password is wrong.');
    expect(screen.queryByText('Anna Weber')).toBeNull();
  });

  it('shows all bookings grouped by tasting after a correct sign-in', async () => {
    fakeServer({ password: 'secret' });
    renderPage();
    await signIn('secret');

    const group = await screen.findByRole('region', { name: 'Riesling Evening' });
    expect(within(group).getByText('Anna Weber')).toBeTruthy();
    expect(within(group).getByText('anna@example.com')).toBeTruthy();
    expect(within(group).getByText('3')).toBeTruthy();
    expect(within(group).getByText('KB-ABC234')).toBeTruthy();

    const empty = screen.getByRole('region', { name: 'Winter Tasting' });
    expect(within(empty).getByText('No bookings yet.')).toBeTruthy();
  });

  it('removes a booking when it is cancelled', async () => {
    fakeServer({ password: 'secret', signedIn: true });
    renderPage();

    const user = userEvent.setup();
    await user.click(await screen.findByRole('button', { name: 'Cancel booking KB-ABC234' }));

    expect(await screen.findByText('Booking cancelled. Its seats are free again.')).toBeTruthy();
    expect(screen.queryByText('Anna Weber')).toBeNull();
    expect(within(screen.getByRole('region', { name: 'Winter Tasting' })).getByText('No bookings yet.')).toBeTruthy();
  });

  it('sends one cancel request for a double click', async () => {
    const { fetchMock } = fakeServer({ password: 'secret', signedIn: true });
    renderPage();
    const cancel = await screen.findByRole('button', { name: 'Cancel booking KB-ABC234' });

    fireEvent.click(cancel);
    fireEvent.click(cancel);
    expect(await screen.findByText('Booking cancelled. Its seats are free again.')).toBeTruthy();

    const deletes = fetchMock.mock.calls.filter(([, init]) => init?.method === 'DELETE');
    expect(deletes).toHaveLength(1);
  });

  it('returns to the sign-in form when the session has ended', async () => {
    const { state } = fakeServer({ password: 'secret', signedIn: true });
    renderPage();
    const cancel = await screen.findByRole('button', { name: 'Cancel booking KB-ABC234' });

    state.signedIn = false;
    await userEvent.setup().click(cancel);

    expect(await screen.findByLabelText('Password')).toBeTruthy();
    expect(screen.queryByText('Anna Weber')).toBeNull();
  });

  it('shows the rate limit message from the server', async () => {
    fakeServer({ signIn: () => json(429, { message: 'Too many sign-in attempts. Try again later.' }) });
    renderPage();
    await signIn('anything');

    expect((await screen.findByRole('alert')).textContent).toContain('Too many sign-in attempts.');
  });
});
