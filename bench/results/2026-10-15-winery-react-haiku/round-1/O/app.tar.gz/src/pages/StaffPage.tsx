import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ApiError, cancelBooking, staffBookings, staffSignIn, type StaffTasting } from '../api';
import { formatDateTime, seatsLabel } from '../format';

type View =
  | { name: 'checking' }
  | { name: 'signin' }
  | { name: 'overview'; groups: StaffTasting[]; notice?: string }
  | { name: 'failed' };

export function StaffPage() {
  const [view, setView] = useState<View>({ name: 'checking' });
  const [cancelling, setCancelling] = useState(false);

  // A 401 means the session is missing or has ended, so the sign-in form takes over.
  const refresh = useCallback(async (notice?: string) => {
    try {
      setView({ name: 'overview', groups: await staffBookings(), notice });
    } catch (error) {
      const unauthorized = error instanceof ApiError && error.status === 401;
      setView(unauthorized ? { name: 'signin' } : { name: 'failed' });
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function cancel(reference: string) {
    if (cancelling) return;
    setCancelling(true);
    try {
      await cancelBooking(reference);
      await refresh('Booking cancelled. Its seats are free again.');
    } catch (error) {
      const gone = error instanceof ApiError && error.status === 404;
      await refresh(gone ? 'That booking no longer exists.' : 'The booking could not be cancelled. Please try again.');
    } finally {
      setCancelling(false);
    }
  }

  if (view.name === 'checking') return <p role="status" className="text-muted">Loading…</p>;
  if (view.name === 'failed') {
    return (
      <p role="alert" className="rounded-lg bg-danger-bg p-4 text-danger">
        We could not load the bookings. Please refresh the page.
      </p>
    );
  }
  if (view.name === 'signin') return <SignInForm onSignedIn={() => refresh()} />;

  return (
    <section>
      <h1 className="font-display text-4xl text-wine-900">Bookings</h1>
      <p className="mt-3 text-muted">All reservations, grouped by tasting.</p>
      {view.notice && (
        <p role="status" className="mt-6 rounded-lg bg-success-bg p-4 text-success">
          {view.notice}
        </p>
      )}

      <div className="mt-8 space-y-8">
        {view.groups.map((group) => (
          <TastingGroup key={group.id} group={group} onCancel={cancel} cancelling={cancelling} />
        ))}
      </div>
    </section>
  );
}

const signInSchema = z.object({
  password: z.string().min(1, 'Please enter the password.'),
});

function SignInForm({ onSignedIn }: { onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<z.infer<typeof signInSchema>>({
    resolver: zodResolver(signInSchema),
    defaultValues: { password: '' },
  });

  const onSubmit = async ({ password }: z.infer<typeof signInSchema>) => {
    try {
      await staffSignIn(password);
      onSignedIn();
    } catch (error) {
      const message = error instanceof ApiError && error.body.message;
      setError('password', { message: message || 'We could not sign you in. Please try again.' });
    }
  };

  return (
    <section className="mx-auto max-w-md">
      <h1 className="font-display text-4xl text-wine-900">Staff sign-in</h1>
      <p className="mt-3 text-muted">Enter the staff password to see today&rsquo;s bookings.</p>

      <form noValidate onSubmit={handleSubmit(onSubmit)} className="mt-8 space-y-5 rounded-2xl border border-line bg-parchment p-6 shadow-sm sm:p-8">
        <div>
          <label htmlFor="password" className="block font-medium">
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            aria-invalid={errors.password ? true : undefined}
            aria-describedby={errors.password ? 'password-error' : undefined}
            className={`mt-1 w-full rounded-lg border bg-white px-4 py-3 ${errors.password ? 'border-danger' : 'border-line'}`}
            {...register('password')}
          />
          {errors.password && (
            <p id="password-error" role="alert" className="mt-1 text-sm font-medium text-danger">
              {errors.password.message}
            </p>
          )}
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full rounded-lg bg-wine-700 px-6 py-3 font-medium text-cream hover:bg-wine-800 disabled:bg-line disabled:text-muted"
        >
          Sign in
        </button>
      </form>
    </section>
  );
}

function TastingGroup({
  group,
  onCancel,
  cancelling,
}: {
  group: StaffTasting;
  onCancel: (reference: string) => void;
  cancelling: boolean;
}) {
  return (
    <section aria-label={group.title} className="overflow-hidden rounded-2xl border border-line bg-parchment shadow-sm">
      <header className="flex flex-wrap items-baseline justify-between gap-2 border-b border-line px-5 py-4">
        <h2 className="font-display text-2xl text-wine-900">{group.title}</h2>
        <p className="text-sm text-muted">
          {formatDateTime(group.date, group.time)} · {seatsLabel(group.seatsLeft)}
        </p>
      </header>

      {group.bookings.length === 0 ? (
        <p className="px-5 py-4 text-muted">No bookings yet.</p>
      ) : (
        <div className="relative overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-cream text-muted">
              <tr>
                <th scope="col" className="px-5 py-3 font-medium">Name</th>
                <th scope="col" className="px-5 py-3 font-medium">Email</th>
                <th scope="col" className="px-5 py-3 font-medium">Guests</th>
                <th scope="col" className="px-5 py-3 font-medium">Reference</th>
                <th scope="col" className="px-5 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {group.bookings.map((booking) => (
                <tr key={booking.reference}>
                  <td className="px-5 py-3 font-medium">{booking.name}</td>
                  <td className="px-5 py-3">{booking.email}</td>
                  <td className="px-5 py-3">{booking.guests}</td>
                  <td className="px-5 py-3 font-mono">{booking.reference}</td>
                  <td className="px-5 py-3 text-right">
                    <button
                      type="button"
                      aria-label={`Cancel booking ${booking.reference}`}
                      onClick={() => onCancel(booking.reference)}
                      disabled={cancelling}
                      className="rounded-md border border-danger px-3 py-1.5 font-medium text-danger hover:bg-danger-bg disabled:opacity-50"
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
