import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { TastingsPage } from './TastingsPage';
import type { Tasting } from '../api';

const tastings: Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', priceCents: 2500, seats: 12, seatsLeft: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', date: '2026-11-14', time: '15:00', priceCents: 3200, seats: 8, seatsLeft: 1 },
  { id: 'winter-tasting', title: 'Winter Tasting', date: '2026-12-05', time: '17:00', priceCents: 2800, seats: 10, seatsLeft: 0 },
];

function renderPage() {
  return render(
    <MemoryRouter>
      <TastingsPage />
    </MemoryRouter>,
  );
}

describe('TastingsPage', () => {
  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it('lists each tasting with date, time, price and seats left', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify(tastings), { status: 200 })));
    renderPage();

    const card = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(card).getByText('Friday, 6 November 2026 · 18:00')).toBeTruthy();
    expect(within(card).getByText('€25.00 per guest')).toBeTruthy();
    expect(within(card).getByText('12 seats left')).toBeTruthy();
  });

  it('uses the singular for one seat left', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify(tastings), { status: 200 })));
    renderPage();

    const card = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(card).getByText('1 seat left')).toBeTruthy();
  });

  it('marks a fully booked tasting and offers no booking link for it', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify(tastings), { status: 200 })));
    renderPage();

    const card = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(card).getByText('Fully booked')).toBeTruthy();
    expect(within(card).queryByRole('link', { name: 'Book Winter Tasting' })).toBeNull();
    expect(within(card).getByRole('button', { name: 'Sold out' }).hasAttribute('disabled')).toBe(true);
  });

  it('links each open tasting to its booking form', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify(tastings), { status: 200 })));
    renderPage();

    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link.getAttribute('href')).toBe('/tastings/riesling-evening/book');
  });

  it('shows an error when the list cannot be loaded', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Failed to fetch')));
    renderPage();

    expect((await screen.findByRole('alert')).textContent).toContain('We could not load the tastings.');
  });
});
