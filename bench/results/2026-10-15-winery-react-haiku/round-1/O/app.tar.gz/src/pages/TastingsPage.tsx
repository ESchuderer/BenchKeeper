import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { listTastings, type Tasting } from '../api';
import { formatDateTime, formatPrice, seatsLabel } from '../format';

export function TastingsPage() {
  const [tastings, setTastings] = useState<Tasting[] | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let current = true;
    listTastings()
      .then((list) => {
        if (current) setTastings(list);
      })
      .catch(() => {
        if (current) setFailed(true);
      });
    return () => {
      current = false;
    };
  }, []);

  return (
    <section>
      <h1 className="font-display text-4xl text-wine-900 sm:text-5xl">Wine tastings</h1>
      <p className="mt-3 max-w-prose text-muted">
        Reserve your seats online. Every tasting is hosted by the family at the cellar door.
      </p>

      {failed && (
        <p role="alert" className="mt-8 rounded-lg bg-danger-bg p-4 text-danger">
          We could not load the tastings. Please refresh the page.
        </p>
      )}
      {!failed && tastings === null && (
        <p role="status" className="mt-8 text-muted">
          Loading tastings…
        </p>
      )}

      <ul className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {tastings?.map((tasting) => (
          <li key={tasting.id}>
            <TastingCard tasting={tasting} />
          </li>
        ))}
      </ul>
    </section>
  );
}

function TastingCard({ tasting }: { tasting: Tasting }) {
  const soldOut = tasting.seatsLeft === 0;
  const fewLeft = tasting.seatsLeft > 0 && tasting.seatsLeft <= 3;

  let badgeClass = 'bg-success-bg text-success';
  if (soldOut) badgeClass = 'bg-line text-ink';
  else if (fewLeft) badgeClass = 'bg-warning-bg text-warning';

  return (
    <article aria-label={tasting.title} className="flex h-full flex-col rounded-2xl border border-line bg-parchment p-6 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <h2 className="font-display text-2xl text-wine-900">{tasting.title}</h2>
        <p className={`shrink-0 rounded-full px-3 py-1 text-sm font-medium ${badgeClass}`}>
          {soldOut ? 'Fully booked' : seatsLabel(tasting.seatsLeft)}
        </p>
      </div>

      <p className="mt-3 text-ink">
        <time dateTime={`${tasting.date}T${tasting.time}`}>{formatDateTime(tasting.date, tasting.time)}</time>
      </p>
      <p className="mt-1 text-muted">{formatPrice(tasting.priceCents)} per guest</p>

      <div className="mt-auto pt-6">
        {soldOut ? (
          <button
            type="button"
            disabled
            className="w-full cursor-not-allowed rounded-lg bg-line px-4 py-3 font-medium text-muted"
          >
            Sold out
          </button>
        ) : (
          <Link
            to={`/tastings/${tasting.id}/book`}
            className="block w-full rounded-lg bg-wine-700 px-4 py-3 text-center font-medium text-cream hover:bg-wine-800"
          >
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
