# Weingut Kieselbrunnen: wine tasting bookings

A small web app where guests book wine tastings online and staff see and cancel bookings.
Built with Express (API and server), React with React Router (interface), React Hook Form and Zod (forms and validation), and Tailwind CSS (styling).

## Run it

```bash
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start
```

Open http://localhost:3000. Staff sign in at http://localhost:3000/staff.

Run exactly one server process per data file: bookings are held in memory by that process. Use HTTPS in front of it on any shared network, because the staff password and session cookie are otherwise sent unencrypted.

Settings are environment variables: `PORT` (default 3000), `STAFF_PASSWORD` (staff sign-in is refused without it), `DATA_FILE` (default `data/bookings.json`), and `TRUST_PROXY` (set to `true` only behind one reverse proxy).

## Tests

```bash
npm test          # API, storage and component tests
npm run typecheck # TypeScript checks
```

## Where things are

- `src/server`: API, booking store (one JSON file), staff sessions, fixed tastings list (`tastings.ts`)
- `src/client`: React pages, API calls, styling
- `src/shared/booking.ts`: validation rules used by both the form and the API
- `specs/001-tasting-bookings`: specification, plan, data model, API contract and task list

For the checks to run by hand, see `specs/001-tasting-bookings/quickstart.md`.
