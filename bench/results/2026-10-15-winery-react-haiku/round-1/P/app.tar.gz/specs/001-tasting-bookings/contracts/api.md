# HTTP API Contract

Base path: `/api`. All request and response bodies are JSON. Errors that concern form fields use the shape `{ "errors": { "<field>": "<message>" } }`, where the field is `name`, `email`, `guests` or `form` (a message not tied to one field).

## Guest

### `GET /api/tastings`

200:

```json
{ "tastings": [
  { "id": "riesling-evening", "title": "Riesling Evening", "startsAt": "2026-11-06T18:00:00+01:00",
    "priceEur": 25, "seats": 12, "seatsLeft": 12, "status": "open" }
] }
```

`status` is `open`, `fully-booked` or `closed`.

### `POST /api/tastings/:tastingId/bookings`

Request:

```json
{ "name": "Anna Keller", "email": "anna@example.com", "guests": 2 }
```

| Status | When | Body |
|---|---|---|
| 201 | Booking saved | `{ "booking": { "reference", "tastingId", "title", "startsAt", "name", "guests", "priceEur", "totalEur" } }` |
| 400 | Invalid input | `{ "errors": { "name": "...", "email": "...", "guests": "..." } }` (only the fields that are invalid) |
| 404 | Unknown tasting | `{ "errors": { "form": "This tasting does not exist." } }` |
| 409 | Not enough seats | `{ "errors": { "guests": "Only 3 seats left." } }` |
| 409 | Tasting closed or fully booked | `{ "errors": { "form": "Booking closed." } }` or `{ "errors": { "form": "Fully booked." } }` |

`totalEur` = `priceEur` × `guests`.

## Staff

Staff endpoints use the `staff_session` cookie set by sign-in. Without a valid cookie they return 401 `{ "errors": { "form": "Please sign in." } }`.

### `POST /api/staff/session`

Request: `{ "password": "..." }`

| Status | When | Body |
|---|---|---|
| 204 | Correct password; `Set-Cookie: staff_session=...; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800` | none |
| 401 | Wrong password | `{ "errors": { "password": "Incorrect password." } }` |
| 429 | More than 10 failed attempts from this IP in 15 minutes | `{ "errors": { "form": "Too many attempts. Try again later." } }` |
| 503 | `STAFF_PASSWORD` not set | `{ "errors": { "form": "Staff access is not configured." } }` |

### `GET /api/staff/session`

204 when the cookie is a valid session, otherwise 401.

### `DELETE /api/staff/session`

Signs out: 204, and clears the cookie.

### `GET /api/staff/bookings`

200:

```json
{ "tastings": [
  { "id": "riesling-evening", "title": "Riesling Evening", "startsAt": "2026-11-06T18:00:00+01:00",
    "seats": 12, "seatsLeft": 10,
    "bookings": [ { "reference": "K7Q3M9XT", "name": "Anna Keller", "email": "anna@example.com", "guests": 2 } ] }
] }
```

### `DELETE /api/staff/bookings/:reference`

204 when cancelled (seats freed at once). 404 when no booking has that reference.
