# Data Model: Wine Tasting Bookings

## Tasting (fixed in code, `src/server/tastings.ts`)

| Field | Type | Rule |
|---|---|---|
| `id` | string | URL-safe slug: `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting` |
| `title` | string | As in the brief |
| `startsAt` | ISO 8601 with offset | `2026-11-06T18:00:00+01:00`, `2026-11-14T15:00:00+01:00`, `2026-12-05T17:00:00+01:00` |
| `priceEur` | integer | Whole euros per guest: 25, 32, 28 |
| `seats` | integer | Capacity: 12, 8, 10 |

**Derived (never stored)**:
- `seatsLeft` = `seats` − sum of `guests` over bookings for this tasting.
- `status`:
  - `closed` when now ≥ `startsAt`.
  - `fully-booked` when `seatsLeft` = 0 (and not closed).
  - `open` otherwise.

## Booking (stored)

| Field | Type | Rule |
|---|---|---|
| `reference` | string | 8 characters from the reference alphabet; unique across all bookings |
| `tastingId` | string | Must match a tasting id |
| `name` | string | Trimmed; 1 to 100 characters |
| `email` | string | Trimmed; valid email address; at most 254 characters |
| `guests` | integer | 1 to 8 |
| `createdAt` | ISO 8601 string | Server time of booking |

**Lifecycle**: created by a guest (if the tasting is open and `guests` ≤ `seatsLeft`); removed by staff (cancel). No other state.

## Staff session (in memory, `src/server/staffSessions.ts`)

| Field | Type | Rule |
|---|---|---|
| `token` | string | 32 random bytes, base64url; key of the session map |
| `expiresAt` | epoch ms | Creation time + 8 hours; expired sessions are removed when checked |

## File format (`data/bookings.json`)

```json
{ "bookings": [ { "reference": "K7Q3M9XT", "tastingId": "riesling-evening", "name": "Anna Keller", "email": "anna@example.com", "guests": 2, "createdAt": "2026-10-20T09:15:00.000Z" } ] }
```

- Missing file, or a file with no `bookings` array, means no bookings (FR-019).
- Written as a whole, through a temp file and rename, after every change.
