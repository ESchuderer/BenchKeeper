# Implementation Plan: Wine Tasting Bookings for Weingut Kieselbrunnen

**Branch**: `001-tasting-bookings` | **Date**: 2026-10-14 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/001-tasting-bookings/spec.md`

## Summary

A single Node.js web app: an Express server exposes a JSON API under `/api` and serves a React single-page app built with Vite. Guests browse three fixed tastings, book seats, and see a confirmation. Staff sign in with `STAFF_PASSWORD`, see bookings by tasting, and cancel them. Bookings live in one JSON file, written atomically, and every seat check and write happens in one synchronous step on the server, so overbooking cannot happen under concurrent requests.

## Technical Context

**Language/Version**: TypeScript 5.9 (strict) on Node.js 22

**Primary Dependencies**:
- Server: Express 5 (routing, JSON parsing, static files), zod 4 (input validation), helmet (security headers), express-rate-limit (staff sign-in throttling)
- Client: React 19, React Router 8 (routing), React Hook Form with the zod resolver (forms and per-field errors), Tailwind CSS 4 (styling)
- Build: Vite 8 (client bundle), `tsc` (server bundle)

**Storage**: One JSON file (`data/bookings.json` by default, `DATA_FILE` overrides). Loaded at start, kept in memory, rewritten atomically (temp file + rename) on each change.

**Testing**: Vitest. Server API tests use supertest. Component tests use Testing Library with jsdom.

**Target Platform**: Linux server (dev container), Node.js 22; browsers on desktop and phones.

**Project Type**: Web application (server + single-page client), one repository.

**Performance Goals**: Booking and listing respond within 100 ms on the local server; the app serves about 1000 simultaneous booking attempts for one tasting without overbooking (SC-002).

**Constraints**: No external services (no CDN fonts, no email, no hosted database). All interface text in English. Usable at 360 px width. Staff session cookie HTTP-only and SameSite=Strict.

**Scale/Scope**: 3 tastings, a few hundred bookings at most, one staff password, one process.

## Constitution Check

*The constitution file is still the unfilled template, so there are no project principles to check against. The gates below come from the brief and the spec instead.*

- Built with React and established libraries for server, routing, forms and styling: **pass**.
- `npm install`, `npm run build`, `npm start` on `PORT` (default 3000): **pass by design** (verified in the verify phase).
- Bookings stored locally, no external services: **pass**.
- Test-first for the booking rules and staff access: **pass** (tests precede the code in `tasks.md`).
- Complexity: one server file group, one client app. No repository layer, no ORM, no state library; the store is a single module with five functions. **pass**.

## Project Structure

### Documentation (this feature)

```text
specs/001-tasting-bookings/
├── plan.md              # This file
├── research.md          # Technology and design decisions
├── data-model.md        # Tasting and booking entities, validation, states
├── quickstart.md        # How to run and check the app
├── contracts/
│   └── api.md           # HTTP API used by the React app
├── checklists/
│   └── requirements.md  # Spec quality checklist
└── tasks.md             # Created by /speckit-tasks
```

### Source Code (repository root)

```text
src/
├── shared/
│   └── booking.ts          # zod schema for the booking form (used by client and server)
├── server/
│   ├── index.ts            # Reads PORT / STAFF_PASSWORD / DATA_FILE, starts the server
│   ├── app.ts              # createApp(options): Express app with API, security and static files
│   ├── tastings.ts         # The three fixed tastings and their status rules
│   ├── store.ts            # Bookings in memory + atomic JSON file; seat counting; add/remove
│   └── staffSessions.ts    # Random session tokens with 8-hour expiry
└── client/
    ├── main.tsx            # Mounts the app with BrowserRouter
    ├── App.tsx             # Layout (winery header) and routes
    ├── api.ts              # fetch helpers for /api
    ├── format.ts           # Date (Europe/Berlin) and price formatting
    ├── index.css           # Tailwind import and the winery theme
    └── pages/
        ├── TastingsPage.tsx      # Start page: tasting cards with seats left
        ├── BookingPage.tsx       # Booking form for one tasting
        ├── ConfirmationPage.tsx  # "Booking confirmed"
        └── StaffPage.tsx         # Sign-in, bookings by tasting, cancel, sign out

tests/
├── server/
│   ├── bookings.test.ts    # Guest API: listing, validation, seats, closed tastings, concurrency
│   ├── staff.test.ts       # Staff API: sign-in, cookie, rate limit, cancel, sign-out, expiry
│   └── store.test.ts       # Persistence across restarts, missing file
└── client/
    ├── TastingsPage.test.tsx
    ├── BookingPage.test.tsx
    └── StaffPage.test.tsx

index.html                  # Vite entry
vite.config.ts              # Vite + React + Tailwind + Vitest config
tsconfig.json               # Client, shared and tests (type check only)
tsconfig.server.json        # Server build to dist/server
data/                       # Runtime data (git-ignored)
dist/                       # Build output (git-ignored)
```

**Structure Decision**: One package with a clear split: `src/server` (Node, compiled by `tsc`), `src/client` (browser, bundled by Vite), `src/shared` (the zod booking schema, imported by both). Tests mirror that split. This is the smallest structure that keeps the browser code out of the server build and lets the booking rules be checked in one place.

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|-----------|------------|-------------------------------------|
| Two tsconfig files | The server must run as plain Node output; the client needs DOM types and JSX | One config would mix DOM and Node types and emit client files into the server build |
| Rate-limit and security-header dependencies | The brief asks for an established staff password gate; a password can be brute-forced without limits | Hand-written limiter and header code would be more code to maintain than the two small packages |
