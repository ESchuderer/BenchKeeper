# Quickstart: Wine Tasting Bookings

## Run it

```bash
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start      # serves on http://localhost:3000
```

Optional environment variables:

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | Port to listen on |
| `STAFF_PASSWORD` | none | Staff sign-in password. Without it, staff sign-in is refused. |
| `DATA_FILE` | `data/bookings.json` | Where bookings are stored |
| `TRUST_PROXY` | unset | Set to `true` only when behind one reverse proxy (see below) |

Run exactly one server process per data file. Behind an HTTPS reverse proxy, set `TRUST_PROXY=true` so the server reads the client address and protocol from the proxy headers. This trusts exactly one proxy hop, makes the staff cookie `Secure`, and gives each client its own sign-in throttle. Only set it when every request reaches the app through that proxy, and make the proxy overwrite X-Forwarded-For with the connecting address. Without the proxy, leave it unset. Note: over plain HTTP the staff password and session cookie are not encrypted, so use HTTPS for any network the public or staff share.

## Check it by hand

1. Open `http://localhost:3000`. Three tastings are listed with "12 seats left", "8 seats left" and "10 seats left".
2. Press "Book Riesling Evening". Leave Name empty and enter `not-an-email` as the email; press "Book". Errors appear next to Name and Email, and nothing is booked.
3. Enter a name, a valid email and 2 guests; press "Book". "Booking confirmed" shows the tasting, 2 guests, EUR 50 and a reference. The start page now shows "10 seats left".
4. Open `http://localhost:3000/staff`. Enter a wrong password: an error appears. Enter the right one: the booking appears under Riesling Evening. Press "Cancel": it disappears and the start page shows "12 seats left" again.

## Run the tests

```bash
npm test          # server API, storage and component tests
npm run typecheck # TypeScript checks for client, shared and tests
```
