# Research: Wine Tasting Bookings

## Server framework
- **Decision**: Express 5.
- **Rationale**: Mature, maintained, widest knowledge base; Express 5 handles async errors and is the simplest way to serve both a JSON API and the built static app from one process.
- **Alternatives**: Fastify (faster, more plugin structure than this app needs); Hono (fine, but less common in hand-off to other developers); Next.js (full-stack framework, but needs a larger build and runtime for a 3-page app).

## Client routing
- **Decision**: React Router 8 with `BrowserRouter` and `Routes`.
- **Rationale**: The established React router; four routes (`/`, `/book/:tastingId`, `/confirmed`, `/staff`).
- **Alternatives**: TanStack Router (type-safe, more setup); hand-written routing on `window.location` (rejected: the brief asks for established libraries).

## Forms and validation
- **Decision**: React Hook Form with `@hookform/resolvers/zod`, using the zod schema from `src/shared/booking.ts`.
- **Rationale**: Gives per-field errors with little code, and the same schema validates on the client and on the server (trust boundary), so the rules cannot drift apart.
- **Alternatives**: Formik (larger, slower); plain controlled inputs (would duplicate the validation rules in two places).

## Styling
- **Decision**: Tailwind CSS 4 via `@tailwindcss/vite`, with the winery theme declared in CSS (`@theme`).
- **Rationale**: Small, consistent utility system with responsive modifiers for phone layouts; no runtime cost.
- **Alternatives**: CSS modules (more files for the same result); a component library such as MUI (heavier look that does not read as a small winery).

## Storage
- **Decision**: One JSON file, held in memory, written atomically (temp file + `rename`).
- **Rationale**: Survives restarts (FR-018) with no external service. Writes happen synchronously inside each request handler, so Node's single thread gives the check-then-write atomicity the seat rule needs (FR-007).
- **Alternatives**: SQLite via `better-sqlite3` (safer for large volumes, but a native build step for a few hundred rows); in-memory only (fails FR-018).

## Staff authentication
- **Decision**: Compare a SHA-256 digest of the submitted password with a digest of `STAFF_PASSWORD` using `crypto.timingSafeEqual`. On success, issue a random 32-byte session token in an HTTP-only, SameSite=Strict cookie with 8-hour expiry. Tokens live in memory.
- **Rationale**: No user accounts are needed (single shared password). The cookie cannot be read by scripts or sent cross-site, which covers CSRF for the JSON API together with the JSON content-type requirement.
- **Alternatives**: HTTP Basic auth (browser dialog, no sign-out, poor on phones); JWT (adds signing key management for one password); Passport.js (more than one password needs).
- **Trade-off**: Sessions are lost on restart; staff sign in again. Acceptable for this scale.

## Brute-force protection
- **Decision**: express-rate-limit on `POST /api/staff/session`, allowing 10 failed attempts per IP per 15 minutes (successful sign-ins do not count).
- **Rationale**: One shared password is otherwise open to guessing.
- **Trade-off**: Behind a reverse proxy all clients share one IP unless `trust proxy` is configured; the quickstart notes this.

## Security headers
- **Decision**: helmet with default settings.
- **Rationale**: Sets Content-Security-Policy (no inline scripts), frame and MIME protections in one line.

## Time and time zones
- **Decision**: Each tasting's start time is stored with its UTC offset (`+01:00`, Europe/Berlin winter time, which applies to all three dates). The client formats times with `Intl.DateTimeFormat` and `timeZone: 'Europe/Berlin'`.
- **Rationale**: Tastings show the same wall-clock time for every guest, whatever their device's time zone, and the "closed" check compares real instants.
- **Alternatives**: Storing local strings and formatting by hand (fragile around daylight saving changes); a date library such as date-fns-tz (one more dependency for three fixed dates).

## Booking reference
- **Decision**: 8 characters from `ABCDEFGHJKLMNPQRSTUVWXYZ23456789` (no 0, O, 1, I), from `crypto.randomInt`, regenerated on collision.
- **Rationale**: Readable over the phone (FR-009). 32^8 is about 10^12 possibilities, so collisions are rare and checked anyway.

## Testing
- **Decision**: Vitest for both suites; supertest for HTTP; Testing Library with jsdom for components.
- **Rationale**: One test runner, same TypeScript config, no browser needed for the main checks. A browser-level check is run separately in the verify phase.
