# Feature Specification: Wine Tasting Bookings for Weingut Kieselbrunnen

**Feature Branch**: `001-tasting-bookings`

**Created**: 2026-10-14

**Status**: Draft

**Input**: User description: "Build a web app for Weingut Kieselbrunnen, a family winery, so guests can book wine tastings online and staff can see the bookings."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Browse tastings and book seats (Priority: P1)

A guest opens the start page, sees the upcoming tastings with date, time, price per guest and the number of seats left, chooses one, and books seats for themselves and others by entering a name, an email address and a number of guests. They receive a booking confirmation with a booking reference.

**Why this priority**: Booking is the core value of the app. Without it, guests cannot buy a tasting and the winery gains nothing.

**Independent Test**: Open the start page, choose "Book Riesling Evening", enter valid details for 2 guests, press "Book", and check that the confirmation shows the tasting, 2 guests, the total price and a booking reference, and that the start page now shows 10 seats left for that tasting.

**Acceptance Scenarios**:

1. **Given** the start page is open, **When** the guest views it, **Then** each of the three tastings shows its title, date and time, price per guest (for example "EUR 25") and "<n> seats left".
2. **Given** a tasting has seats left, **When** the guest selects "Book Riesling Evening", **Then** a booking form for that tasting opens with fields labelled "Name", "Email" and "Guests" and a button "Book".
3. **Given** the booking form is valid (non-empty name, valid email, guests from 1 to 8 and no more than the seats left), **When** the guest presses "Book", **Then** the booking is saved, the seats left drop by the number of guests, and the guest sees a page with the heading "Booking confirmed", the tasting title, the number of guests, the total price (price per guest times guests) and a booking reference.
4. **Given** the guest enters an empty name, an invalid email, or a guest count outside 1 to 8, **When** they press "Book", **Then** no booking is made and an error message appears next to the field concerned.
5. **Given** a tasting has fewer seats left than the guest asks for, **When** the guest presses "Book", **Then** no booking is made and the error appears next to the "Guests" field, stating how many seats are left.
6. **Given** a tasting has no seats left, **When** the guest views the start page, **Then** the tasting is marked "Fully booked" and no "Book" link or button is offered for it.

---

### User Story 2 - Staff sign in and see all bookings (Priority: P2)

A member of staff opens `/staff`, enters the staff password and sees every booking grouped by tasting, with the guest's name, email, number of guests and booking reference.

**Why this priority**: Staff need to know who is coming. It depends on bookings existing (Story 1), but the app is not useful to the winery without it.

**Independent Test**: With one booking made, open `/staff`, sign in with the configured password, and check that the booking appears under its tasting with name, email, guests and reference.

**Acceptance Scenarios**:

1. **Given** a visitor opens `/staff`, **When** the page loads, **Then** they see a "Password" field and a "Sign in" button and no booking data.
2. **Given** the correct password is entered, **When** the staff member presses "Sign in", **Then** the bookings page is shown, grouped by tasting, with name, email, guests and reference for each booking.
3. **Given** a wrong password is entered, **When** the staff member presses "Sign in", **Then** access is refused with an error message next to the password field and no booking data is shown.
4. **Given** a tasting has no bookings, **When** staff view the bookings page, **Then** the tasting is still listed with a note that there are no bookings yet.

---

### User Story 3 - Staff cancel a booking (Priority: P3)

A signed-in staff member cancels a booking (for example after a phone call from the guest). The booking disappears and its seats become available again on the start page.

**Why this priority**: Cancellation is needed to keep seat counts correct, but it is used less often than viewing bookings.

**Independent Test**: With a booking for 3 guests on Winter Tasting (10 seats, 7 left), sign in as staff, press "Cancel" for that booking, and check that the booking is gone and the start page shows 10 seats left.

**Acceptance Scenarios**:

1. **Given** a signed-in staff member views a booking, **When** they press "Cancel" next to it, **Then** the booking is removed from the list and its seats are freed on the start page and for new bookings.
2. **Given** a signed-in staff member, **When** they press "Sign out", **Then** the bookings are no longer visible without signing in again.

---

### Edge Cases

- Two guests try to take the last seats at the same moment: the server accepts only bookings that fit in the seats left, so the second one is refused with a seat-count error.
- A guest submits the form twice (double click or reload): each press is a separate booking attempt; a second booking is made only if seats remain. The form disables its button while the request is in progress to make double submission unlikely.
- A tasting's start time has passed: it is no longer bookable and shows "Booking closed" instead of "Book".
- The `STAFF_PASSWORD` environment variable is not set: staff sign-in is refused with a clear message that staff access is not configured; guest booking still works.
- Many wrong staff passwords in a short time: further attempts from the same client are refused for a short period.
- The server restarts: bookings are kept, because they are stored in a local file.
- The data file is missing or empty at first start: the app starts with no bookings.
- Very long names or emails: rejected by length limits with an error message next to the field.
- Script or HTML in the name or email: stored and shown as plain text, never executed.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST offer exactly the three tastings below, each with a title, date and time, price per guest in EUR and a seat capacity:
  - Riesling Evening, 2026-11-06 18:00, EUR 25 per guest, 12 seats
  - Red Wine Cellar Tour, 2026-11-14 15:00, EUR 32 per guest, 8 seats
  - Winter Tasting, 2026-12-05 17:00, EUR 28 per guest, 10 seats
- **FR-002**: The start page MUST list all tastings with title, date and time, price per guest and the seats left, shown as "<n> seats left".
- **FR-003**: Each tasting MUST have a link or button labelled "Book <tasting title>" that opens a booking form for that tasting.
- **FR-004**: The booking form MUST have fields labelled "Name", "Email" and "Guests" (whole number from 1 to 8) and a button labelled "Book".
- **FR-005**: The system MUST reject invalid input and show an error message next to the field concerned: name missing or longer than 100 characters, email not in a valid address form or longer than 254 characters, guests not a whole number from 1 to 8.
- **FR-006**: A booking MUST NOT take more seats than are left for its tasting. Requests that would exceed the seats left MUST be refused and the error MUST be shown next to the "Guests" field, stating the number of seats left.
- **FR-007**: The seat check and the saving of a booking MUST happen as one step on the server, so that concurrent requests cannot overbook a tasting.
- **FR-008**: After a successful booking the guest MUST see a confirmation with the heading "Booking confirmed", the tasting title, the number of guests, the total price (price per guest times guests, shown as "EUR <amount>") and a booking reference.
- **FR-009**: Each booking MUST get a booking reference that is unique among bookings and short enough to read out over the phone (8 characters, letters and digits, no ambiguous characters such as 0, O, 1, I).
- **FR-010**: Tastings whose start time has passed MUST NOT accept new bookings and MUST be shown as "Booking closed".
- **FR-011**: Tastings with no seats left MUST be shown as "Fully booked" and MUST NOT offer booking.
- **FR-012**: The page `/staff` MUST show a "Password" field and a "Sign in" button. It MUST NOT show any booking data before a correct sign-in.
- **FR-013**: The staff password MUST be read from the environment variable `STAFF_PASSWORD`. The password MUST be compared in constant time. If `STAFF_PASSWORD` is not set, staff sign-in MUST be refused with a clear message.
- **FR-014**: After a correct sign-in the system MUST show all bookings grouped by tasting, with name, email, guests and booking reference for each booking.
- **FR-015**: Staff MUST be able to cancel any booking with a "Cancel" button. A cancelled booking MUST be removed and its seats MUST become available again immediately.
- **FR-016**: Staff sessions MUST be kept in an HTTP-only cookie that the browser cannot read from scripts and that is not sent with cross-site requests. Sessions MUST expire after 8 hours. Staff MUST be able to sign out.
- **FR-017**: Repeated failed staff sign-in attempts from the same client MUST be refused for a short period (rate limiting).
- **FR-018**: Bookings MUST be stored in a local file so that they survive a restart. No external service may be used.
- **FR-019**: The app MUST start with no bookings when no data file exists.
- **FR-020**: The server MUST serve the whole app (interface and API) on the port in the environment variable `PORT` (default 3000).
- **FR-021**: All interface text MUST be in English.
- **FR-022**: Guest and staff pages MUST show clear states for errors, success, and fully booked or closed tastings.
- **FR-023**: All pages MUST be usable on a phone-sized screen (no horizontal scrolling of the booking form or staff list at 360 px width).
- **FR-024**: Guest-entered text MUST be displayed as plain text and never executed.

### Key Entities

- **Tasting**: A wine tasting offered for booking. Attributes: identifier, title, start date and time, price per guest in whole euros, seat capacity. Fixed by the winery, not editable in the app.
- **Booking**: A reservation for one or more guests on one tasting. Attributes: booking reference, tasting, guest name, guest email, number of guests, time of booking. Belongs to exactly one tasting. Removed when cancelled.
- **Staff session**: A signed-in state for one browser. Attributes: random token, expiry time. Held by the server, referenced by an HTTP-only cookie.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A guest can go from the start page to a booking confirmation in under 1 minute on a phone.
- **SC-002**: Over 1000 simultaneous booking attempts for the last seats of one tasting, no more seats are booked than the tasting has.
- **SC-003**: Every invalid input listed in FR-005 and FR-006 is rejected with an error message next to the field concerned, in 100% of tested cases.
- **SC-004**: A booking made before a server restart is still listed on the staff page after the restart.
- **SC-005**: A staff member can find any booking by tasting and cancel it in under 30 seconds.
- **SC-006**: The start page, booking form, confirmation and staff page show no horizontal scrolling at 360 px width.

## Assumptions

- The winery's local time zone applies to all tasting times. Times are shown as the winery's wall-clock time, without conversion for guests in other time zones.
- Prices are whole euros, so amounts are shown without cents (for example "EUR 25").
- Guests cannot cancel their own bookings. Only staff can cancel, as requested. Guests contact the winery for changes.
- No confirmation email is sent, because no external services may be used. The confirmation page shows the booking reference, and staff hold the list.
- A cancelled booking is removed from the data rather than archived.
- The tastings are fixed in the application code. Adding or changing tastings is a code change, not a staff feature.
- There is a single staff password shared by all staff; no user accounts or roles.
- The app is served from one server process, and bookings are stored in one local file. There is no requirement for multi-server scaling.
- The data file is `data/bookings.json` by default, and can be changed with the environment variable `DATA_FILE`.
- Payment is not taken online; guests pay at the winery. The total price is shown for information only.
- Visual design follows a small family winery look: warm, calm colours, clear typography, and a logo-free header with the winery name.
