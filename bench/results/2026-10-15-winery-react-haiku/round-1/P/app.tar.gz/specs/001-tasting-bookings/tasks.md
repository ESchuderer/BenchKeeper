# Tasks: Wine Tasting Bookings for Weingut Kieselbrunnen

**Input**: Design documents in `/specs/001-tasting-bookings/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/api.md, quickstart.md

**Test-first rule**: For each user story, the test tasks come first and must be run and seen to fail before the implementation tasks for that story start.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependency on unfinished tasks)
- **[Story]**: US1 (book), US2 (staff view), US3 (staff cancel)

## Phase 1: Setup

- [x] T001 Create `package.json` with the scripts `build` (`vite build && tsc -p tsconfig.server.json`), `start` (`node dist/server/index.js`), `test` (`vitest run`), `typecheck` (`tsc --noEmit -p tsconfig.json`), and the dependencies listed in plan.md
- [x] T002 [P] Create `tsconfig.json` (client, shared and tests; `jsx: react-jsx`; DOM and Node types; `noEmit`) and `tsconfig.server.json` (server and shared; emits to `dist/server`; Node types only)
- [x] T003 [P] Create `vite.config.ts` (React plugin, Tailwind plugin, `build.outDir` = `dist/client`, Vitest block with `environment: node` by default and a jsdom override for client tests) and `index.html`
- [x] T004 [P] Create `.gitignore` entries for `node_modules/`, `dist/`, `data/`
- [x] T005 Run `npm install` and confirm the versions match plan.md; check that `@hookform/resolvers/zod` works with zod 4

## Phase 2: Foundation (blocks all stories)

- [x] T006 Write `tests/server/store.test.ts`: missing file gives no bookings; bookings written in one instance are read by a new instance with the same file; reference is 8 characters from the allowed alphabet and unique; `seatsLeft` counts guests across bookings. Run it: must fail.
- [x] T007 Write `tests/server/bookings.test.ts` covering FR-001 to FR-011 (listing, validation, seats, closed tastings, unknown tasting). Use an app created with `createApp` and a temp data file. Run it: must fail.
- [x] T008 Implement `src/shared/booking.ts`: zod schema for name, email and guests with the limits in the spec (name 1–100, email valid and ≤254, guests integer 1–8); export its inferred type.
- [x] T009 Implement `src/server/tastings.ts`: the three tastings with `startsAt` offset `+01:00`, `priceEur`, `seats`; `statusOf(tasting, seatsLeft, now)`.
- [x] T010 Implement `src/server/store.ts`: load from the data file (missing or malformed → empty), in-memory list, `seatsLeft(tastingId)`, `addBooking` (checks seats and returns a result type, never partially writes), `removeBooking(reference)`, `findBooking`, atomic save.
- [x] T011 Implement `src/server/app.ts` (guest part): `createApp({ dataFile, staffPassword, now })`; JSON body parser with a 10 kB limit; helmet; `GET /api/tastings`; `POST /api/tastings/:tastingId/bookings`; error handler returning JSON.
- [x] T012 Run `tests/server/store.test.ts` and `tests/server/bookings.test.ts`: must pass.

## Phase 3: User Story 1 - Browse tastings and book seats (P1)

- [x] T013 [US1] Write `tests/server/bookings.test.ts` additions: exact-last-seats booking works and the next one is refused; 20 parallel requests for the last seat of a tasting never book more than the seats (SC-002). Run: must fail on the first new case only if it is not yet covered; otherwise pass and record that.
- [x] T014 [P] [US1] Write `tests/client/TastingsPage.test.tsx`: lists titles, date and time, price, "N seats left" (singular for 1); "Fully booked" and no booking link when `seatsLeft` = 0; "Booking closed" for closed. Run: must fail.
- [x] T015 [P] [US1] Write `tests/client/BookingPage.test.tsx`: fields "Name", "Email", "Guests" and button "Book"; empty submit shows errors next to each field; server seat error shows next to "Guests"; successful submit navigates to "Booking confirmed" with tasting, guests, total and reference. Run: must fail.
- [x] T016 [US1] Implement `src/client/api.ts`, `src/client/format.ts` (Europe/Berlin dates, "EUR n", "n seats left" / "1 seat left"), `src/client/index.css` (theme), `src/client/main.tsx`, `src/client/App.tsx` (header with the winery name, routes `/`, `/book/:tastingId`, `/confirmed`, `/staff`).
- [x] T017 [US1] Implement `src/client/pages/TastingsPage.tsx`.
- [x] T018 [US1] Implement `src/client/pages/BookingPage.tsx` (React Hook Form + zod resolver; server errors mapped with `setError`; button disabled while submitting).
- [x] T019 [US1] Implement `src/client/pages/ConfirmationPage.tsx`.
- [x] T020 [US1] Run all US1 tests (server and client): must pass.

## Phase 4: User Story 2 - Staff sign in and see all bookings (P2)

- [x] T021 [US2] Write `tests/server/staff.test.ts`: `GET /api/staff/bookings` without cookie → 401; wrong password → 401 with `password` error; `STAFF_PASSWORD` unset → 503; correct password → 204 with `HttpOnly; SameSite=Strict` cookie; bookings grouped by tasting with name, email, guests, reference; session check endpoint. Run: must fail.
- [x] T022 [P] [US2] Write `tests/client/StaffPage.test.tsx` (sign-in part): "Password" field and "Sign in" button; no booking data before sign-in; wrong password shows an error next to the field. Run: must fail.
- [x] T023 [US2] Implement `src/server/staffSessions.ts` (32-byte tokens, 8-hour expiry, purge on check).
- [x] T024 [US2] Implement in `src/server/app.ts`: `POST /api/staff/session` with timing-safe password comparison and `express-rate-limit` (10 failed per 15 min, `skipSuccessfulRequests`); `GET /api/staff/session`; `GET /api/staff/bookings`; cookie options.
- [x] T025 [US2] Implement `src/client/pages/StaffPage.tsx`: sign-in form; on load checks the session; bookings grouped by tasting with the empty-state note (FR: US2 scenario 4).
- [x] T026 [US2] Run all US2 tests: must pass.

## Phase 5: User Story 3 - Staff cancel a booking (P3)

- [x] T027 [US3] Write `tests/server/staff.test.ts` additions: cancel removes the booking and frees its seats for the guest page at once; unknown reference → 404; cancel without session → 401; `DELETE /api/staff/session` signs out (next request 401); session expires after 8 hours (use injected `now`); 11th wrong password in 15 min → 429. Run: must fail.
- [x] T028 [P] [US3] Write `tests/client/StaffPage.test.tsx` additions: "Cancel" removes the row; "Sign out" returns to the sign-in form. Run: must fail.
- [x] T029 [US3] Implement `DELETE /api/staff/bookings/:reference` and `DELETE /api/staff/session` in `src/server/app.ts`.
- [x] T030 [US3] Implement Cancel and Sign out in `src/client/pages/StaffPage.tsx`.
- [x] T031 [US3] Run all US3 tests: must pass.

## Phase 6: Serving and polish

- [x] T032 Implement `src/server/index.ts`: reads `PORT` (default 3000), `STAFF_PASSWORD`, `DATA_FILE` (default `data/bookings.json`); logs a warning when `STAFF_PASSWORD` is unset; in `app.ts`, serve `dist/client` with SPA fallback for non-`/api` GET requests, and a JSON 404 for unknown `/api` paths.
- [x] T033 Responsive and visual pass: check the four pages at 360 px and 1280 px (no horizontal scroll, touch targets ≥ 44 px, error states visible).
- [x] T034 Run `npm run build`, `npm run typecheck`, `npm test`; start with `npm start` and run the quickstart checks by hand (or with a browser if one can be installed).
- [x] T035 Review: run the review and security review on the branch diff; fix findings that are real; re-run tests.
- [x] T036 Write `README.md` with the quickstart commands (short, pointing to `specs/001-tasting-bookings/quickstart.md`).

## Dependencies

- T001–T005 before everything. T006–T011 before Phase 3 onwards (the store and app are shared).
- US2 depends on the app factory from T011; US3 depends on US2 (it uses the staff session).
- T032 depends on all stories; T034 depends on T032.
