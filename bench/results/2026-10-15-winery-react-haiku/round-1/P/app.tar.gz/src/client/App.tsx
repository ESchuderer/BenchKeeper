import { Link, Navigate, Route, Routes } from 'react-router';
import { BookingPage } from './pages/BookingPage.js';
import { ConfirmationPage } from './pages/ConfirmationPage.js';
import { StaffPage } from './pages/StaffPage.js';
import { TastingsPage } from './pages/TastingsPage.js';

export function App() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b border-line bg-parchment">
        <div className="mx-auto max-w-3xl px-4 py-5 sm:py-6">
          <Link to="/" className="inline-block no-underline">
            <p className="font-serif text-xs tracking-[0.25em] text-muted uppercase">Family winery</p>
            <h1 className="font-serif text-2xl leading-tight text-wine sm:text-3xl">Weingut Kieselbrunnen</h1>
          </Link>
        </div>
      </header>

      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-8 sm:py-10">
        <Routes>
          <Route path="/" element={<TastingsPage />} />
          <Route path="/book/:tastingId" element={<BookingPage />} />
          <Route path="/confirmed" element={<ConfirmationPage />} />
          <Route path="/staff" element={<StaffPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <footer className="border-t border-line px-4 py-6 text-center text-sm text-muted">
        <p>Weingut Kieselbrunnen · Wine tastings</p>
        <Link to="/staff" className="mt-1 inline-block text-wine underline underline-offset-4">
          Staff sign-in
        </Link>
      </footer>
    </div>
  );
}
