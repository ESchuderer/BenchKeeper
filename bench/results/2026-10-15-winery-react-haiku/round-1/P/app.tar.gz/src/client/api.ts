import type { TastingStatus } from '../shared/types.js';

export interface PublicTasting {
  id: string;
  title: string;
  startsAt: string;
  priceEur: number;
  seats: number;
  seatsLeft: number;
  status: TastingStatus;
}

export interface BookingConfirmation {
  reference: string;
  tastingId: string;
  title: string;
  startsAt: string;
  name: string;
  guests: number;
  priceEur: number;
  totalEur: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTasting extends PublicTasting {
  bookings: StaffBooking[];
}

// Error messages keyed by form field ("name", "email", "guests", "password") or "form" for the whole page.
export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly errors: Record<string, string>,
  ) {
    super(`Request failed with status ${status}`);
  }
}

async function call<T>(method: string, url: string, body?: unknown): Promise<T> {
  const response = await fetch(url, {
    method,
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (response.status === 204) return undefined as T;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(response.status, data.errors ?? { form: 'Something went wrong.' });
  return data as T;
}

export const api = {
  tastings: () => call<{ tastings: PublicTasting[] }>('GET', '/api/tastings'),
  book: (tastingId: string, input: { name: string; email: string; guests: number }) =>
    call<{ booking: BookingConfirmation }>('POST', `/api/tastings/${encodeURIComponent(tastingId)}/bookings`, input),
  staffSession: () => call<void>('GET', '/api/staff/session'),
  signIn: (password: string) => call<void>('POST', '/api/staff/session', { password }),
  signOut: () => call<void>('DELETE', '/api/staff/session'),
  staffBookings: () => call<{ tastings: StaffTasting[] }>('GET', '/api/staff/bookings'),
  cancelBooking: (reference: string) => call<void>('DELETE', `/api/staff/bookings/${encodeURIComponent(reference)}`),
};
