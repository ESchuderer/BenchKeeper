// The winery's local time. Fixed here so every guest sees the same clock time.
const START = new Intl.DateTimeFormat('en-GB', {
  weekday: 'short',
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  timeZone: 'Europe/Berlin',
});

export const formatStart = (startsAt: string) => START.format(new Date(startsAt));

export const formatEur = (amount: number) => `EUR ${amount}`;

export const seatsLeftText = (seatsLeft: number) => `${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left`;
