import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Link, useNavigate, useParams } from 'react-router';
import { api, ApiError, type PublicTasting } from '../api.js';
import { formatEur, formatStart, seatsLeftText } from '../format.js';
import { useTastings } from '../useTastings.js';
import { bookingSchema, MAX_GUESTS, type BookingInput } from '../../shared/booking.js';


const CLOSED_MESSAGE: Record<Exclude<PublicTasting['status'], 'open'>, string> = {
  'fully-booked': 'This tasting is fully booked.',
  closed: 'Bookings for this tasting are closed.',
};

export function BookingPage() {
  const { tastingId = '' } = useParams();
  const { tastings, failed } = useTastings();

  if (failed) return <p role="alert" className="card font-medium text-danger">We could not load this tasting.</p>;
  if (!tastings) return <p className="text-muted">Loading…</p>;

  const tasting = tastings.find((t) => t.id === tastingId);
  if (!tasting) {
    return (
      <div className="card">
        <p className="font-medium">This tasting does not exist.</p>
        <Link to="/" className="mt-3 inline-block text-wine underline underline-offset-4">
          Back to all tastings
        </Link>
      </div>
    );
  }

  if (tasting.status !== 'open') {
    return (
      <div className="card">
        <h2 className="font-serif text-2xl text-wine">{tasting.title}</h2>
        <p className="mt-2 font-medium">{CLOSED_MESSAGE[tasting.status]}</p>
        <Link to="/" className="mt-3 inline-block text-wine underline underline-offset-4">
          Back to all tastings
        </Link>
      </div>
    );
  }

  return <BookingForm tasting={tasting} />;
}

function BookingForm({ tasting }: { tasting: PublicTasting }) {
  const navigate = useNavigate();
  const maxGuests = Math.min(MAX_GUESTS, tasting.seatsLeft);
  const {
    register,
    handleSubmit,
    setError,
    clearErrors,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  });

  const guests = watch('guests');
  const total = Number.isInteger(guests) ? guests * tasting.priceEur : undefined;

  async function onSubmit(values: BookingInput) {
    clearErrors('root');
    try {
      const { booking } = await api.book(tasting.id, values);
      navigate('/confirmed', { state: booking });
    } catch (error) {
      if (!(error instanceof ApiError)) {
        setError('root', { message: 'We could not reach the server. Please try again.' });
        return;
      }
      for (const [field, message] of Object.entries(error.errors)) {
        if (field === 'name' || field === 'email' || field === 'guests') setError(field, { message });
        else setError('root', { message });
      }
    }
  }

  return (
    <section className="flex flex-col gap-6">
      <div>
        <p className="text-sm tracking-wide text-muted uppercase">{formatStart(tasting.startsAt)}</p>
        <h2 className="font-serif text-3xl text-wine">{tasting.title}</h2>
        <p className="mt-2 text-muted">
          {formatEur(tasting.priceEur)} per guest · {seatsLeftText(tasting.seatsLeft)}
        </p>
      </div>

      <form noValidate onSubmit={handleSubmit(onSubmit)} className="card flex flex-col gap-5" aria-label="Booking details">
        <div>
          <label htmlFor="name" className="font-medium">
            Name
          </label>
          <input
            id="name"
            type="text"
            autoComplete="name"
            className="input"
            aria-invalid={errors.name ? true : undefined}
            aria-describedby={errors.name ? 'name-error' : undefined}
            {...register('name')}
          />
          {errors.name && (
            <p id="name-error" className="field-error">
              {errors.name.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="email" className="font-medium">
            Email
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            inputMode="email"
            className="input"
            aria-invalid={errors.email ? true : undefined}
            aria-describedby={errors.email ? 'email-error' : undefined}
            {...register('email')}
          />
          {errors.email && (
            <p id="email-error" className="field-error">
              {errors.email.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="guests" className="font-medium">
            Guests
          </label>
          <input
            id="guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={maxGuests}
            step={1}
            className="input max-w-32"
            aria-invalid={errors.guests ? true : undefined}
            aria-describedby={errors.guests ? 'guests-hint guests-error' : 'guests-hint'}
            {...register('guests', { valueAsNumber: true })}
          />
          <p id="guests-hint" className="mt-1 text-sm text-muted">
            {seatsLeftText(tasting.seatsLeft)} · up to {MAX_GUESTS} guests
          </p>
          {errors.guests && (
            <p id="guests-error" className="field-error">
              {errors.guests.message}
            </p>
          )}
        </div>

        <p className="border-t border-line pt-4 text-ink">
          Total: <strong className="font-semibold text-wine">{total === undefined ? '–' : formatEur(total)}</strong>
          {total !== undefined && <span className="text-muted"> for {guests} {guests === 1 ? 'guest' : 'guests'}</span>}
        </p>

        {errors.root && (
          <p role="alert" className="rounded-md bg-danger-soft px-4 py-3 font-medium text-danger">
            {errors.root.message}
          </p>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button type="submit" className="btn" disabled={isSubmitting} aria-busy={isSubmitting || undefined}>
            Book
          </button>
          <Link to="/" className="text-wine underline underline-offset-4">
            Back to all tastings
          </Link>
        </div>
      </form>
    </section>
  );
}
