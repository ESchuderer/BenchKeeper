import { Navigate, useLocation, Link } from 'react-router';
import type { BookingConfirmation } from '../api.js';
import { formatEur, formatStart } from '../format.js';

export function ConfirmationPage() {
  // The booking is passed in the navigation state; without it there is nothing to confirm.
  const booking = useLocation().state as BookingConfirmation | null;
  if (!booking) return <Navigate to="/" replace />;

  return (
    <section className="card flex flex-col gap-6">
      <div>
        <p className="badge bg-success-soft text-success">Thank you</p>
        <h2 className="mt-3 font-serif text-3xl text-wine">Booking confirmed</h2>
        <p className="mt-2 text-muted">We look forward to welcoming you, {booking.name}.</p>
      </div>

      <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-3 border-y border-line py-5">
        <dt className="text-muted">Tasting</dt>
        <dd className="font-medium">{booking.title}</dd>
        <dt className="text-muted">Date and time</dt>
        <dd>{formatStart(booking.startsAt)}</dd>
        <dt className="text-muted">Guests</dt>
        <dd>{booking.guests}</dd>
        <dt className="text-muted">Total</dt>
        <dd className="font-semibold text-wine">{formatEur(booking.totalEur)}</dd>
        <dt className="text-muted">Booking reference</dt>
        <dd className="font-mono text-lg tracking-widest">{booking.reference}</dd>
      </dl>

      <p className="text-sm text-muted">Please keep your booking reference. You can quote it when you arrive.</p>
      <Link to="/" className="btn self-start no-underline">
        Back to all tastings
      </Link>
    </section>
  );
}
