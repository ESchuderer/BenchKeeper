import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { api, ApiError, type StaffBooking, type StaffTasting } from '../api.js';
import { formatStart, seatsLeftText } from '../format.js';

type View = 'checking' | 'signed-out' | 'signed-in';

export function StaffPage() {
  const [view, setView] = useState<View>('checking');
  const [notice, setNotice] = useState<string>();
  const [tastings, setTastings] = useState<StaffTasting[]>([]);
  const [actionError, setActionError] = useState<string>();

  const loadBookings = useCallback(async () => {
    try {
      const data = await api.staffBookings();
      setTastings(data.tastings);
      setView('signed-in');
    } catch (error) {
      setNotice(
        error instanceof ApiError && error.status === 401
          ? 'Your session has ended. Please sign in again.'
          : 'Could not load the bookings. Please try again.',
      );
      setView('signed-out');
    }
  }, []);

  useEffect(() => {
    api.staffSession().then(loadBookings, () => setView('signed-out'));
  }, [loadBookings]);

  if (view === 'checking') return <p className="text-muted">Loading…</p>;
  if (view === 'signed-out') return <SignIn notice={notice} onSignedIn={loadBookings} />;

  async function signOut() {
    await api.signOut().catch(() => undefined);
    setTastings([]);
    setNotice(undefined);
    setView('signed-out');
  }

  async function cancel(tasting: StaffTasting, booking: StaffBooking) {
    const seats = `${booking.guests} ${booking.guests === 1 ? 'seat' : 'seats'}`;
    if (!window.confirm(`Cancel the booking for ${booking.name} (${seats}) on ${tasting.title}?`)) return;
    setActionError(undefined);
    try {
      await api.cancelBooking(booking.reference);
      await loadBookings();
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) return loadBookings();
      setActionError('The booking could not be cancelled. Please try again.');
    }
  }

  return (
    <section className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-serif text-3xl text-wine">Bookings</h2>
        <button type="button" onClick={signOut} className="btn-quiet">
          Sign out
        </button>
      </div>

      {actionError && (
        <p role="alert" className="rounded-md bg-danger-soft px-4 py-3 font-medium text-danger">
          {actionError}
        </p>
      )}

      {tastings.map((tasting) => (
        <section key={tasting.id} aria-label={tasting.title} className="card flex flex-col gap-4">
          <div>
            <h3 className="font-serif text-2xl text-wine">{tasting.title}</h3>
            <p className="text-sm text-muted">
              {formatStart(tasting.startsAt)} · {seatsLeftText(tasting.seatsLeft)}
            </p>
          </div>

          {tasting.bookings.length === 0 ? (
            <p className="text-muted">No bookings yet.</p>
          ) : (
            <ul className="flex flex-col divide-y divide-line">
              {tasting.bookings.map((booking) => (
                <li key={booking.reference} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="font-medium break-words">{booking.name}</p>
                    <p className="text-sm break-all text-muted">{booking.email}</p>
                    <p className="text-sm text-muted">
                      {booking.guests} {booking.guests === 1 ? 'guest' : 'guests'} · Reference{' '}
                      <span className="font-mono tracking-wider text-ink">{booking.reference}</span>
                    </p>
                  </div>
                  <button type="button" onClick={() => cancel(tasting, booking)} className="btn-quiet self-start sm:self-center">
                    Cancel
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}
    </section>
  );
}

function SignIn({ notice, onSignedIn }: { notice?: string; onSignedIn: () => Promise<void> }) {
  const {
    register,
    handleSubmit,
    setError,
    clearErrors,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } });

  async function onSubmit({ password }: { password: string }) {
    clearErrors();
    try {
      await api.signIn(password);
      await onSignedIn();
    } catch (error) {
      if (!(error instanceof ApiError)) {
        setError('root', { message: 'We could not reach the server. Please try again.' });
        return;
      }
      for (const [field, message] of Object.entries(error.errors)) {
        if (field === 'password') setError('password', { message });
        else setError('root', { message });
      }
    }
  }

  return (
    <section className="mx-auto flex max-w-sm flex-col gap-6">
      <div>
        <h2 className="font-serif text-3xl text-wine">Staff sign-in</h2>
        <p className="mt-2 text-muted">Sign in to see and manage tasting bookings.</p>
      </div>

      {notice && <p className="rounded-md bg-cream px-4 py-3 text-ink ring-1 ring-line">{notice}</p>}

      <form noValidate onSubmit={handleSubmit(onSubmit)} className="card flex flex-col gap-5" aria-label="Staff sign-in">
        <div>
          <label htmlFor="password" className="font-medium">
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className="input"
            aria-invalid={errors.password ? true : undefined}
            aria-describedby={errors.password ? 'password-error' : undefined}
            {...register('password', { required: 'Please enter the staff password.' })}
          />
          {errors.password && (
            <p id="password-error" className="field-error">
              {errors.password.message}
            </p>
          )}
        </div>

        {errors.root && (
          <p role="alert" className="rounded-md bg-danger-soft px-4 py-3 font-medium text-danger">
            {errors.root.message}
          </p>
        )}

        <button type="submit" className="btn" disabled={isSubmitting} aria-busy={isSubmitting || undefined}>
          Sign in
        </button>
      </form>
    </section>
  );
}
