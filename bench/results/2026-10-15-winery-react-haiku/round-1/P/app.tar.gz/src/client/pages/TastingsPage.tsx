import { Link } from 'react-router';
import type { PublicTasting } from '../api.js';
import { formatEur, formatStart, seatsLeftText } from '../format.js';
import { useTastings } from '../useTastings.js';

const STATUS_BADGE: Partial<Record<PublicTasting['status'], { label: string; className: string }>> = {
  'fully-booked': { label: 'Fully booked', className: 'bg-danger-soft text-danger' },
  closed: { label: 'Booking closed', className: 'bg-sold/15 text-muted' },
};

function TastingCard({ tasting }: { tasting: PublicTasting }) {
  const badge = STATUS_BADGE[tasting.status];
  return (
    <article aria-label={tasting.title} className="card flex flex-col gap-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <h3 className="font-serif text-2xl text-wine">{tasting.title}</h3>
        {badge && <span className={`badge ${badge.className}`}>{badge.label}</span>}
      </div>
      <p className="text-ink">{formatStart(tasting.startsAt)}</p>
      <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-muted">
        <p>{formatEur(tasting.priceEur)} per guest</p>
        <p>{seatsLeftText(tasting.seatsLeft)}</p>
      </div>
      {tasting.status === 'open' && (
        <Link to={`/book/${tasting.id}`} className="btn mt-1 self-start no-underline">
          Book {tasting.title}
        </Link>
      )}
    </article>
  );
}

export function TastingsPage() {
  const { tastings, failed, reload } = useTastings();

  if (failed) {
    return (
      <div role="alert" className="card">
        <p className="font-medium text-danger">We could not load the tastings.</p>
        <button type="button" onClick={reload} className="btn-quiet mt-4">
          Try again
        </button>
      </div>
    );
  }

  if (!tastings) return <p className="text-muted">Loading tastings…</p>;

  return (
    <section className="flex flex-col gap-6">
      <div>
        <h2 className="font-serif text-3xl text-wine">Upcoming tastings</h2>
        <p className="mt-2 text-muted">Choose a tasting and reserve your seats. Prices are per guest.</p>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        {tastings.map((tasting) => (
          <TastingCard key={tasting.id} tasting={tasting} />
        ))}
      </div>
    </section>
  );
}
