import { useCallback, useEffect, useState } from 'react';
import { api, type PublicTasting } from './api.js';

export function useTastings() {
  const [tastings, setTastings] = useState<PublicTasting[]>();
  const [failed, setFailed] = useState(false);

  const load = useCallback(() => {
    setFailed(false);
    api.tastings().then(
      (data) => setTastings(data.tastings),
      () => setFailed(true),
    );
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { tastings, failed, reload: load };
}
