import { createHash, timingSafeEqual } from 'node:crypto';
import path from 'node:path';
import express, { type NextFunction, type Request, type Response } from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { bookingSchema } from '../shared/booking.js';
import { createStaffSessions, SESSION_HOURS } from './staffSessions.js';
import { createStore, type Booking } from './store.js';
import { findTasting, statusOf, TASTINGS } from './tastings.js';

export interface AppOptions {
  dataFile: string;
  staffPassword?: string;
  now?: () => Date;
  // Set when the app sits behind one reverse proxy, so client IPs and HTTPS come from the proxy headers.
  // Number of proxy hops to trust (1 = one reverse proxy that sets X-Forwarded-For).
  trustProxy?: number | boolean;
  // Folder with the built React app; omitted in tests.
  staticDir?: string;
}

const SESSION_COOKIE = 'staff_session';

type FormErrors = Record<string, string>;

function readCookie(req: Request, name: string): string | undefined {
  for (const part of (req.headers.cookie ?? '').split(';')) {
    const [key, ...value] = part.trim().split('=');
    if (key === name) return value.join('=');
  }
  return undefined;
}

// Hash both sides first so the comparison always takes the same time and lengths match.
function passwordMatches(given: string, expected: string): boolean {
  const digest = (text: string) => createHash('sha256').update(text).digest();
  return timingSafeEqual(digest(given), digest(expected));
}

function seatsLeftMessage(seatsLeft: number): string {
  return `Only ${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left.`;
}

export function createApp({ dataFile, staffPassword, now = () => new Date(), trustProxy = false, staticDir }: AppOptions) {
  const app = express();
  app.set('trust proxy', trustProxy);
  const store = createStore(dataFile, now);
  const sessions = createStaffSessions(now);

  // Guests need no account, so one client could otherwise fill every seat with bogus bookings.
  const bookingLimit = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 60,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => res.status(429).json({ errors: { form: 'Too many bookings. Try again later.' } }),
  });

  const failedSignIn = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 10,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => res.status(429).json({ errors: { form: 'Too many attempts. Try again later.' } }),
  });

  function requireStaff(req: Request, res: Response, next: NextFunction) {
    const token = readCookie(req, SESSION_COOKIE);
    if (token && sessions.isValid(token)) return next();
    res.status(401).json({ errors: { form: 'Please sign in.' } });
  }

  // upgrade-insecure-requests is off: the app is often served over plain HTTP on a local network.
  app.use(
    helmet({
      contentSecurityPolicy: { useDefaults: true, directives: { 'upgrade-insecure-requests': null } },
    }),
  );
  app.use(express.json({ limit: '10kb' }));

  app.use('/api', (req, res, next) => {
    // Staff data must not stay in browser or proxy caches on a shared machine.
    res.set('Cache-Control', 'no-store');
    // SameSite=Strict already blocks cross-site cookies; this also blocks same-site requests from other origins.
    const site = req.get('Sec-Fetch-Site');
    if (req.method !== 'GET' && site && site !== 'same-origin' && site !== 'none') {
      return res.status(403).json({ errors: { form: 'Request refused.' } });
    }
    next();
  });

  app.get('/api/tastings', (_req, res) => {
    const current = now();
    res.json({
      tastings: TASTINGS.map((tasting) => {
        const seatsLeft = tasting.seats - store.guestsBooked(tasting.id);
        return { ...tasting, seatsLeft, status: statusOf(tasting, seatsLeft, current) };
      }),
    });
  });

  app.post('/api/tastings/:tastingId/bookings', bookingLimit, (req: Request<{ tastingId: string }>, res) => {
    const tasting = findTasting(req.params.tastingId);
    if (!tasting) return res.status(404).json({ errors: { form: 'This tasting does not exist.' } });

    const parsed = bookingSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      const errors: FormErrors = {};
      for (const issue of parsed.error.issues) errors[String(issue.path[0] ?? 'form')] ??= issue.message;
      return res.status(400).json({ errors });
    }

    const seatsLeft = tasting.seats - store.guestsBooked(tasting.id);
    if (statusOf(tasting, seatsLeft, now()) === 'closed') {
      return res.status(409).json({ errors: { form: 'Booking closed.' } });
    }

    const result = store.add({ tastingId: tasting.id, ...parsed.data }, tasting.seats);
    if (!result.ok) {
      if (result.seatsLeft === 0) return res.status(409).json({ errors: { form: 'Fully booked.' } });
      return res.status(409).json({ errors: { guests: seatsLeftMessage(result.seatsLeft) } });
    }

    const { booking } = result;
    res.status(201).json({
      booking: {
        reference: booking.reference,
        tastingId: tasting.id,
        title: tasting.title,
        startsAt: tasting.startsAt,
        name: booking.name,
        guests: booking.guests,
        priceEur: tasting.priceEur,
        totalEur: tasting.priceEur * booking.guests,
      },
    });
  });

  app.post('/api/staff/session', failedSignIn, (req, res) => {
    if (!staffPassword) return res.status(503).json({ errors: { form: 'Staff access is not configured.' } });
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!passwordMatches(password, staffPassword)) {
      return res.status(401).json({ errors: { password: 'Incorrect password.' } });
    }
    res.cookie(SESSION_COOKIE, sessions.create(), {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure,
      path: '/',
      maxAge: SESSION_HOURS * 60 * 60 * 1000,
    });
    res.status(204).end();
  });

  app.get('/api/staff/session', requireStaff, (_req, res) => {
    res.status(204).end();
  });

  app.delete('/api/staff/session', (req, res) => {
    const token = readCookie(req, SESSION_COOKIE);
    if (token) sessions.end(token);
    res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: 'strict', secure: req.secure, path: '/' });
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    const bookings = store.list();
    const current = now();
    res.json({
      tastings: TASTINGS.map((tasting) => {
        const seatsLeft = tasting.seats - store.guestsBooked(tasting.id);
        const mine = bookings
          .filter((b: Booking) => b.tastingId === tasting.id)
          .map(({ reference, name, email, guests }) => ({ reference, name, email, guests }));
        return { ...tasting, seatsLeft, status: statusOf(tasting, seatsLeft, current), bookings: mine };
      }),
    });
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req: Request<{ reference: string }>, res) => {
    if (!store.remove(req.params.reference)) {
      return res.status(404).json({ errors: { form: 'Booking not found.' } });
    }
    res.status(204).end();
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ errors: { form: 'Not found.' } });
  });

  if (staticDir) {
    app.use(express.static(staticDir));
    // Client-side routes (for example /staff) all get the single-page app.
    app.use((req, res, next) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') return next();
      // Missing files such as /assets/old.js get a real 404, not HTML.
      if (path.extname(req.path)) return next();
      res.sendFile(path.join(staticDir, 'index.html'));
    });
  }

  app.use((err: Error & { status?: number }, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status ?? 500;
    if (status >= 500) console.error(err);
    res.status(status).json({ errors: { form: status < 500 ? 'Invalid request.' : 'Something went wrong.' } });
  });

  return app;
}
