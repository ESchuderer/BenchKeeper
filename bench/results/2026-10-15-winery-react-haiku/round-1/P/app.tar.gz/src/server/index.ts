import path from 'node:path';
import { createApp } from './app.js';

const port = Number(process.env.PORT ?? 3000);
const staffPassword = process.env.STAFF_PASSWORD || undefined;
const dataFile = process.env.DATA_FILE ?? path.resolve('data/bookings.json');
// One reverse proxy in front: trust only the hop it adds, so clients cannot fake their address.
const trustProxy = process.env.TRUST_PROXY === 'true' ? 1 : false;

if (!staffPassword) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
if (staffPassword && staffPassword.length < 12) console.warn('STAFF_PASSWORD is shorter than 12 characters; use a longer one.');

const app = createApp({
  dataFile,
  staffPassword,
  trustProxy,
  staticDir: path.resolve(import.meta.dirname, '../client'),
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings on http://localhost:${port}`);
});
