import { randomBytes } from 'node:crypto';

export const SESSION_HOURS = 8;

// Sessions are kept in memory, so staff sign in again after a restart.
export function createStaffSessions(now: () => Date) {
  const expiry = new Map<string, number>();

  return {
    create(): string {
      const current = now().getTime();
      for (const [token, expiresAt] of expiry) if (expiresAt <= current) expiry.delete(token);
      const token = randomBytes(32).toString('base64url');
      expiry.set(token, current + SESSION_HOURS * 60 * 60 * 1000);
      return token;
    },
    isValid(token: string): boolean {
      const expiresAt = expiry.get(token);
      if (expiresAt === undefined) return false;
      if (now().getTime() >= expiresAt) {
        expiry.delete(token);
        return false;
      }
      return true;
    },
    end(token: string) {
      expiry.delete(token);
    },
  };
}
