import { randomInt } from 'node:crypto';
import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import path from 'node:path';

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export type AddResult = { ok: true; booking: Booking } | { ok: false; seatsLeft: number };

// No 0, O, 1 or I, so references can be read out over the phone.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function load(dataFile: string): Booking[] {
  if (!existsSync(dataFile)) return [];
  const text = readFileSync(dataFile, 'utf8');
  if (text.trim() === '') return [];
  // Throws on a damaged file: starting empty would let the next save overwrite the bookings.
  const data = JSON.parse(text);
  if (!Array.isArray(data?.bookings)) throw new Error(`${dataFile} has no bookings list`);
  return data.bookings;
}

// Writes the whole list to a new temp file (owner-only), flushes it to disk, then renames it over the old file.
function save(dataFile: string, bookings: Booking[]) {
  mkdirSync(path.dirname(dataFile), { recursive: true });
  const temp = `${dataFile}.tmp`;
  rmSync(temp, { force: true }); // so the mode below applies even if a stale temp file exists
  const fd = openSync(temp, 'w', 0o600);
  try {
    writeFileSync(fd, JSON.stringify({ bookings }, null, 2));
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
  renameSync(temp, dataFile);
  // Flush the directory so the rename itself survives a power cut.
  const dirFd = openSync(path.dirname(dataFile), 'r');
  try {
    fsyncSync(dirFd);
  } finally {
    closeSync(dirFd);
  }
}

// Node runs one request handler at a time, so each check-then-add below is atomic.
export function createStore(dataFile: string, now: () => Date = () => new Date()) {
  let bookings = load(dataFile);

  function newReference(): string {
    let reference: string;
    do {
      reference = Array.from({ length: 8 }, () => REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)]).join('');
    } while (bookings.some((b) => b.reference === reference));
    return reference;
  }

  function guestsBooked(tastingId: string): number {
    return bookings.filter((b) => b.tastingId === tastingId).reduce((sum, b) => sum + b.guests, 0);
  }

  return {
    list: (): Booking[] => bookings,
    guestsBooked,
    add(input: Omit<Booking, 'reference' | 'createdAt'>, seats: number): AddResult {
      const seatsLeft = seats - guestsBooked(input.tastingId);
      if (input.guests > seatsLeft) return { ok: false, seatsLeft };
      const booking: Booking = { ...input, reference: newReference(), createdAt: now().toISOString() };
      // Save before changing memory, so a failed write leaves memory and disk in step.
      const next = [...bookings, booking];
      save(dataFile, next);
      bookings = next;
      return { ok: true, booking };
    },
    remove(reference: string): boolean {
      const remaining = bookings.filter((b) => b.reference !== reference);
      if (remaining.length === bookings.length) return false;
      save(dataFile, remaining);
      bookings = remaining;
      return true;
    },
  };
}

export type Store = ReturnType<typeof createStore>;
