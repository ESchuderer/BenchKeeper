import type { TastingStatus } from '../shared/types.js';

export interface Tasting {
  id: string;
  title: string;
  // Winter time in Germany (+01:00) applies to all three dates.
  startsAt: string;
  priceEur: number;
  seats: number;
}


export const TASTINGS: Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00:00+01:00', priceEur: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00:00+01:00', priceEur: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00:00+01:00', priceEur: 28, seats: 10 },
];

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((tasting) => tasting.id === id);
}

export function statusOf(tasting: Tasting, seatsLeft: number, now: Date): TastingStatus {
  if (now.getTime() >= Date.parse(tasting.startsAt)) return 'closed';
  return seatsLeft === 0 ? 'fully-booked' : 'open';
}
