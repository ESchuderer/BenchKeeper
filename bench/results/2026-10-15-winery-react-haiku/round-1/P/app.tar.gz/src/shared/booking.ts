import { z } from 'zod';

export const MAX_GUESTS = 8;

// Used by the form in the browser and again by the API, so both enforce the same rules.
export const bookingSchema = z.object({
  name: z
    .string({ error: 'Please enter your name.' })
    .trim()
    .min(1, { error: 'Please enter your name.' })
    .max(100, { error: 'Name must be 100 characters or fewer.' }),
  email: z
    .string({ error: 'Please enter your email address.' })
    .trim()
    .min(1, { error: 'Please enter your email address.' })
    .max(254, { error: 'Email must be 254 characters or fewer.' })
    .email({ error: 'Please enter a valid email address.' }),
  guests: z
    .number({ error: 'Please enter the number of guests.' })
    .int({ error: 'Guests must be a whole number.' })
    .min(1, { error: 'Please enter at least 1 guest.' })
    .max(MAX_GUESTS, { error: `You can book for up to ${MAX_GUESTS} guests.` }),
});

export type BookingInput = z.infer<typeof bookingSchema>;
