export type TastingStatus = 'open' | 'fully-booked' | 'closed';
