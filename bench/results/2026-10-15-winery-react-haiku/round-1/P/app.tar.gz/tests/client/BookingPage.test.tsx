// @vitest-environment jsdom
import { cleanup, render, screen, waitFor } from '@testing-library/react';
import { userEvent } from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router';
import { App } from '../../src/client/App.js';
import { mockApi, TASTINGS_BODY } from './helpers.js';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

const TASTINGS = 'GET /api/tastings';
const BOOK = 'POST /api/tastings/riesling-evening/bookings';

function renderBooking(path = '/book/riesling-evening') {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}

async function openForm() {
  renderBooking();
  await screen.findByRole('heading', { name: 'Riesling Evening' });
}

describe('booking form', () => {
  it('has Name, Email and Guests fields and a Book button', async () => {
    mockApi({ [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }) });
    await openForm();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows each error next to the field it concerns and books nothing', async () => {
    const { requests } = mockApi({ [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }) });
    const user = userEvent.setup();
    await openForm();

    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Please enter your name.')).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toHaveAccessibleDescription('Please enter your name.');
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Please enter your email address.');
    expect(screen.getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true');
    expect(requests).not.toContain(BOOK);
  });

  it('rejects an invalid email address', async () => {
    const { requests } = mockApi({ [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }) });
    const user = userEvent.setup();
    await openForm();

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna-at-example');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Please enter a valid email address.')).toBeInTheDocument();
    expect(requests).not.toContain(BOOK);
  });

  it('rejects more than 8 guests next to the Guests field', async () => {
    mockApi({ [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }) });
    const user = userEvent.setup();
    await openForm();

    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('You can book for up to 8 guests.')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/You can book for up to 8 guests\./);
  });

  it('shows the seats-left refusal from the server next to the Guests field', async () => {
    mockApi({
      [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }),
      [BOOK]: () => ({ status: 409, body: { errors: { guests: 'Only 3 seats left.' } } }),
    });
    const user = userEvent.setup();
    await openForm();

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '5');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Only 3 seats left.')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/Only 3 seats left\./);
  });

  it('shows the confirmation with heading, tasting, guests, total and reference', async () => {
    mockApi({
      [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }),
      [BOOK]: () => ({
        status: 201,
        body: {
          booking: {
            reference: 'K7Q3M9XT',
            tastingId: 'riesling-evening',
            title: 'Riesling Evening',
            startsAt: '2026-11-06T18:00:00+01:00',
            name: 'Anna Keller',
            guests: 2,
            priceEur: 25,
            totalEur: 50,
          },
        },
      }),
    });
    const user = userEvent.setup();
    await openForm();

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument();
    expect(screen.getByText('2')).toBeInTheDocument();
    expect(screen.getByText('EUR 50')).toBeInTheDocument();
    expect(screen.getByText('K7Q3M9XT')).toBeInTheDocument();
  });

  it('shows the total for the chosen number of guests while typing', async () => {
    mockApi({ [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }) });
    const user = userEvent.setup();
    await openForm();

    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '3');
    expect(screen.getByText('EUR 75')).toBeInTheDocument();
  });

  it('does not offer the form for a fully booked tasting', async () => {
    mockApi({ [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }) });
    renderBooking('/book/winter-tasting');
    expect(await screen.findByText('This tasting is fully booked.')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });

  it('says so when the tasting does not exist', async () => {
    mockApi({ [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }) });
    renderBooking('/book/wine-tour-2030');
    expect(await screen.findByText('This tasting does not exist.')).toBeInTheDocument();
  });

  it('keeps the entered details when the server refuses the booking', async () => {
    mockApi({
      [TASTINGS]: () => ({ status: 200, body: TASTINGS_BODY }),
      [BOOK]: () => ({ status: 409, body: { errors: { form: 'Fully booked.' } } }),
    });
    const user = userEvent.setup();
    await openForm();
    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Fully booked.');
    await waitFor(() => expect(screen.getByLabelText('Name')).toHaveValue('Anna Keller'));
  });
});
