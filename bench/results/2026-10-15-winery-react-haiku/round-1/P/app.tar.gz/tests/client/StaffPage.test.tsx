// @vitest-environment jsdom
import { cleanup, render, screen, within } from '@testing-library/react';
import { userEvent } from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router';
import { App } from '../../src/client/App.js';
import { mockApi, TASTINGS_BODY } from './helpers.js';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

const SESSION = 'GET /api/staff/session';
const SIGN_IN = 'POST /api/staff/session';
const SIGN_OUT = 'DELETE /api/staff/session';
const BOOKINGS = 'GET /api/staff/bookings';
const CANCEL = 'DELETE /api/staff/bookings/K7Q3M9XT';

const STAFF_BOOKINGS = {
  tastings: TASTINGS_BODY.tastings.map((t) => ({
    ...t,
    bookings: t.id === 'riesling-evening'
      ? [{ reference: 'K7Q3M9XT', name: 'Anna Keller', email: 'anna@example.com', guests: 2 }]
      : [],
  })),
};

function renderStaff() {
  return render(
    <MemoryRouter initialEntries={['/staff']}>
      <App />
    </MemoryRouter>,
  );
}

describe('staff sign-in', () => {
  it('shows a Password field and Sign in button and no booking data before sign-in', async () => {
    mockApi({ [SESSION]: () => ({ status: 401, body: { errors: { form: 'Please sign in.' } } }) });
    renderStaff();
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('Riesling Evening')).not.toBeInTheDocument();
  });

  it('shows a wrong password error next to the Password field', async () => {
    mockApi({
      [SESSION]: () => ({ status: 401, body: { errors: { form: 'Please sign in.' } } }),
      [SIGN_IN]: () => ({ status: 401, body: { errors: { password: 'Incorrect password.' } } }),
    });
    const user = userEvent.setup();
    renderStaff();
    await user.type(await screen.findByLabelText('Password'), 'guess');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByText('Incorrect password.')).toBeInTheDocument();
    expect(screen.getByLabelText('Password')).toHaveAccessibleDescription('Incorrect password.');
    expect(screen.queryByText('Riesling Evening')).not.toBeInTheDocument();
  });

  it('shows bookings grouped by tasting after the correct password', async () => {
    let signedIn = false;
    mockApi({
      [SESSION]: () => (signedIn ? { status: 204 } : { status: 401, body: { errors: { form: 'Please sign in.' } } }),
      [SIGN_IN]: () => {
        signedIn = true;
        return { status: 204 };
      },
      [BOOKINGS]: () => ({ status: 200, body: STAFF_BOOKINGS }),
    });
    const user = userEvent.setup();
    renderStaff();
    await user.type(await screen.findByLabelText('Password'), 'correct-horse');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    const row = within(riesling).getByRole('listitem');
    expect(row).toHaveTextContent('Anna Keller');
    expect(row).toHaveTextContent('anna@example.com');
    expect(row).toHaveTextContent('2');
    expect(row).toHaveTextContent('K7Q3M9XT');
    expect(within(screen.getByRole('region', { name: 'Winter Tasting' })).getByText('No bookings yet.')).toBeInTheDocument();
  });

  it('explains when the bookings cannot be loaded after signing in', async () => {
    let signedIn = false;
    mockApi({
      [SESSION]: () => (signedIn ? { status: 204 } : { status: 401, body: { errors: { form: 'Please sign in.' } } }),
      [SIGN_IN]: () => {
        signedIn = true;
        return { status: 204 };
      },
      [BOOKINGS]: () => ({ status: 500, body: { errors: { form: 'Something went wrong.' } } }),
    });
    const user = userEvent.setup();
    renderStaff();
    await user.type(await screen.findByLabelText('Password'), 'correct-horse');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByText('Could not load the bookings. Please try again.')).toBeInTheDocument();
    expect(screen.getByLabelText('Password')).toBeInTheDocument();
  });

  it('shows the sign-in form again when the session has ended', async () => {
    let signedIn = true;
    mockApi({
      [SESSION]: () => (signedIn ? { status: 204 } : { status: 401, body: { errors: { form: 'Please sign in.' } } }),
      [BOOKINGS]: () => ({ status: 401, body: { errors: { form: 'Please sign in.' } } }),
    });
    signedIn = true;
    renderStaff();
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.getByText('Your session has ended. Please sign in again.')).toBeInTheDocument();
  });
});

describe('staff bookings', () => {
  async function renderSignedIn(extra: Parameters<typeof mockApi>[0] = {}) {
    const state = { bookings: structuredClone(STAFF_BOOKINGS) };
    mockApi({
      [SESSION]: () => ({ status: 204 }),
      [BOOKINGS]: () => ({ status: 200, body: state.bookings }),
      ...extra,
    });
    renderStaff();
    await screen.findByRole('region', { name: 'Riesling Evening' });
    return state;
  }

  it('cancels a booking after confirmation, and the row disappears', async () => {
    const state = await renderSignedIn({
      [CANCEL]: () => {
        state.bookings.tastings[0].bookings = [];
        return { status: 204 };
      },
    });
    const confirm = vi.spyOn(window, 'confirm').mockReturnValue(true);
    const user = userEvent.setup();

    await user.click(screen.getByRole('button', { name: 'Cancel' }));

    expect(confirm).toHaveBeenCalled();
    const riesling = screen.getByRole('region', { name: 'Riesling Evening' });
    expect(await within(riesling).findByText('No bookings yet.')).toBeInTheDocument();
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
  });

  it('returns to sign-in with the session notice when the session expires during a cancel', async () => {
    let expired = false;
    mockApi({
      [SESSION]: () => ({ status: 204 }),
      [BOOKINGS]: () =>
        expired ? { status: 401, body: { errors: { form: 'Please sign in.' } } } : { status: 200, body: STAFF_BOOKINGS },
      [CANCEL]: () => {
        expired = true;
        return { status: 401, body: { errors: { form: 'Please sign in.' } } };
      },
    });
    vi.spyOn(window, 'confirm').mockReturnValue(true);
    const user = userEvent.setup();
    renderStaff();
    await user.click(await screen.findByRole('button', { name: 'Cancel' }));
    expect(await screen.findByText('Your session has ended. Please sign in again.')).toBeInTheDocument();
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
  });

  it('keeps the booking when the staff member does not confirm the cancel', async () => {
    const { fetchMock } = mockApi({
      [SESSION]: () => ({ status: 204 }),
      [BOOKINGS]: () => ({ status: 200, body: STAFF_BOOKINGS }),
    });
    vi.spyOn(window, 'confirm').mockReturnValue(false);
    const user = userEvent.setup();
    renderStaff();
    await user.click(await screen.findByRole('button', { name: 'Cancel' }));
    expect(screen.getByText('anna@example.com')).toBeInTheDocument();
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'DELETE')).toBe(false);
  });

  it('signs out and returns to the sign-in form', async () => {
    mockApi({
      [SESSION]: () => ({ status: 204 }),
      [BOOKINGS]: () => ({ status: 200, body: STAFF_BOOKINGS }),
      [SIGN_OUT]: () => ({ status: 204 }),
    });
    const user = userEvent.setup();
    renderStaff();
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
  });
});
