// @vitest-environment jsdom
import { cleanup, render, screen, within } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router';
import { App } from '../../src/client/App.js';
import { mockApi, TASTINGS_BODY } from './helpers.js';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

function renderStart() {
  return render(
    <MemoryRouter initialEntries={['/']}>
      <App />
    </MemoryRouter>,
  );
}

describe('start page', () => {
  it('lists each tasting with title, date and time, price and seats left', async () => {
    mockApi({ 'GET /api/tastings': () => ({ status: 200, body: TASTINGS_BODY }) });
    renderStart();

    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(riesling).getByText(/6 Nov 2026/)).toBeInTheDocument();
    expect(within(riesling).getByText(/18:00/)).toBeInTheDocument();
    expect(within(riesling).getByText('EUR 25 per guest')).toBeInTheDocument();
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument();
  });

  it('uses the singular for one seat left', async () => {
    mockApi({ 'GET /api/tastings': () => ({ status: 200, body: TASTINGS_BODY }) });
    renderStart();
    const tour = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(tour).getByText('1 seat left')).toBeInTheDocument();
  });

  it('offers a "Book <title>" link for open tastings', async () => {
    mockApi({ 'GET /api/tastings': () => ({ status: 200, body: TASTINGS_BODY }) });
    renderStart();
    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link).toHaveAttribute('href', '/book/riesling-evening');
  });

  it('marks a fully booked tasting and offers no booking link for it', async () => {
    mockApi({ 'GET /api/tastings': () => ({ status: 200, body: TASTINGS_BODY }) });
    renderStart();
    const winter = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText('Fully booked')).toBeInTheDocument();
    expect(within(winter).queryByRole('link')).not.toBeInTheDocument();
  });

  it('marks a tasting whose start has passed as closed', async () => {
    const body = structuredClone(TASTINGS_BODY);
    body.tastings[0].status = 'closed';
    mockApi({ 'GET /api/tastings': () => ({ status: 200, body }) });
    renderStart();
    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(riesling).getByText('Booking closed')).toBeInTheDocument();
    expect(within(riesling).queryByRole('link')).not.toBeInTheDocument();
  });

  it('shows an error with a retry when the tastings cannot be loaded', async () => {
    mockApi({ 'GET /api/tastings': () => ({ status: 500, body: { errors: { form: 'Something went wrong.' } } }) });
    renderStart();
    expect(await screen.findByRole('alert')).toHaveTextContent('We could not load the tastings.');
  });
});
