import { vi } from 'vitest';

type Handler = (init?: RequestInit) => { status: number; body?: unknown };

// Answers each "METHOD /url" request from the given table; any other request fails the test.
export function mockApi(handlers: Record<string, Handler>) {
  const requests: string[] = [];
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    const key = `${init?.method ?? 'GET'} ${url}`;
    requests.push(key);
    const handler = handlers[key];
    if (!handler) throw new Error(`Unexpected request: ${key}`);
    const { status, body } = handler(init);
    return new Response(body === undefined ? null : JSON.stringify(body), {
      status,
      headers: { 'Content-Type': 'application/json' },
    });
  });
  vi.stubGlobal('fetch', fetchMock);
  return { fetchMock, requests };
}

export const TASTINGS_BODY = {
  tastings: [
    {
      id: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00:00+01:00',
      priceEur: 25,
      seats: 12,
      seatsLeft: 12,
      status: 'open',
    },
    {
      id: 'red-wine-cellar-tour',
      title: 'Red Wine Cellar Tour',
      startsAt: '2026-11-14T15:00:00+01:00',
      priceEur: 32,
      seats: 8,
      seatsLeft: 1,
      status: 'open',
    },
    {
      id: 'winter-tasting',
      title: 'Winter Tasting',
      startsAt: '2026-12-05T17:00:00+01:00',
      priceEur: 28,
      seats: 10,
      seatsLeft: 0,
      status: 'fully-booked',
    },
  ],
};
