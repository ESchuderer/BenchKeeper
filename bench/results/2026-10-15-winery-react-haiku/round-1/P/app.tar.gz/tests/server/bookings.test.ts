import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../../src/server/app.js';
import { tempDataFile } from './helpers.js';

const NOW = new Date('2026-10-14T10:00:00Z');
const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function makeApp(now: Date = NOW) {
  return createApp({ dataFile: tempDataFile(), staffPassword: 'correct-horse', now: () => now });
}

function book(app: ReturnType<typeof makeApp>, tastingId: string, body: unknown) {
  return request(app).post(`/api/tastings/${tastingId}/bookings`).send(body as object);
}

async function seatsLeft(app: ReturnType<typeof makeApp>, tastingId: string): Promise<number> {
  const res = await request(app).get('/api/tastings');
  return res.body.tastings.find((t: { id: string }) => t.id === tastingId).seatsLeft;
}

describe('GET /api/tastings', () => {
  it('lists the three tastings with seats left and status', async () => {
    const res = await request(makeApp()).get('/api/tastings');
    expect(res.status).toBe(200);
    expect(res.body.tastings).toEqual([
      {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        startsAt: '2026-11-06T18:00:00+01:00',
        priceEur: 25,
        seats: 12,
        seatsLeft: 12,
        status: 'open',
      },
      {
        id: 'red-wine-cellar-tour',
        title: 'Red Wine Cellar Tour',
        startsAt: '2026-11-14T15:00:00+01:00',
        priceEur: 32,
        seats: 8,
        seatsLeft: 8,
        status: 'open',
      },
      {
        id: 'winter-tasting',
        title: 'Winter Tasting',
        startsAt: '2026-12-05T17:00:00+01:00',
        priceEur: 28,
        seats: 10,
        seatsLeft: 10,
        status: 'open',
      },
    ]);
  });

  it('does not expose guest names or emails', async () => {
    const app = makeApp();
    await book(app, 'riesling-evening', valid);
    const res = await request(app).get('/api/tastings');
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
    expect(JSON.stringify(res.body)).not.toContain('Anna Keller');
  });
});

describe('POST /api/tastings/:tastingId/bookings', () => {
  it('books seats and returns the booking with the total price', async () => {
    const app = makeApp();
    const res = await book(app, 'riesling-evening', valid);
    expect(res.status).toBe(201);
    expect(res.body.booking).toMatchObject({
      tastingId: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00:00+01:00',
      name: 'Anna Keller',
      guests: 2,
      priceEur: 25,
      totalEur: 50,
    });
    expect(res.body.booking.reference).toMatch(/^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/);
    expect(await seatsLeft(app, 'riesling-evening')).toBe(10);
  });

  it('trims the name before saving it', async () => {
    const res = await book(makeApp(), 'winter-tasting', { ...valid, name: '  Anna Keller  ' });
    expect(res.status).toBe(201);
    expect(res.body.booking.name).toBe('Anna Keller');
  });

  it('rejects a missing body with an error for every field', async () => {
    const res = await book(makeApp(), 'winter-tasting', {});
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it('names each missing field when the request has no body', async () => {
    const res = await request(makeApp()).post('/api/tastings/winter-tasting/bookings');
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
    expect(res.body.errors.name).toBe('Please enter your name.');
  });

  it.each([
    ['empty name', { name: '' }, 'name'],
    ['blank name', { name: '   ' }, 'name'],
    ['name over 100 characters', { name: 'A'.repeat(101) }, 'name'],
    ['email without @', { email: 'not-an-email' }, 'email'],
    ['email over 254 characters', { email: `${'a'.repeat(250)}@x.de` }, 'email'],
    ['zero guests', { guests: 0 }, 'guests'],
    ['nine guests', { guests: 9 }, 'guests'],
    ['fractional guests', { guests: 1.5 }, 'guests'],
    ['guests as text', { guests: '2' }, 'guests'],
  ])('rejects %s and names only that field', async (_label, change, field) => {
    const res = await book(makeApp(), 'winter-tasting', { ...valid, ...change });
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors)).toEqual([field]);
    expect(typeof res.body.errors[field]).toBe('string');
  });

  it('refuses more guests than seats left and names the seats left', async () => {
    const app = makeApp();
    await book(app, 'riesling-evening', { ...valid, guests: 8 });
    const res = await book(app, 'riesling-evening', { ...valid, guests: 5 });
    expect(res.status).toBe(409);
    expect(res.body).toEqual({ errors: { guests: 'Only 4 seats left.' } });
    expect(await seatsLeft(app, 'riesling-evening')).toBe(4);
  });

  it('accepts a booking that takes exactly the last seats, then refuses the next one', async () => {
    const app = makeApp();
    await book(app, 'riesling-evening', { ...valid, guests: 8 });
    await book(app, 'riesling-evening', { ...valid, guests: 3 });
    const last = await book(app, 'riesling-evening', { ...valid, guests: 1 });
    expect(last.status).toBe(201);
    const next = await book(app, 'riesling-evening', { ...valid, guests: 1 });
    expect(next.status).toBe(409);
    expect(next.body).toEqual({ errors: { form: 'Fully booked.' } });
  });

  it('uses the singular when one seat is left', async () => {
    const app = makeApp();
    await book(app, 'riesling-evening', { ...valid, guests: 8 });
    await book(app, 'riesling-evening', { ...valid, guests: 3 });
    const res = await book(app, 'riesling-evening', { ...valid, guests: 2 });
    expect(res.body).toEqual({ errors: { guests: 'Only 1 seat left.' } });
  });

  it('never books more seats than exist when many requests arrive at once', async () => {
    const app = makeApp();
    const results = await Promise.all(
      Array.from({ length: 30 }, (_, i) => book(app, 'riesling-evening', { ...valid, name: `Guest ${i}`, guests: 1 })),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(12);
    expect(results.filter((r) => r.status === 409)).toHaveLength(18);
    expect(await seatsLeft(app, 'riesling-evening')).toBe(0);
  });

  it('refuses booking requests from other sites', async () => {
    const app = makeApp();
    const refused = await book(app, 'riesling-evening', valid).set('Sec-Fetch-Site', 'same-site');
    expect(refused.status).toBe(403);
    const allowed = await book(app, 'riesling-evening', valid).set('Sec-Fetch-Site', 'same-origin');
    expect(allowed.status).toBe(201);
  });

  it('limits how many booking requests one client can make in 15 minutes', async () => {
    const app = makeApp();
    for (let i = 0; i < 60; i++) {
      expect((await book(app, 'riesling-evening', { ...valid, guests: 0 })).status).toBe(400);
    }
    const res = await book(app, 'riesling-evening', valid);
    expect(res.status).toBe(429);
    expect(res.body).toEqual({ errors: { form: 'Too many bookings. Try again later.' } });
  });

  it('tells browsers not to cache API responses', async () => {
    const res = await request(makeApp()).get('/api/tastings');
    expect(res.headers['cache-control']).toBe('no-store');
  });

  it('returns 404 for a tasting that does not exist', async () => {
    const res = await book(makeApp(), 'wine-tour-2030', valid);
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ errors: { form: 'This tasting does not exist.' } });
  });

  it('closes a tasting once its start time has passed', async () => {
    const afterStart = new Date('2026-11-06T17:01:00Z');
    const app = makeApp(afterStart);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[0].status).toBe('closed');
    const res = await book(app, 'riesling-evening', valid);
    expect(res.status).toBe(409);
    expect(res.body).toEqual({ errors: { form: 'Booking closed.' } });
  });

  it('keeps a tasting open until the moment it starts', async () => {
    const justBefore = new Date('2026-11-06T16:59:59Z');
    const res = await book(makeApp(justBefore), 'riesling-evening', valid);
    expect(res.status).toBe(201);
  });

  it('reports a fully booked tasting as fully booked in the list', async () => {
    const app = makeApp();
    await book(app, 'winter-tasting', { ...valid, guests: 8 });
    await book(app, 'winter-tasting', { ...valid, guests: 2 });
    const res = await request(app).get('/api/tastings');
    expect(res.body.tastings[2]).toMatchObject({ seatsLeft: 0, status: 'fully-booked' });
  });
});
