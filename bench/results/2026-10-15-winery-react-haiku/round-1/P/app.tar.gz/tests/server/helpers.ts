import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterEach } from 'vitest';

const dirs: string[] = [];

// A fresh data-file path in its own temp directory, removed after each test.
export function tempDataFile(): string {
  const dir = mkdtempSync(path.join(tmpdir(), 'kieselbrunnen-'));
  dirs.push(dir);
  return path.join(dir, 'bookings.json');
}

afterEach(() => {
  for (const dir of dirs.splice(0)) rmSync(dir, { recursive: true, force: true });
});
