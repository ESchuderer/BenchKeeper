import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../../src/server/app.js';
import { tempDataFile } from './helpers.js';

const PASSWORD = 'correct-horse';
const HOUR = 60 * 60 * 1000;
const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function makeApp(options: { staffPassword?: string; clock?: { now: Date } } = {}) {
  const clock = options.clock ?? { now: new Date('2026-10-14T10:00:00Z') };
  const app = createApp({
    dataFile: tempDataFile(),
    staffPassword: 'staffPassword' in options ? options.staffPassword : PASSWORD,
    now: () => clock.now,
  });
  return { app, clock };
}

async function signedIn(app: ReturnType<typeof makeApp>['app']) {
  const agent = request.agent(app);
  const res = await agent.post('/api/staff/session').send({ password: PASSWORD });
  expect(res.status).toBe(204);
  return agent;
}

describe('staff sign-in', () => {
  it('refuses the bookings list without a session', async () => {
    const { app } = makeApp();
    const res = await request(app).get('/api/staff/bookings');
    expect(res.status).toBe(401);
    expect(res.body).toEqual({ errors: { form: 'Please sign in.' } });
  });

  it('refuses a wrong password with an error for the password field', async () => {
    const { app } = makeApp();
    const res = await request(app).post('/api/staff/session').send({ password: 'guess' });
    expect(res.status).toBe(401);
    expect(res.body).toEqual({ errors: { password: 'Incorrect password.' } });
  });

  it('refuses sign-in when STAFF_PASSWORD is not set', async () => {
    const { app } = makeApp({ staffPassword: undefined });
    const res = await request(app).post('/api/staff/session').send({ password: '' });
    expect(res.status).toBe(503);
    expect(res.body).toEqual({ errors: { form: 'Staff access is not configured.' } });
  });

  it('sets an HTTP-only, SameSite=Strict session cookie on correct password', async () => {
    const { app } = makeApp();
    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    expect(res.status).toBe(204);
    const cookie = [res.headers['set-cookie']].flat().find((c) => c?.startsWith('staff_session='));
    expect(cookie).toBeDefined();
    expect(cookie).toMatch(/HttpOnly/);
    expect(cookie).toMatch(/SameSite=Strict/);
    expect(cookie).toMatch(/Path=\//);
    expect(cookie).toMatch(/Max-Age=28800/);
  });

  it('reports whether the browser holds a valid session', async () => {
    const { app } = makeApp();
    expect((await request(app).get('/api/staff/session')).status).toBe(401);
    const agent = await signedIn(app);
    expect((await agent.get('/api/staff/session')).status).toBe(204);
  });

  it('signs out and ends the session', async () => {
    const { app } = makeApp();
    const agent = await signedIn(app);
    expect((await agent.delete('/api/staff/session')).status).toBe(204);
    expect((await agent.get('/api/staff/bookings')).status).toBe(401);
  });

  it('ends the session after 8 hours', async () => {
    const { app, clock } = makeApp();
    const agent = await signedIn(app);
    clock.now = new Date(clock.now.getTime() + 8 * HOUR - 1000);
    expect((await agent.get('/api/staff/bookings')).status).toBe(200);
    clock.now = new Date(clock.now.getTime() + 2000);
    expect((await agent.get('/api/staff/bookings')).status).toBe(401);
  });

  it('counts failed attempts per client address when behind a trusted proxy', async () => {
    const app = createApp({ dataFile: tempDataFile(), staffPassword: PASSWORD, trustProxy: 1 });
    for (let i = 0; i < 10; i++) {
      await request(app).post('/api/staff/session').set('X-Forwarded-For', '203.0.113.7').send({ password: 'guess' });
    }
    expect((await request(app).post('/api/staff/session').set('X-Forwarded-For', '203.0.113.7').send({ password: PASSWORD })).status).toBe(429);
    expect((await request(app).post('/api/staff/session').set('X-Forwarded-For', '198.51.100.2').send({ password: PASSWORD })).status).toBe(204);
  });

  it('blocks sign-in after 10 failed attempts in 15 minutes', async () => {
    const { app } = makeApp();
    for (let i = 0; i < 10; i++) {
      expect((await request(app).post('/api/staff/session').send({ password: 'guess' })).status).toBe(401);
    }
    const blocked = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    expect(blocked.status).toBe(429);
    expect(blocked.body).toEqual({ errors: { form: 'Too many attempts. Try again later.' } });
  });
});

describe('staff bookings', () => {
  it('lists bookings grouped by tasting with name, email, guests and reference', async () => {
    const { app } = makeApp();
    await request(app).post('/api/tastings/riesling-evening/bookings').send(valid);
    const agent = await signedIn(app);
    const res = await agent.get('/api/staff/bookings');
    expect(res.status).toBe(200);
    expect(res.body.tastings).toHaveLength(3);
    const riesling = res.body.tastings[0];
    expect(riesling).toMatchObject({ id: 'riesling-evening', title: 'Riesling Evening', seats: 12, seatsLeft: 10 });
    expect(riesling.bookings).toEqual([
      {
        reference: expect.stringMatching(/^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/),
        name: 'Anna Keller',
        email: 'anna@example.com',
        guests: 2,
      },
    ]);
    expect(res.body.tastings[1].bookings).toEqual([]);
  });

  it('cancels a booking, frees its seats and removes it from the list', async () => {
    const { app } = makeApp();
    const guest = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...valid, guests: 3 });
    const reference = guest.body.booking.reference;
    const agent = await signedIn(app);

    expect((await agent.delete(`/api/staff/bookings/${reference}`)).status).toBe(204);

    const list = await agent.get('/api/staff/bookings');
    expect(list.body.tastings[2].bookings).toEqual([]);
    expect(list.body.tastings[2].seatsLeft).toBe(10);
    const tastings = await request(app).get('/api/tastings');
    expect(tastings.body.tastings[2].seatsLeft).toBe(10);
    const rebookFull = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...valid, guests: 8 });
    const rebookRest = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...valid, guests: 2 });
    expect([rebookFull.status, rebookRest.status]).toEqual([201, 201]);
  });

  it('returns 404 when cancelling an unknown reference', async () => {
    const agent = await signedIn(makeApp().app);
    expect((await agent.delete('/api/staff/bookings/ZZZZZZZZ')).status).toBe(404);
  });

  it('does not cancel without a session', async () => {
    const { app } = makeApp();
    const guest = await request(app).post('/api/tastings/winter-tasting/bookings').send(valid);
    const reference = guest.body.booking.reference;
    expect((await request(app).delete(`/api/staff/bookings/${reference}`)).status).toBe(401);
    const tastings = await request(app).get('/api/tastings');
    expect(tastings.body.tastings[2].seatsLeft).toBe(8);
  });
});
