import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../../src/server/app.js';
import { tempDataFile } from './helpers.js';

function makeApp() {
  const staticDir = mkdtempSync(path.join(tmpdir(), 'kieselbrunnen-static-'));
  writeFileSync(path.join(staticDir, 'index.html'), '<!doctype html><div id="root"></div>');
  return createApp({ dataFile: tempDataFile(), staffPassword: 'x', staticDir });
}

describe('serving the built app', () => {
  it('serves the single-page app for client-side routes such as /staff', async () => {
    const res = await request(makeApp()).get('/staff');
    expect(res.status).toBe(200);
    expect(res.text).toContain('id="root"');
  });

  it('returns a real 404 for a missing asset instead of the app page', async () => {
    const res = await request(makeApp()).get('/assets/old-build.js');
    expect(res.status).toBe(404);
  });

  it('returns JSON 404 for unknown API paths', async () => {
    const res = await request(makeApp()).get('/api/unknown');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
});
