import { existsSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { createStore } from '../../src/server/store.js';
import { tempDataFile } from './helpers.js';

const REFERENCE = /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/;

describe('booking store', () => {
  it('starts with no bookings when the data file does not exist', () => {
    const store = createStore(tempDataFile());
    expect(store.list()).toEqual([]);
    expect(store.guestsBooked('riesling-evening')).toBe(0);
  });

  it('refuses to start on a malformed data file instead of overwriting it', () => {
    const file = tempDataFile();
    writeFileSync(file, '{ not json');
    expect(() => createStore(file)).toThrow();
    expect(readFileSync(file, 'utf8')).toBe('{ not json');
  });

  it('keeps bookings across restarts', () => {
    const file = tempDataFile();
    const first = createStore(file);
    const result = first.add({ tastingId: 'winter-tasting', name: 'Anna', email: 'a@example.com', guests: 2 }, 10);
    expect(result.ok).toBe(true);

    const restarted = createStore(file);
    expect(restarted.list()).toHaveLength(1);
    expect(restarted.guestsBooked('winter-tasting')).toBe(2);
  });

  it('writes the file atomically with no temp file left behind', () => {
    const file = tempDataFile();
    createStore(file).add({ tastingId: 'winter-tasting', name: 'Anna', email: 'a@example.com', guests: 1 }, 10);
    expect(JSON.parse(readFileSync(file, 'utf8')).bookings).toHaveLength(1);
    expect(existsSync(`${file}.tmp`)).toBe(false);
  });

  it('does not keep a booking that could not be saved', () => {
    const blocker = tempDataFile();
    writeFileSync(blocker, 'a file, so the data folder cannot be created');
    const store = createStore(path.join(blocker, 'bookings.json'));
    expect(() => store.add({ tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 1 }, 10)).toThrow();
    expect(store.list()).toEqual([]);
    expect(store.guestsBooked('winter-tasting')).toBe(0);
  });

  it('writes the data file readable by its owner only', () => {
    const file = tempDataFile();
    createStore(file).add({ tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 1 }, 10);
    expect(statSync(file).mode & 0o777).toBe(0o600);
  });

  it('gives each booking a unique reference from the allowed alphabet', () => {
    const store = createStore(tempDataFile());
    const refs = new Set<string>();
    for (let i = 0; i < 200; i++) {
      const result = store.add({ tastingId: 'riesling-evening', name: 'Guest', email: 'g@example.com', guests: 1 }, 1000);
      expect(result.ok).toBe(true);
      if (result.ok) {
        expect(result.booking.reference).toMatch(REFERENCE);
        refs.add(result.booking.reference);
      }
    }
    expect(refs.size).toBe(200);
  });

  it('refuses a booking that would take more seats than are left and writes nothing', () => {
    const store = createStore(tempDataFile());
    expect(store.add({ tastingId: 'red-wine-cellar-tour', name: 'A', email: 'a@example.com', guests: 4 }, 8).ok).toBe(true);
    expect(store.add({ tastingId: 'red-wine-cellar-tour', name: 'B', email: 'b@example.com', guests: 5 }, 8)).toEqual({
      ok: false,
      seatsLeft: 4,
    });
    expect(store.guestsBooked('red-wine-cellar-tour')).toBe(4);
    expect(store.list()).toHaveLength(1);
  });

  it('counts seats per tasting only', () => {
    const store = createStore(tempDataFile());
    store.add({ tastingId: 'riesling-evening', name: 'A', email: 'a@example.com', guests: 3 }, 12);
    store.add({ tastingId: 'winter-tasting', name: 'B', email: 'b@example.com', guests: 5 }, 10);
    expect(store.guestsBooked('riesling-evening')).toBe(3);
    expect(store.guestsBooked('winter-tasting')).toBe(5);
  });

  it('removes a booking by reference and frees its seats', () => {
    const store = createStore(tempDataFile());
    const result = store.add({ tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 3 }, 10);
    if (!result.ok) throw new Error('setup failed');
    expect(store.remove(result.booking.reference)).toBe(true);
    expect(store.remove(result.booking.reference)).toBe(false);
    expect(store.guestsBooked('winter-tasting')).toBe(0);
  });
});
