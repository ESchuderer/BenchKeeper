# Weingut Kieselbrunnen: wine tasting bookings

A small web app for Weingut Kieselbrunnen. Guests book wine tastings online; staff sign in to see every booking grouped by tasting and to cancel bookings.

- **Guests** see the upcoming tastings with the seats left, book a tasting with name, email and number of guests (1 to 8), and get a confirmation with a booking reference.
- **Staff** sign in at `/staff` with the password from `STAFF_PASSWORD`, see the bookings per tasting, and cancel a booking to free its seats.

The interface is React. The server is Express, serving the JSON API and the built app from one process. Bookings are kept in memory and no external services are used.

## Requirements

- Node.js 22

## Run it

```bash
npm install
npm run build
STAFF_PASSWORD=choose-a-password PORT=3000 npm start
```

Open http://localhost:3000 for the tastings and http://localhost:3000/staff for the staff area.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | Port the server listens on. |
| `STAFF_PASSWORD` | none | Password for the staff area. When it is not set, staff sign-in is refused and the staff page says so. |
| `SESSION_SECRET` | random per start | Key that signs the staff session cookie. Set it in production; without it, staff must sign in again after every restart. |
| `SECURE_COOKIES` | `false` | Set to `true` when the app is served over HTTPS, so the session cookie is sent only over HTTPS. |

Startup warnings are printed for missing `STAFF_PASSWORD` or `SESSION_SECRET`.

## Security

- Staff sessions are signed, HttpOnly, SameSite=Strict cookies that expire eight hours after sign-in. The staff password is compared in constant time.
- Sign-in is limited to 10 failed attempts per 15 minutes per client address. The limiter uses the address the server sees; behind a reverse proxy, every client shares the proxy's address unless Express `trust proxy` is configured.
- Guest bookings are not rate limited, so one visitor can hold seats. Review this before opening the app to the public.
- Responses carry a Content-Security-Policy, `X-Frame-Options: DENY` and `X-Content-Type-Options: nosniff`. Staff responses are `Cache-Control: no-store`.
- Set `SECURE_COOKIES=true` and `SESSION_SECRET` when serving over HTTPS.

## Data

- Bookings live in memory. The app starts with no bookings, and a restart clears all of them.
- The three tastings are defined in `src/shared/tastings.ts`. Changing them requires a rebuild and restart.

## Development

```bash
# Use the same PORT for both (default 3000).
npm run dev:server     # API on PORT, restarts on change
npm run dev:client     # Vite dev server on http://localhost:5173, proxies /api to PORT
npm test               # unit, API and component tests (Vitest)
npm run typecheck      # TypeScript, client and server
npm run lint           # ESLint
```

## Layout

```
src/shared/   tastings, validation (zod), seat rules, references, formatting, API types
src/server/   Express app, in-memory booking store, guest and staff routes, config
src/client/   React app: pages, components, API client, Tailwind styles
tests/        server (Supertest) and client (Testing Library) tests
```

## API

| Method and path | Purpose |
|---|---|
| `GET /api/tastings` | Tastings with `seatsLeft`. |
| `POST /api/tastings/:id/bookings` | Create a booking. `400` with field `errors`, `409` when seats are insufficient. |
| `GET /api/bookings/:reference` | Public confirmation (no email address). |
| `GET /api/staff/session`, `POST /api/staff/session`, `DELETE /api/staff/session` | Staff sign-in state, sign-in, sign-out. Sign-in is rate limited to 10 failed attempts per 15 minutes per client. |
| `GET /api/staff/overview` | Bookings per tasting, with email addresses. Requires a staff session. |
| `DELETE /api/staff/bookings/:reference` | Cancel a booking. Requires a staff session. |
