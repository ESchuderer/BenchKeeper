import js from "@eslint/js";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import tseslint from "typescript-eslint";

export default tseslint.config(
  { ignores: ["dist", "node_modules", "coverage"] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    rules: {
      // Express error handlers must declare four parameters, so unused ones are prefixed with "_".
      "@typescript-eslint/no-unused-vars": ["error", { argsIgnorePattern: "^_" }],
    },
  },
  {
    files: ["src/**/*.{ts,tsx}", "tests/**/*.{ts,tsx}"],
    plugins: { "react-hooks": reactHooks },
    rules: reactHooks.configs.recommended.rules,
  },
  {
    files: ["src/client/**/*.{ts,tsx}", "tests/client/**/*.{ts,tsx}", "tests/setup.ts"],
    languageOptions: { globals: globals.browser },
  },
  {
    files: ["src/server/**/*.ts", "src/shared/**/*.ts", "tests/server/**/*.ts", "tests/shared/**/*.ts", "*.config.*", "eslint.config.js"],
    languageOptions: { globals: globals.node },
  },
);
