# Design

## Context

The repository is empty apart from the OpenSpec setup, so there is no existing code to fit into. The app serves a small winery: three fixed tastings, a handful of guests per week, and two audiences (guests, staff). It runs as one Node.js process on `PORT` with no external services. See proposal.md for motivation and specs/ for the requirements.

## Goals / Non-Goals

**Goals:**
- One process serves the React interface and the JSON API, started with `npm start` after `npm run build`.
- Seat limits are enforced on the server, where concurrent requests are serialised.
- Validation rules are written once and used by both the form and the server.
- Use maintained libraries for server, routing, forms, validation, styling, sessions and rate limiting.

**Non-Goals:**
- Server-side rendering, payments, email, editing tastings in the UI, multiple wineries, horizontal scaling.
- Persistence across restarts (bookings start empty on every start, as the brief requires).

## Decisions

**Stack: Vite-built React SPA + Express 5.** The brief asks for React, a server and a build step that stays simple. Vite gives a fast, conventional client build; Express serves the static bundle and the JSON API from one process. Alternative considered: Next.js (App Router). It covers server, routing and forms in one framework, but adds a heavier build, server/client component rules and framework-managed caching that this small app does not need. Rejected for simplicity.

**Routing: React Router.** Client routes are `/`, `/tastings/:tastingId/book`, `/bookings/:reference` and `/staff`. The server returns `index.html` for any non-API GET so deep links work.

**Validation: zod schemas in `src/shared`.** The same schema drives field errors in the form (via react-hook-form with `@hookform/resolvers/zod`) and server validation (`safeParse`). The server result is authoritative; the client never decides whether a booking is accepted. Alternative: separate client and server rules, rejected because they drift.

**Seat rules in the booking store.** The store is an in-memory map keyed by tasting id. Creating a booking checks `guests <= seatsLeft` and inserts in one synchronous step. Node.js runs JavaScript on one thread, so two requests cannot interleave between check and insert. No locks or transactions are needed. Cancelling removes the booking, which frees its seats automatically because seats left is derived from active bookings, not stored.

**Booking store is in memory.** The brief allows memory or a local file and asks for no bookings on start. A file would have to be cleared to meet that, and would add write-ordering concerns. The store is behind a small interface so a file or database store can replace it later without touching routes.

**Catalogue is static code.** The three tastings are a typed constant (`id` slug, title, date, time, price, seats). Editing tastings means editing that file and restarting. Alternative: admin UI for tastings, out of scope.

**Booking references.** Format `KB-XXXXXX` using six characters from an unambiguous alphabet (no 0, O, 1, I or L), generated with `crypto.randomInt`. Uniqueness is checked against all bookings including cancelled ones; the store retries on collision.

**Money and dates.** Prices are whole euros; total = price × guests. Tasting dates and times are stored as plain date and time strings for Europe/Berlin local time and formatted without timezone conversion, so output does not depend on the server's timezone.

**Staff sessions: `cookie-session`.** The signed cookie holds `{ staffUntil }` (epoch milliseconds, sign-in time plus eight hours) with `httpOnly` and `sameSite: "strict"`, eight-hour lifetime. Its signing key comes from `SESSION_SECRET`, or a random per-process key when unset (sessions then end on restart, which is acceptable for a small staff tool). Alternative: a server-side session store, rejected because `express-session`'s MemoryStore is not intended for production and adds state for no benefit here.

**Password check.** Both the submitted password and `STAFF_PASSWORD` are hashed with SHA-256 and compared with `crypto.timingSafeEqual`, so the comparison time does not reveal the password length or prefix. If `STAFF_PASSWORD` is unset, sign-in is refused and the UI says staff sign-in is not configured.

**Rate limiting: `express-rate-limit`** on `POST /api/staff/session`, counting failed attempts only (`skipSuccessfulRequests`), limit 10 per 15 minutes per client IP.

**Styling: Tailwind CSS v4** with a small theme (wine burgundy, cream paper, vine green accents, serif headings from the system Georgia stack so no external font request is made). Mobile-first layout, large tap targets, and error/success/fully-booked states as distinct components.

**API shape.**
- `GET /api/tastings` → tastings with `seatsLeft`.
- `POST /api/tastings/:id/bookings` `{name, email, guests}` → `201 {reference, tasting, guests, total}`; `400 {errors}` for invalid fields; `409 {errors: {guests}}` when seats are insufficient; `404` for an unknown tasting.
- `GET /api/bookings/:reference` → public confirmation fields without the email.
- `GET /api/staff/session` → `200 {signedIn: boolean}`, so the staff page knows on reload whether to show the sign-in form.
- `POST /api/staff/session` `{password}` → `204` (sets cookie); `401` wrong password; `429` rate limited; `503` not configured.
- `DELETE /api/staff/session` → `204`.
- `GET /api/staff/overview` → tastings with their bookings (including email); `401` without session.
- `DELETE /api/staff/bookings/:reference` → `204`; `404` if not found.

Field errors are returned as `errors: { <field>: message }` so the client can place them next to the matching input.

## Risks / Trade-offs

- **Bookings lost on restart** → Documented; the brief allows it. Mitigation: store interface makes persistence a drop-in change.
- **Single process only** → In-memory state and the synchronous seat check assume one server instance. Mitigation: documented; scaling out would need a shared store with transactions.
- **Booking reference acts as a bearer token for the confirmation page** → It reveals tasting, guest count and total, but never the email. References are 6 characters from a 31-character alphabet, drawn with a crypto source; guessing is impractical at this scale, and rate limiting is not applied to this read endpoint, so this is accepted for a small winery. Recorded here as a known trade-off.
- **Session key rotates on restart when `SESSION_SECRET` is unset** → Staff must sign in again after a restart. Mitigation: set `SESSION_SECRET` in production.
- **Plain HTTP on a LAN** → Cookies are not marked `Secure` unless `SECURE_COOKIES=true`, because a `Secure` cookie is not stored over plain HTTP. Mitigation: enable it behind HTTPS.

## Migration Plan

Greenfield: no data or existing users to migrate. Deploy by running `npm install`, `npm run build`, then `STAFF_PASSWORD=... npm start` with `PORT` and `SESSION_SECRET` set. Rollback is stopping the process and starting the previous build; because bookings are in memory, a rollback loses bookings (documented).

## Open Questions

None that change the specs or task breakdown.
