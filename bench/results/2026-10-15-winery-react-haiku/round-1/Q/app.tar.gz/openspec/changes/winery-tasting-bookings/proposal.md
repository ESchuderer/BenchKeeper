# Proposal

## Why

Weingut Kieselbrunnen runs wine tastings but has no online way for guests to book a seat, and staff have no single place to see who is coming. Bookings are currently handled by hand, which makes it easy to overbook a tasting. A small web app lets guests reserve seats for the scheduled tastings and lets staff review and cancel bookings.

## What Changes

- A public start page lists the three upcoming tastings (title, date and time, price per guest, seats left) and marks fully booked tastings.
- Each tasting has a "Book <tasting title>" action that opens a booking form (Name, Email, Guests 1-8).
- A booking is accepted only when the requested guests fit into the seats left. Invalid input is rejected with field-level error messages.
- A booking confirmation page shows "Booking confirmed", the tasting, guest count, total price and booking reference.
- A staff page at `/staff` requires the password from the `STAFF_PASSWORD` environment variable, then shows all bookings grouped by tasting and lets staff cancel a booking, which frees its seats.
- The app is a React single-page interface served by a Node.js server, started with `npm start` on `PORT` (default 3000). Bookings are held in memory; the app starts with no bookings.

No existing capabilities are modified; this change creates the initial specs.

## Capabilities

### New Capabilities

- `tasting-booking`: the public tasting catalogue, seat availability, the guest booking form, booking validation and seat limits, and the booking confirmation.
- `staff-access`: password-protected staff sign-in and sign-out, using the `STAFF_PASSWORD` environment variable.
- `staff-booking-management`: the staff overview of bookings grouped by tasting, and cancellation of bookings that frees seats.

### Modified Capabilities

None.

## Impact

- New code: a Node.js/Express server (JSON API, staff session, in-memory booking store) and a React + Vite client (routing, forms, styling).
- New dependencies: React, React Router, Express, zod (validation shared by client and server), react-hook-form, cookie-session, express-rate-limit, Tailwind CSS, Vite, and test tooling (Vitest, Testing Library, Supertest).
- Configuration: `PORT` (default 3000) and `STAFF_PASSWORD` environment variables; optional `SESSION_SECRET`.
- Out of scope: payments, email notifications, persistence across restarts, editing tastings through the UI, guest accounts, and external services.
