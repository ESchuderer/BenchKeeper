# Spec Delta

## Purpose

Restricts the staff area of Weingut Kieselbrunnen's booking app to people who know the staff password, so that guest details are visible only to staff.

## ADDED Requirements

### Requirement: Staff page requires the password
The page `/staff` SHALL show a "Password" field and a "Sign in" button until the visitor has signed in, and SHALL NOT show any booking information to a visitor who has not signed in.

#### Scenario: Visitor without sign-in
- **WHEN** a visitor opens `/staff` without a valid staff session
- **THEN** the page shows the "Password" field and the "Sign in" button and no bookings

### Requirement: Password is taken from the STAFF_PASSWORD environment variable
The server SHALL check the entered password against the value of the environment variable `STAFF_PASSWORD`. The comparison SHALL be constant-time with respect to the password content.

#### Scenario: Correct password
- **WHEN** the visitor enters the value of `STAFF_PASSWORD` and presses "Sign in"
- **THEN** the visitor is signed in and the bookings overview is shown

#### Scenario: Incorrect password
- **WHEN** the visitor enters a different password and presses "Sign in"
- **THEN** the message "Incorrect password" is shown next to the Password field and the visitor stays signed out

#### Scenario: Variable not configured
- **WHEN** the server starts without `STAFF_PASSWORD` set
- **THEN** no sign-in succeeds and the page shows that staff sign-in is not configured

### Requirement: Staff session persists until sign-out or expiry
A successful sign-in SHALL create a session that stays valid across page reloads until the visitor signs out or eight hours have passed.

#### Scenario: Reload keeps the session
- **WHEN** a signed-in staff member reloads `/staff`
- **THEN** the bookings overview is shown without asking for the password again

#### Scenario: Session expires
- **WHEN** eight hours have passed since sign-in
- **THEN** the page asks for the password again

### Requirement: Staff can sign out
A signed-in staff member SHALL be able to sign out with a "Sign out" button, after which the staff area is hidden again.

#### Scenario: Sign out
- **WHEN** a signed-in staff member activates "Sign out"
- **THEN** the page shows the "Password" field again and the staff session no longer grants access

### Requirement: Staff endpoints reject unauthenticated requests
Every staff-only server endpoint SHALL respond with HTTP 401 when the request has no valid staff session, and SHALL NOT return booking data or change any booking.

#### Scenario: Unauthenticated listing
- **WHEN** a request without a staff session asks for the bookings list
- **THEN** the response status is 401 and the response contains no booking data

### Requirement: Repeated failed sign-ins are limited
The server SHALL refuse further sign-in attempts from the same client with HTTP 429 after 10 failed attempts within 15 minutes.

#### Scenario: Too many failed attempts
- **WHEN** a client makes 11 incorrect sign-in attempts within 15 minutes
- **THEN** the 11th attempt is refused with HTTP 429 and the message asks the visitor to try again later
