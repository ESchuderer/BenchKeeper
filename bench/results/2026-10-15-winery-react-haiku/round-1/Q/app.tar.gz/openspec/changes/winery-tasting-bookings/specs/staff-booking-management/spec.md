# Spec Delta

## Purpose

Lets signed-in staff of Weingut Kieselbrunnen see every booking for each tasting, with guest name, email, number of guests and reference, and cancel a booking when a guest no longer attends.

## ADDED Requirements

### Requirement: Staff see all bookings grouped by tasting
When signed in, staff SHALL see every scheduled tasting with its title, date and time and seats left, followed by the bookings for that tasting showing the guest name, email, number of guests and booking reference.

#### Scenario: Bookings grouped by tasting
- **WHEN** staff are signed in and bookings exist for "Riesling Evening" and "Winter Tasting"
- **THEN** the overview shows a section for each tasting, and each booking appears under the tasting it belongs to with its name, email, guests and reference

#### Scenario: Tasting without bookings
- **WHEN** staff are signed in and "Red Wine Cellar Tour" has no bookings
- **THEN** its section shows "No bookings yet"

### Requirement: Staff can cancel a booking
Each booking in the staff overview SHALL have a "Cancel" button that cancels that booking. A cancelled booking SHALL be removed from the overview and its guests SHALL no longer count against the seats of its tasting.

#### Scenario: Cancelling frees seats
- **WHEN** staff cancel a booking for 3 guests for "Riesling Evening"
- **THEN** the booking disappears from the overview and the start page shows the seats left increased by 3

#### Scenario: Cancelled booking reference is no longer valid
- **WHEN** a guest opens the confirmation page of a cancelled booking
- **THEN** the page shows that no such booking was found

### Requirement: Cancelling an unknown booking is reported
If the booking to cancel no longer exists, the system SHALL report that the booking was not found and SHALL NOT change any other booking.

#### Scenario: Booking already cancelled
- **WHEN** staff try to cancel a booking that was already cancelled in another browser
- **THEN** the message "This booking no longer exists" is shown and the overview refreshes

### Requirement: Staff overview reflects current bookings
The staff overview SHALL show the bookings as they exist at the time it is loaded, including bookings made since the last load, after staff reload the page.

#### Scenario: New booking appears after reload
- **WHEN** a guest books a tasting while staff are signed in and staff reload the overview
- **THEN** the new booking appears under its tasting
