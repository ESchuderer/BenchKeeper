# Spec Delta

## Purpose

Lets guests of Weingut Kieselbrunnen see the scheduled wine tastings with their seat availability and reserve seats online. Guests receive a booking reference that confirms their reservation.

## ADDED Requirements

### Requirement: Start page lists the tastings
The start page SHALL list every scheduled tasting with its title, date and time, price per guest, and the number of seats left, shown as "<n> seats left".

#### Scenario: Tastings are listed with availability
- **WHEN** a guest opens the start page with no bookings made
- **THEN** the page lists "Riesling Evening" (2026-11-06 18:00, EUR 25, 12 seats left), "Red Wine Cellar Tour" (2026-11-14 15:00, EUR 32, 8 seats left) and "Winter Tasting" (2026-12-05 17:00, EUR 28, 10 seats left)

#### Scenario: Seats left reflect bookings
- **WHEN** a booking for 3 guests exists for "Riesling Evening"
- **THEN** the start page shows "9 seats left" for "Riesling Evening"

### Requirement: Fully booked tastings are marked and cannot be booked
A tasting with no seats left SHALL be clearly marked as fully booked, and the start page SHALL NOT offer a booking action for it.

#### Scenario: Last seat taken
- **WHEN** the seats left for a tasting reach 0
- **THEN** the start page shows the tasting as "Fully booked" with no "Book <tasting title>" action

#### Scenario: Direct visit to a fully booked tasting's form
- **WHEN** a guest opens the booking form of a fully booked tasting
- **THEN** the page shows that the tasting is fully booked and the form cannot be submitted

### Requirement: Each tasting has a booking action
Each bookable tasting SHALL have a "Book <tasting title>" link or button that opens the booking form for that tasting.

#### Scenario: Opening the booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for "Riesling Evening" opens

### Requirement: Booking form fields
The booking form SHALL provide the fields labelled "Name", "Email" and "Guests" and a button labelled "Book". The Guests field SHALL accept whole numbers from 1 to 8.

#### Scenario: Form shows its fields
- **WHEN** the booking form is open
- **THEN** it shows a "Name" field, an "Email" field, a "Guests" field and a "Book" button

### Requirement: Invalid input is rejected next to its field
The system SHALL reject a booking with invalid input and show an error message next to the field it concerns. A booking with an empty Name, a malformed Email, or Guests that is not a whole number from 1 to 8 SHALL NOT be created.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty Name
- **THEN** the message "Enter your name" is shown next to the Name field and no booking is created

#### Scenario: Malformed email
- **WHEN** a guest submits an Email value without a valid address format
- **THEN** the message "Enter a valid email address" is shown next to the Email field and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits 0 or 9 as the number of guests
- **THEN** the message "Guests must be between 1 and 8" is shown next to the Guests field and no booking is created

### Requirement: A booking never exceeds the seats left
The system SHALL NOT create a booking whose guests exceed the seats left for that tasting at the time of booking. Seat limits SHALL be enforced by the server, not only by the form.

#### Scenario: More guests than seats left
- **WHEN** a guest books 4 guests for a tasting with 2 seats left
- **THEN** the message "Only 2 seats left" is shown next to the Guests field, no booking is created, and the seats left are unchanged

#### Scenario: Concurrent bookings for the last seats
- **WHEN** two bookings for 2 guests each are submitted for a tasting with 3 seats left and the second is processed after the first
- **THEN** the first booking is created and the second is rejected with a message that the tasting no longer has enough seats

### Requirement: Successful booking shows a confirmation
After a successful booking, the guest SHALL see a confirmation page with the heading "Booking confirmed", the tasting title, the number of guests, the total price (guests multiplied by the price per guest) and a booking reference.

#### Scenario: Booking confirmed
- **WHEN** a guest books 2 guests for "Winter Tasting" (EUR 28 per guest)
- **THEN** the confirmation shows the heading "Booking confirmed", "Winter Tasting", 2 guests, a total of EUR 56, and a booking reference

#### Scenario: Confirmation can be reopened
- **WHEN** a guest opens the confirmation page again with the booking reference
- **THEN** the same tasting, guests, total and reference are shown, and the guest's email address is not shown

#### Scenario: Unknown reference
- **WHEN** a guest opens a confirmation with a reference that does not exist
- **THEN** the page shows that no such booking was found

### Requirement: Booking references are unique
Each booking SHALL receive a booking reference that is unique among all bookings, including cancelled ones, and that a guest can quote to staff.

#### Scenario: References do not repeat
- **WHEN** 100 bookings are created
- **THEN** each booking has a different reference

### Requirement: Usable on phones with clear feedback states
The pages SHALL be usable on a phone-sized screen (360 px wide) without horizontal scrolling, and error, success and fully booked states SHALL be visually distinct from normal content.

#### Scenario: Booking form on a phone
- **WHEN** the booking form is opened on a 360 px wide viewport
- **THEN** all fields, error messages and the "Book" button are visible and reachable without horizontal scrolling
