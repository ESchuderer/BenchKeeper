# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` with Node.js 22 engine, scripts `build`, `start`, `test`, `typecheck`, `lint`, and dependencies (react, react-dom, react-router, express, zod, react-hook-form, @hookform/resolvers, cookie-session, express-rate-limit, tailwindcss, @tailwindcss/vite, vite, @vitejs/plugin-react, typescript, tsx, vitest, jsdom, @testing-library/react, @testing-library/user-event, @testing-library/jest-dom, supertest, eslint, typescript-eslint, eslint-plugin-react-hooks); verify `npm install` completes without errors
- [x] 1.2 Add `tsconfig.json` (client, strict), `tsconfig.server.json` (server, emits to `dist/server`), `vite.config.ts` and `vitest.config.ts`; verify `npm run typecheck` passes on empty sources
- [x] 1.3 Add `.gitignore` entries for `node_modules/` and `dist/`; verify `git status` does not list them

## 2. Shared domain: tastings, validation and seats

- [x] 2.1 Write failing unit tests in `tests/shared/tastings.test.ts` for the catalogue (three tastings with ids, titles, date/time, EUR prices 25/32/28, seats 12/8/10) and `seatsLeft` derived from active bookings; verify the tests fail before implementation
- [x] 2.2 Implement `src/shared/tastings.ts` (catalogue constant and `seatsLeft(tasting, bookings)`); verify the tests from 2.1 pass
- [x] 2.3 Write failing unit tests in `tests/shared/booking-schema.test.ts` for the zod booking schema: empty name rejected with "Enter your name", malformed email rejected with "Enter a valid email address", guests 0, 9, 2.5 and "" all rejected with "Guests must be between 1 and 8", name trimmed, email trimmed; verify they fail
- [x] 2.4 Implement `src/shared/booking-schema.ts`; verify the tests from 2.3 pass
- [x] 2.5 Write failing unit tests in `tests/shared/reference.test.ts` for booking reference format `KB-XXXXXX` from the unambiguous alphabet and uniqueness across 1000 generated values; implement `src/shared/reference.ts`; verify the tests pass
- [x] 2.6 Write failing unit tests for `totalPrice(tasting, guests)` and the formatting helpers (`EUR 56`, date "Fri 6 Nov 2026, 18:00" formatted without timezone shifts); implement them in `src/shared/format.ts`; verify tests pass

## 3. Guest booking API

- [x] 3.1 Write failing Supertest tests in `tests/server/tastings-api.test.ts` for `GET /api/tastings` (three tastings with `seatsLeft` 12/8/10 on a fresh server, with the price and date fields); verify they fail
- [x] 3.2 Implement the in-memory booking store `src/server/booking-store.ts` (create with synchronous seat check, cancel, find by reference, unique reference retry, list by tasting) and the `GET /api/tastings` route; verify the tests from 3.1 pass
- [x] 3.3 Write failing tests for `POST /api/tastings/:id/bookings`: 201 with reference, tasting, guests and total EUR 56 for 2 × EUR 28; 400 with `errors.name`/`errors.email`/`errors.guests` for invalid input; 409 with `errors.guests` "Only 2 seats left" when 4 guests request 2 seats; 404 for unknown tasting; seats left unchanged after a rejected booking; verify they fail
- [x] 3.4 Implement the booking route using the shared schema and store; verify the tests from 3.3 pass
- [x] 3.5 Write failing tests for `GET /api/bookings/:reference` (public fields, no email, 404 for unknown reference) and for a race-style test that two bookings processed in sequence cannot exceed capacity (3 seats: 2 then 2 → second 409); implement; verify tests pass

## 4. Staff access and staff API

- [x] 4.1 Write failing tests in `tests/server/staff-auth.test.ts`: `POST /api/staff/session` returns 204 and a session cookie for the correct password, 401 with "Incorrect password" for a wrong one, 503 when `STAFF_PASSWORD` is unset, `GET /api/staff/session` reflects sign-in state, `DELETE /api/staff/session` ends the session; verify they fail
- [x] 4.2 Implement `src/server/staff-auth.ts` (SHA-256 + `timingSafeEqual` comparison, `cookie-session` with httpOnly, sameSite strict, 8 h max age, `SESSION_SECRET` or random key) and the session routes; verify tests from 4.1 pass
- [x] 4.3 Write failing tests that 11 failed sign-ins within 15 minutes from the same client produce 429 on the 11th, and that successful sign-ins are not counted; implement the rate limiter on the session route; verify tests pass
- [x] 4.4 Write failing tests for `GET /api/staff/overview` (401 without session; with session returns each tasting with its bookings including name, email, guests, reference, and `seatsLeft`) and `DELETE /api/staff/bookings/:reference` (204 frees seats so `GET /api/tastings` shows them; 404 with "This booking no longer exists" for an unknown reference; other bookings unchanged; 401 without session); implement the routes; verify tests pass

## 5. Server entry point and configuration

- [x] 5.1 Write failing tests that the server app serves `index.html` for unknown non-API GET paths (e.g. `/bookings/KB-ABC123`) and returns 404 JSON for unknown `/api` paths; implement static serving and SPA fallback in `src/server/app.ts` and `src/server/index.ts`; verify tests pass
- [x] 5.2 Implement the entry point reading `PORT` (default 3000), `STAFF_PASSWORD`, `SESSION_SECRET`, `SECURE_COOKIES`; log a warning when `STAFF_PASSWORD` is unset; verify `PORT=3111 npm start` listens and `GET /api/tastings` responds
- [x] 5.3 Add `README.md` documenting install, build, start, environment variables and the in-memory limitation; verify each documented command runs as written

## 6. Client foundation

- [x] 6.1 Write failing component tests for the App shell in `tests/client/app.test.tsx`: header with winery name "Weingut Kieselbrunnen", navigation to start page and staff area, and routing for `/`, `/tastings/:id/book`, `/bookings/:reference`, `/staff`; verify they fail
- [x] 6.2 Implement `src/client/main.tsx`, `src/client/App.tsx` (React Router), the typed API client `src/client/api.ts` and base Tailwind theme in `src/client/styles.css`; verify tests pass and `npm run build` produces `dist/client`

## 7. Start page

- [x] 7.1 Write failing tests for the tasting list: title, date and time, EUR price per guest, "<n> seats left" text; "Fully booked" with no booking action for 0 seats; "Book Riesling Evening" link present for available tastings; loading and network-error states; verify they fail
- [x] 7.2 Implement `src/client/pages/StartPage.tsx` and tasting card component; verify tests pass

## 8. Booking form

- [x] 8.1 Write failing tests for the booking page: fields labelled "Name", "Email", "Guests" (1 to 8) and button "Book"; invalid input shows the message next to its field and sends no request; a 409 error appears next to Guests; a valid submission calls the API with trimmed values; the page shows "Fully booked" for a full tasting; verify they fail
- [x] 8.2 Implement `src/client/pages/BookingPage.tsx` using react-hook-form with the shared zod schema and server error mapping; verify tests pass

## 9. Confirmation page

- [x] 9.1 Write failing tests for the confirmation page: heading "Booking confirmed", tasting title, guest count, total price, booking reference; unknown reference shows "No booking found for this reference"; after a booking the app navigates to `/bookings/<reference>`; verify they fail
- [x] 9.2 Implement `src/client/pages/ConfirmationPage.tsx` and the navigation after submit; verify tests pass

## 10. Staff page

- [x] 10.1 Write failing tests for the staff sign-in: "Password" field and "Sign in" button when signed out; "Incorrect password" next to the field; 429 message; not-configured message; after sign-in the overview loads; verify they fail
- [x] 10.2 Implement the sign-in form in `src/client/pages/StaffPage.tsx`; verify tests pass
- [x] 10.3 Write failing tests for the staff overview: bookings grouped under each tasting with name, email, guests and reference; "No bookings yet" for an empty tasting; "Cancel" button removes the booking and updates seats; "This booking no longer exists" message for a stale cancel; "Sign out" returns to sign-in; verify they fail
- [x] 10.4 Implement the staff overview, cancel action and sign-out; verify tests pass

## 11. Visual design, responsiveness and accessibility

- [x] 11.1 Style the pages to a coherent winery look (header, typography, cards, buttons, error/success/fully-booked badges) with mobile-first layout; verify with the component tests still passing and no regressions in `npm test`
- [x] 11.2 Verify with a headless browser at 360 px and 1280 px widths that the booking form has no horizontal scrolling and error messages are visible; record the result (Playwright if a browser can be installed, otherwise documented as not verified). Result: Chromium 156 (Playwright), 360 px and 1280 px, no horizontal overflow, no console errors
- [x] 11.3 Verify labels, focus states and error association (`aria-invalid`, `aria-describedby`) on the booking and sign-in forms with a test

## 12. Integration verification

- [x] 12.1 Run `npm run typecheck`, `npm run lint` and `npm test`; verify all pass with zero failures and no skipped tests
- [x] 12.2 Run `npm run build` then `PORT=3000 STAFF_PASSWORD=... npm start`; verify with HTTP requests end to end: book, see seats drop, reject over-capacity, staff sign-in, cancel, seats restored
- [x] 12.3 Verify the spec scenarios in `openspec/changes/winery-tasting-bookings/specs/` against the running app and record any deviations. Result: 19 requirements and 31 scenarios checked against tests and the browser run; deviations recorded: singular "1 seat left" wording and the concurrency message "Only N seats left"

## Workflow follow-up

- Run a code review (code-review-and-quality) and a security review (security-and-hardening) before archiving.
- Archive the change with `openspec archive` once the review findings are resolved.
