import type {
  BookingConfirmation,
  ErrorResponse,
  StaffTastingOverview,
  TastingSummary,
} from "../shared/api.js";
import type { BookingInput } from "../shared/booking-schema.js";

export type ApiResult<T> =
  | { ok: true; status: number; data: T }
  | { ok: false; status: number; message: string; errors: Record<string, string> };

const NETWORK_MESSAGE = "We could not reach the server. Please try again.";
const GENERIC_MESSAGE = "Something went wrong. Please try again.";

async function request<T>(method: string, path: string, body?: unknown): Promise<ApiResult<T>> {
  let response: Response;
  try {
    response = await fetch(path, {
      method,
      headers: body === undefined ? undefined : { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    return { ok: false, status: 0, message: NETWORK_MESSAGE, errors: {} };
  }

  if (response.status === 204) {
    return { ok: true, status: response.status, data: undefined as T };
  }
  const payload: unknown = await response.json().catch(() => undefined);
  if (response.ok) {
    return { ok: true, status: response.status, data: payload as T };
  }
  const error = (payload ?? {}) as ErrorResponse;
  return {
    ok: false,
    status: response.status,
    message: error.message ?? GENERIC_MESSAGE,
    errors: error.errors ?? {},
  };
}

export const api = {
  listTastings: () => request<TastingSummary[]>("GET", "/api/tastings"),

  createBooking: (tastingId: string, booking: BookingInput) =>
    request<BookingConfirmation>("POST", `/api/tastings/${encodeURIComponent(tastingId)}/bookings`, booking),

  getBooking: (reference: string) =>
    request<BookingConfirmation>("GET", `/api/bookings/${encodeURIComponent(reference)}`),

  getStaffSession: () => request<{ signedIn: boolean }>("GET", "/api/staff/session"),

  signIn: (password: string) => request<void>("POST", "/api/staff/session", { password }),

  signOut: () => request<void>("DELETE", "/api/staff/session"),

  getOverview: () => request<StaffTastingOverview[]>("GET", "/api/staff/overview"),

  cancelBooking: (reference: string) =>
    request<void>("DELETE", `/api/staff/bookings/${encodeURIComponent(reference)}`),
};
