import { useId, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { MAX_GUESTS, bookingSchema, type BookingField, type BookingInput } from "../../shared/booking-schema.js";
import type { TastingSummary } from "../../shared/api.js";
import { api } from "../api.js";
import { FieldError } from "./FieldError.js";
import { fieldClass } from "./fieldClass.js";
import { Notice } from "./Notice.js";

const FIELDS: readonly BookingField[] = ["name", "email", "guests"];

interface BookingFormProps {
  tasting: TastingSummary;
  onBooked: (reference: string) => void;
  /** Called after the server rejects a booking, so the seats shown can be refreshed. */
  onRejected: () => void;
}

export function BookingForm({ tasting, onBooked, onRejected }: BookingFormProps) {
  const formId = useId();
  const [formError, setFormError] = useState<string | null>(null);
  const isFullyBooked = tasting.seatsLeft === 0;

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: "", email: "", guests: 2 },
  });

  const onSubmit = async (values: BookingInput) => {
    setFormError(null);
    const result = await api.createBooking(tasting.id, values);
    if (result.ok) {
      onBooked(result.data.reference);
      return;
    }

    let placed = false;
    for (const field of FIELDS) {
      const message = result.errors[field];
      if (message) {
        setError(field, { type: "server", message });
        placed = true;
      }
    }
    if (!placed) {
      setFormError(result.message);
    }
    if (result.status === 409) {
      onRejected();
    }
  };

  const describedBy = (field: BookingField) => (errors[field] ? `${formId}-${field}-error` : undefined);

  return (
    <form noValidate onSubmit={handleSubmit(onSubmit)} className="rounded-2xl border border-ink/10 bg-paper p-6 shadow-sm sm:p-8">
      <fieldset disabled={isFullyBooked || isSubmitting} className="grid gap-6">
        <legend className="sr-only">Your booking</legend>

        <div>
          <label htmlFor={`${formId}-name`} className="block text-sm font-semibold text-ink">
            Name
          </label>
          <input
            id={`${formId}-name`}
            type="text"
            autoComplete="name"
            className={fieldClass(Boolean(errors.name))}
            aria-invalid={errors.name ? true : undefined}
            aria-describedby={describedBy("name")}
            {...register("name")}
          />
          <FieldError id={`${formId}-name-error`} message={errors.name?.message} />
        </div>

        <div>
          <label htmlFor={`${formId}-email`} className="block text-sm font-semibold text-ink">
            Email
          </label>
          <input
            id={`${formId}-email`}
            type="email"
            inputMode="email"
            autoComplete="email"
            className={fieldClass(Boolean(errors.email))}
            aria-invalid={errors.email ? true : undefined}
            aria-describedby={describedBy("email")}
            {...register("email")}
          />
          <FieldError id={`${formId}-email-error`} message={errors.email?.message} />
        </div>

        <div>
          <label htmlFor={`${formId}-guests`} className="block text-sm font-semibold text-ink">
            Guests
          </label>
          <input
            id={`${formId}-guests`}
            type="number"
            inputMode="numeric"
            min={1}
            max={MAX_GUESTS}
            step={1}
            className={fieldClass(Boolean(errors.guests))}
            aria-invalid={errors.guests ? true : undefined}
            aria-describedby={describedBy("guests")}
            {...register("guests", { valueAsNumber: true })}
          />
          <FieldError id={`${formId}-guests-error`} message={errors.guests?.message} />
        </div>

        {formError && <Notice variant="error">{formError}</Notice>}

        <button
          type="submit"
          className="inline-flex w-full items-center justify-center rounded-full bg-burgundy px-6 py-3.5 text-base font-semibold text-cream transition-colors hover:bg-burgundy-dark disabled:cursor-not-allowed disabled:bg-muted sm:w-auto"
        >
          Book
        </button>
      </fieldset>
    </form>
  );
}
