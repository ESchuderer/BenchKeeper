import type { ReactNode } from "react";
import { Link, NavLink } from "react-router";

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:rounded focus:bg-paper focus:px-3 focus:py-2"
      >
        Skip to content
      </a>
      <header className="bg-burgundy text-cream">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-x-6 gap-y-3 px-4 py-4 sm:px-6">
          <Link to="/" className="font-serif text-xl tracking-wide hover:text-gold-light">
            Weingut Kieselbrunnen
          </Link>
          <nav aria-label="Main">
            <ul className="flex gap-5 text-sm font-medium">
              <li>
                <NavLink to="/" end className={navClass}>
                  Tastings
                </NavLink>
              </li>
              <li>
                <NavLink to="/staff" className={navClass}>
                  Staff
                </NavLink>
              </li>
            </ul>
          </nav>
        </div>
      </header>
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        {children}
      </main>
      <footer className="border-t border-ink/10 bg-paper">
        <div className="mx-auto max-w-5xl px-4 py-6 text-sm text-muted sm:px-6">
          Weingut Kieselbrunnen · Family winery · Wine tastings by reservation
        </div>
      </footer>
    </div>
  );
}

function navClass({ isActive }: { isActive: boolean }): string {
  return `border-b-2 pb-0.5 transition-colors ${isActive ? "border-gold text-cream" : "border-transparent text-cream/80 hover:text-cream"}`;
}
