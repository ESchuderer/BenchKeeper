import type { ReactNode } from "react";

export type NoticeVariant = "error" | "success" | "info";

const STYLES: Record<NoticeVariant, string> = {
  error: "border-danger/40 bg-danger-light text-danger",
  success: "border-vine/30 bg-vine-light text-vine",
  info: "border-ink/15 bg-paper text-ink",
};

/** Errors are announced as alerts; other notices are polite status messages. */
export function Notice({ variant = "info", children }: { variant?: NoticeVariant; children: ReactNode }) {
  return (
    <div
      role={variant === "error" ? "alert" : "status"}
      className={`rounded-xl border px-4 py-3 text-sm leading-relaxed ${STYLES[variant]}`}
    >
      {children}
    </div>
  );
}
