import { useEffect, useState } from "react";
import type { StaffTastingOverview } from "../../shared/api.js";
import { formatSeatsLeft, formatTastingDateTime } from "../../shared/format.js";
import { api } from "../api.js";
import { Notice, type NoticeVariant } from "./Notice.js";

interface StaffOverviewProps {
  onSessionEnded: () => void;
  onSignedOut: () => void;
}

interface FlashNotice {
  variant: NoticeVariant;
  text: string;
}

export function StaffOverview({ onSessionEnded, onSignedOut }: StaffOverviewProps) {
  const [tastings, setTastings] = useState<StaffTastingOverview[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [flash, setFlash] = useState<FlashNotice | null>(null);
  const [pendingReference, setPendingReference] = useState<string | null>(null);
  const [reloadCount, setReloadCount] = useState(0);

  useEffect(() => {
    let active = true;
    api.getOverview().then((result) => {
      if (!active) return;
      if (result.ok) {
        setTastings(result.data);
        setLoadError(null);
      } else if (result.status === 401) {
        onSessionEnded();
      } else {
        setLoadError(result.message);
      }
    });
    return () => {
      active = false;
    };
  }, [reloadCount, onSessionEnded]);

  const cancelBooking = async (reference: string) => {
    setPendingReference(reference);
    setFlash(null);
    const result = await api.cancelBooking(reference);
    setPendingReference(null);

    if (result.ok) {
      setFlash({ variant: "success", text: `Booking ${reference} cancelled. Its seats are free again.` });
    } else if (result.status === 401) {
      onSessionEnded();
      return;
    } else {
      setFlash({ variant: "error", text: result.message });
    }
    setReloadCount((count) => count + 1);
  };

  const signOut = async () => {
    const result = await api.signOut();
    // A 401 means the session already ended, so the staff area is closed either way.
    if (result.ok || result.status === 401) {
      onSignedOut();
      return;
    }
    setFlash({ variant: "error", text: result.message });
  };

  return (
    <div className="grid gap-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="text-ink/80">Signed in. Guest email addresses are visible only in this area.</p>
        <button
          type="button"
          onClick={signOut}
          className="rounded-full border border-burgundy px-5 py-2 text-sm font-semibold text-burgundy transition-colors hover:bg-burgundy hover:text-cream"
        >
          Sign out
        </button>
      </div>

      {flash && (
        <Notice variant={flash.variant}>{flash.text}</Notice>
      )}
      {loadError && <Notice variant="error">{loadError}</Notice>}
      {tastings === null && !loadError && <p role="status" className="text-muted">Loading bookings…</p>}

      {tastings?.map((tasting) => {
        const headingId = `staff-tasting-${tasting.id}`;
        return (
          <section
            key={tasting.id}
            aria-labelledby={headingId}
            className="rounded-2xl border border-ink/10 bg-paper p-6 shadow-sm"
          >
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 id={headingId} className="text-2xl text-burgundy">
                {tasting.title}
              </h2>
              <p className="text-sm font-semibold text-vine">{formatSeatsLeft(tasting.seatsLeft)}</p>
            </div>
            <p className="mt-1 text-sm text-muted">{formatTastingDateTime(tasting.date, tasting.time)}</p>

            {tasting.bookings.length === 0 ? (
              <p className="mt-6 border-t border-ink/10 pt-6 text-muted">No bookings yet</p>
            ) : (
              <ul aria-label={`Bookings for ${tasting.title}`} className="mt-4 divide-y divide-ink/10 border-t border-ink/10">
                {tasting.bookings.map((booking) => (
                  <li
                    key={booking.reference}
                    className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between sm:gap-6"
                  >
                    <div className="min-w-0">
                      <p className="font-semibold text-ink">{booking.name}</p>
                      <p className="text-sm break-all text-muted">{booking.email}</p>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-5 gap-y-2 sm:justify-end">
                      <span className="text-sm text-ink/80">
                        {booking.guests === 1 ? "1 guest" : `${booking.guests} guests`}
                      </span>
                      <span className="font-mono text-sm tracking-wide text-ink/80">{booking.reference}</span>
                      <button
                        type="button"
                        disabled={pendingReference === booking.reference}
                        onClick={() => cancelBooking(booking.reference)}
                        className="rounded-full border border-danger/50 px-4 py-1.5 text-sm font-semibold text-danger transition-colors hover:bg-danger-light disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        Cancel
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        );
      })}
    </div>
  );
}
