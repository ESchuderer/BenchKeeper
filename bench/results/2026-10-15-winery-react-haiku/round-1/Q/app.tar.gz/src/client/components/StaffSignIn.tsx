import { useId, useState } from "react";
import { useForm } from "react-hook-form";
import { api } from "../api.js";
import { FieldError } from "./FieldError.js";
import { fieldClass } from "./fieldClass.js";
import { Notice } from "./Notice.js";

interface StaffSignInProps {
  onSignedIn: () => void;
  /** Explains why the visitor is asked to sign in again, for example after a session ended. */
  notice?: string;
}

interface SignInValues {
  password: string;
}

export function StaffSignIn({ onSignedIn, notice }: StaffSignInProps) {
  const fieldId = useId();
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<SignInValues>({ defaultValues: { password: "" } });

  const onSubmit = async ({ password }: SignInValues) => {
    setFormError(null);
    const result = await api.signIn(password);
    if (result.ok) {
      onSignedIn();
      return;
    }
    if (result.errors.password) {
      setError("password", { type: "server", message: result.errors.password });
      return;
    }
    setFormError(result.message);
  };

  return (
    <div className="mx-auto max-w-md">
      <p className="text-ink/80">Staff sign-in is required to see guest bookings.</p>
      {notice && (
        <div className="mt-6">
          <Notice>{notice}</Notice>
        </div>
      )}
      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="mt-6 grid gap-6 rounded-2xl border border-ink/10 bg-paper p-6 shadow-sm sm:p-8"
      >
        <div>
          <label htmlFor={`${fieldId}-password`} className="block text-sm font-semibold text-ink">
            Password
          </label>
          <input
            id={`${fieldId}-password`}
            type="password"
            autoComplete="current-password"
            aria-invalid={errors.password ? true : undefined}
            aria-describedby={errors.password ? `${fieldId}-password-error` : undefined}
            className={fieldClass(Boolean(errors.password))}
            {...register("password", { required: "Enter the password" })}
          />
          <FieldError id={`${fieldId}-password-error`} message={errors.password?.message} />
        </div>

        {formError && <Notice variant="error">{formError}</Notice>}

        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex w-full items-center justify-center rounded-full bg-burgundy px-6 py-3.5 text-base font-semibold text-cream transition-colors hover:bg-burgundy-dark disabled:cursor-not-allowed disabled:opacity-60"
        >
          Sign in
        </button>
      </form>
    </div>
  );
}
