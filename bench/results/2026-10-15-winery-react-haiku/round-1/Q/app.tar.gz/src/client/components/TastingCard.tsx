import { Link } from "react-router";
import type { TastingSummary } from "../../shared/api.js";
import { formatEuro, formatSeatsLeft, formatTastingDateTime } from "../../shared/format.js";

export function TastingCard({ tasting }: { tasting: TastingSummary }) {
  const isFullyBooked = tasting.seatsLeft === 0;
  const headingId = `tasting-${tasting.id}`;

  return (
    <article
      aria-labelledby={headingId}
      className="flex flex-col rounded-2xl border border-ink/10 bg-paper p-6 shadow-sm"
    >
      <div className="flex items-start justify-between gap-3">
        <h2 id={headingId} className="text-2xl leading-tight text-burgundy">
          {tasting.title}
        </h2>
        {isFullyBooked ? (
          <span className="shrink-0 rounded-full bg-danger-light px-3 py-1 text-xs font-semibold tracking-wide text-danger uppercase">
            Fully booked
          </span>
        ) : (
          <span className="shrink-0 rounded-full bg-vine-light px-3 py-1 text-xs font-semibold text-vine">
            {formatSeatsLeft(tasting.seatsLeft)}
          </span>
        )}
      </div>

      <dl className="mt-4 grid gap-2 text-sm text-ink/80">
        <div className="flex gap-2">
          <dt className="sr-only">Date and time</dt>
          <dd>
            <time dateTime={`${tasting.date}T${tasting.time}`}>
              {formatTastingDateTime(tasting.date, tasting.time)}
            </time>
          </dd>
        </div>
        <div className="flex gap-2">
          <dt className="sr-only">Price</dt>
          <dd className="font-medium text-ink">{`${formatEuro(tasting.pricePerGuest)} per guest`}</dd>
        </div>
      </dl>

      <div className="mt-6">
        {isFullyBooked ? (
          <p className="text-sm text-muted">No seats are available for this tasting.</p>
        ) : (
          <Link
            to={`/tastings/${tasting.id}/book`}
            aria-label={`Book ${tasting.title}`}
            className="inline-flex w-full items-center justify-center rounded-full bg-burgundy px-5 py-3 font-medium text-cream transition-colors hover:bg-burgundy-dark sm:w-auto"
          >
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
