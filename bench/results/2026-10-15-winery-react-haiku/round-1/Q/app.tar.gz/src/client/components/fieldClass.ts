export function fieldClass(hasError: boolean): string {
  return [
    "mt-2 w-full rounded-xl border bg-cream/40 px-4 py-3 text-base text-ink shadow-inner outline-none transition-colors",
    "focus:border-gold focus:bg-paper disabled:cursor-not-allowed disabled:opacity-60",
    hasError ? "border-danger" : "border-ink/20",
  ].join(" ");
}
