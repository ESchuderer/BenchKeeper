import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router";
import type { TastingSummary } from "../../shared/api.js";
import { formatEuro, formatSeatsLeft, formatTastingDateTime } from "../../shared/format.js";
import { api } from "../api.js";
import { BookingForm } from "../components/BookingForm.js";
import { Notice } from "../components/Notice.js";

type LoadState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "missing" }
  | { status: "ready"; tasting: TastingSummary };

export function BookingPage() {
  const { tastingId = "" } = useParams();
  const navigate = useNavigate();
  const [state, setState] = useState<LoadState>({ status: "loading" });
  const [reloadCount, setReloadCount] = useState(0);

  useEffect(() => {
    let active = true;
    api.listTastings().then((result) => {
      if (!active) return;
      if (!result.ok) {
        setState({ status: "error", message: result.message });
        return;
      }
      const tasting = result.data.find((candidate) => candidate.id === tastingId);
      setState(tasting ? { status: "ready", tasting } : { status: "missing" });
    });
    return () => {
      active = false;
    };
  }, [tastingId, reloadCount]);

  if (state.status === "loading") {
    return <p role="status" className="text-muted">Loading tasting…</p>;
  }

  if (state.status === "error") {
    return <Notice variant="error">{state.message}</Notice>;
  }

  if (state.status === "missing") {
    return (
      <section className="mx-auto max-w-xl text-center">
        <h1 className="font-serif text-3xl text-burgundy">Tasting not found</h1>
        <p className="mt-3 text-muted">This tasting is not on our programme.</p>
        <Link to="/" className="mt-6 inline-block font-medium text-burgundy underline underline-offset-4">
          Back to the tastings
        </Link>
      </section>
    );
  }

  const { tasting } = state;
  const isFullyBooked = tasting.seatsLeft === 0;

  return (
    <section aria-labelledby="booking-title" className="mx-auto max-w-2xl">
      <Link to="/" className="text-sm font-medium text-burgundy underline underline-offset-4">
        ← All tastings
      </Link>

      <header className="mt-6">
        <h1 id="booking-title" className="text-4xl leading-tight text-burgundy sm:text-5xl">
          {tasting.title}
        </h1>
        <dl className="mt-4 flex flex-wrap gap-x-6 gap-y-2 text-base text-ink/80">
          <div>
            <dt className="sr-only">Date and time</dt>
            <dd>{formatTastingDateTime(tasting.date, tasting.time)}</dd>
          </div>
          <div>
            <dt className="sr-only">Price</dt>
            <dd>{`${formatEuro(tasting.pricePerGuest)} per guest`}</dd>
          </div>
          <div>
            <dt className="sr-only">Availability</dt>
            <dd className={isFullyBooked ? "font-semibold text-danger" : "font-semibold text-vine"}>
              {isFullyBooked ? "Fully booked" : formatSeatsLeft(tasting.seatsLeft)}
            </dd>
          </div>
        </dl>
      </header>

      <div className="mt-8">
        {isFullyBooked && (
          <div className="mb-6">
            <Notice variant="error">
              This tasting is fully booked. Choose another tasting or check back later.
            </Notice>
          </div>
        )}
        <BookingForm
          tasting={tasting}
          onBooked={(reference) => navigate(`/bookings/${encodeURIComponent(reference)}`)}
          onRejected={() => setReloadCount((count) => count + 1)}
        />
      </div>
    </section>
  );
}
