import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import type { BookingConfirmation } from "../../shared/api.js";
import { formatEuro, formatTastingDateTime } from "../../shared/format.js";
import { api } from "../api.js";
import { Notice } from "../components/Notice.js";

type LoadState =
  | { status: "loading" }
  | { status: "missing" }
  | { status: "error"; message: string }
  | { status: "ready"; booking: BookingConfirmation };

export function ConfirmationPage() {
  const { reference = "" } = useParams();
  const [state, setState] = useState<LoadState>({ status: "loading" });

  useEffect(() => {
    let active = true;
    api.getBooking(reference).then((result) => {
      if (!active) return;
      if (result.ok) {
        setState({ status: "ready", booking: result.data });
      } else if (result.status === 404) {
        setState({ status: "missing" });
      } else {
        setState({ status: "error", message: result.message });
      }
    });
    return () => {
      active = false;
    };
  }, [reference]);

  if (state.status === "loading") {
    return <p role="status" className="text-muted">Loading your booking…</p>;
  }

  if (state.status === "missing") {
    return (
      <section className="mx-auto max-w-xl text-center">
        <h1 className="font-serif text-3xl text-burgundy">Booking not found</h1>
        <p className="mt-3 text-muted">No booking found for this reference.</p>
        <Link to="/" className="mt-6 inline-block font-medium text-burgundy underline underline-offset-4">
          Back to the tastings
        </Link>
      </section>
    );
  }

  if (state.status === "error") {
    return <Notice variant="error">{state.message}</Notice>;
  }

  const { booking } = state;
  const rows = [
    { label: "Tasting", value: booking.tasting.title },
    { label: "Date and time", value: formatTastingDateTime(booking.tasting.date, booking.tasting.time) },
    { label: "Guests", value: booking.guests === 1 ? "1 guest" : `${booking.guests} guests` },
    { label: "Total", value: formatEuro(booking.total) },
    { label: "Booking reference", value: booking.reference },
  ];

  return (
    <section aria-labelledby="confirmation-title" className="mx-auto max-w-2xl">
      <div className="rounded-2xl border border-vine/25 bg-paper p-6 shadow-sm sm:p-8">
        <p className="text-sm font-semibold tracking-widest text-vine uppercase">Reservation received</p>
        <h1 id="confirmation-title" className="mt-2 text-4xl leading-tight text-burgundy sm:text-5xl">
          Booking confirmed
        </h1>
        <p className="mt-4 text-ink/80">
          Thank you. We look forward to welcoming you. Please quote your booking reference when you arrive.
        </p>

        <ul aria-label="Booking details" className="mt-8 divide-y divide-ink/10 border-y border-ink/10">
          {rows.map((row) => (
            <li key={row.label} className="flex flex-col gap-1 py-4 sm:flex-row sm:items-baseline sm:justify-between">
              <span className="text-sm text-muted">{row.label}</span>
              <span className="font-semibold text-ink sm:text-right">{row.value}</span>
            </li>
          ))}
        </ul>
      </div>

      <p className="mt-6 text-center">
        <Link to="/" className="font-medium text-burgundy underline underline-offset-4">
          Back to the tastings
        </Link>
      </p>
    </section>
  );
}
