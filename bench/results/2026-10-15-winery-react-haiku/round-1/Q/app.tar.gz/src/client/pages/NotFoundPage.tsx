import { Link } from "react-router";

export function NotFoundPage() {
  return (
    <section className="mx-auto max-w-xl text-center">
      <h1 className="font-serif text-3xl text-burgundy">Page not found</h1>
      <p className="mt-3 text-muted">The page you are looking for does not exist.</p>
      <Link to="/" className="mt-6 inline-block font-medium text-burgundy underline underline-offset-4">
        Back to the tastings
      </Link>
    </section>
  );
}
