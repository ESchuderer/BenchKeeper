import { useCallback, useEffect, useState } from "react";
import { api } from "../api.js";
import { StaffOverview } from "../components/StaffOverview.js";
import { StaffSignIn } from "../components/StaffSignIn.js";

type View =
  | { status: "checking" }
  | { status: "signed-out"; notice?: string }
  | { status: "signed-in" };

const SESSION_ENDED = "Your staff session has ended. Sign in again.";

export function StaffPage() {
  const [view, setView] = useState<View>({ status: "checking" });

  useEffect(() => {
    let active = true;
    api.getStaffSession().then((result) => {
      if (!active) return;
      setView(result.ok && result.data.signedIn ? { status: "signed-in" } : { status: "signed-out" });
    });
    return () => {
      active = false;
    };
  }, []);

  const showSignIn = useCallback(() => setView({ status: "signed-out" }), []);
  const sessionEnded = useCallback(() => setView({ status: "signed-out", notice: SESSION_ENDED }), []);
  const signedIn = useCallback(() => setView({ status: "signed-in" }), []);

  return (
    <section aria-labelledby="staff-title" className="grid gap-8">
      <div>
        <p className="text-sm font-semibold tracking-widest text-gold uppercase">Staff only</p>
        <h1 id="staff-title" className="mt-2 text-4xl text-burgundy sm:text-5xl">
          Staff area
        </h1>
      </div>

      {view.status === "checking" && <p role="status" className="text-muted">Checking your sign-in…</p>}
      {view.status === "signed-out" && <StaffSignIn onSignedIn={signedIn} notice={view.notice} />}
      {view.status === "signed-in" && (
        <StaffOverview onSessionEnded={sessionEnded} onSignedOut={showSignIn} />
      )}
    </section>
  );
}
