import { useEffect, useState } from "react";
import type { TastingSummary } from "../../shared/api.js";
import { api } from "../api.js";
import { Notice } from "../components/Notice.js";
import { TastingCard } from "../components/TastingCard.js";

type TastingsState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; tastings: TastingSummary[] };

export function StartPage() {
  const [state, setState] = useState<TastingsState>({ status: "loading" });

  useEffect(() => {
    let active = true;
    api.listTastings().then((result) => {
      if (!active) return;
      setState(
        result.ok
          ? { status: "ready", tastings: result.data }
          : { status: "error", message: result.message },
      );
    });
    return () => {
      active = false;
    };
  }, []);

  return (
    <section aria-labelledby="page-title">
      <div className="max-w-2xl">
        <p className="text-sm font-semibold tracking-widest text-gold uppercase">Wine tastings by reservation</p>
        <h1 id="page-title" className="mt-2 text-4xl leading-tight text-burgundy sm:text-5xl">
          Upcoming tastings
        </h1>
        <p className="mt-4 text-lg text-ink/80">
          Pour, taste and talk with the people who make our wines. Choose a tasting and reserve your seats.
        </p>
      </div>

      <div className="mt-10">
        {state.status === "loading" && <p role="status" className="text-muted">Loading tastings…</p>}
        {state.status === "error" && <Notice variant="error">{state.message}</Notice>}
        {state.status === "ready" && (
          <ul className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {state.tastings.map((tasting) => (
              <li key={tasting.id}>
                <TastingCard tasting={tasting} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
