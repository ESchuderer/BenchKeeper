import path from "node:path";
import express, { type ErrorRequestHandler } from "express";
import helmet from "helmet";
import type { BookingStore } from "./booking-store.js";
import { createGuestRouter } from "./routes/guest.js";
import { createStaffRouter } from "./routes/staff.js";

export interface AppOptions {
  store: BookingStore;
  staffPassword: string | undefined;
  sessionSecret: string;
  secureCookies?: boolean;
  /** Directory with the built client; when set, non-API GET requests return the client app. */
  clientDir?: string;
}

export function createApp(options: AppOptions): express.Express {
  const app = express();
  app.disable("x-powered-by");
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        // Plain-HTTP deployments on a local network must keep working, so do not force HTTPS for subresources.
        directives: { "upgrade-insecure-requests": null },
      },
      frameguard: { action: "deny" },
    }),
  );
  app.use(express.json({ limit: "10kb" }));

  app.use("/api/staff", createStaffRouter({
    store: options.store,
    staffPassword: options.staffPassword,
    sessionSecret: options.sessionSecret,
    secureCookies: options.secureCookies ?? false,
  }));
  app.use("/api", createGuestRouter(options.store));
  app.use("/api", (_request, response) => {
    response.status(404).json({ message: "Not found" });
  });

  if (options.clientDir) {
    const indexFile = path.join(options.clientDir, "index.html");
    app.use(express.static(options.clientDir));
    // Client-side routes (for example /bookings/<reference> or /staff) return the app shell.
    app.get("/{*splat}", (_request, response) => {
      response.sendFile(indexFile);
    });
  }

  app.use(jsonErrorHandler);
  return app;
}

const jsonErrorHandler: ErrorRequestHandler = (error, _request, response, _next) => {
  const status = typeof error?.status === "number" ? error.status : 500;
  if (error?.type === "entity.parse.failed") {
    response.status(400).json({ message: "Request body must be valid JSON" });
    return;
  }
  if (error?.type === "entity.too.large") {
    response.status(413).json({ message: "Request body is too large" });
    return;
  }
  if (status >= 500) {
    console.error(error);
  }
  response.status(status >= 400 && status < 600 ? status : 500).json({ message: "Something went wrong" });
};
