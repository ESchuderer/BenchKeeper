import { generateReference } from "../shared/reference.js";
import { seatsLeft, type Tasting } from "../shared/tastings.js";

export interface Booking {
  readonly reference: string;
  readonly tastingId: string;
  readonly name: string;
  readonly email: string;
  readonly guests: number;
}

export interface NewBooking {
  readonly name: string;
  readonly email: string;
  readonly guests: number;
}

export type CreateBookingResult = { ok: true; booking: Booking } | { ok: false; seatsLeft: number };

const MAX_REFERENCE_ATTEMPTS = 20;

/**
 * In-memory booking store. Node.js runs JavaScript on a single thread and `create`
 * checks the seats and inserts the booking without yielding, so two requests can never
 * both take the last seats.
 */
export class BookingStore {
  private readonly bookings = new Map<string, Booking>();
  /** Every reference ever issued, including cancelled bookings, so references are never reused. */
  private readonly issuedReferences = new Set<string>();

  create(tasting: Tasting, details: NewBooking): CreateBookingResult {
    const available = this.seatsLeft(tasting);
    if (details.guests > available) {
      return { ok: false, seatsLeft: available };
    }
    const booking: Booking = {
      reference: this.nextReference(),
      tastingId: tasting.id,
      name: details.name,
      email: details.email,
      guests: details.guests,
    };
    this.bookings.set(booking.reference, booking);
    return { ok: true, booking };
  }

  findByReference(reference: string): Booking | undefined {
    return this.bookings.get(reference);
  }

  /** Removes the booking, which frees its seats. Returns false when no such booking exists. */
  cancel(reference: string): boolean {
    return this.bookings.delete(reference);
  }

  activeBookings(tastingId?: string): Booking[] {
    const all = [...this.bookings.values()];
    return tastingId === undefined ? all : all.filter((booking) => booking.tastingId === tastingId);
  }

  seatsLeft(tasting: Tasting): number {
    return seatsLeft(tasting, this.activeBookings(tasting.id));
  }

  private nextReference(): string {
    for (let attempt = 0; attempt < MAX_REFERENCE_ATTEMPTS; attempt += 1) {
      const reference = generateReference();
      if (!this.issuedReferences.has(reference)) {
        this.issuedReferences.add(reference);
        return reference;
      }
    }
    throw new Error("Could not generate a unique booking reference");
  }
}
