import { randomBytes } from "node:crypto";

export interface AppConfig {
  port: number;
  /** Undefined when STAFF_PASSWORD is missing or empty; staff sign-in is then refused. */
  staffPassword: string | undefined;
  sessionSecret: string;
  secureCookies: boolean;
  /** Human-readable configuration problems to print at start-up. */
  warnings: string[];
}

export class ConfigError extends Error {}

const DEFAULT_PORT = 3000;

export function loadConfig(env: NodeJS.ProcessEnv): AppConfig {
  const warnings: string[] = [];

  const staffPassword = env.STAFF_PASSWORD ? env.STAFF_PASSWORD : undefined;
  if (staffPassword === undefined) {
    warnings.push("STAFF_PASSWORD is not set, so staff sign-in is disabled.");
  }

  let sessionSecret = env.SESSION_SECRET ? env.SESSION_SECRET : undefined;
  if (sessionSecret === undefined) {
    sessionSecret = randomBytes(32).toString("hex");
    warnings.push("SESSION_SECRET is not set; a random key is used and staff sessions end when the server restarts.");
  }

  return {
    port: parsePort(env.PORT),
    staffPassword,
    sessionSecret,
    secureCookies: env.SECURE_COOKIES === "true",
    warnings,
  };
}

function parsePort(value: string | undefined): number {
  if (value === undefined || value === "") {
    return DEFAULT_PORT;
  }
  const port = Number(value);
  if (!/^\d+$/.test(value) || port < 1 || port > 65535) {
    throw new ConfigError(`PORT must be a whole number between 1 and 65535, got "${value}"`);
  }
  return port;
}
