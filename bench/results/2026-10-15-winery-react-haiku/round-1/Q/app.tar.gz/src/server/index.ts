import { fileURLToPath } from "node:url";
import { existsSync } from "node:fs";
import { createApp } from "./app.js";
import { BookingStore } from "./booking-store.js";
import { ConfigError, loadConfig, type AppConfig } from "./config.js";

/** Built client, produced by `npm run build:client` at the project root (dist/client). */
const clientDir = fileURLToPath(new URL("../../dist/client", import.meta.url));

function readConfigOrExit(): AppConfig {
  try {
    return loadConfig(process.env);
  } catch (error) {
    if (error instanceof ConfigError) {
      console.error(`Configuration error: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

function main(): void {
  const config = readConfigOrExit();

  for (const warning of config.warnings) {
    console.warn(`Warning: ${warning}`);
  }
  if (!existsSync(clientDir)) {
    console.warn("Warning: the client is not built (dist/client is missing). Run `npm run build` first.");
  }

  const app = createApp({
    store: new BookingStore(),
    staffPassword: config.staffPassword,
    sessionSecret: config.sessionSecret,
    secureCookies: config.secureCookies,
    clientDir,
  });

  app.listen(config.port, () => {
    console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${config.port}`);
  });
}

main();
