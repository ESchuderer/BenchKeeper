import type { BookingConfirmation, StaffBookingRow, TastingSummary } from "../shared/api.js";
import { totalPrice } from "../shared/format.js";
import type { Tasting } from "../shared/tastings.js";
import type { Booking } from "./booking-store.js";

/** Maps stored data to the JSON shapes the client receives. Guest email addresses never pass through here. */

export function toTastingSummary(tasting: Tasting, seatsLeft: number): TastingSummary {
  return {
    id: tasting.id,
    title: tasting.title,
    date: tasting.date,
    time: tasting.time,
    pricePerGuest: tasting.pricePerGuest,
    seats: tasting.seats,
    seatsLeft,
  };
}

export function toConfirmation(booking: Booking, tasting: Tasting): BookingConfirmation {
  return {
    reference: booking.reference,
    tasting: { id: tasting.id, title: tasting.title, date: tasting.date, time: tasting.time },
    pricePerGuest: tasting.pricePerGuest,
    guests: booking.guests,
    total: totalPrice(tasting, booking.guests),
  };
}

export function toStaffBookingRow(booking: Booking): StaffBookingRow {
  return {
    reference: booking.reference,
    name: booking.name,
    email: booking.email,
    guests: booking.guests,
  };
}
