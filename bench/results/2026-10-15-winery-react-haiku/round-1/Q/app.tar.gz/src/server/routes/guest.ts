import { Router } from "express";
import type { BookingStore } from "../booking-store.js";
import { formatSeatsLeft } from "../../shared/format.js";
import { validateBooking } from "../../shared/booking-schema.js";
import { normalizeReference } from "../../shared/reference.js";
import { TASTINGS, findTasting } from "../../shared/tastings.js";
import { toConfirmation, toTastingSummary } from "../presenters.js";

export function createGuestRouter(store: BookingStore): Router {
  const router = Router();

  router.get("/tastings", (_request, response) => {
    response.json(TASTINGS.map((tasting) => toTastingSummary(tasting, store.seatsLeft(tasting))));
  });

  router.post("/tastings/:tastingId/bookings", (request, response) => {
    const tasting = findTasting(request.params.tastingId ?? "");
    if (!tasting) {
      response.status(404).json({ message: "Tasting not found" });
      return;
    }

    const validation = validateBooking(request.body);
    if (!validation.ok) {
      response.status(400).json({ errors: validation.errors });
      return;
    }

    const result = store.create(tasting, validation.data);
    if (!result.ok) {
      response.status(409).json({ errors: { guests: seatsRejectionMessage(result.seatsLeft) } });
      return;
    }

    response.status(201).json(toConfirmation(result.booking, tasting));
  });

  router.get("/bookings/:reference", (request, response) => {
    const reference = normalizeReference(request.params.reference);
    const booking = store.findByReference(reference);
    const tasting = booking ? findTasting(booking.tastingId) : undefined;
    if (!booking || !tasting) {
      response.status(404).json({ message: "No booking found for this reference" });
      return;
    }
    response.json(toConfirmation(booking, tasting));
  });

  return router;
}

function seatsRejectionMessage(seatsLeft: number): string {
  return seatsLeft === 0 ? "This tasting is fully booked" : `Only ${formatSeatsLeft(seatsLeft)}`;
}
