import { Router } from "express";
import cookieSession from "cookie-session";
import { rateLimit } from "express-rate-limit";
import type { BookingStore } from "../booking-store.js";
import { requireStaff, isStaffSignedIn, passwordMatches, signInStaff, signOutStaff, STAFF_SESSION_MS } from "../staff-auth.js";
import { normalizeReference } from "../../shared/reference.js";
import { TASTINGS } from "../../shared/tastings.js";
import { toStaffBookingRow, toTastingSummary } from "../presenters.js";

export interface StaffRouterOptions {
  store: BookingStore;
  staffPassword: string | undefined;
  sessionSecret: string;
  secureCookies: boolean;
}

const SIGN_IN_WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILED_SIGN_INS = 10;

export function createStaffRouter(options: StaffRouterOptions): Router {
  const { store, staffPassword } = options;
  const router = Router();

  // Staff responses contain guest email addresses; they must not be kept by browsers or caches.
  router.use((_request, response, next) => {
    response.setHeader("Cache-Control", "no-store");
    next();
  });

  router.use(
    cookieSession({
      name: "kieselbrunnen_staff",
      keys: [options.sessionSecret],
      maxAge: STAFF_SESSION_MS,
      httpOnly: true,
      sameSite: "strict",
      secure: options.secureCookies,
    }),
  );

  // Only failed attempts count: successful sign-ins are not counted (skipSuccessfulRequests).
  const signInLimiter = rateLimit({
    windowMs: SIGN_IN_WINDOW_MS,
    limit: MAX_FAILED_SIGN_INS,
    skipSuccessfulRequests: true,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { message: "Too many sign-in attempts. Try again later." },
  });

  router.get("/session", (request, response) => {
    response.json({ signedIn: isStaffSignedIn(request) });
  });

  router.post("/session", signInLimiter, (request, response) => {
    if (!staffPassword) {
      response.status(503).json({ message: "Staff sign-in is not configured" });
      return;
    }
    const password: unknown = request.body?.password;
    if (typeof password !== "string" || password.length === 0) {
      response.status(400).json({ errors: { password: "Enter the password" } });
      return;
    }
    if (!passwordMatches(password, staffPassword)) {
      response.status(401).json({ errors: { password: "Incorrect password" } });
      return;
    }
    signInStaff(request);
    response.status(204).end();
  });

  router.delete("/session", (request, response) => {
    signOutStaff(request);
    response.status(204).end();
  });

  router.get("/overview", requireStaff, (_request, response) => {
    response.json(
      TASTINGS.map((tasting) => ({
        ...toTastingSummary(tasting, store.seatsLeft(tasting)),
        bookings: store.activeBookings(tasting.id).map(toStaffBookingRow),
      })),
    );
  });

  router.delete("/bookings/:reference", requireStaff, (request, response) => {
    const reference = normalizeReference(request.params.reference);
    if (!store.cancel(reference)) {
      response.status(404).json({ message: "This booking no longer exists" });
      return;
    }
    response.status(204).end();
  });

  return router;
}
