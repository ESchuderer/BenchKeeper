import { createHash, timingSafeEqual } from "node:crypto";
import type { NextFunction, Request, Response } from "express";

export const STAFF_SESSION_MS = 8 * 60 * 60 * 1000;

/**
 * Compares the candidate with the expected password in constant time. Both values are hashed
 * first, so the comparison time reveals neither the password content nor its length.
 */
export function passwordMatches(candidate: string, expected: string): boolean {
  const candidateDigest = createHash("sha256").update(candidate, "utf8").digest();
  const expectedDigest = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(candidateDigest, expectedDigest);
}

export function signInStaff(request: Request, now: number = Date.now()): void {
  if (request.session) {
    request.session.staffUntil = now + STAFF_SESSION_MS;
  }
}

export function signOutStaff(request: Request): void {
  request.session = null;
}

export function isStaffSignedIn(request: Request, now: number = Date.now()): boolean {
  const until: unknown = request.session?.staffUntil;
  return typeof until === "number" && now < until;
}

export function requireStaff(request: Request, response: Response, next: NextFunction): void {
  if (!isStaffSignedIn(request)) {
    response.status(401).json({ message: "Sign in to see the staff area" });
    return;
  }
  next();
}
