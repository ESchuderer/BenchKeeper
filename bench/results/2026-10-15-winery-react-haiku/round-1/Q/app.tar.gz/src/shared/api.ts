/** Shapes of the JSON exchanged between the React client and the server. */

export interface TastingSummary {
  id: string;
  title: string;
  date: string;
  time: string;
  pricePerGuest: number;
  seats: number;
  seatsLeft: number;
}

export interface BookingConfirmation {
  reference: string;
  tasting: { id: string; title: string; date: string; time: string };
  pricePerGuest: number;
  guests: number;
  total: number;
}

/** Field-keyed messages, so each message can be shown next to the field it concerns. */
export interface ErrorResponse {
  message?: string;
  errors?: Record<string, string>;
}

export interface StaffBookingRow {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTastingOverview extends TastingSummary {
  bookings: StaffBookingRow[];
}
