import { z } from "zod";

export const MAX_GUESTS = 8;
export const GUESTS_RANGE_MESSAGE = `Guests must be between 1 and ${MAX_GUESTS}`;

export const bookingSchema = z.object({
  name: z
    .string({ error: "Enter your name" })
    .trim()
    .min(1, "Enter your name")
    .max(100, "Name must be 100 characters or fewer"),
  email: z
    .string({ error: "Enter your email address" })
    .trim()
    .min(1, "Enter your email address")
    .max(254, "Email address must be 254 characters or fewer")
    .pipe(z.email({ error: "Enter a valid email address" })),
  guests: z
    .number({ error: GUESTS_RANGE_MESSAGE })
    .int(GUESTS_RANGE_MESSAGE)
    .min(1, GUESTS_RANGE_MESSAGE)
    .max(MAX_GUESTS, GUESTS_RANGE_MESSAGE),
});

export type BookingInput = z.infer<typeof bookingSchema>;
export type BookingField = keyof BookingInput;
export type BookingFieldErrors = Partial<Record<BookingField, string>>;

export type BookingValidation =
  | { ok: true; data: BookingInput }
  | { ok: false; errors: BookingFieldErrors };

/**
 * Validates untrusted booking input. Returns one message per invalid field so that
 * each message can be shown next to the field it concerns.
 */
export function validateBooking(input: unknown): BookingValidation {
  const result = bookingSchema.safeParse(typeof input === "object" && input !== null ? input : {});
  if (result.success) {
    return { ok: true, data: result.data };
  }
  const errors: BookingFieldErrors = {};
  for (const issue of result.error.issues) {
    const field = issue.path[0];
    if (isBookingField(field) && errors[field] === undefined) {
      errors[field] = issue.message;
    }
  }
  return { ok: false, errors };
}

function isBookingField(value: PropertyKey | undefined): value is BookingField {
  return value === "name" || value === "email" || value === "guests";
}
