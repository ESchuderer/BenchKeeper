import type { Tasting } from "./tastings.js";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] as const;
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"] as const;

export function totalPrice(tasting: Tasting, guests: number): number {
  return tasting.pricePerGuest * guests;
}

export function formatEuro(amount: number): string {
  return `EUR ${amount}`;
}

export function formatSeatsLeft(seats: number): string {
  return seats === 1 ? "1 seat left" : `${seats} seats left`;
}

/**
 * Formats a local date and time such as "Fri 6 Nov 2026, 18:00".
 * Works on calendar parts only, so the output never depends on the server's timezone.
 */
export function formatTastingDateTime(date: string, time: string): string {
  const [year, month, day] = date.split("-").map(Number);
  const weekday = WEEKDAYS[new Date(Date.UTC(year ?? 0, (month ?? 1) - 1, day ?? 1)).getUTCDay()];
  return `${weekday} ${day} ${MONTHS[(month ?? 1) - 1]} ${year}, ${time}`;
}
