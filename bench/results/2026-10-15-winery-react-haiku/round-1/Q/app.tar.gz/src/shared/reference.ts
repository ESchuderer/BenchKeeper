import { randomInt } from "node:crypto";

/**
 * Upper-case letters and digits without 0, O, 1, I and L, so references can be read
 * aloud or copied from a printout without confusion.
 */
export const REFERENCE_ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ";
const REFERENCE_LENGTH = 6;
const PREFIX = "KB-";

export function generateReference(random: (max: number) => number = (max) => randomInt(max)): string {
  let body = "";
  for (let i = 0; i < REFERENCE_LENGTH; i += 1) {
    body += REFERENCE_ALPHABET[random(REFERENCE_ALPHABET.length)];
  }
  return PREFIX + body;
}

/** Normalises a reference typed by a guest or staff member, e.g. " kb-k7m2pq " becomes "KB-K7M2PQ". */
export function normalizeReference(value: unknown): string {
  return typeof value === "string" ? value.trim().toUpperCase() : "";
}
