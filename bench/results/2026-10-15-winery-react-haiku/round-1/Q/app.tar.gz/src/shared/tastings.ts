export interface Tasting {
  readonly id: string;
  readonly title: string;
  /** Local (Europe/Berlin) calendar date, YYYY-MM-DD. */
  readonly date: string;
  /** Local start time, HH:MM. */
  readonly time: string;
  /** Price per guest in whole euros. */
  readonly pricePerGuest: number;
  readonly seats: number;
}

export interface SeatHolding {
  readonly tastingId: string;
  readonly guests: number;
}

export const TASTINGS: readonly Tasting[] = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    date: "2026-11-06",
    time: "18:00",
    pricePerGuest: 25,
    seats: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    date: "2026-11-14",
    time: "15:00",
    pricePerGuest: 32,
    seats: 8,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    date: "2026-12-05",
    time: "17:00",
    pricePerGuest: 28,
    seats: 10,
  },
];

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((tasting) => tasting.id === id);
}

/** Seats left are derived from the active bookings, so cancelling a booking frees its seats. */
export function seatsLeft(tasting: Tasting, bookings: readonly SeatHolding[]): number {
  const taken = bookings
    .filter((booking) => booking.tastingId === tasting.id)
    .reduce((sum, booking) => sum + booking.guests, 0);
  return Math.max(0, tasting.seats - taken);
}
