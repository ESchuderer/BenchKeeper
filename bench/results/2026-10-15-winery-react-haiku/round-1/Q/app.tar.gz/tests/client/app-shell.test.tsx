// @vitest-environment jsdom
import { screen, within } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { renderAt } from "./support.js";

describe("app shell", () => {
  it("shows the winery name in the header with links to the tastings and the staff area", () => {
    renderAt("/");

    const header = screen.getByRole("banner");
    expect(within(header).getByText("Weingut Kieselbrunnen")).toBeInTheDocument();
    expect(within(header).getByRole("link", { name: "Tastings" })).toHaveAttribute("href", "/");
    expect(within(header).getByRole("link", { name: "Staff" })).toHaveAttribute("href", "/staff");
  });

  it("shows a page-not-found message with a way back to the tastings for unknown addresses", () => {
    renderAt("/no-such-page");

    expect(screen.getByRole("heading", { name: "Page not found" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Back to the tastings" })).toHaveAttribute("href", "/");
  });
});
