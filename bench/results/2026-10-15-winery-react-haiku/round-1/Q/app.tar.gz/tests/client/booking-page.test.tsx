// @vitest-environment jsdom
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderAt, stubApi } from "./support.js";

const RIESLING = {
  id: "riesling-evening",
  title: "Riesling Evening",
  date: "2026-11-06",
  time: "18:00",
  pricePerGuest: 25,
  seats: 12,
  seatsLeft: 12,
};
const FULL_WINTER = {
  id: "winter-tasting",
  title: "Winter Tasting",
  date: "2026-12-05",
  time: "17:00",
  pricePerGuest: 28,
  seats: 10,
  seatsLeft: 0,
};
const BOOKING_PATH = "/tastings/riesling-evening/book";

async function fillForm(
  user: ReturnType<typeof userEvent.setup>,
  values: { name?: string; email?: string; guests?: string },
) {
  if (values.name !== undefined) await user.type(screen.getByLabelText("Name"), values.name);
  if (values.email !== undefined) await user.type(screen.getByLabelText("Email"), values.email);
  if (values.guests !== undefined) {
    await user.clear(screen.getByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), values.guests);
  }
}

describe("booking page", () => {
  it("shows the tasting and a form with Name, Email and Guests fields and a Book button", async () => {
    stubApi({ "GET /api/tastings": { body: [RIESLING] } });
    renderAt(BOOKING_PATH);

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByText("12 seats left")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAttribute("min", "1");
    expect(screen.getByLabelText("Guests")).toHaveAttribute("max", "8");
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("shows a message next to the Name field and sends nothing when the name is empty", async () => {
    const user = userEvent.setup();
    const { calls } = stubApi({ "GET /api/tastings": { body: [RIESLING] } });
    renderAt(BOOKING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await user.type(screen.getByLabelText("Email"), "anna@example.com");
    await user.click(screen.getByRole("button", { name: "Book" }));

    const name = screen.getByLabelText("Name");
    expect(await screen.findByText("Enter your name")).toBeInTheDocument();
    expect(name).toHaveAttribute("aria-invalid", "true");
    expect(name).toHaveAccessibleDescription("Enter your name");
    expect(calls.filter((call) => call.method === "POST")).toHaveLength(0);
  });

  it("shows a message next to the Email field for a malformed address", async () => {
    const user = userEvent.setup();
    stubApi({ "GET /api/tastings": { body: [RIESLING] } });
    renderAt(BOOKING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillForm(user, { name: "Anna", email: "anna@" });
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Enter a valid email address")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription("Enter a valid email address");
  });

  it("shows a message next to the Guests field for 0 or 9 guests", async () => {
    const user = userEvent.setup();
    stubApi({ "GET /api/tastings": { body: [RIESLING] } });
    renderAt(BOOKING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillForm(user, { name: "Anna", email: "anna@example.com", guests: "9" });
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Guests must be between 1 and 8")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription("Guests must be between 1 and 8");
  });

  it("sends the trimmed booking to the server and does not add a second request for the same submit", async () => {
    const user = userEvent.setup();
    const { calls } = stubApi({
      "GET /api/tastings": { body: [RIESLING] },
      "POST /api/tastings/riesling-evening/bookings": {
        status: 201,
        body: {
          reference: "KB-ABC234",
          tasting: { id: "riesling-evening", title: "Riesling Evening", date: "2026-11-06", time: "18:00" },
          pricePerGuest: 25,
          guests: 2,
          total: 50,
        },
      },
    });
    renderAt(BOOKING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillForm(user, { name: "  Anna Keller ", email: " anna@example.com", guests: "2" });
    await user.click(screen.getByRole("button", { name: "Book" }));

    await waitFor(() => {
      expect(calls.filter((call) => call.method === "POST")).toHaveLength(1);
    });
    expect(calls.find((call) => call.method === "POST")?.body).toEqual({
      name: "Anna Keller",
      email: "anna@example.com",
      guests: 2,
    });
  });

  it("shows the server's seat limit message next to the Guests field when too many guests are requested", async () => {
    const user = userEvent.setup();
    stubApi({
      "GET /api/tastings": { body: [RIESLING] },
      "POST /api/tastings/riesling-evening/bookings": {
        status: 409,
        body: { errors: { guests: "Only 2 seats left" } },
      },
    });
    renderAt(BOOKING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillForm(user, { name: "Anna", email: "anna@example.com", guests: "4" });
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Only 2 seats left")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription("Only 2 seats left");
  });

  it("shows server field errors next to the fields they concern", async () => {
    const user = userEvent.setup();
    stubApi({
      "GET /api/tastings": { body: [RIESLING] },
      "POST /api/tastings/riesling-evening/bookings": {
        status: 400,
        body: { errors: { email: "Enter a valid email address" } },
      },
    });
    renderAt(BOOKING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillForm(user, { name: "Anna", email: "anna@example.com", guests: "2" });
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Enter a valid email address")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription("Enter a valid email address");
  });

  it("explains in an alert when the booking cannot reach the server", async () => {
    const user = userEvent.setup();
    stubApi({
      "GET /api/tastings": { body: [RIESLING] },
      "POST /api/tastings/riesling-evening/bookings": () => {
        throw new TypeError("Failed to fetch");
      },
    });
    renderAt(BOOKING_PATH);
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await fillForm(user, { name: "Anna", email: "anna@example.com", guests: "2" });
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("We could not reach the server. Please try again.");
  });

  it("shows a fully booked tasting without a bookable form", async () => {
    stubApi({ "GET /api/tastings": { body: [FULL_WINTER] } });
    renderAt("/tastings/winter-tasting/book");

    const heading = await screen.findByRole("heading", { name: "Winter Tasting" });
    const section = heading.closest("section") ?? document.body;
    expect(within(section).getByText("Fully booked")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeDisabled();
  });

  it("explains when the tasting does not exist", async () => {
    stubApi({ "GET /api/tastings": { body: [RIESLING] } });
    renderAt("/tastings/unknown-tasting/book");

    expect(await screen.findByRole("heading", { name: "Tasting not found" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Back to the tastings" })).toHaveAttribute("href", "/");
  });
});
