// @vitest-environment jsdom
import { screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderAt, stubApi } from "./support.js";

const CONFIRMATION = {
  reference: "KB-ABC234",
  tasting: { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00" },
  pricePerGuest: 28,
  guests: 2,
  total: 56,
};

describe("confirmation page", () => {
  it("confirms the booking with the tasting, guest count, total price and reference", async () => {
    stubApi({ "GET /api/bookings/KB-ABC234": { body: CONFIRMATION } });
    renderAt("/bookings/KB-ABC234");

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    const details = screen.getByRole("list", { name: "Booking details" });
    expect(within(details).getByText("Winter Tasting")).toBeInTheDocument();
    expect(within(details).getByText("Sat 5 Dec 2026, 17:00")).toBeInTheDocument();
    expect(within(details).getByText("2 guests")).toBeInTheDocument();
    expect(within(details).getByText("EUR 56")).toBeInTheDocument();
    expect(within(details).getByText("KB-ABC234")).toBeInTheDocument();
  });

  it("uses the singular for a single guest", async () => {
    stubApi({ "GET /api/bookings/KB-ABC234": { body: { ...CONFIRMATION, guests: 1, total: 28 } } });
    renderAt("/bookings/KB-ABC234");

    expect(await screen.findByText("1 guest")).toBeInTheDocument();
  });

  it("explains when no booking has the given reference", async () => {
    stubApi({
      "GET /api/bookings/KB-ZZZZZZ": { status: 404, body: { message: "No booking found for this reference" } },
    });
    renderAt("/bookings/KB-ZZZZZZ");

    expect(await screen.findByRole("heading", { name: "Booking not found" })).toBeInTheDocument();
    expect(screen.getByText("No booking found for this reference.")).toBeInTheDocument();
  });

  it("shows a loading message while the booking is fetched", () => {
    stubApi({ "GET /api/bookings/KB-ABC234": { body: CONFIRMATION } });
    renderAt("/bookings/KB-ABC234");

    expect(screen.getByText("Loading your booking…")).toBeInTheDocument();
  });

  it("is reached after a successful booking from the booking form", async () => {
    const user = userEvent.setup();
    stubApi({
      "GET /api/tastings": {
        body: [
          {
            id: "winter-tasting",
            title: "Winter Tasting",
            date: "2026-12-05",
            time: "17:00",
            pricePerGuest: 28,
            seats: 10,
            seatsLeft: 10,
          },
        ],
      },
      "POST /api/tastings/winter-tasting/bookings": { status: 201, body: CONFIRMATION },
      "GET /api/bookings/KB-ABC234": { body: CONFIRMATION },
    });
    renderAt("/tastings/winter-tasting/book");

    await screen.findByRole("heading", { name: "Winter Tasting" });
    await user.type(screen.getByLabelText("Name"), "Anna Keller");
    await user.type(screen.getByLabelText("Email"), "anna@example.com");
    await user.clear(screen.getByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(screen.getByText("KB-ABC234")).toBeInTheDocument();
  });
});
