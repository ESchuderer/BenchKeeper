// @vitest-environment jsdom
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { renderAt, stubApi } from "./support.js";

function overviewFixture(winterBookings: Array<{ reference: string; name: string; email: string; guests: number }>) {
  return [
    {
      id: "riesling-evening",
      title: "Riesling Evening",
      date: "2026-11-06",
      time: "18:00",
      pricePerGuest: 25,
      seats: 12,
      seatsLeft: 9,
      bookings: [{ reference: "KB-RIES23", name: "Ben Ruh", email: "ben@example.com", guests: 3 }],
    },
    {
      id: "red-wine-cellar-tour",
      title: "Red Wine Cellar Tour",
      date: "2026-11-14",
      time: "15:00",
      pricePerGuest: 32,
      seats: 8,
      seatsLeft: 8,
      bookings: [],
    },
    {
      id: "winter-tasting",
      title: "Winter Tasting",
      date: "2026-12-05",
      time: "17:00",
      pricePerGuest: 28,
      seats: 10,
      seatsLeft: 10 - winterBookings.reduce((sum, booking) => sum + booking.guests, 0),
      bookings: winterBookings,
    },
  ];
}

const ANNA = { reference: "KB-WINT23", name: "Anna Keller", email: "anna@example.com", guests: 2 };

function winterList() {
  return screen.getByRole("list", { name: "Bookings for Winter Tasting" });
}

describe("staff page sign-in", () => {
  it("asks for the password with a Password field and a Sign in button when signed out", async () => {
    stubApi({ "GET /api/staff/session": { body: { signedIn: false } } });
    renderAt("/staff");

    expect(await screen.findByRole("heading", { name: "Staff area" })).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toHaveAttribute("type", "password");
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
  });

  it("shows an incorrect password next to the Password field", async () => {
    const user = userEvent.setup();
    stubApi({
      "GET /api/staff/session": { body: { signedIn: false } },
      "POST /api/staff/session": { status: 401, body: { errors: { password: "Incorrect password" } } },
    });
    renderAt("/staff");
    await screen.findByLabelText("Password");

    await user.type(screen.getByLabelText("Password"), "wrong");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByText("Incorrect password")).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toHaveAccessibleDescription("Incorrect password");
    expect(screen.queryByRole("heading", { name: "Winter Tasting" })).toBeNull();
  });

  it("asks for a password before sending an empty form", async () => {
    const user = userEvent.setup();
    const { calls } = stubApi({ "GET /api/staff/session": { body: { signedIn: false } } });
    renderAt("/staff");
    await screen.findByLabelText("Password");

    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByText("Enter the password")).toBeInTheDocument();
    expect(calls.filter((call) => call.method === "POST")).toHaveLength(0);
  });

  it("explains when too many sign-in attempts have been made", async () => {
    const user = userEvent.setup();
    stubApi({
      "GET /api/staff/session": { body: { signedIn: false } },
      "POST /api/staff/session": {
        status: 429,
        body: { message: "Too many sign-in attempts. Try again later." },
      },
    });
    renderAt("/staff");
    await screen.findByLabelText("Password");

    await user.type(screen.getByLabelText("Password"), "wrong");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("Too many sign-in attempts. Try again later.");
  });

  it("explains when staff sign-in is not configured on the server", async () => {
    const user = userEvent.setup();
    stubApi({
      "GET /api/staff/session": { body: { signedIn: false } },
      "POST /api/staff/session": { status: 503, body: { message: "Staff sign-in is not configured" } },
    });
    renderAt("/staff");
    await screen.findByLabelText("Password");

    await user.type(screen.getByLabelText("Password"), "anything");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("Staff sign-in is not configured");
  });

  it("shows the bookings grouped by tasting after a correct password", async () => {
    const user = userEvent.setup();
    let signedIn = false;
    stubApi({
      "GET /api/staff/session": () => ({ body: { signedIn } }),
      "POST /api/staff/session": () => {
        signedIn = true;
        return { status: 204 };
      },
      "GET /api/staff/overview": { body: overviewFixture([ANNA]) },
    });
    renderAt("/staff");
    await screen.findByLabelText("Password");

    await user.type(screen.getByLabelText("Password"), "correct");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();
    expect(screen.queryByLabelText("Password")).toBeNull();
  });

  it("keeps a signed-in staff member in the overview after a reload", async () => {
    stubApi({
      "GET /api/staff/session": { body: { signedIn: true } },
      "GET /api/staff/overview": { body: overviewFixture([ANNA]) },
    });
    renderAt("/staff");

    expect(await screen.findByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();
    expect(screen.queryByLabelText("Password")).toBeNull();
  });
});

describe("staff overview", () => {
  it("lists name, email, guests and reference for each booking under its tasting", async () => {
    stubApi({
      "GET /api/staff/session": { body: { signedIn: true } },
      "GET /api/staff/overview": { body: overviewFixture([ANNA]) },
    });
    renderAt("/staff");

    const winter = await screen.findByRole("heading", { name: "Winter Tasting" });
    const section = winter.closest("section")!;
    expect(within(section).getByText("8 seats left")).toBeInTheDocument();
    const row = within(winterList()).getByRole("listitem");
    expect(within(row).getByText("Anna Keller")).toBeInTheDocument();
    expect(within(row).getByText("anna@example.com")).toBeInTheDocument();
    expect(within(row).getByText("2 guests")).toBeInTheDocument();
    expect(within(row).getByText("KB-WINT23")).toBeInTheDocument();
  });

  it("shows 'No bookings yet' for a tasting without bookings", async () => {
    stubApi({
      "GET /api/staff/session": { body: { signedIn: true } },
      "GET /api/staff/overview": { body: overviewFixture([ANNA]) },
    });
    renderAt("/staff");

    const cellar = await screen.findByRole("heading", { name: "Red Wine Cellar Tour" });
    expect(within(cellar.closest("section")!).getByText("No bookings yet")).toBeInTheDocument();
  });

  it("cancels a booking, which disappears and frees its seats", async () => {
    const user = userEvent.setup();
    let bookings = [ANNA];
    stubApi({
      "GET /api/staff/session": { body: { signedIn: true } },
      "GET /api/staff/overview": () => ({ body: overviewFixture(bookings) }),
      "DELETE /api/staff/bookings/KB-WINT23": () => {
        bookings = [];
        return { status: 204 };
      },
    });
    renderAt("/staff");
    await screen.findByRole("heading", { name: "Winter Tasting" });

    await user.click(within(winterList()).getByRole("button", { name: "Cancel" }));

    expect(await screen.findByText("Booking KB-WINT23 cancelled. Its seats are free again.")).toBeInTheDocument();
    await waitFor(() => {
      expect(screen.queryByText("Anna Keller")).toBeNull();
    });
    const winter = screen.getByRole("heading", { name: "Winter Tasting" }).closest("section")!;
    expect(within(winter).getByText("No bookings yet")).toBeInTheDocument();
    expect(within(winter).getByText("10 seats left")).toBeInTheDocument();
  });

  it("reports a booking that was already cancelled and refreshes the list", async () => {
    const user = userEvent.setup();
    const { calls } = stubApi({
      "GET /api/staff/session": { body: { signedIn: true } },
      "GET /api/staff/overview": { body: overviewFixture([ANNA]) },
      "DELETE /api/staff/bookings/KB-WINT23": { status: 404, body: { message: "This booking no longer exists" } },
    });
    renderAt("/staff");
    await screen.findByRole("heading", { name: "Winter Tasting" });

    await user.click(within(winterList()).getByRole("button", { name: "Cancel" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("This booking no longer exists");
    await waitFor(() => {
      expect(calls.filter((call) => call.path === "/api/staff/overview")).toHaveLength(2);
    });
  });

  it("signs the staff member out and asks for the password again", async () => {
    const user = userEvent.setup();
    let signedIn = true;
    stubApi({
      "GET /api/staff/session": () => ({ body: { signedIn } }),
      "GET /api/staff/overview": { body: overviewFixture([ANNA]) },
      "DELETE /api/staff/session": () => {
        signedIn = false;
        return { status: 204 };
      },
    });
    renderAt("/staff");
    await screen.findByRole("heading", { name: "Winter Tasting" });

    await user.click(screen.getByRole("button", { name: "Sign out" }));

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Winter Tasting" })).toBeNull();
  });

  it("keeps the staff area open and explains when sign-out fails", async () => {
    const user = userEvent.setup();
    stubApi({
      "GET /api/staff/session": { body: { signedIn: true } },
      "GET /api/staff/overview": { body: overviewFixture([ANNA]) },
      "DELETE /api/staff/session": { status: 500, body: { message: "Something went wrong" } },
    });
    renderAt("/staff");
    await screen.findByRole("heading", { name: "Winter Tasting" });

    await user.click(screen.getByRole("button", { name: "Sign out" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("Something went wrong");
    expect(screen.getByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();
    expect(screen.queryByLabelText("Password")).toBeNull();
  });

  it("asks for the password again when the staff session has ended", async () => {
    stubApi({
      "GET /api/staff/session": { body: { signedIn: true } },
      "GET /api/staff/overview": { status: 401, body: { message: "Sign in to see the staff area" } },
    });
    renderAt("/staff");

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.getByText("Your staff session has ended. Sign in again.")).toBeInTheDocument();
  });
});
