// @vitest-environment jsdom
import { screen, within } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { renderAt, stubApi } from "./support.js";

const TASTINGS = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    date: "2026-11-06",
    time: "18:00",
    pricePerGuest: 25,
    seats: 12,
    seatsLeft: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    date: "2026-11-14",
    time: "15:00",
    pricePerGuest: 32,
    seats: 8,
    seatsLeft: 1,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    date: "2026-12-05",
    time: "17:00",
    pricePerGuest: 28,
    seats: 10,
    seatsLeft: 0,
  },
];

describe("start page", () => {
  it("lists every tasting with its title, date and time, price per guest and seats left", async () => {
    stubApi({ "GET /api/tastings": { body: TASTINGS } });
    renderAt("/");

    const riesling = await screen.findByRole("article", { name: "Riesling Evening" });
    expect(within(riesling).getByText("Fri 6 Nov 2026, 18:00")).toBeInTheDocument();
    expect(within(riesling).getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(within(riesling).getByText("12 seats left")).toBeInTheDocument();

    const cellar = screen.getByRole("article", { name: "Red Wine Cellar Tour" });
    expect(within(cellar).getByText("Sat 14 Nov 2026, 15:00")).toBeInTheDocument();
    expect(within(cellar).getByText("EUR 32 per guest")).toBeInTheDocument();
    expect(within(cellar).getByText("1 seat left")).toBeInTheDocument();
  });

  it("offers a Book action named after each tasting that has seats left", async () => {
    stubApi({ "GET /api/tastings": { body: TASTINGS } });
    renderAt("/");

    expect(await screen.findByRole("link", { name: "Book Riesling Evening" })).toHaveAttribute(
      "href",
      "/tastings/riesling-evening/book",
    );
    expect(screen.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toHaveAttribute(
      "href",
      "/tastings/red-wine-cellar-tour/book",
    );
  });

  it("marks a fully booked tasting and offers no booking action for it", async () => {
    stubApi({ "GET /api/tastings": { body: TASTINGS } });
    renderAt("/");

    const winter = await screen.findByRole("article", { name: "Winter Tasting" });
    expect(within(winter).getByText("Fully booked")).toBeInTheDocument();
    expect(within(winter).queryByRole("link")).toBeNull();
    expect(screen.queryByRole("link", { name: "Book Winter Tasting" })).toBeNull();
  });

  it("shows a loading message while the tastings are fetched", () => {
    stubApi({ "GET /api/tastings": { body: TASTINGS } });
    renderAt("/");

    expect(screen.getByText("Loading tastings…")).toBeInTheDocument();
  });

  it("explains in an alert when the tastings cannot be loaded", async () => {
    stubApi({
      "GET /api/tastings": () => {
        throw new TypeError("Failed to fetch");
      },
    });
    renderAt("/");

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "We could not reach the server. Please try again.",
    );
  });
});
