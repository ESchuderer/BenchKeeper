import type { ReactElement } from "react";
import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router";
import { vi } from "vitest";
import { App } from "../../src/client/App.js";

export interface StubResponse {
  status?: number;
  body?: unknown;
}

export type StubHandler = StubResponse | ((body: unknown) => StubResponse);

export interface RecordedCall {
  method: string;
  path: string;
  body: unknown;
}

/**
 * Replaces the global fetch with a stub keyed by "METHOD /path". Requests without a stub fail
 * the test loudly, and a handler that throws simulates a network failure.
 */
export function stubApi(handlers: Record<string, StubHandler>): { calls: RecordedCall[] } {
  const calls: RecordedCall[] = [];
  const fetchStub = vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
    const url = new URL(String(input), "http://localhost");
    const method = (init?.method ?? "GET").toUpperCase();
    const body: unknown = typeof init?.body === "string" ? JSON.parse(init.body) : undefined;
    calls.push({ method, path: url.pathname, body });

    const handler = handlers[`${method} ${url.pathname}`];
    if (handler === undefined) {
      throw new Error(`Unexpected request in test: ${method} ${url.pathname}`);
    }
    const stub = typeof handler === "function" ? handler(body) : handler;
    const status = stub.status ?? 200;
    return new Response(status === 204 ? null : JSON.stringify(stub.body ?? {}), {
      status,
      headers: { "content-type": "application/json" },
    });
  });
  vi.stubGlobal("fetch", fetchStub);
  return { calls };
}

export function renderAt(path: string, ui: ReactElement = <App />) {
  return render(<MemoryRouter initialEntries={[path]}>{ui}</MemoryRouter>);
}
