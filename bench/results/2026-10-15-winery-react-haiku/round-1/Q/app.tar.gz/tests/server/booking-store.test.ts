import { describe, expect, it } from "vitest";
import { BookingStore } from "../../src/server/booking-store.js";
import { TASTINGS, type Tasting } from "../../src/shared/tastings.js";

const LARGE_TASTING: Tasting = { ...TASTINGS[0]!, seats: 1000 };
const DETAILS = { name: "Anna Keller", email: "anna@example.com", guests: 1 };

describe("BookingStore", () => {
  it("gives every booking a different reference across 100 bookings", () => {
    const store = new BookingStore();

    const references = Array.from({ length: 100 }, () => {
      const result = store.create(LARGE_TASTING, DETAILS);
      if (!result.ok) throw new Error("expected the booking to be created");
      return result.booking.reference;
    });

    expect(new Set(references).size).toBe(100);
  });

  it("never reuses the reference of a cancelled booking", () => {
    const store = new BookingStore();
    const first = store.create(LARGE_TASTING, DETAILS);
    if (!first.ok) throw new Error("expected the booking to be created");
    store.cancel(first.booking.reference);

    const references = new Set<string>();
    for (let i = 0; i < 100; i += 1) {
      const result = store.create(LARGE_TASTING, DETAILS);
      if (result.ok) references.add(result.booking.reference);
    }

    expect(references.has(first.booking.reference)).toBe(false);
  });
});
