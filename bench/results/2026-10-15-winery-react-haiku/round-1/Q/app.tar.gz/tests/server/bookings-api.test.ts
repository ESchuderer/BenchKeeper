import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../../src/server/app.js";
import { BookingStore } from "../../src/server/booking-store.js";

function setup() {
  const store = new BookingStore();
  const app = createApp({ store, staffPassword: "test-password", sessionSecret: "test-secret" });
  return { app, store };
}

const WINTER = "/api/tastings/winter-tasting/bookings";
const validBooking = { name: "Anna Keller", email: "anna@example.com", guests: 2 };

async function seatsLeftFor(app: ReturnType<typeof setup>["app"], tastingId: string): Promise<number> {
  const response = await request(app).get("/api/tastings").expect(200);
  const tasting = (response.body as Array<{ id: string; seatsLeft: number }>).find((t) => t.id === tastingId);
  return tasting!.seatsLeft;
}

describe("POST /api/tastings/:id/bookings", () => {
  it("creates a booking and returns the confirmation with reference, guests and total", async () => {
    const { app } = setup();

    const response = await request(app).post(WINTER).send(validBooking).expect(201);

    expect(response.body).toEqual({
      reference: expect.stringMatching(/^KB-[2-9A-HJ-NP-Z]{6}$/),
      tasting: { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00" },
      pricePerGuest: 28,
      guests: 2,
      total: 56,
    });
  });

  it("reduces the seats left for that tasting by the booked guests", async () => {
    const { app } = setup();

    await request(app).post(WINTER).send(validBooking).expect(201);

    expect(await seatsLeftFor(app, "winter-tasting")).toBe(8);
    expect(await seatsLeftFor(app, "riesling-evening")).toBe(12);
  });

  it("rejects invalid input with a message for each field it concerns", async () => {
    const { app } = setup();

    const response = await request(app)
      .post(WINTER)
      .send({ name: "", email: "not-an-email", guests: 9 })
      .expect(400);

    expect(response.body).toEqual({
      errors: {
        name: "Enter your name",
        email: "Enter a valid email address",
        guests: "Guests must be between 1 and 8",
      },
    });
  });

  it("rejects a booking that asks for more guests than seats left with a message on the guests field", async () => {
    const { app } = setup();
    await request(app).post(WINTER).send({ ...validBooking, guests: 8 }).expect(201);

    const response = await request(app).post(WINTER).send({ ...validBooking, guests: 4 }).expect(409);

    expect(response.body).toEqual({ errors: { guests: "Only 2 seats left" } });
    expect(await seatsLeftFor(app, "winter-tasting")).toBe(2);
  });

  it("says a fully booked tasting is full rather than giving a seat count", async () => {
    const { app } = setup();
    await request(app).post(WINTER).send({ ...validBooking, guests: 8 }).expect(201);
    await request(app).post(WINTER).send({ ...validBooking, guests: 2 }).expect(201);

    const response = await request(app).post(WINTER).send({ ...validBooking, guests: 1 }).expect(409);

    expect(response.body).toEqual({ errors: { guests: "This tasting is fully booked" } });
  });

  it("rejects a second booking for the last seats when they were taken first", async () => {
    const { app } = setup();
    await request(app).post(WINTER).send({ ...validBooking, guests: 7 }).expect(201);

    const [first, second] = await Promise.all([
      request(app).post(WINTER).send({ ...validBooking, guests: 2 }),
      request(app).post(WINTER).send({ ...validBooking, guests: 2 }),
    ]);

    expect([first.status, second.status].sort()).toEqual([201, 409]);
    expect(await seatsLeftFor(app, "winter-tasting")).toBe(1);
  });

  it("answers 404 for an unknown tasting", async () => {
    const { app } = setup();

    await request(app).post("/api/tastings/unknown/bookings").send(validBooking).expect(404);
  });

  it("returns a JSON error for a request body that is not valid JSON", async () => {
    const { app } = setup();

    const response = await request(app)
      .post(WINTER)
      .set("Content-Type", "application/json")
      .send("{not json")
      .expect(400);

    expect(response.body).toEqual({ message: "Request body must be valid JSON" });
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the public confirmation without the guest's email address", async () => {
    const { app } = setup();
    const created = await request(app).post(WINTER).send(validBooking).expect(201);

    const response = await request(app).get(`/api/bookings/${created.body.reference}`).expect(200);

    expect(response.body).toEqual(created.body);
    expect(JSON.stringify(response.body)).not.toContain("anna@example.com");
    expect(JSON.stringify(response.body)).not.toContain("Anna Keller");
  });

  it("answers 404 for a reference that does not exist", async () => {
    const { app } = setup();

    const response = await request(app).get("/api/bookings/KB-ZZZZZZ").expect(404);

    expect(response.body).toEqual({ message: "No booking found for this reference" });
  });
});
