import { describe, expect, it } from "vitest";
import { loadConfig } from "../../src/server/config.js";

describe("loadConfig", () => {
  it("listens on port 3000 when PORT is not set", () => {
    expect(loadConfig({}).port).toBe(3000);
  });

  it("uses the port given in PORT", () => {
    expect(loadConfig({ PORT: "3111" }).port).toBe(3111);
  });

  it.each(["abc", "0", "70000", "3000.5"])("rejects the invalid PORT value %j", (value) => {
    expect(() => loadConfig({ PORT: value })).toThrow(/PORT/);
  });

  it("reads the staff password from STAFF_PASSWORD", () => {
    expect(loadConfig({ STAFF_PASSWORD: "vineyard-2026" }).staffPassword).toBe("vineyard-2026");
  });

  it("has no staff password and warns when STAFF_PASSWORD is missing or empty", () => {
    for (const env of [{}, { STAFF_PASSWORD: "" }]) {
      const config = loadConfig(env);
      expect(config.staffPassword).toBeUndefined();
      expect(config.warnings).toContain("STAFF_PASSWORD is not set, so staff sign-in is disabled.");
    }
  });

  it("uses SESSION_SECRET for signing staff sessions when it is set", () => {
    const config = loadConfig({ SESSION_SECRET: "a-long-secret" });
    expect(config.sessionSecret).toBe("a-long-secret");
    expect(config.warnings.join(" ")).not.toContain("SESSION_SECRET");
  });

  it("generates a random session secret and warns when SESSION_SECRET is missing", () => {
    const first = loadConfig({});
    const second = loadConfig({});
    expect(first.sessionSecret.length).toBeGreaterThanOrEqual(32);
    expect(first.sessionSecret).not.toBe(second.sessionSecret);
    expect(first.warnings.join(" ")).toContain("SESSION_SECRET");
  });

  it("marks cookies Secure only when SECURE_COOKIES is exactly 'true'", () => {
    expect(loadConfig({ SECURE_COOKIES: "true" }).secureCookies).toBe(true);
    expect(loadConfig({ SECURE_COOKIES: "1" }).secureCookies).toBe(false);
    expect(loadConfig({}).secureCookies).toBe(false);
  });
});
