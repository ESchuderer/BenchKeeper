import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../../src/server/app.js";
import { BookingStore } from "../../src/server/booking-store.js";

function appWithClient(clientDir: string) {
  return createApp({ store: new BookingStore(), staffPassword: "pw", sessionSecret: "s", clientDir });
}

describe("security headers", () => {
  it("sends a Content-Security-Policy that only allows the app's own origin by default", async () => {
    const response = await request(appWithClient("/nonexistent")).get("/api/tastings").expect(200);

    expect(response.headers["content-security-policy"]).toContain("default-src 'self'");
    expect(response.headers["content-security-policy"]).not.toContain("upgrade-insecure-requests");
  });

  it("forbids framing, disables MIME sniffing and hides the framework", async () => {
    const response = await request(appWithClient("/nonexistent")).get("/api/tastings").expect(200);

    expect(response.headers["x-frame-options"]).toBe("DENY");
    expect(response.headers["x-content-type-options"]).toBe("nosniff");
    expect(response.headers["x-powered-by"]).toBeUndefined();
  });
});

describe("staff responses", () => {
  it("are marked no-store so guest email addresses are not kept by browsers or shared caches", async () => {
    const app = createApp({ store: new BookingStore(), staffPassword: "pw", sessionSecret: "s" });

    const response = await request(app).get("/api/staff/overview").expect(401);

    expect(response.headers["cache-control"]).toBe("no-store");
  });
});
