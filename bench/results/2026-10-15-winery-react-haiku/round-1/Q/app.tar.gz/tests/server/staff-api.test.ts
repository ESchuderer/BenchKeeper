import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../../src/server/app.js";
import { BookingStore } from "../../src/server/booking-store.js";

const PASSWORD = "staff-secret";
const WINTER_BOOKINGS = "/api/tastings/winter-tasting/bookings";
const RIESLING_BOOKINGS = "/api/tastings/riesling-evening/bookings";

function setup() {
  const app = createApp({ store: new BookingStore(), staffPassword: PASSWORD, sessionSecret: "test-secret" });
  return { app, staff: request.agent(app) };
}

async function signIn(staff: ReturnType<typeof request.agent>) {
  await staff.post("/api/staff/session").send({ password: PASSWORD }).expect(204);
}

interface OverviewBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}
interface OverviewTasting {
  id: string;
  seatsLeft: number;
  bookings: OverviewBooking[];
}

describe("GET /api/staff/overview", () => {
  it("answers 401 without a staff session and returns no booking data", async () => {
    const { app } = setup();
    await request(app).post(WINTER_BOOKINGS).send({ name: "Anna", email: "anna@example.com", guests: 2 }).expect(201);

    const response = await request(app).get("/api/staff/overview").expect(401);

    expect(JSON.stringify(response.body)).not.toContain("anna@example.com");
  });

  it("groups every booking under its tasting with name, email, guests and reference", async () => {
    const { app, staff } = setup();
    await signIn(staff);
    const anna = await request(app)
      .post(WINTER_BOOKINGS)
      .send({ name: "Anna Keller", email: "anna@example.com", guests: 2 })
      .expect(201);
    const ben = await request(app)
      .post(RIESLING_BOOKINGS)
      .send({ name: "Ben Ruh", email: "ben@example.com", guests: 3 })
      .expect(201);

    const response = await staff.get("/api/staff/overview").expect(200);

    const tastings = response.body as OverviewTasting[];
    expect(tastings.map((tasting) => tasting.id)).toEqual([
      "riesling-evening",
      "red-wine-cellar-tour",
      "winter-tasting",
    ]);
    const riesling = tastings.find((tasting) => tasting.id === "riesling-evening")!;
    const winter = tastings.find((tasting) => tasting.id === "winter-tasting")!;
    expect(riesling.bookings).toEqual([
      { reference: ben.body.reference, name: "Ben Ruh", email: "ben@example.com", guests: 3 },
    ]);
    expect(winter.bookings).toEqual([
      { reference: anna.body.reference, name: "Anna Keller", email: "anna@example.com", guests: 2 },
    ]);
    expect(riesling.seatsLeft).toBe(9);
    expect(winter.seatsLeft).toBe(8);
  });

  it("shows a tasting with no bookings with an empty list", async () => {
    const { staff } = setup();
    await signIn(staff);

    const response = await staff.get("/api/staff/overview").expect(200);

    const redWine = (response.body as OverviewTasting[]).find((tasting) => tasting.id === "red-wine-cellar-tour")!;
    expect(redWine.bookings).toEqual([]);
  });
});

describe("DELETE /api/staff/bookings/:reference", () => {
  it("answers 401 without a staff session and leaves the booking in place", async () => {
    const { app, staff } = setup();
    const created = await request(app)
      .post(WINTER_BOOKINGS)
      .send({ name: "Anna", email: "anna@example.com", guests: 2 })
      .expect(201);

    await request(app).delete(`/api/staff/bookings/${created.body.reference}`).expect(401);

    await request(app).get(`/api/bookings/${created.body.reference}`).expect(200);
    await signIn(staff);
    const overview = await staff.get("/api/staff/overview").expect(200);
    const winter = (overview.body as OverviewTasting[]).find((tasting) => tasting.id === "winter-tasting")!;
    expect(winter.bookings).toHaveLength(1);
  });

  it("cancels the booking, frees its seats and removes it from the overview", async () => {
    const { app, staff } = setup();
    await signIn(staff);
    const created = await request(app)
      .post(RIESLING_BOOKINGS)
      .send({ name: "Ben", email: "ben@example.com", guests: 3 })
      .expect(201);

    await staff.delete(`/api/staff/bookings/${created.body.reference}`).expect(204);

    const tastings = await request(app).get("/api/tastings").expect(200);
    expect(tastings.body.find((t: { id: string }) => t.id === "riesling-evening").seatsLeft).toBe(12);
    const overview = await staff.get("/api/staff/overview").expect(200);
    const riesling = (overview.body as OverviewTasting[]).find((tasting) => tasting.id === "riesling-evening")!;
    expect(riesling.bookings).toEqual([]);
    await request(app).get(`/api/bookings/${created.body.reference}`).expect(404);
  });

  it("leaves other bookings untouched when one is cancelled", async () => {
    const { app, staff } = setup();
    await signIn(staff);
    const keep = await request(app).post(WINTER_BOOKINGS).send({ name: "Keep", email: "keep@example.com", guests: 1 }).expect(201);
    const drop = await request(app).post(WINTER_BOOKINGS).send({ name: "Drop", email: "drop@example.com", guests: 1 }).expect(201);

    await staff.delete(`/api/staff/bookings/${drop.body.reference}`).expect(204);

    await request(app).get(`/api/bookings/${keep.body.reference}`).expect(200);
  });

  it("reports a booking that no longer exists", async () => {
    const { staff } = setup();
    await signIn(staff);

    const response = await staff.delete("/api/staff/bookings/KB-ZZZZZZ").expect(404);

    expect(response.body).toEqual({ message: "This booking no longer exists" });
  });
});
