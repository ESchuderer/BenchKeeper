import request from "supertest";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createApp } from "../../src/server/app.js";
import { BookingStore } from "../../src/server/booking-store.js";

const PASSWORD = "correct-horse-battery";
const SESSION = "/api/staff/session";

function appWith(staffPassword: string | undefined) {
  return createApp({ store: new BookingStore(), staffPassword, sessionSecret: "test-secret" });
}

describe("staff sign-in", () => {
  it("reports that nobody is signed in on a fresh visit", async () => {
    const response = await request(appWith(PASSWORD)).get(SESSION).expect(200);

    expect(response.body).toEqual({ signedIn: false });
  });

  it("signs the visitor in with the correct password and keeps the session in a cookie", async () => {
    const agent = request.agent(appWith(PASSWORD));

    const signIn = await agent.post(SESSION).send({ password: PASSWORD }).expect(204);

    const cookie = String(signIn.headers["set-cookie"]);
    expect(cookie).toMatch(/httponly/i);
    expect(cookie).toMatch(/samesite=strict/i);
    const status = await agent.get(SESSION).expect(200);
    expect(status.body).toEqual({ signedIn: true });
  });

  it("refuses an incorrect password with a message for the password field", async () => {
    const agent = request.agent(appWith(PASSWORD));

    const response = await agent.post(SESSION).send({ password: "wrong" }).expect(401);

    expect(response.body).toEqual({ errors: { password: "Incorrect password" } });
    expect(await agent.get(SESSION).expect(200)).toHaveProperty("body", { signedIn: false });
  });

  it("asks for a password when none is sent", async () => {
    const response = await request(appWith(PASSWORD)).post(SESSION).send({}).expect(400);

    expect(response.body).toEqual({ errors: { password: "Enter the password" } });
  });

  it("refuses every sign-in when STAFF_PASSWORD is not configured", async () => {
    const agent = request.agent(appWith(undefined));

    const response = await agent.post(SESSION).send({ password: "anything" }).expect(503);

    expect(response.body).toEqual({ message: "Staff sign-in is not configured" });
    expect(await agent.get(SESSION).expect(200)).toHaveProperty("body", { signedIn: false });
  });

  it("ends the session on sign-out", async () => {
    const agent = request.agent(appWith(PASSWORD));
    await agent.post(SESSION).send({ password: PASSWORD }).expect(204);

    await agent.delete(SESSION).expect(204);

    expect(await agent.get(SESSION).expect(200)).toHaveProperty("body", { signedIn: false });
  });

  describe("session lifetime", () => {
    beforeEach(() => {
      vi.useFakeTimers({ toFake: ["Date"] });
      vi.setSystemTime(new Date("2026-10-14T09:00:00Z"));
    });

    afterEach(() => {
      vi.useRealTimers();
    });

    it("keeps the staff signed in for eight hours after sign-in and then requires the password again", async () => {
      const agent = request.agent(appWith(PASSWORD));
      await agent.post(SESSION).send({ password: PASSWORD }).expect(204);

      vi.setSystemTime(new Date("2026-10-14T16:59:00Z"));
      expect(await agent.get(SESSION).expect(200)).toHaveProperty("body", { signedIn: true });

      vi.setSystemTime(new Date("2026-10-14T17:01:00Z"));
      expect(await agent.get(SESSION).expect(200)).toHaveProperty("body", { signedIn: false });
    });
  });

  describe("failed sign-in attempts", () => {
    it("answers 429 on the 11th failed attempt within the window", async () => {
      const app = appWith(PASSWORD);

      for (let attempt = 0; attempt < 10; attempt += 1) {
        await request(app).post(SESSION).send({ password: "wrong" }).expect(401);
      }
      const limited = await request(app).post(SESSION).send({ password: "wrong" }).expect(429);

      expect(limited.body).toEqual({ message: "Too many sign-in attempts. Try again later." });
    });

    it("does not count successful sign-ins towards the limit", async () => {
      const agent = request.agent(appWith(PASSWORD));
      for (let attempt = 0; attempt < 5; attempt += 1) {
        await agent.post(SESSION).send({ password: "wrong" }).expect(401);
      }
      await agent.post(SESSION).send({ password: PASSWORD }).expect(204);
      for (let attempt = 0; attempt < 5; attempt += 1) {
        await agent.post(SESSION).send({ password: "wrong" }).expect(401);
      }

      await agent.post(SESSION).send({ password: "wrong" }).expect(429);
    });
  });
});
