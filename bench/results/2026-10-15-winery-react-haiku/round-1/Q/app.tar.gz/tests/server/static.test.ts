import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import request from "supertest";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createApp } from "../../src/server/app.js";
import { BookingStore } from "../../src/server/booking-store.js";

let clientDir: string;

beforeAll(() => {
  clientDir = mkdtempSync(path.join(tmpdir(), "kieselbrunnen-client-"));
  mkdirSync(path.join(clientDir, "assets"));
  writeFileSync(path.join(clientDir, "index.html"), "<!doctype html><title>KIESEL-APP</title>");
  writeFileSync(path.join(clientDir, "assets", "app.js"), "console.log('KIESEL-ASSET');");
});

afterAll(() => {
  rmSync(clientDir, { recursive: true, force: true });
});

function appWithClient() {
  return createApp({
    store: new BookingStore(),
    staffPassword: "test-password",
    sessionSecret: "test-secret",
    clientDir,
  });
}

describe("serving the client", () => {
  it("serves the start page at /", async () => {
    const response = await request(appWithClient()).get("/").expect(200);

    expect(response.text).toContain("KIESEL-APP");
  });

  it("serves the client app for deep links such as a booking confirmation or the staff page", async () => {
    const app = appWithClient();

    expect((await request(app).get("/bookings/KB-ABC123").expect(200)).text).toContain("KIESEL-APP");
    expect((await request(app).get("/staff").expect(200)).text).toContain("KIESEL-APP");
    expect((await request(app).get("/tastings/winter-tasting/book").expect(200)).text).toContain("KIESEL-APP");
  });

  it("serves built assets from their own paths", async () => {
    const response = await request(appWithClient()).get("/assets/app.js").expect(200);

    expect(response.text).toContain("KIESEL-ASSET");
  });

  it("answers unknown API paths with JSON 404, not the client app", async () => {
    const response = await request(appWithClient()).get("/api/unknown").expect(404);

    expect(response.body).toEqual({ message: "Not found" });
  });

  it("does not serve the client app when no client directory is configured", async () => {
    const app = createApp({ store: new BookingStore(), staffPassword: undefined, sessionSecret: "s" });

    await request(app).get("/staff").expect(404);
  });
});
