import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "../../src/server/app.js";
import { BookingStore } from "../../src/server/booking-store.js";

function testApp() {
  return createApp({ store: new BookingStore(), staffPassword: "test-password", sessionSecret: "test-secret" });
}

describe("GET /api/tastings", () => {
  it("lists the three tastings with their seats left on a fresh server", async () => {
    const response = await request(testApp()).get("/api/tastings").expect(200);

    expect(response.body).toEqual([
      expect.objectContaining({
        id: "riesling-evening",
        title: "Riesling Evening",
        date: "2026-11-06",
        time: "18:00",
        pricePerGuest: 25,
        seats: 12,
        seatsLeft: 12,
      }),
      expect.objectContaining({
        id: "red-wine-cellar-tour",
        title: "Red Wine Cellar Tour",
        date: "2026-11-14",
        time: "15:00",
        pricePerGuest: 32,
        seats: 8,
        seatsLeft: 8,
      }),
      expect.objectContaining({
        id: "winter-tasting",
        title: "Winter Tasting",
        date: "2026-12-05",
        time: "17:00",
        pricePerGuest: 28,
        seats: 10,
        seatsLeft: 10,
      }),
    ]);
  });
});
