import { describe, expect, it } from "vitest";
import { validateBooking } from "../../src/shared/booking-schema.js";

const valid = { name: "Anna Keller", email: "anna@example.com", guests: 2 };

describe("validateBooking", () => {
  it("accepts a complete booking", () => {
    const result = validateBooking(valid);
    expect(result).toEqual({ ok: true, data: valid });
  });

  it("trims surrounding whitespace from name and email", () => {
    const result = validateBooking({ ...valid, name: "  Anna Keller  ", email: "  anna@example.com " });
    expect(result).toEqual({ ok: true, data: valid });
  });

  it("rejects an empty name with a message for the name field", () => {
    expect(validateBooking({ ...valid, name: "   " })).toEqual({
      ok: false,
      errors: { name: "Enter your name" },
    });
  });

  it("rejects a name longer than 100 characters", () => {
    const result = validateBooking({ ...valid, name: "a".repeat(101) });
    expect(result).toEqual({ ok: false, errors: { name: "Name must be 100 characters or fewer" } });
  });

  it("rejects an empty email address", () => {
    expect(validateBooking({ ...valid, email: "" })).toEqual({
      ok: false,
      errors: { email: "Enter your email address" },
    });
  });

  it.each(["anna", "anna@", "@example.com", "anna@example", "anna example@x.com"])(
    "rejects the malformed email %j",
    (email) => {
      expect(validateBooking({ ...valid, email })).toEqual({
        ok: false,
        errors: { email: "Enter a valid email address" },
      });
    },
  );

  it.each([0, 9, -1, 2.5, Number.NaN])("rejects guests value %p with the range message", (guests) => {
    expect(validateBooking({ ...valid, guests })).toEqual({
      ok: false,
      errors: { guests: "Guests must be between 1 and 8" },
    });
  });

  it("rejects guests sent as text", () => {
    expect(validateBooking({ ...valid, guests: "2" })).toEqual({
      ok: false,
      errors: { guests: "Guests must be between 1 and 8" },
    });
  });

  it("accepts the boundaries 1 and 8 for guests", () => {
    expect(validateBooking({ ...valid, guests: 1 }).ok).toBe(true);
    expect(validateBooking({ ...valid, guests: 8 }).ok).toBe(true);
  });

  it("reports every invalid field at once", () => {
    expect(validateBooking({ name: "", email: "nope", guests: 0 })).toEqual({
      ok: false,
      errors: {
        name: "Enter your name",
        email: "Enter a valid email address",
        guests: "Guests must be between 1 and 8",
      },
    });
  });

  it("rejects a non-object body", () => {
    expect(validateBooking(undefined).ok).toBe(false);
  });
});
