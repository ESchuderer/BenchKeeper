import { describe, expect, it } from "vitest";
import { formatEuro, formatSeatsLeft, formatTastingDateTime, totalPrice } from "../../src/shared/format.js";
import { TASTINGS } from "../../src/shared/tastings.js";

describe("formatting", () => {
  it("multiplies the price per guest by the number of guests", () => {
    expect(totalPrice(TASTINGS[2]!, 2)).toBe(56);
  });

  it("formats an amount in euros", () => {
    expect(formatEuro(56)).toBe("EUR 56");
  });

  it("shows seats left in the agreed form", () => {
    expect(formatSeatsLeft(9)).toBe("9 seats left");
    expect(formatSeatsLeft(0)).toBe("0 seats left");
    expect(formatSeatsLeft(1)).toBe("1 seat left");
  });

  it("formats date and time without shifting by timezone", () => {
    expect(formatTastingDateTime("2026-11-06", "18:00")).toBe("Fri 6 Nov 2026, 18:00");
    expect(formatTastingDateTime("2026-12-05", "17:00")).toBe("Sat 5 Dec 2026, 17:00");
  });
});
