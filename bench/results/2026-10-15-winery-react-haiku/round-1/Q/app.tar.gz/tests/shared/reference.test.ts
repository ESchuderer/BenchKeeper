import { describe, expect, it } from "vitest";
import { REFERENCE_ALPHABET, generateReference } from "../../src/shared/reference.js";

describe("booking references", () => {
  it("uses the KB- prefix followed by six characters", () => {
    expect(generateReference()).toMatch(/^KB-[2-9A-HJ-NP-Z]{6}$/);
  });

  it("leaves out characters that are easily confused when read aloud or printed", () => {
    for (const ambiguous of ["0", "O", "1", "I", "L"]) {
      expect(REFERENCE_ALPHABET).not.toContain(ambiguous);
    }
  });

  it("produces different references across 1000 generations", () => {
    const references = new Set(Array.from({ length: 1000 }, () => generateReference()));
    expect(references.size).toBe(1000);
  });
});
