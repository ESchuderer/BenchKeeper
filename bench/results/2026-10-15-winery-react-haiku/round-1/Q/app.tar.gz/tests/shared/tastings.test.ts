import { describe, expect, it } from "vitest";
import { TASTINGS, findTasting, seatsLeft } from "../../src/shared/tastings.js";

describe("tasting catalogue", () => {
  it("offers the three scheduled tastings in order", () => {
    expect(TASTINGS.map((tasting) => tasting.title)).toEqual([
      "Riesling Evening",
      "Red Wine Cellar Tour",
      "Winter Tasting",
    ]);
  });

  it("gives each tasting its date, time, price per guest and seat count", () => {
    expect(TASTINGS).toEqual([
      expect.objectContaining({ id: "riesling-evening", date: "2026-11-06", time: "18:00", pricePerGuest: 25, seats: 12 }),
      expect.objectContaining({ id: "red-wine-cellar-tour", date: "2026-11-14", time: "15:00", pricePerGuest: 32, seats: 8 }),
      expect.objectContaining({ id: "winter-tasting", date: "2026-12-05", time: "17:00", pricePerGuest: 28, seats: 10 }),
    ]);
  });

  it("finds a tasting by id and returns undefined for an unknown id", () => {
    expect(findTasting("winter-tasting")?.title).toBe("Winter Tasting");
    expect(findTasting("does-not-exist")).toBeUndefined();
  });
});

describe("seatsLeft", () => {
  const winter = TASTINGS[2]!;

  it("equals the seat count when there are no bookings", () => {
    expect(seatsLeft(winter, [])).toBe(10);
  });

  it("subtracts the guests of bookings for this tasting only", () => {
    const bookings = [
      { tastingId: "winter-tasting", guests: 3 },
      { tastingId: "winter-tasting", guests: 2 },
      { tastingId: "riesling-evening", guests: 5 },
    ];
    expect(seatsLeft(winter, bookings)).toBe(5);
  });

  it("never goes below zero", () => {
    const bookings = [{ tastingId: "winter-tasting", guests: 10 }];
    expect(seatsLeft(winter, bookings)).toBe(0);
  });
});
