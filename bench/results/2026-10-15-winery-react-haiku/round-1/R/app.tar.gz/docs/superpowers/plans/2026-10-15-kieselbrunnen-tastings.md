# Kieselbrunnen Tasting Bookings Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking. No commit steps: this folder is not a git repository and commits are made only on request.

**Goal:** A web app where guests book wine tastings online and staff sign in to see and cancel bookings for Weingut Kieselbrunnen.

**Architecture:** One Node.js process. Express 5 serves a JSON API and the built React single-page app. Bookings live in an in-memory store with synchronous seat checks. Zod schemas in `src/shared` validate input on the client and on the server.

**Tech Stack:** TypeScript, Node.js 22, Express 5, React 19, Vite, react-router, react-hook-form, zod, Tailwind CSS v4, Vitest, supertest, React Testing Library, jsdom.

**Spec:** `docs/superpowers/specs/2026-10-15-kieselbrunnen-tastings-design.md`

## Global Constraints

- Node.js 22. `npm install`, then `npm run build`, then `npm start`. The server listens on `PORT` (default 3000).
- Environment variables: `PORT`, `STAFF_PASSWORD`. No other services.
- The app starts with no bookings. Storage is in memory.
- English UI. Money in whole euros, displayed as `EUR 25` (per guest) and `EUR 50` (total).
- Tastings, exactly:
  - `riesling-evening` | "Riesling Evening" | 2026-11-06 | 18:00 | 25 | 12
  - `red-wine-cellar-tour` | "Red Wine Cellar Tour" | 2026-11-14 | 15:00 | 32 | 8
  - `winter-tasting` | "Winter Tasting" | 2026-12-05 | 17:00 | 28 | 10
- Copy that must appear verbatim: "Book <title>", "Name", "Email", "Guests", "Book", "Booking confirmed", "<n> seats left", "Password", "Sign in", "Cancel". Staff sign-in uses one shared password.
- Guests: whole number 1 to 8. A booking never exceeds seats left.
- Time zone for "past": `Europe/Berlin`. Booking reference: `KB-` plus 6 characters from `23456789ABCDEFGHJKLMNPQRSTUVWXYZ`.
- Guest-facing API responses never include email addresses.

## Review Focus

1. Two guests race for the last seats (or a guest asks for more seats than are left): the second request gets 409 with the true seats left, and no seat count goes negative. Tests: Task 3 (store) and Task 4 (API).
2. Guests values `""`, `"0"`, `"9"`, `"1.5"`, `"abc"`, `"  "`, `null`, `true`: each is rejected with the guests message, never stored. Tests: Task 2 (schema), Task 4 (API).
3. Malformed JSON, a non-JSON body, or an unknown tasting id: a JSON error response, never an HTML stack trace or a 500 for client mistakes. Tests: Task 4 (API).
4. Cancelling an unknown id, or cancelling the same booking twice: 404 the second time, and seats are freed only once. Tests: Task 3 (store) and Task 5 (staff API).
5. Staff password: wrong, empty, differs only in case or trailing space, or `STAFF_PASSWORD` unset: never signed in; staff routes return 401 without a session cookie. Tests: Task 5 (staff API).

## Task 1: Project scaffold and toolchain

**Files:**
- Create: `package.json`, `tsconfig.json`, `tsconfig.server.json`, `vite.config.ts`, `vitest.config.ts`, `index.html`, `src/client/main.tsx`, `src/client/styles.css`, `.gitignore`

**Interfaces:**
- Consumes: nothing.
- Produces: scripts `dev`, `build` (`tsc -p tsconfig.server.json && vite build`), `start` (`node dist/server/index.js`), `test` (`vitest run`), `typecheck`. Server output goes to `dist/server`, client build to `dist/client`. Path aliases: none.

- [ ] **Step 1: Write the package and config files** with `"type": "module"`, pinned major versions for each dependency listed in Tech Stack, and `"engines": {"node": ">=22"}`. `tsconfig.json` covers `src/client`, `src/shared`, `tests` with `jsx: react-jsx`, `moduleResolution: bundler`, `noEmit`. `tsconfig.server.json` covers `src/server` and `src/shared` with `module: NodeNext`, `rootDir: src`, `outDir: dist`, so the server compiles to `dist/server/index.js`. `vitest.config.ts` includes `tests/**/*.test.{ts,tsx}`, default environment `node`.
- [ ] **Step 2: Write `src/client/main.tsx`** that mounts `<div id="root">` with a placeholder `<h1>` and imports `./styles.css`. `styles.css` starts with `@import "tailwindcss";`.
- [ ] **Step 3: Run** `npm install`. Expected: exit 0.
- [ ] **Step 4: Run** `npm run build`. Expected: exit 0 and `dist/server/index.js` plus `dist/client/index.html` exist. The server entry is a stub that prints "server stub" until Task 6.
- [ ] **Step 5: Run** `npx vitest run --passWithNoTests`. Expected: exit 0.

## Task 2: Shared domain: tastings, formatting, input schema

**Files:**
- Create: `src/shared/tastings.ts`, `src/shared/format.ts`, `src/shared/booking-schema.ts`, `src/shared/types.ts`
- Test: `tests/shared/format.test.ts`, `tests/shared/booking-schema.test.ts`

**Interfaces:**
- Produces:
  - `tastings: readonly Tasting[]` and `Tasting = { id: string; title: string; date: string; time: string; pricePerGuest: number; seats: number }` (`date` is `YYYY-MM-DD`, `time` is `HH:MM`).
  - `getTasting(id: string): Tasting | undefined`
  - `formatPrice(euros: number): string` returns `"EUR 25"`.
  - `formatDateTime(date: string, time: string): string` returns `"Friday, 6 November 2026, 18:00"` (no time-zone conversion; compute the weekday with `Date.UTC`).
  - `isTastingPast(tasting: Tasting, now: Date): boolean` compares `date + "T" + time` with the wall-clock time in `Europe/Berlin`, using `Intl.DateTimeFormat(...).formatToParts`.
  - `bookingInputSchema` (zod): `{ name, email, guests }` after trim. Output type `BookingInput = { name: string; email: string; guests: number }`.
  - `BookingInputErrors = Partial<Record<"name" | "email" | "guests", string>>`.
  - Guests accepts a number or a digit-only string (trimmed), and must be an integer from 1 to 8. Anything else gets "Please enter between 1 and 8 guests."
  - Name: trimmed, required, at most 100 characters. Message "Please enter your name."
  - Email: trimmed, required, at most 254 characters, matches `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`. Message "Please enter a valid email address."
  - `types.ts` holds the API response types: `TastingView`, `BookingView`, `StaffBookingsResponse`, `ApiErrorBody`. Their exact shapes are in Task 4 and Task 5.

- [ ] **Step 1: Write failing tests.** `format.test.ts`: `formatPrice(25) === "EUR 25"`; `formatDateTime("2026-11-06","18:00") === "Friday, 6 November 2026, 18:00"`; `isTastingPast` is false at `2026-11-06T17:59` Berlin time and true at `18:00` Berlin time (use `new Date("2026-11-06T16:59:00Z")` for 17:59 Berlin, CET). `booking-schema.test.ts`: valid input parses and trims; each of `""`, `"0"`, `"9"`, `"1.5"`, `"abc"`, `"  "`, `null`, `true` fails only on `guests` with the guests message; `" 2 "` parses to 2; blank name and 101-character name fail on `name`; `"ann@"` and `"a b@c.de"` fail on `email`.
- [ ] **Step 2: Run** `npx vitest run tests/shared`. Expected: FAIL, modules missing.
- [ ] **Step 3: Implement** the four files to the interfaces above.
- [ ] **Step 4: Run** `npx vitest run tests/shared`. Expected: PASS.

## Task 3: Booking store (seat logic)

**Files:**
- Create: `src/server/store.ts`
- Test: `tests/server/store.test.ts`

**Interfaces:**
- Consumes: `tastings`, `getTasting`, `isTastingPast`, `BookingInput`.
- Produces:
  - `type BookingRecord = { id: string; reference: string; tastingId: string; name: string; email: string; guests: number; createdAt: string }`
  - `type BookResult = { ok: true; booking: BookingRecord } | { ok: false; code: "NOT_FOUND" | "CLOSED" | "FULLY_BOOKED" | "INSUFFICIENT_SEATS"; seatsLeft: number }`
  - `class BookingStore { constructor(options?: { now?: () => Date }); seatsLeft(tastingId: string): number; book(tastingId: string, input: BookingInput): BookResult; findByReference(reference: string): BookingRecord | undefined; listBookings(): BookingRecord[]; cancel(id: string): boolean }`
- `seatsLeft` for an unknown id returns 0. `book` checks in this order: unknown tasting (NOT_FOUND), past (CLOSED), seats left 0 (FULLY_BOOKED), guests greater than seats left (INSUFFICIENT_SEATS). The check and insert run in one synchronous call.

- [ ] **Step 1: Write failing tests:**
  - `starts empty`: `listBookings()` is `[]`, `seatsLeft("riesling-evening") === 12`.
  - `reduces seats by guests`: after booking 3, `seatsLeft === 9`.
  - `accepts the last seats exactly`: book 8 on Red Wine (8 seats) succeeds, then one more guest gets `FULLY_BOOKED`.
  - `rejects more guests than seats left`: 5 of 8 booked, request 4 → `INSUFFICIENT_SEATS`, `seatsLeft: 3`, and nothing stored.
  - `no overbooking in a burst`: 20 synchronous `book` calls of 1 guest each on Riesling (12 seats) → exactly 12 `ok` results, and `seatsLeft` ends at 0.
  - `cancel frees seats`: cancel the booking, `seatsLeft` goes back up.
  - `cancel unknown or twice`: first cancel `true`, second `false`, seats freed only once.
  - `references are unique and well formed`: 500 bookings, all match `/^KB-[2-9A-HJ-NP-Z]{6}$/` and are distinct; `findByReference` finds each.
  - `closed tastings`: with `now` set to 2026-11-07, booking riesling returns `CLOSED`.
  - `unknown tasting`: `NOT_FOUND`; `seatsLeft("nope") === 0`.
- [ ] **Step 2: Run** `npx vitest run tests/server/store.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** `store.ts`. Use `crypto.randomInt` for references and `crypto.randomUUID` for ids.
- [ ] **Step 4: Run** the same command. Expected: PASS.

## Task 4: Public HTTP API (tastings and guest bookings)

**Files:**
- Create: `src/server/app.ts`
- Test: `tests/server/api-public.test.ts`

**Interfaces:**
- Consumes: `BookingStore`, `tastings`, `bookingInputSchema`, `formatPrice`, `isTastingPast`.
- Produces: `createApp(options: { store?: BookingStore; now?: () => Date; staffPassword?: string | undefined; clientDir?: string }): Express`. Task 5 extends `app.ts` with staff routes. Task 6 uses `clientDir` for static files.
- Types (in `src/shared/types.ts`):
  - `TastingView = { id; title; date; time; pricePerGuest; seats; seatsLeft: number; status: "open" | "fully_booked" | "closed" }`
  - `BookingView = { reference; tastingId; tastingTitle; date; time; guests: number; pricePerGuest: number; total: number }`. No name or email.
  - `ApiErrorBody = { error: string; fieldErrors?: Record<string, string> }`
- Routes:
  - `GET /api/tastings` → 200 `TastingView[]`. `status`: closed if past, else fully_booked if `seatsLeft === 0`, else open.
  - `POST /api/tastings/:id/bookings` with JSON `{name, email, guests}` → 201 `BookingView`. Errors:
    - 400 with `fieldErrors` for invalid input (including malformed JSON, which is also a JSON 400 with `error` "Request body must be JSON.").
    - 404 `{error: "Tasting not found."}`.
    - 409 `{error: "This tasting has already taken place."}` for CLOSED.
    - 409 `{error: "This tasting is fully booked."}` for FULLY_BOOKED.
    - 409 with `fieldErrors: {guests: "Only <n> seats left."}` and `error: "Not enough seats left."` for INSUFFICIENT_SEATS.
  - `GET /api/bookings/:reference` → 200 `BookingView`, or 404 `{error: "Booking not found."}`.
  - Unknown `/api/*` → 404 JSON `{error: "Not found."}`.
  - JSON body parser limit 10 kb. An error handler converts parser errors to JSON.

- [ ] **Step 1: Write failing supertest tests** in `api-public.test.ts`:
  - `GET /api/tastings` returns three items with the spec values, `seatsLeft` 12/8/10, and no `email` keys anywhere.
  - Valid POST returns 201 with `total: 50` for 2 guests of Riesling, `pricePerGuest: 25`, a reference matching `/^KB-/`, and no `email` or `name` keys.
  - Each Review Focus item 2 value (`""`, `"0"`, `"9"`, `"1.5"`, `"abc"`, `"  "`, `null`, `true`) returns 400 with `fieldErrors.guests` and the message from Task 2.
  - Blank name → 400 `fieldErrors.name`; bad email → 400 `fieldErrors.email`; all three problems together → all three fields in `fieldErrors`.
  - Malformed JSON body (`"{"`) → 400 JSON with `error`, `content-type` JSON.
  - Non-JSON content type with a valid body → 400 JSON.
  - Unknown tasting id → 404 JSON. Unknown `/api/whatever` → 404 JSON.
  - Review Focus item 1: after 10 of 12 Riesling seats are booked, a request for 3 guests returns 409, `fieldErrors.guests === "Only 2 seats left."`, and `GET /api/tastings` still shows `seatsLeft: 2`. A request for 2 succeeds.
  - Fully booked tasting: the next POST returns 409 "This tasting is fully booked.", and the tasting listing shows `status: "fully_booked"`.
  - Closed tasting (created app with `now` on 2026-11-07): listing `status: "closed"`, POST returns 409 "This tasting has already taken place."
  - `GET /api/bookings/<reference>` returns the view without email; unknown reference → 404.
- [ ] **Step 2: Run** `npx vitest run tests/server/api-public.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** `app.ts` with `express.json({ limit: "10kb" })`, the routes, and error middleware. Do not add the static handler yet.
- [ ] **Step 4: Run** the same command. Expected: PASS. Also run `npx vitest run` for the full suite.

## Task 5: Staff authentication and staff API

**Files:**
- Create: `src/server/staff-auth.ts`
- Modify: `src/server/app.ts` (add staff routes; add `staffPassword` handling)
- Test: `tests/server/api-staff.test.ts`

**Interfaces:**
- Consumes: `BookingStore`, `createApp` options.
- Produces:
  - `class StaffSessions { create(): string; isValid(token: string | undefined): boolean; revoke(token: string | undefined): void }`
  - `verifyStaffPassword(candidate: unknown, expected: string | undefined): "ok" | "wrong" | "not_configured"`. Compares SHA-256 digests with `timingSafeEqual`. A missing or empty `expected` returns `"not_configured"`. A non-string or empty candidate returns `"wrong"`.
  - `type StaffBookingsResponse = { tastings: { id; title; date; time; seats; seatsLeft; bookings: { id; reference; name; email; guests }[] }[] }`, one entry per tasting in order, including tastings with no bookings.
- Routes:
  - `POST /api/staff/session` `{password}` → 204 and `Set-Cookie: staff_session=<token>; HttpOnly; SameSite=Strict; Path=/`. Wrong password → 401 `{error: "Incorrect password."}`. Not configured → 503 `{error: "Staff sign-in is not configured."}`. Missing `password` key → 400 `{error: "Password is required.", fieldErrors: {password: "Password is required."}}`.
  - `DELETE /api/staff/session` → 204, revokes the cookie's token, clears the cookie.
  - `GET /api/staff/bookings` → 200 `StaffBookingsResponse`, or 401 `{error: "Staff sign-in required."}`.
  - `DELETE /api/staff/bookings/:id` → 204; 401 without a session; 404 `{error: "Booking not found."}` for an unknown or already cancelled id.
- Cookie parsing: read `staff_session` from the `Cookie` header with a small parser (no extra dependency needed). Use the `cookie-parser` package if preferred; either is acceptable.

- [ ] **Step 1: Write failing supertest tests** in `api-staff.test.ts` with `staffPassword: "s3cret-Pass"` in the app options:
  - `GET /api/staff/bookings` without cookie → 401; with a forged cookie `staff_session=abc` → 401.
  - Wrong password `"nope"` → 401. Empty `""` → 401. `"S3CRET-PASS"` → 401. `"s3cret-Pass "` (trailing space) → 401. Missing key → 400 with `fieldErrors.password`.
  - Correct password → 204 and a `Set-Cookie` header containing `HttpOnly` and `SameSite=Strict`.
  - With the cookie: bookings listing has three tastings in order, each with the bookings grouped; guest email and name appear here; `password` never appears in any response body.
  - Staff cancel: after a booking, `DELETE /api/staff/bookings/:id` → 204; the public listing shows the seats freed; a second `DELETE` → 404; an unknown id → 404; without cookie → 401 and the booking remains.
  - Logout: after `DELETE /api/staff/session`, the same cookie gets 401.
  - App created with no `staffPassword` (undefined) and with `""`: sign-in with any password → 503 "Staff sign-in is not configured."; a request to the sign-in with an empty password still returns 503 (not 401) in that case.
  - `verifyStaffPassword` unit cases: `"ok"`, `"wrong"` for each wrong candidate above, `"not_configured"` for undefined and `""`.
- [ ] **Step 2: Run** `npx vitest run tests/server/api-staff.test.ts`. Expected: FAIL.
- [ ] **Step 3: Implement** `staff-auth.ts` and the staff routes in `app.ts`. Sessions live in memory (`Map` of token → true, tokens from `crypto.randomBytes(32).toString("base64url")`).
- [ ] **Step 4: Run** the same command, then `npx vitest run`. Expected: PASS.

## Task 6: Server entry, configuration, and static app serving

**Files:**
- Create: `src/server/config.ts`, `src/server/index.ts`
- Modify: `src/server/app.ts` (static serving and SPA fallback when `clientDir` is given)
- Test: `tests/server/config.test.ts`, `tests/server/static.test.ts`

**Interfaces:**
- Produces:
  - `readConfig(env: NodeJS.ProcessEnv): { port: number; staffPassword: string | undefined }`. Default port 3000. A non-integer or out-of-range `PORT` (outside 1 to 65535) throws `Error("PORT must be a number between 1 and 65535.")`. An empty `STAFF_PASSWORD` is treated as unset.
  - `index.ts`: reads config, warns on stdout ("STAFF_PASSWORD is not set; staff sign-in is disabled.") when unset, creates the app with `clientDir = resolve(dirname(fileURLToPath(import.meta.url)), "../client")`, and listens on `port`.
- `app.ts` with `clientDir`: `express.static(clientDir)`. Any GET that is not under `/api` and does not look like a file (no dot in the last path segment) returns `index.html`. A GET with a file extension that is missing returns 404 text.

- [ ] **Step 1: Write failing tests.** `config.test.ts`: default 3000; `PORT: "8080"` → 8080; `PORT: "abc"` throws; `PORT: "70000"` throws; `STAFF_PASSWORD: ""` gives `undefined`; `STAFF_PASSWORD: "x"` gives `"x"`. `static.test.ts` uses a temp directory containing `index.html` and `assets/app.js`:
  - `GET /` and `GET /tastings/riesling-evening/book` and `GET /staff` return the `index.html` content.
  - `GET /assets/app.js` returns the file.
  - `GET /assets/missing.js` returns 404 (not `index.html`).
  - `GET /api/tastings` still returns JSON.
- [ ] **Step 2: Run** the two test files. Expected: FAIL.
- [ ] **Step 3: Implement** `config.ts`, `index.ts`, and the static handler.
- [ ] **Step 4: Run** `npm run build && PORT=3111 STAFF_PASSWORD=pw npm start` in the background. Then `curl -s localhost:3111/api/tastings` returns three tastings and `curl -s -o /dev/null -w "%{http_code}" localhost:3111/staff` returns 200. Stop the process. Expected: both as described.

## Task 7: Client API layer, routing shell, and layout

**Files:**
- Create: `src/client/api.ts`, `src/client/App.tsx`, `src/client/components/Layout.tsx`, `src/client/pages/NotFoundPage.tsx`
- Modify: `src/client/main.tsx` (render `App` inside `BrowserRouter`)
- Test: `tests/client/api.test.ts`, `tests/client/App.test.tsx`

**Interfaces:**
- Produces:
  - `class ApiError extends Error { status: number; fieldErrors: Record<string, string> }`
  - `api.getTastings(): Promise<TastingView[]>`, `api.getBooking(ref): Promise<BookingView>`, `api.createBooking(tastingId, input): Promise<BookingView>`, `api.staffSession(): Promise<StaffBookingsResponse | null>` (null when not signed in, 401), `api.staffSignIn(password): Promise<void>` (throws ApiError with status 401 or 503), `api.staffSignOut(): Promise<void>`, `api.staffBookings(): Promise<StaffBookingsResponse>` (throws ApiError 401 when not signed in), `api.cancelBooking(id): Promise<void>`.
  - All responses that are not JSON or not OK throw `ApiError` with a message; a non-JSON body gives the message "Something went wrong. Please try again."
  - Routes in `App.tsx`: `/`, `/tastings/:id/book`, `/bookings/:reference`, `/staff`, `*` (NotFoundPage "Page not found").
  - `Layout` renders the header with "Weingut Kieselbrunnen", subtitle "Tastings & bookings", a link to "/", and a footer. The `main` landmark wraps the page.

- [ ] **Step 1: Write failing tests.** `api.test.ts` mocks `fetch` with `vi.stubGlobal`: a 400 JSON response becomes an `ApiError` with `status 400` and the `fieldErrors`; an HTML 500 response gives the generic message; `staffSession` returns null for 401. `App.test.tsx` (jsdom): rendering `/` at `MemoryRouter` shows the header "Weingut Kieselbrunnen"; unknown path shows "Page not found".
- [ ] **Step 2: Run** `npx vitest run tests/client`. Expected: FAIL.
- [ ] **Step 3: Implement** the files. Use `fetch` with `credentials: "same-origin"`, `Content-Type: application/json` on POST, and `Accept: application/json`.
- [ ] **Step 4: Run** the same command. Expected: PASS.

## Task 8: Tastings page (start page)

**Files:**
- Create: `src/client/pages/TastingsPage.tsx`, `src/client/components/TastingCard.tsx`
- Modify: `src/client/App.tsx` (use the page on `/`)
- Test: `tests/client/TastingsPage.test.tsx`

**Interfaces:**
- Consumes: `api.getTastings`, `formatDateTime`, `formatPrice`.
- Produces: `TastingsPage` (default export), which renders a loading state ("Loading tastings…"), an error state with `role="alert"`, and the list. Each `TastingCard` has: the title as `h2`; date and time via `formatDateTime`; "EUR 25 per guest" via `formatPrice`; a badge "<n> seats left" when open, "Fully booked" when `fully_booked`, "Booking closed" when `closed`; a link "Book <title>" to `/tastings/<id>/book` only when open (for `fully_booked` and `closed`, show the badge and no link).
- A badge with exactly 1 seat left reads "1 seat left" (singular). Otherwise "<n> seats left".

- [ ] **Step 1: Write failing tests** with a mocked `api.getTastings` returning the three tastings (12, 8, 10 seats left): the three titles are present; "12 seats left", "8 seats left", "10 seats left" appear; the link `Book Riesling Evening` has href `/tastings/riesling-evening/book`; a fully booked fixture shows "Fully booked" and no "Book Winter Tasting" link; a closed fixture shows "Booking closed"; "1 seat left" singular case; an API failure shows the alert.
- [ ] **Step 2: Run** `npx vitest run tests/client/TastingsPage.test.tsx`. Expected: FAIL.
- [ ] **Step 3: Implement** the page and card.
- [ ] **Step 4: Run** the same command. Expected: PASS.

## Task 9: Booking page (form)

**Files:**
- Create: `src/client/pages/BookingPage.tsx`, `src/client/components/Field.tsx`
- Modify: `src/client/App.tsx` (route `/tastings/:id/book`)
- Test: `tests/client/BookingPage.test.tsx`

**Interfaces:**
- Consumes: `api.getTastings` (to find the tasting and its seats left), `api.createBooking`, `bookingInputSchema` via `zodResolver`, `formatPrice`, `formatDateTime`.
- Produces: `BookingPage`. It shows the tasting title as `h1`, the date and time, and the price per guest. Form fields: label "Name" (`<input name="name" autoComplete="name">`), label "Email" (`type="email"`), label "Guests" (`type="number"`, `min=1`, `max=min(8, seatsLeft)`, `inputMode="numeric"`), button "Book". Each error is in a `<p>` directly after its field with an id referenced by `aria-describedby`, and the input has `aria-invalid="true"`.
- Behaviour:
  - Client validation runs on submit with the shared schema (guests cap is the server rule; the client shows "Only <n> seats left." when the value is larger than seats left).
  - On a 409 or 400 with `fieldErrors`, the matching messages appear next to their fields. Other errors appear in a `role="alert"` box.
  - On success, navigate to `/bookings/<reference>` with `replace`.
  - Button shows "Booking…" and is disabled while submitting.
  - Fully booked: show "This tasting is fully booked." and no form. Closed: show "Booking closed for this tasting." and no form. Unknown id: show "Page not found" text.
- A tasting is treated as open only when `status === "open"`.

- [ ] **Step 1: Write failing tests** (jsdom, `MemoryRouter` at `/tastings/riesling-evening/book`, mocked api):
  - Shows heading "Riesling Evening", "EUR 25" per guest, and the three labelled fields and the "Book" button.
  - Submitting empty shows "Please enter your name.", "Please enter a valid email address.", and the guests message next to their fields with `aria-invalid="true"`.
  - Guests `9` shows the guests message; `0` also; `1.5` also.
  - A valid submit calls `api.createBooking("riesling-evening", {name, email, guests: 2})` and navigates to `/bookings/KB-TEST12`.
  - Server 409 with `fieldErrors.guests` "Only 2 seats left." shows that text next to Guests.
  - Server 409 generic message shows in the alert.
  - Fully booked fixture shows "This tasting is fully booked." and no "Book" button.
  - Closed fixture shows "Booking closed for this tasting." and no form.
  - While submitting, the button reads "Booking…" and is disabled.
- [ ] **Step 2: Run** `npx vitest run tests/client/BookingPage.test.tsx`. Expected: FAIL.
- [ ] **Step 3: Implement** the page and field component with react-hook-form (`mode: "onSubmit"`, `reValidateMode: "onChange"`).
- [ ] **Step 4: Run** the same command. Expected: PASS.

## Task 10: Confirmation page

**Files:**
- Create: `src/client/pages/ConfirmationPage.tsx`
- Modify: `src/client/App.tsx` (route `/bookings/:reference`)
- Test: `tests/client/ConfirmationPage.test.tsx`

**Interfaces:**
- Consumes: `api.getBooking`, `formatPrice`, `formatDateTime`.
- Produces: `ConfirmationPage`. Heading `h1` "Booking confirmed". Definition list with "Tasting", "Date and time", "Guests", "Total", "Booking reference". The total uses `formatPrice(total)`. Unknown reference shows "Booking not found." with a link back to "/". Link "Back to all tastings" to `/`.

- [ ] **Step 1: Write failing tests:** mocked `getBooking` returning `{reference: "KB-TEST12", tastingTitle: "Riesling Evening", date: "2026-11-06", time: "18:00", guests: 2, total: 50, ...}` shows "Booking confirmed", "Riesling Evening", "2", "EUR 50", "KB-TEST12"; a rejected `getBooking` (404) shows "Booking not found.".
- [ ] **Step 2: Run** `npx vitest run tests/client/ConfirmationPage.test.tsx`. Expected: FAIL.
- [ ] **Step 3: Implement** the page.
- [ ] **Step 4: Run** the same command. Expected: PASS.

## Task 11: Staff page

**Files:**
- Create: `src/client/pages/StaffPage.tsx`, `src/client/components/StaffBookingsList.tsx`
- Modify: `src/client/App.tsx` (route `/staff`)
- Test: `tests/client/StaffPage.test.tsx`

**Interfaces:**
- Consumes: `api.staffSession`, `api.staffSignIn`, `api.staffSignOut`, `api.staffBookings`, `api.cancelBooking`.
- Produces:
  - Signed out: heading "Staff sign-in"; label "Password" (`type="password"`); button "Sign in". A wrong password shows "Incorrect password." in a `role="alert"`. 503 shows "Staff sign-in is not configured." Empty submit shows "Password is required." next to the field.
  - Signed in: heading "Bookings", a "Sign out" button, and for each tasting a section with its title, date and time, and "<n> seats left". The bookings table has columns Name, Email, Guests, Reference, and a "Cancel" button per row. A tasting with no bookings shows "No bookings yet." Cancelling calls `api.cancelBooking` and refreshes the list. An error shows in the alert.
  - On page load: if `api.staffSession()` returns data, show it immediately; otherwise show sign-in.

- [ ] **Step 1: Write failing tests** with mocked api:
  - Initially signed out: "Password" field, "Sign in" button.
  - Wrong password → "Incorrect password." shown.
  - Correct password → the grouped bookings appear with names, emails, guest counts, references, and one "Cancel" per booking.
  - A tasting with no bookings shows "No bookings yet.".
  - Clicking "Cancel" calls `cancelBooking` with the booking id, and the row disappears after the list refreshes.
  - "Sign out" calls `staffSignOut` and shows sign-in again.
  - Session present on load (`staffSession` returns data) → bookings shown without sign-in.
- [ ] **Step 2: Run** `npx vitest run tests/client/StaffPage.test.tsx`. Expected: FAIL.
- [ ] **Step 3: Implement** the page and list component.
- [ ] **Step 4: Run** the same command. Expected: PASS.

## Task 12: Visual design and responsive layout

**Files:**
- Modify: `src/client/styles.css` (theme tokens with `@theme`), `src/client/components/Layout.tsx`, `src/client/components/TastingCard.tsx`, `src/client/pages/*.tsx` (class names only)
- Test: none (visual). Verification is in Task 13.

**Interfaces:**
- Consumes: the palette and typography from the spec, section 7.
- Produces: `@theme` tokens (`--color-cream`, `--color-bordeaux`, `--color-slate`, `--color-gold`, `--color-success`, `--color-danger`, `--font-serif` as a system serif stack), `.btn-primary`, `.card`, `.badge-*`, and `.field-error` utility classes in `styles.css` (via `@layer components`). Pages keep their labels and text unchanged.

- [ ] **Step 1: Apply the design.** Serif headings, cream background, bordeaux primary buttons with at least 44 px height, cards with a soft border, badges for open, fully booked, and closed, and a green success card on the confirmation page. Forms are single column on phones, two-column grid on wider screens for Name/Email in booking.
- [ ] **Step 2: Run** `npm run build` and `npx vitest run`. Expected: both exit 0 (tests unchanged, only classes changed).
- [ ] **Step 3: Check the layout in a browser** (Task 13 step 4). Expected: no horizontal scroll at 360 px width.

## Task 13: Full verification

**Files:** none changed unless a check fails.

- [ ] **Step 1: Run** `npm run typecheck`. Expected: exit 0.
- [ ] **Step 2: Run** `npm test`. Expected: all tests pass, with no warnings in the output.
- [ ] **Step 3: Run** a clean install and build: `rm -rf node_modules dist && npm install && npm run build`. Expected: exit 0.
- [ ] **Step 4: Run the app** `PORT=3123 STAFF_PASSWORD=winery-test npm start` in the background. Check: `curl -s localhost:3123/` contains the app shell; `curl -s localhost:3123/api/tastings` lists three tastings; create a booking with curl and check the 201 body; try the Review Focus cases with curl; sign in to `/api/staff/session`; cancel; stop the server. Optionally run a headless browser check through `@playwright/test` if Chromium can be installed; if not, record that it was not run.
- [ ] **Step 5: Fix any failure** with a test first (TDD), re-run the failing check, and repeat Steps 1 to 4.

## Task 14: Independent review

- [ ] **Step 1:** Dispatch a fresh reviewer (`general` subagent) with the spec, this plan, and the file list. The reviewer checks the spec coverage, the Review Focus tests, and the code quality, and reports issues by severity. It only reads files.
- [ ] **Step 2:** Fix every Important or Critical finding with a test first, then re-run `npm test` and `npm run build`.
