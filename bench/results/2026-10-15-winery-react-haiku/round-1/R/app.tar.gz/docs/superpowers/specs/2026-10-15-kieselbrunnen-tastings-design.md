# Weingut Kieselbrunnen Tasting Bookings - Design

Status: approved by the requester in the original request. Decisions marked
**(my call)** were made by the builder and are open to change.

## 1. Intent

Guests book wine tastings online instead of by phone. Staff see who is
coming to each tasting and can cancel a booking, which frees its seats.

Success means:
- A guest on a phone can book a tasting in about a minute, with no
  question about whether it is still possible.
- No tasting is ever overbooked, including when two guests book at the
  same moment.
- Staff can see, per tasting, who is coming and how to find their booking.

## 2. Goals

- Start page lists the three tastings with title, date and time, price per
  guest, and seats left shown as "<n> seats left".
- Each tasting has a button "Book <tasting title>" that opens its booking
  form.
- Booking form: fields labelled "Name", "Email", "Guests" (integer 1 to 8),
  and a button "Book".
- A booking can never take more seats than are left.
- Invalid input is rejected with an error message next to the field it
  concerns.
- Confirmation page after booking: heading "Booking confirmed", the
  tasting, the number of guests, the total price, and a booking reference.
- `/staff` asks for a "Password" field and a "Sign in" button. The password
  comes from the environment variable `STAFF_PASSWORD`.
- Signed-in staff see all bookings grouped by tasting (name, email, guests,
  reference) and can cancel a booking with a "Cancel" button. A cancelled
  booking frees its seats.
- Visual design that looks like a small winery's own site: coherent,
  polished, with clear error, success and fully-booked states, usable on a
  phone.
- Built with React. Established libraries for server, routing, forms and
  styling.
- `npm install`, `npm run build`, `npm start`. The server listens on `PORT`
  (default 3000). Node.js 22. No external services.
- The interface is in English.

## 3. Non-goals

- Payment. The total is displayed only.
- Emails to guests. No confirmation email is sent.
- Guest accounts, editing a booking, or rescheduling.
- Managing tastings through the UI. Tastings are fixed data in code.
- Multiple languages.

## 4. Anti-goals (failure even if the happy path works)

- Overbooking under any input or timing, including concurrent bookings.
- The staff password appearing in the client bundle, in the repository, or
  in an API response.
- Guest email addresses readable through the public API.
- A crash or blank page on malformed input (bad JSON, non-numeric guests,
  unknown tasting or reference).

## 5. Constraints

- Node.js 22, npm, no network services at runtime.
- Only the environment variables `PORT` and `STAFF_PASSWORD`.
- The app starts with no bookings.

## 6. How it is built (my call unless stated)

- **Language:** TypeScript throughout.
- **Server:** Express 5 serving the JSON API and the built React app.
- **Client:** React 19 single-page app built with Vite.
- **Routing:** react-router (v7 or later).
- **Forms:** react-hook-form with zod schemas. The same zod schemas are
  used in the client (immediate feedback) and in the server (authoritative).
- **Styling:** Tailwind CSS v4 via its Vite plugin. No web fonts from
  external hosts; use a system serif stack for headings.
- **Tests:** Vitest for the server and the client. supertest for HTTP
  tests. React Testing Library with jsdom for components.
- **Storage:** in-memory store (a Map) inside the server process. Bookings
  are lost on restart. This matches "the app starts with no bookings" and
  the spec's allowance for memory storage.
- **Concurrency:** the seat check and the insert run synchronously in one
  event-loop turn, so two requests cannot both take the last seat. The app
  runs as a single process.
- **Tastings:** defined in code in `src/shared/tastings.ts`:

  | id | title | date | time | price per guest (EUR) | seats |
  |---|---|---|---|---|---|
  | riesling-evening | Riesling Evening | 2026-11-06 | 18:00 | 25 | 12 |
  | red-wine-cellar-tour | Red Wine Cellar Tour | 2026-11-14 | 15:00 | 32 | 8 |
  | winter-tasting | Winter Tasting | 2026-12-05 | 17:00 | 28 | 10 |

- **Seats left:** seats minus the sum of guests over all current bookings
  for that tasting. Cancelling removes the booking from the store.
- **Booking reference:** `KB-` followed by 6 characters from an unambiguous
  alphabet (no 0, O, 1, I), generated with `crypto.randomInt`. A collision
  is re-drawn.
- **Money:** prices are whole euros. Display is `EUR 25` per guest and
  `EUR 50` for a total of two guests.
- **Dates:** stored as `YYYY-MM-DD` and `HH:MM` strings. Formatted without
  time-zone conversion, for example "Friday, 6 November 2026, 18:00".
- **Pages (client routes):**
  - `/` - tastings list
  - `/tastings/:id/book` - booking form
  - `/bookings/:reference` - confirmation
  - `/staff` - sign-in, then bookings grouped by tasting
- **API:**
  - `GET /api/tastings` - tastings with `seatsLeft`
  - `POST /api/tastings/:id/bookings` `{name, email, guests}` - 201 with the
    booking, or 400 with `fieldErrors`, or 404 unknown tasting, or 409 when
    the request is larger than the seats left
  - `GET /api/bookings/:reference` - booking view without the email address
  - `POST /api/staff/session` `{password}` - 204 and sets a cookie; 400 when
    the password is missing or empty; 401 on a wrong password; 429 after five
    failures from one address in 15 minutes (the lock lifts when the window
    ends, and a success clears the count); 503 when `STAFF_PASSWORD` is unset
  - `DELETE /api/staff/session` - 204, clears the cookie
  - `GET /api/staff/bookings` - 401 unless signed in; bookings grouped by
    tasting, with email
  - `DELETE /api/staff/bookings/:id` - 204; 401 unless signed in; 404 for an
    unknown id
  - Errors are JSON `{error: string, fieldErrors?: Record<string, string>}`.
    Unknown `/api` paths return a JSON 404. Other unknown paths serve the
    app shell, which shows a "Page not found" message.
- **Staff session:** a random token held in server memory, sent as an
  `HttpOnly`, `SameSite=Strict`, `Path=/` cookie. It expires after 8 hours or
  on sign-out. The cookie has no `Secure` flag because the app is served over
  plain HTTP on the local network; add it if the site moves to HTTPS only. The password is compared
  with `crypto.timingSafeEqual` over SHA-256 digests.
- **Missing staff password:** if `STAFF_PASSWORD` is unset or empty, staff
  sign-in always fails with 503 and the page says that staff sign-in is not
  configured. The server logs a warning at startup.
- **Validation rules:**
  - Name: trimmed, required, at most 100 characters. Message "Please enter your name."
  - Email: trimmed, required, at most 254 characters, must look like
    `local@domain.tld` (no spaces). Message "Please enter a valid email address."
  - Guests: a whole number from 1 to 8. Message "Please enter between 1 and 8 guests."
    Non-numeric input gets the same message.
  - Guests greater than seats left. Message "Only <n> seats left."
  - A fully booked tasting shows "Fully booked" and no form.
- **Past tastings (my call):** "now" is the current time in
  `Europe/Berlin` (the winery's time zone). A tasting is bookable until its
  start time. After that the list shows a grey "Booking closed" badge, the
  form is not shown, and the API returns 409 "This tasting has already
  taken place." The clock is injectable so tests can fix it.

## 7. Look and feel (my call)

- Palette: cream background, deep bordeaux primary, dark slate text, a
  muted gold accent for "Book" highlights.
- Headings in a serif system stack. The winery name "Weingut Kieselbrunnen"
  in the header, and "Tastings & bookings" as the subtitle.
- Tasting cards in a grid (one column on a phone). Each card shows the
  title, date and time, price per guest, and a seats-left badge. A fully
  booked card has a grey badge "Fully booked" and no active button.
- Errors: red text under the field, the input gets `aria-invalid`, and
  server-level errors appear in a `role="alert"` box.
- Success: a green confirmation card.
- Touch targets at least 44 px high. No horizontal scrolling at 360 px width.

## 8. Left to the builder

- Exact component breakdown, file names within the layout above, and CSS
  details.
- Copy beyond the labels and messages named in this document.

## 9. Acceptance

- Every requirement in section 2 has at least one automated test.
- The Review Focus list (written in the plan, not in this spec) has a test
  for each item.
- `npm install`, `npm run build`, and `PORT=<p> npm start` run without
  errors on Node.js 22, and the pages respond on `/`, `/tastings/:id/book`,
  `/staff`, and the API.
