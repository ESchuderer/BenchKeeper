import { Route, Routes } from "react-router";
import { Layout } from "./components/Layout";
import { NotFoundPage } from "./pages/NotFoundPage";
import TastingsPage from "./pages/TastingsPage";
import BookingPage from "./pages/BookingPage";
import ConfirmationPage from "./pages/ConfirmationPage";
import StaffPage from "./pages/StaffPage";

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingsPage />} />
        <Route path="tastings/:id/book" element={<BookingPage />} />
        <Route path="bookings/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
