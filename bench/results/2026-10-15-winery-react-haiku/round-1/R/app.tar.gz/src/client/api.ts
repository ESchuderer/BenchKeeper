import type { BookingInput } from "../shared/booking-schema";
import type {
  ApiErrorBody,
  BookingView,
  StaffBookingsResponse,
  TastingView,
} from "../shared/types";

const GENERIC_ERROR = "Something went wrong. Please try again.";

export class ApiError extends Error {
  readonly status: number;
  readonly fieldErrors: Record<string, string>;

  constructor(message: string, status: number, fieldErrors: Record<string, string> = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

async function request<T>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  let body: string | undefined;
  if (init.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(init.body);
  }

  const response = await fetch(path, {
    method: init.method ?? "GET",
    headers,
    body,
    credentials: "same-origin",
  });

  if (response.status === 204) return undefined as T;

  let payload: unknown = null;
  if ((response.headers.get("content-type") ?? "").includes("application/json")) {
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }
  }

  if (!response.ok) {
    const errorBody = payload as ApiErrorBody | null;
    throw new ApiError(errorBody?.error ?? GENERIC_ERROR, response.status, errorBody?.fieldErrors ?? {});
  }
  if (payload === null) throw new ApiError(GENERIC_ERROR, response.status);
  return payload as T;
}

export const api = {
  getTastings(): Promise<TastingView[]> {
    return request<TastingView[]>("/api/tastings");
  },

  getBooking(reference: string): Promise<BookingView> {
    return request<BookingView>(`/api/bookings/${encodeURIComponent(reference)}`);
  },

  createBooking(tastingId: string, input: BookingInput): Promise<BookingView> {
    return request<BookingView>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
      method: "POST",
      body: input,
    });
  },

  async staffBookings(): Promise<StaffBookingsResponse> {
    return request<StaffBookingsResponse>("/api/staff/bookings");
  },

  /** Staff bookings when signed in, or null when not signed in. */
  async staffSession(): Promise<StaffBookingsResponse | null> {
    try {
      return await api.staffBookings();
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) return null;
      throw error;
    }
  },

  staffSignIn(password: string): Promise<void> {
    return request<void>("/api/staff/session", { method: "POST", body: { password } });
  },

  staffSignOut(): Promise<void> {
    return request<void>("/api/staff/session", { method: "DELETE" });
  },

  cancelBooking(bookingId: string): Promise<void> {
    return request<void>(`/api/staff/bookings/${encodeURIComponent(bookingId)}`, { method: "DELETE" });
  },
};
