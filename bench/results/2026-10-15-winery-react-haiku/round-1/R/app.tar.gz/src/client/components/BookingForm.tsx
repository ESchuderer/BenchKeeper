import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router";
import { api, ApiError } from "../api";
import type { z } from "zod";
import { bookingInputSchema, type BookingInput } from "../../shared/booking-schema";
import { seatsLeftMessage } from "../../shared/format";
import { formatPrice } from "../../shared/format";
import type { TastingView } from "../../shared/types";

// Form values as typed by the user; guests is a string until the schema converts it.
type FormValues = z.input<typeof bookingInputSchema>;
const FIELDS = ["name", "email", "guests"] as const;

const GENERIC_ERROR = "Something went wrong. Please try again.";

export function BookingForm({ tasting }: { tasting: TastingView }) {
  const navigate = useNavigate();
  const [formError, setFormError] = useState<string | null>(null);

  // The shared schema plus the seats-left rule for this tasting.
  const schema = useMemo(
    () =>
      bookingInputSchema.superRefine((value, ctx) => {
        if (value.guests > tasting.seatsLeft) {
          ctx.addIssue({ code: "custom", path: ["guests"], message: seatsLeftMessage(tasting.seatsLeft) });
        }
      }),
    [tasting.seatsLeft],
  );

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues, unknown, BookingInput>({
    defaultValues: { name: "", email: "", guests: "" },
    resolver: zodResolver(schema),
  });

  const maxGuests = Math.min(8, tasting.seatsLeft);

  async function onValid(values: BookingInput) {
    setFormError(null);
    try {
      const booking = await api.createBooking(tasting.id, values);
      navigate(`/bookings/${booking.reference}`, { replace: true });
    } catch (error) {
      if (error instanceof ApiError && Object.keys(error.fieldErrors).length > 0) {
        for (const [field, message] of Object.entries(error.fieldErrors)) {
          if ((FIELDS as readonly string[]).includes(field)) {
            setError(field as (typeof FIELDS)[number], { type: "server", message });
          }
        }
      } else {
        setFormError(error instanceof ApiError ? error.message : GENERIC_ERROR);
      }
    }
  }

  const fieldClass =
    "mt-1 w-full rounded-lg border border-slate/20 bg-white px-4 py-3 text-base text-slate shadow-sm focus:border-bordeaux focus:outline-none focus:ring-2 focus:ring-bordeaux/30 aria-[invalid=true]:border-danger";

  return (
    <form noValidate onSubmit={handleSubmit(onValid)} className="mt-8 grid gap-6 sm:grid-cols-2">
      {formError && (
        <p role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger sm:col-span-2">
          {formError}
        </p>
      )}

      <div className="sm:col-span-2">
        <label htmlFor="name" className="block font-medium text-slate">
          Name
        </label>
        <input
          id="name"
          type="text"
          autoComplete="name"
          className={fieldClass}
          aria-invalid={errors.name ? true : undefined}
          aria-describedby={errors.name ? "name-error" : undefined}
          {...register("name")}
        />
        {errors.name && (
          <p id="name-error" className="mt-1 text-sm text-danger">
            {errors.name.message}
          </p>
        )}
      </div>

      <div className="sm:col-span-2">
        <label htmlFor="email" className="block font-medium text-slate">
          Email
        </label>
        <input
          id="email"
          type="email"
          autoComplete="email"
          className={fieldClass}
          aria-invalid={errors.email ? true : undefined}
          aria-describedby={errors.email ? "email-error" : undefined}
          {...register("email")}
        />
        {errors.email && (
          <p id="email-error" className="mt-1 text-sm text-danger">
            {errors.email.message}
          </p>
        )}
      </div>

      <div>
        <label htmlFor="guests" className="block font-medium text-slate">
          Guests
        </label>
        <input
          id="guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={maxGuests}
          step={1}
          className={fieldClass}
          aria-invalid={errors.guests ? true : undefined}
          aria-describedby={errors.guests ? "guests-error guests-hint" : "guests-hint"}
          {...register("guests")}
        />
        <p id="guests-hint" className="mt-1 text-sm text-slate/70">
          {`1 to ${maxGuests} guests, ${formatPrice(tasting.pricePerGuest)} each`}
        </p>
        {errors.guests && (
          <p id="guests-error" className="mt-1 text-sm text-danger">
            {errors.guests.message}
          </p>
        )}
      </div>

      <div className="flex items-end sm:col-span-2">
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex min-h-11 w-full items-center justify-center rounded-lg bg-bordeaux px-6 font-medium text-cream transition hover:bg-bordeaux-dark disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
        >
          {isSubmitting ? "Booking…" : "Book"}
        </button>
      </div>
    </form>
  );
}
