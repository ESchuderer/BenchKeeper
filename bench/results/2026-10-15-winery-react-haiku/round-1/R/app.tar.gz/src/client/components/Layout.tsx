import { Link, Outlet } from "react-router";

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b-4 border-gold bg-bordeaux text-cream">
        <div className="mx-auto flex max-w-5xl flex-col gap-1 px-5 py-6">
          <Link to="/" className="font-serif text-2xl font-semibold tracking-wide text-cream no-underline">
            Weingut Kieselbrunnen
          </Link>
          <p className="text-sm text-cream/80">Tastings &amp; bookings</p>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-10">
        <Outlet />
      </main>
      <footer className="border-t border-slate/10 py-6 text-center text-sm text-slate/70">
        Weingut Kieselbrunnen, family winery
      </footer>
    </div>
  );
}
