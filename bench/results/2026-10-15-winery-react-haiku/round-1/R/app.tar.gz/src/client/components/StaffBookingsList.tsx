import { formatDateTime } from "../../shared/format";
import type { StaffTastingGroup } from "../../shared/types";
import { seatsLeftLabel } from "./TastingCard";

interface Props {
  groups: StaffTastingGroup[];
  busyBookingId: string | null;
  onCancel: (bookingId: string) => void;
}

// On phones each booking stacks as a card, with the column name shown before each value.
const cellLabel =
  "flex items-center justify-between gap-4 py-1.5 sm:table-cell sm:px-4 sm:py-3 before:text-sm before:font-medium before:text-slate/70 before:content-[attr(data-label)] sm:before:content-none";

export function StaffBookingsList({ groups, busyBookingId, onCancel }: Props) {
  return (
    <div className="mt-8 space-y-10">
      {groups.map((group) => (
        <section key={group.id} aria-labelledby={`tasting-${group.id}`}>
          <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-slate/10 pb-2">
            <h2 id={`tasting-${group.id}`} className="font-serif text-2xl text-bordeaux">
              {group.title}
            </h2>
            <p className="text-sm text-slate">
              {formatDateTime(group.date, group.time)}
              <span className="ml-3 font-medium">{seatsLeftLabel(group.seatsLeft)}</span>
            </p>
          </div>

          {group.bookings.length === 0 ? (
            <p className="mt-4 text-slate/80">No bookings yet.</p>
          ) : (
            <div className="mt-4 overflow-hidden rounded-xl border border-slate/10 bg-white shadow-sm">
              <table className="block w-full text-left text-sm sm:table">
                <thead className="sr-only sm:not-sr-only sm:table-header-group bg-cream text-slate/80">
                  <tr>
                    <th scope="col" className="px-4 py-3 font-medium">Name</th>
                    <th scope="col" className="px-4 py-3 font-medium">Email</th>
                    <th scope="col" className="px-4 py-3 font-medium">Guests</th>
                    <th scope="col" className="px-4 py-3 font-medium">Reference</th>
                    <th scope="col" className="px-4 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="block sm:table-row-group">
                  {group.bookings.map((booking) => (
                    <tr
                      key={booking.id}
                      className="block border-t border-slate/10 px-4 py-2 first:border-t-0 sm:table-row sm:px-0 sm:py-0"
                    >
                      <td data-label="Name" className={`${cellLabel} font-medium text-slate`}>
                        {booking.name}
                      </td>
                      <td data-label="Email" className={`${cellLabel} break-all text-slate`}>
                        {booking.email}
                      </td>
                      <td data-label="Guests" className={`${cellLabel} text-slate`}>
                        {booking.guests}
                      </td>
                      <td data-label="Reference" className={`${cellLabel} font-mono text-bordeaux`}>
                        {booking.reference}
                      </td>
                      <td className="block pb-3 pt-2 text-right sm:table-cell sm:px-4 sm:py-3">
                        <button
                          type="button"
                          onClick={() => onCancel(booking.id)}
                          disabled={busyBookingId !== null}
                          className="min-h-11 min-w-28 rounded-lg border border-danger/40 px-4 font-medium text-danger transition hover:bg-danger/5 disabled:opacity-50"
                        >
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      ))}
    </div>
  );
}
