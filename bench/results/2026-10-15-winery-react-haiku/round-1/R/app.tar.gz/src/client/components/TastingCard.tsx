import { Link } from "react-router";
import { formatDateTime, formatPrice } from "../../shared/format";
import type { TastingView } from "../../shared/types";

export function seatsLeftLabel(seatsLeft: number): string {
  return seatsLeft === 1 ? "1 seat left" : `${seatsLeft} seats left`;
}

export function TastingCard({ tasting }: { tasting: TastingView }) {
  const isOpen = tasting.status === "open";

  let badge: { text: string; className: string };
  if (tasting.status === "fully_booked") {
    badge = { text: "Fully booked", className: "bg-slate/10 text-slate" };
  } else if (tasting.status === "closed") {
    badge = { text: "Booking closed", className: "bg-slate/10 text-slate" };
  } else {
    badge = { text: seatsLeftLabel(tasting.seatsLeft), className: "bg-success/10 text-success" };
  }

  return (
    <article className="flex flex-col rounded-2xl border border-slate/10 bg-white p-6 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <h2 className="font-serif text-2xl text-bordeaux">{tasting.title}</h2>
        <span
          className={`shrink-0 rounded-full px-3 py-1 text-sm font-medium ${badge.className}`}
        >
          {badge.text}
        </span>
      </div>
      <p className="mt-3 text-slate">{formatDateTime(tasting.date, tasting.time)}</p>
      <p className="mt-1 font-medium text-slate">{`${formatPrice(tasting.pricePerGuest)} per guest`}</p>
      <div className="mt-auto pt-6">
        {isOpen ? (
          <Link
            to={`/tastings/${tasting.id}/book`}
            className="inline-flex min-h-11 w-full items-center justify-center rounded-lg bg-bordeaux px-5 font-medium text-cream no-underline transition hover:bg-bordeaux-dark sm:w-auto"
          >
            {`Book ${tasting.title}`}
          </Link>
        ) : null}
      </div>
    </article>
  );
}
