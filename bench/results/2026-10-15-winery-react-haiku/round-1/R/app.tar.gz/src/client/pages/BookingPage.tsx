import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import { api } from "../api";
import { BookingForm } from "../components/BookingForm";
import { formatDateTime, formatPrice } from "../../shared/format";
import type { TastingView } from "../../shared/types";

type State =
  | { phase: "loading" }
  | { phase: "error" }
  | { phase: "ready"; tasting: TastingView | undefined };

export default function BookingPage() {
  const { id = "" } = useParams();
  const [state, setState] = useState<State>({ phase: "loading" });

  useEffect(() => {
    let active = true;
    api
      .getTastings()
      .then((tastings) => {
        if (active) setState({ phase: "ready", tasting: tastings.find((t) => t.id === id) });
      })
      .catch(() => {
        if (active) setState({ phase: "error" });
      });
    return () => {
      active = false;
    };
  }, [id]);

  if (state.phase === "loading") return <p className="text-slate">Loading…</p>;

  if (state.phase === "error") {
    return (
      <p role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
        We could not load this tasting. Please try again later.
      </p>
    );
  }

  const { tasting } = state;
  if (!tasting) {
    return (
      <section>
        <h1 className="font-serif text-3xl text-bordeaux">Page not found</h1>
        <p className="mt-4">
          <Link to="/" className="font-medium text-bordeaux underline">
            Back to all tastings
          </Link>
        </p>
      </section>
    );
  }

  return (
    <section className="mx-auto max-w-2xl">
      <Link to="/" className="text-sm font-medium text-bordeaux underline">
        Back to all tastings
      </Link>
      <h1 className="mt-4 font-serif text-3xl text-bordeaux sm:text-4xl">{tasting.title}</h1>
      <p className="mt-2 text-slate">{formatDateTime(tasting.date, tasting.time)}</p>
      <p className="font-medium text-slate">{`${formatPrice(tasting.pricePerGuest)} per guest`}</p>

      <div className="mt-8 rounded-2xl border border-slate/10 bg-white p-6 shadow-sm sm:p-8">
        {tasting.status === "open" && <BookingForm tasting={tasting} />}
        {tasting.status === "fully_booked" && (
          <p className="text-lg text-slate">This tasting is fully booked.</p>
        )}
        {tasting.status === "closed" && (
          <p className="text-lg text-slate">Booking closed for this tasting.</p>
        )}
      </div>
    </section>
  );
}
