import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import { api } from "../api";
import { formatDateTime, formatPrice } from "../../shared/format";
import type { BookingView } from "../../shared/types";

type State =
  | { phase: "loading" }
  | { phase: "notFound" }
  | { phase: "ready"; booking: BookingView };

export default function ConfirmationPage() {
  const { reference = "" } = useParams();
  const [state, setState] = useState<State>({ phase: "loading" });

  useEffect(() => {
    let active = true;
    api
      .getBooking(reference)
      .then((booking) => {
        if (active) setState({ phase: "ready", booking });
      })
      .catch(() => {
        if (active) setState({ phase: "notFound" });
      });
    return () => {
      active = false;
    };
  }, [reference]);

  if (state.phase === "loading") return <p className="text-slate">Loading booking…</p>;

  if (state.phase === "notFound") {
    return (
      <section className="mx-auto max-w-md text-center">
        <h1 className="font-serif text-3xl text-bordeaux">Booking not found.</h1>
        <p className="mt-4">
          <Link to="/" className="font-medium text-bordeaux underline">
            Back to all tastings
          </Link>
        </p>
      </section>
    );
  }

  const { booking } = state;
  return (
    <section className="mx-auto max-w-2xl">
      <div className="rounded-2xl border border-success/30 bg-white p-6 shadow-sm sm:p-10">
        <p className="text-sm font-medium uppercase tracking-widest text-success">Thank you</p>
        <h1 className="mt-2 font-serif text-3xl text-bordeaux sm:text-4xl">Booking confirmed</h1>

        <dl className="mt-8 grid gap-5 sm:grid-cols-2">
          <div>
            <dt className="text-sm text-slate/70">Tasting</dt>
            <dd className="mt-1 text-lg font-medium text-slate">{booking.tastingTitle}</dd>
          </div>
          <div>
            <dt className="text-sm text-slate/70">Date and time</dt>
            <dd className="mt-1 text-lg font-medium text-slate">
              {formatDateTime(booking.date, booking.time)}
            </dd>
          </div>
          <div>
            <dt className="text-sm text-slate/70">Guests</dt>
            <dd className="mt-1 text-lg font-medium text-slate">{booking.guests}</dd>
          </div>
          <div>
            <dt className="text-sm text-slate/70">Total</dt>
            <dd className="mt-1 text-lg font-medium text-slate">{formatPrice(booking.total)}</dd>
          </div>
          <div className="sm:col-span-2">
            <dt className="text-sm text-slate/70">Booking reference</dt>
            <dd className="mt-1 font-mono text-xl tracking-wider text-bordeaux">{booking.reference}</dd>
          </div>
        </dl>

        <p className="mt-8 text-sm text-slate/80">
          Please keep your booking reference for your visit.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex min-h-11 items-center font-medium text-bordeaux underline"
        >
          Back to all tastings
        </Link>
      </div>
    </section>
  );
}
