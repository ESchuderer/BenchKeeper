import { Link } from "react-router";

export function NotFoundPage() {
  return (
    <section className="mx-auto max-w-md text-center">
      <h1 className="font-serif text-3xl text-bordeaux">Page not found</h1>
      <p className="mt-4">
        <Link to="/" className="font-medium text-bordeaux underline">
          Back to all tastings
        </Link>
      </p>
    </section>
  );
}
