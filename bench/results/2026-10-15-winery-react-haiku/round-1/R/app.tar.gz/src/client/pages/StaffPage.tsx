import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { ApiError, api } from "../api";
import { StaffBookingsList } from "../components/StaffBookingsList";
import type { StaffBookingsResponse } from "../../shared/types";

type View =
  | { phase: "checking" }
  | { phase: "signedOut"; notice?: string }
  | { phase: "signedIn"; data: StaffBookingsResponse; busyBookingId: string | null; actionError?: string };

const GENERIC_ERROR = "Something went wrong. Please try again.";

function messageFor(error: unknown): string {
  return error instanceof Error ? error.message : GENERIC_ERROR;
}

export default function StaffPage() {
  const [view, setView] = useState<View>({ phase: "checking" });

  useEffect(() => {
    let active = true;
    api
      .staffSession()
      .then((data) => {
        if (!active) return;
        setView(data ? { phase: "signedIn", data, busyBookingId: null } : { phase: "signedOut" });
      })
      .catch((error: unknown) => {
        if (active) setView({ phase: "signedOut", notice: messageFor(error) });
      });
    return () => {
      active = false;
    };
  }, []);

  async function reload() {
    try {
      const data = await api.staffBookings();
      setView({ phase: "signedIn", data, busyBookingId: null });
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        setView({ phase: "signedOut", notice: "Your session has ended. Please sign in again." });
        return;
      }
      setView((current) =>
        current.phase === "signedIn" ? { ...current, busyBookingId: null, actionError: messageFor(error) } : current,
      );
    }
  }

  async function cancel(bookingId: string) {
    setView((current) => (current.phase === "signedIn" ? { ...current, busyBookingId: bookingId, actionError: undefined } : current));
    try {
      await api.cancelBooking(bookingId);
      await reload();
    } catch (error) {
      setView((current) =>
        current.phase === "signedIn" ? { ...current, busyBookingId: null, actionError: messageFor(error) } : current,
      );
    }
  }

  async function signOut() {
    try {
      await api.staffSignOut();
    } finally {
      setView({ phase: "signedOut" });
    }
  }

  if (view.phase === "checking") return <p className="text-slate">Checking your sign-in…</p>;

  if (view.phase === "signedOut") {
    return <SignInForm notice={view.notice} onSignedIn={reload} />;
  }

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-serif text-3xl text-bordeaux sm:text-4xl">Bookings</h1>
        <button
          type="button"
          onClick={signOut}
          className="min-h-11 rounded-lg border border-slate/20 bg-white px-5 font-medium text-slate transition hover:bg-slate/5"
        >
          Sign out
        </button>
      </div>

      {view.actionError && (
        <p role="alert" className="mt-6 rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
          {view.actionError}
        </p>
      )}

      <StaffBookingsList
        groups={view.data.tastings}
        busyBookingId={view.busyBookingId}
        onCancel={cancel}
      />
    </section>
  );
}

function SignInForm({ notice, onSignedIn }: { notice?: string; onSignedIn: () => Promise<void> }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: "" } });

  async function submit(values: { password: string }) {
    if (values.password === "") {
      setError("password", { type: "required", message: "Password is required." });
      return;
    }
    try {
      await api.staffSignIn(values.password);
    } catch (error) {
      setError("root", { type: "server", message: messageFor(error) });
      return;
    }
    await onSignedIn();
  }

  return (
    <section className="mx-auto max-w-sm">
      <h1 className="font-serif text-3xl text-bordeaux">Staff sign-in</h1>
      {notice && <p className="mt-4 text-slate">{notice}</p>}
      <form noValidate onSubmit={handleSubmit(submit)} className="mt-6 space-y-5 rounded-2xl border border-slate/10 bg-white p-6 shadow-sm">
        {errors.root && (
          <p role="alert" className="rounded-lg border border-danger/30 bg-danger/5 p-3 text-danger">
            {errors.root.message}
          </p>
        )}
        <div>
          <label htmlFor="password" className="block font-medium text-slate">
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className="mt-1 w-full rounded-lg border border-slate/20 bg-white px-4 py-3 text-base text-slate shadow-sm focus:border-bordeaux focus:outline-none focus:ring-2 focus:ring-bordeaux/30 aria-[invalid=true]:border-danger"
            aria-invalid={errors.password ? true : undefined}
            aria-describedby={errors.password ? "password-error" : undefined}
            {...register("password", { required: "Password is required." })}
          />
          {errors.password && (
            <p id="password-error" className="mt-1 text-sm text-danger">
              {errors.password.message}
            </p>
          )}
        </div>
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex min-h-11 w-full items-center justify-center rounded-lg bg-bordeaux px-6 font-medium text-cream transition hover:bg-bordeaux-dark disabled:opacity-60"
        >
          Sign in
        </button>
      </form>
    </section>
  );
}
