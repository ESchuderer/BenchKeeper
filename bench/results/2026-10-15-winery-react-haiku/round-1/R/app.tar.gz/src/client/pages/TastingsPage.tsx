import { useEffect, useState } from "react";
import { api } from "../api";
import { TastingCard } from "../components/TastingCard";
import type { TastingView } from "../../shared/types";

type State =
  | { phase: "loading" }
  | { phase: "error" }
  | { phase: "ready"; tastings: TastingView[] };

export default function TastingsPage() {
  const [state, setState] = useState<State>({ phase: "loading" });

  useEffect(() => {
    let active = true;
    api
      .getTastings()
      .then((tastings) => {
        if (active) setState({ phase: "ready", tastings });
      })
      .catch(() => {
        if (active) setState({ phase: "error" });
      });
    return () => {
      active = false;
    };
  }, []);

  return (
    <section>
      <h1 className="font-serif text-3xl text-bordeaux sm:text-4xl">Book a tasting</h1>
      <p className="mt-2 max-w-2xl text-slate">
        Choose a tasting and reserve your seats. Each booking gets a reference for your visit.
      </p>

      {state.phase === "loading" && <p className="mt-10 text-slate">Loading tastings…</p>}

      {state.phase === "error" && (
        <p role="alert" className="mt-10 rounded-lg border border-danger/30 bg-danger/5 p-4 text-danger">
          We could not load the tastings. Please try again later.
        </p>
      )}

      {state.phase === "ready" && (
        <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {state.tastings.map((tasting) => (
            <TastingCard key={tasting.id} tasting={tasting} />
          ))}
        </div>
      )}
    </section>
  );
}
