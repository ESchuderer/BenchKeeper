import { join, resolve } from "node:path";
import express, {
  type ErrorRequestHandler,
  type Express,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import type { ZodError } from "zod";
import { BookingStore, type BookingRecord } from "./store.js";
import { getTasting, tastings, type Tasting } from "../shared/tastings.js";
import { isTastingPast, seatsLeftMessage } from "../shared/format.js";
import { bookingInputSchema } from "../shared/booking-schema.js";
import { LoginThrottle, STAFF_COOKIE, StaffSessions, readCookie, verifyStaffPassword } from "./staff-auth.js";
import type { ApiErrorBody, BookingView, TastingStatus, TastingView } from "../shared/types.js";

export interface AppOptions {
  store?: BookingStore;
  now?: () => Date;
  /** Undefined or empty disables staff sign-in. */
  staffPassword?: string | undefined;
  /** Directory with the built client; enables static serving when set. */
  clientDir?: string;
}

function sendError(res: Response, status: number, error: string, fieldErrors?: Record<string, string>) {
  const body: ApiErrorBody = fieldErrors ? { error, fieldErrors } : { error };
  res.status(status).json(body);
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function fieldErrorsFrom(error: ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "");
    out[key] ??= issue.message;
  }
  return out;
}

function toTastingView(tasting: Tasting, store: BookingStore, now: Date): TastingView {
  const seatsLeft = store.seatsLeft(tasting.id);
  let status: TastingStatus = "open";
  if (isTastingPast(tasting, now)) status = "closed";
  else if (seatsLeft === 0) status = "fully_booked";
  return {
    id: tasting.id,
    title: tasting.title,
    date: tasting.date,
    time: tasting.time,
    pricePerGuest: tasting.pricePerGuest,
    seats: tasting.seats,
    seatsLeft,
    status,
  };
}

function toBookingView(booking: BookingRecord, tasting: Tasting): BookingView {
  return {
    reference: booking.reference,
    tastingId: tasting.id,
    tastingTitle: tasting.title,
    date: tasting.date,
    time: tasting.time,
    guests: booking.guests,
    pricePerGuest: tasting.pricePerGuest,
    total: tasting.pricePerGuest * booking.guests,
  };
}

export function createApp(options: AppOptions = {}): Express {
  const now = options.now ?? (() => new Date());
  const store = options.store ?? new BookingStore({ now });
  const app = express();

  app.disable("x-powered-by");
  app.use(express.json({ limit: "10kb" }));

  app.get("/api/tastings", (_req, res) => {
    const current = now();
    res.json(tastings.map((tasting) => toTastingView(tasting, store, current)));
  });

  app.post("/api/tastings/:id/bookings", (req, res) => {
    const tasting = getTasting(req.params.id);
    if (!tasting) return sendError(res, 404, "Tasting not found.");

    const body: unknown = req.body;
    if (!isPlainObject(body)) return sendError(res, 400, "Request body must be JSON.");

    const parsed = bookingInputSchema.safeParse(body);
    if (!parsed.success) {
      return sendError(res, 400, "Please check the highlighted fields.", fieldErrorsFrom(parsed.error));
    }

    const result = store.book(tasting.id, parsed.data);
    if (result.ok) return res.status(201).json(toBookingView(result.booking, tasting));

    switch (result.code) {
      case "CLOSED":
        return sendError(res, 409, "This tasting has already taken place.");
      case "FULLY_BOOKED":
        return sendError(res, 409, "This tasting is fully booked.");
      case "INSUFFICIENT_SEATS":
        return sendError(res, 409, "Not enough seats left.", {
          guests: seatsLeftMessage(result.seatsLeft),
        });
      case "NOT_FOUND":
        return sendError(res, 404, "Tasting not found.");
    }
  });

  app.get("/api/bookings/:reference", (req, res) => {
    const booking = store.findByReference(req.params.reference);
    const tasting = booking && getTasting(booking.tastingId);
    if (!booking || !tasting) return sendError(res, 404, "Booking not found.");
    res.json(toBookingView(booking, tasting));
  });

  const staffSessions = new StaffSessions({ now });
  const loginThrottle = new LoginThrottle({ now });
  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    const token = readCookie(req.headers.cookie, STAFF_COOKIE);
    if (!staffSessions.isValid(token)) return sendError(res, 401, "Staff sign-in required.");
    next();
  };

  app.post("/api/staff/session", (req, res) => {
    if (!options.staffPassword) {
      return sendError(res, 503, "Staff sign-in is not configured.");
    }
    const clientKey = req.ip ?? "unknown";
    if (loginThrottle.isLocked(clientKey)) {
      return sendError(res, 429, "Too many attempts. Try again later.");
    }
    const body: unknown = req.body;
    if (!isPlainObject(body)) return sendError(res, 400, "Request body must be JSON.");
    const password = body.password;
    if (password === undefined || password === null || password === "") {
      return sendError(res, 400, "Password is required.", { password: "Password is required." });
    }
    if (verifyStaffPassword(password, options.staffPassword) !== "ok") {
      loginThrottle.recordFailure(clientKey);
      return sendError(res, 401, "Incorrect password.");
    }
    loginThrottle.reset(clientKey);
    const token = staffSessions.create();
    res.cookie(STAFF_COOKIE, token, { httpOnly: true, sameSite: "strict", path: "/" });
    res.status(204).end();
  });

  app.delete("/api/staff/session", (req, res) => {
    staffSessions.revoke(readCookie(req.headers.cookie, STAFF_COOKIE));
    res.clearCookie(STAFF_COOKIE, { httpOnly: true, sameSite: "strict", path: "/" });
    res.status(204).end();
  });

  app.use("/api/staff/bookings", requireStaff);

  app.get("/api/staff/bookings", (_req, res) => {
    const all = store.listBookings();
    res.json({
      tastings: tastings.map((tasting) => ({
        id: tasting.id,
        title: tasting.title,
        date: tasting.date,
        time: tasting.time,
        seats: tasting.seats,
        seatsLeft: store.seatsLeft(tasting.id),
        bookings: all
          .filter((booking) => booking.tastingId === tasting.id)
          .map((booking) => ({
            id: booking.id,
            reference: booking.reference,
            name: booking.name,
            email: booking.email,
            guests: booking.guests,
          })),
      })),
    });
  });

  app.delete("/api/staff/bookings/:id", (req, res) => {
    if (!store.cancel(req.params.id)) return sendError(res, 404, "Booking not found.");
    res.status(204).end();
  });

  app.use("/api", (_req, res) => sendError(res, 404, "Not found."));

  if (options.clientDir) {
    const clientDir = resolve(options.clientDir);
    const indexHtml = join(clientDir, "index.html");
    app.use(express.static(clientDir, { index: false }));
    // Client-side routes: any GET for a path without a file extension gets the app shell.
    app.use((req, res, next) => {
      if (req.method !== "GET" && req.method !== "HEAD") return next();
      const lastSegment = req.path.split("/").pop() ?? "";
      if (lastSegment.includes(".")) return res.status(404).type("text/plain").send("Not found");
      res.sendFile(indexHtml, (err) => {
        if (err) next(err);
      });
    });
  }

  const errorHandler: ErrorRequestHandler = (err: unknown, _req, res, _next) => {
    const type = (err as { type?: unknown } | null)?.type;
    if (type === "entity.parse.failed" || type === "charset.unsupported") {
      return sendError(res, 400, "Request body must be JSON.");
    }
    if (type === "entity.too.large") return sendError(res, 413, "Request body is too large.");

    // Express and body-parser attach a 4xx status to client mistakes; those are not server faults.
    const status = (err as { status?: unknown; statusCode?: unknown } | null)?.status ??
      (err as { statusCode?: unknown } | null)?.statusCode;
    if (typeof status === "number" && status >= 400 && status < 500) {
      return sendError(res, status, "The request could not be processed.");
    }

    console.error(err);
    sendError(res, 500, "Something went wrong.");
  };
  app.use(errorHandler);

  return app;
}
