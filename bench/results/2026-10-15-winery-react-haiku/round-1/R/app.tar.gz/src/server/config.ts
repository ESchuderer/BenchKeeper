export interface Config {
  port: number;
  /** Undefined when STAFF_PASSWORD is unset or empty. */
  staffPassword: string | undefined;
}

export function readConfig(env: NodeJS.ProcessEnv): Config {
  const rawPort = env.PORT ?? "3000";
  const port = /^\d+$/.test(rawPort) ? Number(rawPort) : NaN;
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("PORT must be a number between 1 and 65535.");
  }
  const staffPassword = env.STAFF_PASSWORD ? env.STAFF_PASSWORD : undefined;
  return { port, staffPassword };
}
