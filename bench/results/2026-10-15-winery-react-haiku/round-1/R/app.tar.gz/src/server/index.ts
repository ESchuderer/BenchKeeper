import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";
import { readConfig } from "./config.js";

let config: ReturnType<typeof readConfig>;
try {
  config = readConfig(process.env);
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
}

if (!config.staffPassword) {
  console.warn("STAFF_PASSWORD is not set; staff sign-in is disabled.");
}

// dist/server/index.js -> dist/client
const clientDir = resolve(dirname(fileURLToPath(import.meta.url)), "../client");

const app = createApp({ staffPassword: config.staffPassword, clientDir });
app.listen(config.port, () => {
  console.log(`Weingut Kieselbrunnen listening on http://localhost:${config.port}`);
});
