import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export const STAFF_COOKIE = "staff_session";
const DEFAULT_TTL_MS = 8 * 60 * 60 * 1000;

export interface StaffSessionsOptions {
  now?: () => Date;
  ttlMs?: number;
}

/** Server-side sign-in sessions for staff, keyed by random token. */
export class StaffSessions {
  private readonly expiresAt = new Map<string, number>();
  private readonly now: () => Date;
  private readonly ttlMs: number;

  constructor(options: StaffSessionsOptions = {}) {
    this.now = options.now ?? (() => new Date());
    this.ttlMs = options.ttlMs ?? DEFAULT_TTL_MS;
  }

  create(): string {
    const token = randomBytes(32).toString("base64url");
    this.expiresAt.set(token, this.now().getTime() + this.ttlMs);
    return token;
  }

  isValid(token: string | undefined): boolean {
    if (!token) return false;
    const expiry = this.expiresAt.get(token);
    if (expiry === undefined) return false;
    if (this.now().getTime() >= expiry) {
      this.expiresAt.delete(token);
      return false;
    }
    return true;
  }

  revoke(token: string | undefined): void {
    if (token) this.expiresAt.delete(token);
  }
}

export type PasswordCheck = "ok" | "wrong" | "not_configured";

/** Compares digests in constant time, so the length of the password is not leaked either. */
export function verifyStaffPassword(candidate: unknown, expected: string | undefined): PasswordCheck {
  if (!expected) return "not_configured";
  if (typeof candidate !== "string" || candidate.length === 0) return "wrong";
  const given = createHash("sha256").update(candidate, "utf8").digest();
  const want = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(given, want) ? "ok" : "wrong";
}

export function readCookie(header: string | undefined, name: string): string | undefined {
  if (!header) return undefined;
  for (const part of header.split(";")) {
    const eq = part.indexOf("=");
    if (eq === -1) continue;
    if (part.slice(0, eq).trim() === name) {
      try {
        return decodeURIComponent(part.slice(eq + 1).trim());
      } catch {
        return undefined;
      }
    }
  }
  return undefined;
}

export interface LoginThrottleOptions {
  /** Failed attempts allowed per window before the address is locked out. */
  maxFailures?: number;
  windowMs?: number;
  now?: () => Date;
}

/**
 * Counts failed staff sign-ins per key (client address). After maxFailures in
 * one window, the key is locked until the window ends. A success clears it.
 */
export class LoginThrottle {
  private readonly failures = new Map<string, { count: number; windowStart: number }>();
  private readonly maxFailures: number;
  private readonly windowMs: number;
  private readonly now: () => Date;

  constructor(options: LoginThrottleOptions = {}) {
    this.maxFailures = options.maxFailures ?? 5;
    this.windowMs = options.windowMs ?? 15 * 60 * 1000;
    this.now = options.now ?? (() => new Date());
  }

  isLocked(key: string): boolean {
    const entry = this.current(key);
    return entry !== undefined && entry.count >= this.maxFailures;
  }

  recordFailure(key: string): void {
    const entry = this.current(key) ?? { count: 0, windowStart: this.now().getTime() };
    entry.count += 1;
    this.failures.set(key, entry);
  }

  reset(key: string): void {
    this.failures.delete(key);
  }

  private current(key: string) {
    const entry = this.failures.get(key);
    if (!entry) return undefined;
    if (this.now().getTime() - entry.windowStart >= this.windowMs) {
      this.failures.delete(key);
      return undefined;
    }
    return entry;
  }
}
