import { randomInt, randomUUID } from "node:crypto";
import { getTasting } from "../shared/tastings.js";
import { isTastingPast } from "../shared/format.js";
import type { BookingInput } from "../shared/booking-schema.js";

export interface BookingRecord {
  id: string;
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export type BookFailureCode = "NOT_FOUND" | "CLOSED" | "FULLY_BOOKED" | "INSUFFICIENT_SEATS";

export type BookResult =
  | { ok: true; booking: BookingRecord }
  | { ok: false; code: BookFailureCode; seatsLeft: number };

export interface BookingStoreOptions {
  now?: () => Date;
}

// No 0, O, 1 or I, so references read clearly on paper and over the phone.
const REFERENCE_ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";

function newReference(): string {
  let out = "KB-";
  for (let i = 0; i < 6; i++) {
    out += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  }
  return out;
}

/**
 * In-memory booking store. Each public method is synchronous, so the seat
 * check and the insert cannot interleave with another request.
 */
export class BookingStore {
  private readonly now: () => Date;
  private readonly bookings = new Map<string, BookingRecord>();
  private readonly byReference = new Map<string, string>();

  constructor(options: BookingStoreOptions = {}) {
    this.now = options.now ?? (() => new Date());
  }

  seatsLeft(tastingId: string): number {
    const tasting = getTasting(tastingId);
    if (!tasting) return 0;
    let taken = 0;
    for (const booking of this.bookings.values()) {
      if (booking.tastingId === tastingId) taken += booking.guests;
    }
    return tasting.seats - taken;
  }

  book(tastingId: string, input: BookingInput): BookResult {
    const tasting = getTasting(tastingId);
    if (!tasting) return { ok: false, code: "NOT_FOUND", seatsLeft: 0 };

    const seatsLeft = this.seatsLeft(tastingId);
    if (isTastingPast(tasting, this.now())) return { ok: false, code: "CLOSED", seatsLeft };
    if (seatsLeft === 0) return { ok: false, code: "FULLY_BOOKED", seatsLeft };
    if (input.guests > seatsLeft) return { ok: false, code: "INSUFFICIENT_SEATS", seatsLeft };

    let reference = newReference();
    while (this.byReference.has(reference)) reference = newReference();

    const booking: BookingRecord = {
      id: randomUUID(),
      reference,
      tastingId,
      name: input.name,
      email: input.email,
      guests: input.guests,
      createdAt: this.now().toISOString(),
    };
    this.bookings.set(booking.id, booking);
    this.byReference.set(reference, booking.id);
    return { ok: true, booking };
  }

  findByReference(reference: string): BookingRecord | undefined {
    const id = this.byReference.get(reference);
    return id === undefined ? undefined : this.bookings.get(id);
  }

  listBookings(): BookingRecord[] {
    return [...this.bookings.values()];
  }

  cancel(id: string): boolean {
    const booking = this.bookings.get(id);
    if (!booking) return false;
    this.bookings.delete(id);
    this.byReference.delete(booking.reference);
    return true;
  }
}
