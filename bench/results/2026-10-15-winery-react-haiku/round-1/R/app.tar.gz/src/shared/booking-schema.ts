import { z } from "zod";

export const GUESTS_MESSAGE = "Please enter between 1 and 8 guests.";
export const NAME_MESSAGE = "Please enter your name.";
export const EMAIL_MESSAGE = "Please enter a valid email address.";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Form inputs arrive as strings; accept a whole number written as digits.
const guestsSchema = z.preprocess(
  (value) => (typeof value === "string" && /^\s*\d+\s*$/.test(value) ? Number(value.trim()) : value),
  z
    .number({ error: GUESTS_MESSAGE })
    .int({ error: GUESTS_MESSAGE })
    .min(1, { error: GUESTS_MESSAGE })
    .max(8, { error: GUESTS_MESSAGE }),
);

export const bookingInputSchema = z.object({
  name: z.string({ error: NAME_MESSAGE }).trim().min(1, { error: NAME_MESSAGE }).max(100, { error: NAME_MESSAGE }),
  email: z
    .string({ error: EMAIL_MESSAGE })
    .trim()
    .min(1, { error: EMAIL_MESSAGE })
    .max(254, { error: EMAIL_MESSAGE })
    .regex(EMAIL_PATTERN, { error: EMAIL_MESSAGE }),
  guests: guestsSchema,
});

export type BookingInput = z.infer<typeof bookingInputSchema>;
export type BookingInputField = keyof BookingInput;
