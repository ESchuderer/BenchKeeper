import type { Tasting } from "./tastings.js";

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export const WINERY_TIME_ZONE = "Europe/Berlin";

export function formatPrice(euros: number): string {
  return `EUR ${euros}`;
}

/** Formats YYYY-MM-DD and HH:MM without any time-zone conversion. */
export function formatDateTime(date: string, time: string): string {
  const [year, month, day] = date.split("-").map(Number);
  const weekday = WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()];
  return `${weekday}, ${day} ${MONTHS[month - 1]} ${year}, ${time}`;
}

/** Wall-clock "YYYY-MM-DDTHH:MM" in the winery's time zone. */
function wallClockInWineryZone(now: Date): string {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: WINERY_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(now);
  const get = (type: Intl.DateTimeFormatPartTypes) => parts.find((p) => p.type === type)!.value;
  return `${get("year")}-${get("month")}-${get("day")}T${get("hour")}:${get("minute")}`;
}

/** A tasting is past from its start time on (winery time zone). */
export function isTastingPast(tasting: Tasting, now: Date): boolean {
  return wallClockInWineryZone(now) >= `${tasting.date}T${tasting.time}`;
}

/** Message for guests above the seats left, shared by server and form. */
export function seatsLeftMessage(seatsLeft: number): string {
  return seatsLeft === 1 ? "Only 1 seat left." : `Only ${seatsLeft} seats left.`;
}
