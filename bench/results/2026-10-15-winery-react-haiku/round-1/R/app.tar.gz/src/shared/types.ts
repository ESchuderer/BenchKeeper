export type TastingStatus = "open" | "fully_booked" | "closed";

/** Public tasting listing item. */
export interface TastingView {
  id: string;
  title: string;
  date: string;
  time: string;
  pricePerGuest: number;
  seats: number;
  seatsLeft: number;
  status: TastingStatus;
}

/** Guest-facing booking. Never includes name or email. */
export interface BookingView {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  date: string;
  time: string;
  guests: number;
  pricePerGuest: number;
  total: number;
}

export interface StaffBooking {
  id: string;
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTastingGroup {
  id: string;
  title: string;
  date: string;
  time: string;
  seats: number;
  seatsLeft: number;
  bookings: StaffBooking[];
}

export interface StaffBookingsResponse {
  tastings: StaffTastingGroup[];
}

export interface ApiErrorBody {
  error: string;
  fieldErrors?: Record<string, string>;
}
