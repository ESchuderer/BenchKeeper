// @vitest-environment jsdom
import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router";
import { App } from "../../src/client/App";
import { api } from "../../src/client/api";

function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}

describe("App shell", () => {
  it("shows the winery header and subtitle on every page", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([]);
    renderAt("/");
    expect(screen.getByRole("link", { name: "Weingut Kieselbrunnen" })).toHaveAttribute("href", "/");
    expect(screen.getByText("Tastings & bookings")).toBeInTheDocument();
    expect(screen.getByRole("main")).toBeInTheDocument();
  });

  it("shows Page not found for an unknown path", () => {
    renderAt("/no/such/page");
    expect(screen.getByRole("heading", { name: "Page not found" })).toBeInTheDocument();
  });
});
