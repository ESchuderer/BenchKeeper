// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router";
import BookingPage from "../../src/client/pages/BookingPage";
import { ApiError, api } from "../../src/client/api";
import type { BookingView, TastingView } from "../../src/shared/types";

const riesling: TastingView = {
  id: "riesling-evening",
  title: "Riesling Evening",
  date: "2026-11-06",
  time: "18:00",
  pricePerGuest: 25,
  seats: 12,
  seatsLeft: 12,
  status: "open",
};

const confirmation: BookingView = {
  reference: "KB-TEST12",
  tastingId: "riesling-evening",
  tastingTitle: "Riesling Evening",
  date: "2026-11-06",
  time: "18:00",
  guests: 2,
  pricePerGuest: 25,
  total: 50,
};

function renderAt(path = "/tastings/riesling-evening/book") {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/tastings/:id/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<p>Confirmation for KB-TEST12</p>} />
        <Route path="/" element={<p>Home</p>} />
      </Routes>
    </MemoryRouter>,
  );
}

async function fillForm(user: ReturnType<typeof userEvent.setup>, { name = "Ann Müller", email = "ann@example.de", guests = "2" } = {}) {
  await user.type(await screen.findByLabelText("Name"), name);
  await user.type(screen.getByLabelText("Email"), email);
  await user.type(screen.getByLabelText("Guests"), guests);
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe("BookingPage form", () => {
  it("shows the tasting, its price, and the Name, Email, Guests fields and Book button", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([riesling]);
    renderAt();
    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByText("Friday, 6 November 2026, 18:00")).toBeInTheDocument();
    expect(screen.getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("shows field errors next to each empty field and marks them invalid", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([riesling]);
    const create = vi.spyOn(api, "createBooking");
    const user = userEvent.setup();
    renderAt();
    await user.click(await screen.findByRole("button", { name: "Book" }));

    expect(await screen.findByText("Please enter your name.")).toBeInTheDocument();
    expect(screen.getByText("Please enter a valid email address.")).toBeInTheDocument();
    expect(screen.getByText("Please enter between 1 and 8 guests.")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByLabelText("Guests")).toHaveAttribute("aria-invalid", "true");
    expect(create).not.toHaveBeenCalled();
  });

  it.each(["0", "9", "1.5"])("rejects guests %s with the guests message", async (guests) => {
    vi.spyOn(api, "getTastings").mockResolvedValue([riesling]);
    const create = vi.spyOn(api, "createBooking");
    const user = userEvent.setup();
    renderAt();
    await fillForm(user, { guests });
    await user.click(await screen.findByRole("button", { name: "Book" }));
    expect(await screen.findByText("Please enter between 1 and 8 guests.")).toBeInTheDocument();
    expect(create).not.toHaveBeenCalled();
  });

  it("refuses more guests than seats left without calling the server", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([{ ...riesling, seatsLeft: 2 }]);
    const create = vi.spyOn(api, "createBooking");
    const user = userEvent.setup();
    renderAt();
    await fillForm(user, { guests: "3" });
    await user.click(await screen.findByRole("button", { name: "Book" }));
    expect(await screen.findByText("Only 2 seats left.")).toBeInTheDocument();
    expect(create).not.toHaveBeenCalled();
  });

  it("books with the trimmed values and goes to the confirmation page", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([riesling]);
    const create = vi.spyOn(api, "createBooking").mockResolvedValue(confirmation);
    const user = userEvent.setup();
    renderAt();
    await fillForm(user, { name: "  Ann Müller ", email: " ann@example.de " });
    await user.click(await screen.findByRole("button", { name: "Book" }));

    expect(await screen.findByText("Confirmation for KB-TEST12")).toBeInTheDocument();
    expect(create).toHaveBeenCalledWith("riesling-evening", {
      name: "Ann Müller",
      email: "ann@example.de",
      guests: 2,
    });
  });

  it("shows a server field error next to the field it concerns", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([riesling]);
    vi.spyOn(api, "createBooking").mockRejectedValue(
      new ApiError("Not enough seats left.", 409, { guests: "Only 2 seats left." }),
    );
    const user = userEvent.setup();
    renderAt();
    await fillForm(user, { guests: "2" });
    await user.click(await screen.findByRole("button", { name: "Book" }));
    expect(await screen.findByText("Only 2 seats left.")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAttribute("aria-invalid", "true");
  });

  it("shows a general server error in an alert", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([riesling]);
    vi.spyOn(api, "createBooking").mockRejectedValue(new ApiError("This tasting is fully booked.", 409));
    const user = userEvent.setup();
    renderAt();
    await fillForm(user);
    await user.click(await screen.findByRole("button", { name: "Book" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("This tasting is fully booked.");
  });

  it("disables the button and says Booking… while the request is pending", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([riesling]);
    vi.spyOn(api, "createBooking").mockReturnValue(new Promise(() => {}));
    const user = userEvent.setup();
    renderAt();
    await fillForm(user);
    await user.click(await screen.findByRole("button", { name: "Book" }));
    const pending = await screen.findByRole("button", { name: "Booking…" });
    await waitFor(() => expect(pending).toBeDisabled());
  });

  it("shows fully booked with no form", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([{ ...riesling, seatsLeft: 0, status: "fully_booked" }]);
    renderAt();
    expect(await screen.findByText("This tasting is fully booked.")).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Book" })).not.toBeInTheDocument();
  });

  it("shows booking closed with no form", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([{ ...riesling, status: "closed" }]);
    renderAt();
    expect(await screen.findByText("Booking closed for this tasting.")).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).not.toBeInTheDocument();
  });

  it("shows Page not found for an unknown tasting", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([riesling]);
    renderAt("/tastings/nope/book");
    expect(await screen.findByRole("heading", { name: "Page not found" })).toBeInTheDocument();
  });
});
