// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router";
import ConfirmationPage from "../../src/client/pages/ConfirmationPage";
import { ApiError, api } from "../../src/client/api";
import type { BookingView } from "../../src/shared/types";

const booking: BookingView = {
  reference: "KB-TEST12",
  tastingId: "riesling-evening",
  tastingTitle: "Riesling Evening",
  date: "2026-11-06",
  time: "18:00",
  guests: 2,
  pricePerGuest: 25,
  total: 50,
};

function renderAt(reference: string) {
  return render(
    <MemoryRouter initialEntries={[`/bookings/${reference}`]}>
      <Routes>
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
      </Routes>
    </MemoryRouter>,
  );
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe("ConfirmationPage", () => {
  it("shows the heading, tasting, guests, total and booking reference", async () => {
    vi.spyOn(api, "getBooking").mockResolvedValue(booking);
    renderAt("KB-TEST12");

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(screen.getByText("Riesling Evening")).toBeInTheDocument();
    expect(screen.getByText("Friday, 6 November 2026, 18:00")).toBeInTheDocument();
    expect(screen.getByText("2")).toBeInTheDocument();
    expect(screen.getByText("EUR 50")).toBeInTheDocument();
    expect(screen.getByText("KB-TEST12")).toBeInTheDocument();
    expect(api.getBooking).toHaveBeenCalledWith("KB-TEST12");
  });

  it("offers a way back to all tastings", async () => {
    vi.spyOn(api, "getBooking").mockResolvedValue(booking);
    renderAt("KB-TEST12");
    expect(await screen.findByRole("link", { name: "Back to all tastings" })).toHaveAttribute("href", "/");
  });

  it("says Booking not found for an unknown reference", async () => {
    vi.spyOn(api, "getBooking").mockRejectedValue(new ApiError("Booking not found.", 404));
    renderAt("KB-NOPE00");
    expect(await screen.findByText("Booking not found.")).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Booking confirmed" })).not.toBeInTheDocument();
  });
});
