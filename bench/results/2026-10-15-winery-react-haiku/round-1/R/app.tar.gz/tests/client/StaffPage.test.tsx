// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router";
import StaffPage from "../../src/client/pages/StaffPage";
import { ApiError, api } from "../../src/client/api";
import type { StaffBookingsResponse } from "../../src/shared/types";

const fixture: StaffBookingsResponse = {
  tastings: [
    {
      id: "riesling-evening",
      title: "Riesling Evening",
      date: "2026-11-06",
      time: "18:00",
      seats: 12,
      seatsLeft: 10,
      bookings: [
        { id: "b1", reference: "KB-AAAAAA", name: "Ann Müller", email: "ann@example.de", guests: 2 },
      ],
    },
    {
      id: "red-wine-cellar-tour",
      title: "Red Wine Cellar Tour",
      date: "2026-11-14",
      time: "15:00",
      seats: 8,
      seatsLeft: 8,
      bookings: [],
    },
    {
      id: "winter-tasting",
      title: "Winter Tasting",
      date: "2026-12-05",
      time: "17:00",
      seats: 10,
      seatsLeft: 7,
      bookings: [
        { id: "b2", reference: "KB-BBBBBB", name: "Ben Winzer", email: "ben@example.de", guests: 3 },
      ],
    },
  ],
};

function renderPage() {
  return render(
    <MemoryRouter>
      <StaffPage />
    </MemoryRouter>,
  );
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe("StaffPage sign-in", () => {
  it("asks for the password when not signed in", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(null);
    renderPage();
    expect(await screen.findByRole("heading", { name: "Staff sign-in" })).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toHaveAttribute("type", "password");
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
  });

  it("asks for the password when the field is left empty", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(null);
    const signIn = vi.spyOn(api, "staffSignIn");
    const user = userEvent.setup();
    renderPage();
    await user.click(await screen.findByRole("button", { name: "Sign in" }));
    expect(await screen.findByText("Password is required.")).toBeInTheDocument();
    expect(signIn).not.toHaveBeenCalled();
  });

  it("shows Incorrect password. for a wrong password", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(null);
    vi.spyOn(api, "staffSignIn").mockRejectedValue(new ApiError("Incorrect password.", 401));
    const user = userEvent.setup();
    renderPage();
    await user.type(await screen.findByLabelText("Password"), "nope");
    await user.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Incorrect password.");
  });

  it("shows that sign-in is not configured when the server has no staff password", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(null);
    vi.spyOn(api, "staffSignIn").mockRejectedValue(new ApiError("Staff sign-in is not configured.", 503));
    const user = userEvent.setup();
    renderPage();
    await user.type(await screen.findByLabelText("Password"), "anything");
    await user.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Staff sign-in is not configured.");
  });
});

describe("StaffPage bookings", () => {
  it("shows bookings grouped by tasting after a correct sign-in", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(null);
    vi.spyOn(api, "staffSignIn").mockResolvedValue(undefined);
    vi.spyOn(api, "staffBookings").mockResolvedValue(fixture);
    const user = userEvent.setup();
    renderPage();
    await user.type(await screen.findByLabelText("Password"), "winery-pass");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();
    expect(screen.getByText("10 seats left")).toBeInTheDocument();

    const row = screen.getByRole("row", { name: /Ann Müller/ });
    expect(within(row).getByText("ann@example.de")).toBeInTheDocument();
    expect(within(row).getByText("2")).toBeInTheDocument();
    expect(within(row).getByText("KB-AAAAAA")).toBeInTheDocument();
    expect(within(row).getByRole("button", { name: "Cancel" })).toBeInTheDocument();
    expect(screen.getByText("No bookings yet.")).toBeInTheDocument();
    expect(api.staffSignIn).toHaveBeenCalledWith("winery-pass");
  });

  it("labels each booking cell with its column name for the stacked phone layout", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(fixture);
    renderPage();
    const row = await screen.findByRole("row", { name: /Ann Müller/ });
    expect(row.querySelector("td[data-label=\"Name\"]")).toHaveTextContent("Ann Müller");
    expect(row.querySelector("td[data-label=\"Email\"]")).toHaveTextContent("ann@example.de");
    expect(row.querySelector("td[data-label=\"Guests\"]")).toHaveTextContent("2");
    expect(row.querySelector("td[data-label=\"Reference\"]")).toHaveTextContent("KB-AAAAAA");
  });

  it("shows bookings straight away when a session already exists", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(fixture);
    renderPage();
    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.queryByLabelText("Password")).not.toBeInTheDocument();
  });

  it("cancels a booking and refreshes the list so its seats are freed", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(fixture);
    const cancel = vi.spyOn(api, "cancelBooking").mockResolvedValue(undefined);
    const after: StaffBookingsResponse = {
      tastings: [{ ...fixture.tastings[0], seatsLeft: 12, bookings: [] }, fixture.tastings[1], fixture.tastings[2]],
    };
    vi.spyOn(api, "staffBookings").mockResolvedValue(after);
    const user = userEvent.setup();
    renderPage();

    const row = (await screen.findByRole("row", { name: /Ann Müller/ }));
    await user.click(within(row).getByRole("button", { name: "Cancel" }));

    expect(cancel).toHaveBeenCalledWith("b1");
    await waitFor(() => expect(screen.queryByRole("row", { name: /Ann Müller/ })).not.toBeInTheDocument());
    expect(screen.getByText("12 seats left")).toBeInTheDocument();
  });

  it("signs out and returns to the password form", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(fixture);
    const signOut = vi.spyOn(api, "staffSignOut").mockResolvedValue(undefined);
    const user = userEvent.setup();
    renderPage();
    await user.click(await screen.findByRole("button", { name: "Sign out" }));
    expect(signOut).toHaveBeenCalled();
    expect(await screen.findByRole("heading", { name: "Staff sign-in" })).toBeInTheDocument();
  });

  it("shows an alert when cancelling fails", async () => {
    vi.spyOn(api, "staffSession").mockResolvedValue(fixture);
    vi.spyOn(api, "cancelBooking").mockRejectedValue(new ApiError("Booking not found.", 404));
    const user = userEvent.setup();
    renderPage();
    const row = await screen.findByRole("row", { name: /Ann Müller/ });
    await user.click(within(row).getByRole("button", { name: "Cancel" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Booking not found.");
  });
});
