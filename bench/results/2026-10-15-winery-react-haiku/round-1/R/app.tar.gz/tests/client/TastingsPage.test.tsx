// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import { render, screen, within } from "@testing-library/react";
import { MemoryRouter } from "react-router";
import TastingsPage from "../../src/client/pages/TastingsPage";
import { api } from "../../src/client/api";
import type { TastingView } from "../../src/shared/types";

const base = {
  date: "2026-11-06",
  time: "18:00",
  pricePerGuest: 25,
  status: "open" as const,
};

const tastingsFixture: TastingView[] = [
  { ...base, id: "riesling-evening", title: "Riesling Evening", date: "2026-11-06", time: "18:00", pricePerGuest: 25, seats: 12, seatsLeft: 12 },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", date: "2026-11-14", time: "15:00", pricePerGuest: 32, seats: 8, seatsLeft: 8, status: "open" },
  { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00", pricePerGuest: 28, seats: 10, seatsLeft: 10, status: "open" },
];

function renderPage() {
  return render(
    <MemoryRouter>
      <TastingsPage />
    </MemoryRouter>,
  );
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe("TastingsPage", () => {
  it("lists the three tastings with title, date and time, price and seats left", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue(tastingsFixture);
    renderPage();

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Red Wine Cellar Tour" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();

    expect(screen.getByText("Friday, 6 November 2026, 18:00")).toBeInTheDocument();
    expect(screen.getByText("EUR 25 per guest")).toBeInTheDocument();
    expect(screen.getByText("EUR 32 per guest")).toBeInTheDocument();
    expect(screen.getByText("12 seats left")).toBeInTheDocument();
    expect(screen.getByText("8 seats left")).toBeInTheDocument();
    expect(screen.getByText("10 seats left")).toBeInTheDocument();
  });

  it("links each open tasting with the button text 'Book <title>'", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue(tastingsFixture);
    renderPage();
    const link = await screen.findByRole("link", { name: "Book Riesling Evening" });
    expect(link).toHaveAttribute("href", "/tastings/riesling-evening/book");
    expect(screen.getByRole("link", { name: "Book Winter Tasting" })).toHaveAttribute("href", "/tastings/winter-tasting/book");
  });

  it("shows a fully booked tasting with a badge and no booking link", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([
      { ...tastingsFixture[2], seatsLeft: 0, status: "fully_booked" },
    ]);
    renderPage();
    const card = (await screen.findByRole("heading", { name: "Winter Tasting" })).closest("article")!;
    expect(within(card).getByText("Fully booked")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Winter Tasting" })).not.toBeInTheDocument();
  });

  it("shows a past tasting as booking closed with no booking link", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([{ ...tastingsFixture[0], status: "closed" }]);
    renderPage();
    expect(await screen.findByText("Booking closed")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Riesling Evening" })).not.toBeInTheDocument();
  });

  it("uses the singular for one seat left", async () => {
    vi.spyOn(api, "getTastings").mockResolvedValue([{ ...tastingsFixture[0], seatsLeft: 1 }]);
    renderPage();
    expect(await screen.findByText("1 seat left")).toBeInTheDocument();
  });

  it("shows an alert when the tastings cannot be loaded", async () => {
    vi.spyOn(api, "getTastings").mockRejectedValue(new Error("network down"));
    renderPage();
    expect(await screen.findByRole("alert")).toHaveTextContent("We could not load the tastings. Please try again later.");
  });
});
