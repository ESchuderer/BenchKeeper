// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import { ApiError, api } from "../../src/client/api";

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("api client", () => {
  it("turns a 400 with field errors into an ApiError carrying them", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        jsonResponse(400, {
          error: "Please check the highlighted fields.",
          fieldErrors: { guests: "Please enter between 1 and 8 guests." },
        }),
      ),
    );
    const error = await api.createBooking("riesling-evening", { name: "A", email: "a@b.de", guests: 2 }).catch((e) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect(error.status).toBe(400);
    expect(error.message).toBe("Please check the highlighted fields.");
    expect(error.fieldErrors).toEqual({ guests: "Please enter between 1 and 8 guests." });
  });

  it("posts a booking as JSON to the tasting's endpoint", async () => {
    const fetchMock = vi.fn(async () => jsonResponse(201, { reference: "KB-ABCDEF" }));
    vi.stubGlobal("fetch", fetchMock);
    await api.createBooking("winter-tasting", { name: "Ann", email: "ann@example.de", guests: 3 });
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe("/api/tastings/winter-tasting/bookings");
    expect(init.method).toBe("POST");
    expect(JSON.parse(String(init.body))).toEqual({ name: "Ann", email: "ann@example.de", guests: 3 });
  });

  it("gives a generic message when the error body is not JSON", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response("<html>oops</html>", { status: 500, headers: { "content-type": "text/html" } })));
    const error = await api.getTastings().catch((e) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect(error.status).toBe(500);
    expect(error.message).toBe("Something went wrong. Please try again.");
  });

  it("returns null from staffSession when not signed in", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => jsonResponse(401, { error: "Staff sign-in required." })));
    await expect(api.staffSession()).resolves.toBeNull();
  });

  it("throws the server's message from staffSignIn", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => jsonResponse(401, { error: "Incorrect password." })));
    await expect(api.staffSignIn("nope")).rejects.toMatchObject({ status: 401, message: "Incorrect password." });
  });
});
