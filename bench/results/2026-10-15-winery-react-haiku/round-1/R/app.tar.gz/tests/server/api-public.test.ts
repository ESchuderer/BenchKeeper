import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../../src/server/app";
import { BookingStore } from "../../src/server/store";

const BEFORE = () => new Date("2026-10-15T10:00:00Z");

function setup(now = BEFORE) {
  const store = new BookingStore({ now });
  const app = createApp({ store, now });
  return { app, store };
}

const valid = { name: "Ann Müller", email: "ann@example.de", guests: 2 };

function book(app: ReturnType<typeof createApp>, tastingId: string, body: unknown) {
  return request(app).post(`/api/tastings/${tastingId}/bookings`).send(body as object);
}

describe("GET /api/tastings", () => {
  it("lists the three tastings with seats left and status, without any email", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/tastings");
    expect(res.status).toBe(200);
    expect(res.body.map((t: { id: string }) => t.id)).toEqual([
      "riesling-evening",
      "red-wine-cellar-tour",
      "winter-tasting",
    ]);
    expect(res.body.map((t: { seatsLeft: number }) => t.seatsLeft)).toEqual([12, 8, 10]);
    expect(res.body[0]).toEqual({
      id: "riesling-evening",
      title: "Riesling Evening",
      date: "2026-11-06",
      time: "18:00",
      pricePerGuest: 25,
      seats: 12,
      seatsLeft: 12,
      status: "open",
    });
    expect(JSON.stringify(res.body)).not.toMatch(/email/i);
  });

  it("reports fully booked and closed statuses", async () => {
    const { app } = setup();
    await book(app, "red-wine-cellar-tour", { ...valid, guests: 8 }).expect(201);
    const res = await request(app).get("/api/tastings");
    expect(res.body[1].status).toBe("fully_booked");
    expect(res.body[1].seatsLeft).toBe(0);

    const late = setup(() => new Date("2026-11-07T10:00:00Z")).app;
    const closed = await request(late).get("/api/tastings");
    expect(closed.body[0].status).toBe("closed");
  });
});

describe("POST /api/tastings/:id/bookings", () => {
  it("creates a booking and returns the guest view with the total, and no name or email", async () => {
    const { app } = setup();
    const res = await book(app, "riesling-evening", valid);
    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(/^KB-[2-9A-HJ-NP-Z]{6}$/),
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      date: "2026-11-06",
      time: "18:00",
      guests: 2,
      pricePerGuest: 25,
      total: 50,
    });
    expect(JSON.stringify(res.body)).not.toMatch(/Ann|example\.de|email/);
  });

  it.each(["", "0", "9", "1.5", "abc", "  ", null, true])(
    "rejects guests %j with a field error and stores nothing",
    async (guests) => {
      const { app, store } = setup();
      const res = await book(app, "riesling-evening", { ...valid, guests });
      expect(res.status).toBe(400);
      expect(res.body.fieldErrors).toEqual({ guests: "Please enter between 1 and 8 guests." });
      expect(store.listBookings()).toHaveLength(0);
    },
  );

  it("returns field errors for a blank name and a bad email", async () => {
    const { app } = setup();
    const res = await book(app, "riesling-evening", { ...valid, name: " ", email: "nope" });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe("Please check the highlighted fields.");
    expect(res.body.fieldErrors).toEqual({
      name: "Please enter your name.",
      email: "Please enter a valid email address.",
    });
  });

  it("returns a JSON 400 for a malformed JSON body", async () => {
    const { app } = setup();
    const res = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "application/json")
      .send("{");
    expect(res.status).toBe(400);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body.error).toBe("Request body must be JSON.");
  });

  it("returns a JSON 400 when the body is not JSON at all", async () => {
    const { app } = setup();
    const res = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "text/plain")
      .send("name=Ann&guests=2");
    expect(res.status).toBe(400);
    expect(res.body.error).toBe("Request body must be JSON.");
  });

  it("returns a JSON 404 for an unknown tasting", async () => {
    const { app } = setup();
    const res = await book(app, "nope", valid);
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Tasting not found." });
  });

  it("refuses more guests than seats left, with the true seat count", async () => {
    const { app, store } = setup();
    await book(app, "riesling-evening", { ...valid, guests: 8 }).expect(201);
    await book(app, "riesling-evening", { ...valid, guests: 2 }).expect(201);
    const res = await book(app, "riesling-evening", { ...valid, guests: 3 });
    expect(res.status).toBe(409);
    expect(res.body.error).toBe("Not enough seats left.");
    expect(res.body.fieldErrors).toEqual({ guests: "Only 2 seats left." });
    expect(store.seatsLeft("riesling-evening")).toBe(2);
    expect((await request(app).get("/api/tastings")).body[0].seatsLeft).toBe(2);
    await book(app, "riesling-evening", { ...valid, guests: 2 }).expect(201);
  });

  it("uses the singular for one seat left", async () => {
    const { app } = setup();
    await book(app, "riesling-evening", { ...valid, guests: 8 }).expect(201);
    await book(app, "riesling-evening", { ...valid, guests: 3 }).expect(201);
    const res = await book(app, "riesling-evening", { ...valid, guests: 2 });
    expect(res.status).toBe(409);
    expect(res.body.fieldErrors.guests).toBe("Only 1 seat left.");
  });

  it("refuses a fully booked tasting", async () => {
    const { app } = setup();
    await book(app, "winter-tasting", { ...valid, guests: 8 }).expect(201);
    await book(app, "winter-tasting", { ...valid, guests: 2 }).expect(201);
    const res = await book(app, "winter-tasting", { ...valid, guests: 1 });
    expect(res.status).toBe(409);
    expect(res.body).toEqual({ error: "This tasting is fully booked." });
  });

  it("refuses a tasting that has already taken place", async () => {
    const { app } = setup(() => new Date("2026-11-07T10:00:00Z"));
    const res = await book(app, "riesling-evening", valid);
    expect(res.status).toBe(409);
    expect(res.body).toEqual({ error: "This tasting has already taken place." });
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the guest view for a known reference without the email", async () => {
    const { app } = setup();
    const created = await book(app, "winter-tasting", { ...valid, guests: 3 }).expect(201);
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual(created.body);
  });

  it("returns 404 for an unknown reference", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/bookings/KB-ZZZZZZ");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Booking not found." });
  });
});

describe("client mistakes that Express reports as 4xx", () => {
  it("answers a malformed percent-encoded path with a JSON 400, not a 500", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/bookings/%E0%A4%A");
    expect(res.status).toBe(400);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body).toEqual({ error: "The request could not be processed." });
  });

  it("answers an unsupported Content-Encoding with a JSON 415, not a 500", async () => {
    const { app } = setup();
    const res = await request(app)
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Encoding", "unsupported-encoding")
      .set("Content-Type", "application/json")
      .send("{}");
    expect(res.status).toBe(415);
    expect(res.body).toEqual({ error: "The request could not be processed." });
  });
});

describe("unknown API paths", () => {
  it("return a JSON 404", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/whatever");
    expect(res.status).toBe(404);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body).toEqual({ error: "Not found." });
  });
});
