import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../../src/server/app";
import { BookingStore } from "../../src/server/store";
import { StaffSessions, readCookie, verifyStaffPassword } from "../../src/server/staff-auth";

const PASSWORD = "s3cret-Pass";
const NOW = () => new Date("2026-10-15T10:00:00Z");

function setup(staffPassword: string | undefined = PASSWORD) {
  const store = new BookingStore({ now: NOW });
  const app = createApp({ store, now: NOW, staffPassword });
  return { app, store };
}

async function signIn(app: ReturnType<typeof createApp>, password = PASSWORD): Promise<string> {
  const res = await request(app).post("/api/staff/session").send({ password }).expect(204);
  const setCookie = res.headers["set-cookie"] as unknown as string[];
  const cookie = setCookie.find((c) => c.startsWith("staff_session="));
  if (!cookie) throw new Error("no session cookie");
  return cookie.split(";")[0];
}

const guest = { name: "Ann Müller", email: "ann@example.de", guests: 2 };

describe("POST /api/staff/session", () => {
  it.each(["nope", "", "S3CRET-PASS", "s3cret-Pass "])("refuses the password %j with 401", async (password) => {
    const { app } = setup();
    const res = await request(app).post("/api/staff/session").send({ password });
    if (password === "") {
      expect(res.status).toBe(400);
      expect(res.body.fieldErrors).toEqual({ password: "Password is required." });
    } else {
      expect(res.status).toBe(401);
      expect(res.body).toEqual({ error: "Incorrect password." });
    }
  });

  it("refuses a missing password key with a field error", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/staff/session").send({});
    expect(res.status).toBe(400);
    expect(res.body.fieldErrors).toEqual({ password: "Password is required." });
  });

  it("signs in with the right password and sets an HttpOnly, SameSite=Strict cookie", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });
    expect(res.status).toBe(204);
    const setCookie = (res.headers["set-cookie"] as unknown as string[])[0];
    expect(setCookie).toMatch(/^staff_session=[A-Za-z0-9_-]{20,}/);
    expect(setCookie).toMatch(/HttpOnly/);
    expect(setCookie).toMatch(/SameSite=Strict/i);
    expect(setCookie).toMatch(/Path=\//);
  });

  it("answers 503 when the staff password is not configured, for any password", async () => {
    for (const staffPassword of [undefined, ""]) {
      const app = createApp({ store: new BookingStore({ now: NOW }), now: NOW, staffPassword });
      const res = await request(app).post("/api/staff/session").send({ password: "" });
      expect(res.status).toBe(503);
      expect(res.body).toEqual({ error: "Staff sign-in is not configured." });
      const res2 = await request(app).post("/api/staff/session").send({ password: PASSWORD });
      expect(res2.status).toBe(503);
    }
  });
});

describe("sign-in throttling", () => {
  it("locks sign-in for an address after five wrong passwords, and releases it after 15 minutes", async () => {
    let clock = new Date("2026-10-15T10:00:00Z");
    const app = createApp({ store: new BookingStore({ now: () => clock }), now: () => clock, staffPassword: PASSWORD });
    for (let i = 0; i < 5; i++) {
      expect((await request(app).post("/api/staff/session").send({ password: "wrong" })).status).toBe(401);
    }
    const locked = await request(app).post("/api/staff/session").send({ password: PASSWORD });
    expect(locked.status).toBe(429);
    expect(locked.body).toEqual({ error: "Too many attempts. Try again later." });

    clock = new Date(clock.getTime() + 15 * 60 * 1000 + 1000);
    await request(app).post("/api/staff/session").send({ password: PASSWORD }).expect(204);
  });

  it("clears the failure count after a successful sign-in", async () => {
    const app = createApp({ store: new BookingStore({ now: NOW }), now: NOW, staffPassword: PASSWORD });
    for (let i = 0; i < 4; i++) {
      await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(401);
    }
    await request(app).post("/api/staff/session").send({ password: PASSWORD }).expect(204);
    for (let i = 0; i < 4; i++) {
      await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(401);
    }
    await request(app).post("/api/staff/session").send({ password: PASSWORD }).expect(204);
  });
});

describe("staff routes without a valid session", () => {
  it("return 401 for the bookings list, a forged cookie, and cancel", async () => {
    const { app, store } = setup();
    const created = store.book("riesling-evening", { name: "Ann", email: "ann@example.de", guests: 2 });
    if (!created.ok) throw new Error("setup");
    expect((await request(app).get("/api/staff/bookings")).status).toBe(401);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", "staff_session=abc")).status).toBe(401);
    expect((await request(app).delete(`/api/staff/bookings/${created.booking.id}`)).status).toBe(401);
    expect(store.listBookings()).toHaveLength(1);
  });
});

describe("staff bookings with a session", () => {
  it("lists every tasting in order with its bookings, including name and email", async () => {
    const { app, store } = setup();
    store.book("riesling-evening", guest);
    const cookie = await signIn(app);
    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(res.status).toBe(200);
    expect(res.body.tastings.map((t: { id: string }) => t.id)).toEqual([
      "riesling-evening",
      "red-wine-cellar-tour",
      "winter-tasting",
    ]);
    const riesling = res.body.tastings[0];
    expect(riesling.seatsLeft).toBe(10);
    expect(riesling.bookings).toEqual([
      {
        id: expect.any(String),
        reference: expect.stringMatching(/^KB-/),
        name: "Ann Müller",
        email: "ann@example.de",
        guests: 2,
      },
    ]);
    expect(res.body.tastings[1].bookings).toEqual([]);
  });

  it("never echoes the password in any response", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/staff/session").send({ password: "wrong" });
    expect(JSON.stringify(res.body)).not.toContain(PASSWORD);
    const cookie = await signIn(app);
    const list = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(JSON.stringify(list.body)).not.toContain(PASSWORD);
  });

  it("cancels a booking, frees its seats, and refuses a second cancel or an unknown id", async () => {
    const { app, store } = setup();
    const created = store.book("riesling-evening", guest);
    if (!created.ok) throw new Error("setup");
    const cookie = await signIn(app);

    await request(app).delete(`/api/staff/bookings/${created.booking.id}`).set("Cookie", cookie).expect(204);
    expect((await request(app).get("/api/tastings")).body[0].seatsLeft).toBe(12);
    expect((await request(app).delete(`/api/staff/bookings/${created.booking.id}`).set("Cookie", cookie)).status).toBe(404);
    expect((await request(app).delete("/api/staff/bookings/unknown").set("Cookie", cookie)).status).toBe(404);
    expect((await request(app).get("/api/tastings")).body[0].seatsLeft).toBe(12);
  });

  it("ends the session on sign-out", async () => {
    const { app } = setup();
    const cookie = await signIn(app);
    await request(app).delete("/api/staff/session").set("Cookie", cookie).expect(204);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(401);
  });
});

describe("verifyStaffPassword", () => {
  it("accepts only the exact password", () => {
    expect(verifyStaffPassword(PASSWORD, PASSWORD)).toBe("ok");
    for (const wrong of ["", "nope", "S3CRET-PASS", "s3cret-Pass ", 123, undefined, null]) {
      expect(verifyStaffPassword(wrong, PASSWORD)).toBe("wrong");
    }
  });

  it("reports not_configured for an unset or empty expected password", () => {
    expect(verifyStaffPassword(PASSWORD, undefined)).toBe("not_configured");
    expect(verifyStaffPassword(PASSWORD, "")).toBe("not_configured");
  });
});

describe("StaffSessions", () => {
  it("expires a session after its time to live", () => {
    let clock = new Date("2026-10-15T10:00:00Z");
    const sessions = new StaffSessions({ now: () => clock, ttlMs: 1000 });
    const token = sessions.create();
    expect(sessions.isValid(token)).toBe(true);
    clock = new Date("2026-10-15T10:00:02Z");
    expect(sessions.isValid(token)).toBe(false);
  });

  it("reads a named cookie from a Cookie header", () => {
    expect(readCookie("a=1; staff_session=tok%3D; b=2", "staff_session")).toBe("tok=");
    expect(readCookie(undefined, "staff_session")).toBeUndefined();
  });
});
