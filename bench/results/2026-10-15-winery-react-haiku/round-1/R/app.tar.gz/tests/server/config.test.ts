import { describe, expect, it } from "vitest";
import { readConfig } from "../../src/server/config";

describe("readConfig", () => {
  it("defaults to port 3000 and no staff password", () => {
    expect(readConfig({})).toEqual({ port: 3000, staffPassword: undefined });
  });

  it("reads PORT and STAFF_PASSWORD", () => {
    expect(readConfig({ PORT: "8080", STAFF_PASSWORD: "x" })).toEqual({ port: 8080, staffPassword: "x" });
  });

  it("treats an empty STAFF_PASSWORD as unset", () => {
    expect(readConfig({ STAFF_PASSWORD: "" }).staffPassword).toBeUndefined();
  });

  it.each(["abc", "0", "70000", "3000.5", "-1", " "])("rejects PORT %j", (port) => {
    expect(() => readConfig({ PORT: port })).toThrow("PORT must be a number between 1 and 65535.");
  });
});
