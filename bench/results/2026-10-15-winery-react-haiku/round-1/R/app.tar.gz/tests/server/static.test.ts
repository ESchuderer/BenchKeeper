import { mkdtempSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../../src/server/app";

let clientDir: string;

beforeAll(() => {
  clientDir = mkdtempSync(join(tmpdir(), "kb-client-"));
  mkdirSync(join(clientDir, "assets"));
  writeFileSync(join(clientDir, "index.html"), "<!doctype html><title>Kieselbrunnen app shell</title>");
  writeFileSync(join(clientDir, "assets", "app.js"), "console.log('app');");
});

describe("static client serving", () => {
  const app = () => createApp({ clientDir });

  it.each(["/", "/tastings/riesling-evening/book", "/bookings/KB-ABCDEF", "/staff"])(
    "serves the app shell for %s",
    async (path) => {
      const res = await request(app()).get(path);
      expect(res.status).toBe(200);
      expect(res.text).toContain("Kieselbrunnen app shell");
    },
  );

  it("serves built assets", async () => {
    const res = await request(app()).get("/assets/app.js");
    expect(res.status).toBe(200);
    expect(res.text).toContain("console.log");
  });

  it("returns 404 for a missing asset instead of the app shell", async () => {
    const res = await request(app()).get("/assets/missing.js");
    expect(res.status).toBe(404);
    expect(res.text).not.toContain("app shell");
  });

  it("keeps the JSON API working", async () => {
    const res = await request(app()).get("/api/tastings");
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(3);
  });

  it("keeps unknown API paths as JSON 404, not the app shell", async () => {
    const res = await request(app()).get("/api/nothing");
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: "Not found." });
  });
});
