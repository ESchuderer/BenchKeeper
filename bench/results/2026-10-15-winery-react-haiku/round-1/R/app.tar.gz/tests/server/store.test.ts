import { describe, expect, it } from "vitest";
import { BookingStore } from "../../src/server/store";

const riesling = "riesling-evening"; // 12 seats, 2026-11-06 18:00
const redWine = "red-wine-cellar-tour"; // 8 seats, 2026-11-14 15:00
const beforeAll = () => new Date("2026-10-15T10:00:00Z");

function input(guests: number, name = "Ann", email = "ann@example.de") {
  return { name, email, guests };
}

describe("BookingStore", () => {
  it("starts empty with all seats free", () => {
    const store = new BookingStore({ now: beforeAll });
    expect(store.listBookings()).toEqual([]);
    expect(store.seatsLeft(riesling)).toBe(12);
  });

  it("reduces seats left by the number of guests", () => {
    const store = new BookingStore({ now: beforeAll });
    const result = store.book(riesling, input(3));
    expect(result.ok).toBe(true);
    expect(store.seatsLeft(riesling)).toBe(9);
  });

  it("accepts a booking that takes exactly the last seats, then reports fully booked", () => {
    const store = new BookingStore({ now: beforeAll });
    expect(store.book(redWine, input(8)).ok).toBe(true);
    expect(store.seatsLeft(redWine)).toBe(0);
    expect(store.book(redWine, input(1))).toEqual({ ok: false, code: "FULLY_BOOKED", seatsLeft: 0 });
  });

  it("rejects more guests than seats left and stores nothing", () => {
    const store = new BookingStore({ now: beforeAll });
    store.book(redWine, input(5));
    expect(store.book(redWine, input(4))).toEqual({ ok: false, code: "INSUFFICIENT_SEATS", seatsLeft: 3 });
    expect(store.seatsLeft(redWine)).toBe(3);
    expect(store.listBookings()).toHaveLength(1);
  });

  it("never overbooks when many bookings arrive in one burst", () => {
    const store = new BookingStore({ now: beforeAll });
    const results = Array.from({ length: 20 }, () => store.book(riesling, input(1)));
    expect(results.filter((r) => r.ok)).toHaveLength(12);
    expect(store.seatsLeft(riesling)).toBe(0);
  });

  it("frees seats when a booking is cancelled, and only once", () => {
    const store = new BookingStore({ now: beforeAll });
    const result = store.book(riesling, input(4));
    if (!result.ok) throw new Error("setup failed");
    expect(store.cancel(result.booking.id)).toBe(true);
    expect(store.seatsLeft(riesling)).toBe(12);
    expect(store.cancel(result.booking.id)).toBe(false);
    expect(store.cancel("does-not-exist")).toBe(false);
    expect(store.seatsLeft(riesling)).toBe(12);
  });

  it("gives every booking a unique, well-formed reference that can be found again", () => {
    const store = new BookingStore({ now: beforeAll });
    const refs = new Set<string>();
    for (let i = 0; i < 500; i++) {
      // Cancel each one so the 12 seats are free again for the next draw.
      const result = store.book(riesling, input(1));
      if (!result.ok) throw new Error("unexpected " + result.code);
      expect(result.booking.reference).toMatch(/^KB-[2-9A-HJ-NP-Z]{6}$/);
      refs.add(result.booking.reference);
      expect(store.findByReference(result.booking.reference)?.id).toBe(result.booking.id);
      store.cancel(result.booking.id);
    }
    expect(refs.size).toBe(500);
    expect(store.findByReference("KB-NOPE00")).toBeUndefined();
  });

  it("refuses bookings for a tasting that has already taken place", () => {
    const store = new BookingStore({ now: () => new Date("2026-11-07T10:00:00Z") });
    expect(store.book(riesling, input(1))).toEqual({ ok: false, code: "CLOSED", seatsLeft: 12 });
  });

  it("reports an unknown tasting as not found", () => {
    const store = new BookingStore({ now: beforeAll });
    expect(store.book("nope", input(1))).toEqual({ ok: false, code: "NOT_FOUND", seatsLeft: 0 });
    expect(store.seatsLeft("nope")).toBe(0);
  });
});
