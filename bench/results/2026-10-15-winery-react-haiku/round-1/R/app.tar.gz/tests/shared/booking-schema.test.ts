import { describe, expect, it } from "vitest";
import { bookingInputSchema } from "../../src/shared/booking-schema";

const valid = { name: "  Ann Müller ", email: " ann@example.de ", guests: "2" };

function errorsFor(input: unknown) {
  const result = bookingInputSchema.safeParse(input);
  if (result.success) return {};
  const out: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const key = String(issue.path[0]);
    out[key] ??= issue.message;
  }
  return out;
}

describe("bookingInputSchema", () => {
  it("accepts valid input, trims name and email and converts guests to a number", () => {
    const result = bookingInputSchema.safeParse(valid);
    expect(result.success).toBe(true);
    expect(result.success && result.data).toEqual({ name: "Ann Müller", email: "ann@example.de", guests: 2 });
  });

  it("accepts a numeric guests value and whitespace around a digit string", () => {
    expect(bookingInputSchema.safeParse({ ...valid, guests: 8 }).success).toBe(true);
    expect(bookingInputSchema.safeParse({ ...valid, guests: " 2 " }).success).toBe(true);
  });

  it.each(["", "0", "9", "1.5", "abc", "  ", null, true, -1, 1.5])(
    "rejects guests %j with the guests message only",
    (guests) => {
      expect(errorsFor({ ...valid, guests })).toEqual({
        guests: "Please enter between 1 and 8 guests.",
      });
    },
  );

  it("rejects a blank name and a name over 100 characters", () => {
    expect(errorsFor({ ...valid, name: "   " })).toEqual({ name: "Please enter your name." });
    expect(errorsFor({ ...valid, name: "x".repeat(101) })).toEqual({ name: "Please enter your name." });
  });

  it.each(["ann@", "a b@c.de", "no-at-sign.de", ""])("rejects email %j", (email) => {
    expect(errorsFor({ ...valid, email })).toEqual({
      email: "Please enter a valid email address.",
    });
  });

  it("reports every invalid field together", () => {
    expect(errorsFor({ name: "", email: "x", guests: "" })).toEqual({
      name: "Please enter your name.",
      email: "Please enter a valid email address.",
      guests: "Please enter between 1 and 8 guests.",
    });
  });
});
