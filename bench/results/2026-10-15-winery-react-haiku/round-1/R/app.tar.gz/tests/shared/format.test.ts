import { describe, expect, it } from "vitest";
import { formatDateTime, formatPrice, isTastingPast } from "../../src/shared/format";
import { getTasting, tastings } from "../../src/shared/tastings";

describe("tastings data", () => {
  it("lists the three tastings exactly as the requester specified", () => {
    expect(tastings).toEqual([
      { id: "riesling-evening", title: "Riesling Evening", date: "2026-11-06", time: "18:00", pricePerGuest: 25, seats: 12 },
      { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", date: "2026-11-14", time: "15:00", pricePerGuest: 32, seats: 8 },
      { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00", pricePerGuest: 28, seats: 10 },
    ]);
  });

  it("finds a tasting by id and returns undefined for an unknown id", () => {
    expect(getTasting("winter-tasting")?.title).toBe("Winter Tasting");
    expect(getTasting("nope")).toBeUndefined();
  });
});

describe("formatPrice", () => {
  it("formats whole euros with the EUR prefix", () => {
    expect(formatPrice(25)).toBe("EUR 25");
    expect(formatPrice(50)).toBe("EUR 50");
  });
});

describe("formatDateTime", () => {
  it("formats date and time without time-zone conversion", () => {
    expect(formatDateTime("2026-11-06", "18:00")).toBe("Friday, 6 November 2026, 18:00");
    expect(formatDateTime("2026-12-05", "17:00")).toBe("Saturday, 5 December 2026, 17:00");
  });
});

describe("isTastingPast", () => {
  const riesling = getTasting("riesling-evening")!;

  it("is false until the start time in Europe/Berlin", () => {
    // 2026-11-06 17:59 Berlin (CET, UTC+1) is 16:59 UTC
    expect(isTastingPast(riesling, new Date("2026-11-06T16:59:00Z"))).toBe(false);
  });

  it("is true from the start time in Europe/Berlin", () => {
    // 2026-11-06 18:00 Berlin is 17:00 UTC
    expect(isTastingPast(riesling, new Date("2026-11-06T17:00:00Z"))).toBe(true);
  });
});
