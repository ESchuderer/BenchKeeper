---
description: Implement tasks from an OpenSpec change in existing worktree (Experimental)
---

按照 schema 定义的 apply 阶段流程，在已存在的 worktree 中实现变更。

**Input**: 可选指定变更名称（如 `/opsx-apply add-auth`）。省略时从上下文推断，如果模糊则用 AskUserQuestion 让用户选择。

**Apply 只负责实现**——worktree 由 `/opsx-ff` / `/opsx-new` 提前创建。

```
1. 选择变更 → 检测 worktree → 进入
2. Pre-flight → 检查 skill 文件、工具链
3. 逐任务实现 → task() 派 Agent + 审查
4. Verification → openspec status
5. 提交 → 在 worktree 中提交
```

合并、清理、retrospective、archive、PR 由 `/opsx-finish` 处理。

---

### Step 1: 选择变更

如果提供了名称则直接用，否则：
- 从上下文推断
- 如果只有一个活跃变更则自动选中
- 如果模糊则运行：

  ```bash
  openspec-superpowers-opencode verify
  ```

  - **成功（exit 0）** → 执行 `openspec list --json` → 获取活动 changes → 使用 **AskUserQuestion** 工具让用户选择
  - **失败（exit 1）** →
    - 向用户展示 verify 的输出结果（诊断报告和修复建议）
    - 用 `question` 工具询问用户：**修复** 或者 **停止**
    - 用户选择**修复**，根据 verify 输出的修复命令执行修复 → 修复成功后重新执行本步骤
    - 用户选择**停止**，中断流程

宣布：`"Using change: <name>"`

### Step 2: 确保 worktree 存在并进入

```bash
openspec-superpowers-opencode ensure-worktree <name>
cd .worktrees/<name>
```

### Step 3: 读取 schema apply 指令

```bash
openspec instructions apply --change "<name>" --json
```

同时读取 schema.yaml 中的 `apply:` 阶段指令了解完整流程。

### Step 4: Pre-flight

**4a. 检测 Superpowers 版本并确认 skill 文件都可 Read：**

先读取 `/home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/../package.json` 的 `version` 字段，
取主版本号（如 `5` 或 `6`），然后按版本检查对应文件。

**Superpowers v5：**
Read：
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/implementer-prompt.md
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/spec-reviewer-prompt.md
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/code-quality-reviewer-prompt.md
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/test-driven-development/SKILL.md

**Superpowers v6：**
Read：
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/implementer-prompt.md
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/task-reviewer-prompt.md
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/test-driven-development/SKILL.md

如果有任一 Read 失败，STOP 并告知用户，不要静默降级。

**4b. 确认 plan.md 中提到的工具链（mvn、docker、node 等）可用。**

**4c. 确认 .gitignore 已就绪：**

读取 plan.md，如果计划中包含 `npm install` / `cargo build` / `pip install` 等
会产生构建产物的命令，则在执行前确认对应子目录已有 .gitignore 排除产物：

| 项目类型 | 需排除的产物 |
|---------|-------------|
| Node/TypeScript | `node_modules/`, `dist/`, `*.tsbuildinfo` |
| Rust | `target/` |
| Python | `__pycache__/`, `*.pyc`, `.venv/`, `dist/` |
| Go | 二进制产物 |

**原则：先写 .gitignore，再跑 install/build。避免产物被误提交。**

### Step 5: 逐任务实现

先检测 Superpowers 版本，然后按对应版本流程执行。

**Superpowers v5 流程：**

Read：
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/implementer-prompt.md
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/test-driven-development/SKILL.md

对 plan.md 中的每个微任务：
1. 使用 implementer-prompt.md 模板构造基础 prompt
2. 从 TDD SKILL.md 中提取 RED-GREEN-REFACTOR 流程、铁律作为 prompt 的前置指令
3. 通过 `task()` 派 Agent 实现（load_skills=[]，TDD 通过 prompt 嵌入传递）：

```typescript
task(
  category="deep",
  load_skills=[],
  description="实现 <任务名>",
  prompt="<TDD 前置指令 + 模板填充后的内容>",
  run_in_background=true
)
```

**Superpowers v6 流程：**

Read：
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/SKILL.md
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/implementer-prompt.md
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/test-driven-development/SKILL.md

对 plan.md 中的每个微任务：
1. 运行 `/home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/scripts/task-brief <plan.md 路径> <任务序号>`，提取任务到文件，记录返回的文件路径
2. 使用 implementer-prompt.md 模板构造基础 prompt，嵌入 task-brief 返回的文件路径
3. 从 TDD SKILL.md 中提取 RED-GREEN-REFACTOR 流程、铁律作为 prompt 的前置指令
4. 通过 `task()` 派 Agent 实现（load_skills=[]，TDD 通过 prompt 嵌入传递）：

```typescript
task(
  category="deep",
  load_skills=[],
  description="实现 <任务名>",
  prompt="<TDD 前置指令 + 模板填充后的内容，包含 task-brief 文件路径>",
  run_in_background=true
)
```

> 注意：Superpowers skills 是文件系统路径，不支持 `load_skills` 机制。
> 必须通过 Read 读取后在 prompt 中嵌入 TDD 指令。

### Step 6: 审查每个任务的产出

根据 Superpowers 版本执行对应审查流程。

**Superpowers v5（两步审查）：**

任务完成后，依次执行两项审查：

**Spec 审查**：
Read：
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/spec-reviewer-prompt.md

用 spec-reviewer-prompt.md 模板构造审查 prompt，派 `task(subagent_type="oracle", ...)` 审查。

**代码质量审查**：
Read：
  /home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/code-quality-reviewer-prompt.md

用 code-quality-reviewer-prompt.md 模板构造审查 prompt，派 `task(subagent_type="oracle", ...)` 审查。

全部通过 → 标记 tasks.md checkbox 为完成。

**Superpowers v6（单步审查）：**

先运行 `/home/node/.cache/opencode/packages/superpowers@git+https:/github.com/obra/superpowers.git#v6.1.1/node_modules/superpowers/skills/subagent-driven-development/scripts/review-package BASE HEAD` 生成 diff package，记录返回的文件路径。

然后读取 task-reviewer-prompt.md，构造审查 prompt（嵌入 diff package 路径），
派 `task(subagent_type="oracle", ...)` 一次审查（spec compliance + code quality）。

审查通过 → 标记 tasks.md checkbox 为完成。

### Step 7: Verification

所有任务完成后，在 worktree 中运行验证：

```bash
openspec status --change "<name>" --json
```

确认所有 artifacts 已完成。如果有未完成的，按提示补充。

### Step 8: 在 worktree 中提交变更

```bash
git add -A && git commit -m "<name>: <描述>"
```

### 完成

```
✓ 变更 <name> 已实现并提交。
  Worktree 路径: .worktrees/<name>/
  分支: feature/<name>

下一步: 运行 /opsx-finish 进行合并、清理和归档。
```

---

**幂等性**：如果某些步骤已完成（如已实现部分任务、已提交），则跳过。
通过检查 `.worktrees/<name>/` 是否存在、`git status`、tasks.md 的 checkbox 状态等来判断。

**用户中断**：任何时候用户可中断。再次运行 `/opsx-apply` 时从上一次中断处继续。
