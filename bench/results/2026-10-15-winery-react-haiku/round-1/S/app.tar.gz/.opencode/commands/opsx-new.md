---
description: Start a new change in an isolated worktree (Experimental)
---

覆盖 OpenSpec 内置命令。创建 worktree → 在 worktree 内生成变更 → commit → 回 main。

**Input**: 变更名称（kebab-case），或变更描述。

### Step 1: 确定名称

如果提供了名称则直接用。否则 AskUserQuestion：

> "你想创建什么变更？描述一下你要构建或修复的内容。"

从描述推导 kebab-case 名称（如 "add user authentication" → `add-user-auth`）。

**不要在不理解用户意图时继续。**

### Step 2: 确定 schema

默认使用当前项目的 schema。除非用户明确要求其他 workflow，不要加 `--schema`。

### Step 3: 确认 git 仓库已有至少一个 commit

**3a. 检查 HEAD 是否存在：**

```bash
git rev-parse --verify HEAD
```

- 返回 0 → 跳到 3c
- 返回非 0 → 跳到 3b

**3b. 创建首次提交：**

```bash
git add -A && git commit -m "chore: initial project setup"
```

跳到 Step 4

**3c. 检查 main 是否有未提交更改：**

```bash
git status --porcelain
```

- 输出为空 → 跳到 Step 4
- 输出非空 → 用 **question** 工具询问：

  > **main 分支有未提交的更改。是否先提交？(y/N)**
  >
  > - **N** → 不提交，跳到 Step 4
  > - **Y** →

  **3c-1. 提交变更：**

  ```bash
  git add -A && git commit
  ```

  **3c-2. 确认提交：**

  ```bash
  git log --oneline -1
  ```

  - 显示有新 commit → 成功，跳到 Step 4
  - 无新 commit 或报错 → 失败，回到 3c-1 重试

### Step 4: 创建隔离 Worktree

Artifacts 应在 feature 分支上生成，不在 main 上留痕迹。

**4a. 创建 worktree：**

```bash
openspec-superpowers-opencode ensure-worktree <name>
cd .worktrees/<name>
# 复制 .gitignore 忽略的 openspec/schemas/ 和 config.yaml 到 worktree
mkdir -p openspec/schemas/
cp -r <project-root>/openspec/schemas/* openspec/schemas/ && cp <project-root>/openspec/config.yaml openspec/
```

**验证复制是否成功：**
```bash
test -f openspec/config.yaml && test -f openspec/schemas/superpowers-bridge-opencode/schema.yaml && test -f openspec/schemas/superpowers-bridge-opencode/templates/brainstorm.md
```

- **成功** → 继续
- **失败** → 重新执行复制再验证，成功后才能进入下一步

> worktree 继承了 repo 的所有基础设施文件（`.opencode/`、`openspec/config.yaml` 等）。

**4b. 初始化代码索引：**

```
- codegraph 命令可用 → codegraph init
```

命令不存在或初始化失败不阻断流程，继续下一步。

### Step 5: 在 worktree 内创建变更

```bash
openspec new change "<name>"
```

#### Step 5a: 注册变更到 registry

记录 change 到注册表，供后续 opsx 命令查找活跃变更以及对应的 worktree：

```bash
openspec-superpowers-opencode registry add <name> .worktrees/<name>
```

- **成功（exit 0）** → 继续 Step 6
- **失败（exit 1）** →
  - 执行 `openspec-superpowers-opencode verify`，向用户展示输出结果
  - 用 `question` 工具询问用户：**修复** 或者 **停止**
  - 用户选择**修复**，根据 verify 输出的修复命令执行修复 → 修复成功后重新继续 Step 5a
  - 用户选择**停止**，中断流程

### Step 6: 展示第一个 artifact

```bash
openspec status --change "<name>"
openspec instructions <first-artifact-id> --change "<name>"
```

展示第一个 artifact 的 template 和 instruction，**不需要创建它**。

### Step 7: 提交 scaffold 并回 main

```bash
git add -A && git commit -m "change: <name> (scaffold)"
cd <project-root>
```

### Output

总结变更信息：

- 变更：`<name>`
- Worktree：`.worktrees/<name>/`
- 分支：`feature/<name>`
- Schema：...
- 下一步：`/opsx-continue` 创建下一个 artifact，或 `/opsx-ff <name>` 一次性生成全部

### Guardrails

- 如果同名变更已存在，建议用 `/opsx-continue`
- 不要创建任何 artifact——只展示第一个的 template
- worktree 创建后自动 `cd .worktrees/<name>`，后续命令（`/opsx-continue`）需检测 worktree
