// @vitest-environment jsdom
import { describe, it, expect, beforeEach } from "vitest";
import { render, screen } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { App } from "./App.js";
import { jsonResponse, mockFetch } from "./test-helpers.js";

const tastings = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    date: "2026-11-06",
    time: "18:00",
    pricePerGuest: 25,
    seats: 12,
    seatsLeft: 12,
  },
];

describe("App", () => {
  let user: ReturnType<typeof userEvent.setup>;
  beforeEach(() => {
    user = userEvent.setup();
  });

  beforeEach(() => {
    window.history.pushState({}, "", "/");
  });

  it("takes a guest from the tastings list through booking to the confirmation", async () => {
    const mock = mockFetch((url, init) => {
      if (url === "/api/tastings") return jsonResponse(200, tastings);
      if (url === "/api/bookings" && init?.method === "POST") {
        return jsonResponse(201, {
          reference: "KB-ABC234",
          tastingId: "riesling-evening",
          tastingTitle: "Riesling Evening",
          guests: 2,
          totalPrice: 50,
        });
      }
      if (url === "/api/bookings/KB-ABC234") {
        return jsonResponse(200, {
          reference: "KB-ABC234",
          tastingId: "riesling-evening",
          tastingTitle: "Riesling Evening",
          guests: 2,
          totalPrice: 50,
        });
      }
      return jsonResponse(404, { error: "not mocked" });
    });

    render(<App />);
    await user.click(await screen.findByRole("link", { name: "Book Riesling Evening" }));

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    await user.type(screen.getByLabelText("Name"), "Ada Guest");
    await user.type(screen.getByLabelText("Email"), "ada@example.com");
    await user.type(screen.getByLabelText("Guests"), "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    expect(screen.getByText("EUR 50")).toBeInTheDocument();
    expect(screen.getByText("KB-ABC234")).toBeInTheDocument();
    expect(mock).toHaveBeenCalled();
  });

  it("links to the staff page from the site header", async () => {
    mockFetch(() => jsonResponse(200, tastings));
    render(<App />);

    const nav = screen.getByRole("navigation", { name: "Main" });
    expect(await screen.findByRole("link", { name: "Staff" })).toHaveAttribute("href", "/staff");
    expect(nav).toBeInTheDocument();
  });

  it("shows a friendly page for unknown addresses", async () => {
    window.history.pushState({}, "", "/no-such-page");
    mockFetch(() => jsonResponse(200, tastings));
    render(<App />);

    expect(await screen.findByRole("heading", { name: "Page not found" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Back to the tastings" })).toHaveAttribute("href", "/");
  });
});
