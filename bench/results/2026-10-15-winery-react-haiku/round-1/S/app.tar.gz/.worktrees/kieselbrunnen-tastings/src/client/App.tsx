import { BrowserRouter, Route, Routes } from "react-router";
import { SiteLayout } from "./components/SiteLayout.js";
import { TastingsPage } from "./pages/TastingsPage.js";
import { BookingPage } from "./pages/BookingPage.js";
import { ConfirmationPage } from "./pages/ConfirmationPage.js";
import { StaffPage } from "./pages/StaffPage.js";
import { NotFoundPage } from "./pages/NotFoundPage.js";

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<SiteLayout />}>
          <Route index element={<TastingsPage />} />
          <Route path="book/:tastingId" element={<BookingPage />} />
          <Route path="booking/:reference" element={<ConfirmationPage />} />
          <Route path="staff" element={<StaffPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
