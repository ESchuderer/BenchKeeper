import type { BookingFieldErrors, BookingInput } from "../shared/booking-schema.js";
import type {
  ApiErrorBody,
  ConfirmedBooking,
  PublicTasting,
  StaffTastingGroup,
} from "../shared/api-types.js";

export class ApiUnavailableError extends Error {
  constructor(message = "The service is unavailable.") {
    super(message);
    this.name = "ApiUnavailableError";
  }
}

async function send(
  method: string,
  url: string,
  body?: unknown,
): Promise<{ status: number; data: ApiErrorBody & unknown }> {
  let response: Response;
  try {
    response = await fetch(url, {
      method,
      headers: body === undefined ? undefined : { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: "same-origin",
    });
  } catch {
    throw new ApiUnavailableError();
  }
  const text = response.status === 204 ? "" : await response.text();
  const data = text ? JSON.parse(text) : undefined;
  return { status: response.status, data };
}

export async function getTastings(): Promise<PublicTasting[]> {
  const { status, data } = await send("GET", "/api/tastings");
  if (status !== 200) throw new ApiUnavailableError();
  return data as PublicTasting[];
}

export type CreateBookingResult =
  | { ok: true; booking: ConfirmedBooking }
  | { ok: false; status: number; errors: BookingFieldErrors; seatsLeft?: number };

export async function createBooking(input: BookingInput): Promise<CreateBookingResult> {
  const { status, data } = await send("POST", "/api/bookings", input);
  if (status === 201) return { ok: true, booking: data as ConfirmedBooking };
  if (status === 400 || status === 404 || status === 409) {
    const body = data as ApiErrorBody;
    return { ok: false, status, errors: body.errors ?? {}, seatsLeft: body.seatsLeft };
  }
  throw new ApiUnavailableError();
}

/** Returns null when the reference is unknown. */
export async function getBooking(reference: string): Promise<ConfirmedBooking | null> {
  const { status, data } = await send("GET", `/api/bookings/${encodeURIComponent(reference)}`);
  if (status === 404) return null;
  if (status !== 200) throw new ApiUnavailableError();
  return data as ConfirmedBooking;
}

export type SignInResult =
  | { ok: true }
  | { ok: false; message: string };

export async function staffSignIn(password: string): Promise<SignInResult> {
  const { status, data } = await send("POST", "/api/staff/session", { password });
  if (status === 204) return { ok: true };
  if (status === 401 || status === 429 || status === 503) {
    return { ok: false, message: (data as ApiErrorBody).error ?? "Sign-in failed." };
  }
  throw new ApiUnavailableError();
}

export async function staffSignOut(): Promise<void> {
  await send("DELETE", "/api/staff/session");
}

/** Returns null when the staff session is missing or expired. */
export async function getStaffBookings(): Promise<StaffTastingGroup[] | null> {
  const { status, data } = await send("GET", "/api/staff/bookings");
  if (status === 401) return null;
  if (status !== 200) throw new ApiUnavailableError();
  return data as StaffTastingGroup[];
}

export type CancelResult = "cancelled" | "not-found" | "signed-out";

export async function cancelBooking(reference: string): Promise<CancelResult> {
  const { status } = await send("DELETE", `/api/staff/bookings/${encodeURIComponent(reference)}`);
  if (status === 204) return "cancelled";
  if (status === 404) return "not-found";
  if (status === 401) return "signed-out";
  throw new ApiUnavailableError();
}
