import { useState } from "react";
import { useNavigate } from "react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { createBooking } from "../api.js";
import { bookingSchema, type BookingField } from "../../shared/booking-schema.js";
import type { PublicTasting } from "../../shared/api-types.js";
import { MAX_GUESTS } from "../../shared/tastings.js";

type FormValues = z.input<typeof bookingSchema>;

export function BookingForm({
  tasting,
  onSeatsLeftChange,
}: {
  tasting: PublicTasting;
  onSeatsLeftChange: (seatsLeft: number) => void;
}) {
  const navigate = useNavigate();
  const [formError, setFormError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { tastingId: tasting.id, name: "", email: "", guests: Number.NaN },
  });

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null);
    const result = await createBooking({
      tastingId: values.tastingId,
      name: values.name,
      email: values.email,
      guests: values.guests,
    }).catch(() => null);

    if (result === null) {
      setFormError("We could not complete your booking. Please try again.");
      return;
    }
    if (result.ok) {
      navigate(`/booking/${result.booking.reference}`);
      return;
    }

    if (result.seatsLeft !== undefined) onSeatsLeftChange(result.seatsLeft);
    let shown = false;
    for (const [field, message] of Object.entries(result.errors)) {
      if (!message) continue;
      if (isFieldName(field)) {
        setError(field, { type: "server", message });
      } else {
        setFormError(message);
      }
      shown = true;
    }
    if (!shown) setFormError("We could not complete your booking. Please try again.");
  });

  const describedBy = (field: BookingField) =>
    errors[field] ? `${field}-error` : undefined;

  const fieldError = (field: BookingField) => {
    const error = errors[field];
    if (!error) return null;
    return (
      <p id={`${field}-error`} className="field-error">
        {error.message}
      </p>
    );
  };

  const inputClass = (field: BookingField) =>
    `input ${errors[field] ? "input-invalid" : ""}`;

  return (
    <form onSubmit={onSubmit} noValidate className="card space-y-6" aria-label="Booking form">
      {formError && (
        <p role="alert" className="alert alert-error">
          {formError}
        </p>
      )}

      <input type="hidden" {...register("tastingId")} />

      <div className="field">
        <label htmlFor="name" className="label">
          Name
        </label>
        <input
          id="name"
          type="text"
          autoComplete="name"
          className={inputClass("name")}
          aria-invalid={errors.name ? "true" : undefined}
          aria-describedby={describedBy("name")}
          {...register("name")}
        />
        {fieldError("name")}
      </div>

      <div className="field">
        <label htmlFor="email" className="label">
          Email
        </label>
        <input
          id="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          className={inputClass("email")}
          aria-invalid={errors.email ? "true" : undefined}
          aria-describedby={describedBy("email")}
          {...register("email")}
        />
        {fieldError("email")}
      </div>

      <div className="field">
        <label htmlFor="guests" className="label">
          Guests
        </label>
        <p id="guests-hint" className="hint">
          Between 1 and {MAX_GUESTS} guests.
        </p>
        <input
          id="guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={MAX_GUESTS}
          step={1}
          className={`${inputClass("guests")} w-32`}
          aria-invalid={errors.guests ? "true" : undefined}
          aria-describedby={["guests-hint", describedBy("guests")].filter(Boolean).join(" ")}
          {...register("guests", { valueAsNumber: true })}
        />
        {fieldError("guests")}
      </div>

      <button type="submit" className="btn btn-primary w-full sm:w-auto" disabled={isSubmitting}>
        Book
      </button>
    </form>
  );
}

function isFieldName(field: string): field is "name" | "email" | "guests" {
  return field === "name" || field === "email" || field === "guests";
}
