import { Link, NavLink, Outlet } from "react-router";

export function SiteLayout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <a href="#main" className="skip-link">
        Skip to content
      </a>

      <header className="border-b border-wine-900/10 bg-cream-50/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <Link to="/" className="group flex flex-col leading-tight">
            <span className="font-display text-2xl text-wine-900 group-hover:text-wine-700">
              Weingut Kieselbrunnen
            </span>
            <span className="text-xs uppercase tracking-[0.25em] text-gold-700">Family winery</span>
          </Link>

          <nav aria-label="Main" className="flex items-center gap-1 text-sm font-medium">
            <NavLink to="/" end className={navClass}>
              Tastings
            </NavLink>
            <NavLink to="/staff" className={navClass}>
              Staff
            </NavLink>
          </nav>
        </div>
      </header>

      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-10 sm:px-6 sm:py-14">
        <Outlet />
      </main>

      <footer className="border-t border-wine-900/10 bg-wine-900 text-cream-100">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-6 text-sm sm:px-6">
          <span className="font-display text-base">Weingut Kieselbrunnen</span>
          <span className="text-cream-100/70">Tastings and cellar visits by reservation</span>
        </div>
      </footer>
    </div>
  );
}

function navClass({ isActive }: { isActive: boolean }) {
  return `rounded-full px-4 py-2 transition ${
    isActive ? "bg-wine-900 text-cream-50" : "text-wine-800 hover:bg-wine-900/5"
  }`;
}
