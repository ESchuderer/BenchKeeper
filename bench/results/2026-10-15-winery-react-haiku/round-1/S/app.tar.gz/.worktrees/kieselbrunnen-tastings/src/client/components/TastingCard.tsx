import { Link } from "react-router";
import type { PublicTasting } from "../../shared/api-types.js";
import { formatDate, formatSeatsLeft, formatTime, formatPrice } from "../../shared/format.js";

export function TastingCard({ tasting }: { tasting: PublicTasting }) {
  const titleId = `tasting-${tasting.id}-title`;
  const fullyBooked = tasting.seatsLeft === 0;

  return (
    <article
      aria-labelledby={titleId}
      className={`card flex h-full flex-col ${fullyBooked ? "card-muted" : ""}`}
    >
      <div className="flex items-start justify-between gap-4">
        <h2 id={titleId} className="font-display text-2xl text-wine-900">
          {tasting.title}
        </h2>
        {fullyBooked && <span className="badge">Fully booked</span>}
      </div>

      <dl className="mt-4 space-y-2 text-wine-800">
        <div>
          <dt className="sr-only">Date and time</dt>
          <dd>
            <time dateTime={`${tasting.date}T${tasting.time}`}>
              {formatDate(tasting.date)}, {formatTime(tasting.time)}
            </time>
          </dd>
        </div>
        <div className="flex items-baseline gap-2">
          <dt className="sr-only">Price per guest</dt>
          <dd className="font-semibold text-wine-900">{formatPrice(tasting.pricePerGuest)}</dd>
          <dd className="text-sm text-wine-800/70">per guest</dd>
        </div>
        <div>
          <dt className="sr-only">Seats</dt>
          <dd className={fullyBooked ? "text-wine-800/60" : "text-wine-800"}>
            {formatSeatsLeft(tasting.seatsLeft)}
          </dd>
        </div>
      </dl>

      <div className="mt-auto pt-6">
        {fullyBooked ? (
          <p className="text-sm text-wine-800/70">This tasting is sold out.</p>
        ) : (
          <Link to={`/book/${tasting.id}`} className="btn btn-primary w-full">
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
