// @vitest-environment jsdom
import { describe, it, expect, beforeEach } from "vitest";
import { screen, waitFor } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { BookingPage } from "./BookingPage.js";
import { ConfirmationPage } from "./ConfirmationPage.js";
import { jsonResponse, mockFetch, renderAt } from "../test-helpers.js";

const riesling = {
  id: "riesling-evening",
  title: "Riesling Evening",
  date: "2026-11-06",
  time: "18:00",
  pricePerGuest: 25,
  seats: 12,
  seatsLeft: 12,
};

const winter = { ...riesling, id: "winter-tasting", title: "Winter Tasting", seatsLeft: 0 };

function renderBooking(path = "/book/riesling-evening") {
  return renderAt(path, [
    { path: "/book/:tastingId", element: <BookingPage /> },
    { path: "/booking/:reference", element: <ConfirmationPage /> },
  ]);
}

function fetchRouter(options: { bookingResponse?: () => Response } = {}) {
  return mockFetch((url, init) => {
    if (url === "/api/tastings") return jsonResponse(200, [riesling, winter]);
    if (url === "/api/bookings" && init?.method === "POST") {
      return options.bookingResponse
        ? options.bookingResponse()
        : jsonResponse(201, {
            reference: "KB-ABC234",
            tastingId: "riesling-evening",
            tastingTitle: "Riesling Evening",
            guests: 2,
            totalPrice: 50,
          });
    }
    if (url === "/api/bookings/KB-ABC234") {
      return jsonResponse(200, {
        reference: "KB-ABC234",
        tastingId: "riesling-evening",
        tastingTitle: "Riesling Evening",
        guests: 2,
        totalPrice: 50,
      });
    }
    return jsonResponse(404, { error: "not mocked" });
  });
}

describe("BookingPage", () => {
  let user: ReturnType<typeof userEvent.setup>;
  beforeEach(() => {
    user = userEvent.setup();
  });

  it("shows the tasting with its seats left and a booking form", async () => {
    fetchRouter();
    renderBooking();

    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByText("12 seats left")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("shows each field error next to the field it concerns and sends nothing", async () => {
    const mock = fetchRouter();
    renderBooking();
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Please enter your name.")).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toHaveAccessibleDescription("Please enter your name.");
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription(
      "Please enter your email address.",
    );
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription(
      "Between 1 and 8 guests. Please enter the number of guests.",
    );
    expect(screen.getByLabelText("Name")).toHaveAttribute("aria-invalid", "true");
    expect(mock.mock.calls.some(([url]) => url === "/api/bookings")).toBe(false);
  });

  it("rejects a guest count above 8 next to the Guests field", async () => {
    fetchRouter();
    renderBooking();
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await user.type(screen.getByLabelText("Name"), "Ada Guest");
    await user.type(screen.getByLabelText("Email"), "ada@example.com");
    await user.type(screen.getByLabelText("Guests"), "9");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByText("Choose between 1 and 8 guests.")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription(
      "Between 1 and 8 guests. Choose between 1 and 8 guests.",
    );
  });

  it("books the tasting and shows the confirmation", async () => {
    const mock = fetchRouter();
    renderBooking();
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await user.type(screen.getByLabelText("Name"), "Ada Guest");
    await user.type(screen.getByLabelText("Email"), "ada@example.com");
    await user.type(screen.getByLabelText("Guests"), "2");
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    const post = mock.mock.calls.find(([url]) => url === "/api/bookings");
    expect(JSON.parse(String(post?.[1]?.body))).toEqual({
      tastingId: "riesling-evening",
      name: "Ada Guest",
      email: "ada@example.com",
      guests: 2,
    });
  });

  it("shows the server's seat limit next to the Guests field and keeps the form", async () => {
    fetchRouter({
      bookingResponse: () =>
        jsonResponse(409, { errors: { guests: "Only 3 seats left." }, seatsLeft: 3 }),
    });
    renderBooking();
    await screen.findByRole("heading", { name: "Riesling Evening" });

    await user.type(screen.getByLabelText("Name"), "Ada Guest");
    await user.type(screen.getByLabelText("Email"), "ada@example.com");
    await user.type(screen.getByLabelText("Guests"), "5");
    await user.click(screen.getByRole("button", { name: "Book" }));

    await waitFor(() =>
      expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription("Between 1 and 8 guests. Only 3 seats left."),
    );
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("does not offer the form for a fully booked tasting", async () => {
    fetchRouter();
    renderBooking("/book/winter-tasting");

    expect(await screen.findByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();
    expect(screen.getByText("This tasting is fully booked.")).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).toBeNull();
  });

  it("explains when the tasting does not exist", async () => {
    fetchRouter();
    renderBooking("/book/unknown-tasting");

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "We could not find that tasting.",
    );
    expect(screen.queryByLabelText("Name")).toBeNull();
  });
});
