import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import { getTastings } from "../api.js";
import type { PublicTasting } from "../../shared/api-types.js";
import { formatDate, formatPrice, formatSeatsLeft, formatTime } from "../../shared/format.js";
import { BookingForm } from "../components/BookingForm.js";

type State =
  | { status: "loading" }
  | { status: "error" }
  | { status: "not-found" }
  | { status: "ready"; tasting: PublicTasting };

export function BookingPage() {
  const { tastingId = "" } = useParams();
  const [state, setState] = useState<State>({ status: "loading" });

  useEffect(() => {
    let active = true;
    getTastings()
      .then((tastings) => {
        if (!active) return;
        const tasting = tastings.find((t) => t.id === tastingId);
        setState(tasting ? { status: "ready", tasting } : { status: "not-found" });
      })
      .catch(() => active && setState({ status: "error" }));
    return () => {
      active = false;
    };
  }, [tastingId]);

  if (state.status === "loading") {
    return (
      <p role="status" className="text-center text-wine-800/70">
        Loading…
      </p>
    );
  }

  if (state.status === "error") {
    return (
      <div className="space-y-4">
        <p role="alert" className="alert alert-error">
          We could not load this tasting. Please try again later.
        </p>
        <BackLink />
      </div>
    );
  }

  if (state.status === "not-found") {
    return (
      <div className="space-y-4">
        <p role="alert" className="alert alert-error">
          We could not find that tasting.
        </p>
        <BackLink />
      </div>
    );
  }

  const { tasting } = state;
  const fullyBooked = tasting.seatsLeft === 0;

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
      <section aria-labelledby="booking-heading" className="space-y-5">
        <BackLink />
        <div className="space-y-2">
          <p className="text-sm uppercase tracking-[0.2em] text-gold-700">Reserve your seats</p>
          <h1 id="booking-heading" className="font-display text-4xl text-wine-900">
            {tasting.title}
          </h1>
        </div>
        <dl className="space-y-2 text-wine-800">
          <div>
            <dt className="sr-only">Date and time</dt>
            <dd>
              <time dateTime={`${tasting.date}T${tasting.time}`}>
                {formatDate(tasting.date)}, {formatTime(tasting.time)}
              </time>
            </dd>
          </div>
          <div className="flex items-baseline gap-2">
            <dt className="sr-only">Price per guest</dt>
            <dd className="font-semibold text-wine-900">{formatPrice(tasting.pricePerGuest)}</dd>
            <dd className="text-sm text-wine-800/70">per guest</dd>
          </div>
          <div>
            <dt className="sr-only">Seats</dt>
            <dd className="font-semibold text-wine-900">{formatSeatsLeft(tasting.seatsLeft)}</dd>
          </div>
        </dl>
      </section>

      <section aria-label="Your booking">
        {fullyBooked ? (
          <div className="card card-muted space-y-3">
            <p className="font-display text-2xl text-wine-900">This tasting is fully booked.</p>
            <p className="text-wine-800/80">
              Every seat is taken. Please choose another tasting.
            </p>
          </div>
        ) : (
          <BookingForm
            tasting={tasting}
            onSeatsLeftChange={(seatsLeft) =>
              setState((current) =>
                current.status === "ready"
                  ? { status: "ready", tasting: { ...current.tasting, seatsLeft } }
                  : current,
              )
            }
          />
        )}
      </section>
    </div>
  );
}

function BackLink() {
  return (
    <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-wine-700 hover:text-wine-900">
      <span aria-hidden="true">←</span> All tastings
    </Link>
  );
}
