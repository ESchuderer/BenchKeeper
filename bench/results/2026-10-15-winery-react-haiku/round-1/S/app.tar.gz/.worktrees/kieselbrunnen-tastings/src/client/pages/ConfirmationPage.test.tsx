// @vitest-environment jsdom
import { describe, it, expect } from "vitest";
import { screen, within } from "@testing-library/react";
import { ConfirmationPage } from "./ConfirmationPage.js";
import { jsonResponse, mockFetch, renderAt } from "../test-helpers.js";

function renderConfirmation(path: string) {
  return renderAt(path, [{ path: "/booking/:reference", element: <ConfirmationPage /> }]);
}

describe("ConfirmationPage", () => {
  it("shows the booking confirmation with tasting, guests, total and reference", async () => {
    mockFetch((url) => {
      expect(url).toBe("/api/bookings/KB-ABC234");
      return jsonResponse(200, {
        reference: "KB-ABC234",
        tastingId: "riesling-evening",
        tastingTitle: "Riesling Evening",
        guests: 2,
        totalPrice: 50,
      });
    });
    renderConfirmation("/booking/KB-ABC234");

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    const summary = screen.getByRole("list", { name: "Booking summary" });
    expect(within(summary).getByText("Riesling Evening")).toBeInTheDocument();
    expect(within(summary).getByText("2")).toBeInTheDocument();
    expect(within(summary).getByText("EUR 50")).toBeInTheDocument();
    expect(within(summary).getByText("KB-ABC234")).toBeInTheDocument();
  });

  it("explains when the reference is unknown", async () => {
    mockFetch(() => jsonResponse(404, { error: "Booking not found." }));
    renderConfirmation("/booking/KB-NOPE00");

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "We could not find a booking with this reference.",
    );
    expect(screen.queryByRole("heading", { name: "Booking confirmed" })).toBeNull();
  });
});
