import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import { getBooking } from "../api.js";
import type { ConfirmedBooking } from "../../shared/api-types.js";
import { formatPrice } from "../../shared/format.js";

type State =
  | { status: "loading" }
  | { status: "error" }
  | { status: "not-found" }
  | { status: "ready"; booking: ConfirmedBooking };

export function ConfirmationPage() {
  const { reference = "" } = useParams();
  const [state, setState] = useState<State>({ status: "loading" });

  useEffect(() => {
    let active = true;
    getBooking(reference)
      .then((booking) => {
        if (!active) return;
        setState(booking ? { status: "ready", booking } : { status: "not-found" });
      })
      .catch(() => active && setState({ status: "error" }));
    return () => {
      active = false;
    };
  }, [reference]);

  if (state.status === "loading") {
    return (
      <p role="status" className="text-center text-wine-800/70">
        Loading your booking…
      </p>
    );
  }

  if (state.status === "error") {
    return (
      <p role="alert" className="alert alert-error">
        We could not load this booking. Please try again later.
      </p>
    );
  }

  if (state.status === "not-found") {
    return (
      <div className="space-y-4">
        <p role="alert" className="alert alert-error">
          We could not find a booking with this reference.
        </p>
        <Link to="/" className="btn btn-secondary">
          Back to the tastings
        </Link>
      </div>
    );
  }

  const { booking } = state;
  return (
    <section aria-labelledby="confirmation-heading" className="mx-auto max-w-xl space-y-6">
      <div className="card space-y-6 text-center">
        <p className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-wine-700 text-2xl text-cream-50" aria-hidden="true">
          ✓
        </p>
        <h1 id="confirmation-heading" className="font-display text-4xl text-wine-900">
          Booking confirmed
        </h1>
        <p className="text-wine-800/80">
          Thank you. We look forward to welcoming you to Weingut Kieselbrunnen.
        </p>

        <ul aria-label="Booking summary" className="divide-y divide-wine-900/10 text-left">
          <SummaryRow label="Tasting" value={booking.tastingTitle} />
          <SummaryRow label="Guests" value={String(booking.guests)} />
          <SummaryRow label="Total price" value={formatPrice(booking.totalPrice)} />
          <SummaryRow label="Booking reference" value={booking.reference} mono />
        </ul>
      </div>
      <p className="text-center">
        <Link to="/" className="text-sm font-medium text-wine-700 hover:text-wine-900">
          Back to the tastings
        </Link>
      </p>
    </section>
  );
}

function SummaryRow({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return (
    <li className="flex items-baseline justify-between gap-4 py-3">
      <span className="text-sm text-wine-800/70">{label}</span>
      <span className={`font-semibold text-wine-900 ${mono ? "font-mono tracking-wider" : ""}`}>{value}</span>
    </li>
  );
}
