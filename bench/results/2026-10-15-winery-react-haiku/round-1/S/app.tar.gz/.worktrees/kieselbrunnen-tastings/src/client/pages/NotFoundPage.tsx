import { Link } from "react-router";

export function NotFoundPage() {
  return (
    <section className="mx-auto max-w-md space-y-6 text-center">
      <h1 className="font-display text-4xl text-wine-900">Page not found</h1>
      <p className="text-wine-800/80">The page you are looking for does not exist.</p>
      <Link to="/" className="btn btn-secondary">
        Back to the tastings
      </Link>
    </section>
  );
}
