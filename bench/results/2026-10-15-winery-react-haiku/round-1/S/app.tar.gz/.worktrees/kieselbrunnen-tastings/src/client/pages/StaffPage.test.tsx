// @vitest-environment jsdom
import { describe, it, expect, beforeEach } from "vitest";
import { screen, within, waitFor } from "@testing-library/react";
import { userEvent } from "@testing-library/user-event";
import { StaffPage } from "./StaffPage.js";
import { jsonResponse, mockFetch, renderAt } from "../test-helpers.js";

const groups = [
  {
    tasting: {
      id: "riesling-evening",
      title: "Riesling Evening",
      date: "2026-11-06",
      time: "18:00",
      pricePerGuest: 25,
      seats: 12,
      seatsLeft: 10,
    },
    bookings: [
      { reference: "KB-ABC234", name: "Ada Guest", email: "ada@example.com", guests: 2 },
    ],
  },
  {
    tasting: {
      id: "winter-tasting",
      title: "Winter Tasting",
      date: "2026-12-05",
      time: "17:00",
      pricePerGuest: 28,
      seats: 10,
      seatsLeft: 10,
    },
    bookings: [],
  },
];

function renderStaff() {
  return renderAt("/staff", [{ path: "/staff", element: <StaffPage /> }]);
}

describe("StaffPage", () => {
  let user: ReturnType<typeof userEvent.setup>;
  beforeEach(() => {
    user = userEvent.setup();
  });

  it("asks for the password when nobody is signed in", async () => {
    mockFetch((url) => (url === "/api/staff/bookings" ? jsonResponse(401, { error: "x" }) : jsonResponse(500)));
    renderStaff();

    expect(await screen.findByLabelText("Password")).toHaveAttribute("type", "password");
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
  });

  it("shows an error for a wrong password and stays on the sign-in form", async () => {
    mockFetch((url, init) => {
      if (url === "/api/staff/bookings") return jsonResponse(401, { error: "x" });
      if (url === "/api/staff/session" && init?.method === "POST") {
        return jsonResponse(401, { error: "Incorrect password." });
      }
      return jsonResponse(500);
    });
    renderStaff();

    await user.type(await screen.findByLabelText("Password"), "wrong");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("Incorrect password.");
    expect(screen.getByLabelText("Password")).toBeInTheDocument();
  });

  it("explains when staff sign-in is not configured on the server", async () => {
    mockFetch((url, init) => {
      if (url === "/api/staff/bookings") return jsonResponse(401, { error: "x" });
      if (init?.method === "POST") return jsonResponse(503, { error: "Staff sign-in is not configured." });
      return jsonResponse(500);
    });
    renderStaff();

    await user.type(await screen.findByLabelText("Password"), "anything");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Staff sign-in is not configured.",
    );
  });

  it("shows the bookings grouped by tasting after signing in", async () => {
    let signedIn = false;
    mockFetch((url, init) => {
      if (url === "/api/staff/session" && init?.method === "POST") {
        signedIn = true;
        return new Response(null, { status: 204 });
      }
      if (url === "/api/staff/bookings") {
        return signedIn ? jsonResponse(200, groups) : jsonResponse(401, { error: "x" });
      }
      return jsonResponse(500);
    });
    renderStaff();

    await user.type(await screen.findByLabelText("Password"), "cellar-door-2026");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    const row = within(riesling).getByRole("row", { name: /Ada Guest/ });
    expect(within(row).getByText("ada@example.com")).toBeInTheDocument();
    expect(within(row).getByText("2")).toBeInTheDocument();
    expect(within(row).getByText("KB-ABC234")).toBeInTheDocument();
    expect(within(row).getByRole("button", { name: "Cancel" })).toBeInTheDocument();

    const winter = screen.getByRole("region", { name: "Winter Tasting" });
    expect(within(winter).getByText("No bookings yet.")).toBeInTheDocument();
  });

  it("shows bookings straight away when a staff session already exists", async () => {
    mockFetch((url) => (url === "/api/staff/bookings" ? jsonResponse(200, groups) : jsonResponse(500)));
    renderStaff();

    expect(await screen.findByRole("region", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.queryByLabelText("Password")).toBeNull();
  });

  it("cancels a booking and removes it from the list", async () => {
    let cancelled = false;
    const mock = mockFetch((url, init) => {
      if (url === "/api/staff/bookings") {
        return jsonResponse(200, cancelled ? [{ ...groups[0], bookings: [] }, groups[1]] : groups);
      }
      if (url === "/api/staff/bookings/KB-ABC234" && init?.method === "DELETE") {
        cancelled = true;
        return new Response(null, { status: 204 });
      }
      return jsonResponse(500);
    });
    renderStaff();

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    await user.click(within(riesling).getByRole("button", { name: "Cancel" }));

    await waitFor(() =>
      expect(within(riesling).queryByText("Ada Guest")).toBeNull(),
    );
    expect(within(riesling).getByText("No bookings yet.")).toBeInTheDocument();
    expect(mock.mock.calls.some(([url, init]) => url === "/api/staff/bookings/KB-ABC234" && init?.method === "DELETE")).toBe(true);
  });

  it("explains when the bookings cannot be loaded, without showing the sign-in form", async () => {
    mockFetch(() => jsonResponse(500, { error: "boom" }));
    renderStaff();

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "We could not load the bookings. Please try again later.",
    );
    expect(screen.queryByLabelText("Password")).toBeNull();
  });

  it("explains a rate-limited sign-in attempt", async () => {
    mockFetch((url, init) => {
      if (url === "/api/staff/bookings") return jsonResponse(401, { error: "x" });
      if (init?.method === "POST") {
        return jsonResponse(429, { error: "Too many sign-in attempts. Try again later." });
      }
      return jsonResponse(500);
    });
    renderStaff();

    await user.type(await screen.findByLabelText("Password"), "wrong");
    await user.click(screen.getByRole("button", { name: "Sign in" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Too many sign-in attempts. Try again later.",
    );
  });

  it("asks for the password again when the session ends during a cancellation", async () => {
    let signedIn = true;
    mockFetch((url, init) => {
      if (url === "/api/staff/bookings") {
        return signedIn ? jsonResponse(200, groups) : jsonResponse(401, { error: "x" });
      }
      if (url === "/api/staff/bookings/KB-ABC234" && init?.method === "DELETE") {
        signedIn = false;
        return jsonResponse(401, { error: "Staff sign-in required." });
      }
      return jsonResponse(500);
    });
    renderStaff();

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    await user.click(within(riesling).getByRole("button", { name: "Cancel" }));

    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.getByRole("alert")).toHaveTextContent("Your session has ended. Please sign in again.");
  });

  it("names the booking reference each Cancel button refers to", async () => {
    mockFetch(() => jsonResponse(200, groups));
    renderStaff();

    const riesling = await screen.findByRole("region", { name: "Riesling Evening" });
    expect(within(riesling).getByRole("button", { name: "Cancel" })).toHaveAccessibleDescription(
      "KB-ABC234",
    );
  });

  it("signs out and returns to the password form", async () => {
    let signedIn = true;
    mockFetch((url, init) => {
      if (url === "/api/staff/bookings") {
        return signedIn ? jsonResponse(200, groups) : jsonResponse(401, { error: "x" });
      }
      if (url === "/api/staff/session" && init?.method === "DELETE") {
        signedIn = false;
        return new Response(null, { status: 204 });
      }
      return jsonResponse(500);
    });
    renderStaff();

    await user.click(await screen.findByRole("button", { name: "Sign out" }));
    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
  });
});
