import { useEffect, useState, type FormEvent } from "react";
import {
  ApiUnavailableError,
  cancelBooking,
  getStaffBookings,
  staffSignIn,
  staffSignOut,
} from "../api.js";
import type { StaffTastingGroup } from "../../shared/api-types.js";
import { formatDate, formatPrice, formatSeatsLeft, formatTime } from "../../shared/format.js";

type State =
  | { status: "checking" }
  | { status: "signed-out" }
  | { status: "signed-in"; groups: StaffTastingGroup[] }
  | { status: "error" };

const SESSION_ENDED = "Your session has ended. Please sign in again.";

/** Loads the bookings for the current staff session. */
async function loadBookings(): Promise<State> {
  try {
    const groups = await getStaffBookings();
    return groups ? { status: "signed-in", groups } : { status: "signed-out" };
  } catch {
    return { status: "error" };
  }
}

export function StaffPage() {
  const [state, setState] = useState<State>({ status: "checking" });
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    loadBookings().then((next) => active && setState(next));
    return () => {
      active = false;
    };
  }, []);

  const reload = async () => {
    setState({ status: "checking" });
    setState(await loadBookings());
  };

  if (state.status === "checking") {
    return (
      <p role="status" className="text-center text-wine-800/70">
        Loading…
      </p>
    );
  }

  if (state.status === "signed-out") {
    return (
      <SignInForm
        message={message}
        onSignedIn={async () => {
          setMessage(null);
          setState(await loadBookings());
        }}
        onMessage={setMessage}
      />
    );
  }

  if (state.status === "error") {
    return (
      <div className="mx-auto max-w-md space-y-4 text-center">
        <p role="alert" className="alert alert-error">
          We could not load the bookings. Please try again later.
        </p>
        <button type="button" className="btn btn-secondary" onClick={reload}>
          Try again
        </button>
      </div>
    );
  }

  const endSession = () => {
    setMessage(SESSION_ENDED);
    setState({ status: "signed-out" });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="space-y-2">
          <p className="text-sm uppercase tracking-[0.2em] text-gold-700">Cellar staff</p>
          <h1 className="font-display text-4xl text-wine-900">Bookings</h1>
        </div>
        <button
          type="button"
          className="btn btn-secondary"
          onClick={async () => {
            await staffSignOut().catch(() => undefined);
            setMessage(null);
            setState({ status: "signed-out" });
          }}
        >
          Sign out
        </button>
      </div>

      {message && (
        <p role="alert" className="alert alert-error">
          {message}
        </p>
      )}

      {state.groups.map((group) => (
        <TastingGroup
          key={group.tasting.id}
          group={group}
          onCancel={async (reference) => {
            setMessage(null);
            let result: Awaited<ReturnType<typeof cancelBooking>>;
            try {
              result = await cancelBooking(reference);
            } catch {
              setMessage("We could not cancel the booking. Please try again.");
              return;
            }
            if (result === "signed-out") {
              endSession();
              return;
            }
            if (result === "not-found") setMessage("This booking no longer exists.");
            setState(await loadBookings());
          }}
        />
      ))}
    </div>
  );
}

function SignInForm({
  message,
  onSignedIn,
  onMessage,
}: {
  message: string | null;
  onSignedIn: () => Promise<void>;
  onMessage: (message: string | null) => void;
}) {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    onMessage(null);
    try {
      const result = await staffSignIn(password);
      if (result.ok) {
        setPassword("");
        await onSignedIn();
      } else {
        onMessage(result.message);
      }
    } catch (error) {
      onMessage(
        error instanceof ApiUnavailableError
          ? "We could not reach the server. Please try again."
          : "Sign-in failed. Please try again.",
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <section aria-labelledby="staff-heading" className="mx-auto max-w-md space-y-6">
      <div className="space-y-2 text-center">
        <p className="text-sm uppercase tracking-[0.2em] text-gold-700">Cellar staff</p>
        <h1 id="staff-heading" className="font-display text-4xl text-wine-900">
          Sign in
        </h1>
        <p className="text-wine-800/80">Enter the staff password to see today&apos;s bookings.</p>
      </div>

      <form onSubmit={submit} noValidate className="card space-y-6">
        {message && (
          <p role="alert" className="alert alert-error">
            {message}
          </p>
        )}
        <div className="field">
          <label htmlFor="staff-password" className="label">
            Password
          </label>
          <input
            id="staff-password"
            type="password"
            autoComplete="current-password"
            className="input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary w-full" disabled={busy}>
          Sign in
        </button>
      </form>
    </section>
  );
}

function TastingGroup({
  group,
  onCancel,
}: {
  group: StaffTastingGroup;
  onCancel: (reference: string) => void;
}) {
  const { tasting, bookings } = group;
  const headingId = `group-${tasting.id}`;
  const guests = bookings.reduce((sum, b) => sum + b.guests, 0);

  return (
    <section aria-labelledby={headingId} className="card space-y-4 p-0">
      <header className="flex flex-wrap items-baseline justify-between gap-2 border-b border-wine-900/10 px-6 py-4">
        <div>
          <h2 id={headingId} className="font-display text-2xl text-wine-900">
            {tasting.title}
          </h2>
          <p className="text-sm text-wine-800/80">
            {formatDate(tasting.date)}, {formatTime(tasting.time)} · {formatPrice(tasting.pricePerGuest)} per guest
          </p>
        </div>
        <p className="text-sm text-wine-800/80">
          {guests} guests booked · {formatSeatsLeft(tasting.seatsLeft)}
        </p>
      </header>

      {bookings.length === 0 ? (
        <p className="px-6 pb-6 text-wine-800/70">No bookings yet.</p>
      ) : (
        <div className="overflow-x-auto px-2 pb-4 sm:px-4">
          <table className="w-full min-w-[36rem] border-collapse text-left text-sm">
            <thead>
              <tr className="text-wine-800/70">
                <th scope="col" className="px-4 py-2 font-medium">Name</th>
                <th scope="col" className="px-4 py-2 font-medium">Email</th>
                <th scope="col" className="px-4 py-2 font-medium">Guests</th>
                <th scope="col" className="px-4 py-2 font-medium">Reference</th>
                <th scope="col" className="px-4 py-2 font-medium">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => {
                const referenceId = `ref-${booking.reference}`;
                return (
                  <tr key={booking.reference} className="border-t border-wine-900/10">
                    <td className="px-4 py-3 font-medium text-wine-900">{booking.name}</td>
                    <td className="px-4 py-3 text-wine-800">{booking.email}</td>
                    <td className="px-4 py-3 text-wine-800">{booking.guests}</td>
                    <td id={referenceId} className="px-4 py-3 font-mono text-wine-800">
                      {booking.reference}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        className="btn btn-danger"
                        aria-describedby={referenceId}
                        onClick={() => onCancel(booking.reference)}
                      >
                        Cancel
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
