// @vitest-environment jsdom
import { describe, it, expect } from "vitest";
import { screen, within, waitFor } from "@testing-library/react";
import { TastingsPage } from "./TastingsPage.js";
import { jsonResponse, mockFetch, renderAt } from "../test-helpers.js";

const tastings = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    date: "2026-11-06",
    time: "18:00",
    pricePerGuest: 25,
    seats: 12,
    seatsLeft: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    date: "2026-11-14",
    time: "15:00",
    pricePerGuest: 32,
    seats: 8,
    seatsLeft: 0,
  },
];

function renderPage() {
  return renderAt("/", [{ path: "/", element: <TastingsPage /> }]);
}

describe("TastingsPage", () => {
  it("lists each tasting with its date, time, price per guest and seats left", async () => {
    mockFetch((url) => {
      expect(url).toBe("/api/tastings");
      return jsonResponse(200, tastings);
    });
    renderPage();

    const card = await screen.findByRole("article", { name: "Riesling Evening" });
    expect(within(card).getByText(/Friday, 6 November 2026/)).toBeInTheDocument();
    expect(within(card).getByText(/18:00/)).toBeInTheDocument();
    expect(within(card).getByText("EUR 25")).toBeInTheDocument();
    expect(within(card).getByText("12 seats left")).toBeInTheDocument();
  });

  it("offers a booking link named after each tasting that has seats", async () => {
    mockFetch(() => jsonResponse(200, tastings));
    renderPage();

    const link = await screen.findByRole("link", { name: "Book Riesling Evening" });
    expect(link).toHaveAttribute("href", "/book/riesling-evening");
  });

  it("marks a fully booked tasting and gives no booking link for it", async () => {
    mockFetch(() => jsonResponse(200, tastings));
    renderPage();

    const card = await screen.findByRole("article", { name: "Red Wine Cellar Tour" });
    expect(within(card).getByText("Fully booked")).toBeInTheDocument();
    expect(within(card).getByText("0 seats left")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Red Wine Cellar Tour" })).toBeNull();
  });

  it("explains when the tastings cannot be loaded", async () => {
    mockFetch(() => jsonResponse(500, { error: "boom" }));
    renderPage();

    await waitFor(() =>
      expect(screen.getByRole("alert")).toHaveTextContent(
        "We could not load the tastings. Please try again later.",
      ),
    );
  });
});
