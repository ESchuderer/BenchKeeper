import { useEffect, useState } from "react";
import { getTastings } from "../api.js";
import type { PublicTasting } from "../../shared/api-types.js";
import { TastingCard } from "../components/TastingCard.js";

type State =
  | { status: "loading" }
  | { status: "error" }
  | { status: "ready"; tastings: PublicTasting[] };

export function TastingsPage() {
  const [state, setState] = useState<State>({ status: "loading" });

  useEffect(() => {
    let active = true;
    getTastings()
      .then((tastings) => active && setState({ status: "ready", tastings }))
      .catch(() => active && setState({ status: "error" }));
    return () => {
      active = false;
    };
  }, []);

  return (
    <section aria-labelledby="tastings-heading" className="space-y-8">
      <div className="space-y-3 text-center">
        <p className="text-sm uppercase tracking-[0.2em] text-gold-700">Tastings &amp; visits</p>
        <h1 id="tastings-heading" className="font-display text-4xl text-wine-900 sm:text-5xl">
          Book a tasting
        </h1>
        <p className="mx-auto max-w-xl text-wine-800/80">
          Join us in the cellar for an evening or an afternoon with our wines. Choose a tasting
          below and reserve your seats.
        </p>
      </div>

      {state.status === "loading" && (
        <p role="status" className="text-center text-wine-800/70">
          Loading tastings…
        </p>
      )}

      {state.status === "error" && (
        <p role="alert" className="alert alert-error">
          We could not load the tastings. Please try again later.
        </p>
      )}

      {state.status === "ready" && (
        <ul className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {state.tastings.map((tasting) => (
            <li key={tasting.id}>
              <TastingCard tasting={tasting} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
