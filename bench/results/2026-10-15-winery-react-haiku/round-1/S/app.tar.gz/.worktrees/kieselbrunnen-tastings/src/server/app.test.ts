import { describe, it, expect, beforeEach, afterEach } from "vitest";
import request from "supertest";
import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "./app.js";
import { BookingStore } from "./booking-store.js";
import { StaffSessions } from "./staff-auth.js";
import type { Tasting } from "../shared/tastings.js";

const CATALOGUE: Tasting[] = [
  { id: "riesling-evening", title: "Riesling Evening", date: "2026-11-06", time: "18:00", pricePerGuest: 25, seats: 12 },
  { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00", pricePerGuest: 28, seats: 3 },
];

const PASSWORD = "cellar-door-2026";

function setup(options: { staffPassword?: string | undefined; clientDir?: string } = {}) {
  const store = new BookingStore(CATALOGUE);
  const sessions = new StaffSessions({ ttlMs: 60_000 });
  const app = createApp({
    store,
    sessions,
    staffPassword: "staffPassword" in options ? options.staffPassword : PASSWORD,
    clientDir: options.clientDir,
  });
  return { app, store };
}

const booking = {
  tastingId: "riesling-evening",
  name: "Ada Guest",
  email: "ada@example.com",
  guests: 2,
};

async function signIn(app: ReturnType<typeof createApp>): Promise<string> {
  const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });
  expect(res.status).toBe(204);
  const cookie = res.headers["set-cookie"]?.[0];
  if (!cookie) throw new Error("no session cookie");
  return cookie.split(";")[0];
}

describe("GET /api/tastings", () => {
  it("lists every tasting with its seats left", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/tastings");

    expect(res.status).toBe(200);
    expect(res.body).toEqual([
      { id: "riesling-evening", title: "Riesling Evening", date: "2026-11-06", time: "18:00", pricePerGuest: 25, seats: 12, seatsLeft: 12 },
      { id: "winter-tasting", title: "Winter Tasting", date: "2026-12-05", time: "17:00", pricePerGuest: 28, seats: 3, seatsLeft: 3 },
    ]);
  });
});

describe("POST /api/bookings", () => {
  it("creates a booking and returns the confirmation details with the total price", async () => {
    const { app, store } = setup();
    const res = await request(app).post("/api/bookings").send(booking);

    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(/^KB-[A-Z2-9]{6}$/),
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      guests: 2,
      totalPrice: 50,
    });
    expect(store.seatsLeft("riesling-evening")).toBe(10);
  });

  it("returns field errors and books nothing for invalid input", async () => {
    const { app, store } = setup();
    const res = await request(app)
      .post("/api/bookings")
      .send({ ...booking, email: "not-an-email", guests: 9 });

    expect(res.status).toBe(400);
    expect(res.body.errors).toEqual({
      email: "Please enter a valid email address.",
      guests: "Choose between 1 and 8 guests.",
    });
    expect(store.seatsLeft("riesling-evening")).toBe(12);
  });

  it("rejects more guests than seats left with a guests error and books nothing", async () => {
    const { app, store } = setup();
    const res = await request(app)
      .post("/api/bookings")
      .send({ ...booking, tastingId: "winter-tasting", guests: 4 });

    expect(res.status).toBe(409);
    expect(res.body.errors).toEqual({ guests: "Only 3 seats left." });
    expect(store.seatsLeft("winter-tasting")).toBe(3);
  });

  it("says a fully booked tasting has no seats left", async () => {
    const { app, store } = setup();
    store.createBooking({ tastingId: "winter-tasting", guests: 3, name: "X", email: "x@example.com" });

    const res = await request(app)
      .post("/api/bookings")
      .send({ ...booking, tastingId: "winter-tasting", guests: 1 });

    expect(res.status).toBe(409);
    expect(res.body.errors).toEqual({ guests: "This tasting is fully booked." });
  });

  it("returns 404 for an unknown tasting", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/bookings").send({ ...booking, tastingId: "nope" });

    expect(res.status).toBe(404);
    expect(res.body.errors).toEqual({ tastingId: "This tasting does not exist." });
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the public confirmation details without the guest's contact details", async () => {
    const { app } = setup();
    const created = await request(app).post("/api/bookings").send(booking);

    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual(created.body);
    expect(JSON.stringify(res.body)).not.toContain("ada@example.com");
  });

  it("returns 404 for an unknown reference", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/bookings/KB-NOPE00");
    expect(res.status).toBe(404);
  });
});

describe("staff sign-in", () => {
  it("rejects a wrong password with 401", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/staff/session").send({ password: "wrong" });
    expect(res.status).toBe(401);
    expect(res.body.error).toBe("Incorrect password.");
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("reports 503 when STAFF_PASSWORD is not configured", async () => {
    const { app } = setup({ staffPassword: undefined });
    const res = await request(app).post("/api/staff/session").send({ password: "anything" });
    expect(res.status).toBe(503);
    expect(res.body.error).toBe("Staff sign-in is not configured.");
  });

  it("sets an httpOnly session cookie on success", async () => {
    const { app } = setup();
    const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });
    expect(res.status).toBe(204);
    const cookie = res.headers["set-cookie"]?.[0] ?? "";
    expect(cookie).toMatch(/^staff_session=/);
    expect(cookie.toLowerCase()).toContain("httponly");
    expect(cookie.toLowerCase()).toContain("samesite=strict");
  });
});

describe("staff bookings", () => {
  it("refuses the bookings list without a session", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/staff/bookings");
    expect(res.status).toBe(401);
  });

  it("lists bookings grouped by tasting, including guest contact details", async () => {
    const { app } = setup();
    await request(app).post("/api/bookings").send(booking);
    const cookie = await signIn(app);

    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(2);
    expect(res.body[0].tasting.id).toBe("riesling-evening");
    expect(res.body[0].bookings).toEqual([
      {
        reference: expect.stringMatching(/^KB-/),
        name: "Ada Guest",
        email: "ada@example.com",
        guests: 2,
      },
    ]);
    expect(res.body[1].bookings).toEqual([]);
  });

  it("cancels a booking and frees its seats", async () => {
    const { app } = setup();
    const created = await request(app).post("/api/bookings").send(booking);
    const cookie = await signIn(app);

    const res = await request(app)
      .delete(`/api/staff/bookings/${created.body.reference}`)
      .set("Cookie", cookie);
    expect(res.status).toBe(204);

    const tastings = await request(app).get("/api/tastings");
    expect(tastings.body[0].seatsLeft).toBe(12);
    const after = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(after.status).toBe(404);
  });

  it("returns 404 when cancelling an unknown booking", async () => {
    const { app } = setup();
    const cookie = await signIn(app);
    const res = await request(app).delete("/api/staff/bookings/KB-NOPE00").set("Cookie", cookie);
    expect(res.status).toBe(404);
  });

  it("refuses cancellation without a session", async () => {
    const { app } = setup();
    const created = await request(app).post("/api/bookings").send(booking);
    const res = await request(app).delete(`/api/staff/bookings/${created.body.reference}`);
    expect(res.status).toBe(401);
    const still = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(still.status).toBe(200);
  });

  it("ends the session on sign-out", async () => {
    const { app } = setup();
    const cookie = await signIn(app);

    const out = await request(app).delete("/api/staff/session").set("Cookie", cookie);
    expect(out.status).toBe(204);

    const res = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(res.status).toBe(401);
  });
});

describe("serving the client", () => {
  let clientDir: string;

  beforeEach(() => {
    clientDir = mkdtempSync(join(tmpdir(), ".kb-client-"));
    writeFileSync(join(clientDir, "index.html"), "<!doctype html><div id=\"root\"></div>");
  });

  afterEach(() => {
    rmSync(clientDir, { recursive: true, force: true });
  });

  it("serves the app shell for client-side routes", async () => {
    const { app } = setup({ clientDir });
    const res = await request(app).get("/booking/KB-ABC234");
    expect(res.status).toBe(200);
    expect(res.text).toContain('id="root"');
  });

  it("answers unknown API paths with JSON 404, not the app shell", async () => {
    const { app } = setup({ clientDir });
    const res = await request(app).get("/api/does-not-exist");
    expect(res.status).toBe(404);
    expect(res.headers["content-type"]).toMatch(/json/);
  });
});

describe("hardening", () => {
  it("sends security headers, including a content security policy", async () => {
    const { app } = setup();
    const res = await request(app).get("/api/tastings");

    expect(res.headers["x-content-type-options"]).toBe("nosniff");
    expect(res.headers["content-security-policy"]).toContain("default-src 'self'");
    // Over plain HTTP (e.g. a LAN address), this directive would rewrite the app's own asset URLs to HTTPS and break the page.
    expect(res.headers["content-security-policy"]).not.toContain("upgrade-insecure-requests");
    expect(res.headers["x-powered-by"]).toBeUndefined();
  });

  it("limits repeated staff sign-in attempts", async () => {
    const { app } = setup();
    let last = 0;
    for (let i = 0; i < 11; i++) {
      const res = await request(app).post("/api/staff/session").send({ password: "wrong" });
      last = res.status;
    }
    expect(last).toBe(429);
  });
});
