import express, { type NextFunction, type Request, type Response } from "express";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { BookingStore, type Booking } from "./booking-store.js";
import { STAFF_SESSION_TTL_MS, StaffSessions, passwordMatches } from "./staff-auth.js";
import { validateBookingInput } from "../shared/booking-schema.js";
import { formatSeatsLeft } from "../shared/format.js";
import type { Tasting } from "../shared/tastings.js";

export const STAFF_COOKIE = "staff_session";

const SIGN_IN_WINDOW_MS = 15 * 60 * 1000;
const SIGN_IN_ATTEMPTS_PER_WINDOW = 10;

export interface AppOptions {
  store?: BookingStore;
  sessions?: StaffSessions;
  /** Undefined or empty disables staff sign-in. */
  staffPassword?: string;
  /** Directory with the built client. When set, client routes fall back to index.html. */
  clientDir?: string;
}

export function createApp(options: AppOptions = {}) {
  const store = options.store ?? new BookingStore();
  const sessions =
    options.sessions ?? new StaffSessions({ ttlMs: STAFF_SESSION_TTL_MS });
  const staffPassword = options.staffPassword || undefined;

  const app = express();
  app.disable("x-powered-by");
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        directives: { "upgrade-insecure-requests": null },
      },
    }),
  );
  app.use(express.json({ limit: "10kb" }));
  app.use(cookieParser());

  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    if (!sessions.isValid(req.cookies?.[STAFF_COOKIE])) {
      res.status(401).json({ error: "Staff sign-in required." });
      return;
    }
    next();
  };

  app.get("/api/tastings", (_req, res) => {
    res.json(store.listTastings().map((t) => withSeatsLeft(t, store)));
  });

  app.post("/api/bookings", (req, res) => {
    const input = validateBookingInput(req.body ?? {});
    if (!input.ok) {
      res.status(400).json({ errors: input.errors });
      return;
    }
    const result = store.createBooking(input.data);
    if (!result.ok) {
      if (result.error === "unknown_tasting") {
        res.status(404).json({ errors: { tastingId: "This tasting does not exist." } });
        return;
      }
      const message =
        result.seatsLeft === 0
          ? "This tasting is fully booked."
          : `Only ${formatSeatsLeft(result.seatsLeft)}.`;
      res.status(409).json({ errors: { guests: message }, seatsLeft: result.seatsLeft });
      return;
    }
    res.status(201).json(publicBooking(result.booking, store));
  });

  app.get("/api/bookings/:reference", (req, res) => {
    const booking = store.getBooking(String(req.params.reference));
    if (!booking) {
      res.status(404).json({ error: "Booking not found." });
      return;
    }
    res.json(publicBooking(booking, store));
  });

  const signInLimiter = rateLimit({
    windowMs: SIGN_IN_WINDOW_MS,
    limit: SIGN_IN_ATTEMPTS_PER_WINDOW,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many sign-in attempts. Try again later." },
  });

  app.post("/api/staff/session", signInLimiter, (req, res) => {
    if (!staffPassword) {
      res.status(503).json({ error: "Staff sign-in is not configured." });
      return;
    }
    const given = typeof req.body?.password === "string" ? req.body.password : "";
    if (!passwordMatches(given, staffPassword)) {
      res.status(401).json({ error: "Incorrect password." });
      return;
    }
    const token = sessions.create();
    res.cookie(STAFF_COOKIE, token, {
      httpOnly: true,
      sameSite: "strict",
      path: "/",
      maxAge: STAFF_SESSION_TTL_MS,
    });
    res.status(204).end();
  });

  app.delete("/api/staff/session", (req, res) => {
    sessions.destroy(req.cookies?.[STAFF_COOKIE]);
    res.clearCookie(STAFF_COOKIE, { path: "/", httpOnly: true, sameSite: "strict" });
    res.status(204).end();
  });

  app.get("/api/staff/bookings", requireStaff, (_req, res) => {
    res.json(
      store.bookingsByTasting().map((group) => ({
        tasting: withSeatsLeft(group.tasting, store),
        bookings: group.bookings.map((b) => ({
          reference: b.reference,
          name: b.name,
          email: b.email,
          guests: b.guests,
        })),
      })),
    );
  });

  app.delete("/api/staff/bookings/:reference", requireStaff, (req, res) => {
    if (!store.cancelBooking(String(req.params.reference))) {
      res.status(404).json({ error: "Booking not found." });
      return;
    }
    res.status(204).end();
  });

  // Unknown API paths get a JSON 404 instead of the app shell.
  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Not found." });
  });

  if (options.clientDir) {
    const clientDir = options.clientDir;
    app.use(express.static(clientDir, { index: false }));
    app.use((req, res, next) => {
      if (req.method !== "GET" && req.method !== "HEAD") return next();
      // Pass root so that dot-directories above the client folder (e.g. a
      // ".worktrees" parent) do not trip send's dotfile protection.
      res.sendFile("index.html", { root: clientDir }, (err) => {
        if (err && !res.headersSent) next(err);
      });
    });
  }

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    const status = (err as { status?: unknown }).status;
    if (typeof status === "number" && status >= 400 && status < 500) {
      res.status(status).json({ error: "Invalid request." });
      return;
    }
    console.error(err);
    res.status(500).json({ error: "Something went wrong." });
  });

  return app;
}

function withSeatsLeft(tasting: Tasting, store: BookingStore) {
  return { ...tasting, seatsLeft: store.seatsLeft(tasting.id) };
}

/** Booking details that are safe to show to anyone holding the reference. */
function publicBooking(booking: Booking, store: BookingStore) {
  const tasting = store.findTasting(booking.tastingId);
  return {
    reference: booking.reference,
    tastingId: booking.tastingId,
    tastingTitle: tasting?.title ?? "",
    guests: booking.guests,
    totalPrice: (tasting?.pricePerGuest ?? 0) * booking.guests,
  };
}
