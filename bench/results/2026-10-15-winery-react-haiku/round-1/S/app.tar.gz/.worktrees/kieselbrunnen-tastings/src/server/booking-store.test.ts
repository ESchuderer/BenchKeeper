import { describe, it, expect } from "vitest";
import { BookingStore } from "./booking-store.js";
import type { Tasting } from "../shared/tastings.js";

const CATALOGUE: Tasting[] = [
  { id: "small", title: "Small", date: "2026-11-06", time: "18:00", pricePerGuest: 25, seats: 3 },
  { id: "big", title: "Big", date: "2026-11-14", time: "15:00", pricePerGuest: 32, seats: 12 },
];

function newStore() {
  return new BookingStore(CATALOGUE);
}

const guest = { name: "Ada Guest", email: "ada@example.com" };

describe("BookingStore", () => {
  it("reports all seats as left before any booking", () => {
    const store = newStore();
    expect(store.seatsLeft("small")).toBe(3);
    expect(store.seatsLeft("big")).toBe(12);
  });

  it("reserves the booked guests from the seats left", () => {
    const store = newStore();
    const result = store.createBooking({ tastingId: "big", guests: 3, ...guest });

    expect(result.ok).toBe(true);
    expect(store.seatsLeft("big")).toBe(9);
    expect(store.seatsLeft("small")).toBe(3);
  });

  it("rejects a booking larger than the seats left and reserves nothing", () => {
    const store = newStore();
    const result = store.createBooking({ tastingId: "small", guests: 4, ...guest });

    expect(result).toEqual({ ok: false, error: "insufficient_seats", seatsLeft: 3 });
    expect(store.seatsLeft("small")).toBe(3);
    expect(store.bookingsByTasting()[0].bookings).toHaveLength(0);
  });

  it("accepts a booking for exactly the seats left and then reports the tasting full", () => {
    const store = newStore();
    expect(store.createBooking({ tastingId: "small", guests: 2, ...guest }).ok).toBe(true);
    expect(store.createBooking({ tastingId: "small", guests: 1, ...guest }).ok).toBe(true);

    expect(store.seatsLeft("small")).toBe(0);
    expect(store.createBooking({ tastingId: "small", guests: 1, ...guest })).toEqual({
      ok: false,
      error: "insufficient_seats",
      seatsLeft: 0,
    });
  });

  it("rejects an unknown tasting", () => {
    const store = newStore();
    expect(store.createBooking({ tastingId: "nope", guests: 1, ...guest })).toEqual({
      ok: false,
      error: "unknown_tasting",
    });
  });

  it("returns the stored booking with a reference and the trimmed guest details", () => {
    const store = newStore();
    const result = store.createBooking({ tastingId: "big", guests: 2, ...guest });
    if (!result.ok) throw new Error("expected booking to succeed");

    expect(result.booking.tastingId).toBe("big");
    expect(result.booking.guests).toBe(2);
    expect(result.booking.name).toBe("Ada Guest");
    expect(result.booking.email).toBe("ada@example.com");
    expect(store.getBooking(result.booking.reference)).toEqual(result.booking);
  });

  it("issues unique references in the form KB-XXXXXX", () => {
    const store = new BookingStore([
      { id: "big", title: "Big", date: "2026-11-14", time: "15:00", pricePerGuest: 32, seats: 500 },
    ]);
    const refs = new Set<string>();
    for (let i = 0; i < 300; i++) {
      const result = store.createBooking({ tastingId: "big", guests: 1, ...guest });
      if (!result.ok) throw new Error("expected booking to succeed");
      refs.add(result.booking.reference);
      expect(result.booking.reference).toMatch(/^KB-[A-Z2-9]{6}$/);
    }
    expect(refs.size).toBe(300);
  });

  it("frees the seats of a cancelled booking", () => {
    const store = newStore();
    const result = store.createBooking({ tastingId: "small", guests: 3, ...guest });
    if (!result.ok) throw new Error("expected booking to succeed");
    expect(store.seatsLeft("small")).toBe(0);

    expect(store.cancelBooking(result.booking.reference)).toBe(true);
    expect(store.seatsLeft("small")).toBe(3);
    expect(store.getBooking(result.booking.reference)).toBeUndefined();
  });

  it("returns false when cancelling an unknown reference", () => {
    const store = newStore();
    expect(store.cancelBooking("KB-NOPE00")).toBe(false);
  });

  it("groups bookings by tasting in catalogue order, including empty groups", () => {
    const store = newStore();
    store.createBooking({ tastingId: "big", guests: 1, name: "B", email: "b@example.com" });
    store.createBooking({ tastingId: "small", guests: 2, name: "A", email: "a@example.com" });

    const groups = store.bookingsByTasting();
    expect(groups.map((g) => g.tasting.id)).toEqual(["small", "big"]);
    expect(groups[0].bookings.map((b) => b.name)).toEqual(["A"]);
    expect(groups[1].bookings.map((b) => b.name)).toEqual(["B"]);
  });
});
