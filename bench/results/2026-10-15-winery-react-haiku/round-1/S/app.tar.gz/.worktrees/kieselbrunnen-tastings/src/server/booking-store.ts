import { randomInt } from "node:crypto";
import { TASTINGS, type Tasting } from "../shared/tastings.js";

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export interface NewBooking {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export type BookingResult =
  | { ok: true; booking: Booking }
  | { ok: false; error: "unknown_tasting" }
  | { ok: false; error: "insufficient_seats"; seatsLeft: number };

export interface TastingBookings {
  tasting: Tasting;
  bookings: Booking[];
}

// Upper-case letters and digits without the look-alikes 0, O, 1 and I.
const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const REFERENCE_LENGTH = 6;

/**
 * In-memory booking store. Seat checks and reservations happen in one
 * synchronous call, so two requests can never both take the last seat.
 */
export class BookingStore {
  private readonly tastings: readonly Tasting[];
  private readonly bookings = new Map<string, Booking>();

  constructor(tastings: readonly Tasting[] = TASTINGS) {
    this.tastings = tastings;
  }

  listTastings(): readonly Tasting[] {
    return this.tastings;
  }

  seatsLeft(tastingId: string): number {
    const tasting = this.findTasting(tastingId);
    if (!tasting) return 0;
    let taken = 0;
    for (const booking of this.bookings.values()) {
      if (booking.tastingId === tastingId) taken += booking.guests;
    }
    return tasting.seats - taken;
  }

  createBooking(input: NewBooking): BookingResult {
    if (!this.findTasting(input.tastingId)) {
      return { ok: false, error: "unknown_tasting" };
    }
    const seatsLeft = this.seatsLeft(input.tastingId);
    if (input.guests > seatsLeft) {
      return { ok: false, error: "insufficient_seats", seatsLeft };
    }
    const booking: Booking = {
      reference: this.newReference(),
      tastingId: input.tastingId,
      name: input.name,
      email: input.email,
      guests: input.guests,
    };
    this.bookings.set(booking.reference, booking);
    return { ok: true, booking };
  }

  getBooking(reference: string): Booking | undefined {
    return this.bookings.get(reference);
  }

  cancelBooking(reference: string): boolean {
    return this.bookings.delete(reference);
  }

  bookingsByTasting(): TastingBookings[] {
    const all = [...this.bookings.values()];
    return this.tastings.map((tasting) => ({
      tasting,
      bookings: all.filter((b) => b.tastingId === tasting.id),
    }));
  }

  findTasting(tastingId: string): Tasting | undefined {
    return this.tastings.find((t) => t.id === tastingId);
  }

  private newReference(): string {
    for (;;) {
      let suffix = "";
      for (let i = 0; i < REFERENCE_LENGTH; i++) {
        suffix += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
      }
      const reference = `KB-${suffix}`;
      if (!this.bookings.has(reference)) return reference;
    }
  }
}
