import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";

// Compiled to dist/server/index.js; the built client lives in dist/client.
const here = dirname(fileURLToPath(import.meta.url));
const clientDir = join(here, "..", "client");

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD || undefined;

if (!staffPassword) {
  console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
}
if (!existsSync(join(clientDir, "index.html"))) {
  console.warn(`No client build found in ${clientDir}. Run "npm run build" first.`);
}

const app = createApp({
  staffPassword,
  clientDir: existsSync(join(clientDir, "index.html")) ? clientDir : undefined,
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
});
