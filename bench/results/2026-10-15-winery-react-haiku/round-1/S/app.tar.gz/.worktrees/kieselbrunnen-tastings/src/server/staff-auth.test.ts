import { describe, it, expect } from "vitest";
import { passwordMatches, StaffSessions } from "./staff-auth.js";

describe("passwordMatches", () => {
  it("accepts the configured password", () => {
    expect(passwordMatches("correct horse", "correct horse")).toBe(true);
  });

  it("rejects a different password, including one of another length", () => {
    expect(passwordMatches("wrong", "correct horse")).toBe(false);
    expect(passwordMatches("correct horse!", "correct horse")).toBe(false);
  });

  it("rejects an empty password", () => {
    expect(passwordMatches("", "correct horse")).toBe(false);
  });
});

describe("StaffSessions", () => {
  it("issues a token that is valid until it is destroyed", () => {
    const sessions = new StaffSessions({ ttlMs: 60_000 });
    const token = sessions.create();

    expect(token.length).toBeGreaterThanOrEqual(32);
    expect(sessions.isValid(token)).toBe(true);

    sessions.destroy(token);
    expect(sessions.isValid(token)).toBe(false);
  });

  it("does not accept unknown tokens", () => {
    const sessions = new StaffSessions({ ttlMs: 60_000 });
    expect(sessions.isValid("made-up")).toBe(false);
    expect(sessions.isValid(undefined)).toBe(false);
  });

  it("expires a session after its time to live", () => {
    let now = 1_000;
    const sessions = new StaffSessions({ ttlMs: 60_000, now: () => now });
    const token = sessions.create();

    now += 59_999;
    expect(sessions.isValid(token)).toBe(true);

    now += 1;
    expect(sessions.isValid(token)).toBe(false);
  });

  it("forgets expired sessions when new ones are issued", () => {
    let now = 0;
    const sessions = new StaffSessions({ ttlMs: 1_000, now: () => now });
    sessions.create();
    sessions.create();
    now = 2_000;
    sessions.create();

    expect(sessions.activeCount()).toBe(1);
  });

  it("issues different tokens each time", () => {
    const sessions = new StaffSessions({ ttlMs: 60_000 });
    expect(sessions.create()).not.toBe(sessions.create());
  });
});
