import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

/**
 * Compares a submitted password with the configured one in constant time.
 * Both values are hashed first so the comparison always has equal length.
 */
export function passwordMatches(given: string, expected: string): boolean {
  if (given.length === 0 || expected.length === 0) return false;
  const a = createHash("sha256").update(given, "utf8").digest();
  const b = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(a, b) && given === expected;
}

export const STAFF_SESSION_TTL_MS = 8 * 60 * 60 * 1000;

export interface StaffSessionsOptions {
  ttlMs: number;
  now?: () => number;
}

/** Opaque, in-memory staff sessions with a fixed time to live. */
export class StaffSessions {
  private readonly ttlMs: number;
  private readonly now: () => number;
  private readonly expiry = new Map<string, number>();

  constructor(options: StaffSessionsOptions) {
    this.ttlMs = options.ttlMs;
    this.now = options.now ?? Date.now;
  }

  create(): string {
    this.sweepExpired();
    const token = randomBytes(32).toString("base64url");
    this.expiry.set(token, this.now() + this.ttlMs);
    return token;
  }

  /** Number of sessions that are stored and not yet expired. */
  activeCount(): number {
    this.sweepExpired();
    return this.expiry.size;
  }

  isValid(token: string | undefined): boolean {
    if (!token) return false;
    const expiresAt = this.expiry.get(token);
    if (expiresAt === undefined) return false;
    if (this.now() >= expiresAt) {
      this.expiry.delete(token);
      return false;
    }
    return true;
  }

  destroy(token: string | undefined): void {
    if (token) this.expiry.delete(token);
  }

  private sweepExpired(): void {
    const now = this.now();
    for (const [token, expiresAt] of this.expiry) {
      if (now >= expiresAt) this.expiry.delete(token);
    }
  }
}
