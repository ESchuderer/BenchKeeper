import type { BookingFieldErrors } from "./booking-schema.js";
import type { Tasting } from "./tastings.js";

export interface PublicTasting extends Tasting {
  seatsLeft: number;
}

/** What a guest sees after booking. Contact details are never included. */
export interface ConfirmedBooking {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  guests: number;
  totalPrice: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTastingGroup {
  tasting: PublicTasting;
  bookings: StaffBooking[];
}

export interface ApiErrorBody {
  error?: string;
  errors?: BookingFieldErrors;
  seatsLeft?: number;
}
