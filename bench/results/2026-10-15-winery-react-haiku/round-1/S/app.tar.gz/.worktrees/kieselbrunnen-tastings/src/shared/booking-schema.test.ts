import { describe, it, expect } from "vitest";
import { validateBookingInput } from "./booking-schema.js";

const valid = {
  tastingId: "riesling-evening",
  name: "  Ada Guest  ",
  email: " ada@example.com ",
  guests: 2,
};

describe("validateBookingInput", () => {
  it("accepts valid input and trims name and email", () => {
    const result = validateBookingInput(valid);
    expect(result).toEqual({
      ok: true,
      data: {
        tastingId: "riesling-evening",
        name: "Ada Guest",
        email: "ada@example.com",
        guests: 2,
      },
    });
  });

  it("asks for a name when it is blank", () => {
    const result = validateBookingInput({ ...valid, name: "   " });
    expect(result).toEqual({ ok: false, errors: { name: "Please enter your name." } });
  });

  it("rejects a name longer than 100 characters", () => {
    const result = validateBookingInput({ ...valid, name: "x".repeat(101) });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.errors.name).toBe("Name must be 100 characters or fewer.");
  });

  it("asks for an email address when it is blank", () => {
    const result = validateBookingInput({ ...valid, email: "" });
    expect(result).toEqual({ ok: false, errors: { email: "Please enter your email address." } });
  });

  it("rejects an email address that is not valid", () => {
    const result = validateBookingInput({ ...valid, email: "ada@" });
    expect(result).toEqual({ ok: false, errors: { email: "Please enter a valid email address." } });
  });

  it.each([0, 9, 2.5, -1])("rejects %s guests", (guests) => {
    const result = validateBookingInput({ ...valid, guests });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.errors.guests).toBe("Choose between 1 and 8 guests.");
  });

  it("asks for the number of guests when it is not a number", () => {
    const result = validateBookingInput({ ...valid, guests: Number.NaN });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.errors.guests).toBe("Please enter the number of guests.");
  });

  it("accepts the bounds 1 and 8", () => {
    expect(validateBookingInput({ ...valid, guests: 1 }).ok).toBe(true);
    expect(validateBookingInput({ ...valid, guests: 8 }).ok).toBe(true);
  });

  it("reports every invalid field at once", () => {
    const result = validateBookingInput({ tastingId: "", name: "", email: "", guests: 0 });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(Object.keys(result.errors).sort()).toEqual(["email", "guests", "name", "tastingId"]);
  });
});
