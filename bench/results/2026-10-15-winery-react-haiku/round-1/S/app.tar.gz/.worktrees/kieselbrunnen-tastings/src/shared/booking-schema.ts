import { z } from "zod";
import { MAX_GUESTS, MIN_GUESTS } from "./tastings.js";

export type BookingField = "tastingId" | "name" | "email" | "guests";

export interface BookingInput {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export type BookingFieldErrors = Partial<Record<BookingField, string>>;

export type ValidationResult =
  | { ok: true; data: BookingInput }
  | { ok: false; errors: BookingFieldErrors };

const NAME_MAX_LENGTH = 100;

export const bookingSchema = z.object({
  tastingId: z.string({ error: "Choose a tasting." }).min(1, "Choose a tasting."),
  name: z
    .string({ error: "Please enter your name." })
    .trim()
    .min(1, "Please enter your name.")
    .max(NAME_MAX_LENGTH, `Name must be ${NAME_MAX_LENGTH} characters or fewer.`),
  email: z
    .string({ error: "Please enter your email address." })
    .trim()
    .min(1, "Please enter your email address.")
    .pipe(z.email({ error: "Please enter a valid email address." })),
  guests: z
    .number({ error: "Please enter the number of guests." })
    .int({ error: `Choose between ${MIN_GUESTS} and ${MAX_GUESTS} guests.` })
    .min(MIN_GUESTS, `Choose between ${MIN_GUESTS} and ${MAX_GUESTS} guests.`)
    .max(MAX_GUESTS, `Choose between ${MIN_GUESTS} and ${MAX_GUESTS} guests.`),
});

/** Validates booking input. Used by the guest form and by the API. */
export function validateBookingInput(input: unknown): ValidationResult {
  const parsed = bookingSchema.safeParse(input);
  if (parsed.success) {
    return { ok: true, data: parsed.data };
  }
  const errors: BookingFieldErrors = {};
  for (const issue of parsed.error.issues) {
    const field = issue.path[0];
    if (typeof field === "string" && isBookingField(field) && !errors[field]) {
      errors[field] = issue.message;
    }
  }
  return { ok: false, errors };
}

function isBookingField(value: string): value is BookingField {
  return value === "tastingId" || value === "name" || value === "email" || value === "guests";
}
