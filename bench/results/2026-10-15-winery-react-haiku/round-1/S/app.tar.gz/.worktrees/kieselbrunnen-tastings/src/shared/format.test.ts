import { describe, it, expect } from "vitest";
import { formatDate, formatPrice, formatSeatsLeft, formatTime } from "./format.js";

describe("format helpers", () => {
  it("formats prices in euros", () => {
    expect(formatPrice(25)).toBe("EUR 25");
    expect(formatPrice(75)).toBe("EUR 75");
  });

  it("formats dates with weekday, day, month and year", () => {
    expect(formatDate("2026-11-06")).toBe("Friday, 6 November 2026");
    expect(formatDate("2026-12-05")).toBe("Saturday, 5 December 2026");
  });

  it("returns the time unchanged", () => {
    expect(formatTime("18:00")).toBe("18:00");
  });

  it("formats the seats left count", () => {
    expect(formatSeatsLeft(12)).toBe("12 seats left");
    expect(formatSeatsLeft(0)).toBe("0 seats left");
    expect(formatSeatsLeft(1)).toBe("1 seat left");
  });
});
