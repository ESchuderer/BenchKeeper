const dateFormatter = new Intl.DateTimeFormat("en-GB", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
  timeZone: "UTC",
});

/** Whole euros, e.g. "EUR 25". */
export function formatPrice(euros: number): string {
  return `EUR ${euros}`;
}

/** "2026-11-06" becomes "Friday 6 November 2026". */
export function formatDate(isoDate: string): string {
  const [year, month, day] = isoDate.split("-").map(Number);
  return dateFormatter.format(new Date(Date.UTC(year, month - 1, day)));
}

export function formatTime(time: string): string {
  return time;
}

export function formatSeatsLeft(seats: number): string {
  return seats === 1 ? "1 seat left" : `${seats} seats left`;
}
