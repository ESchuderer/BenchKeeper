# Spec: Weingut Kieselbrunnen Tasting Bookings

## Objective

A small web app for Weingut Kieselbrunnen, a family winery, in two parts:

- **Guests** see the upcoming tastings, book seats for one tasting, and get a booking confirmation with a reference.
- **Staff** sign in with a shared password and see all bookings grouped by tasting. They can cancel a booking, which frees its seats.

Success means a guest can book a tasting on a phone in under a minute, can never over-book a tasting, and staff can see and cancel bookings.

### Catalogue (fixed in code)

| id | Title | Date | Time | Price per guest | Seats |
|---|---|---|---|---|---|
| `riesling-evening` | Riesling Evening | 2026-11-06 | 18:00 | EUR 25 | 12 |
| `red-wine-cellar-tour` | Red Wine Cellar Tour | 2026-11-14 | 15:00 | EUR 32 | 8 |
| `winter-tasting` | Winter Tasting | 2026-12-05 | 17:00 | EUR 28 | 10 |

### Assumptions (please correct)

1. One shared staff password (`STAFF_PASSWORD`); no per-person staff accounts.
2. Bookings are held in memory. They start empty and are lost when the server restarts. The brief allows this; a file-backed store would be a later change.
3. No payment. "Total price" is shown on the confirmation only; guests pay at the winery.
4. No email is sent. The confirmation appears on screen, and it can be reopened later with the reference.
5. Times are the winery's local time as written. No time zone conversion.
6. The tasting catalogue is changed by editing code, not through a UI.
7. A booking is one name, one email and 1 to 8 guests. Guests are not named individually.
8. Only staff can cancel. Guests cannot cancel or edit.
9. A booking may be made for any tasting with enough seats left. No booking cut-off is enforced before the start time.
10. Booking reference format: `KB-` followed by 6 characters from `A-Z` and `2-9` (no look-alikes).
11. Prices are shown as `EUR 25` (whole euros) or `EUR 25.50` when cents are needed.
12. Seats left is shown as `<n> seats left`, literally, including for 1.
13. Staff session lasts 8 hours and is kept in an HttpOnly cookie. Staff can sign out.
14. The interface is English only.

## Tech Stack

- Runtime: Node.js 22, TypeScript (strict)
- Server: Express 5, zod 4 (validation), helmet (headers), express-rate-limit (staff sign-in), cookie-parser
- Client: React 19, React Router 8 (`react-router`, data router), react-hook-form with `@hookform/resolvers` (zod), Tailwind CSS 4 via `@tailwindcss/vite`
- Build: Vite (client), `tsc` (server)
- Tests: Vitest, Supertest (API), React Testing Library + jsdom (components), Playwright (end-to-end, if a browser can be installed)
- Lint: ESLint flat config with typescript-eslint, react-hooks, jsx-a11y

## Commands

```
Install:     npm install
Build:       npm run build            # vite build (client) + tsc (server) -> dist/
Start:       npm start                # serves app on $PORT (default 3000); builds first if needed
Dev server:  npm run dev:server       # API with tsx watch on :3000
Dev client:  npm run dev:client       # Vite on :5173, proxies /api to :3000
Test:        npm test                 # vitest run (unit + API + component)
Test watch:  npm run test:watch
E2E:         npm run test:e2e         # playwright, starts the built app
Typecheck:   npm run typecheck
Lint:        npm run lint
```

Environment variables:

- `PORT` (default 3000)
- `STAFF_PASSWORD` (required for staff sign-in; if unset, staff sign-in is refused and a warning is logged at startup)

## Project Structure

```
src/
  shared/          Catalogue, zod schemas, price/date formatting (used by server and client)
  server/          Express app (app.ts), entry (index.ts), booking store, staff session
  client/          React app: main.tsx, router, pages/, components/, api.ts, styles.css
tests/
  server/          Vitest + Supertest API tests
  client/          Vitest + RTL component/page tests (jsdom)
  e2e/             Playwright specs
dist/              Build output (gitignored)
tasks/             plan.md and todo.md
SPEC.md            This spec
```

## HTTP API

All JSON. Errors use `{ "errors": { "<field>": "message" } }` for field errors or `{ "message": "..." }` otherwise.

| Method | Path | Purpose | Success | Errors |
|---|---|---|---|---|
| GET | `/api/tastings` | List tastings with `seatsLeft` | 200 | |
| GET | `/api/tastings/:id` | One tasting | 200 | 404 |
| POST | `/api/tastings/:id/bookings` | Body `{name,email,guests}` | 201 `{reference, ...}` | 404 unknown tasting; 422 field errors; 409 `errors.guests` when seats are short |
| GET | `/api/bookings/:reference` | Public confirmation view (no email) | 200 | 404 |
| GET | `/api/staff/session` | Whether the caller is signed in | 200 `{signedIn}` | |
| POST | `/api/staff/session` | Body `{password}`; sets session cookie | 204 | 401 wrong password; 422 empty password; 429 too many attempts; 503 staff sign-in not configured |
| DELETE | `/api/staff/session` | Sign out | 204 | |
| GET | `/api/staff/bookings` | All bookings grouped by tasting | 200 | 401 |
| DELETE | `/api/staff/bookings/:reference` | Cancel a booking, frees seats | 204 | 401; 404 |

Staff responses carry `Cache-Control: no-store`. The API sends helmet security headers, including a Content-Security-Policy limited to the app origin.

## Code Style

```ts
// src/server/store.ts — pure domain logic, returns results instead of throwing for expected cases
export function reserve(input: NewBooking): ReserveResult {
  const tasting = findTasting(input.tastingId);
  if (!tasting) return { ok: false, reason: 'unknown-tasting' };
  const left = seatsLeft(tasting.id);
  if (input.guests > left) return { ok: false, reason: 'not-enough-seats', seatsLeft: left };
  // ...
}
```

- Named exports, no default exports except React pages.
- `camelCase` functions, `PascalCase` components and types, `kebab-case` file names for non-component modules, `PascalCase.tsx` for components.
- Money is stored in integer cents. Formatting happens only in `src/shared/format.ts`.
- Validation schemas live in `src/shared/schemas.ts` and are used on the client (for UX) and the server (as the authority).

## Testing Strategy

- **Unit (Vitest, small):** schemas, seat arithmetic, reference generation, formatting.
- **API (Vitest + Supertest, medium):** each endpoint, including 422/409/401/404 paths, seat limits, cancellation freeing seats, and cookie behaviour. The store is real (in-memory), not mocked.
- **Components/pages (Vitest + RTL + jsdom):** booking form labels, inline field errors, success navigation, fully booked state, staff sign-in and list.
- **E2E (Playwright, large, few):** guest booking happy path, seat limit, staff sign-in, cancel frees seats, mobile viewport.
- Every behaviour gets a test written first (red, then green).

## Boundaries

- **Always:** validate every input on the server; check the staff session on every staff route; keep the seat check and insert in one synchronous step; show errors next to the field they concern; run tests before calling work done.
- **Ask first:** adding a database or external service; adding email or payment; changing the catalogue structure; changing the auth model; adding new runtime dependencies beyond those listed above.
- **Never:** commit `STAFF_PASSWORD` or any secret; log passwords or session tokens; return stack traces to clients; disable helmet or CSP; delete or skip failing tests to get green; hardcode seat counts outside the catalogue.

## Success Criteria

1. `npm install`, `npm run build`, `npm start` run on Node 22 with no errors; the app serves on `PORT`.
2. The start page lists the three tastings with title, date and time, price per guest and `<n> seats left`.
3. Each tasting has a link or button `Book <title>` that opens a form with labelled fields `Name`, `Email`, `Guests` (1 to 8) and a `Book` button.
4. Invalid input (empty name, invalid email, guests outside 1 to 8, non-integer guests) shows an error next to the field and does not create a booking.
5. Guests greater than seats left are rejected with an error next to `Guests`; the server enforces this even if the client is bypassed.
6. A successful booking shows `Booking confirmed`, the tasting, the number of guests, the total price (`EUR` amount) and the reference. Reloading the confirmation URL shows the same details.
7. A fully booked tasting shows a clear "Fully booked" state, `0 seats left`, and no booking form.
8. `/staff` shows a `Password` field and `Sign in` button. A wrong password shows an error. The correct password (from `STAFF_PASSWORD`) signs in.
9. Signed in, staff see all bookings grouped by tasting with name, email, guests and reference, and a `Cancel` button per booking. Cancelling removes the booking and frees its seats on the start page immediately.
10. Staff API routes return 401 without a valid session.
11. The UI is usable at 320px width and at desktop width, with a coherent winery-style visual design and clear error, success and fully-booked states.
12. All tests pass; typecheck and lint pass; the build is clean.

## Open Questions

None blocking. Assumptions 2, 3 and 4 (memory store, no payment, no email) are the ones most likely to need the owner's decision.
