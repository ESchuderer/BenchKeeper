import { test, expect, type APIRequestContext } from '@playwright/test';

async function seatsLeft(request: APIRequestContext, id: string): Promise<number> {
  const res = await request.get(`/api/tastings/${id}`);
  return (await res.json()).seatsLeft;
}

test.describe('guest booking', () => {
  test('a guest books Riesling Evening and sees the confirmation', async ({ page, request }) => {
    const before = await seatsLeft(request, 'riesling-evening');

    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
    await page.getByRole('link', { name: 'Book Riesling Evening' }).click();

    await expect(page.getByRole('heading', { name: 'Riesling Evening', level: 1 })).toBeVisible();
    await page.getByLabel('Name').fill('Anna Keller');
    await page.getByLabel('Email').fill('anna@example.com');
    await page.getByLabel('Guests').fill('2');
    await page.getByRole('button', { name: 'Book' }).click();

    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    const details = page.getByRole('region', { name: 'Booking details' });
    await expect(details).toContainText('Riesling Evening');
    await expect(details).toContainText('Friday, 6 November 2026 at 18:00');
    await expect(details).toContainText('EUR 50');
    const reference = (await details.locator('dd').last().innerText()).trim();
    expect(reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
    await expect(details).not.toContainText('anna@example.com');

    // The confirmation survives a reload because it is addressed by reference.
    await page.reload();
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    await expect(page.getByRole('region', { name: 'Booking details' })).toContainText(reference);

    expect(await seatsLeft(request, 'riesling-evening')).toBe(before - 2);
  });

  test('invalid input shows errors next to the fields and books nothing', async ({ page }) => {
    await page.goto('/tastings/winter-tasting/book');
    await expect(page.getByRole('heading', { name: 'Winter Tasting', level: 1 })).toBeVisible();

    await page.getByLabel('Name').fill('');
    await page.getByLabel('Email').fill('not-an-email');
    await page.getByLabel('Guests').fill('9');
    await page.getByRole('button', { name: 'Book' }).click();

    await expect(page.getByText('Enter your name')).toBeVisible();
    await expect(page.getByText('Enter a valid email address')).toBeVisible();
    await expect(page.getByText('Up to 8 guests per booking')).toBeVisible();
    await expect(page.getByLabel('Name')).toHaveAttribute('aria-invalid', 'true');
    await expect(page).toHaveURL(/\/tastings\/winter-tasting\/book$/);
  });

  test('a guest cannot book more seats than are left', async ({ page, request }) => {
    const res = await request.post('/api/tastings/red-wine-cellar-tour/bookings', {
      data: { name: 'Earlier Guest', email: 'earlier@example.com', guests: 6 },
    });
    expect(res.status()).toBe(201);

    await page.goto('/tastings/red-wine-cellar-tour/book');
    await expect(page.getByText('2 seats left')).toBeVisible();
    await page.getByLabel('Name').fill('Ben Müller');
    await page.getByLabel('Email').fill('ben@example.com');
    await page.getByLabel('Guests').fill('3');
    await page.getByRole('button', { name: 'Book' }).click();

    await expect(page.getByText('Only 2 seats left for this tasting')).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
    expect(await seatsLeft(request, 'red-wine-cellar-tour')).toBe(2);
  });

  test('a fully booked tasting is shown as fully booked with no form', async ({ page, request }) => {
    const res = await request.post('/api/tastings/winter-tasting/bookings', {
      data: { name: 'Group Booking', email: 'group@example.com', guests: 8 },
    });
    expect(res.status()).toBe(201);
    const res2 = await request.post('/api/tastings/winter-tasting/bookings', {
      data: { name: 'Second Group', email: 'second@example.com', guests: 2 },
    });
    expect(res2.status()).toBe(201);

    await page.goto('/');
    const card = page.locator('article', { has: page.getByRole('heading', { name: 'Winter Tasting' }) });
    await expect(card.getByText('Fully booked', { exact: true })).toBeVisible();
    await expect(card.getByText('0 seats left')).toBeVisible();
    await expect(card.getByRole('link')).toHaveCount(0);

    await page.goto('/tastings/winter-tasting/book');
    await expect(page.getByText('This tasting is fully booked')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Book' })).toHaveCount(0);
  });

  test('an unknown booking reference shows a page not found message', async ({ page }) => {
    await page.goto('/bookings/KB-ZZZZZZ');
    await expect(page.getByRole('heading', { name: 'Page not found' })).toBeVisible();
  });
});
