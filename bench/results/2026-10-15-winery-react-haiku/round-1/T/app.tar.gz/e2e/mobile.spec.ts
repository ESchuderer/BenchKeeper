import { test, expect } from '@playwright/test';

test.describe('phone layout', () => {
  test('the start page fits the screen width without sideways scrolling', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();

    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBeLessThanOrEqual(0);
  });

  test('a guest can book on a phone', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('link', { name: 'Book Riesling Evening' }).tap();
    await page.getByLabel('Name').fill('Phone Guest');
    await page.getByLabel('Email').fill('phone@example.com');
    await page.getByLabel('Guests').fill('1');
    await page.getByRole('button', { name: 'Book' }).tap();

    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBeLessThanOrEqual(0);
  });
});
