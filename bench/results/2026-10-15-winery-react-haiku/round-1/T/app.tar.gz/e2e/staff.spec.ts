import { test, expect, type APIRequestContext } from '@playwright/test';

async function seatsLeft(request: APIRequestContext, id: string): Promise<number> {
  const res = await request.get(`/api/tastings/${id}`);
  return (await res.json()).seatsLeft;
}

async function signIn(page: import('@playwright/test').Page) {
  await page.goto('/staff');
  await page.getByLabel('Password').fill('e2e-pass');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: 'Bookings', level: 1 })).toBeVisible();
}

test.describe('staff', () => {
  test('a wrong password shows an error next to the Password field', async ({ page }) => {
    await page.goto('/staff');
    await page.getByLabel('Password').fill('not-the-password');
    await page.getByRole('button', { name: 'Sign in' }).click();

    await expect(page.getByText('Incorrect password')).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Bookings', level: 1 })).toHaveCount(0);
  });

  test('staff see bookings grouped by tasting and can cancel one, which frees its seats', async ({
    page,
    request,
  }) => {
    const created = await request.post('/api/tastings/riesling-evening/bookings', {
      data: { name: 'Carla Staff Check', email: 'carla@example.com', guests: 3 },
    });
    const { reference } = await created.json();
    const before = await seatsLeft(request, 'riesling-evening');

    await signIn(page);
    const section = page.locator('section', { has: page.getByRole('heading', { name: 'Riesling Evening', level: 2 }) });
    const row = section.getByRole('row', { name: /Carla Staff Check/ });
    await expect(row).toContainText('carla@example.com');
    await expect(row).toContainText('3');
    await expect(row).toContainText(reference);

    await row.getByRole('button', { name: 'Cancel' }).click();

    await expect(page.getByRole('status')).toContainText(`Booking ${reference} cancelled`);
    await expect(section.getByRole('row', { name: /Carla Staff Check/ })).toHaveCount(0);
    expect(await seatsLeft(request, 'riesling-evening')).toBe(before + 3);
  });

  test('signing out returns to the sign-in form and hides the bookings', async ({ page }) => {
    await signIn(page);

    await page.getByRole('button', { name: 'Sign out' }).click();

    await expect(page.getByRole('button', { name: 'Sign in' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toHaveCount(0);
  });

  test('the staff API refuses requests without a sign-in', async ({ request }) => {
    const res = await request.get('/api/staff/bookings');
    expect(res.status()).toBe(401);
  });
});
