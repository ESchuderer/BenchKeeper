import { defineConfig, devices } from '@playwright/test';

const PORT = 3123;

// The suite runs the built app against an in-memory store that starts empty.
// Each spec uses its own tasting so the tests do not depend on each other's seats.
export default defineConfig({
  testDir: 'e2e',
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [['list']],
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: 'retain-on-failure',
  },
  projects: [
    {
      name: 'desktop',
      use: { ...devices['Desktop Chrome'] },
      testIgnore: /mobile\.spec\.ts/,
    },
    {
      name: 'mobile',
      use: { ...devices['Pixel 5'] },
      testMatch: /mobile\.spec\.ts/,
    },
  ],
  webServer: {
    command: 'npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    reuseExistingServer: false,
    timeout: 60_000,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-pass' },
  },
});
