import type { BookingConfirmation, StaffTastingGroup, TastingView, ApiErrorBody } from '../shared/types.js';
import type { BookingForm, LoginForm } from '../shared/schemas.js';

export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
    readonly fieldErrors: Record<string, string> = {},
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

async function request<T>(path: string, init: { method?: string; body?: string } = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (init.body !== undefined) headers['Content-Type'] = 'application/json';

  let response: Response;
  try {
    response = await fetch(path, { ...init, headers });
  } catch {
    throw new ApiError(0, 'We could not reach the server. Check your connection and try again.');
  }

  if (response.status === 204) return undefined as T;

  const body = (await response.json().catch(() => ({}))) as ApiErrorBody;
  if (!response.ok) {
    throw new ApiError(
      response.status,
      body.message ?? 'Something went wrong. Please try again.',
      body.errors ?? {},
    );
  }
  return body as T;
}

export const api = {
  listTastings: () => request<TastingView[]>('/api/tastings'),

  getTasting: (id: string) => request<TastingView>(`/api/tastings/${encodeURIComponent(id)}`),

  createBooking: (tastingId: string, form: BookingForm) =>
    request<BookingConfirmation>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
      method: 'POST',
      body: JSON.stringify(form),
    }),

  getBooking: (reference: string) =>
    request<BookingConfirmation>(`/api/bookings/${encodeURIComponent(reference)}`),

  staffSignIn: (form: LoginForm) =>
    request<void>('/api/staff/session', { method: 'POST', body: JSON.stringify(form) }),

  staffSession: () => request<{ signedIn: boolean }>('/api/staff/session'),

  staffSignOut: () => request<void>('/api/staff/session', { method: 'DELETE' }),

  staffBookings: () => request<StaffTastingGroup[]>('/api/staff/bookings'),

  cancelBooking: (reference: string) =>
    request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' }),
};
