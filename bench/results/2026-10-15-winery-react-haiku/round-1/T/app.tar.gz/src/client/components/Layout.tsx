import type { ReactNode } from 'react';
import { Link, NavLink, Outlet } from 'react-router';

export function Layout({ children }: { children?: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <header className="bg-wine text-cream">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <Link to="/" className="group flex flex-col no-underline">
            <span className="font-serif text-xl tracking-wide text-gold-light group-hover:text-cream sm:text-2xl">
              Weingut Kieselbrunnen
            </span>
            <span className="text-xs uppercase tracking-[0.2em] text-cream/75">Family winery</span>
          </Link>
          <nav aria-label="Main" className="flex gap-5 text-sm">
            <NavLink to="/" end className="nav-link">
              Tastings
            </NavLink>
            <NavLink to="/staff" className="nav-link">
              Staff
            </NavLink>
          </nav>
        </div>
        <div className="h-1 bg-gold" aria-hidden="true" />
      </header>

      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        {children ?? <Outlet />}
      </main>

      <footer className="border-t border-line bg-paper">
        <div className="mx-auto max-w-5xl px-4 py-6 text-sm text-muted sm:px-6">
          Weingut Kieselbrunnen · Family winery
        </div>
      </footer>
    </div>
  );
}
