import { Link } from 'react-router';
import { formatDateTime, formatEur, formatSeatsLeft } from '../../shared/format.js';
import type { TastingView } from '../../shared/types.js';

export function TastingCard({ tasting }: { tasting: TastingView }) {
  const fullyBooked = tasting.seatsLeft === 0;
  const lowAvailability = !fullyBooked && tasting.seatsLeft <= 3;
  const headingId = `tasting-${tasting.id}`;

  return (
    <article aria-labelledby={headingId} className="card flex h-full flex-col">
      <div className="flex items-start justify-between gap-3">
        <h2 id={headingId} className="font-serif text-2xl leading-tight text-wine-dark">
          {tasting.title}
        </h2>
        {fullyBooked ? <span className="badge badge-full">Fully booked</span> : null}
      </div>

      <p className="mt-2 text-ink">
        <time dateTime={`${tasting.date}T${tasting.time}`}>{formatDateTime(tasting.date, tasting.time)}</time>
      </p>

      <dl className="mt-5 grid grid-cols-2 gap-4 border-t border-line pt-4 text-sm">
        <div>
          <dt className="text-muted">Price per guest</dt>
          <dd className="mt-0.5 font-semibold text-ink">{formatEur(tasting.priceCents)}</dd>
        </div>
        <div>
          <dt className="text-muted">Availability</dt>
          <dd
            className={`mt-0.5 font-semibold ${
              fullyBooked ? 'text-danger' : lowAvailability ? 'text-amber-800' : 'text-success'
            }`}
          >
            {formatSeatsLeft(tasting.seatsLeft)}
          </dd>
        </div>
      </dl>

      <div className="mt-auto pt-6">
        {fullyBooked ? (
          <p className="text-sm text-muted">No seats are left to book online for this tasting.</p>
        ) : (
          <Link to={`/tastings/${tasting.id}/book`} className="btn btn-primary w-full sm:w-auto">
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
