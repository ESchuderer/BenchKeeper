import { useMemo, useState } from 'react';
import { Link, useLoaderData, useNavigate, useRevalidator } from 'react-router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { api, ApiError } from '../api.js';
import { TextField } from '../components/TextField.js';
import { formatDateTime, formatEur, formatSeatsLeft } from '../../shared/format.js';
import { bookingFormSchemaFor, MAX_GUESTS, type BookingForm } from '../../shared/schemas.js';
import type { TastingView } from '../../shared/types.js';

type FieldName = keyof BookingForm;

export function BookingPage() {
  const tasting = useLoaderData() as TastingView;
  const navigate = useNavigate();
  const revalidator = useRevalidator();
  const [formError, setFormError] = useState<string | null>(null);

  const schema = useMemo(() => bookingFormSchemaFor(tasting.seatsLeft), [tasting.seatsLeft]);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { name: '', email: '', guests: '' },
  });

  const onSubmit = async (values: BookingForm) => {
    setFormError(null);
    try {
      const booking = await api.createBooking(tasting.id, values);
      navigate(`/bookings/${booking.reference}`);
    } catch (error) {
      if (error instanceof ApiError && Object.keys(error.fieldErrors).length > 0) {
        for (const [field, message] of Object.entries(error.fieldErrors)) {
          setError(field as FieldName, { type: 'server', message });
        }
        // The seat count may have changed, so refresh it for the next attempt.
        if (error.status === 409) revalidator.revalidate();
        return;
      }
      setFormError(error instanceof ApiError ? error.message : 'Something went wrong. Please try again.');
    }
  };

  if (tasting.seatsLeft === 0) {
    return (
      <article className="card max-w-2xl">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">{tasting.title}</p>
        <h1 className="mt-2 font-serif text-3xl text-wine-dark">Book {tasting.title}</h1>
        <p role="status" className="alert alert-info mt-6">
          This tasting is fully booked
        </p>
        <p className="mt-6">
          <Link to="/" className="link">
            Back to all tastings
          </Link>
        </p>
      </article>
    );
  }

  const hasErrors = Object.keys(errors).length > 0;

  return (
    <div className="grid gap-10 md:grid-cols-[1fr_1.1fr]">
      <section aria-labelledby="tasting-summary" className="space-y-4">
        <Link to="/" className="link text-sm">
          Back to all tastings
        </Link>
        <p className="pt-2 text-sm font-semibold uppercase tracking-[0.18em] text-gold">Your tasting</p>
        <h1 id="tasting-summary" className="font-serif text-4xl leading-tight text-wine-dark">
          {tasting.title}
        </h1>
        <p className="text-lg text-ink">
          <time dateTime={`${tasting.date}T${tasting.time}`}>{formatDateTime(tasting.date, tasting.time)}</time>
        </p>
        <dl className="grid grid-cols-2 gap-4 border-t border-line pt-4 text-sm">
          <div>
            <dt className="text-muted">Price per guest</dt>
            <dd className="mt-0.5 font-semibold">{formatEur(tasting.priceCents)}</dd>
          </div>
          <div>
            <dt className="text-muted">Availability</dt>
            <dd className="mt-0.5 font-semibold text-success">{formatSeatsLeft(tasting.seatsLeft)}</dd>
          </div>
        </dl>
      </section>

      <section aria-labelledby="booking-form-title" className="card">
        <h2 id="booking-form-title" className="font-serif text-2xl text-wine-dark">
          Book your seats
        </h2>

        {hasErrors ? (
          <p role="alert" className="alert alert-error mt-4">
            Please check the highlighted fields.
          </p>
        ) : null}
        {formError ? (
          <p role="alert" className="alert alert-error mt-4">
            {formError}
          </p>
        ) : null}

        <form noValidate onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-5">
          <TextField
            id="name"
            label="Name"
            autoComplete="name"
            error={errors.name?.message}
            {...register('name')}
          />
          <TextField
            id="email"
            label="Email"
            type="email"
            inputMode="email"
            autoComplete="email"
            error={errors.email?.message}
            {...register('email')}
          />
          <TextField
            id="guests"
            label="Guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={MAX_GUESTS}
            step={1}
            hint={`1 to ${MAX_GUESTS} guests per booking`}
            error={errors.guests?.message}
            {...register('guests')}
          />

          <button type="submit" className="btn btn-primary w-full" disabled={isSubmitting} aria-busy={isSubmitting}>
            Book
          </button>
        </form>
      </section>
    </div>
  );
}
