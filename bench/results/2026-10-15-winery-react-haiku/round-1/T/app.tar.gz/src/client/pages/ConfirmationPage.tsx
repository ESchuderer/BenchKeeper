import { Link, useLoaderData } from 'react-router';
import { formatDateTime, formatEur } from '../../shared/format.js';
import type { BookingConfirmation } from '../../shared/types.js';

export function ConfirmationPage() {
  const booking = useLoaderData() as BookingConfirmation;

  return (
    <article className="mx-auto max-w-2xl">
      <div className="card">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Thank you</p>
        <h1 className="mt-2 font-serif text-4xl text-wine-dark">Booking confirmed</h1>
        <p className="mt-3 text-ink/80">Keep your booking reference for your visit.</p>

        <section aria-label="Booking details" className="mt-8 rounded-md border border-line bg-cream/60 p-5">
          <dl className="grid gap-5 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <dt className="text-sm text-muted">Tasting</dt>
              <dd className="mt-0.5 font-serif text-2xl text-wine-dark">{booking.title}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-sm text-muted">When</dt>
              <dd className="mt-0.5 font-medium">{formatDateTime(booking.date, booking.time)}</dd>
            </div>
            <div>
              <dt className="text-sm text-muted">Guests</dt>
              <dd className="mt-0.5 font-medium">{booking.guests}</dd>
            </div>
            <div>
              <dt className="text-sm text-muted">Total price</dt>
              <dd className="mt-0.5 font-medium">{formatEur(booking.totalCents)}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-sm text-muted">Booking reference</dt>
              <dd className="mt-0.5 font-mono text-xl font-semibold tracking-wider text-ink">{booking.reference}</dd>
            </div>
          </dl>
        </section>

        <p className="mt-8">
          <Link to="/" className="btn btn-secondary">
            Back to all tastings
          </Link>
        </p>
      </div>
    </article>
  );
}
