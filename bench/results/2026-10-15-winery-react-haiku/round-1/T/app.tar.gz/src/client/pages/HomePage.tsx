import { useLoaderData } from 'react-router';
import { TastingCard } from '../components/TastingCard.js';
import type { TastingView } from '../../shared/types.js';

export function HomePage() {
  const tastings = useLoaderData() as TastingView[];

  return (
    <>
      <section className="mb-10 max-w-2xl">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Tastings and cellar visits</p>
        <h1 className="mt-2 font-serif text-4xl leading-tight text-wine-dark sm:text-5xl">Upcoming tastings</h1>
        <p className="mt-4 text-lg text-ink/80">
          Pick a tasting, choose how many guests are coming and we will reserve your seats straight away.
        </p>
      </section>

      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {tastings.map((tasting) => (
          <li key={tasting.id} className="flex flex-col">
            <TastingCard tasting={tasting} />
          </li>
        ))}
      </ul>
    </>
  );
}
