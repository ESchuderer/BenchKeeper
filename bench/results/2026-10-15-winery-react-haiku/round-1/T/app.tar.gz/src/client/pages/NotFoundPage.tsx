import { Link } from 'react-router';

export function NotFoundPage() {
  return (
    <section className="mx-auto max-w-xl py-12 text-center">
      <h1 className="font-serif text-4xl text-wine-dark">Page not found</h1>
      <p className="mt-4 text-ink/80">The page or booking you are looking for does not exist.</p>
      <p className="mt-8">
        <Link to="/" className="btn btn-secondary">
          Back to all tastings
        </Link>
      </p>
    </section>
  );
}
