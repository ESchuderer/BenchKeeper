import { isRouteErrorResponse, useRouteError } from 'react-router';
import { NotFoundPage } from './NotFoundPage.js';

export function RouteError() {
  const error = useRouteError();
  if (isRouteErrorResponse(error) && error.status === 404) return <NotFoundPage />;

  return (
    <section role="alert" className="mx-auto max-w-xl py-12 text-center">
      <h1 className="font-serif text-4xl text-wine-dark">Something went wrong</h1>
      <p className="mt-4 text-ink/80">We could not load this page. Please try again in a moment.</p>
      <p className="mt-8">
        <button type="button" className="btn btn-secondary" onClick={() => window.location.reload()}>
          Try again
        </button>
      </p>
    </section>
  );
}
