import { useState } from 'react';
import { useLoaderData, useRevalidator } from 'react-router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { api, ApiError } from '../api.js';
import { TextField } from '../components/TextField.js';
import { formatDateTime } from '../../shared/format.js';
import { loginSchema, type LoginForm } from '../../shared/schemas.js';
import type { StaffTastingGroup } from '../../shared/types.js';

/** Loads the bookings if signed in. Signed out is a normal state, so it returns null rather than failing. */
export async function staffLoader(): Promise<StaffTastingGroup[] | null> {
  const { signedIn } = await api.staffSession();
  if (!signedIn) return null;
  try {
    return await api.staffBookings();
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) return null;
    throw error;
  }
}

export function StaffPage() {
  const groups = useLoaderData() as StaffTastingGroup[] | null;
  const revalidator = useRevalidator();
  const refresh = () => revalidator.revalidate();

  if (!groups) return <StaffSignIn onSignedIn={refresh} />;
  return <StaffBookings groups={groups} onChanged={refresh} />;
}

function StaffSignIn({ onSignedIn }: { onSignedIn: () => void }) {
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { password: '' },
  });

  const onSubmit = async (values: LoginForm) => {
    setFormError(null);
    try {
      await api.staffSignIn(values);
      onSignedIn();
    } catch (error) {
      if (error instanceof ApiError && error.fieldErrors.password) {
        setError('password', { type: 'server', message: error.fieldErrors.password });
        return;
      }
      setFormError(error instanceof ApiError ? error.message : 'Something went wrong. Please try again.');
    }
  };

  return (
    <section className="mx-auto max-w-md">
      <div className="card">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Staff only</p>
        <h1 className="mt-2 font-serif text-3xl text-wine-dark">Staff sign-in</h1>
        <p className="mt-2 text-sm text-muted">Enter the staff password to see the tasting bookings.</p>

        {formError ? (
          <p role="alert" className="alert alert-error mt-6">
            {formError}
          </p>
        ) : null}

        <form noValidate onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-5">
          <TextField
            id="password"
            label="Password"
            type="password"
            autoComplete="current-password"
            error={errors.password?.message}
            {...register('password')}
          />
          <button type="submit" className="btn btn-primary w-full" disabled={isSubmitting}>
            Sign in
          </button>
        </form>
      </div>
    </section>
  );
}

function StaffBookings({ groups, onChanged }: { groups: StaffTastingGroup[]; onChanged: () => void }) {
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState<string | null>(null);

  const signOut = async () => {
    await api.staffSignOut().catch(() => undefined);
    onChanged();
  };

  const cancel = async (reference: string) => {
    setCancelling(reference);
    setNotice(null);
    setError(null);
    try {
      await api.cancelBooking(reference);
      setNotice(`Booking ${reference} cancelled. Its seats are free again.`);
      onChanged();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'The booking could not be cancelled. Please try again.');
      if (err instanceof ApiError && err.status === 401) onChanged();
    } finally {
      setCancelling(null);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Staff only</p>
          <h1 className="mt-2 font-serif text-4xl text-wine-dark">Bookings</h1>
        </div>
        <button type="button" className="btn btn-secondary" onClick={signOut}>
          Sign out
        </button>
      </div>

      <div role="status" aria-live="polite">
        {notice ? <p className="alert alert-info">{notice}</p> : null}
      </div>
      {error ? (
        <p role="alert" className="alert alert-error">
          {error}
        </p>
      ) : null}

      {groups.map(({ tasting, bookings }) => {
        const headingId = `staff-${tasting.id}`;
        return (
          <section key={tasting.id} aria-labelledby={headingId} className="card overflow-hidden p-0">
            <header className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 border-b border-line bg-cream/50 px-5 py-4">
              <h2 id={headingId} className="font-serif text-2xl text-wine-dark">
                {tasting.title}
              </h2>
              <p className="text-sm text-muted">
                <time dateTime={`${tasting.date}T${tasting.time}`}>{formatDateTime(tasting.date, tasting.time)}</time>
                <span aria-hidden="true" className="mx-2 hidden sm:inline">
                  ·
                </span>
                <span className="block sm:inline">{`${tasting.seatsLeft} of ${tasting.seats} seats left`}</span>
              </p>
            </header>

            {bookings.length === 0 ? (
              <p className="px-5 py-6 text-sm text-muted">No bookings yet.</p>
            ) : (
              <div className="relative overflow-x-auto">
                <table className="w-full min-w-[32rem] text-left text-sm">
                  <caption className="sr-only">Bookings for {tasting.title}</caption>
                  <thead className="text-xs uppercase tracking-wider text-muted">
                    <tr>
                      <th scope="col" className="px-3 py-3 sm:px-5 font-semibold">
                        Name
                      </th>
                      <th scope="col" className="px-3 py-3 sm:px-5 font-semibold">
                        Email
                      </th>
                      <th scope="col" className="px-3 py-3 sm:px-5 font-semibold">
                        Guests
                      </th>
                      <th scope="col" className="px-3 py-3 sm:px-5 font-semibold">
                        Reference
                      </th>
                      <th scope="col" className="px-3 py-3 sm:px-5">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {bookings.map((booking) => (
                      <tr key={booking.reference}>
                        <td className="px-3 py-3 sm:px-5 font-medium text-ink">{booking.name}</td>
                        <td className="px-3 py-3 sm:px-5 break-all text-ink/85">{booking.email}</td>
                        <td className="px-3 py-3 sm:px-5">{booking.guests}</td>
                        <td className="px-3 py-3 sm:px-5 font-mono tracking-wide">{booking.reference}</td>
                        <td className="px-3 py-3 sm:px-5 text-right">
                          <button
                            type="button"
                            className="btn btn-secondary px-4 text-sm"
                            disabled={cancelling === booking.reference}
                            onClick={() => cancel(booking.reference)}
                          >
                            Cancel
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
