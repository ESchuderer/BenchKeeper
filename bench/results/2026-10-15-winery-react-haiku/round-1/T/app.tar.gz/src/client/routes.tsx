import type { RouteObject } from 'react-router';
import { Layout } from './components/Layout.js';
import { api, ApiError } from './api.js';
import { BookingPage } from './pages/BookingPage.js';
import { ConfirmationPage } from './pages/ConfirmationPage.js';
import { HomePage } from './pages/HomePage.js';
import { NotFoundPage } from './pages/NotFoundPage.js';
import { RouteError } from './pages/RouteError.js';
import { StaffPage, staffLoader } from './pages/StaffPage.js';

/** Turns a 404 from the API into a router 404 so the route error element can show a not-found page. */
async function notFoundAsRouteError<T>(load: () => Promise<T>): Promise<T> {
  try {
    return await load();
  } catch (error) {
    if (error instanceof ApiError && error.status === 404) throw new Response(null, { status: 404 });
    throw error;
  }
}

export const routes: RouteObject[] = [
  {
    path: '/',
    element: <Layout />,
    HydrateFallback: () => (
      <p className="py-12 text-center text-muted" role="status">
        Loading…
      </p>
    ),
    errorElement: (
      <Layout>
        <RouteError />
      </Layout>
    ),
    children: [
      {
        index: true,
        loader: () => api.listTastings(),
        element: <HomePage />,
      },
      {
        path: 'tastings/:tastingId/book',
        loader: ({ params }) => notFoundAsRouteError(() => api.getTasting(params.tastingId ?? '')),
        element: <BookingPage />,
      },
      {
        path: 'bookings/:reference',
        loader: ({ params }) => notFoundAsRouteError(() => api.getBooking(params.reference ?? '')),
        element: <ConfirmationPage />,
      },
      {
        path: 'staff',
        loader: staffLoader,
        element: <StaffPage />,
      },
      {
        path: '*',
        element: <NotFoundPage />,
      },
    ],
  },
];
