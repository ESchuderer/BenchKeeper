import path from 'node:path';
import express, { type NextFunction, type Request, type Response } from 'express';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { findTasting, TASTINGS } from '../shared/catalogue.js';
import { bookingFormSchema, loginSchema, MAX_GUESTS, seatsLeftMessage, toFieldErrors } from '../shared/schemas.js';
import type { StaffTastingGroup } from '../shared/types.js';
import type { BookingStore } from './store.js';
import { passwordMatches, SESSION_TTL_MS, STAFF_COOKIE, StaffSessions } from './staff-auth.js';
import { toConfirmation, toTastingView } from './views.js';

export interface AppOptions {
  store: BookingStore;
  /** Shared staff password. When unset, staff sign-in is refused. */
  staffPassword?: string | undefined;
  /** Directory holding the built React app. When set, it is served with a client-side route fallback. */
  staticDir?: string | undefined;
  /** Clock in milliseconds, injectable for tests. */
  now?: () => number;
}

const INVALID_FORM_MESSAGE = 'Please correct the highlighted fields.';
const GUESTS_RANGE_MESSAGE = `Enter a whole number of guests from 1 to ${MAX_GUESTS}`;

function cookieValue(req: Request, name: string): string | undefined {
  const value: unknown = req.cookies?.[name];
  return typeof value === 'string' ? value : undefined;
}

export function createApp({ store, staffPassword, staticDir, now = Date.now }: AppOptions) {
  const app = express();
  app.disable('x-powered-by');
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        // Plain-http deployments on a local network must not be upgraded to https.
        directives: { 'upgrade-insecure-requests': null },
      },
    }),
  );
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());
  // Staff data is personal: never let a browser or proxy cache it.
  app.use('/api/staff', (_req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    next();
  });

  const sessions = new StaffSessions(now, SESSION_TTL_MS);
  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    if (sessions.isValid(cookieValue(req, STAFF_COOKIE))) {
      next();
      return;
    }
    res.status(401).json({ message: 'Staff sign-in required' });
  };
  const signInLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 10,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    handler: (_req, res) => {
      res.status(429).json({ message: 'Too many sign-in attempts. Try again in 15 minutes.' });
    },
  });

  app.get('/api/tastings', (_req, res) => {
    res.json(TASTINGS.map((tasting) => toTastingView(tasting, store)));
  });

  app.get('/api/tastings/:id', (req, res) => {
    const tasting = findTasting(req.params.id);
    if (!tasting) {
      res.status(404).json({ message: 'Tasting not found' });
      return;
    }
    res.json(toTastingView(tasting, store));
  });

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const tasting = findTasting(req.params.id);
    if (!tasting) {
      res.status(404).json({ message: 'Tasting not found' });
      return;
    }

    const parsed = bookingFormSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(422).json({ message: INVALID_FORM_MESSAGE, errors: toFieldErrors(parsed.error) });
      return;
    }

    const result = store.reserve({ tastingId: tasting.id, ...parsed.data });
    if (result.ok) {
      res.status(201).json(toConfirmation(result.booking, tasting));
      return;
    }
    switch (result.reason) {
      case 'not-enough-seats':
        res
          .status(409)
          .json({ message: 'Not enough seats left.', errors: { guests: seatsLeftMessage(result.seatsLeft) } });
        return;
      case 'invalid-guests':
        res.status(422).json({ message: INVALID_FORM_MESSAGE, errors: { guests: GUESTS_RANGE_MESSAGE } });
        return;
      case 'unknown-tasting':
        res.status(404).json({ message: 'Tasting not found' });
        return;
    }
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const booking = store.get(req.params.reference);
    const tasting = booking && findTasting(booking.tastingId);
    if (!booking || !tasting) {
      res.status(404).json({ message: 'Booking not found' });
      return;
    }
    res.json(toConfirmation(booking, tasting));
  });

  app.get('/api/staff/session', (req, res) => {
    res.json({ signedIn: sessions.isValid(cookieValue(req, STAFF_COOKIE)) });
  });

  app.post('/api/staff/session', signInLimiter, (req, res) => {
    if (!staffPassword) {
      res.status(503).json({ message: 'Staff sign-in is not set up yet.' });
      return;
    }

    const parsed = loginSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(422).json({ message: 'Please enter the password.', errors: toFieldErrors(parsed.error) });
      return;
    }

    if (!passwordMatches(parsed.data.password, staffPassword)) {
      res.status(401).json({ message: 'Incorrect password', errors: { password: 'Incorrect password' } });
      return;
    }

    const token = sessions.create();
    res.cookie(STAFF_COOKIE, token, {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure,
      path: '/',
      maxAge: SESSION_TTL_MS,
    });
    res.status(204).end();
  });

  app.delete('/api/staff/session', (req, res) => {
    sessions.revoke(cookieValue(req, STAFF_COOKIE));
    res.clearCookie(STAFF_COOKIE, { httpOnly: true, sameSite: 'strict', secure: req.secure, path: '/' });
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    const all = store.list();
    const groups: StaffTastingGroup[] = TASTINGS.map((tasting) => ({
      tasting: toTastingView(tasting, store),
      bookings: all
        .filter((booking) => booking.tastingId === tasting.id)
        .map((booking) => ({
          reference: booking.reference,
          name: booking.name,
          email: booking.email,
          guests: booking.guests,
        })),
    }));
    res.json(groups);
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(String(req.params.reference))) {
      res.status(404).json({ message: 'Booking not found' });
      return;
    }
    res.status(204).end();
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ message: 'Not found' });
  });

  if (staticDir) {
    app.use(express.static(staticDir));
    // Any other GET serves the app shell so client-side routes such as /staff survive a reload.
    const indexFile = path.join(staticDir, 'index.html');
    app.use((req, res, next) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        next();
        return;
      }
      res.sendFile(indexFile, (err) => {
        if (err) next(err);
      });
    });
  }

  // Malformed JSON and unexpected failures never expose internals.
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof SyntaxError && 'body' in err) {
      res.status(400).json({ message: 'Request body is not valid JSON' });
      return;
    }
    console.error(err);
    res.status(500).json({ message: 'Something went wrong. Please try again.' });
  });

  return app;
}
