import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { BookingStore } from './store.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const clientDir = path.resolve(here, '../client');

function readPort(value: string | undefined): number {
  const port = value === undefined || value === '' ? 3000 : Number(value);
  if (!Number.isInteger(port) || port < 0 || port > 65535) {
    throw new Error(`PORT must be a whole number between 0 and 65535, got "${value}"`);
  }
  return port;
}

const port = readPort(process.env.PORT);
const staffPassword = process.env.STAFF_PASSWORD;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled until it is set.');
}

const hasClient = existsSync(path.join(clientDir, 'index.html'));
if (!hasClient) {
  console.warn('The web app has not been built (run "npm run build"); only the API is available.');
}

const app = createApp({
  store: new BookingStore(),
  staffPassword,
  staticDir: hasClient ? clientDir : undefined,
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
});
