import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const STAFF_COOKIE = 'kb_staff';
export const SESSION_TTL_MS = 8 * 60 * 60 * 1000;

/** Compares digests of both values, so the comparison takes the same time whatever the input. */
export function passwordMatches(candidate: string, expected: string): boolean {
  const candidateDigest = createHash('sha256').update(candidate, 'utf8').digest();
  const expectedDigest = createHash('sha256').update(expected, 'utf8').digest();
  return timingSafeEqual(candidateDigest, expectedDigest);
}

/** Random session tokens kept in memory, each valid for a fixed time. */
export class StaffSessions {
  private readonly expiresAt = new Map<string, number>();

  constructor(
    private readonly now: () => number = Date.now,
    private readonly ttlMs: number = SESSION_TTL_MS,
  ) {}

  create(): string {
    const token = randomBytes(32).toString('base64url');
    this.expiresAt.set(token, this.now() + this.ttlMs);
    return token;
  }

  isValid(token: string | undefined): boolean {
    if (!token) return false;
    const expires = this.expiresAt.get(token);
    if (expires === undefined) return false;
    if (this.now() >= expires) {
      this.expiresAt.delete(token);
      return false;
    }
    return true;
  }

  revoke(token: string | undefined): void {
    if (token) this.expiresAt.delete(token);
  }
}
