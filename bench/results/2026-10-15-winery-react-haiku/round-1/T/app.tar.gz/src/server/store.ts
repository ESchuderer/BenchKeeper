import { findTasting, type Tasting } from '../shared/catalogue.js';
import { generateReference } from './reference.js';

export interface NewBooking {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export interface StoredBooking extends NewBooking {
  reference: string;
  createdAt: Date;
}

export type ReserveResult =
  | { ok: true; booking: StoredBooking }
  | { ok: false; reason: 'unknown-tasting' }
  | { ok: false; reason: 'invalid-guests' }
  | { ok: false; reason: 'not-enough-seats'; seatsLeft: number };

/**
 * In-memory booking store. Every method is synchronous, so the seat check and
 * the insert in reserve() cannot interleave with another request.
 */
export class BookingStore {
  private readonly bookings = new Map<string, StoredBooking>();

  constructor(private readonly newReference: () => string = generateReference) {}

  guestsBooked(tastingId: string): number {
    let total = 0;
    for (const booking of this.bookings.values()) {
      if (booking.tastingId === tastingId) total += booking.guests;
    }
    return total;
  }

  seatsLeft(tasting: Tasting): number {
    return tasting.seats - this.guestsBooked(tasting.id);
  }

  reserve(input: NewBooking): ReserveResult {
    const tasting = findTasting(input.tastingId);
    if (!tasting) return { ok: false, reason: 'unknown-tasting' };
    if (!Number.isInteger(input.guests) || input.guests < 1) {
      return { ok: false, reason: 'invalid-guests' };
    }
    const left = this.seatsLeft(tasting);
    if (input.guests > left) return { ok: false, reason: 'not-enough-seats', seatsLeft: left };

    let reference: string;
    do {
      reference = this.newReference();
    } while (this.bookings.has(reference));

    const booking: StoredBooking = { ...input, reference, createdAt: new Date() };
    this.bookings.set(reference, booking);
    return { ok: true, booking };
  }

  get(reference: string): StoredBooking | undefined {
    return this.bookings.get(reference);
  }

  /** Removes a booking, freeing its seats. Returns false if it did not exist. */
  cancel(reference: string): boolean {
    return this.bookings.delete(reference);
  }

  list(): StoredBooking[] {
    return [...this.bookings.values()];
  }
}
