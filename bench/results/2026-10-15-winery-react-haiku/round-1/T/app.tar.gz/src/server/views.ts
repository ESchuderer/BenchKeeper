import type { Tasting } from '../shared/catalogue.js';
import type { BookingConfirmation, TastingView } from '../shared/types.js';
import type { BookingStore, StoredBooking } from './store.js';

export function toTastingView(tasting: Tasting, store: BookingStore): TastingView {
  return { ...tasting, seatsLeft: store.seatsLeft(tasting) };
}

export function toConfirmation(booking: StoredBooking, tasting: Tasting): BookingConfirmation {
  return {
    reference: booking.reference,
    tastingId: tasting.id,
    title: tasting.title,
    date: tasting.date,
    time: tasting.time,
    guests: booking.guests,
    priceCents: tasting.priceCents,
    totalCents: booking.guests * tasting.priceCents,
  };
}
