export interface Tasting {
  id: string;
  title: string;
  /** Local winery date, YYYY-MM-DD. */
  date: string;
  /** Local winery time, HH:mm. */
  time: string;
  /** Price per guest in euro cents. */
  priceCents: number;
  /** Total seats for the tasting. */
  seats: number;
}

export const TASTINGS: readonly Tasting[] = Object.freeze([
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    date: '2026-11-06',
    time: '18:00',
    priceCents: 2500,
    seats: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    date: '2026-11-14',
    time: '15:00',
    priceCents: 3200,
    seats: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    date: '2026-12-05',
    time: '17:00',
    priceCents: 2800,
    seats: 10,
  },
]);

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((tasting) => tasting.id === id);
}
