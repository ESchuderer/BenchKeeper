/** Price in euro cents to a display string, e.g. 2500 -> "EUR 25", 3250 -> "EUR 32.50". */
export function formatEur(cents: number): string {
  const euros = cents / 100;
  const whole = Number.isInteger(euros);
  const amount = euros.toLocaleString('en-GB', {
    minimumFractionDigits: whole ? 0 : 2,
    maximumFractionDigits: 2,
  });
  return `EUR ${amount}`;
}

export function formatSeatsLeft(count: number): string {
  return `${count} seats left`;
}

/** "2026-11-06" + "18:00" -> "Friday, 6 November 2026 at 18:00". Dates are not shifted by time zone. */
export function formatDateTime(date: string, time: string): string {
  const [year, month, day] = date.split('-').map(Number);
  const instant = new Date(Date.UTC(year, month - 1, day));
  const weekday = instant.toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
  const calendar = instant.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  });
  return `${weekday}, ${calendar} at ${time}`;
}
