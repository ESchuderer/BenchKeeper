import { z, type ZodError } from 'zod';

export const MAX_GUESTS = 8;

function toGuestCount(value: unknown): unknown {
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed === '' ? undefined : Number(trimmed);
  }
  return undefined;
}

export const bookingFormSchema = z.object({
  name: z
    .string({ error: 'Enter your name' })
    .trim()
    .min(1, 'Enter your name')
    .max(100, 'Name must be 100 characters or fewer'),
  email: z
    .string({ error: 'Enter your email address' })
    .trim()
    .min(1, 'Enter your email address')
    .max(254, 'Email must be 254 characters or fewer')
    .pipe(z.email({ error: 'Enter a valid email address' })),
  guests: z.preprocess(
    toGuestCount,
    z
      .number({ error: 'Enter the number of guests' })
      .int('Guests must be a whole number')
      .min(1, 'Choose at least 1 guest')
      .max(MAX_GUESTS, `Up to ${MAX_GUESTS} guests per booking`),
  ),
});

export type BookingForm = z.output<typeof bookingFormSchema>;

export function seatsLeftMessage(seatsLeft: number): string {
  if (seatsLeft === 0) return 'This tasting is fully booked';
  return `Only ${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left for this tasting`;
}

/** Adds the seats-left rule. Used by the client for immediate feedback; the server enforces it too. */
export function bookingFormSchemaFor(seatsLeft: number) {
  return bookingFormSchema.superRefine((data, ctx) => {
    if (data.guests > seatsLeft) {
      ctx.addIssue({
        code: 'custom',
        path: ['guests'],
        message: seatsLeftMessage(seatsLeft),
      });
    }
  });
}

export const loginSchema = z.object({
  password: z.string({ error: 'Enter the password' }).min(1, 'Enter the password'),
});

export type LoginForm = z.output<typeof loginSchema>;

/** First message per field, keyed by field name. */
export function toFieldErrors(error: ZodError): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? 'form');
    if (!(key in errors)) errors[key] = issue.message;
  }
  return errors;
}
