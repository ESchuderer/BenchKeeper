import type { Tasting } from './catalogue.js';

export interface TastingView extends Tasting {
  seatsLeft: number;
}

/** Public confirmation view. Contains no personal data beyond the guest count. */
export interface BookingConfirmation {
  reference: string;
  tastingId: string;
  title: string;
  date: string;
  time: string;
  guests: number;
  priceCents: number;
  totalCents: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTastingGroup {
  tasting: TastingView;
  bookings: StaffBooking[];
}

export interface ApiErrorBody {
  message?: string;
  errors?: Record<string, string>;
}
