# Implementation Plan: Weingut Kieselbrunnen Tasting Bookings

Source of truth: `SPEC.md`. This plan orders the work into vertical slices. Each slice is written test-first and leaves the app building and tested.

## Overview

One Node 22 process serves a JSON API under `/api` and the built React SPA for everything else. The booking store is in memory and seat checks run synchronously, so over-booking cannot race. Shared code (catalogue, zod schemas, formatting) is used by both client and server.

## Architecture Decisions

- **Single process, Express 5 serves API and static SPA.** One port (`PORT`), no CORS needed. Matches "`npm start` serves the whole app".
- **Vite for the client, tsc for the server.** Output in `dist/client` and `dist/server`.
- **zod schemas shared in `src/shared`.** Client uses them for inline UX errors; the server re-validates as the authority.
- **React Router data router** (`createBrowserRouter`) with a server-side SPA fallback.
- **react-hook-form + zodResolver** for the booking and sign-in forms. Server field errors are mapped back with `setError`.
- **In-memory store** (`Map` keyed by reference + catalogue), so `reserve` = check seats and insert in one synchronous call.
- **Staff session = random token in an in-memory map**, sent as an HttpOnly, SameSite=Strict cookie, 8h expiry. Password compared with `crypto.timingSafeEqual` on SHA-256 digests. Sign-in is rate-limited.
- **Tailwind 4** for styling with a small theme (wine, cream, gold) defined as CSS variables.
- **Test layers:** Vitest unit, Supertest API, RTL component tests (jsdom), Playwright e2e.

## Dependency Graph

```
catalogue + schemas + format (shared)
    ├── store (seats, reserve, cancel, reference)
    │      ├── API: tastings (GET)
    │      ├── API: bookings (POST, GET by ref)
    │      └── API: staff (session, list, cancel)
    └── client api.ts
           ├── Home page (tastings list)
           ├── Booking page (form)
           ├── Confirmation page
           └── Staff page
```

## Task List

### Phase 0: Foundation

- [x] **Task 1: Scaffold project and toolchain** (see `tasks/todo.md`)

### Checkpoint: Foundation
- [x] `npm install`, `npm run build`, `npm test`, `npm run typecheck`, `npm run lint` all run (tests may be empty but must pass)
- [x] `npm start` serves a placeholder page on `PORT`

### Phase 1: Catalogue

- [x] **Task 2: Tastings catalogue API** (GET list and GET one, with `seatsLeft`)

### Checkpoint: Catalogue
- [x] API tests pass; seat counts correct with no bookings

### Phase 2: Booking

- [x] **Task 3: Booking domain** (schemas, reference generator, reserve and cancel in store)
- [x] **Task 4: Booking API** (POST bookings with 422/409/404; GET confirmation by reference)

### Checkpoint: Booking
- [x] Over-booking is impossible through the API; API tests cover all error codes

### Phase 3: Guest UI

- [x] **Task 5: App shell, routing, design tokens, home page** (tasting cards with all states)
- [x] **Task 6: Booking page** (form, inline errors, server error mapping, success navigation)
- [x] **Task 7: Confirmation page** (`Booking confirmed`, reloadable by reference)

### Checkpoint: Guest flow
- [x] A guest can book and see confirmation in the browser; fully booked state verified

### Phase 4: Staff

- [x] **Task 8: Staff session API** (sign-in, sign-out, auth middleware, rate limit, fail-closed without password)
- [x] **Task 9: Staff bookings list and cancel API**
- [x] **Task 10: Staff page UI** (sign-in form, grouped list, cancel)

### Checkpoint: Staff flow
- [x] Cancelling frees seats visible on the start page

### Phase 5: Hardening, polish, verification

- [x] **Task 11: Security headers and production behaviour** (helmet, no stack traces, startup checks)
- [x] **Task 12: Responsive visual polish and states review** (320px, desktop)
- [x] **Task 13: Playwright end-to-end suite** (happy path, limits, staff flow, mobile)
- [x] **Task 14: final lint/typecheck/test/build/e2e** (README skipped; not requested)

### Checkpoint: Complete
- [x] All SPEC success criteria met
- [x] Code review pass completed and findings addressed

## Risks and Mitigations

| Risk | Impact | Mitigation |
|---|---|---|
| Playwright browser cannot be downloaded in the container | Medium: e2e not runnable | Try install early in Task 1; if it fails, use RTL + Supertest and a jsdom-level flow; report the gap |
| React Router / react-hook-form API differences in new major versions | Medium | Read the installed package README/types before writing code (source-driven-development) |
| Seat race between concurrent requests | High (over-booking) | Synchronous check+insert in one function; test with `Promise.all` burst |
| Staff password unset in production | High | Fail closed (503), warn at startup; tests cover it |
| Tailwind/Vite version drift breaks build | Low | Pin major versions in package.json; verify build after Task 1 |

## Open Questions

- See SPEC.md assumptions 2, 3, 4 (memory store, no payment, no email). Proceeding with these defaults; will be called out in the final summary.
