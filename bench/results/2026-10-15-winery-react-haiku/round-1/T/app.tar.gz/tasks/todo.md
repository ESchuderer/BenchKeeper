# Tasks: Weingut Kieselbrunnen Tasting Bookings

Source: `tasks/plan.md`, `SPEC.md`. Each task: acceptance criteria and verification. Check boxes when done.

## Task 1: Scaffold project and toolchain
- [x] `package.json` with Node 22 engine, scripts from SPEC "Commands"
- [x] TypeScript configs (`tsconfig.json` for client/typecheck, `tsconfig.server.json` for server build)
- [x] Vite client shell (`index.html`, `src/client/main.tsx`) and Tailwind 4 wired in
- [x] Vitest config (jsdom for `tests/client`), ESLint flat config, `.gitignore` (node_modules, dist, .env)
- [x] Placeholder server `src/server/index.ts` serving `dist/client` and `/api/health`
- Verify: `npm install && npm run build && npm test && npm run typecheck && npm run lint`; `PORT=3111 npm start` responds 200 on `/`
- Verify: Playwright browser availability checked (`npx playwright install chromium`)
- Files: package.json, tsconfig*.json, vite.config.ts, vitest.config.ts, eslint.config.js, index.html, src/**, .gitignore

## Task 2: Tastings catalogue API
- [x] `src/shared/catalogue.ts` with the three tastings (ids, title, date, time, priceCents, seats)
- [x] `GET /api/tastings` returns each tasting with `seatsLeft`; `GET /api/tastings/:id` 404 for unknown id
- Verify (tests first): `tests/server/tastings.test.ts` red then green
- Files: src/shared/catalogue.ts, src/server/app.ts, src/server/store.ts, tests/server/tastings.test.ts

## Task 3: Booking domain
- [x] `src/shared/schemas.ts`: booking schema (name required, trimmed, max 100; email valid, max 254; guests integer 1 to 8, accepts numeric string)
- [x] `src/server/store.ts`: `reserve` (rejects unknown tasting, too many guests, returns reference), `cancel`, `seatsLeft`, `listByTasting`
- [x] Reference generator `KB-XXXXXX` from crypto, unique within store
- [x] `src/shared/format.ts`: `formatEur(cents)`, `formatSeatsLeft(n)`, `formatDateTime(date, time)`
- Verify (tests first): `tests/shared/schemas.test.ts`, `tests/server/store.test.ts` (including 50 concurrent reserves for the last seat: exactly one succeeds)
- Files: src/shared/schemas.ts, src/shared/format.ts, src/server/store.ts, tests/shared/*.test.ts, tests/server/store.test.ts

## Task 4: Booking API
- [x] `POST /api/tastings/:id/bookings`: 201 with `{reference, tastingId, title, date, time, name, email, guests, totalCents}`; 422 `errors` per field; 409 `errors.guests` when short; 404 unknown tasting
- [x] `GET /api/bookings/:reference`: 200 public view without email; 404 unknown or cancelled
- [x] Malformed JSON gives 400 without stack trace
- Verify (tests first): `tests/server/bookings.test.ts` covering each status, seat exhaustion via API, and no email in public view
- Files: src/server/app.ts, src/server/errors.ts (error middleware), tests/server/bookings.test.ts

## Task 5: App shell, routing, home page
- [x] `src/client/router.tsx` routes: `/`, `/tastings/:id/book`, `/bookings/:reference`, `/staff`, `*` (not found)
- [x] `src/client/api.ts` typed fetch helpers with `ApiError` carrying status and field errors
- [x] Layout (header with winery name, nav, footer) and design tokens in `src/client/styles.css`
- [x] Home page lists tastings: title, date and time, price per guest, `<n> seats left`, `Book <title>` link; fully booked shows "Fully booked" and no active book link; loading and error states
- Verify (tests first): `tests/client/home.test.tsx`
- Files: src/client/**, tests/client/home.test.tsx

## Task 6: Booking page
- [x] Shows tasting title, date, time, price; seats left
- [x] Form: labels `Name`, `Email`, `Guests` (select or number 1 to 8), button `Book`; `noValidate`; inline errors via `aria-describedby`
- [x] Client check guests <= seatsLeft with message `Only N seats left for this tasting`
- [x] Server 422/409 errors mapped to the right field; on success navigate to `/bookings/:reference`
- [x] Fully booked tasting shows message and no form; unknown tasting shows not found
- Verify (tests first): `tests/client/booking-page.test.tsx`
- Files: src/client/pages/Booking.tsx, src/client/components/FormField.tsx, tests/client/booking-page.test.tsx

## Task 7: Confirmation page
- [x] `Booking confirmed` heading; tasting, date and time, guests, total price, reference
- [x] Not found state for unknown reference
- Verify (tests first): `tests/client/confirmation-page.test.tsx`
- Files: src/client/pages/Confirmation.tsx, tests/client/confirmation-page.test.tsx

### Checkpoint: Guest flow
- [x] Manual browser check of booking flow and fully booked state

## Task 8: Staff session API
- [x] `POST /api/staff/session`: 204 + cookie on match (SHA-256 digest + timingSafeEqual); 401 otherwise; 503 when `STAFF_PASSWORD` unset
- [x] Rate limit: 10 attempts per 15 minutes per IP on sign-in, 429 after
- [x] `DELETE /api/staff/session` clears session
- [x] `requireStaff` middleware: 401 without valid, unexpired session
- [x] Cookie: HttpOnly, SameSite=Strict, Path=/, Secure when request is HTTPS; token never logged
- Verify (tests first): `tests/server/staff-auth.test.ts`
- Files: src/server/staff-auth.ts, src/server/app.ts, tests/server/staff-auth.test.ts

## Task 9: Staff bookings list and cancel API
- [x] `GET /api/staff/bookings` (requireStaff): grouped by tasting with seats, seatsLeft, bookings with name, email, guests, reference
- [x] `DELETE /api/staff/bookings/:reference` (requireStaff): 204 and frees seats; 404 unknown
- Verify (tests first): `tests/server/staff-bookings.test.ts` including cancel then public seatsLeft increases
- Files: src/server/app.ts, tests/server/staff-bookings.test.ts

## Task 10: Staff page UI
- [x] Signed out: `Password` field, `Sign in` button, error `Incorrect password` next to the field; 503 shows configuration message
- [x] Signed in: grouped sections per tasting with table (Name, Email, Guests, Reference, action), `Cancel` button, empty state per tasting, `Sign out`
- [x] Session check on load via `GET /api/staff/bookings` (401 means signed out)
- Verify (tests first): `tests/client/staff-page.test.tsx`
- Files: src/client/pages/Staff.tsx, tests/client/staff-page.test.tsx

### Checkpoint: Staff flow
- [x] Cancel frees seats on the home page

## Task 11: Security headers and production behaviour
- [x] helmet with CSP `default-src 'self'`; `x-powered-by` disabled; `trust proxy` off by default
- [x] Startup logs a warning when `STAFF_PASSWORD` is unset; never logs the password
- [x] Global error handler returns generic JSON 500
- Verify: `tests/server/security.test.ts` (headers present, no stack in 500, staff 503 when unset)
- Files: src/server/app.ts, src/server/index.ts, tests/server/security.test.ts

## Task 12: Responsive visual polish and states
- [x] Review at 320px and 1280px in a browser; fix overflow, tap targets >= 44px
- [x] Coherent winery style: cream background, wine accents, serif headings, consistent spacing
- [x] Error, success, fully booked states have distinct, text-based indicators (not colour alone)
- Verify: browser screenshots reviewed (done). Automated axe scan NOT run: no axe package installed.

## Task 13: Playwright end-to-end suite
- [x] `e2e/guest-booking.spec.ts`: book, errors, seat limit, confirmation, fully booked
- [x] `e2e/staff.spec.ts`: wrong password, sign in, cancel frees seats
- [x] `e2e/mobile.spec.ts`: booking works at 375px width
- [x] Playwright config starts `npm start` with `STAFF_PASSWORD=test-pass` and `PORT=3123`
- Verify: `npm run test:e2e` green

## Task 14: README and final gates
- [ ] `README.md` skipped: the project rules do not allow unrequested docs. Run instructions are in the summary instead.
- [x] Final: `npm run build && npm test && npm run typecheck && npm run lint && npm run test:e2e`
- [x] Code review pass with `code-review-and-quality`; address findings
