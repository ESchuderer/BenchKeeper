// @vitest-environment jsdom
import { describe, it, expect, afterEach, vi } from 'vitest';
import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BookingStore } from '../../src/server/store.js';
import { createApp } from '../../src/server/app.js';
import { connectToApp, renderAt } from './helpers.js';

afterEach(() => {
  vi.unstubAllGlobals();
});

function start() {
  const store = new BookingStore();
  const app = createApp({ store, staffPassword: 'test-pass' });
  const { fetchSpy } = connectToApp(app);
  return { store, fetchSpy };
}

function bookingCalls(fetchSpy: ReturnType<typeof start>['fetchSpy']) {
  return fetchSpy.mock.calls.filter(([, init]) => init?.method === 'POST');
}

describe('booking page', () => {
  it('shows the tasting and a form with Name, Email and Guests fields and a Book button', async () => {
    start();
    renderAt('/tastings/riesling-evening/book');

    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByText('Friday, 6 November 2026 at 18:00')).toBeInTheDocument();
    expect(screen.getByText('EUR 25')).toBeInTheDocument();
    expect(screen.getByText('12 seats left')).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows errors next to each empty field and creates no booking', async () => {
    const user = userEvent.setup();
    const { store, fetchSpy } = start();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByLabelText('Name');

    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Enter your name')).toBeInTheDocument();
    expect(screen.getByText('Enter your email address')).toBeInTheDocument();
    expect(screen.getByText('Enter the number of guests')).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true');
    expect(bookingCalls(fetchSpy)).toHaveLength(0);
    expect(store.list()).toHaveLength(0);
  });

  it('links each error to its field so it is announced with the field', async () => {
    const user = userEvent.setup();
    start();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByLabelText('Email');

    await user.type(screen.getByLabelText('Email'), 'anna@');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    const emailField = screen.getByLabelText('Email');
    const error = await screen.findByText('Enter a valid email address');
    expect(emailField.getAttribute('aria-describedby')).toContain(error.id);
  });

  it('rejects a guest count above 8 with a message next to Guests', async () => {
    const user = userEvent.setup();
    start();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByLabelText('Guests');

    await user.type(screen.getByLabelText('Guests'), '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Up to 8 guests per booking')).toBeInTheDocument();
  });

  it('rejects a guest count of zero next to Guests', async () => {
    const user = userEvent.setup();
    start();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByLabelText('Guests');

    await user.type(screen.getByLabelText('Guests'), '0');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Choose at least 1 guest')).toBeInTheDocument();
  });

  it('does not send a booking that asks for more seats than are left', async () => {
    const user = userEvent.setup();
    const { store, fetchSpy } = start();
    store.reserve({ tastingId: 'winter-tasting', name: 'Other', email: 'o@example.com', guests: 8 });
    renderAt('/tastings/winter-tasting/book');
    await screen.findByText('2 seats left');

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.type(screen.getByLabelText('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Only 2 seats left for this tasting')).toBeInTheDocument();
    expect(bookingCalls(fetchSpy)).toHaveLength(0);
  });

  it('shows the server seat error next to Guests when seats ran out after the page loaded', async () => {
    const user = userEvent.setup();
    const { store } = start();
    renderAt('/tastings/winter-tasting/book');
    await screen.findByLabelText('Guests');
    // Another guest takes seats while this form is open.
    store.reserve({ tastingId: 'winter-tasting', name: 'Other', email: 'o@example.com', guests: 9 });

    await user.type(screen.getByLabelText('Name'), 'Anna Keller');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.type(screen.getByLabelText('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Only 1 seat left for this tasting')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAttribute('aria-invalid', 'true');
    expect(store.list()).toHaveLength(1);
  });

  it('shows the confirmation after a valid booking', async () => {
    const user = userEvent.setup();
    const { store } = start();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByLabelText('Name');

    await user.type(screen.getByLabelText('Name'), '  Anna Keller ');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const [booking] = store.list();
    expect(booking).toMatchObject({ name: 'Anna Keller', guests: 2 });
    expect(screen.getByText(booking.reference)).toBeInTheDocument();
  });

  it('tells the guest when the tasting is fully booked and offers no form', async () => {
    const { store } = start();
    store.reserve({ tastingId: 'winter-tasting', name: 'Other', email: 'o@example.com', guests: 10 });
    renderAt('/tastings/winter-tasting/book');

    expect(await screen.findByText('This tasting is fully booked')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).toBeNull();
    expect(screen.queryByLabelText('Name')).toBeNull();
  });

  it('shows a not found page for an unknown tasting', async () => {
    start();
    renderAt('/tastings/no-such-tasting/book');

    expect(await screen.findByRole('heading', { name: 'Page not found' })).toBeInTheDocument();
    await waitFor(() => expect(screen.queryByLabelText('Name')).toBeNull());
  });
});
