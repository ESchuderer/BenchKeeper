// @vitest-environment jsdom
import { describe, it, expect, afterEach, vi } from 'vitest';
import { screen, within } from '@testing-library/react';
import { BookingStore } from '../../src/server/store.js';
import { createApp } from '../../src/server/app.js';
import { connectToApp, renderAt } from './helpers.js';

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('confirmation page', () => {
  it('shows the heading, tasting, guests, total price and booking reference', async () => {
    const store = new BookingStore(() => 'KB-K7M2QX');
    connectToApp(createApp({ store, staffPassword: 'test-pass' }));
    store.reserve({ tastingId: 'red-wine-cellar-tour', name: 'Anna', email: 'anna@example.com', guests: 3 });
    renderAt('/bookings/KB-K7M2QX');

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const details = screen.getByRole('region', { name: 'Booking details' });
    expect(within(details).getByText('Red Wine Cellar Tour')).toBeInTheDocument();
    expect(within(details).getByText('Saturday, 14 November 2026 at 15:00')).toBeInTheDocument();
    expect(within(details).getByText('3')).toBeInTheDocument();
    expect(within(details).getByText('EUR 96')).toBeInTheDocument();
    expect(within(details).getByText('KB-K7M2QX')).toBeInTheDocument();
  });

  it('does not show the guest email', async () => {
    const store = new BookingStore(() => 'KB-K7M2QX');
    connectToApp(createApp({ store, staffPassword: 'test-pass' }));
    store.reserve({ tastingId: 'winter-tasting', name: 'Anna', email: 'anna@example.com', guests: 1 });
    renderAt('/bookings/KB-K7M2QX');

    await screen.findByRole('heading', { name: 'Booking confirmed' });
    expect(screen.queryByText('anna@example.com')).toBeNull();
  });

  it('shows a not found message for an unknown reference', async () => {
    connectToApp(createApp({ store: new BookingStore(), staffPassword: 'test-pass' }));
    renderAt('/bookings/KB-ZZZZZZ');

    expect(await screen.findByRole('heading', { name: 'Page not found' })).toBeInTheDocument();
    expect(screen.queryByText('Booking confirmed')).toBeNull();
  });
});
