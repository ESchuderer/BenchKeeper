import { render } from '@testing-library/react';
import { RouterProvider, createMemoryRouter } from 'react-router';
import request from 'supertest';
import { vi } from 'vitest';
import type { Express } from 'express';
import { routes } from '../../src/client/routes.js';

/**
 * Routes every fetch() call from the React app to the real Express app in-process.
 * Only the network hop is replaced; the API code and its responses are real.
 * Cookies are kept in a small jar so staff sign-in behaves like a browser.
 */
export function connectToApp(app: Express) {
  let cookieHeader = '';
  const fetchSpy = vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
    const url = new URL(typeof input === 'string' ? input : input.toString(), 'http://localhost');
    const method = (init?.method ?? 'GET').toLowerCase() as 'get' | 'post' | 'delete';
    let call = request(app)[method](url.pathname);
    if (cookieHeader) call = call.set('Cookie', cookieHeader);
    if (typeof init?.body === 'string') call = call.set('Content-Type', 'application/json').send(init.body);
    const res = await call;

    const setCookie = res.headers['set-cookie'] as unknown as string[] | undefined;
    if (setCookie?.length) {
      const [pair] = setCookie[0].split(';');
      const [name, ...rest] = pair.split('=');
      cookieHeader = rest.join('=') === '' ? '' : `${name}=${rest.join('=')}`;
    }

    const hasBody = res.status !== 204 && res.text !== '';
    return new Response(hasBody ? res.text : null, {
      status: res.status,
      headers: { 'content-type': 'application/json' },
    });
  });
  vi.stubGlobal('fetch', fetchSpy);
  return { fetchSpy };
}

export function renderAt(path: string) {
  const router = createMemoryRouter(routes, { initialEntries: [path] });
  render(<RouterProvider router={router} />);
  return router;
}
