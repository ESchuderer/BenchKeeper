// @vitest-environment jsdom
import { describe, it, expect, afterEach, vi } from 'vitest';
import { screen, within } from '@testing-library/react';
import { BookingStore } from '../../src/server/store.js';
import { createApp } from '../../src/server/app.js';
import { connectToApp, renderAt } from './helpers.js';

afterEach(() => {
  vi.unstubAllGlobals();
});

function start() {
  const store = new BookingStore();
  const app = createApp({ store, staffPassword: 'test-pass' });
  connectToApp(app);
  return { store, app };
}

describe('start page', () => {
  it('lists each tasting with title, date and time, price per guest and seats left', async () => {
    start();
    renderAt('/');

    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('article')!;
    expect(within(riesling).getByText('Friday, 6 November 2026 at 18:00')).toBeInTheDocument();
    expect(within(riesling).getByText('EUR 25')).toBeInTheDocument();
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument();

    const cellar = screen.getByRole('heading', { name: 'Red Wine Cellar Tour' }).closest('article')!;
    expect(within(cellar).getByText('Saturday, 14 November 2026 at 15:00')).toBeInTheDocument();
    expect(within(cellar).getByText('EUR 32')).toBeInTheDocument();
    expect(within(cellar).getByText('8 seats left')).toBeInTheDocument();

    const winter = screen.getByRole('heading', { name: 'Winter Tasting' }).closest('article')!;
    expect(within(winter).getByText('Saturday, 5 December 2026 at 17:00')).toBeInTheDocument();
    expect(within(winter).getByText('EUR 28')).toBeInTheDocument();
    expect(within(winter).getByText('10 seats left')).toBeInTheDocument();
  });

  it('gives each tasting a "Book <title>" link to its booking form', async () => {
    start();
    renderAt('/');

    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });

    expect(link).toHaveAttribute('href', '/tastings/riesling-evening/book');
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toBeInTheDocument();
  });

  it('shows seats left after bookings have been made', async () => {
    const { store } = start();
    store.reserve({ tastingId: 'riesling-evening', name: 'Anna', email: 'anna@example.com', guests: 5 });
    renderAt('/');

    expect(await screen.findByText('7 seats left')).toBeInTheDocument();
  });

  it('shows a fully booked tasting with no booking link', async () => {
    const { store } = start();
    store.reserve({ tastingId: 'red-wine-cellar-tour', name: 'Anna', email: 'anna@example.com', guests: 8 });
    renderAt('/');

    const cellar = (await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' })).closest('article')!;
    expect(within(cellar).getByText('Fully booked')).toBeInTheDocument();
    expect(within(cellar).getByText('0 seats left')).toBeInTheDocument();
    expect(within(cellar).queryByRole('link')).toBeNull();
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeNull();
  });
});
