// @vitest-environment jsdom
import { describe, it, expect, afterEach, vi } from 'vitest';
import { screen, within, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BookingStore } from '../../src/server/store.js';
import { createApp } from '../../src/server/app.js';
import { connectToApp, renderAt } from './helpers.js';

const PASSWORD = 'winery-pass';

afterEach(() => {
  vi.unstubAllGlobals();
});

function start(options: { configured?: boolean } = {}) {
  let count = 0;
  const store = new BookingStore(() => `KB-${String((count += 1)).padStart(6, 'A')}`);
  const staffPassword = options.configured === false ? undefined : PASSWORD;
  const app = createApp({ store, staffPassword });
  connectToApp(app);
  return { store };
}

async function signIn(user: ReturnType<typeof userEvent.setup>, password = PASSWORD) {
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
}

describe('staff sign-in', () => {
  it('asks for the password with a Password field and a Sign in button', async () => {
    start();
    renderAt('/staff');

    expect(await screen.findByRole('heading', { name: 'Staff sign-in' })).toBeInTheDocument();
    expect(screen.getByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });

  it('asks for the password when the field is left empty', async () => {
    const user = userEvent.setup();
    start();
    renderAt('/staff');
    await screen.findByLabelText('Password');

    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByText('Enter the password')).toBeInTheDocument();
  });

  it('shows "Incorrect password" next to the Password field and stays signed out', async () => {
    const user = userEvent.setup();
    start();
    renderAt('/staff');

    await signIn(user, 'wrong');

    const error = await screen.findByText('Incorrect password');
    expect(screen.getByLabelText('Password').getAttribute('aria-describedby')).toContain(error.id);
    expect(screen.queryByRole('heading', { name: 'Bookings' })).toBeNull();
  });

  it('explains when staff sign-in has not been configured', async () => {
    const user = userEvent.setup();
    start({ configured: false });
    renderAt('/staff');

    await signIn(user, 'anything');

    expect(await screen.findByText('Staff sign-in is not set up yet.')).toBeInTheDocument();
  });
});

describe('staff bookings', () => {
  it('shows every booking grouped by tasting with name, email, guests and reference', async () => {
    const user = userEvent.setup();
    const { store } = start();
    store.reserve({ tastingId: 'riesling-evening', name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
    store.reserve({ tastingId: 'winter-tasting', name: 'Ben Müller', email: 'ben@example.com', guests: 4 });
    renderAt('/staff');
    await signIn(user);

    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section')!;
    const rows = within(riesling).getAllByRole('row');
    expect(rows).toHaveLength(2); // header + one booking
    expect(within(rows[1]).getByText('Anna Keller')).toBeInTheDocument();
    expect(within(rows[1]).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(rows[1]).getByText('2')).toBeInTheDocument();
    expect(within(rows[1]).getByText(store.list()[0].reference)).toBeInTheDocument();

    const winter = screen.getByRole('heading', { name: 'Winter Tasting' }).closest('section')!;
    expect(within(winter).getByText('Ben Müller')).toBeInTheDocument();
    expect(within(winter).getByText('ben@example.com')).toBeInTheDocument();
  });

  it('shows an empty state for tastings with no bookings', async () => {
    const user = userEvent.setup();
    start();
    renderAt('/staff');
    await signIn(user);

    const cellar = (await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' })).closest('section')!;
    expect(within(cellar).getByText('No bookings yet.')).toBeInTheDocument();
  });

  it('cancels a booking, removes it from the list and frees its seats', async () => {
    const user = userEvent.setup();
    const { store } = start();
    const result = store.reserve({
      tastingId: 'red-wine-cellar-tour',
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: 8,
    });
    if (!result.ok) throw new Error('setup failed');
    renderAt('/staff');
    await signIn(user);

    const cellar = (await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' })).closest('section')!;
    expect(within(cellar).getByText('0 of 8 seats left')).toBeInTheDocument();

    await user.click(within(cellar).getByRole('button', { name: 'Cancel' }));

    await waitFor(() => expect(within(cellar).queryByText('Anna Keller')).toBeNull());
    expect(within(cellar).getByText('No bookings yet.')).toBeInTheDocument();
    expect(within(cellar).getByText('8 of 8 seats left')).toBeInTheDocument();
    expect(store.get(result.booking.reference)).toBeUndefined();
    expect(screen.getByRole('status')).toHaveTextContent(`Booking ${result.booking.reference} cancelled`);
  });

  it('signs out and returns to the sign-in form', async () => {
    const user = userEvent.setup();
    start();
    renderAt('/staff');
    await signIn(user);

    await user.click(await screen.findByRole('button', { name: 'Sign out' }));

    expect(await screen.findByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Riesling Evening' })).toBeNull();
  });
});
