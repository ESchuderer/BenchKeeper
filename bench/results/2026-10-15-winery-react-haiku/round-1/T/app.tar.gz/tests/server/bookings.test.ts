import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';

function setup() {
  const store = new BookingStore();
  const app = createApp({ store, staffPassword: 'test-pass' });
  return { app, store };
}

const anna = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

async function seatsLeft(app: ReturnType<typeof createApp>, id: string): Promise<number> {
  const res = await request(app).get(`/api/tastings/${id}`).expect(200);
  return res.body.seatsLeft;
}

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and returns the public confirmation with reference and total', async () => {
    const { app } = setup();

    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(anna).expect(201);

    expect(res.body).toEqual({
      reference: expect.stringMatching(/^KB-[A-HJ-NP-Z2-9]{6}$/),
      tastingId: 'riesling-evening',
      title: 'Riesling Evening',
      date: '2026-11-06',
      time: '18:00',
      guests: 2,
      priceCents: 2500,
      totalCents: 5000,
    });
    expect(await seatsLeft(app, 'riesling-evening')).toBe(10);
  });

  it('accepts the guest count as numeric text, as sent by an HTML form', async () => {
    const { app } = setup();

    const res = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ ...anna, guests: '3' })
      .expect(201);

    expect(res.body).toMatchObject({ guests: 3, totalCents: 8400 });
  });

  it('returns 422 with a message for each invalid field and stores nothing', async () => {
    const { app } = setup();

    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: '', email: 'not-an-email', guests: 9 })
      .expect(422);

    expect(res.body.message).toEqual(expect.any(String));
    expect(res.body.errors).toEqual({
      name: 'Enter your name',
      email: 'Enter a valid email address',
      guests: 'Up to 8 guests per booking',
    });
    expect(await seatsLeft(app, 'riesling-evening')).toBe(12);
  });

  it('returns 409 with a guests error when there are fewer seats left than guests', async () => {
    const { app, store } = setup();
    store.reserve({ tastingId: 'red-wine-cellar-tour', name: 'Other', email: 'o@example.com', guests: 6 });

    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...anna, guests: 3 })
      .expect(409);

    expect(res.body.errors).toEqual({ guests: 'Only 2 seats left for this tasting' });
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(2);
  });

  it('returns 409 saying the tasting is fully booked when no seats are left', async () => {
    const { app, store } = setup();
    store.reserve({ tastingId: 'winter-tasting', name: 'Other', email: 'o@example.com', guests: 8 });
    store.reserve({ tastingId: 'winter-tasting', name: 'Other', email: 'o@example.com', guests: 2 });

    const res = await request(app).post('/api/tastings/winter-tasting/bookings').send(anna).expect(409);

    expect(res.body.errors).toEqual({ guests: 'This tasting is fully booked' });
  });

  it('accepts a booking that uses exactly the seats left', async () => {
    const { app, store } = setup();
    store.reserve({ tastingId: 'winter-tasting', name: 'Other', email: 'o@example.com', guests: 8 });

    await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ ...anna, guests: 2 })
      .expect(201);

    expect(await seatsLeft(app, 'winter-tasting')).toBe(0);
  });

  it('never over-books when many guests book at the same time', async () => {
    const { app } = setup();

    const responses = await Promise.all(
      Array.from({ length: 25 }, (_, i) =>
        request(app)
          .post('/api/tastings/winter-tasting/bookings')
          .send({ name: `Guest ${i}`, email: `guest${i}@example.com`, guests: 1 }),
      ),
    );

    const statuses = responses.map((r) => r.status);
    expect(statuses.filter((s) => s === 201)).toHaveLength(10);
    expect(statuses.filter((s) => s === 409)).toHaveLength(15);
    expect(await seatsLeft(app, 'winter-tasting')).toBe(0);
  });

  it('returns 404 for an unknown tasting', async () => {
    const { app } = setup();

    const res = await request(app).post('/api/tastings/nope/bookings').send(anna).expect(404);

    expect(res.body).toEqual({ message: 'Tasting not found' });
  });

  it('returns 400 without internal details for a malformed JSON body', async () => {
    const { app } = setup();

    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ')
      .expect(400);

    expect(res.body).toEqual({ message: 'Request body is not valid JSON' });
    expect(JSON.stringify(res.body)).not.toMatch(/at |stack/i);
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the confirmation without the guest email', async () => {
    const { app } = setup();
    const created = await request(app).post('/api/tastings/riesling-evening/bookings').send(anna).expect(201);

    const res = await request(app).get(`/api/bookings/${created.body.reference}`).expect(200);

    expect(res.body).toEqual(created.body);
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
  });

  it('returns 404 for an unknown reference', async () => {
    const { app } = setup();

    const res = await request(app).get('/api/bookings/KB-ZZZZZZ').expect(404);

    expect(res.body).toEqual({ message: 'Booking not found' });
  });

  it('returns 404 once the booking has been cancelled', async () => {
    const { app, store } = setup();
    const created = await request(app).post('/api/tastings/riesling-evening/bookings').send(anna).expect(201);
    store.cancel(created.body.reference);

    await request(app).get(`/api/bookings/${created.body.reference}`).expect(404);
  });
});
