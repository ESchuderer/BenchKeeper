import { describe, it, expect, vi, afterEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';

afterEach(() => {
  vi.restoreAllMocks();
});

describe('security headers', () => {
  it('sends a Content-Security-Policy that only allows the app origin by default', async () => {
    const app = createApp({ store: new BookingStore(), staffPassword: 'x' });

    const res = await request(app).get('/api/tastings').expect(200);

    expect(res.headers['content-security-policy']).toMatch(/default-src 'self'/);
    expect(res.headers['content-security-policy']).toMatch(/object-src 'none'/);
  });

  it('does not ask browsers to upgrade http requests, so a plain-http LAN deployment still works', async () => {
    const app = createApp({ store: new BookingStore(), staffPassword: 'x' });

    const res = await request(app).get('/api/tastings').expect(200);

    expect(res.headers['content-security-policy']).not.toMatch(/upgrade-insecure-requests/);
  });

  it('sets anti-sniffing and framing protections and removes the framework banner', async () => {
    const app = createApp({ store: new BookingStore(), staffPassword: 'x' });

    const res = await request(app).get('/api/tastings').expect(200);

    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-frame-options']).toBe('SAMEORIGIN');
    expect(res.headers['referrer-policy']).toBe('no-referrer');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });

  it('marks staff responses as not cacheable', async () => {
    const app = createApp({ store: new BookingStore(), staffPassword: 'x' });

    const res = await request(app).get('/api/staff/bookings').expect(401);

    expect(res.headers['cache-control']).toBe('no-store');
  });
});

describe('unexpected failures', () => {
  it('returns a generic 500 without internal details or a stack trace', async () => {
    const store = new BookingStore();
    vi.spyOn(store, 'reserve').mockImplementation(() => {
      throw new Error('database password is hunter2');
    });
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    const app = createApp({ store, staffPassword: 'x' });

    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: 'Anna', email: 'anna@example.com', guests: 1 })
      .expect(500);

    expect(res.body).toEqual({ message: 'Something went wrong. Please try again.' });
    expect(JSON.stringify(res.body)).not.toContain('hunter2');
  });
});
