import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';
import { passwordMatches } from '../../src/server/staff-auth.js';

const PASSWORD = 'correct-horse-battery';

function setup(options: { staffPassword?: string | undefined; now?: () => number } = {}) {
  const store = new BookingStore();
  const app = createApp({ store, staffPassword: PASSWORD, ...options });
  return { app, store };
}

function sessionCookie(setCookie: string[] | string | undefined): string {
  const header = Array.isArray(setCookie) ? setCookie[0] : setCookie;
  if (!header) throw new Error('no cookie set');
  return header.split(';')[0];
}

async function signIn(app: ReturnType<typeof createApp>): Promise<string> {
  const res = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(204);
  return sessionCookie(res.headers['set-cookie'] as unknown as string[]);
}

describe('passwordMatches', () => {
  it('accepts the exact password only', () => {
    expect(passwordMatches(PASSWORD, PASSWORD)).toBe(true);
    expect(passwordMatches(PASSWORD + ' ', PASSWORD)).toBe(false);
    expect(passwordMatches('', PASSWORD)).toBe(false);
    expect(passwordMatches('correct-horse-batterx', PASSWORD)).toBe(false);
  });
});

describe('POST /api/staff/session', () => {
  it('signs in with the right password and sets a secure session cookie', async () => {
    const { app } = setup();

    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(204);

    const cookie = res.headers['set-cookie'] as unknown as string[];
    expect(cookie[0]).toMatch(/^kb_staff=[A-Za-z0-9_-]{32,}; Max-Age=28800; Path=\//);
    expect(cookie[0]).toMatch(/HttpOnly/);
    expect(cookie[0]).toMatch(/SameSite=Strict/);
  });

  it('rejects a wrong password with an error next to the password field and sets no cookie', async () => {
    const { app } = setup();

    const res = await request(app).post('/api/staff/session').send({ password: 'nope' }).expect(401);

    expect(res.body).toEqual({ message: 'Incorrect password', errors: { password: 'Incorrect password' } });
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('asks for the password when it is empty', async () => {
    const { app } = setup();

    const res = await request(app).post('/api/staff/session').send({ password: '' }).expect(422);

    expect(res.body.errors).toEqual({ password: 'Enter the password' });
  });

  it('refuses all sign-ins when STAFF_PASSWORD is not configured', async () => {
    const { app } = setup({ staffPassword: undefined });

    const res = await request(app).post('/api/staff/session').send({ password: '' }).expect(503);
    expect(res.body).toEqual({ message: 'Staff sign-in is not set up yet.' });

    await request(app).post('/api/staff/session').send({ password: 'anything' }).expect(503);
  });

  it('locks out further attempts after 10 tries in 15 minutes, even with the right password', async () => {
    const { app } = setup();
    for (let i = 0; i < 10; i += 1) {
      await request(app).post('/api/staff/session').send({ password: 'wrong' }).expect(401);
    }

    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(429);

    expect(res.body.message).toMatch(/too many sign-in attempts/i);
  });
});

describe('staff session lifetime', () => {
  it('ends the session after 8 hours', async () => {
    let now = Date.parse('2026-10-15T08:00:00Z');
    const { app } = setup({ now: () => now });
    const cookie = await signIn(app);
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);

    now += 8 * 60 * 60 * 1000;

    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(401);
  });
});

describe('staff authorisation', () => {
  it('returns 401 for staff routes without a session', async () => {
    const { app } = setup();

    const res = await request(app).get('/api/staff/bookings').expect(401);

    expect(res.body).toEqual({ message: 'Staff sign-in required' });
  });

  it('returns 401 for a made-up session cookie', async () => {
    const { app } = setup();

    await request(app).get('/api/staff/bookings').set('Cookie', 'kb_staff=forged-token').expect(401);
  });

  it('signs out, which ends the session and clears the cookie', async () => {
    const { app } = setup();
    const cookie = await signIn(app);

    const res = await request(app).delete('/api/staff/session').set('Cookie', cookie).expect(204);

    expect(res.headers['set-cookie'][0]).toMatch(/^kb_staff=;.*Expires=Thu, 01 Jan 1970/);
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(401);
  });
});

describe('GET /api/staff/session', () => {
  it('reports signed out without an error status, so visitors see no failed requests', async () => {
    const { app } = setup();

    const res = await request(app).get('/api/staff/session').expect(200);

    expect(res.body).toEqual({ signedIn: false });
  });

  it('reports signed in after sign-in and signed out after sign-out', async () => {
    const { app } = setup();
    const cookie = await signIn(app);

    const signedIn = await request(app).get('/api/staff/session').set('Cookie', cookie).expect(200);
    expect(signedIn.body).toEqual({ signedIn: true });

    await request(app).delete('/api/staff/session').set('Cookie', cookie).expect(204);
    const signedOut = await request(app).get('/api/staff/session').set('Cookie', cookie).expect(200);
    expect(signedOut.body).toEqual({ signedIn: false });
  });
});
