import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';

const PASSWORD = 'staff-pass';

function setup() {
  const store = new BookingStore();
  const app = createApp({ store, staffPassword: PASSWORD });
  return { app, store };
}

async function signedInCookie(app: ReturnType<typeof createApp>): Promise<string> {
  const res = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(204);
  const header = (res.headers['set-cookie'] as unknown as string[])[0];
  return header.split(';')[0];
}

describe('GET /api/staff/bookings', () => {
  it('groups all bookings by tasting, including tastings with no bookings', async () => {
    const { app, store } = setup();
    store.reserve({ tastingId: 'riesling-evening', name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
    store.reserve({ tastingId: 'riesling-evening', name: 'Ben Müller', email: 'ben@example.com', guests: 4 });
    const cookie = await signedInCookie(app);

    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);

    expect(res.body.map((group: { tasting: { id: string } }) => group.tasting.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    const [riesling, cellar] = res.body;
    expect(riesling.tasting).toMatchObject({ title: 'Riesling Evening', seats: 12, seatsLeft: 6 });
    expect(riesling.bookings).toEqual([
      { reference: expect.stringMatching(/^KB-/), name: 'Anna Keller', email: 'anna@example.com', guests: 2 },
      { reference: expect.stringMatching(/^KB-/), name: 'Ben Müller', email: 'ben@example.com', guests: 4 },
    ]);
    expect(cellar.bookings).toEqual([]);
  });
});

describe('DELETE /api/staff/bookings/:reference', () => {
  it('cancels the booking and frees its seats on the public tasting list', async () => {
    const { app, store } = setup();
    const created = store.reserve({
      tastingId: 'winter-tasting',
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: 10,
    });
    if (!created.ok) throw new Error('setup failed');
    const reference = created.booking.reference;
    const cookie = await signedInCookie(app);

    await request(app).delete(`/api/staff/bookings/${reference}`).set('Cookie', cookie).expect(204);

    const tasting = await request(app).get('/api/tastings/winter-tasting').expect(200);
    expect(tasting.body.seatsLeft).toBe(10);
    await request(app).get(`/api/bookings/${reference}`).expect(404);
  });

  it('lets a new guest book the seats that were freed', async () => {
    const { app, store } = setup();
    const created = store.reserve({ tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 10 });
    if (!created.ok) throw new Error('setup failed');
    const cookie = await signedInCookie(app);
    await request(app).delete(`/api/staff/bookings/${created.booking.reference}`).set('Cookie', cookie).expect(204);

    await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ name: 'Ben', email: 'ben@example.com', guests: 8 })
      .expect(201);
  });

  it('returns 404 for an unknown reference', async () => {
    const { app } = setup();
    const cookie = await signedInCookie(app);

    const res = await request(app).delete('/api/staff/bookings/KB-ZZZZZZ').set('Cookie', cookie).expect(404);

    expect(res.body).toEqual({ message: 'Booking not found' });
  });

  it('returns 401 and keeps the booking when not signed in', async () => {
    const { app, store } = setup();
    const created = store.reserve({ tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 1 });
    if (!created.ok) throw new Error('setup failed');

    await request(app).delete(`/api/staff/bookings/${created.booking.reference}`).expect(401);

    expect(store.get(created.booking.reference)).toBeDefined();
  });
});
