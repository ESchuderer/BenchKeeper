import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';

let staticDir: string;

beforeAll(() => {
  staticDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kb-client-'));
  fs.writeFileSync(path.join(staticDir, 'index.html'), '<!doctype html><div id="root"></div>');
  fs.mkdirSync(path.join(staticDir, 'assets'));
  fs.writeFileSync(path.join(staticDir, 'assets', 'app.js'), 'console.log("app")');
});

afterAll(() => {
  fs.rmSync(staticDir, { recursive: true, force: true });
});

function app() {
  return createApp({ store: new BookingStore(), staffPassword: 'test-pass', staticDir });
}

describe('serving the built client', () => {
  it('serves index.html at the root', async () => {
    const res = await request(app()).get('/').expect(200);
    expect(res.text).toContain('<div id="root">');
  });

  it('serves built assets as files', async () => {
    const res = await request(app()).get('/assets/app.js').expect(200);
    expect(res.text).toContain('console.log');
  });

  it('falls back to index.html for client-side routes such as /tastings/x/book', async () => {
    const res = await request(app()).get('/tastings/riesling-evening/book').expect(200);
    expect(res.text).toContain('<div id="root">');
  });

  it('keeps unknown API paths as JSON 404s instead of returning the page', async () => {
    const res = await request(app()).get('/api/does-not-exist').expect(404);
    expect(res.body).toEqual({ message: 'Not found' });
  });
});
