import { describe, it, expect } from 'vitest';
import { BookingStore } from '../../src/server/store.js';
import { generateReference } from '../../src/server/reference.js';
import { findTasting } from '../../src/shared/catalogue.js';

const riesling = { tastingId: 'riesling-evening', name: 'Anna Keller', email: 'anna@example.com' };

describe('BookingStore.reserve', () => {
  it('allows booking exactly the seats that are left', () => {
    const store = new BookingStore();
    const first = store.reserve({ ...riesling, guests: 12 });
    expect(first.ok).toBe(true);
    expect(store.seatsLeft(findTasting('riesling-evening')!)).toBe(0);
  });

  it('rejects a booking that is larger than the seats left and reports how many are left', () => {
    const store = new BookingStore();
    store.reserve({ ...riesling, guests: 10 });

    const result = store.reserve({ ...riesling, guests: 3 });

    expect(result).toEqual({ ok: false, reason: 'not-enough-seats', seatsLeft: 2 });
    expect(store.list()).toHaveLength(1);
  });

  it('rejects an unknown tasting without storing anything', () => {
    const store = new BookingStore();

    const result = store.reserve({ ...riesling, tastingId: 'nope', guests: 1 });

    expect(result).toEqual({ ok: false, reason: 'unknown-tasting' });
    expect(store.list()).toHaveLength(0);
  });

  it('rejects zero and fractional guest counts', () => {
    const store = new BookingStore();
    expect(store.reserve({ ...riesling, guests: 0 })).toEqual({ ok: false, reason: 'invalid-guests' });
    expect(store.reserve({ ...riesling, guests: 1.5 })).toEqual({ ok: false, reason: 'invalid-guests' });
  });

  it('gives each booking a reference in the KB-XXXXXX format', () => {
    const store = new BookingStore();
    const result = store.reserve({ ...riesling, guests: 2 });

    expect(result.ok && result.booking.reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
  });

  it('never reuses a reference that is already taken', () => {
    const sequence = ['KB-AAAAAA', 'KB-AAAAAA', 'KB-BBBBBB'];
    const store = new BookingStore(() => sequence.shift()!);

    const first = store.reserve({ ...riesling, guests: 1 });
    const second = store.reserve({ ...riesling, guests: 1 });

    expect(first.ok && first.booking.reference).toBe('KB-AAAAAA');
    expect(second.ok && second.booking.reference).toBe('KB-BBBBBB');
  });
});

describe('BookingStore.cancel', () => {
  it('removes the booking and frees its seats', () => {
    const store = new BookingStore();
    const result = store.reserve({ ...riesling, guests: 12 });
    if (!result.ok) throw new Error('setup failed');

    expect(store.cancel(result.booking.reference)).toBe(true);

    expect(store.seatsLeft(findTasting('riesling-evening')!)).toBe(12);
    expect(store.get(result.booking.reference)).toBeUndefined();
  });

  it('returns false for an unknown reference', () => {
    expect(new BookingStore().cancel('KB-ZZZZZZ')).toBe(false);
  });
});

describe('generateReference', () => {
  it('produces readable references without look-alike characters', () => {
    for (let i = 0; i < 200; i += 1) {
      expect(generateReference()).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
    }
  });
});
