import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { BookingStore } from '../../src/server/store.js';

function setup() {
  const store = new BookingStore();
  const app = createApp({ store, staffPassword: 'test-pass' });
  return { app, store };
}

describe('GET /api/tastings', () => {
  it('lists the three tastings with title, date, time, price per guest and seats', async () => {
    const { app } = setup();

    const res = await request(app).get('/api/tastings').expect(200);

    expect(res.body).toEqual([
      {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        date: '2026-11-06',
        time: '18:00',
        priceCents: 2500,
        seats: 12,
        seatsLeft: 12,
      },
      {
        id: 'red-wine-cellar-tour',
        title: 'Red Wine Cellar Tour',
        date: '2026-11-14',
        time: '15:00',
        priceCents: 3200,
        seats: 8,
        seatsLeft: 8,
      },
      {
        id: 'winter-tasting',
        title: 'Winter Tasting',
        date: '2026-12-05',
        time: '17:00',
        priceCents: 2800,
        seats: 10,
        seatsLeft: 10,
      },
    ]);
  });

  it('reports seats left as seats minus the guests already booked', async () => {
    const { app, store } = setup();
    store.reserve({ tastingId: 'riesling-evening', name: 'Anna', email: 'anna@example.com', guests: 5 });

    const res = await request(app).get('/api/tastings').expect(200);

    const riesling = res.body.find((t: { id: string }) => t.id === 'riesling-evening');
    expect(riesling.seatsLeft).toBe(7);
  });
});

describe('GET /api/tastings/:id', () => {
  it('returns one tasting with seatsLeft', async () => {
    const { app } = setup();

    const res = await request(app).get('/api/tastings/winter-tasting').expect(200);

    expect(res.body).toMatchObject({ id: 'winter-tasting', title: 'Winter Tasting', seatsLeft: 10 });
  });

  it('returns 404 with a message for an unknown tasting', async () => {
    const { app } = setup();

    const res = await request(app).get('/api/tastings/no-such-tasting').expect(404);

    expect(res.body).toEqual({ message: 'Tasting not found' });
  });
});
