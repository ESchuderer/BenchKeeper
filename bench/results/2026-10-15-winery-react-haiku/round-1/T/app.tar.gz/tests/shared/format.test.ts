import { describe, it, expect } from 'vitest';
import { formatDateTime, formatEur, formatSeatsLeft } from '../../src/shared/format.js';

describe('formatEur', () => {
  it('shows whole euros without cents', () => {
    expect(formatEur(2500)).toBe('EUR 25');
  });

  it('shows cents when they are needed', () => {
    expect(formatEur(3250)).toBe('EUR 32.50');
  });

  it('groups thousands', () => {
    expect(formatEur(256000)).toBe('EUR 2,560');
  });
});

describe('formatSeatsLeft', () => {
  it('uses the wording from the brief, including for zero and one', () => {
    expect(formatSeatsLeft(7)).toBe('7 seats left');
    expect(formatSeatsLeft(0)).toBe('0 seats left');
    expect(formatSeatsLeft(1)).toBe('1 seats left');
  });
});

describe('formatDateTime', () => {
  it('formats the date with weekday and the time, without time zone shifts', () => {
    expect(formatDateTime('2026-11-06', '18:00')).toBe('Friday, 6 November 2026 at 18:00');
  });
});
