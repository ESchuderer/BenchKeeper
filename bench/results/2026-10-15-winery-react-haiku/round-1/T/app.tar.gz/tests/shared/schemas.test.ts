import { describe, it, expect } from 'vitest';
import { bookingFormSchema, bookingFormSchemaFor, loginSchema, toFieldErrors } from '../../src/shared/schemas.js';

const valid = { name: '  Anna Keller ', email: ' anna@example.com ', guests: '2' };

function errorFor(input: unknown, field: string, schema = bookingFormSchema): string | undefined {
  const result = schema.safeParse(input);
  if (result.success) return undefined;
  return toFieldErrors(result.error)[field];
}

describe('bookingFormSchema', () => {
  it('accepts valid input, trims name and email and converts guests to a number', () => {
    const result = bookingFormSchema.parse(valid);

    expect(result).toEqual({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
  });

  it('requires a name', () => {
    expect(errorFor({ ...valid, name: '   ' }, 'name')).toBe('Enter your name');
  });

  it('limits the name to 100 characters', () => {
    expect(errorFor({ ...valid, name: 'a'.repeat(101) }, 'name')).toBe('Name must be 100 characters or fewer');
  });

  it('requires an email address', () => {
    expect(errorFor({ ...valid, email: '' }, 'email')).toBe('Enter your email address');
  });

  it('rejects an email address that is not valid', () => {
    expect(errorFor({ ...valid, email: 'anna@' }, 'email')).toBe('Enter a valid email address');
  });

  it('accepts guest counts from 1 to 8 given as numbers or numeric text', () => {
    expect(bookingFormSchema.parse({ ...valid, guests: 1 }).guests).toBe(1);
    expect(bookingFormSchema.parse({ ...valid, guests: '8' }).guests).toBe(8);
  });

  it('rejects zero guests', () => {
    expect(errorFor({ ...valid, guests: '0' }, 'guests')).toBe('Choose at least 1 guest');
  });

  it('rejects more than eight guests', () => {
    expect(errorFor({ ...valid, guests: 9 }, 'guests')).toBe('Up to 8 guests per booking');
  });

  it('rejects fractional guest counts', () => {
    expect(errorFor({ ...valid, guests: '2.5' }, 'guests')).toBe('Guests must be a whole number');
  });

  it('asks for the guest count when it is empty or not a number', () => {
    expect(errorFor({ ...valid, guests: '' }, 'guests')).toBe('Enter the number of guests');
    expect(errorFor({ ...valid, guests: 'two' }, 'guests')).toBe('Enter the number of guests');
  });
});

describe('bookingFormSchemaFor(seatsLeft)', () => {
  it('rejects more guests than seats left, with the seat count in the message', () => {
    const schema = bookingFormSchemaFor(2);
    expect(errorFor({ ...valid, guests: 3 }, 'guests', schema)).toBe('Only 2 seats left for this tasting');
  });

  it('accepts exactly the seats left', () => {
    const schema = bookingFormSchemaFor(2);
    expect(schema.safeParse({ ...valid, guests: 2 }).success).toBe(true);
  });
});

describe('loginSchema', () => {
  it('requires a password', () => {
    const result = loginSchema.safeParse({ password: '' });
    expect(result.success).toBe(false);
    expect(!result.success && toFieldErrors(result.error).password).toBe('Enter the password');
  });
});
