# Design

## Context

The project is empty apart from its OpenSpec setup. The app is small and single-tenant: three tastings, a few hundred guests at most, one staff password. It runs as one Node.js 22 process started with `npm start` and must not depend on external services. See proposal.md for motivation and specs/ for the requirements.

## Goals / Non-Goals

**Goals:**
- One process serves the React interface and a JSON API on `PORT` (default 3000).
- Seat counting cannot oversell, including under simultaneous requests.
- Validation rules are written once and enforced both in the browser and on the server.
- Staff access is fail-closed when `STAFF_PASSWORD` is missing.

**Non-Goals:**
- Persistence across restarts (bookings start empty each time the process starts).
- Guest accounts, payments, email confirmations, or editing a booking.
- Multiple server instances or horizontal scaling.
- Server-side rendering or search-engine optimisation of the guest pages.
- Cancelled bookings kept as history: a cancelled booking is removed.

## Decisions

**Server: Express 5 serving a built React single-page app.** Express 5 is the mature default for Node HTTP servers, and it serves the static build and a JSON API from one process. Alternatives considered: Fastify (similar, but no advantage for this size), Next.js or React Router framework mode (server rendering that the spec does not need, and a heavier build and runtime).

**Client: React with Vite, React Router, React Hook Form, Zod.** Vite gives a fast production build to static files. React Router provides the routes `/`, `/book/:tastingId`, `/bookings/:reference` and `/staff`. React Hook Form handles field state, focus on error, and per-field errors with low re-render cost. Zod defines the validation rules once.

**Shared validation and catalogue in `src/shared`.** The Zod booking schema and the tasting catalogue live in one module imported by the client and the server. The server still validates every request (the browser check is only a convenience), and the seat check is done on the server only, because it needs current state.

**Styling: Tailwind CSS v4 with its Vite plugin.** Utility classes keep the design consistent across pages and make the responsive layout explicit. No external fonts or CDN assets: headings use a serif system stack (Georgia, "Iowan Old Style") and body text a sans-serif stack, so the app depends on nothing outside the server. Colour palette: cream background, bordeaux primary, muted green for success, and a red-brown error colour with an icon and text, never colour alone.

**Storage: in-memory store with a synchronous reserve operation.** Node runs JavaScript on one thread, so a booking check and insert done in one synchronous function cannot interleave with another request. This makes the "never exceed the seats left" rule hold without locks. Alternative considered: a JSON file. It would persist bookings across restarts, but the spec says the app starts with no bookings, and a file needs write locking and atomic replacement for little gain at this scale. The trade-off is that a restart clears all bookings; this is acceptable for the current scope and is stated in proposal.md.

**Booking references: `KB-` plus six characters from an unambiguous alphabet, from `crypto.randomBytes`.** Six characters from a 31-character alphabet give about 887 million values; collisions are checked against existing bookings and regenerated. Opaque references stop guests from guessing others' bookings.

**Staff authentication.** The password is compared in constant time by hashing both values with SHA-256 and using `crypto.timingSafeEqual`. A successful sign-in issues a random 256-bit session token, held in memory with an 8-hour expiry, sent as an `HttpOnly`, `SameSite=Strict` cookie. Sign-in attempts are rate-limited with `express-rate-limit` (10 failures per 15 minutes per client). If `STAFF_PASSWORD` is unset or empty, sign-in returns 503 and no session is issued. Cross-site request forgery is covered by `SameSite=Strict` plus the API accepting only JSON bodies for mutations. The `Secure` cookie attribute is not set, because the app is also served over plain HTTP on a local network; deploy behind HTTPS and add `Secure` there (see Migration Plan).

**Headers.** `helmet` sets the standard security headers, with a Content Security Policy that allows only same-origin scripts and styles. Staff API responses use `Cache-Control: no-store`. `/staff` is sent with `X-Robots-Tag: noindex`.

**Money and dates.** Prices are whole euros; the total is `guests × pricePerGuest` and is shown as "EUR n". Tasting dates and times are stored as text (`2026-11-06`, `18:00`) and formatted with `Intl` in UTC, so no time-zone shift is possible.

**Routing and API.**
- `GET /api/tastings`: catalogue with `seatsLeft`.
- `POST /api/tastings/:id/bookings`: body `{ name, email, guests }`; returns 201 with the booking, 400 with `fieldErrors`, 404 for an unknown tasting, 409 when the tasting is fully booked.
- `GET /api/bookings/:reference`: confirmation view without the guest's email.
- `POST /api/staff/session`, `DELETE /api/staff/session`, `GET /api/staff/session`.
- `GET /api/staff/bookings` (grouped by tasting), `DELETE /api/staff/bookings/:reference`.
- Any other GET serves the React app, so client routes survive a reload.

**Build and run.** `npm run build` runs `vite build` (to `dist/client`) and `tsc` for the server (to `dist/server`). `npm start` runs `node dist/server/index.js`. Tests run with Vitest: the server with Supertest, the React components with React Testing Library in jsdom, and a browser run of the main flows.

## Risks / Trade-offs

- **Restart loses bookings** → Acceptable per the spec; stated in the proposal. Revisit with a file-backed store if the business needs persistence.
- **Single process only** → The in-memory seat check is only correct inside one process. Mitigation: document it; any future multi-instance deployment needs a shared store with an atomic reserve.
- **Staff password is a shared secret with no per-person accounts** → Mitigation: rate limiting, constant-time comparison, short session, `no-store`. Per-person accounts are out of scope.
- **No `Secure` cookie flag** → Mitigation: deploy behind HTTPS and set the flag there (see Migration Plan).
- **Fully booked and seat counts can be stale in the browser** → The server re-checks at booking time and returns 409 or a field error, so the guest is never charged for seats that are not available.

## Migration Plan

Not applicable: this is a new application with no existing data. Deployment is `npm install`, `npm run build`, then `STAFF_PASSWORD=... PORT=... npm start`. Rollback is stopping the process and starting the previous build; no state is kept on disk.
