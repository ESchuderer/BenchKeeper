# Proposal

## Why

Weingut Kieselbrunnen takes tasting bookings by hand. Guests cannot see seats left or book online, and staff have no single view of who is coming. A small web app that lists the three upcoming tastings, takes bookings against the real seat count, and gives staff a password-protected list with cancellation solves both problems for the next tasting season.

## What Changes

- Add a public start page that lists the three tastings (title, date and time, price per guest, seats left or "Fully booked").
- Add a booking form per tasting ("Book <tasting title>") with Name, Email and Guests (1 to 8). Invalid input is rejected with field-level error messages. A booking never takes more seats than are left.
- Add a booking confirmation page with the heading "Booking confirmed", tasting, number of guests, total price and booking reference.
- Add a staff area at `/staff`: password sign-in (`STAFF_PASSWORD` environment variable), a list of all bookings grouped by tasting, and a "Cancel" action that frees the booking's seats.
- Bookings are held in memory. The app starts with no bookings and forgets them on restart. No external services are used.
- Interface is in English, styled as a small winery's site, and usable on a phone.

No **BREAKING** changes: this is a new application.

## Capabilities

### New Capabilities

- `tasting-catalog`: The fixed list of tastings offered, their date, time, price per guest and seats, and the derived seats-left or fully-booked state shown to guests.
- `guest-booking`: Guest booking of seats for one tasting: form fields and validation, the seat limit, the booking reference, and the confirmation view.
- `staff-bookings`: Staff sign-in with a shared password, the grouped list of bookings per tasting, and cancellation that frees seats.

### Modified Capabilities

None. `openspec/specs/` is empty, so there are no existing capabilities to change.

## Impact

- New application code: a Node.js 22 server (Express) with a JSON API, and a React single-page client (React Router, React Hook Form with Zod validation, Tailwind CSS).
- New environment variables: `PORT` (default 3000), `STAFF_PASSWORD` (required for staff sign-in; when unset, staff sign-in is disabled).
- No database, no external services, no migrations. Data lives in process memory.
- Scripts: `npm install`, `npm run build`, `npm start`, plus `npm test`.
