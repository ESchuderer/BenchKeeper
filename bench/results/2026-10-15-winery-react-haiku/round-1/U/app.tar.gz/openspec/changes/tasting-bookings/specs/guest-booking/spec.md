## Purpose

Lets a guest reserve seats for one tasting through an online form, never beyond the seats left, and shows a confirmation with a booking reference that the guest can keep.

## ADDED Requirements

### Requirement: Booking form fields
The booking form for a tasting SHALL have the fields "Name", "Email" and "Guests", each with a visible label, and a button labelled "Book". The Guests field SHALL accept whole numbers from 1 to 8.

#### Scenario: Form shows the required fields
- **WHEN** a guest opens the booking form for Riesling Evening
- **THEN** the form shows fields labelled "Name", "Email" and "Guests"
- **AND** the form shows a button labelled "Book"
- **AND** the page heading names the tasting, Riesling Evening

### Requirement: Invalid input is rejected next to its field
The booking form SHALL reject invalid input and show an error message next to the field it concerns. Name SHALL be required and at most 100 characters. Email SHALL be required and SHALL be a syntactically valid email address. Guests SHALL be a whole number from 1 to 8. The booking SHALL NOT be created while any field is invalid.

#### Scenario: Empty name
- **WHEN** a guest submits the form with the Name field empty
- **THEN** an error message is shown next to the Name field
- **AND** no booking is created

#### Scenario: Invalid email address
- **WHEN** a guest enters "anna@example" in the Email field and submits
- **THEN** an error message is shown next to the Email field
- **AND** no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest enters 0 or 9 in the Guests field and submits
- **THEN** an error message is shown next to the Guests field
- **AND** no booking is created

#### Scenario: Guests not a whole number
- **WHEN** a guest enters 2.5 in the Guests field and submits
- **THEN** an error message is shown next to the Guests field
- **AND** no booking is created

#### Scenario: Errors are also enforced by the server
- **WHEN** a request to create a booking contains an empty name, an invalid email or guests outside 1 to 8
- **THEN** the server responds with status 400
- **AND** the response identifies each invalid field with its error message
- **AND** no booking is created

### Requirement: A booking never exceeds the seats left
A booking SHALL be accepted only if the requested number of guests is no more than the seats left for that tasting at the moment the booking is made. When the request exceeds the seats left, the booking SHALL be rejected with an error shown next to the Guests field stating how many seats are left, and no seats SHALL be taken. Concurrent booking requests SHALL NOT together take more seats than are left.

#### Scenario: Booking within the seats left
- **WHEN** 3 seats are left for Winter Tasting and a guest books 3 guests
- **THEN** the booking is created
- **AND** Winter Tasting has 0 seats left afterwards

#### Scenario: Booking more than the seats left
- **WHEN** 2 seats are left for Winter Tasting and a guest books 3 guests
- **THEN** the booking is rejected
- **AND** an error next to the Guests field says that only 2 seats are left
- **AND** the number of seats left does not change

#### Scenario: Booking a fully booked tasting
- **WHEN** a guest opens the booking form for a tasting with no seats left
- **THEN** the form is not shown and the page states that the tasting is fully booked

#### Scenario: Simultaneous requests cannot oversell
- **WHEN** two booking requests for 2 guests each arrive at the same time for a tasting with 3 seats left
- **THEN** exactly one booking is created
- **AND** the other request is rejected because only 1 seat is left

### Requirement: Booking reference
Every booking that is created SHALL receive a booking reference that is unique among all bookings and starts with "KB-". The reference SHALL be shown on the confirmation and SHALL be used to identify the booking to staff.

#### Scenario: Each booking gets its own reference
- **WHEN** two bookings are created
- **THEN** they have different booking references, each starting with "KB-"

### Requirement: Confirmation after booking
After a booking is created, the guest SHALL see a confirmation page with the heading "Booking confirmed", the tasting title, date and time, the number of guests, the total price (guests multiplied by price per guest, shown as EUR amount), and the booking reference. The confirmation page SHALL remain available at its own address for the booking reference.

#### Scenario: Confirmation shows booking details
- **WHEN** a guest books 2 guests for Red Wine Cellar Tour
- **THEN** the page heading is "Booking confirmed"
- **AND** the page shows "Red Wine Cellar Tour", the date and time, "2", the total "EUR 64" and the booking reference

#### Scenario: Confirmation can be reopened by reference
- **WHEN** a guest opens the confirmation address for an existing booking reference
- **THEN** the same confirmation details are shown

#### Scenario: Unknown reference
- **WHEN** a guest opens the confirmation address for a reference that does not exist or was cancelled
- **THEN** the page says that no booking was found for that reference
- **AND** no personal details are shown

### Requirement: Booking errors are announced
Error messages for the booking form SHALL be associated with their fields so that screen readers announce them, and the first invalid field SHALL receive focus after a rejected submission.

#### Scenario: First invalid field receives focus
- **WHEN** a guest submits the form with two invalid fields
- **THEN** keyboard focus moves to the first invalid field
- **AND** each invalid field is linked to its error message
