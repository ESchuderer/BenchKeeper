## Purpose

Gives Weingut Kieselbrunnen staff a password-protected view of all tasting bookings, grouped by tasting, and lets them cancel a booking so its seats become available again.

## ADDED Requirements

### Requirement: Staff sign-in with password
The page `/staff` SHALL show a sign-in form with a field labelled "Password" and a button labelled "Sign in" until the staff member has signed in. The password SHALL be compared with the value of the environment variable `STAFF_PASSWORD`. A wrong password SHALL be rejected with an error message on the form and SHALL NOT reveal any booking data.

#### Scenario: Sign-in form before authentication
- **WHEN** a visitor opens `/staff` without being signed in
- **THEN** the page shows a "Password" field and a "Sign in" button
- **AND** no booking data is shown

#### Scenario: Correct password
- **WHEN** staff enter the value of `STAFF_PASSWORD` and press "Sign in"
- **THEN** the booking list is shown

#### Scenario: Wrong password
- **WHEN** staff enter a password that differs from `STAFF_PASSWORD` and press "Sign in"
- **THEN** an error message such as "Wrong password" is shown next to the Password field
- **AND** no booking data is shown

#### Scenario: Password not configured
- **WHEN** the server starts without `STAFF_PASSWORD` set and a visitor tries to sign in
- **THEN** sign-in is refused with a message that staff sign-in is not configured
- **AND** no booking data is shown

#### Scenario: Repeated failed attempts are limited
- **WHEN** more than 10 sign-in attempts from the same client fail within 15 minutes
- **THEN** further sign-in attempts from that client are refused until the window passes

### Requirement: Session stays signed in until it expires or is signed out
After a successful sign-in the staff session SHALL remain valid for 8 hours or until the staff member signs out, whichever comes first. Requests for booking data without a valid session SHALL be refused.

#### Scenario: Booking data requires a session
- **WHEN** a request for the booking list is made without a valid staff session
- **THEN** the request is refused and no booking data is returned

#### Scenario: Signing out ends the session
- **WHEN** a signed-in staff member presses "Sign out"
- **THEN** the sign-in form is shown again
- **AND** a previously issued session no longer returns booking data

### Requirement: Bookings are listed grouped by tasting
Signed-in staff SHALL see all active bookings grouped by tasting. Each booking SHALL show the guest's name, email, number of guests and booking reference. Tastings without bookings SHALL still be shown with a message that there are no bookings yet.

#### Scenario: Bookings grouped by tasting
- **WHEN** staff are signed in and bookings exist for Riesling Evening and Winter Tasting
- **THEN** the list has a group for each tasting, showing that tasting's title
- **AND** each booking in a group shows name, email, guests and booking reference

#### Scenario: Tasting without bookings
- **WHEN** staff are signed in and no bookings exist for Red Wine Cellar Tour
- **THEN** its group shows a message that there are no bookings yet

### Requirement: Staff can cancel a booking
Each booking in the staff list SHALL have a button labelled "Cancel". Pressing it SHALL cancel that booking, remove it from the list and free its seats for the tasting, so that the guest-facing seats-left figure increases by the booking's number of guests.

#### Scenario: Cancelling frees seats
- **WHEN** staff press "Cancel" on a booking for 3 guests for Riesling Evening
- **THEN** the booking disappears from the staff list
- **AND** Riesling Evening shows 3 more seats left on the start page

#### Scenario: Cancelled reference is no longer valid
- **WHEN** a booking has been cancelled and its reference is opened on the confirmation page
- **THEN** the page says that no booking was found for that reference

#### Scenario: Cancelling a booking that no longer exists
- **WHEN** a cancel request is made for a reference that does not exist or was already cancelled
- **THEN** the request is answered with status 404 and no seats change

### Requirement: Staff area is not indexed and is not cached
The staff pages and booking data SHALL be served with headers that prevent search engine indexing and browser caching of booking data.

#### Scenario: Booking data is not cached
- **WHEN** a signed-in staff member requests the booking list
- **THEN** the response carries headers that forbid caching
