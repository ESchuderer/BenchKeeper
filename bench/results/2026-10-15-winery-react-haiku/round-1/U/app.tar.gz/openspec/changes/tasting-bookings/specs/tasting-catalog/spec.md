## Purpose

Lists the wine tastings Weingut Kieselbrunnen offers, with date, time, price per guest and the number of seats still available, so guests can choose a tasting and see whether it can still be booked.

## ADDED Requirements

### Requirement: Start page lists all tastings
The start page SHALL list every offered tasting: Riesling Evening (2026-11-06 18:00, EUR 25 per guest, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32 per guest, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28 per guest, 10 seats). Each entry SHALL show its title, date and time, price per guest and seats status.

#### Scenario: All tastings are shown on the start page
- **WHEN** a guest opens the start page
- **THEN** the page lists Riesling Evening, Red Wine Cellar Tour and Winter Tasting, in date order
- **AND** each tasting shows its title, date and time, and price per guest

#### Scenario: Date and time are shown in readable form
- **WHEN** a guest views a tasting dated 2026-11-06 at 18:00
- **THEN** the date and time are shown as a readable date with the time 18:00

### Requirement: Seats left are shown per tasting
Each tasting SHALL show its number of seats left as "<n> seats left" when at least one seat is free. The number SHALL equal the tasting's seat count minus the guests of all active bookings for it. A tasting with exactly one seat free SHALL show "1 seat left".

#### Scenario: Seats left on an unbooked tasting
- **WHEN** no bookings exist for Red Wine Cellar Tour
- **THEN** its entry shows "8 seats left"

#### Scenario: Seats left after a booking
- **WHEN** a booking for 3 guests exists for Riesling Evening
- **THEN** its entry shows "9 seats left"

#### Scenario: One seat left
- **WHEN** 7 of the 8 seats of Red Wine Cellar Tour are booked
- **THEN** its entry shows "1 seat left"

### Requirement: Fully booked tastings are clearly marked
A tasting with no seats left SHALL be shown with the status "Fully booked" instead of a seat count, and SHALL NOT offer a booking action.

#### Scenario: Fully booked tasting on the start page
- **WHEN** all 8 seats of Red Wine Cellar Tour are booked
- **THEN** its entry shows "Fully booked"
- **AND** the entry has no "Book Red Wine Cellar Tour" action

### Requirement: Each tasting links to its booking form
Each tasting that has seats left SHALL offer a link labelled "Book <tasting title>" (for example "Book Riesling Evening") that opens the booking form for that tasting.

#### Scenario: Booking link for a tasting with seats
- **WHEN** a guest views Winter Tasting, which has seats left
- **THEN** a link labelled "Book Winter Tasting" is shown
- **AND** following it opens the booking form for Winter Tasting

### Requirement: Layout works on phones
The start page and all other pages SHALL remain fully usable on a narrow phone screen: no horizontal scrolling of the page content, and all links and buttons are large enough to tap.

#### Scenario: Start page on a 375 px wide screen
- **WHEN** a guest opens the start page on a 375 px wide viewport
- **THEN** all tasting entries and their booking links are visible and reachable without horizontal scrolling
