# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` (ESM, Node 22 engines, scripts `dev:server`, `dev:client`, `build`, `build:client`, `build:server`, `start`, `test`, `typecheck`) and install runtime dependencies (express, helmet, express-rate-limit, cookie-parser, zod, react, react-dom, react-router, react-hook-form, @hookform/resolvers) and dev dependencies (typescript, vite, @vitejs/plugin-react, tailwindcss, @tailwindcss/vite, vitest, jsdom, @testing-library/react, @testing-library/jest-dom, @testing-library/user-event, supertest, tsx and the matching @types packages); verify `npm install` completes and `npm ls --depth=0` reports no errors
- [x] 1.2 Add `tsconfig.json` (client, bundler resolution), `tsconfig.server.json` (NodeNext, emits to `dist/server`), `vite.config.ts` (with Vitest projects), `index.html` and an empty `src/client/main.tsx`; verify `npm run build` produces `dist/client/index.html` and `dist/server/server/index.js`

## 2. Tasting catalogue, seat rules and booking schema

- [x] 2.1 Write failing unit tests for the catalogue (the three tastings with exact title, date, time, price and seats), the seats-left computation (seats minus guests of active bookings, zero means fully booked), the seats text ("8 seats left", "1 seat left"), the price text ("EUR 25") and the readable date and time; verify they fail for the expected reason
- [x] 2.2 Implement the shared catalogue and formatting helpers in `src/shared`; verify the tests from 2.1 pass
- [x] 2.3 Write failing unit tests for the in-memory booking store: creating a booking within the seats left, rejecting more guests than seats left without changing seats, unknown tasting, references are unique and start with "KB-", two simultaneous 2-guest requests for 3 seats create exactly one booking, cancelling frees seats, cancelling an unknown or already cancelled reference returns not found, cancelled bookings are not returned by reference lookup; verify they fail
- [x] 2.4 Implement the in-memory booking store in `src/server/bookingStore.ts`; verify the tests from 2.3 pass
- [x] 2.5 Write failing unit tests for the Zod booking schema in `src/shared`: name is required, trimmed and at most 100 characters; email is required and must be a valid address; guests must be a whole number from 1 to 8 and an empty guests value gives a "required" message; verify they fail
- [x] 2.6 Implement the booking schema in `src/shared/bookingSchema.ts` with an English message per rule; verify the tests from 2.5 pass

## 3. Guest API

- [x] 3.1 Write failing Supertest tests for `GET /api/tastings` (three tastings with `seatsLeft`), `POST /api/tastings/:id/bookings` (201 with reference and total; 400 with `fieldErrors` for invalid input; 404 for unknown tasting; 409 for fully booked; a `guests` field error stating the seats left when the request is too large; no seats taken on rejection), `GET /api/bookings/:reference` (confirmation view without the guest's email; 404 when unknown), malformed JSON returning 400, unknown `/api/*` returning JSON 404, and security headers from helmet; verify they fail
- [x] 3.2 Implement the Express app factory in `src/server/app.ts` with the JSON parser, helmet, the guest routes and a JSON error handler; verify the tests from 3.1 pass

## 4. Staff API

- [x] 4.1 Write failing Supertest tests for staff access: `POST /api/staff/session` returns 503 when `STAFF_PASSWORD` is unset or empty; wrong password returns 401 with an error and no cookie; correct password returns 200 and an `HttpOnly; SameSite=Strict` session cookie; `GET /api/staff/bookings` returns 401 without a session; with a session it returns bookings grouped by tasting with name, email, guests and reference and `Cache-Control: no-store`; `DELETE /api/staff/bookings/:reference` returns 204 and frees the seats (visible in `GET /api/tastings`); unknown reference returns 404; `DELETE /api/staff/session` ends the session; sessions expire after 8 hours (injected clock); more than 10 failed attempts in 15 minutes returns 429; verify they fail
- [x] 4.2 Implement staff authentication in `src/server/staffAuth.ts` (constant-time SHA-256 comparison, in-memory sessions, rate limiter) and the staff routes; verify the tests from 4.1 pass

## 5. Guest interface

- [x] 5.1 Write failing React Testing Library tests for the start page (three tastings with title, date and time, price per guest and "N seats left"; "Book <title>" links only for tastings with seats; "Fully booked" with no link), the booking form (labels "Name", "Email", "Guests", button "Book", heading with the tasting title), client-side validation messages next to each field with focus on the first invalid field, server 409 or 400 errors shown next to the Guests or other field, and the confirmation page (heading "Booking confirmed", tasting, guests, "EUR" total, reference) and its not-found state; verify they fail
- [x] 5.2 Implement the React app in `src/client`: router, API client, layout, start page, booking page, confirmation page and shared form field component; verify the tests from 5.1 pass

## 6. Staff interface

- [x] 6.1 Write failing React Testing Library tests for `/staff`: "Password" field and "Sign in" button before sign-in, wrong password error next to the field, after sign-in bookings grouped by tasting with name, email, guests, reference and a "Cancel" button per booking, empty-group message, cancelling removes the booking, "Sign out" returns to the form; verify they fail
- [x] 6.2 Implement the staff page in `src/client/pages/StaffPage.tsx`; verify the tests from 6.1 pass

## 7. Winery visual design

- [x] 7.1 Apply the visual system (cream and bordeaux palette, serif headings, header with "Weingut Kieselbrunnen", card layout, focus rings, error, success, fully-booked and empty states, mobile-first spacing with touch targets of at least 44 px); verify `npm test` still passes and `npm run build` succeeds

## 8. Server delivery

- [x] 8.1 Write failing Supertest tests that `GET /` and `GET /book/<id>` and `GET /bookings/<ref>` and `GET /staff` return the React app's `index.html`, that static assets come from `dist/client`, that `/staff` carries `X-Robots-Tag: noindex`, and that `PORT` and `STAFF_PASSWORD` are read from the environment with default port 3000; verify they fail
- [x] 8.2 Implement `src/server/index.ts` (listen on `PORT`, serve `dist/client` with SPA fallback for non-API GET requests); verify the tests from 8.1 pass, then run `npm run build` and `PORT=3123 npm start` and confirm with `fetch` that the start page and `/api/tastings` respond

## 9. Verification

- [x] 9.1 Run the main guest and staff flows in a headless browser at 1280 px and 375 px (book a tasting, validation errors, fully booked tasting, staff sign-in, cancel frees seats), with no console errors and no horizontal scrolling at 375 px; if Chromium cannot be installed, record that in the verification notes and rely on the component and API tests. Evidence: headless Chromium 156 run against the built server on 2026-10-15 passed 22/22 checks (guest booking, validation, seat limit, fully booked, staff sign-in, cancel, sign-out, 375 px layout and tap sizes) with no application console errors; the only browser console entries were the expected 409 and 401 responses from the negative tests
- [x] 9.2 Run `npm run typecheck`, `npm test` and `npm run build`, and map every scenario in `specs/` to a passing test (openspec-verify-change)

## 10. Review fixes

- [x] 10.1 Write failing Supertest tests that malformed JSON sent to a non-API path returns a plain 400 without a stack trace, and that an unexpected error on a non-API path returns a generic 500 without internal details; implement one app-level error handler in `src/server/app.ts` so that API errors stay JSON and other errors do not leak stack traces; verify the tests pass
- [x] 10.2 Write failing tests that a booking body which is a JSON array or a non-object returns 400 with a top-level error and no `fieldErrors` key named "undefined", then implement the fix in `src/server/app.ts`; verify the tests pass
- [x] 10.3 Write failing schema tests that Guests values such as "0x2", "1e0" and "2 3" are rejected with the guests range message, then restrict the Guests field to plain decimal digits in `src/shared/bookingSchema.ts`; verify the tests pass
- [x] 10.4 Write a failing unit test that expired staff sessions are removed when a new session is created, then sweep expired sessions in `src/server/staffAuth.ts`; verify the test passes
- [x] 10.5 Remove the unused `createdAt` field from `src/server/bookingStore.ts`; verify `npm test` and `npm run typecheck` pass

## Workflow follow-up

- Review the change with code-review-and-quality and fix findings
- Archive the change with openspec-archive-change once verification passes
