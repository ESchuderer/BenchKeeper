import type {
  ApiErrorBody,
  BookingResponse,
  StaffBookingsResponse,
  StaffSessionResponse,
  TastingsResponse,
} from '../shared/api.js';
import type { BookingFormValues } from '../shared/bookingSchema.js';

export class ApiError extends Error {
  readonly status: number;
  readonly body: ApiErrorBody;

  constructor(status: number, body: ApiErrorBody) {
    super(body.error);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const response = await fetch(path, {
    method,
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
    credentials: 'same-origin',
  });

  if (response.status === 204) return undefined as T;

  const data: unknown = await response.json().catch(() => ({}));
  if (!response.ok) {
    const errorBody = (data ?? {}) as Partial<ApiErrorBody>;
    throw new ApiError(response.status, {
      error: errorBody.error ?? 'Something went wrong. Please try again.',
      fieldErrors: errorBody.fieldErrors,
    });
  }
  return data as T;
}

export function getTastings(): Promise<TastingsResponse> {
  return request('GET', '/api/tastings');
}

export function createBooking(tastingId: string, values: BookingFormValues): Promise<BookingResponse> {
  return request('POST', `/api/tastings/${encodeURIComponent(tastingId)}/bookings`, values);
}

export function getBooking(reference: string): Promise<BookingResponse> {
  return request('GET', `/api/bookings/${encodeURIComponent(reference)}`);
}

export function getStaffSession(): Promise<StaffSessionResponse> {
  return request('GET', '/api/staff/session');
}

export function signInStaff(password: string): Promise<StaffSessionResponse> {
  return request('POST', '/api/staff/session', { password });
}

export function signOutStaff(): Promise<void> {
  return request('DELETE', '/api/staff/session');
}

export function getStaffBookings(): Promise<StaffBookingsResponse> {
  return request('GET', '/api/staff/bookings');
}

export function cancelStaffBooking(reference: string): Promise<void> {
  return request('DELETE', `/api/staff/bookings/${encodeURIComponent(reference)}`);
}
