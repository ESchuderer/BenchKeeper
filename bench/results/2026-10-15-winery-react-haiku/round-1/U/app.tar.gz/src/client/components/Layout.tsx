import { Link, Outlet } from 'react-router';

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:rounded focus:bg-white focus:px-3 focus:py-2"
      >
        Skip to content
      </a>
      <header className="border-b border-line bg-paper">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-x-6 gap-y-3 px-4 py-5">
          <Link to="/" className="font-serif text-xl font-semibold text-bordeaux no-underline">
            Weingut Kieselbrunnen
          </Link>
          <nav aria-label="Main">
            <Link to="/" className="text-sm font-semibold text-ink no-underline hover:text-bordeaux">
              Tastings
            </Link>
          </nav>
        </div>
      </header>
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <Outlet />
      </main>
      <footer className="border-t border-line bg-paper">
        <div className="mx-auto max-w-4xl px-4 py-6 text-sm text-ink-soft">
          <span className="font-serif text-ink">Weingut Kieselbrunnen</span>, a family winery. Wine tastings by reservation.
        </div>
      </footer>
    </div>
  );
}
