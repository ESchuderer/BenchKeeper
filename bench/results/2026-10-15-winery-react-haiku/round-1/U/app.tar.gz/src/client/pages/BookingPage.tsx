import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { ApiError, createBooking, getTastings } from '../api.js';
import { TextField } from '../components/TextField.js';
import { bookingFormSchema, MAX_GUESTS, type BookingFormInput, type BookingFormValues } from '../../shared/bookingSchema.js';
import { formatPrice, formatSeatsLeft, formatWhen } from '../../shared/format.js';
import type { TastingView } from '../../shared/tastings.js';
import type { BookingField } from '../../shared/api.js';

type LoadState = { status: 'loading' } | { status: 'ready'; tasting: TastingView | undefined } | { status: 'error' };

export function BookingPage() {
  const { tastingId = '' } = useParams();
  const [state, setState] = useState<LoadState>({ status: 'loading' });

  useEffect(() => {
    let cancelled = false;
    getTastings()
      .then((data) => {
        if (!cancelled) {
          setState({ status: 'ready', tasting: data.tastings.find((tasting) => tasting.id === tastingId) });
        }
      })
      .catch(() => {
        if (!cancelled) setState({ status: 'error' });
      });
    return () => {
      cancelled = true;
    };
  }, [tastingId]);

  if (state.status === 'loading') {
    return <p role="status">Loading tasting...</p>;
  }
  if (state.status === 'error') {
    return <ErrorPanel message="We could not load this tasting. Please reload the page to try again." />;
  }
  if (!state.tasting) {
    return <ErrorPanel message="That tasting does not exist." />;
  }
  const tasting = state.tasting;
  if (tasting.seatsLeft === 0) {
    return (
      <section className="flex flex-col gap-4">
        <title>{`${tasting.title} - Weingut Kieselbrunnen`}</title>
        <h1 className="font-serif text-3xl text-bordeaux">{tasting.title}</h1>
        <p role="status" className="rounded-md border border-error bg-error-soft p-4 text-error">
          {tasting.title} is fully booked.
        </p>
        <BackToTastings />
      </section>
    );
  }
  return <BookingForm tasting={tasting} />;
}

function ErrorPanel({ message }: { message: string }) {
  return (
    <section className="flex flex-col gap-4">
      <p role="alert" className="rounded-md border border-error bg-error-soft p-4 text-error">
        {message}
      </p>
      <BackToTastings />
    </section>
  );
}

function BackToTastings() {
  return (
    <p>
      <Link to="/" className="font-semibold">
        Back to all tastings
      </Link>
    </p>
  );
}

function BookingForm({ tasting }: { tasting: TastingView }) {
  const navigate = useNavigate();
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingFormInput, unknown, BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: { name: '', email: '', guests: '' },
  });

  const onSubmit: SubmitHandler<BookingFormValues> = async (values) => {
    setFormError(null);
    try {
      const { booking } = await createBooking(tasting.id, values);
      navigate(`/bookings/${booking.reference}`);
    } catch (error) {
      if (!(error instanceof ApiError)) {
        setFormError('We could not reach the server. Please check your connection and try again.');
        return;
      }
      const fieldErrors = error.body.fieldErrors ?? {};
      const entries = Object.entries(fieldErrors) as [BookingField, string][];
      for (const [field, message] of entries) {
        setError(field, { type: 'server', message });
      }
      if (entries.length === 0 || error.status !== 400) {
        setFormError(error.body.error);
      }
    }
  };

  return (
    <section className="flex flex-col gap-6">
      <title>{`Book ${tasting.title} - Weingut Kieselbrunnen`}</title>
      <div>
        <h1 className="font-serif text-3xl text-bordeaux sm:text-4xl">{tasting.title}</h1>
        <p className="mt-2 text-ink">{formatWhen(tasting.date, tasting.time)}</p>
        <p className="text-ink-soft">
          {formatPrice(tasting.pricePerGuest)} per guest, {formatSeatsLeft(tasting.seatsLeft)}
        </p>
      </div>

      {formError && (
        <p role="alert" className="rounded-md border border-error bg-error-soft p-4 text-error">
          {formError}
        </p>
      )}

      <form noValidate onSubmit={handleSubmit(onSubmit)} className="flex max-w-md flex-col gap-5 rounded-lg border border-line bg-white p-5 shadow-sm">
        <TextField
          label="Name"
          autoComplete="name"
          error={errors.name?.message}
          {...register('name')}
        />
        <TextField
          label="Email"
          type="email"
          autoComplete="email"
          inputMode="email"
          error={errors.email?.message}
          {...register('email')}
        />
        <TextField
          label="Guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={MAX_GUESTS}
          step={1}
          hint={`1 to ${MAX_GUESTS} people`}
          error={errors.guests?.message}
          {...register('guests')}
        />
        <button
          type="submit"
          disabled={isSubmitting}
          className="min-h-11 rounded-md bg-bordeaux px-4 py-2 font-semibold text-white hover:bg-bordeaux-dark disabled:opacity-60"
        >
          Book
        </button>
      </form>

      <BackToTastings />
    </section>
  );
}
