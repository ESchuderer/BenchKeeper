import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { ApiError, getBooking } from '../api.js';
import { formatPrice, formatWhen } from '../../shared/format.js';
import type { BookingConfirmation } from '../../shared/api.js';

type LoadState =
  | { status: 'loading' }
  | { status: 'ready'; booking: BookingConfirmation }
  | { status: 'not_found'; message: string }
  | { status: 'error' };

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const [state, setState] = useState<LoadState>({ status: 'loading' });

  useEffect(() => {
    let cancelled = false;
    getBooking(reference)
      .then((data) => {
        if (!cancelled) setState({ status: 'ready', booking: data.booking });
      })
      .catch((error: unknown) => {
        if (cancelled) return;
        if (error instanceof ApiError && error.status === 404) {
          setState({ status: 'not_found', message: error.body.error });
        } else {
          setState({ status: 'error' });
        }
      });
    return () => {
      cancelled = true;
    };
  }, [reference]);

  if (state.status === 'loading') {
    return <p role="status">Loading your booking...</p>;
  }
  if (state.status === 'error') {
    return (
      <p role="alert" className="rounded-md border border-error bg-error-soft p-4 text-error">
        We could not load this booking. Please reload the page to try again.
      </p>
    );
  }
  if (state.status === 'not_found') {
    return (
      <section className="flex flex-col gap-4">
        <title>Booking not found - Weingut Kieselbrunnen</title>
        <p role="alert" className="rounded-md border border-error bg-error-soft p-4 text-error">
          {state.message}
        </p>
        <p>
          <Link to="/" className="font-semibold">
            Back to all tastings
          </Link>
        </p>
      </section>
    );
  }

  const { booking } = state;
  return (
    <section className="flex flex-col gap-6">
      <title>Booking confirmed - Weingut Kieselbrunnen</title>
      <div role="status" className="flex flex-col gap-3 rounded-lg border border-success bg-success-soft p-5">
        <p className="flex items-center gap-2 text-sm font-semibold text-success">
          <span aria-hidden="true" className="flex size-6 items-center justify-center rounded-full bg-success text-white">&#10003;</span>
          Your seats are reserved
        </p>
        <h1 className="font-serif text-3xl text-bordeaux sm:text-4xl">Booking confirmed</h1>
        <p className="text-ink">Thank you. We look forward to welcoming you. Please keep your booking reference.</p>
      </div>
      <dl className="grid max-w-md gap-4 rounded-lg border border-line bg-white p-5 shadow-sm">
        <div>
          <dt className="text-sm text-ink-soft">Tasting</dt>
          <dd className="font-serif text-xl text-ink">{booking.tastingTitle}</dd>
        </div>
        <div>
          <dt className="text-sm text-ink-soft">Date and time</dt>
          <dd className="text-ink">{formatWhen(booking.date, booking.time)}</dd>
        </div>
        <div>
          <dt className="text-sm text-ink-soft">Guests</dt>
          <dd className="text-ink">{booking.guests}</dd>
        </div>
        <div>
          <dt className="text-sm text-ink-soft">Total price</dt>
          <dd className="font-semibold text-ink">{formatPrice(booking.total)}</dd>
        </div>
        <div>
          <dt className="text-sm text-ink-soft">Booking reference</dt>
          <dd className="font-mono text-lg font-semibold tracking-wider text-bordeaux">{booking.reference}</dd>
        </div>
      </dl>
      <p>
        <Link to="/" className="font-semibold">
          Back to all tastings
        </Link>
      </p>
    </section>
  );
}
