import { Link } from 'react-router';

export function NotFoundPage() {
  return (
    <section className="flex flex-col gap-4">
      <title>Page not found - Weingut Kieselbrunnen</title>
      <h1 className="font-serif text-3xl text-bordeaux">Page not found</h1>
      <p>The page you are looking for does not exist.</p>
      <p>
        <Link to="/" className="font-semibold">
          See the tastings
        </Link>
      </p>
    </section>
  );
}
