import { useEffect, useState, type ReactNode } from 'react';
import { useForm } from 'react-hook-form';
import { ApiError, cancelStaffBooking, getStaffBookings, getStaffSession, signInStaff, signOutStaff } from '../api.js';
import { TextField } from '../components/TextField.js';
import { formatSeatsLeft } from '../../shared/format.js';
import type { StaffBookingGroup } from '../../shared/api.js';

type View =
  | { kind: 'checking' }
  | { kind: 'signed_out'; notice?: string }
  | { kind: 'signed_in' };

export function StaffPage() {
  const [view, setView] = useState<View>({ kind: 'checking' });

  useEffect(() => {
    let cancelled = false;
    getStaffSession()
      .then((session) => {
        if (!cancelled) setView(session.signedIn ? { kind: 'signed_in' } : { kind: 'signed_out' });
      })
      .catch(() => {
        if (!cancelled) setView({ kind: 'signed_out', notice: 'We could not check your sign-in. Please reload the page.' });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (view.kind === 'checking') {
    return (
      <p role="status">
        <title>Staff - Weingut Kieselbrunnen</title>
        Checking your sign-in...
      </p>
    );
  }

  if (view.kind === 'signed_out') {
    return (
      <SignInForm
        notice={view.notice}
        onSignedIn={() => setView({ kind: 'signed_in' })}
      />
    );
  }

  return (
    <BookingList
      onSignedOut={() => setView({ kind: 'signed_out' })}
      onSessionEnded={() => setView({ kind: 'signed_out', notice: 'Your session has ended. Please sign in again.' })}
    />
  );
}

function SignInForm({ notice, onSignedIn }: { notice?: string; onSignedIn: () => void }) {
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } });

  const onSubmit = async ({ password }: { password: string }) => {
    setFormError(null);
    try {
      await signInStaff(password);
      onSignedIn();
    } catch (error) {
      if (error instanceof ApiError && error.body.fieldErrors?.password) {
        setError('password', { type: 'server', message: error.body.fieldErrors.password });
        return;
      }
      setFormError(error instanceof ApiError ? error.body.error : 'We could not reach the server. Please try again.');
    }
  };

  return (
    <section className="flex flex-col gap-6">
      <title>Staff sign-in - Weingut Kieselbrunnen</title>
      <h1 className="font-serif text-3xl text-bordeaux">Staff sign-in</h1>
      {notice && (
        <p role="alert" className="rounded-md border border-line bg-cream p-4 text-ink">
          {notice}
        </p>
      )}
      {formError && (
        <p role="alert" className="rounded-md border border-error bg-error-soft p-4 text-error">
          {formError}
        </p>
      )}
      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="flex max-w-sm flex-col gap-5 rounded-lg border border-line bg-white p-5 shadow-sm"
      >
        <TextField
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          {...register('password')}
        />
        <button
          type="submit"
          disabled={isSubmitting}
          className="min-h-11 rounded-md bg-bordeaux px-4 py-2 font-semibold text-white hover:bg-bordeaux-dark disabled:opacity-60"
        >
          Sign in
        </button>
      </form>
    </section>
  );
}

type ListState =
  | { status: 'loading' }
  | { status: 'ready'; groups: StaffBookingGroup[] }
  | { status: 'error' };

function BookingList({ onSignedOut, onSessionEnded }: { onSignedOut: () => void; onSessionEnded: () => void }) {
  const [list, setList] = useState<ListState>({ status: 'loading' });
  const [actionError, setActionError] = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);

  /** Loads the list; a 401 means the session has ended and the user must sign in again. */
  const load = async () => {
    try {
      const data = await getStaffBookings();
      setList({ status: 'ready', groups: data.groups });
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) return onSessionEnded();
      setList({ status: 'error' });
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const cancel = async (reference: string) => {
    setActionError(null);
    setPending(reference);
    try {
      await cancelStaffBooking(reference);
      await load();
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) return onSessionEnded();
      setActionError(error instanceof ApiError ? error.body.error : 'The booking could not be cancelled. Please try again.');
    } finally {
      setPending(null);
    }
  };

  const signOut = async () => {
    await signOutStaff().catch(() => undefined);
    onSignedOut();
  };

  return (
    <section className="flex flex-col gap-6">
      <title>Staff bookings - Weingut Kieselbrunnen</title>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-serif text-3xl text-bordeaux">Bookings</h1>
        <button
          type="button"
          onClick={signOut}
          className="min-h-11 rounded-md border border-bordeaux px-4 py-2 font-semibold text-bordeaux hover:bg-cream"
        >
          Sign out
        </button>
      </div>

      {actionError && (
        <p role="alert" className="rounded-md border border-error bg-error-soft p-4 text-error">
          {actionError}
        </p>
      )}

      {list.status === 'loading' && <p role="status">Loading bookings...</p>}
      {list.status === 'error' && (
        <p role="alert" className="rounded-md border border-error bg-error-soft p-4 text-error">
          The bookings could not be loaded. Please reload the page to try again.
        </p>
      )}

      {list.status === 'ready' &&
        list.groups.map((group) => (
          <TastingGroup key={group.tasting.id} group={group} pending={pending} onCancel={cancel} />
        ))}
    </section>
  );
}

function TastingGroup({
  group,
  pending,
  onCancel,
}: {
  group: StaffBookingGroup;
  pending: string | null;
  onCancel: (reference: string) => void;
}) {
  const headingId = `group-${group.tasting.id}`;
  return (
    <section aria-labelledby={headingId} className="flex flex-col gap-3 rounded-lg border border-line bg-white p-5 shadow-sm">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 id={headingId} className="font-serif text-2xl text-bordeaux">
          {group.tasting.title}
        </h2>
        <p className="text-sm text-ink-soft">{formatSeatsLeft(group.tasting.seatsLeft)}</p>
      </div>

      {group.bookings.length === 0 ? (
        <p className="text-ink-soft">No bookings yet.</p>
      ) : (
        <ul className="flex flex-col divide-y divide-line">
          {group.bookings.map((booking) => (
            <li key={booking.reference} className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between">
              <dl className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm sm:grid-cols-4">
                <Detail label="Name">
                  <span className="font-semibold text-ink">{booking.name}</span>
                </Detail>
                <Detail label="Email">
                  <span className="break-all text-ink">{booking.email}</span>
                </Detail>
                <Detail label="Guests">
                  <span className="text-ink">{booking.guests}</span>
                </Detail>
                <Detail label="Reference">
                  <span className="font-mono text-ink">{booking.reference}</span>
                </Detail>
              </dl>
              <button
                type="button"
                disabled={pending === booking.reference}
                onClick={() => onCancel(booking.reference)}
                className="min-h-11 shrink-0 rounded-md border border-error px-4 py-2 font-semibold text-error hover:bg-error-soft disabled:opacity-60"
              >
                Cancel
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Detail({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col">
      <dt className="text-ink-soft">{label}</dt>
      <dd className="m-0">{children}</dd>
    </div>
  );
}
