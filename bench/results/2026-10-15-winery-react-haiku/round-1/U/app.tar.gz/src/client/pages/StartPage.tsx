import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { getTastings } from '../api.js';
import { formatPrice, formatSeatsLeft, formatWhen } from '../../shared/format.js';
import type { TastingView } from '../../shared/tastings.js';

type LoadState = { status: 'loading' } | { status: 'ready'; tastings: TastingView[] } | { status: 'error' };

export function StartPage() {
  const [state, setState] = useState<LoadState>({ status: 'loading' });

  useEffect(() => {
    let cancelled = false;
    getTastings()
      .then((data) => {
        if (!cancelled) setState({ status: 'ready', tastings: data.tastings });
      })
      .catch(() => {
        if (!cancelled) setState({ status: 'error' });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <section className="flex flex-col gap-6">
      <title>Wine tastings - Weingut Kieselbrunnen</title>
      <div>
        <h1 className="font-serif text-3xl text-bordeaux sm:text-4xl">Wine tastings</h1>
        <p className="mt-2 max-w-2xl text-ink-soft">
          Join us at the cellar door. Choose a tasting and reserve your seats online.
        </p>
      </div>

      {state.status === 'loading' && <p role="status">Loading tastings...</p>}

      {state.status === 'error' && (
        <p role="alert" className="rounded-md border border-error bg-error-soft p-4 text-error">
          We could not load the tastings. Please reload the page to try again.
        </p>
      )}

      {state.status === 'ready' && (
        <ul className="grid gap-5 sm:grid-cols-2">
          {state.tastings.map((tasting) => (
            <li key={tasting.id}>
              <TastingCard tasting={tasting} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function TastingCard({ tasting }: { tasting: TastingView }) {
  const titleId = `tasting-${tasting.id}`;
  const fullyBooked = tasting.seatsLeft === 0;

  return (
    <article
      aria-labelledby={titleId}
      className={`flex h-full flex-col gap-4 rounded-lg border p-5 shadow-sm ${
        fullyBooked ? "border-line bg-cream text-ink-soft" : "border-line bg-paper"
      }`}
    >
      <div className="flex flex-col gap-1">
        <h2 id={titleId} className={`font-serif text-2xl ${fullyBooked ? "text-ink-soft" : "text-bordeaux"}`}>
          {tasting.title}
        </h2>
        <p className="text-ink">{formatWhen(tasting.date, tasting.time)}</p>
      </div>
      <dl className="grid grid-cols-2 gap-3 border-t border-line pt-4 text-sm">
        <div>
          <dt className="text-ink-soft">Price</dt>
          <dd className="font-semibold text-ink">{formatPrice(tasting.pricePerGuest)} per guest</dd>
        </div>
        <div>
          <dt className="text-ink-soft">Availability</dt>
          <dd
            className={`font-semibold ${fullyBooked ? "text-error" : tasting.seatsLeft <= 2 ? "text-warn" : "text-success"}`}
          >
            {fullyBooked ? 'Fully booked' : formatSeatsLeft(tasting.seatsLeft)}
          </dd>
        </div>
      </dl>
      {!fullyBooked && (
        <Link
          to={`/book/${tasting.id}`}
          className="mt-auto inline-flex min-h-11 items-center justify-center rounded-md bg-bordeaux px-4 py-2 font-semibold text-white no-underline hover:bg-bordeaux-dark hover:text-white"
        >
          Book {tasting.title}
        </Link>
      )}
    </article>
  );
}
