import { existsSync } from 'node:fs';
import { extname, join } from 'node:path';
import express, { type ErrorRequestHandler, type NextFunction, type Request, type Response } from 'express';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { ZodError } from 'zod';
import { createBookingStore, type Booking, type BookingStore } from './bookingStore.js';
import { STAFF_COOKIE, createStaffSessions, passwordMatches, SESSION_TTL_MS } from './staffAuth.js';
import { bookingFormSchema } from '../shared/bookingSchema.js';
import { formatSeatsLeft } from '../shared/format.js';
import type {
  ApiErrorBody,
  BookingConfirmation,
  BookingField,
  FormField,
  StaffBookingsResponse,
  StaffSessionResponse,
} from '../shared/api.js';
import type { TastingDefinition } from '../shared/tastings.js';

export interface AppOptions {
  store?: BookingStore;
  /** Staff password. When missing or empty, staff sign-in is disabled. */
  staffPassword?: string;
  /** Clock in milliseconds since the epoch; injected for tests. */
  now?: () => number;
  /** Directory with the built React app. When omitted, only the API is served. */
  clientDir?: string;
}

const SIGN_IN_WINDOW_MS = 15 * 60 * 1000;
const SIGN_IN_FAILURE_LIMIT = 10;

function sendError(res: Response, status: number, body: ApiErrorBody): void {
  res.status(status).json(body);
}

function fieldErrorsFrom(error: ZodError): Partial<Record<FormField, string>> {
  const fieldErrors: Partial<Record<BookingField, string>> = {};
  for (const issue of error.issues) {
    const field = issue.path[0] as BookingField;
    fieldErrors[field] ??= issue.message;
  }
  return fieldErrors;
}

function toConfirmation(booking: Booking, tasting: TastingDefinition): BookingConfirmation {
  return {
    reference: booking.reference,
    tastingTitle: tasting.title,
    date: tasting.date,
    time: tasting.time,
    guests: booking.guests,
    pricePerGuest: tasting.pricePerGuest,
    total: booking.guests * tasting.pricePerGuest,
  };
}

export function createApp(options: AppOptions = {}) {
  const store = options.store ?? createBookingStore();
  const now = options.now ?? Date.now;
  const staffPassword = options.staffPassword;
  const sessions = createStaffSessions(now);
  const app = express();

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'"],
          // Plain HTTP on a local network must keep working, so do not upgrade requests to HTTPS.
          upgradeInsecureRequests: null,
        },
      },
    }),
  );
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  // ---- Guest API -------------------------------------------------------

  app.get('/api/tastings', (_req, res) => {
    res.json({ tastings: store.listTastings() });
  });

  app.post('/api/tastings/:tastingId/bookings', (req: Request, res: Response) => {
    const tastingId = String(req.params.tastingId);
    const tasting = store.getTasting(tastingId);
    if (!tasting) {
      return sendError(res, 404, { error: 'That tasting does not exist.' });
    }

    const body: unknown = req.body ?? {};
    if (typeof body !== 'object' || Array.isArray(body)) {
      return sendError(res, 400, { error: 'Please send the booking as a JSON object.' });
    }

    const parsed = bookingFormSchema.safeParse(body);
    if (!parsed.success) {
      return sendError(res, 400, {
        error: 'Please correct the highlighted fields.',
        fieldErrors: fieldErrorsFrom(parsed.error),
      });
    }

    const result = store.createBooking(tastingId, parsed.data);
    if (result.ok) {
      return res.status(201).json({ booking: toConfirmation(result.booking, tasting) });
    }
    if (result.reason === 'insufficient_seats') {
      return sendError(res, 409, {
        error: 'Not enough seats are left for this booking.',
        fieldErrors: { guests: `Only ${formatSeatsLeft(result.seatsLeft)} for this tasting.` },
      });
    }
    if (result.reason === 'fully_booked') {
      return sendError(res, 409, { error: 'This tasting is fully booked.' });
    }
    return sendError(res, 404, { error: 'That tasting does not exist.' });
  });

  app.get('/api/bookings/:reference', (req: Request, res: Response) => {
    const booking = store.getBooking(String(req.params.reference));
    const tasting = booking && store.getTasting(booking.tastingId);
    if (!booking || !tasting) {
      return sendError(res, 404, { error: 'No booking was found for that reference.' });
    }
    res.json({ booking: toConfirmation(booking, tasting) });
  });

  // ---- Staff API -------------------------------------------------------

  const staffApi = express.Router();
  staffApi.use((_req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });

  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    if (sessions.isValid(req.cookies?.[STAFF_COOKIE])) return next();
    sendError(res, 401, { error: 'Please sign in to see bookings.' });
  };

  const signInLimiter = rateLimit({
    windowMs: SIGN_IN_WINDOW_MS,
    limit: SIGN_IN_FAILURE_LIMIT,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => {
      sendError(res, 429, { error: 'Too many sign-in attempts. Please wait 15 minutes and try again.' });
    },
  });

  staffApi.get('/session', (req, res) => {
    const body: StaffSessionResponse = { signedIn: sessions.isValid(req.cookies?.[STAFF_COOKIE]) };
    res.json(body);
  });

  staffApi.post('/session', signInLimiter, (req: Request, res: Response) => {
    if (!staffPassword) {
      return sendError(res, 503, { error: 'Staff sign-in is not configured.' });
    }
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!passwordMatches(password, staffPassword)) {
      return sendError(res, 401, {
        error: 'Wrong password.',
        fieldErrors: { password: 'Wrong password.' },
      });
    }
    const token = sessions.create();
    res.cookie(STAFF_COOKIE, token, {
      httpOnly: true,
      sameSite: 'strict',
      path: '/',
      maxAge: SESSION_TTL_MS,
    });
    res.json({ signedIn: true });
  });

  staffApi.delete('/session', (req, res) => {
    sessions.revoke(req.cookies?.[STAFF_COOKIE]);
    res.clearCookie(STAFF_COOKIE, { httpOnly: true, sameSite: 'strict', path: '/' });
    res.status(204).end();
  });

  staffApi.get('/bookings', requireStaff, (_req, res) => {
    const body: StaffBookingsResponse = {
      groups: store.listBookingsByTasting().map((group) => ({
        tasting: group.tasting,
        bookings: group.bookings.map((booking) => ({
          reference: booking.reference,
          name: booking.name,
          email: booking.email,
          guests: booking.guests,
        })),
      })),
    };
    res.json(body);
  });

  staffApi.delete('/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancelBooking(String(req.params.reference))) {
      return sendError(res, 404, { error: 'No booking was found for that reference.' });
    }
    res.status(204).end();
  });

  app.use('/api/staff', staffApi);

  // ---- Errors ----------------------------------------------------------

  app.use('/api', (_req: Request, res: Response) => {
    sendError(res, 404, { error: 'Not found.' });
  });

  if (options.clientDir) {
    serveClient(app, options.clientDir);
  }

  app.use(errorHandler);

  return app;
}

/**
 * Last-resort error handler. API errors get a JSON body; everywhere else gets plain
 * text. Stack traces are logged on the server and never sent to the client.
 */
const errorHandler: ErrorRequestHandler = (error, req, res, _next) => {
  const { status, message } = describeError(error);
  if (status === 500) console.error(error);

  if (req.path.startsWith('/api')) {
    return sendError(res, status, { error: message });
  }
  res.status(status).type('text/plain').send(message);
};

function describeError(error: unknown): { status: number; message: string } {
  const type = (error as { type?: unknown } | null)?.type;
  if (type === 'entity.parse.failed') return { status: 400, message: 'Request body must be valid JSON.' };
  if (type === 'entity.too.large') return { status: 413, message: 'Request body is too large.' };
  return { status: 500, message: 'Something went wrong. Please try again.' };
}

/**
 * Serves the built React app. Real files come from the directory; any other GET
 * that is not a file path gets index.html so client-side routes survive a reload.
 */
function serveClient(app: express.Express, clientDir: string): void {
  const indexFile = join(clientDir, 'index.html');

  if (!existsSync(indexFile)) {
    app.use((req, res, next) => {
      if (req.method !== 'GET' || req.path.startsWith('/api')) return next();
      res.status(503).type('text/plain').send('The web app has not been built. Run "npm run build" first.');
    });
    return;
  }

  app.use('/staff', (_req, res, next) => {
    res.set('X-Robots-Tag', 'noindex, nofollow');
    next();
  });
  app.use(express.static(clientDir, { index: false }));
  app.use((req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    // A path with a file extension that was not found is a missing asset, not a route.
    if (extname(req.path)) return next();
    res.sendFile(indexFile);
  });
}
