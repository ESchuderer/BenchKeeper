import { randomInt } from 'node:crypto';
import { TASTINGS, type TastingDefinition, type TastingView } from '../shared/tastings.js';

export interface BookingDetails {
  name: string;
  email: string;
  guests: number;
}

export interface Booking extends BookingDetails {
  reference: string;
  tastingId: string;
}

export type CreateBookingResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: 'unknown_tasting' }
  | { ok: false; reason: 'fully_booked' }
  | { ok: false; reason: 'insufficient_seats'; seatsLeft: number };

export interface TastingBookings {
  tasting: TastingView;
  bookings: Booking[];
}

export interface BookingStore {
  listTastings(): TastingView[];
  getTasting(tastingId: string): TastingView | undefined;
  createBooking(tastingId: string, details: BookingDetails): CreateBookingResult;
  getBooking(reference: string): Booking | undefined;
  listBookingsByTasting(): TastingBookings[];
  cancelBooking(reference: string): boolean;
}

export interface BookingStoreOptions {
  tastings?: readonly TastingDefinition[];
}

// Omits look-alikes (I, L, O, 0, 1) so references can be read out loud.
const REFERENCE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const REFERENCE_LENGTH = 6;

function generateReference(): string {
  let suffix = '';
  for (let i = 0; i < REFERENCE_LENGTH; i++) {
    suffix += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  }
  return `KB-${suffix}`;
}

/**
 * In-memory booking store. Every operation is synchronous, so a seat check and
 * the insert that depends on it cannot interleave with another request in this
 * single-threaded process.
 */
export function createBookingStore(options: BookingStoreOptions = {}): BookingStore {
  const tastings = options.tastings ?? TASTINGS;
  const definitions = new Map(tastings.map((tasting) => [tasting.id, tasting]));
  const bookingsByTasting = new Map<string, Booking[]>();
  const bookingsByReference = new Map<string, Booking>();

  function activeBookings(tastingId: string): Booking[] {
    return bookingsByTasting.get(tastingId) ?? [];
  }

  function seatsLeft(definition: TastingDefinition): number {
    const guestsBooked = activeBookings(definition.id).reduce((sum, booking) => sum + booking.guests, 0);
    return definition.seats - guestsBooked;
  }

  function view(definition: TastingDefinition): TastingView {
    return { ...definition, seatsLeft: seatsLeft(definition) };
  }

  function uniqueReference(): string {
    let reference = generateReference();
    while (bookingsByReference.has(reference)) {
      reference = generateReference();
    }
    return reference;
  }

  return {
    listTastings() {
      return tastings.map(view);
    },

    getTasting(tastingId) {
      const definition = definitions.get(tastingId);
      return definition && view(definition);
    },

    createBooking(tastingId, details) {
      const definition = definitions.get(tastingId);
      if (!definition) return { ok: false, reason: 'unknown_tasting' };

      const available = seatsLeft(definition);
      if (available === 0) return { ok: false, reason: 'fully_booked' };
      if (details.guests > available) {
        return { ok: false, reason: 'insufficient_seats', seatsLeft: available };
      }

      const booking: Booking = {
        ...details,
        reference: uniqueReference(),
        tastingId,
      };
      const bookings = bookingsByTasting.get(tastingId) ?? [];
      bookings.push(booking);
      bookingsByTasting.set(tastingId, bookings);
      bookingsByReference.set(booking.reference, booking);
      return { ok: true, booking };
    },

    getBooking(reference) {
      return bookingsByReference.get(reference);
    },

    listBookingsByTasting() {
      return tastings.map((definition) => ({
        tasting: view(definition),
        bookings: [...activeBookings(definition.id)],
      }));
    },

    cancelBooking(reference) {
      const booking = bookingsByReference.get(reference);
      if (!booking) return false;

      bookingsByReference.delete(reference);
      const bookings = bookingsByTasting.get(booking.tastingId) ?? [];
      bookingsByTasting.set(
        booking.tastingId,
        bookings.filter((candidate) => candidate !== booking),
      );
      return true;
    },
  };
}
