export const DEFAULT_PORT = 3000;

export interface ServerConfig {
  port: number;
  /** Undefined when STAFF_PASSWORD is unset or empty, which disables staff sign-in. */
  staffPassword: string | undefined;
}

/** Reads the server configuration from environment variables. Throws on an invalid PORT. */
export function readConfig(env: NodeJS.ProcessEnv): ServerConfig {
  return {
    port: readPort(env.PORT),
    staffPassword: env.STAFF_PASSWORD ? env.STAFF_PASSWORD : undefined,
  };
}

function readPort(raw: string | undefined): number {
  const value = raw?.trim();
  if (value === undefined || value === '') return DEFAULT_PORT;
  const port = Number(value);
  if (!/^\d+$/.test(value) || port > 65535) {
    throw new Error(`PORT must be a whole number from 0 to 65535, got "${raw}".`);
  }
  return port;
}
