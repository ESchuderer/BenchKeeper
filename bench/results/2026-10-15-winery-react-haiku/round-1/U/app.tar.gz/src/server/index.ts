import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { readConfig } from './config.js';

/** The built React app lives in dist/client at the project root, next to package.json. */
function findClientDir(): string {
  let dir = dirname(fileURLToPath(import.meta.url));
  for (;;) {
    if (existsSync(join(dir, 'package.json'))) return join(dir, 'dist', 'client');
    const parent = dirname(dir);
    if (parent === dir) return resolve('dist', 'client');
    dir = parent;
  }
}

function main(): void {
  let config;
  try {
    config = readConfig(process.env);
  } catch (error) {
    console.error(error instanceof Error ? error.message : error);
    process.exit(1);
  }

  if (!config.staffPassword) {
    console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
  }

  const app = createApp({ staffPassword: config.staffPassword, clientDir: findClientDir() });
  app.listen(config.port, () => {
    console.log(`Weingut Kieselbrunnen is running on http://localhost:${config.port}`);
  });
}

main();
