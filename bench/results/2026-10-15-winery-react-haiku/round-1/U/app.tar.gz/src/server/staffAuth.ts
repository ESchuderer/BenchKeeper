import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const STAFF_COOKIE = 'kb_staff';
export const SESSION_TTL_MS = 8 * 60 * 60 * 1000;

/**
 * Compares two strings in constant time. Both are hashed first so the comparison
 * always runs over equal-length buffers and leaks neither content nor length.
 */
export function passwordMatches(candidate: string, expected: string): boolean {
  const candidateDigest = createHash('sha256').update(candidate, 'utf8').digest();
  const expectedDigest = createHash('sha256').update(expected, 'utf8').digest();
  return timingSafeEqual(candidateDigest, expectedDigest);
}

export interface StaffSessions {
  create(): string;
  isValid(token: string | undefined): boolean;
  revoke(token: string | undefined): void;
  /** Number of sessions still held, including any that have expired but are not yet swept. */
  size(): number;
}

/** In-memory staff sessions. Tokens are random and expire after SESSION_TTL_MS. */
export function createStaffSessions(now: () => number): StaffSessions {
  const expiresAt = new Map<string, number>();

  return {
    create() {
      sweepExpired();
      const token = randomBytes(32).toString('base64url');
      expiresAt.set(token, now() + SESSION_TTL_MS);
      return token;
    },

    isValid(token) {
      if (!token) return false;
      const expiry = expiresAt.get(token);
      if (expiry === undefined) return false;
      if (now() >= expiry) {
        expiresAt.delete(token);
        return false;
      }
      return true;
    },

    revoke(token) {
      if (token) expiresAt.delete(token);
    },

    size() {
      return expiresAt.size;
    },
  };

  /** Removes expired sessions so abandoned tokens do not accumulate in memory. */
  function sweepExpired(): void {
    const current = now();
    for (const [token, expiry] of expiresAt) {
      if (current >= expiry) expiresAt.delete(token);
    }
  }
}
