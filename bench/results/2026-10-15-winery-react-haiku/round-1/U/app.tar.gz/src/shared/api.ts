import type { TastingView } from './tastings.js';

/** Form fields that can carry a validation message. */
export type BookingField = 'name' | 'email' | 'guests';
export type FormField = BookingField | 'password';

export interface ApiErrorBody {
  error: string;
  fieldErrors?: Partial<Record<FormField, string>>;
}

export interface TastingsResponse {
  tastings: TastingView[];
}

/** Guest-facing booking details. Deliberately omits the guest's name and email. */
export interface BookingConfirmation {
  reference: string;
  tastingTitle: string;
  date: string;
  time: string;
  guests: number;
  pricePerGuest: number;
  total: number;
}

export interface BookingResponse {
  booking: BookingConfirmation;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffBookingGroup {
  tasting: TastingView;
  bookings: StaffBooking[];
}

export interface StaffBookingsResponse {
  groups: StaffBookingGroup[];
}

export interface StaffSessionResponse {
  signedIn: boolean;
}
