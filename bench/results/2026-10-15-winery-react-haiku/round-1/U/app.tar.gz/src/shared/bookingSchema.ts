import { z } from 'zod';

export const MIN_GUESTS = 1;
export const MAX_GUESTS = 8;
export const MAX_NAME_LENGTH = 100;

const GUESTS_RANGE_MESSAGE = `Guests must be a whole number from ${MIN_GUESTS} to ${MAX_GUESTS}.`;

/**
 * Validation for the booking form. It is shared by the browser (instant feedback)
 * and the server (authoritative), so both apply the same rules and messages.
 */
export const bookingFormSchema = z.object({
  name: z
    .string({ error: 'Please enter your name.' })
    .trim()
    .min(1, 'Please enter your name.')
    .max(MAX_NAME_LENGTH, `Name must be ${MAX_NAME_LENGTH} characters or fewer.`),
  email: z
    .string({ error: 'Please enter your email address.' })
    .trim()
    .min(1, 'Please enter your email address.')
    .pipe(z.email({ error: 'Please enter a valid email address.' })),
  guests: z.preprocess(
    (value) => {
      if (typeof value !== 'string') return value;
      const trimmed = value.trim();
      if (trimmed === '') return undefined;
      // Only plain digits count: Number() would also accept "0x2", "1e0" and "+2".
      return /^\d+$/.test(trimmed) ? Number(trimmed) : Number.NaN;
    },
    z
      .number({
        error: (issue) => (issue.input === undefined ? 'Please enter the number of guests.' : GUESTS_RANGE_MESSAGE),
      })
      .int(GUESTS_RANGE_MESSAGE)
      .min(MIN_GUESTS, GUESTS_RANGE_MESSAGE)
      .max(MAX_GUESTS, GUESTS_RANGE_MESSAGE),
  ),
});

/** Values as typed into the form (guests may still be text). */
export type BookingFormInput = z.input<typeof bookingFormSchema>;
/** Validated values (guests is a number). */
export type BookingFormValues = z.output<typeof bookingFormSchema>;
