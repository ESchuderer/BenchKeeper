const UTC_DATE_PARTS = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' } as const;

/** "8 seats left", or "1 seat left" for exactly one seat. */
export function formatSeatsLeft(seatsLeft: number): string {
  return seatsLeft === 1 ? '1 seat left' : `${seatsLeft} seats left`;
}

/** "EUR 25" for a whole-euro amount. */
export function formatPrice(euros: number): string {
  return `EUR ${euros}`;
}

/**
 * "Friday, 6 November 2026, 18:00".
 * Formatted in UTC so the calendar date never shifts with the viewer's time zone.
 */
export function formatWhen(date: string, time: string): string {
  const [year, month, day] = date.split('-').map(Number);
  const parts = new Intl.DateTimeFormat('en-GB', UTC_DATE_PARTS).formatToParts(
    new Date(Date.UTC(year, month - 1, day)),
  );
  const value = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value ?? '';
  return `${value('weekday')}, ${value('day')} ${value('month')} ${value('year')}, ${time}`;
}
