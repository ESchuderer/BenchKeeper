export interface TastingDefinition {
  id: string;
  title: string;
  /** Calendar date, YYYY-MM-DD. */
  date: string;
  /** Start time, HH:mm (24 h). */
  time: string;
  /** Whole euros per guest. */
  pricePerGuest: number;
  /** Total seats for the tasting. */
  seats: number;
}

export interface TastingView extends TastingDefinition {
  seatsLeft: number;
}

export const TASTINGS: readonly TastingDefinition[] = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    date: '2026-11-06',
    time: '18:00',
    pricePerGuest: 25,
    seats: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    date: '2026-11-14',
    time: '15:00',
    pricePerGuest: 32,
    seats: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    date: '2026-12-05',
    time: '17:00',
    pricePerGuest: 28,
    seats: 10,
  },
];
