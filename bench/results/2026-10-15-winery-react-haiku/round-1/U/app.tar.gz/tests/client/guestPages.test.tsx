import { describe, expect, it } from 'vitest';
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { catalogue, renderApp, stubApi } from './helpers.js';

const CONFIRMATION_PATH = '/bookings/KB-ABC234';

describe('start page', () => {
  it('lists each tasting with title, date and time, price per guest and seats left', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({ 'riesling-evening': 12, 'red-wine-cellar-tour': 8, 'winter-tasting': 10 }) } }));

    renderApp('/');

    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(riesling).getByText('Friday, 6 November 2026, 18:00')).toBeInTheDocument();
    expect(within(riesling).getByText('EUR 25 per guest')).toBeInTheDocument();
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument();

    const red = screen.getByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(red).getByText('Saturday, 14 November 2026, 15:00')).toBeInTheDocument();
    expect(within(red).getByText('EUR 32 per guest')).toBeInTheDocument();
    expect(within(red).getByText('8 seats left')).toBeInTheDocument();

    const winter = screen.getByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText('Saturday, 5 December 2026, 17:00')).toBeInTheDocument();
    expect(within(winter).getByText('EUR 28 per guest')).toBeInTheDocument();
    expect(within(winter).getByText('10 seats left')).toBeInTheDocument();
  });

  it('shows "1 seat left" in the singular', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({ 'winter-tasting': 1 }) } }));

    renderApp('/');

    const winter = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText('1 seat left')).toBeInTheDocument();
  });

  it('offers a "Book <title>" link to the booking form for a tasting with seats', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({}) } }));

    renderApp('/');

    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link).toHaveAttribute('href', '/book/riesling-evening');
  });

  it('marks a fully booked tasting and offers no booking link for it', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({ 'winter-tasting': 0 }) } }));

    renderApp('/');

    const winter = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText('Fully booked')).toBeInTheDocument();
    expect(within(winter).queryByText(/seats? left/)).not.toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Winter Tasting' })).not.toBeInTheDocument();
  });

  it('shows a clear message when the tastings cannot be loaded', async () => {
    stubApi(() => ({ status: 500, body: { error: 'Something went wrong.' } }));

    renderApp('/');

    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load the tastings/i);
  });
});

describe('booking form', () => {
  it('shows the tasting title as heading and the Name, Email and Guests fields with a Book button', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({}) } }));

    renderApp('/book/riesling-evening');

    expect(await screen.findByRole('heading', { level: 1, name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows an error next to each empty field and does not send the booking', async () => {
    const { calls } = stubApi(() => ({ status: 200, body: { tastings: catalogue({}) } }));
    renderApp('/book/riesling-evening');
    await screen.findByRole('button', { name: 'Book' });

    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Name')).toHaveAccessibleDescription('Please enter your name.');
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Please enter your email address.');
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Please enter the number of guests.');
    expect(screen.getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true');
    expect(calls.filter((call) => call.method === 'POST')).toHaveLength(0);
  });

  it('moves keyboard focus to the first invalid field', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({}) } }));
    renderApp('/book/riesling-evening');
    await screen.findByRole('button', { name: 'Book' });

    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    await waitFor(() => expect(screen.getByLabelText('Name')).toHaveFocus());
  });

  it('rejects an invalid email address next to the Email field', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({}) } }));
    renderApp('/book/riesling-evening');
    await screen.findByRole('button', { name: 'Book' });

    await userEvent.type(screen.getByLabelText('Name'), 'Anna Keller');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example');
    await userEvent.type(screen.getByLabelText('Guests'), '2');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Email')).toHaveAccessibleDescription('Please enter a valid email address.');
  });

  it.each(['0', '9', '2.5'])('rejects guests value %s next to the Guests field', async (guests) => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({}) } }));
    renderApp('/book/riesling-evening');
    await screen.findByRole('button', { name: 'Book' });

    await userEvent.type(screen.getByLabelText('Name'), 'Anna Keller');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.type(screen.getByLabelText('Guests'), guests);
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(
      'Guests must be a whole number from 1 to 8.',
    );
  });

  it('shows the seats-left message from the server next to the Guests field when too many guests are requested', async () => {
    stubApi((call) => {
      if (call.method === 'POST') {
        return { status: 409, body: { error: 'Not enough seats are left for this booking.', fieldErrors: { guests: 'Only 2 seats left for this tasting.' } } };
      }
      return { status: 200, body: { tastings: catalogue({ 'winter-tasting': 2 }) } };
    });
    renderApp('/book/winter-tasting');
    await screen.findByRole('button', { name: 'Book' });

    await userEvent.type(screen.getByLabelText('Name'), 'Anna Keller');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.type(screen.getByLabelText('Guests'), '3');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription('Only 2 seats left for this tasting.');
  });

  it('shows a fully booked message instead of the form when no seats are left', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({ 'winter-tasting': 0 }) } }));

    renderApp('/book/winter-tasting');

    expect(await screen.findByText('Winter Tasting is fully booked.')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });

  it('tells the guest when the tasting does not exist', async () => {
    stubApi(() => ({ status: 200, body: { tastings: catalogue({}) } }));

    renderApp('/book/no-such-tasting');

    expect(await screen.findByText('That tasting does not exist.')).toBeInTheDocument();
  });

  it('books the seats and opens the confirmation for the new reference', async () => {
    const { calls } = stubApi((call) => {
      if (call.method === 'POST') {
        return {
          status: 201,
          body: {
            booking: {
              reference: 'KB-ABC234',
              tastingTitle: 'Red Wine Cellar Tour',
              date: '2026-11-14',
              time: '15:00',
              guests: 2,
              pricePerGuest: 32,
              total: 64,
            },
          },
        };
      }
      if (call.path === '/api/bookings/KB-ABC234') {
        return { status: 200, body: { booking: { reference: 'KB-ABC234', tastingTitle: 'Red Wine Cellar Tour', date: '2026-11-14', time: '15:00', guests: 2, pricePerGuest: 32, total: 64 } } };
      }
      return { status: 200, body: { tastings: catalogue({}) } };
    });
    renderApp('/book/red-wine-cellar-tour');
    await screen.findByRole('button', { name: 'Book' });

    await userEvent.type(screen.getByLabelText('Name'), 'Anna Keller');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.type(screen.getByLabelText('Guests'), '2');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { level: 1, name: 'Booking confirmed' })).toBeInTheDocument();
    const post = calls.find((call) => call.method === 'POST');
    expect(post).toMatchObject({
      path: '/api/tastings/red-wine-cellar-tour/bookings',
      body: { name: 'Anna Keller', email: 'anna@example.com', guests: 2 },
    });
  });
});

describe('confirmation page', () => {
  it('shows the heading, tasting, guests, total price and booking reference', async () => {
    stubApi(() => ({
      status: 200,
      body: { booking: { reference: 'KB-ABC234', tastingTitle: 'Red Wine Cellar Tour', date: '2026-11-14', time: '15:00', guests: 2, pricePerGuest: 32, total: 64 } },
    }));

    renderApp(CONFIRMATION_PATH);

    expect(await screen.findByRole('heading', { level: 1, name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Red Wine Cellar Tour')).toBeInTheDocument();
    expect(screen.getByText('Saturday, 14 November 2026, 15:00')).toBeInTheDocument();
    expect(screen.getByText('Guests')).toBeInTheDocument();
    expect(screen.getByText('2')).toBeInTheDocument();
    expect(screen.getByText('EUR 64')).toBeInTheDocument();
    expect(screen.getByText('KB-ABC234')).toBeInTheDocument();
  });

  it('says so when no booking exists for the reference', async () => {
    stubApi(() => ({ status: 404, body: { error: 'No booking was found for that reference.' } }));

    renderApp('/bookings/KB-ZZZZZZ');

    expect(await screen.findByText('No booking was found for that reference.')).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
  });
});
