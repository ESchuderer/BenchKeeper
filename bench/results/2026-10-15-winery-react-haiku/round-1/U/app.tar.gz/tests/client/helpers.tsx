import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { vi } from 'vitest';
import { App } from '../../src/client/App.js';
import { TASTINGS, type TastingView } from '../../src/shared/tastings.js';

export interface ApiCall {
  method: string;
  path: string;
  body: unknown;
}

export interface ApiReply {
  status: number;
  body?: unknown;
}

/**
 * Replaces the global fetch with a fake API. Each request is recorded in `calls`
 * and answered by `handler`. This is the boundary for client tests: the React
 * code runs for real, only the network is replaced.
 */
export function stubApi(handler: (call: ApiCall) => ApiReply) {
  const calls: ApiCall[] = [];
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input), 'http://localhost');
    const method = (init?.method ?? 'GET').toUpperCase();
    const body = typeof init?.body === 'string' ? JSON.parse(init.body) : undefined;
    const call: ApiCall = { method, path: url.pathname, body };
    calls.push(call);

    const reply = handler(call);
    if (reply.status === 204) return new Response(null, { status: 204 });
    return new Response(JSON.stringify(reply.body ?? {}), {
      status: reply.status,
      headers: { 'Content-Type': 'application/json' },
    });
  });
  vi.stubGlobal('fetch', fetchMock);
  return { calls, fetchMock };
}

/** The catalogue as the server reports it, with the given seats left per tasting id. */
export function catalogue(seatsLeft: Record<string, number>): TastingView[] {
  return TASTINGS.map((tasting) => ({ ...tasting, seatsLeft: seatsLeft[tasting.id] ?? tasting.seats }));
}

export function renderApp(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}
