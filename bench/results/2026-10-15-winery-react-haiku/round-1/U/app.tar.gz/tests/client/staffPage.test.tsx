import { describe, expect, it } from 'vitest';
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { catalogue, renderApp, stubApi, type ApiCall } from './helpers.js';
import type { StaffBookingGroup } from '../../src/shared/api.js';

const PASSWORD = 'correct horse battery';

/**
 * A small stateful fake of the staff API: it keeps a signed-in flag and the list of
 * bookings, and changes them as the real server would on sign-in, sign-out and cancel.
 */
function fakeStaffServer(options: { signedIn?: boolean } = {}) {
  let signedIn = options.signedIn ?? false;
  let groups: StaffBookingGroup[] = [
    {
      tasting: catalogue({})[0],
      bookings: [
        { reference: 'KB-AAAA23', name: 'Anna Keller', email: 'anna@example.com', guests: 2 },
        { reference: 'KB-BBBB34', name: 'Ben Hofmann', email: 'ben@example.com', guests: 1 },
      ],
    },
    { tasting: catalogue({})[1], bookings: [] },
    { tasting: catalogue({})[2], bookings: [] },
  ];

  return stubApi((call: ApiCall) => {
    if (call.path === '/api/staff/session' && call.method === 'GET') {
      return { status: 200, body: { signedIn } };
    }
    if (call.path === '/api/staff/session' && call.method === 'POST') {
      if ((call.body as { password?: string }).password === PASSWORD) {
        signedIn = true;
        return { status: 200, body: { signedIn: true } };
      }
      return { status: 401, body: { error: 'Wrong password.', fieldErrors: { password: 'Wrong password.' } } };
    }
    if (call.path === '/api/staff/session' && call.method === 'DELETE') {
      signedIn = false;
      return { status: 204 };
    }
    if (call.path === '/api/staff/bookings' && call.method === 'GET') {
      if (!signedIn) return { status: 401, body: { error: 'Please sign in to see bookings.' } };
      return { status: 200, body: { groups } };
    }
    const cancel = call.path.match(/^\/api\/staff\/bookings\/(KB-[A-Z0-9]+)$/);
    if (cancel && call.method === 'DELETE') {
      if (!signedIn) return { status: 401, body: { error: 'Please sign in to see bookings.' } };
      const reference = cancel[1];
      groups = groups.map((group) => ({
        ...group,
        bookings: group.bookings.filter((booking) => booking.reference !== reference),
      }));
      return { status: 204 };
    }
    return { status: 404, body: { error: 'Not found.' } };
  });
}

describe('staff sign-in', () => {
  it('asks for a password with a Password field and a Sign in button, and shows no booking data', async () => {
    const { calls } = fakeStaffServer();

    renderApp('/staff');

    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
    expect(calls.some((call) => call.path === '/api/staff/bookings')).toBe(false);
  });

  it('shows the wrong password error next to the Password field and keeps the form', async () => {
    fakeStaffServer();
    renderApp('/staff');
    await screen.findByLabelText('Password');

    await userEvent.type(screen.getByLabelText('Password'), 'guess');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription('Wrong password.');
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
  });

  it('shows the bookings after a correct password', async () => {
    fakeStaffServer();
    renderApp('/staff');
    await screen.findByLabelText('Password');

    await userEvent.type(screen.getByLabelText('Password'), PASSWORD);
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByText('anna@example.com')).toBeInTheDocument();
  });

  it('shows a clear message when staff sign-in is not configured on the server', async () => {
    stubApi((call) => {
      if (call.method === 'GET') return { status: 200, body: { signedIn: false } };
      return { status: 503, body: { error: 'Staff sign-in is not configured.' } };
    });
    renderApp('/staff');
    await screen.findByLabelText('Password');

    await userEvent.type(screen.getByLabelText('Password'), 'anything');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Staff sign-in is not configured.');
  });

  it('opens the booking list straight away when a staff session already exists', async () => {
    fakeStaffServer({ signedIn: true });

    renderApp('/staff');

    expect(await screen.findByText('anna@example.com')).toBeInTheDocument();
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument();
  });
});

describe('staff booking list', () => {
  it('groups bookings by tasting with name, email, guests and reference', async () => {
    fakeStaffServer({ signedIn: true });

    renderApp('/staff');

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    expect(within(riesling).getByText('Anna Keller')).toBeInTheDocument();
    expect(within(riesling).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(riesling).getByText('2')).toBeInTheDocument();
    expect(within(riesling).getByText('KB-AAAA23')).toBeInTheDocument();
    expect(within(riesling).getByText('Ben Hofmann')).toBeInTheDocument();
    expect(within(riesling).getByText('KB-BBBB34')).toBeInTheDocument();
  });

  it('shows a message for a tasting without bookings', async () => {
    fakeStaffServer({ signedIn: true });

    renderApp('/staff');

    const cellar = await screen.findByRole('region', { name: 'Red Wine Cellar Tour' });
    expect(within(cellar).getByText('No bookings yet.')).toBeInTheDocument();
  });

  it('gives each booking a Cancel button', async () => {
    fakeStaffServer({ signedIn: true });

    renderApp('/staff');

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    expect(within(riesling).getAllByRole('button', { name: 'Cancel' })).toHaveLength(2);
  });

  it('cancels a booking, removes it from the list and frees its seats for guests', async () => {
    const { calls } = fakeStaffServer({ signedIn: true });
    renderApp('/staff');
    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });

    await userEvent.click(within(riesling).getAllByRole('button', { name: 'Cancel' })[0]);

    await waitFor(() => expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument());
    expect(calls).toContainEqual(expect.objectContaining({ method: 'DELETE', path: '/api/staff/bookings/KB-AAAA23' }));
    expect(within(riesling).getByText('Ben Hofmann')).toBeInTheDocument();
  });

  it('shows an error when a cancellation fails and keeps the booking listed', async () => {
    stubApi((call) => {
      if (call.path === '/api/staff/session') return { status: 200, body: { signedIn: true } };
      if (call.path === '/api/staff/bookings') {
        return {
          status: 200,
          body: {
            groups: [
              {
                tasting: catalogue({})[0],
                bookings: [{ reference: 'KB-AAAA23', name: 'Anna Keller', email: 'anna@example.com', guests: 2 }],
              },
            ],
          },
        };
      }
      return { status: 404, body: { error: 'No booking was found for that reference.' } };
    });
    renderApp('/staff');
    await screen.findByText('anna@example.com');

    await userEvent.click(screen.getByRole('button', { name: 'Cancel' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('No booking was found for that reference.');
    expect(screen.getByText('anna@example.com')).toBeInTheDocument();
  });

  it('returns to the sign-in form with a message when the session has ended', async () => {
    stubApi((call) => {
      if (call.path === '/api/staff/session' && call.method === 'GET') return { status: 200, body: { signedIn: true } };
      if (call.path === '/api/staff/bookings') return { status: 401, body: { error: 'Please sign in to see bookings.' } };
      return { status: 404, body: {} };
    });

    renderApp('/staff');

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.getByRole('alert')).toHaveTextContent('Your session has ended. Please sign in again.');
  });
});

describe('staff sign-out', () => {
  it('returns to the sign-in form and hides the bookings', async () => {
    fakeStaffServer({ signedIn: true });
    renderApp('/staff');
    await screen.findByText('anna@example.com');

    await userEvent.click(screen.getByRole('button', { name: 'Sign out' }));

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
  });
});
