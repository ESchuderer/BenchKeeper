import { describe, expect, it } from 'vitest';
import { createBookingStore } from '../../src/server/bookingStore.js';
import type { TastingDefinition } from '../../src/shared/tastings.js';

const SMALL_CATALOGUE: TastingDefinition[] = [
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    date: '2026-12-05',
    time: '17:00',
    pricePerGuest: 28,
    seats: 3,
  },
  {
    id: 'sold-out',
    title: 'Sold Out Tasting',
    date: '2026-12-06',
    time: '17:00',
    pricePerGuest: 10,
    seats: 1,
  },
];

const guest = { name: 'Anna Keller', email: 'anna@example.com' };

function newStore() {
  return createBookingStore({ tastings: SMALL_CATALOGUE });
}

describe('booking store: seats', () => {
  it('starts with every seat free and no bookings', () => {
    const store = newStore();
    expect(store.listTastings()).toEqual([
      expect.objectContaining({ id: 'winter-tasting', seatsLeft: 3 }),
      expect.objectContaining({ id: 'sold-out', seatsLeft: 1 }),
    ]);
    expect(store.listBookingsByTasting()).toEqual([
      expect.objectContaining({ tasting: expect.objectContaining({ id: 'winter-tasting' }), bookings: [] }),
      expect.objectContaining({ tasting: expect.objectContaining({ id: 'sold-out' }), bookings: [] }),
    ]);
  });

  it('reduces seats left by the number of guests booked', () => {
    const store = newStore();
    store.createBooking('winter-tasting', { ...guest, guests: 2 });
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(1);
  });

  it('creates a booking when the guests fit in the seats left', () => {
    const store = newStore();
    const result = store.createBooking('winter-tasting', { ...guest, guests: 3 });
    expect(result).toEqual({
      ok: true,
      booking: expect.objectContaining({
        tastingId: 'winter-tasting',
        name: 'Anna Keller',
        email: 'anna@example.com',
        guests: 3,
      }),
    });
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(0);
  });

  it('rejects more guests than seats left and takes no seats', () => {
    const store = newStore();
    store.createBooking('winter-tasting', { ...guest, guests: 2 });

    const result = store.createBooking('winter-tasting', { ...guest, guests: 2 });

    expect(result).toEqual({ ok: false, reason: 'insufficient_seats', seatsLeft: 1 });
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(1);
  });

  it('rejects any booking for a tasting with no seats left as fully booked', () => {
    const store = newStore();
    store.createBooking('sold-out', { ...guest, guests: 1 });

    const result = store.createBooking('sold-out', { ...guest, guests: 1 });

    expect(result).toEqual({ ok: false, reason: 'fully_booked' });
  });

  it('rejects a booking for a tasting that does not exist', () => {
    const store = newStore();
    expect(store.createBooking('no-such-tasting', { ...guest, guests: 1 })).toEqual({
      ok: false,
      reason: 'unknown_tasting',
    });
  });

  it('keeps the seat count consistent when a rejected request is followed by a valid one', () => {
    const store = newStore();
    store.createBooking('winter-tasting', { ...guest, guests: 3 });
    store.createBooking('winter-tasting', { ...guest, guests: 1 });
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(0);
  });
});

describe('booking store: references', () => {
  it('gives every booking a reference starting with "KB-" and six unambiguous characters', () => {
    const store = createBookingStore({
      tastings: [{ ...SMALL_CATALOGUE[0], seats: 20 }],
    });
    const references = new Set<string>();
    for (let i = 0; i < 20; i++) {
      const result = store.createBooking('winter-tasting', { ...guest, guests: 1 });
      if (!result.ok) throw new Error('booking should succeed');
      expect(result.booking.reference).toMatch(/^KB-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}$/);
      references.add(result.booking.reference);
    }
    expect(references.size).toBe(20);
  });
});

describe('booking store: lookup and cancellation', () => {
  it('finds a booking by its reference', () => {
    const store = newStore();
    const result = store.createBooking('winter-tasting', { ...guest, guests: 1 });
    if (!result.ok) throw new Error('booking should succeed');
    expect(store.getBooking(result.booking.reference)).toEqual(result.booking);
  });

  it('groups active bookings by tasting for staff', () => {
    const store = newStore();
    store.createBooking('winter-tasting', { ...guest, guests: 1 });
    store.createBooking('winter-tasting', { name: 'Ben', email: 'ben@example.com', guests: 2 });

    const groups = store.listBookingsByTasting();
    const winter = groups.find((group) => group.tasting.id === 'winter-tasting');
    expect(winter?.bookings.map((booking) => booking.name)).toEqual(['Anna Keller', 'Ben']);
  });

  it('cancelling a booking frees its seats', () => {
    const store = newStore();
    const result = store.createBooking('winter-tasting', { ...guest, guests: 3 });
    if (!result.ok) throw new Error('booking should succeed');

    expect(store.cancelBooking(result.booking.reference)).toBe(true);
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(3);
  });

  it('a cancelled booking is no longer found and no longer listed', () => {
    const store = newStore();
    const result = store.createBooking('winter-tasting', { ...guest, guests: 1 });
    if (!result.ok) throw new Error('booking should succeed');

    store.cancelBooking(result.booking.reference);

    expect(store.getBooking(result.booking.reference)).toBeUndefined();
    expect(store.listBookingsByTasting()[0].bookings).toEqual([]);
  });

  it('cancelling an unknown or already cancelled reference returns false', () => {
    const store = newStore();
    const result = store.createBooking('winter-tasting', { ...guest, guests: 1 });
    if (!result.ok) throw new Error('booking should succeed');

    expect(store.cancelBooking('KB-ZZZZZZ')).toBe(false);
    expect(store.cancelBooking(result.booking.reference)).toBe(true);
    expect(store.cancelBooking(result.booking.reference)).toBe(false);
  });
});
