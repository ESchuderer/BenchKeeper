import { describe, expect, it } from 'vitest';
import { readConfig } from '../../src/server/config.js';

describe('readConfig', () => {
  it('uses port 3000 and no staff password when the environment is empty', () => {
    expect(readConfig({})).toEqual({ port: 3000, staffPassword: undefined });
  });

  it('reads the port from PORT', () => {
    expect(readConfig({ PORT: '8080' }).port).toBe(8080);
  });

  it('rejects a PORT that is not a number between 0 and 65535', () => {
    expect(() => readConfig({ PORT: 'abc' })).toThrow(/PORT/);
    expect(() => readConfig({ PORT: '70000' })).toThrow(/PORT/);
  });

  it('reads the staff password from STAFF_PASSWORD, exactly as set', () => {
    expect(readConfig({ STAFF_PASSWORD: ' secret pass ' }).staffPassword).toBe(' secret pass ');
  });

  it('treats an empty STAFF_PASSWORD as not configured', () => {
    expect(readConfig({ STAFF_PASSWORD: '' }).staffPassword).toBeUndefined();
  });
});
