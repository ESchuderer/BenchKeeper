import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { createBookingStore } from '../../src/server/bookingStore.js';

const INDEX_HTML = '<!doctype html><html><body><div id="root"></div></body></html>';
const APP_JS = 'console.log("kieselbrunnen");';

let clientDir: string;

beforeAll(() => {
  clientDir = mkdtempSync(join(tmpdir(), 'kb-client-'));
  mkdirSync(join(clientDir, 'assets'));
  writeFileSync(join(clientDir, 'index.html'), INDEX_HTML);
  writeFileSync(join(clientDir, 'assets', 'app.js'), APP_JS);
});

afterAll(() => {
  rmSync(clientDir, { recursive: true, force: true });
});

function appWithClient(dir = clientDir) {
  return createApp({ store: createBookingStore(), clientDir: dir, staffPassword: 'pw' });
}

describe('serving the React app', () => {
  it('serves index.html at the start page', async () => {
    const response = await request(appWithClient()).get('/');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    expect(response.text).toContain('<div id="root">');
  });

  it.each(['/book/winter-tasting', '/bookings/KB-ABC234', '/staff'])(
    'serves the app shell for client route %s so that a reload works',
    async (path) => {
      const response = await request(appWithClient()).get(path);

      expect(response.status).toBe(200);
      expect(response.text).toContain('<div id="root">');
    },
  );

  it('serves built static assets from the client directory', async () => {
    const response = await request(appWithClient()).get('/assets/app.js');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/javascript/);
    expect(response.text).toBe(APP_JS);
  });

  it('answers a missing static file with 404 instead of the app shell', async () => {
    const response = await request(appWithClient()).get('/assets/missing.js');

    expect(response.status).toBe(404);
    expect(response.text).not.toContain('<div id="root">');
  });

  it('keeps API routes returning JSON, not the app shell', async () => {
    const response = await request(appWithClient()).get('/api/tastings');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/application\/json/);
  });

  it('does not serve the app shell for non-GET requests', async () => {
    const response = await request(appWithClient()).post('/book/winter-tasting').send({});

    expect(response.status).toBe(404);
  });

  it('tells the operator to build when the client has not been built', async () => {
    const response = await request(appWithClient(join(clientDir, 'missing'))).get('/');

    expect(response.status).toBe(503);
    expect(response.text).toContain('npm run build');
  });

  it('still answers the API when the client has not been built', async () => {
    const response = await request(appWithClient(join(clientDir, 'missing'))).get('/api/tastings');

    expect(response.status).toBe(200);
  });
});

describe('errors outside the API', () => {
  it('answers malformed JSON on a non-API path with a plain 400 and no stack trace', async () => {
    const response = await request(appWithClient()).post('/anything').set('Content-Type', 'application/json').send('{"a":');

    expect(response.status).toBe(400);
    expect(response.headers['content-type']).toMatch(/text\/plain/);
    expect(response.text).toBe('Request body must be valid JSON.');
    expect(response.text).not.toMatch(/node_modules|\n\s+at /);
  });
});

describe('staff area headers', () => {
  it('asks search engines not to index the staff page', async () => {
    const response = await request(appWithClient()).get('/staff');

    expect(response.headers['x-robots-tag']).toBe('noindex, nofollow');
  });

  it('does not add the noindex header to the public pages', async () => {
    const response = await request(appWithClient()).get('/');

    expect(response.headers['x-robots-tag']).toBeUndefined();
  });
});
