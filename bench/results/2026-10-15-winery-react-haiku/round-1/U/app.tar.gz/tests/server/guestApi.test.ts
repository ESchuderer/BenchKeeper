import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { createBookingStore } from '../../src/server/bookingStore.js';
import type { TastingDefinition } from '../../src/shared/tastings.js';

const CATALOGUE: TastingDefinition[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', pricePerGuest: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', date: '2026-11-14', time: '15:00', pricePerGuest: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', date: '2026-12-05', time: '17:00', pricePerGuest: 28, seats: 3 },
];

const validBooking = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

function setup() {
  const store = createBookingStore({ tastings: CATALOGUE });
  const app = createApp({ store });
  return { app, store };
}

function seatsLeftFor(tastingId: string, store: ReturnType<typeof createBookingStore>): number | undefined {
  return store.getTasting(tastingId)?.seatsLeft;
}

describe('GET /api/tastings', () => {
  it('lists every tasting with its seats left', async () => {
    const { app } = setup();

    const response = await request(app).get('/api/tastings');

    expect(response.status).toBe(200);
    expect(response.body.tastings).toEqual([
      expect.objectContaining({ id: 'riesling-evening', title: 'Riesling Evening', seatsLeft: 12 }),
      expect.objectContaining({ id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', seatsLeft: 8 }),
      expect.objectContaining({ id: 'winter-tasting', title: 'Winter Tasting', seatsLeft: 3 }),
    ]);
  });

  it('reflects seats taken by existing bookings', async () => {
    const { app } = setup();
    await request(app).post('/api/tastings/riesling-evening/bookings').send(validBooking);

    const response = await request(app).get('/api/tastings');

    expect(response.body.tastings[0]).toMatchObject({ id: 'riesling-evening', seatsLeft: 10 });
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and returns the confirmation details with status 201', async () => {
    const { app } = setup();

    const response = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send(validBooking);

    expect(response.status).toBe(201);
    expect(response.body.booking).toEqual({
      reference: expect.stringMatching(/^KB-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}$/),
      tastingTitle: 'Red Wine Cellar Tour',
      date: '2026-11-14',
      time: '15:00',
      guests: 2,
      pricePerGuest: 32,
      total: 64,
    });
  });

  it('takes the booked seats from the tasting', async () => {
    const { app, store } = setup();

    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...validBooking, guests: 2 });

    expect(seatsLeftFor('winter-tasting', store)).toBe(1);
  });

  it('accepts guests sent as text, as a browser form sends them', async () => {
    const { app } = setup();

    const response = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...validBooking, guests: '4' });

    expect(response.status).toBe(201);
    expect(response.body.booking.guests).toBe(4);
  });

  it('rejects invalid input with status 400 and an error for each invalid field', async () => {
    const { app, store } = setup();

    const response = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: '', email: 'anna@example', guests: 9 });

    expect(response.status).toBe(400);
    expect(response.body).toEqual({
      error: 'Please correct the highlighted fields.',
      fieldErrors: {
        name: 'Please enter your name.',
        email: 'Please enter a valid email address.',
        guests: 'Guests must be a whole number from 1 to 8.',
      },
    });
    expect(seatsLeftFor('riesling-evening', store)).toBe(12);
  });

  it('rejects a request for more guests than seats left with status 409 and a message for the guests field', async () => {
    const { app, store } = setup();
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...validBooking, guests: 2 });

    const response = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ ...validBooking, guests: 3 });

    expect(response.status).toBe(409);
    expect(response.body.fieldErrors).toEqual({ guests: 'Only 1 seat left for this tasting.' });
    expect(seatsLeftFor('winter-tasting', store)).toBe(1);
  });

  it('rejects a booking for a fully booked tasting with status 409', async () => {
    const { app } = setup();
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...validBooking, guests: 3 });

    const response = await request(app).post('/api/tastings/winter-tasting/bookings').send(validBooking);

    expect(response.status).toBe(409);
    expect(response.body.error).toBe('This tasting is fully booked.');
  });

  it('returns 404 for a tasting that does not exist', async () => {
    const { app } = setup();

    const response = await request(app).post('/api/tastings/no-such-tasting/bookings').send(validBooking);

    expect(response.status).toBe(404);
    expect(response.body.error).toBe('That tasting does not exist.');
  });

  it('never oversells when two requests arrive at the same time', async () => {
    const { app, store } = setup();

    const [first, second] = await Promise.all([
      request(app).post('/api/tastings/winter-tasting/bookings').send({ ...validBooking, guests: 2 }),
      request(app).post('/api/tastings/winter-tasting/bookings').send({ ...validBooking, guests: 2 }),
    ]);

    expect([first.status, second.status].sort()).toEqual([201, 409]);
    expect(seatsLeftFor('winter-tasting', store)).toBe(1);
  });

  it('answers a booking body that is not a JSON object with 400 and a message, not a field error', async () => {
    const { app } = setup();

    const response = await request(app).post('/api/tastings/riesling-evening/bookings').send([]);

    expect(response.status).toBe(400);
    expect(response.body).toEqual({ error: 'Please send the booking as a JSON object.' });
  });

  it('returns 400 when the request body is not valid JSON', async () => {
    const { app } = setup();

    const response = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ');

    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Request body must be valid JSON.');
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the confirmation details without the guest email', async () => {
    const { app } = setup();
    const created = await request(app).post('/api/tastings/riesling-evening/bookings').send(validBooking);

    const response = await request(app).get(`/api/bookings/${created.body.booking.reference}`);

    expect(response.status).toBe(200);
    expect(response.body.booking).toEqual(created.body.booking);
    expect(JSON.stringify(response.body)).not.toContain('anna@example.com');
  });

  it('returns 404 with a message when no booking has that reference', async () => {
    const { app } = setup();

    const response = await request(app).get('/api/bookings/KB-ZZZZZZ');

    expect(response.status).toBe(404);
    expect(response.body).toEqual({ error: 'No booking was found for that reference.' });
  });
});

describe('API responses', () => {
  it('returns a JSON 404 for unknown API paths', async () => {
    const { app } = setup();

    const response = await request(app).get('/api/unknown');

    expect(response.status).toBe(404);
    expect(response.headers['content-type']).toMatch(/application\/json/);
  });

  it('sends security headers from helmet', async () => {
    const { app } = setup();

    const response = await request(app).get('/api/tastings');

    expect(response.headers['x-content-type-options']).toBe('nosniff');
    expect(response.headers['content-security-policy']).toContain("default-src 'self'");
  });
});
