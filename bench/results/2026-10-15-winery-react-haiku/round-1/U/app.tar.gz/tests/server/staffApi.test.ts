import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app.js';
import { createBookingStore } from '../../src/server/bookingStore.js';
import type { TastingDefinition } from '../../src/shared/tastings.js';

const PASSWORD = 'correct horse battery';

const CATALOGUE: TastingDefinition[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', pricePerGuest: 25, seats: 12 },
  { id: 'winter-tasting', title: 'Winter Tasting', date: '2026-12-05', time: '17:00', pricePerGuest: 28, seats: 3 },
];

const EIGHT_HOURS_MS = 8 * 60 * 60 * 1000;

function setup(options: { staffPassword?: string; clock?: { now: number } } = {}) {
  const store = createBookingStore({ tastings: CATALOGUE });
  const clock = options.clock ?? { now: Date.parse('2026-10-15T10:00:00Z') };
  const app = createApp({
    store,
    staffPassword: 'staffPassword' in options ? options.staffPassword : PASSWORD,
    now: () => clock.now,
  });
  return { app, store, clock };
}

/** Signs in and returns the Cookie header value for later requests. */
async function signIn(app: ReturnType<typeof createApp>, password = PASSWORD): Promise<string> {
  const response = await request(app).post('/api/staff/session').send({ password });
  expect(response.status).toBe(200);
  const setCookie = response.headers['set-cookie'] as unknown as string[];
  return setCookie[0].split(';')[0];
}

async function bookSeats(app: ReturnType<typeof createApp>, tastingId: string, guests: number): Promise<string> {
  const response = await request(app)
    .post(`/api/tastings/${tastingId}/bookings`)
    .send({ name: 'Ben Hofmann', email: 'ben@example.com', guests });
  expect(response.status).toBe(201);
  return response.body.booking.reference;
}

describe('POST /api/staff/session (sign in)', () => {
  it('returns 503 and issues no session when STAFF_PASSWORD is not configured', async () => {
    const { app } = setup({ staffPassword: undefined });

    const response = await request(app).post('/api/staff/session').send({ password: 'anything' });

    expect(response.status).toBe(503);
    expect(response.body.error).toBe('Staff sign-in is not configured.');
    expect(response.headers['set-cookie']).toBeUndefined();
  });

  it('returns 503 when STAFF_PASSWORD is an empty string', async () => {
    const { app } = setup({ staffPassword: '' });

    const response = await request(app).post('/api/staff/session').send({ password: '' });

    expect(response.status).toBe(503);
  });

  it('rejects a wrong password with 401, an error next to the password field and no cookie', async () => {
    const { app } = setup();

    const response = await request(app).post('/api/staff/session').send({ password: 'guess' });

    expect(response.status).toBe(401);
    expect(response.body).toEqual({
      error: 'Wrong password.',
      fieldErrors: { password: 'Wrong password.' },
    });
    expect(response.headers['set-cookie']).toBeUndefined();
  });

  it('rejects a missing password with 401', async () => {
    const { app } = setup();

    const response = await request(app).post('/api/staff/session').send({});

    expect(response.status).toBe(401);
  });

  it('rejects a password that only differs by a trailing character', async () => {
    const { app } = setup();

    const response = await request(app).post('/api/staff/session').send({ password: `${PASSWORD}!` });

    expect(response.status).toBe(401);
  });

  it('issues an HttpOnly, SameSite=Strict session cookie for the correct password', async () => {
    const { app } = setup();

    const response = await request(app).post('/api/staff/session').send({ password: PASSWORD });

    expect(response.status).toBe(200);
    expect(response.body).toEqual({ signedIn: true });
    const setCookie = response.headers['set-cookie'] as unknown as string[];
    expect(setCookie[0]).toMatch(/^kb_staff=[A-Za-z0-9_-]{40,}/);
    expect(setCookie[0]).toMatch(/HttpOnly/i);
    expect(setCookie[0]).toMatch(/SameSite=Strict/i);
  });

  it('answers with Cache-Control: no-store', async () => {
    const { app } = setup();

    const response = await request(app).post('/api/staff/session').send({ password: 'guess' });

    expect(response.headers['cache-control']).toBe('no-store');
  });
});

describe('GET /api/staff/session', () => {
  it('reports that nobody is signed in without a session cookie', async () => {
    const { app } = setup();

    const response = await request(app).get('/api/staff/session');

    expect(response.status).toBe(200);
    expect(response.body).toEqual({ signedIn: false });
  });

  it('reports a signed-in staff member', async () => {
    const { app } = setup();
    const cookie = await signIn(app);

    const response = await request(app).get('/api/staff/session').set('Cookie', cookie);

    expect(response.body).toEqual({ signedIn: true });
  });
});

describe('GET /api/staff/bookings', () => {
  it('refuses booking data without a session', async () => {
    const { app } = setup();
    await bookSeats(app, 'riesling-evening', 2);

    const response = await request(app).get('/api/staff/bookings');

    expect(response.status).toBe(401);
    expect(response.body).toEqual({ error: 'Please sign in to see bookings.' });
    expect(JSON.stringify(response.body)).not.toContain('ben@example.com');
  });

  it('refuses booking data with a forged session cookie', async () => {
    const { app } = setup();

    const response = await request(app)
      .get('/api/staff/bookings')
      .set('Cookie', 'kb_staff=not-a-real-session-token');

    expect(response.status).toBe(401);
  });

  it('lists bookings grouped by tasting with name, email, guests and reference', async () => {
    const { app } = setup();
    const reference = await bookSeats(app, 'riesling-evening', 2);
    const cookie = await signIn(app);

    const response = await request(app).get('/api/staff/bookings').set('Cookie', cookie);

    expect(response.status).toBe(200);
    expect(response.body.groups).toEqual([
      {
        tasting: expect.objectContaining({ id: 'riesling-evening', title: 'Riesling Evening', seatsLeft: 10 }),
        bookings: [{ reference, name: 'Ben Hofmann', email: 'ben@example.com', guests: 2 }],
      },
      {
        tasting: expect.objectContaining({ id: 'winter-tasting', title: 'Winter Tasting', seatsLeft: 3 }),
        bookings: [],
      },
    ]);
  });

  it('is never cached', async () => {
    const { app } = setup();
    const cookie = await signIn(app);

    const response = await request(app).get('/api/staff/bookings').set('Cookie', cookie);

    expect(response.headers['cache-control']).toBe('no-store');
  });
});

describe('DELETE /api/staff/bookings/:reference (cancel)', () => {
  it('refuses to cancel without a session and keeps the booking', async () => {
    const { app, store } = setup();
    const reference = await bookSeats(app, 'winter-tasting', 3);

    const response = await request(app).delete(`/api/staff/bookings/${reference}`);

    expect(response.status).toBe(401);
    expect(store.getBooking(reference)).toBeDefined();
  });

  it('cancels the booking with status 204 and frees its seats for guests', async () => {
    const { app } = setup();
    const reference = await bookSeats(app, 'winter-tasting', 3);
    const cookie = await signIn(app);
    const before = await request(app).get('/api/tastings');
    expect(before.body.tastings[1].seatsLeft).toBe(0);

    const response = await request(app).delete(`/api/staff/bookings/${reference}`).set('Cookie', cookie);

    expect(response.status).toBe(204);
    const after = await request(app).get('/api/tastings');
    expect(after.body.tastings[1].seatsLeft).toBe(3);
  });

  it('removes the cancelled booking from the staff list', async () => {
    const { app } = setup();
    const reference = await bookSeats(app, 'riesling-evening', 1);
    const cookie = await signIn(app);

    await request(app).delete(`/api/staff/bookings/${reference}`).set('Cookie', cookie);

    const list = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(list.body.groups[0].bookings).toEqual([]);
  });

  it('returns 404 when the reference does not exist or was already cancelled', async () => {
    const { app } = setup();
    const reference = await bookSeats(app, 'riesling-evening', 1);
    const cookie = await signIn(app);
    await request(app).delete(`/api/staff/bookings/${reference}`).set('Cookie', cookie);

    const again = await request(app).delete(`/api/staff/bookings/${reference}`).set('Cookie', cookie);
    const unknown = await request(app).delete('/api/staff/bookings/KB-ZZZZZZ').set('Cookie', cookie);

    expect(again.status).toBe(404);
    expect(unknown.status).toBe(404);
    expect(again.body).toEqual({ error: 'No booking was found for that reference.' });
  });
});

describe('DELETE /api/staff/session (sign out)', () => {
  it('ends the session so a previously issued cookie no longer returns booking data', async () => {
    const { app } = setup();
    const cookie = await signIn(app);

    const signOut = await request(app).delete('/api/staff/session').set('Cookie', cookie);
    const afterwards = await request(app).get('/api/staff/bookings').set('Cookie', cookie);

    expect(signOut.status).toBe(204);
    expect(afterwards.status).toBe(401);
  });
});

describe('staff session lifetime', () => {
  it('stays valid for 8 hours', async () => {
    const { app, clock } = setup();
    const cookie = await signIn(app);

    clock.now += EIGHT_HOURS_MS - 1000;

    const response = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(response.status).toBe(200);
  });

  it('expires after 8 hours', async () => {
    const { app, clock } = setup();
    const cookie = await signIn(app);

    clock.now += EIGHT_HOURS_MS + 1000;

    const response = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(response.status).toBe(401);
  });
});

describe('sign-in rate limit', () => {
  it('allows 10 failed attempts and refuses further attempts for 15 minutes', async () => {
    const { app } = setup();

    for (let attempt = 0; attempt < 10; attempt++) {
      const response = await request(app).post('/api/staff/session').send({ password: 'guess' });
      expect(response.status).toBe(401);
    }
    const blocked = await request(app).post('/api/staff/session').send({ password: 'guess' });

    expect(blocked.status).toBe(429);
    expect(blocked.body.error).toMatch(/too many/i);
  });

  it('does not count successful sign-ins against the limit', async () => {
    const { app } = setup();

    for (let attempt = 0; attempt < 12; attempt++) {
      const response = await request(app).post('/api/staff/session').send({ password: PASSWORD });
      expect(response.status).toBe(200);
    }
  });
});
