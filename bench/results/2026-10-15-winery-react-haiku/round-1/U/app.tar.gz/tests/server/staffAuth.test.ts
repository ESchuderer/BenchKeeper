import { describe, expect, it } from 'vitest';
import { SESSION_TTL_MS, createStaffSessions, passwordMatches } from '../../src/server/staffAuth.js';

describe('createStaffSessions', () => {
  it('issues a session that is valid until it expires', () => {
    let now = 0;
    const sessions = createStaffSessions(() => now);
    const token = sessions.create();

    now = SESSION_TTL_MS - 1;
    expect(sessions.isValid(token)).toBe(true);
    now = SESSION_TTL_MS;
    expect(sessions.isValid(token)).toBe(false);
  });

  it('forgets expired sessions when a new session is created', () => {
    let now = 0;
    const sessions = createStaffSessions(() => now);
    sessions.create();
    sessions.create();
    expect(sessions.size()).toBe(2);

    now = SESSION_TTL_MS + 1;
    sessions.create();

    expect(sessions.size()).toBe(1);
  });

  it('keeps sessions that have not expired when a new session is created', () => {
    let now = 0;
    const sessions = createStaffSessions(() => now);
    const older = sessions.create();

    now = SESSION_TTL_MS / 2;
    sessions.create();

    expect(sessions.isValid(older)).toBe(true);
    expect(sessions.size()).toBe(2);
  });
});

describe('passwordMatches', () => {
  it('accepts only the exact password', () => {
    expect(passwordMatches('s3cret', 's3cret')).toBe(true);
    expect(passwordMatches('s3cret ', 's3cret')).toBe(false);
    expect(passwordMatches('', 's3cret')).toBe(false);
  });
});
