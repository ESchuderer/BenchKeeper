import { describe, expect, it } from 'vitest';
import { bookingFormSchema } from '../../src/shared/bookingSchema.js';

const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: '2' };

function errorsFor(input: unknown): Record<string, string> {
  const result = bookingFormSchema.safeParse(input);
  if (result.success) return {};
  const errors: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const field = String(issue.path[0]);
    errors[field] ??= issue.message;
  }
  return errors;
}

describe('bookingFormSchema', () => {
  it('accepts a complete booking and converts guests to a number', () => {
    const result = bookingFormSchema.parse(valid);
    expect(result).toEqual({ name: 'Anna Keller', email: 'anna@example.com', guests: 2 });
  });

  it('trims surrounding whitespace from name and email', () => {
    const result = bookingFormSchema.parse({ ...valid, name: '  Anna  ', email: ' anna@example.com ' });
    expect(result.name).toBe('Anna');
    expect(result.email).toBe('anna@example.com');
  });

  it('requires a name', () => {
    expect(errorsFor({ ...valid, name: '   ' })).toEqual({ name: 'Please enter your name.' });
  });

  it('rejects names longer than 100 characters', () => {
    expect(errorsFor({ ...valid, name: 'a'.repeat(101) })).toEqual({
      name: 'Name must be 100 characters or fewer.',
    });
  });

  it('requires an email address', () => {
    expect(errorsFor({ ...valid, email: '' })).toEqual({
      email: 'Please enter your email address.',
    });
  });

  it('rejects an email address that is not valid', () => {
    expect(errorsFor({ ...valid, email: 'anna@example' })).toEqual({
      email: 'Please enter a valid email address.',
    });
  });

  it('requires the number of guests', () => {
    expect(errorsFor({ ...valid, guests: '' })).toEqual({
      guests: 'Please enter the number of guests.',
    });
  });

  it.each([
    ['0', 0],
    ['9', 9],
    ['-1', -1],
  ])('rejects guests outside 1 to 8 (%s)', (guests) => {
    expect(errorsFor({ ...valid, guests })).toEqual({
      guests: 'Guests must be a whole number from 1 to 8.',
    });
  });

  it('rejects guests that are not a whole number', () => {
    expect(errorsFor({ ...valid, guests: '2.5' })).toEqual({
      guests: 'Guests must be a whole number from 1 to 8.',
    });
  });

  it.each(['0x2', '1e0', '2 3', '+2', '-0'])('rejects guests written in a form other than plain digits (%s)', (guests) => {
    expect(errorsFor({ ...valid, guests })).toEqual({
      guests: 'Guests must be a whole number from 1 to 8.',
    });
  });

  it('rejects guests that are not a number at all', () => {
    expect(errorsFor({ ...valid, guests: 'two' })).toEqual({
      guests: 'Guests must be a whole number from 1 to 8.',
    });
  });

  it('accepts the boundaries 1 and 8', () => {
    expect(errorsFor({ ...valid, guests: '1' })).toEqual({});
    expect(errorsFor({ ...valid, guests: '8' })).toEqual({});
  });

  it('reports every invalid field at once', () => {
    expect(errorsFor({ name: '', email: 'nope', guests: '' })).toEqual({
      name: 'Please enter your name.',
      email: 'Please enter a valid email address.',
      guests: 'Please enter the number of guests.',
    });
  });
});
