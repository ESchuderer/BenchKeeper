import { describe, expect, it } from 'vitest';
import { TASTINGS } from '../../src/shared/tastings.js';
import { formatPrice, formatSeatsLeft, formatWhen } from '../../src/shared/format.js';

describe('tasting catalogue', () => {
  it('offers exactly the three tastings from the brief, in date order', () => {
    expect(TASTINGS).toEqual([
      {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        date: '2026-11-06',
        time: '18:00',
        pricePerGuest: 25,
        seats: 12,
      },
      {
        id: 'red-wine-cellar-tour',
        title: 'Red Wine Cellar Tour',
        date: '2026-11-14',
        time: '15:00',
        pricePerGuest: 32,
        seats: 8,
      },
      {
        id: 'winter-tasting',
        title: 'Winter Tasting',
        date: '2026-12-05',
        time: '17:00',
        pricePerGuest: 28,
        seats: 10,
      },
    ]);
  });
});

describe('formatSeatsLeft', () => {
  it('shows a plural count as "<n> seats left"', () => {
    expect(formatSeatsLeft(8)).toBe('8 seats left');
  });

  it('uses the singular for exactly one seat', () => {
    expect(formatSeatsLeft(1)).toBe('1 seat left');
  });
});

describe('formatPrice', () => {
  it('shows the price per guest in euros', () => {
    expect(formatPrice(25)).toBe('EUR 25');
  });
});

describe('formatWhen', () => {
  it('shows weekday, day, month, year and time in English', () => {
    expect(formatWhen('2026-11-06', '18:00')).toBe('Friday, 6 November 2026, 18:00');
  });

  it('does not shift the date for any time of day', () => {
    expect(formatWhen('2026-12-05', '17:00')).toBe('Saturday, 5 December 2026, 17:00');
  });
});
