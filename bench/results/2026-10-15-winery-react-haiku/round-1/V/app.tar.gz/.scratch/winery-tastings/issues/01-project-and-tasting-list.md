# Project scaffold and tasting list

Status: resolved
Blocked by: none

## What to build

Tracer bullet through every layer: Express server, React client, shared catalogue.

- `GET /api/tastings` returns the three tastings with `seatsLeft` (no bookings yet, so `seatsLeft == seats`).
- Start page `/` fetches the list and shows each tasting: title, date and time, "EUR <price> per guest", "<n> seats left", and a "Book <title>" link to `/tastings/:id/book` (the target page can be a placeholder in this ticket).
- `npm run build`, `npm start` (port from `PORT`, default 3000) serve the built client for non-`/api` routes and JSON 404 for unknown `/api` paths.

## Acceptance criteria

- Test (API, supertest): `GET /api/tastings` returns the three tastings with the exact values from the spec.
- Test (component, RTL): start page renders the tastings from a mocked `fetch`, showing "12 seats left" etc. and the "Book Riesling Evening" link.
- Manual: `npm start` then `curl localhost:3000/api/tastings` returns the list.

## Blocked by

None.

## Comments

- Resolved. API tests for the catalogue and static serving, component test for the start page; built app checked over HTTP.
