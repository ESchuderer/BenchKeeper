# Create booking and seat limits (API and booking module)

Status: resolved
Blocked by: 01

## What to build

Booking module (`src/server/bookings.ts`) and the API:

- Create booking: validates `name`, `email`, `guests` with the shared zod schema; checks seats left; stores the booking with a generated reference (`KB-` + 6 chars, unambiguous alphabet).
- `POST /api/tastings/:id/bookings` returns 201 with the confirmation body, 400 with field errors, 404 for unknown tasting, 409 with `errors.guests` when seats are short or the tasting is full.
- `GET /api/bookings/:reference` returns the confirmation body or 404.
- Seats left is computed from active bookings; it can never go negative.

## Acceptance criteria

- Unit tests (booking module): seats left after a booking; a booking for more guests than seats left is rejected and stores nothing; two sequential bookings that together exceed capacity — the second is rejected; references are unique across many bookings and match the format.
- API tests (supertest): 201 body values for the Riesling Evening (2 guests → total EUR 50); 400 field errors for blank name, bad email, guests 0 / 9 / 2.5; 409 when guests exceed seats left; 404 for unknown tasting and unknown reference; `GET /api/tastings` `seatsLeft` decreases after booking.

## Blocked by

- 01

## Comments

- Resolved. Booking module unit tests and API tests; references checked for uniqueness and format over 200 bookings.
