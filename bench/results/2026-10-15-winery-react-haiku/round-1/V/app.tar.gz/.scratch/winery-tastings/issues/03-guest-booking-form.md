# Guest booking form and confirmation page

Status: resolved
Blocked by: 02

## What to build

- `/tastings/:id/book`: heading with the tasting title, date and time, price; fields "Name", "Email", "Guests" (1 to 8, number), button "Book". Built with React Hook Form and the shared zod schema (zod resolver). Each error shows next to its field.
- Server errors (400 / 409) map onto the matching field. A 409 shows "Only <n> seats left for this tasting." on Guests and refreshes the seats left.
- Fully booked tasting: no form; message "This tasting is fully booked." and a link back to the start page.
- On 201, navigate to `/bookings/:reference`.
- `/bookings/:reference` shows heading "Booking confirmed", tasting, guests, total "EUR <total>", reference; unknown reference shows "Booking not found".
- Start page: tastings with zero seats show "Fully booked" and no "Book" link.

## Acceptance criteria

- Component test (RTL, mocked fetch): submitting an empty form shows "Please enter your name.", "Please enter a valid email address.", and the guests message next to their fields; no fetch is sent.
- Component test: a 409 response shows "Only 3 seats left for this tasting." under Guests.
- Component test: the confirmation page renders "Booking confirmed", tasting, guests, total and reference from the mocked response.
- Component test: a tasting with `seatsLeft: 0` shows "Fully booked" and no form.

## Blocked by

- 02

## Comments

- Resolved. Component tests for per-field errors, seat conflict, success path and fully-booked state; E2E journey covers the flow.
