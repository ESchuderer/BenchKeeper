# Staff sign-in

Status: resolved
Blocked by: 01

## What to build

- `POST /api/staff/session` with `{password}` compared against `STAFF_PASSWORD` in constant time. 204 and `staff_session` cookie (random token, in-memory, `HttpOnly`, `SameSite=Strict`) on success; 401 `{error: "Incorrect password."}` otherwise; 429 `{error: "Too many attempts. Try again later."}` after repeated failures (`express-rate-limit`).
- `DELETE /api/staff/session` ends the session (204).
- If `STAFF_PASSWORD` is unset or empty, every sign-in is refused and a warning is logged at startup.
- `/staff` page: "Password" field and "Sign in" button when signed out; shows the error text on failure; after sign-in shows a placeholder list and a "Sign out" button.

## Acceptance criteria

- API tests: correct password → 204 and a `Set-Cookie` with `HttpOnly` and `SameSite=Strict`; wrong password → 401; empty `STAFF_PASSWORD` → 401 even for an empty password; the attempt limit returns 429.
- API test: `DELETE` invalidates the cookie, which then gets 401 on `GET /api/staff/bookings` (once ticket 05 exists; for this ticket test sign-out with a session-protected probe route is enough).
- Component test: wrong password shows "Incorrect password." next to the Password field.

## Blocked by

- 01

## Comments

- Resolved. Sign-in, cookie flags, empty STAFF_PASSWORD, rate limit and session check covered by API tests; sign-in page covered by component tests. Added GET /api/staff/session.
