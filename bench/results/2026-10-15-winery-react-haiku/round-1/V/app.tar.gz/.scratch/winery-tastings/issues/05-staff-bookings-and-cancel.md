# Staff bookings list and cancel

Status: resolved
Blocked by: 02, 04

## What to build

- `GET /api/staff/bookings` (signed-in only, 401 otherwise): tastings with `seats`, `seatsLeft` and `bookings: [{reference, name, email, guests}]`.
- `DELETE /api/staff/bookings/:reference` (signed-in only): removes the booking, 204; 404 if unknown.
- `/staff` (signed in): bookings grouped by tasting with name, email, guests and reference; each booking has a "Cancel" button which removes it from the list and frees its seats; a tasting with no bookings says "No bookings yet."

## Acceptance criteria

- API tests: unauthenticated requests get 401; grouped list contains the booking under the right tasting; cancel returns 204, the booking is gone from the list, and `seatsLeft` on `GET /api/tastings` goes back up; cancelling twice gives 404.
- Component test: list renders name, email, guests, reference per tasting; clicking "Cancel" calls the DELETE endpoint and removes the row.

## Blocked by

- 02
- 04

## Comments

- Resolved. Cancel frees seats in unit and API tests; list and cancel covered by component tests and the E2E journey.
