# Visual design, mobile layout and end-to-end journey

Status: resolved
Blocked by: 03, 05

## What to build

- Winery look: cream background, deep wine-red accents, vine-green secondary, gold hairlines, serif headings with a system serif stack (no external fonts), tasting cards, consistent buttons, form controls and error text (red with an icon-free text label), clear success banner, "Fully booked" badge, visible focus rings.
- Layouts usable at 375 px: single column, tap targets ≥ 44 px, no horizontal scroll.
- Not-found page for unknown client routes.
- Playwright end-to-end test against the built app: guest books 2 guests in Riesling Evening (sees confirmation with EUR 50 total), start page shows 10 seats left, staff signs in with the password, sees the booking under Riesling Evening, cancels it, and the start page shows 12 seats left again. Also a 375 px viewport check.
- Screenshots of the start page, booking form with errors, confirmation, staff list at 375 px and desktop, reviewed by eye.

## Acceptance criteria

- Playwright journey passes in a headless browser.
- Screenshots show no overflow at 375 px and the error/success/fully-booked states are visually distinct.
- README documents the commands and the `STAFF_PASSWORD` / `PORT` variables.

## Blocked by

- 03
- 05

## Comments

- Resolved. Playwright journey passes at 375 px; screenshots of start, errors, confirmation and staff list reviewed; README written.
