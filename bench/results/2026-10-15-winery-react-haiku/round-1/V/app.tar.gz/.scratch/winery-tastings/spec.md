# Winery tasting bookings

Status: resolved

## Goal

Weingut Kieselbrunnen, a family winery, needs a small website where guests can book wine tastings online and staff can see and manage the bookings. The site must look like the winery's own site and work on a phone.

## Users

- **Guests**: browse the tastings, book seats, see a booking reference.
- **Staff**: sign in with a shared password, see every booking per tasting, cancel a booking (which frees its seats).

## Catalogue (fixed in code, no admin UI)

| id | Title | Date | Time | Price per guest | Seats |
|---|---|---|---|---|---|
| `riesling-evening` | Riesling Evening | 2026-11-06 | 18:00 | EUR 25 | 12 |
| `red-wine-cellar-tour` | Red Wine Cellar Tour | 2026-11-14 | 15:00 | EUR 32 | 8 |
| `winter-tasting` | Winter Tasting | 2026-12-05 | 17:00 | EUR 28 | 10 |

Dates are the winery's local time. They are displayed without a time-zone conversion (e.g. "Fri 6 Nov 2026, 18:00").

## Pages (client routes)

| Route | Page |
|---|---|
| `/` | Start page: heading, tasting cards with title, date and time, price per guest ("EUR 25 per guest"), seats left ("<n> seats left"), and a "Book <title>" link. |
| `/tastings/:id/book` | Booking form for one tasting. Fields "Name", "Email", "Guests" (1 to 8), button "Book". |
| `/bookings/:reference` | Confirmation: heading "Booking confirmed", tasting, number of guests, total price ("EUR <total>"), booking reference. |
| `/staff` | Without a session: "Password" field and "Sign in" button. With a session: bookings grouped by tasting (name, email, guests, reference), each with a "Cancel" button, and a "Sign out" button. |

Unknown routes show a "Page not found" page with a link back to the start page.

A tasting with zero seats left shows the label "Fully booked" on the start page, no "Book" link, and the booking page for it says the tasting is fully booked and offers no form.

## Booking rules

- Name: required, trimmed, 1 to 80 characters. Error: "Please enter your name."
- Email: required, must look like an email address, max 254 characters. Error: "Please enter a valid email address."
- Guests: whole number from 1 to 8. Error: "Please choose between 1 and 8 guests."
- Guests may not exceed seats left. Error on the Guests field: "Only <n> seats left for this tasting." (`<n>` is the current seats left.)
- Seats left = seats − sum of guests of all active bookings for that tasting.
- Total = guests × price per guest.
- Reference: `KB-` followed by 6 characters from an unambiguous uppercase alphanumeric alphabet (no 0/O/1/I), generated randomly and unique.
- Validation runs on the client for immediate feedback and again on the server, which is authoritative. Server validation errors are shown next to the field they concern. A seat conflict discovered by the server (another guest booked first) shows the new seats-left message on the Guests field.

## Staff rules

- The password comes from the environment variable `STAFF_PASSWORD`. Comparison is constant-time.
- If `STAFF_PASSWORD` is unset or empty, sign-in always fails and the server logs a warning at startup. The site still starts.
- Wrong password: "Incorrect password." Repeated failures from one client are rate-limited (429, message "Too many attempts. Try again later.").
- A successful sign-in creates a random session token held in memory and stored in an `HttpOnly`, `SameSite=Strict` cookie named `staff_session`. Sign-out removes it.
- Cancelling removes the booking, so its seats are free again immediately. Confirm the result on screen: the booking disappears from the list.

## Storage

Bookings are kept in memory. The app starts with no bookings; restarting it clears them. No external services.

## Non-goals

- Payments, booking edits, waiting lists, email sending, multiple staff accounts, an admin UI for the catalogue, internationalisation (English only).

## Technical decisions

- Node.js 22, TypeScript throughout.
- Server: Express 5, `cookie-parser` for the session cookie, `express-rate-limit` for sign-in attempts, `zod` for request validation.
- Client: React 19, Vite, React Router (library mode), React Hook Form with the zod resolver, Tailwind CSS v4 for styling.
- Shared zod schemas in `src/shared/` are used by the client form and by the server route, so the rules are written once.
- Build: `npm run build` produces `dist/client` (Vite) and `dist/server` (tsc). `npm start` runs `node dist/server/index.js`, which serves the API under `/api` and the built client for every other route. Port from `PORT`, default 3000.
- No `GLOSSARY.md` or ADRs exist yet; the domain terms used are: tasting, booking, reference, seats left, guests, staff session.

## HTTP API

| Method and path | Purpose | Responses |
|---|---|---|
| `GET /api/tastings` | List tastings with `seatsLeft` | 200 `[{id, title, date, time, priceEur, seats, seatsLeft}]` |
| `POST /api/tastings/:id/bookings` body `{name, email, guests}` | Create a booking | 201 `{reference, tastingId, tastingTitle, date, time, guests, priceEur, totalEur}`; 400 `{errors: {name?, email?, guests?}}`; 404 unknown tasting; 409 `{errors: {guests}}` when seats are short or the tasting is fully booked |
| `GET /api/bookings/:reference` | Booking details for the confirmation page | 200 same shape as the 201 body; 404 |
| `POST /api/staff/session` body `{password}` | Sign in | 204 + `staff_session` cookie; 401 `{error}`; 429 `{error}` |
| `GET /api/staff/session` | Whether the caller is signed in (used by `/staff` on load) | 200 `{signedIn: true}`; 401 |
| `DELETE /api/staff/session` | Sign out | 204 |
| `GET /api/staff/bookings` | Bookings grouped by tasting (signed-in only) | 200 `[{id, title, date, time, seats, seatsLeft, bookings: [{reference, name, email, guests}]}]`; 401 |
| `DELETE /api/staff/bookings/:reference` | Cancel a booking (signed-in only) | 204; 401; 404 |

Malformed JSON bodies get a JSON 400 `{error}`.

Responses to unknown `/api` paths are 404 JSON.

## Acceptance criteria

1. The start page lists the three tastings with title, date and time, price per guest and "<n> seats left", and each has a "Book <title>" link.
2. The booking form shows Name, Email, Guests and Book, and every rejected input shows its error next to its own field.
3. A booking for more guests than seats left is rejected, both in the form and by the server, and never leaves seats negative.
4. A valid booking shows "Booking confirmed" with tasting, guests, total price and reference; the start page then shows the reduced seats left.
5. A fully booked tasting is clearly marked and cannot be booked.
6. `/staff` requires the `STAFF_PASSWORD` password; wrong passwords are refused with a message; sign-in is rate-limited.
7. Signed in, staff see every active booking grouped by tasting, and "Cancel" removes it and frees its seats.
8. The site is usable at 375 px width and looks like a winery site (palette, serif headings, consistent cards and buttons, visible focus states).
9. `npm install`, `npm run build`, `npm test`, `npm start` work on Node.js 22 with no external services.

## Seams under test

Agreed up front (per the TDD skill; the user's brief is the agreement, and these are the only places tests are written):

1. **Booking module** (`src/server/bookings.ts`): create, cancel, seats left, listing, validation of seat limits. Tested through its exported functions with an in-memory store.
2. **HTTP API** (`src/server/app.ts` via `supertest`): every endpoint in the table above, including auth, cookies, rate limit, and error shapes.
3. **Booking form and staff page components** (React Testing Library, network mocked at `fetch`): per-field error display, fully-booked state, sign-in error, cancel updates the list.
4. **End-to-end journey** (Playwright, real server, real browser): guest books, confirmation appears, staff signs in, sees and cancels the booking, plus a 375 px viewport check and screenshots reviewed by eye.

## Decisions taken during implementation

- Seats wording: "1 seat left" for one seat, "<n> seats left" otherwise.
- Date wording: "Fri, 6 Nov 2026, 18:00" (en-GB, no time-zone conversion).
- Prices read "EUR 25 per guest" on the start page and "EUR 50" for a total.
- The confirmation endpoint returns no names or emails; staff listings do.
- Unknown client routes render a "Page not found" page inside the app shell.

## Out of scope for tests

Visual pixel comparison, Tailwind class names, and the private helpers of the store.
