# Weingut Kieselbrunnen · tasting bookings

A small website for the family winery: guests book wine tastings online, staff see and cancel the bookings.

- Guests: browse the tastings, book seats, get a booking reference.
- Staff (`/staff`): sign in with the shared password, see every booking grouped by tasting, cancel a booking to free its seats.

The feature spec and the implementation tickets live in [`.scratch/winery-tastings/`](.scratch/winery-tastings/spec.md).

## Requirements

- Node.js 22

## Run it

```bash
npm install
npm run build
STAFF_PASSWORD=choose-a-password PORT=3000 npm start
```

Open http://localhost:3000. `PORT` defaults to `3000`.

| Variable         | Purpose                                                                                           |
| ---------------- | ------------------------------------------------------------------------------------------------- |
| `STAFF_PASSWORD` | Password for `/staff`. If unset or empty, staff sign-in is refused and the server logs a warning. |
| `PORT`           | Port the server listens on (default `3000`).                                                      |

Bookings are kept in memory: the app starts with no bookings, and restarting it clears them.

## Develop

```bash
npm run dev:api   # API on PORT (default 3000), restarts on change
npm run dev       # Vite on http://localhost:5173, proxies /api to the API
```

The tastings on offer are fixed in [`src/server/catalogue.ts`](src/server/catalogue.ts).

## Test

```bash
npm test            # unit, API (supertest) and component (React Testing Library) tests
npm run typecheck   # TypeScript
npm run test:e2e    # Playwright journey in headless Chromium, on a real build
```

The end-to-end tests need Chromium and its system libraries:

```bash
npx playwright install chromium
npx playwright install-deps chromium   # needs root; installs the system libraries
```

`npm run test:e2e` builds the app and starts it on port 3100 with a test staff password. Screenshots of the phone and desktop layouts are written to `test-results/screenshots/`.

## Layout

```
src/
  shared/     zod booking schema, formatting helpers and types shared by client and server
  server/     Express app: catalogue, booking module, staff sign-in, HTTP routes
  client/     React app: pages, components, API calls, Tailwind styles
tests/
  unit/       booking module
  api/        HTTP endpoints
  components/ React pages with the network mocked at fetch
  e2e/        Playwright journey
```

## Build output

`npm run build` writes the client to `dist/client` (Vite) and the server to `dist/server` (tsc). `npm start` runs `dist/server/index.js`, which serves the API under `/api` and the built client for every other route.
