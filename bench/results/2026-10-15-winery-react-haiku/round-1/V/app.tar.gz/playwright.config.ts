import { defineConfig, devices } from '@playwright/test';

const port = process.env.E2E_PORT ?? '3100';

export default defineConfig({
  testDir: 'tests/e2e',
  timeout: 30_000,
  use: {
    baseURL: `http://localhost:${port}`,
    trace: 'retain-on-failure',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'npm run build && npm start',
    url: `http://localhost:${port}/api/tastings`,
    reuseExistingServer: false,
    env: { PORT: port, STAFF_PASSWORD: 'e2e-staff-pass' },
    timeout: 120_000,
  },
});
