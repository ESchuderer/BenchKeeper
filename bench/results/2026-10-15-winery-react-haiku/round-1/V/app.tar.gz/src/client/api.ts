import type { StaffTastingView, TastingSummary } from '../shared/types.js';
import type { BookingDetails } from '../shared/booking.js';

export async function getTastings(): Promise<TastingSummary[]> {
  const res = await fetch('/api/tastings');
  if (!res.ok) {
    throw new Error(`Could not load tastings (${res.status})`);
  }
  return res.json() as Promise<TastingSummary[]>;
}

export async function getBooking(reference: string): Promise<BookingDetails | null> {
  const res = await fetch(`/api/bookings/${encodeURIComponent(reference)}`);
  if (res.status === 404) {
    return null;
  }
  if (!res.ok) {
    throw new Error(`Could not load booking (${res.status})`);
  }
  return res.json() as Promise<BookingDetails>;
}

export async function getStaffSession(): Promise<boolean> {
  const res = await fetch('/api/staff/session');
  return res.ok;
}

export type SignInResult = 'ok' | 'wrong-password' | 'too-many-attempts' | 'error';

export async function signIn(password: string): Promise<{ result: SignInResult; message?: string }> {
  let res: Response;
  try {
    res = await fetch('/api/staff/session', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ password }),
    });
  } catch {
    return { result: 'error', message: 'Something went wrong. Please try again.' };
  }
  if (res.status === 204) {
    return { result: 'ok' };
  }
  const body = (await res.json().catch(() => ({}))) as { error?: string };
  if (res.status === 401) {
    return { result: 'wrong-password', message: body.error };
  }
  if (res.status === 429) {
    return { result: 'too-many-attempts', message: body.error };
  }
  return { result: 'error', message: 'Something went wrong. Please try again.' };
}

export async function signOut(): Promise<void> {
  await fetch('/api/staff/session', { method: 'DELETE' });
}

export async function getStaffBookings(): Promise<StaffTastingView[] | null> {
  const res = await fetch('/api/staff/bookings');
  if (res.status === 401) {
    return null;
  }
  if (!res.ok) {
    throw new Error(`Could not load bookings (${res.status})`);
  }
  return res.json() as Promise<StaffTastingView[]>;
}

/** Returns false when the session has expired. */
export async function cancelBooking(reference: string): Promise<boolean> {
  const res = await fetch(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' });
  if (res.status === 401) {
    return false;
  }
  if (!res.ok && res.status !== 404) {
    throw new Error(`Could not cancel booking (${res.status})`);
  }
  return true;
}
