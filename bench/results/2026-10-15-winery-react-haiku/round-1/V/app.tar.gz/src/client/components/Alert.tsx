import type { ReactNode } from 'react';

/** A message that must reach the user: errors that are not tied to one field. */
export function Alert({ children }: { children: ReactNode }) {
  return (
    <p role="alert" className="rounded-lg border border-danger/30 bg-danger/5 px-4 py-3 text-danger">
      {children}
    </p>
  );
}
