import { Link, Outlet } from 'react-router';

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-wine text-cream">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-4 py-5">
          <Link to="/" className="font-serif text-xl tracking-wide">
            Weingut Kieselbrunnen
          </Link>
          <span className="hidden text-sm text-cream/80 sm:inline">Family winery · Tastings</span>
        </div>
        <div className="h-1 bg-gold" />
      </header>

      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-10">
        <Outlet />
      </main>

      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-2 px-4 py-6 text-sm text-muted">
          <p>Weingut Kieselbrunnen · Family winery</p>
          <Link to="/staff" className="font-medium text-wine underline underline-offset-4">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}
