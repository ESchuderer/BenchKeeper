import { useEffect, useState } from 'react';
import { cancelBooking, getStaffBookings } from '../api.js';
import { formatSeatsLeft, formatTastingDateTime } from '../../shared/format.js';
import type { StaffTastingView } from '../../shared/types.js';
import { Alert } from './Alert.js';

interface StaffBookingsProps {
  onSessionExpired: () => void;
}

export function StaffBookings({ onSessionExpired }: StaffBookingsProps) {
  const [tastings, setTastings] = useState<StaffTastingView[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [cancelError, setCancelError] = useState<string | null>(null);

  function load() {
    getStaffBookings().then(
      (list) => {
        if (list === null) {
          onSessionExpired();
        } else {
          setTastings(list);
        }
      },
      (err: unknown) => setError(err instanceof Error ? err.message : 'Could not load bookings'),
    );
  }

  useEffect(load, []);

  async function cancel(reference: string) {
    setCancelError(null);
    try {
      const stillSignedIn = await cancelBooking(reference);
      if (!stillSignedIn) {
        onSessionExpired();
        return;
      }
      load();
    } catch {
      setCancelError('Could not cancel the booking. Please try again.');
    }
  }

  if (error) {
    return <Alert>{error}</Alert>;
  }
  if (!tastings) {
    return <p className="text-muted">Loading bookings…</p>;
  }

  return (
    <div className="grid gap-6">
      {cancelError && <Alert>{cancelError}</Alert>}
      {tastings.map((tasting) => (
        <section
          key={tasting.id}
          aria-label={tasting.title}
          className="rounded-2xl border border-line bg-white/70 p-6 shadow-sm"
        >
          <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
            <h2 className="text-2xl">{tasting.title}</h2>
            <p className="text-sm font-semibold text-vine">{formatSeatsLeft(tasting.seatsLeft)}</p>
          </div>
          <p className="mt-1 text-sm text-muted">{formatTastingDateTime(tasting.date, tasting.time)}</p>

          {tasting.bookings.length === 0 ? (
            <p className="mt-4 text-muted">No bookings yet.</p>
          ) : (
            <ul className="mt-4 divide-y divide-line">
              {tasting.bookings.map((booking) => (
                <li key={booking.reference} className="flex flex-wrap items-center gap-x-5 gap-y-2 py-3">
                  <span className="min-w-40 font-semibold">{booking.name}</span>
                  <span className="break-all text-sm text-muted">{booking.email}</span>
                  <span className="text-sm">
                    <span className="text-muted">Guests </span>
                    <span className="font-semibold">{booking.guests}</span>
                  </span>
                  <span className="font-mono text-sm tracking-wider text-wine">{booking.reference}</span>
                  <button
                    type="button"
                    onClick={() => cancel(booking.reference)}
                    className="ml-auto min-h-11 rounded-lg border border-danger px-4 py-2 font-semibold text-danger hover:bg-danger hover:text-cream"
                  >
                    Cancel
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}
    </div>
  );
}
