import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useNavigate, useParams } from 'react-router';
import type { z } from 'zod';
import { getTastings } from '../api.js';
import { Alert } from '../components/Alert.js';
import { TextField } from '../components/TextField.js';
import { bookingInputSchema, type BookingInput } from '../../shared/booking-schema.js';
import { formatEur, formatSeatsLeft, formatTastingDateTime, seatsShortMessage } from '../../shared/format.js';
import type { TastingSummary } from '../../shared/types.js';

const GENERIC_ERROR = 'Something went wrong. Please try again.';

export function BookingPage() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const [tasting, setTasting] = useState<TastingSummary | null | undefined>(undefined);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<z.input<typeof bookingInputSchema>, unknown, BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '', guests: 2 },
  });

  useEffect(() => {
    getTastings().then(
      (all) => setTasting(all.find((t) => t.id === id) ?? null),
      () => setTasting(null),
    );
  }, [id]);

  if (tasting === undefined) {
    return <p className="text-muted">Loading…</p>;
  }
  if (tasting === null) {
    return <Alert>Tasting not found.</Alert>;
  }

  const onSubmit = async (values: BookingInput) => {
    if (values.guests > tasting.seatsLeft) {
      setError('guests', { message: seatsShortMessage(tasting.seatsLeft) });
      return;
    }

    let res: Response;
    try {
      res = await fetch(`/api/tastings/${tasting.id}/bookings`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(values),
      });
    } catch {
      setError('root', { message: GENERIC_ERROR });
      return;
    }

    if (res.status === 201) {
      const booking = (await res.json()) as { reference: string };
      navigate(`/bookings/${booking.reference}`);
      return;
    }

    if (res.status === 400 || res.status === 409) {
      const body = (await res.json()) as {
        errors?: Partial<Record<keyof BookingInput, string>>;
        seatsLeft?: number;
      };
      for (const [field, message] of Object.entries(body.errors ?? {})) {
        setError(field as keyof BookingInput, { message });
      }
      if (typeof body.seatsLeft === 'number') {
        setTasting({ ...tasting, seatsLeft: body.seatsLeft });
      }
      return;
    }

    setError('root', { message: GENERIC_ERROR });
  };

  const soldOut = tasting.seatsLeft === 0;

  return (
    <section aria-labelledby="booking-heading" className="mx-auto max-w-xl">
      <Link to="/" className="text-sm font-medium text-wine underline underline-offset-4">
        All tastings
      </Link>
      <h1 id="booking-heading" className="mt-4 text-4xl">
        {tasting.title}
      </h1>
      <p className="mt-3 text-muted">
        {formatTastingDateTime(tasting.date, tasting.time)} · {formatEur(tasting.priceEur)} per guest ·{' '}
        {formatSeatsLeft(tasting.seatsLeft)}
      </p>

      {soldOut ? (
        <div className="mt-8 rounded-2xl border border-line bg-white/70 p-6">
          <p className="text-lg font-semibold text-wine">This tasting is fully booked.</p>
          <p className="mt-2 text-muted">Please choose another date.</p>
        </div>
      ) : (
        <form
          noValidate
          onSubmit={handleSubmit(onSubmit)}
          className="mt-8 grid gap-5 rounded-2xl border border-line bg-white/70 p-6 shadow-sm"
        >
          <TextField
            id="name"
            label="Name"
            autoComplete="name"
            error={errors.name?.message}
            {...register('name')}
          />
          <TextField
            id="email"
            label="Email"
            type="email"
            autoComplete="email"
            error={errors.email?.message}
            {...register('email')}
          />
          <TextField
            id="guests"
            label="Guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={Math.min(8, tasting.seatsLeft)}
            error={errors.guests?.message}
            {...register('guests')}
          />
          {errors.root && <Alert>{errors.root.message}</Alert>}
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex min-h-12 w-full items-center justify-center rounded-lg bg-wine px-6 py-3 text-lg font-semibold text-cream hover:bg-wine-dark disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto sm:self-start"
          >
            Book
          </button>
        </form>
      )}
    </section>
  );
}
