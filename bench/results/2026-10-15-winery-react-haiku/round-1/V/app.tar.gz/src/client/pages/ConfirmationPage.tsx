import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { getBooking } from '../api.js';
import { formatEur, formatTastingDateTime } from '../../shared/format.js';
import type { BookingDetails } from '../../shared/booking.js';
import { Alert } from '../components/Alert.js';

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const [booking, setBooking] = useState<BookingDetails | null | undefined>(undefined);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getBooking(reference).then(setBooking, (err: unknown) => {
      setError(err instanceof Error ? err.message : 'Could not load booking');
    });
  }, [reference]);

  if (error) {
    return <Alert>{error}</Alert>;
  }
  if (booking === undefined) {
    return <p className="text-muted">Loading…</p>;
  }
  if (booking === null) {
    return (
      <section className="mx-auto max-w-md text-center">
        <p role="alert" className="text-lg font-semibold text-danger">
          Booking not found
        </p>
        <Link to="/" className="mt-4 inline-block font-medium text-wine underline underline-offset-4">
          Back to all tastings
        </Link>
      </section>
    );
  }

  return (
    <section aria-labelledby="confirmation-heading" className="mx-auto max-w-xl">
      <p className="text-sm font-semibold uppercase tracking-widest text-vine">Thank you</p>
      <h1 id="confirmation-heading" className="mt-2 text-4xl">
        Booking confirmed
      </h1>
      <p className="mt-3 text-muted">
        We look forward to welcoming you. Please keep your booking reference for your visit.
      </p>

      <ul
        aria-label="Booking details"
        className="mt-8 divide-y divide-line rounded-2xl border border-line bg-white/70 px-6 shadow-sm"
      >
        <li className="flex justify-between gap-4 py-4">
          <span className="text-muted">Tasting</span>
          <span className="text-right font-semibold">{booking.tastingTitle}</span>
        </li>
        <li className="flex justify-between gap-4 py-4">
          <span className="text-muted">When</span>
          <span className="text-right font-semibold">
            {formatTastingDateTime(booking.date, booking.time)}
          </span>
        </li>
        <li className="flex justify-between gap-4 py-4">
          <span className="text-muted">Guests</span>
          <span className="text-right font-semibold">{booking.guests}</span>
        </li>
        <li className="flex justify-between gap-4 py-4">
          <span className="text-muted">Total</span>
          <span className="text-right font-semibold">{formatEur(booking.totalEur)}</span>
        </li>
        <li className="flex justify-between gap-4 py-4">
          <span className="text-muted">Reference</span>
          <span className="font-mono text-right text-lg font-semibold tracking-wider text-wine">
            {booking.reference}
          </span>
        </li>
      </ul>

      <Link
        to="/"
        className="mt-8 inline-flex min-h-11 items-center justify-center rounded-lg border border-wine px-5 py-2.5 font-semibold text-wine hover:bg-wine hover:text-cream"
      >
        Back to all tastings
      </Link>
    </section>
  );
}
