import { Link } from 'react-router';

export function NotFoundPage() {
  return (
    <section className="mx-auto max-w-md text-center">
      <h1 className="text-3xl">Page not found</h1>
      <p className="mt-3 text-muted">The page you are looking for is not here.</p>
      <Link
        to="/"
        className="mt-6 inline-flex min-h-11 items-center justify-center rounded-lg bg-wine px-5 py-2.5 font-semibold text-cream hover:bg-wine-dark"
      >
        Back to all tastings
      </Link>
    </section>
  );
}
