import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { getStaffSession, signIn, signOut } from '../api.js';
import { StaffBookings } from '../components/StaffBookings.js';
import { TextField } from '../components/TextField.js';
import { Alert } from '../components/Alert.js';

interface PasswordForm {
  password: string;
}

type Session = 'checking' | 'signed-out' | 'signed-in';

export function StaffPage() {
  const [session, setSession] = useState<Session>('checking');
  const {
    register,
    handleSubmit,
    setError,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<PasswordForm>({ defaultValues: { password: '' } });

  useEffect(() => {
    getStaffSession().then(
      (signedIn) => setSession(signedIn ? 'signed-in' : 'signed-out'),
      () => setSession('signed-out'),
    );
  }, []);

  async function onSubmit({ password }: PasswordForm) {
    const outcome = await signIn(password);
    if (outcome.result === 'ok') {
      reset({ password: '' });
      setSession('signed-in');
    } else if (outcome.result === 'wrong-password') {
      setError('password', { message: outcome.message });
    } else {
      setError('root', { message: outcome.message });
    }
  }

  async function onSignOut() {
    await signOut();
    setSession('signed-out');
  }

  if (session === 'checking') {
    return <p className="text-muted">Loading…</p>;
  }

  if (session === 'signed-in') {
    return (
      <section aria-labelledby="staff-heading">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h1 id="staff-heading" className="text-4xl">
            Bookings
          </h1>
          <button
            type="button"
            onClick={onSignOut}
            className="inline-flex min-h-11 items-center justify-center rounded-lg border border-wine px-5 py-2.5 font-semibold text-wine hover:bg-wine hover:text-cream"
          >
            Sign out
          </button>
        </div>
        <div className="mt-8">
          <StaffBookings onSessionExpired={() => setSession('signed-out')} />
        </div>
      </section>
    );
  }

  return (
    <section aria-labelledby="staff-heading" className="mx-auto max-w-sm">
      <h1 id="staff-heading" className="text-4xl">
        Staff sign-in
      </h1>
      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="mt-8 grid gap-5 rounded-2xl border border-line bg-white/70 p-6 shadow-sm"
      >
        <TextField
          id="password"
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          {...register('password', { required: 'Please enter the password.' })}
        />
        {errors.root && <Alert>{errors.root.message}</Alert>}
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex min-h-12 items-center justify-center rounded-lg bg-wine px-6 py-3 text-lg font-semibold text-cream hover:bg-wine-dark disabled:cursor-not-allowed disabled:opacity-60"
        >
          Sign in
        </button>
      </form>
    </section>
  );
}
