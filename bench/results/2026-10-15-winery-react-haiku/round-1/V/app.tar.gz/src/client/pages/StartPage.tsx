import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { getTastings } from '../api.js';
import type { TastingSummary } from '../../shared/types.js';
import { formatEur, formatSeatsLeft, formatTastingDateTime } from '../../shared/format.js';
import { Alert } from '../components/Alert.js';

export function StartPage() {
  const [tastings, setTastings] = useState<TastingSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getTastings().then(setTastings, (err: unknown) => {
      setError(err instanceof Error ? err.message : 'Could not load tastings');
    });
  }, []);

  if (error) {
    return <Alert>{error}</Alert>;
  }
  if (!tastings) {
    return <p className="text-muted">Loading tastings…</p>;
  }

  return (
    <section aria-labelledby="tastings-heading">
      <p className="text-sm font-semibold uppercase tracking-widest text-gold">Come and taste with us</p>
      <h1 id="tastings-heading" className="mt-2 text-4xl sm:text-5xl">
        Tastings at Weingut Kieselbrunnen
      </h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">
        Choose an evening in the cellar or a tour among the barrels, then reserve your seats online.
      </p>

      <ul className="mt-10 grid gap-6 sm:grid-cols-2">
        {tastings.map((tasting) => {
          const soldOut = tasting.seatsLeft === 0;
          return (
            <li key={tasting.id} className="flex">
              <article
                aria-label={tasting.title}
                className="flex w-full flex-col gap-3 rounded-2xl border border-line bg-white/70 p-6 shadow-sm"
              >
                <h2 className="text-2xl">{tasting.title}</h2>
                <p className="font-medium text-ink">{formatTastingDateTime(tasting.date, tasting.time)}</p>
                <p className="text-muted">{formatEur(tasting.priceEur)} per guest</p>
                {soldOut ? (
                  <p className="w-fit rounded-full bg-parchment px-3 py-1 text-sm font-semibold tracking-wide text-wine uppercase">
                    Fully booked
                  </p>
                ) : (
                  <p className="w-fit rounded-full bg-parchment px-3 py-1 text-sm font-semibold text-vine">
                    {formatSeatsLeft(tasting.seatsLeft)}
                  </p>
                )}
                {!soldOut && (
                  <Link
                    to={`/tastings/${tasting.id}/book`}
                    className="mt-auto inline-flex min-h-11 items-center justify-center rounded-lg bg-wine px-5 py-2.5 font-semibold text-cream hover:bg-wine-dark"
                  >
                    Book {tasting.title}
                  </Link>
                )}
              </article>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
