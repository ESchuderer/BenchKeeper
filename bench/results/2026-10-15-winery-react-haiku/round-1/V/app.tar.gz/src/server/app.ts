import { existsSync } from 'node:fs';
import { join } from 'node:path';
import cookieParser from 'cookie-parser';
import express, { type NextFunction, type Request, type Response } from 'express';
import { rateLimit } from 'express-rate-limit';
import { createBookingService } from './bookings.js';
import { createStaffAuth, STAFF_SESSION_COOKIE, type StaffAuth } from './staff-auth.js';

export interface AppOptions {
  /** Built client directory served for every non-API route. */
  clientDir?: string;
  bookings?: ReturnType<typeof createBookingService>;
  /** Defaults to the STAFF_PASSWORD environment variable. Empty or unset means staff sign-in is refused. */
  staffPassword?: string;
}

const SIGN_IN_WINDOW_MS = 15 * 60 * 1000;
const SIGN_IN_FAILURES_ALLOWED = 5;

/** Body-parser reports malformed JSON as a SyntaxError tagged with this type. */
function isJsonSyntaxError(err: unknown): boolean {
  return err instanceof SyntaxError && 'type' in err && err.type === 'entity.parse.failed';
}

export function createApp({
  clientDir,
  bookings = createBookingService(),
  staffPassword = process.env.STAFF_PASSWORD,
}: AppOptions = {}) {
  const app = express();
  const staff: StaffAuth = createStaffAuth(staffPassword);
  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    if (staff.isSignedIn(req.cookies[STAFF_SESSION_COOKIE])) {
      next();
    } else {
      res.status(401).json({ error: 'Staff sign-in required' });
    }
  };
  // Only failed attempts count, so a correct sign-in is never blocked by earlier typos.
  const signInLimiter = rateLimit({
    windowMs: SIGN_IN_WINDOW_MS,
    limit: SIGN_IN_FAILURES_ALLOWED,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many attempts. Try again later.' },
  });

  app.use(express.json());
  app.use(cookieParser());

  app.get('/api/tastings', (_req, res) => {
    res.json(bookings.listTastings());
  });

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const result = bookings.book(req.params.id, req.body ?? {});
    if (result.ok) {
      res.status(201).json(result.booking);
    } else if (result.kind === 'validation') {
      res.status(400).json({ errors: result.errors });
    } else if (result.kind === 'unknown-tasting') {
      res.status(404).json({ error: 'Tasting not found' });
    } else {
      res.status(409).json({ errors: result.errors, seatsLeft: result.seatsLeft });
    }
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const booking = bookings.getBooking(req.params.reference);
    if (booking) {
      res.json(booking);
    } else {
      res.status(404).json({ error: 'Booking not found' });
    }
  });

  app.post('/api/staff/session', signInLimiter, (req, res) => {
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!staff.checkPassword(password)) {
      res.status(401).json({ error: 'Incorrect password.' });
      return;
    }
    res.cookie(STAFF_SESSION_COOKIE, staff.createSession(), {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure,
      path: '/',
      maxAge: staff.sessionTtlMs,
    });
    res.status(204).end();
  });

  app.get('/api/staff/session', requireStaff, (_req, res) => {
    res.json({ signedIn: true });
  });

  app.use('/api/staff/bookings', requireStaff);

  app.get('/api/staff/bookings', (_req, res) => {
    res.json(bookings.listBookingsByTasting());
  });

  app.delete('/api/staff/bookings/:reference', (req, res) => {
    if (bookings.cancel(req.params.reference)) {
      res.status(204).end();
    } else {
      res.status(404).json({ error: 'Booking not found' });
    }
  });

  app.delete('/api/staff/session', (req, res) => {
    staff.endSession(req.cookies[STAFF_SESSION_COOKIE]);
    res.clearCookie(STAFF_SESSION_COOKIE, { httpOnly: true, sameSite: 'strict', path: '/' });
    res.status(204).end();
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found' });
  });

  if (clientDir && existsSync(join(clientDir, 'index.html'))) {
    app.use(express.static(clientDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(join(clientDir, 'index.html'));
    });
  }

  app.use((err: unknown, _req: Request, res: Response, next: NextFunction) => {
    if (isJsonSyntaxError(err)) {
      res.status(400).json({ error: 'Request body must be valid JSON' });
      return;
    }
    next(err);
  });

  return app;
}
