import { randomInt } from 'node:crypto';
import type { z } from 'zod';
import type { BookingDetails } from '../shared/booking.js';
import { bookingInputSchema } from '../shared/booking-schema.js';
import { seatsShortMessage } from '../shared/format.js';
import type { StaffTastingView, TastingSummary } from '../shared/types.js';
import { TASTINGS, type Tasting } from './catalogue.js';

export type BookingField = 'name' | 'email' | 'guests';
export type BookingErrors = Partial<Record<BookingField, string>>;

export type BookingResult =
  | { ok: true; booking: BookingDetails }
  | { ok: false; kind: 'validation'; errors: BookingErrors }
  | { ok: false; kind: 'unknown-tasting' }
  | { ok: false; kind: 'insufficient-seats'; seatsLeft: number; errors: { guests: string } };

export interface BookingServiceOptions {
  tastings?: readonly Tasting[];
}

// No 0/O or 1/I, so references read correctly when spoken or written down.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const REFERENCE_LENGTH = 6;

interface StoredBooking {
  details: BookingDetails;
  name: string;
  email: string;
}

export function createBookingService({ tastings = TASTINGS }: BookingServiceOptions = {}) {
  const bookings = new Map<string, StoredBooking>();

  function findOffered(tastingId: string): Tasting | undefined {
    return tastings.find((tasting) => tasting.id === tastingId);
  }

  function seatsLeftFor(tasting: Tasting): number {
    let booked = 0;
    for (const { details } of bookings.values()) {
      if (details.tastingId === tasting.id) {
        booked += details.guests;
      }
    }
    return tasting.seats - booked;
  }

  function newReference(): string {
    let reference: string;
    do {
      reference = `KB-${Array.from(
        { length: REFERENCE_LENGTH },
        () => REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)],
      ).join('')}`;
    } while (bookings.has(reference));
    return reference;
  }

  return {
    listTastings(): TastingSummary[] {
      return tastings.map((tasting) => ({ ...tasting, seatsLeft: seatsLeftFor(tasting) }));
    },

    seatsLeft(tastingId: string): number {
      const tasting = findOffered(tastingId);
      if (!tasting) {
        throw new Error(`Unknown tasting: ${tastingId}`);
      }
      return seatsLeftFor(tasting);
    },

    book(tastingId: string, input: unknown): BookingResult {
      const tasting = findOffered(tastingId);
      if (!tasting) {
        return { ok: false, kind: 'unknown-tasting' };
      }

      const parsed = bookingInputSchema.safeParse(input);
      if (!parsed.success) {
        return { ok: false, kind: 'validation', errors: firstErrorPerField(parsed.error) };
      }
      const { name, email, guests } = parsed.data;

      const seatsLeft = seatsLeftFor(tasting);
      if (guests > seatsLeft) {
        return {
          ok: false,
          kind: 'insufficient-seats',
          seatsLeft,
          errors: {
            guests: seatsShortMessage(seatsLeft),
          },
        };
      }

      const details: BookingDetails = {
        reference: newReference(),
        tastingId: tasting.id,
        tastingTitle: tasting.title,
        date: tasting.date,
        time: tasting.time,
        guests,
        priceEur: tasting.priceEur,
        totalEur: tasting.priceEur * guests,
      };
      bookings.set(details.reference, { details, name, email });
      return { ok: true, booking: details };
    },

    getBooking(reference: string): BookingDetails | undefined {
      return bookings.get(reference)?.details;
    },

    /** Removes the booking and frees its seats. Returns false when the reference is unknown. */
    cancel(reference: string): boolean {
      return bookings.delete(reference);
    },

    listBookingsByTasting(): StaffTastingView[] {
      return tastings.map((tasting) => ({
        id: tasting.id,
        title: tasting.title,
        date: tasting.date,
        time: tasting.time,
        seats: tasting.seats,
        seatsLeft: seatsLeftFor(tasting),
        bookings: [...bookings.values()]
          .filter(({ details }) => details.tastingId === tasting.id)
          .map(({ details, name, email }) => ({
            reference: details.reference,
            name,
            email,
            guests: details.guests,
          })),
      }));
    },
  };
}

function firstErrorPerField(error: z.ZodError): BookingErrors {
  const errors: BookingErrors = {};
  for (const issue of error.issues) {
    const field = issue.path[0];
    if ((field === 'name' || field === 'email' || field === 'guests') && !errors[field]) {
      errors[field] = issue.message;
    }
  }
  return errors;
}
