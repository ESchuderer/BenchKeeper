import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const STAFF_SESSION_COOKIE = 'staff_session';
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;

const digest = (value: string) => createHash('sha256').update(value).digest();

export function createStaffAuth(password: string | undefined) {
  // Comparing fixed-length digests keeps the comparison constant-time and independent of length.
  const expected = password ? digest(password) : undefined;
  const sessions = new Map<string, number>();

  return {
    /** False for every candidate when no password is configured. */
    checkPassword(candidate: string): boolean {
      return expected !== undefined && timingSafeEqual(digest(candidate), expected);
    },

    createSession(): string {
      const token = randomBytes(32).toString('base64url');
      sessions.set(token, Date.now() + SESSION_TTL_MS);
      return token;
    },

    isSignedIn(token: string | undefined): boolean {
      if (!token) {
        return false;
      }
      const expiresAt = sessions.get(token);
      if (expiresAt === undefined) {
        return false;
      }
      if (expiresAt < Date.now()) {
        sessions.delete(token);
        return false;
      }
      return true;
    },

    endSession(token: string | undefined): void {
      if (token) {
        sessions.delete(token);
      }
    },

    sessionTtlMs: SESSION_TTL_MS,
  };
}

export type StaffAuth = ReturnType<typeof createStaffAuth>;
