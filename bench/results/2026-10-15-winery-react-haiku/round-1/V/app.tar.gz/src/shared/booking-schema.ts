import { z } from 'zod';

export const MIN_GUESTS = 1;
export const MAX_GUESTS = 8;

const NAME_MESSAGE = 'Please enter your name.';
const EMAIL_MESSAGE = 'Please enter a valid email address.';
/** Only plain numbers or runs of digits count: "true", "0x2" or [3] are rejected, not coerced. */
const wholeNumberInput = (value: unknown) =>
  typeof value === 'string' && /^\s*\d+\s*$/.test(value) ? Number(value) : value;

const GUESTS_MESSAGE = `Please choose between ${MIN_GUESTS} and ${MAX_GUESTS} guests.`;

/** Guest input for a booking. Shared by the booking form and the server, so the rules live in one place. */
export const bookingInputSchema = z.object({
  name: z
    .string({ error: NAME_MESSAGE })
    .trim()
    .min(1, NAME_MESSAGE)
    .max(80, 'Please enter a name of up to 80 characters.'),
  email: z
    .string({ error: EMAIL_MESSAGE })
    .trim()
    .max(254, EMAIL_MESSAGE)
    .pipe(z.email({ error: EMAIL_MESSAGE })),
  guests: z.preprocess(
    wholeNumberInput,
    z
      .number({ error: GUESTS_MESSAGE })
      .int(GUESTS_MESSAGE)
      .min(MIN_GUESTS, GUESTS_MESSAGE)
      .max(MAX_GUESTS, GUESTS_MESSAGE),
  ),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;
