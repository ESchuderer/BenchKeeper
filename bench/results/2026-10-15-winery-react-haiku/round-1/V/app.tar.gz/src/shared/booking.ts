/** A booking as the API returns it to the guest who made it. */
export interface BookingDetails {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  date: string;
  time: string;
  guests: number;
  priceEur: number;
  totalEur: number;
}
