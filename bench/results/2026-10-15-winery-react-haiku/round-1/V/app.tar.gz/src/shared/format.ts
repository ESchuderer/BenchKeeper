const dateFormatter = new Intl.DateTimeFormat('en-GB', {
  weekday: 'short',
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  timeZone: 'UTC',
});

/** Formats a winery-local date and time, e.g. "Fri 6 Nov 2026, 18:00". No time-zone conversion. */
export function formatTastingDateTime(date: string, time: string): string {
  const [year, month, day] = date.split('-').map(Number);
  return `${dateFormatter.format(new Date(Date.UTC(year, month - 1, day)))}, ${time}`;
}

export function formatSeatsLeft(seatsLeft: number): string {
  return seatsLeft === 1 ? '1 seat left' : `${seatsLeft} seats left`;
}

/** The message shown when a booking asks for more guests than there are seats. */
export function seatsShortMessage(seatsLeft: number): string {
  return seatsLeft === 0
    ? 'This tasting is fully booked.'
    : `Only ${formatSeatsLeft(seatsLeft)} for this tasting.`;
}

export function formatEur(amount: number): string {
  return `EUR ${amount}`;
}
