/** A tasting as the API returns it, with live seat availability. */
export interface TastingSummary {
  id: string;
  title: string;
  date: string;
  time: string;
  priceEur: number;
  seats: number;
  seatsLeft: number;
}

/** Everything staff see for one tasting, including guests' contact details. */
export interface StaffTastingView {
  id: string;
  title: string;
  date: string;
  time: string;
  seats: number;
  seatsLeft: number;
  bookings: StaffBooking[];
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}
