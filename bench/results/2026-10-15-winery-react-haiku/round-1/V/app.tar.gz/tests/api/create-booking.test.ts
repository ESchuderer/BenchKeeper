import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../../src/server/app.js';

const guest = { name: 'Anna Berger', email: 'anna@example.com' };
const REFERENCE_FORMAT = /^KB-[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{6}$/;

describe('POST /api/tastings/:id/bookings', () => {
  it('creates the booking and returns the confirmation details', async () => {
    const app = createApp();

    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guest, guests: 2 });

    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(REFERENCE_FORMAT),
      tastingId: 'riesling-evening',
      tastingTitle: 'Riesling Evening',
      date: '2026-11-06',
      time: '18:00',
      guests: 2,
      priceEur: 25,
      totalEur: 50,
    });
  });

  it('takes the seats off the tastings list', async () => {
    const app = createApp();

    await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guest, guests: 2 });
    const tastings = await request(app).get('/api/tastings');

    expect(tastings.body.find((t: { id: string }) => t.id === 'riesling-evening').seatsLeft).toBe(10);
  });

  it('returns 400 with a message per invalid field', async () => {
    const res = await request(createApp())
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: '', email: 'nope', guests: 0 });

    expect(res.status).toBe(400);
    expect(res.body).toEqual({
      errors: {
        name: 'Please enter your name.',
        email: 'Please enter a valid email address.',
        guests: 'Please choose between 1 and 8 guests.',
      },
    });
  });

  it('returns 409 with the seats left when the guests do not fit', async () => {
    const app = createApp();
    await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guest, guests: 8 });

    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guest, guests: 5 });

    expect(res.status).toBe(409);
    expect(res.body).toEqual({
      errors: { guests: 'Only 4 seats left for this tasting.' },
      seatsLeft: 4,
    });
  });

  it('returns 409 for a fully booked tasting', async () => {
    const app = createApp();
    await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 8 });

    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 1 });

    expect(res.status).toBe(409);
    expect(res.body.errors.guests).toBe('This tasting is fully booked.');
  });

  it('answers a malformed JSON body with a JSON 400, not an HTML error page', async () => {
    const res = await request(createApp())
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ');

    expect(res.status).toBe(400);
    expect(res.headers['content-type']).toMatch(/application\/json/);
    expect(res.body).toEqual({ error: 'Request body must be valid JSON' });
  });

  it('returns 404 for an unknown tasting', async () => {
    const res = await request(createApp())
      .post('/api/tastings/no-such-tasting/bookings')
      .send({ ...guest, guests: 1 });

    expect(res.status).toBe(404);
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the booking that was created', async () => {
    const app = createApp();
    const created = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ ...guest, guests: 3 });

    const res = await request(app).get(`/api/bookings/${created.body.reference}`);

    expect(res.status).toBe(200);
    expect(res.body).toEqual(created.body);
  });

  it('returns 404 for an unknown reference', async () => {
    const res = await request(createApp()).get('/api/bookings/KB-ZZZZZZ');

    expect(res.status).toBe(404);
  });
});
