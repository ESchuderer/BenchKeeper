import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../../src/server/app.js';

const PASSWORD = 'staff-pass';

async function signedInApp() {
  const app = createApp({ staffPassword: PASSWORD });
  const signIn = await request(app).post('/api/staff/session').send({ password: PASSWORD });
  const cookie = (signIn.headers['set-cookie'] as unknown as string[])[0].split(';')[0];
  return { app, cookie };
}

describe('staff bookings', () => {
  it('refuses the list and cancel endpoints without a staff session', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const booked = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: 'Anna Berger', email: 'anna@example.com', guests: 2 });

    expect((await request(app).get('/api/staff/bookings')).status).toBe(401);
    expect((await request(app).delete(`/api/staff/bookings/${booked.body.reference}`)).status).toBe(401);
    expect((await request(app).get('/api/tastings')).body[0].seatsLeft).toBe(10);
  });

  it('lists every tasting with its bookings and the guests’ contact details', async () => {
    const { app, cookie } = await signedInApp();
    const booked = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: 'Anna Berger', email: 'anna@example.com', guests: 2 });

    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie);

    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(3);
    expect(res.body[0]).toEqual({
      id: 'riesling-evening',
      title: 'Riesling Evening',
      date: '2026-11-06',
      time: '18:00',
      seats: 12,
      seatsLeft: 10,
      bookings: [
        {
          reference: booked.body.reference,
          name: 'Anna Berger',
          email: 'anna@example.com',
          guests: 2,
        },
      ],
    });
    expect(res.body[1].bookings).toEqual([]);
  });

  it('cancels a booking, which frees its seats and removes it from the list', async () => {
    const { app, cookie } = await signedInApp();
    const booked = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: 'Anna Berger', email: 'anna@example.com', guests: 2 });

    const cancel = await request(app)
      .delete(`/api/staff/bookings/${booked.body.reference}`)
      .set('Cookie', cookie);
    const list = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    const tastings = await request(app).get('/api/tastings');

    expect(cancel.status).toBe(204);
    expect(list.body[0].bookings).toEqual([]);
    expect(tastings.body[0].seatsLeft).toBe(12);
    expect((await request(app).get(`/api/bookings/${booked.body.reference}`)).status).toBe(404);
  });

  it('answers 404 when cancelling a booking that does not exist or was already cancelled', async () => {
    const { app, cookie } = await signedInApp();
    const booked = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ name: 'Anna Berger', email: 'anna@example.com', guests: 1 });
    await request(app).delete(`/api/staff/bookings/${booked.body.reference}`).set('Cookie', cookie);

    expect(
      (await request(app).delete(`/api/staff/bookings/${booked.body.reference}`).set('Cookie', cookie))
        .status,
    ).toBe(404);
    expect((await request(app).delete('/api/staff/bookings/KB-ZZZZZZ').set('Cookie', cookie)).status).toBe(
      404,
    );
  });
});
