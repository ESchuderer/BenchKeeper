import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../../src/server/app.js';

const PASSWORD = 'correct-horse-battery';

function sessionCookie(res: request.Response): string | undefined {
  const cookies = res.headers['set-cookie'] as unknown as string[] | undefined;
  return cookies?.find((c) => c.startsWith('staff_session='));
}

describe('POST /api/staff/session', () => {
  it('signs in with the right password and sets an HttpOnly, SameSite=Strict session cookie', async () => {
    const app = createApp({ staffPassword: PASSWORD });

    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD });

    expect(res.status).toBe(204);
    const cookie = sessionCookie(res);
    expect(cookie).toMatch(/^staff_session=[^;]+/);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
  });

  it('refuses a wrong password with a message', async () => {
    const res = await request(createApp({ staffPassword: PASSWORD }))
      .post('/api/staff/session')
      .send({ password: 'wrong' });

    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: 'Incorrect password.' });
    expect(sessionCookie(res)).toBeUndefined();
  });

  it('refuses every password, even an empty one, when no staff password is configured', async () => {
    const app = createApp({ staffPassword: '' });

    for (const password of ['', 'anything']) {
      const res = await request(app).post('/api/staff/session').send({ password });
      expect(res.status).toBe(401);
    }
  });

  it('refuses a missing password field', async () => {
    const res = await request(createApp({ staffPassword: PASSWORD }))
      .post('/api/staff/session')
      .send({});

    expect(res.status).toBe(401);
  });

  it('answers 429 after repeated wrong passwords', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    for (let attempt = 0; attempt < 5; attempt++) {
      await request(app).post('/api/staff/session').send({ password: 'wrong' });
    }

    const res = await request(app).post('/api/staff/session').send({ password: 'wrong' });

    expect(res.status).toBe(429);
    expect(res.body).toEqual({ error: 'Too many attempts. Try again later.' });
  });
});

describe('staff session', () => {
  it('reports no session without a cookie', async () => {
    const res = await request(createApp({ staffPassword: PASSWORD })).get('/api/staff/session');

    expect(res.status).toBe(401);
  });

  it('reports the session the sign-in created, and not after sign-out', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const signIn = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    const cookie = sessionCookie(signIn)!.split(';')[0];

    const signedIn = await request(app).get('/api/staff/session').set('Cookie', cookie);
    expect(signedIn.status).toBe(200);
    expect(signedIn.body).toEqual({ signedIn: true });

    const signOut = await request(app).delete('/api/staff/session').set('Cookie', cookie);
    expect(signOut.status).toBe(204);

    const afterSignOut = await request(app).get('/api/staff/session').set('Cookie', cookie);
    expect(afterSignOut.status).toBe(401);
  });

  it('does not accept a made-up session token', async () => {
    const res = await request(createApp({ staffPassword: PASSWORD }))
      .get('/api/staff/session')
      .set('Cookie', 'staff_session=forged');

    expect(res.status).toBe(401);
  });
});
