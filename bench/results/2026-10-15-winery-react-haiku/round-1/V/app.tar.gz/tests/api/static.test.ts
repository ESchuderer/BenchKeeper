import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../../src/server/app.js';

describe('serving the built client', () => {
  let clientDir: string;

  beforeAll(() => {
    clientDir = mkdtempSync(join(tmpdir(), 'kieselbrunnen-client-'));
    writeFileSync(join(clientDir, 'index.html'), '<!doctype html><div id="root"></div>');
  });

  it('returns the app shell for client routes such as /staff and /tastings/x/book', async () => {
    const app = createApp({ clientDir });

    for (const path of ['/', '/staff', '/tastings/riesling-evening/book']) {
      const res = await request(app).get(path);
      expect(res.status).toBe(200);
      expect(res.text).toContain('id="root"');
    }
  });

  it('answers unknown API paths with a JSON 404', async () => {
    const res = await request(createApp({ clientDir })).get('/api/nope');

    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/application\/json/);
  });
});
