import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../../src/server/app.js';

describe('GET /api/tastings', () => {
  it('lists the three tastings with every seat free before any booking', async () => {
    const res = await request(createApp()).get('/api/tastings');

    expect(res.status).toBe(200);
    expect(res.body).toEqual([
      {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        date: '2026-11-06',
        time: '18:00',
        priceEur: 25,
        seats: 12,
        seatsLeft: 12,
      },
      {
        id: 'red-wine-cellar-tour',
        title: 'Red Wine Cellar Tour',
        date: '2026-11-14',
        time: '15:00',
        priceEur: 32,
        seats: 8,
        seatsLeft: 8,
      },
      {
        id: 'winter-tasting',
        title: 'Winter Tasting',
        date: '2026-12-05',
        time: '17:00',
        priceEur: 28,
        seats: 10,
        seatsLeft: 10,
      },
    ]);
  });
});
