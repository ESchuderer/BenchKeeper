// @vitest-environment jsdom
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { App } from '../../src/client/App.js';

const riesling = {
  id: 'riesling-evening',
  title: 'Riesling Evening',
  date: '2026-11-06',
  time: '18:00',
  priceEur: 25,
  seats: 12,
  seatsLeft: 12,
};

const confirmation = {
  reference: 'KB-K7M2QX',
  tastingId: 'riesling-evening',
  tastingTitle: 'Riesling Evening',
  date: '2026-11-06',
  time: '18:00',
  guests: 2,
  priceEur: 25,
  totalEur: 50,
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}

function fillForm(
  user: ReturnType<typeof userEvent.setup>,
  { name, email, guests }: { name?: string; email?: string; guests?: string },
) {
  return (async () => {
    if (name !== undefined) await user.type(screen.getByLabelText('Name'), name);
    if (email !== undefined) await user.type(screen.getByLabelText('Email'), email);
    if (guests !== undefined) {
      await user.clear(screen.getByLabelText('Guests'));
      await user.type(screen.getByLabelText('Guests'), guests);
    }
    await user.click(screen.getByRole('button', { name: 'Book' }));
  })();
}

describe('booking form', () => {
  let fetchMock: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
      if (url === '/api/tastings') return json([riesling]);
      if (url === '/api/tastings/riesling-evening/bookings' && init?.method === 'POST') {
        return json(confirmation, 201);
      }
      if (url === '/api/bookings/KB-K7M2QX') return json(confirmation);
      return json({ error: 'unexpected' }, 500);
    });
    vi.stubGlobal('fetch', fetchMock);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('shows the chosen tasting with its Name, Email and Guests fields and a Book button', async () => {
    renderAt('/tastings/riesling-evening/book');

    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows each invalid input next to its own field and sends nothing', async () => {
    const user = userEvent.setup();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Email'), 'not-an-email');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Name')).toHaveAccessibleDescription('Please enter your name.');
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Please enter a valid email address.');
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(
      'Please choose between 1 and 8 guests.',
    );
    expect(fetchMock).not.toHaveBeenCalledWith('/api/tastings/riesling-evening/bookings', expect.anything());
  });

  it('shows the seats-left message on Guests when the server says the guests do not fit', async () => {
    fetchMock.mockImplementation(async (url: string, init?: RequestInit) => {
      if (url === '/api/tastings') return json([riesling]);
      if (init?.method === 'POST') {
        return json({ errors: { guests: 'Only 3 seats left for this tasting.' }, seatsLeft: 3 }, 409);
      }
      return json({ error: 'unexpected' }, 500);
    });
    const user = userEvent.setup();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await fillForm(user, { name: 'Anna Berger', email: 'anna@example.com', guests: '4' });

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(
      'Only 3 seats left for this tasting.',
    );
  });

  it('goes to the confirmation page after a successful booking', async () => {
    const user = userEvent.setup();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await fillForm(user, { name: 'Anna Berger', email: 'anna@example.com', guests: '2' });

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const details = screen.getByRole('list', { name: 'Booking details' });
    expect(within(details).getByText('Riesling Evening')).toBeInTheDocument();
    expect(within(details).getByText('EUR 50')).toBeInTheDocument();
    expect(within(details).getByText('KB-K7M2QX')).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledWith(
      '/api/tastings/riesling-evening/bookings',
      expect.objectContaining({ method: 'POST' }),
    );
  });

  it('shows a fully booked tasting without a form', async () => {
    fetchMock.mockImplementation(async () => json([{ ...riesling, seatsLeft: 0 }]));
    renderAt('/tastings/riesling-evening/book');

    expect(await screen.findByText('This tasting is fully booked.')).toBeInTheDocument();
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });
  it('refuses more guests than seats left in the form, without sending a request', async () => {
    fetchMock.mockImplementation(async (url: string) => {
      if (url === '/api/tastings') return json([{ ...riesling, seatsLeft: 3 }]);
      return json({ error: 'unexpected' }, 500);
    });
    const user = userEvent.setup();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await fillForm(user, { name: 'Anna Berger', email: 'anna@example.com', guests: '4' });

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(
      'Only 3 seats left for this tasting.',
    );
    expect(fetchMock).not.toHaveBeenCalledWith('/api/tastings/riesling-evening/bookings', expect.anything());
  });

  it('tells the guest when the booking request cannot be sent', async () => {
    fetchMock.mockImplementation(async (url: string, init?: RequestInit) => {
      if (url === '/api/tastings') return json([riesling]);
      if (init?.method === 'POST') throw new TypeError('Failed to fetch');
      return json({ error: 'unexpected' }, 500);
    });
    const user = userEvent.setup();
    renderAt('/tastings/riesling-evening/book');
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await fillForm(user, { name: 'Anna Berger', email: 'anna@example.com', guests: '2' });

    expect(await screen.findByRole('alert')).toHaveTextContent('Something went wrong. Please try again.');
  });
});

describe('confirmation page', () => {
  beforeEach(() => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => json(confirmation)),
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('shows the booking confirmed heading with tasting, guests, total and reference', async () => {
    renderAt('/bookings/KB-K7M2QX');

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const details = screen.getByRole('list', { name: 'Booking details' });
    expect(within(details).getByText('Riesling Evening')).toBeInTheDocument();
    expect(within(details).getByText('2')).toBeInTheDocument();
    expect(within(details).getByText('EUR 50')).toBeInTheDocument();
    expect(within(details).getByText('KB-K7M2QX')).toBeInTheDocument();
  });

  it('says so when the reference is unknown', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => json({ error: 'Booking not found' }, 404)),
    );
    renderAt('/bookings/KB-ZZZZZZ');

    expect(await screen.findByText('Booking not found')).toBeInTheDocument();
    await waitFor(() =>
      expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument(),
    );
  });
});
