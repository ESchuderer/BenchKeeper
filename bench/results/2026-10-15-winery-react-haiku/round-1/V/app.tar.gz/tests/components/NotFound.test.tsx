// @vitest-environment jsdom
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { describe, expect, it } from 'vitest';
import { App } from '../../src/client/App.js';

describe('unknown pages', () => {
  it('shows a page-not-found message with a way back to the tastings', () => {
    render(
      <MemoryRouter initialEntries={['/no/such/page']}>
        <App />
      </MemoryRouter>,
    );

    expect(screen.getByRole('heading', { name: 'Page not found' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Back to all tastings' })).toHaveAttribute('href', '/');
  });
});
