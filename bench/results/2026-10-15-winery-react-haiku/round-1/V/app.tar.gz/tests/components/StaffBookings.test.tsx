// @vitest-environment jsdom
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { App } from '../../src/client/App.js';

function json(body: unknown, status = 200) {
  return new Response(body === null ? null : JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

const dayTastings = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    date: '2026-11-06',
    time: '18:00',
    seats: 12,
    seatsLeft: 8,
    bookings: [
      { reference: 'KB-K7M2QX', name: 'Anna Berger', email: 'anna@example.com', guests: 2 },
      { reference: 'KB-ZP4HWA', name: 'Ben Ortiz', email: 'ben@example.com', guests: 2 },
    ],
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    date: '2026-11-14',
    time: '15:00',
    seats: 8,
    seatsLeft: 8,
    bookings: [],
  },
];

/** A tiny in-memory staff API: the list is mutated by DELETE, like the real server. */
function stubSignedInStaff(initial = structuredClone(dayTastings)) {
  let tastings = initial;
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    const method = init?.method ?? 'GET';
    if (url === '/api/staff/session' && method === 'GET') return json({ signedIn: true });
    if (url === '/api/staff/bookings' && method === 'GET') return json(tastings);
    const cancel = url.match(/^\/api\/staff\/bookings\/(KB-[A-Z0-9]{6})$/);
    if (cancel && method === 'DELETE') {
      tastings = tastings.map((tasting) => {
        const remaining = tasting.bookings.filter((b) => b.reference !== cancel[1]);
        const removed = tasting.bookings.filter((b) => b.reference === cancel[1]);
        const freed = removed.reduce((sum, b) => sum + b.guests, 0);
        return { ...tasting, bookings: remaining, seatsLeft: tasting.seatsLeft + freed };
      });
      return new Response(null, { status: 204 });
    }
    return json({ error: 'unexpected' }, 500);
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

function renderStaff() {
  return render(
    <MemoryRouter initialEntries={['/staff']}>
      <App />
    </MemoryRouter>,
  );
}

describe('staff bookings list', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('groups bookings by tasting with name, email, guests and reference', async () => {
    stubSignedInStaff();
    renderStaff();

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    const rows = within(riesling).getAllByRole('listitem');
    expect(rows).toHaveLength(2);
    expect(within(rows[0]).getByText('Anna Berger')).toBeInTheDocument();
    expect(within(rows[0]).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(rows[0]).getByText('2')).toBeInTheDocument();
    expect(within(rows[0]).getByText('KB-K7M2QX')).toBeInTheDocument();
    expect(within(riesling).getByText('8 seats left')).toBeInTheDocument();
  });

  it('says when a tasting has no bookings yet', async () => {
    stubSignedInStaff();
    renderStaff();

    const cellar = await screen.findByRole('region', { name: 'Red Wine Cellar Tour' });
    expect(within(cellar).getByText('No bookings yet.')).toBeInTheDocument();
  });

  it('cancels a booking: it leaves the list and its seats come back', async () => {
    const fetchMock = stubSignedInStaff();
    const user = userEvent.setup();
    renderStaff();

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    const anna = within(riesling).getByText('Anna Berger').closest('li')!;
    await user.click(within(anna).getByRole('button', { name: 'Cancel' }));

    await vi.waitFor(() => expect(within(riesling).queryByText('Anna Berger')).not.toBeInTheDocument());
    expect(within(riesling).getByText('Ben Ortiz')).toBeInTheDocument();
    expect(within(riesling).getByText('10 seats left')).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledWith(
      '/api/staff/bookings/KB-K7M2QX',
      expect.objectContaining({ method: 'DELETE' }),
    );
  });

  it('says so when a cancel fails, and keeps the booking listed', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url === '/api/staff/session') return json({ signedIn: true });
        if (url === '/api/staff/bookings') return json(structuredClone(dayTastings));
        if (init?.method === 'DELETE') return json({ error: 'boom' }, 500);
        return json({ error: 'unexpected' }, 500);
      }),
    );
    const user = userEvent.setup();
    renderStaff();

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    await user.click(
      within(within(riesling).getByText('Anna Berger').closest('li')!).getByRole('button', {
        name: 'Cancel',
      }),
    );

    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Could not cancel the booking. Please try again.',
    );
    expect(within(riesling).getByText('Anna Berger')).toBeInTheDocument();
  });

  it('returns to the sign-in form when the session has expired', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url === '/api/staff/session' && !init?.method) return json({ signedIn: true });
        if (url === '/api/staff/bookings') return json({ error: 'Staff sign-in required' }, 401);
        return json({ error: 'unexpected' }, 500);
      }),
    );
    renderStaff();

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });
});
