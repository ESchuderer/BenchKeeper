// @vitest-environment jsdom
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { App } from '../../src/client/App.js';

function json(body: unknown, status = 200) {
  return new Response(body === null ? null : JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

function renderStaff() {
  return render(
    <MemoryRouter initialEntries={['/staff']}>
      <App />
    </MemoryRouter>,
  );
}

/** Answers the session check as signed out, and sign-in as the given response. */
function stubStaffApi(signIn: () => Response) {
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    if (url === '/api/staff/session' && (!init || !init.method || init.method === 'GET')) {
      return json({ error: 'Staff sign-in required' }, 401);
    }
    if (url === '/api/staff/session' && init?.method === 'POST') {
      return signIn();
    }
    return json({ error: 'unexpected' }, 500);
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

describe('staff sign-in page', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('asks for the password when nobody is signed in', async () => {
    stubStaffApi(() => new Response(null, { status: 204 }));
    renderStaff();

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });

  it('shows "Incorrect password." next to the Password field', async () => {
    stubStaffApi(() => json({ error: 'Incorrect password.' }, 401));
    const user = userEvent.setup();
    renderStaff();

    await user.type(await screen.findByLabelText('Password'), 'nope');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription('Incorrect password.');
  });

  it('shows the rate-limit message when too many attempts were made', async () => {
    stubStaffApi(() => json({ error: 'Too many attempts. Try again later.' }, 429));
    const user = userEvent.setup();
    renderStaff();

    await user.type(await screen.findByLabelText('Password'), 'nope');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByText('Too many attempts. Try again later.')).toBeInTheDocument();
  });

  it('tells the user when the sign-in request cannot be sent', async () => {
    stubStaffApi(() => {
      throw new TypeError('Failed to fetch');
    });
    const user = userEvent.setup();
    renderStaff();

    await user.type(await screen.findByLabelText('Password'), 'anything');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Something went wrong. Please try again.');
  });

  it('shows the signed-in view after the right password, and returns to sign-in on sign out', async () => {
    const fetchMock = stubStaffApi(() => new Response(null, { status: 204 }));
    const user = userEvent.setup();
    renderStaff();

    await user.type(await screen.findByLabelText('Password'), 'right-password');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByRole('button', { name: 'Sign out' })).toBeInTheDocument();
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledWith(
      '/api/staff/session',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({ password: 'right-password' }) }),
    );

    await user.click(screen.getByRole('button', { name: 'Sign out' }));

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });
});
