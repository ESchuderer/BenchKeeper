// @vitest-environment jsdom
import { render, screen, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { StartPage } from '../../src/client/pages/StartPage.js';

const tastings = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    date: '2026-11-06',
    time: '18:00',
    priceEur: 25,
    seats: 12,
    seatsLeft: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    date: '2026-11-14',
    time: '15:00',
    priceEur: 32,
    seats: 8,
    seatsLeft: 1,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    date: '2026-12-05',
    time: '17:00',
    priceEur: 28,
    seats: 10,
    seatsLeft: 0,
  },
];

function renderStartPage() {
  return render(
    <MemoryRouter>
      <StartPage />
    </MemoryRouter>,
  );
}

describe('StartPage', () => {
  beforeEach(() => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify(tastings), { status: 200 })),
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('lists each tasting with its title, date, time, price and seats left', async () => {
    renderStartPage();

    const card = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(card).getByText(/6 Nov 2026/)).toBeInTheDocument();
    expect(within(card).getByText(/18:00/)).toBeInTheDocument();
    expect(within(card).getByText('EUR 25 per guest')).toBeInTheDocument();
    expect(within(card).getByText('12 seats left')).toBeInTheDocument();
  });

  it('offers a "Book <title>" link for each tasting that has seats', async () => {
    renderStartPage();

    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link).toHaveAttribute('href', '/tastings/riesling-evening/book');
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeInTheDocument();
  });

  it('uses the singular for a single seat left', async () => {
    renderStartPage();

    const card = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(card).getByText('1 seat left')).toBeInTheDocument();
  });
});

describe('StartPage fully booked tastings', () => {
  it('marks a tasting with no seats left as fully booked and gives it no booking link', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify([{ ...tastings[2], seatsLeft: 0 }]), { status: 200 })),
    );
    renderStartPage();

    const card = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(within(card).queryByRole('link', { name: /Book/ })).not.toBeInTheDocument();
    vi.unstubAllGlobals();
  });
});
