import { expect, test, type Page } from '@playwright/test';

const STAFF_PASSWORD = 'e2e-staff-pass';
const SCREENSHOTS = 'test-results/screenshots';

// The server is shared by the whole run, so the journey runs in order and leaves no bookings behind.
test.describe.configure({ mode: 'serial' });
// The whole journey runs on a phone-sized screen, the way most guests will meet it.
test.use({ viewport: { width: 375, height: 812 } });

async function expectNoHorizontalOverflow(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow).toBeLessThanOrEqual(0);
}

test('a guest books seats, and staff see and cancel the booking', async ({ page }) => {
  await page.goto('/');
  const riesling = page.getByRole('article', { name: 'Riesling Evening' });
  await expect(riesling.getByText('12 seats left')).toBeVisible();

  await riesling.getByRole('link', { name: 'Book Riesling Evening' }).click();
  await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();

  await page.getByLabel('Name').fill('Anna Berger');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('2');
  await page.getByRole('button', { name: 'Book' }).click();

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const details = page.getByRole('list', { name: 'Booking details' });
  await expect(details.getByText('EUR 50')).toBeVisible();
  await page.screenshot({ path: `${SCREENSHOTS}/375-confirmation.png`, fullPage: true });
  const reference = await details.locator('li', { hasText: 'Reference' }).locator('span').last().innerText();
  expect(reference).toMatch(/^KB-[A-Z2-9]{6}$/);

  await page.goto('/');
  await expect(
    page.getByRole('article', { name: 'Riesling Evening' }).getByText('10 seats left'),
  ).toBeVisible();

  await page.goto('/staff');
  await page.getByLabel('Password').fill('wrong-password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByLabel('Password')).toHaveAccessibleDescription('Incorrect password.');

  await page.getByLabel('Password').fill(STAFF_PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  const group = page.getByRole('region', { name: 'Riesling Evening' });
  await expect(group.getByText('Anna Berger')).toBeVisible();
  await expect(group.getByText('anna@example.com')).toBeVisible();
  await expect(group.getByText(reference, { exact: true })).toBeVisible();
  await expectNoHorizontalOverflow(page);
  await page.screenshot({ path: `${SCREENSHOTS}/375-staff-bookings.png`, fullPage: true });

  await group.getByRole('button', { name: 'Cancel' }).click();
  await expect(group.getByText('Anna Berger')).toHaveCount(0);
  await expect(group.getByText('12 seats left')).toBeVisible();

  await page.goto('/');
  await expect(
    page.getByRole('article', { name: 'Riesling Evening' }).getByText('12 seats left'),
  ).toBeVisible();
});

test('the booking form explains each mistake next to its field', async ({ page }) => {
  await page.goto('/tastings/winter-tasting/book');
  await page.getByLabel('Email').fill('not-an-email');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book' }).click();

  await expect(page.getByLabel('Name')).toHaveAccessibleDescription('Please enter your name.');
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Please enter a valid email address.');
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(
    'Please choose between 1 and 8 guests.',
  );
});

test('every page fits a 375 px phone screen', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 812 });

  await page.goto('/');
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  await expectNoHorizontalOverflow(page);
  await page.screenshot({ path: `${SCREENSHOTS}/375-start.png`, fullPage: true });

  await page.goto('/tastings/red-wine-cellar-tour/book');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription('Please enter your name.');
  await expectNoHorizontalOverflow(page);
  await page.screenshot({ path: `${SCREENSHOTS}/375-booking-errors.png`, fullPage: true });

  await page.goto('/staff');
  await expect(page.getByLabel('Password')).toBeVisible();
  await expectNoHorizontalOverflow(page);
  await page.screenshot({ path: `${SCREENSHOTS}/375-staff-sign-in.png`, fullPage: true });
});

test('desktop screenshots of the main pages', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Winter Tasting' })).toBeVisible();
  await page.screenshot({ path: `${SCREENSHOTS}/desktop-start.png`, fullPage: true });
});
