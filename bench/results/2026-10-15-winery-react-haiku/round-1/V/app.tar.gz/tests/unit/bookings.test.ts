import { describe, expect, it } from 'vitest';
import { createBookingService, type BookingResult } from '../../src/server/bookings.js';

const guest = { name: 'Anna Berger', email: 'anna@example.com', guests: 2 };
const REFERENCE_FORMAT = /^KB-[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{6}$/;

function expectBooked(result: BookingResult) {
  if (!result.ok) {
    throw new Error(`expected a booking, got ${JSON.stringify(result)}`);
  }
  return result.booking;
}

describe('booking service', () => {
  it('takes the booked guests off the seats left for that tasting only', () => {
    const service = createBookingService();

    expectBooked(service.book('riesling-evening', { ...guest, guests: 3 }));

    expect(service.seatsLeft('riesling-evening')).toBe(9);
    expect(service.seatsLeft('red-wine-cellar-tour')).toBe(8);
  });

  it('prices the booking at the price per guest times the number of guests', () => {
    const service = createBookingService();

    const booking = expectBooked(service.book('riesling-evening', { ...guest, guests: 2 }));

    expect(booking).toMatchObject({
      tastingId: 'riesling-evening',
      tastingTitle: 'Riesling Evening',
      date: '2026-11-06',
      time: '18:00',
      guests: 2,
      priceEur: 25,
      totalEur: 50,
    });
  });

  it('rejects a booking for more guests than seats left and stores nothing', () => {
    const service = createBookingService();
    expectBooked(service.book('red-wine-cellar-tour', { ...guest, guests: 6 }));

    const result = service.book('red-wine-cellar-tour', { ...guest, guests: 3 });

    expect(result).toEqual({
      ok: false,
      kind: 'insufficient-seats',
      seatsLeft: 2,
      errors: { guests: 'Only 2 seats left for this tasting.' },
    });
    expect(service.seatsLeft('red-wine-cellar-tour')).toBe(2);
  });

  it('accepts a booking that fills the last seats, then reports the tasting as fully booked', () => {
    const service = createBookingService();
    expectBooked(service.book('red-wine-cellar-tour', { ...guest, guests: 8 }));

    expect(service.seatsLeft('red-wine-cellar-tour')).toBe(0);
    expect(service.book('red-wine-cellar-tour', { ...guest, guests: 1 })).toEqual({
      ok: false,
      kind: 'insufficient-seats',
      seatsLeft: 0,
      errors: { guests: 'This tasting is fully booked.' },
    });
  });

  it('reports each invalid field with its message', () => {
    const service = createBookingService();

    expect(service.book('riesling-evening', { name: '   ', email: 'anna@example.com', guests: 2 })).toEqual({
      ok: false,
      kind: 'validation',
      errors: { name: 'Please enter your name.' },
    });
    expect(service.book('riesling-evening', { name: 'Anna', email: 'not-an-email', guests: 2 })).toEqual({
      ok: false,
      kind: 'validation',
      errors: { email: 'Please enter a valid email address.' },
    });
    for (const guests of [0, 9, 2.5, Number.NaN, true, '0x2', [3], '2x', '']) {
      expect(service.book('riesling-evening', { ...guest, guests })).toEqual({
        ok: false,
        kind: 'validation',
        errors: { guests: 'Please choose between 1 and 8 guests.' },
      });
    }
  });

  it('reports an unknown tasting', () => {
    expect(createBookingService().book('no-such-tasting', guest)).toEqual({
      ok: false,
      kind: 'unknown-tasting',
    });
  });

  it('gives every booking a unique reference in the KB-XXXXXX format', () => {
    const service = createBookingService({
      tastings: [{ id: 'big', title: 'Big', date: '2026-11-06', time: '18:00', priceEur: 1, seats: 800 }],
    });

    const references = Array.from(
      { length: 200 },
      () => expectBooked(service.book('big', { ...guest, guests: 1 })).reference,
    );

    expect(new Set(references).size).toBe(200);
    for (const reference of references) {
      expect(reference).toMatch(REFERENCE_FORMAT);
    }
  });

  it('finds a booking by its reference and returns nothing for an unknown one', () => {
    const service = createBookingService();
    const booking = expectBooked(service.book('winter-tasting', guest));

    expect(service.getBooking(booking.reference)).toEqual(booking);
    expect(service.getBooking('KB-ZZZZZZ')).toBeUndefined();
  });
  it('frees the seats of a cancelled booking and reports nothing when the reference is unknown', () => {
    const service = createBookingService();
    const booking = expectBooked(service.book('red-wine-cellar-tour', { ...guest, guests: 5 }));
    expect(service.seatsLeft('red-wine-cellar-tour')).toBe(3);

    expect(service.cancel(booking.reference)).toBe(true);

    expect(service.seatsLeft('red-wine-cellar-tour')).toBe(8);
    expect(service.getBooking(booking.reference)).toBeUndefined();
    expect(service.cancel(booking.reference)).toBe(false);
  });

  it('lists active bookings per tasting with the guest contact details, in booking order', () => {
    const service = createBookingService();
    const first = expectBooked(service.book('riesling-evening', { ...guest, guests: 2 }));
    const cancelled = expectBooked(
      service.book('riesling-evening', { name: 'Ben', email: 'ben@example.com', guests: 1 }),
    );
    const second = expectBooked(
      service.book('riesling-evening', { name: 'Cara', email: 'cara@example.com', guests: 4 }),
    );
    service.cancel(cancelled.reference);

    const riesling = service.listBookingsByTasting().find((t) => t.id === 'riesling-evening');

    expect(riesling?.bookings).toEqual([
      { reference: first.reference, name: 'Anna Berger', email: 'anna@example.com', guests: 2 },
      { reference: second.reference, name: 'Cara', email: 'cara@example.com', guests: 4 },
    ]);
    expect(service.listBookingsByTasting().find((t) => t.id === 'winter-tasting')?.bookings).toEqual([]);
  });
});
