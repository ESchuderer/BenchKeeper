# Weingut Kieselbrunnen: tasting bookings

A small web app where guests book wine tastings online and staff see and cancel bookings.

- **Guests** see the three upcoming tastings with seats left, book seats through a form, and get a confirmation with a booking reference.
- **Staff** sign in at `/staff` with a shared password and see every booking grouped by tasting. They can cancel a booking, which frees its seats.

The app is a single Node.js process: an Express JSON API plus the React interface built with Vite.

## Requirements

- Node.js 22

## Run it

```sh
npm install
npm run build
PORT=3000 STAFF_PASSWORD='choose-a-password' npm start
```

Then open http://localhost:3000.

| Variable         | Default | Purpose                                                                                     |
| ---------------- | ------- | ------------------------------------------------------------------------------------------- |
| `PORT`           | `3000`  | Port the app listens on.                                                                    |
| `STAFF_PASSWORD` | unset   | Password for `/staff`. When unset, staff sign-in is disabled and shows a "not configured" message. |

## Develop

```sh
npm run dev        # API with auto-reload on PORT (default 3000) and Vite on http://localhost:5173
npm test             # unit, API and component tests
npm run test:e2e   # browser tests against a fresh build on port 3100
npm run typecheck  # TypeScript for client, shared and server code
```

The browser tests need Chromium once: `npx playwright install chromium`. On a Linux machine without the browser's system libraries, `npx playwright install-deps chromium` installs them.

`npm run dev` proxies `/api` from Vite to the API server, so open http://localhost:5173 while developing.

## Behaviour to know

- **Bookings are kept in memory.** The app starts with no bookings, and a restart clears all bookings and staff sign-ins. Keep this in mind before going live.
- **Seat limits hold for one server process.** Bookings are checked and saved in one step, so two guests cannot take the same last seat. Running several server processes would need a shared database.
- **Run it behind HTTPS in production.** The app does not terminate TLS itself, so the staff password would otherwise travel in clear text.
- Tasting details (dates, prices, seats) are fixed in `shared/catalog.ts`.

## Layout

```
shared/   tasting catalogue, validation schemas and formatting, used by server and client
server/   Express app, booking store, staff sessions, entry point (dist/server/index.js)
client/   React app (Vite root), pages and components
dist/     build output: dist/server (compiled server) and dist/client (static site)
openspec/ the change specification this app was built from (see openspec/changes/add-tasting-bookings)
```
