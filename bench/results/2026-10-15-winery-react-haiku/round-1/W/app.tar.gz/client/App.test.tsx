import { render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router';
import { App } from './App';
import { mockApi } from './test-utils';

function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('App shell', () => {
  it('shows the winery name in the header on every page', () => {
    mockApi({ 'GET /api/tastings': { body: [] } });
    renderAt('/');
    expect(screen.getByRole('banner')).toHaveTextContent('Weingut Kieselbrunnen');
  });

  it('renders the start page at /', async () => {
    mockApi({ 'GET /api/tastings': { body: [] } });
    renderAt('/');
    expect(await screen.findByRole('heading', { level: 1, name: 'Upcoming tastings' })).toBeInTheDocument();
  });

  it('renders the staff page at /staff', async () => {
    mockApi({ 'GET /api/staff/bookings': { status: 401, body: { error: 'Sign in' } } });
    renderAt('/staff');
    expect(await screen.findByRole('heading', { level: 1, name: 'Staff' })).toBeInTheDocument();
  });

  it('renders a not-found page for an unknown path', () => {
    mockApi({});
    renderAt('/no/such/page');
    expect(screen.getByRole('heading', { level: 1, name: 'Page not found' })).toBeInTheDocument();
  });
});

describe('App routes for guest pages', () => {
  it('opens the booking form for a tasting at /tastings/:id/book', async () => {
    mockApi({
      'GET /api/tastings/riesling-evening': {
        body: { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', priceEur: 25, seats: 12, seatsLeft: 12 },
      },
    });
    renderAt('/tastings/riesling-evening/book');
    expect(await screen.findByLabelText('Name')).toBeInTheDocument();
  });

  it('shows the confirmation at /bookings/:reference', async () => {
    mockApi({
      'GET /api/bookings/K7QF-M3HX': {
        body: {
          reference: 'K7QF-M3HX',
          tasting: { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00' },
          guests: 3,
          priceEur: 25,
          totalEur: 75,
        },
      },
    });
    renderAt('/bookings/K7QF-M3HX');
    expect(await screen.findByRole('heading', { level: 1, name: 'Booking confirmed' })).toBeInTheDocument();
  });
});
