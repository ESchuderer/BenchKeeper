import { Link, Outlet } from 'react-router';

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-wine-900 text-cream-100">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-5 py-5">
          <Link to="/" className="font-serif text-xl tracking-wide">
            Weingut Kieselbrunnen
          </Link>
          <Link to="/" className="text-sm text-cream-200 underline-offset-4 hover:underline">
            Tastings
          </Link>
        </div>
      </header>
      <main className="mx-auto w-full max-w-3xl flex-1 px-5 py-10">
        <Outlet />
      </main>
      <footer className="border-t border-wine-900/10 py-6 text-center text-sm text-ink-muted">
        Weingut Kieselbrunnen · Family winery
      </footer>
    </div>
  );
}
