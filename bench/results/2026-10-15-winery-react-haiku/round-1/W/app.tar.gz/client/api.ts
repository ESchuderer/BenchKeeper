export interface ApiErrorBody {
  error?: string;
  /** Field messages keyed by form field name, as the server returns them. */
  errors?: Record<string, string>;
}

export class ApiError extends Error {
  readonly status: number;
  readonly body: ApiErrorBody;

  constructor(status: number, body: ApiErrorBody) {
    super(body.error ?? `Request failed with status ${status}`);
    this.status = status;
    this.body = body;
  }
}

/** Calls the JSON API. Throws ApiError for any non-2xx response. */
export async function api<T>(path: string, init: RequestInit & { json?: unknown } = {}): Promise<T> {
  const { json, headers, ...rest } = init;
  const response = await fetch(path, {
    ...rest,
    headers: { Accept: 'application/json', ...(json !== undefined && { 'Content-Type': 'application/json' }), ...headers },
    ...(json !== undefined && { body: JSON.stringify(json) }),
  });
  if (response.status === 204) return undefined as T;
  const body = (await response.json().catch(() => ({}))) as ApiErrorBody | T;
  if (!response.ok) throw new ApiError(response.status, body as ApiErrorBody);
  return body as T;
}

export const GENERIC_FAILURE = 'Something went wrong. Please try again.';
