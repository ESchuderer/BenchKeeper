import { forwardRef, type ComponentPropsWithoutRef } from 'react';

interface FieldProps extends ComponentPropsWithoutRef<'input'> {
  label: string;
  error?: string;
}

/** A labelled input whose error message is linked to it for screen readers. */
export const Field = forwardRef<HTMLInputElement, FieldProps>(function Field(
  { label, error, id, name, className = '', ...input },
  ref,
) {
  const fieldId = id ?? name ?? label.toLowerCase();
  const errorId = `${fieldId}-error`;

  return (
    <div>
      <label htmlFor={fieldId} className="block text-sm font-medium text-ink">
        {label}
      </label>
      <input
        ref={ref}
        id={fieldId}
        name={name}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className={`mt-1.5 block w-full rounded-md border bg-cream-50 px-3.5 py-2.5 text-base text-ink shadow-inner focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500 ${
          error ? 'border-error' : 'border-wine-900/20'
        } ${className}`}
        {...input}
      />
      {error && (
        <p id={errorId} className="mt-1.5 text-sm text-error">
          {error}
        </p>
      )}
    </div>
  );
});
