import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter, Route, Routes, useParams } from 'react-router';
import { TASTINGS } from '../../shared/catalog';
import { mockApi } from '../test-utils';
import { BookingPage } from './BookingPage';

const riesling = { ...TASTINGS[0], seatsLeft: 12 };

function Confirmation() {
  const { reference } = useParams();
  return <p>Confirmation page for {reference}</p>;
}

function renderBooking() {
  return render(
    <MemoryRouter initialEntries={['/tastings/riesling-evening/book']}>
      <Routes>
        <Route path="/tastings/:tastingId/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<Confirmation />} />
      </Routes>
    </MemoryRouter>,
  );
}

async function fill(name: string, email: string, guests: string) {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText('Name'), name);
  await user.type(screen.getByLabelText('Email'), email);
  await user.type(screen.getByLabelText('Guests'), guests);
  return user;
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('BookingPage form', () => {
  it('shows the tasting and the Name, Email and Guests fields with a Book button', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': { body: riesling } });
    renderBooking();

    expect(await screen.findByRole('heading', { level: 1, name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows each invalid field message next to its field and sends nothing', async () => {
    const fetchMock = mockApi({ 'GET /api/tastings/riesling-evening': { body: riesling } });
    renderBooking();
    const user = userEvent.setup();
    await user.click(await screen.findByRole('button', { name: 'Book' }));

    expect(screen.getByLabelText('Name')).toHaveAccessibleDescription('Enter your name');
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Enter a valid email address');
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(
      'Choose between 1 and 8 guests',
    );
    expect(screen.getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true');
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'POST')).toBe(false);
  });

  it('rejects an email without a domain and keeps the other values', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': { body: riesling } });
    renderBooking();
    const user = await fill('Anna Keller', 'anna@example', '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Enter a valid email address');
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Keller');
    expect(screen.getByLabelText('Guests')).toHaveValue(2);
  });

  it('rejects 9 guests with the range message next to Guests', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': { body: riesling } });
    renderBooking();
    const user = await fill('Anna Keller', 'anna@example.com', '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(
      'Choose between 1 and 8 guests',
    );
  });

  it('shows the seats-left message next to Guests when the server has fewer seats', async () => {
    mockApi({
      'GET /api/tastings/riesling-evening': { body: riesling },
      'POST /api/tastings/riesling-evening/bookings': {
        status: 409,
        body: { errors: { guests: 'Only 2 seats left for this tasting.' } },
      },
    });
    renderBooking();
    const user = await fill('Anna Keller', 'anna@example.com', '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(
      'Only 2 seats left for this tasting.',
    );
  });

  it('shows the fully booked message on the form', async () => {
    mockApi({
      'GET /api/tastings/riesling-evening': { body: riesling },
      'POST /api/tastings/riesling-evening/bookings': {
        status: 409,
        body: { error: 'This tasting is fully booked.' },
      },
    });
    renderBooking();
    const user = await fill('Anna Keller', 'anna@example.com', '1');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('This tasting is fully booked.');
  });

  it.each([
    ['a server error', { status: 500, body: { error: 'boom' } }],
  ])('shows the failure message after %s and leaves seats unchanged', async (_label, reply) => {
    mockApi({
      'GET /api/tastings/riesling-evening': { body: riesling },
      'POST /api/tastings/riesling-evening/bookings': reply,
    });
    renderBooking();
    const user = await fill('Anna Keller', 'anna@example.com', '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Something went wrong. Your booking was not saved. Please try again.',
    );
  });

  it('shows the failure message when the network is unreachable', async () => {
    mockApi({ 'GET /api/tastings/riesling-evening': { body: riesling } });
    vi.stubGlobal(
      'fetch',
      vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => {
        if (init?.method === 'POST') throw new TypeError('Failed to fetch');
        return new Response(JSON.stringify(riesling), { headers: { 'Content-Type': 'application/json' } });
      }),
    );
    renderBooking();
    const user = await fill('Anna Keller', 'anna@example.com', '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Something went wrong. Your booking was not saved. Please try again.',
    );
  });

  it('sends the trimmed name and numeric guests, then opens the confirmation', async () => {
    const fetchMock = mockApi({
      'GET /api/tastings/riesling-evening': { body: riesling },
      'POST /api/tastings/riesling-evening/bookings': {
        status: 201,
        body: { reference: 'K7QF-M3HX' },
      },
    });
    renderBooking();
    const user = await fill('  Anna Keller ', 'anna@example.com', '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Confirmation page for K7QF-M3HX')).toBeInTheDocument();
    const post = fetchMock.mock.calls.find(([, init]) => init?.method === 'POST');
    expect(JSON.parse(String(post?.[1]?.body))).toEqual({
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: 3,
    });
  });
});

describe('BookingPage for an unknown tasting', () => {
  it('shows "Tasting not found" and no booking form', async () => {
    mockApi({ 'GET /api/tastings/no-such': { status: 404, body: { error: 'Tasting not found' } } });
    render(
      <MemoryRouter initialEntries={['/tastings/no-such/book']}>
        <Routes>
          <Route path="/tastings/:tastingId/book" element={<BookingPage />} />
        </Routes>
      </MemoryRouter>,
    );

    expect(await screen.findByRole('heading', { level: 1, name: 'Tasting not found' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).toBeNull();
  });
});
