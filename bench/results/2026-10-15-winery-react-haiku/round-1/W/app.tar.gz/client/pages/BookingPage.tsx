import { zodResolver } from '@hookform/resolvers/zod';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate, useParams } from 'react-router';
import type { ConfirmationView, TastingView } from '../../shared/api';
import { formatEur, formatTastingDate } from '../../shared/format';
import { type BookingFormInput, type BookingInput, bookingInputSchema } from '../../shared/validation';
import { api, ApiError, GENERIC_FAILURE } from '../api';
import { Field } from '../components/Field';

type Load =
  | { status: 'loading' }
  | { status: 'not-found' }
  | { status: 'error' }
  | { status: 'ready'; tasting: TastingView };

const SAVE_FAILED = 'Something went wrong. Your booking was not saved. Please try again.';

export function BookingPage() {
  const { tastingId = '' } = useParams();
  const navigate = useNavigate();
  const [load, setLoad] = useState<Load>({ status: 'loading' });
  const [formError, setFormError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingFormInput, unknown, BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '', guests: '' },
  });

  useEffect(() => {
    const controller = new AbortController();
    setLoad({ status: 'loading' });
    api<TastingView>(`/api/tastings/${encodeURIComponent(tastingId)}`, { signal: controller.signal })
      .then((tasting) => setLoad({ status: 'ready', tasting }))
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        setLoad(error instanceof ApiError && error.status === 404 ? { status: 'not-found' } : { status: 'error' });
      });
    return () => controller.abort();
  }, [tastingId]);

  // The resolver has parsed the values: guests is a number and name is trimmed.
  async function onSubmit(values: BookingInput) {
    setFormError(null);
    try {
      const confirmation = await api<ConfirmationView>(
        `/api/tastings/${encodeURIComponent(tastingId)}/bookings`,
        { method: 'POST', json: values },
      );
      navigate(`/bookings/${confirmation.reference}`);
    } catch (error) {
      if (error instanceof ApiError && error.body.errors) {
        for (const [field, message] of Object.entries(error.body.errors)) {
          setError(field as keyof BookingFormInput, { type: 'server', message });
        }
        return;
      }
      // Client errors carry a message worth showing (e.g. fully booked); server errors do not.
      const clientMessage = error instanceof ApiError && error.status < 500 ? error.body.error : undefined;
      setFormError(clientMessage ?? SAVE_FAILED);
    }
  }

  if (load.status === 'loading') {
    return <p className="text-ink-muted">Loading…</p>;
  }
  if (load.status === 'not-found') {
    return <NotFound />;
  }
  if (load.status === 'error') {
    return (
      <p role="alert" className="rounded-md bg-red-50 px-4 py-3 text-error">
        {GENERIC_FAILURE}
      </p>
    );
  }

  const { tasting } = load;
  return (
    <section aria-labelledby="booking-title" className="grid gap-8">
      <div>
        <Link to="/" className="text-sm text-wine-700 underline-offset-4 hover:underline">
          ← All tastings
        </Link>
        <h1 id="booking-title" className="mt-3 font-serif text-3xl text-wine-900">
          {tasting.title}
        </h1>
        <p className="mt-2 text-ink-muted">
          {formatTastingDate(tasting.date)}, {tasting.time} · {formatEur(tasting.priceEur)} per guest
        </p>
      </div>

      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="grid gap-5 rounded-xl border border-wine-900/10 bg-cream-50 p-6 shadow-sm"
      >
        {formError && (
          <p role="alert" className="rounded-md bg-red-50 px-4 py-3 text-error">
            {formError}
          </p>
        )}

        <Field label="Name" autoComplete="name" error={errors.name?.message} {...register('name')} />
        <Field
          label="Email"
          type="email"
          autoComplete="email"
          inputMode="email"
          error={errors.email?.message}
          {...register('email')}
        />
        <Field
          label="Guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={8}
          step={1}
          error={errors.guests?.message}
          {...register('guests')}
        />

        <button
          type="submit"
          disabled={isSubmitting}
          className="mt-1 inline-flex items-center justify-center rounded-md bg-wine-700 px-5 py-3 font-medium text-cream-50 transition hover:bg-wine-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500 focus-visible:ring-offset-2 disabled:opacity-60"
        >
          Book
        </button>
      </form>
    </section>
  );
}

function NotFound() {
  return <h1 className="font-serif text-3xl text-wine-900">Tasting not found</h1>;
}
