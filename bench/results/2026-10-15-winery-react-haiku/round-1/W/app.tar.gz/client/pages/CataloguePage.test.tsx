import { render, screen, within } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router';
import { TASTINGS } from '../../shared/catalog';
import { mockApi } from '../test-utils';
import { CataloguePage } from './CataloguePage';

function renderPage() {
  return render(
    <MemoryRouter>
      <CataloguePage />
    </MemoryRouter>,
  );
}

const withSeats = (seatsLeft: Record<string, number>) =>
  TASTINGS.map((t) => ({ ...t, seatsLeft: seatsLeft[t.id] ?? t.seats }));

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('CataloguePage', () => {
  it('shows each tasting with its date and time, price per guest and seats left', async () => {
    mockApi({ 'GET /api/tastings': { body: withSeats({ 'riesling-evening': 9 }) } });
    renderPage();

    const card = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(card).getByText('Friday, 6 November 2026')).toBeInTheDocument();
    expect(within(card).getByText('18:00')).toBeInTheDocument();
    expect(within(card).getByText('EUR 25')).toBeInTheDocument();
    expect(within(card).getByText('9 seats left')).toBeInTheDocument();
  });

  it('gives each tasting with seats a "Book <title>" link to its booking form', async () => {
    mockApi({ 'GET /api/tastings': { body: withSeats({}) } });
    renderPage();

    const link = await screen.findByRole('link', { name: 'Book Red Wine Cellar Tour' });
    expect(link).toHaveAttribute('href', '/tastings/red-wine-cellar-tour/book');
  });

  it('marks a tasting with no seats left as fully booked, with no booking action', async () => {
    mockApi({ 'GET /api/tastings': { body: withSeats({ 'winter-tasting': 0 }) } });
    renderPage();

    const card = await screen.findByRole('article', { name: 'Winter Tasting' });
    expect(within(card).getByText('0 seats left')).toBeInTheDocument();
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(within(card).queryByRole('link', { name: 'Book Winter Tasting' })).toBeNull();
  });

  it('shows a clear message when the tastings cannot be loaded', async () => {
    mockApi({ 'GET /api/tastings': { status: 500, body: { error: 'boom' } } });
    renderPage();

    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Could not load the tastings. Please try again.',
    );
  });
});
