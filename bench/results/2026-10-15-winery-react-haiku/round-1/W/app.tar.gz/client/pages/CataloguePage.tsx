import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import type { TastingView } from '../../shared/api';
import { formatEur, formatTastingDate, seatsLeftText } from '../../shared/format';
import { api } from '../api';

type Load =
  | { status: 'loading' }
  | { status: 'error' }
  | { status: 'ready'; tastings: TastingView[] };

export function CataloguePage() {
  const [load, setLoad] = useState<Load>({ status: 'loading' });

  useEffect(() => {
    const controller = new AbortController();
    api<TastingView[]>('/api/tastings', { signal: controller.signal })
      .then((tastings) => setLoad({ status: 'ready', tastings }))
      .catch(() => {
        if (!controller.signal.aborted) setLoad({ status: 'error' });
      });
    return () => controller.abort();
  }, []);

  return (
    <section aria-labelledby="page-title">
      <h1 id="page-title" className="font-serif text-3xl text-wine-900">
        Upcoming tastings
      </h1>
      <p className="mt-2 text-ink-muted">Choose a tasting and reserve your seats online.</p>

      {load.status === 'loading' && <p className="mt-8 text-ink-muted">Loading tastings…</p>}

      {load.status === 'error' && (
        <p role="alert" className="mt-8 rounded-md bg-red-50 px-4 py-3 text-error">
          Could not load the tastings. Please try again.
        </p>
      )}

      {load.status === 'ready' && (
        <ul className="mt-8 grid gap-6">
          {load.tastings.map((tasting) => (
            <li key={tasting.id}>
              <TastingCard tasting={tasting} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function TastingCard({ tasting }: { tasting: TastingView }) {
  const soldOut = tasting.seatsLeft === 0;
  const titleId = `tasting-${tasting.id}`;

  return (
    <article
      aria-labelledby={titleId}
      className={`rounded-xl border bg-cream-50 p-6 shadow-sm ${
        soldOut ? 'border-sold-out/30' : 'border-wine-900/10'
      }`}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <h2 id={titleId} className="font-serif text-2xl text-wine-900">
          {tasting.title}
        </h2>
        {soldOut && (
          <span className="rounded-full bg-sold-out/15 px-3 py-1 text-sm font-medium text-sold-out">
            Fully booked
          </span>
        )}
      </div>

      <dl className="mt-4 grid gap-x-8 gap-y-3 text-sm sm:grid-cols-3">
        <div>
          <dt className="text-ink-muted">Date and time</dt>
          <dd className="mt-0.5 font-medium">
            <span className="block">{formatTastingDate(tasting.date)}</span>
            <span className="block text-ink-muted">{tasting.time}</span>
          </dd>
        </div>
        <div>
          <dt className="text-ink-muted">Price</dt>
          <dd className="mt-0.5 font-medium">
            {formatEur(tasting.priceEur)} <span className="font-normal text-ink-muted">per guest</span>
          </dd>
        </div>
        <div>
          <dt className="text-ink-muted">Availability</dt>
          <dd className={`mt-0.5 font-medium ${soldOut ? 'text-sold-out' : 'text-success'}`}>
            {seatsLeftText(tasting.seatsLeft)}
          </dd>
        </div>
      </dl>

      {!soldOut && (
        <Link
          to={`/tastings/${tasting.id}/book`}
          className="mt-6 inline-flex items-center rounded-md bg-wine-700 px-5 py-2.5 font-medium text-cream-50 transition hover:bg-wine-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500 focus-visible:ring-offset-2"
        >
          Book {tasting.title}
        </Link>
      )}
    </article>
  );
}
