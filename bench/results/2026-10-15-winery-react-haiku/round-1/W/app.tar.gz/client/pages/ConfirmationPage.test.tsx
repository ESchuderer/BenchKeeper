import { render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter, Route, Routes } from 'react-router';
import { mockApi } from '../test-utils';
import { ConfirmationPage } from './ConfirmationPage';

const confirmation = {
  reference: 'K7QF-M3HX',
  tasting: { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00' },
  guests: 3,
  priceEur: 25,
  totalEur: 75,
};

function renderConfirmation(path = '/bookings/K7QF-M3HX') {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
      </Routes>
    </MemoryRouter>,
  );
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('ConfirmationPage', () => {
  it('shows the heading, tasting, number of guests, total price and booking reference', async () => {
    mockApi({ 'GET /api/bookings/K7QF-M3HX': { body: confirmation } });
    renderConfirmation();

    expect(await screen.findByRole('heading', { level: 1, name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument();
    expect(screen.getByText('Guests').nextElementSibling).toHaveTextContent(/^3 guests$/);
    expect(screen.getByText('Total').nextElementSibling).toHaveTextContent('EUR 75');
    expect(screen.getByText('Booking reference').nextElementSibling).toHaveTextContent('K7QF-M3HX');
  });

  it('shows the date and time of the tasting', async () => {
    mockApi({ 'GET /api/bookings/K7QF-M3HX': { body: confirmation } });
    renderConfirmation();

    expect(await screen.findByText('Friday, 6 November 2026')).toBeInTheDocument();
    expect(screen.getByText('18:00')).toBeInTheDocument();
  });

  it('shows "Booking not found" for an unknown or cancelled reference', async () => {
    mockApi({ 'GET /api/bookings/ZZZZ-ZZZZ': { status: 404, body: { error: 'Booking not found' } } });
    renderConfirmation('/bookings/ZZZZ-ZZZZ');

    expect(await screen.findByRole('heading', { level: 1, name: 'Booking not found' })).toBeInTheDocument();
    expect(screen.queryByText('Booking confirmed')).toBeNull();
  });
});
