import { type ReactNode, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import type { ConfirmationView } from '../../shared/api';
import { formatEur, formatTastingDate, guestsText } from '../../shared/format';
import { api, ApiError, GENERIC_FAILURE } from '../api';

type Load =
  | { status: 'loading' }
  | { status: 'not-found' }
  | { status: 'error' }
  | { status: 'ready'; confirmation: ConfirmationView };

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const [load, setLoad] = useState<Load>({ status: 'loading' });

  useEffect(() => {
    const controller = new AbortController();
    setLoad({ status: 'loading' });
    api<ConfirmationView>(`/api/bookings/${encodeURIComponent(reference)}`, {
      signal: controller.signal,
    })
      .then((confirmation) => setLoad({ status: 'ready', confirmation }))
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        setLoad(error instanceof ApiError && error.status === 404 ? { status: 'not-found' } : { status: 'error' });
      });
    return () => controller.abort();
  }, [reference]);

  if (load.status === 'loading') {
    return <p className="text-ink-muted">Loading…</p>;
  }
  if (load.status === 'not-found') {
    return (
      <section className="grid gap-4">
        <h1 className="font-serif text-3xl text-wine-900">Booking not found</h1>
        <p className="text-ink-muted">Check the reference, or book a tasting from the start page.</p>
        <Link to="/" className="text-wine-700 underline-offset-4 hover:underline">
          Back to all tastings
        </Link>
      </section>
    );
  }
  if (load.status === 'error') {
    return (
      <p role="alert" className="rounded-md bg-red-50 px-4 py-3 text-error">
        {GENERIC_FAILURE}
      </p>
    );
  }

  const { confirmation } = load;
  return (
    <section aria-labelledby="confirmation-title" className="grid gap-6">
      <div className="rounded-xl border border-success/30 bg-success/10 p-6">
        <h1 id="confirmation-title" className="font-serif text-3xl text-success">
          Booking confirmed
        </h1>
        <p className="mt-2 text-ink">
          Thank you. Please keep your booking reference for your visit.
        </p>
      </div>

      <dl className="grid gap-4 rounded-xl border border-wine-900/10 bg-cream-50 p-6 shadow-sm sm:grid-cols-2">
        <Row label="Tasting" value={confirmation.tasting.title} />
        <Row
          label="Date and time"
          value={
            <>
              <span className="block">{formatTastingDate(confirmation.tasting.date)}</span>
              <span className="block">{confirmation.tasting.time}</span>
            </>
          }
        />
        <Row label="Guests" value={guestsText(confirmation.guests)} />
        <Row label="Price per guest" value={formatEur(confirmation.priceEur)} />
        <Row label="Total" value={formatEur(confirmation.totalEur)} strong />
        <Row label="Booking reference" value={confirmation.reference} strong mono />
      </dl>

      <Link to="/" className="justify-self-start text-wine-700 underline-offset-4 hover:underline">
        Back to all tastings
      </Link>
    </section>
  );
}

function Row({
  label,
  value,
  strong = false,
  mono = false,
}: {
  label: string;
  value: ReactNode;
  strong?: boolean;
  mono?: boolean;
}) {
  return (
    <div>
      <dt className="text-sm text-ink-muted">{label}</dt>
      <dd className={`mt-0.5 ${strong ? 'text-lg font-semibold text-wine-900' : 'font-medium'} ${mono ? 'font-mono tracking-wider' : ''}`}>
        {value}
      </dd>
    </div>
  );
}
