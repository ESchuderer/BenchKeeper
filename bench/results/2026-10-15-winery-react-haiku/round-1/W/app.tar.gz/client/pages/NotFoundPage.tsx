export function NotFoundPage() {
  return <h1 className="font-serif text-3xl text-wine-900">Page not found</h1>;
}
