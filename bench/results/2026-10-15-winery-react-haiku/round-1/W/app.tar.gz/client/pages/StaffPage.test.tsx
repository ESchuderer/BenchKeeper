import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router';
import { TASTINGS } from '../../shared/catalog';
import type { StaffBookingsView } from '../../shared/api';
import { mockApi } from '../test-utils';
import { StaffPage } from './StaffPage';

const SIGN_IN = 'POST /api/staff/session';
const LIST = 'GET /api/staff/bookings';

function groupsWith(bookings: Record<string, { reference: string; name: string; email: string; guests: number }[]>): StaffBookingsView {
  return {
    groups: TASTINGS.map((tasting) => {
      const list = bookings[tasting.id] ?? [];
      const taken = list.reduce((sum, b) => sum + b.guests, 0);
      return { tasting: { ...tasting, seatsLeft: tasting.seats - taken }, bookings: list };
    }),
  };
}

function renderStaff() {
  return render(
    <MemoryRouter>
      <StaffPage />
    </MemoryRouter>,
  );
}

async function signInWith(password: string) {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
  return user;
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('StaffPage sign-in', () => {
  it('shows a Password field and Sign in button, and no booking data, when signed out', async () => {
    mockApi({ [LIST]: { status: 401, body: { error: 'Sign in to see bookings.' } } });
    renderStaff();

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByRole('table')).toBeNull();
  });

  it('shows "Incorrect password." next to the field and keeps bookings hidden', async () => {
    mockApi({
      [LIST]: { status: 401, body: { error: 'Sign in to see bookings.' } },
      [SIGN_IN]: { status: 401, body: { errors: { password: 'Incorrect password.' } } },
    });
    renderStaff();
    await signInWith('wrong');

    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription('Incorrect password.');
    expect(screen.queryByRole('table')).toBeNull();
  });

  it('shows the sign-in failure when the password is empty and sends nothing', async () => {
    const fetchMock = mockApi({ [LIST]: { status: 401, body: { error: 'x' } } });
    renderStaff();
    const user = userEvent.setup();
    await user.click(await screen.findByRole('button', { name: 'Sign in' }));

    expect(screen.getByLabelText('Password')).toHaveAccessibleDescription('Enter the password');
    expect(fetchMock.mock.calls.some(([, init]) => init?.method === 'POST')).toBe(false);
  });

  it('shows the not-configured message when STAFF_PASSWORD is not set', async () => {
    mockApi({
      [LIST]: { status: 401, body: { error: 'x' } },
      [SIGN_IN]: { status: 503, body: { error: 'Staff sign-in is not configured.' } },
    });
    renderStaff();
    await signInWith('anything');

    expect(await screen.findByRole('alert')).toHaveTextContent('Staff sign-in is not configured.');
  });

  it('shows the too-many-attempts message after the limit is reached', async () => {
    mockApi({
      [LIST]: { status: 401, body: { error: 'x' } },
      [SIGN_IN]: { status: 429, body: { error: 'Too many attempts. Try again later.' } },
    });
    renderStaff();
    await signInWith('anything');

    expect(await screen.findByRole('alert')).toHaveTextContent('Too many attempts. Try again later.');
  });
});

describe('StaffPage booking list', () => {
  const bookings = {
    'riesling-evening': [{ reference: 'AAAA-BBBB', name: 'Anna Keller', email: 'anna@example.com', guests: 3 }],
    'winter-tasting': [
      { reference: 'CCCC-DDDD', name: 'Ben Ortiz', email: 'ben@example.com', guests: 2 },
      { reference: 'EEEE-FFFF', name: 'Clara Vogt', email: 'clara@example.com', guests: 4 },
    ],
  };

  function signedIn(extra: Record<string, unknown> = {}) {
    return mockApi({
      [LIST]: { body: groupsWith(bookings) },
      ...extra,
    });
  }

  it('groups the bookings by tasting, with name, email, guests and reference', async () => {
    signedIn();
    renderStaff();

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    const annaRow = within(riesling).getByRole('row', { name: /Anna Keller/ });
    expect(within(annaRow).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(annaRow).getByText('3')).toBeInTheDocument();
    expect(within(annaRow).getByText('AAAA-BBBB')).toBeInTheDocument();

    const winter = screen.getByRole('region', { name: 'Winter Tasting' });
    expect(within(winter).getByRole('row', { name: /Ben Ortiz/ })).toBeInTheDocument();
    expect(within(winter).getByRole('row', { name: /Clara Vogt/ })).toBeInTheDocument();
    expect(within(riesling).queryByRole('row', { name: /Ben Ortiz/ })).toBeNull();
  });

  it('says "No bookings yet." for a tasting without bookings', async () => {
    signedIn();
    renderStaff();

    const redWine = await screen.findByRole('region', { name: 'Red Wine Cellar Tour' });
    expect(within(redWine).getByText('No bookings yet.')).toBeInTheDocument();
  });

  it('cancels a booking in place, frees its seats and does not reload the list', async () => {
    const fetchMock = signedIn({ 'DELETE /api/staff/bookings/AAAA-BBBB': { status: 204 } });
    renderStaff();
    const user = userEvent.setup();
    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    await user.click(within(within(riesling).getByRole('row', { name: /Anna Keller/ })).getByRole('button', { name: 'Cancel' }));

    expect(await within(riesling).findByText('No bookings yet.')).toBeInTheDocument();
    expect(within(riesling).getByText('0 of 12 seats booked')).toBeInTheDocument();
    const listCalls = fetchMock.mock.calls.filter(([url, init]) => String(url) === '/api/staff/bookings' && !init?.method);
    expect(listCalls).toHaveLength(1);
  });

  it('shows "This booking no longer exists." and refreshes when the booking is already gone', async () => {
    const fetchMock = signedIn({
      [LIST]: [{ body: groupsWith(bookings) }, { body: groupsWith({ 'winter-tasting': bookings['winter-tasting'] }) }],
      'DELETE /api/staff/bookings/AAAA-BBBB': { status: 404, body: { error: 'This booking no longer exists.' } },
    });
    renderStaff();
    const user = userEvent.setup();
    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' });
    await user.click(within(within(riesling).getByRole('row', { name: /Anna Keller/ })).getByRole('button', { name: 'Cancel' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('This booking no longer exists.');
    expect(await within(riesling).findByText('No bookings yet.')).toBeInTheDocument();
    expect(fetchMock.mock.calls.filter(([, init]) => !init?.method)).toHaveLength(2);
  });

  it('signs out and shows the sign-in form again', async () => {
    signedIn({ 'DELETE /api/staff/session': { status: 204 } });
    renderStaff();
    const user = userEvent.setup();
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));

    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.queryByRole('region', { name: 'Riesling Evening' })).toBeNull();
  });
});
