import { zodResolver } from '@hookform/resolvers/zod';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import type { StaffBookingsView, StaffGroupView } from '../../shared/api';
import { formatTastingDate } from '../../shared/format';
import { staffPasswordSchema, type StaffPasswordInput } from '../../shared/validation';
import { api, ApiError, GENERIC_FAILURE } from '../api';
import { Field } from '../components/Field';

type View =
  | { status: 'checking' }
  | { status: 'signed-out' }
  | { status: 'signed-in'; groups: StaffGroupView[] }
  | { status: 'error' };

const GONE_MESSAGE = 'This booking no longer exists.';

export function StaffPage() {
  const [view, setView] = useState<View>({ status: 'checking' });
  const [formError, setFormError] = useState<string | null>(null);
  const [listError, setListError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<StaffPasswordInput>({
    resolver: zodResolver(staffPasswordSchema),
    defaultValues: { password: '' },
  });

  // A 401 from the bookings list means "not signed in": no separate status endpoint is needed.
  useEffect(() => {
    loadBookings(setView);
  }, []);

  async function onSignIn(values: StaffPasswordInput) {
    setFormError(null);
    try {
      await api<void>('/api/staff/session', { method: 'POST', json: values });
    } catch (error) {
      if (error instanceof ApiError && error.body.errors) {
        for (const [field, message] of Object.entries(error.body.errors)) {
          setError(field as keyof StaffPasswordInput, { type: 'server', message });
        }
        return;
      }
      // The server sends these messages on purpose (e.g. not configured, too many attempts).
      setFormError((error instanceof ApiError && error.body.error) || GENERIC_FAILURE);
      return;
    }
    await loadBookings(setView);
  }

  async function onSignOut() {
    await api<void>('/api/staff/session', { method: 'DELETE' }).catch(() => undefined);
    setListError(null);
    setView({ status: 'signed-out' });
  }

  async function onCancel(reference: string) {
    setListError(null);
    try {
      await api<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        setListError(GONE_MESSAGE);
        await loadBookings(setView);
      } else if (error instanceof ApiError && error.status === 401) {
        setView({ status: 'signed-out' });
      } else {
        setListError(GENERIC_FAILURE);
      }
      return;
    }
    // Remove the row locally rather than reloading the whole list.
    setView((current) =>
      current.status === 'signed-in'
        ? {
            status: 'signed-in',
            groups: current.groups.map((group) => {
              const freed = group.bookings
                .filter((b) => b.reference === reference)
                .reduce((seats, b) => seats + b.guests, 0);
              if (freed === 0) return group;
              return {
                tasting: { ...group.tasting, seatsLeft: group.tasting.seatsLeft + freed },
                bookings: group.bookings.filter((b) => b.reference !== reference),
              };
            }),
          }
        : current,
    );
  }

  return (
    <section aria-labelledby="staff-title" className="grid grid-cols-1 gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 id="staff-title" className="font-serif text-3xl text-wine-900">
          Staff
        </h1>
        {view.status === 'signed-in' && (
          <button
            type="button"
            onClick={onSignOut}
            className="rounded-md border border-wine-900/20 px-4 py-2 text-sm font-medium text-wine-900 hover:bg-wine-900/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500"
          >
            Sign out
          </button>
        )}
      </div>

      {view.status === 'checking' && <p className="text-ink-muted">Loading…</p>}

      {view.status === 'error' && (
        <p role="alert" className="rounded-md bg-red-50 px-4 py-3 text-error">
          {GENERIC_FAILURE}
        </p>
      )}

      {view.status === 'signed-out' && (
        <form
          noValidate
          onSubmit={handleSubmit(onSignIn)}
          className="grid max-w-sm gap-5 rounded-xl border border-wine-900/10 bg-cream-50 p-6 shadow-sm"
        >
          <p className="text-ink-muted">Sign in to see and manage bookings.</p>
          {formError && (
            <p role="alert" className="rounded-md bg-red-50 px-4 py-3 text-error">
              {formError}
            </p>
          )}
          <Field
            label="Password"
            type="password"
            autoComplete="current-password"
            error={errors.password?.message}
            {...register('password')}
          />
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center justify-center rounded-md bg-wine-700 px-5 py-3 font-medium text-cream-50 transition hover:bg-wine-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500 focus-visible:ring-offset-2 disabled:opacity-60"
          >
            Sign in
          </button>
        </form>
      )}

      {view.status === 'signed-in' && (
        <div className="grid grid-cols-1 gap-8">
          {listError && (
            <p role="alert" className="rounded-md bg-red-50 px-4 py-3 text-error">
              {listError}
            </p>
          )}
          {view.groups.map((group) => (
            <TastingGroup key={group.tasting.id} group={group} onCancel={onCancel} />
          ))}
        </div>
      )}
    </section>
  );
}

function TastingGroup({
  group,
  onCancel,
}: {
  group: StaffGroupView;
  onCancel: (reference: string) => void;
}) {
  const { tasting, bookings } = group;
  const titleId = `group-${tasting.id}`;
  const booked = tasting.seats - tasting.seatsLeft;

  return (
    <section aria-labelledby={titleId} className="min-w-0 rounded-xl border border-wine-900/10 bg-cream-50 p-5 shadow-sm">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 id={titleId} className="font-serif text-xl text-wine-900">
          {tasting.title}
        </h2>
        <p className="text-sm text-ink-muted">
          <span className="block">
            {formatTastingDate(tasting.date)}, {tasting.time}
          </span>
          <span className="block">{booked} of {tasting.seats} seats booked</span>
        </p>
      </div>

      {bookings.length === 0 ? (
        <p className="mt-4 text-ink-muted">No bookings yet.</p>
      ) : (
        // Phones stack each booking as a block; from sm up it is a normal table.
        <div className="mt-4">
          <table className="block w-full text-left text-sm sm:table">
            <thead className="max-sm:sr-only sm:table-header-group">
              <tr className="sm:table-row">
                <th scope="col" className="sm:py-2 sm:pr-4 sm:font-medium sm:text-ink-muted sm:table-cell">Name</th>
                <th scope="col" className="sm:py-2 sm:pr-4 sm:font-medium sm:text-ink-muted sm:table-cell">Email</th>
                <th scope="col" className="sm:py-2 sm:pr-4 sm:font-medium sm:text-ink-muted sm:table-cell">Guests</th>
                <th scope="col" className="sm:py-2 sm:pr-4 sm:font-medium sm:text-ink-muted sm:table-cell">Reference</th>
                <th scope="col" className="sm:py-2 sm:font-medium sm:table-cell">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="block sm:table-row-group">
              {bookings.map((booking) => (
                <tr
                  key={booking.reference}
                  className="block border-b border-wine-900/10 py-3 last:border-0 sm:table-row sm:py-0"
                >
                  <td data-label="Name" className="block py-0.5 font-medium before:mr-2 before:text-ink-muted before:content-[attr(data-label)] sm:before:content-none sm:table-cell sm:py-3 sm:pr-4">
                    {booking.name}
                  </td>
                  <td data-label="Email" className="block break-all py-0.5 before:mr-2 before:text-ink-muted before:content-[attr(data-label)] sm:before:content-none sm:table-cell sm:py-3 sm:pr-4">
                    {booking.email}
                  </td>
                  <td data-label="Guests" className="block py-0.5 before:mr-2 before:text-ink-muted before:content-[attr(data-label)] sm:before:content-none sm:table-cell sm:py-3 sm:pr-4">
                    {booking.guests}
                  </td>
                  <td data-label="Reference" className="block py-0.5 font-mono tracking-wider before:mr-2 before:text-ink-muted before:content-[attr(data-label)] sm:before:content-none sm:table-cell sm:py-3 sm:pr-4">
                    {booking.reference}
                  </td>
                  <td className="block pt-2 text-right sm:table-cell sm:py-3 sm:pt-3">
                    <button
                      type="button"
                      onClick={() => onCancel(booking.reference)}
                      className="rounded-md px-3 py-1.5 font-medium text-error hover:bg-red-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500"
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

async function loadBookings(setView: (view: View) => void) {
  try {
    const bookings = await api<StaffBookingsView>('/api/staff/bookings');
    setView({ status: 'signed-in', groups: bookings.groups });
  } catch (error) {
    setView(error instanceof ApiError && error.status === 401 ? { status: 'signed-out' } : { status: 'error' });
  }
}
