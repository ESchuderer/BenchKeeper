import { vi } from 'vitest';

export interface MockReply {
  status?: number;
  body?: unknown;
}

/**
 * Replaces fetch with replies keyed by "METHOD path", e.g. "GET /api/tastings".
 * A key may list several replies: they are used in order, and the last one repeats.
 */
export function mockApi(replies: Record<string, MockReply | MockReply[]>) {
  const used = new Map<string, number>();
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input), 'http://localhost');
    const method = (init?.method ?? 'GET').toUpperCase();
    const key = `${method} ${url.pathname}`;
    const entry = replies[key];
    if (!entry) throw new Error(`Unexpected request: ${key}`);
    const list = Array.isArray(entry) ? entry : [entry];
    const index = Math.min(used.get(key) ?? 0, list.length - 1);
    used.set(key, index + 1);
    const reply = list[index];
    const status = reply.status ?? 200;
    const body = reply.body === undefined ? null : JSON.stringify(reply.body);
    return new Response(status === 204 ? null : body, {
      status,
      headers: { 'Content-Type': 'application/json' },
    });
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}
