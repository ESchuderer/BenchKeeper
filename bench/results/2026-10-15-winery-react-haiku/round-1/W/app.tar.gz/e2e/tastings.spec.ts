import { expect, test, type Page } from '@playwright/test';

const STAFF_PASSWORD = 'e2e-password';

async function bookViaForm(page: Page, tastingId: string, name: string, email: string, guests: string) {
  await page.goto(`/tastings/${tastingId}/book`);
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Guests').fill(guests);
  await page.getByRole('button', { name: 'Book' }).click();
}

async function signInAsStaff(page: Page) {
  await page.goto('/staff');
  await page.getByLabel('Password').fill(STAFF_PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
}

// Serial: each test builds on the bookings made by the tests before it.
test.describe.serial('tasting bookings', () => {
  test('a guest books seats and staff see and cancel the booking', async ({ page }) => {
    await page.goto('/');
    const riesling = page.getByRole('article', { name: 'Riesling Evening' });
    await expect(riesling.getByText('12 seats left')).toBeVisible();

    await riesling.getByRole('link', { name: 'Book Riesling Evening' }).click();
    await page.getByLabel('Name').fill('Anna Keller');
    await page.getByLabel('Email').fill('anna@example.com');
    await page.getByLabel('Guests').fill('3');
    await page.getByRole('button', { name: 'Book' }).click();

    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    // 3 guests at EUR 25 each.
    await expect(page.locator('dd').filter({ hasText: /^EUR 75$/ })).toBeVisible();
    await expect(page.getByText('Booking reference', { exact: true })).toBeVisible();

    await page.getByRole('link', { name: 'Back to all tastings' }).click();
    await expect(riesling.getByText('9 seats left')).toBeVisible();

    await signInAsStaff(page);
    const group = page.getByRole('region', { name: 'Riesling Evening' });
    const row = group.getByRole('row', { name: /Anna Keller/ });
    await expect(row).toBeVisible();
    await row.getByRole('button', { name: 'Cancel' }).click();
    await expect(group.getByText('No bookings yet.')).toBeVisible();

    await page.goto('/');
    await expect(riesling.getByText('12 seats left')).toBeVisible();
  });

  test('a booking cannot take more seats than are left', async ({ page, request }) => {
    const filled = await request.post('/api/tastings/red-wine-cellar-tour/bookings', {
      data: { name: 'Ben Ortiz', email: 'ben@example.com', guests: 6 },
    });
    expect(filled.status()).toBe(201);

    await bookViaForm(page, 'red-wine-cellar-tour', 'Clara Vogt', 'clara@example.com', '3');

    await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('Only 2 seats left for this tasting.');
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
  });

  test('a fully booked tasting shows as such on the start page', async ({ page, request }) => {
    // A single booking is capped at 8 guests, so fill the 10 seats with two bookings.
    for (const guests of [8, 2]) {
      const filled = await request.post('/api/tastings/winter-tasting/bookings', {
        data: { name: 'Dora Lenz', email: 'dora@example.com', guests },
      });
      expect(filled.status()).toBe(201);
    }

    await page.goto('/');
    const winter = page.getByRole('article', { name: 'Winter Tasting' });
    await expect(winter.getByText('Fully booked')).toBeVisible();
    await expect(winter.getByRole('link', { name: 'Book Winter Tasting' })).toHaveCount(0);
  });

  test('a wrong staff password is refused next to the field', async ({ page }) => {
    await page.goto('/staff');
    await page.getByLabel('Password').fill('not-the-password');
    await page.getByRole('button', { name: 'Sign in' }).click();

    await expect(page.getByLabel('Password')).toHaveAccessibleDescription('Incorrect password.');
    await expect(page.getByRole('table')).toHaveCount(0);
  });

  test('the layout fits a phone and a desktop screen, and the key states look right', async ({ page }) => {
    const sizes = [
      { label: 'phone', width: 390, height: 844 },
      { label: 'desktop', width: 1280, height: 900 },
    ];

    for (const size of sizes) {
      await page.setViewportSize({ width: size.width, height: size.height });

      await page.goto('/');
      await expect(page.getByRole('article', { name: 'Winter Tasting' })).toBeVisible();
      await page.screenshot({ path: `test-results/${size.label}-catalogue.png`, fullPage: true });

      await page.goto('/tastings/riesling-evening/book');
      await page.getByRole('button', { name: 'Book' }).click();
      await expect(page.getByLabel('Name')).toHaveAccessibleDescription('Enter your name');
      await page.screenshot({ path: `test-results/${size.label}-validation.png`, fullPage: true });

      await bookViaForm(page, 'riesling-evening', `Visitor ${size.label}`, `${size.label}@example.com`, '2');
      await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
      await page.screenshot({ path: `test-results/${size.label}-confirmation.png`, fullPage: true });

      await signInAsStaff(page);
      await expect(page.getByRole('region', { name: 'Riesling Evening' }).getByRole('row', { name: new RegExp(`Visitor ${size.label}`) })).toBeVisible();
      await page.screenshot({ path: `test-results/${size.label}-staff.png`, fullPage: true });
      await page.getByRole('button', { name: 'Sign out' }).click();

      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
      expect(overflow, `horizontal overflow at ${size.label} width`).toBeLessThanOrEqual(0);
    }
  });
});
