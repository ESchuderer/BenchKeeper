# Design

## Context

The repository contains only the OpenSpec scaffolding and agent configuration, so there is no existing application code to extend. The app is a single small site for one winery: three fixed tastings, a few dozen guests at most, and two audiences (guests and staff). It runs in the development container with Node.js 22 and must start with `npm start` after `npm install` and `npm run build`. No external services are available. See proposal.md for motivation.

## Goals / Non-Goals

**Goals:**
- One process serves the React interface and the JSON API on `PORT`.
- Seat capacity is enforced on the server, so no client can overbook.
- Validation rules are written once and used by both the form (immediate feedback) and the server (authoritative).
- A small, maintained set of libraries covers the server, routing, forms and styling; no hand-written framework replacements.
- The visual design reads as a small winery's own site and works on phones.

**Non-Goals:**
- Payments, email confirmations, or reminders.
- Editing tastings, prices or seat counts from the UI; they are fixed in code.
- Persistent storage across restarts (see Decisions).
- Multiple staff accounts, roles, or an audit log.
- Multi-instance deployment. The capacity guarantee assumes a single server process.

## Decisions

**Stack.** Express 5 serves the API and the built client. React 19 with React Router handles pages. React Hook Form with the Zod resolver handles the forms. Tailwind CSS v4 handles styling. Vite builds the client, and `tsc` compiles the server. TypeScript is used throughout.
- Alternative: a full-stack framework (Next.js, React Router framework mode). Rejected: SSR and a second runtime add deployment surface a single-process winery site does not need.
- Alternative: Fastify. Rejected only because Express is the more widely known choice for a small app; either would meet the brief.

**Shared validation.** A `shared/` module holds the tasting catalogue, the Zod schemas for booking input and staff sign-in, and date formatting. The server imports the same schemas the form uses, so the rules in the spec are enforced in one place.

**Capacity is checked inside the store.** The booking store checks seats left and inserts the booking in one synchronous step. Node runs JavaScript on one thread, so two requests cannot interleave between the check and the insert. This satisfies the "never overbooked" requirement, including the simultaneous-booking scenario. If the app ever runs on several processes, this guarantee must move into a database transaction.

**Storage is in memory.** Bookings live in a `Map` keyed by reference. This matches "the app starts with no bookings" literally and needs no file handling. The store sits behind a small interface so a file or database store can replace it later without touching routes. Trade-off: a restart clears all bookings. Staff should be told this before the site goes live; see Open Questions.

**Booking references.** Eight characters drawn with `crypto.randomInt` from an alphabet without look-alike characters (no 0/O, 1/I/L), displayed in two groups of four. The store regenerates on the rare collision. Confirmation pages are addressed by reference (`/bookings/:reference`), so a reload or a shared link shows the same confirmation without re-booking.

**Dates and prices.** Dates and times are stored as strings (`2026-11-06`, `18:00`) with no time zone and formatted with UTC-based helpers, so the winery's local time is shown everywhere without conversion. Prices are whole euros, so the total is `guests × price` with no rounding.

**Staff session.** `POST /api/staff/session` compares the submitted password with `STAFF_PASSWORD` using `crypto.timingSafeEqual` on equal-length digests. On success it issues a random 32-byte token, stored in memory, sent as an `HttpOnly`, `SameSite=Strict` cookie. Sign-out deletes the token. Restarting the server invalidates all sessions, which matches the spec. If `STAFF_PASSWORD` is unset or empty, sign-in returns 503 and nothing else changes.
- Alternative: signed cookies with an HMAC secret. Rejected: needs a second secret to manage for no gain over an in-memory token in a single process.

**Sign-in rate limit.** `express-rate-limit` on the sign-in route with a 15-minute window and a limit of 10, counting failed attempts only (`skipSuccessfulRequests`). Its custom handler returns 429 with "Too many attempts. Try again later." The limit is per client address.

**Routes.**
- Pages: `/` (catalogue), `/tastings/:tastingId/book` (booking form), `/bookings/:reference` (confirmation), `/staff` (sign-in and list). Unknown paths and unknown tasting or booking references render their "not found" states.
- API: `GET /api/tastings`, `GET /api/tastings/:id`, `POST /api/tastings/:id/bookings`, `GET /api/bookings/:reference`, `POST /api/staff/session`, `DELETE /api/staff/session`, `GET /api/staff/bookings`, `DELETE /api/staff/bookings/:reference`.
- Errors: 400 for field errors (`{ errors: { field: message } }`), 409 for seat conflicts (guests field or form-level message), 404 for unknown tastings and bookings, 401 for unsigned staff requests, 429 and 503 for the sign-in cases above.

**Staff sign-in state.** The staff page asks the bookings endpoint on load; a 401 means "show the sign-in form". This avoids a separate session-status endpoint.

**Visual design.** Tailwind theme tokens for wine red, cream paper and slate ink; a serif heading face from the system font stack (no web-font requests, since the app has no external services); a single-column layout on phones that widens for the catalogue and staff tables. Fully booked tastings use a muted badge; errors use a red message beside the field with `aria-describedby`; success uses a green confirmation panel.

**Build and run.** `npm run build` runs `tsc` for the server (output `dist/server`) and `vite build` for the client (output `dist/client`). `npm start` runs `node dist/server/index.js`, which serves `dist/client` and falls back to `index.html` for page routes. `npm run dev` runs the server with `tsx watch` and Vite with an `/api` proxy.

## Risks / Trade-offs

- **Bookings lost on restart** → Staff are told; the store interface allows a file store later with no route changes.
- **Capacity guarantee is single-process only** → Documented in Non-Goals; a multi-instance deploy must move the check into a transaction.
- **Sign-in rate limit is per IP and in memory** → A shared IP (for example, a venue Wi-Fi) can lock out other staff for 15 minutes. Acceptable for a small team; the limit resets on restart.
- **No HTTPS in the app** → The `HttpOnly` cookie still protects the token from scripts, but the password crosses the network in clear text over plain HTTP. Deployments must sit behind TLS.
- **Guest booking lookup by reference** → Anyone with a reference can view the confirmation (tasting, guest count, total, reference only). References are random and long enough that guessing is impractical, and no name or email is shown there.

## Open Questions

- Should bookings survive a restart (a JSON file in a configurable path)? The current design keeps them in memory per the brief. Switching later is a store-only change and does not alter specs.
