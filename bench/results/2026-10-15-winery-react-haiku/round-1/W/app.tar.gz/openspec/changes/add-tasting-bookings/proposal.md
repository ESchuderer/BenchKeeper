# Proposal

## Why

Weingut Kieselbrunnen has no online way for guests to reserve seats at its tastings, so bookings arrive by phone or email and seat counts are tracked by hand. This change adds a small web app where guests book tastings online and staff see and manage the resulting bookings.

## What Changes

- Add a public page listing the three upcoming tastings with date, time, price per guest and seats left, with clear states for fully booked tastings.
- Add a booking form per tasting (Name, Email, Guests 1–8) that rejects invalid input next to the field concerned and never accepts more guests than seats left.
- Add a booking confirmation page showing the tasting, number of guests, total price and a booking reference.
- Add a staff area at `/staff`, protected by a password read from the `STAFF_PASSWORD` environment variable, that lists bookings grouped by tasting and lets staff cancel a booking, which frees its seats.
- Serve the React interface and the JSON API from one Node.js process on `PORT` (default 3000).
- Keep bookings in memory: the app starts with no bookings and a restart clears them.

No existing behavior is changed; the repository has no prior application code.

## Capabilities

### New Capabilities

- `tasting-catalog`: The fixed set of tastings offered, and how each one's date, price, capacity and seats left are presented to guests.
- `tasting-booking`: The guest flow for reserving seats: booking form, validation, seat capacity enforcement, and the booking confirmation.
- `staff-bookings`: Staff sign-in with the shared password, and the staff view of bookings grouped by tasting with cancellation.

### Modified Capabilities

None.

## Impact

- New application code: a Node.js/Express server exposing a small JSON API, and a React single-page interface built with Vite.
- New dependencies (see design.md for the chosen libraries): React, React Router, Express, Zod, React Hook Form, Tailwind CSS, Vite, and test tooling.
- New runtime configuration: `PORT` (optional, default 3000) and `STAFF_PASSWORD` (required to enable staff sign-in).
- No external services, no database, no authentication provider.
