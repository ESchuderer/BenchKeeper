# Spec Delta

## Purpose

Gives Weingut Kieselbrunnen staff a password-protected page to see every booking grouped by tasting and to cancel a booking, freeing its seats. It is the only place where booking details beyond the guest's own confirmation are visible.

## ADDED Requirements

### Requirement: Staff sign-in
The staff page at `/staff` SHALL show a sign-in form with a "Password" field and a "Sign in" button until staff are signed in. Sign-in SHALL succeed only when the password equals the value of the `STAFF_PASSWORD` environment variable.

#### Scenario: Sign-in form is shown
- **WHEN** a visitor who is not signed in opens `/staff`
- **THEN** the page shows a "Password" field and a "Sign in" button and no booking data

#### Scenario: Correct password
- **WHEN** staff enter the configured password and press "Sign in"
- **THEN** the staff booking list is shown

#### Scenario: Wrong password
- **WHEN** staff enter a password that does not match
- **THEN** the message "Incorrect password." is shown and the visitor remains signed out

#### Scenario: Staff password not configured
- **WHEN** `STAFF_PASSWORD` is unset or empty and someone presses "Sign in"
- **THEN** the message "Staff sign-in is not configured." is shown and the visitor remains signed out

### Requirement: Session persists until sign-out or restart
A signed-in staff session SHALL remain valid across page reloads until staff sign out or the server restarts. The system SHALL provide a "Sign out" action that ends the session.

#### Scenario: Reload keeps the session
- **WHEN** a signed-in staff member reloads `/staff`
- **THEN** the booking list is shown without asking for the password again

#### Scenario: Sign out
- **WHEN** a signed-in staff member presses "Sign out"
- **THEN** the sign-in form is shown and the booking data is no longer available to that browser

### Requirement: Booking data requires a session
The system SHALL NOT return booking data, including the list of bookings and any booking details, to a request that has no valid staff session.

#### Scenario: Unsigned request for bookings
- **WHEN** a request for the staff booking list arrives without a valid staff session
- **THEN** the system responds with status 401 and returns no booking data

### Requirement: Limit on failed sign-in attempts
The system SHALL allow at most 10 failed sign-in attempts per client in a 15-minute window. Once a client has used those 10 failed attempts in the window, further sign-in attempts from that client SHALL be rejected for the rest of the window with "Too many attempts. Try again later.", even if the password is correct.

#### Scenario: Attempt after ten failures
- **WHEN** a client has made 10 failed sign-in attempts within the current 15-minute window and makes another attempt, with the correct password
- **THEN** the message "Too many attempts. Try again later." is shown and the visitor remains signed out

### Requirement: Bookings grouped by tasting
The staff booking list SHALL show the bookings grouped by tasting, in the order of the tastings. Each group SHALL show the tasting title, its date and time, and each booking's name, email, guests and booking reference. A tasting without bookings SHALL show "No bookings yet."

#### Scenario: Two tastings with bookings
- **WHEN** staff view the list and Riesling Evening has one booking and Winter Tasting has two
- **THEN** the Riesling Evening group shows one row and the Winter Tasting group shows two rows, each with name, email, guests and reference

#### Scenario: Tasting without bookings
- **WHEN** staff view the list and Red Wine Cellar Tour has no bookings
- **THEN** its group shows "No bookings yet."

### Requirement: Cancel a booking
The system SHALL give each booking a "Cancel" button. Activating it SHALL remove the booking, free its guests' seats for its tasting, and remove the row from the staff list without reloading the page.

#### Scenario: Cancel a booking
- **WHEN** staff press "Cancel" on a booking for 2 guests
- **THEN** the booking disappears from the list and the tasting's seats left increase by 2

#### Scenario: Booking already gone
- **WHEN** staff press "Cancel" on a booking that was already cancelled
- **THEN** the message "This booking no longer exists." is shown and the list is refreshed
