# Spec Delta

## Purpose

Lets a guest reserve seats at an offered tasting through a booking form, with input validated and seat capacity enforced, and receive a booking reference as confirmation. Staff rely on each booking being recorded exactly once.

## ADDED Requirements

### Requirement: Booking form fields
The booking form for a tasting SHALL have the fields labelled "Name", "Email" and "Guests", and a "Book" button. The Guests field SHALL accept whole numbers from 1 to 8.

#### Scenario: Form shows the required fields
- **WHEN** a guest opens the booking form for Winter Tasting
- **THEN** the form shows a "Name" field, an "Email" field, a "Guests" field and a "Book" button, and the tasting title "Winter Tasting"

### Requirement: Input validation next to the field
The system SHALL reject a submission with missing or invalid input and SHALL show each error message next to the field it concerns. Name MUST be non-blank after trimming and at most 100 characters. Email MUST be a valid email address of at most 254 characters. Guests MUST be a whole number from 1 to 8.

#### Scenario: Empty name
- **WHEN** a guest submits the form with the Name field blank
- **THEN** the message "Enter your name" is shown next to the Name field and no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits the form with the Email field "anna@example"
- **THEN** the message "Enter a valid email address" is shown next to the Email field and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits the form with Guests set to 0 or 9
- **THEN** the message "Choose between 1 and 8 guests" is shown next to the Guests field and no booking is created

#### Scenario: Entered values are kept after an error
- **WHEN** a submission is rejected for an invalid field
- **THEN** the values the guest already entered in the other fields remain in the form

### Requirement: Seats are never overbooked
The system SHALL reject a booking whose guests exceed the seats left for its tasting at the moment the booking is made. The rejection SHALL name the seats left next to the Guests field. Concurrent bookings SHALL NOT together take more seats than the tasting has.

#### Scenario: Requested guests exceed seats left
- **WHEN** a guest books 4 guests for a tasting with 3 seats left
- **THEN** the message "Only 3 seats left for this tasting." is shown next to the Guests field and no booking is created

#### Scenario: Two bookings compete for the last seats
- **WHEN** two guests submit bookings for 2 guests each for a tasting with 3 seats left, at the same time
- **THEN** exactly one booking is created and the other is rejected with the seats-left message

#### Scenario: Fully booked tasting cannot be booked
- **WHEN** a guest submits the form for a tasting with zero seats left
- **THEN** the form shows the message "This tasting is fully booked." and no booking is created

### Requirement: Booking confirmation
After a successful booking the system SHALL show a confirmation page with the heading "Booking confirmed", the tasting title, the number of guests, the total price as "EUR <n>" (guests multiplied by the price per guest), and the booking reference.

#### Scenario: Confirmation after booking
- **WHEN** a guest books 2 guests for Red Wine Cellar Tour
- **THEN** the page shows the heading "Booking confirmed", "Red Wine Cellar Tour", "2 guests", "EUR 64" as the total, and a booking reference

#### Scenario: Confirmation can be reopened
- **WHEN** a guest opens the confirmation address that contains the booking reference again
- **THEN** the same confirmation details are shown

#### Scenario: Unknown booking reference
- **WHEN** a guest opens a confirmation address with a reference that does not exist or was cancelled
- **THEN** the page shows "Booking not found" and no booking details

### Requirement: Booking references are unique
The system SHALL give every booking a booking reference that is unique among current bookings and hard to guess, and SHALL NOT reuse a reference of a cancelled booking.

#### Scenario: Two bookings get different references
- **WHEN** two bookings are created
- **THEN** their booking references are different

### Requirement: Failure leaves no partial booking
If the booking cannot be saved, the system SHALL show "Something went wrong. Your booking was not saved. Please try again." and SHALL NOT reduce the seats left.

#### Scenario: Server error during booking
- **WHEN** the server fails while saving a booking
- **THEN** the form shows the failure message, the seats left are unchanged, and the guest may submit again
