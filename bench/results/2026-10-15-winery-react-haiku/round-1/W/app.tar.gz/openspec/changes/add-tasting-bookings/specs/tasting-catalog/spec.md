# Spec Delta

## Purpose

Describes the tastings Weingut Kieselbrunnen offers and how guests see each tasting's date, price and remaining seats before they book. It is the public starting point for every booking.

## ADDED Requirements

### Requirement: Offered tastings
The system SHALL offer exactly three tastings, with these fixed details: Riesling Evening on 2026-11-06 at 18:00, EUR 25 per guest, 12 seats; Red Wine Cellar Tour on 2026-11-14 at 15:00, EUR 32 per guest, 8 seats; Winter Tasting on 2026-12-05 at 17:00, EUR 28 per guest, 10 seats.

#### Scenario: Start page lists all tastings
- **WHEN** a guest opens the start page
- **THEN** the page lists Riesling Evening, Red Wine Cellar Tour and Winter Tasting, in that order

#### Scenario: Tasting details are shown
- **WHEN** a guest views the start page
- **THEN** each tasting shows its title, its date and time, its price as "EUR <n>" per guest, and its seats left as "<n> seats left"

### Requirement: Date and time are shown as winery local time
The system SHALL show each tasting's date and time exactly as configured, without converting them to another time zone, so every guest sees the same date and time.

#### Scenario: Riesling Evening date
- **WHEN** a guest views Riesling Evening
- **THEN** the date shown is 6 November 2026 and the time shown is 18:00

### Requirement: Seats left reflect bookings
The system SHALL compute seats left for a tasting as its seat total minus the guests of all of its current bookings, and SHALL update it as bookings are made and cancelled.

#### Scenario: Seats left after a booking
- **WHEN** a booking for 3 guests is made for Red Wine Cellar Tour
- **THEN** the start page shows "5 seats left" for Red Wine Cellar Tour

#### Scenario: Seats freed by cancellation
- **WHEN** a booking for 3 guests on Red Wine Cellar Tour is cancelled by staff
- **THEN** the start page shows the seats left increased by 3

### Requirement: Fully booked tastings
The system SHALL show a tasting with zero seats left as "Fully booked" and SHALL NOT offer a booking action for it.

#### Scenario: Tasting is fully booked
- **WHEN** a tasting has zero seats left
- **THEN** the start page shows "0 seats left" together with a "Fully booked" label, and no "Book <tasting title>" action is shown for that tasting

### Requirement: Booking action per tasting
The system SHALL give each tasting that has seats left a "Book <tasting title>" link or button that opens the booking form for that tasting.

#### Scenario: Book Riesling Evening
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens

### Requirement: Unknown tasting
The system SHALL show a "Tasting not found" page for any tasting address that does not match an offered tasting.

#### Scenario: Unknown tasting address
- **WHEN** a guest opens the booking form address of a tasting that is not offered
- **THEN** the page shows the heading "Tasting not found" and no booking form
