# Tasks

Tests for each group are written before the code they cover and must fail first (red), then pass (green).

## 1. Project setup

- [x] 1.1 Add `package.json` (type module, Node 22 engines) with runtime dependencies (react, react-dom, react-router, express, cookie-parser, express-rate-limit, zod, react-hook-form, @hookform/resolvers) and dev dependencies (typescript, vite, @vitejs/plugin-react, tailwindcss, @tailwindcss/vite, tsx, concurrently, vitest, jsdom, supertest, @testing-library/react, @testing-library/user-event, @testing-library/jest-dom, and their @types packages); verify `npm install` completes with no errors
- [x] 1.2 Add `tsconfig.json` (client, JSX, no emit), `tsconfig.server.json` (emits `dist/server` and `dist/shared`), and `vite.config.ts` (React and Tailwind plugins, `/api` proxy for dev, build output `dist/client`); verify `npm run typecheck` passes on an empty `src` placeholder
- [x] 1.3 Add Vitest configuration with two projects (node for `server` and `shared`, jsdom for `client`) and a `test` script; verify `npm test` runs and reports zero failing suites on a placeholder test

## 2. Shared catalogue and validation

- [x] 2.1 Write failing tests for the catalogue: exactly three tastings with the fixed titles, dates, times, prices and seats from the tasting-catalog spec, and stable ids (`riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`); verify they fail for the right reason
- [x] 2.2 Implement the catalogue module to pass 2.1; verify `npm test` shows those tests green
- [x] 2.3 Write failing tests for date formatting ("6 November 2026" style, derived without time-zone conversion) and for the total-price helper (`guests × price`, formatted as "EUR <n>"); verify they fail
- [x] 2.4 Implement the formatting and total-price helpers to pass 2.3; verify green
- [x] 2.5 Write failing tests for the booking-input schema: Name blank/whitespace rejected with "Enter your name" and 100-character limit; Email invalid rejected with "Enter a valid email address" and 254-character limit; Guests 0, 9, 1.5 and non-numeric rejected with "Choose between 1 and 8 guests"; valid input accepted; verify they fail
- [x] 2.6 Implement the booking-input and staff-password schemas to pass 2.5; verify green

## 3. Booking store

- [x] 3.1 Write failing tests for the store: seats left equals seats minus active guests; a booking that fits is created; a booking over the seats left is rejected with the exact seats-left count; a booking on a tasting with zero seats left is rejected as fully booked; verify they fail
- [x] 3.2 Write failing tests for cancellation and references: cancelling frees seats; cancelling an unknown or already-cancelled reference reports not found; references are 8 characters from the unambiguous alphabet, unique across 1,000 bookings, and not reused after cancellation; verify they fail
- [x] 3.3 Implement the in-memory store behind a small interface (create, get, list by tasting, cancel, seats left), with the capacity check and insert done in one synchronous step, and the reference generator using `crypto.randomInt`; verify 3.1 and 3.2 are green
- [x] 3.4 Write and run a test that fires 50 simultaneous booking calls for 3 seats left and asserts exactly 3 seats are taken; verify it passes

## 4. Staff session and sign-in limit

- [x] 4.1 Write failing tests for the staff session: correct password returns a session cookie that is HttpOnly and SameSite=Strict; wrong password returns 401 with "Incorrect password."; unset or empty `STAFF_PASSWORD` returns 503 with "Staff sign-in is not configured."; unsigned bookings request returns 401; sign-out invalidates the cookie; verify they fail
- [x] 4.2 Write failing tests for the sign-in limit: 10 failed attempts are allowed, the 11th (even with the correct password) returns 429 with "Too many attempts. Try again later."; successful sign-ins do not consume the limit; verify they fail
- [x] 4.3 Implement the staff session module (timing-safe password comparison, random token map, cookie helpers) and the sign-in rate limiter with `express-rate-limit` configured for failed attempts only; verify 4.1 and 4.2 are green

## 5. HTTP API and server entry

- [x] 5.1 Write failing supertest tests for the guest endpoints: `GET /api/tastings` and `GET /api/tastings/:id` return seats left; `POST /api/tastings/:id/bookings` returns 201 with reference, title, guests and total; field errors return 400 with `{ errors }`; over-capacity returns 409 with the guests message; fully booked returns 409 with the form-level message; unknown tasting returns 404; `GET /api/bookings/:reference` returns the confirmation details without name or email, or 404; verify they fail
- [x] 5.2 Write failing supertest tests for the staff endpoints: `GET /api/staff/bookings` returns groups in tasting order with name, email, guests and reference, and a tasting with no bookings has an empty list; `DELETE /api/staff/bookings/:reference` returns 204 and frees seats, or 404 when gone; verify they fail
- [x] 5.3 Implement the Express app factory (`createApp` taking the store and staff password), the routes, JSON body parsing and cookie parsing, and make 5.1 and 5.2 green
- [x] 5.4 Write a failing test that the server entry reads `PORT` (default 3000), serves `dist/client` for page routes with `index.html` fallback, and does not serve the fallback for unknown `/api` paths; implement the entry (`server/index.ts`) and make it green

## 6. Client foundation

- [x] 6.1 Write failing component tests for the layout and routes: the header shows "Weingut Kieselbrunnen"; `/` renders the catalogue; `/staff` renders; an unknown path renders the not-found page; verify they fail
- [x] 6.2 Implement the React entry, router, layout, Tailwind theme (wine, cream, slate tokens and a serif heading stack), and shared API client helpers; make 6.1 green

## 7. Guest pages

- [x] 7.1 Write failing component tests for the catalogue page: each tasting shows title, date and time, "EUR <n>" price and "<n> seats left"; a fully booked tasting shows "0 seats left", a "Fully booked" label and no "Book <title>" action; verify they fail
- [x] 7.2 Implement the catalogue page to pass 7.1; verify green
- [x] 7.3 Write failing component tests for the booking form: labelled Name, Email and Guests fields and a Book button; each invalid input shows its message next to its own field with `aria-invalid`; server 409 shows the seats-left message next to Guests; a 409 fully-booked message shows at form level; values stay after an error; a server failure shows "Something went wrong. Your booking was not saved. Please try again."; verify they fail
- [x] 7.4 Implement the booking form using React Hook Form with the shared Zod resolver to pass 7.3; verify green
- [x] 7.5 Write failing component tests for the confirmation page: heading "Booking confirmed", tasting title, "<n> guests", "EUR <total>" and the reference; unknown reference shows "Booking not found"; verify they fail
- [x] 7.6 Implement the confirmation page and the unknown-tasting "Tasting not found" page to pass 7.5; verify green

## 8. Staff page

- [x] 8.1 Write failing component tests for staff sign-in: the form shows "Password" and "Sign in" when not signed in; a wrong password shows "Incorrect password." without showing bookings; the not-configured and too-many-attempts messages are shown; verify they fail
- [x] 8.2 Implement the staff sign-in form and session check (a 401 from the bookings list shows the form) to pass 8.1; verify green
- [x] 8.3 Write failing component tests for the staff list: bookings grouped by tasting with name, email, guests and reference; "No bookings yet." for an empty tasting; "Cancel" removes the row without a reload; a 404 on cancel shows "This booking no longer exists."; "Sign out" returns to the form; verify they fail
- [x] 8.4 Implement the staff booking list and cancel and sign-out actions to pass 8.3; verify green

## 9. Build, run and documentation

- [x] 9.1 Write a README section covering install, build, start, dev, test and the `STAFF_PASSWORD` and `PORT` variables, and the in-memory limitation; verify each command in it runs as written in a clean shell
- [x] 9.2 Verify `npm run build` produces `dist/server/index.js` and `dist/client/index.html` with no type or build errors; verify `npm start` serves `/` and `/api/tastings` on `PORT`

## 10. End-to-end verification

- [x] 10.1 Add Playwright end-to-end tests for the full flow: book Riesling Evening for 3 guests, see the confirmation with total "EUR 75", see "9 seats left" on the start page, sign in to staff, see the booking under Riesling Evening, cancel it, and see "12 seats left" again; verify they pass against the built app
- [x] 10.2 Verify the run in a browser at 390 px and 1280 px widths: capture screenshots of the catalogue, a validation error, a fully booked tasting, the confirmation and the staff list, and confirm no horizontal overflow on the phone width
