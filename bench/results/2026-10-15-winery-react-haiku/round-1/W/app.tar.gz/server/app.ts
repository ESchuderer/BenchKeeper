import cookieParser from 'cookie-parser';
import { join } from 'node:path';
import express, { type Express, type NextFunction, type Request, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import { seatsLeftText, totalEur } from '../shared/format.js';
import { bookingInputSchema, staffPasswordSchema } from '../shared/validation.js';
import { type Booking, BookingStore } from './store.js';
import { SESSION_COOKIE, StaffSessions } from './staff.js';

export interface AppOptions {
  store: BookingStore;
  staffPassword: string | undefined;
  /** Directory of the built client. When set, pages are served from it. */
  clientDir?: string;
}

type FieldErrors = Record<string, string>;

// First message per field, so the form can show each one next to its field.
function fieldErrors(issues: { path: PropertyKey[]; message: string }[]): FieldErrors {
  const errors: FieldErrors = {};
  for (const issue of issues) {
    const field = String(issue.path[0]);
    errors[field] ??= issue.message;
  }
  return errors;
}

function confirmationView(booking: Booking, store: BookingStore) {
  const tasting = store.findTasting(booking.tastingId);
  if (!tasting) throw new Error(`Unknown tasting: ${booking.tastingId}`);
  return {
    reference: booking.reference,
    tasting: { id: tasting.id, title: tasting.title, date: tasting.date, time: tasting.time },
    guests: booking.guests,
    priceEur: tasting.priceEur,
    totalEur: totalEur(tasting.priceEur, booking.guests),
  };
}

export function createApp({ store, staffPassword, clientDir }: AppOptions): Express {
  const app = express();
  const sessions = new StaffSessions(staffPassword);

  app.disable('x-powered-by');
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  // Only failed attempts count, so a correct password never locks anyone out
  // on its own. The 10 failures allowed are per client address per window.
  const signInLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 10,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => {
      res.status(429).json({ error: 'Too many attempts. Try again later.' });
    },
  });

  function requireStaff(req: Request, res: Response, next: NextFunction) {
    if (!sessions.isValid(req.cookies?.[SESSION_COOKIE])) {
      res.status(401).json({ error: 'Sign in to see bookings.' });
      return;
    }
    next();
  }

  app.get('/api/tastings', (_req, res) => {
    res.json(store.listTastings());
  });

  app.get('/api/tastings/:tastingId', (req, res) => {
    const tasting = store.findTasting(req.params.tastingId);
    if (!tasting) {
      res.status(404).json({ error: 'Tasting not found' });
      return;
    }
    res.json({ ...tasting, seatsLeft: store.seatsLeft(tasting.id) });
  });

  app.post('/api/tastings/:tastingId/bookings', (req, res) => {
    const tastingId = req.params.tastingId;
    if (!store.findTasting(tastingId)) {
      res.status(404).json({ error: 'Tasting not found' });
      return;
    }

    const parsed = bookingInputSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error.issues) });
      return;
    }

    const result = store.createBooking({ tastingId, ...parsed.data });
    if (!result.ok) {
      switch (result.reason) {
        case 'unknown-tasting':
          res.status(404).json({ error: 'Tasting not found' });
          break;
        case 'fully-booked':
          res.status(409).json({ error: 'This tasting is fully booked.' });
          break;
        case 'insufficient-seats':
          res.status(409).json({
            errors: { guests: `Only ${seatsLeftText(result.seatsLeft)} for this tasting.` },
          });
          break;
      }
      return;
    }
    res.status(201).json(confirmationView(result.booking, store));
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const booking = store.getBooking(req.params.reference);
    if (!booking) {
      res.status(404).json({ error: 'Booking not found' });
      return;
    }
    res.json(confirmationView(booking, store));
  });

  app.post('/api/staff/session', signInLimiter, (req, res) => {
    const parsed = staffPasswordSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ errors: { password: parsed.error.issues[0].message } });
      return;
    }
    if (!sessions.configured) {
      res.status(503).json({ error: 'Staff sign-in is not configured.' });
      return;
    }
    if (!sessions.verifyPassword(parsed.data.password)) {
      res.status(401).json({ errors: { password: 'Incorrect password.' } });
      return;
    }
    res.cookie(SESSION_COOKIE, sessions.open(), {
      httpOnly: true,
      sameSite: 'strict',
      path: '/',
    });
    res.status(204).end();
  });

  app.delete('/api/staff/session', (req, res) => {
    const token = req.cookies?.[SESSION_COOKIE];
    sessions.close(token);
    res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: 'strict', path: '/' });
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    res.json({
      groups: store.bookingsByTasting().map(({ tasting, bookings }) => ({
        tasting: { ...tasting, seatsLeft: store.seatsLeft(tasting.id) },
        bookings: bookings.map(({ reference, name, email, guests }) => ({
          reference,
          name,
          email,
          guests,
        })),
      })),
    });
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req: Request<{ reference: string }>, res) => {
    if (!store.cancelBooking(req.params.reference)) {
      res.status(404).json({ error: 'This booking no longer exists.' });
      return;
    }
    res.status(204).end();
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found' });
  });

  if (clientDir) {
    app.use(express.static(clientDir));
    // Page routes such as /tastings/:id/book are handled by the client router.
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(join(clientDir, 'index.html'));
    });
  }

  // Errors are answered in JSON, never with Express's HTML error page.
  app.use((err: unknown, _req: Request, res: Response, next: NextFunction) => {
    if (res.headersSent) {
      next(err);
      return;
    }
    if ((err as { type?: string }).type === 'entity.parse.failed') {
      res.status(400).json({ error: 'The request body is not valid JSON.' });
      return;
    }
    console.error(err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  });

  return app;
}
