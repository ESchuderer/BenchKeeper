import { describe, expect, it } from 'vitest';
import { readConfig } from './config.js';

describe('readConfig', () => {
  it('defaults the port to 3000 and leaves staff sign-in unconfigured', () => {
    const config = readConfig({});
    expect(config.port).toBe(3000);
    expect(config.staffPassword).toBeUndefined();
  });

  it('reads PORT and STAFF_PASSWORD from the environment', () => {
    const config = readConfig({ PORT: '8080', STAFF_PASSWORD: 'vintage-2026' });
    expect(config.port).toBe(8080);
    expect(config.staffPassword).toBe('vintage-2026');
  });

  it('treats an empty STAFF_PASSWORD as unconfigured', () => {
    expect(readConfig({ STAFF_PASSWORD: '' }).staffPassword).toBeUndefined();
  });

  it.each(['abc', '0', '70000', '3000.5'])('rejects PORT=%s', (port) => {
    expect(() => readConfig({ PORT: port })).toThrow(/PORT/);
  });
});
