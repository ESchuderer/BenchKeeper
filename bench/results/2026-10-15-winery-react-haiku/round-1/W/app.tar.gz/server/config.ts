import { fileURLToPath } from 'node:url';

export interface Config {
  port: number;
  /** Undefined when STAFF_PASSWORD is unset or empty, which disables staff sign-in. */
  staffPassword: string | undefined;
  /** The built React app, served from dist/client next to dist/server. */
  clientDir: string;
}

export function readConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const rawPort = env.PORT || '3000';
  const port = Number(rawPort);
  if (!/^\d+$/.test(rawPort) || port < 1 || port > 65535) {
    throw new Error(`PORT must be a whole number from 1 to 65535, got "${rawPort}"`);
  }
  return {
    port,
    staffPassword: env.STAFF_PASSWORD || undefined,
    clientDir: fileURLToPath(new URL('../client', import.meta.url)),
  };
}
