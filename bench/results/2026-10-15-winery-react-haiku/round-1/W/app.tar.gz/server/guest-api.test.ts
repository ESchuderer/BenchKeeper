import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { TASTINGS } from '../shared/catalog.js';
import { createApp } from './app.js';
import { BookingStore } from './store.js';

function setup() {
  const store = new BookingStore(TASTINGS);
  return { store, app: createApp({ store, staffPassword: 'pw' }) };
}

const booking = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

describe('GET /api/tastings', () => {
  it('lists the tastings with seats left', async () => {
    const { app, store } = setup();
    store.createBooking({ tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 4 });

    const res = await request(app).get('/api/tastings');

    expect(res.status).toBe(200);
    expect(res.body.map((t: { id: string }) => t.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(res.body[2]).toMatchObject({
      title: 'Winter Tasting',
      date: '2026-12-05',
      time: '17:00',
      priceEur: 28,
      seats: 10,
      seatsLeft: 6,
    });
  });
});

describe('GET /api/tastings/:id', () => {
  it('returns one tasting with seats left', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/tastings/red-wine-cellar-tour');

    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ id: 'red-wine-cellar-tour', seatsLeft: 8 });
  });

  it('returns 404 for a tasting that is not offered', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/tastings/no-such');

    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: 'Tasting not found' });
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates the booking and returns the confirmation with the total price', async () => {
    const { app, store } = setup();
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send(booking);

    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({
      tasting: { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour' },
      guests: 2,
      totalEur: 64,
    });
    expect(res.body.reference).toMatch(/^[2-9A-HJ-KM-NP-Z]{4}-[2-9A-HJ-KM-NP-Z]{4}$/);
    expect(store.seatsLeft('red-wine-cellar-tour')).toBe(6);
  });

  it('does not return the guest name or email in the confirmation', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/tastings/winter-tasting/bookings').send(booking);

    expect(res.body).not.toHaveProperty('name');
    expect(res.body).not.toHaveProperty('email');
  });

  it('accepts guests sent as a string and stores the trimmed name', async () => {
    const { app, store } = setup();
    const res = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ name: '  Ben  ', email: 'ben@example.com', guests: '3' });

    expect(res.status).toBe(201);
    expect(res.body.guests).toBe(3);
    const stored = store.bookingsByTasting()[2].bookings[0];
    expect(stored.name).toBe('Ben');
  });

  it('returns 400 with one message per invalid field', async () => {
    const { app, store } = setup();
    const res = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ name: '', email: 'anna@example', guests: 9 });

    expect(res.status).toBe(400);
    expect(res.body).toEqual({
      errors: {
        name: 'Enter your name',
        email: 'Enter a valid email address',
        guests: 'Choose between 1 and 8 guests',
      },
    });
    expect(store.seatsLeft('winter-tasting')).toBe(10);
  });

  it('returns 400 when the body is missing entirely', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/tastings/winter-tasting/bookings');
    expect(res.status).toBe(400);
    expect(res.body.errors).toHaveProperty('name');
  });

  it('returns 409 naming the seats left when the guests exceed them', async () => {
    const { app, store } = setup();
    store.createBooking({ tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 8 });

    const res = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .send({ ...booking, guests: 4 });

    expect(res.status).toBe(409);
    expect(res.body).toEqual({ errors: { guests: 'Only 2 seats left for this tasting.' } });
    expect(store.seatsLeft('winter-tasting')).toBe(2);
  });

  it('returns 409 with a form-level message when the tasting is fully booked', async () => {
    const { app, store } = setup();
    store.createBooking({ tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 10 });

    const res = await request(app).post('/api/tastings/winter-tasting/bookings').send(booking);

    expect(res.status).toBe(409);
    expect(res.body).toEqual({ error: 'This tasting is fully booked.' });
  });

  it('returns 404 for a tasting that is not offered', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/tastings/no-such/bookings').send(booking);
    expect(res.status).toBe(404);
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the confirmation for an existing booking', async () => {
    const { app } = setup();
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send(booking);

    const res = await request(app).get(`/api/bookings/${created.body.reference}`);

    expect(res.status).toBe(200);
    expect(res.body).toEqual(created.body);
  });

  it('returns 404 for a reference that does not exist', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/bookings/ZZZZ-ZZZZ');
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: 'Booking not found' });
  });

  it('returns 404 once the booking has been cancelled', async () => {
    const { app, store } = setup();
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send(booking);
    store.cancelBooking(created.body.reference);

    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(404);
  });
});

describe('unknown API paths', () => {
  it('answers 404 with JSON rather than a page', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/nothing-here');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
});

describe('malformed request bodies', () => {
  it('answers a body that is not valid JSON with a JSON 400', async () => {
    const { app } = setup();
    const res = await request(app)
      .post('/api/tastings/winter-tasting/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ');

    expect(res.status).toBe(400);
    expect(res.headers['content-type']).toMatch(/json/);
    expect(res.body).toEqual({ error: 'The request body is not valid JSON.' });
  });
});
