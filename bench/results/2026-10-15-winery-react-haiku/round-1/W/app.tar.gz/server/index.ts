import { TASTINGS } from '../shared/catalog.js';
import { createApp } from './app.js';
import { readConfig } from './config.js';
import { BookingStore } from './store.js';

const config = readConfig();

if (config.staffPassword === undefined) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

const app = createApp({
  store: new BookingStore(TASTINGS),
  staffPassword: config.staffPassword,
  clientDir: config.clientDir,
});

app.listen(config.port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${config.port}`);
});
