import { describe, expect, it } from 'vitest';
import { generateReference } from './reference.js';

describe('generateReference', () => {
  it('gives 8 characters in two groups of four, from the unambiguous alphabet', () => {
    // No 0, O, 1, I or L, so references read clearly over the phone.
    for (let i = 0; i < 200; i++) {
      expect(generateReference()).toMatch(/^[2-9A-HJ-KM-NP-Z]{4}-[2-9A-HJ-KM-NP-Z]{4}$/);
    }
  });
});
