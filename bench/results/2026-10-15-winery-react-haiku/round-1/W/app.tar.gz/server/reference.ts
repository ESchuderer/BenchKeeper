import { randomInt } from 'node:crypto';

// Without 0, O, 1, I and L, so a reference can be read out over the phone.
const ALPHABET = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
const LENGTH = 8;

/** A booking reference such as "K7QF-M3HX". */
export function generateReference(): string {
  let chars = '';
  for (let i = 0; i < LENGTH; i++) {
    chars += ALPHABET[randomInt(ALPHABET.length)];
  }
  return `${chars.slice(0, 4)}-${chars.slice(4)}`;
}
