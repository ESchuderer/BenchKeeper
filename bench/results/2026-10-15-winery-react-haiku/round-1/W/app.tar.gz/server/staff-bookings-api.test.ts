import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { TASTINGS } from '../shared/catalog.js';
import { createApp } from './app.js';
import { BookingStore } from './store.js';

async function setup() {
  const store = new BookingStore(TASTINGS);
  const app = createApp({ store, staffPassword: 'pw' });
  const signIn = await request(app).post('/api/staff/session').send({ password: 'pw' });
  const cookie = (signIn.headers['set-cookie'][0] as string).split(';')[0];
  return { store, app, cookie };
}

describe('GET /api/staff/bookings', () => {
  it('groups bookings by tasting in catalogue order, with name, email, guests and reference', async () => {
    const { app, store, cookie } = await setup();
    store.createBooking({ tastingId: 'winter-tasting', name: 'Ben', email: 'ben@example.com', guests: 2 });
    store.createBooking({ tastingId: 'riesling-evening', name: 'Anna', email: 'anna@example.com', guests: 3 });

    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie);

    expect(res.status).toBe(200);
    expect(res.body.groups.map((g: { tasting: { id: string } }) => g.tasting.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(res.body.groups[0].bookings).toEqual([
      {
        reference: expect.stringMatching(/^[2-9A-HJ-KM-NP-Z]{4}-[2-9A-HJ-KM-NP-Z]{4}$/),
        name: 'Anna',
        email: 'anna@example.com',
        guests: 3,
      },
    ]);
  });

  it('gives a tasting with no bookings an empty list, and shows its seats left', async () => {
    const { app, cookie, store } = await setup();
    store.createBooking({ tastingId: 'winter-tasting', name: 'Ben', email: 'ben@example.com', guests: 4 });

    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie);

    expect(res.body.groups[1]).toMatchObject({
      tasting: { id: 'red-wine-cellar-tour', seatsLeft: 8 },
      bookings: [],
    });
    expect(res.body.groups[2].tasting).toMatchObject({ id: 'winter-tasting', seatsLeft: 6 });
  });
});

describe('DELETE /api/staff/bookings/:reference', () => {
  it('cancels the booking, frees its seats and removes it from the list', async () => {
    const { app, store, cookie } = await setup();
    const created = store.createBooking({
      tastingId: 'winter-tasting',
      name: 'Ben',
      email: 'ben@example.com',
      guests: 4,
    });
    if (!created.ok) throw new Error('setup booking failed');

    const res = await request(app)
      .delete(`/api/staff/bookings/${created.booking.reference}`)
      .set('Cookie', cookie);

    expect(res.status).toBe(204);
    expect(store.seatsLeft('winter-tasting')).toBe(10);
    const list = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(list.body.groups[2].bookings).toEqual([]);
  });

  it('answers 404 with the message when the booking is already gone', async () => {
    const { app, cookie } = await setup();
    const res = await request(app).delete('/api/staff/bookings/ZZZZ-ZZZZ').set('Cookie', cookie);

    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: 'This booking no longer exists.' });
  });

  it('refuses cancellation without a staff session', async () => {
    const { app, store } = await setup();
    const created = store.createBooking({
      tastingId: 'winter-tasting',
      name: 'Ben',
      email: 'ben@example.com',
      guests: 4,
    });
    if (!created.ok) throw new Error('setup booking failed');

    const res = await request(app).delete(`/api/staff/bookings/${created.booking.reference}`);

    expect(res.status).toBe(401);
    expect(store.seatsLeft('winter-tasting')).toBe(6);
  });
});
