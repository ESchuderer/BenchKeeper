import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { TASTINGS } from '../shared/catalog.js';
import { createApp } from './app.js';
import { BookingStore } from './store.js';

const PASSWORD = 'vintage-2026';

function setup(staffPassword: string | undefined = PASSWORD) {
  return createApp({ store: new BookingStore(TASTINGS), staffPassword });
}

async function signIn(app: ReturnType<typeof setup>) {
  const res = await request(app).post('/api/staff/session').send({ password: PASSWORD });
  const cookie = res.headers['set-cookie']?.[0] ?? '';
  return { res, cookie: cookie.split(';')[0] };
}

describe('staff sign-in', () => {
  it('issues an HttpOnly, SameSite=Strict session cookie for the correct password', async () => {
    const app = setup();
    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD });

    expect(res.status).toBe(204);
    const cookie = res.headers['set-cookie']?.[0] ?? '';
    expect(cookie).toMatch(/^staff_session=[^;]+/);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
  });

  it('rejects a wrong password with a message on the password field', async () => {
    const app = setup();
    const res = await request(app).post('/api/staff/session').send({ password: 'nope' });

    expect(res.status).toBe(401);
    expect(res.body).toEqual({ errors: { password: 'Incorrect password.' } });
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('rejects an empty password as a field error', async () => {
    const app = setup();
    const res = await request(app).post('/api/staff/session').send({ password: '' });

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ errors: { password: 'Enter the password' } });
  });

  it.each([undefined, ''])('answers 503 when STAFF_PASSWORD is %j', async (configured) => {
    // Call createApp directly: setup() would fall back to the default password.
    const app = createApp({ store: new BookingStore(TASTINGS), staffPassword: configured });
    const res = await request(app).post('/api/staff/session').send({ password: 'anything' });

    expect(res.status).toBe(503);
    expect(res.body).toEqual({ error: 'Staff sign-in is not configured.' });
  });

  it('lets a signed-in session read the bookings and an unsigned request not', async () => {
    const app = setup();
    const unsigned = await request(app).get('/api/staff/bookings');
    expect(unsigned.status).toBe(401);
    expect(unsigned.body).not.toHaveProperty('groups');

    const { cookie } = await signIn(app);
    const signed = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(signed.status).toBe(200);
    expect(signed.body).toHaveProperty('groups');
  });

  it('treats a forged cookie as unsigned', async () => {
    const app = setup();
    const res = await request(app)
      .get('/api/staff/bookings')
      .set('Cookie', 'staff_session=not-a-real-token');
    expect(res.status).toBe(401);
  });

  it('ends the session on sign-out so the old cookie stops working', async () => {
    const app = setup();
    const { cookie } = await signIn(app);

    const out = await request(app).delete('/api/staff/session').set('Cookie', cookie);
    expect(out.status).toBe(204);

    const after = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(after.status).toBe(401);
  });
});

describe('staff sign-in limit', () => {
  it('allows 10 failed attempts and blocks the 11th, even with the correct password', async () => {
    const app = setup();
    for (let i = 0; i < 10; i++) {
      const res = await request(app).post('/api/staff/session').send({ password: 'wrong' });
      expect(res.status).toBe(401);
    }

    const blocked = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    expect(blocked.status).toBe(429);
    expect(blocked.body).toEqual({ error: 'Too many attempts. Try again later.' });
    expect(blocked.headers['set-cookie']).toBeUndefined();
  });

  it('does not count successful sign-ins towards the limit', async () => {
    const app = setup();
    for (let i = 0; i < 9; i++) {
      await request(app).post('/api/staff/session').send({ password: 'wrong' });
    }
    const ok = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    expect(ok.status).toBe(204);

    const tenth = await request(app).post('/api/staff/session').send({ password: 'wrong' });
    expect(tenth.status).toBe(401);
  });
});
