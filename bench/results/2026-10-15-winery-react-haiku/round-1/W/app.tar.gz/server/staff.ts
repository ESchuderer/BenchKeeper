import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const SESSION_COOKIE = 'staff_session';

/**
 * Staff sessions are random tokens held in memory, so every session ends
 * when the server restarts or the staff member signs out.
 */
export class StaffSessions {
  private readonly tokens = new Set<string>();
  private readonly password: string | undefined;

  constructor(password: string | undefined) {
    this.password = password || undefined;
  }

  get configured(): boolean {
    return this.password !== undefined;
  }

  verifyPassword(candidate: string): boolean {
    if (this.password === undefined) return false;
    // Hash both sides so the comparison runs in constant time whatever the lengths.
    const expected = createHash('sha256').update(this.password).digest();
    const given = createHash('sha256').update(candidate).digest();
    return timingSafeEqual(expected, given);
  }

  open(): string {
    const token = randomBytes(32).toString('base64url');
    this.tokens.add(token);
    return token;
  }

  isValid(token: string | undefined): boolean {
    return token !== undefined && this.tokens.has(token);
  }

  close(token: string | undefined): void {
    if (token !== undefined) this.tokens.delete(token);
  }
}
