import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { beforeAll, describe, expect, it } from 'vitest';
import { TASTINGS } from '../shared/catalog.js';
import { createApp } from './app.js';
import { BookingStore } from './store.js';

let clientDir: string;

beforeAll(() => {
  clientDir = mkdtempSync(join(tmpdir(), 'kieselbrunnen-client-'));
  mkdirSync(join(clientDir, 'assets'));
  writeFileSync(join(clientDir, 'index.html'), '<!doctype html><div id="root"></div>');
  writeFileSync(join(clientDir, 'assets', 'app.js'), 'console.log("app");');
});

function app() {
  return createApp({ store: new BookingStore(TASTINGS), staffPassword: 'pw', clientDir });
}

describe('serving the built client', () => {
  it('serves index.html at the start page', async () => {
    const res = await request(app()).get('/');
    expect(res.status).toBe(200);
    expect(res.text).toContain('<div id="root">');
  });

  it('serves index.html for page routes so the client router can take over', async () => {
    const res = await request(app()).get('/tastings/winter-tasting/book');
    expect(res.status).toBe(200);
    expect(res.text).toContain('<div id="root">');
  });

  it('serves built assets as files', async () => {
    const res = await request(app()).get('/assets/app.js');
    expect(res.status).toBe(200);
    expect(res.text).toContain('console.log("app")');
  });

  it('does not answer unknown API paths with the page', async () => {
    const res = await request(app()).get('/api/nothing-here');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
    expect(res.text).not.toContain('<div id="root">');
  });
});
