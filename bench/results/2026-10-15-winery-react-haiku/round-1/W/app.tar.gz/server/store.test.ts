import { describe, expect, it } from 'vitest';
import { TASTINGS, type Tasting } from '../shared/catalog.js';
import { BookingStore } from './store.js';

const riesling = 'riesling-evening'; // 12 seats
const redWine = 'red-wine-cellar-tour'; // 8 seats

const guest = { name: 'Anna Keller', email: 'anna@example.com' };

describe('BookingStore seats', () => {
  it('starts with every seat of each tasting free', () => {
    const store = new BookingStore(TASTINGS);
    expect(store.seatsLeft(riesling)).toBe(12);
    expect(store.seatsLeft(redWine)).toBe(8);
  });

  it('reduces seats left by the guests of a booking', () => {
    const store = new BookingStore(TASTINGS);
    store.createBooking({ tastingId: riesling, ...guest, guests: 3 });
    expect(store.seatsLeft(riesling)).toBe(9);
  });

  it('accepts a booking that uses exactly the seats left', () => {
    const store = new BookingStore(TASTINGS);
    const result = store.createBooking({ tastingId: redWine, ...guest, guests: 8 });
    expect(result.ok).toBe(true);
    expect(store.seatsLeft(redWine)).toBe(0);
  });

  it('rejects a booking with more guests than seats left and reports the seats left', () => {
    const store = new BookingStore(TASTINGS);
    store.createBooking({ tastingId: riesling, ...guest, guests: 9 });
    const result = store.createBooking({ tastingId: riesling, ...guest, guests: 4 });
    expect(result).toEqual({ ok: false, reason: 'insufficient-seats', seatsLeft: 3 });
    expect(store.seatsLeft(riesling)).toBe(3);
  });

  it('rejects any booking on a fully booked tasting as fully booked', () => {
    const store = new BookingStore(TASTINGS);
    store.createBooking({ tastingId: redWine, ...guest, guests: 8 });
    expect(store.createBooking({ tastingId: redWine, ...guest, guests: 1 })).toEqual({
      ok: false,
      reason: 'fully-booked',
    });
  });

  it('rejects a booking for a tasting that is not offered', () => {
    const store = new BookingStore(TASTINGS);
    expect(store.createBooking({ tastingId: 'no-such', ...guest, guests: 1 })).toEqual({
      ok: false,
      reason: 'unknown-tasting',
    });
  });

  it('returns the booking details when a booking succeeds', () => {
    const store = new BookingStore(TASTINGS);
    const result = store.createBooking({ tastingId: redWine, ...guest, guests: 2 });
    expect(result.ok && result.booking).toMatchObject({
      tastingId: redWine,
      name: 'Anna Keller',
      email: 'anna@example.com',
      guests: 2,
    });
  });
});

describe('BookingStore cancellation and references', () => {
  it('frees the guests seats when a booking is cancelled', () => {
    const store = new BookingStore(TASTINGS);
    const result = store.createBooking({ tastingId: redWine, ...guest, guests: 3 });
    if (!result.ok) throw new Error('setup booking failed');

    expect(store.seatsLeft(redWine)).toBe(5);
    expect(store.cancelBooking(result.booking.reference)).toBe(true);
    expect(store.seatsLeft(redWine)).toBe(8);
  });

  it('reports an unknown or already cancelled reference as not found', () => {
    const store = new BookingStore(TASTINGS);
    const result = store.createBooking({ tastingId: redWine, ...guest, guests: 1 });
    if (!result.ok) throw new Error('setup booking failed');

    expect(store.cancelBooking('ZZZZ-ZZZZ')).toBe(false);
    expect(store.cancelBooking(result.booking.reference)).toBe(true);
    expect(store.cancelBooking(result.booking.reference)).toBe(false);
    expect(store.getBooking(result.booking.reference)).toBeUndefined();
  });

  it('never gives two current bookings the same reference, across 1000 bookings', () => {
    const big: Tasting = { ...TASTINGS[0], id: 'big', seats: 1000 };
    const store = new BookingStore([big]);
    const references = new Set<string>();
    for (let i = 0; i < 1000; i++) {
      const result = store.createBooking({ tastingId: 'big', ...guest, guests: 1 });
      if (!result.ok) throw new Error('setup booking failed');
      references.add(result.booking.reference);
    }
    expect(references.size).toBe(1000);
  });

  it('does not reuse the reference of a cancelled booking', () => {
    const issued = ['AAAA-AAAA', 'AAAA-AAAA', 'BBBB-BBBB'];
    const store = new BookingStore(TASTINGS, { newReference: () => issued.shift()! });

    const first = store.createBooking({ tastingId: redWine, ...guest, guests: 1 });
    if (!first.ok) throw new Error('setup booking failed');
    store.cancelBooking(first.booking.reference);

    const second = store.createBooking({ tastingId: redWine, ...guest, guests: 1 });
    expect(second.ok && second.booking.reference).toBe('BBBB-BBBB');
  });

  it('lists bookings grouped by tasting in catalogue order', () => {
    const store = new BookingStore(TASTINGS);
    store.createBooking({ tastingId: 'winter-tasting', ...guest, guests: 1 });
    store.createBooking({ tastingId: riesling, ...guest, guests: 2 });
    store.createBooking({ tastingId: 'winter-tasting', ...guest, guests: 3 });

    const groups = store.bookingsByTasting();
    expect(groups.map((g) => g.tasting.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(groups.map((g) => g.bookings.length)).toEqual([1, 0, 2]);
  });
});

describe('BookingStore under concurrent requests', () => {
  it('lets exactly 3 of 50 simultaneous bookings for 3 seats left succeed', async () => {
    const store = new BookingStore(TASTINGS);
    store.createBooking({ tastingId: riesling, ...guest, guests: 9 });

    // Each attempt runs in its own microtask, the way overlapping requests would.
    const attempts = Array.from({ length: 50 }, () =>
      Promise.resolve().then(() => store.createBooking({ tastingId: riesling, ...guest, guests: 1 })),
    );
    const results = await Promise.all(attempts);

    expect(results.filter((r) => r.ok)).toHaveLength(3);
    expect(store.seatsLeft(riesling)).toBe(0);
  });
});
