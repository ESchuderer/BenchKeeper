import type { Tasting } from '../shared/catalog.js';
import { generateReference } from './reference.js';

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  createdAt: Date;
}

export interface NewBooking {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export type CreateBookingResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: 'unknown-tasting' }
  | { ok: false; reason: 'fully-booked' }
  | { ok: false; reason: 'insufficient-seats'; seatsLeft: number };

export interface TastingWithSeats extends Tasting {
  seatsLeft: number;
}

export interface TastingBookings {
  tasting: Tasting;
  bookings: Booking[];
}

interface BookingStoreOptions {
  newReference?: () => string;
}

/**
 * Bookings kept in memory. Node runs JavaScript on one thread, and
 * createBooking checks the seats and inserts the booking in one synchronous
 * step, so concurrent requests can never take more seats than a tasting has.
 * This holds for a single process only.
 */
export class BookingStore {
  private readonly tastings: readonly Tasting[];
  private readonly bookings = new Map<string, Booking>();
  // Every reference ever issued, including cancelled ones, is never reused.
  private readonly issuedReferences = new Set<string>();
  private readonly newReference: () => string;

  constructor(tastings: readonly Tasting[], options: BookingStoreOptions = {}) {
    this.tastings = tastings;
    this.newReference = options.newReference ?? generateReference;
  }

  listTastings(): TastingWithSeats[] {
    return this.tastings.map((tasting) => ({ ...tasting, seatsLeft: this.seatsLeft(tasting.id) }));
  }

  findTasting(tastingId: string): Tasting | undefined {
    return this.tastings.find((tasting) => tasting.id === tastingId);
  }

  seatsLeft(tastingId: string): number {
    const tasting = this.requireTasting(tastingId);
    let taken = 0;
    for (const booking of this.bookings.values()) {
      if (booking.tastingId === tastingId) taken += booking.guests;
    }
    return tasting.seats - taken;
  }

  createBooking(input: NewBooking): CreateBookingResult {
    if (!this.findTasting(input.tastingId)) return { ok: false, reason: 'unknown-tasting' };

    const seatsLeft = this.seatsLeft(input.tastingId);
    if (seatsLeft === 0) return { ok: false, reason: 'fully-booked' };
    if (input.guests > seatsLeft) return { ok: false, reason: 'insufficient-seats', seatsLeft };

    const booking: Booking = {
      reference: this.issueReference(),
      tastingId: input.tastingId,
      name: input.name,
      email: input.email,
      guests: input.guests,
      createdAt: new Date(),
    };
    this.bookings.set(booking.reference, booking);
    return { ok: true, booking };
  }

  getBooking(reference: string): Booking | undefined {
    return this.bookings.get(reference);
  }

  /** Removes the booking and frees its seats. Returns false if no such booking exists. */
  cancelBooking(reference: string): boolean {
    return this.bookings.delete(reference);
  }

  bookingsByTasting(): TastingBookings[] {
    return this.tastings.map((tasting) => ({
      tasting,
      bookings: [...this.bookings.values()].filter((b) => b.tastingId === tasting.id),
    }));
  }

  private issueReference(): string {
    let reference = this.newReference();
    while (this.issuedReferences.has(reference)) reference = this.newReference();
    this.issuedReferences.add(reference);
    return reference;
  }

  private requireTasting(tastingId: string): Tasting {
    const tasting = this.findTasting(tastingId);
    if (!tasting) throw new Error(`Unknown tasting: ${tastingId}`);
    return tasting;
  }
}
