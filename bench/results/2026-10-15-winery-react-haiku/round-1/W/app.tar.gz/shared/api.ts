import type { Tasting } from './catalog.js';

// Response shapes shared by the server and the client.

export interface TastingView extends Tasting {
  seatsLeft: number;
}

export interface ConfirmationView {
  reference: string;
  tasting: Pick<Tasting, 'id' | 'title' | 'date' | 'time'>;
  guests: number;
  priceEur: number;
  totalEur: number;
}

export interface StaffBookingView {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffGroupView {
  tasting: TastingView;
  bookings: StaffBookingView[];
}

export interface StaffBookingsView {
  groups: StaffGroupView[];
}
