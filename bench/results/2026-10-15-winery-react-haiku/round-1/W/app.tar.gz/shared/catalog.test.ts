import { describe, expect, it } from 'vitest';
import { TASTINGS, findTasting } from './catalog.js';

describe('tasting catalogue', () => {
  it('offers exactly the three tastings from the spec, in order', () => {
    expect(TASTINGS.map((t) => t.title)).toEqual([
      'Riesling Evening',
      'Red Wine Cellar Tour',
      'Winter Tasting',
    ]);
  });

  it('gives each tasting its fixed date, time, price and seats', () => {
    expect(TASTINGS).toEqual([
      {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        date: '2026-11-06',
        time: '18:00',
        priceEur: 25,
        seats: 12,
      },
      {
        id: 'red-wine-cellar-tour',
        title: 'Red Wine Cellar Tour',
        date: '2026-11-14',
        time: '15:00',
        priceEur: 32,
        seats: 8,
      },
      {
        id: 'winter-tasting',
        title: 'Winter Tasting',
        date: '2026-12-05',
        time: '17:00',
        priceEur: 28,
        seats: 10,
      },
    ]);
  });

  it('finds a tasting by its id and returns undefined for unknown ids', () => {
    expect(findTasting('winter-tasting')?.title).toBe('Winter Tasting');
    expect(findTasting('no-such-tasting')).toBeUndefined();
  });
});
