export interface Tasting {
  id: string;
  title: string;
  /** Winery local date, YYYY-MM-DD. No time zone is applied. */
  date: string;
  /** Winery local time, HH:MM. */
  time: string;
  /** Price per guest in whole euros. */
  priceEur: number;
  seats: number;
}

export const TASTINGS: readonly Tasting[] = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    date: '2026-11-06',
    time: '18:00',
    priceEur: 25,
    seats: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    date: '2026-11-14',
    time: '15:00',
    priceEur: 32,
    seats: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    date: '2026-12-05',
    time: '17:00',
    priceEur: 28,
    seats: 10,
  },
];

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((tasting) => tasting.id === id);
}
