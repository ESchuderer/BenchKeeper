import { describe, expect, it } from 'vitest';
import { formatEur, formatTastingDate, guestsText, seatsLeftText, totalEur } from './format.js';

describe('formatTastingDate', () => {
  it('formats the date without shifting it into another time zone', () => {
    // 6 November 2026 is a Friday.
    expect(formatTastingDate('2026-11-06')).toBe('Friday, 6 November 2026');
  });

  it('formats a December date', () => {
    // 5 December 2026 is a Saturday.
    expect(formatTastingDate('2026-12-05')).toBe('Saturday, 5 December 2026');
  });
});

describe('formatEur', () => {
  it('shows the price as EUR followed by whole euros', () => {
    expect(formatEur(25)).toBe('EUR 25');
  });
});

describe('totalEur', () => {
  it('multiplies the price per guest by the number of guests', () => {
    expect(totalEur(25, 3)).toBe(75);
    expect(totalEur(32, 2)).toBe(64);
  });
});

describe('seatsLeftText', () => {
  it('reads naturally for zero, one and many seats', () => {
    expect(seatsLeftText(0)).toBe('0 seats left');
    expect(seatsLeftText(1)).toBe('1 seat left');
    expect(seatsLeftText(3)).toBe('3 seats left');
  });
});

describe('guestsText', () => {
  it('reads naturally for one and many guests', () => {
    expect(guestsText(1)).toBe('1 guest');
    expect(guestsText(2)).toBe('2 guests');
  });
});
