const WEEKDAYS = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

/**
 * Formats a YYYY-MM-DD date such as "Friday, 6 November 2026".
 * The date is read as calendar parts, so no time zone can shift it.
 */
export function formatTastingDate(isoDate: string): string {
  const [year, month, day] = isoDate.split('-').map(Number);
  const weekday = WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()];
  return `${weekday}, ${day} ${MONTHS[month - 1]} ${year}`;
}

export function formatEur(euros: number): string {
  return `EUR ${euros}`;
}

export function totalEur(pricePerGuest: number, guests: number): number {
  return pricePerGuest * guests;
}

export function seatsLeftText(seats: number): string {
  return seats === 1 ? '1 seat left' : `${seats} seats left`;
}

export function guestsText(guests: number): string {
  return guests === 1 ? '1 guest' : `${guests} guests`;
}
