import { describe, expect, it } from 'vitest';
import { bookingInputSchema, staffPasswordSchema } from './validation.js';

// The first error message the schema reports for a given field, or undefined.
function messageFor(input: unknown, field: string): string | undefined {
  const result = bookingInputSchema.safeParse(input);
  if (result.success) return undefined;
  return result.error.issues.find((issue) => issue.path[0] === field)?.message;
}

const valid = { name: 'Anna Keller', email: 'anna@example.com', guests: 2 };

describe('bookingInputSchema', () => {
  it('accepts valid input', () => {
    expect(bookingInputSchema.safeParse(valid).success).toBe(true);
  });

  it('accepts guests sent as text, as a form field delivers them', () => {
    const result = bookingInputSchema.safeParse({ ...valid, guests: '3' });
    expect(result.success).toBe(true);
    expect(result.success && result.data.guests).toBe(3);
  });

  describe('name', () => {
    it('rejects a blank name', () => {
      expect(messageFor({ ...valid, name: '' }, 'name')).toBe('Enter your name');
    });

    it('rejects a name that is only whitespace', () => {
      expect(messageFor({ ...valid, name: '   ' }, 'name')).toBe('Enter your name');
    });

    it('accepts a name of exactly 100 characters', () => {
      expect(messageFor({ ...valid, name: 'a'.repeat(100) }, 'name')).toBeUndefined();
    });

    it('rejects a name of 101 characters', () => {
      expect(messageFor({ ...valid, name: 'a'.repeat(101) }, 'name')).toBe(
        'Name must be 100 characters or fewer.',
      );
    });
  });

  describe('email', () => {
    it('rejects an address without a domain', () => {
      expect(messageFor({ ...valid, email: 'anna@example' }, 'email')).toBe(
        'Enter a valid email address',
      );
    });

    it('rejects a blank address', () => {
      expect(messageFor({ ...valid, email: '' }, 'email')).toBe('Enter a valid email address');
    });

    it('accepts an address of exactly 254 characters', () => {
      const email = `${'a'.repeat(242)}@example.com`;
      expect(email).toHaveLength(254);
      expect(messageFor({ ...valid, email }, 'email')).toBeUndefined();
    });

    it('rejects an address of 255 characters', () => {
      const email = `${'a'.repeat(243)}@example.com`;
      expect(email).toHaveLength(255);
      expect(messageFor({ ...valid, email }, 'email')).toBe(
        'Email must be 254 characters or fewer.',
      );
    });
  });

  describe('guests', () => {
    it.each([0, 9, 1.5, -1])('rejects %s', (guests) => {
      expect(messageFor({ ...valid, guests }, 'guests')).toBe('Choose between 1 and 8 guests');
    });

    it.each(['', 'abc', '2.5'])('rejects the text %j', (guests) => {
      expect(messageFor({ ...valid, guests }, 'guests')).toBe('Choose between 1 and 8 guests');
    });

    it.each([true, false, null, [2]])('rejects the non-number %j', (guests) => {
      expect(messageFor({ ...valid, guests }, 'guests')).toBe('Choose between 1 and 8 guests');
    });

    it.each([1, 8])('accepts %s', (guests) => {
      expect(messageFor({ ...valid, guests }, 'guests')).toBeUndefined();
    });
  });
});

describe('staffPasswordSchema', () => {
  it('accepts any non-empty password', () => {
    expect(staffPasswordSchema.safeParse({ password: 'secret' }).success).toBe(true);
  });

  it('rejects an empty password with a message', () => {
    const result = staffPasswordSchema.safeParse({ password: '' });
    expect(result.success).toBe(false);
    expect(!result.success && result.error.issues[0].message).toBe('Enter the password');
  });
});
