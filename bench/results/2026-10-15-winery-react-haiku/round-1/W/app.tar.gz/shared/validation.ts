import { z } from 'zod';

export const GUEST_LIMITS = { min: 1, max: 8 } as const;

const GUESTS_MESSAGE = `Choose between ${GUEST_LIMITS.min} and ${GUEST_LIMITS.max} guests`;

// Shared by the form (instant feedback) and the server (authoritative check).
export const bookingInputSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1, 'Enter your name')
    .max(100, 'Name must be 100 characters or fewer.'),
  email: z
    .string()
    .trim()
    .max(254, 'Email must be 254 characters or fewer.')
    .pipe(z.email('Enter a valid email address')),
  // Form fields send text, so convert text only; other types must already be numbers.
  guests: z.preprocess(
    (value) => (typeof value === 'string' && value.trim() !== '' ? Number(value) : value),
    z
      .number({ error: GUESTS_MESSAGE })
      .int(GUESTS_MESSAGE)
      .min(GUEST_LIMITS.min, GUESTS_MESSAGE)
      .max(GUEST_LIMITS.max, GUESTS_MESSAGE),
  ),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;
/** What a form holds before parsing: guests may still be text. */
export type BookingFormInput = z.input<typeof bookingInputSchema>;

export const staffPasswordSchema = z.object({
  password: z.string().min(1, 'Enter the password'),
});

export type StaffPasswordInput = z.infer<typeof staffPasswordSchema>;
