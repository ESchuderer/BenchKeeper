# Scaffold app and list tastings

Status: resolved
Blocked by: none

## Goal
Runnable app: `npm install`, `npm run build`, `npm start` serves the start page on `PORT`.

## Acceptance
- `GET /api/tastings` returns the three tastings with `seatsLeft`.
- `/` lists tastings with title, date and time, "EUR <price>", "<n> seats left", and "Book <title>" link; fully booked shows "Fully booked".
- Tests: API returns seats left from store; list renders titles and seat text.
