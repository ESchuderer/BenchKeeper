# Book a tasting and see confirmation

Status: resolved
Blocked by: 01

## Goal
Guests book a tasting and see a confirmation that survives reload.

## Acceptance
- `/tastings/:id/book` form: Name, Email, Guests (1 to 8), button "Book"; field errors next to each field.
- `POST /api/tastings/:id/bookings` validates with zod, rejects guests greater than seats left (field error on `guests`), returns the booking.
- `GET /api/bookings/:reference` returns tasting, guests, total, reference only.
- `/bookings/:reference` shows "Booking confirmed", tasting, guests, "EUR <total>", reference.
- Tests: validation errors per field; seats decrease; overbooking rejected; confirmation shows total.
