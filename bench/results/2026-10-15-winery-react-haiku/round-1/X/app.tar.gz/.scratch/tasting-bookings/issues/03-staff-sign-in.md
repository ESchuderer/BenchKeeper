# Staff sign-in

Status: resolved
Blocked by: 01

## Goal
`/staff` requires `STAFF_PASSWORD` to sign in, with the session and rate-limit rules in spec.md.

## Acceptance
- `POST /api/staff/session` checks the password with a constant-time compare; sets `staff_session` (HttpOnly, SameSite=Strict, Secure on HTTPS).
- Session expires 8 hours after sign-in; `POST /api/staff/sign-out` ends it and clears the cookie.
- 6th failed attempt in 15 minutes per IP returns 429; successful sign-ins do not count.
- Unset or empty `STAFF_PASSWORD`: sign-in always fails; warning logged at startup.
- `/staff` shows the password form when signed out, and "Sign out" when signed in.
- Tests: wrong password, correct password, cookie flags, expiry, sign-out, 429 after 5 failures.
