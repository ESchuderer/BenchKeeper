# Staff view and cancel bookings

Status: resolved
Blocked by: 02, 03

## Goal
Signed-in staff see bookings grouped by tasting and cancel them.

## Acceptance
- `GET /api/staff/bookings` (requires session) returns tastings with their bookings.
- `DELETE /api/staff/bookings/:reference` (requires session) removes the booking and frees its seats; unknown reference returns 404.
- `/staff` lists per tasting: name, email, guests, reference, "Cancel" button.
- Tests: unauthenticated access returns 401; cancel frees seats; list grouping.
