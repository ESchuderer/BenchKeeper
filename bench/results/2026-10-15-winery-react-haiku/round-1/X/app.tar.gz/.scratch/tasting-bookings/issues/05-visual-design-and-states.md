# Visual design, states and browser verification

Status: resolved
Blocked by: 02, 03, 04

## Goal
Winery look, clear error, success, and fully booked states, usable at 375px.

## Acceptance
- Shared layout with winery name header, warm palette, tokens in Tailwind theme.
- Error, success, fully booked, and not-found states styled and labelled.
- Playwright MCP run against `npm start`: book flow, fully booked tasting, staff sign-in, cancel, at 375px and desktop widths. Results recorded in the final report.
