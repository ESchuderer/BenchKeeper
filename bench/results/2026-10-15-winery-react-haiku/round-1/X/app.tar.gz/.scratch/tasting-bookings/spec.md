# Tasting bookings for Weingut Kieselbrunnen

Status: accepted (spec written by the agent from the request; decisions below are the defaults taken where the request was silent)

## Goal

Guests book wine tastings online. Staff sign in and see and cancel bookings.

## Tastings (seeded at start, fixed)

| id | Title | Starts (local) | Price per guest | Seats |
|---|---|---|---|---|
| riesling-evening | Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| red-wine-cellar-tour | Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| winter-tasting | Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

Times are winery local time. The app shows the stored date and time text, never converts time zones.

## Guest flow

- `/`: list of tastings. Each shows title, date and time, price per guest ("EUR 25"), seats left ("<n> seats left"), and a link "Book <title>". A fully booked tasting shows "Fully booked" and no booking link.
- `/tastings/:id/book`: form with fields "Name" (required, max 100), "Email" (required, valid email), "Guests" (integer 1 to 8, and not more than seats left), button "Book". Errors appear under the field they concern. Unknown tasting id shows a not-found page.
- Success: the guest is sent to `/bookings/:reference`, which shows heading "Booking confirmed", tasting title, guests, total price (guests x price per guest, "EUR 50"), and the booking reference. The page works after reload. The public lookup returns only tasting, guests, total, and reference (no name or email).
- The booking POST rejects with a field error when the guests value exceeds seats left, and the list shows the current seats left.

## Staff flow

- `/staff` when signed out: heading, "Password" field, "Sign in" button. Wrong password shows an error. No password configured (`STAFF_PASSWORD` unset or empty): sign-in always fails and the server logs a warning at startup.
- Signed in: all bookings grouped by tasting, each row with name, email, guests, reference, and a "Cancel" button. Cancelling removes the booking and frees its seats. A "Sign out" button ends the session.
- Sign-in rules (apply to any sign-in feature):
  - Session expires 8 hours after sign-in (server-side, absolute).
  - Sign-out ends the session on the server and clears the cookie.
  - At most 5 failed sign-in attempts per IP per 15 minutes; further attempts get HTTP 429. Successful sign-ins do not count.
  - Session cookie `staff_session`: `HttpOnly`, `SameSite=Strict`, `Path=/`, `Secure` when the request is HTTPS.
  - Password compared in constant time.

## Storage

- In memory. The app starts with no bookings. Restart clears bookings (accepted by the request: "memory or local file").
- Booking reference: 8 characters from an unambiguous uppercase alphabet, generated with `crypto`, unique.
- Seats check and insert happen in one synchronous step, so concurrent requests cannot overbook.

## Non-goals

- Payment, guest cancellation, email sending, editing bookings, admin management of tastings, i18n (UI is English only).

## Technology

- Server: Express 5 (serves API and built React app on `PORT`, default 3000), zod for input validation, express-rate-limit, cookie-parser.
- Client: React 19, React Router, react-hook-form with @hookform/resolvers/zod, Tailwind CSS 4 via Vite.
- Language: TypeScript. Server compiled with `tsc`, client built with Vite.
- Tests: Vitest, supertest (API), React Testing Library with jsdom (UI). Lint: ESLint flat config with typescript-eslint and react-hooks.

## Commands

- `npm install`
- `npm run build`: Vite client build and server compile.
- `npm start`: `node dist/server/index.js`.
- `npm test`, `npm run lint`, `npm run typecheck`.

## Acceptance

- Every rule above has a test or a browser check recorded in the verify step.
- Looks like a small winery site: warm palette, readable type, clear error (red), success (green), and fully booked (muted) states, usable at 375px width.
