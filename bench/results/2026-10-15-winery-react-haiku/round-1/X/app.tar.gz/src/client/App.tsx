import { Link, Outlet, Route, Routes } from 'react-router';
import BookingForm from './pages/BookingForm';
import Confirmation from './pages/Confirmation';
import Staff from './pages/Staff';
import TastingList from './pages/TastingList';

function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b-4 border-gold bg-wine text-cream">
        <div className="mx-auto flex max-w-5xl items-baseline justify-between gap-4 px-4 py-5">
          <Link to="/" className="font-serif text-2xl tracking-wide">
            Weingut Kieselbrunnen
          </Link>
          <Link to="/staff" className="text-sm text-parchment underline-offset-4 hover:underline">
            Staff
          </Link>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-10">
        <Outlet />
      </main>
      <footer className="border-t border-parchment py-6 text-center text-sm text-stone-600">
        Weingut Kieselbrunnen, family winery
      </footer>
    </div>
  );
}

function NotFound() {
  return (
    <>
      <h1 className="font-serif text-3xl text-wine">Page not found</h1>
      <Link to="/" className="mt-4 inline-block text-wine underline underline-offset-4">
        Back to all tastings
      </Link>
    </>
  );
}

export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingList />} />
        <Route path="tastings/:id/book" element={<BookingForm />} />
        <Route path="bookings/:reference" element={<Confirmation />} />
        <Route path="staff" element={<Staff />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
