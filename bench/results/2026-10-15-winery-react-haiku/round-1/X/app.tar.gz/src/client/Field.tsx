import type { ComponentProps } from 'react';

type FieldProps = ComponentProps<'input'> & { label: string; error?: string };

export function Field({ label, error, id, ...input }: FieldProps) {
  const errorId = `${id}-error`;
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium text-ink">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className="rounded-md border border-stone-300 bg-white px-3 py-2 text-base outline-none focus:border-gold focus:ring-2 focus:ring-gold/40 aria-invalid:border-red-700 aria-invalid:ring-red-700/20"
        {...input}
      />
      {error && (
        <p id={errorId} className="text-sm text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}
