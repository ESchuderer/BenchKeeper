export interface ErrorBody {
  error?: string;
  errors?: Record<string, string>;
}

export interface ApiResult<T> {
  ok: boolean;
  status: number;
  body?: T & ErrorBody;
}

export async function api<T>(url: string, init: RequestInit = {}): Promise<ApiResult<T>> {
  let res: Response;
  try {
    res = await fetch(url, { ...init, headers: { 'Content-Type': 'application/json' } });
  } catch {
    return { ok: false, status: 0 };
  }
  const body = (await res.json().catch(() => undefined)) as (T & ErrorBody) | undefined;
  return { ok: res.ok, status: res.status, body };
}
