export function formatStartsAt(startsAt: string): string {
  const [date, time] = startsAt.split(' ');
  const day = new Date(`${date}T00:00:00Z`).toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  });
  return `${day}, ${time}`;
}

export const formatEur = (amount: number) => `EUR ${amount}`;

export const seatsLeftText = (n: number) => `${n} ${n === 1 ? 'seat' : 'seats'} left`;
