import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router';
import { zodResolver } from '@hookform/resolvers/zod';
import type { z } from 'zod';
import { bookingInputSchema, type BookingInput, type TastingSummary } from '../../shared/api';
import { api } from '../api';
import { Field } from '../Field';
import { formatEur, formatStartsAt, seatsLeftText } from '../format';
import { useApi } from '../useApi';

export default function BookingForm() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const { result } = useApi<TastingSummary[]>('/api/tastings');
  const [submitError, setSubmitError] = useState('');
  const form = useForm<z.input<typeof bookingInputSchema>, unknown, BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  });
  const { errors, isSubmitting } = form.formState;

  if (!result) return <p className="text-stone-600">Loading...</p>;
  const tasting = result.ok ? result.body?.find((t) => t.id === id) : undefined;
  if (!tasting) {
    return (
      <>
        <h1 className="font-serif text-3xl text-wine">Tasting not found</h1>
        <p className="mt-2 text-stone-600">This tasting does not exist.</p>
      </>
    );
  }

  const onSubmit = async (values: BookingInput) => {
    setSubmitError('');
    const res = await api<{ reference: string }>(`/api/tastings/${tasting.id}/bookings`, {
      method: 'POST',
      body: JSON.stringify(values),
    });
    if (res.status === 201 && res.body) {
      navigate(`/bookings/${res.body.reference}`);
      return;
    }
    if ((res.status === 400 || res.status === 409) && res.body?.errors) {
      for (const [field, message] of Object.entries(res.body.errors)) {
        form.setError(field as keyof BookingInput, { message });
      }
      return;
    }
    setSubmitError(res.status === 404 ? 'This tasting no longer exists.' : 'Something went wrong. Try again.');
  };

  return (
    <div className="grid gap-10 md:grid-cols-[1fr_1.2fr]">
      <section>
        <h1 className="font-serif text-3xl text-wine">{tasting.title}</h1>
        <p className="mt-3 text-stone-700">{formatStartsAt(tasting.startsAt)}</p>
        <p className="mt-1 text-stone-700">{`${formatEur(tasting.price)} per guest`}</p>
        <p className="mt-1 text-sm font-medium text-wine">{seatsLeftText(tasting.seatsLeft)}</p>
      </section>

      {tasting.seatsLeft === 0 ? (
        <p role="status" className="rounded-md bg-stone-100 px-4 py-3 text-stone-700">
          This tasting is fully booked
        </p>
      ) : (
        <form
          noValidate
          onSubmit={form.handleSubmit(onSubmit)}
          className="flex flex-col gap-5 rounded-lg border border-parchment bg-white p-6 shadow-sm"
        >
          {submitError && (
            <p role="alert" className="rounded-md border border-red-700 bg-red-50 px-4 py-3 text-red-900">
              {submitError}
            </p>
          )}
          <Field
            id="name"
            label="Name"
            autoComplete="name"
            error={errors.name?.message}
            {...form.register('name')}
          />
          <Field
            id="email"
            label="Email"
            type="email"
            autoComplete="email"
            error={errors.email?.message}
            {...form.register('email')}
          />
          <Field
            id="guests"
            label="Guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={8}
            error={errors.guests?.message}
            {...form.register('guests')}
          />
          <button
            type="submit"
            disabled={isSubmitting}
            className="rounded-md bg-wine px-5 py-3 font-medium text-cream hover:bg-wine-dark disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
          >
            Book
          </button>
        </form>
      )}
    </div>
  );
}
