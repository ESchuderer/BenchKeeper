import { Link, useParams } from 'react-router';
import type { BookingConfirmation } from '../../shared/api';
import { formatEur } from '../format';
import { useApi } from '../useApi';

export default function Confirmation() {
  const { reference = '' } = useParams();
  const { result } = useApi<BookingConfirmation>(`/api/bookings/${reference}`);

  if (!result) return <p className="text-stone-600">Loading...</p>;
  if (!result.ok || !result.body) {
    return (
      <>
        <h1 className="font-serif text-3xl text-wine">Booking not found</h1>
        <Link to="/" className="mt-4 inline-block text-wine underline underline-offset-4">
          Back to all tastings
        </Link>
      </>
    );
  }

  const booking = result.body;
  return (
    <section className="mx-auto max-w-xl rounded-lg border-l-4 border-emerald-700 bg-emerald-50 p-8 shadow-sm">
      <h1 className="font-serif text-3xl text-emerald-950">Booking confirmed</h1>
      <dl className="mt-6 grid grid-cols-[max-content_1fr] gap-x-6 gap-y-3 text-ink">
        <dt className="text-stone-600">Tasting</dt>
        <dd className="font-medium">{booking.tasting.title}</dd>
        <dt className="text-stone-600">Guests</dt>
        <dd className="font-medium">{booking.guests}</dd>
        <dt className="text-stone-600">Total</dt>
        <dd className="font-medium">{formatEur(booking.total)}</dd>
        <dt className="text-stone-600">Booking reference</dt>
        <dd className="font-mono font-medium tracking-widest">{booking.reference}</dd>
      </dl>
      <p className="mt-6 text-sm text-stone-700">Keep this reference for your visit.</p>
      <Link to="/" className="mt-6 inline-block text-wine underline underline-offset-4">
        Back to all tastings
      </Link>
    </section>
  );
}
