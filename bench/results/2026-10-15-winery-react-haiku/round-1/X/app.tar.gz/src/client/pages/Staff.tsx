import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import type { StaffTasting } from '../../shared/api';
import { api } from '../api';
import { Field } from '../Field';
import { formatEur, formatStartsAt, seatsLeftText } from '../format';
import { useApi } from '../useApi';

const cell =
  'flex justify-between gap-4 py-1 before:text-stone-600 before:content-[attr(data-label)] sm:table-cell sm:py-3 sm:pr-4 sm:before:content-none';

const buttonClass =
  'rounded-md bg-wine px-4 py-2 font-medium text-cream hover:bg-wine-dark disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold';

export default function Staff() {
  const { result, reload } = useApi<{ signedIn: boolean }>('/api/staff/session');

  if (!result) return <p className="text-stone-600">Loading...</p>;
  if (!result.body?.signedIn) return <SignIn onSignedIn={reload} />;
  return <Bookings onSignedOut={reload} />;
}

function SignIn({ onSignedIn }: { onSignedIn: () => void }) {
  const form = useForm<{ password: string }>({
    defaultValues: { password: '' },
  });
  const { errors, isSubmitting } = form.formState;

  const onSubmit = async ({ password }: { password: string }) => {
    const res = await api('/api/staff/session', { method: 'POST', body: JSON.stringify({ password }) });
    if (res.ok) {
      onSignedIn();
      return;
    }
    const message =
      res.status === 429 ? 'Too many failed attempts. Try again in 15 minutes.' : (res.body?.error ?? 'Could not sign in.');
    form.setError('password', { message });
  };

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="font-serif text-3xl text-wine">Staff sign in</h1>
      <form
        noValidate
        onSubmit={form.handleSubmit(onSubmit)}
        className="mt-6 flex flex-col gap-5 rounded-lg border border-parchment bg-white p-6 shadow-sm"
      >
        <Field
          id="password"
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          {...form.register('password', { required: 'Enter the password' })}
        />
        <button type="submit" disabled={isSubmitting} className={buttonClass}>
          Sign in
        </button>
      </form>
    </div>
  );
}

function Bookings({ onSignedOut }: { onSignedOut: () => void }) {
  const { result, reload } = useApi<StaffTasting[]>('/api/staff/bookings');
  const [error, setError] = useState('');

  useEffect(() => {
    if (result?.status === 401) onSignedOut();
  }, [result, onSignedOut]);

  const cancel = async (reference: string) => {
    setError('');
    const res = await api(`/api/staff/bookings/${reference}`, { method: 'DELETE' });
    if (res.ok) reload();
    else setError('The booking could not be cancelled. Try again.');
  };

  const signOut = async () => {
    await api('/api/staff/sign-out', { method: 'POST' });
    onSignedOut();
  };

  if (!result) return <p className="text-stone-600">Loading...</p>;

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-serif text-3xl text-wine">Bookings</h1>
        <button type="button" onClick={signOut} className={buttonClass}>
          Sign out
        </button>
      </div>
      {error && (
        <p role="alert" className="mt-6 rounded-md border border-red-700 bg-red-50 px-4 py-3 text-red-900">
          {error}
        </p>
      )}
      <div className="mt-8 flex flex-col gap-8">
        {result.body?.map((t) => (
          <section key={t.id} className="rounded-lg border border-parchment bg-white p-6 shadow-sm">
            <h2 className="font-serif text-xl text-wine">{t.title}</h2>
            <p className="mt-1 text-sm text-stone-600">
              {`${formatStartsAt(t.startsAt)}, ${formatEur(t.price)} per guest, ${seatsLeftText(t.seatsLeft)}`}
            </p>
            {t.bookings.length === 0 ? (
              <p className="mt-4 text-stone-600">No bookings yet.</p>
            ) : (
              <div className="mt-4 overflow-x-auto">
                <table className="block w-full text-left text-sm sm:table">
                  <thead className="hidden border-b border-parchment text-stone-600 sm:table-header-group">
                    <tr>
                      <th className="py-2 pr-4 font-medium">Name</th>
                      <th className="py-2 pr-4 font-medium">Email</th>
                      <th className="py-2 pr-4 font-medium">Guests</th>
                      <th className="py-2 pr-4 font-medium">Reference</th>
                      <th className="py-2 font-medium">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="block sm:table-row-group">
                    {t.bookings.map((b) => (
                      <tr key={b.reference} className="block border-b border-parchment/60 py-3 sm:table-row sm:py-0">
                        <td data-label="Name" className={cell}>{b.name}</td>
                        <td data-label="Email" className={cell}>{b.email}</td>
                        <td data-label="Guests" className={cell}>{b.guests}</td>
                        <td data-label="Reference" className={`${cell} font-mono tracking-wider`}>{b.reference}</td>
                        <td className="pt-2 text-right sm:table-cell sm:py-3">
                          <button
                            type="button"
                            onClick={() => cancel(b.reference)}
                            className="rounded-md border border-red-700 px-3 py-1.5 text-red-800 hover:bg-red-50"
                          >
                            Cancel
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        ))}
      </div>
    </>
  );
}
