import { Link } from 'react-router';
import type { TastingSummary } from '../../shared/api';
import { formatEur, formatStartsAt, seatsLeftText } from '../format';
import { useApi } from '../useApi';

export default function TastingList() {
  const { result } = useApi<TastingSummary[]>('/api/tastings');

  if (!result) return <p className="text-stone-600">Loading tastings...</p>;
  if (!result.ok) {
    return (
      <p role="alert" className="rounded-md border border-red-700 bg-red-50 px-4 py-3 text-red-900">
        The tastings could not be loaded. Try again later.
      </p>
    );
  }

  return (
    <>
      <h1 className="font-serif text-3xl text-wine">Wine tastings</h1>
      <p className="mt-2 text-stone-600">Choose a tasting and reserve your seats online.</p>
      <ul className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {result.body?.map((t) => {
          const soldOut = t.seatsLeft === 0;
          return (
            <li key={t.id}>
              <article className="flex h-full flex-col rounded-lg border border-parchment bg-white p-6 shadow-sm">
                <h2 className="font-serif text-xl text-wine">{t.title}</h2>
                <p className="mt-2 text-stone-700">{formatStartsAt(t.startsAt)}</p>
                <p className="mt-1 text-stone-700">{`${formatEur(t.price)} per guest`}</p>
                <p className={`mt-4 text-sm font-medium ${soldOut ? 'text-stone-500' : 'text-wine'}`}>
                  {soldOut ? 'Fully booked' : seatsLeftText(t.seatsLeft)}
                </p>
                <div className="mt-auto pt-6">
                  {soldOut ? (
                    <span className="inline-block rounded-md bg-stone-100 px-4 py-2.5 text-sm text-stone-500">
                      No seats available
                    </span>
                  ) : (
                    <Link
                      to={`/tastings/${t.id}/book`}
                      className="inline-block rounded-md bg-wine px-4 py-2.5 font-medium text-cream hover:bg-wine-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
                    >
                      Book {t.title}
                    </Link>
                  )}
                </div>
              </article>
            </li>
          );
        })}
      </ul>
    </>
  );
}
