import { useCallback, useEffect, useState } from 'react';
import { api, type ApiResult } from './api';

export function useApi<T>(url: string) {
  const [result, setResult] = useState<ApiResult<T> | null>(null);
  const [version, setVersion] = useState(0);

  useEffect(() => {
    let current = true;
    api<T>(url)
      .then((res) => {
        if (current) setResult(res);
      })
      .catch(() => {
        if (current) setResult({ ok: false, status: 0 });
      });
    return () => {
      current = false;
    };
  }, [url, version]);

  const reload = useCallback(() => setVersion((v) => v + 1), []);
  return { result, reload };
}
