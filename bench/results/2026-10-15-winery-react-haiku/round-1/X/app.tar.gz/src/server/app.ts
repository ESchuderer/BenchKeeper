import path from 'node:path';
import express, { type NextFunction, type Request, type Response } from 'express';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { bookingInputSchema } from '../shared/api.js';
import { createStaffAuth, SESSION_COOKIE, SESSION_MS } from './staff.js';
import { createStore } from './store.js';

export interface AppOptions {
  staffPassword?: string;
  trustProxy?: boolean;
  clientDir?: string;
}

const signInSchema = z.object({ password: z.string({ error: 'Enter the password' }) });

function fieldErrors(error: z.ZodError): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const issue of error.issues) errors[String(issue.path[0] ?? 'form')] ??= issue.message;
  return errors;
}

function cookieFlags(req: Request) {
  return { httpOnly: true, sameSite: 'strict' as const, secure: req.secure, path: '/' };
}

export function createApp({ staffPassword, trustProxy = false, clientDir }: AppOptions = {}) {
  const store = createStore();
  const staff = createStaffAuth(staffPassword);

  const signInLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many failed attempts. Try again in 15 minutes.' },
  });

  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    if (!staff.isValid(req.cookies[SESSION_COOKIE])) {
      res.status(401).json({ error: 'Sign in required' });
      return;
    }
    next();
  };

  const app = express();
  app.set('trust proxy', trustProxy);
  app.disable('x-powered-by');
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  app.get('/api/tastings', (_req, res) => {
    res.json(store.listTastings());
  });

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const parsed = bookingInputSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error) });
      return;
    }
    const result = store.createBooking(req.params.id, parsed.data);
    if (result.status === 'not-found') {
      res.status(404).json({ error: 'Tasting not found' });
      return;
    }
    if (result.status === 'no-seats') {
      const { seatsLeft } = result;
      const guests =
        seatsLeft === 0 ? 'This tasting is fully booked' : `Only ${seatsLeft} seat${seatsLeft === 1 ? '' : 's'} left`;
      res.status(409).json({ errors: { guests } });
      return;
    }
    res.status(201).json(result.confirmation);
  });

  app.get('/api/bookings/:reference', (req, res) => {
    const confirmation = store.getConfirmation(req.params.reference);
    if (!confirmation) {
      res.status(404).json({ error: 'Booking not found' });
      return;
    }
    res.json(confirmation);
  });

  app.get('/api/staff/session', (req, res) => {
    res.json({ signedIn: staff.isValid(req.cookies[SESSION_COOKIE]) });
  });

  app.post('/api/staff/session', signInLimiter, (req, res) => {
    const parsed = signInSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error) });
      return;
    }
    if (!staff.checkPassword(parsed.data.password)) {
      res.status(401).json({ error: 'Wrong password' });
      return;
    }
    res.cookie(SESSION_COOKIE, staff.createSession(), { ...cookieFlags(req), maxAge: SESSION_MS });
    res.status(204).end();
  });

  app.post('/api/staff/sign-out', (req, res) => {
    staff.endSession(req.cookies[SESSION_COOKIE]);
    res.clearCookie(SESSION_COOKIE, cookieFlags(req));
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    res.json(store.listByTasting());
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req: Request<{ reference: string }>, res) => {
    if (!store.cancel(req.params.reference)) {
      res.status(404).json({ error: 'Booking not found' });
      return;
    }
    res.status(204).end();
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found' });
  });

  if (clientDir) {
    app.use(express.static(clientDir));
    app.get('/{*path}', (_req, res) => {
      res.sendFile(path.join(clientDir, 'index.html'));
    });
  }

  app.use((err: { status?: number }, _req: Request, res: Response, next: NextFunction) => {
    if (res.headersSent) return next(err);
    const status = err.status ?? 500;
    res.status(status).json({ error: status < 500 ? 'Invalid request' : 'Server error' });
  });

  return app;
}
