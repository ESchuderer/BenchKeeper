import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const SESSION_COOKIE = 'staff_session';
export const SESSION_MS = 8 * 60 * 60 * 1000;

const digest = (value: string) => createHash('sha256').update(value).digest();

export function createStaffAuth(password: string | undefined) {
  const expected = password ? digest(password) : undefined;
  const sessions = new Map<string, number>();

  return {
    checkPassword(candidate: string): boolean {
      return expected !== undefined && timingSafeEqual(digest(candidate), expected);
    },

    createSession(): string {
      const now = Date.now();
      for (const [token, expiresAt] of sessions) {
        if (expiresAt <= now) sessions.delete(token);
      }
      const token = randomBytes(32).toString('base64url');
      sessions.set(token, now + SESSION_MS);
      return token;
    },

    isValid(token: string | undefined): boolean {
      if (!token) return false;
      const expiresAt = sessions.get(token);
      if (expiresAt === undefined) return false;
      if (expiresAt <= Date.now()) {
        sessions.delete(token);
        return false;
      }
      return true;
    },

    endSession(token: string | undefined) {
      if (token) sessions.delete(token);
    },
  };
}
