import { randomInt } from 'node:crypto';
import type { BookingConfirmation, BookingInput, StaffTasting, TastingSummary } from '../shared/api.js';

interface Tasting {
  id: string;
  title: string;
  startsAt: string;
  price: number;
  seats: number;
}

interface Booking extends BookingInput {
  reference: string;
  tastingId: string;
}

const TASTINGS: Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06 18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05 17:00', price: 28, seats: 10 },
];

const REFERENCE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

export type CreateResult =
  | { status: 'created'; confirmation: BookingConfirmation }
  | { status: 'not-found' }
  | { status: 'no-seats'; seatsLeft: number };

export function createStore() {
  const bookings = new Map<string, Booking>();

  const findTasting = (id: string) => TASTINGS.find((t) => t.id === id);

  const guestsBooked = (tastingId: string) =>
    [...bookings.values()]
      .filter((b) => b.tastingId === tastingId)
      .reduce((sum, b) => sum + b.guests, 0);

  const seatsLeft = (t: Tasting) => t.seats - guestsBooked(t.id);

  const summary = (t: Tasting): TastingSummary => ({
    id: t.id,
    title: t.title,
    startsAt: t.startsAt,
    price: t.price,
    seatsLeft: seatsLeft(t),
  });

  const newReference = () => {
    let reference: string;
    do {
      reference = Array.from({ length: 8 }, () => REFERENCE_CHARS[randomInt(REFERENCE_CHARS.length)]).join('');
    } while (bookings.has(reference));
    return reference;
  };

  const confirmation = (b: Booking): BookingConfirmation => {
    const t = findTasting(b.tastingId)!;
    return {
      reference: b.reference,
      tasting: { id: t.id, title: t.title },
      guests: b.guests,
      total: t.price * b.guests,
    };
  };

  return {
    listTastings: (): TastingSummary[] => TASTINGS.map(summary),

    createBooking(tastingId: string, input: BookingInput): CreateResult {
      const t = findTasting(tastingId);
      if (!t) return { status: 'not-found' };
      const left = seatsLeft(t);
      if (input.guests > left) return { status: 'no-seats', seatsLeft: left };
      const booking: Booking = { ...input, reference: newReference(), tastingId };
      bookings.set(booking.reference, booking);
      return { status: 'created', confirmation: confirmation(booking) };
    },

    getConfirmation(reference: string): BookingConfirmation | undefined {
      const b = bookings.get(reference);
      return b && confirmation(b);
    },

    listByTasting: (): StaffTasting[] =>
      TASTINGS.map((t) => ({
        ...summary(t),
        bookings: [...bookings.values()]
          .filter((b) => b.tastingId === t.id)
          .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
      })),

    cancel(reference: string): boolean {
      return bookings.delete(reference);
    },
  };
}
