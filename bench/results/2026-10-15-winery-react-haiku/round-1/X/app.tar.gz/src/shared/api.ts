import { z } from 'zod';

export const bookingInputSchema = z.object({
  name: z
    .string({ error: 'Enter your name' })
    .trim()
    .min(1, 'Enter your name')
    .max(100, 'Use 100 characters or fewer'),
  email: z
    .string({ error: 'Enter your email address' })
    .trim()
    .pipe(z.email('Enter a valid email address')),
  guests: z
    .coerce.number({ error: 'Enter the number of guests' })
    .int('Use a whole number of guests')
    .min(1, 'Book for at least 1 guest')
    .max(8, 'Book for at most 8 guests'),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;

export interface TastingSummary {
  id: string;
  title: string;
  startsAt: string;
  price: number;
  seatsLeft: number;
}

export interface BookingConfirmation {
  reference: string;
  tasting: { id: string; title: string };
  guests: number;
  total: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTasting extends TastingSummary {
  bookings: StaffBooking[];
}
