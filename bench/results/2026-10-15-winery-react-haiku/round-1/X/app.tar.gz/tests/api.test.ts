import request from 'supertest';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createApp } from '../src/server/app.js';

const PASSWORD = 'correct horse battery';
const RIESLING = 'riesling-evening';
const RED = 'red-wine-cellar-tour';
const WINTER = 'winter-tasting';
const REFERENCE_PATTERN = /^[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{8}$/;

function server(staffPassword: string | undefined = PASSWORD, trustProxy = false) {
  return request(createApp({ staffPassword, trustProxy }));
}

async function signIn(app: ReturnType<typeof server>, password = PASSWORD) {
  const res = await app.post('/api/staff/session').send({ password });
  expect(res.status).toBe(204);
  return res.headers['set-cookie'][0].split(';')[0];
}

async function book(app: ReturnType<typeof server>, tastingId: string, guests: number, name = 'Ada Guest') {
  return app.post(`/api/tastings/${tastingId}/bookings`).send({ name, email: 'ada@example.com', guests });
}

afterEach(() => {
  vi.useRealTimers();
});

describe('GET /api/tastings', () => {
  it('lists the three tastings with all seats left', async () => {
    const res = await server().get('/api/tastings');

    expect(res.status).toBe(200);
    expect(res.body).toEqual([
      { id: RIESLING, title: 'Riesling Evening', startsAt: '2026-11-06 18:00', price: 25, seatsLeft: 12 },
      { id: RED, title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', price: 32, seatsLeft: 8 },
      { id: WINTER, title: 'Winter Tasting', startsAt: '2026-12-05 17:00', price: 28, seatsLeft: 10 },
    ]);
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking with reference and total', async () => {
    const res = await book(server(), RIESLING, 2);

    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(REFERENCE_PATTERN),
      tasting: { id: RIESLING, title: 'Riesling Evening' },
      guests: 2,
      total: 50,
    });
  });

  it('reduces the seats left', async () => {
    const app = server();
    await book(app, RIESLING, 5);

    const list = await app.get('/api/tastings');
    expect(list.body[0].seatsLeft).toBe(7);
  });

  it('accepts a booking for exactly the seats left', async () => {
    const app = server();
    await book(app, RED, 5);

    const res = await book(app, RED, 3);
    expect(res.status).toBe(201);
  });

  it('rejects more guests than seats left with a field error on guests', async () => {
    const app = server();
    await book(app, RIESLING, 8);

    const res = await book(app, RIESLING, 5);
    expect(res.status).toBe(409);
    expect(res.body.errors.guests).toBe('Only 4 seats left');
  });

  it('rejects a booking when the tasting is fully booked', async () => {
    const app = server();
    await book(app, RED, 8);

    const res = await book(app, RED, 1);
    expect(res.status).toBe(409);
    expect(res.body.errors.guests).toBe('This tasting is fully booked');
  });

  it('does not change seats when a booking is rejected', async () => {
    const app = server();
    await book(app, WINTER, 8);
    expect((await book(app, WINTER, 2)).status).toBe(201);
    expect((await book(app, WINTER, 1)).status).toBe(409);

    const list = await app.get('/api/tastings');
    expect(list.body[2].seatsLeft).toBe(0);
  });

  it.each([
    ['name missing', { name: '', email: 'a@example.com', guests: 1 }, 'name'],
    ['name too long', { name: 'x'.repeat(101), email: 'a@example.com', guests: 1 }, 'name'],
    ['email invalid', { name: 'Ada', email: 'not-an-email', guests: 1 }, 'email'],
    ['email missing', { name: 'Ada', guests: 1 }, 'email'],
    ['guests zero', { name: 'Ada', email: 'a@example.com', guests: 0 }, 'guests'],
    ['guests nine', { name: 'Ada', email: 'a@example.com', guests: 9 }, 'guests'],
    ['guests fractional', { name: 'Ada', email: 'a@example.com', guests: 2.5 }, 'guests'],
    ['guests not a number', { name: 'Ada', email: 'a@example.com', guests: 'many' }, 'guests'],
    ['no body', undefined, 'name'],
  ])('rejects invalid input (%s) with a field error', async (_label, body, field) => {
    const app = server();
    const res = await app.post(`/api/tastings/${RIESLING}/bookings`).send(body);

    expect(res.status).toBe(400);
    expect(res.body.errors[field]).toEqual(expect.any(String));
  });

  it('returns a JSON error for a malformed request body', async () => {
    const res = await server()
      .post(`/api/tastings/${RIESLING}/bookings`)
      .set('Content-Type', 'application/json')
      .send('{');

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ error: 'Invalid request' });
  });

  it('returns 404 for an unknown tasting', async () => {
    const res = await book(server(), 'no-such-tasting', 1);
    expect(res.status).toBe(404);
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the confirmation without the guest name or email', async () => {
    const app = server();
    const created = await book(app, RED, 2);

    const res = await app.get(`/api/bookings/${created.body.reference}`);

    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      reference: created.body.reference,
      tasting: { id: RED, title: 'Red Wine Cellar Tour' },
      guests: 2,
      total: 64,
    });
    expect(res.body).not.toHaveProperty('email');
    expect(res.body).not.toHaveProperty('name');
  });

  it('returns 404 for an unknown reference', async () => {
    const res = await server().get('/api/bookings/ZZZZZZZZ');
    expect(res.status).toBe(404);
  });
});

describe('staff sign-in', () => {
  it('rejects a wrong password without setting a cookie', async () => {
    const res = await server().post('/api/staff/session').send({ password: 'wrong' });

    expect(res.status).toBe(401);
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('sets an HttpOnly, SameSite=Strict session cookie for 8 hours', async () => {
    const res = await server().post('/api/staff/session').send({ password: PASSWORD });

    expect(res.status).toBe(204);
    const cookie = res.headers['set-cookie'][0];
    expect(cookie).toMatch(/^staff_session=[A-Za-z0-9_-]{43};/);
    expect(cookie).toMatch(/HttpOnly/);
    expect(cookie).toMatch(/SameSite=Strict/);
    expect(cookie).toMatch(/Path=\//);
    expect(cookie).toMatch(/Max-Age=28800/);
    expect(cookie).not.toMatch(/Secure/);
  });

  it('adds Secure to the cookie when the request is HTTPS behind a trusted proxy', async () => {
    const res = await server(PASSWORD, true)
      .post('/api/staff/session')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD });

    expect(res.headers['set-cookie'][0]).toMatch(/; Secure/);
  });

  it('never signs in when STAFF_PASSWORD is not configured', async () => {
    const app = server(undefined);

    expect((await app.post('/api/staff/session').send({ password: '' })).status).toBe(401);
    expect((await app.post('/api/staff/session').send({ password: 'anything' })).status).toBe(401);
  });

  it('reports the session state', async () => {
    const app = server();
    expect((await app.get('/api/staff/session')).body).toEqual({ signedIn: false });

    const cookie = await signIn(app);
    const res = await app.get('/api/staff/session').set('Cookie', cookie);
    expect(res.body).toEqual({ signedIn: true });
  });

  it('expires the session 8 hours after sign-in', async () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    const app = server();
    const cookie = await signIn(app);

    vi.setSystemTime(Date.now() + 8 * 60 * 60 * 1000 - 60_000);
    expect((await app.get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(200);

    vi.setSystemTime(Date.now() + 60_000);
    expect((await app.get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });

  it('ends the session on sign-out and clears the cookie', async () => {
    const app = server();
    const cookie = await signIn(app);

    const out = await app.post('/api/staff/sign-out').set('Cookie', cookie);
    expect(out.status).toBe(204);
    expect(out.headers['set-cookie'][0]).toMatch(/^staff_session=;.*Max-Age=0|^staff_session=;.*Expires=Thu, 01 Jan 1970/);

    expect((await app.get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });

  it('locks sign-in after 5 failed attempts with 429', async () => {
    const app = server();
    for (let i = 0; i < 5; i++) {
      expect((await app.post('/api/staff/session').send({ password: 'wrong' })).status).toBe(401);
    }

    expect((await app.post('/api/staff/session').send({ password: 'wrong' })).status).toBe(429);
    expect((await app.post('/api/staff/session').send({ password: PASSWORD })).status).toBe(429);
  });

  it('does not count successful sign-ins towards the limit', async () => {
    const app = server();
    for (let i = 0; i < 4; i++) {
      await app.post('/api/staff/session').send({ password: 'wrong' });
    }
    expect((await app.post('/api/staff/session').send({ password: PASSWORD })).status).toBe(204);

    expect((await app.post('/api/staff/session').send({ password: 'wrong' })).status).toBe(401);
    expect((await app.post('/api/staff/session').send({ password: 'wrong' })).status).toBe(429);
  });
});

describe('staff bookings', () => {
  it('requires a session to list bookings', async () => {
    expect((await server().get('/api/staff/bookings')).status).toBe(401);
  });

  it('lists bookings grouped by tasting with contact details', async () => {
    const app = server();
    const cookie = await signIn(app);
    const created = await book(app, RIESLING, 3, 'Ada Guest');

    const res = await app.get('/api/staff/bookings').set('Cookie', cookie);

    expect(res.status).toBe(200);
    const riesling = res.body.find((t: { id: string }) => t.id === RIESLING);
    expect(riesling.bookings).toEqual([
      { reference: created.body.reference, name: 'Ada Guest', email: 'ada@example.com', guests: 3 },
    ]);
    expect(res.body.find((t: { id: string }) => t.id === RED).bookings).toEqual([]);
  });

  it('requires a session to cancel', async () => {
    const app = server();
    const created = await book(app, RIESLING, 1);

    expect((await app.delete(`/api/staff/bookings/${created.body.reference}`)).status).toBe(401);
  });

  it('cancels a booking and frees its seats', async () => {
    const app = server();
    const cookie = await signIn(app);
    const created = await book(app, RIESLING, 4);

    const res = await app.delete(`/api/staff/bookings/${created.body.reference}`).set('Cookie', cookie);
    expect(res.status).toBe(204);

    const list = await app.get('/api/tastings');
    expect(list.body[0].seatsLeft).toBe(12);
    expect((await app.get(`/api/bookings/${created.body.reference}`)).status).toBe(404);
  });

  it('returns 404 when cancelling an unknown reference', async () => {
    const app = server();
    const cookie = await signIn(app);

    expect((await app.delete('/api/staff/bookings/ZZZZZZZZ').set('Cookie', cookie)).status).toBe(404);
  });
});
