// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { AppRoutes } from '../src/client/App';

type Reply = { status: number; body?: unknown };
type Handler = Reply | ((body: Record<string, unknown>) => Reply);

function mockApi(handlers: Record<string, Handler>) {
  const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
    const key = `${init?.method ?? 'GET'} ${url}`;
    const handler = handlers[key];
    if (!handler) throw new Error(`Unmocked request: ${key}`);
    const reply = typeof handler === 'function' ? handler(init?.body ? JSON.parse(init.body as string) : {}) : handler;
    return new Response(reply.body === undefined ? null : JSON.stringify(reply.body), {
      status: reply.status,
      headers: { 'Content-Type': 'application/json' },
    });
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

function renderAt(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <AppRoutes />
    </MemoryRouter>,
  );
}

const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06 18:00', price: 25, seatsLeft: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', price: 32, seatsLeft: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05 17:00', price: 28, seatsLeft: 0 },
];

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe('start page', () => {
  it('lists each tasting with date, price per guest, seats left and a booking link', async () => {
    mockApi({ 'GET /api/tastings': { status: 200, body: TASTINGS } });
    renderAt('/');

    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByText('Friday, 6 November 2026, 18:00')).toBeInTheDocument();
    expect(screen.getByText('EUR 25 per guest')).toBeInTheDocument();
    expect(screen.getByText('12 seats left')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toHaveAttribute(
      'href',
      '/tastings/riesling-evening/book',
    );
  });

  it('shows a fully booked tasting without a booking link', async () => {
    mockApi({ 'GET /api/tastings': { status: 200, body: TASTINGS } });
    renderAt('/');

    expect(await screen.findByText('Fully booked')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Winter Tasting' })).not.toBeInTheDocument();
  });
});

describe('booking form', () => {
  const RIESLING_BOOKINGS = 'POST /api/tastings/riesling-evening/bookings';

  it('shows each validation error next to the field it concerns and does not submit', async () => {
    const fetchMock = mockApi({ 'GET /api/tastings': { status: 200, body: TASTINGS } });
    renderAt('/tastings/riesling-evening/book');
    const user = userEvent.setup();
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText('Enter your name')).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toHaveAccessibleDescription('Enter your name');

    await user.type(screen.getByLabelText('Email'), 'not-an-email');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText('Enter a valid email address')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Enter a valid email address');

    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText('Book for at most 8 guests')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Book for at most 8 guests');

    expect(fetchMock).not.toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ method: 'POST' }));
  });

  it('shows the seats-left message from the server under Guests', async () => {
    mockApi({
      'GET /api/tastings': { status: 200, body: TASTINGS },
      [RIESLING_BOOKINGS]: { status: 409, body: { errors: { guests: 'Only 4 seats left' } } },
    });
    renderAt('/tastings/riesling-evening/book');
    const user = userEvent.setup();
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Name'), 'Ada Guest');
    await user.type(screen.getByLabelText('Email'), 'ada@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '5');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Only 4 seats left')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Only 4 seats left');
  });

  it('shows the booking confirmation after a successful booking', async () => {
    mockApi({
      'GET /api/tastings': { status: 200, body: TASTINGS },
      [RIESLING_BOOKINGS]: (body) => ({
        status: 201,
        body: { reference: 'K7Q2M9TP', tasting: { id: 'riesling-evening', title: 'Riesling Evening' }, guests: Number(body.guests), total: 25 * Number(body.guests) },
      }),
      'GET /api/bookings/K7Q2M9TP': {
        status: 200,
        body: { reference: 'K7Q2M9TP', tasting: { id: 'riesling-evening', title: 'Riesling Evening' }, guests: 2, total: 50 },
      },
    });
    renderAt('/tastings/riesling-evening/book');
    const user = userEvent.setup();
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Name'), 'Ada Guest');
    await user.type(screen.getByLabelText('Email'), 'ada@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument();
    expect(screen.getByText('EUR 50')).toBeInTheDocument();
    expect(screen.getByText('K7Q2M9TP')).toBeInTheDocument();
  });

  it('shows a retry message when the booking request cannot reach the server', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (init?.method === 'POST') throw new TypeError('Failed to fetch');
        return new Response(JSON.stringify(TASTINGS), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }),
    );
    renderAt('/tastings/riesling-evening/book');
    const user = userEvent.setup();
    await screen.findByRole('heading', { name: 'Riesling Evening' });

    await user.type(screen.getByLabelText('Name'), 'Ada Guest');
    await user.type(screen.getByLabelText('Email'), 'ada@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Something went wrong. Try again.');
  });

  it('does not offer the form for a fully booked tasting', async () => {
    mockApi({ 'GET /api/tastings': { status: 200, body: TASTINGS } });
    renderAt('/tastings/winter-tasting/book');

    expect(await screen.findByText('This tasting is fully booked')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });
});

describe('staff page', () => {
  it('shows an error next to the password after a wrong password', async () => {
    mockApi({
      'GET /api/staff/session': { status: 200, body: { signedIn: false } },
      'POST /api/staff/session': { status: 401, body: { error: 'Wrong password' } },
    });
    renderAt('/staff');
    const user = userEvent.setup();

    await user.type(await screen.findByLabelText('Password'), 'wrong');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByText('Wrong password')).toBeInTheDocument();
    expect(screen.getByLabelText('Password')).toHaveAccessibleDescription('Wrong password');
  });

  it('lists bookings per tasting, cancels one and signs out', async () => {
    let signedIn = true;
    let bookings = [
      {
        id: 'riesling-evening',
        title: 'Riesling Evening',
        startsAt: '2026-11-06 18:00',
        price: 25,
        seatsLeft: 9,
        bookings: [{ reference: 'K7Q2M9TP', name: 'Ada Guest', email: 'ada@example.com', guests: 3 }],
      },
    ];
    const fetchMock = mockApi({
      'GET /api/staff/session': () => ({ status: 200, body: { signedIn } }),
      'GET /api/staff/bookings': () => ({ status: 200, body: bookings }),
      'DELETE /api/staff/bookings/K7Q2M9TP': () => {
        bookings = [{ ...bookings[0], seatsLeft: 12, bookings: [] }];
        return { status: 204 };
      },
      'POST /api/staff/sign-out': () => {
        signedIn = false;
        return { status: 204 };
      },
    });
    renderAt('/staff');
    const user = userEvent.setup();

    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByText('Ada Guest')).toBeInTheDocument();
    expect(screen.getByText('ada@example.com')).toBeInTheDocument();
    expect(screen.getByText('K7Q2M9TP')).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    await waitFor(() => expect(screen.queryByText('Ada Guest')).not.toBeInTheDocument());
    expect(fetchMock).toHaveBeenCalledWith('/api/staff/bookings/K7Q2M9TP', expect.objectContaining({ method: 'DELETE' }));

    await user.click(screen.getByRole('button', { name: 'Sign out' }));
    expect(await screen.findByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });
});
