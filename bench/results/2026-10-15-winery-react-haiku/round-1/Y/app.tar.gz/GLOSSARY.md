# Glossary

- **Tasting**: a scheduled wine tasting with a title, start time, price per guest and seat count. The three tastings are fixed in `shared/tastings.ts`.
- **Seats left**: the tasting's seat count minus the guests of all its bookings.
- **Booking**: a guest's reservation of one or more seats on one tasting, with a name, email, guest count and reference.
- **Booking reference**: the code (`KB-` plus 6 characters) that identifies a booking on the confirmation page and in the staff list.
- **Guest**: a person attending a tasting. The word also counts the seats a booking takes ("3 guests").
- **Staff**: winery employees who sign in with the staff password to view and cancel bookings.
- **Cancellation**: staff removal of a booking, which frees its seats.
