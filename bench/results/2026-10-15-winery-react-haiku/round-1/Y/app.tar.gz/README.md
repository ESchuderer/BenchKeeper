# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online. Staff sign in to see and cancel bookings.

## Requirements

- Node.js 22
- npm

## Commands

```sh
npm install        # install dependencies
npm run build      # build the React app into dist/client
npm start          # serve the app and API on PORT (default 3000)
npm test           # run the test suite
npm run typecheck  # TypeScript check
npm run lint       # ESLint
```

## Environment variables

| Name | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | HTTP port |
| `STAFF_PASSWORD` | unset | Password for `/staff`. If unset, staff sign-in always fails. |

## Data

Bookings are held in memory. The app starts with no bookings and loses them on restart.
