# Design

## Context

The repository has no application code yet, only OpenSpec and the project setup (Node.js 22, npm). The app must run with `npm install`, `npm run build` and `npm start` on `PORT` (default 3000), with no external services. Requirements are in `specs/`; motivation is in `proposal.md`.

## Goals / Non-Goals

**Goals:**
- One Node.js process serves the JSON API under `/api` and the React single-page app.
- Validation rules live in one schema shared by the browser form and the server.
- Seat counts cannot go negative under concurrent requests.

**Non-Goals:**
- Persistence across restarts, multiple server instances, payments, email, editing tastings in the UI, time zone handling.

## Decisions

- **Server: Express 5 with `tsx`.** The server runs TypeScript directly with `tsx server/index.ts`, so there is no separate server build step. Express is the established option for a small Node server; alternatives (Fastify, Next.js) add more surface than three routes need.
- **Client: Vite + React + react-router.** Vite builds the static bundle to `dist/client`; Express serves it and falls back to `index.html` for non-`/api` paths. Next.js was rejected because the app needs no server rendering.
- **Forms: react-hook-form with `@hookform/resolvers` and zod.** The zod schema for the booking form is in `shared/booking.ts` and is used by the client resolver and by the server route. The server check is authoritative.
- **Styling: Tailwind CSS v4 via `@tailwindcss/vite`.** Theme colours and the serif heading font are declared once in `src/index.css`. The font is a system serif stack, so no external font service is loaded.
- **Catalogue data: constant array in `shared/tastings.ts`.** The three tastings are fixed by the brief. Ids are slugs (`riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`). Prices are whole euros; totals are computed as `price * guests`.
- **Storage: in-memory `Map` in `server/store.ts`.** Booking creation checks seats and inserts in one synchronous function, so Node's single thread prevents double booking without locks. Starting with no bookings matches the brief.
- **Booking reference: `KB-` plus 6 characters** from an alphabet without `0`, `O`, `1`, `I`, generated with `crypto.randomInt`. A collision with an existing reference is retried.
- **Confirmation page: `GET /api/bookings/:reference`** returns only tasting, guests, total and reference, not name or email, so the reference alone does not expose guest details.
- **Staff password: `crypto.timingSafeEqual` on SHA-256 digests** of the submitted and configured password. A missing `STAFF_PASSWORD` yields no valid password.
- **Staff session: random 32-byte token** in a cookie named `staff_session`, stored in a `Map` with an 8-hour expiry. Cookie: `HttpOnly`, `SameSite=Strict`, `Path=/`, `Secure` when `req.secure` is true.
- **Failed-attempt limit: `Map` keyed by `req.ip`.** The window starts at the first failure, not a sliding one; five failures open a 15-minute lock. Entries older than the window are dropped when the map is touched, so it stays bounded by active clients.
- **API errors:** validation and seat errors return `400` or `409` with `{ "errors": { "<field>": "<message>" } }`, which the form maps onto fields.
- **Routes:**

  | Method | Path | Result |
  |---|---|---|
  | GET | `/api/tastings` | list with `seatsLeft` |
  | GET | `/api/tastings/:id` | one tasting, `404` if unknown |
  | POST | `/api/tastings/:id/bookings` | `201` with booking summary; `400`, `404`, `409` |
  | GET | `/api/bookings/:reference` | booking summary, `404` if unknown |
  | POST | `/api/staff/session` | `204` and cookie; `401` wrong password; `429` locked |
  | GET | `/api/staff/session` | `204` when signed in; `401` otherwise (the client uses it on page load) |
  | DELETE | `/api/staff/session` | `204`, clears cookie |
  | GET | `/api/staff/bookings` | `200` grouped by tasting; `401` without session |
  | DELETE | `/api/staff/bookings/:reference` | `204`; `401` without session; `404` unknown |

- **Client routes:** `/` start page, `/tastings/:id` booking form, `/bookings/:reference` confirmation, `/staff` sign-in and list.
- **Tests: Vitest with supertest** for the schema and the API. Browser behaviour is checked with Playwright MCP against the running app.

## Risks / Trade-offs

- **Bookings, sessions and failed-attempt counts are lost on restart** → accepted by the brief for bookings; the code carries a `shortcut:` comment naming the upgrade (file or SQLite).
- **Rate limit and cookie `Secure` use the direct client address** → behind a TLS-terminating proxy every client shares one IP and `req.secure` is false. Mitigation: set Express `trust proxy` when deploying behind a proxy (not configured here).
- **Single process only** → sessions and bookings are in memory, so two instances would disagree. Acceptable for one winery site on one server.
- **Reference is a bearer token for the confirmation page** → it exposes tasting, guests and total only. Guessing is limited by the 8-character space and the lack of a listing endpoint.

## Migration Plan

Not applicable: the repository has no existing application or data. Rollback is removing the commit.

## Open Questions

None.
