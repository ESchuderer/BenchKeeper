# Proposal

## Why

Guests cannot book wine tastings online, and staff have no view of bookings. The winery needs a booking site for its three tastings and a staff page that lists and cancels bookings.

## What Changes

- Add a public catalogue of the three tastings with title, date and time, price per guest and seats left.
- Add a per-tasting booking form (Name, Email, Guests 1 to 8) that rejects invalid input and never books more seats than are left.
- Add a booking confirmation page with reference, tasting, guests and total price.
- Add a staff page at `/staff` protected by the password from `STAFF_PASSWORD`, listing bookings grouped by tasting and cancelling them.
- Bookings are held in memory; the app starts with no bookings.

Assumptions (no user input available during planning):

- Tasting times are the winery's local time, shown as given; no time zone conversion.
- Prices are shown as `EUR <amount>` per guest and as a total; no VAT line.
- Bookings are lost on restart.
- If `STAFF_PASSWORD` is unset, staff sign-in always fails.

## Capabilities

### New Capabilities

- `tasting-catalog`: the list of tastings with date, price per guest and seats left, and the sold-out state.
- `tasting-booking`: the booking form, input validation, seat capacity rule, booking reference and confirmation.
- `staff-bookings`: staff sign-in with the shared password, session expiry and sign-out, rate limiting of failed sign-ins, the bookings list grouped by tasting, and booking cancellation.

### Modified Capabilities

None (`openspec/specs/` is empty).

## Impact

- New Node.js 22 project at the repository root: Express server serving a React single-page app built with Vite.
- Dependencies: react, react-dom, react-router, react-hook-form, @hookform/resolvers, zod, express, cookie-parser, tailwindcss, @tailwindcss/vite, vite, tsx, typescript, vitest, supertest.
- Environment variables: `PORT` (default 3000), `STAFF_PASSWORD`.
- No external services, no database.
