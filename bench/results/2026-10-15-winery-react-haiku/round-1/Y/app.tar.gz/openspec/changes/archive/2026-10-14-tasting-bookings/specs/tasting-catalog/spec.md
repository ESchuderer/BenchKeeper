# Spec Delta

## Purpose

Shows guests the wine tastings on offer with their date, price and remaining seats, and links each tasting to its booking form. Covers the start page and the sold-out state.

## ADDED Requirements

### Requirement: Start page lists the tastings
The start page SHALL list the tastings Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats), each with its title, date and time, price per guest and seats left. When one seat is left the text SHALL be "1 seat left".

#### Scenario: All tastings shown on an empty booking book
- **WHEN** a guest opens the start page and no bookings exist
- **THEN** the page shows three tastings, each with its title, date and time, price per guest, and "12 seats left", "8 seats left" or "10 seats left" respectively

#### Scenario: Seats left reflect bookings
- **WHEN** a booking of 3 guests exists for Riesling Evening and a guest opens the start page
- **THEN** Riesling Evening shows "9 seats left"

### Requirement: Each tasting links to its booking form
Each tasting SHALL have a link or button labelled "Book <tasting title>" that opens that tasting's booking form.

#### Scenario: Booking link for a tasting
- **WHEN** a guest selects "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens

### Requirement: Fully booked tasting
A tasting with no seats left SHALL show the text "Fully booked" in place of a seat count, and its booking form SHALL NOT accept bookings.

#### Scenario: Sold-out tasting
- **WHEN** all 8 seats of Red Wine Cellar Tour are booked and a guest opens the start page
- **THEN** Red Wine Cellar Tour shows "Fully booked"

#### Scenario: Booking form of a sold-out tasting
- **WHEN** a guest opens the booking form of a fully booked tasting
- **THEN** the page shows "Fully booked" and no booking fields or Book button
