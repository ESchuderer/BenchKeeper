# Tasks

## 1. Project setup

- [x] 1.1 Add `package.json` (type module, scripts `build`, `start`, `test`, `typecheck`, `lint`) and install dependencies; verify `npm install` succeeds in the container
- [x] 1.2 Add `tsconfig.json`, `vite.config.ts` (React and Tailwind plugins, build output `dist/client`), `index.html` and `src/main.tsx` rendering an empty app; verify `npm run build` and `npm run typecheck` succeed
- [x] 1.3 Add `eslint.config.js` covering TypeScript and React hooks; verify `npm run lint` succeeds

## 2. Tastings and booking rules (shared)

- [x] 2.1 Write `test/booking-schema.test.ts` with cases for each rule in `tasting-booking` (empty or blank name, name over 100 characters, invalid email, guests 0, 9, 2.5, "two", empty); verify it fails before the schema exists
- [x] 2.2 Add `shared/tastings.ts` with the three tastings, the price formatting `EUR <amount>` and the start formatting in UTC; verify a unit assertion in `test/booking-schema.test.ts` that the start formats as "6 November 2026, 18:00"
- [x] 2.3 Add `shared/booking.ts` with the zod schema and the error messages from the spec; verify `npm test` passes the tests from 2.1

## 3. Bookings API

- [x] 3.1 Write `test/bookings-api.test.ts` (supertest) for: list shows 12, 8, 10 seats left; booking reduces seats left; over-capacity booking gets 409 with "Only 2 seats left" and no change; 400 with field errors; 404 for unknown tasting; confirmation returns tasting, guests, total (EUR 64 for 2 Red Wine Cellar Tour guests), reference, and no name or email; unknown reference 404; verify the tests fail before the implementation
- [x] 3.2 Add `server/store.ts` (in-memory bookings, seat count, reference generator with collision retry, and `shortcut:` comment for the in-memory limit) and `server/app.ts` with the tastings and bookings routes; verify `npm test` passes these tests
- [x] 3.3 Add the `shared/booking.ts` schema check to the POST route and the `errors` response shape; verify the 400 test from 3.1 passes

## 4. Staff sign-in

- [x] 4.1 Write `test/staff-session.test.ts` for: correct password sets cookie with `HttpOnly`, `SameSite=Strict`, no `Secure` over HTTP; wrong password 401 "Wrong password"; unset `STAFF_PASSWORD` rejects any password; 5 failures lock for 15 minutes (429 "Too many attempts. Try again later.") and the lock ends after 15 minutes; a successful sign-in resets the count; session expires after 8 hours; sign-out ends the session; verify the tests fail before the implementation
- [x] 4.2 Add `server/staff.ts` (SHA-256 `timingSafeEqual` comparison, session map with expiry, failed-attempt map keyed by IP, `now` injected for tests) and the `POST` and `DELETE /api/staff/session` routes in `server/app.ts`; verify the tests from 4.1 pass
- [x] 4.3 Set `Secure` on the cookie when `req.secure` is true; add a case to `test/staff-session.test.ts` that asserts it, and verify it passes

## 5. Staff bookings API

- [x] 5.1 Write `test/staff-bookings.test.ts` for: list without session 401; list with session groups bookings by tasting and shows "No bookings" for an empty tasting (returned as an empty list); cancel without session 401 and booking kept; cancel with session removes booking and frees seats; cancel unknown reference 404; verify the tests fail before the implementation
- [x] 5.2 Add `GET /api/staff/bookings` and `DELETE /api/staff/bookings/:reference` to `server/app.ts`, guarded by a session check; verify the tests from 5.1 pass

## 6. Server entry point

- [x] 6.1 Add `server/index.ts` that listens on `PORT` (default 3000), serves `dist/client` with the `index.html` fallback for non-`/api` paths, and logs a warning (without the password) when `STAFF_PASSWORD` is unset; verify `npm run build && PORT=3100 npm start` serves `/api/tastings` and `/` with HTTP 200

## 7. Guest pages

- [x] 7.1 Add `src/` pages for the start page (tastings with title, date and time, price, "<n> seats left" or "Fully booked", "Book <title>" link), the booking form (fields Name, Email, Guests with inline errors and server errors mapped to fields, "Book" button, "Fully booked" or "Tasting not found" states) and the confirmation page ("Booking confirmed", tasting, guests, total, reference, "Booking not found"); using react-router, react-hook-form and the shared schema; verify `npm run typecheck` and `npm run build` pass
- [x] 7.2 Verify the guest flow in the browser with Playwright MCP against `npm start` on desktop and a 375 px wide viewport: book, see confirmation, see the seat count drop, see the seats-left error, and see the fully booked state; record the result in the final report

## 8. Staff page

- [x] 8.1 Add `src/pages/StaffPage.tsx` with the sign-in form ("Password", "Sign in", inline and lockout messages), the bookings list grouped by tasting with name, email, guests, reference and a "Cancel" button per booking, and "Sign out"; verify `npm run typecheck` and `npm run build` pass
- [x] 8.2 Verify the staff flow in the browser with Playwright MCP: wrong password, correct password, cancel a booking and see the seats freed on the start page, sign out; record the result in the final report

## 9. Look and feel

- [x] 9.1 Add `src/index.css` with the Tailwind theme (wine, cream, gold accents, serif headings), a header with the winery name "Weingut Kieselbrunnen", and styles for the error, success and fully booked states; verify with a screenshot at 375 px and 1280 px in Playwright MCP that the layout is readable and the states are distinct

## 10. Documentation

- [x] 10.1 Add `README.md` with install, build, start, test commands and the `PORT` and `STAFF_PASSWORD` variables; verify each command in the README runs as written

## 11. Integration

- [x] 11.1 Run `npm install`, `npm run typecheck`, `npm run lint`, `npm test`, `npm run build` and `npm start` from a clean state; verify all pass with no failing tests

## Workflow follow-up

- Run `code-review` on the branch and fix findings in new commits.
- Archive the change with `openspec-archive-change` on this branch.
