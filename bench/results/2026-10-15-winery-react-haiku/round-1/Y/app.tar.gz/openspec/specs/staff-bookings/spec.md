# staff-bookings Specification

## Purpose
Lets staff sign in with the shared staff password, view all bookings grouped by tasting, and cancel a booking to free its seats. Covers sign-in, session handling, limits on failed sign-in attempts and the bookings list.

## Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL show a "Password" field and a "Sign in" button until staff are signed in. The password SHALL be compared with the value of the environment variable `STAFF_PASSWORD`. If `STAFF_PASSWORD` is not set, every sign-in SHALL fail.

#### Scenario: Correct password
- **WHEN** staff enter the value of `STAFF_PASSWORD` and select "Sign in"
- **THEN** the bookings list is shown

#### Scenario: Wrong password
- **WHEN** staff enter a different password and select "Sign in"
- **THEN** the error "Wrong password" is shown and the bookings list is not shown

#### Scenario: Password not configured
- **WHEN** `STAFF_PASSWORD` is not set and staff enter any password
- **THEN** the error "Wrong password" is shown

### Requirement: Session lifetime and sign-out
A staff session SHALL expire 8 hours after sign-in. Staff SHALL be able to end their session with a "Sign out" button, after which the bookings list is no longer shown and cannot be fetched without signing in again.

#### Scenario: Sign out
- **WHEN** signed-in staff select "Sign out"
- **THEN** the sign-in form is shown and the bookings list is not

#### Scenario: Expired session
- **WHEN** a staff session is more than 8 hours old and staff request the bookings list
- **THEN** the sign-in form is shown

### Requirement: Limit on failed sign-in attempts
After 5 failed sign-in attempts from the same client within 15 minutes, further sign-in attempts from that client SHALL be refused for 15 minutes with the message "Too many attempts. Try again later." A successful sign-in SHALL reset the failed-attempt count of that client.

#### Scenario: Lockout after five failures
- **WHEN** a client fails to sign in 5 times within 15 minutes and then submits the correct password
- **THEN** the message "Too many attempts. Try again later." is shown and the bookings list is not shown

#### Scenario: Lockout ends
- **WHEN** 15 minutes have passed since the lockout started and the correct password is submitted
- **THEN** the bookings list is shown

### Requirement: Session cookie
The session SHALL be held in a cookie that is `HttpOnly` and `SameSite=Strict`, and that is `Secure` when the app is served over HTTPS. The session token SHALL be random and unguessable.

#### Scenario: Cookie attributes over HTTPS
- **WHEN** staff sign in on an HTTPS connection
- **THEN** the session cookie is set with `HttpOnly`, `SameSite=Strict` and `Secure`

#### Scenario: Cookie attributes over HTTP
- **WHEN** staff sign in over plain HTTP, for example on localhost
- **THEN** the session cookie is set with `HttpOnly` and `SameSite=Strict` and without `Secure`

### Requirement: Bookings list grouped by tasting
The bookings list SHALL show every booking grouped under its tasting, with each booking's name, email, number of guests and reference. A tasting with no bookings SHALL show "No bookings".

#### Scenario: Bookings grouped
- **WHEN** signed-in staff open the bookings list and two bookings exist for Riesling Evening and none for Winter Tasting
- **THEN** the Riesling Evening group lists both bookings with name, email, guests and reference, and the Winter Tasting group shows "No bookings"

#### Scenario: Bookings requested without sign-in
- **WHEN** a request for the bookings list arrives without a valid staff session
- **THEN** the request is refused and no booking data is returned

### Requirement: Cancel booking
Signed-in staff SHALL be able to cancel a booking with its "Cancel" button. A cancelled booking SHALL be removed from the list and its seats SHALL become available for new bookings. Cancelling without a valid staff session SHALL be refused.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 3 guests for Riesling Evening
- **THEN** the booking is removed from the list and Riesling Evening has 3 more seats left

#### Scenario: Cancel without sign-in
- **WHEN** a cancel request arrives without a valid staff session
- **THEN** the request is refused and the booking is kept
