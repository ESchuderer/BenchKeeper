# tasting-booking Specification

## Purpose
Lets a guest book seats on one tasting through a form that validates input, never exceeds the seats left, and confirms the booking with a reference. Covers the booking form, validation errors and the confirmation page.

## Requirements

### Requirement: Booking form fields
The booking form for a tasting SHALL have the fields "Name", "Email" and "Guests" (whole numbers 1 to 8) and a "Book" button.

#### Scenario: Form shown for an open tasting
- **WHEN** a guest opens the booking form of Winter Tasting while seats are left
- **THEN** the page shows the fields "Name", "Email" and "Guests" and a "Book" button

### Requirement: Input validation
The booking form SHALL reject invalid input and show an error message next to the field it concerns. A booking SHALL NOT be created while any field is invalid. Name SHALL be 1 to 100 characters after trimming spaces. Email SHALL be a syntactically valid email address. Guests SHALL be a whole number from 1 to 8.

#### Scenario: Empty name
- **WHEN** a guest submits the form with the Name field empty or only spaces
- **THEN** the error "Enter your name" is shown next to the Name field and no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits the form with the Email "guest at example"
- **THEN** the error "Enter a valid email address" is shown next to the Email field and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits the form with Guests set to 0 or 9
- **THEN** the error "Choose between 1 and 8 guests" is shown next to the Guests field and no booking is created

#### Scenario: Guests not a whole number
- **WHEN** a guest submits the form with Guests set to 2.5 or "two"
- **THEN** the error "Choose between 1 and 8 guests" is shown next to the Guests field and no booking is created

### Requirement: Seat capacity
A booking SHALL NOT take more seats than are left for its tasting. A booking whose guests exceed the seats left SHALL be rejected with an error next to the Guests field stating the number of seats left, and the seats left SHALL NOT change. With one seat left the error is "Only 1 seat left"; with no seats left it is "This tasting is fully booked".

#### Scenario: Booking within seats left
- **WHEN** 4 seats are left for Riesling Evening and a guest books 4 guests
- **THEN** the booking is created and no seats are left for Riesling Evening

#### Scenario: Booking more than seats left
- **WHEN** 2 seats are left for Riesling Evening and a guest books 3 guests
- **THEN** the error "Only 2 seats left" is shown next to the Guests field, no booking is created, and 2 seats are still left

#### Scenario: Last seats taken by another guest
- **WHEN** a guest submits 2 guests for a tasting, and between page load and submission another guest took enough seats that fewer than 2 remain
- **THEN** the submission is rejected with the seats-left error and no booking is created

### Requirement: Booking confirmation
A successful booking SHALL show the confirmation with the heading "Booking confirmed", the tasting title, the number of guests, the total price (price per guest multiplied by guests, shown as "EUR <amount>") and a booking reference. Each booking SHALL have a unique reference. The confirmation SHALL be reachable again at an address that contains the booking reference.

#### Scenario: Confirmation shown
- **WHEN** a guest books 2 guests for Red Wine Cellar Tour
- **THEN** the page shows the heading "Booking confirmed", "Red Wine Cellar Tour", "2 guests", "EUR 64" as the total, and a booking reference

#### Scenario: Confirmation reloaded
- **WHEN** a guest reloads the confirmation page of a booking
- **THEN** the same tasting, guests, total and reference are shown

#### Scenario: Unknown booking reference
- **WHEN** a guest opens the confirmation address with a reference that does not exist
- **THEN** a "Booking not found" message is shown

### Requirement: Unknown tasting
A booking form address for a tasting that does not exist SHALL show a "Tasting not found" message and no booking fields.

#### Scenario: Unknown tasting address
- **WHEN** a guest opens the booking form of a tasting id that does not exist
- **THEN** the page shows "Tasting not found" and no booking fields
