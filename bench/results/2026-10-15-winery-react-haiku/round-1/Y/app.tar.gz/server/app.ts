import cookieParser from 'cookie-parser'
import express, { type NextFunction, type Request, type Response } from 'express'
import type { ZodError } from 'zod'
import { bookingSchema } from '../shared/booking'
import { findTasting, tastings, type Tasting } from '../shared/tastings'
import { createStaffAuth } from './staff'
import { createStore, type Booking } from './store'

const SESSION_COOKIE = 'staff_session'
const SESSION_COOKIE_OPTIONS = { httpOnly: true, sameSite: 'strict', path: '/' } as const

type AppOptions = {
  env?: Record<string, string | undefined>
  now?: () => number
  // Set only behind a reverse proxy that terminates TLS, so req.ip and req.secure come from the proxy headers
  trustProxy?: boolean
}

function tastingView(tasting: Tasting, seatsLeft: number) {
  return {
    id: tasting.id,
    title: tasting.title,
    startsAt: tasting.startsAt,
    pricePerGuest: tasting.pricePerGuest,
    seats: tasting.seats,
    seatsLeft,
  }
}

function bookingSummary(booking: Booking, tasting: Tasting) {
  return {
    reference: booking.reference,
    tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt },
    guests: booking.guests,
    total: tasting.pricePerGuest * booking.guests,
  }
}

function fieldErrors(error: ZodError): Record<string, string> {
  const errors: Record<string, string> = {}
  for (const issue of error.issues) {
    errors[String(issue.path[0])] ??= issue.message
  }
  return errors
}

function seatsLeftMessage(seatsLeft: number): string {
  if (seatsLeft === 0) return 'This tasting is fully booked'
  return `Only ${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left`
}

export function createApp({ env = process.env, now = Date.now, trustProxy = false }: AppOptions = {}) {
  const store = createStore()
  const staff = createStaffAuth(env.STAFF_PASSWORD, now)
  const app = express()
  app.set('trust proxy', trustProxy)
  app.use(express.json())
  app.use(cookieParser())

  const requireStaff = <P extends object>(req: Request<P>, res: Response, next: NextFunction) => {
    if (staff.isSignedIn(req.cookies[SESSION_COOKIE])) return next()
    res.status(401).json({ error: 'Not signed in' })
  }

  app.get('/api/tastings', (_req, res) => {
    res.json(tastings.map((tasting) => tastingView(tasting, store.seatsLeft(tasting))))
  })

  app.get('/api/tastings/:id', (req, res) => {
    const tasting = findTasting(req.params.id)
    if (!tasting) return res.status(404).json({ error: 'Tasting not found' })
    res.json(tastingView(tasting, store.seatsLeft(tasting)))
  })

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const tasting = findTasting(req.params.id)
    if (!tasting) return res.status(404).json({ error: 'Tasting not found' })

    const input = bookingSchema.safeParse(req.body)
    if (!input.success) return res.status(400).json({ errors: fieldErrors(input.error) })

    const result = store.book(tasting, input.data)
    if ('seatsLeft' in result) {
      return res.status(409).json({ errors: { guests: seatsLeftMessage(result.seatsLeft) } })
    }
    res.status(201).json(bookingSummary(result.booking, tasting))
  })

  app.get('/api/bookings/:reference', (req, res) => {
    const booking = store.get(req.params.reference)
    const tasting = booking && findTasting(booking.tastingId)
    if (!booking || !tasting) return res.status(404).json({ error: 'Booking not found' })
    res.json(bookingSummary(booking, tasting))
  })

  app.post('/api/staff/session', (req, res) => {
    const result = staff.signIn(req.ip ?? '', req.body?.password)
    if ('locked' in result) return res.status(429).json({ error: 'Too many attempts. Try again later.' })
    if ('wrong' in result) return res.status(401).json({ error: 'Wrong password' })
    res.cookie(SESSION_COOKIE, result.token, {
      ...SESSION_COOKIE_OPTIONS,
      secure: req.secure,
      maxAge: staff.sessionMaxAgeMs,
    })
    res.status(204).end()
  })

  app.get('/api/staff/session', requireStaff, (_req, res) => {
    res.status(204).end()
  })

  app.delete('/api/staff/session', (req, res) => {
    staff.signOut(req.cookies[SESSION_COOKIE])
    res.clearCookie(SESSION_COOKIE, { ...SESSION_COOKIE_OPTIONS, secure: req.secure })
    res.status(204).end()
  })

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    const bookings = store.all()
    res.json(
      tastings.map((tasting) => ({
        tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt },
        bookings: bookings
          .filter((booking) => booking.tastingId === tasting.id)
          .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
      })),
    )
  })

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.remove(req.params.reference)) return res.status(404).json({ error: 'Booking not found' })
    res.status(204).end()
  })

  return app
}
