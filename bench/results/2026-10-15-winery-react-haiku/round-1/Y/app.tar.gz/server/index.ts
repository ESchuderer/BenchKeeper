import path from 'node:path'
import { fileURLToPath } from 'node:url'
import express from 'express'
import { createApp } from './app'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const clientDir = path.join(root, 'dist/client')
const port = Number(process.env.PORT ?? 3000)

const app = createApp()

if (!process.env.STAFF_PASSWORD) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled')
}

app.use(express.static(clientDir))
app.use((req, res, next) => {
  if (req.method !== 'GET' || req.path.startsWith('/api/') || path.extname(req.path)) return next()
  res.sendFile(path.join(clientDir, 'index.html'))
})

app.listen(port, () => {
  console.log(`Listening on http://localhost:${port}`)
})
