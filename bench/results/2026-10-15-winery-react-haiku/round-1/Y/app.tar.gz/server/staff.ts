import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'

const SESSION_MS = 8 * 60 * 60 * 1000
const FAILURE_WINDOW_MS = 15 * 60 * 1000
const MAX_FAILURES = 5

type Failures = { count: number; windowEnd: number; lockedUntil: number }

export type SignInResult = { token: string } | { wrong: true } | { locked: true }

// shortcut: sessions and failure counts are held in memory and reset on restart, fine for a single server process
export function createStaffAuth(password: string | undefined, now: () => number) {
  const sessions = new Map<string, number>()
  const failures = new Map<string, Failures>()

  function matches(candidate: unknown): boolean {
    if (!password || typeof candidate !== 'string') return false
    const hash = (value: string) => createHash('sha256').update(value).digest()
    return timingSafeEqual(hash(candidate), hash(password))
  }

  function prune(time: number) {
    for (const [token, expiresAt] of sessions) {
      if (expiresAt <= time) sessions.delete(token)
    }
    for (const [ip, entry] of failures) {
      if (entry.windowEnd <= time && entry.lockedUntil <= time) failures.delete(ip)
    }
  }

  return {
    signIn(ip: string, candidate: unknown): SignInResult {
      const time = now()
      prune(time)

      const entry = failures.get(ip)
      if (entry && entry.lockedUntil > time) return { locked: true }

      if (matches(candidate)) {
        failures.delete(ip)
        const token = randomBytes(32).toString('base64url')
        sessions.set(token, time + SESSION_MS)
        return { token }
      }

      const current = entry && entry.windowEnd > time ? entry : { count: 0, windowEnd: time + FAILURE_WINDOW_MS, lockedUntil: 0 }
      current.count++
      if (current.count >= MAX_FAILURES) current.lockedUntil = time + FAILURE_WINDOW_MS
      failures.set(ip, current)
      return { wrong: true }
    },

    isSignedIn(token: unknown): boolean {
      if (typeof token !== 'string') return false
      const expiresAt = sessions.get(token)
      if (expiresAt === undefined) return false
      if (expiresAt <= now()) {
        sessions.delete(token)
        return false
      }
      return true
    },

    signOut(token: unknown) {
      if (typeof token === 'string') sessions.delete(token)
    },

    sessionMaxAgeMs: SESSION_MS,
  }
}
