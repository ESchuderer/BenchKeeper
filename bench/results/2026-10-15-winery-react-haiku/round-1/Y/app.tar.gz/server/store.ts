import { randomInt } from 'node:crypto'
import type { Tasting } from '../shared/tastings'

export type Booking = {
  reference: string
  tastingId: string
  name: string
  email: string
  guests: number
}

export type BookInput = Omit<Booking, 'reference' | 'tastingId'>

export type BookResult = { booking: Booking } | { seatsLeft: number }

// Without the letters O and I, and without the digits 0 and 1
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

// shortcut: bookings are held in memory and lost on restart, move to a file or SQLite before real use
export function createStore() {
  const bookings = new Map<string, Booking>()

  function seatsLeft(tasting: Tasting): number {
    let taken = 0
    for (const booking of bookings.values()) {
      if (booking.tastingId === tasting.id) taken += booking.guests
    }
    return tasting.seats - taken
  }

  function newReference(): string {
    let reference: string
    do {
      const suffix = Array.from({ length: 6 }, () => REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)])
      reference = `KB-${suffix.join('')}`
    } while (bookings.has(reference))
    return reference
  }

  return {
    seatsLeft,

    // Check and insert in one synchronous call, so concurrent requests cannot oversell
    book(tasting: Tasting, input: BookInput): BookResult {
      const left = seatsLeft(tasting)
      if (input.guests > left) return { seatsLeft: left }
      const booking = { ...input, reference: newReference(), tastingId: tasting.id }
      bookings.set(booking.reference, booking)
      return { booking }
    },

    get(reference: string): Booking | undefined {
      return bookings.get(reference)
    },

    all(): Booking[] {
      return [...bookings.values()]
    },

    remove(reference: string): boolean {
      return bookings.delete(reference)
    },
  }
}
