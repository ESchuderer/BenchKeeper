import { z } from 'zod'

export const MAX_GUESTS = 8

const GUESTS_ERROR = `Choose between 1 and ${MAX_GUESTS} guests`

export const bookingSchema = z.object({
  name: z
    .string({ required_error: 'Enter your name' })
    .trim()
    .min(1, 'Enter your name')
    .max(100, 'Name must be 100 characters or fewer'),
  email: z
    .string({ required_error: 'Enter a valid email address' })
    .trim()
    .email('Enter a valid email address'),
  guests: z
    .number({ required_error: GUESTS_ERROR, invalid_type_error: GUESTS_ERROR })
    .int(GUESTS_ERROR)
    .min(1, GUESTS_ERROR)
    .max(MAX_GUESTS, GUESTS_ERROR),
})

export type BookingInput = z.input<typeof bookingSchema>
export type BookingData = z.output<typeof bookingSchema>
