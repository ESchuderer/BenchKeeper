export type Tasting = {
  id: string
  title: string
  // Local winery time, no time zone: "YYYY-MM-DDTHH:mm"
  startsAt: string
  pricePerGuest: number
  seats: number
}

export const tastings: Tasting[] = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06T18:00',
    pricePerGuest: 25,
    seats: 12,
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    startsAt: '2026-11-14T15:00',
    pricePerGuest: 32,
    seats: 8,
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    startsAt: '2026-12-05T17:00',
    pricePerGuest: 28,
    seats: 10,
  },
]

const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
]

export function findTasting(id: string): Tasting | undefined {
  return tastings.find((tasting) => tasting.id === id)
}

// Parsed by hand so the output does not depend on the runtime's time zone or ICU data
export function formatStart(startsAt: string): string {
  const [date, time] = startsAt.split('T')
  const [year, month, day] = date.split('-').map(Number)
  return `${day} ${MONTHS[month - 1]} ${year}, ${time}`
}

export function formatPrice(euros: number): string {
  return `EUR ${euros}`
}

export function formatSeatsLeft(seatsLeft: number): string {
  if (seatsLeft === 0) return 'Fully booked'
  return seatsLeft === 1 ? '1 seat left' : `${seatsLeft} seats left`
}
