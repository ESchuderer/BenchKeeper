import { BrowserRouter, Link, Route, Routes } from 'react-router'
import { BookingPage } from './pages/BookingPage'
import { ConfirmationPage } from './pages/ConfirmationPage'
import { StaffPage } from './pages/StaffPage'
import { StartPage } from './pages/StartPage'

export function App() {
  return (
    <BrowserRouter>
      <header className="bg-wine-dark text-paper">
        <div className="mx-auto max-w-5xl px-4 py-5">
          <Link to="/" className="font-serif text-2xl tracking-wide">
            Weingut Kieselbrunnen
          </Link>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-10">
        <Routes>
          <Route path="/" element={<StartPage />} />
          <Route path="/tastings/:id" element={<BookingPage />} />
          <Route path="/bookings/:reference" element={<ConfirmationPage />} />
          <Route path="/staff" element={<StaffPage />} />
          <Route path="*" element={<h1 className="page-title">Page not found</h1>} />
        </Routes>
      </main>
    </BrowserRouter>
  )
}
