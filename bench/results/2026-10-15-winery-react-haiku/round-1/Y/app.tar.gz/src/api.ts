export type TastingView = {
  id: string
  title: string
  startsAt: string
  pricePerGuest: number
  seats: number
  seatsLeft: number
}

export type TastingRef = Pick<TastingView, 'id' | 'title' | 'startsAt'>

export type BookingSummary = {
  reference: string
  tasting: TastingRef
  guests: number
  total: number
}

export type StaffBookingGroup = {
  tasting: TastingRef
  bookings: { reference: string; name: string; email: string; guests: number }[]
}

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly body: { error?: string; errors?: Record<string, string> },
  ) {
    super(`Request failed with status ${status}`)
  }
}

async function call<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(path, {
    method,
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  if (res.status === 204) return undefined as T
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new ApiError(res.status, data)
  return data as T
}

export const api = {
  tastings: () => call<TastingView[]>('GET', '/api/tastings'),
  tasting: (id: string) => call<TastingView>('GET', `/api/tastings/${id}`),
  book: (id: string, input: { name: string; email: string; guests: number }) =>
    call<BookingSummary>('POST', `/api/tastings/${id}/bookings`, input),
  booking: (reference: string) => call<BookingSummary>('GET', `/api/bookings/${reference}`),
  staffSignedIn: () => call<void>('GET', '/api/staff/session'),
  staffSignIn: (password: string) => call<void>('POST', '/api/staff/session', { password }),
  staffSignOut: () => call<void>('DELETE', '/api/staff/session'),
  staffBookings: () => call<StaffBookingGroup[]>('GET', '/api/staff/bookings'),
  cancelBooking: (reference: string) => call<void>('DELETE', `/api/staff/bookings/${reference}`),
}
