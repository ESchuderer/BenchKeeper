import { useEffect, useState } from 'react'
import { useForm, useWatch } from 'react-hook-form'
import { Link, useNavigate, useParams } from 'react-router'
import { zodResolver } from '@hookform/resolvers/zod'
import { api, ApiError, type TastingView } from '../api'
import { bookingSchema, MAX_GUESTS, type BookingInput } from '../../shared/booking'
import { formatPrice, formatSeatsLeft, formatStart } from '../../shared/tastings'

// Each result carries the id it was loaded for, so a route change shows loading instead of the old tasting
type Result = { id: string; tasting: TastingView } | { id: string; failure: 'missing' | 'failed' }

export function BookingPage() {
  const { id = '' } = useParams()
  const [result, setResult] = useState<Result>()

  useEffect(() => {
    api.tasting(id).then(
      (tasting) => setResult({ id, tasting }),
      (error) => setResult({ id, failure: error instanceof ApiError && error.status === 404 ? 'missing' : 'failed' }),
    )
  }, [id])

  if (result?.id !== id) return <p className="text-muted">Loading…</p>
  if ('failure' in result) {
    return result.failure === 'missing' ? (
      <p role="alert" className="notice notice-error">Tasting not found.</p>
    ) : (
      <p role="alert" className="notice notice-error">Could not load this tasting. Try again later.</p>
    )
  }

  const { tasting } = result
  return (
    <section className="grid gap-8 md:grid-cols-[1fr_1.2fr]">
      <div>
        <h1 className="page-title">{tasting.title}</h1>
        <p className="text-muted">{formatStart(tasting.startsAt)}</p>
        <p className="mt-2">
          {formatPrice(tasting.pricePerGuest)} per guest · {formatSeatsLeft(tasting.seatsLeft)}
        </p>
        <Link to="/" className="mt-6 inline-block text-wine underline">
          Back to all tastings
        </Link>
      </div>
      {tasting.seatsLeft === 0 ? (
        <p role="status" className="notice notice-warning self-start">
          Fully booked. There are no seats left for this tasting.
        </p>
      ) : (
        <BookingForm tasting={tasting} />
      )}
    </section>
  )
}

function BookingForm({ tasting }: { tasting: TastingView }) {
  const navigate = useNavigate()
  const {
    control,
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  })

  const guests = useWatch({ control, name: 'guests' })
  const total = Number.isInteger(guests) ? tasting.pricePerGuest * guests : undefined

  async function onSubmit(values: BookingInput) {
    try {
      const booking = await api.book(tasting.id, { name: values.name, email: values.email, guests: values.guests })
      navigate(`/bookings/${booking.reference}`)
    } catch (error) {
      if (error instanceof ApiError && error.body.errors) {
        for (const [field, message] of Object.entries(error.body.errors)) {
          setError(field as keyof BookingInput, { message })
        }
      } else {
        setError('root', { message: 'Something went wrong. Try again.' })
      }
    }
  }

  const describedBy = (field: keyof BookingInput) => (errors[field] ? `${field}-error` : undefined)

  return (
    <form noValidate onSubmit={handleSubmit(onSubmit)} className="card space-y-5 self-start">
      {errors.root && (
        <p role="alert" className="notice notice-error">
          {errors.root.message}
        </p>
      )}

      <div className="field">
        <label htmlFor="name">Name</label>
        <input
          id="name"
          autoComplete="name"
          aria-invalid={!!errors.name}
          aria-describedby={describedBy('name')}
          {...register('name')}
        />
        {errors.name && <p id="name-error" role="alert" className="field-error">{errors.name.message}</p>}
      </div>

      <div className="field">
        <label htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          autoComplete="email"
          aria-invalid={!!errors.email}
          aria-describedby={describedBy('email')}
          {...register('email')}
        />
        {errors.email && <p id="email-error" role="alert" className="field-error">{errors.email.message}</p>}
      </div>

      <div className="field">
        <label htmlFor="guests">Guests</label>
        <input
          id="guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={MAX_GUESTS}
          step={1}
          aria-invalid={!!errors.guests}
          aria-describedby={describedBy('guests')}
          {...register('guests', { valueAsNumber: true })}
        />
        {errors.guests && <p id="guests-error" role="alert" className="field-error">{errors.guests.message}</p>}
      </div>

      <p className="flex justify-between border-t border-gold/40 pt-4">
        <span>Total</span>
        <span className="font-serif text-xl">{total === undefined ? '—' : formatPrice(total)}</span>
      </p>

      <button type="submit" disabled={isSubmitting} className="button-primary w-full">
        Book
      </button>
    </form>
  )
}
