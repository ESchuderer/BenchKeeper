import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router'
import { api, ApiError, type BookingSummary } from '../api'
import { formatPrice, formatStart } from '../../shared/tastings'

// Each result carries the reference it was loaded for, so a route change shows loading instead of the old booking
type Result = { reference: string; booking: BookingSummary } | { reference: string; failure: 'missing' | 'failed' }

export function ConfirmationPage() {
  const { reference = '' } = useParams()
  const [result, setResult] = useState<Result>()

  useEffect(() => {
    api.booking(reference).then(
      (booking) => setResult({ reference, booking }),
      (error) => setResult({ reference, failure: error instanceof ApiError && error.status === 404 ? 'missing' : 'failed' }),
    )
  }, [reference])

  if (result?.reference !== reference) return <p className="text-muted">Loading…</p>
  if ('failure' in result) {
    return result.failure === 'missing' ? (
      <h1 className="page-title">Booking not found</h1>
    ) : (
      <p role="alert" className="notice notice-error">Could not load this booking. Try again later.</p>
    )
  }

  const { booking } = result
  return (
    <section className="mx-auto max-w-xl">
      <div className="notice notice-success">
        <h1 className="font-serif text-3xl">Booking confirmed</h1>
        <p className="mt-2">Please keep your booking reference for the day of the tasting.</p>
      </div>
      <dl className="card mt-6 grid grid-cols-[auto_1fr] gap-x-6 gap-y-3">
        <dt className="text-muted">Tasting</dt>
        <dd>{booking.tasting.title}</dd>
        <dt className="text-muted">When</dt>
        <dd>{formatStart(booking.tasting.startsAt)}</dd>
        <dt className="text-muted">Guests</dt>
        <dd>{booking.guests === 1 ? '1 guest' : `${booking.guests} guests`}</dd>
        <dt className="text-muted">Total</dt>
        <dd>{formatPrice(booking.total)}</dd>
        <dt className="text-muted">Reference</dt>
        <dd className="font-mono text-lg tracking-wider">{booking.reference}</dd>
      </dl>
      <Link to="/" className="mt-6 inline-block text-wine underline">
        Back to all tastings
      </Link>
    </section>
  )
}
