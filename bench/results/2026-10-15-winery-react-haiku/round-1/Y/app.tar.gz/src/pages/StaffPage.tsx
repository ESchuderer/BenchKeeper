import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { api, ApiError, type StaffBookingGroup } from '../api'
import { formatStart } from '../../shared/tastings'

export function StaffPage() {
  const [signedIn, setSignedIn] = useState<boolean>()

  useEffect(() => {
    api.staffSignedIn().then(
      () => setSignedIn(true),
      () => setSignedIn(false),
    )
  }, [])

  if (signedIn === undefined) return <p className="text-muted">Loading…</p>
  if (!signedIn) return <SignInForm onSignedIn={() => setSignedIn(true)} />
  return <Bookings onSignedOut={() => setSignedIn(false)} />
}

function SignInForm({ onSignedIn }: { onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } })

  async function onSubmit({ password }: { password: string }) {
    try {
      await api.staffSignIn(password)
      onSignedIn()
    } catch (error) {
      const message = error instanceof ApiError && error.body.error ? error.body.error : 'Could not sign in. Try again.'
      setError('password', { message })
    }
  }

  return (
    <section className="mx-auto max-w-sm">
      <h1 className="page-title">Staff sign in</h1>
      <form noValidate onSubmit={handleSubmit(onSubmit)} className="card space-y-5">
        <div className="field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            aria-invalid={!!errors.password}
            aria-describedby={errors.password ? 'password-error' : undefined}
            {...register('password')}
          />
          {errors.password && (
            <p id="password-error" role="alert" className="field-error">
              {errors.password.message}
            </p>
          )}
        </div>
        <button type="submit" disabled={isSubmitting} className="button-primary w-full">
          Sign in
        </button>
      </form>
    </section>
  )
}

function Bookings({ onSignedOut }: { onSignedOut: () => void }) {
  const [groups, setGroups] = useState<StaffBookingGroup[]>()
  const [version, setVersion] = useState(0)
  const [message, setMessage] = useState<string>()

  // A 401 means the session has ended, so return to sign-in
  useEffect(() => {
    api.staffBookings().then(setGroups, (error) => {
      if (error instanceof ApiError && error.status === 401) return onSignedOut()
      setMessage('Could not load bookings. Try again later.')
    })
  }, [version, onSignedOut])

  async function cancel(reference: string) {
    setMessage(undefined)
    try {
      await api.cancelBooking(reference)
      setVersion((v) => v + 1)
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) return onSignedOut()
      setMessage('Could not cancel the booking. Try again.')
    }
  }

  async function signOut() {
    await api.staffSignOut()
    onSignedOut()
  }

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="page-title">Bookings</h1>
        <button type="button" onClick={signOut} className="button-secondary">
          Sign out
        </button>
      </div>

      {message && (
        <p role="alert" className="notice notice-error mb-6">
          {message}
        </p>
      )}

      {!groups && !message && <p className="text-muted">Loading…</p>}

      {groups?.map((group) => (
        <div key={group.tasting.id} className="card mb-6">
          <h2 className="card-title">
            {group.tasting.title} <span className="text-base font-normal text-muted">{formatStart(group.tasting.startsAt)}</span>
          </h2>
          {group.bookings.length === 0 ? (
            <p className="mt-3 text-muted">No bookings</p>
          ) : (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-gold/40 text-muted">
                  <tr>
                    <th className="py-2 pr-4 font-normal">Name</th>
                    <th className="py-2 pr-4 font-normal">Email</th>
                    <th className="py-2 pr-4 font-normal">Guests</th>
                    <th className="py-2 pr-4 font-normal">Reference</th>
                    <th className="py-2 font-normal"><span className="sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody>
                  {group.bookings.map((booking) => (
                    <tr key={booking.reference} className="border-b border-gold/20">
                      <td className="py-2 pr-4">{booking.name}</td>
                      <td className="py-2 pr-4">{booking.email}</td>
                      <td className="py-2 pr-4">{booking.guests}</td>
                      <td className="py-2 pr-4 font-mono">{booking.reference}</td>
                      <td className="py-2 text-right">
                        <button type="button" onClick={() => cancel(booking.reference)} className="button-danger">
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ))}
    </section>
  )
}
