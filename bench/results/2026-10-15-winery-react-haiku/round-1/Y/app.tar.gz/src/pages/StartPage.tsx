import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import { api, type TastingView } from '../api'
import { formatPrice, formatSeatsLeft, formatStart } from '../../shared/tastings'

export function StartPage() {
  const [tastings, setTastings] = useState<TastingView[]>()
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    api.tastings().then(setTastings, () => setFailed(true))
  }, [])

  if (failed) return <p role="alert" className="notice notice-error">Could not load the tastings. Try again later.</p>
  if (!tastings) return <p className="text-muted">Loading tastings…</p>

  return (
    <section>
      <h1 className="page-title">Wine tastings</h1>
      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {tastings.map((tasting) => (
          <li key={tasting.id} className="card">
            <h2 className="card-title">{tasting.title}</h2>
            <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
              <dt className="text-muted">When</dt>
              <dd>{formatStart(tasting.startsAt)}</dd>
              <dt className="text-muted">Price</dt>
              <dd>{formatPrice(tasting.pricePerGuest)} per guest</dd>
              <dt className="text-muted">Seats</dt>
              <dd className={tasting.seatsLeft === 0 ? 'font-semibold text-danger' : ''}>
                {formatSeatsLeft(tasting.seatsLeft)}
              </dd>
            </dl>
            <Link to={`/tastings/${tasting.id}`} className="button-primary mt-6">
              {`Book ${tasting.title}`}
            </Link>
          </li>
        ))}
      </ul>
    </section>
  )
}
