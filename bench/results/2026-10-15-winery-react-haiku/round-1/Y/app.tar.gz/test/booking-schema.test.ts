import { describe, expect, it } from 'vitest'
import { bookingSchema } from '../shared/booking'
import { formatPrice, formatStart, tastings } from '../shared/tastings'

const valid = { name: 'Anna Berg', email: 'anna@example.com', guests: 2 }

function errorFor(input: unknown, field: string) {
  const result = bookingSchema.safeParse(input)
  if (result.success) return undefined
  return result.error.issues.find((issue) => issue.path[0] === field)?.message
}

describe('bookingSchema', () => {
  it('accepts a valid booking', () => {
    expect(bookingSchema.safeParse(valid).success).toBe(true)
  })

  it.each(['', '   '])('rejects the name %j', (name) => {
    expect(errorFor({ ...valid, name }, 'name')).toBe('Enter your name')
  })

  it('accepts a name of 100 characters and rejects 101', () => {
    expect(errorFor({ ...valid, name: 'a'.repeat(100) }, 'name')).toBeUndefined()
    expect(errorFor({ ...valid, name: 'a'.repeat(101) }, 'name')).toBe(
      'Name must be 100 characters or fewer',
    )
  })

  it.each(['guest at example', 'guest@', ''])('rejects the email %j', (email) => {
    expect(errorFor({ ...valid, email }, 'email')).toBe('Enter a valid email address')
  })

  it.each([0, 9, 2.5, Number.NaN, 'two'])('rejects guests %p', (guests) => {
    expect(errorFor({ ...valid, guests }, 'guests')).toBe('Choose between 1 and 8 guests')
  })

  it('accepts 1 and 8 guests', () => {
    expect(errorFor({ ...valid, guests: 1 }, 'guests')).toBeUndefined()
    expect(errorFor({ ...valid, guests: 8 }, 'guests')).toBeUndefined()
  })
})

describe('tasting formatting', () => {
  it('formats the start of the first tasting in local winery time', () => {
    expect(formatStart(tastings[0].startsAt)).toBe('6 November 2026, 18:00')
  })

  it('formats prices in EUR', () => {
    expect(formatPrice(25)).toBe('EUR 25')
  })
})
