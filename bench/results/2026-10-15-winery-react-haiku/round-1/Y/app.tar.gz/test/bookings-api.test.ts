import request from 'supertest'
import { describe, expect, it } from 'vitest'
import { createApp } from '../server/app'

const guest = { name: 'Anna Berg', email: 'anna@example.com' }

function seatsLeft(app: ReturnType<typeof createApp>, id: string) {
  return request(app)
    .get('/api/tastings')
    .then((res) => res.body.find((t: { id: string }) => t.id === id).seatsLeft)
}

describe('GET /api/tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const app = createApp()
    const res = await request(app).get('/api/tastings')

    expect(res.status).toBe(200)
    expect(res.body).toEqual([
      expect.objectContaining({ id: 'riesling-evening', pricePerGuest: 25, seats: 12, seatsLeft: 12 }),
      expect.objectContaining({ id: 'red-wine-cellar-tour', pricePerGuest: 32, seats: 8, seatsLeft: 8 }),
      expect.objectContaining({ id: 'winter-tasting', pricePerGuest: 28, seats: 10, seatsLeft: 10 }),
    ])
  })

  it('returns 404 for an unknown tasting', async () => {
    const res = await request(createApp()).get('/api/tastings/unknown')
    expect(res.status).toBe(404)
  })
})

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking, returns the summary and reduces seats left', async () => {
    const app = createApp()
    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 2 })

    expect(res.status).toBe(201)
    expect(res.body).toEqual({
      reference: expect.stringMatching(/^KB-[A-HJ-NP-Z2-9]{6}$/),
      tasting: { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00' },
      guests: 2,
      total: 64,
    })
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(6)
  })

  it('gives each booking its own reference', async () => {
    const app = createApp()
    const first = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 1 })
    const second = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 1 })

    expect(first.body.reference).not.toBe(second.body.reference)
  })

  it('rejects a booking above the seats left and leaves seats unchanged', async () => {
    const app = createApp()
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 6 })

    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 3 })

    expect(res.status).toBe(409)
    expect(res.body).toEqual({ errors: { guests: 'Only 2 seats left' } })
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(2)
  })

  it('uses the singular for one seat left', async () => {
    const app = createApp()
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 7 })

    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 2 })

    expect(res.body).toEqual({ errors: { guests: 'Only 1 seat left' } })
  })

  it('rejects a booking to a fully booked tasting', async () => {
    const app = createApp()
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 8 })

    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 1 })

    expect(res.status).toBe(409)
    expect(res.body).toEqual({ errors: { guests: 'This tasting is fully booked' } })
  })

  it('returns a field error for each invalid field', async () => {
    const res = await request(createApp())
      .post('/api/tastings/winter-tasting/bookings')
      .send({ name: ' ', email: 'anna at example', guests: 9 })

    expect(res.status).toBe(400)
    expect(res.body).toEqual({
      errors: {
        name: 'Enter your name',
        email: 'Enter a valid email address',
        guests: 'Choose between 1 and 8 guests',
      },
    })
  })

  it('returns 404 for an unknown tasting', async () => {
    const res = await request(createApp()).post('/api/tastings/unknown/bookings').send({ ...guest, guests: 1 })
    expect(res.status).toBe(404)
  })
})

describe('GET /api/bookings/:reference', () => {
  it('returns tasting, guests and total without the guest name or email', async () => {
    const app = createApp()
    const created = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 2 })

    const res = await request(app).get(`/api/bookings/${created.body.reference}`)

    expect(res.status).toBe(200)
    expect(res.body).toEqual(created.body)
    expect(res.body).not.toHaveProperty('name')
    expect(res.body).not.toHaveProperty('email')
  })

  it('returns 404 for an unknown reference', async () => {
    const res = await request(createApp()).get('/api/bookings/KB-AAAAAA')
    expect(res.status).toBe(404)
  })
})
