import request from 'supertest'
import { describe, expect, it } from 'vitest'
import { createApp } from '../server/app'

const PASSWORD = 'correct-horse'
const guest = { name: 'Anna Berg', email: 'anna@example.com' }

async function setup() {
  const app = createApp({ env: { STAFF_PASSWORD: PASSWORD } })
  const signIn = await request(app).post('/api/staff/session').send({ password: PASSWORD })
  const cookie = signIn.headers['set-cookie'][0].split(';')[0]
  return { app, cookie }
}

describe('GET /api/staff/bookings', () => {
  it('returns 401 and no booking data without a session', async () => {
    const app = createApp({ env: { STAFF_PASSWORD: PASSWORD } })
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 2 })

    const res = await request(app).get('/api/staff/bookings')

    expect(res.status).toBe(401)
    expect(res.body).not.toHaveProperty('0')
  })

  it('groups bookings by tasting in catalogue order, with empty groups', async () => {
    const { app, cookie } = await setup()
    const first = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guest, guests: 3 })
    await request(app).post('/api/tastings/riesling-evening/bookings').send({ name: 'Ben', email: 'ben@example.com', guests: 1 })

    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie)

    expect(res.status).toBe(200)
    expect(res.body).toHaveLength(3)
    expect(res.body[0]).toEqual({
      tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00' },
      bookings: [
        { reference: first.body.reference, name: 'Anna Berg', email: 'anna@example.com', guests: 3 },
        { reference: expect.any(String), name: 'Ben', email: 'ben@example.com', guests: 1 },
      ],
    })
    expect(res.body[1].bookings).toEqual([])
    expect(res.body[2].bookings).toEqual([])
  })
})

describe('DELETE /api/staff/bookings/:reference', () => {
  it('refuses without a session and keeps the booking', async () => {
    const { app } = await setup()
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 2 })

    const res = await request(app).delete(`/api/staff/bookings/${created.body.reference}`)

    expect(res.status).toBe(401)
    expect((await request(app).get(`/api/bookings/${created.body.reference}`)).status).toBe(200)
  })

  it('cancels the booking and frees its seats', async () => {
    const { app, cookie } = await setup()
    const created = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guest, guests: 3 })
    expect((await request(app).get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(9)

    const res = await request(app)
      .delete(`/api/staff/bookings/${created.body.reference}`)
      .set('Cookie', cookie)

    expect(res.status).toBe(204)
    expect((await request(app).get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(12)
    expect((await request(app).get(`/api/bookings/${created.body.reference}`)).status).toBe(404)
    const list = await request(app).get('/api/staff/bookings').set('Cookie', cookie)
    expect(list.body[0].bookings).toEqual([])
  })

  it('returns 404 for an unknown reference', async () => {
    const { app, cookie } = await setup()
    const res = await request(app).delete('/api/staff/bookings/KB-AAAAAA').set('Cookie', cookie)
    expect(res.status).toBe(404)
  })
})
