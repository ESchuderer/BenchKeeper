import request from 'supertest'
import { describe, expect, it } from 'vitest'
import { createApp } from '../server/app'

const MINUTE = 60_000
const HOUR = 60 * MINUTE
const PASSWORD = 'correct-horse'

function setup(options: { env?: Record<string, string | undefined>; trustProxy?: boolean } = {}) {
  let now = 0
  const app = createApp({ env: { STAFF_PASSWORD: PASSWORD }, now: () => now, ...options })
  return { app, advance: (ms: number) => (now += ms) }
}

function signIn(app: ReturnType<typeof createApp>, password = PASSWORD) {
  return request(app).post('/api/staff/session').send({ password })
}

function sessionCookie(res: request.Response): string {
  return res.headers['set-cookie'][0].split(';')[0]
}

describe('POST /api/staff/session', () => {
  it('signs in with the configured password and sets an HttpOnly session cookie', async () => {
    const { app } = setup()
    const res = await signIn(app)

    expect(res.status).toBe(204)
    const header = res.headers['set-cookie'][0]
    expect(header).toMatch(/^staff_session=[A-Za-z0-9_-]{40,};/)
    expect(header).toContain('HttpOnly')
    expect(header).toContain('SameSite=Strict')
    expect(header).toContain('Path=/')
    expect(header).not.toContain('Secure')
  })

  it('sets Secure on the cookie when the request is HTTPS', async () => {
    const { app } = setup({ trustProxy: true })
    const res = await request(app)
      .post('/api/staff/session')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD })

    expect(res.headers['set-cookie'][0]).toContain('Secure')
  })

  it('rejects a wrong password with 401 and sets no cookie', async () => {
    const { app } = setup()
    const res = await signIn(app, 'wrong')

    expect(res.status).toBe(401)
    expect(res.body).toEqual({ error: 'Wrong password' })
    expect(res.headers['set-cookie']).toBeUndefined()
  })

  it('rejects every password when STAFF_PASSWORD is not set', async () => {
    const { app } = setup({ env: {} })

    expect((await signIn(app, PASSWORD)).status).toBe(401)
    expect((await signIn(app, '')).status).toBe(401)
  })

  it('locks sign-in for 15 minutes after five failed attempts', async () => {
    const { app, advance } = setup()
    for (let i = 0; i < 5; i++) expect((await signIn(app, 'wrong')).status).toBe(401)

    const locked = await signIn(app)
    expect(locked.status).toBe(429)
    expect(locked.body).toEqual({ error: 'Too many attempts. Try again later.' })

    advance(15 * MINUTE)
    expect((await signIn(app)).status).toBe(204)
  })

  it('resets the failure count after a successful sign-in', async () => {
    const { app } = setup()
    for (let i = 0; i < 4; i++) await signIn(app, 'wrong')
    expect((await signIn(app)).status).toBe(204)

    for (let i = 0; i < 4; i++) expect((await signIn(app, 'wrong')).status).toBe(401)
    expect((await signIn(app)).status).toBe(204)
  })

  it('counts failures only within a 15 minute window', async () => {
    const { app, advance } = setup()
    for (let i = 0; i < 4; i++) await signIn(app, 'wrong')
    advance(15 * MINUTE + 1)

    for (let i = 0; i < 4; i++) expect((await signIn(app, 'wrong')).status).toBe(401)
    expect((await signIn(app)).status).toBe(204)
  })
})

describe('GET /api/staff/session', () => {
  it('returns 401 without a session cookie', async () => {
    const { app } = setup()
    expect((await request(app).get('/api/staff/session')).status).toBe(401)
  })

  it('returns 204 with the cookie from sign-in', async () => {
    const { app } = setup()
    const cookie = sessionCookie(await signIn(app))

    expect((await request(app).get('/api/staff/session').set('Cookie', cookie)).status).toBe(204)
  })

  it('ends the session 8 hours after sign-in', async () => {
    const { app, advance } = setup()
    const cookie = sessionCookie(await signIn(app))

    advance(8 * HOUR - 1)
    expect((await request(app).get('/api/staff/session').set('Cookie', cookie)).status).toBe(204)

    advance(1)
    expect((await request(app).get('/api/staff/session').set('Cookie', cookie)).status).toBe(401)
  })
})

describe('DELETE /api/staff/session', () => {
  it('ends the session so the old cookie no longer works', async () => {
    const { app } = setup()
    const cookie = sessionCookie(await signIn(app))

    const out = await request(app).delete('/api/staff/session').set('Cookie', cookie)
    expect(out.status).toBe(204)
    expect(out.headers['set-cookie'][0]).toMatch(/^staff_session=;/)

    expect((await request(app).get('/api/staff/session').set('Cookie', cookie)).status).toBe(401)
  })
})
