# 01: Project foundation and tasting list

**What to build:** A guest opens the winery's site and sees the three upcoming tastings, each with its title, date and time, price per guest, seats left, and a "Book <tasting title>" link. The app builds with `npm run build` and serves everything on one port with `npm start`. This slice cuts through the catalogue, the seat count, the JSON API, and the browser page.

**Blocked by:** None (can start immediately)

**Status:** resolved

- [x] `npm install`, `npm run build` and `npm start` work on Node.js 22; `npm start` serves on `PORT` (default 3000)
- [x] `GET /api/tastings` returns the three tastings with identifier, title, starts-at, price per guest, total seats and seats left (seats left equals total seats when there are no bookings)
- [x] The start page lists each tasting with its title, date and time, "EUR <price> per guest", and "<n> seats left"
- [x] Each tasting has a "Book <tasting title>" link pointing at its booking page (the booking page itself is built in ticket 02)
- [x] The app starts with no bookings and makes no network calls to external services
- [x] Tests written first at the HTTP seam; the browser flow for the list is covered by an end-to-end test
- [x] Interface text is in English
