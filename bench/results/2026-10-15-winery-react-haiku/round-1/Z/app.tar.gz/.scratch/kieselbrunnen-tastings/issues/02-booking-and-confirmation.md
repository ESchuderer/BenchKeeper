# 02: Booking form and confirmation

**What to build:** A guest clicks "Book <tasting title>", fills in Name, Email and Guests, and submits. Invalid input shows an error next to the field it concerns. A valid booking succeeds only when enough seats are left, and the guest sees the "Booking confirmed" page with the tasting, guests, total price and booking reference. The confirmation page works when reloaded or opened later from its link.

**Blocked by:** 01

**Status:** resolved

- [x] `POST /api/tastings/:id/bookings` creates a booking and returns 201 with reference, tasting, guests and total price
- [x] A booking that asks for more guests than seats left is rejected with 400 and a `guests` error, and no seats are taken
- [x] Missing name, invalid email, and guests that are not a whole number from 1 to 8 are each rejected with the exact error messages in the spec
- [x] Two bookings made for the last seat cannot both succeed
- [x] An unknown tasting returns 404; a fully booked tasting returns 400 with "This tasting is fully booked."
- [x] `GET /api/bookings/:reference` returns the confirmation data without the guest's email; an unknown reference returns 404
- [x] Booking page at `/tastings/:id/book` shows the tasting title, date, time and price; has fields labelled "Name", "Email" and "Guests" (1 to 8) and a "Book" button
- [x] The total price updates as the guest count changes
- [x] Validation errors appear next to the field they concern and keep what the guest typed
- [x] The Book button is disabled while the request is in flight
- [x] Booking page for an unknown tasting shows a "page not found" message; for a fully booked tasting it shows the fully booked message instead of a form
- [x] Confirmation page at `/bookings/:reference` shows the heading "Booking confirmed", the tasting, guests, total price, booking reference, and a link back to the tastings
- [x] Tests written first at the HTTP seam, plus end-to-end tests for the form errors and the confirmation
