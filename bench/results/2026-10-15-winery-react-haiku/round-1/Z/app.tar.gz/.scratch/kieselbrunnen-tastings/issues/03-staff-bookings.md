# 03: Staff sign-in, bookings list and cancellation

**What to build:** A staff member opens `/staff`, signs in with the password from `STAFF_PASSWORD`, and sees every booking grouped by tasting. They can cancel a booking, which frees its seats immediately, and sign out.

**Blocked by:** 02

**Status:** resolved

- [x] `POST /api/staff/session` returns 204 and sets a session cookie for the correct password; 401 "Incorrect password." for a wrong password; 401 "Please enter the password." for an empty one; 503 "Staff sign-in is not configured." when `STAFF_PASSWORD` is unset
- [x] Repeated wrong passwords from one client are rate-limited with 429
- [x] Session cookie is httpOnly, sameSite strict, lasts 12 hours, and is marked secure in production
- [x] `DELETE /api/staff/session` ends the session
- [x] `GET /api/staff/bookings` returns all tastings with total seats, booked seats and their bookings (reference, name, email, guests); tastings with no bookings are included; 401 without a session
- [x] `DELETE /api/staff/bookings/:reference` removes the booking and frees its seats (so `GET /api/tastings` shows the seats back); 404 for an unknown reference; 401 without a session
- [x] `/staff` shows a "Password" field and a "Sign in" button; wrong or empty password shows the message next to the field; sign-in does not expose the password to the page afterwards
- [x] Signed in, `/staff` shows each tasting heading with "<booked> of <total> seats booked", a table with Name, Email, Guests and Reference plus a "Cancel" button per booking, and "No bookings yet" for empty tastings
- [x] Cancel asks for confirmation first; confirming removes the booking from the list and refreshes the list
- [x] "Sign out" returns to the sign-in form
- [x] Tests written first at the HTTP seam, plus end-to-end tests for sign-in, grouping, cancellation and sign-out
