# 04: Visual design, responsive layout and states

**What to build:** The app looks like a small winery's own site. Every page has a coherent design with clear success, error, loading and fully booked states, and works on a phone without horizontal scrolling.

**Blocked by:** 03

**Status:** resolved

- [x] Shared header with "Weingut Kieselbrunnen" and footer; a consistent palette (cream background, wine-red accents), serif headings and a system sans-serif body font, with no third-party font or script loads
- [x] Tasting cards: clear "<n> seats left" text, a distinct "Fully booked" badge, and no booking link for fully booked tastings
- [x] Error states: inline field errors and a server-unreachable message that tells the guest to try again rather than implying success
- [x] Success state: the confirmation page is visually clear and matches the rest of the site
- [x] Staff table becomes readable on narrow screens (stacked rows or an internal scroll container), and the page never scrolls sideways
- [x] Layout checked at a 375px-wide viewport and a desktop viewport in the end-to-end suite (no horizontal overflow; primary actions visible)
- [x] Interface text remains in English
