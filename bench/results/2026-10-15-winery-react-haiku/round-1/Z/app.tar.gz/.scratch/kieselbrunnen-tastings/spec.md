# Spec: Kieselbrunnen Wine Tasting Bookings

Status: ready-for-agent

## Problem Statement

Weingut Kieselbrunnen, a family winery, takes bookings for its wine tastings by hand. Guests cannot see which tastings still have seats or book one online, and staff have no single place to see who is coming to each tasting or to cancel a booking.

## Solution

A small web app for the winery's own site, in English, with two audiences:

- **Guests** see the three upcoming tastings with their date, time, price per guest and seats left. They book a tasting through a short form and receive a booking confirmation with a booking reference. A booking can never take more seats than are left.
- **Staff** sign in with a shared password and see every booking grouped by tasting. They can cancel a booking, which frees its seats.

The app looks like the winery's own site: warm, polished and readable, with clear states for errors, success and fully booked tastings, and usable on a phone.

## Tastings on offer

| Tasting | Date and time | Price per guest | Seats |
|---|---|---|---|
| Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

## User Stories

### Guest: browsing tastings

1. As a guest, I want to see the winery's name and a page titled with the tastings, so that I know I am in the right place.
2. As a guest, I want each tasting listed with its title, so that I can choose the one I want.
3. As a guest, I want each tasting's date and time shown, so that I can check I am free.
4. As a guest, I want each tasting's price per guest shown, so that I know what it costs before booking.
5. As a guest, I want to see how many seats are left for each tasting (for example "7 seats left"), so that I know whether I can still book.
6. As a guest, I want a "Book Riesling Evening" style button or link on each tasting, so that I can start a booking for that tasting.
7. As a guest, I want fully booked tastings to be clearly marked as "Fully booked" and not offer a booking link, so that I am not sent to a form I cannot use.
8. As a guest, I want the seat count to reflect bookings made moments earlier, so that I do not see stale availability after reloading.

### Guest: booking a tasting

9. As a guest, I want a booking form for the tasting I picked, with its title, date, time and price shown at the top, so that I know what I am booking.
10. As a guest, I want a field labelled "Name", so that I can give the name the booking is under.
11. As a guest, I want a field labelled "Email", so that I can be contacted about my booking.
12. As a guest, I want a field labelled "Guests" that accepts whole numbers from 1 to 8, so that I can book for my party.
13. As a guest, I want to see the total price update as I change the number of guests, so that I know what I will pay.
14. As a guest, I want a "Book" button to submit the form, so that I can complete the booking.
15. As a guest, I want a missing name rejected with a message next to the Name field, so that I know what to fix.
16. As a guest, I want an invalid email rejected with a message next to the Email field, so that I know what to fix.
17. As a guest, I want a guest count outside 1 to 8, or not a whole number, rejected with a message next to the Guests field, so that I know what to fix.
18. As a guest, I want a guest count larger than the seats left rejected with a message next to the Guests field (for example "Only 3 seats left for this tasting."), so that I never book seats that do not exist.
19. As a guest, I want the form to show a message if the tasting became fully booked while I was filling it in, so that I understand why my booking was refused.
20. As a guest, I want the form not to lose what I typed when there is a validation error, so that I can correct the one field.
21. As a guest, I want the form to tell me I cannot book a tasting that is fully booked, instead of offering a form, so that I do not waste my time.
22. As a guest, I want a clear "page not found" message if I open a tasting that does not exist, so that I am not left on a blank page.

### Guest: confirmation

23. As a guest, I want to see a confirmation with the heading "Booking confirmed" after I book, so that I know the booking worked.
24. As a guest, I want the confirmation to name the tasting, so that I can check which tasting I booked.
25. As a guest, I want the confirmation to show the number of guests, so that I can check the party size.
26. As a guest, I want the confirmation to show the total price, so that I know what I owe.
27. As a guest, I want the confirmation to show a booking reference, so that I can quote it to the winery.
28. As a guest, I want the confirmation to stay available if I reload the page or open its link later, so that I can find my reference again.
29. As a guest, I want a link back to the tastings from the confirmation, so that I can book something else.

### Staff: signing in

30. As a staff member, I want a `/staff` page with a "Password" field and a "Sign in" button, so that I can get into the bookings.
31. As a staff member, I want a wrong password rejected with a message, so that I know to try again.
32. As a staff member, I want an empty password rejected with a message, so that I know to type one in.
33. As a staff member, I want to stay signed in while I use the bookings page, so that I do not have to type the password for every action.
34. As a staff member, I want a "Sign out" button, so that I can end the session on a shared device.
35. As a staff member, I want an error shown if the server has no staff password configured, so that I know the deployment needs fixing rather than thinking my password is wrong.
36. As the winery, I want repeated wrong password attempts slowed down, so that the shared password cannot be guessed quickly.

### Staff: managing bookings

37. As a staff member, I want to see all bookings grouped by tasting, so that I can see who is coming to each tasting.
38. As a staff member, I want each booking's name, email, number of guests and reference in a table, so that I have the details I need.
39. As a staff member, I want each tasting group to show how many seats are booked out of the total, so that I can see how full it is.
40. As a staff member, I want an empty tasting to say "No bookings yet", so that I know it is not a loading problem.
41. As a staff member, I want a "Cancel" button on each booking, so that I can cancel a booking the guest no longer needs.
42. As a staff member, I want to confirm a cancellation before it happens, so that a mis-click does not cancel someone's booking.
43. As a staff member, I want a cancelled booking removed from the list and its seats freed, so that the seats can be sold again immediately.
44. As a staff member, I want the bookings list to refresh after a cancellation, so that the screen matches the data.

### Look, feel and resilience

45. As a guest on a phone, I want every page to fit the screen without horizontal scrolling, so that I can book from my phone.
46. As a staff member on a phone, I want the bookings table to remain readable on a narrow screen, so that I can manage bookings from my phone.
47. As a guest, I want a clear message if the server cannot be reached, so that I know to try again rather than assuming my booking went through.
48. As a guest, I want the Book button to be disabled while the booking is being sent, so that I do not submit twice.
49. As the winery, I want the app to start with no bookings and no external services, so that it runs on a small server.
50. As the winery, I want the app to serve the guest pages, the staff pages and the API on one port set by the `PORT` environment variable (default 3000), so that deployment is one process.
51. As the winery, I want the interface in English throughout, so that it matches the brief.

## Implementation Decisions

### Modules

- **Tastings catalogue**: a fixed list of the three tastings above, with an identifier (a URL-safe slug), title, starts-at as local winery time without a timezone, price per guest in whole euros, and total seats.
- **Booking store**: an in-memory store of bookings. It creates bookings, looks them up by reference, removes them, and reports the seats booked per tasting. Seats left is always derived from the stored bookings, never stored separately. Each process starts empty. Creation and the seat check happen in one synchronous step so two simultaneous bookings cannot oversell.
- **Booking rules** (shared by client and server): name, email, and guests rules, plus the seat limit rule. The same rule definitions are used to validate the form in the browser and to validate the request on the server. The server is the authority.
- **HTTP application**: a factory that takes the staff password (or none, meaning staff sign-in is unavailable) and returns the application, with the store created inside it. Each call gives a fresh, empty store, so tests stay isolated. It exposes the JSON API and, when given the built client directory, serves the single-page app with a fallback to the index page for non-API paths.
- **Staff session**: held on the server in memory. The cookie carries only a signed session id; it is httpOnly, sameSite strict, lasts 12 hours, and is marked secure in production. Signing in issues a new session id; signing out destroys the server-side session, so a copied cookie stops working. The signing key is random per process unless one is supplied. Passwords are compared in constant time, after hashing both sides to equal length.
- **Server entry point**: reads `PORT` (default 3000) and `STAFF_PASSWORD`, logs a warning at startup if the password is unset, and serves the built client.
- **Client**: a single-page app. Routes are the tasting list, the booking form for one tasting, the booking confirmation for one reference, and the staff page. Data fetching and cache invalidation use a server-state library. Forms use a form library with the same schema as the server.

### Interfaces

Guest API (JSON):

- `GET /api/tastings` returns each tasting with its identifier, title, starts-at, price per guest, total seats and seats left.
- `GET /api/tastings/:id` returns one tasting in the same shape, or 404.
- `POST /api/tastings/:id/bookings` takes name, email and guests. On success it returns 201 with the booking reference, tasting, guests and total price. On a validation or seat problem it returns 400 with an error per field: `{ "errors": { "name"?: string, "email"?: string, "guests"?: string } }`. An unknown tasting returns 404. A fully booked tasting returns 400 with a `guests` error saying so.
- `GET /api/bookings/:reference` returns the booking confirmation data: reference, tasting title, starts-at, price per guest, guests and total price. It does not return the guest's email. Unknown references return 404.

Staff API (JSON, requires a valid session except sign-in):

- `POST /api/staff/session` takes a password. It returns 204 and sets the session cookie on success, 401 with a message on a wrong or empty password, and 503 with a message when no staff password is configured. Repeated failures are rate-limited and return 429.
- `DELETE /api/staff/session` signs out and returns 204.
- `GET /api/staff/bookings` returns every tasting with its total seats, booked seats, and its bookings (reference, name, email, guests). Tastings with no bookings are included with an empty list. Unauthenticated requests return 401.
- `DELETE /api/staff/bookings/:reference` removes the booking and returns 204, or 404 if it does not exist.

Error messages (exact wording used by the UI):

- Name missing: "Please enter your name."
- Email invalid or missing: "Please enter a valid email address."
- Guests not a whole number from 1 to 8: "Guests must be a whole number from 1 to 8."
- Guests above seats left: "Only N seats left for this tasting." (N is the current number; "Only 1 seat left" is singular.)
- Fully booked: "This tasting is fully booked."
- Wrong staff password: "Incorrect password."
- Empty staff password: "Please enter the password."
- No staff password configured: "Staff sign-in is not configured."

Client routes:

- `/`: tasting list.
- `/tastings/:id/book`: booking form.
- `/bookings/:reference`: booking confirmation.
- `/staff`: sign-in, then bookings.

Data rules:

- Total price is price per guest times guests, in whole euros.
- Seats left is total seats minus the sum of guests across the tasting's bookings, never below zero.
- References are short, human-readable and unique (for example `KB-` followed by six characters from an alphabet that omits look-alike letters and digits). Collisions are retried.
- Dates are shown in the winery's local time without timezone conversion. The weekday is computed from the calendar date, not from the machine's clock.

Build and run:

- The client is built with a bundler into a static directory. The server is compiled to JavaScript.
- `npm install`, then `npm run build`, then `npm start`. `npm start` serves the app on `PORT`.
- Node.js 22. No external services, no database, no network calls at runtime.

Styling:

- Utility-first CSS with a custom palette inspired by a small winery: cream background, deep wine-red accents, warm neutral text, and a serif face for headings with a system sans-serif for body text. No web fonts loaded from third-party servers.
- Layout is mobile-first. Tables switch to stacked cards on narrow screens or scroll within their own container; the page never scrolls sideways.

### Assumptions made without asking the user

These are decisions the spec author made from the brief. Review them before publishing.

- **Persistence**: bookings are kept in memory only. Restarting the server clears all bookings, which matches "the app starts with no bookings". A local file store can replace the in-memory store behind the same interface later.
- **Fully booked tastings** are shown on the list with a "Fully booked" badge and no booking link. Their booking URL shows the fully booked message instead of a form.
- **Cancellation** removes the booking record rather than keeping a cancelled status. The guest's reference then returns 404.
- **Cancel confirmation** uses a browser confirmation dialog before the request is sent.
- **Staff session** does not survive a server restart, because sessions are held in memory.
- **Rate limiting** on the staff sign-in is per process and per client address. It does not account for a reverse proxy in front of the app.
- **Sorting**: tastings appear in the order in the table above. Staff groups use the same order.

## Testing Decisions

### What makes a good test here

Tests check behaviour a guest or a member of staff would notice, through the interfaces above. They use known literal values, such as the seat numbers and prices in the table, rather than recomputing them with the code's own formulas. They do not assert on internal modules, call counts or the shape of private helpers.

### Seams

Two seams, confirmed by the spec author as the minimum that covers the requirements:

1. **The HTTP API** (the application factory, exercised with HTTP requests). Almost all business rules are tested here: seat limits, validation, reference lookup, cancellation, staff access control, and rate limiting. Each test creates its own application, so no test depends on another.
2. **The browser** (end-to-end, against the built and started app). Used for the user-visible requirements: the tasting list, the Book link, the form's labels and inline errors, the confirmation heading, the staff sign-in flow, grouped bookings, cancellation with its dialog, and the mobile layout.

The UI is not tested with component-level tests that stub the network. Those would duplicate the browser tests and tie the tests to implementation details.

### Modules tested

- The HTTP application, through its API (primary).
- The browser flows listed above (end-to-end).
- Shared validation rules are covered through the API tests rather than their own unit tests, because the API is the seam that matters. The browser tests confirm the messages appear next to the right fields.

### Prior art

None. The repository has no code yet; it contains only the agent configuration and this spec's directory.

## Out of Scope

- Payments, invoices or any money being taken online. The total is informational.
- Email or SMS sending. Confirmations are shown on screen only.
- Editing a booking (changing guests or contact details). Staff can only cancel.
- Creating, editing or removing tastings from the UI. The catalogue is fixed in code.
- Multiple staff accounts, roles or password reset. A single shared password.
- Hiding tastings that have already happened. All three tastings are upcoming relative to the planned launch.
- Waiting lists, holds or reservations that expire.
- Persistence across restarts (see the assumption above).
- Accessibility beyond sensible defaults: labels, focus, and inline error association are included; a full audit is not.
- Localisation. English only.

## Further Notes

- The staff password is read from the `STAFF_PASSWORD` environment variable. It is never stored in the repository or sent to the browser.
- If `STAFF_PASSWORD` is unset, the app still runs; only staff sign-in is disabled and returns the "not configured" message.
- Session cookies are marked secure in production. Deploy behind HTTPS.
