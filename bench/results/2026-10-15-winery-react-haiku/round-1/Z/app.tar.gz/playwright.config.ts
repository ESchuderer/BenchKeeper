import { defineConfig, devices } from "@playwright/test";

const staffPassword = "e2e-staff-password";

// Each project gets its own freshly started server, so bookings made by one
// project never leak into another. The build runs first, in `npm run test:e2e`.
const desktopPort = process.env.E2E_PORT ?? "3100";
const mobilePort = String(Number(desktopPort) + 1);

function serverFor(port: string) {
  return {
    command: "node dist/server/main.js",
    url: `http://localhost:${port}/api/tastings`,
    env: { PORT: port, STAFF_PASSWORD: staffPassword },
    reuseExistingServer: false,
    timeout: 60_000,
  };
}

export default defineConfig({
  testDir: "tests/e2e",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [["list"]],
  use: {
    trace: "retain-on-failure",
  },
  projects: [
    {
      name: "desktop",
      use: { ...devices["Desktop Chrome"], baseURL: `http://localhost:${desktopPort}` },
    },
    {
      name: "mobile",
      use: { ...devices["Pixel 5"], baseURL: `http://localhost:${mobilePort}` },
    },
  ],
  webServer: [serverFor(desktopPort), serverFor(mobilePort)],
});
