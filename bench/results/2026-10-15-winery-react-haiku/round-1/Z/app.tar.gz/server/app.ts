import path from "node:path";
import express, { type NextFunction, type Request, type RequestHandler, type Response } from "express";
import type { ZodError } from "zod";
import { findTasting, tastings } from "./catalogue.js";
import { createBookingStore, type BookingStore } from "./booking-store.js";
import { bookingSchema } from "../shared/booking-rules.js";
import type { BookingConfirmation, StaffTastingGroup, Tasting, TastingView } from "../shared/types.js";
import { MESSAGES } from "../shared/messages.js";
import {
  passwordMatches,
  requireStaff,
  signInLimiter,
  staffSession,
  STAFF_SESSION_COOKIE,
} from "./staff-auth.js";

export interface AppOptions {
  /** Staff password. When undefined, staff sign-in is unavailable. */
  staffPassword?: string | undefined;
  /** Key for signing staff session cookies. Random per process when omitted. */
  sessionSecret?: string;
  /** Built client directory to serve. Omit to serve the API only. */
  clientDir?: string;
}

/** Maps each invalid field to its first message, for the form to show next to it. */
function fieldErrors(error: ZodError): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0] ?? "");
    if (!(field in errors)) errors[field] = issue.message;
  }
  return errors;
}

export function createApp(options: AppOptions = {}) {
  const store: BookingStore = createBookingStore();
  const app = express();

  app.use(express.json());

  function seatsLeftFor(tasting: Tasting): number {
    return Math.max(0, tasting.seats - store.seatsBooked(tasting.id));
  }

  function toView(tasting: Tasting): TastingView {
    return { ...tasting, seatsLeft: seatsLeftFor(tasting) };
  }

  function toConfirmation(
    booking: { reference: string; tastingId: string; guests: number },
    tasting: Tasting,
  ): BookingConfirmation {
    return {
      reference: booking.reference,
      tastingId: tasting.id,
      tastingTitle: tasting.title,
      startsAt: tasting.startsAt,
      pricePerGuest: tasting.pricePerGuest,
      guests: booking.guests,
      totalPrice: tasting.pricePerGuest * booking.guests,
    };
  }

  app.get("/api/tastings", (_req, res) => {
    res.json(tastings.map(toView));
  });

  app.get("/api/tastings/:id", (req, res) => {
    const tasting = findTasting(req.params.id ?? "");
    if (!tasting) {
      res.status(404).json({ message: "Tasting not found." });
      return;
    }
    res.json(toView(tasting));
  });

  app.post("/api/tastings/:id/bookings", (req, res) => {
    const tasting = findTasting(req.params.id ?? "");
    if (!tasting) {
      res.status(404).json({ message: "Tasting not found." });
      return;
    }

    // Check the seats and record the booking in one synchronous step, so no
    // other request can take the seats in between.
    const parsed = bookingSchema(seatsLeftFor(tasting)).safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ errors: fieldErrors(parsed.error) });
      return;
    }

    const booking = store.add({ tastingId: tasting.id, ...parsed.data });
    res.status(201).json(toConfirmation(booking, tasting));
  });

  app.get("/api/bookings/:reference", (req, res) => {
    const booking = store.findByReference(req.params.reference ?? "");
    const tasting = booking ? findTasting(booking.tastingId) : undefined;
    if (!booking || !tasting) {
      res.status(404).json({ message: "Booking not found." });
      return;
    }
    res.json(toConfirmation(booking, tasting));
  });

  app.use("/api/staff", staffSession(options.sessionSecret));

  // Checked before the rate limiter, so an unconfigured server never locks anyone out.
  const requireConfigured: RequestHandler = (_req, res, next) => {
    if (!options.staffPassword) {
      res.status(503).json({ message: MESSAGES.staffNotConfigured });
      return;
    }
    next();
  };

  app.post("/api/staff/session", requireConfigured, signInLimiter(), (req, res, next) => {
    const staffPassword = options.staffPassword ?? "";
    const password: unknown = req.body?.password;
    if (typeof password !== "string" || password.trim() === "") {
      res.status(401).json({ message: MESSAGES.staffPasswordRequired });
      return;
    }
    if (!passwordMatches(password, staffPassword)) {
      res.status(401).json({ message: MESSAGES.staffIncorrectPassword });
      return;
    }
    // A fresh session id on sign-in stops a session id set before sign-in from being reused.
    req.session.regenerate((error) => {
      if (error) {
        next(error);
        return;
      }
      req.session.staff = true;
      res.status(204).end();
    });
  });

  app.delete("/api/staff/session", (req, res, next) => {
    req.session.destroy((error) => {
      if (error) {
        next(error);
        return;
      }
      res.clearCookie(STAFF_SESSION_COOKIE, { path: "/" });
      res.status(204).end();
    });
  });

  app.get("/api/staff/bookings", requireStaff, (_req, res) => {
    const groups: StaffTastingGroup[] = tastings.map((tasting) => ({
      id: tasting.id,
      title: tasting.title,
      startsAt: tasting.startsAt,
      seats: tasting.seats,
      bookedSeats: store.seatsBooked(tasting.id),
      bookings: store
        .listForTasting(tasting.id)
        .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
    }));
    res.json(groups);
  });

  app.delete("/api/staff/bookings/:reference", requireStaff, (req, res) => {
    if (!store.remove(String(req.params.reference ?? ""))) {
      res.status(404).json({ message: "Booking not found." });
      return;
    }
    res.status(204).end();
  });

  app.use("/api", (req, res) => {
    res.status(404).json({ message: "Not found." });
  });

  app.use("/api", (err: unknown, _req: Request, res: Response, next: NextFunction) => {
    const error = (err ?? {}) as { type?: string; status?: number };
    if (error.type === "entity.parse.failed") {
      res.status(400).json({ message: "Invalid request." });
      return;
    }
    if (error.status === 413 || error.type === "entity.too.large") {
      res.status(413).json({ message: "Request too large." });
      return;
    }
    if (res.headersSent) return next(err);
    res.status(500).json({ message: "Something went wrong." });
  });

  if (options.clientDir) {
    app.use(express.static(options.clientDir));
    app.use((req, res, next) => {
      // Only page paths fall back to the app. A missing file such as a script stays a 404.
      const acceptsHtml = req.accepts(["html"]) === "html";
      const isFile = path.extname(req.path) !== "";
      if (req.method !== "GET" || !acceptsHtml || isFile) return next();
      res.sendFile("index.html", { root: options.clientDir });
    });
  }

  return app;
}
