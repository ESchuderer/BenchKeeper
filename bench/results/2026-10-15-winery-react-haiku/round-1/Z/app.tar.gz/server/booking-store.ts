import { randomInt } from "node:crypto";

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export interface NewBooking {
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

/**
 * In-memory booking storage. Seats left are never stored; they are derived
 * from the bookings held here, so there is a single source of truth.
 */
export interface BookingStore {
  seatsBooked(tastingId: string): number;
  add(booking: NewBooking): Booking;
  findByReference(reference: string): Booking | undefined;
  listForTasting(tastingId: string): Booking[];
  /** Removes a booking and frees its seats. Returns false if there was no such booking. */
  remove(reference: string): boolean;
}

// Leaves out the look-alike characters 0, O, 1 and I.
const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomReference(): string {
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  }
  return `KB-${code}`;
}

export function createBookingStore(): BookingStore {
  const bookings: Booking[] = [];
  const byReference = new Map<string, Booking>();

  function newUniqueReference(): string {
    for (;;) {
      const reference = randomReference();
      if (!byReference.has(reference)) return reference;
    }
  }

  return {
    seatsBooked(tastingId) {
      return bookings
        .filter((booking) => booking.tastingId === tastingId)
        .reduce((sum, booking) => sum + booking.guests, 0);
    },

    add(input) {
      const booking: Booking = { ...input, reference: newUniqueReference() };
      bookings.push(booking);
      byReference.set(booking.reference, booking);
      return booking;
    },

    findByReference(reference) {
      return byReference.get(reference);
    },

    listForTasting(tastingId) {
      return bookings.filter((booking) => booking.tastingId === tastingId);
    },

    remove(reference) {
      const booking = byReference.get(reference);
      if (!booking) return false;
      byReference.delete(reference);
      bookings.splice(bookings.indexOf(booking), 1);
      return true;
    },
  };
}
