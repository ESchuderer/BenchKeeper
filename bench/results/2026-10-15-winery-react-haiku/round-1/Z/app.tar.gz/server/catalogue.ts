import type { Tasting } from "../shared/types.js";

/** The winery's fixed programme of tastings, in display order. */
export const tastings: readonly Tasting[] = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00",
    pricePerGuest: 25,
    seats: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00",
    pricePerGuest: 32,
    seats: 8,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00",
    pricePerGuest: 28,
    seats: 10,
  },
];

export function findTasting(id: string): Tasting | undefined {
  return tastings.find((tasting) => tasting.id === id);
}
