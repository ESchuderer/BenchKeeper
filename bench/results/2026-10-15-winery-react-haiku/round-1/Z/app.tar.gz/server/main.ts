import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";

const port = Number(process.env.PORT ?? 3000);
const clientDir = fileURLToPath(new URL("../client", import.meta.url));
const staffPassword = process.env.STAFF_PASSWORD;

if (!staffPassword) {
  console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled until it is.");
}

const app = createApp({ staffPassword, clientDir });

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
});
