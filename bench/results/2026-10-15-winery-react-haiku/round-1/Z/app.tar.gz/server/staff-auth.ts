import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import session from "express-session";
import memorystore from "memorystore";
import { rateLimit } from "express-rate-limit";
import { MESSAGES } from "../shared/messages.js";

declare module "express-session" {
  interface SessionData {
    staff?: boolean;
  }
}

export const STAFF_SESSION_COOKIE = "kb_staff";
const SESSION_LIFETIME_MS = 12 * 60 * 60 * 1000;
const SIGN_IN_WINDOW_MS = 15 * 60 * 1000;
const SIGN_IN_FAILURES_ALLOWED = 10;

const MemoryStore = memorystore(session);

/** Compares two passwords in constant time, after hashing so their lengths do not matter. */
export function passwordMatches(candidate: string, expected: string): boolean {
  const candidateHash = createHash("sha256").update(candidate, "utf8").digest();
  const expectedHash = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(candidateHash, expectedHash);
}

/**
 * Staff sessions live on the server: the cookie only carries a signed session
 * id. Signing out destroys the session, so a copied cookie stops working.
 */
export function staffSession(secret: string | undefined) {
  return session({
    name: STAFF_SESSION_COOKIE,
    secret: secret ?? randomBytes(32).toString("hex"),
    store: new MemoryStore({ checkPeriod: SESSION_LIFETIME_MS }),
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "strict",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: SESSION_LIFETIME_MS,
    },
  });
}

/** Counts failed sign-in attempts per client address. */
export function signInLimiter() {
  return rateLimit({
    windowMs: SIGN_IN_WINDOW_MS,
    limit: SIGN_IN_FAILURES_ALLOWED,
    skipSuccessfulRequests: true,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { message: MESSAGES.staffRateLimited },
  });
}

export function requireStaff(req: Request, res: Response, next: NextFunction) {
  if (req.session.staff === true) {
    next();
    return;
  }
  res.status(401).json({ message: "Please sign in." });
}
