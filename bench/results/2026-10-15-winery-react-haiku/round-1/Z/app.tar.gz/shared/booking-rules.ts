import { z } from "zod";
import { MAX_GUESTS, MAX_NAME_LENGTH, MESSAGES, seatsLeftText } from "./messages.js";

/**
 * Booking rules shared by the browser form and the server. The server is the
 * authority; the browser uses the same rules so the messages match.
 */

/** Message when the requested guests cannot be seated, or undefined if they can. */
export function seatProblem(guests: number, seatsLeft: number): string | undefined {
  if (seatsLeft <= 0) return MESSAGES.fullyBooked;
  if (guests > seatsLeft) return `Only ${seatsLeftText(seatsLeft)} for this tasting.`;
  return undefined;
}

export function bookingSchema(seatsLeft: number) {
  return z.object({
    name: z
      .string({ error: MESSAGES.nameRequired })
      .trim()
      .min(1, { error: MESSAGES.nameRequired })
      .max(MAX_NAME_LENGTH, { error: MESSAGES.nameTooLong }),
    email: z
      .string({ error: MESSAGES.email })
      .trim()
      .pipe(z.email({ error: MESSAGES.email })),
    guests: z
      .number({ error: MESSAGES.guests })
      .int({ error: MESSAGES.guests })
      .min(1, { error: MESSAGES.guests })
      .max(MAX_GUESTS, { error: MESSAGES.guests })
      .superRefine((guests, ctx) => {
        const message = seatProblem(guests, seatsLeft);
        if (message) ctx.addIssue({ code: "custom", message });
      }),
  });
}
