/** Wording shared by the server and the browser, so the same message appears in both. */

export const MAX_GUESTS = 8;
export const MAX_NAME_LENGTH = 100;

export const MESSAGES = {
  nameRequired: "Please enter your name.",
  nameTooLong: `Please enter ${MAX_NAME_LENGTH} characters or fewer.`,
  email: "Please enter a valid email address.",
  guests: `Guests must be a whole number from 1 to ${MAX_GUESTS}.`,
  fullyBooked: "This tasting is fully booked.",
  staffPasswordRequired: "Please enter the password.",
  staffIncorrectPassword: "Incorrect password.",
  staffNotConfigured: "Staff sign-in is not configured.",
  staffRateLimited: "Too many attempts. Please wait 15 minutes and try again.",
} as const;

/** "1 seat left" or "7 seats left". */
export function seatsLeftText(seatsLeft: number): string {
  return seatsLeft === 1 ? "1 seat left" : `${seatsLeft} seats left`;
}
