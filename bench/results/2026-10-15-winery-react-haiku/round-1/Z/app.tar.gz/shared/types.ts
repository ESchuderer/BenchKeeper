/** A tasting in the winery's programme. */
export interface Tasting {
  id: string;
  title: string;
  /** Local winery time, without a timezone, e.g. "2026-11-06T18:00". */
  startsAt: string;
  /** Price per guest in whole euros. */
  pricePerGuest: number;
  seats: number;
}

/** A tasting as the guest and staff apps see it, with seats left derived from bookings. */
export interface TastingView extends Tasting {
  seatsLeft: number;
}

/** What a guest sees after booking, and when reopening a booking by its reference. */
export interface BookingConfirmation {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  pricePerGuest: number;
  guests: number;
  totalPrice: number;
}

/** A booking as the staff list shows it. */
export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

/** One tasting with its bookings, for the staff page. */
export interface StaffTastingGroup {
  id: string;
  title: string;
  startsAt: string;
  seats: number;
  bookedSeats: number;
  bookings: StaffBooking[];
}
