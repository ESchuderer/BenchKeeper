import { Route, Routes } from "react-router";
import { Layout } from "./components/Layout.js";
import { NotFoundPanel } from "./components/NotFoundPanel.js";
import { BookingPage } from "./pages/BookingPage.js";
import { ConfirmationPage } from "./pages/ConfirmationPage.js";
import { StaffPage } from "./pages/StaffPage.js";
import { TastingsPage } from "./pages/TastingsPage.js";

export function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<TastingsPage />} />
        <Route path="/tastings/:id/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
        <Route path="/staff" element={<StaffPage />} />
        <Route
          path="*"
          element={<NotFoundPanel title="Page not found" message="We couldn't find that page." />}
        />
      </Routes>
    </Layout>
  );
}
