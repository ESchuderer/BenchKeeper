import type { BookingConfirmation, StaffTastingGroup, TastingView } from "../shared/types.js";

export class ApiError extends Error {
  readonly status: number;
  readonly errors: Record<string, string>;

  constructor(status: number, message: string, errors: Record<string, string> = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.errors = errors;
  }
}

const UNREACHABLE_MESSAGE = "We couldn't reach the server, so we can't confirm your booking. Please try again.";

/** Retry a failed request once, unless the thing asked for does not exist. */
export function retryUnlessNotFound(failureCount: number, error: Error): boolean {
  return !(error instanceof ApiError && error.status === 404) && failureCount < 1;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(path, {
      ...init,
      headers: {
        Accept: "application/json",
        ...(init?.body ? { "Content-Type": "application/json" } : {}),
        ...init?.headers,
      },
    });
  } catch {
    throw new ApiError(0, UNREACHABLE_MESSAGE);
  }

  if (response.status === 204) {
    return undefined as T;
  }

  const body = (await response.json().catch(() => ({}))) as {
    message?: string;
    errors?: Record<string, string>;
  };

  if (!response.ok) {
    throw new ApiError(response.status, body.message ?? "Something went wrong.", body.errors);
  }

  return body as T;
}

export function fetchTastings(): Promise<TastingView[]> {
  return request<TastingView[]>("/api/tastings");
}

export function fetchTasting(id: string): Promise<TastingView> {
  return request<TastingView>(`/api/tastings/${encodeURIComponent(id)}`);
}

export interface BookingRequest {
  name: string;
  email: string;
  guests: number;
}

export function createBooking(tastingId: string, booking: BookingRequest): Promise<BookingConfirmation> {
  return request<BookingConfirmation>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
    method: "POST",
    body: JSON.stringify(booking),
  });
}

export function fetchBooking(reference: string): Promise<BookingConfirmation> {
  return request<BookingConfirmation>(`/api/bookings/${encodeURIComponent(reference)}`);
}

export function fetchStaffBookings(): Promise<StaffTastingGroup[]> {
  return request<StaffTastingGroup[]>("/api/staff/bookings");
}

export function staffSignIn(password: string): Promise<void> {
  return request<void>("/api/staff/session", {
    method: "POST",
    body: JSON.stringify({ password }),
  });
}

export function staffSignOut(): Promise<void> {
  return request<void>("/api/staff/session", { method: "DELETE" });
}

export function cancelBooking(reference: string): Promise<void> {
  return request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: "DELETE" });
}
