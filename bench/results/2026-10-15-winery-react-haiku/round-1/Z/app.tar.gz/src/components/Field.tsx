import type { InputHTMLAttributes, Ref } from "react";

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  id: string;
  label: string;
  error?: string | undefined;
  ref?: Ref<HTMLInputElement>;
}

/** A labelled input that shows its error message next to it and links the two for screen readers. */
export function Field({ id, label, error, ref, ...input }: FieldProps) {
  const errorId = `${id}-error`;
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium text-ink">
        {label}
      </label>
      <input
        id={id}
        ref={ref}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className={`w-full rounded border bg-white px-3 py-2.5 text-base text-ink placeholder:text-muted/60 ${
          error ? "border-wine bg-wine/5" : "border-muted"
        }`}
        {...input}
      />
      {error && (
        <p id={errorId} className="flex items-start gap-1.5 text-sm font-medium text-wine">
          <span aria-hidden="true">●</span>
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}
