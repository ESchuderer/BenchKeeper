import type { ReactNode } from "react";
import { Link } from "react-router";

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-wine text-cream shadow-sm">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-5">
          <Link to="/" className="min-w-0">
            <span className="block font-display text-xl leading-tight tracking-wide sm:text-2xl">
              Weingut Kieselbrunnen
            </span>
            <span className="block text-xs uppercase tracking-[0.2em] text-cream/75">Family winery</span>
          </Link>
          <nav aria-label="Main" className="shrink-0 text-sm">
            <Link to="/" className="rounded px-2 py-1 underline-offset-4 hover:underline">
              Tastings
            </Link>
          </nav>
        </div>
        <div aria-hidden="true" className="h-0.5 bg-gold" />
      </header>

      <main className="mx-auto w-full max-w-5xl min-w-0 flex-1 px-4 py-10 sm:py-14">{children}</main>

      <footer className="border-t border-gold/40 py-8 text-center text-sm text-muted">
        <p className="font-display text-base text-wine-dark">Weingut Kieselbrunnen</p>
        <p className="mt-1">
          <Link to="/staff" className="underline-offset-4 hover:underline">
            Staff
          </Link>
        </p>
      </footer>
    </div>
  );
}
