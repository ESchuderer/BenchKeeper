import { Link } from "react-router";

export function NotFoundPanel({ title, message }: { title: string; message: string }) {
  return (
    <section className="max-w-xl">
      <h1 className="font-display text-4xl text-wine-dark">{title}</h1>
      <p className="mt-4 text-muted">{message}</p>
      <Link to="/" className="mt-6 inline-block font-medium text-wine underline underline-offset-4">
        Back to all tastings
      </Link>
    </section>
  );
}
