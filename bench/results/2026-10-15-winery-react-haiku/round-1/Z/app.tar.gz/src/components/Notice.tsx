import type { ReactNode } from "react";

export type NoticeTone = "error" | "success" | "info";

const tones: Record<NoticeTone, string> = {
  error: "border-wine/40 bg-wine/10 text-wine-dark",
  success: "border-gold/60 bg-gold/15 text-ink",
  info: "border-muted/30 bg-white/60 text-ink",
};

/**
 * A banner for a whole-page or whole-form message. Errors are announced as
 * alerts; other messages as status updates.
 */
export function Notice({ tone, children, className = "" }: { tone: NoticeTone; children: ReactNode; className?: string }) {
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={`rounded border px-4 py-3 text-sm font-medium ${tones[tone]} ${className}`}
    >
      {children}
    </div>
  );
}
