import type { TastingView } from "../../shared/types.js";
import { formatPrice, formatWhen } from "../format.js";
import { seatsLeftText } from "../../shared/messages.js";

export function TastingSummary({ tasting }: { tasting: TastingView }) {
  return (
    <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-3 text-sm">
      <dt className="font-medium text-muted">When</dt>
      <dd>{formatWhen(tasting.startsAt)}</dd>
      <dt className="font-medium text-muted">Price</dt>
      <dd>{formatPrice(tasting.pricePerGuest)} per guest</dd>
      {tasting.seatsLeft > 0 && (
        <>
          <dt className="font-medium text-muted">Availability</dt>
          <dd>{seatsLeftText(tasting.seatsLeft)}</dd>
        </>
      )}
    </dl>
  );
}
