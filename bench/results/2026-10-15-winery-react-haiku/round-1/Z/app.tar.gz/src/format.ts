/**
 * Formats a local winery time such as "2026-11-06T18:00" for display, e.g.
 * "Friday 6 November 2026, 18:00". Works on the calendar fields only, so the
 * result does not depend on the viewer's timezone.
 */
export function formatWhen(startsAt: string): string {
  const [datePart = "", timePart = ""] = startsAt.split("T");
  const [year = 0, month = 1, day = 1] = datePart.split("-").map(Number);
  const weekdayAndDate = new Intl.DateTimeFormat("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(Date.UTC(year, month - 1, day)));

  return `${weekdayAndDate}, ${timePart}`;
}

export function formatPrice(euros: number): string {
  return `EUR ${euros}`;
}
