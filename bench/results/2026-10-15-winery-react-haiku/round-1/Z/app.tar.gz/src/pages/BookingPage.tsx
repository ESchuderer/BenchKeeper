import { useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Link, useNavigate, useParams } from "react-router";
import { ApiError, createBooking, fetchTasting, retryUnlessNotFound } from "../api.js";
import { Field } from "../components/Field.js";
import { NotFoundPanel } from "../components/NotFoundPanel.js";
import { Notice } from "../components/Notice.js";
import { TastingSummary } from "../components/TastingSummary.js";
import { bookingSchema } from "../../shared/booking-rules.js";
import { MAX_GUESTS, MESSAGES } from "../../shared/messages.js";
import type { TastingView } from "../../shared/types.js";
import { formatPrice } from "../format.js";

export function BookingPage() {
  const { id = "" } = useParams();
  const tasting = useQuery({
    queryKey: ["tasting", id],
    queryFn: () => fetchTasting(id),
    retry: retryUnlessNotFound,
  });

  if (tasting.isPending) {
    return <p className="text-muted">Loading tasting…</p>;
  }

  if (tasting.error instanceof ApiError && tasting.error.status === 404) {
    return <NotFoundPanel title="Tasting not found" message="We couldn't find that tasting." />;
  }

  if (tasting.isError) {
    return <Notice tone="error">{tasting.error.message}</Notice>;
  }

  return (
    <section className="grid gap-10 md:grid-cols-[1fr_1.2fr] md:gap-12">
      <div>
        <Link to="/" className="text-sm font-medium text-wine underline underline-offset-4">
          ← All tastings
        </Link>
        <h1 className="mt-4 font-display text-4xl leading-tight text-wine-dark">
          Book {tasting.data.title}
        </h1>
        <div className="mt-6">
          <TastingSummary tasting={tasting.data} />
        </div>
      </div>

      <div className="rounded-lg border border-gold/40 bg-parchment p-6 shadow-sm sm:p-8">
        {tasting.data.seatsLeft === 0 ? (
          <div className="space-y-5">
            <Notice tone="info">{MESSAGES.fullyBooked}</Notice>
            <Link to="/" className="inline-block font-medium text-wine underline underline-offset-4">
              See the other tastings
            </Link>
          </div>
        ) : (
          <BookingForm tasting={tasting.data} />
        )}
      </div>
    </section>
  );
}

interface BookingFormValues {
  name: string;
  email: string;
  guests: number;
}

function BookingForm({ tasting }: { tasting: TastingView }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const schema = useMemo(() => bookingSchema(tasting.seatsLeft), [tasting.seatsLeft]);
  const form = useForm<BookingFormValues>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", email: "", guests: 1 },
  });
  const { errors } = form.formState;
  const guests = form.watch("guests");
  const showTotal = Number.isInteger(guests) && guests >= 1 && guests <= MAX_GUESTS;

  const mutation = useMutation({
    mutationFn: (values: BookingFormValues) => createBooking(tasting.id, values),
    onSuccess: async (booking) => {
      await queryClient.invalidateQueries({ queryKey: ["tastings"] });
      await queryClient.invalidateQueries({ queryKey: ["tasting", tasting.id] });
      navigate(`/bookings/${booking.reference}`);
    },
    onError: (error) => {
      if (error instanceof ApiError && Object.keys(error.errors).length > 0) {
        for (const [field, message] of Object.entries(error.errors)) {
          form.setError(field as keyof BookingFormValues, { type: "server", message });
        }
      }
    },
  });

  const submitError =
    mutation.error && !(mutation.error instanceof ApiError && Object.keys(mutation.error.errors).length > 0)
      ? mutation.error.message
      : undefined;

  return (
    <form noValidate className="space-y-5" onSubmit={form.handleSubmit((values) => mutation.mutate(values))}>
      <h2 className="font-display text-2xl text-wine-dark">Your details</h2>

      <Field id="name" label="Name" autoComplete="name" error={errors.name?.message} {...form.register("name")} />
      <Field
        id="email"
        label="Email"
        type="email"
        autoComplete="email"
        inputMode="email"
        error={errors.email?.message}
        {...form.register("email")}
      />
      <Field
        id="guests"
        label="Guests"
        type="number"
        inputMode="numeric"
        min={1}
        max={MAX_GUESTS}
        step={1}
        error={errors.guests?.message}
        {...form.register("guests", { valueAsNumber: true })}
      />

      <p className="flex items-baseline justify-between border-t border-gold/30 pt-5 text-sm text-muted" aria-live="polite">
        <span>Total</span>
        <span className="font-display text-xl text-ink">
          {showTotal ? formatPrice(tasting.pricePerGuest * guests) : "—"}
        </span>
      </p>

      {submitError && <Notice tone="error">{submitError}</Notice>}

      <button
        type="submit"
        disabled={mutation.isPending}
        className="w-full rounded bg-wine px-6 py-3 font-medium text-cream hover:bg-wine-dark disabled:cursor-wait disabled:opacity-60 sm:w-auto"
      >
        Book
      </button>
    </form>
  );
}
