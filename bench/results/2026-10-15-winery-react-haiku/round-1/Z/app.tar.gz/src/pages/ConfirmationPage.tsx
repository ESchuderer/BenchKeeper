import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router";
import { ApiError, fetchBooking, retryUnlessNotFound } from "../api.js";
import { NotFoundPanel } from "../components/NotFoundPanel.js";
import { Notice } from "../components/Notice.js";
import { formatPrice, formatWhen } from "../format.js";

export function ConfirmationPage() {
  const { reference = "" } = useParams();
  const booking = useQuery({
    queryKey: ["booking", reference],
    queryFn: () => fetchBooking(reference),
    retry: retryUnlessNotFound,
  });

  if (booking.isPending) {
    return <p className="text-muted">Loading booking…</p>;
  }

  if (booking.error instanceof ApiError && booking.error.status === 404) {
    return <NotFoundPanel title="Booking not found" message="We couldn't find that booking." />;
  }

  if (booking.isError) {
    return <Notice tone="error">{booking.error.message}</Notice>;
  }

  return (
    <section className="mx-auto max-w-xl">
      <div className="flex items-center gap-3">
        <span
          aria-hidden="true"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-wine text-cream"
        >
          ✓
        </span>
        <h1 className="font-display text-4xl text-wine-dark">Booking confirmed</h1>
      </div>
      <p className="mt-4 text-muted">Thank you. Your seats are reserved.</p>

      <dl className="mt-8 grid gap-x-6 gap-y-4 rounded-lg border border-gold/40 bg-parchment p-6 shadow-sm sm:grid-cols-[auto_1fr] sm:p-8">
        <dt className="text-sm font-medium text-muted">Tasting</dt>
        <dd className="font-display text-xl text-wine-dark">{booking.data.tastingTitle}</dd>
        <dt className="text-sm font-medium text-muted">Date and time</dt>
        <dd>{formatWhen(booking.data.startsAt)}</dd>
        <dt className="text-sm font-medium text-muted">Guests</dt>
        <dd>{booking.data.guests}</dd>
        <dt className="text-sm font-medium text-muted">Total price</dt>
        <dd>{formatPrice(booking.data.totalPrice)}</dd>
        <dt className="text-sm font-medium text-muted">Booking reference</dt>
        <dd className="font-mono text-lg font-semibold tracking-wider">{booking.data.reference}</dd>
      </dl>

      <p className="mt-6 text-sm text-muted">Please quote your booking reference when you arrive.</p>
      <Link to="/" className="mt-6 inline-block font-medium text-wine underline underline-offset-4">
        Back to all tastings
      </Link>
    </section>
  );
}
