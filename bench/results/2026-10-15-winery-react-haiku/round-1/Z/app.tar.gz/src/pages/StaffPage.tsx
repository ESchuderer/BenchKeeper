import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ApiError, cancelBooking, fetchStaffBookings, staffSignIn, staffSignOut } from "../api.js";
import { Field } from "../components/Field.js";
import { Notice } from "../components/Notice.js";
import { formatWhen } from "../format.js";
import { MESSAGES } from "../../shared/messages.js";
import type { StaffTastingGroup } from "../../shared/types.js";

export function StaffPage() {
  const bookings = useQuery({
    queryKey: ["staff", "bookings"],
    queryFn: fetchStaffBookings,
    retry: false,
  });

  if (bookings.isPending) {
    return <p className="text-muted">Loading…</p>;
  }

  if (bookings.error instanceof ApiError && bookings.error.status === 401) {
    return <SignInForm />;
  }

  if (bookings.isError) {
    return <Notice tone="error">{bookings.error.message}</Notice>;
  }

  return <BookingsList groups={bookings.data} />;
}

function SignInForm() {
  const queryClient = useQueryClient();
  const form = useForm<{ password: string }>({ defaultValues: { password: "" } });
  const { errors } = form.formState;
  const [formError, setFormError] = useState<string | undefined>();

  const mutation = useMutation({
    mutationFn: ({ password }: { password: string }) => staffSignIn(password),
    onSuccess: async () => {
      setFormError(undefined);
      await queryClient.invalidateQueries({ queryKey: ["staff"] });
    },
    onError: (error) => {
      if (error instanceof ApiError && (error.status === 401 || error.status === 429)) {
        form.setError("password", { type: "server", message: error.message });
        return;
      }
      setFormError(error.message);
    },
  });

  return (
    <section className="mx-auto max-w-md">
      <h1 className="font-display text-4xl text-wine-dark">Staff sign-in</h1>
      <p className="mt-3 text-muted">Enter the staff password to see the bookings.</p>

      <div className="mt-8 rounded-lg border border-gold/40 bg-parchment p-6 shadow-sm sm:p-8">
        <form
          noValidate
          className="space-y-5"
          onSubmit={form.handleSubmit((values) => mutation.mutate({ password: values.password }))}
        >
          <Field
            id="password"
            label="Password"
            type="password"
            autoComplete="current-password"
            error={errors.password?.message}
            {...form.register("password", {
              validate: (value) => value.trim() !== "" || MESSAGES.staffPasswordRequired,
            })}
          />
          {formError && <Notice tone="error">{formError}</Notice>}
          <button
            type="submit"
            disabled={mutation.isPending}
            className="w-full rounded bg-wine px-6 py-3 font-medium text-cream hover:bg-wine-dark disabled:cursor-wait disabled:opacity-60"
          >
            Sign in
          </button>
        </form>
      </div>
    </section>
  );
}

function BookingsList({ groups }: { groups: StaffTastingGroup[] }) {
  const queryClient = useQueryClient();
  const [actionError, setActionError] = useState<string | undefined>();

  const cancel = useMutation({
    mutationFn: (reference: string) => cancelBooking(reference),
    onSuccess: async () => {
      setActionError(undefined);
      await refreshAfterChange();
    },
    onError: async (error) => {
      // Signed out, or the booking was already cancelled elsewhere: show what is current.
      if (error instanceof ApiError && (error.status === 401 || error.status === 404)) {
        await refreshAfterChange();
        return;
      }
      setActionError("We couldn't cancel that booking. Please try again.");
    },
  });

  async function refreshAfterChange() {
    await queryClient.invalidateQueries({ queryKey: ["staff"] });
    await queryClient.invalidateQueries({ queryKey: ["tastings"] });
  }

  const signOut = useMutation({
    mutationFn: staffSignOut,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["staff"] }),
  });

  function confirmCancel(name: string, reference: string) {
    if (window.confirm(`Cancel booking ${reference} for ${name}? Their seats will be released.`)) {
      cancel.mutate(reference);
    }
  }

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-4xl text-wine-dark">Bookings</h1>
        <button
          type="button"
          onClick={() => signOut.mutate()}
          className="rounded border border-wine px-4 py-2 text-sm font-medium text-wine hover:bg-wine hover:text-cream"
        >
          Sign out
        </button>
      </div>

      {actionError && <Notice tone="error" className="mt-6">{actionError}</Notice>}

      <div className="mt-10 space-y-12">
        {groups.map((group) => {
          const headingId = `group-${group.id}`;
          return (
            <section key={group.id} aria-labelledby={headingId}>
              <h2 id={headingId} className="font-display text-2xl text-wine-dark">
                {group.title}
              </h2>
              <p className="mt-1 text-sm text-muted">
                {formatWhen(group.startsAt)} · {group.bookedSeats} of {group.seats} seats booked
              </p>

              {group.bookings.length === 0 ? (
                <p className="mt-4 rounded border border-dashed border-muted/40 px-4 py-6 text-center text-muted">
                  No bookings yet
                </p>
              ) : (
                <div className="relative mt-4 overflow-x-auto rounded-lg border border-gold/40 bg-parchment">
                  <table className="w-full min-w-[36rem] border-collapse text-left text-sm">
                    <thead>
                      <tr className="border-b border-gold/50">
                        <th scope="col" className="px-4 py-3 font-medium">Name</th>
                        <th scope="col" className="px-4 py-3 font-medium">Email</th>
                        <th scope="col" className="px-4 py-3 font-medium">Guests</th>
                        <th scope="col" className="px-4 py-3 font-medium">Reference</th>
                        <th scope="col" className="px-4 py-3">
                          <span className="sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {group.bookings.map((booking) => (
                        <tr key={booking.reference} className="border-b border-gold/20 last:border-b-0">
                          <td className="px-4 py-3 font-medium">{booking.name}</td>
                          <td className="px-4 py-3 break-words text-muted">{booking.email}</td>
                          <td className="px-4 py-3">{booking.guests}</td>
                          <td className="px-4 py-3 font-mono">{booking.reference}</td>
                          <td className="px-4 py-3 text-right">
                            <button
                              type="button"
                              disabled={cancel.isPending}
                              onClick={() => confirmCancel(booking.name, booking.reference)}
                              className="rounded border border-wine px-3 py-1.5 text-wine hover:bg-wine hover:text-cream disabled:opacity-60"
                            >
                              Cancel
                              <span className="sr-only"> booking {booking.reference}</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          );
        })}
      </div>
    </section>
  );
}
