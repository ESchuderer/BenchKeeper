import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router";
import { fetchTastings } from "../api.js";
import { Notice } from "../components/Notice.js";
import { formatPrice, formatWhen } from "../format.js";
import { seatsLeftText } from "../../shared/messages.js";

export function TastingsPage() {
  const tastings = useQuery({ queryKey: ["tastings"], queryFn: fetchTastings });

  return (
    <section aria-labelledby="tastings-heading">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-wine">Tasting room</p>
      <h1 id="tastings-heading" className="mt-2 font-display text-4xl text-wine-dark sm:text-5xl">
        Wine tastings
      </h1>
      <p className="mt-3 max-w-2xl text-muted">
        Choose a tasting and reserve your seats online. Prices are per guest.
      </p>

      {tastings.isPending && <p className="mt-10 text-muted">Loading tastings…</p>}
      {tastings.isError && (
        <Notice tone="error" className="mt-10">
          We couldn't load the tastings. Please try again in a moment.
        </Notice>
      )}

      {tastings.data && (
        <ul className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {tastings.data.map((tasting) => {
            const fullyBooked = tasting.seatsLeft === 0;
            return (
              <li key={tasting.id} className="flex">
                <article
                  className={`flex w-full flex-col rounded-lg border bg-parchment p-6 shadow-sm ${
                    fullyBooked ? "border-muted/30" : "border-gold/40"
                  }`}
                >
                  <h2 className="font-display text-2xl leading-snug text-wine-dark">{tasting.title}</h2>
                  <p className="mt-3 text-sm">{formatWhen(tasting.startsAt)}</p>
                  <p className="mt-1 text-sm">{formatPrice(tasting.pricePerGuest)} per guest</p>

                  <p className="mt-4">
                    {fullyBooked ? (
                      <span className="inline-block rounded-full bg-muted/15 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted">
                        Fully booked
                      </span>
                    ) : (
                      <span className="inline-block rounded-full bg-gold/20 px-3 py-1 text-xs font-semibold tracking-wide text-wine-dark">
                        {seatsLeftText(tasting.seatsLeft)}
                      </span>
                    )}
                  </p>

                  {!fullyBooked && (
                    <div className="mt-auto pt-6">
                      <Link
                        to={`/tastings/${tasting.id}/book`}
                        className="inline-flex w-full justify-center rounded bg-wine px-4 py-3 text-center font-medium text-cream hover:bg-wine-dark"
                      >
                        Book {tasting.title}
                      </Link>
                    </div>
                  )}
                </article>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
