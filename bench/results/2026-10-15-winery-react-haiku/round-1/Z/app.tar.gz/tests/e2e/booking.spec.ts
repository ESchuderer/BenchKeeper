import { expect, test, type Page } from "@playwright/test";

const bookButton = (page: Page) => page.getByRole("button", { name: "Book", exact: true });

test.describe("booking a tasting", () => {
  test("the Book link opens the booking form with Name, Email and Guests", async ({ page }) => {
    await page.goto("/");

    await page.getByRole("link", { name: "Book Riesling Evening", exact: true }).click();

    await expect(page).toHaveURL(/\/tastings\/riesling-evening\/book$/);
    await expect(page.getByRole("heading", { name: "Book Riesling Evening" })).toBeVisible();
    await expect(page.getByLabel("Name", { exact: true })).toBeVisible();
    await expect(page.getByLabel("Email", { exact: true })).toBeVisible();
    await expect(page.getByLabel("Guests", { exact: true })).toBeVisible();
    await expect(bookButton(page)).toBeVisible();
  });

  test("shows each invalid field's error next to that field and keeps the input", async ({ page }) => {
    await page.goto("/tastings/riesling-evening/book");

    await page.getByLabel("Email", { exact: true }).fill("not-an-email");
    await page.getByLabel("Guests", { exact: true }).fill("9");
    await bookButton(page).click();

    await expect(page.getByLabel("Name", { exact: true })).toHaveAccessibleDescription(
      "Please enter your name.",
    );
    await expect(page.getByLabel("Email", { exact: true })).toHaveAccessibleDescription(
      "Please enter a valid email address.",
    );
    await expect(page.getByLabel("Guests", { exact: true })).toHaveAccessibleDescription(
      "Guests must be a whole number from 1 to 8.",
    );
    await expect(page.getByLabel("Email", { exact: true })).toHaveValue("not-an-email");
  });

  test("refuses more guests than seats left, next to the Guests field", async ({ page }) => {
    // Riesling Evening starts with 12 seats. This test is the only one that
    // books it, so after 8 guests exactly 4 seats remain.
    await page.goto("/tastings/riesling-evening/book");
    await page.getByLabel("Name", { exact: true }).fill("Large Party");
    await page.getByLabel("Email", { exact: true }).fill("party@example.com");
    await page.getByLabel("Guests", { exact: true }).fill("8");
    await bookButton(page).click();
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

    await page.goto("/tastings/riesling-evening/book");
    await expect(page.getByText("4 seats left")).toBeVisible();
    await page.getByLabel("Name", { exact: true }).fill("Seat Test");
    await page.getByLabel("Email", { exact: true }).fill("seats@example.com");
    await page.getByLabel("Guests", { exact: true }).fill("5");
    await bookButton(page).click();

    await expect(page.getByLabel("Guests", { exact: true })).toHaveAccessibleDescription(
      "Only 4 seats left for this tasting.",
    );
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toHaveCount(0);
  });

  test("books seats and shows the confirmation, which survives a reload", async ({ page }) => {
    await page.goto("/tastings/winter-tasting/book");

    await page.getByLabel("Name", { exact: true }).fill("Anna Keller");
    await page.getByLabel("Email", { exact: true }).fill("anna@example.com");
    await page.getByLabel("Guests", { exact: true }).fill("2");
    await expect(page.getByText("EUR 56")).toBeVisible();
    await bookButton(page).click();

    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
    await expect(page.getByText("Winter Tasting").first()).toBeVisible();
    await expect(page.getByText("EUR 56").first()).toBeVisible();
    await expect(page.getByText(/KB-[A-HJ-NP-Z2-9]{6}/).first()).toBeVisible();

    await page.reload();
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
    await expect(page.getByText("EUR 56").first()).toBeVisible();
  });

  test("a fully booked tasting offers no form and is marked on the start page", async ({ page }) => {
    await page.goto("/tastings/red-wine-cellar-tour/book");
    await page.getByLabel("Name", { exact: true }).fill("Full House");
    await page.getByLabel("Email", { exact: true }).fill("full@example.com");
    await page.getByLabel("Guests", { exact: true }).fill("8");
    await bookButton(page).click();
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

    await page.goto("/tastings/red-wine-cellar-tour/book");
    await expect(page.getByText("This tasting is fully booked.")).toBeVisible();
    await expect(page.getByLabel("Guests", { exact: true })).toHaveCount(0);

    await page.goto("/");
    const card = page.getByRole("article").filter({ hasText: "Red Wine Cellar Tour" });
    await expect(card).toContainText("Fully booked");
    await expect(card.getByRole("link")).toHaveCount(0);
  });

  test("when the server cannot be reached, says so and books nothing", async ({ page }) => {
    await page.goto("/tastings/winter-tasting/book");
    await page.getByLabel("Name", { exact: true }).fill("Offline Guest");
    await page.getByLabel("Email", { exact: true }).fill("offline@example.com");
    await page.getByLabel("Guests", { exact: true }).fill("1");
    await page.route("**/api/tastings/winter-tasting/bookings", (route) => route.abort());

    await bookButton(page).click();

    await expect(page.getByRole("alert")).toContainText("We couldn't reach the server, so we can't confirm your booking.");
    await expect(page).toHaveURL(/\/tastings\/winter-tasting\/book$/);
  });

  test("the Book button is disabled while the booking is being sent", async ({ page }) => {
    await page.goto("/tastings/winter-tasting/book");
    await page.getByLabel("Name", { exact: true }).fill("Slow Network");
    await page.getByLabel("Email", { exact: true }).fill("slow@example.com");
    await page.getByLabel("Guests", { exact: true }).fill("1");
    await page.route("**/api/tastings/winter-tasting/bookings", async (route) => {
      await new Promise((resolve) => setTimeout(resolve, 800));
      await route.continue();
    });

    await bookButton(page).click();
    await expect(bookButton(page)).toBeDisabled();
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  });

  test("an unknown tasting shows a not-found message", async ({ page }) => {
    await page.goto("/tastings/no-such-tasting/book");

    await expect(page.getByRole("heading", { name: "Tasting not found" })).toBeVisible();
  });

  test("an unknown booking reference shows a not-found message", async ({ page }) => {
    await page.goto("/bookings/KB-ZZZZZZ");

    await expect(page.getByText("We couldn't find that booking.")).toBeVisible();
  });
});
