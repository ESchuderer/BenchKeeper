/** Must match the password the e2e web servers are started with (playwright.config.ts). */
export const STAFF_PASSWORD = "e2e-staff-password";
