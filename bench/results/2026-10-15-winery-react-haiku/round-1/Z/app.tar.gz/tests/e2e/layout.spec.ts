import { expect, test } from "@playwright/test";
import { STAFF_PASSWORD } from "./helpers.js";

const pages = [
  { name: "tasting list", path: "/" },
  { name: "booking form", path: "/tastings/winter-tasting/book" },
  { name: "staff sign-in", path: "/staff" },
  { name: "not-found page", path: "/no-such-page" },
];

async function horizontalOverflow(page: import("@playwright/test").Page) {
  return page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
}

test.describe("layout on small screens", () => {
  test.use({ viewport: { width: 375, height: 812 } });

  for (const { name, path } of pages) {
    test(`${name} does not scroll sideways at 375px`, async ({ page }) => {
      await page.goto(path);
      await expect(page.getByRole("heading").first()).toBeVisible();

      expect(await horizontalOverflow(page)).toBeLessThanOrEqual(0);
    });
  }

  test("the staff bookings page does not scroll sideways at 375px", async ({ page }) => {
    await page.goto("/staff");
    await page.getByLabel("Password", { exact: true }).fill(STAFF_PASSWORD);
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Bookings", exact: true })).toBeVisible();

    expect(await horizontalOverflow(page)).toBeLessThanOrEqual(0);
  });
});

test("pages load nothing from third-party hosts", async ({ page, baseURL }) => {
  const origin = new URL(baseURL ?? "http://localhost").origin;
  const foreign: string[] = [];
  page.on("request", (request) => {
    const url = new URL(request.url());
    if (url.origin !== origin && url.protocol !== "data:" && url.protocol !== "blob:") {
      foreign.push(request.url());
    }
  });

  for (const { path } of pages) {
    await page.goto(path);
    await page.waitForLoadState("networkidle");
  }

  expect(foreign).toEqual([]);
});
