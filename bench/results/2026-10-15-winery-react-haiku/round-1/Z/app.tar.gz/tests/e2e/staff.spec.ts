import { expect, test, type Page } from "@playwright/test";
import { STAFF_PASSWORD } from "./helpers.js";

const signInButton = (page: Page) => page.getByRole("button", { name: "Sign in", exact: true });
const passwordField = (page: Page) => page.getByLabel("Password", { exact: true });

async function signIn(page: Page) {
  await page.goto("/staff");
  await passwordField(page).fill(STAFF_PASSWORD);
  await signInButton(page).click();
  await expect(page.getByRole("heading", { name: "Bookings", exact: true })).toBeVisible();
}

async function winterBookedSeats(page: Page): Promise<number> {
  const text = await page.getByRole("region", { name: "Winter Tasting" }).textContent();
  return Number(text?.match(/(\d+) of 10 seats booked/)?.[1]);
}

async function bookAsGuest(page: Page, tastingSlug: string, name: string, email: string, guests: number) {
  await page.goto(`/tastings/${tastingSlug}/book`);
  await page.getByLabel("Name", { exact: true }).fill(name);
  await page.getByLabel("Email", { exact: true }).fill(email);
  await page.getByLabel("Guests", { exact: true }).fill(String(guests));
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  const reference = (await page.getByText(/^KB-[A-HJ-NP-Z2-9]{6}$/).textContent())?.trim() ?? "";
  expect(reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
  return reference;
}

test.describe("staff sign-in", () => {
  test("shows a Password field and a Sign in button", async ({ page }) => {
    await page.goto("/staff");

    await expect(passwordField(page)).toBeVisible();
    await expect(signInButton(page)).toBeVisible();
  });

  test("a wrong password is refused with the message next to the field", async ({ page }) => {
    await page.goto("/staff");

    await passwordField(page).fill("definitely-wrong");
    await signInButton(page).click();

    await expect(passwordField(page)).toHaveAccessibleDescription("Incorrect password.");
    await expect(page.getByRole("heading", { name: "Bookings", exact: true })).toHaveCount(0);
  });

  test("an empty password is refused with a message", async ({ page }) => {
    await page.goto("/staff");

    await signInButton(page).click();

    await expect(passwordField(page)).toHaveAccessibleDescription("Please enter the password.");
  });
});

test.describe("staff bookings", () => {
  test("shows bookings grouped by tasting, with the seat count and each booking's details", async ({ page }) => {
    const reference = await bookAsGuest(page, "winter-tasting", "Staff Visible Guest", "visible@example.com", 3);

    await signIn(page);

    const winter = page.getByRole("region", { name: "Winter Tasting" });
    await expect(winter).toContainText(/\d+ of 10 seats booked/);
    const row = winter.getByRole("row").filter({ hasText: reference });
    await expect(row).toContainText("Staff Visible Guest");
    await expect(row).toContainText("visible@example.com");
    await expect(row).toContainText("3");
  });

  test("every tasting group either lists bookings or says there are none", async ({ page }) => {
    await signIn(page);

    for (const title of ["Riesling Evening", "Red Wine Cellar Tour", "Winter Tasting"]) {
      const group = page.getByRole("region", { name: title });
      await expect(group).toContainText(/\d+ of \d+ seats booked/);
      const hasBookings = (await group.getByRole("row").count()) > 1; // header row + bookings
      if (!hasBookings) {
        await expect(group).toContainText("No bookings yet");
      }
    }
  });

  test("cancelling a booking frees its seats and removes it for the guest", async ({ page }) => {
    const reference = await bookAsGuest(page, "winter-tasting", "Cancel Me", "cancel@example.com", 2);
    await signIn(page);
    const seatsBefore = await winterBookedSeats(page);

    const row = page.getByRole("region", { name: "Winter Tasting" }).getByRole("row").filter({ hasText: reference });
    page.once("dialog", (dialog) => dialog.accept());
    await row.getByRole("button", { name: /^Cancel/ }).click();

    await expect(row).toHaveCount(0);
    await expect.poll(() => winterBookedSeats(page)).toBe(seatsBefore - 2);
    await page.goto(`/bookings/${reference}`);
    await expect(page.getByText("We couldn't find that booking.")).toBeVisible();
  });

  test("dismissing the cancellation confirmation keeps the booking", async ({ page }) => {
    const reference = await bookAsGuest(page, "winter-tasting", "Keep Me", "keep@example.com", 1);
    await signIn(page);

    const row = page.getByRole("region", { name: "Winter Tasting" }).getByRole("row").filter({ hasText: reference });
    page.once("dialog", (dialog) => dialog.dismiss());
    await row.getByRole("button", { name: /^Cancel/ }).click();

    await expect(row).toBeVisible();
    await page.reload();
    await expect(page.getByRole("region", { name: "Winter Tasting" }).getByRole("row").filter({ hasText: reference })).toBeVisible();
  });

  test("the signed-in session survives a reload, and Sign out returns to the password form", async ({ page }) => {
    await signIn(page);

    await page.reload();
    await expect(page.getByRole("heading", { name: "Bookings", exact: true })).toBeVisible();

    await page.getByRole("button", { name: "Sign out", exact: true }).click();
    await expect(passwordField(page)).toBeVisible();
    await expect(page.getByRole("heading", { name: "Bookings", exact: true })).toHaveCount(0);
  });
});
