import { expect, test } from "@playwright/test";

const tastings = [
  {
    title: "Riesling Evening",
    slug: "riesling-evening",
    date: "6 November 2026",
    time: "18:00",
    price: "EUR 25 per guest",
  },
  {
    title: "Red Wine Cellar Tour",
    slug: "red-wine-cellar-tour",
    date: "14 November 2026",
    time: "15:00",
    price: "EUR 32 per guest",
  },
  {
    title: "Winter Tasting",
    slug: "winter-tasting",
    date: "5 December 2026",
    time: "17:00",
    price: "EUR 28 per guest",
  },
];

test.describe("start page", () => {
  test("lists the three tastings with date, time, price and seats", async ({ page }) => {
    await page.goto("/");

    for (const tasting of tastings) {
      const card = page.getByRole("article").filter({
        has: page.getByRole("heading", { name: tasting.title, exact: true }),
      });
      await expect(card).toBeVisible();
      await expect(card).toContainText(tasting.date);
      await expect(card).toContainText(tasting.time);
      await expect(card).toContainText(tasting.price);
      await expect(card).toContainText(/\d+ seats? left|Fully booked/);
    }
  });

  test("offers a Book link per tasting that opens its booking page", async ({ page }) => {
    await page.goto("/");

    for (const tasting of tastings) {
      const card = page.getByRole("article").filter({
        has: page.getByRole("heading", { name: tasting.title, exact: true }),
      });
      const link = page.getByRole("link", { name: `Book ${tasting.title}`, exact: true });
      if (await card.getByText("Fully booked").count()) {
        // Fully booked tastings take no bookings, so no link is offered.
        await expect(link).toHaveCount(0);
      } else {
        await expect(link).toHaveAttribute("href", `/tastings/${tasting.slug}/book`);
      }
    }
  });

  test("says so when the tastings cannot be loaded", async ({ page }) => {
    await page.route("**/api/tastings", (route) => route.abort());

    await page.goto("/");

    await expect(page.getByRole("alert")).toContainText("We couldn't load the tastings.");
  });
});
