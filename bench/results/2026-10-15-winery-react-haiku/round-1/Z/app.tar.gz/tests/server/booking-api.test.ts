import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../../server/app.js";

const validBooking = { name: "Anna Keller", email: "anna@example.com", guests: 2 };

function bookingUrl(tastingId: string) {
  return `/api/tastings/${tastingId}/bookings`;
}

async function seatsLeft(app: ReturnType<typeof createApp>, tastingId: string) {
  const res = await request(app).get(`/api/tastings/${tastingId}`);
  return (res.body as { seatsLeft: number }).seatsLeft;
}

describe("POST /api/tastings/:id/bookings", () => {
  it("creates a booking and returns the confirmation details with 201", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app).post(bookingUrl("riesling-evening")).send(validBooking);

    expect(res.status).toBe(201);
    expect(res.body).toEqual({
      reference: expect.stringMatching(/^KB-[A-HJ-NP-Z2-9]{6}$/),
      tastingId: "riesling-evening",
      tastingTitle: "Riesling Evening",
      startsAt: "2026-11-06T18:00",
      pricePerGuest: 25,
      guests: 2,
      totalPrice: 50,
    });
  });

  it("takes seats from that tasting only", async () => {
    const app = createApp({ staffPassword: "pw" });

    await request(app).post(bookingUrl("riesling-evening")).send(validBooking).expect(201);

    expect(await seatsLeft(app, "riesling-evening")).toBe(10);
    expect(await seatsLeft(app, "red-wine-cellar-tour")).toBe(8);
    expect(await seatsLeft(app, "winter-tasting")).toBe(10);
  });

  it("rejects a missing or blank name, and takes no seats", async () => {
    const app = createApp({ staffPassword: "pw" });

    const missing = await request(app)
      .post(bookingUrl("riesling-evening"))
      .send({ email: validBooking.email, guests: 2 });
    const blank = await request(app)
      .post(bookingUrl("riesling-evening"))
      .send({ ...validBooking, name: "   " });

    expect(missing.status).toBe(400);
    expect(missing.body).toEqual({ errors: { name: "Please enter your name." } });
    expect(blank.status).toBe(400);
    expect(blank.body).toEqual({ errors: { name: "Please enter your name." } });
    expect(await seatsLeft(app, "riesling-evening")).toBe(12);
  });

  it.each(["", "anna", "anna@", "anna@example", "not an email"])(
    "rejects the invalid email %j",
    async (email) => {
      const app = createApp({ staffPassword: "pw" });

      const res = await request(app).post(bookingUrl("riesling-evening")).send({ ...validBooking, email });

      expect(res.status).toBe(400);
      expect(res.body).toEqual({ errors: { email: "Please enter a valid email address." } });
    },
  );

  it.each([0, 9, 1.5, -1, "2", null])("rejects guests %j as not a whole number from 1 to 8", async (guests) => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app).post(bookingUrl("riesling-evening")).send({ ...validBooking, guests });

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ errors: { guests: "Guests must be a whole number from 1 to 8." } });
  });

  it("rejects a guest count above the seats left, with the number of seats left", async () => {
    const app = createApp({ staffPassword: "pw" });
    await request(app).post(bookingUrl("red-wine-cellar-tour")).send({ ...validBooking, guests: 6 }).expect(201);

    const tooMany = await request(app)
      .post(bookingUrl("red-wine-cellar-tour"))
      .send({ ...validBooking, guests: 3 });

    expect(tooMany.status).toBe(400);
    expect(tooMany.body).toEqual({ errors: { guests: "Only 2 seats left for this tasting." } });
    expect(await seatsLeft(app, "red-wine-cellar-tour")).toBe(2);
  });

  it("uses the singular when one seat is left", async () => {
    const app = createApp({ staffPassword: "pw" });
    await request(app).post(bookingUrl("red-wine-cellar-tour")).send({ ...validBooking, guests: 7 }).expect(201);

    const res = await request(app).post(bookingUrl("red-wine-cellar-tour")).send({ ...validBooking, guests: 2 });

    expect(res.body).toEqual({ errors: { guests: "Only 1 seat left for this tasting." } });
  });

  it("refuses bookings once the tasting is fully booked", async () => {
    const app = createApp({ staffPassword: "pw" });
    await request(app).post(bookingUrl("red-wine-cellar-tour")).send({ ...validBooking, guests: 8 }).expect(201);

    const res = await request(app).post(bookingUrl("red-wine-cellar-tour")).send({ ...validBooking, guests: 1 });

    expect(res.status).toBe(400);
    expect(res.body).toEqual({ errors: { guests: "This tasting is fully booked." } });
  });

  it("never oversells: of two simultaneous requests for the last seat, only one succeeds", async () => {
    const app = createApp({ staffPassword: "pw" });
    await request(app).post(bookingUrl("red-wine-cellar-tour")).send({ ...validBooking, guests: 7 }).expect(201);

    const [first, second] = await Promise.all([
      request(app).post(bookingUrl("red-wine-cellar-tour")).send({ ...validBooking, guests: 1 }),
      request(app).post(bookingUrl("red-wine-cellar-tour")).send({ ...validBooking, guests: 1 }),
    ]);

    expect([first.status, second.status].sort()).toEqual([201, 400]);
    expect(await seatsLeft(app, "red-wine-cellar-tour")).toBe(0);
  });

  it("reports every invalid field at once", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app)
      .post(bookingUrl("riesling-evening"))
      .send({ name: "", email: "nope", guests: 0 });

    expect(res.status).toBe(400);
    expect(res.body).toEqual({
      errors: {
        name: "Please enter your name.",
        email: "Please enter a valid email address.",
        guests: "Guests must be a whole number from 1 to 8.",
      },
    });
  });

  it("returns 404 for an unknown tasting", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app).post(bookingUrl("no-such-tasting")).send(validBooking);

    expect(res.status).toBe(404);
    expect(res.body).toEqual({ message: "Tasting not found." });
  });

  it("answers malformed JSON with a JSON 400 rather than an HTML error page", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app)
      .post(bookingUrl("riesling-evening"))
      .set("Content-Type", "application/json")
      .send("{not json");

    expect(res.status).toBe(400);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
  });

  it("answers an oversized request with a JSON 413", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app)
      .post(bookingUrl("riesling-evening"))
      .send({ ...validBooking, name: "x".repeat(200_000) });

    expect(res.status).toBe(413);
    expect(res.body).toEqual({ message: "Request too large." });
  });

  it("keeps bookings separate between app instances", async () => {
    const first = createApp({ staffPassword: "pw" });
    const second = createApp({ staffPassword: "pw" });

    await request(first).post(bookingUrl("riesling-evening")).send(validBooking).expect(201);

    expect(await seatsLeft(first, "riesling-evening")).toBe(10);
    expect(await seatsLeft(second, "riesling-evening")).toBe(12);
  });
});

describe("GET /api/bookings/:reference", () => {
  it("returns the confirmation details without the guest's name or email", async () => {
    const app = createApp({ staffPassword: "pw" });
    const created = await request(app).post(bookingUrl("winter-tasting")).send(validBooking).expect(201);

    const res = await request(app).get(`/api/bookings/${created.body.reference}`);

    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      reference: created.body.reference,
      tastingId: "winter-tasting",
      tastingTitle: "Winter Tasting",
      startsAt: "2026-12-05T17:00",
      pricePerGuest: 28,
      guests: 2,
      totalPrice: 56,
    });
  });

  it("returns 404 for an unknown reference", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app).get("/api/bookings/KB-NOPE00");

    expect(res.status).toBe(404);
  });
});
