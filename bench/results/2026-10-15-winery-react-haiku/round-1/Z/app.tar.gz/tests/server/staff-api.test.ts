import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../../server/app.js";

const PASSWORD = "correct-horse";
const guest = { name: "Anna Keller", email: "anna@example.com", guests: 2 };

async function bookRiesling(app: ReturnType<typeof createApp>) {
  const res = await request(app).post("/api/tastings/riesling-evening/bookings").send(guest).expect(201);
  return res.body as { reference: string };
}

async function signedInStaff(app: ReturnType<typeof createApp>) {
  const staff = request.agent(app);
  await staff.post("/api/staff/session").send({ password: PASSWORD }).expect(204);
  return staff;
}

describe("staff sign-in", () => {
  it("accepts the right password with 204 and sets a session cookie", async () => {
    const app = createApp({ staffPassword: PASSWORD });

    const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });

    expect(res.status).toBe(204);
    expect(res.headers["set-cookie"]).toBeDefined();
  });

  it("sets an httpOnly, strict same-site, site-wide session cookie", async () => {
    const app = createApp({ staffPassword: PASSWORD });

    const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });

    const cookie = String(res.headers["set-cookie"]?.[0] ?? "");
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    expect(cookie).toMatch(/Path=\//i);
    expect(cookie).toMatch(/Expires=/i);
  });

  it("rejects a wrong password with 401 and a message", async () => {
    const app = createApp({ staffPassword: PASSWORD });

    const res = await request(app).post("/api/staff/session").send({ password: "guess" });

    expect(res.status).toBe(401);
    expect(res.body).toEqual({ message: "Incorrect password." });
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it.each([{}, { password: "" }, { password: "   " }, { password: 42 }])(
    "rejects an empty or missing password %j",
    async (body) => {
      const app = createApp({ staffPassword: PASSWORD });

      const res = await request(app).post("/api/staff/session").send(body);

      expect(res.status).toBe(401);
      expect(res.body.message).toMatch(/Please enter the password\.|Incorrect password\./);
    },
  );

  it("answers 503 when no staff password is configured", async () => {
    const app = createApp({});

    const res = await request(app).post("/api/staff/session").send({ password: PASSWORD });

    expect(res.status).toBe(503);
    expect(res.body).toEqual({ message: "Staff sign-in is not configured." });
  });

  it("slows down repeated wrong passwords: after 10 failures even the right password gets 429", async () => {
    const app = createApp({ staffPassword: PASSWORD });

    for (let attempt = 0; attempt < 10; attempt++) {
      await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(401);
    }
    const blocked = await request(app).post("/api/staff/session").send({ password: PASSWORD });

    expect(blocked.status).toBe(429);
    expect(blocked.body.message).toMatch(/Too many attempts/);
  });

  it("treats an empty configured password as not configured", async () => {
    const app = createApp({ staffPassword: "" });

    const res = await request(app).post("/api/staff/session").send({ password: "" });

    expect(res.status).toBe(503);
    expect(res.body).toEqual({ message: "Staff sign-in is not configured." });
  });

  it("answers 503 without counting those attempts against the sign-in limit", async () => {
    const app = createApp({});

    for (let attempt = 0; attempt < 11; attempt++) {
      await request(app).post("/api/staff/session").send({ password: "guess" }).expect(503);
    }
  });

  it("refuses staff routes without a session", async () => {
    const app = createApp({ staffPassword: PASSWORD });

    const res = await request(app).get("/api/staff/bookings");

    expect(res.status).toBe(401);
  });

  it("does not accept a session from another app instance", async () => {
    const issuer = createApp({ staffPassword: PASSWORD });
    const other = createApp({ staffPassword: PASSWORD });
    const signIn = await request(issuer).post("/api/staff/session").send({ password: PASSWORD });
    const cookie = String(signIn.headers["set-cookie"]?.[0]).split(";")[0] ?? "";

    const res = await request(other).get("/api/staff/bookings").set("Cookie", cookie);

    expect(res.status).toBe(401);
  });

  it("does not accept a forged session cookie", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const forged = `kb_staff=${Buffer.from('{"staff":true}').toString("base64")}`;

    const res = await request(app).get("/api/staff/bookings").set("Cookie", forged);

    expect(res.status).toBe(401);
  });

  it("signs out, after which staff routes refuse again", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const staff = await signedInStaff(app);

    await staff.get("/api/staff/bookings").expect(200);
    await staff.delete("/api/staff/session").expect(204);

    await staff.get("/api/staff/bookings").expect(401);
  });

  it("a copy of the session cookie stops working once staff have signed out", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const signIn = await request(app).post("/api/staff/session").send({ password: PASSWORD }).expect(204);
    const cookie = (signIn.headers["set-cookie"] as unknown as string[])
      .map((value) => value.split(";")[0] ?? "")
      .join("; ");
    await request(app).get("/api/staff/bookings").set("Cookie", cookie).expect(200);

    await request(app).delete("/api/staff/session").set("Cookie", cookie).expect(204);

    await request(app).get("/api/staff/bookings").set("Cookie", cookie).expect(401);
  });
});

describe("GET /api/staff/bookings", () => {
  it("lists every tasting in order, with booked seats and its bookings", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const booking = await bookRiesling(app);
    const staff = await signedInStaff(app);

    const res = await staff.get("/api/staff/bookings").expect(200);

    expect(res.body).toEqual([
      {
        id: "riesling-evening",
        title: "Riesling Evening",
        startsAt: "2026-11-06T18:00",
        seats: 12,
        bookedSeats: 2,
        bookings: [
          { reference: booking.reference, name: "Anna Keller", email: "anna@example.com", guests: 2 },
        ],
      },
      {
        id: "red-wine-cellar-tour",
        title: "Red Wine Cellar Tour",
        startsAt: "2026-11-14T15:00",
        seats: 8,
        bookedSeats: 0,
        bookings: [],
      },
      {
        id: "winter-tasting",
        title: "Winter Tasting",
        startsAt: "2026-12-05T17:00",
        seats: 10,
        bookedSeats: 0,
        bookings: [],
      },
    ]);
  });
});

describe("DELETE /api/staff/bookings/:reference", () => {
  it("cancels the booking, frees its seats and removes it for the guest", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const booking = await bookRiesling(app);
    const staff = await signedInStaff(app);

    await staff.delete(`/api/staff/bookings/${booking.reference}`).expect(204);

    const tasting = await request(app).get("/api/tastings/riesling-evening");
    expect(tasting.body.seatsLeft).toBe(12);
    await request(app).get(`/api/bookings/${booking.reference}`).expect(404);
    const groups = await staff.get("/api/staff/bookings");
    expect(groups.body[0].bookings).toEqual([]);
  });

  it("returns 404 for an unknown reference", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const staff = await signedInStaff(app);

    await staff.delete("/api/staff/bookings/KB-NOPE00").expect(404);
  });

  it("refuses without a session and leaves the booking in place", async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const booking = await bookRiesling(app);

    await request(app).delete(`/api/staff/bookings/${booking.reference}`).expect(401);

    await request(app).get(`/api/bookings/${booking.reference}`).expect(200);
  });
});
