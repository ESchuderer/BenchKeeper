import { mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../../server/app.js";

function makeClientDir(): string {
  const dir = mkdtempSync(path.join(tmpdir(), "kb-client-"));
  writeFileSync(path.join(dir, "index.html"), "<!doctype html><title>kb app</title>");
  mkdirSync(path.join(dir, "assets"));
  writeFileSync(path.join(dir, "assets", "app.js"), "console.log('kb');");
  return dir;
}

describe("serving the built client", () => {
  it("serves the app page for in-app paths, so reloads work", async () => {
    const app = createApp({ staffPassword: "pw", clientDir: makeClientDir() });

    const res = await request(app).get("/tastings/winter-tasting/book").set("Accept", "text/html");

    expect(res.status).toBe(200);
    expect(res.text).toContain("<title>kb app</title>");
  });

  it("serves built files as they are", async () => {
    const app = createApp({ staffPassword: "pw", clientDir: makeClientDir() });

    const res = await request(app).get("/assets/app.js");

    expect(res.status).toBe(200);
    expect(res.text).toBe("console.log('kb');");
  });

  it("does not answer a missing script with the app page", async () => {
    const app = createApp({ staffPassword: "pw", clientDir: makeClientDir() });

    const res = await request(app).get("/assets/missing.js").set("Accept", "text/html");

    expect(res.status).toBe(404);
    expect(res.text).not.toContain("kb app");
  });

  it("does not answer unknown API paths with the app page", async () => {
    const app = createApp({ staffPassword: "pw", clientDir: makeClientDir() });

    const res = await request(app).get("/api/unknown").set("Accept", "text/html");

    expect(res.status).toBe(404);
    expect(res.body).toEqual({ message: "Not found." });
  });
});
