import { describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../../server/app.js";

const riesling = {
  id: "riesling-evening",
  title: "Riesling Evening",
  startsAt: "2026-11-06T18:00",
  pricePerGuest: 25,
  seats: 12,
  seatsLeft: 12,
};

const redWine = {
  id: "red-wine-cellar-tour",
  title: "Red Wine Cellar Tour",
  startsAt: "2026-11-14T15:00",
  pricePerGuest: 32,
  seats: 8,
  seatsLeft: 8,
};

const winter = {
  id: "winter-tasting",
  title: "Winter Tasting",
  startsAt: "2026-12-05T17:00",
  pricePerGuest: 28,
  seats: 10,
  seatsLeft: 10,
};

describe("GET /api/tastings", () => {
  it("lists the three tastings, all seats left on a fresh app", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app).get("/api/tastings");

    expect(res.status).toBe(200);
    expect(res.body).toEqual([riesling, redWine, winter]);
  });

});

describe("GET /api/tastings/:id", () => {
  it("returns one tasting", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app).get("/api/tastings/winter-tasting");

    expect(res.status).toBe(200);
    expect(res.body).toEqual(winter);
  });

  it("returns 404 for an unknown tasting", async () => {
    const app = createApp({ staffPassword: "pw" });

    const res = await request(app).get("/api/tastings/no-such-tasting");

    expect(res.status).toBe(404);
  });
});
