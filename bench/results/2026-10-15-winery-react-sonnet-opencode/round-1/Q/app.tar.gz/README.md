# Weingut Kieselbrunnen - tasting bookings

Guests book wine tastings online; staff see and cancel bookings at `/staff`.

React single-page app (Vite, React Router, TanStack Query, react-hook-form, Tailwind CSS) served by a small Express server. Requires Node.js 22.

## Run

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start
```

The app listens on `PORT` (default `3000`). Open <http://localhost:3000>.

| Variable | Purpose |
|---|---|
| `STAFF_PASSWORD` | Password for `/staff`. If unset or empty nobody can sign in. |
| `PORT` | HTTP port, default `3000`. |
| `TRUST_PROXY` | Set to `1` when the app runs behind one TLS-terminating reverse proxy, so the staff cookie is marked `Secure` and the sign-in rate limit sees real client addresses. |

Bookings are kept **in memory**: the app starts with no bookings and a restart discards them.
The tastings themselves are defined in `src/server/tastings.ts`.

## Develop

```sh
npm run dev          # API on :3000 with reload (set STAFF_PASSWORD)
npm run dev:client   # Vite dev server with /api proxied to :3000
```

## Test

```sh
npm test             # unit, API and component tests (Vitest)
npm run typecheck
npm run lint
npx playwright install --with-deps chromium   # once
npm run test:e2e     # end-to-end tests against the built app (run `npm run build` first)
```

## HTTP API

JSON over HTTP. Errors have the shape `{ "error": { "code", "message", "fields"? } }`, where `fields` maps `name`, `email`, `guests` or `password` to the message shown beside that field.

| Method and path | Purpose |
|---|---|
| `GET /api/tastings` | Tastings with `seatsLeft` and `soldOut` |
| `GET /api/tastings/:id` | One tasting, 404 if unknown |
| `POST /api/tastings/:id/bookings` | Book `{ name, email, guests }`. 201 with the confirmation, 422 for invalid input, 409 when seats are short (`not_enough_seats`) or gone (`sold_out`) |
| `GET /api/bookings/:reference` | Confirmation summary (no name or e-mail) |
| `POST /api/staff/session` | Sign in `{ password }`; sets an httpOnly, SameSite=Strict cookie. 10 failed attempts per 15 minutes per IP, then 429 |
| `GET /api/staff/session` / `DELETE /api/staff/session` | Check / end the session |
| `GET /api/staff/bookings` | Bookings grouped by tasting (staff only) |
| `DELETE /api/staff/bookings/:reference` | Cancel a booking and free its seats (staff only) |

## Known limitations

- Bookings live in memory: a restart discards them, and the app must run as a single process.
- Public booking has no rate limit or captcha; a bot could fill a tasting with fake bookings, which staff can cancel.
- Staff share one password; there are no individual accounts.
- The date and time of a tasting is the winery's local time; booking is not closed once a tasting has started.
