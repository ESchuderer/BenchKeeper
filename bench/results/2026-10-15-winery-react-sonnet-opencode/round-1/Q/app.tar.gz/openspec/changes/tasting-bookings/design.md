# Design

## Context

Greenfield repository (only OpenSpec and agent tooling exist). Constraints from the brief: React interface, Node.js 22, `npm install` / `npm run build` / `npm start` serving the whole app on `PORT` (default 3000), no external services, empty booking state on start, English UI. Motivation and scope: see proposal.md. Behaviour: see the four specs.

## Goals / Non-Goals

**Goals:**
- One deployable Node process serving both the JSON API and the built React app.
- The seat limit is enforced on the server, atomically, and re-validated there regardless of client checks.
- Validation rules are written once and shared by browser and server so error messages match.
- Reach for maintained libraries for routing, forms, validation, data fetching, styling, HTTP security.

**Non-Goals:**
- Persistence across restarts, payments, e-mail, multi-user staff accounts, editing tastings, i18n, server-side rendering.
- Blocking bookings for tastings whose start time has passed (not requested; would also make behaviour depend on the wall clock).

## Decisions

**D1. Vite + React 19 + React Router (declarative) SPA, Express 5 API in one TypeScript package.**
Alternatives: Next.js / React Router framework mode (SSR). Rejected: SSR brings a build/runtime surface the brief does not need; a SPA served by Express keeps `npm start` trivial and the app small. Express is the most established Node server, with first-class middleware for the security needs below. Server is bundled with tsup to `dist/server`, client with Vite to `dist/client`.

**D2. In-memory store as a plain class with synchronous methods.**
Node runs JS on one thread, so a synchronous "check seats left, then insert" has no interleaving: concurrent requests are serialised and the seat limit cannot be exceeded. No lock or transaction needed. Alternatives: JSON file (explicit "starts with no bookings" would be violated by a leftover file; adds fs error handling) and SQLite (new native dependency). Trade-off: a restart loses bookings; documented in the README. The store sits behind a small interface (`listTastings`, `book`, `cancel`, `findByReference`, `bookingsByTasting`) so a persistent implementation can replace it.

**D3. Tastings are static data in the server (`tastings.ts`); prices are integer cents.**
Date and time is kept as the local wall-clock string "YYYY-MM-DD HH:mm" (winery's time zone, no conversion), which is exactly what is displayed. Money is integer cents and formatted in one shared function as "EUR 25" (or "EUR 25.50" when not whole), avoiding float arithmetic for totals.

**D4. Shared zod schema (`src/shared/booking.ts`) used by client and server.**
react-hook-form with the zod resolver gives instant field errors; the server parses the same schema and returns `{ error: { code: "validation", fields: { name?, email?, guests? } } }`. The server additionally checks seats and returns the failure on the `guests` field (`code: "not_enough_seats"` / `"sold_out"`). The client maps any server field errors back onto the form, so a lost race still shows the message beside the Guests field. The form uses `noValidate` and text-level messages instead of the browser's native bubbles so that error placement and wording are ours and consistent. Guests is a numeric input; empty or non-integer input is coerced into a validation error rather than silently defaulted.

**D5. API surface.**
- `GET /api/tastings` , `GET /api/tastings/:id` (with `seatsLeft`, `soldOut`)
- `POST /api/tastings/:id/bookings` -> 201 `{ reference, tasting, guests, totalCents }`
- `GET /api/bookings/:reference` -> same summary, no name or e-mail (powers reload of the confirmation; a 40-bit random reference is enough for non-personal data). Cancelled bookings return 404.
- `POST /api/staff/session`, `GET /api/staff/session`, `DELETE /api/staff/session`
- `GET /api/staff/bookings` (grouped by tasting), `DELETE /api/staff/bookings/:reference`
Unknown `/api/*` returns JSON 404; every other GET falls through to `index.html` for client routing.

**D6. Staff authentication.**
Single shared password from `STAFF_PASSWORD`, read once at startup and passed into `createApp`. Comparison via SHA-256 digests with `timingSafeEqual`. If unset/empty, login always fails and a warning is logged at startup (fail closed; no default password). Sessions are server-side (`express-session` with the `memorystore` store, which prunes expired entries): an opaque cookie (httpOnly, SameSite=Strict, `secure: 'auto'`, which needs the optional `TRUST_PROXY` setting behind a TLS-terminating proxy, 8 h) so that sign-out really revokes access, and the id is regenerated on login. `express-rate-limit` on the login route (10 failed attempts per 15 min per IP, successful logins not counted). CSRF: SameSite=Strict cookie and JSON-only bodies. Alternatives: signed stateless cookie or JWT (cannot be revoked at sign-out), a database-backed session store (no gain for one password).

**D7. Security headers and hygiene.**
`helmet` with its default CSP (all assets are same-origin; fonts are self-hosted through `@fontsource`, no CDN). JSON body limit 10 kB. `x-powered-by` off. Errors never leak stack traces; unexpected errors are logged and return a generic 500. Booking events (created, cancelled, failed login) are logged as single structured lines without e-mail addresses.

**D8. Data fetching with TanStack Query.**
Seat counts must be fresh whenever the start page or form is shown: queries use `staleTime: 0` and refetch on mount; successful booking and cancellation invalidate the affected queries. Failures are retried once unless the server gave a definite 4xx answer. Query errors render an inline error state with "Try again".

**D9. Styling with Tailwind CSS v4 and a small set of design tokens.**
Palette drawn from wine and stone (burgundy accent, cream background, dark slate text; contrast checked against WCAG AA), a serif display face (Fraunces, self-hosted) for headings, system sans for body. A handful of reusable components (`Button`, `Field`, `Badge`, `Alert`, `Card`) hold the state styling so errors, success and fully booked look identical everywhere. Staff tables collapse into stacked cards below 640 px instead of scrolling horizontally. Alternatives: a component kit (MUI) - heavier and generic look; hand-rolled CSS - more code to maintain.

**D10. Test strategy (pyramid).**
Vitest for everything unit/integration: store and schema (small), the HTTP API through Supertest against `createApp()` with an injected store and password (medium), React Testing Library for pages with a mocked `fetch` boundary only (medium). A small Playwright suite runs the built app end to end (guest books, sold-out, staff cancels, phone viewport). Tests are written before the code they cover.

**D11. Layout.**
`src/shared` (schema, money, types), `src/server` (`app.ts` factory, `index.ts` entry, `store.ts`, `tastings.ts`, `staffAuth.ts`), `src/client` (`main.tsx`, `routes`, `pages`, `components`, `api`), `tests/e2e`. `createApp({ store, staffPassword })` takes its dependencies as arguments so tests never touch process env or ports.

## Risks / Trade-offs

- [Restart loses bookings] -> Documented; store interface allows a file-backed implementation later.
- [Single shared staff password, brute force] -> Rate limiting, constant-time compare, fail closed when unset.
- [Staff cancels by mistake: no confirmation dialog] -> Dialogs are hostile to assistive tech and automation; the action posts a visible status message naming the cancelled booking. Accepted for a small winery; an undo is out of scope.
- [Reference guessing] -> Reference only reveals non-personal data and cannot be used to modify anything.
- [Single process memory store cannot scale horizontally] -> Acceptable for a single-site winery; noted in README.
- [Playwright needs a browser download] -> E2E is a separate script (`npm run test:e2e`) so the unit suite and the build never depend on it.
