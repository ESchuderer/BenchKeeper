# Proposal

## Why

Weingut Kieselbrunnen, a family winery, takes tasting reservations by phone and mail today. Guests cannot see which tastings still have room, and staff have no single place to see who is coming. An online booking page and a staff overview remove the back-and-forth and prevent overbooking.

## What Changes

- New public web app: a start page listing the three offered tastings with date and time, price per guest and seats left.
- A booking form per tasting (Name, Email, Guests 1 to 8) with field-level validation and a hard guarantee that a booking never takes more seats than are left.
- A booking confirmation (heading "Booking confirmed") with tasting, guests, total price and a booking reference.
- A password-protected `/staff` page (password from `STAFF_PASSWORD`) listing bookings grouped by tasting, with a "Cancel" action that frees the seats.
- A coherent winery look and feel with clear error, success and fully-booked states, usable on a phone.
- Delivery: React front end, Node.js 22 server, `npm install` / `npm run build` / `npm start` on `PORT` (default 3000), bookings start empty and are kept in memory.

## Capabilities

### New Capabilities
- `tasting-catalog`: the offered tastings and the start page that presents them with live seat availability and fully-booked state.
- `tasting-booking`: the guest booking form, input validation, seat-limit guarantee and booking confirmation.
- `staff-booking-management`: password-protected staff sign-in, bookings grouped by tasting, and cancellation that frees seats.
- `site-presentation`: visual identity, state styling, responsiveness and accessibility baseline shared by all pages.

### Modified Capabilities
<!-- None: the project has no existing specs. -->

## Impact

- Greenfield project: new `package.json`, server, client, tests and documentation in `/work`.
- New runtime dependencies (React, React Router, TanStack Query, react-hook-form, zod, Express, helmet, express-session, memorystore, express-rate-limit) and dev tooling (Vite, Tailwind CSS, TypeScript, Vitest, Testing Library, Supertest, Playwright).
- Configuration surface: `STAFF_PASSWORD` (required for staff sign-in) and `PORT`.
- Out of scope: payment, e-mail notifications, editing the tasting catalogue, persistence across restarts, multiple staff accounts, booking-cutoff times.
