# Spec Delta

## Purpose

Makes every page feel like the winery's own small site and keeps all states understandable on any screen size and for assistive technology.

## ADDED Requirements

### Requirement: Winery visual identity
All pages SHALL share one coherent visual design (colour palette, typography, spacing, header with the winery name "Weingut Kieselbrunnen", footer) that reads as a small family winery's site.

#### Scenario: Consistent shell
- **WHEN** a guest moves between the start page, the booking form, the confirmation and `/staff`
- **THEN** each page shows the same header, typography and colour scheme

### Requirement: Distinct states
Errors, success, fully-booked tastings, loading and empty states SHALL be visually and textually distinct and SHALL NOT rely on colour alone.

#### Scenario: Field error
- **WHEN** a field is invalid
- **THEN** its message appears directly beneath it with an icon or text prefix, the field is marked invalid for assistive technology and the message is programmatically associated with the field

#### Scenario: Server unreachable
- **WHEN** a request fails because the server cannot be reached
- **THEN** the page shows an error message with a way to retry instead of staying blank

### Requirement: Phone usability
Every page SHALL be usable at a 360 px wide viewport without horizontal scrolling, with touch targets of at least 44 px.

#### Scenario: Narrow viewport
- **WHEN** a page is displayed at 360 px width
- **THEN** content is fully readable and operable without horizontal scrolling, including the staff bookings list

### Requirement: Accessibility baseline
Pages SHALL use semantic landmarks and headings, labelled form controls, visible keyboard focus and sufficient text contrast; changing status messages SHALL be announced to assistive technology.

#### Scenario: Keyboard use
- **WHEN** a guest completes a booking using only the keyboard
- **THEN** every control is reachable in a logical order with a visible focus indicator
