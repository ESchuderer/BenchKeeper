# Spec Delta

## Purpose

Gives winery staff a protected overview of all bookings and the ability to cancel them, so seats can be released again.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a "Password" and offer a "Sign in" button. The accepted password SHALL be the value of the environment variable `STAFF_PASSWORD`. If that variable is unset or empty, nobody SHALL be able to sign in.

#### Scenario: Not signed in
- **WHEN** a visitor opens `/staff` without signing in
- **THEN** a Password field and a "Sign in" button are shown and no booking data is shown

#### Scenario: Wrong password
- **WHEN** a visitor submits an incorrect or empty password
- **THEN** an error is shown next to the Password field and no booking data is shown

#### Scenario: Correct password
- **WHEN** a visitor submits the correct password
- **THEN** the bookings overview is shown

#### Scenario: Password not configured
- **WHEN** `STAFF_PASSWORD` is not set and a visitor submits any password
- **THEN** sign-in is refused

### Requirement: Staff data is protected
Booking data and cancellation SHALL only be available to signed-in staff, and repeated failed sign-in attempts SHALL be rate limited.

#### Scenario: Unauthenticated data request
- **WHEN** a request for the bookings list or a cancellation is made without a staff session
- **THEN** it is refused as unauthorised and no personal data is returned

#### Scenario: Sign out
- **WHEN** a signed-in staff member presses "Sign out"
- **THEN** the sign-in form is shown again and the session no longer grants access

### Requirement: Bookings grouped by tasting
A signed-in staff member SHALL see all active bookings grouped by tasting, each showing name, email, guests and booking reference.

#### Scenario: Grouped list
- **WHEN** bookings exist for two different tastings
- **THEN** each tasting appears with its own bookings and every booking shows name, email, guests and reference

#### Scenario: No bookings
- **WHEN** a tasting has no bookings
- **THEN** its group states that there are no bookings yet

### Requirement: Cancel a booking
Staff SHALL be able to cancel a booking with a "Cancel" button. A cancelled booking SHALL disappear from the list and its seats SHALL be available again.

#### Scenario: Cancel frees seats
- **WHEN** staff press "Cancel" on a booking of 4 guests for Red Wine Cellar Tour, which then shows "4 seats left"
- **THEN** the booking disappears from the staff list and the start page shows "8 seats left"

#### Scenario: Cancelling twice
- **WHEN** a booking that was already cancelled is cancelled again
- **THEN** the system reports that the booking no longer exists and seats are not freed a second time
