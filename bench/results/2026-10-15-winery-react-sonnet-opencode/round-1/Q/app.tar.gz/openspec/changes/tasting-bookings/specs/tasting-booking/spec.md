# Spec Delta

## Purpose

Lets a guest reserve seats for a tasting online, guarantees that a tasting is never overbooked, and gives the guest proof of the booking.

## ADDED Requirements

### Requirement: Booking form
The booking form SHALL contain the fields "Name", "Email" and "Guests" (whole number 1 to 8) and a "Book" button, and SHALL state the tasting, its date and time and its price per guest.

#### Scenario: Form contents
- **WHEN** a guest opens the form for Winter Tasting
- **THEN** it shows the fields Name, Email and Guests and a "Book" button
- **AND** it shows the tasting title, "2026-12-05 17:00" and "EUR 28" per guest

### Requirement: Field validation
The system SHALL reject a booking whose Name is blank (or longer than 100 characters), whose Email is not a valid address, or whose Guests is not a whole number from 1 to 8, and SHALL show an error message next to each affected field.

#### Scenario: Empty submit
- **WHEN** a guest presses "Book" with all fields empty
- **THEN** no booking is created
- **AND** an error is shown next to Name, next to Email and next to Guests

#### Scenario: Guests out of range
- **WHEN** a guest enters 0, 9, 2.5 or text in Guests and presses "Book"
- **THEN** no booking is created and an error next to Guests says to choose 1 to 8 guests

#### Scenario: Invalid email
- **WHEN** a guest enters "not-an-email" in Email and presses "Book"
- **THEN** no booking is created and an error is shown next to Email

#### Scenario: Server-side enforcement
- **WHEN** a booking request that violates these rules reaches the server without passing through the form
- **THEN** the server rejects it with the same field-level errors and creates no booking

### Requirement: Seat limit
A booking SHALL NEVER take more seats than are left for its tasting, including when several guests book at the same time.

#### Scenario: More guests than seats left
- **WHEN** 3 seats are left and a guest requests 4
- **THEN** no booking is created and an error next to Guests states that only 3 seats are left

#### Scenario: Exact fit
- **WHEN** 3 seats are left and a guest requests 3
- **THEN** the booking is confirmed and the tasting becomes "Fully booked"

#### Scenario: Concurrent bookings
- **WHEN** two requests for the last 2 seats arrive at the same moment
- **THEN** exactly one is confirmed and the other is rejected as exceeding the seats left

#### Scenario: Fully booked tasting
- **WHEN** a booking is submitted for a tasting with no seats left
- **THEN** it is rejected and the guest is told the tasting is fully booked

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a confirmation headed "Booking confirmed" that shows the tasting, the number of guests, the total price (guests times price per guest) and a unique booking reference.

#### Scenario: Confirmation content
- **WHEN** a guest books 2 guests for Riesling Evening
- **THEN** the page shows the heading "Booking confirmed", "Riesling Evening", 2 guests, a total of "EUR 50" and a booking reference

#### Scenario: References are unique
- **WHEN** two bookings are made
- **THEN** their booking references differ

#### Scenario: Reload keeps the confirmation
- **WHEN** the guest reloads the confirmation page
- **THEN** the same confirmation is shown, without personal details other than those listed above

### Requirement: Single submission
The form SHALL prevent a double click on "Book" from creating two bookings.

#### Scenario: Double click
- **WHEN** a guest presses "Book" twice quickly
- **THEN** only one booking is created
