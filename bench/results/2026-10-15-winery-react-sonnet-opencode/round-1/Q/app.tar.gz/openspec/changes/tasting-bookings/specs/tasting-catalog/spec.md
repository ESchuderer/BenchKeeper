# Spec Delta

## Purpose

Presents the winery's tastings to guests with the information needed to choose one: title, date and time, price per guest and how many seats are still available.

## ADDED Requirements

### Requirement: Tasting offer
The system SHALL offer exactly these tastings: Riesling Evening (2026-11-06 18:00, EUR 25 per guest, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32 per guest, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28 per guest, 10 seats).

#### Scenario: Fresh start
- **WHEN** the app has just started and a guest opens the start page
- **THEN** all three tastings are listed in date order with their title, date and time and price per guest
- **AND** Riesling Evening shows "12 seats left", Red Wine Cellar Tour "8 seats left" and Winter Tasting "10 seats left"

### Requirement: Live seat availability
The start page SHALL show for each tasting the seats left, calculated as its seats minus the guests of all active (not cancelled) bookings, formatted as "<n> seats left" ("1 seat left" when exactly one remains).

#### Scenario: Seats decrease after a booking
- **WHEN** a booking for 3 guests is made for Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening and the other tastings are unchanged

#### Scenario: Seats are freed by a cancellation
- **WHEN** staff cancel that booking
- **THEN** the start page shows "12 seats left" for Riesling Evening again

### Requirement: Booking entry point
The start page SHALL give each tasting a link or button named "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens and names the tasting

### Requirement: Fully booked state
A tasting with no seats left SHALL be clearly marked "Fully booked" and SHALL NOT be bookable.

#### Scenario: Last seats taken
- **WHEN** the active bookings of a tasting add up to all of its seats
- **THEN** the start page marks it "Fully booked" and its "Book <tasting title>" control is disabled

#### Scenario: Direct visit to a full tasting's form
- **WHEN** a guest opens the booking form URL of a fully booked tasting
- **THEN** no form is offered and a message explains the tasting is fully booked with a way back to the start page

### Requirement: Unknown tasting
The system SHALL tell the guest when a requested tasting does not exist.

#### Scenario: Unknown tasting URL
- **WHEN** a guest opens the booking form for a tasting that does not exist
- **THEN** a "Tasting not found" message with a link back to the start page is shown
