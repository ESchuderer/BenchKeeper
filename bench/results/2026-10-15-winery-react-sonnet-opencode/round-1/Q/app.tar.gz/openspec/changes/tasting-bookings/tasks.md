# Tasks

## 1. Project scaffolding

- [x] 1.1 Create `package.json` (Node 22 engines, scripts `dev`, `build`, `start`, `test`, `test:e2e`, `lint`, `typecheck`), TypeScript, Vite, Vitest, tsup, Tailwind and ESLint configs, `.gitignore`, `.env.example`; verify `npm install` succeeds and `npm run typecheck` passes on a trivial entry
- [x] 1.2 Write `README.md` (install, build, start, `PORT`, `STAFF_PASSWORD`, in-memory persistence note, test commands); verify every documented command runs as written at the end of group 8

## 2. Domain core (tests first)

- [x] 2.1 Write failing tests then implement shared money formatting ("EUR 25", "EUR 25.50") and the shared booking zod schema (name, email, guests 1-8 integer); verify unit tests cover blank/over-long name, bad email, 0/9/2.5/"abc"/empty guests
- [x] 2.2 Write failing tests then implement the tasting data and in-memory `BookingStore` (seats left, book, cancel, find by reference, bookings grouped by tasting, unique references); verify tests cover exact fit, over-limit, sold out, cancel frees seats, cancel twice, unknown tasting, and that fresh store starts empty

## 3. HTTP API (tests first)

- [x] 3.1 Write failing Supertest tests then implement the public API (`GET /api/tastings`, `GET /api/tastings/:id`, `POST /api/tastings/:id/bookings`, `GET /api/bookings/:reference`) with field-level error responses; verify tests cover validation errors, seat limit, sold out, 404s, malformed JSON, oversize body, and the reference lookup exposing no name or e-mail
- [x] 3.2 Write failing tests then implement staff auth and management (`/api/staff/session`, `/api/staff/bookings`, cancel) with fail-closed password, cookie session, rate limit; verify tests cover wrong/empty password, unset `STAFF_PASSWORD`, 401 without session, sign out, cancel frees seats, double cancel 404, rate limiting
- [x] 3.3 Add helmet, JSON-only parsing, generic error handler, structured logging, static serving of `dist/client` with SPA fallback and `PORT` handling in `index.ts`; verify tests for headers and SPA fallback pass and API errors never contain stack traces; document the API in README

## 4. Client shell and start page (tests first)

- [x] 4.1 Implement the design tokens, fonts, layout shell (header, footer, skip link) and reusable `Button`, `Field`, `Badge`, `Alert`, `Card` components; verify component tests for field error association (`aria-invalid`, `aria-describedby`) and disabled/fully-booked rendering
- [x] 4.2 Write failing page tests then implement the start page (tasting cards: title, date and time, price, "<n> seats left", "Fully booked", "Book <title>" link, loading and retryable error states); verify tests with a mocked API cover fresh state, 1 seat left, sold out disabled control, and error retry

## 5. Booking form and confirmation (tests first)

- [x] 5.1 Write failing tests then implement the booking form page (Name, Email, Guests, "Book", client validation, server field errors mapped to fields, seats-left cap message, double-submit guard, sold-out and not-found states); verify tests cover empty submit, invalid values, more guests than seats, server 409 mapped to Guests, and a single request on double click
- [x] 5.2 Write failing tests then implement the "Booking confirmed" page (tasting, guests, total, reference; works after reload via the reference lookup; link back to start); verify tests cover content, total price and reload

## 6. Staff page (tests first)

- [x] 6.1 Write failing tests then implement the `/staff` sign-in form (Password, "Sign in", error beside field, session check on load, "Sign out"); verify tests cover wrong password, success and sign out
- [x] 6.2 Write failing tests then implement the grouped bookings view with per-row "Cancel" (name, email, guests, reference; empty-group message; status message after cancel; responsive card layout on phones); verify tests cover grouping, empty group, cancel removing the row and updating seats

## 7. End-to-end and visual verification

- [x] 7.1 Add Playwright config and e2e tests against the built app (guest books and sees confirmation and reduced seats; over-booking rejected; sold-out state; staff signs in, sees booking, cancels, seats return; wrong staff password); verify `npm run build && npm run test:e2e` passes
- [x] 7.2 Check the running app at 360 px and desktop widths (no horizontal scroll, 44 px targets, readable contrast, keyboard-only booking, console free of errors) using screenshots and an automated check; fix findings and verify the checks pass

## 8. Release checks

- [x] 8.1 Run the full suite, lint, typecheck, `npm run build`, `npm start` with `PORT` and `STAFF_PASSWORD` set, and `npm audit`; verify the README commands work as written and the app starts with no bookings
- [x] 8.2 Review against the definition of done: five-axis code review, security checklist, accessibility checklist; fix all Critical/Important findings and verify the suite still passes

## Workflow follow-up

- Verify the change against its specs (`/opsx-verify`) and archive it after review (`/opsx-archive`).
