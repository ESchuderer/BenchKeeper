import { defineConfig, devices } from '@playwright/test';

const PORT = 3100;

export default defineConfig({
  testDir: 'tests/e2e',
  fullyParallel: false,
  workers: 1,
  reporter: 'list',
  use: { baseURL: `http://localhost:${PORT}`, trace: 'retain-on-failure' },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] }, grepInvert: /@phone/ },
    { name: 'phone', use: { ...devices['Pixel 7'], viewport: { width: 360, height: 740 } }, grep: /@phone/ },
  ],
  webServer: {
    command: 'npm start',
    port: PORT,
    reuseExistingServer: false,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-secret-password' },
  },
});
