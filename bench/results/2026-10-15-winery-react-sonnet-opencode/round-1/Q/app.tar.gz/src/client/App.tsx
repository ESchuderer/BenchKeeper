import { Route, Routes } from 'react-router';
import { Layout } from './components/Layout';
import { BookingPage } from './pages/BookingPage';
import { ConfirmationPage } from './pages/ConfirmationPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { StaffPage } from './pages/StaffPage';
import { StartPage } from './pages/StartPage';

export function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<StartPage />} />
        <Route path="/tastings/:id/book" element={<BookingPage />} />
        <Route path="/bookings/:reference" element={<ConfirmationPage />} />
        <Route path="/staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Layout>
  );
}
