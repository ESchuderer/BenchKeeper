import type {
  ApiErrorBody,
  BookingConfirmationDto,
  StaffGroupDto,
  TastingDto,
} from '../shared/api';
import type { BookingInput } from '../shared/booking';

export class ApiError extends Error {
  readonly status: number;
  readonly detail: ApiErrorBody['error'] | undefined;

  constructor(status: number, detail?: ApiErrorBody['error']) {
    super(detail?.message ?? `Request failed (${status})`);
    this.status = status;
    this.detail = detail;
  }
}

/** The server could not be reached at all. */
export class NetworkError extends Error {
  constructor() {
    super('Could not reach the server');
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let response: Response;
  try {
    response = await fetch(path, {
      ...init,
      headers: { Accept: 'application/json', ...(init.body ? { 'Content-Type': 'application/json' } : {}) },
    });
  } catch {
    throw new NetworkError();
  }
  const body = response.status === 204 ? undefined : await response.json().catch(() => undefined);
  if (!response.ok) throw new ApiError(response.status, (body as ApiErrorBody | undefined)?.error);
  return body as T;
}

const json = (method: string, payload?: unknown): RequestInit => ({
  method,
  ...(payload === undefined ? {} : { body: JSON.stringify(payload) }),
});

export const api = {
  listTastings: () => request<{ tastings: TastingDto[] }>('/api/tastings').then((r) => r.tastings),
  getTasting: (id: string) =>
    request<{ tasting: TastingDto }>(`/api/tastings/${encodeURIComponent(id)}`).then((r) => r.tasting),
  book: (tastingId: string, input: BookingInput) =>
    request<{ booking: BookingConfirmationDto }>(
      `/api/tastings/${encodeURIComponent(tastingId)}/bookings`,
      json('POST', input),
    ).then((r) => r.booking),
  getBooking: (reference: string) =>
    request<{ booking: BookingConfirmationDto }>(`/api/bookings/${encodeURIComponent(reference)}`).then(
      (r) => r.booking,
    ),
  staffSession: () => request<{ signedIn: boolean }>('/api/staff/session').then((r) => r.signedIn),
  staffSignIn: (password: string) => request<{ signedIn: true }>('/api/staff/session', json('POST', { password })),
  staffSignOut: () => request<void>('/api/staff/session', json('DELETE')),
  staffBookings: () => request<{ groups: StaffGroupDto[] }>('/api/staff/bookings').then((r) => r.groups),
  staffCancel: (reference: string) =>
    request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, json('DELETE')),
};
