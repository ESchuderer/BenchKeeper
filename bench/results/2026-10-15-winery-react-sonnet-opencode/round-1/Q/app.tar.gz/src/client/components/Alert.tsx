import type { ReactNode } from 'react';
import { AlertIcon, CheckIcon, InfoIcon } from './icons';

type Tone = 'error' | 'success' | 'info';

const styles: Record<Tone, string> = {
  error: 'border-danger-200 bg-danger-50 text-danger-700',
  success: 'border-vine-200 bg-vine-50 text-vine-700',
  info: 'border-line bg-sand text-ink',
};

const icons = { error: AlertIcon, success: CheckIcon, info: InfoIcon };

export function Alert({
  tone,
  children,
  className = '',
  announce = true,
}: {
  tone: Tone;
  children: ReactNode;
  className?: string;
  /** Set to false when an enclosing live region already announces this alert. */
  announce?: boolean;
}) {
  const ToneIcon = icons[tone];
  return (
    <div
      role={announce ? (tone === 'error' ? 'alert' : 'status') : undefined}
      className={`flex items-start gap-3 rounded-xl border px-4 py-3 text-[0.95rem] font-medium ${styles[tone]} ${className}`}
    >
      <ToneIcon className="mt-0.5 shrink-0" width="1.25em" height="1.25em" />
      <div className="min-w-0">{children}</div>
    </div>
  );
}
