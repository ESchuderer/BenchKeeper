import type { ReactNode } from 'react';

type Tone = 'neutral' | 'warning' | 'danger' | 'success';

const styles: Record<Tone, string> = {
  neutral: 'bg-sand text-ink',
  warning: 'bg-warn-50 text-warn-800 ring-warn-200',
  danger: 'bg-danger-50 text-danger-700 ring-danger-200',
  success: 'bg-vine-50 text-vine-700 ring-vine-200',
};

export function Badge({ tone, children }: { tone: Tone; children: ReactNode }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold tracking-wide uppercase ring-1 ring-inset ring-transparent ${styles[tone]}`}
    >
      {children}
    </span>
  );
}
