import type { ButtonHTMLAttributes } from 'react';
import { Link, type LinkProps } from 'react-router';

type Variant = 'primary' | 'secondary' | 'danger';

const base =
  'inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-6 py-2.5 text-base font-semibold transition-colors select-none';

const variants: Record<Variant, string> = {
  primary: 'bg-wine-700 text-white hover:bg-wine-800 active:bg-wine-900',
  secondary: 'border border-wine-700 bg-transparent text-wine-700 hover:bg-wine-50',
  danger: 'border border-danger-700 bg-paper text-danger-700 hover:bg-danger-50',
};

const disabled =
  'disabled:cursor-not-allowed disabled:border-line disabled:bg-sand disabled:text-ink-soft disabled:hover:bg-sand';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  loading?: boolean;
}

export function Button({ variant = 'primary', loading = false, className = '', children, ...props }: ButtonProps) {
  return (
    <button
      type="button"
      {...props}
      disabled={props.disabled || loading}
      aria-busy={loading || undefined}
      className={`${base} ${variants[variant]} ${disabled} ${className}`}
    >
      {loading && (
        <span
          aria-hidden="true"
          className="size-4 animate-spin rounded-full border-2 border-current border-t-transparent"
        />
      )}
      {children}
    </button>
  );
}

export function ButtonLink({
  variant = 'primary',
  className = '',
  ...props
}: LinkProps & { variant?: Variant }) {
  return <Link {...props} className={`${base} ${variants[variant]} ${className}`} />;
}
