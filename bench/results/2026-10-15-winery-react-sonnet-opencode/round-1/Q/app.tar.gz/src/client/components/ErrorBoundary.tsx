import { Component, type ErrorInfo, type ReactNode } from 'react';
import { Alert } from './Alert';
import { Button } from './Button';

interface State {
  failed: boolean;
}

export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { failed: false };

  static getDerivedStateFromError(): State {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(error, info.componentStack);
  }

  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="mx-auto max-w-xl px-4 py-12">
        <Alert tone="error">
          <p>Something went wrong on our side. Please reload the page.</p>
          <Button variant="secondary" className="mt-3" onClick={() => window.location.reload()}>
            Reload page
          </Button>
        </Alert>
      </div>
    );
  }
}
