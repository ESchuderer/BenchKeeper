import { useId, type InputHTMLAttributes, type Ref } from 'react';
import { AlertIcon } from './icons';

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: string;
  error?: string | undefined;
  ref?: Ref<HTMLInputElement>;
}

export function Field({ label, hint, error, className = '', ref, ...inputProps }: FieldProps) {
  const id = useId();
  const hintId = `${id}-hint`;
  const errorId = `${id}-error`;
  const describedBy = [hint && hintId, error && errorId].filter(Boolean).join(' ') || undefined;

  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-[0.95rem] font-semibold text-ink">
        {label}
      </label>
      <input
        {...inputProps}
        ref={ref}
        id={id}
        aria-required="true"
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        className={`block min-h-12 w-full rounded-xl border bg-white px-4 py-2.5 text-base text-ink shadow-sm placeholder:text-ink-soft/70 ${
          error ? 'border-danger-700 ring-1 ring-danger-700' : 'border-line hover:border-ink-soft'
        } ${className}`}
      />
      {hint && (
        <p id={hintId} className="mt-1.5 text-sm text-ink-soft">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} role="alert" className="mt-1.5 flex items-start gap-1.5 text-sm font-semibold text-danger-700">
          <AlertIcon className="mt-0.5 shrink-0" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}
