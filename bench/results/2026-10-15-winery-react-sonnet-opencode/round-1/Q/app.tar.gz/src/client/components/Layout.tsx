import type { ReactNode } from 'react';
import { Link } from 'react-router';
import { GrapeMark } from './icons';

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:rounded-lg focus:bg-paper focus:px-4 focus:py-2 focus:font-semibold focus:text-wine-800"
      >
        Skip to content
      </a>
      <header className="border-b-4 border-gold bg-wine-900 text-cream">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-4 sm:px-6">
          <Link to="/" className="flex min-h-11 items-center gap-3 rounded-lg text-cream no-underline hover:opacity-90">
            <GrapeMark className="size-10 shrink-0" />
            <span className="flex flex-col leading-tight">
              <span className="font-display text-xl font-semibold tracking-wide sm:text-2xl">Weingut Kieselbrunnen</span>
              <span className="text-xs tracking-[0.18em] text-gold uppercase">Family winery</span>
            </span>
          </Link>
        </div>
      </header>
      <main id="main" tabIndex={-1} className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        {children}
      </main>
      <footer className="border-t border-line bg-sand">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-x-6 gap-y-2 px-4 py-6 text-sm text-ink-soft sm:px-6">
          <p>Weingut Kieselbrunnen &middot; a family winery</p>
          <Link to="/staff" className="inline-flex min-h-11 items-center font-medium text-wine-700 underline">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
