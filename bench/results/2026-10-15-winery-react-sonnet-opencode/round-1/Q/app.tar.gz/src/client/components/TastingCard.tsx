import type { TastingDto } from '../../shared/api';
import { formatMoney } from '../../shared/money';
import { seatsLeftLabel } from '../../shared/seats';
import { dateBadge, toIsoDateTime, weekdayOf } from '../tastingTime';
import { Badge } from './Badge';
import { Button, ButtonLink } from './Button';
import { SeatIcon } from './icons';

const ALMOST_FULL_AT = 3;

export function TastingCard({ tasting }: { tasting: TastingDto }) {
  const { month, day } = dateBadge(tasting.startsAt);
  const almostFull = !tasting.soldOut && tasting.seatsLeft <= ALMOST_FULL_AT;
  const bookLabel = `Book ${tasting.title}`;

  return (
    <article
      className={`flex flex-col rounded-2xl border p-5 shadow-sm sm:p-6 ${
        tasting.soldOut ? 'border-line bg-sand/60' : 'border-line bg-paper'
      }`}
    >
      <div className="flex items-start gap-4">
        <div
          aria-hidden="true"
          className={`flex size-16 shrink-0 flex-col items-center justify-center rounded-xl text-center leading-none ${
            tasting.soldOut ? 'bg-ink-soft text-cream' : 'bg-wine-800 text-cream'
          }`}
        >
          <span className="text-xs font-semibold tracking-widest text-gold uppercase">{month}</span>
          <span className="mt-1 font-display text-2xl font-semibold">{day}</span>
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold tracking-wide text-wine-700 uppercase">{weekdayOf(tasting.startsAt)}</p>
          <h2 className="font-display text-2xl font-semibold">{tasting.title}</h2>
          <p className="mt-1 text-ink-soft">
            <time dateTime={toIsoDateTime(tasting.startsAt)}>{tasting.startsAt}</time>
          </p>
        </div>
      </div>

      <p className="mt-5 flex items-baseline gap-2">
        <span className="font-display text-3xl font-semibold text-wine-800">{formatMoney(tasting.priceCents)}</span>
        <span className="text-sm text-ink-soft">per guest</span>
      </p>

      <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-2">
        <p className="flex items-center gap-1.5 font-medium">
          <SeatIcon className="text-wine-700" />
          <span>{seatsLeftLabel(tasting.seatsLeft)}</span>
        </p>
        {tasting.soldOut && <Badge tone="danger">Fully booked</Badge>}
        {almostFull && <Badge tone="warning">Almost full</Badge>}
      </div>

      <div className="mt-6 flex-1 content-end">
        {tasting.soldOut ? (
          <Button disabled className="w-full">
            {bookLabel}
          </Button>
        ) : (
          <ButtonLink to={`/tastings/${tasting.id}/book`} className="w-full">
            {bookLabel}
          </ButtonLink>
        )}
      </div>
    </article>
  );
}
