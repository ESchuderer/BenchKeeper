// @vitest-environment jsdom
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { describe, expect, it } from 'vitest';
import { Alert } from './Alert';
import { Badge } from './Badge';
import { Button, ButtonLink } from './Button';
import { Field } from './Field';

describe('Field', () => {
  it('labels the input and links the hint to it', () => {
    render(<Field label="Email" hint="We only use it for your booking" name="email" />);
    const input = screen.getByLabelText('Email');
    expect(input).toHaveAccessibleDescription('We only use it for your booking');
    expect(input).not.toHaveAttribute('aria-invalid', 'true');
  });

  it('marks the input invalid and associates the error message with it', () => {
    render(<Field label="Name" error="Enter your name" hint="As on the invitation" name="name" />);
    const input = screen.getByLabelText('Name');
    expect(input).toHaveAttribute('aria-invalid', 'true');
    expect(input).toHaveAccessibleDescription(/Enter your name/);
    expect(screen.getByText('Enter your name')).toBeVisible();
  });
});

describe('Alert', () => {
  it('announces errors assertively and success politely', () => {
    render(
      <>
        <Alert tone="error">Something failed</Alert>
        <Alert tone="success">All good</Alert>
      </>,
    );
    expect(screen.getByRole('alert')).toHaveTextContent('Something failed');
    expect(screen.getByRole('status')).toHaveTextContent('All good');
  });
});

describe('Badge', () => {
  it('renders its text', () => {
    render(<Badge tone="danger">Fully booked</Badge>);
    expect(screen.getByText('Fully booked')).toBeVisible();
  });
});

describe('Button', () => {
  it('is disabled and busy while loading', () => {
    render(
      <Button loading type="submit">
        Book
      </Button>,
    );
    expect(screen.getByRole('button', { name: /Book/ })).toBeDisabled();
    expect(screen.getByRole('button', { name: /Book/ })).toHaveAttribute('aria-busy', 'true');
  });

  it('renders a router link styled as a button', () => {
    render(
      <MemoryRouter>
        <ButtonLink to="/x">Go</ButtonLink>
      </MemoryRouter>,
    );
    expect(screen.getByRole('link', { name: 'Go' })).toHaveAttribute('href', '/x');
  });
});
