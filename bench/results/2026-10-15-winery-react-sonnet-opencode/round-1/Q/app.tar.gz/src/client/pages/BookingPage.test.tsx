// @vitest-environment jsdom
import { screen, waitFor } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { guest, renderApp, startHarness } from '../../test/serverHarness';

const posts = (requests: { method: string }[]) => requests.filter((r) => r.method === 'POST');

describe('booking form', () => {
  it('opens from the start page and shows the tasting, its time and its price per guest', async () => {
    await startHarness();
    const { user } = renderApp('/');
    await user.click(await screen.findByRole('link', { name: 'Book Winter Tasting' }));

    expect(await screen.findByRole('heading', { level: 1, name: 'Winter Tasting' })).toBeVisible();
    expect(screen.getByText('2026-12-05 17:00')).toBeVisible();
    expect(screen.getByText('EUR 28')).toBeVisible();
    expect(screen.getByLabelText('Name')).toBeVisible();
    expect(screen.getByLabelText('Email')).toBeVisible();
    expect(screen.getByLabelText('Guests')).toBeVisible();
    expect(screen.getByRole('button', { name: 'Book' })).toBeEnabled();
  });

  it('marks all three fields as required for assistive technology', async () => {
    await startHarness();
    renderApp('/tastings/riesling-evening/book');
    for (const label of ['Name', 'Email', 'Guests']) {
      expect(await screen.findByLabelText(label)).toHaveAttribute('aria-required', 'true');
    }
  });

  it('shows an error next to every field when submitted empty and sends nothing', async () => {
    const { requests } = await startHarness();
    const { user } = renderApp('/tastings/riesling-evening/book');
    await user.click(await screen.findByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Name')).toHaveAccessibleDescription(/Enter your name/);
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription(/Enter a valid email address/);
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/Choose between 1 and 8 guests/);
    expect(screen.getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true');
    expect(posts(requests)).toHaveLength(0);
  });

  it.each(['0', '9', '2.5'])('rejects %s guests next to the Guests field', async (value) => {
    const { requests } = await startHarness();
    const { user } = renderApp('/tastings/riesling-evening/book');
    await user.type(await screen.findByLabelText('Name'), guest.name);
    await user.type(screen.getByLabelText('Email'), guest.email);
    await user.type(screen.getByLabelText('Guests'), value);
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByText('Choose between 1 and 8 guests')).toBeVisible();
    expect(screen.getByLabelText('Guests')).toHaveAttribute('aria-invalid', 'true');
    expect(screen.getByLabelText('Name')).not.toHaveAttribute('aria-invalid', 'true');
    expect(posts(requests)).toHaveLength(0);
  });

  it('rejects an invalid email next to the Email field', async () => {
    await startHarness();
    const { user } = renderApp('/tastings/riesling-evening/book');
    await user.type(await screen.findByLabelText('Name'), guest.name);
    await user.type(screen.getByLabelText('Email'), 'not-an-email');
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByLabelText('Email')).toHaveAccessibleDescription(/Enter a valid email address/);
  });

  it('clears an error once the field is corrected', async () => {
    await startHarness();
    const { user } = renderApp('/tastings/riesling-evening/book');
    await user.click(await screen.findByRole('button', { name: 'Book' }));
    await user.type(await screen.findByLabelText('Name'), 'Anna');
    await waitFor(() => expect(screen.queryByText('Enter your name')).not.toBeInTheDocument());
  });

  it('refuses more guests than seats left, naming the seats left, without asking the server', async () => {
    const { store, requests } = await startHarness();
    store.book('red-wine-cellar-tour', { ...guest, guests: 5 });
    const { user } = renderApp('/tastings/red-wine-cellar-tour/book');
    await user.type(await screen.findByLabelText('Name'), guest.name);
    await user.type(screen.getByLabelText('Email'), guest.email);
    await user.type(screen.getByLabelText('Guests'), '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(/Only 3 seats left/);
    expect(posts(requests)).toHaveLength(0);
  });

  it('shows the server refusal beside Guests when seats were taken meanwhile', async () => {
    const { store } = await startHarness();
    const { user } = renderApp('/tastings/red-wine-cellar-tour/book');
    await user.type(await screen.findByLabelText('Name'), guest.name);
    await user.type(screen.getByLabelText('Email'), guest.email);
    await user.type(screen.getByLabelText('Guests'), '4');
    store.book('red-wine-cellar-tour', { ...guest, guests: 6 });
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(/Only 2 seats left/);
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(2);
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
  });

  it('confirms a booking with tasting, guests, total price and reference', async () => {
    const { store } = await startHarness();
    const { user } = renderApp('/tastings/winter-tasting/book');
    await user.type(await screen.findByLabelText('Name'), guest.name);
    await user.type(screen.getByLabelText('Email'), guest.email);
    await user.type(screen.getByLabelText('Guests'), '2');
    expect(screen.getByText('EUR 56')).toBeVisible();
    await user.click(screen.getByRole('button', { name: 'Book' }));

    const heading = await screen.findByRole('heading', { name: 'Booking confirmed' });
    expect(heading).toHaveFocus();
    expect(screen.getByText('Winter Tasting')).toBeVisible();
    expect(screen.getByText('2026-12-05 17:00')).toBeVisible();
    expect(screen.getByText('2', { selector: 'dd' })).toBeVisible();
    expect(screen.getByText('EUR 56')).toBeVisible();
    const reference = screen.getByText(/^KB-[A-Z2-9]{8}$/);
    expect(store.findByReference(reference.textContent!)).toMatchObject({ name: guest.name, guests: 2 });
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(8);
  });

  it('lets the guest return to the tastings after booking, with updated seats', async () => {
    await startHarness();
    const { user } = renderApp('/tastings/riesling-evening/book');
    await user.type(await screen.findByLabelText('Name'), guest.name);
    await user.type(screen.getByLabelText('Email'), guest.email);
    await user.type(screen.getByLabelText('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await screen.findByRole('heading', { name: 'Booking confirmed' });
    await user.click(screen.getByRole('link', { name: /all tastings/i }));
    expect(await screen.findByText('9 seats left')).toBeVisible();
  });

  it('creates one booking when the button is double-clicked', async () => {
    const { store, requests } = await startHarness();
    const { user } = renderApp('/tastings/riesling-evening/book');
    await user.type(await screen.findByLabelText('Name'), guest.name);
    await user.type(screen.getByLabelText('Email'), guest.email);
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.dblClick(screen.getByRole('button', { name: 'Book' }));
    await screen.findByRole('heading', { name: 'Booking confirmed' });
    expect(posts(requests)).toHaveLength(1);
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(10);
  });

  it('keeps what the guest typed and offers a retry when the server is unreachable', async () => {
    const harness = await startHarness();
    const { user } = renderApp('/tastings/riesling-evening/book');
    await user.type(await screen.findByLabelText('Name'), guest.name);
    await user.type(screen.getByLabelText('Email'), guest.email);
    await user.type(screen.getByLabelText('Guests'), '2');
    harness.setOffline(true);
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('alert')).toHaveTextContent(/couldn.t reach the server/i);
    expect(screen.getByLabelText('Name')).toHaveValue(guest.name);
    harness.setOffline(false);
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  });

  it('shows a fully booked notice instead of a form for a sold-out tasting', async () => {
    const { store } = await startHarness();
    store.book('red-wine-cellar-tour', { ...guest, guests: 8 });
    renderApp('/tastings/red-wine-cellar-tour/book');
    expect(await screen.findByText(/fully booked/i)).toBeVisible();
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: /all tastings/i })).toBeVisible();
  });

  it('says so when the tasting does not exist', async () => {
    await startHarness();
    renderApp('/tastings/nope/book');
    expect(await screen.findByRole('heading', { name: 'Tasting not found' })).toBeVisible();
  });
});

describe('booking confirmation page', () => {
  it('shows the same confirmation after a reload, without personal details', async () => {
    const { store } = await startHarness();
    const result = store.book('riesling-evening', { ...guest, guests: 2 });
    if (!result.ok) throw new Error('booking failed');
    renderApp(`/bookings/${result.booking.reference}`);

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    expect(screen.getByText('Riesling Evening')).toBeVisible();
    expect(screen.getByText('EUR 50')).toBeVisible();
    expect(screen.getByText(result.booking.reference)).toBeVisible();
    expect(screen.queryByText(guest.email)).not.toBeInTheDocument();
    expect(screen.queryByText(guest.name)).not.toBeInTheDocument();
  });

  it('reports an unknown or cancelled reference', async () => {
    await startHarness();
    renderApp('/bookings/KB-NOPE2222');
    expect(await screen.findByRole('heading', { name: 'Booking not found' })).toBeVisible();
  });
});
