import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useMemo, useRef, useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { Link, useNavigate, useParams } from 'react-router';
import type { TastingDto } from '../../shared/api';
import { bookingInputSchema, MAX_GUESTS_PER_BOOKING, type BookingInput } from '../../shared/booking';
import { formatMoney } from '../../shared/money';
import { onlySeatsLeftMessage, seatsLeftLabel } from '../../shared/seats';
import { api, ApiError, NetworkError } from '../api';
import { Alert } from '../components/Alert';
import { Button, ButtonLink } from '../components/Button';
import { Card } from '../components/Card';
import { Field } from '../components/Field';
import { ArrowLeftIcon, SeatIcon } from '../components/icons';
import { queryKeys, useTasting } from '../queries';
import { toIsoDateTime, weekdayOf } from '../tastingTime';
import { useDocumentTitle } from '../useDocumentTitle';
import { NotFoundPage } from './NotFoundPage';

export function BookingPage() {
  const { id = '' } = useParams();
  const tasting = useTasting(id);
  useDocumentTitle(tasting.data ? `Book ${tasting.data.title}` : 'Book a tasting');

  if (tasting.isPending) return <p role="status">Loading&hellip;</p>;
  if (tasting.error instanceof ApiError && tasting.error.status === 404) {
    return <NotFoundPage title="Tasting not found" text="We could not find that tasting. It may no longer be offered." />;
  }
  if (tasting.isError) {
    return (
      <Alert tone="error">
        <p>We couldn&rsquo;t load this tasting. Please check your connection and try again.</p>
        <Button variant="secondary" className="mt-3" onClick={() => void tasting.refetch()}>
          Try again
        </Button>
      </Alert>
    );
  }

  return (
    <div className="mx-auto max-w-2xl">
      <Link to="/" className="mb-6 inline-flex min-h-11 items-center gap-2 font-medium text-wine-700 underline">
        <ArrowLeftIcon />
        All tastings
      </Link>
      <TastingHeader tasting={tasting.data} />
      {tasting.data.soldOut ? <SoldOutNotice /> : <BookingForm tasting={tasting.data} />}
    </div>
  );
}

function TastingHeader({ tasting }: { tasting: TastingDto }) {
  return (
    <header className="mb-6">
      <p className="text-sm font-semibold tracking-[0.2em] text-wine-700 uppercase">Book a tasting</p>
      <h1 className="mt-1 text-4xl font-semibold">{tasting.title}</h1>
      <p className="mt-2 text-lg text-ink-soft">
        {weekdayOf(tasting.startsAt)}, <time dateTime={toIsoDateTime(tasting.startsAt)}>{tasting.startsAt}</time>
      </p>
      <p className="mt-3 flex flex-wrap items-baseline gap-x-2">
        <span className="font-display text-2xl font-semibold text-wine-800">{formatMoney(tasting.priceCents)}</span>
        <span className="text-ink-soft">per guest</span>
        <span className="mx-1 text-line" aria-hidden="true">
          |
        </span>
        <span className="inline-flex items-center gap-1.5 font-medium">
          <SeatIcon className="text-wine-700" />
          {seatsLeftLabel(tasting.seatsLeft)}
        </span>
      </p>
    </header>
  );
}

function SoldOutNotice() {
  return (
    <Alert tone="error">
      <p className="font-semibold">This tasting is fully booked.</p>
      <p className="mt-1 font-normal">Please have a look at our other tastings.</p>
      <ButtonLink to="/" variant="secondary" className="mt-3">
        See other tastings
      </ButtonLink>
    </Alert>
  );
}

function BookingForm({ tasting }: { tasting: TastingDto }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [formError, setFormError] = useState<string>();
  const submitting = useRef(false);

  const schema = useMemo(
    () =>
      bookingInputSchema.refine((input) => input.guests <= tasting.seatsLeft, {
        path: ['guests'],
        message: onlySeatsLeftMessage(tasting.seatsLeft),
      }),
    [tasting.seatsLeft],
  );

  const form = useForm<BookingInput>({
    resolver: zodResolver(schema),
    defaultValues: { name: '', email: '' },
  });
  const { register, handleSubmit, setError, control, formState } = form;
  const { errors } = formState;

  const book = useMutation({
    mutationFn: (input: BookingInput) => api.book(tasting.id, input),
    onSuccess: (booking) => {
      queryClient.setQueryData(queryKeys.booking(booking.reference), booking);
      void queryClient.invalidateQueries({ queryKey: queryKeys.tastings });
      void queryClient.invalidateQueries({ queryKey: queryKeys.tasting(tasting.id) });
      void navigate(`/bookings/${booking.reference}`, { replace: true });
    },
    onError: (error) => {
      submitting.current = false;
      if (error instanceof ApiError && error.detail?.fields) {
        for (const [field, message] of Object.entries(error.detail.fields)) {
          setError(field as keyof BookingInput, { type: 'server', message }, { shouldFocus: true });
        }
        void queryClient.invalidateQueries({ queryKey: queryKeys.tasting(tasting.id) });
        return;
      }
      setFormError(
        error instanceof NetworkError
          ? 'We couldn’t reach the server. Check your connection and press Book to try again.'
          : 'Something went wrong and your booking was not made. Please try again.',
      );
    },
  });

  const onValid = (input: BookingInput) => {
    if (submitting.current) return;
    submitting.current = true;
    setFormError(undefined);
    book.mutate(input);
  };

  const guests = Number(useWatch({ control, name: 'guests' }));
  const showTotal = Number.isInteger(guests) && guests >= 1 && guests <= MAX_GUESTS_PER_BOOKING;

  return (
    <Card>
      <form noValidate onSubmit={(event) => void handleSubmit(onValid)(event)} className="space-y-5">
        {formError && <Alert tone="error">{formError}</Alert>}
        <Field label="Name" autoComplete="name" error={errors.name?.message} {...register('name')} />
        <Field
          label="Email"
          type="email"
          autoComplete="email"
          inputMode="email"
          error={errors.email?.message}
          {...register('email')}
        />
        <Field
          label="Guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={MAX_GUESTS_PER_BOOKING}
          step={1}
          hint={`1 to ${MAX_GUESTS_PER_BOOKING} guests`}
          error={errors.guests?.message}
          {...register('guests', { valueAsNumber: true })}
        />
        {showTotal && (
          <p className="flex items-baseline justify-between rounded-xl bg-sand px-4 py-3">
            <span className="text-ink-soft">Total</span>
            <span className="font-display text-2xl font-semibold text-wine-800">
              {formatMoney(guests * tasting.priceCents)}
            </span>
          </p>
        )}
        <Button type="submit" loading={book.isPending} className="w-full sm:w-auto">
          Book
        </Button>
      </form>
    </Card>
  );
}
