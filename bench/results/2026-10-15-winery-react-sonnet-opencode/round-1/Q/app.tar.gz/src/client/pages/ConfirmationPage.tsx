import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef } from 'react';
import { useParams } from 'react-router';
import { formatMoney } from '../../shared/money';
import { api, ApiError } from '../api';
import { Alert } from '../components/Alert';
import { Button, ButtonLink } from '../components/Button';
import { Card } from '../components/Card';
import { CheckIcon } from '../components/icons';
import { queryKeys } from '../queries';
import { useDocumentTitle } from '../useDocumentTitle';
import { NotFoundPage } from './NotFoundPage';

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const booking = useQuery({ queryKey: queryKeys.booking(reference), queryFn: () => api.getBooking(reference) });
  const heading = useRef<HTMLHeadingElement>(null);
  const loaded = booking.isSuccess;
  useDocumentTitle(loaded ? 'Booking confirmed' : 'Your booking');

  useEffect(() => {
    if (loaded) heading.current?.focus();
  }, [loaded]);

  if (booking.isPending) return <p role="status">Loading your booking&hellip;</p>;
  if (booking.error instanceof ApiError && booking.error.status === 404) {
    return (
      <NotFoundPage
        title="Booking not found"
        text="We could not find a booking with this reference. It may have been cancelled."
      />
    );
  }
  if (booking.isError) {
    return (
      <Alert tone="error">
        <p>We couldn&rsquo;t load your booking. Please check your connection and try again.</p>
        <Button variant="secondary" className="mt-3" onClick={() => void booking.refetch()}>
          Try again
        </Button>
      </Alert>
    );
  }

  const { tasting, guests, totalCents } = booking.data;
  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-6 flex items-start gap-4 rounded-2xl border border-vine-200 bg-vine-50 p-5 text-vine-700 sm:p-6">
        <CheckIcon className="mt-1.5 shrink-0" width="2em" height="2em" />
        <div>
          <h1 ref={heading} tabIndex={-1} className="!text-vine-700 text-3xl font-semibold sm:text-4xl">
            Booking confirmed
          </h1>
          <p className="mt-1 text-ink">Thank you! Your seats are reserved. We look forward to welcoming you.</p>
        </div>
      </div>

      <Card>
        <dl className="grid items-baseline gap-x-6 gap-y-4 sm:grid-cols-[10rem_1fr]">
          <dt className="text-ink-soft">Tasting</dt>
          <dd className="font-display text-xl font-semibold">{tasting.title}</dd>
          <dt className="text-ink-soft">Date and time</dt>
          <dd>{tasting.startsAt}</dd>
          <dt className="text-ink-soft">Guests</dt>
          <dd>{guests}</dd>
          <dt className="text-ink-soft">Total price</dt>
          <dd className="font-display text-xl font-semibold text-wine-800">{formatMoney(totalCents)}</dd>
          <dt className="text-ink-soft">Booking reference</dt>
          <dd>
            <span className="inline-block rounded-lg bg-sand px-3 py-1 font-mono text-lg font-bold tracking-wider">
              {booking.data.reference}
            </span>
          </dd>
        </dl>
        <p className="mt-6 text-sm text-ink-soft">
          Please keep your booking reference and mention it when you arrive.
        </p>
        <ButtonLink to="/" variant="secondary" className="mt-5">
          Back to all tastings
        </ButtonLink>
      </Card>
    </div>
  );
}
