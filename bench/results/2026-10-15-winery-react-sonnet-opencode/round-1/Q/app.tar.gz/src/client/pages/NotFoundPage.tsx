import { ButtonLink } from '../components/Button';
import { useDocumentTitle } from '../useDocumentTitle';

export function NotFoundPage({ title = 'Page not found', text = 'The page you are looking for does not exist.' }) {
  useDocumentTitle(title);
  return (
    <section className="max-w-xl">
      <h1 className="text-3xl font-semibold sm:text-4xl">{title}</h1>
      <p className="mt-3 text-lg text-ink-soft">{text}</p>
      <ButtonLink to="/" className="mt-6">
        Back to all tastings
      </ButtonLink>
    </section>
  );
}
