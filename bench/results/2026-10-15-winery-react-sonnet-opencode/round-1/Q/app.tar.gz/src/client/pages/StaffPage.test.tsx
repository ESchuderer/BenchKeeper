// @vitest-environment jsdom
import { screen, waitFor, within } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { guest, renderApp, STAFF_PASSWORD, startHarness } from '../../test/serverHarness';

async function signIn(user: ReturnType<typeof renderApp>['user'], password = STAFF_PASSWORD) {
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
}

describe('staff sign-in', () => {
  it('asks for a password and shows no bookings while signed out', async () => {
    const { store } = await startHarness();
    store.book('riesling-evening', guest);
    renderApp('/staff');
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeVisible();
    expect(screen.queryByText(guest.email)).not.toBeInTheDocument();
  });

  it('shows an error next to the Password field for a wrong password', async () => {
    const { store } = await startHarness();
    store.book('riesling-evening', guest);
    const { user } = renderApp('/staff');
    await signIn(user, 'wrong');
    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription(/Incorrect password/);
    expect(screen.getByLabelText('Password')).toHaveAttribute('aria-invalid', 'true');
    expect(screen.queryByText(guest.email)).not.toBeInTheDocument();
  });

  it('asks for the password when it is left empty', async () => {
    await startHarness();
    const { user } = renderApp('/staff');
    await user.click(await screen.findByRole('button', { name: 'Sign in' }));
    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription(/Enter the password/);
  });

  it('shows the bookings after signing in with the right password', async () => {
    await startHarness();
    const { user } = renderApp('/staff');
    await signIn(user);
    expect(await screen.findByRole('heading', { level: 1, name: 'Bookings' })).toBeVisible();
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument();
  });

  it('stays signed in when the page is opened again', async () => {
    await startHarness();
    const first = renderApp('/staff');
    await signIn(first.user);
    await screen.findByRole('heading', { name: 'Bookings' });
    first.unmount();
    renderApp('/staff');
    expect(await screen.findByRole('heading', { name: 'Bookings' })).toBeVisible();
  });

  it('shows the rate-limit message after too many wrong passwords', async () => {
    await startHarness();
    const { user } = renderApp('/staff');
    for (let attempt = 0; attempt < 11; attempt++) {
      await user.clear(await screen.findByLabelText('Password'));
      await signIn(user, 'wrong');
      await screen.findByLabelText('Password');
    }
    await waitFor(() => expect(screen.getByLabelText('Password')).toHaveAccessibleDescription(/too many attempts/i));
  });

  it('stays signed in and says so when signing out fails', async () => {
    const harness = await startHarness();
    const { user } = renderApp('/staff');
    await signIn(user);
    await screen.findByRole('heading', { name: 'Bookings' });
    harness.setOffline(true);
    await user.click(screen.getByRole('button', { name: 'Sign out' }));
    expect(await screen.findByText(/couldn.t sign you out/i)).toBeVisible();
    expect(screen.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  });

  it('signs out', async () => {
    await startHarness();
    const { user } = renderApp('/staff');
    await signIn(user);
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeVisible();
    expect(screen.queryByRole('heading', { name: 'Bookings' })).not.toBeInTheDocument();
  });
});

describe('staff bookings', () => {
  it('groups bookings by tasting with name, email, guests and reference', async () => {
    const { store } = await startHarness();
    const anna = store.book('winter-tasting', guest);
    store.book('riesling-evening', { name: 'Ben Roth', email: 'ben@example.com', guests: 4 });
    if (!anna.ok) throw new Error('booking failed');
    const { user } = renderApp('/staff');
    await signIn(user);

    const winterHeading = await screen.findByRole('heading', { level: 2, name: 'Winter Tasting' });
    const winter = within(winterHeading.closest('section')!);
    expect(winter.getByRole('table', { name: 'Winter Tasting' })).toBeVisible();
    const row = winter.getByRole('row', { name: /Anna Weber/ });
    expect(within(row).getByRole('rowheader', { name: 'Anna Weber' })).toBeVisible();
    expect(within(row).getByText('anna@example.com')).toBeVisible();
    expect(within(row).getByText('2')).toBeVisible();
    expect(within(row).getByText(anna.booking.reference)).toBeVisible();
    expect(winter.queryByText('Ben Roth')).not.toBeInTheDocument();

    const riesling = within(screen.getByRole('heading', { level: 2, name: 'Riesling Evening' }).closest('section')!);
    expect(riesling.getByText('Ben Roth')).toBeVisible();
    expect(riesling.getByText(/4 of 12 seats booked/)).toBeVisible();
  });

  it('says when a tasting has no bookings yet', async () => {
    await startHarness();
    const { user } = renderApp('/staff');
    await signIn(user);
    const cellar = within((await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' })).closest('section')!);
    expect(cellar.getByText('No bookings yet')).toBeVisible();
    expect(cellar.queryByRole('button', { name: 'Cancel' })).not.toBeInTheDocument();
  });

  it('cancels a booking, removes it from the list and frees its seats', async () => {
    const { store } = await startHarness();
    const result = store.book('red-wine-cellar-tour', { ...guest, guests: 4 });
    store.book('red-wine-cellar-tour', { name: 'Ben Roth', email: 'ben@example.com', guests: 1 });
    if (!result.ok) throw new Error('booking failed');
    const { user } = renderApp('/staff');
    await signIn(user);

    const row = await screen.findByRole('row', { name: /Anna Weber/ });
    await user.click(within(row).getByRole('button', { name: 'Cancel' }));

    await waitFor(() => expect(screen.getByRole('status')).toHaveTextContent(/cancelled.*4 seats/i));
    expect(screen.getByRole('status')).toHaveFocus();
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument();
    expect(screen.queryByText(result.booking.reference)).not.toBeInTheDocument();
    expect(screen.getByText('Ben Roth')).toBeVisible();
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(7);
    expect(store.findByReference(result.booking.reference)).toBeUndefined();
  });

  it('returns to sign-in when the session has ended', async () => {
    const { store } = await startHarness();
    store.book('winter-tasting', guest);
    const { user } = renderApp('/staff');
    await signIn(user);
    const row = await screen.findByRole('row', { name: /Anna Weber/ });
    await fetch('/api/staff/session', { method: 'DELETE' });
    await user.click(within(row).getByRole('button', { name: 'Cancel' }));

    expect(await screen.findByLabelText('Password')).toBeVisible();
    expect(screen.getByRole('alert')).toHaveTextContent(/session has ended/i);
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(8);
  });

  it('shows a retryable error when the bookings cannot be loaded', async () => {
    const harness = await startHarness();
    const first = renderApp('/staff');
    await signIn(first.user);
    await screen.findByRole('heading', { name: 'Bookings' });
    first.unmount();

    harness.setOffline(true);
    const { user } = renderApp('/staff');
    expect(await screen.findByRole('alert')).toHaveTextContent(/couldn.t load/i);
    harness.setOffline(false);
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByRole('heading', { name: 'Bookings' })).toBeVisible();
  });
});
