import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import type { StaffBookingDto, StaffGroupDto } from '../../shared/api';
import { seatsLeftLabel } from '../../shared/seats';
import { api, ApiError, NetworkError } from '../api';
import { Alert } from '../components/Alert';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { Field } from '../components/Field';
import { queryKeys } from '../queries';
import { useDocumentTitle } from '../useDocumentTitle';

export function StaffPage() {
  useDocumentTitle('Staff');
  const queryClient = useQueryClient();
  const session = useQuery({ queryKey: queryKeys.staffSession, queryFn: api.staffSession });
  const [notice, setNotice] = useState<string>();

  const endSession = useCallback(
    (message?: string) => {
      setNotice(message);
      queryClient.setQueryData(queryKeys.staffSession, false);
      queryClient.removeQueries({ queryKey: queryKeys.staffBookings });
    },
    [queryClient],
  );

  if (session.isPending) return <p role="status">Loading&hellip;</p>;
  if (session.isError) {
    return (
      <Alert tone="error">
        <p>We couldn&rsquo;t load this page. Please check your connection and try again.</p>
        <Button variant="secondary" className="mt-3" onClick={() => void session.refetch()}>
          Try again
        </Button>
      </Alert>
    );
  }
  if (!session.data) return <SignIn notice={notice} onSignedIn={() => setNotice(undefined)} />;
  return <Bookings onSignedOut={endSession} />;
}

function SignIn({ notice, onSignedIn }: { notice: string | undefined; onSignedIn: () => void }) {
  const queryClient = useQueryClient();
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string>();

  const signIn = useMutation({
    mutationFn: api.staffSignIn,
    onSuccess: () => {
      onSignedIn();
      queryClient.setQueryData(queryKeys.staffSession, true);
    },
    onError: (failure) => {
      if (failure instanceof ApiError) {
        setError(failure.detail?.fields?.password ?? 'Incorrect password');
      } else {
        setError(failure instanceof NetworkError ? 'We couldn’t reach the server. Try again.' : 'Something went wrong. Try again.');
      }
    },
  });

  const submit = (event: FormEvent) => {
    event.preventDefault();
    setError(undefined);
    signIn.mutate(password);
  };

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-6 text-3xl font-semibold sm:text-4xl">Staff sign-in</h1>
      <Card>
        <form noValidate onSubmit={submit} className="space-y-5">
          {notice && <Alert tone="error">{notice}</Alert>}
          <Field
            label="Password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            error={error}
          />
          <Button type="submit" loading={signIn.isPending} className="w-full">
            Sign in
          </Button>
        </form>
      </Card>
    </div>
  );
}

function Bookings({ onSignedOut }: { onSignedOut: (message?: string) => void }) {
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<{ tone: 'success' | 'info'; text: string }>();
  const statusRegion = useRef<HTMLDivElement>(null);
  const bookings = useQuery({ queryKey: queryKeys.staffBookings, queryFn: api.staffBookings, retry: false });
  const sessionEnded = bookings.error instanceof ApiError && bookings.error.status === 401;

  useEffect(() => {
    if (sessionEnded) onSignedOut(SESSION_ENDED);
  }, [sessionEnded, onSignedOut]);

  // The cancelled row (and the button that was focused) is gone, so hand focus to the confirmation.
  useEffect(() => {
    if (status) statusRegion.current?.focus();
  }, [status]);

  const refreshAfterChange = () =>
    Promise.all([
      queryClient.invalidateQueries({ queryKey: queryKeys.staffBookings }),
      queryClient.invalidateQueries({ queryKey: queryKeys.tastings }),
      queryClient.invalidateQueries({ queryKey: ['tasting'] }),
    ]);

  const cancel = useMutation({
    mutationFn: ({ booking }: { booking: StaffBookingDto }) => api.staffCancel(booking.reference),
    onSuccess: async (_data, { booking }) => {
      await refreshAfterChange();
      const seats = booking.guests === 1 ? '1 seat is' : `${booking.guests} seats are`;
      setStatus({ tone: 'success', text: `Booking cancelled. ${seats} free again.` });
    },
    onError: async (error) => {
      if (error instanceof ApiError && error.status === 401) return onSignedOut(SESSION_ENDED);
      if (error instanceof ApiError && error.status === 404) {
        await refreshAfterChange();
        return setStatus({ tone: 'info', text: 'That booking had already been cancelled.' });
      }
      setStatus({ tone: 'info', text: 'The booking could not be cancelled. Please try again.' });
    },
  });

  const signOut = useMutation({
    mutationFn: api.staffSignOut,
    onSuccess: () => onSignedOut(),
    onError: () => setStatus({ tone: 'info', text: 'We couldn’t sign you out. Check your connection and try again.' }),
  });

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-3xl font-semibold sm:text-4xl">Bookings</h1>
        <Button variant="secondary" onClick={() => signOut.mutate()} loading={signOut.isPending}>
          Sign out
        </Button>
      </div>

      <div role="status" ref={statusRegion} tabIndex={-1}>
        {status && (
          <Alert tone={status.tone} announce={false} className="mb-6">
            {status.text}
          </Alert>
        )}
      </div>

      {bookings.isPending && <p role="status">Loading bookings&hellip;</p>}
      {bookings.isError && !sessionEnded && (
        <Alert tone="error">
          <p>We couldn&rsquo;t load the bookings. Please check your connection and try again.</p>
          <Button variant="secondary" className="mt-3" onClick={() => void bookings.refetch()}>
            Try again
          </Button>
        </Alert>
      )}
      {bookings.data && (
        <div className="space-y-8">
          {bookings.data.map((group) => (
            <TastingGroup
              key={group.tasting.id}
              group={group}
              cancelling={cancel.isPending ? cancel.variables.booking.reference : undefined}
              onCancel={(booking) => {
                setStatus(undefined);
                cancel.mutate({ booking });
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}

const SESSION_ENDED = 'Your session has ended. Please sign in again.';

function TastingGroup({
  group,
  cancelling,
  onCancel,
}: {
  group: StaffGroupDto;
  cancelling: string | undefined;
  onCancel: (booking: StaffBookingDto) => void;
}) {
  const { tasting, bookings } = group;
  const headingId = `group-${tasting.id}`;
  const booked = tasting.seats - tasting.seatsLeft;

  return (
    <section aria-labelledby={headingId} className="overflow-hidden rounded-2xl border border-line bg-paper shadow-sm">
      <header className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b border-line bg-sand/60 px-5 py-4">
        <div>
          <h2 id={headingId} className="font-display text-2xl font-semibold">
            {tasting.title}
          </h2>
          <p className="text-ink-soft">{tasting.startsAt}</p>
        </div>
        <p className="font-medium">
          {booked} of {tasting.seats} seats booked
          <span className="text-ink-soft"> &middot; {seatsLeftLabel(tasting.seatsLeft)}</span>
        </p>
      </header>

      {bookings.length === 0 ? (
        <p className="px-5 py-6 text-ink-soft">No bookings yet</p>
      ) : (
        <table role="table" aria-labelledby={headingId} className="block w-full text-left sm:table">
          <thead role="rowgroup" className="hidden text-sm text-ink-soft sm:table-header-group">
            <tr role="row" className="border-b border-line">
              <th role="columnheader" scope="col" className="px-5 py-3 font-semibold">Name</th>
              <th role="columnheader" scope="col" className="px-3 py-3 font-semibold">Email</th>
              <th role="columnheader" scope="col" className="px-3 py-3 font-semibold">Guests</th>
              <th role="columnheader" scope="col" className="px-3 py-3 font-semibold">Reference</th>
              <th role="columnheader" scope="col" className="px-5 py-3"><span className="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody role="rowgroup" className="block sm:table-row-group">
            {bookings.map((booking) => (
              <BookingRow
                key={booking.reference}
                booking={booking}
                busy={cancelling === booking.reference}
                onCancel={onCancel}
              />
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

const cell = 'block px-5 py-1 sm:table-cell sm:px-3 sm:py-3 sm:align-middle';
const labelled =
  "before:mr-2 before:text-sm before:text-ink-soft before:content-[attr(data-label)] sm:before:hidden";

function BookingRow({
  booking,
  busy,
  onCancel,
}: {
  booking: StaffBookingDto;
  busy: boolean;
  onCancel: (booking: StaffBookingDto) => void;
}) {
  const nameId = `booking-${booking.reference}`;
  return (
    <tr role="row" className="block border-b border-line py-3 last:border-b-0 sm:table-row sm:py-0">
      <th role="rowheader" scope="row" id={nameId} className={`${cell} text-left font-semibold sm:pl-5`}>
        {booking.name}
      </th>
      <td role="cell" data-label="Email" className={`${cell} ${labelled} break-all`}>
        {booking.email}
      </td>
      <td role="cell" data-label="Guests" className={`${cell} ${labelled}`}>
        {booking.guests}
      </td>
      <td role="cell" data-label="Reference" className={`${cell} ${labelled} font-mono text-sm`}>
        {booking.reference}
      </td>
      <td role="cell" className={`${cell} pt-3 sm:pr-5 sm:pt-3 sm:text-right`}>
        <Button
          variant="danger"
          aria-describedby={nameId}
          loading={busy}
          onClick={() => onCancel(booking)}
          className="min-h-11 px-5 py-1.5"
        >
          Cancel
        </Button>
      </td>
    </tr>
  );
}
