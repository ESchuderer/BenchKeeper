// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { guest, renderApp, startHarness } from '../../test/serverHarness';

async function card(title: string) {
  const heading = await screen.findByRole('heading', { name: title });
  return within(heading.closest('article')!);
}

describe('start page', () => {
  it('lists the three tastings with date and time, price and seats left', async () => {
    await startHarness();
    renderApp('/');

    const riesling = await card('Riesling Evening');
    expect(riesling.getByText('2026-11-06 18:00')).toBeVisible();
    expect(riesling.getByText('EUR 25')).toBeVisible();
    expect(riesling.getByText('12 seats left')).toBeVisible();

    const cellar = await card('Red Wine Cellar Tour');
    expect(cellar.getByText('2026-11-14 15:00')).toBeVisible();
    expect(cellar.getByText('EUR 32')).toBeVisible();
    expect(cellar.getByText('8 seats left')).toBeVisible();

    const winter = await card('Winter Tasting');
    expect(winter.getByText('2026-12-05 17:00')).toBeVisible();
    expect(winter.getByText('EUR 28')).toBeVisible();
    expect(winter.getByText('10 seats left')).toBeVisible();
  });

  it('shows a main heading and the winery name', async () => {
    await startHarness();
    renderApp('/');
    expect(await screen.findByRole('heading', { level: 1 })).toBeVisible();
    expect(screen.getAllByText(/Weingut Kieselbrunnen/).length).toBeGreaterThan(0);
  });

  it('offers a "Book <title>" link per tasting that points at its booking form', async () => {
    await startHarness();
    renderApp('/');
    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' });
    expect(link).toHaveAttribute('href', '/tastings/riesling-evening/book');
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toHaveAttribute(
      'href',
      '/tastings/winter-tasting/book',
    );
  });

  it('shows current seats after bookings, with the singular for one seat', async () => {
    const { store } = await startHarness();
    store.book('riesling-evening', { ...guest, guests: 3 });
    store.book('red-wine-cellar-tour', { ...guest, guests: 7 });
    renderApp('/');
    expect(await (await card('Riesling Evening')).findByText('9 seats left')).toBeVisible();
    expect((await card('Red Wine Cellar Tour')).getByText('1 seat left')).toBeVisible();
  });

  it('marks a sold-out tasting as fully booked and disables its book control', async () => {
    const { store } = await startHarness();
    store.book('red-wine-cellar-tour', { ...guest, guests: 8 });
    renderApp('/');
    const cellar = await card('Red Wine Cellar Tour');
    expect(cellar.getByText('Fully booked')).toBeVisible();
    expect(cellar.getByText('0 seats left')).toBeVisible();
    expect(cellar.getByRole('button', { name: 'Book Red Wine Cellar Tour' })).toBeDisabled();
    expect(cellar.queryByRole('link', { name: /Book/ })).not.toBeInTheDocument();
    const riesling = await card('Riesling Evening');
    expect(riesling.queryByText('Fully booked')).not.toBeInTheDocument();
  });

  it('flags tastings that are nearly full', async () => {
    const { store } = await startHarness();
    store.book('winter-tasting', { ...guest, guests: 8 });
    renderApp('/');
    expect((await card('Winter Tasting')).getByText('Almost full')).toBeVisible();
  });

  it('shows a retryable error when the server cannot be reached', async () => {
    const harness = await startHarness();
    harness.setOffline(true);
    const { user } = renderApp('/');
    expect(await screen.findByRole('alert')).toHaveTextContent(/couldn.t load the tastings/i);
    harness.setOffline(false);
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
  });

  it('shows a not-found page for unknown addresses', async () => {
    await startHarness();
    renderApp('/nowhere');
    expect(await screen.findByRole('heading', { name: 'Page not found' })).toBeVisible();
    expect(screen.getByRole('link', { name: /all tastings/i })).toHaveAttribute('href', '/');
  });
});
