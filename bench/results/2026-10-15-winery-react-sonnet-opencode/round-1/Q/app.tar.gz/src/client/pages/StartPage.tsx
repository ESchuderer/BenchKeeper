import { Alert } from '../components/Alert';
import { Button } from '../components/Button';
import { TastingCard } from '../components/TastingCard';
import { useDocumentTitle } from '../useDocumentTitle';
import { useTastings } from '../queries';

function TastingSkeletons() {
  return (
    <div role="status" aria-label="Loading tastings" className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      {[0, 1, 2].map((n) => (
        <div key={n} className="h-72 animate-pulse rounded-2xl border border-line bg-sand/70" />
      ))}
    </div>
  );
}

export function StartPage() {
  useDocumentTitle();
  const tastings = useTastings();

  return (
    <>
      <section className="mb-10 max-w-2xl">
        <p className="text-sm font-semibold tracking-[0.2em] text-wine-700 uppercase">Weingut Kieselbrunnen</p>
        <h1 className="mt-2 text-4xl font-semibold sm:text-5xl">Wine tastings, straight from the cellar</h1>
        <p className="mt-4 text-lg text-ink-soft">
          Spend an evening with our family among the barrels. Choose a tasting, reserve your seats and we will have a
          glass ready for you.
        </p>
      </section>

      <section aria-labelledby="tastings-heading">
        <h2 id="tastings-heading" className="sr-only">
          Upcoming tastings
        </h2>
        {tastings.isPending && <TastingSkeletons />}
        {tastings.isError && (
          <Alert tone="error">
            <p>We couldn&rsquo;t load the tastings. Please check your connection and try again.</p>
            <Button variant="secondary" className="mt-3" onClick={() => void tastings.refetch()}>
              Try again
            </Button>
          </Alert>
        )}
        {tastings.data && (
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {tastings.data.map((tasting) => (
              <TastingCard key={tasting.id} tasting={tasting} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}
