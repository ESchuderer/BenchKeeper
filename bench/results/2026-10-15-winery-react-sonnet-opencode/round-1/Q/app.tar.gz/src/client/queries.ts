import { useQuery } from '@tanstack/react-query';
import { api } from './api';

export const queryKeys = {
  tastings: ['tastings'] as const,
  tasting: (id: string) => ['tasting', id] as const,
  booking: (reference: string) => ['booking', reference] as const,
  staffSession: ['staff', 'session'] as const,
  staffBookings: ['staff', 'bookings'] as const,
};

export const useTastings = () => useQuery({ queryKey: queryKeys.tastings, queryFn: api.listTastings });

export const useTasting = (id: string) =>
  useQuery({ queryKey: queryKeys.tasting(id), queryFn: () => api.getTasting(id) });
