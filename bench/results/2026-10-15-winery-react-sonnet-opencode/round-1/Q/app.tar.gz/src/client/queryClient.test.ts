import { describe, expect, it } from 'vitest';
import { ApiError, NetworkError } from './api';
import { shouldRetry } from './queryClient';

describe('shouldRetry', () => {
  it('retries a dropped connection once', () => {
    expect(shouldRetry(0, new NetworkError())).toBe(true);
    expect(shouldRetry(1, new NetworkError())).toBe(false);
  });

  it('retries a server error once', () => {
    expect(shouldRetry(0, new ApiError(500))).toBe(true);
  });

  it.each([400, 401, 404, 422])('does not retry a %i answer, which a retry cannot change', (status) => {
    expect(shouldRetry(0, new ApiError(status))).toBe(false);
  });
});
