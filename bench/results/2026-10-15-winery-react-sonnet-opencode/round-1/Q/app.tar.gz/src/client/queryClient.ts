import { QueryClient } from '@tanstack/react-query';
import { ApiError } from './api';

/** Retry a failure once, unless the server gave a definite answer that a retry cannot change. */
export function shouldRetry(failureCount: number, error: unknown): boolean {
  if (error instanceof ApiError && error.status < 500) return false;
  return failureCount < 1;
}

export const createQueryClient = () => new QueryClient({ defaultOptions: { queries: { retry: shouldRetry } } });
