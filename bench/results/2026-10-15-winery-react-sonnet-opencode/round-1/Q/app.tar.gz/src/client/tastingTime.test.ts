import { describe, expect, it } from 'vitest';
import { dateBadge, toIsoDateTime, weekdayOf } from './tastingTime';

describe('tasting time helpers', () => {
  it('derives the weekday from the date', () => {
    expect(weekdayOf('2026-11-06 18:00')).toBe('Friday');
    expect(weekdayOf('2026-11-14 15:00')).toBe('Saturday');
    expect(weekdayOf('2026-12-05 17:00')).toBe('Saturday');
  });

  it('builds a machine-readable datetime', () => {
    expect(toIsoDateTime('2026-11-06 18:00')).toBe('2026-11-06T18:00');
  });

  it('splits month and day for the date badge', () => {
    expect(dateBadge('2026-11-06 18:00')).toEqual({ month: 'Nov', day: '6' });
    expect(dateBadge('2026-12-05 17:00')).toEqual({ month: 'Dec', day: '5' });
  });
});
