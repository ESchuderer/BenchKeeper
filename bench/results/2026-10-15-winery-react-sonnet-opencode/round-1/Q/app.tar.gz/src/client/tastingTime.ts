const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function datePart(startsAt: string) {
  const [year = 0, month = 1, day = 1] = startsAt.slice(0, 10).split('-').map(Number);
  return { year, month, day };
}

export function weekdayOf(startsAt: string): string {
  const { year, month, day } = datePart(startsAt);
  return WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()] ?? '';
}

export function toIsoDateTime(startsAt: string): string {
  return startsAt.replace(' ', 'T');
}

export function dateBadge(startsAt: string): { month: string; day: string } {
  const { month, day } = datePart(startsAt);
  return { month: MONTHS[month - 1] ?? '', day: String(day) };
}
