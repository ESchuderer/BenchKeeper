import { useEffect } from 'react';

const SITE = 'Weingut Kieselbrunnen';

export function useDocumentTitle(title?: string) {
  useEffect(() => {
    document.title = title ? `${title} | ${SITE}` : SITE;
  }, [title]);
}
