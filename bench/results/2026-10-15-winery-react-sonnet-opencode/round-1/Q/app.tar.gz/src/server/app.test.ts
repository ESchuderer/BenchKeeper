import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from './app';
import { createBookingStore } from './store';

const PASSWORD = 'correct horse battery';
const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

function makeApp(options: Partial<Parameters<typeof createApp>[0]> = {}) {
  const store = createBookingStore();
  const app = createApp({ store, staffPassword: PASSWORD, log: () => {}, ...options });
  return { app, store };
}

async function signedInStaff(app: ReturnType<typeof makeApp>['app']) {
  const agent = request.agent(app);
  await agent.post('/api/staff/session').send({ password: PASSWORD }).expect(200);
  return agent;
}

describe('GET /api/tastings', () => {
  it('lists the tastings with seats left', async () => {
    const { app } = makeApp();
    const res = await request(app).get('/api/tastings').expect(200);
    expect(res.body.tastings).toHaveLength(3);
    expect(res.body.tastings[0]).toEqual({
      id: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06 18:00',
      priceCents: 2500,
      seats: 12,
      seatsLeft: 12,
      soldOut: false,
    });
  });

  it('returns a single tasting or 404', async () => {
    const { app } = makeApp();
    const found = await request(app).get('/api/tastings/winter-tasting').expect(200);
    expect(found.body.tasting.title).toBe('Winter Tasting');
    const missing = await request(app).get('/api/tastings/unknown').expect(404);
    expect(missing.body.error.code).toBe('not_found');
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and returns a confirmation without personal data', async () => {
    const { app } = makeApp();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(guest).expect(201);
    expect(res.body.booking).toMatchObject({
      tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06 18:00' },
      guests: 2,
      totalCents: 5000,
    });
    expect(res.body.booking.reference).toMatch(/^KB-/);
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
    const after = await request(app).get('/api/tastings/riesling-evening');
    expect(after.body.tasting.seatsLeft).toBe(10);
  });

  it('rejects invalid input with an error per field and creates no booking', async () => {
    const { app, store } = makeApp();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({}).expect(422);
    expect(res.body.error.code).toBe('validation');
    expect(res.body.error.fields).toEqual({
      name: 'Enter your name',
      email: 'Enter a valid email address',
      guests: 'Choose between 1 and 8 guests',
    });
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });

  it.each([0, 9, 2.5, '2'])('rejects guests = %j', async (guests) => {
    const { app } = makeApp();
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guest, guests })
      .expect(422);
    expect(Object.keys(res.body.error.fields)).toEqual(['guests']);
  });

  it('rejects more guests than seats left on the Guests field', async () => {
    const { app } = makeApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 5 }).expect(201);
    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 4 })
      .expect(409);
    expect(res.body.error).toMatchObject({
      code: 'not_enough_seats',
      seatsLeft: 3,
      fields: { guests: 'Only 3 seats left' },
    });
  });

  it('uses the singular when one seat is left', async () => {
    const { app } = makeApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 7 }).expect(201);
    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 2 })
      .expect(409);
    expect(res.body.error.fields.guests).toBe('Only 1 seat left');
  });

  it('rejects bookings for a fully booked tasting', async () => {
    const { app } = makeApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 8 }).expect(201);
    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...guest, guests: 1 })
      .expect(409);
    expect(res.body.error.code).toBe('sold_out');
    expect(res.body.error.fields.guests).toBeDefined();
  });

  it('accepts exactly one of two simultaneous requests for the last seats', async () => {
    const { app } = makeApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 6 }).expect(201);
    const responses = await Promise.all([
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 2 }),
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 2 }),
    ]);
    expect(responses.map((r) => r.status).sort()).toEqual([201, 409]);
  });

  it('never oversells under a burst of simultaneous requests', async () => {
    const { app, store } = makeApp();
    const responses = await Promise.all(
      Array.from({ length: 20 }, () =>
        request(app)
          .post('/api/tastings/winter-tasting/bookings')
          .send({ ...guest, guests: 3 }),
      ),
    );
    expect(responses.filter((r) => r.status === 201)).toHaveLength(3);
    expect(responses.filter((r) => r.status === 409)).toHaveLength(17);
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(1);
  });

  it('ignores unknown properties such as seats or __proto__', async () => {
    const { app, store } = makeApp();
    await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name":"Anna","email":"anna@example.com","guests":1,"seats":99,"__proto__":{"guests":8}}')
      .expect(201);
    expect(store.getTasting('riesling-evening')).toMatchObject({ seats: 12, seatsLeft: 11 });
  });

  it.each([[[]], ['text'], [42]])('rejects a body that is not an object (%j) with 400', async (body) => {
    const { app } = makeApp();
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send(JSON.stringify(body))
      .expect(400);
    expect(res.body.error.code).toBe('bad_request');
  });

  it('returns 404 for an unknown tasting', async () => {
    const { app } = makeApp();
    await request(app).post('/api/tastings/unknown/bookings').send(guest).expect(404);
  });

  it('rejects malformed JSON with 400 and no stack trace', async () => {
    const { app } = makeApp();
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name": ')
      .expect(400);
    expect(res.body.error.code).toBe('bad_request');
    expect(JSON.stringify(res.body)).not.toMatch(/at .*\(|node_modules/);
  });

  it('rejects oversized bodies with 413', async () => {
    const { app } = makeApp();
    await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guest, name: 'x'.repeat(20_000) })
      .expect(413);
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the confirmation summary only for active bookings', async () => {
    const { app, store } = makeApp();
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send(guest).expect(201);
    const { reference } = created.body.booking;
    const res = await request(app).get(`/api/bookings/${reference}`).expect(200);
    expect(res.body.booking).toEqual(created.body.booking);
    store.cancel(reference);
    await request(app).get(`/api/bookings/${reference}`).expect(404);
  });

  it('returns 404 for an unknown reference', async () => {
    const { app } = makeApp();
    await request(app).get('/api/bookings/KB-NOPE2222').expect(404);
  });
});

describe('staff session', () => {
  it('signs in with the configured password', async () => {
    const { app } = makeApp();
    const agent = request.agent(app);
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: false });
    await agent.post('/api/staff/session').send({ password: PASSWORD }).expect(200);
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: true });
  });

  it('sets an httpOnly, SameSite=Strict cookie', async () => {
    const { app } = makeApp();
    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(200);
    const cookie = String(res.headers['set-cookie']);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
  });

  it('marks the cookie Secure when the request arrived over HTTPS via a trusted proxy', async () => {
    const { app } = makeApp({ trustProxy: 1 });
    const viaProxy = await request(app)
      .post('/api/staff/session')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD })
      .expect(200);
    expect(String(viaProxy.headers['set-cookie'])).toMatch(/Secure/i);

    const plain = await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(200);
    expect(String(plain.headers['set-cookie'])).not.toMatch(/Secure/i);
  });

  it('does not trust forwarded headers unless configured', async () => {
    const { app } = makeApp();
    const res = await request(app)
      .post('/api/staff/session')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD })
      .expect(200);
    expect(String(res.headers['set-cookie'])).not.toMatch(/Secure/i);
  });

  it('refuses a wrong password with an error for the Password field', async () => {
    const { app } = makeApp();
    const res = await request(app).post('/api/staff/session').send({ password: 'nope' }).expect(401);
    expect(res.body.error.fields.password).toBe('Incorrect password');
  });

  it('refuses an empty or missing password', async () => {
    const { app } = makeApp();
    const empty = await request(app).post('/api/staff/session').send({ password: '' }).expect(401);
    expect(empty.body.error.fields.password).toBe('Enter the password');
    await request(app).post('/api/staff/session').send({}).expect(401);
    await request(app).post('/api/staff/session').send({ password: ['x'] }).expect(401);
  });

  it.each([undefined, ''])('refuses everyone when STAFF_PASSWORD is %j', async (staffPassword) => {
    const { app } = makeApp({ staffPassword });
    await request(app).post('/api/staff/session').send({ password: '' }).expect(401);
    await request(app).post('/api/staff/session').send({ password: 'undefined' }).expect(401);
    await request(app).post('/api/staff/session').send({ password: 'anything' }).expect(401);
  });

  it('ends the session on sign out, even if the old cookie is replayed', async () => {
    const { app } = makeApp();
    const login = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    const cookie = login.headers['set-cookie'];
    await request(app).get('/api/staff/bookings').set('Cookie', cookie!).expect(200);
    await request(app).delete('/api/staff/session').set('Cookie', cookie!).expect(204);
    await request(app).get('/api/staff/bookings').set('Cookie', cookie!).expect(401);
  });

  it('rate limits repeated failed sign-ins but not successful ones', async () => {
    const { app } = makeApp();
    for (let i = 0; i < 10; i++) {
      await request(app).post('/api/staff/session').send({ password: 'wrong' }).expect(401);
    }
    const limited = await request(app).post('/api/staff/session').send({ password: 'wrong' }).expect(429);
    expect(limited.body.error.fields.password).toMatch(/too many/i);
    await request(app).post('/api/staff/session').send({ password: PASSWORD }).expect(429);

    const fresh = makeApp().app;
    for (let i = 0; i < 15; i++) {
      await request(fresh).post('/api/staff/session').send({ password: PASSWORD }).expect(200);
    }
  });
});

describe('staff bookings', () => {
  it('requires a staff session for listing and cancelling', async () => {
    const { app } = makeApp();
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send(guest).expect(201);
    const list = await request(app).get('/api/staff/bookings').expect(401);
    expect(JSON.stringify(list.body)).not.toContain('anna@example.com');
    await request(app).delete(`/api/staff/bookings/${created.body.booking.reference}`).expect(401);
    const agent = await signedInStaff(app);
    const after = await agent.get('/api/staff/bookings').expect(200);
    expect(after.body.groups[2].bookings).toHaveLength(1);
  });

  it('lists bookings grouped by tasting with name, email, guests and reference', async () => {
    const { app } = makeApp();
    await request(app).post('/api/tastings/winter-tasting/bookings').send(guest).expect(201);
    const agent = await signedInStaff(app);
    const res = await agent.get('/api/staff/bookings').expect(200);
    expect(res.body.groups.map((g: { tasting: { id: string } }) => g.tasting.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    expect(res.body.groups[0].bookings).toEqual([]);
    expect(res.body.groups[2].tasting).toMatchObject({ title: 'Winter Tasting', seatsLeft: 8 });
    expect(res.body.groups[2].bookings[0]).toMatchObject({
      name: 'Anna Weber',
      email: 'anna@example.com',
      guests: 2,
      reference: expect.stringMatching(/^KB-/),
    });
  });

  it('cancels a booking, frees its seats and reports a second cancel as not found', async () => {
    const { app } = makeApp();
    const created = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 4 });
    const { reference } = created.body.booking;
    const agent = await signedInStaff(app);
    await agent.delete(`/api/staff/bookings/${reference}`).expect(204);
    const tasting = await request(app).get('/api/tastings/red-wine-cellar-tour');
    expect(tasting.body.tasting.seatsLeft).toBe(8);
    const again = await agent.delete(`/api/staff/bookings/${reference}`).expect(404);
    expect(again.body.error.code).toBe('not_found');
  });
});

describe('platform behaviour', () => {
  it('sends security headers and hides the framework', async () => {
    const { app } = makeApp();
    const res = await request(app).get('/api/tastings');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['content-security-policy']).toContain("default-src 'self'");
    expect(res.headers['content-security-policy']).not.toContain('upgrade-insecure-requests');
  });

  it('forbids caching of API answers', async () => {
    const { app } = makeApp();
    const tastings = await request(app).get('/api/tastings');
    expect(tastings.headers['cache-control']).toBe('no-store');
    const agent = await signedInStaff(app);
    expect((await agent.get('/api/staff/bookings')).headers['cache-control']).toBe('no-store');
  });

  it('answers unknown API routes with JSON 404', async () => {
    const { app } = makeApp();
    const res = await request(app).get('/api/nothing-here').expect(404);
    expect(res.body.error.code).toBe('not_found');
  });

  it('serves the built client and falls back to index.html for client routes', async () => {
    const clientDir = mkdtempSync(join(tmpdir(), 'kb-client-'));
    writeFileSync(join(clientDir, 'index.html'), '<!doctype html><title>Kieselbrunnen</title>');
    const { app } = makeApp({ clientDir });
    for (const path of ['/', '/staff', '/tastings/winter-tasting/book']) {
      const res = await request(app).get(path).expect(200);
      expect(res.text).toContain('Kieselbrunnen');
    }
  });

  it('serves hashed assets as immutable and answers a missing asset with 404, not index.html', async () => {
    const clientDir = mkdtempSync(join(tmpdir(), 'kb-client-'));
    writeFileSync(join(clientDir, 'index.html'), '<!doctype html><title>Kieselbrunnen</title>');
    mkdirSync(join(clientDir, 'assets'));
    writeFileSync(join(clientDir, 'assets', 'app-abc123.js'), 'console.log(1)');
    const { app } = makeApp({ clientDir });
    const found = await request(app).get('/assets/app-abc123.js').expect(200);
    expect(found.headers['cache-control']).toMatch(/immutable/);
    await request(app).get('/assets/missing.js').expect(404);
    const page = await request(app).get('/staff').expect(200);
    expect(page.headers['cache-control']).toBe('no-cache');
  });

  it('does not leak internals when the store throws', async () => {
    const store = createBookingStore();
    store.listTastings = () => {
      throw new Error('secret internal detail');
    };
    const { app } = makeApp({ store });
    const res = await request(app).get('/api/tastings').expect(500);
    expect(res.body.error.code).toBe('server_error');
    expect(JSON.stringify(res.body)).not.toContain('secret internal detail');
  });
});
