import { randomBytes } from 'node:crypto';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import express, { type ErrorRequestHandler, type RequestHandler, type Response } from 'express';
import { rateLimit } from 'express-rate-limit';
import session from 'express-session';
import helmet from 'helmet';
import createMemoryStore from 'memorystore';
import type { ApiErrorBody, BookingConfirmationDto, ErrorCode, TastingDto } from '../shared/api';
import { parseBookingInput } from '../shared/booking';
import { onlySeatsLeftMessage } from '../shared/seats';
import { consoleLogger, type Logger } from './log';
import { passwordMatches } from './staffAuth';
import type { Booking, BookingStore, TastingAvailability } from './store';

export interface AppOptions {
  store: BookingStore;
  /** Staff password. Staff sign-in is refused while this is unset or empty. */
  staffPassword: string | undefined;
  /** Directory with the built client; when absent only the API is served. */
  clientDir?: string;
  /** Express "trust proxy" setting; needed behind a TLS-terminating reverse proxy. */
  trustProxy?: boolean | number | string;
  log?: Logger;
}

const SESSION_MAX_AGE_MS = 8 * 60 * 60 * 1000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILED_LOGINS = 10;
const SESSION_COOKIE = 'kb_staff';

declare module 'express-session' {
  interface SessionData {
    staff?: true;
  }
}

function sendError(
  res: Response,
  status: number,
  code: ErrorCode,
  message: string,
  extra: Partial<ApiErrorBody['error']> = {},
) {
  const body: ApiErrorBody = { error: { code, message, ...extra } };
  res.status(status).json(body);
}

const toTastingDto = (t: TastingAvailability): TastingDto => ({
  id: t.id,
  title: t.title,
  startsAt: t.startsAt,
  priceCents: t.priceCents,
  seats: t.seats,
  seatsLeft: t.seatsLeft,
  soldOut: t.soldOut,
});

const toConfirmation = (booking: Booking, tasting: TastingAvailability): BookingConfirmationDto => ({
  reference: booking.reference,
  tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt, priceCents: tasting.priceCents },
  guests: booking.guests,
  totalCents: booking.totalCents,
});

export function createApp({ store, staffPassword, clientDir, trustProxy, log = consoleLogger }: AppOptions) {
  const app = express();
  app.disable('x-powered-by');
  if (trustProxy !== undefined) app.set('trust proxy', trustProxy);
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        directives: { upgradeInsecureRequests: null },
      },
    }),
  );
  app.use(express.json({ limit: '10kb' }));

  const MemoryStore = createMemoryStore(session);
  app.use(
    session({
      name: SESSION_COOKIE,
      secret: randomBytes(32).toString('hex'),
      resave: false,
      saveUninitialized: false,
      store: new MemoryStore({ checkPeriod: 60 * 60 * 1000 }),
      cookie: { httpOnly: true, sameSite: 'strict', secure: 'auto', maxAge: SESSION_MAX_AGE_MS },
    }),
  );

  const api = express.Router();
  api.use((_req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });

  api.get('/tastings', (_req, res) => {
    res.json({ tastings: store.listTastings().map(toTastingDto) });
  });

  api.get('/tastings/:id', (req, res) => {
    const tasting = store.getTasting(req.params.id);
    if (!tasting) return sendError(res, 404, 'not_found', 'Tasting not found');
    res.json({ tasting: toTastingDto(tasting) });
  });

  api.post('/tastings/:id/bookings', (req, res) => {
    const tastingId = req.params.id;
    if (!store.getTasting(tastingId)) return sendError(res, 404, 'not_found', 'Tasting not found');
    if (typeof req.body !== 'object' || req.body === null || Array.isArray(req.body)) {
      return sendError(res, 400, 'bad_request', 'Send the booking as a JSON object');
    }

    const parsed = parseBookingInput(req.body);
    if (!parsed.ok) {
      return sendError(res, 422, 'validation', 'Please correct the highlighted fields', { fields: parsed.errors });
    }

    const result = store.book(tastingId, parsed.value);
    if (result.ok) {
      log('booking_created', { reference: result.booking.reference, tastingId, guests: result.booking.guests });
      return void res.status(201).json({ booking: toConfirmation(result.booking, result.tasting) });
    }
    if (result.reason === 'unknown_tasting') return sendError(res, 404, 'not_found', 'Tasting not found');
    if (result.reason === 'sold_out') {
      return sendError(res, 409, 'sold_out', 'This tasting is fully booked', {
        seatsLeft: 0,
        fields: { guests: 'This tasting is fully booked' },
      });
    }
    sendError(res, 409, 'not_enough_seats', onlySeatsLeftMessage(result.seatsLeft), {
      seatsLeft: result.seatsLeft,
      fields: { guests: onlySeatsLeftMessage(result.seatsLeft) },
    });
  });

  api.get('/bookings/:reference', (req, res) => {
    const booking = store.findByReference(req.params.reference.toUpperCase());
    const tasting = booking && store.getTasting(booking.tastingId);
    if (!booking || !tasting) return sendError(res, 404, 'not_found', 'Booking not found');
    res.json({ booking: toConfirmation(booking, tasting) });
  });

  const loginLimiter = rateLimit({
    windowMs: LOGIN_WINDOW_MS,
    limit: MAX_FAILED_LOGINS,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    handler: (_req, res) =>
      sendError(res, 429, 'too_many_attempts', 'Too many attempts. Try again later.', {
        fields: { password: 'Too many attempts. Try again later.' },
      }),
  });

  const requireStaff: RequestHandler = (req, res, next) => {
    if (req.session.staff) return next();
    sendError(res, 401, 'unauthorized', 'Please sign in');
  };

  api.post('/staff/session', loginLimiter, (req, res, next) => {
    const password: unknown = req.body?.password;
    if (typeof password !== 'string' || password === '') {
      log('staff_login_failed', { reason: 'empty' });
      return sendError(res, 401, 'invalid_password', 'Enter the password', {
        fields: { password: 'Enter the password' },
      });
    }
    if (!passwordMatches(staffPassword, password)) {
      log('staff_login_failed', { reason: staffPassword ? 'wrong_password' : 'not_configured' });
      return sendError(res, 401, 'invalid_password', 'Incorrect password', {
        fields: { password: 'Incorrect password' },
      });
    }
    req.session.regenerate((error) => {
      if (error) return next(error);
      req.session.staff = true;
      log('staff_login');
      res.json({ signedIn: true });
    });
  });

  api.get('/staff/session', (req, res) => {
    res.json({ signedIn: req.session.staff === true });
  });

  api.delete('/staff/session', (req, res, next) => {
    req.session.destroy((error) => {
      if (error) return next(error);
      res.clearCookie(SESSION_COOKIE);
      res.status(204).end();
    });
  });

  api.get('/staff/bookings', requireStaff, (_req, res) => {
    res.json({
      groups: store.bookingsByTasting().map(({ tasting, bookings }) => ({
        tasting: toTastingDto(tasting),
        bookings: bookings.map(({ reference, name, email, guests, totalCents, createdAt }) => ({
          reference,
          name,
          email,
          guests,
          totalCents,
          createdAt,
        })),
      })),
    });
  });

  api.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
    const { reference } = req.params as { reference: string };
    if (!store.cancel(reference)) return sendError(res, 404, 'not_found', 'Booking not found');
    log('booking_cancelled', { reference });
    res.status(204).end();
  });

  api.use((_req, res) => sendError(res, 404, 'not_found', 'Not found'));
  app.use('/api', api);

  if (clientDir && existsSync(join(clientDir, 'index.html'))) {
    // Vite fingerprints everything in /assets, so those files never change under the same name.
    app.use('/assets', express.static(join(clientDir, 'assets'), { immutable: true, maxAge: '1y', fallthrough: false }));
    app.use(express.static(clientDir, { index: false, maxAge: '1h' }));
    app.get('/{*path}', (_req, res) => {
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(join(clientDir, 'index.html'));
    });
  }

  // Express recognises error handlers by their four-argument signature.
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const handleError: ErrorRequestHandler = (error, _req, res, _next) => {
    const status = typeof error?.status === 'number' ? error.status : 500;
    if (status === 404) return sendError(res, 404, 'not_found', 'Not found');
    if (status === 413) return sendError(res, 413, 'payload_too_large', 'Request is too large');
    if (status >= 400 && status < 500) return sendError(res, 400, 'bad_request', 'Invalid request');
    log('server_error', { message: error instanceof Error ? error.message : String(error) });
    sendError(res, 500, 'server_error', 'Something went wrong. Please try again.');
  };
  app.use(handleError);

  return app;
}
