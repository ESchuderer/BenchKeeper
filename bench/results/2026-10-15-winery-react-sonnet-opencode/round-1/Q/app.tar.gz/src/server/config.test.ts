import { describe, expect, it } from 'vitest';
import { parsePort, parseTrustProxy } from './config';

describe('parsePort', () => {
  it('defaults to 3000 when unset or empty', () => {
    expect(parsePort(undefined)).toBe(3000);
    expect(parsePort('')).toBe(3000);
  });

  it('accepts a valid port', () => {
    expect(parsePort('8080')).toBe(8080);
    expect(parsePort('0')).toBe(0);
  });

  it.each(['abc', '-1', '70000', '80.5', '3000x'])('rejects %j instead of silently using another port', (value) => {
    expect(() => parsePort(value)).toThrow(/PORT/);
  });
});

describe('parseTrustProxy', () => {
  it('is off when unset', () => {
    expect(parseTrustProxy(undefined)).toBeUndefined();
    expect(parseTrustProxy('')).toBeUndefined();
  });

  it('takes a number of proxy hops', () => {
    expect(parseTrustProxy('1')).toBe(1);
  });

  it.each(['true', 'yes', '-1'])('rejects %j, which would let clients spoof their address', (value) => {
    expect(() => parseTrustProxy(value)).toThrow(/TRUST_PROXY/);
  });
});
