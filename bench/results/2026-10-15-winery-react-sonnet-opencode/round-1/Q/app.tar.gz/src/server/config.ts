export function parsePort(value: string | undefined): number {
  if (!value) return 3000;
  const port = Number(value);
  if (!/^\d+$/.test(value) || port > 65535) throw new Error(`PORT must be a whole number from 0 to 65535, got "${value}"`);
  return port;
}

/** A number of proxy hops. Anything looser would let clients spoof their address. */
export function parseTrustProxy(value: string | undefined): number | undefined {
  if (!value) return undefined;
  if (!/^\d+$/.test(value)) throw new Error(`TRUST_PROXY must be a number of reverse proxies such as 1, got "${value}"`);
  return Number(value);
}
