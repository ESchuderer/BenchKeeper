import { fileURLToPath } from 'node:url';
import { createApp } from './app';
import { parsePort, parseTrustProxy } from './config';
import { consoleLogger } from './log';
import { createBookingStore } from './store';

const port = parsePort(process.env.PORT);
const staffPassword = process.env.STAFF_PASSWORD;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled until it is.');
}

const app = createApp({
  store: createBookingStore(),
  staffPassword,
  trustProxy: parseTrustProxy(process.env.TRUST_PROXY),
  clientDir: fileURLToPath(new URL('../client', import.meta.url)),
});

const server = app.listen(port, () => consoleLogger('server_started', { port }));

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
