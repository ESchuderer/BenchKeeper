export type Logger = (event: string, details?: Record<string, unknown>) => void;

export const consoleLogger: Logger = (event, details = {}) => {
  console.log(JSON.stringify({ time: new Date().toISOString(), event, ...details }));
};
