import { createHash, timingSafeEqual } from 'node:crypto';

const digest = (value: string) => createHash('sha256').update(value).digest();

/** Fails closed: an unset or empty configured password never matches. */
export function passwordMatches(configured: string | undefined, candidate: string): boolean {
  if (!configured) return false;
  return timingSafeEqual(digest(configured), digest(candidate));
}
