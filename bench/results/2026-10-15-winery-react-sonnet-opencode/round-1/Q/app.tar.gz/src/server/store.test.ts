import { describe, expect, it } from 'vitest';
import { createBookingStore } from './store';
import { TASTINGS } from './tastings';

const guest = { name: 'Anna Weber', email: 'anna@example.com' };

function seatsLeft(store: ReturnType<typeof createBookingStore>, id: string) {
  return store.listTastings().find((t) => t.id === id)?.seatsLeft;
}

describe('tasting catalogue', () => {
  it('offers the three tastings in date order with prices in cents', () => {
    expect(
      TASTINGS.map(({ title, startsAt, priceCents, seats }) => ({ title, startsAt, priceCents, seats })),
    ).toEqual([
      { title: 'Riesling Evening', startsAt: '2026-11-06 18:00', priceCents: 2500, seats: 12 },
      { title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', priceCents: 3200, seats: 8 },
      { title: 'Winter Tasting', startsAt: '2026-12-05 17:00', priceCents: 2800, seats: 10 },
    ]);
  });
});

describe('BookingStore', () => {
  it('starts with every seat free and no bookings', () => {
    const store = createBookingStore();
    expect(store.listTastings().map((t) => t.seatsLeft)).toEqual([12, 8, 10]);
    expect(store.bookingsByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });

  it('books seats, computes the total and reduces seats left', () => {
    const store = createBookingStore();
    const result = store.book('riesling-evening', { ...guest, guests: 3 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.booking).toMatchObject({ tastingId: 'riesling-evening', guests: 3, totalCents: 7500 });
    expect(seatsLeft(store, 'riesling-evening')).toBe(9);
    expect(seatsLeft(store, 'winter-tasting')).toBe(10);
  });

  it('accepts a booking that takes exactly the seats left and then reports sold out', () => {
    const store = createBookingStore();
    store.book('red-wine-cellar-tour', { ...guest, guests: 5 });
    const result = store.book('red-wine-cellar-tour', { ...guest, guests: 3 });
    expect(result.ok).toBe(true);
    const tasting = store.listTastings().find((t) => t.id === 'red-wine-cellar-tour');
    expect(tasting).toMatchObject({ seatsLeft: 0, soldOut: true });
  });

  it('rejects a booking that needs more seats than are left and changes nothing', () => {
    const store = createBookingStore();
    store.book('red-wine-cellar-tour', { ...guest, guests: 5 });
    const result = store.book('red-wine-cellar-tour', { ...guest, guests: 4 });
    expect(result).toEqual({ ok: false, reason: 'not_enough_seats', seatsLeft: 3 });
    expect(seatsLeft(store, 'red-wine-cellar-tour')).toBe(3);
  });

  it('rejects any booking for a sold-out tasting', () => {
    const store = createBookingStore();
    store.book('red-wine-cellar-tour', { ...guest, guests: 8 });
    const result = store.book('red-wine-cellar-tour', { ...guest, guests: 1 });
    expect(result).toEqual({ ok: false, reason: 'sold_out', seatsLeft: 0 });
  });

  it.each([0, -1, 2.5, Number.NaN, Number.POSITIVE_INFINITY])(
    'refuses %s guests even if the caller skipped validation, leaving seats untouched',
    (guests) => {
      const store = createBookingStore();
      const result = store.book('riesling-evening', { ...guest, guests });
      expect(result.ok).toBe(false);
      expect(seatsLeft(store, 'riesling-evening')).toBe(12);
      store.book('riesling-evening', { ...guest, guests: 12 });
      expect(store.getTasting('riesling-evening')?.soldOut).toBe(true);
    },
  );

  it('draws a new reference when one is already taken', () => {
    const draws = ['KB-AAAAAAAA', 'KB-AAAAAAAA', 'KB-BBBBBBBB'];
    const store = createBookingStore(undefined, () => draws.shift()!);
    const first = store.book('riesling-evening', { ...guest, guests: 1 });
    const second = store.book('riesling-evening', { ...guest, guests: 1 });
    expect([first, second].map((r) => r.ok && r.booking.reference)).toEqual(['KB-AAAAAAAA', 'KB-BBBBBBBB']);
  });

  it('returns the updated tasting with a successful booking', () => {
    const store = createBookingStore();
    const result = store.book('riesling-evening', { ...guest, guests: 5 });
    expect(result.ok && result.tasting.seatsLeft).toBe(7);
  });

  it('rejects an unknown tasting', () => {
    const store = createBookingStore();
    expect(store.book('nope', { ...guest, guests: 1 })).toEqual({ ok: false, reason: 'unknown_tasting' });
  });

  it('never oversells when many bookings are attempted', () => {
    const store = createBookingStore();
    const outcomes = Array.from({ length: 20 }, () => store.book('winter-tasting', { ...guest, guests: 3 }));
    expect(outcomes.filter((o) => o.ok)).toHaveLength(3);
    expect(seatsLeft(store, 'winter-tasting')).toBe(1);
  });

  it('gives every booking a unique reference', () => {
    const store = createBookingStore();
    const references = new Set<string>();
    for (let i = 0; i < 12; i++) {
      const result = store.book('riesling-evening', { ...guest, guests: 1 });
      if (result.ok) references.add(result.booking.reference);
    }
    expect(references.size).toBe(12);
    for (const reference of references) expect(reference).toMatch(/^KB-[A-Z2-9]{8}$/);
  });

  it('finds an active booking by reference', () => {
    const store = createBookingStore();
    const result = store.book('winter-tasting', { ...guest, guests: 2 });
    if (!result.ok) throw new Error('booking failed');
    expect(store.findByReference(result.booking.reference)).toEqual(result.booking);
    expect(store.findByReference('KB-UNKNOWN0')).toBeUndefined();
  });

  it('groups bookings by tasting', () => {
    const store = createBookingStore();
    store.book('winter-tasting', { ...guest, guests: 2 });
    store.book('riesling-evening', { name: 'Ben', email: 'ben@example.com', guests: 1 });
    store.book('winter-tasting', { name: 'Cleo', email: 'cleo@example.com', guests: 4 });
    const groups = store.bookingsByTasting();
    expect(groups.map((g) => [g.tasting.id, g.bookings.length])).toEqual([
      ['riesling-evening', 1],
      ['red-wine-cellar-tour', 0],
      ['winter-tasting', 2],
    ]);
  });

  it('frees the seats when a booking is cancelled and forgets the booking', () => {
    const store = createBookingStore();
    const result = store.book('red-wine-cellar-tour', { ...guest, guests: 4 });
    if (!result.ok) throw new Error('booking failed');
    expect(seatsLeft(store, 'red-wine-cellar-tour')).toBe(4);
    expect(store.cancel(result.booking.reference)).toBe(true);
    expect(seatsLeft(store, 'red-wine-cellar-tour')).toBe(8);
    expect(store.findByReference(result.booking.reference)).toBeUndefined();
  });

  it('does not free seats twice when a booking is cancelled again', () => {
    const store = createBookingStore();
    const first = store.book('riesling-evening', { ...guest, guests: 2 });
    store.book('riesling-evening', { ...guest, guests: 3 });
    if (!first.ok) throw new Error('booking failed');
    store.cancel(first.booking.reference);
    expect(store.cancel(first.booking.reference)).toBe(false);
    expect(seatsLeft(store, 'riesling-evening')).toBe(9);
  });

  it('lets cancelled seats be booked again', () => {
    const store = createBookingStore();
    const full = store.book('red-wine-cellar-tour', { ...guest, guests: 8 });
    if (!full.ok) throw new Error('booking failed');
    store.cancel(full.booking.reference);
    expect(store.book('red-wine-cellar-tour', { ...guest, guests: 8 }).ok).toBe(true);
  });
});
