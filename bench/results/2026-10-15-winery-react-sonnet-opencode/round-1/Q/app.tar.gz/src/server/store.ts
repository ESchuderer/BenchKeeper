import { randomInt } from 'node:crypto';
import type { BookingInput } from '../shared/booking';
import { TASTINGS, type Tasting } from './tastings';

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  totalCents: number;
  createdAt: string;
}

export interface TastingAvailability extends Tasting {
  seatsLeft: number;
  soldOut: boolean;
}

export type BookResult =
  | { ok: true; booking: Booking; tasting: TastingAvailability }
  | { ok: false; reason: 'unknown_tasting' }
  | { ok: false; reason: 'sold_out' | 'not_enough_seats'; seatsLeft: number };

export interface BookingGroup {
  tasting: TastingAvailability;
  bookings: Booking[];
}

export interface BookingStore {
  listTastings(): TastingAvailability[];
  getTasting(id: string): TastingAvailability | undefined;
  /** Synchronous on purpose: check-and-insert cannot interleave with another request. */
  book(tastingId: string, input: BookingInput): BookResult;
  cancel(reference: string): boolean;
  findByReference(reference: string): Booking | undefined;
  bookingsByTasting(): BookingGroup[];
}

const REFERENCE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const REFERENCE_LENGTH = 8;

function randomReference(): string {
  let code = '';
  for (let i = 0; i < REFERENCE_LENGTH; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  return `KB-${code}`;
}

export function createBookingStore(
  tastings: readonly Tasting[] = TASTINGS,
  generateReference: () => string = randomReference,
): BookingStore {
  const bookings = new Map<string, Booking>();

  const bookedSeats = (tastingId: string) => {
    let total = 0;
    for (const booking of bookings.values()) if (booking.tastingId === tastingId) total += booking.guests;
    return total;
  };

  const withAvailability = (tasting: Tasting): TastingAvailability => {
    const seatsLeft = tasting.seats - bookedSeats(tasting.id);
    return { ...tasting, seatsLeft, soldOut: seatsLeft <= 0 };
  };

  const newReference = () => {
    let reference = generateReference();
    while (bookings.has(reference)) reference = generateReference();
    return reference;
  };

  return {
    listTastings: () => tastings.map(withAvailability),

    getTasting(id) {
      const tasting = tastings.find((t) => t.id === id);
      return tasting && withAvailability(tasting);
    },

    book(tastingId, input) {
      const tasting = tastings.find((t) => t.id === tastingId);
      if (!tasting) return { ok: false, reason: 'unknown_tasting' };
      // The store owns the seat invariant, whatever the caller validated.
      if (!Number.isInteger(input.guests) || input.guests < 1) {
        return { ok: false, reason: 'not_enough_seats', seatsLeft: withAvailability(tasting).seatsLeft };
      }
      const { seatsLeft } = withAvailability(tasting);
      if (seatsLeft <= 0) return { ok: false, reason: 'sold_out', seatsLeft: 0 };
      if (input.guests > seatsLeft) return { ok: false, reason: 'not_enough_seats', seatsLeft };
      const booking: Booking = {
        reference: newReference(),
        tastingId,
        name: input.name,
        email: input.email,
        guests: input.guests,
        totalCents: input.guests * tasting.priceCents,
        createdAt: new Date().toISOString(),
      };
      bookings.set(booking.reference, booking);
      return { ok: true, booking, tasting: withAvailability(tasting) };
    },

    cancel: (reference) => bookings.delete(reference),

    findByReference: (reference) => bookings.get(reference),

    bookingsByTasting: () =>
      tastings.map((tasting) => ({
        tasting: withAvailability(tasting),
        bookings: [...bookings.values()].filter((b) => b.tastingId === tasting.id),
      })),
  };
}
