export interface Tasting {
  id: string;
  title: string;
  /** Winery-local wall-clock time, "YYYY-MM-DD HH:mm". */
  startsAt: string;
  priceCents: number;
  seats: number;
}

export const TASTINGS: readonly Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06 18:00', priceCents: 2500, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', priceCents: 3200, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05 17:00', priceCents: 2800, seats: 10 },
];
