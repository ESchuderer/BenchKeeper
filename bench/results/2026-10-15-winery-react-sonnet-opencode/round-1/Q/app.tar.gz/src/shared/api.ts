import type { FieldErrors } from './booking';

export interface TastingDto {
  id: string;
  title: string;
  startsAt: string;
  priceCents: number;
  seats: number;
  seatsLeft: number;
  soldOut: boolean;
}

export interface BookingConfirmationDto {
  reference: string;
  tasting: Pick<TastingDto, 'id' | 'title' | 'startsAt' | 'priceCents'>;
  guests: number;
  totalCents: number;
}

export interface StaffBookingDto {
  reference: string;
  name: string;
  email: string;
  guests: number;
  totalCents: number;
  createdAt: string;
}

export interface StaffGroupDto {
  tasting: TastingDto;
  bookings: StaffBookingDto[];
}

export type ErrorCode =
  | 'validation'
  | 'not_enough_seats'
  | 'sold_out'
  | 'not_found'
  | 'unauthorized'
  | 'invalid_password'
  | 'too_many_attempts'
  | 'bad_request'
  | 'payload_too_large'
  | 'server_error';

export interface ApiErrorBody {
  error: {
    code: ErrorCode;
    message: string;
    fields?: FieldErrors & { password?: string };
    seatsLeft?: number;
  };
}
