import { describe, expect, it } from 'vitest';
import { parseBookingInput } from './booking';

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

describe('parseBookingInput', () => {
  it('accepts a valid booking and trims name and email', () => {
    const result = parseBookingInput({ name: '  Anna Weber ', email: ' anna@example.com ', guests: 2 });
    expect(result).toEqual({ ok: true, value: valid });
  });

  it.each([1, 8])('accepts %i guests', (guests) => {
    expect(parseBookingInput({ ...valid, guests }).ok).toBe(true);
  });

  it.each(['', '   '])('rejects a blank name (%j)', (name) => {
    const result = parseBookingInput({ ...valid, name });
    expect(result).toEqual({ ok: false, errors: { name: 'Enter your name' } });
  });

  it('accepts a name of exactly 100 characters', () => {
    expect(parseBookingInput({ ...valid, name: 'x'.repeat(100) }).ok).toBe(true);
  });

  it('rejects a name longer than 100 characters', () => {
    const result = parseBookingInput({ ...valid, name: 'x'.repeat(101) });
    expect(result).toEqual({ ok: false, errors: { name: 'Name must be at most 100 characters' } });
  });

  it.each(['', 'not-an-email', 'a@b', 'a b@example.com'])('rejects the email %j', (email) => {
    const result = parseBookingInput({ ...valid, email });
    expect(result).toEqual({ ok: false, errors: { email: 'Enter a valid email address' } });
  });

  it('rejects an email longer than 254 characters', () => {
    const result = parseBookingInput({ ...valid, email: `${'a'.repeat(250)}@example.com` });
    expect(result.ok).toBe(false);
  });

  it.each([0, 9, -1, 2.5, Number.NaN, '3', null, undefined, true])(
    'rejects guests = %j',
    (guests) => {
      const result = parseBookingInput({ ...valid, guests });
      expect(result).toEqual({ ok: false, errors: { guests: 'Choose between 1 and 8 guests' } });
    },
  );

  it('reports every invalid field at once', () => {
    const result = parseBookingInput({});
    expect(result).toEqual({
      ok: false,
      errors: {
        name: 'Enter your name',
        email: 'Enter a valid email address',
        guests: 'Choose between 1 and 8 guests',
      },
    });
  });

  it('rejects input that is not an object', () => {
    expect(parseBookingInput(null).ok).toBe(false);
    expect(parseBookingInput('x').ok).toBe(false);
  });

  it('ignores unknown properties', () => {
    const result = parseBookingInput({ ...valid, isAdmin: true });
    expect(result).toEqual({ ok: true, value: valid });
  });
});
