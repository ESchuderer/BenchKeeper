import { z } from 'zod';

export const MAX_GUESTS_PER_BOOKING = 8;
const MAX_NAME_LENGTH = 100;
const MAX_EMAIL_LENGTH = 254;

export const GUESTS_MESSAGE = `Choose between 1 and ${MAX_GUESTS_PER_BOOKING} guests`;
export const EMAIL_MESSAGE = 'Enter a valid email address';

export const bookingInputSchema = z.object({
  name: z
    .string({ error: 'Enter your name' })
    .trim()
    .min(1, 'Enter your name')
    .max(MAX_NAME_LENGTH, `Name must be at most ${MAX_NAME_LENGTH} characters`),
  email: z
    .string({ error: EMAIL_MESSAGE })
    .trim()
    .max(MAX_EMAIL_LENGTH, EMAIL_MESSAGE)
    .pipe(z.email(EMAIL_MESSAGE)),
  guests: z
    .number({ error: GUESTS_MESSAGE })
    .int(GUESTS_MESSAGE)
    .min(1, GUESTS_MESSAGE)
    .max(MAX_GUESTS_PER_BOOKING, GUESTS_MESSAGE),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;
export type BookingField = keyof BookingInput;
export type FieldErrors = Partial<Record<BookingField, string>>;

export type ParseResult = { ok: true; value: BookingInput } | { ok: false; errors: FieldErrors };

const FIELDS: readonly string[] = ['name', 'email', 'guests'];

export function parseBookingInput(input: unknown): ParseResult {
  const result = bookingInputSchema.safeParse(input);
  if (result.success) return { ok: true, value: result.data };
  return { ok: false, errors: firstErrorPerField(result.error.issues) };
}

function firstErrorPerField(issues: readonly z.core.$ZodIssue[]): FieldErrors {
  const errors: FieldErrors = {};
  for (const issue of issues) {
    const field = issue.path[0];
    if (typeof field === 'string' && FIELDS.includes(field) && !errors[field as BookingField]) {
      errors[field as BookingField] = issue.message;
    }
  }
  return errors;
}
