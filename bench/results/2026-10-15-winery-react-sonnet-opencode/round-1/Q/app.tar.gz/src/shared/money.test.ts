import { describe, expect, it } from 'vitest';
import { formatMoney } from './money';

describe('formatMoney', () => {
  it('shows whole euros without decimals', () => {
    expect(formatMoney(2500)).toBe('EUR 25');
  });

  it('shows cents when the amount is not whole', () => {
    expect(formatMoney(2550)).toBe('EUR 25.50');
    expect(formatMoney(5)).toBe('EUR 0.05');
  });

  it('formats a multi-guest total', () => {
    expect(formatMoney(3 * 3200)).toBe('EUR 96');
  });
});
