export function formatMoney(cents: number): string {
  const euros = cents / 100;
  return Number.isInteger(euros) ? `EUR ${euros}` : `EUR ${euros.toFixed(2)}`;
}
