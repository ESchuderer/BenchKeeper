import { describe, expect, it } from 'vitest';
import { onlySeatsLeftMessage, seatsLeftLabel } from './seats';

describe('seat wording', () => {
  it.each([
    [12, '12 seats left'],
    [2, '2 seats left'],
    [1, '1 seat left'],
    [0, '0 seats left'],
  ])('labels %i seats', (n, label) => {
    expect(seatsLeftLabel(n)).toBe(label);
  });

  it('words the over-limit message', () => {
    expect(onlySeatsLeftMessage(3)).toBe('Only 3 seats left');
    expect(onlySeatsLeftMessage(1)).toBe('Only 1 seat left');
  });
});
