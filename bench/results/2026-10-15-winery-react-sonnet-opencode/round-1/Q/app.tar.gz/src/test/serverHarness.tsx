import type { Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { afterEach, vi } from 'vitest';
import { App } from '../client/App';
import { createApp } from '../server/app';
import { createBookingStore, type BookingStore } from '../server/store';

export const STAFF_PASSWORD = 'test-staff-password';

export interface Harness {
  store: BookingStore;
  /** Every API request the client has made, in order. */
  requests: { method: string; path: string }[];
  /** Make every request fail as if the network were down. */
  setOffline(offline: boolean): void;
  /** Delay every response, to observe in-flight states. */
  setLatency(ms: number): void;
}

const servers: Server[] = [];

afterEach(async () => {
  vi.unstubAllGlobals();
  await Promise.all(servers.splice(0).map((s) => new Promise((resolve) => s.close(resolve))));
});

/**
 * Runs the real API in-process and routes the client's `fetch` to it, keeping cookies like a browser.
 * Only the network boundary is substituted.
 */
export async function startHarness(): Promise<Harness> {
  const store = createBookingStore();
  const app = createApp({ store, staffPassword: STAFF_PASSWORD, log: () => {} });
  const server = await new Promise<Server>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  servers.push(server);
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

  const realFetch = globalThis.fetch;
  const cookies = new Map<string, string>();
  const harness: Harness = { store, requests: [], setOffline: () => {}, setLatency: () => {} };
  let offline = false;
  let latency = 0;
  harness.setOffline = (value) => (offline = value);
  harness.setLatency = (ms) => (latency = ms);

  vi.stubGlobal('fetch', async (input: string, init: RequestInit = {}) => {
    harness.requests.push({ method: init.method ?? 'GET', path: input });
    if (offline) throw new TypeError('Failed to fetch');
    if (latency) await new Promise((resolve) => setTimeout(resolve, latency));
    const headers = new Headers(init.headers);
    if (cookies.size) headers.set('cookie', [...cookies].map(([k, v]) => `${k}=${v}`).join('; '));
    const response = await realFetch(base + input, { ...init, headers });
    for (const line of response.headers.getSetCookie()) {
      const [pair = ''] = line.split(';');
      const [name = '', ...value] = pair.split('=');
      if (/max-age=0|expires=Thu, 01 Jan 1970/i.test(line)) cookies.delete(name);
      else cookies.set(name, value.join('='));
    }
    return response;
  });
  return harness;
}

export function renderApp(path = '/') {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const user = userEvent.setup();
  const utils = render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={[path]}>
        <App />
      </MemoryRouter>
    </QueryClientProvider>,
  );
  return { user, ...utils };
}

export const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };
