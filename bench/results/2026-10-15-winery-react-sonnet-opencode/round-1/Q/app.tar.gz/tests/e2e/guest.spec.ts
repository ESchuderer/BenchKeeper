import { expect, test } from '@playwright/test';
import { bookTasting, resetBookings } from './helpers';

test.beforeEach(async ({ request }) => resetBookings(request));

const anna = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

test('start page lists the three tastings with price and seats', async ({ page }) => {
  await page.goto('/');
  const cards = page.getByRole('article');
  await expect(cards).toHaveCount(3);
  await expect(page.getByRole('article').filter({ hasText: 'Riesling Evening' })).toContainText('2026-11-06 18:00');
  await expect(page.getByRole('article').filter({ hasText: 'Riesling Evening' })).toContainText('EUR 25');
  await expect(page.getByRole('article').filter({ hasText: 'Riesling Evening' })).toContainText('12 seats left');
  await expect(page.getByRole('article').filter({ hasText: 'Red Wine Cellar Tour' })).toContainText('8 seats left');
  await expect(page.getByRole('article').filter({ hasText: 'Winter Tasting' })).toContainText('10 seats left');
});

test('a guest books a tasting and sees the confirmation', async ({ page }) => {
  await bookTasting(page, 'Riesling Evening', anna);

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const main = page.getByRole('main');
  await expect(main).toContainText('Riesling Evening');
  await expect(main).toContainText('EUR 50');
  await expect(main.getByText(/^KB-[A-Z2-9]{8}$/)).toBeVisible();

  await page.reload();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(main).toContainText('EUR 50');

  await page.getByRole('link', { name: /all tastings/i }).click();
  await expect(page.getByRole('article').filter({ hasText: 'Riesling Evening' })).toContainText('10 seats left');
});

test('invalid input is rejected with an error next to each field', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'Book Winter Tasting' }).click();
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription(/Enter your name/);
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription(/valid email/);
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/between 1 and 8/);

  await page.getByLabel('Name').fill('Anna');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/between 1 and 8/);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
});

test('a booking can never take more seats than are left', async ({ page, request }) => {
  await bookTasting(page, 'Red Wine Cellar Tour', { ...anna, guests: 6 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await bookTasting(page, 'Red Wine Cellar Tour', { ...anna, guests: 3 });
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/Only 2 seats left/);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);

  const direct = await request.post('/api/tastings/red-wine-cellar-tour/bookings', {
    data: { name: 'Eve', email: 'eve@example.com', guests: 3 },
  });
  expect(direct.status()).toBe(409);

  await bookTasting(page, 'Red Wine Cellar Tour', { ...anna, guests: 2 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
});

test('a fully booked tasting is marked and cannot be booked', async ({ page, request }) => {
  await bookTasting(page, 'Red Wine Cellar Tour', { ...anna, guests: 8 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  const card = page.getByRole('article').filter({ hasText: 'Red Wine Cellar Tour' });
  await expect(card).toContainText('Fully booked');
  await expect(card.getByRole('button', { name: 'Book Red Wine Cellar Tour' })).toBeDisabled();

  await page.goto('/tastings/red-wine-cellar-tour/book');
  await expect(page.getByText(/fully booked/i).first()).toBeVisible();
  await expect(page.getByLabel('Name')).toHaveCount(0);

  const direct = await request.post('/api/tastings/red-wine-cellar-tour/bookings', {
    data: { name: 'Eve', email: 'eve@example.com', guests: 1 },
  });
  expect(direct.status()).toBe(409);
});

test('a guest can book using only the keyboard', async ({ page }) => {
  await page.goto('/tastings/winter-tasting/book');
  await page.getByLabel('Name').focus();
  await page.keyboard.type('Keyboard Kim');
  await page.keyboard.press('Tab');
  await page.keyboard.type('kim@example.com');
  await page.keyboard.press('Tab');
  await page.keyboard.type('3');
  await page.keyboard.press('Tab');
  await expect(page.getByRole('button', { name: 'Book', exact: true })).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeFocused();
  await expect(page.getByRole('main')).toContainText('EUR 84');
});

test('unknown tasting and unknown page are reported', async ({ page }) => {
  await page.goto('/tastings/nope/book');
  await expect(page.getByRole('heading', { name: 'Tasting not found' })).toBeVisible();
  await page.goto('/nowhere');
  await expect(page.getByRole('heading', { name: 'Page not found' })).toBeVisible();
});
