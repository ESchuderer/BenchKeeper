import { expect, type APIRequestContext, type Page } from '@playwright/test';

export const STAFF_PASSWORD = 'e2e-secret-password';

/** Removes every booking so each test starts from the same empty state. */
export async function resetBookings(request: APIRequestContext) {
  await request.post('/api/staff/session', { data: { password: STAFF_PASSWORD } });
  const { groups } = await (await request.get('/api/staff/bookings')).json();
  for (const group of groups) {
    for (const booking of group.bookings) await request.delete(`/api/staff/bookings/${booking.reference}`);
  }
}

export async function bookTasting(
  page: Page,
  tasting: string,
  guest: { name: string; email: string; guests: number | string },
) {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${tasting}` }).click();
  await page.getByLabel('Name').fill(guest.name);
  await page.getByLabel('Email').fill(guest.email);
  await page.getByLabel('Guests').fill(String(guest.guests));
  await page.getByRole('button', { name: 'Book', exact: true }).click();
}

export async function signInAsStaff(page: Page, password = STAFF_PASSWORD) {
  await page.goto('/staff');
  await page.getByLabel('Password').fill(password);
  await page.getByRole('button', { name: 'Sign in' }).click();
}

export async function expectNoHorizontalScroll(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow).toBeLessThanOrEqual(0);
}
