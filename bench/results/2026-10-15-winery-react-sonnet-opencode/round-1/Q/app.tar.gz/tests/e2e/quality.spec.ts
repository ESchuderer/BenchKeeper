import AxeBuilder from '@axe-core/playwright';
import { expect, test, type Page } from '@playwright/test';
import { bookTasting, expectNoHorizontalScroll, resetBookings, signInAsStaff } from './helpers';

test.beforeEach(async ({ request }) => resetBookings(request));

const anna = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

async function expectNoAxeViolations(page: Page) {
  const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
  expect(results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target).join(' | ')}`)).toEqual([]);
}

async function expectTouchTargets(page: Page) {
  const small = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>('main a, main button, main input, footer a, header a')]
      .filter((el) => !el.matches('.sr-only') && el.getBoundingClientRect().width > 0)
      .map((el) => ({ name: (el.textContent || el.id).trim().slice(0, 30), h: el.getBoundingClientRect().height }))
      .filter((el) => el.h < 44),
  );
  expect(small).toEqual([]);
}

test.describe('accessibility (axe, WCAG 2.1 AA)', () => {
  test('guest pages', async ({ page, request }) => {
    await page.goto('/');
    await page.getByRole('article').first().waitFor();
    await expectNoAxeViolations(page);

    await page.goto('/tastings/riesling-evening/book');
    await page.getByRole('button', { name: 'Book', exact: true }).click();
    await expect(page.getByText('Enter your name')).toBeVisible();
    await expectNoAxeViolations(page);

    await request.post('/api/tastings/red-wine-cellar-tour/bookings', { data: { ...anna, guests: 8 } });
    await page.goto('/');
    await expect(page.getByText('Fully booked')).toBeVisible();
    await expectNoAxeViolations(page);

    await bookTasting(page, 'Winter Tasting', anna);
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    await expectNoAxeViolations(page);
  });

  test('staff pages', async ({ page, request }) => {
    await request.post('/api/tastings/winter-tasting/bookings', { data: anna });
    await page.goto('/staff');
    await page.getByLabel('Password').fill('wrong');
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page.getByText('Incorrect password')).toBeVisible();
    await expectNoAxeViolations(page);

    await signInAsStaff(page);
    await expect(page.getByText('Anna Weber')).toBeVisible();
    await expectNoAxeViolations(page);
  });
});

test.describe('phone layout @phone', () => {
  test('every page fits a 360px screen with comfortable touch targets', async ({ page, request }) => {
    await request.post('/api/tastings/winter-tasting/bookings', {
      data: { name: 'A very long name for a very narrow screen', email: 'a.very.long.address.for.testing@example-winery.com', guests: 3 },
    });

    await page.goto('/');
    await page.getByRole('article').first().waitFor();
    await expectNoHorizontalScroll(page);
    await expectTouchTargets(page);

    await page.goto('/tastings/riesling-evening/book');
    await page.getByRole('button', { name: 'Book', exact: true }).click();
    await expect(page.getByText('Enter your name')).toBeVisible();
    await expectNoHorizontalScroll(page);
    await expectTouchTargets(page);

    await signInAsStaff(page);
    await expect(page.getByText('A very long name for a very narrow screen')).toBeVisible();
    await expectNoHorizontalScroll(page);
    await expectTouchTargets(page);
    await page.screenshot({ path: 'test-results/phone-staff.png', fullPage: true });
  });
});

test('a full guest and staff journey logs no console errors', async ({ page }) => {
  const problems: string[] = [];
  page.on('console', (message) => {
    if (['error', 'warning'].includes(message.type())) problems.push(message.text());
  });
  page.on('pageerror', (error) => problems.push(error.message));

  await bookTasting(page, 'Winter Tasting', anna);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await signInAsStaff(page);
  await page.getByRole('button', { name: 'Cancel' }).click();
  await expect(page.getByRole('status')).toContainText(/cancelled/i);
  await page.goto('/nowhere');
  await expect(page.getByRole('heading', { name: 'Page not found' })).toBeVisible();

  expect(problems).toEqual([]);
});
