import { expect, test } from '@playwright/test';
import { bookTasting, resetBookings, signInAsStaff } from './helpers';

test.beforeEach(async ({ request }) => resetBookings(request));

const anna = { name: 'Anna Weber', email: 'anna@example.com', guests: 4 };

test('staff are asked for a password and a wrong one is refused', async ({ page }) => {
  await bookTasting(page, 'Winter Tasting', anna);
  await page.getByRole('heading', { name: 'Booking confirmed' }).waitFor();

  await signInAsStaff(page, 'not the password');
  await expect(page.getByLabel('Password')).toHaveAccessibleDescription(/Incorrect password/);
  await expect(page.getByText(anna.email)).toHaveCount(0);
});

test('bookings are protected without a staff session', async ({ playwright, baseURL }) => {
  const anonymous = await playwright.request.newContext({ baseURL });
  expect((await anonymous.get('/api/staff/bookings')).status()).toBe(401);
  expect((await anonymous.delete('/api/staff/bookings/KB-ANYTHING')).status()).toBe(401);
  await anonymous.dispose();
});

test('staff see bookings grouped by tasting and can cancel one to free its seats', async ({ page }) => {
  await bookTasting(page, 'Winter Tasting', anna);
  await page.getByRole('heading', { name: 'Booking confirmed' }).waitFor();
  const reference = (await page.getByText(/^KB-[A-Z2-9]{8}$/).textContent())!;

  await page.goto('/');
  await expect(page.getByRole('article').filter({ hasText: 'Winter Tasting' })).toContainText('6 seats left');

  await signInAsStaff(page);
  await expect(page.getByRole('heading', { name: 'Bookings', level: 1 })).toBeVisible();
  const group = page.locator('section').filter({ has: page.getByRole('heading', { name: 'Winter Tasting' }) });
  const row = group.getByRole('row', { name: /Anna Weber/ });
  await expect(row).toContainText('anna@example.com');
  await expect(row).toContainText('4');
  await expect(row).toContainText(reference);
  const empty = page.locator('section').filter({ has: page.getByRole('heading', { name: 'Riesling Evening' }) });
  await expect(empty).toContainText('No bookings yet');

  await row.getByRole('button', { name: 'Cancel' }).click();
  await expect(page.getByText('Anna Weber')).toHaveCount(0);
  await expect(page.getByRole('status')).toContainText(/cancelled/i);

  await page.goto('/');
  await expect(page.getByRole('article').filter({ hasText: 'Winter Tasting' })).toContainText('10 seats left');
});

test('staff can sign out', async ({ page }) => {
  await signInAsStaff(page);
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Password')).toBeVisible();
});
