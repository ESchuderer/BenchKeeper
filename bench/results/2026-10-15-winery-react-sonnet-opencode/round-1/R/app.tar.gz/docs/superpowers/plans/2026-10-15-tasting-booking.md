# Tasting Booking Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Web app where guests book winery tastings and staff view/cancel bookings.

**Architecture:** One Node 22 process. Express serves `/api/*` and the built React SPA (`dist/client`). Node runs the TypeScript server directly (type stripping, `.ts` import extensions). A shared module holds the tasting catalogue, zod booking schema and money formatting, used by client and server. Booking state lives in an in-memory store whose book operation is synchronous (atomic).

**Tech Stack:** TypeScript, Express 5, React 19, Vite, React Router, react-hook-form + zod, Tailwind CSS 4, helmet, express-session, express-rate-limit, Vitest, Testing Library, supertest.

**Spec:** `docs/superpowers/specs/2026-10-15-tasting-booking-design.md`

## Global Constraints
- Node.js 22; `npm install`, `npm run build`, `npm start` serves the whole app on `PORT` (default 3000).
- Start with no bookings; no external services; UI in English.
- Tastings: Riesling Evening 2026-11-06 18:00 EUR 25 12 seats; Red Wine Cellar Tour 2026-11-14 15:00 EUR 32 8 seats; Winter Tasting 2026-12-05 17:00 EUR 28 10 seats.
- Start page copy: "<n> seats left"; links "Book <tasting title>"; form labels "Name", "Email", "Guests" (1 to 8), button "Book"; heading "Booking confirmed".
- Staff: `/staff`, "Password" field, "Sign in" button, password from `STAFF_PASSWORD`; "Cancel" button per booking; bookings grouped by tasting with name, email, guests, reference.
- Errors appear next to the field concerned. Never exceed seats left.

## Review Focus
1. Two parallel bookings for the last seats: only one succeeds (Task 2 test).
2. Guests as `0`, `9`, `2.5`, `""`, `"abc"` sent directly to the API: 400 with a `guests` field error (Task 1/2 tests).
3. Name of only whitespace; HTML in name or email rendered as text in staff view (Tasks 1, 4).
4. Staff API without session, wrong password, and `STAFF_PASSWORD` unset: 401, never data (Task 2 tests).
5. Unknown tasting id or reference: 404 and a friendly not-found page (Tasks 2, 3).
6. Cancelling frees seats and the start page count rises again (Tasks 2, 4).

---

### Task 1: Scaffold and shared domain
**Files:** Create `package.json`, `tsconfig.json`, `vite.config.ts`, `index.html`, `shared/tastings.ts`, `shared/booking.ts`, `shared/booking.test.ts`.

**Interfaces — Produces:**
- `type Tasting = { id: string; title: string; startsAt: string /* "2026-11-06T18:00" */; priceEur: number; capacity: number }`
- `TASTINGS: readonly Tasting[]` (ids `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`); `findTasting(id: string): Tasting | undefined`
- `bookingSchema(seatsLeft: number)`: zod object `{ name, email, guests }` (`guests` coerced from number or numeric string); `type BookingInput`
- `formatEur(n: number): string` → `"EUR 25"`; `formatWhen(startsAt: string): string` (e.g. "Fri 6 Nov 2026, 18:00")
- npm scripts: `dev`, `build` (vite build → `dist/client`), `start` (`node server/index.ts`), `test` (vitest run), `typecheck`.

- [ ] Write failing tests in `shared/booking.test.ts`: valid input passes; guests 0, 9, 2.5, "", "abc" fail on path `guests`; guests 3 with seatsLeft 2 fails with message containing "2"; name "   " fails on `name`; email "nope" fails on `email`; name/email trimmed; `formatEur(25) === "EUR 25"`.
- [ ] Run `npx vitest run shared` → FAIL.
- [ ] Implement shared modules; write the config files. Run → PASS; run `npm run typecheck`.

### Task 2: Store and API
**Files:** Create `server/store.ts`, `server/app.ts` (`createApp({ staffPassword?: string, sessionSecret?: string }): Express`, no listen), `server/index.ts` (reads env, listens), tests `server/store.test.ts`, `server/app.test.ts`.

**Interfaces — Consumes:** Task 1 shared. **Produces (HTTP):**
- `GET /api/tastings` → `[{...Tasting, seatsLeft: number, soldOut: boolean}]`
- `POST /api/tastings/:id/bookings` body `{name,email,guests}` → 201 `{reference, tastingId, tastingTitle, guests, totalEur}`; 400 `{errors: {name?:string,email?:string,guests?:string}}`; 404 unknown tasting; 409 `{errors:{guests:"..."}}` when seats ran out between validation and booking (same shape as 400 so the form shows it)
- `GET /api/bookings/:reference` → `{reference, tastingId, tastingTitle, startsAt, guests, totalEur}` or 404
- `POST /api/staff/login {password}` → 204 / 401 `{error}`; `POST /api/staff/logout` → 204; `GET /api/staff/session` → `{signedIn: boolean}`
- `GET /api/staff/bookings` → 401 or `[{tasting: Tasting, seatsLeft, bookings:[{reference,name,email,guests,createdAt}]}]`; `DELETE /api/staff/bookings/:reference` → 204 / 401 / 404

- [ ] Write failing store tests (`createStore()`: `book`, `cancel`, `seatsLeft`, `listByTasting`): books reduce seats; overbooking returns error and leaves state unchanged; last seat can be taken; cancel frees seats; unique references.
- [ ] Write failing supertest tests for every endpoint above including Review Focus 1, 2, 4, 5, 6 (parallel `Promise.all` of two bookings of 7 on an 8-seat tasting: exactly one 201 and one 409/400; login unset password → 401; `STAFF_PASSWORD` correct → cookie allows bookings list).
- [ ] Run → FAIL. Implement store (references `KB-` + 6 chars from `ABCDEFGHJKLMNPQRSTUVWXYZ23456789`; synchronous check-and-insert), then app (helmet, express.json with small limit, express-session, express-rate-limit 30 logins/15 min, constant-time compare via `crypto.timingSafeEqual` on SHA-256 digests, static `dist/client` + SPA fallback for non-`/api` GETs, JSON 404 for unknown `/api`). `server/index.ts` warns when `STAFF_PASSWORD` is missing.
- [ ] Run tests → PASS. Commit.

### Task 3: Guest UI
**Files:** Create `src/main.tsx`, `src/App.tsx` (routes `/`, `/book/:tastingId`, `/confirmation/:reference`, `/staff`, `*` not found), `src/api.ts` (typed fetch helpers), `src/pages/Home.tsx`, `src/pages/BookingForm.tsx`, `src/pages/Confirmation.tsx`, `src/pages/NotFound.tsx`, `src/components/Layout.tsx`, `src/index.css`, tests alongside (`*.test.tsx`, jsdom, fetch mocked).

**Interfaces — Consumes:** Task 2 HTTP contract, Task 1 shared. **Produces:** `api.listTastings()`, `api.book(id, input)` (throws `FieldErrors` on 400/409), `api.getBooking(ref)`, `api.staff.{session,login,logout,bookings,cancel}`.

- [ ] Write failing tests: Home shows each title, "EUR 25", "12 seats left", links "Book Riesling Evening"…; sold-out tasting shows "Fully booked" and no Book link; form shows empty-field errors beside "Name"/"Email"/"Guests" (via `aria-describedby` + `role="alert"` text) and does not call the API; server field errors are mapped to the right field; success navigates to a page with heading "Booking confirmed", tasting, guests, total, reference; fully booked / unknown tasting form pages show a notice not a form; submit button disabled while submitting (no double submit).
- [ ] Run → FAIL. Implement. Form: react-hook-form with `zodResolver(bookingSchema(seatsLeft))`, `noValidate`, number input for Guests (`min=1 max=8`). Run → PASS.

### Task 4: Staff UI
**Files:** Create `src/pages/Staff.tsx`, `src/pages/Staff.test.tsx`.

- [ ] Failing tests: signed-out shows "Password" and "Sign in"; wrong password shows error beside the field; signed in lists groups per tasting with name, email, guests, reference and "Cancel"; clicking Cancel calls delete and removes row and shows notice; empty tasting shows "No bookings yet"; `<b>x</b>` in a name renders as literal text; "Sign out" returns to the sign-in form; a 401 during listing returns to sign-in.
- [ ] Run → FAIL; implement; run → PASS. Commit.

### Task 5: Design polish, build, verification
- [ ] Tailwind theme (cream/burgundy/gold, serif headings), responsive grid, distinct styles for error, success, fully-booked, focus rings, adequate touch targets; favicon-free but with `<title>` and meta viewport.
- [ ] `npm run build`, then `STAFF_PASSWORD=... PORT=3111 npm start`; exercise the full flow with curl and, if a browser is available, screenshots at 390px and 1280px.
- [ ] Run full `npm test` and `npm run typecheck`; fresh-reviewer pass over the whole project; fix findings.
