# Weingut Kieselbrunnen: tasting booking app, design

## Intent
A family winery wants guests to book wine tastings online without phone calls, and staff to see who is coming. Small, calm, trustworthy: it should feel like the winery's own site, not a generic booking widget.

## Goals
- Guests see the three tastings, how many seats are left, and book in one short form.
- Seats can never be oversold, even with simultaneous requests.
- Staff sign in with a password, see bookings grouped by tasting, and cancel one (seats are freed).
- Polished, coherent visual design; clear error, success and fully booked states; works on a phone.

## Non-goals
Payments, emails, guest accounts, editing bookings, admin editing of tastings, i18n, persistence across restarts, multiple staff users.

## Anti-goals (failure even if it "works")
- Overbooking, or a booking accepted with invalid input.
- Staff data (names, emails) reachable without signing in.
- Errors only shown as a generic banner instead of next to the field.
- Hand-rolled replacements for routing, forms, validation, sessions, security headers.

## Fixed by the brief
Tastings (fixed catalogue, ids are my slugs):

| Tasting | Date and time | Price | Seats |
|---|---|---|---|
| Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

- Start page: title, date and time, price per guest, "<n> seats left". Each tasting has "Book <title>" opening a form with labelled fields "Name", "Email", "Guests" (1 to 8) and button "Book".
- Never more seats than left. Invalid input rejected, error shown next to its field.
- Confirmation: heading "Booking confirmed", tasting, guests, total price, booking reference.
- `/staff`: "Password" field, "Sign in" button; password from env `STAFF_PASSWORD`. Signed in: bookings grouped by tasting (name, email, guests, reference), "Cancel" button per booking; cancelling frees seats.
- React UI; established libraries. Node 22; `npm install`, `npm run build`, `npm start` serves everything on `PORT` (default 3000). Starts empty; in-memory is allowed. English UI.

## Builder's calls (mine, not the user's)
- Stack: TypeScript; Express 5 server; React 19 + Vite + React Router; react-hook-form + zod (one shared schema validates on client and server); Tailwind CSS for styling; helmet, express-session, express-rate-limit; Vitest + Testing Library + supertest for tests.
- Storage: in-memory. Booking is a synchronous check-and-insert, so it cannot oversell within the single Node process.
- Routes: `/` list, `/book/:tastingId` form, `/confirmation/:reference`, `/staff`. API under `/api`.
- Fields: Name required, max 100 chars. Email must be a valid address. Guests is a whole number 1 to 8 and at most the seats left (message says how many are left). Server re-validates everything and returns per-field errors; the form shows them beside the field. Browser-native validation is turned off so our messages show.
- Seats text is literally "<n> seats left" for every n, per the brief ("1 seats left" included); fully booked tastings show a "Fully booked" badge and "0 seats left", no Book link, and the booking page shows a fully booked notice instead of a form.
- Booking reference: `KB-` plus 6 random characters from an unambiguous alphabet. The confirmation page can be reloaded; the public lookup returns only tasting, guests, total, reference (no name or email).
- Cancelling removes the booking (no cancelled history) and shows a notice; no confirm dialog.
- Staff auth: password compared in constant time; session cookie (HttpOnly, SameSite=Lax); login rate-limited generously; if `STAFF_PASSWORD` is unset nobody can sign in (fail closed) and a warning is logged. Staff API returns 401 without session. Sign out button.
- Past tastings are not hidden or blocked (brief does not mention it).
- Price shown as "EUR 25"; total as "EUR 50".
- Visual: warm, wine-cellar palette (cream paper, deep burgundy, muted gold, slate green accents), serif headings, mobile-first single column that becomes a 3-column card grid.
