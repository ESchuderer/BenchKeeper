import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import request from "supertest";
import { createApp } from "./app.ts";

const PASSWORD = "correct horse";
const ok = { name: "Anna Weber", email: "anna@example.com", guests: 2 };

function setup(staffPassword: string | undefined = PASSWORD) {
  return request.agent(createApp({ staffPassword, sessionSecret: "test-secret" }));
}

async function staff() {
  const agent = setup();
  await agent.post("/api/staff/login").send({ password: PASSWORD }).expect(204);
  return agent;
}

describe("tastings", () => {
  it("lists tastings with seats left", async () => {
    const res = await setup().get("/api/tastings").expect(200);
    expect(res.body).toHaveLength(3);
    expect(res.body[0]).toMatchObject({ id: "riesling-evening", title: "Riesling Evening", seatsLeft: 12, soldOut: false, priceEur: 25 });
  });
});

describe("booking", () => {
  it("creates a booking and returns the confirmation data", async () => {
    const agent = setup();
    const res = await agent.post("/api/tastings/riesling-evening/bookings").send(ok).expect(201);
    expect(res.body).toMatchObject({ tastingId: "riesling-evening", tastingTitle: "Riesling Evening", guests: 2, totalEur: 50 });
    expect(res.body.reference).toMatch(/^KB-/);
    const list = await agent.get("/api/tastings").expect(200);
    expect(list.body[0].seatsLeft).toBe(10);
  });

  it("public lookup shows the booking without name or email", async () => {
    const agent = setup();
    const { body } = await agent.post("/api/tastings/winter-tasting/bookings").send(ok);
    const res = await agent.get(`/api/bookings/${body.reference}`).expect(200);
    expect(res.body).toMatchObject({ reference: body.reference, tastingTitle: "Winter Tasting", guests: 2, totalEur: 56 });
    expect(JSON.stringify(res.body)).not.toContain("anna@example.com");
    expect(JSON.stringify(res.body)).not.toContain("Anna");
  });

  it("404s for unknown reference and unknown tasting", async () => {
    const agent = setup();
    await agent.get("/api/bookings/KB-NOPE00").expect(404);
    await agent.post("/api/tastings/nope/bookings").send(ok).expect(404);
    await agent.post("/api/tastings/__proto__/bookings").send(ok).expect(404);
  });

  it.each([0, 9, 2.5, "", "abc", -1, null])("rejects guests=%j with a guests error", async (guests) => {
    const res = await setup().post("/api/tastings/riesling-evening/bookings").send({ ...ok, guests }).expect(400);
    expect(res.body.errors.guests).toBeTruthy();
  });

  it("rejects blank name and bad email with per-field errors", async () => {
    const res = await setup().post("/api/tastings/riesling-evening/bookings").send({ name: "   ", email: "x", guests: 1 }).expect(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(["email", "name"]);
  });

  it("rejects non-object and malformed JSON bodies cleanly", async () => {
    const agent = setup();
    await agent.post("/api/tastings/riesling-evening/bookings").set("Content-Type", "application/json").send("[1,2]").expect(400);
    await agent.post("/api/tastings/riesling-evening/bookings").set("Content-Type", "application/json").send("{oops").expect(400);
    await agent.post("/api/tastings/riesling-evening/bookings").expect(400);
  });

  it("never takes more seats than are left", async () => {
    const agent = setup();
    await agent.post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...ok, guests: 6 }).expect(201);
    const res = await agent.post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...ok, guests: 3 }).expect(400);
    expect(res.body.errors.guests).toContain("2");
    const list = await agent.get("/api/tastings");
    expect(list.body[1].seatsLeft).toBe(2);
  });

  it("lets only one of two simultaneous bookings for the last seats through", async () => {
    const agent = setup();
    await agent.post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...ok, guests: 1 }).expect(201);
    const results = await Promise.all([
      agent.post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...ok, guests: 7 }),
      agent.post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...ok, guests: 7 }),
    ]);
    expect(results.map((r) => r.status).sort()).toEqual([201, 400]);
    const list = await agent.get("/api/tastings");
    expect(list.body[1]).toMatchObject({ seatsLeft: 0, soldOut: true });
  });

  it("refuses bookings for a fully booked tasting", async () => {
    const agent = setup();
    await agent.post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...ok, guests: 8 }).expect(201);
    const res = await agent.post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...ok, guests: 1 }).expect(400);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });
});

describe("staff", () => {
  it("rejects bookings list and cancel without a session", async () => {
    const agent = setup();
    await agent.get("/api/staff/bookings").expect(401);
    await agent.delete("/api/staff/bookings/KB-ABCDEF").expect(401);
  });

  it("rejects a wrong password and a missing password", async () => {
    const agent = setup();
    await agent.post("/api/staff/login").send({ password: "wrong" }).expect(401);
    await agent.post("/api/staff/login").send({}).expect(401);
    await agent.post("/api/staff/login").send({ password: ["correct horse"] }).expect(401);
    await agent.get("/api/staff/bookings").expect(401);
  });

  it("nobody can sign in when STAFF_PASSWORD is not set", async () => {
    const agent = setup(undefined);
    await agent.post("/api/staff/login").send({ password: "" }).expect(401);
    await agent.post("/api/staff/login").send({ password: "undefined" }).expect(401);
    await agent.get("/api/staff/bookings").expect(401);
  });

  it("logout ends the session", async () => {
    const agent = await staff();
    await agent.get("/api/staff/bookings").expect(200);
    await agent.post("/api/staff/logout").expect(204);
    await agent.get("/api/staff/bookings").expect(401);
  });

  it("lists bookings grouped by tasting", async () => {
    const agent = await staff();
    const b = await agent.post("/api/tastings/winter-tasting/bookings").send(ok).expect(201);
    const res = await agent.get("/api/staff/bookings").expect(200);
    expect(res.body).toHaveLength(3);
    const winter = res.body.find((g: any) => g.tasting.id === "winter-tasting");
    expect(winter.seatsLeft).toBe(8);
    expect(winter.bookings).toEqual([expect.objectContaining({ reference: b.body.reference, name: "Anna Weber", email: "anna@example.com", guests: 2 })]);
    expect(res.body.find((g: any) => g.tasting.id === "riesling-evening").bookings).toEqual([]);
  });

  it("cancelling frees seats; unknown reference is 404", async () => {
    const agent = await staff();
    const b = await agent.post("/api/tastings/riesling-evening/bookings").send({ ...ok, guests: 4 }).expect(201);
    await agent.delete(`/api/staff/bookings/${b.body.reference}`).expect(204);
    expect((await agent.get("/api/tastings")).body[0].seatsLeft).toBe(12);
    await agent.delete(`/api/staff/bookings/${b.body.reference}`).expect(404);
    await agent.get(`/api/bookings/${b.body.reference}`).expect(404);
  });
});

describe("misc", () => {
  it("unknown api routes are JSON 404s", async () => {
    const res = await setup().get("/api/nothing").expect(404);
    expect(res.body.error).toBeTruthy();
  });
  it("sets security headers", async () => {
    const res = await setup().get("/api/tastings");
    expect(res.headers["x-content-type-options"]).toBe("nosniff");
  });
});

describe("serving the built client", () => {
  const dir = mkdtempSync(path.join(tmpdir(), "kb-client-"));
  writeFileSync(path.join(dir, "index.html"), '<div id="root"></div>');
  const agent = () => request(createApp({ staffPassword: PASSWORD, clientDir: dir }));

  it("serves the app for client-side routes", async () => {
    for (const route of ["/", "/staff", "/book/riesling-evening", "/confirmation/KB-ABC234"]) {
      const res = await agent().get(route).expect(200);
      expect(res.text).toContain('id="root"');
    }
  });
  it("returns 404 for missing files instead of the app", async () => {
    await agent().get("/assets/missing.js").expect(404);
    await agent().get("/favicon.ico").expect(404);
  });
});

describe("headers for a plain-HTTP deployment", () => {
  it("does not force browsers to upgrade to https or pin https", async () => {
    const res = await setup().get("/api/tastings");
    expect(res.headers["content-security-policy"]).toBeDefined();
    expect(res.headers["content-security-policy"]).not.toContain("upgrade-insecure-requests");
    expect(res.headers["strict-transport-security"]).toBeUndefined();
  });
});
