import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { existsSync } from "node:fs";
import path from "node:path";
import express, { type ErrorRequestHandler, type Request } from "express";
import helmet from "helmet";
import cookieSession from "cookie-session";
import { rateLimit } from "express-rate-limit";
import { bookingSchema, fieldErrors } from "../shared/booking.ts";
import { findTasting } from "../shared/tastings.ts";
import { createStore } from "./store.ts";

export type AppOptions = { staffPassword?: string; sessionSecret?: string; clientDir?: string };

const digest = (s: string) => createHash("sha256").update(s).digest();

function passwordMatches(expected: string | undefined, given: unknown): boolean {
  if (!expected || typeof given !== "string") return false;
  return timingSafeEqual(digest(expected), digest(given));
}

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);

export function createApp(options: AppOptions = {}) {
  const store = createStore();
  const app = express();
  const clientDir = options.clientDir ?? path.resolve(import.meta.dirname, "../dist/client");

  app.disable("x-powered-by");
  // This server speaks plain HTTP (TLS, if any, is a proxy's job), so do not tell browsers to upgrade or pin https.
  app.use(helmet({ hsts: false, contentSecurityPolicy: { directives: { ...helmet.contentSecurityPolicy.getDefaultDirectives(), "upgrade-insecure-requests": null } } }));
  app.use(express.json({ limit: "10kb" }));
  app.use(
    cookieSession({
      name: "kb_staff",
      keys: [options.sessionSecret ?? randomBytes(32).toString("hex")],
      maxAge: 8 * 60 * 60 * 1000,
      httpOnly: true,
      sameSite: "lax",
    }),
  );

  const api = express.Router();
  const isStaff = (req: Request) => req.session?.staff === true;

  api.get("/tastings", (_req, res) => {
    res.json(
      store.tastings.map((t) => {
        const seatsLeft = store.seatsLeft(t.id);
        return { ...t, seatsLeft, soldOut: seatsLeft <= 0 };
      }),
    );
  });

  api.post("/tastings/:id/bookings", (req, res) => {
    const tasting = findTasting(req.params.id);
    if (!tasting) return res.status(404).json({ error: "Tasting not found." });
    const parsed = bookingSchema(store.seatsLeft(tasting.id)).safeParse(isRecord(req.body) ? req.body : {});
    if (!parsed.success) {
      const errors = fieldErrors(parsed.error);
      return res.status(400).json({ errors: Object.keys(errors).length ? errors : { name: "Please check your details." } });
    }
    const result = store.book(tasting.id, parsed.data);
    if (!result.ok) {
      return res.status(400).json({ errors: { guests: "Sorry, those seats were just taken. Please reload and try again." } });
    }
    const { booking } = result;
    res.status(201).json({
      reference: booking.reference,
      tastingId: tasting.id,
      tastingTitle: tasting.title,
      startsAt: tasting.startsAt,
      guests: booking.guests,
      totalEur: booking.guests * tasting.priceEur,
    });
  });

  api.get("/bookings/:reference", (req, res) => {
    const booking = store.find(req.params.reference.toUpperCase());
    const tasting = booking && findTasting(booking.tastingId);
    if (!booking || !tasting) return res.status(404).json({ error: "Booking not found." });
    res.json({
      reference: booking.reference,
      tastingId: tasting.id,
      tastingTitle: tasting.title,
      startsAt: tasting.startsAt,
      guests: booking.guests,
      totalEur: booking.guests * tasting.priceEur,
    });
  });

  const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });

  api.post("/staff/login", loginLimiter, (req, res) => {
    const password = isRecord(req.body) ? req.body.password : undefined;
    if (!passwordMatches(options.staffPassword, password)) {
      return res.status(401).json({ error: "That password is not correct." });
    }
    req.session = { staff: true };
    res.status(204).end();
  });

  api.post("/staff/logout", (req, res) => {
    req.session = null;
    res.status(204).end();
  });

  api.use("/staff", (req, res, next) => {
    if (!isStaff(req)) return res.status(401).json({ error: "Please sign in." });
    next();
  });

  api.get("/staff/bookings", (_req, res) => {
    res.json(store.listByTasting());
  });

  api.delete("/staff/bookings/:reference", (req, res) => {
    if (!store.cancel(req.params.reference.toUpperCase())) return res.status(404).json({ error: "Booking not found." });
    res.status(204).end();
  });

  api.use((_req, res) => {
    res.status(404).json({ error: "Not found." });
  });

  app.use("/api", api);

  if (existsSync(path.join(clientDir, "index.html"))) {
    app.use(express.static(clientDir, { index: false }));
    // Client-side routes get the app; anything that looks like a file (has an extension) is a real 404.
    app.get(/.*/, (req, res, next) => {
      if (path.extname(req.path)) return next();
      res.sendFile(path.join(clientDir, "index.html"));
    });
  }

  const onError: ErrorRequestHandler = (err, _req, res, _next) => {
    const status = typeof err?.status === "number" && err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 500 ? "Something went wrong." : "Invalid request." });
  };
  app.use(onError);

  return app;
}
