import { createApp } from "./app.ts";

const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) {
  console.warn("STAFF_PASSWORD is not set: nobody will be able to sign in to /staff.");
}

const port = Number(process.env.PORT) || 3000;
createApp({ staffPassword }).listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings listening on http://localhost:${port}`);
});
