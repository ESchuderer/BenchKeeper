declare global {
  interface CookieSessionObject {
    staff?: boolean;
  }
}
export {};
