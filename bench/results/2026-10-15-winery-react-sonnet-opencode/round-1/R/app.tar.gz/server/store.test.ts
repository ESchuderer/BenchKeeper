import { createStore } from "./store.ts";

const guest = { name: "Anna", email: "anna@example.com" };

describe("store", () => {
  it("starts empty with full capacity", () => {
    const s = createStore();
    expect(s.seatsLeft("riesling-evening")).toBe(12);
    expect(s.listByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });

  it("books seats and reduces seats left", () => {
    const s = createStore();
    const r = s.book("riesling-evening", { ...guest, guests: 5 });
    expect(r.ok && r.booking.reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
    expect(s.seatsLeft("riesling-evening")).toBe(7);
  });

  it("allows taking exactly the last seats", () => {
    const s = createStore();
    expect(s.book("red-wine-cellar-tour", { ...guest, guests: 8 }).ok).toBe(true);
    expect(s.seatsLeft("red-wine-cellar-tour")).toBe(0);
  });

  it("refuses to overbook and leaves state unchanged", () => {
    const s = createStore();
    s.book("red-wine-cellar-tour", { ...guest, guests: 7 });
    const r = s.book("red-wine-cellar-tour", { ...guest, guests: 2 });
    expect(r).toEqual({ ok: false, reason: "sold-out", seatsLeft: 1 });
    expect(s.seatsLeft("red-wine-cellar-tour")).toBe(1);
  });

  it("reports unknown tastings", () => {
    expect(createStore().book("nope", { ...guest, guests: 1 })).toEqual({ ok: false, reason: "unknown-tasting" });
  });

  it("cancelling frees the seats and forgets the booking", () => {
    const s = createStore();
    const r = s.book("winter-tasting", { ...guest, guests: 4 });
    if (!r.ok) throw new Error("expected booking");
    expect(s.cancel(r.booking.reference)).toBe(true);
    expect(s.seatsLeft("winter-tasting")).toBe(10);
    expect(s.find(r.booking.reference)).toBeUndefined();
    expect(s.cancel(r.booking.reference)).toBe(false);
  });

  it("issues unique references", () => {
    const s = createStore();
    const refs = new Set<string>();
    for (let i = 0; i < 8; i++) {
      const r = s.book("riesling-evening", { ...guest, guests: 1 });
      if (r.ok) refs.add(r.booking.reference);
    }
    expect(refs.size).toBe(8);
  });
});
