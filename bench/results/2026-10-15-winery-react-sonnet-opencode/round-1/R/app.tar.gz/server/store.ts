import { randomInt } from "node:crypto";
import { TASTINGS, type Tasting } from "../shared/tastings.ts";

export type Booking = {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
};

export type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: "unknown-tasting" }
  | { ok: false; reason: "sold-out"; seatsLeft: number };

export type TastingGroup = { tasting: Tasting; seatsLeft: number; bookings: Booking[] };

// No 0/O/1/I/L so references can be read out over the phone.
const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

function newReference(taken: (ref: string) => boolean): string {
  for (;;) {
    let ref = "KB-";
    for (let i = 0; i < 6; i++) ref += ALPHABET[randomInt(ALPHABET.length)];
    if (!taken(ref)) return ref;
  }
}

/**
 * In-memory bookings. `book` checks seats and inserts in one synchronous step,
 * so two requests can never both take the last seats.
 */
export function createStore(tastings: readonly Tasting[] = TASTINGS) {
  const bookings = new Map<string, Booking>();

  const find = (reference: string) => bookings.get(reference);
  const tastingById = (id: string) => tastings.find((t) => t.id === id);

  function seatsLeft(tastingId: string): number {
    const tasting = tastingById(tastingId);
    if (!tasting) return 0;
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === tastingId) taken += b.guests;
    return tasting.capacity - taken;
  }

  function book(tastingId: string, input: { name: string; email: string; guests: number }): BookResult {
    if (!tastingById(tastingId)) return { ok: false, reason: "unknown-tasting" };
    const left = seatsLeft(tastingId);
    if (input.guests > left) return { ok: false, reason: "sold-out", seatsLeft: left };
    const booking: Booking = {
      reference: newReference((r) => bookings.has(r)),
      tastingId,
      name: input.name,
      email: input.email,
      guests: input.guests,
      createdAt: new Date().toISOString(),
    };
    bookings.set(booking.reference, booking);
    return { ok: true, booking };
  }

  const cancel = (reference: string) => bookings.delete(reference);

  function listByTasting(): TastingGroup[] {
    return tastings.map((tasting) => ({
      tasting,
      seatsLeft: seatsLeft(tasting.id),
      bookings: [...bookings.values()].filter((b) => b.tastingId === tasting.id),
    }));
  }

  return { find, seatsLeft, book, cancel, listByTasting, tastings };
}

export type Store = ReturnType<typeof createStore>;
