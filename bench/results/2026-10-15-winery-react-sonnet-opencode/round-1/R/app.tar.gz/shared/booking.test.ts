import { bookingSchema } from "./booking.ts";
import { TASTINGS, findTasting, formatEur, formatWhen } from "./tastings.ts";

const valid = { name: "Anna Weber", email: "anna@example.com", guests: 2 };

function firstError(result: ReturnType<ReturnType<typeof bookingSchema>["safeParse"]>) {
  if (result.success) return {};
  const out: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const key = String(issue.path[0]);
    out[key] ??= issue.message;
  }
  return out;
}

describe("catalogue", () => {
  it("lists the three tastings from the brief", () => {
    expect(TASTINGS.map((t) => [t.title, t.startsAt, t.priceEur, t.capacity])).toEqual([
      ["Riesling Evening", "2026-11-06T18:00", 25, 12],
      ["Red Wine Cellar Tour", "2026-11-14T15:00", 32, 8],
      ["Winter Tasting", "2026-12-05T17:00", 28, 10],
    ]);
  });
  it("finds by id and returns undefined for unknown ids", () => {
    expect(findTasting("riesling-evening")?.title).toBe("Riesling Evening");
    expect(findTasting("nope")).toBeUndefined();
    expect(findTasting("__proto__")).toBeUndefined();
  });
  it("formats money and dates", () => {
    expect(formatEur(25)).toBe("EUR 25");
    expect(formatWhen("2026-11-06T18:00")).toBe("Fri 6 Nov 2026, 18:00");
  });
});

describe("bookingSchema", () => {
  it("accepts valid input and trims", () => {
    const r = bookingSchema(12).safeParse({ name: "  Anna Weber ", email: " anna@example.com ", guests: "2" });
    expect(r.success && r.data).toEqual(valid);
  });
  it.each([0, 9, 2.5, "", "abc", -1, null, undefined])("rejects guests=%s", (guests) => {
    const r = bookingSchema(12).safeParse({ ...valid, guests });
    expect(r.success).toBe(false);
    expect(firstError(r).guests).toBeTruthy();
  });
  it("rejects more guests than seats left and says how many are left", () => {
    const r = bookingSchema(2).safeParse({ ...valid, guests: 3 });
    expect(firstError(r).guests).toContain("2");
  });
  it("rejects any booking when nothing is left", () => {
    expect(bookingSchema(0).safeParse(valid).success).toBe(false);
  });
  it("rejects blank name and bad email, each on its own field", () => {
    expect(firstError(bookingSchema(12).safeParse({ ...valid, name: "   " })).name).toBeTruthy();
    expect(firstError(bookingSchema(12).safeParse({ ...valid, email: "nope" })).email).toBeTruthy();
  });
  it("rejects over-long names and non-string fields", () => {
    expect(bookingSchema(12).safeParse({ ...valid, name: "x".repeat(101) }).success).toBe(false);
    expect(bookingSchema(12).safeParse({ ...valid, name: { a: 1 }, email: 5 }).success).toBe(false);
  });
});
