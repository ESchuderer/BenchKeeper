import { z } from "zod";

export const MAX_GUESTS = 8;

export type FieldErrors = Partial<Record<"name" | "email" | "guests", string>>;

/** Validates a booking request. `seatsLeft` is how many seats the tasting still has. */
export function bookingSchema(seatsLeft: number) {
  return z.object({
    name: z
      .string({ error: "Please enter your name." })
      .trim()
      .min(1, "Please enter your name.")
      .max(100, "Please use at most 100 characters."),
    email: z
      .string({ error: "Please enter your email address." })
      .trim()
      .min(1, "Please enter your email address.")
      .max(254, "That email address is too long.")
      .pipe(z.email("Please enter a valid email address, like name@example.com.")),
    guests: z.preprocess(
      (v) => (typeof v === "string" && v.trim() !== "" ? Number(v) : v),
      z
        .number({ error: `Please enter the number of guests, from 1 to ${MAX_GUESTS}.` })
        .int(`Please enter a whole number of guests, from 1 to ${MAX_GUESTS}.`)
        .min(1, "At least 1 guest is needed.")
        .max(MAX_GUESTS, `You can book at most ${MAX_GUESTS} guests at a time.`)
        .refine((n) => n <= seatsLeft, {
          error:
            seatsLeft <= 0
              ? "This tasting is fully booked."
              : `Only ${seatsLeft} ${seatsLeft === 1 ? "seat is" : "seats are"} left, please choose ${seatsLeft} or fewer.`,
        }),
    ),
  });
}

export type BookingInput = z.output<ReturnType<typeof bookingSchema>>;

/** First message per field from a failed parse. */
export function fieldErrors(error: z.ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const key = issue.path[0];
    if ((key === "name" || key === "email" || key === "guests") && !out[key]) out[key] = issue.message;
  }
  return out;
}
