export type Tasting = {
  id: string;
  title: string;
  /** Local wall-clock time at the winery, "YYYY-MM-DDTHH:mm". */
  startsAt: string;
  priceEur: number;
  capacity: number;
};

export const TASTINGS: readonly Tasting[] = [
  { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00", priceEur: 25, capacity: 12 },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00", priceEur: 32, capacity: 8 },
  { id: "winter-tasting", title: "Winter Tasting", startsAt: "2026-12-05T17:00", priceEur: 28, capacity: 10 },
];

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((t) => t.id === id);
}

export function formatEur(amount: number): string {
  return `EUR ${amount}`;
}

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** "2026-11-06T18:00" -> "Fri 6 Nov 2026, 18:00" (no time zone maths: it is the winery's wall-clock time). */
export function formatWhen(startsAt: string): string {
  const [date = "", time = ""] = startsAt.split("T");
  const [y = 0, m = 1, d = 1] = date.split("-").map(Number);
  const weekday = WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
  return `${weekday} ${d} ${MONTHS[m - 1]} ${y}, ${time}`;
}
