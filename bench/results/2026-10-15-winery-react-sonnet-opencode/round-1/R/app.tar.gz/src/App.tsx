import { Route, Routes } from "react-router";
import { Layout } from "./components/Layout.tsx";
import { Home } from "./pages/Home.tsx";
import { BookingForm } from "./pages/BookingForm.tsx";
import { ConfirmationPage } from "./pages/ConfirmationPage.tsx";
import { Staff } from "./pages/Staff.tsx";
import { NotFound } from "./pages/NotFound.tsx";

export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="book/:tastingId" element={<BookingForm />} />
        <Route path="confirmation/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<Staff />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
