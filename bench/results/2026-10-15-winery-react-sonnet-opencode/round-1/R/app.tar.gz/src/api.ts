import type { FieldErrors } from "../shared/booking.ts";
import type { Tasting } from "../shared/tastings.ts";

export type TastingWithSeats = Tasting & { seatsLeft: number; soldOut: boolean };

export type Confirmation = {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  totalEur: number;
};

export type StaffBooking = { reference: string; name: string; email: string; guests: number; createdAt: string };
export type StaffGroup = { tasting: Tasting; seatsLeft: number; bookings: StaffBooking[] };

export class ApiError extends Error {
  status: number;
  fieldErrors?: FieldErrors;
  constructor(status: number, message: string, fieldErrors?: FieldErrors) {
    super(message);
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(path, {
    method,
    headers: body === undefined ? undefined : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, data?.error ?? "Request failed", data?.errors);
  return data as T;
}

export const api = {
  listTastings: () => request<TastingWithSeats[]>("GET", "/api/tastings"),
  book: (tastingId: string, input: { name: string; email: string; guests: unknown }) =>
    request<Confirmation>("POST", `/api/tastings/${encodeURIComponent(tastingId)}/bookings`, input),
  getBooking: (reference: string) => request<Confirmation>("GET", `/api/bookings/${encodeURIComponent(reference)}`),
  staff: {
    login: (password: string) => request<void>("POST", "/api/staff/login", { password }),
    logout: () => request<void>("POST", "/api/staff/logout"),
    bookings: () => request<StaffGroup[]>("GET", "/api/staff/bookings"),
    cancel: (reference: string) => request<void>("DELETE", `/api/staff/bookings/${encodeURIComponent(reference)}`),
  },
};
