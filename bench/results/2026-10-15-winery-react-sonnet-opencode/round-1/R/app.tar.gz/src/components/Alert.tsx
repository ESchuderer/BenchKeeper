import type { ReactNode } from "react";

const styles = {
  error: "border-red-300 bg-red-50 text-red-900",
  success: "border-moss/40 bg-moss/10 text-moss-dark",
  info: "border-gold/50 bg-gold/10 text-stone-800",
} as const;

export function Alert({ tone, children, role }: { tone: keyof typeof styles; children: ReactNode; role?: "alert" | "status" }) {
  return (
    <div role={role ?? (tone === "error" ? "alert" : "status")} className={`rounded-md border px-4 py-3 text-sm ${styles[tone]}`}>
      {children}
    </div>
  );
}
