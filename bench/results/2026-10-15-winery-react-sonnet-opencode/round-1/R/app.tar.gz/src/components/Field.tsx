import type { ComponentProps } from "react";

type Props = ComponentProps<"input"> & { id: string; label: string; error?: string; hint?: string };

/** A labelled input with its error message directly underneath, linked for screen readers. */
export function Field({ id, label, error, hint, className, ...input }: Props) {
  const hintId = `${id}-hint`;
  const errorId = `${id}-error`;
  const describedBy = [hint ? hintId : null, error ? errorId : null].filter(Boolean).join(" ") || undefined;
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-semibold text-stone-800">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        className={`block w-full rounded-md border bg-white px-3 py-3 text-base text-stone-900 shadow-sm focus:outline-2 focus:outline-offset-1 focus:outline-burgundy ${
          error ? "border-red-600 bg-red-50/40" : "border-stone-400"
        } ${className ?? ""}`}
        {...input}
      />
      {hint ? (
        <p id={hintId} className="mt-1 text-sm text-stone-600">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={errorId} role="alert" className="mt-1 flex gap-1 text-sm font-medium text-red-700">
          <span aria-hidden="true">&#9888;</span>
          <span>{error}</span>
        </p>
      ) : null}
    </div>
  );
}
