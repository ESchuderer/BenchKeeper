import { Link, Outlet } from "react-router";

export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b border-gold/40 bg-burgundy text-cream">
        <div className="mx-auto flex max-w-5xl flex-col gap-1 px-5 py-6 sm:flex-row sm:items-end sm:justify-between">
          <Link to="/" className="font-serif text-2xl font-semibold tracking-wide hover:text-gold-soft sm:text-3xl">
            Weingut Kieselbrunnen
          </Link>
          <p className="text-sm tracking-widest text-gold-soft uppercase">Family winery &middot; Wine tastings</p>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-8 sm:py-12">
        <Outlet />
      </main>
      <footer className="border-t border-stone-300 bg-parchment">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-5 text-sm text-stone-600">
          <span>Weingut Kieselbrunnen &middot; Family winery</span>
          <Link to="/staff" className="underline decoration-stone-400 underline-offset-4 hover:text-burgundy">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
