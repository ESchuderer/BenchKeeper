// @vitest-environment jsdom
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { mockApi, renderAt, tastings } from "./test-utils.tsx";

afterEach(() => vi.unstubAllGlobals());

describe("start page", () => {
  it("lists every tasting with date, price and seats left, and a Book link", async () => {
    mockApi({ "GET /api/tastings": { body: tastings } });
    renderAt("/");
    expect(await screen.findByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(screen.getByText("Fri 6 Nov 2026, 18:00")).toBeInTheDocument();
    expect(screen.getByText("EUR 25")).toBeInTheDocument();
    expect(screen.getByText("12 seats left")).toBeInTheDocument();
    expect(screen.getByText("2 seats left")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Book Riesling Evening" })).toHaveAttribute("href", "/book/riesling-evening");
    expect(screen.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toBeInTheDocument();
  });

  it("marks a fully booked tasting and offers no way to book it", async () => {
    mockApi({ "GET /api/tastings": { body: tastings } });
    renderAt("/");
    await screen.findByRole("heading", { name: "Winter Tasting" });
    expect(screen.getByText("Fully booked")).toBeInTheDocument();
    expect(screen.getByText("0 seats left")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Winter Tasting" })).not.toBeInTheDocument();
  });

  it("shows an error with a retry when loading fails", async () => {
    const api = mockApi({ "GET /api/tastings": { status: 500, body: { error: "x" } } });
    renderAt("/");
    expect(await screen.findByRole("alert")).toHaveTextContent(/could not load/i);
    await userEvent.click(screen.getByRole("button", { name: "Try again" }));
    await waitFor(() => expect(api.calls.length).toBe(2));
  });
});

describe("booking form", () => {
  const table = { "GET /api/tastings": { body: tastings } };

  it("shows the tasting and the labelled fields", async () => {
    mockApi(table);
    renderAt("/book/riesling-evening");
    expect(await screen.findByRole("heading", { name: /Riesling Evening/ })).toBeInTheDocument();
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeInTheDocument();
  });

  it("shows an error next to each invalid field and sends nothing", async () => {
    const api = mockApi(table);
    renderAt("/book/riesling-evening");
    await screen.findByLabelText("Name");
    await userEvent.type(screen.getByLabelText("Email"), "nope");
    await userEvent.clear(screen.getByLabelText("Guests"));
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByLabelText("Name")).toHaveAccessibleDescription(/enter your name/i);
    expect(screen.getByLabelText("Name")).toBeInvalid();
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription(/valid email/i);
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription(/number of guests/i);
    expect(api.calls.some((c) => c.key.startsWith("POST"))).toBe(false);
  });

  it("rejects 9 guests", async () => {
    mockApi(table);
    renderAt("/book/riesling-evening");
    await userEvent.type(await screen.findByLabelText("Name"), "Anna");
    await userEvent.type(screen.getByLabelText("Email"), "anna@example.com");
    await userEvent.clear(screen.getByLabelText("Guests"));
    await userEvent.type(screen.getByLabelText("Guests"), "9");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByLabelText("Guests")).toHaveAccessibleDescription(/at most 8/i);
  });

  it("does not allow more guests than seats left", async () => {
    mockApi(table);
    renderAt("/book/red-wine-cellar-tour");
    await userEvent.type(await screen.findByLabelText("Name"), "Anna");
    await userEvent.type(screen.getByLabelText("Email"), "anna@example.com");
    await userEvent.clear(screen.getByLabelText("Guests"));
    await userEvent.type(screen.getByLabelText("Guests"), "3");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByLabelText("Guests")).toHaveAccessibleDescription(/only 2 seats/i);
  });

  it("maps server field errors onto the right field", async () => {
    mockApi({ ...table, "POST /api/tastings/riesling-evening/bookings": { status: 400, body: { errors: { email: "Server says no." } } } });
    renderAt("/book/riesling-evening");
    await userEvent.type(await screen.findByLabelText("Name"), "Anna");
    await userEvent.type(screen.getByLabelText("Email"), "anna@example.com");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByLabelText("Email")).toHaveAccessibleDescription("Server says no.");
    expect(screen.getByLabelText("Name")).not.toHaveAccessibleDescription(/./);
  });

  it("books, then confirms with tasting, guests, total and reference", async () => {
    const api = mockApi({
      ...table,
      "POST /api/tastings/riesling-evening/bookings": {
        status: 201,
        body: { reference: "KB-ABC234", tastingId: "riesling-evening", tastingTitle: "Riesling Evening", startsAt: "2026-11-06T18:00", guests: 3, totalEur: 75 },
      },
      "GET /api/bookings/KB-ABC234": {
        body: { reference: "KB-ABC234", tastingId: "riesling-evening", tastingTitle: "Riesling Evening", startsAt: "2026-11-06T18:00", guests: 3, totalEur: 75 },
      },
    });
    renderAt("/book/riesling-evening");
    await userEvent.type(await screen.findByLabelText("Name"), "  Anna Weber ");
    await userEvent.type(screen.getByLabelText("Email"), "anna@example.com");
    await userEvent.clear(screen.getByLabelText("Guests"));
    await userEvent.type(screen.getByLabelText("Guests"), "3");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    const main = screen.getByRole("main");
    expect(within(main).getByText("Riesling Evening")).toBeInTheDocument();
    expect(within(main).getByText("3")).toBeInTheDocument();
    expect(within(main).getByText("EUR 75")).toBeInTheDocument();
    expect(within(main).getByText("KB-ABC234")).toBeInTheDocument();
    expect(api.calls.find((c) => c.key.startsWith("POST"))?.body).toMatchObject({ name: "Anna Weber", email: "anna@example.com", guests: 3 });
  });

  it("disables the button while sending so a double click books once", async () => {
    let release!: () => void;
    const gate = new Promise<void>((r) => (release = r));
    let posts = 0;
    const real = mockApi(table);
    const inner = real.fn.getMockImplementation()!;
    real.fn.mockImplementation(async (input, init) => {
      if (init?.method === "POST") {
        posts++;
        await gate;
        return new Response(JSON.stringify({ errors: { name: "stop" } }), { status: 400, headers: { "Content-Type": "application/json" } });
      }
      return inner(input, init);
    });
    renderAt("/book/riesling-evening");
    await userEvent.type(await screen.findByLabelText("Name"), "Anna");
    await userEvent.type(screen.getByLabelText("Email"), "anna@example.com");
    const button = screen.getByRole("button", { name: "Book" });
    await userEvent.dblClick(button);
    await waitFor(() => expect(screen.getByRole("button", { name: /Booking/ })).toBeDisabled());
    release();
    await screen.findByText("stop");
    expect(posts).toBe(1);
  });

  it("shows a fully booked notice instead of a form", async () => {
    mockApi(table);
    renderAt("/book/winter-tasting");
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: /all tastings/i })).toHaveAttribute("href", "/");
  });

  it("shows not found for an unknown tasting", async () => {
    mockApi(table);
    renderAt("/book/nope");
    expect(await screen.findByRole("heading", { name: /not found/i })).toBeInTheDocument();
  });
});

describe("confirmation page", () => {
  it("shows not found for an unknown reference", async () => {
    mockApi({ "GET /api/bookings/KB-NOPE00": { status: 404, body: { error: "x" } } });
    renderAt("/confirmation/KB-NOPE00");
    expect(await screen.findByRole("heading", { name: /not found/i })).toBeInTheDocument();
  });
});

describe("unknown pages", () => {
  it("shows a friendly not found page", () => {
    mockApi({});
    renderAt("/nowhere");
    expect(screen.getByRole("heading", { name: /not found/i })).toBeInTheDocument();
  });
});

describe("review fixes", () => {
  const confirmed = { reference: "KB-LAST22", tastingId: "red-wine-cellar-tour", tastingTitle: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00", guests: 2, totalEur: 64 };

  it("never shows 'fully booked' to the guest who just took the last seats", async () => {
    let booked = false;
    mockApi({
      "GET /api/tastings": () => ({
        body: tastings.map((t) => (t.id === "red-wine-cellar-tour" && booked ? { ...t, seatsLeft: 0, soldOut: true } : t)),
        delayMs: booked ? 30 : 0,
      }),
      "POST /api/tastings/red-wine-cellar-tour/bookings": () => {
        booked = true;
        return { status: 201, body: confirmed };
      },
      "GET /api/bookings/KB-LAST22": { body: confirmed },
    });
    let sawFullyBooked = false;
    const observer = new MutationObserver(() => {
      if (/fully booked/i.test(document.body.textContent ?? "")) sawFullyBooked = true;
    });
    renderAt("/book/red-wine-cellar-tour");
    await userEvent.type(await screen.findByLabelText("Name"), "Anna");
    await userEvent.type(screen.getByLabelText("Email"), "anna@example.com");
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    await new Promise((r) => setTimeout(r, 50));
    observer.disconnect();
    expect(sawFullyBooked).toBe(false);
  });

  it("starts Guests at 2, or at the one seat that is left", async () => {
    mockApi({ "GET /api/tastings": { body: [tastings[0]!, { ...tastings[1]!, seatsLeft: 1 }] } });
    const first = renderAt("/book/riesling-evening");
    expect(await screen.findByLabelText("Guests")).toHaveValue(2);
    first.unmount();
    renderAt("/book/red-wine-cellar-tour");
    expect(await screen.findByLabelText("Guests")).toHaveValue(1);
  });

  it("shows fresh seat counts, not cached ones, when coming back from the staff page", async () => {
    let cancelled = false;
    mockApi({
      "GET /api/tastings": () => ({ body: [{ ...tastings[0]!, seatsLeft: cancelled ? 12 : 4 }], delayMs: cancelled ? 100 : 0 }),
      "GET /api/staff/bookings": () => ({
        body: [{ tasting: tastings[0], seatsLeft: 4, bookings: cancelled ? [] : [{ reference: "KB-AAAAAA", name: "Anna", email: "a@b.de", guests: 8, createdAt: "x" }] }],
      }),
      "DELETE /api/staff/bookings/KB-AAAAAA": () => {
        cancelled = true;
        return { status: 204 };
      },
    });
    renderAt("/");
    expect(await screen.findByText("4 seats left")).toBeInTheDocument();
    await userEvent.click(screen.getByRole("link", { name: "Staff" }));
    await userEvent.click(await screen.findByRole("button", { name: "Cancel" }));
    await screen.findByText(/is cancelled/);
    await userEvent.click(screen.getByRole("link", { name: "Weingut Kieselbrunnen" }));
    expect(screen.queryByText("4 seats left")).not.toBeInTheDocument();
    expect(await screen.findByText("12 seats left")).toBeInTheDocument();
  });
});
