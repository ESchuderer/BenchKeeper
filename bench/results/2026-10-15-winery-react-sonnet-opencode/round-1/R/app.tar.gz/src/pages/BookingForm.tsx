import { useQuery, useQueryClient } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Link, useNavigate, useParams } from "react-router";
import { MAX_GUESTS, bookingSchema } from "../../shared/booking.ts";
import { formatEur, formatWhen } from "../../shared/tastings.ts";
import { ApiError, api, type TastingWithSeats } from "../api.ts";
import { tastingsQuery } from "../queries.ts";
import { Alert } from "../components/Alert.tsx";
import { Field } from "../components/Field.tsx";
import { NotFound } from "./NotFound.tsx";

type Values = { name: string; email: string; guests: string };

export function BookingForm() {
  const { tastingId = "" } = useParams();
  const { data, error, isPending, refetch } = useQuery(tastingsQuery);

  if (isPending) return <p className="text-stone-600">Loading&hellip;</p>;
  if (error) {
    return (
      <div className="max-w-xl space-y-3">
        <Alert tone="error">We could not load this tasting. Please try again.</Alert>
        <button type="button" onClick={() => refetch()} className="rounded-md border border-burgundy px-4 py-2 font-semibold text-burgundy">
          Try again
        </button>
      </div>
    );
  }
  const tasting = data.find((t) => t.id === tastingId);
  if (!tasting) return <NotFound what="tasting" />;

  return (
    <div className="mx-auto max-w-xl">
      <Link to="/" className="text-sm text-burgundy underline underline-offset-4">
        &larr; All tastings
      </Link>
      <h1 className="mt-4 font-serif text-3xl text-burgundy sm:text-4xl">Book: {tasting.title}</h1>
      <p className="mt-2 text-stone-700">
        {formatWhen(tasting.startsAt)} &middot; {formatEur(tasting.priceEur)} per guest
      </p>
      {tasting.soldOut ? <SoldOut /> : <Form tasting={tasting} />}
    </div>
  );
}

function SoldOut() {
  return (
    <div className="mt-8 space-y-4">
      <Alert tone="info">This tasting is fully booked. There are no seats left.</Alert>
      <Link to="/" className="inline-block rounded-md bg-burgundy px-5 py-3 font-semibold text-cream hover:bg-burgundy-dark">
        Choose another tasting
      </Link>
    </div>
  );
}

function Form({ tasting }: { tasting: TastingWithSeats }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const maxGuests = Math.min(MAX_GUESTS, tasting.seatsLeft);
  const {
    register,
    handleSubmit,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<Values>({
    resolver: zodResolver(bookingSchema(tasting.seatsLeft)) as never,
    defaultValues: { name: "", email: "", guests: String(Math.min(2, tasting.seatsLeft)) },
  });

  const guests = Number(watch("guests"));
  const total = Number.isInteger(guests) && guests >= 1 && guests <= maxGuests ? guests * tasting.priceEur : null;

  const onSubmit = handleSubmit(async (values) => {
    try {
      const booking = await api.book(tasting.id, values);
      // Leave first: the tastings list is dropped once unused, so the guest never sees a refreshed "fully booked" page.
      navigate(`/confirmation/${booking.reference}`);
    } catch (e) {
      if (e instanceof ApiError && e.fieldErrors) {
        for (const [field, message] of Object.entries(e.fieldErrors)) {
          setError(field as keyof Values, { type: "server", message });
        }
        await queryClient.invalidateQueries({ queryKey: ["tastings"] });
      } else {
        setError("root", { type: "server", message: "Something went wrong. Please try again in a moment." });
      }
    }
  });

  return (
    <form onSubmit={onSubmit} noValidate className="mt-8 space-y-5 rounded-lg border border-gold/50 bg-white p-6 shadow-sm">
      {errors.root?.message ? <Alert tone="error">{errors.root.message}</Alert> : null}
      <Field id="name" label="Name" type="text" autoComplete="name" error={errors.name?.message} {...register("name")} />
      <Field id="email" label="Email" type="email" autoComplete="email" inputMode="email" error={errors.email?.message} {...register("email")} />
      <Field
        id="guests"
        label="Guests"
        type="number"
        inputMode="numeric"
        min={1}
        max={maxGuests}
        hint={`1 to ${MAX_GUESTS} guests. ${tasting.seatsLeft} seats left.`}
        error={errors.guests?.message}
        {...register("guests")}
      />
      {total !== null ? (
        <p className="text-stone-700">
          Total: <strong className="text-burgundy">{formatEur(total)}</strong>
        </p>
      ) : null}
      <button
        type="submit"
        disabled={isSubmitting}
        className="min-h-12 w-full rounded-md bg-burgundy px-5 py-3 font-semibold text-cream hover:bg-burgundy-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-burgundy disabled:cursor-wait disabled:opacity-70"
      >
        {isSubmitting ? "Booking\u2026" : "Book"}
      </button>
    </form>
  );
}
