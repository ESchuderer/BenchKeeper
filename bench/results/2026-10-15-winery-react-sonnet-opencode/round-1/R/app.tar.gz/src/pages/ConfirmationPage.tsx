import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router";
import { formatEur, formatWhen } from "../../shared/tastings.ts";
import { ApiError, api } from "../api.ts";
import { Alert } from "../components/Alert.tsx";
import { NotFound } from "./NotFound.tsx";

export function ConfirmationPage() {
  const { reference = "" } = useParams();
  const { data, error, isPending } = useQuery({
    queryKey: ["booking", reference],
    queryFn: () => api.getBooking(reference),
    retry: (count, e) => !(e instanceof ApiError && e.status === 404) && count < 1,
  });

  if (isPending) return <p className="text-stone-600">Loading your booking&hellip;</p>;
  if (error instanceof ApiError && error.status === 404) return <NotFound what="booking" />;
  if (error) return <Alert tone="error">We could not load your booking. Please reload the page.</Alert>;

  return (
    <section className="mx-auto max-w-xl">
      <div className="rounded-lg border border-moss/40 bg-white p-6 shadow-sm sm:p-8">
        <p className="text-sm font-semibold tracking-widest text-moss uppercase">Thank you</p>
        <h1 className="mt-1 font-serif text-3xl text-moss-dark sm:text-4xl">Booking confirmed</h1>
        <p className="mt-2 text-stone-700">We look forward to welcoming you. Please keep your booking reference.</p>
        <dl className="mt-6 divide-y divide-stone-200 border-y border-stone-200">
          <Row label="Tasting" value={data.tastingTitle} />
          <Row label="When" value={formatWhen(data.startsAt)} />
          <Row label="Guests" value={String(data.guests)} />
          <Row label="Total price" value={formatEur(data.totalEur)} />
          <Row label="Booking reference" value={data.reference} strong />
        </dl>
        <Link to="/" className="mt-6 inline-block text-burgundy underline underline-offset-4">
          Back to all tastings
        </Link>
      </div>
    </section>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-3">
      <dt className="text-stone-600">{label}</dt>
      <dd className={strong ? "font-mono text-lg font-bold tracking-wider text-burgundy" : "text-right font-semibold"}>{value}</dd>
    </div>
  );
}
