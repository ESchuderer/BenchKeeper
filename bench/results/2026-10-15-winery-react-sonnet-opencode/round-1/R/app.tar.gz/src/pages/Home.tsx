import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router";
import { formatEur, formatWhen } from "../../shared/tastings.ts";
import type { TastingWithSeats } from "../api.ts";
import { tastingsQuery } from "../queries.ts";
import { Alert } from "../components/Alert.tsx";

export function Home() {
  const { data, error, isPending, refetch } = useQuery(tastingsQuery);

  return (
    <>
      <section className="mb-10 max-w-2xl">
        <h1 className="font-serif text-4xl leading-tight text-burgundy sm:text-5xl">Wine tastings at the estate</h1>
        <p className="mt-4 text-lg text-stone-700">
          Join us in the cellar and at the table. Pick an evening below and reserve your seats in a minute.
        </p>
      </section>

      {isPending ? <p className="text-stone-600">Loading tastings&hellip;</p> : null}
      {error ? (
        <div className="max-w-xl space-y-3">
          <Alert tone="error">We could not load the tastings. Please check your connection and try again.</Alert>
          <button type="button" onClick={() => refetch()} className="rounded-md border border-burgundy px-4 py-2 font-semibold text-burgundy hover:bg-burgundy hover:text-cream">
            Try again
          </button>
        </div>
      ) : null}
      {data ? (
        <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {data.map((t) => (
            <li key={t.id}>
              <TastingCard tasting={t} />
            </li>
          ))}
        </ul>
      ) : null}
    </>
  );
}

function TastingCard({ tasting: t }: { tasting: TastingWithSeats }) {
  const low = !t.soldOut && t.seatsLeft <= 3;
  return (
    <article
      className={`flex h-full flex-col rounded-lg border p-6 shadow-sm ${
        t.soldOut ? "border-stone-300 bg-stone-100 text-stone-600" : "border-gold/50 bg-white"
      }`}
    >
      <p className="text-sm font-semibold tracking-wide text-gold-dark uppercase">{formatWhen(t.startsAt)}</p>
      <h2 className={`mt-2 font-serif text-2xl ${t.soldOut ? "text-stone-700" : "text-burgundy"}`}>{t.title}</h2>
      <dl className="mt-4 space-y-1 text-stone-700">
        <div className="flex items-baseline gap-2">
          <dt className="sr-only">Price per guest</dt>
          <dd className="text-lg font-semibold">{formatEur(t.priceEur)}</dd>
          <span aria-hidden="true" className="text-sm text-stone-500">
            per guest
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <dt className="sr-only">Availability</dt>
          <dd className={low ? "font-semibold text-red-700" : ""}>{`${t.seatsLeft} seats left`}</dd>
          {t.soldOut ? (
            <span className="rounded-full bg-stone-700 px-3 py-0.5 text-xs font-semibold tracking-wide text-white uppercase">Fully booked</span>
          ) : null}
        </div>
      </dl>
      <div className="mt-auto pt-6">
        {t.soldOut ? (
          <p className="text-sm italic">This tasting is sold out. Please look at the other dates.</p>
        ) : (
          <Link
            to={`/book/${t.id}`}
            className="inline-flex min-h-12 w-full items-center justify-center rounded-md bg-burgundy px-5 py-3 font-semibold text-cream hover:bg-burgundy-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-burgundy sm:w-auto"
          >
            Book {t.title}
          </Link>
        )}
      </div>
    </article>
  );
}
