import { Link } from "react-router";

export function NotFound({ what = "page" }: { what?: string }) {
  return (
    <section className="mx-auto max-w-xl py-10 text-center">
      <h1 className="font-serif text-3xl text-burgundy">{what.charAt(0).toUpperCase() + what.slice(1)} not found</h1>
      <p className="mt-3 text-stone-700">We could not find what you were looking for. The link may be old or mistyped.</p>
      <Link to="/" className="mt-6 inline-block rounded-md bg-burgundy px-5 py-3 font-semibold text-cream hover:bg-burgundy-dark">
        See all tastings
      </Link>
    </section>
  );
}
