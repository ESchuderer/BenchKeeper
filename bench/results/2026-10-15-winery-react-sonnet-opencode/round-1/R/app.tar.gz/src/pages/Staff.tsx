import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { formatWhen } from "../../shared/tastings.ts";
import { ApiError, api, type StaffBooking, type StaffGroup } from "../api.ts";
import { Alert } from "../components/Alert.tsx";
import { Field } from "../components/Field.tsx";

const KEY = ["staff", "bookings"];

export function Staff() {
  const queryClient = useQueryClient();
  const { data, error, isPending, refetch } = useQuery({ queryKey: KEY, queryFn: api.staff.bookings, retry: false });

  if (isPending) return <p className="text-stone-600">Loading&hellip;</p>;
  if (error instanceof ApiError && error.status === 401) {
    return <SignIn onDone={() => queryClient.resetQueries({ queryKey: KEY })} />;
  }
  if (error) {
    return (
      <div className="max-w-xl space-y-3">
        <Alert tone="error">We could not load the bookings. Please try again.</Alert>
        <button type="button" onClick={() => refetch()} className="rounded-md border border-burgundy px-4 py-2 font-semibold text-burgundy">
          Try again
        </button>
      </div>
    );
  }
  return <Dashboard groups={data} />;
}

function SignIn({ onDone }: { onDone: () => unknown }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: "" } });

  const submit = handleSubmit(async ({ password }) => {
    if (!password) return setError("password", { message: "Please enter the password." });
    try {
      await api.staff.login(password);
      await onDone();
    } catch (e) {
      const wrong = e instanceof ApiError && e.status === 401;
      setError("password", {
        message: wrong ? "That password is not correct." : "We could not sign you in. Please try again.",
      });
    }
  });

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="font-serif text-3xl text-burgundy">Staff area</h1>
      <p className="mt-2 text-stone-700">Please sign in to see the tasting bookings.</p>
      <form
        noValidate
        onSubmit={(e) => {
          // Empty submit is validated by hand so the message sits next to the field.
          void submit(e);
        }}
        className="mt-6 space-y-5 rounded-lg border border-gold/50 bg-white p-6 shadow-sm"
      >
        <Field id="password" label="Password" type="password" autoComplete="current-password" error={errors.password?.message} {...register("password")} />
        <button
          type="submit"
          disabled={isSubmitting}
          className="min-h-12 w-full rounded-md bg-burgundy px-5 py-3 font-semibold text-cream hover:bg-burgundy-dark focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-burgundy disabled:opacity-70"
        >
          Sign in
        </button>
      </form>
    </div>
  );
}

function Dashboard({ groups }: { groups: StaffGroup[] }) {
  const queryClient = useQueryClient();
  const [notice, setNotice] = useState<string | null>(null);
  const [failure, setFailure] = useState<string | null>(null);

  const cancel = useMutation({
    mutationFn: (b: StaffBooking) => api.staff.cancel(b.reference),
    onMutate: () => {
      setNotice(null);
      setFailure(null);
    },
    onSuccess: (_data, b) => setNotice(`Booking ${b.reference} for ${b.name} is cancelled. Its seats are free again.`),
    onError: (e) => {
      if (!(e instanceof ApiError && e.status === 401)) setFailure("We could not cancel that booking. Please try again.");
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: KEY }),
  });

  const signOut = useMutation({
    mutationFn: api.staff.logout,
    onSettled: () => queryClient.resetQueries({ queryKey: KEY }),
  });

  return (
    <>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-serif text-3xl text-burgundy sm:text-4xl">Bookings</h1>
        <button
          type="button"
          onClick={() => signOut.mutate()}
          className="rounded-md border border-stone-400 px-4 py-2 font-semibold text-stone-700 hover:border-burgundy hover:text-burgundy"
        >
          Sign out
        </button>
      </div>
      <div className="mb-6 space-y-3 empty:hidden">
        {notice ? <Alert tone="success">{notice}</Alert> : null}
        {failure ? <Alert tone="error">{failure}</Alert> : null}
      </div>
      <div className="space-y-8">
        {groups.map(({ tasting, seatsLeft, bookings }) => (
          <section key={tasting.id} className="rounded-lg border border-gold/50 bg-white shadow-sm">
            <div className="border-b border-stone-200 px-5 py-4">
              <h2 className="font-serif text-2xl text-burgundy">{tasting.title}</h2>
              <p className="text-sm text-stone-600">
                {formatWhen(tasting.startsAt)} &middot; <span>{`${tasting.capacity - seatsLeft} of ${tasting.capacity} seats booked`}</span>
              </p>
            </div>
            {bookings.length === 0 ? (
              <p className="px-5 py-4 text-stone-600">No bookings yet</p>
            ) : (
              <ul className="divide-y divide-stone-200">
                {bookings.map((b) => (
                  <li key={b.reference} className="flex flex-wrap items-center justify-between gap-x-6 gap-y-2 px-5 py-4">
                    <div className="min-w-0">
                      <p className="font-semibold break-words">{b.name}</p>
                      <p className="text-sm break-all text-stone-600">{b.email}</p>
                    </div>
                    <p className="text-stone-700">{`${b.guests} ${b.guests === 1 ? "guest" : "guests"}`}</p>
                    <p className="font-mono text-sm tracking-wider text-burgundy">{b.reference}</p>
                    <button
                      type="button"
                      onClick={() => cancel.mutate(b)}
                      disabled={cancel.isPending}
                      className="rounded-md border border-red-700 px-4 py-2 font-semibold text-red-700 hover:bg-red-700 hover:text-white disabled:opacity-50"
                    >
                      Cancel
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </div>
    </>
  );
}
