import { queryOptions } from "@tanstack/react-query";
import { api } from "./api.ts";

/** Seat counts change with every booking, so never show a cached list: drop it as soon as no page uses it. */
export const tastingsQuery = queryOptions({ queryKey: ["tastings"], queryFn: api.listTastings, gcTime: 0 });
