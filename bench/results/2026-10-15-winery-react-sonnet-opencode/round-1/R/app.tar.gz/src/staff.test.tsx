// @vitest-environment jsdom
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { mockApi, renderAt } from "./test-utils.tsx";

afterEach(() => vi.unstubAllGlobals());

const riesling = { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00", priceEur: 25, capacity: 12 };
const red = { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00", priceEur: 32, capacity: 8 };

function groups(bookings: { reference: string; name: string; email: string; guests: number }[]) {
  const taken = bookings.reduce((n, b) => n + b.guests, 0);
  return [
    { tasting: riesling, seatsLeft: 12 - taken, bookings: bookings.map((b) => ({ ...b, createdAt: "2026-10-15T10:00:00Z" })) },
    { tasting: red, seatsLeft: 8, bookings: [] },
  ];
}

const anna = { reference: "KB-AAAAAA", name: "Anna Weber", email: "anna@example.com", guests: 2 };
const ben = { reference: "KB-BBBBBB", name: "Ben Roth", email: "ben@example.com", guests: 3 };

describe("staff sign in", () => {
  it("asks for a password when not signed in", async () => {
    mockApi({ "GET /api/staff/bookings": { status: 401, body: { error: "Please sign in." } } });
    renderAt("/staff");
    expect(await screen.findByLabelText("Password")).toHaveAttribute("type", "password");
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
    expect(screen.queryByText("anna@example.com")).not.toBeInTheDocument();
  });

  it("asks for the password before sending anything", async () => {
    const api = mockApi({ "GET /api/staff/bookings": { status: 401 } });
    renderAt("/staff");
    await userEvent.click(await screen.findByRole("button", { name: "Sign in" }));
    expect(await screen.findByLabelText("Password")).toHaveAccessibleDescription(/enter the password/i);
    expect(api.calls.some((c) => c.key.startsWith("POST"))).toBe(false);
  });

  it("shows a wrong password error next to the field", async () => {
    mockApi({
      "GET /api/staff/bookings": { status: 401 },
      "POST /api/staff/login": { status: 401, body: { error: "That password is not correct." } },
    });
    renderAt("/staff");
    await userEvent.type(await screen.findByLabelText("Password"), "nope");
    await userEvent.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByLabelText("Password")).toHaveAccessibleDescription("That password is not correct.");
  });

  it("signs in and shows the bookings", async () => {
    let signedIn = false;
    mockApi({
      "GET /api/staff/bookings": () => (signedIn ? { body: groups([anna]) } : { status: 401 }),
      "POST /api/staff/login": ({ body }) => {
        expect(body).toEqual({ password: "secret" });
        signedIn = true;
        return { status: 204 };
      },
    });
    renderAt("/staff");
    await userEvent.type(await screen.findByLabelText("Password"), "secret");
    await userEvent.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByText("Anna Weber")).toBeInTheDocument();
  });
});

describe("staff bookings", () => {
  it("groups bookings by tasting with name, email, guests and reference", async () => {
    mockApi({ "GET /api/staff/bookings": { body: groups([anna, ben]) } });
    renderAt("/staff");
    const section = (await screen.findByRole("heading", { name: "Riesling Evening" })).closest("section")!;
    expect(within(section).getByText("Anna Weber")).toBeInTheDocument();
    expect(within(section).getByText("anna@example.com")).toBeInTheDocument();
    expect(within(section).getByText("KB-AAAAAA")).toBeInTheDocument();
    expect(within(section).getByText("3 guests")).toBeInTheDocument();
    expect(within(section).getByText("Ben Roth")).toBeInTheDocument();
    expect(within(section).getAllByRole("button", { name: "Cancel" })).toHaveLength(2);
    expect(within(section).getByText("5 of 12 seats booked")).toBeInTheDocument();
    const other = screen.getByRole("heading", { name: "Red Wine Cellar Tour" }).closest("section")!;
    expect(within(other).getByText("No bookings yet")).toBeInTheDocument();
  });

  it("uses singular for one guest", async () => {
    mockApi({ "GET /api/staff/bookings": { body: groups([{ ...anna, guests: 1 }]) } });
    renderAt("/staff");
    expect(await screen.findByText("1 guest")).toBeInTheDocument();
  });

  it("shows guest-supplied text literally, never as markup", async () => {
    mockApi({ "GET /api/staff/bookings": { body: groups([{ ...anna, name: "<b>Bold</b>", email: "<img src=x onerror=alert(1)>@x.de" }]) } });
    const { container } = renderAt("/staff");
    expect(await screen.findByText("<b>Bold</b>")).toBeInTheDocument();
    expect(container.querySelector("main b, main img")).toBeNull();
  });

  it("cancels a booking, removes it and says so", async () => {
    let current = [anna, ben];
    const api = mockApi({
      "GET /api/staff/bookings": () => ({ body: groups(current) }),
      "DELETE /api/staff/bookings/KB-AAAAAA": () => {
        current = [ben];
        return { status: 204 };
      },
    });
    renderAt("/staff");
    await screen.findByText("Anna Weber");
    const row = screen.getByText("Anna Weber").closest("li")!;
    await userEvent.click(within(row).getByRole("button", { name: "Cancel" }));
    await waitFor(() => expect(screen.queryByText("Anna Weber")).not.toBeInTheDocument());
    expect(screen.getByRole("status")).toHaveTextContent("KB-AAAAAA");
    expect(screen.getByText("Ben Roth")).toBeInTheDocument();
    expect(screen.getByText("3 of 12 seats booked")).toBeInTheDocument();
    expect(api.calls.filter((c) => c.key.startsWith("DELETE"))).toHaveLength(1);
  });

  it("shows an error when cancelling fails and keeps the booking", async () => {
    mockApi({
      "GET /api/staff/bookings": { body: groups([anna]) },
      "DELETE /api/staff/bookings/KB-AAAAAA": { status: 500, body: { error: "boom" } },
    });
    renderAt("/staff");
    await userEvent.click(await screen.findByRole("button", { name: "Cancel" }));
    expect(await screen.findByRole("alert")).toHaveTextContent(/could not cancel/i);
    expect(screen.getByText("Anna Weber")).toBeInTheDocument();
  });

  it("returns to sign in when the session has expired during cancel", async () => {
    let expired = false;
    mockApi({
      "GET /api/staff/bookings": () => (expired ? { status: 401 } : { body: groups([anna]) }),
      "DELETE /api/staff/bookings/KB-AAAAAA": () => {
        expired = true;
        return { status: 401, body: { error: "Please sign in." } };
      },
    });
    renderAt("/staff");
    await userEvent.click(await screen.findByRole("button", { name: "Cancel" }));
    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
  });

  it("signs out", async () => {
    let out = false;
    mockApi({
      "GET /api/staff/bookings": () => (out ? { status: 401 } : { body: groups([anna]) }),
      "POST /api/staff/logout": () => {
        out = true;
        return { status: 204 };
      },
    });
    renderAt("/staff");
    await userEvent.click(await screen.findByRole("button", { name: "Sign out" }));
    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.queryByText("Anna Weber")).not.toBeInTheDocument();
  });
});
