import { render } from "@testing-library/react";
import { QueryClientProvider } from "@tanstack/react-query";
import { MemoryRouter } from "react-router";
import { makeQueryClient } from "./queryClient.ts";
import { AppRoutes } from "./App.tsx";

type Reply = { status?: number; body?: unknown; delayMs?: number };
type Handler = Reply | ((req: { body: any }) => Reply);

/** Replaces global fetch with a table keyed "METHOD /path". Unlisted requests fail the test. */
export function mockApi(table: Record<string, Handler>) {
  const calls: { key: string; body: any }[] = [];
  const fn = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const key = `${(init?.method ?? "GET").toUpperCase()} ${String(input)}`;
    const body = init?.body ? JSON.parse(String(init.body)) : undefined;
    calls.push({ key, body });
    const h = table[key];
    if (!h) throw new Error(`Unexpected request: ${key}`);
    const reply = typeof h === "function" ? h({ body }) : h;
    if (reply.delayMs) await new Promise((r) => setTimeout(r, reply.delayMs));
    const status = reply.status ?? 200;
    return new Response(status === 204 ? null : JSON.stringify(reply.body ?? {}), {
      status,
      headers: { "Content-Type": "application/json" },
    });
  });
  vi.stubGlobal("fetch", fn);
  return { calls, fn };
}

export function renderAt(path: string) {
  return render(
    <QueryClientProvider client={makeQueryClient(false)}>
      <MemoryRouter initialEntries={[path]}>
        <AppRoutes />
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

export const tastings = [
  { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00", priceEur: 25, capacity: 12, seatsLeft: 12, soldOut: false },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00", priceEur: 32, capacity: 8, seatsLeft: 2, soldOut: false },
  { id: "winter-tasting", title: "Winter Tasting", startsAt: "2026-12-05T17:00", priceEur: 28, capacity: 10, seatsLeft: 0, soldOut: true },
];
