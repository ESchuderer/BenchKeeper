# Weingut Kieselbrunnen – tasting bookings

React (Vite, React Router, React Hook Form) frontend, Express 5 + Zod backend, bookings kept in memory.

```
npm install
npm run build
STAFF_PASSWORD=choose-one npm start     # http://localhost:3000, PORT to change
npm test                                # API + UI tests (vitest)
npm run dev                             # Vite dev server, proxies /api to :3000 (run `npm start` too)
```

- `STAFF_PASSWORD` – staff password for `/staff`. If unset, staff sign-in is disabled (nobody can sign in).
- `TRUST_PROXY` – set (e.g. `1`) when behind a TLS-terminating proxy.
- Bookings live in memory and are lost on restart. See `docs/SPEC.md` for behaviour.
