# Weingut Kieselbrunnen – tasting bookings

## Data
Three tastings, seeded at start (ids `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`):
Riesling Evening 2026-11-06 18:00 EUR 25 / 12 seats; Red Wine Cellar Tour 2026-11-14 15:00 EUR 32 / 8;
Winter Tasting 2026-12-05 17:00 EUR 28 / 10. Bookings start empty, kept in memory.

## API (JSON)
- `GET /api/tastings` -> tastings with `seatsLeft`, `priceCents`, `startsAt`, `started` (booking closed once started).
- `POST /api/bookings {tastingId, name, email, guests}` -> 201 `{booking, tasting}`.
  Errors 400/404/409: `{error, errors: {field: message}}`. Fields: `name`, `email`, `guests`.
  Rules: name 1-100 chars after trim; email valid, max 254; guests integer 1-8 and <= seats left
  (checked atomically with the insert); tasting must exist and not have started.
- `POST /api/staff/login {password}` -> sets httpOnly session cookie; 401 on wrong password.
  Fails closed (always 401) when `STAFF_PASSWORD` is unset/empty. Rate limited.
- `POST /api/staff/logout`, `GET /api/staff/bookings` (401 without session) -> tastings with bookings.
- `DELETE /api/staff/bookings/:id` (401 without session, 404 unknown) frees seats.

## UI
- `/` tasting list: title, date/time, price per guest, "<n> seats left", "Book <title>" link;
  fully booked tastings show a "Fully booked" badge and a disabled button instead of a link.
- `/book/:id` form: Name, Email, Guests (1-8), "Book". Errors inline next to field (client and server).
- Confirmation: heading "Booking confirmed", tasting, guests, total, reference (e.g. `KB-7F3K2Q`).
- `/staff`: Password + "Sign in"; then bookings grouped by tasting (name, email, guests, reference),
  "Cancel" per booking, "Sign out".
- Responsive (phone first), accessible labels, visible focus, clear error/success/sold-out states.

## Run
`npm install && npm run build && npm start` (PORT, default 3000; STAFF_PASSWORD).
`npm test` runs API tests (vitest + supertest) and UI tests (Testing Library).
