import { randomBytes, timingSafeEqual, createHash } from 'node:crypto';
import path from 'node:path';
import { existsSync } from 'node:fs';
import express from 'express';
import cookieParser from 'cookie-parser';
import { rateLimit } from 'express-rate-limit';
import { createStore } from './store.js';
import { parseBooking } from './validate.js';

const COOKIE = 'staff_session';
const SESSION_MS = 8 * 3600 * 1000;

const digest = (s) => createHash('sha256').update(s).digest();
const passwordMatches = (given, expected) =>
  typeof given === 'string' && timingSafeEqual(digest(given), digest(expected));

const publicBooking = ({ reference, tastingId, name, email, guests, totalCents }) => ({
  reference, tastingId, name, email, guests, totalCents,
});

export function createApp({
  staffPassword = process.env.STAFF_PASSWORD,
  now = () => new Date(),
  loginLimit = 10,
  trustProxy = process.env.TRUST_PROXY,
  staticDir = path.resolve(import.meta.dirname, '../dist'),
} = {}) {
  const store = createStore({ now });
  const sessions = new Map(); // token -> expiry ms
  const app = express();
  app.disable('x-powered-by');
  // Set TRUST_PROXY (e.g. 1) when running behind a TLS-terminating proxy, so the cookie gets `Secure`
  // and rate limiting sees the real client address.
  if (trustProxy) app.set('trust proxy', /^\d+$/.test(trustProxy) ? Number(trustProxy) : trustProxy);
  app.use((req, res, next) => {
    res.set({
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'same-origin',
      'X-Frame-Options': 'DENY',
      'Content-Security-Policy':
        "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'",
    });
    next();
  });
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  const loggedIn = (req) => {
    const token = req.cookies[COOKIE];
    const expires = typeof token === 'string' ? sessions.get(token) : undefined;
    if (expires === undefined) return false;
    if (expires <= now().getTime()) {
      sessions.delete(token);
      return false;
    }
    return true;
  };
  const requireStaff = (req, res, next) => {
    if (!loggedIn(req)) {
      res.set('Cache-Control', 'no-store');
      return res.status(401).json({ error: 'Please sign in.' });
    }
    res.set('Cache-Control', 'no-store');
    next();
  };

  app.get('/api/tastings', (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.json({ tastings: store.listTastings() });
  });

  app.post('/api/bookings', (req, res) => {
    const parsed = parseBooking(req.body);
    if (parsed.errors) return res.status(400).json({ error: 'Please check your details.', errors: parsed.errors });
    const result = store.book(parsed.data);
    if (result.error) {
      const { status, message, field } = result.error;
      return res.status(status).json({ error: message, ...(field && { errors: { [field]: message } }) });
    }
    res.status(201).json({ booking: publicBooking(result.booking), tasting: result.tasting });
  });

  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: loginLimit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many attempts. Please try again later.' },
  });
  app.post('/api/staff/login', limiter, (req, res) => {
    // An unset or empty STAFF_PASSWORD must never grant access.
    const ok = Boolean(staffPassword) && passwordMatches(req.body?.password, staffPassword);
    if (!ok) return res.status(401).json({ error: 'Wrong password.' });
    const nowMs = now().getTime();
    for (const [t, expires] of sessions) if (expires <= nowMs) sessions.delete(t);
    const token = randomBytes(32).toString('hex');
    sessions.set(token, now().getTime() + SESSION_MS);
    res.cookie(COOKIE, token, {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure,
      maxAge: SESSION_MS,
      path: '/',
    });
    res.json({ ok: true });
  });
  app.post('/api/staff/logout', (req, res) => {
    const token = req.cookies[COOKIE];
    if (typeof token === 'string') sessions.delete(token);
    res.clearCookie(COOKIE, { path: '/' });
    res.status(204).end();
  });
  app.get('/api/staff/session', (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.json({ signedIn: loggedIn(req) });
  });
  app.get('/api/staff/bookings', requireStaff, (req, res) => {
    res.json({ tastings: store.listWithBookings() });
  });
  app.delete('/api/staff/bookings/:id', requireStaff, (req, res) => {
    if (!store.cancel(req.params.id)) return res.status(404).json({ error: 'Booking not found.' });
    res.status(204).end();
  });

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

  if (existsSync(staticDir)) {
    app.use(express.static(staticDir, { index: false, maxAge: '1h' }));
    // Client-side routes get the app; requests for files (/assets/x.js) must 404 for real.
    app.get(/.*/, (req, res, next) =>
      path.extname(req.path) ? next() : res.sendFile(path.join(staticDir, 'index.html')),
    );
  }

  app.use((err, req, res, next) => {
    if (err.status >= 400 && err.status < 500) return res.status(err.status).json({ error: 'Invalid request.' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong.' });
  });
  return app;
}
