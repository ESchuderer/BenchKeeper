import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import path from 'node:path';
import { tmpdir } from 'node:os';
import { mkdtemp, writeFile } from 'node:fs/promises';
import { createApp } from './app.js';

const NOW = new Date('2026-10-15T12:00:00+02:00');
const PASSWORD = 'correct horse';
let app;

const make = (opts = {}) =>
  createApp({ staffPassword: PASSWORD, now: () => NOW, loginLimit: 1000, ...opts });
const book = (body, a = app) => request(a).post('/api/bookings').send(body);
const valid = (over = {}) => ({
  tastingId: 'riesling-evening',
  name: 'Anna Weber',
  email: 'anna@example.com',
  guests: 2,
  ...over,
});
const staff = async (a = app) => {
  const agent = request.agent(a);
  await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(200);
  return agent;
};

beforeEach(() => {
  app = make();
});

describe('GET /api/tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const res = await request(app).get('/api/tastings').expect(200);
    expect(res.body.tastings.map((t) => [t.id, t.title, t.priceCents, t.seats, t.seatsLeft])).toEqual([
      ['riesling-evening', 'Riesling Evening', 2500, 12, 12],
      ['red-wine-cellar-tour', 'Red Wine Cellar Tour', 3200, 8, 8],
      ['winter-tasting', 'Winter Tasting', 2800, 10, 10],
    ]);
    expect(res.body.tastings[0].startsAt).toBe('2026-11-06T18:00:00+01:00');
  });
});

describe('POST /api/bookings', () => {
  it('books, returns total and reference, and reduces seats left', async () => {
    const res = await book(valid({ guests: 3 })).expect(201);
    expect(res.body.booking).toMatchObject({ name: 'Anna Weber', guests: 3, totalCents: 7500 });
    expect(res.body.booking.reference).toMatch(/^KB-[A-Z2-9]{6}$/);
    expect(res.body.tasting).toMatchObject({ title: 'Riesling Evening', seatsLeft: 9 });
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[0].seatsLeft).toBe(9);
  });

  it('does not leak other bookings or staff-only data in the response', async () => {
    const res = await book(valid()).expect(201);
    expect(Object.keys(res.body.booking).sort()).toEqual(
      ['email', 'guests', 'name', 'reference', 'tastingId', 'totalCents'].sort(),
    );
  });

  it('trims name and email', async () => {
    const res = await book(valid({ name: '  Anna  ', email: ' anna@example.com ' })).expect(201);
    expect(res.body.booking).toMatchObject({ name: 'Anna', email: 'anna@example.com' });
  });

  it('issues unique references', async () => {
    const refs = new Set();
    for (let i = 0; i < 5; i++) refs.add((await book(valid({ guests: 1 }))).body.booking.reference);
    expect(refs.size).toBe(5);
  });

  it.each([
    ['name', { name: '' }],
    ['name', { name: '   ' }],
    ['name', { name: 'x'.repeat(101) }],
    ['name', { name: 42 }],
    ['email', { email: '' }],
    ['email', { email: 'not-an-email' }],
    ['email', { email: 'a@b' }],
    ['guests', { guests: 0 }],
    ['guests', { guests: 9 }],
    ['guests', { guests: -1 }],
    ['guests', { guests: 1.5 }],
    ['guests', { guests: '' }],
    ['guests', { guests: 'abc' }],
    ['guests', { guests: null }],
    ['guests', { guests: true }],
    ['guests', { guests: undefined }],
  ])('rejects invalid %s (%j) with a field error', async (field, over) => {
    const res = await book(valid(over)).expect(400);
    expect(res.body.errors[field]).toEqual(expect.any(String));
    expect(Object.keys(res.body.errors)).toEqual([field]);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[0].seatsLeft).toBe(12);
  });

  it('reports every invalid field at once', async () => {
    const res = await book({ tastingId: 'riesling-evening' }).expect(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it('accepts guests sent as a digit string', async () => {
    await book(valid({ guests: '4' })).expect(201);
  });

  it('rejects a non-object body', async () => {
    await request(app).post('/api/bookings').send([1]).expect(400);
    await request(app).post('/api/bookings').set('Content-Type', 'application/json').send('{bad').expect(400);
  });

  it('404s for an unknown tasting', async () => {
    const res = await book(valid({ tastingId: 'nope' })).expect(404);
    expect(res.body.error).toEqual(expect.any(String));
  });

  it('never takes more seats than are left', async () => {
    for (let i = 0; i < 7; i++) await book(valid({ tastingId: 'red-wine-cellar-tour', guests: 1 })).expect(201);
    // 1 seat left on an 8 seat tasting
    const res = await book(valid({ tastingId: 'red-wine-cellar-tour', guests: 2 })).expect(409);
    expect(res.body.errors.guests).toMatch(/1 seat/);
    await book(valid({ tastingId: 'red-wine-cellar-tour', guests: 1 })).expect(201);
    const full = await book(valid({ tastingId: 'red-wine-cellar-tour', guests: 1 })).expect(409);
    expect(full.body.errors.guests).toMatch(/fully booked/i);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[1].seatsLeft).toBe(0);
  });

  it('never oversells under concurrent requests', async () => {
    const results = await Promise.all(
      Array.from({ length: 20 }, () => book(valid({ tastingId: 'winter-tasting', guests: 3 }))),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(3);
    expect(results.filter((r) => r.status === 409)).toHaveLength(17);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[2].seatsLeft).toBe(1);
  });

  it('refuses tastings that already started', async () => {
    const late = make({ now: () => new Date('2026-11-06T17:00:00Z') }); // 18:00 CET has passed
    const res = await book(valid(), late).expect(409);
    expect(res.body.error).toMatch(/already/i);
  });
});

describe('started tastings and static serving', () => {
  it('flags tastings that have started', async () => {
    const late = make({ now: () => new Date('2026-11-10T12:00:00Z') });
    const res = await request(late).get('/api/tastings');
    expect(res.body.tastings.map((t) => t.started)).toEqual([true, false, false]);
  });

  it('gives a whole-number message for fractional guests sent as text', async () => {
    const res = await book(valid({ guests: '2.5' })).expect(400);
    expect(res.body.errors.guests).toMatch(/whole number/);
  });

  it('serves the SPA for routes but 404s for missing files', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'kb-'));
    await writeFile(path.join(dir, 'index.html'), '<div id="root"></div>');
    const a = make({ staticDir: dir });
    await request(a).get('/book/riesling-evening').expect(200).expect(/root/);
    await request(a).get('/assets/missing.js').expect(404);
  });

  it('reports unsupported request encodings as 4xx, not 500', async () => {
    const res = await request(app)
      .post('/api/bookings')
      .set('Content-Type', 'application/json; charset=utf-7')
      .send('{}');
    expect(res.status).toBeGreaterThanOrEqual(400);
    expect(res.status).toBeLessThan(500);
  });
});

describe('staff auth', () => {
  it('rejects wrong and missing passwords', async () => {
    await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    await request(app).post('/api/staff/login').send({}).expect(401);
    await request(app).post('/api/staff/login').send({ password: ['x'] }).expect(401);
  });

  it('fails closed when STAFF_PASSWORD is not set', async () => {
    for (const pw of [undefined, '']) {
      const a = make({ staffPassword: pw });
      await request(a).post('/api/staff/login').send({ password: '' }).expect(401);
      await request(a).post('/api/staff/login').send({ password: 'undefined' }).expect(401);
    }
  });

  it('protects staff endpoints', async () => {
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete('/api/staff/bookings/abc').expect(401);
    await request(app).get('/api/staff/bookings').set('Cookie', 'staff_session=forged').expect(401);
  });

  it('sets an httpOnly cookie and supports logout', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(200);
    const cookie = res.headers['set-cookie'][0];
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    const agent = await staff();
    await agent.get('/api/staff/bookings').expect(200);
    await agent.post('/api/staff/logout').expect(204);
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('expires sessions', async () => {
    let t = NOW.getTime();
    const a = make({ now: () => new Date(t) });
    const agent = await staff(a);
    await agent.get('/api/staff/bookings').expect(200);
    t += 9 * 3600 * 1000;
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('rate limits login attempts', async () => {
    const a = make({ loginLimit: 3 });
    for (let i = 0; i < 3; i++) await request(a).post('/api/staff/login').send({ password: 'x' }).expect(401);
    await request(a).post('/api/staff/login').send({ password: 'x' }).expect(429);
  });
});

describe('staff bookings', () => {
  it('groups bookings by tasting, including empty tastings', async () => {
    await book(valid({ name: 'A', guests: 2 }));
    await book(valid({ name: 'B', tastingId: 'winter-tasting', guests: 1 }));
    const agent = await staff();
    const res = await agent.get('/api/staff/bookings').expect(200);
    const [riesling, red, winter] = res.body.tastings;
    expect(riesling.bookings).toHaveLength(1);
    expect(riesling.bookings[0]).toMatchObject({ name: 'A', email: 'anna@example.com', guests: 2 });
    expect(riesling.bookings[0].reference).toMatch(/^KB-/);
    expect(red.bookings).toEqual([]);
    expect(winter.bookings[0].name).toBe('B');
  });

  it('cancelling frees the seats and removes the booking', async () => {
    const { body } = await book(valid({ guests: 5 }));
    const agent = await staff();
    const before = await agent.get('/api/staff/bookings');
    const id = before.body.tastings[0].bookings[0].id;
    expect(before.body.tastings[0].seatsLeft).toBe(7);
    await agent.delete(`/api/staff/bookings/${id}`).expect(204);
    const after = await agent.get('/api/staff/bookings');
    expect(after.body.tastings[0].bookings).toEqual([]);
    expect(after.body.tastings[0].seatsLeft).toBe(12);
    await agent.delete(`/api/staff/bookings/${id}`).expect(404);
    // seats are bookable again
    await book(valid({ guests: 8 })).expect(201);
    await book(valid({ guests: 4 })).expect(201);
    expect(body.booking.reference).toBeTruthy();
  });

  it('does not expose internal ids in the public booking response', async () => {
    const res = await book(valid());
    expect(res.body.booking.id).toBeUndefined();
  });
});
