import { randomBytes, randomUUID } from 'node:crypto';

export const MAX_GUESTS = 8;

const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00:00+01:00', priceCents: 2500, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00:00+01:00', priceCents: 3200, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00:00+01:00', priceCents: 2800, seats: 10 },
];

// No 0/O/1/I so references can be read out over the phone.
const REF_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newReference = () =>
  'KB-' + Array.from(randomBytes(6), (b) => REF_ALPHABET[b % REF_ALPHABET.length]).join('');

/** In-memory store. All mutations are synchronous, so seat checks and inserts cannot interleave. */
export function createStore({ now = () => new Date() } = {}) {
  const bookings = new Map(); // id -> booking

  const seatsTaken = (tastingId) => {
    let n = 0;
    for (const b of bookings.values()) if (b.tastingId === tastingId) n += b.guests;
    return n;
  };
  const withSeats = (t) => ({
    ...t,
    seatsLeft: t.seats - seatsTaken(t.id),
    started: new Date(t.startsAt) <= now(),
  });
  const find = (id) => TASTINGS.find((t) => t.id === id);

  return {
    listTastings: () => TASTINGS.map(withSeats),

    /** Returns { booking, tasting } or { error: { status, message, field? } }. Input must be validated. */
    book({ tastingId, name, email, guests }) {
      const base = find(tastingId);
      if (!base) return { error: { status: 404, message: 'This tasting does not exist.' } };
      if (new Date(base.startsAt) <= now()) {
        return { error: { status: 409, message: 'This tasting has already started and can no longer be booked.' } };
      }
      const left = base.seats - seatsTaken(base.id);
      if (guests > left) {
        const message =
          left === 0
            ? 'This tasting is fully booked.'
            : `Only ${left} ${left === 1 ? 'seat is' : 'seats are'} left for this tasting.`;
        return { error: { status: 409, message, field: 'guests' } };
      }
      let reference = newReference();
      while ([...bookings.values()].some((b) => b.reference === reference)) reference = newReference();
      const booking = {
        id: randomUUID(),
        reference,
        tastingId,
        name,
        email,
        guests,
        totalCents: guests * base.priceCents,
        createdAt: now().toISOString(),
      };
      bookings.set(booking.id, booking);
      return { booking, tasting: withSeats(base) };
    },

    cancel: (id) => bookings.delete(id),

    listWithBookings: () =>
      TASTINGS.map((t) => ({
        ...withSeats(t),
        bookings: [...bookings.values()].filter((b) => b.tastingId === t.id),
      })),
  };
}
