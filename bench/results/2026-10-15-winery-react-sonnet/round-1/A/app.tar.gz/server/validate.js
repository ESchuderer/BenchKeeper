import { z } from 'zod';
import { MAX_GUESTS } from './store.js';

const text = (label, max) =>
  z
    .string({ error: `Please enter your ${label}.` })
    .trim()
    .min(1, `Please enter your ${label}.`)
    .max(max, `Your ${label} is too long (max ${max} characters).`);

const guests = z.preprocess(
  (v) => (typeof v === 'string' && /^\d{1,3}(\.\d+)?$/.test(v.trim()) ? Number(v) : v),
  z
    .number({ error: `Please enter a number of guests from 1 to ${MAX_GUESTS}.` })
    .int(`Please enter a whole number of guests from 1 to ${MAX_GUESTS}.`)
    .min(1, `Please book for at least 1 guest.`)
    .max(MAX_GUESTS, `You can book at most ${MAX_GUESTS} guests at a time.`),
);

const schema = z.object({
  tastingId: z.string(),
  name: text('name', 100),
  email: z
    .string({ error: 'Please enter your email address.' })
    .trim()
    .min(1, 'Please enter your email address.')
    .max(254, 'This email address is too long.')
    .pipe(z.email('Please enter a valid email address, e.g. name@example.com.')),
  guests,
});

/** @returns {{ data: object } | { errors: Record<string,string> }} */
export function parseBooking(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    return { errors: { form: 'Invalid request.' } };
  }
  const result = schema.safeParse({ ...body, tastingId: typeof body.tastingId === 'string' ? body.tastingId : '' });
  if (result.success) return { data: result.data };
  const errors = {};
  for (const issue of result.error.issues) {
    const key = String(issue.path[0] ?? 'form');
    errors[key] ??= issue.message;
  }
  return { errors };
}
