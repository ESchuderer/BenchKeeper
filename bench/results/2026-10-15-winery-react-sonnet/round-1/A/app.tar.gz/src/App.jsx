import { Link, NavLink, Route, Routes } from 'react-router-dom';
import TastingList from './pages/TastingList.jsx';
import BookingPage from './pages/BookingPage.jsx';
import StaffPage from './pages/StaffPage.jsx';

function NotFound() {
  return (
    <section className="panel">
      <h1>Page not found</h1>
      <p>We could not find that page.</p>
      <Link className="btn" to="/">See our tastings</Link>
    </section>
  );
}

export default function App() {
  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <header className="site-header">
        <div className="wrap header-inner">
          <Link to="/" className="brand">
            <svg className="brand-mark" viewBox="0 0 32 32" aria-hidden="true">
              <circle cx="16" cy="16" r="16" />
              <path d="M10 7h12c0 7-2 11-6 11s-6-4-6-11zm6 11v6m-4 0h8" />
            </svg>
            <span>
              Weingut Kieselbrunnen
              <small>Family winery</small>
            </span>
          </Link>
          <nav aria-label="Main">
            <NavLink to="/" end>Tastings</NavLink>
          </nav>
        </div>
      </header>
      <main id="main" className="wrap">
        <Routes>
          <Route path="/" element={<TastingList />} />
          <Route path="/book/:id" element={<BookingPage />} />
          <Route path="/staff" element={<StaffPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <div className="wrap">
          <p>Weingut Kieselbrunnen · Wine grown with patience, poured with pride.</p>
          <p><Link to="/staff">Staff</Link></p>
        </div>
      </footer>
    </>
  );
}
