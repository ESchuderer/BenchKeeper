/** JSON helper. Never throws on HTTP errors; a network failure yields { ok: false, status: 0 }. */
export async function api(path, { method = 'GET', body } = {}) {
  try {
    const res = await fetch(path, {
      method,
      ...(body !== undefined && { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
    });
    let data = null;
    try {
      data = await res.json();
    } catch {
      /* empty body, e.g. 204 */
    }
    return { ok: res.ok, status: res.status, data };
  } catch {
    return { ok: false, status: 0, data: null };
  }
}
