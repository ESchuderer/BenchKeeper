// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, within, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import request from 'supertest';
import { createApp } from '../server/app.js';
import App from './App.jsx';

const PASSWORD = 'secret-pw';
let server; // express app
let agent; // the "browser": keeps cookies

beforeEach(() => {
  server = createApp({ staffPassword: PASSWORD, now: () => new Date('2026-10-15T12:00:00+02:00'), loginLimit: 1000 });
  agent = request.agent(server);
  // fetch adapter: routes the UI's requests into the real express app, with a cookie jar.
  vi.stubGlobal('fetch', async (url, init = {}) => {
    const method = (init.method ?? 'GET').toLowerCase();
    let req = agent[method](url);
    if (init.body) req = req.set('Content-Type', 'application/json').send(init.body);
    const res = await req;
    return {
      ok: res.status >= 200 && res.status < 300,
      status: res.status,
      json: async () => (res.text ? JSON.parse(res.text) : null),
    };
  });
});

const open = (path = '/') =>
  render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
const apiBook = (over = {}) =>
  request(server)
    .post('/api/bookings')
    .send({ tastingId: 'riesling-evening', name: 'Pre Booked', email: 'pre@example.com', guests: 1, ...over });

describe('start page', () => {
  it('lists tastings with date, time, price, seats and a book link', async () => {
    open();
    const cards = await screen.findAllByRole('article');
    expect(cards).toHaveLength(3);
    const first = within(cards[0]);
    expect(first.getByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(first.getByText('2026-11-06 18:00')).toBeInTheDocument();
    expect(first.getByText(/EUR 25/)).toBeInTheDocument();
    expect(first.getByText('12 seats left')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveAttribute('href', '/book/red-wine-cellar-tour');
    expect(screen.getByText('8 seats left')).toBeInTheDocument();
    expect(screen.getByText('10 seats left')).toBeInTheDocument();
  });

  it('marks a fully booked tasting and offers no booking link', async () => {
    await apiBook({ tastingId: 'red-wine-cellar-tour', guests: 8 });
    open();
    await screen.findByText('12 seats left');
    const card = screen.getByRole('heading', { name: 'Red Wine Cellar Tour' }).closest('article');
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(within(card).getByText('0 seats left')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeNull();
    expect(within(card).getByRole('button', { name: 'Book Red Wine Cellar Tour' })).toBeDisabled();
  });

  it('closes booking for a tasting that has already started', async () => {
    server = createApp({ staffPassword: PASSWORD, now: () => new Date('2026-11-10T12:00:00Z') });
    agent = request.agent(server);
    open();
    const card = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('article');
    expect(within(card).getByText('Booking closed')).toBeInTheDocument();
    expect(within(card).getByRole('button', { name: 'Book Riesling Evening' })).toBeDisabled();
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toBeInTheDocument();
  });

  it('shows an error state when tastings cannot be loaded', async () => {
    vi.stubGlobal('fetch', async () => {
      throw new Error('offline');
    });
    open();
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
  });
});

describe('booking flow', () => {
  it('books a tasting and shows the confirmation', async () => {
    const user = userEvent.setup();
    open();
    await user.click(await screen.findByRole('link', { name: 'Book Riesling Evening' }));
    expect(await screen.findByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument();
    await user.type(screen.getByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument();
    expect(screen.getByText('3')).toBeInTheDocument();
    expect(screen.getByText('EUR 75')).toBeInTheDocument();
    expect(screen.getByText(/^KB-[A-Z2-9]{6}$/)).toBeInTheDocument();
    const list = await request(server).get('/api/tastings');
    expect(list.body.tastings[0].seatsLeft).toBe(9);
  });

  it('shows errors next to the fields for an empty submit and does not book', async () => {
    const user = userEvent.setup();
    open('/book/riesling-evening');
    await user.click(await screen.findByRole('button', { name: 'Book' }));
    const name = screen.getByLabelText('Name');
    const email = screen.getByLabelText('Email');
    expect(name).toBeInvalid();
    expect(name).toHaveAccessibleDescription(/enter your name/i);
    expect(email).toHaveAccessibleDescription(/enter your email/i);
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).toBeNull();
  });

  it.each([
    ['Email', 'nope', /valid email/i],
    ['Guests', '9', /at most 8/i],
    ['Guests', '0', /at least 1/i],
  ])('rejects %s = %s with a message on that field', async (label, value, message) => {
    const user = userEvent.setup();
    open('/book/riesling-evening');
    await screen.findByLabelText('Name');
    await user.type(screen.getByLabelText('Name'), 'Anna');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    const field = screen.getByLabelText(label);
    await user.clear(field);
    await user.type(field, value);
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(field).toHaveAccessibleDescription(message);
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).toBeNull();
  });

  it('shows the server error at the Guests field when seats ran out meanwhile', async () => {
    const user = userEvent.setup();
    open('/book/red-wine-cellar-tour');
    await screen.findByLabelText('Name');
    await apiBook({ tastingId: 'red-wine-cellar-tour', guests: 7 }); // someone else books
    await user.type(screen.getByLabelText('Name'), 'Anna');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/only 1 seat is left/i));
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).toBeNull();
  });

  it('refuses guests above the seats left before submitting', async () => {
    const user = userEvent.setup();
    await apiBook({ tastingId: 'red-wine-cellar-tour', guests: 6 });
    open('/book/red-wine-cellar-tour');
    await screen.findByLabelText('Name');
    await user.type(screen.getByLabelText('Name'), 'Anna');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/only 2 seats are left/i);
  });

  it('shows a sold-out notice instead of the form for a fully booked tasting', async () => {
    await apiBook({ tastingId: 'winter-tasting', guests: 8 });
    await apiBook({ tastingId: 'winter-tasting', guests: 2 });
    open('/book/winter-tasting');
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByLabelText('Name')).toBeNull();
  });

  it('handles an unknown tasting', async () => {
    open('/book/unknown');
    expect(await screen.findByText(/could not find/i)).toBeInTheDocument();
  });
});

describe('staff page', () => {
  it('rejects a wrong password with an error at the field', async () => {
    const user = userEvent.setup();
    open('/staff');
    await user.type(await screen.findByLabelText('Password'), 'wrong');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    await waitFor(() => expect(screen.getByLabelText('Password')).toHaveAccessibleDescription(/wrong password/i));
    expect(screen.queryByText('Riesling Evening')).toBeNull();
  });

  it('shows bookings grouped by tasting and cancels one', async () => {
    await apiBook({ name: 'Anna Weber', email: 'anna@example.com', guests: 3 });
    await apiBook({ name: 'Ben Roth', email: 'ben@example.com', guests: 2, tastingId: 'winter-tasting' });
    const user = userEvent.setup();
    open('/staff');
    await user.type(await screen.findByLabelText('Password'), PASSWORD);
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section');
    expect(within(riesling).getByText('Anna Weber')).toBeInTheDocument();
    expect(within(riesling).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(riesling).getByText(/^KB-/)).toBeInTheDocument();
    const winter = screen.getByRole('heading', { name: 'Winter Tasting' }).closest('section');
    expect(within(winter).getByText('Ben Roth')).toBeInTheDocument();
    const red = screen.getByRole('heading', { name: 'Red Wine Cellar Tour' }).closest('section');
    expect(within(red).getByText(/no bookings/i)).toBeInTheDocument();

    await user.click(within(riesling).getByRole('button', { name: 'Cancel' }));
    await waitFor(() => expect(screen.queryByText('Anna Weber')).toBeNull());
    expect(screen.getByText('Ben Roth')).toBeInTheDocument();
    const list = await request(server).get('/api/tastings');
    expect(list.body.tastings[0].seatsLeft).toBe(12);
  });

  it('stays signed in on reload and can sign out', async () => {
    const user = userEvent.setup();
    await agent.post('/api/staff/login').send({ password: PASSWORD });
    open('/staff');
    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });
});
