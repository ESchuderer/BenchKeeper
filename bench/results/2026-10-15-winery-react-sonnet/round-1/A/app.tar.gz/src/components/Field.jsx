import { useId } from 'react';

/** Labelled input with an inline error and optional hint, wired up for screen readers. */
export default function Field({ label, error, hint, register, type = 'text', ...inputProps }) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [error && errorId, hint && hintId].filter(Boolean).join(' ') || undefined;
  return (
    <div className={`field${error ? ' has-error' : ''}`}>
      <label htmlFor={id}>{label}</label>
      <input id={id} type={type} aria-invalid={error ? 'true' : undefined} aria-describedby={describedBy} {...register} {...inputProps} />
      {error && (
        <p className="field-error" id={errorId}>
          <span aria-hidden="true">! </span>
          {error}
        </p>
      )}
      {hint && <p className="field-hint" id={hintId}>{hint}</p>}
    </div>
  );
}
