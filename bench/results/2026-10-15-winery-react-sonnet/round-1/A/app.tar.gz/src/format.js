// startsAt is local winery time ("2026-11-06T18:00:00+01:00"); show its wall-clock values to everyone.
export const formatWhen = (startsAt) => `${startsAt.slice(0, 10)} ${startsAt.slice(11, 16)}`;

export const formatWeekday = (startsAt) =>
  new Date(`${startsAt.slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });

export const formatMoney = (cents) => `EUR ${cents % 100 ? (cents / 100).toFixed(2) : cents / 100}`;

export const seatsLabel = (n) => `${n} seats left`;
