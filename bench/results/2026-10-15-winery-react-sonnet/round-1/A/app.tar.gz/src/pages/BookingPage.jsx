import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { api } from '../api.js';
import { useTastings } from '../useTastings.js';
import Field from '../components/Field.jsx';
import { TastingMeta } from './TastingList.jsx';
import { formatMoney, formatWhen, seatsLabel } from '../format.js';

const MAX_GUESTS = 8;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function Confirmation({ booking, tasting }) {
  const heading = useRef(null);
  useEffect(() => heading.current?.focus(), []);
  return (
    <section className="panel confirmation" aria-labelledby="confirmed">
      <p className="seal" aria-hidden="true">✓</p>
      <h1 id="confirmed" ref={heading} tabIndex={-1}>Booking confirmed</h1>
      <p>Thank you, {booking.name}. We look forward to pouring for you.</p>
      <dl className="summary">
        <div><dt>Tasting</dt><dd>{tasting.title}</dd></div>
        <div><dt>Date and time</dt><dd>{formatWhen(tasting.startsAt)}</dd></div>
        <div><dt>Guests</dt><dd>{booking.guests}</dd></div>
        <div><dt>Total price</dt><dd>{formatMoney(booking.totalCents)}</dd></div>
        <div><dt>Booking reference</dt><dd className="reference">{booking.reference}</dd></div>
      </dl>
      <p className="note">Please keep your reference and mention it at the winery.</p>
      <Link className="btn btn-secondary" to="/">Back to all tastings</Link>
    </section>
  );
}

function BookingForm({ tasting, onBooked, onRefresh }) {
  const {
    register, handleSubmit, setError, watch, formState: { errors, isSubmitting },
  } = useForm({ defaultValues: { name: '', email: '', guests: '' }, shouldFocusError: true });
  const [formError, setFormError] = useState('');
  const guestsValue = Number(watch('guests'));
  const total = Number.isInteger(guestsValue) && guestsValue >= 1 && guestsValue <= MAX_GUESTS ? guestsValue * tasting.priceCents : null;

  const submit = async (values) => {
    setFormError('');
    const res = await api('/api/bookings', {
      method: 'POST',
      body: { tastingId: tasting.id, name: values.name, email: values.email, guests: values.guests },
    });
    if (res.ok) return onBooked(res.data.booking);
    const fieldErrors = res.data?.errors ?? {};
    const known = Object.entries(fieldErrors).filter(([f]) => ['name', 'email', 'guests'].includes(f));
    known.forEach(([field, message]) => setError(field, { type: 'server', message }, { shouldFocus: true }));
    if (known.length === 0) {
      setFormError(res.data?.error ?? 'We could not reach the winery. Please try again.');
    }
    if (res.status === 409) onRefresh();
  };

  return (
    <form className="panel form" onSubmit={handleSubmit(submit)} noValidate>
      <h2>Your details</h2>
      {formError && <div className="alert alert-error" role="alert">{formError}</div>}
      <Field
        label="Name"
        autoComplete="name"
        error={errors.name?.message}
        register={register('name', {
          validate: (v) =>
            !v.trim() ? 'Please enter your name.' : v.trim().length > 100 ? 'Your name is too long (max 100 characters).' : true,
        })}
      />
      <Field
        label="Email"
        type="email"
        autoComplete="email"
        inputMode="email"
        error={errors.email?.message}
        register={register('email', {
          validate: (v) =>
            !v.trim() ? 'Please enter your email address.' : EMAIL.test(v.trim()) ? true : 'Please enter a valid email address, e.g. name@example.com.',
        })}
      />
      <Field
        label="Guests"
        type="number"
        inputMode="numeric"
        min="1"
        max={MAX_GUESTS}
        step="1"
        placeholder="e.g. 2"
        hint={`1 to ${MAX_GUESTS} guests · ${seatsLabel(tasting.seatsLeft)}`}
        error={errors.guests?.message}
        register={register('guests', {
          validate: (v) => {
            const n = Number(v);
            if (String(v).trim() === '' || !Number.isFinite(n)) return `Please enter a number of guests from 1 to ${MAX_GUESTS}.`;
            if (!Number.isInteger(n)) return `Please enter a whole number of guests from 1 to ${MAX_GUESTS}.`;
            if (n < 1) return 'Please book for at least 1 guest.';
            if (n > MAX_GUESTS) return `You can book at most ${MAX_GUESTS} guests at a time.`;
            if (n > tasting.seatsLeft) {
              return `Only ${tasting.seatsLeft} ${tasting.seatsLeft === 1 ? 'seat is' : 'seats are'} left for this tasting.`;
            }
            return true;
          },
        })}
      />
      <p className="total" aria-live="polite">
        Total: <strong>{total === null ? '–' : formatMoney(total)}</strong>
      </p>
      <button type="submit" className="btn" disabled={isSubmitting} aria-busy={isSubmitting}>Book</button>
    </form>
  );
}

export default function BookingPage() {
  const { id } = useParams();
  const { tastings, status, reload } = useTastings();
  const [booked, setBooked] = useState(null);
  const tasting = tastings.find((t) => t.id === id);

  if (booked && tasting) {
    return <Confirmation booking={booked} tasting={tasting} />;
  }
  if (status === 'loading') return <p className="status" role="status">Loading…</p>;
  if (status === 'error') {
    return (
      <div className="alert alert-error" role="alert">
        <p>We could not load this tasting. Please check your connection and try again.</p>
        <button type="button" className="btn btn-small" onClick={reload}>Try again</button>
      </div>
    );
  }
  if (!tasting) {
    return (
      <section className="panel">
        <h1>Tasting not found</h1>
        <p>We could not find that tasting.</p>
        <Link className="btn" to="/">See our tastings</Link>
      </section>
    );
  }
  return (
    <>
      <p><Link to="/" className="back">← All tastings</Link></p>
      <section className="panel intro">
        <p className="eyebrow">Book your seats</p>
        <h1>{tasting.title}</h1>
        <TastingMeta tasting={tasting} />
        <p className={`seats${tasting.seatsLeft <= 0 ? ' seats-low' : ''}`}>{seatsLabel(Math.max(tasting.seatsLeft, 0))}</p>
      </section>
      {tasting.seatsLeft <= 0 || tasting.started ? (
        <div className="alert alert-warn" role="status">
          <p>
            {tasting.seatsLeft <= 0
              ? 'This tasting is fully booked. Please have a look at our other tastings.'
              : 'Booking for this tasting has closed. Please have a look at our other tastings.'}
          </p>
          <Link className="btn btn-small" to="/">Other tastings</Link>
        </div>
      ) : (
        <BookingForm tasting={tasting} onBooked={setBooked} onRefresh={reload} />
      )}
    </>
  );
}
