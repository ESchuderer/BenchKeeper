import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { api } from '../api.js';
import Field from '../components/Field.jsx';
import { formatMoney, formatWhen } from '../format.js';

function SignIn({ onSignedIn }) {
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm({ defaultValues: { password: '' } });
  const submit = async ({ password }) => {
    const res = await api('/api/staff/login', { method: 'POST', body: { password } });
    if (res.ok) return onSignedIn();
    const message =
      res.status === 401 ? 'Wrong password. Please try again.'
      : res.status === 429 ? 'Too many attempts. Please wait a few minutes and try again.'
      : 'Could not sign in right now. Please try again.';
    setError('password', { type: 'server', message }, { shouldFocus: true });
  };
  return (
    <section className="panel narrow">
      <p className="eyebrow">Staff area</p>
      <h1>Staff sign-in</h1>
      <form className="form-plain" onSubmit={handleSubmit(submit)} noValidate>
        <Field
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          register={register('password', { required: 'Please enter the staff password.' })}
        />
        <button type="submit" className="btn" disabled={isSubmitting}>Sign in</button>
      </form>
    </section>
  );
}

function Bookings({ onSignedOut }) {
  const [tastings, setTastings] = useState(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const res = await api('/api/staff/bookings');
    if (res.status === 401) return onSignedOut();
    if (res.ok) {
      setTastings(res.data.tastings);
      setError('');
    } else setError('Could not load the bookings. Please try again.');
  }, [onSignedOut]);
  useEffect(() => {
    load();
  }, [load]);

  const cancel = async (id) => {
    const res = await api(`/api/staff/bookings/${id}`, { method: 'DELETE' });
    if (res.status === 401) return onSignedOut();
    if (!res.ok && res.status !== 404) setError('Could not cancel the booking. Please try again.');
    else await load();
  };
  const signOut = async () => {
    await api('/api/staff/logout', { method: 'POST' });
    onSignedOut();
  };

  return (
    <>
      <div className="staff-head">
        <h1>Bookings</h1>
        <button type="button" className="btn btn-secondary btn-small" onClick={signOut}>Sign out</button>
      </div>
      {error && <div className="alert alert-error" role="alert">{error}</div>}
      {!tastings && !error && <p className="status" role="status">Loading bookings…</p>}
      {tastings?.map((t) => {
        const heading = `heading-${t.id}`;
        return (
          <section className="panel tasting-bookings" key={t.id} aria-labelledby={heading}>
            <div className="card-head">
              <h2 id={heading}>{t.title}</h2>
              <span className={`badge${t.seatsLeft <= 0 ? ' badge-full' : ''}`}>
                {t.seats - t.seatsLeft} of {t.seats} seats booked
              </span>
            </div>
            <p className="when">{formatWhen(t.startsAt)}</p>
            {t.bookings.length === 0 ? (
              <p className="empty">No bookings yet.</p>
            ) : (
              <table className="bookings">
                <thead>
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Guests</th>
                    <th scope="col">Total</th>
                    <th scope="col">Reference</th>
                    <th scope="col"><span className="sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody>
                  {t.bookings.map((b) => (
                    <tr key={b.id}>
                      <td data-label="Name" id={`name-${b.id}`}>{b.name}</td>
                      <td data-label="Email">{b.email}</td>
                      <td data-label="Guests">{b.guests}</td>
                      <td data-label="Total">{formatMoney(b.totalCents)}</td>
                      <td data-label="Reference" className="reference">{b.reference}</td>
                      <td className="actions">
                        <button type="button" className="btn btn-danger btn-small" aria-describedby={`name-${b.id}`} onClick={() => cancel(b.id)}>
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        );
      })}
    </>
  );
}

export default function StaffPage() {
  const [signedIn, setSignedIn] = useState(null); // null = checking
  useEffect(() => {
    api('/api/staff/session').then((res) => setSignedIn(Boolean(res.data?.signedIn)));
  }, []);
  const out = useCallback(() => setSignedIn(false), []);
  if (signedIn === null) return <p className="status" role="status">Loading…</p>;
  return signedIn ? <Bookings onSignedOut={out} /> : <SignIn onSignedIn={() => setSignedIn(true)} />;
}
