import { Link } from 'react-router-dom';
import { useTastings } from '../useTastings.js';
import { formatMoney, formatWeekday, formatWhen, seatsLabel } from '../format.js';

export function TastingMeta({ tasting }) {
  return (
    <dl className="meta">
      <div>
        <dt>When</dt>
        <dd>
          <time dateTime={tasting.startsAt}>{formatWhen(tasting.startsAt)}</time>
          <span className="weekday">{formatWeekday(tasting.startsAt)}</span>
        </dd>
      </div>
      <div>
        <dt>Price</dt>
        <dd>{formatMoney(tasting.priceCents)} <span className="weekday">per guest</span></dd>
      </div>
    </dl>
  );
}

function TastingCard({ tasting }) {
  const soldOut = tasting.seatsLeft <= 0;
  const closed = soldOut || tasting.started;
  const label = `Book ${tasting.title}`;
  return (
    <article className={`card${closed ? ' sold-out' : ''}`}>
      <div className="card-head">
        <h2>{tasting.title}</h2>
        {soldOut ? (
          <span className="badge badge-full">Fully booked</span>
        ) : (
          tasting.started && <span className="badge badge-full">Booking closed</span>
        )}
      </div>
      <TastingMeta tasting={tasting} />
      <p className={`seats${tasting.seatsLeft > 0 && tasting.seatsLeft <= 3 ? ' seats-low' : ''}`}>
        {seatsLabel(Math.max(tasting.seatsLeft, 0))}
      </p>
      {closed ? (
        <button type="button" className="btn" disabled>{label}</button>
      ) : (
        <Link className="btn" to={`/book/${tasting.id}`}>{label}</Link>
      )}
    </article>
  );
}

export default function TastingList() {
  const { tastings, status, reload } = useTastings();
  return (
    <>
      <section className="hero">
        <p className="eyebrow">Autumn &amp; winter 2026</p>
        <h1>Wine tastings at the Kieselbrunnen</h1>
        <p>
          Join us in our cellar and at our long oak table. We pour our own wines, tell the story behind each
          bottle and keep the groups small.
        </p>
      </section>
      {status === 'loading' && <p className="status" role="status">Loading tastings…</p>}
      {status === 'error' && (
        <div className="alert alert-error" role="alert">
          <p>We could not load the tastings. Please check your connection and try again.</p>
          <button type="button" className="btn btn-small" onClick={reload}>Try again</button>
        </div>
      )}
      {status === 'ready' && (
        <div className="grid">
          {tastings.map((t) => <TastingCard key={t.id} tasting={t} />)}
        </div>
      )}
    </>
  );
}
