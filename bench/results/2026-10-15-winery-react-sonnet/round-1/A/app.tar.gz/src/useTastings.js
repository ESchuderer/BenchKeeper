import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';

/** Loads the public tasting list: { tastings, status: 'loading' | 'ready' | 'error', reload }. */
export function useTastings() {
  const [state, setState] = useState({ tastings: [], status: 'loading' });
  const load = useCallback(async () => {
    const res = await api('/api/tastings');
    setState(res.ok ? { tastings: res.data.tastings, status: 'ready' } : { tastings: [], status: 'error' });
  }, []);
  useEffect(() => {
    load();
  }, [load]);
  return { ...state, reload: load };
}
