import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { proxy: { '/api': 'http://localhost:3000' } },
  test: { setupFiles: ['./src/test-setup.js'], include: ['server/**/*.test.js', 'src/**/*.test.{js,jsx}'] },
});
