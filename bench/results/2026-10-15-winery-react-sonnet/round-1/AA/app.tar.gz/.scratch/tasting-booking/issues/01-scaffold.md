# 01: Walking skeleton

**What to build:** A deployable shell: `npm install`, `npm run build`, `npm start` serve a branded page on PORT; Vitest and Playwright run.

**Blocked by:** None (can start immediately)

**Status:** ready-for-agent

- [x] Build + start serves the page on PORT (default 3000)
- [x] Typecheck, unit and e2e commands exist and pass
- [x] Layout is readable at 375px
