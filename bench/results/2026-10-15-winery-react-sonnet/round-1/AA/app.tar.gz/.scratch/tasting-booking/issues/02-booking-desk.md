# 02: Booking desk domain module

**What to build:** Seeded Tastings and a BookingDesk that validates, takes Seats atomically, cancels and groups Bookings.

**Blocked by:** 01

**Status:** ready-for-agent

- [x] Three Tastings with 12/8/10 seats
- [x] Each invalid field yields a per-field error and no state change
- [x] Cannot exceed seats left; last seats bookable; tastings independent
- [x] References unique; cancel frees seats and is idempotent
