# 03: Guests see Tastings and open a booking form

**What to build:** Start page with Tasting cards (title, date and time, price, '<n> seats left', Fully booked state) and 'Book <title>' links opening the form; submitting invalid input shows errors next to fields with entries kept.

**Blocked by:** 02

**Status:** ready-for-agent

- [x] Start page content as specified
- [x] Form fields Name, Email, Guests, button Book
- [x] Field errors incl. seats left error next to Guests
