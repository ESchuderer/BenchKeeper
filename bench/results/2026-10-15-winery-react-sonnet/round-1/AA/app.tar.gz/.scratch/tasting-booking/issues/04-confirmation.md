# 04: Booking confirmation

**What to build:** Valid submission redirects to a confirmation: heading 'Booking confirmed', tasting, guests, total price, reference; start page seats left drop.

**Blocked by:** 03

**Status:** ready-for-agent

- [x] Confirmation content correct (3 x EUR 28 = EUR 84)
- [x] Seats left reduced on start page
