# 05: Staff sign-in

**What to build:** /staff asks for Password, 'Sign in'; password from STAFF_PASSWORD; session cookie; unset or empty never signs in.

**Blocked by:** 01

**Status:** ready-for-agent

- [x] Wrong password: error next to field
- [x] Correct password: signed in across visits
- [x] Unset STAFF_PASSWORD: nobody can sign in
