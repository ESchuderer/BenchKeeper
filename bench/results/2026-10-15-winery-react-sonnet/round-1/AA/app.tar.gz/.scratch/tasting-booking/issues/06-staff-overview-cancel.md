# 06: Staff overview and cancel

**What to build:** Signed-in staff see Bookings grouped by Tasting (name, email, guests, reference) and cancel with 'Cancel', freeing seats; cancel requires sign-in.

**Blocked by:** 02, 05

**Status:** ready-for-agent

- [x] Grouped list incl. empty groups
- [x] Cancel frees seats on start page
- [x] Cancel without session does nothing
