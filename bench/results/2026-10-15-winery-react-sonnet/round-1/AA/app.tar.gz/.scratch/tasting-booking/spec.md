# Tasting booking for Weingut Kieselbrunnen

Source of truth for requirements, design and task list is the OpenSpec change `openspec/changes/add-tasting-booking/` (proposal, specs, design, tasks). Vocabulary: `GLOSSARY.md`.

Summary: guests list Tastings and book Seats online (never overbooked, validation next to each field, confirmation with Booking reference); staff sign in at `/staff` with `STAFF_PASSWORD`, see Bookings grouped by Tasting and cancel them to free Seats. React Router + Tailwind, in-memory Bookings, `npm start` on `PORT`.

Tickets: `issues/01..06`.
