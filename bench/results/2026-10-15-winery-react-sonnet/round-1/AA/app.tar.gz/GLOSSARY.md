# Weingut Kieselbrunnen Tastings

A family winery's online booking of wine tastings for guests, and a back office where staff see and cancel those bookings.

## Language

**Tasting**:
A single scheduled wine event with a title, a date and time, a price per guest and a fixed capacity.
_Avoid_: Event, tour, course, product

**Seats**:
The fixed capacity of a Tasting: how many guests it can host in total.
_Avoid_: Capacity, spots, tickets, places

**Seats left**:
The Seats of a Tasting minus the guests on all of its active Bookings.
_Avoid_: Availability, remaining capacity

**Fully booked**:
A Tasting with no Seats left.
_Avoid_: Sold out, full

**Guest**:
A person attending a Tasting. A Booking covers one or more Guests.
_Avoid_: Attendee, participant, visitor

**Booker**:
The person who makes a Booking and leaves their name and email; one of the Guests unless stated otherwise.
_Avoid_: Customer, user, client

**Booking**:
A Booker's claim on a number of Seats at one Tasting. It holds its Seats until it is cancelled.
_Avoid_: Reservation, order, ticket

**Booking reference**:
The short code that identifies one Booking to the Booker and to staff.
_Avoid_: Booking ID, confirmation number, ticket number

**Total price**:
The price per guest of the Tasting multiplied by the number of Guests in the Booking.
_Avoid_: Amount, cost, fee

**Cancellation**:
Staff ending a Booking so that its Seats become free again; the Booking then no longer appears anywhere.
_Avoid_: Deletion, refund

**Staff**:
The winery's own people who sign in with the shared staff password to see and cancel Bookings.
_Avoid_: Admin, owner, employee
