# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff see and cancel the bookings.
React Router (server-rendered React), Tailwind CSS, Zod. Node.js 22.

## Run

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start   # serves on $PORT (default 3000)
```

| Variable         | Meaning                                                                   |
| ---------------- | ------------------------------------------------------------------------- |
| `PORT`           | Port to listen on. Default `3000`.                                        |
| `STAFF_PASSWORD` | Password for `/staff`. If unset or empty, nobody can sign in to `/staff`. |

Bookings are kept in memory: the app starts with none and a restart clears them. Run a single
process; the seat check relies on it.

## Pages

- `/` the tastings, with seats left
- `/book/:slug` booking form for one tasting
- `/bookings/:reference` confirmation
- `/staff` staff sign-in, bookings grouped by tasting, cancel

## Develop and test

```sh
npm run dev         # dev server with hot reload
npm run typecheck
npm test            # unit tests of the booking rules (Vitest)
npx playwright install chromium   # once
npm run test:e2e    # builds, starts the app, drives it in a browser (desktop and phone)
```

Domain vocabulary: `GLOSSARY.md`. Requirements, design and task list: `openspec/changes/add-tasting-booking/`.

## Decisions worth knowing

- The tastings are fixed data in `app/domain/tastings.ts`. Past tastings stay bookable.
- All seat and validation rules live in `app/domain/booking-desk.ts`.
- Seats left reads "<n> seats left" for every n, as specified (so "1 seats left").
- Staff sign-in uses a signed `httpOnly` cookie (8 hours); there is no rate limiting on password attempts.
- Booking confirmations are not emailed.
