import { Link } from "react-router";

function VineMark() {
  return (
    <svg width="34" height="34" viewBox="0 0 34 34" aria-hidden="true" focusable="false">
      <circle cx="17" cy="17" r="16" fill="#6d1f33" />
      <g fill="#faf6ee">
        <circle cx="12.5" cy="17" r="2.6" />
        <circle cx="17" cy="17" r="2.6" />
        <circle cx="21.5" cy="17" r="2.6" />
        <circle cx="14.7" cy="21.2" r="2.6" />
        <circle cx="19.3" cy="21.2" r="2.6" />
        <circle cx="17" cy="25.4" r="2.6" />
      </g>
      <path d="M17 14c0-3 1.6-5 4.6-5.6C21.4 11.4 19.8 13.4 17 14Z" fill="#c9a24a" />
    </svg>
  );
}

export function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="site-header">
        <div className="container-page flex items-center justify-between gap-4 py-4">
          <Link to="/" className="brand">
            <VineMark />
            <span>
              <span className="brand-name">Weingut Kieselbrunnen</span>
              <span className="brand-sub">Family winery</span>
            </span>
          </Link>
          <nav aria-label="Main">
            <Link to="/" className="text-link text-sm font-semibold no-underline sm:text-base">
              Tastings
            </Link>
          </nav>
        </div>
      </header>
      <div className="flex-1">{children}</div>
      <footer className="site-footer">
        <div className="container-page flex flex-wrap items-center justify-between gap-3 py-6">
          <p>Weingut Kieselbrunnen &middot; Family winery</p>
          <Link to="/staff">Staff sign-in</Link>
        </div>
      </footer>
    </div>
  );
}
