import { describe, expect, it } from "vitest";
import { createBookingDesk } from "./booking-desk";

const valid = { name: "Anna Weber", email: "anna@example.com", guests: "2" };

function seatsLeft(desk: ReturnType<typeof createBookingDesk>, slug: string) {
  return desk.getTasting(slug)?.seatsLeft;
}

describe("tastings on offer", () => {
  it("lists the three tastings with full seats on a fresh desk", () => {
    const desk = createBookingDesk();
    expect(
      desk.listTastings().map((t) => [t.title, t.startsAt, t.pricePerGuest, t.seatsLeft]),
    ).toEqual([
      ["Riesling Evening", "2026-11-06T18:00", 25, 12],
      ["Red Wine Cellar Tour", "2026-11-14T15:00", 32, 8],
      ["Winter Tasting", "2026-12-05T17:00", 28, 10],
    ]);
  });

  it("finds a tasting by its slug and returns undefined for an unknown one", () => {
    const desk = createBookingDesk();
    expect(desk.getTasting("winter-tasting")?.title).toBe("Winter Tasting");
    expect(desk.getTasting("nope")).toBeUndefined();
  });
});

describe("booking", () => {
  it("confirms a valid booking with total price and reference, and takes the seats", () => {
    const desk = createBookingDesk();
    const result = desk.book("winter-tasting", { ...valid, guests: "3" });
    if (!result.ok) throw new Error("expected a confirmed booking");
    expect(result.booking).toMatchObject({
      tastingSlug: "winter-tasting",
      name: "Anna Weber",
      email: "anna@example.com",
      guests: 3,
      totalPrice: 84,
    });
    expect(result.booking.reference).toMatch(/^KB-[A-Z2-9]{6}$/);
    expect(seatsLeft(desk, "winter-tasting")).toBe(7);
    expect(desk.getBooking(result.booking.reference)).toEqual(result.booking);
  });

  it("trims name and email", () => {
    const desk = createBookingDesk();
    const result = desk.book("riesling-evening", {
      name: "  Anna Weber ",
      email: " anna@example.com ",
      guests: "1",
    });
    if (!result.ok) throw new Error("expected a confirmed booking");
    expect(result.booking.name).toBe("Anna Weber");
    expect(result.booking.email).toBe("anna@example.com");
  });

  it("accepts guests typed with surrounding spaces or leading zeros", () => {
    const desk = createBookingDesk();
    const result = desk.book("riesling-evening", { ...valid, guests: " 03 " });
    if (!result.ok) throw new Error("expected a confirmed booking");
    expect(result.booking.guests).toBe(3);
  });

  it("rejects an unknown tasting", () => {
    const desk = createBookingDesk();
    expect(desk.book("nope", valid)).toEqual({ ok: false, reason: "unknown-tasting" });
  });

  it.each([
    ["blank name", { name: "   " }, "name"],
    ["missing name", { name: undefined }, "name"],
    ["name that is too long", { name: "x".repeat(101) }, "name"],
    ["blank email", { email: "" }, "email"],
    ["email without @", { email: "anna.example.com" }, "email"],
    ["email without domain dot", { email: "anna@example" }, "email"],
    ["email with spaces", { email: "an na@example.com" }, "email"],
    ["email that is too long", { email: `${"a".repeat(250)}@example.com` }, "email"],
    ["blank guests", { guests: "" }, "guests"],
    ["zero guests", { guests: "0" }, "guests"],
    ["negative guests", { guests: "-1" }, "guests"],
    ["nine guests", { guests: "9" }, "guests"],
    ["fractional guests", { guests: "2.5" }, "guests"],
    ["text guests", { guests: "two" }, "guests"],
    ["exponent guests", { guests: "1e0" }, "guests"],
  ])("rejects %s with an error on that field only and books nothing", (_label, change, field) => {
    const desk = createBookingDesk();
    const result = desk.book("riesling-evening", { ...valid, ...change });
    if (result.ok || result.reason !== "invalid") throw new Error("expected invalid input");
    expect(Object.keys(result.errors)).toEqual([field]);
    expect(result.errors[field as "name" | "email" | "guests"]).toBeTruthy();
    expect(seatsLeft(desk, "riesling-evening")).toBe(12);
    expect(desk.bookingsByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });

  it("reports every invalid field at once", () => {
    const desk = createBookingDesk();
    const result = desk.book("riesling-evening", { name: "", email: "x", guests: "0" });
    if (result.ok || result.reason !== "invalid") throw new Error("expected invalid input");
    expect(Object.keys(result.errors).sort()).toEqual(["email", "guests", "name"]);
  });
});

describe("seat limit", () => {
  it("rejects more guests than seats left and names how many are left", () => {
    const desk = createBookingDesk();
    desk.book("red-wine-cellar-tour", { ...valid, guests: "5" }); // 3 left
    const result = desk.book("red-wine-cellar-tour", { ...valid, guests: "4" });
    if (result.ok || result.reason !== "invalid") throw new Error("expected a rejection");
    expect(result.errors.guests).toContain("3");
    expect(seatsLeft(desk, "red-wine-cellar-tour")).toBe(3);
  });

  it("accepts exactly the seats left and then reports the tasting fully booked", () => {
    const desk = createBookingDesk();
    desk.book("red-wine-cellar-tour", { ...valid, guests: "5" });
    expect(desk.book("red-wine-cellar-tour", { ...valid, guests: "3" }).ok).toBe(true);
    const tasting = desk.getTasting("red-wine-cellar-tour");
    expect(tasting?.seatsLeft).toBe(0);
    expect(tasting?.fullyBooked).toBe(true);
  });

  it("rejects any booking on a fully booked tasting", () => {
    const desk = createBookingDesk();
    desk.book("red-wine-cellar-tour", { ...valid, guests: "8" });
    const result = desk.book("red-wine-cellar-tour", { ...valid, guests: "1" });
    if (result.ok || result.reason !== "invalid") throw new Error("expected a rejection");
    expect(result.errors.guests).toBeTruthy();
    expect(seatsLeft(desk, "red-wine-cellar-tour")).toBe(0);
  });

  it("never lets total guests exceed the seats, however bookings are sliced", () => {
    const desk = createBookingDesk();
    let booked = 0;
    for (let i = 0; i < 20; i++) {
      const result = desk.book("riesling-evening", { ...valid, guests: String((i % 4) + 1) });
      if (result.ok) booked += result.booking.guests;
    }
    expect(booked).toBeLessThanOrEqual(12);
    expect(seatsLeft(desk, "riesling-evening")).toBe(12 - booked);
  });

  it("keeps seats of different tastings apart", () => {
    const desk = createBookingDesk();
    desk.book("riesling-evening", { ...valid, guests: "4" });
    expect(seatsLeft(desk, "riesling-evening")).toBe(8);
    expect(seatsLeft(desk, "red-wine-cellar-tour")).toBe(8);
    expect(seatsLeft(desk, "winter-tasting")).toBe(10);
  });
});

describe("booking references", () => {
  it("are unique even if the generator repeats itself", () => {
    const drawn = ["KB-AAAAAA", "KB-AAAAAA", "KB-BBBBBB"];
    const desk = createBookingDesk({ newReference: () => drawn.shift() ?? "KB-CCCCCC" });
    const first = desk.book("riesling-evening", valid);
    const second = desk.book("riesling-evening", valid);
    if (!first.ok || !second.ok) throw new Error("expected confirmed bookings");
    expect([first.booking.reference, second.booking.reference]).toEqual(["KB-AAAAAA", "KB-BBBBBB"]);
  });

  it("are never issued again, not even after the booking was cancelled", () => {
    const drawn = ["KB-AAAAAA", "KB-AAAAAA", "KB-BBBBBB"];
    const desk = createBookingDesk({ newReference: () => drawn.shift() ?? "KB-CCCCCC" });
    const first = desk.book("riesling-evening", valid);
    if (!first.ok) throw new Error("expected a confirmed booking");
    desk.cancel(first.booking.reference);
    const second = desk.book("riesling-evening", valid);
    if (!second.ok) throw new Error("expected a confirmed booking");
    expect(second.booking.reference).toBe("KB-BBBBBB");
  });

  it("are not found when unknown", () => {
    expect(createBookingDesk().getBooking("KB-ZZZZZZ")).toBeUndefined();
  });
});

describe("staff overview and cancellation", () => {
  it("groups bookings by tasting, in tasting order, including empty tastings", () => {
    const desk = createBookingDesk();
    desk.book("winter-tasting", { ...valid, name: "Carl", guests: "1" });
    desk.book("riesling-evening", { ...valid, name: "Anna", guests: "2" });
    desk.book("riesling-evening", { ...valid, name: "Ben", guests: "3" });
    const groups = desk.bookingsByTasting();
    expect(groups.map((g) => [g.tasting.title, g.bookings.map((b) => b.name)])).toEqual([
      ["Riesling Evening", ["Anna", "Ben"]],
      ["Red Wine Cellar Tour", []],
      ["Winter Tasting", ["Carl"]],
    ]);
  });

  it("frees the seats of a cancelled booking and removes it from the overview", () => {
    const desk = createBookingDesk();
    const result = desk.book("red-wine-cellar-tour", { ...valid, guests: "4" });
    if (!result.ok) throw new Error("expected a confirmed booking");
    expect(seatsLeft(desk, "red-wine-cellar-tour")).toBe(4);
    expect(desk.cancel(result.booking.reference)).toBe(true);
    expect(seatsLeft(desk, "red-wine-cellar-tour")).toBe(8);
    expect(desk.bookingsByTasting()[1].bookings).toEqual([]);
    expect(desk.getBooking(result.booking.reference)).toBeUndefined();
  });

  it("lets the freed seats be booked again", () => {
    const desk = createBookingDesk();
    const full = desk.book("red-wine-cellar-tour", { ...valid, guests: "8" });
    if (!full.ok) throw new Error("expected a confirmed booking");
    desk.cancel(full.booking.reference);
    expect(desk.book("red-wine-cellar-tour", { ...valid, guests: "8" }).ok).toBe(true);
  });

  it("frees seats only once when cancelled twice, and ignores unknown references", () => {
    const desk = createBookingDesk();
    const kept = desk.book("riesling-evening", { ...valid, guests: "2" });
    const gone = desk.book("riesling-evening", { ...valid, guests: "3" });
    if (!kept.ok || !gone.ok) throw new Error("expected confirmed bookings");
    expect(desk.cancel(gone.booking.reference)).toBe(true);
    expect(desk.cancel(gone.booking.reference)).toBe(false);
    expect(desk.cancel("KB-ZZZZZZ")).toBe(false);
    expect(seatsLeft(desk, "riesling-evening")).toBe(10);
  });
});
