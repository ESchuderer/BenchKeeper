import { randomInt } from "node:crypto";
import { z } from "zod";
import { type Tasting, tastings as seededTastings } from "./tastings";

export const MAX_GUESTS_PER_BOOKING = 8;

export type TastingView = Tasting & { seatsLeft: number; fullyBooked: boolean };

export type Booking = {
  reference: string;
  tastingSlug: string;
  name: string;
  email: string;
  guests: number;
  /** Whole EUR. */
  totalPrice: number;
};

/** Raw form values: anything a browser may send, including nothing. */
export type BookingInput = { name?: unknown; email?: unknown; guests?: unknown };

export type BookingField = "name" | "email" | "guests";
export type FieldErrors = Partial<Record<BookingField, string>>;

export type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: "invalid"; errors: FieldErrors }
  | { ok: false; reason: "unknown-tasting" };

export type BookingDesk = ReturnType<typeof createBookingDesk>;

const GUESTS_MESSAGE = `Please enter a whole number from 1 to ${MAX_GUESTS_PER_BOOKING}.`;

const bookingSchema = z.object({
  name: z
    .string({ error: "Please enter your name." })
    .trim()
    .min(1, "Please enter your name.")
    .max(100, "Please use at most 100 characters."),
  email: z
    .string({ error: "Please enter your email address." })
    .trim()
    .min(1, "Please enter your email address.")
    .max(254, "That email address is too long.")
    .pipe(z.email("Please enter a valid email address, like name@example.com.")),
  guests: z
    .string({ error: "Please choose how many guests are coming." })
    .trim()
    .regex(/^\d{1,3}$/, GUESTS_MESSAGE)
    .transform(Number)
    .pipe(z.number().min(1, GUESTS_MESSAGE).max(MAX_GUESTS_PER_BOOKING, GUESTS_MESSAGE)),
});

// No 0/O and 1/I, so a reference read out over the phone is not ambiguous.
const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomReference(): string {
  let code = "";
  for (let i = 0; i < 6; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  return `KB-${code}`;
}

function seatsLeftMessage(seatsLeft: number): string {
  return seatsLeft === 0
    ? "This tasting is fully booked."
    : `Only ${seatsLeft} ${seatsLeft === 1 ? "seat is" : "seats are"} left for this tasting.`;
}

/**
 * Owns every rule about tastings, seats and bookings. All state lives in the
 * instance. `book` checks the seats and takes them in one synchronous step, so
 * simultaneous requests on one Node process can never overbook a tasting.
 */
export function createBookingDesk({
  newReference = randomReference,
}: { newReference?: () => string } = {}) {
  const tastings = seededTastings;
  const active = new Map<string, Booking>();
  // Every reference ever issued, so a cancelled booking's reference is never handed out again.
  const issued = new Set<string>();

  const findTasting = (slug: string) => tastings.find((t) => t.slug === slug);

  const seatsTaken = (slug: string) =>
    [...active.values()].reduce((sum, b) => (b.tastingSlug === slug ? sum + b.guests : sum), 0);

  const view = (tasting: Tasting): TastingView => {
    const seatsLeft = tasting.seats - seatsTaken(tasting.slug);
    return { ...tasting, seatsLeft, fullyBooked: seatsLeft === 0 };
  };

  const freshReference = () => {
    let reference = newReference();
    while (issued.has(reference)) reference = newReference();
    issued.add(reference);
    return reference;
  };

  return {
    listTastings: (): TastingView[] => tastings.map(view),

    getTasting(slug: string): TastingView | undefined {
      const tasting = findTasting(slug);
      return tasting && view(tasting);
    },

    book(slug: string, input: BookingInput): BookResult {
      const tasting = findTasting(slug);
      if (!tasting) return { ok: false, reason: "unknown-tasting" };

      const parsed = bookingSchema.safeParse(input);
      if (!parsed.success) {
        const errors: FieldErrors = {};
        for (const issue of parsed.error.issues) {
          const field = issue.path[0] as BookingField;
          errors[field] ??= issue.message;
        }
        return { ok: false, reason: "invalid", errors };
      }

      const { name, email, guests } = parsed.data;
      const { seatsLeft } = view(tasting);
      if (guests > seatsLeft) {
        return { ok: false, reason: "invalid", errors: { guests: seatsLeftMessage(seatsLeft) } };
      }

      const booking: Booking = {
        reference: freshReference(),
        tastingSlug: slug,
        name,
        email,
        guests,
        totalPrice: guests * tasting.pricePerGuest,
      };
      active.set(booking.reference, booking);
      return { ok: true, booking };
    },

    getBooking: (reference: string): Booking | undefined => active.get(reference),

    bookingsByTasting: () =>
      tastings.map((tasting) => ({
        tasting: view(tasting),
        bookings: [...active.values()].filter((b) => b.tastingSlug === tasting.slug),
      })),

    /** Returns false when there is no active booking with that reference. */
    cancel: (reference: string): boolean => active.delete(reference),
  };
}
