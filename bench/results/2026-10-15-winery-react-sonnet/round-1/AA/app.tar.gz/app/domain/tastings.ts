export type Tasting = {
  slug: string;
  title: string;
  /** Local wall-clock start, `YYYY-MM-DDTHH:mm`, no time zone. */
  startsAt: string;
  /** Whole EUR per guest. */
  pricePerGuest: number;
  seats: number;
};

export const tastings: readonly Tasting[] = [
  {
    slug: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00",
    pricePerGuest: 25,
    seats: 12,
  },
  {
    slug: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00",
    pricePerGuest: 32,
    seats: 8,
  },
  {
    slug: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00",
    pricePerGuest: 28,
    seats: 10,
  },
];
