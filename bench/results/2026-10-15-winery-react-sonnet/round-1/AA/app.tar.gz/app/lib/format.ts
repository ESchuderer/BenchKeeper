const dateFormat = new Intl.DateTimeFormat("en-GB", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
  timeZone: "UTC",
});

/** `2026-11-06T18:00` -> "Friday 6 November 2026". The time is wall-clock, never converted. */
export function formatDate(startsAt: string): string {
  return dateFormat.format(new Date(`${startsAt}:00Z`)).replace(",", "");
}

/** `2026-11-06T18:00` -> "18:00" */
export function formatTime(startsAt: string): string {
  return startsAt.slice(11, 16);
}

export function formatEur(amount: number): string {
  return `EUR ${amount}`;
}

export function guestsLabel(count: number): string {
  return `${count} ${count === 1 ? "guest" : "guests"}`;
}

/** The format the winery asked for: "<n> seats left". */
export function seatsLeftLabel(seatsLeft: number): string {
  return `${seatsLeft} seats left`;
}
