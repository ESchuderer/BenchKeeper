import {
  isRouteErrorResponse,
  Link,
  Links,
  Meta,
  Outlet,
  Scripts,
  ScrollRestoration,
} from "react-router";

import type { Route } from "./+types/root";
import "./app.css";
import { SiteLayout } from "./components/site-layout";

export const meta: Route.MetaFunction = () => [
  { title: "Wine tastings | Weingut Kieselbrunnen" },
  {
    name: "description",
    content: "Book a wine tasting at Weingut Kieselbrunnen, a family winery.",
  },
  { name: "theme-color", content: "#6d1f33" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <Meta />
        <Links />
      </head>
      <body>
        {children}
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  );
}

export default function App() {
  return (
    <SiteLayout>
      <Outlet />
    </SiteLayout>
  );
}

export function ErrorBoundary({ error }: Route.ErrorBoundaryProps) {
  const notFound = isRouteErrorResponse(error) && error.status === 404;
  return (
    <SiteLayout>
      <main className="container-page max-w-2xl py-16">
        <p className="eyebrow">{notFound ? "404" : "Error"}</p>
        <h1 className="page-title mt-2">
          {notFound ? "We could not find that page" : "Something went wrong"}
        </h1>
        <p className="lead">
          {notFound
            ? "The tasting or booking you are looking for does not exist."
            : "Please try again in a moment."}
        </p>
        <p className="mt-6">
          <Link to="/" className="btn">
            See all tastings
          </Link>
        </p>
      </main>
    </SiteLayout>
  );
}
