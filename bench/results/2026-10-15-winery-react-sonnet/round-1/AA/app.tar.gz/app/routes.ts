import { type RouteConfig, index, route } from "@react-router/dev/routes";

export default [
  index("routes/home.tsx"),
  route("book/:slug", "routes/book.tsx"),
  route("bookings/:reference", "routes/booking.tsx"),
  route("staff", "routes/staff.tsx"),
] satisfies RouteConfig;
