import { useEffect, useRef } from "react";
import { data, Form, Link, redirect, useNavigation } from "react-router";
import type { Route } from "./+types/book";
import { Field } from "~/components/field";
import { MAX_GUESTS_PER_BOOKING } from "~/domain/booking-desk";
import { formatDate, formatEur, formatTime, seatsLeftLabel } from "~/lib/format";
import { desk } from "~/server/desk.server";

export function loader({ params }: Route.LoaderArgs) {
  const tasting = desk.getTasting(params.slug);
  if (!tasting) throw data("Tasting not found", { status: 404 });
  return { tasting };
}

export async function action({ params, request }: Route.ActionArgs) {
  const form = await request.formData();
  const text = (value: FormDataEntryValue | null) => (typeof value === "string" ? value : "");
  const values = {
    name: text(form.get("name")),
    email: text(form.get("email")),
    guests: text(form.get("guests")),
  };

  const result = desk.book(params.slug, values);
  if (result.ok) return redirect(`/bookings/${result.booking.reference}`);
  if (result.reason === "unknown-tasting") throw data("Tasting not found", { status: 404 });
  return data({ errors: result.errors, values }, { status: 400 });
}

export const meta: Route.MetaFunction = ({ loaderData }) => [
  { title: `${loaderData?.tasting.title ?? "Booking"} | Weingut Kieselbrunnen` },
];

export default function Book({ loaderData, actionData }: Route.ComponentProps) {
  const { tasting } = loaderData;
  const errors = actionData?.errors ?? {};
  const values = actionData?.values;
  const submitting = useNavigation().state === "submitting";
  const formRef = useRef<HTMLFormElement>(null);

  // After a rejected submission, move focus to the first field with an error.
  useEffect(() => {
    if (actionData?.errors) {
      formRef.current?.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus();
    }
  }, [actionData]);

  return (
    <main className="container-page max-w-2xl pt-10 sm:pt-14">
      <Link to="/" className="text-link text-sm">
        &larr; All tastings
      </Link>

      <p className="eyebrow mt-6">Book a tasting</p>
      <h1 className="page-title mt-2">{tasting.title}</h1>
      <p className="mt-3 text-lg text-ink-soft">
        <time dateTime={tasting.startsAt}>
          {formatDate(tasting.startsAt)}, {formatTime(tasting.startsAt)}
        </time>{" "}
        &middot; {formatEur(tasting.pricePerGuest)} per guest &middot;{" "}
        <span className="font-semibold">{seatsLeftLabel(tasting.seatsLeft)}</span>
      </p>

      {tasting.fullyBooked && (
        <p role="status" className="notice notice-fully-booked mt-6">
          <strong>This tasting is fully booked.</strong> All seats are taken, so a new booking
          cannot be made. Please have a look at our other tastings.
        </p>
      )}

      <Form method="post" noValidate ref={formRef} className="form-card mt-8 flex flex-col gap-6">
        <Field
          label="Name"
          name="name"
          type="text"
          autoComplete="name"
          required
          defaultValue={values?.name}
          error={errors.name}
        />
        <Field
          label="Email"
          name="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          required
          defaultValue={values?.email}
          error={errors.email}
        />
        <Field
          label="Guests"
          name="guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={MAX_GUESTS_PER_BOOKING}
          step={1}
          required
          hint={`Between 1 and ${MAX_GUESTS_PER_BOOKING} guests per booking.`}
          defaultValue={values?.guests}
          error={errors.guests}
        />
        <button
          type="submit"
          className={`btn w-full sm:w-auto sm:self-start ${tasting.fullyBooked ? "btn-outline-muted" : ""}`}
          disabled={submitting}
          aria-busy={submitting}
        >
          Book
        </button>
      </Form>
    </main>
  );
}
