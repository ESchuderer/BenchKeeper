import { data, Link } from "react-router";
import type { Route } from "./+types/booking";
import { formatDate, formatEur, formatTime, guestsLabel } from "~/lib/format";
import { desk } from "~/server/desk.server";

export function loader({ params }: Route.LoaderArgs) {
  const booking = desk.getBooking(params.reference);
  const tasting = booking && desk.getTasting(booking.tastingSlug);
  if (!booking || !tasting) throw data("Booking not found", { status: 404 });
  return { booking, tasting };
}

export const meta: Route.MetaFunction = () => [
  { title: "Booking confirmed | Weingut Kieselbrunnen" },
];

export default function BookingConfirmed({ loaderData }: Route.ComponentProps) {
  const { booking, tasting } = loaderData;
  return (
    <main className="container-page max-w-2xl pt-10 sm:pt-14">
      <div className="form-card border-leaf/40">
        <div className="tick" aria-hidden="true">
          &#10003;
        </div>
        <h1 className="page-title mt-4 text-center">Booking confirmed</h1>
        <p className="mt-2 text-center text-ink-soft">
          Thank you, {booking.name}. Your seats are booked. Please keep your booking reference.
        </p>

        <dl className="details mt-6">
          <div>
            <dt>Tasting</dt>
            <dd>{tasting.title}</dd>
          </div>
          <div>
            <dt>Date and time</dt>
            <dd>
              {formatDate(tasting.startsAt)}, {formatTime(tasting.startsAt)}
            </dd>
          </div>
          <div>
            <dt>Guests</dt>
            <dd>{guestsLabel(booking.guests)}</dd>
          </div>
          <div>
            <dt>Total price</dt>
            <dd>{formatEur(booking.totalPrice)}</dd>
          </div>
          <div>
            <dt>Booking reference</dt>
            <dd>
              <span className="reference">{booking.reference}</span>
            </dd>
          </div>
        </dl>

        <p className="mt-8 text-center">
          <Link to="/" className="btn btn-outline">
            Back to all tastings
          </Link>
        </p>
      </div>
    </main>
  );
}
