import { Link } from "react-router";
import type { Route } from "./+types/home";
import { desk } from "~/server/desk.server";
import { formatDate, formatEur, formatTime, seatsLeftLabel } from "~/lib/format";
import type { TastingView } from "~/domain/booking-desk";

const FEW_SEATS_LEFT = 3;

export function loader() {
  return { tastings: desk.listTastings() };
}

export const meta: Route.MetaFunction = () => [{ title: "Wine tastings | Weingut Kieselbrunnen" }];

function seatState(tasting: TastingView) {
  if (tasting.fullyBooked) return "fully-booked";
  return tasting.seatsLeft <= FEW_SEATS_LEFT ? "few-left" : "open";
}

function TastingCard({ tasting }: { tasting: TastingView }) {
  const state = seatState(tasting);
  const titleId = `tasting-${tasting.slug}`;
  return (
    <article aria-labelledby={titleId} className="tasting-card" data-state={state}>
      <div className="flex flex-1 flex-col gap-4 p-5 sm:p-6">
        <div>
          <p className="eyebrow">{formatDate(tasting.startsAt)}</p>
          <h2 id={titleId} className="tasting-title mt-2">
            {tasting.title}
          </h2>
          <p className="mt-1 text-ink-soft">
            <time dateTime={tasting.startsAt}>{formatTime(tasting.startsAt)}</time>
          </p>
        </div>

        <p className="text-ink">
          <span className="text-2xl font-semibold">{formatEur(tasting.pricePerGuest)}</span>{" "}
          <span className="text-sm text-ink-soft">per guest</span>
        </p>

        <div className="flex flex-wrap items-center gap-2">
          <p className="seats" data-state={state}>
            {seatsLeftLabel(tasting.seatsLeft)}
          </p>
          {state === "fully-booked" && (
            <span className="badge badge-fully-booked">Fully booked</span>
          )}
          {state === "few-left" && <span className="badge badge-few-left">Almost full</span>}
        </div>

        <Link
          to={`/book/${tasting.slug}`}
          className={`btn mt-auto ${state === "fully-booked" ? "btn-outline-muted" : ""}`}
        >
          {`Book ${tasting.title}`}
        </Link>
      </div>
    </article>
  );
}

export default function Home({ loaderData }: Route.ComponentProps) {
  return (
    <main className="container-page pt-10 sm:pt-14">
      <p className="eyebrow">Tastings</p>
      <h1 className="page-title mt-2">Wine tastings at Weingut Kieselbrunnen</h1>
      <p className="lead">
        Pick a tasting, choose how many of you are coming, and your seats are booked.
      </p>
      <div className="vine-rule" aria-hidden="true">
        &#10059;
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {loaderData.tastings.map((tasting) => (
          <TastingCard key={tasting.slug} tasting={tasting} />
        ))}
      </div>
    </main>
  );
}
