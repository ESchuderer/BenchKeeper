import { data, Form, redirect, useNavigation } from "react-router";
import type { Route } from "./+types/staff";
import { Field } from "~/components/field";
import type { BookingDesk } from "~/domain/booking-desk";
import { formatDate, formatTime, guestsLabel, seatsLeftLabel } from "~/lib/format";
import { desk } from "~/server/desk.server";
import {
  isStaff,
  passwordMatches,
  signInCookie,
  signOutCookie,
} from "~/server/staff-session.server";

export const meta: Route.MetaFunction = () => [{ title: "Staff | Weingut Kieselbrunnen" }];

// Bookings contain personal data: keep them out of the browser cache (e.g. back button after sign-out).
export const headers: Route.HeadersFunction = () => ({ "Cache-Control": "no-store" });

export async function loader({ request }: Route.LoaderArgs) {
  // Booking data is only put into the response for signed-in staff.
  if (!(await isStaff(request))) return { signedIn: false as const };
  return { signedIn: true as const, groups: desk.bookingsByTasting() };
}

export async function action({ request }: Route.ActionArgs) {
  const form = await request.formData();
  const intent = form.get("intent");

  if (intent === "sign-in") {
    const password = form.get("password");
    if (typeof password !== "string" || password === "") {
      return data({ passwordError: "Please enter the staff password." }, { status: 400 });
    }
    if (!passwordMatches(password)) {
      return data({ passwordError: "Incorrect password. Please try again." }, { status: 401 });
    }
    return redirect("/staff", { headers: { "Set-Cookie": await signInCookie(request) } });
  }

  if (intent === "sign-out") {
    return redirect("/staff", { headers: { "Set-Cookie": await signOutCookie(request) } });
  }

  if (intent === "cancel") {
    if (!(await isStaff(request))) return redirect("/staff");
    const reference = form.get("reference");
    if (typeof reference === "string") desk.cancel(reference);
    return redirect("/staff");
  }

  throw data("Unknown action", { status: 400 });
}

function SignIn({ passwordError }: { passwordError?: string }) {
  return (
    <main className="container-page max-w-md pt-10 sm:pt-14">
      <p className="eyebrow">Staff</p>
      <h1 className="page-title mt-2">Staff sign-in</h1>
      <p className="lead">Bookings are only visible to the winery team.</p>
      <Form method="post" noValidate className="form-card mt-8 flex flex-col gap-6">
        <input type="hidden" name="intent" value="sign-in" />
        <Field
          label="Password"
          name="password"
          type="password"
          autoComplete="current-password"
          required
          error={passwordError}
        />
        <button type="submit" className="btn w-full">
          Sign in
        </button>
      </Form>
    </main>
  );
}

function Overview({
  groups,
}: {
  groups: Extract<Route.ComponentProps["loaderData"], { signedIn: true }>["groups"];
}) {
  const busy = useNavigation().state !== "idle";
  const totalGuests = groups.reduce(
    (sum, g) => sum + g.bookings.reduce((n, b) => n + b.guests, 0),
    0,
  );

  return (
    <main className="container-page pt-10 sm:pt-14">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow">Staff</p>
          <h1 className="page-title mt-2">Bookings</h1>
          <p className="mt-2 text-ink-soft">
            {guestsLabel(totalGuests)} booked across all tastings.
          </p>
        </div>
        <Form method="post">
          <input type="hidden" name="intent" value="sign-out" />
          <button type="submit" className="btn btn-outline">
            Sign out
          </button>
        </Form>
      </div>

      <div className="mt-8 flex flex-col gap-6">
        {groups.map(({ tasting, bookings }) => {
          const headingId = `staff-${tasting.slug}`;
          return (
            <section key={tasting.slug} aria-labelledby={headingId} className="staff-group">
              <div className="staff-group-head">
                <h2 id={headingId} className="tasting-title text-xl">
                  {tasting.title}
                </h2>
                <p className="text-sm text-ink-soft">
                  {formatDate(tasting.startsAt)}, {formatTime(tasting.startsAt)} &middot;{" "}
                  {seatsLeftLabel(tasting.seatsLeft)} of {tasting.seats}
                </p>
              </div>
              {bookings.length === 0 ? (
                <p className="px-5 py-4 text-ink-soft">No bookings yet.</p>
              ) : (
                <ul>
                  {bookings.map((booking) => (
                    <li key={booking.reference} className="booking-row">
                      <div className="min-w-0">
                        <p className="font-semibold text-ink">{booking.name}</p>
                        <p className="break-words text-sm text-ink-soft">{booking.email}</p>
                        <p className="mt-1 text-sm">
                          <span className="font-semibold">{guestsLabel(booking.guests)}</span>
                          <span className="text-ink-soft"> &middot; Booking reference </span>
                          <span className="font-mono font-bold tracking-wider text-wine-dark">
                            {booking.reference}
                          </span>
                        </p>
                      </div>
                      <Form method="post">
                        <input type="hidden" name="intent" value="cancel" />
                        <input type="hidden" name="reference" value={booking.reference} />
                        <button
                          type="submit"
                          className="btn btn-danger w-full sm:w-auto"
                          disabled={busy}
                        >
                          Cancel
                        </button>
                      </Form>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          );
        })}
      </div>
    </main>
  );
}

export default function Staff({ loaderData, actionData }: Route.ComponentProps) {
  return loaderData.signedIn ? (
    <Overview groups={loaderData.groups} />
  ) : (
    <SignIn passwordError={actionData?.passwordError} />
  );
}
