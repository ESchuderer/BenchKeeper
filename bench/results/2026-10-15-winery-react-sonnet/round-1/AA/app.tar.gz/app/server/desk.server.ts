import { type BookingDesk, createBookingDesk } from "~/domain/booking-desk";

// One desk per server process, shared by every request. Kept on globalThis so a
// reloaded module (dev server) does not start over with an empty desk.
const globalForDesk = globalThis as typeof globalThis & { __bookingDesk?: BookingDesk };

export const desk: BookingDesk = (globalForDesk.__bookingDesk ??= createBookingDesk());
