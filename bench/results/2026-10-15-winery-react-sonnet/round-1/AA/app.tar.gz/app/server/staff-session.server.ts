import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { createCookieSessionStorage } from "react-router";

const EIGHT_HOURS = 8 * 60 * 60;

/** The staff password, or undefined when it is not configured (nobody can sign in then). */
function configuredPassword(): string | undefined {
  const password = process.env.STAFF_PASSWORD;
  return password ? password : undefined;
}

// Random per process: sessions end on restart, and a cookie alone gives nothing to brute-force
// the password from.
const processSalt = randomBytes(32);

function storageFor(password: string) {
  // The cookie secret mixes in the password: no second variable to set, and
  // changing the password signs every session out.
  const secret = createHmac("sha256", password).update(processSalt).digest("hex");
  return createCookieSessionStorage<{ staff: boolean }>({
    cookie: {
      name: "__staff",
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: EIGHT_HOURS,
      secrets: [secret],
    },
  });
}

function sha256(value: string) {
  return createHash("sha256").update(value).digest();
}

export function passwordMatches(attempt: string): boolean {
  const password = configuredPassword();
  if (!password) {
    console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
    return false;
  }
  return timingSafeEqual(sha256(attempt), sha256(password));
}

export async function isStaff(request: Request): Promise<boolean> {
  const password = configuredPassword();
  if (!password) return false;
  const session = await storageFor(password).getSession(request.headers.get("Cookie"));
  return session.get("staff") === true;
}

// Marks the cookie Secure when the site is served over https (directly or behind a proxy).
function isHttps(request: Request) {
  return (
    new URL(request.url).protocol === "https:" ||
    request.headers.get("x-forwarded-proto")?.split(",")[0].trim() === "https"
  );
}

/** Set-Cookie header value that signs the requester in. Call only after `passwordMatches`. */
export async function signInCookie(request: Request): Promise<string> {
  const storage = storageFor(configuredPassword() ?? "");
  const session = await storage.getSession();
  session.set("staff", true);
  return storage.commitSession(session, { secure: isHttps(request) });
}

export async function signOutCookie(request: Request): Promise<string> {
  const storage = storageFor(configuredPassword() ?? "");
  const session = await storage.getSession(request.headers.get("Cookie"));
  return storage.destroySession(session, { secure: isHttps(request) });
}
