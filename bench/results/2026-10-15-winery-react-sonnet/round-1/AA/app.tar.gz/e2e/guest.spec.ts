import { expect, test } from "@playwright/test";
import {
  bookSeats,
  cancelTestBookings,
  fillAndSubmit,
  openBookingForm,
  seatsLeftOnStartPage,
  tastingCard,
  TEST_PREFIX,
} from "./helpers";

test.afterEach(async ({ page }) => {
  await cancelTestBookings(page);
});

test("start page lists the tastings with date, price and seats left", async ({ page }) => {
  await page.goto("/");
  const riesling = tastingCard(page, "Riesling Evening");
  await expect(riesling).toContainText("6 November 2026");
  await expect(riesling).toContainText("18:00");
  await expect(riesling).toContainText("EUR 25");
  await expect(riesling.getByText("12 seats left")).toBeVisible();

  const cellar = tastingCard(page, "Red Wine Cellar Tour");
  await expect(cellar).toContainText("14 November 2026");
  await expect(cellar).toContainText("15:00");
  await expect(cellar).toContainText("EUR 32");
  await expect(cellar.getByText("8 seats left")).toBeVisible();

  const winter = tastingCard(page, "Winter Tasting");
  await expect(winter).toContainText("5 December 2026");
  await expect(winter).toContainText("17:00");
  await expect(winter).toContainText("EUR 28");
  await expect(winter.getByText("10 seats left")).toBeVisible();
});

test("every tasting has a Book link that opens its own form", async ({ page }) => {
  for (const title of ["Riesling Evening", "Red Wine Cellar Tour", "Winter Tasting"]) {
    await openBookingForm(page, title);
    await expect(page.getByRole("heading", { name: title })).toBeVisible();
    await expect(page.getByLabel("Name")).toBeVisible();
    await expect(page.getByLabel("Email")).toBeVisible();
    await expect(page.getByLabel("Guests")).toBeVisible();
  }
});

test("booking shows a confirmation and takes the seats", async ({ page }) => {
  const before = await seatsLeftOnStartPage(page, "Winter Tasting");
  await openBookingForm(page, "Winter Tasting");
  await fillAndSubmit(page, {
    name: `${TEST_PREFIX} Anna`,
    email: "anna@example.com",
    guests: "3",
  });

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  const confirmation = page.getByRole("main");
  await expect(confirmation).toContainText("Winter Tasting");
  await expect(confirmation).toContainText("3 guests");
  await expect(confirmation).toContainText("EUR 84");
  await expect(confirmation).toContainText(/KB-[A-Z2-9]{6}/);

  expect(await seatsLeftOnStartPage(page, "Winter Tasting")).toBe(before - 3);
});

test("errors appear next to the field they concern and entries are kept", async ({ page }) => {
  await openBookingForm(page, "Riesling Evening");
  await fillAndSubmit(page, { name: "", email: "not-an-email", guests: "9" });

  await expect(page.getByLabel("Name")).toHaveAccessibleDescription(/enter your name/i);
  await expect(page.getByLabel("Email")).toHaveAccessibleDescription(/valid email/i);
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/from 1 to 8/i);
  await expect(page.getByLabel("Email")).toHaveValue("not-an-email");
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toHaveCount(0);
});

test("a fixed field error does not clear the other entries", async ({ page }) => {
  await openBookingForm(page, "Riesling Evening");
  await fillAndSubmit(page, {
    name: `${TEST_PREFIX} Berta`,
    email: "berta@example.com",
    guests: "0",
  });
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/from 1 to 8/i);
  await expect(page.getByLabel("Name")).toHaveValue(`${TEST_PREFIX} Berta`);
  await expect(page.getByLabel("Email")).toHaveValue("berta@example.com");
});

test("a booking can never take more seats than are left", async ({ page }) => {
  await bookSeats(page, "Red Wine Cellar Tour", 6, `${TEST_PREFIX} Clara`); // 2 left
  await openBookingForm(page, "Red Wine Cellar Tour");
  await fillAndSubmit(page, {
    name: `${TEST_PREFIX} Dora`,
    email: "dora@example.com",
    guests: "3",
  });
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/only 2 seats are left/i);
  expect(await seatsLeftOnStartPage(page, "Red Wine Cellar Tour")).toBe(2);
});

test("a fully booked tasting is marked and cannot be booked", async ({ page }) => {
  await bookSeats(page, "Red Wine Cellar Tour", 8, `${TEST_PREFIX} Emil`);
  await page.goto("/");
  const card = tastingCard(page, "Red Wine Cellar Tour");
  await expect(card.getByText("0 seats left")).toBeVisible();
  await expect(card.getByText("Fully booked")).toBeVisible();

  await page.getByRole("link", { name: "Book Red Wine Cellar Tour" }).click();
  await expect(page.getByText(/fully booked/i).first()).toBeVisible();
  await fillAndSubmit(page, {
    name: `${TEST_PREFIX} Fritz`,
    email: "fritz@example.com",
    guests: "1",
  });
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/fully booked/i);
});

test("six simultaneous bookings never overbook a tasting", async ({ browser, baseURL }) => {
  const results = await Promise.all(
    [1, 2, 3, 4, 5, 6].map(async (n) => {
      const context = await browser.newContext({ baseURL });
      const page = await context.newPage();
      await openBookingForm(page, "Winter Tasting");
      await fillAndSubmit(page, {
        name: `${TEST_PREFIX} Rush ${n}`,
        email: "rush@example.com",
        guests: "4",
      });
      const confirmedHeading = page.getByRole("heading", { name: "Booking confirmed" });
      const rejectedGuests = page.locator('input[name="guests"][aria-invalid="true"]');
      await expect(confirmedHeading.or(rejectedGuests)).toBeVisible();
      const confirmed = await confirmedHeading.count();
      await context.close();
      return confirmed;
    }),
  );
  // 10 seats, 4 guests each: at most two bookings fit.
  expect(results.reduce((a, b) => a + b, 0)).toBe(2);
});

test("unknown tastings and bookings give a not-found page", async ({ page }) => {
  expect((await page.goto("/book/nope"))?.status()).toBe(404);
  expect((await page.goto("/bookings/KB-ZZZZZZ"))?.status()).toBe(404);
});

test.describe("without JavaScript", () => {
  test.use({ javaScriptEnabled: false });

  test("booking and its errors still work as plain forms", async ({ page }) => {
    await openBookingForm(page, "Winter Tasting");
    await fillAndSubmit(page, { name: `${TEST_PREFIX} Plain`, email: "bad", guests: "1" });
    await expect(page.getByLabel("Email")).toHaveAccessibleDescription(/valid email/i);
    await expect(page.getByLabel("Name")).toHaveValue(`${TEST_PREFIX} Plain`);

    await fillAndSubmit(page, { email: "plain@example.com" });
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  });
});

test("a tasting with only a few seats left is flagged", async ({ page }) => {
  await bookSeats(page, "Red Wine Cellar Tour", 5, `${TEST_PREFIX} Gerda`); // 3 left
  await page.goto("/");
  const card = tastingCard(page, "Red Wine Cellar Tour");
  await expect(card.getByText("3 seats left")).toBeVisible();
  await expect(card.getByText("Almost full")).toBeVisible();
  await expect(card.getByText("Fully booked")).toHaveCount(0);
});
