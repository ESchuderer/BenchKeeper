import { expect, type Page } from "@playwright/test";

export const STAFF_PASSWORD = "riesling-2026";
export const TEST_PREFIX = "E2E";

export function tastingCard(page: Page, title: string) {
  return page.getByRole("article", { name: title });
}

/** Seats left shown on the start page for one tasting. */
export async function seatsLeftOnStartPage(page: Page, title: string): Promise<number> {
  await page.goto("/");
  const text = await tastingCard(page, title)
    .getByText(/\d+ seats left/)
    .innerText();
  return Number(/(\d+) seats left/.exec(text)![1]);
}

export async function openBookingForm(page: Page, title: string) {
  await page.goto("/");
  await page.getByRole("link", { name: `Book ${title}` }).click();
  await expect(page.getByRole("button", { name: "Book", exact: true })).toBeVisible();
}

export async function fillAndSubmit(
  page: Page,
  values: { name?: string; email?: string; guests?: string },
) {
  if (values.name !== undefined) await page.getByLabel("Name").fill(values.name);
  if (values.email !== undefined) await page.getByLabel("Email").fill(values.email);
  if (values.guests !== undefined) await page.getByLabel("Guests").fill(values.guests);
  await page.getByRole("button", { name: "Book", exact: true }).click();
}

export async function bookSeats(page: Page, title: string, guests: number, name: string) {
  await openBookingForm(page, title);
  await fillAndSubmit(page, { name, email: "guest@example.com", guests: String(guests) });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
}

export async function signInAsStaff(page: Page) {
  await page.goto("/staff");
  if ((await page.getByLabel("Password").count()) > 0) {
    await page.getByLabel("Password").fill(STAFF_PASSWORD);
    await page.getByRole("button", { name: "Sign in" }).click();
  }
  await expect(page.getByRole("heading", { name: "Bookings" })).toBeVisible();
}

/** Cancel every booking made by the e2e tests so the next test starts from the same seats. */
export async function cancelTestBookings(page: Page) {
  await signInAsStaff(page);
  const rows = page.getByRole("listitem").filter({ hasText: TEST_PREFIX });
  for (let left = await rows.count(); left > 0; left--) {
    await rows.first().getByRole("button", { name: "Cancel" }).click();
    await expect(rows).toHaveCount(left - 1);
  }
}
