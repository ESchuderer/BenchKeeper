import { expect, test, type Page } from "@playwright/test";
import {
  bookSeats,
  cancelTestBookings,
  fillAndSubmit,
  openBookingForm,
  signInAsStaff,
  TEST_PREFIX,
} from "./helpers";

// Runs with a phone viewport (see the "phone" project).

async function expectNoSidewaysScroll(page: Page) {
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
  expect(overflow).toBeLessThanOrEqual(0);
}

async function expectTapTargets(page: Page) {
  for (const control of await page.locator("main a.btn, main button, main input").all()) {
    const box = await control.boundingBox();
    if (!box) continue;
    expect(box.height, "control is tall enough to tap").toBeGreaterThanOrEqual(40);
  }
}

test.afterEach(async ({ page }) => {
  await cancelTestBookings(page);
});

test("start page fits a phone", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("link", { name: "Book Riesling Evening" })).toBeVisible();
  await expectNoSidewaysScroll(page);
  await expectTapTargets(page);
});

test("booking form, its errors and the confirmation fit a phone", async ({ page }) => {
  await openBookingForm(page, "Red Wine Cellar Tour");
  await expectNoSidewaysScroll(page);
  await expectTapTargets(page);

  await fillAndSubmit(page, { name: "", email: "no", guests: "99" });
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/from 1 to 8/);
  await expectNoSidewaysScroll(page);

  await fillAndSubmit(page, {
    name: `${TEST_PREFIX} Phone`,
    email: "phone@example.com",
    guests: "2",
  });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  await expectNoSidewaysScroll(page);
});

test("fully booked state and staff pages fit a phone", async ({ page }) => {
  const longName = `${TEST_PREFIX} A very long name that keeps going and going on a small screen`;
  await bookSeats(page, "Winter Tasting", 8, longName);
  await bookSeats(page, "Winter Tasting", 2, `${TEST_PREFIX} Second`);
  await page.goto("/");
  await expect(page.getByText("Fully booked")).toBeVisible();
  await expectNoSidewaysScroll(page);

  await page.goto("/staff");
  await expectNoSidewaysScroll(page);
  await signInAsStaff(page);
  await expect(page.getByRole("button", { name: "Cancel" }).first()).toBeVisible();
  await expectNoSidewaysScroll(page);
  await expectTapTargets(page);
});
