import { expect, test } from "@playwright/test";

// Runs against a second server that is started without STAFF_PASSWORD.
test("nobody can sign in when STAFF_PASSWORD is not set", async ({ page }) => {
  for (const attempt of ["", "undefined", "password"]) {
    await page.goto("/staff");
    await page.getByLabel("Password").fill(attempt);
    await page.getByRole("button", { name: "Sign in" }).click();
    await expect(page.getByLabel("Password")).toBeVisible();
    await expect(page.getByRole("heading", { name: "Bookings" })).toHaveCount(0);
  }
});
