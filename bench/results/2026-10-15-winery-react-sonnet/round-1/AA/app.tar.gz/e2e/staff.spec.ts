import { expect, test } from "@playwright/test";
import {
  bookSeats,
  cancelTestBookings,
  seatsLeftOnStartPage,
  signInAsStaff,
  STAFF_PASSWORD,
  TEST_PREFIX,
} from "./helpers";

test.afterEach(async ({ page }) => {
  await cancelTestBookings(page);
});

test("staff page asks for a password and shows no bookings before sign-in", async ({ page }) => {
  await bookSeats(page, "Riesling Evening", 2, `${TEST_PREFIX} Secret Guest`);
  await page.goto("/staff");
  await expect(page.getByLabel("Password")).toBeVisible();
  await expect(page.getByRole("button", { name: "Sign in" })).toBeVisible();
  await expect(page.getByText("Secret Guest")).toHaveCount(0);
});

test("a wrong password is rejected with an error next to the field", async ({ page }) => {
  await page.goto("/staff");
  await page.getByLabel("Password").fill("not-the-password");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByLabel("Password")).toHaveAccessibleDescription(/incorrect password/i);
  await expect(page.getByRole("heading", { name: "Bookings" })).toHaveCount(0);
});

test("an empty password is rejected", async ({ page }) => {
  await page.goto("/staff");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByLabel("Password")).toHaveAccessibleDescription(/password/i);
  await expect(page.getByRole("heading", { name: "Bookings" })).toHaveCount(0);
});

test("the right password signs in, and stays signed in on later visits", async ({ page }) => {
  await signInAsStaff(page);
  await page.goto("/");
  await page.goto("/staff");
  await expect(page.getByRole("heading", { name: "Bookings" })).toBeVisible();
  await expect(page.getByLabel("Password")).toHaveCount(0);
});

test("signing out hides the bookings again", async ({ page }) => {
  await signInAsStaff(page);
  await page.getByRole("button", { name: "Sign out" }).click();
  await expect(page.getByLabel("Password")).toBeVisible();
});

test("bookings are grouped by tasting with name, email, guests and reference", async ({ page }) => {
  await bookSeats(page, "Riesling Evening", 2, `${TEST_PREFIX} Anna`);
  await bookSeats(page, "Winter Tasting", 1, `${TEST_PREFIX} Carl`);
  await signInAsStaff(page);

  for (const title of ["Riesling Evening", "Red Wine Cellar Tour", "Winter Tasting"]) {
    await expect(page.getByRole("region", { name: title })).toBeVisible();
  }
  const riesling = page.getByRole("region", { name: "Riesling Evening" });
  const anna = riesling.getByRole("listitem").filter({ hasText: `${TEST_PREFIX} Anna` });
  await expect(anna).toContainText("guest@example.com");
  await expect(anna).toContainText("2 guests");
  await expect(anna).toContainText(/KB-[A-Z2-9]{6}/);

  const winter = page.getByRole("region", { name: "Winter Tasting" });
  await expect(
    winter.getByRole("listitem").filter({ hasText: `${TEST_PREFIX} Carl` }),
  ).toContainText("1 guest");
  await expect(winter).not.toContainText(`${TEST_PREFIX} Anna`);
});

test("cancelling a booking removes it and frees its seats", async ({ page }) => {
  const before = await seatsLeftOnStartPage(page, "Red Wine Cellar Tour");
  await bookSeats(page, "Red Wine Cellar Tour", 4, `${TEST_PREFIX} Greta`);
  expect(await seatsLeftOnStartPage(page, "Red Wine Cellar Tour")).toBe(before - 4);

  await signInAsStaff(page);
  const row = page.getByRole("listitem").filter({ hasText: `${TEST_PREFIX} Greta` });
  await row.getByRole("button", { name: "Cancel" }).click();
  await expect(row).toHaveCount(0);

  expect(await seatsLeftOnStartPage(page, "Red Wine Cellar Tour")).toBe(before);
});

test("cancelling without a staff sign-in does nothing", async ({ page, playwright, baseURL }) => {
  await bookSeats(page, "Riesling Evening", 2, `${TEST_PREFIX} Hanna`);
  const reference = /KB-[A-Z2-9]{6}/.exec(await page.getByRole("main").innerText())![0];
  const before = await seatsLeftOnStartPage(page, "Riesling Evening");

  const anonymous = await playwright.request.newContext({ baseURL });
  const response = await anonymous.post("/staff", {
    form: { intent: "cancel", reference },
    maxRedirects: 0,
  });
  expect(response.status()).not.toBe(500);
  await anonymous.dispose();

  expect(await seatsLeftOnStartPage(page, "Riesling Evening")).toBe(before);
  await page.goto(`/bookings/${reference}`);
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
});

test("the staff password is not exposed to guests", async ({ page }) => {
  const response = await page.goto("/");
  expect(await response!.text()).not.toContain(STAFF_PASSWORD);
});

test("staff pages are never cached by the browser", async ({ page }) => {
  await signInAsStaff(page);
  const response = await page.goto("/staff");
  expect(response!.headers()["cache-control"]).toContain("no-store");
});
