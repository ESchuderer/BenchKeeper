# Design

## Context

Greenfield repo; nothing exists but the process tooling. See proposal.md for motivation and specs/ for behavior. Vocabulary follows `GLOSSARY.md` (Tasting, Seats, Seats left, Booking, Booking reference, Staff, Cancellation). Constraints: Node 22, `npm install` / `npm run build` / `npm start` on `PORT`, React interface, no external services, English UI.

## Goals / Non-Goals

**Goals:**
- One deep domain module owns every seat rule, so the "never overbook" rule is enforced in exactly one place and testable without a browser.
- Forms work as plain HTML form posts (server validation, redirect after success) and are enhanced by React; the error-next-to-field behavior does not depend on client JS.
- Small, consistent look built from design tokens, not per-page styling.

**Non-Goals:**
- Persistence across restarts, multi-process deployment, payments, email, internationalisation, closing sales for past Tastings.

## Decisions

**Stack: React Router v7 framework mode (SSR) + Tailwind CSS v4 + Zod.** React Router gives routing, server `action`/`loader`, cookie sessions and `npm start` via `@react-router/serve`, so no custom server or router. Tailwind gives a token-based design system without hand-written CSS plumbing. Zod gives typed validation with per-field messages. Alternatives: Next.js (heavier, more conventions than a four-page site needs); Express + Vite SPA (needs a hand-built API, client routing and form state, i.e. the replacements the brief says not to write); react-hook-form (client-only validation duplicates the server rules, which must exist anyway).

**Domain module `BookingDesk` (`app/domain/booking-desk.ts`).** Created with `createBookingDesk({ newReference })` (the reference generator is injectable so tests can force collisions); the seeded Tastings are fixed. Public interface: `listTastings()`, `getTasting(slug)`, `book(slug, input)`, `getBooking(reference)`, `bookingsByTasting()`, `cancel(reference)`. `book` takes the raw form values (strings), validates them, checks Seats left and takes the Seats in one synchronous step, and returns either `{ ok: true, booking }` or `{ ok: false, errors }` keyed by field. Because Node runs it on one thread with no `await` inside, check-and-take is atomic, which covers simultaneous bookings. Seats left is derived from the active Bookings, never stored separately, so Cancellation cannot drift. The in-memory state is held in the module instance; the app creates one instance, kept on `globalThis` so dev reloads and the server bundle share it. Cancelled bookings are removed; every reference ever issued is remembered so none is reused. Alternatives: a repository interface with a file adapter (speculative, only one adapter needed now).

**Tastings are seeded data in code** (`app/domain/tastings.ts`), slug = kebab-case title. Date and time are wall-clock strings (`2026-11-06T18:00`) formatted without time-zone conversion, so every visitor sees 18:00.

**Booking reference**: `KB-` plus 6 characters from an unambiguous alphabet (no 0/O/1/I), randomly generated and re-drawn on collision. The confirmation page lives at `/bookings/:reference`; the reference is the only handle and is not guessable enough to enumerate (31^6).

**Staff access**: `STAFF_PASSWORD` read at request time. Password compared in constant time (hash both sides, `timingSafeEqual`). Signed-in state is a signed, `httpOnly`, `sameSite=lax` session cookie (React Router `createCookieSessionStorage`), secret derived from `STAFF_PASSWORD` and a random per-process salt via HMAC, so no second variable is needed, changing the password or restarting signs everybody out, and a cookie cannot be used to brute-force the password offline. `/staff` responses are `Cache-Control: no-store`. Unset or empty `STAFF_PASSWORD` means sign-in always fails. `/staff` loader and the cancel action both check the session. `sameSite=lax` blocks cross-site cancel posts, so no separate CSRF token.

**Routes**: `/` (list), `/book/:slug` (form + action), `/bookings/:reference` (confirmation), `/staff` (sign-in, overview, cancel, sign-out).

**Fully booked tastings keep their "Book <title>" link.** The brief says each tasting has the link; the form page shows a clear "fully booked" notice and the server rejects with a Guests error. The start page marks the Tasting "Fully booked" with a muted card.

**UI copy details.** Seats left uses the literal brief format "<n> seats left" (also "1 seats left"). Prices read "EUR 25". Guests is a number input; forms use `noValidate` so our messages, not browser bubbles, appear. Labels are exactly "Name", "Email", "Guests"; hints sit outside the label and are linked by `aria-describedby`; errors are `role="alert"`-linked via `aria-describedby` and `aria-invalid`.

**Look and feel**: warm off-white paper background, deep wine/burgundy primary, muted olive-gold accent, serif display type (system serif stack, no web font fetch, so it works offline), generous spacing, card per Tasting with a coloured state strip; error = red border + message with icon-free text, success = green-tinted confirmation card, fully booked = muted card with badge. Mobile-first single column, two columns from `md`.

**Testing seams** (pre-agreed here because no user was available to confirm; see tasks):
1. `BookingDesk` interface, in-process Vitest tests, no mocks (only an injected reference generator for the collision case).
2. The running app over HTTP in a real browser (Playwright against `npm run build && npm start`), for the guest flow, the staff flow and the responsive/visual states. Nothing in between (no component-level tests of routes).

## Risks / Trade-offs

- [Bookings lost on restart] → stated in proposal; acceptable per brief ("in memory or local file").
- [Single process only] → atomicity relies on one Node process; documented in README.
- [Literal "1 seats left"] → follows brief wording; one-line change in one component if the winery wants "1 seat left".
- [Password derived secret] → weak password means weak cookie secret; the cookie only carries a boolean and the password is shared anyway.
- [No request-size limit and no password rate limiting] → fields are length-capped in the domain; acceptable for a small site behind a reverse proxy, noted in the README.
- [Past Tastings stay bookable] → data is fixed at 2026 dates; add a clock to `BookingDesk` if the offer becomes dynamic.
