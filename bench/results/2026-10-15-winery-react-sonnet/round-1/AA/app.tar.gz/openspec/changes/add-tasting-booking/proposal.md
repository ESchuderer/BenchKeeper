# Proposal

## Why

Weingut Kieselbrunnen takes tasting bookings informally today. Guests cannot see what is on offer or how many Seats are left, and staff have no single list of who is coming. An online booking site fixes both, and the hard rule is that a Tasting is never overbooked.

## What Changes

- New React web app served by one Node process (`npm start`, port from `PORT`).
- Guest flow: list of Tastings (title, date and time, price per guest, seats left), a booking form per Tasting, a confirmation with a Booking reference.
- Staff flow: password-protected `/staff` (password from `STAFF_PASSWORD`) showing Bookings grouped by Tasting, with Cancellation that frees Seats.
- Three Tastings are seeded in code; Bookings start empty and live in memory.
- A visual design that fits a small winery (own site, not a generic form), with clear error, success and fully-booked states, usable on a phone.

## Capabilities

### New Capabilities
- `tasting-booking`: guest-facing listing of Tastings, booking with validation and the seat limit, confirmation.
- `staff-bookings`: staff sign-in, grouped Booking overview, Cancellation.

### Modified Capabilities

(none, greenfield)

## Impact

- New code: whole application (routes, booking domain module, session handling, styling, tests).
- Dependencies: React, React Router (framework mode, server rendering, form actions), Tailwind CSS, Zod, Vitest, Playwright.
- No external services; no database. A restart clears all Bookings.
- Out of scope: payment, email sending, editing Bookings, staff accounts, closing sales for Tastings in the past.
