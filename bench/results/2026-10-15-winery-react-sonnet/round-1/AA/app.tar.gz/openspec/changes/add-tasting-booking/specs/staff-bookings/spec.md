# Spec Delta

## Purpose

Lets the winery's staff sign in, see who has booked which Tasting, and cancel Bookings to free their Seats.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a password ("Password" field, "Sign in" button) and SHALL show Bookings only after the password equals the environment variable `STAFF_PASSWORD`. If `STAFF_PASSWORD` is not set, nobody SHALL be able to sign in.

#### Scenario: Not signed in
- **WHEN** someone opens `/staff` without being signed in
- **THEN** a "Password" field and a "Sign in" button are shown, and no Booking data

#### Scenario: Wrong password
- **WHEN** someone submits a wrong password
- **THEN** an error message appears next to the Password field and no Booking data is shown

#### Scenario: Right password
- **WHEN** someone submits the correct password
- **THEN** they see the Bookings overview and stay signed in on later visits of `/staff` in that browser

#### Scenario: Password not configured
- **WHEN** `STAFF_PASSWORD` is not set or empty
- **THEN** no password, including the empty one, signs anyone in

### Requirement: Bookings overview grouped by Tasting
A signed-in staff member SHALL see all active Bookings grouped by Tasting. Each Booking shows name, email, number of Guests and Booking reference. Every Tasting appears as a group, also when it has no Bookings.

#### Scenario: Grouped list
- **WHEN** staff are signed in and two guests have booked the Riesling Evening and one the Winter Tasting
- **THEN** the Riesling Evening group lists two Bookings and the Winter Tasting group lists one, each with name, email, guests and reference

#### Scenario: Empty overview
- **WHEN** staff are signed in and nothing has been booked
- **THEN** every Tasting is shown with a note that it has no Bookings

### Requirement: Staff can cancel a Booking
A signed-in staff member SHALL be able to cancel a Booking with a "Cancel" button. A cancelled Booking disappears from the overview and its Seats become free again.

#### Scenario: Cancel frees seats
- **WHEN** a Booking of 4 Guests on a Tasting with 8 seats left is cancelled
- **THEN** the Booking is gone from the overview and the Tasting shows "12 seats left" on the start page

#### Scenario: Cancelling twice
- **WHEN** a Booking that was already cancelled is cancelled again
- **THEN** no Seats are freed twice and the staff page still shows correctly

#### Scenario: Cancel needs sign-in
- **WHEN** a request to cancel a Booking arrives without a staff sign-in
- **THEN** the Booking is not cancelled

### Requirement: Staff can sign out
A signed-in staff member SHALL be able to sign out with a "Sign out" button, after which the Bookings are no longer shown without a new sign-in.

#### Scenario: Sign out
- **WHEN** staff press "Sign out"
- **THEN** the "Password" field is shown again instead of the Bookings

### Requirement: Staff pages are not cached
Responses of `/staff` SHALL tell the browser not to store them, because they contain guests' names and email addresses.

#### Scenario: No-store header
- **WHEN** a signed-in staff member loads `/staff`
- **THEN** the response carries `Cache-Control: no-store`
