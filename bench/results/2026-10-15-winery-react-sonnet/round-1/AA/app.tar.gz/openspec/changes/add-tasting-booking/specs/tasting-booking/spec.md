# Spec Delta

## Purpose

Lets guests of Weingut Kieselbrunnen see the offered Tastings and book Seats online, without ever overbooking a Tasting.

## ADDED Requirements

### Requirement: Start page lists the Tastings
The start page SHALL list every Tasting with its title, date and time, price per guest in EUR, and Seats left shown as "<n> seats left". The winery offers Riesling Evening (2026-11-06 18:00, EUR 25, 12 Seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 Seats) and Winter Tasting (2026-12-05 17:00, EUR 28, 10 Seats).

#### Scenario: Fresh start
- **WHEN** a guest opens the start page and nothing has been booked
- **THEN** the page shows the three Tastings with "12 seats left", "8 seats left" and "10 seats left"

#### Scenario: Each Tasting has a booking link
- **WHEN** a guest views the start page
- **THEN** every Tasting has a link named "Book <tasting title>", for example "Book Riesling Evening", that opens the booking form of that Tasting

#### Scenario: Fully booked Tasting is marked
- **WHEN** a Tasting has no Seats left
- **THEN** the start page shows "0 seats left" and a visible "Fully booked" state for that Tasting

### Requirement: Few seats left are flagged
The start page SHALL mark a Tasting with 3 or fewer Seats left, but more than none, as "Almost full" in addition to its seats left.

#### Scenario: Three seats left
- **WHEN** a Tasting has 3 Seats left
- **THEN** its card shows "3 seats left" and an "Almost full" marker

### Requirement: Booking form
The booking form of a Tasting SHALL have the fields "Name", "Email" and "Guests" (1 to 8) and a "Book" button, and SHALL show the Tasting it belongs to.

#### Scenario: Open the form
- **WHEN** a guest follows "Book Red Wine Cellar Tour"
- **THEN** a form for the Red Wine Cellar Tour with fields "Name", "Email", "Guests" and a "Book" button is shown

### Requirement: Input is validated next to the field
The system SHALL reject invalid input and show an error message next to the field it concerns. Name MUST NOT be blank. Email MUST be a valid email address. Guests MUST be a whole number from 1 to 8; surrounding spaces and leading zeros are tolerated. Email MUST NOT exceed 254 characters. A rejected submission MUST NOT create a Booking, and the guest's other entries SHALL stay in the form.

#### Scenario: Blank name
- **WHEN** a guest submits the form with an empty Name
- **THEN** an error message appears next to the Name field and no Booking is created

#### Scenario: Malformed email
- **WHEN** a guest submits "not-an-email" as Email
- **THEN** an error message appears next to the Email field and no Booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits 0, 9, 2.5 or text as Guests
- **THEN** an error message appears next to the Guests field and no Booking is created

#### Scenario: Entries are kept
- **WHEN** a submission is rejected because of one field
- **THEN** the values the guest typed into the other fields are still in the form

### Requirement: Seats are never overbooked
A Booking SHALL NOT take more Seats than are left on the Tasting at the moment it is made, including when several guests book at the same time. A rejection for lack of Seats SHALL show an error message next to the Guests field and name how many Seats are left.

#### Scenario: More guests than seats left
- **WHEN** 3 Seats are left on a Tasting and a guest books 4
- **THEN** the booking is rejected with an error next to the Guests field saying 3 seats are left, and the seats left stay 3

#### Scenario: Last seats
- **WHEN** 3 Seats are left and a guest books 3
- **THEN** the Booking is made and the Tasting shows "0 seats left"

#### Scenario: Fully booked form
- **WHEN** a guest opens the booking form of a fully booked Tasting
- **THEN** the page states that the Tasting is fully booked, and submitting a Booking is rejected next to the Guests field

#### Scenario: Seats are per Tasting
- **WHEN** guests book Seats on one Tasting
- **THEN** the Seats left of the other Tastings do not change

### Requirement: Booking confirmation
After a successful Booking the system SHALL show a confirmation with the heading "Booking confirmed", the Tasting, the number of Guests, the Total price in EUR and a Booking reference. Every Booking reference MUST be unique, and never reused after a cancellation.

#### Scenario: Confirmation content
- **WHEN** a guest books 3 Guests on the Winter Tasting (EUR 28 per guest)
- **THEN** the page shows "Booking confirmed", "Winter Tasting", 3 guests, a total of EUR 84 and a Booking reference

#### Scenario: Seats are taken
- **WHEN** the Booking is confirmed
- **THEN** the start page shows the Tasting's Seats left reduced by the number of Guests
