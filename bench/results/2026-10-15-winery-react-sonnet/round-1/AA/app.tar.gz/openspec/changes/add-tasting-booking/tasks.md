# Tasks

Slices are vertical (tracer bullets); the same slices exist as tickets under `.scratch/tasting-booking/issues/`. Each slice is built test-first at the seams named in design.md.

## 1. Scaffold

- [x] 1.1 Create the React Router + Tailwind + Vitest + Playwright project with `npm install`, `npm run build`, `npm start` (PORT, default 3000); verify `npm run build && npm start` serves a placeholder page and `npm run typecheck` passes
- [x] 1.2 Add design tokens, base layout (header, footer, container) and fonts stack; verify the placeholder page renders with the winery look at 375px and 1280px wide

## 2. Booking desk (domain, seam 1)

- [x] 2.1 Seeded Tastings and `listTastings` with seats left; verify Vitest tests for the three Tastings and "12/8/10" seats
- [x] 2.2 `book` with validation (name, email, guests 1-8) returning per-field errors; verify Vitest tests for each invalid case and no state change on rejection
- [x] 2.3 Seat limit, last seats, per-Tasting isolation, unique references; verify Vitest tests
- [x] 2.4 `bookingsByTasting` and idempotent `cancel` freeing seats; verify Vitest tests

## 3. Guest flow (seam 2)

- [x] 3.1 Start page lists Tastings with "Book <title>" links and fully-booked state; verify Playwright test
- [x] 3.2 Booking form with field errors, kept entries, over-limit error; verify Playwright tests
- [x] 3.3 Confirmation page "Booking confirmed" with tasting, guests, total, reference; verify Playwright test including seats-left drop on start page

## 4. Staff flow (seam 2)

- [x] 4.1 `/staff` sign-in with `STAFF_PASSWORD` (wrong, empty, unset cases); verify Playwright tests
- [x] 4.2 Grouped overview and "Cancel" freeing seats, cancel blocked without sign-in; verify Playwright tests

## 5. Integration

- [x] 5.1 Run the full suite against a production build, check phone viewport screenshots of every page state, write README (run, env vars, assumptions); verify `npm test`, `npm run test:e2e`, `npm run typecheck` pass
- [x] 5.2 Two-axis code review against these specs; fix findings; verify `openspec validate add-tasting-booking --strict`
