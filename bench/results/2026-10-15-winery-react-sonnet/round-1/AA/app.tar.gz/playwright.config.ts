import { defineConfig, devices } from "@playwright/test";

const PORT = 3100;
const PORT_WITHOUT_PASSWORD = 3101;

export default defineConfig({
  testDir: "./e2e",
  fullyParallel: false,
  workers: 1,
  reporter: "list",
  use: { baseURL: `http://localhost:${PORT}` },
  projects: [
    {
      name: "desktop",
      use: { ...devices["Desktop Chrome"] },
      testIgnore: [/responsive\.spec\.ts/, /staff-unconfigured\.spec\.ts/],
    },
    {
      name: "phone",
      use: { ...devices["Pixel 7"] },
      testMatch: /responsive\.spec\.ts/,
    },
    {
      name: "no-staff-password",
      use: { ...devices["Desktop Chrome"], baseURL: `http://localhost:${PORT_WITHOUT_PASSWORD}` },
      testMatch: /staff-unconfigured\.spec\.ts/,
    },
  ],
  // Started in order: the first builds, the second reuses that build.
  webServer: [
    {
      command: "npm run build && npm start",
      url: `http://localhost:${PORT}`,
      timeout: 120_000,
      env: { PORT: String(PORT), STAFF_PASSWORD: "riesling-2026" },
    },
    {
      command: "npm start",
      url: `http://localhost:${PORT_WITHOUT_PASSWORD}`,
      timeout: 60_000,
      env: { PORT: String(PORT_WITHOUT_PASSWORD), STAFF_PASSWORD: "" },
    },
  ],
});
