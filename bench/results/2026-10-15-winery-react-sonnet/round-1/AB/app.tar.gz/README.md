# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings online; staff see and cancel the bookings.
React single-page app (Vite, React Router, TanStack Query, React Hook Form, Tailwind CSS) served by an Express API, in one Node.js process.

## Run

Requires Node.js 22.

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start    # http://localhost:3000
```

| Variable | Meaning |
|---|---|
| `PORT` | Port to listen on (default `3000`). |
| `STAFF_PASSWORD` | Password for `/staff`. If unset or empty, nobody can sign in. |
| `BOOKINGS_FILE` | Optional path of a JSON file that persists bookings across restarts. Without it, bookings live in memory only. A corrupt file stops the app with an error instead of being overwritten. |
| `TRUST_PROXY` | Number of reverse-proxy hops in front of the app (e.g. `1`). Needed behind a proxy so HTTPS is detected for the cookie `Secure` flag and the login rate limit uses the client IP. Leave unset when not behind a proxy. |

The app starts with no bookings. The three tastings are fixed in `shared/tastings.ts`.

## Pages

- `/` – tastings with date, price per guest and seats left; "Book <tasting>" opens the form.
- `/tastings/:id/book` – booking form (Name, Email, Guests 1–8).
- `/booking/:reference` – confirmation ("Booking confirmed"), reload-safe, shows no personal data.
- `/staff` – password sign-in, then all bookings grouped by tasting with a "Cancel" button per booking.

## Develop and test

```sh
npm run dev         # API on :3000 + Vite dev server with /api proxy
npm test            # unit + API + component tests (Vitest)
npm run typecheck
npm run build && npm run test:e2e   # Playwright against the built app
```

The e2e tests need a Chromium: `npx playwright install chromium` (on Linux also its system libraries, `npx playwright install-deps chromium`).

## Layout

- `shared/` – tasting data, money formatting and the booking validation schema (used by client and server)
- `server/` – `store.ts` (bookings and seat accounting, optional file persistence), `app.ts` (HTTP API, staff sessions, static serving), `index.ts` (startup)
- `src/` – React app
- `tests/` – `shared`, `server` (Supertest), `client` (Testing Library), `e2e` (Playwright)
- `openspec/` – specification, design and task list of the change that built the app

## Notes

- Seats are checked and taken in one synchronous step, so simultaneous requests can never overbook a tasting.
- A tasting closes for booking once its start time (Europe/Berlin) has passed.
- Prices are informational; guests pay at the winery.
