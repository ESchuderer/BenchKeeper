import { existsSync } from 'node:fs';
import { join } from 'node:path';
import cookieParser from 'cookie-parser';
import express from 'express';
import { rateLimit } from 'express-rate-limit';
import helmet from 'helmet';
import { bookingInputSchema } from '../shared/booking.js';
import { TASTINGS } from '../shared/tastings.js';
import { SessionStore, passwordMatches } from './sessions.js';
const SESSION_COOKIE = 'kb_staff';
const sendErrors = (res, status, errors, extra = {}) => res.status(status).json({ errors, ...extra });
export function createApp(options) {
    const { store, staffPassword, staticDir } = options;
    const now = options.now ?? (() => new Date());
    const sessions = new SessionStore(now);
    const app = express();
    app.disable('x-powered-by');
    if (options.trustProxy)
        app.set('trust proxy', options.trustProxy);
    app.use(helmet({ contentSecurityPolicy: { directives: { upgradeInsecureRequests: null } } }));
    const api = express.Router();
    api.use((_req, res, next) => {
        res.set('Cache-Control', 'no-store');
        next();
    });
    api.use(express.json({ limit: '8kb' }));
    api.use(cookieParser());
    // ---- Guests ----
    api.get('/tastings', (_req, res) => {
        res.json({ tastings: store.listTastings() });
    });
    api.post('/bookings', (req, res) => {
        const body = isRecord(req.body) ? req.body : {};
        const tastingId = typeof body.tastingId === 'string' ? body.tastingId : '';
        const tasting = store.getTasting(tastingId);
        if (!tasting)
            return sendErrors(res, 404, { form: 'This tasting does not exist.' });
        const parsed = bookingInputSchema.safeParse(body);
        if (!parsed.success) {
            const errors = {};
            for (const issue of parsed.error.issues) {
                const key = issue.path[0];
                if ((key === 'name' || key === 'email' || key === 'guests') && !errors[key])
                    errors[key] = issue.message;
            }
            return sendErrors(res, 422, errors);
        }
        const result = store.createBooking(tastingId, parsed.data);
        if (result.ok)
            return res.status(201).json(confirmationView(result.booking, store));
        switch (result.code) {
            case 'not_enough_seats':
                return sendErrors(res, 422, { guests: `Only ${result.seatsLeft} ${result.seatsLeft === 1 ? "seat" : "seats"} left for this tasting. Please reduce the number of guests.` }, { seatsLeft: result.seatsLeft });
            case 'full':
                return sendErrors(res, 409, { guests: 'Sorry, this tasting is now fully booked.' }, { seatsLeft: 0 });
            case 'closed':
                return sendErrors(res, 409, { form: 'Booking for this tasting is closed because it has already started.' });
            default:
                return sendErrors(res, 404, { form: 'This tasting does not exist.' });
        }
    });
    api.get('/bookings/:reference', (req, res) => {
        const booking = store.getBooking(String(req.params.reference));
        if (!booking)
            return sendErrors(res, 404, { form: 'We could not find this booking.' });
        res.json(confirmationView(booking, store));
    });
    // ---- Staff ----
    const loginLimiter = rateLimit({
        windowMs: 15 * 60 * 1000,
        limit: options.loginAttempts ?? 10,
        skipSuccessfulRequests: true,
        standardHeaders: 'draft-7',
        legacyHeaders: false,
        handler: (_req, res) => sendErrors(res, 429, { password: 'Too many failed attempts. Please try again later.' }),
    });
    api.post('/staff/login', loginLimiter, (req, res) => {
        const password = isRecord(req.body) ? req.body.password : undefined;
        if (!passwordMatches(password, staffPassword)) {
            return sendErrors(res, 401, { password: 'That password is not correct.' });
        }
        res.cookie(SESSION_COOKIE, sessions.create(), {
            httpOnly: true,
            sameSite: 'strict',
            secure: req.secure,
            path: '/',
        });
        res.json({ ok: true });
    });
    const requireStaff = (req, res, next) => {
        if (!sessions.touch(req.cookies?.[SESSION_COOKIE])) {
            return sendErrors(res, 401, { form: 'Please sign in to continue.' });
        }
        next();
    };
    api.post('/staff/logout', (req, res) => {
        sessions.destroy(req.cookies?.[SESSION_COOKIE]);
        res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: 'strict', secure: req.secure, path: '/' });
        res.status(204).end();
    });
    api.get('/staff/session', requireStaff, (_req, res) => {
        res.json({ ok: true });
    });
    api.get('/staff/bookings', requireStaff, (_req, res) => {
        const active = store.listActiveBookings();
        res.json({
            tastings: TASTINGS.map((t) => {
                const bookings = active
                    .filter((b) => b.tastingId === t.id)
                    .map(({ reference, name, email, guests, createdAt }) => ({ reference, name, email, guests, createdAt }));
                return {
                    id: t.id,
                    title: t.title,
                    startsAt: t.startsAt,
                    capacity: t.capacity,
                    seatsBooked: bookings.reduce((sum, b) => sum + b.guests, 0),
                    bookings,
                };
            }),
        });
    });
    api.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
        if (!store.cancelBooking(String(req.params.reference))) {
            return sendErrors(res, 404, { form: 'This booking no longer exists.' });
        }
        res.status(204).end();
    });
    api.use((_req, res) => sendErrors(res, 404, { form: 'Not found.' }));
    app.use('/api', api);
    // ---- Client ----
    if (staticDir) {
        app.use('/assets', express.static(join(staticDir, 'assets'), { immutable: true, maxAge: '1y', fallthrough: true }));
        app.use(express.static(staticDir, { index: false, maxAge: '1h' }));
        const indexFile = join(staticDir, 'index.html');
        app.use((req, res, next) => {
            const isPage = (req.method === 'GET' || req.method === 'HEAD') && !req.path.includes('.');
            if (!isPage || !existsSync(indexFile))
                return next();
            res.set('Cache-Control', 'no-cache');
            res.sendFile(indexFile);
        });
    }
    app.use((_req, res) => {
        res.status(404).type('text/plain').send('Not found');
    });
    const onError = (err, _req, res, _next) => {
        if (err.type === 'entity.parse.failed')
            return sendErrors(res, 400, { form: 'The request was not valid JSON.' });
        if (err.type === 'entity.too.large')
            return sendErrors(res, 413, { form: 'The request is too large.' });
        console.error('Unexpected server error:', err instanceof Error ? err.message : 'unknown');
        sendErrors(res, 500, { form: 'Something went wrong on our side. Please try again.' });
    };
    app.use(onError);
    return app;
}
function isRecord(v) {
    return typeof v === 'object' && v !== null && !Array.isArray(v);
}
function confirmationView(booking, store) {
    const t = store.getTasting(booking.tastingId);
    return {
        reference: booking.reference,
        tasting: { id: t.id, title: t.title, startsAt: t.startsAt },
        guests: booking.guests,
        totalCents: t.priceCents * booking.guests,
        status: booking.status,
    };
}
