import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { BookingStore } from './store.js';
const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;
const bookingsFile = process.env.BOOKINGS_FILE || undefined;
// dist-server/server/index.js -> ../../dist
const staticDir = fileURLToPath(new URL('../../dist', import.meta.url));
/** TRUST_PROXY=<number of proxy hops in front of the app>; unset or 0 means no proxy. */
function trustProxyHops(value) {
    const hops = Number(value);
    return Number.isInteger(hops) && hops > 0 ? hops : 0;
}
let store;
try {
    store = new BookingStore({ file: bookingsFile });
}
catch (err) {
    console.error(err.message);
    process.exit(1);
}
const app = createApp({
    store,
    staffPassword,
    staticDir: process.env.NODE_ENV === 'development' ? undefined : staticDir,
    trustProxy: trustProxyHops(process.env.TRUST_PROXY),
});
if (process.env.NODE_ENV === 'production' && !process.env.TRUST_PROXY) {
    console.warn('TRUST_PROXY is not set: behind a TLS-terminating proxy the staff cookie will not be marked Secure.');
}
if (!staffPassword) {
    console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}
app.listen(port, () => {
    console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
    if (bookingsFile)
        console.log(`Bookings are persisted to ${bookingsFile}`);
});
