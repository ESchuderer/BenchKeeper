import { z } from 'zod';
export const MAX_GUESTS = 8;
export const GUESTS_MESSAGE = `Enter a whole number of guests between 1 and ${MAX_GUESTS}.`;
const guests = z.unknown().transform((value, ctx) => {
    let n = NaN;
    if (typeof value === 'number')
        n = value;
    else if (typeof value === 'string' && /^\s*\d+\s*$/.test(value))
        n = Number(value);
    if (!Number.isInteger(n) || n < 1 || n > MAX_GUESTS) {
        ctx.addIssue({ code: 'custom', message: GUESTS_MESSAGE });
        return z.NEVER;
    }
    return n;
});
const stringField = (label) => z.string({ error: `Enter your ${label}.` });
export const bookingInputSchema = z.object({
    name: stringField('name')
        .trim()
        .min(1, 'Enter your name.')
        .max(100, 'Please use at most 100 characters for your name.'),
    email: stringField('email address')
        .trim()
        .min(1, 'Enter your email address.')
        .max(254, 'This email address is too long.')
        .pipe(z.email('Enter a valid email address, for example name@example.com.')),
    guests,
});
