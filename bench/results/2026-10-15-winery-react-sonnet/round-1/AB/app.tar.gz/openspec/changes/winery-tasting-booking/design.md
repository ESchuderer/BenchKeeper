# Design

## Context

Greenfield repository: only OpenSpec scaffolding exists. Node.js 22 / npm 10 are available. The run contract is `npm install` → `npm run build` → `npm start` on `PORT`, one process, no external services. Requirements are in `specs/`; motivation in `proposal.md`.

## Goals / Non-Goals

**Goals:**
- One deployable Node process serving a React SPA and a small JSON API.
- Server-side authority for validation, seat accounting and auth; the client validates only for convenience and shows server errors identically.
- Boring, established libraries instead of hand-rolled replacements.

**Non-Goals:**
- Horizontal scaling or multi-process safety (a single process owns the bookings).
- A database, payments, email, staff-managed tastings.

## Decisions

**Stack: TypeScript everywhere; Vite + React 19 + React Router for the client; Express 5 for the server.**
Vite is the maintained standard for building React apps; React Router gives the `/`, `/tastings/:id/book`, `/booking/:reference`, `/staff` routes. Express is chosen over Fastify/Next.js for familiarity and because the API is tiny; Next.js would add a second runtime model for no gain. Alternatives: Next.js (heavier, SSR not needed), plain Node `http` (re-implements routing/body parsing).

**Layout.** `shared/` (Zod schemas, types, money/date formatting helpers) is imported by both `server/` and `src/`, so field rules exist once. `server/` is compiled with `tsc` to `dist-server/`; the client builds with Vite to `dist/`. `npm run build` runs both; `npm start` runs `node dist-server/index.js`, which serves `dist/` statically and falls back to `index.html` for any non-`/api` GET so deep links like `/staff` work. During development `npm run dev` runs Vite with an `/api` proxy and `tsx watch` for the server.

**Validation: Zod schema in `shared/`, used by React Hook Form (`@hookform/resolvers/zod`) on the client and by the API on the server.**
The form is `noValidate` so our messages (not browser bubbles) appear, each rendered under its field with `aria-invalid` and `aria-describedby`. Server errors have the shape `{ errors: { name?, email?, guests?, form? } }` and are mapped onto the same fields with `setError`, so a seat-limit rejection looks identical to a local validation error. "Guests" is `type="number"` but parsed from a string, so `""`, `2.5` and `abc` all produce a field error rather than silently coercing.

**Domain: a `BookingStore` class owning tastings and bookings; all mutations are synchronous.**
Node runs one JS thread, and `createBooking` checks seats left and inserts in one synchronous call, so concurrent HTTP requests cannot interleave between check and insert. This is simpler and safer than locks. Persistence (if `BOOKINGS_FILE`) is written after each mutation via write-to-temp-and-rename, so a crash cannot leave a half-written file; a failed write rolls the in-memory change back and returns 500 so memory and disk never disagree. Alternative: SQLite — rejected as unnecessary for a few dozen bookings and an extra native dependency. The clock is injected so "tasting already started" is testable.

**Tastings are seed data in code** (`shared/tastings.ts`): id slugs `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`; date/time stored as local-time strings (`2026-11-06T18:00`) for Europe/Berlin and displayed as written, never through `Date` time-zone conversion. The "already started" check interprets them as Europe/Berlin wall-clock time. Prices are stored as integer cents; the UI formats as `EUR 25` (no decimals when whole, `EUR 25.50` otherwise).

**Seats left wording.** Displayed exactly as specified, `<n> seats left`, for every n ≥ 1; 0 is "Fully booked". (`1 seats left` is grammatically off but is the literal format requested; changing to singular is a one-line change if the winery prefers it.)

**API.**
- `GET /api/tastings` → tastings with `seatsLeft`, `status` (`open | full | closed`).
- `POST /api/bookings` `{tastingId, name, email, guests}` → `201 {reference, tasting, guests, totalCents}` / `422 {errors}` (validation or seats; seat violations carry `errors.guests`) / `404` unknown tasting / `409` full-or-closed with `errors.form`.
- `GET /api/bookings/:reference` → public confirmation view (no name/email); includes `status: confirmed | cancelled`.
- `POST /api/staff/login` `{password}` / `POST /api/staff/logout` / `GET /api/staff/session`.
- `GET /api/staff/bookings` → bookings grouped by tasting; `DELETE /api/staff/bookings/:reference` → cancels (404 if missing/cancelled).
JSON bodies are limited to a few KB.

**Booking reference:** `KB-` + 8 characters from an unambiguous Crockford-style alphabet (no `0/O/1/I`), from `crypto.randomInt`, regenerated on collision. 40 bits is enough because the public view reveals no personal data.

**Staff auth: password check + server-side session in an httpOnly cookie.**
`STAFF_PASSWORD` is compared with `crypto.timingSafeEqual` over SHA-256 digests (equal length, no length leak). If the variable is unset/empty, login always fails. Success creates a random 256-bit session id kept in an in-memory `Map` and sent as `HttpOnly; SameSite=Strict; Path=/` cookie (plus `Secure` when the request is HTTPS / `NODE_ENV=production` behind a proxy with `trust proxy` configured by env), as a session cookie (no `Max-Age`), with a server-side idle expiry of 8 hours. `SameSite=Strict` plus requiring `application/json` on mutating requests covers CSRF for this API. Login is limited with `express-rate-limit` (e.g. 10 failed attempts per 15 minutes per IP). Sessions vanish on restart; staff simply sign in again. Alternative: HTTP Basic auth (no sign-in form with required labels, no logout) and JWT (revocation hassle) — rejected.

**Cancellation** marks a booking `cancelled` (kept in the store, for the confirmation page and an audit trail) and seats-left is computed as `capacity − sum(guests of confirmed bookings)`, so cancelling frees seats with no separate counter to keep in sync.

**Client structure.** `src/` has `api.ts` (fetch wrapper with typed errors), pages (`TastingsPage`, `BookingPage`, `ConfirmationPage`, `StaffPage`), and small components (`TastingCard`, `Field`, `Layout`, `Notice`). Server state is fetched with TanStack Query (caching, refetch-on-focus, loading/error states, mutation invalidation) rather than hand-rolled `useEffect` fetching. Alternative: plain `useEffect` — rejected as it re-implements that library.

**Styling: Tailwind CSS v4 (Vite plugin) with design tokens in `@theme`.** Palette: deep burgundy `#5b1a2b` (primary), warm cream background `#faf5ec`, vine green `#3f5b3a` (success), muted gold `#b08a3e` (accent), ink `#2a1d1d` text; errors in a red distinct from burgundy and always accompanied by an icon + text. Headings use a serif (self-hosted via `@fontsource/cormorant-garamond` or `@fontsource/fraunces`; no external CDN, so the app works offline and leaks no visitor data); body in system sans. Inputs 16 px font and 44 px min height. Mobile-first single column, tasting cards in a 2–3 column grid from `md`. Alternative: component libraries (MUI, etc.) — a generic look clashes with "small winery's own site".

**Security hardening.** `helmet` with a CSP allowing only self (the build emits no inline scripts); React escapes text; no `dangerouslySetInnerHTML`; passwords and session ids never logged; generic 500 errors without stack traces; `x-powered-by` off.

**Testing (tests first per group).** Vitest for `BookingStore` unit tests and shared schema tests; Supertest for the API (auth, validation, seat limit, concurrent `Promise.all` bookings, cancellation, persistence round-trip); React Testing Library (+ `user-event`) for forms and pages with a mocked API (MSW); Playwright for end-to-end flows against the built `npm start` (guest booking → confirmation, fully booked, staff login/cancel, 375 px viewport, axe accessibility check via `@axe-core/playwright`). If Playwright's browser cannot be installed offline, the e2e group falls back to the Supertest/RTL suites and the gap is stated in the final report.

## Risks / Trade-offs

- [Single-process in-memory state loses bookings on restart] → documented; `BOOKINGS_FILE` gives opt-in persistence; the app still never silently discards a corrupt file.
- [Concurrency safety depends on the mutation staying synchronous] → a regression test fires simultaneous bookings, and a code comment on `createBooking` states the invariant; file persistence uses synchronous write so it keeps the invariant.
- [Time-zone handling: "closed once started" depends on Europe/Berlin conversion] → implemented with `Intl.DateTimeFormat` for the zone, unit tested around the start instant and a DST-free winter/autumn date; display never converts.
- [In-memory sessions + rate limit keyed by IP behind a proxy] → `TRUST_PROXY=<hops>` (a hop count, never blanket `true`, which would let clients spoof `X-Forwarded-For` and dodge the limit); otherwise the limit is per-socket address.
- [Immediate "Cancel" with no confirmation can be mis-tapped] → chosen to keep one-click flow as specified; a notice names the cancelled booking. Not undoable in this version.
- [`1 seats left`] → see decision above.
- [Public `POST /api/bookings` has no rate limit, so a script could reserve every seat with fake bookings] → accepted for this version (no deposit or email verification in scope; staff can cancel; any limit would be arbitrary for a venue with 30 seats); revisit with email confirmation.
- [Public confirmation URL by reference] → reveals no name/email; unguessable reference.

## Assumptions (minor, recorded rather than asked)

- A tasting becomes unbookable at its start time; the winery is in Europe/Berlin.
- Duplicate bookings by the same email are allowed (families may book separately).
- One booking = one tasting; "Guests" counts all attendees including the booker.
- Total price is shown for information; payment happens at the winery.
