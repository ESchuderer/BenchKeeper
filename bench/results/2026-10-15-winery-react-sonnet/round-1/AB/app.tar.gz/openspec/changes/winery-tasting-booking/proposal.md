# Proposal

## Why

Weingut Kieselbrunnen takes tasting reservations informally today. Guests cannot see which tastings still have room, and staff have no single place to see who is coming. The winery needs a small website where guests book a tasting themselves and staff see and manage the bookings. The three winter tastings (Nov–Dec 2026) are about to go on sale.

## What Changes

- New web app (greenfield; the repo has no code yet): a React single-page interface served by a Node.js server with a JSON API.
- Guests see the three tastings with title, date and time, price per guest and seats left, and can open a booking form per tasting ("Book <tasting title>").
- The booking form (Name, Email, Guests 1–8) is validated; invalid input is rejected with an error next to the field it concerns. A booking can never take more seats than are left, even with concurrent requests.
- A successful booking shows a confirmation ("Booking confirmed") with the tasting, number of guests, total price and a booking reference.
- Staff sign in at `/staff` with a password taken from `STAFF_PASSWORD`, see all bookings grouped by tasting, and can cancel a booking, which frees its seats.
- A coherent winery look and feel with clear error, success and fully-booked states, usable on a phone.
- Bookings are kept in memory and can optionally be persisted to a local JSON file; no external services.

## Capabilities

### New Capabilities
- `tasting-catalog`: the fixed list of tastings and how it is presented to guests (title, date and time, price per guest, seats left, fully-booked state).
- `guest-booking`: the booking form, validation, seat limits, price calculation, booking reference and confirmation.
- `staff-bookings`: staff sign-in with the environment password, the bookings overview grouped by tasting, and cancellation that frees seats.
- `site-experience`: visual design, responsive behaviour, accessible states and the way the app is built, configured and served (build, start, `PORT`, `STAFF_PASSWORD`).

### Modified Capabilities
<!-- None: there are no existing specs. -->

## Impact

- New code: `server/` (Express API, booking store), `src/` (React app), `shared/` (validation schema and types used by both sides), tests, and project configuration (`package.json`, TypeScript, Vite).
- New dependencies, all established and maintained: React, React Router, Vite, Express, Zod, React Hook Form, Tailwind CSS, Helmet, express-rate-limit; Vitest, Testing Library and Supertest for tests.
- Configuration: `PORT` (default 3000), `STAFF_PASSWORD` (required for staff access), optional `BOOKINGS_FILE` for persistence.
- No external services, no database, no payment processing (the total price is informational; payment happens at the winery).

## Out of scope

Online payment, guest-initiated cancellation or changes, confirmation emails, tasting management by staff (the three tastings are fixed seed data), multiple staff accounts, and internationalisation (English only).
