# Spec Delta

## Purpose

Lets a guest reserve seats for a tasting through a validated booking form and receive a confirmation with a booking reference, while guaranteeing that a tasting is never overbooked.

## ADDED Requirements

### Requirement: Booking form
The booking form for a tasting SHALL show the tasting's title, date and time and price per guest, and SHALL have fields labelled "Name", "Email" and "Guests" and a button "Book". "Guests" SHALL start at 1.

#### Scenario: Form contents
- **WHEN** a guest opens the form for the Winter Tasting
- **THEN** the form names the Winter Tasting, shows 2026-12-05 17:00 and EUR 28, and has "Name", "Email" and "Guests" fields and a "Book" button

#### Scenario: Live total
- **WHEN** a guest enters 3 in "Guests" for the Winter Tasting
- **THEN** the form shows a total of EUR 84

### Requirement: Field validation
The system SHALL reject a booking unless Name is non-empty after trimming (at most 100 characters), Email is a syntactically valid address (at most 254 characters) and Guests is a whole number from 1 to 8. Each problem SHALL be reported with an error message next to the field it concerns, and the entered values SHALL stay in the form.

#### Scenario: Empty form
- **WHEN** a guest submits the form with "Name" and "Email" empty
- **THEN** an error appears next to "Name" and another next to "Email", and no booking is created

#### Scenario: Malformed email
- **WHEN** a guest enters "not-an-email" in "Email" and submits
- **THEN** an error appears next to "Email" and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest enters 0, 9, 2.5 or a non-number in "Guests" and submits
- **THEN** an error appears next to "Guests" and no booking is created

#### Scenario: Whitespace-only name
- **WHEN** a guest enters only spaces in "Name" and submits
- **THEN** an error appears next to "Name"

#### Scenario: Values kept
- **WHEN** a submission is rejected
- **THEN** the values the guest typed are still in the fields

### Requirement: Seat limit
A booking SHALL be accepted only if its number of guests is at most the seats left for that tasting at the moment it is processed. This SHALL hold regardless of what the client sends and for simultaneous requests.

#### Scenario: More guests than seats left
- **WHEN** 3 seats are left and a guest books 4
- **THEN** the booking is rejected with an error next to "Guests" that states how many seats are left, and no seats are taken

#### Scenario: Exactly the remaining seats
- **WHEN** 3 seats are left and a guest books 3
- **THEN** the booking is confirmed and the tasting becomes fully booked

#### Scenario: Simultaneous bookings for the last seats
- **WHEN** two requests for 5 guests each arrive at the same time and only 6 seats are left
- **THEN** exactly one is confirmed and the other is rejected, and the tasting never has fewer than 0 seats left

#### Scenario: Seats taken while the form was open
- **WHEN** the tasting fills up between the guest opening the form and submitting it
- **THEN** the submission is rejected with a message next to "Guests" and the displayed seats left are refreshed

#### Scenario: Direct API abuse
- **WHEN** a client submits a booking for a nonexistent tasting, more than 8 guests, or a non-integer guest count
- **THEN** the system rejects it and creates no booking

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (price per guest times guests, as "EUR <amount>") and a booking reference. The reference SHALL be unique per booking and hard to guess.

#### Scenario: Successful booking
- **WHEN** a guest books 2 guests for the Red Wine Cellar Tour with a valid name and email
- **THEN** a confirmation headed "Booking confirmed" shows "Red Wine Cellar Tour", 2 guests, "EUR 64" and a booking reference

#### Scenario: Seats are taken
- **WHEN** that booking is confirmed
- **THEN** the Red Wine Cellar Tour shows 6 seats left on the start page

#### Scenario: Unique references
- **WHEN** two bookings are made
- **THEN** they have different references

#### Scenario: Reloading the confirmation
- **WHEN** the guest reloads the confirmation page
- **THEN** the same confirmation is shown, without the guest's email address

#### Scenario: Cancelled booking reference
- **WHEN** a guest opens the confirmation page of a booking staff have cancelled
- **THEN** the page says the booking was cancelled and does not say "Booking confirmed"

### Requirement: Failure feedback
If a booking cannot be submitted because the server is unreachable or fails, the guest SHALL see a clear error message that does not lose the entered values, and the "Book" button SHALL be disabled while a submission is in flight so a double click cannot create two bookings.

#### Scenario: Double click
- **WHEN** a guest clicks "Book" twice quickly
- **THEN** only one booking is created

#### Scenario: Server error
- **WHEN** the server cannot be reached while submitting
- **THEN** an error message is shown, the form values remain and the guest can try again
