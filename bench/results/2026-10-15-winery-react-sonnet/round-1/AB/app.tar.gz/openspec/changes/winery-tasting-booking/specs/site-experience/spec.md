# Spec Delta

## Purpose

Defines the look, responsiveness and accessibility of the winery site and how the app is built, configured and served, so it can be run the same way everywhere.

## ADDED Requirements

### Requirement: Winery look and feel
All pages SHALL share one visual design that suits a small family winery: a consistent header with the name "Weingut Kieselbrunnen", a restrained wine-inspired colour palette, a serif display typeface for headings, consistent spacing, buttons and form styling, and a footer. All interface text SHALL be in English.

#### Scenario: Consistent identity
- **WHEN** a visitor moves between the start page, a booking form, the confirmation and `/staff`
- **THEN** each page shows the same header, typography and colours

### Requirement: Clear states
The interface SHALL make these states visually and textually distinct: field errors (next to the field, with an error colour and message text, not colour alone), form-level errors, success (the confirmation), loading, and fully-booked or closed tastings.

#### Scenario: Error not by colour alone
- **WHEN** a field fails validation
- **THEN** the field shows message text and is programmatically marked invalid and associated with that message

#### Scenario: Loading
- **WHEN** the tastings are still being fetched
- **THEN** a loading indicator is shown instead of an empty or broken list

#### Scenario: Load failure
- **WHEN** the tastings cannot be fetched
- **THEN** an error message with a "Try again" action is shown

### Requirement: Mobile friendly
Every page SHALL be usable on a phone-sized viewport (320 px wide and up) without horizontal scrolling, with touch targets at least 44 px high and form inputs large enough that mobile browsers do not zoom on focus.

#### Scenario: Phone layout
- **WHEN** the start page, booking form and staff overview are viewed at 375 px width
- **THEN** there is no horizontal scrolling and all actions are reachable

### Requirement: Accessibility basics
Every form control SHALL have a visible label that is programmatically associated with it, interactive elements SHALL be keyboard operable with a visible focus indicator, text contrast SHALL meet WCAG AA, and each page SHALL have a meaningful title and one main heading.

#### Scenario: Label association
- **WHEN** a user agent looks up the "Name", "Email", "Guests" and "Password" controls by their labels
- **THEN** each label resolves to exactly one control

### Requirement: Run configuration
`npm install`, `npm run build` and `npm start` SHALL produce and serve the whole app (interface and API) from one process on the port given by `PORT`, defaulting to 3000. The app SHALL start with no bookings. Reloading or directly opening any app URL, such as `/staff` or a booking form URL, SHALL work.

#### Scenario: Default port
- **WHEN** `npm start` runs without `PORT`
- **THEN** the app answers on port 3000

#### Scenario: Custom port
- **WHEN** `npm start` runs with `PORT=4123`
- **THEN** the app answers on port 4123

#### Scenario: Deep link
- **WHEN** a browser requests `/staff` directly
- **THEN** the staff sign-in page is served, not a 404

### Requirement: Optional booking persistence
If the environment variable `BOOKINGS_FILE` is set, the app SHALL store bookings in that local file and restore them on start; otherwise bookings SHALL be kept in memory only. A missing file SHALL mean no bookings, and a corrupt file SHALL stop the app with a clear message instead of silently discarding bookings.

#### Scenario: Restart with a file
- **WHEN** a booking is made, the app is restarted with the same `BOOKINGS_FILE`
- **THEN** the booking and the reduced seats left are still there

#### Scenario: No file configured
- **WHEN** the app is restarted without `BOOKINGS_FILE`
- **THEN** there are no bookings

### Requirement: Safe handling of input and secrets
The app SHALL escape all guest-supplied text when displaying it, SHALL NOT expose `STAFF_PASSWORD` or any session secret to the browser or in logs, and SHALL set standard security headers.

#### Scenario: Script in name
- **WHEN** a guest books with the name `<script>alert(1)</script>`
- **THEN** staff see that text literally and no script runs
