# Spec Delta

## Purpose

Gives winery staff a password-protected page to see all bookings grouped by tasting and to cancel bookings, freeing their seats.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a password in a "Password" field with a "Sign in" button. The correct password is the value of the environment variable `STAFF_PASSWORD`. A wrong password SHALL be rejected with an error message next to the field and grant no access. If `STAFF_PASSWORD` is unset or empty, nobody SHALL be able to sign in.

#### Scenario: Sign-in page
- **WHEN** an unauthenticated visitor opens `/staff`
- **THEN** they see a "Password" field and a "Sign in" button and no booking data

#### Scenario: Correct password
- **WHEN** the visitor enters the value of `STAFF_PASSWORD` and clicks "Sign in"
- **THEN** the bookings overview is shown

#### Scenario: Wrong password
- **WHEN** the visitor enters a different password
- **THEN** an error message is shown next to "Password" and no booking data is shown

#### Scenario: No password configured
- **WHEN** the app runs without `STAFF_PASSWORD` and someone submits any password, including an empty one
- **THEN** sign-in fails

#### Scenario: Repeated wrong passwords
- **WHEN** a client makes many failed sign-in attempts in a short time
- **THEN** further attempts are temporarily refused with a message saying to try again later

### Requirement: Protected booking data
All booking data that includes guest names or email addresses SHALL be available only to a signed-in staff member, including to direct requests to the underlying API. A session SHALL last until the staff member signs out or closes the browser, and a "Sign out" action SHALL end it.

#### Scenario: Unauthenticated API access
- **WHEN** a client requests the staff booking list or a cancellation without being signed in
- **THEN** the request is refused and no booking data is returned

#### Scenario: Reload while signed in
- **WHEN** a signed-in staff member reloads `/staff`
- **THEN** the overview is shown without asking for the password again

#### Scenario: Sign out
- **WHEN** a staff member clicks "Sign out"
- **THEN** `/staff` asks for the password again and the previous session no longer grants access

### Requirement: Bookings overview
A signed-in staff member SHALL see all active bookings grouped by tasting, in tasting order, each showing name, email, number of guests and booking reference. Each tasting group SHALL show the tasting's title and date and time, and how many of its seats are booked. A tasting without bookings SHALL be shown with an empty-state message.

#### Scenario: Grouped list
- **WHEN** Anna booked 2 guests for the Riesling Evening and Ben booked 4 for the Winter Tasting
- **THEN** the overview shows Anna's name, email, 2 guests and reference under "Riesling Evening", Ben's under "Winter Tasting", and an empty-state message under "Red Wine Cellar Tour"

#### Scenario: New booking appears
- **WHEN** a guest books while staff have the overview open and staff reload it
- **THEN** the new booking is listed

### Requirement: Cancel booking
Each booking in the overview SHALL have a "Cancel" button. Cancelling SHALL remove the booking from the overview, free its seats immediately for new guests, and show a notice naming the cancelled booking.

#### Scenario: Cancel frees seats
- **WHEN** the Riesling Evening has 9 seats left and staff cancel a booking of 3 guests
- **THEN** the booking disappears from the overview and the start page shows "12 seats left"

#### Scenario: Rebooking after cancellation
- **WHEN** a fully booked tasting has a booking cancelled
- **THEN** a guest can book the freed seats

#### Scenario: Cancelling twice
- **WHEN** a booking is already cancelled and a second cancel request for it arrives
- **THEN** the system answers that the booking no longer exists and frees no further seats

#### Scenario: Cancellation failure
- **WHEN** a cancellation fails because the server is unreachable or the session expired
- **THEN** staff see an error message and the booking remains listed
