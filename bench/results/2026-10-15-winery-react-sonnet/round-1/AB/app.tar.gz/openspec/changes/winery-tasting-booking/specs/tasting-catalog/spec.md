# Spec Delta

## Purpose

Defines which tastings Weingut Kieselbrunnen offers and how the start page presents them to guests, including how many seats are left and when a tasting is fully booked.

## ADDED Requirements

### Requirement: Fixed tasting offering
The system SHALL offer exactly these tastings, with seats counted per tasting: Riesling Evening (2026-11-06 18:00, EUR 25 per guest, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32 per guest, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28 per guest, 10 seats). Dates and times are winery local time and are never converted to the visitor's time zone.

#### Scenario: Fresh start
- **WHEN** the app starts with no stored bookings
- **THEN** all three tastings are offered with their full seat counts

#### Scenario: Time zone independence
- **WHEN** a guest views the start page from any time zone
- **THEN** the Riesling Evening is shown as 2026-11-06 at 18:00

### Requirement: Start page lists tastings
The start page SHALL list every tasting with its title, date and time, price per guest and seats left, in chronological order. Seats left SHALL be shown as "<n> seats left" and reflect all active bookings.

#### Scenario: Initial listing
- **WHEN** a guest opens the start page with no bookings
- **THEN** the page shows "Riesling Evening", "Red Wine Cellar Tour" and "Winter Tasting" with "EUR 25", "EUR 32" and "EUR 28" and "12 seats left", "8 seats left" and "10 seats left"

#### Scenario: Seats left after a booking
- **WHEN** 3 guests have booked the Riesling Evening
- **THEN** the start page shows "9 seats left" for the Riesling Evening and unchanged counts for the others

#### Scenario: Seats left after a cancellation
- **WHEN** a booking of 3 guests for the Riesling Evening is cancelled
- **THEN** the start page again counts those 3 seats as left

### Requirement: Book link per tasting
Each tasting that can be booked SHALL have a link or button named "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Opening a booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for the Riesling Evening opens and names the tasting

### Requirement: Fully booked tastings
A tasting with no seats left SHALL be clearly marked "Fully booked" on the start page and SHALL offer no booking link; its booking form, if opened directly, SHALL explain that the tasting is fully booked and offer no way to submit.

#### Scenario: Last seat taken
- **WHEN** the last seats of the Red Wine Cellar Tour are booked
- **THEN** the start page shows "Fully booked" for it and no "Book Red Wine Cellar Tour" link, while the other tastings stay bookable

#### Scenario: Direct visit to a full tasting's form
- **WHEN** a guest opens the booking form URL of a fully booked tasting
- **THEN** the page states the tasting is fully booked and shows no "Book" button

#### Scenario: Seats freed again
- **WHEN** a booking for a fully booked tasting is cancelled
- **THEN** the tasting is bookable again with the freed seats

### Requirement: Past tastings cannot be booked
A tasting whose start time has passed SHALL be marked as closed for booking and offer no booking link, and booking requests for it SHALL be rejected.

#### Scenario: Tasting already started
- **WHEN** the current time is after the start of a tasting
- **THEN** the start page shows it as closed and offers no booking link for it

### Requirement: Unknown tasting
A request for a tasting that does not exist SHALL show a clear "not found" page with a way back to the start page, and booking requests for it SHALL be rejected.

#### Scenario: Unknown booking URL
- **WHEN** a guest opens the booking form for a tasting that does not exist
- **THEN** a "not found" message with a link to the start page is shown
