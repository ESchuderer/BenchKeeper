# Tasks

## 1. Project scaffolding

- [x] 1.1 Create `package.json` (Node 22 engines, scripts `dev`, `build`, `start`, `test`, `test:e2e`, `typecheck`), TypeScript configs for client and server, Vite config with React and Tailwind, `.gitignore`; install dependencies and verify `npm install` and `npm run typecheck` succeed on an empty skeleton
- [x] 1.2 Add Vitest setup (node + jsdom projects), ESLint-free minimal test runner config and a smoke test; verify `npm test` runs and passes

## 2. Shared domain (tests first)

- [x] 2.1 Write failing tests for tasting seed data, money formatting (`EUR 25`, `EUR 84`, `EUR 25.50`), and the booking Zod schema (empty/whitespace name, malformed email, guests 0/9/2.5/"abc"/""), then implement `shared/` until they pass (specs: tasting-catalog, guest-booking field validation)

## 3. Booking store (tests first)

- [x] 3.1 Write failing `BookingStore` tests: seats left accounting, over-booking rejected, exact remaining seats accepted, unique references, cancel frees seats, double cancel, unknown tasting, closed after start (injected clock, Europe/Berlin), then implement `server/store.ts` until they pass
- [x] 3.2 Write failing persistence tests (round-trip via `BOOKINGS_FILE`, missing file = empty, corrupt file = clear startup error, failed write rolls back) and implement atomic file persistence; verify tests pass

## 4. HTTP API (tests first)

- [x] 4.1 Write failing Supertest tests for `GET /api/tastings`, `POST /api/bookings` (201, 422 per-field errors, seat-limit error on `guests`, 404, 409 full/closed, malformed JSON/oversized body), `GET /api/bookings/:reference` (no PII, cancelled status) and simultaneous bookings via `Promise.all`; implement the Express app until they pass
- [x] 4.2 Write failing tests for staff auth (login with `STAFF_PASSWORD`, wrong password, unset/empty password, cookie flags, logout invalidates session, protected routes return 401, login rate limit) and cancel (`DELETE`, 404 on repeat, seats freed); implement auth, sessions and staff routes until they pass
- [x] 4.3 Implement `server/index.ts` (read `PORT` default 3000 and `STAFF_PASSWORD`, helmet + CSP, static serving of `dist/` with SPA fallback for non-`/api` paths); verify with a test that `/staff` returns the app shell, unknown `/api/x` returns JSON 404, and no response or log contains the password

## 5. Guest interface (tests first)

- [x] 5.1 Set up the design system: Tailwind theme tokens, self-hosted fonts, `Layout` (header "Weingut Kieselbrunnen", footer), `Field`, `Button`, `Notice` components, router and TanStack Query provider; verify by a render test of the layout and a visual check in the browser at 375 px and desktop widths
- [x] 5.2 Write failing RTL tests for the start page (title, `2026-11-06 18:00`, `EUR 25`, `12 seats left`, "Book Riesling Evening" link, "Fully booked" with no link, loading and retry-on-error states), then implement `TastingsPage` and `TastingCard` until they pass
- [x] 5.3 Write failing RTL tests for the booking form (labels Name/Email/Guests, button "Book", per-field errors with `aria-invalid`/`aria-describedby`, values retained, live total, server seat-limit error shown next to Guests and seats refreshed, double-click guard, network error, fully-booked and not-found variants), then implement `BookingPage` until they pass
- [x] 5.4 Write failing RTL tests for the confirmation page (heading "Booking confirmed", tasting, guests, total, reference, reload-safe, cancelled variant), then implement `ConfirmationPage` and the redirect after a successful booking until they pass

## 6. Staff interface (tests first)

- [x] 6.1 Write failing RTL tests for `/staff` (sign-in form with "Password"/"Sign in", wrong-password error next to field, bookings grouped by tasting with name/email/guests/reference, empty state per tasting, "Cancel" removes the booking and shows a notice, failure keeps the booking and shows an error, "Sign out"), then implement `StaffPage` until they pass

## 7. End-to-end verification and polish

- [x] 7.1 Add Playwright e2e tests against the built app (`npm run build && npm start` with `STAFF_PASSWORD` set and a test `PORT`): guest books and sees confirmation; seat counts update; booking more than seats left is rejected next to Guests; tasting fills to "Fully booked"; staff sign-in, list, cancel frees seats; deep link `/staff`; 375 px viewport without horizontal scroll; `@axe-core/playwright` finds no serious violations. Verify all pass (if browsers can't be installed, record that and run the same flows by script against the running server)
- [x] 7.2 Manually run the real app with `npm run build && PORT=3456 STAFF_PASSWORD=secret npm start`, walk the guest and staff flows in a browser, take screenshots at phone and desktop width, and fix any visual defects found
- [x] 7.3 Write `README.md` (run instructions, env vars `PORT`, `STAFF_PASSWORD`, `BOOKINGS_FILE`, tests, project layout) and verify each documented command works exactly as written from a clean `npm ci`
- [x] 7.4 Run the full suite (`npm run typecheck && npm test && npm run build && npm run test:e2e`) and `openspec validate winery-tasting-booking --strict`; verify everything is green

## Workflow follow-up

- Review the finished implementation (`/code-review`, `/simplify`, `/security-review`) before committing.
- Archive the change (`openspec-archive-change`) once the review is satisfied.
