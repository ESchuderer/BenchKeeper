import { defineConfig, devices } from '@playwright/test';

// Each test starts its own app instance (see tests/e2e/fixtures.ts), so no webServer here.
// Run `npm run build` first.
export default defineConfig({
  testDir: 'tests/e2e',
  fullyParallel: true,
  reporter: [['list']],
  use: { ...devices['Desktop Chrome'], trace: 'retain-on-failure' },
});
