import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

const IDLE_TIMEOUT_MS = 8 * 60 * 60 * 1000;

/** Compares via SHA-256 digests so neither content nor length of the secret leaks through timing. */
export function passwordMatches(candidate: unknown, expected: string | undefined): boolean {
  if (!expected || typeof candidate !== 'string') return false;
  const a = createHash('sha256').update(candidate).digest();
  const b = createHash('sha256').update(expected).digest();
  return timingSafeEqual(a, b);
}

/** In-memory staff sessions with idle expiry. They end on restart; staff just sign in again. */
export class SessionStore {
  private readonly sessions = new Map<string, number>();

  constructor(private readonly now: () => Date = () => new Date()) {}

  create(): string {
    this.sweep();
    const id = randomBytes(32).toString('base64url');
    this.sessions.set(id, this.now().getTime());
    return id;
  }

  /** True while the session exists and was used within the idle timeout; refreshes the timeout. */
  touch(id: unknown): boolean {
    if (typeof id !== 'string') return false;
    const last = this.sessions.get(id);
    if (last === undefined) return false;
    const t = this.now().getTime();
    if (t - last > IDLE_TIMEOUT_MS) {
      this.sessions.delete(id);
      return false;
    }
    this.sessions.set(id, t);
    return true;
  }

  destroy(id: unknown): void {
    if (typeof id === 'string') this.sessions.delete(id);
  }

  private sweep(): void {
    const t = this.now().getTime();
    for (const [id, last] of this.sessions) if (t - last > IDLE_TIMEOUT_MS) this.sessions.delete(id);
  }
}
