import { randomInt } from 'node:crypto';
import { closeSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, unlinkSync, writeSync } from 'node:fs';
import { dirname } from 'node:path';
import { z } from 'zod';
import type { BookingInput } from '../shared/booking.js';
import { TASTINGS, findTasting, hasStarted, type Tasting, type TastingStatus } from '../shared/tastings.js';

export type BookingStatus = 'confirmed' | 'cancelled';

const bookingSchema = z.object({
  reference: z.string().min(1),
  tastingId: z.string().min(1),
  name: z.string(),
  email: z.string(),
  guests: z.number().int().min(1),
  createdAt: z.string(),
  status: z.enum(['confirmed', 'cancelled']),
  cancelledAt: z.string().optional(),
});
export type Booking = z.infer<typeof bookingSchema>;

const fileSchema = z.object({ version: z.literal(1), bookings: z.array(bookingSchema) });


export interface TastingView extends Tasting {
  seatsLeft: number;
  status: TastingStatus;
}

export type CreateResult =
  | { ok: true; booking: Booking }
  | { ok: false; code: 'unknown_tasting' }
  | { ok: false; code: 'closed' | 'full' | 'not_enough_seats'; seatsLeft: number };

export interface StoreOptions {
  /** Persist bookings to this file; in-memory only when omitted. */
  file?: string;
  now?: () => Date;
  generateReference?: () => string;
}

// Unambiguous alphabet: no 0/O, 1/I.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function randomReference(): string {
  let s = 'KB-';
  for (let i = 0; i < 8; i++) s += ALPHABET[randomInt(ALPHABET.length)];
  return s;
}

export class BookingStore {
  private readonly bookings = new Map<string, Booking>();
  private readonly file: string | undefined;
  private readonly now: () => Date;
  private readonly generateReference: () => string;

  constructor(options: StoreOptions = {}) {
    this.file = options.file;
    this.now = options.now ?? (() => new Date());
    this.generateReference = options.generateReference ?? randomReference;
    if (this.file) this.load(this.file);
  }

  listTastings(): TastingView[] {
    return TASTINGS.map((t) => this.view(t));
  }

  getTasting(id: string): TastingView | undefined {
    const t = findTasting(id);
    return t && this.view(t);
  }

  getBooking(reference: string): Booking | undefined {
    return this.bookings.get(reference);
  }

  /** Active (not cancelled) bookings in the order they were made. */
  listActiveBookings(): Booking[] {
    return [...this.bookings.values()].filter((b) => b.status === 'confirmed');
  }

  /**
   * INVARIANT: the seat check and the insert happen in one synchronous call (no `await`
   * in between), so concurrent requests can never both see the same free seats.
   */
  createBooking(tastingId: string, input: BookingInput): CreateResult {
    const tasting = findTasting(tastingId);
    if (!tasting) return { ok: false, code: 'unknown_tasting' };
    const seatsLeft = this.seatsLeft(tasting);
    if (hasStarted(tasting, this.now())) return { ok: false, code: 'closed', seatsLeft };
    if (seatsLeft === 0) return { ok: false, code: 'full', seatsLeft };
    if (input.guests > seatsLeft) return { ok: false, code: 'not_enough_seats', seatsLeft };

    let reference = this.generateReference();
    while (this.bookings.has(reference)) reference = this.generateReference();
    const booking: Booking = {
      reference,
      tastingId,
      name: input.name,
      email: input.email,
      guests: input.guests,
      createdAt: this.now().toISOString(),
      status: 'confirmed',
    };
    this.bookings.set(reference, booking);
    try {
      this.save();
    } catch (err) {
      this.bookings.delete(reference);
      throw err;
    }
    return { ok: true, booking };
  }

  /** Returns false when the booking does not exist or is already cancelled. */
  cancelBooking(reference: string): boolean {
    const booking = this.bookings.get(reference);
    if (!booking || booking.status === 'cancelled') return false;
    this.bookings.set(reference, { ...booking, status: 'cancelled', cancelledAt: this.now().toISOString() });
    try {
      this.save();
    } catch (err) {
      this.bookings.set(reference, booking);
      throw err;
    }
    return true;
  }

  private seatsLeft(tasting: Tasting): number {
    let taken = 0;
    for (const b of this.bookings.values()) if (b.status === 'confirmed' && b.tastingId === tasting.id) taken += b.guests;
    return Math.max(0, tasting.capacity - taken);
  }

  private view(tasting: Tasting): TastingView {
    const seatsLeft = this.seatsLeft(tasting);
    const status: TastingStatus = hasStarted(tasting, this.now()) ? 'closed' : seatsLeft === 0 ? 'full' : 'open';
    return { ...tasting, seatsLeft, status };
  }

  private load(file: string): void {
    let raw: string;
    try {
      raw = readFileSync(file, 'utf8');
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return;
      throw new Error(`Cannot read the bookings file ${file}: ${(err as Error).message}`);
    }
    const parsed = fileSchema.safeParse(safeJson(raw));
    if (!parsed.success) {
      throw new Error(
        `The bookings file ${file} is corrupt or has an unexpected format. Fix or remove it (it has not been modified).`,
      );
    }
    for (const b of parsed.data.bookings) {
      if (!findTasting(b.tastingId)) {
        throw new Error(
          `The bookings file ${file} contains booking ${b.reference} for the unknown tasting "${b.tastingId}". Fix or remove it (it has not been modified).`,
        );
      }
      this.bookings.set(b.reference, b);
    }
  }

  private save(): void {
    if (!this.file) return;
    const tmp = `${this.file}.${process.pid}.tmp`;
    mkdirSync(dirname(this.file), { recursive: true, mode: 0o700 });
    try {
      const fd = openSync(tmp, 'w', 0o600); // guest names and emails: owner-only
      try {
        writeSync(fd, JSON.stringify({ version: 1, bookings: [...this.bookings.values()] }, null, 2));
        fsyncSync(fd); // data on disk before the rename makes it visible
      } finally {
        closeSync(fd);
      }
      renameSync(tmp, this.file);
    } catch (err) {
      try {
        unlinkSync(tmp);
      } catch {
        /* nothing to clean up */
      }
      throw err;
    }
  }
}

function safeJson(raw: string): unknown {
  try {
    return JSON.parse(raw);
  } catch {
    return undefined;
  }
}
