/** 2500 -> "EUR 25", 2550 -> "EUR 25.50" */
export function formatEur(cents: number): string {
  const euros = cents / 100;
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`;
}
