export interface Tasting {
  id: string;
  title: string;
  /** Winery local time (Europe/Berlin) as `YYYY-MM-DDTHH:mm`; never converted for display. */
  startsAt: string;
  priceCents: number;
  capacity: number;
}

export const WINERY_TIME_ZONE = 'Europe/Berlin';

export const TASTINGS: readonly Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceCents: 2500, capacity: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceCents: 3200, capacity: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceCents: 2800, capacity: 10 },
];

export function findTasting(id: string): Tasting | undefined {
  return TASTINGS.find((t) => t.id === id);
}

/** `2026-11-06T18:00` -> `2026-11-06 18:00` */
export function formatDateTime(startsAt: string): string {
  return startsAt.replace('T', ' ');
}

const wallClock = new Intl.DateTimeFormat('en-CA', {
  timeZone: WINERY_TIME_ZONE,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});

/** The winery's current wall-clock time as `YYYY-MM-DDTHH:mm`. */
export function wineryWallClock(now: Date): string {
  const p = Object.fromEntries(wallClock.formatToParts(now).map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;
}

export function hasStarted(tasting: Pick<Tasting, 'startsAt'>, now: Date): boolean {
  return wineryWallClock(now) >= tasting.startsAt;
}

export type TastingStatus = 'open' | 'full' | 'closed';
