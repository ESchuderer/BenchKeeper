import { Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { NotFound } from './components/NotFound';
import { BookingPage } from './pages/BookingPage';
import { ConfirmationPage } from './pages/ConfirmationPage';
import { StaffPage } from './pages/StaffPage';
import { TastingsPage } from './pages/TastingsPage';

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingsPage />} />
        <Route path="tastings/:id/book" element={<BookingPage />} />
        <Route path="booking/:reference" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
