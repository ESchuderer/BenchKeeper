import type { FieldErrors } from '../shared/booking';
import type { TastingStatus } from '../shared/tastings';

export interface TastingDto {
  id: string;
  title: string;
  startsAt: string;
  priceCents: number;
  capacity: number;
  seatsLeft: number;
  status: TastingStatus;
}

export interface ConfirmationDto {
  reference: string;
  tasting: { id: string; title: string; startsAt: string };
  guests: number;
  totalCents: number;
  status: 'confirmed' | 'cancelled';
}

export interface StaffBookingDto {
  reference: string;
  name: string;
  email: string;
  guests: number;
  createdAt: string;
}

export interface StaffTastingDto {
  id: string;
  title: string;
  startsAt: string;
  capacity: number;
  seatsBooked: number;
  bookings: StaffBookingDto[];
}

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly errors: FieldErrors,
    public readonly seatsLeft?: number,
  ) {
    super(errors.form ?? errors.guests ?? `Request failed (${status})`);
  }
  /** The server could not be reached at all. */
  get isNetwork() {
    return this.status === 0;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      ...init,
      credentials: 'same-origin',
      headers: init?.body ? { 'Content-Type': 'application/json' } : undefined,
    });
  } catch {
    throw new ApiError(0, { form: 'We could not reach the server. Please check your connection and try again.' });
  }
  if (res.status === 204) return undefined as T;
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    /* non-JSON body */
  }
  if (!res.ok) {
    const b = (body ?? {}) as { errors?: FieldErrors; seatsLeft?: number };
    throw new ApiError(
      res.status,
      b.errors ?? { form: 'Something went wrong. Please try again.' },
      b.seatsLeft,
    );
  }
  return body as T;
}

const json = (method: string, data?: unknown): RequestInit => ({
  method,
  body: data === undefined ? undefined : JSON.stringify(data),
});

export const api = {
  tastings: () => request<{ tastings: TastingDto[] }>('/api/tastings').then((r) => r.tastings),
  createBooking: (data: { tastingId: string; name: string; email: string; guests: number }) =>
    request<ConfirmationDto>('/api/bookings', json('POST', data)),
  booking: (reference: string) => request<ConfirmationDto>(`/api/bookings/${encodeURIComponent(reference)}`),
  staffLogin: (password: string) => request<{ ok: true }>('/api/staff/login', json('POST', { password })),
  staffLogout: () => request<void>('/api/staff/logout', json('POST')),
  staffBookings: () => request<{ tastings: StaffTastingDto[] }>('/api/staff/bookings').then((r) => r.tastings),
  staffCancel: (reference: string) =>
    request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, json('DELETE')),
};
