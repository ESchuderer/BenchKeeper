import { useId, type InputHTMLAttributes, type Ref } from 'react';
import { AlertIcon } from './Icons';

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string | undefined;
  hint?: string;
  ref?: Ref<HTMLInputElement>;
}

/** Label + input + inline error, wired together for assistive technology. */
export function Field({ label, error, hint, className, ref, ...input }: FieldProps) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [hint ? hintId : null, error ? errorId : null].filter(Boolean).join(' ') || undefined;
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-base font-semibold text-wine-900">
        {label}
      </label>
      {hint && (
        <p id={hintId} className="mb-1 text-sm text-muted">
          {hint}
        </p>
      )}
      <input
        {...input}
        ref={ref}
        id={id}
        className={`input ${className ?? ''}`}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
      />
      {error && (
        <p id={errorId} className="mt-1.5 flex items-start gap-1.5 text-sm font-semibold text-danger-700">
          <AlertIcon className="mt-0.5 shrink-0" width={16} height={16} />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}
