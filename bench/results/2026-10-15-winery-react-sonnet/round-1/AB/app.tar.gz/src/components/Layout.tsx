import { Link, Outlet } from 'react-router-dom';
import { GlassIcon } from './Icons';

export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-10 focus:rounded focus:bg-cream-50 focus:px-3 focus:py-2">
        Skip to content
      </a>
      <header className="bg-wine-800 text-cream-50">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <Link to="/" className="flex min-h-11 items-center gap-3 text-cream-50 no-underline">
            <span className="text-gold-500"><GlassIcon /></span>
            <span className="font-display text-xl font-semibold tracking-wide sm:text-2xl">Weingut Kieselbrunnen</span>
          </Link>
          <nav aria-label="Main">
            <Link to="/" className="inline-flex min-h-11 items-center whitespace-nowrap px-2 text-sm font-semibold text-cream-100 underline-offset-4 hover:underline">
              Tastings
            </Link>
          </nav>
        </div>
        <div aria-hidden="true" className="h-1 bg-gold-500" />
      </header>
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        <Outlet />
      </main>
      <footer className="border-t border-cream-300 bg-cream-200">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-x-6 gap-y-1 px-4 py-5 text-sm text-muted sm:px-6">
          <p>Weingut Kieselbrunnen · a family winery</p>
          <Link to="/staff" className="inline-flex min-h-11 items-center text-muted underline underline-offset-4">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
