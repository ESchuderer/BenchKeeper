import { Link } from 'react-router-dom';
import { usePageTitle } from '../usePageTitle';

export function NotFound({ what = 'page' }: { what?: string }) {
  usePageTitle('Not found');
  return (
    <section className="mx-auto max-w-xl py-10 text-center">
      <h1 className="text-4xl">{what[0]!.toUpperCase() + what.slice(1)} not found</h1>
      <p className="mt-4 text-lg text-muted">We couldn’t find what you were looking for. The link may be mistyped or out of date.</p>
      <Link to="/" className="btn btn-primary mt-8">
        Back to the tastings
      </Link>
    </section>
  );
}
