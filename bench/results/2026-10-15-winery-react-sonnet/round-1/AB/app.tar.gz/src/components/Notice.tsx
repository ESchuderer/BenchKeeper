import type { ReactNode } from 'react';
import { AlertIcon, CheckIcon, InfoIcon } from './Icons';

type Variant = 'error' | 'success' | 'info';

const styles: Record<Variant, string> = {
  error: 'border-danger-700 bg-danger-100 text-danger-700',
  success: 'border-vine-700 bg-vine-100 text-vine-800',
  info: 'border-gold-500 bg-cream-200 text-gold-800',
};

export function Notice({ variant, children, onDismiss }: { variant: Variant; children: ReactNode; onDismiss?: () => void }) {
  const Icon = variant === 'error' ? AlertIcon : variant === 'success' ? CheckIcon : InfoIcon;
  return (
    <div
      role={variant === 'error' ? 'alert' : 'status'}
      className={`flex items-start gap-3 rounded-lg border-l-4 px-4 py-3 text-base font-medium ${styles[variant]}`}
    >
      <Icon className="mt-0.5 shrink-0" />
      <div className="min-w-0 flex-1">{children}</div>
      {onDismiss && (
        <button type="button" onClick={onDismiss} className="-my-1 -mr-2 min-h-11 min-w-11 cursor-pointer rounded text-sm font-semibold underline">
          Dismiss
        </button>
      )}
    </div>
  );
}
