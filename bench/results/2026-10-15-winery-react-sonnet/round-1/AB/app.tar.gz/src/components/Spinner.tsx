export function Spinner({ label = 'Loading…' }: { label?: string }) {
  return (
    <div role="status" className="flex items-center justify-center gap-3 py-16 text-muted">
      <span aria-hidden="true" className="size-6 animate-spin rounded-full border-[3px] border-cream-300 border-t-wine-700" />
      <span>{label}</span>
    </div>
  );
}
