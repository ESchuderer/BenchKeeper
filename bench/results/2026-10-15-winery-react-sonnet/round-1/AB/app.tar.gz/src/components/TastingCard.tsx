import { Link } from 'react-router-dom';
import type { TastingDto } from '../api';
import { formatDateTime, formatEur, weekday } from '../format';
import { AlertIcon, CheckIcon } from './Icons';

export function SeatsBadge({ tasting }: { tasting: Pick<TastingDto, 'status' | 'seatsLeft'> }) {
  if (tasting.status === 'closed') {
    return <span className="badge bg-cream-200 text-muted">Booking closed</span>;
  }
  if (tasting.status === 'full') {
    return (
      <span className="badge bg-danger-100 text-danger-700">
        <AlertIcon width={16} height={16} />
        Fully booked
      </span>
    );
  }
  const scarce = tasting.seatsLeft <= 3;
  return (
    <span className={`badge ${scarce ? 'bg-cream-200 text-gold-800' : 'bg-vine-100 text-vine-800'}`}>
      <CheckIcon width={16} height={16} />
      {tasting.seatsLeft} seats left
    </span>
  );
}

export function TastingCard({ tasting }: { tasting: TastingDto }) {
  const headingId = `tasting-${tasting.id}`;
  const open = tasting.status === 'open';
  return (
    <article aria-labelledby={headingId} className={`card flex flex-col p-5 sm:p-6 ${open ? '' : 'opacity-90'}`}>
      <p className="text-sm font-semibold uppercase tracking-wider text-gold-800">{weekday(tasting.startsAt)}</p>
      <h2 id={headingId} className="mt-1 text-2xl">
        {tasting.title}
      </h2>
      <dl className="mt-4 space-y-1 text-base">
        <div className="flex gap-2">
          <dt className="sr-only">Date and time</dt>
          <dd className="font-semibold">
            <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time>
          </dd>
        </div>
        <div className="flex gap-2">
          <dt className="sr-only">Price</dt>
          <dd>
            <span className="font-semibold">{formatEur(tasting.priceCents)}</span> <span className="text-muted">per guest</span>
          </dd>
        </div>
      </dl>
      <div className="mt-4">
        <SeatsBadge tasting={tasting} />
      </div>
      {open && (
        <div className="mt-auto pt-6">
          <Link to={`/tastings/${tasting.id}/book`} className="btn btn-primary w-full">
            Book {tasting.title}
          </Link>
        </div>
      )}
    </article>
  );
}
