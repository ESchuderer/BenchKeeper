export { formatEur } from '../shared/money';
export { formatDateTime } from '../shared/tastings';

/** "2026-11-06T18:00" -> "Fri" (weekday of the calendar date, independent of time zone) */
export function weekday(startsAt: string): string {
  const [y, m, d] = startsAt.slice(0, 10).split('-').map(Number);
  return new Date(Date.UTC(y!, m! - 1, d!)).toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
}
