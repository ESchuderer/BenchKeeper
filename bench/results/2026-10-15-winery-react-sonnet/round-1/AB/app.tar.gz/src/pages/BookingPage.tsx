import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate, useParams } from 'react-router-dom';
import type { z } from 'zod';
import { MAX_GUESTS, bookingInputSchema, type BookingInput } from '../../shared/booking';
import { ApiError, api, type TastingDto } from '../api';
import { Field } from '../components/Field';
import { NotFound } from '../components/NotFound';
import { Notice } from '../components/Notice';
import { Spinner } from '../components/Spinner';
import { SeatsBadge } from '../components/TastingCard';
import { formatDateTime, formatEur } from '../format';
import { bookingKey, tastingsKey, useTastings } from '../queries';
import { usePageTitle } from '../usePageTitle';

type FormValues = z.input<typeof bookingInputSchema>;

export function BookingPage() {
  const { id = '' } = useParams();
  const { data, isPending, isError, refetch } = useTastings();
  const tasting = data?.find((t) => t.id === id);
  // Once the form has been shown for this tasting it stays, so a rejection ("just fully booked")
  // is explained next to the field instead of replacing the form.
  const [shownFor, setShownFor] = useState<string | null>(null);
  const formShown = shownFor === id;
  const open = tasting?.status === 'open';
  useEffect(() => {
    if (open) setShownFor(id);
  }, [open, id]);
  usePageTitle(tasting ? `Book ${tasting.title}` : 'Book a tasting');

  if (isPending) return <Spinner label="Loading tasting…" />;
  // A failed background refetch keeps the cached data; do not throw the user's form away for it.
  if (isError && !data) {
    return (
      <div className="max-w-xl space-y-3">
        <Notice variant="error">We could not load the tasting. Please try again.</Notice>
        <button type="button" className="btn btn-secondary" onClick={() => refetch()}>
          Try again
        </button>
      </div>
    );
  }
  if (!tasting) return <NotFound what="tasting" />;

  if (!formShown && !open) {
    return (
      <section className="mx-auto max-w-xl">
        <h1 className="text-4xl">{tasting.title}</h1>
        <p className="mt-2 text-lg font-semibold">
          <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time>
        </p>
        <div className="mt-6">
          <Notice variant="info">
            {tasting.status === 'full'
              ? 'Sorry, this tasting is fully booked.'
              : 'Booking for this tasting is closed because it has already started.'}
          </Notice>
        </div>
        <Link to="/" className="btn btn-primary mt-8">
          See other tastings
        </Link>
      </section>
    );
  }

  return <BookingForm key={tasting.id} tasting={tasting} />;
}

function BookingForm({ tasting }: { tasting: TastingDto }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const inFlight = useRef(false);
  const [formError, setFormError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<FormValues, unknown, BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '', guests: '1' },
  });

  const mutation = useMutation({
    mutationFn: api.createBooking,
    onSuccess: (confirmation) => {
      queryClient.setQueryData(bookingKey(confirmation.reference), confirmation);
      void queryClient.invalidateQueries({ queryKey: tastingsKey });
      navigate(`/booking/${confirmation.reference}`);
    },
    onError: (err) => {
      const e = err instanceof ApiError ? err : new ApiError(0, { form: 'Something went wrong. Please try again.' });
      for (const field of ['name', 'email', 'guests'] as const) {
        const message = e.errors[field];
        if (message) setError(field, { type: 'server', message }, { shouldFocus: true });
      }
      setFormError(e.errors.form ?? null);
      if (e.seatsLeft !== undefined || e.status === 404 || e.status === 409) {
        void queryClient.invalidateQueries({ queryKey: tastingsKey });
      }
    },
    onSettled: () => {
      inFlight.current = false;
    },
  });

  const onSubmit = async (input: BookingInput) => {
    if (inFlight.current) return;
    inFlight.current = true;
    setFormError(null);
    mutation.mutate({ tastingId: tasting.id, ...input });
  };

  const guests = Number(watch('guests'));
  const validGuests = Number.isInteger(guests) && guests >= 1 && guests <= MAX_GUESTS;
  const maxGuests = Math.max(1, Math.min(MAX_GUESTS, tasting.seatsLeft));
  const busy = isSubmitting || mutation.isPending;

  return (
    <div className="mx-auto max-w-xl">
      <Link to="/" className="inline-flex min-h-11 items-center text-sm font-semibold text-wine-700 underline underline-offset-4">
        ← All tastings
      </Link>
      <h1 className="mt-2 text-4xl">{tasting.title}</h1>
      <dl className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-lg">
        <div>
          <dt className="sr-only">Date and time</dt>
          <dd className="font-semibold">
            <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time>
          </dd>
        </div>
        <div>
          <dt className="sr-only">Price</dt>
          <dd>
            <span className="font-semibold">{formatEur(tasting.priceCents)}</span> <span className="text-muted">per guest</span>
          </dd>
        </div>
        <div>
          <dt className="sr-only">Availability</dt>
          <dd>
            <SeatsBadge tasting={tasting} />
          </dd>
        </div>
      </dl>

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="card mt-6 space-y-5 p-5 sm:p-7" aria-label={`Book ${tasting.title}`}>
        {formError && <Notice variant="error">{formError}</Notice>}
        <Field label="Name" type="text" autoComplete="name" error={errors.name?.message} {...register('name')} />
        <Field label="Email" type="email" autoComplete="email" inputMode="email" error={errors.email?.message} {...register('email')} />
        <Field
          label="Guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={maxGuests}
          step={1}
          hint={
            tasting.status === 'open'
              ? `Between 1 and ${maxGuests} · ${tasting.seatsLeft} ${tasting.seatsLeft === 1 ? 'seat' : 'seats'} left`
              : `Between 1 and ${MAX_GUESTS}`
          }
          error={errors.guests?.message}
          {...register('guests')}
        />
        <div className="flex items-baseline justify-between gap-4 border-t border-cream-300 pt-4" aria-live="polite">
          <span className="text-muted">Total</span>
          <span className="font-display text-2xl font-semibold text-wine-800">
            {validGuests ? formatEur(tasting.priceCents * guests) : '–'}
          </span>
        </div>
        <button type="submit" className="btn btn-primary w-full" disabled={busy} aria-busy={busy}>
          {busy ? 'Booking…' : 'Book'}
        </button>
        <p className="text-center text-sm text-muted">You pay at the winery. No payment is taken online.</p>
      </form>
    </div>
  );
}
