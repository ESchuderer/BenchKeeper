import { useQuery } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import { ApiError, api } from '../api';
import { AlertIcon, CheckIcon } from '../components/Icons';
import { NotFound } from '../components/NotFound';
import { Notice } from '../components/Notice';
import { Spinner } from '../components/Spinner';
import { formatDateTime, formatEur } from '../format';
import { bookingKey } from '../queries';
import { usePageTitle } from '../usePageTitle';

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const { data, isPending, error, refetch } = useQuery({
    queryKey: bookingKey(reference),
    queryFn: () => api.booking(reference),
  });
  const cancelled = data?.status === 'cancelled';
  usePageTitle(cancelled ? 'Booking cancelled' : 'Booking confirmed');

  if (isPending && !error) return <Spinner label="Loading your booking…" />;
  if (error instanceof ApiError && error.status === 404) return <NotFound what="booking" />;
  if (!data) {
    return (
      <div className="max-w-xl space-y-3">
        <Notice variant="error">We could not load your booking. Please try again.</Notice>
        <button type="button" className="btn btn-secondary" onClick={() => refetch()}>
          Try again
        </button>
      </div>
    );
  }

  return (
    <section className="mx-auto max-w-xl">
      <div className={`card overflow-hidden border-t-4 ${cancelled ? 'border-t-danger-700' : 'border-t-vine-700'}`}>
        <div className="p-6 sm:p-8">
          <div className={`flex items-center gap-3 ${cancelled ? 'text-danger-700' : 'text-vine-700'}`}>
            {cancelled ? <AlertIcon width={32} height={32} /> : <CheckIcon width={32} height={32} />}
            <h1 className={`text-3xl sm:text-4xl ${cancelled ? 'text-danger-700!' : 'text-vine-800!'}`}>
              {cancelled ? 'Booking cancelled' : 'Booking confirmed'}
            </h1>
          </div>
          <p className="mt-3 text-muted">
            {cancelled
              ? 'This booking has been cancelled and its seats were released.'
              : 'Thank you! Your seats are reserved. Please keep your booking reference.'}
          </p>
          <dl className="mt-6 divide-y divide-cream-300 text-base">
            <Row label="Tasting" value={data.tasting.title} />
            <Row label="Date and time" value={formatDateTime(data.tasting.startsAt)} />
            <Row label="Guests" value={String(data.guests)} />
            <Row label="Total price" value={formatEur(data.totalCents)} strong />
            <Row label="Booking reference" value={data.reference} mono />
          </dl>
          {!cancelled && <p className="mt-6 text-sm text-muted">Payment is made at the winery on the day of the tasting.</p>}
        </div>
      </div>
      <Link to="/" className="btn btn-secondary mt-6">
        Back to the tastings
      </Link>
    </section>
  );
}

function Row({ label, value, strong, mono }: { label: string; value: string; strong?: boolean; mono?: boolean }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 py-3">
      <dt className="text-muted">{label}</dt>
      <dd className={`${strong ? 'font-display text-xl font-semibold text-wine-800' : 'font-semibold'} ${mono ? 'font-mono tracking-wider' : ''}`}>
        {value}
      </dd>
    </div>
  );
}
