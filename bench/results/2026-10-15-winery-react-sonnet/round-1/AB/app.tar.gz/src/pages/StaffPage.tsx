import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { ApiError, api, type StaffBookingDto, type StaffTastingDto } from '../api';
import { Field } from '../components/Field';
import { Notice } from '../components/Notice';
import { Spinner } from '../components/Spinner';
import { formatDateTime } from '../format';
import { staffBookingsKey } from '../queries';
import { usePageTitle } from '../usePageTitle';

export function StaffPage() {
  usePageTitle('Staff');
  const { data, error, isPending, refetch } = useQuery({
    queryKey: staffBookingsKey,
    queryFn: api.staffBookings,
    retry: false,
    refetchOnWindowFocus: true,
  });

  if (isPending) return <Spinner label="Loading…" />;
  // A failed refetch keeps the previous data, so a 401 (expired session, sign-out) must win over it.
  if (error instanceof ApiError && error.status === 401) return <SignIn />;
  if (data) return <Overview tastings={data} />;
  return (
    <div className="max-w-xl space-y-3">
      <h1 className="text-4xl">Staff</h1>
      <Notice variant="error">We could not load the bookings. Please try again.</Notice>
      <button type="button" className="btn btn-secondary" onClick={() => refetch()}>
        Try again
      </button>
    </div>
  );
}

function SignIn() {
  const queryClient = useQueryClient();
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } });
  const [formError, setFormError] = useState<string | null>(null);

  const login = useMutation({
    mutationFn: (password: string) => api.staffLogin(password),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: staffBookingsKey }),
    onError: (err) => {
      const e = err instanceof ApiError ? err : null;
      if (e?.errors.password) setError('password', { type: 'server', message: e.errors.password }, { shouldFocus: true });
      else setFormError(e?.errors.form ?? 'Something went wrong. Please try again.');
    },
  });

  return (
    <section className="mx-auto max-w-md">
      <h1 className="text-4xl">Staff area</h1>
      <p className="mt-3 text-muted">Please sign in to see and manage the tasting bookings.</p>
      <form
        noValidate
        className="card mt-6 space-y-5 p-5 sm:p-7"
        aria-label="Staff sign-in"
        onSubmit={handleSubmit(({ password }) => {
          setFormError(null);
          login.mutate(password);
        })}
      >
        {formError && <Notice variant="error">{formError}</Notice>}
        <Field
          label="Password"
          type="password"
          autoComplete="current-password"
          error={errors.password?.message}
          {...register('password', { required: 'Enter the password.' })}
        />
        <button type="submit" className="btn btn-primary w-full" disabled={login.isPending}>
          {login.isPending ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </section>
  );
}

type Message = { kind: 'success' | 'error'; text: string };

function Overview({ tastings }: { tastings: StaffTastingDto[] }) {
  const queryClient = useQueryClient();
  const [message, setMessage] = useState<Message | null>(null);

  const cancel = useMutation({
    mutationFn: (booking: StaffBookingDto) => api.staffCancel(booking.reference),
    onSuccess: (_void, booking) => {
      setMessage({ kind: 'success', text: `Booking ${booking.reference} of ${booking.name} was cancelled. Its seats are free again.` });
      return queryClient.invalidateQueries({ queryKey: staffBookingsKey });
    },
    onError: (err, booking) => {
      const e = err instanceof ApiError ? err : null;
      if (e?.status === 404) {
        setMessage({ kind: 'error', text: `Booking ${booking.reference} no longer exists.` });
      } else if (e?.status === 401) {
        setMessage(null);
        return queryClient.resetQueries({ queryKey: staffBookingsKey });
      } else {
        setMessage({ kind: 'error', text: `We could not cancel booking ${booking.reference}. ${e?.errors.form ?? 'Please try again.'}` });
      }
      return queryClient.invalidateQueries({ queryKey: staffBookingsKey });
    },
  });

  const logout = useMutation({
    mutationFn: api.staffLogout,
    // Reset (not just invalidate) so guest names and emails do not linger in memory after sign-out.
    onSettled: () => queryClient.resetQueries({ queryKey: staffBookingsKey }),
  });

  const totalGuests = tastings.reduce((sum, t) => sum + t.seatsBooked, 0);

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl">Bookings</h1>
          <p className="mt-2 text-muted">{totalGuests} guests booked across all tastings.</p>
        </div>
        <button type="button" className="btn btn-secondary" onClick={() => logout.mutate()} disabled={logout.isPending}>
          Sign out
        </button>
      </div>

      {message && (
        <div className="mt-6">
          <Notice variant={message.kind} onDismiss={() => setMessage(null)}>
            {message.text}
          </Notice>
        </div>
      )}

      <div className="mt-8 space-y-8">
        {tastings.map((t) => (
          <section key={t.id} aria-labelledby={`staff-${t.id}`}>
            <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b-2 border-gold-500 pb-2">
              <h2 id={`staff-${t.id}`} className="text-2xl">
                {t.title}
              </h2>
              <p className="text-sm text-muted">
                <time dateTime={t.startsAt}>{formatDateTime(t.startsAt)}</time> · {t.seatsBooked} of {t.capacity} seats booked
              </p>
            </div>
            {t.bookings.length === 0 ? (
              <p className="mt-4 rounded-lg bg-cream-200 px-4 py-3 text-muted">No bookings yet.</p>
            ) : (
              <ul className="mt-3 space-y-3">
                {t.bookings.map((b) => (
                  <li key={b.reference} className="card flex flex-wrap items-center justify-between gap-x-6 gap-y-3 p-4">
                    <div className="min-w-0 flex-1 basis-60">
                      <p id={`name-${b.reference}`} className="text-lg font-semibold">
                        {b.name}
                      </p>
                      <p className="text-muted">{b.email}</p>
                      <p className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-sm">
                        <span className="font-semibold">
                          {b.guests} {b.guests === 1 ? 'guest' : 'guests'}
                        </span>
                        <span className="font-mono tracking-wider text-muted">{b.reference}</span>
                      </p>
                    </div>
                    <button
                      type="button"
                      className="btn btn-danger"
                      aria-describedby={`name-${b.reference}`}
                      disabled={cancel.isPending && cancel.variables?.reference === b.reference}
                      onClick={() => {
                        setMessage(null);
                        cancel.mutate(b);
                      }}
                    >
                      Cancel
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </div>
    </>
  );
}
