import { Notice } from '../components/Notice';
import { Spinner } from '../components/Spinner';
import { TastingCard } from '../components/TastingCard';
import { useTastings } from '../queries';
import { usePageTitle } from '../usePageTitle';

export function TastingsPage() {
  usePageTitle('Wine tastings');
  const { data, isPending, isError, refetch, isFetching } = useTastings();

  return (
    <>
      <section className="mb-8 max-w-2xl sm:mb-10">
        <h1 className="text-4xl sm:text-5xl">Wine tastings at Kieselbrunnen</h1>
        <p className="mt-4 text-lg text-muted">
          Join us in the cellar for an evening of our own wines. Choose a tasting, tell us how many of you are coming and
          your seats are reserved.
        </p>
      </section>

      {isPending && <Spinner label="Loading tastings…" />}
      {isError && !data && (
        <div className="max-w-xl space-y-3">
          <Notice variant="error">We could not load the tastings. Please try again.</Notice>
          <button type="button" className="btn btn-secondary" onClick={() => refetch()} disabled={isFetching}>
            Try again
          </button>
        </div>
      )}
      {data && (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {data.map((t) => (
            <TastingCard key={t.id} tasting={t} />
          ))}
        </div>
      )}
    </>
  );
}
