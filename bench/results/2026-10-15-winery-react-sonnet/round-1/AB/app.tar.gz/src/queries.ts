import { useQuery } from '@tanstack/react-query';
import { api } from './api';

export const tastingsKey = ['tastings'] as const;
export const bookingKey = (reference: string) => ['booking', reference] as const;
export const staffBookingsKey = ['staff', 'bookings'] as const;

export const useTastings = () => useQuery({ queryKey: tastingsKey, queryFn: api.tastings });
