import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { BookingPage } from '../../src/pages/BookingPage';
import { TASTINGS, mockApi, renderRoute, type Handler } from './helpers';

afterEach(() => vi.unstubAllGlobals());

const tastingsRoute = (tastings = TASTINGS): Record<string, Handler> => ({
  'GET /api/tastings': () => ({ body: { tastings } }),
});
const open = (id = 'riesling-evening') =>
  renderRoute(<BookingPage />, { path: '/tastings/:id/book', at: `/tastings/${id}/book` });

const fill = async (name: string, email: string, guests?: string) => {
  const user = userEvent.setup();
  await user.type(screen.getByLabelText('Name'), name);
  await user.type(screen.getByLabelText('Email'), email);
  if (guests !== undefined) {
    await user.clear(screen.getByLabelText('Guests'));
    if (guests) await user.type(screen.getByLabelText('Guests'), guests);
  }
  return user;
};
const errorFor = (label: string) => {
  const field = screen.getByLabelText(label);
  const id = field.getAttribute('aria-describedby');
  expect(field).toHaveAttribute('aria-invalid', 'true');
  expect(id).toBeTruthy();
  return document.getElementById(id!.split(' ').pop()!)!;
};

describe('BookingPage form', () => {
  it('names the tasting and has labelled Name, Email and Guests fields and a Book button', async () => {
    mockApi(tastingsRoute());
    open('winter-tasting');
    expect(await screen.findByRole('heading', { level: 1, name: 'Winter Tasting' })).toBeInTheDocument();
    expect(screen.getByText('2026-12-05 17:00')).toBeInTheDocument();
    expect(screen.getAllByText(/EUR 28/).length).toBeGreaterThan(0);
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveValue(1);
    expect(screen.getByRole('button', { name: 'Book' })).toBeEnabled();
    expect(screen.getByRole('link', { name: /all tastings/i })).toHaveAttribute('href', '/');
  });

  it('shows a live total for the number of guests', async () => {
    mockApi(tastingsRoute());
    open('winter-tasting');
    await screen.findByLabelText('Name');
    const user = userEvent.setup();
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '3');
    expect(screen.getByText('EUR 84', { exact: false })).toBeInTheDocument();
  });

  it('shows errors next to Name and Email for an empty form without calling the API', async () => {
    const fetchMock = mockApi(tastingsRoute());
    open();
    await screen.findByLabelText('Name');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText('Enter your name.')).toBe(errorFor('Name').querySelector('span'));
    expect(errorFor('Email')).toHaveTextContent(/email/i);
    expect(screen.getByLabelText('Guests')).not.toHaveAttribute('aria-invalid');
    expect(fetchMock.mock.calls.filter(([, i]) => i?.method === 'POST')).toHaveLength(0);
  });

  it('rejects a malformed email', async () => {
    mockApi(tastingsRoute());
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'not-an-email');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText(/valid email address/i)).toBeInTheDocument();
    expect(errorFor('Email')).toHaveTextContent(/valid email/i);
  });

  it.each(['0', '9', '2.5', '', '-1'])('rejects %j guests next to Guests', async (guests) => {
    mockApi(tastingsRoute());
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'a@example.com', guests);
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(errorFor('Guests')).toHaveTextContent(/between 1 and 8/));
  });

  it('keeps typed values after a rejection', async () => {
    mockApi(tastingsRoute());
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'bad', '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await screen.findByText(/valid email address/i);
    expect(screen.getByLabelText('Name')).toHaveValue('Anna');
    expect(screen.getByLabelText('Email')).toHaveValue('bad');
    expect(screen.getByLabelText('Guests')).toHaveValue(2);
  });
});

describe('BookingPage submission', () => {
  const confirmation = {
    reference: 'KB-ABCD2345',
    tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00' },
    guests: 2,
    totalCents: 5000,
    status: 'confirmed',
  };

  it('posts the booking and goes to the confirmation page', async () => {
    const fetchMock = mockApi({
      ...tastingsRoute(),
      'POST /api/bookings': () => ({ status: 201, body: confirmation }),
    });
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna Berger', 'anna@example.com', '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(screen.getByTestId('location')).toHaveTextContent('/booking/KB-ABCD2345'));
    const post = fetchMock.mock.calls.find(([, i]) => i?.method === 'POST')!;
    expect(JSON.parse(String(post[1]!.body))).toEqual({
      tastingId: 'riesling-evening',
      name: 'Anna Berger',
      email: 'anna@example.com',
      guests: 2,
    });
  });

  it('shows the server seat-limit error next to Guests, keeps values and refreshes seats left', async () => {
    let tastingCalls = 0;
    mockApi({
      'GET /api/tastings': () => ({
        body: { tastings: tastingCalls++ === 0 ? TASTINGS : [{ ...TASTINGS[0]!, seatsLeft: 3 }, TASTINGS[1], TASTINGS[2]] },
      }),
      'POST /api/bookings': () => ({
        status: 422,
        seatsLeft: 3,
        body: { errors: { guests: 'Only 3 seats left for this tasting. Please reduce the number of guests.' }, seatsLeft: 3 },
      }),
    });
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'a@example.com', '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(errorFor('Guests')).toHaveTextContent('Only 3 seats left'));
    expect(screen.getByLabelText('Name')).toHaveValue('Anna');
    expect(await screen.findByText('3 seats left')).toBeInTheDocument();
  });

  it('keeps the form and shows the message if the tasting fills up meanwhile', async () => {
    let call = 0;
    mockApi({
      'GET /api/tastings': () => ({
        body: { tastings: call++ === 0 ? TASTINGS : [{ ...TASTINGS[0]!, seatsLeft: 0, status: 'full' }, TASTINGS[1], TASTINGS[2]] },
      }),
      'POST /api/bookings': () => ({ status: 409, body: { errors: { guests: 'Sorry, this tasting is now fully booked.' }, seatsLeft: 0 } }),
    });
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'a@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(errorFor('Guests')).toHaveTextContent('fully booked'));
  });

  it('shows a form-level error and keeps values when the server is unreachable, then allows retry', async () => {
    let attempt = 0;
    mockApi({
      ...tastingsRoute(),
      'POST /api/bookings': () => (attempt++ === 0 ? { networkError: true } : { status: 201, body: confirmation }),
    });
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'a@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach the server/i);
    expect(screen.getByLabelText('Name')).toHaveValue('Anna');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(screen.getByTestId('location')).toHaveTextContent('/booking/KB-ABCD2345'));
  });

  it('sends only one booking when Book is clicked twice quickly', async () => {
    let release: () => void = () => {};
    const gate = new Promise<void>((r) => (release = r));
    const fetchMock = mockApi({
      ...tastingsRoute(),
      'POST /api/bookings': async () => {
        await gate;
        return { status: 201, body: confirmation };
      },
    });
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'a@example.com');
    const button = screen.getByRole('button', { name: 'Book' });
    await user.dblClick(button);
    await waitFor(() => expect(screen.getByRole('button', { name: /Booking/ })).toBeDisabled());
    release();
    await waitFor(() => expect(screen.getByTestId('location')).toHaveTextContent('/booking/'));
    expect(fetchMock.mock.calls.filter(([, i]) => i?.method === 'POST')).toHaveLength(1);
  });
});

describe('BookingPage resilience and hints', () => {
  it('limits the hint to the seats left, with singular wording for one seat', async () => {
    mockApi(tastingsRoute([{ ...TASTINGS[0]!, seatsLeft: 1 }, TASTINGS[1]!, TASTINGS[2]!]));
    open();
    expect(await screen.findByText('Between 1 and 1 · 1 seat left')).toBeInTheDocument();
  });

  it('keeps the form and typed values when a background refresh of the tastings fails', async () => {
    let calls = 0;
    mockApi({
      'GET /api/tastings': () => (calls++ === 0 ? { body: { tastings: TASTINGS } } : { status: 500, body: {} }),
      'POST /api/bookings': () => ({ status: 422, body: { errors: { guests: 'Only 3 seats left for this tasting.' }, seatsLeft: 3 } }),
    });
    open();
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'a@example.com', '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(errorFor('Guests')).toHaveTextContent('Only 3 seats left'));
    await waitFor(() => expect(calls).toBeGreaterThan(1));
    expect(screen.getByLabelText('Name')).toHaveValue('Anna');
    expect(screen.queryByRole('button', { name: 'Try again' })).not.toBeInTheDocument();
  });
});

describe('BookingPage unavailable tastings', () => {
  it('explains a fully booked tasting and offers no way to submit', async () => {
    mockApi(tastingsRoute([TASTINGS[0]!, { ...TASTINGS[1]!, seatsLeft: 0, status: 'full' }, TASTINGS[2]!]));
    open('red-wine-cellar-tour');
    const note = (await screen.findByText(/fully booked/i)).closest('[role=status]');
    expect(note).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: /other tastings|all tastings/i })).toHaveAttribute('href', '/');
  });

  it('explains a closed tasting', async () => {
    mockApi(tastingsRoute([{ ...TASTINGS[0]!, status: 'closed' }]));
    open();
    expect((await screen.findByText(/already started/i)).closest('[role=status]')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });

  it('shows a not-found page for an unknown tasting', async () => {
    mockApi(tastingsRoute());
    open('nope');
    expect(await screen.findByRole('heading', { name: /not found/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /back to the tastings/i })).toHaveAttribute('href', '/');
  });

  it('shows an error with retry when tastings cannot be loaded', async () => {
    mockApi({ 'GET /api/tastings': () => ({ status: 500, body: {} }) });
    open();
    const alert = await screen.findByRole('alert');
    expect(within(alert).getByText(/could not load/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument();
  });
});
