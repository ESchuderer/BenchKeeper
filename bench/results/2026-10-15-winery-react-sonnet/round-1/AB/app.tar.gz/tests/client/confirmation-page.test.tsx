import { screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ConfirmationPage } from '../../src/pages/ConfirmationPage';
import { mockApi, renderRoute } from './helpers';

afterEach(() => vi.unstubAllGlobals());

const booking = {
  reference: 'KB-ABCD2345',
  tasting: { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00' },
  guests: 2,
  totalCents: 6400,
  status: 'confirmed',
};
const open = () => renderRoute(<ConfirmationPage />, { path: '/booking/:reference', at: '/booking/KB-ABCD2345' });

describe('ConfirmationPage', () => {
  it('shows the heading, tasting, guests, total and reference', async () => {
    mockApi({ 'GET /api/bookings/KB-ABCD2345': () => ({ body: booking }) });
    open();
    expect(await screen.findByRole('heading', { level: 1, name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Red Wine Cellar Tour')).toBeInTheDocument();
    expect(screen.getByText('2026-11-14 15:00')).toBeInTheDocument();
    expect(screen.getByText('2')).toBeInTheDocument();
    expect(screen.getByText('EUR 64')).toBeInTheDocument();
    expect(screen.getByText('KB-ABCD2345')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /back to the tastings/i })).toHaveAttribute('href', '/');
  });

  it('uses singular wording for one guest', async () => {
    mockApi({ 'GET /api/bookings/KB-ABCD2345': () => ({ body: { ...booking, guests: 1, totalCents: 3200 } }) });
    open();
    expect(await screen.findByText('EUR 32')).toBeInTheDocument();
    expect(screen.getByText('1')).toBeInTheDocument();
  });

  it('says so, without "Booking confirmed", when the booking was cancelled', async () => {
    mockApi({ 'GET /api/bookings/KB-ABCD2345': () => ({ body: { ...booking, status: 'cancelled' } }) });
    open();
    expect(await screen.findByRole('heading', { level: 1, name: 'Booking cancelled' })).toBeInTheDocument();
    expect(screen.queryByText('Booking confirmed')).not.toBeInTheDocument();
  });

  it('shows not found for an unknown reference', async () => {
    mockApi({ 'GET /api/bookings/KB-ABCD2345': () => ({ status: 404, body: { errors: { form: 'nope' } } }) });
    open();
    expect(await screen.findByRole('heading', { name: /not found/i })).toBeInTheDocument();
  });

  it('shows an error with retry when the server fails', async () => {
    mockApi({ 'GET /api/bookings/KB-ABCD2345': () => ({ status: 500, body: {} }) });
    open();
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument();
  });
});
