import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render } from '@testing-library/react';
import type { ReactElement } from 'react';
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom';
import { vi } from 'vitest';
import type { TastingDto } from '../../src/api';

export const TASTINGS: TastingDto[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceCents: 2500, capacity: 12, seatsLeft: 12, status: 'open' },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceCents: 3200, capacity: 8, seatsLeft: 8, status: 'open' },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceCents: 2800, capacity: 10, seatsLeft: 10, status: 'open' },
];

export interface FakeResponse {
  status?: number;
  body?: unknown;
  /** Make fetch itself reject (network failure). */
  networkError?: boolean;
}
export type Handler = (req: { body: any; url: string }) => FakeResponse | Promise<FakeResponse>;

/** Replaces global fetch with a router keyed by "METHOD /path". Returns the mock for call inspection. */
export function mockApi(routes: Record<string, Handler>) {
  const fn = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input);
    const method = init?.method ?? 'GET';
    const handler = routes[`${method} ${url}`];
    if (!handler) throw new Error(`Unexpected request: ${method} ${url}`);
    const r = await handler({ body: init?.body ? JSON.parse(String(init.body)) : undefined, url });
    if (r.networkError) throw new TypeError('Failed to fetch');
    const status = r.status ?? 200;
    return new Response(status === 204 ? null : JSON.stringify(r.body ?? {}), {
      status,
      headers: { 'Content-Type': 'application/json' },
    });
  });
  vi.stubGlobal('fetch', fn);
  return fn;
}

function LocationProbe() {
  const l = useLocation();
  return <div data-testid="location">{l.pathname}</div>;
}

export function renderRoute(ui: ReactElement, { path = '/', at = '/' }: { path?: string; at?: string } = {}) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[at]}>
        <Routes>
          <Route path={path} element={ui} />
          <Route path="*" element={<p>other page</p>} />
        </Routes>
        <LocationProbe />
      </MemoryRouter>
    </QueryClientProvider>,
  );
}
