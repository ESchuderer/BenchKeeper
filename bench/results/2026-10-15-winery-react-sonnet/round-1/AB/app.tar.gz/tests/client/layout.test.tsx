import { render, screen } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { expect, it } from 'vitest';
import { Layout } from '../../src/components/Layout';

it('shows the winery name, navigation, the page content and a footer link to staff', () => {
  render(
    <MemoryRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<h1>Page content</h1>} />
        </Route>
      </Routes>
    </MemoryRouter>,
  );
  expect(screen.getByRole('link', { name: /Weingut Kieselbrunnen/ })).toHaveAttribute('href', '/');
  expect(screen.getByRole('main')).toContainElement(screen.getByRole('heading', { name: 'Page content' }));
  expect(screen.getByRole('contentinfo')).toContainElement(screen.getByRole('link', { name: 'Staff' }));
});
