import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { StaffPage } from '../../src/pages/StaffPage';
import { mockApi, renderRoute, type Handler } from './helpers';

afterEach(() => vi.unstubAllGlobals());

const unauthorized = { status: 401, body: { errors: { form: 'Please sign in to continue.' } } };
const overview = (bookings: Record<string, object[]> = {}) => ({
  tastings: [
    { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', capacity: 12, seatsBooked: 2, bookings: bookings['riesling-evening'] ?? [] },
    { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', capacity: 8, seatsBooked: 0, bookings: [] },
    { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', capacity: 10, seatsBooked: 4, bookings: bookings['winter-tasting'] ?? [] },
  ],
});
const anna = { reference: 'KB-AAAA2222', name: 'Anna Berger', email: 'anna@example.com', guests: 2, createdAt: '2026-10-15T08:00:00Z' };
const ben = { reference: 'KB-BBBB3333', name: 'Ben Roth', email: 'ben@example.com', guests: 4, createdAt: '2026-10-15T09:00:00Z' };
const open = () => renderRoute(<StaffPage />, { path: '/staff', at: '/staff' });

describe('StaffPage sign-in', () => {
  it('asks for a password and shows no booking data when not signed in', async () => {
    mockApi({ 'GET /api/staff/bookings': () => unauthorized });
    open();
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('Riesling Evening')).not.toBeInTheDocument();
  });

  it('shows the overview after a correct password', async () => {
    let signedIn = false;
    const fetchMock = mockApi({
      'GET /api/staff/bookings': () => (signedIn ? { body: overview({ 'riesling-evening': [anna] }) } : unauthorized),
      'POST /api/staff/login': ({ body }) => {
        signedIn = body.password === 'pw';
        return signedIn ? { body: { ok: true } } : { status: 401, body: { errors: { password: 'That password is not correct.' } } };
      },
    });
    open();
    await userEvent.type(await screen.findByLabelText('Password'), 'pw');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalled();
  });

  it('shows an error next to the Password field for a wrong password', async () => {
    mockApi({
      'GET /api/staff/bookings': () => unauthorized,
      'POST /api/staff/login': () => ({ status: 401, body: { errors: { password: 'That password is not correct.' } } }),
    });
    open();
    await userEvent.type(await screen.findByLabelText('Password'), 'nope');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    const message = await screen.findByText('That password is not correct.');
    const field = screen.getByLabelText('Password');
    expect(field).toHaveAttribute('aria-invalid', 'true');
    expect(field.getAttribute('aria-describedby')).toContain(message.closest('p')!.id);
    expect(screen.queryByText('Riesling Evening')).not.toBeInTheDocument();
  });

  it('shows the rate-limit message next to the field', async () => {
    mockApi({
      'GET /api/staff/bookings': () => unauthorized,
      'POST /api/staff/login': () => ({ status: 429, body: { errors: { password: 'Too many failed attempts. Please try again later.' } } }),
    });
    open();
    await userEvent.type(await screen.findByLabelText('Password'), 'x');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByText(/try again later/i)).toBeInTheDocument();
  });

  it('asks for the password when it is left empty, without calling the API', async () => {
    const fetchMock = mockApi({ 'GET /api/staff/bookings': () => unauthorized });
    open();
    await userEvent.click(await screen.findByRole('button', { name: 'Sign in' }));
    expect(await screen.findByText(/enter the password/i)).toBeInTheDocument();
    expect(fetchMock.mock.calls.some(([, i]) => i?.method === 'POST')).toBe(false);
  });
});

describe('StaffPage overview', () => {
  const routes = (extra: Record<string, Handler> = {}, data = overview({ 'riesling-evening': [anna], 'winter-tasting': [ben] })) => ({
    'GET /api/staff/bookings': () => ({ body: data }),
    ...extra,
  });

  it('groups bookings by tasting with name, email, guests and reference', async () => {
    mockApi(routes());
    open();
    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section')!;
    expect(within(riesling).getByText('Anna Berger')).toBeInTheDocument();
    expect(within(riesling).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(riesling).getByText(/2 guests/)).toBeInTheDocument();
    expect(within(riesling).getByText('KB-AAAA2222')).toBeInTheDocument();
    expect(within(riesling).getByText('2026-11-06 18:00')).toBeInTheDocument();
    expect(within(riesling).getByText(/2 of 12 seats booked/)).toBeInTheDocument();
    expect(within(riesling).queryByText('Ben Roth')).not.toBeInTheDocument();

    const winter = screen.getByRole('heading', { name: 'Winter Tasting' }).closest('section')!;
    expect(within(winter).getByText('Ben Roth')).toBeInTheDocument();
    expect(within(winter).getByText(/4 guests/)).toBeInTheDocument();
  });

  it('shows an empty state for a tasting without bookings', async () => {
    mockApi(routes());
    open();
    const red = (await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' })).closest('section')!;
    expect(within(red).getByText(/no bookings yet/i)).toBeInTheDocument();
    expect(within(red).queryByRole('button', { name: 'Cancel' })).not.toBeInTheDocument();
  });

  it('shows 1 guest in singular', async () => {
    mockApi(routes({}, overview({ 'riesling-evening': [{ ...anna, guests: 1 }] })));
    open();
    expect(await screen.findByText(/^1 guest$/)).toBeInTheDocument();
  });

  it('cancels a booking, removes it and shows a notice naming it', async () => {
    let cancelled = false;
    mockApi(
      routes({
        'GET /api/staff/bookings': () => ({ body: cancelled ? overview({ 'winter-tasting': [ben] }) : overview({ 'riesling-evening': [anna], 'winter-tasting': [ben] }) }),
        'DELETE /api/staff/bookings/KB-AAAA2222': () => {
          cancelled = true;
          return { status: 204 };
        },
      }),
    );
    open();
    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section')!;
    await userEvent.click(within(riesling).getByRole('button', { name: 'Cancel' }));
    await waitFor(() => expect(screen.queryByText('Anna Berger')).not.toBeInTheDocument());
    expect(screen.getByRole('status')).toHaveTextContent(/KB-AAAA2222.*cancelled/i);
    expect(screen.getByText('Ben Roth')).toBeInTheDocument();
  });

  it('keeps the booking and shows an error when cancelling fails', async () => {
    mockApi(
      routes({ 'DELETE /api/staff/bookings/KB-AAAA2222': () => ({ networkError: true }) }),
    );
    open();
    await userEvent.click((await screen.findAllByRole('button', { name: 'Cancel' }))[0]!);
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not cancel|could not reach/i);
    expect(screen.getByText('Anna Berger')).toBeInTheDocument();
  });

  it('shows the sign-in form again when the session expired during cancel', async () => {
    let expired = false;
    mockApi(
      routes({
        'GET /api/staff/bookings': () => (expired ? unauthorized : { body: overview({ 'riesling-evening': [anna] }) }),
        'DELETE /api/staff/bookings/KB-AAAA2222': () => {
          expired = true;
          return unauthorized;
        },
      }),
    );
    open();
    await userEvent.click((await screen.findAllByRole('button', { name: 'Cancel' }))[0]!);
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.queryByText('Anna Berger')).not.toBeInTheDocument();
  });

  it('signs out and asks for the password again', async () => {
    let signedOut = false;
    mockApi({
      'GET /api/staff/bookings': () => (signedOut ? unauthorized : { body: overview({ 'riesling-evening': [anna] }) }),
      'POST /api/staff/logout': () => {
        signedOut = true;
        return { status: 204 };
      },
    });
    open();
    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.queryByText('Anna Berger')).not.toBeInTheDocument();
  });

  it('shows an error with retry when the bookings cannot be loaded', async () => {
    mockApi({ 'GET /api/staff/bookings': () => ({ status: 500, body: {} }) });
    open();
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument();
  });
});
