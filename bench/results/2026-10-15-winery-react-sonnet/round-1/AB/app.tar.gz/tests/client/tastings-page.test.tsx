import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { TastingsPage } from '../../src/pages/TastingsPage';
import { TASTINGS, mockApi, renderRoute } from './helpers';

afterEach(() => vi.unstubAllGlobals());

describe('TastingsPage', () => {
  it('shows a loading indicator, then every tasting with its details', async () => {
    mockApi({ 'GET /api/tastings': () => ({ body: { tastings: TASTINGS } }) });
    renderRoute(<TastingsPage />);
    expect(screen.getByRole('status')).toHaveTextContent(/loading/i);

    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(riesling).getByText('2026-11-06 18:00')).toBeInTheDocument();
    expect(within(riesling).getByText(/EUR 25\b/)).toBeInTheDocument();
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument();
    expect(within(riesling).getByRole('link', { name: 'Book Riesling Evening' })).toHaveAttribute('href', '/tastings/riesling-evening/book');

    const red = screen.getByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(red).getByText('2026-11-14 15:00')).toBeInTheDocument();
    expect(within(red).getByText(/EUR 32\b/)).toBeInTheDocument();
    expect(within(red).getByText('8 seats left')).toBeInTheDocument();
    const winter = screen.getByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText(/EUR 28\b/)).toBeInTheDocument();
    expect(within(winter).getByText('10 seats left')).toBeInTheDocument();
    expect(screen.getByRole('heading', { level: 1 })).toBeInTheDocument();
  });

  it('marks a fully booked tasting and offers no booking link, while others stay bookable', async () => {
    mockApi({
      'GET /api/tastings': () => ({
        body: { tastings: [TASTINGS[0], { ...TASTINGS[1]!, seatsLeft: 0, status: 'full' }, TASTINGS[2]] },
      }),
    });
    renderRoute(<TastingsPage />);
    const red = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(red).getByText('Fully booked')).toBeInTheDocument();
    expect(within(red).queryByText(/seats left/)).not.toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toBeInTheDocument();
  });

  it('marks a tasting that has started as closed', async () => {
    mockApi({
      'GET /api/tastings': () => ({ body: { tastings: [{ ...TASTINGS[0]!, status: 'closed' }] } }),
    });
    renderRoute(<TastingsPage />);
    const card = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(card).getByText('Booking closed')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: /Book/ })).not.toBeInTheDocument();
  });

  it('shows an error with a "Try again" action when loading fails', async () => {
    let calls = 0;
    mockApi({
      'GET /api/tastings': () => (++calls === 1 ? { status: 500, body: { errors: { form: 'boom' } } } : { body: { tastings: TASTINGS } }),
    });
    renderRoute(<TastingsPage />);
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }));
    await waitFor(() => expect(screen.getByRole('article', { name: 'Riesling Evening' })).toBeInTheDocument());
  });
});
