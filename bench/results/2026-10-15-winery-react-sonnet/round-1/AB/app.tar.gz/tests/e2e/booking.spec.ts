import AxeBuilder from '@axe-core/playwright';
import type { Page } from '@playwright/test';
import { STAFF_PASSWORD, expect, test } from './fixtures';

async function bookViaUi(page: Page, tasting: string, name: string, email: string, guests: number) {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${tasting}` }).click();
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Guests').fill(String(guests));
  await page.getByRole('button', { name: 'Book' }).click();
}

async function signIn(page: Page) {
  await page.goto('/staff');
  await page.getByLabel('Password').fill(STAFF_PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
}

test('start page lists the three tastings with price, date and seats', async ({ page }) => {
  await page.goto('/');
  const riesling = page.getByRole('article', { name: 'Riesling Evening' });
  await expect(riesling).toContainText('2026-11-06 18:00');
  await expect(riesling).toContainText('EUR 25');
  await expect(riesling).toContainText('12 seats left');
  await expect(page.getByRole('article', { name: 'Red Wine Cellar Tour' })).toContainText('8 seats left');
  await expect(page.getByRole('article', { name: 'Winter Tasting' })).toContainText('10 seats left');
  await expect(page.getByRole('article', { name: 'Winter Tasting' })).toContainText('EUR 28');
});

test('a guest books a tasting and sees the confirmation; seats left drop', async ({ page }) => {
  await bookViaUi(page, 'Riesling Evening', 'Anna Berger', 'anna@example.com', 3);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const main = page.getByRole('main');
  await expect(main).toContainText('Riesling Evening');
  await expect(main).toContainText('EUR 75');
  await expect(main).toContainText(/KB-[A-Z0-9]{8}/);
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(main).not.toContainText('anna@example.com');
  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Riesling Evening' })).toContainText('9 seats left');
});

test('invalid input is rejected with errors next to the fields', async ({ page }) => {
  await page.goto('/tastings/winter-tasting/book');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByLabel('Name')).toHaveAttribute('aria-invalid', 'true');
  await expect(page.getByLabel('Email')).toHaveAttribute('aria-invalid', 'true');
  await page.getByLabel('Name').fill('Anna');
  await page.getByLabel('Email').fill('nope');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByText(/valid email address/)).toBeVisible();
  await expect(page.getByText(/between 1 and 8/)).toBeVisible();
  await expect(page.getByLabel('Name')).toHaveValue('Anna');
  await expect(page).toHaveURL(/\/tastings\/winter-tasting\/book$/);
});

test('a booking can never take more seats than are left', async ({ page }) => {
  await bookViaUi(page, 'Red Wine Cellar Tour', 'Anna', 'a@example.com', 6);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/tastings/red-wine-cellar-tour/book');
  await page.getByLabel('Name').fill('Ben');
  await page.getByLabel('Email').fill('ben@example.com');
  await page.getByLabel('Guests').fill('3');
  await page.getByRole('button', { name: 'Book' }).click();
  const guests = page.getByLabel('Guests');
  await expect(guests).toHaveAttribute('aria-invalid', 'true');
  await expect(page.getByText('Only 2 seats left for this tasting.')).toBeVisible();
  await expect(page.getByLabel('Name')).toHaveValue('Ben');

  // the exact remaining seats work
  await guests.fill('2');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
});

test('a tasting that fills up shows as fully booked, and staff cancelling frees the seats', async ({ page }) => {
  await bookViaUi(page, 'Red Wine Cellar Tour', 'Anna Berger', 'anna@example.com', 8);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  const red = page.getByRole('article', { name: 'Red Wine Cellar Tour' });
  await expect(red).toContainText('Fully booked');
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0);
  await expect(page.getByRole('link', { name: 'Book Riesling Evening' })).toBeVisible();

  await page.goto('/tastings/red-wine-cellar-tour/book');
  await expect(page.getByText(/fully booked/i)).toBeVisible();
  await expect(page.getByRole('button', { name: 'Book' })).toHaveCount(0);

  await signIn(page);
  const section = page.getByRole('region', { name: 'Red Wine Cellar Tour' });
  await expect(section).toContainText('Anna Berger');
  await expect(section).toContainText('anna@example.com');
  await expect(section).toContainText('8 guests');
  await section.getByRole('button', { name: 'Cancel' }).click();
  await expect(section).toContainText('No bookings yet.');

  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Red Wine Cellar Tour' })).toContainText('8 seats left');
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeVisible();
});

test('staff sign-in: wrong password rejected, deep link and reload work, sign out ends the session', async ({ page }) => {
  await page.goto('/staff');
  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByText('That password is not correct.')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toHaveCount(0);

  await page.getByLabel('Password').fill(STAFF_PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();

  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Password')).toBeVisible();
});

test('staff API refuses unauthenticated requests', async ({ request }) => {
  expect((await request.get('/api/staff/bookings')).status()).toBe(401);
  expect((await request.delete('/api/staff/bookings/KB-XXXXXXXX')).status()).toBe(401);
});

test('guest-supplied text is shown literally to staff', async ({ page }) => {
  await bookViaUi(page, 'Winter Tasting', '<img src=x onerror=window.__pwned=1>', 'x@example.com', 1);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await signIn(page);
  await expect(page.getByText('<img src=x onerror=window.__pwned=1>')).toBeVisible();
  expect(await page.evaluate(() => (window as unknown as { __pwned?: number }).__pwned)).toBeUndefined();
});

test('unknown tasting and unknown pages show a not-found page', async ({ page }) => {
  await page.goto('/tastings/nope/book');
  await expect(page.getByRole('heading', { name: /not found/i })).toBeVisible();
  await page.goto('/somewhere/else');
  await expect(page.getByRole('heading', { name: /not found/i })).toBeVisible();
});

test.describe('phone viewport (375 px)', () => {
  test.use({ viewport: { width: 375, height: 800 }, hasTouch: true, isMobile: true });

  test('no horizontal scrolling and big touch targets on every page', async ({ page }) => {
    const noOverflow = async () =>
      expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(375);

    await page.goto('/');
    await expect(page.getByRole('article')).toHaveCount(3);
    await noOverflow();
    await page.getByRole('link', { name: 'Book Winter Tasting' }).click();
    await page.getByLabel('Name').fill('A'.repeat(90));
    await page.getByLabel('Email').fill('very.long.email.address.for.testing@example-with-long-domain.com');
    await noOverflow();
    for (const el of [page.getByLabel('Name'), page.getByLabel('Email'), page.getByLabel('Guests'), page.getByRole('button', { name: 'Book' })]) {
      const box = (await el.boundingBox())!;
      expect(box.height).toBeGreaterThanOrEqual(44);
      expect(await el.evaluate((e) => parseFloat(getComputedStyle(e).fontSize))).toBeGreaterThanOrEqual(16);
    }
    await page.getByRole('button', { name: 'Book' }).click();
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    await noOverflow();
    await signIn(page);
    await noOverflow();
    const cancel = (await page.getByRole('button', { name: 'Cancel' }).first().boundingBox())!;
    expect(cancel.height).toBeGreaterThanOrEqual(44);
  });
});

test.describe('accessibility (axe)', () => {
  const check = async (page: Page) => {
    const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
    expect(results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target).join(' | ')}`)).toEqual([]);
  };

  test('guest pages', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('article')).toHaveCount(3);
    await check(page);
    await page.getByRole('link', { name: 'Book Riesling Evening' }).click();
    await check(page);
    await page.getByRole('button', { name: 'Book' }).click();
    await expect(page.getByLabel('Name')).toHaveAttribute('aria-invalid', 'true');
    await check(page);
    await page.getByLabel('Name').fill('Anna');
    await page.getByLabel('Email').fill('a@example.com');
    await page.getByRole('button', { name: 'Book' }).click();
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
    await check(page);
  });

  test('staff pages', async ({ page }) => {
    await page.goto('/staff');
    await expect(page.getByLabel('Password')).toBeVisible();
    await check(page);
    await page.getByLabel('Password').fill('bad');
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page.getByText('That password is not correct.')).toBeVisible();
    await check(page);
    await signIn(page);
    await check(page);
  });
});
