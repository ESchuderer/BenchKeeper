import { spawn, type ChildProcess } from 'node:child_process';
import { createServer } from 'node:net';
import { test as base, expect } from '@playwright/test';

export const STAFF_PASSWORD = 'e2e-staff-password';

function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const s = createServer();
    s.listen(0, () => {
      const { port } = s.address() as { port: number };
      s.close(() => resolve(port));
    });
    s.on('error', reject);
  });
}

/** Starts the built app (`npm start`'s entry point) on a free port with a fresh, empty state. */
export const test = base.extend<{ app: { url: string } }>({
  app: async ({}, use) => {
    const port = await freePort();
    const child: ChildProcess = spawn('node', ['dist-server/server/index.js'], {
      env: { ...process.env, PORT: String(port), STAFF_PASSWORD, BOOKINGS_FILE: '' },
      stdio: ['ignore', 'pipe', 'inherit'],
    });
    await new Promise<void>((resolve, reject) => {
      child.once('error', reject);
      child.once('exit', (code) => reject(new Error(`app exited early (${code}); did you run npm run build?`)));
      child.stdout!.on('data', (d: Buffer) => {
        if (String(d).includes('listening')) resolve();
      });
    });
    child.removeAllListeners('exit');
    await use({ url: `http://localhost:${port}` });
    child.kill();
  },
  baseURL: async ({ app }, use) => use(app.url),
});

export { expect };
