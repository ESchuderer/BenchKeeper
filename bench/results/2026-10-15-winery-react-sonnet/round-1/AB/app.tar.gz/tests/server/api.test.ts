import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../server/app.js';
import { BookingStore } from '../../server/store.js';

const NOW = new Date('2026-10-15T06:00:00Z');
let store: BookingStore;
let app: ReturnType<typeof createApp>;
beforeEach(() => {
  store = new BookingStore({ now: () => NOW });
  app = createApp({ store, staffPassword: 'secret-pw', now: () => NOW });
});

const valid = { tastingId: 'riesling-evening', name: 'Anna Berger', email: 'anna@example.com', guests: 2 };
const book = (body: object) => request(app).post('/api/bookings').send(body);

describe('GET /api/tastings', () => {
  it('lists tastings with seats left and status', async () => {
    const res = await request(app).get('/api/tastings').expect(200);
    expect(res.body.tastings).toHaveLength(3);
    expect(res.body.tastings[0]).toEqual({
      id: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      priceCents: 2500,
      capacity: 12,
      seatsLeft: 12,
      status: 'open',
    });
  });

  it('reflects bookings', async () => {
    await book({ ...valid, guests: 3 }).expect(201);
    const res = await request(app).get('/api/tastings');
    expect(res.body.tastings[0].seatsLeft).toBe(9);
  });
});

describe('POST /api/bookings', () => {
  it('creates a booking and returns the confirmation without personal data', async () => {
    const res = await book({ ...valid, tastingId: 'red-wine-cellar-tour', guests: 2 }).expect(201);
    expect(res.body).toMatchObject({
      tasting: { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00' },
      guests: 2,
      totalCents: 6400,
      status: 'confirmed',
    });
    expect(res.body.reference).toMatch(/^KB-/);
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
  });

  it('accepts guests sent as a string', async () => {
    await book({ ...valid, guests: '4' }).expect(201);
  });

  it('returns per-field errors for invalid input and creates nothing', async () => {
    const res = await book({ tastingId: 'riesling-evening', name: '  ', email: 'nope', guests: 9 }).expect(422);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
    expect((await request(app).get('/api/tastings')).body.tastings[0].seatsLeft).toBe(12);
  });

  it.each([0, 2.5, 'abc', null, -1, 100])('rejects guests %j', async (guests) => {
    const res = await book({ ...valid, guests }).expect(422);
    expect(res.body.errors.guests).toBeTruthy();
  });

  it('rejects more guests than seats left with an error on guests naming the seats left', async () => {
    await book({ ...valid, tastingId: 'red-wine-cellar-tour', guests: 6 }).expect(201);
    const res = await book({ ...valid, tastingId: 'red-wine-cellar-tour', guests: 3 }).expect(422);
    expect(res.body.errors.guests).toMatch(/2 seats left/);
    expect(res.body.seatsLeft).toBe(2);
  });

  it('rejects a booking for a full tasting with 409', async () => {
    await book({ ...valid, tastingId: 'red-wine-cellar-tour', guests: 8 }).expect(201);
    const res = await book({ ...valid, tastingId: 'red-wine-cellar-tour', guests: 1 }).expect(409);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });

  it('rejects a booking for a tasting that already started with 409', async () => {
    const late = new BookingStore({ now: () => new Date('2026-11-07T12:00:00Z') });
    const lateApp = createApp({ store: late, staffPassword: 'x', now: () => NOW });
    const res = await request(lateApp).post('/api/bookings').send(valid).expect(409);
    expect(res.body.errors.form).toMatch(/closed|started/i);
  });

  it('answers 404 for unknown tastings, including prototype keys', async () => {
    await book({ ...valid, tastingId: 'nope' }).expect(404);
    await book({ ...valid, tastingId: '__proto__' }).expect(404);
    await book({ ...valid, tastingId: undefined }).expect(404);
  });

  it('answers 400 for malformed JSON and 413 for oversized bodies', async () => {
    const bad = await request(app).post('/api/bookings').set('content-type', 'application/json').send('{oops').expect(400);
    expect(bad.body.errors.form).toBeTruthy();
    await book({ ...valid, name: 'x'.repeat(50_000) }).expect(413);
  });

  it('never overbooks with simultaneous requests for the last seats', async () => {
    const results = await Promise.all(
      Array.from({ length: 10 }, (_, i) =>
        book({ ...valid, tastingId: 'red-wine-cellar-tour', name: `G${i}`, guests: 3 }),
      ),
    );
    const ok = results.filter((r) => r.status === 201);
    expect(ok).toHaveLength(2); // 8 seats / 3 per booking
    expect(results.filter((r) => r.status !== 201).every((r) => r.status === 422 || r.status === 409)).toBe(true);
    const t = (await request(app).get('/api/tastings')).body.tastings[1];
    expect(t.seatsLeft).toBe(2);
  });

  it('treats script-like names as plain data', async () => {
    const res = await book({ ...valid, name: '<script>alert(1)</script>' }).expect(201);
    const login = await request(app).post('/api/staff/login').send({ password: 'secret-pw' });
    const list = await request(app).get('/api/staff/bookings').set('Cookie', login.headers['set-cookie']!);
    expect(JSON.stringify(list.body)).toContain('<script>alert(1)</script>');
    expect(res.body.reference).toBeTruthy();
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the public view, then cancelled status after cancellation', async () => {
    const created = await book(valid).expect(201);
    const ref = created.body.reference;
    const got = await request(app).get(`/api/bookings/${ref}`).expect(200);
    expect(got.body).toEqual(created.body);
    store.cancelBooking(ref);
    expect((await request(app).get(`/api/bookings/${ref}`).expect(200)).body.status).toBe('cancelled');
  });

  it('answers 404 for unknown references', async () => {
    await request(app).get('/api/bookings/KB-NOPE').expect(404);
  });
});

describe('API fallbacks', () => {
  it('answers unknown /api paths with JSON 404', async () => {
    const res = await request(app).get('/api/unknown').expect(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
  it('sets security headers and hides the framework', async () => {
    const res = await request(app).get('/api/tastings');
    expect(res.headers['content-security-policy']).toContain("default-src 'self'");
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });
});
