import { mkdtempSync, readFileSync, readdirSync, statSync, writeFileSync, existsSync, mkdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { BookingStore } from '../../server/store.js';

const NOW = new Date('2026-10-15T06:00:00Z');
let dir: string;
let file: string;
beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), 'kb-'));
  file = join(dir, 'bookings.json');
});
afterEach(() => rmSync(dir, { recursive: true, force: true }));
const open = () => new BookingStore({ file, now: () => NOW });
const book = (s: BookingStore, n: number, name = 'Anna') =>
  s.createBooking('riesling-evening', { name, email: 'a@example.com', guests: n });

describe('file persistence', () => {
  it('treats a missing file as no bookings and does not create it until needed', () => {
    const s = open();
    expect(s.listActiveBookings()).toEqual([]);
    expect(existsSync(file)).toBe(false);
  });

  it('restores bookings, cancellations and seats after a restart', () => {
    const s = open();
    const a = book(s, 3);
    const b = book(s, 2, 'Ben');
    if (!a.ok || !b.ok) throw new Error('setup');
    s.cancelBooking(b.booking.reference);

    const again = open();
    expect(again.listTastings()[0]?.seatsLeft).toBe(9);
    expect(again.getBooking(a.booking.reference)?.name).toBe('Anna');
    expect(again.getBooking(b.booking.reference)?.status).toBe('cancelled');
  });

  it('does not reuse a restored reference for a new booking', () => {
    const first = new BookingStore({ file, now: () => NOW, generateReference: () => 'KB-AAAAAAAA' });
    book(first, 1);
    const seq = ['KB-AAAAAAAA', 'KB-CCCCCCCC'];
    const s = new BookingStore({ file, now: () => NOW, generateReference: () => seq.shift()! });
    const r = book(s, 1, 'Ben');
    expect(r.ok && r.booking.reference).toBe('KB-CCCCCCCC');
  });

  it('stops with a clear message on a corrupt file instead of discarding bookings', () => {
    writeFileSync(file, '{ this is not json');
    expect(open).toThrowError(/bookings file/i);
    expect(readFileSync(file, 'utf8')).toBe('{ this is not json');
  });

  it('stops on a file with the wrong structure', () => {
    writeFileSync(file, JSON.stringify({ version: 1, bookings: [{ reference: 1 }] }));
    expect(open).toThrowError(/bookings file/i);
  });

  it('rolls the booking back when the file cannot be written', () => {
    const s = new BookingStore({ file: join(dir, 'missing-dir', 'sub', 'b.json'), now: () => NOW });
    // make the parent a file so mkdir/write fails
    writeFileSync(join(dir, 'missing-dir'), 'x');
    expect(() => book(s, 3)).toThrowError();
    expect(s.listTastings()[0]?.seatsLeft).toBe(12);
    expect(s.listActiveBookings()).toEqual([]);
  });

  it('rolls a cancellation back when the file cannot be written', () => {
    const s = open();
    const r = book(s, 3);
    if (!r.ok) throw new Error('setup');
    rmSync(file);
    mkdirSync(file); // renaming a file over a directory fails
    expect(() => s.cancelBooking(r.booking.reference)).toThrowError();
    expect(s.getBooking(r.booking.reference)?.status).toBe('confirmed');
    expect(s.listTastings()[0]?.seatsLeft).toBe(9);
  });
});

describe('file persistence – integrity', () => {
  it('refuses a file with bookings for a tasting that no longer exists', () => {
    writeFileSync(
      file,
      JSON.stringify({
        version: 1,
        bookings: [{ reference: 'KB-AAAAAAAA', tastingId: 'gone', name: 'A', email: 'a@b.de', guests: 1, createdAt: 'x', status: 'confirmed' }],
      }),
    );
    expect(open).toThrowError(/unknown tasting "gone"/);
  });

  it('leaves no temp file behind when a write fails', () => {
    const s = open();
    mkdirSync(file); // renaming over a directory fails
    expect(() => book(s, 1)).toThrowError();
    expect(readdirSync(dir).filter((f) => f.endsWith('.tmp'))).toEqual([]);
  });
});

describe('file persistence – permissions', () => {
  it('writes the bookings file readable by the owner only', () => {
    const s = open();
    book(s, 1);
    expect(statSync(file).mode & 0o777).toBe(0o600);
  });
});
