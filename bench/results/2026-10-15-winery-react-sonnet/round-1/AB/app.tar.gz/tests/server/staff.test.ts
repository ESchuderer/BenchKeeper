import request from 'supertest';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { createApp } from '../../server/app.js';
import { BookingStore } from '../../server/store.js';

let now = new Date('2026-10-15T06:00:00Z');
let store: BookingStore;
let app: ReturnType<typeof createApp>;
beforeEach(() => {
  now = new Date('2026-10-15T06:00:00Z');
  store = new BookingStore({ now: () => now });
  app = createApp({ store, staffPassword: 'secret-pw', now: () => now, loginAttempts: 5 });
});

const login = (password: string, a = app) => request(a).post('/api/staff/login').send({ password });
const signIn = async () => (await login('secret-pw')).headers['set-cookie']![0]!.split(';')[0]!;
const book = (name: string, tastingId = 'riesling-evening', guests = 2) =>
  request(app).post('/api/bookings').send({ tastingId, name, email: `${name.toLowerCase()}@example.com`, guests });

describe('staff login', () => {
  it('accepts the configured password and sets a hardened session cookie', async () => {
    const res = await login('secret-pw').expect(200);
    const cookie = res.headers['set-cookie']![0]!;
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    expect(cookie).toMatch(/Path=\//);
    expect(cookie).not.toMatch(/Max-Age|Expires/i); // session cookie
    expect(cookie).not.toContain('secret-pw');
    expect(JSON.stringify(res.body)).not.toContain('secret-pw');
  });

  it('rejects wrong passwords with an error for the password field and no cookie', async () => {
    const res = await login('wrong').expect(401);
    expect(res.body.errors.password).toBeTruthy();
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it.each(['', 'secret-pw ', 'SECRET-PW', 'secret'])('rejects %j', async (pw) => {
    await login(pw).expect(401);
  });

  it('rejects non-string passwords', async () => {
    await request(app).post('/api/staff/login').send({ password: ['secret-pw'] }).expect(401);
    await request(app).post('/api/staff/login').send({}).expect(401);
  });

  it.each([undefined, ''])('never lets anyone in when STAFF_PASSWORD is %j', async (pw) => {
    const closed = createApp({ store, staffPassword: pw, now: () => now });
    await login('', closed).expect(401);
    await login('anything', closed).expect(401);
    await login(String(pw), closed).expect(401);
  });

  it('refuses further attempts after too many failures, with a retry message', async () => {
    for (let i = 0; i < 5; i++) await login('bad').expect(401);
    const res = await login('bad').expect(429);
    expect(res.body.errors.password).toMatch(/try again later/i);
    // even the right password is refused while limited
    await login('secret-pw').expect(429);
  });

  it('does not count successful logins towards the limit', async () => {
    for (let i = 0; i < 8; i++) await login('secret-pw').expect(200);
  });
});

describe('protected staff routes', () => {
  it('refuses unauthenticated access', async () => {
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete('/api/staff/bookings/KB-X').expect(401);
    await request(app).get('/api/staff/session').expect(401);
  });

  it('refuses a forged or unknown session cookie', async () => {
    await request(app).get('/api/staff/bookings').set('Cookie', 'kb_staff=forged').expect(401);
  });

  it('reports the session while signed in, and logout ends it', async () => {
    const cookie = await signIn();
    await request(app).get('/api/staff/session').set('Cookie', cookie).expect(200);
    await request(app).post('/api/staff/logout').set('Cookie', cookie).expect(204);
    await request(app).get('/api/staff/session').set('Cookie', cookie).expect(401);
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(401);
  });

  it('expires idle sessions', async () => {
    const cookie = await signIn();
    now = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    await request(app).get('/api/staff/session').set('Cookie', cookie).expect(401);
  });

  it('marks the cookie Secure when the request is HTTPS (behind a trusted proxy)', async () => {
    const proxied = createApp({ store, staffPassword: 'secret-pw', now: () => now, trustProxy: 1 });
    const res = await request(proxied).post('/api/staff/login').set('X-Forwarded-Proto', 'https').send({ password: 'secret-pw' });
    expect(res.headers['set-cookie']![0]).toMatch(/Secure/i);
  });
});

describe('staff bookings overview and cancellation', () => {
  it('groups active bookings by tasting in tasting order, with seats booked', async () => {
    await book('Ben', 'winter-tasting', 4);
    await book('Anna', 'riesling-evening', 2);
    const cookie = await signIn();
    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);
    expect(res.body.tastings.map((t: { id: string }) => t.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ]);
    const [riesling, red, winter] = res.body.tastings;
    expect(riesling).toMatchObject({ title: 'Riesling Evening', startsAt: '2026-11-06T18:00', capacity: 12, seatsBooked: 2 });
    expect(riesling.bookings).toEqual([
      expect.objectContaining({ name: 'Anna', email: 'anna@example.com', guests: 2, reference: expect.stringMatching(/^KB-/) }),
    ]);
    expect(red.bookings).toEqual([]);
    expect(winter.seatsBooked).toBe(4);
  });

  it('cancels a booking, frees the seats and removes it from the list', async () => {
    const created = await book('Anna', 'riesling-evening', 3);
    const cookie = await signIn();
    await request(app).delete(`/api/staff/bookings/${created.body.reference}`).set('Cookie', cookie).expect(204);
    const list = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(list.body.tastings[0].bookings).toEqual([]);
    expect((await request(app).get('/api/tastings')).body.tastings[0].seatsLeft).toBe(12);
  });

  it('answers 404 for a second cancellation and frees nothing twice', async () => {
    const a = await book('Anna', 'riesling-evening', 2);
    await book('Ben', 'riesling-evening', 4);
    const cookie = await signIn();
    await request(app).delete(`/api/staff/bookings/${a.body.reference}`).set('Cookie', cookie).expect(204);
    await request(app).delete(`/api/staff/bookings/${a.body.reference}`).set('Cookie', cookie).expect(404);
    expect((await request(app).get('/api/tastings')).body.tastings[0].seatsLeft).toBe(8);
  });

  it('lets guests book freed seats of a full tasting', async () => {
    const full = await book('Anna', 'red-wine-cellar-tour', 8);
    await book('Ben', 'red-wine-cellar-tour', 1).expect(409);
    const cookie = await signIn();
    await request(app).delete(`/api/staff/bookings/${full.body.reference}`).set('Cookie', cookie).expect(204);
    await book('Ben', 'red-wine-cellar-tour', 1).expect(201);
  });
});

describe('secrets', () => {
  it('never writes the password to the logs', async () => {
    const spies = (['log', 'warn', 'error', 'info'] as const).map((m) => vi.spyOn(console, m).mockImplementation(() => {}));
    await login('wrong-guess');
    await login('secret-pw');
    await request(app).post('/api/bookings').set('content-type', 'application/json').send('{broken');
    const logged = spies.flatMap((s) => s.mock.calls).flat().join(' ');
    expect(logged).not.toContain('secret-pw');
    expect(logged).not.toContain('wrong-guess');
    spies.forEach((s) => s.mockRestore());
  });
});
