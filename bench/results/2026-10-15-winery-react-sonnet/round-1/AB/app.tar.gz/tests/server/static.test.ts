import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../../server/app.js';
import { BookingStore } from '../../server/store.js';

let dir: string;
let app: ReturnType<typeof createApp>;
beforeAll(() => {
  dir = mkdtempSync(join(tmpdir(), 'kb-static-'));
  mkdirSync(join(dir, 'assets'));
  writeFileSync(join(dir, 'index.html'), '<!doctype html><div id="root"></div>');
  writeFileSync(join(dir, 'assets', 'app.js'), 'console.log(1)');
  app = createApp({ store: new BookingStore(), staffPassword: 'pw', staticDir: dir });
});
afterAll(() => rmSync(dir, { recursive: true, force: true }));

describe('static serving', () => {
  it.each(['/', '/staff', '/tastings/riesling-evening/book', '/booking/KB-ABC'])('serves the app shell for %s', async (path) => {
    const res = await request(app).get(path).expect(200);
    expect(res.text).toContain('id="root"');
    expect(res.headers['content-type']).toMatch(/html/);
  });
  it('serves assets', async () => {
    await request(app).get('/assets/app.js').expect(200);
  });
  it('does not fall back to the app shell for missing assets or API paths', async () => {
    await request(app).get('/assets/missing.js').expect(404);
    const res = await request(app).get('/api/nothing').expect(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
  it('only falls back for GET/HEAD', async () => {
    await request(app).post('/staff').expect(404);
  });
});
