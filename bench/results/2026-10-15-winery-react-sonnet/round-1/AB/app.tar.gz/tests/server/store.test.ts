import { describe, expect, it } from 'vitest';
import { BookingStore } from '../../server/store.js';

const NOW = new Date('2026-10-15T06:00:00Z');
const guest = (guests: number, name = 'Anna') => ({ name, email: `${name.toLowerCase()}@example.com`, guests });
const make = (now: Date = NOW) => new BookingStore({ now: () => now });
const seats = (s: BookingStore, id: string) => s.listTastings().find((t) => t.id === id)!.seatsLeft;

describe('BookingStore seat accounting', () => {
  it('starts with full capacity, status open and no bookings', () => {
    const s = make();
    expect(s.listTastings().map((t) => [t.id, t.seatsLeft, t.status])).toEqual([
      ['riesling-evening', 12, 'open'],
      ['red-wine-cellar-tour', 8, 'open'],
      ['winter-tasting', 10, 'open'],
    ]);
    expect(s.listActiveBookings()).toEqual([]);
  });

  it('reduces only the booked tasting by the number of guests', () => {
    const s = make();
    const r = s.createBooking('riesling-evening', guest(3));
    expect(r.ok).toBe(true);
    expect(seats(s, 'riesling-evening')).toBe(9);
    expect(seats(s, 'winter-tasting')).toBe(10);
  });

  it('rejects more guests than seats left and takes no seats', () => {
    const s = make();
    s.createBooking('red-wine-cellar-tour', guest(5));
    const r = s.createBooking('red-wine-cellar-tour', guest(4, 'Ben'));
    expect(r).toEqual({ ok: false, code: 'not_enough_seats', seatsLeft: 3 });
    expect(seats(s, 'red-wine-cellar-tour')).toBe(3);
  });

  it('accepts exactly the remaining seats and then reports the tasting full', () => {
    const s = make();
    s.createBooking('red-wine-cellar-tour', guest(5));
    expect(s.createBooking('red-wine-cellar-tour', guest(3, 'Ben')).ok).toBe(true);
    expect(s.listTastings().find((t) => t.id === 'red-wine-cellar-tour')).toMatchObject({ seatsLeft: 0, status: 'full' });
    expect(s.createBooking('red-wine-cellar-tour', guest(1, 'Cleo'))).toEqual({ ok: false, code: 'full', seatsLeft: 0 });
  });

  it('rejects unknown tastings', () => {
    expect(make().createBooking('nope', guest(1))).toEqual({ ok: false, code: 'unknown_tasting' });
  });

  it('closes a tasting once its start time has passed (Europe/Berlin)', () => {
    const s = make(new Date('2026-11-06T17:00:00Z')); // 18:00 CET
    expect(s.listTastings().find((t) => t.id === 'riesling-evening')?.status).toBe('closed');
    expect(s.createBooking('riesling-evening', guest(1))).toEqual({ ok: false, code: 'closed', seatsLeft: 12 });
    expect(s.createBooking('winter-tasting', guest(1)).ok).toBe(true);
  });

  it('never overbooks across many sequential and interleaved requests', () => {
    const s = make();
    let accepted = 0;
    for (let i = 0; i < 20; i++) if (s.createBooking('winter-tasting', guest(1 + (i % 3), `G${i}`)).ok) accepted += 1 + (i % 3);
    expect(accepted).toBeLessThanOrEqual(10);
    expect(seats(s, 'winter-tasting')).toBe(10 - accepted);
    expect(seats(s, 'winter-tasting')).toBeGreaterThanOrEqual(0);
  });
});

describe('BookingStore references', () => {
  it('generates unique, readable references', () => {
    const s = make();
    const refs = new Set<string>();
    for (let i = 0; i < 8; i++) {
      const r = s.createBooking('riesling-evening', guest(1, `G${i}`));
      if (r.ok) refs.add(r.booking.reference);
    }
    expect(refs.size).toBe(8);
    for (const ref of refs) expect(ref).toMatch(/^KB-[A-HJ-NP-Z2-9]{8}$/);
  });

  it('regenerates on collision', () => {
    const seq = ['KB-AAAAAAAA', 'KB-AAAAAAAA', 'KB-BBBBBBBB'];
    const s = new BookingStore({ now: () => NOW, generateReference: () => seq.shift()! });
    const a = s.createBooking('riesling-evening', guest(1));
    const b = s.createBooking('riesling-evening', guest(1, 'Ben'));
    expect([a, b].map((r) => (r.ok ? r.booking.reference : null))).toEqual(['KB-AAAAAAAA', 'KB-BBBBBBBB']);
  });
});

describe('BookingStore cancellation', () => {
  it('frees the seats and removes the booking from the active list', () => {
    const s = make();
    const r = s.createBooking('riesling-evening', guest(3));
    if (!r.ok) throw new Error('setup');
    expect(s.cancelBooking(r.booking.reference)).toBe(true);
    expect(seats(s, 'riesling-evening')).toBe(12);
    expect(s.listActiveBookings()).toEqual([]);
    expect(s.getBooking(r.booking.reference)?.status).toBe('cancelled');
  });

  it('reopens a full tasting', () => {
    const s = make();
    const r = s.createBooking('red-wine-cellar-tour', guest(8));
    if (!r.ok) throw new Error('setup');
    s.cancelBooking(r.booking.reference);
    expect(s.createBooking('red-wine-cellar-tour', guest(8, 'Ben')).ok).toBe(true);
  });

  it('answers false for repeated or unknown cancellation and frees nothing twice', () => {
    const s = make();
    const a = s.createBooking('riesling-evening', guest(2));
    const b = s.createBooking('riesling-evening', guest(4, 'Ben'));
    if (!a.ok || !b.ok) throw new Error('setup');
    expect(s.cancelBooking(a.booking.reference)).toBe(true);
    expect(s.cancelBooking(a.booking.reference)).toBe(false);
    expect(s.cancelBooking('KB-UNKNOWN1')).toBe(false);
    expect(seats(s, 'riesling-evening')).toBe(8);
  });

  it('lists active bookings per tasting in booking order', () => {
    const s = make();
    s.createBooking('winter-tasting', guest(1, 'Ben'));
    s.createBooking('riesling-evening', guest(2, 'Anna'));
    s.createBooking('winter-tasting', guest(1, 'Cleo'));
    expect(s.listActiveBookings().map((b) => b.name)).toEqual(['Ben', 'Anna', 'Cleo']);
  });
});
