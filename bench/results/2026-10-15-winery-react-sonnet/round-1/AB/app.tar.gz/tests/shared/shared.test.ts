import { describe, expect, it } from 'vitest';
import { TASTINGS, findTasting, formatDateTime, hasStarted } from '../../shared/tastings.js';
import { formatEur } from '../../shared/money.js';
import { bookingInputSchema, MAX_GUESTS } from '../../shared/booking.js';

describe('tasting seed data', () => {
  it('offers exactly the three tastings in chronological order', () => {
    expect(TASTINGS.map((t) => [t.title, t.startsAt, t.priceCents, t.capacity])).toEqual([
      ['Riesling Evening', '2026-11-06T18:00', 2500, 12],
      ['Red Wine Cellar Tour', '2026-11-14T15:00', 3200, 8],
      ['Winter Tasting', '2026-12-05T17:00', 2800, 10],
    ]);
  });

  it('finds tastings by id and returns undefined for unknown ids', () => {
    expect(findTasting('winter-tasting')?.title).toBe('Winter Tasting');
    expect(findTasting('nope')).toBeUndefined();
    expect(findTasting('__proto__')).toBeUndefined();
  });

  it('formats the local date and time exactly as written, without time zone conversion', () => {
    expect(formatDateTime('2026-11-06T18:00')).toBe('2026-11-06 18:00');
  });
});

describe('hasStarted (Europe/Berlin wall clock)', () => {
  const riesling = findTasting('riesling-evening')!;
  it('is false before the start', () => {
    // 17:59 Berlin (CET, UTC+1) = 16:59 UTC
    expect(hasStarted(riesling, new Date('2026-11-06T16:59:00Z'))).toBe(false);
  });
  it('is true from the start instant on', () => {
    expect(hasStarted(riesling, new Date('2026-11-06T17:00:00Z'))).toBe(true);
    expect(hasStarted(riesling, new Date('2026-11-07T00:00:00Z'))).toBe(true);
  });
  it('is false long before', () => {
    expect(hasStarted(riesling, new Date('2026-10-15T06:00:00Z'))).toBe(false);
  });
});

describe('formatEur', () => {
  it('omits decimals for whole euros', () => {
    expect(formatEur(2500)).toBe('EUR 25');
    expect(formatEur(8400)).toBe('EUR 84');
  });
  it('shows two decimals otherwise', () => {
    expect(formatEur(2550)).toBe('EUR 25.50');
    expect(formatEur(1205)).toBe('EUR 12.05');
  });
});

describe('bookingInputSchema', () => {
  const valid = { name: 'Anna Berger', email: 'anna@example.com', guests: '2' };
  const errorsOf = (input: unknown) => {
    const r = bookingInputSchema.safeParse(input);
    if (r.success) return null;
    return Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message]));
  };

  it('accepts valid input and converts guests to a number', () => {
    const r = bookingInputSchema.parse(valid);
    expect(r).toEqual({ name: 'Anna Berger', email: 'anna@example.com', guests: 2 });
  });
  it('accepts numeric guests and trims name and email', () => {
    expect(bookingInputSchema.parse({ name: '  Anna ', email: ' a@b.de ', guests: 8 })).toEqual({
      name: 'Anna',
      email: 'a@b.de',
      guests: 8,
    });
  });
  it('rejects empty and whitespace-only names', () => {
    expect(errorsOf({ ...valid, name: '' })?.name).toMatch(/name/i);
    expect(errorsOf({ ...valid, name: '    ' })?.name).toMatch(/name/i);
  });
  it('rejects names over 100 characters', () => {
    expect(errorsOf({ ...valid, name: 'x'.repeat(101) })?.name).toBeTruthy();
    expect(errorsOf({ ...valid, name: 'x'.repeat(100) })).toBeNull();
  });
  it.each(['', 'not-an-email', 'a@b', '@example.com', 'a b@example.com'])('rejects email %j', (email) => {
    expect(errorsOf({ ...valid, email })?.email).toMatch(/email/i);
  });
  it('rejects emails over 254 characters', () => {
    expect(errorsOf({ ...valid, email: `${'a'.repeat(250)}@example.com` })?.email).toBeTruthy();
  });
  it.each(['0', '9', '2.5', 'abc', '', ' ', '-1', '1e1', 0, 9, 2.5, NaN, null, undefined, true, [], {}])(
    'rejects guests %j',
    (guests) => {
      expect(errorsOf({ ...valid, guests })?.guests).toMatch(/1 and 8/);
    },
  );
  it.each(['1', '8', ' 3 ', 1, 8])('accepts guests %j', (guests) => {
    expect(errorsOf({ ...valid, guests })).toBeNull();
  });
  it('reports all problems at once, per field', () => {
    const e = errorsOf({ name: '', email: '', guests: '' });
    expect(Object.keys(e!).sort()).toEqual(['email', 'guests', 'name']);
  });
  it('exposes the guest maximum', () => {
    expect(MAX_GUESTS).toBe(8);
  });
});
