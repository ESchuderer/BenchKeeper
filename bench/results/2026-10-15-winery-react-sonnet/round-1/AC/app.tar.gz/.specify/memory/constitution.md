<!--
Sync Impact Report
- Version change: template (unversioned) -> 1.0.0
- Modified principles: all placeholders replaced (initial ratification)
- Added sections: Core Principles I-VI, Technology & Operational Constraints, Development Workflow, Governance
- Removed sections: none
- Deferred items: none
-->
# Weingut Kieselbrunnen Tasting Bookings Constitution

## Core Principles

### I. Test-First (NON-NEGOTIABLE)
Tests for a behavior MUST be written, and seen to fail for the right reason, before the code that
implements it. Red-Green-Refactor is followed for every task. Booking rules (capacity, validation,
cancellation, staff authentication) MUST be covered by automated tests at the API level, and the
guest and staff journeys by at least one end-to-end test each.

### II. Never Overbook
The server is the only authority on seats. Every booking request MUST be validated server-side
against the seats currently left, and the check and the write MUST happen as one atomic step so
concurrent requests cannot take more seats than exist. Client-side checks are conveniences only.
A cancelled booking MUST release its seats immediately.

### III. Established Libraries Over Custom Code
Servers, routing, form handling, validation, sessions and styling MUST use established, maintained
libraries rather than hand-written replacements. Each dependency MUST have a clear purpose; no
dependency is added for something the platform or an existing dependency already does.

### IV. Simplicity
No external services. Data is held in memory or a local file. The app starts with no bookings. One
process serves both the API and the built front end. YAGNI applies: features not in the current
spec MUST NOT be built.

### V. Security Basics
The staff password MUST come from the `STAFF_PASSWORD` environment variable and MUST NOT appear in
source, logs or responses. Password comparison MUST be constant-time. Staff sessions use an
httpOnly, SameSite cookie with a server-verified token; every staff API route MUST require it.
All user-supplied input MUST be validated on the server and output MUST be escaped (React default
escaping; no raw HTML injection).

### VI. Accessible, Mobile-First UI
Every form field MUST have a visible label, and errors MUST be shown next to the field they concern
and be announced to assistive technology. Success, error and fully-booked states MUST be visually
distinct and not rely on colour alone. Layouts MUST work on a phone-width viewport. The interface
language is English.

## Technology & Operational Constraints

- Node.js 22; React front end; `npm install`, `npm run build`, `npm start` MUST work from a clean
  checkout, and `npm start` serves the whole app on `PORT` (default 3000).
- Tasting data: Riesling Evening, Red Wine Cellar Tour, Winter Tasting, as given in the spec.
- Money is handled in integer cents internally and shown as EUR.

## Development Workflow

Work follows the Spec Kit sequence: specify, clarify, plan, tasks, implement, with analyze before
implementation and a code review before the work is called done. Verification MUST include running
the real built app (`npm run build` and `npm start`) and exercising the guest and staff flows, not
only unit tests. Commits are small and describe one change.

## Governance

This constitution supersedes other practices. Amendments are made through the
`speckit-constitution` command, recorded with a version bump (MAJOR: principle removal or
redefinition; MINOR: new principle or materially expanded guidance; PATCH: clarification). Plans
and reviews MUST check compliance with these principles, and any deviation MUST be justified in the
plan's complexity tracking.

**Version**: 1.0.0 | **Ratified**: 2026-10-15 | **Last Amended**: 2026-10-15
