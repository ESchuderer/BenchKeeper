# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff see and cancel bookings. React front end, Express 5 server, one process.

## Run

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start   # http://localhost:3000, or set PORT
```

- `/` lists the tastings, "Book <title>" opens the booking form.
- `/staff` is the staff area. The password is read from `STAFF_PASSWORD`; if it is not set, nobody can sign in.
- Behind a reverse proxy, set `TRUST_PROXY=1` (number of proxies) so the login limit sees real client addresses and the session cookie is marked `Secure` for HTTPS requests.
- Bookings are kept in memory: the app starts empty and a restart clears all bookings.

## Develop and test

```sh
npm test            # unit, API and component tests (Vitest, Supertest, Testing Library)
npm run test:e2e    # browser tests (Playwright; first run: npx playwright install chromium)
npm run dev         # Vite dev server on :5173, proxying /api to a server on :3000
```

Design documents live in `specs/001-tasting-bookings/` (spec, plan, tasks, API contract).

## Known limitations

- Anyone can create bookings (no email confirmation, as the brief asks for none), so a malicious visitor could fill the tastings with fake bookings; staff can cancel them. Put a rate limit or bot protection in front of the app if this becomes a problem.
- Bookings live in memory only.
