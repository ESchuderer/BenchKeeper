export class ApiError extends Error {
  constructor(status, body) {
    super(body?.error ?? `Request failed (${status})`);
    this.status = status;
    this.errors = body?.errors ?? {};
    this.seatsLeft = body?.seatsLeft;
  }
}

async function request(method, url, body) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: 'same-origin',
    });
  } catch {
    throw new ApiError(0, { error: 'Could not reach the server.' });
  }
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}

export const listTastings = () => request('GET', '/api/tastings');
export const getTasting = (id) => request('GET', `/api/tastings/${encodeURIComponent(id)}`);
export const createBooking = (id, input) => request('POST', `/api/tastings/${encodeURIComponent(id)}/bookings`, input);

export const getStaffSession = () => request('GET', '/api/staff/session');
export const staffLogin = (password) => request('POST', '/api/staff/login', { password });
export const staffLogout = () => request('POST', '/api/staff/logout', {});
export const listStaffBookings = () => request('GET', '/api/staff/bookings');
export const cancelBooking = (reference) => request('DELETE', `/api/staff/bookings/${encodeURIComponent(reference)}`);
