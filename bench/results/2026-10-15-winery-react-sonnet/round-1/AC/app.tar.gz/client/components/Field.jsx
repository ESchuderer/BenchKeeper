import { useId } from 'react';

/** A labelled input with an optional hint and an error shown right below it. */
export default function Field({ label, hint, error, ref, ...inputProps }) {
  const id = useId();
  const hintId = `${id}-hint`;
  const errorId = `${id}-error`;
  const describedBy = [hint && hintId, error && errorId].filter(Boolean).join(' ') || undefined;
  return (
    <div className={`field${error ? ' field--invalid' : ''}`}>
      <label htmlFor={id}>{label}</label>
      <input
        id={id}
        ref={ref}
        aria-invalid={error ? 'true' : undefined}
        aria-describedby={describedBy}
        {...inputProps}
      />
      {hint && <p id={hintId} className="field__hint">{hint}</p>}
      {error && <p id={errorId} role="alert" className="field__error">{error}</p>}
    </div>
  );
}
