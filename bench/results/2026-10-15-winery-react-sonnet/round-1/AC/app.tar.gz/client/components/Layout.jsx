import { Link, Outlet } from 'react-router';
import Logo from './Logo.jsx';

export default function Layout() {
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <header className="site-header">
        <div className="container site-header__inner">
          <Link to="/" className="brand" aria-label="Weingut Kieselbrunnen, home">
            <Logo />
            <span className="brand__text">
              <span className="brand__name">Weingut Kieselbrunnen</span>
              <span className="brand__tag">Family winery</span>
            </span>
          </Link>
        </div>
      </header>
      <main id="main" className="container main" tabIndex={-1}>
        <Outlet />
      </main>
      <footer className="site-footer">
        <div className="container site-footer__inner">
          <p>Weingut Kieselbrunnen · a family winery</p>
          <Link to="/staff">Staff</Link>
        </div>
      </footer>
    </>
  );
}
