export default function Logo() {
  return (
    <svg className="logo" viewBox="0 0 48 48" width="40" height="40" aria-hidden="true" focusable="false">
      <circle cx="24" cy="24" r="23" fill="currentColor" />
      <path d="M25 6c1 4 4 6 8 6-1 4-4 6-8 6z" fill="#cfd8b0" />
      <path d="M24 12v6" stroke="#cfd8b0" strokeWidth="2" strokeLinecap="round" />
      <g fill="#f6efe2">
        <circle cx="17" cy="23" r="4" />
        <circle cx="25" cy="23" r="4" />
        <circle cx="33" cy="23" r="4" />
        <circle cx="21" cy="30" r="4" />
        <circle cx="29" cy="30" r="4" />
        <circle cx="25" cy="37" r="4" />
      </g>
    </svg>
  );
}
