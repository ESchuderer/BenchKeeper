import { Link } from 'react-router';
import { formatStart } from '../../shared/dates.js';
import { formatMoney } from '../../shared/money.js';

export default function TastingCard({ tasting }) {
  const { id, title, startsAt, pricePerGuestCents, seatsLeft } = tasting;
  const soldOut = seatsLeft === 0;
  return (
    <article className={`card${soldOut ? ' card--sold-out' : ''}`} aria-labelledby={`t-${id}`}>
      <h2 id={`t-${id}`} className="card__title">{title}</h2>
      <p className="card__when">
        <time dateTime={startsAt}>{formatStart(startsAt)}</time>
      </p>
      <dl className="card__facts">
        <div>
          <dt>Price</dt>
          <dd>
            <span className="price">{formatMoney(pricePerGuestCents)}</span> <span className="muted">per guest</span>
          </dd>
        </div>
        <div>
          <dt>Availability</dt>
          <dd>
            {soldOut ? (
              <span className="badge badge--sold-out">Fully booked</span>
            ) : (
              <span className={`badge ${seatsLeft <= 3 ? 'badge--low' : 'badge--ok'}`}>{seatsLeft} seats left</span>
            )}
          </dd>
        </div>
      </dl>
      {!soldOut && (
        <Link className="button" to={`/book/${id}`}>
          Book {title}
        </Link>
      )}
    </article>
  );
}
