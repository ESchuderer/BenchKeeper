import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { bookingSchema, MAX_GUESTS } from '../../shared/schemas.js';
import { formatStart } from '../../shared/dates.js';
import { formatMoney } from '../../shared/money.js';
import { ApiError, createBooking, getTasting } from '../api.js';
import { useLoad } from '../useLoad.js';
import Field from '../components/Field.jsx';
import NotFound from './NotFound.jsx';

function Summary({ tasting }) {
  return (
    <dl className="summary">
      <div><dt>When</dt><dd><time dateTime={tasting.startsAt}>{formatStart(tasting.startsAt)}</time></dd></div>
      <div><dt>Price</dt><dd>{formatMoney(tasting.pricePerGuestCents)} per guest</dd></div>
      <div><dt>Availability</dt><dd>{tasting.seatsLeft} seats left</dd></div>
    </dl>
  );
}

function SoldOut({ tasting }) {
  return (
    <section className="panel panel--narrow">
      <p className="eyebrow">Book a tasting</p>
      <h1>{tasting.title}</h1>
      <div className="notice notice--sold-out" role="status">
        <p><strong>Fully booked.</strong> Every seat for this tasting has been taken.</p>
      </div>
      <Link className="button" to="/">See all tastings</Link>
    </section>
  );
}

function Confirmation({ booking }) {
  const heading = useRef(null);
  useEffect(() => {
    heading.current?.focus();
    window.scrollTo?.(0, 0);
  }, []);
  return (
    <section className="panel panel--narrow confirmation">
      <p className="eyebrow eyebrow--success">Thank you, {booking.name}</p>
      <h1 ref={heading} tabIndex={-1}>Booking confirmed</h1>
      <p>Your seats are reserved. Please bring your booking reference; you pay at the winery.</p>
      <dl className="receipt">
        <div><dt>Tasting</dt><dd>{booking.tasting.title}</dd></div>
        <div><dt>When</dt><dd><time dateTime={booking.tasting.startsAt}>{formatStart(booking.tasting.startsAt)}</time></dd></div>
        <div><dt>Guests</dt><dd>{booking.guests}</dd></div>
        <div><dt>Total price</dt><dd>{formatMoney(booking.totalCents)}</dd></div>
        <div><dt>Booking reference</dt><dd className="reference">{booking.reference}</dd></div>
      </dl>
      <Link className="button button--secondary" to="/">Back to all tastings</Link>
    </section>
  );
}

function BookingForm({ tasting, onBooked, onSoldOut, onSeatsChanged }) {
  const [formError, setFormError] = useState('');
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(bookingSchema), // the seats left are decided by the server, which always has the current count
    defaultValues: { name: '', email: '', guests: String(Math.min(2, tasting.seatsLeft)) },
  });

  const submit = handleSubmit(async (values) => {
    setFormError('');
    try {
      onBooked(await createBooking(tasting.id, values));
    } catch (err) {
      if (!(err instanceof ApiError)) throw err;
      if (err.status === 409) {
        if (err.seatsLeft === 0) return onSoldOut();
        onSeatsChanged(err.seatsLeft);
      }
      const fields = Object.entries(err.errors);
      if (fields.length === 0) {
        setFormError(err.status === 0 ? 'We could not reach the server. Please try again.' : 'Something went wrong. Please try again.');
      }
      for (const [field, message] of fields) setError(field, { type: 'server', message });
    }
  });

  return (
    <form className="form" onSubmit={submit} noValidate>
      <Field label="Name" type="text" autoComplete="name" {...register('name')} error={errors.name?.message} />
      <Field label="Email" type="email" autoComplete="email" inputMode="email" {...register('email')} error={errors.email?.message} />
      <Field
        label="Guests"
        type="number"
        inputMode="numeric"
        min="1"
        max={MAX_GUESTS}
        step="1"
        hint={`1 to ${MAX_GUESTS} guests`}
        {...register('guests')}
        error={errors.guests?.message}
      />
      {formError && <p className="notice notice--error" role="alert">{formError}</p>}
      <button className="button button--block" type="submit" disabled={isSubmitting}>Book</button>
    </form>
  );
}

export default function Book() {
  const { id } = useParams();
  return <BookTasting key={id} id={id} />; // fresh state for every tasting
}

function BookTasting({ id }) {
  const { status, data, error } = useLoad(() => getTasting(id), id);
  const [booking, setBooking] = useState(null);
  const [override, setOverride] = useState(null); // seats left learned from a refused booking

  useEffect(() => {
    document.title = data ? `Book ${data.title} · Weingut Kieselbrunnen` : 'Book a tasting · Weingut Kieselbrunnen';
  }, [data]);

  if (status === 'loading') return <p className="status" role="status">Loading tasting…</p>;
  if (status === 'error') {
    return error.status === 404 ? (
      <NotFound what="tasting" />
    ) : (
      <div className="notice notice--error" role="alert">
        <p>We could not load this tasting. Please try again.</p>
        <Link className="button button--secondary" to="/">See all tastings</Link>
      </div>
    );
  }
  if (booking) return <Confirmation booking={booking} />;

  const tasting = override === null ? data : { ...data, seatsLeft: override };
  if (tasting.seatsLeft === 0) return <SoldOut tasting={tasting} />;

  return (
    <section className="panel panel--narrow">
      <Link className="back" to="/">← All tastings</Link>
      <p className="eyebrow">Book a tasting</p>
      <h1>{tasting.title}</h1>
      <Summary tasting={tasting} />
      <BookingForm
        tasting={tasting}
        onBooked={setBooking}
        onSoldOut={() => setOverride(0)}
        onSeatsChanged={setOverride}
      />
    </section>
  );
}
