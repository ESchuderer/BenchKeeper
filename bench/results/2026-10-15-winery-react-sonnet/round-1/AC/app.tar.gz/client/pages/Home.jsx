import { useEffect } from 'react';
import { listTastings } from '../api.js';
import { useLoad } from '../useLoad.js';
import TastingCard from '../components/TastingCard.jsx';

export default function Home() {
  const { status, data, reload } = useLoad(listTastings, 'tastings');
  useEffect(() => {
    document.title = 'Wine tastings · Weingut Kieselbrunnen';
  }, []);

  return (
    <>
      <section className="hero">
        <p className="eyebrow">Tastings 2026</p>
        <h1>Wine tastings at Weingut Kieselbrunnen</h1>
        <p className="lead">
          Pick an evening, reserve your seats and join us at the family winery. You pay on the day.
        </p>
      </section>

      {status === 'loading' && <p className="status" role="status">Loading tastings…</p>}
      {status === 'error' && (
        <div className="notice notice--error" role="alert">
          <p>We could not load the tastings. Please check your connection.</p>
          <button type="button" className="button button--secondary" onClick={reload}>Try again</button>
        </div>
      )}
      {status === 'done' && (
        <div className="cards">
          {data.map((t) => (
            <TastingCard key={t.id} tasting={t} />
          ))}
        </div>
      )}
    </>
  );
}
