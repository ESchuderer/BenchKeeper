import { Link } from 'react-router';

export default function NotFound({ what = 'page' }) {
  return (
    <section className="panel panel--narrow">
      <p className="eyebrow">Error 404</p>
      <h1>This {what} was not found</h1>
      <p>The address may be mistyped, or the {what} no longer exists.</p>
      <Link className="button" to="/">See all tastings</Link>
    </section>
  );
}
