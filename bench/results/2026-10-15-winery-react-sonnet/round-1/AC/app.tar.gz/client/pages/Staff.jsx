import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { loginSchema } from '../../shared/schemas.js';
import { formatStart } from '../../shared/dates.js';
import { formatMoney } from '../../shared/money.js';
import { ApiError, cancelBooking, getStaffSession, listStaffBookings, staffLogin, staffLogout } from '../api.js';
import Field from '../components/Field.jsx';

function SignIn({ onSignedIn, notice }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(loginSchema), defaultValues: { password: '' } });

  const submit = handleSubmit(async ({ password }) => {
    try {
      await staffLogin(password);
      onSignedIn();
    } catch (err) {
      if (!(err instanceof ApiError)) throw err;
      setError('password', {
        type: 'server',
        message: err.errors.password ?? 'We could not sign you in. Please try again.',
      });
    }
  });

  return (
    <section className="panel panel--narrow">
      <p className="eyebrow">Staff</p>
      <h1>Staff sign-in</h1>
      <p>Sign in to see who is coming to the tastings.</p>
      {notice && <p className="notice notice--error" role="alert">{notice}</p>}
      <form className="form" onSubmit={submit} noValidate>
        <Field label="Password" type="password" autoComplete="current-password" {...register('password')} error={errors.password?.message} />
        <button className="button button--block" type="submit" disabled={isSubmitting}>Sign in</button>
      </form>
    </section>
  );
}

function BookingsTable({ group, onCancel, busy }) {
  const { tasting, bookings } = group;
  const headingId = `staff-${tasting.id}`;
  const booked = tasting.seats - tasting.seatsLeft;
  return (
    <section className="group" aria-labelledby={headingId}>
      <header className="group__head">
        <h2 id={headingId}>{tasting.title}</h2>
        <p className="muted">
          <time dateTime={tasting.startsAt}>{formatStart(tasting.startsAt)}</time> · {booked} of {tasting.seats} seats booked
        </p>
      </header>
      {bookings.length === 0 ? (
        <p className="empty">No bookings yet.</p>
      ) : (
        <table className="bookings">
          <caption className="sr-only">Bookings for {tasting.title}</caption>
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Guests</th>
              <th scope="col">Reference</th>
              <th scope="col"><span className="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b.reference}>
                <td data-label="Name" id={`n-${b.reference}`}>{b.name}</td>
                <td data-label="Email">{b.email}</td>
                <td data-label="Guests">{b.guests}</td>
                <td data-label="Reference" className="reference">{b.reference}</td>
                <td className="bookings__action">
                  <button
                    type="button"
                    className="button button--danger button--small"
                    aria-describedby={`n-${b.reference}`}
                    disabled={busy === b.reference}
                    onClick={() => onCancel(b)}
                  >
                    Cancel
                  </button>
                  <span className="sr-only"> ({formatMoney(b.totalCents)})</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

function Bookings({ onSignedOut }) {
  const [groups, setGroups] = useState(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(null);

  const refresh = useCallback(async () => {
    try {
      setGroups(await listStaffBookings());
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) return onSignedOut('Your session has ended. Please sign in again.');
      setMessage('We could not load the bookings. Please try again.');
    }
  }, [onSignedOut]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const cancel = async (booking) => {
    setMessage('');
    setBusy(booking.reference);
    try {
      await cancelBooking(booking.reference);
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) return onSignedOut('Your session has ended. Please sign in again.');
      setMessage(
        err instanceof ApiError && err.status === 404
          ? `The booking by ${booking.name} no longer exists. The list was refreshed.`
          : 'We could not cancel the booking. Please try again.',
      );
    }
    setBusy(null);
    await refresh();
  };

  const signOut = async () => {
    await staffLogout().catch(() => {});
    onSignedOut();
  };

  return (
    <>
      <div className="staff-head">
        <div>
          <p className="eyebrow">Staff</p>
          <h1>Bookings</h1>
        </div>
        <button type="button" className="button button--secondary" onClick={signOut}>Sign out</button>
      </div>
      {message && <p className="notice notice--error" role="alert">{message}</p>}
      {groups === null ? (
        !message && <p className="status" role="status">Loading bookings…</p>
      ) : (
        <div className="groups">
          {groups.map((g) => (
            <BookingsTable key={g.tasting.id} group={g} onCancel={cancel} busy={busy} />
          ))}
        </div>
      )}
    </>
  );
}

export default function Staff() {
  const [phase, setPhase] = useState('checking');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    document.title = 'Staff · Weingut Kieselbrunnen';
    getStaffSession().then(
      ({ signedIn }) => setPhase(signedIn ? 'in' : 'out'),
      () => setPhase('out'),
    );
  }, []);

  const signedOut = useCallback((message = '') => {
    setNotice(message);
    setPhase('out');
  }, []);

  if (phase === 'checking') return <p className="status" role="status">Loading…</p>;
  if (phase === 'out') return <SignIn notice={notice} onSignedIn={() => { setNotice(''); setPhase('in'); }} />;
  return <Bookings onSignedOut={signedOut} />;
}
