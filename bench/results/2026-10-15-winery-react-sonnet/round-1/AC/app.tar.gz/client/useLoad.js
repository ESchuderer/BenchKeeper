import { useCallback, useEffect, useState } from 'react';

/** Runs `load()` on mount and whenever `key` changes; `reload()` runs it again. */
export function useLoad(load, key) {
  const [state, setState] = useState({ status: 'loading', data: null, error: null });
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let current = true;
    setState((s) => (s.status === 'loading' ? s : { ...s, status: 'loading' }));
    load().then(
      (data) => current && setState({ status: 'done', data, error: null }),
      (error) => current && setState({ status: 'error', data: null, error }),
    );
    return () => {
      current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, tick]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { ...state, reload };
}
