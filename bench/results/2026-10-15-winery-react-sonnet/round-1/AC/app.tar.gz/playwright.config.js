import { defineConfig } from '@playwright/test';

const PORT = 3100;

export default defineConfig({
  testDir: 'tests/e2e',
  fullyParallel: false,
  workers: 1,
  reporter: 'list',
  use: { baseURL: `http://localhost:${PORT}` },
  webServer: {
    command: 'npm run build && npm start',
    port: PORT,
    reuseExistingServer: false,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-secret' },
  },
});
