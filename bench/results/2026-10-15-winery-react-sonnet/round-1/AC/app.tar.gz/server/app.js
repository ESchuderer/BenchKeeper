import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import { bookingSchema, loginSchema, fieldErrors, seatsLeftMessage } from '../shared/schemas.js';
import { createStaffSessions, loginLimiter, passwordMatches, requireStaff } from './staffAuth.js';

const DIST = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist');

export function createApp({ store, staffPassword, loginLimit = 20, distDir = DIST, trustProxy }) {
  const app = express();
  // Only when a reverse proxy sits in front: otherwise X-Forwarded-For could be spoofed to dodge the login limit.
  if (trustProxy) app.set('trust proxy', trustProxy);
  const sessions = createStaffSessions();
  app.disable('x-powered-by');
  // No upgrade-insecure-requests / HSTS: the app may be served over plain HTTP (TLS is the proxy's job).
  app.use(helmet({ hsts: false, contentSecurityPolicy: { directives: { upgradeInsecureRequests: null } } }));
  app.use(express.json({ limit: '10kb' }));

  const api = express.Router();
  api.use(sessions.middleware);

  api.get('/tastings', (req, res) => res.json(store.listTastings()));

  api.get('/tastings/:id', (req, res) => {
    const tasting = store.getTasting(req.params.id);
    if (!tasting) return res.status(404).json({ error: 'Tasting not found.' });
    res.json(tasting);
  });

  api.post('/tastings/:id/bookings', (req, res) => {
    const tasting = store.getTasting(req.params.id);
    if (!tasting) return res.status(404).json({ error: 'Tasting not found.' });
    const parsed = bookingSchema.safeParse(req.body ?? {});
    if (!parsed.success) return res.status(400).json({ errors: fieldErrors(parsed.error) });
    const result = store.reserve(tasting.id, parsed.data);
    if (!result.ok) {
      return res.status(409).json({ errors: { guests: seatsLeftMessage(result.seatsLeft) }, seatsLeft: result.seatsLeft });
    }
    const { booking } = result;
    res.status(201).json({
      reference: booking.reference,
      tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt },
      name: booking.name,
      email: booking.email,
      guests: booking.guests,
      totalCents: booking.totalCents,
    });
  });

  const staff = express.Router();
  staff.use((req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });

  staff.post('/login', loginLimiter(loginLimit), (req, res) => {
    const parsed = loginSchema.safeParse(req.body ?? {});
    if (!parsed.success) return res.status(400).json({ errors: fieldErrors(parsed.error) });
    if (!passwordMatches(parsed.data.password, staffPassword)) {
      return res.status(401).json({ errors: { password: 'That password is not correct.' } });
    }
    sessions.start(req);
    res.status(204).end();
  });

  staff.post('/logout', (req, res) => {
    sessions.end(req);
    res.status(204).end();
  });

  staff.get('/session', (req, res) => res.json({ signedIn: sessions.isActive(req) }));

  staff.get('/bookings', requireStaff(sessions), (req, res) => res.json(store.listBookingsByTasting()));

  staff.delete('/bookings/:reference', requireStaff(sessions), (req, res) => {
    const result = store.cancel(req.params.reference);
    if (!result.ok) return res.status(404).json({ error: 'This booking no longer exists.' });
    res.status(204).end();
  });

  api.use('/staff', staff);
  api.use((req, res) => res.status(404).json({ error: 'Not found.' }));
  app.use('/api', api);

  app.use(express.static(distDir));
  app.get('/{*splat}', (req, res, next) => {
    // Missing files (assets, robots.txt, ...) are real 404s; only extension-less paths are client routes.
    if (path.extname(req.path)) return next();
    const index = path.join(distDir, 'index.html');
    if (!existsSync(index)) {
      return res.status(503).type('text').send('The web app has not been built yet. Run "npm run build" and restart the server.');
    }
    res.sendFile(index);
  });

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'The request body is not valid JSON.' });
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'The request is too large.' });
    if (err.status >= 400 && err.status < 500) return res.status(err.status).json({ error: 'The request could not be processed.' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on our side. Please try again.' });
  });

  return app;
}
