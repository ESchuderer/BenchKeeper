import { existsSync } from 'node:fs';
import { createApp } from './app.js';
import { createStore } from './store.js';

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: nobody will be able to sign in at /staff.');
}

if (!existsSync(new URL('../dist/index.html', import.meta.url))) {
  console.warn('dist/ is missing: run "npm run build" first, or the pages will not load.');
}

// TRUST_PROXY: number of reverse proxies in front of the app (e.g. 1), so client IPs are read correctly.
const trustProxy = process.env.TRUST_PROXY ? Number(process.env.TRUST_PROXY) || process.env.TRUST_PROXY : undefined;

createApp({ store: createStore(), staffPassword, trustProxy }).listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings on http://localhost:${port}`);
});
