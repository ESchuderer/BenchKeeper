import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import cookieSession from 'cookie-session';
import rateLimit from 'express-rate-limit';

const digest = (value) => createHash('sha256').update(value).digest();

/** Constant-time password check; an unset or empty STAFF_PASSWORD never matches. */
export function passwordMatches(candidate, expected) {
  const same = timingSafeEqual(digest(candidate), digest(expected ?? ''));
  return same && typeof expected === 'string' && expected.length > 0;
}

const SESSION_MS = 8 * 60 * 60 * 1000;

/**
 * Staff sessions: the cookie is signed and carries a random session id; the id is only valid while
 * the server still knows it, so signing out (or restarting) revokes it everywhere.
 */
export function createStaffSessions() {
  const live = new Map(); // id -> expiry time
  return {
    middleware: cookieSession({
      name: 'session',
      keys: [randomBytes(32).toString('hex')],
      httpOnly: true,
      sameSite: 'strict',
      maxAge: SESSION_MS,
    }),
    start(req) {
      const now = Date.now();
      for (const [other, expires] of live) if (expires < now) live.delete(other);
      const id = randomUUID();
      live.set(id, now + SESSION_MS);
      req.session.sid = id;
    },
    isActive(req) {
      const id = req.session?.sid;
      const expires = typeof id === 'string' ? live.get(id) : undefined;
      if (expires === undefined) return false;
      if (expires < Date.now()) {
        live.delete(id);
        return false;
      }
      return true;
    },
    end(req) {
      if (typeof req.session?.sid === 'string') live.delete(req.session.sid);
      req.session = null;
    },
  };
}

/** Only failed attempts count towards the limit. */
export function loginLimiter(limit) {
  return rateLimit({
    windowMs: 15 * 60 * 1000,
    limit,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    handler: (req, res) =>
      res.status(429).json({ errors: { password: 'Too many failed attempts. Please wait a few minutes and try again.' } }),
  });
}

export const requireStaff = (sessions) => (req, res, next) => {
  if (sessions.isActive(req)) return next();
  res.status(401).json({ error: 'Staff sign-in required.' });
};
