import { randomInt } from 'node:crypto';
import { TASTINGS } from './tastings.js';

// No 0/O/1/I, so references can be read out over the phone.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function newReference(issued, random) {
  for (;;) {
    let code = '';
    for (let i = 0; i < 6; i++) code += REFERENCE_ALPHABET[random(REFERENCE_ALPHABET.length)];
    const reference = `KB-${code}`;
    if (!issued.has(reference)) return reference;
  }
}

/**
 * In-memory tastings and bookings. Every method is synchronous, so a seat check and the write
 * that follows it can never interleave with another request on Node's single thread.
 */
export function createStore(tastings = TASTINGS, { random = randomInt } = {}) {
  const sorted = [...tastings].sort((a, b) => a.startsAt.localeCompare(b.startsAt));
  const bookings = new Map();
  const issued = new Set(); // every reference ever handed out, so a stale cancel can never hit a newer booking

  const seatsTaken = (tastingId) => {
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === tastingId) taken += b.guests;
    return taken;
  };
  const withSeatsLeft = (t) => ({ ...t, seatsLeft: t.seats - seatsTaken(t.id) });

  return {
    listTastings: () => sorted.map(withSeatsLeft),

    getTasting(id) {
      const t = sorted.find((x) => x.id === id);
      return t ? withSeatsLeft(t) : null;
    },

    reserve(tastingId, { name, email, guests }) {
      const tasting = sorted.find((x) => x.id === tastingId);
      if (!tasting) return { ok: false, reason: 'UNKNOWN_TASTING' };
      const seatsLeft = tasting.seats - seatsTaken(tastingId);
      if (guests > seatsLeft) return { ok: false, reason: 'NOT_ENOUGH_SEATS', seatsLeft };
      const booking = {
        reference: newReference(issued, random),
        tastingId,
        name,
        email,
        guests,
        totalCents: guests * tasting.pricePerGuestCents,
        createdAt: new Date().toISOString(),
      };
      issued.add(booking.reference);
      bookings.set(booking.reference, booking);
      return { ok: true, booking: { ...booking } };
    },

    cancel(reference) {
      return bookings.delete(reference) ? { ok: true } : { ok: false, reason: 'UNKNOWN_BOOKING' };
    },

    listBookingsByTasting() {
      return sorted.map((t) => ({
        tasting: withSeatsLeft(t),
        bookings: [...bookings.values()].filter((b) => b.tastingId === t.id).map((b) => ({ ...b })),
      }));
    },
  };
}
