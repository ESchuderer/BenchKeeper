export const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuestCents: 2500, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuestCents: 3200, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuestCents: 2800, seats: 10 },
];
