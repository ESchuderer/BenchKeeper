const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** '2026-11-06T18:00' -> 'Fri, 2026-11-06 18:00'. Local winery time, so no timezone conversion. */
export function formatStart(startsAt) {
  const [date, time] = startsAt.split('T');
  const [y, m, d] = date.split('-').map(Number);
  return `${WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()]}, ${date} ${time}`;
}
