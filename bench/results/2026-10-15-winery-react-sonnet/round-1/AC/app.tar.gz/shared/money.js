export function formatMoney(cents) {
  const euros = cents / 100;
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`;
}
