import { z } from 'zod';

export const MAX_GUESTS = 8;

const wholeNumber = (value) => (typeof value === 'string' && /^\d+$/.test(value.trim()) ? Number(value.trim()) : value);

export const bookingSchema = z.object({
  name: z
    .string({ error: 'Please enter your name.' })
    .trim()
    .min(1, 'Please enter your name.')
    .max(100, 'Please use 100 characters or fewer.'),
  email: z
    .string({ error: 'Please enter your email address.' })
    .trim()
    .min(1, 'Please enter your email address.')
    .max(254, 'This email address is too long.')
    .pipe(z.email('Please enter a valid email address, like name@example.com.')),
  guests: z.preprocess(
    wholeNumber,
    z
      .number({ error: `Please enter a whole number of guests from 1 to ${MAX_GUESTS}.` })
      .int(`Please enter a whole number of guests from 1 to ${MAX_GUESTS}.`)
      .min(1, 'At least 1 guest is needed.')
      .max(MAX_GUESTS, `You can book up to ${MAX_GUESTS} guests at a time.`),
  ),
});

export const loginSchema = z.object({
  password: z.string({ error: 'Please enter the password.' }).min(1, 'Please enter the password.'),
});

/** First message per field, as { field: message }. */
export function fieldErrors(error) {
  const errors = {};
  for (const issue of error.issues) {
    const field = issue.path[0];
    if (field !== undefined && !(field in errors)) errors[field] = issue.message;
  }
  return errors;
}

export const seatsLeftMessage = (seatsLeft) =>
  seatsLeft === 0
    ? 'Sorry, this tasting is fully booked.'
    : `Only ${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left for this tasting.`;
