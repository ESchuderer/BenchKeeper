# HTTP API Contract

All bodies are JSON. Field errors use `{ "errors": { "<field>": "<message>" } }` where field is
`name`, `email`, `guests` or `password`.

| Method & path | Auth | Success | Failure |
|---|---|---|---|
| `GET /api/tastings` | none | 200 `[Tasting+seatsLeft]` | |
| `GET /api/tastings/:id` | none | 200 `Tasting+seatsLeft` | 404 |
| `POST /api/tastings/:id/bookings` `{name,email,guests}` | none | 201 `{reference, tasting:{id,title,startsAt}, name, email, guests, totalCents}` | 400 field errors; 409 `{errors:{guests}, seatsLeft}` when not enough seats (including 0); 404 unknown tasting |
| `POST /api/staff/login` `{password}` | none | 204 + session cookie | 401 `{errors:{password}}`; 429 rate limit |
| `POST /api/staff/logout` | none | 204 | |
| `GET /api/staff/session` | cookie | 200 `{signedIn:boolean}` | |
| `GET /api/staff/bookings` | staff | 200 `[{tasting, bookings:[{reference,name,email,guests,totalCents}]}]` (all tastings, in date order) | 401 |
| `DELETE /api/staff/bookings/:reference` | staff | 204 | 401; 404 unknown/already cancelled |

Every route that reads or changes booking data requires the staff session; only login, logout and session-status are open.

Tasting JSON: `{id,title,startsAt,pricePerGuestCents,seats,seatsLeft}`.

Client routes: `/` list, `/book/:id` form then confirmation, `/staff`, anything else = not found page.
Unknown `/api/*` paths return JSON 404.
