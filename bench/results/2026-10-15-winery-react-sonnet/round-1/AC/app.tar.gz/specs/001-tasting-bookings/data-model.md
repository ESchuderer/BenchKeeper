# Data Model

## Tasting (seed data, fixed)
| Field | Type | Notes |
|---|---|---|
| id | string slug | `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting` |
| title | string | |
| startsAt | string `YYYY-MM-DDTHH:mm` | local time |
| pricePerGuestCents | integer | 2500, 3200, 2800 |
| seats | integer | 12, 8, 10 |
| seatsLeft | derived | `seats - sum(guests of active bookings)` |

## Booking
| Field | Type | Rules |
|---|---|---|
| reference | string | `KB-` + 6 chars from an unambiguous alphabet (no 0/O/1/I), unique |
| tastingId | string | must exist |
| name | string | trimmed, 1-100 chars |
| email | string | trimmed, valid address, max 254 chars |
| guests | integer | 1-8 and <= seatsLeft at write time |
| totalCents | integer | guests x pricePerGuestCents |
| createdAt | ISO timestamp | |

## Transitions
- `reserve(tastingId, input)` -> Booking, or `SOLD_OUT`/`NOT_ENOUGH_SEATS` (with seatsLeft) / `UNKNOWN_TASTING`.
- `cancel(reference)` -> removes the booking (seats freed) or `UNKNOWN_BOOKING`.
