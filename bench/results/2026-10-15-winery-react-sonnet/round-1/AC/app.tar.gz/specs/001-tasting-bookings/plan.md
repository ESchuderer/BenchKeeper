# Implementation Plan: Wine Tasting Bookings

**Branch**: `001-tasting-bookings` | **Date**: 2026-10-15 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-tasting-bookings/spec.md`

## Summary

One Node process: an Express 5 JSON API plus the built React single-page app. Guests list tastings,
book through a validated form, and see a confirmation. Staff sign in with the `STAFF_PASSWORD`
secret, see bookings grouped by tasting and cancel them. Bookings live in memory; reserving seats
is one synchronous check-and-write, which makes it atomic on Node's single thread. Validation
schemas (zod) are shared by client and server, the server being authoritative.

## Technical Context

**Language/Version**: JavaScript (ESM), Node.js 22; React 19 (JSX)

**Primary Dependencies**: express 5, zod 4, cookie-session, express-rate-limit, react, react-dom,
react-router (declarative mode), react-hook-form + @hookform/resolvers, vite + @vitejs/plugin-react

**Storage**: in-memory store behind a small repository interface (`server/store.js`)

**Testing**: Vitest + Supertest (API and store), Vitest + Testing Library (components),
Playwright (end-to-end against the built app)

**Target Platform**: Linux server, modern browsers incl. phones (360 px and up)

**Project Type**: web application (single package, `client/` + `server/` + `shared/`)

**Performance Goals**: not critical; a few dozen bookings

**Constraints**: no external services (also no web-font CDN: system font stacks); zero overbookings

**Scale/Scope**: 3 tastings, 2 audiences, 4 pages (list, booking form + confirmation, staff)

## Constitution Check

| Principle | Gate | Status |
|---|---|---|
| I Test-First | Tasks put failing tests before each implementation task; API, component and e2e levels | Pass |
| II Never Overbook | `store.reserve()` checks and writes synchronously; concurrency test with parallel requests | Pass |
| III Libraries | Express, zod, react-hook-form, react-router, cookie-session, express-rate-limit, Vite | Pass |
| IV Simplicity | In-memory store, one process, no extra services, no accounts | Pass |
| V Security | Env password, `crypto.timingSafeEqual` on SHA-256 digests, httpOnly+SameSite cookie, rate-limited login, React escaping | Pass |
| VI Accessible UI | Labelled fields, `aria-invalid`/`aria-describedby` errors, `role="alert"`, mobile-first CSS | Pass |

Re-check after design: still passing; no complexity violations.

## Project Structure

### Documentation (this feature)

```text
specs/001-tasting-bookings/
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/api.md
└── tasks.md             # created by /speckit-tasks
```

### Source Code (repository root)

```text
package.json
vite.config.js
index.html                 # Vite entry
shared/
├── schemas.js             # zod booking + login schemas, limits
└── money.js               # cents -> "EUR 25"
server/
├── index.js               # starts listening on PORT
├── app.js                 # createApp({ store, staffPassword }) for tests
├── store.js               # tastings, bookings, reserve/cancel
├── staffAuth.js           # password check, session middleware
└── tastings.js            # seed data
client/
├── main.jsx
├── App.jsx                # routes + layout
├── api.js                 # fetch wrappers
├── styles.css             # tokens + components
├── components/            # TastingCard, Field, Layout, ...
└── pages/                 # Home, Book, Staff, NotFound
tests/
├── api/                   # supertest
├── client/                # Testing Library
└── e2e/                   # Playwright
```

**Structure Decision**: single package with three folders; the Express app serves `dist/` and
falls back to `index.html` for client routes, so `npm start` is the whole app.

## Complexity Tracking

No violations.
