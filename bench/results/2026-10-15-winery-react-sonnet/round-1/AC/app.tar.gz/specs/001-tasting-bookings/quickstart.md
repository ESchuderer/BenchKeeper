# Quickstart / Validation Guide

Prerequisites: Node 22.

```sh
npm install
npm run build
STAFF_PASSWORD=secret PORT=3000 npm start
```

Scenarios (also automated in `tests/e2e`):
1. Open `/`: three tastings with "12 seats left", "8 seats left", "10 seats left".
2. "Book Riesling Evening", enter Name/Email, Guests 2, "Book" -> "Booking confirmed", total EUR 50, reference; `/` shows 10 seats left.
3. Submit empty / bad email / Guests 0, 9 -> errors beside each field. Guests above seats left -> error beside Guests.
4. `/staff`: wrong password -> error; `secret` -> bookings grouped by tasting; "Cancel" -> booking gone, `/` shows seats restored.
5. Book all seats of a tasting -> "Fully booked", no "Book ..." link.

Checks: `npm test` (unit/API/component), `npm run test:e2e` (Playwright).
Details: [data-model.md](data-model.md), [contracts/api.md](contracts/api.md).
