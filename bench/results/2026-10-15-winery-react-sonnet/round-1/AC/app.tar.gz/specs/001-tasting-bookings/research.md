# Research: Wine Tasting Bookings

## Server: Express 5
- **Decision**: Express 5 (stable, async error handling, serves static files).
- **Alternatives**: Fastify (fine, but Express is the lowest-risk, best-known choice); Next.js (more machinery than a 4-page app needs).

## Front end: React 19 + Vite + React Router (declarative mode)
- **Decision**: Vite SPA built to `dist/`, served by Express. Client routes `/`, `/book/:id`, `/staff`.
- **Alternatives**: Next/Remix (SSR not needed; second runtime concept); CRA (unmaintained).

## Forms and validation: react-hook-form + zod
- **Decision**: one zod schema in `shared/` used by the form (via `@hookform/resolvers`) and by the server. Server errors (409 seats, 400) are mapped onto fields with `setError`.
- **Alternatives**: hand-written validation (rejected by constitution III); native-only validation (messages inconsistent and not next to field in a styled way). Forms use `noValidate` so our messages show.

## Atomic seat reservation
- **Decision**: in-memory store; `reserve()` computes seats left from active bookings and pushes the booking in the same synchronous function. Node runs it without interleaving, so parallel requests are serialized. A test fires parallel HTTP requests to prove it.
- **Alternatives**: SQLite (external-ish dependency, unnecessary); file store (needs locking, adds stale-state risk at start).

## Staff authentication
- **Decision**: password in `STAFF_PASSWORD`; compare SHA-256 digests with `crypto.timingSafeEqual` (equal length, constant time); unset/empty password = login always fails. Session via `cookie-session` (signed, httpOnly, SameSite=Strict, Secure when behind HTTPS); signing key is random per process. Login limited with `express-rate-limit`: only failed attempts count (`skipSuccessfulRequests`), 20 per 15 min per IP.
- **Alternatives**: express-session (needs a store for production, memory store leaks); JWT (no need).
- Cancel/logout are state-changing; SameSite=Strict plus JSON-only bodies covers CSRF for this app.

## Styling
- **Decision**: hand-written CSS with custom properties (tokens), mobile-first, system serif headings (Georgia) over a system sans body, burgundy / cream / olive palette; no web fonts or CDN.
- **Alternatives**: Tailwind (build config for little gain); component kits (generic look).

## Money and dates
- Prices stored as integer cents; shown "EUR 25" / "EUR 25.50". Dates are stored as local `YYYY-MM-DDTHH:mm` strings and shown as "Fri, 2026-11-06 18:00" without timezone conversion.

## Testing
- Vitest (shares Vite config) with Supertest against `createApp()` using a fresh store; Testing Library for the form; Playwright against `npm start` for the real journeys and a 360 px viewport check. Playwright browser availability is verified in the first task.
