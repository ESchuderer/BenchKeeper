# Feature Specification: Wine Tasting Bookings

**Feature Branch**: `001-tasting-bookings`

**Created**: 2026-10-15

**Status**: Draft

**Input**: User description: "Web app for Weingut Kieselbrunnen, a family winery, so guests can book wine tastings online and staff can see the bookings."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Guest books a tasting (Priority: P1)

A guest opens the winery's start page, sees the tastings on offer with date, time, price per guest and seats left, chooses one with "Book <tasting title>", fills in name, email and number of guests, and receives a confirmation with a booking reference.

**Why this priority**: This is the reason the app exists; without it the winery gets no online bookings.

**Independent Test**: Open the start page, click "Book Riesling Evening", enter valid details, press "Book" and see "Booking confirmed" with tasting, guests, total price and reference; the start page then shows fewer seats left.

**Acceptance Scenarios**:

1. **Given** a fresh start, **When** the guest opens the start page, **Then** three tastings are listed: Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats left), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats left), Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats left).
2. **Given** the start page, **When** the guest chooses "Book Riesling Evening", **Then** a form with "Name", "Email", "Guests" (1 to 8) and a "Book" button is shown for that tasting.
3. **Given** valid details with 2 guests for Riesling Evening, **When** the guest presses "Book", **Then** "Booking confirmed" is shown with the tasting, 2 guests, total EUR 50 and a booking reference, and Riesling Evening now shows 10 seats left.
4. **Given** two bookings of 2 guests each, **When** both are made, **Then** their booking references differ.

---

### User Story 2 - Guest is protected from invalid and over-capacity bookings (Priority: P1)

Invalid input is rejected with a message next to the field concerned, and a booking can never take more seats than are left, even when several guests book at the same time.

**Why this priority**: Overbooking a small tasting is the main business risk; bad data makes bookings unusable.

**Independent Test**: Submit the form empty, with a malformed email, with 0 or 9 guests, and with more guests than seats left; verify per-field errors and that seats left never change. Fire parallel booking requests for the last seats and verify total booked never exceeds capacity.

**Acceptance Scenarios**:

1. **Given** the booking form, **When** Name is empty or blank, **Then** an error is shown next to Name and nothing is booked.
2. **Given** the booking form, **When** Email is empty or not a valid address, **Then** an error is shown next to Email.
3. **Given** the booking form, **When** Guests is empty, not a whole number, below 1 or above 8, **Then** an error is shown next to Guests.
4. **Given** Red Wine Cellar Tour has 3 seats left, **When** a guest asks for 4, **Then** an error next to Guests says only 3 seats are left and nothing is booked.
5. **Given** a tasting with 2 seats left, **When** two guests simultaneously book 2 seats each, **Then** exactly one succeeds and the other is told the seats are no longer available.
6. **Given** a tasting with no seats left, **When** the start page is shown, **Then** it is clearly marked "Fully booked" and offers no way to book it; opening its booking form directly shows the fully-booked state instead of a usable form.
7. **Given** a failed submission, **When** the guest corrects the field, **Then** the entered values were kept and the booking succeeds.

---

### User Story 3 - Staff sign in and see bookings (Priority: P2)

Staff open `/staff`, enter the password and see all bookings grouped by tasting with name, email, guests and reference.

**Why this priority**: Staff need to know who is coming, but the guest flow must exist first.

**Independent Test**: Open `/staff`, sign in with the configured password, and verify bookings made by guests appear under the correct tasting.

**Acceptance Scenarios**:

1. **Given** the staff page, **When** it is opened without being signed in, **Then** a "Password" field and a "Sign in" button are shown and no booking data is visible.
2. **Given** the sign-in form, **When** a wrong password is entered, **Then** an error is shown next to the field and no booking data is revealed.
3. **Given** the correct password, **When** staff press "Sign in", **Then** all three tastings are listed with their bookings (name, email, guests, reference); a tasting without bookings says so.
4. **Given** no signed-in session, **When** booking data is requested directly, **Then** it is refused.
5. **Given** no staff password is configured, **When** anyone tries to sign in, **Then** sign-in always fails.

---

### User Story 4 - Staff cancel a booking (Priority: P2)

Staff press "Cancel" on a booking; it disappears from the list and its seats become available to guests again.

**Why this priority**: Guests change plans; freed seats must be resellable.

**Independent Test**: Book 3 seats, sign in, cancel the booking, and verify the staff list no longer shows it and the start page seat count is restored.

**Acceptance Scenarios**:

1. **Given** a booking of 3 guests on a tasting with 9 seats left, **When** staff press "Cancel" on it, **Then** it disappears and the tasting shows 12 seats left.
2. **Given** a fully booked tasting, **When** a booking is cancelled, **Then** the tasting becomes bookable again.
3. **Given** a booking that was already cancelled elsewhere, **When** staff cancel it again, **Then** staff see a clear message and the list refreshes; seats are not freed twice.

---

### Edge Cases

- Whitespace-only name, or leading/trailing spaces around name and email: trimmed before validation.
- Very long name or email: rejected with a field error.
- Guests entered as "2.5", "abc", "-1", or "1e1": rejected.
- Guests exceeding seats left at the time of the request, even if the page showed more seats earlier: rejected with the up-to-date seat count.
- Unknown tasting address: a friendly "not found" page.
- Staff session cookie missing or tampered with: treated as signed out.
- Server restart: bookings are lost (in-memory storage).

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The start page MUST list every tasting with title, date and time, price per guest, and seats left shown as "<n> seats left".
- **FR-002**: Each bookable tasting MUST have a link or button named "Book <tasting title>" that opens a booking form for that tasting.
- **FR-003**: The booking form MUST have fields labelled "Name", "Email" and "Guests" (whole number 1 to 8) and a "Book" button.
- **FR-004**: The system MUST reject a booking with empty/blank name, invalid email, or guests that are not a whole number from 1 to 8, showing an error message next to the field concerned.
- **FR-005**: The system MUST NOT accept a booking that takes more seats than are left; the check and the reservation MUST be a single atomic step, including under concurrent requests.
- **FR-006**: A rejected booking for lack of seats MUST show, next to Guests, how many seats are left.
- **FR-007**: A successful booking MUST show a confirmation with heading "Booking confirmed", the tasting, number of guests, total price (guests times price per guest, in EUR) and a unique booking reference.
- **FR-008**: Seats left MUST reflect confirmed bookings immediately.
- **FR-009**: A tasting with no seats left MUST be shown as "Fully booked" and MUST NOT be bookable.
- **FR-010**: `/staff` MUST show a "Password" field and "Sign in" button when not signed in, and MUST verify the password against the `STAFF_PASSWORD` environment variable. If it is unset or empty, sign-in MUST always fail.
- **FR-011**: Signed-in staff MUST see all bookings grouped by tasting with name, email, guests and reference.
- **FR-012**: Booking data for staff MUST only be available to signed-in staff.
- **FR-013**: Signed-in staff MUST be able to cancel a booking with a "Cancel" button; the cancelled booking MUST leave the list and its seats MUST be freed.
- **FR-014**: Staff MUST be able to sign out.
- **FR-015**: The app MUST start with no bookings and need no external services.
- **FR-016**: All pages MUST be in English, use a coherent winery-style design, show distinct states for errors, success and fully-booked tastings, and work on phone-width screens.
- **FR-017**: Forms MUST be keyboard-usable with visible labels, and errors MUST be announced to assistive technology.

### Key Entities

- **Tasting**: title, date and time, price per guest, total seats; seats left is derived from active bookings.
- **Booking**: booking reference, tasting, guest name, guest email, number of guests, total price, creation time.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A guest can go from the start page to "Booking confirmed" in under 1 minute with no instructions.
- **SC-002**: Across any number of simultaneous booking attempts, the seats booked for a tasting never exceed its capacity (0 overbookings).
- **SC-003**: 100% of invalid submissions show an error next to the specific field concerned and create no booking.
- **SC-004**: Staff can find a given guest's booking and cancel it within 30 seconds of signing in.
- **SC-005**: After a cancellation, the freed seats are bookable by the next guest straight away.
- **SC-006**: All guest and staff pages are fully usable at 360 px width without horizontal scrolling.

## Assumptions

- Dates and times are the winery's local time and are displayed as given; there is no cut-off before the start time.
- There are exactly the three tastings from the brief; staff cannot edit tastings.
- Payment is not taken online; the total price is informational (paid at the winery).
- No email is sent; the on-screen confirmation and reference are the only confirmation.
- The same guest or email may make several bookings.
- Seats left uses the literal format "<n> seats left" for every non-zero count.
- A single shared staff password; no individual staff accounts.
- Bookings are held in server memory and do not survive a restart.
- Cancelled bookings are removed from the staff list rather than kept as history.
