# Tasks: Wine Tasting Bookings

**Input**: `specs/001-tasting-bookings/` (plan, spec, data-model, contracts/api.md)
**Tests**: Required (constitution I): each test task is written first and MUST fail before its implementation task.

Format: `- [ ] ID [P] [Story] Description with path` (`[P]` = parallelizable)

## Phase 1: Setup

- [x] T001 Create `package.json` (type module; scripts build/start/dev/test/test:e2e), install dependencies from plan.md, add `.gitignore` (node_modules, dist, test output)
- [x] T002 [P] Create `vite.config.js` (react plugin, `/api` dev proxy, Vitest config with jsdom for `tests/client`) and `index.html`
- [x] T003 Verify Playwright can launch a browser (`npx playwright install chromium`, or use a system browser) and add `playwright.config.js` (webServer = `npm start` on a test port with `STAFF_PASSWORD`)

## Phase 2: Foundational (blocks all stories)

- [x] T004 [P] Write failing tests for `shared/money.js` and `shared/schemas.js` (name/email/guests rules, trimming, limits) in `tests/api/shared.test.js`
- [x] T005 [P] Write failing tests for `server/store.js` (seed data, seatsLeft, reserve success/limits, unique references, cancel frees seats, unknown ids) in `tests/api/store.test.js`
- [x] T006 Implement `shared/money.js`, `shared/schemas.js`, `server/tastings.js`, `server/store.js`
- [x] T007 Implement `server/app.js` (`createApp({store, staffPassword})`, JSON parsing, static `dist/` + SPA fallback, JSON 404/500 handlers) and `server/index.js` (PORT, default 3000)
- [x] T008 [P] Client shell: `client/main.jsx`, `client/App.jsx` (routes, layout with header/footer, NotFound), `client/api.js`, `client/styles.css` design tokens and base components (buttons, cards, form fields, alerts, badges)

## Phase 3: User Story 1 - Guest books a tasting (P1) MVP

**Independent test**: list, open form, book, see confirmation, seats decrease.

- [x] T009 [P] [US1] Write failing API tests for `GET /api/tastings`, `GET /api/tastings/:id`, and `POST /api/tastings/:id/bookings` success in `tests/api/bookings.test.js`
- [x] T010 [P] [US1] Write failing component tests for Home (title, date/time, price, "<n> seats left", "Book <title>" links) and Book form success → "Booking confirmed" in `tests/client/guest.test.jsx`
- [x] T011 [US1] Implement tasting and booking-create routes in `server/app.js` (or `server/routes/guest.js`)
- [x] T012 [P] [US1] Implement `client/pages/Home.jsx` and `client/components/TastingCard.jsx`
- [x] T013 [US1] Implement `client/pages/Book.jsx` (react-hook-form + zod resolver, labelled fields, confirmation view)
- [x] T014 [US1] Write Playwright journey `tests/e2e/guest.spec.js` (book Riesling Evening for 2 → confirmation EUR 50, seats 10) and make it pass

## Phase 4: User Story 2 - Validation and capacity (P1)

**Independent test**: invalid inputs and overflow give field errors; parallel requests never overbook.

- [x] T015 [P] [US2] Write failing API tests: 400 per-field errors (blank name, bad email, guests 0/9/2.5/"abc"/missing), 409 when over seats left with `seatsLeft`, 409 when sold out, 404 unknown tasting, and a parallel-requests test (e.g. 20 simultaneous bookings of 1 seat on 8 seats → exactly 8 succeed) in `tests/api/capacity.test.js`
- [x] T016 [P] [US2] Write failing component tests: errors next to Name/Email/Guests (`aria-describedby`, `role="alert"`), server 409 mapped to Guests, values retained, fully-booked card without "Book" link, fully-booked form page and unknown tasting id → not-found page in `tests/client/validation.test.jsx`
- [x] T017 [US2] Implement validation and capacity responses in the booking route; map unknown fields safely
- [x] T018 [US2] Implement client error mapping, "Fully booked" state in `TastingCard` and `Book.jsx`, and a sold-out refresh when a 409 arrives
- [x] T019 [US2] Add Playwright `tests/e2e/validation.spec.js` (invalid fields, overflow, fully booked after booking all seats)

## Phase 5: User Story 3 - Staff sign in and list (P2)

**Independent test**: wrong/right password; list grouped by tasting; protected API.

- [x] T020 [P] [US3] Write failing API tests: login 204/401, unset or empty `STAFF_PASSWORD` always 401, `GET /api/staff/bookings` 401 without cookie / tampered cookie, grouped result, session endpoint, logout, cookie flags httpOnly and SameSite, login rate limit 429 (failed attempts only), in `tests/api/staff.test.js`
- [x] T021 [P] [US3] Write failing component tests for Staff page (sign-in form, error next to Password, grouped list, empty tasting message, sign out) in `tests/client/staff.test.jsx`
- [x] T022 [US3] Implement `server/staffAuth.js` (timing-safe digest compare, cookie-session, rate limiter) and staff routes
- [x] T023 [US3] Implement `client/pages/Staff.jsx` (sign in, grouped bookings, sign out)

## Phase 6: User Story 4 - Staff cancel (P2)

**Independent test**: cancel restores seats; double cancel handled.

- [x] T024 [P] [US4] Write failing tests: API `DELETE /api/staff/bookings/:reference` (204, 401, 404 on repeat, seats restored, sold-out tasting becomes bookable) in `tests/api/staff.test.js`; component test for "Cancel" button and repeat-cancel message in `tests/client/staff.test.jsx`
- [x] T025 [US4] Implement the delete route and the "Cancel" button with inline error/refresh handling
- [x] T026 [US4] Add Playwright `tests/e2e/staff.spec.js` (wrong password; sign in; see booking; cancel; seats restored on `/`; sign out)

## Phase 7: Polish and verification

- [x] T027 [P] Visual and responsive pass at 360 px and desktop (screenshots), contrast and focus styles, `prefers-reduced-motion`, page `<title>`s and `lang="en"`; Playwright 360 px no-horizontal-scroll test in `tests/e2e/mobile.spec.js`
- [x] T028 [P] Write `README.md` (install/build/start, env vars, tests, in-memory note)
- [x] T029 Run full flow from a clean state: `npm ci`, `npm run build`, `npm test`, `npm run test:e2e`, then manual run of `npm start` against quickstart.md
- [x] T030 Run `/speckit-analyze`, then `/code-review` and `/security-review`; fix findings

## Dependencies

Setup → Foundational → US1 → US2 (same files as US1) → US3 → US4 → Polish. US3/US4 server work is independent of US1/US2 once Foundational is done, but the client shares `App.jsx` and `styles.css`, so they are done in sequence.

## Implementation strategy

MVP = Phases 1-3. Each story ends green on its API, component and e2e tests before the next starts.
