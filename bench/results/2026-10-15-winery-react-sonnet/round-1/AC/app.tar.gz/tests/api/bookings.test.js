import { describe, it, expect } from 'vitest';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { setup, validBooking } from './helpers.js';

describe('GET /api/tastings', () => {
  it('lists the tastings with seats left', async () => {
    const { http } = setup();
    const res = await http.get('/api/tastings').expect(200);
    expect(res.body.map((t) => [t.title, t.startsAt, t.pricePerGuestCents, t.seatsLeft])).toEqual([
      ['Riesling Evening', '2026-11-06T18:00', 2500, 12],
      ['Red Wine Cellar Tour', '2026-11-14T15:00', 3200, 8],
      ['Winter Tasting', '2026-12-05T17:00', 2800, 10],
    ]);
  });
  it('returns one tasting, or 404', async () => {
    const { http } = setup();
    const res = await http.get('/api/tastings/winter-tasting').expect(200);
    expect(res.body).toMatchObject({ id: 'winter-tasting', seatsLeft: 10 });
    await http.get('/api/tastings/nope').expect(404);
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('books and returns the confirmation data', async () => {
    const { http } = setup();
    const res = await http.post('/api/tastings/riesling-evening/bookings').send(validBooking()).expect(201);
    expect(res.body).toMatchObject({
      tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00' },
      name: 'Anna Weber',
      email: 'anna@example.com',
      guests: 2,
      totalCents: 5000,
    });
    expect(res.body.reference).toMatch(/^KB-/);
    const after = await http.get('/api/tastings/riesling-evening');
    expect(after.body.seatsLeft).toBe(10);
  });
  it('accepts guests sent as a numeric string', async () => {
    const { http } = setup();
    const res = await http.post('/api/tastings/winter-tasting/bookings').send(validBooking({ guests: '3' })).expect(201);
    expect(res.body.totalCents).toBe(8400);
  });
  it('gives different references to different bookings', async () => {
    const { http } = setup();
    const a = await http.post('/api/tastings/riesling-evening/bookings').send(validBooking());
    const b = await http.post('/api/tastings/riesling-evening/bookings').send(validBooking());
    expect(a.body.reference).not.toBe(b.body.reference);
  });
  it('returns 404 for an unknown tasting', async () => {
    const { http } = setup();
    await http.post('/api/tastings/nope/bookings').send(validBooking()).expect(404);
  });
  it('rejects a malformed JSON body with 400, not a crash', async () => {
    const { http } = setup();
    await http.post('/api/tastings/riesling-evening/bookings').set('Content-Type', 'application/json').send('{oops').expect(400);
  });
});

describe('security headers', () => {
  it('sets a CSP that does not force https, and hides the framework', async () => {
    const { http } = setup();
    const res = await http.get('/api/tastings');
    expect(res.headers['content-security-policy']).toContain("default-src 'self'");
    expect(res.headers['content-security-policy']).not.toContain('upgrade-insecure-requests');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['strict-transport-security']).toBeUndefined();
  });
});

describe('serving the built client', () => {
  const distDir = mkdtempSync(path.join(tmpdir(), 'dist-'));
  writeFileSync(path.join(distDir, 'index.html'), '<!doctype html><title>app</title>');

  it('falls back to index.html for client routes', async () => {
    const { http } = setup({ distDir });
    const res = await http.get('/book/riesling-evening').expect(200);
    expect(res.text).toContain('<title>app</title>');
  });
  it('answers 404 for missing files instead of returning the page', async () => {
    const { http } = setup({ distDir });
    await http.get('/assets/old-hash.js').expect(404);
  });
  it('explains that the client was not built when dist/ is missing', async () => {
    const { http } = setup({ distDir: path.join(distDir, 'missing') });
    const res = await http.get('/').expect(503);
    expect(res.text).toMatch(/npm run build/);
    await http.get('/api/tastings').expect(200);
  });
});

describe('error handling', () => {
  it('passes client errors through with their status', async () => {
    const { http } = setup();
    const res = await http
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .set('Content-Encoding', 'nope')
      .send('x');
    expect(res.status).toBe(415);
    expect(res.body).toHaveProperty('error');
  });
});
