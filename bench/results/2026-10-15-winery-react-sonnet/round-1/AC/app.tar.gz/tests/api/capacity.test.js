import { describe, it, expect, afterEach } from 'vitest';
import request from 'supertest';
import { setup, validBooking } from './helpers.js';

const book = (http, id, body) => http.post(`/api/tastings/${id}/bookings`).send(body);

describe('validation', () => {
  it.each([
    [{ name: '' }, 'name'],
    [{ name: '   ' }, 'name'],
    [{ name: 'x'.repeat(101) }, 'name'],
    [{ email: '' }, 'email'],
    [{ email: 'not-an-email' }, 'email'],
    [{ guests: 0 }, 'guests'],
    [{ guests: 9 }, 'guests'],
    [{ guests: 2.5 }, 'guests'],
    [{ guests: 'abc' }, 'guests'],
    [{ guests: '' }, 'guests'],
    [{ guests: -1 }, 'guests'],
  ])('rejects %j with an error for %s and books nothing', async (patch, field) => {
    const { http } = setup();
    const res = await book(http, 'riesling-evening', validBooking(patch)).expect(400);
    expect(Object.keys(res.body.errors)).toEqual([field]);
    expect(typeof res.body.errors[field]).toBe('string');
    expect((await http.get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(12);
  });
  it('reports every invalid field at once', async () => {
    const { http } = setup();
    const res = await book(http, 'riesling-evening', {}).expect(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });
  it('ignores unknown fields instead of storing them', async () => {
    const { http } = setup();
    const res = await book(http, 'riesling-evening', validBooking({ totalCents: 1, tastingId: 'winter-tasting' })).expect(201);
    expect(res.body.totalCents).toBe(5000);
    expect(res.body.tasting.id).toBe('riesling-evening');
  });
});

const servers = [];
const listening = (app) => {
  const server = app.listen(0);
  servers.push(server);
  return request(server);
};
afterEach(() => servers.splice(0).forEach((s) => s.close()));

describe('capacity', () => {
  it('refuses more guests than seats left with a Guests error and the seat count', async () => {
    const { http } = setup();
    await book(http, 'red-wine-cellar-tour', validBooking({ guests: 5 })).expect(201);
    const res = await book(http, 'red-wine-cellar-tour', validBooking({ guests: 4 })).expect(409);
    expect(res.body.seatsLeft).toBe(3);
    expect(res.body.errors.guests).toMatch(/3 seats/);
    expect((await http.get('/api/tastings/red-wine-cellar-tour')).body.seatsLeft).toBe(3);
  });
  it('says so when the tasting is fully booked', async () => {
    const { http } = setup();
    await book(http, 'red-wine-cellar-tour', validBooking({ guests: 8 })).expect(201);
    const res = await book(http, 'red-wine-cellar-tour', validBooking({ guests: 1 })).expect(409);
    expect(res.body.seatsLeft).toBe(0);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });
  it('uses singular wording for one seat left', async () => {
    const { http } = setup();
    await book(http, 'red-wine-cellar-tour', validBooking({ guests: 7 })).expect(201);
    const res = await book(http, 'red-wine-cellar-tour', validBooking({ guests: 2 })).expect(409);
    expect(res.body.errors.guests).toMatch(/only 1 seat left/i);
  });
  it('never overbooks under simultaneous requests', async () => {
    const http = listening(setup().app);
    const results = await Promise.all(
      Array.from({ length: 30 }, () => book(http, 'red-wine-cellar-tour', validBooking({ guests: 1 }))),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(8);
    expect(results.filter((r) => r.status === 409)).toHaveLength(22);
    expect((await http.get('/api/tastings/red-wine-cellar-tour')).body.seatsLeft).toBe(0);
  });
  it('lets exactly one of two simultaneous bookings for the last seats win', async () => {
    const http = listening(setup().app);
    await book(http, 'red-wine-cellar-tour', validBooking({ guests: 6 })).expect(201);
    const [a, b] = await Promise.all([
      book(http, 'red-wine-cellar-tour', validBooking({ guests: 2 })),
      book(http, 'red-wine-cellar-tour', validBooking({ guests: 2 })),
    ]);
    expect([a.status, b.status].sort()).toEqual([201, 409]);
  });
});
