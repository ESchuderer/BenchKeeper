import request from 'supertest';
import { createApp } from '../../server/app.js';
import { createStore } from '../../server/store.js';

export function setup(options = {}) {
  const store = createStore();
  const app = createApp({ store, staffPassword: 'correct horse', ...options });
  return { app, store, http: request(app) };
}

export const validBooking = (extra = {}) => ({ name: 'Anna Weber', email: 'anna@example.com', guests: 2, ...extra });

export async function staffAgent(app, password = 'correct horse') {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password }).expect(204);
  return agent;
}
