import { describe, it, expect } from 'vitest';
import { formatMoney } from '../../shared/money.js';
import { bookingSchema, loginSchema, MAX_GUESTS } from '../../shared/schemas.js';

describe('formatMoney', () => {
  it('shows whole euros without decimals', () => {
    expect(formatMoney(2500)).toBe('EUR 25');
    expect(formatMoney(5000)).toBe('EUR 50');
  });
  it('shows cents when present', () => {
    expect(formatMoney(2550)).toBe('EUR 25.50');
    expect(formatMoney(5)).toBe('EUR 0.05');
  });
});

const ok = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };
const errorsOf = (input) => {
  const r = bookingSchema.safeParse(input);
  if (r.success) return null;
  return Object.fromEntries(r.error.issues.map((i) => [i.path[0], i.message]));
};

describe('bookingSchema', () => {
  it('accepts valid input and trims', () => {
    const r = bookingSchema.parse({ name: '  Anna  ', email: ' anna@example.com ', guests: '3' });
    expect(r).toEqual({ name: 'Anna', email: 'anna@example.com', guests: 3 });
  });
  it('exposes the guest limit', () => {
    expect(MAX_GUESTS).toBe(8);
  });
  it.each([['', 'name'], ['   ', 'name'], [undefined, 'name'], ['x'.repeat(101), 'name']])(
    'rejects name %j',
    (name, field) => {
      expect(errorsOf({ ...ok, name })).toHaveProperty(field);
    },
  );
  it.each(['', 'nope', 'a@b', 'a b@c.de', '@x.de', undefined, `${'a'.repeat(250)}@x.de`])(
    'rejects email %j',
    (email) => {
      expect(errorsOf({ ...ok, email })).toHaveProperty('email');
    },
  );
  it.each([0, 9, -1, 2.5, '2.5', 'abc', '', '1e1', null, undefined, NaN, true, []])(
    'rejects guests %j',
    (guests) => {
      expect(errorsOf({ ...ok, guests })).toHaveProperty('guests');
    },
  );
  it.each([1, 8, '1', '8'])('accepts guests %j', (guests) => {
    expect(errorsOf({ ...ok, guests })).toBeNull();
  });
  it('reports only one message per field', () => {
    const r = bookingSchema.safeParse({ name: '', email: '', guests: '' });
    const fields = r.error.issues.map((i) => i.path[0]);
    expect(new Set(fields).size).toBe(3);
  });
});

describe('loginSchema', () => {
  it('requires a password', () => {
    expect(loginSchema.safeParse({ password: '' }).success).toBe(false);
    expect(loginSchema.safeParse({}).success).toBe(false);
    expect(loginSchema.safeParse({ password: 'x' }).success).toBe(true);
  });
});

import { formatStart } from '../../shared/dates.js';

describe('formatStart', () => {
  it('shows weekday, date and time without timezone shifts', () => {
    expect(formatStart('2026-11-06T18:00')).toBe('Fri, 2026-11-06 18:00');
    expect(formatStart('2026-11-14T15:00')).toBe('Sat, 2026-11-14 15:00');
    expect(formatStart('2026-12-05T17:00')).toBe('Sat, 2026-12-05 17:00');
  });
});
