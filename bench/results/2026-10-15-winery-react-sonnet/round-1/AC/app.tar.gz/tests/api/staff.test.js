import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { setup, staffAgent, validBooking } from './helpers.js';

describe('staff sign in', () => {
  it('accepts the right password and sets an httpOnly SameSite cookie', async () => {
    const { http } = setup();
    const res = await http.post('/api/staff/login').send({ password: 'correct horse' }).expect(204);
    const cookie = res.headers['set-cookie'].join(';');
    expect(cookie).toMatch(/httponly/i);
    expect(cookie).toMatch(/samesite=strict/i);
  });
  it('rejects a wrong password with a Password error and no cookie', async () => {
    const { http } = setup();
    const res = await http.post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    expect(res.body.errors.password).toBeTruthy();
    expect(res.headers['set-cookie']).toBeUndefined();
  });
  it('rejects a missing password with a Password error', async () => {
    const { http } = setup();
    const res = await http.post('/api/staff/login').send({}).expect(400);
    expect(res.body.errors.password).toBeTruthy();
  });
  it('does not accept prefixes or longer strings of the password', async () => {
    const { http } = setup();
    await http.post('/api/staff/login').send({ password: 'correct hors' }).expect(401);
    await http.post('/api/staff/login').send({ password: 'correct horse!' }).expect(401);
  });
  it.each([undefined, ''])('always refuses sign-in when STAFF_PASSWORD is %j', async (staffPassword) => {
    const { http } = setup({ staffPassword });
    await http.post('/api/staff/login').send({ password: '' }).expect(400);
    await http.post('/api/staff/login').send({ password: 'anything' }).expect(401);
    await http.post('/api/staff/login').send({ password: 'undefined' }).expect(401);
  });
  it('limits repeated failed attempts, but not successful ones', async () => {
    const { http } = setup({ loginLimit: 3 });
    for (let i = 0; i < 3; i++) await http.post('/api/staff/login').send({ password: 'bad' }).expect(401);
    await http.post('/api/staff/login').send({ password: 'bad' }).expect(429);
    const ok = setup({ loginLimit: 3 });
    for (let i = 0; i < 6; i++) await ok.http.post('/api/staff/login').send({ password: 'correct horse' }).expect(204);
  });
});

describe('staff session', () => {
  it('reports signed in / out and signs out', async () => {
    const { app, http } = setup();
    expect((await http.get('/api/staff/session')).body).toEqual({ signedIn: false });
    const agent = await staffAgent(app);
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: true });
    await agent.post('/api/staff/logout').expect(204);
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: false });
    await agent.get('/api/staff/bookings').expect(401);
  });
  it('refuses booking data and cancelling without a session', async () => {
    const { http } = setup();
    await http.get('/api/staff/bookings').expect(401);
    await http.delete('/api/staff/bookings/KB-AAAAAA').expect(401);
  });
  it('treats a forged cookie as signed out', async () => {
    const { http } = setup();
    const forged = Buffer.from(JSON.stringify({ staff: true })).toString('base64');
    await http.get('/api/staff/bookings').set('Cookie', [`session=${forged}`, 'session.sig=abc']).expect(401);
  });
  it('invalidates a copied cookie once the staff member signs out', async () => {
    const { app } = setup();
    const agent = await staffAgent(app);
    const header = agent.jar.getCookies({ path: '/', domain: '127.0.0.1', secure: false, script: false }).map((c) => `${c.name}=${c.value}`);
    await request(app).get('/api/staff/bookings').set('Cookie', header).expect(200);
    await agent.post('/api/staff/logout').expect(204);
    await request(app).get('/api/staff/bookings').set('Cookie', header).expect(401);
  });
  it('does not share a session between apps with different secrets', async () => {
    const a = setup();
    const agent = await staffAgent(a.app);
    const cookies = agent.jar.getCookies({ path: '/', domain: '127.0.0.1', secure: false, script: false });
    const header = cookies.map((c) => `${c.name}=${c.value}`);
    const b = setup();
    await request(b.app).get('/api/staff/bookings').set('Cookie', header).expect(401);
  });
});

describe('staff bookings', () => {
  it('lists all tastings with their bookings, grouped', async () => {
    const { app, http } = setup();
    await http.post('/api/tastings/riesling-evening/bookings').send(validBooking({ name: 'Ann' })).expect(201);
    await http.post('/api/tastings/winter-tasting/bookings').send(validBooking({ name: 'Bob', guests: 3 })).expect(201);
    const agent = await staffAgent(app);
    const res = await agent.get('/api/staff/bookings').expect(200);
    expect(res.body.map((g) => g.tasting.title)).toEqual(['Riesling Evening', 'Red Wine Cellar Tour', 'Winter Tasting']);
    expect(res.body[0].bookings).toHaveLength(1);
    expect(res.body[0].bookings[0]).toMatchObject({ name: 'Ann', email: 'anna@example.com', guests: 2 });
    expect(res.body[0].bookings[0].reference).toMatch(/^KB-/);
    expect(res.body[1].bookings).toEqual([]);
    expect(res.body[2].bookings[0]).toMatchObject({ name: 'Bob', guests: 3 });
  });
});

describe('cancel', () => {
  it('removes the booking and frees its seats', async () => {
    const { app, http } = setup();
    const { body } = await http.post('/api/tastings/riesling-evening/bookings').send(validBooking({ guests: 3 }));
    expect((await http.get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(9);
    const agent = await staffAgent(app);
    await agent.delete(`/api/staff/bookings/${body.reference}`).expect(204);
    expect((await http.get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(12);
    expect((await agent.get('/api/staff/bookings')).body[0].bookings).toEqual([]);
  });
  it('returns 404 when cancelled again, without freeing seats twice', async () => {
    const { app, http } = setup();
    const { body } = await http.post('/api/tastings/riesling-evening/bookings').send(validBooking({ guests: 3 }));
    const agent = await staffAgent(app);
    await agent.delete(`/api/staff/bookings/${body.reference}`).expect(204);
    await agent.delete(`/api/staff/bookings/${body.reference}`).expect(404);
    expect((await http.get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(12);
  });
  it('makes a fully booked tasting bookable again', async () => {
    const { app, http } = setup();
    const { body } = await http.post('/api/tastings/red-wine-cellar-tour/bookings').send(validBooking({ guests: 8 }));
    await http.post('/api/tastings/red-wine-cellar-tour/bookings').send(validBooking({ guests: 1 })).expect(409);
    await (await staffAgent(app)).delete(`/api/staff/bookings/${body.reference}`).expect(204);
    await http.post('/api/tastings/red-wine-cellar-tour/bookings').send(validBooking({ guests: 8 })).expect(201);
  });
});

describe('misc', () => {
  it('returns JSON 404 for unknown API paths', async () => {
    const { http } = setup();
    const res = await http.get('/api/nothing').expect(404);
    expect(res.body).toHaveProperty('error');
  });
});
