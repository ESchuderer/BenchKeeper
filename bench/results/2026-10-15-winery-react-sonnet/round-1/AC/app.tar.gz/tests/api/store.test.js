import { describe, it, expect, beforeEach } from 'vitest';
import { createStore } from '../../server/store.js';

const guest = (guests, extra = {}) => ({ name: 'Anna', email: 'anna@example.com', guests, ...extra });
let store;
beforeEach(() => {
  store = createStore();
});

describe('seed data', () => {
  it('has the three tastings, with all seats free and no bookings', () => {
    expect(store.listTastings().map((t) => [t.id, t.title, t.startsAt, t.pricePerGuestCents, t.seats, t.seatsLeft])).toEqual([
      ['riesling-evening', 'Riesling Evening', '2026-11-06T18:00', 2500, 12, 12],
      ['red-wine-cellar-tour', 'Red Wine Cellar Tour', '2026-11-14T15:00', 3200, 8, 8],
      ['winter-tasting', 'Winter Tasting', '2026-12-05T17:00', 2800, 10, 10],
    ]);
    expect(store.listBookingsByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });
  it('returns null for an unknown tasting', () => {
    expect(store.getTasting('nope')).toBeNull();
  });
});

describe('reserve', () => {
  it('books, prices and reduces seats left', () => {
    const r = store.reserve('riesling-evening', guest(2));
    expect(r.ok).toBe(true);
    expect(r.booking).toMatchObject({ tastingId: 'riesling-evening', name: 'Anna', guests: 2, totalCents: 5000 });
    expect(r.booking.reference).toMatch(/^KB-[A-Z2-9]{6}$/);
    expect(store.getTasting('riesling-evening').seatsLeft).toBe(10);
  });
  it('allows exactly the seats left', () => {
    expect(store.reserve('red-wine-cellar-tour', guest(8)).ok).toBe(true);
    expect(store.getTasting('red-wine-cellar-tour').seatsLeft).toBe(0);
  });
  it('refuses more than seats left, reporting how many are left', () => {
    store.reserve('red-wine-cellar-tour', guest(5));
    const r = store.reserve('red-wine-cellar-tour', guest(4));
    expect(r).toEqual({ ok: false, reason: 'NOT_ENOUGH_SEATS', seatsLeft: 3 });
    expect(store.getTasting('red-wine-cellar-tour').seatsLeft).toBe(3);
  });
  it('refuses when sold out', () => {
    store.reserve('red-wine-cellar-tour', guest(8));
    expect(store.reserve('red-wine-cellar-tour', guest(1))).toEqual({ ok: false, reason: 'NOT_ENOUGH_SEATS', seatsLeft: 0 });
  });
  it('refuses an unknown tasting', () => {
    expect(store.reserve('nope', guest(1))).toEqual({ ok: false, reason: 'UNKNOWN_TASTING' });
  });
  it('creates unique references', () => {
    const refs = new Set();
    for (let i = 0; i < 12; i++) refs.add(store.reserve('riesling-evening', guest(1)).booking.reference);
    expect(refs.size).toBe(12);
  });
});

describe('cancel', () => {
  it('removes the booking and frees its seats', () => {
    const { booking } = store.reserve('winter-tasting', guest(4));
    expect(store.cancel(booking.reference)).toEqual({ ok: true });
    expect(store.getTasting('winter-tasting').seatsLeft).toBe(10);
    expect(store.listBookingsByTasting().find((g) => g.tasting.id === 'winter-tasting').bookings).toEqual([]);
  });
  it('does not free seats twice', () => {
    const { booking } = store.reserve('winter-tasting', guest(4));
    store.cancel(booking.reference);
    expect(store.cancel(booking.reference)).toEqual({ ok: false, reason: 'UNKNOWN_BOOKING' });
    expect(store.getTasting('winter-tasting').seatsLeft).toBe(10);
  });
  it('makes a sold-out tasting bookable again', () => {
    const { booking } = store.reserve('red-wine-cellar-tour', guest(8));
    store.cancel(booking.reference);
    expect(store.reserve('red-wine-cellar-tour', guest(8)).ok).toBe(true);
  });
});

describe('references', () => {
  it('are never issued again after a booking was cancelled', () => {
    const picks = [...Array(6).fill(0), ...Array(6).fill(0), ...Array(6).fill(1)];
    const seeded = createStore(undefined, { random: () => picks.shift() });
    const first = seeded.reserve('riesling-evening', guest(1)).booking;
    expect(first.reference).toBe('KB-AAAAAA');
    seeded.cancel(first.reference);
    expect(seeded.reserve('riesling-evening', guest(1)).booking.reference).toBe('KB-BBBBBB');
  });
});

describe('listBookingsByTasting', () => {
  it('groups bookings by tasting in date order', () => {
    store.reserve('winter-tasting', guest(1, { name: 'Zed' }));
    store.reserve('riesling-evening', guest(2, { name: 'Ann' }));
    const groups = store.listBookingsByTasting();
    expect(groups.map((g) => g.tasting.id)).toEqual(['riesling-evening', 'red-wine-cellar-tour', 'winter-tasting']);
    expect(groups[0].bookings[0]).toMatchObject({ name: 'Ann', email: 'anna@example.com', guests: 2 });
    expect(groups[2].bookings[0].name).toBe('Zed');
  });
});
