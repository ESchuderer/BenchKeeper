import { vi } from 'vitest';
import { createApp } from '../../server/app.js';
import { createStore } from '../../server/store.js';

/** Runs the real Express app on a random port and routes the browser's fetch() to it, with cookies. */
export async function startBackend(options = {}) {
  const store = createStore();
  const app = createApp({ store, staffPassword: 'cellar-door', distDir: '/nonexistent', ...options });
  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const base = `http://127.0.0.1:${server.address().port}`;
  const realFetch = globalThis.fetch;
  const jar = new Map();
  const calls = [];

  vi.stubGlobal('fetch', async (url, init = {}) => {
    calls.push({ url, method: init.method ?? 'GET' });
    const headers = new Headers(init.headers);
    if (jar.size) headers.set('cookie', [...jar].map(([k, v]) => `${k}=${v}`).join('; '));
    const res = await realFetch(base + url, { ...init, headers });
    for (const line of res.headers.getSetCookie()) {
      const [pair] = line.split(';');
      const i = pair.indexOf('=');
      const [name, value] = [pair.slice(0, i), pair.slice(i + 1)];
      if (value === '') jar.delete(name);
      else jar.set(name, value);
    }
    return res;
  });

  return {
    store,
    calls,
    async close() {
      vi.unstubAllGlobals();
      await new Promise((resolve) => server.close(resolve));
    },
  };
}
