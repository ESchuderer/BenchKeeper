import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { screen, within } from '@testing-library/react';
import { startBackend } from './backend.js';
import { renderApp } from './render.jsx';

let backend;
beforeEach(async () => {
  backend = await startBackend();
});
afterEach(() => backend.close());

describe('start page', () => {
  it('lists the tastings with date and time, price and seats left', async () => {
    renderApp('/');
    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(riesling).getByText(/2026-11-06 18:00/)).toBeInTheDocument();
    expect(within(riesling).getByText(/EUR 25/)).toBeInTheDocument();
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument();

    const cellar = screen.getByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(cellar).getByText(/2026-11-14 15:00/)).toBeInTheDocument();
    expect(within(cellar).getByText(/EUR 32/)).toBeInTheDocument();
    expect(within(cellar).getByText('8 seats left')).toBeInTheDocument();

    const winter = screen.getByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText(/2026-12-05 17:00/)).toBeInTheDocument();
    expect(within(winter).getByText(/EUR 28/)).toBeInTheDocument();
    expect(within(winter).getByText('10 seats left')).toBeInTheDocument();
  });

  it('has a "Book <title>" link for each tasting', async () => {
    renderApp('/');
    for (const title of ['Riesling Evening', 'Red Wine Cellar Tour', 'Winter Tasting']) {
      const link = await screen.findByRole('link', { name: `Book ${title}` });
      expect(link).toHaveAttribute('href', expect.stringMatching(/^\/book\//));
    }
  });

  it('shows a clear message with a retry when the tastings cannot be loaded', async () => {
    vi.stubGlobal('fetch', async () => {
      throw new TypeError('network down');
    });
    renderApp('/');
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument();
  });
});

describe('booking a tasting', () => {
  it('opens the form for the chosen tasting from the start page', async () => {
    const { user } = renderApp('/');
    await user.click(await screen.findByRole('link', { name: 'Book Riesling Evening' }));
    expect(await screen.findByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('confirms with tasting, guests, total and reference, and the seats drop', async () => {
    const { user } = renderApp('/book/riesling-evening');
    await user.type(await screen.findByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.clear(screen.getByLabelText('Guests'));
    await user.type(screen.getByLabelText('Guests'), '2');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const confirmation = screen.getByRole('main');
    expect(within(confirmation).getByText(/Riesling Evening/)).toBeInTheDocument();
    expect(within(confirmation).getByText(/2026-11-06 18:00/)).toBeInTheDocument();
    expect(within(confirmation).getByText('2')).toBeInTheDocument();
    expect(within(confirmation).getByText('EUR 50')).toBeInTheDocument();
    expect(within(confirmation).getByText(/^KB-[A-Z2-9]{6}$/)).toBeInTheDocument();
    expect(backend.store.getTasting('riesling-evening').seatsLeft).toBe(10);
  });

  it('does not carry a confirmation over to another tasting', async () => {
    const { user, rerender } = renderApp('/book/riesling-evening');
    await user.type(await screen.findByLabelText('Name'), 'Anna');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await screen.findByRole('heading', { name: 'Booking confirmed' });
    await user.click(screen.getByRole('link', { name: 'Back to all tastings' }));
    await user.click(await screen.findByRole('link', { name: 'Book Winter Tasting' }));
    expect(await screen.findByLabelText('Name')).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
    void rerender;
  });

  it('shows the not-found page for an unknown tasting', async () => {
    renderApp('/book/does-not-exist');
    expect(await screen.findByRole('heading', { name: /not found/i })).toBeInTheDocument();
  });

  it('shows the not-found page for an unknown address', async () => {
    renderApp('/nowhere');
    expect(await screen.findByRole('heading', { name: /not found/i })).toBeInTheDocument();
  });
});
