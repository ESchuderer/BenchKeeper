import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { screen, within, waitFor } from '@testing-library/react';
import { startBackend } from './backend.js';
import { renderApp } from './render.jsx';

let backend;
beforeEach(async () => {
  backend = await startBackend();
});
afterEach(() => backend.close());

const reserve = (id, name, guests, email = `${name.toLowerCase()}@example.com`) =>
  backend.store.reserve(id, { name, email, guests }).booking;

const signIn = async (user, password = 'cellar-door') => {
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
};

describe('sign in', () => {
  it('asks for a password and shows no bookings', async () => {
    reserve('riesling-evening', 'Anna', 2);
    renderApp('/staff');
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('Anna')).not.toBeInTheDocument();
  });

  it('shows an error next to the password for a wrong one', async () => {
    reserve('riesling-evening', 'Anna', 2);
    const { user } = renderApp('/staff');
    await signIn(user, 'wrong');
    const field = await screen.findByLabelText('Password');
    await waitFor(() => expect(field).toHaveAttribute('aria-invalid', 'true'));
    expect(field).toHaveAccessibleDescription(/not correct/i);
    expect(screen.queryByText('Anna')).not.toBeInTheDocument();
  });

  it('asks for the password when it is left empty', async () => {
    const { user } = renderApp('/staff');
    await user.click(await screen.findByRole('button', { name: 'Sign in' }));
    expect(screen.getByLabelText('Password')).toHaveAccessibleDescription(/enter the password/i);
  });
});

describe('bookings list', () => {
  it('groups bookings by tasting with name, email, guests and reference', async () => {
    const a = reserve('riesling-evening', 'Anna', 2);
    const b = reserve('winter-tasting', 'Bruno', 3);
    const { user } = renderApp('/staff');
    await signIn(user);

    const riesling = await screen.findByRole('region', { name: /Riesling Evening/ });
    expect(within(riesling).getByText('Anna')).toBeInTheDocument();
    expect(within(riesling).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(riesling).getByText('2')).toBeInTheDocument();
    expect(within(riesling).getByText(a.reference)).toBeInTheDocument();

    const winter = screen.getByRole('region', { name: /Winter Tasting/ });
    expect(within(winter).getByText('Bruno')).toBeInTheDocument();
    expect(within(winter).getByText(b.reference)).toBeInTheDocument();
    expect(within(winter).queryByText('Anna')).not.toBeInTheDocument();

    expect(within(screen.getByRole('region', { name: /Red Wine Cellar Tour/ })).getByText(/no bookings yet/i)).toBeInTheDocument();
  });

  it('stays signed in on reload of the page, and can sign out', async () => {
    reserve('riesling-evening', 'Anna', 2);
    const first = renderApp('/staff');
    await signIn(first.user);
    await screen.findByText('Anna');
    first.unmount();

    const { user } = renderApp('/staff');
    expect(await screen.findByText('Anna')).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.queryByText('Anna')).not.toBeInTheDocument();
  });
});

describe('cancel', () => {
  it('removes the booking from the list and frees its seats', async () => {
    reserve('riesling-evening', 'Anna', 3);
    reserve('riesling-evening', 'Bruno', 1);
    const { user } = renderApp('/staff');
    await signIn(user);
    const row = (await screen.findByText('Anna')).closest('tr');
    await user.click(within(row).getByRole('button', { name: 'Cancel' }));
    await waitFor(() => expect(screen.queryByText('Anna')).not.toBeInTheDocument());
    expect(screen.getByText('Bruno')).toBeInTheDocument();
    expect(backend.store.getTasting('riesling-evening').seatsLeft).toBe(11);
  });

  it('tells staff when the booking was already cancelled, and refreshes the list', async () => {
    const a = reserve('riesling-evening', 'Anna', 3);
    const { user } = renderApp('/staff');
    await signIn(user);
    const row = (await screen.findByText('Anna')).closest('tr');
    backend.store.cancel(a.reference);
    await user.click(within(row).getByRole('button', { name: 'Cancel' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/no longer exists/i);
    await waitFor(() => expect(screen.queryByText('Anna')).not.toBeInTheDocument());
  });
});
