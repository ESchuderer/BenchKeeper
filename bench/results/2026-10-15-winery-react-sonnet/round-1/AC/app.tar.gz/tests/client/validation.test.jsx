import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { screen } from '@testing-library/react';
import { startBackend } from './backend.js';
import { renderApp } from './render.jsx';

let backend;
beforeEach(async () => {
  backend = await startBackend();
});
afterEach(() => backend.close());

const fill = async (user, { name = 'Anna Weber', email = 'anna@example.com', guests = '2' } = {}) => {
  const nameInput = await screen.findByLabelText('Name');
  await user.clear(nameInput);
  if (name) await user.type(nameInput, name);
  await user.clear(screen.getByLabelText('Email'));
  if (email) await user.type(screen.getByLabelText('Email'), email);
  await user.clear(screen.getByLabelText('Guests'));
  if (guests) await user.type(screen.getByLabelText('Guests'), guests);
};

const expectFieldError = (label, pattern) => {
  const field = screen.getByLabelText(label);
  expect(field).toHaveAttribute('aria-invalid', 'true');
  expect(field).toHaveAccessibleDescription(pattern);
  expect(screen.getByText(pattern)).toHaveAttribute('role', 'alert');
};

describe('form validation', () => {
  it('shows an error next to each invalid field and books nothing', async () => {
    const { user } = renderApp('/book/riesling-evening');
    await fill(user, { name: '', email: 'nope', guests: '' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expectFieldError('Name', /enter your name/i);
    expectFieldError('Email', /valid email/i);
    expectFieldError('Guests', /whole number/i);
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
    expect(backend.store.getTasting('riesling-evening').seatsLeft).toBe(12);
  });

  it.each([['0', /at least 1/i], ['9', /up to 8/i], ['2.5', /whole number/i]])('rejects %s guests', async (guests, pattern) => {
    const { user } = renderApp('/book/riesling-evening');
    await fill(user, { guests });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expectFieldError('Guests', pattern);
  });

  it('keeps what was typed and succeeds after the error is fixed', async () => {
    const { user } = renderApp('/book/riesling-evening');
    await fill(user, { email: 'broken' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expectFieldError('Email', /valid email/i);
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Weber');
    await user.clear(screen.getByLabelText('Email'));
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    expect(screen.getByLabelText('Email')).not.toHaveAttribute('aria-invalid', 'true');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
  });
});

describe('capacity', () => {
  it('shows the server refusal next to Guests when others took the seats in the meantime', async () => {
    const { user } = renderApp('/book/red-wine-cellar-tour');
    await fill(user, { guests: '4' });
    backend.store.reserve('red-wine-cellar-tour', { name: 'Other', email: 'o@example.com', guests: 5 });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await screen.findByText(/only 3 seats left/i);
    expectFieldError('Guests', /only 3 seats left/i);
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Weber');
    expect(backend.store.getTasting('red-wine-cellar-tour').seatsLeft).toBe(3);
  });

  it('lets the server decide, so seats freed since the page loaded can be booked', async () => {
    const other = backend.store.reserve('red-wine-cellar-tour', { name: 'Other', email: 'o@example.com', guests: 6 }).booking;
    const { user } = renderApp('/book/red-wine-cellar-tour');
    await fill(user, { guests: '4' });
    backend.store.cancel(other.reference);
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
  });

  it('refuses more guests than the seats left and says how many are left', async () => {
    backend.store.reserve('red-wine-cellar-tour', { name: 'Other', email: 'o@example.com', guests: 5 });
    const { user } = renderApp('/book/red-wine-cellar-tour');
    await fill(user, { guests: '4' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await screen.findByText(/only 3 seats left/i);
    expectFieldError('Guests', /only 3 seats left/i);
  });

  it('turns into a fully-booked page when the last seats vanish meanwhile', async () => {
    const { user } = renderApp('/book/red-wine-cellar-tour');
    await fill(user, { guests: '1' });
    backend.store.reserve('red-wine-cellar-tour', { name: 'Other', email: 'o@example.com', guests: 8 });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
  });
});

describe('fully booked tastings', () => {
  beforeEach(() => {
    backend.store.reserve('red-wine-cellar-tour', { name: 'Other', email: 'o@example.com', guests: 8 });
  });

  it('are marked as such on the start page, with no way to book', async () => {
    renderApp('/');
    const card = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(card).toHaveTextContent('Fully booked');
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toBeInTheDocument();
  });

  it('show the fully-booked state instead of a form when opened directly', async () => {
    renderApp('/book/red-wine-cellar-tour');
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: /all tastings/i })).toBeInTheDocument();
  });
});
