import { test, expect } from '@playwright/test';

// This spec only books Riesling Evening.
test('a guest books a tasting and sees the confirmation', async ({ page }) => {
  await page.goto('/');
  const card = page.getByRole('article', { name: 'Riesling Evening' });
  await expect(card).toContainText('2026-11-06 18:00');
  await expect(card).toContainText('EUR 25');
  await expect(card).toContainText('12 seats left');
  await expect(page.getByRole('article', { name: 'Red Wine Cellar Tour' })).toContainText('8 seats left');
  await expect(page.getByRole('article', { name: 'Winter Tasting' })).toContainText('10 seats left');

  await page.getByRole('link', { name: 'Book Riesling Evening' }).click();
  await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
  await page.getByLabel('Name').fill('Anna Weber');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('2');
  await page.getByRole('button', { name: 'Book' }).click();

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const main = page.getByRole('main');
  await expect(main).toContainText('Riesling Evening');
  await expect(main).toContainText('EUR 50');
  await expect(main.locator('.reference')).toHaveText(/^KB-[A-Z2-9]{6}$/);

  await page.getByRole('link', { name: 'Back to all tastings' }).click();
  await expect(page.getByRole('article', { name: 'Riesling Evening' })).toContainText('10 seats left');
});

test('the book page can be opened directly and a reload keeps working', async ({ page }) => {
  await page.goto('/book/winter-tasting');
  await expect(page.getByRole('heading', { name: 'Winter Tasting' })).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Guests')).toBeVisible();
  await page.goto('/book/nope');
  await expect(page.getByRole('heading', { name: /not found/i })).toBeVisible();
});
