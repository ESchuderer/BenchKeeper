import { test, expect } from '@playwright/test';

test.use({ viewport: { width: 360, height: 740 }, hasTouch: true, isMobile: true });

for (const path of ['/', '/book/riesling-evening', '/staff', '/nothing-here']) {
  test(`${path} fits a 360px phone without sideways scrolling`, async ({ page }) => {
    await page.goto(path);
    await expect(page.getByRole('main')).toBeVisible();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBeLessThanOrEqual(0);
  });
}

test('the signed-in staff list also fits a phone', async ({ page }) => {
  await page.goto('/staff');
  await page.getByLabel('Password').fill('e2e-secret');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  expect(overflow).toBeLessThanOrEqual(0);
});
