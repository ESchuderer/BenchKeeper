import { test, expect } from '@playwright/test';

const PASSWORD = 'e2e-secret';

test('staff see bookings grouped by tasting and can cancel one, freeing the seats', async ({ page, request }) => {
  // Other specs may have used Winter Tasting seats; make our own booking and measure relatively.
  const before = await (await request.get('/api/tastings/winter-tasting')).json();
  test.skip(before.seatsLeft < 3, 'not enough seats left in this run');
  const made = await request.post('/api/tastings/winter-tasting/bookings', {
    data: { name: 'Carla Cancel', email: 'carla@example.com', guests: 3 },
  });
  const { reference } = await made.json();

  await page.goto('/staff');
  await expect(page.getByLabel('Password')).toBeVisible();
  await expect(page.getByText('Carla Cancel')).toHaveCount(0);

  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByLabel('Password')).toHaveAccessibleDescription(/not correct/i);
  await expect(page.getByText('Carla Cancel')).toHaveCount(0);

  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  const group = page.getByRole('region', { name: /Winter Tasting/ });
  const row = group.getByRole('row', { name: /Carla Cancel/ });
  await expect(row).toContainText('carla@example.com');
  await expect(row).toContainText(reference);
  await expect(page.getByRole('region', { name: /Riesling Evening/ })).toBeVisible();

  await page.reload();
  await expect(row).toBeVisible();

  await row.getByRole('button', { name: 'Cancel' }).click();
  await expect(page.getByText('Carla Cancel')).toHaveCount(0);

  await page.goto('/');
  const card = page.getByRole('article', { name: 'Winter Tasting' });
  await expect(card).toContainText(`${before.seatsLeft} seats left`);

  await page.goto('/staff');
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
  await page.goto('/staff');
  await expect(page.getByLabel('Password')).toBeVisible();
});

test('booking data is not available without signing in', async ({ request }) => {
  expect((await request.get('/api/staff/bookings')).status()).toBe(401);
});
