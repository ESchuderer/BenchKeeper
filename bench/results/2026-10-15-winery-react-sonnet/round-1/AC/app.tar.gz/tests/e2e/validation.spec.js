import { test, expect } from '@playwright/test';

// This spec only books the Red Wine Cellar Tour (8 seats) and ends with it fully booked.
const fill = async (page, { name = 'Bea Braun', email = 'bea@example.com', guests = '1' } = {}) => {
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Guests').fill(guests);
};

test('invalid input is rejected next to the field concerned', async ({ page }) => {
  await page.goto('/book/red-wine-cellar-tour');
  await fill(page, { name: '', email: 'bad', guests: '9' });
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription(/enter your name/i);
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription(/valid email/i);
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/up to 8/i);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);

  await fill(page, { guests: '0' });
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/at least 1/i);
});

test('never takes more seats than are left, and a fully booked tasting cannot be booked', async ({ page, request }) => {
  await page.goto('/book/red-wine-cellar-tour');
  // Someone else takes 6 of the 8 seats while this form is open.
  const other = await request.post('/api/tastings/red-wine-cellar-tour/bookings', {
    data: { name: 'Other', email: 'other@example.com', guests: 6 },
  });
  expect(other.status()).toBe(201);

  await fill(page, { guests: '3' });
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/only 2 seats left/i);
  await expect(page.getByLabel('Name')).toHaveValue('Bea Braun');

  await page.getByLabel('Guests').fill('2');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  const card = page.getByRole('article', { name: 'Red Wine Cellar Tour' });
  await expect(card).toContainText('Fully booked');
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0);
  await expect(page.getByRole('link', { name: 'Book Riesling Evening' })).toBeVisible();

  await page.goto('/book/red-wine-cellar-tour');
  await expect(page.getByText(/fully booked/i).first()).toBeVisible();
  await expect(page.getByLabel('Name')).toHaveCount(0);
});

test('parallel requests for the last seats never overbook', async ({ request }) => {
  const before = await (await request.get('/api/tastings/winter-tasting')).json();
  const results = await Promise.all(
    Array.from({ length: before.seatsLeft + 5 }, (_, i) =>
      request.post('/api/tastings/winter-tasting/bookings', { data: { name: `P${i}`, email: `p${i}@example.com`, guests: 1 } }),
    ),
  );
  const ok = results.filter((r) => r.status() === 201).length;
  const after = await (await request.get('/api/tastings/winter-tasting')).json();
  expect(ok).toBe(before.seatsLeft);
  expect(after.seatsLeft).toBe(0);
});
