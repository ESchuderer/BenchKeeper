import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { proxy: { '/api': 'http://localhost:3000' } },
  test: {
    projects: [
      { extends: true, test: { name: 'api', include: ['tests/api/**/*.test.js'], environment: 'node' } },
      {
        extends: true,
        test: {
          name: 'client',
          include: ['tests/client/**/*.test.{js,jsx}'],
          environment: 'jsdom',
          setupFiles: ['tests/client/setup.js'],
        },
      },
    ],
  },
});
