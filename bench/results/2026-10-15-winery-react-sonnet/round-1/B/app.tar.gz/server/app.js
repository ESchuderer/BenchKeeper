import express from 'express'
import crypto from 'node:crypto'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06 18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05 17:00', price: 28, seats: 10 },
]
const MAX_GUESTS = 8
const REF_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

const safeEqual = (a, b) => {
  const [x, y] = [a, b].map(s => crypto.createHash('sha256').update(String(s)).digest())
  return crypto.timingSafeEqual(x, y)
}

// shortcut: bookings live in memory and are lost on restart, switch to a file/DB if that matters
export function createApp({ staffPassword = process.env.STAFF_PASSWORD, distDir } = {}) {
  const bookings = []
  const sessions = new Set()
  const app = express()
  app.use(express.json())

  const seatsLeft = t => t.seats - bookings.filter(b => b.tastingId === t.id).reduce((n, b) => n + b.guests, 0)
  const view = t => ({ ...t, seatsLeft: seatsLeft(t) })
  const find = id => TASTINGS.find(t => t.id === id)

  app.get('/api/tastings', (req, res) => res.json(TASTINGS.map(view)))

  app.get('/api/tastings/:id', (req, res) => {
    const t = find(req.params.id)
    t ? res.json(view(t)) : res.status(404).json({ error: 'Tasting not found' })
  })

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const t = find(req.params.id)
    if (!t) return res.status(404).json({ error: 'Tasting not found' })

    const { name, email, guests } = req.body ?? {}
    const errors = {}
    const cleanName = typeof name === 'string' ? name.trim() : ''
    const cleanEmail = typeof email === 'string' ? email.trim() : ''
    if (!cleanName) errors.name = 'Please enter your name.'
    else if (cleanName.length > 100) errors.name = 'Please use 100 characters or fewer.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail) || cleanEmail.length > 200) errors.email = 'Please enter a valid email address.'
    const n = typeof guests === 'number' ? guests : /^\d+$/.test(String(guests).trim()) ? Number(guests) : NaN
    if (!Number.isInteger(n) || n < 1 || n > MAX_GUESTS) errors.guests = `Please choose between 1 and ${MAX_GUESTS} guests.`
    if (Object.keys(errors).length) return res.status(400).json({ errors })

    const left = seatsLeft(t)
    if (n > left) {
      const msg = left === 0 ? 'Sorry, this tasting is fully booked.' : `Only ${left} seats left for this tasting.`
      return res.status(409).json({ errors: { guests: msg } })
    }
    const ref = 'KB-' + Array.from(crypto.randomBytes(6), b => REF_CHARS[b % REF_CHARS.length]).join('')
    bookings.push({ ref, tastingId: t.id, name: cleanName, email: cleanEmail, guests: n })
    res.status(201).json({ ref, name: cleanName, email: cleanEmail, guests: n, total: n * t.price, tasting: t })
  })

  // staff
  const cookieToken = req => /(?:^|;\s*)staff=([\w-]+)/.exec(req.headers.cookie ?? '')?.[1]
  const requireStaff = (req, res, next) =>
    sessions.has(cookieToken(req)) ? next() : res.status(401).json({ error: 'Not signed in' })

  app.post('/api/staff/login', (req, res) => {
    const pw = req.body?.password
    if (!staffPassword || typeof pw !== 'string' || !safeEqual(pw, staffPassword))
      return res.status(401).json({ errors: { password: 'Wrong password.' } })
    const token = crypto.randomUUID()
    sessions.add(token)
    res.setHeader('Set-Cookie', `staff=${token}; HttpOnly; SameSite=Strict; Path=/`)
    res.status(204).end()
  })

  app.post('/api/staff/logout', (req, res) => {
    sessions.delete(cookieToken(req))
    res.setHeader('Set-Cookie', 'staff=; Max-Age=0; HttpOnly; SameSite=Strict; Path=/')
    res.status(204).end()
  })

  app.get('/api/staff/bookings', requireStaff, (req, res) =>
    res.json(TASTINGS.map(t => ({
      ...view(t),
      bookings: bookings.filter(b => b.tastingId === t.id).map(({ ref, name, email, guests }) => ({ ref, name, email, guests })),
    }))))

  app.delete('/api/staff/bookings/:ref', requireStaff, (req, res) => {
    const i = bookings.findIndex(b => b.ref === req.params.ref)
    if (i < 0) return res.status(404).json({ error: 'Booking not found' })
    bookings.splice(i, 1)
    res.status(204).end()
  })

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }))

  // built React app + client-side routing fallback
  const dist = distDir ?? path.join(path.dirname(fileURLToPath(import.meta.url)), '../dist')
  app.use(express.static(dist))
  app.use((req, res) => res.sendFile(path.join(dist, 'index.html')))

  app.use((err, req, res, next) => // eslint-disable-line no-unused-vars
    res.status(err.status ?? 500).json({ error: err.status < 500 ? 'Invalid request.' : 'Server error.' }))

  return app
}
