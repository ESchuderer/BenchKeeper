import { createApp } from './app.js'

const port = process.env.PORT || 3000
if (!process.env.STAFF_PASSWORD) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.')
createApp().listen(port, () => console.log(`Listening on http://localhost:${port}`))
