import { useEffect, useState } from 'react'
import { Link, Route, Routes, useParams } from 'react-router-dom'

async function api(path, options = {}) {
  const res = await fetch('/api' + path, {
    ...options,
    headers: { 'Content-Type': 'application/json' },
    body: options.body && JSON.stringify(options.body),
  })
  const data = res.status === 204 ? null : await res.json().catch(() => null)
  if (!res.ok) throw Object.assign(new Error(data?.error ?? 'Something went wrong. Please try again.'), { status: res.status, errors: data?.errors })
  return data
}

function useLoad(path, deps = []) {
  const [state, setState] = useState({ loading: true })
  const reload = () =>
    api(path).then(data => setState({ data }), error => setState({ error }))
  useEffect(() => { setState({ loading: true }); reload() }, deps) // eslint-disable-line react-hooks/exhaustive-deps
  return [state, reload]
}

const Status = ({ state, children }) =>
  state.loading ? <p className="muted" role="status">Loading…</p>
  : state.error ? <p className="alert error" role="alert">{state.error.message}</p>
  : children(state.data)

const Field = ({ label, error, ...input }) => (
  <div className={'field' + (error ? ' has-error' : '')}>
    <label htmlFor={input.name}>{label}</label>
    <input id={input.name} aria-invalid={!!error} aria-describedby={error ? input.name + '-error' : undefined} {...input} />
    {error && <p className="field-error" id={input.name + '-error'}>{error}</p>}
  </div>
)

const TastingMeta = ({ t }) => (
  <p className="when"><time>{t.startsAt}</time> · EUR {t.price} per guest</p>
)

function Home() {
  const [state] = useLoad('/tastings')
  return (
    <>
      <section className="hero">
        <h1>Wine Tastings</h1>
        <p>Join us at the family estate for an evening among the vines. Small groups, our own wines, and plenty of stories.</p>
      </section>
      <Status state={state}>{tastings => (
        <ul className="cards">
          {tastings.map(t => (
            <li key={t.id} className={'card' + (t.seatsLeft === 0 ? ' soldout' : '')}>
              <h2>{t.title}</h2>
              <p className="when"><time>{t.startsAt}</time></p>
              <p className="price">EUR {t.price} <span>per guest</span></p>
              {t.seatsLeft === 0
                ? <p className="badge full">Fully booked</p>
                : <p className="badge">{t.seatsLeft} seats left</p>}
              {t.seatsLeft > 0 && <Link className="button" to={`/book/${t.id}`}>Book {t.title}</Link>}
            </li>
          ))}
        </ul>
      )}</Status>
    </>
  )
}

function Book() {
  const { id } = useParams()
  const [state, reload] = useLoad(`/tastings/${id}`, [id])
  const [form, setForm] = useState({ name: '', email: '', guests: '2' })
  const [errors, setErrors] = useState({})
  const [busy, setBusy] = useState(false)
  const [booking, setBooking] = useState(null)
  const set = e => setForm({ ...form, [e.target.name]: e.target.value })

  async function submit(e) {
    e.preventDefault()
    setBusy(true)
    try {
      setBooking(await api(`/tastings/${id}/bookings`, { method: 'POST', body: form }))
    } catch (err) {
      setErrors(err.errors ?? { form: err.message })
      reload() // seats may have changed
    } finally { setBusy(false) }
  }

  if (booking) return (
    <section className="panel success" aria-live="polite">
      <h1>Booking confirmed</h1>
      <p>Thank you, {booking.name}! We look forward to seeing you.</p>
      <dl>
        <dt>Tasting</dt><dd>{booking.tasting.title}, {booking.tasting.startsAt}</dd>
        <dt>Guests</dt><dd>{booking.guests}</dd>
        <dt>Total price</dt><dd>EUR {booking.total}</dd>
        <dt>Booking reference</dt><dd className="ref">{booking.ref}</dd>
      </dl>
      <p className="muted">Please keep your reference. We will see you at the winery.</p>
      <Link className="button secondary" to="/">Back to all tastings</Link>
    </section>
  )

  return (
    <Status state={state}>{t => (
      <section className="panel">
        <Link to="/" className="back">← All tastings</Link>
        <h1>{t.title}</h1>
        <TastingMeta t={t} />
        {t.seatsLeft === 0 ? (
          <p className="alert error" role="alert">Sorry, this tasting is fully booked.</p>
        ) : (
          <>
            <p className="badge">{t.seatsLeft} seats left</p>
            <form onSubmit={submit} noValidate>
              {errors.form && <p className="alert error" role="alert">{errors.form}</p>}
              <Field label="Name" name="name" autoComplete="name" value={form.name} onChange={set} error={errors.name} />
              <Field label="Email" name="email" type="email" autoComplete="email" value={form.email} onChange={set} error={errors.email} />
              <Field label="Guests" name="guests" type="number" min="1" max="8" inputMode="numeric" value={form.guests} onChange={set} error={errors.guests} />
              <button className="button" disabled={busy}>Book</button>
            </form>
          </>
        )}
      </section>
    )}</Status>
  )
}

function Staff() {
  const [state, reload] = useLoad('/staff/bookings')
  const [password, setPassword] = useState('')
  const [error, setError] = useState()
  const [actionError, setActionError] = useState()

  async function signIn(e) {
    e.preventDefault()
    try { await api('/staff/login', { method: 'POST', body: { password } }); setPassword(''); setError(); reload() }
    catch (err) { setError(err.errors?.password ?? err.message) }
  }
  const signOut = () => api('/staff/logout', { method: 'POST' }).then(reload)
  const cancel = ref => api(`/staff/bookings/${ref}`, { method: 'DELETE' }).then(() => setActionError(), e => setActionError(e.message)).then(reload)

  if (state.loading) return <p className="muted" role="status">Loading…</p>
  if (state.error?.status === 401) return (
    <section className="panel narrow">
      <h1>Staff</h1>
      <form onSubmit={signIn} noValidate>
        <Field label="Password" name="password" type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} error={error} />
        <button className="button">Sign in</button>
      </form>
    </section>
  )
  return (
    <Status state={state}>{groups => (
      <section>
        <div className="row"><h1>Bookings</h1><button className="button secondary" onClick={signOut}>Sign out</button></div>
        {actionError && <p className="alert error" role="alert">{actionError}</p>}
        {groups.map(t => (
          <article key={t.id} className="panel group">
            <h2>{t.title} <small>{t.startsAt} · {t.seats - t.seatsLeft} of {t.seats} seats booked</small></h2>
            {t.bookings.length === 0 ? <p className="muted">No bookings yet.</p> : (
              <div className="scroll"><table>
                <thead><tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th></th></tr></thead>
                <tbody>{t.bookings.map(b => (
                  <tr key={b.ref}>
                    <td>{b.name}</td><td>{b.email}</td><td>{b.guests}</td><td className="ref">{b.ref}</td>
                    <td><button className="button danger small" onClick={() => cancel(b.ref)}>Cancel</button></td>
                  </tr>
                ))}</tbody>
              </table></div>
            )}
          </article>
        ))}
      </section>
    )}</Status>
  )
}

export default function App() {
  return (
    <>
      <header className="site-header"><Link to="/" className="brand">Weingut Kieselbrunnen<span>Family winery</span></Link></header>
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/book/:id" element={<Book />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<section className="panel"><h1>Page not found</h1><Link to="/">Back to all tastings</Link></section>} />
        </Routes>
      </main>
      <footer className="site-footer">© Weingut Kieselbrunnen · <Link to="/staff">Staff</Link></footer>
    </>
  )
}
