import { describe, it, expect, beforeEach } from 'vitest'
import request from 'supertest'
import { createApp } from '../server/app.js'

let app
beforeEach(() => { app = createApp({ staffPassword: 'secret' }) })

const book = (id, body) => request(app).post(`/api/tastings/${id}/bookings`).send(body)
const ok = { name: 'Anna', email: 'anna@example.com', guests: 2 }

async function staff() {
  const res = await request(app).post('/api/staff/login').send({ password: 'secret' })
  return res.headers['set-cookie']
}

describe('tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const { body } = await request(app).get('/api/tastings')
    expect(body.map(t => [t.title, t.price, t.seatsLeft])).toEqual([
      ['Riesling Evening', 25, 12],
      ['Red Wine Cellar Tour', 32, 8],
      ['Winter Tasting', 28, 10],
    ])
  })
})

describe('booking', () => {
  it('confirms with total and reference, and reduces seats', async () => {
    const res = await book('riesling-evening', ok)
    expect(res.status).toBe(201)
    expect(res.body).toMatchObject({ guests: 2, total: 50, tasting: { title: 'Riesling Evening' } })
    expect(res.body.ref).toMatch(/^KB-[A-Z0-9]{6}$/)
    const { body } = await request(app).get('/api/tastings/riesling-evening')
    expect(body.seatsLeft).toBe(10)
  })

  it.each([
    ['name', { ...ok, name: '  ' }],
    ['email', { ...ok, email: 'nope' }],
    ['guests', { ...ok, guests: 0 }],
    ['guests', { ...ok, guests: 9 }],
    ['guests', { ...ok, guests: 1.5 }],
    ['guests', { ...ok, guests: 'abc' }],
    ['guests', { ...ok, guests: '' }],
  ])('rejects invalid %s', async (field, body) => {
    const res = await book('winter-tasting', body)
    expect(res.status).toBe(400)
    expect(Object.keys(res.body.errors)).toEqual([field])
  })

  it('accepts guests sent as a numeric string', async () => {
    expect((await book('winter-tasting', { ...ok, guests: '3' })).status).toBe(201)
  })

  it('never takes more seats than are left', async () => {
    await book('red-wine-cellar-tour', { ...ok, guests: 8 })
    await book('red-wine-cellar-tour', { ...ok, guests: 8 }) // sold out now
    const { body } = await request(app).get('/api/tastings/red-wine-cellar-tour')
    expect(body.seatsLeft).toBe(0)

    await book('winter-tasting', { ...ok, guests: 8 })
    const res = await book('winter-tasting', { ...ok, guests: 3 })
    expect(res.status).toBe(409)
    expect(res.body.errors.guests).toMatch(/2 seats left/)
    expect((await book('winter-tasting', { ...ok, guests: 2 })).status).toBe(201)
  })

  it('says so when fully booked', async () => {
    await book('red-wine-cellar-tour', { ...ok, guests: 8 })
    const res = await book('red-wine-cellar-tour', ok)
    expect(res.status).toBe(409)
    expect(res.body.errors.guests).toMatch(/fully booked/i)
  })

  it('404s on unknown tasting', async () => {
    expect((await book('nope', ok)).status).toBe(404)
  })
})

describe('staff', () => {
  it('requires sign in', async () => {
    expect((await request(app).get('/api/staff/bookings')).status).toBe(401)
    expect((await request(app).delete('/api/staff/bookings/KB-AAAAAA')).status).toBe(401)
  })

  it('rejects a wrong password', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: 'wrong' })
    expect(res.status).toBe(401)
    expect(res.body.errors.password).toBeTruthy()
  })

  it('refuses all logins when STAFF_PASSWORD is not set', async () => {
    const open = createApp({ staffPassword: '' })
    const res = await request(open).post('/api/staff/login').send({ password: '' })
    expect(res.status).toBe(401)
  })

  it('lists bookings grouped by tasting and cancel frees seats', async () => {
    const { body: b } = await book('riesling-evening', ok)
    const cookie = await staff()
    const list = await request(app).get('/api/staff/bookings').set('Cookie', cookie)
    const group = list.body.find(t => t.id === 'riesling-evening')
    expect(group.bookings).toEqual([{ ref: b.ref, name: 'Anna', email: 'anna@example.com', guests: 2 }])
    expect(list.body).toHaveLength(3)

    expect((await request(app).delete(`/api/staff/bookings/${b.ref}`).set('Cookie', cookie)).status).toBe(204)
    expect((await request(app).get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(12)
    expect((await request(app).delete(`/api/staff/bookings/${b.ref}`).set('Cookie', cookie)).status).toBe(404)
  })

  it('sign out ends the session', async () => {
    const cookie = await staff()
    await request(app).post('/api/staff/logout').set('Cookie', cookie)
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401)
  })
})

it('answers malformed JSON with a JSON 400, not a stack trace', async () => {
  const res = await request(app).post('/api/staff/login').set('Content-Type', 'application/json').send('{bad')
  expect(res.status).toBe(400)
  expect(res.body.error).toBeTruthy()
})
