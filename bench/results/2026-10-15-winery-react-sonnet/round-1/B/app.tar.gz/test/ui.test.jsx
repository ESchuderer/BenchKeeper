// @vitest-environment jsdom
import { describe, it, expect, beforeAll, afterAll, afterEach } from 'vitest'
import { render, screen, within, cleanup } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import App from '../src/App.jsx'
import { createApp } from '../server/app.js'

let server, base
const realFetch = globalThis.fetch
let cookie = ''
beforeAll(async () => {
  server = createApp({ staffPassword: 'secret' }).listen(0)
  base = `http://localhost:${server.address().port}`
  // jsdom has no cookie-aware fetch for a foreign origin, so keep a tiny jar
  globalThis.fetch = async (url, opts = {}) => {
    const res = await realFetch(base + url, { ...opts, headers: { ...opts.headers, cookie } })
    const set = res.headers.get('set-cookie')
    if (set) cookie = set.split(';')[0]
    return res
  }
})
afterEach(cleanup)
afterAll(() => { globalThis.fetch = realFetch; server.close() })

const open = path => render(<MemoryRouter initialEntries={[path]}><App /></MemoryRouter>)

describe('guest flow', () => {
  it('books a tasting and shows the confirmation', async () => {
    const user = userEvent.setup()
    open('/')
    expect(await screen.findByText('12 seats left')).toBeInTheDocument()
    await user.click(screen.getByRole('link', { name: 'Book Riesling Evening' }))

    await user.click(await screen.findByRole('button', { name: 'Book' }))
    expect(await screen.findByText('Please enter your name.')).toBeInTheDocument()
    expect(screen.getByLabelText('Name')).toHaveAccessibleDescription('Please enter your name.')

    await user.type(screen.getByLabelText('Name'), 'Anna')
    await user.type(screen.getByLabelText('Email'), 'anna@example.com')
    await user.clear(screen.getByLabelText('Guests'))
    await user.type(screen.getByLabelText('Guests'), '3')
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument()
    expect(screen.getByText('EUR 75')).toBeInTheDocument()
    expect(screen.getByText(/^KB-[A-Z0-9]{6}$/)).toBeInTheDocument()
  })

  it('rejects more guests than seats left next to the field, and shows sold out', async () => {
    const user = userEvent.setup()
    open('/book/red-wine-cellar-tour')
    await user.type(await screen.findByLabelText('Name'), 'Bo')
    await user.type(screen.getByLabelText('Email'), 'bo@example.com')
    await user.clear(screen.getByLabelText('Guests'))
    await user.type(screen.getByLabelText('Guests'), '8')
    await user.click(screen.getByRole('button', { name: 'Book' }))
    await screen.findByRole('heading', { name: 'Booking confirmed' })

    open('/')
    expect(await screen.findByText('Fully booked')).toBeInTheDocument()
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeNull()
  })
})

describe('staff flow', () => {
  it('signs in, lists bookings, cancels one', async () => {
    const user = userEvent.setup()
    open('/staff')
    await user.type(await screen.findByLabelText('Password'), 'wrong')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))
    expect(await screen.findByText('Wrong password.')).toBeInTheDocument()

    await user.clear(screen.getByLabelText('Password'))
    await user.type(screen.getByLabelText('Password'), 'secret')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))
    const group = (await screen.findByRole('heading', { name: /Riesling Evening/ })).closest('article')
    expect(within(group).getByText('anna@example.com')).toBeInTheDocument()

    await user.click(within(group).getByRole('button', { name: 'Cancel' }))
    expect(await within(group).findByText('No bookings yet.')).toBeInTheDocument()
  })
})
