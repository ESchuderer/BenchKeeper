# Weingut Kieselbrunnen tasting bookings

Guests book wine tastings online; staff see and cancel bookings at `/staff`.

## Run

```
npm install
npm run build
STAFF_PASSWORD=<password> npm start
```

Serves the app on `PORT` (default 3000). Bookings are kept in memory and are lost on restart.

| Variable | Meaning |
|---|---|
| `STAFF_PASSWORD` | Staff password. If unset or empty, staff sign-in is disabled. |
| `PORT` | HTTP port, default 3000. |
| `TRUST_PROXY` | Express `trust proxy` value (for example `1`). Set it behind a TLS-terminating proxy so the session cookie is `Secure` and the sign-in limit sees client IPs. |

## Test

```
npm test                          # API tests (Vitest)
npx playwright install chromium   # once
npm run build && npm run test:e2e # browser tests, start the app on port 3100
npm run typecheck
```

Specs: `openspec/`.
