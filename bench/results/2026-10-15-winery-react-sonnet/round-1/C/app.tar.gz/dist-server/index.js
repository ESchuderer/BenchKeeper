// server/index.ts
import path2 from "node:path";

// server/app.ts
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { existsSync } from "node:fs";
import path from "node:path";
import express from "express";
import { rateLimit } from "express-rate-limit";
import session from "express-session";
import helmet from "helmet";

// shared/booking-schema.ts
import { z } from "zod";
var MAX_GUESTS = 8;
var guestsMessage = `Enter a whole number of guests from 1 to ${MAX_GUESTS}`;
var bookingSchema = z.object({
  name: z.string().trim().min(1, "Enter your name").max(100, "Use at most 100 characters"),
  email: z.string().trim().pipe(z.email("Enter a valid email address")),
  guests: z.number({ error: guestsMessage }).int(guestsMessage).min(1, guestsMessage).max(MAX_GUESTS, guestsMessage)
});
function fieldErrors(error) {
  const out = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "");
    if (key && !(key in out)) out[key] = issue.message;
  }
  return out;
}
var seatsMessage = (seatsLeft) => seatsLeft === 0 ? "This tasting is fully booked" : `Only ${seatsLeft} seats left for this tasting`;

// server/store.ts
import { randomInt } from "node:crypto";

// server/tastings.ts
var TASTINGS = [
  { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06 18:00", pricePerGuest: 25, capacity: 12 },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", startsAt: "2026-11-14 15:00", pricePerGuest: 32, capacity: 8 },
  { id: "winter-tasting", title: "Winter Tasting", startsAt: "2026-12-05 17:00", pricePerGuest: 28, capacity: 10 }
];

// server/store.ts
var ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function createStore() {
  const bookings = /* @__PURE__ */ new Map();
  const seatsLeft = (t) => {
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === t.id) taken += b.guests;
    return t.capacity - taken;
  };
  const reference = () => {
    let ref;
    do {
      ref = "KB-" + Array.from({ length: 6 }, () => ALPHABET[randomInt(ALPHABET.length)]).join("");
    } while (bookings.has(ref));
    return ref;
  };
  return {
    tastings: () => TASTINGS.map((t) => ({ ...t, seatsLeft: seatsLeft(t) })),
    /** Synchronous, so the seat check and the insert cannot interleave with another request. */
    book(tastingId, input) {
      const tasting = TASTINGS.find((t) => t.id === tastingId);
      if (!tasting) return { error: "not-found" };
      const left = seatsLeft(tasting);
      if (input.guests > left) return { error: "seats", message: seatsMessage(left) };
      const booking = { ...input, reference: reference(), tastingId };
      bookings.set(booking.reference, booking);
      return { booking, tasting, total: tasting.pricePerGuest * input.guests };
    },
    cancel: (ref) => bookings.delete(ref),
    byTasting: () => TASTINGS.map((t) => ({
      tasting: { ...t, seatsLeft: seatsLeft(t) },
      bookings: [...bookings.values()].filter((b) => b.tastingId === t.id).map(({ reference: reference2, name, email, guests }) => ({ reference: reference2, name, email, guests }))
    }))
  };
}

// server/app.ts
var digest = (s) => createHash("sha256").update(s).digest();
function createApp(opts = {}) {
  const { staffPassword: staffPassword2 = "", sessionTtlMs = 8 * 60 * 60 * 1e3, trustProxy: trustProxy2, staticDir } = opts;
  const store = createStore();
  const app = express();
  if (trustProxy2 !== void 0) app.set("trust proxy", trustProxy2);
  app.disable("x-powered-by");
  app.use(helmet());
  app.use(express.json({ limit: "10kb" }));
  app.use(
    session({
      secret: randomBytes(32).toString("hex"),
      name: "kb.sid",
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: "strict", secure: "auto", maxAge: sessionTtlMs }
    })
  );
  const requireStaff = (req, res, next) => {
    const since = req.session.staff;
    if (since !== void 0 && Date.now() - since < sessionTtlMs) return next();
    res.status(401).json({ error: "Please sign in." });
  };
  const api = express.Router();
  api.use((_req, res, next) => {
    res.set("Cache-Control", "no-store");
    next();
  });
  api.get("/tastings", (_req, res) => void res.json(store.tastings()));
  api.post("/tastings/:id/bookings", (req, res) => {
    const parsed = bookingSchema.safeParse(req.body);
    if (!parsed.success) {
      const errors = fieldErrors(parsed.error);
      return void res.status(400).json(Object.keys(errors).length ? { errors } : { error: "Invalid request." });
    }
    const result = store.book(String(req.params.id), parsed.data);
    if ("error" in result) {
      return result.error === "not-found" ? void res.status(404).json({ error: "Tasting not found." }) : void res.status(409).json({ errors: { guests: result.message } });
    }
    const { booking, tasting, total } = result;
    res.status(201).json({
      reference: booking.reference,
      guests: booking.guests,
      total,
      tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt }
    });
  });
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1e3,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: "draft-8",
    legacyHeaders: false,
    message: { error: "Too many failed attempts. Try again in 15 minutes." }
  });
  api.post("/staff/login", loginLimiter, (req, res) => {
    const given = typeof req.body?.password === "string" ? req.body.password : "";
    const ok = staffPassword2 !== "" && timingSafeEqual(digest(given), digest(staffPassword2));
    if (!ok) return void res.status(401).json({ error: "Wrong password." });
    req.session.regenerate((err) => {
      if (err) return void res.status(500).json({ error: "Sign-in failed." });
      req.session.staff = Date.now();
      res.status(204).end();
    });
  });
  api.post("/staff/logout", (req, res) => {
    req.session.destroy(() => {
      res.clearCookie("kb.sid").status(204).end();
    });
  });
  api.get("/staff/bookings", requireStaff, (_req, res) => void res.json(store.byTasting()));
  api.delete("/staff/bookings/:reference", requireStaff, (req, res) => {
    res.status(store.cancel(String(req.params.reference)) ? 204 : 404).end();
  });
  api.use((_req, res) => void res.status(404).json({ error: "Not found." }));
  app.use("/api", api);
  if (staticDir && existsSync(staticDir)) {
    app.use(express.static(staticDir));
    app.use(
      (req, res, next) => req.method === "GET" ? res.sendFile(path.join(staticDir, "index.html")) : next()
    );
  }
  app.use((err, _req, res, _next) => {
    const status = err.status && err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 500 ? "Server error." : "Invalid request." });
  });
  return app;
}

// server/index.ts
var staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
var proxy = process.env.TRUST_PROXY;
var trustProxy = proxy === void 0 ? void 0 : /^\d+$/.test(proxy) ? Number(proxy) : proxy === "true" ? true : proxy === "false" ? false : proxy;
var port = Number(process.env.PORT) || 3e3;
createApp({ staffPassword, trustProxy, staticDir: path2.resolve(import.meta.dirname, "../dist") }).listen(
  port,
  () => console.log(`Weingut Kieselbrunnen bookings on http://localhost:${port}`)
);
