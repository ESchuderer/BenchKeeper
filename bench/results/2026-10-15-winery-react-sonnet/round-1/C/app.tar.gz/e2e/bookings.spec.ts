import { expect, test, type Page } from '@playwright/test';

const card = (page: Page, title: string) => page.getByRole('article').filter({ hasText: title });

async function book(page: Page, title: string, guests: number, name = 'Anna Weber', email = 'anna@example.com') {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${title}` }).click();
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Guests').fill(String(guests));
  await page.getByRole('button', { name: 'Book', exact: true }).click();
}

test('start page lists the tastings', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  const riesling = card(page, 'Riesling Evening');
  await expect(riesling).toContainText('2026-11-06 18:00');
  await expect(riesling).toContainText('EUR 25');
  await expect(riesling).toContainText('12 seats left');
  await expect(card(page, 'Red Wine Cellar Tour')).toContainText('EUR 32');
  await expect(card(page, 'Winter Tasting')).toContainText('2026-12-05 17:00');
});

test('guest books a tasting and sees the confirmation', async ({ page }) => {
  await book(page, 'Riesling Evening', 2);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const main = page.getByRole('main');
  await expect(main).toContainText('Riesling Evening');
  await expect(main).toContainText('2 guests');
  await expect(main).toContainText('EUR 50');
  await expect(main).toContainText(/KB-[A-Z0-9]{6}/);
  await page.goto('/');
  await expect(card(page, 'Riesling Evening')).toContainText('10 seats left');
});

test('invalid input shows an error next to each field', async ({ page }) => {
  await page.goto('/book/winter-tasting');
  await page.getByLabel('Email').fill('not-an-email');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription(/Enter your name/);
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription(/valid email/);
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/1 to 8/);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
});

test('a booking can not take more seats than are left', async ({ page }) => {
  await book(page, 'Red Wine Cellar Tour', 6);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/book/red-wine-cellar-tour');
  await page.getByLabel('Name').fill('Ben');
  await page.getByLabel('Email').fill('ben@example.com');
  await page.getByLabel('Guests').fill('3');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/Only 2 seats left/);

  await book(page, 'Red Wine Cellar Tour', 2, 'Ben', 'ben@example.com');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await page.goto('/');
  await expect(card(page, 'Red Wine Cellar Tour')).toContainText('0 seats left');
  await expect(card(page, 'Red Wine Cellar Tour')).toContainText('Fully booked');

  await page.getByRole('link', { name: 'Book Red Wine Cellar Tour' }).click();
  await expect(page.getByRole('main')).toContainText('fully booked');
  await page.getByLabel('Name').fill('Cleo');
  await page.getByLabel('Email').fill('cleo@example.com');
  await page.getByLabel('Guests').fill('1');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/fully booked/i);
});

test('staff sign in, see bookings grouped, cancel and sign out', async ({ page }) => {
  await book(page, 'Winter Tasting', 4, 'Dora Fischer', 'dora@example.com');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const ref = (await page.getByRole('main').textContent())!.match(/KB-[A-Z0-9]{6}/)![0];

  await page.goto('/staff');
  await expect(page.getByRole('heading', { name: 'Staff' })).toBeVisible();
  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('alert')).toContainText('Wrong password');
  await expect(page.getByText('dora@example.com')).toHaveCount(0);

  await page.getByLabel('Password').fill('e2e-secret');
  await page.getByRole('button', { name: 'Sign in' }).click();
  const group = page.getByRole('region', { name: 'Winter Tasting' });
  await expect(group).toContainText('Dora Fischer');
  await expect(group).toContainText('dora@example.com');
  await expect(group).toContainText(ref);
  await expect(page.getByRole('region', { name: 'Riesling Evening' })).toContainText('Anna Weber');

  await group.getByRole('row').filter({ hasText: ref }).getByRole('button', { name: 'Cancel' }).click();
  await expect(group).not.toContainText(ref);
  await expect(group).toContainText('No bookings yet');
  await page.goto('/');
  await expect(card(page, 'Winter Tasting')).toContainText('10 seats left');

  await page.goto('/staff');
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByRole('button', { name: 'Sign in' })).toBeVisible();
  await page.reload();
  await expect(page.getByRole('button', { name: 'Sign in' })).toBeVisible();
});

test.describe('@responsive', () => {
  for (const path of ['/', '/book/riesling-evening', '/staff']) {
    test(`no horizontal scroll at ${path}`, async ({ page }) => {
      await page.goto(path);
      await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
      );
      expect(overflow).toBeLessThanOrEqual(0);
    });
  }
});
