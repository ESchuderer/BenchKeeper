# Design

## Context

Greenfield repository (Node.js 22, npm). `npm start` must serve the whole app on `PORT` (default 3000). See proposal.md for scope.

## Goals / Non-Goals

**Goals:**
- One process serves the built React app and a JSON API.
- Seat accounting that cannot overbook.
- Staff authentication with expiry, sign-out, failed-attempt limit and safe cookies.

**Non-Goals:**
- Persistence across restarts, multiple server instances, email, payments.

## Decisions

- **Server: Express 5 serving `dist/` plus `/api`.** Alternatives: Next.js (heavier, SSR not needed), Fastify (no advantage here).
- **Client: Vite + React + React Router (`/`, `/book/:id`, `/staff`).** Alternative: server-rendered pages (contradicts the React requirement).
- **Forms: react-hook-form with a zod schema in `shared/`.** The same schema runs in the browser (instant messages) and on the server (authoritative). Server field errors are mapped back onto the fields.
- **Tasting data: constants in `server/tastings.ts`; bookings in an in-memory `Map`.** Booking creation is one synchronous function (check seats, insert), so Node's single thread makes it atomic. `shortcut: bookings are lost on restart, move to a file or database when persistence is needed.`
- **Money: whole euros as integers**, shown as `EUR <n>`.
- **Booking reference: `KB-` plus 6 characters from an unambiguous alphabet, via `crypto.randomInt`**, regenerated on collision.
- **Confirmation is rendered by the booking page after the POST succeeds.** No public endpoint returns a booking, so guest names and emails are never readable without a staff session. A reload of the confirmation shows the form again.
- **Staff auth: `express-session` with the default in-memory store**, `httpOnly`, `sameSite: strict`, `secure: 'auto'` (honours `TRUST_PROXY` for TLS-terminating proxies), 8 hour lifetime, random per-process secret, `saveUninitialized: false`. Server-side sessions make sign-out immediate (the session is destroyed). Alternative: stateless signed cookie (cannot revoke).
- **Password check: SHA-256 of both values compared with `crypto.timingSafeEqual`.** Unset or empty `STAFF_PASSWORD` rejects every login and logs a warning.
- **Failed-attempt limit: `express-rate-limit` on the login route**, 5 failures per 15 minutes per IP, successful logins not counted. Cancel is `DELETE` with `SameSite=Strict`, which blocks cross-site requests.
- **Headers: `helmet`.** No external fonts or scripts, so the default CSP holds.
- **Build: `vite build` for the client, `esbuild` bundle for the server (`dist-server/index.js`)**, so `npm start` is `node dist-server/index.js` on any Node 22.
- **Styling: one hand-written CSS file with custom properties**; system serif for headings, no web fonts.
- **Tests:** Vitest + Supertest for the API (`createApp()` factory takes password, TTL and limit so tests configure it); Playwright for the guest and staff flows against the built app, desktop and phone viewport.

## Risks / Trade-offs

- In-memory state is lost on restart or lost bookings on crash → documented; acceptable per task statement.
- Session store is in memory and per-process → single instance only.
- IP-based limiter behind a proxy sees the proxy address unless `TRUST_PROXY` is set → document the variable.
- Seats-left shown in the browser can be stale → the server is authoritative and returns a field error.
