# Proposal

## Why

Weingut Kieselbrunnen takes tasting reservations without a shared system. Guests need to book seats online for three scheduled tastings, and staff need to see and cancel bookings, without overbooking.

## What Changes

- New web app (React front end, Node.js server) serving guests and staff from one port.
- Guests see the tastings with date and time, price per guest and seats left, open a booking form, and receive a confirmation with a booking reference.
- The server rejects any booking that exceeds the seats left and reports field-level errors.
- Staff sign in at `/staff` with a password from `STAFF_PASSWORD`, see bookings grouped by tasting, and cancel bookings (seats are freed).
- Bookings are kept in memory; the app starts empty.

## Capabilities

### New Capabilities
- `tasting-catalog`: the start page listing the offered tastings, their price and live seats left, including the fully booked state.
- `tasting-booking`: the guest booking form, input validation, seat limits and the booking confirmation.
- `staff-bookings`: password sign-in, session handling, the grouped booking list and cancellation.

### Modified Capabilities

None.

## Impact

- New code: `server/` (Express API), `src/` (React app), `shared/` (validation schema), tests, `package.json`.
- Dependencies: react, react-router, react-hook-form, zod, express, express-session, express-rate-limit, helmet, vite, vitest, supertest, Playwright.
- Environment: `STAFF_PASSWORD`, `PORT`, optional `TRUST_PROXY`.
- Out of scope: payments, email sending, guest self-cancellation, persistence across restarts, admin editing of tastings.
