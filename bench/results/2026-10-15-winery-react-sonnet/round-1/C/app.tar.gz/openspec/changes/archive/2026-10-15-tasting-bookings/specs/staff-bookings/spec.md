# Spec Delta

## Purpose

Gives winery staff a password-protected view of all bookings per tasting and the ability to cancel a booking and free its seats.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL show a "Password" field and a "Sign in" button until staff have signed in. The accepted password SHALL be the value of the environment variable `STAFF_PASSWORD`. If the variable is unset or empty, nobody SHALL be able to sign in.

#### Scenario: Wrong password
- **WHEN** staff submit a wrong password
- **THEN** an error message is shown and no booking data is shown

#### Scenario: Correct password
- **WHEN** staff submit the value of `STAFF_PASSWORD`
- **THEN** the booking list is shown

### Requirement: Protected booking data
Booking data (names, emails, references) SHALL be available only to a signed-in staff session.

#### Scenario: Unauthenticated request
- **WHEN** the bookings list is requested without a staff session
- **THEN** the server answers 401 and returns no booking data

### Requirement: Session lifecycle and sign-in hardening
A staff session SHALL expire after a fixed time and SHALL be ended by "Sign out". After 5 failed sign-in attempts from one client within 15 minutes, further attempts SHALL be refused until the window ends. The session cookie SHALL be HttpOnly and SameSite, and Secure when the request is served over HTTPS.

#### Scenario: Sign out
- **WHEN** a signed-in staff member activates "Sign out"
- **THEN** the old session no longer returns booking data

#### Scenario: Expired session
- **WHEN** the session lifetime has passed
- **THEN** the bookings list is refused with 401

#### Scenario: Too many failed attempts
- **WHEN** a client submits 5 wrong passwords and then the correct one
- **THEN** the sixth attempt is refused with an error message and no session is created

### Requirement: Bookings grouped by tasting
A signed-in staff member SHALL see all active bookings grouped under their tasting, each with name, email, guests and booking reference.

#### Scenario: Grouped list
- **WHEN** bookings exist for two tastings
- **THEN** each booking appears under its own tasting with name, email, guests and reference
- **AND** a tasting without bookings is shown with a "No bookings yet" note

### Requirement: Cancel booking
Each booking in the staff list SHALL have a "Cancel" button that removes the booking and frees its seats.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 3 guests for Riesling Evening
- **THEN** the booking disappears from the staff list
- **AND** the start page shows 3 more seats left for Riesling Evening
