# Spec Delta

## Purpose

Lets a guest reserve seats at a tasting, guarantees that seats are never overbooked, and confirms the reservation with a reference.

## ADDED Requirements

### Requirement: Booking form
The booking form for a tasting SHALL show the tasting, the fields "Name", "Email" and "Guests", and a "Book" button.

#### Scenario: Form fields
- **WHEN** a guest opens the booking form for Winter Tasting
- **THEN** the form names the tasting and shows fields labelled "Name", "Email" and "Guests" and a button "Book"

### Requirement: Input validation
The system SHALL accept a booking only with a non-empty name, a syntactically valid email address and a whole number of guests from 1 to 8. Each rejected field SHALL show an error message next to that field, and no booking SHALL be created.

#### Scenario: Empty and invalid fields
- **WHEN** a guest submits an empty name, the email "not-an-email" and 9 guests
- **THEN** an error message appears next to each of "Name", "Email" and "Guests"
- **AND** the seats left do not change

#### Scenario: Server-side enforcement
- **WHEN** a booking request with invalid values is sent directly to the server
- **THEN** the server rejects it with the per-field messages and creates no booking

### Requirement: Seat limit
A booking SHALL NOT take more seats than are left for the tasting, including when bookings are submitted at the same time.

#### Scenario: More guests than seats left
- **WHEN** 3 seats are left and a guest books 4
- **THEN** the booking is rejected with an error message next to "Guests" stating the seats left
- **AND** the seats left remain 3

#### Scenario: Tasting full
- **WHEN** a guest books 1 guest for a tasting with 0 seats left
- **THEN** the booking is rejected with an error message next to "Guests"

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (price per guest times guests) and a unique booking reference.

#### Scenario: Successful booking
- **WHEN** a guest books 2 guests for Riesling Evening with valid name and email
- **THEN** the page shows "Booking confirmed", "Riesling Evening", 2 guests, a total of EUR 50 and a booking reference
- **AND** the start page shows "10 seats left" for Riesling Evening
