# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` (scripts `build`, `start`, `test`, `test:e2e`), TypeScript, Vite and Vitest config, install dependencies; verify `npm install` and `npm run build` on a stub succeed
- [x] 1.2 Add `.gitignore` (node_modules, dist, dist-server, test output); verify `git status` shows no generated files

## 2. Booking domain and API (tests first)

- [x] 2.1 Write failing API tests for tastings, booking, validation, seat limit and cancel-frees-seats; verify they fail
- [x] 2.2 Implement `shared/booking-schema.ts`, `server/tastings.ts`, `server/store.ts` and the public routes; verify the tests from 2.1 pass
- [x] 2.3 Write failing tests for staff auth (401, wrong/right password, unset password, logout, expiry, attempt limit, cookie flags); then implement the staff routes and session; verify they pass

## 3. Guest interface

- [x] 3.1 Implement layout, CSS and the start page (tasting list, seats left, fully booked state); verify with a Playwright test
- [x] 3.2 Implement the booking form with inline errors and the confirmation; verify with Playwright tests for success, invalid input and overbooking

## 4. Staff interface

- [x] 4.1 Implement sign-in, grouped list, Cancel and Sign out on `/staff`; verify with a Playwright test covering sign-in, list, cancel and seats freed

## 5. Integration and docs

- [x] 5.1 Serve `dist/` and SPA fallback from the server; verify `npm run build && STAFF_PASSWORD=x npm start` serves `/`, `/staff` and `/book/riesling-evening` on `PORT`
- [x] 5.2 Check the pages in a browser on desktop and phone width (Playwright MCP screenshots); fix layout issues
- [x] 5.3 Add `README.md` with run commands and environment variables; verify the commands run as written

## Workflow follow-up

- Review the branch, then archive the change (`openspec-archive-change`) on the branch.
