# tasting-catalog Specification

## Purpose
Shows guests which tastings the winery offers, what they cost and how many seats remain, so they can choose one to book.

## Requirements

### Requirement: Start page lists tastings
The start page SHALL list every tasting with its title, date and time, price per guest and seats left. The offered tastings are Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats).

#### Scenario: Fresh start
- **WHEN** a guest opens the start page and no bookings exist
- **THEN** the page shows "12 seats left", "8 seats left" and "10 seats left" for the three tastings in date order
- **AND** each tasting shows its date and time and its price per guest in euros

### Requirement: Seats left reflect bookings
The seats left of a tasting SHALL equal its capacity minus the guests of all active bookings, and SHALL be shown as "<n> seats left".

#### Scenario: Booking reduces seats
- **WHEN** a booking for 3 guests is made for Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening

#### Scenario: Cancellation restores seats
- **WHEN** staff cancel that booking
- **THEN** the start page shows "12 seats left" for Riesling Evening again

### Requirement: Book link per tasting
Each tasting SHALL offer a link or button named "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens

### Requirement: Fully booked state
A tasting with no seats left SHALL be marked "Fully booked" on the start page.

#### Scenario: Last seats taken
- **WHEN** the active bookings of a tasting use all its seats
- **THEN** the tasting shows "0 seats left" and a "Fully booked" marker
