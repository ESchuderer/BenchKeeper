import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: 'e2e',
  workers: 1,
  use: { baseURL: 'http://localhost:3100' },
  projects: [
    { name: 'desktop', use: { viewport: { width: 1280, height: 800 } } },
    { name: 'phone', use: { viewport: { width: 375, height: 700 } }, grep: /@responsive/ },
  ],
  webServer: {
    command: 'npm start',
    url: 'http://localhost:3100',
    env: { PORT: '3100', STAFF_PASSWORD: 'e2e-secret' },
    reuseExistingServer: false,
  },
});
