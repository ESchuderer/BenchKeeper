import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from './app.ts';

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

const newApp = (opts = {}) => createApp({ staffPassword: 'secret', ...opts });
const seatsLeft = async (app: ReturnType<typeof newApp>, id: string) =>
  (await request(app).get('/api/tastings')).body.find((t: { id: string }) => t.id === id).seatsLeft;

describe('tastings', () => {
  it('lists the three tastings in date order with all seats free', async () => {
    const res = await request(newApp()).get('/api/tastings');
    expect(res.status).toBe(200);
    expect(res.body.map((t: any) => [t.title, t.startsAt, t.pricePerGuest, t.seatsLeft])).toEqual([
      ['Riesling Evening', '2026-11-06 18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14 15:00', 32, 8],
      ['Winter Tasting', '2026-12-05 17:00', 28, 10],
    ]);
  });
});

describe('booking', () => {
  it('confirms a booking with total price and reference, and reduces seats', async () => {
    const app = newApp();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(valid);
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ guests: 2, total: 50, tasting: { title: 'Riesling Evening' } });
    expect(res.body.reference).toMatch(/^KB-[A-Z0-9]{6}$/);
    expect(await seatsLeft(app, 'riesling-evening')).toBe(10);
  });

  it('gives each booking a unique reference', async () => {
    const app = newApp();
    const refs = new Set<string>();
    for (let i = 0; i < 6; i++) {
      const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...valid, guests: 1 });
      refs.add(res.body.reference);
    }
    expect(refs.size).toBe(6);
  });

  it('rejects invalid fields with a message per field and creates nothing', async () => {
    const app = newApp();
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: ' ', email: 'not-an-email', guests: 9 });
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
    expect(await seatsLeft(app, 'riesling-evening')).toBe(12);
  });

  it.each([0, 1.5, '2', null, -1])('rejects guests=%j', async (guests) => {
    const res = await request(newApp())
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...valid, guests });
    expect(res.status).toBe(400);
    expect(res.body.errors.guests).toBeTruthy();
  });

  it('rejects more guests than seats left on the guests field', async () => {
    const app = newApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...valid, guests: 6 });
    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...valid, guests: 3 });
    expect(res.status).toBe(409);
    expect(res.body.errors.guests).toMatch(/2 seats left/);
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(2);
  });

  it('rejects any booking when the tasting is full', async () => {
    const app = newApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...valid, guests: 8 });
    const res = await request(app)
      .post('/api/tastings/red-wine-cellar-tour/bookings')
      .send({ ...valid, guests: 1 });
    expect(res.status).toBe(409);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });

  it('never overbooks under concurrent requests', async () => {
    const app = newApp();
    const results = await Promise.all(
      Array.from({ length: 6 }, () =>
        request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...valid, guests: 3 }),
      ),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(2);
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(2);
  });

  it('answers 404 for an unknown tasting and 400 for malformed JSON', async () => {
    const app = newApp();
    expect((await request(app).post('/api/tastings/nope/bookings').send(valid)).status).toBe(404);
    const bad = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{oops');
    expect(bad.status).toBe(400);
  });
});

describe('staff', () => {
  const signIn = async (app: ReturnType<typeof newApp>) => {
    const agent = request.agent(app);
    const res = await agent.post('/api/staff/login').send({ password: 'secret' });
    return { agent, res };
  };

  it('refuses booking data without a session', async () => {
    const res = await request(newApp()).get('/api/staff/bookings');
    expect(res.status).toBe(401);
    expect(res.body).toEqual({ error: expect.any(String) });
  });

  it('rejects a wrong password and accepts the right one', async () => {
    const app = newApp();
    expect((await request(app).post('/api/staff/login').send({ password: 'wrong' })).status).toBe(401);
    expect((await request(app).post('/api/staff/login').send({})).status).toBe(401);
    const { agent, res } = await signIn(app);
    expect(res.status).toBe(204);
    expect((await agent.get('/api/staff/bookings')).status).toBe(200);
  });

  it('rejects every password when STAFF_PASSWORD is unset or empty', async () => {
    for (const staffPassword of [undefined, '']) {
      const app = createApp({ staffPassword });
      expect((await request(app).post('/api/staff/login').send({ password: '' })).status).toBe(401);
      expect((await request(app).post('/api/staff/login').send({ password: 'undefined' })).status).toBe(401);
    }
  });

  it('groups bookings by tasting and cancel frees the seats', async () => {
    const app = newApp();
    const booked = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...valid, guests: 4 });
    const { agent } = await signIn(app);
    const list = await agent.get('/api/staff/bookings');
    expect(list.body).toHaveLength(3);
    const winter = list.body.find((g: any) => g.tasting.id === 'winter-tasting');
    expect(winter.bookings).toEqual([
      { reference: booked.body.reference, name: 'Anna Weber', email: 'anna@example.com', guests: 4 },
    ]);
    expect(list.body.find((g: any) => g.tasting.id === 'riesling-evening').bookings).toEqual([]);

    expect(await seatsLeft(app, 'winter-tasting')).toBe(6);
    expect((await agent.delete(`/api/staff/bookings/${booked.body.reference}`)).status).toBe(204);
    expect(await seatsLeft(app, 'winter-tasting')).toBe(10);
    expect((await agent.delete(`/api/staff/bookings/${booked.body.reference}`)).status).toBe(404);
  });

  it('refuses cancel without a session and keeps the booking', async () => {
    const app = newApp();
    const booked = await request(app).post('/api/tastings/winter-tasting/bookings').send(valid);
    const res = await request(app).delete(`/api/staff/bookings/${booked.body.reference}`);
    expect(res.status).toBe(401);
    expect(await seatsLeft(app, 'winter-tasting')).toBe(8);
  });

  it('ends the session on logout', async () => {
    const { agent } = await signIn(newApp());
    expect((await agent.post('/api/staff/logout')).status).toBe(204);
    expect((await agent.get('/api/staff/bookings')).status).toBe(401);
  });

  it('expires the session after its lifetime', async () => {
    const { agent } = await signIn(newApp({ sessionTtlMs: 1000 }));
    expect((await agent.get('/api/staff/bookings')).status).toBe(200);
    await new Promise((r) => setTimeout(r, 1200));
    expect((await agent.get('/api/staff/bookings')).status).toBe(401);
  });

  it('refuses sign-in after 5 failed attempts, even with the right password', async () => {
    const app = newApp();
    for (let i = 0; i < 5; i++) {
      expect((await request(app).post('/api/staff/login').send({ password: 'x' })).status).toBe(401);
    }
    const res = await request(app).post('/api/staff/login').send({ password: 'secret' });
    expect(res.status).toBe(429);
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('sets HttpOnly and SameSite cookies, Secure only over HTTPS', async () => {
    const http = await request(newApp()).post('/api/staff/login').send({ password: 'secret' });
    const httpCookie = http.headers['set-cookie']![0];
    expect(httpCookie).toMatch(/HttpOnly/i);
    expect(httpCookie).toMatch(/SameSite=Strict/i);
    expect(httpCookie).not.toMatch(/Secure/i);

    const https = await request(newApp({ trustProxy: 1 }))
      .post('/api/staff/login')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: 'secret' });
    expect(https.headers['set-cookie']![0]).toMatch(/Secure/i);
  });
});

describe('hardening', () => {
  it('ends a session after a fixed time even while it is in use', async () => {
    const app = newApp({ sessionTtlMs: 1000 });
    const login = await request(app).post('/api/staff/login').send({ password: 'secret' });
    const cookie = login.headers['set-cookie']![0].split(';')[0];
    const status = async () => (await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status;
    expect(await status()).toBe(200);
    await new Promise((r) => setTimeout(r, 600));
    expect(await status()).toBe(200);
    await new Promise((r) => setTimeout(r, 600));
    expect(await status()).toBe(401);
  });

  it('answers a non-object booking body with a general error', async () => {
    const res = await request(newApp()).post('/api/tastings/riesling-evening/bookings').send([]);
    expect(res.status).toBe(400);
    expect(res.body.errors).toBeUndefined();
    expect(res.body.error).toBeTruthy();
  });
});
