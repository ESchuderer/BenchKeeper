import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { existsSync } from 'node:fs';
import path from 'node:path';
import express, { type NextFunction, type Request, type Response } from 'express';
import { rateLimit } from 'express-rate-limit';
import session from 'express-session';
import helmet from 'helmet';
import { bookingSchema, fieldErrors } from '../shared/booking-schema.ts';
import { createStore } from './store.ts';

export interface AppOptions {
  staffPassword?: string;
  sessionTtlMs?: number;
  /** Express "trust proxy" value, needed for Secure cookies behind a TLS-terminating proxy. */
  trustProxy?: boolean | number | string;
  /** Directory with the built client; omitted in API tests. */
  staticDir?: string;
}

declare module 'express-session' {
  interface SessionData {
    /** Sign-in time (ms), so the lifetime is fixed and not extended by use. */
    staff: number;
  }
}

const digest = (s: string) => createHash('sha256').update(s).digest();

export function createApp(opts: AppOptions = {}) {
  const { staffPassword = '', sessionTtlMs = 8 * 60 * 60 * 1000, trustProxy, staticDir } = opts;
  const store = createStore();
  const app = express();

  if (trustProxy !== undefined) app.set('trust proxy', trustProxy);
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(express.json({ limit: '10kb' }));
  app.use(
    session({
      secret: randomBytes(32).toString('hex'),
      name: 'kb.sid',
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: 'strict', secure: 'auto', maxAge: sessionTtlMs },
    }),
  );

  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    const since = req.session.staff;
    if (since !== undefined && Date.now() - since < sessionTtlMs) return next();
    res.status(401).json({ error: 'Please sign in.' });
  };

  const api = express.Router();
  api.use((_req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });

  api.get('/tastings', (_req, res) => void res.json(store.tastings()));

  api.post('/tastings/:id/bookings', (req, res) => {
    const parsed = bookingSchema.safeParse(req.body);
    if (!parsed.success) {
      const errors = fieldErrors(parsed.error);
      return void res.status(400).json(Object.keys(errors).length ? { errors } : { error: 'Invalid request.' });
    }
    const result = store.book(String(req.params.id), parsed.data);
    if ('error' in result) {
      return result.error === 'not-found'
        ? void res.status(404).json({ error: 'Tasting not found.' })
        : void res.status(409).json({ errors: { guests: result.message } });
    }
    const { booking, tasting, total } = result;
    res.status(201).json({
      reference: booking.reference,
      guests: booking.guests,
      total,
      tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt },
    });
  });

  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Too many failed attempts. Try again in 15 minutes.' },
  });

  api.post('/staff/login', loginLimiter, (req, res) => {
    const given = typeof req.body?.password === 'string' ? req.body.password : '';
    const ok = staffPassword !== '' && timingSafeEqual(digest(given), digest(staffPassword));
    if (!ok) return void res.status(401).json({ error: 'Wrong password.' });
    // New session id on sign-in prevents session fixation.
    req.session.regenerate((err) => {
      if (err) return void res.status(500).json({ error: 'Sign-in failed.' });
      req.session.staff = Date.now();
      res.status(204).end();
    });
  });

  api.post('/staff/logout', (req, res) => {
    req.session.destroy(() => {
      res.clearCookie('kb.sid').status(204).end();
    });
  });

  api.get('/staff/bookings', requireStaff, (_req, res) => void res.json(store.byTasting()));

  api.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
    res.status(store.cancel(String(req.params.reference)) ? 204 : 404).end();
  });

  api.use((_req, res) => void res.status(404).json({ error: 'Not found.' }));
  app.use('/api', api);

  if (staticDir && existsSync(staticDir)) {
    app.use(express.static(staticDir));
    app.use((req, res, next) =>
      req.method === 'GET' ? res.sendFile(path.join(staticDir, 'index.html')) : next(),
    );
  }

  app.use((err: Error & { status?: number }, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status && err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 500 ? 'Server error.' : 'Invalid request.' });
  });

  return app;
}
