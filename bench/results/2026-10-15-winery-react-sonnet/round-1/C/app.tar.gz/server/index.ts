import path from 'node:path';
import { createApp } from './app.ts';

const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');

const proxy = process.env.TRUST_PROXY;
const trustProxy = proxy === undefined ? undefined : /^\d+$/.test(proxy) ? Number(proxy) : proxy === 'true' ? true : proxy === 'false' ? false : proxy;

const port = Number(process.env.PORT) || 3000;
createApp({ staffPassword, trustProxy, staticDir: path.resolve(import.meta.dirname, '../dist') }).listen(port, () =>
  console.log(`Weingut Kieselbrunnen bookings on http://localhost:${port}`),
);
