import { randomInt } from 'node:crypto';
import { seatsMessage, type BookingInput } from '../shared/booking-schema.ts';
import { TASTINGS, type Tasting } from './tastings.ts';

export interface Booking extends BookingInput {
  reference: string;
  tastingId: string;
}

// No 0/O/1/I so references can be read out over the phone.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// shortcut: bookings live in memory and are lost on restart, move to a file or database when they must persist.
export function createStore() {
  const bookings = new Map<string, Booking>();

  const seatsLeft = (t: Tasting) => {
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === t.id) taken += b.guests;
    return t.capacity - taken;
  };
  const reference = () => {
    let ref: string;
    do {
      ref = 'KB-' + Array.from({ length: 6 }, () => ALPHABET[randomInt(ALPHABET.length)]).join('');
    } while (bookings.has(ref));
    return ref;
  };

  return {
    tastings: () => TASTINGS.map((t) => ({ ...t, seatsLeft: seatsLeft(t) })),

    /** Synchronous, so the seat check and the insert cannot interleave with another request. */
    book(tastingId: string, input: BookingInput) {
      const tasting = TASTINGS.find((t) => t.id === tastingId);
      if (!tasting) return { error: 'not-found' as const };
      const left = seatsLeft(tasting);
      if (input.guests > left) return { error: 'seats' as const, message: seatsMessage(left) };
      const booking: Booking = { ...input, reference: reference(), tastingId };
      bookings.set(booking.reference, booking);
      return { booking, tasting, total: tasting.pricePerGuest * input.guests };
    },

    cancel: (ref: string) => bookings.delete(ref),

    byTasting: () =>
      TASTINGS.map((t) => ({
        tasting: { ...t, seatsLeft: seatsLeft(t) },
        bookings: [...bookings.values()]
          .filter((b) => b.tastingId === t.id)
          .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
      })),
  };
}
