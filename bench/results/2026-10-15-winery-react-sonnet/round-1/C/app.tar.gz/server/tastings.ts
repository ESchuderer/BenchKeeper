export interface Tasting {
  id: string;
  title: string;
  /** Local winery time, "YYYY-MM-DD HH:mm". */
  startsAt: string;
  pricePerGuest: number;
  capacity: number;
}

export const TASTINGS: Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06 18:00', pricePerGuest: 25, capacity: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', pricePerGuest: 32, capacity: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05 17:00', pricePerGuest: 28, capacity: 10 },
];
