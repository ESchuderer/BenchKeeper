import { z } from 'zod';

export const MAX_GUESTS = 8;

const guestsMessage = `Enter a whole number of guests from 1 to ${MAX_GUESTS}`;

export const bookingSchema = z.object({
  name: z.string().trim().min(1, 'Enter your name').max(100, 'Use at most 100 characters'),
  email: z.string().trim().pipe(z.email('Enter a valid email address')),
  guests: z
    .number({ error: guestsMessage })
    .int(guestsMessage)
    .min(1, guestsMessage)
    .max(MAX_GUESTS, guestsMessage),
});

export type BookingInput = z.infer<typeof bookingSchema>;
export type FieldErrors = Partial<Record<keyof BookingInput, string>>;

/** First message per field. */
export function fieldErrors(error: z.ZodError): FieldErrors {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? '');
    if (key && !(key in out)) out[key] = issue.message;
  }
  return out;
}

export const seatsMessage = (seatsLeft: number) =>
  seatsLeft === 0 ? 'This tasting is fully booked' : `Only ${seatsLeft} seats left for this tasting`;
