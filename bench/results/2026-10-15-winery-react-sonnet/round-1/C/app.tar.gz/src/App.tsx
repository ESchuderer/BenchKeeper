import { useEffect } from 'react';
import { Link, Route, Routes, useLocation } from 'react-router';
import { Book } from './pages/Book.tsx';
import { Home } from './pages/Home.tsx';
import { Staff } from './pages/Staff.tsx';

function NotFound() {
  return (
    <>
      <h1>Page not found</h1>
      <p>
        <Link to="/">See the tastings</Link>
      </p>
    </>
  );
}

export function App() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <>
      <a className="skip" href="#main">
        Skip to content
      </a>
      <header className="site-header">
        <div className="wrap">
          <Link to="/" className="brand">
            Weingut Kieselbrunnen
            <span>Family winery</span>
          </Link>
        </div>
      </header>
      <main id="main" className="wrap">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/book/:id" element={<Book />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <div className="wrap">
          <span>Weingut Kieselbrunnen</span>
          <Link to="/staff">Staff</Link>
        </div>
      </footer>
    </>
  );
}
