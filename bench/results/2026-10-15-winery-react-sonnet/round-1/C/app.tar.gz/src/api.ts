import type { BookingInput, FieldErrors } from '../shared/booking-schema.ts';

export interface Tasting {
  id: string;
  title: string;
  startsAt: string;
  pricePerGuest: number;
  capacity: number;
  seatsLeft: number;
}

export interface Confirmation {
  reference: string;
  guests: number;
  total: number;
  tasting: Pick<Tasting, 'id' | 'title' | 'startsAt'>;
}

export interface StaffGroup {
  tasting: Tasting;
  bookings: { reference: string; name: string; email: string; guests: number }[];
}

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public errors?: FieldErrors,
  ) {
    super(message);
  }
}

async function call<T>(method: string, url: string, body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method,
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = res.status === 204 ? undefined : await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, data?.error ?? 'Something went wrong. Please try again.', data?.errors);
  return data as T;
}

export const api = {
  tastings: () => call<Tasting[]>('GET', '/api/tastings'),
  book: (id: string, input: BookingInput) => call<Confirmation>('POST', `/api/tastings/${id}/bookings`, input),
  staffBookings: () => call<StaffGroup[]>('GET', '/api/staff/bookings'),
  login: (password: string) => call<void>('POST', '/api/staff/login', { password }),
  logout: () => call<void>('POST', '/api/staff/logout'),
  cancel: (reference: string) => call<void>('DELETE', `/api/staff/bookings/${encodeURIComponent(reference)}`),
};
