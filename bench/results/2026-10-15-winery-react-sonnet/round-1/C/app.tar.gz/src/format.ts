const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const euro = (n: number) => `EUR ${n}`;

/** Splits the winery-local "YYYY-MM-DD HH:mm" without time zone conversion. */
export function dateParts(startsAt: string) {
  const [y, m, d] = startsAt.slice(0, 10).split('-').map(Number);
  return {
    weekday: WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()],
    day: String(d),
    month: MONTHS[m - 1],
  };
}
