import { zodResolver } from '@hookform/resolvers/zod';
import { useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useParams } from 'react-router';
import { bookingSchema, type BookingInput } from '../../shared/booking-schema.ts';
import { api, ApiError, type Confirmation, type Tasting } from '../api.ts';
import { euro } from '../format.ts';
import { useTitle } from '../useTitle.ts';

function Field({ id, label, error, children }: { id: string; label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className={`field${error ? ' field-invalid' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children}
      {error && (
        <p id={`${id}-error`} className="field-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

function Confirmed({ c }: { c: Confirmation }) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    heading.current?.focus();
  }, []);
  return (
    <section className="notice notice-success">
      <h1 ref={heading} tabIndex={-1}>
        Booking confirmed
      </h1>
      <p>Thank you. Please keep your booking reference.</p>
      <dl className="summary">
        <dt>Tasting</dt>
        <dd>
          {c.tasting.title}, <time>{c.tasting.startsAt}</time>
        </dd>
        <dt>Guests</dt>
        <dd>{c.guests === 1 ? '1 guest' : `${c.guests} guests`}</dd>
        <dt>Total price</dt>
        <dd>{euro(c.total)}</dd>
        <dt>Booking reference</dt>
        <dd className="reference">{c.reference}</dd>
      </dl>
      <Link className="button" to="/">
        Back to all tastings
      </Link>
    </section>
  );
}

export function Book() {
  const { id } = useParams();
  const [tasting, setTasting] = useState<Tasting | null | undefined>();
  const [failed, setFailed] = useState(false);
  const [confirmation, setConfirmation] = useState<Confirmation>();
  const [formError, setFormError] = useState('');
  useTitle(tasting ? `Book ${tasting.title}` : 'Book a tasting');

  const refresh = () =>
    api.tastings().then(
      (all) => setTasting(all.find((t) => t.id === id) ?? null),
      () => setFailed(true),
    );
  useEffect(() => void refresh(), [id]);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  });

  if (failed) return <p className="notice notice-error" role="alert">The tasting could not be loaded. Please reload the page.</p>;
  if (tasting === undefined) return <p role="status" className="muted">Loading...</p>;
  if (tasting === null)
    return (
      <>
        <h1>Tasting not found</h1>
        <p>
          <Link to="/">See all tastings</Link>
        </p>
      </>
    );
  if (confirmation) return <Confirmed c={confirmation} />;

  const submit = handleSubmit(async (input) => {
    setFormError('');
    try {
      setConfirmation(await api.book(tasting.id, input));
    } catch (e) {
      if (e instanceof ApiError && e.errors) {
        for (const [field, message] of Object.entries(e.errors)) {
          setError(field as keyof BookingInput, { message }, { shouldFocus: true });
        }
        if (e.status === 409) refresh();
      } else {
        setFormError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
      }
    }
  });

  const full = tasting.seatsLeft === 0;
  const described = (field: keyof BookingInput) => (errors[field] ? `${field}-error` : undefined);

  return (
    <>
      <p>
        <Link to="/">All tastings</Link>
      </p>
      <h1>Book {tasting.title}</h1>
      <p className="lede">
        <time>{tasting.startsAt}</time> &middot; {euro(tasting.pricePerGuest)} per guest &middot; {tasting.seatsLeft} seats left
      </p>
      {full && (
        <p className="notice notice-warn">
          <span className="badge">Fully booked</span> This tasting is fully booked.
        </p>
      )}
      <form className="form" onSubmit={submit} noValidate>
        {formError && (
          <p className="notice notice-error" role="alert">
            {formError}
          </p>
        )}
        <Field id="name" label="Name" error={errors.name?.message}>
          <input id="name" autoComplete="name" aria-invalid={!!errors.name} aria-describedby={described('name')} {...register('name')} />
        </Field>
        <Field id="email" label="Email" error={errors.email?.message}>
          <input
            id="email"
            type="email"
            autoComplete="email"
            aria-invalid={!!errors.email}
            aria-describedby={described('email')}
            {...register('email')}
          />
        </Field>
        <Field id="guests" label="Guests" error={errors.guests?.message}>
          <input
            id="guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={8}
            aria-invalid={!!errors.guests}
            aria-describedby={described('guests')}
            {...register('guests', { valueAsNumber: true })}
          />
        </Field>
        <button className="button" type="submit" disabled={isSubmitting}>
          Book
        </button>
      </form>
    </>
  );
}
