import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { api, type Tasting } from '../api.ts';
import { dateParts, euro } from '../format.ts';
import { useTitle } from '../useTitle.ts';

export function TastingCard({ t }: { t: Tasting }) {
  const { weekday, day, month } = dateParts(t.startsAt);
  const full = t.seatsLeft === 0;
  const taken = ((t.capacity - t.seatsLeft) / t.capacity) * 100;
  return (
    <article className={`card${full ? ' card-full' : ''}`} aria-labelledby={`t-${t.id}`}>
      <div className="stub" aria-hidden="true">
        <span>{weekday}</span>
        <strong>{day}</strong>
        <span>{month}</span>
      </div>
      <div className="card-body">
        <h2 id={`t-${t.id}`}>{t.title}</h2>
        <p className="when">
          <time>{t.startsAt}</time>
        </p>
        <p className="price">{euro(t.pricePerGuest)} per guest</p>
        <div className="seats">
          <div className="meter" aria-hidden="true">
            <span style={{ width: `${taken}%` }} />
          </div>
          <p className={t.seatsLeft <= 3 ? 'seats-low' : undefined}>
            {t.seatsLeft} seats left
            {full && <span className="badge">Fully booked</span>}
          </p>
        </div>
        <Link className={`button${full ? ' button-quiet' : ''}`} to={`/book/${t.id}`}>
          Book {t.title}
        </Link>
      </div>
    </article>
  );
}

export function Home() {
  useTitle('Wine tastings');
  const [tastings, setTastings] = useState<Tasting[]>();
  const [failed, setFailed] = useState(false);

  const load = () => {
    setFailed(false);
    api.tastings().then(setTastings, () => setFailed(true));
  };
  useEffect(load, []);

  return (
    <>
      <section className="intro">
        <h1>Book a wine tasting</h1>
        <p>Join us for a Riesling evening, a red wine cellar tour or a winter tasting. Choose a date and reserve your seats.</p>
      </section>
      {failed ? (
        <div className="notice notice-error" role="alert">
          The tastings could not be loaded.{' '}
          <button className="link" onClick={load}>
            Try again
          </button>
        </div>
      ) : !tastings ? (
        <p role="status" className="muted">
          Loading tastings...
        </p>
      ) : (
        <div className="grid">
          {tastings.map((t) => (
            <TastingCard key={t.id} t={t} />
          ))}
        </div>
      )}
    </>
  );
}
