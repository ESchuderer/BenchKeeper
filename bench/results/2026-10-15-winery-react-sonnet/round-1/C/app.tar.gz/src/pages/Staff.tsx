import { useEffect, useRef, useState, type FormEvent } from 'react';
import { api, ApiError, type StaffGroup } from '../api.ts';
import { useTitle } from '../useTitle.ts';

function SignIn({ onSignedIn }: { onSignedIn: () => void }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api.login(password);
      onSignedIn();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign-in failed.');
      setBusy(false);
    }
  };

  return (
    <form className="form" onSubmit={submit}>
      <h2>Sign in</h2>
      {error && (
        <p className="notice notice-error" role="alert">
          {error}
        </p>
      )}
      <div className="field">
        <label htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          autoComplete="current-password"
          required
          autoFocus
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <button className="button" type="submit" disabled={busy}>
        Sign in
      </button>
    </form>
  );
}

function Group({ g, onCancel }: { g: StaffGroup; onCancel: (b: StaffGroup['bookings'][number]) => void }) {
  const booked = g.tasting.capacity - g.tasting.seatsLeft;
  return (
    <section className="group" aria-labelledby={`g-${g.tasting.id}`}>
      <h2 id={`g-${g.tasting.id}`}>{g.tasting.title}</h2>
      <p className="muted">
        <time>{g.tasting.startsAt}</time> &middot; {booked} of {g.tasting.capacity} seats booked
      </p>
      {g.bookings.length === 0 ? (
        <p className="empty">No bookings yet</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Guests</th>
              <th scope="col">Reference</th>
              <th scope="col">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {g.bookings.map((b) => (
              <tr key={b.reference}>
                <td data-label="Name" id={`n-${b.reference}`}>
                  {b.name}
                </td>
                <td data-label="Email">{b.email}</td>
                <td data-label="Guests">{b.guests}</td>
                <td data-label="Reference" className="reference">
                  {b.reference}
                </td>
                <td className="actions">
                  <button className="button button-danger" aria-describedby={`n-${b.reference}`} onClick={() => onCancel(b)}>
                    Cancel
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

export function Staff() {
  useTitle('Staff');
  // undefined: checking the session, null: signed out
  const [groups, setGroups] = useState<StaffGroup[] | null>();
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const status = useRef<HTMLDivElement>(null);

  const load = () =>
    api.staffBookings().then(setGroups, (e) => {
      if (e instanceof ApiError && e.status === 401) setGroups(null);
      else setError('The bookings could not be loaded.');
    });
  useEffect(() => void load(), []);

  const cancel = async (b: StaffGroup['bookings'][number]) => {
    setMessage('');
    setError('');
    try {
      await api.cancel(b.reference);
      setMessage(`Cancelled booking ${b.reference} (${b.name}).`);
      status.current?.focus(); // the Cancel button is about to disappear
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) return setGroups(null);
      setError(e instanceof ApiError && e.status === 404 ? 'That booking was already cancelled.' : 'The booking could not be cancelled.');
    }
    load();
  };

  const signOut = async () => {
    try {
      await api.logout();
    } catch {
      return setError('Signing out failed. Please try again.');
    }
    setMessage('');
    setError('');
    setGroups(null);
  };

  return (
    <>
      <div className="staff-head">
        <h1>Staff bookings</h1>
        {groups && (
          <button className="button button-quiet" onClick={signOut}>
            Sign out
          </button>
        )}
      </div>
      {groups === undefined && !error && (
        <p role="status" className="muted">
          Loading...
        </p>
      )}
      {groups === null && <SignIn onSignedIn={load} />}
      <div role="status" tabIndex={-1} ref={status}>
        {message && <p className="notice notice-success">{message}</p>}
      </div>
      {error && (
        <p className="notice notice-error" role="alert">
          {error}
        </p>
      )}
      {groups?.map((g) => <Group key={g.tasting.id} g={g} onCancel={cancel} />)}
    </>
  );
}
