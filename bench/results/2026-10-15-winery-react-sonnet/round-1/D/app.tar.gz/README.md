# Weingut Kieselbrunnen tastings

Online tasting bookings for guests, booking list for staff.

```
npm install
npm run build
STAFF_PASSWORD=<password> npm start   # http://localhost:3000
npm test
```

| Variable | Meaning |
|---|---|
| `STAFF_PASSWORD` | Password for `/staff`. If unset, nobody can sign in. |
| `PORT` | Port, default 3000. |
| `TRUST_PROXY` | Number of reverse-proxy hops to trust (for example `1`; `true` means 1). Other values stop the start. Needed behind a TLS proxy so the session cookie gets `Secure` and the sign-in limit sees the client IP. Unset when no proxy is used. |

Bookings are kept in memory and are lost on restart. Staff sessions last 8 hours; 5 failed sign-ins per client within 15 minutes block further attempts.
