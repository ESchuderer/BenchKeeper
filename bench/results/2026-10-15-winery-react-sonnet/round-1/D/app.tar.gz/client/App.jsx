import { Link, Route, Routes } from 'react-router-dom';
import Home from './Home.jsx';
import Book from './Book.jsx';
import Staff from './Staff.jsx';

export default function App() {
  return (
    <>
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-name">Weingut Kieselbrunnen</span>
          <span className="brand-tag">Family winery, wine tastings</span>
        </Link>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/book/:id" element={<Book />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <p>Weingut Kieselbrunnen</p>
        <Link to="/staff">Staff</Link>
      </footer>
    </>
  );
}

function NotFound() {
  return (
    <section className="page">
      <h2>Page not found</h2>
      <p><Link to="/">Back to the tastings</Link></p>
    </section>
  );
}
