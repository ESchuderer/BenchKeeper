import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useParams } from 'react-router-dom';
import { bookingSchema, MAX_GUESTS } from '../shared/booking.js';
import { api } from './api.js';
import { formatPrice, formatWhen } from './format.js';
import { SeatsLeft } from './Home.jsx';
import { useTastings } from './useTastings.js';

function Field({ label, error, ...input }) {
  const id = input.name;
  return (
    <div className={`field${error ? ' field-invalid' : ''}`}>
      <label htmlFor={id}>{label}</label>
      <input id={id} aria-invalid={Boolean(error)} aria-describedby={error ? `${id}-error` : undefined} {...input} />
      {error && <p id={`${id}-error`} className="field-error" role="alert">{error}</p>}
    </div>
  );
}

// Keyed by tasting so switching between /book/a and /book/b never keeps a confirmation or form state.
export default function BookPage() {
  const { id } = useParams();
  return <Book key={id} id={id} />;
}

function Book({ id }) {
  const { tastings, error: loadError, reload } = useTastings();
  const [booking, setBooking] = useState(null);
  const {
    register, handleSubmit, setError, formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(bookingSchema), defaultValues: { name: '', email: '', guests: 1 } });

  if (loadError) return <section className="page"><p className="notice notice-error" role="alert">The tasting could not be loaded. Please reload the page.</p></section>;
  if (!tastings) return <section className="page"><p className="muted">Loading...</p></section>;
  const tasting = tastings.find((t) => t.id === id);
  if (!tasting) {
    return (
      <section className="page">
        <p className="notice notice-error" role="alert">We could not find that tasting.</p>
        <p><Link to="/">Back to the tastings</Link></p>
      </section>
    );
  }
  const { date, time } = formatWhen(tasting.startsAt);

  async function onSubmit(values) {
    if (isSubmitting) return;
    try {
      const res = await api('/api/bookings', { method: 'POST', body: { tastingId: id, ...values } });
      if (res.ok) return setBooking(res.data);
      if (res.data?.errors) {
        for (const [field, message] of Object.entries(res.data.errors)) setError(field, { message }, { shouldFocus: true });
        return reload();
      }
    } catch { /* falls through to the generic message */ }
    setError('root', { message: 'The booking could not be made. Please try again.' });
  }

  if (booking) {
    const when = formatWhen(booking.tasting.startsAt);
    return (
      <section className="page confirmation">
        <h2>Booking confirmed</h2>
        <p className="notice notice-success">Thank you, {booking.name}. We look forward to seeing you.</p>
        <dl className="summary">
          <dt>Tasting</dt><dd>{booking.tasting.title}</dd>
          <dt>Date and time</dt><dd>{when.date}, {when.time}</dd>
          <dt>Guests</dt><dd>{booking.guests}</dd>
          <dt>Total price</dt><dd>{formatPrice(booking.total)}</dd>
          <dt>Booking reference</dt><dd className="reference">{booking.reference}</dd>
        </dl>
        <p><Link to="/">Back to the tastings</Link></p>
      </section>
    );
  }

  return (
    <section className="page">
      <p><Link to="/">All tastings</Link></p>
      <h2>Book {tasting.title}</h2>
      <p className="when"><time dateTime={tasting.startsAt}>{date}, {time}</time></p>
      <p className="price">{formatPrice(tasting.pricePerGuest)} per guest</p>
      <SeatsLeft tasting={tasting} />
      {tasting.seatsLeft === 0 && (
        <p className="notice notice-error">This tasting is fully booked. Please choose another date.</p>
      )}
      <form className="form" onSubmit={handleSubmit(onSubmit)} noValidate>
        <Field label="Name" autoComplete="name" error={errors.name?.message} {...register('name')} />
        <Field label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register('email')} />
        <Field label="Guests" type="number" inputMode="numeric" min={1} max={MAX_GUESTS} error={errors.guests?.message} {...register('guests')} />
        {errors.root && <p className="notice notice-error" role="alert">{errors.root.message}</p>}
        <button type="submit" className="button" disabled={isSubmitting}>Book</button>
      </form>
    </section>
  );
}
