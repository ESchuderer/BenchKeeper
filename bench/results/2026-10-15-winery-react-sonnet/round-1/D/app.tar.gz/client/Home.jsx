import { Link } from 'react-router-dom';
import { formatPrice, formatWhen } from './format.js';
import { useTastings } from './useTastings.js';

export function SeatsLeft({ tasting }) {
  return (
    <p className="seats">
      {tasting.seatsLeft === 0 && <span className="badge badge-full">Fully booked</span>}
      <span>{tasting.seatsLeft} seats left</span>
    </p>
  );
}

export default function Home() {
  const { tastings, error } = useTastings();

  return (
    <section className="page">
      <h2>Our tastings</h2>
      <p className="lead">Book a seat at one of our upcoming tastings in the cellar and tasting room.</p>
      {error && <p className="notice notice-error" role="alert">The tastings could not be loaded. Please reload the page.</p>}
      {!tastings && !error && <p className="muted">Loading tastings...</p>}
      <div className="cards">
        {tastings?.map((t) => {
          const { date, time } = formatWhen(t.startsAt);
          return (
            <article key={t.id} className={`card${t.seatsLeft === 0 ? ' card-full' : ''}`}>
              <h3>{t.title}</h3>
              <p className="when">
                <time dateTime={t.startsAt}>{date}, {time}</time>
              </p>
              <p className="price">{formatPrice(t.pricePerGuest)} per guest</p>
              <SeatsLeft tasting={t} />
              <Link to={`/book/${t.id}`} className="button">Book {t.title}</Link>
            </article>
          );
        })}
      </div>
    </section>
  );
}
