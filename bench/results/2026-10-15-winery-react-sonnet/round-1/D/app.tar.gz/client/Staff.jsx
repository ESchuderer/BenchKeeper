import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';
import { formatWhen } from './format.js';

export default function Staff() {
  const [tastings, setTastings] = useState(null);
  const [state, setState] = useState('loading');
  const [error, setError] = useState('');
  const [password, setPassword] = useState('');

  const load = useCallback(async () => {
    try {
      const res = await api('/api/staff/bookings');
      if (res.ok) { setTastings(res.data.tastings); setState('in'); } else setState('out');
    } catch {
      setState('out');
      setError('The server could not be reached.');
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function signIn(e) {
    e.preventDefault();
    setError('');
    try {
      const res = await api('/api/staff/login', { method: 'POST', body: { password } });
      if (res.ok) { setPassword(''); return load(); }
      setError(res.data?.error ?? 'Could not sign in.');
    } catch {
      setError('The server could not be reached.');
    }
  }

  async function signOut() {
    setError('');
    await api('/api/staff/logout', { method: 'POST', body: {} }).catch(() => {});
    setTastings(null);
    setState('out');
  }

  async function cancel(reference) {
    setError('');
    const res = await api(`/api/staff/bookings/${reference}`, { method: 'DELETE' });
    if (!res.ok && res.status !== 404 && res.status !== 401) setError('The booking could not be cancelled.');
    load();
  }

  if (state === 'loading') return <section className="page"><p className="muted">Loading...</p></section>;

  if (state === 'out') {
    return (
      <section className="page narrow">
        <h2>Staff</h2>
        <form className="form" onSubmit={signIn}>
          <div className={`field${error ? ' field-invalid' : ''}`}>
            <label htmlFor="password">Password</label>
            <input
              id="password" type="password" autoComplete="current-password" value={password}
              onChange={(e) => setPassword(e.target.value)}
              aria-invalid={Boolean(error)} aria-describedby={error ? 'password-error' : undefined}
            />
            {error && <p id="password-error" className="field-error" role="alert">{error}</p>}
          </div>
          <button type="submit" className="button">Sign in</button>
        </form>
      </section>
    );
  }

  return (
    <section className="page">
      <div className="staff-head">
        <h2>Bookings</h2>
        <button type="button" className="button button-quiet" onClick={signOut}>Sign out</button>
      </div>
      {error && <p className="notice notice-error" role="alert">{error}</p>}
      {tastings.map((t) => {
        const { date, time } = formatWhen(t.startsAt);
        return (
          <section key={t.id} className="tasting-group">
            <h3>{t.title}</h3>
            <p className="muted">{date}, {time}. {t.seats - t.seatsLeft} of {t.seats} seats booked.</p>
            {t.bookings.length === 0 ? (
              <p className="empty">No bookings yet.</p>
            ) : (
              <ul className="bookings">
                {t.bookings.map((b) => (
                  <li key={b.reference}>
                    <div className="booking-main">
                      <strong>{b.name}</strong>
                      <span>{b.email}</span>
                    </div>
                    <div className="booking-meta">
                      <span>{b.guests} {b.guests === 1 ? 'guest' : 'guests'}</span>
                      <span className="reference">{b.reference}</span>
                    </div>
                    <button type="button" className="button button-danger" onClick={() => cancel(b.reference)}>Cancel</button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        );
      })}
    </section>
  );
}
