// startsAt is wall-clock time ("2026-11-06T18:00"); format it in UTC so the viewer's time zone never shifts it.
const dateFormat = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
});

export function formatWhen(startsAt) {
  const [date, time] = startsAt.split('T');
  return { date: dateFormat.format(new Date(`${date}T00:00:00Z`)), time };
}

export const formatPrice = (euros) => `EUR ${euros}`;
