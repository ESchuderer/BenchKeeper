// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { renderApp } from './test-utils.jsx';

const seed = (app, tastingId, guests) =>
  request(app).post('/api/bookings').send({ tastingId, name: 'A', email: 'a@b.de', guests });

async function fillAndBook({ name = 'Anna Weber', email = 'anna@example.com', guests = '2' } = {}) {
  const user = userEvent.setup();
  const nameField = screen.getByLabelText('Name');
  const guestsField = screen.getByLabelText('Guests');
  await user.clear(nameField);
  if (name) await user.type(nameField, name);
  await user.type(screen.getByLabelText('Email'), email);
  await user.clear(guestsField);
  if (guests) await user.type(guestsField, guests);
  await user.click(screen.getByRole('button', { name: 'Book' }));
}

describe('start page', () => {
  it('lists the tastings with date, price and seats left', async () => {
    await renderApp('/');
    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('article');
    expect(riesling).toHaveTextContent('6 November 2026');
    expect(riesling).toHaveTextContent('18:00');
    expect(riesling).toHaveTextContent('EUR 25');
    expect(riesling).toHaveTextContent('12 seats left');
    expect(screen.getByText('8 seats left')).toBeInTheDocument();
    expect(screen.getByText('10 seats left')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveAttribute('href', '/book/red-wine-cellar-tour');
  });

  it('marks a fully booked tasting', async () => {
    await renderApp('/', {
      before: async (app) => {
        await seed(app, 'winter-tasting', 8);
        await seed(app, 'winter-tasting', 2);
      },
    });
    const card = (await screen.findByRole('heading', { name: 'Winter Tasting' })).closest('article');
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(card).toHaveTextContent('0 seats left');
  });
});

describe('booking form', () => {
  it('opens from the Book link with the three fields', async () => {
    await renderApp('/');
    await userEvent.click(await screen.findByRole('link', { name: 'Book Riesling Evening' }));
    expect(await screen.findByRole('heading', { name: 'Book Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows an error next to each invalid field', async () => {
    await renderApp('/book/riesling-evening');
    await screen.findByLabelText('Name');
    await fillAndBook({ name: '', email: 'not-an-email', guests: '0' });
    expect(screen.getByLabelText('Name')).toHaveAccessibleDescription('Enter your name.');
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Enter a valid email address.');
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/from 1 to 8/);
    expect(screen.queryByText('Booking confirmed')).not.toBeInTheDocument();
  });

  it('confirms with tasting, guests, total and reference', async () => {
    await renderApp('/book/winter-tasting');
    await screen.findByLabelText('Name');
    await fillAndBook();
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const main = screen.getByRole('main');
    expect(main).toHaveTextContent('Winter Tasting');
    expect(main).toHaveTextContent('2');
    expect(main).toHaveTextContent('EUR 56');
    expect(main).toHaveTextContent(/KB-[A-Z0-9]{6}/);
  });

  it('rejects more guests than seats left', async () => {
    await renderApp('/book/red-wine-cellar-tour', { before: (app) => seed(app, 'red-wine-cellar-tour', 7) });
    await screen.findByLabelText('Name');
    await fillAndBook({ guests: '2' });
    expect(await screen.findByText('Only 1 seat is left.')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Only 1 seat is left.');
    expect(screen.queryByText('Booking confirmed')).not.toBeInTheDocument();
  });

  it('says so for an unknown tasting', async () => {
    await renderApp('/book/nope');
    expect(await screen.findByText(/could not find that tasting/i)).toBeInTheDocument();
  });
});
