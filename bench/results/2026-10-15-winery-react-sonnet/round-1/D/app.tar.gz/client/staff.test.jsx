// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { PASSWORD, renderApp } from './test-utils.jsx';

const seed = async (app) => {
  const post = (tastingId, name, guests) =>
    request(app).post('/api/bookings').send({ tastingId, name, email: `${name.toLowerCase()}@example.com`, guests });
  await post('riesling-evening', 'Anna', 3);
  await post('winter-tasting', 'Bob', 2);
};

async function signIn(password = PASSWORD) {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
  return user;
}

describe('staff page', () => {
  it('asks for the password and hides bookings until signed in', async () => {
    await renderApp('/staff', { before: seed });
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
  });

  it('shows an error for a wrong password', async () => {
    await renderApp('/staff', { before: seed });
    await signIn('wrong');
    expect(await screen.findByText('Wrong password.')).toBeInTheDocument();
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument();
  });

  it('lists bookings grouped by tasting', async () => {
    await renderApp('/staff', { before: seed });
    await signIn();
    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section');
    expect(riesling).toHaveTextContent('Anna');
    expect(riesling).toHaveTextContent('anna@example.com');
    expect(riesling).toHaveTextContent(/KB-[A-Z0-9]{6}/);
    expect(riesling).not.toHaveTextContent('Bob');
    const winter = screen.getByRole('heading', { name: 'Winter Tasting' }).closest('section');
    expect(winter).toHaveTextContent('Bob');
    const red = screen.getByRole('heading', { name: 'Red Wine Cellar Tour' }).closest('section');
    expect(red).toHaveTextContent('No bookings yet.');
  });

  it('cancels a booking and frees its seats', async () => {
    const { agent } = await renderApp('/staff', { before: seed });
    const user = await signIn();
    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section');
    expect((await agent.get('/api/tastings')).body[0].seatsLeft).toBe(9);
    await user.click(within(riesling).getByRole('button', { name: 'Cancel' }));
    expect(await within(riesling).findByText('No bookings yet.')).toBeInTheDocument();
    expect((await agent.get('/api/tastings')).body[0].seatsLeft).toBe(12);
  });

  it('signs out', async () => {
    const { agent } = await renderApp('/staff', { before: seed });
    const user = await signIn();
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect((await agent.get('/api/staff/bookings')).status).toBe(401);
  });
});
