import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import request from 'supertest';
import { vi } from 'vitest';
import { createApp } from '../server/app.js';
import App from './App.jsx';

export const PASSWORD = 'secret-pw';

// Routes fetch() calls to a real in-process server, with a cookie jar, so the UI is tested against the real API.
// `before(app)` runs before the first render, e.g. to seed bookings.
export async function renderApp(path = '/', { before, ...options } = {}) {
  const app = createApp({ staffPassword: PASSWORD, ...options });
  await before?.(app);
  const agent = request.agent(app);
  vi.stubGlobal('fetch', async (url, { method = 'GET', body } = {}) => {
    let req = agent[method.toLowerCase()](url);
    if (body) req = req.type('json').send(body);
    const res = await req;
    return { ok: res.status < 400, status: res.status, json: async () => res.body };
  });
  render(<MemoryRouter initialEntries={[path]}><App /></MemoryRouter>);
  return { app, agent };
}
