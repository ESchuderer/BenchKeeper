import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';

export function useTastings() {
  const [tastings, setTastings] = useState(null);
  const [error, setError] = useState(false);

  const reload = useCallback(async () => {
    try {
      const res = await api('/api/tastings');
      if (!res.ok) throw new Error();
      setTastings(res.data);
      setError(false);
    } catch {
      setError(true);
    }
  }, []);

  useEffect(() => { reload(); }, [reload]);

  return { tastings, error, reload };
}
