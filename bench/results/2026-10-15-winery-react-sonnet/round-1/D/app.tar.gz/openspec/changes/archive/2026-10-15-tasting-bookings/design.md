# Design

## Context

Greenfield project, Node.js 22, npm, one service. See proposal.md for scope. Bookings are kept in memory; the app starts empty.

## Goals / Non-Goals

**Goals:**
- One process serves the built React app and the JSON API.
- The server is the only authority for seat counts, validation and prices.

**Non-Goals:**
- Payments, email sending, guest self-service cancellation, editing tastings, multiple staff accounts, persistence across restarts.
- Past-date handling: all seeded tastings are in the future.

## Decisions

- **Server: Express 5 + helmet.** Established, small surface. CSP default minus `upgrade-insecure-requests` so plain-HTTP deployments keep working.
- **Client: React 19 + Vite + React Router.** Routes `/`, `/book/:id`, `/staff`. Vite builds into `dist/client`; Express serves it and falls back to `index.html` for non-`/api` GET requests.
- **Validation: one zod schema in `shared/`**, used by react-hook-form (via `@hookform/resolvers`) and by the server. The server adds the seat check and returns `400 {errors: {field: message}}`; the client maps these onto the fields with `setError`. Forms use `noValidate` so the app's messages show instead of browser bubbles.
- **Seat integrity:** booking is a single synchronous function over the in-memory store (check seats, push booking). Node's single thread makes it atomic. Alternative (database transactions) rejected: no database.
- **Seats left** is derived (`seats - sum(guests)`), never stored, so cancel needs no bookkeeping.
- **Money:** whole euros as integers; display "EUR <n>".
- **Dates:** stored and displayed as local wall-clock strings (`2026-11-06T18:00`), formatted without `Date` time-zone conversion.
- **Reference:** `KB-` plus 6 characters from an unambiguous alphabet via `crypto.randomInt`; retried on collision.
- **Staff auth:** `express-session` (server-side store, so sign-out revokes), cookie HttpOnly, SameSite=Strict, `secure: 'auto'`, maxAge 8 h. Password compared with `crypto.timingSafeEqual` over SHA-256 digests. Unset or empty `STAFF_PASSWORD` fails closed. `express-rate-limit` on `POST /api/staff/login`: 5 failures per 15 min per IP (`skipSuccessfulRequests`, but a blocked client is blocked for correct passwords too). `TRUST_PROXY` env (hop count) enables `trust proxy` so `Secure` and client IP work behind a TLS proxy; off by default because `X-Forwarded-*` is spoofable otherwise.
- **CSRF:** SameSite=Strict cookie plus JSON-only mutation endpoints (a cross-site form post cannot send `application/json`).
- **Styling:** hand-written CSS with custom properties, mobile-first, no external fonts or assets (no external services).
- **Tests:** Vitest. Server API tests with supertest against `createApp()` (fresh store per test). Component tests with Testing Library. Browser verification with Playwright MCP.
- **Fully booked:** shown as a badge; the "Book <title>" link and form stay reachable and the server rejects the booking (keeps behavior uniform). The seat count text always reads "<n> seats left" exactly as specified, including "1 seats left".

## Risks / Trade-offs

- In-memory bookings are lost on restart → documented; swap the store module for a file or database if needed.
- Rate limit and sessions are per process → fine for a single instance.
- Session store is the default memory store (warns about leaks in production) → acceptable for one staff password; sessions are created only after sign-in, so anonymous traffic creates none (`saveUninitialized: false`).
- Immediate cancel with no confirmation step → matches the requested single "Cancel" button.
