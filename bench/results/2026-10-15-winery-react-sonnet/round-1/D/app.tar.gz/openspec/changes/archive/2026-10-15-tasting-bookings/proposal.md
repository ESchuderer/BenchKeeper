# Proposal

## Why

Weingut Kieselbrunnen takes tasting bookings without a shared, live view of free seats. Guests need to book online and see what is left; staff need one list of who is coming.

## What Changes

- Public web app: tasting list with date, time, price per guest and seats left; booking form per tasting; booking confirmation with reference.
- Seat limits enforced on the server: a booking never takes more seats than are left.
- Password-protected `/staff` page: bookings grouped by tasting, cancel a booking to free its seats.
- Three tastings are seeded from the winery's schedule; bookings start empty and are kept in memory.
- Single Node.js 22 service serving the React interface and a JSON API on `PORT` (default 3000).

## Capabilities

### New Capabilities
- `tasting-booking`: guests list tastings, book seats, receive a confirmation; validation and seat limits.
- `staff-access`: staff sign-in with a shared password from `STAFF_PASSWORD`, session expiry, sign-out, failed-attempt limit, cookie flags.
- `staff-bookings`: staff view bookings grouped by tasting and cancel a booking.

### Modified Capabilities

## Impact

- New project: Node.js 22, Express, React, Vite, npm scripts `build`, `start`, `test`.
- No external services, no database. Environment: `STAFF_PASSWORD`, `PORT`, optional `TRUST_PROXY`.
