# Spec Delta

## Purpose

Restricts the staff area to people who know the staff password, with limits that make guessing the password and reusing a session impractical.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL show a "Password" field and a "Sign in" button to visitors who are not signed in. The correct password is the value of the environment variable `STAFF_PASSWORD`. No booking data is returned to visitors who are not signed in.

#### Scenario: Correct password
- **WHEN** a visitor enters the value of `STAFF_PASSWORD` and presses "Sign in"
- **THEN** the bookings view is shown

#### Scenario: Wrong password
- **WHEN** a visitor enters another password
- **THEN** an error message is shown and the bookings view stays hidden

#### Scenario: Not signed in
- **WHEN** a request for the staff bookings is made without a session
- **THEN** it is rejected with status 401 and contains no booking data

#### Scenario: Password not configured
- **WHEN** `STAFF_PASSWORD` is unset or empty
- **THEN** no password signs in

### Requirement: Sign-out
A signed-in staff member SHALL be able to sign out with a "Sign out" button, which ends the session so that the previous session cookie no longer grants access.

#### Scenario: Sign out
- **WHEN** a signed-in staff member presses "Sign out"
- **THEN** the sign-in form is shown and the former session cookie is rejected

### Requirement: Session expiry
A staff session SHALL expire 8 hours after sign-in.

#### Scenario: Expired session
- **WHEN** a session is older than 8 hours
- **THEN** staff requests with it are rejected with status 401

### Requirement: Failed attempt limit
The system SHALL allow at most 5 failed sign-in attempts per client within 15 minutes and then reject further sign-in attempts, including correct ones, with status 429 until the window ends.

#### Scenario: Too many failures
- **WHEN** a client makes 5 failed sign-in attempts and then a sixth attempt
- **THEN** the sixth attempt gets status 429

### Requirement: Session cookie flags
The session cookie SHALL be HttpOnly and SameSite=Strict, and SHALL be Secure when the request was made over HTTPS.

#### Scenario: Cookie flags over HTTPS
- **WHEN** a staff member signs in over HTTPS
- **THEN** the Set-Cookie header contains HttpOnly, SameSite=Strict and Secure
