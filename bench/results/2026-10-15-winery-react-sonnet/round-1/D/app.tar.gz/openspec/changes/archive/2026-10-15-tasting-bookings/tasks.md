# Tasks

## 1. Project scaffold

- [x] 1.1 Create `package.json` (ESM, scripts `build`, `start`, `test`), install dependencies, `.gitignore`; verify `npm install` succeeds and `npm run build` runs against a placeholder page
- [x] 1.2 Add `shared/booking.js` (zod schema, limits) and its unit test; verify `npm test` passes

## 2. Booking API

- [x] 2.1 Write failing tests for tastings, booking, validation, seat limit, cancel-frees-seats (`server/app.test.js`); verify they fail
- [x] 2.2 Implement `server/store.js` and `server/app.js` public routes; verify tests pass

## 3. Staff access and bookings API

- [x] 3.1 Write failing tests for sign-in, 401 without session, sign-out, expiry, rate limit, cookie flags, grouped list, cancel; verify they fail
- [x] 3.2 Implement session, rate limit and staff routes; verify tests pass

## 4. Guest interface

- [x] 4.1 Write component tests for tasting list, booking form errors and confirmation; verify they fail
- [x] 4.2 Implement start page, booking form, confirmation, layout and styles (mobile-first); verify tests pass

## 5. Staff interface

- [x] 5.1 Write component tests for sign-in, grouped list, cancel, sign-out; verify they fail
- [x] 5.2 Implement `/staff` page; verify tests pass

## 6. Integration

- [x] 6.1 Add `server/index.js` (PORT, STAFF_PASSWORD warning, static serving, SPA fallback) and README; verify `npm run build && STAFF_PASSWORD=x npm start` serves the app
- [x] 6.2 Verify full flow in a browser with Playwright MCP at desktop and phone width (book, overbook, fully booked, staff sign-in, cancel); verify `npm test` passes

## Workflow follow-up

- Review the branch diff for correctness and security before reporting done.
- Archive the change on the branch with `openspec-archive-change`.
