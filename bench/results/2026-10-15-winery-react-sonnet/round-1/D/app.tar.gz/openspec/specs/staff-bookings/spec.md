# staff-bookings Specification

## Purpose
Gives staff one view of all bookings per tasting and lets them cancel a booking so that its seats become available again.

## Requirements

### Requirement: Bookings grouped by tasting
A signed-in staff member SHALL see all bookings grouped under their tasting, each with name, email, number of guests and booking reference. A tasting without bookings is shown with an empty-state message.

#### Scenario: Grouped list
- **WHEN** bookings exist for Riesling Evening and Winter Tasting
- **THEN** each booking is listed under its tasting with name, email, guests and reference

#### Scenario: No bookings
- **WHEN** a tasting has no bookings
- **THEN** its group shows that there are no bookings

### Requirement: Cancel a booking
Each listed booking SHALL have a "Cancel" button that removes the booking and frees its seats.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 3 guests for Riesling Evening that left 9 seats
- **THEN** the booking disappears from the list and the start page shows "12 seats left"

#### Scenario: Cancel requires sign-in
- **WHEN** a cancel request is made without a staff session
- **THEN** it is rejected with status 401 and the booking stays
