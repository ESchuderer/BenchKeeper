# tasting-booking Specification

## Purpose
Lets guests see the available wine tastings and book seats online, with seat limits enforced so that no tasting is overbooked.

## Requirements

### Requirement: Tasting list
The start page SHALL list every tasting with its title, date and time, price per guest and seats left, shown as "<n> seats left".

#### Scenario: Initial state
- **WHEN** a guest opens the start page and no bookings exist
- **THEN** the page shows Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats left), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats left) and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats left)

#### Scenario: Seats left update
- **WHEN** a booking of 3 guests is made for Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening

### Requirement: Fully booked state
A tasting with no seats left SHALL be marked "Fully booked" on the start page and on its booking page.

#### Scenario: Last seats taken
- **WHEN** the seats left of a tasting reach 0
- **THEN** the tasting is marked "Fully booked" and the booking form still rejects any booking for it

### Requirement: Booking entry point
Each tasting SHALL offer a link "Book <tasting title>" that opens a booking form for that tasting with fields "Name", "Email" and "Guests" and a button "Book".

#### Scenario: Open the form
- **WHEN** a guest follows "Book Riesling Evening"
- **THEN** a form for Riesling Evening opens with the fields "Name", "Email", "Guests" and the button "Book"

### Requirement: Booking input validation
The system SHALL reject a booking with a missing name, an invalid email address, or a guest count that is not a whole number from 1 to 8, and SHALL show the error message next to the field it concerns. No booking is created and no seats are taken.

#### Scenario: Invalid fields
- **WHEN** a guest submits an empty Name, the Email "not-an-email" and Guests 0
- **THEN** an error message is shown next to each of the three fields and no booking exists

#### Scenario: Guests above the limit
- **WHEN** a guest submits Guests 9
- **THEN** an error message is shown next to Guests

### Requirement: Seat limit
The system SHALL reject a booking whose guest count exceeds the seats left of the tasting, show the error next to Guests, and leave the seats left unchanged. This holds for concurrent requests.

#### Scenario: More guests than seats
- **WHEN** 7 guests are booked for Red Wine Cellar Tour (8 seats) and a further booking of 2 is submitted
- **THEN** the second booking is rejected with an error next to Guests and the page shows "1 seats left"

#### Scenario: Exactly the remaining seats
- **WHEN** 1 seat is left and a booking of 1 guest is submitted
- **THEN** the booking is accepted and the tasting becomes fully booked

### Requirement: Booking confirmation
After a successful booking the guest SHALL see the heading "Booking confirmed", the tasting, the number of guests, the total price (guests times price per guest) and a booking reference unique to the booking.

#### Scenario: Confirmation content
- **WHEN** a guest books 2 guests for Winter Tasting
- **THEN** the page shows "Booking confirmed", Winter Tasting, 2 guests, a total of EUR 56 and a booking reference
