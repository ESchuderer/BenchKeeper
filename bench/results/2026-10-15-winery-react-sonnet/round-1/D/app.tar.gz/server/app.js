import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import path from 'node:path';
import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import { rateLimit } from 'express-rate-limit';
import { fieldErrors, bookingSchema } from '../shared/booking.js';
import { createStore } from './store.js';
import { TASTINGS } from './tastings.js';

const digest = (s) => createHash('sha256').update(s).digest();

export function createApp({
  staffPassword,
  tastings = TASTINGS,
  sessionMaxAgeMs = 8 * 60 * 60 * 1000,
  trustProxy = false,
  staticDir,
} = {}) {
  const store = createStore(tastings);
  const app = express();
  app.set('trust proxy', trustProxy);
  app.disable('x-powered-by');
  app.use(helmet({ contentSecurityPolicy: { directives: { 'upgrade-insecure-requests': null } } }));
  app.use(express.json({ limit: '10kb' }));

  // Mutations are JSON only: with SameSite=Strict this keeps cross-site form posts out.
  app.use('/api', (req, res, next) =>
    req.method === 'POST' && !req.is('json') ? res.status(415).json({ error: 'Send JSON.' }) : next());

  app.use(session({
    name: 'kb.sid',
    secret: randomBytes(32).toString('hex'),
    resave: false,
    saveUninitialized: false,
    // shortcut: default in-memory session store, one process only; use a shared store to scale out.
    cookie: { httpOnly: true, sameSite: 'strict', secure: 'auto', maxAge: sessionMaxAgeMs },
  }));

  app.use('/api/staff', (req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

  const requireStaff = (req, res, next) => (req.session.staff ? next() : res.status(401).json({ error: 'Sign in required.' }));

  const loginLimit = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Too many failed attempts. Try again in 15 minutes.' },
  });

  app.get('/api/tastings', (req, res) => res.json(store.tastings()));

  app.post('/api/bookings', (req, res) => {
    const { tastingId, ...input } = req.body ?? {};
    const errors = fieldErrors(input);
    if (Object.keys(errors).length) return res.status(400).json({ errors });
    const result = store.book(String(tastingId), bookingSchema.parse(input));
    if (result.notFound) return res.status(404).json({ error: 'Unknown tasting.' });
    if (result.errors) return res.status(400).json({ errors: result.errors });
    res.status(201).json(result.booking);
  });

  app.post('/api/staff/login', loginLimit, (req, res, next) => {
    const { password } = req.body ?? {};
    const valid = Boolean(staffPassword) && typeof password === 'string'
      && timingSafeEqual(digest(password), digest(staffPassword));
    if (!valid) return res.status(401).json({ error: 'Wrong password.' });
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.staff = true;
      req.session.save((err2) => (err2 ? next(err2) : res.status(204).end()));
    });
  });

  app.post('/api/staff/logout', (req, res, next) =>
    req.session.destroy((err) => {
      if (err) return next(err);
      res.clearCookie('kb.sid').status(204).end();
    }));

  app.get('/api/staff/bookings', requireStaff, (req, res) => res.json({ tastings: store.bookingsByTasting() }));

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) =>
    res.status(store.cancel(req.params.reference) ? 204 : 404).end());

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

  if (staticDir) {
    app.use(express.static(staticDir));
    // Pages fall back to the app shell; a missing file (path with an extension) stays a 404.
    app.use((req, res, next) =>
      (req.method === 'GET' || req.method === 'HEAD') && !path.extname(req.path)
        ? res.sendFile(path.resolve(staticDir, 'index.html')) : next());
  }

  app.use((err, req, res, next) => {
    if (err.status && err.status < 500) return res.status(err.status).json({ error: 'Bad request.' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong.' });
  });

  return app;
}
