import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from './app.js';

const PASSWORD = 'secret-pw';
const guest = { name: 'Anna', email: 'anna@example.com', guests: 2 };
const book = (app, id, body = guest) => request(app).post('/api/bookings').send({ tastingId: id, ...body });
const seatsLeft = async (app, id) =>
  (await request(app).get('/api/tastings')).body.find((t) => t.id === id).seatsLeft;

async function signedIn(app) {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(204);
  return agent;
}

describe('tastings', () => {
  it('lists the three tastings with full seats', async () => {
    const { body } = await request(createApp({ staffPassword: PASSWORD })).get('/api/tastings').expect(200);
    expect(body.map((t) => [t.title, t.startsAt, t.pricePerGuest, t.seatsLeft])).toEqual([
      ['Riesling Evening', '2026-11-06T18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14T15:00', 32, 8],
      ['Winter Tasting', '2026-12-05T17:00', 28, 10],
    ]);
  });
});

describe('booking', () => {
  it('confirms with tasting, guests, total and a reference, and takes the seats', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const { body } = await book(app, 'winter-tasting').expect(201);
    expect(body).toMatchObject({ guests: 2, total: 56, tasting: { title: 'Winter Tasting' } });
    expect(body.reference).toMatch(/^KB-[A-Z0-9]{6}$/);
    expect(await seatsLeft(app, 'winter-tasting')).toBe(8);
  });

  it('gives each booking a different reference', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const refs = new Set();
    for (let i = 0; i < 5; i++) refs.add((await book(app, 'riesling-evening', { ...guest, guests: 1 })).body.reference);
    expect(refs.size).toBe(5);
  });

  it('rejects invalid fields with an error per field and takes no seats', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const { body } = await book(app, 'riesling-evening', { name: '', email: 'nope', guests: 0 }).expect(400);
    expect(Object.keys(body.errors).sort()).toEqual(['email', 'guests', 'name']);
    expect(await seatsLeft(app, 'riesling-evening')).toBe(12);
  });

  it('rejects 9 guests', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const { body } = await book(app, 'riesling-evening', { ...guest, guests: 9 }).expect(400);
    expect(body.errors).toHaveProperty('guests');
  });

  it('rejects more guests than seats left, accepts exactly the rest', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    await book(app, 'red-wine-cellar-tour', { ...guest, guests: 7 }).expect(201);
    const { body } = await book(app, 'red-wine-cellar-tour').expect(400);
    expect(body.errors.guests).toMatch(/1 seat/);
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(1);
    await book(app, 'red-wine-cellar-tour', { ...guest, guests: 1 }).expect(201);
    await book(app, 'red-wine-cellar-tour', { ...guest, guests: 1 }).expect(400);
  });

  it('never overbooks under concurrent requests', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const results = await Promise.all(Array.from({ length: 10 }, () => book(app, 'red-wine-cellar-tour')));
    expect(results.filter((r) => r.status === 201)).toHaveLength(4);
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(0);
  });

  it('rejects guests that are not a plain number', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    for (const guests of [true, '0x3', [2]]) {
      await book(app, 'riesling-evening', { ...guest, guests }).expect(400);
    }
    expect(await seatsLeft(app, 'riesling-evening')).toBe(12);
  });

  it('serves the app shell for pages but 404 for missing assets', async () => {
    const staticDir = mkdtempSync(path.join(tmpdir(), 'kb-'));
    writeFileSync(path.join(staticDir, 'index.html'), '<div id="root"></div>');
    const app = createApp({ staffPassword: PASSWORD, staticDir });
    await request(app).get('/staff').expect(200).expect(/root/);
    await request(app).head('/staff').expect(200);
    await request(app).get('/assets/nope.js').expect(404);
  });

  it('marks staff responses no-store', async () => {
    const res = await request(createApp({ staffPassword: PASSWORD })).get('/api/staff/bookings');
    expect(res.headers['cache-control']).toBe('no-store');
  });

  it('404 for an unknown tasting', async () => {
    await book(createApp({ staffPassword: PASSWORD }), 'nope').expect(404);
  });

  it('415 for a non-JSON body', async () => {
    await request(createApp({ staffPassword: PASSWORD }))
      .post('/api/bookings').type('form').send('name=x').expect(415);
  });
});

describe('staff access', () => {
  it('rejects staff routes without a session', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    await book(app, 'winter-tasting');
    const res = await request(app).get('/api/staff/bookings').expect(401);
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
    await request(app).delete('/api/staff/bookings/KB-AAAAAA').expect(401);
  });

  it('rejects a wrong password and signs in with the right one', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    await request(app).post('/api/staff/login').send({}).expect(401);
    await signedIn(app);
  });

  it('fails closed when no password is configured', async () => {
    for (const staffPassword of [undefined, '']) {
      const app = createApp({ staffPassword });
      await request(app).post('/api/staff/login').send({ password: '' }).expect(401);
      await request(app).post('/api/staff/login').send({ password: 'undefined' }).expect(401);
    }
  });

  it('sign-out ends the session', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const agent = request.agent(app);
    const login = await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(204);
    const cookie = login.headers['set-cookie'][0].split(';')[0];
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);
    await agent.post('/api/staff/logout').send({}).expect(204);
    await agent.get('/api/staff/bookings').expect(401);
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(401);
  });

  it('expires the session', async () => {
    const app = createApp({ staffPassword: PASSWORD, sessionMaxAgeMs: 400 });
    // Send the cookie by hand: the client's own cookie jar would drop it after rounding Expires to whole seconds.
    const login = await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(204);
    const cookie = login.headers['set-cookie'][0].split(';')[0];
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);
    await new Promise((r) => setTimeout(r, 600));
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(401);
  });

  it('blocks after 5 failed attempts, even for the right password', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    for (let i = 0; i < 5; i++) await request(app).post('/api/staff/login').send({ password: 'x' }).expect(401);
    await request(app).post('/api/staff/login').send({ password: 'x' }).expect(429);
    await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(429);
  });

  it('sets HttpOnly, SameSite=Strict and Secure over HTTPS', async () => {
    const app = createApp({ staffPassword: PASSWORD, trustProxy: 1 });
    const res = await request(app).post('/api/staff/login').set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD }).expect(204);
    const cookie = res.headers['set-cookie'][0];
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    expect(cookie).toMatch(/Secure/i);
  });

  it('omits Secure over plain HTTP', async () => {
    const res = await request(createApp({ staffPassword: PASSWORD }))
      .post('/api/staff/login').send({ password: PASSWORD }).expect(204);
    expect(res.headers['set-cookie'][0]).not.toMatch(/Secure/i);
  });
});

describe('staff bookings', () => {
  it('groups bookings by tasting, including empty tastings', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    await book(app, 'winter-tasting', { name: 'Bob', email: 'bob@example.com', guests: 3 });
    const agent = await signedIn(app);
    const { body } = await agent.get('/api/staff/bookings').expect(200);
    expect(body.tastings.map((t) => t.bookings.length)).toEqual([0, 0, 1]);
    expect(body.tastings[2].bookings[0]).toMatchObject({ name: 'Bob', email: 'bob@example.com', guests: 3 });
    expect(body.tastings[2].bookings[0].reference).toMatch(/^KB-/);
  });

  it('cancel removes the booking and frees its seats', async () => {
    const app = createApp({ staffPassword: PASSWORD });
    const { reference } = (await book(app, 'riesling-evening', { ...guest, guests: 3 })).body;
    expect(await seatsLeft(app, 'riesling-evening')).toBe(9);
    const agent = await signedIn(app);
    await agent.delete(`/api/staff/bookings/${reference}`).expect(204);
    expect(await seatsLeft(app, 'riesling-evening')).toBe(12);
    await agent.delete(`/api/staff/bookings/${reference}`).expect(404);
  });
});
