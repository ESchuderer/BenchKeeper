import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';

const { STAFF_PASSWORD, PORT = 3000, TRUST_PROXY } = process.env;
if (!STAFF_PASSWORD) console.warn('STAFF_PASSWORD is not set: nobody can sign in to /staff.');

// "true" means one proxy hop; anything else that is not a hop count stops the start instead of silently dropping Secure.
let trustProxy = false;
if (TRUST_PROXY) {
  trustProxy = TRUST_PROXY === 'true' ? 1 : /^\d+$/.test(TRUST_PROXY) ? Number(TRUST_PROXY) : NaN;
  if (Number.isNaN(trustProxy)) {
    console.error('TRUST_PROXY must be a number of proxy hops, for example 1.');
    process.exit(1);
  }
}

const app = createApp({
  staffPassword: STAFF_PASSWORD,
  trustProxy,
  staticDir: path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist'),
});

app.listen(Number(PORT), () => console.log(`Listening on port ${PORT}`));
