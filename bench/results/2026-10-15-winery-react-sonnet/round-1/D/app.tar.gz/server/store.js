import { randomInt } from 'node:crypto';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// shortcut: bookings live in memory and are lost on restart, replace this module to persist them.
export function createStore(tastings) {
  const bookings = [];

  const taken = (tastingId) => bookings.filter((b) => b.tastingId === tastingId).reduce((n, b) => n + b.guests, 0);
  const view = (t) => ({ ...t, seatsLeft: t.seats - taken(t.id) });

  function newReference() {
    let ref;
    do {
      ref = 'KB-' + Array.from({ length: 6 }, () => ALPHABET[randomInt(ALPHABET.length)]).join('');
    } while (bookings.some((b) => b.reference === ref));
    return ref;
  }

  return {
    tastings: () => tastings.map(view),
    // Synchronous, so the seat check and the insert cannot interleave with another request.
    book(tastingId, { name, email, guests }) {
      const tasting = tastings.find((t) => t.id === tastingId);
      if (!tasting) return { notFound: true };
      const left = view(tasting).seatsLeft;
      if (guests > left) {
        return { errors: { guests: left === 0 ? 'This tasting is fully booked.' : `Only ${left} ${left === 1 ? 'seat is' : 'seats are'} left.` } };
      }
      const booking = { reference: newReference(), tastingId, name, email, guests };
      bookings.push(booking);
      const { id, title, startsAt, pricePerGuest } = tasting;
      return { booking: { reference: booking.reference, name, email, guests, total: guests * pricePerGuest, tasting: { id, title, startsAt } } };
    },
    bookingsByTasting: () =>
      tastings.map((t) => ({
        ...view(t),
        bookings: bookings.filter((b) => b.tastingId === t.id).map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
      })),
    cancel(reference) {
      const i = bookings.findIndex((b) => b.reference === reference);
      if (i < 0) return false;
      bookings.splice(i, 1);
      return true;
    },
  };
}
