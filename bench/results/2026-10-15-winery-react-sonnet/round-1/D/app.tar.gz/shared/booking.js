import { z } from 'zod';

export const MAX_GUESTS = 8;
const guestsMessage = `Enter a whole number of guests from 1 to ${MAX_GUESTS}.`;

export const bookingSchema = z.object({
  name: z.string().trim().min(1, 'Enter your name.').max(100, 'Name is too long.'),
  email: z.string().trim().max(254, 'Email is too long.').pipe(z.email('Enter a valid email address.')),
  // Only a number or a string of digits: z.coerce would also accept true, "0x3", "1e0" and [2].
  guests: z.preprocess(
    (v) => (typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : v),
    z.number({ error: guestsMessage }).int(guestsMessage).min(1, guestsMessage).max(MAX_GUESTS, guestsMessage),
  ),
});

// First message per field, e.g. { email: 'Enter a valid email address.' }; {} when valid.
export function fieldErrors(input) {
  const result = bookingSchema.safeParse(input);
  const errors = {};
  if (!result.success) {
    for (const issue of result.error.issues) errors[issue.path[0] ?? 'form'] ??= issue.message;
  }
  return errors;
}
