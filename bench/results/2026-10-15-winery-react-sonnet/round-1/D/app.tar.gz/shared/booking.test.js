import { describe, expect, it } from 'vitest';
import { bookingSchema, fieldErrors } from './booking.js';

const ok = { name: 'Anna', email: 'anna@example.com', guests: 2 };

describe('bookingSchema', () => {
  it('accepts valid input and coerces guests from a string', () => {
    expect(bookingSchema.parse({ ...ok, guests: '2' })).toEqual(ok);
  });

  it('trims the name', () => {
    expect(bookingSchema.parse({ ...ok, name: '  Anna ' }).name).toBe('Anna');
  });

  it.each([0, 9, 1.5, '', 'x', null, true, '0x3', '1e0', ' 3 ', [2]])('rejects guests %j', (guests) => {
    expect(fieldErrors({ ...ok, guests })).toHaveProperty('guests');
  });

  it.each([1, 8])('accepts guests %j', (guests) => {
    expect(fieldErrors({ ...ok, guests })).toEqual({});
  });

  it('rejects empty name and bad email, each under its own field', () => {
    const errors = fieldErrors({ name: ' ', email: 'not-an-email', guests: 1 });
    expect(Object.keys(errors).sort()).toEqual(['email', 'name']);
  });

  it('rejects non-object input', () => {
    expect(Object.keys(fieldErrors(undefined)).length).toBeGreaterThan(0);
  });
});
