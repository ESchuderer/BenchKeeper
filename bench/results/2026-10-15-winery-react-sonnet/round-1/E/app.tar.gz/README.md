# Weingut Kieselbrunnen tastings

Online tasting bookings for guests and a booking list for staff. React front end (Vite, React Router, react-hook-form, Tailwind CSS), Express server, bookings held in memory (lost on restart).

## Run

```
npm install
npm run build
STAFF_PASSWORD=<password> npm start
```

Serves the app and API on `PORT` (default 3000).

| Variable | Purpose |
|---|---|
| `STAFF_PASSWORD` | Password for `/staff`. If unset or empty, staff sign-in is disabled. |
| `PORT` | Port to listen on, default 3000. |
| `TRUST_PROXY` | Number of reverse proxies in front of the app (for example `1`). Needed so the session cookie is `Secure` over HTTPS and the sign-in limit sees client IPs. |

Staff sign-in allows 5 failed attempts per 15 minutes per IP; sessions end after 2 hours of inactivity.

## Test

```
npm test            # unit and API tests with coverage
npm run build && npm run test:e2e   # browser tests (Playwright, starts the built app on port 3100)
npm run typecheck
```

Set `CHROMIUM_PATH` to use an existing Chromium binary for the browser tests.
