import { expect, test } from '@playwright/test';
import { STAFF_PASSWORD, bookViaApi, cancelAllBookings, fillBooking } from './helpers';

test.afterEach(async ({ request }) => {
  await cancelAllBookings(request);
});

test('start page lists the tastings with date, price, and seats left', async ({ page }) => {
  await page.goto('/');
  const cards = page.getByRole('article');
  await expect(cards).toHaveCount(3);
  await expect(cards.nth(0)).toContainText('Riesling Evening');
  await expect(cards.nth(0)).toContainText('2026-11-06 18:00');
  await expect(cards.nth(0)).toContainText('EUR 25');
  await expect(cards.nth(0)).toContainText('12 seats left');
  await expect(cards.nth(1)).toContainText('Red Wine Cellar Tour');
  await expect(cards.nth(1)).toContainText('2026-11-14 15:00');
  await expect(cards.nth(1)).toContainText('EUR 32');
  await expect(cards.nth(1)).toContainText('8 seats left');
  await expect(cards.nth(2)).toContainText('Winter Tasting');
  await expect(cards.nth(2)).toContainText('2026-12-05 17:00');
  await expect(cards.nth(2)).toContainText('EUR 28');
  await expect(cards.nth(2)).toContainText('10 seats left');
});

test('a guest books a tasting and sees the confirmation', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'Book Riesling Evening' }).click();
  await fillBooking(page, { name: 'Ada Lovelace', email: 'ada@example.com', guests: '2' });
  await page.getByRole('button', { name: 'Book', exact: true }).click();

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const confirmation = page.getByRole('main');
  await expect(confirmation).toContainText('Riesling Evening');
  await expect(confirmation).toContainText('2');
  await expect(confirmation).toContainText('EUR 50');
  await expect(confirmation).toContainText(/KB-[A-Z2-9]{6}/);

  await page.goto('/');
  await expect(page.getByRole('article').nth(0)).toContainText('10 seats left');
});

test('invalid input is rejected with errors next to the fields', async ({ page }) => {
  await page.goto('/book/riesling-evening');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Name')).toHaveAttribute('aria-invalid', 'true');
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription('Enter your name');
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Enter your email address');
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/Enter the number of guests/);

  await fillBooking(page, { name: 'Ada', email: 'not-an-email', guests: '9' });
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Enter a valid email address');
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/at most 8/);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
});

test('a booking cannot take more seats than are left', async ({ page, request }) => {
  await bookViaApi(request, 'red-wine-cellar-tour', 7);
  await page.goto('/book/red-wine-cellar-tour');
  await fillBooking(page, { name: 'Bo', email: 'bo@example.com', guests: '2' });
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/Only 1 seat left/);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);

  await page.goto('/');
  await expect(page.getByRole('article').nth(1)).toContainText('1 seats left');
});

test('a fully booked tasting is marked and cannot be booked', async ({ page, request }) => {
  await bookViaApi(request, 'red-wine-cellar-tour', 8);
  await page.goto('/');
  const card = page.getByRole('article').nth(1);
  await expect(card).toContainText('Fully booked');
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0);

  await page.goto('/book/red-wine-cellar-tour');
  await expect(page.getByText(/fully booked/i).first()).toBeVisible();
  await expect(page.getByLabel('Name')).toHaveCount(0);
});

test('an unknown tasting shows a not-found message', async ({ page }) => {
  await page.goto('/book/nope');
  await expect(page.getByText('We could not find that tasting')).toBeVisible();
});

test.describe('phone viewport', () => {
  test.use({ viewport: { width: 360, height: 740 } });

  for (const path of ['/', '/book/riesling-evening', '/staff']) {
    test(`no horizontal scroll on ${path}`, async ({ page }) => {
      await page.goto(path);
      await expect(page.getByRole('banner')).toBeVisible();
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expect(overflow).toBeLessThanOrEqual(0);
    });
  }

  const expectTouchTargets = async (locators: import('@playwright/test').Locator[]) => {
    for (const locator of locators) expect((await locator.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  };

  test('start page and form controls are at least 44 px tall', async ({ page }) => {
    await page.goto('/');
    await expectTouchTargets([page.getByRole('link', { name: 'Book Riesling Evening' }), page.getByRole('link', { name: 'Staff' })]);
    await page.goto('/book/riesling-evening');
    await expectTouchTargets([
      page.getByLabel('Name'),
      page.getByLabel('Email'),
      page.getByLabel('Guests'),
      page.getByRole('button', { name: 'Book', exact: true }),
    ]);
  });

  test('staff bookings fit the screen and their controls are tall enough', async ({ page, request }) => {
    await bookViaApi(request, 'riesling-evening', 2, 'Ada Lovelace-Extraordinarily-Long-Surname');
    await page.goto('/staff');
    await page.getByLabel('Password').fill(STAFF_PASSWORD);
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page.getByRole('button', { name: 'Cancel' })).toBeVisible();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBeLessThanOrEqual(0);
    await expectTouchTargets([page.getByRole('button', { name: 'Cancel' }), page.getByRole('button', { name: 'Sign out' })]);
  });
});
