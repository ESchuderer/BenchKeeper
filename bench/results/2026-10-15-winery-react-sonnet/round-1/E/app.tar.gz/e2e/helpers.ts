import { expect, type APIRequestContext, type Page } from '@playwright/test';

export const STAFF_PASSWORD = 'e2e-secret';

export async function bookViaApi(request: APIRequestContext, tastingId: string, guests: number, name = 'Api Guest') {
  const res = await request.post(`/api/tastings/${tastingId}/bookings`, { data: { name, email: 'api@example.com', guests } });
  expect(res.status()).toBe(201);
  return (await res.json()) as { reference: string };
}

export async function cancelAllBookings(request: APIRequestContext) {
  await request.post('/api/staff/login', { data: { password: STAFF_PASSWORD } });
  const groups = (await (await request.get('/api/staff/bookings')).json()) as { bookings: { reference: string }[] }[];
  for (const group of groups) for (const b of group.bookings) await request.delete(`/api/staff/bookings/${b.reference}`);
  await request.post('/api/staff/logout');
}

export async function fillBooking(page: Page, values: { name?: string; email?: string; guests?: string }) {
  if (values.name !== undefined) await page.getByLabel('Name').fill(values.name);
  if (values.email !== undefined) await page.getByLabel('Email').fill(values.email);
  if (values.guests !== undefined) await page.getByLabel('Guests').fill(values.guests);
}
