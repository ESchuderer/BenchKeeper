import { expect, test } from '@playwright/test';
import { STAFF_PASSWORD, bookViaApi, cancelAllBookings } from './helpers';

test.afterEach(async ({ request }) => {
  await cancelAllBookings(request);
});

async function signIn(page: import('@playwright/test').Page, password = STAFF_PASSWORD) {
  await page.goto('/staff');
  await page.getByLabel('Password').fill(password);
  await page.getByRole('button', { name: 'Sign in' }).click();
}

test('a wrong password shows an error next to the field and hides bookings', async ({ page, request }) => {
  await bookViaApi(request, 'riesling-evening', 2, 'Secret Guest');
  await signIn(page, 'wrong');
  await expect(page.getByLabel('Password')).toHaveAccessibleDescription(/Wrong password/);
  await expect(page.getByText('Secret Guest')).toHaveCount(0);
});

test('staff see bookings grouped by tasting and can cancel one', async ({ page, request }) => {
  const ada = await bookViaApi(request, 'riesling-evening', 3, 'Ada');
  await bookViaApi(request, 'winter-tasting', 1, 'Bo');
  await signIn(page);

  const riesling = page.getByRole('region', { name: 'Riesling Evening' });
  await expect(riesling).toContainText('Ada');
  await expect(riesling).toContainText('api@example.com');
  await expect(riesling).toContainText(ada.reference);
  await expect(riesling.getByRole('row', { name: /Ada/ })).toContainText('3');
  await expect(page.getByRole('region', { name: 'Winter Tasting' })).toContainText('Bo');
  await expect(page.getByRole('region', { name: 'Red Wine Cellar Tour' })).toContainText('No bookings yet');

  await riesling.getByRole('button', { name: 'Cancel' }).click();
  await expect(riesling).not.toContainText('Ada');
  await expect(riesling).toContainText('No bookings yet');

  await page.goto('/');
  await expect(page.getByRole('article').nth(0)).toContainText('12 seats left');
});

test('the session survives a reload and ends on sign out', async ({ page }) => {
  await signIn(page);
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Password')).toBeVisible();
});
