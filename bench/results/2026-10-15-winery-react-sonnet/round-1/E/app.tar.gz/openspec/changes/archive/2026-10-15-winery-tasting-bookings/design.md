# Design

## Context

Greenfield repository (no code yet), Node.js 22, npm. `npm start` must serve the whole app on `PORT`. See proposal.md for scope.

## Goals / Non-Goals

**Goals:**
- One process serving the built React app and the JSON API.
- Seat limits enforced on the server only; the client only mirrors rules for early feedback.
- One validation schema shared by client and server.

**Non-Goals:**
- Persistence across restarts, email sending, payments, multiple staff accounts, admin editing of tastings, multi-instance deployment.

## Decisions

- **Stack**: TypeScript, Vite + React 19, React Router (routing), react-hook-form + zod (forms; schema in `shared/` used by the server too), Tailwind CSS (styling), Express 5 (server). Alternative: Next.js; rejected, larger runtime for three pages and one API.
- **Server bundle**: `esbuild` bundles `server/index.ts` to `dist/server.js` (packages external); `npm start` runs `node dist/server.js`. Alternative: run TS with `tsx` at runtime; rejected, adds a runtime dev tool.
- **Store**: in-memory module, tastings are constants. Booking is a synchronous check-and-insert, so it is atomic in Node's single thread (no lock needed). Seats left = capacity minus sum of guests of existing bookings; cancel deletes the booking. shortcut: in-memory, move to a database if bookings must survive restarts.
- **API**: `GET /api/tastings`; `POST /api/tastings/:id/bookings` (201 / 422 field errors / 409 not enough seats / 404); `GET /api/staff/session`; `POST /api/staff/login`; `POST /api/staff/logout`; `GET /api/staff/bookings`; `DELETE /api/staff/bookings/:reference`. Errors use `{ errors: { field: message } }` for field-level problems. No endpoint returns a booking to a guest by reference, so the confirmation is shown from the POST response only.
- **Staff auth**: `express-session` (in-memory store), cookie `HttpOnly`, `SameSite=Strict`, `Secure` automatic (needs `TRUST_PROXY` behind a TLS proxy), 2 h rolling inactivity expiry, session regenerated on login. Password compared with `timingSafeEqual` over SHA-256 digests. `express-rate-limit`: 5 failed attempts per 15 min per IP (successful attempts not counted). State-changing staff routes need the session cookie plus `SameSite=Strict`; no additional CSRF token.
- **Hardening**: `helmet` (CSP with `upgrade-insecure-requests` removed so plain-HTTP deployments work), JSON body limit 10 kb, `Cache-Control: no-store` on `/api`.
- **Booking reference**: `KB-` plus 6 characters from an unambiguous alphabet via `crypto.randomInt`, retried on collision.
- **Seat label**: rendered literally as "<n> seats left" for every n above 0 (specified format); 0 renders "Fully booked".
- **Cancel**: no confirmation dialog; the result is announced in a status message.
- **Tests**: Vitest + supertest for store and API (coverage target 80%), Playwright for browser flows including a 360 px viewport.

## Risks / Trade-offs

- Restart loses bookings and sessions → documented; acceptable per brief.
- IP-based rate limiting behind a proxy needs `TRUST_PROXY` or all clients share one bucket → env option and README note.
- A shared lockout bucket lets one client block staff sign-in for 15 minutes → accepted for a single-password site.
- Reload on the confirmation page loses it (no guest lookup endpoint, avoids exposing personal data by reference) → reference is shown once.
- Anonymous booking has no abuse limit (no email verification in the brief); a script can take all 30 seats → staff cancel in `/staff`; add per-IP limiting or email confirmation if abused.
- `TRUST_PROXY` must be set to the real number of proxy hops; too high lets clients spoof IPs, unset behind TLS proxy leaves the cookie without `Secure`.
