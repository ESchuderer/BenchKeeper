# Proposal

## Why

Weingut Kieselbrunnen takes tasting reservations informally. Guests cannot see free seats, and staff have no single list of who is coming. An online booking site with a staff view removes overbooking and manual tracking.

## What Changes

- Public site listing three tastings (title, date and time, price per guest, seats left).
- Booking form per tasting (name, email, guests 1 to 8) with server-enforced seat limits, field-level errors, and a confirmation with a booking reference.
- Password-protected `/staff` page listing bookings grouped by tasting, with cancellation that frees seats.
- Winery-styled, responsive interface with explicit error, success, and fully booked states.
- Single Node.js service serving the React app and a JSON API; bookings held in memory (no external services).

## Capabilities

### New Capabilities
- `tasting-booking`: tasting list, seat availability, booking form validation, seat limits, confirmation.
- `staff-bookings`: staff sign-in, session handling, booking list grouped by tasting, cancellation.
- `site-experience`: visual design, state presentation, responsive and accessible behavior.

### Modified Capabilities

## Impact

- New project: React front end, Node.js 22 server, npm scripts (`build`, `start`, `test`).
- Environment: `STAFF_PASSWORD` (required for staff sign-in), `PORT` (default 3000), `TRUST_PROXY` (optional).
- No migrations; bookings are lost on restart (in-memory store).
