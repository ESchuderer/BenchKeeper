# Spec Delta

## Purpose

Defines how the site looks and behaves so that it reads as the winery's own site, works on phones, and communicates states clearly.

## ADDED Requirements

### Requirement: Winery look and feel
All pages SHALL share one visual design (palette, typography, header with the winery name, footer) in English.

#### Scenario: Consistent pages
- **WHEN** a user moves between the start page, a booking form, the confirmation, and `/staff`
- **THEN** each page shows the same header and styling

### Requirement: Clear states
Errors, success, and fully booked tastings SHALL each have a distinct visual treatment that does not rely on color alone.

#### Scenario: Error state
- **WHEN** a field is invalid
- **THEN** the field is outlined and an error text is shown next to it and announced to assistive technology

#### Scenario: Success state
- **WHEN** a booking succeeds
- **THEN** the confirmation is presented as a success panel with the heading "Booking confirmed"

### Requirement: Mobile usability
All pages SHALL be usable at a viewport width of 360 px without horizontal scrolling, with touch targets of at least 44 px.

#### Scenario: Phone viewport
- **WHEN** the start page, booking form, and staff page are opened at 360 px width
- **THEN** no horizontal scrollbar appears and all controls are reachable

### Requirement: Keyboard and screen reader support
Form fields SHALL have programmatic labels, errors SHALL be associated with their fields, and focus indicators SHALL be visible.

#### Scenario: Labels
- **WHEN** a screen reader reads the booking form
- **THEN** the fields are announced as "Name", "Email", and "Guests"
