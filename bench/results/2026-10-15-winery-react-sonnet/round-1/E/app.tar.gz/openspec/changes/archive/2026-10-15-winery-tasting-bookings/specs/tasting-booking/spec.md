# Spec Delta

## Purpose

Lets guests see the winery's tastings with remaining seats and reserve seats online without ever exceeding a tasting's capacity.

## ADDED Requirements

### Requirement: Tasting list
The start page SHALL list every tasting with its title, date and time, price per guest, and seats left shown as "<n> seats left". The offered tastings are Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats), and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats).

#### Scenario: Initial state
- **WHEN** a guest opens the start page with no bookings made
- **THEN** the page shows the three tastings with "12 seats left", "8 seats left", and "10 seats left"

#### Scenario: Seats left reflect bookings
- **WHEN** 3 guests have booked Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening

### Requirement: Fully booked tastings
A tasting with no seats left SHALL be shown as fully booked and SHALL NOT offer a booking form.

#### Scenario: Last seats taken
- **WHEN** bookings have taken all 8 seats of Red Wine Cellar Tour
- **THEN** the start page marks it "Fully booked" and its booking page shows that no seats are available instead of the form

### Requirement: Booking entry points
Each tasting SHALL have a link or button "Book <tasting title>" that opens a booking form for that tasting with fields labelled "Name", "Email", and "Guests", and a "Book" button.

#### Scenario: Open the form
- **WHEN** a guest selects "Book Riesling Evening"
- **THEN** a form for Riesling Evening opens with the fields "Name", "Email", "Guests" and the button "Book"

### Requirement: Input validation
The system SHALL reject a booking when Name is empty or longer than 100 characters, Email is not a valid address, or Guests is not a whole number from 1 to 8. Each error SHALL be shown next to the field it concerns, and no booking SHALL be created. The same rules SHALL be enforced by the server.

#### Scenario: Empty form
- **WHEN** a guest submits the form with all fields empty
- **THEN** an error message appears next to each of Name, Email, and Guests and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits Guests = 9 or Guests = 0
- **THEN** an error appears next to the Guests field and no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits Email = "not-an-email"
- **THEN** an error appears next to the Email field

#### Scenario: Direct API request with invalid data
- **WHEN** a request with invalid data is sent to the booking API without the front end
- **THEN** the server responds with status 422 and per-field error messages

### Requirement: Seat limit
A booking SHALL NOT take more seats than are left for the tasting, including when bookings arrive concurrently. A rejected booking SHALL leave the seat count unchanged and show an error next to the Guests field.

#### Scenario: More guests than seats left
- **WHEN** 2 seats are left and a guest books 3
- **THEN** the booking is rejected with an error next to Guests stating that only 2 seats are left

#### Scenario: Exactly the seats left
- **WHEN** 2 seats are left and a guest books 2
- **THEN** the booking succeeds and the tasting shows as fully booked

#### Scenario: Concurrent requests
- **WHEN** two requests for 5 seats each arrive while 8 seats are left
- **THEN** exactly one succeeds and the other is rejected

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (price per guest times guests), and a unique booking reference.

#### Scenario: Successful booking
- **WHEN** a guest books 2 guests for Riesling Evening
- **THEN** the confirmation shows "Booking confirmed", "Riesling Evening", 2 guests, total "EUR 50", and a booking reference
- **AND** the start page shows "10 seats left" for Riesling Evening

#### Scenario: References are unique
- **WHEN** two bookings are made
- **THEN** their booking references differ
