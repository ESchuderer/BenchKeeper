# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` (scripts `build`, `start`, `test`, `test:e2e`, `typecheck`), TypeScript config, Vite, Tailwind, Vitest, Playwright config; verify `npm install` succeeds and `npm run typecheck` passes on the empty skeleton
- [x] 1.2 Add `.gitignore` (node_modules, dist, test artifacts) and README with run instructions and environment variables; verify the documented commands run as written

## 2. Shared rules and store

- [x] 2.1 Write failing tests for the shared booking schema and the store (seat arithmetic, overbooking, cancel frees seats, unique references), then implement `shared/` and `server/store.ts`; verify tests pass
- [x] 2.2 Define the three tastings as constants; verify the store test for initial seats passes

## 3. HTTP API

- [x] 3.1 Write failing supertest tests for tastings and booking endpoints (201, 422, 409, 404, concurrency), then implement them; verify tests pass
- [x] 3.2 Write failing tests for staff auth (login, wrong password, unset password, logout, session expiry, rate limit, cookie flags, 401 without session, cancel 404), then implement; verify tests pass and API coverage is at least 80%
- [x] 3.3 Serve the built client with SPA fallback, `PORT` default 3000, helmet, no-store; verify `npm run build && npm start` serves `/`, `/staff`, and `/api/tastings`

## 4. Front end

- [x] 4.1 Write failing Playwright tests for the guest flow (list, book, validation errors, overbooking error, confirmation, fully booked), then implement layout, list, booking form, confirmation; verify the tests pass
- [x] 4.2 Write failing Playwright tests for the staff flow (sign-in error, list grouped by tasting, cancel frees seats, sign out), then implement the staff page; verify the tests pass
- [x] 4.3 Apply the visual design, states, and 360 px layout; verify the viewport test (no horizontal scroll) and a visual check with Playwright MCP screenshots

## 5. Final checks

- [x] 5.1 Run typecheck, build, unit and e2e suites; verify all pass
- [x] 5.2 Run code review and security review agents; verify no CRITICAL or HIGH findings remain

## Workflow follow-up

- Archive the change (`openspec-archive-change`) on the branch before merging.
