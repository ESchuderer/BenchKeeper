# staff-bookings Specification

## Purpose
Lets winery staff sign in and see all bookings per tasting, and cancel a booking so its seats become available again.

## Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a password in a field labelled "Password" with a "Sign in" button. The expected password SHALL come from the environment variable `STAFF_PASSWORD`. A wrong password SHALL show an error next to the field and grant no access. If `STAFF_PASSWORD` is unset or empty, no password SHALL be accepted.

#### Scenario: Correct password
- **WHEN** staff enter the value of `STAFF_PASSWORD` and select "Sign in"
- **THEN** the bookings view is shown

#### Scenario: Wrong password
- **WHEN** staff enter a different password
- **THEN** an error is shown next to the Password field and bookings stay hidden

#### Scenario: Not signed in
- **WHEN** a client requests the staff booking data without signing in
- **THEN** the server responds with status 401 and no booking data

### Requirement: Sign-in protection
The system SHALL limit failed sign-in attempts, SHALL end staff sessions after a period of inactivity, SHALL let staff sign out, and SHALL set the session cookie HttpOnly, SameSite, and Secure when served over HTTPS.

#### Scenario: Too many failed attempts
- **WHEN** a client makes 5 failed sign-in attempts within 15 minutes
- **THEN** further sign-in attempts from that client are rejected with status 429, including with the correct password

#### Scenario: Sign out
- **WHEN** signed-in staff select "Sign out"
- **THEN** the staff booking data is no longer accessible with that session

#### Scenario: Session expiry
- **WHEN** a session has been idle longer than its allowed lifetime
- **THEN** staff booking data requests are rejected with status 401

#### Scenario: Cookie attributes
- **WHEN** staff sign in
- **THEN** the session cookie has HttpOnly and SameSite set, and Secure when the request arrived over HTTPS

### Requirement: Bookings grouped by tasting
A signed-in staff member SHALL see all bookings grouped by tasting, each with name, email, guests, and booking reference. A tasting without bookings SHALL say so.

#### Scenario: Bookings listed
- **WHEN** Ada booked 2 guests and Bo booked 3 guests for Riesling Evening
- **THEN** the Riesling Evening group lists both bookings with name, email, guests, and reference

#### Scenario: No bookings
- **WHEN** a tasting has no bookings
- **THEN** its group shows that there are no bookings

### Requirement: Cancel booking
Each booking SHALL have a "Cancel" button that removes the booking and frees its seats for new bookings.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 3 guests for Riesling Evening that had 9 seats left
- **THEN** the booking disappears from the list and the start page shows "12 seats left"

#### Scenario: Cancel unknown booking
- **WHEN** a cancel request names a reference that does not exist
- **THEN** the server responds with status 404 and nothing changes

#### Scenario: Cancel while signed out
- **WHEN** a cancel request is made without signing in
- **THEN** the server responds with status 401 and the booking remains
