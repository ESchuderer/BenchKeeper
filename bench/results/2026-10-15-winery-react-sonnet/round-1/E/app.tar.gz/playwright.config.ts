import { defineConfig, devices } from '@playwright/test';

const port = 3100;
const staffPassword = 'e2e-secret';

export default defineConfig({
  testDir: 'e2e',
  fullyParallel: false,
  workers: 1,
  reporter: 'list',
  use: {
    baseURL: `http://localhost:${port}`,
    launchOptions: process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {},
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'npm start',
    port,
    env: { PORT: String(port), STAFF_PASSWORD: staffPassword },
    reuseExistingServer: false,
  },
});
