import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp, type AppOptions } from './app';

const PASSWORD = 'correct horse';
const guest = { name: 'Ada', email: 'ada@example.com', guests: 2 };
const make = (options: AppOptions = {}) => createApp({ staffPassword: PASSWORD, ...options });

async function signedIn(app = make()) {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(204);
  return agent;
}

describe('guest API', () => {
  it('lists tastings with seats left', async () => {
    const res = await request(make()).get('/api/tastings').expect(200);
    expect(res.body.map((t: { seatsLeft: number }) => t.seatsLeft)).toEqual([12, 8, 10]);
    expect(res.headers['cache-control']).toContain('no-store');
  });

  it('books and returns a confirmation without personal data', async () => {
    const app = make();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(guest).expect(201);
    expect(res.body).toMatchObject({ guests: 2, totalEur: 50, tasting: { title: 'Riesling Evening' } });
    expect(res.body.reference).toMatch(/^KB-/);
    expect(JSON.stringify(res.body)).not.toContain('ada@example.com');
    const list = await request(app).get('/api/tastings');
    expect(list.body[0].seatsLeft).toBe(10);
  });

  it('answers 422 with per-field errors for invalid input', async () => {
    const res = await request(make()).post('/api/tastings/riesling-evening/bookings').send({ name: '', email: 'x', guests: 9 }).expect(422);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it('answers 409 with a guests error when seats are short and keeps the count', async () => {
    const app = make();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 7 }).expect(201);
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 2 }).expect(409);
    expect(res.body.errors.guests).toMatch(/only 1 seat/i);
    expect((await request(app).get('/api/tastings')).body[1].seatsLeft).toBe(1);
  });

  it('says fully booked when no seats remain', async () => {
    const app = make();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 8 }).expect(201);
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 1 }).expect(409);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });

  it('lets exactly one of two concurrent requests win', async () => {
    const app = make();
    const post = () => request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 5 });
    const statuses = (await Promise.all([post(), post()])).map((r) => r.status).sort();
    expect(statuses).toEqual([201, 409]);
  });

  it('answers 404 for an unknown tasting and unknown API paths', async () => {
    await request(make()).post('/api/tastings/nope/bookings').send(guest).expect(404);
    await request(make()).get('/api/unknown').expect(404);
  });

  it('answers 400 for malformed JSON', async () => {
    await request(make()).post('/api/tastings/riesling-evening/bookings').set('Content-Type', 'application/json').send('{bad').expect(400);
  });
});

describe('staff API', () => {
  it('rejects staff data and cancel without a session', async () => {
    const app = make();
    await request(app).get('/api/staff/bookings').expect(401);
    const booked = await request(app).post('/api/tastings/riesling-evening/bookings').send(guest);
    await request(app).delete(`/api/staff/bookings/${booked.body.reference}`).expect(401);
    expect((await request(app).get('/api/tastings')).body[0].seatsLeft).toBe(10);
  });

  it('rejects a wrong password with 401', async () => {
    await request(make()).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    await request(make()).post('/api/staff/login').send({}).expect(401);
  });

  it('accepts no password when STAFF_PASSWORD is empty', async () => {
    const app = createApp({ staffPassword: '' });
    await request(app).post('/api/staff/login').send({ password: '' }).expect(503);
    await request(app).post('/api/staff/login').send({ password: 'anything' }).expect(503);
  });

  it('reports the session state', async () => {
    const app = make();
    expect((await request(app).get('/api/staff/session')).body).toEqual({ authenticated: false });
    const agent = await signedIn(app);
    expect((await agent.get('/api/staff/session')).body).toEqual({ authenticated: true });
  });

  it('lists bookings grouped by tasting and cancels one, freeing its seats', async () => {
    const app = make();
    const agent = await signedIn(app);
    const booked = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guest, guests: 3 });
    const list = await agent.get('/api/staff/bookings').expect(200);
    expect(list.body).toHaveLength(3);
    expect(list.body[0].tasting.title).toBe('Riesling Evening');
    expect(list.body[0].bookings).toEqual([
      expect.objectContaining({ name: 'Ada', email: 'ada@example.com', guests: 3, reference: booked.body.reference }),
    ]);
    expect(list.body[1].bookings).toEqual([]);
    await agent.delete(`/api/staff/bookings/${booked.body.reference}`).expect(204);
    expect((await request(app).get('/api/tastings')).body[0].seatsLeft).toBe(12);
    await agent.delete(`/api/staff/bookings/${booked.body.reference}`).expect(404);
  });

  it('ends the session on logout', async () => {
    const agent = await signedIn();
    await agent.post('/api/staff/logout').expect(204);
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('expires an idle session', async () => {
    const app = make({ sessionMaxAgeMs: 1000 });
    const login = await request(app).post('/api/staff/login').send({ password: PASSWORD });
    const cookie = login.headers['set-cookie'][0].split(';')[0];
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);
    await new Promise((r) => setTimeout(r, 1300));
    // The cookie is replayed, so a 401 proves the server dropped the session.
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(401);
  });

  it('blocks sign-in after 5 failed attempts, even with the right password', async () => {
    const app = make();
    for (let i = 0; i < 5; i++) await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(429);
    await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(429);
  });

  it('does not count successful sign-ins against the limit', async () => {
    const app = make();
    for (let i = 0; i < 7; i++) await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(204);
  });

  it('sets HttpOnly and SameSite on the session cookie, Secure only over HTTPS', async () => {
    const plain = await request(make()).post('/api/staff/login').send({ password: PASSWORD });
    const plainCookie = plain.headers['set-cookie'][0];
    expect(plainCookie).toMatch(/HttpOnly/i);
    expect(plainCookie).toMatch(/SameSite=Strict/i);
    expect(plainCookie).not.toMatch(/Secure/i);

    const tls = await request(make({ trustProxy: 1 })).post('/api/staff/login').set('X-Forwarded-Proto', 'https').send({ password: PASSWORD });
    expect(tls.headers['set-cookie'][0]).toMatch(/Secure/i);
  });
});

describe('static client', () => {
  it('serves index.html for client routes but not for API misses', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'client-'));
    writeFileSync(join(dir, 'index.html'), '<!doctype html><title>app</title>');
    const app = make({ clientDir: dir });
    expect((await request(app).get('/staff').expect(200)).text).toContain('<title>app</title>');
    expect((await request(app).get('/book/riesling-evening').expect(200)).text).toContain('<title>app</title>');
    await request(app).get('/api/nothing').expect(404);
  });
});
