import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { resolve } from 'node:path';
import express, { type ErrorRequestHandler, type RequestHandler } from 'express';
import { rateLimit } from 'express-rate-limit';
import session from 'express-session';
import helmet from 'helmet';
import { parseBooking } from '../shared/booking';
import { createStore, type Store } from './store';

declare module 'express-session' {
  interface SessionData {
    staff?: boolean;
  }
}

export interface AppOptions {
  staffPassword?: string;
  store?: Store;
  clientDir?: string;
  trustProxy?: number | boolean;
  sessionMaxAgeMs?: number;
}

const TWO_HOURS_MS = 2 * 60 * 60 * 1000;
const MAX_FAILED_LOGINS = 5;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

const digest = (value: string) => createHash('sha256').update(value).digest();
const seatsText = (n: number) => `${n} seat${n === 1 ? '' : 's'}`;

export function createApp({
  staffPassword = '',
  store = createStore(),
  clientDir,
  trustProxy = false,
  sessionMaxAgeMs = TWO_HOURS_MS,
}: AppOptions = {}) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', trustProxy);
  // upgrade-insecure-requests would break plain-HTTP deployments.
  app.use(helmet({ contentSecurityPolicy: { directives: { 'upgrade-insecure-requests': null } } }));
  app.use('/api', express.json({ limit: '10kb' }), (_req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });
  app.use(
    session({
      name: 'kb.sid',
      // shortcut: random per process and in-memory store, sessions end on restart; use a shared store for several instances.
      secret: randomBytes(32).toString('hex'),
      resave: false,
      saveUninitialized: false,
      rolling: true,
      cookie: { httpOnly: true, sameSite: 'strict', secure: 'auto', maxAge: sessionMaxAgeMs },
    }),
  );

  const requireStaff: RequestHandler = (req, res, next) => {
    if (req.session.staff) return next();
    res.status(401).json({ error: 'Sign in required.' });
  };
  const limitFailedLogins = rateLimit({
    windowMs: LOGIN_WINDOW_MS,
    limit: MAX_FAILED_LOGINS,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many failed attempts. Try again in 15 minutes.' },
  });

  app.get('/api/tastings', (_req, res) => {
    res.json(store.listTastings());
  });

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const parsed = parseBooking(req.body);
    if (!parsed.ok) return res.status(422).json({ errors: parsed.errors });
    const result = store.book(req.params.id, parsed.data);
    if (result.ok) return res.status(201).json(result.confirmation);
    if (result.reason === 'unknown-tasting') return res.status(404).json({ error: 'Unknown tasting.' });
    const message =
      result.seatsLeft === 0 ? 'This tasting is fully booked.' : `Only ${seatsText(result.seatsLeft)} left. Choose fewer guests.`;
    res.status(409).json({ errors: { guests: message } });
  });

  app.get('/api/staff/session', (req, res) => {
    res.json({ authenticated: req.session.staff === true });
  });

  app.post('/api/staff/login', limitFailedLogins, (req, res, next) => {
    if (!staffPassword) return res.status(503).json({ error: 'Staff sign-in is not configured.' });
    const given = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!timingSafeEqual(digest(given), digest(staffPassword))) return res.status(401).json({ error: 'Wrong password.' });
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.staff = true;
      req.session.save((saveErr) => (saveErr ? next(saveErr) : res.sendStatus(204)));
    });
  });

  app.post('/api/staff/logout', (req, res, next) => {
    req.session.destroy((err) => {
      if (err) return next(err);
      res.clearCookie('kb.sid').sendStatus(204);
    });
  });

  app.get('/api/staff/bookings', requireStaff, (_req, res) => {
    res.json(store.bookingsByTasting());
  });

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(String(req.params.reference))) return res.status(404).json({ error: 'Unknown booking.' });
    res.sendStatus(204);
  });

  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found.' });
  });

  if (clientDir) {
    const root = resolve(clientDir);
    app.use(express.static(root));
    app.get('/{*path}', (_req, res) => {
      res.sendFile('index.html', { root });
    });
  }

  const onError: ErrorRequestHandler = (err, _req, res, _next) => {
    const status = typeof err?.status === 'number' && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 500 ? 'Something went wrong.' : 'Bad request.' });
  };
  app.use(onError);

  return app;
}
