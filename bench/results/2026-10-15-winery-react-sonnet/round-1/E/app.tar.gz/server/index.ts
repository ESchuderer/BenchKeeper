import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app';

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD ?? '';
if (!staffPassword) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');

const app = createApp({
  staffPassword,
  clientDir: join(dirname(fileURLToPath(import.meta.url)), 'client'),
  trustProxy: Number(process.env.TRUST_PROXY) || false,
});
app.listen(port, () => console.log(`Weingut Kieselbrunnen bookings on http://localhost:${port}`));
