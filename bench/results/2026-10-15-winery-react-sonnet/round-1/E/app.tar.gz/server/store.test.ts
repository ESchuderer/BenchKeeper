import { beforeEach, describe, expect, it } from 'vitest';
import { createStore, type Store } from './store';

const guest = { name: 'Ada', email: 'ada@example.com' };

describe('store', () => {
  let store: Store;
  beforeEach(() => {
    store = createStore();
  });

  it('starts with the three tastings and no bookings', () => {
    expect(store.listTastings().map((t) => [t.title, t.startsAt, t.priceEur, t.seatsLeft])).toEqual([
      ['Riesling Evening', '2026-11-06T18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14T15:00', 32, 8],
      ['Winter Tasting', '2026-12-05T17:00', 28, 10],
    ]);
    expect(store.bookingsByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });

  it('books seats and computes the total price', () => {
    const result = store.book('riesling-evening', { ...guest, guests: 2 });
    expect(result.ok && result.confirmation).toMatchObject({ guests: 2, totalEur: 50, tasting: { title: 'Riesling Evening' } });
    expect(store.listTastings()[0].seatsLeft).toBe(10);
  });

  it('rejects more guests than seats left and leaves seats unchanged', () => {
    store.book('red-wine-cellar-tour', { ...guest, guests: 6 });
    const result = store.book('red-wine-cellar-tour', { ...guest, guests: 3 });
    expect(result).toEqual({ ok: false, reason: 'no-seats', seatsLeft: 2 });
    expect(store.listTastings()[1].seatsLeft).toBe(2);
  });

  it('allows booking exactly the seats left', () => {
    store.book('red-wine-cellar-tour', { ...guest, guests: 6 });
    expect(store.book('red-wine-cellar-tour', { ...guest, guests: 2 }).ok).toBe(true);
    expect(store.listTastings()[1].seatsLeft).toBe(0);
  });

  it('reports an unknown tasting', () => {
    expect(store.book('nope', { ...guest, guests: 1 })).toEqual({ ok: false, reason: 'unknown-tasting' });
  });

  it('gives unique references', () => {
    const refs = new Set<string>();
    for (let i = 0; i < 12; i++) {
      const r = store.book('riesling-evening', { ...guest, guests: 1 });
      if (r.ok) refs.add(r.confirmation.reference);
    }
    expect(refs.size).toBe(12);
    for (const ref of refs) expect(ref).toMatch(/^KB-[A-Z2-9]{6}$/);
  });

  it('groups bookings by tasting in booking order', () => {
    store.book('winter-tasting', { name: 'Bo', email: 'bo@example.com', guests: 1 });
    store.book('winter-tasting', { name: 'Cy', email: 'cy@example.com', guests: 2 });
    const winter = store.bookingsByTasting()[2];
    expect(winter.bookings.map((b) => b.name)).toEqual(['Bo', 'Cy']);
    expect(winter.bookings[0]).toMatchObject({ email: 'bo@example.com', guests: 1 });
  });

  it('cancel removes the booking and frees its seats', () => {
    const r = store.book('riesling-evening', { ...guest, guests: 3 });
    if (!r.ok) throw new Error('booking failed');
    expect(store.cancel(r.confirmation.reference)).toBe(true);
    expect(store.listTastings()[0].seatsLeft).toBe(12);
    expect(store.cancel(r.confirmation.reference)).toBe(false);
  });
});
