import { randomInt } from 'node:crypto';
import type { BookingInput, ConfirmationDto, StaffTastingDto, TastingDto } from '../shared/booking';

type TastingDef = Omit<TastingDto, 'seatsLeft'>;

export const TASTINGS: TastingDef[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEur: 25, capacity: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceEur: 32, capacity: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceEur: 28, capacity: 10 },
];

interface Booking extends BookingInput {
  reference: string;
  tastingId: string;
}

export type BookResult =
  | { ok: true; confirmation: ConfirmationDto }
  | { ok: false; reason: 'unknown-tasting' }
  | { ok: false; reason: 'no-seats'; seatsLeft: number };

export interface Store {
  listTastings(): TastingDto[];
  book(tastingId: string, input: BookingInput): BookResult;
  bookingsByTasting(): StaffTastingDto[];
  cancel(reference: string): boolean;
}

// No I, O, 0, 1: references are read aloud and typed by hand.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function newReference(): string {
  let code = '';
  for (let i = 0; i < 6; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  return `KB-${code}`;
}

export function createStore(tastings: TastingDef[] = TASTINGS): Store {
  const bookings = new Map<string, Booking>();

  const seatsLeft = (tasting: TastingDef) =>
    tasting.capacity - [...bookings.values()].filter((b) => b.tastingId === tasting.id).reduce((sum, b) => sum + b.guests, 0);
  const view = (tasting: TastingDef): TastingDto => ({ ...tasting, seatsLeft: seatsLeft(tasting) });

  return {
    listTastings: () => tastings.map(view),

    // Synchronous check-and-insert: atomic on Node's single thread.
    book(tastingId, input) {
      const tasting = tastings.find((t) => t.id === tastingId);
      if (!tasting) return { ok: false, reason: 'unknown-tasting' };
      const left = seatsLeft(tasting);
      if (input.guests > left) return { ok: false, reason: 'no-seats', seatsLeft: left };
      let reference = newReference();
      while (bookings.has(reference)) reference = newReference();
      bookings.set(reference, { ...input, reference, tastingId });
      const { id, title, startsAt, priceEur } = tasting;
      return { ok: true, confirmation: { reference, tasting: { id, title, startsAt }, guests: input.guests, totalEur: priceEur * input.guests } };
    },

    bookingsByTasting: () =>
      tastings.map((tasting) => ({
        tasting: view(tasting),
        bookings: [...bookings.values()]
          .filter((b) => b.tastingId === tasting.id)
          .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
      })),

    cancel: (reference) => bookings.delete(reference),
  };
}
