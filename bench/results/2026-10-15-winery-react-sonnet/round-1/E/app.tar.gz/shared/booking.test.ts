import { describe, expect, it } from 'vitest';
import { parseBooking } from './booking';

const valid = { name: 'Ada Lovelace', email: 'ada@example.com', guests: 2 };

describe('parseBooking', () => {
  it('accepts valid input and trims text', () => {
    const result = parseBooking({ ...valid, name: '  Ada  ', email: ' ada@example.com ' });
    expect(result).toEqual({ ok: true, data: { name: 'Ada', email: 'ada@example.com', guests: 2 } });
  });

  it('reports an error for every empty field', () => {
    const result = parseBooking({ name: '', email: '', guests: Number.NaN });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(Object.keys(result.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it.each([0, 9, 1.5, -1])('rejects guests = %s', (guests) => {
    const result = parseBooking({ ...valid, guests });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.errors).toHaveProperty('guests');
  });

  it.each([1, 8])('accepts guests = %s', (guests) => {
    expect(parseBooking({ ...valid, guests }).ok).toBe(true);
  });

  it('rejects an invalid email', () => {
    const result = parseBooking({ ...valid, email: 'not-an-email' });
    expect(result.ok === false && result.errors.email).toBeTruthy();
  });

  it('rejects names over 100 characters', () => {
    expect(parseBooking({ ...valid, name: 'x'.repeat(101) }).ok).toBe(false);
  });

  it.each([null, 'text', 42, [], { name: 1, email: 2, guests: '2' }])('rejects non-object or mistyped body %j', (body) => {
    expect(parseBooking(body).ok).toBe(false);
  });
});

describe('parseBooking control characters', () => {
  it.each(['Ada\nLovelace', 'Ada\u0000', 'Ada\tL'])('rejects a name with control characters %j', (name) => {
    const result = parseBooking({ name, email: 'ada@example.com', guests: 1 });
    expect(result.ok === false && result.errors.name).toBeTruthy();
  });
});
