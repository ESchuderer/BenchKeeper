import { z } from 'zod';

export const MAX_GUESTS = 8;

export const bookingSchema = z.object({
  name: z
    .string({ error: 'Enter your name' })
    .trim()
    .min(1, 'Enter your name')
    .max(100, 'Use at most 100 characters')
    .regex(/^[^\p{Cc}]*$/u, 'Remove line breaks and control characters'),
  email: z
    .string({ error: 'Enter your email address' })
    .trim()
    .min(1, 'Enter your email address')
    .max(254, 'Use at most 254 characters')
    .pipe(z.email('Enter a valid email address')),
  guests: z
    .number({ error: 'Enter the number of guests' })
    .int('Enter a whole number of guests')
    .min(1, 'Book at least 1 guest')
    .max(MAX_GUESTS, `Book at most ${MAX_GUESTS} guests`),
});

export type BookingInput = z.infer<typeof bookingSchema>;
export type FieldErrors = Partial<Record<keyof BookingInput, string>>;

export function parseBooking(body: unknown): { ok: true; data: BookingInput } | { ok: false; errors: FieldErrors } {
  const result = bookingSchema.safeParse(body);
  if (result.success) return { ok: true, data: result.data };
  const errors: FieldErrors = {};
  for (const issue of result.error.issues) {
    const field = issue.path[0] as keyof BookingInput | undefined;
    // Non-object bodies have no field; show them next to the first field.
    const key = field ?? 'name';
    errors[key] ??= issue.message;
  }
  return { ok: false, errors };
}

export interface TastingDto {
  id: string;
  title: string;
  startsAt: string;
  priceEur: number;
  capacity: number;
  seatsLeft: number;
}

export interface ConfirmationDto {
  reference: string;
  tasting: Pick<TastingDto, 'id' | 'title' | 'startsAt'>;
  guests: number;
  totalEur: number;
}

export interface StaffBookingDto {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTastingDto {
  tasting: TastingDto;
  bookings: StaffBookingDto[];
}
