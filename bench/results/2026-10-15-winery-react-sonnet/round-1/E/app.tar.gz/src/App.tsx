import { Route, Routes } from 'react-router';
import { Layout } from './components/Layout';
import { BookPage } from './pages/BookPage';
import { HomePage } from './pages/HomePage';
import { StaffPage } from './pages/StaffPage';

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="book/:tastingId" element={<BookPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

function NotFound() {
  return (
    <section className="panel">
      <title>Page not found | Weingut Kieselbrunnen</title>
      <h1 className="text-3xl">Page not found</h1>
      <p className="mt-3">
        <a href="/">Back to the tastings</a>
      </p>
    </section>
  );
}
