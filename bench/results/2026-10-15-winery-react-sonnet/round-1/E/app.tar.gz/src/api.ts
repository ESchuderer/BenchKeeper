import type { BookingInput, ConfirmationDto, FieldErrors, StaffTastingDto, TastingDto } from '../shared/booking';

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly fieldErrors: FieldErrors = {},
    message = 'Something went wrong.',
  ) {
    super(message);
  }
}

async function call<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      ...init,
      headers: init?.body ? { 'Content-Type': 'application/json' } : undefined,
    });
  } catch {
    throw new ApiError(0, {}, 'Could not reach the server. Check your connection and try again.');
  }
  if (res.status === 204) return undefined as T;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, body.errors, body.error);
  return body as T;
}

const post = <T>(path: string, data?: unknown) =>
  call<T>(path, { method: 'POST', body: data === undefined ? undefined : JSON.stringify(data) });

export const api = {
  tastings: () => call<TastingDto[]>('/api/tastings'),
  book: (tastingId: string, input: BookingInput) => post<ConfirmationDto>(`/api/tastings/${tastingId}/bookings`, input),
  staffSession: () => call<{ authenticated: boolean }>('/api/staff/session'),
  login: (password: string) => post<void>('/api/staff/login', { password }),
  logout: () => post<void>('/api/staff/logout'),
  staffBookings: () => call<StaffTastingDto[]>('/api/staff/bookings'),
  cancel: (reference: string) => call<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' }),
};
