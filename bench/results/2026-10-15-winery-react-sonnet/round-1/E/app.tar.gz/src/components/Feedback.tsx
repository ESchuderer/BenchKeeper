import type { ReactNode } from 'react';

function WarningIcon() {
  return (
    <svg viewBox="0 0 20 20" aria-hidden="true" className="mt-0.5 size-4 shrink-0" fill="currentColor">
      <path d="M10 1.5 19 17.5H1zM9 7v5h2V7zm0 6.5v2h2v-2z" />
    </svg>
  );
}

export function FieldError({ id, children }: { id: string; children?: ReactNode }) {
  if (!children) return null;
  return (
    <p id={id} className="field-error">
      <WarningIcon />
      <span>{children}</span>
    </p>
  );
}

export function ErrorAlert({ children, onRetry }: { children: ReactNode; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-danger bg-danger-soft p-4 text-danger">
      <WarningIcon />
      <p className="flex-1 font-medium">{children}</p>
      {onRetry && (
        <button type="button" className="btn-quiet" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}

export function Loading({ label }: { label: string }) {
  return (
    <p role="status" className="text-muted">
      {label}
    </p>
  );
}
