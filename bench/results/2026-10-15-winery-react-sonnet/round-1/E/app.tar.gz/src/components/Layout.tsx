import { Link, Outlet } from 'react-router';

function GrapeMark() {
  return (
    <svg viewBox="0 0 32 32" aria-hidden="true" className="size-9 shrink-0">
      <circle cx="16" cy="16" r="16" fill="#f7f1e5" />
      <path d="M16 4c1 3 3 4 6 4-1 3-3 4-6 3z" fill="#3f5230" />
      <circle cx="11.5" cy="15" r="3.6" fill="#6b1f33" />
      <circle cx="20.5" cy="15" r="3.6" fill="#6b1f33" />
      <circle cx="16" cy="21" r="3.6" fill="#6b1f33" />
    </svg>
  );
}

export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b-4 border-gold bg-wine text-cream">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-4">
          <Link to="/" className="flex items-center gap-3 text-cream no-underline focus-visible:outline-cream">
            <GrapeMark />
            <span>
              <span className="block font-serif text-xl leading-tight font-semibold sm:text-2xl">Weingut Kieselbrunnen</span>
              <span className="block text-xs tracking-widest text-parchment uppercase">Family winery</span>
            </span>
          </Link>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:py-12">
        <Outlet />
      </main>
      <footer className="border-t border-parchment bg-parchment/60">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-5 text-sm text-muted">
          <p>Weingut Kieselbrunnen. Tastings by appointment.</p>
          <Link to="/staff" className="inline-flex min-h-11 items-center text-muted underline">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
