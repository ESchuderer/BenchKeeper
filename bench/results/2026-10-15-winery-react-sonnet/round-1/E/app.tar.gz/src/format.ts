export const formatEur = (amount: number) => `EUR ${amount}`;

// "2026-11-06T18:00" -> "2026-11-06 18:00"
export const formatStart = (startsAt: string) => startsAt.replace('T', ' ');

export function dateBadge(startsAt: string): { day: string; month: string } {
  const date = new Date(`${startsAt.slice(0, 10)}T12:00:00Z`);
  return {
    day: String(date.getUTCDate()),
    month: date.toLocaleString('en', { month: 'short', timeZone: 'UTC' }).toUpperCase(),
  };
}

export const seatsLeftText = (seatsLeft: number) => (seatsLeft > 0 ? `${seatsLeft} seats left` : 'Fully booked');
