import { zodResolver } from '@hookform/resolvers/zod';
import { useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useParams } from 'react-router';
import { MAX_GUESTS, bookingSchema, type BookingInput, type ConfirmationDto, type TastingDto } from '../../shared/booking';
import { ApiError, api } from '../api';
import { ErrorAlert, FieldError, Loading } from '../components/Feedback';
import { formatEur, formatStart, seatsLeftText } from '../format';
import { useAsync } from '../useAsync';

export function BookPage() {
  const { tastingId } = useParams();
  const [tastings, reload] = useAsync(api.tastings);
  const [confirmation, setConfirmation] = useState<ConfirmationDto>();

  if (confirmation) return <Confirmation confirmation={confirmation} />;
  if (tastings.status === 'loading') return <Loading label="Loading tasting..." />;
  if (tastings.status === 'error') return <ErrorAlert onRetry={reload}>{tastings.message}</ErrorAlert>;

  const tasting = tastings.data.find((t) => t.id === tastingId);
  if (!tasting) {
    return (
      <section className="panel max-w-xl">
        <title>Tasting not found | Weingut Kieselbrunnen</title>
        <h1 className="text-3xl">We could not find that tasting</h1>
        <p className="mt-4">
          <Link to="/" className="btn">
            See all tastings
          </Link>
        </p>
      </section>
    );
  }
  return <BookingForm tasting={tasting} onBooked={setConfirmation} onSeatsChanged={reload} />;
}

function BookingForm({
  tasting,
  onBooked,
  onSeatsChanged,
}: {
  tasting: TastingDto;
  onBooked: (c: ConfirmationDto) => void;
  onSeatsChanged: () => void;
}) {
  const [formError, setFormError] = useState<string>();
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({ resolver: zodResolver(bookingSchema), defaultValues: { name: '', email: '' } });

  const onSubmit = handleSubmit(async (values) => {
    setFormError(undefined);
    try {
      onBooked(await api.book(tasting.id, values));
    } catch (err) {
      if (!(err instanceof ApiError)) throw err;
      const fields = Object.entries(err.fieldErrors) as [keyof BookingInput, string][];
      if (fields.length === 0) return setFormError(err.message);
      for (const [field, message] of fields) setError(field, { message }, { shouldFocus: true });
      if (err.status === 409) onSeatsChanged();
    }
  });

  if (tasting.seatsLeft === 0) {
    return (
      <section className="panel max-w-xl">
        <title>{`${tasting.title} | Weingut Kieselbrunnen`}</title>
        <h1 className="text-3xl">{tasting.title}</h1>
        <p className="mt-3 rounded-lg border border-muted bg-parchment/50 p-4 font-medium">
          This tasting is fully booked. Please choose another date.
        </p>
        <p className="mt-5">
          <Link to="/" className="btn">
            See all tastings
          </Link>
        </p>
      </section>
    );
  }

  return (
    <div className="mx-auto max-w-xl">
      <title>{`Book ${tasting.title} | Weingut Kieselbrunnen`}</title>
      <Link to="/" className="inline-flex min-h-11 items-center">
        &larr; All tastings
      </Link>
      <section className="panel mt-2">
        <p className="text-sm font-semibold tracking-widest text-gold uppercase">Book your tasting</p>
        <h1 className="mt-1 text-3xl">{tasting.title}</h1>
        <p className="mt-2 text-muted">
          <time dateTime={tasting.startsAt}>{formatStart(tasting.startsAt)}</time> &middot; {formatEur(tasting.priceEur)} per guest
          &middot; {seatsLeftText(tasting.seatsLeft)}
        </p>

        <form onSubmit={onSubmit} noValidate className="mt-6 space-y-5">
          {formError && <ErrorAlert>{formError}</ErrorAlert>}
          <Field label="Name" name="name" error={errors.name?.message}>
            {(props) => <input {...props} {...register('name')} type="text" autoComplete="name" />}
          </Field>
          <Field label="Email" name="email" error={errors.email?.message}>
            {(props) => <input {...props} {...register('email')} type="email" autoComplete="email" />}
          </Field>
          <Field label="Guests" name="guests" hint={`1 to ${MAX_GUESTS} guests`} error={errors.guests?.message}>
            {(props) => <input {...props} {...register('guests', { valueAsNumber: true })} type="number" inputMode="numeric" min={1} max={MAX_GUESTS} />}
          </Field>
          <button type="submit" className="btn w-full" disabled={isSubmitting}>
            Book
          </button>
        </form>
      </section>
    </div>
  );
}

interface FieldProps {
  label: string;
  name: string;
  hint?: string;
  error?: string;
  children: (props: { id: string; className: string; 'aria-invalid': boolean; 'aria-describedby'?: string }) => React.ReactNode;
}

function Field({ label, name, hint, error, children }: FieldProps) {
  const id = `field-${name}`;
  const describedBy = [error && `${id}-error`, hint && `${id}-hint`].filter(Boolean).join(' ') || undefined;
  return (
    <div>
      <label htmlFor={id} className="mb-1 block font-semibold">
        {label}
      </label>
      {children({ id, className: 'field', 'aria-invalid': Boolean(error), 'aria-describedby': describedBy })}
      <FieldError id={`${id}-error`}>{error}</FieldError>
      {hint && !error && (
        <p id={`${id}-hint`} className="mt-1 text-sm text-muted">
          {hint}
        </p>
      )}
    </div>
  );
}

function Confirmation({ confirmation }: { confirmation: ConfirmationDto }) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => heading.current?.focus(), []);
  const rows: [string, string][] = [
    ['Tasting', confirmation.tasting.title],
    ['Date and time', formatStart(confirmation.tasting.startsAt)],
    ['Guests', String(confirmation.guests)],
    ['Total price', formatEur(confirmation.totalEur)],
    ['Booking reference', confirmation.reference],
  ];
  return (
    <section className="mx-auto max-w-xl rounded-xl border-2 border-vine bg-vine-soft p-5 sm:p-7">
      <title>Booking confirmed | Weingut Kieselbrunnen</title>
      <h1 ref={heading} tabIndex={-1} className="flex items-center gap-3 text-3xl text-vine! outline-none">
        <svg viewBox="0 0 24 24" aria-hidden="true" className="size-8 shrink-0" fill="none" stroke="currentColor" strokeWidth="2.5">
          <circle cx="12" cy="12" r="10" />
          <path d="m7 12.5 3.5 3.5L17 9" />
        </svg>
        Booking confirmed
      </h1>
      <p className="mt-3">We look forward to welcoming you. Please keep your booking reference.</p>
      <dl className="mt-5 divide-y divide-vine/20 rounded-lg bg-white px-4">
        {rows.map(([term, value]) => (
          <div key={term} className="flex flex-wrap justify-between gap-x-4 py-3">
            <dt className="text-muted">{term}</dt>
            <dd className={`font-semibold ${term === 'Booking reference' ? 'font-mono tracking-wider' : ''}`}>{value}</dd>
          </div>
        ))}
      </dl>
      <p className="mt-6">
        <Link to="/" className="btn-quiet">
          Back to all tastings
        </Link>
      </p>
    </section>
  );
}
