import { Link } from 'react-router';
import type { TastingDto } from '../../shared/booking';
import { api } from '../api';
import { ErrorAlert, Loading } from '../components/Feedback';
import { dateBadge, formatEur, formatStart, seatsLeftText } from '../format';
import { useAsync } from '../useAsync';

export function HomePage() {
  const [tastings, reload] = useAsync(api.tastings);

  return (
    <>
      <title>Wine tastings | Weingut Kieselbrunnen</title>
      <section className="mb-10 max-w-2xl">
        <p className="text-sm font-semibold tracking-widest text-gold uppercase">Autumn and winter 2026</p>
        <h1 className="mt-2 text-4xl leading-tight sm:text-5xl">Wine tastings at our family winery</h1>
        <p className="mt-4 text-lg text-muted">
          Taste our wines where they are made. Choose an evening below and reserve your seats online.
        </p>
      </section>
      {tastings.status === 'loading' && <Loading label="Loading tastings..." />}
      {tastings.status === 'error' && <ErrorAlert onRetry={reload}>{tastings.message}</ErrorAlert>}
      {tastings.status === 'ready' && (
        <ul className="grid gap-6 md:grid-cols-3">
          {tastings.data.map((tasting) => (
            <li key={tasting.id} className="flex">
              <TastingCard tasting={tasting} />
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

function TastingCard({ tasting }: { tasting: TastingDto }) {
  const full = tasting.seatsLeft === 0;
  const { day, month } = dateBadge(tasting.startsAt);
  return (
    <article className={`panel flex w-full flex-col gap-4 ${full ? 'bg-parchment/50' : ''}`}>
      <div className="flex items-start gap-4">
        <div aria-hidden="true" className="w-16 shrink-0 rounded-lg bg-wine py-2 text-center text-cream">
          <div className="font-serif text-2xl leading-none font-semibold">{day}</div>
          <div className="mt-1 text-xs tracking-widest">{month}</div>
        </div>
        <div>
          <h2 className="text-2xl leading-tight">{tasting.title}</h2>
          <p className="mt-1 text-muted">
            <time dateTime={tasting.startsAt}>{formatStart(tasting.startsAt)}</time>
          </p>
        </div>
      </div>
      <p>
        <span className="text-2xl font-semibold text-wine-dark">{formatEur(tasting.priceEur)}</span>{' '}
        <span className="text-muted">per guest</span>
      </p>
      <p
        className={`w-fit rounded-full border px-3 py-1 text-sm font-semibold ${
          full ? 'border-muted bg-white text-muted' : 'border-vine bg-vine-soft text-vine'
        }`}
      >
        {full ? <span aria-hidden="true">&#x2715; </span> : <span aria-hidden="true">&#x2713; </span>}
        {seatsLeftText(tasting.seatsLeft)}
      </p>
      <div className="mt-auto">
        {full ? (
          <button type="button" className="btn w-full" disabled>
            Fully booked
          </button>
        ) : (
          <Link to={`/book/${tasting.id}`} className="btn w-full">
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
