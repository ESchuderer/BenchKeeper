import { useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import type { StaffTastingDto } from '../../shared/booking';
import { ApiError, api } from '../api';
import { ErrorAlert, FieldError, Loading } from '../components/Feedback';
import { formatStart } from '../format';

type View = { name: 'loading' } | { name: 'signed-out'; notice?: string } | { name: 'signed-in'; groups: StaffTastingDto[] };

export function StaffPage() {
  const [view, setView] = useState<View>({ name: 'loading' });

  const loadBookings = async () => {
    try {
      setView({ name: 'signed-in', groups: await api.staffBookings() });
    } catch (err) {
      const ended = err instanceof ApiError && err.status === 401;
      setView({
        name: 'signed-out',
        notice: ended ? 'Your session has ended. Please sign in again.' : 'Could not load the bookings. Please sign in again.',
      });
    }
  };

  useEffect(() => {
    api
      .staffSession()
      .then((s) => (s.authenticated ? loadBookings() : setView({ name: 'signed-out' })))
      .catch(() => setView({ name: 'signed-out', notice: 'Could not reach the server. Please try again.' }));
  }, []);

  return (
    <>
      <title>Staff | Weingut Kieselbrunnen</title>
      {view.name === 'loading' && <Loading label="Loading..." />}
      {view.name === 'signed-out' && <SignIn notice={view.notice} onSignedIn={loadBookings} />}
      {view.name === 'signed-in' && (
        <Bookings groups={view.groups} reload={loadBookings} onSignedOut={() => setView({ name: 'signed-out' })} />
      )}
    </>
  );
}

function SignIn({ notice, onSignedIn }: { notice?: string; onSignedIn: () => Promise<void> }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>();

  const onSubmit = handleSubmit(async ({ password }) => {
    try {
      await api.login(password);
    } catch (err) {
      if (!(err instanceof ApiError)) throw err;
      return setError('password', { message: err.message }, { shouldFocus: true });
    }
    await onSignedIn();
  });

  const error = errors.password?.message;
  return (
    <section className="panel mx-auto max-w-md">
      <h1 className="text-3xl">Staff sign-in</h1>
      {notice && (
        <p role="status" className="mt-3 rounded-lg border border-gold bg-parchment/60 p-3">
          {notice}
        </p>
      )}
      <form onSubmit={onSubmit} noValidate className="mt-5 space-y-5">
        <div>
          <label htmlFor="password" className="mb-1 block font-semibold">
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className="field"
            aria-invalid={Boolean(error)}
            aria-describedby={error ? 'password-error' : undefined}
            {...register('password')}
          />
          <FieldError id="password-error">{error}</FieldError>
        </div>
        <button type="submit" className="btn w-full" disabled={isSubmitting}>
          Sign in
        </button>
      </form>
    </section>
  );
}

function Bookings({ groups, reload, onSignedOut }: { groups: StaffTastingDto[]; reload: () => Promise<void>; onSignedOut: () => void }) {
  const [status, setStatus] = useState<string>();
  const [error, setError] = useState<string>();
  const [pending, setPending] = useState<string>();
  const statusRef = useRef<HTMLParagraphElement>(null);
  useEffect(() => statusRef.current?.focus(), [status]);

  const cancel = async (reference: string, name: string) => {
    setError(undefined);
    setPending(reference);
    try {
      await api.cancel(reference);
      setStatus(`Cancelled the booking of ${name} (${reference}). Its seats are free again.`);
    } catch (err) {
      if (!(err instanceof ApiError)) throw err;
      if (err.status === 401) return onSignedOut();
      setStatus(undefined);
      setError(err.status === 404 ? 'That booking no longer exists.' : err.message);
    } finally {
      setPending(undefined);
    }
    await reload();
  };

  const signOut = async () => {
    await api.logout().catch(() => undefined);
    onSignedOut();
  };

  return (
    <>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl">Bookings</h1>
        <button type="button" className="btn-quiet" onClick={signOut}>
          Sign out
        </button>
      </div>
      {status && (
        <p ref={statusRef} tabIndex={-1} role="status" className="mb-4 rounded-lg border-2 border-vine bg-vine-soft p-3 font-medium text-vine outline-none">
          {status}
        </p>
      )}
      {error && (
        <div className="mb-4">
          <ErrorAlert>{error}</ErrorAlert>
        </div>
      )}
      <div className="space-y-8">
        {groups.map(({ tasting, bookings }) => (
          <section key={tasting.id} aria-labelledby={`h-${tasting.id}`} className="panel">
            <h2 id={`h-${tasting.id}`} className="text-2xl">
              {tasting.title}
            </h2>
            <p className="mt-1 text-muted">
              {formatStart(tasting.startsAt)} &middot; {tasting.capacity - tasting.seatsLeft} of {tasting.capacity} seats booked
            </p>
            {bookings.length === 0 ? (
              <p className="mt-4 text-muted">No bookings yet.</p>
            ) : (
              <table className="mt-4 w-full text-left">
                <thead className="max-sm:sr-only">
                  <tr className="border-b border-parchment text-sm text-muted">
                    <th className="py-2 pr-3 font-semibold">Name</th>
                    <th className="py-2 pr-3 font-semibold">Email</th>
                    <th className="py-2 pr-3 font-semibold">Guests</th>
                    <th className="py-2 pr-3 font-semibold">Reference</th>
                    <th className="py-2">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="max-sm:block">
                  {bookings.map((b) => (
                    <tr key={b.reference} className="border-b border-parchment last:border-0 max-sm:block max-sm:py-3">
                      <Cell label="Name" id={`name-${b.reference}`} className="font-semibold">
                        {b.name}
                      </Cell>
                      <Cell label="Email" className="break-all">
                        {b.email}
                      </Cell>
                      <Cell label="Guests">{b.guests}</Cell>
                      <Cell label="Reference" className="font-mono">
                        {b.reference}
                      </Cell>
                      <td className="py-2 max-sm:block max-sm:pt-2">
                        <button
                          type="button"
                          className="btn-quiet max-sm:w-full"
                          aria-describedby={`name-${b.reference}`}
                          disabled={pending === b.reference}
                          onClick={() => cancel(b.reference, b.name)}
                        >
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        ))}
      </div>
    </>
  );
}

function Cell({ label, id, className = '', children }: { label: string; id?: string; className?: string; children: React.ReactNode }) {
  return (
    <td
      id={id}
      data-label={label}
      className={`py-2 pr-3 max-sm:block max-sm:py-0.5 max-sm:before:mr-2 max-sm:before:text-sm max-sm:before:text-muted max-sm:before:content-[attr(data-label)':'] ${className}`}
    >
      {children}
    </td>
  );
}
