import { useCallback, useEffect, useState } from 'react';

export type AsyncState<T> = { status: 'loading' } | { status: 'error'; message: string } | { status: 'ready'; data: T };

// Runs `load` on mount and whenever the returned reload function is called.
export function useAsync<T>(load: () => Promise<T>): [AsyncState<T>, () => void] {
  const [state, setState] = useState<AsyncState<T>>({ status: 'loading' });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let current = true;
    setState((prev) => (prev.status === 'error' ? { status: 'loading' } : prev));
    load().then(
      (data) => current && setState({ status: 'ready', data }),
      (err: Error) => current && setState({ status: 'error', message: err.message }),
    );
    return () => {
      current = false;
    };
  }, [attempt]);

  return [state, useCallback(() => setAttempt((n) => n + 1), [])];
}
