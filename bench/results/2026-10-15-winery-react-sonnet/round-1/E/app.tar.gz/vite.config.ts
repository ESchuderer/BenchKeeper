import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: { outDir: 'dist/client' },
  server: { proxy: { '/api': 'http://localhost:3000' } },
  test: {
    include: ['server/**/*.test.ts', 'shared/**/*.test.ts'],
    coverage: { include: ['server/**', 'shared/**'], exclude: ['**/*.test.ts', 'server/index.ts'] },
  },
});
