# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings online; staff see and cancel bookings at `/staff`.

```
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start    # http://localhost:3000 (PORT overrides)
```

- `STAFF_PASSWORD` – staff password. If unset, the server starts but **all staff sign-ins are rejected**.
- `PORT` – default `3000`.
- `TRUST_PROXY` – number of reverse proxies in front of the app (e.g. `1`). Set it when deployed behind one, so the login rate limit sees real client IPs and the session cookie is marked `Secure` over HTTPS.
- Bookings live in memory: restarting the server clears them.

## Development

| Command | Purpose |
|---|---|
| `npm run dev` | Vite dev server + API with reload (API on :3000, UI on :5173) |
| `npm test` | Unit, API (supertest) and component tests (Vitest) |
| `npm run test:e2e` | Playwright against the built app (`npm run build` first; needs `npx playwright install chromium`) |
| `npm run typecheck` / `npm run lint` | TypeScript and ESLint |

Stack: Express 5, React 19, React Router, React Hook Form, Zod (shared validation), Tailwind CSS, Vite.
See `SPEC.md` for requirements and `tasks/` for the plan.

## API

```
GET    /api/tastings
POST   /api/bookings                 { tastingId, name, email, guests }  → 201 | 400 | 404 | 409  (errors: { field: message })
GET    /api/staff/session            → { signedIn }
POST   /api/staff/login   { password } → 204 | 401 | 429
POST   /api/staff/logout
GET    /api/staff/bookings           → grouped by tasting (401 without session)
DELETE /api/staff/bookings/:reference → 204 | 404
```
