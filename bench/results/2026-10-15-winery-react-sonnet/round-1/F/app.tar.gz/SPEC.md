# Spec: Weingut Kieselbrunnen – Tasting Booking App

## Objective

A small web app for the family winery Weingut Kieselbrunnen.

- **Guests** browse three tastings, book seats online and get a booking reference.
- **Staff** sign in with a shared password, see all bookings grouped by tasting and can cancel a booking (which frees its seats).

Success = a guest can book without help, seats can never be overbooked, staff always see the true state, and the site looks like a winery's own site, including on a phone.

### Tastings (fixed seed data, no admin UI)

| id | Title | Date and time | Price per guest | Seats |
|---|---|---|---|---|
| riesling-evening | Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| red-wine-cellar-tour | Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| winter-tasting | Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

### Guest acceptance criteria

1. `/` lists every tasting with title, date and time, "EUR <n>" per guest and "<n> seats left".
2. Each tasting has a link "Book <title>" (e.g. "Book Riesling Evening") opening `/book/:id`.
3. Form fields labelled "Name", "Email", "Guests" (integer 1–8) and a button "Book".
4. A booking never takes more seats than are left (enforced on the server, atomically, and reflected in the UI).
5. Invalid input is rejected with an error message next to the field it concerns (client-side and server-side; server field errors are shown at the same place).
6. Success shows the heading "Booking confirmed", the tasting, number of guests, total price (guests × price) and a booking reference.
7. Fully booked tastings show a clear "Fully booked" badge and "0 seats left". The "Book <title>" link stays available (every tasting has one); its booking page explains that the tasting is full, and a submitted booking is rejected with the message next to the Guests field.

### Staff acceptance criteria

1. `/staff` shows a "Password" field and a "Sign in" button when not signed in. The password is the env var `STAFF_PASSWORD`. Wrong password gives an error message.
2. Signed in, staff see all bookings grouped by tasting (name, email, guests, reference) with a "Cancel" button per booking. Empty tastings show "No bookings yet".
3. Cancel removes the booking and frees its seats (the start page shows the new count).
4. The bookings API is inaccessible without a staff session (401).

### Look and feel

Warm, wine-estate aesthetic (deep burgundy, cream, a muted gold/olive accent, a serif display font for headings, a clean sans for body). Consistent header/footer with the winery name. Clear visual states: field errors, success confirmation, fully booked badge, loading, server error. Responsive (mobile-first, usable at 360 px wide), accessible (labels, focus rings, `aria-describedby`/`aria-invalid` on errors, role="alert" for form-level errors, contrast ≥ WCAG AA).

## Assumptions (correct me or I proceed with these)

1. Single shared staff password, no user accounts. Staff session is an httpOnly, SameSite=Lax cookie (signed).
2. Bookings are kept **in memory** (restart = empty). No file or database persistence.
3. Times are the winery's local time; shown as written, with no timezone conversion.
4. Price display format is literally "EUR 25" and total "EUR 50", as in the brief.
5. No payment, no emails sent, no guest-side cancellation or lookup by reference (this keeps guest data private; the confirmation is shown once, right after booking).
6. A guest may make several bookings with the same email (no uniqueness rule).
7. Tastings stay bookable until full (no cutoff by date; all dates are in the future).
8. If `STAFF_PASSWORD` is unset, the server starts, logs a warning and **rejects every staff login** (fails closed, no default password).
9. Name: 1–100 characters after trimming. Email: valid format, ≤ 254 characters. Guests: integer 1–8, and ≤ seats left.
10. Modern evergreen browsers only. English UI only.

## Tech Stack

- Node.js 22, TypeScript (strict), npm.
- **Server:** Express 5 + `zod` (validation, shared with the client) + `helmet` + `express-rate-limit` (staff login) + `cookie-session` or `express-session` (staff session).
- **Client:** React 19 + Vite + React Router + React Hook Form (with `@hookform/resolvers/zod`) + Tailwind CSS.
- **Tests:** Vitest, React Testing Library, supertest, Playwright (end-to-end, against the built app).
- `npm start` runs the built server, which serves the API (`/api/*`) and the built client with SPA fallback on `PORT` (default 3000).

## Commands

```
Install:      npm install
Dev:          npm run dev            # Vite + server with reload
Build:        npm run build          # vite build + tsc server
Start:        npm start              # node dist/server/index.js on $PORT (default 3000)
Unit/API:     npm test               # vitest run
Watch:        npm run test:watch
E2E:          npm run test:e2e       # playwright against built app
Typecheck:    npm run typecheck
Lint:         npm run lint
```

## Project Structure

```
src/shared/      → zod schemas + types shared by client and server
src/server/      → Express app (app.ts), booking store (store.ts), routes, index.ts entry
src/client/      → React app: pages/, components/, api.ts, styles
tests/           → Vitest unit (store, validation), API (supertest), component tests
e2e/             → Playwright specs
dist/            → build output (git-ignored)
SPEC.md, tasks/  → spec, plan and todo
```

## API (draft)

```
GET    /api/tastings                 → [{ id, title, startsAt, pricePerGuest, seatsTotal, seatsLeft }]
POST   /api/bookings                 → 201 { reference, tasting, guests, total } | 400 { errors: { field: msg } } | 404 | 409 (not enough seats → errors.guests)
POST   /api/staff/login   {password} → 204 | 401
POST   /api/staff/logout             → 204
GET    /api/staff/bookings           → 200 grouped by tasting | 401
DELETE /api/staff/bookings/:ref      → 204 | 401 | 404
```

Seat check and insert happen in one synchronous store operation, so there is no race condition. Money is calculated from the server's price, never from client input. References are random (e.g. `KB-7QX4M2`), non-sequential.

## Code Style

TypeScript strict, ES modules, 2-space indent, single quotes, no semicolon-free tricks, small pure functions, named exports, components in `PascalCase.tsx`, everything else `camelCase.ts`.

```ts
export function book(input: BookingInput): BookingResult {
  const tasting = findTasting(input.tastingId);
  if (!tasting) return { ok: false, status: 404, errors: { tastingId: 'Unknown tasting' } };
  if (input.guests > seatsLeft(tasting)) {
    return { ok: false, status: 409, errors: { guests: `Only ${seatsLeft(tasting)} seats left` } };
  }
  // ...
}
```

## Testing Strategy

Tests first (red → green), per the TDD skill.

- **Unit (Vitest):** store (seat accounting, overbooking, cancel frees seats, reference uniqueness), validation schema (boundaries 0/1/8/9, empty name, bad email).
- **API (supertest):** all endpoints incl. auth (401 without session, wrong/right password, unset password), 400/409 field errors, atomic seat limits.
- **Component (RTL):** tasting list states (seats left, fully booked), booking form errors next to fields, confirmation.
- **E2E (Playwright, built app on a real port):** guest books → confirmation → start page seat count drops; overbooking rejected; staff sign in → sees booking → cancel → seats restored; mobile viewport check.
- Coverage: all acceptance criteria above map to at least one test; no numeric coverage gate.

## Boundaries

- **Always:** validate on the server as well as client; run `typecheck`, `lint`, `npm test` before declaring a task done; keep secrets in env only; escape/render user data as text (React default); keep UI accessible.
- **Ask first:** adding dependencies beyond the stack above, adding persistence, changing the data model or API contract, adding features not listed (emails, payments, guest cancellation).
- **Never:** commit or hard-code the staff password, log passwords or emails, trust client-sent prices/seat counts, skip or delete failing tests to get to green, use `dangerouslySetInnerHTML` with user data.

## Success Criteria

- A clean checkout runs `npm install && npm run build && STAFF_PASSWORD=x PORT=3000 npm start` and serves the whole app.
- Every guest and staff acceptance criterion above is covered by a passing automated test.
- Concurrent/over-limit requests never produce more than `seatsTotal` booked seats per tasting.
- Pages are usable at 360 px width (no horizontal scrolling, tap targets ≥ 44 px) and have no serious axe accessibility violations.
- Typecheck, lint, unit/API and e2e suites all pass.

## Open Questions

1. In-memory only is OK (bookings lost on restart)? Or do you want a local JSON file?
2. Should a booking be allowed for a tasting whose date has passed (currently yes, since none has)?
3. Any logo, brand colours or photos to use? Otherwise I'll create a typographic design with no imagery.
4. OK with the default of rejecting all staff logins if `STAFF_PASSWORD` is unset?

## Decisions made during the build (the user asked to proceed without a spec approval round)

- All open questions were resolved with the defaults above (in-memory store, no date cutoff, typographic design, fail-closed staff login).
- Seat texts follow the brief literally: "<n> seats left" for every n (so "1 seats left"); server error messages use correct singular/plural.
- The browser never decides seat availability: the client validates field rules only, the server's answer ("Only 2 seats left" / "This tasting is fully booked") is shown next to Guests and the displayed seat count is refreshed.
- Added `GET /api/staff/session` so the staff page does not trigger a 401 just by opening it.
- Login rate limit counts failed attempts only. Staff sessions expire server-side after 8 hours (`sessionMaxAgeMs`). `TRUST_PROXY` configures proxy trust. Staff responses are `no-store`.
- Known and accepted: the public booking endpoint has no rate limit or e-mail verification (a script could reserve all seats; staff can cancel). Logout clears the cookie but the stateless session cannot be revoked server-side before it expires. Adding limits or verification changes behaviour beyond the brief, so it is left for the owner to decide.
