import AxeBuilder from '@axe-core/playwright';
import { expect, test } from './fixtures';
import type { Page } from '@playwright/test';

const PASSWORD = 'e2e-secret';

async function book(page: Page, tasting: string, guests: number, name = 'Anna Weber') {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${tasting}` }).click();
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill(String(guests));
  await page.getByRole('button', { name: 'Book' }).click();
}

async function signIn(page: Page) {
  await page.goto('/staff');
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
}

async function cancelAll(page: Page) {
  await signIn(page);
  const buttons = page.getByRole('button', { name: 'Cancel' });
  while ((await buttons.count()) > 0) {
    const before = await buttons.count();
    await buttons.first().click();
    await expect(buttons).toHaveCount(before - 1);
  }
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
}

test.beforeEach(async ({ page }) => {
  await cancelAll(page);
});

test('guest sees the tastings, books, and gets a confirmation', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('12 seats left')).toBeVisible();
  await expect(page.getByText('EUR 32 per guest')).toBeVisible();

  await book(page, 'Winter Tasting', 3);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(page.getByText('EUR 84')).toBeVisible();
  await expect(page.getByText(/^KB-[A-Z0-9]{6}$/)).toBeVisible();

  await page.goto('/');
  await expect(page.getByText('7 seats left')).toBeVisible();
});

test('invalid input shows errors next to the fields', async ({ page }) => {
  await page.goto('/book/riesling-evening');
  await page.getByLabel('Email').fill('not-an-email');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription('Please enter your name');
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Please enter a valid email address');
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('Choose between 1 and 8 guests');
  const axe = await new AxeBuilder({ page }).analyze();
  expect(axe.violations).toEqual([]);
});

test('a booking can never take more seats than are left', async ({ page }) => {
  await book(page, 'Red Wine Cellar Tour', 8);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  const card = page.locator('article', { hasText: 'Red Wine Cellar Tour' });
  await expect(card.getByText('Fully booked')).toBeVisible();
  await expect(card.getByText('0 seats left')).toBeVisible();

  await book(page, 'Red Wine Cellar Tour', 1, 'Late Guest');
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('This tasting is fully booked');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
});

test('staff sign in, see bookings grouped by tasting and cancel to free the seats', async ({ page }) => {
  await book(page, 'Winter Tasting', 4, 'Ben Klein');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/staff');
  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByLabel('Password')).toHaveAccessibleDescription('Incorrect password');

  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  const winter = page.locator('section', { has: page.getByRole('heading', { name: 'Winter Tasting' }) });
  await expect(winter.getByText('Ben Klein')).toBeVisible();
  await expect(winter.getByText('anna@example.com')).toBeVisible();
  const axe = await new AxeBuilder({ page }).analyze();
  expect(axe.violations).toEqual([]);

  await winter.getByRole('button', { name: 'Cancel' }).click();
  await expect(winter.getByText('No bookings yet')).toBeVisible();

  await page.goto('/');
  await expect(page.getByText('10 seats left')).toBeVisible();
});

test('pages fit the screen without horizontal scrolling', async ({ page }) => {
  const overflow = () => page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
  expect(await overflow()).toBeLessThanOrEqual(0);
  await page.goto('/book/riesling-evening');
  await expect(page.getByLabel('Name')).toBeVisible();
  expect(await overflow()).toBeLessThanOrEqual(0);
  await book(page, 'Riesling Evening', 2, 'A Guest With A Rather Long Name Indeed');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  expect(await overflow()).toBeLessThanOrEqual(0);
  await signIn(page);
  expect(await overflow()).toBeLessThanOrEqual(0);
});

test('home page has no serious accessibility violations', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
  const axe = await new AxeBuilder({ page }).analyze();
  expect(axe.violations).toEqual([]);
});
