import { readFileSync } from 'node:fs';
import { test as base } from '@playwright/test';

export { expect } from '@playwright/test';

/**
 * Some headless Chromium builds without any system fonts (e.g. minimal containers) never apply
 * stylesheet-declared web fonts, so all text lays out with zero height. Registering the same font
 * files through the FontFace API makes such browsers render text like a normal desktop browser.
 * It changes nothing where fonts already load.
 */
const fontFiles = {
  'Fraunces Variable': 'node_modules/@fontsource-variable/fraunces/files/fraunces-latin-wght-normal.woff2',
  'Inter Variable': 'node_modules/@fontsource-variable/inter/files/inter-latin-wght-normal.woff2',
};
const fonts = Object.entries(fontFiles).map(([family, file]) => ({
  family,
  base64: readFileSync(file).toString('base64'),
}));

export const test = base.extend({
  page: async ({ page }, use) => {
    await page.addInitScript((list) => {
      for (const { family, base64 } of list) {
        const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
        const face = new FontFace(family, bytes.buffer, { weight: '100 900' });
        document.fonts.add(face);
        face.load().catch(() => undefined);
      }
    }, fonts);
    await use(page);
  },
});
