import type { BookingConfirmation, Tasting, TastingBookings } from '../shared/types';
import type { FieldErrors } from '../shared/schema';

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly errors: FieldErrors,
  ) {
    super(Object.values(errors)[0] ?? 'Request failed');
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      ...init,
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
    });
  } catch {
    throw new ApiError(0, { form: 'We could not reach the server. Please check your connection and try again.' });
  }
  if (res.status === 204) return undefined as T;
  const body = await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, body?.errors ?? { form: 'Something went wrong, please try again.' });
  if (body === null) throw new ApiError(res.status, { form: 'Something went wrong, please try again.' });
  return body as T;
}

const json = (method: string, body: unknown): RequestInit => ({ method, body: JSON.stringify(body) });

export const api = {
  listTastings: () => request<Tasting[]>('/api/tastings'),
  book: (input: { tastingId: string; name: string; email: string; guests: number }) =>
    request<BookingConfirmation>('/api/bookings', json('POST', input)),
  staffSession: () => request<{ signedIn: boolean }>('/api/staff/session'),
  staffLogin: (password: string) => request<void>('/api/staff/login', json('POST', { password })),
  staffLogout: () => request<void>('/api/staff/logout', { method: 'POST' }),
  staffBookings: () => request<TastingBookings[]>('/api/staff/bookings'),
  staffCancel: (reference: string) =>
    request<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' }),
};
