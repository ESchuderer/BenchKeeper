import type { ReactNode } from 'react';

const tones = {
  error: 'border-alarm-700 bg-alarm-100 text-alarm-700',
  notice: 'border-gold-deep bg-parchment text-ink',
  success: 'border-leaf-700 bg-leaf-100 text-leaf-700',
} as const;

export function Banner({ tone, children, role }: { tone: keyof typeof tones; children: ReactNode; role?: 'alert' | 'status' }) {
  return (
    <div role={role} className={`rounded-md border-l-4 px-4 py-3 text-base ${tones[tone]}`}>
      {children}
    </div>
  );
}
