import type { InputHTMLAttributes } from 'react';
import type { UseFormRegisterReturn } from 'react-hook-form';
import { AlertIcon } from './icons';

interface FieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'name' | 'onChange' | 'onBlur' | 'ref'> {
  label: string;
  registration: UseFormRegisterReturn;
  error?: string;
  hint?: string;
}

/** Labelled input with its error message directly beneath it. */
export function Field({ label, registration, error, hint, id, ...input }: FieldProps) {
  const fieldId = id ?? registration.name;
  const errorId = `${fieldId}-error`;
  const hintId = `${fieldId}-hint`;
  const describedBy = [error ? errorId : null, hint ? hintId : null].filter(Boolean).join(' ') || undefined;

  return (
    <div>
      <label htmlFor={fieldId} className="mb-1.5 block text-sm font-semibold text-wine-900">
        {label}
      </label>
      <input
        id={fieldId}
        className="input"
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        {...registration}
        {...input}
      />
      {hint && !error && (
        <p id={hintId} className="mt-1.5 text-sm text-muted">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} className="mt-1.5 flex gap-1.5 text-sm font-medium text-alarm-700">
          <AlertIcon />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}
