import { useEffect } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';

export function Layout() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo?.(0, 0);
  }, [pathname]);

  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-10 focus:rounded focus:bg-white focus:px-3 focus:py-2"
      >
        Skip to content
      </a>
      <header className="vine-rows border-b-4 border-gold text-cream">
        <div className="mx-auto flex max-w-5xl flex-col gap-1 px-4 py-5 sm:flex-row sm:items-end sm:justify-between">
          <Link to="/" className="rounded focus-visible:outline-gold">
            <span className="block text-xs font-semibold uppercase tracking-[0.25em] text-gold">Family winery</span>
            <span className="font-display text-3xl font-semibold leading-tight sm:text-4xl">Weingut Kieselbrunnen</span>
          </Link>
          <p className="text-sm text-cream/80">Wine tastings &amp; cellar tours</p>
        </div>
      </header>
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:py-12">
        <Outlet />
      </main>
      <footer className="border-t border-line bg-parchment">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-5 text-sm text-muted">
          <p>Weingut Kieselbrunnen · Please enjoy responsibly.</p>
          <Link to="/staff" className="rounded underline underline-offset-4 hover:text-wine-800">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
