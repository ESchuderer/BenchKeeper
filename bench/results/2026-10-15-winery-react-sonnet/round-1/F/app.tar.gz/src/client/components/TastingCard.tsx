import { Link } from 'react-router-dom';
import { describeStart, formatPrice, formatSeatsLeft } from '../format';
import type { Tasting } from '../../shared/types';

export function TastingCard({ tasting }: { tasting: Tasting }) {
  const start = describeStart(tasting.startsAt);
  const soldOut = tasting.seatsLeft <= 0;
  const fewLeft = !soldOut && tasting.seatsLeft <= 3;

  return (
    <article
      className={`flex flex-col gap-4 rounded-lg border bg-white p-5 shadow-sm sm:flex-row sm:items-center sm:gap-6 ${
        soldOut ? 'border-line opacity-95' : 'border-line hover:shadow-md'
      }`}
    >
      <div
        aria-hidden="true"
        className={`flex h-20 w-20 shrink-0 flex-col items-center justify-center rounded-md border-2 border-gold font-display ${
          soldOut ? 'bg-muted/80 text-cream' : 'bg-wine-800 text-cream'
        }`}
      >
        <span className="text-3xl font-semibold leading-none">{start.day}</span>
        <span className="mt-1 text-xs font-semibold uppercase tracking-widest text-gold">{start.month}</span>
      </div>

      <div className="flex-1">
        <h2 className="text-2xl font-semibold">{tasting.title}</h2>
        <p className="mt-1 text-muted">
          <time dateTime={tasting.startsAt}>
            {start.weekday} · {start.text}
          </time>
        </p>
        <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5">
          <span className="font-semibold text-wine-900">{formatPrice(tasting.pricePerGuest)} per guest</span>
          <span className="inline-flex items-center gap-2">
            {soldOut && (
              <span className="rounded-full bg-alarm-700 px-2.5 py-0.5 text-sm font-semibold text-white">Fully booked</span>
            )}
            <span className={fewLeft ? 'font-semibold text-alarm-700' : 'text-muted'}>
              {formatSeatsLeft(tasting.seatsLeft)}
            </span>
          </span>
        </p>
      </div>

      <Link
        to={`/book/${tasting.id}`}
        className={`btn sm:self-center ${soldOut ? 'btn-outline' : 'btn-primary'}`}
      >
        Book {tasting.title}
      </Link>
    </article>
  );
}
