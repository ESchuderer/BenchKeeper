const base = { width: 16, height: 16, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2.5, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true } as const;

export const AlertIcon = () => (
  <svg {...base} className="mt-0.5 shrink-0">
    <circle cx="12" cy="12" r="10" />
    <path d="M12 7v6M12 17h.01" />
  </svg>
);

export const ArrowLeftIcon = () => (
  <svg {...base} className="shrink-0">
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </svg>
);

export const CheckIcon = () => (
  <svg {...base} width={28} height={28} strokeWidth={3}>
    <path d="M5 13l4 4L19 7" />
  </svg>
);
