const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Splits a local `YYYY-MM-DDTHH:mm` timestamp without any timezone conversion. */
export function describeStart(startsAt: string) {
  const [date = '', time = ''] = startsAt.split('T');
  const [year = 0, month = 1, day = 1] = date.split('-').map(Number);
  return {
    weekday: WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()] ?? '',
    day,
    month: MONTHS[month - 1] ?? '',
    text: `${date} ${time}`,
  };
}

export const formatPrice = (euro: number) => `EUR ${euro}`;
export const formatSeatsLeft = (seats: number) => `${seats} seats left`;
