import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import type { Tasting } from '../shared/types';

type TastingsState = { status: 'loading' } | { status: 'error' } | { status: 'ready'; tastings: Tasting[] };

export function useTastings() {
  const [state, setState] = useState<TastingsState>({ status: 'loading' });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let ignore = false;
    api
      .listTastings()
      .then((tastings) => !ignore && setState({ status: 'ready', tastings }))
      .catch(() => !ignore && setState({ status: 'error' }));
    return () => {
      ignore = true;
    };
  }, [attempt]);

  /** Re-fetches without switching to the loading state, so forms stay mounted. */
  const refresh = useCallback(() => {
    api
      .listTastings()
      .then((tastings) => setState({ status: 'ready', tastings }))
      .catch(() => undefined);
  }, []);

  const reload = useCallback(() => {
    setState({ status: 'loading' });
    setAttempt((n) => n + 1);
  }, []);

  return { state, reload, refresh };
}
