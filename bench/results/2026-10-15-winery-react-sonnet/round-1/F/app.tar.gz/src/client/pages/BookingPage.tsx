import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Link, useParams } from 'react-router-dom';
import { z } from 'zod';
import { api, ApiError } from '../api';
import { Banner } from '../components/Banner';
import { Field } from '../components/Field';
import { ArrowLeftIcon, CheckIcon } from '../components/icons';
import { describeStart, formatPrice, formatSeatsLeft } from '../format';
import { useTastings } from '../hooks';
import { NotFoundPage } from './NotFoundPage';
import { bookingInputSchema, MAX_GUESTS_PER_BOOKING } from '../../shared/schema';
import type { BookingConfirmation, Tasting } from '../../shared/types';

const formFields = ['name', 'email', 'guests'] as const;

/**
 * Same field rules as the server. The seats left are deliberately not checked here: the count on screen
 * can be stale, so the server decides and its answer is shown next to the Guests field.
 */
const bookingFormSchema = bookingInputSchema.omit({ tastingId: true });

type FormInput = z.input<typeof bookingFormSchema>;
type FormOutput = z.output<typeof bookingFormSchema>;

export function BookingPage() {
  const { id } = useParams();
  const { state, reload, refresh } = useTastings();
  const [confirmation, setConfirmation] = useState<BookingConfirmation | null>(null);

  if (confirmation) return <Confirmation booking={confirmation} />;

  if (state.status === 'loading') {
    return (
      <p role="status" className="text-muted">
        Loading…
      </p>
    );
  }
  if (state.status === 'error') {
    return (
      <div className="flex flex-col items-start gap-4">
        <Banner tone="error" role="alert">
          We could not load this tasting. Please try again.
        </Banner>
        <button type="button" className="btn btn-primary" onClick={reload}>
          Try again
        </button>
      </div>
    );
  }

  const tasting = state.tastings.find((t) => t.id === id);
  if (!tasting) return <NotFoundPage what="tasting" />;
  return <BookingForm tasting={tasting} onBooked={setConfirmation} onSeatsChanged={refresh} />;
}

function BookingForm({
  tasting,
  onBooked,
  onSeatsChanged,
}: {
  tasting: Tasting;
  onBooked: (b: BookingConfirmation) => void;
  onSeatsChanged: () => void;
}) {
  const start = describeStart(tasting.startsAt);
  const soldOut = tasting.seatsLeft <= 0;
  const [formError, setFormError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormInput, unknown, FormOutput>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: { name: '', email: '', guests: 2 },
  });

  const onSubmit = async (values: FormOutput) => {
    setFormError(null);
    try {
      onBooked(await api.book({ tastingId: tasting.id, ...values }));
    } catch (err) {
      if (!(err instanceof ApiError)) throw err;
      if (err.status === 409) onSeatsChanged();
      let placed = false;
      for (const field of formFields) {
        const message = err.errors[field];
        if (message) {
          setError(field, { type: 'server', message }, { shouldFocus: !placed });
          placed = true;
        }
      }
      if (!placed) setFormError(Object.values(err.errors)[0] ?? 'Something went wrong, please try again.');
    }
  };

  return (
    <div className="mx-auto max-w-xl">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-medium text-wine-800 underline underline-offset-4">
        <ArrowLeftIcon />
        All tastings
      </Link>
      <h1 className="mt-3 text-3xl font-semibold sm:text-4xl">Book {tasting.title}</h1>
      <p className="mt-2 text-muted">
        <time dateTime={tasting.startsAt}>
          {start.weekday} · {start.text}
        </time>
        {' · '}
        {formatPrice(tasting.pricePerGuest)} per guest · {formatSeatsLeft(tasting.seatsLeft)}
      </p>

      {soldOut && (
        <div className="mt-5">
          <Banner tone="notice">This tasting is fully booked. Please have a look at our other dates.</Banner>
        </div>
      )}

      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="mt-6 flex flex-col gap-5 rounded-lg border border-line bg-white p-5 shadow-sm sm:p-7"
      >
        {formError && (
          <Banner tone="error" role="alert">
            {formError}
          </Banner>
        )}
        <Field label="Name" registration={register('name')} error={errors.name?.message} autoComplete="name" />
        <Field
          label="Email"
          type="email"
          registration={register('email')}
          error={errors.email?.message}
          autoComplete="email"
          inputMode="email"
        />
        <Field
          label="Guests"
          type="number"
          registration={register('guests', { valueAsNumber: true })}
          error={errors.guests?.message}
          min={1}
          max={MAX_GUESTS_PER_BOOKING}
          inputMode="numeric"
          hint={`1 to ${MAX_GUESTS_PER_BOOKING} guests per booking`}
        />
        <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
          Book
        </button>
        <p className="text-sm text-muted">
          We use your name and email only to manage your booking and to contact you about this tasting.
        </p>
      </form>
    </div>
  );
}

function Confirmation({ booking }: { booking: BookingConfirmation }) {
  const start = describeStart(booking.tasting.startsAt);
  return (
    <section className="mx-auto max-w-xl">
      <div className="rounded-lg border-2 border-leaf-700 bg-white p-6 shadow-sm sm:p-8">
        <p aria-hidden="true" className="flex h-12 w-12 items-center justify-center rounded-full bg-leaf-700 text-2xl text-white">
          <CheckIcon />
        </p>
        <h1 className="mt-4 text-3xl font-semibold sm:text-4xl">Booking confirmed</h1>
        <p className="mt-2 text-muted">Thank you! We look forward to welcoming you at the estate.</p>

        <dl className="mt-6 divide-y divide-line border-y border-line">
          <Row label="Tasting">
            <span>{booking.tasting.title}</span>
          </Row>
          <Row label="Date and time">
            <span>{`${start.weekday} · ${start.text}`}</span>
          </Row>
          <Row label="Guests">
            <span>{booking.guests}</span>
          </Row>
          <Row label="Total price">
            <span>{formatPrice(booking.total)}</span>
          </Row>
          <Row label="Booking reference">
            <span className="rounded bg-parchment px-2 py-0.5 text-lg font-semibold tabular-nums tracking-wider text-wine-900">
              {booking.reference}
            </span>
          </Row>
        </dl>
        <p className="mt-4 text-sm text-muted">Please keep your reference and quote it if you need to reach us.</p>
        <Link to="/" className="btn btn-outline mt-6">
          Back to tastings
        </Link>
      </div>
    </section>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5 py-3 sm:flex-row sm:items-baseline sm:justify-between">
      <dt className="text-sm font-semibold uppercase tracking-wide text-muted">{label}</dt>
      <dd className="text-lg font-medium text-ink sm:text-right">{children}</dd>
    </div>
  );
}
