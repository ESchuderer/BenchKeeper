import { Banner } from '../components/Banner';
import { TastingCard } from '../components/TastingCard';
import { useTastings } from '../hooks';

export function HomePage() {
  const { state, reload } = useTastings();

  return (
    <>
      <section className="mb-8 max-w-2xl">
        <h1 className="text-4xl font-semibold leading-tight sm:text-5xl">Wine tastings at the estate</h1>
        <p className="mt-4 text-lg text-muted">
          Join us in the cellar and at the long table for an evening with our family&rsquo;s wines. Pick a tasting and
          reserve your seats; we will pour the rest.
        </p>
        <div aria-hidden="true" className="mt-6 h-1 w-24 rounded bg-gold" />
      </section>

      {state.status === 'loading' && (
        <div role="status" className="flex flex-col gap-4">
          <span className="sr-only">Loading tastings…</span>
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-36 animate-pulse rounded-lg border border-line bg-parchment" />
          ))}
        </div>
      )}

      {state.status === 'error' && (
        <div className="flex flex-col items-start gap-4">
          <Banner tone="error" role="alert">
            We could not load the tastings. Please try again.
          </Banner>
          <button type="button" className="btn btn-primary" onClick={reload}>
            Try again
          </button>
        </div>
      )}

      {state.status === 'ready' && (
        <div className="flex flex-col gap-4">
          {state.tastings.map((tasting) => (
            <TastingCard key={tasting.id} tasting={tasting} />
          ))}
        </div>
      )}
    </>
  );
}
