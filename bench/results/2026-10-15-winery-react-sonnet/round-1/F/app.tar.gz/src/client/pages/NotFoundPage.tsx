import { Link } from 'react-router-dom';

export function NotFoundPage({ what = 'page' }: { what?: string }) {
  return (
    <section className="py-10 text-center">
      <h1 className="text-3xl font-semibold first-letter:uppercase">{what} not found</h1>
      <p className="mt-3 text-muted">It may have moved, or the link may be mistyped.</p>
      <Link to="/" className="btn btn-primary mt-6">
        Back to tastings
      </Link>
    </section>
  );
}
