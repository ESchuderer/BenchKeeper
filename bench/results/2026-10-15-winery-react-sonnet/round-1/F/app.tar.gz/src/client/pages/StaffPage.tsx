import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { api, ApiError } from '../api';
import { Banner } from '../components/Banner';
import { Field } from '../components/Field';
import { describeStart } from '../format';
import type { Booking, TastingBookings } from '../../shared/types';

type View =
  | { status: 'loading' }
  | { status: 'signedOut' }
  | { status: 'error'; message: string }
  | { status: 'ready'; groups: TastingBookings[] };

export function StaffPage() {
  const [view, setView] = useState<View>({ status: 'loading' });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let ignore = false;
    api
      .staffSession()
      .then(({ signedIn }) => (signedIn ? api.staffBookings() : null))
      .then((groups) => {
        if (ignore) return;
        setView(groups ? { status: 'ready', groups } : { status: 'signedOut' });
      })
      .catch((err: unknown) => {
        if (ignore) return;
        if (err instanceof ApiError && err.status === 401) setView({ status: 'signedOut' });
        else setView({ status: 'error', message: err instanceof ApiError ? err.message : 'Something went wrong.' });
      });
    return () => {
      ignore = true;
    };
  }, [attempt]);

  const refresh = useCallback(() => setAttempt((n) => n + 1), []);

  if (view.status === 'loading') {
    return (
      <p role="status" className="text-muted">
        Loading…
      </p>
    );
  }
  if (view.status === 'signedOut') return <SignIn onSignedIn={refresh} />;
  if (view.status === 'error') {
    return (
      <div className="flex flex-col items-start gap-4">
        <Banner tone="error" role="alert">
          {view.message}
        </Banner>
        <button type="button" className="btn btn-primary" onClick={refresh}>
          Try again
        </button>
      </div>
    );
  }
  return <Bookings groups={view.groups} onChanged={refresh} onSignedOut={() => setView({ status: 'signedOut' })} />;
}

function SignIn({ onSignedIn }: { onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } });
  const [formError, setFormError] = useState<string | null>(null);

  const onSubmit = async ({ password }: { password: string }) => {
    setFormError(null);
    try {
      await api.staffLogin(password);
      onSignedIn();
    } catch (err) {
      if (!(err instanceof ApiError)) throw err;
      if (err.errors.password) setError('password', { type: 'server', message: err.errors.password });
      else setFormError(Object.values(err.errors)[0] ?? 'Something went wrong.');
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <h1 className="text-3xl font-semibold">Staff sign in</h1>
      <p className="mt-2 text-muted">Bookings are visible to winery staff only.</p>
      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="mt-6 flex flex-col gap-5 rounded-lg border border-line bg-white p-5 shadow-sm sm:p-7"
      >
        {formError && (
          <Banner tone="error" role="alert">
            {formError}
          </Banner>
        )}
        <Field
          label="Password"
          type="password"
          registration={register('password')}
          error={errors.password?.message}
          autoComplete="current-password"
        />
        <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
          Sign in
        </button>
      </form>
    </div>
  );
}

function Bookings({
  groups,
  onChanged,
  onSignedOut,
}: {
  groups: TastingBookings[];
  onChanged: () => void;
  onSignedOut: () => void;
}) {
  const [error, setError] = useState<string | null>(null);
  // References are never reused, so a cancelled row can safely stay hidden until the refreshed list arrives.
  const [cancelled, setCancelled] = useState<ReadonlySet<string>>(new Set());
  const [cancelling, setCancelling] = useState<string | null>(null);

  const cancel = async (reference: string) => {
    setError(null);
    setCancelling(reference);
    try {
      await api.staffCancel(reference);
    } catch (err) {
      // 404: someone else already cancelled it, which is the outcome the user wanted.
      if (!(err instanceof ApiError && err.status === 404)) {
        if (err instanceof ApiError && err.status === 401) onSignedOut();
        else setError(err instanceof ApiError ? err.message : 'Something went wrong.');
        setCancelling(null);
        return;
      }
    }
    setCancelled((prev) => new Set(prev).add(reference));
    setCancelling(null);
    onChanged();
  };

  const signOut = async () => {
    await api.staffLogout().catch(() => undefined);
    onSignedOut();
  };

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-semibold sm:text-4xl">Bookings</h1>
        <button type="button" className="btn btn-outline" onClick={signOut}>
          Sign out
        </button>
      </div>

      {error && (
        <div className="mt-4">
          <Banner tone="error" role="alert">
            {error}
          </Banner>
        </div>
      )}

      <div className="mt-6 flex flex-col gap-6">
        {groups.map(({ tasting, bookings: allBookings }) => {
          const bookings = allBookings.filter((b) => !cancelled.has(b.reference));
          const booked = tasting.seatsTotal - tasting.seatsLeft;
          return (
            <section key={tasting.id} className="rounded-lg border border-line bg-white p-5 shadow-sm">
              <h2 className="text-2xl font-semibold">{tasting.title}</h2>
              <p className="mt-1 text-sm text-muted">
                {describeStart(tasting.startsAt).text} · {booked} of {tasting.seatsTotal} seats booked
              </p>
              {bookings.length === 0 ? (
                <p className="mt-4 rounded-md bg-parchment px-4 py-3 text-muted">No bookings yet</p>
              ) : (
                <BookingTable bookings={bookings} cancelling={cancelling} onCancel={cancel} />
              )}
            </section>
          );
        })}
      </div>
    </>
  );
}

function BookingTable({
  bookings,
  cancelling,
  onCancel,
}: {
  bookings: Booking[];
  cancelling: string | null;
  onCancel: (reference: string) => void;
}) {
  const cell = 'block px-0 py-1 before:mr-2 before:text-xs before:font-semibold before:uppercase before:text-muted before:content-[attr(data-label)] sm:table-cell sm:px-3 sm:py-3 sm:before:content-none';
  return (
    <table className="mt-4 block w-full text-left sm:table">
      <thead className="sr-only sm:not-sr-only sm:table-header-group">
        <tr className="border-b border-line text-sm text-muted sm:table-row">
          <th className="px-3 py-2 font-semibold">Name</th>
          <th className="px-3 py-2 font-semibold">Email</th>
          <th className="px-3 py-2 font-semibold">Guests</th>
          <th className="px-3 py-2 font-semibold">Reference</th>
          <th className="px-3 py-2">
            <span className="sr-only">Actions</span>
          </th>
        </tr>
      </thead>
      <tbody className="block sm:table-row-group">
        {bookings.map((b) => (
          <tr key={b.reference} className="block border-b border-line py-3 last:border-0 sm:table-row sm:py-0">
            <td data-label="Name" className={`${cell} font-medium`}>
              {b.name}
            </td>
            <td data-label="Email" className={`${cell} break-all`}>
              {b.email}
            </td>
            <td data-label="Guests" className={cell}>
              {b.guests}
            </td>
            <td data-label="Reference" className={`${cell} tabular-nums tracking-wide`}>
              {b.reference}
            </td>
            <td className="block pt-2 sm:table-cell sm:px-3 sm:py-2 sm:text-right">
              <button
                type="button"
                className="btn btn-danger"
                disabled={cancelling === b.reference}
                onClick={() => onCancel(b.reference)}
              >
                Cancel
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
