import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { existsSync } from 'node:fs';
import path from 'node:path';
import express, { type NextFunction, type Request, type RequestHandler, type Response } from 'express';
import cookieSession from 'cookie-session';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { bookingInputSchema, toFieldErrors } from '../shared/schema';
import type { BookingConfirmation } from '../shared/types';
import type { Store } from './store';

export interface AppOptions {
  store: Store;
  /** Shared staff password. When unset or empty, every staff login is rejected. */
  staffPassword: string | undefined;
  /** Directory with the built client; served with SPA fallback when it exists. */
  clientDir?: string;
  loginAttemptsPerWindow?: number;
  /** Staff session lifetime, enforced on the server. Defaults to 8 hours. */
  sessionMaxAgeMs?: number;
  /**
   * Number of reverse proxies in front of the app (Express `trust proxy`). Set it when deployed behind
   * one so client IPs (login rate limit) and HTTPS (Secure cookie) are detected correctly.
   */
  trustProxy?: number;
}

const digest = (value: string) => createHash('sha256').update(value).digest();

function passwordMatches(expected: string | undefined, given: unknown): boolean {
  if (!expected || typeof given !== 'string') return false;
  return timingSafeEqual(digest(expected), digest(given));
}

export function createApp({
  store,
  staffPassword,
  clientDir,
  loginAttemptsPerWindow = 10,
  sessionMaxAgeMs = 8 * 60 * 60 * 1000,
  trustProxy,
}: AppOptions) {
  const app = express();
  app.disable('x-powered-by');
  if (trustProxy) app.set('trust proxy', trustProxy);
  app.use(helmet());
  app.use(express.json({ limit: '10kb' }));
  app.use(
    cookieSession({
      name: 'kb_staff',
      keys: [randomBytes(32).toString('hex')],
      httpOnly: true,
      sameSite: 'lax',
      maxAge: sessionMaxAgeMs,
    }),
  );

  const api = express.Router();

  api.get('/tastings', (_req, res) => {
    res.json(store.listTastings());
  });

  api.post('/bookings', (req, res) => {
    const parsed = bookingInputSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      res.status(400).json({ errors: toFieldErrors(parsed.error) });
      return;
    }
    const result = store.book(parsed.data);
    if (!result.ok) {
      res.status(result.status).json({ errors: result.errors });
      return;
    }
    const { booking, tasting } = result;
    const confirmation: BookingConfirmation = {
      reference: booking.reference,
      tasting,
      guests: booking.guests,
      total: booking.total,
    };
    res.status(201).json(confirmation);
  });

  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: loginAttemptsPerWindow,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { errors: { password: 'Too many attempts, please try again later' } },
  });

  api.post('/staff/login', loginLimiter, (req, res) => {
    if (!passwordMatches(staffPassword, req.body?.password)) {
      res.status(401).json({ errors: { password: 'Incorrect password' } });
      return;
    }
    req.session = { staff: true, signedInAt: Date.now() };
    res.status(204).end();
  });

  // The cookie alone is not trusted for its lifetime: the sign-in time is checked here as well.
  const isStaff = (req: Request) =>
    req.session?.staff === true && Date.now() - Number(req.session.signedInAt) < sessionMaxAgeMs;

  api.use('/staff', (_req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });

  api.get('/staff/session', (req, res) => {
    res.json({ signedIn: isStaff(req) });
  });

  api.post('/staff/logout', (req, res) => {
    req.session = null;
    res.status(204).end();
  });

  const requireStaff: RequestHandler = (req, res, next) => {
    if (!isStaff(req)) {
      res.status(401).json({ errors: { form: 'Please sign in' } });
      return;
    }
    next();
  };

  api.get('/staff/bookings', requireStaff, (_req, res) => {
    res.json(store.listBookingsByTasting());
  });

  api.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
    const removed = store.cancel(String(req.params.reference));
    if (!removed) {
      res.status(404).json({ errors: { form: 'Booking not found' } });
      return;
    }
    res.status(204).end();
  });

  api.use((_req, res) => {
    res.status(404).json({ errors: { form: 'Not found' } });
  });

  app.use('/api', api);

  if (clientDir && existsSync(clientDir)) {
    app.use(express.static(clientDir));
    app.get('/{*splat}', (req, res) => {
      // Missing files (anything with an extension) are real 404s, not the app shell.
      if (path.extname(req.path)) {
        res.status(404).type('text/plain').send('Not found');
        return;
      }
      res.sendFile(path.join(clientDir, 'index.html'));
    });
  }

  app.use((err: Error & { status?: number; type?: string }, _req: Request, res: Response, next: NextFunction) => {
    if (res.headersSent) {
      next(err);
      return;
    }
    if (err.status && err.status >= 400 && err.status < 500) {
      res.status(err.status).json({ errors: { form: 'The request could not be read' } });
      return;
    }
    console.error(err);
    res.status(500).json({ errors: { form: 'Something went wrong, please try again' } });
  });

  return app;
}
