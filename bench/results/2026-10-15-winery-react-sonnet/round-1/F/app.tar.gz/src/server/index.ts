import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app';
import { createStore } from './store';

const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

const port = Number(process.env.PORT) || 3000;
const clientDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../client');

const trustProxy = Number(process.env.TRUST_PROXY) || undefined;
const app = createApp({ store: createStore(), staffPassword, clientDir, trustProxy });
app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings running on http://localhost:${port}`);
});
