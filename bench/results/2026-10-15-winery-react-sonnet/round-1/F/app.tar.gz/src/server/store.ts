import { randomInt } from 'node:crypto';
import { seatsMessage, type BookingInput, type FieldErrors } from '../shared/schema';
import type { Booking, Tasting, TastingBookings } from '../shared/types';

type TastingDefinition = Omit<Tasting, 'seatsLeft'>;

export const TASTINGS: readonly TastingDefinition[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuest: 25, seatsTotal: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuest: 32, seatsTotal: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuest: 28, seatsTotal: 10 },
];

export type BookResult =
  | { ok: true; booking: Booking; tasting: Pick<Tasting, 'id' | 'title' | 'startsAt'> }
  | { ok: false; status: 404 | 409; errors: FieldErrors };

// No 0/O/1/I so references are easy to read out over the phone.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function newReference(taken: Set<string>): string {
  for (;;) {
    let code = '';
    for (let i = 0; i < 6; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
    const reference = `KB-${code}`;
    if (!taken.has(reference)) return reference;
  }
}

export function createStore(definitions: readonly TastingDefinition[] = TASTINGS) {
  const bookings = new Map<string, Booking>();

  const seatsTaken = (tastingId: string) =>
    [...bookings.values()].filter((b) => b.tastingId === tastingId).reduce((sum, b) => sum + b.guests, 0);

  const withSeats = (d: TastingDefinition): Tasting => ({ ...d, seatsLeft: d.seatsTotal - seatsTaken(d.id) });

  return {
    listTastings: (): Tasting[] => definitions.map(withSeats),

    // Synchronous on purpose: check-then-insert cannot interleave with another request.
    book(input: BookingInput): BookResult {
      const definition = definitions.find((d) => d.id === input.tastingId);
      if (!definition) return { ok: false, status: 404, errors: { tastingId: 'Unknown tasting' } };

      const { seatsLeft } = withSeats(definition);
      if (input.guests > seatsLeft) {
        return { ok: false, status: 409, errors: { guests: seatsMessage(seatsLeft) } };
      }

      const booking: Booking = {
        reference: newReference(new Set(bookings.keys())),
        tastingId: definition.id,
        name: input.name,
        email: input.email,
        guests: input.guests,
        total: input.guests * definition.pricePerGuest,
      };
      bookings.set(booking.reference, booking);
      return { ok: true, booking, tasting: { id: definition.id, title: definition.title, startsAt: definition.startsAt } };
    },

    listBookingsByTasting: (): TastingBookings[] =>
      definitions.map((d) => ({
        tasting: withSeats(d),
        bookings: [...bookings.values()].filter((b) => b.tastingId === d.id),
      })),

    cancel: (reference: string): boolean => bookings.delete(reference),
  };
}

export type Store = ReturnType<typeof createStore>;
