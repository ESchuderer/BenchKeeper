import { z } from 'zod';

export const MAX_GUESTS_PER_BOOKING = 8;

const guestsMessage = `Choose between 1 and ${MAX_GUESTS_PER_BOOKING} guests`;

export const bookingInputSchema = z.object({
  tastingId: z.string({ error: 'Unknown tasting' }),
  name: z
    .string({ error: 'Please enter your name' })
    .trim()
    .min(1, 'Please enter your name')
    .max(100, 'Please use at most 100 characters'),
  email: z
    .string({ error: 'Please enter a valid email address' })
    .trim()
    .max(254, 'Please enter a valid email address')
    .pipe(z.email('Please enter a valid email address')),
  guests: z
    .number({ error: guestsMessage })
    .int(guestsMessage)
    .min(1, guestsMessage)
    .max(MAX_GUESTS_PER_BOOKING, guestsMessage),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;

export type FieldErrors = Partial<Record<string, string>>;

/** First message per field, keyed by field name. */
export function toFieldErrors(error: z.ZodError): FieldErrors {
  const errors: FieldErrors = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0] ?? 'form');
    errors[field] ??= issue.message;
  }
  return errors;
}

export function seatsMessage(seatsLeft: number): string {
  if (seatsLeft <= 0) return 'This tasting is fully booked';
  return `Only ${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left`;
}
