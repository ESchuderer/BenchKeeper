export interface Tasting {
  id: string;
  title: string;
  /** Local winery time, `YYYY-MM-DDTHH:mm` (no timezone conversion). */
  startsAt: string;
  pricePerGuest: number;
  seatsTotal: number;
  seatsLeft: number;
}

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  total: number;
}

export interface BookingConfirmation {
  reference: string;
  tasting: Pick<Tasting, 'id' | 'title' | 'startsAt'>;
  guests: number;
  total: number;
}

export interface TastingBookings {
  tasting: Tasting;
  bookings: Booking[];
}
