# Implementation Plan: Weingut Kieselbrunnen Tasting Bookings

Source: `/work/SPEC.md` (assumptions in the spec apply; the user asked to proceed without approval).

## Overview
Express 5 API + React 19 SPA (Vite, React Router, React Hook Form, Tailwind), in-memory store, single `npm start` process serving both.

## Architecture Decisions
- Shared zod schemas in `src/shared` are used by the server (authority) and the client form (fast feedback).
- Store is a plain module with synchronous `book`/`cancel`, so seat checks are atomic. `createApp(store, config)` factory enables isolated tests.
- Server errors use `{ errors: { field: message } }`; the form maps them onto fields.
- Confirmation is shown from the POST response (router state); no GET by reference.
- Staff auth: signed cookie session (`cookie-session`), constant-time password compare, login rate limit.

## Dependency graph
shared schemas/seed → store → API (guest) → client list/form/confirmation
                         └→ API (staff) → client staff page
design system (Tailwind theme/layout) underlies all client pages → polish & e2e last.

## Phases (vertical slices)
1. Foundation: scaffold + tooling, shared schema, store (TDD).
2. Guest slice: tastings + booking API, then list/form/confirmation UI.
3. Staff slice: auth + bookings/cancel API, then staff UI.
4. Polish and verification: design, responsive/a11y, e2e, build/start, review.

## Risks
| Risk | Impact | Mitigation |
|---|---|---|
| Overbooking under concurrency | High | Single synchronous store op; test with many parallel requests |
| Staff password leak / unset | High | env only; fail closed; no logging; constant-time compare |
| Express 5 / Vite / Tailwind 4 config drift | Med | Check installed versions' docs; build early (Task 1) |
| Field-error UX mismatch between client/server | Med | One schema; server errors mapped to fields; tests |

## Tasks
See `tasks/todo.md` (default task list target).
