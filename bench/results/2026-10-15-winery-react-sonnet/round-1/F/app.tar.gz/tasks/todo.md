# Task list

## Phase 1: Foundation
- [x] Task 1: Scaffold (package.json, tsconfig, vite, tailwind, vitest, eslint), `npm run build` + `npm start` serve a placeholder page
  - Acceptance: build passes; `npm start` honours PORT (default 3000) and serves SPA with fallback
  - Verify: `npm run build && npm start` + curl
- [x] Task 2: Shared schema + store with seed tastings (tests first)
  - Acceptance: seat accounting, overbooking rejected, cancel frees seats, refs unique, validation boundaries 0/1/8/9, bad email, blank name
  - Verify: `npm test`

### Checkpoint: Foundation — tests + build green

## Phase 2: Guest slice
- [x] Task 3: API `GET /api/tastings`, `POST /api/bookings` (supertest first; 400/404/409 field errors, 201 payload)
- [x] Task 4: Start page: list with title, date/time, "EUR n", "<n> seats left", "Book <title>", "Fully booked" state
- [x] Task 5: Booking form + confirmation (field errors next to fields, server errors mapped, "Booking confirmed", total, ref)

### Checkpoint: guest flow works end to end in browser

## Phase 3: Staff slice
- [x] Task 6: Staff API: login/logout/session, list grouped, cancel; 401 without session; unset password fails closed; rate limit
- [x] Task 7: `/staff` UI: Password + Sign in, grouped bookings, Cancel, empty state, error state

### Checkpoint: staff flow works; cancel frees seats on start page

## Phase 4: Polish and verify
- [x] Task 8: Visual design pass (theme, header/footer, states, 360px mobile), a11y
- [x] Task 9: Playwright e2e for guest + staff + mobile; run axe
- [x] Task 10: Code review + security review; fix findings; README; final `npm install && build && start` check

### Checkpoint: Complete — all acceptance criteria covered by passing tests
