import { mkdtemp, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import request from 'supertest';
import { createApp } from '../src/server/app';
import { createStore } from '../src/server/store';

const PASSWORD = 'correct horse';
const valid = { tastingId: 'riesling-evening', name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

function setup(staffPassword: string | undefined = PASSWORD) {
  const store = createStore();
  const app = createApp({ store, staffPassword, loginAttemptsPerWindow: 1000 });
  return { app, store };
}

async function signedInAgent(app: ReturnType<typeof setup>['app']) {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(204);
  return agent;
}

describe('GET /api/tastings', () => {
  it('lists the tastings with seats left', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/tastings').expect(200);
    expect(res.body).toHaveLength(3);
    expect(res.body[0]).toMatchObject({ id: 'riesling-evening', title: 'Riesling Evening', pricePerGuest: 25, seatsLeft: 12 });
  });
});

describe('POST /api/bookings', () => {
  it('creates a booking and returns the confirmation', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/bookings').send(valid).expect(201);
    expect(res.body).toMatchObject({
      guests: 2,
      total: 50,
      tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00' },
    });
    expect(res.body.reference).toMatch(/^KB-/);
    expect(res.body.email).toBeUndefined();
    const tastings = await request(app).get('/api/tastings');
    expect(tastings.body[0].seatsLeft).toBe(10);
  });

  it('rejects invalid input with errors keyed by field and books nothing', async () => {
    const { app, store } = setup();
    const res = await request(app)
      .post('/api/bookings')
      .send({ ...valid, name: '', email: 'nope', guests: 9 })
      .expect(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
    expect(store.listTastings()[0]?.seatsLeft).toBe(12);
  });

  it('ignores a client-sent total', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/bookings').send({ ...valid, total: 1 }).expect(201);
    expect(res.body.total).toBe(50);
  });

  it('answers 404 for an unknown tasting', async () => {
    const { app } = setup();
    await request(app).post('/api/bookings').send({ ...valid, tastingId: 'nope' }).expect(404);
  });

  it('answers 409 with a message on guests when there are not enough seats', async () => {
    const { app } = setup();
    await request(app).post('/api/bookings').send({ ...valid, tastingId: 'red-wine-cellar-tour', guests: 7 }).expect(201);
    const res = await request(app)
      .post('/api/bookings')
      .send({ ...valid, tastingId: 'red-wine-cellar-tour', guests: 2 })
      .expect(409);
    expect(res.body.errors.guests).toBe('Only 1 seat left');
  });

  it('accepts exactly as many bookings as seats allow when requests are fired concurrently', async () => {
    const { app } = setup();
    const results = await Promise.all(
      Array.from({ length: 12 }, () => request(app).post('/api/bookings').send({ ...valid, guests: 3 })),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(4);
    const tastings = await request(app).get('/api/tastings');
    expect(tastings.body[0].seatsLeft).toBe(0);
  });

  it('answers 400 with a form error for malformed JSON', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/bookings').set('Content-Type', 'application/json').send('{oops').expect(400);
    expect(res.body.errors.form).toBeDefined();
  });

  it('answers 400 for a missing body', async () => {
    const { app } = setup();
    await request(app).post('/api/bookings').expect(400);
  });
});

describe('staff authentication', () => {
  it('rejects staff endpoints without a session', async () => {
    const { app } = setup();
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete('/api/staff/bookings/KB-AAAAAA').expect(401);
  });

  it('rejects a wrong password and does not sign in', async () => {
    const { app } = setup();
    const agent = request.agent(app);
    const res = await agent.post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    expect(res.body.errors.password).toBe('Incorrect password');
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('signs in with the right password using an httpOnly cookie', async () => {
    const { app } = setup();
    const res = await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(204);
    const cookies = ([] as string[]).concat(res.headers['set-cookie'] ?? []).join(';');
    expect(cookies).toMatch(/httponly/i);
    expect(cookies).toMatch(/samesite=lax/i);
  });

  it('signs out', async () => {
    const { app } = setup();
    const agent = await signedInAgent(app);
    await agent.get('/api/staff/bookings').expect(200);
    await agent.post('/api/staff/logout').expect(204);
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('rejects every login when STAFF_PASSWORD is unset or empty', async () => {
    for (const pw of [undefined, '']) {
      const { app } = setup(pw);
      await request(app).post('/api/staff/login').send({ password: '' }).expect(401);
      await request(app).post('/api/staff/login').send({ password: 'undefined' }).expect(401);
    }
  });

  it('rejects a non-string password', async () => {
    const { app } = setup();
    await request(app).post('/api/staff/login').send({ password: { $ne: 1 } }).expect(401);
  });

  it('rate limits repeated login attempts', async () => {
    const app = createApp({ store: createStore(), staffPassword: PASSWORD, loginAttemptsPerWindow: 3 });
    const statuses: number[] = [];
    for (let i = 0; i < 5; i++) statuses.push((await request(app).post('/api/staff/login').send({ password: 'x' })).status);
    expect(statuses).toEqual([401, 401, 401, 429, 429]);
  });
});

describe('staff bookings', () => {
  it('lists bookings grouped by tasting', async () => {
    const { app } = setup();
    await request(app).post('/api/bookings').send(valid).expect(201);
    const agent = await signedInAgent(app);
    const res = await agent.get('/api/staff/bookings').expect(200);
    expect(res.body).toHaveLength(3);
    expect(res.body[0].tasting.title).toBe('Riesling Evening');
    expect(res.body[0].bookings[0]).toMatchObject({ name: 'Anna Weber', email: 'anna@example.com', guests: 2 });
    expect(res.body[1].bookings).toEqual([]);
  });

  it('cancels a booking and frees its seats', async () => {
    const { app } = setup();
    const booked = await request(app).post('/api/bookings').send(valid).expect(201);
    const agent = await signedInAgent(app);
    await agent.delete(`/api/staff/bookings/${booked.body.reference}`).expect(204);
    const tastings = await request(app).get('/api/tastings');
    expect(tastings.body[0].seatsLeft).toBe(12);
    await agent.delete(`/api/staff/bookings/${booked.body.reference}`).expect(404);
  });
});

describe('misc', () => {
  it('answers unknown API routes with JSON 404', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/nope').expect(404);
    expect(res.body.errors.form).toBeDefined();
  });

  it('sets security headers', async () => {
    const { app } = setup();
    const res = await request(app).get('/api/tastings');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });
});

describe('static client', () => {
  it('serves index.html for app routes but 404 for missing files', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'client-'));
    await writeFile(path.join(dir, 'index.html'), '<!doctype html><title>app</title>');
    const app = createApp({ store: createStore(), staffPassword: PASSWORD, clientDir: dir });
    const route = await request(app).get('/book/winter-tasting').expect(200);
    expect(route.text).toContain('<title>app</title>');
    await request(app).get('/staff').expect(200);
    await request(app).get('/assets/missing.js').expect(404);
  });
});

describe('GET /api/staff/session', () => {
  it('reports whether the visitor is signed in, without an error status', async () => {
    const { app } = setup();
    const anonymous = await request(app).get('/api/staff/session').expect(200);
    expect(anonymous.body).toEqual({ signedIn: false });
    const agent = await signedInAgent(app);
    expect((await agent.get('/api/staff/session').expect(200)).body).toEqual({ signedIn: true });
  });
});

describe('login rate limit', () => {
  it('only counts failed attempts, so staff signing in repeatedly are never locked out', async () => {
    const app = createApp({ store: createStore(), staffPassword: PASSWORD, loginAttemptsPerWindow: 3 });
    for (let i = 0; i < 6; i++) await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(204);
  });
});

describe('hardening', () => {
  it('marks staff responses as no-store', async () => {
    const { app } = setup();
    const agent = await signedInAgent(app);
    expect((await agent.get('/api/staff/bookings')).headers['cache-control']).toBe('no-store');
    expect((await agent.get('/api/staff/session')).headers['cache-control']).toBe('no-store');
  });

  it('rejects a replayed session cookie once the maximum age has passed', async () => {
    const app = createApp({ store: createStore(), staffPassword: PASSWORD, sessionMaxAgeMs: 300 });
    const login = await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(204);
    const cookie = ([] as string[]).concat(login.headers['set-cookie'] ?? []).map((c) => c.split(';')[0] ?? '');
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(200);
    await new Promise((resolve) => setTimeout(resolve, 400));
    await request(app).get('/api/staff/bookings').set('Cookie', cookie).expect(401);
    const session = await request(app).get('/api/staff/session').set('Cookie', cookie);
    expect(session.body).toEqual({ signedIn: false });
  });

  it('answers unsupported body encodings with their 4xx status, not 500', async () => {
    const { app } = setup();
    const res = await request(app)
      .post('/api/bookings')
      .set('Content-Type', 'application/json')
      .set('Content-Encoding', 'unknown')
      .send('{}');
    expect(res.status).toBe(415);
    expect(res.body.errors.form).toBeDefined();
  });

  it('uses the client address from X-Forwarded-For only when trustProxy is configured', async () => {
    const limited = (trustProxy?: number) =>
      createApp({ store: createStore(), staffPassword: PASSWORD, loginAttemptsPerWindow: 1, trustProxy });
    const attempt = (app: ReturnType<typeof limited>, ip: string) =>
      request(app).post('/api/staff/login').set('X-Forwarded-For', ip).send({ password: 'x' });

    const proxied = limited(1);
    expect((await attempt(proxied, '1.1.1.1')).status).toBe(401);
    expect((await attempt(proxied, '2.2.2.2')).status).toBe(401);
    expect((await attempt(proxied, '1.1.1.1')).status).toBe(429);
  });
});
