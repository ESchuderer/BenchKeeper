// @vitest-environment jsdom
import { cleanup, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { App } from '../src/client/App';
import { STAFF_PASSWORD, startTestServer, type TestServer } from './helpers';

let server: TestServer;
beforeEach(async () => {
  server = await startTestServer();
});
afterEach(async () => {
  cleanup();
  await server.close();
});

function renderAt(path: string) {
  render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
  return userEvent.setup();
}

async function fillAndBook(user: ReturnType<typeof userEvent.setup>, over: { name?: string; email?: string; guests?: string } = {}) {
  const name = screen.getByLabelText('Name');
  const email = screen.getByLabelText('Email');
  const guests = screen.getByLabelText('Guests');
  await user.clear(name);
  await user.type(name, over.name ?? 'Anna Weber');
  await user.clear(email);
  await user.type(email, over.email ?? 'anna@example.com');
  await user.clear(guests);
  if (over.guests !== '') await user.type(guests, over.guests ?? '2');
  await user.click(screen.getByRole('button', { name: 'Book' }));
}

describe('start page', () => {
  it('lists the tastings with date, time, price and seats left', async () => {
    renderAt('/');
    const card = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('article')!;
    expect(within(card).getByText(/2026-11-06 18:00/)).toBeInTheDocument();
    expect(within(card).getByText(/EUR 25/)).toBeInTheDocument();
    expect(within(card).getByText('12 seats left')).toBeInTheDocument();
    expect(await screen.findByText('8 seats left')).toBeInTheDocument();
    expect(screen.getByText('10 seats left')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toHaveAttribute('href', '/book/riesling-evening');
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toBeInTheDocument();
  });

  it('marks a sold-out tasting as fully booked', async () => {
    server.store.book({ tastingId: 'red-wine-cellar-tour', guests: 8, name: 'A', email: 'a@b.de' });
    renderAt('/');
    const card = (await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' })).closest('article')!;
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(within(card).getByText('0 seats left')).toBeInTheDocument();
  });

  it('shows an error with a retry when the tastings cannot be loaded', async () => {
    await server.close();
    renderAt('/');
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument();
    server = await startTestServer();
  });
});

describe('booking form', () => {
  it('has labelled Name, Email and Guests fields and a Book button', async () => {
    renderAt('/book/riesling-evening');
    expect(await screen.findByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument();
    expect(screen.getByText(/only to manage your booking/i)).toBeInTheDocument();
  });

  it('shows errors next to each invalid field and books nothing', async () => {
    const user = renderAt('/book/riesling-evening');
    await screen.findByLabelText('Name');
    await fillAndBook(user, { name: ' ', email: 'nope', guests: '9' });
    const name = screen.getByLabelText('Name');
    const email = screen.getByLabelText('Email');
    const guests = screen.getByLabelText('Guests');
    expect(name).toHaveAccessibleDescription('Please enter your name');
    expect(email).toHaveAccessibleDescription('Please enter a valid email address');
    expect(guests).toHaveAccessibleDescription('Choose between 1 and 8 guests');
    expect(name).toBeInvalid();
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
    expect(server.store.listTastings()[0]?.seatsLeft).toBe(12);
  });

  it('rejects an empty guests field', async () => {
    const user = renderAt('/book/riesling-evening');
    await screen.findByLabelText('Name');
    await fillAndBook(user, { guests: '' });
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Choose between 1 and 8 guests');
  });

  it('rejects more guests than seats left, next to the Guests field', async () => {
    server.store.book({ tastingId: 'red-wine-cellar-tour', guests: 7, name: 'A', email: 'a@b.de' });
    const user = renderAt('/book/red-wine-cellar-tour');
    await screen.findByLabelText('Name');
    await fillAndBook(user, { guests: '3' });
    await waitFor(() => expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Only 1 seat left'));
    expect(server.store.listTastings()[1]?.seatsLeft).toBe(1);
  });

  it('shows the server error on Guests when seats were taken in the meantime', async () => {
    const user = renderAt('/book/red-wine-cellar-tour');
    await screen.findByLabelText('Name');
    server.store.book({ tastingId: 'red-wine-cellar-tour', guests: 7, name: 'A', email: 'a@b.de' });
    await fillAndBook(user, { guests: '3' });
    expect(await screen.findByText('Only 1 seat left')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Only 1 seat left');
    expect(await screen.findByText(/1 seats left/)).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Weber');
  });

  it('lets the guest book seats that were freed after the page loaded', async () => {
    const taken = server.store.book({ tastingId: 'red-wine-cellar-tour', guests: 7, name: 'A', email: 'a@b.de' });
    if (!taken.ok) throw new Error('setup failed');
    const user = renderAt('/book/red-wine-cellar-tour');
    await screen.findByLabelText('Name');
    server.store.cancel(taken.booking.reference);
    await fillAndBook(user, { guests: '3' });
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
  });

  it('shows a fully booked notice for a sold-out tasting and still rejects a booking', async () => {
    server.store.book({ tastingId: 'red-wine-cellar-tour', guests: 8, name: 'A', email: 'a@b.de' });
    const user = renderAt('/book/red-wine-cellar-tour');
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    await fillAndBook(user, { guests: '1' });
    await waitFor(() =>
      expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('This tasting is fully booked'),
    );
  });

  it('confirms a booking with tasting, guests, total and reference', async () => {
    const user = renderAt('/book/red-wine-cellar-tour');
    await screen.findByLabelText('Name');
    await fillAndBook(user, { guests: '3' });
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Red Wine Cellar Tour')).toBeInTheDocument();
    expect(screen.getByText('EUR 96')).toBeInTheDocument();
    expect(screen.getByText(/^KB-[A-Z0-9]{6}$/)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /back to tastings/i })).toBeInTheDocument();
    expect(server.store.listTastings()[1]?.seatsLeft).toBe(5);
  });

  it('shows not found for an unknown tasting', async () => {
    renderAt('/book/nope');
    expect(await screen.findByRole('heading', { name: /not found/i })).toBeInTheDocument();
  });
});

describe('staff page', () => {
  async function signIn(user: ReturnType<typeof userEvent.setup>, password = STAFF_PASSWORD) {
    await user.type(await screen.findByLabelText('Password'), password);
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
  }

  it('asks for the password first', async () => {
    renderAt('/staff');
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });

  it('shows an error next to the password field for a wrong password', async () => {
    const user = renderAt('/staff');
    await signIn(user, 'wrong');
    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription('Incorrect password');
  });

  it('lists bookings grouped by tasting and cancels one, freeing the seats', async () => {
    server.store.book({ tastingId: 'riesling-evening', guests: 2, name: 'Anna Weber', email: 'anna@example.com' });
    const booked = server.store.book({ tastingId: 'winter-tasting', guests: 4, name: 'Ben Klein', email: 'ben@example.com' });
    if (!booked.ok) throw new Error('setup failed');
    const user = renderAt('/staff');
    await signIn(user);

    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section')!;
    expect(within(riesling).getByText('Anna Weber')).toBeInTheDocument();
    expect(within(riesling).getByText('anna@example.com')).toBeInTheDocument();
    const winter = screen.getByRole('heading', { name: 'Winter Tasting' }).closest('section')!;
    expect(within(winter).getByText(booked.booking.reference)).toBeInTheDocument();
    const cellar = screen.getByRole('heading', { name: 'Red Wine Cellar Tour' }).closest('section')!;
    expect(within(cellar).getByText('No bookings yet')).toBeInTheDocument();

    await user.click(within(winter).getByRole('button', { name: 'Cancel' }));
    expect(await within(winter).findByText('No bookings yet')).toBeInTheDocument();
    expect(server.store.listTastings()[2]?.seatsLeft).toBe(10);
    expect(within(riesling).getByText('Anna Weber')).toBeInTheDocument();
  });

  it('treats cancelling an already cancelled booking as done, without an error', async () => {
    const booked = server.store.book({ tastingId: 'winter-tasting', guests: 2, name: 'Ben Klein', email: 'ben@example.com' });
    if (!booked.ok) throw new Error('setup failed');
    const user = renderAt('/staff');
    await signIn(user);
    const winter = (await screen.findByRole('heading', { name: 'Winter Tasting' })).closest('section')!;
    server.store.cancel(booked.booking.reference); // another staff member got there first
    await user.click(within(winter).getByRole('button', { name: 'Cancel' }));
    expect(await within(winter).findByText('No bookings yet')).toBeInTheDocument();
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
  });

  it('signs out', async () => {
    const user = renderAt('/staff');
    await signIn(user);
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });
});
