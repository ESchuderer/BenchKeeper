import type { AddressInfo } from 'node:net';
import type { Server } from 'node:http';
import { createApp } from '../src/server/app';
import { createStore, type Store } from '../src/server/store';

export const STAFF_PASSWORD = 'riesling-2026';

export interface TestServer {
  store: Store;
  close: () => Promise<void>;
}

/**
 * Starts the real Express app on a random port and routes the jsdom `fetch`
 * to it (with a tiny cookie jar), so component tests exercise the real API.
 */
export async function startTestServer(): Promise<TestServer> {
  const store = createStore();
  const app = createApp({ store, staffPassword: STAFF_PASSWORD, loginAttemptsPerWindow: 1000 });
  const server: Server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const realFetch = globalThis.fetch;
  const jar = new Map<string, string>();

  globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input), baseUrl);
    const headers = new Headers(init?.headers);
    if (jar.size) headers.set('cookie', [...jar].map(([k, v]) => `${k}=${v}`).join('; '));
    const res = await realFetch(url, { ...init, headers });
    for (const line of res.headers.getSetCookie()) {
      const [pair = ''] = line.split(';');
      const [name = '', ...value] = pair.split('=');
      if (value.join('=') === '') jar.delete(name);
      else jar.set(name, value.join('='));
    }
    return res;
  }) as typeof fetch;

  return {
    store,
    close: async () => {
      globalThis.fetch = realFetch;
      await new Promise<void>((resolve) => server.close(() => resolve()));
    },
  };
}
