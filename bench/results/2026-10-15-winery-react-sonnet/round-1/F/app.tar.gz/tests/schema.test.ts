import { bookingInputSchema, toFieldErrors } from '../src/shared/schema';

const valid = { tastingId: 'riesling-evening', name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

function errorsFor(input: unknown) {
  const result = bookingInputSchema.safeParse(input);
  return result.success ? {} : toFieldErrors(result.error);
}

describe('bookingInputSchema', () => {
  it('accepts a valid booking and trims the name', () => {
    const result = bookingInputSchema.safeParse({ ...valid, name: '  Anna Weber  ' });
    expect(result.success && result.data.name).toBe('Anna Weber');
  });

  it.each([1, 8])('accepts %i guests', (guests) => {
    expect(errorsFor({ ...valid, guests })).toEqual({});
  });

  it.each([0, 9, -1, 2.5, Number.NaN])('rejects %s guests with a message on guests', (guests) => {
    expect(errorsFor({ ...valid, guests }).guests).toMatch(/1 and 8/);
  });

  it('rejects guests sent as a string', () => {
    expect(errorsFor({ ...valid, guests: '2' }).guests).toBeDefined();
  });

  it('rejects a blank name', () => {
    expect(errorsFor({ ...valid, name: '   ' }).name).toBe('Please enter your name');
  });

  it('rejects a name over 100 characters', () => {
    expect(errorsFor({ ...valid, name: 'a'.repeat(101) }).name).toBeDefined();
  });

  it.each(['', 'anna', 'anna@', '@example.com', 'a b@example.com'])('rejects email %j', (email) => {
    expect(errorsFor({ ...valid, email }).email).toBe('Please enter a valid email address');
  });

  it('reports every invalid field at once', () => {
    expect(Object.keys(errorsFor({ ...valid, name: '', email: 'x', guests: 0 })).sort()).toEqual([
      'email',
      'guests',
      'name',
    ]);
  });
});
