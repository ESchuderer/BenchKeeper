import { createStore, TASTINGS } from '../src/server/store';

const guest = { name: 'Anna Weber', email: 'anna@example.com' };

describe('store', () => {
  it('starts with the three tastings, all seats free, and no bookings', () => {
    const store = createStore();
    expect(store.listTastings().map((t) => [t.id, t.title, t.startsAt, t.pricePerGuest, t.seatsLeft])).toEqual([
      ['riesling-evening', 'Riesling Evening', '2026-11-06T18:00', 25, 12],
      ['red-wine-cellar-tour', 'Red Wine Cellar Tour', '2026-11-14T15:00', 32, 8],
      ['winter-tasting', 'Winter Tasting', '2026-12-05T17:00', 28, 10],
    ]);
    expect(store.listBookingsByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });

  it('books seats, computes the total from the server price and reduces seats left', () => {
    const store = createStore();
    const result = store.book({ tastingId: 'riesling-evening', guests: 3, ...guest });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.booking.total).toBe(75);
    expect(result.booking.reference).toMatch(/^KB-[A-Z0-9]{6}$/);
    expect(result.tasting).toMatchObject({ id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00' });
    expect(store.listTastings()[0]?.seatsLeft).toBe(9);
  });

  it('rejects an unknown tasting with 404', () => {
    const result = createStore().book({ tastingId: 'nope', guests: 1, ...guest });
    expect(result).toMatchObject({ ok: false, status: 404 });
  });

  it('rejects a booking that exceeds the seats left with 409 on guests', () => {
    const store = createStore();
    store.book({ tastingId: 'red-wine-cellar-tour', guests: 8, ...guest });
    store.book({ tastingId: 'winter-tasting', guests: 8, ...guest });
    const result = store.book({ tastingId: 'winter-tasting', guests: 3, ...guest });
    expect(result).toMatchObject({ ok: false, status: 409, errors: { guests: 'Only 2 seats left' } });
    expect(store.listTastings()[2]?.seatsLeft).toBe(2);
  });

  it('uses singular wording for one seat and a clear message when sold out', () => {
    const store = createStore();
    store.book({ tastingId: 'red-wine-cellar-tour', guests: 8, ...guest });
    expect(store.book({ tastingId: 'red-wine-cellar-tour', guests: 1, ...guest })).toMatchObject({
      status: 409,
      errors: { guests: 'This tasting is fully booked' },
    });
    const store2 = createStore();
    store2.book({ tastingId: 'winter-tasting', guests: 8, ...guest });
    store2.book({ tastingId: 'winter-tasting', guests: 1, ...guest });
    expect(store2.book({ tastingId: 'winter-tasting', guests: 2, ...guest })).toMatchObject({
      errors: { guests: 'Only 1 seat left' },
    });
  });

  it('never books more than the total seats, however many attempts', () => {
    const store = createStore();
    for (let i = 0; i < 20; i++) store.book({ tastingId: 'riesling-evening', guests: 5, ...guest });
    expect(store.listTastings()[0]?.seatsLeft).toBe(2);
  });

  it('issues unique references', () => {
    const store = createStore();
    const refs = new Set<string>();
    for (let i = 0; i < 8; i++) {
      const r = store.book({ tastingId: 'riesling-evening', guests: 1, ...guest });
      if (r.ok) refs.add(r.booking.reference);
    }
    expect(refs.size).toBe(8);
  });

  it('groups bookings by tasting', () => {
    const store = createStore();
    store.book({ tastingId: 'winter-tasting', guests: 2, ...guest });
    const groups = store.listBookingsByTasting();
    expect(groups.map((g) => g.tasting.id)).toEqual(TASTINGS.map((t) => t.id));
    expect(groups[2]?.bookings).toHaveLength(1);
    expect(groups[2]?.bookings[0]).toMatchObject({ name: 'Anna Weber', email: 'anna@example.com', guests: 2 });
  });

  it('cancel frees the seats and removes the booking', () => {
    const store = createStore();
    const r = store.book({ tastingId: 'riesling-evening', guests: 4, ...guest });
    if (!r.ok) throw new Error('booking failed');
    expect(store.cancel(r.booking.reference)).toBe(true);
    expect(store.listTastings()[0]?.seatsLeft).toBe(12);
    expect(store.listBookingsByTasting()[0]?.bookings).toHaveLength(0);
  });

  it('cancelling an unknown or already cancelled reference returns false', () => {
    const store = createStore();
    const r = store.book({ tastingId: 'riesling-evening', guests: 1, ...guest });
    if (!r.ok) throw new Error('booking failed');
    store.cancel(r.booking.reference);
    expect(store.cancel(r.booking.reference)).toBe(false);
    expect(store.cancel('KB-NOPE00')).toBe(false);
  });

  it('a freed tasting can be booked again', () => {
    const store = createStore();
    const r = store.book({ tastingId: 'red-wine-cellar-tour', guests: 8, ...guest });
    if (!r.ok) throw new Error('booking failed');
    store.cancel(r.booking.reference);
    expect(store.book({ tastingId: 'red-wine-cellar-tour', guests: 8, ...guest }).ok).toBe(true);
  });
});
