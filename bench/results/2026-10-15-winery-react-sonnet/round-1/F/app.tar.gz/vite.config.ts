import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// Everything is served from one origin, so the `crossorigin` attribute Vite adds to the stylesheet link is
// unnecessary, and it makes some Chromium builds refuse the web fonts declared inside that stylesheet.
const sameOriginAssets = {
  name: 'same-origin-assets',
  enforce: 'post' as const,
  transformIndexHtml: (html: string) => html.replace(/(<link rel="stylesheet") crossorigin/g, '$1'),
};

export default defineConfig({
  root: 'src/client',
  plugins: [react(), tailwindcss(), sameOriginAssets],
  build: { outDir: '../../dist/client', emptyOutDir: true },
  server: { proxy: { '/api': 'http://localhost:3000' } },
  test: {
    root: '.',
    include: ['tests/**/*.test.{ts,tsx}'],
    environment: 'node',
    setupFiles: ['tests/setup.ts'],
    globals: true,
  },
});
