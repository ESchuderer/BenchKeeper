# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings online; staff see and cancel bookings.

```
npm install
npm run build
STAFF_PASSWORD=your-password npm start   # http://localhost:3000, or set PORT
```

- Staff sign in at `/staff` with `STAFF_PASSWORD` (sessions last 12 hours). If it is not set, staff sign-in is disabled.
- Behind a reverse proxy set `TRUST_PROXY` (e.g. `1`) so login throttling sees real client IPs and the cookie gets `Secure`.
- Bookings are kept in memory: the app starts empty and a restart clears them.
- The three tastings are defined in `server/tastings.ts`.

## Development

- `npm test` – unit, API and UI tests (Vitest). The UI tests run against the real Express app.
- `npm run e2e` – browser end-to-end run with screenshots in `e2e/screenshots` (needs `npm run build` first and a Playwright browser: `npx playwright install chromium`).
- `npm run dev` – Vite dev server (proxying `/api` to port 3000) plus the API server with reload.

## Layout

- `shared/` – booking validation (zod), used by the browser and the server
- `server/` – Express app: `store.ts` (seat accounting), `auth.ts` (staff sessions), `app.ts` (routes)
- `src/` – React app (React Router, react-hook-form)
- `tests/`, `e2e/`

## API

| Route | |
|---|---|
| `GET /api/tastings`, `GET /api/tastings/:id` | tastings with `seatsLeft` |
| `POST /api/tastings/:id/bookings` | `{name, email, guests}` → 201 booking, 422 `{errors: {field: message}}` |
| `GET /api/bookings/:reference` | public booking summary (no personal data) |
| `POST /api/staff/login`, `POST /api/staff/logout`, `GET /api/staff/session` | staff cookie session |
| `GET /api/staff/bookings`, `DELETE /api/staff/bookings/:reference` | staff only |
