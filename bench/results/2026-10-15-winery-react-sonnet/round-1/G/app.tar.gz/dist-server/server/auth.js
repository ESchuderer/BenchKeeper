import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
const digest = (value) => createHash('sha256').update(value).digest();
export const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
export function createAuth(password, { ttlMs = SESSION_TTL_MS, now = Date.now } = {}) {
    const sessions = new Map(); // token -> expiry time
    const expected = password ? digest(password) : undefined;
    return {
        ttlMs,
        /** Returns a new session token, or null if the password is wrong or staff sign-in is disabled. */
        login(candidate) {
            if (!expected || typeof candidate !== 'string')
                return null;
            if (!timingSafeEqual(expected, digest(candidate)))
                return null;
            for (const [token, expiresAt] of sessions)
                if (expiresAt <= now())
                    sessions.delete(token);
            const token = randomBytes(32).toString('hex');
            sessions.set(token, now() + ttlMs);
            return token;
        },
        isValid(token) {
            const expiresAt = token === undefined ? undefined : sessions.get(token);
            if (expiresAt === undefined)
                return false;
            if (expiresAt <= now()) {
                sessions.delete(token);
                return false;
            }
            return true;
        },
        logout: (token) => void (token && sessions.delete(token)),
    };
}
