import { randomInt } from 'node:crypto';
import { bookingInputSchema } from '../shared/schema.js';
import { TASTINGS } from './tastings.js';
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function createStore(tastings = TASTINGS) {
    const bookings = new Map();
    const seatsTaken = (tastingId) => {
        let taken = 0;
        for (const b of bookings.values())
            if (b.tastingId === tastingId)
                taken += b.guests;
        return taken;
    };
    const view = (t) => ({ ...t, seatsLeft: t.capacity - seatsTaken(t.id) });
    const newReference = () => {
        for (;;) {
            let code = '';
            for (let i = 0; i < 6; i++)
                code += ALPHABET[randomInt(ALPHABET.length)];
            const reference = `KB-${code}`;
            if (!bookings.has(reference))
                return reference;
        }
    };
    return {
        listTastings: () => tastings.map(view),
        getTasting(id) {
            const t = tastings.find((x) => x.id === id);
            return t && view(t);
        },
        // Synchronous on purpose: the seat check and the insert cannot interleave with another request.
        book(tastingId, input) {
            const tasting = tastings.find((x) => x.id === tastingId);
            if (!tasting)
                return { ok: false, notFound: true };
            const parsed = bookingInputSchema.safeParse(input);
            if (!parsed.success) {
                const errors = {};
                for (const issue of parsed.error.issues) {
                    const field = issue.path[0];
                    if ((field === 'name' || field === 'email' || field === 'guests') && !errors[field]) {
                        errors[field] = issue.message;
                    }
                }
                return { ok: false, errors };
            }
            const data = parsed.data;
            const seatsLeft = view(tasting).seatsLeft;
            if (seatsLeft === 0)
                return { ok: false, errors: { guests: 'This tasting is fully booked.' } };
            if (data.guests > seatsLeft) {
                return { ok: false, errors: { guests: `Only ${seatsLeft} ${seatsLeft === 1 ? 'seat' : 'seats'} left.` } };
            }
            const booking = {
                reference: newReference(),
                tastingId,
                name: data.name,
                email: data.email,
                guests: data.guests,
                total: data.guests * tasting.pricePerGuest,
            };
            bookings.set(booking.reference, booking);
            return { ok: true, booking };
        },
        getBooking: (reference) => bookings.get(reference),
        cancel: (reference) => bookings.delete(reference),
        bookingsByTasting: () => tastings.map((t) => ({
            tasting: view(t),
            bookings: [...bookings.values()].filter((b) => b.tastingId === t.id),
        })),
    };
}
