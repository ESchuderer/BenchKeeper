import { z } from 'zod';
export const MAX_GUESTS = 8;
export const bookingInputSchema = z.object({
    name: z
        .string({ error: 'Please enter your name.' })
        .trim()
        .min(1, 'Please enter your name.')
        .max(100, 'Please keep your name under 100 characters.'),
    email: z
        .string({ error: 'Please enter your email address.' })
        .trim()
        .min(1, 'Please enter your email address.')
        .max(254, 'This email address is too long.')
        .pipe(z.email('Please enter a valid email address.')),
    guests: z
        .number({ error: 'Please enter the number of guests.' })
        .int('Please enter a whole number of guests.')
        .min(1, 'Please book for at least 1 guest.')
        .max(MAX_GUESTS, `You can book for at most ${MAX_GUESTS} guests.`),
});
export const formatEur = (amount) => `EUR ${amount}`;
