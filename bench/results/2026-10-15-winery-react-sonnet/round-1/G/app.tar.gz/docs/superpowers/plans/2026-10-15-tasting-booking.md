# Tasting Booking Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A web app where guests book tastings at Weingut Kieselbrunnen and staff view and cancel bookings.

**Architecture:** One Express 5 server (TypeScript) serves a JSON API and the built React SPA. State is in memory behind a `Store` object, which is the only place seat counts are checked. A zod schema in `shared/` validates on both sides.

**Tech Stack:** Node 22, Express 5, React 19, React Router, Vite, react-hook-form + zod, Helmet, express-rate-limit, Vitest, Supertest, Testing Library, plain CSS.

**Spec:** `docs/superpowers/specs/2026-10-15-tasting-booking-design.md` (and the user's request, reproduced in its Global Constraints below).

## Global Constraints

- Tastings: Riesling Evening 2026-11-06 18:00 EUR 25, 12 seats; Red Wine Cellar Tour 2026-11-14 15:00 EUR 32, 8 seats; Winter Tasting 2026-12-05 17:00 EUR 28, 10 seats.
- Start page: title, date and time, price per guest, seats left as "<n> seats left". Link/button "Book <tasting title>".
- Form labels exactly "Name", "Email", "Guests" (1 to 8), button "Book". Errors shown next to the field they concern.
- A booking never takes more seats than are left.
- Confirmation: heading "Booking confirmed", tasting, number of guests, total price, booking reference.
- `/staff`: "Password" field, "Sign in" button, password from env `STAFF_PASSWORD`. Signed in: bookings grouped by tasting (name, email, guests, reference), "Cancel" button per booking; cancelling frees seats.
- Node 22; `npm install`, `npm run build`, `npm start` serves everything on `PORT` (default 3000). Starts with no bookings; no external services; interface in English; React; mobile-friendly; clear error, success and fully-booked states.

## Review Focus

- Concurrent or repeated submits for the last seats: exactly one succeeds, the other gets a field error on Guests. (Task 1, 2)
- Malformed input: `guests` as `"2"`, `2.5`, `0`, `9`, `null`, a missing body, non-JSON, a 10 kB name, whitespace-only name. A 4xx with field errors, never a 500. (Task 2)
- Unknown tasting id, unknown or already-cancelled reference: 404, not a crash. (Task 2, 3)
- Staff: wrong password, missing `STAFF_PASSWORD` env (nobody can sign in), no cookie on the bookings or cancel endpoints → 401. (Task 3)
- Name/email containing `<script>` or HTML must render as text in the staff view. (Task 5)
- Reload of `/staff`, `/book/x`, `/booking/KB-…` served by the SPA fallback; `/api/unknown` returns JSON 404. (Task 6)

---

### Task 1: Scaffold, shared schema, store

**Files:**
- Create: `package.json`, `tsconfig.json`, `tsconfig.server.json`, `vite.config.ts`, `vitest.config.ts`, `.gitignore`
- Create: `shared/schema.ts`, `server/tastings.ts`, `server/store.ts`
- Test: `tests/store.test.ts`

**Interfaces:**
- Produces `shared/schema.ts`: `MAX_GUESTS = 8`; `bookingInputSchema` (zod: `name` trimmed 1–100, `email` trimmed valid ≤254, `guests` integer 1..8); `type BookingInput`; `type FieldErrors = Partial<Record<'name'|'email'|'guests', string>>`; `formatEur(n: number): string` → `"EUR 25"`.
- Produces `server/tastings.ts`: `type Tasting = {id: string; title: string; startsAt: string /* "2026-11-06 18:00" */; pricePerGuest: number; capacity: number}`; `TASTINGS: Tasting[]` with ids `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`.
- Produces `server/store.ts`: `type Booking = {reference: string; tastingId: string; name: string; email: string; guests: number; total: number}`; `type TastingView = Tasting & {seatsLeft: number}`; `createStore(tastings?: Tasting[]): Store` with `listTastings(): TastingView[]`, `getTasting(id): TastingView | undefined`, `book(tastingId: string, input: BookingInput): {ok: true; booking: Booking} | {ok: false; errors: FieldErrors} | {ok: false; notFound: true}`, `getBooking(ref): Booking | undefined`, `cancel(ref): boolean`, `bookingsByTasting(): {tasting: TastingView; bookings: Booking[]}[]`.

- [ ] **Step 1:** Create the project files; `npm install` the dependencies listed in the header. `package.json` scripts: `build` (vite build + `tsc -p tsconfig.server.json`), `start` (`node dist-server/server/index.js`), `dev`, `test` (vitest run). Type is `module`.
- [ ] **Step 2: Write failing tests** in `tests/store.test.ts`: starts with seatsLeft 12/8/10 and no bookings; booking 3 of riesling → seatsLeft 9, total 75, reference matches `/^KB-[A-Z2-9]{6}$/`; booking 9 seats of a tasting with 8 left → `errors.guests` matches `/Only \d+ seats? left/`; booking exactly the remaining seats succeeds then the next booking fails with "fully booked" message in `errors.guests`; `cancel` frees seats and returns false the second time; unknown tasting → `notFound`; references are unique over 500 bookings (use a tasting with large capacity); `bookingsByTasting` returns all three tastings in order.
- [ ] **Step 3:** Run `npx vitest run tests/store.test.ts`; expect FAIL (modules missing).
- [ ] **Step 4:** Implement the three modules as per the interfaces. `book` validates with `bookingInputSchema.safeParse` (mapping the first issue per field to `FieldErrors`) then checks seats synchronously; the reference comes from `crypto.randomInt` over the alphabet `ABCDEFGHJKLMNPQRSTUVWXYZ23456789` (retry on collision).
- [ ] **Step 5:** Run the tests; expect PASS.

### Task 2: Public HTTP API

**Files:**
- Create: `server/app.ts`; Test: `tests/api.test.ts`

**Interfaces:**
- Consumes: `createStore`, `Store`.
- Produces: `createApp(opts: {store?: Store; staffPassword?: string; staticDir?: string}): express.Express`.
  - `GET /api/tastings` → `TastingView[]`
  - `GET /api/tastings/:id` → `TastingView` or 404 `{error}`
  - `POST /api/tastings/:id/bookings` body `BookingInput` → 201 `Booking` (public fields); 422 `{errors: FieldErrors}`; 404 `{error}`; 400 for malformed JSON → `{error}`
  - `GET /api/bookings/:reference` → `{reference, tastingTitle, startsAt, guests, total}` (no name/email), 404 otherwise.

- [ ] **Step 1: Write failing Supertest tests:** list returns 3 tastings with the spec's values; successful booking returns 201 and list shows reduced seats; each invalid case from Review Focus (guests `"2"`, `2.5`, `0`, `9`, `null`, missing body, whitespace name, 10 kB name, bad email) returns 422 with the right field key; overbooking returns 422 `errors.guests`; two concurrent `Promise.all` posts for the last 5 seats × 3 → one 201, one 422; invalid JSON → 400 JSON; unknown tasting → 404; confirmation lookup excludes `email`/`name`; unknown reference → 404; `/api/nope` → 404 JSON.
- [ ] **Step 2:** Run; expect FAIL. **Step 3:** Implement `createApp` with `express.json({limit: '10kb'})`, Helmet, a JSON error handler, and the routes. `guests` must be a JSON number (do not coerce strings). **Step 4:** Run; expect PASS.

### Task 3: Staff API

**Files:** Modify `server/app.ts`; Create `server/auth.ts`; Test: `tests/staff-api.test.ts`

**Interfaces:**
- Produces `server/auth.ts`: `createAuth(password: string | undefined): {login(candidate: unknown): string | null; isValid(token: string | undefined): boolean; logout(token): void}`; tokens are `crypto.randomBytes(32).toString('hex')`, compared passwords via `timingSafeEqual` on SHA-256 digests; unset or empty password → `login` always `null`.
- Routes: `POST /api/staff/login` `{password}` → 204 + `Set-Cookie: staff=<token>; HttpOnly; SameSite=Strict; Path=/` (rate-limited, 10 per 15 min per IP — configurable via `opts.loginLimit` so tests are not throttled), 401 `{error: "Wrong password."}`; `POST /api/staff/logout` → 204; `GET /api/staff/session` → 204/401; `GET /api/staff/bookings` → `{groups: {tasting: TastingView; bookings: Booking[]}[]}`; `DELETE /api/staff/bookings/:reference` → 204 or 404. All except login need the cookie, otherwise 401.

- [ ] **Step 1: Write failing tests:** wrong/missing password → 401 and no cookie; correct → 204 with HttpOnly cookie; bookings and delete without cookie → 401; with cookie bookings grouped (includes email); delete frees seats (visible in `/api/tastings`) and a second delete → 404; `staffPassword` undefined or `""` → even an empty-string password is rejected; logout invalidates the token; 11th login attempt → 429.
- [ ] **Step 2:** Run; expect FAIL. **Step 3:** Implement; parse cookies with the `cookie` package (or `cookie-parser`). **Step 4:** Run; expect PASS.

### Task 4: Guest UI (list, booking form, confirmation)

**Files:** Create `index.html`, `src/main.tsx`, `src/App.tsx`, `src/api.ts`, `src/format.ts`, `src/pages/TastingList.tsx`, `src/pages/BookingForm.tsx`, `src/pages/Confirmation.tsx`, `src/components/Layout.tsx`, `src/styles.css`, `tests/ui/guest.test.tsx` (jsdom, fetch mocked)

**Interfaces:**
- `src/api.ts`: `getTastings()`, `getTasting(id)`, `createBooking(id, input): Promise<{ok: true; booking} | {ok: false; errors: FieldErrors}>`, `getBookingSummary(ref)`, plus staff functions defined in Task 5.
- `src/format.ts`: `seatsLeftText(n)` → `"<n> seats left"`; re-export `formatEur`; `dateBadge(startsAt)` → `{day: string; month: string}`.
- Routes: `/`, `/book/:tastingId`, `/booking/:reference`.

- [ ] **Step 1: Write failing tests:** list shows the three titles, "EUR 25", "12 seats left", the literal "2026-11-06 18:00", and links named "Book Riesling Evening" etc.; a tasting with 0 seats shows "Fully booked" and no Book link; the form has labels Name/Email/Guests and button "Book"; submitting empty shows "required"-style errors in `role="alert"` elements linked via `aria-describedby` to the right field (not only a banner); server 422 `errors.guests` appears next to Guests; success navigates to a view with heading "Booking confirmed" showing tasting, guests, "EUR 75", and the reference; a full tasting's booking page shows a fully-booked notice and no form; the button is disabled while submitting.
- [ ] **Step 2:** Run; expect FAIL. **Step 3:** Implement with react-hook-form + `zodResolver(bookingInputSchema)` (Guests as `<input type=number min=1 max=8>` using `valueAsNumber`; also set `max` to `min(8, seatsLeft)`); map server errors with `setError`. Keep `noValidate` on the form so our messages are the ones shown. **Step 4:** Run; expect PASS.

### Task 5: Staff UI

**Files:** Create `src/pages/Staff.tsx`; Modify `src/api.ts`, `src/App.tsx`; Test: `tests/ui/staff.test.tsx`

**Interfaces:** `src/api.ts`: `staffSession(): Promise<boolean>`, `staffLogin(password): Promise<boolean>`, `staffLogout()`, `staffBookings(): Promise<Group[]>`, `staffCancel(ref): Promise<void>`.

- [ ] **Step 1: Write failing tests:** signed out shows "Password" field and "Sign in" button; wrong password shows an error alert; signed in shows a section per tasting with name, email, guests, reference, and a "Cancel" button per booking; clicking Cancel removes the row and updates the list; empty tasting shows "No bookings yet."; a name of `<script>alert(1)</script>` is rendered as text.
- [ ] **Step 2:** Run; expect FAIL. **Step 3:** Implement. **Step 4:** Run; expect PASS.

### Task 6: Serving, build, styling, end-to-end

**Files:** Create `server/index.ts`; Modify `server/app.ts` (static + SPA fallback), `src/styles.css`; Test: `tests/spa.test.ts`, `e2e/booking.e2e.ts` (script `npm run e2e`, if a browser is available)

- [ ] **Step 1: Write failing tests** (`tests/spa.test.ts`, with a temp `staticDir` containing `index.html`): `/`, `/staff`, `/book/x`, `/booking/KB-ABC234` return the HTML; `/api/nope` returns JSON 404; `/assets/missing.js` returns 404, not HTML.
- [ ] **Step 2:** Implement the static serving with SPA fallback (only for GET requests accepting HTML, not under `/api` or `/assets`), `server/index.ts` (reads `PORT` default 3000 and `STAFF_PASSWORD`; warns if unset; listens on 0.0.0.0).
- [ ] **Step 3:** Polish `src/styles.css`: design tokens, wine/cream palette, serif headings (system font stack), responsive card grid, visible focus, error/success/sold-out states, readable at 360px width.
- [ ] **Step 4:** `npm run build && STAFF_PASSWORD=secret PORT=3100 npm start`; exercise the full flow with curl and a headless browser (screenshots at 390px and 1280px) and check the visuals.

### Task 7: Final verification and review

- [ ] Run `npm test` and `npm run build` fresh; report the actual output.
- [ ] Run a code review (superpowers:requesting-code-review) over the whole tree, fix the findings, and re-run the tests.
- [ ] Write a short `README.md` (run commands, env vars, API summary).
