# Weingut Kieselbrunnen – Tasting Booking: Design

The user's request is the specification (tastings, guest flow, staff flow, look and feel, run commands). It was complete enough that no questions were asked. This document records the choices that were left to the builder. They are the builder's calls, not agreed with the user.

## Intent
Guests book wine tastings online. Staff see and cancel bookings. A small family winery runs it, so it should be simple, robust and pleasant.

## Goals
- Guest flow: list → book form → confirmation (heading "Booking confirmed").
- Seats can never be oversold. The server is the only authority; client validation is a convenience.
- Staff: password sign-in (`STAFF_PASSWORD`), bookings grouped by tasting, cancel frees seats.
- Polished, phone-friendly design with clear error, success and sold-out states.

## Non-goals
- Payments, emails, accounts, editing bookings, hiding past tastings, an admin UI for editing tastings, i18n (English only), persistence across restarts.

## Anti-goals
- Overbooking under concurrent requests.
- Leaking guest names or emails to the public (the public confirmation lookup returns no email).
- Staff data reachable without signing in.

## Builder's calls
- **Stack:** Node 22, Express 5 (API and static serving), React 19 + React Router + Vite (client), react-hook-form + zod (forms; the same zod schema is used on server and client), plain hand-written CSS with design tokens, no CSS framework (the app is small; this keeps the bundle light), Helmet and express-rate-limit (login throttling). Tests: Vitest, Supertest, Testing Library. Playwright for a browser end-to-end check if a browser is available.
- **Storage:** in memory. The app starts empty. Single-threaded Node plus a synchronous check-and-insert makes the seat check atomic.
- **Tastings:** seeded constants on the server. Date/time is winery-local wall time, with no timezone conversion.
- **Display:** each card shows a calendar badge (day/month) plus the literal text `YYYY-MM-DD HH:MM`, "EUR n" per guest, and "<n> seats left" (always this wording). At 0 seats the card shows a "Fully booked" badge and no Book link. The booking page for a full tasting shows a notice instead of the form.
- **Validation:** name 1–100 chars after trim; email syntactically valid, ≤ 254 chars; guests integer 1–8 and ≤ seats left (message, e.g. "Only 3 seats left."). The server returns per-field errors `{errors: {field: message}}` with status 422 (409 for unknown/cancelled cases), and the form shows each message next to its field.
- **Booking reference:** `KB-` plus 6 characters from an unambiguous alphabet (random).
- **Total price:** guests × price, shown as "EUR 50".
- **Staff auth:** `POST /api/staff/login`, constant-time password comparison, random session token kept in server memory, delivered in an httpOnly, SameSite=Strict cookie. If `STAFF_PASSWORD` is unset or empty, staff sign-in is disabled (all attempts fail) and a warning is logged. There is no default password.
- **Cancel:** immediate on click of "Cancel" (no confirm dialog); the booking is removed and the seats are freed.
- **Routes:** `/` list, `/book/:tastingId`, `/booking/:reference` confirmation (survives reload), `/staff`.

## Left to builder
Visual details: a warm palette (wine red, cream, slate/gold accent), a serif heading font stack (system fonts, no external font requests), a responsive card grid.
