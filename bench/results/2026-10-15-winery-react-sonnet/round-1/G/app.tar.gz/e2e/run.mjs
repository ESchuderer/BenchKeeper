// End-to-end check in a real browser against the built app: `npm run build && npm run e2e`.
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';

const PORT = 3190;
const base = `http://localhost:${PORT}`;
const server = spawn('node', ['dist-server/server/index.js'], {
  env: { ...process.env, PORT: String(PORT), STAFF_PASSWORD: 'e2e-secret' },
  stdio: 'inherit',
});
const stop = () => server.kill();
process.on('exit', stop);

for (let i = 0; ; i++) {
  try { await fetch(base); break; } catch { if (i > 50) throw new Error('server did not start'); await new Promise((r) => setTimeout(r, 100)); }
}

const browser = await chromium.launch();
try {
  const phone = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  const page = await phone.newPage();
  const shot = (name) => page.screenshot({ path: `e2e/screenshots/${name}.png`, fullPage: true });

  await page.goto(base);
  await page.getByText('12 seats left').waitFor();
  await shot('1-list-phone');
  // no horizontal scrolling on a phone
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'horizontal overflow on list');

  await page.getByRole('link', { name: 'Book Red Wine Cellar Tour' }).click();
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await page.getByText('Please enter your name.').waitFor();
  await shot('2-form-errors-phone');
  assert.equal(await page.getByLabel('Name').getAttribute('aria-invalid'), 'true');

  await page.getByLabel('Name').fill('Anna Weber');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('8');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await page.getByRole('heading', { name: 'Booking confirmed' }).waitFor();
  await shot('3-confirmation-phone');
  const reference = (await page.locator('.reference').innerText()).trim();
  assert.match(reference, /^KB-[A-Z2-9]{6}$/);

  // sold out now
  await page.goto(base);
  await page.getByText('Fully booked').waitFor();
  assert.equal(await page.getByRole('link', { name: 'Book Red Wine Cellar Tour' }).count(), 0);
  await shot('4-soldout-phone');

  // a second guest cannot book the tasting any more
  await page.goto(`${base}/book/red-wine-cellar-tour`);
  await page.getByText(/fully booked/i).first().waitFor();

  // staff
  await page.goto(`${base}/staff`);
  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByText('Wrong password.').waitFor();
  await shot('5-staff-login-error-phone');
  await page.getByLabel('Password').fill('e2e-secret');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByText('anna@example.com').waitFor();
  await shot('6-staff-phone');

  const desktop = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const dpage = await desktop.newPage();
  await dpage.goto(`${base}/staff`);
  await dpage.getByLabel('Password').fill('e2e-secret');
  await dpage.getByRole('button', { name: 'Sign in' }).click();
  await dpage.getByText('anna@example.com').waitFor();
  await dpage.screenshot({ path: 'e2e/screenshots/7-staff-desktop.png', fullPage: true });
  await dpage.goto(base);
  await dpage.getByText('Fully booked').waitFor();
  await dpage.screenshot({ path: 'e2e/screenshots/8-list-desktop.png', fullPage: true });

  // cancel frees the seats
  await page.getByRole('button', { name: 'Cancel' }).click();
  await page.getByText('anna@example.com').waitFor({ state: 'detached' });
  await page.goto(base);
  await page.getByRole('link', { name: 'Book Red Wine Cellar Tour' }).waitFor();
  assert.ok(await page.getByText('8 seats left').count() >= 1);
  console.log('e2e passed');
} finally {
  await browser.close();
  stop();
}
