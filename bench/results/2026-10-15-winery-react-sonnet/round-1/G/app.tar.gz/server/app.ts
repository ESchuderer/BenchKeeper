import path from 'node:path';
import express, { type ErrorRequestHandler } from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { parseCookie } from 'cookie';
import { createAuth } from './auth.js';
import { createStore, type Store } from './store.js';

export type AppOptions = {
  store?: Store;
  staffPassword?: string;
  staticDir?: string;
  loginLimit?: number;
  sessionTtlMs?: number;
  now?: () => number;
  /** Express 'trust proxy' setting, for deployments behind a reverse proxy. */
  trustProxy?: boolean | number | string;
};

export function createApp(opts: AppOptions = {}) {
  const store = opts.store ?? createStore();
  const app = express();
  app.disable('x-powered-by');
  if (opts.trustProxy !== undefined) app.set('trust proxy', opts.trustProxy);
  // The app may be served over plain HTTP (e.g. on a LAN), so do not force HTTPS upgrades or HSTS.
  app.use(
    helmet({
      strictTransportSecurity: false,
      contentSecurityPolicy: { useDefaults: true, directives: { upgradeInsecureRequests: null } },
    }),
  );

  const auth = createAuth(opts.staffPassword, { ttlMs: opts.sessionTtlMs, now: opts.now });
  const COOKIE = 'staff';
  const tokenOf = (req: express.Request) => parseCookie(req.headers.cookie ?? '')[COOKIE];
  const requireStaff: express.RequestHandler = (req, res, next) => {
    if (!auth.isValid(tokenOf(req))) return void res.status(401).json({ error: 'Please sign in.' });
    next();
  };
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: opts.loginLimit ?? 10,
    skipSuccessfulRequests: true,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (_req, res) => void res.status(429).json({ error: 'Too many attempts. Please try again later.' }),
  });

  const api = express.Router();
  api.use(express.json({ limit: '10kb' }));

  api.get('/tastings', (_req, res) => {
    res.json(store.listTastings());
  });

  api.get('/tastings/:id', (req, res) => {
    const tasting = store.getTasting(req.params.id);
    if (!tasting) return void res.status(404).json({ error: 'Tasting not found.' });
    res.json(tasting);
  });

  api.post('/tastings/:id/bookings', (req, res) => {
    const result = store.book(req.params.id, req.body ?? {});
    if (result.ok) return void res.status(201).json(result.booking);
    if ('notFound' in result) return void res.status(404).json({ error: 'Tasting not found.' });
    res.status(422).json({ errors: result.errors });
  });

  api.get('/bookings/:reference', (req, res) => {
    const booking = store.getBooking(req.params.reference);
    const tasting = booking && store.getTasting(booking.tastingId);
    if (!booking || !tasting) return void res.status(404).json({ error: 'Booking not found.' });
    res.json({
      reference: booking.reference,
      tastingTitle: tasting.title,
      startsAt: tasting.startsAt,
      guests: booking.guests,
      total: booking.total,
    });
  });

  api.post('/staff/login', loginLimiter, (req, res) => {
    const token = auth.login(req.body?.password);
    if (!token) return void res.status(401).json({ error: 'Wrong password.' });
    res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'strict', secure: req.secure, maxAge: auth.ttlMs, path: '/' }).status(204).end();
  });

  api.post('/staff/logout', (req, res) => {
    auth.logout(tokenOf(req));
    res.clearCookie(COOKIE, { path: '/' }).status(204).end();
  });

  api.get('/staff/session', requireStaff, (_req, res) => void res.status(204).end());

  api.get('/staff/bookings', requireStaff, (_req, res) => {
    res.json({ groups: store.bookingsByTasting() });
  });

  api.delete<{ reference: string }>('/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(req.params.reference)) return void res.status(404).json({ error: 'Booking not found.' });
    res.status(204).end();
  });

  api.use((_req, res) => {
    res.status(404).json({ error: 'Not found.' });
  });

  const onError: ErrorRequestHandler = (err, _req, res, _next) => {
    const status = typeof err?.status === 'number' && err.status >= 400 && err.status < 500 ? err.status : 500;
    res.status(status).json({ error: status === 500 ? 'Something went wrong.' : 'Invalid request.' });
  };
  api.use(onError);

  app.use('/api', api);

  if (opts.staticDir) {
    const root = path.resolve(opts.staticDir);
    app.use(express.static(root, { index: false }));
    // Client-side routes (/staff, /book/..., /booking/...) all get the app shell; missing files stay 404.
    app.get(/^\/(?!assets\/)[^.]*$/, (_req, res) => {
      res.sendFile(path.join(root, 'index.html'));
    });
  }
  return app;
}
