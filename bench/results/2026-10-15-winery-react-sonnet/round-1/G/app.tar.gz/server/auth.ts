import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

const digest = (value: string) => createHash('sha256').update(value).digest();

export const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

export function createAuth(
  password: string | undefined,
  { ttlMs = SESSION_TTL_MS, now = Date.now }: { ttlMs?: number; now?: () => number } = {},
) {
  const sessions = new Map<string, number>(); // token -> expiry time
  const expected = password ? digest(password) : undefined;

  return {
    ttlMs,
    /** Returns a new session token, or null if the password is wrong or staff sign-in is disabled. */
    login(candidate: unknown): string | null {
      if (!expected || typeof candidate !== 'string') return null;
      if (!timingSafeEqual(expected, digest(candidate))) return null;
      for (const [token, expiresAt] of sessions) if (expiresAt <= now()) sessions.delete(token);
      const token = randomBytes(32).toString('hex');
      sessions.set(token, now() + ttlMs);
      return token;
    },
    isValid(token: string | undefined) {
      const expiresAt = token === undefined ? undefined : sessions.get(token);
      if (expiresAt === undefined) return false;
      if (expiresAt <= now()) {
        sessions.delete(token!);
        return false;
      }
      return true;
    },
    logout: (token: string | undefined) => void (token && sessions.delete(token)),
  };
}
