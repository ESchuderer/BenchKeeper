import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

// dist-server/server/index.js -> ../../dist (the Vite build)
const staticDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../dist');

// TRUST_PROXY: "true", a hop count such as "1", or an Express subnet list. Set it behind a reverse proxy.
const trust = process.env.TRUST_PROXY;
const trustProxy = trust === undefined ? undefined : trust === 'true' ? true : /^\d+$/.test(trust) ? Number(trust) : trust;

createApp({ staffPassword, staticDir, trustProxy }).listen(port, '0.0.0.0', () => {
  console.log(`Weingut Kieselbrunnen bookings listening on http://localhost:${port}`);
});
