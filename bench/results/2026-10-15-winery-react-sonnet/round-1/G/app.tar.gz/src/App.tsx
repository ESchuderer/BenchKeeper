import { Route, Routes } from 'react-router';
import { Layout } from './components/Layout';
import { BookingForm } from './pages/BookingForm';
import { Confirmation } from './pages/Confirmation';
import { Staff } from './pages/Staff';
import { TastingList } from './pages/TastingList';

export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingList />} />
        <Route path="book/:tastingId" element={<BookingForm />} />
        <Route path="booking/:reference" element={<Confirmation />} />
        <Route path="staff" element={<Staff />} />
        <Route path="*" element={<p className="notice notice-error">Page not found.</p>} />
      </Route>
    </Routes>
  );
}
