import type { BookingInput, FieldErrors } from '../shared/schema';
import type { Booking, TastingView } from '../server/store';

export type { Booking, TastingView };
export type BookingSummary = { reference: string; tastingTitle: string; startsAt: string; guests: number; total: number };
export type BookResult = { ok: true; booking: Booking } | { ok: false; errors: FieldErrors };

async function request(path: string, init?: RequestInit) {
  const res = await fetch(path, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers },
  });
  return res;
}

async function readJson<T>(res: Response): Promise<T> {
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return res.json() as Promise<T>;
}

export const getTastings = async () => readJson<TastingView[]>(await request('/api/tastings'));

/** Resolves to null when the tasting does not exist. */
export async function getTasting(id: string): Promise<TastingView | null> {
  const res = await request(`/api/tastings/${encodeURIComponent(id)}`);
  return res.status === 404 ? null : readJson<TastingView>(res);
}

export async function getBookingSummary(reference: string): Promise<BookingSummary | null> {
  const res = await request(`/api/bookings/${encodeURIComponent(reference)}`);
  return res.status === 404 ? null : readJson<BookingSummary>(res);
}

export async function createBooking(tastingId: string, input: BookingInput): Promise<BookResult> {
  const res = await request(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
  if (res.status === 201) return { ok: true, booking: await res.json() };
  if (res.status === 422) return { ok: false, errors: (await res.json()).errors };
  throw new Error(`Request failed (${res.status})`);
}

export type StaffGroup = { tasting: TastingView; bookings: Booking[] };

export async function staffSession(): Promise<boolean> {
  return (await request('/api/staff/session')).status === 204;
}

export async function staffLogin(password: string): Promise<boolean> {
  const res = await request('/api/staff/login', { method: 'POST', body: JSON.stringify({ password }) });
  if (res.status === 204) return true;
  if (res.status === 401) return false;
  throw new Error(res.status === 429 ? 'Too many attempts. Please try again later.' : `Request failed (${res.status})`);
}

export async function staffLogout(): Promise<void> {
  await request('/api/staff/logout', { method: 'POST' });
}

/** Resolves to null when the session is no longer valid. */
export async function staffBookings(): Promise<StaffGroup[] | null> {
  const res = await request('/api/staff/bookings');
  if (res.status === 401) return null;
  return (await readJson<{ groups: StaffGroup[] }>(res)).groups;
}

export class SessionExpiredError extends Error {}

export async function staffCancel(reference: string): Promise<void> {
  const res = await request(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' });
  if (res.status === 401) throw new SessionExpiredError();
  if (!res.ok && res.status !== 404) throw new Error(`Request failed (${res.status})`);
}
