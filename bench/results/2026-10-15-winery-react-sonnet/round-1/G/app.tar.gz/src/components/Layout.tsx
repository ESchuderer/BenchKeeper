import { Link, Outlet } from 'react-router';

export function Layout() {
  return (
    <>
      <header className="site-header">
        <div className="wrap">
          <Link to="/" className="brand">
            <span className="brand-mark" aria-hidden="true" />
            <span>
              Weingut <strong>Kieselbrunnen</strong>
            </span>
          </Link>
          <span className="tagline">Family winery</span>
        </div>
      </header>
      <main className="wrap">
        <Outlet />
      </main>
      <footer className="site-footer">
        <div className="wrap">
          <span>© Weingut Kieselbrunnen</span>
          <Link to="/staff">Staff</Link>
        </div>
      </footer>
    </>
  );
}

export function LoadError({ what, onRetry }: { what: string; onRetry: () => void }) {
  return (
    <div className="notice notice-error" role="alert">
      <p>We could not load {what}. Please check your connection.</p>
      <button type="button" className="btn btn-secondary" onClick={onRetry}>
        Try again
      </button>
    </div>
  );
}

export function Loading() {
  return (
    <p className="loading" role="status">
      Loading…
    </p>
  );
}
