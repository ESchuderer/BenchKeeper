export { formatEur } from '../shared/schema';

export const seatsLeftText = (n: number) => `${n} seats left`;

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** Splits a winery-local "YYYY-MM-DD HH:MM" into display parts, with no timezone conversion. */
export function dateBadge(startsAt: string) {
  const [y, m, d] = startsAt.slice(0, 10).split('-').map(Number);
  return {
    weekday: WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()],
    day: String(d),
    month: MONTHS[m - 1],
  };
}
