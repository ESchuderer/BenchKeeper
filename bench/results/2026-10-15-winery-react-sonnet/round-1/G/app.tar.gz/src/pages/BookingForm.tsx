import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useNavigate, useParams } from 'react-router';
import { createBooking, getTasting, type TastingView } from '../api';
import { LoadError, Loading } from '../components/Layout';
import { dateBadge, formatEur } from '../format';
import { bookingInputSchema, MAX_GUESTS, type BookingInput, type FieldName } from '../../shared/schema';
import { useAsync } from '../useAsync';

function Field({ name, label, error, hint, children }: {
  name: FieldName; label: string; error?: string; hint?: string; children: React.ReactNode;
}) {
  return (
    <div className={`field${error ? ' field-invalid' : ''}`}>
      <label htmlFor={name}>{label}</label>
      {children}
      {hint && !error && <p className="hint" id={`${name}-hint`}>{hint}</p>}
      {error && (
        <p className="field-error" id={`${name}-error`} role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export function BookingForm() {
  const { tastingId = '' } = useParams();
  const { state, retry } = useAsync(() => getTasting(tastingId), [tastingId]);

  if (state.status === 'loading') return <Loading />;
  if (state.status === 'error') return <LoadError what="this tasting" onRetry={retry} />;

  const tasting = state.data;
  if (!tasting) {
    return (
      <div className="notice notice-error" role="alert">
        <p>We could not find that tasting.</p>
        <Link to="/">See all tastings</Link>
      </div>
    );
  }

  if (tasting.seatsLeft === 0) {
    return (
      <section className="panel">
        <h1>{tasting.title}</h1>
        <div className="notice notice-soldout">
          <p><strong>Fully booked.</strong> All seats for this tasting have been taken.</p>
          <Link to="/">See other tastings</Link>
        </div>
      </section>
    );
  }

  return <TastingForm tasting={tasting} />;
}

function TastingForm({ tasting }: { tasting: TastingView }) {
  const navigate = useNavigate();
  const maxGuests = Math.min(MAX_GUESTS, tasting.seatsLeft);
  const {
    register,
    handleSubmit,
    setError,
    setFocus,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '', guests: Math.min(2, maxGuests) },
  });
  const badge = dateBadge(tasting.startsAt);

  const onSubmit = handleSubmit(async (input) => {
    try {
      const result = await createBooking(tasting.id, input);
      if (result.ok) return navigate(`/booking/${result.booking.reference}`);
      let first: FieldName | undefined;
      for (const [field, message] of Object.entries(result.errors) as [FieldName, string][]) {
        setError(field, { type: 'server', message });
        first ??= field;
      }
      if (first) setFocus(first);
    } catch {
      setError('root', { type: 'server', message: 'Something went wrong. Please try again.' });
    }
  });

  const describedBy = (name: FieldName, hint = false) =>
    errors[name] ? `${name}-error` : hint ? `${name}-hint` : undefined;

  return (
    <section className="panel">
      <p className="crumbs"><Link to="/">← All tastings</Link></p>
      <h1>Book {tasting.title}</h1>
      <p className="summary facts">
        <span>{badge.weekday}, {badge.day} {badge.month}</span>
        <span>{tasting.startsAt}</span>
        <span>{formatEur(tasting.pricePerGuest)} per guest</span>
        <span>{tasting.seatsLeft} seats left</span>
      </p>
      <form onSubmit={onSubmit} noValidate>
        <Field name="name" label="Name" error={errors.name?.message}>
          <input id="name" type="text" autoComplete="name" aria-invalid={!!errors.name}
            aria-describedby={describedBy('name')} {...register('name')} />
        </Field>
        <Field name="email" label="Email" error={errors.email?.message}>
          <input id="email" type="email" autoComplete="email" aria-invalid={!!errors.email}
            aria-describedby={describedBy('email')} {...register('email')} />
        </Field>
        <Field name="guests" label="Guests" error={errors.guests?.message} hint={`1 to ${maxGuests}`}>
          <input id="guests" type="number" inputMode="numeric" min={1} max={maxGuests} step={1}
            aria-invalid={!!errors.guests} aria-describedby={describedBy('guests', true)}
            {...register('guests', { valueAsNumber: true })} />
        </Field>
        {errors.root && (
          <div className="notice notice-error" role="alert">
            <p>{errors.root.message}</p>
          </div>
        )}
        <button type="submit" className="btn btn-block" disabled={isSubmitting}>
          {isSubmitting ? 'Booking…' : 'Book'}
        </button>
      </form>
    </section>
  );
}
