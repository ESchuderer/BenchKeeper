import { Link, useParams } from 'react-router';
import { getBookingSummary } from '../api';
import { LoadError, Loading } from '../components/Layout';
import { formatEur } from '../format';
import { useAsync } from '../useAsync';

export function Confirmation() {
  const { reference = '' } = useParams();
  const { state, retry } = useAsync(() => getBookingSummary(reference), [reference]);

  if (state.status === 'loading') return <Loading />;
  if (state.status === 'error') return <LoadError what="your booking" onRetry={retry} />;
  if (!state.data) {
    return (
      <div className="notice notice-error" role="alert">
        <p>We could not find that booking. It may have been cancelled.</p>
        <Link to="/">See all tastings</Link>
      </div>
    );
  }

  const b = state.data;
  return (
    <section className="panel confirmation">
      <div className="success-mark" aria-hidden="true">✓</div>
      <h1>Booking confirmed</h1>
      <p>Thank you! We look forward to welcoming you at the winery.</p>
      <dl className="details">
        <div><dt>Tasting</dt><dd>{b.tastingTitle}</dd></div>
        <div><dt>When</dt><dd>{b.startsAt}</dd></div>
        <div><dt>Guests</dt><dd>{b.guests}</dd></div>
        <div><dt>Total price</dt><dd>{formatEur(b.total)}</dd></div>
        <div><dt>Booking reference</dt><dd className="reference">{b.reference}</dd></div>
      </dl>
      <p className="hint">Please keep your booking reference and mention it if you need to reach us.</p>
      <Link className="btn btn-secondary" to="/">Back to all tastings</Link>
    </section>
  );
}
