import { useCallback, useEffect, useState } from 'react';
import { SessionExpiredError, staffBookings, staffCancel, staffLogin, staffLogout, type StaffGroup } from '../api';
import { LoadError, Loading } from '../components/Layout';

type View = { kind: 'loading' } | { kind: 'error' } | { kind: 'signedOut' } | { kind: 'ready'; groups: StaffGroup[] };

export function Staff() {
  const [view, setView] = useState<View>({ kind: 'loading' });

  const refresh = useCallback(async () => {
    try {
      const groups = await staffBookings();
      setView(groups ? { kind: 'ready', groups } : { kind: 'signedOut' });
    } catch {
      setView({ kind: 'error' });
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  if (view.kind === 'loading') return <Loading />;
  if (view.kind === 'error') return <LoadError what="the bookings" onRetry={() => void refresh()} />;
  if (view.kind === 'signedOut') return <SignIn onSignedIn={refresh} />;
  return (
    <Bookings
      groups={view.groups}
      onChange={refresh}
      onSessionExpired={() => setView({ kind: 'signedOut' })}
      onSignOut={async () => {
        await staffLogout();
        setView({ kind: 'signedOut' });
      }}
    />
  );
}

function SignIn({ onSignedIn }: { onSignedIn: () => Promise<void> }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(undefined);
    try {
      if (await staffLogin(password)) return await onSignedIn();
      setError('Wrong password.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel panel-narrow">
      <h1>Staff</h1>
      <p className="summary">Sign in to see the bookings.</p>
      <form onSubmit={submit}>
        <div className={`field${error ? ' field-invalid' : ''}`}>
          <label htmlFor="password">Password</label>
          <input id="password" type="password" autoComplete="current-password" value={password}
            onChange={(e) => setPassword(e.target.value)} aria-invalid={!!error}
            aria-describedby={error ? 'password-error' : undefined} />
          {error && <p className="field-error" id="password-error" role="alert">{error}</p>}
        </div>
        <button type="submit" className="btn btn-block" disabled={busy}>Sign in</button>
      </form>
    </section>
  );
}

function Bookings({ groups, onChange, onSessionExpired, onSignOut }: {
  groups: StaffGroup[]; onChange: () => Promise<void>; onSessionExpired: () => void; onSignOut: () => Promise<void>;
}) {
  const [pending, setPending] = useState<string>();
  const [error, setError] = useState<string>();

  const cancel = async (reference: string) => {
    setPending(reference);
    setError(undefined);
    try {
      await staffCancel(reference);
      await onChange(); // reports its own load errors
    } catch (err) {
      if (err instanceof SessionExpiredError) onSessionExpired();
      else setError('The booking could not be cancelled. Please try again.');
    } finally {
      setPending(undefined);
    }
  };

  return (
    <>
      <div className="staff-head">
        <h1>Bookings</h1>
        <button type="button" className="btn btn-secondary" onClick={() => void onSignOut()}>Sign out</button>
      </div>
      {error && <div className="notice notice-error" role="alert"><p>{error}</p></div>}
      {groups.map(({ tasting, bookings }) => (
        <section className="panel staff-group" key={tasting.id}>
          <h2>
            {tasting.title} <span className="when">{tasting.startsAt}</span>
          </h2>
          <p className="summary">
            {tasting.capacity - tasting.seatsLeft} of {tasting.capacity} seats booked
          </p>
          {bookings.length === 0 ? (
            <p className="empty">No bookings yet.</p>
          ) : (
            <table className="bookings">
              <thead>
                <tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th><span className="sr-only">Actions</span></th></tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr key={b.reference}>
                    <td data-label="Name">{b.name}</td>
                    <td data-label="Email">{b.email}</td>
                    <td data-label="Guests">{b.guests}</td>
                    <td data-label="Reference" className="reference">{b.reference}</td>
                    <td className="actions">
                      <button type="button" className="btn btn-danger" disabled={pending === b.reference}
                        onClick={() => void cancel(b.reference)}>Cancel</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      ))}
    </>
  );
}
