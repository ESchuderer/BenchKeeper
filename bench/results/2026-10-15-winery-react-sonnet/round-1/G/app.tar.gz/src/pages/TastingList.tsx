import { Link } from 'react-router';
import { getTastings } from '../api';
import { LoadError, Loading } from '../components/Layout';
import { dateBadge, formatEur, seatsLeftText } from '../format';
import { useAsync } from '../useAsync';

export function TastingList() {
  const { state, retry } = useAsync(getTastings, []);

  return (
    <>
      <section className="hero">
        <h1>Wine tastings at the winery</h1>
        <p>Join us in the cellar and taste what our family has grown, pressed and matured. Choose a date and reserve your seats.</p>
      </section>
      {state.status === 'loading' && <Loading />}
      {state.status === 'error' && <LoadError what="the tastings" onRetry={retry} />}
      {state.status === 'ready' && (
        <ul className="cards">
          {state.data.map((t) => {
            const soldOut = t.seatsLeft === 0;
            const badge = dateBadge(t.startsAt);
            return (
              <li key={t.id}>
                <article className={`card${soldOut ? ' card-soldout' : ''}`}>
                  <div className="date-badge" aria-hidden="true">
                    <span>{badge.weekday}</span>
                    <strong>{badge.day}</strong>
                    <span>{badge.month}</span>
                  </div>
                  <div className="card-body">
                    <h2>{t.title}</h2>
                    <p className="when">
                      <time dateTime={t.startsAt.replace(' ', 'T')}>{t.startsAt}</time>
                    </p>
                    <p className="meta">
                      <span className="price">{formatEur(t.pricePerGuest)}</span>
                      <span className="per"> per guest</span>
                    </p>
                    <p className={`seats${t.seatsLeft <= 3 ? ' seats-low' : ''}`}>
                      {soldOut && <span className="badge badge-soldout">Fully booked</span>}
                      <span>{seatsLeftText(t.seatsLeft)}</span>
                    </p>
                  </div>
                  {!soldOut && (
                    <Link className="btn" to={`/book/${t.id}`}>
                      Book {t.title}
                    </Link>
                  )}
                </article>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
