import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../server/app.js';
import { createStore } from '../server/store.js';

const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };
let app: ReturnType<typeof createApp>;

beforeEach(() => {
  app = createApp({ store: createStore(), staffPassword: 'secret' });
});

describe('GET /api/tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const res = await request(app).get('/api/tastings');
    expect(res.status).toBe(200);
    expect(res.body.map((t: any) => [t.title, t.startsAt, t.pricePerGuest, t.seatsLeft])).toEqual([
      ['Riesling Evening', '2026-11-06 18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14 15:00', 32, 8],
      ['Winter Tasting', '2026-12-05 17:00', 28, 10],
    ]);
  });

  it('returns one tasting, or 404 JSON for an unknown id', async () => {
    expect((await request(app).get('/api/tastings/winter-tasting')).body.title).toBe('Winter Tasting');
    const res = await request(app).get('/api/tastings/nope');
    expect(res.status).toBe(404);
    expect(res.body.error).toEqual(expect.any(String));
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and reduces the seats left', async () => {
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(guest);
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ guests: 2, total: 50, tastingId: 'riesling-evening' });
    expect(res.body.reference).toMatch(/^KB-/);
    const list = await request(app).get('/api/tastings');
    expect(list.body[0].seatsLeft).toBe(10);
  });

  it.each([
    ['guests as a string', { ...guest, guests: '2' }, 'guests'],
    ['guests fractional', { ...guest, guests: 2.5 }, 'guests'],
    ['guests zero', { ...guest, guests: 0 }, 'guests'],
    ['guests nine', { ...guest, guests: 9 }, 'guests'],
    ['guests null', { ...guest, guests: null }, 'guests'],
    ['guests missing', { name: guest.name, email: guest.email }, 'guests'],
    ['whitespace name', { ...guest, name: '   ' }, 'name'],
    ['name 101 characters', { ...guest, name: 'x'.repeat(101) }, 'name'],
    ['bad email', { ...guest, email: 'not-an-email' }, 'email'],
    ['email not a string', { ...guest, email: 42 }, 'email'],
  ])('rejects %s with a 422 and an error on that field', async (_label, body, field) => {
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(body);
    expect(res.status).toBe(422);
    expect(res.body.errors[field]).toEqual(expect.any(String));
    expect((await request(app).get('/api/tastings')).body[0].seatsLeft).toBe(12);
  });

  it('rejects an oversized body with 413 and books nothing', async () => {
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guest, name: 'x'.repeat(20_000) });
    expect(res.status).toBe(413);
    expect((await request(app).get('/api/tastings')).body[0].seatsLeft).toBe(12);
  });

  it('answers 422 (not 500) when the body is missing', async () => {
    const res = await request(app).post('/api/tastings/riesling-evening/bookings');
    expect(res.status).toBe(422);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it('answers 400 JSON for malformed JSON', async () => {
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{nope');
    expect(res.status).toBe(400);
    expect(res.body.error).toEqual(expect.any(String));
  });

  it('answers 404 for an unknown tasting', async () => {
    expect((await request(app).post('/api/tastings/nope/bookings').send(guest)).status).toBe(404);
  });

  it('never overbooks: two simultaneous requests for 5 of the last 5 seats', async () => {
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 3 });
    const results = await Promise.all([
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 5 }),
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 5 }),
    ]);
    expect(results.map((r) => r.status).sort()).toEqual([201, 422]);
    const loser = results.find((r) => r.status === 422)!;
    expect(loser.body.errors.guests).toBe('This tasting is fully booked.');
    expect((await request(app).get('/api/tastings/red-wine-cellar-tour')).body.seatsLeft).toBe(0);
  });

  it('rejects more guests than seats left', async () => {
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 7 });
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 2 });
    expect(res.status).toBe(422);
    expect(res.body.errors.guests).toBe('Only 1 seat left.');
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns a summary without personal data', async () => {
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send(guest);
    const res = await request(app).get(`/api/bookings/${created.body.reference}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      reference: created.body.reference,
      tastingTitle: 'Winter Tasting',
      startsAt: '2026-12-05 17:00',
      guests: 2,
      total: 56,
    });
  });

  it('answers 404 for an unknown reference', async () => {
    expect((await request(app).get('/api/bookings/KB-AAAAAA')).status).toBe(404);
  });
});

describe('security headers', () => {
  it('work over plain HTTP: no HSTS and no upgrade-insecure-requests', async () => {
    const res = await request(app).get('/api/tastings');
    expect(res.headers['strict-transport-security']).toBeUndefined();
    expect(res.headers['content-security-policy']).toBeDefined();
    expect(res.headers['content-security-policy']).not.toContain('upgrade-insecure-requests');
  });
});

describe('unknown API routes', () => {
  it('answer 404 JSON', async () => {
    const res = await request(app).get('/api/nope');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
});
