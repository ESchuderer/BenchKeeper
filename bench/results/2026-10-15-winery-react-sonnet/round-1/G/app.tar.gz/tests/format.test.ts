import { describe, expect, it } from 'vitest';
import { dateBadge, formatEur, seatsLeftText } from '../src/format';

describe('format', () => {
  it('derives the weekday of a winery-local date without timezone drift', () => {
    expect(dateBadge('2026-11-06 18:00')).toEqual({ weekday: 'Fri', day: '6', month: 'Nov' });
    expect(dateBadge('2026-12-05 17:00')).toEqual({ weekday: 'Sat', day: '5', month: 'Dec' });
  });
  it('formats seats and prices as specified', () => {
    expect(seatsLeftText(12)).toBe('12 seats left');
    expect(formatEur(75)).toBe('EUR 75');
  });
});
