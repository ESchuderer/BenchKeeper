import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { createApp } from '../server/app.js';

let dir: string;
let app: ReturnType<typeof createApp>;

beforeAll(() => {
  dir = mkdtempSync(join(tmpdir(), 'spa-'));
  writeFileSync(join(dir, 'index.html'), '<!doctype html><div id="root">SPA</div>');
  mkdirSync(join(dir, 'assets'));
  writeFileSync(join(dir, 'assets', 'app.js'), 'console.log(1)');
  app = createApp({ staticDir: dir, staffPassword: 'x' });
});
afterAll(() => rmSync(dir, { recursive: true, force: true }));

describe('static serving', () => {
  it.each(['/', '/staff', '/book/riesling-evening', '/booking/KB-ABC234'])('serves the app shell at %s', async (path) => {
    const res = await request(app).get(path).set('Accept', 'text/html');
    expect(res.status).toBe(200);
    expect(res.text).toContain('SPA');
  });

  it('serves built assets', async () => {
    const res = await request(app).get('/assets/app.js');
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/javascript/);
  });

  it('answers 404, not HTML, for a missing asset', async () => {
    const res = await request(app).get('/assets/missing.js');
    expect(res.status).toBe(404);
    expect(res.text).not.toContain('SPA');
  });

  it('answers JSON 404 for unknown API routes, even with an HTML Accept header', async () => {
    const res = await request(app).get('/api/nope').set('Accept', 'text/html');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });

  it('does not answer non-GET requests outside the API with the app shell', async () => {
    expect((await request(app).post('/staff')).status).toBe(404);
  });
});
