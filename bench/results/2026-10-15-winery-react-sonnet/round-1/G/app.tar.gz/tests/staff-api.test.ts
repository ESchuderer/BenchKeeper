import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../server/app.js';
import { createStore } from '../server/store.js';

const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 3 };

async function signIn(app: ReturnType<typeof createApp>) {
  const res = await request(app).post('/api/staff/login').send({ password: 'secret' });
  expect(res.status).toBe(204);
  return res.headers['set-cookie'] as unknown as string[];
}

let app: ReturnType<typeof createApp>;
beforeEach(() => {
  app = createApp({ store: createStore(), staffPassword: 'secret', loginLimit: 1000 });
});

describe('staff login', () => {
  it('rejects a wrong password without setting a cookie', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: 'nope' });
    expect(res.status).toBe(401);
    expect(res.headers['set-cookie']).toBeUndefined();
    expect(res.body.error).toBe('Wrong password.');
  });

  it('rejects a missing or non-string password', async () => {
    expect((await request(app).post('/api/staff/login')).status).toBe(401);
    expect((await request(app).post('/api/staff/login').send({ password: 123 })).status).toBe(401);
  });

  it('sets an HttpOnly SameSite=Strict cookie on the right password', async () => {
    const cookie = (await signIn(app)).join(';');
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
  });

  it('lets nobody in when STAFF_PASSWORD is unset or empty', async () => {
    for (const staffPassword of [undefined, '']) {
      const closed = createApp({ staffPassword, loginLimit: 1000 });
      expect((await request(closed).post('/api/staff/login').send({ password: '' })).status).toBe(401);
      expect((await request(closed).post('/api/staff/login').send({ password: 'undefined' })).status).toBe(401);
    }
  });

  it('throttles repeated attempts', async () => {
    const limited = createApp({ staffPassword: 'secret', loginLimit: 3 });
    const statuses: number[] = [];
    for (let i = 0; i < 5; i++) {
      statuses.push((await request(limited).post('/api/staff/login').send({ password: 'bad' })).status);
    }
    expect(statuses).toEqual([401, 401, 401, 429, 429]);
  });
});

describe('login limiter', () => {
  it('counts only failed attempts, so staff signing in repeatedly are not locked out', async () => {
    const limited = createApp({ staffPassword: 'secret', loginLimit: 2 });
    for (let i = 0; i < 5; i++) {
      expect((await request(limited).post('/api/staff/login').send({ password: 'secret' })).status).toBe(204);
    }
  });
});

describe('staff sessions', () => {
  it('expire after the session lifetime', async () => {
    let now = 1_000_000;
    const timed = createApp({ staffPassword: 'secret', loginLimit: 1000, now: () => now, sessionTtlMs: 60_000 });
    const cookie = (await request(timed).post('/api/staff/login').send({ password: 'secret' })).headers['set-cookie'] as unknown as string[];
    expect(cookie.join(';')).toMatch(/Max-Age=60/i);
    now += 59_000;
    expect((await request(timed).get('/api/staff/session').set('Cookie', cookie)).status).toBe(204);
    now += 2_000;
    expect((await request(timed).get('/api/staff/session').set('Cookie', cookie)).status).toBe(401);
  });
});

describe('staff endpoints', () => {
  it('require a session', async () => {
    expect((await request(app).get('/api/staff/bookings')).status).toBe(401);
    expect((await request(app).get('/api/staff/session')).status).toBe(401);
    expect((await request(app).delete('/api/staff/bookings/KB-AAAAAA')).status).toBe(401);
    expect(
      (await request(app).get('/api/staff/bookings').set('Cookie', 'staff=forged')).status,
    ).toBe(401);
  });

  it('list bookings grouped by tasting, including contact data', async () => {
    const cookie = await signIn(app);
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send(guest);
    expect((await request(app).get('/api/staff/session').set('Cookie', cookie)).status).toBe(204);
    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(res.status).toBe(200);
    expect(res.body.groups.map((g: any) => g.tasting.title)).toEqual([
      'Riesling Evening',
      'Red Wine Cellar Tour',
      'Winter Tasting',
    ]);
    expect(res.body.groups[2].bookings).toEqual([
      expect.objectContaining({ name: 'Anna Weber', email: 'anna@example.com', guests: 3, reference: created.body.reference }),
    ]);
  });

  it('cancel frees the seats; cancelling again gives 404', async () => {
    const cookie = await signIn(app);
    const created = await request(app).post('/api/tastings/winter-tasting/bookings').send(guest);
    expect((await request(app).get('/api/tastings/winter-tasting')).body.seatsLeft).toBe(7);
    const url = `/api/staff/bookings/${created.body.reference}`;
    expect((await request(app).delete(url).set('Cookie', cookie)).status).toBe(204);
    expect((await request(app).get('/api/tastings/winter-tasting')).body.seatsLeft).toBe(10);
    expect((await request(app).delete(url).set('Cookie', cookie)).status).toBe(404);
    expect((await request(app).get(`/api/bookings/${created.body.reference}`)).status).toBe(404);
  });

  it('logout ends the session', async () => {
    const cookie = await signIn(app);
    expect((await request(app).post('/api/staff/logout').set('Cookie', cookie)).status).toBe(204);
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });
});
