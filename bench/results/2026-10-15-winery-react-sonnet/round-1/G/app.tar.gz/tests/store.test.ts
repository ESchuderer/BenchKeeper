import { describe, it, expect } from 'vitest';
import { createStore } from '../server/store.js';
import { TASTINGS } from '../server/tastings.js';

const guest = { name: 'Anna Weber', email: 'anna@example.com' };

describe('store', () => {
  it('starts with full seats and no bookings', () => {
    const store = createStore();
    expect(store.listTastings().map((t) => t.seatsLeft)).toEqual([12, 8, 10]);
    expect(store.bookingsByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });

  it('offers the three tastings from the brief', () => {
    expect(TASTINGS.map((t) => [t.title, t.startsAt, t.pricePerGuest, t.capacity])).toEqual([
      ['Riesling Evening', '2026-11-06 18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14 15:00', 32, 8],
      ['Winter Tasting', '2026-12-05 17:00', 28, 10],
    ]);
  });

  it('books seats, computes the total and issues a reference', () => {
    const store = createStore();
    const r = store.book('riesling-evening', { ...guest, guests: 3 });
    if (!r.ok || !('booking' in r)) throw new Error('expected success');
    expect(r.booking.total).toBe(75);
    expect(r.booking.reference).toMatch(/^KB-[A-Z2-9]{6}$/);
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(9);
  });

  it('rejects more guests than seats left with a guests error', () => {
    const store = createStore();
    store.book('red-wine-cellar-tour', { ...guest, guests: 8 });
    store.cancel(store.bookingsByTasting()[1].bookings[0].reference);
    store.book('red-wine-cellar-tour', { ...guest, guests: 6 });
    const r = store.book('red-wine-cellar-tour', { ...guest, guests: 3 });
    expect(r).toEqual({ ok: false, errors: { guests: 'Only 2 seats left.' } });
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(2);
  });

  it('allows exactly the remaining seats, then reports fully booked', () => {
    const store = createStore();
    expect(store.book('red-wine-cellar-tour', { ...guest, guests: 8 }).ok).toBe(true);
    const r = store.book('red-wine-cellar-tour', { ...guest, guests: 1 });
    expect(r).toEqual({ ok: false, errors: { guests: 'This tasting is fully booked.' } });
  });

  it('frees seats on cancel, and cancel twice returns false', () => {
    const store = createStore();
    const r = store.book('winter-tasting', { ...guest, guests: 4 });
    if (!r.ok || !('booking' in r)) throw new Error('expected success');
    expect(store.cancel(r.booking.reference)).toBe(true);
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(10);
    expect(store.getBooking(r.booking.reference)).toBeUndefined();
    expect(store.cancel(r.booking.reference)).toBe(false);
  });

  it('reports an unknown tasting as not found', () => {
    expect(createStore().book('nope', { ...guest, guests: 1 })).toEqual({ ok: false, notFound: true });
  });

  it('validates input and returns field errors', () => {
    const r = createStore().book('winter-tasting', { name: '  ', email: 'x', guests: 0 });
    expect(r.ok).toBe(false);
    expect(r).toMatchObject({ errors: { name: expect.any(String), email: expect.any(String), guests: expect.any(String) } });
  });

  it('issues unique references', () => {
    const store = createStore([{ id: 't', title: 'T', startsAt: '2026-01-01 10:00', pricePerGuest: 1, capacity: 1000 }]);
    const refs = new Set<string>();
    for (let i = 0; i < 500; i++) {
      const r = store.book('t', { ...guest, guests: 1 });
      if (r.ok && 'booking' in r) refs.add(r.booking.reference);
    }
    expect(refs.size).toBe(500);
  });

  it('groups bookings by tasting in tasting order', () => {
    const store = createStore();
    store.book('winter-tasting', { ...guest, guests: 1 });
    const groups = store.bookingsByTasting();
    expect(groups.map((g) => g.tasting.id)).toEqual(['riesling-evening', 'red-wine-cellar-tour', 'winter-tasting']);
    expect(groups[2].bookings).toHaveLength(1);
  });
});
