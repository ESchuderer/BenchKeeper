// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { cleanup, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderAt, startBackend } from './helpers';

let backend: Awaited<ReturnType<typeof startBackend>>;
beforeEach(async () => {
  backend = await startBackend();
});
afterEach(() => {
  cleanup();
  backend.close();
});

const fill = async (name: string, email: string, guests: string) => {
  const user = userEvent.setup();
  await user.type(screen.getByLabelText('Name'), name);
  await user.type(screen.getByLabelText('Email'), email);
  await user.clear(screen.getByLabelText('Guests'));
  if (guests) await user.type(screen.getByLabelText('Guests'), guests);
  return user;
};

describe('start page', () => {
  it('lists every tasting with date, price, seats and a Book link', async () => {
    renderAt('/');
    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('article')!;
    expect(within(riesling).getByText('2026-11-06 18:00')).toBeInTheDocument();
    expect(within(riesling).getByText('EUR 25')).toBeInTheDocument();
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toHaveAttribute('href', '/book/riesling-evening');
    expect(screen.getByText('8 seats left')).toBeInTheDocument();
    expect(screen.getByText('EUR 32')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toBeInTheDocument();
  });

  it('marks a sold-out tasting as fully booked and offers no Book link', async () => {
    backend.store.book('red-wine-cellar-tour', { name: 'A', email: 'a@b.de', guests: 8 });
    renderAt('/');
    const card = (await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' })).closest('article')!;
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(within(card).getByText('0 seats left')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).not.toBeInTheDocument();
  });

  it('shows an error with a retry button when the server is unreachable', async () => {
    const original = globalThis.fetch;
    globalThis.fetch = (() => Promise.reject(new TypeError('offline'))) as typeof fetch;
    renderAt('/');
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument();
    globalThis.fetch = original;
  });
});

describe('booking form', () => {
  it('has labelled fields and a Book button for the chosen tasting', async () => {
    renderAt('/book/winter-tasting');
    expect(await screen.findByRole('heading', { name: /Winter Tasting/ })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('shows each error next to its own field and books nothing', async () => {
    renderAt('/book/winter-tasting');
    await screen.findByLabelText('Name');
    const user = await fill('   ', 'not-an-email', '9');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByLabelText('Name')).toHaveAccessibleDescription('Please enter your name.');
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription('Please enter a valid email address.');
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('You can book for at most 8 guests.');
    expect(screen.getByLabelText('Name')).toBeInvalid();
    expect(backend.store.getTasting('winter-tasting')?.seatsLeft).toBe(10);
  });

  it('shows the server error next to Guests when another guest took the seats first', async () => {
    renderAt('/book/red-wine-cellar-tour');
    await screen.findByLabelText('Name');
    backend.store.book('red-wine-cellar-tour', { name: 'A', email: 'a@b.de', guests: 6 });
    const user = await fill('Anna', 'anna@example.com', '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription('Only 2 seats left.');
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
  });

  it('confirms a booking with tasting, guests, total and reference', async () => {
    renderAt('/book/riesling-evening');
    await screen.findByLabelText('Name');
    const user = await fill('Anna Weber', 'anna@example.com', '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText(/Riesling Evening/)).toBeInTheDocument();
    expect(screen.getByText('3')).toBeInTheDocument();
    expect(screen.getByText('EUR 75')).toBeInTheDocument();
    const ref = backend.store.bookingsByTasting()[0].bookings[0].reference;
    expect(screen.getByText(ref)).toBeInTheDocument();
  });

  it('shows a fully-booked notice instead of the form for a sold-out tasting', async () => {
    backend.store.book('red-wine-cellar-tour', { name: 'A', email: 'a@b.de', guests: 8 });
    renderAt('/book/red-wine-cellar-tour');
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: /other tastings/i })).toBeInTheDocument();
  });

  it('starts with a guest count that fits when only one seat is left', async () => {
    backend.store.book('red-wine-cellar-tour', { name: 'A', email: 'a@b.de', guests: 7 });
    renderAt('/book/red-wine-cellar-tour');
    expect(await screen.findByLabelText('Guests')).toHaveValue(1);
  });

  it('shows a not-found message for an unknown tasting', async () => {
    renderAt('/book/nope');
    expect(await screen.findByText(/could not find that tasting/i)).toBeInTheDocument();
  });

  it('disables the Book button while the request is in flight', async () => {
    renderAt('/book/riesling-evening');
    await screen.findByLabelText('Name');
    const user = await fill('Anna', 'anna@example.com', '1');
    const real = globalThis.fetch;
    let release!: () => void;
    globalThis.fetch = ((...args: Parameters<typeof fetch>) =>
      new Promise((resolve) => (release = () => resolve(real(...args))))) as typeof fetch;
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('button', { name: /Booking/ })).toBeDisabled();
    globalThis.fetch = real;
    release();
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
  });
});

describe('confirmation page', () => {
  it('survives a reload and says so for an unknown reference', async () => {
    const r = backend.store.book('winter-tasting', { name: 'A', email: 'a@b.de', guests: 2 });
    if (!r.ok || !('booking' in r)) throw new Error();
    renderAt(`/booking/${r.booking.reference}`);
    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('EUR 56')).toBeInTheDocument();
    cleanup();
    renderAt('/booking/KB-AAAAAA');
    expect(await screen.findByText(/could not find that booking/i)).toBeInTheDocument();
  });
});
