import type { AddressInfo } from 'node:net';
import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { AppRoutes } from '../../src/App';
import { createApp } from '../../server/app';
import { createStore, type Store } from '../../server/store';

/** Starts the real Express app on an ephemeral port and routes the browser's fetch to it, with a cookie jar. */
export async function startBackend(staffPassword = 'secret') {
  const store: Store = createStore();
  const server = createApp({ store, staffPassword, loginLimit: 1000 }).listen(0);
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const realFetch = globalThis.fetch;
  const jar = new Map<string, string>();

  globalThis.fetch = (async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const headers = new Headers(init.headers);
    if (jar.size) headers.set('cookie', [...jar].map(([k, v]) => `${k}=${v}`).join('; '));
    const res = await realFetch(new URL(String(input), base), { ...init, headers });
    for (const line of res.headers.getSetCookie()) {
      const [pair] = line.split(';');
      const [k, v] = pair.split('=');
      if (/Max-Age=0|Expires=Thu, 01 Jan 1970/i.test(line)) jar.delete(k);
      else jar.set(k, v);
    }
    return res;
  }) as typeof fetch;

  return {
    store,
    close: () => {
      globalThis.fetch = realFetch;
      server.close();
    },
  };
}

export const renderAt = (path: string) =>
  render(
    <MemoryRouter initialEntries={[path]}>
      <AppRoutes />
    </MemoryRouter>,
  );
