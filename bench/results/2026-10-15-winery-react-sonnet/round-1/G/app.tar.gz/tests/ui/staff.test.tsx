// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { cleanup, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderAt, startBackend } from './helpers';

let backend: Awaited<ReturnType<typeof startBackend>>;
beforeEach(async () => {
  backend = await startBackend('secret');
});
afterEach(() => {
  cleanup();
  backend.close();
});

async function signIn(password = 'secret') {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
  return user;
}

describe('staff page', () => {
  it('asks for a password when signed out', async () => {
    renderAt('/staff');
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument();
  });

  it('shows an error next to the field for a wrong password', async () => {
    renderAt('/staff');
    await signIn('wrong');
    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription('Wrong password.');
    expect(screen.queryByRole('button', { name: 'Cancel' })).not.toBeInTheDocument();
  });

  it('shows bookings grouped by tasting after signing in', async () => {
    backend.store.book('riesling-evening', { name: 'Anna Weber', email: 'anna@example.com', guests: 3 });
    backend.store.book('winter-tasting', { name: 'Ben Roth', email: 'ben@example.com', guests: 2 });
    renderAt('/staff');
    await signIn();
    const riesling = (await screen.findByRole('heading', { name: /Riesling Evening/ })).closest('section')!;
    expect(within(riesling).getByText('Anna Weber')).toBeInTheDocument();
    expect(within(riesling).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(riesling).getByText('3')).toBeInTheDocument();
    const ref = backend.store.bookingsByTasting()[0].bookings[0].reference;
    expect(within(riesling).getByText(ref)).toBeInTheDocument();
    expect(within(riesling).queryByText('Ben Roth')).not.toBeInTheDocument();
    const cellar = screen.getByRole('heading', { name: /Red Wine Cellar Tour/ }).closest('section')!;
    expect(within(cellar).getByText('No bookings yet.')).toBeInTheDocument();
  });

  it('cancels a booking, removes it from the list and frees the seats', async () => {
    backend.store.book('winter-tasting', { name: 'Ben Roth', email: 'ben@example.com', guests: 4 });
    renderAt('/staff');
    const user = await signIn();
    await screen.findByText('Ben Roth');
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    await waitFor(() => expect(screen.queryByText('Ben Roth')).not.toBeInTheDocument());
    expect(screen.getAllByText('No bookings yet.')).toHaveLength(3);
    expect(backend.store.getTasting('winter-tasting')?.seatsLeft).toBe(10);
  });

  it('returns to the sign-in form when the session has expired during a cancel', async () => {
    backend.store.book('winter-tasting', { name: 'Ben Roth', email: 'ben@example.com', guests: 1 });
    renderAt('/staff');
    const user = await signIn();
    await screen.findByText('Ben Roth');
    const real = globalThis.fetch;
    globalThis.fetch = ((input: RequestInfo | URL, init?: RequestInit) =>
      init?.method === 'DELETE'
        ? Promise.resolve(new Response(JSON.stringify({ error: 'Please sign in.' }), { status: 401 }))
        : Promise.reject(new TypeError('offline'))) as typeof fetch;
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    globalThis.fetch = real;
  });

  it('does not report a failed cancel when the booking was cancelled but the refresh failed', async () => {
    backend.store.book('winter-tasting', { name: 'Ben Roth', email: 'ben@example.com', guests: 1 });
    renderAt('/staff');
    const user = await signIn();
    await screen.findByText('Ben Roth');
    const real = globalThis.fetch;
    globalThis.fetch = ((input: RequestInfo | URL, init?: RequestInit) =>
      init?.method === 'DELETE' ? real(input, init) : Promise.reject(new TypeError('offline'))) as typeof fetch;
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    await screen.findByRole('alert');
    expect(screen.getByRole('alert')).not.toHaveTextContent(/could not be cancelled/i);
    expect(backend.store.getTasting('winter-tasting')?.seatsLeft).toBe(10);
    globalThis.fetch = real;
  });

  it('renders HTML in names as plain text', async () => {
    backend.store.book('winter-tasting', { name: '<img src=x onerror=alert(1)>', email: 'x@example.com', guests: 1 });
    renderAt('/staff');
    await signIn();
    expect(await screen.findByText('<img src=x onerror=alert(1)>')).toBeInTheDocument();
    expect(document.querySelector('img')).toBeNull();
  });

  it('stays signed in on reload and signs out on request', async () => {
    renderAt('/staff');
    const user = await signIn();
    await screen.findByRole('heading', { name: /Winter Tasting/ });
    cleanup();
    renderAt('/staff');
    await screen.findByRole('heading', { name: /Winter Tasting/ });
    await user.click(screen.getByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });
});
