# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff see and cancel the bookings.
React 19 + Vite on the front, Express 5 on the back, one process, bookings held in memory (the app starts empty).

```bash
npm install
npm run build
STAFF_PASSWORD='choose-a-long-password' npm start   # http://localhost:3000, or set PORT
```

| Variable | Meaning |
|---|---|
| `PORT` | Port to listen on (default 3000) |
| `STAFF_PASSWORD` | Password for `/staff`. If unset, staff sign-in is refused. A warning is logged below 12 characters |
| `TRUST_PROXY` | Number of reverse proxies in front of the app (default 0). Set it so rate limits see real client IPs and the session cookie gets `Secure` over HTTPS |
| `CLIENT_DIR` | Folder with the built client (default: `dist/client` next to the server) |

## Develop and test

```bash
npm run dev:server   # API on :3000 (tsx watch); needs CLIENT_DIR only for the built UI
npm run dev:client   # Vite on :5173, proxies /api to :3000
npm test             # unit, component and API tests (Vitest)
npm run test:coverage
npm run typecheck
npm run test:e2e     # Playwright against the built app (builds first); needs Chromium: npx playwright install chromium
```

The design decisions and requirements are in [docs/SPEC.md](docs/SPEC.md).
