# Weingut Kieselbrunnen — Tasting Booking: Specification

Status: draft v1 · Source: product brief from the winery (verbatim requirements restated below).

## 1. Goal

Guests book wine tastings online; staff see and cancel bookings. One Node.js 22 process serves the API and the React UI (`npm install`, `npm run build`, `npm start`, port `PORT`, default 3000). Interface language: English. No external services; bookings are held in memory and the app starts empty.

## 2. Locked decisions

| # | Decision | Reason |
|---|---|---|
| D1 | Express 5 + TypeScript server, React 19 + Vite SPA, React Router, TanStack Query, react-hook-form + zod | Established libraries for server, routing, data, forms, validation |
| D2 | One zod schema module shared by client and server | Same rules, same messages |
| D3 | In-memory store; synchronous booking operation | No overbooking race in a single Node process; spec says app starts with no bookings |
| D4 | Staff auth = shared password from `STAFF_PASSWORD`, httpOnly SameSite=Strict session cookie, in-memory sessions. If `STAFF_PASSWORD` is unset or empty, staff login is refused (fail closed, no default password) | No secrets in code |
| D5 | Cancelling deletes the booking (it disappears from the list and its seats are freed) | Matches "frees its seats" |
| D6 | Plain CSS with design tokens, self-hosted fonts (@fontsource) | No external requests, small bundle |
| D7 | Display format of date/time `YYYY-MM-DD HH:mm` (as in the brief); price `EUR n`; seats `<n> seats left` literally | Match the brief exactly |

## 3. Data

Tastings (seeded, fixed):

| id | title | starts | price/guest (EUR) | seats |
|---|---|---|---|---|
| riesling-evening | Riesling Evening | 2026-11-06 18:00 | 25 | 12 |
| red-wine-cellar-tour | Red Wine Cellar Tour | 2026-11-14 15:00 | 32 | 8 |
| winter-tasting | Winter Tasting | 2026-12-05 17:00 | 28 | 10 |

Booking: `reference` (e.g. `KB-7F3K9Q`, random, unambiguous alphabet, unique), `tastingId`, `name`, `email`, `guests` (int 1–8). Insertion order is the booking order.
`seatsLeft = seats − Σ guests of bookings of that tasting`.
Total price = `guests × price` (integer EUR).

## 4. Requirements

### Guest

- **G1** `/` lists all tastings: title, date and time, price per guest, `<n> seats left`.
- **G2** Each tasting has a link/button `Book <title>` (e.g. `Book Riesling Evening`) opening `/book/:id` with a form: `Name`, `Email`, `Guests` (1–8) and a `Book` button.
- **G3** A booking can never exceed seats left (enforced on the server atomically; the form also reflects it). Guests max is `min(8, seatsLeft)`.
- **G4** Invalid input is rejected with an error message next to the offending field (client and server). Rules:
  - Name: required (trimmed), ≤ 100 chars.
  - Email: required, valid address, ≤ 254 chars.
  - Guests: required, whole number, 1–8, ≤ seats left. Over capacity: "Only n seats left for this tasting." Sold out: "This tasting is fully booked."
  - Server validation errors come back as `{ errors: { field: message } }` and are shown by the matching field.
- **G5** After success: heading `Booking confirmed`, tasting title + date/time, number of guests, total price (`EUR n`), booking reference.
- **G6** Fully booked tasting (0 seats): start page shows a "Fully booked" state, no active booking action; `/book/:id` shows a fully-booked message instead of a form. Unknown tasting id → friendly not-found page.

### Staff

- **S1** `/staff` shows a sign-in form: `Password` field, `Sign in` button. Wrong password → error next to the field. Rate-limited.
- **S2** Signed in: all bookings grouped by tasting (name, email, guests, reference), each group showing the tasting title, date/time and seats taken/left; empty groups say "No bookings yet".
- **S3** `Cancel` button per booking removes it; seats are freed (start page reflects it). Staff API calls require the session.
- **S4** `Sign out` ends the session.

### Look and feel

- **L1** Coherent winery look: burgundy/cream/gold palette, serif headings, header with wordmark, footer.
- **L2** Distinct states: field errors (red, icon + text, `aria-invalid`), success (green confirmation card), fully booked (muted card + badge), loading and load-failure messages with retry.
- **L3** Mobile-first responsive layout; tap targets ≥ 44 px; inputs ≥ 16 px font; no horizontal scroll at 320 px.
- **L4** Accessible: labels bound to inputs, errors linked via `aria-describedby`, focus moves to the confirmation heading and to the first invalid field, visible focus rings, contrast ≥ 4.5:1, `prefers-reduced-motion` respected.

## 5. API

| Method & path | Auth | Result |
|---|---|---|
| `GET /api/tastings` | – | `[{id,title,startsAt,pricePerGuest,seats,seatsLeft}]` |
| `GET /api/tastings/:id` | – | one tasting or 404 |
| `POST /api/tastings/:id/bookings` `{name,email,guests}` | – | 201 `{booking:{reference,tastingId,name,guests,total}, tasting}`; 400 `{errors}`; 404; 409 `{errors:{guests}}` when it no longer fits |
| `POST /api/staff/session` `{password}` | – | 204 + cookie; 401 `{errors:{password}}`; 429 |
| `GET /api/staff/session` | cookie | 204 / 401 |
| `DELETE /api/staff/session` | – (idempotent: always 204, clears the cookie, ends the session if any) | 204 |
| `GET /api/staff/bookings` | cookie | `[{tasting:{…tasting, seatsLeft}, bookings:[{reference,name,email,guests}]}]`, sorted by start time |
| `DELETE /api/staff/bookings/:reference` | cookie | 204 / 404 |

## 6. Non-functional

- Security: helmet headers (no HSTS / upgrade-insecure-requests: the app speaks plain HTTP, TLS belongs to the proxy), `Cache-Control: no-store` on all API answers, JSON body limit, constant-time password compare, no PII on public endpoints, no stack traces to clients, rate limiting on login (10 failures / 15 min / IP) and booking (120 / 10 min / IP), `TRUST_PROXY=<hops>` for deployments behind a reverse proxy, security events logged without secrets, React escapes all output.
- Known limitation: bookings are unauthenticated (no e-mail verification), so a bot could hold seats; staff cancel them. A per-e-mail cap was rejected because it would block legitimate repeat bookings.
- `PORT` env var (default 3000); unknown `/api/*` → JSON 404; all other GETs fall back to the SPA (`/staff`, `/book/:id` work on reload).
- Tests: unit (store, schema), API integration, component tests, Playwright E2E over the built app; ≥ 80 % coverage.

## 7. Vertical slices

1. **Slice 1 — Guest booking** (G1–G6): store, API, start page, booking form, confirmation, design system.
2. **Slice 2 — Staff** (S1–S4): auth, bookings list, cancel.
3. **Slice 3 — Polish & hardening**: states, a11y, responsive audit, security review.

## 8. Out of scope

Payments, e-mail sending, editing bookings, persistence across restarts, rules about tastings in the past (all three dates are in the future), admin editing of tastings.
