export const E2E_PORT = 3100
export const STAFF_PASSWORD = 'e2e-staff-password'
