import { expect, test } from '@playwright/test'
import { bookViaApi, fillBooking, guest, resetBookings } from './helpers.js'

test.beforeEach(async ({ request }) => resetBookings(request))

test('the start page lists the three tastings', async ({ page }) => {
  await page.goto('/')
  const riesling = page.getByRole('article', { name: 'Riesling Evening' })
  await expect(riesling).toContainText('2026-11-06 18:00')
  await expect(riesling).toContainText('EUR 25 per guest')
  await expect(riesling).toContainText('12 seats left')
  const tour = page.getByRole('article', { name: 'Red Wine Cellar Tour' })
  await expect(tour).toContainText('2026-11-14 15:00')
  await expect(tour).toContainText('EUR 32 per guest')
  await expect(tour).toContainText('8 seats left')
  const winter = page.getByRole('article', { name: 'Winter Tasting' })
  await expect(winter).toContainText('2026-12-05 17:00')
  await expect(winter).toContainText('EUR 28 per guest')
  await expect(winter).toContainText('10 seats left')
})

test('a guest books a tasting and sees the confirmation', async ({ page }) => {
  await page.goto('/')
  await page.getByRole('link', { name: 'Book Riesling Evening' }).click()
  await expect(page).toHaveURL(/\/book\/riesling-evening$/)

  await fillBooking(page, { ...guest, guests: '3' })
  await page.getByRole('button', { name: 'Book' }).click()

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeFocused()
  const main = page.getByRole('main')
  await expect(main).toContainText('Riesling Evening')
  await expect(main).toContainText('2026-11-06 18:00')
  await expect(main).toContainText('EUR 75')
  await expect(main.getByText(/^KB-[A-Z0-9]{6}$/)).toBeVisible()

  await page.getByRole('link', { name: 'See all tastings' }).click()
  await expect(page.getByRole('article', { name: 'Riesling Evening' })).toContainText('9 seats left')
})

test('invalid input is rejected next to the field it concerns', async ({ page }) => {
  await page.goto('/book/riesling-evening')
  await fillBooking(page, { name: '', email: 'nope', guests: '9' })
  await page.getByRole('button', { name: 'Book' }).click()

  for (const [label, text] of [
    ['Name', 'Enter your name.'],
    ['Email', 'Enter a valid email address'],
    ['Guests', 'You can book up to 8 guests at a time.'],
  ] as const) {
    const field = page.locator('.field').filter({ has: page.getByLabel(label) })
    await expect(field).toContainText(text)
    await expect(page.getByLabel(label)).toHaveAttribute('aria-invalid', 'true')
  }
  await expect(page.getByLabel('Name')).toBeFocused()
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0)
})

test('a booking can never take more seats than are left, and fills the tasting exactly', async ({ page, request }) => {
  await bookViaApi(request, 'red-wine-cellar-tour', 6)
  await page.goto('/book/red-wine-cellar-tour')

  await fillBooking(page, { ...guest, guests: '3' })
  await page.getByRole('button', { name: 'Book' }).click()
  await expect(page.locator('.field').filter({ has: page.getByLabel('Guests') })).toContainText('Only 2 seats left for this tasting.')

  await page.getByLabel('Guests').fill('2')
  await page.getByRole('button', { name: 'Book' }).click()
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()

  await page.goto('/')
  const tour = page.getByRole('article', { name: 'Red Wine Cellar Tour' })
  await expect(tour).toContainText('Fully booked')
  await expect(tour).toContainText('0 seats left')
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0)

  await page.goto('/book/red-wine-cellar-tour')
  await expect(page.getByText('Fully booked', { exact: true })).toBeVisible()
  await expect(page.getByLabel('Name')).toHaveCount(0)
})

test('seats taken by someone else while the form is open are reported at the guests field', async ({ page, request }) => {
  await page.goto('/book/red-wine-cellar-tour')
  await expect(page.getByLabel('Guests')).toHaveAttribute('max', '8')
  await bookViaApi(request, 'red-wine-cellar-tour', 7)

  await fillBooking(page, { ...guest, guests: '4' })
  await page.getByRole('button', { name: 'Book' }).click()
  await expect(page.locator('.field').filter({ has: page.getByLabel('Guests') })).toContainText('Only 1 seat left for this tasting.')
  await expect(page.getByLabel('Guests')).toHaveAttribute('max', '1')
})

test('booking pages work when opened or reloaded directly', async ({ page }) => {
  await page.goto('/book/winter-tasting')
  await expect(page.getByRole('heading', { name: 'Winter Tasting' })).toBeVisible()
  await page.reload()
  await expect(page.getByRole('heading', { name: 'Winter Tasting' })).toBeVisible()
  await page.goto('/book/unknown')
  await expect(page.getByRole('heading', { name: 'Tasting not found' })).toBeVisible()
})
