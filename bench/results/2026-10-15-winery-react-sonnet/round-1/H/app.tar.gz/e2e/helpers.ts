import { expect, type APIRequestContext, type Page } from '@playwright/test'

import { STAFF_PASSWORD } from './constants.js'

export const guest = { name: 'Anna Weber', email: 'anna@example.com' }

/** Cancel every booking through the staff API, so each test starts from an empty winery. */
export async function resetBookings(request: APIRequestContext): Promise<void> {
  const login = await request.post('/api/staff/session', { data: { password: STAFF_PASSWORD } })
  expect(login.status()).toBe(204)
  const groups = (await (await request.get('/api/staff/bookings')).json()) as { bookings: { reference: string }[] }[]
  for (const { bookings } of groups) {
    for (const { reference } of bookings) {
      expect((await request.delete(`/api/staff/bookings/${reference}`)).status()).toBe(204)
    }
  }
  await request.delete('/api/staff/session')
}

export async function bookViaApi(request: APIRequestContext, tastingId: string, guests: number, extra: { name?: string } = {}) {
  const response = await request.post(`/api/tastings/${tastingId}/bookings`, { data: { ...guest, ...extra, guests } })
  expect(response.status()).toBe(201)
  return (await response.json()).booking.reference as string
}

export async function fillBooking(page: Page, { name, email, guests }: { name: string; email: string; guests: string }) {
  await page.getByLabel('Name').fill(name)
  await page.getByLabel('Email').fill(email)
  await page.getByLabel('Guests').fill(guests)
}

export async function signInAsStaff(page: Page) {
  await page.goto('/staff')
  await page.getByLabel('Password').fill(STAFF_PASSWORD)
  await page.getByRole('button', { name: 'Sign in' }).click()
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible()
}
