import AxeBuilder from '@axe-core/playwright'
import { expect, test, type Page } from '@playwright/test'
import { bookViaApi, fillBooking, guest, resetBookings, signInAsStaff } from './helpers.js'

test.beforeEach(async ({ request }) => resetBookings(request))

async function expectAccessibleAndFitting(page: Page) {
  // Reduced motion switches transitions off, so axe never samples a control halfway through a hover fade.
  await page.emulateMedia({ reducedMotion: 'reduce' })
  await page.mouse.move(0, 0)
  const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa']).analyze()
  expect(results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(' ')).join(', ')}`)).toEqual([])
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)
  expect(overflow).toBeLessThanOrEqual(0)
}

async function expectTapTargets(page: Page) {
  const tooSmall = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>('main a.button, main button, main input, footer a, header a')]
      .map((el) => ({ el: el.textContent?.trim() || el.id, box: el.getBoundingClientRect() }))
      .filter(({ box }) => box.height > 0 && box.height < 43.5)
      .map(({ el, box }) => `${el} (${Math.round(box.height)}px)`),
  )
  expect(tooSmall).toEqual([])
}

test('start page: accessible, no horizontal scroll, comfortable tap targets', async ({ page }) => {
  await page.goto('/')
  await expect(page.getByRole('article', { name: 'Riesling Evening' })).toBeVisible()
  await expectAccessibleAndFitting(page)
  await expectTapTargets(page)
})

test('start page with a fully booked tasting stays accessible', async ({ page, request }) => {
  await bookViaApi(request, 'red-wine-cellar-tour', 8)
  await page.goto('/')
  await expect(page.getByText('Fully booked')).toBeVisible()
  await expectAccessibleAndFitting(page)
})

test('booking form, its error state and the confirmation are accessible', async ({ page }) => {
  await page.goto('/book/riesling-evening')
  await expectAccessibleAndFitting(page)
  await expectTapTargets(page)

  await fillBooking(page, { name: '', email: 'bad', guests: '0' })
  await page.getByRole('button', { name: 'Book' }).click()
  await expect(page.getByText('Enter your name.')).toBeVisible()
  await expectAccessibleAndFitting(page)

  await fillBooking(page, { ...guest, guests: '2' })
  await page.getByRole('button', { name: 'Book' }).click()
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
  await expectAccessibleAndFitting(page)
})

test('staff sign-in and bookings list are accessible and fit the screen', async ({ page, request }) => {
  await bookViaApi(request, 'riesling-evening', 2, { name: 'Anna Weber-Hohenstaufen-Longname' })
  await page.goto('/staff')
  await expect(page.getByLabel('Password')).toBeVisible()
  await expectAccessibleAndFitting(page)

  await signInAsStaff(page)
  await expect(page.getByText('Anna Weber-Hohenstaufen-Longname')).toBeVisible()
  await expectAccessibleAndFitting(page)
  await expectTapTargets(page)
})

test.describe('screenshots for visual review', () => {
  test.skip(!process.env.SCREENSHOT_DIR, 'set SCREENSHOT_DIR to capture')

  for (const width of [320, 768, 1024, 1440]) {
    test(`pages at ${width}px`, async ({ page, request }) => {
      await page.setViewportSize({ width, height: 900 })
      const dir = process.env.SCREENSHOT_DIR!
      await bookViaApi(request, 'red-wine-cellar-tour', 8)
      await bookViaApi(request, 'riesling-evening', 3, { name: 'Anna Weber' })
      await page.goto('/')
      await expect(page.getByRole('article', { name: 'Riesling Evening' })).toBeVisible()
      await page.screenshot({ path: `${dir}/home-${width}.png`, fullPage: true })

      await page.goto('/book/riesling-evening')
      await fillBooking(page, { name: '', email: 'bad', guests: '0' })
      await page.getByRole('button', { name: 'Book' }).click()
      await expect(page.getByText('Enter your name.')).toBeVisible()
      await page.screenshot({ path: `${dir}/form-errors-${width}.png`, fullPage: true })

      await fillBooking(page, { ...guest, guests: '2' })
      await page.getByRole('button', { name: 'Book' }).click()
      await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
      await page.screenshot({ path: `${dir}/confirmed-${width}.png`, fullPage: true })

      await page.goto('/staff')
      await page.screenshot({ path: `${dir}/staff-login-${width}.png`, fullPage: true })
      await signInAsStaff(page)
      await page.screenshot({ path: `${dir}/staff-list-${width}.png`, fullPage: true })
    })
  }
})
