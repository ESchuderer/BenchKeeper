import { expect, test } from '@playwright/test'
import { bookViaApi, resetBookings, signInAsStaff } from './helpers.js'

test.beforeEach(async ({ request }) => resetBookings(request))

test('staff must sign in; a wrong password is reported at the password field', async ({ page }, testInfo) => {
  // Failed attempts are rate limited per IP; keep them to the desktop run.
  test.skip(testInfo.project.name !== 'desktop', 'covered once, on desktop')
  await page.goto('/staff')
  await expect(page.getByRole('heading', { name: 'Bookings' })).toHaveCount(0)
  await page.getByLabel('Password').fill('not-the-password')
  await page.getByRole('button', { name: 'Sign in' }).click()
  await expect(page.locator('.field').filter({ has: page.getByLabel('Password') })).toContainText('Incorrect password.')
  await expect(page.getByLabel('Password')).toBeFocused()
})

test('the staff API is closed without a session', async ({ request }) => {
  expect((await request.get('/api/staff/bookings')).status()).toBe(401)
  expect((await request.delete('/api/staff/bookings/KB-AAAAAA')).status()).toBe(401)
})

test('staff see bookings grouped by tasting and the session survives a reload', async ({ page, request }) => {
  const reference = await bookViaApi(request, 'riesling-evening', 2, { name: 'Anna Weber' })
  await signInAsStaff(page)

  const riesling = page.getByRole('region', { name: 'Riesling Evening' })
  const row = riesling.getByRole('row', { name: /Anna Weber/ })
  await expect(row).toContainText('anna@example.com')
  await expect(row).toContainText('2')
  await expect(row).toContainText(reference)
  await expect(riesling).toContainText('2 of 12 seats taken')
  await expect(page.getByRole('region', { name: 'Red Wine Cellar Tour' })).toContainText('No bookings yet')

  await page.reload()
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible()
})

test('cancelling a booking removes it and frees its seats', async ({ page, request }) => {
  await bookViaApi(request, 'red-wine-cellar-tour', 8, { name: 'Anna Weber' })
  await bookViaApi(request, 'winter-tasting', 2, { name: 'Ben Roth' })
  await signInAsStaff(page)

  const tour = page.getByRole('region', { name: 'Red Wine Cellar Tour' })
  await tour.getByRole('row', { name: /Anna Weber/ }).getByRole('button', { name: 'Cancel' }).click()
  await expect(page.getByRole('status')).toContainText('Cancelled booking')
  await expect(tour).toContainText('No bookings yet')
  await expect(page.getByText('Ben Roth')).toBeVisible()

  await page.goto('/')
  await expect(page.getByRole('article', { name: 'Red Wine Cellar Tour' })).toContainText('8 seats left')
  await expect(page.getByRole('article', { name: 'Winter Tasting' })).toContainText('8 seats left')
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeVisible()
})

test('signing out closes the session', async ({ page }) => {
  await signInAsStaff(page)
  await page.getByRole('button', { name: 'Sign out' }).click()
  await expect(page.getByLabel('Password')).toBeVisible()
  await page.reload()
  await expect(page.getByLabel('Password')).toBeVisible()
  await expect(page.getByRole('heading', { name: 'Bookings' })).toHaveCount(0)
})
