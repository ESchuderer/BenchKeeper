import { defineConfig, devices } from '@playwright/test'

import { E2E_PORT as PORT, STAFF_PASSWORD } from './e2e/constants.js'

export default defineConfig({
  testDir: 'e2e',
  workers: 1, // the in-memory store is shared by the single test server
  fullyParallel: false,
  reporter: [['list']],
  use: { baseURL: `http://localhost:${PORT}`, trace: 'retain-on-failure' },
  webServer: {
    command: 'npm run build && npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    env: { PORT: String(PORT), STAFF_PASSWORD },
    reuseExistingServer: false,
    timeout: 60_000,
  },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['Pixel 7'], viewport: { width: 360, height: 740 } } },
  ],
})
