import { Route, Routes, useParams } from 'react-router'
import { Layout } from './components/Layout.js'
import { BookingPage } from './pages/BookingPage.js'
import { HomePage } from './pages/HomePage.js'
import { NotFoundPage } from './pages/NotFoundPage.js'
import { StaffPage } from './staff/StaffPage.js'

/** Keyed by tasting id: moving between two booking pages must not carry over a form or confirmation. */
function BookingRoute() {
  const { id = '' } = useParams()
  return <BookingPage key={id} id={id} />
}

export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="book/:id" element={<BookingRoute />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  )
}
