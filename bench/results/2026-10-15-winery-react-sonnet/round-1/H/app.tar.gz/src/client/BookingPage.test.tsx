import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { NETWORK_ERROR, fakeBackend, renderAt, reply, tastingViews, type FakeRoute } from '../test/clientHarness.js'


const created = (guests: number, seatsLeft: number) => ({
  booking: { reference: 'KB-7F3K9Q', tastingId: 'riesling-evening', name: 'Anna Weber', guests, total: guests * 25 },
  tasting: { ...tastingViews()[0]!, seatsLeft },
})

async function openForm(seatsLeft: Record<string, number> = {}, extra: Record<string, FakeRoute> = {}) {
  const backend = fakeBackend({ 'GET /api/tastings': reply(200, tastingViews(seatsLeft)), ...extra })
  renderAt('/')
  await userEvent.click(await screen.findByRole('link', { name: 'Book Riesling Evening' }))
  await screen.findByLabelText('Name')
  return backend
}

const fill = async (name: string, email: string, guests: string) => {
  const user = userEvent.setup()
  const nameInput = screen.getByLabelText('Name')
  const emailInput = screen.getByLabelText('Email')
  const guestsInput = screen.getByLabelText('Guests')
  await user.clear(nameInput)
  await user.clear(emailInput)
  await user.clear(guestsInput)
  if (name) await user.type(nameInput, name)
  if (email) await user.type(emailInput, email)
  if (guests) await user.type(guestsInput, guests)
}

const errorFor = (label: string) => {
  const input = screen.getByLabelText(label)
  const id = input.getAttribute('aria-describedby')
  return id ? document.getElementById(id.split(' ')[0]!) : null
}

describe('booking form', () => {
  it('opens for the chosen tasting with labelled fields and a Book button', async () => {
    await openForm()
    expect(screen.getByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument()
    expect(screen.getByText('2026-11-06 18:00')).toBeInTheDocument()
    expect(screen.getByLabelText('Name')).toHaveAttribute('autocomplete', 'name')
    expect(screen.getByLabelText('Email')).toHaveAttribute('type', 'email')
    const guests = screen.getByLabelText('Guests')
    expect(guests).toHaveAttribute('type', 'number')
    expect(guests).toHaveAttribute('min', '1')
    expect(guests).toHaveAttribute('max', '8')
    expect(screen.getByRole('button', { name: 'Book' })).toBeEnabled()
  })

  it('limits the guests field to the seats left', async () => {
    await openForm({ 'riesling-evening': 3 })
    expect(screen.getByLabelText('Guests')).toHaveAttribute('max', '3')
  })

  it('shows an error next to every invalid field and focuses the first one', async () => {
    const backend = await openForm()
    await fill('', 'not-an-email', '0')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByText('Enter your name.')).toBeInTheDocument()
    expect(errorFor('Name')).toHaveTextContent('Enter your name.')
    expect(errorFor('Email')).toHaveTextContent(/valid email address/i)
    expect(errorFor('Guests')).toHaveTextContent('Book for at least 1 guest.')
    expect(screen.getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true')
    expect(screen.getByLabelText('Name')).toHaveFocus()
    expect(backend.count('POST', '/api/tastings/riesling-evening/bookings')).toBe(0)
  })

  it('rejects more guests than seats left, next to the guests field', async () => {
    await openForm({ 'riesling-evening': 3 })
    await fill('Anna Weber', 'anna@example.com', '4')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    expect(await screen.findByText('Only 3 seats left for this tasting.')).toBeInTheDocument()
    expect(errorFor('Guests')).toHaveTextContent('Only 3 seats left for this tasting.')
  })

  it('rejects an empty guests field', async () => {
    await openForm()
    await fill('Anna Weber', 'anna@example.com', '')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    expect(errorFor('Guests')).toHaveTextContent('Enter the number of guests.')
  })

  it('clears an error once the field is corrected', async () => {
    await openForm()
    await fill('', 'anna@example.com', '2')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    await screen.findByText('Enter your name.')
    await userEvent.type(screen.getByLabelText('Name'), 'Anna')
    await waitFor(() => expect(screen.queryByText('Enter your name.')).not.toBeInTheDocument())
    expect(screen.getByLabelText('Name')).not.toHaveAttribute('aria-invalid', 'true')
  })

  it('confirms the booking with tasting, guests, total price and reference', async () => {
    let seats = 12
    const backend = await openForm(
      {},
      {
        'POST /api/tastings/riesling-evening/bookings': () => {
          seats -= 3
          return reply(201, created(3, seats))
        },
      },
    )
    await fill('Anna Weber', 'anna@example.com', '3')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))

    const heading = await screen.findByRole('heading', { name: 'Booking confirmed' })
    expect(heading).toHaveFocus()
    const main = screen.getByRole('main')
    expect(within(main).getByText('Riesling Evening')).toBeInTheDocument()
    expect(within(main).getByText('2026-11-06 18:00')).toBeInTheDocument()
    expect(within(main).getByText('3')).toBeInTheDocument()
    expect(within(main).getByText('EUR 75')).toBeInTheDocument()
    expect(within(main).getByText('KB-7F3K9Q')).toBeInTheDocument()
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument()
    expect(backend.calls.find((c) => c.method === 'POST')?.body).toEqual({ name: 'Anna Weber', email: 'anna@example.com', guests: 3 })
  })

  it('shows seats left updated on the start page after booking', async () => {
    let seats = 12
    fakeBackend({
      'GET /api/tastings': () => reply(200, tastingViews({ 'riesling-evening': seats })),
      'POST /api/tastings/riesling-evening/bookings': () => {
        seats -= 3
        return reply(201, created(3, seats))
      },
    })
    renderAt('/book/riesling-evening')
    await screen.findByLabelText('Name')
    await fill('Anna Weber', 'anna@example.com', '3')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    await screen.findByRole('heading', { name: 'Booking confirmed' })
    await userEvent.click(screen.getByRole('link', { name: /all tastings/i }))
    expect(await screen.findByText('9 seats left')).toBeInTheDocument()
  })

  it('shows server field errors next to the matching fields', async () => {
    await openForm(
      {},
      { 'POST /api/tastings/riesling-evening/bookings': reply(400, { errors: { email: 'Enter a valid email address, like name@example.com.' } }) },
    )
    await fill('Anna Weber', 'anna@example.com', '2')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    expect(await screen.findByText(/valid email address/i)).toBeInTheDocument()
    expect(errorFor('Email')).toHaveTextContent(/valid email address/i)
    expect(screen.getByLabelText('Email')).toHaveFocus()
  })

  it('handles seats that were taken meanwhile: message at the guests field and fresh seat count', async () => {
    let seats = 12
    fakeBackend({
      'GET /api/tastings': () => reply(200, tastingViews({ 'riesling-evening': seats })),
      'POST /api/tastings/riesling-evening/bookings': () => {
        seats = 2
        return reply(409, { errors: { guests: 'Only 2 seats left for this tasting.' } })
      },
    })
    renderAt('/book/riesling-evening')
    await screen.findByLabelText('Name')
    await fill('Anna Weber', 'anna@example.com', '4')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    expect(await screen.findByText('Only 2 seats left for this tasting.')).toBeInTheDocument()
    await waitFor(() => expect(screen.getByLabelText('Guests')).toHaveAttribute('max', '2'))
  })

  it('shows a general error when the server cannot be reached and keeps the input', async () => {
    await openForm({}, { 'POST /api/tastings/riesling-evening/bookings': reply(500, { error: 'Something went wrong. Please try again.' }) })
    await fill('Anna Weber', 'anna@example.com', '2')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    expect(await screen.findByRole('alert')).toHaveTextContent('Something went wrong. Please try again.')
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Weber')
  })

  it('disables the button while the booking is being sent', async () => {
    let release: () => void = () => {}
    const gate = new Promise<void>((resolve) => (release = resolve))
    await openForm(
      {},
      {
        'POST /api/tastings/riesling-evening/bookings': async () => {
          await gate
          return reply(201, created(2, 10))
        },
      },
    )
    await fill('Anna Weber', 'anna@example.com', '2')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    expect(await screen.findByRole('button', { name: /Booking/ })).toBeDisabled()
    release()
    await screen.findByRole('heading', { name: 'Booking confirmed' })
  })
})

describe('booking page states', () => {
  it('shows a fully booked message instead of the form', async () => {
    fakeBackend({ 'GET /api/tastings': reply(200, tastingViews({ 'riesling-evening': 0 })) })
    renderAt('/book/riesling-evening')
    expect(await screen.findByText('Fully booked')).toBeInTheDocument()
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument()
    expect(screen.getByRole('link', { name: /other tastings/i })).toHaveAttribute('href', '/')
  })

  it('shows not found for an unknown tasting', async () => {
    fakeBackend({ 'GET /api/tastings': reply(200, tastingViews()) })
    renderAt('/book/nope')
    expect(await screen.findByRole('heading', { name: /tasting not found/i })).toBeInTheDocument()
  })

  it('shows a retryable error when the tastings cannot be loaded', async () => {
    fakeBackend({ 'GET /api/tastings': reply(500, { error: 'Something went wrong. Please try again.' }) })
    renderAt('/book/riesling-evening')
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i)
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument()
  })
})

describe('booking form: review findings', () => {
  it('confirms right away and does not wait for the seat-count refresh to finish', async () => {
    let tastingsCalls = 0
    fakeBackend({
      'GET /api/tastings': () => (++tastingsCalls === 1 ? reply(200, tastingViews()) : new Promise<never>(() => {})),
      'POST /api/tastings/riesling-evening/bookings': reply(201, created(2, 10)),
    })
    renderAt('/book/riesling-evening')
    await screen.findByLabelText('Name')
    await fill('Anna Weber', 'anna@example.com', '2')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument()
    await waitFor(() => expect(tastingsCalls).toBe(2)) // the refresh was started, just not awaited
  })

  it('shows the confirmation, never a "Fully booked" flash, when the booking takes the last seats', async () => {
    let seats = 2
    let tastingsCalls = 0
    fakeBackend({
      'GET /api/tastings': () => {
        tastingsCalls++
        return reply(200, tastingViews({ 'riesling-evening': seats }))
      },
      'POST /api/tastings/riesling-evening/bookings': () => {
        seats = 0
        return reply(201, created(2, 0))
      },
    })
    renderAt('/book/riesling-evening')
    await screen.findByLabelText('Name')
    await fill('Anna Weber', 'anna@example.com', '2')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument()
    await waitFor(() => expect(tastingsCalls).toBe(2))
    expect(screen.queryByText('Fully booked')).not.toBeInTheDocument()
    expect(screen.getByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument()
  })

  it('says the server cannot be reached and keeps what was typed', async () => {
    await openForm({}, { 'POST /api/tastings/riesling-evening/bookings': NETWORK_ERROR })
    await fill('Anna Weber', 'anna@example.com', '2')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach the server/i)
    expect(screen.getByLabelText('Email')).toHaveValue('anna@example.com')
  })

  it('words the guests hint correctly for one seat and for several', async () => {
    await openForm({ 'riesling-evening': 1 })
    expect(screen.getByText('1 guest')).toBeInTheDocument()
    expect(screen.getByLabelText('Guests')).toHaveValue(1)
  })

  it('says all fields are required and marks them as required', async () => {
    await openForm()
    expect(screen.getByText('All fields are required.')).toBeInTheDocument()
    for (const label of ['Name', 'Email', 'Guests']) expect(screen.getByLabelText(label)).toBeRequired()
    expect(screen.getByText('1 to 8 guests')).toBeInTheDocument()
  })

  it('moves focus to the page content when navigating to the booking page', async () => {
    await openForm()
    expect(screen.getByRole('main')).toHaveFocus()
  })
})
