import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { fakeBackend, renderAt, reply, tastingViews } from '../test/clientHarness.js'


describe('start page', () => {
  it('lists every tasting with title, date and time, price per guest and seats left', async () => {
    fakeBackend({ 'GET /api/tastings': reply(200, tastingViews({ 'red-wine-cellar-tour': 5 })) })
    renderAt('/')

    expect(await screen.findByRole('heading', { level: 1 })).toBeInTheDocument()
    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' })
    expect(within(riesling).getByText('2026-11-06 18:00')).toBeInTheDocument()
    expect(within(riesling).getByText('EUR 25 per guest')).toBeInTheDocument()
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument()

    const tour = screen.getByRole('article', { name: 'Red Wine Cellar Tour' })
    expect(within(tour).getByText('2026-11-14 15:00')).toBeInTheDocument()
    expect(within(tour).getByText('EUR 32 per guest')).toBeInTheDocument()
    expect(within(tour).getByText('5 seats left')).toBeInTheDocument()

    const winter = screen.getByRole('article', { name: 'Winter Tasting' })
    expect(within(winter).getByText('EUR 28 per guest')).toBeInTheDocument()
    expect(within(winter).getByText('10 seats left')).toBeInTheDocument()
  })

  it('offers a "Book <title>" link to the booking form of each tasting', async () => {
    fakeBackend({ 'GET /api/tastings': reply(200, tastingViews()) })
    renderAt('/')
    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' })
    expect(link).toHaveAttribute('href', '/book/riesling-evening')
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveAttribute('href', '/book/red-wine-cellar-tour')
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toHaveAttribute('href', '/book/winter-tasting')
  })

  it('shows a fully booked tasting as such, without a way to book it', async () => {
    fakeBackend({ 'GET /api/tastings': reply(200, tastingViews({ 'winter-tasting': 0 })) })
    renderAt('/')
    const winter = await screen.findByRole('article', { name: 'Winter Tasting' })
    expect(within(winter).getByText('Fully booked')).toBeInTheDocument()
    expect(within(winter).getByText('0 seats left')).toBeInTheDocument()
    expect(within(winter).queryByRole('link')).not.toBeInTheDocument()
    expect(within(winter).queryByRole('button')).not.toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toBeInTheDocument()
  })

  it('shows a loading state, then an error with a retry that works', async () => {
    let fail = true
    const backend = fakeBackend({
      'GET /api/tastings': () => (fail ? reply(500, { error: 'Something went wrong. Please try again.' }) : reply(200, tastingViews())),
    })
    renderAt('/')
    expect(screen.getByRole('status')).toHaveTextContent(/loading/i)

    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent(/could not load the tastings/i)

    fail = false
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }))
    expect(await screen.findByRole('article', { name: 'Riesling Evening' })).toBeInTheDocument()
    expect(backend.count('GET', '/api/tastings')).toBe(2)
  })

  it('links to the staff page from the footer', async () => {
    fakeBackend({ 'GET /api/tastings': reply(200, tastingViews()) })
    renderAt('/')
    expect(await screen.findByRole('link', { name: 'Staff' })).toHaveAttribute('href', '/staff')
  })
})

describe('unknown page', () => {
  it('shows a friendly not-found page with a way back', async () => {
    renderAt('/no/such/page')
    expect(await screen.findByRole('heading', { name: /page not found/i })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: /all tastings/i })).toHaveAttribute('href', '/')
  })
})
