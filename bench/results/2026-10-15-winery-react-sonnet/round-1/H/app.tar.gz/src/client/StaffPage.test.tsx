import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { fakeBackend, renderAt, reply, staffGroups } from '../test/clientHarness.js'


const anna = { reference: 'KB-AAAAAA', name: 'Anna Weber', email: 'anna@example.com', guests: 2 }
const ben = { reference: 'KB-BBBBBB', name: 'Ben Roth', email: 'ben@example.com', guests: 4 }

describe('staff sign-in', () => {
  it('asks for the password when there is no session', async () => {
    fakeBackend({ 'GET /api/staff/bookings': reply(401, { error: 'Please sign in.' }) })
    renderAt('/staff')
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password')
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument()
  })

  it('asks for a password before sending anything', async () => {
    const backend = fakeBackend({ 'GET /api/staff/bookings': reply(401, { error: 'Please sign in.' }) })
    renderAt('/staff')
    await userEvent.click(await screen.findByRole('button', { name: 'Sign in' }))
    expect(await screen.findByText('Enter the password.')).toBeInTheDocument()
    expect(screen.getByLabelText('Password')).toHaveAttribute('aria-invalid', 'true')
    expect(backend.count('POST', '/api/staff/session')).toBe(0)
  })

  it('shows a wrong password next to the field', async () => {
    fakeBackend({
      'GET /api/staff/bookings': reply(401, { error: 'Please sign in.' }),
      'POST /api/staff/session': reply(401, { errors: { password: 'Incorrect password.' } }),
    })
    renderAt('/staff')
    await userEvent.type(await screen.findByLabelText('Password'), 'wrong')
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }))
    const message = await screen.findByText('Incorrect password.')
    expect(message.closest('.field')).toContainElement(screen.getByLabelText('Password'))
    expect(screen.getByLabelText('Password')).toHaveFocus()
  })

  it('shows the lock-out message when sign-in is rate limited', async () => {
    fakeBackend({
      'GET /api/staff/bookings': reply(401, { error: 'Please sign in.' }),
      'POST /api/staff/session': reply(429, { errors: { password: 'Too many requests. Please wait a little and try again.' } }),
    })
    renderAt('/staff')
    await userEvent.type(await screen.findByLabelText('Password'), 'x')
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }))
    expect(await screen.findByText(/too many requests/i)).toBeInTheDocument()
  })

  it('signs in and shows the bookings', async () => {
    let signedIn = false
    fakeBackend({
      'GET /api/staff/bookings': () => (signedIn ? reply(200, staffGroups({ 'riesling-evening': [anna] })) : reply(401, { error: 'Please sign in.' })),
      'POST /api/staff/session': (call) => {
        expect(call.body).toEqual({ password: 'right' })
        signedIn = true
        return reply(204)
      },
    })
    renderAt('/staff')
    await userEvent.type(await screen.findByLabelText('Password'), 'right')
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }))
    expect(await screen.findByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument()
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument()
  })
})

describe('staff bookings', () => {
  const signedInBackend = (extra = {}, groups = staffGroups({ 'riesling-evening': [anna, ben] }, { 'riesling-evening': 6 })) =>
    fakeBackend({ 'GET /api/staff/bookings': () => reply(200, groups), ...extra })

  it('groups bookings by tasting with name, email, guests and reference', async () => {
    signedInBackend()
    renderAt('/staff')
    const riesling = await screen.findByRole('region', { name: /Riesling Evening/ })
    const rows = within(riesling).getAllByRole('row')
    expect(within(rows[1]!).getByText('Anna Weber')).toBeInTheDocument()
    expect(within(rows[1]!).getByText('anna@example.com')).toBeInTheDocument()
    expect(within(rows[1]!).getByText('2')).toBeInTheDocument()
    expect(within(rows[1]!).getByText('KB-AAAAAA')).toBeInTheDocument()
    expect(within(rows[2]!).getByText('Ben Roth')).toBeInTheDocument()
    expect(within(riesling).getByText('2026-11-06 18:00')).toBeInTheDocument()
    expect(within(riesling).getByText(/6 of 12 seats taken/)).toBeInTheDocument()
  })

  it('says when a tasting has no bookings yet', async () => {
    signedInBackend()
    renderAt('/staff')
    const tour = await screen.findByRole('region', { name: /Red Wine Cellar Tour/ })
    expect(within(tour).getByText('No bookings yet')).toBeInTheDocument()
    expect(within(tour).queryByRole('table')).not.toBeInTheDocument()
  })

  it('cancels a booking and shows the list without it', async () => {
    let groups = staffGroups({ 'riesling-evening': [anna, ben] }, { 'riesling-evening': 6 })
    const backend = fakeBackend({
      'GET /api/staff/bookings': () => reply(200, groups),
      'DELETE /api/staff/bookings/KB-AAAAAA': () => {
        groups = staffGroups({ 'riesling-evening': [ben] }, { 'riesling-evening': 8 })
        return reply(204)
      },
    })
    renderAt('/staff')
    const annaRow = (await screen.findByText('Anna Weber')).closest('tr')!
    await userEvent.click(within(annaRow).getByRole('button', { name: 'Cancel' }))

    expect(await screen.findByRole('status')).toHaveTextContent('KB-AAAAAA')
    expect(screen.queryByText('Anna Weber', { selector: 'td' })).not.toBeInTheDocument()
    expect(screen.getByText('Ben Roth')).toBeInTheDocument()
    expect(screen.getByText(/4 of 12 seats taken/)).toBeInTheDocument()
    expect(backend.count('DELETE', '/api/staff/bookings/KB-AAAAAA')).toBe(1)
  })

  it('gives each Cancel button the booking it belongs to as description', async () => {
    signedInBackend()
    renderAt('/staff')
    const buttons = await screen.findAllByRole('button', { name: 'Cancel' })
    expect(buttons).toHaveLength(2)
    expect(buttons[0]).toHaveAccessibleDescription(/Anna Weber.*KB-AAAAAA/)
    expect(buttons[1]).toHaveAccessibleDescription(/Ben Roth.*KB-BBBBBB/)
  })

  it('returns to sign-in when the session has expired during a cancel', async () => {
    let expired = false
    fakeBackend({
      'GET /api/staff/bookings': () => (expired ? reply(401, { error: 'Please sign in.' }) : reply(200, staffGroups({ 'riesling-evening': [anna] }))),
      'DELETE /api/staff/bookings/KB-AAAAAA': () => {
        expired = true
        return reply(401, { error: 'Please sign in.' })
      },
    })
    renderAt('/staff')
    await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }))
    expect(await screen.findByLabelText('Password')).toBeInTheDocument()
  })

  it('shows an error when cancelling fails', async () => {
    signedInBackend({ 'DELETE /api/staff/bookings/KB-AAAAAA': reply(500, { error: 'Something went wrong. Please try again.' }) })
    renderAt('/staff')
    const annaRow = (await screen.findByText('Anna Weber')).closest('tr')!
    await userEvent.click(within(annaRow).getByRole('button', { name: 'Cancel' }))
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not cancel/i)
    expect(screen.getByText('Anna Weber')).toBeInTheDocument()
  })

  it('signs out and shows the sign-in form again', async () => {
    let signedIn = true
    fakeBackend({
      'GET /api/staff/bookings': () => (signedIn ? reply(200, staffGroups()) : reply(401, { error: 'Please sign in.' })),
      'DELETE /api/staff/session': () => {
        signedIn = false
        return reply(204)
      },
    })
    renderAt('/staff')
    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }))
    expect(await screen.findByLabelText('Password')).toBeInTheDocument()
    expect(screen.queryByRole('region', { name: /Riesling Evening/ })).not.toBeInTheDocument()
  })

  it('shows a retryable error when the bookings cannot be loaded', async () => {
    fakeBackend({ 'GET /api/staff/bookings': reply(500, { error: 'Something went wrong. Please try again.' }) })
    renderAt('/staff')
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load the bookings/i)
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument()
  })
})

describe('staff page: review findings', () => {
  it('moves focus to the heading after signing in', async () => {
    let signedIn = false
    fakeBackend({
      'GET /api/staff/bookings': () => (signedIn ? reply(200, staffGroups()) : reply(401, { error: 'Please sign in.' })),
      'POST /api/staff/session': () => {
        signedIn = true
        return reply(204)
      },
    })
    renderAt('/staff')
    await userEvent.type(await screen.findByLabelText('Password'), 'right')
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }))
    expect(await screen.findByRole('heading', { name: 'Bookings' })).toHaveFocus()
  })

  it('moves focus to the confirmation message after a cancel, so it is announced and focus is not lost', async () => {
    let groups = staffGroups({ 'riesling-evening': [anna] })
    fakeBackend({
      'GET /api/staff/bookings': () => reply(200, groups),
      'DELETE /api/staff/bookings/KB-AAAAAA': () => {
        groups = staffGroups()
        return reply(204)
      },
    })
    renderAt('/staff')
    await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }))
    expect(await screen.findByRole('status')).toHaveFocus()
  })

  it('explains a cancel that finds the booking already gone, and refreshes the list', async () => {
    let groups = staffGroups({ 'riesling-evening': [anna] })
    const backend = fakeBackend({
      'GET /api/staff/bookings': () => reply(200, groups),
      'DELETE /api/staff/bookings/KB-AAAAAA': () => {
        groups = staffGroups()
        return reply(404, { error: 'Booking not found.' })
      },
    })
    renderAt('/staff')
    await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }))
    expect(await screen.findByRole('alert')).toHaveTextContent(/already cancelled/i)
    await waitFor(() => expect(backend.count('GET', '/api/staff/bookings')).toBe(2))
    await waitFor(() => expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument())
  })

  it('says so when signing out fails, and stays signed in', async () => {
    fakeBackend({
      'GET /api/staff/bookings': reply(200, staffGroups()),
      'DELETE /api/staff/session': reply(500, { error: 'Something went wrong. Please try again.' }),
    })
    renderAt('/staff')
    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }))
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not sign you out/i)
    expect(screen.getByRole('heading', { name: 'Bookings' })).toBeInTheDocument()
  })

  it('drops the cached bookings, with their guest emails, when signing out', async () => {
    let signedIn = true
    const { client } = (() => {
      fakeBackend({
        'GET /api/staff/bookings': () => (signedIn ? reply(200, staffGroups({ 'riesling-evening': [anna] })) : reply(401, { error: 'Please sign in.' })),
        'DELETE /api/staff/session': () => {
          signedIn = false
          return reply(204)
        },
      })
      return renderAt('/staff')
    })()
    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }))
    await screen.findByLabelText('Password')
    expect(client.getQueryData(['staff', 'bookings'])).toBeUndefined()
  })

  it('does not refetch the public tastings when a booking is cancelled (nothing on screen shows them)', async () => {
    const backend = fakeBackend({
      'GET /api/staff/bookings': reply(200, staffGroups({ 'riesling-evening': [anna] })),
      'DELETE /api/staff/bookings/KB-AAAAAA': reply(204),
    })
    renderAt('/staff')
    await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }))
    await screen.findByRole('status')
    expect(backend.count('GET', '/api/tastings')).toBe(0)
  })
})
