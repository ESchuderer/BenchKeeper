import { ApiError, api, isUnauthorized } from './api.js'
import { NETWORK_ERROR, fakeBackend, reply } from '../test/fakeBackend.js'

const failure = async (promise: Promise<unknown>) => {
  try {
    await promise
  } catch (error) {
    return error
  }
  throw new Error('expected the request to fail')
}

describe('api', () => {
  it('returns the parsed JSON body and sends JSON with credentials', async () => {
    const backend = fakeBackend({ 'POST /api/x': (call) => reply(201, { echoed: call.body }) })
    await expect(api('POST', '/api/x', { a: 1 })).resolves.toEqual({ echoed: { a: 1 } })
    expect(vi.mocked(fetch).mock.calls[0]?.[1]).toMatchObject({
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
    })
    expect(backend.calls).toHaveLength(1)
  })

  it('returns undefined for 204 and sends no body or content type on a plain GET', async () => {
    fakeBackend({ 'GET /api/x': reply(204) })
    await expect(api('GET', '/api/x')).resolves.toBeUndefined()
    expect(vi.mocked(fetch).mock.calls[0]?.[1]).toMatchObject({ body: undefined, headers: undefined })
  })

  it('turns an unreachable server into an ApiError with status 0', async () => {
    fakeBackend({ 'GET /api/x': NETWORK_ERROR })
    const error = await failure(api('GET', '/api/x'))
    expect(error).toBeInstanceOf(ApiError)
    expect(error).toMatchObject({ status: 0, message: expect.stringMatching(/could not reach the server/i) })
  })

  it('carries the server message and field errors of a failed request', async () => {
    fakeBackend({ 'POST /api/x': reply(400, { errors: { name: 'Enter your name.' } }), 'GET /api/y': reply(404, { error: 'Nope.' }) })
    expect(await failure(api('POST', '/api/x', {}))).toMatchObject({ status: 400, errors: { name: 'Enter your name.' } })
    expect(await failure(api('GET', '/api/y'))).toMatchObject({ status: 404, message: 'Nope.' })
  })

  it('uses a generic message when an error response is not JSON', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('<html>Bad gateway</html>', { status: 502 })))
    expect(await failure(api('GET', '/api/x'))).toMatchObject({ status: 502, message: 'Something went wrong. Please try again.' })
  })

  it('ignores error bodies of the wrong shape instead of passing them to the form', async () => {
    fakeBackend({ 'POST /api/x': reply(400, { error: 5, errors: 'x' }), 'POST /api/y': reply(400, { errors: { name: 7, bogus: 'x' } }) })
    expect(await failure(api('POST', '/api/x', {}))).toMatchObject({ message: 'Something went wrong. Please try again.', errors: undefined })
    expect(await failure(api('POST', '/api/y', {}))).toMatchObject({ errors: {} })
  })

  it('does not hand back undefined as data when a success body cannot be read', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('not json', { status: 201 })))
    expect(await failure(api('POST', '/api/x', {}))).toMatchObject({ status: 201, message: 'Something went wrong. Please try again.' })
  })
})

describe('isUnauthorized', () => {
  it('recognises only a 401 ApiError', () => {
    expect(isUnauthorized(new ApiError(401, 'x'))).toBe(true)
    expect(isUnauthorized(new ApiError(403, 'x'))).toBe(false)
    expect(isUnauthorized(new Error('x'))).toBe(false)
    expect(isUnauthorized(undefined)).toBe(false)
  })
})
