import { FIELD_NAMES, type FieldErrors } from '../shared/schema.js'

const NETWORK_MESSAGE = 'Could not reach the server. Check your connection and try again.'
const GENERIC_MESSAGE = 'Something went wrong. Please try again.'

export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
    readonly errors?: FieldErrors,
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

export const isUnauthorized = (error: unknown): boolean => error instanceof ApiError && error.status === 401

const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value)

/** Keep only the field messages we know how to show; anything else in an error body is ignored. */
function readFieldErrors(value: unknown): FieldErrors | undefined {
  if (!isRecord(value)) return undefined
  const errors: FieldErrors = {}
  for (const field of FIELD_NAMES) {
    const message = value[field]
    if (typeof message === 'string') errors[field] = message
  }
  return errors
}

async function readBody(response: Response): Promise<unknown> {
  if (response.status === 204) return undefined
  try {
    return await response.json()
  } catch {
    return undefined
  }
}

export async function api<T>(method: string, path: string, body?: unknown): Promise<T> {
  let response: Response
  try {
    response = await fetch(path, {
      method,
      credentials: 'same-origin',
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
  } catch {
    throw new ApiError(0, NETWORK_MESSAGE)
  }

  const data = await readBody(response)
  if (!response.ok) {
    const message = isRecord(data) && typeof data.error === 'string' ? data.error : GENERIC_MESSAGE
    throw new ApiError(response.status, message, isRecord(data) ? readFieldErrors(data.errors) : undefined)
  }
  if (data === undefined && response.status !== 204) throw new ApiError(response.status, GENERIC_MESSAGE)
  return data as T
}
