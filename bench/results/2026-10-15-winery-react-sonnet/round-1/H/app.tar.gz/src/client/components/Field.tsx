import type { ReactNode } from 'react'

export interface ControlProps {
  readonly id: string
  readonly 'aria-invalid': boolean
  readonly 'aria-describedby': string | undefined
}

interface FieldProps {
  readonly id: string
  readonly label: string
  readonly error?: string
  readonly hint?: string
  readonly children: (control: ControlProps) => ReactNode
}

/** Label, control, optional hint and the field's error message, kept together in one block. */
export function Field({ id, label, error, hint, children }: FieldProps) {
  const hintId = `${id}-hint`
  const errorId = `${id}-error`
  const describedBy = [error ? errorId : undefined, hint ? hintId : undefined].filter(Boolean).join(' ') || undefined

  return (
    <div className={error ? 'field has-error' : 'field'}>
      <label htmlFor={id}>{label}</label>
      {children({ id, 'aria-invalid': Boolean(error), 'aria-describedby': describedBy })}
      {error && (
        <p id={errorId} className="field-error" role="alert">
          <ErrorIcon />
          <span>{error}</span>
        </p>
      )}
      {hint && (
        <p id={hintId} className="field-hint">
          {hint}
        </p>
      )}
    </div>
  )
}

export function ErrorIcon() {
  return (
    <svg className="icon" viewBox="0 0 20 20" aria-hidden="true" focusable="false">
      <circle cx="10" cy="10" r="9" fill="currentColor" />
      <path d="M10 5.500v5.500M10 13.500v1" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}
