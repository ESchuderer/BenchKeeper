import { useEffect, useRef } from 'react'
import { Link, Outlet, useLocation } from 'react-router'

export function Layout() {
  const { pathname } = useLocation()
  const main = useRef<HTMLElement>(null)
  const shownPath = useRef(pathname)

  // A client-side navigation replaces the page without a reload: move focus to the new content.
  useEffect(() => {
    if (shownPath.current === pathname) return
    shownPath.current = pathname
    main.current?.focus()
  }, [pathname])

  return (
    <div className="site">
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="site-header">
        <div className="container site-header-inner">
          <Link to="/" className="wordmark">
            <GrapeMark />
            <span>
              <span className="wordmark-name">Weingut Kieselbrunnen</span>
              <span className="wordmark-tag">Family winery</span>
            </span>
          </Link>
        </div>
      </header>
      <main id="main" ref={main} tabIndex={-1} className="container main">
        <Outlet />
      </main>
      <footer className="site-footer">
        <div className="container site-footer-inner">
          <p>Weingut Kieselbrunnen · a family winery</p>
          <Link to="/staff">Staff</Link>
        </div>
      </footer>
    </div>
  )
}

function GrapeMark() {
  return (
    <svg className="wordmark-mark" viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <path d="M16 3c1 3 3 4.500 6 5-1 2.500-3.500 4-6 3.500" fill="none" stroke="currentColor" strokeWidth="1.600" strokeLinecap="round" />
      <circle cx="11" cy="16" r="3.500" />
      <circle cx="18" cy="16" r="3.500" />
      <circle cx="14.500" cy="22" r="3.500" />
      <circle cx="21.500" cy="22" r="3" opacity="0.6" />
      <circle cx="8" cy="22.500" r="3" opacity="0.6" />
      <circle cx="14.500" cy="28" r="2.500" opacity="0.8" />
    </svg>
  )
}
