import { ErrorIcon } from './Field.js'

export function Loading({ what }: { readonly what: string }) {
  return (
    <p role="status" className="loading">
      <span className="spinner" aria-hidden="true" />
      Loading {what}…
    </p>
  )
}

interface LoadErrorProps {
  readonly message: string
  readonly onRetry: () => void
}

export function LoadError({ message, onRetry }: LoadErrorProps) {
  return (
    <div role="alert" className="notice notice-error">
      <ErrorIcon />
      <div>
        <p>{message}</p>
        <button type="button" className="button button-secondary" onClick={onRetry}>
          Try again
        </button>
      </div>
    </div>
  )
}
