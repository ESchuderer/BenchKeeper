import { Link } from 'react-router'
import { formatDateTime, formatPrice, formatWeekday, seatsLeftLabel } from '../../shared/format.js'
import type { TastingView } from '../../shared/tastings.js'

const FEW_SEATS = 3

export function TastingCard({ tasting }: { readonly tasting: TastingView }) {
  const headingId = `tasting-${tasting.id}`
  const full = tasting.seatsLeft === 0
  const few = !full && tasting.seatsLeft <= FEW_SEATS

  return (
    <article className={full ? 'card tasting is-full' : 'card tasting'} aria-labelledby={headingId}>
      <div className="tasting-when">
        <span className="tasting-weekday">{formatWeekday(tasting.startsAt)}</span>
        <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time>
      </div>
      <h2 id={headingId}>{tasting.title}</h2>
      <div className="tasting-facts">
        <p className="tasting-price">{formatPrice(tasting.pricePerGuest)} per guest</p>
        <p className={few ? 'tasting-seats is-few' : 'tasting-seats'}>{seatsLeftLabel(tasting.seatsLeft)}</p>
      </div>
      {full ? (
        <p className="badge badge-full">Fully booked</p>
      ) : (
        <Link className="button" to={`/book/${tasting.id}`}>
          Book {tasting.title}
        </Link>
      )}
    </article>
  )
}
