import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { formatDateTime, formatPrice, formatWeekday, seatsLeftLabel } from '../../shared/format.js'
import { MAX_GUESTS_PER_BOOKING, type BookingCreated, type TastingView } from '../../shared/tastings.js'
import { bookingInputFor, type BookingInput, type FieldName } from '../../shared/schema.js'
import { ApiError } from '../api.js'
import { ErrorIcon, Field } from '../components/Field.js'
import { useCreateBooking } from '../queries.js'
import { useState } from 'react'

type Props = {
  tasting: TastingView
  onBooked: (created: BookingCreated) => void
}

type FormValues = { name: string; email: string; guests: number }

const DEFAULT_GUESTS = 2
const FORM_FIELDS: readonly FieldName[] = ['name', 'email', 'guests']

export function BookingForm({ tasting, onBooked }: Props) {
  const createBooking = useCreateBooking(tasting.id)
  const [formError, setFormError] = useState<string>()
  const maxGuests = Math.min(MAX_GUESTS_PER_BOOKING, tasting.seatsLeft)

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues, unknown, BookingInput>({
    resolver: zodResolver(bookingInputFor(tasting.seatsLeft)),
    defaultValues: { name: '', email: '', guests: Math.min(DEFAULT_GUESTS, maxGuests) },
  })

  const submit = handleSubmit(async (values) => {
    setFormError(undefined)
    try {
      onBooked(await createBooking.mutateAsync(values))
    } catch (error) {
      if (!(error instanceof ApiError)) throw error
      const fieldMessages = FORM_FIELDS.flatMap((field) => {
        const message = error.errors?.[field]
        return message ? [[field, message] as const] : []
      })
      fieldMessages.forEach(([field, message], index) => {
        setError(field as keyof FormValues, { type: 'server', message }, { shouldFocus: index === 0 })
      })
      if (fieldMessages.length === 0) setFormError(error.message)
    }
  })

  return (
    <form className="card form" onSubmit={submit} noValidate>
      <dl className="summary">
        <div>
          <dt>When</dt>
          <dd>
            <span className="tasting-weekday">{formatWeekday(tasting.startsAt)}</span>{' '}
            <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time>
          </dd>
        </div>
        <div>
          <dt>Price</dt>
          <dd>{formatPrice(tasting.pricePerGuest)} per guest</dd>
        </div>
        <div>
          <dt>Availability</dt>
          <dd>{seatsLeftLabel(tasting.seatsLeft)}</dd>
        </div>
      </dl>

      <p className="form-note">All fields are required.</p>

      <Field id="name" label="Name" error={errors.name?.message}>
        {(control) => <input {...control} type="text" autoComplete="name" required {...register('name')} />}
      </Field>

      <Field id="email" label="Email" error={errors.email?.message}>
        {(control) => <input {...control} type="email" autoComplete="email" inputMode="email" required {...register('email')} />}
      </Field>

      <Field id="guests" label="Guests" error={errors.guests?.message} hint={maxGuests === 1 ? '1 guest' : `1 to ${maxGuests} guests`}>
        {(control) => (
          <input
            {...control}
            type="number"
            inputMode="numeric"
            min={1}
            max={maxGuests}
            step={1}
            required
            {...register('guests', { valueAsNumber: true })}
          />
        )}
      </Field>

      {formError && (
        <p role="alert" className="notice notice-error">
          <ErrorIcon />
          <span>{formError}</span>
        </p>
      )}

      <button type="submit" className="button button-block" disabled={isSubmitting}>
        {isSubmitting ? 'Booking…' : 'Book'}
      </button>
    </form>
  )
}
