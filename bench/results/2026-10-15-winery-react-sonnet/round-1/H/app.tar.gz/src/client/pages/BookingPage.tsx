import { useState } from 'react'
import { Link } from 'react-router'
import { formatDateTime } from '../../shared/format.js'
import type { BookingCreated } from '../../shared/tastings.js'
import { Loading, LoadError } from '../components/StatusMessage.js'
import { useTastings } from '../queries.js'
import { useDocumentTitle } from '../useDocumentTitle.js'
import { BookingForm } from './BookingForm.js'
import { Confirmation } from './Confirmation.js'
import { NotFoundPage } from './NotFoundPage.js'

type Props = { id: string }

export function BookingPage({ id }: Props) {
  const tastings = useTastings()
  const [created, setCreated] = useState<BookingCreated>()
  const tasting = tastings.data?.find((candidate) => candidate.id === id)
  useDocumentTitle(created ? 'Booking confirmed' : tasting ? `Book ${tasting.title}` : undefined)

  if (created) return <Confirmation created={created} />
  if (!tastings.data) {
    return tastings.isError ? (
      <LoadError message="We could not load this tasting." onRetry={() => void tastings.refetch()} />
    ) : (
      <Loading what="tasting" />
    )
  }
  if (!tasting) return <NotFoundPage what="Tasting" />

  return (
    <section className="narrow">
      <Link className="back-link" to="/">
        ← All tastings
      </Link>
      <p className="eyebrow">Book your seats</p>
      <h1>{tasting.title}</h1>
      {tasting.seatsLeft === 0 ? (
        <div className="card centered">
          <p className="badge badge-full">Fully booked</p>
          <p>
            {tasting.title} on <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time> is fully booked. Every seat has been taken.
          </p>
          <Link className="button button-secondary" to="/">
            See other tastings
          </Link>
        </div>
      ) : (
        <BookingForm tasting={tasting} onBooked={setCreated} />
      )}
    </section>
  )
}
