import { useEffect, useRef } from 'react'
import { Link } from 'react-router'
import { formatDateTime, formatPrice, formatWeekday } from '../../shared/format.js'
import type { BookingCreated } from '../../shared/tastings.js'

type Props = { created: BookingCreated }

export function Confirmation({ created: { booking, tasting } }: Props) {
  const heading = useRef<HTMLHeadingElement>(null)
  useEffect(() => heading.current?.focus(), [])

  return (
    <section className="card narrow confirmation" aria-labelledby="confirmation-heading">
      <svg className="confirmation-mark" viewBox="0 0 48 48" aria-hidden="true" focusable="false">
        <circle cx="24" cy="24" r="22" fill="currentColor" />
        <path d="M14 25l7 7 13-15" fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <p className="eyebrow">Thank you, {booking.name}</p>
      <h1 id="confirmation-heading" ref={heading} tabIndex={-1}>
        Booking confirmed
      </h1>
      <p className="lead">We look forward to seeing you at the winery. Please keep your booking reference.</p>
      <dl className="receipt">
        <div>
          <dt>Tasting</dt>
          <dd>{tasting.title}</dd>
        </div>
        <div>
          <dt>Date and time</dt>
          <dd>
            {formatWeekday(tasting.startsAt)}, <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time>
          </dd>
        </div>
        <div>
          <dt>Guests</dt>
          <dd>{booking.guests}</dd>
        </div>
        <div>
          <dt>Total price</dt>
          <dd>{formatPrice(booking.total)}</dd>
        </div>
        <div className="receipt-reference">
          <dt>Booking reference</dt>
          <dd>{booking.reference}</dd>
        </div>
      </dl>
      <Link className="button button-secondary" to="/">
        See all tastings
      </Link>
    </section>
  )
}
