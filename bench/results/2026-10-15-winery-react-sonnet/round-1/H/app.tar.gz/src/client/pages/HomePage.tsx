import { Loading, LoadError } from '../components/StatusMessage.js'
import { TastingCard } from '../components/TastingCard.js'
import { useDocumentTitle } from '../useDocumentTitle.js'
import { useTastings } from '../queries.js'

export function HomePage() {
  useDocumentTitle()
  const tastings = useTastings()

  return (
    <>
      <section className="hero">
        <p className="eyebrow">Weingut Kieselbrunnen</p>
        <h1>Wine tastings at our family winery</h1>
        <p className="lead">Choose a tasting, pick the number of guests and reserve your seats online.</p>
      </section>
      {tastings.data ? (
        <div className="tasting-grid">
          {tastings.data.map((tasting) => (
            <TastingCard key={tasting.id} tasting={tasting} />
          ))}
        </div>
      ) : tastings.isError ? (
        <LoadError message="We could not load the tastings." onRetry={() => void tastings.refetch()} />
      ) : (
        <Loading what="tastings" />
      )}
    </>
  )
}
