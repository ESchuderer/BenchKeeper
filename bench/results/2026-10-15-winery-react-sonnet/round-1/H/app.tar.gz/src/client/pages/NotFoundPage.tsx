import { Link } from 'react-router'
import { useDocumentTitle } from '../useDocumentTitle.js'

export function NotFoundPage({ what = 'Page' }: { readonly what?: string }) {
  useDocumentTitle(`${what} not found`)
  return (
    <section className="card narrow centered">
      <h1>{what} not found</h1>
      <p>We could not find what you were looking for.</p>
      <Link className="button" to="/">
        See all tastings
      </Link>
    </section>
  )
}
