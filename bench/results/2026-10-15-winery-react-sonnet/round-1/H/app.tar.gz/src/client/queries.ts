import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import type { BookingInput } from '../shared/schema.js'
import type { BookingCreated, StaffTastingGroup, TastingView } from '../shared/tastings.js'
import { api } from './api.js'

const TASTINGS_KEY = ['tastings'] as const
const STAFF_KEY = ['staff'] as const
const STAFF_BOOKINGS_KEY = [...STAFF_KEY, 'bookings'] as const

export function useTastings() {
  return useQuery({ queryKey: TASTINGS_KEY, queryFn: () => api<TastingView[]>('GET', '/api/tastings') })
}

export function useCreateBooking(tastingId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: BookingInput) => api<BookingCreated>('POST', `/api/tastings/${tastingId}/bookings`, input),
    // Success or "no longer fits": the seat counts are out of date. Refresh in the background:
    // the guest must see the outcome of their booking without waiting for (or depending on) the refresh.
    onSettled: () => void queryClient.invalidateQueries({ queryKey: TASTINGS_KEY }),
  })
}

export function useStaffBookings() {
  return useQuery({
    queryKey: STAFF_BOOKINGS_KEY,
    queryFn: () => api<StaffTastingGroup[]>('GET', '/api/staff/bookings'),
    retry: false,
  })
}

export function useSignIn() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (password: string) => api<void>('POST', '/api/staff/session', { password }),
    // Awaited on purpose: the form stays in its "Signing in…" state until the list has arrived.
    onSuccess: () => queryClient.invalidateQueries({ queryKey: STAFF_KEY }),
  })
}

export function useSignOut() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: () => api<void>('DELETE', '/api/staff/session'),
    // Reset, not invalidate: the cached bookings (with guest emails) must not outlive the session.
    onSuccess: () => queryClient.resetQueries({ queryKey: STAFF_KEY }),
  })
}

export function useCancelBooking() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (reference: string) => api<void>('DELETE', `/api/staff/bookings/${encodeURIComponent(reference)}`),
    // The public tastings are not on screen here and refetch when the start page mounts.
    onSettled: () => void queryClient.invalidateQueries({ queryKey: STAFF_KEY }),
  })
}
