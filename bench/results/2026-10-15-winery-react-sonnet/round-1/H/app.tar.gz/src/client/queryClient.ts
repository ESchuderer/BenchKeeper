import { QueryClient, type DefaultOptions } from '@tanstack/react-query'

type QueryDefaults = NonNullable<DefaultOptions['queries']>

/** One place for the cache settings; tests pass overrides (no retries, no focus refetch). */
export function createQueryClient(overrides: QueryDefaults = {}): QueryClient {
  return new QueryClient({ defaultOptions: { queries: { retry: 1, ...overrides } } })
}
