import { useEffect, useRef, useState } from 'react'
import { formatDateTime } from '../../shared/format.js'
import type { StaffTastingGroup } from '../../shared/tastings.js'
import { ApiError } from '../api.js'
import { ErrorIcon } from '../components/Field.js'
import { useCancelBooking, useSignOut } from '../queries.js'
import { useFocusOnMount } from '../useFocusOnMount.js'

type Props = { groups: readonly StaffTastingGroup[] }

function Alert({ children }: { children: string }) {
  return (
    <p role="alert" className="notice notice-error">
      <ErrorIcon />
      <span>{children}</span>
    </p>
  )
}

export function StaffBookings({ groups }: Props) {
  const signOut = useSignOut()
  const cancel = useCancelBooking()
  const heading = useFocusOnMount<HTMLHeadingElement>()
  const status = useRef<HTMLParagraphElement>(null)
  const [cancelled, setCancelled] = useState<string>()

  // The cancelled row (and its button) is gone: move focus to the message so it is read out and focus is not lost.
  useEffect(() => {
    if (cancelled) status.current?.focus()
  }, [cancelled])

  const cancelBooking = (reference: string, name: string) => {
    setCancelled(undefined)
    cancel.mutate(reference, { onSuccess: () => setCancelled(`Cancelled booking ${reference} for ${name}. Its seats are free again.`) })
  }

  const alreadyGone = cancel.error instanceof ApiError && cancel.error.status === 404

  return (
    <section>
      <div className="staff-bar">
        <div>
          <p className="eyebrow">Staff area</p>
          <h1 ref={heading} tabIndex={-1}>
            Bookings
          </h1>
        </div>
        <button type="button" className="button button-secondary" onClick={() => signOut.mutate()} disabled={signOut.isPending}>
          Sign out
        </button>
      </div>

      {signOut.isError && <Alert>We could not sign you out. Please try again.</Alert>}
      {cancelled && (
        <p role="status" tabIndex={-1} ref={status} className="notice notice-success">
          {cancelled}
        </p>
      )}
      {cancel.isError && <Alert>{alreadyGone ? 'That booking was already cancelled.' : 'We could not cancel the booking. Please try again.'}</Alert>}

      <div className="staff-groups">
        {groups.map(({ tasting, bookings }) => (
          <section key={tasting.id} className="card staff-group" aria-labelledby={`staff-${tasting.id}`}>
            <header className="staff-group-head">
              <h2 id={`staff-${tasting.id}`}>{tasting.title}</h2>
              <p>
                <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time> · {tasting.seats - tasting.seatsLeft} of {tasting.seats} seats
                taken
              </p>
            </header>
            {bookings.length === 0 ? (
              <p className="empty">No bookings yet</p>
            ) : (
              // Explicit roles: the narrow-screen layout turns rows into stacked cards with `display: block`,
              // which makes some browsers drop the native table semantics.
              <table className="bookings" role="table">
                <caption className="sr-only">Bookings for {tasting.title}</caption>
                <thead role="rowgroup">
                  <tr role="row">
                    <th scope="col" role="columnheader">
                      Name
                    </th>
                    <th scope="col" role="columnheader">
                      Email
                    </th>
                    <th scope="col" role="columnheader">
                      Guests
                    </th>
                    <th scope="col" role="columnheader">
                      Reference
                    </th>
                    <th scope="col" role="columnheader">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody role="rowgroup">
                  {bookings.map((booking) => (
                    <tr key={booking.reference} role="row">
                      <td role="cell" data-label="Name" id={`name-${booking.reference}`}>
                        {booking.name}
                      </td>
                      <td role="cell" data-label="Email">
                        {booking.email}
                      </td>
                      <td role="cell" data-label="Guests">
                        {booking.guests}
                      </td>
                      <td role="cell" data-label="Reference" id={`ref-${booking.reference}`} className="reference">
                        {booking.reference}
                      </td>
                      <td role="cell" className="actions">
                        <button
                          type="button"
                          className="button button-danger"
                          aria-describedby={`name-${booking.reference} ref-${booking.reference}`}
                          disabled={cancel.isPending}
                          onClick={() => cancelBooking(booking.reference, booking.name)}
                        >
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        ))}
      </div>
    </section>
  )
}
