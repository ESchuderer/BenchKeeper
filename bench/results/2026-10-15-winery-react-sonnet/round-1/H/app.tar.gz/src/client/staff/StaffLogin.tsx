import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { loginInput } from '../../shared/schema.js'
import { ApiError } from '../api.js'
import { ErrorIcon, Field } from '../components/Field.js'
import { useSignIn } from '../queries.js'
import { useFocusOnMount } from '../useFocusOnMount.js'
import { useState } from 'react'

type FormValues = { password: string }

export function StaffLogin() {
  const signIn = useSignIn()
  const heading = useFocusOnMount<HTMLHeadingElement>()
  const [formError, setFormError] = useState<string>()
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(loginInput), defaultValues: { password: '' } })

  const submit = handleSubmit(async ({ password }) => {
    setFormError(undefined)
    try {
      await signIn.mutateAsync(password)
    } catch (error) {
      if (!(error instanceof ApiError)) throw error
      if (error.errors?.password) setError('password', { type: 'server', message: error.errors.password }, { shouldFocus: true })
      else setFormError(error.message)
    }
  })

  return (
    <section className="narrow">
      <p className="eyebrow">Staff area</p>
      <h1 ref={heading} tabIndex={-1}>
        Staff sign-in
      </h1>
      <form className="card form" onSubmit={submit} noValidate>
        <Field id="password" label="Password" error={errors.password?.message}>
          {(control) => <input {...control} type="password" autoComplete="current-password" required {...register('password')} />}
        </Field>
        {formError && (
          <p role="alert" className="notice notice-error">
            <ErrorIcon />
            <span>{formError}</span>
          </p>
        )}
        <button type="submit" className="button button-block" disabled={isSubmitting}>
          {isSubmitting ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </section>
  )
}
