import { isUnauthorized } from '../api.js'
import { Loading, LoadError } from '../components/StatusMessage.js'
import { useStaffBookings } from '../queries.js'
import { useDocumentTitle } from '../useDocumentTitle.js'
import { StaffBookings } from './StaffBookings.js'
import { StaffLogin } from './StaffLogin.js'

export function StaffPage() {
  useDocumentTitle('Staff')
  const bookings = useStaffBookings()

  if (isUnauthorized(bookings.error)) return <StaffLogin />
  if (bookings.data) return <StaffBookings groups={bookings.data} />
  if (bookings.isError) return <LoadError message="We could not load the bookings." onRetry={() => void bookings.refetch()} />
  return <Loading what="bookings" />
}
