import { useEffect, useRef } from 'react'

/** Ref for an element that should take focus when it appears (a view swap would otherwise drop focus to <body>). */
export function useFocusOnMount<T extends HTMLElement>() {
  const ref = useRef<T>(null)
  useEffect(() => ref.current?.focus(), [])
  return ref
}
