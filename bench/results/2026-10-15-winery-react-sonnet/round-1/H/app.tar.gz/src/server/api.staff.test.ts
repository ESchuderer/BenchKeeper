import request from 'supertest'
import { STAFF_PASSWORD, guestBody, makeApp } from '../test/helpers.js'

type App = ReturnType<typeof makeApp>['app']

async function signedIn(app: App) {
  const agent = request.agent(app)
  await agent.post('/api/staff/session').send({ password: STAFF_PASSWORD }).expect(204)
  return agent
}

const book = (app: App, id: string, guests = 2, extra: object = {}) =>
  request(app).post(`/api/tastings/${id}/bookings`).send({ ...guestBody, guests, ...extra })

describe('staff sign-in', () => {
  it('sets an HttpOnly, SameSite=Strict session cookie for the right password', async () => {
    const { app } = makeApp()
    const res = await request(app).post('/api/staff/session').send({ password: STAFF_PASSWORD })
    expect(res.status).toBe(204)
    const cookie = String(res.headers['set-cookie'])
    expect(cookie).toMatch(/HttpOnly/i)
    expect(cookie).toMatch(/SameSite=Strict/i)
    expect(cookie).toMatch(/Path=\//)
    expect(cookie).toMatch(/Max-Age=\d+/)
    expect(cookie).not.toContain(STAFF_PASSWORD)
  })

  it('rejects a wrong password with a message for the password field', async () => {
    const { app } = makeApp()
    const res = await request(app).post('/api/staff/session').send({ password: 'wrong' })
    expect(res.status).toBe(401)
    expect(res.body).toEqual({ errors: { password: 'Incorrect password.' } })
    expect(res.headers['set-cookie']).toBeUndefined()
  })

  it('rejects an empty or missing password with 400', async () => {
    const { app } = makeApp()
    for (const body of [{ password: '' }, {}, { password: 42 }]) {
      const res = await request(app).post('/api/staff/session').send(body)
      expect(res.status).toBe(400)
      expect(res.body.errors).toHaveProperty('password')
    }
  })

  it('refuses all sign-ins when STAFF_PASSWORD is not configured', async () => {
    for (const staffPassword of [undefined, '']) {
      const { app } = makeApp({ staffPassword })
      const res = await request(app).post('/api/staff/session').send({ password: 'x' })
      expect(res.status).toBe(401)
      expect(res.body.errors.password).toBe('Staff sign-in is not configured.')
    }
  })

  it('locks out an IP after too many wrong passwords', async () => {
    const { app } = makeApp({ limits: { login: { max: 3, windowMs: 60_000 }, booking: { max: 100, windowMs: 60_000 } } })
    for (let i = 0; i < 3; i++) {
      expect((await request(app).post('/api/staff/session').send({ password: 'wrong' })).status).toBe(401)
    }
    const limited = await request(app).post('/api/staff/session').send({ password: 'wrong' })
    expect(limited.status).toBe(429)
    expect(limited.body.errors.password).toMatch(/too many/i)
  })

  it('does not count successful sign-ins against the limit', async () => {
    const { app } = makeApp({ limits: { login: { max: 2, windowMs: 60_000 }, booking: { max: 100, windowMs: 60_000 } } })
    for (let i = 0; i < 5; i++) {
      await request(app).post('/api/staff/session').send({ password: STAFF_PASSWORD }).expect(204)
    }
  })
})

describe('staff security', () => {
  it('marks the cookie Secure when a trusted proxy says the request was HTTPS', async () => {
    const { app } = makeApp({ trustProxy: 1 })
    const res = await request(app).post('/api/staff/session').set('X-Forwarded-Proto', 'https').send({ password: STAFF_PASSWORD })
    expect(String(res.headers['set-cookie'])).toMatch(/; Secure/i)
    const plain = await request(app).post('/api/staff/session').send({ password: STAFF_PASSWORD })
    expect(String(plain.headers['set-cookie'])).not.toMatch(/; Secure/i)
  })

  it('treats a cookie that cookie-parser decodes into an object as no session', async () => {
    const { app } = makeApp()
    const res = await request(app).get('/api/staff/bookings').set('Cookie', 'kb_staff=j:{"a":1}')
    expect(res.status).toBe(401)
  })

  it('logs sign-ins, failed sign-ins and cancellations without ever logging the password', async () => {
    const log = vi.fn()
    const { app } = makeApp({ log })
    await request(app).post('/api/staff/session').send({ password: 'guess-1' })
    await book(app, 'riesling-evening')
    const agent = await signedIn(app)
    await agent.delete('/api/staff/bookings/KB-TEST1')
    const lines = log.mock.calls.map(([line]) => String(line))
    expect(lines.some((l) => /failed staff sign-in/i.test(l))).toBe(true)
    expect(lines.some((l) => /staff signed in/i.test(l))).toBe(true)
    expect(lines.some((l) => /cancelled booking KB-TEST1/i.test(l))).toBe(true)
    expect(lines.join('\n')).not.toContain('guess-1')
    expect(lines.join('\n')).not.toContain(STAFF_PASSWORD)
  })
})

describe('staff session', () => {
  it('reports whether the cookie is a valid session', async () => {
    const { app } = makeApp()
    expect((await request(app).get('/api/staff/session')).status).toBe(401)
    const agent = await signedIn(app)
    expect((await agent.get('/api/staff/session')).status).toBe(204)
  })

  it('ends the session on sign out', async () => {
    const { app } = makeApp()
    const agent = await signedIn(app)
    const res = await agent.delete('/api/staff/session')
    expect(res.status).toBe(204)
    expect(String(res.headers['set-cookie'])).toMatch(/kb_staff=;/)
    expect((await agent.get('/api/staff/bookings')).status).toBe(401)
  })

  it('rejects a forged cookie', async () => {
    const { app } = makeApp()
    const res = await request(app).get('/api/staff/bookings').set('Cookie', 'kb_staff=forged')
    expect(res.status).toBe(401)
  })
})

describe('staff bookings', () => {
  it.each([
    ['get', '/api/staff/bookings'],
    ['delete', '/api/staff/bookings/KB-TEST1'],
  ] as const)('requires a session for %s %s', async (method, path) => {
    const { app } = makeApp()
    await book(app, 'riesling-evening')
    const res = await request(app)[method](path)
    expect(res.status).toBe(401)
    expect(res.body).toEqual({ error: 'Please sign in.' })
  })

  it('lists bookings grouped by tasting with name, email, guests and reference', async () => {
    const { app } = makeApp()
    await book(app, 'winter-tasting', 3, { name: 'Cleo' })
    await book(app, 'riesling-evening', 2)
    const agent = await signedIn(app)
    const res = await agent.get('/api/staff/bookings')
    expect(res.status).toBe(200)
    expect(res.headers['cache-control']).toMatch(/no-store/)
    expect(res.body.map((g: { tasting: { id: string } }) => g.tasting.id)).toEqual([
      'riesling-evening',
      'red-wine-cellar-tour',
      'winter-tasting',
    ])
    expect(res.body[0].bookings).toEqual([{ reference: 'KB-TEST2', name: 'Anna Weber', email: 'anna@example.com', guests: 2 }])
    expect(res.body[0].tasting.seatsLeft).toBe(10)
    expect(res.body[1].bookings).toEqual([])
    expect(res.body[2].bookings[0]).toMatchObject({ name: 'Cleo', guests: 3, reference: 'KB-TEST1' })
  })

  it('cancels a booking, frees its seats and forgets it', async () => {
    const { app } = makeApp()
    await book(app, 'red-wine-cellar-tour', 8)
    expect((await book(app, 'red-wine-cellar-tour', 1)).status).toBe(409)
    const agent = await signedIn(app)

    expect((await agent.delete('/api/staff/bookings/KB-TEST1')).status).toBe(204)
    expect((await request(app).get('/api/tastings/red-wine-cellar-tour')).body.seatsLeft).toBe(8)
    expect((await agent.get('/api/staff/bookings')).body[1].bookings).toEqual([])
    expect((await book(app, 'red-wine-cellar-tour', 8)).status).toBe(201)
  })

  it('answers 404 when the booking does not exist or was already cancelled', async () => {
    const { app } = makeApp()
    await book(app, 'riesling-evening')
    const agent = await signedIn(app)
    await agent.delete('/api/staff/bookings/KB-TEST1').expect(204)
    expect((await agent.delete('/api/staff/bookings/KB-TEST1')).status).toBe(404)
    expect((await agent.delete('/api/staff/bookings/whatever')).status).toBe(404)
  })

  it('rejects state-changing requests from another origin', async () => {
    const { app } = makeApp()
    await book(app, 'riesling-evening')
    const agent = await signedIn(app)
    const res = await agent.delete('/api/staff/bookings/KB-TEST1').set('Origin', 'https://evil.example')
    expect(res.status).toBe(403)
    expect((await agent.get('/api/staff/bookings')).body[0].bookings).toHaveLength(1)
  })

  it('accepts requests whose Origin matches the host', async () => {
    const { app } = makeApp()
    await book(app, 'riesling-evening')
    const agent = await signedIn(app)
    const res = await agent.delete('/api/staff/bookings/KB-TEST1').set('Host', 'winery.test').set('Origin', 'http://winery.test')
    expect(res.status).toBe(204)
  })
})
