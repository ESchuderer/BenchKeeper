import request from 'supertest'
import { guestBody, makeApp } from '../test/helpers.js'
import type { Store } from './store.js'

describe('GET /api/tastings', () => {
  it('lists the tastings with seats left and no personal data', async () => {
    const { app } = makeApp()
    const res = await request(app).get('/api/tastings')
    expect(res.status).toBe(200)
    expect(res.body).toHaveLength(3)
    expect(res.body[0]).toEqual({
      id: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      pricePerGuest: 25,
      seats: 12,
      seatsLeft: 12,
    })
    expect(JSON.stringify(res.body)).not.toMatch(/email|@/)
  })

  it('returns one tasting or a JSON 404', async () => {
    const { app } = makeApp()
    expect((await request(app).get('/api/tastings/winter-tasting')).body.title).toBe('Winter Tasting')
    const missing = await request(app).get('/api/tastings/nope')
    expect(missing.status).toBe(404)
    expect(missing.body).toEqual({ error: 'Tasting not found.' })
  })
})

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and returns the confirmation without the email', async () => {
    const { app } = makeApp()
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send(guestBody)
    expect(res.status).toBe(201)
    expect(res.body.booking).toEqual({
      reference: 'KB-TEST1',
      tastingId: 'riesling-evening',
      name: 'Anna Weber',
      guests: 2,
      total: 50,
    })
    expect(res.body.tasting).toMatchObject({ id: 'riesling-evening', seatsLeft: 10 })
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com')
    expect((await request(app).get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(10)
  })

  it('rejects invalid fields with a message per field', async () => {
    const { app } = makeApp()
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: ' ', email: 'not-an-email', guests: 9 })
    expect(res.status).toBe(400)
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name'])
  })

  it.each([['a string', '2'], ['a fraction', 1.5], ['zero', 0], ['missing', undefined]])('rejects guests given as %s', async (_l, guests) => {
    const { app } = makeApp()
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guestBody, guests })
    expect(res.status).toBe(400)
    expect(res.body.errors).toHaveProperty('guests')
  })

  it('answers 409 on the guests field when fewer seats are left', async () => {
    const { app } = makeApp()
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guestBody, guests: 6 })
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guestBody, guests: 3 })
    expect(res.status).toBe(409)
    expect(res.body).toEqual({ errors: { guests: 'Only 2 seats left for this tasting.' } })
    expect((await request(app).get('/api/tastings/red-wine-cellar-tour')).body.seatsLeft).toBe(2)
  })

  it('answers 409 fully booked when nothing is left', async () => {
    const { app } = makeApp()
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guestBody, guests: 8 })
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guestBody, guests: 1 })
    expect(res.status).toBe(409)
    expect(res.body.errors.guests).toBe('This tasting is fully booked.')
  })

  it('never oversells under concurrent requests', async () => {
    const { app } = makeApp()
    const results = await Promise.all(
      Array.from({ length: 12 }, () => request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guestBody, guests: 2 })),
    )
    expect(results.filter((r) => r.status === 201)).toHaveLength(4)
    expect(results.filter((r) => r.status === 409)).toHaveLength(8)
    expect((await request(app).get('/api/tastings/red-wine-cellar-tour')).body.seatsLeft).toBe(0)
  })

  it('returns 404 for an unknown tasting', async () => {
    const { app } = makeApp()
    const res = await request(app).post('/api/tastings/nope/bookings').send(guestBody)
    expect(res.status).toBe(404)
  })

  it('requires a JSON body', async () => {
    const { app } = makeApp()
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').type('text/plain').send('name=Anna')
    expect(res.status).toBe(415)
  })

  it('answers 400 for malformed JSON and 413 for oversized bodies', async () => {
    const { app } = makeApp()
    const bad = await request(app).post('/api/tastings/riesling-evening/bookings').type('json').send('{"name":')
    expect(bad.status).toBe(400)
    expect(bad.body).toEqual({ error: 'The request body is not valid JSON.' })
    const big = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ ...guestBody, name: 'x'.repeat(20_000) })
    expect(big.status).toBe(413)
  })

  it('rate limits bookings per client', async () => {
    const { app } = makeApp({ limits: { login: { max: 100, windowMs: 60_000 }, booking: { max: 2, windowMs: 60_000 } } })
    const post = () => request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guestBody, guests: 1 })
    expect((await post()).status).toBe(201)
    expect((await post()).status).toBe(201)
    const limited = await post()
    expect(limited.status).toBe(429)
    expect(limited.body.error).toMatch(/too many/i)
  })
})

describe('API hardening', () => {
  it('never lets shared caches keep API responses', async () => {
    const { app } = makeApp()
    expect((await request(app).get('/api/tastings')).headers['cache-control']).toMatch(/no-store/)
    const booked = await request(app).post('/api/tastings/riesling-evening/bookings').send(guestBody)
    expect(booked.headers['cache-control']).toMatch(/no-store/)
  })

  it('answers a body that is not an object with a plain message, not an empty error map', async () => {
    const { app } = makeApp()
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send([])
    expect(res.status).toBe(400)
    expect(res.body).toEqual({ error: 'The request body must be a JSON object.' })
  })

  it('does not force HTTPS: the app is served over plain HTTP unless a proxy adds TLS', async () => {
    const { app } = makeApp()
    const res = await request(app).get('/')
    expect(res.headers['strict-transport-security']).toBeUndefined()
    expect(res.headers['content-security-policy']).not.toContain('upgrade-insecure-requests')
  })

  it('rate limits per client address when a trusted proxy forwards it', async () => {
    const { app } = makeApp({ trustProxy: 1, limits: { login: { max: 100, windowMs: 60_000 }, booking: { max: 1, windowMs: 60_000 } } })
    const post = (ip: string) =>
      request(app).post('/api/tastings/riesling-evening/bookings').set('X-Forwarded-For', ip).send({ ...guestBody, guests: 1 })
    expect((await post('203.0.113.1')).status).toBe(201)
    expect((await post('203.0.113.1')).status).toBe(429)
    expect((await post('203.0.113.2')).status).toBe(201)
  })
})

describe('app shell', () => {
  it('answers unknown /api paths with a JSON 404', async () => {
    const { app } = makeApp()
    const res = await request(app).get('/api/nope')
    expect(res.status).toBe(404)
    expect(res.body).toEqual({ error: 'Not found.' })
  })

  it.each(['/', '/book/riesling-evening', '/staff'])('serves the SPA on %s', async (path) => {
    const { app } = makeApp()
    const res = await request(app).get(path)
    expect(res.status).toBe(200)
    expect(res.headers['content-type']).toMatch(/html/)
    expect(res.text).toContain('id="root"')
  })

  it('serves built assets and 404s on missing ones instead of the SPA', async () => {
    const { app } = makeApp()
    expect((await request(app).get('/assets/app.js')).status).toBe(200)
    expect((await request(app).get('/assets/missing.js')).status).toBe(404)
  })

  it('does not fall back to the SPA for non-GET requests', async () => {
    const { app } = makeApp()
    expect((await request(app).post('/staff')).status).toBe(404)
  })

  it('sets security headers and hides the framework', async () => {
    const { app } = makeApp()
    const res = await request(app).get('/')
    expect(res.headers['x-content-type-options']).toBe('nosniff')
    expect(res.headers['content-security-policy']).toContain("default-src 'self'")
    expect(res.headers['x-powered-by']).toBeUndefined()
  })

  it('hides internals when something throws', async () => {
    const broken = { listTastings: () => { throw new Error('secret db path /srv/x') } } as unknown as Store
    const { app } = makeApp({ store: broken })
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {})
    const res = await request(app).get('/api/tastings')
    spy.mockRestore()
    expect(res.status).toBe(500)
    expect(res.body).toEqual({ error: 'Something went wrong. Please try again.' })
  })
})
