import express, { type Express } from 'express'
import helmet from 'helmet'
import path from 'node:path'
import { createSessions, type Sessions } from './auth.js'
import { apiNotFound, errorHandler, noStore, requireJson } from './errors.js'
import { DEFAULT_LIMITS, type Limits } from './rateLimit.js'
import { staffRoutes } from './routes/staff.js'
import { tastingRoutes } from './routes/tastings.js'
import type { Store } from './store.js'

export interface AppConfig {
  readonly store: Store
  /** Shared staff password; when empty or missing, staff sign-in is refused. */
  readonly staffPassword: string | undefined
  /** Folder with the built React app (index.html + assets/). */
  readonly clientDir: string
  readonly limits?: Limits
  readonly sessions?: Sessions
  /** Number of reverse proxies in front of the app (X-Forwarded-* are trusted for that many hops). Default: none. */
  readonly trustProxy?: number
  /** Where security events are written. Default: stdout. */
  readonly log?: (message: string) => void
}

const JSON_BODY_LIMIT = '10kb'
const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000

export function createApp(config: AppConfig): Express {
  const limits = config.limits ?? DEFAULT_LIMITS
  const app = express()
  app.disable('x-powered-by')
  if (config.trustProxy) app.set('trust proxy', config.trustProxy)
  app.use(
    helmet({
      // The app speaks plain HTTP itself; TLS (and HSTS) belong to whatever terminates it.
      strictTransportSecurity: false,
      contentSecurityPolicy: { directives: { upgradeInsecureRequests: null } },
    }),
  )

  app.use('/api', noStore, requireJson, express.json({ limit: JSON_BODY_LIMIT }))
  app.use('/api/tastings', tastingRoutes(config.store, limits.booking))
  app.use('/api/staff', staffRoutes({
      store: config.store,
      sessions: config.sessions ?? createSessions(),
      staffPassword: config.staffPassword,
      loginLimit: limits.login,
      log: config.log ?? console.info,
    }))
  app.use('/api', apiNotFound)

  app.use('/assets', express.static(path.join(config.clientDir, 'assets'), { maxAge: ONE_YEAR_MS, immutable: true }))
  app.use(express.static(config.clientDir, { index: false }))
  app.get('/{*splat}', (req, res, next) => {
    // A path with a file extension (or under /assets) is a missing file, not a client-side route.
    if (path.extname(req.path) || req.path.startsWith('/assets/')) {
      next()
      return
    }
    res.sendFile('index.html', { root: config.clientDir })
  })

  app.use((_req, res) => {
    res.status(404).type('text/plain').send('Not found.')
  })
  app.use(errorHandler)
  return app
}
