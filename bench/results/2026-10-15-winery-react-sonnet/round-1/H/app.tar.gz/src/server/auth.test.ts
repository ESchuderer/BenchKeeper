import { checkPassword, createSessions } from './auth.js'

describe('checkPassword', () => {
  it('accepts only the exact password', () => {
    expect(checkPassword('s3cret', 's3cret')).toBe(true)
    expect(checkPassword('s3cret ', 's3cret')).toBe(false)
    expect(checkPassword('S3CRET', 's3cret')).toBe(false)
    expect(checkPassword('', 's3cret')).toBe(false)
  })

  it('refuses everything when no password is configured', () => {
    expect(checkPassword('', undefined)).toBe(false)
    expect(checkPassword('', '')).toBe(false)
    expect(checkPassword('anything', undefined)).toBe(false)
  })

  it('handles passwords of different lengths and unicode', () => {
    expect(checkPassword('a', 'a-much-longer-password')).toBe(false)
    expect(checkPassword('Grüße-🍷', 'Grüße-🍷')).toBe(true)
  })
})

describe('sessions', () => {
  it('creates unguessable, unique ids that validate until destroyed', () => {
    const sessions = createSessions()
    const a = sessions.create()
    const b = sessions.create()
    expect(a).not.toBe(b)
    expect(a).toMatch(/^[A-Za-z0-9_-]{43}$/)
    expect(sessions.isValid(a)).toBe(true)
    sessions.destroy(a)
    expect(sessions.isValid(a)).toBe(false)
    expect(sessions.isValid(b)).toBe(true)
  })

  it('rejects unknown and missing ids', () => {
    const sessions = createSessions()
    expect(sessions.isValid('nope')).toBe(false)
    expect(sessions.isValid(undefined)).toBe(false)
  })

  it('expires sessions after the lifetime', () => {
    let now = 1_000
    const sessions = createSessions({ ttlMs: 500, now: () => now })
    const id = sessions.create()
    now += 499
    expect(sessions.isValid(id)).toBe(true)
    now += 2
    expect(sessions.isValid(id)).toBe(false)
  })

  it('drops the oldest session when the cap is reached', () => {
    const sessions = createSessions({ maxSessions: 2 })
    const first = sessions.create()
    const second = sessions.create()
    const third = sessions.create()
    expect(sessions.isValid(first)).toBe(false)
    expect(sessions.isValid(second)).toBe(true)
    expect(sessions.isValid(third)).toBe(true)
  })
})
