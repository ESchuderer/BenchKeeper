import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'
import type { Request, RequestHandler } from 'express'

export const SESSION_COOKIE = 'kb_staff'
const EIGHT_HOURS_MS = 8 * 60 * 60 * 1000
const MAX_SESSIONS = 1000
const SESSION_ID_BYTES = 32

const sha256 = (value: string) => createHash('sha256').update(value).digest()

/** Constant-time comparison; never succeeds when no password is configured. */
export function checkPassword(candidate: string, expected: string | undefined): boolean {
  if (!expected) return false
  return timingSafeEqual(sha256(candidate), sha256(expected))
}

export interface SessionOptions {
  readonly ttlMs?: number
  readonly maxSessions?: number
  readonly now?: () => number
}

export interface Sessions {
  readonly ttlMs: number
  create(): string
  isValid(id: string | undefined): boolean
  destroy(id: string | undefined): void
}

/** In-memory staff sessions: random ids, fixed lifetime, bounded count. */
export function createSessions({ ttlMs = EIGHT_HOURS_MS, maxSessions = MAX_SESSIONS, now = Date.now }: SessionOptions = {}): Sessions {
  const expiries = new Map<string, number>()

  return {
    ttlMs,

    create() {
      const id = randomBytes(SESSION_ID_BYTES).toString('base64url')
      expiries.set(id, now() + ttlMs)
      while (expiries.size > maxSessions) {
        const oldest = expiries.keys().next().value
        if (oldest === undefined) break
        expiries.delete(oldest)
      }
      return id
    },

    isValid(id) {
      if (!id) return false
      const expiresAt = expiries.get(id)
      if (expiresAt === undefined) return false
      if (expiresAt <= now()) {
        expiries.delete(id)
        return false
      }
      return true
    },

    destroy(id) {
      if (id) expiries.delete(id)
    },
  }
}

/** cookie-parser may decode a `j:` cookie into an object; only a plain string can be a session id. */
export function sessionIdFrom(req: Request): string | undefined {
  const value: unknown = req.cookies?.[SESSION_COOKIE]
  return typeof value === 'string' ? value : undefined
}

export function requireStaff(sessions: Sessions): RequestHandler {
  return (req, res, next) => {
    if (!sessions.isValid(sessionIdFrom(req))) {
      res.status(401).json({ error: 'Please sign in.' })
      return
    }
    next()
  }
}

/** Browsers send Origin on cross-site writes; refuse any that is not this host. */
export const sameOriginWrites: RequestHandler = (req, res, next) => {
  const origin = req.get('origin')
  if (req.method !== 'GET' && origin !== undefined) {
    let originHost: string | undefined
    try {
      originHost = new URL(origin).host
    } catch {
      originHost = undefined
    }
    if (originHost !== req.get('host')) {
      res.status(403).json({ error: 'Cross-site requests are not allowed.' })
      return
    }
  }
  next()
}
