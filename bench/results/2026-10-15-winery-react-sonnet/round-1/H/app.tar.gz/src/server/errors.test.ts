import type { NextFunction, Request, Response } from 'express'
import { errorHandler } from './errors.js'

function fakeResponse(headersSent = false) {
  const res = { headersSent, status: vi.fn(), json: vi.fn() }
  res.status.mockReturnValue(res)
  return res
}

const call = (err: unknown, res: ReturnType<typeof fakeResponse>, next: NextFunction = vi.fn()) =>
  errorHandler(err, {} as Request, res as unknown as Response, next)

describe('errorHandler', () => {
  beforeEach(() => {
    vi.spyOn(console, 'error').mockImplementation(() => {})
  })
  afterEach(() => vi.restoreAllMocks())

  it('hands the error to Express when the response has already started', () => {
    const res = fakeResponse(true)
    const next = vi.fn()
    const err = new Error('stream broke')
    call(err, res, next)
    expect(next).toHaveBeenCalledWith(err)
    expect(res.status).not.toHaveBeenCalled()
  })

  it.each([['a string', 'boom'], ['null', null], ['undefined', undefined], ['a number', 42]])('answers 500 when %s was thrown', (_label, thrown) => {
    const res = fakeResponse()
    call(thrown, res)
    expect(res.status).toHaveBeenCalledWith(500)
    expect(res.json).toHaveBeenCalledWith({ error: 'Something went wrong. Please try again.' })
  })

  it('maps client errors raised by middleware to their own 4xx status', () => {
    const res = fakeResponse()
    call({ status: 400 }, res)
    expect(res.status).toHaveBeenCalledWith(400)
  })
})
