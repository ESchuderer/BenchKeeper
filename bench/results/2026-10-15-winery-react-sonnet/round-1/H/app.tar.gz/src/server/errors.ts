import type { ErrorRequestHandler, RequestHandler, Response } from 'express'
import type { ZodError } from 'zod'
import { fieldErrors } from '../shared/schema.js'

export const apiNotFound: RequestHandler = (_req, res) => {
  res.status(404).json({ error: 'Not found.' })
}

/** API answers can hold personal data (names, emails): no shared cache may keep them. */
export const noStore: RequestHandler = (_req, res, next) => {
  res.set('Cache-Control', 'no-store')
  next()
}

/** Only JSON bodies are accepted on API POSTs (also a CSRF guard: forms cannot send it cross-site). */
export const requireJson: RequestHandler = (req, res, next) => {
  if (req.method === 'POST' && !req.is('application/json')) {
    res.status(415).json({ error: 'Send the request as application/json.' })
    return
  }
  next()
}

/** 400 with a message per field; a body that is not even an object has no field to blame. */
export function sendValidationError(res: Response, error: ZodError): void {
  const errors = fieldErrors(error)
  if (Object.keys(errors).length === 0) {
    res.status(400).json({ error: 'The request body must be a JSON object.' })
    return
  }
  res.status(400).json({ errors })
}

interface HttpishError {
  readonly type?: string
  readonly status?: number
}

const asHttpish = (err: unknown): HttpishError => (typeof err === 'object' && err !== null ? (err as HttpishError) : {})

export const errorHandler: ErrorRequestHandler = (err: unknown, _req, res, next) => {
  if (res.headersSent) {
    next(err)
    return
  }
  const { type, status } = asHttpish(err)
  if (type === 'entity.parse.failed') {
    res.status(400).json({ error: 'The request body is not valid JSON.' })
    return
  }
  if (type === 'entity.too.large') {
    res.status(413).json({ error: 'The request is too large.' })
    return
  }
  if (typeof status === 'number' && status >= 400 && status < 500) {
    res.status(status).json({ error: 'The request could not be processed.' })
    return
  }
  console.error('Unhandled error:', err)
  res.status(500).json({ error: 'Something went wrong. Please try again.' })
}
