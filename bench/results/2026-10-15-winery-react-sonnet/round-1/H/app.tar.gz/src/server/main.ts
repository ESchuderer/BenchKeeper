import { fileURLToPath } from 'node:url'
import { createApp } from './app.js'
import { createStore } from './store.js'

const DEFAULT_PORT = 3000
const MIN_RECOMMENDED_PASSWORD_LENGTH = 12

const port = Number(process.env.PORT) || DEFAULT_PORT
const staffPassword = process.env.STAFF_PASSWORD
const trustProxy = Number(process.env.TRUST_PROXY) || 0
// dist/server/server/main.js -> dist/client, wherever the process is started from.
const clientDir = process.env.CLIENT_DIR ?? fileURLToPath(new URL('../../client', import.meta.url))

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.')
} else if (staffPassword.length < MIN_RECOMMENDED_PASSWORD_LENGTH) {
  console.warn(`STAFF_PASSWORD is shorter than ${MIN_RECOMMENDED_PASSWORD_LENGTH} characters: choose a longer one.`)
}

const server = createApp({ store: createStore(), staffPassword, clientDir, trustProxy }).listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings listening on http://localhost:${port}`)
})

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.once(signal, () => server.close(() => process.exit(0)))
}
