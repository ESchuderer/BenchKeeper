import { rateLimit } from 'express-rate-limit'

export interface LimitConfig {
  readonly max: number
  readonly windowMs: number
}

export interface Limits {
  readonly login: LimitConfig
  readonly booking: LimitConfig
}

export const DEFAULT_LIMITS: Limits = {
  login: { max: 10, windowMs: 15 * 60_000 },
  booking: { max: 120, windowMs: 10 * 60_000 },
}

interface LimiterOptions {
  /** Only rejected requests (status >= 400) use up the allowance. */
  readonly countFailuresOnly?: boolean
}

/** `shapeBody` wraps the message so the 429 body has the same shape as the route's other errors. */
export function limiter({ max, windowMs }: LimitConfig, shapeBody: (message: { error: string }) => object, options: LimiterOptions = {}) {
  return rateLimit({
    windowMs,
    limit: max,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    skipSuccessfulRequests: options.countFailuresOnly ?? false,
    handler: (_req, res) => {
      res.status(429).json(shapeBody({ error: 'Too many requests. Please wait a little and try again.' }))
    },
  })
}
