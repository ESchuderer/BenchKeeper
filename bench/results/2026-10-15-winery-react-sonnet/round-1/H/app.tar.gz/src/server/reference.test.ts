import { REFERENCE_ALPHABET, generateReference, uniqueReference } from './reference.js'

describe('booking reference', () => {
  it('looks like KB-XXXXXX using an unambiguous alphabet', () => {
    for (let i = 0; i < 200; i++) {
      expect(generateReference()).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/)
    }
    expect(REFERENCE_ALPHABET).not.toMatch(/[01OIL]/)
  })

  it('is built from the picker, one character per position', () => {
    expect(generateReference(() => 0)).toBe(`KB-${REFERENCE_ALPHABET[0]!.repeat(6)}`)
  })

  it('retries until it finds a reference that is not taken', () => {
    let calls = 0
    const pick = () => (calls++ < 12 ? 0 : 1) // first two references collide
    const taken = new Set([`KB-${REFERENCE_ALPHABET[0]!.repeat(6)}`])
    const reference = uniqueReference((ref) => taken.has(ref), pick)
    expect(reference).toBe(`KB-${REFERENCE_ALPHABET[1]!.repeat(6)}`)
  })

  it('gives up instead of looping forever', () => {
    expect(() => uniqueReference(() => true)).toThrow(/unique/i)
  })
})
