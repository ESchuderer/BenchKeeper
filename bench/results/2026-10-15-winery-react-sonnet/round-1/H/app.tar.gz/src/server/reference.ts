import { randomInt } from 'node:crypto'

/** No 0/O/1/I/L: references get read out over the phone. */
export const REFERENCE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'
const REFERENCE_LENGTH = 6
const MAX_ATTEMPTS = 25

type Pick = (max: number) => number

export function generateReference(pick: Pick = randomInt): string {
  let code = ''
  for (let i = 0; i < REFERENCE_LENGTH; i++) code += REFERENCE_ALPHABET[pick(REFERENCE_ALPHABET.length)]
  return `KB-${code}`
}

export function uniqueReference(isTaken: (reference: string) => boolean, pick: Pick = randomInt): string {
  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    const reference = generateReference(pick)
    if (!isTaken(reference)) return reference
  }
  throw new Error('Could not generate a unique booking reference')
}
