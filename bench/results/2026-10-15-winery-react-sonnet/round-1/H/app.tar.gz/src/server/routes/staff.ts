import cookieParser from 'cookie-parser'
import { Router } from 'express'
import { loginInput } from '../../shared/schema.js'
import { SESSION_COOKIE, checkPassword, requireStaff, sameOriginWrites, sessionIdFrom, type Sessions } from '../auth.js'
import { sendValidationError } from '../errors.js'
import { limiter, type LimitConfig } from '../rateLimit.js'
import type { Store } from '../store.js'

export interface StaffDeps {
  readonly store: Store
  readonly sessions: Sessions
  readonly staffPassword: string | undefined
  readonly loginLimit: LimitConfig
  /** Security events go here; never pass passwords. */
  readonly log: (message: string) => void
}

export function staffRoutes({ store, sessions, staffPassword, loginLimit, log }: StaffDeps): Router {
  const router = Router()
  const guard = requireStaff(sessions)
  const cookieOptions = (secure: boolean) => ({ httpOnly: true, sameSite: 'strict', secure, path: '/' }) as const

  router.use((_req, res, next) => {
    res.set('Cache-Control', 'no-store')
    next()
  })
  router.use(cookieParser(), sameOriginWrites)

  router.post(
    '/session',
    limiter(loginLimit, ({ error }) => ({ errors: { password: error } }), { countFailuresOnly: true }),
    (req, res) => {
      const parsed = loginInput.safeParse(req.body)
      if (!parsed.success) {
        sendValidationError(res, parsed.error)
        return
      }
      if (!staffPassword) {
        res.status(401).json({ errors: { password: 'Staff sign-in is not configured.' } })
        return
      }
      if (!checkPassword(parsed.data.password, staffPassword)) {
        log(`Failed staff sign-in from ${req.ip}`)
        res.status(401).json({ errors: { password: 'Incorrect password.' } })
        return
      }
      log(`Staff signed in from ${req.ip}`)
      res.cookie(SESSION_COOKIE, sessions.create(), { ...cookieOptions(req.secure), maxAge: sessions.ttlMs })
      res.status(204).end()
    },
  )

  router.get('/session', guard, (_req, res) => {
    res.status(204).end()
  })

  router.delete('/session', (req, res) => {
    sessions.destroy(sessionIdFrom(req))
    res.clearCookie(SESSION_COOKIE, cookieOptions(req.secure))
    res.status(204).end()
  })

  router.get('/bookings', guard, (_req, res) => {
    res.json(store.groupedBookings())
  })

  router.delete<{ reference: string }>('/bookings/:reference', guard, (req, res) => {
    if (!store.cancel(req.params.reference)) {
      res.status(404).json({ error: 'Booking not found.' })
      return
    }
    log(`Cancelled booking ${req.params.reference}`)
    res.status(204).end()
  })

  return router
}
