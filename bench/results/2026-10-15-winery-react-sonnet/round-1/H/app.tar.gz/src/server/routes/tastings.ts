import { Router } from 'express'
import { bookingInput, capacityMessage } from '../../shared/schema.js'
import type { BookingCreated } from '../../shared/tastings.js'
import { sendValidationError } from '../errors.js'
import { limiter, type LimitConfig } from '../rateLimit.js'
import type { Store } from '../store.js'

const NOT_FOUND = { error: 'Tasting not found.' }

export function tastingRoutes(store: Store, bookingLimit: LimitConfig): Router {
  const router = Router()

  router.get('/', (_req, res) => {
    res.json(store.listTastings())
  })

  router.get<{ id: string }>('/:id', (req, res) => {
    const tasting = store.getTasting(req.params.id)
    if (!tasting) {
      res.status(404).json(NOT_FOUND)
      return
    }
    res.json(tasting)
  })

  router.post<{ id: string }>('/:id/bookings', limiter(bookingLimit, (message) => message), (req, res) => {
    const parsed = bookingInput.safeParse(req.body)
    if (!parsed.success) {
      sendValidationError(res, parsed.error)
      return
    }

    const result = store.book(req.params.id, parsed.data)
    if (!result.ok) {
      if (result.reason === 'not-found') {
        res.status(404).json(NOT_FOUND)
      } else {
        res.status(409).json({ errors: { guests: capacityMessage(result.seatsLeft) } })
      }
      return
    }

    const created: BookingCreated = { booking: result.booking, tasting: result.tasting }
    res.status(201).json(created)
  })

  return router
}
