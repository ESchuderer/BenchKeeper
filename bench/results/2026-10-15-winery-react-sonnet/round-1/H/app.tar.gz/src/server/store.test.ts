import { createStore } from './store.js'

const guest = { name: 'Anna Weber', email: 'anna@example.com' }

function newStore() {
  let n = 0
  return createStore(undefined, () => `KB-TEST${++n}`)
}

describe('store', () => {
  it('starts with all seats free and no bookings', () => {
    const store = newStore()
    expect(store.listTastings().map((t) => [t.id, t.seatsLeft])).toEqual([
      ['riesling-evening', 12],
      ['red-wine-cellar-tour', 8],
      ['winter-tasting', 10],
    ])
    expect(store.groupedBookings().every((g) => g.bookings.length === 0)).toBe(true)
  })

  it('looks up a tasting or returns undefined', () => {
    const store = newStore()
    expect(store.getTasting('winter-tasting')?.title).toBe('Winter Tasting')
    expect(store.getTasting('nope')).toBeUndefined()
  })

  it('books seats, computes the total and reduces seats left', () => {
    const store = newStore()
    const result = store.book('riesling-evening', { ...guest, guests: 3 })
    expect(result).toEqual({
      ok: true,
      booking: { reference: 'KB-TEST1', tastingId: 'riesling-evening', name: 'Anna Weber', guests: 3, total: 75 },
      tasting: expect.objectContaining({ id: 'riesling-evening', seatsLeft: 9 }),
    })
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(9)
  })

  it('lets a booking fill the tasting exactly', () => {
    const store = newStore()
    expect(store.book('red-wine-cellar-tour', { ...guest, guests: 8 }).ok).toBe(true)
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(0)
  })

  it('refuses a booking that needs more seats than are left and changes nothing', () => {
    const store = newStore()
    store.book('red-wine-cellar-tour', { ...guest, guests: 6 })
    const result = store.book('red-wine-cellar-tour', { ...guest, guests: 3 })
    expect(result).toEqual({ ok: false, reason: 'insufficient-seats', seatsLeft: 2 })
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(2)
  })

  it('refuses any booking once sold out', () => {
    const store = newStore()
    store.book('red-wine-cellar-tour', { ...guest, guests: 8 })
    expect(store.book('red-wine-cellar-tour', { ...guest, guests: 1 })).toEqual({
      ok: false,
      reason: 'insufficient-seats',
      seatsLeft: 0,
    })
  })

  it('reports an unknown tasting', () => {
    expect(newStore().book('nope', { ...guest, guests: 1 })).toEqual({ ok: false, reason: 'not-found' })
  })

  it('never oversells across many bookings', () => {
    const store = newStore()
    let booked = 0
    for (let i = 0; i < 30; i++) {
      const result = store.book('winter-tasting', { ...guest, guests: 1 + (i % 4) })
      if (result.ok) booked += result.booking.guests
    }
    expect(booked).toBeLessThanOrEqual(10)
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(10 - booked)
  })

  it('groups bookings by tasting in start order, oldest booking first', () => {
    const store = newStore()
    store.book('winter-tasting', { ...guest, guests: 2 })
    store.book('riesling-evening', { name: 'Ben', email: 'ben@example.com', guests: 1 })
    store.book('riesling-evening', { name: 'Cleo', email: 'cleo@example.com', guests: 4 })
    const groups = store.groupedBookings()
    expect(groups.map((g) => g.tasting.id)).toEqual(['riesling-evening', 'red-wine-cellar-tour', 'winter-tasting'])
    expect(groups[0]?.bookings).toEqual([
      { reference: 'KB-TEST2', name: 'Ben', email: 'ben@example.com', guests: 1 },
      { reference: 'KB-TEST3', name: 'Cleo', email: 'cleo@example.com', guests: 4 },
    ])
    expect(groups[0]?.tasting.seatsLeft).toBe(7)
  })

  it('frees the seats when a booking is cancelled and forgets the booking', () => {
    const store = newStore()
    store.book('riesling-evening', { ...guest, guests: 5 })
    expect(store.cancel('KB-TEST1')).toBe(true)
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(12)
    expect(store.groupedBookings()[0]?.bookings).toEqual([])
    expect(store.cancel('KB-TEST1')).toBe(false)
  })

  it('lets freed seats be booked again', () => {
    const store = newStore()
    store.book('red-wine-cellar-tour', { ...guest, guests: 8 })
    store.cancel('KB-TEST1')
    expect(store.book('red-wine-cellar-tour', { ...guest, guests: 8 }).ok).toBe(true)
  })

  it.each([0, -1, 1.5, Number.NaN])('refuses to book %s guests: that is a caller bug, not a seat shortage', (guests) => {
    const store = newStore()
    expect(() => store.book('winter-tasting', { ...guest, guests })).toThrow(RangeError)
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(10)
  })

  it('keeps separate instances isolated', () => {
    const a = newStore()
    const b = newStore()
    a.book('winter-tasting', { ...guest, guests: 4 })
    expect(b.getTasting('winter-tasting')?.seatsLeft).toBe(10)
  })
})
