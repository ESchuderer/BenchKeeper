import { TASTINGS, type BookingConfirmation, type StaffBooking, type StaffTastingGroup, type Tasting, type TastingView } from '../shared/tastings.js'
import { uniqueReference } from './reference.js'

export interface BookingRequest {
  readonly name: string
  readonly email: string
  readonly guests: number
}

interface StoredBooking extends BookingRequest {
  readonly reference: string
  readonly tastingId: string
}

export type BookResult =
  | { readonly ok: true; readonly booking: BookingConfirmation; readonly tasting: TastingView }
  | { readonly ok: false; readonly reason: 'not-found' }
  | { readonly ok: false; readonly reason: 'insufficient-seats'; readonly seatsLeft: number }

export interface Store {
  listTastings(): TastingView[]
  getTasting(id: string): TastingView | undefined
  book(tastingId: string, request: BookingRequest): BookResult
  groupedBookings(): StaffTastingGroup[]
  cancel(reference: string): boolean
}

/**
 * In-memory bookings. Every operation is synchronous, so the seat check and the
 * insert can never interleave with another request in the single Node process.
 */
export function createStore(
  tastings: readonly Tasting[] = TASTINGS,
  makeReference: (isTaken: (reference: string) => boolean) => string = uniqueReference,
): Store {
  let bookings: readonly StoredBooking[] = []

  const seatsTaken = (tastingId: string) =>
    bookings.filter((b) => b.tastingId === tastingId).reduce((sum, b) => sum + b.guests, 0)

  const view = (tasting: Tasting): TastingView => ({ ...tasting, seatsLeft: tasting.seats - seatsTaken(tasting.id) })

  const find = (id: string) => tastings.find((t) => t.id === id)

  return {
    listTastings: () => tastings.map(view),

    getTasting(id) {
      const tasting = find(id)
      return tasting && view(tasting)
    },

    book(tastingId, request) {
      if (!Number.isInteger(request.guests) || request.guests < 1) {
        throw new RangeError('guests must be a whole number of at least 1')
      }
      const tasting = find(tastingId)
      if (!tasting) return { ok: false, reason: 'not-found' }
      const seatsLeft = view(tasting).seatsLeft
      if (request.guests > seatsLeft) return { ok: false, reason: 'insufficient-seats', seatsLeft }

      const reference = makeReference((candidate) => bookings.some((b) => b.reference === candidate))
      bookings = [...bookings, { reference, tastingId, name: request.name, email: request.email, guests: request.guests }]
      return {
        ok: true,
        booking: { reference, tastingId, name: request.name, guests: request.guests, total: request.guests * tasting.pricePerGuest },
        tasting: view(tasting),
      }
    },

    groupedBookings() {
      return [...tastings]
        .sort((a, b) => a.startsAt.localeCompare(b.startsAt))
        .map((tasting) => ({
          tasting: view(tasting),
          bookings: bookings
            .filter((b) => b.tastingId === tasting.id)
            .map((b): StaffBooking => ({ reference: b.reference, name: b.name, email: b.email, guests: b.guests })),
        }))
    },

    cancel(reference) {
      if (!bookings.some((b) => b.reference === reference)) return false
      bookings = bookings.filter((b) => b.reference !== reference)
      return true
    },
  }
}
