import { formatDateTime, formatPrice, formatWeekday, seatsLeftLabel } from './format.js'

describe('format', () => {
  it('formats the start as YYYY-MM-DD HH:mm without timezone shifts', () => {
    expect(formatDateTime('2026-11-06T18:00')).toBe('2026-11-06 18:00')
    expect(formatDateTime('2026-12-05T07:05')).toBe('2026-12-05 07:05')
  })

  it('names the weekday of the date', () => {
    expect(formatWeekday('2026-11-06T18:00')).toBe('Friday')
    expect(formatWeekday('2026-11-14T15:00')).toBe('Saturday')
  })

  it('formats prices as EUR with whole numbers', () => {
    expect(formatPrice(25)).toBe('EUR 25')
    expect(formatPrice(75)).toBe('EUR 75')
  })

  it('formats prices with cents only when needed', () => {
    expect(formatPrice(12.5)).toBe('EUR 12.50')
  })

  it('labels seats left literally', () => {
    expect(seatsLeftLabel(12)).toBe('12 seats left')
    expect(seatsLeftLabel(1)).toBe('1 seats left')
    expect(seatsLeftLabel(0)).toBe('0 seats left')
  })
})
