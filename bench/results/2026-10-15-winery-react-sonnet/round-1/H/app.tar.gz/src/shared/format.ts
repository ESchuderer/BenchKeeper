const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] as const

/** `2026-11-06T18:00` -> `2026-11-06 18:00`. Plain string work: no timezone conversion. */
export function formatDateTime(startsAt: string): string {
  return startsAt.replace('T', ' ')
}

export function formatWeekday(startsAt: string): string {
  const [year = 0, month = 1, day = 1] = startsAt.slice(0, 10).split('-').map(Number)
  return WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()] ?? ''
}

export function formatPrice(euro: number): string {
  return `EUR ${Number.isInteger(euro) ? euro : euro.toFixed(2)}`
}

export function seatsLeftLabel(seatsLeft: number): string {
  return `${seatsLeft} seats left`
}
