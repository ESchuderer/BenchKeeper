import { bookingInput, bookingInputFor, capacityMessage, fieldErrors, loginInput } from './schema.js'

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 }

function errorsOf(input: unknown, schema = bookingInput) {
  const result = schema.safeParse(input)
  return result.success ? {} : fieldErrors(result.error)
}

describe('bookingInput', () => {
  it('accepts valid input and trims text', () => {
    const result = bookingInput.parse({ ...valid, name: '  Anna Weber ', email: ' anna@example.com ' })
    expect(result).toEqual(valid)
  })

  it.each([
    ['empty', ''],
    ['blank', '   '],
    ['too long', 'x'.repeat(101)],
  ])('rejects a %s name', (_label, name) => {
    expect(errorsOf({ ...valid, name })).toHaveProperty('name')
  })

  it.each([['empty', ''], ['no at sign', 'anna.example.com'], ['no domain', 'anna@'], ['too long', `${'a'.repeat(250)}@x.io`]])(
    'rejects a %s email',
    (_label, email) => {
      expect(errorsOf({ ...valid, email })).toHaveProperty('email')
    },
  )

  it.each([
    ['zero', 0],
    ['nine', 9],
    ['negative', -1],
    ['fractional', 2.5],
    ['a string', '3'],
    ['NaN', Number.NaN],
    ['missing', undefined],
  ])('rejects guests that are %s', (_label, guests) => {
    expect(errorsOf({ ...valid, guests })).toHaveProperty('guests')
  })

  it('accepts the guest bounds 1 and 8', () => {
    expect(errorsOf({ ...valid, guests: 1 })).toEqual({})
    expect(errorsOf({ ...valid, guests: 8 })).toEqual({})
  })

  it('reports one message per field and strips unknown keys', () => {
    const errors = errorsOf({ name: '', email: 'nope', guests: 0 })
    expect(Object.keys(errors).sort()).toEqual(['email', 'guests', 'name'])
    expect(bookingInput.parse({ ...valid, role: 'admin' })).toEqual(valid)
  })

  it('rejects input that is not an object', () => {
    expect(bookingInput.safeParse(null).success).toBe(false)
  })
})

describe('bookingInputFor(seatsLeft)', () => {
  it('limits guests to the seats left with the capacity message', () => {
    expect(errorsOf({ ...valid, guests: 4 }, bookingInputFor(3))).toEqual({ guests: 'Only 3 seats left for this tasting.' })
    expect(errorsOf({ ...valid, guests: 3 }, bookingInputFor(3))).toEqual({})
  })

  it('says fully booked when no seats are left', () => {
    expect(errorsOf({ ...valid, guests: 1 }, bookingInputFor(0))).toEqual({ guests: 'This tasting is fully booked.' })
  })

  it('keeps the 8 guest cap when many seats are left', () => {
    expect(errorsOf({ ...valid, guests: 9 }, bookingInputFor(12))).toHaveProperty('guests')
  })
})

describe('capacityMessage', () => {
  it('words sold out and partial availability', () => {
    expect(capacityMessage(0)).toBe('This tasting is fully booked.')
    expect(capacityMessage(5)).toBe('Only 5 seats left for this tasting.')
  })

  it('uses the singular for one seat', () => {
    expect(capacityMessage(1)).toBe('Only 1 seat left for this tasting.')
  })
})

describe('loginInput', () => {
  it('requires a password', () => {
    expect(errorsOf({ password: '' }, loginInput as never)).toHaveProperty('password')
    expect(loginInput.safeParse({ password: 'x' }).success).toBe(true)
  })
})
