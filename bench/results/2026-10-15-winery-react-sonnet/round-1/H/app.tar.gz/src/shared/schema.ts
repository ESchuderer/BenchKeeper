import { z } from 'zod'
import { MAX_GUESTS_PER_BOOKING } from './tastings.js'

export const NAME_MAX_LENGTH = 100
export const EMAIL_MAX_LENGTH = 254

export const FIELD_NAMES = ['name', 'email', 'guests', 'password'] as const
export type FieldName = (typeof FIELD_NAMES)[number]
export type FieldErrors = Partial<Record<FieldName, string>>

export function capacityMessage(seatsLeft: number): string {
  if (seatsLeft <= 0) return 'This tasting is fully booked.'
  return seatsLeft === 1 ? 'Only 1 seat left for this tasting.' : `Only ${seatsLeft} seats left for this tasting.`
}

function guestsField(seatsLeft: number) {
  const limit = Math.min(MAX_GUESTS_PER_BOOKING, seatsLeft)
  const tooMany =
    seatsLeft < MAX_GUESTS_PER_BOOKING ? capacityMessage(seatsLeft) : `You can book up to ${MAX_GUESTS_PER_BOOKING} guests at a time.`
  return z
    .number({ error: 'Enter the number of guests.' })
    .int('Guests must be a whole number.')
    .min(1, 'Book for at least 1 guest.')
    .max(limit, tooMany)
}

const nameField = z
  .string({ error: 'Enter your name.' })
  .trim()
  .min(1, 'Enter your name.')
  .max(NAME_MAX_LENGTH, `Name can have at most ${NAME_MAX_LENGTH} characters.`)

const emailField = z
  .string({ error: 'Enter your email address.' })
  .trim()
  .min(1, 'Enter your email address.')
  .max(EMAIL_MAX_LENGTH, 'That email address is too long.')
  .pipe(z.email('Enter a valid email address, like name@example.com.'))

function bookingShape(seatsLeft: number) {
  return z.object({ name: nameField, email: emailField, guests: guestsField(seatsLeft) })
}

/** Shape rules only; capacity is decided by the store, which owns the seat count. */
export const bookingInput = bookingShape(MAX_GUESTS_PER_BOOKING)

/** Shape rules plus the seats currently left (used by the form for instant feedback). */
export function bookingInputFor(seatsLeft: number) {
  return bookingShape(seatsLeft)
}

export const loginInput = z.object({ password: z.string({ error: 'Enter the password.' }).min(1, 'Enter the password.') })

export type BookingInput = z.infer<typeof bookingInput>

/** First message per field, keyed by field name. */
export function fieldErrors(error: z.ZodError): FieldErrors {
  const errors: FieldErrors = {}
  for (const issue of error.issues) {
    const field = FIELD_NAMES.find((name) => name === issue.path[0])
    if (field && !(field in errors)) errors[field] = issue.message
  }
  return errors
}
