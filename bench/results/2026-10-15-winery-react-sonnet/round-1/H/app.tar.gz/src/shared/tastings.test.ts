import { MAX_GUESTS_PER_BOOKING, TASTINGS } from './tastings.js'

describe('tasting catalogue', () => {
  it('offers the three tastings from the brief', () => {
    expect(TASTINGS.map((t) => [t.id, t.title, t.startsAt, t.pricePerGuest, t.seats])).toEqual([
      ['riesling-evening', 'Riesling Evening', '2026-11-06T18:00', 25, 12],
      ['red-wine-cellar-tour', 'Red Wine Cellar Tour', '2026-11-14T15:00', 32, 8],
      ['winter-tasting', 'Winter Tasting', '2026-12-05T17:00', 28, 10],
    ])
  })

  it('allows at most 8 guests per booking', () => {
    expect(MAX_GUESTS_PER_BOOKING).toBe(8)
  })
})
