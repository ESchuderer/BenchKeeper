export const MAX_GUESTS_PER_BOOKING = 8

export interface Tasting {
  readonly id: string
  readonly title: string
  /** Local wall-clock start, `YYYY-MM-DDTHH:mm` (no timezone: the winery's own time). */
  readonly startsAt: string
  readonly pricePerGuest: number
  readonly seats: number
}

export interface TastingView extends Tasting {
  readonly seatsLeft: number
}

export const TASTINGS: readonly Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuest: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuest: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuest: 28, seats: 10 },
]

export interface BookingConfirmation {
  readonly reference: string
  readonly tastingId: string
  readonly name: string
  readonly guests: number
  readonly total: number
}

export interface BookingCreated {
  readonly booking: BookingConfirmation
  readonly tasting: TastingView
}

export interface StaffBooking {
  readonly reference: string
  readonly name: string
  readonly email: string
  readonly guests: number
}

export interface StaffTastingGroup {
  readonly tasting: TastingView
  readonly bookings: readonly StaffBooking[]
}
