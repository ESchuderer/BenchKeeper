import { QueryClientProvider } from '@tanstack/react-query'
import { render } from '@testing-library/react'
import { MemoryRouter } from 'react-router'
import { AppRoutes } from '../client/App.js'
import { createQueryClient } from '../client/queryClient.js'
import { TASTINGS, type StaffTastingGroup, type TastingView } from '../shared/tastings.js'

export { NETWORK_ERROR, fakeBackend, reply, type FakeRoute, type FakeReply, type RecordedCall } from './fakeBackend.js'

export function tastingViews(seatsLeft: Record<string, number> = {}): TastingView[] {
  return TASTINGS.map((t) => ({ ...t, seatsLeft: seatsLeft[t.id] ?? t.seats }))
}

export function staffGroups(
  bookings: Record<string, StaffTastingGroup['bookings']> = {},
  seatsLeft: Record<string, number> = {},
): StaffTastingGroup[] {
  return tastingViews(seatsLeft).map((tasting) => ({ tasting, bookings: bookings[tasting.id] ?? [] }))
}

export function renderAt(path: string) {
  const client = createQueryClient({ retry: false, refetchOnWindowFocus: false })
  const view = render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[path]}>
        <AppRoutes />
      </MemoryRouter>
    </QueryClientProvider>,
  )
  return { ...view, client }
}
