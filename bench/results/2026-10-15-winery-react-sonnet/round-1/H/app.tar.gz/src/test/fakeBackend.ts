import { vi } from 'vitest'

export interface FakeReply {
  readonly status: number
  readonly body?: unknown
}

export const reply = (status: number, body?: unknown): FakeReply => ({ status, body })

/** Returned by a handler to make fetch itself fail, as when the server cannot be reached. */
export const NETWORK_ERROR = Symbol('network error')

export interface RecordedCall {
  readonly method: string
  readonly path: string
  readonly body: unknown
}

type HandlerResult = FakeReply | typeof NETWORK_ERROR
type Handler = (call: RecordedCall) => HandlerResult | Promise<HandlerResult>
export type FakeRoute = Handler | FakeReply | typeof NETWORK_ERROR

const unexpectedRequests: string[] = []

/** Called after every test: a request nobody stubbed is a failure even if the UI swallowed the error. */
export function takeUnexpectedRequests(): string[] {
  return unexpectedRequests.splice(0)
}

/** Replaces global fetch with route handlers keyed "METHOD /path". */
export function fakeBackend(routes: Record<string, FakeRoute>) {
  const calls: RecordedCall[] = []
  vi.stubGlobal(
    'fetch',
    vi.fn(async (input: string, init: RequestInit = {}) => {
      const method = (init.method ?? 'GET').toUpperCase()
      const call: RecordedCall = { method, path: input, body: init.body ? JSON.parse(String(init.body)) : undefined }
      calls.push(call)
      const route = routes[`${method} ${input}`]
      if (!route) {
        unexpectedRequests.push(`${method} ${input}`)
        return new Response(JSON.stringify({ error: 'Unexpected request in test' }), { status: 599 })
      }
      const result = typeof route === 'function' ? await route(call) : route
      if (result === NETWORK_ERROR) throw new TypeError('Failed to fetch')
      const { status, body } = result
      return new Response(status === 204 || body === undefined ? null : JSON.stringify(body), {
        status,
        headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
      })
    }),
  )
  return { calls, count: (method: string, path: string) => calls.filter((c) => c.method === method && c.path === path).length }
}
