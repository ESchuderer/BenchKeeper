import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createApp, type AppConfig } from '../server/app.js'
import { createStore } from '../server/store.js'

export const STAFF_PASSWORD = 'test-staff-password'

export function makeClientDir(): string {
  const dir = mkdtempSync(join(tmpdir(), 'kb-client-'))
  mkdirSync(join(dir, 'assets'))
  writeFileSync(join(dir, 'index.html'), '<!doctype html><title>Kieselbrunnen</title><div id="root"></div>')
  writeFileSync(join(dir, 'assets', 'app.js'), 'console.log("app")')
  return dir
}

const GENEROUS = { max: 1000, windowMs: 60_000 }

export function makeApp(overrides: Partial<AppConfig> = {}) {
  let n = 0
  const store = overrides.store ?? createStore(undefined, () => `KB-TEST${++n}`)
  const app = createApp({
    store,
    staffPassword: STAFF_PASSWORD,
    clientDir: makeClientDir(),
    limits: { login: GENEROUS, booking: GENEROUS },
    log: () => {},
    ...overrides,
  })
  return { app, store }
}

export const guestBody = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 }
