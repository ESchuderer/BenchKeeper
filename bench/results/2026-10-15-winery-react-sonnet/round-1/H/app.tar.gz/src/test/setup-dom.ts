import '@testing-library/jest-dom/vitest'
import { cleanup } from '@testing-library/react'
import { afterEach, vi } from 'vitest'
import { takeUnexpectedRequests } from './fakeBackend.js'

afterEach(() => {
  cleanup()
  vi.unstubAllGlobals()
  const unexpected = takeUnexpectedRequests()
  if (unexpected.length > 0) throw new Error(`Requests nobody stubbed: ${unexpected.join(', ')}`)
})
