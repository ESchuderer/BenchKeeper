# Constraints

The quality bar for this project. Do not lower it to get a check green; change the code instead.

- **Tests first.** Every behaviour in `openspec/` has a test (Vitest for domain, API and components; Playwright for end-to-end).
- **No skipped or deleted tests**, no `eslint-disable`, `@ts-ignore` or `@ts-expect-error` to silence a check.
- **Gates that must pass:** `npm run lint`, `npm run typecheck`, `npm test`, `npm run build`, `npm run test:e2e`.
- **Overbooking is impossible.** Seats left are derived from bookings, checked on the server for every booking.
- **Accessibility:** no axe violations on any page; form errors linked to their field (`aria-invalid`, `aria-describedby`, `role="alert"`).
- **Mobile:** no horizontal scroll at 360 px; touch targets of at least 44 px.
- **Security:** staff data only behind the session; constant-time password check; login rate limited; no secrets in the client bundle.
