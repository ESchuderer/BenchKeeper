# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings online; staff see and cancel bookings.

- Guests: `/` lists the tastings, `Book <title>` opens the booking form, a confirmation shows the booking reference.
- Staff: `/staff`, protected by the password in `STAFF_PASSWORD`.

## Run

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start   # http://localhost:3000, or set PORT
```

Without `STAFF_PASSWORD` the app runs, but nobody can sign in to `/staff`. Bookings live in memory and are gone after a restart.

Behind a reverse proxy that terminates TLS set:

- `TRUST_PROXY=1` (the number of proxies in front of the app) so rate limits see each visitor's address instead of the proxy's. Leave it unset when the app is reachable directly, otherwise clients could spoof their address.
- `COOKIE_SECURE=true` so the staff cookie is only sent over https (the proxy must send `X-Forwarded-Proto`).

Use a long, random `STAFF_PASSWORD`: it is a single shared secret.

## Develop

| Command | What it does |
|---|---|
| `npm run dev` | Vite dev server (with `/api` proxy) and the API server with reload |
| `npm test` | Vitest: validation, store, HTTP API, React components |
| `npm run test:e2e` | Playwright against the built app (desktop and 360 px phone, incl. axe accessibility checks) |
| `npm run lint` / `npm run typecheck` | ESLint / TypeScript |

Playwright needs a Chromium: `npx playwright install chromium`.

## Layout

- `shared/` booking rules (zod schema) and types used by both server and browser
- `server/` Express app (`app.ts`), in-memory store (`store.ts`), entry point (`index.ts`)
- `client/` React app (Vite, React Router, React Hook Form, Tailwind)
- `tests/`, `e2e/` tests; `openspec/` the specification, design and task list this was built from
