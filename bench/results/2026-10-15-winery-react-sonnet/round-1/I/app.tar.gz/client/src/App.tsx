import { Route, Routes } from 'react-router';
import { Layout } from './components/Layout';
import { NotFound } from './components/StatusViews';
import { Booking } from './pages/Booking';
import { Home } from './pages/Home';
import { Staff } from './pages/Staff';

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="tastings/:id/book" element={<Booking />} />
        <Route path="staff" element={<Staff />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
