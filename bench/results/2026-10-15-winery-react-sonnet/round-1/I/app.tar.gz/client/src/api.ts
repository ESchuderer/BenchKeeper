import type { Booking, BookingInput, FieldErrors, Tasting } from '../../shared/booking';

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly errors?: Record<string, string>,
  ) {
    super(message);
  }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      method,
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError('We could not reach the server. Please check your connection and try again.', 0);
  }
  const data = res.status === 204 ? undefined : await res.json().catch(() => undefined);
  if (!res.ok) {
    throw new ApiError(data?.error ?? 'Something went wrong. Please try again.', res.status, data?.errors);
  }
  return data as T;
}

export interface ConfirmedBooking extends Booking {
  tastingTitle: string;
  startsAt: string;
}

export interface StaffTasting extends Tasting {
  bookings: Booking[];
}

export const api = {
  tastings: () => request<{ tastings: Tasting[] }>('GET', '/api/tastings').then((r) => r.tastings),
  tasting: (id: string) => request<{ tasting: Tasting }>('GET', `/api/tastings/${encodeURIComponent(id)}`).then((r) => r.tasting),
  book: (id: string, input: Record<keyof BookingInput, unknown>) =>
    request<{ booking: ConfirmedBooking }>('POST', `/api/tastings/${encodeURIComponent(id)}/bookings`, input).then((r) => r.booking),
  staffSession: () => request<{ signedIn: boolean }>('GET', '/api/staff/session').then((r) => r.signedIn),
  staffLogin: (password: string) => request<{ signedIn: boolean }>('POST', '/api/staff/login', { password }),
  staffLogout: () => request<{ signedIn: boolean }>('POST', '/api/staff/logout', {}),
  staffBookings: () => request<{ tastings: StaffTasting[] }>('GET', '/api/staff/bookings').then((r) => r.tastings),
  cancelBooking: (reference: string) => request<void>('DELETE', `/api/staff/bookings/${encodeURIComponent(reference)}`),
};

export type { FieldErrors };
