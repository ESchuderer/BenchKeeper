import type { ReactNode } from 'react';

type Tone = 'error' | 'success';

const styles: Record<Tone, string> = {
  error: 'border-danger-700 bg-danger-50 text-danger-700',
  success: 'border-leaf-700 bg-leaf-50 text-leaf-700',
};

const icons: Record<Tone, string> = { error: '!', success: '✓' };

/** Banner for errors (announced immediately) and success notices (announced politely). */
export function Banner({ tone, children, action }: { tone: Tone; children: ReactNode; action?: ReactNode }) {
  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={`flex flex-wrap items-center gap-3 rounded-lg border-2 px-4 py-3 font-medium ${styles[tone]}`}
    >
      <span
        aria-hidden="true"
        className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-current text-sm font-bold"
      >
        <span className="text-white">{icons[tone]}</span>
      </span>
      <span className="min-w-0 flex-1">{children}</span>
      {action}
    </div>
  );
}

export function FieldError({ id, children }: { id: string; children?: string }) {
  if (!children) return null;
  return (
    <p id={id} role="alert" className="mt-1.5 flex items-start gap-1.5 text-sm font-medium text-danger-700">
      <span aria-hidden="true" className="font-bold">
        ⚠
      </span>
      <span>{children}</span>
    </p>
  );
}
