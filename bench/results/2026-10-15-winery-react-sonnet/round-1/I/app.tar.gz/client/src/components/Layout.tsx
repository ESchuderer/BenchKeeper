import { Link, Outlet } from 'react-router';

function Grapes() {
  return (
    <svg viewBox="0 0 64 64" width="36" height="36" aria-hidden="true" focusable="false">
      <g fill="#f2e9d8">
        <circle cx="22" cy="32" r="8" />
        <circle cx="42" cy="32" r="8" />
        <circle cx="32" cy="44" r="8" />
      </g>
      <path d="M32 28c0-9 5-14 14-15-1 9-6 14-14 15z" fill="#b08d57" />
    </svg>
  );
}

export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-10 focus:rounded focus:bg-white focus:px-3 focus:py-2"
      >
        Skip to content
      </a>
      <header className="border-b-4 border-gold bg-wine-800 text-parchment">
        <div className="mx-auto flex max-w-5xl items-center px-4 py-3">
          <Link to="/" className="inline-flex min-h-11 items-center gap-3 rounded text-parchment no-underline">
            <Grapes />
            <span className="flex flex-col leading-tight">
              <span className="font-display text-xl font-bold tracking-wide sm:text-2xl">Weingut Kieselbrunnen</span>
              <span className="text-xs uppercase tracking-[0.2em] text-parchment/80">Family winery</span>
            </span>
          </Link>
        </div>
      </header>
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:py-12">
        <Outlet />
      </main>
      <footer className="border-t border-line bg-parchment">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-4 text-sm text-muted">
          <p>Weingut Kieselbrunnen · Wine tastings in the cellar</p>
          <Link to="/staff" className="inline-flex min-h-11 items-center px-2 text-muted underline">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
