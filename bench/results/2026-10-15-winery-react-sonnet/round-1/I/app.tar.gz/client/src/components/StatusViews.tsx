import { Link } from 'react-router';
import { ApiError } from '../api';
import { Banner } from './Feedback';
import { usePageTitle } from '../usePageTitle';

export function Loading({ label = 'Loading…' }: { label?: string }) {
  return (
    <p role="status" className="py-10 text-center text-muted">
      {label}
    </p>
  );
}

export function LoadError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <Banner
      tone="error"
      action={
        <button type="button" className="btn btn-secondary" onClick={onRetry}>
          Try again
        </button>
      }
    >
      {message}
    </Banner>
  );
}

export const isNotFound = (error: unknown) => error instanceof ApiError && error.status === 404;

export function NotFound({ what = 'Page' }: { what?: string }) {
  usePageTitle('Not found');
  return (
    <section className="mx-auto max-w-xl py-10 text-center">
      <p aria-hidden="true" className="font-display text-6xl text-wine-700">
        404
      </p>
      <h1 className="mt-2 text-3xl font-bold">{what} not found</h1>
      <p className="mt-3 text-muted">The link may be old or mistyped. Our tastings are only a click away.</p>
      <Link to="/" className="btn mt-6">
        Back to the tastings
      </Link>
    </section>
  );
}
