import type { Tasting } from '../../../shared/booking';
import { formatEuro } from '../../../shared/booking';
import { isoDateTime, seatsLeftText, weekday } from '../format';

export function WhenBadge({ startsAt }: { startsAt: string }) {
  return (
    <p className="flex flex-col text-wine-700">
      <span className="text-xs font-bold uppercase tracking-[0.18em]">{weekday(startsAt)}</span>
      <time dateTime={isoDateTime(startsAt)} className="font-display text-lg font-bold">
        {startsAt}
      </time>
    </p>
  );
}

export function SeatMeter({ tasting }: { tasting: Tasting }) {
  const taken = tasting.seats - tasting.seatsLeft;
  const full = tasting.seatsLeft === 0;
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className={`font-semibold ${full ? 'text-muted' : 'text-leaf-700'}`}>{seatsLeftText(tasting.seatsLeft)}</p>
        {full && (
          <span className="rounded-full border-2 border-danger-700 bg-danger-50 px-3 py-0.5 text-sm font-bold text-danger-700">
            Fully booked
          </span>
        )}
      </div>
      <div aria-hidden="true" className="mt-2 h-2 overflow-hidden rounded-full bg-parchment">
        <div
          className={`h-full rounded-full ${full ? 'bg-danger-700' : 'bg-wine-700'}`}
          style={{ width: `${(taken / tasting.seats) * 100}%` }}
        />
      </div>
    </div>
  );
}

export function Price({ priceEur }: { priceEur: number }) {
  return (
    <p className="flex items-baseline gap-1.5">
      <span className="font-display text-2xl font-bold text-wine-800">{formatEuro(priceEur)}</span>
      <span className="text-sm text-muted">per guest</span>
    </p>
  );
}
