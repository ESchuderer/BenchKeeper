const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/** "2026-11-06 18:00" → "Friday". The date is winery-local, so no timezone conversion happens. */
export function weekday(startsAt: string): string {
  const [y, m, d] = startsAt.slice(0, 10).split('-').map(Number);
  return WEEKDAYS[new Date(Date.UTC(y!, m! - 1, d!)).getUTCDay()]!;
}

export const isoDateTime = (startsAt: string) => startsAt.replace(' ', 'T');

export const seatsLeftText = (n: number) => `${n} seats left`;
