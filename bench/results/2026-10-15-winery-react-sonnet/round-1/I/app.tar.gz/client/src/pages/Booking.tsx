import { useCallback, useMemo, useRef, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router';
import { useForm } from 'react-hook-form';
import type { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { bookingSchema, formatEuro, MAX_GUESTS, type BookingField, type BookingInput, type Tasting } from '../../../shared/booking';
import { api, ApiError, type ConfirmedBooking } from '../api';
import { Banner, FieldError } from '../components/Feedback';
import { isNotFound, LoadError, Loading, NotFound } from '../components/StatusViews';
import { Price, SeatMeter, WhenBadge } from '../components/TastingDetails';
import { useLoad } from '../useLoad';
import { usePageTitle } from '../usePageTitle';

const BackLink = () => (
  <Link to="/" className="btn btn-secondary">
    Back to the tastings
  </Link>
);

export function Booking() {
  const { id = '' } = useParams();
  const load = useCallback(() => api.tasting(id), [id]);
  const { state, reload, retry } = useLoad(load);
  const [confirmed, setConfirmed] = useState<ConfirmedBooking | null>(null);

  usePageTitle(state.status === 'ready' ? `Book ${state.data.title}` : 'Book a tasting');

  if (confirmed) return <Confirmation booking={confirmed} />;
  if (state.status === 'loading') return <Loading label="Loading the tasting…" />;
  if (state.status === 'error') {
    return isNotFound(state.error) ? (
      <NotFound what="Tasting" />
    ) : (
      <LoadError message="We could not load this tasting." onRetry={retry} />
    );
  }

  const tasting = state.data;
  return (
    <div className="mx-auto max-w-xl">
      <h1 className="text-3xl font-bold sm:text-4xl">{tasting.title}</h1>
      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <WhenBadge startsAt={tasting.startsAt} />
        <Price priceEur={tasting.priceEur} />
      </div>

      {tasting.seatsLeft === 0 ? (
        <div className="mt-8 space-y-4">
          <Banner tone="error">Sorry, this tasting is fully booked.</Banner>
          <BackLink />
        </div>
      ) : (
        <>
          <div className="mt-5">
            <SeatMeter tasting={tasting} />
          </div>
          <BookingForm tasting={tasting} onSeatsChanged={() => void reload()} onConfirmed={setConfirmed} />
        </>
      )}
    </div>
  );
}

function BookingForm({
  tasting,
  onSeatsChanged,
  onConfirmed,
}: {
  tasting: Tasting;
  onSeatsChanged: () => void;
  onConfirmed: (booking: ConfirmedBooking) => void;
}) {
  const maxGuests = Math.min(MAX_GUESTS, tasting.seatsLeft);
  const [formError, setFormError] = useState<string | null>(null);
  const inFlight = useRef(false);

  const schema = useMemo(
    () =>
      bookingSchema.refine((value) => value.guests <= tasting.seatsLeft, {
        path: ['guests'],
        message:
          tasting.seatsLeft === 1 ? 'Only 1 seat is left for this tasting.' : `Only ${tasting.seatsLeft} seats are left for this tasting.`,
      }),
    [tasting.seatsLeft],
  );

  const {
    register,
    handleSubmit,
    setError,
    setFocus,
    formState: { errors, isSubmitting },
  } = useForm<z.input<typeof bookingSchema>, unknown, BookingInput>({
    resolver: zodResolver(schema),
    defaultValues: { name: '', email: '', guests: '2' },
    shouldFocusError: true,
  });

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null);
    try {
      onConfirmed(await api.book(tasting.id, values));
    } catch (error) {
      if (error instanceof ApiError && error.errors) {
        let first: BookingField | undefined;
        for (const [field, message] of Object.entries(error.errors) as [BookingField, string][]) {
          setError(field, { type: 'server', message });
          first ??= field;
        }
        if (first) setFocus(first);
        if (error.status === 409) onSeatsChanged();
      } else {
        setFormError(error instanceof Error ? error.message : 'Something went wrong. Please try again.');
      }
    }
  });

  // A second submit while one is on its way (double click, Enter twice) must not book twice.
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (inFlight.current) return;
    inFlight.current = true;
    void onSubmit().finally(() => {
      inFlight.current = false;
    });
  };

  return (
    <form onSubmit={submit} noValidate className="card mt-6 space-y-5 p-5 sm:p-6">
      {formError && <Banner tone="error">{formError}</Banner>}

      <Field label="Name" id="name" error={errors.name?.message}>
        <input id="name" type="text" autoComplete="name" className="field-input" {...a11y('name', errors.name?.message)} {...register('name')} />
      </Field>

      <Field label="Email" id="email" error={errors.email?.message}>
        <input
          id="email"
          type="email"
          autoComplete="email"
          className="field-input"
          {...a11y('email', errors.email?.message)}
          {...register('email')}
        />
      </Field>

      <Field
        label="Guests"
        id="guests"
        error={errors.guests?.message}
        hint={`1 to ${maxGuests} guests, ${formatEuro(tasting.priceEur)} each`}
      >
        <input
          id="guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={maxGuests}
          step={1}
          className="field-input"
          {...a11y('guests', errors.guests?.message, 'guests-hint')}
          {...register('guests')}
        />
      </Field>

      <button type="submit" className="btn w-full" disabled={isSubmitting}>
        {isSubmitting ? 'Booking…' : 'Book'}
      </button>
    </form>
  );
}

function a11y(id: string, error?: string, hintId?: string) {
  return {
    'aria-invalid': error ? true : undefined,
    'aria-describedby': [error ? `${id}-error` : null, hintId].filter(Boolean).join(' ') || undefined,
  } as const;
}

function Field({
  label,
  id,
  error,
  hint,
  children,
}: {
  label: string;
  id: string;
  error?: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block font-semibold">
        {label}
      </label>
      {children}
      <FieldError id={`${id}-error`}>{error}</FieldError>
      {hint && (
        <p id={`${id}-hint`} className="mt-1.5 text-sm text-muted">
          {hint}
        </p>
      )}
    </div>
  );
}

function Confirmation({ booking }: { booking: ConfirmedBooking }) {
  usePageTitle('Booking confirmed');
  return (
    <section aria-labelledby="confirmed-heading" className="mx-auto max-w-xl">
      <div className="card overflow-hidden border-leaf-700">
        <div className="flex items-center gap-3 border-b border-leaf-700/30 bg-leaf-50 px-5 py-4 text-leaf-700 sm:px-6">
          <span aria-hidden="true" className="flex h-9 w-9 items-center justify-center rounded-full bg-leaf-700 text-xl text-white">
            ✓
          </span>
          <h1 id="confirmed-heading" className="text-2xl font-bold text-leaf-700 sm:text-3xl">
            Booking confirmed
          </h1>
        </div>
        <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-3 px-5 py-5 sm:px-6">
          <dt className="text-muted">Tasting</dt>
          <dd className="font-semibold">{booking.tastingTitle}</dd>
          <dt className="text-muted">Date</dt>
          <dd>{booking.startsAt}</dd>
          <dt className="text-muted">Guests</dt>
          <dd>{booking.guests}</dd>
          <dt className="text-muted">Total price</dt>
          <dd className="font-semibold">{formatEuro(booking.totalEur)}</dd>
          <dt className="text-muted">Booking reference</dt>
          <dd className="font-mono text-lg font-bold tracking-wider text-wine-800">{booking.reference}</dd>
        </dl>
      </div>
      <p className="mt-4 text-muted">
        Please keep your booking reference.
      </p>
      <div className="mt-6">
        <BackLink />
      </div>
    </section>
  );
}
