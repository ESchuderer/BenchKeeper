import { Link } from 'react-router';
import { api } from '../api';
import { LoadError, Loading } from '../components/StatusViews';
import { Price, SeatMeter, WhenBadge } from '../components/TastingDetails';
import { useLoad } from '../useLoad';
import { usePageTitle } from '../usePageTitle';

export function Home() {
  usePageTitle('Wine tastings');
  const { state, retry } = useLoad(api.tastings);

  return (
    <>
      <section className="max-w-2xl">
        <h1 className="text-3xl font-bold sm:text-5xl">Wine tastings at Kieselbrunnen</h1>
        <p className="mt-4 text-lg text-muted">
          Join us in the cellar for an evening with our family&rsquo;s wines. Pick a tasting, choose your seats and
          you are booked.
        </p>
      </section>

      <section aria-label="Upcoming tastings" className="mt-8 sm:mt-10">
        {state.status === 'loading' && <Loading label="Loading the tastings…" />}
        {state.status === 'error' && <LoadError message="We could not load the tastings." onRetry={retry} />}
        {state.status === 'ready' && (
          <ul className="grid gap-6 md:grid-cols-3">
            {state.data.map((tasting) => {
              const full = tasting.seatsLeft === 0;
              return (
                <li key={tasting.id} className="flex">
                  <article
                    aria-labelledby={`tasting-${tasting.id}`}
                    className={`card flex w-full flex-col gap-4 p-5 ${full ? 'bg-parchment/60' : ''}`}
                  >
                    <WhenBadge startsAt={tasting.startsAt} />
                    <h2 id={`tasting-${tasting.id}`} className="text-2xl font-bold">
                      {tasting.title}
                    </h2>
                    <Price priceEur={tasting.priceEur} />
                    <div className="mt-auto flex flex-col gap-4">
                      <SeatMeter tasting={tasting} />
                      {!full && (
                        <Link to={`/tastings/${tasting.id}/book`} className="btn">
                          Book {tasting.title}
                        </Link>
                      )}
                    </div>
                  </article>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </>
  );
}
