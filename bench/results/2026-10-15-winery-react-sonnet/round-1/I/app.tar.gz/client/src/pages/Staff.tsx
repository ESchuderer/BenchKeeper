import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { api, ApiError } from '../api';
import { Banner, FieldError } from '../components/Feedback';
import { Loading } from '../components/StatusViews';
import { seatsLeftText } from '../format';
import { useLoad } from '../useLoad';
import { usePageTitle } from '../usePageTitle';
import { WhenBadge } from '../components/TastingDetails';

type View = { kind: 'checking' } | { kind: 'signed-out' } | { kind: 'signed-in' };

export function Staff() {
  usePageTitle('Staff');
  const [view, setView] = useState<View>({ kind: 'checking' });
  const [sessionError, setSessionError] = useState<string | null>(null);

  const signedOut = useCallback(() => setView({ kind: 'signed-out' }), []);
  const signedIn = useCallback(() => {
    setSessionError(null);
    setView({ kind: 'signed-in' });
  }, []);

  useEffect(() => {
    let current = true;
    api
      .staffSession()
      .then((signedIn) => current && setView({ kind: signedIn ? 'signed-in' : 'signed-out' }))
      .catch((error: Error) => {
        if (!current) return;
        setSessionError(error.message);
        setView({ kind: 'signed-out' });
      });
    return () => {
      current = false;
    };
  }, []);

  return (
    <div className="mx-auto max-w-3xl">
      {view.kind === 'checking' && <Loading />}
      {view.kind === 'signed-out' && <SignIn initialError={sessionError} onSignedIn={signedIn} />}
      {view.kind === 'signed-in' && <Overview onSignedOut={signedOut} />}
    </div>
  );
}

function SignIn({ onSignedIn, initialError }: { onSignedIn: () => void; initialError: string | null }) {
  const [formError, setFormError] = useState<string | null>(initialError);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } });

  const onSubmit = handleSubmit(async ({ password }) => {
    setFormError(null);
    try {
      await api.staffLogin(password);
      onSignedIn();
    } catch (error) {
      if (error instanceof ApiError && error.errors?.password) {
        setError('password', { type: 'server', message: error.errors.password });
      } else {
        setFormError(error instanceof Error ? error.message : 'Something went wrong. Please try again.');
      }
    }
  });

  return (
    <div className="mx-auto max-w-md">
      <h1 className="text-3xl font-bold">Staff</h1>
      <p className="mt-2 text-muted">Sign in to see the bookings for the upcoming tastings.</p>
      <form onSubmit={onSubmit} noValidate className="card mt-6 space-y-5 p-5 sm:p-6">
        {formError && <Banner tone="error">{formError}</Banner>}
        <div>
          <label htmlFor="password" className="mb-1.5 block font-semibold">
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className="field-input"
            aria-invalid={errors.password ? true : undefined}
            aria-describedby={errors.password ? 'password-error' : undefined}
            {...register('password')}
          />
          <FieldError id="password-error">{errors.password?.message}</FieldError>
        </div>
        <button type="submit" className="btn w-full" disabled={isSubmitting}>
          Sign in
        </button>
      </form>
    </div>
  );
}

function Overview({ onSignedOut }: { onSignedOut: () => void }) {
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  // A 401 means the session is gone: go back to the sign-in prompt.
  const loadBookings = useCallback(
    () =>
      api.staffBookings().catch((e: unknown) => {
        if (e instanceof ApiError && e.status === 401) onSignedOut();
        throw e;
      }),
    [onSignedOut],
  );
  const { state, reload } = useLoad(loadBookings);

  async function refresh() {
    setError(null);
    if (!(await reload()) && state.status === 'ready') {
      setError('We could not refresh the bookings. The list below may be out of date.');
    }
  }

  async function cancel(reference: string, name: string) {
    setBusy(reference);
    setError(null);
    setNotice(null);
    try {
      await api.cancelBooking(reference);
      setNotice(`Booking ${reference} for ${name} was cancelled. Its seats are free again.`);
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) {
        onSignedOut();
        return;
      }
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.');
    }
    setBusy(null);
    if (!(await reload())) setError((prev) => prev ?? 'We could not refresh the bookings. The list below may be out of date.');
  }

  async function signOut() {
    try {
      await api.staffLogout();
    } finally {
      onSignedOut();
    }
  }

  const loadError = state.status === 'error' && !(state.error instanceof ApiError && state.error.status === 401);
  const tastings = state.status === 'ready' ? state.data : null;

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-bold">Bookings</h1>
        <div className="flex gap-3">
          <button type="button" className="btn btn-secondary" onClick={() => void refresh()}>
            Refresh
          </button>
          <button type="button" className="btn btn-secondary" onClick={() => void signOut()}>
            Sign out
          </button>
        </div>
      </div>

      <div className="mt-5 space-y-3">
        {error && <Banner tone="error">{error}</Banner>}
        {loadError && <Banner tone="error">We could not load the bookings. Please try again.</Banner>}
        {notice && <Banner tone="success">{notice}</Banner>}
      </div>

      {tastings === null ? (
        !loadError && <Loading label="Loading the bookings…" />
      ) : (
        <div className="mt-6 space-y-6">
          {tastings.map((tasting) => (            <section key={tasting.id} aria-labelledby={`staff-${tasting.id}`} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 id={`staff-${tasting.id}`} className="text-2xl font-bold">
                    {tasting.title}
                  </h2>
                  <WhenBadge startsAt={tasting.startsAt} />
                </div>
                <p className="text-sm font-semibold text-muted">{seatsLeftText(tasting.seatsLeft)}</p>
              </div>

              {tasting.bookings.length === 0 ? (
                <p className="mt-4 rounded-lg bg-parchment px-4 py-3 text-muted">No bookings yet.</p>
              ) : (
                <ul className="mt-4 divide-y divide-line">
                  {tasting.bookings.map((booking) => (
                    <li key={booking.reference} className="flex flex-col gap-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                      <dl className="grid min-w-0 grid-cols-[auto_1fr] gap-x-4 gap-y-1 sm:flex-1">
                        <dt className="text-muted">Name</dt>
                        <dd className="break-words font-semibold">{booking.name}</dd>
                        <dt className="text-muted">Email</dt>
                        <dd className="break-all">{booking.email}</dd>
                        <dt className="text-muted">Guests</dt>
                        <dd>{booking.guests}</dd>
                        <dt className="text-muted">Reference</dt>
                        <dd className="font-mono font-bold text-wine-800">{booking.reference}</dd>
                      </dl>
                      <button
                        type="button"
                        className="btn btn-secondary"
                        disabled={busy === booking.reference}
                        onClick={() => void cancel(booking.reference, booking.name)}
                      >
                        Cancel
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>
      )}
    </>
  );
}
