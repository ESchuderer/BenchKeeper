import { useCallback, useEffect, useState } from 'react';

export type Loaded<T> =
  | { status: 'loading' }
  | { status: 'error'; error: unknown }
  | { status: 'ready'; data: T };

/**
 * Loads data when `load` changes. `reload` refetches while keeping the current data on screen
 * (resolving to whether it worked), `retry` goes back to the loading state first.
 */
export function useLoad<T>(load: () => Promise<T>) {
  // The result remembers which `load` produced it, so a new `load` reads as "loading" without
  // resetting state inside an effect.
  const [result, setResult] = useState<{ load: () => Promise<T>; value: Loaded<T> } | null>(null);
  const state: Loaded<T> = result && result.load === load ? result.value : { status: 'loading' };

  const run = useCallback(
    (isCurrent: () => boolean = () => true) =>
      load().then(
        (data) => {
          if (isCurrent()) setResult({ load, value: { status: 'ready', data } });
          return true;
        },
        (error: unknown) => {
          // A failed refetch must not blank data that is already on screen.
          if (isCurrent()) {
            setResult((prev) =>
              prev?.load === load && prev.value.status === 'ready' ? prev : { load, value: { status: 'error', error } },
            );
          }
          return false;
        },
      ),
    [load],
  );

  useEffect(() => {
    let current = true;
    void run(() => current);
    return () => {
      current = false;
    };
  }, [run]);

  const retry = useCallback(() => {
    setResult(null);
    return run();
  }, [run]);

  return { state, reload: run, retry };
}
