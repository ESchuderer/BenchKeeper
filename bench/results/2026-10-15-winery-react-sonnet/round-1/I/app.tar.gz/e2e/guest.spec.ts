import { expect, test } from '@playwright/test';
import { book, resetBookings } from './helpers';

test.beforeEach(({ request }) => resetBookings(request));

test('start page lists the three tastings with price and seats left', async ({ page }) => {
  await page.goto('/');
  const riesling = page.getByRole('article', { name: 'Riesling Evening' });
  await expect(riesling).toContainText('2026-11-06 18:00');
  await expect(riesling).toContainText('EUR 25');
  await expect(riesling).toContainText('12 seats left');
  await expect(page.getByRole('article', { name: 'Red Wine Cellar Tour' })).toContainText('8 seats left');
  await expect(page.getByRole('article', { name: 'Winter Tasting' })).toContainText('EUR 28');
});

test('a guest books a tasting and sees the confirmation; seats left drop', async ({ page }) => {
  await book(page, 'Riesling Evening', { name: 'Anna Weber', email: 'anna@example.com', guests: 3 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const summary = page.getByRole('region', { name: 'Booking confirmed' });
  await expect(summary).toContainText('Riesling Evening');
  await expect(summary).toContainText('EUR 75');
  await expect(summary).toContainText(/KB-[A-Z2-9]{6}/);

  await page.getByRole('link', { name: /back to the tastings/i }).click();
  await expect(page.getByRole('article', { name: 'Riesling Evening' })).toContainText('9 seats left');
});

test('invalid input shows errors next to the fields', async ({ page }) => {
  await page.goto('/tastings/riesling-evening/book');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByLabel('Name')).toHaveAttribute('aria-invalid', 'true');
  await expect(page.locator('#name-error')).toContainText(/name/i);
  await expect(page.locator('#email-error')).toBeVisible();

  await page.getByLabel('Name').fill('Anna');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.locator('#guests-error')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
});

test('the seat limit holds, including when the page is stale, and a sold-out tasting is marked', async ({ page, request }) => {
  await page.goto('/tastings/red-wine-cellar-tour/book');
  // Someone else takes 6 of the 8 seats while this form is open.
  const other = await request.post('/api/tastings/red-wine-cellar-tour/bookings', {
    data: { name: 'Other', email: 'o@example.com', guests: 6 },
  });
  expect(other.status()).toBe(201);

  await page.getByLabel('Name').fill('Anna');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('3');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.locator('#guests-error')).toContainText(/only 2 seats/i);
  await expect(page.getByLabel('Guests')).toHaveAttribute('max', '2');

  await page.getByLabel('Guests').fill('2');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  const tour = page.getByRole('article', { name: 'Red Wine Cellar Tour' });
  await expect(tour).toContainText('Fully booked');
  await expect(tour).toContainText('0 seats left');
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0);

  await page.goto('/tastings/red-wine-cellar-tour/book');
  await expect(page.getByText(/fully booked/i)).toBeVisible();
  await expect(page.getByRole('button', { name: 'Book' })).toHaveCount(0);
});

test('deep links and unknown pages work after a reload', async ({ page }) => {
  await page.goto('/tastings/winter-tasting/book');
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Winter Tasting' })).toBeVisible();
  await page.goto('/tastings/unknown/book');
  await expect(page.getByRole('heading', { name: /not found/i })).toBeVisible();
  await page.goto('/no/such/page');
  await expect(page.getByRole('link', { name: /back to the tastings/i })).toBeVisible();
});
