import { expect, type APIRequestContext, type Page } from '@playwright/test';

export const STAFF_PASSWORD = 'e2e-password';

/** Removes every booking so each test starts from a fresh winery (the server keeps state in memory). */
export async function resetBookings(request: APIRequestContext) {
  await request.post('/api/staff/login', { data: { password: STAFF_PASSWORD } });
  const { tastings } = await (await request.get('/api/staff/bookings')).json();
  for (const t of tastings) for (const b of t.bookings) await request.delete(`/api/staff/bookings/${b.reference}`);
}

export async function book(page: Page, tasting: string, who: { name: string; email: string; guests: number }) {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${tasting}` }).click();
  await page.getByLabel('Name').fill(who.name);
  await page.getByLabel('Email').fill(who.email);
  await page.getByLabel('Guests').fill(String(who.guests));
  await page.getByRole('button', { name: 'Book' }).click();
}

export async function signInAsStaff(page: Page) {
  await page.goto('/staff');
  await page.getByLabel('Password').fill(STAFF_PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('button', { name: 'Sign out' })).toBeVisible();
}
