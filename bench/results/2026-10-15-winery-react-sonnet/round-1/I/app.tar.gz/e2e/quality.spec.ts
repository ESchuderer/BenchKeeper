import AxeBuilder from '@axe-core/playwright';
import { expect, test, type Page } from '@playwright/test';
import { resetBookings, signInAsStaff } from './helpers';

test.beforeEach(({ request }) => resetBookings(request));

async function expectNoHorizontalScroll(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  expect(overflow).toBeLessThanOrEqual(0);
}

async function expectAccessible(page: Page) {
  const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze();
  expect(results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target).join(', ')}`)).toEqual([]);
}

async function expectTouchTargets(page: Page) {
  const small = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>('a.btn, button, input:not([type=hidden])')]
      .map((el) => ({ text: el.textContent?.trim() || el.id, h: el.getBoundingClientRect().height }))
      .filter((x) => x.h < 44),
  );
  expect(small).toEqual([]);
}

test('start page: no horizontal scroll, accessible, touch-friendly', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Winter Tasting' })).toBeVisible();
  await expectNoHorizontalScroll(page);
  await expectAccessible(page);
  await expectTouchTargets(page);
});

test('booking form incl. error states', async ({ page }) => {
  await page.goto('/tastings/riesling-evening/book');
  await expectNoHorizontalScroll(page);
  await expectAccessible(page);
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.locator('#name-error')).toBeVisible();
  await expectAccessible(page);
  await expectNoHorizontalScroll(page);
  await expectTouchTargets(page);
});

test('confirmation page', async ({ page }) => {
  await page.goto('/tastings/riesling-evening/book');
  await page.getByLabel('Name').fill('Anna Weber');
  await page.getByLabel('Email').fill('anna-with-a-really-long-address-for-wrapping@example-winery-domain.com');
  await page.getByRole('button', { name: 'Book' }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expectNoHorizontalScroll(page);
  await expectAccessible(page);
});

test('fully booked state', async ({ page, request }) => {
  await request.post('/api/tastings/winter-tasting/bookings', { data: { name: 'G', email: 'g@example.com', guests: 8 } });
  await request.post('/api/tastings/winter-tasting/bookings', { data: { name: 'G', email: 'g@example.com', guests: 2 } });
  await page.goto('/');
  await expect(page.getByText('Fully booked')).toBeVisible();
  await expectAccessible(page);
  await page.goto('/tastings/winter-tasting/book');
  await expect(page.getByText(/fully booked/i)).toBeVisible();
  await expectAccessible(page);
});

test('staff sign-in and overview with long values', async ({ page, request }) => {
  await request.post('/api/tastings/winter-tasting/bookings', {
    data: { name: 'Anna Maria von Hohenzollern-Sigmaringen', email: 'a.very.long.email.address.indeed@subdomain.example-winery-domain.com', guests: 2 },
  });
  await page.goto('/staff');
  await expectNoHorizontalScroll(page);
  await expectAccessible(page);
  await page.getByLabel('Password').fill('nope');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.locator('#password-error')).toBeVisible();
  await expectAccessible(page);

  await signInAsStaff(page);
  await expect(page.getByText('Anna Maria von Hohenzollern-Sigmaringen')).toBeVisible();
  await expectNoHorizontalScroll(page);
  await expectAccessible(page);
  await expectTouchTargets(page);
});

test('not found page', async ({ page }) => {
  await page.goto('/nope');
  await expectNoHorizontalScroll(page);
  await expectAccessible(page);
});
