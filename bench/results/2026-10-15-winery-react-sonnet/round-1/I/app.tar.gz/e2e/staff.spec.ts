import { expect, test } from '@playwright/test';
import { book, resetBookings, signInAsStaff } from './helpers';

test.beforeEach(({ request }) => resetBookings(request));

test('staff page needs the password and rejects a wrong one next to the field', async ({ page, playwright, baseURL }) => {
  await book(page, 'Winter Tasting', { name: 'Ben Roth', email: 'ben@example.com', guests: 2 });
  await page.goto('/staff');
  await expect(page.getByText('Ben Roth')).toHaveCount(0);
  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.locator('#password-error')).toBeVisible();
  await expect(page.getByText('Ben Roth')).toHaveCount(0);

  const anonymous = await playwright.request.newContext({ baseURL });
  expect((await anonymous.get('/api/staff/bookings')).status()).toBe(401);
});

test('staff see bookings grouped by tasting and cancelling frees the seats', async ({ page, browser }) => {
  await book(page, 'Winter Tasting', { name: 'Ben Roth', email: 'ben@example.com', guests: 4 });
  const reference = (await page.getByRole('region', { name: 'Booking confirmed' }).innerText()).match(/KB-[A-Z2-9]{6}/)![0];

  const staff = await (await browser.newContext()).newPage();
  await signInAsStaff(staff);
  const winter = staff.getByRole('region', { name: 'Winter Tasting' });
  await expect(winter).toContainText('Ben Roth');
  await expect(winter).toContainText('ben@example.com');
  await expect(winter).toContainText(reference);
  await expect(winter).toContainText('6 seats left');
  await expect(staff.getByRole('region', { name: 'Riesling Evening' })).toContainText(/no bookings yet/i);

  await winter.getByRole('button', { name: 'Cancel' }).click();
  await expect(winter).not.toContainText('Ben Roth');
  await expect(winter).toContainText('10 seats left');

  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Winter Tasting' })).toContainText('10 seats left');
});

test('a cancelled booking lets a full tasting be booked again', async ({ page, request, browser }) => {
  const full = await request.post('/api/tastings/red-wine-cellar-tour/bookings', {
    data: { name: 'Group', email: 'g@example.com', guests: 8 },
  });
  expect(full.status()).toBe(201);
  await page.goto('/');
  await expect(page.getByRole('article', { name: 'Red Wine Cellar Tour' })).toContainText('Fully booked');

  const staff = await (await browser.newContext()).newPage();
  await signInAsStaff(staff);
  await staff.getByRole('region', { name: 'Red Wine Cellar Tour' }).getByRole('button', { name: 'Cancel' }).click();

  await page.reload();
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeVisible();
});

test('signing out returns to the password prompt', async ({ page }) => {
  await signInAsStaff(page);
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Password')).toBeVisible();
});
