# Design

## Context

Greenfield project, Node.js 22, one process must serve the whole app via `npm start` on `PORT`. Behaviour is defined in `specs/`; motivation in `proposal.md`. Bookings may live in memory. Interface language is English.

## Goals / Non-Goals

**Goals:**
- One deployable Node process serving the JSON API and the built React app.
- A single validation schema shared by browser and server, so rules cannot drift.
- Overbooking impossible by construction.
- Tests first at each layer: domain, HTTP API, components, and a browser end-to-end flow.

**Non-Goals:**
- Persistence across restarts, multi-instance deployment, payments, emails, user accounts.
- Server-side rendering or SEO tuning; the pages are an app, not marketing content.

## Decisions

- **Stack: Express 5 + React 19 SPA built by Vite, TypeScript throughout.** Express is the established minimal server; Vite is the standard React build tool. Alternatives: Next.js / React Router framework mode (heavier, SSR not needed), Fastify (no advantage here).
- **Routing: react-router** (`/`, `/tastings/:id/book`, `/staff`, catch-all). The Express server serves `index.html` for any non-`/api` GET so deep links and reloads work.
- **Forms: react-hook-form + zod (`@hookform/resolvers`).** The zod `bookingSchema` lives in `shared/` and is used by the form resolver and by the API handler. Server-returned field errors (including the seat limit) are mapped onto the same fields with `setError`. `noValidate` is set on the form so our own messages are shown instead of native bubbles.
- **Styling: Tailwind CSS v4** (Vite plugin) with a small token set (wine/cream/slate palette, serif display font via system font stack, no external font requests) in `@theme`. Alternative: component library (MUI); rejected as it gives a generic look and a heavy bundle.
- **Domain module (`server/store.ts`)** owns tastings and bookings in memory. `book()` checks seats left and inserts in one synchronous step, which in single-threaded Node is atomic, so concurrent requests cannot overbook. Cancel removes the booking, so seats-left is always computed as `capacity - sum(guests)` rather than stored, which cannot drift.
- **API:**
  - `GET /api/tastings` → tastings with `seatsLeft`.
  - `POST /api/tastings/:id/bookings` → 201 booking, 400 `{errors:{field:msg}}` for invalid input, 409 `{errors:{guests:msg}}` when seats are insufficient (including fully booked), 404 unknown tasting.
  - `POST /api/staff/login`, `POST /api/staff/logout`, `GET /api/staff/session`, `GET /api/staff/bookings`, `DELETE /api/staff/bookings/:reference`.
- **Staff auth:** password compared with `crypto.timingSafeEqual` on SHA-256 digests against `STAFF_PASSWORD` (read at request time so tests can set it; empty or unset refuses everyone). Session via `cookie-session` (signed, `httpOnly`, `sameSite=strict`) with a random secret generated at startup, so a restart signs staff out. `express-rate-limit` on login (10 / 15 min / IP). POST endpoints require `application/json` and `DELETE` needs a preflighted cross-site request, which together with SameSite=Strict blocks cross-site forgery. API responses are `Cache-Control: no-store`. Only accepted bookings count against the booking rate limit.
- **Hardening:** `helmet` with a CSP that allows only self, JSON body limit 10 kB, `x-powered-by` disabled, errors never leak stack traces. A rate limit also guards the booking POST to blunt scripted seat-grabbing.
- **Booking reference:** `KB-` plus 6 characters from an unambiguous alphabet (no 0/O/1/I), drawn with `crypto.randomInt`, retried on collision.
- **Money:** integer euros in the domain, formatted as `EUR 25`; total = guests × price.
- **Dates:** kept as the local winery time strings `2026-11-06 18:00` and shown verbatim (plus weekday derived in UTC, so there is no timezone shift).
- **Build/run:** `npm run build` = `vite build` (client to `dist/client`) + `esbuild` bundle of the server to `dist/server/index.js` (dependencies external). `npm start` runs it. Dev: `npm run dev` runs Vite with an `/api` proxy and `tsx watch` for the server.
- **Tests:** Vitest for everything unit-level (store, API via supertest against the Express app factory, components via Testing Library in jsdom); Playwright for end-to-end flows against the built app, including 360 px viewport checks and axe accessibility scans.

## Risks / Trade-offs

- [Bookings lost on restart] → Accepted by the brief; the store sits behind a small interface so a file or database backend can replace it.
- [Anyone can hold seats] → Booking needs no verification (as briefed) and a few requests can fill a tasting; staff can cancel, and the booking rate limit slows scripts. Email confirmation or expiring holds would be the next step.
- [Stateless session] → Sign-out clears the cookie but a copied cookie stays valid until its 8 h expiry.
- [Single shared staff password] → Accepted by the brief; compare in constant time, rate limit, signed cookie, no password in client code.
- [Stale seats on the start page] → The server is the authority: every booking re-checks seats and returns a 409 the form shows next to "Guests"; the form also refetches seats on load.
- [No `secure` cookie flag] → The app is served over plain HTTP by `npm start`; behind a TLS proxy set `COOKIE_SECURE=true`. It is opt-in because a `secure` cookie would silently break sign-in over plain http. Proxy trust is a separate opt-in (`TRUST_PROXY=<hops>`, default off) so spoofed `X-Forwarded-For` headers cannot dodge the rate limits, and a proxy's address is not mistaken for every client's.
