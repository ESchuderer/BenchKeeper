# Proposal

## Why

Weingut Kieselbrunnen sells its wine tastings by phone and email. Guests cannot see how many seats are left, and staff cannot see at a glance who is coming. A small website where guests book a tasting themselves and staff see the guest list removes the back-and-forth and prevents overbooking.

## What Changes

- New public start page listing the three upcoming tastings with date and time, price per guest and seats left.
- New booking form per tasting (name, email, number of guests) with field-level validation and a hard guarantee that a tasting is never overbooked.
- New booking confirmation with a booking reference and total price.
- New password-protected staff page that lists bookings grouped by tasting and lets staff cancel a booking, which frees its seats.
- A coherent winery look and feel with explicit error, success and fully-booked states, usable on a phone.
- Bookings are held on the server (in memory); the app starts with none. No external services.

## Capabilities

### New Capabilities
- `tasting-catalog`: the offered tastings and the start page that lists them with live seat availability and fully-booked state.
- `tasting-booking`: the guest booking flow: form, validation, seat limit, confirmation.
- `staff-bookings`: staff sign-in with a shared password, the grouped booking overview, and cancelling bookings.
- `site-presentation`: cross-page visual design, responsive behaviour and accessibility of states.

### Modified Capabilities

(none, greenfield project)

## Impact

- New code: Express server, React single-page app, shared validation schema, tests.
- New dependencies: express, react, react-router, react-hook-form, zod, tailwindcss, vite, vitest, Playwright and supporting packages.
- Runtime configuration: `STAFF_PASSWORD` (required for staff sign-in), `PORT` (default 3000).
- Out of scope: online payment, emails to guests, guest-side cancellation, editing tastings, persistence across restarts, multiple staff accounts.
