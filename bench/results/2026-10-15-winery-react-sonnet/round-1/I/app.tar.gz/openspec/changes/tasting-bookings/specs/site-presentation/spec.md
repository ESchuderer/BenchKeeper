# Spec Delta

## Purpose

Ensures all pages look like one coherent winery website, work on a phone and communicate error, success and fully-booked states clearly and accessibly.

## ADDED Requirements

### Requirement: Coherent winery design
All pages SHALL share one visual design with the winery name "Weingut Kieselbrunnen" in the header, a consistent palette, typography and form styling, and a link back to the start page.

#### Scenario: Shared header
- **WHEN** a visitor opens the start page, a booking form or `/staff`
- **THEN** each shows the same header with "Weingut Kieselbrunnen"

### Requirement: Mobile usability
The pages SHALL be usable on a 360 px wide screen without horizontal scrolling, with touch targets of at least 44 px for buttons and links.

#### Scenario: Phone width
- **WHEN** any page is viewed at 360 px width
- **THEN** content fits the width and nothing requires horizontal scrolling

### Requirement: Clear states
Errors, success and fully-booked states SHALL be visually distinct and not rely on colour alone, and form errors SHALL be announced to assistive technology and linked to their field.

#### Scenario: Field error association
- **WHEN** a field has an error
- **THEN** the message sits next to the field, is marked invalid on the field and is announced to screen readers

#### Scenario: Not found
- **WHEN** a visitor opens an unknown URL or the booking form of an unknown tasting
- **THEN** a friendly "not found" page with a link to the start page is shown

#### Scenario: Server unreachable
- **WHEN** the tastings cannot be loaded
- **THEN** an error message with a retry option is shown instead of a blank page
