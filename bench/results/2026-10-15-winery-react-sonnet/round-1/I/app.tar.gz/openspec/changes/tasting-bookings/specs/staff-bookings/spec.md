# Spec Delta

## Purpose

Gives winery staff a password-protected view of all bookings grouped by tasting and the ability to cancel a booking to free its seats.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a "Password" and offer a "Sign in" button. Sign-in SHALL succeed only with the value of the environment variable `STAFF_PASSWORD`. If that variable is unset or empty, nobody can sign in.

#### Scenario: Sign-in prompt
- **WHEN** an unauthenticated visitor opens `/staff`
- **THEN** a "Password" field and a "Sign in" button are shown and no booking data

#### Scenario: Correct password
- **WHEN** the visitor enters the configured password and presses "Sign in"
- **THEN** the booking overview is shown

#### Scenario: Wrong password
- **WHEN** the visitor enters a wrong password
- **THEN** an error message is shown next to the password field and no booking data is revealed

#### Scenario: Password not configured
- **WHEN** `STAFF_PASSWORD` is unset and a visitor tries any password
- **THEN** sign-in is refused

### Requirement: Staff data is protected
The booking data and the cancel operation SHALL be available only to a signed-in staff member, and guessing the password SHALL be rate limited.

#### Scenario: Unauthenticated data request
- **WHEN** a request for all bookings or to cancel a booking arrives without a staff session
- **THEN** it is refused with status 401 and nothing changes

#### Scenario: Repeated wrong passwords
- **WHEN** many wrong passwords are submitted in a short time
- **THEN** further attempts are refused with status 429

### Requirement: Bookings grouped by tasting
A signed-in staff member SHALL see all bookings grouped by tasting, each with name, email, number of guests and booking reference. A tasting without bookings SHALL be shown with an empty note.

#### Scenario: Grouped overview
- **WHEN** bookings exist for two tastings and staff open the overview
- **THEN** each booking appears under its own tasting with name, email, guests and reference

#### Scenario: No bookings
- **WHEN** a tasting has no bookings
- **THEN** its group states that there are no bookings yet

### Requirement: Cancel a booking
Staff SHALL be able to cancel a booking with a "Cancel" button. The cancelled booking SHALL disappear from the overview and its seats SHALL become available again.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 4 guests for a tasting with 3 seats left
- **THEN** the booking is gone from the overview and the tasting has 7 seats left

#### Scenario: Cancel an already cancelled booking
- **WHEN** a booking was cancelled elsewhere and staff cancel it again
- **THEN** the overview refreshes without that booking and an error message explains it no longer exists

### Requirement: Sign out
A signed-in staff member SHALL be able to sign out, after which the sign-in prompt is shown again.

#### Scenario: Sign out
- **WHEN** staff press "Sign out"
- **THEN** the sign-in prompt is shown and booking data requests are refused
