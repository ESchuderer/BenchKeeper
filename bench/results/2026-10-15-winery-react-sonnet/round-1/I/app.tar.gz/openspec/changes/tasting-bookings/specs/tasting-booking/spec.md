# Spec Delta

## Purpose

Lets a guest reserve seats for a tasting online, guaranteeing that a tasting is never overbooked and that invalid input is explained next to the field it concerns.

## ADDED Requirements

### Requirement: Booking form
The booking form of a tasting SHALL show the tasting it is for and the fields "Name", "Email" and "Guests" (a whole number from 1 to 8) and a "Book" button.

#### Scenario: Form contents
- **WHEN** a guest opens the booking form for "Winter Tasting"
- **THEN** the page names "Winter Tasting" and shows fields labelled "Name", "Email" and "Guests" and a button "Book"

### Requirement: Input validation
The system SHALL reject a booking whose name is blank, whose email is not a valid address, or whose guests is not a whole number from 1 to 8, and SHALL show an error message next to the field concerned, both in the browser and on the server.

#### Scenario: Blank name
- **WHEN** a guest submits with an empty "Name"
- **THEN** no booking is made and an error message appears next to "Name"

#### Scenario: Invalid email
- **WHEN** a guest submits with "Email" set to "not-an-email"
- **THEN** no booking is made and an error message appears next to "Email"

#### Scenario: Guests out of range
- **WHEN** a guest submits with "Guests" set to 0, 9, 2.5 or text
- **THEN** no booking is made and an error message appears next to "Guests"

#### Scenario: Direct API call with invalid data
- **WHEN** a request that bypasses the form submits invalid data
- **THEN** the server rejects it with per-field error messages and creates no booking

### Requirement: Seat limit
A booking SHALL NOT take more seats than are left for the tasting. This SHALL hold even when several guests book at the same time.

#### Scenario: More guests than seats left
- **WHEN** 2 seats are left and a guest books 3
- **THEN** the booking is rejected with an error message next to "Guests" saying only 2 seats are left, and the seats left stay 2

#### Scenario: Exactly the seats left
- **WHEN** 2 seats are left and a guest books 2
- **THEN** the booking succeeds and the tasting becomes fully booked

#### Scenario: Concurrent bookings
- **WHEN** two bookings of 5 guests arrive at once for a tasting with 8 seats left
- **THEN** exactly one succeeds and the other is rejected

### Requirement: Booking confirmation
After a successful booking the system SHALL show a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (guests times price per guest) and a unique booking reference.

#### Scenario: Confirmation content
- **WHEN** a guest books 3 places for "Riesling Evening"
- **THEN** the page shows "Booking confirmed", "Riesling Evening", 3 guests, a total of "EUR 75" and a booking reference

#### Scenario: References are unique
- **WHEN** two bookings are made
- **THEN** their booking references differ

#### Scenario: Seats are taken
- **WHEN** a booking is confirmed
- **THEN** the seats left of that tasting drop by the number of guests
