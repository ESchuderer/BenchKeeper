# Spec Delta

## Purpose

Defines which tastings the winery offers and how the start page presents them to guests, including live seat availability and the fully-booked state.

## ADDED Requirements

### Requirement: Offered tastings
The system SHALL offer exactly these tastings: "Riesling Evening" on 2026-11-06 at 18:00 for EUR 25 per guest with 12 seats, "Red Wine Cellar Tour" on 2026-11-14 at 15:00 for EUR 32 with 8 seats, and "Winter Tasting" on 2026-12-05 at 17:00 for EUR 28 with 10 seats.

#### Scenario: Fresh start
- **WHEN** the application starts
- **THEN** the three tastings are offered with all of their seats free and no bookings exist

### Requirement: Start page lists tastings
The start page SHALL list every tasting with its title, date and time, price per guest and the seats left, written as "<n> seats left".

#### Scenario: Initial listing
- **WHEN** a guest opens the start page on a fresh system
- **THEN** "Riesling Evening" shows "12 seats left" and "EUR 25", "Red Wine Cellar Tour" shows "8 seats left" and "EUR 32", and "Winter Tasting" shows "10 seats left" and "EUR 28"

#### Scenario: Seats reflect bookings
- **WHEN** 3 guests have booked "Riesling Evening"
- **THEN** the start page shows "9 seats left" for it

#### Scenario: Seats reflect cancellations
- **WHEN** staff cancel a booking of 3 guests for "Riesling Evening"
- **THEN** the start page shows 3 more seats left for it

### Requirement: Book link per tasting
Each tasting with seats left SHALL have a link named "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open booking form
- **WHEN** a guest follows "Book Riesling Evening"
- **THEN** the booking form for "Riesling Evening" opens

### Requirement: Fully booked tastings
A tasting with no seats left SHALL be marked "Fully booked" on the start page and SHALL NOT offer a booking link.

#### Scenario: Last seats taken
- **WHEN** all 8 seats of "Red Wine Cellar Tour" are booked
- **THEN** the start page shows "Fully booked" and "0 seats left" for it and no "Book Red Wine Cellar Tour" link

#### Scenario: Direct visit to a sold-out form
- **WHEN** a guest opens the booking form URL of a fully booked tasting
- **THEN** the page says the tasting is fully booked and offers no form
