# Tasks

## 1. Project scaffold

- [x] 1.1 Create `package.json` (Node 22, scripts `dev`, `build`, `start`, `test`, `test:e2e`, `lint`, `typecheck`), TypeScript, Vite, Tailwind, Vitest config and install dependencies; verify `npm install` and `npm run typecheck` succeed on the empty skeleton.
- [x] 1.2 Write `CONSTRAINTS.md` with the quality bar (tests, accessibility, no suppressions) and `.gitignore`; verify files exist and `node_modules`/`dist` are ignored.

## 2. Domain and shared validation (tests first)

- [x] 2.1 Write failing tests for `bookingSchema` (name, email, guests 1..8, whole numbers) then implement `shared/booking.ts`; verify `npm test -- shared` passes.
- [x] 2.2 Write failing tests for the store (seed tastings, seats left, book, overbooking, exact fill, unique references, cancel frees seats, cancel unknown) then implement `server/store.ts`; verify `npm test -- store` passes.

## 3. HTTP API (tests first)

- [x] 3.1 Write failing supertest tests for `GET /api/tastings` and `POST /api/tastings/:id/bookings` (201, 400 field errors, 409 seat limit, 404, concurrent bookings) then implement the Express app factory; verify they pass.
- [x] 3.2 Write failing tests for staff login/logout/session/bookings/cancel (correct, wrong and unset password, 401 without session, 429 rate limit, cancel frees seats, double cancel 404) then implement; verify they pass.
- [x] 3.3 Add static serving with SPA fallback, helmet, `PORT` handling and the `server/index.ts` entry; verify `npm run build && npm start` serves `/api/tastings` and `/` and `/staff` return the HTML shell.

## 4. Guest interface (tests first)

- [x] 4.1 Add layout, theme tokens, router, API client and not-found/error states; verify component tests for header, not-found and load-error with retry pass.
- [x] 4.2 Write failing component tests for the start page (listing text, "<n> seats left", "Book <title>" links, "Fully booked" with no link) then implement; verify they pass.
- [x] 4.3 Write failing component tests for the booking form (labels, client validation messages next to fields, server 409/400 mapped to fields, confirmation with heading, tasting, guests, total, reference, sold-out visit) then implement; verify they pass.

## 5. Staff interface (tests first)

- [x] 5.1 Write failing component tests for `/staff` (sign-in form, wrong password error, grouped bookings, empty group note, "Cancel" updates list, sign out) then implement; verify they pass.

## 6. Polish and end-to-end verification

- [x] 6.1 Add Playwright end-to-end tests for the guest flow, overbooking at the UI, staff flow incl. cancel freeing seats, 360 px no horizontal scroll, and axe checks on all pages; verify `npm run test:e2e` passes against the built app.
- [x] 6.2 Review the result with the code-review, security and test agents, fix findings, document usage in `README.md`; verify `npm run lint`, `typecheck`, `test`, `build` all pass from a clean `npm ci`.
