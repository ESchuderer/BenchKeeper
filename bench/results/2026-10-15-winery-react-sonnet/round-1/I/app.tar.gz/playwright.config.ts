import { defineConfig, devices } from '@playwright/test';

const PORT = 3100;

export default defineConfig({
  testDir: 'e2e',
  fullyParallel: false,
  workers: 1,
  reporter: [['list']],
  use: { baseURL: `http://localhost:${PORT}`, trace: 'retain-on-failure' },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'phone', use: { ...devices['Pixel 5'], viewport: { width: 360, height: 740 } } },
  ],
  webServer: {
    command: 'npm run build && npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-password' },
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
