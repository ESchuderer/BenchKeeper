import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { join } from 'node:path';
import express, { type ErrorRequestHandler, type NextFunction, type Request, type Response } from 'express';
import cookieSession from 'cookie-session';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { bookingSchema, type FieldErrors } from '../shared/booking';
import { createStore, type Store } from './store';

export interface AppOptions {
  store?: Store;
  /** Read per request so the password can be changed without rebuilding the app. */
  staffPassword?: () => string | undefined;
  /** Directory with the built client; when set, it is served with an SPA fallback. */
  clientDir?: string;
  /** Failed staff sign-ins allowed per 15 minutes per client. */
  loginRateLimit?: number;
  /**
   * Number of reverse proxies in front of the app whose X-Forwarded-For is trusted. Off (0) by
   * default: trusting the header without a proxy lets clients spoof their address and dodge rate limits.
   */
  trustProxy?: number;
  /** Bookings accepted per 10 minutes per client (rejected requests are not counted). */
  bookingRateLimit?: number;
}

const sha256 = (value: string) => createHash('sha256').update(value).digest();

function passwordMatches(candidate: unknown, configured: string | undefined): boolean {
  if (!configured || typeof candidate !== 'string') return false;
  // Hashing first gives equal-length buffers, so the comparison is constant time for any input.
  return timingSafeEqual(sha256(candidate), sha256(configured));
}

function requireJson(req: Request, res: Response, next: NextFunction) {
  if (req.method === 'POST' && !req.is('application/json')) {
    res.status(415).json({ error: 'Send the request as application/json.' });
    return;
  }
  next();
}

export function createApp(options: AppOptions = {}) {
  const store = options.store ?? createStore();
  const staffPassword = options.staffPassword ?? (() => process.env.STAFF_PASSWORD);
  // Opt-in: `secure` cookies are never sent back over plain http, which is how `npm start` serves.
  const secureCookie = process.env.COOKIE_SECURE === 'true';
  const trustProxy = options.trustProxy ?? 0;

  const app = express();
  app.disable('x-powered-by');
  if (trustProxy > 0) app.set('trust proxy', trustProxy);

  app.use(helmet({ contentSecurityPolicy: { directives: { upgradeInsecureRequests: null } } }));
  app.use(
    cookieSession({
      name: 'session',
      keys: [randomBytes(32).toString('hex')],
      maxAge: 8 * 60 * 60 * 1000,
      httpOnly: true,
      sameSite: 'strict',
      secure: secureCookie,
    }),
  );

  const api = express.Router();
  // Booking data and seat counts must never come from a cache.
  api.use((_req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });
  api.use(requireJson);
  api.use(express.json({ limit: '10kb' }));

  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: options.loginRateLimit ?? 10,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many attempts. Please wait a few minutes and try again.' },
  });
  const bookingLimiter = rateLimit({
    windowMs: 10 * 60 * 1000,
    limit: options.bookingRateLimit ?? 60,
    skipFailedRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many bookings in a short time. Please try again in a few minutes.' },
  });

  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    if (req.session?.staff !== true) {
      res.status(401).json({ error: 'Please sign in as staff.' });
      return;
    }
    next();
  };

  api.get('/tastings', (_req, res) => {
    res.json({ tastings: store.listTastings() });
  });

  api.get('/tastings/:id', (req, res) => {
    const tasting = store.getTasting(String(req.params.id));
    if (!tasting) {
      res.status(404).json({ error: 'We could not find that tasting.' });
      return;
    }
    res.json({ tasting });
  });

  api.post('/tastings/:id/bookings', bookingLimiter, (req, res) => {
    if (!store.getTasting(String(req.params.id))) {
      res.status(404).json({ error: 'We could not find that tasting.' });
      return;
    }
    const parsed = bookingSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
      const errors: FieldErrors = {};
      for (const issue of parsed.error.issues) {
        const field = issue.path[0];
        if (field === 'name' || field === 'email' || field === 'guests') errors[field] ??= issue.message;
      }
      if (Object.keys(errors).length === 0) {
        res.status(400).json({ error: 'Please send the booking as a JSON object with name, email and guests.' });
        return;
      }
      res.status(400).json({ errors });
      return;
    }
    const result = store.book(String(req.params.id), parsed.data);
    if (!result.ok) {
      if (result.reason === 'unknown-tasting') {
        res.status(404).json({ error: 'We could not find that tasting.' });
        return;
      }
      const message =
        result.seatsLeft === 0
          ? 'Sorry, this tasting is fully booked.'
          : `Only ${result.seatsLeft} ${result.seatsLeft === 1 ? 'seat is' : 'seats are'} left for this tasting.`;
      res.status(409).json({ errors: { guests: message }, seatsLeft: result.seatsLeft });
      return;
    }
    const tasting = store.getTasting(result.booking.tastingId)!;
    res.status(201).json({ booking: { ...result.booking, tastingTitle: tasting.title, startsAt: tasting.startsAt } });
  });

  api.get('/staff/session', (req, res) => {
    res.json({ signedIn: req.session?.staff === true });
  });

  api.post('/staff/login', loginLimiter, (req, res) => {
    if (!passwordMatches(req.body?.password, staffPassword())) {
      res.status(401).json({ errors: { password: 'That password is not correct.' } });
      return;
    }
    req.session = { staff: true };
    res.json({ signedIn: true });
  });

  api.post('/staff/logout', (req, res) => {
    req.session = null;
    res.json({ signedIn: false });
  });

  api.get('/staff/bookings', requireStaff, (_req, res) => {
    const bookings = store.listBookings();
    res.json({
      tastings: store.listTastings().map((tasting) => ({
        ...tasting,
        bookings: bookings.filter((b) => b.tastingId === tasting.id),
      })),
    });
  });

  api.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(String(req.params.reference))) {
      res.status(404).json({ error: 'That booking no longer exists. It may already have been cancelled.' });
      return;
    }
    res.status(204).end();
  });

  api.use((_req, res) => {
    res.status(404).json({ error: 'Not found.' });
  });

  app.use('/api', api);

  if (options.clientDir) {
    const dir = options.clientDir;
    app.use('/assets', express.static(join(dir, 'assets'), { immutable: true, maxAge: '1y', fallthrough: false }));
    app.use(express.static(dir, { index: false }));
    app.get('/{*path}', (_req, res) => {
      res.sendFile(join(dir, 'index.html'));
    });
  }

  const onError: ErrorRequestHandler = (err, _req, res, _next) => {
    const status = typeof err?.status === 'number' && err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 500 ? 'Something went wrong on our side.' : 'Invalid request.' });
  };
  app.use(onError);

  return app;
}

declare module 'express-serve-static-core' {
  interface Request {
    session?: { staff?: boolean } | null;
  }
}
