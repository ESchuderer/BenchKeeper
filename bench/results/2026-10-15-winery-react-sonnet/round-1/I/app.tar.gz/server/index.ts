import { fileURLToPath } from 'node:url';
import { createApp } from './app';

const port = Number(process.env.PORT) || 3000;

if (!process.env.STAFF_PASSWORD) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

const app = createApp({
  trustProxy: Number(process.env.TRUST_PROXY) || 0,
  clientDir: fileURLToPath(new URL('../client', import.meta.url)),
});

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings listening on http://localhost:${port}`);
});
