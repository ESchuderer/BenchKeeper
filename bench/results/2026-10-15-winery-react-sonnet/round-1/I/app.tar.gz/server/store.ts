import { randomInt } from 'node:crypto';
import { formatEuro, type Booking, type BookingInput, type Tasting } from '../shared/booking';

export { formatEuro };

type TastingDef = Omit<Tasting, 'seatsLeft'>;

const TASTINGS: readonly TastingDef[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06 18:00', priceEur: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14 15:00', priceEur: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05 17:00', priceEur: 28, seats: 10 },
];

// No 0/O/1/I so references can be read out over the phone.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: 'unknown-tasting' }
  | { ok: false; reason: 'insufficient-seats'; seatsLeft: number };

export interface Store {
  listTastings(): Tasting[];
  getTasting(id: string): Tasting | undefined;
  listBookings(): Booking[];
  book(tastingId: string, input: BookingInput): BookResult;
  cancel(reference: string): boolean;
}

export function createStore(): Store {
  const bookings = new Map<string, Booking>();

  const withSeatsLeft = (def: TastingDef): Tasting => {
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === def.id) taken += b.guests;
    return { ...def, seatsLeft: def.seats - taken };
  };

  const newReference = (): string => {
    for (;;) {
      let code = '';
      for (let i = 0; i < 6; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
      const reference = `KB-${code}`;
      if (!bookings.has(reference)) return reference;
    }
  };

  return {
    listTastings: () => TASTINGS.map(withSeatsLeft),
    getTasting: (id) => {
      const def = TASTINGS.find((t) => t.id === id);
      return def && withSeatsLeft(def);
    },
    listBookings: () => [...bookings.values()],
    // Check and insert happen in one synchronous step, so concurrent requests cannot overbook.
    book(tastingId, input) {
      const def = TASTINGS.find((t) => t.id === tastingId);
      if (!def) return { ok: false, reason: 'unknown-tasting' };
      const { seatsLeft } = withSeatsLeft(def);
      if (input.guests > seatsLeft) return { ok: false, reason: 'insufficient-seats', seatsLeft };
      const booking: Booking = {
        reference: newReference(),
        tastingId,
        name: input.name,
        email: input.email,
        guests: input.guests,
        totalEur: input.guests * def.priceEur,
      };
      bookings.set(booking.reference, booking);
      return { ok: true, booking };
    },
    cancel: (reference) => bookings.delete(reference),
  };
}
