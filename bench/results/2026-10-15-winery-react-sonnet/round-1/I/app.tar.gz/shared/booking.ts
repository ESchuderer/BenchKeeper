import { z } from 'zod';

export const MAX_GUESTS = 8;

const guestsSchema = z.preprocess(
  (value) => (typeof value === 'string' && /^\s*\d+\s*$/.test(value) ? Number(value) : value),
  z
    .number({ message: 'Enter the number of guests as a whole number.' })
    .int('Enter the number of guests as a whole number.')
    .min(1, 'Book at least 1 guest.')
    .max(MAX_GUESTS, `You can book up to ${MAX_GUESTS} guests at a time.`),
);

export const bookingSchema = z.object({
  name: z
    .string({ message: 'Please enter your name.' })
    .trim()
    .min(1, 'Please enter your name.')
    .max(100, 'Please keep your name under 100 characters.'),
  email: z
    .string({ message: 'Please enter your email address.' })
    .trim()
    .min(1, 'Please enter your email address.')
    .max(254, 'This email address is too long.')
    .email('Please enter a valid email address, for example name@example.com.'),
  guests: guestsSchema,
});

export type BookingInput = z.infer<typeof bookingSchema>;
export type BookingField = keyof BookingInput;

export function formatEuro(amount: number): string {
  return `EUR ${amount}`;
}

export interface Tasting {
  id: string;
  title: string;
  /** Local winery time, "YYYY-MM-DD HH:mm". */
  startsAt: string;
  priceEur: number;
  seats: number;
  seatsLeft: number;
}

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  totalEur: number;
}

export type FieldErrors = Partial<Record<BookingField, string>>;
