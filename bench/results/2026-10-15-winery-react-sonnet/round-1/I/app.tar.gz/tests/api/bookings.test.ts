import request from 'supertest';
import { makeApp, guest } from './helpers';

describe('GET /api/tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const res = await request(makeApp()).get('/api/tastings').expect(200);
    expect(res.body.tastings).toHaveLength(3);
    expect(res.body.tastings[0]).toEqual({
      id: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06 18:00',
      priceEur: 25,
      seats: 12,
      seatsLeft: 12,
    });
  });
});

describe('GET /api/tastings/:id', () => {
  it('returns one tasting', async () => {
    const res = await request(makeApp()).get('/api/tastings/winter-tasting').expect(200);
    expect(res.body.tasting.title).toBe('Winter Tasting');
  });
  it('404s for an unknown tasting', async () => {
    await request(makeApp()).get('/api/tastings/nope').expect(404);
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and returns the confirmation data', async () => {
    const app = makeApp();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guest, guests: 3 }).expect(201);
    expect(res.body.booking).toMatchObject({
      tastingId: 'riesling-evening',
      tastingTitle: 'Riesling Evening',
      guests: 3,
      totalEur: 75,
      name: guest.name,
    });
    expect(res.body.booking.reference).toMatch(/^KB-/);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[0].seatsLeft).toBe(9);
  });

  it('rejects invalid input with per-field messages and books nothing', async () => {
    const app = makeApp();
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .send({ name: ' ', email: 'nope', guests: 0 })
      .expect(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[0].seatsLeft).toBe(12);
  });

  it.each([9, 2.5, 'abc'])('rejects guests=%j', async (guests) => {
    const res = await request(makeApp()).post('/api/tastings/riesling-evening/bookings').send({ ...guest, guests }).expect(400);
    expect(res.body.errors.guests).toBeTruthy();
  });

  it('rejects a missing body with field errors', async () => {
    const res = await request(makeApp()).post('/api/tastings/riesling-evening/bookings').send({}).expect(400);
    expect(res.body.errors.name).toBeTruthy();
  });

  it('refuses non-JSON content with 415', async () => {
    await request(makeApp())
      .post('/api/tastings/riesling-evening/bookings')
      .type('form')
      .send('name=Anna&email=anna@example.com&guests=1')
      .expect(415);
  });

  it('rejects malformed JSON with 400', async () => {
    await request(makeApp())
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{not json')
      .expect(400);
  });

  it('404s for an unknown tasting', async () => {
    await request(makeApp()).post('/api/tastings/nope/bookings').send(guest).expect(404);
  });

  it('never takes more seats than are left (409 on the guests field)', async () => {
    const app = makeApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 6 }).expect(201);
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 3 }).expect(409);
    expect(res.body.errors.guests).toMatch(/only 2 seats/i);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[1].seatsLeft).toBe(2);
  });

  it('says fully booked when no seats are left', async () => {
    const app = makeApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 8 }).expect(201);
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 1 }).expect(409);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });

  it('lets exactly one of two simultaneous bookings win', async () => {
    const app = makeApp();
    const post = () =>
      request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 5 }).then((r) => r.status);
    const statuses = (await Promise.all([post(), post()])).sort();
    expect(statuses).toEqual([201, 409]);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[1].seatsLeft).toBe(3);
  });

  it('rate limits scripted booking floods', async () => {
    const app = makeApp({ bookingRateLimit: 3 });
    const codes: number[] = [];
    for (let i = 0; i < 5; i++) {
      codes.push((await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 1 })).status);
    }
    expect(codes).toEqual([201, 201, 201, 429, 429]);
  });
});

describe('app shell', () => {
  it('sets security headers and hides express', async () => {
    const res = await request(makeApp()).get('/api/tastings');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['content-security-policy']).toContain("default-src 'self'");
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });
  it('404s unknown API routes as JSON', async () => {
    const res = await request(makeApp()).get('/api/nothing').expect(404);
    expect(res.body.error).toBeTruthy();
  });
});

describe('malformed bodies', () => {
  it.each([[[]], ['"text"'], [null]])('answers a non-object JSON body %j with a general error, not a bogus field', async (body) => {
    const res = await request(makeApp())
      .post('/api/tastings/winter-tasting/bookings')
      .set('Content-Type', 'application/json')
      .send(JSON.stringify(body))
      .expect(400);
    expect(res.body.errors).toBeUndefined();
    expect(res.body.error).toBeTruthy();
  });

  it('answers an unknown tasting with 404 even when the body is invalid', async () => {
    await request(makeApp()).post('/api/tastings/nope/bookings').send({ name: '' }).expect(404);
  });
});
