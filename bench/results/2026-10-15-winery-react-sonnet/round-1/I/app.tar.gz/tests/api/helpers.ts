import request from 'supertest';
import { createApp, type AppOptions } from '../../server/app';

export const PASSWORD = 'correct horse';

export function makeApp(options: AppOptions = {}) {
  return createApp({ staffPassword: () => PASSWORD, ...options });
}

export async function signedInAgent(app = makeApp()) {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(200);
  return { agent, app };
}

export const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };
