import request from 'supertest';
import { makeApp, signedInAgent, guest, PASSWORD } from './helpers';

describe('staff sign-in', () => {
  it('accepts the configured password and opens a session', async () => {
    const app = makeApp();
    const agent = request.agent(app);
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: false });
    const res = await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(200);
    expect([res.headers['set-cookie']].flat().join(';')).toMatch(/httponly/i);
    expect([res.headers['set-cookie']].flat().join(';')).toMatch(/samesite=strict/i);
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: true });
  });

  it('rejects a wrong password with an error for the password field', async () => {
    const res = await request(makeApp()).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    expect(res.body.errors.password).toBeTruthy();
  });

  it('rejects a missing password', async () => {
    await request(makeApp()).post('/api/staff/login').send({}).expect(401);
  });

  it('rejects a password that merely starts with the right one', async () => {
    await request(makeApp()).post('/api/staff/login').send({ password: PASSWORD + 'x' }).expect(401);
  });

  it.each([undefined, ''])('refuses everyone when STAFF_PASSWORD is %j', async (configured) => {
    const app = makeApp({ staffPassword: () => configured });
    await request(app).post('/api/staff/login').send({ password: '' }).expect(401);
    await request(app).post('/api/staff/login').send({ password: 'anything' }).expect(401);
    await request(app).post('/api/staff/login').send({}).expect(401);
  });

  it('rate limits password guessing', async () => {
    const app = makeApp({ loginRateLimit: 3 });
    const codes: number[] = [];
    for (let i = 0; i < 5; i++) codes.push((await request(app).post('/api/staff/login').send({ password: 'x' })).status);
    expect(codes).toEqual([401, 401, 401, 429, 429]);
    // even the right password is refused while limited
    await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(429);
  });

  it('ends the session on sign out', async () => {
    const { agent } = await signedInAgent();
    await agent.post('/api/staff/logout').send({}).expect(200);
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: false });
    await agent.get('/api/staff/bookings').expect(401);
  });
});

describe('staff data is protected', () => {
  it('refuses listing and cancelling without a session and changes nothing', async () => {
    const app = makeApp();
    const booked = await request(app).post('/api/tastings/winter-tasting/bookings').send(guest);
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete(`/api/staff/bookings/${booked.body.booking.reference}`).expect(401);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[2].seatsLeft).toBe(8);
  });

  it('does not accept a forged session cookie', async () => {
    const res = await request(makeApp())
      .get('/api/staff/bookings')
      .set('Cookie', ['session=eyJzdGFmZiI6dHJ1ZX0=; session.sig=forged']);
    expect(res.status).toBe(401);
  });
});

describe('staff bookings overview and cancel', () => {
  it('groups bookings by tasting and lists empty tastings', async () => {
    const { agent, app } = await signedInAgent();
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, name: 'Ben' });
    await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guest, name: 'Clara', guests: 4 });
    const res = await agent.get('/api/staff/bookings').expect(200);
    const groups = res.body.tastings;
    expect(groups.map((g: { id: string }) => g.id)).toEqual(['riesling-evening', 'red-wine-cellar-tour', 'winter-tasting']);
    expect(groups[0].bookings).toHaveLength(1);
    expect(groups[0].bookings[0]).toMatchObject({ name: 'Clara', email: guest.email, guests: 4 });
    expect(groups[0].bookings[0].reference).toMatch(/^KB-/);
    expect(groups[1].bookings).toEqual([]);
    expect(groups[2].bookings[0].name).toBe('Ben');
  });

  it('cancel removes the booking and frees its seats', async () => {
    const { agent, app } = await signedInAgent();
    const booked = await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, guests: 4 });
    await agent.delete(`/api/staff/bookings/${booked.body.booking.reference}`).expect(204);
    const list = await request(app).get('/api/tastings');
    expect(list.body.tastings[2].seatsLeft).toBe(10);
    const overview = await agent.get('/api/staff/bookings');
    expect(overview.body.tastings[2].bookings).toEqual([]);
  });

  it('cancelling twice or an unknown reference gives 404', async () => {
    const { agent, app } = await signedInAgent();
    const booked = await request(app).post('/api/tastings/winter-tasting/bookings').send(guest);
    const ref = booked.body.booking.reference;
    await agent.delete(`/api/staff/bookings/${ref}`).expect(204);
    const again = await agent.delete(`/api/staff/bookings/${ref}`).expect(404);
    expect(again.body.error).toBeTruthy();
    await agent.delete('/api/staff/bookings/KB-NOPE').expect(404);
  });

  it('a cancelled booking lets the tasting be fully booked again', async () => {
    const { agent, app } = await signedInAgent();
    const full = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 8 });
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send(guest).expect(409);
    await agent.delete(`/api/staff/bookings/${full.body.booking.reference}`).expect(204);
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send(guest).expect(201);
  });
});

describe('rate limiting and client identity', () => {
  const attempt = (app: ReturnType<typeof makeApp>, ip: string) =>
    request(app).post('/api/staff/login').set('X-Forwarded-For', ip).send({ password: 'x' }).then((r) => r.status);

  it('ignores X-Forwarded-For by default, so spoofed addresses cannot dodge the limit', async () => {
    const app = makeApp({ loginRateLimit: 2 });
    const codes = [];
    for (let i = 1; i <= 4; i++) codes.push(await attempt(app, `9.9.9.${i}`));
    expect(codes).toEqual([401, 401, 429, 429]);
  });

  it('uses the forwarded client address when a proxy is trusted', async () => {
    const app = makeApp({ loginRateLimit: 2, trustProxy: 1 });
    expect(await attempt(app, '9.9.9.1')).toBe(401);
    expect(await attempt(app, '9.9.9.1')).toBe(401);
    expect(await attempt(app, '9.9.9.1')).toBe(429);
    expect(await attempt(app, '9.9.9.2')).toBe(401);
  });
});

describe('caching', () => {
  it('forbids caching of staff data and other API responses', async () => {
    const { agent } = await signedInAgent();
    expect((await agent.get('/api/staff/bookings')).headers['cache-control']).toMatch(/no-store/);
    expect((await agent.get('/api/tastings')).headers['cache-control']).toMatch(/no-store/);
  });
});
