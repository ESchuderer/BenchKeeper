import { mkdtempSync, writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { makeApp } from './helpers';

describe('static client', () => {
  const dir = mkdtempSync(join(tmpdir(), 'kb-client-'));
  mkdirSync(join(dir, 'assets'));
  writeFileSync(join(dir, 'index.html'), '<!doctype html><title>shell</title>');
  writeFileSync(join(dir, 'assets', 'app.js'), 'console.log(1)');
  const app = makeApp({ clientDir: dir });

  it.each(['/', '/staff', '/tastings/riesling-evening/book', '/whatever'])('serves the HTML shell at %s', async (path) => {
    const res = await request(app).get(path).expect(200);
    expect(res.text).toContain('<title>shell</title>');
  });

  it('serves assets', async () => {
    const res = await request(app).get('/assets/app.js').expect(200);
    expect(res.text).toBe('console.log(1)');
  });

  it('does not turn missing API routes into the HTML shell', async () => {
    const res = await request(app).get('/api/nothing').expect(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
});
