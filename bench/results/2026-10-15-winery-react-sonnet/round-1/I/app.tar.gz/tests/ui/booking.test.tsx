// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import { installFakeApi } from './fakeApi';
import { renderApp } from './render';

afterEach(() => vi.unstubAllGlobals());

const field = (name: string) => screen.getByLabelText(name);

async function openForm(path = '/tastings/riesling-evening/book') {
  const ctx = renderApp(path);
  await screen.findByRole('button', { name: 'Book' });
  return ctx;
}

describe('booking form', () => {
  it('opens from the start page and names the tasting', async () => {
    installFakeApi();
    const { user } = renderApp('/');
    await user.click(await screen.findByRole('link', { name: 'Book Riesling Evening' }));
    expect(await screen.findByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument();
    expect(screen.getByText('2026-11-06 18:00')).toBeInTheDocument();
  });

  it('has Name, Email and Guests fields and a Book button', async () => {
    installFakeApi();
    await openForm('/tastings/winter-tasting/book');
    expect(screen.getByRole('heading', { name: /Winter Tasting/ })).toBeInTheDocument();
    expect(field('Name')).toBeInTheDocument();
    expect(field('Email')).toHaveAttribute('type', 'email');
    expect(field('Guests')).toHaveAttribute('min', '1');
    expect(field('Guests')).toHaveAttribute('max', '8');
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
  });

  it('limits the Guests input to the seats left', async () => {
    const { store } = installFakeApi();
    store.book('red-wine-cellar-tour', { name: 'A', email: 'a@example.com', guests: 6 });
    await openForm('/tastings/red-wine-cellar-tour/book');
    expect(field('Guests')).toHaveAttribute('max', '2');
  });

  it('shows errors next to the empty Name and Email fields and books nothing', async () => {
    const { store } = installFakeApi();
    const { user } = await openForm();
    await user.click(screen.getByRole('button', { name: 'Book' }));
    const name = field('Name');
    const email = field('Email');
    expect(name).toHaveAttribute('aria-invalid', 'true');
    expect(email).toHaveAttribute('aria-invalid', 'true');
    expect(name).toHaveAccessibleDescription(/enter your name/i);
    expect(email).toHaveAccessibleDescription(/email/i);
    expect(store.listBookings()).toHaveLength(0);
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
  });

  it('shows an error next to Email for a malformed address', async () => {
    installFakeApi();
    const { user } = await openForm();
    await user.type(field('Name'), 'Anna');
    await user.type(field('Email'), 'not-an-email');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(field('Email')).toHaveAccessibleDescription(/valid email/i);
    expect(field('Name')).not.toHaveAttribute('aria-invalid', 'true');
  });

  it.each(['0', '9', '2.5'])('shows an error next to Guests for %s', async (value) => {
    const { store } = installFakeApi();
    const { user } = await openForm();
    await user.type(field('Name'), 'Anna');
    await user.type(field('Email'), 'anna@example.com');
    await user.clear(field('Guests'));
    await user.type(field('Guests'), value);
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(field('Guests')).toHaveAttribute('aria-invalid', 'true');
    expect(field('Guests')).toHaveAccessibleDescription(/.+/);
    expect(store.listBookings()).toHaveLength(0);
  });

  it('shows an error next to Guests when more guests than seats left are requested', async () => {
    const { store } = installFakeApi();
    store.book('red-wine-cellar-tour', { name: 'A', email: 'a@example.com', guests: 6 });
    const { user } = await openForm('/tastings/red-wine-cellar-tour/book');
    await user.type(field('Name'), 'Anna');
    await user.type(field('Email'), 'anna@example.com');
    await user.clear(field('Guests'));
    await user.type(field('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(field('Guests')).toHaveAccessibleDescription(/only 2 seats/i);
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(2);
  });

  it('shows the server seat-limit error next to Guests when seats ran out meanwhile', async () => {
    const { store } = installFakeApi();
    const { user } = await openForm('/tastings/red-wine-cellar-tour/book');
    store.book('red-wine-cellar-tour', { name: 'Other', email: 'o@example.com', guests: 7 });
    await user.type(field('Name'), 'Anna');
    await user.type(field('Email'), 'anna@example.com');
    await user.clear(field('Guests'));
    await user.type(field('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText(/Only 1 seats are left/)).toBeInTheDocument();
    expect(field('Guests')).toHaveAccessibleDescription(/Only 1 seats are left/);
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(1);
  });

  it('confirms a booking with tasting, guests, total and reference', async () => {
    const { store } = installFakeApi();
    const { user } = await openForm();
    await user.type(field('Name'), 'Anna Weber');
    await user.type(field('Email'), 'anna@example.com');
    await user.clear(field('Guests'));
    await user.type(field('Guests'), '3');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const [booking] = store.listBookings();
    expect(booking).toMatchObject({ name: 'Anna Weber', guests: 3, totalEur: 75 });
    const summary = screen.getByRole('region', { name: 'Booking confirmed' });
    expect(within(summary).getByText('Riesling Evening')).toBeInTheDocument();
    expect(within(summary).getByText('3')).toBeInTheDocument();
    expect(within(summary).getByText('EUR 75')).toBeInTheDocument();
    expect(within(summary).getByText(booking!.reference)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: /back to the tastings/i })).toBeInTheDocument();
  });

  it('disables the button while the booking is being sent so it cannot be double submitted', async () => {
    const { store } = installFakeApi();
    const { user } = await openForm();
    await user.type(field('Name'), 'Anna');
    await user.type(field('Email'), 'anna@example.com');
    const button = screen.getByRole('button', { name: 'Book' });
    await user.dblClick(button);
    await screen.findByRole('heading', { name: 'Booking confirmed' });
    expect(store.listBookings()).toHaveLength(1);
  });

  it('shows a general error when the server cannot be reached', async () => {
    const { state } = installFakeApi();
    const { user } = await openForm();
    await user.type(field('Name'), 'Anna');
    await user.type(field('Email'), 'anna@example.com');
    state.offline = true;
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach/i);
    expect(field('Name')).toHaveValue('Anna');
  });

  it('says a fully booked tasting is fully booked instead of showing the form', async () => {
    const { store } = installFakeApi();
    store.book('winter-tasting', { name: 'A', email: 'a@example.com', guests: 8 });
    store.book('winter-tasting', { name: 'B', email: 'b@example.com', guests: 2 });
    renderApp('/tastings/winter-tasting/book');
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: /back to the tastings/i })).toBeInTheDocument();
  });

  it('shows not found for an unknown tasting', async () => {
    installFakeApi();
    renderApp('/tastings/nope/book');
    expect(await screen.findByRole('heading', { name: /not found/i })).toBeInTheDocument();
  });
});
