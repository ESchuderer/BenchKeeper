import { bookingSchema, type BookingField, type FieldErrors } from '../../shared/booking';
import { createStore } from '../../server/store';

export const PASSWORD = 'sesame';

interface Options {
  /** Make every request fail as if the server were unreachable. */
  offline?: boolean;
}

/**
 * Installs a fake `fetch` backed by the real in-memory store and the real booking schema,
 * so component tests exercise the same rules as the server without a network.
 */
export function installFakeApi(options: Options = {}) {
  const store = createStore();
  const state = { signedIn: false, offline: options.offline ?? false, calls: [] as string[] };

  const json = (status: number, body?: unknown) =>
    new Response(body === undefined ? null : JSON.stringify(body), {
      status,
      headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    });

  const handler = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const url = new URL(String(input), 'http://localhost');
    const method = (init?.method ?? 'GET').toUpperCase();
    const body = init?.body ? JSON.parse(String(init.body)) : undefined;
    state.calls.push(`${method} ${url.pathname}`);
    if (state.offline) throw new TypeError('Failed to fetch');
    const path = url.pathname;

    if (method === 'GET' && path === '/api/tastings') return json(200, { tastings: store.listTastings() });

    let m = path.match(/^\/api\/tastings\/([^/]+)$/);
    if (m && method === 'GET') {
      const tasting = store.getTasting(m[1]!);
      return tasting ? json(200, { tasting }) : json(404, { error: 'We could not find that tasting.' });
    }

    m = path.match(/^\/api\/tastings\/([^/]+)\/bookings$/);
    if (m && method === 'POST') {
      const parsed = bookingSchema.safeParse(body ?? {});
      if (!parsed.success) {
        const errors: FieldErrors = {};
        for (const issue of parsed.error.issues) errors[issue.path[0] as BookingField] ??= issue.message;
        return json(400, { errors });
      }
      const result = store.book(m[1]!, parsed.data);
      if (!result.ok) {
        if (result.reason === 'unknown-tasting') return json(404, { error: 'We could not find that tasting.' });
        const message =
          result.seatsLeft === 0 ? 'Sorry, this tasting is fully booked.' : `Only ${result.seatsLeft} seats are left for this tasting.`;
        return json(409, { errors: { guests: message } });
      }
      const tasting = store.getTasting(result.booking.tastingId)!;
      return json(201, { booking: { ...result.booking, tastingTitle: tasting.title, startsAt: tasting.startsAt } });
    }

    if (path === '/api/staff/session') return json(200, { signedIn: state.signedIn });
    if (path === '/api/staff/login' && method === 'POST') {
      if (body?.password !== PASSWORD) return json(401, { errors: { password: 'That password is not correct.' } });
      state.signedIn = true;
      return json(200, { signedIn: true });
    }
    if (path === '/api/staff/logout' && method === 'POST') {
      state.signedIn = false;
      return json(200, { signedIn: false });
    }
    if (path === '/api/staff/bookings' && method === 'GET') {
      if (!state.signedIn) return json(401, { error: 'Please sign in as staff.' });
      const bookings = store.listBookings();
      return json(200, {
        tastings: store.listTastings().map((t) => ({ ...t, bookings: bookings.filter((b) => b.tastingId === t.id) })),
      });
    }
    m = path.match(/^\/api\/staff\/bookings\/([^/]+)$/);
    if (m && method === 'DELETE') {
      if (!state.signedIn) return json(401, { error: 'Please sign in as staff.' });
      return store.cancel(m[1]!) ? json(204) : json(404, { error: 'That booking no longer exists. It may already have been cancelled.' });
    }
    return json(404, { error: 'Not found.' });
  };

  vi.stubGlobal('fetch', vi.fn(handler));
  return { store, state };
}
