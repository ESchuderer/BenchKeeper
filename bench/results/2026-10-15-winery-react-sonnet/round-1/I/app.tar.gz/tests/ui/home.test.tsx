// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import { installFakeApi } from './fakeApi';
import { renderApp } from './render';

afterEach(() => vi.unstubAllGlobals());

describe('start page', () => {
  it('lists every tasting with title, date and time, price and seats left', async () => {
    installFakeApi();
    renderApp('/');
    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' });
    expect(within(riesling).getByText('2026-11-06 18:00')).toBeInTheDocument();
    expect(within(riesling).getByText('EUR 25')).toBeInTheDocument();
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument();

    const tour = screen.getByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(tour).getByText('2026-11-14 15:00')).toBeInTheDocument();
    expect(within(tour).getByText('EUR 32')).toBeInTheDocument();
    expect(within(tour).getByText('8 seats left')).toBeInTheDocument();

    const winter = screen.getByRole('article', { name: 'Winter Tasting' });
    expect(within(winter).getByText('EUR 28')).toBeInTheDocument();
    expect(within(winter).getByText('10 seats left')).toBeInTheDocument();
  });

  it('shows the winery name in a header with a link home', async () => {
    installFakeApi();
    renderApp('/');
    expect(await screen.findByRole('link', { name: /Weingut Kieselbrunnen/ })).toHaveAttribute('href', '/');
  });

  it('has a "Book <title>" link per tasting pointing at its booking form', async () => {
    installFakeApi();
    renderApp('/');
    expect(await screen.findByRole('link', { name: 'Book Riesling Evening' })).toHaveAttribute('href', '/tastings/riesling-evening/book');
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toBeInTheDocument();
  });

  it('marks a sold-out tasting "Fully booked" and offers no booking link', async () => {
    const { store } = installFakeApi();
    store.book('red-wine-cellar-tour', { name: 'A', email: 'a@example.com', guests: 8 });
    renderApp('/');
    const tour = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' });
    expect(within(tour).getByText('Fully booked')).toBeInTheDocument();
    expect(within(tour).getByText('0 seats left')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toBeInTheDocument();
  });

  it('shows an error with a retry button when the tastings cannot be loaded', async () => {
    const { state } = installFakeApi({ offline: true });
    const { user } = renderApp('/');
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load the tastings/i);
    state.offline = false;
    await user.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByRole('article', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
  });

  it('shows a not-found page with a way back for unknown URLs', async () => {
    installFakeApi();
    renderApp('/nothing-here');
    expect(await screen.findByRole('heading', { name: /page not found/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /back to the tastings/i })).toHaveAttribute('href', '/');
  });
});
