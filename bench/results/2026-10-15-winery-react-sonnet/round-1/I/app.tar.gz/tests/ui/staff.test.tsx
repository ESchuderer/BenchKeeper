// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import { installFakeApi, PASSWORD } from './fakeApi';
import { renderApp } from './render';

afterEach(() => vi.unstubAllGlobals());

const anna = { name: 'Anna Weber', email: 'anna@example.com', guests: 4 };

async function signIn(user: ReturnType<typeof renderApp>['user'], password = PASSWORD) {
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
}

describe('/staff', () => {
  it('asks for a password and shows no booking data', async () => {
    const { store } = installFakeApi();
    store.book('winter-tasting', anna);
    renderApp('/staff');
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument();
  });

  it('shows an error next to the password field for a wrong password', async () => {
    installFakeApi();
    const { user } = renderApp('/staff');
    await signIn(user, 'wrong');
    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription(/not correct/i);
    expect(screen.queryByRole('button', { name: 'Sign out' })).not.toBeInTheDocument();
  });

  it('shows bookings grouped by tasting with name, email, guests and reference', async () => {
    const { store } = installFakeApi();
    const r = store.book('winter-tasting', anna);
    if (!r.ok) throw new Error('setup');
    const { user } = renderApp('/staff');
    await signIn(user);

    const winter = await screen.findByRole('region', { name: 'Winter Tasting' });
    expect(within(winter).getByText('Anna Weber')).toBeInTheDocument();
    expect(within(winter).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(winter).getByText('4')).toBeInTheDocument();
    expect(within(winter).getByText(r.booking.reference)).toBeInTheDocument();
    expect(within(winter).getByRole('button', { name: 'Cancel' })).toBeInTheDocument();

    const riesling = screen.getByRole('region', { name: 'Riesling Evening' });
    expect(within(riesling).getByText(/no bookings yet/i)).toBeInTheDocument();
    expect(within(riesling).queryByRole('button', { name: 'Cancel' })).not.toBeInTheDocument();
  });

  it('cancels a booking, removes it from the list and frees its seats', async () => {
    const { store } = installFakeApi();
    store.book('winter-tasting', anna);
    store.book('winter-tasting', { name: 'Ben Roth', email: 'ben@example.com', guests: 1 });
    const { user } = renderApp('/staff');
    await signIn(user);
    const winter = await screen.findByRole('region', { name: 'Winter Tasting' });
    expect(within(winter).getByText('5 seats left')).toBeInTheDocument();

    const annaRow = within(winter).getByText('Anna Weber').closest('li')!;
    await user.click(within(annaRow).getByRole('button', { name: 'Cancel' }));

    expect(await screen.findByRole('status')).toHaveTextContent(/cancelled/i);
    expect(within(winter).queryByText('Anna Weber')).not.toBeInTheDocument();
    expect(within(winter).getByText('Ben Roth')).toBeInTheDocument();
    expect(within(winter).getByText('9 seats left')).toBeInTheDocument();
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(9);
  });

  it('refreshes and explains when the booking was already cancelled', async () => {
    const { store } = installFakeApi();
    const r = store.book('winter-tasting', anna);
    if (!r.ok) throw new Error('setup');
    const { user } = renderApp('/staff');
    await signIn(user);
    const winter = await screen.findByRole('region', { name: 'Winter Tasting' });
    store.cancel(r.booking.reference);
    await user.click(within(winter).getByRole('button', { name: 'Cancel' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/no longer exists/i);
    expect(within(winter).queryByText('Anna Weber')).not.toBeInTheDocument();
  });

  it('goes back to the sign-in prompt after "Sign out"', async () => {
    installFakeApi();
    const { user } = renderApp('/staff');
    await signIn(user);
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });

  it('skips the prompt when a staff session already exists', async () => {
    const { state } = installFakeApi();
    state.signedIn = true;
    renderApp('/staff');
    expect(await screen.findByRole('button', { name: 'Sign out' })).toBeInTheDocument();
  });

  it('returns to the sign-in prompt when the session has expired', async () => {
    const { state } = installFakeApi();
    state.signedIn = true;
    const { user } = renderApp('/staff');
    await screen.findByRole('button', { name: 'Sign out' });
    state.signedIn = false;
    await user.click(screen.getByRole('button', { name: 'Refresh' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });
});

describe('/staff resilience', () => {
  it('keeps the bookings on screen when a refresh fails and says so', async () => {
    const { store, state } = installFakeApi();
    store.book('winter-tasting', anna);
    state.signedIn = true;
    const { user } = renderApp('/staff');
    await screen.findByText('Anna Weber');
    state.offline = true;
    await user.click(screen.getByRole('button', { name: 'Refresh' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not (load|refresh)/i);
    expect(screen.getByText('Anna Weber')).toBeInTheDocument();
  });

  it('does not show an old connection error again after signing in and out', async () => {
    const { state } = installFakeApi({ offline: true });
    const { user } = renderApp('/staff');
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach/i);
    state.offline = false;
    await signIn(user);
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));
    await screen.findByLabelText('Password');
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
  });
});
