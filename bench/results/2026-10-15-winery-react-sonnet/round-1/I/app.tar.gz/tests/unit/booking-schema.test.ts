import { bookingSchema, MAX_GUESTS } from '../../shared/booking';

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

function errorsFor(input: unknown) {
  const result = bookingSchema.safeParse(input);
  if (result.success) return {};
  const out: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const key = String(issue.path[0]);
    out[key] ??= issue.message;
  }
  return out;
}

describe('bookingSchema', () => {
  it('accepts a valid booking and trims name and email', () => {
    const result = bookingSchema.parse({ name: '  Anna Weber ', email: ' anna@example.com ', guests: 2 });
    expect(result).toEqual(valid);
  });

  it('accepts guests given as a numeric string from a form field', () => {
    expect(bookingSchema.parse({ ...valid, guests: '3' }).guests).toBe(3);
  });

  it('rejects a blank name', () => {
    expect(errorsFor({ ...valid, name: '   ' }).name).toBeTruthy();
  });

  it('rejects a name longer than 100 characters', () => {
    expect(errorsFor({ ...valid, name: 'x'.repeat(101) }).name).toBeTruthy();
  });

  it.each(['', 'not-an-email', 'a@b', 'a b@example.com'])('rejects email %j', (email) => {
    expect(errorsFor({ ...valid, email }).email).toBeTruthy();
  });

  it.each([0, -1, MAX_GUESTS + 1, 2.5, '', 'abc', null, undefined, NaN, '1e1'])('rejects guests %j', (guests) => {
    expect(errorsFor({ ...valid, guests }).guests).toBeTruthy();
  });

  it.each([1, MAX_GUESTS])('accepts guests = %i', (guests) => {
    expect(bookingSchema.safeParse({ ...valid, guests }).success).toBe(true);
  });

  it('rejects non-object input', () => {
    expect(bookingSchema.safeParse(null).success).toBe(false);
    expect(bookingSchema.safeParse('x').success).toBe(false);
  });
});
