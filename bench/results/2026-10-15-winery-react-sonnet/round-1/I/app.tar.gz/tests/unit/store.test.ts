import { createStore, formatEuro } from '../../server/store';

const guest = { name: 'Anna Weber', email: 'anna@example.com' };

describe('store', () => {
  it('starts with the three tastings, all seats free and no bookings', () => {
    const store = createStore();
    expect(store.listTastings().map((t) => [t.id, t.title, t.startsAt, t.priceEur, t.seats, t.seatsLeft])).toEqual([
      ['riesling-evening', 'Riesling Evening', '2026-11-06 18:00', 25, 12, 12],
      ['red-wine-cellar-tour', 'Red Wine Cellar Tour', '2026-11-14 15:00', 32, 8, 8],
      ['winter-tasting', 'Winter Tasting', '2026-12-05 17:00', 28, 10, 10],
    ]);
    expect(store.listBookings()).toEqual([]);
  });

  it('books seats, computes the total and reduces seats left', () => {
    const store = createStore();
    const result = store.book('riesling-evening', { ...guest, guests: 3 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.booking).toMatchObject({ ...guest, guests: 3, tastingId: 'riesling-evening', totalEur: 75 });
    expect(result.booking.reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(9);
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(10);
  });

  it('rejects a booking for more guests than seats left and changes nothing', () => {
    const store = createStore();
    store.book('red-wine-cellar-tour', { ...guest, guests: 6 });
    const result = store.book('red-wine-cellar-tour', { ...guest, guests: 3 });
    expect(result).toEqual({ ok: false, reason: 'insufficient-seats', seatsLeft: 2 });
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(2);
  });

  it('accepts a booking for exactly the seats left and then reports fully booked', () => {
    const store = createStore();
    store.book('red-wine-cellar-tour', { ...guest, guests: 6 });
    expect(store.book('red-wine-cellar-tour', { ...guest, guests: 2 }).ok).toBe(true);
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(0);
    expect(store.book('red-wine-cellar-tour', { ...guest, guests: 1 })).toEqual({
      ok: false,
      reason: 'insufficient-seats',
      seatsLeft: 0,
    });
  });

  it('reports an unknown tasting', () => {
    expect(createStore().book('nope', { ...guest, guests: 1 })).toEqual({ ok: false, reason: 'unknown-tasting' });
  });

  it('gives every booking a unique reference', () => {
    const store = createStore();
    const refs = new Set<string>();
    for (let i = 0; i < 12; i++) {
      const r = store.book('riesling-evening', { ...guest, guests: 1 });
      if (r.ok) refs.add(r.booking.reference);
    }
    expect(refs.size).toBe(12);
  });

  it('cancel removes the booking and frees its seats', () => {
    const store = createStore();
    const r = store.book('winter-tasting', { ...guest, guests: 4 });
    if (!r.ok) throw new Error('booking failed');
    expect(store.cancel(r.booking.reference)).toBe(true);
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(10);
    expect(store.listBookings()).toEqual([]);
  });

  it('cancel of an unknown or already cancelled reference returns false', () => {
    const store = createStore();
    const r = store.book('winter-tasting', { ...guest, guests: 1 });
    if (!r.ok) throw new Error('booking failed');
    expect(store.cancel(r.booking.reference)).toBe(true);
    expect(store.cancel(r.booking.reference)).toBe(false);
    expect(store.cancel('KB-NOPE')).toBe(false);
  });

  it('keeps stores independent of each other', () => {
    const a = createStore();
    const b = createStore();
    a.book('winter-tasting', { ...guest, guests: 2 });
    expect(b.getTasting('winter-tasting')?.seatsLeft).toBe(10);
  });
});

describe('formatEuro', () => {
  it('formats whole euro amounts', () => {
    expect(formatEuro(25)).toBe('EUR 25');
    expect(formatEuro(0)).toBe('EUR 0');
  });
});
