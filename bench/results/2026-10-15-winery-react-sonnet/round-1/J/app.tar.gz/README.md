# Weingut Kieselbrunnen – tasting bookings

Guests browse the winery's tastings and book seats online; staff see all bookings and can cancel them.
React front end, Node.js 22 / Express back end, one process serves both.

## Run it

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start      # http://localhost:3000
```

| Variable | Meaning |
|---|---|
| `PORT` | Port to listen on (default `3000`). |
| `STAFF_PASSWORD` | Password for `/staff`. If unset or empty nobody can sign in. |
| `TRUST_PROXY` | Set (e.g. `1`) when running behind a reverse proxy that terminates TLS. Without it the staff cookie is not marked `Secure` and the sign-in rate limit sees the proxy's IP instead of the client's. |

- Guests: `/` lists the tastings; "Book <tasting>" opens the booking form; a confirmation follows at `/booking/<reference>`.
- Staff: `/staff` (also linked in the footer).
- Bookings are kept **in memory** and the app starts with none. Restarting the server clears them and staff sessions.
- The tastings are defined in `shared/tastings.ts`.

## Develop and test

```sh
npm run dev         # API on :3000 (tsx watch) + Vite on :5173 with hot reload
npm test            # Vitest: shared rules, booking service, HTTP API, React components
npm run typecheck
npm run e2e         # real-browser run against the built app (needs `npm run build` and `npx playwright install chromium`)
```

Layout: `shared/` (catalogue, validation, formatting used by both sides), `server/` (Express app, booking rules, staff auth), `client/` (React app), `tests/`, `e2e/`. The planning artifacts (specs, design, tasks) are in `openspec/changes/winery-tasting-booking/`.

## Notes

- The booking rules live in `server/booking-service.ts`. Seat checks and inserts are synchronous, so simultaneous requests can never overbook a tasting.
- Staff sign-in uses a constant-time password comparison, an HttpOnly `SameSite=Strict` session cookie (8 hours) and a rate limit (10 failed attempts per 15 minutes per IP).
- Seats left read "<n> seats left" for every n, including 1, as specified.
