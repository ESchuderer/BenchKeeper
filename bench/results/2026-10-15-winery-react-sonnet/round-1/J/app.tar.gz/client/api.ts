import type { BookingInput, FieldErrors } from '../shared/schemas';
import type { TastingView } from '../shared/tastings';

export interface BookingSummary {
  reference: string;
  guests: number;
  totalCents: number;
  tasting: { id: string; title: string; startsAt: string; priceCents: number };
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
  totalCents: number;
}

export interface StaffGroup {
  tasting: TastingView;
  bookings: StaffBooking[];
}

/** An error response from the server; `fieldErrors` is set when it concerns form fields. */
export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly fieldErrors?: FieldErrors,
  ) {
    super(message);
  }
}

async function call<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      ...init,
      headers: { ...(init?.body ? { 'Content-Type': 'application/json' } : {}), ...init?.headers },
    });
  } catch {
    throw new ApiError('We could not reach the server. Please check your connection.', 0);
  }
  if (res.status === 204) return undefined as T;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiError(body.error ?? 'Something went wrong. Please try again.', res.status, body.errors);
  }
  return body as T;
}

export const api = {
  tastings: () => call<{ tastings: TastingView[] }>('/api/tastings').then((r) => r.tastings),
  tasting: (id: string) => call<{ tasting: TastingView }>(`/api/tastings/${encodeURIComponent(id)}`).then((r) => r.tasting),
  book: (tastingId: string, input: BookingInput) =>
    call<{ booking: BookingSummary }>(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
      method: 'POST',
      body: JSON.stringify(input),
    }).then((r) => r.booking),
  booking: (reference: string) =>
    call<{ booking: BookingSummary }>(`/api/bookings/${encodeURIComponent(reference)}`).then((r) => r.booking),
  staffSession: () => call<{ signedIn: boolean }>('/api/staff/session').then((r) => r.signedIn),
  staffSignIn: (password: string) => call<{ signedIn: true }>('/api/staff/session', { method: 'POST', body: JSON.stringify({ password }) }),
  staffSignOut: () => call<void>('/api/staff/session', { method: 'DELETE' }),
  staffBookings: () => call<{ groups: StaffGroup[] }>('/api/staff/bookings').then((r) => r.groups),
  staffCancel: (reference: string) => call<void>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' }),
};
