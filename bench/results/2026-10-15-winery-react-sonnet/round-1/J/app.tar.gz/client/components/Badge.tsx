import type { ReactNode } from 'react';

const tones = {
  neutral: 'bg-parchment text-wine-dark border-line',
  warning: 'bg-gold-soft text-wine-dark border-gold',
  soldout: 'bg-wine-dark text-white border-wine-dark',
} as const;

export function Badge({ tone = 'neutral', children }: { tone?: keyof typeof tones; children: ReactNode }) {
  return <span className={`inline-flex items-center rounded-full border px-3 py-1 text-sm font-semibold ${tones[tone]}`}>{children}</span>;
}
