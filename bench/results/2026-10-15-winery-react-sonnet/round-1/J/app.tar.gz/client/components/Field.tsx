import { useId, type ComponentProps } from 'react';

interface FieldProps extends ComponentProps<'input'> {
  label: string;
  error?: string;
  hint?: string;
}

/** A labelled input whose error message sits directly below it and is linked via aria-describedby. */
export function Field({ label, error, hint, className = '', ...input }: FieldProps) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [error && errorId, hint && hintId].filter(Boolean).join(' ') || undefined;

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-base font-semibold text-wine-dark">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        className={`min-h-12 w-full rounded-lg border-2 bg-white px-3.5 py-2 text-base text-ink placeholder:text-muted/70 ${
          error ? 'border-danger bg-danger-soft/40' : 'border-line hover:border-gold'
        } ${className}`}
        {...input}
      />
      {hint && !error && (
        <p id={hintId} className="text-sm text-muted">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} className="flex items-start gap-1.5 text-sm font-semibold text-danger">
          <span aria-hidden="true" className="mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-danger text-[11px] leading-none text-white">
            !
          </span>
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}
