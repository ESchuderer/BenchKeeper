import { Link, Outlet } from 'react-router';

function Mark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 32 32" className="h-10 w-10 shrink-0">
      <rect width="32" height="32" rx="9" fill="var(--color-wine)" />
      <path d="M16 6c3.6 4.6 6 7.8 6 11a6 6 0 0 1-12 0c0-3.2 2.4-6.4 6-11z" fill="var(--color-gold-soft)" />
    </svg>
  );
}

export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b border-line bg-cream">
        <div className="h-1.5 bg-wine" />
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-4">
          <Link to="/" className="flex min-h-11 items-center gap-3 no-underline">
            <Mark />
            <span className="flex flex-col leading-tight">
              <span className="font-display text-xl font-semibold text-wine-dark sm:text-2xl">Weingut Kieselbrunnen</span>
              <span className="text-sm text-muted">Family winery · Wine tastings</span>
            </span>
          </Link>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-5 py-8 sm:py-12">
        <Outlet />
      </main>

      <footer className="border-t border-line bg-parchment">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-x-6 gap-y-2 px-5 py-6 text-sm text-muted">
          <p>© Weingut Kieselbrunnen. Tastings are held at the winery.</p>
          <Link to="/staff" className="inline-flex min-h-11 items-center underline-offset-4 hover:underline">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
