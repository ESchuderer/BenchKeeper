import type { ReactNode } from 'react';

type Tone = 'error' | 'success' | 'info';

const tones: Record<Tone, { box: string; icon: string; glyph: string }> = {
  error: { box: 'border-danger bg-danger-soft text-danger', icon: 'bg-danger', glyph: '!' },
  success: { box: 'border-leaf bg-leaf-soft text-leaf', icon: 'bg-leaf', glyph: '✓' },
  info: { box: 'border-gold bg-gold-soft/50 text-wine-dark', icon: 'bg-gold', glyph: 'i' },
};

/** A boxed message. Errors are announced to assistive technology; the icon means state is not shown by colour alone. */
export function Notice({ tone, children, action }: { tone: Tone; children: ReactNode; action?: ReactNode }) {
  const t = tones[tone];
  return (
    <div role={tone === 'error' ? 'alert' : 'status'} className={`flex flex-wrap items-center gap-x-4 gap-y-3 rounded-xl border-2 px-4 py-3.5 ${t.box}`}>
      <span aria-hidden="true" className={`inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white ${t.icon}`}>
        {t.glyph}
      </span>
      <div className="min-w-0 flex-1 font-semibold">{children}</div>
      {action}
    </div>
  );
}

export function Loading({ label = 'Loading…' }: { label?: string }) {
  return (
    <p role="status" className="flex items-center gap-3 py-10 text-muted">
      <span aria-hidden="true" className="h-5 w-5 animate-spin rounded-full border-2 border-line border-t-wine" />
      {label}
    </p>
  );
}
