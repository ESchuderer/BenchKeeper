import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Link, useNavigate, useParams } from 'react-router';
import { formatEur } from '../../shared/format';
import { bookingInputSchema, type BookingInput } from '../../shared/schemas';
import { ApiError, api } from '../api';
import { Badge } from '../components/Badge';
import { Button, ButtonLink } from '../components/Button';
import { Field } from '../components/Field';
import { Loading, Notice } from '../components/Notice';
import { DateBlock, TastingStart } from './TastingsPage';
import { NotFoundPage } from './NotFoundPage';

const FIELDS = ['name', 'email', 'guests'] as const;

export function BookingPage() {
  const { tastingId = '' } = useParams();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const tastingQuery = useQuery({ queryKey: ['tasting', tastingId], queryFn: () => api.tasting(tastingId) });

  const {
    register,
    handleSubmit,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '' },
  });

  const booking = useMutation({ mutationFn: (input: BookingInput) => api.book(tastingId, input) });

  const tasting = tastingQuery.data;
  const guests = Number(watch('guests'));

  async function onSubmit(input: BookingInput) {
    try {
      const confirmed = await booking.mutateAsync(input);
      void queryClient.invalidateQueries({ queryKey: ['tastings'] });
      void queryClient.invalidateQueries({ queryKey: ['tasting', tastingId] });
      navigate(`/booking/${confirmed.reference}`);
    } catch (error) {
      if (error instanceof ApiError && error.fieldErrors) {
        for (const field of FIELDS) {
          const message = error.fieldErrors[field];
          if (message) setError(field, { message }, { shouldFocus: true });
        }
        void queryClient.invalidateQueries({ queryKey: ['tasting', tastingId] });
      }
    }
  }

  if (tastingQuery.isPending) return <Loading label="Loading tasting…" />;
  if (tastingQuery.error instanceof ApiError && tastingQuery.error.status === 404) {
    return <NotFoundPage title="Tasting not found" message="We could not find that tasting. It may have been renamed or removed." />;
  }
  if (!tasting) {
    return (
      <Notice
        tone="error"
        action={
          <Button variant="secondary" onClick={() => void tastingQuery.refetch()}>
            Try again
          </Button>
        }
      >
        {tastingQuery.error?.message}
      </Notice>
    );
  }

  const soldOut = tasting.seatsLeft === 0;
  const fieldErrorKeys = FIELDS.filter((f) => errors[f]);
  const formError = booking.error instanceof ApiError && !booking.error.fieldErrors ? booking.error.message : undefined;

  return (
    <div className="mx-auto grid max-w-4xl gap-8 md:grid-cols-[2fr_3fr]">
      <aside className="h-fit rounded-2xl bg-gradient-to-br from-wine to-wine-dark p-6 text-cream">
        <Link to="/" className="mb-5 inline-flex min-h-11 items-center text-sm text-gold-soft underline-offset-4 hover:underline">
          ← All tastings
        </Link>
        <div className="flex items-start gap-4">
          <DateBlock startsAt={tasting.startsAt} onDark />
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-gold-soft">You are booking</p>
            <h1 className="mt-1 text-3xl !text-cream">{tasting.title}</h1>
          </div>
        </div>
        <div className="mt-5 text-cream [&_p]:!text-cream/85 [&_time]:!text-cream">
          <TastingStart startsAt={tasting.startsAt} />
        </div>
        <p className="mt-4 text-cream/85">{tasting.description}</p>
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <span className="font-display text-xl font-semibold">{formatEur(tasting.priceCents)}</span>
          <span className="text-sm text-cream/80">per guest</span>
          <Badge tone={soldOut ? 'soldout' : 'neutral'}>{tasting.seatsLeft} seats left</Badge>
        </div>
      </aside>

      {soldOut ? (
        <section className="flex flex-col items-start gap-4 rounded-2xl border border-line bg-parchment/70 p-6">
          <Badge tone="soldout">Fully booked</Badge>
          <h2 className="text-2xl">This tasting is fully booked</h2>
          <p className="text-muted">All seats have been taken. If a booking is cancelled, the seats become available here again.</p>
          <ButtonLink to="/" variant="secondary">
            See other tastings
          </ButtonLink>
        </section>
      ) : (
        <form
          onSubmit={(event) => void handleSubmit(onSubmit)(event)}
          noValidate
          aria-label={`Book ${tasting.title}`}
          className="flex flex-col gap-5 rounded-2xl border border-line bg-white p-6 shadow-sm"
        >
          <h2 className="text-2xl">Your details</h2>

          {(formError || fieldErrorKeys.length > 1) && (
            <Notice tone="error">{formError ?? 'Please check the fields marked below.'}</Notice>
          )}

          <Field label="Name" autoComplete="name" required error={errors.name?.message} {...register('name')} />
          <Field label="Email" type="email" autoComplete="email" required error={errors.email?.message} {...register('email')} />
          <Field
            label="Guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={8}
            step={1}
            required
            placeholder="1 to 8"
            hint={`1 to 8 guests · ${tasting.seatsLeft} seats left`}
            error={errors.guests?.message}
            {...register('guests', { valueAsNumber: true })}
          />

          {!errors.guests && guests >= 1 && guests <= 8 && Number.isInteger(guests) && (
            <p className="flex items-baseline justify-between border-t border-line pt-4 text-lg">
              <span>Total</span>
              <span className="font-display text-2xl font-semibold text-wine">{formatEur(guests * tasting.priceCents)}</span>
            </p>
          )}

          <Button type="submit" disabled={isSubmitting} aria-busy={isSubmitting}>
            Book
          </Button>
        </form>
      )}
    </div>
  );
}
