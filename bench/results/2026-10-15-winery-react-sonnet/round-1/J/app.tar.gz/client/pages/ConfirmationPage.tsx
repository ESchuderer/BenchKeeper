import { useQuery } from '@tanstack/react-query';
import { useParams } from 'react-router';
import { describeStart, formatEur } from '../../shared/format';
import { ApiError, api } from '../api';
import { Button, ButtonLink } from '../components/Button';
import { Loading, Notice } from '../components/Notice';
import { NotFoundPage } from './NotFoundPage';

export function ConfirmationPage() {
  const { reference = '' } = useParams();
  const { data: booking, error, isPending, refetch } = useQuery({
    queryKey: ['booking', reference],
    queryFn: () => api.booking(reference),
  });

  if (isPending) return <Loading label="Loading your booking…" />;
  if (error instanceof ApiError && error.status === 404) {
    return (
      <NotFoundPage
        title="Booking not found"
        message="We could not find a booking with this reference. It may have been cancelled."
      />
    );
  }
  if (!booking) {
    return (
      <Notice
        tone="error"
        action={
          <Button variant="secondary" onClick={() => void refetch()}>
            Try again
          </Button>
        }
      >
        {error?.message}
      </Notice>
    );
  }

  const { date, time } = describeStart(booking.tasting.startsAt);
  const rows: [string, string][] = [
    ['Tasting', booking.tasting.title],
    ['Date and time', `${date} ${time}`],
    ['Guests', `${booking.guests} ${booking.guests === 1 ? 'guest' : 'guests'}`],
    ['Total price', formatEur(booking.totalCents)],
  ];

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-8 flex flex-col items-center gap-4 text-center">
        <span aria-hidden="true" className="flex h-16 w-16 items-center justify-center rounded-full bg-leaf text-3xl text-white">
          ✓
        </span>
        <h1 className="text-4xl">Booking confirmed</h1>
        <p className="text-lg text-muted">Thank you! Your seats are reserved. We look forward to welcoming you at the winery.</p>
      </div>

      <section aria-label="Booking details" className="overflow-hidden rounded-2xl border border-leaf/40 bg-white shadow-sm">
        <dl className="divide-y divide-line">
          {rows.map(([label, value]) => (
            <div key={label} className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 px-6 py-4">
              <dt className="text-muted">{label}</dt>
              <dd className="font-semibold text-ink">{value}</dd>
            </div>
          ))}
        </dl>
        <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 bg-leaf-soft px-6 py-5">
          <p className="text-leaf">Booking reference</p>
          <p className="font-mono text-2xl font-bold tracking-wider text-leaf">{booking.reference}</p>
        </div>
      </section>

      <p className="mt-5 text-center text-sm text-muted">Please keep your reference and mention it if you need to change or cancel your booking.</p>
      <div className="mt-8 flex justify-center">
        <ButtonLink to="/" variant="secondary">
          All tastings
        </ButtonLink>
      </div>
    </div>
  );
}
