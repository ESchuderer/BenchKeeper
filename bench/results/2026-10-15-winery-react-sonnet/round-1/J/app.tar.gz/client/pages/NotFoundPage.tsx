import { ButtonLink } from '../components/Button';

export function NotFoundPage({ title = 'Page not found', message = 'We could not find the page you were looking for.' }) {
  return (
    <section className="mx-auto max-w-xl py-10 text-center">
      <h1 className="text-3xl sm:text-4xl">{title}</h1>
      <p className="mt-4 text-lg text-muted">{message}</p>
      <ButtonLink to="/" className="mt-8">
        Back to the tastings
      </ButtonLink>
    </section>
  );
}
