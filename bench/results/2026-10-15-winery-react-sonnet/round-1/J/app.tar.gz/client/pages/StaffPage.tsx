import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { describeStart } from '../../shared/format';
import { staffLoginSchema } from '../../shared/schemas';
import { ApiError, api } from '../api';
import { Button } from '../components/Button';
import { Field } from '../components/Field';
import { Loading, Notice } from '../components/Notice';

type Login = { password: string };

function SignIn({ onSignedIn }: { onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<Login>({ resolver: zodResolver(staffLoginSchema), defaultValues: { password: '' } });
  const [failure, setFailure] = useState<string>();

  async function onSubmit({ password }: Login) {
    setFailure(undefined);
    try {
      await api.staffSignIn(password);
      onSignedIn();
    } catch (error) {
      const message = error instanceof ApiError ? error.fieldErrors?.password : undefined;
      if (message) setError('password', { message }, { shouldFocus: true });
      else setFailure(error instanceof Error ? error.message : 'Something went wrong.');
    }
  }

  return (
    <form
      onSubmit={(event) => void handleSubmit(onSubmit)(event)}
      noValidate
      aria-label="Staff sign in"
      className="mx-auto flex max-w-md flex-col gap-5 rounded-2xl border border-line bg-white p-6 shadow-sm sm:p-8"
    >
      <div>
        <h1 className="text-3xl">Staff sign in</h1>
        <p className="mt-2 text-muted">See the tasting bookings and cancel them when plans change.</p>
      </div>
      {failure && <Notice tone="error">{failure}</Notice>}
      <Field label="Password" type="password" autoComplete="current-password" required error={errors.password?.message} {...register('password')} />
      <Button type="submit" disabled={isSubmitting}>
        Sign in
      </Button>
    </form>
  );
}

function Overview({ onSignedOut }: { onSignedOut: () => void }) {
  const queryClient = useQueryClient();
  const { data: groups, error, isPending, refetch } = useQuery({ queryKey: ['staff', 'bookings'], queryFn: api.staffBookings });
  const expired = error instanceof ApiError && error.status === 401;
  useEffect(() => {
    if (expired) onSignedOut();
  }, [expired, onSignedOut]);
  const [cancelError, setCancelError] = useState<string>();
  const [cancelling, setCancelling] = useState<string>();

  const cancel = useMutation({
    mutationFn: api.staffCancel,
    onMutate: (reference) => {
      setCancelError(undefined);
      setCancelling(reference);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['staff', 'bookings'] });
      void queryClient.invalidateQueries({ queryKey: ['tastings'] });
    },
    onError: (e) => {
      if (e instanceof ApiError && e.status === 401) onSignedOut();
      // A booking that is already gone is not an error worth keeping on screen.
      else if (e instanceof ApiError && e.status === 404) void queryClient.invalidateQueries({ queryKey: ['staff', 'bookings'] });
      else setCancelError(e.message);
    },
    onSettled: () => setCancelling(undefined),
  });

  const signOut = useMutation({ mutationFn: api.staffSignOut, onSettled: onSignedOut });

  return (
    <>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl">Tasting bookings</h1>
          <p className="mt-1 text-muted">All bookings, grouped by tasting.</p>
        </div>
        <Button variant="secondary" onClick={() => signOut.mutate()}>
          Sign out
        </Button>
      </div>

      {cancelError && (
        <div className="mb-6">
          <Notice tone="error">Could not cancel the booking: {cancelError}</Notice>
        </div>
      )}
      {isPending && <Loading label="Loading bookings…" />}
      {error && !expired && (
        <Notice
          tone="error"
          action={
            <Button variant="secondary" onClick={() => void refetch()}>
              Try again
            </Button>
          }
        >
          {error.message}
        </Notice>
      )}

      <div className="flex flex-col gap-8">
        {groups?.map(({ tasting, bookings }) => {
          const { date, time } = describeStart(tasting.startsAt);
          const booked = tasting.capacity - tasting.seatsLeft;
          return (
            <section key={tasting.id} aria-labelledby={`g-${tasting.id}`} className="overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
              <header className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b border-line bg-parchment px-5 py-4">
                <h2 id={`g-${tasting.id}`} className="text-2xl">
                  {tasting.title}
                </h2>
                <p className="text-sm text-muted">
                  {date} {time} · {booked} of {tasting.capacity} seats booked
                </p>
              </header>
              {bookings.length === 0 ? (
                <p className="px-5 py-5 text-muted">No bookings yet.</p>
              ) : (
                <ul className="divide-y divide-line">
                  {bookings.map((b) => (
                    <li key={b.reference} className="grid items-center gap-x-6 gap-y-2 px-5 py-4 sm:grid-cols-[1.4fr_1.6fr_auto_auto_auto]">
                      <span id={`name-${b.reference}`} className="font-semibold text-ink">{b.name}</span>
                      <span className="break-all text-muted">{b.email}</span>
                      <span>{b.guests} {b.guests === 1 ? 'guest' : 'guests'}</span>
                      <span className="font-mono text-sm font-bold tracking-wide text-wine">{b.reference}</span>
                      <Button variant="danger" aria-describedby={`name-${b.reference}`} disabled={cancelling === b.reference} onClick={() => cancel.mutate(b.reference)} className="justify-self-start sm:justify-self-end">
                        Cancel
                      </Button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          );
        })}
      </div>
    </>
  );
}

export function StaffPage() {
  const queryClient = useQueryClient();
  const session = useQuery({ queryKey: ['staff', 'session'], queryFn: api.staffSession });

  const setSignedIn = useCallback(
    (signedIn: boolean) => {
      queryClient.setQueryData(['staff', 'session'], signedIn);
      if (!signedIn) queryClient.removeQueries({ queryKey: ['staff', 'bookings'] });
    },
    [queryClient],
  );
  const handleSignedOut = useCallback(() => setSignedIn(false), [setSignedIn]);

  if (session.isPending) return <Loading label="Checking your session…" />;
  if (session.error) return <Notice tone="error">{session.error.message}</Notice>;
  return session.data ? <Overview onSignedOut={handleSignedOut} /> : <SignIn onSignedIn={() => setSignedIn(true)} />;
}
