import { useQuery } from '@tanstack/react-query';
import { describeStart, formatEur } from '../../shared/format';
import type { TastingView } from '../../shared/tastings';
import { api } from '../api';
import { Badge } from '../components/Badge';
import { ButtonLink, Button } from '../components/Button';
import { Loading, Notice } from '../components/Notice';

export function TastingStart({ startsAt }: { startsAt: string }) {
  const { weekday, date, time } = describeStart(startsAt);
  return (
    <p className="text-base text-muted">
      <span>{weekday}</span>{' '}
      <time dateTime={startsAt} className="whitespace-nowrap font-semibold text-ink">
        {date} {time}
      </time>
    </p>
  );
}

export function DateBlock({ startsAt, onDark = false }: { startsAt: string; onDark?: boolean }) {
  const { day, month } = describeStart(startsAt);
  return (
    <div aria-hidden="true" className={`flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-xl ${onDark ? 'bg-gold-soft text-wine-dark' : 'bg-wine text-gold-soft'}`}>
      <span className="font-display text-2xl font-semibold leading-none">{day}</span>
      <span className="mt-1 text-xs font-semibold uppercase tracking-widest">{month}</span>
    </div>
  );
}

function TastingCard({ tasting }: { tasting: TastingView }) {
  const soldOut = tasting.seatsLeft === 0;
  const fewLeft = !soldOut && tasting.seatsLeft <= 3;
  return (
    <article
      className={`flex flex-col gap-5 rounded-2xl border p-5 shadow-sm sm:p-6 ${
        soldOut ? 'border-line bg-parchment/70' : 'border-line bg-white'
      }`}
    >
      <div className="flex items-start gap-4">
        <DateBlock startsAt={tasting.startsAt} />
        <div className="min-w-0">
          <h2 className="text-2xl">{tasting.title}</h2>
          <TastingStart startsAt={tasting.startsAt} />
        </div>
      </div>

      <p className="text-muted">{tasting.description}</p>

      <div className="mt-auto flex flex-wrap items-center gap-x-4 gap-y-2">
        <p className="font-display text-xl font-semibold text-wine">
          {formatEur(tasting.priceCents)} <span className="font-sans text-sm font-normal text-muted">per guest</span>
        </p>
        <div className="flex flex-wrap items-center gap-2">
          {soldOut && <Badge tone="soldout">Fully booked</Badge>}
          <Badge tone={fewLeft ? 'warning' : 'neutral'}>{tasting.seatsLeft} seats left</Badge>
        </div>
      </div>

      {soldOut ? (
        <p className="min-h-11 rounded-lg border border-dashed border-line px-4 py-2.5 text-center text-sm text-muted">
          This tasting is fully booked. Seats may open up again if a booking is cancelled.
        </p>
      ) : (
        <ButtonLink to={`/book/${tasting.id}`}>Book {tasting.title}</ButtonLink>
      )}
    </article>
  );
}

export function TastingsPage() {
  const { data, error, isPending, refetch } = useQuery({ queryKey: ['tastings'], queryFn: api.tastings });

  return (
    <>
      <section className="mb-10 rounded-3xl bg-gradient-to-br from-wine to-wine-dark px-6 py-10 text-cream sm:px-10 sm:py-14">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-soft">Autumn &amp; winter at the estate</p>
        <h1 className="mt-3 max-w-2xl text-4xl !text-cream sm:text-5xl">Wine tastings at Weingut Kieselbrunnen</h1>
        <p className="mt-4 max-w-xl text-lg text-cream/85">
          Join us in the cellar for an evening with the wines we grow ourselves. Pick a tasting and reserve your seats online.
        </p>
      </section>

      {isPending && <Loading label="Loading tastings…" />}
      {error && (
        <Notice
          tone="error"
          action={
            <Button variant="secondary" onClick={() => void refetch()}>
              Try again
            </Button>
          }
        >
          {error.message}
        </Notice>
      )}
      {data && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {data.map((tasting) => (
            <TastingCard key={tasting.id} tasting={tasting} />
          ))}
        </div>
      )}
    </>
  );
}
