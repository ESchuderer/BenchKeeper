// End-to-end check against the built app in a real browser:  npm run build && npm run e2e
// Needs a browser once:  npx playwright install chromium
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { chromium } from 'playwright';

const PORT = 3457;
const BASE = `http://localhost:${PORT}`;
const PASSWORD = 'e2e-secret';
mkdirSync('screenshots', { recursive: true });

const server = spawn('node', ['dist/server/index.js'], {
  env: { ...process.env, PORT: String(PORT), STAFF_PASSWORD: PASSWORD },
  stdio: ['ignore', 'pipe', 'inherit'],
});
await new Promise((resolve, reject) => {
  server.stdout.on('data', (d) => String(d).includes('running') && resolve());
  server.on('exit', (code) => reject(new Error(`server exited early (${code})`)));
});

let browser;
let failed = false;
try {
  browser = await chromium.launch();
  const phone = await browser.newContext({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 2 });
  const page = await phone.newPage();
  const noHorizontalScroll = async (label) => {
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assert.ok(overflow <= 0, `${label}: horizontal overflow of ${overflow}px at 360px`);
  };

  // Start page
  await page.goto(BASE);
  await page.getByText('12 seats left').waitFor();
  await page.getByText('8 seats left').waitFor();
  await page.getByText('10 seats left').waitFor();
  await page.getByText('2026-11-06 18:00').waitFor();
  await noHorizontalScroll('start page');
  await page.screenshot({ path: 'screenshots/start-360.png', fullPage: true });

  // Invalid input
  await page.getByRole('link', { name: 'Book Riesling Evening' }).click();
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await page.getByText('Please enter your name.').waitFor();
  await page.getByLabel('Guests').fill('9');
  await page.getByLabel('Email').fill('nope');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await page.getByText(/valid email address/).waitFor();
  await noHorizontalScroll('booking form with errors');
  await page.screenshot({ path: 'screenshots/form-errors-360.png', fullPage: true });

  // Book 3 seats
  await page.getByLabel('Name').fill('Anna Weber');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('3');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await page.getByRole('heading', { name: 'Booking confirmed' }).waitFor();
  const confirmation = await page.locator('main').innerText();
  assert.match(confirmation, /Riesling Evening/);
  assert.match(confirmation, /3 guests/);
  assert.match(confirmation, /EUR 75/);
  const reference = confirmation.match(/KB-[A-Z2-9]{8}/)?.[0];
  assert.ok(reference, 'booking reference shown');
  await noHorizontalScroll('confirmation');
  await page.screenshot({ path: 'screenshots/confirmation-360.png', fullPage: true });

  // Reload keeps the confirmation
  await page.reload();
  await page.getByRole('heading', { name: 'Booking confirmed' }).waitFor();

  // Seats went down; take the rest of the Red Wine tour to see the fully booked state
  await page.goto(BASE);
  await page.getByText('9 seats left').waitFor();
  await page.getByRole('link', { name: 'Book Red Wine Cellar Tour' }).click();
  await page.getByLabel('Name').fill('Ben Koch');
  await page.getByLabel('Email').fill('ben@example.com');
  await page.getByLabel('Guests').fill('8');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await page.getByRole('heading', { name: 'Booking confirmed' }).waitFor();
  await page.goto(BASE);
  await page.getByText('Fully booked').first().waitFor();
  assert.equal(await page.getByRole('link', { name: 'Book Red Wine Cellar Tour' }).count(), 0);
  await page.screenshot({ path: 'screenshots/start-booked-360.png', fullPage: true });

  // Seats can never be exceeded: take 8 of the Winter Tasting's 10, then ask for 3
  const book = async (tasting, name, guests) => {
    await page.goto(`${BASE}/book/${tasting}`);
    await page.getByLabel('Name').fill(name);
    await page.getByLabel('Email').fill('guest@example.com');
    await page.getByLabel('Guests').fill(String(guests));
    await page.getByRole('button', { name: 'Book', exact: true }).click();
  };
  await book('winter-tasting', 'Carla Roth', 8);
  await page.getByRole('heading', { name: 'Booking confirmed' }).waitFor();
  await book('winter-tasting', 'Too Many', 3);
  await page.getByText(/Only 2 seats left/).waitFor();
  await noHorizontalScroll('booking form with capacity error');
  await page.screenshot({ path: 'screenshots/form-capacity-360.png', fullPage: true });

  // Staff
  await page.goto(`${BASE}/staff`);
  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByText('Incorrect password.').waitFor();
  await page.screenshot({ path: 'screenshots/staff-login-error-360.png', fullPage: true });
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByText('Anna Weber').waitFor();
  await page.getByText('anna@example.com').waitFor();
  await page.getByText(reference).waitFor();
  await noHorizontalScroll('staff overview');
  await page.screenshot({ path: 'screenshots/staff-360.png', fullPage: true });

  // Cancel frees seats
  const row = page.getByRole('listitem').filter({ hasText: 'Anna Weber' });
  await row.getByRole('button', { name: 'Cancel' }).click();
  await page.getByText('Anna Weber').waitFor({ state: 'detached' });
  await page.goto(BASE);
  await page.getByText('12 seats left').waitFor();

  // Desktop screenshots
  const desktop = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  await desktop.goto(BASE);
  await desktop.getByText('12 seats left').waitFor();
  await desktop.screenshot({ path: 'screenshots/start-1280.png', fullPage: true });
  await desktop.goto(`${BASE}/book/winter-tasting`);
  await desktop.getByLabel('Name').waitFor();
  await desktop.screenshot({ path: 'screenshots/form-1280.png', fullPage: true });

  console.log('e2e passed');
} catch (error) {
  failed = true;
  console.error(error);
} finally {
  await browser?.close();
  server.kill();
}
process.exit(failed ? 1 : 0);
