# Design

## Context

Greenfield repository, Node.js 22. See proposal.md for motivation and specs/ for behaviour. Constraints: one `npm install` / `npm run build` / `npm start` flow serving everything on `PORT`; no external services; in-memory bookings starting empty; React interface; English only. No browser is preinstalled in the container.

## Goals / Non-Goals

**Goals:**
- A single deployable process that serves the JSON API and the built React app.
- The booking rules (validation, capacity, cancel) live in one place on the server and cannot be bypassed from the client.
- Validation rules are written once and shared by client (instant feedback) and server (authority).

**Non-Goals:**
- Persistence across restarts, multi-instance deployment, payments, e-mail, admin editing of tastings, i18n, rejecting bookings for tastings whose date has passed (all three tastings are in the future; the catalogue is fixed).

## Decisions

- **TypeScript monorepo-in-one-package**: `server/`, `client/`, `shared/` folders, one `package.json`. Shared code (tasting catalogue types, zod schemas, price formatting) is imported by both sides. Alternative: npm workspaces; rejected as ceremony for a small app.
- **Server: Express 5** with `helmet` (security headers), `express-rate-limit` (staff sign-in brute-force limit) and `cookie-parser`. Alternative: Fastify; equally fine, Express is the most familiar to maintainers and its 5.x line handles async errors.
- **Server build**: `esbuild` bundles `server/index.ts` into `dist/server/index.js` (packages kept external); `tsc --noEmit` is the type check. `npm start` runs `node dist/server/index.js`. `tsx` is used for development only.
- **Client: React 19 + Vite + React Router (declarative mode)** for SPA routing: `/`, `/book/:tastingId`, `/booking/:reference`, `/staff`. Express serves `dist/client` and falls back to `index.html` for non-API paths so deep links and reloads work.
- **Forms: react-hook-form + zod (`@hookform/resolvers`)**. The same zod schema validates on the client and on the server. Server-side errors (e.g. "only 1 seat left") are mapped back onto fields with `setError`. Forms use `noValidate` so our own messages show next to fields instead of browser tooltips. Guests uses `type="number"`.
- **Styling: Tailwind CSS v4** (`@tailwindcss/vite`) with a small theme (burgundy, cream, olive, slate; serif headings, sans body). Fonts via `@fontsource` packages bundled into the build, so there are no external requests. Alternative: component library (MUI); rejected because it would look generic, not like a family winery's site.
- **Domain model**: `BookingService` is a plain class holding tastings and bookings in memory, with an injectable reference generator. Every operation is synchronous, so the check "guests <= seats left" and the insert happen in one uninterrupted step on Node's single thread; this is what guarantees no overbooking under simultaneous requests. Seats left are derived (`capacity - sum(guests)`), never stored, so cancelling cannot drift.
- **Prices** are integers in cents; formatted as "EUR 25" or "EUR 25.50".
- **Booking reference**: `KB-` plus 8 characters from an unambiguous 32-letter alphabet using `crypto.randomInt`; regenerated on collision.
- **API** (JSON):
  - `GET /api/tastings`, `GET /api/tastings/:id`
  - `POST /api/tastings/:id/bookings` → 201 `{reference, ...}`; 422 `{errors: {field: message}}`; 404 unknown tasting; 409-style capacity problems are also returned as 422 on `guests` so the UI treats them like any field error.
  - `GET /api/bookings/:reference` → public summary without name or email.
  - `POST /api/staff/session` (sign in), `GET /api/staff/session`, `DELETE /api/staff/session`, `GET /api/staff/bookings` (grouped), `DELETE /api/staff/bookings/:reference`.
- **Staff auth**: password compared in constant time (hash both sides with SHA-256, `timingSafeEqual`); if `STAFF_PASSWORD` is empty/unset sign-in always fails. On success the server issues a random session id stored in a server-side map and sent as an `HttpOnly`, `SameSite=Strict` cookie. Cross-site requests are blocked by SameSite=Strict; the only body-carrying staff route (sign-in) is JSON, and the DELETE routes cannot be sent cross-site without a CORS preflight, which the server never grants. Sessions expire after 8 hours.
- **Tests**: Vitest. Service unit tests; API tests with supertest (including concurrent bookings and auth); component tests with React Testing Library against a fetch stub for forms, states and staff flow. An end-to-end pass with a real browser is attempted via Playwright if a browser can be installed; otherwise it is reported as not run.
- **Tastings in the client** are fetched on the start page each time it mounts so seats left are fresh after booking or cancelling.

## Risks / Trade-offs

- [Bookings vanish on restart] → accepted by the brief; documented in the README.
- [Singular grammar: spec dictates "<n> seats left", so "1 seats left"] → follow the spec literally.
- [In-memory sessions lost on restart or not shared between instances] → staff just sign in again; single instance assumed.
- [Rate limit keyed on IP behind a proxy] → `trust proxy` configurable through `TRUST_PROXY`.
- [Tailwind class soup] → keep repeated patterns in a few small components (Button, Field, Badge).
