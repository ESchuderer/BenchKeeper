# Proposal

## Why

Weingut Kieselbrunnen, a family winery, takes tasting reservations by hand. Guests cannot see which tastings still have room, and staff have no single overview of who is coming. Three tastings are on sale from November 2026, so online booking and a staff overview are needed now.

## What Changes

- New public web app: guests see the three tastings with date, time, price per guest and seats left, and book seats through a form.
- Bookings can never exceed the seats left; invalid input is rejected with an error next to the field it concerns.
- After booking, guests get a confirmation (tasting, guests, total price, booking reference) that can be reopened by its reference.
- New staff area at `/staff`, protected by a password taken from the `STAFF_PASSWORD` environment variable. Signed-in staff see all bookings grouped by tasting and can cancel a booking, which frees its seats.
- A coherent winery-branded visual design, responsive down to phone widths, with clear error, success and fully-booked states.
- Single Node.js 22 service that serves the API and the React interface; bookings live in memory and start empty.

## Capabilities

### New Capabilities
- `tasting-booking`: the tasting catalogue, seat availability, guest booking with validation and the booking confirmation.
- `staff-bookings`: password-protected staff access, the bookings overview grouped by tasting, and booking cancellation.
- `winery-site-experience`: the look and feel of the guest and staff pages: branding, responsiveness, accessible form feedback and distinct error, success and fully-booked states.

### Modified Capabilities

(none; the project has no existing specs)

## Impact

- New code in a greenfield repository: React front end, Node.js server, shared validation, tests.
- New runtime configuration: `PORT` (default 3000) and `STAFF_PASSWORD`.
- Third-party libraries for server, routing, forms, validation and styling (see design.md). No external services.
- Out of scope: online payment, e-mail delivery, editing the tasting catalogue, persistence across restarts, languages other than English.
