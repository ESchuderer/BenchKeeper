# Spec Delta

## Purpose

Gives winery staff a password-protected overview of all bookings per tasting and the ability to cancel a booking and free its seats.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a password with a "Password" field and a "Sign in" button. The expected password SHALL come from the environment variable `STAFF_PASSWORD`. A wrong password SHALL show an error message next to the Password field and grant no access. If `STAFF_PASSWORD` is unset or empty, nobody SHALL be able to sign in.

#### Scenario: Correct password
- **WHEN** staff enter the value of `STAFF_PASSWORD` and press "Sign in"
- **THEN** the bookings overview is shown

#### Scenario: Wrong password
- **WHEN** staff enter a different password
- **THEN** an error message appears next to the Password field and the overview stays hidden

#### Scenario: Empty password
- **WHEN** staff press "Sign in" with an empty Password field
- **THEN** an error message appears next to the Password field

#### Scenario: No password configured
- **WHEN** the server runs without `STAFF_PASSWORD`
- **THEN** every sign-in attempt fails, including one with an empty password

### Requirement: Staff data is protected
All booking data that includes guest names, emails or the full booking list, and the cancel operation, SHALL be available only to a signed-in staff session. Guests and anonymous requests SHALL be refused. A staff session SHALL end when staff press "Sign out".

#### Scenario: Anonymous request for bookings
- **WHEN** a request for the bookings list or a cancellation arrives without a staff session
- **THEN** it is refused and no data is returned or changed

#### Scenario: Page reload keeps the session
- **WHEN** signed-in staff reload `/staff`
- **THEN** the overview is still shown without asking for the password again

#### Scenario: Sign out
- **WHEN** staff press "Sign out"
- **THEN** `/staff` asks for the password again

### Requirement: Bookings overview grouped by tasting
Signed-in staff SHALL see all bookings grouped by tasting. Each booking SHALL show name, email, number of guests and booking reference. Each tasting group SHALL name the tasting, and a tasting without bookings SHALL say so.

#### Scenario: Grouped list
- **WHEN** two guests booked the Riesling Evening and one booked the Winter Tasting
- **THEN** staff see a group "Riesling Evening" with two bookings, a group "Winter Tasting" with one booking, and a group "Red Wine Cellar Tour" saying it has no bookings
- **AND** every booking shows name, email, guests and reference

### Requirement: Cancel a booking
Each booking in the overview SHALL have a "Cancel" button. Cancelling SHALL remove the booking from the overview and from the system and SHALL free its seats immediately. The cancelled reference SHALL no longer show a confirmation.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 3 guests for the Riesling Evening that showed "9 seats left"
- **THEN** the booking disappears from the overview and the start page shows "12 seats left"

#### Scenario: Cancel twice
- **WHEN** a booking that is already cancelled is cancelled again
- **THEN** the server answers that it was not found and nothing else changes

#### Scenario: Failed cancel is visible
- **WHEN** the cancellation cannot be completed
- **THEN** staff see an error message and the booking stays in the list
