# Spec Delta

## Purpose

Lets guests see the winery's tastings with their remaining seats and book seats online, with a confirmation they can refer back to.

## ADDED Requirements

### Requirement: Tasting catalogue
The system SHALL offer exactly these tastings: "Riesling Evening" on 2026-11-06 at 18:00 for EUR 25 per guest with 12 seats; "Red Wine Cellar Tour" on 2026-11-14 at 15:00 for EUR 32 with 8 seats; "Winter Tasting" on 2026-12-05 at 17:00 for EUR 28 with 10 seats. The system SHALL start with no bookings.

#### Scenario: Fresh start
- **WHEN** the app has just started
- **THEN** every tasting has all its seats left and no booking exists

### Requirement: Tasting overview on the start page
The start page SHALL list every tasting with its title, date and time, price per guest and the seats left, written as "<n> seats left". Each tasting SHALL have a link or button named "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Start page content
- **WHEN** a guest opens the start page on a fresh system
- **THEN** "Riesling Evening", "Red Wine Cellar Tour" and "Winter Tasting" are listed with their date and time, price per guest, and "12 seats left", "8 seats left" and "10 seats left"
- **AND** links "Book Riesling Evening", "Book Red Wine Cellar Tour" and "Book Winter Tasting" are present

#### Scenario: Seats left follow bookings
- **WHEN** 3 guests have booked the Riesling Evening
- **THEN** the start page shows "9 seats left" for it

### Requirement: Booking form
Following "Book <tasting title>" SHALL open a booking form for that tasting with the fields "Name", "Email" and "Guests" and a button "Book". The form SHALL make clear which tasting is being booked.

#### Scenario: Open the form
- **WHEN** a guest follows "Book Winter Tasting"
- **THEN** a form with fields "Name", "Email", "Guests" and a button "Book" is shown, naming the Winter Tasting

### Requirement: Booking input validation
The system SHALL accept a booking only when Name is non-empty after trimming (at most 100 characters), Email is a syntactically valid address, and Guests is a whole number from 1 to 8. Each rejected input SHALL produce an error message shown next to the field it concerns, and no booking SHALL be created. The same rules SHALL hold when the booking is submitted directly to the server.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty or blank Name
- **THEN** an error message appears next to the Name field and no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits "not-an-email" as Email
- **THEN** an error message appears next to the Email field and no booking is created

#### Scenario: Guests out of range
- **WHEN** a guest submits 0, 9, 2.5 or an empty value as Guests
- **THEN** an error message appears next to the Guests field and no booking is created

#### Scenario: Several invalid fields
- **WHEN** a guest submits an empty Name and an invalid Email together
- **THEN** each field shows its own error message

#### Scenario: Direct submission with invalid data
- **WHEN** a booking request with invalid data reaches the server without going through the form
- **THEN** the server rejects it with field-specific error messages and creates no booking

### Requirement: Seats are never overbooked
A booking SHALL never take more seats than are left for its tasting, including when several bookings arrive at the same moment. A booking that asks for more seats than are left SHALL be rejected with an error message next to the Guests field stating how many seats are left, and the seats left SHALL stay unchanged.

#### Scenario: More guests than seats left
- **WHEN** 7 guests have booked the Red Wine Cellar Tour (1 seat left) and a guest asks for 2
- **THEN** the booking is rejected and an error next to Guests says only 1 seat is left
- **AND** the tasting still shows "1 seats left"

#### Scenario: Exactly the seats left
- **WHEN** a guest asks for as many guests as there are seats left
- **THEN** the booking succeeds and the tasting shows "0 seats left"

#### Scenario: Simultaneous bookings for the last seats
- **WHEN** two bookings of 2 guests arrive at the same moment for a tasting with 3 seats left
- **THEN** exactly one is accepted and the other is rejected for lack of seats

### Requirement: Fully booked tastings
A tasting with no seats left SHALL be shown on the start page as fully booked, SHALL show "0 seats left", and SHALL NOT offer a "Book <tasting title>" link. Opening its booking form directly SHALL show that it is fully booked instead of a usable form, and the server SHALL reject bookings for it.

#### Scenario: Last seats taken
- **WHEN** all 8 seats of the Red Wine Cellar Tour are booked
- **THEN** the start page marks it as fully booked and offers no "Book Red Wine Cellar Tour" link

#### Scenario: Seats freed again
- **WHEN** staff cancel a booking of a fully booked tasting
- **THEN** the start page shows its freed seats and offers the "Book" link again

### Requirement: Booking confirmation
After a successful booking the system SHALL show a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (guests times price per guest) and a booking reference. The reference SHALL be unique. The confirmation SHALL stay reachable at its own address, which shows no guest name or email.

#### Scenario: Successful booking
- **WHEN** a guest books 3 guests for the Riesling Evening with valid Name and Email
- **THEN** the page shows the heading "Booking confirmed", "Riesling Evening", 3 guests, a total of EUR 75 and a booking reference

#### Scenario: Reopen confirmation
- **WHEN** a guest reloads the confirmation page
- **THEN** the same confirmation is shown

#### Scenario: Unknown reference
- **WHEN** a guest opens a confirmation address with a reference that does not exist or was cancelled
- **THEN** a clear "booking not found" message is shown instead of a confirmation

### Requirement: Unknown tasting
The system SHALL answer a request for a tasting that does not exist with a clear not-found message and SHALL NOT create a booking for it.

#### Scenario: Unknown tasting address
- **WHEN** a guest opens the booking form of a tasting that does not exist
- **THEN** a not-found message with a link back to the start page is shown
