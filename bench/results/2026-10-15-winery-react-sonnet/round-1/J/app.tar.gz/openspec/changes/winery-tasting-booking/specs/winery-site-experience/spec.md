# Spec Delta

## Purpose

Defines the look, feel and usability of the guest and staff pages so the site feels like a small winery's own, works on phones and communicates states clearly.

## ADDED Requirements

### Requirement: Coherent winery branding
All pages SHALL share one visual design: the name "Weingut Kieselbrunnen" in a header, a consistent colour palette, typography and spacing, and a footer. Fonts SHALL be served by the app itself, not by an external service.

#### Scenario: Shared frame
- **WHEN** a guest moves between the start page, a booking form and a confirmation
- **THEN** the header with the winery name and the visual style stay the same

### Requirement: Usable on a phone
Every page SHALL be usable at a viewport width of 360 px without horizontal scrolling, with touch targets of at least 44 px height for buttons and form fields.

#### Scenario: Narrow viewport
- **WHEN** any page is shown at 360 px width
- **THEN** its content fits the width without horizontal scrolling and the Book and Sign in controls are fully visible

### Requirement: Clear states
The interface SHALL show distinct, labelled states: errors (next to the field and, for failures not tied to a field, in a visible message), success (the booking confirmation), loading, and fully booked tastings. State SHALL NOT be conveyed by colour alone.

#### Scenario: Field error
- **WHEN** a field is rejected
- **THEN** its message is placed next to the field, is linked to it for assistive technology, and the field is visibly marked

#### Scenario: Fully booked
- **WHEN** a tasting is fully booked
- **THEN** it carries a visible "Fully booked" label in addition to any colour change

#### Scenario: Server unreachable
- **WHEN** the tastings cannot be loaded
- **THEN** a visible error message explains it and offers a retry

### Requirement: Accessible forms
Each form field SHALL have a visible label that matches its accessible name ("Name", "Email", "Guests", "Password"), and each form SHALL be submittable with the keyboard.

#### Scenario: Labels
- **WHEN** a user looks up a form field by its label text
- **THEN** exactly one field matches
