# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` (Node 22, scripts `build`, `start`, `dev`, `test`, `typecheck`), TypeScript, Vite, Vitest configs and `.gitignore`; verify `npm install` succeeds and `npm run typecheck` passes on the empty skeleton.

## 2. Booking domain (tests first)

- [x] 2.1 Write failing tests for the shared zod schemas and price formatting (`shared/`), then implement them; verify `npm test -- shared` passes.
- [x] 2.2 Write failing tests for `BookingService` (catalogue, seats left, capacity rejection, exact-fit booking, cancel frees seats, unique references), then implement it; verify the tests pass.

## 3. HTTP API (tests first)

- [x] 3.1 Write failing supertest tests for the guest endpoints (list, create with validation errors per field, capacity error on `guests`, 404, public confirmation without PII, simultaneous bookings), then implement them; verify tests pass.
- [x] 3.2 Write failing supertest tests for staff auth and bookings (wrong/empty password, unset `STAFF_PASSWORD`, protected routes, grouped list, cancel, cancel twice, sign out), then implement them; verify tests pass.
- [x] 3.3 Serve the built client with SPA fallback and read `PORT`; verify with a test that `/staff` returns the HTML shell and `/api/unknown` returns JSON 404.

## 4. Guest interface (tests first)

- [x] 4.1 Add the app shell: Tailwind theme, bundled fonts, header/footer, routes, shared Button/Field/Badge components; verify the client builds.
- [x] 4.2 Write failing component tests for the start page (listing, "<n> seats left", "Book <title>" links, fully booked state, load error with retry), then implement; verify tests pass.
- [x] 4.3 Write failing component tests for the booking form (labels, per-field client errors, server field errors incl. capacity, success redirect, fully-booked and unknown tasting views), then implement; verify tests pass.
- [x] 4.4 Write failing component tests for the confirmation page ("Booking confirmed", tasting, guests, total, reference, not-found), then implement; verify tests pass.

## 5. Staff interface (tests first)

- [x] 5.1 Write failing component tests for sign-in (error next to Password), the grouped overview, empty groups, Cancel (removal and error state) and Sign out, then implement; verify tests pass.

## 6. Documentation and integration

- [x] 6.1 Write `README.md` (install, build, start, `PORT`, `STAFF_PASSWORD`, tests, in-memory note); verify the documented commands run as written.
- [x] 6.2 Run `npm run build` and `npm start` with `STAFF_PASSWORD` set; drive the real app (curl and, if a browser can be installed, Playwright at 360 px and desktop widths) through book → confirm → staff view → cancel → seats freed, and save screenshots for visual review.
- [x] 6.3 Run the full test suite, typecheck and `openspec validate winery-tasting-booking`; then review the diff (code-review) and fix findings.
