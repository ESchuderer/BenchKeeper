import cookieParser from 'cookie-parser';
import express, { type ErrorRequestHandler } from 'express';
import { existsSync } from 'node:fs';
import { extname, join } from 'node:path';
import helmet from 'helmet';
import { BookingService } from './booking-service';
import { guestRoutes } from './guest-routes';
import { staffRoutes } from './staff-routes';

export interface AppOptions {
  service?: BookingService;
  /** Value of STAFF_PASSWORD; staff cannot sign in when empty. */
  staffPassword?: string;
  /** Sign-in attempts allowed per IP and window before answering 429. */
  loginRateLimit?: { limit: number; windowMs: number };
  /** Express `trust proxy` setting, for deployments behind a reverse proxy. */
  trustProxy?: boolean | number | string;
  now?: () => number;
  /** Folder with the built React app (index.html and assets). Omit to serve the API only. */
  clientDir?: string;
}

export function createApp(options: AppOptions = {}) {
  const service = options.service ?? new BookingService();
  const app = express();

  app.disable('x-powered-by');
  if (options.trustProxy !== undefined) app.set('trust proxy', options.trustProxy);
  app.use(
    helmet({
      contentSecurityPolicy: { directives: { 'upgrade-insecure-requests': null } },
    }),
  );
  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  app.use('/api', guestRoutes(service));
  app.use(
    '/api',
    staffRoutes(service, {
      password: options.staffPassword ?? '',
      now: options.now ?? Date.now,
      loginRateLimit: options.loginRateLimit ?? { limit: 10, windowMs: 15 * 60 * 1000 },
    }),
  );
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found.' });
  });

  const { clientDir } = options;
  if (clientDir && existsSync(join(clientDir, 'index.html'))) {
    app.use(express.static(clientDir, { index: false, maxAge: '1h' }));
    // Client-side routes (/staff, /book/...) all load the same shell; missing files stay 404.
    app.get(/.*/, (req, res, next) => {
      if (extname(req.path)) return next();
      res.sendFile(join(clientDir, 'index.html'));
    });
  }

  const onError: ErrorRequestHandler = (err, _req, res, _next) => {
    const status = typeof err?.status === 'number' && err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 500 ? 'Something went wrong on our side.' : 'The request could not be read.' });
  };
  app.use(onError);

  return app;
}
