import { randomInt } from 'node:crypto';
import { bookingInputSchema, fieldErrors, type FieldErrors } from '../shared/schemas';
import { TASTINGS, type Tasting, type TastingView } from '../shared/tastings';

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  totalCents: number;
  createdAt: string;
}

export type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; kind: 'not_found' }
  | { ok: false; kind: 'invalid'; errors: FieldErrors };

export interface TastingBookings {
  tasting: TastingView;
  bookings: Booking[];
}

// No 0/O/1/I so references can be read out over the phone.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function randomReference(): string {
  let code = '';
  for (let i = 0; i < 8; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  return `KB-${code}`;
}

/**
 * In-memory tastings and bookings. Every method is synchronous, so the seat check
 * and the insert in `book` cannot interleave with another request.
 */
export class BookingService {
  private readonly bookings = new Map<string, Booking>();
  private readonly tastings: readonly Tasting[];
  private readonly generateReference: () => string;

  constructor(options: { tastings?: readonly Tasting[]; generateReference?: () => string } = {}) {
    this.tastings = options.tastings ?? TASTINGS;
    this.generateReference = options.generateReference ?? randomReference;
  }

  listTastings(): TastingView[] {
    return this.tastings.map((t) => this.view(t));
  }

  getTasting(id: string): TastingView | undefined {
    const tasting = this.tastings.find((t) => t.id === id);
    return tasting && this.view(tasting);
  }

  book(tastingId: string, input: unknown): BookResult {
    const tasting = this.getTasting(tastingId);
    if (!tasting) return { ok: false, kind: 'not_found' };

    // A missing or non-object body reports every field as missing rather than one vague error.
    const raw = typeof input === 'object' && input !== null && !Array.isArray(input) ? input : {};
    const parsed = bookingInputSchema.safeParse(raw);
    if (!parsed.success) return { ok: false, kind: 'invalid', errors: fieldErrors(parsed.error) };
    const { name, email, guests } = parsed.data;

    if (tasting.seatsLeft === 0) {
      return { ok: false, kind: 'invalid', errors: { guests: 'This tasting is fully booked.' } };
    }
    if (guests > tasting.seatsLeft) {
      const seats = tasting.seatsLeft === 1 ? '1 seat' : `${tasting.seatsLeft} seats`;
      return { ok: false, kind: 'invalid', errors: { guests: `Only ${seats} left for this tasting.` } };
    }

    const booking: Booking = {
      reference: this.uniqueReference(),
      tastingId,
      name,
      email,
      guests,
      totalCents: guests * tasting.priceCents,
      createdAt: new Date().toISOString(),
    };
    this.bookings.set(booking.reference, booking);
    return { ok: true, booking };
  }

  getBooking(reference: string): Booking | undefined {
    return this.bookings.get(reference);
  }

  cancel(reference: string): boolean {
    return this.bookings.delete(reference);
  }

  listByTasting(): TastingBookings[] {
    return this.listTastings().map((tasting) => ({
      tasting,
      bookings: [...this.bookings.values()].filter((b) => b.tastingId === tasting.id),
    }));
  }

  private view(tasting: Tasting): TastingView {
    let taken = 0;
    for (const b of this.bookings.values()) if (b.tastingId === tasting.id) taken += b.guests;
    return { ...tasting, seatsLeft: tasting.capacity - taken };
  }

  private uniqueReference(): string {
    let reference = this.generateReference();
    while (this.bookings.has(reference)) reference = this.generateReference();
    return reference;
  }
}
