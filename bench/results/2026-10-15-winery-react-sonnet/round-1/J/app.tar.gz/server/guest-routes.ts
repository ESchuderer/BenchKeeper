import { Router } from 'express';
import type { Booking, BookingService } from './booking-service';

/** What a guest may see about a booking: no name, no email. */
export function publicBooking(service: BookingService, booking: Booking) {
  const tasting = service.getTasting(booking.tastingId);
  return {
    reference: booking.reference,
    guests: booking.guests,
    totalCents: booking.totalCents,
    tasting: tasting && { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt, priceCents: tasting.priceCents },
  };
}

export function guestRoutes(service: BookingService) {
  const router = Router();

  router.get('/tastings', (_req, res) => {
    res.json({ tastings: service.listTastings() });
  });

  router.get('/tastings/:id', (req, res) => {
    const tasting = service.getTasting(req.params.id);
    if (!tasting) return void res.status(404).json({ error: 'Tasting not found.' });
    res.json({ tasting });
  });

  router.post('/tastings/:id/bookings', (req, res) => {
    const result = service.book(req.params.id, req.body);
    if (result.ok) return void res.status(201).json({ booking: publicBooking(service, result.booking) });
    if (result.kind === 'not_found') return void res.status(404).json({ error: 'Tasting not found.' });
    res.status(422).json({ errors: result.errors });
  });

  router.get('/bookings/:reference', (req, res) => {
    const booking = service.getBooking(req.params.reference);
    if (!booking) return void res.status(404).json({ error: 'Booking not found.' });
    res.json({ booking: publicBooking(service, booking) });
  });

  return router;
}
