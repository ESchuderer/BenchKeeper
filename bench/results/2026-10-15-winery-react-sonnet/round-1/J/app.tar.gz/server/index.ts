import { fileURLToPath } from 'node:url';
import { createApp } from './app';

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD ?? '';
const trustProxy = process.env.TRUST_PROXY;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: nobody can sign in at /staff.');
}

const app = createApp({
  staffPassword,
  clientDir: fileURLToPath(new URL('../client', import.meta.url)),
  trustProxy: trustProxy === undefined ? undefined : /^\d+$/.test(trustProxy) ? Number(trustProxy) : trustProxy === 'true' ? true : trustProxy,
});

const server = app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings running on http://localhost:${port}`);
});

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
