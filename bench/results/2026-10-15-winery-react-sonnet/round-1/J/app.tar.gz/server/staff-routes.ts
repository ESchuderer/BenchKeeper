import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { Router, type RequestHandler } from 'express';
import { rateLimit } from 'express-rate-limit';
import { fieldErrors, staffLoginSchema } from '../shared/schemas';
import type { BookingService } from './booking-service';

const COOKIE = 'kb_staff';
const SESSION_MS = 8 * 60 * 60 * 1000;

export interface StaffOptions {
  password: string;
  now: () => number;
  loginRateLimit: { limit: number; windowMs: number };
}

function sha256(value: string) {
  return createHash('sha256').update(value).digest();
}

function passwordMatches(expected: string, given: string): boolean {
  if (expected === '') return false;
  return timingSafeEqual(sha256(expected), sha256(given));
}

export function staffRoutes(service: BookingService, options: StaffOptions) {
  const router = Router();
  const sessions = new Map<string, number>();

  const isSignedIn = (token: unknown): boolean => {
    if (typeof token !== 'string') return false;
    const expiresAt = sessions.get(token);
    if (expiresAt === undefined) return false;
    if (expiresAt <= options.now()) {
      sessions.delete(token);
      return false;
    }
    return true;
  };

  const requireStaff: RequestHandler = (req, res, next) => {
    if (!isSignedIn(req.cookies?.[COOKIE])) return void res.status(401).json({ error: 'Please sign in as staff.' });
    next();
  };

  const loginLimiter = rateLimit({
    windowMs: options.loginRateLimit.windowMs,
    limit: options.loginRateLimit.limit,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => {
      res.status(429).json({ errors: { password: 'Too many attempts. Please wait a few minutes and try again.' } });
    },
  });

  router.post('/staff/session', loginLimiter, (req, res) => {
    const parsed = staffLoginSchema.safeParse(req.body ?? {});
    if (!parsed.success) return void res.status(422).json({ errors: fieldErrors(parsed.error) });
    if (!passwordMatches(options.password, parsed.data.password)) {
      return void res.status(401).json({ errors: { password: 'Incorrect password.' } });
    }
    for (const [id, expiresAt] of sessions) if (expiresAt <= options.now()) sessions.delete(id);
    const token = randomBytes(32).toString('hex');
    sessions.set(token, options.now() + SESSION_MS);
    res.cookie(COOKIE, token, {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure,
      maxAge: SESSION_MS,
      path: '/',
    });
    res.json({ signedIn: true });
  });

  router.get('/staff/session', (req, res) => {
    res.json({ signedIn: isSignedIn(req.cookies?.[COOKIE]) });
  });

  router.delete('/staff/session', (req, res) => {
    const token = req.cookies?.[COOKIE];
    if (typeof token === 'string') sessions.delete(token);
    res.clearCookie(COOKIE, { path: '/' });
    res.status(204).end();
  });

  router.get('/staff/bookings', requireStaff, (_req, res) => {
    res.json({
      groups: service.listByTasting().map(({ tasting, bookings }) => ({
        tasting,
        bookings: bookings.map(({ reference, name, email, guests, totalCents }) => ({
          reference,
          name,
          email,
          guests,
          totalCents,
        })),
      })),
    });
  });

  router.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!service.cancel(String(req.params.reference))) return void res.status(404).json({ error: 'Booking not found.' });
    res.status(204).end();
  });

  return router;
}
