export function formatEur(cents: number): string {
  const euros = cents / 100;
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`;
}

const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/** Splits `YYYY-MM-DDTHH:mm` into display parts without any timezone conversion. */
export function describeStart(startsAt: string) {
  const [date = '', time = ''] = startsAt.split('T');
  const [y = 0, m = 1, d = 1] = date.split('-').map(Number);
  const weekday = WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()] ?? '';
  const month = new Date(Date.UTC(y, m - 1, d)).toLocaleString('en-GB', { month: 'short', timeZone: 'UTC' });
  return { weekday, date, time, day: String(d).padStart(2, '0'), month };
}
