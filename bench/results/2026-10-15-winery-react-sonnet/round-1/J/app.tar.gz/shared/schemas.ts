import { z } from 'zod';
import { MAX_GUESTS_PER_BOOKING } from './tastings';

const guestsMessage = `Enter a whole number of guests from 1 to ${MAX_GUESTS_PER_BOOKING}.`;

export const bookingInputSchema = z.object({
  name: z
    .string({ error: 'Please enter your name.' })
    .trim()
    .min(1, 'Please enter your name.')
    .max(100, 'Please use at most 100 characters.'),
  email: z
    .string({ error: 'Please enter your email address.' })
    .trim()
    .min(1, 'Please enter your email address.')
    .max(254, 'This email address is too long.')
    .pipe(z.email('Please enter a valid email address, like name@example.com.')),
  guests: z
    .number({ error: guestsMessage })
    .int(guestsMessage)
    .min(1, guestsMessage)
    .max(MAX_GUESTS_PER_BOOKING, guestsMessage),
});

export type BookingInput = z.infer<typeof bookingInputSchema>;

export const staffLoginSchema = z.object({
  password: z.string({ error: 'Please enter the password.' }).min(1, 'Please enter the password.'),
});

export type FieldErrors = Record<string, string>;

/** First message per field, in the shape the API returns and forms display. */
export function fieldErrors(error: z.ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? 'form');
    if (!(key in out)) out[key] = issue.message;
  }
  return out;
}
