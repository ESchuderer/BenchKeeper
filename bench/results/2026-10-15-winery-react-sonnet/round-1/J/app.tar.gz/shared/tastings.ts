export interface Tasting {
  id: string;
  title: string;
  /** Local winery time, `YYYY-MM-DDTHH:mm`. */
  startsAt: string;
  priceCents: number;
  capacity: number;
  description: string;
}

export const TASTINGS: readonly Tasting[] = [
  {
    id: 'riesling-evening',
    title: 'Riesling Evening',
    startsAt: '2026-11-06T18:00',
    priceCents: 2500,
    capacity: 12,
    description: 'Six estate Rieslings, from steely dry to gently sweet, poured at the long table in our vaulted tasting room.',
  },
  {
    id: 'red-wine-cellar-tour',
    title: 'Red Wine Cellar Tour',
    startsAt: '2026-11-14T15:00',
    priceCents: 3200,
    capacity: 8,
    description: 'A guided walk through the barrel cellar with barrel samples of our Spätburgunder and Dornfelder.',
  },
  {
    id: 'winter-tasting',
    title: 'Winter Tasting',
    startsAt: '2026-12-05T17:00',
    priceCents: 2800,
    capacity: 10,
    description: 'Cosy candlelit tasting of our full-bodied whites and reds with bread, cheese and mulled wine.',
  },
];

export const MAX_GUESTS_PER_BOOKING = 8;

/** A tasting together with its current availability, as sent to guests. */
export interface TastingView extends Tasting {
  seatsLeft: number;
}
