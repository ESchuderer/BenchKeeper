// @vitest-environment jsdom
import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { guest, renderApp, useBackend } from './helpers';

const backend = useBackend();

async function openForm(id = 'riesling-evening') {
  renderApp(`/book/${id}`);
  await screen.findByRole('button', { name: 'Book' });
}

const nameField = () => screen.getByLabelText('Name');
const emailField = () => screen.getByLabelText('Email');
const guestsField = () => screen.getByLabelText('Guests');

async function fill({ name, email, guests }: { name?: string; email?: string; guests?: string }) {
  const user = userEvent.setup();
  if (name !== undefined) await user.type(nameField(), name);
  if (email !== undefined) await user.type(emailField(), email);
  if (guests !== undefined) await user.type(guestsField(), guests);
  return user;
}

describe('booking form', () => {
  it('shows the tasting and the fields Name, Email and Guests with a Book button', async () => {
    await openForm('winter-tasting');
    expect(screen.getByRole('heading', { name: /Winter Tasting/ })).toBeInTheDocument();
    expect(nameField()).toBeRequired();
    expect(emailField()).toHaveAttribute('type', 'email');
    expect(guestsField()).toHaveAttribute('type', 'number');
    expect(guestsField()).toHaveAttribute('min', '1');
    expect(guestsField()).toHaveAttribute('max', '8');
    expect(screen.getByRole('button', { name: 'Book' })).toBeEnabled();
  });

  it('shows an error next to every empty field and books nothing', async () => {
    await openForm();
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByLabelText('Name')).toHaveAccessibleDescription(/enter your name/i);
    expect(emailField()).toHaveAccessibleDescription(/enter your email/i);
    expect(guestsField()).toHaveAccessibleDescription(/from 1 to 8/i);
    expect(nameField()).toBeInvalid();
    expect(backend.service.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });

  it('rejects a malformed email next to the Email field', async () => {
    await openForm();
    const user = await fill({ name: 'Anna', email: 'not-an-email', guests: '2' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText(/valid email address/i)).toBeInTheDocument();
    expect(emailField()).toHaveAccessibleDescription(/valid email address/i);
    expect(nameField()).not.toHaveAttribute('aria-invalid');
  });

  it.each(['0', '9', '2.5', '-1'])('rejects %s guests next to the Guests field', async (guests) => {
    await openForm();
    const user = await fill({ name: 'Anna', email: 'anna@example.com', guests });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(guestsField()).toHaveAccessibleDescription(/from 1 to 8/i));
    expect(backend.service.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });

  it('shows the server message next to Guests when seats were taken meanwhile', async () => {
    await openForm('red-wine-cellar-tour');
    backend.service.book('red-wine-cellar-tour', guest(7));
    const user = await fill({ name: 'Anna', email: 'anna@example.com', guests: '2' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(guestsField()).toHaveAccessibleDescription(/only 1 seat left/i));
    expect(backend.service.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(1);
  });

  it('creates the booking when everything is valid', async () => {
    await openForm();
    const user = await fill({ name: 'Anna Weber', email: 'anna@example.com', guests: '3' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(backend.service.getTasting('riesling-evening')?.seatsLeft).toBe(9));
  });

  it('shows a visible error when the server cannot be reached and keeps the input', async () => {
    await openForm();
    const user = await fill({ name: 'Anna Weber', email: 'anna@example.com', guests: '3' });
    backend.failRequests(1);
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach the server/i);
    expect(nameField()).toHaveValue('Anna Weber');
  });

  it('shows a fully booked notice instead of a form', async () => {
    backend.service.book('red-wine-cellar-tour', guest(8));
    renderApp('/book/red-wine-cellar-tour');
    expect(await screen.findByRole('heading', { name: /fully booked/i })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: /other tastings/i })).toHaveAttribute('href', '/');
  });

  it('shows a not-found message for an unknown tasting', async () => {
    renderApp('/book/nope');
    expect(await screen.findByRole('heading', { name: /tasting not found/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /back to the tastings/i })).toHaveAttribute('href', '/');
  });
});
