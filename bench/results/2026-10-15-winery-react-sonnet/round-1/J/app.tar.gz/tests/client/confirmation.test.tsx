// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { guest, renderApp, useBackend } from './helpers';

const backend = useBackend();

describe('booking confirmation', () => {
  it('shows tasting, guests, total price and reference for a booking', async () => {
    const result = backend.service.book('riesling-evening', guest(3));
    if (!result.ok) throw new Error('setup failed');
    renderApp(`/booking/${result.booking.reference}`);

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const details = within(screen.getByRole('region', { name: /booking details/i }));
    expect(details.getByText('Riesling Evening')).toBeInTheDocument();
    expect(details.getByText('2026-11-06 18:00')).toBeInTheDocument();
    expect(details.getByText('3 guests')).toBeInTheDocument();
    expect(details.getByText('EUR 75')).toBeInTheDocument();
    expect(details.getByText(result.booking.reference)).toBeInTheDocument();
  });

  it('does not show the name or email of the guest', async () => {
    const result = backend.service.book('riesling-evening', guest(1, 'Zora Private'));
    if (!result.ok) throw new Error('setup failed');
    renderApp(`/booking/${result.booking.reference}`);
    await screen.findByRole('heading', { name: 'Booking confirmed' });
    expect(screen.queryByText(/Zora/)).not.toBeInTheDocument();
    expect(screen.queryByText(/anna@example.com/)).not.toBeInTheDocument();
  });

  it('is reached after submitting the booking form', async () => {
    renderApp('/book/winter-tasting');
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Name'), 'Anna Weber');
    await user.type(screen.getByLabelText('Email'), 'anna@example.com');
    await user.type(screen.getByLabelText('Guests'), '4');
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const details = within(screen.getByRole('region', { name: /booking details/i }));
    expect(details.getByText('Winter Tasting')).toBeInTheDocument();
    expect(details.getByText('EUR 112')).toBeInTheDocument();
    expect(details.getByText(/^KB-[A-Z2-9]{8}$/)).toBeInTheDocument();
  });

  it('shows the lowered seat count on the start page afterwards', async () => {
    const result = backend.service.book('winter-tasting', guest(4));
    if (!result.ok) throw new Error('setup failed');
    renderApp(`/booking/${result.booking.reference}`);
    await userEvent.click(await screen.findByRole('link', { name: /all tastings/i }));
    expect(await screen.findByText('6 seats left')).toBeInTheDocument();
  });

  it('shows a not-found message for an unknown or cancelled reference', async () => {
    const result = backend.service.book('winter-tasting', guest(1));
    if (!result.ok) throw new Error('setup failed');
    backend.service.cancel(result.booking.reference);
    renderApp(`/booking/${result.booking.reference}`);
    expect(await screen.findByRole('heading', { name: /booking not found/i })).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
  });
});
