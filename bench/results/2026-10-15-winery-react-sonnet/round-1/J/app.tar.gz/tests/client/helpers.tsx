import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render } from '@testing-library/react';
import type { AddressInfo } from 'node:net';
import type { Server } from 'node:http';
import { MemoryRouter } from 'react-router';
import { afterEach, beforeEach, vi } from 'vitest';
import { AppRoutes } from '../../client/App';
import { createApp } from '../../server/app';
import { BookingService } from '../../server/booking-service';

export const STAFF_PASSWORD = 'winery-secret';

export interface Backend {
  service: BookingService;
  /** Make the next `count` requests fail as if the network were down. */
  failRequests(count: number): void;
}

/**
 * Runs the real Express app on a free port and points the browser-side `fetch` at it,
 * keeping cookies like a browser would, so component tests exercise the real API.
 */
export function useBackend(): Backend {
  const backend: Backend = { service: new BookingService(), failRequests: () => {} };
  let server: Server;
  let failures = 0;
  const cookies = new Map<string, string>();
  const realFetch = globalThis.fetch;

  beforeEach(async () => {
    backend.service = new BookingService();
    failures = 0;
    cookies.clear();
    server = createApp({ service: backend.service, staffPassword: STAFF_PASSWORD }).listen(0);
    await new Promise((resolve) => server.once('listening', resolve));
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

    vi.stubGlobal('fetch', async (input: string, init: RequestInit = {}) => {
      if (failures > 0) {
        failures--;
        throw new TypeError('network down');
      }
      const headers = new Headers(init.headers);
      if (cookies.size) headers.set('Cookie', [...cookies].map(([k, v]) => `${k}=${v}`).join('; '));
      const res = await realFetch(base + input, { ...init, headers });
      for (const line of res.headers.getSetCookie()) {
        const [pair = ''] = line.split(';');
        const [name = '', ...rest] = pair.split('=');
        const value = rest.join('=');
        if (/max-age=0|expires=thu, 01 jan 1970/i.test(line) || value === '') cookies.delete(name);
        else cookies.set(name, value);
      }
      return res;
    });
    backend.failRequests = (count) => {
      failures = count;
    };
  });

  afterEach(async () => {
    vi.unstubAllGlobals();
    await new Promise((resolve) => server.close(resolve));
  });

  return backend;
}

export function renderApp(route = '/') {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0 } } });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[route]}>
        <AppRoutes />
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

export const guest = (guests: number, name = 'Anna Weber') => ({ name, email: 'anna@example.com', guests });
