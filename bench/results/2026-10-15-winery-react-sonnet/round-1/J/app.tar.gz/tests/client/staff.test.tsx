// @vitest-environment jsdom
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { STAFF_PASSWORD, guest, renderApp, useBackend } from './helpers';

const backend = useBackend();

async function signIn(password = STAFF_PASSWORD) {
  const user = userEvent.setup();
  await user.type(await screen.findByLabelText('Password'), password);
  await user.click(screen.getByRole('button', { name: 'Sign in' }));
  return user;
}

const group = async (title: string) => within((await screen.findByRole('heading', { name: new RegExp(title) })).closest('section') as HTMLElement);

describe('staff sign-in', () => {
  it('asks for a password', async () => {
    renderApp('/staff');
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('Cancel')).not.toBeInTheDocument();
  });

  it('shows an error next to the Password field for a wrong password', async () => {
    backend.service.book('riesling-evening', guest(2, 'Secret Guest'));
    renderApp('/staff');
    await signIn('wrong');
    await waitFor(() => expect(screen.getByLabelText('Password')).toHaveAccessibleDescription(/incorrect password/i));
    expect(screen.queryByText('Secret Guest')).not.toBeInTheDocument();
  });

  it('shows an error next to the Password field when it is empty', async () => {
    renderApp('/staff');
    await userEvent.click(await screen.findByRole('button', { name: 'Sign in' }));
    await waitFor(() => expect(screen.getByLabelText('Password')).toHaveAccessibleDescription(/enter the password/i));
  });
});

describe('staff overview', () => {
  it('groups bookings by tasting with name, email, guests and reference', async () => {
    const a = backend.service.book('riesling-evening', { name: 'Anna Weber', email: 'anna@example.com', guests: 2 });
    backend.service.book('winter-tasting', { name: 'Carla Roth', email: 'carla@example.com', guests: 4 });
    if (!a.ok) throw new Error('setup failed');
    renderApp('/staff');
    await signIn();

    const riesling = await group('Riesling Evening');
    expect(riesling.getByText('Anna Weber')).toBeInTheDocument();
    expect(riesling.getByText('anna@example.com')).toBeInTheDocument();
    expect(riesling.getByText('2 guests')).toBeInTheDocument();
    expect(riesling.getByText(a.booking.reference)).toBeInTheDocument();

    const winter = await group('Winter Tasting');
    expect(winter.getByText('Carla Roth')).toBeInTheDocument();
    expect(winter.queryByText('Anna Weber')).not.toBeInTheDocument();

    const red = await group('Red Wine Cellar Tour');
    expect(red.getByText(/no bookings yet/i)).toBeInTheDocument();
  });

  it('cancels a booking, removes it from the list and frees its seats', async () => {
    backend.service.book('riesling-evening', { name: 'Anna Weber', email: 'anna@example.com', guests: 3 });
    backend.service.book('riesling-evening', { name: 'Ben Koch', email: 'ben@example.com', guests: 1 });
    renderApp('/staff');
    const user = await signIn();

    const riesling = await group('Riesling Evening');
    const row = (await riesling.findByText('Anna Weber')).closest('li') as HTMLElement;
    await user.click(within(row).getByRole('button', { name: 'Cancel' }));

    await waitFor(() => expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument());
    expect(screen.getByText('Ben Koch')).toBeInTheDocument();
    expect(backend.service.getTasting('riesling-evening')?.seatsLeft).toBe(11);
  });

  it('keeps the booking and shows an error when cancelling fails', async () => {
    backend.service.book('riesling-evening', { name: 'Anna Weber', email: 'anna@example.com', guests: 3 });
    renderApp('/staff');
    const user = await signIn();
    await screen.findByText('Anna Weber');
    backend.failRequests(1);
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach the server/i);
    expect(screen.getByText('Anna Weber')).toBeInTheDocument();
    expect(backend.service.getTasting('riesling-evening')?.seatsLeft).toBe(9);
  });

  it('returns to the sign-in form when the session has ended', async () => {
    backend.service.book('riesling-evening', guest(1));
    renderApp('/staff');
    const user = await signIn();
    await screen.findByText('Anna Weber');
    await fetch('/api/staff/session', { method: 'DELETE' }); // e.g. signed out in another tab
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(backend.service.getTasting('riesling-evening')?.seatsLeft).toBe(11);
  });

  it('stays signed in after a reload and asks again after signing out', async () => {
    backend.service.book('riesling-evening', guest(1));
    const first = renderApp('/staff');
    await signIn();
    await screen.findByText('Anna Weber');
    first.unmount();

    renderApp('/staff');
    expect(await screen.findByText('Anna Weber')).toBeInTheDocument();
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument();
  });
});
