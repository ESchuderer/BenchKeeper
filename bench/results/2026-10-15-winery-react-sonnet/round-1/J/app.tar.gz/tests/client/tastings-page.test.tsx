// @vitest-environment jsdom
import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { guest, renderApp, useBackend } from './helpers';

const backend = useBackend();

async function card(title: string) {
  const heading = await screen.findByRole('heading', { name: title });
  return within(heading.closest('article') as HTMLElement);
}

describe('start page', () => {
  it('lists each tasting with date and time, price per guest and seats left', async () => {
    renderApp('/');
    const riesling = await card('Riesling Evening');
    expect(riesling.getByText('2026-11-06 18:00')).toBeInTheDocument();
    expect(riesling.getByText(/EUR 25\b/)).toBeInTheDocument();
    expect(riesling.getByText('12 seats left')).toBeInTheDocument();

    const red = await card('Red Wine Cellar Tour');
    expect(red.getByText('2026-11-14 15:00')).toBeInTheDocument();
    expect(red.getByText(/EUR 32\b/)).toBeInTheDocument();
    expect(red.getByText('8 seats left')).toBeInTheDocument();

    const winter = await card('Winter Tasting');
    expect(winter.getByText('2026-12-05 17:00')).toBeInTheDocument();
    expect(winter.getByText(/EUR 28\b/)).toBeInTheDocument();
    expect(winter.getByText('10 seats left')).toBeInTheDocument();
  });

  it('offers a "Book <title>" link to each tasting form', async () => {
    renderApp('/');
    for (const [title, id] of [
      ['Riesling Evening', 'riesling-evening'],
      ['Red Wine Cellar Tour', 'red-wine-cellar-tour'],
      ['Winter Tasting', 'winter-tasting'],
    ]) {
      expect(await screen.findByRole('link', { name: `Book ${title}` })).toHaveAttribute('href', `/book/${id}`);
    }
  });

  it('shows seats left after bookings', async () => {
    backend.service.book('riesling-evening', guest(3));
    renderApp('/');
    expect(await screen.findByText('9 seats left')).toBeInTheDocument();
  });

  it('marks a fully booked tasting and drops its Book link', async () => {
    backend.service.book('red-wine-cellar-tour', guest(8));
    renderApp('/');
    const red = await card('Red Wine Cellar Tour');
    expect(red.getByText('Fully booked')).toBeInTheDocument();
    expect(red.getByText('0 seats left')).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toBeInTheDocument();
  });

  it('shows a loading state, then an error with a working retry', async () => {
    backend.failRequests(1);
    renderApp('/');
    expect(screen.getByRole('status')).toHaveTextContent(/loading/i);
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach the server/i);
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
  });
});
