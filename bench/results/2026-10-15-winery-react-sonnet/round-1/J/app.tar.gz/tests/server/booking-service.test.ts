import { beforeEach, describe, expect, it } from 'vitest';
import { BookingService } from '../../server/booking-service';

const guest = (guests: number, name = 'Anna Weber') => ({ name, email: 'anna@example.com', guests });

let service: BookingService;
beforeEach(() => {
  service = new BookingService();
});

function bookOk(tastingId: string, guests: number, name?: string) {
  const result = service.book(tastingId, guest(guests, name));
  if (!result.ok) throw new Error(`booking failed: ${JSON.stringify(result)}`);
  return result.booking;
}

describe('catalogue', () => {
  it('starts with all seats left and no bookings', () => {
    expect(service.listTastings().map((t) => [t.id, t.seatsLeft])).toEqual([
      ['riesling-evening', 12],
      ['red-wine-cellar-tour', 8],
      ['winter-tasting', 10],
    ]);
    expect(service.listByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });

  it('finds a tasting by id and returns undefined for unknown ids', () => {
    expect(service.getTasting('winter-tasting')?.title).toBe('Winter Tasting');
    expect(service.getTasting('nope')).toBeUndefined();
  });
});

describe('book', () => {
  it('creates a booking with total price and reduces seats left', () => {
    const booking = bookOk('riesling-evening', 3);
    expect(booking).toMatchObject({ tastingId: 'riesling-evening', guests: 3, totalCents: 7500, name: 'Anna Weber' });
    expect(booking.reference).toMatch(/^KB-[A-Z2-9]{8}$/);
    expect(service.getTasting('riesling-evening')?.seatsLeft).toBe(9);
  });

  it('gives every booking a different reference', () => {
    const refs = new Set(Array.from({ length: 12 }, () => bookOk('riesling-evening', 1).reference));
    expect(refs.size).toBe(12);
  });

  it('regenerates a reference on collision', () => {
    const refs = ['KB-AAAAAAAA', 'KB-AAAAAAAA', 'KB-BBBBBBBB'];
    const s = new BookingService({ generateReference: () => refs.shift() ?? 'KB-ZZZZZZZZ' });
    const first = s.book('winter-tasting', guest(1));
    const second = s.book('winter-tasting', guest(1));
    expect(first.ok && second.ok && [first.booking.reference, second.booking.reference]).toEqual(['KB-AAAAAAAA', 'KB-BBBBBBBB']);
  });

  it('rejects invalid input with field errors and books nothing', () => {
    const result = service.book('riesling-evening', { name: '', email: 'x', guests: 0 });
    expect(result).toMatchObject({ ok: false, kind: 'invalid' });
    if (!result.ok && result.kind === 'invalid') {
      expect(Object.keys(result.errors).sort()).toEqual(['email', 'guests', 'name']);
    }
    expect(service.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });

  it('reports an unknown tasting', () => {
    expect(service.book('nope', guest(1))).toEqual({ ok: false, kind: 'not_found' });
  });

  it('rejects more guests than seats left, naming the seats left on the guests field', () => {
    bookOk('red-wine-cellar-tour', 7);
    const result = service.book('red-wine-cellar-tour', guest(2));
    expect(result.ok).toBe(false);
    if (!result.ok && result.kind === 'invalid') {
      expect(result.errors.guests).toMatch(/only 1 seat left/i);
    }
    expect(service.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(1);
  });

  it('accepts exactly the seats left', () => {
    bookOk('red-wine-cellar-tour', 8);
    expect(service.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(0);
  });

  it('rejects any booking for a fully booked tasting', () => {
    bookOk('red-wine-cellar-tour', 8);
    const result = service.book('red-wine-cellar-tour', guest(1));
    expect(result.ok).toBe(false);
    if (!result.ok && result.kind === 'invalid') expect(result.errors.guests).toMatch(/fully booked/i);
  });

  it('never overbooks across many bookings', () => {
    for (let i = 0; i < 20; i++) service.book('winter-tasting', guest(3));
    expect(service.getTasting('winter-tasting')?.seatsLeft).toBe(1);
  });
});

describe('cancel', () => {
  it('removes the booking and frees its seats', () => {
    const booking = bookOk('riesling-evening', 4);
    expect(service.cancel(booking.reference)).toBe(true);
    expect(service.getBooking(booking.reference)).toBeUndefined();
    expect(service.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });

  it('allows booking again after a fully booked tasting is cancelled', () => {
    const booking = bookOk('red-wine-cellar-tour', 8);
    service.cancel(booking.reference);
    expect(service.book('red-wine-cellar-tour', guest(2)).ok).toBe(true);
  });

  it('returns false for an unknown or already cancelled reference', () => {
    const booking = bookOk('riesling-evening', 1);
    expect(service.cancel('KB-UNKNOWN0')).toBe(false);
    expect(service.cancel(booking.reference)).toBe(true);
    expect(service.cancel(booking.reference)).toBe(false);
  });
});

describe('listByTasting', () => {
  it('groups bookings under their tasting in catalogue order', () => {
    bookOk('winter-tasting', 1, 'Carl');
    bookOk('riesling-evening', 2, 'Anna');
    bookOk('riesling-evening', 1, 'Ben');
    const groups = service.listByTasting();
    expect(groups.map((g) => [g.tasting.id, g.bookings.map((b) => b.name)])).toEqual([
      ['riesling-evening', ['Anna', 'Ben']],
      ['red-wine-cellar-tour', []],
      ['winter-tasting', ['Carl']],
    ]);
  });
});
