import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../server/app';
import { BookingService } from '../../server/booking-service';

let service: BookingService;
let app: ReturnType<typeof createApp>;

beforeEach(() => {
  service = new BookingService();
  app = createApp({ service, staffPassword: 'secret' });
});

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 3 };
const post = (id: string, body: unknown) => request(app).post(`/api/tastings/${id}/bookings`).send(body as object);

describe('GET /api/tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const res = await request(app).get('/api/tastings');
    expect(res.status).toBe(200);
    expect(res.body.tastings).toHaveLength(3);
    expect(res.body.tastings[0]).toMatchObject({
      id: 'riesling-evening',
      title: 'Riesling Evening',
      startsAt: '2026-11-06T18:00',
      priceCents: 2500,
      seatsLeft: 12,
    });
  });

  it('reflects bookings in seats left', async () => {
    await post('riesling-evening', valid);
    const res = await request(app).get('/api/tastings');
    expect(res.body.tastings[0].seatsLeft).toBe(9);
  });
});

describe('GET /api/tastings/:id', () => {
  it('returns one tasting', async () => {
    const res = await request(app).get('/api/tastings/winter-tasting');
    expect(res.status).toBe(200);
    expect(res.body.tasting).toMatchObject({ title: 'Winter Tasting', seatsLeft: 10 });
  });

  it('answers 404 for an unknown tasting', async () => {
    const res = await request(app).get('/api/tastings/nope');
    expect(res.status).toBe(404);
    expect(res.body.error).toMatch(/not found/i);
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  it('creates a booking and returns the confirmation data without personal data', async () => {
    const res = await post('riesling-evening', valid);
    expect(res.status).toBe(201);
    expect(res.body.booking).toMatchObject({
      guests: 3,
      totalCents: 7500,
      tasting: { id: 'riesling-evening', title: 'Riesling Evening' },
    });
    expect(res.body.booking.reference).toMatch(/^KB-/);
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
    expect(JSON.stringify(res.body)).not.toContain('Anna');
  });

  it('answers 422 with a message per invalid field', async () => {
    const res = await post('riesling-evening', { name: '', email: 'nope', guests: 9 });
    expect(res.status).toBe(422);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
    expect(service.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });

  it('rejects an empty body and a JSON array with 422', async () => {
    const empty = await request(app).post('/api/tastings/riesling-evening/bookings');
    expect(empty.status).toBe(422);
    expect(Object.keys(empty.body.errors).sort()).toEqual(['email', 'guests', 'name']);
    const array = await request(app).post('/api/tastings/riesling-evening/bookings').send([]);
    expect(array.status).toBe(422);
  });

  it('answers 400 JSON for malformed JSON', async () => {
    const res = await request(app)
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{"name":');
    expect(res.status).toBe(400);
    expect(res.body.error).toBeTruthy();
  });

  it('rejects more guests than seats left on the guests field', async () => {
    await post('red-wine-cellar-tour', { ...valid, guests: 7 });
    const res = await post('red-wine-cellar-tour', { ...valid, guests: 2 });
    expect(res.status).toBe(422);
    expect(res.body.errors.guests).toMatch(/only 1 seat left/i);
  });

  it('answers 404 for an unknown tasting', async () => {
    expect((await post('nope', valid)).status).toBe(404);
  });

  it('accepts exactly one of two simultaneous bookings that cannot both fit', async () => {
    await post('winter-tasting', { ...valid, guests: 7 }); // 3 seats left
    const results = await Promise.all([
      post('winter-tasting', { ...valid, guests: 2 }),
      post('winter-tasting', { ...valid, guests: 2 }),
    ]);
    expect(results.map((r) => r.status).sort()).toEqual([201, 422]);
    expect(service.getTasting('winter-tasting')?.seatsLeft).toBe(1);
  });

  it('never exceeds capacity under a burst of requests', async () => {
    const results = await Promise.all(Array.from({ length: 30 }, () => post('red-wine-cellar-tour', { ...valid, guests: 1 })));
    expect(results.filter((r) => r.status === 201)).toHaveLength(8);
    expect(service.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(0);
  });
});

describe('GET /api/bookings/:reference', () => {
  it('returns the public confirmation for a reference', async () => {
    const created = await post('riesling-evening', valid);
    const res = await request(app).get(`/api/bookings/${created.body.booking.reference}`);
    expect(res.status).toBe(200);
    expect(res.body.booking).toEqual(created.body.booking);
  });

  it('answers 404 for an unknown reference', async () => {
    const res = await request(app).get('/api/bookings/KB-NOPE0000');
    expect(res.status).toBe(404);
  });
});

describe('unknown API paths', () => {
  it('answer JSON 404', async () => {
    const res = await request(app).get('/api/unknown');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
});
