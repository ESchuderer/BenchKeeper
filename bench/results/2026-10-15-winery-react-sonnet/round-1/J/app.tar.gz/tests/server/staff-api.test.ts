import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../server/app';
import { BookingService } from '../../server/booking-service';

const PASSWORD = 'correct horse';
let service: BookingService;
let app: ReturnType<typeof createApp>;

beforeEach(() => {
  service = new BookingService();
  app = createApp({ service, staffPassword: PASSWORD });
});

async function signIn(target = app) {
  const agent = request.agent(target);
  const res = await agent.post('/api/staff/session').send({ password: PASSWORD });
  expect(res.status).toBe(200);
  return agent;
}

const book = async (tastingId: string, guests: number, name = 'Anna Weber') => {
  const res = await request(app)
    .post(`/api/tastings/${tastingId}/bookings`)
    .send({ name, email: `${name.split(' ')[0]!.toLowerCase()}@example.com`, guests });
  return res.body.booking.reference as string;
};

describe('sign-in', () => {
  it('accepts the configured password and sets an HttpOnly, SameSite=Strict cookie', async () => {
    const res = await request(app).post('/api/staff/session').send({ password: PASSWORD });
    expect(res.status).toBe(200);
    const cookie = String(res.headers['set-cookie']);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
  });

  it('rejects a wrong password with an error on the password field', async () => {
    const res = await request(app).post('/api/staff/session').send({ password: 'wrong' });
    expect(res.status).toBe(401);
    expect(res.body.errors.password).toMatch(/incorrect/i);
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('rejects an empty password with an error on the password field', async () => {
    const res = await request(app).post('/api/staff/session').send({ password: '' });
    expect(res.status).toBe(422);
    expect(res.body.errors.password).toBeTruthy();
  });

  it.each([[undefined], ['']])('never signs anyone in when STAFF_PASSWORD is %j', async (configured) => {
    const locked = createApp({ service, staffPassword: configured });
    for (const password of ['', 'anything', 'undefined']) {
      const res = await request(locked).post('/api/staff/session').send({ password });
      expect(res.status).toBeGreaterThanOrEqual(401);
      expect(res.headers['set-cookie']).toBeUndefined();
    }
  });

  it('limits repeated attempts', async () => {
    const limited = createApp({ service, staffPassword: PASSWORD, loginRateLimit: { limit: 3, windowMs: 60_000 } });
    const statuses: number[] = [];
    for (let i = 0; i < 5; i++) {
      statuses.push((await request(limited).post('/api/staff/session').send({ password: 'wrong' })).status);
    }
    expect(statuses).toEqual([401, 401, 401, 429, 429]);
  });
});

describe('protected routes', () => {
  it('refuse anonymous requests', async () => {
    const reference = await book('riesling-evening', 2);
    expect((await request(app).get('/api/staff/bookings')).status).toBe(401);
    expect((await request(app).delete(`/api/staff/bookings/${reference}`)).status).toBe(401);
    expect(service.getBooking(reference)).toBeDefined();
  });

  it('refuse a forged session cookie', async () => {
    const res = await request(app).get('/api/staff/bookings').set('Cookie', 'kb_staff=forged');
    expect(res.status).toBe(401);
  });

  it('reports the session state', async () => {
    expect((await request(app).get('/api/staff/session')).body).toEqual({ signedIn: false });
    const agent = await signIn();
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: true });
  });

  it('end the session on sign-out', async () => {
    const agent = await signIn();
    expect((await agent.delete('/api/staff/session')).status).toBe(204);
    expect((await agent.get('/api/staff/bookings')).status).toBe(401);
  });

  it('expire after the session lifetime', async () => {
    let now = 1_000_000;
    const timed = createApp({ service, staffPassword: PASSWORD, now: () => now });
    const agent = await signIn(timed);
    expect((await agent.get('/api/staff/bookings')).status).toBe(200);
    now += 9 * 60 * 60 * 1000;
    expect((await agent.get('/api/staff/bookings')).status).toBe(401);
  });
});

describe('GET /api/staff/bookings', () => {
  it('groups bookings by tasting with name, email, guests and reference', async () => {
    const r1 = await book('riesling-evening', 2, 'Anna Weber');
    await book('riesling-evening', 1, 'Ben Koch');
    await book('winter-tasting', 4, 'Carla Roth');
    const res = await (await signIn()).get('/api/staff/bookings');
    expect(res.status).toBe(200);
    const groups = res.body.groups as { tasting: { title: string }; bookings: Record<string, unknown>[] }[];
    expect(groups.map((g) => [g.tasting.title, g.bookings.length])).toEqual([
      ['Riesling Evening', 2],
      ['Red Wine Cellar Tour', 0],
      ['Winter Tasting', 1],
    ]);
    expect(groups[0]!.bookings[0]).toMatchObject({
      reference: r1,
      name: 'Anna Weber',
      email: 'anna@example.com',
      guests: 2,
    });
  });
});

describe('DELETE /api/staff/bookings/:reference', () => {
  it('cancels a booking and frees its seats', async () => {
    const reference = await book('riesling-evening', 3);
    const agent = await signIn();
    expect((await agent.delete(`/api/staff/bookings/${reference}`)).status).toBe(204);
    expect(service.getTasting('riesling-evening')?.seatsLeft).toBe(12);
    expect((await request(app).get(`/api/bookings/${reference}`)).status).toBe(404);
  });

  it('answers 404 when cancelled twice', async () => {
    const reference = await book('riesling-evening', 1);
    const agent = await signIn();
    await agent.delete(`/api/staff/bookings/${reference}`);
    expect((await agent.delete(`/api/staff/bookings/${reference}`)).status).toBe(404);
  });
});
