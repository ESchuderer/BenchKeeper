import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../../server/app';

let app: ReturnType<typeof createApp>;

beforeAll(() => {
  const dir = mkdtempSync(join(tmpdir(), 'kb-client-'));
  mkdirSync(join(dir, 'assets'));
  writeFileSync(join(dir, 'index.html'), '<!doctype html><div id="root">shell</div>');
  writeFileSync(join(dir, 'assets', 'app.js'), 'console.log(1)');
  app = createApp({ clientDir: dir });
});

describe('serving the client', () => {
  it.each(['/', '/staff', '/book/riesling-evening', '/booking/KB-ABCDEFGH'])('serves the HTML shell at %s', async (path) => {
    const res = await request(app).get(path);
    expect(res.status).toBe(200);
    expect(res.text).toContain('shell');
    expect(res.headers['content-type']).toMatch(/html/);
  });

  it('serves built assets', async () => {
    const res = await request(app).get('/assets/app.js');
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/javascript/);
  });

  it('answers 404 for a missing asset instead of the HTML shell', async () => {
    expect((await request(app).get('/assets/missing.js')).status).toBe(404);
  });

  it('answers JSON 404 for unknown API paths', async () => {
    const res = await request(app).get('/api/unknown');
    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });

  it('sets security headers', async () => {
    const res = await request(app).get('/');
    expect(res.headers['content-security-policy']).toContain("default-src 'self'");
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });
});
