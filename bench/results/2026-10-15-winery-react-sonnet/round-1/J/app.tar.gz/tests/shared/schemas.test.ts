import { describe, expect, it } from 'vitest';
import { bookingInputSchema, fieldErrors, staffLoginSchema } from '../../shared/schemas';
import { formatEur } from '../../shared/format';
import { TASTINGS } from '../../shared/tastings';

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

describe('bookingInputSchema', () => {
  it('accepts valid input and trims the name and email', () => {
    const result = bookingInputSchema.safeParse({ name: '  Anna Weber ', email: ' anna@example.com ', guests: 2 });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.name).toBe('Anna Weber');
      expect(result.data.email).toBe('anna@example.com');
    }
  });

  it.each([
    ['empty name', { ...valid, name: '' }, 'name'],
    ['blank name', { ...valid, name: '   ' }, 'name'],
    ['name over 100 characters', { ...valid, name: 'x'.repeat(101) }, 'name'],
    ['email without @', { ...valid, email: 'not-an-email' }, 'email'],
    ['empty email', { ...valid, email: '' }, 'email'],
    ['email without domain dot', { ...valid, email: 'a@b' }, 'email'],
    ['zero guests', { ...valid, guests: 0 }, 'guests'],
    ['nine guests', { ...valid, guests: 9 }, 'guests'],
    ['fractional guests', { ...valid, guests: 2.5 }, 'guests'],
    ['NaN guests', { ...valid, guests: Number.NaN }, 'guests'],
    ['string guests', { ...valid, guests: '2' }, 'guests'],
    ['missing guests', { name: 'A', email: 'a@b.de' }, 'guests'],
  ])('rejects %s on the %s field', (_label, input, field) => {
    const result = bookingInputSchema.safeParse(input);
    expect(result.success).toBe(false);
    if (!result.success) {
      const errors = fieldErrors(result.error);
      expect(Object.keys(errors)).toContain(field);
      expect(errors[field]).toMatch(/\S/);
    }
  });

  it('accepts the boundaries 1 and 8 guests', () => {
    expect(bookingInputSchema.safeParse({ ...valid, guests: 1 }).success).toBe(true);
    expect(bookingInputSchema.safeParse({ ...valid, guests: 8 }).success).toBe(true);
  });

  it('reports one message per invalid field', () => {
    const result = bookingInputSchema.safeParse({ name: '', email: 'x', guests: 0 });
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(Object.keys(fieldErrors(result.error)).sort()).toEqual(['email', 'guests', 'name']);
    }
  });
});

describe('staffLoginSchema', () => {
  it('requires a password', () => {
    const result = staffLoginSchema.safeParse({ password: '' });
    expect(result.success).toBe(false);
    if (!result.success) expect(fieldErrors(result.error).password).toMatch(/password/i);
  });
});

describe('formatEur', () => {
  it('prints whole euros without decimals', () => {
    expect(formatEur(2500)).toBe('EUR 25');
  });
  it('prints cents when present', () => {
    expect(formatEur(2550)).toBe('EUR 25.50');
  });
});

describe('TASTINGS', () => {
  it('matches the offered catalogue', () => {
    expect(TASTINGS.map((t) => [t.title, t.startsAt, t.priceCents, t.capacity])).toEqual([
      ['Riesling Evening', '2026-11-06T18:00', 2500, 12],
      ['Red Wine Cellar Tour', '2026-11-14T15:00', 3200, 8],
      ['Winter Tasting', '2026-12-05T17:00', 2800, 10],
    ]);
  });
});

describe('describeStart', () => {
  it('splits a local start into weekday, date and time', async () => {
    const { describeStart } = await import('../../shared/format');
    expect(describeStart('2026-11-06T18:00')).toMatchObject({
      weekday: 'Friday',
      date: '2026-11-06',
      time: '18:00',
      day: '06',
      month: 'Nov',
    });
  });
});
