# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff see and cancel bookings. React single-page app served by an Express API, all in one Node.js 22 process. No database and no external services.

## Run it

```bash
npm install
npm run build      # builds the React client (dist/client) and compiles the server (dist/server)
STAFF_PASSWORD='choose-a-password' npm start
```

The app listens on `PORT` (default `3000`): <http://localhost:3000>. Staff sign in at <http://localhost:3000/staff> with the password from `STAFF_PASSWORD`.

| Variable | Meaning |
|---|---|
| `PORT` | Port to listen on (default `3000`). |
| `STAFF_PASSWORD` | Password for `/staff`. If unset or empty, staff sign-in is refused for everyone (a warning is logged at startup). |
| `SECURE_COOKIES` | Set to `true` when served over HTTPS so the session cookie gets the `Secure` flag. |

Bookings are kept in memory: the app starts with none and they are lost on restart. Staff sessions are in memory too (8 hours).

## What it does

- `/`: the three tastings with date, time, price per guest and "<n> seats left" (or "Fully booked").
- `/book/:tasting`: booking form (Name, Email, Guests 1 to 8). Errors appear next to the field concerned. The server enforces capacity atomically, so a tasting is never oversold. A confirmation shows tasting, guests, total price and a booking reference (`KB-XXXXXX`).
- `/staff`: password sign-in, bookings grouped by tasting, "Cancel" frees the seats, "Sign out".

## Develop and test

```bash
npm test                 # unit, API (supertest) and component (Testing Library) tests
npm run test:coverage    # same, with coverage thresholds (80 %)
npm run typecheck
npm run build && npm run test:e2e   # Playwright against the built app (port 3100)
```

The end-to-end tests need a Playwright browser: `npx playwright install --with-deps chromium`.

## Layout

```
shared/   booking schema (zod), catalogue, formatting, API types: used by server and client
server/   Express app (createApp), in-memory booking store, sessions, entry point
client/   Vite + React + React Router + Tailwind CSS
tests/e2e Playwright journeys (guest, staff, accessibility with axe, phone viewport)
openspec/ requirements, design and task list for the change `add-tasting-bookings`
```

## Assumptions

- Tasting dates are wall-clock times (no time zone) and bookings stay open regardless of today's date.
- "1 seats left" keeps the wording `<n> seats left` for every n, as specified.
- The rate limit for staff sign-in is per client IP (10 failed attempts per 15 minutes). Behind a reverse proxy the proxy address would be seen unless Express `trust proxy` is configured.
- Cancelling is immediate (no confirmation dialog) and permanent.
