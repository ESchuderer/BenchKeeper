import { Route, Routes } from 'react-router'
import { Layout } from './components/Layout'
import { BookingPage } from './pages/BookingPage'
import { NotFoundPage } from './pages/NotFoundPage'
import { StaffPage } from './pages/StaffPage'
import { StartPage } from './pages/StartPage'

export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<StartPage />} />
        <Route path="book/:tastingId" element={<BookingPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  )
}
