import type { BookingInput } from '@shared/booking-schema'
import type { ApiErrorBody, BookingConfirmation, StaffTastingGroup, TastingView } from '@shared/types'

export type ApiResult<T> =
  | { ok: true; data: T }
  | { ok: false; status: number; message: string; errors: Record<string, string> }

const NETWORK_MESSAGE = 'We could not reach the server. Please check your connection and try again.'

async function request<T>(method: string, path: string, body?: unknown): Promise<ApiResult<T>> {
  try {
    const response = await fetch(path, {
      method,
      credentials: 'same-origin',
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    if (response.ok) {
      const data = response.status === 204 ? undefined : await response.json()
      return { ok: true, data: data as T }
    }
    const error = (await response.json().catch(() => ({}))) as Partial<ApiErrorBody>
    return {
      ok: false,
      status: response.status,
      message: error.message ?? 'Something went wrong. Please try again.',
      errors: error.errors ?? {},
    }
  } catch {
    return { ok: false, status: 0, message: NETWORK_MESSAGE, errors: {} }
  }
}

export const api = {
  async listTastings(): Promise<ApiResult<TastingView[]>> {
    const result = await request<{ tastings: TastingView[] }>('GET', '/api/tastings')
    return result.ok ? { ok: true, data: result.data.tastings } : result
  },
  book: (tastingId: string, input: BookingInput) =>
    request<BookingConfirmation>('POST', `/api/tastings/${encodeURIComponent(tastingId)}/bookings`, input),
  async staffSignedIn(): Promise<boolean> {
    const result = await request<{ signedIn: boolean }>('GET', '/api/staff/session')
    return result.ok && result.data.signedIn
  },
  staffLogin: (password: string) => request<{ signedIn: true }>('POST', '/api/staff/login', { password }),
  staffLogout: () => request<void>('POST', '/api/staff/logout'),
  async staffBookings(): Promise<ApiResult<StaffTastingGroup[]>> {
    const result = await request<{ groups: StaffTastingGroup[] }>('GET', '/api/staff/bookings')
    return result.ok ? { ok: true, data: result.data.groups } : result
  },
  staffCancel: (reference: string) => request<void>('DELETE', `/api/staff/bookings/${encodeURIComponent(reference)}`),
}
