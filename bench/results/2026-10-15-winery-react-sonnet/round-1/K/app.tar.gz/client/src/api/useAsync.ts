import { useCallback, useEffect, useState } from 'react'
import type { ApiResult } from './client'

export type AsyncState<T> = { status: 'loading' } | { status: 'error'; message: string; code: number } | { status: 'ready'; data: T }

/** Runs `load` on mount and exposes `reload`; results arriving after unmount are ignored. */
export function useAsync<T>(load: () => Promise<ApiResult<T>>) {
  const [state, setState] = useState<AsyncState<T>>({ status: 'loading' })
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let active = true
    setState((current) => (current.status === 'ready' ? current : { status: 'loading' }))
    load().then((result) => {
      if (!active) return
      setState(result.ok ? { status: 'ready', data: result.data } : { status: 'error', message: result.message, code: result.status })
    })
    return () => {
      active = false
    }
    // `load` is re-created on every render; only `attempt` should trigger a fetch.
  }, [attempt])

  const reload = useCallback(() => setAttempt((n) => n + 1), [])
  return { state, reload }
}
