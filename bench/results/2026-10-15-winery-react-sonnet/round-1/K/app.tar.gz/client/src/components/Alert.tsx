import type { ReactNode } from 'react'

type Variant = 'error' | 'success'

const styles: Record<Variant, string> = {
  error: 'border-error-600 bg-error-50 text-error-700',
  success: 'border-vine-700 bg-vine-50 text-vine-700',
}

interface AlertProps {
  variant: Variant
  children: ReactNode
  /** `alert` interrupts screen readers (errors); `status` is polite (success notices). */
  role?: 'alert' | 'status'
  className?: string
}

export function Alert({ variant, children, role = variant === 'error' ? 'alert' : 'status', className = '' }: AlertProps) {
  return (
    <div role={role} className={`flex items-start gap-3 rounded-lg border-l-4 px-4 py-3 text-sm font-medium ${styles[variant]} ${className}`}>
      <span aria-hidden="true" className="mt-0.5 font-bold">
        {variant === 'error' ? '!' : '✓'}
      </span>
      <div>{children}</div>
    </div>
  )
}
