export function GrapeMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true" focusable="false">
      <g fill="#e9c77b">
        <circle cx="22" cy="30" r="8" />
        <circle cx="42" cy="30" r="8" />
        <circle cx="32" cy="43" r="8" />
        <circle cx="32" cy="27" r="6" opacity="0.85" />
      </g>
      <path d="M32 6c0 8-3 12-3 12m3-12c2 5 8 6 13 4" stroke="#a9c995" strokeWidth="3.5" fill="none" strokeLinecap="round" />
    </svg>
  )
}
