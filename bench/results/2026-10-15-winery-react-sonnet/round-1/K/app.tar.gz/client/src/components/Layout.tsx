import { Link, Outlet } from 'react-router'
import { GrapeMark } from './GrapeMark'

export function Layout() {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-wine-800 text-cream">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3 sm:px-6">
          <Link to="/" className="flex items-center gap-3 rounded focus-visible:outline-gold">
            <GrapeMark className="size-9" />
            <span className="font-display text-xl font-semibold tracking-tight">Weingut Kieselbrunnen</span>
          </Link>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        <Outlet />
      </main>
      <footer className="border-t border-line bg-parchment">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-5 text-sm text-muted sm:px-6">
          <p>Weingut Kieselbrunnen · a family winery</p>
          <Link to="/staff" className="underline underline-offset-4 hover:text-wine-700">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  )
}
