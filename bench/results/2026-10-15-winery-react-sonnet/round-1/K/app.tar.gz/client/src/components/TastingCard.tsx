import { Link } from 'react-router'
import { formatMoney, formatSeatsLeft, formatStart } from '@shared/format'
import type { TastingView } from '@shared/types'

export function TastingCard({ tasting }: { tasting: TastingView }) {
  const { date, time } = formatStart(tasting.startsAt)
  const fullyBooked = tasting.seatsLeft === 0
  const headingId = `tasting-${tasting.id}`
  const [day = ''] = tasting.startsAt.split('T')

  return (
    <article
      aria-labelledby={headingId}
      className={`flex flex-col rounded-2xl border p-6 shadow-sm ${fullyBooked ? 'border-line bg-parchment/60 text-muted' : 'border-line bg-white'}`}
    >
      <div>
        {fullyBooked && <span className="mb-2 inline-block rounded-full bg-wine-900 px-3 py-1 text-xs font-bold uppercase tracking-wide text-cream">Fully booked</span>}
        <h2 id={headingId} className={`text-2xl font-semibold ${fullyBooked ? 'text-muted' : 'text-wine-800'}`}>
          {tasting.title}
        </h2>
      </div>

      <p className="mt-3 flex flex-wrap gap-x-3 text-base">
        <time dateTime={day} className="font-medium">
          {date}
        </time>
        <time dateTime={time} className="font-medium">
          {time}
        </time>
      </p>

      <dl className="mt-5 flex items-end justify-between gap-4 border-t border-line pt-4">
        <div>
          <dt className="text-xs font-semibold uppercase tracking-wide text-muted">Per guest</dt>
          <dd className={`font-display text-2xl font-semibold ${fullyBooked ? '' : 'text-ink'}`}>{formatMoney(tasting.priceCents)}</dd>
        </div>
        <div className="text-right">
          <dt className="sr-only">Availability</dt>
          <dd className={`text-sm font-semibold ${fullyBooked ? '' : tasting.seatsLeft <= 3 ? 'text-wine-700' : 'text-vine-700'}`}>{formatSeatsLeft(tasting.seatsLeft)}</dd>
        </div>
      </dl>

      {!fullyBooked && (
        <div className="mt-auto pt-5">
          <Link to={`/book/${tasting.id}`} className="btn btn-primary w-full">
            Book {tasting.title}
          </Link>
        </div>
      )}
    </article>
  )
}
