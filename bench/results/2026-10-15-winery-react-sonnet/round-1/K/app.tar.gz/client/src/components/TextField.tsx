import { useId, type ComponentPropsWithRef } from 'react'

interface TextFieldProps extends ComponentPropsWithRef<'input'> {
  label: string
  error?: string | undefined
  hint?: string
}

/** Labelled input whose error message sits directly below it and is announced with the field. */
export function TextField({ label, error, hint, className = '', ...inputProps }: TextFieldProps) {
  const id = useId()
  const errorId = `${id}-error`
  const hintId = `${id}-hint`
  const describedBy = [error && errorId, hint && hintId].filter(Boolean).join(' ') || undefined

  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-semibold text-ink">
        {label}
      </label>
      <input id={id} className={`input ${className}`} aria-invalid={error ? true : undefined} aria-describedby={describedBy} {...inputProps} />
      {hint && !error && (
        <p id={hintId} className="text-sm text-muted">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} className="flex items-start gap-1.5 text-sm font-medium text-error-700">
          <span aria-hidden="true" className="font-bold">
            !
          </span>
          {error}
        </p>
      )}
    </div>
  )
}
