// @vitest-environment jsdom
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, describe, expect, test, vi } from 'vitest'
import { mockApi, renderApp, tastings, type MockReply, type MockRequest } from '../test-utils'

afterEach(() => vi.unstubAllGlobals())

const confirmation = {
  booking: { reference: 'KB-ABC234', tastingId: 'riesling-evening', name: 'Anna Weber', email: 'anna@example.com', guests: 2, totalCents: 5000, createdAt: '2026-10-15T08:00:00Z' },
  tasting: { ...tastings[0]!, seatsLeft: 10 },
}

function setup(onBook?: (req: MockRequest) => MockReply, list = tastings) {
  return mockApi((req) => {
    if (req.method === 'GET' && req.path === '/api/tastings') return { body: { tastings: list } }
    if (req.method === 'POST' && req.path === '/api/tastings/riesling-evening/bookings') return onBook?.(req)
    return undefined
  })
}

const fill = async (name: string, email: string, guests: string) => {
  const user = userEvent.setup()
  if (name) await user.type(screen.getByLabelText('Name'), name)
  if (email) await user.type(screen.getByLabelText('Email'), email)
  if (guests) await user.type(screen.getByLabelText('Guests'), guests)
  return user
}

describe('booking form', () => {
  test('shows the tasting and the Name, Email and Guests fields with a Book button', async () => {
    setup()
    renderApp('/book/riesling-evening')
    expect(await screen.findByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument()
    expect(screen.getByText('EUR 25')).toBeInTheDocument()
    expect(screen.getByLabelText('Name')).toBeInTheDocument()
    expect(screen.getByLabelText('Email')).toBeInTheDocument()
    expect(screen.getByLabelText('Guests')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument()
  })

  test('shows an error next to every empty field and sends nothing', async () => {
    const fetchMock = setup()
    renderApp('/book/riesling-evening')
    await screen.findByLabelText('Name')
    await userEvent.click(screen.getByRole('button', { name: 'Book' }))

    expect(screen.getByLabelText('Name')).toHaveAccessibleDescription(/enter your name/i)
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription(/enter your email/i)
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/from 1 to 8/i)
    expect(screen.getByLabelText('Name')).toBeInvalid()
    expect(fetchMock.mock.calls.filter(([, init]) => init?.method === 'POST')).toHaveLength(0)
  })

  test('flags only the invalid email and keeps what was typed', async () => {
    setup()
    renderApp('/book/riesling-evening')
    await screen.findByLabelText('Name')
    const user = await fill('Anna Weber', 'not-an-email', '2')
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription(/valid email/i)
    expect(screen.getByLabelText('Name')).toBeValid()
    expect(screen.getByLabelText('Guests')).toBeValid()
    expect(screen.getByLabelText('Name')).toHaveValue('Anna Weber')
    expect(screen.getByLabelText('Email')).toHaveValue('not-an-email')
    expect(screen.getByLabelText('Guests')).toHaveValue(2)
  })

  test.each(['0', '9'])('rejects %s guests next to the Guests field', async (guests) => {
    setup()
    renderApp('/book/riesling-evening')
    await screen.findByLabelText('Name')
    const user = await fill('Anna', 'anna@example.com', guests)
    await user.click(screen.getByRole('button', { name: 'Book' }))
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/from 1 to 8/i)
    expect(screen.getByLabelText('Name')).toBeValid()
  })

  test('confirms a successful booking with tasting, guests, total and reference', async () => {
    const fetchMock = setup(() => ({ status: 201, body: confirmation }))
    renderApp('/book/riesling-evening')
    await screen.findByLabelText('Name')
    const user = await fill('Anna Weber', 'anna@example.com', '2')
    await user.click(screen.getByRole('button', { name: 'Book' }))

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument()
    const summary = screen.getByRole('region', { name: 'Booking confirmed' })
    expect(within(summary).getByText('Riesling Evening')).toBeInTheDocument()
    expect(within(summary).getByText('2')).toBeInTheDocument()
    expect(within(summary).getByText('EUR 50')).toBeInTheDocument()
    expect(within(summary).getByText('KB-ABC234')).toBeInTheDocument()
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument()
    expect(screen.getByRole('link', { name: /back to all tastings/i })).toHaveAttribute('href', '/')

    const post = fetchMock.mock.calls.find(([, init]) => init?.method === 'POST')!
    expect(JSON.parse(post[1]!.body as string)).toEqual({ name: 'Anna Weber', email: 'anna@example.com', guests: 2 })
  })

  test('shows the server seat error next to Guests and keeps the form', async () => {
    setup(() => ({ status: 409, body: { message: 'Only 1 seat is left for this tasting.', errors: { guests: 'Only 1 seat is left for this tasting.' } } }))
    renderApp('/book/riesling-evening')
    await screen.findByLabelText('Name')
    const user = await fill('Anna', 'anna@example.com', '2')
    await user.click(screen.getByRole('button', { name: 'Book' }))

    await waitFor(() => expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/only 1 seat is left/i))
    expect(screen.getByLabelText('Name')).toHaveValue('Anna')
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument()
  })

  test('maps server validation errors onto their fields', async () => {
    setup(() => ({ status: 422, body: { message: 'Please correct the highlighted fields.', errors: { email: 'Enter a valid email address, e.g. name@example.com.' } } }))
    renderApp('/book/riesling-evening')
    await screen.findByLabelText('Name')
    const user = await fill('Anna', 'a@b.co', '2')
    await user.click(screen.getByRole('button', { name: 'Book' }))
    await waitFor(() => expect(screen.getByLabelText('Email')).toHaveAccessibleDescription(/valid email/i))
  })

  test('shows a general error when the server is unreachable', async () => {
    mockApi((req) => (req.method === 'GET' ? { body: { tastings } } : undefined))
    vi.mocked(fetch).mockImplementation(async (_input, init) => {
      if (init?.method === 'POST') throw new TypeError('network down')
      return new Response(JSON.stringify({ tastings }), { status: 200 })
    })
    renderApp('/book/riesling-evening')
    await screen.findByLabelText('Name')
    const user = await fill('Anna', 'anna@example.com', '2')
    await user.click(screen.getByRole('button', { name: 'Book' }))
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach the server/i)
  })

  test('shows a fully-booked notice instead of the form', async () => {
    setup(undefined, tastings.map((t) => (t.id === 'riesling-evening' ? { ...t, seatsLeft: 0 } : t)))
    renderApp('/book/riesling-evening')
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument()
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument()
    expect(screen.getByRole('link', { name: /back to all tastings/i })).toBeInTheDocument()
  })

  test('says so when the tasting does not exist', async () => {
    setup()
    renderApp('/book/no-such-tasting')
    expect(await screen.findByRole('heading', { name: /tasting not found/i })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: /back to all tastings/i })).toHaveAttribute('href', '/')
  })
})
