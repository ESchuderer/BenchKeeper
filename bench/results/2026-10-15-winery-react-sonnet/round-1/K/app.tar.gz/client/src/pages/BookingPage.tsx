import { zodResolver } from '@hookform/resolvers/zod'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link, useParams } from 'react-router'
import type { z } from 'zod'
import { bookingInputSchema, MAX_GUESTS_PER_BOOKING, type BookingField, type BookingInput } from '@shared/booking-schema'
import { formatMoney, formatSeatsLeft, formatStart } from '@shared/format'
import type { BookingConfirmation, TastingView } from '@shared/types'
import { api } from '../api/client'
import { useAsync } from '../api/useAsync'
import { Alert } from '../components/Alert'
import { TextField } from '../components/TextField'

const BOOKING_FIELDS: readonly BookingField[] = ['name', 'email', 'guests']

const BackLink = () => (
  <Link to="/" className="btn btn-secondary mt-6">
    Back to all tastings
  </Link>
)

export function BookingPage() {
  const { tastingId = '' } = useParams()
  const { state } = useAsync(api.listTastings)
  const [confirmation, setConfirmation] = useState<BookingConfirmation>()

  if (state.status === 'loading') return <p role="status" className="text-muted">Loading…</p>
  if (state.status === 'error') return <Alert variant="error">We could not load this tasting. Please try again later.</Alert>

  const tasting = state.data.find((t) => t.id === tastingId)
  if (!tasting) {
    return (
      <section className="max-w-xl">
        <h1 className="text-3xl font-semibold text-wine-900">Tasting not found</h1>
        <p className="mt-3 text-muted">This tasting does not exist (any more).</p>
        <BackLink />
      </section>
    )
  }
  if (confirmation) return <Confirmation confirmation={confirmation} />
  if (tasting.seatsLeft === 0) {
    return (
      <section className="max-w-xl">
        <h1 className="text-3xl font-semibold text-wine-900">{tasting.title}</h1>
        <div className="mt-4">
          <Alert variant="error" role="status">
            This tasting is fully booked. Please choose another date.
          </Alert>
        </div>
        <BackLink />
      </section>
    )
  }
  return <BookingForm tasting={tasting} onBooked={setConfirmation} />
}

function BookingForm({ tasting, onBooked }: { tasting: TastingView; onBooked: (c: BookingConfirmation) => void }) {
  const { date, time } = formatStart(tasting.startsAt)
  const [formError, setFormError] = useState<string>()
  const {
    register,
    handleSubmit,
    setError,
    setFocus,
    formState: { errors, isSubmitting },
  } = useForm<z.input<typeof bookingInputSchema>, unknown, BookingInput>({
    resolver: zodResolver(bookingInputSchema),
    defaultValues: { name: '', email: '', guests: '' },
  })

  const submit = handleSubmit(async (values) => {
    setFormError(undefined)
    const result = await api.book(tasting.id, values)
    if (result.ok) return onBooked(result.data)

    const fieldErrors = BOOKING_FIELDS.filter((field) => result.errors[field])
    fieldErrors.forEach((field) => setError(field, { type: 'server', message: result.errors[field] }))
    if (fieldErrors[0]) setFocus(fieldErrors[0])
    else setFormError(result.message)
  })

  return (
    <div className="grid gap-10 md:grid-cols-[1fr_1.2fr] md:items-start">
      <section>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-wine-700">Reserve your seats</p>
        <h1 className="mt-2 text-3xl font-semibold text-wine-900 sm:text-4xl">Book {tasting.title}</h1>
        <dl className="mt-6 space-y-3 rounded-2xl border border-line bg-parchment/60 p-5">
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide text-muted">When</dt>
            <dd className="font-medium">
              {date}, {time}
            </dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide text-muted">Price</dt>
            <dd className="font-medium">
              <span>{formatMoney(tasting.priceCents)}</span> per guest
            </dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide text-muted">Availability</dt>
            <dd className="font-medium">{formatSeatsLeft(tasting.seatsLeft)}</dd>
          </div>
        </dl>
        <Link to="/" className="mt-4 inline-block text-sm text-muted underline underline-offset-4 hover:text-wine-700">
          ← All tastings
        </Link>
      </section>

      <form onSubmit={submit} noValidate className="space-y-5 rounded-2xl border border-line bg-white p-6 shadow-sm sm:p-8">
        {formError && <Alert variant="error">{formError}</Alert>}
        <TextField label="Name" autoComplete="name" error={errors.name?.message} {...register('name')} />
        <TextField label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register('email')} />
        <TextField
          label="Guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={MAX_GUESTS_PER_BOOKING}
          hint={`1 to ${MAX_GUESTS_PER_BOOKING} guests`}
          error={errors.guests?.message}
          {...register('guests')}
        />
        <button type="submit" className="btn btn-primary w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Booking…' : 'Book'}
        </button>
      </form>
    </div>
  )
}

function Confirmation({ confirmation }: { confirmation: BookingConfirmation }) {
  const { booking, tasting } = confirmation
  const { date, time } = formatStart(tasting.startsAt)
  return (
    <section aria-labelledby="confirmed-heading" className="mx-auto max-w-xl rounded-2xl border border-vine-700/40 bg-vine-50 p-6 sm:p-8">
      <p aria-hidden="true" className="grid size-12 place-items-center rounded-full bg-vine-700 text-2xl text-white">
        ✓
      </p>
      <h1 id="confirmed-heading" className="mt-4 text-3xl font-semibold text-vine-700">
        Booking confirmed
      </h1>
      <p className="mt-2 text-muted">Thank you, {booking.name}. We look forward to welcoming you.</p>
      <dl className="mt-6 divide-y divide-vine-700/20 rounded-xl bg-white px-5">
        <Row label="Tasting" value={tasting.title} />
        <Row label="When" value={`${date}, ${time}`} />
        <Row label="Guests" value={String(booking.guests)} />
        <Row label="Total price" value={formatMoney(booking.totalCents)} />
        <Row label="Booking reference" value={booking.reference} mono />
      </dl>
      <p className="mt-4 text-sm text-muted">Please keep your booking reference; you will need it if you contact us.</p>
      <Link to="/" className="btn btn-primary mt-6">
        Back to all tastings
      </Link>
    </section>
  )
}

function Row({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-3">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className={`text-right font-semibold ${mono ? 'font-mono tracking-wider text-wine-800' : ''}`}>{value}</dd>
    </div>
  )
}
