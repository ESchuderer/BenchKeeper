import { Link } from 'react-router'

export function NotFoundPage() {
  return (
    <section className="max-w-xl">
      <h1 className="text-3xl font-semibold text-wine-900">Page not found</h1>
      <p className="mt-3 text-muted">We could not find the page you were looking for.</p>
      <Link to="/" className="btn btn-primary mt-6">
        Back to all tastings
      </Link>
    </section>
  )
}
