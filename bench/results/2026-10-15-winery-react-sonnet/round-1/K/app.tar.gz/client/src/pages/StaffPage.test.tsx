// @vitest-environment jsdom
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, describe, expect, test, vi } from 'vitest'
import type { Booking, StaffTastingGroup } from '@shared/types'
import { mockApi, renderApp, tastings, type MockRequest } from '../test-utils'

afterEach(() => vi.unstubAllGlobals())

const booking = (over: Partial<Booking>): Booking => ({
  reference: 'KB-AAA111',
  tastingId: 'riesling-evening',
  name: 'Anna Weber',
  email: 'anna@example.com',
  guests: 2,
  totalCents: 5000,
  createdAt: '2026-10-15T08:00:00Z',
  ...over,
})

function groupsWith(bookings: Booking[]): StaffTastingGroup[] {
  return tastings.map((tasting) => {
    const mine = bookings.filter((b) => b.tastingId === tasting.id)
    return { tasting: { ...tasting, seatsLeft: tasting.capacity - mine.reduce((n, b) => n + b.guests, 0) }, bookings: mine }
  })
}

/** Staff backend double: signed-in state and bookings are mutable per test. */
function staffBackend(opts: { signedIn?: boolean; bookings?: Booking[]; password?: string } = {}) {
  const state = { signedIn: opts.signedIn ?? false, bookings: opts.bookings ?? [] }
  const handler = (req: MockRequest) => {
    const { method, path } = req
    if (method === 'GET' && path === '/api/staff/session') return { body: { signedIn: state.signedIn } }
    if (method === 'POST' && path === '/api/staff/login') {
      if (req.body?.password !== (opts.password ?? 'secret')) {
        return { status: 401, body: { message: 'Wrong password.', errors: { password: 'That password is not correct.' } } }
      }
      state.signedIn = true
      return { body: { signedIn: true } }
    }
    if (method === 'POST' && path === '/api/staff/logout') {
      state.signedIn = false
      return { status: 204 }
    }
    if (!state.signedIn && path.startsWith('/api/staff/')) return { status: 401, body: { message: 'Please sign in.' } }
    if (method === 'GET' && path === '/api/staff/bookings') return { body: { groups: groupsWith(state.bookings) } }
    if (method === 'DELETE' && path.startsWith('/api/staff/bookings/')) {
      const ref = decodeURIComponent(path.split('/').pop()!)
      const before = state.bookings.length
      state.bookings = state.bookings.filter((b) => b.reference !== ref)
      return state.bookings.length < before ? { status: 204 } : { status: 404, body: { message: 'Booking not found.' } }
    }
    return undefined
  }
  return { state, fetchMock: mockApi(handler) }
}

describe('staff page', () => {
  test('asks for a password when signed out and shows no bookings', async () => {
    staffBackend({ bookings: [booking({})] })
    renderApp('/staff')
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password')
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument()
    expect(screen.queryByText('anna@example.com')).not.toBeInTheDocument()
  })

  test('shows an error next to the Password field for a wrong password', async () => {
    staffBackend()
    renderApp('/staff')
    await userEvent.type(await screen.findByLabelText('Password'), 'wrong')
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }))
    await waitFor(() => expect(screen.getByLabelText('Password')).toHaveAccessibleDescription(/not correct/i))
    expect(screen.getByLabelText('Password')).toBeInvalid()
  })

  test('asks for a password instead of calling the server when the field is empty', async () => {
    const { fetchMock } = staffBackend()
    renderApp('/staff')
    await screen.findByLabelText('Password')
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }))
    expect(screen.getByLabelText('Password')).toHaveAccessibleDescription(/enter the password/i)
    expect(fetchMock.mock.calls.some(([path]) => path === '/api/staff/login')).toBe(false)
  })

  test('signs in and lists bookings grouped by tasting with name, email, guests and reference', async () => {
    staffBackend({ bookings: [booking({}), booking({ reference: 'KB-BBB222', tastingId: 'winter-tasting', name: 'Ben Roth', email: 'ben@example.com', guests: 3 })] })
    renderApp('/staff')
    await userEvent.type(await screen.findByLabelText('Password'), 'secret')
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }))

    const riesling = await screen.findByRole('region', { name: 'Riesling Evening' })
    const row = within(riesling).getByRole('row', { name: /Anna Weber/ })
    expect(within(row).getByText('anna@example.com')).toBeInTheDocument()
    expect(within(row).getByText('2')).toBeInTheDocument()
    expect(within(row).getByText('KB-AAA111')).toBeInTheDocument()

    const winter = screen.getByRole('region', { name: 'Winter Tasting' })
    expect(within(winter).getByText('Ben Roth')).toBeInTheDocument()
    expect(within(winter).getByText('KB-BBB222')).toBeInTheDocument()

    const cellar = screen.getByRole('region', { name: 'Red Wine Cellar Tour' })
    expect(within(cellar).getByText(/no bookings yet/i)).toBeInTheDocument()
  })

  test('stays signed in after reload (existing session)', async () => {
    staffBackend({ signedIn: true, bookings: [booking({})] })
    renderApp('/staff')
    expect(await screen.findByText('Anna Weber')).toBeInTheDocument()
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument()
  })

  test('cancels a booking, removes it from the list and confirms', async () => {
    const { fetchMock } = staffBackend({ signedIn: true, bookings: [booking({}), booking({ reference: 'KB-CCC333', name: 'Clara Vogt', email: 'clara@example.com', guests: 1 })] })
    renderApp('/staff')
    const row = (await screen.findByText('Anna Weber')).closest('tr')!
    await userEvent.click(within(row).getByRole('button', { name: 'Cancel' }))

    await waitFor(() => expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument())
    expect(screen.getByText('Clara Vogt')).toBeInTheDocument()
    expect(screen.getByRole('status')).toHaveTextContent(/KB-AAA111.*cancelled/i)
    expect(fetchMock.mock.calls.some(([path, init]) => path === '/api/staff/bookings/KB-AAA111' && init?.method === 'DELETE')).toBe(true)
  })

  test('shows freed seats in the tasting header after a cancellation', async () => {
    staffBackend({ signedIn: true, bookings: [booking({ guests: 4 })] })
    renderApp('/staff')
    const region = await screen.findByRole('region', { name: 'Riesling Evening' })
    expect(within(region).getByText('8 seats left')).toBeInTheDocument()
    await userEvent.click(within(region).getByRole('button', { name: 'Cancel' }))
    await waitFor(() => expect(screen.getByRole('region', { name: 'Riesling Evening' })).toHaveTextContent('12 seats left'))
  })

  test('signs out and returns to the password form', async () => {
    staffBackend({ signedIn: true, bookings: [booking({})] })
    renderApp('/staff')
    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }))
    expect(await screen.findByLabelText('Password')).toBeInTheDocument()
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument()
  })

  test('returns to sign-in with a notice when the session has expired', async () => {
    const { state } = staffBackend({ signedIn: true, bookings: [booking({})] })
    renderApp('/staff')
    const row = (await screen.findByText('Anna Weber')).closest('tr')!
    state.signedIn = false
    await userEvent.click(within(row).getByRole('button', { name: 'Cancel' }))
    expect(await screen.findByLabelText('Password')).toBeInTheDocument()
    expect(screen.getByRole('alert')).toHaveTextContent(/session has expired/i)
  })
})
