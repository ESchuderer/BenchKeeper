import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { formatSeatsLeft, formatStart } from '@shared/format'
import type { Booking, StaffTastingGroup } from '@shared/types'
import { api } from '../api/client'
import { useAsync, type AsyncState } from '../api/useAsync'
import { Alert } from '../components/Alert'
import { TextField } from '../components/TextField'

export function StaffPage() {
  const [signedIn, setSignedIn] = useState<boolean>()
  const [notice, setNotice] = useState<string>()
  const { state } = useAsync(async () => ({ ok: true as const, data: await api.staffSignedIn() }))

  const isSignedIn = signedIn ?? (state.status === 'ready' ? state.data : undefined)

  return (
    <>
      <h1 className="text-3xl font-semibold text-wine-900 sm:text-4xl">Staff</h1>
      {isSignedIn === undefined && (
        <p role="status" className="mt-6 text-muted">
          Loading…
        </p>
      )}
      {isSignedIn === false && <SignIn notice={notice} onSignedIn={() => { setNotice(undefined); setSignedIn(true) }} />}
      {isSignedIn === true && (
        <Overview
          onSignedOut={(message) => {
            setNotice(message)
            setSignedIn(false)
          }}
        />
      )}
    </>
  )
}

function SignIn({ notice, onSignedIn }: { notice: string | undefined; onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } })

  const submit = handleSubmit(async ({ password }) => {
    const result = await api.staffLogin(password)
    if (result.ok) return onSignedIn()
    setError('password', { type: 'server', message: result.errors.password ?? result.message })
  })

  return (
    <form onSubmit={submit} noValidate className="mt-6 max-w-md space-y-5 rounded-2xl border border-line bg-white p-6 shadow-sm sm:p-8">
      <p className="text-muted">Sign in to see and manage the bookings.</p>
      {notice && <Alert variant="error">{notice}</Alert>}
      <TextField
        label="Password"
        type="password"
        autoComplete="current-password"
        error={errors.password?.message}
        {...register('password', { required: 'Enter the password.' })}
      />
      <button type="submit" className="btn btn-primary w-full" disabled={isSubmitting}>
        Sign in
      </button>
    </form>
  )
}

function Overview({ onSignedOut }: { onSignedOut: (message?: string) => void }) {
  const { state, reload } = useAsync(api.staffBookings)
  const [status, setStatus] = useState<string>()
  const [error, setError] = useState<string>()
  const [cancelling, setCancelling] = useState<string>()

  const expired = state.status === 'error' && state.code === 401
  if (expired) onSignedOut('Your session has expired. Please sign in again.')

  const cancel = async (booking: Booking) => {
    setStatus(undefined)
    setError(undefined)
    setCancelling(booking.reference)
    const result = await api.staffCancel(booking.reference)
    setCancelling(undefined)
    if (result.ok || result.status === 404) {
      setStatus(`Booking ${booking.reference} (${booking.name}) was cancelled and its seats are free again.`)
      return reload()
    }
    if (result.status === 401) return onSignedOut('Your session has expired. Please sign in again.')
    setError(result.message)
  }

  const signOut = async () => {
    await api.staffLogout()
    onSignedOut()
  }

  return (
    <div className="mt-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-muted">All bookings, grouped by tasting.</p>
        <button type="button" className="btn btn-secondary" onClick={signOut}>
          Sign out
        </button>
      </div>
      {status && <Alert variant="success">{status}</Alert>}
      {error && <Alert variant="error">{error}</Alert>}
      <Groups state={state} cancelling={cancelling} onCancel={cancel} />
    </div>
  )
}

function Groups({ state, cancelling, onCancel }: { state: AsyncState<StaffTastingGroup[]>; cancelling: string | undefined; onCancel: (b: Booking) => void }) {
  if (state.status === 'loading') return <p role="status" className="text-muted">Loading bookings…</p>
  if (state.status === 'error') return state.code === 401 ? null : <Alert variant="error">{state.message}</Alert>
  return (
    <div className="space-y-8">
      {state.data.map(({ tasting, bookings }) => {
        const { date, time } = formatStart(tasting.startsAt)
        const headingId = `staff-${tasting.id}`
        return (
          <section key={tasting.id} aria-labelledby={headingId} className="overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
            <header className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 bg-parchment px-5 py-4">
              <h2 id={headingId} className="text-xl font-semibold text-wine-800">
                {tasting.title}
              </h2>
              <p className="text-sm text-muted">
                <span>{date}, {time}</span> · <span>{formatSeatsLeft(tasting.seatsLeft)}</span>
              </p>
            </header>
            {bookings.length === 0 ? (
              <p className="px-5 py-4 text-muted">No bookings yet.</p>
            ) : (
              <BookingTable bookings={bookings} cancelling={cancelling} onCancel={onCancel} />
            )}
          </section>
        )
      })}
    </div>
  )
}

const cell =
  'px-5 py-2.5 max-sm:flex max-sm:items-baseline max-sm:gap-3 max-sm:px-4 max-sm:py-1.5 max-sm:before:w-20 max-sm:before:shrink-0 max-sm:before:text-xs max-sm:before:font-semibold max-sm:before:uppercase max-sm:before:text-muted max-sm:before:content-[attr(data-label)]'

function BookingTable({ bookings, cancelling, onCancel }: { bookings: Booking[]; cancelling: string | undefined; onCancel: (b: Booking) => void }) {
  return (
    <table className="w-full text-left max-sm:block">
      <thead className="max-sm:sr-only">
        <tr className="border-b border-line text-xs uppercase tracking-wide text-muted">
          <th scope="col" className="px-5 py-2 font-semibold">Name</th>
          <th scope="col" className="px-5 py-2 font-semibold">Email</th>
          <th scope="col" className="px-5 py-2 font-semibold">Guests</th>
          <th scope="col" className="px-5 py-2 font-semibold">Reference</th>
          <th scope="col" className="px-5 py-2"><span className="sr-only">Actions</span></th>
        </tr>
      </thead>
      <tbody className="max-sm:block">
        {bookings.map((booking) => (
          <tr key={booking.reference} className="border-b border-line last:border-0 max-sm:block max-sm:py-3">
            <td data-label="Name" className={`${cell} font-semibold`}>{booking.name}</td>
            <td data-label="Email" className={`${cell} break-all`}>{booking.email}</td>
            <td data-label="Guests" className={cell}>{booking.guests}</td>
            <td data-label="Reference" className={`${cell} font-mono tracking-wider`} id={`ref-${booking.reference}`}>{booking.reference}</td>
            <td className={`${cell} max-sm:before:content-none sm:text-right`}>
              <button
                type="button"
                className="btn btn-danger"
                aria-describedby={`ref-${booking.reference}`}
                disabled={cancelling === booking.reference}
                onClick={() => onCancel(booking)}
              >
                Cancel
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
