// @vitest-environment jsdom
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, describe, expect, test, vi } from 'vitest'
import { mockApi, renderApp, tastings } from '../test-utils'

afterEach(() => vi.unstubAllGlobals())

describe('start page', () => {
  test('lists every tasting with title, date, time, price and seats left', async () => {
    mockApi(() => ({ body: { tastings } }))
    renderApp('/')

    const riesling = await screen.findByRole('article', { name: 'Riesling Evening' })
    expect(within(riesling).getByText('Friday, 6 November 2026')).toBeInTheDocument()
    expect(within(riesling).getByText('18:00')).toBeInTheDocument()
    expect(within(riesling).getByText('EUR 25')).toBeInTheDocument()
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument()

    expect(screen.getByText('8 seats left')).toBeInTheDocument()
    expect(screen.getByText('10 seats left')).toBeInTheDocument()
    expect(screen.getAllByRole('article')).toHaveLength(3)
  })

  test('offers a "Book <title>" link that opens the booking form', async () => {
    mockApi(() => ({ body: { tastings } }))
    renderApp('/')
    const link = await screen.findByRole('link', { name: 'Book Riesling Evening' })
    expect(link).toHaveAttribute('href', '/book/riesling-evening')
    await userEvent.click(link)
    expect(await screen.findByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument()
    expect(screen.getByLabelText('Name')).toBeInTheDocument()
  })

  test('marks a tasting without seats as fully booked and offers no booking link', async () => {
    const soldOut = tastings.map((t) => (t.id === 'red-wine-cellar-tour' ? { ...t, seatsLeft: 0 } : t))
    mockApi(() => ({ body: { tastings: soldOut } }))
    renderApp('/')

    const card = await screen.findByRole('article', { name: 'Red Wine Cellar Tour' })
    expect(within(card).getByText('Fully booked')).toBeInTheDocument()
    expect(screen.queryByRole('link', { name: 'Book Red Wine Cellar Tour' })).not.toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toBeInTheDocument()
  })

  test('shows an error with a retry button when tastings cannot be loaded', async () => {
    let fail = true
    mockApi(() => (fail ? { status: 500, body: { message: 'Boom' } } : { body: { tastings } }))
    renderApp('/')
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load the tastings/i)
    fail = false
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }))
    expect(await screen.findByRole('article', { name: 'Riesling Evening' })).toBeInTheDocument()
  })

  test('has a link to the staff area in the footer', async () => {
    mockApi(() => ({ body: { tastings } }))
    renderApp('/')
    expect(await screen.findByRole('link', { name: 'Staff' })).toHaveAttribute('href', '/staff')
  })
})
