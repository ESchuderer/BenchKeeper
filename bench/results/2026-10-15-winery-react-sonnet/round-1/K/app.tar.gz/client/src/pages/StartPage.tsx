import { api } from '../api/client'
import { useAsync } from '../api/useAsync'
import { Alert } from '../components/Alert'
import { TastingCard } from '../components/TastingCard'

export function StartPage() {
  const { state, reload } = useAsync(api.listTastings)

  return (
    <>
      <section className="mb-10 max-w-2xl">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-wine-700">Wine tastings</p>
        <h1 className="mt-2 text-4xl font-semibold leading-tight text-wine-900 sm:text-5xl">Weingut Kieselbrunnen</h1>
        <p className="mt-4 text-lg text-muted">
          Join us at our family winery for an evening among the vines. Choose a tasting below and reserve your seats in a minute.
        </p>
      </section>

      {state.status === 'loading' && (
        <p role="status" className="text-muted">
          Loading tastings…
        </p>
      )}

      {state.status === 'error' && (
        <div className="max-w-xl space-y-3">
          <Alert variant="error">We could not load the tastings. Please try again.</Alert>
          <button type="button" className="btn btn-secondary" onClick={reload}>
            Try again
          </button>
        </div>
      )}

      {state.status === 'ready' && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {state.data.map((tasting) => (
            <TastingCard key={tasting.id} tasting={tasting} />
          ))}
        </div>
      )}
    </>
  )
}
