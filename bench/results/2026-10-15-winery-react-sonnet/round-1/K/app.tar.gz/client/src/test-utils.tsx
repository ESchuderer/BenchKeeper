import { render } from '@testing-library/react'
import { MemoryRouter } from 'react-router'
import { vi } from 'vitest'
import type { TastingView } from '@shared/types'
import { AppRoutes } from './App'

export interface MockRequest {
  method: string
  path: string
  body: Record<string, unknown> | undefined
}
export type MockReply = { status?: number; body?: unknown } | undefined

/** Replaces global fetch with a handler; returns the mock so tests can assert on calls. */
export function mockApi(handler: (req: MockRequest) => MockReply) {
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const request: MockRequest = {
      method: init?.method ?? 'GET',
      path: String(input),
      body: typeof init?.body === 'string' ? JSON.parse(init.body) : undefined,
    }
    const reply = handler(request) ?? { status: 404, body: { message: 'Not found.' } }
    const status = reply.status ?? 200
    return new Response(status === 204 ? null : JSON.stringify(reply.body ?? {}), {
      status,
      headers: { 'Content-Type': 'application/json' },
    })
  })
  vi.stubGlobal('fetch', fetchMock)
  return fetchMock
}

export const tastings: TastingView[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceCents: 2500, capacity: 12, seatsLeft: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceCents: 3200, capacity: 8, seatsLeft: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceCents: 2800, capacity: 10, seatsLeft: 10 },
]

export function renderApp(path = '/') {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <AppRoutes />
    </MemoryRouter>,
  )
}
