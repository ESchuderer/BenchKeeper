# Design

## Context

Greenfield repository (only a setup commit and OpenSpec scaffolding). Requirements: Node.js 22, React UI, `npm install` → `npm run build` → `npm start` serving the whole app on `PORT`, no external services, bookings may live in memory. See proposal.md for motivation and the specs for behavior.

## Goals / Non-Goals

**Goals:**
- One process serves both the JSON API and the built React app.
- Booking rules (validation, capacity) are enforced on the server; the client only mirrors them for fast feedback, using one shared validation schema.
- Test pyramid: unit tests for the booking logic, API tests against the real Express app, component tests for the forms, and a browser end-to-end test of the main journeys.

**Non-Goals:**
- Persistence across restarts, payments, email, i18n, multiple staff accounts, editing the catalogue.

## Decisions

**Stack: Express 5 + Vite/React 19 + React Router, TypeScript throughout.**
Express is the established minimal server; Vite builds the SPA into `dist/client`, which Express serves with an index fallback for client routes (`/staff`, `/book/:id`). *Alternatives:* Next.js / React Router framework mode (heavier, SSR not needed for a three-page site); a hand-rolled `http` server (rejected: the brief asks for established libraries).

**Shared validation with zod (`shared/`).** One schema (`bookingInputSchema`) used by the server to reject and by `react-hook-form` (via `@hookform/resolvers`) in the client. Server returns `{ errors: { field: message } }` with status 422, which the form maps back onto the same fields. *Alternative:* two hand-written validators (drift risk).

**Capacity check is atomic by construction.** The store is in-memory and its `book()` method does check-and-insert synchronously (no `await` between reading seats left and pushing the booking), so Node's single-threaded event loop makes it race-free. A test fires concurrent requests to prove it. *Alternative:* a database with transactions (overkill, violates "no external services").

**Store behind a small interface (`BookingStore`).** Seeded with the three catalogue tastings; `list`, `book`, `cancel`. Cancelling deletes the booking, which frees seats because seats left is always derived (`capacity − Σ guests`), never stored separately, so it cannot drift.

**Money as integer cents** in the catalogue and bookings; formatted as `EUR 25` / `EUR 50` (decimals only when not whole euros). Dates are stored as local wall-clock ISO strings (`2026-11-06T18:00`) and formatted without time-zone conversion, so every visitor sees 18:00.

**Booking references:** `KB-` + 6 characters from an unambiguous alphabet (no 0/O/1/I), from `crypto.randomInt`, re-drawn on collision.

**Staff auth:** `POST /api/staff/login` compares the password to `STAFF_PASSWORD` with `crypto.timingSafeEqual` on SHA-256 digests (constant time, equal length), then issues a random 256-bit session token in an `HttpOnly; SameSite=Strict; Path=/` cookie (`Secure` when behind HTTPS/`NODE_ENV=production` with trust proxy), held in an in-memory session map with expiry (8 h). Login is rate limited (`express-rate-limit`, 10 attempts per 15 min per IP). Empty/unset `STAFF_PASSWORD` disables login (fail closed) and logs a startup warning. State-changing routes only accept `application/json`, which with SameSite=Strict closes CSRF. *Alternatives:* HTTP Basic (no styled form, browser caches creds); JWT (no benefit single-process).

**Security headers** via `helmet` (self-only CSP; fonts are self-hosted through `@fontsource` so no third-party origins). Body size limited; JSON parse errors answered with 400 JSON.

**API surface:** `GET /api/tastings`, `POST /api/tastings/:id/bookings` (201 → confirmation payload; 422 field errors; 409 fully booked/not enough seats reported as a `guests` field error; 404 unknown tasting), `POST /api/staff/login`, `POST /api/staff/logout`, `GET /api/staff/session`, `GET /api/staff/bookings` (401 without session), `DELETE /api/staff/bookings/:reference` (401/404). The guest confirmation is held in client state, so there is no public endpoint that reads a booking by reference (it would expose personal data).

**Styling: Tailwind CSS v4 (Vite plugin)** with a small theme (burgundy `wine`, `cream`, `slate` greens, Fraunces serif headings, system sans body). Mobile-first layout; tasting cards stack on phones. States: error (red text + border + icon, `aria-invalid`, `role="alert"`), success (green confirmation panel), fully booked (muted card + badge). *Alternative:* component kit (MUI) – heavier and less characterful for a small winery site.

**Client routing/data:** React Router (`/`, `/book/:tastingId`, `/staff`); plain `fetch` wrapped in a tiny typed API module, no data-fetching library (three screens). Tasting list is refetched on every visit to the start page so seats left are fresh.

**Tests:** Vitest (+ supertest for API, React Testing Library for components, jsdom), Playwright for end-to-end against the built app. Tests are written before the implementation of each layer.

**Layout:**
```
shared/      schema, types, money/date formatting
server/      catalog, store, app (createApp), index (listen)
client/      Vite root: src/{pages,components,api,styles}
tests/e2e/   Playwright specs
```

## Risks / Trade-offs

- [In-memory data is lost on restart] → Stated in the README; store interface allows a file/DB-backed store later.
- [Single-process session map is lost on restart / does not scale horizontally] → Acceptable for a one-instance winery site; staff just sign in again.
- ["1 seats left" reads awkwardly] → The brief fixes the format "<n> seats left"; kept verbatim for all n.
- [Cancel without confirmation dialog] → Single click matches the brief; the cancelled reference is announced in a status message so mistakes are visible. Cancelled bookings cannot be restored (guest would rebook).
- [No cutoff for past tastings] → The brief lists none and the dates are fixed; recorded as out of scope.
- [Playwright browser download may be unavailable] → If so, end-to-end checks fall back to the API/component tests and a scripted HTTP smoke test, and this is reported.
