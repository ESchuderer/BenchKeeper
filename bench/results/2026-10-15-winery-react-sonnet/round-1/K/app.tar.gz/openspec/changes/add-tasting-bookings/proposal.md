# Proposal

## Why

Weingut Kieselbrunnen, a family winery, takes tasting reservations informally today. Guests cannot see how many seats are left, and staff have no single list of who is coming. A small website where guests book a tasting themselves, and staff see and manage the bookings, removes the back-and-forth and prevents overbooking.

## What Changes

- New public site (React single-page app) with a start page listing the three upcoming tastings: title, date and time, price per guest, seats left (or a clear "Fully booked" state).
- New per-tasting booking form (Name, Email, Guests 1-8) with field-level error messages, followed by a "Booking confirmed" page showing tasting, guest count, total price and booking reference.
- New server-side booking rules: a booking can never take more seats than are left, even with concurrent requests; invalid input is rejected with per-field errors.
- New staff area at `/staff`, protected by a password taken from `STAFF_PASSWORD`, listing all bookings grouped by tasting and allowing a booking to be cancelled (which frees its seats).
- Visual design: a coherent winery look (warm palette, serif headings), responsive down to phone width, with distinct error, success and fully-booked states.
- Single `npm install` / `npm run build` / `npm start` workflow; `PORT` (default 3000) and `STAFF_PASSWORD` configure it. Bookings live in memory; the app starts with none.

## Capabilities

### New Capabilities
- `tasting-catalog`: the fixed list of tastings (title, start, price, capacity) and the public view of them with live seats left and fully-booked state.
- `guest-booking`: booking a tasting: input validation with per-field errors, capacity enforcement, booking reference, confirmation.
- `staff-bookings`: password-protected staff sign-in, bookings grouped by tasting, and cancellation that frees seats.

### Modified Capabilities
<!-- None: the project has no existing specs. -->

## Impact

- Greenfield project: adds `package.json`, a Node.js 22 / Express API server, a React (Vite) client, and unit, API and end-to-end tests.
- New runtime configuration: `PORT` (optional), `STAFF_PASSWORD` (required for staff sign-in; staff sign-in is refused if unset).
- No external services, database or network access at runtime.
- Out of scope: online payment, email sending, editing the tasting catalogue, booking cutoff times, persistence across restarts, multi-user staff accounts.
