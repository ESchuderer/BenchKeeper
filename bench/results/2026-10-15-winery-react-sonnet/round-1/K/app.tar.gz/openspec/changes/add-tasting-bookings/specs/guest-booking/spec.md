# Spec Delta

## Purpose

Lets a guest reserve seats at a tasting online, guaranteeing that a tasting is never overbooked and that invalid input is explained next to the field it concerns.

## ADDED Requirements

### Requirement: Booking form
The booking form for a tasting SHALL provide fields labelled "Name", "Email" and "Guests" and a button "Book". "Guests" accepts whole numbers from 1 to 8.

#### Scenario: Form fields are present
- **WHEN** a guest opens the booking form for Winter Tasting
- **THEN** the form shows the tasting title, date, time and price per guest
- **AND** has the fields "Name", "Email" and "Guests" and a "Book" button

#### Scenario: Unknown tasting
- **WHEN** a guest opens the booking form for a tasting that does not exist
- **THEN** the page says the tasting was not found and links back to the start page

### Requirement: Input validation with field-level errors
The system SHALL reject a booking with an error message shown next to the field concerned when: Name is empty or blank; Email is not a valid email address; Guests is not a whole number from 1 to 8. A rejected booking SHALL NOT change seat availability, and values already entered SHALL be kept.

#### Scenario: Empty form
- **WHEN** a guest submits the form with all fields empty
- **THEN** an error appears next to "Name", next to "Email" and next to "Guests"
- **AND** no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits Email "not-an-email"
- **THEN** an error appears next to "Email" only, and the entered Name and Guests remain in the form

#### Scenario: Guests out of range
- **WHEN** a guest submits Guests 0, 9, 2.5 or a non-number
- **THEN** an error appears next to "Guests" and no booking is created

#### Scenario: Server rejects what the client let through
- **WHEN** a booking request with invalid values reaches the server directly
- **THEN** the server refuses it with per-field error messages and creates no booking

### Requirement: Capacity is never exceeded
The system SHALL reject a booking whose Guests exceeds the seats left for the tasting, with an error next to "Guests" stating how many seats are left, and SHALL never allow total booked seats of a tasting to exceed its capacity, including under simultaneous requests.

#### Scenario: More guests than seats left
- **WHEN** 7 of 8 Red Wine Cellar Tour seats are booked and a guest requests 2 guests
- **THEN** the booking is rejected with an error next to "Guests" saying only 1 seat is left
- **AND** the tasting still shows 1 seat left

#### Scenario: Exactly the remaining seats
- **WHEN** 7 of 8 seats are booked and a guest requests 1 guest
- **THEN** the booking succeeds and the tasting becomes fully booked

#### Scenario: Simultaneous requests
- **WHEN** two requests for 5 guests each arrive at the same time for a tasting with 8 seats left
- **THEN** exactly one succeeds and the other is rejected for lack of seats

#### Scenario: Tasting is fully booked
- **WHEN** a booking request targets a fully booked tasting
- **THEN** it is rejected with a message that the tasting is fully booked

### Requirement: Booking confirmation
After a successful booking the system SHALL show a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (price per guest times guests, in EUR) and a unique booking reference.

#### Scenario: Confirmation content
- **WHEN** a guest books 2 guests for Riesling Evening
- **THEN** the confirmation shows heading "Booking confirmed", "Riesling Evening", 2 guests, total "EUR 50" and a booking reference
- **AND** the start page afterwards shows "10 seats left" for Riesling Evening

#### Scenario: References are unique
- **WHEN** two bookings are made
- **THEN** their booking references differ
