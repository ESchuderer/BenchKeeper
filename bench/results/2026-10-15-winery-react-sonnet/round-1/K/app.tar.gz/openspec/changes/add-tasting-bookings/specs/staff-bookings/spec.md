# Spec Delta

## Purpose

Gives winery staff a password-protected page to see all bookings grouped by tasting and to cancel a booking so its seats become available again.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a password in a field labelled "Password" with a "Sign in" button. The expected password SHALL come from the environment variable `STAFF_PASSWORD`. Without a correct password no booking data SHALL be disclosed, on the page or through the API. If `STAFF_PASSWORD` is unset or empty, nobody can sign in.

#### Scenario: Sign-in form
- **WHEN** an unauthenticated visitor opens `/staff`
- **THEN** they see a "Password" field and a "Sign in" button and no booking data

#### Scenario: Wrong password
- **WHEN** a visitor submits a password that differs from `STAFF_PASSWORD`
- **THEN** an error appears next to the "Password" field and the visitor stays signed out

#### Scenario: Correct password
- **WHEN** a visitor submits the password equal to `STAFF_PASSWORD`
- **THEN** the booking overview is shown, and stays available after reloading the page until the staff member signs out

#### Scenario: Unauthenticated API access
- **WHEN** the staff booking data or the cancel operation is requested without being signed in
- **THEN** the request is refused as unauthorized and nothing is changed

#### Scenario: Repeated wrong guesses
- **WHEN** a client submits many wrong passwords in a short time
- **THEN** further attempts are temporarily refused

### Requirement: Bookings grouped by tasting
A signed-in staff member SHALL see all bookings grouped by tasting, each with name, email, number of guests and booking reference. Tastings without bookings SHALL still be shown, marked as having no bookings.

#### Scenario: Grouped overview
- **WHEN** Anna booked 2 guests for Riesling Evening and Ben booked 3 for Winter Tasting, and staff are signed in
- **THEN** under Riesling Evening staff see Anna's name, email, 2 guests and reference
- **AND** under Winter Tasting staff see Ben's entry
- **AND** Red Wine Cellar Tour is shown with no bookings

#### Scenario: New bookings appear
- **WHEN** a guest books while staff have the overview open and staff reload it
- **THEN** the new booking is listed

### Requirement: Cancelling a booking
A signed-in staff member SHALL be able to cancel a booking with a "Cancel" button on that booking. Cancelling SHALL remove the booking from the overview and free its seats.

#### Scenario: Cancel frees seats
- **WHEN** a booking of 3 guests for Winter Tasting exists (7 seats left) and staff press "Cancel" on it
- **THEN** the booking disappears from the overview
- **AND** the start page shows "10 seats left" for Winter Tasting

#### Scenario: Cancelling an already cancelled booking
- **WHEN** a cancel request targets a booking that no longer exists
- **THEN** the system answers that the booking was not found and changes no seats

### Requirement: Staff sign-out
A signed-in staff member SHALL be able to sign out, after which the booking overview is no longer accessible without signing in again.

#### Scenario: Sign out
- **WHEN** staff press "Sign out"
- **THEN** the sign-in form is shown again and booking data requests are refused
