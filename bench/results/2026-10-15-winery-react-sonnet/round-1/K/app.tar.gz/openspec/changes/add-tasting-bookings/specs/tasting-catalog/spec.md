# Spec Delta

## Purpose

Defines the tastings Weingut Kieselbrunnen offers and how guests see them, including live seat availability and the fully-booked state.

## ADDED Requirements

### Requirement: Fixed tasting offering
The system SHALL offer exactly these tastings, each with a title, start date and time, price per guest and seat capacity: Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats), Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats).

#### Scenario: Fresh start lists all tastings with full capacity
- **WHEN** the application has just started and a guest opens the start page
- **THEN** the page lists Riesling Evening, Red Wine Cellar Tour and Winter Tasting in date order
- **AND** shows "12 seats left", "8 seats left" and "10 seats left" respectively

### Requirement: Tasting listing shows price, time and availability
The start page SHALL show, for each tasting, its title, date and time, price per guest in EUR, and the number of seats left as "<n> seats left".

#### Scenario: Price and time are visible
- **WHEN** a guest opens the start page
- **THEN** the Riesling Evening entry shows "EUR 25" per guest and the time 18:00 on 6 November 2026

#### Scenario: Seats left reflect bookings
- **WHEN** 3 guests have booked Riesling Evening and a guest opens the start page
- **THEN** the Riesling Evening entry shows "9 seats left"

### Requirement: Booking entry point per tasting
Each tasting with seats left SHALL offer a link or button named "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open the booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens, naming the tasting

### Requirement: Fully booked tastings are clearly marked
A tasting with no seats left SHALL be shown as "Fully booked", SHALL NOT offer a way to open its booking form from the start page, and SHALL be visually distinct from tastings with availability.

#### Scenario: Last seats taken
- **WHEN** all 8 seats of Red Wine Cellar Tour are booked
- **THEN** the start page shows "Fully booked" for it and no "Book Red Wine Cellar Tour" link

#### Scenario: Seats are freed by a cancellation
- **WHEN** staff cancel a booking of a fully booked tasting
- **THEN** the start page shows the freed seats as "<n> seats left" again and offers the Book link
