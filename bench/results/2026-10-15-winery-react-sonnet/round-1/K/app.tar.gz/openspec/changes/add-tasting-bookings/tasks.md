# Tasks

## 1. Project setup

- [x] 1.1 Create `package.json` (Node 22, scripts `build`, `start`, `test`, `test:e2e`, `typecheck`), TypeScript configs, Vite config, Vitest config, `.gitignore`; verify `npm install` succeeds
- [x] 1.2 Add dependencies (express, helmet, express-rate-limit, zod, react, react-dom, react-router, react-hook-form, @hookform/resolvers, tailwindcss, @fontsource fonts; dev: vite, vitest, supertest, testing-library, playwright, typescript) and verify `npm run typecheck` runs on the empty skeleton

## 2. Shared domain and booking store (tests first)

- [x] 2.1 Write failing unit tests for catalogue seeding, seats left, money/date formatting and the booking input schema (spec: tasting-catalog, guest-booking validation); verify they fail for the right reason
- [x] 2.2 Implement `shared/` (schema, types, formatting) and the catalogue; verify tests pass
- [x] 2.3 Write failing store tests (book, over-capacity, exact remaining seats, unique references, cancel frees seats, unknown ids), then implement the in-memory `BookingStore`; verify tests pass

## 3. HTTP API (tests first)

- [x] 3.1 Write failing supertest tests for `GET /api/tastings`, `POST /api/tastings/:id/bookings` (success, 422 per-field errors, over-capacity, fully booked, 404, concurrent requests, malformed JSON)
- [x] 3.2 Write failing supertest tests for staff routes (login success/failure, unset `STAFF_PASSWORD`, rate limiting, 401 without session, list grouped data, cancel, 404, logout, cookie flags)
- [x] 3.3 Implement `createApp` and `index.ts` (JSON API, sessions, helmet, static client with SPA fallback, `PORT`); verify all API tests pass and `npm run build && npm start` serves `/api/tastings`

## 4. Guest UI (tests first)

- [x] 4.1 Write failing component tests for the start page (title, date/time, price, "<n> seats left", "Book <title>" link, "Fully booked" without link) and implement the layout shell, theme and start page; verify tests pass
- [x] 4.2 Write failing component tests for the booking form (labels, client-side errors next to each field, server field errors mapped, over-capacity message, confirmation with "Booking confirmed", tasting, guests, total, reference, unknown tasting) and implement the form and confirmation; verify tests pass

## 5. Staff UI (tests first)

- [x] 5.1 Write failing component tests for `/staff` (sign-in form, wrong password error next to field, grouped bookings with name/email/guests/reference, empty groups, Cancel removes booking, sign out) and implement the page; verify tests pass

## 6. Look and feel

- [x] 6.1 Polish visual design (palette, typography, hero, cards, focus states, error/success/fully-booked states, responsive at 360 px); verify with screenshots at phone and desktop widths and an accessibility check (labels, contrast, keyboard path)

## 7. Integration and verification

- [x] 7.1 Add Playwright end-to-end tests for the guest journey (list → book → confirmation → seats decrease), validation errors, fully booked, and the staff journey (sign in → see booking → cancel → seats freed); verify they pass against `npm run build && npm start`
- [ ] 7.2 Write `README.md` (install, build, start, env vars, tests, assumptions) and verify the documented commands run as written; run full verification (typecheck, unit/API/component tests with coverage ≥ 80%, build) and code, React and security reviews; fix CRITICAL/HIGH findings
