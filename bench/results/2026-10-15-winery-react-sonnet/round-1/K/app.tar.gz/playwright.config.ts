import { defineConfig, devices } from '@playwright/test'

const PORT = 3100

export default defineConfig({
  testDir: 'tests/e2e',
  // The app keeps bookings in memory, so the journeys run in order against one server.
  fullyParallel: false,
  workers: 1,
  reporter: [['list']],
  use: { baseURL: `http://localhost:${PORT}`, trace: 'retain-on-failure' },
  projects: [
    { name: 'desktop', testMatch: 'journeys.spec.ts', use: { ...devices['Desktop Chrome'] } },
    { name: 'phone', testMatch: 'phone.spec.ts', dependencies: ['desktop'], use: { ...devices['Pixel 5'] } },
  ],
  webServer: {
    command: 'npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    reuseExistingServer: false,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-secret' },
  },
})
