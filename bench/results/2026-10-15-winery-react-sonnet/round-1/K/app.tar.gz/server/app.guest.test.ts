import request from 'supertest'
import { beforeEach, describe, expect, test } from 'vitest'
import { createApp } from './app.js'
import { createBookingStore } from './store.js'

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 }

let app: ReturnType<typeof createApp>
beforeEach(() => {
  app = createApp({ store: createBookingStore(), staffPassword: 'secret' })
})

const book = (id: string, body: unknown) => request(app).post(`/api/tastings/${id}/bookings`).send(body as object)

describe('GET /api/tastings', () => {
  test('lists the tastings with seats left', async () => {
    const res = await request(app).get('/api/tastings')
    expect(res.status).toBe(200)
    expect(res.body.tastings).toHaveLength(3)
    expect(res.body.tastings[0]).toMatchObject({ id: 'riesling-evening', title: 'Riesling Evening', priceCents: 2500, seatsLeft: 12 })
  })

  test('is not cached so seats left stay fresh', async () => {
    const res = await request(app).get('/api/tastings')
    expect(res.headers['cache-control']).toMatch(/no-store/)
  })

  test('sends security headers', async () => {
    const res = await request(app).get('/api/tastings')
    expect(res.headers['content-security-policy']).toContain("default-src 'self'")
    expect(res.headers['x-powered-by']).toBeUndefined()
  })
})

describe('POST /api/tastings/:id/bookings', () => {
  test('creates a booking and returns the confirmation', async () => {
    const res = await book('riesling-evening', valid)
    expect(res.status).toBe(201)
    expect(res.body.booking).toMatchObject({ guests: 2, totalCents: 5000, name: 'Anna Weber', email: 'anna@example.com' })
    expect(res.body.booking.reference).toMatch(/^KB-/)
    expect(res.body.tasting).toMatchObject({ title: 'Riesling Evening', seatsLeft: 10 })
    const list = await request(app).get('/api/tastings')
    expect(list.body.tastings[0].seatsLeft).toBe(10)
  })

  test('rejects invalid input with per-field errors and books nothing', async () => {
    const res = await book('riesling-evening', { name: '', email: 'nope', guests: 0 })
    expect(res.status).toBe(422)
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name'])
    expect((await request(app).get('/api/tastings')).body.tastings[0].seatsLeft).toBe(12)
  })

  test('rejects more guests than seats left with an error on guests', async () => {
    await book('red-wine-cellar-tour', { ...valid, guests: 7 })
    const res = await book('red-wine-cellar-tour', { ...valid, guests: 2 })
    expect(res.status).toBe(409)
    expect(res.body.errors.guests).toMatch(/only 1 seat is left/i)
    expect((await request(app).get('/api/tastings')).body.tastings[1].seatsLeft).toBe(1)
  })

  test('rejects bookings for a fully booked tasting', async () => {
    await book('red-wine-cellar-tour', { ...valid, guests: 8 })
    const res = await book('red-wine-cellar-tour', { ...valid, guests: 1 })
    expect(res.status).toBe(409)
    expect(res.body.message).toMatch(/fully booked/i)
    expect(res.body.errors.guests).toMatch(/fully booked/i)
  })

  test('never oversells under concurrent requests', async () => {
    const results = await Promise.all(
      Array.from({ length: 6 }, (_, i) => book('red-wine-cellar-tour', { ...valid, name: `Guest ${i}`, guests: 5 })),
    )
    expect(results.filter((r) => r.status === 201)).toHaveLength(1)
    expect(results.filter((r) => r.status === 409)).toHaveLength(5)
    expect((await request(app).get('/api/tastings')).body.tastings[1].seatsLeft).toBe(3)
  })

  test('answers 404 for an unknown tasting', async () => {
    const res = await book('nope', valid)
    expect(res.status).toBe(404)
    expect(res.body.message).toMatch(/not found/i)
  })

  test('answers 400 for malformed JSON', async () => {
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').set('Content-Type', 'application/json').send('{bad')
    expect(res.status).toBe(400)
    expect(res.body.message).toBeTruthy()
  })

  test('refuses non-JSON bodies', async () => {
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').type('form').send('name=a&email=b&guests=1')
    expect(res.status).toBe(415)
  })

  test('refuses oversized bodies', async () => {
    const res = await book('riesling-evening', { ...valid, name: 'x'.repeat(50_000) })
    expect(res.status).toBe(413)
  })
})

describe('unknown API routes', () => {
  test('answer 404 JSON', async () => {
    const res = await request(app).get('/api/nothing')
    expect(res.status).toBe(404)
    expect(res.body.message).toBeTruthy()
  })
})
