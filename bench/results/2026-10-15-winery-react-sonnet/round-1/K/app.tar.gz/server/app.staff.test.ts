import request from 'supertest'
import { beforeEach, describe, expect, test } from 'vitest'
import { createApp } from './app.js'
import { createBookingStore } from './store.js'

const PASSWORD = 'correct horse'
const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 3 }

let app: ReturnType<typeof createApp>
beforeEach(() => {
  app = createApp({ store: createBookingStore(), staffPassword: PASSWORD })
})

async function signIn(target = app) {
  const res = await request(target).post('/api/staff/login').send({ password: PASSWORD })
  const cookie = (res.headers['set-cookie'] as unknown as string[] | undefined)?.[0]?.split(';')[0]
  return { res, cookie: cookie ?? '' }
}

describe('POST /api/staff/login', () => {
  test('signs in with the right password and sets a hardened session cookie', async () => {
    const { res } = await signIn()
    expect(res.status).toBe(200)
    const setCookie = (res.headers['set-cookie'] as unknown as string[])[0]!
    expect(setCookie).toMatch(/HttpOnly/i)
    expect(setCookie).toMatch(/SameSite=Strict/i)
    expect(setCookie).toMatch(/Path=\//)
    expect(setCookie).not.toMatch(/Secure/i)
  })

  test('marks the cookie Secure when configured for https', async () => {
    const secure = createApp({ store: createBookingStore(), staffPassword: PASSWORD, secureCookies: true })
    const { res } = await signIn(secure)
    expect((res.headers['set-cookie'] as unknown as string[])[0]).toMatch(/Secure/i)
  })

  test('rejects a wrong password with a field error and no cookie', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: 'wrong' })
    expect(res.status).toBe(401)
    expect(res.body.errors.password).toBeTruthy()
    expect(res.headers['set-cookie']).toBeUndefined()
  })

  test('rejects missing and non-string passwords', async () => {
    expect((await request(app).post('/api/staff/login').send({})).status).toBe(401)
    expect((await request(app).post('/api/staff/login').send({ password: 123 })).status).toBe(401)
  })

  test('refuses everyone when STAFF_PASSWORD is unset or empty', async () => {
    for (const staffPassword of [undefined, '']) {
      const closed = createApp({ store: createBookingStore(), staffPassword })
      expect((await request(closed).post('/api/staff/login').send({ password: '' })).status).toBe(401)
      expect((await request(closed).post('/api/staff/login').send({ password: 'undefined' })).status).toBe(401)
    }
  })

  test('temporarily refuses a client that keeps guessing', async () => {
    let last = 0
    for (let i = 0; i < 12; i++) {
      last = (await request(app).post('/api/staff/login').send({ password: `guess ${i}` })).status
    }
    expect(last).toBe(429)
    expect((await request(app).post('/api/staff/login').send({ password: PASSWORD })).status).toBe(429)
  })
})

describe('staff data', () => {
  test('GET /api/staff/bookings and DELETE are unauthorized without a session', async () => {
    await request(app).post('/api/tastings/winter-tasting/bookings').send(guest)
    const list = await request(app).get('/api/staff/bookings')
    expect(list.status).toBe(401)
    expect(JSON.stringify(list.body)).not.toContain('anna@example.com')
    const ref = (await request(app).post('/api/tastings/winter-tasting/bookings').send(guest)).body.booking.reference
    expect((await request(app).delete(`/api/staff/bookings/${ref}`)).status).toBe(401)
    expect((await request(app).get('/api/tastings')).body.tastings[2].seatsLeft).toBe(4)
  })

  test('rejects forged or unknown session cookies', async () => {
    const res = await request(app).get('/api/staff/bookings').set('Cookie', 'kb_staff=forged')
    expect(res.status).toBe(401)
  })

  test('lists bookings grouped by tasting, including empty tastings', async () => {
    await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guest, guests: 2 })
    await request(app).post('/api/tastings/winter-tasting/bookings').send({ ...guest, name: 'Ben Roth' })
    const { cookie } = await signIn()
    const res = await request(app).get('/api/staff/bookings').set('Cookie', cookie)
    expect(res.status).toBe(200)
    expect(res.headers['cache-control']).toMatch(/no-store/)
    const groups = res.body.groups as { tasting: { id: string }; bookings: { name: string; email: string; guests: number; reference: string }[] }[]
    expect(groups.map((g) => [g.tasting.id, g.bookings.length])).toEqual([
      ['riesling-evening', 1],
      ['red-wine-cellar-tour', 0],
      ['winter-tasting', 1],
    ])
    expect(groups[0]!.bookings[0]).toMatchObject({ name: 'Anna Weber', email: 'anna@example.com', guests: 2 })
    expect(groups[0]!.bookings[0]!.reference).toMatch(/^KB-/)
  })

  test('cancels a booking and frees its seats', async () => {
    const ref = (await request(app).post('/api/tastings/winter-tasting/bookings').send(guest)).body.booking.reference
    expect((await request(app).get('/api/tastings')).body.tastings[2].seatsLeft).toBe(7)
    const { cookie } = await signIn()
    const res = await request(app).delete(`/api/staff/bookings/${ref}`).set('Cookie', cookie)
    expect(res.status).toBe(204)
    expect((await request(app).get('/api/tastings')).body.tastings[2].seatsLeft).toBe(10)
  })

  test('answers 404 when cancelling a booking that no longer exists', async () => {
    const { cookie } = await signIn()
    const res = await request(app).delete('/api/staff/bookings/KB-GONE22').set('Cookie', cookie)
    expect(res.status).toBe(404)
  })
})

describe('session and sign-out', () => {
  test('GET /api/staff/session reports the sign-in state', async () => {
    expect((await request(app).get('/api/staff/session')).body).toEqual({ signedIn: false })
    const { cookie } = await signIn()
    expect((await request(app).get('/api/staff/session').set('Cookie', cookie)).body).toEqual({ signedIn: true })
  })

  test('logout invalidates the session', async () => {
    const { cookie } = await signIn()
    expect((await request(app).post('/api/staff/logout').set('Cookie', cookie)).status).toBe(204)
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401)
  })

  test('sessions expire', async () => {
    let now = 1_000_000
    const aging = createApp({ store: createBookingStore(), staffPassword: PASSWORD, now: () => now, sessionTtlMs: 60_000 })
    const { cookie } = await signIn(aging)
    expect((await request(aging).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(200)
    now += 61_000
    expect((await request(aging).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401)
  })
})
