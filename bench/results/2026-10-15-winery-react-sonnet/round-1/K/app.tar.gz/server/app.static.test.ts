import { mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import request from 'supertest'
import { afterAll, beforeAll, describe, expect, test } from 'vitest'
import { createApp } from './app.js'
import { createBookingStore } from './store.js'

let dir: string
let app: ReturnType<typeof createApp>

beforeAll(() => {
  dir = mkdtempSync(join(tmpdir(), 'kb-client-'))
  writeFileSync(join(dir, 'index.html'), '<!doctype html><title>Kieselbrunnen</title><div id="root"></div>')
  app = createApp({ store: createBookingStore(), staffPassword: 'x', clientDir: dir })
})
afterAll(() => rmSync(dir, { recursive: true, force: true }))

describe('serving the client', () => {
  test('serves index.html at /', async () => {
    const res = await request(app).get('/')
    expect(res.status).toBe(200)
    expect(res.text).toContain('Kieselbrunnen')
  })

  test.each(['/staff', '/book/riesling-evening', '/anything/else'])('falls back to index.html for client route %s', async (path) => {
    const res = await request(app).get(path)
    expect(res.status).toBe(200)
    expect(res.headers['content-type']).toMatch(/html/)
    expect(res.text).toContain('id="root"')
  })

  test('does not fall back for API paths', async () => {
    const res = await request(app).get('/api/missing')
    expect(res.status).toBe(404)
    expect(res.headers['content-type']).toMatch(/json/)
  })
})
