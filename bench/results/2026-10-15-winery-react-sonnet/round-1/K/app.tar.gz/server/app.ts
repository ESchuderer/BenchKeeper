import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { parseCookie } from 'cookie'
import express, { type ErrorRequestHandler, type NextFunction, type Request, type RequestHandler, type Response } from 'express'
import { rateLimit } from 'express-rate-limit'
import helmet from 'helmet'
import { validateBookingInput } from '../shared/booking-schema.js'
import type { ApiErrorBody, BookingConfirmation } from '../shared/types.js'
import { passwordMatches } from './password.js'
import { createSessionStore } from './sessions.js'
import { createBookingStore, type BookingStore } from './store.js'

export interface AppOptions {
  store?: BookingStore
  /** Staff password (STAFF_PASSWORD). When unset or empty nobody can sign in. */
  staffPassword?: string | undefined
  /** Directory with the built client; when it contains index.html it is served. */
  clientDir?: string
  secureCookies?: boolean
  sessionTtlMs?: number
  now?: () => number
  loginAttempts?: { max: number; windowMs: number }
}

const SESSION_COOKIE = 'kb_staff'
const DEFAULT_SESSION_TTL_MS = 8 * 60 * 60 * 1000
const DEFAULT_LOGIN_ATTEMPTS = { max: 10, windowMs: 15 * 60 * 1000 }
const JSON_BODY_LIMIT = '10kb'

const sendError = (res: Response, status: number, message: string, errors?: ApiErrorBody['errors']) => {
  const body: ApiErrorBody = errors ? { message, errors } : { message }
  res.status(status).json(body)
}

const requireJson: RequestHandler = (req, res, next) => {
  if (!req.is('application/json')) return sendError(res, 415, 'Send the request as application/json.')
  next()
}

const seatsMessage = (seatsLeft: number) => `Only ${seatsLeft} ${seatsLeft === 1 ? 'seat is' : 'seats are'} left for this tasting.`

export function createApp(options: AppOptions = {}) {
  const store = options.store ?? createBookingStore()
  const now = options.now ?? Date.now
  const sessions = createSessionStore(options.sessionTtlMs ?? DEFAULT_SESSION_TTL_MS, now)
  const loginAttempts = options.loginAttempts ?? DEFAULT_LOGIN_ATTEMPTS

  const app = express()
  app.disable('x-powered-by')
  app.use(helmet({ contentSecurityPolicy: { directives: { ...helmet.contentSecurityPolicy.getDefaultDirectives(), 'upgrade-insecure-requests': null } } }))

  const sessionToken = (req: Request) => parseCookie(req.headers.cookie ?? '')[SESSION_COOKIE]

  const requireStaff = (req: Request, res: Response, next: NextFunction) => {
    if (!sessions.isValid(sessionToken(req))) return sendError(res, 401, 'Please sign in.')
    next()
  }

  const api = express.Router()
  api.use((_req, res, next) => {
    res.set('Cache-Control', 'no-store')
    next()
  })
  api.use(express.json({ limit: JSON_BODY_LIMIT }))

  api.get('/tastings', (_req, res) => {
    res.json({ tastings: store.listTastings() })
  })

  api.post('/tastings/:id/bookings', requireJson, (req, res) => {
    const tastingId = String(req.params.id)
    if (!store.getTasting(tastingId)) return sendError(res, 404, 'Tasting not found.')

    const input = validateBookingInput(req.body)
    if (!input.ok) return sendError(res, 422, 'Please correct the highlighted fields.', input.errors)

    const result = store.book(tastingId, input.data)
    if (!result.ok) {
      if (result.reason === 'not_found') return sendError(res, 404, 'Tasting not found.')
      const message = result.reason === 'fully_booked' ? 'This tasting is fully booked.' : seatsMessage(result.seatsLeft)
      return sendError(res, 409, message, { guests: message })
    }
    const confirmation: BookingConfirmation = { booking: result.booking, tasting: store.getTasting(tastingId)! }
    res.status(201).json(confirmation)
  })

  const loginLimiter = rateLimit({
    windowMs: loginAttempts.windowMs,
    limit: loginAttempts.max,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => sendError(res, 429, 'Too many attempts. Please wait a few minutes and try again.', { password: 'Too many attempts. Please wait a few minutes.' }),
  })

  api.post('/staff/login', loginLimiter, requireJson, (req, res) => {
    const password: unknown = req.body?.password
    if (!passwordMatches(options.staffPassword, password)) {
      return sendError(res, 401, 'Wrong password.', { password: 'That password is not correct.' })
    }
    const ttl = options.sessionTtlMs ?? DEFAULT_SESSION_TTL_MS
    res.cookie(SESSION_COOKIE, sessions.create(), {
      httpOnly: true,
      sameSite: 'strict',
      secure: options.secureCookies ?? false,
      path: '/',
      maxAge: ttl,
    })
    res.json({ signedIn: true })
  })

  api.post('/staff/logout', (req, res) => {
    sessions.destroy(sessionToken(req))
    res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: 'strict', secure: options.secureCookies ?? false, path: '/' })
    res.status(204).end()
  })

  api.get('/staff/session', (req, res) => {
    res.json({ signedIn: sessions.isValid(sessionToken(req)) })
  })

  api.get('/staff/bookings', requireStaff, (_req, res) => {
    res.json({ groups: store.listByTasting() })
  })

  api.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(String(req.params.reference))) return sendError(res, 404, 'Booking not found.')
    res.status(204).end()
  })

  api.use((_req, res) => sendError(res, 404, 'Not found.'))
  app.use('/api', api)

  const indexFile = options.clientDir ? join(options.clientDir, 'index.html') : undefined
  if (options.clientDir && indexFile && existsSync(indexFile)) {
    app.use(express.static(options.clientDir, { index: false }))
    app.get('/{*path}', (_req, res) => res.sendFile(indexFile))
  }

  const onError: ErrorRequestHandler = (err: { status?: number; type?: string }, _req, res, _next) => {
    if (err.type === 'entity.too.large') return sendError(res, 413, 'Request is too large.')
    if (err.type === 'entity.parse.failed') return sendError(res, 400, 'Request body is not valid JSON.')
    console.error(err)
    sendError(res, 500, 'Something went wrong. Please try again.')
  }
  app.use(onError)

  return app
}
