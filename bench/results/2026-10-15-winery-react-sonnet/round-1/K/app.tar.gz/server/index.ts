import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createApp } from './app.js'

const DEFAULT_PORT = 3000

const here = dirname(fileURLToPath(import.meta.url))
// Compiled layout: dist/server/server/index.js, client build in dist/client.
const clientDir = resolve(here, '../../client')

const staffPassword = process.env.STAFF_PASSWORD
if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.')
}

const port = Number(process.env.PORT) || DEFAULT_PORT
const app = createApp({
  staffPassword,
  clientDir,
  secureCookies: process.env.SECURE_COOKIES === 'true',
})

app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings listening on http://localhost:${port}`)
})
