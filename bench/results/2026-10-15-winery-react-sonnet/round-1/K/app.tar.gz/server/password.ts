import { createHash, timingSafeEqual } from 'node:crypto'

const digest = (value: string) => createHash('sha256').update(value).digest()

/** Constant-time comparison; an unset or empty expected password never matches. */
export function passwordMatches(expected: string | undefined, given: unknown): boolean {
  if (!expected || typeof given !== 'string') return false
  return timingSafeEqual(digest(expected), digest(given))
}
