import { randomBytes } from 'node:crypto'

export interface SessionStore {
  create(): string
  isValid(token: string | undefined): boolean
  destroy(token: string | undefined): void
}

/** In-memory staff sessions: random 256-bit tokens that expire after `ttlMs`. */
export function createSessionStore(ttlMs: number, now: () => number = Date.now): SessionStore {
  const expiresAt = new Map<string, number>()

  const purgeExpired = () => {
    const t = now()
    for (const [token, expiry] of expiresAt) if (expiry <= t) expiresAt.delete(token)
  }

  return {
    create() {
      purgeExpired()
      const token = randomBytes(32).toString('base64url')
      expiresAt.set(token, now() + ttlMs)
      return token
    },
    isValid(token) {
      if (!token) return false
      const expiry = expiresAt.get(token)
      if (expiry === undefined) return false
      if (expiry <= now()) {
        expiresAt.delete(token)
        return false
      }
      return true
    },
    destroy(token) {
      if (token) expiresAt.delete(token)
    },
  }
}
