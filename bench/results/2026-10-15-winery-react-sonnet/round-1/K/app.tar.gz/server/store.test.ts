import { beforeEach, describe, expect, test } from 'vitest'
import { createBookingStore, type BookingStore } from './store.js'

const guest = (guests: number, name = 'Anna Weber') => ({ name, email: 'anna@example.com', guests })

let store: BookingStore
beforeEach(() => {
  store = createBookingStore()
})

describe('listTastings', () => {
  test('starts with no bookings and full capacity', () => {
    expect(store.listTastings().map((t) => [t.title, t.seatsLeft])).toEqual([
      ['Riesling Evening', 12],
      ['Red Wine Cellar Tour', 8],
      ['Winter Tasting', 10],
    ])
  })
})

describe('book', () => {
  test('creates a booking with total price and reference and reduces seats left', () => {
    const result = store.book('riesling-evening', guest(2))
    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.booking).toMatchObject({ tastingId: 'riesling-evening', guests: 2, totalCents: 5000, name: 'Anna Weber' })
    expect(result.booking.reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/)
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBe(10)
  })

  test('rejects more guests than seats left and leaves seats untouched', () => {
    store.book('red-wine-cellar-tour', guest(7))
    const result = store.book('red-wine-cellar-tour', guest(2))
    expect(result).toEqual({ ok: false, reason: 'not_enough_seats', seatsLeft: 1 })
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(1)
  })

  test('accepts exactly the remaining seats, making the tasting fully booked', () => {
    store.book('red-wine-cellar-tour', guest(7))
    expect(store.book('red-wine-cellar-tour', guest(1)).ok).toBe(true)
    expect(store.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(0)
  })

  test('reports a fully booked tasting', () => {
    store.book('red-wine-cellar-tour', guest(8))
    expect(store.book('red-wine-cellar-tour', guest(1))).toEqual({ ok: false, reason: 'fully_booked' })
  })

  test('reports unknown tastings', () => {
    expect(store.book('nope', guest(1))).toEqual({ ok: false, reason: 'not_found' })
  })

  test('never exceeds capacity over many bookings and issues unique references', () => {
    const refs = new Set<string>()
    for (let i = 0; i < 40; i++) {
      const r = store.book('riesling-evening', guest(1 + (i % 3)))
      if (r.ok) refs.add(r.booking.reference)
    }
    expect(store.getTasting('riesling-evening')?.seatsLeft).toBeGreaterThanOrEqual(0)
    const booked = store.listByTasting().find((g) => g.tasting.id === 'riesling-evening')!.bookings
    expect(booked.reduce((n, b) => n + b.guests, 0)).toBeLessThanOrEqual(12)
    expect(refs.size).toBe(booked.length)
  })
})

describe('listByTasting', () => {
  test('groups bookings per tasting and includes empty tastings', () => {
    store.book('riesling-evening', guest(2, 'Anna'))
    store.book('winter-tasting', guest(3, 'Ben'))
    const groups = store.listByTasting()
    expect(groups.map((g) => [g.tasting.id, g.bookings.map((b) => b.name)])).toEqual([
      ['riesling-evening', ['Anna']],
      ['red-wine-cellar-tour', []],
      ['winter-tasting', ['Ben']],
    ])
  })

  test('does not let callers mutate the store', () => {
    store.book('riesling-evening', guest(2))
    const groups = store.listByTasting()
    groups[0]!.bookings.length = 0
    expect(store.listByTasting()[0]!.bookings).toHaveLength(1)
  })
})

describe('cancel', () => {
  test('removes the booking and frees its seats', () => {
    const r = store.book('winter-tasting', guest(3))
    if (!r.ok) throw new Error('booking failed')
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(7)
    expect(store.cancel(r.booking.reference)).toBe(true)
    expect(store.getTasting('winter-tasting')?.seatsLeft).toBe(10)
  })

  test('returns false for unknown or already cancelled references', () => {
    const r = store.book('winter-tasting', guest(1))
    if (!r.ok) throw new Error('booking failed')
    expect(store.cancel(r.booking.reference)).toBe(true)
    expect(store.cancel(r.booking.reference)).toBe(false)
    expect(store.cancel('KB-NOPE00')).toBe(false)
  })
})
