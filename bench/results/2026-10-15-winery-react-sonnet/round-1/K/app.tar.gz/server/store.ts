import { randomInt } from 'node:crypto'
import { TASTINGS, type Tasting } from '../shared/catalog.js'
import type { BookingInput } from '../shared/booking-schema.js'
import type { Booking, StaffTastingGroup, TastingView } from '../shared/types.js'

export type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: 'not_found' }
  | { ok: false; reason: 'fully_booked' }
  | { ok: false; reason: 'not_enough_seats'; seatsLeft: number }

export interface BookingStore {
  listTastings(): TastingView[]
  getTasting(id: string): TastingView | undefined
  book(tastingId: string, input: BookingInput): BookResult
  listByTasting(): StaffTastingGroup[]
  cancel(reference: string): boolean
}

const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
const REFERENCE_LENGTH = 6

function newReference(): string {
  let code = ''
  for (let i = 0; i < REFERENCE_LENGTH; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)]
  return `KB-${code}`
}

/**
 * In-memory store. `book` checks capacity and inserts synchronously (no awaits in between),
 * so concurrent requests cannot oversell a tasting. Seats left are always derived from bookings.
 */
export function createBookingStore(tastings: readonly Tasting[] = TASTINGS): BookingStore {
  const bookings = new Map<string, Booking>()

  const bookingsFor = (tastingId: string) => [...bookings.values()].filter((b) => b.tastingId === tastingId)

  const view = (tasting: Tasting): TastingView => ({
    ...tasting,
    seatsLeft: tasting.capacity - bookingsFor(tasting.id).reduce((sum, b) => sum + b.guests, 0),
  })

  const find = (id: string) => tastings.find((t) => t.id === id)

  return {
    listTastings: () => tastings.map(view),

    getTasting: (id) => {
      const tasting = find(id)
      return tasting && view(tasting)
    },

    book(tastingId, input) {
      const tasting = find(tastingId)
      if (!tasting) return { ok: false, reason: 'not_found' }
      const { seatsLeft } = view(tasting)
      if (seatsLeft === 0) return { ok: false, reason: 'fully_booked' }
      if (input.guests > seatsLeft) return { ok: false, reason: 'not_enough_seats', seatsLeft }

      let reference = newReference()
      while (bookings.has(reference)) reference = newReference()
      const booking: Booking = {
        reference,
        tastingId,
        name: input.name,
        email: input.email,
        guests: input.guests,
        totalCents: input.guests * tasting.priceCents,
        createdAt: new Date().toISOString(),
      }
      bookings.set(reference, booking)
      return { ok: true, booking: { ...booking } }
    },

    listByTasting: () =>
      tastings.map((tasting) => ({ tasting: view(tasting), bookings: bookingsFor(tasting.id).map((b) => ({ ...b })) })),

    cancel: (reference) => bookings.delete(reference),
  }
}
