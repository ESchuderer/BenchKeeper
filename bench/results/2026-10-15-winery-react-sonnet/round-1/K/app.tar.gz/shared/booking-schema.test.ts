import { describe, expect, test } from 'vitest'
import { MAX_GUESTS_PER_BOOKING, validateBookingInput } from './booking-schema.js'

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 }

describe('validateBookingInput', () => {
  test('accepts valid input and trims text', () => {
    const result = validateBookingInput({ name: '  Anna Weber ', email: ' anna@example.com ', guests: 2 })
    expect(result).toEqual({ ok: true, data: valid })
  })

  test('accepts guests given as a numeric string (form input)', () => {
    expect(validateBookingInput({ ...valid, guests: '3' })).toEqual({ ok: true, data: { ...valid, guests: 3 } })
  })

  test('reports an error for every empty field', () => {
    const result = validateBookingInput({ name: '', email: '', guests: '' })
    expect(result.ok).toBe(false)
    if (!result.ok) expect(Object.keys(result.errors).sort()).toEqual(['email', 'guests', 'name'])
  })

  test('rejects blank names', () => {
    const result = validateBookingInput({ ...valid, name: '   ' })
    expect(result).toMatchObject({ ok: false, errors: { name: expect.any(String) } })
  })

  test.each(['not-an-email', 'a@b', '@example.com', 'a b@example.com'])('rejects email %s', (email) => {
    const result = validateBookingInput({ ...valid, email })
    expect(result).toMatchObject({ ok: false, errors: { email: expect.any(String) } })
  })

  test.each([0, -1, 9, 2.5, 'abc', '', null, undefined, true, NaN, '1e1'])('rejects guests %s', (guests) => {
    const result = validateBookingInput({ ...valid, guests })
    expect(result).toMatchObject({ ok: false, errors: { guests: expect.any(String) } })
    if (!result.ok) expect(Object.keys(result.errors)).toEqual(['guests'])
  })

  test(`accepts the bounds 1 and ${MAX_GUESTS_PER_BOOKING}`, () => {
    expect(validateBookingInput({ ...valid, guests: 1 }).ok).toBe(true)
    expect(validateBookingInput({ ...valid, guests: MAX_GUESTS_PER_BOOKING }).ok).toBe(true)
  })

  test('rejects overlong values and non-object input', () => {
    expect(validateBookingInput({ ...valid, name: 'x'.repeat(101) }).ok).toBe(false)
    expect(validateBookingInput(null).ok).toBe(false)
    expect(validateBookingInput('nope').ok).toBe(false)
  })
})
