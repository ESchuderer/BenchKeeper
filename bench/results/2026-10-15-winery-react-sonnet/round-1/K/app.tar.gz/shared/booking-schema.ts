import { z } from 'zod'

export const MAX_GUESTS_PER_BOOKING = 8
export const MAX_NAME_LENGTH = 100
export const MAX_EMAIL_LENGTH = 200

export const GUESTS_MESSAGE = `Enter a whole number of guests from 1 to ${MAX_GUESTS_PER_BOOKING}.`

/** Form inputs deliver strings; accept whole-number strings, reject everything else non-numeric. */
const toNumber = (value: unknown): unknown => {
  if (typeof value !== 'string') return value
  const trimmed = value.trim()
  return /^\d+$/.test(trimmed) ? Number(trimmed) : value
}

export const bookingInputSchema = z.object({
  name: z
    .string({ error: 'Enter your name.' })
    .trim()
    .min(1, 'Enter your name.')
    .max(MAX_NAME_LENGTH, `Name must be at most ${MAX_NAME_LENGTH} characters.`),
  email: z
    .string({ error: 'Enter your email address.' })
    .trim()
    .min(1, 'Enter your email address.')
    .max(MAX_EMAIL_LENGTH, `Email must be at most ${MAX_EMAIL_LENGTH} characters.`)
    .regex(/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, 'Enter a valid email address, e.g. name@example.com.'),
  guests: z.preprocess(
    toNumber,
    z
      .number({ error: GUESTS_MESSAGE })
      .int(GUESTS_MESSAGE)
      .min(1, GUESTS_MESSAGE)
      .max(MAX_GUESTS_PER_BOOKING, GUESTS_MESSAGE),
  ),
})

export type BookingInput = z.output<typeof bookingInputSchema>
export type BookingField = keyof BookingInput
export type FieldErrors = Partial<Record<BookingField, string>>

export type ValidationResult = { ok: true; data: BookingInput } | { ok: false; errors: FieldErrors }

export function validateBookingInput(input: unknown): ValidationResult {
  const parsed = bookingInputSchema.safeParse(input ?? {})
  if (parsed.success) return { ok: true, data: parsed.data }
  const errors: FieldErrors = {}
  for (const issue of parsed.error.issues) {
    const field = issue.path[0]
    if ((field === 'name' || field === 'email' || field === 'guests') && !errors[field]) {
      errors[field] = issue.message
    }
  }
  return { ok: false, errors }
}
