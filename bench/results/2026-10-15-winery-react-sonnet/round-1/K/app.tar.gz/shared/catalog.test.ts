import { describe, expect, test } from 'vitest'
import { TASTINGS } from './catalog.js'

describe('tasting catalogue', () => {
  test('offers exactly the three tastings from the brief in date order', () => {
    expect(TASTINGS.map(({ title, startsAt, priceCents, capacity }) => ({ title, startsAt, priceCents, capacity }))).toEqual([
      { title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceCents: 2500, capacity: 12 },
      { title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceCents: 3200, capacity: 8 },
      { title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceCents: 2800, capacity: 10 },
    ])
  })

  test('uses unique url-safe ids', () => {
    const ids = TASTINGS.map((t) => t.id)
    expect(new Set(ids).size).toBe(ids.length)
    ids.forEach((id) => expect(id).toMatch(/^[a-z0-9-]+$/))
  })
})
