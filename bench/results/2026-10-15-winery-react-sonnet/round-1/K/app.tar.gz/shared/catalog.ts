export interface Tasting {
  readonly id: string
  readonly title: string
  /** Local wall-clock start, `YYYY-MM-DDTHH:mm`, without a time zone. */
  readonly startsAt: string
  readonly priceCents: number
  readonly capacity: number
}

export const TASTINGS: readonly Tasting[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceCents: 2500, capacity: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceCents: 3200, capacity: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceCents: 2800, capacity: 10 },
]
