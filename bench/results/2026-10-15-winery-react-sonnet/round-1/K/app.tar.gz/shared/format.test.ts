import { describe, expect, test } from 'vitest'
import { formatMoney, formatSeatsLeft, formatStart } from './format.js'

describe('formatMoney', () => {
  test('omits decimals for whole euros', () => {
    expect(formatMoney(2500)).toBe('EUR 25')
    expect(formatMoney(5000)).toBe('EUR 50')
  })
  test('shows two decimals otherwise', () => {
    expect(formatMoney(2550)).toBe('EUR 25.50')
  })
})

describe('formatStart', () => {
  test('formats wall-clock date and time without time-zone shifts', () => {
    expect(formatStart('2026-11-06T18:00')).toEqual({ date: 'Friday, 6 November 2026', time: '18:00' })
    expect(formatStart('2026-12-05T17:00')).toEqual({ date: 'Saturday, 5 December 2026', time: '17:00' })
  })
})

describe('formatSeatsLeft', () => {
  test('uses the "<n> seats left" wording for every n', () => {
    expect(formatSeatsLeft(12)).toBe('12 seats left')
    expect(formatSeatsLeft(1)).toBe('1 seats left')
    expect(formatSeatsLeft(0)).toBe('0 seats left')
  })
})
