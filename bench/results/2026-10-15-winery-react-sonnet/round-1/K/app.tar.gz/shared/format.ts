export function formatMoney(cents: number): string {
  const euros = cents / 100
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`
}

const dateFormat = new Intl.DateTimeFormat('en-GB', {
  weekday: 'long',
  day: 'numeric',
  month: 'long',
  year: 'numeric',
  timeZone: 'UTC',
})

/** Formats a wall-clock `YYYY-MM-DDTHH:mm` string; no time-zone conversion takes place. */
export function formatStart(startsAt: string): { date: string; time: string } {
  const [day = '', time = ''] = startsAt.split('T')
  return { date: dateFormat.format(new Date(`${day}T00:00:00Z`)), time }
}

export function formatSeatsLeft(seatsLeft: number): string {
  return `${seatsLeft} seats left`
}
