
export interface TastingView {
  id: string
  title: string
  startsAt: string
  priceCents: number
  capacity: number
  seatsLeft: number
}

export interface Booking {
  reference: string
  tastingId: string
  name: string
  email: string
  guests: number
  totalCents: number
  createdAt: string
}

export interface BookingConfirmation {
  booking: Booking
  tasting: TastingView
}

export interface StaffTastingGroup {
  tasting: TastingView
  bookings: Booking[]
}

export interface ApiErrorBody {
  message: string
  errors?: Record<string, string>
}
