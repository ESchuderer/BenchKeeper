import AxeBuilder from '@axe-core/playwright'
import { expect, test, type Page } from '@playwright/test'

const STAFF_PASSWORD = 'e2e-secret'

async function book(page: Page, tasting: string, name: string, email: string, guests: string) {
  await page.goto('/')
  await page.getByRole('link', { name: `Book ${tasting}` }).click()
  await page.getByLabel('Name').fill(name)
  await page.getByLabel('Email').fill(email)
  await page.getByLabel('Guests').fill(guests)
  await page.getByRole('button', { name: 'Book', exact: true }).click()
}

const card = (page: Page, title: string) => page.getByRole('article', { name: title })

async function signIn(page: Page) {
  await page.goto('/staff')
  await page.getByLabel('Password').fill(STAFF_PASSWORD)
  await page.getByRole('button', { name: 'Sign in' }).click()
}

test.describe.serial('guest and staff journeys', () => {
  test('start page lists the three tastings with price, time and seats left', async ({ page }) => {
    await page.goto('/')
    await expect(card(page, 'Riesling Evening')).toContainText('12 seats left')
    await expect(card(page, 'Riesling Evening')).toContainText('EUR 25')
    await expect(card(page, 'Riesling Evening')).toContainText('18:00')
    await expect(card(page, 'Red Wine Cellar Tour')).toContainText('8 seats left')
    await expect(card(page, 'Red Wine Cellar Tour')).toContainText('EUR 32')
    await expect(card(page, 'Winter Tasting')).toContainText('10 seats left')
    await expect(card(page, 'Winter Tasting')).toContainText('EUR 28')
  })

  test('invalid input is rejected next to the field concerned', async ({ page }) => {
    await page.goto('/')
    await page.getByRole('link', { name: 'Book Riesling Evening' }).click()
    await page.getByRole('button', { name: 'Book', exact: true }).click()
    await expect(page.getByLabel('Name')).toHaveAccessibleDescription(/enter your name/i)
    await expect(page.getByLabel('Email')).toHaveAccessibleDescription(/enter your email/i)
    await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/from 1 to 8/i)

    await page.getByLabel('Name').fill('Anna Weber')
    await page.getByLabel('Email').fill('anna-at-example')
    await page.getByLabel('Guests').fill('9')
    await page.getByRole('button', { name: 'Book', exact: true }).click()
    await expect(page.getByLabel('Name')).not.toHaveAttribute('aria-invalid', 'true')
    await expect(page.getByLabel('Email')).toHaveAccessibleDescription(/valid email/i)
    await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/from 1 to 8/i)
  })

  test('a guest books and sees the confirmation; seats left drop', async ({ page }) => {
    await book(page, 'Riesling Evening', 'Anna Weber', 'anna@example.com', '2')
    const confirmation = page.getByRole('region', { name: 'Booking confirmed' })
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
    await expect(confirmation).toContainText('Riesling Evening')
    await expect(confirmation).toContainText('EUR 50')
    await expect(confirmation).toContainText(/KB-[A-Z0-9]{6}/)

    await page.getByRole('link', { name: 'Back to all tastings' }).click()
    await expect(card(page, 'Riesling Evening')).toContainText('10 seats left')
  })

  test('a booking can never take more seats than are left', async ({ page }) => {
    await book(page, 'Red Wine Cellar Tour', 'Ben Roth', 'ben@example.com', '7')
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()

    await book(page, 'Red Wine Cellar Tour', 'Clara Vogt', 'clara@example.com', '2')
    await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/only 1 seat is left/i)
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0)

    await page.getByLabel('Guests').fill('1')
    await page.getByRole('button', { name: 'Book', exact: true }).click()
    await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible()
  })

  test('a fully booked tasting is marked and cannot be opened from the start page', async ({ page }) => {
    await page.goto('/')
    await expect(card(page, 'Red Wine Cellar Tour')).toContainText('Fully booked')
    await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0)
    await page.goto('/book/red-wine-cellar-tour')
    await expect(page.getByText(/fully booked/i).first()).toBeVisible()
    await expect(page.getByLabel('Name')).toHaveCount(0)
  })

  test('staff must sign in, see bookings grouped by tasting, and cancel to free seats', async ({ page }) => {
    await page.goto('/staff')
    await page.getByLabel('Password').fill('wrong')
    await page.getByRole('button', { name: 'Sign in' }).click()
    await expect(page.getByLabel('Password')).toHaveAccessibleDescription(/not correct/i)
    await expect(page.getByText('anna@example.com')).toHaveCount(0)

    await page.getByLabel('Password').fill(STAFF_PASSWORD)
    await page.getByRole('button', { name: 'Sign in' }).click()
    const riesling = page.getByRole('region', { name: 'Riesling Evening' })
    await expect(riesling).toContainText('Anna Weber')
    await expect(riesling).toContainText('anna@example.com')
    const cellar = page.getByRole('region', { name: 'Red Wine Cellar Tour' })
    await expect(cellar).toContainText('Ben Roth')
    await expect(cellar).toContainText('Clara Vogt')
    await expect(page.getByRole('region', { name: 'Winter Tasting' })).toContainText('No bookings yet')

    await page.reload()
    await expect(page.getByRole('region', { name: 'Riesling Evening' })).toContainText('Anna Weber')

    await cellar.getByRole('row', { name: /Ben Roth/ }).getByRole('button', { name: 'Cancel' }).click()
    await expect(cellar).not.toContainText('Ben Roth')

    await page.goto('/')
    await expect(card(page, 'Red Wine Cellar Tour')).toContainText('7 seats left')
    await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeVisible()
  })

  test('staff can sign out and lose access', async ({ page }) => {
    await signIn(page)
    await expect(page.getByRole('region', { name: 'Riesling Evening' })).toBeVisible()
    await page.getByRole('button', { name: 'Sign out' }).click()
    await expect(page.getByLabel('Password')).toBeVisible()
    const api = await page.request.get('/api/staff/bookings')
    expect(api.status()).toBe(401)
  })
})

test.describe('accessibility', () => {
  const audit = async (page: Page) =>
    new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']).analyze()

  test('start, booking (with errors) and staff pages have no detectable WCAG A/AA violations', async ({ page }) => {
    await page.goto('/')
    await expect(card(page, 'Riesling Evening')).toBeVisible()
    expect((await audit(page)).violations).toEqual([])

    await page.getByRole('link', { name: 'Book Riesling Evening' }).click()
    await page.getByRole('button', { name: 'Book', exact: true }).click()
    await expect(page.getByLabel('Name')).toHaveAccessibleDescription(/enter your name/i)
    expect((await audit(page)).violations).toEqual([])

    await page.goto('/staff')
    await expect(page.getByLabel('Password')).toBeVisible()
    expect((await audit(page)).violations).toEqual([])
    await signIn(page)
    await expect(page.getByRole('region', { name: 'Riesling Evening' })).toBeVisible()
    expect((await audit(page)).violations).toEqual([])
  })
})
