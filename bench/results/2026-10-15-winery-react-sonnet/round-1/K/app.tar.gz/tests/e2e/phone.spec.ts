import { expect, test, type Page } from '@playwright/test'

const noHorizontalScroll = (page: Page) =>
  page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth)

test.describe('phone viewport', () => {
  test('start page fits the screen and the Book link is visible', async ({ page }) => {
    await page.goto('/')
    await expect(page.getByRole('article', { name: 'Riesling Evening' })).toBeVisible()
    expect(await noHorizontalScroll(page)).toBe(true)
    await expect(page.getByRole('link', { name: 'Book Riesling Evening' })).toBeVisible()
  })

  test('booking form is usable and shows errors without horizontal scrolling', async ({ page }) => {
    await page.goto('/')
    await page.getByRole('link', { name: 'Book Winter Tasting' }).click()
    await page.getByRole('button', { name: 'Book', exact: true }).click()
    await expect(page.getByLabel('Name')).toHaveAccessibleDescription(/enter your name/i)
    expect(await noHorizontalScroll(page)).toBe(true)
    const box = await page.getByRole('button', { name: 'Book', exact: true }).boundingBox()
    expect(box!.height).toBeGreaterThanOrEqual(44)
  })

  test('staff overview fits the screen', async ({ page }) => {
    await page.goto('/staff')
    await page.getByLabel('Password').fill('e2e-secret')
    await page.getByRole('button', { name: 'Sign in' }).click()
    await expect(page.getByRole('region', { name: 'Riesling Evening' })).toBeVisible()
    expect(await noHorizontalScroll(page)).toBe(true)
  })
})
