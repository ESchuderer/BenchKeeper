import { fileURLToPath } from 'node:url'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@shared': fileURLToPath(new URL('./shared', import.meta.url)) } },
  test: {
    include: ['shared/**/*.test.ts', 'server/**/*.test.ts', 'client/**/*.test.{ts,tsx}'],
    setupFiles: ['client/src/test-setup.ts'],
    coverage: {
      provider: 'v8',
      include: ['shared/**', 'server/**', 'client/src/**'],
      exclude: ['**/*.test.*', 'server/index.ts', 'client/src/main.tsx', 'client/src/test-setup.ts'],
      thresholds: { lines: 80, functions: 80, branches: 80, statements: 80 },
    },
  },
})
