import { createHash, randomBytes, randomInt, timingSafeEqual } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import session from 'express-session';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { tastings } from './tastings.js';

const MAX_GUESTS = 8;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const sha = (s) => createHash('sha256').update(s).digest();
const reference = () =>
  'KB-' + Array.from({ length: 8 }, () => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[randomInt(36)]).join('');

export function createApp({ staffPassword = '', trustProxy = false, distDir } = {}) {
  // shortcut: bookings live in memory and are lost on restart, switch to a file or database to keep them
  const bookings = [];
  const seatsLeft = (t) => t.seats - bookings.filter((b) => b.tastingId === t.id).reduce((n, b) => n + b.guests, 0);
  const publicTasting = (t) => ({ id: t.id, title: t.title, start: t.start, price: t.price, seats: t.seats, seatsLeft: seatsLeft(t) });

  const app = express();
  app.set('trust proxy', trustProxy);
  app.disable('x-powered-by');
  app.use(helmet({ contentSecurityPolicy: { directives: { upgradeInsecureRequests: null } } }));
  app.use(express.json({ limit: '10kb' }));
  // shortcut: sessions use the in-memory store and end on restart, use a persistent store for several instances
  app.use(
    '/api/staff',
    session({
      name: 'staff.sid',
      secret: randomBytes(32).toString('hex'),
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: 'strict', secure: 'auto', maxAge: 2 * 60 * 60 * 1000 },
    }),
  );

  const api = express.Router();
  app.use('/api', api);

  api.get('/tastings', (req, res) => res.json(tastings.map(publicTasting)));

  api.post('/tastings/:id/bookings', (req, res) => {
    const tasting = tastings.find((t) => t.id === req.params.id);
    if (!tasting) return res.status(404).json({ error: 'Tasting not found.' });
    const { name, email, guests: rawGuests } = req.body ?? {};
    const errors = {};
    const cleanName = typeof name === 'string' ? name.trim() : '';
    const cleanEmail = typeof email === 'string' ? email.trim() : '';
    if (!cleanName) errors.name = 'Please enter your name.';
    else if (cleanName.length > 100) errors.name = 'Please use at most 100 characters.';
    if (!cleanEmail) errors.email = 'Please enter your email address.';
    else if (cleanEmail.length > 254 || !EMAIL.test(cleanEmail)) errors.email = 'Please enter a valid email address.';
    const isCount = typeof rawGuests === 'number' || (typeof rawGuests === 'string' && /^\d+$/.test(rawGuests.trim()));
    const guests = isCount ? Number(rawGuests) : NaN;
    const left = seatsLeft(tasting);
    if (!Number.isInteger(guests) || guests < 1 || guests > MAX_GUESTS) {
      errors.guests = `Please enter a whole number of guests from 1 to ${MAX_GUESTS}.`;
    } else if (left === 0) {
      errors.guests = 'This tasting is fully booked.';
    } else if (guests > left) {
      errors.guests = `Only ${left} ${left === 1 ? 'seat is' : 'seats are'} left.`;
    }
    if (Object.keys(errors).length) return res.status(422).json({ errors });

    const booking = { reference: reference(), tastingId: tasting.id, name: cleanName, email: cleanEmail, guests };
    bookings.push(booking);
    res.status(201).json(confirmation(booking));
  });

  const confirmation = (b) => {
    const t = tastings.find((x) => x.id === b.tastingId);
    return { reference: b.reference, guests: b.guests, total: b.guests * t.price, tasting: publicTasting(t) };
  };

  // The reference acts as the secret for this page, so it carries no name or email.
  api.get('/bookings/:reference', (req, res) => {
    const b = bookings.find((x) => x.reference === req.params.reference);
    if (!b) return res.status(404).json({ error: 'Booking not found.' });
    res.json(confirmation(b));
  });

  const loginLimit = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many failed attempts. Try again in 15 minutes.' },
  });

  api.post('/staff/login', loginLimit, (req, res, next) => {
    const given = req.body?.password;
    const valid =
      staffPassword !== '' && typeof given === 'string' && timingSafeEqual(sha(given), sha(staffPassword));
    if (!valid) return res.status(401).json({ error: 'Wrong password.' });
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.staff = true;
      res.status(204).end();
    });
  });

  api.post('/staff/logout', (req, res, next) => {
    req.session.destroy((err) => {
      if (err) return next(err);
      res.clearCookie('staff.sid').status(204).end();
    });
  });

  const requireStaff = (req, res, next) =>
    req.session?.staff ? next() : res.status(401).json({ error: 'Sign in required.' });

  api.get('/staff/session', (req, res) => res.json({ signedIn: Boolean(req.session?.staff) }));

  api.get('/staff/bookings', requireStaff, (req, res) => {
    res.json(
      tastings.map((t) => ({
        ...publicTasting(t),
        bookings: bookings
          .filter((b) => b.tastingId === t.id)
          .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
      })),
    );
  });

  api.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
    const i = bookings.findIndex((b) => b.reference === req.params.reference);
    if (i < 0) return res.status(404).json({ error: 'Booking not found.' });
    bookings.splice(i, 1);
    res.status(204).end();
  });

  api.use((req, res) => res.status(404).json({ error: 'Not found.' }));

  if (distDir) {
    app.use(express.static(distDir));
    app.use((req, res) => res.sendFile(join(distDir, 'index.html')));
  }

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    const status = err.status && err.status < 500 ? err.status : 500;
    res.status(status).json({ error: status === 500 ? 'Something went wrong.' : 'Invalid request.' });
  });

  return app;
}

export const defaultDist = join(dirname(fileURLToPath(import.meta.url)), '..', 'dist');
