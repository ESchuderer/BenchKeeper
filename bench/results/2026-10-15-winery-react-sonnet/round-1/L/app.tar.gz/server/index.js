import { createApp, defaultDist } from './app.js';

const port = Number(process.env.PORT) || 3000;
if (!process.env.STAFF_PASSWORD) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
// TRUST_PROXY: "true", or the number of proxy hops in front of the app
const tp = process.env.TRUST_PROXY ?? '';
const trustProxy = tp === 'true' ? true : /^\d+$/.test(tp) ? Number(tp) : false;
if (tp && tp !== 'true' && !/^\d+$/.test(tp)) throw new Error('TRUST_PROXY must be "true" or a number');

createApp({ staffPassword: process.env.STAFF_PASSWORD ?? '', trustProxy, distDir: defaultDist }).listen(port, () =>
  console.log(`Weingut Kieselbrunnen listening on port ${port}`),
);
