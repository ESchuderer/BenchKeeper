export const tastings = [
  { id: 'riesling-evening', title: 'Riesling Evening', start: '2026-11-06T18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', start: '2026-11-14T15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', start: '2026-12-05T17:00', price: 28, seats: 10 },
];
