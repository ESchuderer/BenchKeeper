import { Link, Route, Routes, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Home from './pages/Home.jsx';
import Book from './pages/Book.jsx';
import Confirmation from './pages/Confirmation.jsx';
import Staff from './pages/Staff.jsx';

function NotFound() {
  return (
    <section className="panel">
      <h1>Page not found</h1>
      <p>
        <Link to="/">Back to the tastings</Link>
      </p>
    </section>
  );
}

export default function App() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-mark" aria-hidden="true" />
          <span>
            <span className="brand-name">Weingut Kieselbrunnen</span>
            <span className="brand-sub">Family winery</span>
          </span>
        </Link>
      </header>
      <main id="main" className="wrap">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/tastings/:id/book" element={<Book />} />
          <Route path="/bookings/:reference" element={<Confirmation />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <p>Weingut Kieselbrunnen, family winery</p>
        <Link to="/staff">Staff</Link>
      </footer>
    </>
  );
}
