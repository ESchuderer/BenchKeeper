export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  return { status: res.status, ok: res.ok, data };
}

export const money = (n) => `EUR ${n}`;
export const when = (start) => `${start.slice(0, 10)} ${start.slice(11, 16)}`;
export const weekday = (start) =>
  new Date(`${start.slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
export const seatsText = (n) => (n === 0 ? 'Fully booked' : `${n} ${n === 1 ? 'seat' : 'seats'} left`);
