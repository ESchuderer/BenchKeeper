import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api, money, seatsText, weekday, when } from '../api.js';

function Field({ id, label, error, hint, children }) {
  return (
    <div className={`field${error ? ' field-error' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children({ id, 'aria-invalid': error ? 'true' : undefined, 'aria-describedby': error ? `${id}-error` : hint ? `${id}-hint` : undefined })}
      {hint && !error && <p className="hint" id={`${id}-hint`}>{hint}</p>}
      {error && <p className="error" id={`${id}-error`}>{error}</p>}
    </div>
  );
}

export default function Book() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tasting, setTasting] = useState(undefined);
  const [form, setForm] = useState({ name: '', email: '', guests: '2' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api('/tastings')
      .then((r) => setTasting(r.ok ? (r.data.find((t) => t.id === id) ?? null) : null))
      .catch(() => setTasting(null));
  }, [id]);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setFormError('');
    try {
      const res = await api(`/tastings/${id}/bookings`, { method: 'POST', body: form });
      if (res.status === 201) return navigate(`/bookings/${res.data.reference}`);
      if (res.status === 422) {
        setErrors(res.data.errors);
        // seats may have changed since the page loaded
        api('/tastings').then((r) => r.ok && setTasting(r.data.find((t) => t.id === id) ?? null));
      } else setFormError('The booking could not be saved. Please try again.');
    } catch {
      setFormError('The server cannot be reached. Please try again.');
    }
    setBusy(false);
  }

  if (tasting === undefined) return <p className="muted" role="status">Loading...</p>;
  if (tasting === null) {
    return (
      <section className="panel">
        <h1>Tasting not found</h1>
        <p><Link to="/">Back to the tastings</Link></p>
      </section>
    );
  }

  const full = tasting.seatsLeft === 0;
  const total = Number(form.guests) >= 1 && Number.isInteger(Number(form.guests)) ? Number(form.guests) * tasting.price : null;

  return (
    <section className="panel panel-narrow">
      <p className="crumb"><Link to="/">All tastings</Link></p>
      <h1>{tasting.title}</h1>
      <p className="lead">
        {weekday(tasting.start)} {when(tasting.start)} &middot; {money(tasting.price)} per guest &middot; {seatsText(tasting.seatsLeft)}
      </p>
      {full ? (
        <p className="notice notice-error" role="alert">This tasting is fully booked. Please choose another date.</p>
      ) : (
        <form onSubmit={submit} noValidate>
          <Field id="name" label="Name" error={errors.name}>
            {(p) => <input {...p} type="text" name="name" autoComplete="name" value={form.name} onChange={set('name')} />}
          </Field>
          <Field id="email" label="Email" error={errors.email}>
            {(p) => <input {...p} type="email" name="email" autoComplete="email" value={form.email} onChange={set('email')} />}
          </Field>
          <Field id="guests" label="Guests" error={errors.guests} hint={`1 to 8 guests, ${seatsText(tasting.seatsLeft)}`}>
            {(p) => <input {...p} type="number" name="guests" inputMode="numeric" min="1" max="8" value={form.guests} onChange={set('guests')} />}
          </Field>
          {total !== null && <p className="total">Total: <strong>{money(total)}</strong></p>}
          {formError && <p className="notice notice-error" role="alert">{formError}</p>}
          <button className="btn" type="submit" disabled={busy}>Book</button>
        </form>
      )}
    </section>
  );
}
