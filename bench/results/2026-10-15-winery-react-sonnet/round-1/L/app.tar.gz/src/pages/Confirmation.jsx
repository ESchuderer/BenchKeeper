import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, money, weekday, when } from '../api.js';

export default function Confirmation() {
  const { reference } = useParams();
  const [booking, setBooking] = useState(undefined);
  const heading = useRef(null);

  useEffect(() => {
    api(`/bookings/${encodeURIComponent(reference)}`)
      .then((r) => setBooking(r.ok ? r.data : null))
      .catch(() => setBooking(null));
  }, [reference]);

  useEffect(() => {
    heading.current?.focus();
  }, [booking]);

  if (booking === undefined) return <p className="muted" role="status">Loading...</p>;
  if (booking === null) {
    return (
      <section className="panel">
        <h1>Booking not found</h1>
        <p>This booking does not exist or was cancelled.</p>
        <p><Link to="/">Back to the tastings</Link></p>
      </section>
    );
  }

  return (
    <section className="panel panel-narrow notice-success">
      <h1 ref={heading} tabIndex={-1}>Booking confirmed</h1>
      <p className="lead">Thank you. We look forward to seeing you at the estate.</p>
      <dl className="summary">
        <div><dt>Tasting</dt><dd>{booking.tasting.title}, {weekday(booking.tasting.start)} {when(booking.tasting.start)}</dd></div>
        <div><dt>Guests</dt><dd>{booking.guests}</dd></div>
        <div><dt>Total price</dt><dd>{money(booking.total)}</dd></div>
        <div><dt>Booking reference</dt><dd className="ref">{booking.reference}</dd></div>
      </dl>
      <p className="muted">Please keep your booking reference.</p>
      <Link className="btn btn-quiet" to="/">Back to the tastings</Link>
    </section>
  );
}
