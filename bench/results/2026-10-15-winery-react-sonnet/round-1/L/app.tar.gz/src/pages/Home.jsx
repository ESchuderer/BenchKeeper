import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, money, seatsText, weekday, when } from '../api.js';

export default function Home() {
  const [tastings, setTastings] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    api('/tastings')
      .then((r) => (r.ok ? setTastings(r.data) : setFailed(true)))
      .catch(() => setFailed(true));
  }, []);

  return (
    <>
      <section className="hero">
        <h1>Wine tastings at the estate</h1>
        <p>
          Join us in the cellar for an evening with our family's wines. Pick a tasting, reserve your
          seats and we will have your glasses ready.
        </p>
      </section>
      {failed && <p className="notice notice-error" role="alert">The tastings could not be loaded. Please try again later.</p>}
      {!failed && !tastings && <p className="muted" role="status">Loading tastings...</p>}
      {tastings && (
        <ul className="cards">
          {tastings.map((t) => {
            const full = t.seatsLeft === 0;
            return (
              <li key={t.id} className={`card${full ? ' card-full' : ''}`}>
                <p className="card-day">{weekday(t.start)}</p>
                <h2>{t.title}</h2>
                <p className="card-when">{when(t.start)}</p>
                <dl className="facts">
                  <div>
                    <dt>Price</dt>
                    <dd>{money(t.price)} per guest</dd>
                  </div>
                  <div>
                    <dt>Availability</dt>
                    <dd>
                      <span className={`badge ${full ? 'badge-full' : t.seatsLeft <= 3 ? 'badge-low' : 'badge-ok'}`}>
                        {seatsText(t.seatsLeft)}
                      </span>
                    </dd>
                  </div>
                </dl>
                {full ? (
                  <p className="btn btn-disabled" aria-disabled="true">Sold out</p>
                ) : (
                  <Link className="btn" to={`/tastings/${t.id}/book`}>Book {t.title}</Link>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
