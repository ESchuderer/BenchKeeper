import { useEffect, useState } from 'react';
import { api, seatsText, weekday, when } from '../api.js';

function Login({ onDone }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const res = await api('/staff/login', { method: 'POST', body: { password } });
      if (res.ok) return onDone();
      setError(res.data?.error ?? 'Sign-in failed.');
    } catch {
      setError('The server cannot be reached. Please try again.');
    }
    setBusy(false);
  }

  return (
    <section className="panel panel-narrow">
      <h1>Staff</h1>
      <p className="lead">Sign in to see the bookings.</p>
      <form onSubmit={submit} noValidate>
        <div className={`field${error ? ' field-error' : ''}`}>
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            aria-invalid={error ? 'true' : undefined}
            aria-describedby={error ? 'password-error' : undefined}
          />
          {error && <p className="error" id="password-error">{error}</p>}
        </div>
        <button className="btn" type="submit" disabled={busy}>Sign in</button>
      </form>
    </section>
  );
}

function Bookings({ onSignOut }) {
  const [tastings, setTastings] = useState(null);
  const [error, setError] = useState('');

  async function load() {
    try {
      const res = await api('/staff/bookings');
      if (res.status === 401) return onSignOut();
      if (res.ok) setTastings(res.data);
      else setError('The bookings could not be loaded.');
    } catch {
      setError('The server cannot be reached.');
    }
  }
  useEffect(() => {
    load();
  }, []);

  async function cancel(reference) {
    setError('');
    const res = await api(`/staff/bookings/${reference}`, { method: 'DELETE' });
    if (res.status === 401) return onSignOut();
    if (!res.ok && res.status !== 404) setError('The booking could not be cancelled.');
    load();
  }

  async function signOut() {
    await api('/staff/logout', { method: 'POST' }).catch(() => {});
    onSignOut();
  }

  return (
    <>
      <div className="staff-head">
        <h1>Bookings</h1>
        <button className="btn btn-quiet" type="button" onClick={signOut}>Sign out</button>
      </div>
      {error && <p className="notice notice-error" role="alert">{error}</p>}
      {!tastings && !error && <p className="muted" role="status">Loading...</p>}
      {tastings?.map((t) => (
        <section key={t.id} className="panel" aria-labelledby={`h-${t.id}`}>
          <h2 id={`h-${t.id}`}>{t.title}</h2>
          <p className="lead">
            {weekday(t.start)} {when(t.start)} &middot; {t.seats - t.seatsLeft} of {t.seats} seats booked &middot; {seatsText(t.seatsLeft)}
          </p>
          {t.bookings.length === 0 ? (
            <p className="muted">No bookings yet.</p>
          ) : (
            <table className="table">
              <thead>
                <tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th><span className="sr-only">Action</span></th></tr>
              </thead>
              <tbody>
                {t.bookings.map((b) => (
                  <tr key={b.reference}>
                    <td data-label="Name">{b.name}</td>
                    <td data-label="Email">{b.email}</td>
                    <td data-label="Guests">{b.guests}</td>
                    <td data-label="Reference" className="ref">{b.reference}</td>
                    <td><button className="btn btn-danger btn-small" type="button" onClick={() => cancel(b.reference)}>Cancel</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      ))}
    </>
  );
}

export default function Staff() {
  // null while checking the session, then true or false
  const [signedIn, setSignedIn] = useState(null);

  useEffect(() => {
    api('/staff/session').then((r) => setSignedIn(r.data?.signedIn === true)).catch(() => setSignedIn(false));
  }, []);

  if (signedIn === null) return <p className="muted" role="status">Loading...</p>;
  return signedIn ? <Bookings onSignOut={() => setSignedIn(false)} /> : <Login onDone={() => setSignedIn(true)} />;
}
