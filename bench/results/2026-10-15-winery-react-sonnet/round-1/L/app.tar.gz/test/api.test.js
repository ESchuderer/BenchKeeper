import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../server/app.js';

let app;
beforeEach(() => {
  app = createApp({ staffPassword: 'secret' });
});

const book = (id, body) => request(app).post(`/api/tastings/${id}/bookings`).send(body);
const ok = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

async function staff() {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password: 'secret' }).expect(204);
  return agent;
}

describe('tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const { body } = await request(app).get('/api/tastings').expect(200);
    expect(body.map((t) => [t.title, t.price, t.seatsLeft])).toEqual([
      ['Riesling Evening', 25, 12],
      ['Red Wine Cellar Tour', 32, 8],
      ['Winter Tasting', 28, 10],
    ]);
  });
});

describe('booking', () => {
  it('confirms a booking, computes the total and reduces seats left', async () => {
    const res = await book('riesling-evening', ok).expect(201);
    expect(res.body).toMatchObject({ guests: 2, total: 50, tasting: { title: 'Riesling Evening' } });
    expect(res.body.reference).toMatch(/^KB-[A-Z0-9]{8}$/);
    const { body } = await request(app).get('/api/tastings');
    expect(body[0].seatsLeft).toBe(10);
  });

  it('returns a confirmation by reference without personal data', async () => {
    const { body: b } = await book('riesling-evening', ok);
    const res = await request(app).get(`/api/bookings/${b.reference}`).expect(200);
    expect(res.body).toMatchObject({ guests: 2, total: 50 });
    expect(JSON.stringify(res.body)).not.toContain('anna@example.com');
    await request(app).get('/api/bookings/KB-NOPE').expect(404);
  });

  it('never takes more seats than are left', async () => {
    await book('red-wine-cellar-tour', { ...ok, guests: 8 }).expect(201);
    const res = await book('red-wine-cellar-tour', { ...ok, guests: 1 }).expect(422);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });

  it('rejects more guests than seats left with the number left', async () => {
    await book('red-wine-cellar-tour', { ...ok, guests: 7 }).expect(201);
    const res = await book('red-wine-cellar-tour', { ...ok, guests: 2 }).expect(422);
    expect(res.body.errors.guests).toMatch(/1 seat/);
  });

  it('does not oversell under concurrent requests', async () => {
    const results = await Promise.all(
      Array.from({ length: 6 }, () => book('red-wine-cellar-tour', { ...ok, guests: 3 })),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(2);
    const { body } = await request(app).get('/api/tastings');
    expect(body[1].seatsLeft).toBe(2);
  });

  it.each([
    [{ ...ok, name: '  ' }, 'name'],
    [{ ...ok, email: 'not-an-email' }, 'email'],
    [{ ...ok, guests: 0 }, 'guests'],
    [{ ...ok, guests: 9 }, 'guests'],
    [{ ...ok, guests: 1.5 }, 'guests'],
    [{ ...ok, guests: 'abc' }, 'guests'],
    [{}, 'name'],
  ])('rejects invalid input %j with an error for %s', async (body, field) => {
    const res = await book('riesling-evening', body).expect(422);
    expect(res.body.errors[field]).toBeTruthy();
    const { body: list } = await request(app).get('/api/tastings');
    expect(list[0].seatsLeft).toBe(12);
  });

  it('accepts guests sent as a numeric string', async () => {
    await book('riesling-evening', { ...ok, guests: '3' }).expect(201);
  });

  it('404s for an unknown tasting', async () => {
    await book('nope', ok).expect(404);
  });
});

describe('staff', () => {
  it('refuses bookings without a session', async () => {
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete('/api/staff/bookings/KB-X').expect(401);
  });

  it('rejects a wrong password', async () => {
    await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
  });

  it('rejects every password when STAFF_PASSWORD is not set', async () => {
    const open = createApp({ staffPassword: '' });
    await request(open).post('/api/staff/login').send({ password: '' }).expect(401);
  });

  it('locks out after 5 failed attempts', async () => {
    for (let i = 0; i < 5; i++) {
      await request(app).post('/api/staff/login').send({ password: 'x' }).expect(401);
    }
    await request(app).post('/api/staff/login').send({ password: 'secret' }).expect(429);
  });

  it('sets an HttpOnly SameSite cookie, and Secure behind HTTPS', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: 'secret' });
    expect(res.headers['set-cookie'][0]).toMatch(/HttpOnly/i);
    expect(res.headers['set-cookie'][0]).toMatch(/SameSite=Strict/i);
    expect(res.headers['set-cookie'][0]).not.toMatch(/Secure/i);

    const proxied = createApp({ staffPassword: 'secret', trustProxy: 1 });
    const https = await request(proxied)
      .post('/api/staff/login')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: 'secret' });
    expect(https.headers['set-cookie'][0]).toMatch(/Secure/i);
  });

  it('lists bookings and frees seats on cancel', async () => {
    const { body: b } = await book('winter-tasting', ok);
    const agent = await staff();
    const list = await agent.get('/api/staff/bookings').expect(200);
    const winter = list.body.find((t) => t.id === 'winter-tasting');
    expect(winter.bookings).toEqual([
      { reference: b.reference, name: 'Anna Weber', email: 'anna@example.com', guests: 2 },
    ]);
    await agent.delete(`/api/staff/bookings/${b.reference}`).expect(204);
    await agent.delete(`/api/staff/bookings/${b.reference}`).expect(404);
    const { body } = await request(app).get('/api/tastings');
    expect(body[2].seatsLeft).toBe(10);
  });

  it('reports whether a session is signed in', async () => {
    const res = await request(app).get('/api/staff/session').expect(200);
    expect(res.body).toEqual({ signedIn: false });
    const agent = await staff();
    expect((await agent.get('/api/staff/session')).body).toEqual({ signedIn: true });
  });

  it('ends the session on sign-out', async () => {
    const agent = await staff();
    await agent.post('/api/staff/logout').expect(204);
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('expires the session cookie after two hours', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: 'secret' });
    expect(res.headers['set-cookie'][0]).toMatch(/Max-Age=7200|Expires=/i);
  });
});
