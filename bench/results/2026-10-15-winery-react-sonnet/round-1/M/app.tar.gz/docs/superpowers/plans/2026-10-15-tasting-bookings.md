# Tasting Bookings Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Guests book tastings online; staff see and cancel bookings.

**Architecture:** Express 5 serves a JSON API and the built Vite/React app. Bookings and tastings live in memory in a store module; the API validates with zod. React Router pages call the API.

**Tech Stack:** Node 22, Express 5, express-session, express-rate-limit, zod, React 19, react-router, Vite, vitest, supertest.

**Spec:** `docs/superpowers/specs/2026-10-15-tasting-bookings-design.md`

## Global Constraints
- `npm install`, `npm run build`, `npm start` serves everything on `PORT` (default 3000); `STAFF_PASSWORD` from env.
- UI in English; texts exact: "<n> seats left", "Book <title>", labels "Name", "Email", "Guests", button "Book", heading "Booking confirmed", staff "Password", "Sign in", "Cancel".
- Tastings: Riesling Evening 2026-11-06 18:00 EUR 25 12 seats; Red Wine Cellar Tour 2026-11-14 15:00 EUR 32 8 seats; Winter Tasting 2026-12-05 17:00 EUR 28 10 seats.
- Guests 1 to 8. Starts with no bookings. No emdash, no emoji in anything.

## Review Focus
- Guests "0", "9", "2.5", "abc", empty: field error on Guests, no booking.
- Guests above seats left (including exactly seats left, and a sold-out tasting): rejected; exactly seats left accepted.
- Unknown tasting id: 404.
- Name of only spaces, malformed email: field errors; name/email with `<script>`: shown as text.
- Staff API without session, wrong password, 6th failed attempt: 401 / 429; empty `STAFF_PASSWORD`: nobody signs in.
- Cancelling an unknown reference: 404; cancelling twice frees seats once.

### Task 1: API (store, routes, auth)

**Files:**
- Create: `server/app.js` (`createApp({ staffPassword }) -> express.Application`, exports `TASTINGS`), `server/index.js` (listens on `PORT`), `server/app.test.js`, `package.json`, `.gitignore`

**Interfaces:**
- Produces: `GET /api/tastings` -> `[{id, title, startsAt, pricePerGuest, seats, seatsLeft}]` (ids `riesling-evening`, `red-wine-cellar-tour`, `winter-tasting`; `startsAt` like `2026-11-06T18:00`).
- `POST /api/bookings {tastingId, name, email, guests}` -> 201 `{reference, tasting: {id,title,startsAt}, guests, total}`; 400 `{errors: {name?, email?, guests?}}`; 404 `{error}` for unknown tasting.
- `POST /api/staff/login {password}` -> 204 / 401 `{errors:{password}}` / 429 `{errors:{password}}`; `POST /api/staff/logout` -> 204; `GET /api/staff/bookings` -> 200 `[{tasting, bookings:[{reference,name,email,guests}]}]` or 401; `DELETE /api/staff/bookings/:reference` -> 204 / 401 / 404.

- [ ] **Step 1: Write failing tests** in `server/app.test.js` (supertest, one `createApp` per test) covering: list shows 12/8/10 seats left and no bookings; booking returns reference `/^KB-[A-Z2-9]{6}$/` and total 50 for 2 guests of Riesling Evening, seats left drops to 10; every Review Focus line above; staff list groups by tasting, cancel restores seats; cookie of login has `HttpOnly`, `SameSite=Strict`, no `Secure` over HTTP and `Secure` with `X-Forwarded-For`/proto https when `trust proxy` set; logout then list is 401.
- [ ] **Step 2: Run** `npx vitest run` -> FAIL.
- [ ] **Step 3: Implement** `server/app.js`: zod schema (name trim 1..100, email trim `.email()` max 200, guests via `z.coerce`-free check: accept number or integer string, integer 1..8), seat check against `seatsLeft` writing the error to `guests`; refs from `crypto.randomInt`; sessions via express-session (`httpOnly`, `sameSite: 'strict'`, `secure: 'auto'`, maxAge 8 h, random secret per start); login limiter 5 failed per 15 min with `skipSuccessfulRequests`; password compare with `timingSafeEqual` on sha256 digests, reject when `staffPassword` is empty; serve `dist/` and fall back to `index.html` for non-API GETs when `dist/` exists. `server/index.js` reads `STAFF_PASSWORD`, `PORT`, `TRUST_PROXY`.
- [ ] **Step 4: Run** `npx vitest run` -> PASS.
- [ ] **Step 5: Commit** `feat: booking and staff API`.

### Task 2: React UI

**Files:**
- Create: `index.html`, `vite.config.js` (proxy `/api` to 3000 in dev), `src/main.jsx`, `src/App.jsx`, `src/pages/Home.jsx`, `src/pages/Book.jsx`, `src/pages/Confirmation.jsx`, `src/pages/Staff.jsx`, `src/styles.css`

**Interfaces:**
- Consumes: Task 1 API.
- Routes `/`, `/book/:id`, `/confirmation` (router state from POST), `/staff`.

- [ ] **Step 1: Implement** pages: Home lists tastings with "Fully booked" badge and disabled "Book <title>" button at 0 seats, else link "Book <title>". Book: form `noValidate`, labels, `aria-invalid`/`aria-describedby`, inline errors from server, submit disabled while sending, notice for sold-out. Confirmation: heading, tasting, guests, total as `EUR n`, reference. Staff: sign-in form, then groups with "Cancel", "Sign out", empty state per tasting. Winery styling (burgundy/cream/gold, serif headings), mobile-first.
- [ ] **Step 2: Run** `npm run build` -> succeeds.
- [ ] **Step 3: Commit** `feat: guest and staff pages`.

### Task 3: Browser verification and README

- [ ] **Step 1:** `STAFF_PASSWORD=secret npm start`; with Playwright MCP at 1280 and 375 px: book, error states, sold-out (book 8 of Red Wine Cellar Tour), staff sign-in, wrong password, cancel frees seats.
- [ ] **Step 2:** Fix defects found; commit.
