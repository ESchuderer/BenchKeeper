# Tasting bookings: design

## Intent
Guests of Weingut Kieselbrunnen book wine tastings online. Staff see and cancel bookings. Source of requirements: the task brief (three fixed tastings, guest flow, staff flow, look and feel).

## Goals
- Guest: list tastings (title, date and time, price per guest, "<n> seats left"), "Book <title>" opens a form (Name, Email, Guests 1 to 8, button "Book"), confirmation with heading "Booking confirmed", tasting, guests, total price, reference.
- Never overbook. Field errors shown next to the field.
- Staff: `/staff` password sign-in (`STAFF_PASSWORD`), bookings grouped by tasting (name, email, guests, reference), "Cancel" frees seats.
- Winery look, clear error/success/fully booked states, usable on a phone.

## Non-goals
- Payment, emails, editing bookings, adding tastings in the UI, time-based closing of past tastings, persistence across restarts, i18n.

## Anti-goals
- Overbooking under concurrent requests. Staff data reachable without sign-in. Guest-visible personal data of other guests.

## Constraints
- Node.js 22, `npm install`, `npm run build`, `npm start` on `PORT` (default 3000). React UI, English.

## Decisions (my calls, not agreed with the user)
- Stack: Express 5 API and static server; Vite + React 19 + react-router; zod for server validation; plain CSS.
- Tastings are constants in server code. Bookings are in memory (lost on restart). Seats left = seats minus sum of active bookings, computed on each request. Express handles a request synchronously in the booking handler, so check-then-insert is atomic.
- Validation lives on the server only; the form posts and renders returned field errors (`noValidate` form so the browser does not show its own bubbles). No duplicate client schema.
- Overbooking error is attached to the Guests field ("Only 3 seats left."). Fully booked tasting: list shows "Fully booked" and a disabled "Book <title>" button; the form route shows a notice.
- Reference: `KB-` plus 6 characters from an unambiguous alphabet, generated with `crypto.randomInt`.
- Confirmation data comes from the POST response via router state; reloading the confirmation page returns to the start page. There is no public lookup of a booking.
- Staff sign-in: `express-session` cookie (HttpOnly, SameSite=Strict, Secure when the request is HTTPS via `secure: 'auto'`, `TRUST_PROXY` env for proxies), 8 hour expiry, sign-out endpoint, 5 failed attempts per 15 minutes per IP (`express-rate-limit`, successful logins not counted), constant-time password compare. Without `STAFF_PASSWORD` no one can sign in.
- Cancelled bookings are removed.
- Tests: vitest + supertest for the API; browser checks with Playwright MCP.
- No lint or type check (plain JS); no persistence.
