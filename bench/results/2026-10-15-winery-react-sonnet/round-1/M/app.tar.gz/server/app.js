import { createHash, randomBytes, randomInt, timingSafeEqual } from 'node:crypto';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import express from 'express';
import session from 'express-session';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';

const DIST = fileURLToPath(new URL('../dist', import.meta.url));
const REF_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const SESSION_MS = 8 * 60 * 60 * 1000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_GUESTS = 8;

export const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuest: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuest: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuest: 28, seats: 10 },
];

const bookingSchema = z.object({
  name: z.string({ error: 'Please enter your name.' }).trim().min(1, 'Please enter your name.').max(100, 'Name is too long.'),
  email: z
    .string({ error: 'Please enter a valid email address.' })
    .trim()
    .max(200, 'Email is too long.')
    .pipe(z.email('Please enter a valid email address.')),
  guests: z.preprocess(
    (v) => (typeof v === 'string' && v.trim() !== '' ? Number(v) : v),
    z.number({ error: `Choose 1 to ${MAX_GUESTS} guests.` }).int(`Choose 1 to ${MAX_GUESTS} guests.`)
      .min(1, `Choose 1 to ${MAX_GUESTS} guests.`).max(MAX_GUESTS, `Choose 1 to ${MAX_GUESTS} guests.`),
  ),
});

// Express reads a number as a hop count, "true" as trust-all, other strings as subnets or names.
export const parseTrustProxy = (raw) => {
  if (!raw) return false;
  if (/^\d+$/.test(raw)) return Number(raw);
  return raw === 'true' ? true : raw === 'false' ? false : raw;
};

const digest = (s) => createHash('sha256').update(s).digest();

export function createApp({ staffPassword = '', trustProxy = false } = {}) {
  const bookings = []; // shortcut: in memory, lost on restart; persist to a file or database when that matters
  const taken = (id) => bookings.filter((b) => b.tastingId === id).reduce((n, b) => n + b.guests, 0);
  const view = (t) => ({ ...t, seatsLeft: t.seats - taken(t.id) });
  const newReference = () => {
    let ref;
    do {
      ref = 'KB-' + Array.from({ length: 6 }, () => REF_ALPHABET[randomInt(REF_ALPHABET.length)]).join('');
    } while (bookings.some((b) => b.reference === ref));
    return ref;
  };

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', trustProxy);
  app.use(express.json({ limit: '10kb' }));
  app.use(
    session({
      name: 'kb.sid',
      secret: randomBytes(32).toString('hex'),
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: 'strict', secure: 'auto', maxAge: SESSION_MS },
    }),
  );

  const api = express.Router();

  api.get('/tastings', (req, res) => res.json(TASTINGS.map(view)));

  api.post('/bookings', (req, res) => {
    const tasting = TASTINGS.find((t) => t.id === req.body?.tastingId);
    if (!tasting) return res.status(404).json({ error: 'Tasting not found.' });

    const parsed = bookingSchema.safeParse(req.body);
    const errors = {};
    if (!parsed.success) {
      for (const issue of parsed.error.issues) errors[issue.path[0]] ??= issue.message;
    } else {
      const left = view(tasting).seatsLeft;
      if (left === 0) errors.guests = 'This tasting is fully booked.';
      else if (parsed.data.guests > left) errors.guests = `Only ${left} ${left === 1 ? 'seat' : 'seats'} left.`;
    }
    if (Object.keys(errors).length) return res.status(400).json({ errors });

    const { name, email, guests } = parsed.data;
    const reference = newReference();
    bookings.push({ reference, tastingId: tasting.id, name, email, guests });
    const { id, title, startsAt } = tasting;
    res.status(201).json({ reference, tasting: { id, title, startsAt }, guests, total: guests * tasting.pricePerGuest });
  });

  const loginLimiter = rateLimit({
    windowMs: LOGIN_WINDOW_MS,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) =>
      res.status(429).json({ errors: { password: 'Too many failed attempts. Try again in 15 minutes.' } }),
  });

  api.post('/staff/login', loginLimiter, (req, res, next) => {
    const given = req.body?.password;
    const ok =
      staffPassword !== '' && typeof given === 'string' && timingSafeEqual(digest(given), digest(staffPassword));
    if (!ok) return res.status(401).json({ errors: { password: 'Wrong password.' } });
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.staff = true;
      req.session.loginAt = Date.now();
      req.session.save((err2) => (err2 ? next(err2) : res.status(204).end()));
    });
  });

  api.post('/staff/logout', (req, res, next) => {
    req.session.destroy((err) => {
      if (err) return next(err);
      res.clearCookie('kb.sid', { httpOnly: true, sameSite: 'strict', secure: req.secure });
      res.status(204).end();
    });
  });

  const staffOnly = (req, res, next) => {
    if (!req.session.staff || Date.now() - req.session.loginAt > SESSION_MS) return res.status(401).json({ error: 'Sign in required.' });
    res.set('Cache-Control', 'no-store');
    next();
  };

  api.get('/staff/bookings', staffOnly, (req, res) =>
    res.json(
      TASTINGS.map((t) => ({
        tasting: { id: t.id, title: t.title, startsAt: t.startsAt },
        bookings: bookings
          .filter((b) => b.tastingId === t.id)
          .map(({ reference, name, email, guests }) => ({ reference, name, email, guests })),
      })),
    ),
  );

  api.delete('/staff/bookings/:reference', staffOnly, (req, res) => {
    const i = bookings.findIndex((b) => b.reference === req.params.reference);
    if (i === -1) return res.status(404).json({ error: 'Booking not found.' });
    bookings.splice(i, 1);
    res.status(204).end();
  });

  api.use((req, res) => res.status(404).json({ error: 'Not found.' }));
  app.use('/api', api);

  if (existsSync(DIST)) {
    app.use(express.static(DIST));
    app.get(/.*/, (req, res) => res.sendFile(DIST + '/index.html'));
  }

  app.use((err, req, res, next) => {
    const status = err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 500 ? 'Something went wrong.' : 'Bad request.' });
  });

  return app;
}
