import { describe, it, expect, beforeEach, vi } from 'vitest';
import request from 'supertest';
import { createApp, parseTrustProxy } from './app.js';

const PASSWORD = 'secret';
const valid = { tastingId: 'riesling-evening', name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

let app;
beforeEach(() => {
  app = createApp({ staffPassword: PASSWORD });
});

const seatsLeft = async (id) =>
  (await request(app).get('/api/tastings')).body.find((t) => t.id === id).seatsLeft;
const book = (body) => request(app).post('/api/bookings').send(body);
const signIn = async (a = app) => {
  const agent = request.agent(a);
  await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(204);
  return agent;
};

describe('tastings', () => {
  it('lists the three tastings with full seats', async () => {
    const res = await request(app).get('/api/tastings').expect(200);
    expect(res.body.map((t) => [t.title, t.startsAt, t.pricePerGuest, t.seatsLeft])).toEqual([
      ['Riesling Evening', '2026-11-06T18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14T15:00', 32, 8],
      ['Winter Tasting', '2026-12-05T17:00', 28, 10],
    ]);
  });
});

describe('booking', () => {
  it('confirms with reference and total, and takes seats', async () => {
    const res = await book(valid).expect(201);
    expect(res.body.reference).toMatch(/^KB-[A-Z2-9]{6}$/);
    expect(res.body).toMatchObject({ guests: 2, total: 50, tasting: { title: 'Riesling Evening' } });
    expect(await seatsLeft('riesling-evening')).toBe(10);
  });

  it.each([0, 9, 2.5, 'abc', '', null])('rejects guests %s on the guests field', async (guests) => {
    const res = await book({ ...valid, guests }).expect(400);
    expect(res.body.errors.guests).toBeTruthy();
    expect(await seatsLeft('riesling-evening')).toBe(12);
  });

  it('accepts guests sent as a numeric string', async () => {
    await book({ ...valid, guests: '3' }).expect(201);
  });

  it('rejects blank name and malformed email on their own fields', async () => {
    const res = await book({ ...valid, name: '   ', email: 'nope' }).expect(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'name']);
  });

  it('rejects an unknown tasting', async () => {
    await book({ ...valid, tastingId: 'nope' }).expect(404);
  });

  it('never takes more seats than are left, and accepts exactly the seats left', async () => {
    const red = { ...valid, tastingId: 'red-wine-cellar-tour' };
    await book({ ...red, guests: 8 }).expect(201);
    expect(await seatsLeft('red-wine-cellar-tour')).toBe(0);
    const res = await book({ ...red, guests: 1 }).expect(400);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });

  it('names the seats left when asking for too many', async () => {
    const winter = { ...valid, tastingId: 'winter-tasting' };
    await book({ ...winter, guests: 8 }).expect(201);
    const res = await book({ ...winter, guests: 3 }).expect(400);
    expect(res.body.errors.guests).toBe('Only 2 seats left.');
  });
});

describe('staff', () => {
  it('requires a session', async () => {
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete('/api/staff/bookings/KB-AAAAAA').expect(401);
  });

  it('rejects a wrong password', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    expect(res.body.errors.password).toBeTruthy();
  });

  it('lets nobody in when no password is configured', async () => {
    const open = createApp({ staffPassword: '' });
    await request(open).post('/api/staff/login').send({ password: '' }).expect(401);
  });

  it('limits failed attempts', async () => {
    for (let i = 0; i < 5; i++) await request(app).post('/api/staff/login').send({ password: 'x' }).expect(401);
    await request(app).post('/api/staff/login').send({ password: 'x' }).expect(429);
    await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(429);
  });

  it('does not count successful sign-ins', async () => {
    for (let i = 0; i < 8; i++) await signIn();
  });

  it('groups bookings by tasting and cancel frees the seats once', async () => {
    const { body } = await book(valid);
    const agent = await signIn();
    const list = (await agent.get('/api/staff/bookings').expect(200)).body;
    expect(list).toHaveLength(3);
    expect(list[0].tasting.title).toBe('Riesling Evening');
    expect(list[0].bookings).toEqual([
      { reference: body.reference, name: 'Anna Weber', email: 'anna@example.com', guests: 2 },
    ]);
    expect(list[1].bookings).toEqual([]);
    await agent.delete(`/api/staff/bookings/${body.reference}`).expect(204);
    expect(await seatsLeft('riesling-evening')).toBe(12);
    await agent.delete(`/api/staff/bookings/${body.reference}`).expect(404);
    expect(await seatsLeft('riesling-evening')).toBe(12);
  });

  it('ends the session on sign-out', async () => {
    const agent = await signIn();
    await agent.post('/api/staff/logout').expect(204);
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('sets the session cookie HttpOnly and SameSite=Strict, Secure only over https', async () => {
    const http = await request(app).post('/api/staff/login').send({ password: PASSWORD });
    const cookie = http.headers['set-cookie'][0];
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    expect(cookie).toMatch(/Expires=/i);
    expect(cookie).not.toMatch(/Secure/i);

    const proxied = createApp({ staffPassword: PASSWORD, trustProxy: 1 });
    const https = await request(proxied)
      .post('/api/staff/login')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD });
    expect(https.headers['set-cookie'][0]).toMatch(/Secure/i);
  });
});

describe('TRUST_PROXY parsing', () => {
  it.each([
    [undefined, false],
    ['', false],
    ['1', 1],
    ['true', true],
    ['loopback', 'loopback'],
  ])('parses %j', (raw, expected) => {
    expect(parseTrustProxy(raw)).toBe(expected);
  });
});

describe('session expiry', () => {
  it('rejects a session older than 8 hours even when it is still in use', async () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    try {
      // replay the raw cookie so only the server-side check can reject it
      const login = await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(204);
      const cookie = login.headers['set-cookie'][0].split(';')[0];
      const list = () => request(app).get('/api/staff/bookings').set('Cookie', cookie);
      vi.setSystemTime(Date.now() + 7 * 3600e3);
      await list().expect(200);
      vi.setSystemTime(Date.now() + 2 * 3600e3);
      await list().expect(401);
    } finally {
      vi.useRealTimers();
    }
  });
});
