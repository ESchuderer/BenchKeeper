import { createApp, parseTrustProxy } from './app.js';

const staffPassword = process.env.STAFF_PASSWORD ?? '';
if (!staffPassword) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');

const trustProxy = parseTrustProxy(process.env.TRUST_PROXY);
const port = Number(process.env.PORT) || 3000;
createApp({ staffPassword, trustProxy }).listen(port, () => console.log(`Listening on http://localhost:${port}`));
