import { Link, Route, Routes } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Book from './pages/Book.jsx';
import Confirmation from './pages/Confirmation.jsx';
import Staff from './pages/Staff.jsx';

export default function App() {
  return (
    <>
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-name">Weingut Kieselbrunnen</span>
          <span className="brand-tag">Family winery</span>
        </Link>
      </header>
      <main className="page">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/book/:id" element={<Book />} />
          <Route path="/confirmation" element={<Confirmation />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">Weingut Kieselbrunnen</footer>
    </>
  );
}

function NotFound() {
  return (
    <section className="card">
      <h1>Page not found</h1>
      <p>
        <Link to="/">Back to the tastings</Link>
      </p>
    </section>
  );
}
