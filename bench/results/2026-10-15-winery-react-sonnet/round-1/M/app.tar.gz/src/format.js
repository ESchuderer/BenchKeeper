// Matches the date format of the brief ("2026-11-06 18:00"), with the weekday added.
export const formatWhen = (startsAt) =>
  `${new Date(startsAt).toLocaleDateString('en-GB', { weekday: 'long' })} ${startsAt.replace('T', ' ')}`;

export const euro = (n) => `EUR ${n}`;
