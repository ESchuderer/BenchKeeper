import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { euro, formatWhen } from '../format.js';

const fields = [
  { name: 'name', label: 'Name', type: 'text', autoComplete: 'name' },
  { name: 'email', label: 'Email', type: 'email', autoComplete: 'email' },
];

export default function Book() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tasting, setTasting] = useState(undefined); // undefined: loading, null: unknown
  const [values, setValues] = useState({ name: '', email: '', guests: '1' });
  const [errors, setErrors] = useState({});
  const [sending, setSending] = useState(false);

  useEffect(() => {
    fetch('/api/tastings')
      .then((r) => r.json())
      .then((all) => setTasting(all.find((t) => t.id === id) ?? null))
      .catch(() => setErrors({ form: 'The tasting could not be loaded. Please try again later.' }));
  }, [id]);

  if (tasting === undefined) return <p role={errors.form ? 'alert' : undefined}>{errors.form ?? 'Loading...'}</p>;
  if (tasting === null)
    return (
      <section className="card">
        <h1>Tasting not found</h1>
        <p><Link to="/">Back to the tastings</Link></p>
      </section>
    );

  const soldOut = tasting.seatsLeft === 0;
  const set = (name) => (e) => setValues((v) => ({ ...v, [name]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setSending(true);
    setErrors({});
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tastingId: id, ...values }),
      });
      const body = await res.json();
      if (res.status === 201) return navigate('/confirmation', { state: body });
      setErrors(body.errors ?? { form: body.error ?? 'Something went wrong. Please try again.' });
      // refresh seats so the guest sees the current number after a rejection
      fetch('/api/tastings').then((r) => r.json()).then((all) => setTasting(all.find((t) => t.id === id) ?? null));
    } catch {
      setErrors({ form: 'The booking could not be sent. Please check your connection and try again.' });
    } finally {
      setSending(false);
    }
  }

  const fieldProps = (name) => ({
    id: name,
    name,
    value: values[name],
    onChange: set(name),
    disabled: soldOut,
    'aria-invalid': errors[name] ? 'true' : undefined,
    'aria-describedby': errors[name] ? `${name}-error` : undefined,
  });
  const fieldError = (name) =>
    errors[name] && <p id={`${name}-error`} className="field-error" role="alert">{errors[name]}</p>;

  return (
    <section className="card">
      <p><Link to="/">&larr; All tastings</Link></p>
      <h1>Book {tasting.title}</h1>
      <p className="when"><time dateTime={tasting.startsAt}>{formatWhen(tasting.startsAt)}</time></p>
      <p className="price">
        {euro(tasting.pricePerGuest)} per guest
        {!soldOut && <> &middot; {tasting.seatsLeft} seats left</>}
      </p>
      {soldOut && <p className="alert alert-error" role="status">This tasting is fully booked.</p>}
      {errors.form && <p className="alert alert-error" role="alert">{errors.form}</p>}
      <form onSubmit={submit} noValidate>
        {fields.map((f) => (
          <div key={f.name} className={`field${errors[f.name] ? ' has-error' : ''}`}>
            <label htmlFor={f.name}>{f.label}</label>
            <input {...fieldProps(f.name)} type={f.type} autoComplete={f.autoComplete} />
            {fieldError(f.name)}
          </div>
        ))}
        <div className={`field${errors.guests ? ' has-error' : ''}`}>
          <label htmlFor="guests">Guests</label>
          <input {...fieldProps('guests')} type="number" inputMode="numeric" min="1" max="8" step="1" />
          {fieldError('guests')}
        </div>
        <button type="submit" className="button" disabled={soldOut || sending}>Book</button>
      </form>
    </section>
  );
}
