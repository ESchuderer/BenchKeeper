import { Link, Navigate, useLocation } from 'react-router-dom';
import { euro, formatWhen } from '../format.js';

export default function Confirmation() {
  const { state } = useLocation();
  if (!state?.reference) return <Navigate to="/" replace />;

  return (
    <section className="card success">
      <h1>Booking confirmed</h1>
      <p>Thank you! We look forward to seeing you at the winery.</p>
      <dl className="summary">
        <dt>Tasting</dt>
        <dd>{state.tasting.title}, {formatWhen(state.tasting.startsAt)}</dd>
        <dt>Guests</dt>
        <dd>{state.guests}</dd>
        <dt>Total price</dt>
        <dd>{euro(state.total)}</dd>
        <dt>Booking reference</dt>
        <dd className="reference">{state.reference}</dd>
      </dl>
      <p><Link to="/" className="button">Back to the tastings</Link></p>
    </section>
  );
}
