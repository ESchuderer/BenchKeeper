import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { euro, formatWhen } from '../format.js';

export default function Home() {
  const [tastings, setTastings] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    fetch('/api/tastings')
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then(setTastings)
      .catch(() => setFailed(true));
  }, []);

  return (
    <>
      <section className="hero">
        <h1>Wine tastings</h1>
        <p>Join us in the cellar and taste what the family has been growing for generations.</p>
      </section>
      {failed && <p className="alert alert-error" role="alert">The tastings could not be loaded. Please try again later.</p>}
      {!tastings && !failed && <p>Loading tastings...</p>}
      <ul className="tastings">
        {tastings?.map((t) => {
          const soldOut = t.seatsLeft === 0;
          return (
            <li key={t.id} className={`card tasting${soldOut ? ' sold-out' : ''}`}>
              <h2>{t.title}</h2>
              <p className="when">
                <time dateTime={t.startsAt}>{formatWhen(t.startsAt)}</time>
              </p>
              <p className="price">{euro(t.pricePerGuest)} per guest</p>
              {soldOut ? (
                <p className="badge badge-sold">Fully booked, 0 seats left</p>
              ) : (
                <p className={`badge${t.seatsLeft <= 3 ? ' badge-few' : ''}`}>{t.seatsLeft} seats left</p>
              )}
              {soldOut ? (
                <button type="button" className="button" disabled>Book {t.title}</button>
              ) : (
                <Link to={`/book/${t.id}`} className="button">Book {t.title}</Link>
              )}
            </li>
          );
        })}
      </ul>
    </>
  );
}
