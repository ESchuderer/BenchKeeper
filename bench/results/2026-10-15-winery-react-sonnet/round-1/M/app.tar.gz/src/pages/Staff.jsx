import { useEffect, useState } from 'react';
import { formatWhen } from '../format.js';

export default function Staff() {
  const [groups, setGroups] = useState(undefined); // undefined: checking, null: signed out
  const [error, setError] = useState('');

  async function load() {
    const res = await fetch('/api/staff/bookings');
    if (res.status === 401) return setGroups(null);
    if (!res.ok) return setError('The bookings could not be loaded.');
    setGroups(await res.json());
  }

  useEffect(() => {
    load().catch(() => setError('The bookings could not be loaded.'));
  }, []);

  async function cancel(reference) {
    setError('');
    const res = await fetch(`/api/staff/bookings/${reference}`, { method: 'DELETE' });
    if (res.status === 401) return setGroups(null);
    if (!res.ok && res.status !== 404) setError('The booking could not be cancelled.');
    await load();
  }

  async function signOut() {
    await fetch('/api/staff/logout', { method: 'POST' });
    setGroups(null);
  }

  if (groups === undefined) return <p role={error ? 'alert' : undefined}>{error || 'Loading...'}</p>;
  if (groups === null) return <SignIn onSignedIn={load} />;

  return (
    <>
      <div className="staff-head">
        <h1>Bookings</h1>
        <button type="button" className="button button-secondary" onClick={signOut}>Sign out</button>
      </div>
      {error && <p className="alert alert-error" role="alert">{error}</p>}
      {groups.map(({ tasting, bookings }) => (
        <section key={tasting.id} className="card" aria-labelledby={`h-${tasting.id}`}>
          <h2 id={`h-${tasting.id}`}>{tasting.title}</h2>
          <p className="when">{formatWhen(tasting.startsAt)}</p>
          {bookings.length === 0 ? (
            <p className="muted">No bookings yet.</p>
          ) : (
            <ul className="bookings">
              {bookings.map((b) => (
                <li key={b.reference}>
                  <div>
                    <strong>{b.name}</strong>
                    <span>{b.email}</span>
                    <span>{b.guests} {b.guests === 1 ? 'guest' : 'guests'}</span>
                    <span className="reference">{b.reference}</span>
                  </div>
                  <button type="button" className="button button-danger" onClick={() => cancel(b.reference)}>Cancel</button>
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}
    </>
  );
}

function SignIn({ onSignedIn }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setSending(true);
    setError('');
    try {
      const res = await fetch('/api/staff/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      if (res.status === 204) return await onSignedIn();
      setError((await res.json()).errors?.password ?? 'Sign in failed.');
    } catch {
      setError('Sign in failed. Please check your connection.');
    } finally {
      setSending(false);
    }
  }

  return (
    <section className="card narrow">
      <h1>Staff</h1>
      <form onSubmit={submit} noValidate>
        <div className={`field${error ? ' has-error' : ''}`}>
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            aria-invalid={error ? 'true' : undefined}
            aria-describedby={error ? 'password-error' : undefined}
          />
          {error && <p id="password-error" className="field-error" role="alert">{error}</p>}
        </div>
        <button type="submit" className="button" disabled={sending}>Sign in</button>
      </form>
    </section>
  );
}
