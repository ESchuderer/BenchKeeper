import { test, expect } from '@playwright/test';
import { book } from './helpers.js';

const card = (page, title) => page.getByRole('listitem').filter({ has: page.getByRole('heading', { name: title }) });

test('start page lists the tastings', async ({ page }) => {
  await page.goto('/');
  const riesling = card(page, 'Riesling Evening');
  await expect(riesling).toContainText('Friday, 6 November 2026, 18:00');
  await expect(riesling).toContainText('EUR 25 per guest');
  await expect(riesling).toContainText('12 seats left');
  await expect(card(page, 'Red Wine Cellar Tour')).toContainText('Saturday, 14 November 2026, 15:00');
  await expect(card(page, 'Red Wine Cellar Tour')).toContainText('EUR 32 per guest');
  await expect(card(page, 'Winter Tasting')).toContainText('10 seats left');
});

test('booking shows a confirmation and reduces the seats left', async ({ page }) => {
  await book(page, 'Winter Tasting', { guests: 3 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const main = page.getByRole('main');
  await expect(main).toContainText('Winter Tasting');
  await expect(main).toContainText('EUR 84');
  await expect(main.locator('.reference')).toHaveText(/^KB-[A-Z0-9]{6}$/);
  await page.getByRole('link', { name: 'Back to all tastings' }).click();
  await expect(card(page, 'Winter Tasting')).toContainText('7 seats left');
});

test('invalid input is reported next to the fields', async ({ page }) => {
  await page.goto('/book/riesling-evening');
  await page.getByLabel('Email').fill('nope');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.locator('#name-error')).toHaveText(/Enter your name/);
  await expect(page.locator('#email-error')).toHaveText(/valid email/);
  await expect(page.locator('#guests-error')).toHaveText(/At most 8/);
  await expect(page.getByLabel('Email')).toHaveAttribute('aria-invalid', 'true');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
});

test('a booking larger than the seats left is rejected by the server', async ({ page, request }) => {
  await page.goto('/book/riesling-evening');
  await request.post('/api/tastings/riesling-evening/bookings', { data: { name: 'Other', email: 'o@example.com', guests: 8 } });
  await request.post('/api/tastings/riesling-evening/bookings', { data: { name: 'Other', email: 'o@example.com', guests: 2 } });
  // the page still thinks 12 seats are left, so the server must refuse
  await page.getByLabel('Name').fill('Anna');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('3');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.locator('#guests-error')).toHaveText(/Only 2 seats left/);
});

test('a fully booked tasting has no booking link', async ({ page, request }) => {
  await request.post('/api/tastings/red-wine-cellar-tour/bookings', { data: { name: 'Full', email: 'f@example.com', guests: 8 } });
  await page.goto('/');
  const tour = card(page, 'Red Wine Cellar Tour');
  await expect(tour).toContainText('Fully booked');
  await expect(tour).toContainText('0 seats left');
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0);
  await page.goto('/book/red-wine-cellar-tour');
  await expect(page.getByRole('alert')).toHaveText('This tasting is fully booked.');
});
