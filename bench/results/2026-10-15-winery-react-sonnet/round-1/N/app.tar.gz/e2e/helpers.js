export const STAFF_PASSWORD = 'e2e-secret';

export async function signIn(page, password = STAFF_PASSWORD) {
  await page.goto('/staff');
  await page.getByLabel('Password').fill(password);
  await page.getByRole('button', { name: 'Sign in' }).click();
}

export async function book(page, title, { name = 'Anna Weber', email = 'anna@example.com', guests = 2 } = {}) {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${title}` }).click();
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Guests').fill(String(guests));
  await page.getByRole('button', { name: 'Book', exact: true }).click();
}
