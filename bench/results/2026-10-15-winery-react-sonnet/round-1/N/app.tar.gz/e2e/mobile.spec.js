import { test, expect } from '@playwright/test';
import { book, signIn } from './helpers.js';

const noHorizontalScroll = (page) =>
  page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth);

test('guest pages fit a phone screen', async ({ page }) => {
  await page.goto('/');
  expect(await noHorizontalScroll(page)).toBe(true);
  await book(page, 'Riesling Evening', { guests: 1 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  expect(await noHorizontalScroll(page)).toBe(true);
});

test('staff list fits a phone screen', async ({ page }) => {
  await signIn(page);
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  expect(await noHorizontalScroll(page)).toBe(true);
});
