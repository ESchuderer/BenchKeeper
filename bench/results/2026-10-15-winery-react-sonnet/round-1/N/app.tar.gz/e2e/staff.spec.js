import { test, expect } from '@playwright/test';
import { signIn } from './helpers.js';

test('wrong password shows an error next to the field', async ({ page }) => {
  await signIn(page, 'wrong');
  await expect(page.locator('#password-error')).toHaveText('Wrong password.');
  await expect(page.getByRole('heading', { name: 'Bookings' })).toHaveCount(0);
});

test('staff see bookings grouped by tasting, cancel one and sign out', async ({ page, request }) => {
  const res = await request.post('/api/tastings/winter-tasting/bookings', {
    data: { name: 'Staff Test Guest', email: 'guest@example.com', guests: 4 },
  });
  const { reference } = await res.json();

  await signIn(page);
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  const group = page.getByRole('region', { name: 'Winter Tasting' });
  const row = group.getByRole('row').filter({ hasText: reference });
  await expect(row).toContainText('Staff Test Guest');
  await expect(row).toContainText('guest@example.com');
  await expect(row).toContainText('4');
  await expect(page.getByRole('region', { name: 'Riesling Evening' })).toBeVisible();

  const before = (await (await request.get('/api/tastings')).json()).find((t) => t.id === 'winter-tasting').seatsLeft;
  await row.getByRole('button', { name: 'Cancel' }).click();
  await expect(row).toHaveCount(0);
  await expect(page.getByRole('status')).toContainText(`Booking ${reference} for Staff Test Guest cancelled.`);
  const after = (await (await request.get('/api/tastings')).json()).find((t) => t.id === 'winter-tasting').seatsLeft;
  expect(after).toBe(before + 4);

  await page.reload();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Password')).toBeVisible();
});
