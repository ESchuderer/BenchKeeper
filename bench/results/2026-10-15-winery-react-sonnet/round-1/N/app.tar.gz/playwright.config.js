import { defineConfig, devices } from '@playwright/test';

const PORT = 3111;

export default defineConfig({
  testDir: 'e2e',
  workers: 1, // bookings are shared server state
  use: { baseURL: `http://localhost:${PORT}` },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] }, testIgnore: /mobile\.spec\.js/ },
    { name: 'mobile', use: { ...devices['Pixel 7'] }, testMatch: /mobile\.spec\.js/ },
  ],
  webServer: {
    command: 'npm run build && npm start',
    url: `http://localhost:${PORT}`,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-secret' },
    reuseExistingServer: false,
  },
});
