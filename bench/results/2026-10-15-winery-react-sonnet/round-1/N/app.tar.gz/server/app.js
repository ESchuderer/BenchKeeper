import { randomBytes, timingSafeEqual, createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import { createStore } from './store.js';

const SESSION_COOKIE = 'kb_staff';
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const MAX_FAILED_LOGINS = 5;
const FAILED_LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_GUESTS = 8;
const DIST = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');

const bookingSchema = z.object({
  name: z
    .string({ error: 'Enter your name.' })
    .transform((s) => s.trim().replace(/\s+/g, ' '))
    .pipe(z.string().min(1, 'Enter your name.').max(100, 'Name must be 100 characters or fewer.')),
  email: z
    .string({ error: 'Enter your email address.' })
    .trim()
    .min(1, 'Enter your email address.')
    .max(254, 'Email must be 254 characters or fewer.')
    .pipe(z.email('Enter a valid email address.')),
  guests: z.preprocess(
    (v) => (typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : v),
    z
      .number({ error: `Enter a number of guests from 1 to ${MAX_GUESTS}.` })
      .int(`Enter a whole number of guests from 1 to ${MAX_GUESTS}.`)
      .min(1, `Enter a number of guests from 1 to ${MAX_GUESTS}.`)
      .max(MAX_GUESTS, `At most ${MAX_GUESTS} guests per booking.`),
  ),
});

const digest = (value) => createHash('sha256').update(String(value)).digest();
const passwordMatches = (given, expected) => timingSafeEqual(digest(given), digest(expected));

function fieldErrors(issues) {
  const errors = {};
  for (const issue of issues) errors[issue.path[0] ?? 'form'] ??= issue.message;
  return errors;
}

export function createApp({
  staffPassword = process.env.STAFF_PASSWORD ?? '',
  sessionTtlMs = SESSION_TTL_MS,
  now = Date.now,
  trustProxy = process.env.TRUST_PROXY || '',
} = {}) {
  const store = createStore();
  const sessions = new Map(); // token hash -> expiry (ms)
  const app = express();
  // "true" would trust any client-supplied X-Forwarded-For and defeat the login limit; use a hop count or subnet list.
  if (trustProxy && trustProxy !== 'true') app.set('trust proxy', /^\d+$/.test(trustProxy) ? Number(trustProxy) : trustProxy);
  app.disable('x-powered-by');
  // upgrade-insecure-requests would break asset loading over plain HTTP on a non-localhost host.
  app.use(helmet({ contentSecurityPolicy: { directives: { 'upgrade-insecure-requests': null } } }));
  app.use(express.json({ limit: '10kb' }));

  const sessionKey = (req) => {
    const token = req.get('cookie')?.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([\\w-]+)`))?.[1];
    return token && digest(token).toString('hex');
  };
  const clearCookie = (res) => res.clearCookie(SESSION_COOKIE, { path: '/' });

  const requireStaff = (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    const key = sessionKey(req);
    const expiry = key && sessions.get(key);
    if (expiry && expiry > now()) return next();
    if (key) sessions.delete(key);
    res.status(401).json({ error: 'Sign in required.' });
  };

  // Only failed attempts count; once the limit is hit, even the right password is refused.
  const failedLoginLimit = rateLimit({
    windowMs: FAILED_LOGIN_WINDOW_MS,
    limit: MAX_FAILED_LOGINS,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res) => res.status(429).json({ error: 'Too many failed attempts. Try again in 15 minutes.' }),
  });

  app.get('/api/tastings', (req, res) => res.json(store.tastings()));

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const parsed = bookingSchema.safeParse(req.body ?? {});
    if (!parsed.success) return res.status(400).json({ errors: fieldErrors(parsed.error.issues) });
    const result = store.book(req.params.id, parsed.data);
    if (result.error === 'unknown') return res.status(404).json({ error: 'Tasting not found.' });
    if (result.error) {
      const guests =
        result.error === 'full'
          ? 'This tasting is fully booked.'
          : `Only ${result.seatsLeft} seats left for this tasting.`;
      return res.status(409).json({ errors: { guests } });
    }
    res.status(201).json(result.booking);
  });

  app.post('/api/staff/login', failedLoginLimit, (req, res) => {
    const given = req.body?.password;
    // An unset STAFF_PASSWORD never matches, so staff access stays closed.
    if (!staffPassword || typeof given !== 'string' || !passwordMatches(given, staffPassword)) {
      return res.status(401).json({ error: 'Wrong password.' });
    }
    const token = randomBytes(32).toString('base64url');
    sessions.set(digest(token).toString('hex'), now() + sessionTtlMs);
    res.cookie(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure || req.get('x-forwarded-proto')?.split(',')[0].trim() === 'https',
      maxAge: sessionTtlMs,
      path: '/',
    });
    res.status(204).end();
  });

  app.post('/api/staff/logout', (req, res) => {
    const key = sessionKey(req);
    if (key) sessions.delete(key);
    clearCookie(res);
    res.status(204).end();
  });

  app.get('/api/staff/bookings', requireStaff, (req, res) => res.json(store.bookingsByTasting()));

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!store.cancel(req.params.reference)) return res.status(404).json({ error: 'Booking not found.' });
    res.status(204).end();
  });

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

  app.use(express.static(DIST));
  app.get('/{*splat}', (req, res) => res.sendFile(path.join(DIST, 'index.html')));

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed' || err.type === 'entity.too.large') {
      return res.status(err.status).json({ error: 'Invalid request body.' });
    }
    console.error(err);
    res.status(500).json({ error: 'Something went wrong.' });
  });

  return app;
}
