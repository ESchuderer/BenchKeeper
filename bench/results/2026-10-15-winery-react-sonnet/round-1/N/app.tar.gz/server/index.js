import { createApp } from './app.js';

if (!process.env.STAFF_PASSWORD) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}
const port = Number(process.env.PORT) || 3000;
createApp().listen(port, () => console.log(`Listening on port ${port}`));
