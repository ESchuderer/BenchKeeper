import { randomInt } from 'node:crypto';

export const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEur: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceEur: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceEur: 28, seats: 10 },
];

// No 0/O/1/I so references can be read out over the phone.
const REFERENCE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function newReference(taken) {
  let reference;
  do {
    reference = 'KB-' + Array.from({ length: 6 }, () => REFERENCE_CHARS[randomInt(REFERENCE_CHARS.length)]).join('');
  } while (taken.has(reference));
  return reference;
}

// shortcut: bookings live in memory and are lost on restart, move to a file or database if that matters.
export function createStore() {
  const bookings = new Map();

  const seatsLeft = (tasting) => {
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === tasting.id) taken += b.guests;
    return tasting.seats - taken;
  };
  const describe = (tasting) => ({ ...tasting, seatsLeft: seatsLeft(tasting) });
  const find = (id) => TASTINGS.find((t) => t.id === id);

  return {
    tastings: () => TASTINGS.map(describe),

    // Returns { booking } or { error: 'unknown' | 'full' | 'too-many', seatsLeft }.
    book(tastingId, { name, email, guests }) {
      const tasting = find(tastingId);
      if (!tasting) return { error: 'unknown' };
      const left = seatsLeft(tasting);
      if (left === 0) return { error: 'full', seatsLeft: left };
      if (guests > left) return { error: 'too-many', seatsLeft: left };
      const booking = {
        reference: newReference(bookings),
        tastingId,
        name,
        email,
        guests,
        createdAt: new Date().toISOString(),
      };
      bookings.set(booking.reference, booking);
      return {
        booking: { ...booking, totalEur: tasting.priceEur * guests, tasting: describe(tasting) },
      };
    },

    cancel: (reference) => bookings.delete(reference),

    bookingsByTasting: () =>
      TASTINGS.map((tasting) => ({
        tasting: describe(tasting),
        bookings: [...bookings.values()]
          .filter((b) => b.tastingId === tasting.id)
          .map(({ reference, name, email, guests, createdAt }) => ({ reference, name, email, guests, createdAt })),
      })),
  };
}
