import { Link, Route, Routes } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Book from './pages/Book.jsx';
import Staff from './pages/Staff.jsx';

function NotFound() {
  return (
    <section className="panel narrow">
      <h1>Page not found</h1>
      <p>We could not find that page.</p>
      <Link className="button" to="/">
        Back to all tastings
      </Link>
    </section>
  );
}

export default function App() {
  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-name">Weingut Kieselbrunnen</span>
          <span className="brand-tag">Family winery</span>
        </Link>
      </header>
      <main id="main" className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/book/:id" element={<Book />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <span>Weingut Kieselbrunnen</span>
        <Link to="/staff">Staff</Link>
      </footer>
    </>
  );
}
