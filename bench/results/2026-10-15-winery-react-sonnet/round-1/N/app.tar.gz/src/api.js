export class ApiError extends Error {
  constructor(status, body) {
    super(body?.error ?? 'Something went wrong.');
    this.status = status;
    this.fieldErrors = body?.errors ?? {};
  }
}

export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}
