// startsAt is winery-local wall time ("2026-11-06T18:00"); format it as UTC so the viewer's time zone never shifts it.
const dateTime = new Intl.DateTimeFormat('en-GB', {
  weekday: 'long',
  day: 'numeric',
  month: 'long',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
  timeZone: 'UTC',
});

export const formatDateTime = (startsAt) => dateTime.format(new Date(`${startsAt}:00Z`)).replace(' at ', ', ');
export const formatEur = (amount) => `EUR ${amount}`;
