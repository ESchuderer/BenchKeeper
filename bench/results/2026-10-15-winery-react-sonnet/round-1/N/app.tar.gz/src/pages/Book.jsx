import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useForm, useWatch } from 'react-hook-form';
import { api, ApiError } from '../api.js';
import { useTastings } from '../useTastings.js';
import { formatDateTime, formatEur } from '../format.js';

const MAX_GUESTS = 8;
const FIELDS = ['name', 'email', 'guests'];

function Field({ id, label, error, children }) {
  return (
    <div className={`field${error ? ' has-error' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children}
      {error && (
        <p className="field-error" role="alert" id={`${id}-error`}>
          {error}
        </p>
      )}
    </div>
  );
}

function Confirmation({ booking }) {
  const heading = useRef(null);
  useEffect(() => heading.current?.focus(), []);
  return (
    <section className="panel narrow success" aria-labelledby="confirmed">
      <h1 id="confirmed" tabIndex={-1} ref={heading}>
        Booking confirmed
      </h1>
      <p>Thank you, {booking.name}. Your seats are reserved.</p>
      <dl className="summary">
        <dt>Tasting</dt>
        <dd>{booking.tasting.title}</dd>
        <dt>Date and time</dt>
        <dd>{formatDateTime(booking.tasting.startsAt)}</dd>
        <dt>Guests</dt>
        <dd>{booking.guests}</dd>
        <dt>Total price</dt>
        <dd>{formatEur(booking.totalEur)}</dd>
        <dt>Booking reference</dt>
        <dd className="reference">{booking.reference}</dd>
      </dl>
      <p className="muted">Please quote your booking reference when you arrive.</p>
      <Link className="button" to="/">
        Back to all tastings
      </Link>
    </section>
  );
}

function BookingForm({ tasting, onBooked }) {
  const {
    register,
    handleSubmit,
    setError,
    control,
    formState: { errors, isSubmitting },
  } = useForm({ defaultValues: { name: '', email: '', guests: 1 } });
  const [formError, setFormError] = useState('');
  const guests = Number(useWatch({ control, name: 'guests' }));
  const maxGuests = Math.min(MAX_GUESTS, tasting.seatsLeft);
  const total = Number.isInteger(guests) && guests >= 1 && guests <= maxGuests ? guests * tasting.priceEur : null;

  const onSubmit = async (values) => {
    setFormError('');
    try {
      onBooked(await api(`/api/tastings/${tasting.id}/bookings`, { method: 'POST', body: values }));
    } catch (err) {
      const fields = err instanceof ApiError ? Object.entries(err.fieldErrors).filter(([name]) => FIELDS.includes(name)) : [];
      if (fields.length) fields.forEach(([name, message]) => setError(name, { message }, { shouldFocus: true }));
      else setFormError('We could not complete your booking. Please try again.');
    }
  };

  const describe = (name) => ({ 'aria-invalid': !!errors[name], 'aria-describedby': errors[name] ? `${name}-error` : undefined });

  return (
    <form className="panel narrow" onSubmit={handleSubmit(onSubmit)} noValidate>
      <h1>Book {tasting.title}</h1>
      <p className="muted">
        {formatDateTime(tasting.startsAt)} &middot; {formatEur(tasting.priceEur)} per guest &middot; {tasting.seatsLeft} seats left
      </p>
      <Field id="name" label="Name" error={errors.name?.message}>
        <input
          id="name"
          autoComplete="name"
          {...describe('name')}
          {...register('name', {
            validate: (v) => (v.trim() ? true : 'Enter your name.'),
            maxLength: { value: 100, message: 'Name must be 100 characters or fewer.' },
          })}
        />
      </Field>
      <Field id="email" label="Email" error={errors.email?.message}>
        <input
          id="email"
          type="email"
          autoComplete="email"
          {...describe('email')}
          {...register('email', {
            required: 'Enter your email address.',
            pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address.' },
          })}
        />
      </Field>
      <Field id="guests" label="Guests" error={errors.guests?.message}>
        <input
          id="guests"
          type="number"
          inputMode="numeric"
          min={1}
          max={maxGuests}
          {...describe('guests')}
          {...register('guests', {
            validate: (v) => {
              const n = Number(v);
              if (v === '' || !Number.isInteger(n) || n < 1) return `Enter a number of guests from 1 to ${MAX_GUESTS}.`;
              if (n > MAX_GUESTS) return `At most ${MAX_GUESTS} guests per booking.`;
              if (n > tasting.seatsLeft) return `Only ${tasting.seatsLeft} seats left for this tasting.`;
              return true;
            },
          })}
        />
      </Field>
      {total !== null && (
        <p className="total">
          Total: <strong>{formatEur(total)}</strong>
        </p>
      )}
      {formError && (
        <p className="alert" role="alert">
          {formError}
        </p>
      )}
      <button className="button" type="submit" disabled={isSubmitting}>
        Book
      </button>
      <Link className="text-link" to="/">
        Back to all tastings
      </Link>
    </form>
  );
}

export default function Book() {
  const { id } = useParams();
  const { status, tastings } = useTastings();
  const [booking, setBooking] = useState(null);
  const tasting = tastings.find((t) => t.id === id);

  if (booking) return <Confirmation booking={booking} />;
  if (status === 'loading') return <p role="status">Loading...</p>;
  if (status === 'error') {
    return (
      <p className="alert" role="alert">
        We could not load this tasting. Please refresh the page.
      </p>
    );
  }
  if (!tasting) {
    return (
      <section className="panel narrow">
        <h1>Tasting not found</h1>
        <Link className="button" to="/">
          Back to all tastings
        </Link>
      </section>
    );
  }
  if (tasting.seatsLeft === 0) {
    return (
      <section className="panel narrow">
        <h1>{tasting.title}</h1>
        <p className="alert" role="alert">
          This tasting is fully booked.
        </p>
        <Link className="button" to="/">
          Back to all tastings
        </Link>
      </section>
    );
  }
  return <BookingForm tasting={tasting} onBooked={setBooking} />;
}
