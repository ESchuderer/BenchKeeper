import { Link } from 'react-router-dom';
import { useTastings } from '../useTastings.js';
import { formatDateTime, formatEur } from '../format.js';

const FEW_LEFT = 3;

function TastingCard({ tasting }) {
  const full = tasting.seatsLeft === 0;
  return (
    <li className="card">
      <time className="card-date" dateTime={tasting.startsAt}>
        {formatDateTime(tasting.startsAt)}
      </time>
      <h2>{tasting.title}</h2>
      <p className="card-price">{formatEur(tasting.priceEur)} per guest</p>
      <div className="card-foot">
        <span className={`pill ${full ? 'pill-full' : tasting.seatsLeft <= FEW_LEFT ? 'pill-few' : 'pill-ok'}`}>
          {tasting.seatsLeft} seats left
        </span>
        {full ? (
          <span className="badge-full">Fully booked</span>
        ) : (
          <Link className="button" to={`/book/${tasting.id}`}>
            Book {tasting.title}
          </Link>
        )}
      </div>
    </li>
  );
}

export default function Home() {
  const { status, tastings } = useTastings();
  return (
    <>
      <section className="hero">
        <h1>Wine tastings at Kieselbrunnen</h1>
        <p>Join us at the family estate for an evening among the vines and the cellar. Choose a tasting and reserve your seats.</p>
      </section>
      {status === 'loading' && <p role="status">Loading tastings...</p>}
      {status === 'error' && (
        <p className="alert" role="alert">
          We could not load the tastings. Please refresh the page.
        </p>
      )}
      {status === 'ready' && (
        <ul className="cards">
          {tastings.map((t) => (
            <TastingCard key={t.id} tasting={t} />
          ))}
        </ul>
      )}
    </>
  );
}
