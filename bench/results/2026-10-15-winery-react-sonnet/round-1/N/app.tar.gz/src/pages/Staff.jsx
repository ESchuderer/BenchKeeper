import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '../api.js';
import { formatDateTime } from '../format.js';

function SignIn({ notice, onSignedIn }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (event) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api('/api/staff/login', { method: 'POST', body: { password } });
      onSignedIn();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'We could not sign you in. Please try again.');
      setBusy(false);
    }
  };

  return (
    <form className="panel narrow" onSubmit={submit} noValidate>
      <h1>Staff sign-in</h1>
      {notice && (
        <p className="alert" role="status">
          {notice}
        </p>
      )}
      <div className={`field${error ? ' has-error' : ''}`}>
        <label htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          aria-invalid={!!error}
          aria-describedby={error ? 'password-error' : undefined}
        />
        {error && (
          <p className="field-error" role="alert" id="password-error">
            {error}
          </p>
        )}
      </div>
      <button className="button" type="submit" disabled={busy}>
        Sign in
      </button>
    </form>
  );
}

function TastingBookings({ group, onCancel, cancelling }) {
  const { tasting, bookings } = group;
  return (
    <section className="panel staff-group" aria-labelledby={`t-${tasting.id}`}>
      <header className="staff-group-head">
        <h2 id={`t-${tasting.id}`}>{tasting.title}</h2>
        <p className="muted">
          {formatDateTime(tasting.startsAt)} &middot; {tasting.seats - tasting.seatsLeft} of {tasting.seats} seats booked
        </p>
      </header>
      {bookings.length === 0 ? (
        <p className="muted">No bookings yet.</p>
      ) : (
        <table className="bookings">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Guests</th>
              <th scope="col">Reference</th>
              <th scope="col">
                <span className="visually-hidden">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b.reference}>
                <td data-label="Name">{b.name}</td>
                <td data-label="Email">{b.email}</td>
                <td data-label="Guests">{b.guests}</td>
                <td data-label="Reference" className="reference-cell">
                  {b.reference}
                </td>
                <td className="actions">
                  <button className="button button-danger" type="button" disabled={cancelling !== null} onClick={() => onCancel(b)}>
                    Cancel
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

async function fetchView() {
  try {
    return { status: 'ready', groups: await api('/api/staff/bookings') };
  } catch (err) {
    return { status: err instanceof ApiError && err.status === 401 ? 'signed-out' : 'error' };
  }
}

export default function Staff() {
  const [view, setView] = useState({ status: 'loading' }); // loading | signed-out | ready | error
  const [notice, setNotice] = useState('');
  const [cancelling, setCancelling] = useState(null);

  const load = useCallback(() => fetchView().then(setView), []);

  useEffect(() => {
    let stale = false;
    fetchView().then((next) => !stale && setView(next));
    return () => {
      stale = true;
    };
  }, []);

  const cancel = async (booking) => {
    setCancelling(booking.reference);
    setNotice('');
    try {
      await api(`/api/staff/bookings/${booking.reference}`, { method: 'DELETE' });
      setNotice(`Booking ${booking.reference} for ${booking.name} cancelled.`);
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setNotice('Your session has expired. Sign in again.');
        setView({ status: 'signed-out' });
        setCancelling(null);
        return;
      }
      setNotice(err instanceof ApiError && err.status === 404 ? 'That booking was already cancelled.' : 'We could not cancel the booking. Please try again.');
    }
    setCancelling(null);
    load();
  };

  const signOut = async () => {
    try {
      await api('/api/staff/logout', { method: 'POST' });
    } catch {
      setNotice('We could not sign you out. Please try again.');
      return;
    }
    setNotice('You are signed out.');
    setView({ status: 'signed-out' });
  };

  if (view.status === 'loading') return <p role="status">Loading...</p>;
  if (view.status === 'error') {
    return (
      <p className="alert" role="alert">
        We could not load the bookings. Please refresh the page.
      </p>
    );
  }
  if (view.status === 'signed-out') {
    return (
      <SignIn
        notice={notice}
        onSignedIn={() => {
          setNotice('');
          load();
        }}
      />
    );
  }

  const total = view.groups.reduce((sum, g) => sum + g.bookings.length, 0);
  return (
    <>
      <div className="staff-bar">
        <h1>Bookings</h1>
        <button className="button button-secondary" type="button" onClick={signOut}>
          Sign out
        </button>
      </div>
      <p className="muted">{total} {total === 1 ? 'booking' : 'bookings'} in total.</p>
      <div role="status" className={notice ? 'notice' : undefined}>
        {notice}
      </div>
      {view.groups.map((group) => (
        <TastingBookings key={group.tasting.id} group={group} onCancel={cancel} cancelling={cancelling} />
      ))}
    </>
  );
}
