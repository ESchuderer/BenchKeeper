import { useEffect, useState } from 'react';
import { api } from './api.js';

export function useTastings() {
  const [state, setState] = useState({ status: 'loading', tastings: [] });
  useEffect(() => {
    let cancelled = false;
    api('/api/tastings')
      .then((tastings) => !cancelled && setState({ status: 'ready', tastings }))
      .catch(() => !cancelled && setState({ status: 'error', tastings: [] }));
    return () => {
      cancelled = true;
    };
  }, []);
  return state;
}
