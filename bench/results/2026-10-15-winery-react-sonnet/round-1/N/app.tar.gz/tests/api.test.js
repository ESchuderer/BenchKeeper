import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../server/app.js';

const PASSWORD = 'correct horse';
const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

let app;
beforeEach(() => {
  app = createApp({ staffPassword: PASSWORD });
});

const book = (tastingId, body = valid) => request(app).post(`/api/tastings/${tastingId}/bookings`).send(body);
const seatsLeft = async (id) => (await request(app).get('/api/tastings')).body.find((t) => t.id === id).seatsLeft;

async function staffAgent() {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(204);
  return agent;
}

describe('tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const res = await request(app).get('/api/tastings').expect(200);
    expect(res.body.map((t) => [t.title, t.startsAt, t.priceEur, t.seatsLeft])).toEqual([
      ['Riesling Evening', '2026-11-06T18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14T15:00', 32, 8],
      ['Winter Tasting', '2026-12-05T17:00', 28, 10],
    ]);
  });
});

describe('booking', () => {
  it('confirms a booking with total price and reference and reduces seats', async () => {
    const res = await book('riesling-evening').expect(201);
    expect(res.body).toMatchObject({ guests: 2, totalEur: 50, tasting: { title: 'Riesling Evening' } });
    expect(res.body.reference).toMatch(/^KB-[A-Z0-9]{6}$/);
    expect(await seatsLeft('riesling-evening')).toBe(10);
  });

  it('accepts the maximum of 8 guests and numeric strings', async () => {
    await book('winter-tasting', { ...valid, guests: 8 }).expect(201);
    await book('winter-tasting', { ...valid, guests: '2' }).expect(201);
  });

  it('issues distinct references', async () => {
    const a = await book('winter-tasting', { ...valid, guests: 1 });
    const b = await book('winter-tasting', { ...valid, guests: 1 });
    expect(a.body.reference).not.toBe(b.body.reference);
  });

  it('returns 404 for an unknown tasting', async () => {
    await book('nope').expect(404);
  });

  it.each([
    ['name', { ...valid, name: '   ' }],
    ['name', { ...valid, name: 'x'.repeat(101) }],
    ['email', { ...valid, email: 'not-an-email' }],
    ['email', { ...valid, email: '' }],
    ['guests', { ...valid, guests: 0 }],
    ['guests', { ...valid, guests: 9 }],
    ['guests', { ...valid, guests: 1.5 }],
    ['guests', { ...valid, guests: 'many' }],
    ['guests', { ...valid, guests: '' }],
    ['guests', { ...valid, guests: true }],
    ['guests', { ...valid, guests: [3] }],
    ['guests', { ...valid, guests: '0x2' }],
    ['guests', { name: valid.name, email: valid.email }],
  ])('rejects invalid %s with a field error', async (field, body) => {
    const res = await book('riesling-evening', body).expect(400);
    expect(res.body.errors[field]).toEqual(expect.any(String));
    expect(await seatsLeft('riesling-evening')).toBe(12);
  });

  it('rejects a body that is not JSON object', async () => {
    await request(app).post('/api/tastings/riesling-evening/bookings').set('Content-Type', 'application/json').send('[1]').expect(400);
  });

  it('never books more seats than are left', async () => {
    await book('red-wine-cellar-tour', { ...valid, guests: 8 }).expect(201);
    const res = await book('red-wine-cellar-tour', { ...valid, guests: 1 }).expect(409);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
    expect(await seatsLeft('red-wine-cellar-tour')).toBe(0);
  });

  it('names the remaining seats when the request is too large', async () => {
    await book('red-wine-cellar-tour', { ...valid, guests: 6 }).expect(201);
    const res = await book('red-wine-cellar-tour', { ...valid, guests: 3 }).expect(409);
    expect(res.body.errors.guests).toMatch(/2 seats left/);
    expect(await seatsLeft('red-wine-cellar-tour')).toBe(2);
  });

  it('can book exactly the seats left', async () => {
    await book('red-wine-cellar-tour', { ...valid, guests: 6 }).expect(201);
    await book('red-wine-cellar-tour', { ...valid, guests: 2 }).expect(201);
    expect(await seatsLeft('red-wine-cellar-tour')).toBe(0);
  });
});

describe('staff access', () => {
  it('rejects bookings and cancel without a session', async () => {
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete('/api/staff/bookings/KB-AAAAAA').expect(401);
  });

  it('rejects a wrong password and sets no cookie', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('rejects every login when STAFF_PASSWORD is not configured', async () => {
    const open = createApp({ staffPassword: '' });
    await request(open).post('/api/staff/login').send({ password: '' }).expect(401);
    await request(open).post('/api/staff/login').send({}).expect(401);
  });

  it('sets an HttpOnly SameSite cookie on login', async () => {
    const res = await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(204);
    const cookie = res.headers['set-cookie'][0];
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    expect(cookie).not.toMatch(/Secure/i);
  });

  it('marks the cookie Secure when served over HTTPS', async () => {
    const res = await request(app)
      .post('/api/staff/login')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: PASSWORD })
      .expect(204);
    expect(res.headers['set-cookie'][0]).toMatch(/Secure/i);
  });

  it('ends the session on sign-out', async () => {
    const agent = await staffAgent();
    await agent.get('/api/staff/bookings').expect(200);
    await agent.post('/api/staff/logout').expect(204);
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('expires the session after its lifetime', async () => {
    let now = 1_000_000;
    const timed = createApp({ staffPassword: PASSWORD, sessionTtlMs: 1000, now: () => now });
    const agent = request.agent(timed);
    await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(204);
    await agent.get('/api/staff/bookings').expect(200);
    now += 1001;
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('blocks sign-in after 5 failed attempts, even with the right password', async () => {
    for (let i = 0; i < 5; i++) {
      await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    }
    await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(429);
    await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(429);
  });

  it('does not count successful sign-ins against the limit', async () => {
    for (let i = 0; i < 7; i++) await staffAgent();
  });
});

describe('staff bookings', () => {
  it('groups bookings by tasting, including empty tastings', async () => {
    await book('riesling-evening', { name: 'Anna', email: 'a@example.com', guests: 2 });
    await book('winter-tasting', { name: 'Ben', email: 'b@example.com', guests: 3 });
    const agent = await staffAgent();
    const res = await agent.get('/api/staff/bookings').expect(200);
    expect(res.body.map((g) => [g.tasting.id, g.bookings.length])).toEqual([
      ['riesling-evening', 1],
      ['red-wine-cellar-tour', 0],
      ['winter-tasting', 1],
    ]);
    expect(res.body[0].bookings[0]).toMatchObject({ name: 'Anna', email: 'a@example.com', guests: 2 });
    expect(res.body[0].bookings[0].reference).toMatch(/^KB-/);
  });

  it('cancels a booking and frees its seats', async () => {
    const { body } = await book('red-wine-cellar-tour', { ...valid, guests: 8 });
    const agent = await staffAgent();
    await agent.delete(`/api/staff/bookings/${body.reference}`).expect(204);
    expect(await seatsLeft('red-wine-cellar-tour')).toBe(8);
    await book('red-wine-cellar-tour', { ...valid, guests: 8 }).expect(201);
  });

  it('returns 404 when cancelling an unknown booking', async () => {
    const agent = await staffAgent();
    await agent.delete('/api/staff/bookings/KB-ZZZZZZ').expect(404);
  });
});

describe('http', () => {
  it('returns JSON 404 for unknown API routes', async () => {
    const res = await request(app).get('/api/unknown').expect(404);
    expect(res.body.error).toEqual(expect.any(String));
  });

  it('sends security headers and no-store on staff data', async () => {
    const agent = await staffAgent();
    const res = await agent.get('/api/staff/bookings');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['cache-control']).toMatch(/no-store/);
  });
});
