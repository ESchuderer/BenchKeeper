# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings online; staff see and cancel bookings at `/staff`.

```
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start   # http://localhost:3000 (PORT overrides the port)
```

- Without `STAFF_PASSWORD` nobody can sign in to `/staff`.
- Bookings are kept in memory and are lost when the server restarts.
- `npm test` runs API and UI tests, `npm run typecheck` checks types, `npm run dev` starts Vite (run the server on port 3000 too; `/api` is proxied).
- The three tastings are defined in `shared/tastings.ts`.

Stack: React 19, React Router, react-hook-form + zod, Tailwind CSS 4, Vite; Express 5 (run directly by Node 22, no server build).
