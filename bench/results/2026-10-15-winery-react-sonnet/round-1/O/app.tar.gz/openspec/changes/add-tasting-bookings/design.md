# Design

## Context

Greenfield, single small site. See proposal.md for scope and specs/ for behaviour. Node 22, no external services, one process serves API and UI.

## Goals / Non-Goals

**Goals:**
- One package, one process: `npm run build` then `npm start` serves everything on `PORT`.
- Seat limits that cannot be broken, even by simultaneous requests.
- Same validation rules enforced on the server; the client only mirrors them for convenience.

**Non-Goals:**
- Persistence across restarts, payments, emails, tasting management, past-date handling, per-user staff accounts.

## Decisions

- **Express 5 + Vite/React 19 + React Router 7 (library mode).** Established and small. Express serves the `dist` bundle and `/api`; the router handles `/`, `/book/:id`, `/staff`. Alternative: Next.js or React Router framework mode — heavier for three pages.
- **TypeScript everywhere; server run by Node's built-in type stripping** (Node 22.23), so there is no server build step and `tsc --noEmit` is the type check.
- **Zod schema shared by server and client**, with react-hook-form on the client. Server errors come back as `{ errors: { field: message } }` and are placed next to the fields, so client and server cannot disagree on wording.
- **Overbooking safety by single-threaded atomicity**: the seat check and the insert run in one synchronous function with no `await` between them, over in-memory state. Alternative: a database with transactions — unnecessary with no persistence requirement.
- **Staff auth**: random session token in an in-memory set, sent as an HttpOnly, SameSite=Strict cookie; password compared via SHA-256 digests with `timingSafeEqual`; `express-rate-limit` on sign-in. Empty `STAFF_PASSWORD` means sign-in always fails. SameSite=Strict plus JSON-only mutations is the CSRF defence.
- **Cancel = delete** from memory; seats left are always computed as seats minus booked guests, so cancelling frees them with no extra bookkeeping.
- **Confirmation is shown from the POST response** (no public lookup by reference), so booking data is never exposed to anonymous users.
- **References**: `KB-` plus 6 characters from an unambiguous alphabet, random, regenerated on collision.
- **Styling: Tailwind CSS v4** with a small palette (cream, burgundy, olive, gold) and a serif heading stack; no external fonts or services.
- **Tests**: Vitest + Supertest for the API (written first), React Testing Library for form/state behaviour, Playwright for an end-to-end pass if a browser is available.

## Risks / Trade-offs

- Bookings vanish on restart → documented; swap the store module for a file/DB later (`shortcut:` comment).
- Sessions are in memory and lost on restart → staff sign in again.
- Tastings in the past can still be booked → out of scope for the fixed autumn/winter list.
