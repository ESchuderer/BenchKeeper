# Proposal

## Why

Weingut Kieselbrunnen takes tasting reservations by hand. Guests cannot see which tastings have seats, and staff have no single list of who is coming. An online booking site fixes both and prevents overbooking.

## What Changes

- New guest-facing site: list of tastings with date, price and seats left; booking form; booking confirmation.
- New staff area at `/staff`, protected by a password from `STAFF_PASSWORD`: bookings per tasting, with cancellation that frees seats.
- Three fixed tastings (Riesling Evening, Red Wine Cellar Tour, Winter Tasting) are built in; there is no tasting management.
- A coherent winery look that works on phones and has clear error, success and fully-booked states.

## Capabilities

### New Capabilities
- `tasting-booking`: guests browse tastings and book seats; seat limits and input validation are enforced on the server.
- `staff-bookings`: password-protected staff view of bookings grouped by tasting, with cancellation.
- `site-presentation`: visual design, responsiveness and accessibility of states across all pages.

### Modified Capabilities

## Impact

- New project from scratch: React single-page app plus a Node 22 HTTP server in one package, served by `npm start` on `PORT`.
- Bookings are held in server memory (no external services); they are lost on restart.
- No existing code or specs are affected.
