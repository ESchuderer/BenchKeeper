# Spec Delta

## Purpose

Gives all pages one coherent winery look that is usable on phones and makes errors, success and fully booked tastings clearly recognisable.

## ADDED Requirements

### Requirement: Coherent winery design
All pages SHALL share one visual design (colours, typography, spacing, header and footer) that fits a small family winery, and the interface SHALL be in English.

#### Scenario: Consistent pages
- **WHEN** a visitor moves between the start page, booking form and staff page
- **THEN** they share the same header, palette and typography

### Requirement: Mobile usability
Every page SHALL be usable at a 360 px wide viewport without horizontal scrolling, with form controls and buttons large enough to tap.

#### Scenario: Phone viewport
- **WHEN** any page is opened at 360 px width
- **THEN** no horizontal scrollbar appears and all content and actions are reachable

### Requirement: Clear states
Errors, success and fully booked tastings SHALL be visually distinct and not conveyed by colour alone. Field errors SHALL be associated with their field for assistive technology, and every form control SHALL have a visible label.

#### Scenario: Field error
- **WHEN** a field is invalid
- **THEN** its message is shown next to it in text, the field is marked invalid, and the message is linked to the field

#### Scenario: Fully booked
- **WHEN** a tasting is fully booked
- **THEN** it carries a text label "Fully booked" and a muted appearance
