# Spec Delta

## Purpose

Lets winery staff see who has booked each tasting and cancel bookings, behind a shared password.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a password ("Password" field, "Sign in" button) and compare it with the environment variable `STAFF_PASSWORD`. Booking data SHALL NOT be available without signing in. If `STAFF_PASSWORD` is not set or empty, nobody SHALL be able to sign in.

#### Scenario: Correct password
- **WHEN** staff enter the value of `STAFF_PASSWORD` and press "Sign in"
- **THEN** the booking overview is shown

#### Scenario: Wrong password
- **WHEN** staff enter a different password
- **THEN** an error message is shown next to the "Password" field and no booking data is shown

#### Scenario: Unauthenticated data access
- **WHEN** the staff booking data is requested without signing in
- **THEN** the request is refused

### Requirement: Bookings overview
Signed-in staff SHALL see all bookings grouped by tasting, each with name, email, number of guests and booking reference. A tasting without bookings SHALL be shown as having none.

#### Scenario: Grouped list
- **WHEN** two guests have booked Riesling Evening and one has booked Winter Tasting
- **THEN** staff see Riesling Evening with two bookings and Winter Tasting with one, each with name, email, guests and reference

### Requirement: Cancel a booking
Signed-in staff SHALL be able to cancel a booking with a "Cancel" button. A cancelled booking SHALL disappear from the overview and its seats SHALL become available again.

#### Scenario: Cancel frees seats
- **WHEN** a booking of 3 guests on a tasting with 5 seats left is cancelled
- **THEN** the booking is gone from the overview and the tasting shows 8 seats left on the start page
