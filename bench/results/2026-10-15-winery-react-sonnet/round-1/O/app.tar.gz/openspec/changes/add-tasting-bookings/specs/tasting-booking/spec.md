# Spec Delta

## Purpose

Lets guests see the available wine tastings and reserve seats online, with the seat limit of each tasting enforced.

## ADDED Requirements

### Requirement: Tasting list
The start page SHALL list every tasting with its title, date and time, price per guest and the seats left, shown as "<n> seats left". The offered tastings are Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats). A new instance starts with no bookings.

#### Scenario: Fresh start
- **WHEN** a guest opens the start page and nothing has been booked
- **THEN** the three tastings are listed with "12 seats left", "8 seats left" and "10 seats left"

#### Scenario: Seats left after booking
- **WHEN** 3 guests have been booked on Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening

### Requirement: Booking entry point
Each tasting with seats left SHALL offer a link "Book <tasting title>" that opens a booking form for that tasting. A fully booked tasting SHALL be marked as fully booked and SHALL NOT offer booking.

#### Scenario: Open the form
- **WHEN** a guest follows "Book Riesling Evening"
- **THEN** a form for Riesling Evening opens with fields "Name", "Email" and "Guests" and a button "Book"

#### Scenario: Fully booked tasting
- **WHEN** a tasting has no seats left
- **THEN** the list shows it as fully booked with no "Book" link, and its booking form cannot be submitted

### Requirement: Booking input validation
The system SHALL accept a booking only with a non-empty name, a valid email address and a whole number of guests from 1 to 8. Each invalid input SHALL be rejected with an error message shown next to the field it concerns, and no booking SHALL be created. Validation SHALL be enforced by the server regardless of the client.

#### Scenario: Missing name
- **WHEN** a guest submits the form with an empty "Name"
- **THEN** an error message appears next to "Name" and no seats are taken

#### Scenario: Invalid email
- **WHEN** a guest submits "not-an-email" as "Email"
- **THEN** an error message appears next to "Email"

#### Scenario: Guests out of range
- **WHEN** a guest submits 0, 9, 2.5 or a non-number as "Guests"
- **THEN** an error message appears next to "Guests"

### Requirement: Seats are never overbooked
A booking SHALL NOT take more seats than are left for its tasting, including when several bookings are submitted at the same time.

#### Scenario: More guests than seats left
- **WHEN** 2 seats are left and a guest books 3
- **THEN** the booking is rejected with an error message next to "Guests" stating how many seats are left, and the seats left stay 2

#### Scenario: Last seats
- **WHEN** 2 seats are left and a guest books 2
- **THEN** the booking succeeds and the tasting is fully booked

#### Scenario: Concurrent bookings
- **WHEN** many bookings for more seats than are left are submitted simultaneously
- **THEN** the total of accepted guests never exceeds the tasting's seats

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (guests times price per guest) and a booking reference. Each booking SHALL get a distinct reference.

#### Scenario: Confirmation content
- **WHEN** a guest books 2 guests on Riesling Evening
- **THEN** the confirmation shows "Booking confirmed", "Riesling Evening", 2 guests, a total of EUR 50 and a booking reference
