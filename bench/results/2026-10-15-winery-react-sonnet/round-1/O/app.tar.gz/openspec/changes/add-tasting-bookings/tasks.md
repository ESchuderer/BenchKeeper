# Tasks

## 1. Project setup

- [x] 1.1 Create package.json, tsconfig, Vite + Tailwind + Vitest config, .gitignore; verify `npm install` succeeds and `npm run build` produces `dist/`
- [x] 1.2 Add `npm start` (Node server on `PORT`, default 3000); verify it serves the built app

## 2. Booking API (tests first)

- [x] 2.1 Write failing API tests for tasting list, validation, overbooking, concurrency, references; then implement store + routes; verify `npm test` passes
- [x] 2.2 Write failing API tests for staff sign-in, unauthenticated refusal, grouped list, cancel frees seats, empty `STAFF_PASSWORD`; then implement; verify `npm test` passes

## 3. Guest UI

- [x] 3.1 Write component tests, then build start page (list, seats left, fully booked state) and booking form (field errors, seats error, confirmation); verify tests pass
- [x] 3.2 Winery styling, responsive at 360 px, accessible error states; verify in a browser at phone and desktop widths

## 4. Staff UI

- [x] 4.1 Write component tests, then build `/staff` sign-in and grouped bookings with Cancel; verify tests pass

## 5. Integration

- [x] 5.1 Run the real built app and exercise the whole flow end to end (book, fill up, cancel, staff); verify against every spec scenario
- [x] 5.2 Write a README with run instructions; run the code review and security review and fix findings
