import { beforeEach, describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "./app.ts";

const PASSWORD = "s3cret-pw";
let app: ReturnType<typeof createApp>;

beforeEach(() => {
  app = createApp({ staffPassword: PASSWORD });
});

const book = (id: string, body: object) => request(app).post(`/api/tastings/${id}/bookings`).send(body);
const valid = { name: "Anna Weber", email: "anna@example.com", guests: 2 };
const seatsLeft = async (id: string) =>
  (await request(app).get("/api/tastings")).body.find((t: { id: string }) => t.id === id).seatsLeft;

async function signIn() {
  const res = await request(app).post("/api/staff/login").send({ password: PASSWORD });
  return res.headers["set-cookie"] as unknown as string[];
}

describe("tastings", () => {
  it("lists the three tastings with full seats", async () => {
    const res = await request(app).get("/api/tastings");
    expect(res.status).toBe(200);
    expect(res.body.map((t: any) => [t.title, t.startsAt, t.pricePerGuest, t.seatsLeft])).toEqual([
      ["Riesling Evening", "2026-11-06T18:00", 25, 12],
      ["Red Wine Cellar Tour", "2026-11-14T15:00", 32, 8],
      ["Winter Tasting", "2026-12-05T17:00", 28, 10],
    ]);
  });
});

describe("booking", () => {
  it("confirms a booking with total and reference and takes the seats", async () => {
    const res = await book("riesling-evening", valid);
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ guests: 2, total: 50, name: "Anna Weber", tasting: { title: "Riesling Evening" } });
    expect(res.body.reference).toMatch(/^KB-[A-Z0-9]{6}$/);
    expect(await seatsLeft("riesling-evening")).toBe(10);
  });

  it("gives distinct references", async () => {
    const refs = new Set<string>();
    for (let i = 0; i < 8; i++) refs.add((await book("winter-tasting", { ...valid, guests: 1 })).body.reference);
    expect(refs.size).toBe(8);
  });

  it("accepts guests sent as digits text", async () => {
    expect((await book("winter-tasting", { ...valid, guests: "3" })).body.total).toBe(84);
  });

  it.each([
    ["empty name", { ...valid, name: "  " }, "name"],
    ["missing name", { email: valid.email, guests: 1 }, "name"],
    ["bad email", { ...valid, email: "not-an-email" }, "email"],
    ["missing email", { name: "A", guests: 1 }, "email"],
    ["zero guests", { ...valid, guests: 0 }, "guests"],
    ["nine guests", { ...valid, guests: 9 }, "guests"],
    ["fractional guests", { ...valid, guests: 2.5 }, "guests"],
    ["text guests", { ...valid, guests: "abc" }, "guests"],
    ["empty guests", { ...valid, guests: "" }, "guests"],
    ["negative guests", { ...valid, guests: "-1" }, "guests"],
    ["missing guests", { name: "A", email: valid.email }, "guests"],
  ])("rejects %s next to its field", async (_label, body, field) => {
    const res = await book("riesling-evening", body);
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors)).toContain(field);
    expect(await seatsLeft("riesling-evening")).toBe(12);
  });

  it("reports every invalid field at once", async () => {
    const res = await book("riesling-evening", { name: "", email: "x", guests: 0 });
    expect(Object.keys(res.body.errors).sort()).toEqual(["email", "guests", "name"]);
  });

  it("rejects a body that is not an object, and broken JSON", async () => {
    expect((await book("riesling-evening", [1] as any)).status).toBe(400);
    const res = await request(app).post("/api/tastings/riesling-evening/bookings").set("Content-Type", "application/json").send("{oops");
    expect(res.status).toBe(400);
  });

  it("404s for an unknown tasting", async () => {
    expect((await book("nope", valid)).status).toBe(404);
  });

  it("rejects more guests than seats left, naming the seats left", async () => {
    await book("red-wine-cellar-tour", { ...valid, guests: 8 });
    await book("red-wine-cellar-tour", { ...valid, guests: 8 }); // now 0 left of 8
    expect(await seatsLeft("red-wine-cellar-tour")).toBe(0);
    const full = await book("red-wine-cellar-tour", { ...valid, guests: 1 });
    expect(full.status).toBe(409);
    expect(full.body.errors.guests).toMatch(/fully booked/i);
  });

  it("allows booking exactly the seats left and refuses one more", async () => {
    await book("winter-tasting", { ...valid, guests: 8 }); // 2 left
    const over = await book("winter-tasting", { ...valid, guests: 3 });
    expect(over.status).toBe(409);
    expect(over.body.errors.guests).toMatch(/only 2 seats left/i);
    expect(await seatsLeft("winter-tasting")).toBe(2);
    expect((await book("winter-tasting", { ...valid, guests: 2 })).status).toBe(201);
    expect(await seatsLeft("winter-tasting")).toBe(0);
  });

  it("never overbooks under simultaneous requests", async () => {
    const results = await Promise.all(
      Array.from({ length: 30 }, (_, i) => book("riesling-evening", { ...valid, guests: (i % 3) + 1 })),
    );
    const taken = results.filter((r) => r.status === 201).reduce((n, r) => n + r.body.guests, 0);
    expect(taken).toBeLessThanOrEqual(12);
    expect(await seatsLeft("riesling-evening")).toBe(12 - taken);
  });
});

describe("staff", () => {
  it("refuses bookings and cancelling without sign-in", async () => {
    expect((await request(app).get("/api/staff/bookings")).status).toBe(401);
    expect((await request(app).delete("/api/staff/bookings/KB-AAAAAA")).status).toBe(401);
  });

  it("rejects a wrong password with a field error and sets no session", async () => {
    const res = await request(app).post("/api/staff/login").send({ password: "wrong" });
    expect(res.status).toBe(401);
    expect(res.body.errors.password).toBeTruthy();
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("rejects a forged cookie", async () => {
    const res = await request(app).get("/api/staff/bookings").set("Cookie", "staff=forged");
    expect(res.status).toBe(401);
  });

  it("nobody can sign in when STAFF_PASSWORD is empty or unset", async () => {
    for (const staffPassword of ["", undefined]) {
      const open = createApp({ staffPassword });
      expect((await request(open).post("/api/staff/login").send({ password: "" })).status).toBe(401);
      expect((await request(open).post("/api/staff/login").send({})).status).toBe(401);
    }
  });

  it("lists bookings grouped by tasting, cancelling frees the seats", async () => {
    const a = await book("riesling-evening", valid);
    await book("riesling-evening", { name: "Ben", email: "ben@example.com", guests: 3 });
    await book("winter-tasting", { name: "Cara", email: "cara@example.com", guests: 1 });
    const cookie = await signIn();

    const list = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(list.status).toBe(200);
    const [riesling, red, winter] = list.body;
    expect(riesling.bookings.map((b: any) => [b.name, b.email, b.guests])).toEqual([
      ["Anna Weber", "anna@example.com", 2],
      ["Ben", "ben@example.com", 3],
    ]);
    expect(riesling.bookings[0].reference).toBe(a.body.reference);
    expect(red.bookings).toEqual([]);
    expect(winter.bookings).toHaveLength(1);

    const del = await request(app).delete(`/api/staff/bookings/${a.body.reference}`).set("Cookie", cookie);
    expect(del.status).toBe(204);
    expect(await seatsLeft("riesling-evening")).toBe(9);
    expect((await request(app).delete(`/api/staff/bookings/${a.body.reference}`).set("Cookie", cookie)).status).toBe(404);
  });

  it("logout ends the session", async () => {
    const cookie = await signIn();
    await request(app).post("/api/staff/logout").set("Cookie", cookie);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(401);
  });

  it("session cookie is HttpOnly and SameSite=Strict", async () => {
    const cookie = (await signIn()).join(";");
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
  });
});
