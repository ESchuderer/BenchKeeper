import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { existsSync } from "node:fs";
import { join } from "node:path";
import express from "express";
import type { ErrorRequestHandler, RequestHandler } from "express";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import { bookingSchema, type FieldErrors } from "../shared/booking.ts";
import { createStore } from "./store.ts";

const SESSION_MS = 12 * 60 * 60 * 1000;
const digest = (s: string) => createHash("sha256").update(s).digest();

export function createApp({ staffPassword, distDir }: { staffPassword?: string; distDir?: string } = {}) {
  const store = createStore();
  const sessions = new Map<string, number>(); // token -> expiry; lost on restart, staff just sign in again

  const tokenOf = (cookie = "") => /(?:^|;\s*)staff=([\w-]+)/.exec(cookie)?.[1];
  const hasSession = (cookie?: string) => {
    const token = tokenOf(cookie);
    const expires = token && sessions.get(token);
    if (token && expires && expires < Date.now()) sessions.delete(token);
    return !!expires && expires >= Date.now();
  };
  const requireStaff: RequestHandler = (req, res, next) =>
    hasSession(req.headers.cookie) ? next() : void res.status(401).json({ errors: { form: "Please sign in." } });

  const app = express();
  app.disable("x-powered-by");
  app.use(helmet());
  app.use(express.json({ limit: "10kb" }));

  app.get("/api/tastings", (_req, res) => void res.json(store.tastings()));

  app.post("/api/tastings/:id/bookings", (req, res) => {
    const parsed = bookingSchema.safeParse(req.body);
    if (!parsed.success) {
      const errors: FieldErrors = {};
      for (const issue of parsed.error.issues) {
        const field = issue.path[0];
        if ((field === "name" || field === "email" || field === "guests") && !errors[field]) errors[field] = issue.message;
      }
      if (!Object.keys(errors).length) errors.form = "Invalid request.";
      return void res.status(400).json({ errors });
    }
    const result = store.book(String(req.params.id), parsed.data);
    if (result.ok) return void res.status(201).json(result.confirmation);
    if (result.reason === "unknown-tasting") return void res.status(404).json({ errors: { form: "Tasting not found." } });
    const message = result.seatsLeft === 0 ? "Sorry, this tasting is fully booked." : `Only ${result.seatsLeft} ${result.seatsLeft === 1 ? "seat" : "seats"} left.`;
    res.status(409).json({ errors: { guests: message }, seatsLeft: result.seatsLeft });
  });

  const loginLimit = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 20,
    skipSuccessfulRequests: true,
    standardHeaders: true,
    legacyHeaders: false,
    message: { errors: { password: "Too many attempts. Please try again later." } },
  });
  app.post("/api/staff/login", loginLimit, (req, res) => {
    const given = typeof req.body?.password === "string" ? req.body.password : "";
    // An unset or empty STAFF_PASSWORD must never match, not even an empty guess.
    const ok = !!staffPassword && timingSafeEqual(digest(given), digest(staffPassword));
    if (!ok) return void res.status(401).json({ errors: { password: "That password is not correct." } });
    const token = randomBytes(24).toString("base64url");
    for (const [t, expires] of sessions) if (expires < Date.now()) sessions.delete(t);
    sessions.set(token, Date.now() + SESSION_MS);
    res.cookie("staff", token, { httpOnly: true, sameSite: "strict", maxAge: SESSION_MS, path: "/" }).status(204).end();
  });
  app.post("/api/staff/logout", (req, res) => {
    const token = tokenOf(req.headers.cookie);
    if (token) sessions.delete(token);
    res.clearCookie("staff", { path: "/" }).status(204).end();
  });
  app.get("/api/staff/bookings", requireStaff, (_req, res) => void res.json(store.staffView()));
  app.delete("/api/staff/bookings/:reference", requireStaff, (req, res) =>
    void res.status(store.cancel(String(req.params.reference)) ? 204 : 404).end(),
  );

  app.use("/api", (_req, res) => void res.status(404).json({ errors: { form: "Not found." } }));

  if (distDir && existsSync(join(distDir, "index.html"))) {
    app.use(express.static(distDir));
    app.use((req, res, next) => (req.method === "GET" && !req.path.includes(".") ? res.sendFile(join(distDir, "index.html")) : next()));
  }

  const onError: ErrorRequestHandler = (err, _req, res, _next) => {
    const status = err.status === 400 || err.status === 413 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ errors: { form: status === 500 ? "Something went wrong." : "Invalid request." } });
  };
  app.use(onError);
  return app;
}
