import { fileURLToPath } from "node:url";
import { createApp } from "./app.ts";

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");

createApp({ staffPassword, distDir: fileURLToPath(new URL("../dist", import.meta.url)) }).listen(port, () =>
  console.log(`Kieselbrunnen tastings on http://localhost:${port}`),
);
