import { randomInt } from "node:crypto";
import { TASTINGS } from "../shared/tastings.ts";
import type { Booking, Confirmation, StaffTasting, Tasting } from "../shared/booking.ts";

// shortcut: bookings live in memory and vanish on restart; swap this module for a file or DB if that matters.
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I

export type BookResult =
  | { ok: true; confirmation: Confirmation }
  | { ok: false; reason: "unknown-tasting" }
  | { ok: false; reason: "no-seats"; seatsLeft: number };

export function createStore() {
  const bookings = new Map<string, Booking & { tastingId: string }>();

  const seatsLeft = (tastingId: string, seats: number) => {
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === tastingId) taken += b.guests;
    return seats - taken;
  };

  const newReference = () => {
    let ref;
    do ref = "KB-" + Array.from({ length: 6 }, () => ALPHABET[randomInt(ALPHABET.length)]).join("");
    while (bookings.has(ref));
    return ref;
  };

  return {
    tastings(): Tasting[] {
      return TASTINGS.map((t) => ({ ...t, seatsLeft: seatsLeft(t.id, t.seats) }));
    },

    // Check and insert run synchronously with no await in between, so concurrent requests cannot overbook.
    book(tastingId: string, input: { name: string; email: string; guests: number }): BookResult {
      const tasting = TASTINGS.find((t) => t.id === tastingId);
      if (!tasting) return { ok: false, reason: "unknown-tasting" };
      const left = seatsLeft(tasting.id, tasting.seats);
      if (input.guests > left) return { ok: false, reason: "no-seats", seatsLeft: left };
      const reference = newReference();
      bookings.set(reference, { reference, tastingId, ...input });
      return {
        ok: true,
        confirmation: {
          reference,
          ...input,
          tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt },
          total: input.guests * tasting.pricePerGuest,
        },
      };
    },

    staffView(): StaffTasting[] {
      return TASTINGS.map((t) => ({
        ...t,
        seatsLeft: seatsLeft(t.id, t.seats),
        bookings: [...bookings.values()]
          .filter((b) => b.tastingId === t.id)
          .map(({ tastingId: _, ...b }) => b),
      }));
    },

    cancel(reference: string): boolean {
      return bookings.delete(reference);
    },
  };
}
