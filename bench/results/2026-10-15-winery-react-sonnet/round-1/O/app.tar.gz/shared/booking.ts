import { z } from "zod";

export const MAX_GUESTS = 8;
export const GUESTS_MESSAGE = `Choose between 1 and ${MAX_GUESTS} guests.`;

export const bookingSchema = z.object({
  name: z.string().trim().min(1, "Please enter your name.").max(100, "Please use at most 100 characters."),
  email: z.string().trim().max(254, "Please use at most 254 characters.").pipe(z.email("Please enter a valid email address.")),
  // The form sends text, JSON clients send numbers; digits-only strings are accepted, everything else is rejected.
  guests: z.preprocess(
    (v) => (typeof v === "string" && /^\d{1,3}$/.test(v) ? Number(v) : v),
    z.number({ error: GUESTS_MESSAGE }).int(GUESTS_MESSAGE).min(1, GUESTS_MESSAGE).max(MAX_GUESTS, GUESTS_MESSAGE),
  ),
});

export type Tasting = {
  id: string;
  title: string;
  startsAt: string; // local time at the winery, "YYYY-MM-DDTHH:mm"
  pricePerGuest: number; // EUR
  seats: number;
  seatsLeft: number;
};

export type Booking = {
  reference: string;
  name: string;
  email: string;
  guests: number;
};

export type Confirmation = Booking & {
  tasting: { id: string; title: string; startsAt: string };
  total: number; // EUR
};

export type FieldErrors = Partial<Record<"name" | "email" | "guests" | "password" | "form", string>>;

export type StaffTasting = Omit<Tasting, "seatsLeft"> & { seatsLeft: number; bookings: Booking[] };
