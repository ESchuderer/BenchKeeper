// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router";
import { App } from "./App.tsx";

const tastings = [
  { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00", pricePerGuest: 25, seats: 12, seatsLeft: 12 },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00", pricePerGuest: 32, seats: 8, seatsLeft: 0 },
  { id: "winter-tasting", title: "Winter Tasting", startsAt: "2026-12-05T17:00", pricePerGuest: 28, seats: 10, seatsLeft: 10 },
];

type Reply = { status?: number; body?: unknown };
let routes: Record<string, Reply | (() => Reply)>;
let calls: { method: string; url: string; body?: any }[];

beforeEach(() => {
  calls = [];
  routes = { "GET /api/tastings": { body: tastings } };
  vi.stubGlobal("fetch", async (url: string, init: RequestInit = {}) => {
    const method = init.method ?? "GET";
    calls.push({ method, url, body: init.body ? JSON.parse(init.body as string) : undefined });
    const r = routes[`${method} ${url}`] ?? { status: 404, body: {} };
    const { status = 200, body } = typeof r === "function" ? r() : r;
    return new Response(body === undefined ? null : JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
  });
});
afterEach(cleanup);

const open = (path: string) => render(<MemoryRouter initialEntries={[path]}><App /></MemoryRouter>);

describe("start page", () => {
  it("lists tastings with date, price and seats left, and marks full ones", async () => {
    open("/");
    const riesling = (await screen.findByRole("heading", { name: "Riesling Evening" })).closest("article")!;
    expect(within(riesling).getByText(/6 November 2026/)).toBeInTheDocument();
    expect(within(riesling).getByText(/18:00/)).toBeInTheDocument();
    expect(within(riesling).getByText(/EUR 25/)).toBeInTheDocument();
    expect(within(riesling).getByText("12 seats left")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Book Riesling Evening" })).toHaveAttribute("href", "/book/riesling-evening");

    const full = screen.getByRole("heading", { name: "Red Wine Cellar Tour" }).closest("article")!;
    expect(within(full).getByText("Fully booked")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Red Wine Cellar Tour" })).toBeNull();
  });

  it("shows an error with a retry when the tastings cannot be loaded", async () => {
    routes["GET /api/tastings"] = { status: 500, body: {} };
    open("/");
    expect(await screen.findByRole("alert")).toHaveTextContent(/could not load/i);
    expect(screen.getByRole("button", { name: "Try again" })).toBeInTheDocument();
  });
});

describe("booking form", () => {
  it("shows errors next to the fields and sends nothing when input is invalid", async () => {
    open("/book/riesling-evening");
    await userEvent.click(await screen.findByRole("button", { name: "Book" }));
    const name = screen.getByLabelText("Name");
    expect(name).toBeInvalid();
    expect(name).toHaveAccessibleDescription(/enter your name/i);
    expect(screen.getByLabelText("Email")).toHaveAccessibleDescription(/valid email/i);
    expect(calls.filter((c) => c.method === "POST")).toHaveLength(0);

    await userEvent.clear(screen.getByLabelText("Guests"));
    await userEvent.type(screen.getByLabelText("Guests"), "9");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(screen.getByLabelText("Guests")).toHaveAccessibleDescription(/between 1 and 8/i);
  });

  it("shows the server's seats error next to Guests", async () => {
    routes["POST /api/tastings/riesling-evening/bookings"] = { status: 409, body: { errors: { guests: "Only 2 seats left." }, seatsLeft: 2 } };
    open("/book/riesling-evening");
    await userEvent.type(await screen.findByLabelText("Name"), "Anna");
    await userEvent.type(screen.getByLabelText("Email"), "anna@example.com");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByLabelText("Guests")).toHaveAccessibleDescription(/Only 2 seats left/);
  });

  it("confirms the booking", async () => {
    routes["POST /api/tastings/riesling-evening/bookings"] = {
      status: 201,
      body: { reference: "KB-ABC234", name: "Anna", email: "anna@example.com", guests: 2, total: 50, tasting: tastings[0] },
    };
    open("/book/riesling-evening");
    await userEvent.type(await screen.findByLabelText("Name"), "Anna");
    await userEvent.type(screen.getByLabelText("Email"), "anna@example.com");
    await userEvent.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    const main = screen.getByRole("main");
    expect(main).toHaveTextContent("Riesling Evening");
    expect(main).toHaveTextContent(/2 guests/);
    expect(main).toHaveTextContent("EUR 50");
    expect(main).toHaveTextContent("KB-ABC234");
    expect(calls.find((c) => c.method === "POST")!.body).toEqual({ name: "Anna", email: "anna@example.com", guests: 2 });
  });

  it("offers no form for a fully booked tasting or an unknown one", async () => {
    open("/book/red-wine-cellar-tour");
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Book" })).toBeNull();
    cleanup();
    open("/book/nope");
    expect(await screen.findByText(/could not find/i)).toBeInTheDocument();
  });
});

describe("staff page", () => {
  const staffList = (bookings: unknown[]) => [{ ...tastings[0], bookings }, { ...tastings[1], bookings: [] }, { ...tastings[2], bookings: [] }];

  it("shows the sign-in form and an error for a wrong password", async () => {
    routes["GET /api/staff/bookings"] = { status: 401, body: {} };
    routes["POST /api/staff/login"] = { status: 401, body: { errors: { password: "That password is not correct." } } };
    open("/staff");
    await userEvent.type(await screen.findByLabelText("Password"), "nope");
    await userEvent.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByLabelText("Password")).toHaveAccessibleDescription(/not correct/);
  });

  it("lists bookings by tasting and cancels one", async () => {
    let bookings = [{ reference: "KB-ABC234", name: "Anna Weber", email: "anna@example.com", guests: 2 }];
    routes["GET /api/staff/bookings"] = () => ({ body: staffList(bookings) });
    routes["DELETE /api/staff/bookings/KB-ABC234"] = () => { bookings = []; return { status: 204 }; };
    open("/staff");
    const group = (await screen.findByRole("heading", { name: /Riesling Evening/ })).closest("section")!;
    expect(group).toHaveTextContent("Anna Weber");
    expect(group).toHaveTextContent("anna@example.com");
    expect(group).toHaveTextContent("KB-ABC234");
    expect(screen.getAllByText(/no bookings/i)).toHaveLength(2);
    await userEvent.click(within(group).getByRole("button", { name: "Cancel" }));
    expect(await screen.findAllByText(/no bookings/i)).toHaveLength(3);
    expect(calls.some((c) => c.method === "DELETE")).toBe(true);
  });
});
