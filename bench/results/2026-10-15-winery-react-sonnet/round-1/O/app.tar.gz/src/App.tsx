import { Link, Route, Routes } from "react-router";
import { Home } from "./Home.tsx";
import { BookingPage } from "./BookingPage.tsx";
import { Staff } from "./Staff.tsx";

export function App() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b-4 border-wine bg-parchment">
        <div className="mx-auto flex max-w-4xl flex-col gap-1 px-4 py-5 sm:flex-row sm:items-baseline sm:justify-between">
          <Link to="/" className="font-serif text-2xl font-bold text-wine-dark no-underline sm:text-3xl">
            Weingut Kieselbrunnen
          </Link>
          <p className="text-sm text-muted">Family winery · Wine tastings</p>
        </div>
      </header>
      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/book/:id" element={<BookingPage />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<p>Page not found. <Link to="/" className="underline">Back to the tastings</Link></p>} />
        </Routes>
      </main>
      <footer className="border-t border-line bg-parchment py-5 text-center text-sm text-muted">
        Weingut Kieselbrunnen · <Link to="/staff" className="underline">Staff</Link>
      </footer>
    </div>
  );
}
