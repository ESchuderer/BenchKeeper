import { useState } from "react";
import { Link, useParams } from "react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { bookingSchema, MAX_GUESTS, type Confirmation, type FieldErrors } from "../shared/booking.ts";
import { api, eur, formatWhen } from "./api.ts";
import { Field, Notice } from "./ui.tsx";
import { useTastings } from "./useTastings.ts";

type Values = { name: string; email: string; guests: string };

export function BookingPage() {
  const { id } = useParams();
  const { tastings, failed, reload } = useTastings();
  const [confirmation, setConfirmation] = useState<Confirmation>();
  const tasting = tastings?.find((t) => t.id === id);

  if (confirmation) return <Confirmed c={confirmation} />;
  if (failed && !tastings) return <Notice kind="error"><p>We could not load this tasting.</p><button className="btn-quiet mt-3" onClick={reload}>Try again</button></Notice>;
  if (!tastings) return <p className="text-muted">Loading…</p>;
  if (!tasting) return <Notice kind="error">We could not find that tasting. <Link to="/" className="underline">See all tastings</Link></Notice>;

  const when = formatWhen(tasting.startsAt);
  return (
    <>
      <Link to="/" className="text-sm underline">← All tastings</Link>
      <h1 className="mt-3 text-3xl font-bold">{tasting.title}</h1>
      <p className="mt-1">{when.date}, {when.time}</p>
      <p className="text-muted">{eur(tasting.pricePerGuest)} per guest</p>
      {tasting.seatsLeft <= 0 ? (
        <div className="mt-6"><Notice kind="error">This tasting is fully booked. <Link to="/" className="underline">See other tastings</Link></Notice></div>
      ) : (
        <BookingForm tastingId={tasting.id} seatsLeft={tasting.seatsLeft} onDone={setConfirmation} onStale={reload} />
      )}
    </>
  );
}

function BookingForm({ tastingId, seatsLeft, onDone, onStale }: { tastingId: string; seatsLeft: number; onDone: (c: Confirmation) => void; onStale: () => void }) {
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<Values>({
    resolver: zodResolver(bookingSchema) as never,
    defaultValues: { name: "", email: "", guests: String(Math.min(2, seatsLeft)) },
  });
  const [formError, setFormError] = useState<string>();

  const submit = handleSubmit(async (values) => {
    setFormError(undefined);
    try {
      const res = await api<Confirmation & { seatsLeft?: number }>(`/api/tastings/${tastingId}/bookings`, { method: "POST", body: values });
      if (res.status === 201) return onDone(res.data as Confirmation);
      const fieldErrors: FieldErrors = res.data.errors ?? {};
      (["name", "email", "guests"] as const).forEach((f) => fieldErrors[f] && setError(f, { message: fieldErrors[f] }));
      if (res.status === 409) onStale(); // seats changed under us: refresh the count
      else if (!fieldErrors.name && !fieldErrors.email && !fieldErrors.guests) setFormError(fieldErrors.form ?? "Something went wrong. Please try again.");
    } catch {
      setFormError("We could not reach the winery. Please check your connection and try again.");
    }
  });

  return (
    <form onSubmit={submit} noValidate className="mt-6 grid max-w-xl gap-5 rounded-lg border border-line bg-white p-5 shadow-sm">
      {formError && <Notice kind="error">{formError}</Notice>}
      <Field label="Name" error={errors.name?.message}>
        {(p) => <input {...p} {...register("name")} className="field" autoComplete="name" />}
      </Field>
      <Field label="Email" error={errors.email?.message}>
        {(p) => <input {...p} {...register("email")} className="field" type="email" autoComplete="email" />}
      </Field>
      <Field label="Guests" error={errors.guests?.message} hint={`${seatsLeft} seats left (up to ${Math.min(MAX_GUESTS, seatsLeft)} per booking)`}>
        {(p) => <input {...p} {...register("guests")} className="field" type="number" inputMode="numeric" min={1} max={MAX_GUESTS} />}
      </Field>
      <button type="submit" className="btn" disabled={isSubmitting}>{isSubmitting ? "Booking…" : "Book"}</button>
    </form>
  );
}

function Confirmed({ c }: { c: Confirmation }) {
  const when = formatWhen(c.tasting.startsAt);
  return (
    <section className="max-w-xl rounded-lg border-2 border-olive bg-olive-soft p-6">
      <h1 className="text-3xl font-bold text-olive">
        <span aria-hidden="true">✓ </span>Booking confirmed
      </h1>
      <p className="mt-2">Thank you, {c.name}. We look forward to seeing you.</p>
      <dl className="mt-5 grid grid-cols-[auto_1fr] gap-x-5 gap-y-2">
        <dt className="font-semibold">Tasting</dt><dd>{c.tasting.title}, {when.date}, {when.time}</dd>
        <dt className="font-semibold">Guests</dt><dd>{c.guests} {c.guests === 1 ? "guest" : "guests"}</dd>
        <dt className="font-semibold">Total price</dt><dd>{eur(c.total)}</dd>
        <dt className="font-semibold">Booking reference</dt><dd className="font-mono font-bold tracking-wider">{c.reference}</dd>
      </dl>
      <p className="mt-5 text-sm text-muted">Please keep your reference and mention it when you arrive.</p>
      <Link to="/" className="btn-quiet mt-5">Back to the tastings</Link>
    </section>
  );
}
