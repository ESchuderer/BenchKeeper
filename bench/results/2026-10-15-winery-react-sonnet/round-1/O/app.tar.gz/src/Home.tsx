import { Link } from "react-router";
import { eur, formatWhen } from "./api.ts";
import { Notice } from "./ui.tsx";
import { useTastings } from "./useTastings.ts";

export function Home() {
  const { tastings, failed, reload } = useTastings();
  return (
    <>
      <section className="mb-8">
        <h1 className="text-3xl font-bold sm:text-4xl">Join us for a tasting</h1>
        <p className="mt-2 max-w-prose text-lg text-muted">
          Come to the cellar, taste what our family has grown and ask us anything. Choose a tasting and reserve your seats.
        </p>
      </section>
      {failed && (
        <Notice kind="error">
          <p>We could not load the tastings.</p>
          <button className="btn-quiet mt-3" onClick={reload}>Try again</button>
        </Notice>
      )}
      {!tastings && !failed && <p className="text-muted">Loading tastings…</p>}
      <div className="grid gap-5">
        {tastings?.map((t) => {
          const when = formatWhen(t.startsAt);
          const full = t.seatsLeft <= 0;
          return (
            <article key={t.id} className={`rounded-lg border border-line p-5 shadow-sm sm:flex sm:items-center sm:justify-between sm:gap-6 ${full ? "bg-parchment opacity-90" : "bg-white"}`}>
              <div>
                <h2 className="text-2xl font-bold">{t.title}</h2>
                <p className="mt-1">
                  <time dateTime={t.startsAt}>{when.date}, {when.time}</time>
                </p>
                <p className="mt-1 text-muted">{eur(t.pricePerGuest)} per guest</p>
                <p className="mt-3 flex flex-wrap items-center gap-2">
                  {full && <span className="rounded-full bg-wine-dark px-3 py-1 text-sm font-semibold text-cream">Fully booked</span>}
                  <span className={`rounded-full px-3 py-1 text-sm font-semibold ${full ? "bg-line text-ink" : "bg-olive-soft text-olive"}`}>
                    {t.seatsLeft} seats left
                  </span>
                </p>
              </div>
              {!full && (
                <Link to={`/book/${t.id}`} className="btn mt-4 w-full sm:mt-0 sm:w-auto">
                  Book {t.title}
                </Link>
              )}
            </article>
          );
        })}
      </div>
    </>
  );
}
