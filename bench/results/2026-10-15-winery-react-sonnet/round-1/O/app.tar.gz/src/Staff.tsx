import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import type { StaffTasting } from "../shared/booking.ts";
import { api, eur, formatWhen } from "./api.ts";
import { Field, Notice } from "./ui.tsx";

export function Staff() {
  const [list, setList] = useState<StaffTasting[] | null>();
  const load = useCallback(async () => {
    const r = await api<StaffTasting[]>("/api/staff/bookings").catch(() => null);
    setList(r?.status === 200 ? (r.data as unknown as StaffTasting[]) : null);
  }, []);
  useEffect(() => void load(), [load]);

  if (list === undefined) return <p className="text-muted">Loading…</p>;
  if (list === null) return <SignIn onDone={load} />;
  return <Overview list={list} reload={load} signOut={() => api("/api/staff/logout", { method: "POST" }).then(() => setList(null))} />;
}

function SignIn({ onDone }: { onDone: () => void }) {
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<{ password: string }>();
  const submit = handleSubmit(async ({ password }) => {
    const r = await api("/api/staff/login", { method: "POST", body: { password } }).catch(() => null);
    if (r?.status === 204) return onDone();
    setError("password", { message: r?.data.errors?.password ?? "We could not sign you in. Please try again." });
  });
  return (
    <>
      <h1 className="text-3xl font-bold">Staff</h1>
      <form onSubmit={submit} noValidate className="mt-6 grid max-w-sm gap-5 rounded-lg border border-line bg-white p-5 shadow-sm">
        <Field label="Password" error={errors.password?.message}>
          {(p) => <input {...p} {...register("password")} className="field" type="password" autoComplete="current-password" />}
        </Field>
        <button type="submit" className="btn" disabled={isSubmitting}>Sign in</button>
      </form>
    </>
  );
}

function Overview({ list, reload, signOut }: { list: StaffTasting[]; reload: () => void; signOut: () => void }) {
  const [error, setError] = useState<string>();
  const cancel = async (reference: string) => {
    setError(undefined);
    const r = await api(`/api/staff/bookings/${reference}`, { method: "DELETE" }).catch(() => null);
    if (r && r.status !== 204 && r.status !== 404) setError("The booking could not be cancelled. Please try again.");
    else if (!r) setError("We could not reach the server. Please try again.");
    reload();
  };
  return (
    <>
      <div className="flex items-center justify-between gap-4">
        <h1 className="text-3xl font-bold">Bookings</h1>
        <button className="btn-quiet" onClick={signOut}>Sign out</button>
      </div>
      {error && <div className="mt-4"><Notice kind="error">{error}</Notice></div>}
      <div className="mt-6 grid gap-6">
        {list.map((t) => {
          const when = formatWhen(t.startsAt);
          return (
            <section key={t.id} className="rounded-lg border border-line bg-white p-5 shadow-sm">
              <h2 className="text-xl font-bold">{t.title} <span className="block text-base font-normal text-muted">{when.date}, {when.time}</span></h2>
              <p className="text-sm text-muted">{t.seats - t.seatsLeft} of {t.seats} seats booked · {eur(t.pricePerGuest)} per guest</p>
              {t.bookings.length === 0 ? (
                <p className="mt-3 text-muted">No bookings yet.</p>
              ) : (
                <ul className="mt-3 divide-y divide-line">
                  {t.bookings.map((b) => (
                    <li key={b.reference} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center sm:justify-between">
                      <div className="min-w-0">
                        <p id={`b-${b.reference}`} className="font-semibold">{b.name}</p>
                        <p className="break-all text-sm">{b.email}</p>
                        <p className="text-sm text-muted">{b.guests} {b.guests === 1 ? "guest" : "guests"} · Ref <span className="font-mono font-bold">{b.reference}</span></p>
                      </div>
                      <button className="btn-quiet" aria-describedby={`b-${b.reference}`} onClick={() => cancel(b.reference)}>Cancel</button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          );
        })}
      </div>
    </>
  );
}
