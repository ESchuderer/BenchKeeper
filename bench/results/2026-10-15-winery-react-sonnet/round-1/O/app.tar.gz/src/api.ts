import type { FieldErrors } from "../shared/booking.ts";

export type ApiResult<T> = { status: number; data: T & { errors?: FieldErrors } };

const parse = (text: string) => {
  try {
    return text ? JSON.parse(text) : {};
  } catch {
    return {}; // e.g. an HTML error page from a proxy
  }
};

export async function api<T = unknown>(path: string, init: { method?: string; body?: unknown } = {}): Promise<ApiResult<T>> {
  const res = await fetch(path, {
    method: init.method,
    headers: init.body ? { "Content-Type": "application/json" } : undefined,
    body: init.body ? JSON.stringify(init.body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, data: parse(text) };
}

const date = new Intl.DateTimeFormat("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
const time = new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "UTC" });

// startsAt is wall-clock time at the winery; formatting it as UTC avoids any browser time zone shift.
export const formatWhen = (startsAt: string) => {
  const d = new Date(startsAt + ":00Z");
  return { date: date.format(d), time: time.format(d) };
};

export const eur = (n: number) => `EUR ${n}`;
