import { useId } from "react";
import type { ReactNode } from "react";

export const ErrorText = ({ id, children }: { id: string; children?: ReactNode }) =>
  children ? (
    <p id={id} className="error-text">
      <span aria-hidden="true">⚠</span>
      <span>{children}</span>
    </p>
  ) : null;

type FieldProps = { label: string; error?: string; hint?: string; children: (p: { id: string; "aria-invalid": boolean; "aria-describedby"?: string }) => ReactNode };

// A labelled control whose error and hint text are linked to it for assistive technology.
export function Field({ label, error, hint, children }: FieldProps) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [error && errorId, hint && hintId].filter(Boolean).join(" ") || undefined;
  return (
    <div>
      <label htmlFor={id} className="block font-semibold">{label}</label>
      {children({ id, "aria-invalid": !!error, "aria-describedby": describedBy })}
      {hint && <p id={hintId} className="mt-1 text-sm text-muted">{hint}</p>}
      <ErrorText id={errorId}>{error}</ErrorText>
    </div>
  );
}

export const Notice = ({ kind, children }: { kind: "error" | "info"; children: ReactNode }) => (
  <div
    role={kind === "error" ? "alert" : "status"}
    className={`rounded-md border-l-4 p-4 ${kind === "error" ? "border-danger bg-danger-soft text-danger" : "border-wine bg-parchment text-ink"}`}
  >
    {children}
  </div>
);
