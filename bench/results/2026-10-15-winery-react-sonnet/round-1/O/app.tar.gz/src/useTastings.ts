import { useCallback, useEffect, useState } from "react";
import type { Tasting } from "../shared/booking.ts";
import { api } from "./api.ts";

export function useTastings() {
  const [tastings, setTastings] = useState<Tasting[]>();
  const [failed, setFailed] = useState(false);
  const load = useCallback(() => {
    setFailed(false);
    api<Tasting[]>("/api/tastings").then(
      (r) => (r.status === 200 ? setTastings(r.data as unknown as Tasting[]) : setFailed(true)),
      () => setFailed(true),
    );
  }, []);
  useEffect(load, [load]);
  return { tastings, failed, reload: load };
}
