# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings; staff see and cancel bookings at `/staff`.

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start   # PORT defaults to 3000
npm test
```

- Without `STAFF_PASSWORD` nobody can sign in to `/staff`.
- Bookings are kept in memory and are lost when the server restarts.
- Stack: Express 5 API, React + react-router + react-hook-form/zod, Tailwind CSS, Vite. Spec and plan: `specs/001-tasting-bookings/`.
