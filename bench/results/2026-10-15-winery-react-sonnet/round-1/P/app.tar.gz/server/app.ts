import express, { type NextFunction, type Request, type Response } from "express";
import cookieParser from "cookie-parser";
import { randomBytes, timingSafeEqual, createHash } from "node:crypto";
import { resolve } from "node:path";
import { bookingSchema } from "../shared/schema.ts";
import { createStore, type Store } from "./store.ts";

const dist = resolve(import.meta.dirname, "../dist");
const digest = (s: string) => createHash("sha256").update(s).digest();

export function createApp({ staffPassword, store = createStore() }: { staffPassword?: string; store?: Store } = {}) {
  // shortcut: no login rate limit, sessions never expire (cleared on restart), cookie not `Secure`; upgrade before exposing /staff beyond a trusted network or without HTTPS.
  const sessions = new Set<string>();
  const app = express();
  app.disable("x-powered-by");
  app.use(express.json({ limit: "10kb" }), cookieParser());

  const api = express.Router();

  api.get("/tastings", (_req, res) => res.json(store.tastings()));
  api.get("/tastings/:id", (req, res) => {
    const t = store.tasting(req.params.id);
    t ? res.json(t) : res.status(404).json({ error: "Tasting not found" });
  });

  const withTasting = (b: NonNullable<ReturnType<Store["booking"]>>) => {
    const { tastingId, ...rest } = b;
    return { ...rest, tasting: store.tasting(tastingId) };
  };

  api.post("/bookings", (req, res) => {
    const body = req.body ?? {};
    const parsed = bookingSchema.safeParse(body);
    if (!parsed.success) {
      const errors: Record<string, string> = {};
      for (const i of parsed.error.issues) errors[String(i.path[0] ?? "form")] ??= i.message;
      return res.status(400).json({ errors });
    }
    const result = store.book(String(body.tastingId), parsed.data);
    if ("booking" in result) return res.status(201).json(withTasting(result.booking));
    if (result.error === "unknown-tasting") return res.status(404).json({ error: "Tasting not found" });
    const n = result.seatsLeft;
    res.status(400).json({
      errors: { guests: n === 0 ? "Sorry, this tasting is fully booked" : `Only ${n} seat${n === 1 ? "" : "s"} left` },
    });
  });

  api.get("/bookings/:reference", (req, res) => {
    const b = store.booking(req.params.reference);
    if (!b) return res.status(404).json({ error: "Booking not found" });
    const { email: _private, ...publicView } = withTasting(b); // the reference is the only secret here: never expose the email
    res.json(publicView);
  });

  // Fails closed: with no STAFF_PASSWORD configured nobody can sign in.
  api.post("/staff/login", (req, res) => {
    const given = req.body?.password;
    const ok = !!staffPassword && typeof given === "string" && timingSafeEqual(digest(given), digest(staffPassword));
    if (!ok) return res.status(401).json({ errors: { password: "Wrong password" } });
    const token = randomBytes(32).toString("hex");
    sessions.add(token);
    res.cookie("staff", token, { httpOnly: true, sameSite: "strict", path: "/" }).sendStatus(204);
  });
  api.post("/staff/logout", (req, res) => {
    sessions.delete(req.cookies?.staff);
    res.clearCookie("staff", { path: "/" }).sendStatus(204);
  });

  const staffOnly = (req: Request, res: Response, next: NextFunction) =>
    sessions.has(req.cookies?.staff) ? next() : res.status(401).json({ error: "Staff sign-in required" });
  api.get("/staff/bookings", staffOnly, (_req, res) => res.json(store.byTasting()));
  api.get("/staff/session", staffOnly, (_req, res) => res.sendStatus(204));
  api.delete("/staff/bookings/:reference", staffOnly, (req, res) =>
    store.cancel(String(req.params.reference)) ? res.sendStatus(204) : res.status(404).json({ error: "Booking not found" }));

  api.use((_req, res) => res.status(404).json({ error: "Not found" }));
  app.use("/api", api);

  app.use(express.static(dist));
  app.get("/{*path}", (_req, res) => res.sendFile(resolve(dist, "index.html")));

  app.use((err: { status?: number }, _req: Request, res: Response, _next: NextFunction) => {
    res.status(err.status && err.status < 500 ? err.status : 500).json({ error: "Request failed" });
  });
  return app;
}
