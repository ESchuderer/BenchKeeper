import { createApp } from "./app.ts";

const port = Number(process.env.PORT) || 3000;
if (!process.env.STAFF_PASSWORD) console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
createApp({ staffPassword: process.env.STAFF_PASSWORD }).listen(port, () => console.log(`Listening on http://localhost:${port}`));
