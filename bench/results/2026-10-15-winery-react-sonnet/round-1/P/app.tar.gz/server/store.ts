import { randomBytes } from "node:crypto";

export type Tasting = { id: string; title: string; startsAt: string; priceEur: number; capacity: number };
export type Booking = { reference: string; tastingId: string; name: string; email: string; guests: number; totalEur: number };

export const tastings: Tasting[] = [
  { id: "riesling-evening", title: "Riesling Evening", startsAt: "2026-11-06T18:00", priceEur: 25, capacity: 12 },
  { id: "red-wine-cellar-tour", title: "Red Wine Cellar Tour", startsAt: "2026-11-14T15:00", priceEur: 32, capacity: 8 },
  { id: "winter-tasting", title: "Winter Tasting", startsAt: "2026-12-05T17:00", priceEur: 28, capacity: 10 },
];

export function createStore() {
  const bookings = new Map<string, Booking>();
  const find = (id: string) => tastings.find((t) => t.id === id);
  const seatsLeft = (t: Tasting) =>
    t.capacity - [...bookings.values()].filter((b) => b.tastingId === t.id).reduce((n, b) => n + b.guests, 0);
  const view = (t: Tasting) => ({ ...t, seatsLeft: seatsLeft(t) });

  return {
    tastings: () => tastings.map(view),
    tasting: (id: string) => { const t = find(id); return t && view(t); },
    booking: (reference: string) => bookings.get(reference),
    // Check and insert happen synchronously, so concurrent requests cannot oversell.
    book(tastingId: string, input: { name: string; email: string; guests: number }):
      | { booking: Booking }
      | { error: "unknown-tasting" }
      | { error: "no-seats"; seatsLeft: number } {
      const t = find(tastingId);
      if (!t) return { error: "unknown-tasting" };
      const left = seatsLeft(t);
      if (input.guests > left) return { error: "no-seats", seatsLeft: left };
      let reference: string;
      do reference = "KB-" + randomBytes(5).toString("hex").toUpperCase(); while (bookings.has(reference));
      const booking = { reference, tastingId, ...input, totalEur: input.guests * t.priceEur };
      bookings.set(reference, booking);
      return { booking };
    },
    cancel: (reference: string) => bookings.delete(reference),
    byTasting: () => tastings.map((t) => ({
      tasting: view(t),
      bookings: [...bookings.values()].filter((b) => b.tastingId === t.id),
    })),
  };
}
export type Store = ReturnType<typeof createStore>;
