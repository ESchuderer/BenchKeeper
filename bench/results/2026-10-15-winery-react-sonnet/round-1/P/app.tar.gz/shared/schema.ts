import { z } from "zod";

export const bookingSchema = z.object({
  name: z.string().trim().min(1, "Please enter your name").max(100, "Name is too long (max 100 characters)"),
  email: z.string().trim().max(200, "Email is too long").pipe(z.email("Please enter a valid email address")),
  guests: z.coerce
    .number<unknown>("Please enter the number of guests")
    .int("Guests must be a whole number")
    .min(1, "Book at least 1 guest")
    .max(8, "You can book at most 8 guests"),
});
export type BookingInput = z.input<typeof bookingSchema>;
