# API contract (JSON)

| Method & path | Auth | Success | Errors |
|---|---|---|---|
| `GET /api/tastings` | – | 200 `[{id,title,startsAt,priceEur,capacity,seatsLeft}]` | |
| `GET /api/tastings/:id` | – | 200 tasting | 404 |
| `POST /api/bookings` `{tastingId,name,email,guests}` | – | 201 `{reference,tasting,name,email,guests,totalEur}` | 400 `{errors:{field:message}}` (also for too few seats: `errors.guests`), 404 unknown tasting |
| `GET /api/bookings/:reference` | – | 200 booking (for the confirmation page) | 404 |
| `POST /api/staff/login` `{password}` | – | 204 + session cookie | 401 `{errors:{password}}` |
| `POST /api/staff/logout` | – | 204 | |
| `GET /api/staff/bookings` | staff | 200 `[{tasting, bookings:[{reference,name,email,guests}]}]` | 401 |
| `DELETE /api/staff/bookings/:reference` | staff | 204 | 401, 404 |

Any other `/api/*` path returns 404 JSON. Other GETs return `index.html` (SPA routes).
