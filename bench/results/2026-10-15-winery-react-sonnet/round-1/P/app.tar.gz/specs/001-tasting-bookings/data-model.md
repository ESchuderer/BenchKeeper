# Data Model

**Tasting**: `id` (slug, e.g. `riesling-evening`), `title`, `startsAt` (local `YYYY-MM-DDTHH:mm`), `priceEur` (integer), `capacity`. `seatsLeft = capacity − Σ guests of active bookings`. Derived, never stored.

**Booking**: `reference` (`KB- + 10 hex characters`, unique), `tastingId`, `name` (trimmed, 1–100), `email` (valid, ≤200), `guests` (integer 1–8), `totalEur = guests × priceEur`.

Lifecycle: created only if `guests ≤ seatsLeft`; cancel deletes it, which frees its seats; cancelling an unknown reference returns 404.
