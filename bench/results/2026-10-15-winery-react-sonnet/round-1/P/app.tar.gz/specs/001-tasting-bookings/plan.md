# Implementation Plan: Wine Tasting Bookings

**Branch**: `001-tasting-bookings` | **Date**: 2026-10-15 | **Spec**: [spec.md](spec.md)

## Summary

One Node process: an Express 5 JSON API (`/api`) with in-memory tastings and bookings, which also serves the built React single-page app. Guests use the public pages; staff use `/staff`, guarded by a password from `STAFF_PASSWORD` and an httpOnly session cookie.

## Technical Context

**Language/Version**: TypeScript, Node.js 22
**Primary Dependencies**: Express 5, cookie-parser, zod (shared validation); React 19, react-router, react-hook-form with @hookform/resolvers/zod; Vite; Tailwind CSS 4
**Storage**: In memory (fresh start, no bookings); no external services
**Testing**: vitest + supertest (API), vitest + Testing Library (UI)
**Target Platform**: Linux server, modern browsers incl. phones
**Project Type**: web application, single package, server serves the SPA
**Performance Goals**: not a concern at this scale
**Constraints**: `npm install && npm run build && npm start`; PORT default 3000
**Scale/Scope**: 3 tastings, one winery, tens of bookings

## Constitution Check

The constitution is an unfilled template: no gates apply. Own principles: test first, validate at the server (never trust the form), fail closed on staff auth.

## Project Structure

### Documentation

```text
specs/001-tasting-bookings/
├── spec.md  plan.md  research.md  data-model.md  quickstart.md
├── contracts/api.md
└── tasks.md
```

### Source Code

```text
server/
├── app.ts          # createApp(): API routes + static SPA + fallback
├── store.ts        # tastings, bookings, seat accounting
├── index.ts        # reads PORT, starts the server
shared/schema.ts    # zod booking schema, used by form and server
src/                # React app: main, App (routes), pages/{Tastings,BookingForm,Confirmation,Staff}, styles.css
tests/              # api.test.ts, ui.test.tsx
```

**Structure Decision**: a single package; the server runs TypeScript via `tsx` (a dependency), so `npm run build` is just `vite build`.

## Key decisions

- Seat check and booking are one synchronous step in the store, which is race-free in a single Node process.
- The server computes the price; the client never sends it.
- Staff sessions are random tokens held in memory and sent as an httpOnly, SameSite=Strict cookie. The password is compared in constant time. With `STAFF_PASSWORD` unset, sign-in always fails.
- User-supplied text is rendered by React, which escapes it.
- Shortcut: no login rate limiting; upgrade if the site is exposed to the public internet.
