# Quickstart

```sh
npm install && npm run build
STAFF_PASSWORD=secret PORT=3000 npm start
npm test
```

Check:
1. Open http://localhost:3000. Three tastings show "12 seats left", "8 seats left" and "10 seats left".
2. "Book Riesling Evening", then book 2 guests. The page shows "Booking confirmed", EUR 50 and a reference, and the list shows "10 seats left".
3. Submit with 9 guests or a bad email. Errors appear next to the fields.
4. Open /staff and sign in with `secret`. The booking is listed under Riesling Evening. Click "Cancel", and the start page shows "12 seats left" again.
