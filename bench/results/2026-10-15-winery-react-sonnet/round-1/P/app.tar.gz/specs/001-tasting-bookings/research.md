# Research

- **Server**: Express 5 — the most established option, and it handles async errors natively. Alternatives: Fastify, Next.js (heavier than needed).
- **UI build**: Vite + React, with react-router for `/`, `/book/:id`, `/confirmation/:ref`, `/staff`.
- **Forms**: react-hook-form with a zod resolver. The same zod schema validates on the server, so rules are written once.
- **Styling**: Tailwind CSS 4 through its Vite plugin. A small set of design tokens (wine/cream palette, serif headings) gives one coherent look. Mobile-first.
- **Storage**: in memory. The spec allows it, and no persistence layer is needed.
- **Auth**: one shared password and an opaque session cookie. JWT is unnecessary because there is a single server.
- **TS execution**: `tsx` runs the server, so there is no separate server build.
