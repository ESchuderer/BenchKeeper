# Feature Specification: Wine Tasting Bookings

**Feature Branch**: `001-tasting-bookings`
**Created**: 2026-10-15
**Status**: Draft
**Input**: Web app for Weingut Kieselbrunnen where guests book wine tastings online and staff see and cancel bookings.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Guest books a tasting (Priority: P1)

A guest opens the start page, sees the tastings with date, time, price and seats left, chooses one ("Book <title>"), fills in Name, Email and Guests (1 to 8), presses "Book" and sees a "Booking confirmed" page with the tasting, guest count, total price and booking reference.

**Why this priority**: This is the reason the site exists; it alone is a viable MVP.

**Independent Test**: Open the start page, book 2 guests for Riesling Evening, check the confirmation (total EUR 50, a reference) and that the list now shows "10 seats left".

**Acceptance Scenarios**:

1. **Given** a fresh start, **When** the guest opens the start page, **Then** three tastings are listed: Riesling Evening (2026-11-06 18:00, EUR 25, "12 seats left"), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, "8 seats left"), Winter Tasting (2026-12-05 17:00, EUR 28, "10 seats left").
2. **Given** the start page, **When** the guest chooses "Book Riesling Evening", **Then** a form with "Name", "Email", "Guests" and a "Book" button for that tasting is shown.
3. **Given** valid input of 3 guests for Winter Tasting, **When** the guest presses "Book", **Then** "Booking confirmed" is shown with the tasting, 3 guests, total EUR 84 and a booking reference, and the tasting shows "7 seats left".

---

### User Story 2 - Booking input is protected (Priority: P1)

Invalid input and overbooking are rejected with an error message next to the field concerned. Seats are never oversold, including when two guests book at the same time.

**Why this priority**: Overbooking a family winery's small tasting is the main business risk.

**Independent Test**: Submit the form empty, with a bad email, with 0 and 9 guests, and with more guests than seats left; each shows an error at its field and creates no booking.

**Acceptance Scenarios**:

1. **Given** the booking form, **When** Name is empty or blank, **Then** an error appears next to "Name".
2. **Given** the booking form, **When** Email is not a valid address, **Then** an error appears next to "Email".
3. **Given** the booking form, **When** Guests is not a whole number from 1 to 8, **Then** an error appears next to "Guests".
4. **Given** a tasting with 3 seats left, **When** a guest requests 4, **Then** an error next to "Guests" says only 3 seats are left and no booking is made.
5. **Given** a tasting with 0 seats left, **Then** the start page shows it as fully booked (no booking possible) and a direct request to book it is rejected.

---

### User Story 3 - Staff review and cancel bookings (Priority: P2)

Staff open `/staff`, sign in with the password, see all bookings grouped by tasting (name, email, guests, reference), and cancel a booking with "Cancel". The seats become available again.

**Why this priority**: Staff need to prepare each tasting and handle cancellations; guests can already book without it.

**Independent Test**: Make a booking, sign in on `/staff`, find it under its tasting, cancel it, and check the start page shows the seats again.

**Acceptance Scenarios**:

1. **Given** `/staff` and not signed in, **Then** only a "Password" field and "Sign in" button are shown, and no booking data.
2. **Given** a wrong password, **When** "Sign in" is pressed, **Then** an error is shown and no booking data is revealed.
3. **Given** the correct password, **Then** all bookings are shown grouped by tasting with name, email, guests and reference; tastings without bookings show an empty state.
4. **Given** a booking of 2 guests, **When** staff press "Cancel", **Then** it disappears from the list and the tasting's seats left increase by 2.

---

### User Story 4 - Looks like the winery's own site (Priority: P3)

All pages share one polished winery-style design, work on a phone, and show clear states for errors, success and fully booked tastings.

**Independent Test**: View every page at 375px width: no horizontal scrolling, readable text, tappable buttons.

**Acceptance Scenarios**:

1. **Given** a phone-sized screen, **Then** every page is fully usable without sideways scrolling.
2. **Given** a fully booked tasting, **Then** the list visibly marks it "Fully booked" and offers no booking link.

### Edge Cases

- Two guests book the last seats at the same moment: only one succeeds, the other sees a seats-left error.
- A booking for an unknown tasting is rejected.
- A cancelled booking cannot be cancelled twice, and a stale staff page shows an error rather than freeing seats twice.
- Staff pages and staff actions are refused without a valid sign-in, including direct requests.
- Very long or markup-containing names are shown as plain text.
- Reloading the confirmation page does not create a second booking.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The start page MUST list every tasting with title, date and time, price per guest and "<n> seats left".
- **FR-002**: Each tasting MUST offer a link "Book <tasting title>" that opens a booking form for it with fields "Name", "Email", "Guests" and a "Book" button.
- **FR-003**: Name MUST be non-blank; Email MUST be a valid address; Guests MUST be a whole number from 1 to 8.
- **FR-004**: A booking MUST NOT take more seats than are left, even under concurrent requests; this MUST also be enforced for requests not made through the form.
- **FR-005**: Invalid input MUST be rejected with an error message shown next to the field concerned; entered values MUST be kept.
- **FR-006**: A successful booking MUST show a confirmation with heading "Booking confirmed", the tasting, number of guests, total price (guests × price) and a unique booking reference.
- **FR-007**: A fully booked tasting MUST be clearly marked and not bookable.
- **FR-008**: `/staff` MUST require a password, taken from the `STAFF_PASSWORD` environment variable, via a "Password" field and "Sign in" button; wrong passwords MUST show an error.
- **FR-009**: Signed-in staff MUST see all bookings grouped by tasting with name, email, guests and reference.
- **FR-010**: Staff MUST be able to cancel a booking with a "Cancel" button; cancelling MUST free its seats.
- **FR-011**: Booking data and staff actions MUST NOT be available without staff sign-in.
- **FR-012**: The app MUST start with no bookings and need no external services.
- **FR-013**: The interface MUST be in English, share a coherent winery-style design, and be usable on phone screens.

### Key Entities

- **Tasting**: title, date and time, price per guest (EUR), total seats; seats left is derived from active bookings.
- **Booking**: reference, tasting, guest name, email, number of guests, total price.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A guest can complete a booking from the start page in under 1 minute.
- **SC-002**: Across any number of bookings and cancellations, seats booked for a tasting never exceed its capacity, and seats left always equals capacity minus active guests.
- **SC-003**: 100% of invalid submissions show an error at the field concerned and create no booking.
- **SC-004**: Staff can find and cancel a booking in under 30 seconds after signing in.
- **SC-005**: Every page is usable at 375px width without horizontal scrolling.

## Assumptions

- Total price is guests × price per guest, in EUR; no payment is taken online.
- Tastings are fixed (the three listed); staff do not edit tastings.
- One shared staff password; a sign-in lasts until the browser session ends or the server restarts.
- Bookings are kept in memory or a local file; data may be lost on restart if kept in memory.
- Tasting times are shown as given (winery local time); past tastings are not considered since all are in the future.
- No confirmation emails are sent.
