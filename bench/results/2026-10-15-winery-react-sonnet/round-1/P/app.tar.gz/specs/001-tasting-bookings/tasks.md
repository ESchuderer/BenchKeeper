# Tasks: Wine Tasting Bookings

**Input**: `specs/001-tasting-bookings/` (plan, spec, data-model, contracts/api.md). Tests come first in each story and must fail before the code is written.

## Phase 1: Setup

- [x] T001 Create `package.json` (type module, scripts build/start/test, Node 22) and install express, cookie-parser, zod, react, react-dom, react-router, react-hook-form, @hookform/resolvers, tsx, vite, @vitejs/plugin-react, tailwindcss, @tailwindcss/vite, vitest, supertest, jsdom, @testing-library/*, typescript and types
- [x] T002 [P] Create `tsconfig.json`, `vite.config.ts` (React, Tailwind, vitest jsdom config, /api dev proxy), `index.html`, `.gitignore` (node_modules, dist)

## Phase 2: Foundational

- [x] T003 [P] Create `shared/schema.ts`: zod booking schema, name trimmed 1–100, email valid ≤200, guests integer 1–8
- [x] T004 Create `server/store.ts` with the three seeded tastings, `seatsLeft`, `book()` (rejects `guests > seatsLeft`), `cancel()` and `reference` generation `KB-XXXXXX`
- [x] T005 Create `server/app.ts` (`createApp()`: JSON body, `/api` 404, static `dist`, SPA fallback) and `server/index.ts` (PORT default 3000)

## Phase 3: US1 Guest books a tasting (P1)

**Test**: book 2 guests on Riesling Evening, then see the confirmation and "10 seats left".

- [x] T006 [P] [US1] Write failing API tests in `tests/api.test.ts`: list tastings, create a booking (total price, reference), seats decrease, get booking by reference
- [x] T007 [P] [US1] Write failing UI tests in `tests/ui.test.tsx`: list shows title, price and "<n> seats left", "Book <title>" opens the form, submitting shows "Booking confirmed"
- [x] T008 [US1] Add the tastings and bookings routes to `server/app.ts`
- [x] T009 [US1] Build `src/main.tsx`, `src/App.tsx` (layout and routes), `src/pages/Tastings.tsx`, `src/pages/BookingForm.tsx`, `src/pages/Confirmation.tsx`

## Phase 4: US2 Input protection (P1)

**Test**: bad input and overbooking give field errors and create no booking.

- [x] T010 [P] [US2] Add failing API tests: blank name, bad email, guests 0/9/1.5/"x", more guests than seats left (`errors.guests`), unknown tasting, concurrent last-seat requests
- [x] T011 [P] [US2] Add failing UI tests: error text appears next to Name, Email and Guests; server-side errors are shown at the field
- [x] T012 [US2] Validate in the `POST /api/bookings` route with the shared schema and return `{errors}`; show the errors in `BookingForm.tsx` next to the fields, keeping the values

## Phase 5: US3 Staff (P2)

**Test**: sign in, see the booking grouped, cancel it, and the seats return.

- [x] T013 [P] [US3] Add failing API tests: staff endpoints return 401 without a session, wrong password returns 401, correct password returns 204 and a cookie, the list is grouped by tasting, delete frees seats, deleting twice returns 404, an unset `STAFF_PASSWORD` rejects every login
- [x] T014 [P] [US3] Add failing UI tests: the sign-in form, wrong-password error, grouped list, "Cancel" removes the booking
- [x] T015 [US3] Add the staff routes to `server/app.ts` (session tokens, httpOnly SameSite=Strict cookie, `timingSafeEqual`)
- [x] T016 [US3] Build `src/pages/Staff.tsx` and the `/staff` route

## Phase 6: US4 Design (P3) and polish

- [x] T017 [US4] Write `src/styles.css` (Tailwind theme: wine and cream palette, serif headings, header and footer, cards, "Fully booked" badge, error, success and empty states, 375px layout) and apply it to all pages
- [x] T018 [P] [US4] Add a "Fully booked" state without a booking link to `Tastings.tsx`, with a test
- [x] T019 Run `npm run build`, `npm start` and the quickstart in a real browser at desktop and 375px width. Fix what it finds.
- [x] T020 Write `README.md` (run instructions, `STAFF_PASSWORD`), then run the review step

## Dependencies

Phase 1 → 2 → US1 → US2 → US3 → US4 (all of them touch `server/app.ts`, so they run in order). The `[P]` tasks in a phase are the tests and can be written together.
