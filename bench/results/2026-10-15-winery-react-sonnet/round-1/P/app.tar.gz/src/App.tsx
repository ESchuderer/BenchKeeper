import { Link, Route, Routes } from "react-router";
import Tastings from "./pages/Tastings";
import BookingForm from "./pages/BookingForm";
import Confirmation from "./pages/Confirmation";
import Staff from "./pages/Staff";

export default function App() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-wine text-cream">
        <div className="mx-auto max-w-3xl px-4 py-6 text-center">
          <Link to="/" className="font-serif text-3xl tracking-wide sm:text-4xl">Weingut Kieselbrunnen</Link>
          <p className="mt-1 text-sm uppercase tracking-[0.25em] text-gold">Family winery · Tastings</p>
        </div>
      </header>
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-8">
        <Routes>
          <Route path="/" element={<Tastings />} />
          <Route path="/book/:id" element={<BookingForm />} />
          <Route path="/confirmation/:reference" element={<Confirmation />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="border-t border-line py-6 text-center text-sm text-muted">
        Weingut Kieselbrunnen · Wine tastings in the cellar
      </footer>
    </div>
  );
}

function NotFound() {
  return (
    <div className="text-center">
      <h1 className="font-serif text-3xl text-wine">Page not found</h1>
      <p className="mt-3"><Link className="link" to="/">Back to the tastings</Link></p>
    </div>
  );
}
