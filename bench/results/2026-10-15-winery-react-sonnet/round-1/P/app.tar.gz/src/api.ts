export type Tasting = { id: string; title: string; startsAt: string; priceEur: number; capacity: number; seatsLeft: number };
export type Booking = { reference: string; name: string; email: string; guests: number; totalEur: number; tasting: Tasting };

export async function api<T = unknown>(path: string, init?: { method?: string; body?: unknown }) {
  const res = await fetch("/api" + path, {
    method: init?.method,
    headers: init?.body ? { "Content-Type": "application/json" } : undefined,
    body: init?.body ? JSON.stringify(init.body) : undefined,
  });
  const data = res.headers.get("content-type")?.includes("json") ? await res.json() : undefined;
  return { ok: res.ok, status: res.status, data: data as T };
}

const weekday = new Intl.DateTimeFormat("en-GB", { weekday: "long", timeZone: "UTC" });
export const dayName = (startsAt: string) => weekday.format(new Date(startsAt.slice(0, 10)));
export const when = (startsAt: string) => startsAt.replace("T", " ");
