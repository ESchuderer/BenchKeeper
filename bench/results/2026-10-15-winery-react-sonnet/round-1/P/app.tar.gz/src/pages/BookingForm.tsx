import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { bookingSchema } from "../../shared/schema";
import { api, dayName, when, type Booking, type Tasting } from "../api";

type Values = { name: string; email: string; guests: string };
type Field = keyof Values;

export default function BookingForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tasting, setTasting] = useState<Tasting | null | undefined>();
  const [formError, setFormError] = useState("");
  const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm<Values>({
    resolver: zodResolver(bookingSchema) as never,
    defaultValues: { name: "", email: "", guests: "1" },
  });

  useEffect(() => {
    api<Tasting>(`/tastings/${id}`).then((r) => setTasting(r.ok ? r.data : null), () => setTasting(null));
  }, [id]);

  if (tasting === undefined) return <p className="text-muted">Loading…</p>;
  if (tasting === null) {
    return (
      <div>
        <h1 className="font-serif text-3xl text-wine">Tasting not found</h1>
        <p className="mt-3"><Link className="link" to="/">Back to the tastings</Link></p>
      </div>
    );
  }

  const submit = handleSubmit(async (values) => {
    setFormError("");
    const r = await api<Booking & { errors?: Record<string, string> }>("/bookings", {
      method: "POST", body: { ...values, tastingId: tasting.id },
    }).catch(() => null);
    if (r?.ok) return navigate(`/confirmation/${r.data.reference}`, { replace: true });
    const fieldErrors = r?.data?.errors;
    if (!fieldErrors) return setFormError("Something went wrong. Please try again.");
    for (const [field, message] of Object.entries(fieldErrors)) {
      if (field in values) setError(field as Field, { message });
      else setFormError(message);
    }
    api<Tasting>(`/tastings/${tasting.id}`).then((t) => t.ok && setTasting(t.data));
  });

  const full = tasting.seatsLeft === 0;
  const field = (name: Field, label: string, input: React.ComponentProps<"input">) => (
    <div>
      <label htmlFor={name} className="label">{label}</label>
      <input
        id={name} {...register(name)} {...input}
        aria-invalid={errors[name] ? "true" : "false"}
        aria-describedby={`${name}-error`}
        className={`input ${errors[name] ? "input-error" : ""}`}
      />
      <p id={`${name}-error`} className="mt-1 min-h-5 text-sm text-red-800">{errors[name]?.message}</p>
    </div>
  );

  return (
    <>
      <Link to="/" className="link text-sm">← All tastings</Link>
      <h1 className="mt-3 font-serif text-3xl text-wine sm:text-4xl">{tasting.title}</h1>
      <p className="mt-1 text-muted">
        {dayName(tasting.startsAt)} · <time dateTime={tasting.startsAt}>{when(tasting.startsAt)}</time> · EUR {tasting.priceEur} per guest · {tasting.seatsLeft} seats left
      </p>
      {full && <p role="alert" className="alert mt-5">This tasting is fully booked.</p>}
      <form onSubmit={submit} noValidate className="card mt-6 grid gap-2">
        {field("name", "Name", { type: "text", autoComplete: "name" })}
        {field("email", "Email", { type: "email", autoComplete: "email" })}
        {field("guests", "Guests", { type: "number", min: 1, max: 8, inputMode: "numeric" })}
        {formError && <p role="alert" className="alert">{formError}</p>}
        <button type="submit" className="btn mt-2 w-full sm:w-auto" disabled={isSubmitting}>Book</button>
      </form>
    </>
  );
}
