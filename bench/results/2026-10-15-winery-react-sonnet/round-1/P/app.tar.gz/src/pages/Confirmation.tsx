import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import { api, dayName, when, type Booking } from "../api";

export default function Confirmation() {
  const { reference } = useParams();
  const [booking, setBooking] = useState<Booking | null | undefined>();
  useEffect(() => {
    api<Booking>(`/bookings/${reference}`).then((r) => setBooking(r.ok ? r.data : null), () => setBooking(null));
  }, [reference]);

  if (booking === undefined) return <p className="text-muted">Loading…</p>;
  if (!booking) {
    return (
      <div>
        <h1 className="font-serif text-3xl text-wine">Booking not found</h1>
        <p className="mt-3"><Link className="link" to="/">Back to the tastings</Link></p>
      </div>
    );
  }
  return (
    <div className="card border-ok text-center">
      <p className="text-4xl text-ok" aria-hidden="true">✓</p>
      <h1 className="mt-2 font-serif text-3xl text-wine sm:text-4xl">Booking confirmed</h1>
      <p className="mt-2 text-muted">Thank you, {booking.name}. We look forward to welcoming you.</p>
      <dl className="mx-auto mt-6 grid max-w-sm grid-cols-[auto_1fr] gap-x-6 gap-y-2 text-left">
        <dt className="text-muted">Tasting</dt>
        <dd className="font-semibold">{booking.tasting.title}</dd>
        <dt className="text-muted">When</dt>
        <dd>{dayName(booking.tasting.startsAt)}, {when(booking.tasting.startsAt)}</dd>
        <dt className="text-muted">Guests</dt>
        <dd>{booking.guests}</dd>
        <dt className="text-muted">Total price</dt>
        <dd className="font-semibold">EUR {booking.totalEur}</dd>
        <dt className="text-muted">Reference</dt>
        <dd className="font-mono font-semibold">{booking.reference}</dd>
      </dl>
      <p className="mt-6"><Link className="link" to="/">Back to the tastings</Link></p>
    </div>
  );
}
