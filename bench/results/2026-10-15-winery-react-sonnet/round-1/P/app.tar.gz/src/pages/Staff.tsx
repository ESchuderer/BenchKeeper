import { useEffect, useState } from "react";
import { api, dayName, when, type Tasting } from "../api";

type Group = { tasting: Tasting; bookings: { reference: string; name: string; email: string; guests: number }[] };

export default function Staff() {
  const [groups, setGroups] = useState<Group[] | null>();
  const load = () => api<Group[]>("/staff/bookings").then((r) => setGroups(r.ok ? r.data : null), () => setGroups(null));
  useEffect(() => { load(); }, []);

  if (groups === undefined) return <p className="text-muted">Loading…</p>;
  if (groups === null) return <SignIn onDone={load} />;
  return <Bookings groups={groups} reload={load} signOut={() => api("/staff/logout", { method: "POST" }).then(() => setGroups(null))} />;
}

function SignIn({ onDone }: { onDone: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  return (
    <>
      <h1 className="font-serif text-3xl text-wine sm:text-4xl">Staff</h1>
      <form
        noValidate
        className="card mt-6 grid max-w-md gap-2"
        onSubmit={async (e) => {
          e.preventDefault();
          const r = await api<{ errors: { password: string } }>("/staff/login", { method: "POST", body: { password } }).catch(() => null);
          if (r?.ok) onDone();
          else setError(r?.data?.errors?.password ?? "Something went wrong. Please try again.");
        }}
      >
        <label htmlFor="password" className="label">Password</label>
        <input
          id="password" type="password" autoComplete="current-password" value={password}
          onChange={(e) => setPassword(e.target.value)}
          aria-invalid={error ? "true" : "false"} aria-describedby="password-error"
          className={`input ${error ? "input-error" : ""}`}
        />
        <p id="password-error" className="min-h-5 text-sm text-red-800">{error}</p>
        <button type="submit" className="btn">Sign in</button>
      </form>
    </>
  );
}

function Bookings({ groups, reload, signOut }: { groups: Group[]; reload: () => void; signOut: () => void }) {
  const [error, setError] = useState("");
  const cancel = async (reference: string) => {
    const r = await api(`/staff/bookings/${reference}`, { method: "DELETE" }).catch(() => null);
    setError(r && (r.ok || r.status === 404) ? "" : "Could not cancel the booking. Please try again.");
    reload();
  };
  return (
    <>
      <div className="flex items-center justify-between gap-3">
        <h1 className="font-serif text-3xl text-wine sm:text-4xl">Bookings</h1>
        <button className="btn-quiet" onClick={signOut}>Sign out</button>
      </div>
      {error && <p role="alert" className="alert mt-4">{error}</p>}
      <div className="mt-6 grid gap-5">
        {groups.map(({ tasting, bookings }) => (
          <section key={tasting.id} className="card">
            <h2 className="font-serif text-2xl text-wine">{tasting.title}</h2>
            <p className="text-sm text-muted">
              {dayName(tasting.startsAt)}, {when(tasting.startsAt)} · {tasting.capacity - tasting.seatsLeft} of {tasting.capacity} seats booked
            </p>
            {bookings.length === 0 ? (
              <p className="mt-4 text-muted">No bookings yet.</p>
            ) : (
              <ul className="mt-4 divide-y divide-line">
                {bookings.map((b) => (
                  <li key={b.reference} className="flex flex-wrap items-center justify-between gap-3 py-3">
                    <div className="min-w-0">
                      <p className="font-semibold">{b.name}</p>
                      <p className="break-all text-sm text-muted">{b.email}</p>
                      <p className="text-sm">{b.guests} {b.guests === 1 ? "guest" : "guests"} · <span className="font-mono">{b.reference}</span></p>
                    </div>
                    <button className="btn-danger" onClick={() => cancel(b.reference)}>Cancel</button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </div>
    </>
  );
}
