import { useEffect, useState } from "react";
import { Link } from "react-router";
import { api, dayName, when, type Tasting } from "../api";

export default function Tastings() {
  const [tastings, setTastings] = useState<Tasting[]>();
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    api<Tasting[]>("/tastings").then((r) => (r.ok ? setTastings(r.data) : setFailed(true)), () => setFailed(true));
  }, []);

  return (
    <>
      <h1 className="font-serif text-3xl text-wine sm:text-4xl">Upcoming tastings</h1>
      <p className="mt-2 text-muted">Join us at the estate. Pick a tasting and reserve your seats.</p>
      {failed && <p role="alert" className="alert mt-6">Could not load the tastings. Please try again later.</p>}
      {!tastings && !failed && <p className="mt-6 text-muted">Loading…</p>}
      <div className="mt-6 grid gap-5">
        {tastings?.map((t) => {
          const full = t.seatsLeft === 0;
          return (
            <article key={t.id} className={`card ${full ? "opacity-80" : ""}`}>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <h2 className="font-serif text-2xl text-wine">{t.title}</h2>
                {full && <span className="badge-full">Fully booked</span>}
              </div>
              <p className="mt-1 text-muted"><span>{dayName(t.startsAt)}</span> · <time dateTime={t.startsAt}>{when(t.startsAt)}</time></p>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <p>
                  <span className="font-semibold">EUR {t.priceEur}</span> per guest
                  <span className={`ml-3 text-sm ${full ? "text-red-800" : "text-ok"}`}>{t.seatsLeft} seats left</span>
                </p>
                {!full && <Link to={`/book/${t.id}`} className="btn">Book {t.title}</Link>}
              </div>
            </article>
          );
        })}
      </div>
    </>
  );
}
