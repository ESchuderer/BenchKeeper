import request from "supertest";
import { createApp } from "../server/app";

const mk = (staffPassword: string | undefined = "secret") => createApp({ staffPassword });
const book = (app: ReturnType<typeof mk>, body: object) => request(app).post("/api/bookings").send(body);
const ok = { tastingId: "riesling-evening", name: "Anna", email: "anna@example.com", guests: 2 };

async function staff(app: ReturnType<typeof mk>) {
  const res = await request(app).post("/api/staff/login").send({ password: "secret" });
  return res.headers["set-cookie"] as unknown as string[];
}

describe("guests", () => {
  it("lists the three tastings with full seats", async () => {
    const res = await request(mk()).get("/api/tastings");
    expect(res.body.map((t: any) => [t.title, t.priceEur, t.seatsLeft])).toEqual([
      ["Riesling Evening", 25, 12], ["Red Wine Cellar Tour", 32, 8], ["Winter Tasting", 28, 10],
    ]);
  });

  it("books, prices on the server, reduces seats, and can be fetched", async () => {
    const app = mk();
    const res = await book(app, { ...ok, totalEur: 1 });
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ guests: 2, totalEur: 50, tasting: { title: "Riesling Evening" } });
    expect(res.body.reference).toMatch(/^KB-[0-9A-F]{10}$/);
    expect((await request(app).get("/api/tastings/riesling-evening")).body.seatsLeft).toBe(10);
    const fetched = (await request(app).get(`/api/bookings/${res.body.reference}`)).body;
    expect(fetched.reference).toBe(res.body.reference);
    expect(fetched.email).toBeUndefined(); // public lookup must not leak the guest's email
  });

  it.each([
    [{ name: "  " }, "name"],
    [{ name: "x".repeat(101) }, "name"],
    [{ email: "nope" }, "email"],
    [{ guests: 0 }, "guests"],
    [{ guests: 9 }, "guests"],
    [{ guests: 1.5 }, "guests"],
    [{ guests: "x" }, "guests"],
    [{ guests: null }, "guests"],
  ])("rejects %j with an error on %s", async (patch, field) => {
    const app = mk();
    const res = await book(app, { ...ok, ...patch });
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors)).toContain(field);
    expect((await request(app).get("/api/tastings/riesling-evening")).body.seatsLeft).toBe(12);
  });

  it("rejects missing body fields and non-object bodies", async () => {
    const res = await request(mk()).post("/api/bookings").send({});
    expect(res.status).toBe(400);
  });

  it("never books more than the seats left", async () => {
    const app = mk();
    await book(app, { ...ok, tastingId: "red-wine-cellar-tour", guests: 6 });
    const res = await book(app, { ...ok, tastingId: "red-wine-cellar-tour", guests: 3 });
    expect(res.status).toBe(400);
    expect(res.body.errors.guests).toMatch(/2 seats left/);
    expect((await book(app, { ...ok, tastingId: "red-wine-cellar-tour", guests: 2 })).status).toBe(201);
    const full = await book(app, { ...ok, tastingId: "red-wine-cellar-tour", guests: 1 });
    expect(full.status).toBe(400);
    expect(full.body.errors.guests).toMatch(/fully booked/i);
  });

  it("only one of two concurrent last-seat bookings succeeds", async () => {
    const app = mk();
    const body = { ...ok, tastingId: "red-wine-cellar-tour", guests: 5 };
    const codes = (await Promise.all([book(app, body), book(app, body)])).map((r) => r.status).sort();
    expect(codes).toEqual([201, 400]);
  });

  it("rejects unknown tastings and unknown references", async () => {
    const app = mk();
    expect((await book(app, { ...ok, tastingId: "nope" })).status).toBe(404);
    expect((await request(app).get("/api/tastings/nope")).status).toBe(404);
    expect((await request(app).get("/api/bookings/KB-000000")).status).toBe(404);
    expect((await request(app).get("/api/nothing")).status).toBe(404);
  });
});

describe("staff", () => {
  it("refuses everything without a session", async () => {
    const app = mk();
    expect((await request(app).get("/api/staff/bookings")).status).toBe(401);
    expect((await request(app).delete("/api/staff/bookings/KB-000000")).status).toBe(401);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", "staff=forged")).status).toBe(401);
  });

  it("rejects wrong, empty and missing passwords", async () => {
    const app = mk();
    for (const body of [{ password: "wrong" }, { password: "" }, {}]) {
      const res = await request(app).post("/api/staff/login").send(body);
      expect(res.status).toBe(401);
      expect(res.body.errors.password).toBeTruthy();
      expect(res.headers["set-cookie"]).toBeUndefined();
    }
  });

  it("rejects every login when STAFF_PASSWORD is unset or empty", async () => {
    for (const pw of [undefined, ""]) {
      const res = await request(mk(pw)).post("/api/staff/login").send({ password: pw ?? "" });
      expect(res.status).toBe(401);
    }
  });

  it("signs in with an httpOnly cookie, lists bookings by tasting, cancels and frees seats", async () => {
    const app = mk();
    const login = await request(app).post("/api/staff/login").send({ password: "secret" });
    expect(login.status).toBe(204);
    const cookie = login.headers["set-cookie"] as unknown as string[];
    expect(cookie[0]).toMatch(/HttpOnly/i);

    const { body: b } = await book(app, ok);
    const list = await request(app).get("/api/staff/bookings").set("Cookie", cookie);
    expect(list.status).toBe(200);
    expect(list.body.map((g: any) => g.tasting.title)).toEqual(["Riesling Evening", "Red Wine Cellar Tour", "Winter Tasting"]);
    expect(list.body[0].bookings).toEqual([expect.objectContaining({ reference: b.reference, name: "Anna", email: "anna@example.com", guests: 2 })]);
    expect(list.body[1].bookings).toEqual([]);

    expect((await request(app).delete(`/api/staff/bookings/${b.reference}`).set("Cookie", cookie)).status).toBe(204);
    expect((await request(app).get("/api/tastings/riesling-evening")).body.seatsLeft).toBe(12);
    expect((await request(app).delete(`/api/staff/bookings/${b.reference}`).set("Cookie", cookie)).status).toBe(404);
  });

  it("logout ends the session", async () => {
    const app = mk();
    const cookie = await staff(app);
    await request(app).post("/api/staff/logout").set("Cookie", cookie);
    expect((await request(app).get("/api/staff/bookings").set("Cookie", cookie)).status).toBe(401);
  });
});
