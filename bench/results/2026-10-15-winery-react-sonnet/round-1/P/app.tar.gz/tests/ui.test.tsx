// @vitest-environment jsdom
import { render, screen, within, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router";
import type { Server } from "node:http";
import { createApp } from "../server/app";
import App from "../src/App";

// The UI talks to the real API on an ephemeral port; a tiny cookie jar stands in for the browser.
let server: Server;
let cookie = "";
beforeEach(async () => {
  cookie = "";
  server = createApp({ staffPassword: "secret" }).listen(0);
  const base = `http://127.0.0.1:${(server.address() as any).port}`;
  const realFetch = globalThis.fetch;
  vi.stubGlobal("fetch", async (url: string, init: RequestInit = {}) => {
    const res = await realFetch(base + url, { ...init, headers: { ...(init.headers as object), cookie } });
    const set = res.headers.getSetCookie()[0];
    if (set) cookie = set.split(";")[0];
    return res;
  });
});
afterEach(() => { cleanup(); server.close(); vi.unstubAllGlobals(); });

const open = (path = "/") => render(<MemoryRouter initialEntries={[path]}><App /></MemoryRouter>);

async function bookRiesling(user: ReturnType<typeof userEvent.setup>, guests = "2") {
  await user.click(await screen.findByRole("link", { name: "Book Riesling Evening" }));
  await user.type(await screen.findByLabelText("Name"), "Anna Weiss");
  await user.type(screen.getByLabelText("Email"), "anna@example.com");
  await user.clear(screen.getByLabelText("Guests"));
  await user.type(screen.getByLabelText("Guests"), guests);
  await user.click(screen.getByRole("button", { name: "Book" }));
}

describe("guest", () => {
  it("lists tastings with date, price and seats left", async () => {
    open();
    const card = (await screen.findByText("Riesling Evening")).closest("article")!;
    expect(card).toHaveTextContent("2026-11-06 18:00");
    expect(card).toHaveTextContent("EUR 25");
    expect(card).toHaveTextContent("12 seats left");
    expect(screen.getByText("8 seats left")).toBeInTheDocument();
    expect(screen.getByText("10 seats left")).toBeInTheDocument();
  });

  it("books a tasting and shows the confirmation", async () => {
    const user = userEvent.setup();
    open();
    await bookRiesling(user);
    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    const main = screen.getByRole("main");
    expect(main).toHaveTextContent("Riesling Evening");
    expect(main).toHaveTextContent("EUR 50");
    expect(main).toHaveTextContent(/KB-[0-9A-F]{10}/);
  });

  it("shows validation errors next to the fields", async () => {
    const user = userEvent.setup();
    open("/book/riesling-evening");
    await user.clear(await screen.findByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), "9");
    await user.type(screen.getByLabelText("Email"), "nope");
    await user.click(screen.getByRole("button", { name: "Book" }));
    for (const label of ["Name", "Email", "Guests"]) {
      const field = screen.getByLabelText(label);
      expect(field).toHaveAttribute("aria-invalid", "true");
      expect(document.getElementById(field.getAttribute("aria-describedby")!)).toHaveTextContent(/\w/);
    }
    expect(screen.queryByRole("heading", { name: "Booking confirmed" })).toBeNull();
  });

  it("shows the server's seats-left error at Guests and marks full tastings", async () => {
    const user = userEvent.setup();
    open();
    await bookRiesling(user, "8");
    await screen.findByRole("heading", { name: "Booking confirmed" });
    cleanup();
    open();
    await bookRiesling(user, "8"); // only 4 left
    expect(await screen.findByText("Only 4 seats left")).toBeInTheDocument();
    expect(screen.getByLabelText("Guests")).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByLabelText("Name")).toHaveValue("Anna Weiss");
    await user.clear(screen.getByLabelText("Guests"));
    await user.type(screen.getByLabelText("Guests"), "4");
    await user.click(screen.getByRole("button", { name: "Book" }));
    await screen.findByRole("heading", { name: "Booking confirmed" });
    cleanup();
    open();
    expect(await screen.findByText("Fully booked")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Riesling Evening" })).toBeNull();
    expect(screen.getByRole("link", { name: "Book Winter Tasting" })).toBeInTheDocument();
  });
});

describe("staff", () => {
  it("signs in, lists bookings by tasting and cancels", async () => {
    const user = userEvent.setup();
    open();
    await bookRiesling(user);
    await screen.findByRole("heading", { name: "Booking confirmed" });
    cleanup();

    open("/staff");
    await user.type(await screen.findByLabelText("Password"), "wrong");
    await user.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByText("Wrong password")).toBeInTheDocument();
    expect(screen.queryByText("anna@example.com")).toBeNull();

    await user.clear(screen.getByLabelText("Password"));
    await user.type(screen.getByLabelText("Password"), "secret");
    await user.click(screen.getByRole("button", { name: "Sign in" }));
    const group = (await screen.findByRole("heading", { name: /Riesling Evening/ })).closest("section")!;
    expect(group).toHaveTextContent("Anna Weiss");
    expect(group).toHaveTextContent("anna@example.com");
    expect(group).toHaveTextContent(/KB-[0-9A-F]{10}/);
    expect(screen.getByRole("heading", { name: /Winter Tasting/ }).closest("section")).toHaveTextContent("No bookings");

    await user.click(within(group).getByRole("button", { name: "Cancel" }));
    await screen.findAllByText(/No bookings/);
    expect(screen.queryByText("Anna Weiss")).toBeNull();
    cleanup();
    open();
    expect(await screen.findByText("Riesling Evening")).toBeInTheDocument();
    expect(await screen.findByText("12 seats left")).toBeInTheDocument();
  });

  it("asks for the password without a session", async () => {
    open("/staff");
    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
  });
});
