# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings online; staff see and cancel bookings.

## Run

```bash
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start   # serves everything on $PORT (default 3000)
```

| Variable | Purpose |
|---|---|
| `PORT` | Port to listen on (default `3000`) |
| `STAFF_PASSWORD` | Password for `/staff`. If unset, staff sign-in is disabled (there is no default password) |
| `DATA_FILE` | Optional. Path of a JSON file to keep bookings across restarts. Without it bookings live in memory and the app starts empty |
| `TRUST_PROXY` | Optional. Number of reverse proxies in front of the app (e.g. `1`). Needed behind nginx/Caddy so the sign-in rate limit counts each visitor separately and the staff cookie gets the `Secure` flag over https |

Node.js 22 is required.

## Pages

- `/` – tastings with date, price per guest and seats left
- `/book/:id` – booking form, then the confirmation with the booking reference
- `/staff` – password-protected list of bookings grouped by tasting, with a Cancel button per booking

## Develop and test

```bash
npm test            # unit + API + component tests (Vitest)
npm run test:e2e    # Playwright against the real server (run `npm run build` and `npx playwright install chromium` first)
npm run dev         # Vite dev server with /api proxied to localhost:3000 (start `npm start` too)
```

## Layout

```
server/       Express app, booking store, staff auth, tasting data
src/shared/   Booking validation (zod), money and date helpers used by client and server
src/client/   React app (Vite)
tests/        shared / server / client / e2e
docs/superpowers/   design spec and implementation plan
```

Seats are checked and booked inside one serialized queue, so concurrent requests can never oversell a tasting.
