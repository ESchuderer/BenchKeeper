# Tasting Bookings Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (chosen: inline, tasks are tightly coupled). Steps use checkbox syntax.

**Goal:** Guests book tastings, staff see and cancel bookings; `npm start` serves everything.

**Architecture:** One Express process serves the Vite-built React SPA and a JSON API. A serialized in-memory store (optional JSON file) guarantees no overbooking. The zod booking schema is shared by client and server.

**Tech Stack:** Node 22, Express, React 18, React Router, Vite, react-hook-form + zod, Vitest, Supertest, React Testing Library, Playwright.

## Global Constraints

- Node.js 22; `npm install`, `npm run build`, `npm start` on `PORT` (default 3000). App starts with no bookings.
- Interface in English. Tastings and prices exactly as in `docs/superpowers/specs/2026-10-15-tasting-bookings-design.md`.
- Seat text: `<n> seats left`. Link/button text: `Book <tasting title>`. Fields labelled `Name`, `Email`, `Guests` (1 to 8), button `Book`.
- Confirmation heading `Booking confirmed` + tasting, guests, total price, reference.
- Staff at `/staff`: `Password` field, `Sign in` button, password from `STAFF_PASSWORD`; `Cancel` button per booking; cancelling frees seats.
- Errors are shown next to the field concerned. Mobile-usable, polished design.
- TDD: every behaviour gets a failing test first.

---

### Task 1: Scaffold + shared domain (money, schema, tastings)

**Files:** Create `package.json`, `vite.config.js`, `vitest.config.js`, `.gitignore` additions (`node_modules`, `dist`, `data`), `src/shared/money.js`, `src/shared/booking-schema.js`, `server/tastings.js`; tests `tests/shared/*.test.js`.

**Interfaces — Produces:**
- `formatEur(cents) -> "EUR 25"` / `"EUR 12.50"`
- `bookingSchema` (zod): `{name, email, guests}`; `guests` accepts numbers and numeric strings; messages: "Please enter your name.", "Please enter a valid email address.", "Please choose between 1 and 8 guests."
- `TASTINGS` array `{id,title,startsAt:"2026-11-06T18:00",pricePerGuest(cents),capacity}`

- [ ] Write tests (money formatting; schema accepts valid, rejects blank name / bad email / 0 / 9 / 1.5 / "abc" guests; trims name)
- [ ] Run, expect FAIL; implement; run, expect PASS; commit

### Task 2: Store with serialized mutation and optional file persistence

**Files:** Create `server/store.js`; test `tests/server/store.test.js`.

**Interfaces — Produces:** `createStore({tastings, file?}) -> { list(), seatsLeft(tastingId), create({tastingId,name,email,guests}), cancel(reference) }`, async. `create` throws `BookingError(code: 'NOT_FOUND'|'SOLD_OUT'|'TOO_MANY', seatsLeft)`; `cancel` returns `true/false`.

- [ ] Tests: create reduces seats; over-capacity rejected with seatsLeft; fully booked -> SOLD_OUT; 20 concurrent creates of 1 guest on 8 seats yield exactly 8 successes; cancel frees seats; unknown reference false; references unique and match `/^KB-[A-Z2-9]{6}$/`; file persistence reload round-trips
- [ ] Run FAIL; implement (promise queue, atomic write via tmp+rename); run PASS; commit

### Task 3: HTTP API + staff auth

**Files:** Create `server/app.js` (`createApp({store, staffPassword})`), `server/staff-auth.js`, `server/index.js`; test `tests/server/api.test.js`.

**Interfaces — Produces:** endpoints exactly as in the spec "API" section. Deps: `express`, `cookie-parser` not needed (parse cookie manually), `express-rate-limit`.

- [ ] Tests: GET tastings shows seeds + seatsLeft; POST valid -> 201 with reference/total; invalid -> 400 with field errors; too many -> 409 on `guests`; sold out -> 409; unknown tasting 404; staff routes 401 without cookie; login wrong 401, right 204 + cookie HttpOnly; unset password 503; list grouped by tasting; DELETE frees seats; logout invalidates; non-JSON body rejected
- [ ] Run FAIL; implement; run PASS; commit

### Task 4: Serve SPA + start script

**Files:** Modify `server/app.js` (static `dist/client`, SPA fallback for non-`/api` GET), `server/index.js` (PORT, DATA_FILE, STAFF_PASSWORD warn); `package.json` scripts.

- [ ] Test: unknown API route -> 404 JSON; `GET /staff` returns index.html when the build exists. Implement; commit

### Task 5: Client – API layer, guest pages

**Files:** Create `index.html`, `src/client/{main.jsx,App.jsx,api.js,styles.css}`, `pages/{TastingsPage,BookingPage,NotFoundPage}.jsx`, `components/{TastingCard,Layout,FieldError}.jsx`; tests `tests/client/guest.test.jsx` (jsdom, fetch mocked).

**Interfaces — Consumes:** API from Task 3. **Produces:** `api.{getTastings,book,login,logout,session,getBookings,cancel}`; errors thrown as `ApiError{status,errors}`.

- [ ] Tests: list shows title/date/price/`n seats left`; sold out shows "Fully booked" and no link; "Book <title>" navigates to form; client validation shows errors beside Name/Email/Guests; server 409 error shows under Guests; success shows "Booking confirmed", guests, total, reference
- [ ] Run FAIL; implement; run PASS; commit

### Task 6: Client – staff page

**Files:** Create `pages/StaffPage.jsx`; test `tests/client/staff.test.jsx`.

- [ ] Tests: sign-in form; wrong password shows error; signed-in shows grouped bookings; Cancel removes row and refreshes seats; empty state; sign out
- [ ] Run FAIL; implement; PASS; commit

### Task 7: Visual design and responsiveness

**Files:** Modify `src/client/styles.css`, components as needed.

- [ ] Implement theme (tokens, cards, badges, alerts, form states, focus rings, breakpoints at 640/960px); check with Playwright screenshots at 375px and 1280px; commit

### Task 8: End-to-end and finalisation

**Files:** Create `playwright.config.js`, `tests/e2e/flow.spec.js`, `README.md`.

- [ ] E2E against the real `npm start` with `STAFF_PASSWORD`: guest books -> confirmation -> seats decrease -> overbooking rejected -> staff signs in, sees booking, cancels -> seats restored
- [ ] Run `npm test`, `npm run build`, `npm start`; request-review; fix; merge to main

---

**Self-review:** spec sections Stack/Domain/Storage/API/UI map to Tasks 1–7; E2E covers the full flow; names (`createStore`, `createApp`, `bookingSchema`, `formatEur`) are used consistently.
