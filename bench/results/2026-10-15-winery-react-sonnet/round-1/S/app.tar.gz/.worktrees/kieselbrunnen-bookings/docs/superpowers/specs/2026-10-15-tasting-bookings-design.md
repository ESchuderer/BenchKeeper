# Weingut Kieselbrunnen – Tasting Bookings: Design

Date: 2026-10-15. Status: approved by the user ("continue ... do not wait for approval").

## Goal

A small web app where guests book wine tastings online and staff see and cancel bookings.
Interface language: English. Single Node 22 process, no external services.

## Stack

- Frontend: Vite + React 18 + React Router, react-hook-form + zod (`@hookform/resolvers`), plain CSS with design tokens.
- Server: Express 4 serving the built SPA (`dist/client`) and a JSON API under `/api`.
- Shared: zod schema for the booking input in `src/shared/`, used by client and server.
- Tests: Vitest, Supertest (API), React Testing Library (UI), Playwright (e2e against `npm start`).
- `npm run build` builds the client. `npm start` runs the server (`PORT`, default 3000).

## Domain

Seed tastings (fixed, prices in cents):

| id | title | starts | price | seats |
|---|---|---|---|---|
| riesling-evening | Riesling Evening | 2026-11-06 18:00 | 2500 | 12 |
| red-wine-cellar-tour | Red Wine Cellar Tour | 2026-11-14 15:00 | 3200 | 8 |
| winter-tasting | Winter Tasting | 2026-12-05 17:00 | 2800 | 10 |

Booking: `{ reference, tastingId, name, email, guests, createdAt }`.
Seats left = capacity − sum(guests of active bookings). Cancelling deletes the booking, which frees its seats.
Reference: `KB-` + 6 chars from `ABCDEFGHJKMNPQRSTUVWXYZ23456789`, generated with `crypto.randomInt`, retried on collision.
Total price = guests × price per guest, computed on the server.

## Storage

`BookingStore` interface (`list`, `create`, `cancel`, `seatsLeft`). In-memory by default. If `DATA_FILE` is set,
state is loaded from the file at start and written atomically (tmp file + rename) after every mutation.
All mutations run through a promise queue, so check-and-write is atomic and the app cannot oversell under concurrency.

## API

- `GET /api/tastings` → `[{id,title,startsAt,pricePerGuest,capacity,seatsLeft}]`
- `POST /api/tastings/:id/bookings` `{name,email,guests}` → 201 `{reference,tasting,guests,total,name,email}`;
  400 `{errors:{field:message}}` for invalid input; 404 unknown tasting; 409 `{errors:{guests:"Only N seats left"}}`
  (or "This tasting is fully booked") when too many seats are requested.
- `POST /api/staff/login` `{password}` → 204 + httpOnly SameSite=Strict cookie; 401 on a wrong password;
  503 if `STAFF_PASSWORD` is unset (sign-in disabled, no default password). Constant-time comparison. Rate-limited.
- `POST /api/staff/logout`, `GET /api/staff/session` (200/401).
- `GET /api/staff/bookings` → bookings grouped by tasting; 401 without a session.
- `DELETE /api/staff/bookings/:reference` → 204; 401 / 404.

Validation: name trimmed, 1–100 chars; email valid format, ≤ 254 chars; guests integer 1–8. The server also enforces guests ≤ seats left.
Request bodies are JSON only and size-limited. Sessions are random 32-byte tokens held in memory.

## UI

Routes: `/` (list), `/book/:id` (form, then confirmation in place), `/staff`, and a not-found page.

- Start page: cards with title, `2026-11-06 18:00` (plus a weekday label), `EUR 25 per guest`, `12 seats left`
  and a "Book <title>" link. A fully booked tasting shows a "Fully booked" badge and no link.
  Loading and error states are included.
- Booking form: fields Name, Email, Guests (number input, `noValidate`) and a "Book" button.
  Errors sit under the field with an icon and text and are linked via `aria-describedby` and `aria-invalid`.
  Server errors map onto their fields. The button is disabled while submitting.
  A tasting that is already full shows a notice instead of the form.
- Confirmation: heading "Booking confirmed", tasting, guests, total (`EUR 50`) and reference, with a link back.
- Staff: "Password" + "Sign in", with an inline error on failure. Once signed in, bookings are grouped under each tasting
  (name, email, guests, reference, "Cancel" button, no confirm dialog). The page shows seats taken and
  "No bookings yet" for an empty tasting. A "Sign out" button is included.
- Money format: `EUR 25`, with decimals only when needed.
- Design: cream background, burgundy and gold accents, serif headings (system serif stack, no external fonts),
  mobile-first responsive layout, visible focus rings, AA contrast, `prefers-reduced-motion` respected.
  Success, error and fully-booked states are visually distinct and never rely on colour alone.

## Layout

```
server/        index.js (start), app.js (createApp), store.js, tastings.js, staff-auth.js
src/shared/    booking-schema.js, money.js
src/client/    main.jsx, App.jsx, pages/, components/, api.js, styles.css
tests/         server/*.test.js, client/*.test.jsx, e2e/*.spec.js
```

## Out of scope

Payments, emails, guest-side cancellation, tasting admin, closing bookings for past tastings.
