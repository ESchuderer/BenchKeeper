import { defineConfig, devices } from '@playwright/test';

const PORT = 3100;

export default defineConfig({
  testDir: 'tests/e2e',
  fullyParallel: false,
  workers: 1, // bookings live in the server's memory, so tests share state
  reporter: 'list',
  use: { baseURL: `http://localhost:${PORT}`, trace: 'retain-on-failure' },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    reuseExistingServer: false,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-secret' },
  },
});
