import { existsSync } from 'node:fs';
import { extname, join } from 'node:path';
import express from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { bookingSchema, fieldErrors } from '../src/shared/booking-schema.js';
import { BookingError } from './store.js';
import { createStaffAuth, COOKIE_NAME } from './staff-auth.js';

const seatsMessage = (n) => `Only ${n} ${n === 1 ? 'seat' : 'seats'} left.`;

/**
 * Build the Express app.
 * @param {object} options
 * @param {object} options.store        booking store (see store.js)
 * @param {object[]} options.tastings   tastings on offer
 * @param {string} options.staffPassword  empty/undefined disables staff sign-in
 * @param {string} [options.clientDir]  built SPA to serve
 * @param {number} [options.loginLimit] failed sign-ins allowed per 15 minutes per IP
 * @param {number|boolean} [options.trustProxy] Express 'trust proxy' setting; set to the number of reverse
 *   proxies in front of the app so client IPs (rate limiting) and https detection (Secure cookie) are right
 */
export function createApp({ store, tastings, staffPassword, clientDir, loginLimit = 10, trustProxy = false }) {
  const app = express();
  const auth = createStaffAuth({ password: staffPassword });
  const byId = new Map(tastings.map((t) => [t.id, t]));

  const publicTasting = (t) => ({
    id: t.id,
    title: t.title,
    startsAt: t.startsAt,
    pricePerGuest: t.pricePerGuest,
    capacity: t.capacity,
    seatsLeft: store.seatsLeft(t.id),
  });

  app.disable('x-powered-by');
  if (trustProxy) app.set('trust proxy', trustProxy);
  // The winery may serve this over plain http (e.g. on a LAN), so don't force https upgrades.
  app.use(helmet({ contentSecurityPolicy: { directives: { 'upgrade-insecure-requests': null } } }));
  app.use(express.json({ limit: '10kb' }));

  const api = express.Router();
  api.use((req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });

  // --- guests ---------------------------------------------------------------------------
  api.get('/tastings', (req, res) => res.json(tastings.map(publicTasting)));

  api.post('/tastings/:id/bookings', async (req, res, next) => {
    try {
      const tasting = byId.get(req.params.id);
      if (!tasting) return res.status(404).json({ error: 'Tasting not found.' });

      const parsed = bookingSchema.safeParse(req.body ?? {});
      if (!parsed.success) return res.status(400).json({ errors: fieldErrors(parsed) });

      const { name, email, guests } = parsed.data;
      let booking;
      try {
        booking = await store.create({ tastingId: tasting.id, name, email, guests });
      } catch (err) {
        if (!(err instanceof BookingError)) throw err;
        if (err.code === 'NOT_FOUND') return res.status(404).json({ error: 'Tasting not found.' });
        const message = err.code === 'SOLD_OUT' ? 'This tasting is fully booked.' : seatsMessage(err.seatsLeft);
        return res.status(409).json({ errors: { guests: message } });
      }
      res.status(201).json({
        reference: booking.reference,
        name: booking.name,
        email: booking.email,
        guests: booking.guests,
        pricePerGuest: tasting.pricePerGuest,
        total: tasting.pricePerGuest * booking.guests,
        tasting: { id: tasting.id, title: tasting.title, startsAt: tasting.startsAt },
      });
    } catch (err) {
      next(err);
    }
  });

  // --- staff ----------------------------------------------------------------------------
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: loginLimit,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res) =>
      res.status(429).json({ errors: { password: 'Too many attempts. Please try again later.' } }),
  });

  api.post('/staff/login', loginLimiter, (req, res) => {
    if (!auth.enabled) {
      return res.status(503).json({ errors: { password: 'Staff sign-in is not configured.' } });
    }
    const token = auth.login(req.body?.password);
    if (!token) return res.status(401).json({ errors: { password: 'Incorrect password.' } });
    res.cookie(COOKIE_NAME, token, { ...auth.cookieOptions, secure: req.secure }).status(204).end();
  });

  api.post('/staff/logout', (req, res) => {
    const token = auth.tokenFrom(req);
    if (token) auth.logout(token);
    res.clearCookie(COOKIE_NAME, { path: '/' }).status(204).end();
  });

  api.get('/staff/session', auth.requireStaff, (req, res) => res.json({ ok: true }));

  api.get('/staff/bookings', auth.requireStaff, (req, res) => {
    const all = store.list();
    res.json(
      tastings.map((t) => ({
        tasting: publicTasting(t),
        bookings: all
          .filter((b) => b.tastingId === t.id)
          .map(({ reference, name, email, guests, createdAt }) => ({ reference, name, email, guests, createdAt })),
      })),
    );
  });

  api.delete('/staff/bookings/:reference', auth.requireStaff, async (req, res, next) => {
    try {
      const removed = await store.cancel(req.params.reference);
      if (!removed) return res.status(404).json({ error: 'Booking not found.' });
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  api.use((req, res) => res.status(404).json({ error: 'Not found.' }));
  app.use('/api', api);

  // --- built client ---------------------------------------------------------------------
  if (clientDir && existsSync(join(clientDir, 'index.html'))) {
    app.use(express.static(clientDir, { index: false, maxAge: '1h' }));
    app.use((req, res, next) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') return next();
      if (extname(req.path)) return next(); // a missing file (e.g. a stale asset hash), not an app route
      res.sendFile('index.html', { root: clientDir, headers: { 'Cache-Control': 'no-cache' } });
    });
  }

  // --- errors ---------------------------------------------------------------------------
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') {
      return res.status(400).json({ errors: { form: 'The request could not be read.' } });
    }
    if (err.type === 'entity.too.large') {
      return res.status(413).json({ errors: { form: 'The request is too large.' } });
    }
    console.error(err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  });

  return app;
}
