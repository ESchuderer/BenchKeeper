import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { createApp } from './app.js';
import { createStore } from './store.js';
import { TASTINGS } from './tastings.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD ?? '';
const trustProxy = process.env.TRUST_PROXY ? Number(process.env.TRUST_PROXY) : false;
const clientDir = join(root, 'dist', 'client');
const file = process.env.DATA_FILE ? resolve(process.env.DATA_FILE) : undefined;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');
}

if (!existsSync(join(clientDir, 'index.html'))) {
  console.warn('No client build found in dist/client: run `npm run build` first.');
}

const store = await createStore({ tastings: TASTINGS, file });
const app = createApp({ store, tastings: TASTINGS, staffPassword, clientDir, trustProxy });

const server = app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings listening on http://localhost:${port}`);
  console.log(file ? `Bookings are stored in ${file}` : 'Bookings are kept in memory.');
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
