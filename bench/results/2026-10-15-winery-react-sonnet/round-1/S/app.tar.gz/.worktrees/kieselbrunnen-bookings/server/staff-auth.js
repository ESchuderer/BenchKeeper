import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const COOKIE_NAME = 'kb_staff';
const SESSION_MS = 8 * 60 * 60 * 1000;

const digest = (value) => createHash('sha256').update(value).digest();

/** Constant-time password comparison (both sides hashed to equal length first). */
function passwordMatches(candidate, expected) {
  return timingSafeEqual(digest(candidate), digest(expected));
}

function readCookie(req, name) {
  const header = req.headers.cookie;
  if (!header) return undefined;
  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index > -1 && part.slice(0, index).trim() === name) {
      try {
        return decodeURIComponent(part.slice(index + 1).trim());
      } catch {
        return undefined; // malformed escape sequence: treat as no cookie
      }
    }
  }
  return undefined;
}

/** In-memory staff sessions guarded by one shared password. Empty password disables sign-in. */
export function createStaffAuth({ password }) {
  const sessions = new Map(); // token -> expiry timestamp
  const enabled = typeof password === 'string' && password.length > 0;

  const isValid = (token) => {
    const expires = token ? sessions.get(token) : undefined;
    if (!expires) return false;
    if (expires < Date.now()) {
      sessions.delete(token);
      return false;
    }
    return true;
  };

  return {
    enabled,

    /** Returns a new session token, or null when the password is wrong. */
    login(candidate) {
      if (!enabled || typeof candidate !== 'string' || !passwordMatches(candidate, password)) return null;
      const token = randomBytes(32).toString('hex');
      sessions.set(token, Date.now() + SESSION_MS);
      return token;
    },

    logout(token) {
      sessions.delete(token);
    },

    tokenFrom: (req) => readCookie(req, COOKIE_NAME),
    isValid,

    cookieOptions: { httpOnly: true, sameSite: 'strict', path: '/', maxAge: SESSION_MS },

    requireStaff(req, res, next) {
      if (isValid(readCookie(req, COOKIE_NAME))) return next();
      res.status(401).json({ error: 'Please sign in.' });
    },
  };
}
