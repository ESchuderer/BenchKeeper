import { randomInt } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';

const REFERENCE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

export class BookingError extends Error {
  constructor(code, seatsLeft) {
    super(code);
    this.code = code; // 'NOT_FOUND' | 'SOLD_OUT' | 'TOO_MANY'
    this.seatsLeft = seatsLeft;
  }
}

function newReference() {
  let suffix = '';
  for (let i = 0; i < 6; i++) suffix += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  return `KB-${suffix}`;
}

async function load(file) {
  if (!file) return [];
  let raw;
  try {
    raw = await readFile(file, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
  // A corrupt file must stop the app rather than silently drop bookings.
  const data = JSON.parse(raw);
  if (!Array.isArray(data.bookings)) throw new Error(`Invalid data file: ${file}`);
  return data.bookings;
}

async function save(file, bookings) {
  if (!file) return;
  await mkdir(dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  await writeFile(tmp, JSON.stringify({ bookings }, null, 2));
  await rename(tmp, file);
}

/**
 * Booking store. Reads are synchronous on in-memory state; mutations are queued so that the
 * seat check and the write always happen together (no overbooking under concurrency).
 * Pass `file` to persist state as JSON.
 */
export async function createStore({ tastings, file } = {}) {
  const byId = new Map(tastings.map((t) => [t.id, t]));
  let bookings = await load(file);
  let queue = Promise.resolve();

  const taken = (tastingId) =>
    bookings.filter((b) => b.tastingId === tastingId).reduce((sum, b) => sum + b.guests, 0);

  const seatsLeft = (tastingId) => {
    const tasting = byId.get(tastingId);
    return tasting ? Math.max(0, tasting.capacity - taken(tastingId)) : undefined;
  };

  const enqueue = (task) => {
    const run = queue.then(task);
    queue = run.catch(() => {});
    return run;
  };

  return {
    list: () => bookings.map((b) => ({ ...b })),
    seatsLeft,

    create: ({ tastingId, name, email, guests }) =>
      enqueue(async () => {
        const left = seatsLeft(tastingId);
        if (left === undefined) throw new BookingError('NOT_FOUND');
        if (left === 0) throw new BookingError('SOLD_OUT', 0);
        if (guests > left) throw new BookingError('TOO_MANY', left);

        let reference = newReference();
        while (bookings.some((b) => b.reference === reference)) reference = newReference();
        const booking = { reference, tastingId, name, email, guests, createdAt: new Date().toISOString() };
        const next = [...bookings, booking];
        await save(file, next); // persist first: on failure memory is untouched
        bookings = next;
        return { ...booking };
      }),

    cancel: (reference) =>
      enqueue(async () => {
        if (!bookings.some((b) => b.reference === reference)) return false;
        const next = bookings.filter((b) => b.reference !== reference);
        await save(file, next);
        bookings = next;
        return true;
      }),
  };
}
