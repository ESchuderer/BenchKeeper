import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import TastingsPage from './pages/TastingsPage.jsx';
import BookingPage from './pages/BookingPage.jsx';
import StaffPage from './pages/StaffPage.jsx';
import NotFoundPage from './pages/NotFoundPage.jsx';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingsPage />} />
        <Route path="book/:id" element={<BookingPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
