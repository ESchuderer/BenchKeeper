export class ApiError extends Error {
  /** @param {number} status HTTP status, 0 for network failures */
  constructor(status, body = {}) {
    super(body.error ?? `Request failed (${status})`);
    this.status = status;
    this.errors = body.errors ?? {};
  }
}

async function request(method, path, body) {
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: 'same-origin',
    });
  } catch {
    throw new ApiError(0, { error: 'Network error' });
  }
  const text = res.status === 204 ? '' : await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : undefined;
  } catch {
    data = undefined;
  }
  if (!res.ok) throw new ApiError(res.status, data ?? {});
  return data;
}

export const api = {
  getTastings: () => request('GET', '/api/tastings'),
  book: (tastingId, values) => request('POST', `/api/tastings/${encodeURIComponent(tastingId)}/bookings`, values),
  login: (password) => request('POST', '/api/staff/login', { password }),
  logout: () => request('POST', '/api/staff/logout'),
  session: () => request('GET', '/api/staff/session'),
  getBookings: () => request('GET', '/api/staff/bookings'),
  cancel: (reference) => request('DELETE', `/api/staff/bookings/${encodeURIComponent(reference)}`),
};
