export function Icon({ name }) {
  const paths = {
    error: 'M12 3 2 21h20L12 3Zm0 6v6m0 3v.01',
    success: 'M5 12.5 10 17.5 19 7',
    info: 'M12 8v.01M12 11v6',
  };
  return (
    <svg className="icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"
      fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {name === 'info' && <circle cx="12" cy="12" r="9" />}
      {name === 'success' && <circle cx="12" cy="12" r="10" />}
      <path d={paths[name]} />
    </svg>
  );
}

/** Inline error shown directly under a form field. Render with the id the field points at. */
export function FieldError({ id, children }) {
  if (!children) return null;
  return (
    <p className="field-error" id={id}>
      <Icon name="error" />
      <span>{children}</span>
    </p>
  );
}

/** Block-level message. kind: 'error' (announced as alert) | 'success' | 'info'. */
export function Notice({ kind = 'info', title, children, action }) {
  return (
    <div className={`notice notice-${kind}`} role={kind === 'error' ? 'alert' : 'status'}>
      <Icon name={kind === 'error' ? 'error' : kind} />
      <div className="notice-body">
        {title && <strong>{title}</strong>}
        {children && <p>{children}</p>}
      </div>
      {action}
    </div>
  );
}

export function Loading({ children = 'Loading…' }) {
  return (
    <p className="loading" role="status">
      <span className="spinner" aria-hidden="true" />
      {children}
    </p>
  );
}
