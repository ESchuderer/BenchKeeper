import { Link, NavLink, Outlet } from 'react-router-dom';

export default function Layout() {
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <header className="site-header">
        <div className="container header-inner">
          <Link to="/" className="brand">
            <span className="brand-mark" aria-hidden="true">K</span>
            <span>
              <span className="brand-name">Weingut Kieselbrunnen</span>
              <span className="brand-tag">Family winery &middot; Wine tastings</span>
            </span>
          </Link>
          <nav aria-label="Main">
            <NavLink to="/" end>Tastings</NavLink>
            <NavLink to="/staff">Staff</NavLink>
          </nav>
        </div>
      </header>
      <main id="main" className="container main">
        <Outlet />
      </main>
      <footer className="site-footer">
        <div className="container">
          <p>Weingut Kieselbrunnen &middot; A family winery</p>
          <p className="muted">Please enjoy responsibly.</p>
        </div>
      </footer>
    </>
  );
}
