import { Link } from 'react-router-dom';
import { describeStart } from '../../shared/datetime.js';
import { formatEur } from '../../shared/money.js';

export function When({ startsAt }) {
  const { date, time, weekday } = describeStart(startsAt);
  return (
    <>
      <time dateTime={startsAt}>{`${date} ${time}`}</time>
      <span className="weekday">{weekday}</span>
    </>
  );
}

export default function TastingCard({ tasting }) {
  const soldOut = tasting.seatsLeft <= 0;
  const low = !soldOut && tasting.seatsLeft <= 3;
  return (
    <article className={`card tasting${soldOut ? ' is-full' : ''}`}>
      <div className="card-top">
        <h2>{tasting.title}</h2>
        {soldOut && <span className="badge badge-full">Fully booked</span>}
      </div>
      <p className="when"><When startsAt={tasting.startsAt} /></p>
      <dl className="facts">
        <div>
          <dt>Price</dt>
          <dd>{formatEur(tasting.pricePerGuest)} per guest</dd>
        </div>
        <div>
          <dt>Availability</dt>
          <dd className={low ? 'seats seats-low' : 'seats'}>{tasting.seatsLeft} seats left</dd>
        </div>
      </dl>
      {soldOut ? (
        <p className="muted card-note">This tasting is sold out.</p>
      ) : (
        <Link className="button" to={`/book/${tasting.id}`}>
          Book {tasting.title}
        </Link>
      )}
    </article>
  );
}
