import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { bookingSchema, MAX_GUESTS } from '../../shared/booking-schema.js';
import { formatEur } from '../../shared/money.js';
import { ApiError, api } from '../api.js';
import { useTastings } from '../useTastings.js';
import { When } from '../components/TastingCard.jsx';
import { FieldError, Icon, Loading, Notice } from '../components/Feedback.jsx';

const FIELDS = ['name', 'email', 'guests'];

export default function BookingPage() {
  const { id } = useParams();
  const { status, tastings, reload, refresh } = useTastings();
  const [booking, setBooking] = useState(null);

  if (booking) return <Confirmation booking={booking} />;
  if (status === 'loading') return <Loading>Loading tasting…</Loading>;
  if (status === 'error') {
    return (
      <Notice
        kind="error"
        title="We could not load this tasting."
        action={<button type="button" className="button button-secondary" onClick={reload}>Try again</button>}
      >
        Please check your connection and try again.
      </Notice>
    );
  }

  const tasting = tastings.find((t) => t.id === id);
  if (!tasting) {
    return (
      <section className="narrow">
        <h1>Tasting not found</h1>
        <p className="lead">We could not find that tasting.</p>
        <Link className="button" to="/">Back to all tastings</Link>
      </section>
    );
  }
  if (tasting.seatsLeft <= 0) {
    return (
      <section className="narrow">
        <Header tasting={tasting} />
        <Notice kind="info" title="This tasting is fully booked.">
          Every seat has been taken. Please have a look at our other tastings.
        </Notice>
        <p><Link className="button button-secondary" to="/">Back to all tastings</Link></p>
      </section>
    );
  }
  return <BookingForm tasting={tasting} onBooked={setBooking} refresh={refresh} />;
}

function Header({ tasting }) {
  return (
    <header className="page-head">
      <p className="eyebrow">Book your seats</p>
      <h1>{tasting.title}</h1>
      <p className="when"><When startsAt={tasting.startsAt} /></p>
    </header>
  );
}

function BookingForm({ tasting, onBooked, refresh }) {
  const [formError, setFormError] = useState('');
  const {
    register,
    handleSubmit,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: '', email: '', guests: 1 },
  });

  const guests = Number(watch('guests'));
  const total = Number.isInteger(guests) && guests >= 1 && guests <= MAX_GUESTS ? guests * tasting.pricePerGuest : null;

  const onSubmit = async (values) => {
    setFormError('');
    try {
      const booking = await api.book(tasting.id, values);
      window.scrollTo?.(0, 0);
      onBooked(booking);
    } catch (err) {
      const serverErrors = err instanceof ApiError ? err.errors : {};
      const fieldKeys = Object.keys(serverErrors).filter((k) => FIELDS.includes(k));
      fieldKeys.forEach((field, i) =>
        setError(field, { type: 'server', message: serverErrors[field] }, { shouldFocus: i === 0 }),
      );
      if (err instanceof ApiError && err.status === 409) refresh();
      if (fieldKeys.length === 0) {
        setFormError(serverErrors.form ?? 'Something went wrong. Please try again.');
      }
    }
  };

  const fieldProps = (name) => ({
    'aria-invalid': errors[name] ? 'true' : 'false',
    'aria-describedby': errors[name] ? `${name}-error` : name === 'guests' ? 'guests-hint' : undefined,
    className: errors[name] ? 'input has-error' : 'input',
  });

  return (
    <section className="narrow">
      <Header tasting={tasting} />
      <dl className="facts facts-inline">
        <div><dt>Price</dt><dd>{formatEur(tasting.pricePerGuest)} per guest</dd></div>
        <div><dt>Availability</dt><dd>{tasting.seatsLeft} seats left</dd></div>
      </dl>

      <form className="card form" onSubmit={handleSubmit(onSubmit)} noValidate>
        {formError && <Notice kind="error" title={formError} />}

        <div className="field">
          <label htmlFor="name">Name</label>
          <input id="name" type="text" autoComplete="name" {...register('name')} {...fieldProps('name')} />
          <FieldError id="name-error">{errors.name?.message}</FieldError>
        </div>

        <div className="field">
          <label htmlFor="email">Email</label>
          <input id="email" type="email" autoComplete="email" inputMode="email" {...register('email')} {...fieldProps('email')} />
          <FieldError id="email-error">{errors.email?.message}</FieldError>
        </div>

        <div className="field field-narrow">
          <label htmlFor="guests">Guests</label>
          <input id="guests" type="number" inputMode="numeric" min={1} max={MAX_GUESTS} step={1}
            {...register('guests')} {...fieldProps('guests')} />
          {errors.guests ? (
            <FieldError id="guests-error">{errors.guests.message}</FieldError>
          ) : (
            <p className="hint" id="guests-hint">1 to {MAX_GUESTS} guests</p>
          )}
        </div>

        <div className="form-footer">
          <p className="total" aria-live="polite">
            {total === null ? 'Total: –' : `Total: ${formatEur(total)}`}
          </p>
          <button type="submit" className="button" disabled={isSubmitting}>
            {isSubmitting ? 'Booking…' : 'Book'}
          </button>
        </div>
      </form>
      <p><Link to="/">Back to all tastings</Link></p>
    </section>
  );
}

function Confirmation({ booking }) {
  const heading = useRef(null);
  useEffect(() => heading.current?.focus(), []);
  return (
    <section className="narrow confirmation card">
      <p className="success-mark" aria-hidden="true"><Icon name="success" /></p>
      <h1 tabIndex={-1} ref={heading}>Booking confirmed</h1>
      <p className="lead">Thank you, {booking.name}. We look forward to welcoming you at the winery.</p>
      <dl className="summary">
        <div><dt>Tasting</dt><dd>{booking.tasting.title}</dd></div>
        <div><dt>Date</dt><dd><When startsAt={booking.tasting.startsAt} /></dd></div>
        <div><dt>Guests</dt><dd>{booking.guests}</dd></div>
        <div><dt>Total price</dt><dd>{formatEur(booking.total)}</dd></div>
        <div><dt>Booking reference</dt><dd className="reference">{booking.reference}</dd></div>
      </dl>
      <p className="muted">Please keep your booking reference for your visit.</p>
      <Link className="button button-secondary" to="/">Back to all tastings</Link>
    </section>
  );
}
