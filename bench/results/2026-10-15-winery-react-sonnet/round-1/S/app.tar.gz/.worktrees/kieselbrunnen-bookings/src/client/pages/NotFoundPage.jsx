import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <section className="narrow">
      <h1>Page not found</h1>
      <p className="lead">We could not find the page you were looking for.</p>
      <Link className="button" to="/">Back to all tastings</Link>
    </section>
  );
}
