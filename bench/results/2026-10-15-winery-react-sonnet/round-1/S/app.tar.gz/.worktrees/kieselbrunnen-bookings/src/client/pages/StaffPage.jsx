import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { ApiError, api } from '../api.js';
import { When } from '../components/TastingCard.jsx';
import { FieldError, Loading, Notice } from '../components/Feedback.jsx';

export default function StaffPage() {
  // 'checking' | 'signed-out' | 'signed-in'
  const [auth, setAuth] = useState('checking');
  const signedOut = useCallback(() => setAuth('signed-out'), []);

  useEffect(() => {
    let active = true;
    api
      .session()
      .then(() => active && setAuth('signed-in'))
      .catch(() => active && setAuth('signed-out'));
    return () => {
      active = false;
    };
  }, []);

  if (auth === 'checking') return <Loading />;
  if (auth === 'signed-out') return <SignIn onSignedIn={() => setAuth('signed-in')} />;
  return <Dashboard onSignedOut={signedOut} />;
}

function SignIn({ onSignedIn }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({ defaultValues: { password: '' } });

  const onSubmit = async ({ password }) => {
    try {
      await api.login(password);
      onSignedIn();
    } catch (err) {
      const message =
        err instanceof ApiError && err.errors.password ? err.errors.password : 'Something went wrong. Please try again.';
      setError('password', { type: 'server', message }, { shouldFocus: true });
    }
  };

  return (
    <section className="narrow">
      <header className="page-head">
        <p className="eyebrow">Staff area</p>
        <h1>Staff sign in</h1>
      </header>
      <form className="card form" onSubmit={handleSubmit(onSubmit)} noValidate>
        <div className="field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className={errors.password ? 'input has-error' : 'input'}
            aria-invalid={errors.password ? 'true' : 'false'}
            aria-describedby={errors.password ? 'password-error' : undefined}
            {...register('password', { required: 'Please enter the password.' })}
          />
          <FieldError id="password-error">{errors.password?.message}</FieldError>
        </div>
        <div className="form-footer">
          <span />
          <button type="submit" className="button" disabled={isSubmitting}>
            {isSubmitting ? 'Signing in…' : 'Sign in'}
          </button>
        </div>
      </form>
    </section>
  );
}

function Dashboard({ onSignedOut }) {
  const [groups, setGroups] = useState(null);
  const [loadError, setLoadError] = useState(false);
  const [cancelError, setCancelError] = useState('');
  const [busy, setBusy] = useState(null);
  const [cancelled, setCancelled] = useState(false);

  const load = useCallback(async () => {
    try {
      setGroups(await api.getBookings());
      setLoadError(false);
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) onSignedOut();
      else setLoadError(true);
    }
  }, [onSignedOut]);

  useEffect(() => {
    load();
  }, [load]);

  const cancel = async (reference) => {
    setCancelError('');
    setCancelled(false);
    setBusy(reference);
    try {
      await api.cancel(reference);
      await load();
      setCancelled(true);
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) onSignedOut();
      else if (err instanceof ApiError && err.status === 404) await load();
      else setCancelError('We could not cancel that booking. Please try again.');
    } finally {
      setBusy(null);
    }
  };

  const signOut = async () => {
    try {
      await api.logout();
    } finally {
      onSignedOut();
    }
  };

  const total = groups?.reduce((sum, g) => sum + g.bookings.length, 0);

  return (
    <>
      <header className="page-head page-head-row">
        <div>
          <p className="eyebrow">Staff area</p>
          <h1>Bookings</h1>
          {groups && <p className="lead">{total === 1 ? '1 booking' : `${total} bookings`} across {groups.length} tastings.</p>}
        </div>
        <button type="button" className="button button-secondary" onClick={signOut}>Sign out</button>
      </header>

      {cancelError && <Notice kind="error" title={cancelError} />}
      {cancelled && <Notice kind="success" title="Booking cancelled. The seats are free again." />}
      {loadError && (
        <Notice
          kind="error"
          title="We could not load the bookings."
          action={<button type="button" className="button button-secondary" onClick={load}>Try again</button>}
        />
      )}
      {!groups && !loadError && <Loading>Loading bookings…</Loading>}

      {groups?.map(({ tasting, bookings }) => (
        <section className="card staff-group" key={tasting.id} aria-labelledby={`t-${tasting.id}`}>
          <header className="staff-group-head">
            <div>
              <h2 id={`t-${tasting.id}`}>{tasting.title}</h2>
              <p className="when"><When startsAt={tasting.startsAt} /></p>
            </div>
            <p className={tasting.seatsLeft === 0 ? 'badge badge-full' : 'badge'}>
              {tasting.capacity - tasting.seatsLeft} of {tasting.capacity} seats booked
            </p>
          </header>
          {bookings.length === 0 ? (
            <p className="empty">No bookings yet</p>
          ) : (
            <table className="bookings">
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Guests</th>
                  <th scope="col">Reference</th>
                  <th scope="col"><span className="visually-hidden">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr key={b.reference}>
                    <td data-label="Name" id={`name-${b.reference}`}>{b.name}</td>
                    <td data-label="Email">{b.email}</td>
                    <td data-label="Guests">{b.guests}</td>
                    <td data-label="Reference" className="reference" id={`ref-${b.reference}`}>{b.reference}</td>
                    <td className="actions">
                      <button
                        type="button"
                        className="button button-danger"
                        aria-describedby={`name-${b.reference} ref-${b.reference}`}
                        disabled={busy === b.reference}
                        onClick={() => cancel(b.reference)}
                      >
                        Cancel
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      ))}
    </>
  );
}
