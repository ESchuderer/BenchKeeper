import { useTastings } from '../useTastings.js';
import TastingCard from '../components/TastingCard.jsx';
import { Loading, Notice } from '../components/Feedback.jsx';

export default function TastingsPage() {
  const { status, tastings, reload } = useTastings();
  return (
    <>
      <section className="hero">
        <p className="eyebrow">Weingut Kieselbrunnen</p>
        <h1>Wine tastings at the winery</h1>
        <p className="lead">
          Join us in our cellar and at our tables for an evening with the wines of our family estate. Choose a tasting and
          reserve your seats online.
        </p>
      </section>
      {status === 'loading' && <Loading>Loading tastings…</Loading>}
      {status === 'error' && (
        <Notice
          kind="error"
          title="We could not load the tastings."
          action={<button type="button" className="button button-secondary" onClick={reload}>Try again</button>}
        >
          Please check your connection and try again.
        </Notice>
      )}
      {status === 'ready' && (
        <div className="grid">
          {tastings.map((t) => (
            <TastingCard key={t.id} tasting={t} />
          ))}
        </div>
      )}
    </>
  );
}
