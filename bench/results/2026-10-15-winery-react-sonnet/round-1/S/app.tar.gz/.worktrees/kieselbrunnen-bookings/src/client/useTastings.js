import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api.js';

/** Loads the tastings. `status` is 'loading' | 'ready' | 'error'; `reload` refetches quietly. */
export function useTastings() {
  const [state, setState] = useState({ status: 'loading', tastings: [] });

  const latest = useRef(0);

  const load = useCallback(async ({ quiet = false } = {}) => {
    const request = ++latest.current;
    if (!quiet) setState((s) => ({ ...s, status: 'loading' }));
    try {
      const tastings = await api.getTastings();
      if (request === latest.current) setState({ status: 'ready', tastings });
    } catch {
      if (request === latest.current) {
        setState((s) => (quiet && s.status === 'ready' ? s : { status: 'error', tastings: [] }));
      }
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { ...state, reload: () => load(), refresh: () => load({ quiet: true }) };
}
