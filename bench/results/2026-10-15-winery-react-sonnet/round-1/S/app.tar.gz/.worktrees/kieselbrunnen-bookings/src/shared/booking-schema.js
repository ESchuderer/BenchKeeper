import { z } from 'zod';

export const MAX_GUESTS = 8;

const guests = z.preprocess(
  (value) => {
    if (typeof value === 'string' && /^\s*\d+\s*$/.test(value)) return Number(value);
    return value;
  },
  z
    .number({ invalid_type_error: 'Please choose between 1 and 8 guests.', required_error: 'Please choose between 1 and 8 guests.' })
    .int('Please choose between 1 and 8 guests.')
    .min(1, 'Please choose between 1 and 8 guests.')
    .max(MAX_GUESTS, 'Please choose between 1 and 8 guests.'),
);

export const bookingSchema = z.object({
  name: z
    .string({ required_error: 'Please enter your name.', invalid_type_error: 'Please enter your name.' })
    .trim()
    .min(1, 'Please enter your name.')
    .max(100, 'Please keep the name under 100 characters.'),
  email: z
    .string({ required_error: 'Please enter a valid email address.', invalid_type_error: 'Please enter a valid email address.' })
    .trim()
    .max(254, 'Please enter a valid email address.')
    .regex(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Please enter a valid email address.'),
  guests,
});

/** Reduce a failed safeParse result to `{ field: firstMessage }`. */
export function fieldErrors(result) {
  const errors = {};
  if (result.success) return errors;
  for (const issue of result.error.issues) {
    const key = issue.path[0] ?? 'form';
    if (!(key in errors)) errors[key] = issue.message;
  }
  return errors;
}
