const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/** Split a local "YYYY-MM-DDTHH:mm" start into display parts (no timezone conversion). */
export function describeStart(startsAt) {
  const [date, time] = startsAt.split('T');
  const [y, m, d] = date.split('-').map(Number);
  return { date, time, weekday: WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()] };
}
