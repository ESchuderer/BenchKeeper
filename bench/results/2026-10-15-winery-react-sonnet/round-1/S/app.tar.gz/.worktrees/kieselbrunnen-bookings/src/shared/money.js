/** Format an amount in cents as "EUR 25" or "EUR 12.50". */
export function formatEur(cents) {
  const euros = cents / 100;
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`;
}
