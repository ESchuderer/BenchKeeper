// @vitest-environment jsdom
import { describe, it, expect, afterEach, vi } from 'vitest';
import { screen, within, cleanup, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { stubApi, tastings, renderApp, calls } from './helpers.jsx';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe('start page', () => {
  it('lists every tasting with title, date and time, price and seats left', async () => {
    stubApi({ 'GET /api/tastings': [200, tastings()] });
    renderApp('/');
    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('article');
    expect(within(riesling).getByText('2026-11-06 18:00')).toBeInTheDocument();
    expect(within(riesling).getByText(/EUR 25\b/)).toBeInTheDocument();
    expect(within(riesling).getByText('12 seats left')).toBeInTheDocument();
    expect(within(riesling).getByRole('link', { name: 'Book Riesling Evening' })).toHaveAttribute(
      'href',
      '/book/riesling-evening',
    );
    expect(screen.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toBeInTheDocument();
    expect(screen.getByText('8 seats left')).toBeInTheDocument();
    expect(screen.getByText('2026-12-05 17:00')).toBeInTheDocument();
    expect(screen.getByText(/EUR 28\b/)).toBeInTheDocument();
  });

  it('marks a fully booked tasting and offers no booking link', async () => {
    stubApi({ 'GET /api/tastings': [200, tastings({ seatsLeft: 0 })] });
    renderApp('/');
    const card = (await screen.findByRole('heading', { name: 'Red Wine Cellar Tour' })).closest('article');
    expect(within(card).getByText('Fully booked')).toBeInTheDocument();
    expect(within(card).queryByRole('link', { name: /Book/ })).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toBeInTheDocument();
  });

  it('shows an error with a retry when loading fails', async () => {
    const fetchMock = stubApi({ 'GET /api/tastings': [500, { error: 'boom' }] });
    renderApp('/');
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
    fetchMock.mockClear();
    stubApi({ 'GET /api/tastings': [200, tastings()] });
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
  });

  it('navigates from "Book <title>" to that tasting\'s form', async () => {
    stubApi({ 'GET /api/tastings': [200, tastings()] });
    renderApp('/');
    await userEvent.click(await screen.findByRole('link', { name: 'Book Riesling Evening' }));
    expect(await screen.findByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Book' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /Riesling Evening/ })).toBeInTheDocument();
  });
});

describe('booking form', () => {
  const open = async (list = tastings(), extra = {}) => {
    const fetchMock = stubApi({ 'GET /api/tastings': [200, list], ...extra });
    renderApp('/book/riesling-evening');
    await screen.findByLabelText('Name');
    return fetchMock;
  };

  it('shows an error next to each invalid field and sends nothing', async () => {
    const fetchMock = await open();
    await userEvent.clear(screen.getByLabelText('Guests'));
    await userEvent.type(screen.getByLabelText('Email'), 'not-an-email');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    const name = screen.getByLabelText('Name');
    const email = screen.getByLabelText('Email');
    const guests = screen.getByLabelText('Guests');
    await waitFor(() => expect(name).toHaveAccessibleDescription('Please enter your name.'));
    expect(email).toHaveAccessibleDescription('Please enter a valid email address.');
    expect(guests).toHaveAccessibleDescription('Please choose between 1 and 8 guests.');
    expect(name).toHaveAttribute('aria-invalid', 'true');
    expect(calls(fetchMock, 'POST /api/tastings/riesling-evening/bookings')).toHaveLength(0);
  });

  it('rejects 9 guests', async () => {
    await open();
    await userEvent.type(screen.getByLabelText('Name'), 'Anna');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.clear(screen.getByLabelText('Guests'));
    await userEvent.type(screen.getByLabelText('Guests'), '9');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByText('Please choose between 1 and 8 guests.')).toBeInTheDocument();
  });

  it('shows a server seat-limit error next to the Guests field and refreshes the seats', async () => {
    const fetchMock = await open(tastings(), {
      'POST /api/tastings/riesling-evening/bookings': [409, { errors: { guests: 'Only 2 seats left.' } }],
    });
    await userEvent.type(screen.getByLabelText('Name'), 'Anna');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.clear(screen.getByLabelText('Guests'));
    await userEvent.type(screen.getByLabelText('Guests'), '5');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));
    await waitFor(() => expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription('Only 2 seats left.'));
    expect(screen.queryByText('Booking confirmed')).not.toBeInTheDocument();
    await waitFor(() => expect(calls(fetchMock, 'GET /api/tastings').length).toBeGreaterThan(1));
  });

  it('confirms a booking with tasting, guests, total and reference', async () => {
    const fetchMock = await open(tastings(), {
      'POST /api/tastings/riesling-evening/bookings': ({ body }) => [
        201,
        {
          reference: 'KB-7F3K9Q',
          name: body.name,
          email: body.email,
          guests: body.guests,
          pricePerGuest: 2500,
          total: 2500 * body.guests,
          tasting: { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00' },
        },
      ],
    });
    await userEvent.type(screen.getByLabelText('Name'), '  Anna Weber ');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.clear(screen.getByLabelText('Guests'));
    await userEvent.type(screen.getByLabelText('Guests'), '2');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    const region = screen.getByRole('heading', { name: 'Booking confirmed' }).closest('section');
    expect(within(region).getByText('Riesling Evening')).toBeInTheDocument();
    expect(within(region).getByText('2')).toBeInTheDocument();
    expect(within(region).getByText('EUR 50')).toBeInTheDocument();
    expect(within(region).getByText('KB-7F3K9Q')).toBeInTheDocument();
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument();
    expect(screen.getByText(/keep your booking reference/i)).toBeInTheDocument();

    const [[, init]] = calls(fetchMock, 'POST /api/tastings/riesling-evening/bookings');
    expect(JSON.parse(init.body)).toEqual({ name: 'Anna Weber', email: 'anna@example.com', guests: 2 });
  });

  it('shows a general error when the request fails', async () => {
    await open(tastings(), { 'POST /api/tastings/riesling-evening/bookings': [500, { error: 'boom' }] });
    await userEvent.type(screen.getByLabelText('Name'), 'Anna');
    await userEvent.type(screen.getByLabelText('Email'), 'anna@example.com');
    await userEvent.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/something went wrong/i);
  });

  it('shows a notice instead of the form for a fully booked tasting', async () => {
    stubApi({ 'GET /api/tastings': [200, tastings({ seatsLeft: 0 })] });
    renderApp('/book/red-wine-cellar-tour');
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByLabelText('Name')).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: /back to all tastings/i })).toBeInTheDocument();
  });

  it('shows not-found for an unknown tasting', async () => {
    stubApi({ 'GET /api/tastings': [200, tastings()] });
    renderApp('/book/nope');
    expect(await screen.findByText(/could not find that tasting/i)).toBeInTheDocument();
  });
});
