import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { vi } from 'vitest';
import App from '../../src/client/App.jsx';

export const tastings = (overrides = {}) => [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuest: 2500, capacity: 12, seatsLeft: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuest: 3200, capacity: 8, seatsLeft: 8, ...overrides },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuest: 2800, capacity: 10, seatsLeft: 10 },
];

const json = (status, body) =>
  Promise.resolve(
    new Response(body === undefined ? null : JSON.stringify(body), {
      status,
      headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    }),
  );

/**
 * Stub fetch with `handlers`: { "GET /api/tastings": (req) => [status, body] | [status] }.
 * Returns the vi.fn so tests can inspect calls. Unhandled requests fail loudly.
 */
export function stubApi(handlers) {
  const fn = vi.fn((url, init = {}) => {
    const method = (init.method ?? 'GET').toUpperCase();
    const key = `${method} ${url}`;
    const handler = handlers[key];
    if (!handler) throw new Error(`Unhandled request: ${key}`);
    const body = init.body ? JSON.parse(init.body) : undefined;
    const [status, payload] = typeof handler === 'function' ? handler({ url, body }) : handler;
    return json(status, payload);
  });
  vi.stubGlobal('fetch', fn);
  return fn;
}

export const calls = (fn, key) =>
  fn.mock.calls.filter(([url, init]) => `${(init?.method ?? 'GET').toUpperCase()} ${url}` === key);

export function renderApp(path = '/') {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}
