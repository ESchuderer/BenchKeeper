// @vitest-environment jsdom
import { describe, it, expect, afterEach, vi } from 'vitest';
import { screen, within, cleanup, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { stubApi, tastings, renderApp, calls } from './helpers.jsx';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

const group = (t, bookings) => ({ tasting: t, bookings });
const anna = { reference: 'KB-AAAAAA', name: 'Anna Weber', email: 'anna@example.com', guests: 2, createdAt: '2026-10-15T10:00:00Z' };
const ben = { reference: 'KB-BBBBBB', name: 'Ben Fischer', email: 'ben@example.com', guests: 3, createdAt: '2026-10-15T11:00:00Z' };

function bookingsPayload(bookingsByIndex = {}) {
  return tastings().map((t, i) => group(t, bookingsByIndex[i] ?? []));
}

describe('staff page', () => {
  it('asks for a password when not signed in', async () => {
    stubApi({ 'GET /api/staff/session': [401, { error: 'Please sign in.' }] });
    renderApp('/staff');
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
  });

  it('shows an error next to the password for a wrong password', async () => {
    stubApi({
      'GET /api/staff/session': [401, {}],
      'POST /api/staff/login': [401, { errors: { password: 'Incorrect password.' } }],
    });
    renderApp('/staff');
    await userEvent.type(await screen.findByLabelText('Password'), 'nope');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    await waitFor(() => expect(screen.getByLabelText('Password')).toHaveAccessibleDescription('Incorrect password.'));
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument();
  });

  it('requires a password before calling the server', async () => {
    const fetchMock = stubApi({ 'GET /api/staff/session': [401, {}] });
    renderApp('/staff');
    await userEvent.click(await screen.findByRole('button', { name: 'Sign in' }));
    expect(await screen.findByText('Please enter the password.')).toBeInTheDocument();
    expect(calls(fetchMock, 'POST /api/staff/login')).toHaveLength(0);
  });

  it('signs in and shows bookings grouped by tasting', async () => {
    stubApi({
      'GET /api/staff/session': [401, {}],
      'POST /api/staff/login': [204],
      'GET /api/staff/bookings': [200, bookingsPayload({ 0: [anna, ben], 2: [] })],
    });
    renderApp('/staff');
    await userEvent.type(await screen.findByLabelText('Password'), 'sekret');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));

    const riesling = (await screen.findByRole('heading', { name: 'Riesling Evening' })).closest('section');
    expect(within(riesling).getByText('Anna Weber')).toBeInTheDocument();
    expect(within(riesling).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(riesling).getByText('KB-AAAAAA')).toBeInTheDocument();
    expect(within(riesling).getByText('Ben Fischer')).toBeInTheDocument();
    expect(within(riesling).getAllByRole('button', { name: 'Cancel' })).toHaveLength(2);

    const red = screen.getByRole('heading', { name: 'Red Wine Cellar Tour' }).closest('section');
    expect(within(red).getByText('No bookings yet')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Winter Tasting' })).toBeInTheDocument();
  });

  it('is already signed in when a session exists', async () => {
    stubApi({
      'GET /api/staff/session': [200, { ok: true }],
      'GET /api/staff/bookings': [200, bookingsPayload({ 1: [anna] })],
    });
    renderApp('/staff');
    expect(await screen.findByText('Anna Weber')).toBeInTheDocument();
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument();
  });

  it('cancels a booking and updates the list and seats', async () => {
    let cancelled = false;
    const fetchMock = stubApi({
      'GET /api/staff/session': [200, { ok: true }],
      'GET /api/staff/bookings': () => [200, bookingsPayload({ 0: cancelled ? [ben] : [anna, ben] })],
      'DELETE /api/staff/bookings/KB-AAAAAA': () => {
        cancelled = true;
        return [204];
      },
    });
    renderApp('/staff');
    const row = (await screen.findByText('Anna Weber')).closest('tr');
    await userEvent.click(within(row).getByRole('button', { name: 'Cancel' }));
    await waitFor(() => expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument());
    expect(screen.getByText('Ben Fischer')).toBeInTheDocument();
    expect(calls(fetchMock, 'DELETE /api/staff/bookings/KB-AAAAAA')).toHaveLength(1);
    expect(screen.getByRole('status')).toHaveTextContent('Booking cancelled. The seats are free again.');
  });

  it('gives each Cancel button the booking it belongs to as its description', async () => {
    stubApi({
      'GET /api/staff/session': [200, { ok: true }],
      'GET /api/staff/bookings': [200, bookingsPayload({ 0: [anna, ben] })],
    });
    renderApp('/staff');
    const row = (await screen.findByText('Ben Fischer')).closest('tr');
    expect(within(row).getByRole('button', { name: 'Cancel' })).toHaveAccessibleDescription('Ben Fischer KB-BBBBBB');
  });

  it('shows an error when cancelling fails and keeps the booking', async () => {
    stubApi({
      'GET /api/staff/session': [200, { ok: true }],
      'GET /api/staff/bookings': [200, bookingsPayload({ 0: [anna] })],
      'DELETE /api/staff/bookings/KB-AAAAAA': [500, { error: 'x' }],
    });
    renderApp('/staff');
    await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not cancel/i);
    expect(screen.getByText('Anna Weber')).toBeInTheDocument();
  });

  it('returns to the sign-in form when the session has expired', async () => {
    stubApi({
      'GET /api/staff/session': [200, { ok: true }],
      'GET /api/staff/bookings': [200, bookingsPayload({ 0: [anna] })],
      'DELETE /api/staff/bookings/KB-AAAAAA': [401, { error: 'Please sign in.' }],
    });
    renderApp('/staff');
    await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });

  it('signs out', async () => {
    stubApi({
      'GET /api/staff/session': [200, { ok: true }],
      'GET /api/staff/bookings': [200, bookingsPayload()],
      'POST /api/staff/logout': [204],
    });
    renderApp('/staff');
    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });

  it('explains when staff sign-in is not configured', async () => {
    stubApi({
      'GET /api/staff/session': [401, {}],
      'POST /api/staff/login': [503, { errors: { password: 'Staff sign-in is not configured.' } }],
    });
    renderApp('/staff');
    await userEvent.type(await screen.findByLabelText('Password'), 'x');
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByText('Staff sign-in is not configured.')).toBeInTheDocument();
  });
});
