import { test, expect } from '@playwright/test';

const seatsLeft = async (page, title) => {
  await page.goto('/');
  const card = page.locator('article', { has: page.getByRole('heading', { name: title }) });
  const text = await card.getByText(/\d+ seats left/).innerText();
  return Number(text.match(/\d+/)[0]);
};

async function fillBooking(page, { name, email, guests }) {
  await page.getByLabel('Name').fill(name);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Guests').fill(String(guests));
  await page.getByRole('button', { name: 'Book', exact: true }).click();
}

test('start page lists the three tastings from the brief', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
  await expect(page.getByText('2026-11-06 18:00')).toBeVisible();
  await expect(page.getByText('EUR 25 per guest')).toBeVisible();
  await expect(page.getByText('2026-11-14 15:00')).toBeVisible();
  await expect(page.getByText('EUR 32 per guest')).toBeVisible();
  await expect(page.getByText('2026-12-05 17:00')).toBeVisible();
  await expect(page.getByText('EUR 28 per guest')).toBeVisible();
});

test('guest books, sees the confirmation and the seats go down', async ({ page }) => {
  const before = await seatsLeft(page, 'Riesling Evening');
  await page.getByRole('link', { name: 'Book Riesling Evening' }).click();
  await fillBooking(page, { name: 'Anna Weber', email: 'anna@example.com', guests: 2 });

  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  const confirmation = page.locator('section', { has: page.getByRole('heading', { name: 'Booking confirmed' }) });
  await expect(confirmation).toContainText('Riesling Evening');
  await expect(confirmation).toContainText('EUR 50');
  await expect(confirmation).toContainText(/KB-[A-Z0-9]{6}/);

  expect(await seatsLeft(page, 'Riesling Evening')).toBe(before - 2);
});

test('invalid input is rejected next to the field', async ({ page }) => {
  await page.goto('/book/winter-tasting');
  await page.getByLabel('Guests').fill('9');
  await page.getByLabel('Email').fill('nope');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription('Please enter your name.');
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription('Please enter a valid email address.');
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('Please choose between 1 and 8 guests.');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);
});

test('never books more seats than are left; fully booked is shown; staff cancel frees seats', async ({ page, browser }) => {
  // Red Wine Cellar Tour has 8 seats: take 6, then 3 must fail, then 2 succeed -> fully booked.
  await page.goto('/book/red-wine-cellar-tour');
  await fillBooking(page, { name: 'Ben Fischer', email: 'ben@example.com', guests: 6 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/book/red-wine-cellar-tour');
  await fillBooking(page, { name: 'Carla Roth', email: 'carla@example.com', guests: 3 });
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('Only 2 seats left.');
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);

  await page.getByLabel('Guests').fill('2');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  const card = page.locator('article', { has: page.getByRole('heading', { name: 'Red Wine Cellar Tour' }) });
  await expect(card.getByText('Fully booked')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0);

  // staff: wrong password, then right password
  const staff = await (await browser.newContext()).newPage();
  await staff.goto('/staff');
  await staff.getByLabel('Password').fill('wrong');
  await staff.getByRole('button', { name: 'Sign in' }).click();
  await expect(staff.getByLabel('Password')).toHaveAccessibleDescription('Incorrect password.');
  await staff.getByLabel('Password').fill('e2e-secret');
  await staff.getByRole('button', { name: 'Sign in' }).click();

  const group = staff.locator('section', { has: staff.getByRole('heading', { name: 'Red Wine Cellar Tour' }) });
  await expect(group.getByText('Ben Fischer')).toBeVisible();
  await expect(group.getByText('ben@example.com')).toBeVisible();
  await expect(group.getByText('Carla Roth')).toBeVisible(); // her second try for 2 guests succeeded

  await group.locator('tr', { hasText: 'Ben Fischer' }).getByRole('button', { name: 'Cancel' }).click();
  await expect(group.getByText('Ben Fischer')).toHaveCount(0);

  // 6 seats are free again
  expect(await seatsLeft(page, 'Red Wine Cellar Tour')).toBe(6);
  await page.getByRole('link', { name: 'Book Red Wine Cellar Tour' }).click();
  await expect(page.getByLabel('Name')).toBeVisible();
});

test('staff bookings API is closed without a session', async ({ request }) => {
  expect((await request.get('/api/staff/bookings')).status()).toBe(401);
});

test('layout fits a phone without horizontal scrolling', async ({ browser }) => {
  const context = await browser.newContext({ viewport: { width: 375, height: 740 }, isMobile: true, hasTouch: true });
  const page = await context.newPage();
  const noOverflow = () => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);

  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Winter Tasting' })).toBeVisible();
  expect(await noOverflow()).toBe(true);

  await page.goto('/book/winter-tasting');
  await expect(page.getByLabel('Name')).toBeVisible();
  expect(await noOverflow()).toBe(true);

  await page.goto('/staff');
  await page.getByLabel('Password').fill('e2e-secret');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: 'Bookings' })).toBeVisible();
  expect(await noOverflow()).toBe(true);
  await context.close();
});
