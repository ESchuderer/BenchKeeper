import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../../server/app.js';
import { createStore } from '../../server/store.js';
import { TASTINGS } from '../../server/tastings.js';

const RED = 'red-wine-cellar-tour';
const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

async function makeApp(options = {}) {
  const store = await createStore({ tastings: TASTINGS });
  return createApp({ store, tastings: TASTINGS, staffPassword: 'sekret', ...options });
}

async function staffAgent(app) {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password: 'sekret' }).expect(204);
  return agent;
}

describe('GET /api/tastings', () => {
  it('lists the tastings with seats left', async () => {
    const app = await makeApp();
    const res = await request(app).get('/api/tastings').expect(200);
    expect(res.body).toEqual([
      { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', pricePerGuest: 2500, capacity: 12, seatsLeft: 12 },
      { id: RED, title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', pricePerGuest: 3200, capacity: 8, seatsLeft: 8 },
      { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', pricePerGuest: 2800, capacity: 10, seatsLeft: 10 },
    ]);
  });
});

describe('POST /api/tastings/:id/bookings', () => {
  let app;
  beforeEach(async () => {
    app = await makeApp();
  });
  const book = (id, body) => request(app).post(`/api/tastings/${id}/bookings`).send(body);

  it('creates a booking and returns the confirmation data', async () => {
    const res = await book(RED, valid).expect(201);
    expect(res.body).toMatchObject({
      name: 'Anna Weber',
      email: 'anna@example.com',
      guests: 2,
      pricePerGuest: 3200,
      total: 6400,
      tasting: { id: RED, title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00' },
    });
    expect(res.body.reference).toMatch(/^KB-/);
    const list = await request(app).get('/api/tastings');
    expect(list.body.find((t) => t.id === RED).seatsLeft).toBe(6);
  });

  it('computes the total on the server and ignores client-supplied extras', async () => {
    const res = await book(RED, { ...valid, total: 1, pricePerGuest: 1, reference: 'KB-HACKED' }).expect(201);
    expect(res.body.total).toBe(6400);
    expect(res.body.reference).not.toBe('KB-HACKED');
  });

  it('rejects invalid input with an error per field', async () => {
    const res = await book(RED, { name: '', email: 'nope', guests: 0 }).expect(400);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it('rejects more than 8 guests even if seats are free', async () => {
    const res = await book('riesling-evening', { ...valid, guests: 9 }).expect(400);
    expect(res.body.errors.guests).toBe('Please choose between 1 and 8 guests.');
  });

  it('rejects a missing body', async () => {
    const res = await request(app).post(`/api/tastings/${RED}/bookings`).expect(400);
    expect(Object.keys(res.body.errors)).toEqual(expect.arrayContaining(['name', 'email', 'guests']));
  });

  it('rejects malformed JSON with a 400', async () => {
    const res = await request(app)
      .post(`/api/tastings/${RED}/bookings`)
      .set('Content-Type', 'application/json')
      .send('{"name":')
      .expect(400);
    expect(res.body.errors.form).toBeTruthy();
  });

  it('never takes more seats than are left (409 on guests)', async () => {
    await book(RED, { ...valid, guests: 6 }).expect(201);
    const res = await book(RED, { ...valid, guests: 3 }).expect(409);
    expect(res.body.errors.guests).toBe('Only 2 seats left.');
    await book(RED, { ...valid, guests: 2 }).expect(201);
  });

  it('uses singular wording for one seat', async () => {
    await book(RED, { ...valid, guests: 7 }).expect(201);
    const res = await book(RED, { ...valid, guests: 2 }).expect(409);
    expect(res.body.errors.guests).toBe('Only 1 seat left.');
  });

  it('reports a fully booked tasting', async () => {
    await book(RED, { ...valid, guests: 8 }).expect(201);
    const res = await book(RED, valid).expect(409);
    expect(res.body.errors.guests).toBe('This tasting is fully booked.');
  });

  it('returns 404 for an unknown tasting', async () => {
    await book('nope', valid).expect(404);
  });

  it('handles concurrent bookings without overselling', async () => {
    const results = await Promise.all(Array.from({ length: 15 }, () => book(RED, { ...valid, guests: 1 })));
    expect(results.filter((r) => r.status === 201)).toHaveLength(8);
    expect(results.filter((r) => r.status === 409)).toHaveLength(7);
  });
});

describe('staff authentication', () => {
  it('requires a session for staff endpoints', async () => {
    const app = await makeApp();
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete('/api/staff/bookings/KB-AAAAAA').expect(401);
    await request(app).get('/api/staff/session').expect(401);
  });

  it('rejects a wrong password without setting a cookie', async () => {
    const app = await makeApp();
    const res = await request(app).post('/api/staff/login').send({ password: 'wrong' }).expect(401);
    expect(res.headers['set-cookie']).toBeUndefined();
    expect(res.body.errors.password).toBeTruthy();
  });

  it('rejects empty and non-string passwords', async () => {
    const app = await makeApp();
    await request(app).post('/api/staff/login').send({ password: '' }).expect(401);
    await request(app).post('/api/staff/login').send({ password: ['sekret'] }).expect(401);
    await request(app).post('/api/staff/login').send({}).expect(401);
  });

  it('signs in with the right password using an httpOnly strict cookie', async () => {
    const app = await makeApp();
    const res = await request(app).post('/api/staff/login').send({ password: 'sekret' }).expect(204);
    const cookie = res.headers['set-cookie'][0];
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    await request(app).get('/api/staff/bookings').set('Cookie', cookie.split(';')[0]).expect(200);
  });

  it('disables sign-in when STAFF_PASSWORD is not configured', async () => {
    const app = await makeApp({ staffPassword: '' });
    await request(app).post('/api/staff/login').send({ password: '' }).expect(503);
    await request(app).post('/api/staff/login').send({ password: 'undefined' }).expect(503);
  });

  it('logout invalidates the session', async () => {
    const app = await makeApp();
    const agent = await staffAgent(app);
    await agent.get('/api/staff/session').expect(200);
    await agent.post('/api/staff/logout').expect(204);
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('rate-limits repeated failed logins', async () => {
    const app = await makeApp({ loginLimit: 3 });
    for (let i = 0; i < 3; i++) await request(app).post('/api/staff/login').send({ password: 'bad' }).expect(401);
    await request(app).post('/api/staff/login').send({ password: 'bad' }).expect(429);
    await request(app).post('/api/staff/login').send({ password: 'sekret' }).expect(429);
  });

  it('does not count successful logins against the limit', async () => {
    const app = await makeApp({ loginLimit: 2 });
    for (let i = 0; i < 5; i++) await request(app).post('/api/staff/login').send({ password: 'sekret' }).expect(204);
  });
});

describe('staff authentication hardening', () => {
  it('treats a malformed Cookie header as "not signed in" (401, not 500)', async () => {
    const app = await makeApp();
    await request(app).get('/api/staff/bookings').set('Cookie', 'kb_staff=%E0%A4%A').expect(401);
    await request(app).post('/api/staff/logout').set('Cookie', 'kb_staff=%E0%A4%A').expect(204);
  });

  it('marks the session cookie Secure when the request arrived over https via a trusted proxy', async () => {
    const app = await makeApp({ trustProxy: 1 });
    const res = await request(app)
      .post('/api/staff/login')
      .set('X-Forwarded-For', '203.0.113.7')
      .set('X-Forwarded-Proto', 'https')
      .send({ password: 'sekret' })
      .expect(204);
    expect(res.headers['set-cookie'][0]).toMatch(/; Secure/i);
  });

  it('rate-limits per client address when behind a trusted proxy', async () => {
    const app = await makeApp({ trustProxy: 1, loginLimit: 2 });
    const attempt = (ip, password = 'bad') =>
      request(app).post('/api/staff/login').set('X-Forwarded-For', ip).send({ password });
    await attempt('203.0.113.1').expect(401);
    await attempt('203.0.113.1').expect(401);
    await attempt('203.0.113.1').expect(429);
    await attempt('203.0.113.2', 'sekret').expect(204); // another visitor is unaffected
  });
});

describe('staff bookings', () => {
  it('lists bookings grouped by tasting, including empty tastings', async () => {
    const app = await makeApp();
    const agent = await staffAgent(app);
    const made = await request(app).post(`/api/tastings/${RED}/bookings`).send(valid).expect(201);
    const res = await agent.get('/api/staff/bookings').expect(200);
    expect(res.body.map((g) => g.tasting.id)).toEqual(['riesling-evening', RED, 'winter-tasting']);
    expect(res.body[0].bookings).toEqual([]);
    expect(res.body[1].tasting).toMatchObject({ title: 'Red Wine Cellar Tour', capacity: 8, seatsLeft: 6 });
    expect(res.body[1].bookings).toEqual([
      expect.objectContaining({ reference: made.body.reference, name: 'Anna Weber', email: 'anna@example.com', guests: 2 }),
    ]);
  });

  it('cancelling frees the seats', async () => {
    const app = await makeApp();
    const agent = await staffAgent(app);
    const made = await request(app).post(`/api/tastings/${RED}/bookings`).send({ ...valid, guests: 8 }).expect(201);
    await request(app).post(`/api/tastings/${RED}/bookings`).send(valid).expect(409);
    await agent.delete(`/api/staff/bookings/${made.body.reference}`).expect(204);
    const list = await request(app).get('/api/tastings');
    expect(list.body.find((t) => t.id === RED).seatsLeft).toBe(8);
    await request(app).post(`/api/tastings/${RED}/bookings`).send(valid).expect(201);
  });

  it('returns 404 when cancelling an unknown booking', async () => {
    const app = await makeApp();
    const agent = await staffAgent(app);
    await agent.delete('/api/staff/bookings/KB-AAAAAA').expect(404);
  });
});

describe('misc', () => {
  it('returns JSON 404 for unknown API routes', async () => {
    const app = await makeApp();
    const res = await request(app).get('/api/nothing').expect(404);
    expect(res.body.error).toBeTruthy();
  });

  it('sets basic security headers and hides x-powered-by', async () => {
    const app = await makeApp();
    const res = await request(app).get('/api/tastings');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });

  it('does not force https upgrades (the app may be served over plain http)', async () => {
    const app = await makeApp();
    const res = await request(app).get('/api/tastings');
    expect(res.headers['content-security-policy']).toContain("default-src 'self'");
    expect(res.headers['content-security-policy']).not.toContain('upgrade-insecure-requests');
  });

  it('rejects oversized bodies', async () => {
    const app = await makeApp();
    await request(app)
      .post(`/api/tastings/${RED}/bookings`)
      .send({ ...valid, name: 'x'.repeat(50_000) })
      .expect(413);
  });
});
