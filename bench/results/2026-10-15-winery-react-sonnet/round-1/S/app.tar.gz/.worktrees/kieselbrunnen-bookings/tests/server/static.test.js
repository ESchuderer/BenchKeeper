import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { mkdtemp, writeFile, rm, mkdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../../server/app.js';
import { createStore } from '../../server/store.js';
import { TASTINGS } from '../../server/tastings.js';

describe('serving the built client', () => {
  let dir;
  let app;
  beforeAll(async () => {
    dir = await mkdtemp(join(tmpdir(), 'kb-client-'));
    await mkdir(join(dir, 'assets'));
    await writeFile(join(dir, 'index.html'), '<!doctype html><div id="root">SPA</div>');
    await writeFile(join(dir, 'assets', 'app.js'), 'console.log(1)');
    app = createApp({ store: await createStore({ tastings: TASTINGS }), tastings: TASTINGS, staffPassword: 'x', clientDir: dir });
  });
  afterAll(() => rm(dir, { recursive: true, force: true }));

  it.each(['/', '/staff', '/book/riesling-evening'])('serves index.html for %s', async (path) => {
    const res = await request(app).get(path).expect(200);
    expect(res.text).toContain('SPA');
  });

  it('serves static assets', async () => {
    const res = await request(app).get('/assets/app.js').expect(200);
    expect(res.text).toBe('console.log(1)');
  });

  it('serves index.html even when the app lives under a dot-directory', async () => {
    const hidden = join(dir, '.hidden', 'client');
    await mkdir(hidden, { recursive: true });
    await writeFile(join(hidden, 'index.html'), '<div>HIDDEN SPA</div>');
    const hiddenApp = createApp({
      store: await createStore({ tastings: TASTINGS }),
      tastings: TASTINGS,
      staffPassword: 'x',
      clientDir: hidden,
    });
    const res = await request(hiddenApp).get('/staff').expect(200);
    expect(res.text).toContain('HIDDEN SPA');
  });

  it('returns 404 (not index.html) for missing files such as stale assets', async () => {
    await request(app).get('/assets/old-hash.js').expect(404);
    await request(app).get('/favicon.ico').expect(404);
  });

  it('keeps API 404s as JSON, not index.html', async () => {
    const res = await request(app).get('/api/missing').expect(404);
    expect(res.body.error).toBeTruthy();
  });
});
