import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdtemp, rm, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createStore, BookingError } from '../../server/store.js';
import { TASTINGS } from '../../server/tastings.js';

const guest = { name: 'Anna', email: 'anna@example.com' };
const RIES = 'riesling-evening'; // 12 seats
const RED = 'red-wine-cellar-tour'; // 8 seats

describe('store', () => {
  let store;
  beforeEach(async () => {
    store = await createStore({ tastings: TASTINGS });
  });

  it('starts with no bookings and full capacity', async () => {
    expect(store.list()).toEqual([]);
    expect(store.seatsLeft(RIES)).toBe(12);
  });

  it('creates a booking and reduces the seats left', async () => {
    const b = await store.create({ tastingId: RIES, ...guest, guests: 3 });
    expect(b).toMatchObject({ tastingId: RIES, name: 'Anna', email: 'anna@example.com', guests: 3 });
    expect(b.reference).toMatch(/^KB-[A-HJ-KM-NP-Z2-9]{6}$/);
    expect(store.seatsLeft(RIES)).toBe(9);
    expect(store.seatsLeft(RED)).toBe(8);
  });

  it('never accepts more guests than seats left', async () => {
    await store.create({ tastingId: RED, ...guest, guests: 6 });
    await expect(store.create({ tastingId: RED, ...guest, guests: 3 })).rejects.toMatchObject({
      code: 'TOO_MANY',
      seatsLeft: 2,
    });
    expect(store.seatsLeft(RED)).toBe(2);
  });

  it('allows booking exactly the seats left, then reports SOLD_OUT', async () => {
    await store.create({ tastingId: RED, ...guest, guests: 8 });
    expect(store.seatsLeft(RED)).toBe(0);
    await expect(store.create({ tastingId: RED, ...guest, guests: 1 })).rejects.toMatchObject({
      code: 'SOLD_OUT',
      seatsLeft: 0,
    });
  });

  it('rejects unknown tastings', async () => {
    await expect(store.create({ tastingId: 'nope', ...guest, guests: 1 })).rejects.toBeInstanceOf(BookingError);
    await expect(store.create({ tastingId: 'nope', ...guest, guests: 1 })).rejects.toMatchObject({ code: 'NOT_FOUND' });
    expect(store.seatsLeft('nope')).toBeUndefined();
  });

  it('cannot oversell under concurrent requests', async () => {
    const results = await Promise.allSettled(
      Array.from({ length: 20 }, () => store.create({ tastingId: RED, ...guest, guests: 1 })),
    );
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(8);
    expect(results.filter((r) => r.status === 'rejected')).toHaveLength(12);
    expect(store.seatsLeft(RED)).toBe(0);
  });

  it('cancelling a booking frees its seats', async () => {
    const b = await store.create({ tastingId: RED, ...guest, guests: 5 });
    expect(await store.cancel(b.reference)).toBe(true);
    expect(store.seatsLeft(RED)).toBe(8);
    expect(store.list()).toEqual([]);
  });

  it('cancelling an unknown reference returns false', async () => {
    expect(await store.cancel('KB-AAAAAA')).toBe(false);
  });

  it('issues unique references', async () => {
    const refs = new Set();
    for (let i = 0; i < 12; i++) refs.add((await store.create({ tastingId: RIES, ...guest, guests: 1 })).reference);
    expect(refs.size).toBe(12);
  });
});

describe('store with inconsistent data', () => {
  it('never reports negative seats, e.g. when capacity was reduced after bookings were saved', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'kb-'));
    const file = join(dir, 'b.json');
    const big = await createStore({ tastings: TASTINGS, file });
    await big.create({ tastingId: RED, ...guest, guests: 8 });
    const smaller = await createStore({ tastings: TASTINGS.map((t) => (t.id === RED ? { ...t, capacity: 5 } : t)), file });
    expect(smaller.seatsLeft(RED)).toBe(0);
    await expect(smaller.create({ tastingId: RED, ...guest, guests: 1 })).rejects.toMatchObject({ code: 'SOLD_OUT' });
    await rm(dir, { recursive: true, force: true });
  });
});

describe('store file persistence', () => {
  let dir;
  beforeEach(async () => {
    dir = await mkdtemp(join(tmpdir(), 'kb-'));
  });
  afterEach(() => rm(dir, { recursive: true, force: true }));

  it('reloads bookings from the data file, including cancellations', async () => {
    const file = join(dir, 'bookings.json');
    const a = await createStore({ tastings: TASTINGS, file });
    const keep = await a.create({ tastingId: RIES, name: 'Keep', email: 'k@example.com', guests: 4 });
    const drop = await a.create({ tastingId: RIES, name: 'Drop', email: 'd@example.com', guests: 2 });
    await a.cancel(drop.reference);

    const b = await createStore({ tastings: TASTINGS, file });
    expect(b.list().map((x) => x.reference)).toEqual([keep.reference]);
    expect(b.seatsLeft(RIES)).toBe(8);
    expect(JSON.parse(await readFile(file, 'utf8')).bookings).toHaveLength(1);
  });

  it('starts empty when the data file does not exist yet', async () => {
    const s = await createStore({ tastings: TASTINGS, file: join(dir, 'missing', 'b.json') });
    expect(s.list()).toEqual([]);
    await s.create({ tastingId: RIES, ...guest, guests: 1 }); // creates the directory
    expect(s.list()).toHaveLength(1);
  });
});
