import { describe, it, expect } from 'vitest';
import { bookingSchema, fieldErrors } from '../../src/shared/booking-schema.js';

const valid = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

describe('bookingSchema', () => {
  it('accepts valid input and trims strings', () => {
    const r = bookingSchema.safeParse({ name: '  Anna  ', email: ' anna@example.com ', guests: '3' });
    expect(r.success).toBe(true);
    expect(r.data).toEqual({ name: 'Anna', email: 'anna@example.com', guests: 3 });
  });

  it('rejects a blank name', () => {
    expect(fieldErrors(bookingSchema.safeParse({ ...valid, name: '   ' }))).toEqual({
      name: 'Please enter your name.',
    });
  });

  it('rejects an over-long name', () => {
    expect(fieldErrors(bookingSchema.safeParse({ ...valid, name: 'x'.repeat(101) })).name).toMatch(/100/);
  });

  it.each(['', 'nope', 'a@b', 'a b@c.de', '@example.com'])('rejects email %j', (email) => {
    expect(fieldErrors(bookingSchema.safeParse({ ...valid, email }))).toEqual({
      email: 'Please enter a valid email address.',
    });
  });

  it.each([0, 9, -1, 1.5, '', 'abc', null, undefined, NaN, '2x'])('rejects guests %j', (guests) => {
    expect(fieldErrors(bookingSchema.safeParse({ ...valid, guests }))).toEqual({
      guests: 'Please choose between 1 and 8 guests.',
    });
  });

  it.each([1, 8, '1', '8'])('accepts guests %j', (guests) => {
    expect(bookingSchema.safeParse({ ...valid, guests }).success).toBe(true);
  });

  it('reports every invalid field, one message each', () => {
    const errors = fieldErrors(bookingSchema.safeParse({ name: '', email: 'x', guests: 0 }));
    expect(Object.keys(errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it('rejects non-object bodies', () => {
    expect(bookingSchema.safeParse(null).success).toBe(false);
    expect(Object.keys(fieldErrors(bookingSchema.safeParse(undefined)))).not.toHaveLength(0);
  });
});
