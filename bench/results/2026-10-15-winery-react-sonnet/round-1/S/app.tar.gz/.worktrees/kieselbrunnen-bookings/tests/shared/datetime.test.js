import { describe, it, expect } from 'vitest';
import { describeStart } from '../../src/shared/datetime.js';

describe('describeStart', () => {
  it('splits a local ISO start into date, time and weekday without timezone drift', () => {
    expect(describeStart('2026-11-06T18:00')).toEqual({ date: '2026-11-06', time: '18:00', weekday: 'Friday' });
    expect(describeStart('2026-11-14T15:00').weekday).toBe('Saturday');
    expect(describeStart('2026-12-05T17:00').weekday).toBe('Saturday');
  });
});
