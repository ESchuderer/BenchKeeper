import { describe, it, expect } from 'vitest';
import { formatEur } from '../../src/shared/money.js';

describe('formatEur', () => {
  it('formats whole euros without decimals', () => {
    expect(formatEur(2500)).toBe('EUR 25');
    expect(formatEur(5000)).toBe('EUR 50');
  });
  it('shows decimals only when needed', () => {
    expect(formatEur(1250)).toBe('EUR 12.50');
    expect(formatEur(2805)).toBe('EUR 28.05');
  });
});
