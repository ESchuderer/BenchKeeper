import { describe, it, expect } from 'vitest';
import { TASTINGS } from '../../server/tastings.js';

describe('TASTINGS', () => {
  it('offers exactly the three tastings of the brief', () => {
    expect(TASTINGS.map((t) => [t.id, t.title, t.startsAt, t.pricePerGuest, t.capacity])).toEqual([
      ['riesling-evening', 'Riesling Evening', '2026-11-06T18:00', 2500, 12],
      ['red-wine-cellar-tour', 'Red Wine Cellar Tour', '2026-11-14T15:00', 3200, 8],
      ['winter-tasting', 'Winter Tasting', '2026-12-05T17:00', 2800, 10],
    ]);
  });
});
