import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

// Client tests opt in to jsdom with a `// @vitest-environment jsdom` docblock.
export default defineConfig({
  plugins: [react()],
  test: {
    include: ['tests/**/*.test.{js,jsx}'],
    environment: 'node',
    setupFiles: ['tests/setup.js'],
  },
});
