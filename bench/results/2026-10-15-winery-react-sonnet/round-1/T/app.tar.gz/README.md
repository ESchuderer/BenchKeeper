# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff see and cancel the bookings. React Router (framework mode, server-rendered), TypeScript, Tailwind CSS. The specification is in [`SPEC.md`](SPEC.md).

## Run it

Node.js 22.

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start      # http://localhost:3000
```

| Variable | Purpose |
|---|---|
| `STAFF_PASSWORD` | Password for `/staff`. If unset or empty nobody can sign in. |
| `PORT` | Port to listen on (default `3000`). |
| `SESSION_SECRET` | Optional. Signs the staff session cookie. Without it a random secret is created per process. Staff sessions live in memory either way, so they end on restart. |
| `ALLOWED_ACTION_ORIGINS` | Build-time, comma-separated public host names (e.g. `wein.example.com`). Needed only behind a TLS-terminating proxy: React Router rejects form posts whose `Origin` (https) differs from the URL the app sees (http). Run `ALLOWED_ACTION_ORIGINS=wein.example.com npm run build`. The proxy should send `X-Forwarded-Proto: https` so cookies are marked `Secure`. |

Bookings are kept in memory: the app starts with none, and a restart clears them. Run a single instance.

## Develop and test

```sh
npm run dev          # dev server with hot reload
npm run typecheck
npm test             # unit, route and component tests (Vitest)
npm run test:e2e     # builds, starts the app on :4173, runs Playwright (desktop and phone)
```

The e2e tests need Chromium (`npx playwright install chromium`).

## How it works

- `app/domain/`: tasting catalogue, price/date formatting, input validation (pure, shared).
- `app/.server/`: booking store, staff session and sign-in throttle, security headers, bounded form reading (server only).
- `app/routes/`: `home` (list), `book` (form and booking), `confirmation`, `staff` (sign-in, list, cancel).
- Forms are plain HTML forms handled by route actions, so they also work without JavaScript. Validation errors are rendered next to the field.

Decisions worth knowing:

- **Seats are never oversold.** `store.book` checks and inserts synchronously, so concurrent requests cannot interleave. Validation checks the same limit first to show a friendly message.
- **Validation failures return HTTP 200** with the form re-rendered, not 4xx, because a rejected form is an expected result of a submission (and keeps the browser console clean).
- **Double submits book once.** Each rendering of the form carries a random `submissionId`; the store returns the existing booking for a repeated one.
- **Staff sign-in** compares password digests in constant time and starts a server-side session (random id in a signed `HttpOnly`, `SameSite=Lax` cookie, `Secure` over HTTPS, 8 hours, ended by sign-out) and allows 10 failed attempts per 15 minutes. The limit is global, not per client, because the app has no trustworthy client address; the cost is that an attacker can temporarily lock staff out of sign-in, never guests out of booking.
- **Headers:** CSP with a per-request nonce, `nosniff`, frame denial, referrer and permissions policies; staff pages are `no-store`.
- Seat text is literally "`<n>` seats left", also for 1, as specified.

## Known limitations

- Guests book without an account or captcha, so anyone could reserve all seats; staff can cancel such bookings. Add per-client limits or a captcha if this becomes a problem.
- Bookings and staff sessions are in memory: one instance, cleared on restart.
- The sign-in throttle is global (see above).
