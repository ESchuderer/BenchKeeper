# Spec: Weingut Kieselbrunnen – Tasting Bookings

## Objective

A small web app for a family winery. **Guests** book wine tastings online; **staff** see all bookings and cancel them.

Success means: a guest on a phone can find a tasting, book 1–8 seats, and get a confirmation with a reference; staff can sign in at `/staff`, see who is coming per tasting, and cancel a booking (freeing its seats). Seats are never oversold.

### Tastings (fixed catalogue, in code)

| id | Title | Date and time | Price per guest | Seats |
|---|---|---|---|---|
| `riesling-evening` | Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| `red-wine-cellar-tour` | Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| `winter-tasting` | Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

### Guest requirements
- G1 Start page `/` lists every tasting: title, date and time, price per guest, `<n> seats left` (literal format, also for 0 and 1).
- G2 Each tasting with seats has a link "Book <title>" opening the booking form for it. A tasting with 0 seats shows a clear "Fully booked" state instead of the link.
- G3 Booking form: fields labelled `Name`, `Email`, `Guests` (1–8), button `Book`.
- G4 A booking never takes more seats than are left (enforced on the server, atomically).
- G5 Invalid input is rejected; the message is rendered next to the field it concerns (and linked with `aria-describedby`). Entered values are kept.
- G6 On success the guest lands on a confirmation: heading `Booking confirmed`, tasting, number of guests, total price, booking reference.

### Staff requirements
- S1 `/staff` shows a sign-in form (`Password`, `Sign in`). The password is `STAFF_PASSWORD`. If it is unset, nobody can sign in (fail closed).
- S2 Signed in: all bookings grouped by tasting (name, email, guests, reference) and a `Cancel` button per booking. Cancelling removes the booking and frees its seats immediately.
- S3 Wrong password: error next to the field. Repeated failures are throttled.

### Look and feel
Small-winery character: cream paper background, deep burgundy primary, olive accent, serif headings (Cormorant Garamond) over a humanist sans (Source Sans 3), self-hosted fonts. Clear, non-colour-only states for error, success, fully booked and loading/submitting. Mobile first (checked at 320, 768, 1024 px), WCAG 2.1 AA contrast, visible focus, keyboard usable.

## Assumptions (stated, not asked)
1. Bookings are kept in memory (allowed by the brief); the app starts with none, and a restart clears them. A file store was rejected: it adds I/O races and could violate "starts with no bookings".
2. Tastings are always bookable regardless of the current date (no "past event" rule was requested).
3. No payment and no email: the app collects name, email, guests only. The confirmation does not claim an email was sent.
4. One booking = one name/email/guests/reference. No edit, no per-email limit.
5. Cancelled bookings are deleted (not shown as cancelled); the confirmation URL of a cancelled booking returns "not found".
6. Staff is a single shared password; the session is a random id held server-side (in memory, 8 hours, ended by sign-out) in a signed, httpOnly cookie.
7. Dates are shown in the winery's local time without a timezone conversion.
8. Seat text is literally "<n> seats left" even for n = 1, as specified.
9. Currency is shown as `EUR <amount>` as in the brief.

## Tech Stack
- Node.js 22, TypeScript, React 19
- React Router 8 framework mode (SSR, file `routes.ts`, loaders/actions, `<Form>`), served by `react-router-serve` (honours `PORT`, default 3000)
- Zod 4 for input validation at the boundary
- Tailwind CSS 4 (`@tailwindcss/vite`), `@fontsource` fonts
- Tests: Vitest (+ Testing Library, jsdom), Playwright (Chromium) with axe-core for end-to-end and accessibility

## Commands
```
Install:    npm install
Build:      npm run build        # react-router build
Start:      npm start            # PORT=3000 STAFF_PASSWORD=... npm start
Dev:        npm run dev
Typecheck:  npm run typecheck
Unit/int.:  npm test             # vitest run
E2E:        npm run test:e2e     # builds, starts the app, runs Playwright
Audit:      npm audit --omit=dev
```

## Project Structure
```
app/
  routes.ts                 route table
  root.tsx                  document, header/footer shell, error boundary
  entry.server.tsx          streaming render + security headers (CSP nonce)
  app.css                   Tailwind theme tokens + fonts
  domain/                   pure, shared: tastings catalogue, formatting, input validation
  .server/                  server-only: booking store, staff auth/session, rate limiter
  components/               presentational UI (TastingCard, Field, Alert, ...)
  routes/                   home, book, confirmation, staff
tests/                      vitest tests (unit, route integration, components)
e2e/                        Playwright specs
tasks/                      plan.md, todo.md
```

## Contracts

HTML routes (all forms work without client JS; JS only enhances):

| Route | GET | POST |
|---|---|---|
| `/` | tastings with `seatsLeft` | – |
| `/tastings/:id/book` | form with a per-render `submissionId` (404 unknown id; fully-booked notice if 0 seats) | validates, books once per `submissionId`, redirects 303 to `/bookings/:reference`; on invalid input re-renders with `{ fieldErrors, values }` (HTTP 200, see README) |
| `/bookings/:reference` | confirmation (404 unknown/cancelled) | – |
| `/staff` | sign-in form, or bookings if signed in | `intent=sign-in` (wrong password: field error, 200; throttled: 429; no `STAFF_PASSWORD`: 503), `intent=cancel` (`reference`; 401 without session), `intent=sign-out` |

Store interface (single seam between routes and state):
```ts
type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: "unknown-tasting" }
  | { ok: false; reason: "not-enough-seats"; seatsLeft: number };
store.book(input: { tastingId; name; email; guests }): BookResult   // synchronous => atomic
store.cancel(reference): boolean
store.seatsLeft(tastingId): number
store.findByReference(reference): Booking | undefined
store.listByTasting(): { tasting; bookings: Booking[] }[]
```
Booking reference: `KB-` + 6 characters from an unambiguous alphabet, unique across the store.

Validation (server is authoritative): name trimmed, NFC-normalised, 1–100 characters, no control/invisible characters; email valid (umlauts allowed), ≤254; guests integer 1–8 and ≤ seats left.

## Code Style
TypeScript strict, ES modules, named exports for domain code, default exports only for routes. Small pure functions; no abstractions without a second user.
```ts
export function formatPrice(cents: number): string {
  return `EUR ${cents % 100 === 0 ? cents / 100 : (cents / 100).toFixed(2)}`;
}
```
Money is stored in integer cents. Tailwind utilities with theme tokens (`bg-paper`, `text-wine`), no raw hex in components, no inline styles (CSP).

## Testing Strategy
Test-first (red → green) per slice.
- Unit (most): store (capacity, never oversold, cancel frees seats, reference format/uniqueness), validation, formatting, staff auth (password check, unset password, throttling).
- Integration: route `loader`/`action` functions called with real `Request`s against a fresh store (booking happy path, each field error, race on last seats, staff sign-in/cancel, unauthenticated cancel rejected).
- Component: field-level error placement and accessible names (`Book <title>`, labels).
- E2E (few, critical): guest books; sold out state; staff signs in and cancels, seats return; phone viewport.
- Every spec acceptance criterion maps to at least one test.

## Boundaries
- Always: validate on the server; keep values on error; run tests + typecheck before declaring done; read `STAFF_PASSWORD` only from the environment.
- Ask first: new runtime dependencies beyond the stack above; persisting bookings to disk; sending email; payment.
- Never: commit secrets; skip/delete failing tests; log the password; trust client-side validation; expose stack traces.

## Security notes (threat model summary)
- Untrusted input: booking form fields, staff password, route params, cookies. All validated/escaped (React escaping; no `dangerouslySetInnerHTML`).
- Staff area: constant-time password comparison, signed httpOnly `SameSite=Lax` cookie (`Secure` when served over HTTPS), failed-login throttling, `Cache-Control: no-store`, authorisation re-checked on every cancel POST.
- Headers: CSP with per-request nonce, `X-Content-Type-Options`, `Referrer-Policy`, `frame-ancestors 'none'`.
- Data minimisation: name + email only, kept in memory only, deleted on cancel; confirmation page shows no personal data.
- Known limitation: guests book without an account or captcha, so anyone can reserve all 30 seats; staff can cancel such bookings. Per-client limits or captcha are "ask first" items.
- DoS: total bookings are bounded by the seat capacity (30); form bodies are capped at 16 KB and read as a bounded stream.

## Success Criteria
1. Every requirement G1–G6, S1–S3 is covered by an automated test and passes.
2. `npm install && npm run build && STAFF_PASSWORD=x npm start` serves the app on `PORT`.
3. Starting fresh shows 12 / 8 / 10 seats left; no bookings in `/staff`.
4. Booking 8 of 8 seats makes "Red Wine Cellar Tour" fully booked; cancelling restores them.
5. No console errors; usable at 320 px; keyboard-only flow works; `npm audit --omit=dev` has no high/critical findings.

## Open Questions
None blocking. Items 1–2 and 8 of the assumptions are the ones a human may want to change.
