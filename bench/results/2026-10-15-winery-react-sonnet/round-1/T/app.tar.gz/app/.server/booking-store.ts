import { randomInt } from "node:crypto";
import type { Tasting } from "~/domain/tastings";
import { tastings } from "~/domain/tastings";

export type Booking = {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  totalCents: number;
};

export type BookingRequest = Pick<Booking, "tastingId" | "name" | "email" | "guests"> & {
  /** Identifies one rendering of the form, so a repeated post books only once. */
  submissionId?: string;
};

export type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: "unknown-tasting" }
  | { ok: false; reason: "not-enough-seats"; seatsLeft: number };

export type BookingStore = {
  book(request: BookingRequest): BookResult;
  cancel(reference: string): boolean;
  seatsLeft(tastingId: string): number;
  findByReference(reference: string): Booking | undefined;
  listByTasting(): { tasting: Tasting; seatsLeft: number; bookings: Booking[] }[];
};

// No 0/O, 1/I: references get read out over the phone.
const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function newReference(isTaken: (reference: string) => boolean): string {
  for (;;) {
    let code = "";
    for (let i = 0; i < 6; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
    const reference = `KB-${code}`;
    if (!isTaken(reference)) return reference;
  }
}

/**
 * Keeps bookings in memory. `book` is synchronous, so the seat check and the
 * insert can never interleave with another request: seats cannot be oversold.
 */
export function createBookingStore(catalogue: readonly Tasting[]): BookingStore {
  const bookings = new Map<string, Booking>();
  const referenceBySubmission = new Map<string, string>(); // bounded by the live bookings

  const seatsTaken = (tastingId: string) => {
    let taken = 0;
    for (const booking of bookings.values()) {
      if (booking.tastingId === tastingId) taken += booking.guests;
    }
    return taken;
  };

  const seatsLeft = (tastingId: string) => {
    const tasting = catalogue.find((t) => t.id === tastingId);
    return tasting ? tasting.seats - seatsTaken(tastingId) : 0;
  };

  return {
    seatsLeft,

    book({ tastingId, name, email, guests, submissionId }) {
      const repeated = submissionId ? bookings.get(referenceBySubmission.get(submissionId) ?? "") : undefined;
      if (repeated) return { ok: true, booking: { ...repeated } };

      const tasting = catalogue.find((t) => t.id === tastingId);
      if (!tasting) return { ok: false, reason: "unknown-tasting" };

      const left = seatsLeft(tastingId);
      if (guests > left) return { ok: false, reason: "not-enough-seats", seatsLeft: left };

      const reference = newReference((candidate) => bookings.has(candidate));
      const booking: Booking = {
        reference,
        tastingId,
        name,
        email,
        guests,
        totalCents: tasting.priceCents * guests,
      };
      bookings.set(reference, booking);
      if (submissionId) referenceBySubmission.set(submissionId, reference);
      return { ok: true, booking: { ...booking } };
    },

    cancel(reference) {
      for (const [submissionId, booked] of referenceBySubmission) {
        if (booked === reference) referenceBySubmission.delete(submissionId);
      }
      return bookings.delete(reference);
    },

    findByReference(reference) {
      const booking = bookings.get(reference);
      return booking && { ...booking };
    },

    listByTasting() {
      return catalogue.map((tasting) => ({
        tasting,
        seatsLeft: seatsLeft(tasting.id),
        bookings: [...bookings.values()]
          .filter((booking) => booking.tastingId === tasting.id)
          .map((booking) => ({ ...booking })),
      }));
    },
  };
}

// One store per server process, kept across dev-server module reloads.
const globalForStore = globalThis as { __bookingStore?: BookingStore };
export const bookingStore: BookingStore = (globalForStore.__bookingStore ??=
  createBookingStore(tastings));
