/** True when the browser reached the app over HTTPS, directly or through a TLS-terminating proxy. */
export function isHttps(request: Request): boolean {
  return new URL(request.url).protocol === "https:" || request.headers.get("X-Forwarded-Proto") === "https";
}
