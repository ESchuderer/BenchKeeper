const MAX_FORM_BYTES = 16 * 1024; // a booking or sign-in form is a few hundred bytes

/** Reads a form post, stopping as soon as the body exceeds the limit instead of buffering it. */
export async function readForm(request: Request): Promise<FormData> {
  const tooLarge = () => new Response("Request too large.", { status: 413 });

  if (Number(request.headers.get("Content-Length")) > MAX_FORM_BYTES) throw tooLarge();

  const chunks: Uint8Array[] = [];
  let received = 0;
  const reader = request.body?.getReader();
  while (reader) {
    const { done, value } = await reader.read();
    if (done) break;
    received += value.byteLength;
    if (received > MAX_FORM_BYTES) {
      await reader.cancel();
      throw tooLarge();
    }
    chunks.push(value);
  }

  const headers = { "Content-Type": request.headers.get("Content-Type") ?? "" };
  try {
    return await new Response(new Blob(chunks as BlobPart[]), { headers }).formData();
  } catch {
    throw new Response("Bad request.", { status: 400 });
  }
}
