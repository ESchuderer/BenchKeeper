import { randomBytes } from "node:crypto";

export function createNonce(): string {
  return randomBytes(16).toString("base64");
}

/** Headers for every HTML response. The nonce lets React Router's inline hydration scripts run. */
export function securityHeaders({ nonce, https }: { nonce: string; https: boolean }) {
  const headers: Record<string, string> = {
    "Content-Security-Policy": [
      "default-src 'self'",
      `script-src 'self' 'nonce-${nonce}'`,
      "style-src 'self'",
      "img-src 'self'",
      "font-src 'self'",
      "connect-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'none'",
    ].join("; "),
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
  };
  if (https) headers["Strict-Transport-Security"] = "max-age=15552000";
  return headers;
}
