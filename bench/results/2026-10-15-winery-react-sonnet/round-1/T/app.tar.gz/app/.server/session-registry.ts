import { randomBytes } from "node:crypto";

type RegistryOptions = { ttlMs: number; maxSessions: number; now?: () => number };

/**
 * Server-side record of live staff sessions. The cookie only carries an unguessable id,
 * so signing out (or waiting out the lifetime) really ends the session.
 */
export function createSessionRegistry({ ttlMs, maxSessions, now = Date.now }: RegistryOptions) {
  const expiresAt = new Map<string, number>(); // insertion order = oldest first

  return {
    create(): string {
      const id = randomBytes(24).toString("base64url");
      expiresAt.set(id, now() + ttlMs);
      while (expiresAt.size > maxSessions) {
        const oldest = expiresAt.keys().next().value;
        if (oldest === undefined) break;
        expiresAt.delete(oldest);
      }
      return id;
    },

    isValid(id: string | undefined): boolean {
      const expiry = id === undefined ? undefined : expiresAt.get(id);
      if (expiry === undefined) return false;
      if (now() >= expiry) {
        expiresAt.delete(id!);
        return false;
      }
      return true;
    },

    destroy(id: string | undefined) {
      if (id !== undefined) expiresAt.delete(id);
    },
  };
}
