import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { createCookieSessionStorage } from "react-router";
import { isHttps } from "./is-https";
import { createSessionRegistry } from "./session-registry";

const SESSION_HOURS = 8;

/** Compares digests so the comparison takes the same time for every candidate. */
export function isStaffPasswordValid(candidate: string, expected = process.env.STAFF_PASSWORD): boolean {
  if (!expected) return false; // unset or empty: nobody gets in
  const digest = (value: string) => createHash("sha256").update(value).digest();
  return timingSafeEqual(digest(candidate), digest(expected));
}

if (!process.env.STAFF_PASSWORD) {
  console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled until it is set and the server restarted.");
}

export function isStaffPasswordConfigured(): boolean {
  return Boolean(process.env.STAFF_PASSWORD);
}

type ThrottleOptions = { maxFailures: number; windowMs: number; now?: () => number };

/**
 * Counts failed sign-ins in a sliding window. It is deliberately global rather than
 * per client: the app cannot see a trustworthy client address, and a shared staff
 * password should not be guessable at speed. Memory stays bounded by `maxFailures`.
 */
export function createFailureThrottle({ maxFailures, windowMs, now = Date.now }: ThrottleOptions) {
  let failures: number[] = [];
  const prune = () => {
    const cutoff = now() - windowMs;
    failures = failures.filter((time) => time > cutoff);
  };

  return {
    isBlocked() {
      prune();
      return failures.length >= maxFailures;
    },
    recordFailure() {
      prune();
      failures.push(now());
      if (failures.length > maxFailures) failures = failures.slice(-maxFailures);
    },
    reset() {
      failures = [];
    },
    recordedFailures: () => failures.length,
  };
}

const globalForThrottle = globalThis as { __staffThrottle?: ReturnType<typeof createFailureThrottle> };
export const staffThrottle = (globalForThrottle.__staffThrottle ??= createFailureThrottle({
  maxFailures: 10,
  windowMs: 15 * 60 * 1000,
}));

export function resetStaffThrottle() {
  staffThrottle.reset();
}

const globalForSessions = globalThis as { __staffSessions?: ReturnType<typeof createSessionRegistry> };
const staffSessions = (globalForSessions.__staffSessions ??= createSessionRegistry({
  ttlMs: SESSION_HOURS * 60 * 60 * 1000,
  maxSessions: 100,
}));

// The cookie carries only the id of a server-side session and is signed on top of that.
// A fresh signing secret per process also ends all sessions on restart, which is fine for staff.
// Set SESSION_SECRET to keep the signature stable across restarts.
const sessionStorage = createCookieSessionStorage<{ sessionId: string }>({
  cookie: {
    name: "kb_staff",
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_HOURS * 60 * 60,
    secrets: [process.env.SESSION_SECRET || randomBytes(32).toString("hex")],
  },
});

async function readSessionId(request: Request) {
  const session = await sessionStorage.getSession(request.headers.get("Cookie"));
  return session.get("sessionId");
}

export async function isStaffSignedIn(request: Request): Promise<boolean> {
  return staffSessions.isValid(await readSessionId(request));
}

export async function staffSignInCookie(request: Request): Promise<string> {
  const session = await sessionStorage.getSession();
  session.set("sessionId", staffSessions.create());
  return sessionStorage.commitSession(session, { secure: isHttps(request) });
}

export async function staffSignOutCookie(request: Request): Promise<string> {
  const session = await sessionStorage.getSession(request.headers.get("Cookie"));
  staffSessions.destroy(session.get("sessionId"));
  return sessionStorage.destroySession(session, { secure: isHttps(request) });
}
