type Tone = "error" | "success" | "sold";

const tones: Record<Tone, string> = {
  error: "border-error bg-error-soft text-error",
  success: "border-success bg-success-soft text-success",
  sold: "border-sold bg-sold-soft text-sold",
};

const icons: Record<Tone, string> = {
  error: "M12 8v5m0 3.5v.01M10.3 3.9 2.6 17.5A2 2 0 0 0 4.3 20.5h15.4a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z",
  success: "m5 12.5 4.5 4.5L19 7.5",
  sold: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18ZM5.6 5.6l12.8 12.8",
};

type AlertProps = {
  tone: Tone;
  children: React.ReactNode;
  role?: "alert" | "status";
  /** Lets the page move focus here so keyboard and screen reader users hear the message. */
  ref?: React.Ref<HTMLDivElement>;
};

export function Alert({ tone, children, role, ref }: AlertProps) {
  return (
    <div ref={ref} role={role} tabIndex={ref ? -1 : undefined} className={`flex items-start gap-3 rounded-md border-l-4 px-4 py-3 font-semibold ${tones[tone]}`}>
      <svg
        aria-hidden="true"
        viewBox="0 0 24 24"
        className="mt-0.5 size-5 shrink-0"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d={icons[tone]} />
      </svg>
      <div>{children}</div>
    </div>
  );
}
