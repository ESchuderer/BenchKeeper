import { useId } from "react";

type FieldProps = Omit<React.ComponentProps<"input">, "id" | "className"> & {
  label: string;
  name: string;
  error?: string;
  hint?: string;
};

export function Field({ label, error, hint, ...inputProps }: FieldProps) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [error && errorId, hint && hintId].filter(Boolean).join(" ") || undefined;

  return (
    <div className="grid gap-1.5">
      <label htmlFor={id} className="font-semibold">
        {label}
      </label>
      <input
        {...inputProps}
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        className={`min-h-12 w-full rounded-md border bg-white px-3 text-ink placeholder:text-ink-soft/70 ${
          error ? "border-2 border-error" : "border-line hover:border-ink-soft"
        }`}
      />
      {hint && (
        <p id={hintId} className="text-sm text-ink-soft">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} className="flex items-start gap-2 text-sm font-semibold text-error">
          <svg aria-hidden="true" viewBox="0 0 20 20" className="mt-0.5 size-4 shrink-0" fill="currentColor">
            <path d="M10 1.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17Zm-.9 4.5h1.8v5.2H9.1V6Zm0 6.7h1.8v1.8H9.1v-1.8Z" />
          </svg>
          {error}
        </p>
      )}
    </div>
  );
}
