import { Link } from "react-router";

function BrandMark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 40 40" className="size-10 shrink-0" fill="none">
      <circle cx="20" cy="20" r="18.5" stroke="currentColor" strokeWidth="1.5" />
      <ellipse cx="14" cy="24" rx="5.5" ry="4" fill="currentColor" opacity="0.9" />
      <ellipse cx="25" cy="26" rx="6.5" ry="4.5" fill="currentColor" opacity="0.7" />
      <ellipse cx="21" cy="19" rx="4.5" ry="3.5" fill="currentColor" opacity="0.5" />
      <path d="M9 13c3-3 6-3 9 0s6 3 9 0 4-2 5-1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

export function SiteShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-10 focus:rounded-md focus:bg-card focus:px-4 focus:py-2"
      >
        Skip to content
      </a>
      <header className="border-b-4 border-double border-gold/70 bg-card">
        <div className="mx-auto flex max-w-4xl items-center gap-3 px-4 py-4 sm:px-6">
          <Link to="/" className="flex items-center gap-3 text-wine no-underline">
            <BrandMark />
            <span className="grid leading-none">
              <span className="font-serif text-2xl font-bold sm:text-3xl">Weingut Kieselbrunnen</span>
              <span className="mt-1 text-xs tracking-[0.2em] text-ink-soft uppercase">Family winery</span>
            </span>
          </Link>
        </div>
      </header>

      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        {children}
      </main>

      <footer className="border-t border-line bg-paper-deep">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-2 px-4 py-5 text-sm text-ink-soft sm:px-6">
          <p>Weingut Kieselbrunnen, a family winery.</p>
          <Link to="/staff" className="underline underline-offset-4 hover:text-wine">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
