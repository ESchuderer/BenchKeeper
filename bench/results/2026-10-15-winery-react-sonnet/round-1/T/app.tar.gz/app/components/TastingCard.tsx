import { Link } from "react-router";
import { formatDateBadge, formatDateTime, formatPrice, formatSeatsLeft } from "~/domain/format";
import type { Tasting } from "~/domain/tastings";

type TastingCardProps = {
  tasting: Tasting;
  seatsLeft: number;
};

export function TastingCard({ tasting, seatsLeft }: TastingCardProps) {
  const fullyBooked = seatsLeft === 0;
  const { day, month } = formatDateBadge(tasting.startsAt);

  return (
    <article
      className={`grid gap-x-6 gap-y-4 rounded-md border border-line p-5 sm:grid-cols-[5.5rem_1fr_auto] sm:items-center sm:p-6 ${
        fullyBooked ? "bg-paper-deep" : "bg-card"
      }`}
    >
      <div
        aria-hidden="true"
        className="flex w-20 flex-col items-center rounded-sm border border-gold/60 py-2 text-wine sm:w-auto"
      >
        <span className="text-3xl leading-none font-bold">{day}</span>
        <span className="text-sm font-semibold tracking-widest uppercase">{month}</span>
      </div>

      <div className="grid gap-1">
        <h2 className="text-3xl">{tasting.title}</h2>
        <p className="text-ink-soft">
          <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time>
        </p>
        <p>
          <span className="text-xl font-bold">{formatPrice(tasting.priceCents)}</span>{" "}
          <span className="text-ink-soft">per guest</span>
        </p>
      </div>

      <div className="grid gap-3 sm:justify-items-end">
        <p className={seatsLeft > 0 && seatsLeft <= 3 ? "font-semibold text-wine" : "text-ink-soft"}>
          {formatSeatsLeft(seatsLeft)}
        </p>
        {fullyBooked ? (
          <p className="inline-flex min-h-11 items-center gap-2 rounded-md bg-sold-soft px-4 font-semibold text-sold ring-1 ring-sold/40">
            <svg aria-hidden="true" viewBox="0 0 20 20" className="size-4" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="10" cy="10" r="7.5" />
              <path d="M5 15 15 5" />
            </svg>
            Fully booked
          </p>
        ) : (
          <Link
            to={`/tastings/${tasting.id}/book`}
            className="inline-flex min-h-11 items-center justify-center rounded-md bg-wine px-5 font-semibold text-white transition-colors hover:bg-wine-dark"
          >
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}
