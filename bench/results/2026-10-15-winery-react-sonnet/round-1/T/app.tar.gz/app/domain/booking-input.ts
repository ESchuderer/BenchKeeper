import { z } from "zod";
import { MAX_GUESTS_PER_BOOKING } from "./tastings";

export type BookingField = "name" | "email" | "guests";
export type FieldErrors = Partial<Record<BookingField, string>>;
export type BookingValues = { name: string; email: string; guests: number };

export type ValidationResult =
  | { ok: true; value: BookingValues }
  | { ok: false; errors: FieldErrors };

const rangeMessage = `You can book 1 to ${MAX_GUESTS_PER_BOOKING} guests at a time.`;

const guestsSchema = z
  .string()
  .trim()
  .regex(/^\d+$/, `Please enter the number of guests, from 1 to ${MAX_GUESTS_PER_BOOKING}.`)
  .transform(Number)
  .pipe(z.number().min(1, rangeMessage).max(MAX_GUESTS_PER_BOOKING, rangeMessage));

// Local part and domain labels may contain any letters and digits (umlauts included); the domain needs a dot.
const WORD = "[\\p{L}\\p{N}_%+'-]+";
const DOMAIN_LABEL = "[\\p{L}\\p{N}]([\\p{L}\\p{N}-]*[\\p{L}\\p{N}])?";
const EMAIL_PATTERN = new RegExp(`^${WORD}(\\.${WORD})*@(${DOMAIN_LABEL}\\.)+\\p{L}{2,}$`, "u");

// Control and invisible formatting characters (line breaks, zero-width spaces, bidi overrides).
const INVISIBLE_CHARACTERS = /[\p{Cc}\p{Cf}]/u;

const bookingSchema = z.object({
  name: z
    .string()
    .trim()
    .normalize("NFC")
    .min(1, "Please enter your name.")
    .refine((name) => [...name].length <= 100, "Please keep your name to 100 characters.")
    .refine((name) => !INVISIBLE_CHARACTERS.test(name), "Please use letters, numbers and common punctuation in your name."),
  email: z
    .string()
    .trim()
    .min(1, "Please enter your email address.")
    .max(254, "That email address is too long.")
    .pipe(z.email({ pattern: EMAIL_PATTERN, error: "Please enter a valid email address, like name@example.com." })),
  guests: guestsSchema,
});

export function seatsMessage(seatsLeft: number): string {
  if (seatsLeft <= 0) return "This tasting is fully booked.";
  return `Only ${seatsLeft} ${seatsLeft === 1 ? "seat" : "seats"} left for this tasting.`;
}

export const asText = (value: unknown) => (typeof value === "string" ? value : "");

/** Validates raw form values (strings, possibly missing) at the system boundary. */
export function validateBookingInput(
  raw: Record<BookingField, unknown>,
  seatsLeft: number,
): ValidationResult {
  const fields = { name: asText(raw.name), email: asText(raw.email), guests: asText(raw.guests) };
  const parsed = bookingSchema.safeParse(fields);

  const errors: FieldErrors = {};
  if (!parsed.success) {
    for (const issue of parsed.error.issues) {
      const field = issue.path[0] as BookingField;
      errors[field] ??= issue.message;
    }
  }

  // Report the seat limit together with other errors, not one round trip later.
  const guests = guestsSchema.safeParse(fields.guests);
  if (guests.success && guests.data > seatsLeft) errors.guests = seatsMessage(seatsLeft);

  if (parsed.success && !errors.guests) return { ok: true, value: parsed.data };
  return { ok: false, errors };
}
