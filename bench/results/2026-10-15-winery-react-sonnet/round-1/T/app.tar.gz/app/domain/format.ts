const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export function formatPrice(cents: number): string {
  const euros = cents % 100 === 0 ? String(cents / 100) : (cents / 100).toFixed(2);
  return `EUR ${euros}`;
}

export function formatSeatsLeft(seats: number): string {
  return `${seats} seats left`;
}

/** Formats a local `YYYY-MM-DDTHH:mm` string without involving any timezone. */
export function formatDateTime(startsAt: string): string {
  const [date = "", time = ""] = startsAt.split("T");
  const [year = 0, month = 1, day = 1] = date.split("-").map(Number);
  const weekday = WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()];
  return `${weekday}, ${day} ${MONTHS[month - 1]} ${year}, ${time}`;
}

export function formatDateBadge(startsAt: string): { day: string; month: string } {
  const [, month = 1, day = 1] = (startsAt.split("T")[0] ?? "").split("-").map(Number);
  return { day: String(day), month: (MONTHS[month - 1] ?? "").slice(0, 3) };
}
