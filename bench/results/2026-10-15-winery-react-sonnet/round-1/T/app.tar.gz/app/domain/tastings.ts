export type Tasting = {
  id: string;
  title: string;
  /** Local start at the winery, `YYYY-MM-DDTHH:mm`, no timezone. */
  startsAt: string;
  priceCents: number;
  seats: number;
};

export const MAX_GUESTS_PER_BOOKING = 8;

export const tastings: readonly Tasting[] = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00",
    priceCents: 2500,
    seats: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00",
    priceCents: 3200,
    seats: 8,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00",
    priceCents: 2800,
    seats: 10,
  },
];

export function findTasting(id: string): Tasting | undefined {
  return tastings.find((tasting) => tasting.id === id);
}
