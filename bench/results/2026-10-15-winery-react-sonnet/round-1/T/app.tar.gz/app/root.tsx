import { isRouteErrorResponse, Link, Links, Meta, Outlet, Scripts, ScrollRestoration } from "react-router";
import { SiteShell } from "~/components/SiteShell";
import type { Route } from "./+types/root";
import "./app.css";

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="Book a wine tasting at Weingut Kieselbrunnen, a family winery." />
        <Meta />
        <Links />
      </head>
      <body>
        {children}
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  );
}

export default function App() {
  return (
    <SiteShell>
      <Outlet />
    </SiteShell>
  );
}

export function ErrorBoundary({ error }: Route.ErrorBoundaryProps) {
  const status = isRouteErrorResponse(error) ? error.status : undefined;
  const copy =
    status === 404
      ? {
          title: "We can't find that page",
          text: "The page you are looking for does not exist, or the booking is no longer there.",
          link: { to: "/", label: "See all tastings" },
        }
      : status === 401
        ? {
            title: "Please sign in again",
            text: "Your staff session has ended.",
            link: { to: "/staff", label: "Go to staff sign-in" },
          }
        : {
            title: "Something went wrong",
            text: "Please try again in a moment.",
            link: { to: "/", label: "See all tastings" },
          };

  return (
    <SiteShell>
      <title>{`${copy.title} | Weingut Kieselbrunnen`}</title>
      <h1 className="text-5xl">{copy.title}</h1>
      <p className="mt-4 max-w-prose text-lg text-ink-soft">{copy.text}</p>
      <Link
        to={copy.link.to}
        className="mt-6 inline-flex min-h-11 items-center rounded-md bg-wine px-5 font-semibold text-white hover:bg-wine-dark"
      >
        {copy.link.label}
      </Link>
    </SiteShell>
  );
}
