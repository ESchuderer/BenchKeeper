import { type RouteConfig, index, route } from "@react-router/dev/routes";

export default [
  index("routes/home.tsx"),
  route("tastings/:tastingId/book", "routes/book.tsx"),
  route("bookings/:reference", "routes/confirmation.tsx"),
  route("staff", "routes/staff.tsx"),
] satisfies RouteConfig;
