import { useEffect, useRef } from "react";
import { Form, Link, redirect, useNavigation } from "react-router";
import { bookingStore } from "~/.server/booking-store";
import { readForm } from "~/.server/read-form";
import { Alert } from "~/components/Alert";
import { Field } from "~/components/Field";
import { asText, seatsMessage, validateBookingInput, type FieldErrors } from "~/domain/booking-input";
import { formatDateTime, formatPrice, formatSeatsLeft } from "~/domain/format";
import { findTasting, MAX_GUESTS_PER_BOOKING } from "~/domain/tastings";
import type { Route } from "./+types/book";

const SUBMISSION_ID = /^[A-Za-z0-9-]{8,64}$/;

function requireTasting(tastingId: string | undefined) {
  const tasting = tastingId ? findTasting(tastingId) : undefined;
  if (!tasting) throw new Response("Tasting not found", { status: 404 });
  return tasting;
}

export async function loader({ params }: Route.LoaderArgs) {
  const tasting = requireTasting(params.tastingId);
  return { tasting, seatsLeft: bookingStore.seatsLeft(tasting.id), submissionId: crypto.randomUUID() };
}

export async function action({ request, params }: Route.ActionArgs) {
  const tasting = requireTasting(params.tastingId);
  const form = await readForm(request);
  const values = {
    name: asText(form.get("name")),
    email: asText(form.get("email")),
    guests: asText(form.get("guests")),
  };

  const submissionId = asText(form.get("submissionId"));
  const checked = validateBookingInput(values, bookingStore.seatsLeft(tasting.id));
  // A rejected form is a normal outcome of a submission: re-render it with 200, not an error status.
  if (!checked.ok) return { fieldErrors: checked.errors, values };

  const result = bookingStore.book({
    tastingId: tasting.id,
    ...checked.value,
    submissionId: SUBMISSION_ID.test(submissionId) ? submissionId : undefined,
  });
  if (!result.ok) {
    const fieldErrors: FieldErrors = {
      guests: seatsMessage(result.reason === "not-enough-seats" ? result.seatsLeft : 0),
    };
    return { fieldErrors, values };
  }
  return redirect(`/bookings/${result.booking.reference}`, 303);
}

export function meta({ loaderData }: Route.MetaArgs) {
  return [{ title: `${loaderData?.tasting.title ?? "Booking"} | Weingut Kieselbrunnen` }];
}

export default function Book({ loaderData, actionData }: Route.ComponentProps) {
  const { tasting, seatsLeft, submissionId } = loaderData;
  const navigation = useNavigation();
  const submitting = navigation.state === "submitting";
  const formRef = useRef<HTMLFormElement>(null);
  const fieldErrors = actionData?.fieldErrors ?? {};
  const values = actionData?.values;

  // Move keyboard and screen reader users to the first field that needs attention.
  useEffect(() => {
    if (actionData) formRef.current?.querySelector<HTMLElement>("[aria-invalid]")?.focus();
  }, [actionData]);

  return (
    <div className="max-w-xl">
      <Link to="/" className="inline-flex min-h-11 items-center text-wine underline underline-offset-4">
        All tastings
      </Link>

      <h1 className="mt-2 text-5xl">{tasting.title}</h1>
      <p className="mt-3 text-ink-soft">
        <time dateTime={tasting.startsAt}>{formatDateTime(tasting.startsAt)}</time>
        {" · "}
        {formatPrice(tasting.priceCents)} per guest
        {" · "}
        {formatSeatsLeft(seatsLeft)}
      </p>

      {seatsLeft === 0 ? (
        <div className="mt-8 grid gap-4">
          <Alert tone="sold">This tasting is fully booked. Please choose another evening.</Alert>
        </div>
      ) : (
        <Form
          ref={formRef}
          method="post"
          noValidate
          aria-busy={submitting}
          className="mt-8 grid gap-5 rounded-md border border-line bg-card p-5 sm:p-7"
        >
          {Object.keys(fieldErrors).length > 0 && (
            <Alert tone="error" role="alert">
              Your booking has not been made yet. Please check the fields below.
            </Alert>
          )}
          <input type="hidden" name="submissionId" value={submissionId} />
          <Field
            label="Name"
            name="name"
            type="text"
            autoComplete="name"
            defaultValue={values?.name}
            error={fieldErrors.name}
          />
          <Field
            label="Email"
            name="email"
            type="email"
            autoComplete="email"
            defaultValue={values?.email}
            error={fieldErrors.email}
          />
          <Field
            label="Guests"
            name="guests"
            type="number"
            inputMode="numeric"
            min={1}
            max={MAX_GUESTS_PER_BOOKING}
            step={1}
            defaultValue={values?.guests ?? String(Math.min(2, seatsLeft))}
            hint={`1 to ${MAX_GUESTS_PER_BOOKING} guests per booking.`}
            error={fieldErrors.guests}
          />
          <div className="flex flex-wrap items-center gap-4">
            <button
              type="submit"
              disabled={submitting}
              className="min-h-12 rounded-md bg-wine px-8 font-semibold text-white transition-colors hover:bg-wine-dark disabled:cursor-wait disabled:opacity-60"
            >
              Book
            </button>
            {submitting && (
              <p role="status" className="text-ink-soft">
                Reserving your seats…
              </p>
            )}
          </div>
        </Form>
      )}
    </div>
  );
}
