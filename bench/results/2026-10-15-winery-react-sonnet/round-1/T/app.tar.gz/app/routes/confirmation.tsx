import { Link } from "react-router";
import { bookingStore } from "~/.server/booking-store";
import { Alert } from "~/components/Alert";
import { formatDateTime, formatPrice } from "~/domain/format";
import { findTasting } from "~/domain/tastings";
import type { Route } from "./+types/confirmation";

export async function loader({ params }: Route.LoaderArgs) {
  const booking = params.reference ? bookingStore.findByReference(params.reference) : undefined;
  const tasting = booking && findTasting(booking.tastingId);
  if (!booking || !tasting) throw new Response("Booking not found", { status: 404 });

  // Deliberately without name and email: the reference alone must not reveal personal data.
  return {
    reference: booking.reference,
    guests: booking.guests,
    totalCents: booking.totalCents,
    tasting,
  };
}

export function meta() {
  return [{ title: "Booking confirmed | Weingut Kieselbrunnen" }];
}

export default function Confirmation({ loaderData }: Route.ComponentProps) {
  const { reference, guests, totalCents, tasting } = loaderData;

  return (
    <div className="max-w-xl">
      <Alert tone="success" role="status">
        Your seats are reserved.
      </Alert>
      <h1 className="mt-6 text-5xl">Booking confirmed</h1>

      <dl className="mt-6 grid gap-x-6 gap-y-4 rounded-md border border-line bg-card p-5 sm:grid-cols-[auto_1fr] sm:p-7">
        <dt className="text-ink-soft">Tasting</dt>
        <dd className="font-semibold">
          {tasting.title}
          <span className="block font-normal text-ink-soft">{formatDateTime(tasting.startsAt)}</span>
        </dd>
        <dt className="text-ink-soft">Guests</dt>
        <dd className="font-semibold">{guests}</dd>
        <dt className="text-ink-soft">Total price</dt>
        <dd className="font-semibold">{formatPrice(totalCents)}</dd>
        <dt className="text-ink-soft">Booking reference</dt>
        <dd className="font-mono text-2xl font-bold tracking-widest text-wine">{reference}</dd>
      </dl>

      <p className="mt-4 text-ink-soft">Please keep your reference and mention it when you arrive.</p>
      <Link
        to="/"
        className="mt-6 inline-flex min-h-12 items-center rounded-md border border-wine px-6 font-semibold text-wine hover:bg-wine-soft"
      >
        Back to all tastings
      </Link>
    </div>
  );
}
