import { bookingStore } from "~/.server/booking-store";
import { TastingCard } from "~/components/TastingCard";
import { tastings } from "~/domain/tastings";
import type { Route } from "./+types/home";

export async function loader() {
  return {
    tastings: tastings.map((tasting) => ({
      ...tasting,
      seatsLeft: bookingStore.seatsLeft(tasting.id),
    })),
  };
}

export function meta() {
  return [{ title: "Wine tastings | Weingut Kieselbrunnen" }];
}

export default function Home({ loaderData }: Route.ComponentProps) {
  return (
    <>
      <header className="mb-8 max-w-prose">
        <h1 className="text-5xl sm:text-6xl">Wine tastings at the estate</h1>
        <p className="mt-4 text-lg text-ink-soft">
          Pour, swirl and taste with our family. Choose an evening below and reserve your seats.
        </p>
      </header>
      <div className="grid gap-5">
        {loaderData.tastings.map(({ seatsLeft, ...tasting }) => (
          <TastingCard key={tasting.id} tasting={tasting} seatsLeft={seatsLeft} />
        ))}
      </div>
    </>
  );
}
