import { useEffect, useRef } from "react";
import { data, Form, redirect, useNavigation } from "react-router";
import { bookingStore } from "~/.server/booking-store";
import { readForm } from "~/.server/read-form";
import {
  isStaffPasswordConfigured,
  isStaffPasswordValid,
  isStaffSignedIn,
  staffSignInCookie,
  staffSignOutCookie,
  staffThrottle,
} from "~/.server/staff-auth";
import { Alert } from "~/components/Alert";
import { Field } from "~/components/Field";
import { asText } from "~/domain/booking-input";
import { formatDateTime } from "~/domain/format";
import type { Route } from "./+types/staff";

export function headers() {
  return { "Cache-Control": "private, no-store" };
}

export function meta() {
  return [{ title: "Staff | Weingut Kieselbrunnen" }, { name: "robots", content: "noindex" }];
}

export async function loader({ request }: Route.LoaderArgs) {
  if (!(await isStaffSignedIn(request))) {
    return { signedIn: false as const, configured: isStaffPasswordConfigured() };
  }
  return { signedIn: true as const, groups: bookingStore.listByTasting() };
}

async function signIn(request: Request, form: FormData) {
  if (!isStaffPasswordConfigured()) {
    return data({ notConfigured: true as const }, { status: 503 });
  }
  if (staffThrottle.isBlocked()) {
    return data(
      { fieldErrors: { password: "Too many attempts. Please wait a few minutes and try again." } },
      { status: 429 },
    );
  }
  if (!isStaffPasswordValid(asText(form.get("password")))) {
    staffThrottle.recordFailure();
    return { fieldErrors: { password: "That password is not correct." } };
  }
  staffThrottle.reset();
  return redirect("/staff", { status: 303, headers: { "Set-Cookie": await staffSignInCookie(request) } });
}

export async function action({ request }: Route.ActionArgs) {
  const form = await readForm(request);
  const intent = form.get("intent");

  if (intent === "sign-in") return signIn(request, form);
  if (intent === "sign-out") {
    return redirect("/staff", { status: 303, headers: { "Set-Cookie": await staffSignOutCookie(request) } });
  }

  // Every other action needs a staff session, checked on each request.
  if (!(await isStaffSignedIn(request))) throw new Response("Please sign in.", { status: 401 });

  if (intent === "cancel") {
    const reference = asText(form.get("reference"));
    return bookingStore.cancel(reference) ? { cancelled: reference } : { alreadyGone: reference };
  }
  throw new Response("Unknown action.", { status: 400 });
}

export default function Staff({ loaderData, actionData }: Route.ComponentProps) {
  return (
    <div>
      <h1 className="text-5xl">Staff</h1>
      {loaderData.signedIn ? (
        <Bookings groups={loaderData.groups} actionData={actionData} />
      ) : (
        <SignIn configured={loaderData.configured} actionData={actionData} />
      )}
    </div>
  );
}

type ActionData = Route.ComponentProps["actionData"];

function SignIn({ configured, actionData }: { configured: boolean; actionData: ActionData }) {
  const navigation = useNavigation();
  const submitting = navigation.state === "submitting";
  const passwordRef = useRef<HTMLInputElement>(null);
  const error = actionData && "fieldErrors" in actionData ? actionData.fieldErrors.password : undefined;
  const notConfigured = !configured || (actionData && "notConfigured" in actionData);

  useEffect(() => {
    if (error) passwordRef.current?.focus();
  }, [error, actionData]);

  return (
    <div className="mt-6 max-w-md">
      <p className="mb-6 text-lg text-ink-soft">Sign in to see the tasting bookings.</p>
      {notConfigured ? (
        <Alert tone="error" role="alert">
          Staff sign-in is currently unavailable.
        </Alert>
      ) : (
        <Form method="post" noValidate className="grid gap-5 rounded-md border border-line bg-card p-5 sm:p-7">
          <input type="hidden" name="intent" value="sign-in" />
          <Field
            ref={passwordRef}
            label="Password"
            name="password"
            type="password"
            autoComplete="current-password"
            error={error}
          />
          <button
            type="submit"
            disabled={submitting}
            className="min-h-12 rounded-md bg-wine px-8 font-semibold text-white transition-colors hover:bg-wine-dark disabled:cursor-wait disabled:opacity-60"
          >
            Sign in
          </button>
        </Form>
      )}
    </div>
  );
}

type Groups = Extract<Route.ComponentProps["loaderData"], { signedIn: true }>["groups"];

function Bookings({ groups, actionData }: { groups: Groups; actionData: ActionData }) {
  const navigation = useNavigation();
  const statusRef = useRef<HTMLDivElement>(null);
  const cancelling =
    navigation.state === "submitting" && navigation.formData?.get("intent") === "cancel"
      ? String(navigation.formData.get("reference"))
      : undefined;

  // The cancelled row (and the focused button in it) disappears: move focus to the result message.
  useEffect(() => {
    if (actionData && ("cancelled" in actionData || "alreadyGone" in actionData)) statusRef.current?.focus();
  }, [actionData]);

  return (
    <div className="mt-6 grid gap-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="text-lg text-ink-soft">All bookings, grouped by tasting.</p>
        <Form method="post">
          <input type="hidden" name="intent" value="sign-out" />
          <button
            type="submit"
            className="min-h-11 rounded-md border border-wine px-5 font-semibold text-wine hover:bg-wine-soft"
          >
            Sign out
          </button>
        </Form>
      </div>

      {actionData && "cancelled" in actionData && (
        <Alert ref={statusRef} tone="success" role="status">
          Booking {actionData.cancelled} was cancelled and its seats are free again.
        </Alert>
      )}
      {actionData && "alreadyGone" in actionData && (
        <Alert ref={statusRef} tone="sold" role="status">
          Booking {actionData.alreadyGone} had already been cancelled.
        </Alert>
      )}

      {groups.map(({ tasting, seatsLeft, bookings }) => (
        <section key={tasting.id} aria-labelledby={`h-${tasting.id}`}>
          <h2 id={`h-${tasting.id}`} className="text-3xl">
            {tasting.title}
          </h2>
          <p className="mt-1 text-ink-soft">
            {formatDateTime(tasting.startsAt)} · {tasting.seats - seatsLeft} of {tasting.seats} seats booked
          </p>

          {bookings.length === 0 ? (
            <p className="mt-3 rounded-md border border-dashed border-line px-4 py-3 text-ink-soft">
              No bookings yet.
            </p>
          ) : (
            <table role="table" className="mt-3 w-full border-collapse text-left">
              <thead role="rowgroup" className="max-sm:sr-only">
                <tr role="row" className="border-b-2 border-line text-sm text-ink-soft">
                  <th role="columnheader" scope="col" className="py-2 pr-3 font-semibold">Name</th>
                  <th role="columnheader" scope="col" className="py-2 pr-3 font-semibold">Email</th>
                  <th role="columnheader" scope="col" className="py-2 pr-3 font-semibold">Guests</th>
                  <th role="columnheader" scope="col" className="py-2 pr-3 font-semibold">Reference</th>
                  <th role="columnheader" scope="col" className="py-2 font-semibold">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody role="rowgroup">
                {bookings.map((booking) => (
                  <tr
                    role="row"
                    key={booking.reference}
                    className="border-b border-line max-sm:mb-3 max-sm:block max-sm:rounded-md max-sm:border max-sm:bg-card max-sm:p-4"
                  >
                    <td role="cell" id={`name-${booking.reference}`} className="py-3 pr-3 font-semibold max-sm:block max-sm:py-0.5">
                      {booking.name}
                    </td>
                    <td role="cell" className="py-3 pr-3 break-all max-sm:block max-sm:py-0.5">{booking.email}</td>
                    <td role="cell" className="py-3 pr-3 max-sm:block max-sm:py-0.5">
                      <span className="sm:sr-only">Guests: </span>
                      {booking.guests}
                    </td>
                    <td role="cell" className="py-3 pr-3 font-mono tracking-wider max-sm:block max-sm:py-0.5">
                      {booking.reference}
                    </td>
                    <td role="cell" className="py-3 text-right max-sm:block max-sm:pt-3 max-sm:text-left">
                      <Form method="post">
                        <input type="hidden" name="intent" value="cancel" />
                        <input type="hidden" name="reference" value={booking.reference} />
                        <button
                          type="submit"
                          aria-describedby={`name-${booking.reference}`}
                          disabled={cancelling === booking.reference}
                          className="min-h-11 rounded-md border border-error px-4 font-semibold text-error hover:bg-error-soft disabled:cursor-wait disabled:opacity-60"
                        >
                          Cancel
                        </button>
                      </Form>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      ))}
    </div>
  );
}
