import AxeBuilder from "@axe-core/playwright";
import { expect, test as base, type Browser, type Page } from "@playwright/test";

export const STAFF_PASSWORD = "e2e-staff-password";

/** Fails any test during which the browser logged an error or warning. */
export const test = base.extend<{ consoleProblems: string[]; allowedConsoleProblems: RegExp[] }>({
  allowedConsoleProblems: [[], { option: true }],
  consoleProblems: [
    async ({ page, allowedConsoleProblems }, use) => {
      const problems: string[] = [];
      page.on("console", (message) => {
        if (["error", "warning"].includes(message.type())) problems.push(message.text());
      });
      page.on("pageerror", (error) => problems.push(error.message));
      await use(problems);
      const unexpected = problems.filter((text) => !allowedConsoleProblems.some((allowed) => allowed.test(text)));
      expect(unexpected, "browser console problems").toEqual([]);
    },
    { auto: true },
  ],
});

export { expect };

export async function bookTasting(
  page: Page,
  tasting: string,
  guest: { name: string; email: string; guests: number },
) {
  await page.goto("/");
  await page.getByRole("link", { name: `Book ${tasting}` }).click();
  await page.getByLabel("Name").fill(guest.name);
  await page.getByLabel("Email").fill(guest.email);
  await page.getByLabel("Guests").fill(String(guest.guests));
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  return (await page.getByText(/^KB-[A-Z2-9]{6}$/).textContent()) ?? "";
}

export async function signInAsStaff(page: Page) {
  await page.goto("/staff");
  await page.getByLabel("Password").fill(STAFF_PASSWORD);
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByRole("button", { name: "Sign out" })).toBeVisible();
}

/** Leaves the shared in-memory server without bookings, whatever a test did. */
export async function cancelAllBookings(browser: Browser, baseURL: string | undefined) {
  const context = await browser.newContext({ baseURL });
  const page = await context.newPage();
  await signInAsStaff(page);
  const cancelButtons = page.getByRole("button", { name: "Cancel", exact: true });
  while ((await cancelButtons.count()) > 0) {
    const before = await cancelButtons.count();
    await cancelButtons.first().click();
    await expect(cancelButtons).toHaveCount(before - 1);
  }
  await context.close();
}

export async function expectNoAccessibilityViolations(page: Page) {
  const results = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa"]).analyze();
  expect(results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(", ")}`)).toEqual([]);
}

export async function expectNoHorizontalScroll(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  expect(overflow, "horizontal overflow in px").toBeLessThanOrEqual(0);
}
