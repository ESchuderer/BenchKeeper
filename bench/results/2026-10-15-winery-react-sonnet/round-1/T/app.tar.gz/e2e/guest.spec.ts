import { bookTasting, cancelAllBookings, expect, expectNoAccessibilityViolations, expectNoHorizontalScroll, test } from "./fixtures";

test.afterEach(async ({ browser, baseURL }) => cancelAllBookings(browser, baseURL));

const anna = { name: "Anna Weber", email: "anna@example.com", guests: 2 };

test("the start page lists the tastings with date, price and seats left", async ({ page }) => {
  await page.goto("/");

  const riesling = page.getByRole("article").filter({ hasText: "Riesling Evening" });
  await expect(riesling).toContainText("Friday, 6 November 2026, 18:00");
  await expect(riesling).toContainText("EUR 25");
  await expect(riesling).toContainText("12 seats left");
  const tour = page.getByRole("article").filter({ hasText: "Red Wine Cellar Tour" });
  await expect(tour).toContainText("Saturday, 14 November 2026, 15:00");
  await expect(tour).toContainText("EUR 32");
  await expect(tour).toContainText("8 seats left");
  const winter = page.getByRole("article").filter({ hasText: "Winter Tasting" });
  await expect(winter).toContainText("Saturday, 5 December 2026, 17:00");
  await expect(winter).toContainText("EUR 28");
  await expect(winter).toContainText("10 seats left");
  await expectNoHorizontalScroll(page);
  await expectNoAccessibilityViolations(page);
});

test("a guest books a tasting and sees the confirmation", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Book Riesling Evening" }).click();
  await expect(page.getByRole("heading", { name: "Riesling Evening" })).toBeVisible();
  await expectNoAccessibilityViolations(page);

  await page.getByLabel("Name").fill("Anna Weber");
  await page.getByLabel("Email").fill("anna@example.com");
  await page.getByLabel("Guests").fill("3");
  await page.getByRole("button", { name: "Book", exact: true }).click();

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  await expect(page.getByText("Riesling Evening")).toBeVisible();
  await expect(page.getByText("EUR 75")).toBeVisible();
  await expect(page.getByText(/^KB-[A-Z2-9]{6}$/)).toBeVisible();
  await expectNoHorizontalScroll(page);
  await expectNoAccessibilityViolations(page);

  await page.goto("/");
  await expect(page.getByRole("article").filter({ hasText: "Riesling Evening" })).toContainText("9 seats left");
});

test("a guest can book using the keyboard alone", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Book Winter Tasting" }).focus();
  await page.keyboard.press("Enter");
  await expect(page.getByRole("heading", { name: "Winter Tasting" })).toBeVisible();

  await page.getByLabel("Name").focus();
  await page.keyboard.type("Dora Fischer");
  await page.keyboard.press("Tab");
  await expect(page.getByLabel("Email")).toBeFocused();
  await page.keyboard.type("dora@example.com");
  await page.keyboard.press("Tab");
  await expect(page.getByLabel("Guests")).toBeFocused();
  await page.keyboard.press("Tab");
  await expect(page.getByRole("button", { name: "Book", exact: true })).toBeFocused();
  await page.keyboard.press("Enter");

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
});

test("invalid input shows an error next to each field and keeps what was typed", async ({ page }) => {
  await page.goto("/tastings/riesling-evening/book");
  await page.getByLabel("Name").fill("   ");
  await page.getByLabel("Email").fill("not-an-email");
  await page.getByLabel("Guests").fill("9");
  await page.getByRole("button", { name: "Book", exact: true }).click();

  await expect(page.getByLabel("Name")).toHaveAccessibleDescription("Please enter your name.");
  await expect(page.getByLabel("Email")).toHaveAccessibleDescription(/valid email address/);
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/You can book 1 to 8 guests at a time\./);
  await expect(page.getByLabel("Email")).toHaveValue("not-an-email");
  await expect(page.getByLabel("Guests")).toHaveValue("9");
  await expect(page.getByLabel("Name")).toBeFocused();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toHaveCount(0);
  await expectNoAccessibilityViolations(page);
  await expectNoHorizontalScroll(page);
});

test("a booking can never take more seats than are left, up to a fully booked tasting", async ({ page }) => {
  await bookTasting(page, "Red Wine Cellar Tour", { ...anna, guests: 6 });

  await page.goto("/tastings/red-wine-cellar-tour/book");
  await page.getByLabel("Name").fill("Ben Keller");
  await page.getByLabel("Email").fill("ben@example.com");
  await page.getByLabel("Guests").fill("3");
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/Only 2 seats left for this tasting\./);

  await page.getByLabel("Guests").fill("2");
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await page.goto("/");
  const tour = page.getByRole("article").filter({ hasText: "Red Wine Cellar Tour" });
  await expect(tour).toContainText("0 seats left");
  await expect(tour).toContainText("Fully booked");
  await expect(page.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toHaveCount(0);
  await expect(page.getByRole("link", { name: "Book Riesling Evening" })).toBeVisible();
  await expectNoAccessibilityViolations(page);

  await page.goto("/tastings/red-wine-cellar-tour/book");
  await expect(page.getByText("This tasting is fully booked.")).toBeVisible();
  await expect(page.getByRole("button", { name: "Book", exact: true })).toHaveCount(0);
});

test.describe("not found", () => {
  test.use({ allowedConsoleProblems: [/status of 404/] });

  test("an unknown tasting or booking reference shows a friendly not-found page", async ({ page }) => {
    await page.goto("/tastings/nope/book");
    await expect(page.getByRole("heading", { name: "We can't find that page" })).toBeVisible();
    await page.goto("/bookings/KB-AAAAAA");
    await expect(page.getByRole("heading", { name: "We can't find that page" })).toBeVisible();
  });
});

test.describe("without JavaScript", () => {
  test.use({ javaScriptEnabled: false });

  test("booking and validation still work with plain form posts", async ({ page }) => {
    await page.goto("/tastings/winter-tasting/book");
    await page.getByLabel("Name").fill("Carla Schmid");
    await page.getByLabel("Email").fill("carla@example");
    await page.getByLabel("Guests").fill("2");
    await page.getByRole("button", { name: "Book", exact: true }).click();
    await expect(page.getByLabel("Email")).toHaveAccessibleDescription(/valid email address/);

    await page.getByLabel("Email").fill("carla@example.com");
    await page.getByRole("button", { name: "Book", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
    await expect(page.getByText("EUR 56")).toBeVisible();
  });
});
