import { bookTasting, cancelAllBookings, expect, expectNoAccessibilityViolations, expectNoHorizontalScroll, signInAsStaff, STAFF_PASSWORD, test } from "./fixtures";

test.afterEach(async ({ browser, baseURL }) => cancelAllBookings(browser, baseURL));

test("staff must sign in; a wrong password is rejected next to the field", async ({ page }) => {
  await bookTasting(page, "Winter Tasting", { name: "Anna Weber", email: "anna@example.com", guests: 2 });

  await page.goto("/staff");
  await expect(page.getByRole("button", { name: "Sign in" })).toBeVisible();
  await expect(page.getByText("anna@example.com")).toHaveCount(0);
  await expectNoAccessibilityViolations(page);

  await page.getByLabel("Password").fill("not the password");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByLabel("Password")).toHaveAccessibleDescription("That password is not correct.");
  await expect(page.getByText("anna@example.com")).toHaveCount(0);

  await page.getByLabel("Password").fill(STAFF_PASSWORD);
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByText("anna@example.com")).toBeVisible();
});

test.describe("cancelling", () => {
  test.use({ allowedConsoleProblems: [/status of 404/] });

  test("staff see bookings grouped by tasting and cancelling frees the seats", async ({ page }) => {
  const reference = await bookTasting(page, "Riesling Evening", { name: "Anna Weber", email: "anna@example.com", guests: 4 });
  await bookTasting(page, "Winter Tasting", { name: "Ben Keller", email: "ben@example.com", guests: 1 });

  await signInAsStaff(page);
  const riesling = page.getByRole("region", { name: "Riesling Evening" });
  const row = riesling.getByRole("row", { name: /Anna Weber/ });
  await expect(row).toContainText("anna@example.com");
  await expect(row).toContainText("4");
  await expect(row).toContainText(reference);
  await expect(riesling).not.toContainText("Ben Keller");
  await expect(page.getByRole("region", { name: "Winter Tasting" })).toContainText("Ben Keller");
  await expect(page.getByRole("region", { name: "Red Wine Cellar Tour" })).toContainText("No bookings yet.");
  await expectNoHorizontalScroll(page);
  await expectNoAccessibilityViolations(page);

  await row.getByRole("button", { name: "Cancel" }).click();
  await expect(page.getByText(`Booking ${reference} was cancelled`)).toBeVisible();
  await expect(riesling.getByText("Anna Weber")).toHaveCount(0);
  await expect(page.getByRole("region", { name: "Winter Tasting" })).toContainText("Ben Keller");

  await page.goto("/");
  await expect(page.getByRole("article").filter({ hasText: "Riesling Evening" })).toContainText("12 seats left");
  await page.goto(`/bookings/${reference}`);
  await expect(page.getByRole("heading", { name: "We can't find that page" })).toBeVisible();
  });
});

test("cancelling a full tasting makes it bookable again", async ({ page }) => {
  await bookTasting(page, "Red Wine Cellar Tour", { name: "Anna Weber", email: "anna@example.com", guests: 8 });
  await page.goto("/");
  await expect(page.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toHaveCount(0);

  await signInAsStaff(page);
  await page.getByRole("button", { name: "Cancel" }).click();
  await expect(page.getByText("was cancelled")).toBeVisible();

  await page.goto("/");
  await expect(page.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toBeVisible();
});

test("after cancelling, focus moves to the result message instead of getting lost", async ({ page }) => {
  await bookTasting(page, "Winter Tasting", { name: "Anna Weber", email: "anna@example.com", guests: 1 });
  await signInAsStaff(page);

  await page.getByRole("button", { name: "Cancel" }).click();

  await expect(page.getByRole("status").filter({ hasText: "was cancelled" })).toBeFocused();
});

test("signing out locks the staff page again", async ({ page }) => {
  await signInAsStaff(page);
  await page.getByRole("button", { name: "Sign out" }).click();
  await expect(page.getByRole("button", { name: "Sign in" })).toBeVisible();
  await page.reload();
  await expect(page.getByRole("button", { name: "Sign in" })).toBeVisible();
});

test("responses carry the security headers and the staff page is not cached", async ({ request }) => {
  const response = await request.get("/staff");

  expect(response.headers()["content-security-policy"]).toContain("script-src 'self' 'nonce-");
  expect(response.headers()["x-content-type-options"]).toBe("nosniff");
  expect(response.headers()["x-frame-options"]).toBe("DENY");
  expect(response.headers()["cache-control"]).toContain("no-store");
});
