import type { Config } from "@react-router/dev/config";

// Browsers send an Origin header with form posts and React Router rejects posts whose origin differs
// from the request URL. Behind a TLS-terminating proxy the app sees http while browsers send https,
// so list the public host(s) at build time, e.g. ALLOWED_ACTION_ORIGINS=wein.example.com npm run build
const allowedActionOrigins = process.env.ALLOWED_ACTION_ORIGINS?.split(",")
  .map((host) => host.trim())
  .filter(Boolean);

export default {
  ssr: true,
  ...(allowedActionOrigins?.length ? { allowedActionOrigins } : {}),
} satisfies Config;
