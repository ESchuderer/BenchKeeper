# Implementation Plan: Kieselbrunnen Tasting Bookings

Spec: `/SPEC.md`. Tasks are tracked in `tasks/todo.md` (default target).

## Overview
Server-rendered React Router app with an in-memory booking store. Built as vertical slices, each test-first and leaving the app buildable and runnable.

## Architecture decisions
- **React Router framework mode + `react-router-serve`**: one tool for server, routing, forms, loaders/actions. Forms work without JS (progressive enhancement), and server-side validation is the single source of truth. No separate API layer needed.
- **Synchronous in-memory store behind a small interface**: Node runs one request handler at a time on a synchronous `book()`, so the capacity check and the insert cannot interleave. The interface keeps a future file/DB store swappable.
- **Domain code is pure and shared** (`app/domain`), server state is in `app/.server`, so tests need no browser and no mocks.
- **Zod** for validation; **Tailwind** for styling with theme tokens; **Fontsource** for self-hosted fonts (keeps CSP `font-src 'self'`).
- **Security headers in `entry.server.tsx`** (nonce CSP) instead of a custom Express server: fewer moving parts.
- **No commits**: the environment rule is to commit only on request; the work is left in the working tree.

## Dependency graph
```
domain (catalogue, format, validation)
   └─ store (.server)
        ├─ home loader ── TastingCard UI
        ├─ book action ── BookingForm UI ── confirmation route
        └─ staff auth (.server) ── staff route (list, cancel)
                                      └─ e2e + polish + review
```

## Phases and checkpoints
- Phase 0 Foundation: scaffold, tooling, test runners.
- Phase 1 Guest browse (slice 1) then guest book (slices 2–3).
- Checkpoint A: guests can book end to end; tests, typecheck, build pass.
- Phase 2 Staff (slices 4–5).
- Checkpoint B: staff flow end to end; cancel frees seats.
- Phase 3 Hardening, design polish, e2e, docs, independent review.
- Checkpoint C: Definition of Done (`.opencode/references/definition-of-done.md`).

## Risks
| Risk | Impact | Mitigation |
|---|---|---|
| React Router 8 API differs from memory | Med | Scaffold from official templates, read docs, typecheck early |
| Native HTML validation hides server error messages | High | `noValidate` on forms; server renders the errors |
| Accessible names collide ("Book" vs "Book Riesling Evening", many "Cancel") | Med | Exact visible names; `aria-describedby` for context, not `aria-label` |
| Secure cookie breaks sign-in over plain HTTP | Med | Set `Secure` only when the request is HTTPS |
| Playwright browser cannot be installed | Med | Fall back to HTTP-level tests against the built server |
| Overselling by concurrent requests | High | Synchronous check+insert; test fires many bookings for the last seats |
