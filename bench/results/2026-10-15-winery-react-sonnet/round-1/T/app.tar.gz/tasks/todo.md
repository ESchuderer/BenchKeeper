# Task list

Definition of Done applies to every task: tests first and green, typecheck clean, no dead code, scope kept.

## Phase 0: Foundation
- [x] **T0 Scaffold and tooling**
  - Acceptance: `npm install`, `npm run build`, `npm start` serve a placeholder page on `PORT`; `npm test` runs Vitest; `npm run typecheck` passes.
  - Verify: run those commands; `curl localhost:$PORT/`.
  - Files: package.json, vite.config.ts, vitest.config.ts, react-router.config.ts, tsconfig.json, .gitignore, app/root.tsx, app/routes.ts

## Phase 1: Guest
- [x] **T1 Catalogue, formatting, store core** (domain + store, no UI)
  - Acceptance: catalogue matches the brief; `formatPrice`, `formatDateTime`; store `book/cancel/seatsLeft/find/list`; never oversold; references unique `KB-XXXXXX`; cancel frees seats; starts empty.
  - Verify: `npx vitest run tests/domain tests/server/booking-store.test.ts`
  - Files: app/domain/tastings.ts, app/domain/format.ts, app/.server/booking-store.ts, tests/*
- [x] **T2 Start page lists tastings**
  - Acceptance: title, date/time, `EUR n`, `<n> seats left`, "Book <title>" link; fully booked shows "Fully booked" and no link.
  - Verify: loader test + component test; manual in browser.
  - Files: app/routes/home.tsx, app/components/TastingCard.tsx, app/root.tsx, app/app.css, tests/*
- [x] **T3 Validation + booking form + confirmation**
  - Acceptance: fields `Name`/`Email`/`Guests`, button `Book`; each invalid input gives an inline error next to its field and keeps values; guests > seats left rejected; success redirects to confirmation with heading `Booking confirmed`, tasting, guests, total, reference; unknown tasting/reference 404; fully booked tasting shows notice, not a form.
  - Verify: `npx vitest run tests/domain/booking-input.test.ts tests/routes/book.test.ts`
  - Files: app/domain/booking-input.ts, app/routes/book.tsx, app/routes/confirmation.tsx, app/components/Field.tsx, tests/*

### Checkpoint A
- [x] tests, typecheck, build pass; guest flow works in a real browser

## Phase 2: Staff
- [x] **T4 Staff auth**
  - Acceptance: `/staff` shows `Password` + `Sign in`; correct `STAFF_PASSWORD` signs in (signed httpOnly cookie); wrong password gives inline error; unset password rejects everyone; throttling after repeated failures; sign out.
  - Verify: `npx vitest run tests/server/staff-auth.test.ts tests/routes/staff.test.ts`
  - Files: app/.server/staff-auth.ts, app/routes/staff.tsx, tests/*
- [x] **T5 Staff bookings list + cancel**
  - Acceptance: bookings grouped by tasting with name, email, guests, reference; `Cancel` removes the booking and frees seats (start page count rises); unauthenticated cancel POST rejected; empty tastings say so.
  - Verify: route tests + e2e.
  - Files: app/routes/staff.tsx, app/components/*, tests/*

### Checkpoint B
- [x] staff flow works; full test suite and typecheck pass

## Phase 3: Quality
- [x] **T6 Security headers and hardening**: nonce CSP, nosniff, referrer, frame-ancestors, no-store on staff; `npm audit`.
- [x] **T7 Design polish and responsive/accessibility pass**: 320/768/1024, focus states, contrast, error/success/sold-out states, reduced motion; verified with screenshots.
- [x] **T8 End-to-end tests**: guest books, sold out, staff cancel restores seats, phone viewport.
- [x] **T9 README + independent review**: run/env docs; fresh-context review across correctness, readability, architecture, security, performance; fix findings.

### Checkpoint C
- [x] Spec success criteria 1–5 verified; Definition of Done satisfied
