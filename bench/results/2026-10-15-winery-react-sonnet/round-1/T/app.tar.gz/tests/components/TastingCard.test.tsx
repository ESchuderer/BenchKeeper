// @vitest-environment jsdom
import { render, screen, within } from "@testing-library/react";
import { createRoutesStub } from "react-router";
import { describe, expect, it } from "vitest";
import { TastingCard } from "~/components/TastingCard";
import { findTasting } from "~/domain/tastings";

function renderCard(tastingId: string, seatsLeft: number) {
  const tasting = findTasting(tastingId)!;
  const Stub = createRoutesStub([
    { path: "/", Component: () => <TastingCard tasting={tasting} seatsLeft={seatsLeft} /> },
  ]);
  render(<Stub />);
  return screen.getByRole("article");
}

describe("TastingCard", () => {
  it("shows title, date and time, price per guest and seats left", () => {
    const card = renderCard("riesling-evening", 12);

    expect(within(card).getByRole("heading", { name: "Riesling Evening" })).toBeInTheDocument();
    expect(within(card).getByText("Friday, 6 November 2026, 18:00")).toBeInTheDocument();
    expect(within(card).getByText("EUR 25")).toBeInTheDocument();
    expect(within(card).getByText(/per guest/)).toBeInTheDocument();
    expect(within(card).getByText("12 seats left")).toBeInTheDocument();
  });

  it("links to the booking form with the accessible name 'Book <title>'", () => {
    renderCard("red-wine-cellar-tour", 8);

    const link = screen.getByRole("link", { name: "Book Red Wine Cellar Tour" });
    expect(link).toHaveAttribute("href", "/tastings/red-wine-cellar-tour/book");
  });

  it("marks a tasting without seats as fully booked and offers no booking link", () => {
    const card = renderCard("winter-tasting", 0);

    expect(within(card).getByText("Fully booked")).toBeInTheDocument();
    expect(within(card).getByText("0 seats left")).toBeInTheDocument();
    expect(within(card).queryByRole("link")).not.toBeInTheDocument();
  });
});
