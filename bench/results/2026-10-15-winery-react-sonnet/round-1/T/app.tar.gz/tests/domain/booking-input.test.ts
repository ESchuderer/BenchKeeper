import { describe, expect, it } from "vitest";
import { validateBookingInput } from "~/domain/booking-input";

const valid = { name: "Anna Weber", email: "anna@example.com", guests: "2" };

describe("validateBookingInput", () => {
  it("accepts valid input and returns typed, trimmed values", () => {
    const result = validateBookingInput(
      { name: "  Anna Weber ", email: " anna@example.com ", guests: " 2 " },
      12,
    );

    expect(result).toEqual({
      ok: true,
      value: { name: "Anna Weber", email: "anna@example.com", guests: 2 },
    });
  });

  it.each([
    ["", "Please enter your name."],
    ["   ", "Please enter your name."],
    ["x".repeat(101), "Please keep your name to 100 characters."],
  ])("rejects name %j", (name, message) => {
    expect(validateBookingInput({ ...valid, name }, 12)).toEqual({
      ok: false,
      errors: { name: message },
    });
  });

  it.each([
    ["", "Please enter your email address."],
    ["anna", "Please enter a valid email address, like name@example.com."],
    ["anna@", "Please enter a valid email address, like name@example.com."],
    ["anna@example", "Please enter a valid email address, like name@example.com."],
    ["a b@example.com", "Please enter a valid email address, like name@example.com."],
  ])("rejects email %j", (email, message) => {
    expect(validateBookingInput({ ...valid, email }, 12)).toEqual({
      ok: false,
      errors: { email: message },
    });
  });

  it.each(["", "abc", "1.5", "-1", "2e1", "1 2"])("rejects guests %j as not a whole number", (guests) => {
    const result = validateBookingInput({ ...valid, guests }, 12);

    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.errors.guests).toBe("Please enter the number of guests, from 1 to 8.");
  });

  it.each(["0", "9", "100"])("rejects %s guests as outside 1 to 8", (guests) => {
    expect(validateBookingInput({ ...valid, guests }, 12)).toEqual({
      ok: false,
      errors: { guests: "You can book 1 to 8 guests at a time." },
    });
  });

  it("rejects more guests than seats left and says how many are left", () => {
    expect(validateBookingInput({ ...valid, guests: "5" }, 3)).toEqual({
      ok: false,
      errors: { guests: "Only 3 seats left for this tasting." },
    });
  });

  it("uses the singular when one seat is left", () => {
    expect(validateBookingInput({ ...valid, guests: "2" }, 1)).toEqual({
      ok: false,
      errors: { guests: "Only 1 seat left for this tasting." },
    });
  });

  it("says the tasting is fully booked when no seat is left", () => {
    expect(validateBookingInput({ ...valid, guests: "1" }, 0)).toEqual({
      ok: false,
      errors: { guests: "This tasting is fully booked." },
    });
  });

  it("accepts exactly the seats that are left", () => {
    expect(validateBookingInput({ ...valid, guests: "3" }, 3).ok).toBe(true);
  });

  it("accepts umlauts in email addresses", () => {
    expect(validateBookingInput({ ...valid, email: "jörg@müller-weine.de" }, 12).ok).toBe(true);
  });

  it("accepts a name of exactly 100 characters and counts emoji as one character", () => {
    expect(validateBookingInput({ ...valid, name: "x".repeat(100) }, 12).ok).toBe(true);
    expect(validateBookingInput({ ...valid, name: "🍷".repeat(100) }, 12).ok).toBe(true);
  });

  it.each([
    ["a zero-width space", "\u200b"],
    ["a right-to-left override", "\u202eevil"],
    ["a line break", "Anna\nWeber"],
  ])("rejects a name made of or containing %s", (_label, name) => {
    expect(validateBookingInput({ ...valid, name }, 12)).toEqual({
      ok: false,
      errors: { name: "Please use letters, numbers and common punctuation in your name." },
    });
  });

  it("stores names in composed (NFC) form", () => {
    const result = validateBookingInput({ ...valid, name: "Mu\u0308ller" }, 12);

    expect(result.ok && result.value.name).toBe("M\u00fcller");
  });

  it.each(["1", "8"])("accepts %s guest(s) as the smallest and largest booking", (guests) => {
    expect(validateBookingInput({ ...valid, guests }, 12).ok).toBe(true);
  });

  it("reports every invalid field at once", () => {
    const result = validateBookingInput({ name: "", email: "nope", guests: "" }, 12);

    expect(result.ok).toBe(false);
    if (!result.ok) expect(Object.keys(result.errors).sort()).toEqual(["email", "guests", "name"]);
  });

  it("reports the seat limit together with errors in other fields", () => {
    expect(validateBookingInput({ ...valid, name: "", guests: "5" }, 3)).toEqual({
      ok: false,
      errors: { name: "Please enter your name.", guests: "Only 3 seats left for this tasting." },
    });
  });

  it("treats missing or non-text fields as empty", () => {
    const result = validateBookingInput({ name: undefined, email: new Blob(["x"]), guests: null }, 12);

    expect(result.ok).toBe(false);
    if (!result.ok) expect(Object.keys(result.errors).sort()).toEqual(["email", "guests", "name"]);
  });
});
