import { describe, expect, it } from "vitest";
import { formatDateBadge, formatDateTime, formatPrice, formatSeatsLeft } from "~/domain/format";

describe("formatPrice", () => {
  it("shows whole euros without decimals", () => {
    expect(formatPrice(2500)).toBe("EUR 25");
  });

  it("shows cents when the amount is not whole", () => {
    expect(formatPrice(2550)).toBe("EUR 25.50");
  });
});

describe("formatSeatsLeft", () => {
  it.each([
    [12, "12 seats left"],
    [1, "1 seats left"],
    [0, "0 seats left"],
  ])("renders %i as %s", (seats, text) => {
    expect(formatSeatsLeft(seats)).toBe(text);
  });
});

describe("formatDateTime", () => {
  it("renders the local start as weekday, date and 24h time", () => {
    expect(formatDateTime("2026-11-06T18:00")).toBe("Friday, 6 November 2026, 18:00");
  });

  it("does not shift the time with the server timezone", () => {
    expect(formatDateTime("2026-12-05T17:00")).toBe("Saturday, 5 December 2026, 17:00");
  });
});

describe("formatDateBadge", () => {
  it("splits a start into day number and short month", () => {
    expect(formatDateBadge("2026-11-06T18:00")).toEqual({ day: "6", month: "Nov" });
    expect(formatDateBadge("2026-12-05T17:00")).toEqual({ day: "5", month: "Dec" });
  });
});
