import { describe, expect, it } from "vitest";
import { findTasting, tastings } from "~/domain/tastings";

describe("tasting catalogue", () => {
  it("offers exactly the three tastings of the brief", () => {
    expect(
      tastings.map((t) => [t.title, t.startsAt, t.priceCents, t.seats]),
    ).toEqual([
      ["Riesling Evening", "2026-11-06T18:00", 2500, 12],
      ["Red Wine Cellar Tour", "2026-11-14T15:00", 3200, 8],
      ["Winter Tasting", "2026-12-05T17:00", 2800, 10],
    ]);
  });

  it("finds a tasting by id and returns undefined for unknown ids", () => {
    expect(findTasting("winter-tasting")?.title).toBe("Winter Tasting");
    expect(findTasting("nope")).toBeUndefined();
  });
});
