import { bookingStore } from "~/.server/booking-store";

/** The routes share one process-wide store; tests start from an empty one. */
export function clearBookings() {
  for (const { bookings } of bookingStore.listByTasting()) {
    for (const booking of bookings) bookingStore.cancel(booking.reference);
  }
}

export function formRequest(url: string, fields: Record<string, string>, headers: HeadersInit = {}) {
  return new Request(`http://localhost${url}`, {
    method: "POST",
    headers,
    body: new URLSearchParams(fields),
  });
}
