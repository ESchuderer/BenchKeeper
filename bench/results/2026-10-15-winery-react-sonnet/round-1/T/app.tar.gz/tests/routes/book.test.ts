import { beforeEach, describe, expect, it } from "vitest";
import { bookingStore } from "~/.server/booking-store";
import { action, loader } from "~/routes/book";
import { clearBookings, formRequest } from "../helpers";

const call = (fn: typeof action | typeof loader, request: Request, tastingId: string) =>
  fn({ request, params: { tastingId }, context: {} } as never);

const submit = (tastingId: string, fields: Record<string, string>) =>
  call(action, formRequest(`/tastings/${tastingId}/book`, fields), tastingId);

const guest = { name: "Anna Weber", email: "anna@example.com", guests: "2" };

async function thrownResponse(promise: unknown): Promise<Response> {
  try {
    await promise;
  } catch (thrown) {
    if (thrown instanceof Response) return thrown;
    throw thrown;
  }
  throw new Error("expected a thrown Response");
}

describe("book route loader", () => {
  it("hands every visitor of the form its own submission id", async () => {
    const request = () => new Request("http://localhost/tastings/winter-tasting/book");
    const first = (await call(loader, request(), "winter-tasting")) as { submissionId: string };
    const second = (await call(loader, request(), "winter-tasting")) as { submissionId: string };

    expect(first.submissionId).not.toBe(second.submissionId);
    expect(first.submissionId).toMatch(/^[A-Za-z0-9-]{16,}$/);
  });

  beforeEach(clearBookings);

  it("returns the tasting and its seats left", async () => {
    const result = await call(loader, new Request("http://localhost/tastings/winter-tasting/book"), "winter-tasting");

    expect(result).toMatchObject({ tasting: { id: "winter-tasting", title: "Winter Tasting" }, seatsLeft: 10 });
  });

  it("answers 404 for an unknown tasting", async () => {
    const response = await thrownResponse(
      call(loader, new Request("http://localhost/tastings/nope/book"), "nope"),
    );

    expect(response.status).toBe(404);
  });
});

describe("book route action", () => {
  beforeEach(clearBookings);

  it("books and redirects to the confirmation of the new reference", async () => {
    const response = (await submit("riesling-evening", guest)) as Response;

    expect(response.status).toBe(303);
    const reference = response.headers.get("Location")?.replace("/bookings/", "") ?? "";
    expect(bookingStore.findByReference(reference)).toMatchObject({
      name: "Anna Weber",
      email: "anna@example.com",
      guests: 2,
      tastingId: "riesling-evening",
    });
    expect(bookingStore.seatsLeft("riesling-evening")).toBe(10);
  });

  it("re-renders with the error for the guests field and keeps the typed values", async () => {
    const result = (await submit("riesling-evening", { ...guest, guests: "9" })) as { fieldErrors: Record<string, string>; values: Record<string, string> };
    expect(result.fieldErrors).toEqual({ guests: "You can book 1 to 8 guests at a time." });
    expect(result.values).toEqual({ ...guest, guests: "9" });
    expect(bookingStore.seatsLeft("riesling-evening")).toBe(12);
  });

  it("returns errors for name and email next to their own fields", async () => {
    const result = (await submit("riesling-evening", { name: "", email: "x", guests: "2" })) as { fieldErrors: Record<string, string> };

    expect(Object.keys(result.fieldErrors).sort()).toEqual(["email", "name"]);
  });

  it("refuses to take more seats than are left", async () => {
    bookingStore.book({ tastingId: "red-wine-cellar-tour", guests: 6, name: "B", email: "b@example.com" });

    const result = (await submit("red-wine-cellar-tour", { ...guest, guests: "3" })) as { fieldErrors: Record<string, string> };
    expect(result.fieldErrors.guests).toBe("Only 2 seats left for this tasting.");
    expect(bookingStore.seatsLeft("red-wine-cellar-tour")).toBe(2);
  });

  it("refuses any booking for a fully booked tasting", async () => {
    bookingStore.book({ tastingId: "red-wine-cellar-tour", guests: 8, name: "B", email: "b@example.com" });

    const result = (await submit("red-wine-cellar-tour", { ...guest, guests: "1" })) as { fieldErrors: Record<string, string> };

    expect(result.fieldErrors.guests).toBe("This tasting is fully booked.");
  });

  it("books once when the same form is submitted twice", async () => {
    const form = { ...guest, submissionId: "form-0123456789" };

    const first = (await submit("riesling-evening", form)) as Response;
    const second = (await submit("riesling-evening", form)) as Response;

    expect(second.headers.get("Location")).toBe(first.headers.get("Location"));
    expect(bookingStore.seatsLeft("riesling-evening")).toBe(10);
  });

  it("books twice for two different forms", async () => {
    await submit("riesling-evening", { ...guest, submissionId: "form-aaaaaaaaaa" });
    await submit("riesling-evening", { ...guest, submissionId: "form-bbbbbbbbbb" });

    expect(bookingStore.seatsLeft("riesling-evening")).toBe(8);
  });

  it("lets exactly one of two simultaneous requests for the last seats win", async () => {
    const results = await Promise.all([
      submit("red-wine-cellar-tour", { ...guest, guests: "8" }),
      submit("red-wine-cellar-tour", { ...guest, guests: "8", email: "other@example.com" }),
    ]);

    const redirects = results.filter((r) => r instanceof Response);
    const rejected = results.filter((r) => !(r instanceof Response)) as { fieldErrors: Record<string, string> }[];
    expect(redirects).toHaveLength(1);
    expect(rejected[0]?.fieldErrors.guests).toBe("This tasting is fully booked.");
    expect(bookingStore.seatsLeft("red-wine-cellar-tour")).toBe(0);
  });

  it("answers 404 when posting to an unknown tasting", async () => {
    const response = await thrownResponse(submit("nope", guest));

    expect(response.status).toBe(404);
  });
});
