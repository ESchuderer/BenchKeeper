import { beforeEach, describe, expect, it } from "vitest";
import { bookingStore } from "~/.server/booking-store";
import { loader } from "~/routes/confirmation";
import { clearBookings } from "../helpers";

const call = (reference: string) =>
  loader({ request: new Request(`http://localhost/bookings/${reference}`), params: { reference }, context: {} } as never);

describe("confirmation loader", () => {
  beforeEach(clearBookings);

  it("returns tasting, guests, total price and reference of the booking", async () => {
    const result = bookingStore.book({ tastingId: "red-wine-cellar-tour", guests: 3, name: "A", email: "a@example.com" });
    if (!result.ok) throw new Error("setup failed");

    const data = await call(result.booking.reference);

    expect(data).toMatchObject({
      reference: result.booking.reference,
      guests: 3,
      totalCents: 9600,
      tasting: { title: "Red Wine Cellar Tour" },
    });
  });

  it("does not expose the guest's personal data", async () => {
    const result = bookingStore.book({ tastingId: "winter-tasting", guests: 1, name: "Anna", email: "anna@example.com" });
    if (!result.ok) throw new Error("setup failed");

    const data = await call(result.booking.reference);

    expect(JSON.stringify(data)).not.toContain("anna@example.com");
    expect(JSON.stringify(data)).not.toContain("Anna");
  });

  it("answers 404 for an unknown reference", async () => {
    await expect(call("KB-AAAAAA")).rejects.toMatchObject({ status: 404 });
  });

  it("answers 404 once the booking was cancelled", async () => {
    const result = bookingStore.book({ tastingId: "winter-tasting", guests: 1, name: "A", email: "a@example.com" });
    if (!result.ok) throw new Error("setup failed");
    bookingStore.cancel(result.booking.reference);

    await expect(call(result.booking.reference)).rejects.toMatchObject({ status: 404 });
  });
});
