import { beforeEach, describe, expect, it } from "vitest";
import { bookingStore } from "~/.server/booking-store";
import { loader } from "~/routes/home";
import { clearBookings } from "../helpers";

describe("home loader", () => {
  beforeEach(clearBookings);

  it("lists the three tastings with their seats left", async () => {
    const { tastings } = await loader();

    expect(tastings.map((t) => [t.title, t.seatsLeft])).toEqual([
      ["Riesling Evening", 12],
      ["Red Wine Cellar Tour", 8],
      ["Winter Tasting", 10],
    ]);
  });

  it("reflects bookings in the seats left", async () => {
    bookingStore.book({ tastingId: "riesling-evening", guests: 5, name: "A", email: "a@example.com" });

    const { tastings } = await loader();

    expect(tastings[0]?.seatsLeft).toBe(7);
  });
});
