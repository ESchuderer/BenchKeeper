import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { bookingStore } from "~/.server/booking-store";
import { resetStaffThrottle } from "~/.server/staff-auth";
import { action, loader } from "~/routes/staff";
import { clearBookings, formRequest } from "../helpers";

type Data<T> = { data: T; init: { status: number } };

const PASSWORD = "winery-secret";

const load = (cookie?: string) =>
  loader({
    request: new Request("http://localhost/staff", { headers: cookie ? { Cookie: cookie } : {} }),
    params: {},
    context: {},
  } as never);

const post = (fields: Record<string, string>, cookie?: string, headers: HeadersInit = {}) =>
  action({
    request: formRequest("/staff", fields, cookie ? { Cookie: cookie, ...headers } : headers),
    params: {},
    context: {},
  } as never);

async function signIn(): Promise<string> {
  const response = (await post({ intent: "sign-in", password: PASSWORD })) as Response;
  return (response.headers.get("Set-Cookie") ?? "").split(";")[0] ?? "";
}

const book = (tastingId: string, name: string, guests = 2) => {
  const result = bookingStore.book({ tastingId, name, email: `${name.toLowerCase()}@example.com`, guests });
  if (!result.ok) throw new Error("setup failed");
  return result.booking;
};

beforeEach(() => {
  vi.stubEnv("STAFF_PASSWORD", PASSWORD);
  clearBookings();
  resetStaffThrottle();
});
afterEach(() => vi.unstubAllEnvs());

describe("staff sign-in", () => {
  it("asks for a password when not signed in and shows no bookings", async () => {
    book("riesling-evening", "Anna");

    const result = (await load()) as { signedIn: boolean };

    expect(result.signedIn).toBe(false);
    expect(JSON.stringify(result)).not.toContain("anna@example.com");
  });

  it("signs in with the right password and sets a hardened session cookie", async () => {
    const response = (await post({ intent: "sign-in", password: PASSWORD })) as Response;

    expect(response.status).toBe(303);
    const cookie = response.headers.get("Set-Cookie") ?? "";
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Lax/i);
    expect(cookie).not.toMatch(/;\s*Secure/i);
    expect(cookie).not.toContain(PASSWORD);
  });

  it("marks the cookie Secure when the request came over HTTPS", async () => {
    const response = (await post(
      { intent: "sign-in", password: PASSWORD },
      undefined,
      { "X-Forwarded-Proto": "https" },
    )) as Response;

    expect(response.headers.get("Set-Cookie")).toMatch(/;\s*Secure/i);
  });

  it("rejects a wrong password with an error for the password field", async () => {
    const result = (await post({ intent: "sign-in", password: "nope" })) as { fieldErrors: { password: string } };

    expect(result.fieldErrors.password).toBe("That password is not correct.");
  });

  it("rejects an empty password", async () => {
    const result = (await post({ intent: "sign-in", password: "" })) as { fieldErrors: { password: string } };

    expect(result.fieldErrors.password).toBeDefined();
  });

  it("rejects everyone when STAFF_PASSWORD is not set", async () => {
    vi.stubEnv("STAFF_PASSWORD", undefined);

    const result = (await post({ intent: "sign-in", password: "" })) as Data<{ notConfigured: boolean }>;

    expect(result.init.status).toBe(503);
    expect(result.data.notConfigured).toBe(true);
  });

  it("throttles after repeated wrong passwords, even for the right one", async () => {
    for (let i = 0; i < 10; i++) await post({ intent: "sign-in", password: "nope" });

    const result = (await post({ intent: "sign-in", password: PASSWORD })) as Data<{ fieldErrors: { password: string } }>;

    expect(result.init.status).toBe(429);
    expect(result.data.fieldErrors.password).toMatch(/too many/i);
  });

  it("keeps the session cookie for 8 hours only", async () => {
    const response = (await post({ intent: "sign-in", password: PASSWORD })) as Response;

    expect(response.headers.get("Set-Cookie")).toMatch(/Max-Age=28800/);
  });

  it("counts failures only until the next successful sign-in", async () => {
    for (let i = 0; i < 9; i++) await post({ intent: "sign-in", password: "nope" });
    await signIn();
    for (let i = 0; i < 9; i++) await post({ intent: "sign-in", password: "nope" });

    const response = (await post({ intent: "sign-in", password: PASSWORD })) as Response;

    expect(response.status).toBe(303);
  });

  it("ignores a forged session cookie", async () => {
    const result = (await load("kb_staff=eyJzdGFmZiI6dHJ1ZX0")) as { signedIn: boolean };

    expect(result.signedIn).toBe(false);
  });
});

describe("staff bookings", () => {
  it("lists all bookings grouped by tasting once signed in", async () => {
    const anna = book("riesling-evening", "Anna", 3);
    book("winter-tasting", "Ben", 1);

    const result = (await load(await signIn())) as {
      signedIn: true;
      groups: { tasting: { title: string }; seatsLeft: number; bookings: { name: string; email: string; guests: number; reference: string }[] }[];
    };

    expect(result.groups.map((g) => g.tasting.title)).toEqual(["Riesling Evening", "Red Wine Cellar Tour", "Winter Tasting"]);
    expect(result.groups[0]?.bookings).toEqual([
      expect.objectContaining({ name: "Anna", email: "anna@example.com", guests: 3, reference: anna.reference }),
    ]);
    expect(result.groups[1]?.bookings).toEqual([]);
    expect(result.groups[0]?.seatsLeft).toBe(9);
  });

  it("cancels a booking and frees its seats", async () => {
    const cookie = await signIn();
    const anna = book("red-wine-cellar-tour", "Anna", 8);
    expect(bookingStore.seatsLeft("red-wine-cellar-tour")).toBe(0);

    const result = (await post({ intent: "cancel", reference: anna.reference }, cookie)) as { cancelled: string };

    expect(result.cancelled).toBe(anna.reference);
    expect(bookingStore.seatsLeft("red-wine-cellar-tour")).toBe(8);
  });

  it("refuses to cancel without a staff session and leaves the booking alone", async () => {
    const anna = book("winter-tasting", "Anna");

    await expect(post({ intent: "cancel", reference: anna.reference })).rejects.toMatchObject({ status: 401 });

    expect(bookingStore.findByReference(anna.reference)).toBeDefined();
  });

  it("reports a booking that was already cancelled instead of failing", async () => {
    const cookie = await signIn();

    const result = (await post({ intent: "cancel", reference: "KB-AAAAAA" }, cookie)) as { alreadyGone: string };

    expect(result.alreadyGone).toBe("KB-AAAAAA");
  });

  it("signs out by clearing the session cookie", async () => {
    const cookie = await signIn();

    const response = (await post({ intent: "sign-out" }, cookie)) as Response;

    expect(response.status).toBe(303);
    expect(response.headers.get("Set-Cookie")).toMatch(/Max-Age=0|Expires=Thu, 01 Jan 1970/i);
  });

  it("ends the session on the server, so a copied cookie stops working after sign-out", async () => {
    const cookie = await signIn();
    const anna = book("winter-tasting", "Anna");
    await post({ intent: "sign-out" }, cookie);

    expect(((await load(cookie)) as { signedIn: boolean }).signedIn).toBe(false);
    await expect(post({ intent: "cancel", reference: anna.reference }, cookie)).rejects.toMatchObject({ status: 401 });
    expect(bookingStore.findByReference(anna.reference)).toBeDefined();
  });

  it("signing out without a session just returns to the sign-in page", async () => {
    const response = (await post({ intent: "sign-out" })) as Response;

    expect(response.status).toBe(303);
  });

  it("does not tell visitors how the server is configured", async () => {
    vi.stubEnv("STAFF_PASSWORD", undefined);

    const result = (await load()) as { configured: boolean };

    expect(result.configured).toBe(false);
  });

  it("answers 400 for an unknown intent", async () => {
    await expect(post({ intent: "drop-tables" }, await signIn())).rejects.toMatchObject({ status: 400 });
  });
});
