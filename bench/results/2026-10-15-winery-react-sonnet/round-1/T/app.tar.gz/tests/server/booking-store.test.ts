import { beforeEach, describe, expect, it } from "vitest";
import { tastings } from "~/domain/tastings";
import { createBookingStore, type BookingStore } from "~/.server/booking-store";

const guest = { name: "Anna Weber", email: "anna@example.com" };

describe("booking store", () => {
  let store: BookingStore;

  beforeEach(() => {
    store = createBookingStore(tastings);
  });

  it("starts with every seat free and no bookings", () => {
    expect(store.seatsLeft("riesling-evening")).toBe(12);
    expect(store.seatsLeft("red-wine-cellar-tour")).toBe(8);
    expect(store.seatsLeft("winter-tasting")).toBe(10);
    expect(store.listByTasting().every((g) => g.bookings.length === 0)).toBe(true);
  });

  it("books seats, reduces seats left and totals the price", () => {
    const result = store.book({ tastingId: "riesling-evening", guests: 3, ...guest });

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.booking).toMatchObject({ tastingId: "riesling-evening", guests: 3, ...guest });
    expect(result.booking.totalCents).toBe(7500);
    expect(store.seatsLeft("riesling-evening")).toBe(9);
  });

  it("issues unique references in the KB-XXXXXX format", () => {
    const references = new Set<string>();
    for (let i = 0; i < 12; i++) {
      const result = store.book({ tastingId: "riesling-evening", guests: 1, ...guest });
      if (result.ok) references.add(result.booking.reference);
    }
    expect(references.size).toBe(12);
    for (const reference of references) {
      expect(reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
    }
  });

  it("books exactly the last seats and then reports the tasting as full", () => {
    expect(store.book({ tastingId: "red-wine-cellar-tour", guests: 8, ...guest }).ok).toBe(true);
    expect(store.seatsLeft("red-wine-cellar-tour")).toBe(0);
  });

  it("refuses a booking that needs more seats than are left", () => {
    store.book({ tastingId: "red-wine-cellar-tour", guests: 6, ...guest });

    const result = store.book({ tastingId: "red-wine-cellar-tour", guests: 3, ...guest });

    expect(result).toEqual({ ok: false, reason: "not-enough-seats", seatsLeft: 2 });
    expect(store.seatsLeft("red-wine-cellar-tour")).toBe(2);
  });

  it("never sells more seats than exist, however many bookings arrive", () => {
    let accepted = 0;
    for (let i = 0; i < 40; i++) {
      const result = store.book({ tastingId: "winter-tasting", guests: (i % 4) + 1, ...guest });
      if (result.ok) accepted += result.booking.guests;
    }
    expect(accepted).toBeLessThanOrEqual(10);
    expect(store.seatsLeft("winter-tasting")).toBe(10 - accepted);
  });

  it("rejects an unknown tasting", () => {
    expect(store.book({ tastingId: "nope", guests: 1, ...guest })).toEqual({
      ok: false,
      reason: "unknown-tasting",
    });
  });

  it("cancels a booking, frees its seats and forgets it", () => {
    const result = store.book({ tastingId: "winter-tasting", guests: 4, ...guest });
    if (!result.ok) throw new Error("setup failed");

    expect(store.cancel(result.booking.reference)).toBe(true);

    expect(store.seatsLeft("winter-tasting")).toBe(10);
    expect(store.findByReference(result.booking.reference)).toBeUndefined();
  });

  it("lets a full tasting be booked again after a cancellation", () => {
    const full = store.book({ tastingId: "red-wine-cellar-tour", guests: 8, ...guest });
    if (!full.ok) throw new Error("setup failed");
    store.cancel(full.booking.reference);

    expect(store.book({ tastingId: "red-wine-cellar-tour", guests: 2, ...guest }).ok).toBe(true);
  });

  it("reports false when cancelling an unknown or already cancelled reference", () => {
    expect(store.cancel("KB-AAAAAA")).toBe(false);
    const result = store.book({ tastingId: "winter-tasting", guests: 1, ...guest });
    if (!result.ok) throw new Error("setup failed");
    store.cancel(result.booking.reference);
    expect(store.cancel(result.booking.reference)).toBe(false);
  });

  it("groups bookings by tasting in catalogue order, oldest first", () => {
    store.book({ tastingId: "winter-tasting", guests: 1, name: "B", email: "b@example.com" });
    store.book({ tastingId: "riesling-evening", guests: 2, name: "A", email: "a@example.com" });
    store.book({ tastingId: "winter-tasting", guests: 1, name: "C", email: "c@example.com" });

    const groups = store.listByTasting();

    expect(groups.map((g) => g.tasting.id)).toEqual([
      "riesling-evening",
      "red-wine-cellar-tour",
      "winter-tasting",
    ]);
    expect(groups[0]?.bookings.map((b) => b.name)).toEqual(["A"]);
    expect(groups[2]?.bookings.map((b) => b.name)).toEqual(["B", "C"]);
  });

  it("returns the same booking for a repeated submission id and takes the seats once", () => {
    const first = store.book({ tastingId: "winter-tasting", guests: 3, submissionId: "form-0123456789", ...guest });
    const second = store.book({ tastingId: "winter-tasting", guests: 3, submissionId: "form-0123456789", ...guest });

    expect(first.ok && second.ok && first.booking.reference === second.booking.reference).toBe(true);
    expect(store.seatsLeft("winter-tasting")).toBe(7);
  });

  it("books again with a used submission id once that booking was cancelled", () => {
    const first = store.book({ tastingId: "winter-tasting", guests: 3, submissionId: "form-0123456789", ...guest });
    if (!first.ok) throw new Error("setup failed");
    store.cancel(first.booking.reference);

    const again = store.book({ tastingId: "winter-tasting", guests: 3, submissionId: "form-0123456789", ...guest });

    expect(again.ok && again.booking.reference !== first.booking.reference).toBe(true);
    expect(store.seatsLeft("winter-tasting")).toBe(7);
  });

  it("hands out copies so callers cannot change stored bookings", () => {
    const result = store.book({ tastingId: "winter-tasting", guests: 1, ...guest });
    if (!result.ok) throw new Error("setup failed");
    result.booking.guests = 8;

    expect(store.seatsLeft("winter-tasting")).toBe(9);
  });
});
