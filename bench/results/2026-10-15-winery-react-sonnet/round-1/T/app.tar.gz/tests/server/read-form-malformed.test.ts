import { describe, expect, it } from "vitest";
import { readForm } from "~/.server/read-form";

const post = (body: string, contentType?: string) =>
  new Request("http://localhost/x", {
    method: "POST",
    headers: contentType ? { "Content-Type": contentType } : {},
    body,
  });

describe("readForm with bodies that are not forms", () => {
  it.each([
    ["JSON", '{"name":"x"}', "application/json"],
    ["a body without content type", "name=x", undefined],
    ["broken multipart", "--nope\r\nbroken", "multipart/form-data; boundary=xyz"],
  ])("answers 400 for %s instead of failing with a server error", async (_label, body, contentType) => {
    await expect(readForm(post(body, contentType))).rejects.toMatchObject({ status: 400 });
  });
});
