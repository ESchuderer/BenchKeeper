import { describe, expect, it } from "vitest";
import { readForm } from "~/.server/read-form";

const post = (body: string, headers: HeadersInit = {}) =>
  new Request("http://localhost/x", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", ...headers },
    body,
  });

describe("readForm", () => {
  it("parses an ordinary form post", async () => {
    const form = await readForm(post("name=Anna&guests=2"));

    expect(form.get("name")).toBe("Anna");
  });

  it("refuses a body announced as larger than a booking form could ever be", async () => {
    const request = post("a=b", { "Content-Length": "100000" });

    await expect(readForm(request)).rejects.toMatchObject({ status: 413 });
  });

  it("refuses a body that turns out larger than allowed even without a Content-Length", async () => {
    const request = post("a=" + "x".repeat(20_000));

    await expect(readForm(request)).rejects.toMatchObject({ status: 413 });
  });
});
