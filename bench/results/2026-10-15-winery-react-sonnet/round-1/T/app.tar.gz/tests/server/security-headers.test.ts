import { describe, expect, it } from "vitest";
import { createNonce, securityHeaders } from "~/.server/security-headers";

describe("securityHeaders", () => {
  const headers = securityHeaders({ nonce: "abc123", https: false });
  const csp = headers["Content-Security-Policy"] ?? "";

  it("only runs scripts from the app itself or carrying this request's nonce", () => {
    expect(csp).toContain("script-src 'self' 'nonce-abc123'");
    expect(csp).not.toContain("unsafe-inline");
    expect(csp).not.toContain("unsafe-eval");
  });

  it("loads everything else from the app only and forbids framing, plugins and foreign forms", () => {
    for (const directive of [
      "default-src 'self'",
      "style-src 'self'",
      "font-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'none'",
    ]) {
      expect(csp).toContain(directive);
    }
  });

  it("adds the standard hardening headers", () => {
    expect(headers["X-Content-Type-Options"]).toBe("nosniff");
    expect(headers["X-Frame-Options"]).toBe("DENY");
    expect(headers["Referrer-Policy"]).toBe("strict-origin-when-cross-origin");
    expect(headers["Permissions-Policy"]).toContain("camera=()");
  });

  it("sends HSTS only for HTTPS requests", () => {
    expect(headers["Strict-Transport-Security"]).toBeUndefined();
    expect(securityHeaders({ nonce: "n", https: true })["Strict-Transport-Security"]).toMatch(/max-age=\d+/);
  });
});

describe("createNonce", () => {
  it("is unpredictable: different on every call and long enough", () => {
    const a = createNonce();
    const b = createNonce();

    expect(a).not.toBe(b);
    expect(a.length).toBeGreaterThanOrEqual(22);
    expect(a).toMatch(/^[A-Za-z0-9+/_-]+=*$/);
  });
});
