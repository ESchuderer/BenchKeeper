import { describe, expect, it } from "vitest";
import { createSessionRegistry } from "~/.server/session-registry";

describe("session registry", () => {
  it("recognises sessions it created and nothing else", () => {
    const registry = createSessionRegistry({ ttlMs: 1000, maxSessions: 10 });
    const id = registry.create();

    expect(registry.isValid(id)).toBe(true);
    expect(registry.isValid("made-up")).toBe(false);
    expect(registry.isValid(undefined)).toBe(false);
  });

  it("issues unpredictable, distinct ids", () => {
    const registry = createSessionRegistry({ ttlMs: 1000, maxSessions: 10 });
    const [a, b] = [registry.create(), registry.create()];

    expect(a).not.toBe(b);
    expect(a.length).toBeGreaterThanOrEqual(32);
  });

  it("ends a session on destroy", () => {
    const registry = createSessionRegistry({ ttlMs: 1000, maxSessions: 10 });
    const id = registry.create();

    registry.destroy(id);

    expect(registry.isValid(id)).toBe(false);
  });

  it("expires a session once its lifetime has passed", () => {
    let now = 0;
    const registry = createSessionRegistry({ ttlMs: 1000, maxSessions: 10, now: () => now });
    const id = registry.create();

    now = 999;
    expect(registry.isValid(id)).toBe(true);
    now = 1000;
    expect(registry.isValid(id)).toBe(false);
  });

  it("keeps a bounded number of sessions by dropping the oldest", () => {
    const registry = createSessionRegistry({ ttlMs: 1000, maxSessions: 2 });
    const [first, second, third] = [registry.create(), registry.create(), registry.create()];

    expect(registry.isValid(first)).toBe(false);
    expect(registry.isValid(second)).toBe(true);
    expect(registry.isValid(third)).toBe(true);
  });
});
