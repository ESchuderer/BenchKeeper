import { afterEach, describe, expect, it, vi } from "vitest";
import { createFailureThrottle, isStaffPasswordValid } from "~/.server/staff-auth";

afterEach(() => vi.unstubAllEnvs());

describe("isStaffPasswordValid", () => {
  it("accepts exactly the password from STAFF_PASSWORD", () => {
    vi.stubEnv("STAFF_PASSWORD", "correct horse");

    expect(isStaffPasswordValid("correct horse")).toBe(true);
    expect(isStaffPasswordValid("correct horse ")).toBe(false);
    expect(isStaffPasswordValid("Correct horse")).toBe(false);
    expect(isStaffPasswordValid("")).toBe(false);
  });

  it("copes with candidates of any length", () => {
    vi.stubEnv("STAFF_PASSWORD", "short");

    expect(isStaffPasswordValid("x".repeat(10_000))).toBe(false);
  });

  it("lets nobody in when STAFF_PASSWORD is unset", () => {
    vi.stubEnv("STAFF_PASSWORD", undefined);

    expect(isStaffPasswordValid("")).toBe(false);
    expect(isStaffPasswordValid("undefined")).toBe(false);
  });

  it("lets nobody in when STAFF_PASSWORD is empty", () => {
    vi.stubEnv("STAFF_PASSWORD", "");

    expect(isStaffPasswordValid("")).toBe(false);
  });
});

describe("failure throttle", () => {
  it("blocks after the allowed number of failures within the window", () => {
    let now = 0;
    const throttle = createFailureThrottle({ maxFailures: 3, windowMs: 1000, now: () => now });

    for (let i = 0; i < 3; i++) {
      expect(throttle.isBlocked()).toBe(false);
      throttle.recordFailure();
    }

    expect(throttle.isBlocked()).toBe(true);
  });

  it("lets attempts through again once the failures are older than the window", () => {
    let now = 0;
    const throttle = createFailureThrottle({ maxFailures: 2, windowMs: 1000, now: () => now });
    throttle.recordFailure();
    throttle.recordFailure();
    expect(throttle.isBlocked()).toBe(true);

    now = 1001;

    expect(throttle.isBlocked()).toBe(false);
  });

  it("forgets earlier failures after a success", () => {
    const throttle = createFailureThrottle({ maxFailures: 2, windowMs: 1000, now: () => 0 });
    throttle.recordFailure();
    throttle.reset();
    throttle.recordFailure();

    expect(throttle.isBlocked()).toBe(false);
  });

  it("does not grow without bound under constant failures", () => {
    const throttle = createFailureThrottle({ maxFailures: 3, windowMs: 1000, now: () => 0 });
    for (let i = 0; i < 100_000; i++) throttle.recordFailure();

    expect(throttle.isBlocked()).toBe(true);
    expect(throttle.recordedFailures()).toBeLessThanOrEqual(3);
  });
});
