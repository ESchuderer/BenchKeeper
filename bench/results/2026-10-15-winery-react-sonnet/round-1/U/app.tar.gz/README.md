# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff see and cancel bookings.

- **Guests** (`/`): see the three tastings with price and seats left, open "Book <tasting>", fill in Name, Email and Guests (1 to 8), and get a confirmation with a booking reference.
- **Staff** (`/staff`): sign in with the shared password, see bookings grouped by tasting, cancel a booking to free its seats.

## Run it

Requires Node.js 22.

```bash
npm install
npm run build
STAFF_PASSWORD='choose-a-password' npm start   # http://localhost:3000
```

| Variable         | Default | Purpose                                                                        |
| ---------------- | ------- | ------------------------------------------------------------------------------ |
| `PORT`           | `3000`  | Port for the whole app (UI and API).                                           |
| `STAFF_PASSWORD` | unset   | Password for `/staff`. Unset or empty means nobody can sign in (fails closed). |
| `COOKIE_SECURE`  | `false` | Set to `true` behind HTTPS so the staff session cookie is marked `Secure`.     |

## Develop and test

```bash
npm run dev          # API on :3000 (tsx watch) and Vite on :5173 with /api proxied
npm run typecheck
npm test             # unit, API (Supertest) and component tests (Vitest, Testing Library)
npm run test:e2e     # Playwright against the built app (needs Chromium: npx playwright install chromium)
```

## How it is built

- **Front end:** React 19, React Router, react-hook-form with Zod, TanStack Query, Tailwind CSS 4, self-hosted fonts.
- **Server:** Express 5 with Helmet, rate limiting and a JSON API under `/api`; it also serves the built client.
- **Shared:** `shared/` holds the tasting data and the Zod booking schema used by both the form and the API, so the browser and the server validate identically. The server is authoritative.
- **Capacity:** the in-memory store checks seats and inserts a booking in one synchronous step, so concurrent requests cannot oversell a tasting.
- **Staff auth:** constant-time password check, random server-side session in an `HttpOnly`, `SameSite=Strict` cookie that expires after 8 hours, failed sign-ins rate limited (10 per 15 minutes per client).

Requirements and design decisions live in `openspec/` (change `winery-tasting-bookings`).

## Limits to know about

- Bookings are kept **in memory**: restarting the server clears them, and only one server process is supported.
- Past-dated tastings stay bookable; the brief defines no cut-off.
- Payment is not handled: the confirmation states the total, payable at the winery. No emails are sent.
- Guests cannot cancel on their own; staff do that.
