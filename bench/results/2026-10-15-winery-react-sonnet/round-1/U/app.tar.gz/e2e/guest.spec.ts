import { expect, test } from "@playwright/test";
import { bookViaApi, fillBooking, resetBookings } from "./helpers";

test.beforeEach(async ({ request }) => resetBookings(request));
test.afterAll(async ({ request }) => resetBookings(request));

test("start page lists the three tastings with details", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveTitle(/Kieselbrunnen/);
  const riesling = page.getByRole("article", { name: "Riesling Evening" });
  await expect(riesling).toContainText("Fri, 6 Nov 2026");
  await expect(riesling).toContainText("18:00");
  await expect(riesling).toContainText("EUR 25");
  await expect(riesling).toContainText("12 seats left");
  await expect(page.getByRole("article", { name: "Red Wine Cellar Tour" })).toContainText("8 seats left");
  await expect(page.getByRole("article", { name: "Red Wine Cellar Tour" })).toContainText("EUR 32");
  await expect(page.getByRole("article", { name: "Winter Tasting" })).toContainText("10 seats left");
  await expect(page.getByRole("article", { name: "Winter Tasting" })).toContainText("EUR 28");
  await page.screenshot({ path: `test-results/home-${test.info().project.name}.png`, fullPage: true });
});

test("a guest books a tasting and sees the confirmation", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Book Red Wine Cellar Tour" }).click();
  await expect(page).toHaveURL(/\/book\/red-wine-cellar-tour$/);
  await page.screenshot({ path: `test-results/form-${test.info().project.name}.png`, fullPage: true });
  await fillBooking(page, { name: "Anna Weber", email: "anna@example.com", guests: "3" });
  await page.getByRole("button", { name: "Book" }).click();

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  const region = page.getByRole("region", { name: "Booking confirmed" });
  await expect(region).toContainText("Red Wine Cellar Tour");
  await expect(region).toContainText("EUR 96");
  await expect(region.getByText(/^KB-[A-Z2-9]{8}$/)).toBeVisible();
  await page.screenshot({ path: `test-results/confirmed-${test.info().project.name}.png`, fullPage: true });

  await page.getByRole("link", { name: /all tastings/i }).click();
  await expect(page.getByRole("article", { name: "Red Wine Cellar Tour" })).toContainText("5 seats left");
});

test("invalid input is rejected with an error next to each field", async ({ page }) => {
  await page.goto("/book/riesling-evening");
  await fillBooking(page, { name: "", email: "nope", guests: "9" });
  await page.getByRole("button", { name: "Book" }).click();
  await expect(page.getByLabel("Name")).toHaveAccessibleDescription(/enter your name/i);
  await expect(page.getByLabel("Email")).toHaveAccessibleDescription(/valid email/i);
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/at most 8/i);
  await expect(page.getByLabel("Name")).toBeFocused();
  await page.screenshot({ path: `test-results/errors-${test.info().project.name}.png`, fullPage: true });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toHaveCount(0);
});

test("a booking can never take more seats than are left, and the tasting becomes fully booked", async ({
  page,
  request,
}) => {
  await bookViaApi(request, "winter-tasting", 8);
  await page.goto("/book/winter-tasting");
  await expect(page.getByText("2 seats left")).toBeVisible();

  await fillBooking(page, { name: "Anna Weber", email: "anna@example.com", guests: "3" });
  await page.getByRole("button", { name: "Book" }).click();
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/only 2 seats are left/i);
  await page.screenshot({ path: `test-results/capacity-${test.info().project.name}.png`, fullPage: true });

  await page.getByLabel("Guests").fill("2");
  await page.getByRole("button", { name: "Book" }).click();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await page.goto("/");
  const winter = page.getByRole("article", { name: "Winter Tasting" });
  await expect(winter).toContainText("Fully booked");
  await expect(winter).toContainText("0 seats left");
  await expect(page.getByRole("link", { name: "Book Winter Tasting" })).toHaveCount(0);
  await page.screenshot({ path: `test-results/full-${test.info().project.name}.png`, fullPage: true });

  await page.goto("/book/winter-tasting");
  await expect(page.getByText("Fully booked")).toBeVisible();
  await expect(page.getByLabel("Name")).toHaveCount(0);
});

test("the API itself refuses overbooking and bad input", async ({ request }) => {
  const over = await request.post("/api/bookings", {
    data: { tastingId: "red-wine-cellar-tour", name: "X", email: "x@example.com", guests: 9 },
  });
  expect(over.status()).toBe(422);
  const results = await Promise.all(
    Array.from({ length: 4 }, () =>
      request.post("/api/bookings", {
        data: { tastingId: "red-wine-cellar-tour", name: "X", email: "x@example.com", guests: 3 },
      }),
    ),
  );
  expect(results.filter((r) => r.status() === 201)).toHaveLength(2); // 8 seats / 3 guests
});

test("unknown tasting and unknown page show a way back", async ({ page }) => {
  await page.goto("/book/unknown");
  await expect(page.getByRole("heading", { name: /not found/i })).toBeVisible();
  await page.getByRole("link", { name: /all tastings/i }).click();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Wine tastings");
  await page.goto("/no/such/page");
  await expect(page.getByRole("heading", { name: /not found/i })).toBeVisible();
});
