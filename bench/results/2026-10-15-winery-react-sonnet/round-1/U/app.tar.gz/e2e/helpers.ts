import { expect, type APIRequestContext, type Page } from "@playwright/test";

export const STAFF_PASSWORD = "e2e-staff-pass";

/** Cancels every booking through the staff API so each test starts from an empty winery. */
export async function resetBookings(request: APIRequestContext) {
  const login = await request.post("/api/staff/session", { data: { password: STAFF_PASSWORD } });
  expect(login.status()).toBe(204);
  const list = await request.get("/api/staff/bookings");
  const { tastings } = (await list.json()) as { tastings: { bookings: { reference: string }[] }[] };
  for (const tasting of tastings) {
    for (const booking of tasting.bookings) await request.delete(`/api/staff/bookings/${booking.reference}`);
  }
  await request.delete("/api/staff/session");
}

export async function bookViaApi(
  request: APIRequestContext,
  tastingId: string,
  guests: number,
  name = "Pat Example",
) {
  const res = await request.post("/api/bookings", {
    data: { tastingId, name, email: `${name.split(" ")[0]!.toLowerCase()}@example.com`, guests },
  });
  expect(res.status()).toBe(201);
  return ((await res.json()) as { booking: { reference: string } }).booking.reference;
}

export async function fillBooking(page: Page, v: { name: string; email: string; guests: string }) {
  await page.getByLabel("Name").fill(v.name);
  await page.getByLabel("Email").fill(v.email);
  await page.getByLabel("Guests").fill(v.guests);
}

export async function signInAsStaff(page: Page, password = STAFF_PASSWORD) {
  await page.goto("/staff");
  await page.getByLabel("Password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
}
