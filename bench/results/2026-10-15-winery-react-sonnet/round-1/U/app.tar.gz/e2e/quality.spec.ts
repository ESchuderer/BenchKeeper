import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { bookViaApi, fillBooking, resetBookings, signInAsStaff } from "./helpers";

test.beforeEach(async ({ request }) => resetBookings(request));
test.afterAll(async ({ request }) => resetBookings(request));

async function expectNoOverflow(page: Page) {
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
  expect(overflow, "horizontal overflow in px").toBeLessThanOrEqual(0);
}

async function expectTouchTargets(page: Page) {
  const small = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>("button, input, a[href]")]
      .filter(
        (el) => el.offsetParent !== null && !el.closest(".sr-only") && !el.classList.contains("sr-only"),
      )
      .map((el) => ({ el, r: el.getBoundingClientRect() }))
      // Inline links inside running text are exempt (WCAG 2.5.8); controls are not.
      .filter(
        ({ el, r }) =>
          (el.tagName !== "A" || el.classList.contains("btn") || el.closest("header, footer")) &&
          r.height < 44,
      )
      .map(({ el, r }) => `${el.tagName} "${el.textContent?.trim().slice(0, 30)}" ${Math.round(r.height)}px`),
  );
  expect(small).toEqual([]);
}

const pages: [string, (page: Page) => Promise<void>][] = [
  [
    "start page",
    async (page) => {
      await page.goto("/");
      await page.getByRole("article").first().waitFor();
    },
  ],
  [
    "booking form",
    async (page) => {
      await page.goto("/book/riesling-evening");
      await page.getByLabel("Name").waitFor();
    },
  ],
  [
    "booking form with errors",
    async (page) => {
      await page.goto("/book/riesling-evening");
      await fillBooking(page, { name: "", email: "bad", guests: "0" });
      await page.getByRole("button", { name: "Book" }).click();
      await expect(page.getByLabel("Name")).toHaveAttribute("aria-invalid", "true");
    },
  ],
  [
    "confirmation",
    async (page) => {
      await page.goto("/book/riesling-evening");
      await fillBooking(page, { name: "Anna", email: "anna@example.com", guests: "2" });
      await page.getByRole("button", { name: "Book" }).click();
      await page.getByRole("heading", { name: "Booking confirmed" }).waitFor();
    },
  ],
  [
    "staff sign-in",
    async (page) => {
      await page.goto("/staff");
      await page.getByLabel("Password").waitFor();
    },
  ],
  [
    "staff overview",
    async (page) => {
      await signInAsStaff(page);
      await page.getByRole("heading", { name: "Bookings" }).waitFor();
    },
  ],
  [
    "not found",
    async (page) => {
      await page.goto("/nope");
      await page.getByRole("heading", { name: /not found/i }).waitFor();
    },
  ],
];

for (const [name, open] of pages) {
  test(`${name}: no axe violations, fits the viewport, big touch targets`, async ({ page, request }) => {
    // Fill Winter Tasting (10 seats, max 8 per booking) to exercise the fully booked state too.
    await bookViaApi(request, "winter-tasting", 8, "Full House");
    await bookViaApi(request, "winter-tasting", 2, "Full House");
    await bookViaApi(request, "riesling-evening", 2, "Anna Weber");
    await open(page);
    const results = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
      .analyze();
    expect(
      results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(", ")}`),
    ).toEqual([]);
    await expectNoOverflow(page);
    await expectTouchTargets(page);
    await expect(page.locator("html")).toHaveAttribute("lang", "en");
  });
}

test("a guest can book with the keyboard only", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("article").first().waitFor();
  const link = page.getByRole("link", { name: "Book Riesling Evening" });
  await page.keyboard.press("Tab");
  await expect(page.getByRole("link", { name: "Skip to content" })).toBeFocused();
  for (let i = 0; i < 10 && !(await link.evaluate((el) => el === document.activeElement)); i++)
    await page.keyboard.press("Tab");
  await expect(link).toBeFocused();
  await page.keyboard.press("Enter");
  await expect(page.getByLabel("Name")).toBeVisible();
  await page.getByLabel("Name").focus();
  await page.keyboard.type("Keyboard Guest");
  await page.keyboard.press("Tab");
  await page.keyboard.type("keys@example.com");
  await page.keyboard.press("Tab");
  await page.keyboard.press("Control+A");
  await page.keyboard.type("4");
  await page.keyboard.press("Tab");
  await expect(page.getByRole("button", { name: "Book" })).toBeFocused();
  await page.keyboard.press("Enter");
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeFocused();
  await expect(page.getByRole("region", { name: "Booking confirmed" })).toContainText("EUR 100");
});

test("pages load without console errors or CSP violations, using only same-origin resources", async ({
  page,
}) => {
  const problems: string[] = [];
  const foreign: string[] = [];
  page.on("console", (m) => {
    if (m.type() === "error" || m.type() === "warning") problems.push(m.text());
  });
  page.on("pageerror", (e) => problems.push(e.message));
  page.on("request", (r) => {
    if (!r.url().startsWith("http://localhost:3100")) foreign.push(r.url());
  });
  await page.goto("/");
  await page.getByRole("article").first().waitFor();
  await page.getByRole("link", { name: "Book Riesling Evening" }).click();
  await page.getByLabel("Name").waitFor();
  await page.goto("/staff");
  await page.getByLabel("Password").waitFor();
  await page.evaluate(() => document.fonts.ready);
  expect(problems).toEqual([]);
  expect(foreign).toEqual([]);
});
