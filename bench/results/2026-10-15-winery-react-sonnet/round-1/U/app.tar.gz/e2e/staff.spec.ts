import { expect, test } from "@playwright/test";
import { bookViaApi, resetBookings, signInAsStaff } from "./helpers";

test.beforeEach(async ({ request }) => resetBookings(request));
test.afterAll(async ({ request }) => resetBookings(request));

test("bookings are hidden until staff sign in; a wrong password shows an error", async ({
  page,
  request,
}) => {
  await bookViaApi(request, "winter-tasting", 2, "Anna Weber");
  await signInAsStaff(page, "wrong-password");
  await expect(page.getByLabel("Password")).toHaveAccessibleDescription(/not correct/i);
  await expect(page.getByText("Anna Weber")).toHaveCount(0);
  await page.screenshot({
    path: `test-results/staff-login-error-${test.info().project.name}.png`,
    fullPage: true,
  });
  expect((await request.get("/api/staff/bookings")).status()).toBe(401);
});

test("staff see bookings grouped by tasting and can cancel one to free its seats", async ({
  page,
  request,
}) => {
  const annaRef = await bookViaApi(request, "winter-tasting", 6, "Anna Weber");
  await bookViaApi(request, "winter-tasting", 2, "Ben Koch");
  await bookViaApi(request, "riesling-evening", 3, "Clara Vogt");

  await signInAsStaff(page);
  const winter = page.getByRole("region", { name: "Winter Tasting" });
  await expect(winter).toContainText("Anna Weber");
  await expect(winter).toContainText("anna@example.com");
  await expect(winter).toContainText(annaRef);
  await expect(winter).toContainText("Ben Koch");
  await expect(winter).not.toContainText("Clara Vogt");
  await expect(page.getByRole("region", { name: "Riesling Evening" })).toContainText("Clara Vogt");
  await expect(page.getByRole("region", { name: "Red Wine Cellar Tour" })).toContainText("No bookings yet");
  await page.screenshot({ path: `test-results/staff-${test.info().project.name}.png`, fullPage: true });

  await winter
    .getByRole("listitem")
    .filter({ hasText: "Anna Weber" })
    .getByRole("button", { name: "Cancel" })
    .click();
  await expect(winter).not.toContainText("Anna Weber");
  await expect(winter).toContainText("Ben Koch");

  await page.goto("/");
  await expect(page.getByRole("article", { name: "Winter Tasting" })).toContainText("8 seats left");
});

test("the session survives a reload and ends at sign out", async ({ page }) => {
  await signInAsStaff(page);
  await expect(page.getByRole("heading", { name: "Bookings" })).toBeVisible();
  await page.reload();
  await expect(page.getByRole("heading", { name: "Bookings" })).toBeVisible();
  await page.getByRole("button", { name: "Sign out" }).click();
  await expect(page.getByLabel("Password")).toBeVisible();
  await page.reload();
  await expect(page.getByLabel("Password")).toBeVisible();
});

test("staff cookie is HttpOnly and SameSite=Strict", async ({ page, context }) => {
  await signInAsStaff(page);
  await expect(page.getByRole("heading", { name: "Bookings" })).toBeVisible();
  const cookie = (await context.cookies()).find((c) => c.name === "kb_staff");
  expect(cookie?.httpOnly).toBe(true);
  expect(cookie?.sameSite).toBe("Strict");
});
