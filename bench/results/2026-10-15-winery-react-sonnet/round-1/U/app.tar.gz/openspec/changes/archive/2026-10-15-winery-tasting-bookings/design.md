# Design

## Context

Greenfield repository, no code yet. Requirements are in `specs/`; motivation in `proposal.md`. Constraints: React UI, Node 22, one `npm start` serving everything on `PORT`, no external services, bookings may live in memory, English UI. Guest PII (name, email) is stored, so the staff boundary matters.

## Goals / Non-Goals

**Goals:**
- One validation source of truth shared by browser and server.
- Capacity guarantee enforced only on the server, atomically.
- Small, conventional stack using maintained libraries.

**Non-Goals:**
- Persistence across restarts, multi-instance deployment, payments, email, i18n, tasting admin UI.

## Decisions

1. **Single-package TypeScript app: Vite + React SPA, Express 5 API.** `server/` (API and static hosting of `dist/client`), `shared/` (Zod schemas, money/date helpers), `src/` (React). `npm run build` runs `vite build` for the client and bundles the server with esbuild into `dist/server`; `npm start` runs `node dist/server/index.js`.
   Alternatives: React Router framework mode or Next.js (SSR) give more machinery than a three-page site needs and complicate the one-command run; separate client/server packages add workspace overhead. SSR/SEO is a non-goal; the start page content comes from one JSON call.

2. **Routing and forms with established libraries.** React Router for `/`, `/book/:tastingId`, `/staff`, and not-found. TanStack Query for server state (loading, error and retry states, refetch after booking or cancelling). react-hook-form with the Zod resolver for the booking form and staff login; Tailwind CSS v4 for styling with design tokens in CSS theme variables; fonts self-hosted through `@fontsource` packages (no third-party requests, works offline, keeps a strict CSP).

3. **Validation: Zod schemas in `shared/`.** Used by the form (client) and the API (server). The form is `noValidate` so our own, linked, accessible messages show instead of browser bubbles. The server is authoritative and returns `{ errors: { field: message } }` with 422; the client maps these onto fields (`setError`), including the capacity error on `guests`. "Guests" is a number input; empty or fractional input yields a field error rather than coercion to a valid number.

4. **Capacity atomicity via a synchronous in-memory store.** `BookingStore.book()` checks seats and inserts in one synchronous function; Node's single thread makes this atomic without locks, so concurrent requests cannot oversell. The store is an interface (`book`, `cancel`, `list`, `seatsLeft`) so file or DB persistence could replace it. In-memory chosen over a JSON file: no write-failure or corruption modes, spec allows it. The trade-off is that restarts drop bookings (documented).

5. **Money in integer cents, tastings as static server data.** Total = guests x price computed server-side and returned; the UI never recomputes it. Display format "EUR 25" (and "EUR 25.50" when non-integer) to match the brief's wording. Date/time are stored as local wall-clock strings (`2026-11-06T18:00`) and rendered without timezone conversion, so every visitor sees the winery's time.

6. **Seats-left wording follows the brief literally**: "<n> seats left", also for 1 and 0, with an additional "Fully booked" badge at 0. This keeps one stable text contract; grammar for n=1 is a known cosmetic cost.

7. **References**: `KB-` plus 8 characters from an unambiguous 31-character unambiguous alphabet using `crypto.randomInt` (about 40 bits), retried on collision. Not sequential, so not guessable. The confirmation is rendered from the POST response held in component state; there is no public lookup endpoint, so references never expose PII.

8. **Staff auth: shared password, server session.** `POST /api/staff/session` compares the password in constant time (SHA-256 digests with `timingSafeEqual`) against `STAFF_PASSWORD`; an unset or empty variable means every attempt fails (fail closed). On success the server issues a random 256-bit token held in an in-memory session set and sends it as an `HttpOnly; SameSite=Strict; Path=/` cookie (`Secure` when the request is HTTPS or `COOKIE_SECURE=true`, for TLS-terminating proxies). Sessions expire after 8 hours. `GET /api/staff/session` always answers 200 with `{ signedIn }` so the sign-in page never triggers a failing request; `GET /api/staff/bookings`, `DELETE /api/staff/bookings/:reference` require the cookie (401 otherwise); `DELETE /api/staff/session` destroys the session. CSRF is covered by SameSite=Strict plus JSON-only bodies. Failed logins are rate-limited with `express-rate-limit` (10 per 15 minutes per IP); the booking endpoint gets a looser limit (120 per minute per IP). Capacity, not rate, bounds what abuse can do, and a low limit would block a busy shared network such as a tasting group booking from one venue.
   Alternatives: JWT (needs secret management, no server-side revocation); HTTP Basic (no sign-out, no custom form).

9. **Hardening middleware**: `helmet` with a CSP that allows only self (no inline scripts), a `Permissions-Policy` that denies camera, microphone, geolocation and payment, `express.json({ limit: "10kb" })`, `x-powered-by` off, generic error handler that never leaks stack traces. React escapes output, so names and emails render as text.

10. **Testing pyramid**: Vitest + Supertest for the API (`createApp()` factory with injectable store and password), Vitest unit tests for shared schemas, Vitest + Testing Library for components and pages with a mocked fetch, Playwright for end-to-end flows against the built app (including a 360 px viewport and axe accessibility checks). Tests are written before the implementation for each group.

11. **UI approach**: warm, restrained palette (deep wine burgundy, cream, slate-green accent, dark text on cream with AA contrast), serif display font for headings and a humanist sans for body, a small inline SVG mark for the logo, cards for tastings, status badges that pair colour with text. Layout is mobile first with a single column below 640 px.

## Risks / Trade-offs

- Bookings are lost on restart → documented in README; store interface isolates future persistence.
- Single shared staff password → acceptable per brief; rate limit, constant-time compare, short session life.
- In-memory sessions and store assume one process → documented; not a goal to scale out.
- Past tastings remain bookable because the brief gives no cut-off rule → recorded as out of scope in the proposal.
- Dependency versions are recent majors (React 19, Vite, React Router 7+, Zod 4, Express 5, Tailwind 4) → follow each library's installed docs/types rather than older habits; lockfile committed.
- E2E needs a Chromium download → if unavailable, fall back to component and API tests and report the gap.
