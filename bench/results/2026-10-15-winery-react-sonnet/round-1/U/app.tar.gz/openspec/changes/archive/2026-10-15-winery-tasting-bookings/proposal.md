# Proposal

## Why

Weingut Kieselbrunnen, a family winery, takes tasting reservations informally today. Guests cannot see what is on offer or how many seats remain, and staff have no single list of who is coming. An online booking site fixes both, and keeps seats from being overbooked.

## What Changes

- Add a public start page listing three tastings (title, date and time, price per guest, seats left).
- Add a per-tasting booking form (Name, Email, Guests 1 to 8) with field-level validation errors and a confirmation page with a booking reference.
- Enforce capacity on the server: a booking can never take more seats than are left.
- Add a password-protected `/staff` area (password from `STAFF_PASSWORD`) that lists bookings grouped by tasting and lets staff cancel a booking, which frees its seats.
- Give all pages one coherent, mobile-friendly winery look with explicit error, success and fully-booked states.
- Single deployable Node.js 22 app: `npm install`, `npm run build`, `npm start` on `PORT` (default 3000). Bookings are held in memory; the app starts with none.

## Capabilities

### New Capabilities
- `tasting-catalog`: the offered tastings and the start page that presents them, including live seats-left and fully-booked state.
- `tasting-booking`: the guest booking flow, validation, capacity enforcement and confirmation.
- `staff-bookings`: staff sign-in, grouped booking overview and cancellation.
- `site-experience`: visual design, responsiveness, accessibility and feedback-state requirements across pages.

### Modified Capabilities

(none, the project has no existing specs)

## Impact

- New code: React front end, Node server with JSON API, shared validation, tests.
- New dependencies: React, React Router, TanStack Query, Vite, Express, Zod, react-hook-form, Tailwind CSS, Vitest, Testing Library, Playwright with axe, Prettier, and security middleware (helmet, express-rate-limit).
- Environment: `PORT`, `STAFF_PASSWORD`.
- Out of scope: online payment, email notifications, persistence across restarts, guest-initiated cancellation, closing bookings for tastings whose start time has passed, multiple staff accounts, and tasting administration.
