# Spec Delta

## Purpose

Sets the visual and interaction quality bar for the whole site so it reads as the winery's own website and works well for every guest on any device.

## ADDED Requirements

### Requirement: Coherent winery design
All pages SHALL share one visual identity (colours, typography, spacing, header with winery name, footer) appropriate for a small family winery.

#### Scenario: Consistent chrome
- **WHEN** a guest moves between the start page, a booking form and `/staff`
- **THEN** the header, footer, typography and colours stay consistent

### Requirement: Clear feedback states
The interface SHALL show distinct, visible states for field errors, success (confirmation), fully booked tastings, loading and unexpected failures. State SHALL NOT be conveyed by colour alone.

#### Scenario: Error state
- **WHEN** a field is invalid
- **THEN** its error text appears next to it with an icon or text prefix, the field is marked invalid for assistive technology, and the error is linked to the field

#### Scenario: Server unreachable
- **WHEN** a request fails for a network or server reason
- **THEN** the guest sees a clear message with an option to retry and typed values are kept

### Requirement: Mobile usability
Every page SHALL be usable at a 360 px wide viewport without horizontal scrolling, with touch targets at least 44 px high.

#### Scenario: Phone viewport
- **WHEN** any page is viewed at 360 px width
- **THEN** content fits the width, and buttons and links are easy to tap

### Requirement: Accessibility basics
Pages SHALL be operable by keyboard, have visible focus, label every form field, use sufficient text contrast, set the document title per page and move focus sensibly after navigation or submit errors.

#### Scenario: Keyboard booking
- **WHEN** a guest uses only the keyboard
- **THEN** they can open a booking form, fill it, submit it and reach the confirmation

#### Scenario: Focus on first error
- **WHEN** a submission is rejected
- **THEN** focus moves to the first invalid field

### Requirement: English interface
All user-facing text SHALL be in English.

#### Scenario: Language
- **WHEN** any page is viewed
- **THEN** its text is English and the document language is "en"
