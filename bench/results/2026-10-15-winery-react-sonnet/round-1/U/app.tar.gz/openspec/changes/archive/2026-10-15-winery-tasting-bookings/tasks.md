# Tasks

## 1. Project scaffolding

- [x] 1.1 Create `package.json` (Node 22, scripts `dev`, `build`, `start`, `test`, `test:e2e`, `typecheck`), TypeScript, Vite, Vitest, Tailwind configs, `.gitignore`; verify `npm install` succeeds and `npm run typecheck` runs on the empty skeleton
- [x] 1.2 Add the shared test setup (Vitest projects for node and jsdom, Testing Library, jest-dom); verify `npm test` runs a trivial passing test

## 2. Shared domain and validation (tests first)

- [x] 2.1 Write failing unit tests for the tasting data, booking schema (name, email, guests bounds, whole numbers), price/total and date formatting; verify they fail
- [x] 2.2 Implement `shared/` schemas and helpers; verify the unit tests pass

## 3. Server API (tests first)

- [x] 3.1 Write failing Supertest tests for `GET /api/tastings`, `POST /api/bookings` (valid, each invalid field, over capacity, exact capacity, concurrent last seats, unknown tasting, oversize body) and absence of PII in public responses; verify they fail
- [x] 3.2 Implement the in-memory booking store, reference generation, tastings and booking routes; verify the tests from 3.1 pass
- [x] 3.3 Write failing tests for staff auth (correct, wrong, empty, unset `STAFF_PASSWORD`, unauthenticated list and cancel refused, grouped list, cancel frees seats, cancel twice, sign out, rate limit); verify they fail
- [x] 3.4 Implement session auth, staff routes, rate limiting, helmet, error handling and static hosting with SPA fallback and `PORT` handling; verify the tests from 3.3 pass and `npm run build && npm start` serves `/` and `/api/tastings`

## 4. Guest UI (tests first)

- [x] 4.1 Write failing component tests for the start page (details, "<n> seats left", "Book <title>" links, fully-booked state, loading and error with retry); verify they fail
- [x] 4.2 Write failing component tests for the booking form (labels, field errors next to fields, server capacity error on Guests, values kept, focus on first invalid field, double-click guard, confirmation content, fully-booked and not-found views); verify they fail
- [x] 4.3 Implement the app shell (header, footer, theme, fonts), start page and booking flow; verify tests from 4.1 and 4.2 pass

## 5. Staff UI (tests first)

- [x] 5.1 Write failing component tests for sign-in (error next to Password), grouped bookings, empty state, Cancel, sign out; verify they fail
- [x] 5.2 Implement the `/staff` page; verify the tests from 5.1 pass

## 6. End-to-end and quality verification

- [x] 6.1 Write and run Playwright e2e tests against the built app: guest booking to confirmation, overbooking rejection, fully booked, staff sign-in, grouped list, cancel frees seats; verify all pass
- [x] 6.2 Run e2e at 360 px (no horizontal scroll, touch targets) plus axe accessibility checks and a keyboard-only booking; verify they pass and inspect screenshots of every page
- [x] 6.3 Security pass against `.opencode/references/security-checklist.md` (cookie flags, headers, rate limits, fail-closed password, no PII leaks); verify findings are fixed or documented
- [x] 6.4 Code review pass (correctness, readability, architecture, security, performance) and simplification; verify `npm run typecheck`, `npm test`, `npm run build` and e2e are green
- [x] 6.5 Write `README.md` (install, build, start, env vars, tests, limits such as in-memory bookings) and verify the documented commands run as written from a clean checkout
- [x] 6.6 Run `openspec validate` and the verify workflow against the change; verify no critical issues

## Workflow follow-up

- Archive the change after verification passes.
