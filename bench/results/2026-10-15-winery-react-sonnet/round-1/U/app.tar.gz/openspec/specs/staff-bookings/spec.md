# staff-bookings Specification

## Purpose
Lets winery staff sign in with a shared password, see who has booked each tasting and cancel bookings, while keeping guest data away from the public.

## Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL ask for a password in a field labelled "Password" with a "Sign in" button. The correct password is the value of the environment variable `STAFF_PASSWORD`. A wrong password SHALL be rejected with an error message shown next to the field.

#### Scenario: Correct password
- **WHEN** staff enter the value of `STAFF_PASSWORD` and press "Sign in"
- **THEN** the bookings overview is shown

#### Scenario: Wrong or empty password
- **WHEN** staff enter a wrong or empty password and press "Sign in"
- **THEN** an error is shown next to "Password" and no booking data is shown

#### Scenario: No password configured
- **WHEN** `STAFF_PASSWORD` is not set or empty
- **THEN** nobody can sign in

### Requirement: Booking data is protected
Booking data SHALL be available only to signed-in staff. Unauthenticated requests for it MUST be refused.

#### Scenario: Unauthenticated data request
- **WHEN** a request for the bookings list or a cancellation carries no valid staff session
- **THEN** it is refused as unauthorised and returns no booking data

#### Scenario: Guest pages expose no personal data
- **WHEN** a guest views any public page or public API response
- **THEN** no other guest's name or email is included

### Requirement: Bookings grouped by tasting
Signed-in staff SHALL see all bookings grouped by tasting, each showing name, email, number of guests and booking reference. Tastings without bookings SHALL show an empty state.

#### Scenario: Grouped list
- **WHEN** staff view the overview after bookings were made for two tastings
- **THEN** each tasting is a group listing its bookings with name, email, guests and reference

#### Scenario: No bookings yet
- **WHEN** a tasting has no bookings
- **THEN** its group states that there are no bookings

### Requirement: Cancel a booking
Signed-in staff SHALL be able to cancel a booking with a "Cancel" button on it. A cancelled booking disappears from the overview and its seats become available again.

#### Scenario: Cancelling frees seats
- **WHEN** staff cancel a booking of 4 guests for a tasting with 3 seats left
- **THEN** the booking is no longer listed and the tasting has 7 seats left

#### Scenario: Cancel an already cancelled booking
- **WHEN** a cancellation names a booking that no longer exists
- **THEN** the overview refreshes without error to the staff and no seats change

### Requirement: Sign out
Signed-in staff SHALL be able to sign out, after which booking data is no longer accessible.

#### Scenario: Sign out
- **WHEN** staff press "Sign out"
- **THEN** the sign-in form is shown and booking data requests are refused

### Requirement: Sign-in abuse resistance
The system SHALL limit repeated failed sign-in attempts from one client.

#### Scenario: Repeated failures
- **WHEN** a client makes many failed sign-in attempts in a short time
- **THEN** further attempts are refused with a "try again later" message
