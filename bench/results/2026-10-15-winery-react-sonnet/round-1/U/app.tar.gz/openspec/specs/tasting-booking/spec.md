# tasting-booking Specification

## Purpose
Defines how a guest books seats at a tasting: the form, input validation, the capacity guarantee and the confirmation, so every accepted booking is valid and never oversells a tasting.

## Requirements

### Requirement: Booking form
The booking form for a tasting SHALL show the tasting it is for and the fields labelled "Name", "Email" and "Guests", and a "Book" button.

#### Scenario: Form fields
- **WHEN** a guest opens the booking form of a tasting with seats left
- **THEN** the fields "Name", "Email" and "Guests" and a button "Book" are shown

### Requirement: Input validation with field errors
The system SHALL reject invalid input and show an error message next to the field it concerns. Name MUST NOT be blank after trimming and at most 100 characters. Email MUST be a valid email address. Guests MUST be a whole number from 1 to 8.

#### Scenario: Blank name
- **WHEN** a guest submits with an empty Name
- **THEN** no booking is created and an error is shown next to "Name"

#### Scenario: Invalid email
- **WHEN** a guest submits with Email "not-an-email"
- **THEN** no booking is created and an error is shown next to "Email"

#### Scenario: Guests out of range or not a whole number
- **WHEN** a guest submits with Guests 0, 9, 2.5 or empty
- **THEN** no booking is created and an error is shown next to "Guests"

#### Scenario: Several invalid fields
- **WHEN** a guest submits with several invalid fields
- **THEN** each invalid field shows its own error

#### Scenario: Entered values are kept
- **WHEN** a submission is rejected
- **THEN** the values the guest typed remain in the form

### Requirement: Capacity is never exceeded
The system SHALL reject any booking whose guest count exceeds the seats left for the tasting, regardless of how the request is made, including simultaneous requests.

#### Scenario: More guests than seats left
- **WHEN** 2 seats are left and a guest books 3
- **THEN** the booking is rejected, an error next to "Guests" says only 2 seats are left, and seats left stay at 2

#### Scenario: Exactly the seats left
- **WHEN** 2 seats are left and a guest books 2
- **THEN** the booking is accepted and the tasting becomes fully booked

#### Scenario: Concurrent requests for the last seats
- **WHEN** two requests each for 5 guests arrive at once for a tasting with 8 seats left
- **THEN** exactly one is accepted and the other is rejected for lack of seats

#### Scenario: Direct API requests are checked too
- **WHEN** a request outside the form sends invalid fields or too many guests
- **THEN** it is rejected with field-level errors and nothing is stored

#### Scenario: Unknown tasting
- **WHEN** a booking request names a tasting that does not exist
- **THEN** it is rejected as not found and nothing is stored

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (guests times price per guest, in EUR) and a booking reference. References MUST be unique and hard to guess.

#### Scenario: Confirmation content
- **WHEN** a guest books 3 guests for Red Wine Cellar Tour
- **THEN** the page shows "Booking confirmed", "Red Wine Cellar Tour", 3 guests, total "EUR 96" and a booking reference

#### Scenario: Seats are taken
- **WHEN** a booking is confirmed
- **THEN** the seats left for that tasting drop by the number of guests

### Requirement: Double submission protection
The booking form SHALL prevent a guest from submitting the same booking twice by repeated clicking while a request is in progress.

#### Scenario: Repeated clicks
- **WHEN** a guest clicks "Book" several times quickly
- **THEN** only one booking is created
