# tasting-catalog Specification

## Purpose
Defines which tastings the winery offers and how the start page presents them, so guests can see what is available and how many seats remain before booking.

## Requirements

### Requirement: Offered tastings
The system SHALL offer exactly these tastings: "Riesling Evening" on 2026-11-06 at 18:00, EUR 25 per guest, 12 seats; "Red Wine Cellar Tour" on 2026-11-14 at 15:00, EUR 32 per guest, 8 seats; "Winter Tasting" on 2026-12-05 at 17:00, EUR 28 per guest, 10 seats.

#### Scenario: Fresh start has full capacity
- **WHEN** the app has just started and has no bookings
- **THEN** the start page lists the three tastings with 12, 8 and 10 seats left respectively

### Requirement: Start page lists tastings
The start page at `/` SHALL list every tasting with its title, date and time, price per guest, and seats left shown as "<n> seats left".

#### Scenario: Tasting details are visible
- **WHEN** a guest opens the start page
- **THEN** each tasting shows its title, date, time, "EUR <price>" per guest and "<n> seats left"

#### Scenario: Seats left reflect bookings
- **WHEN** 3 guests have booked Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening

#### Scenario: Cancelled booking restores seats
- **WHEN** staff cancel that booking of 3 guests
- **THEN** the start page shows "12 seats left" for Riesling Evening again

### Requirement: Book link per tasting
Each tasting with seats left SHALL have a link named "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open the booking form
- **WHEN** a guest selects "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens

### Requirement: Fully booked tastings
A tasting with no seats left SHALL be clearly marked "Fully booked" and SHALL NOT offer a booking link or accept bookings.

#### Scenario: Last seats taken
- **WHEN** all seats of a tasting are booked
- **THEN** the start page shows "Fully booked" for it and no "Book <title>" link

#### Scenario: Direct visit to a fully booked form
- **WHEN** a guest opens the booking URL of a fully booked tasting
- **THEN** the page states that the tasting is fully booked and shows no booking form

### Requirement: Unknown tasting
The system SHALL show a clear not-found message with a way back to the start page when a booking URL names a tasting that does not exist.

#### Scenario: Unknown tasting URL
- **WHEN** a guest opens the booking URL of an unknown tasting
- **THEN** a "not found" message and a link to the start page are shown
