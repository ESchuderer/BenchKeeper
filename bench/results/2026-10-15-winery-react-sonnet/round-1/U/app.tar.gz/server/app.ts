import { existsSync } from "node:fs";
import { join, resolve } from "node:path";
import cookieParser from "cookie-parser";
import express, { type ErrorRequestHandler, type RequestHandler } from "express";
import { rateLimit } from "express-rate-limit";
import helmet from "helmet";
import { validateBooking } from "../shared/booking.js";
import { TASTINGS } from "../shared/tastings.js";
import { totalCents } from "../shared/format.js";
import { createSessionStore, passwordMatches, SESSION_COOKIE, SESSION_TTL_MS } from "./auth.js";
import { createBookingStore, type BookingStore } from "./store.js";

interface LimitOptions {
  limit?: number;
  windowMs?: number;
}

export interface AppOptions {
  store?: BookingStore;
  /** The shared staff password. Unset or empty disables staff sign-in entirely. */
  staffPassword?: string | undefined;
  /** Directory with the built client; when set it is served with a SPA fallback. */
  clientDir?: string;
  /** Mark the session cookie `Secure` (set when served over HTTPS). */
  cookieSecure?: boolean;
  now?: () => number;
  bookingRateLimit?: LimitOptions;
  loginRateLimit?: LimitOptions;
}

const requireJson: RequestHandler = (req, res, next) => {
  if (req.is("application/json")) return next();
  res.status(415).json({ error: "Send JSON with Content-Type: application/json." });
};

export function createApp(options: AppOptions = {}) {
  const store = options.store ?? createBookingStore(TASTINGS);
  const sessions = createSessionStore(options.now);
  const app = express();

  app.disable("x-powered-by");
  app.use((_req, res, next) => {
    res.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
    next();
  });
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          "default-src": ["'self'"],
          "img-src": ["'self'", "data:"],
          // Not set: it would break plain-http localhost use in some browsers.
          "upgrade-insecure-requests": null,
        },
      },
    }),
  );

  const api = express.Router();
  api.use((_req, res, next) => {
    res.set("Cache-Control", "no-store");
    next();
  });
  api.use(cookieParser());

  const bookingLimiter = rateLimit({
    windowMs: options.bookingRateLimit?.windowMs ?? 60_000,
    limit: options.bookingRateLimit?.limit ?? 120,
    standardHeaders: "draft-8",
    legacyHeaders: false,
    handler: (_req, res) => res.status(429).json({ error: "Too many requests. Please try again later." }),
  });

  const loginLimiter = rateLimit({
    windowMs: options.loginRateLimit?.windowMs ?? 15 * 60_000,
    limit: options.loginRateLimit?.limit ?? 10,
    skipSuccessfulRequests: true,
    standardHeaders: "draft-8",
    legacyHeaders: false,
    handler: (_req, res) =>
      res.status(429).json({ errors: { password: "Too many attempts. Please try again later." } }),
  });

  const requireStaff: RequestHandler = (req, res, next) => {
    if (sessions.isValid(req.cookies?.[SESSION_COOKIE])) return next();
    res.status(401).json({ error: "Staff sign-in required." });
  };

  // ---- public

  api.get("/tastings", (_req, res) => {
    res.json(store.list().map(({ bookings: _bookings, ...tasting }) => tasting));
  });

  api.post("/bookings", bookingLimiter, requireJson, express.json({ limit: "10kb" }), (req, res) => {
    const body: unknown = req.body;
    const requestedId = (body as { tastingId?: unknown } | null)?.tastingId;
    const tasting = typeof requestedId === "string" ? store.find(requestedId) : undefined;
    if (!tasting) {
      res.status(404).json({ error: "This tasting does not exist." });
      return;
    }

    const parsed = validateBooking(body);
    if (!parsed.ok) {
      res.status(422).json({ errors: parsed.errors });
      return;
    }

    const result = store.book({ tastingId: tasting.id, ...parsed.data });
    if (!result.ok) {
      if (result.reason === "unknown-tasting") {
        res.status(404).json({ error: "This tasting does not exist." });
        return;
      }
      const message =
        result.seatsLeft === 0
          ? "This tasting is fully booked."
          : `Only ${result.seatsLeft} ${result.seatsLeft === 1 ? "seat is" : "seats are"} left for this tasting.`;
      res.status(409).json({ errors: { guests: message } });
      return;
    }

    const { booking } = result;
    res.status(201).json({
      booking: {
        reference: booking.reference,
        tastingId: tasting.id,
        tastingTitle: tasting.title,
        startsAt: tasting.startsAt,
        guests: booking.guests,
        totalCents: totalCents(tasting.priceCents, booking.guests),
      },
    });
  });

  // ---- staff

  api.post("/staff/session", loginLimiter, requireJson, express.json({ limit: "1kb" }), (req, res) => {
    const password: unknown = req.body?.password;
    if (!passwordMatches(password, options.staffPassword)) {
      res.status(401).json({ errors: { password: "That password is not correct." } });
      return;
    }
    res.cookie(SESSION_COOKIE, sessions.create(), {
      httpOnly: true,
      sameSite: "strict",
      secure: options.cookieSecure ?? req.secure,
      path: "/",
      maxAge: SESSION_TTL_MS,
    });
    res.status(204).end();
  });

  // Answers 200 either way: "not signed in" is a normal state, not an error.
  api.get("/staff/session", (req, res) => {
    res.json({ signedIn: sessions.isValid(req.cookies?.[SESSION_COOKIE]) });
  });

  api.delete("/staff/session", (req, res) => {
    sessions.destroy(req.cookies?.[SESSION_COOKIE]);
    res.clearCookie(SESSION_COOKIE, { path: "/" });
    res.status(204).end();
  });

  api.get("/staff/bookings", requireStaff, (_req, res) => {
    res.json({ tastings: store.list() });
  });

  api.delete("/staff/bookings/:reference", requireStaff, (req, res) => {
    if (store.cancel(String(req.params.reference))) res.status(204).end();
    else res.status(404).json({ error: "This booking no longer exists." });
  });

  api.use((_req, res) => {
    res.status(404).json({ error: "Not found." });
  });

  app.use("/api", api);

  // ---- built client

  const { clientDir } = options;
  if (clientDir && existsSync(join(clientDir, "index.html"))) {
    app.use(
      "/assets",
      express.static(join(clientDir, "assets"), { immutable: true, maxAge: "1y", fallthrough: false }),
    );
    app.use(express.static(clientDir, { index: false, maxAge: "1h" }));
    const indexFile = resolve(clientDir, "index.html");
    app.use((req, res, next) => {
      if (req.method !== "GET" && req.method !== "HEAD") return next();
      res.set("Cache-Control", "no-cache");
      res.sendFile(indexFile);
    });
  }

  const onError: ErrorRequestHandler = (err, _req, res, _next) => {
    const status = typeof err?.status === "number" ? err.status : 500;
    if (status === 413) {
      res.status(413).json({ error: "Request is too large." });
    } else if (status >= 400 && status < 500) {
      res.status(status).json({ error: "The request could not be read." });
    } else {
      console.error(err);
      res.status(500).json({ error: "Something went wrong on our side. Please try again." });
    }
  };
  app.use(onError);

  return app;
}
