import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export const SESSION_COOKIE = "kb_staff";
export const SESSION_TTL_MS = 8 * 60 * 60 * 1000;

const digest = (value: string) => createHash("sha256").update(value).digest();

/** Constant-time comparison. An unset or empty configured password never matches. */
export function passwordMatches(candidate: unknown, expected: string | undefined): boolean {
  if (!expected || typeof candidate !== "string") return false;
  return timingSafeEqual(digest(candidate), digest(expected));
}

export interface SessionStore {
  create(): string;
  isValid(token: unknown): boolean;
  destroy(token: unknown): void;
}

export function createSessionStore(now: () => number = Date.now): SessionStore {
  const expiries = new Map<string, number>();

  const prune = () => {
    for (const [token, expiresAt] of expiries) if (expiresAt <= now()) expiries.delete(token);
  };

  return {
    create() {
      prune();
      const token = randomBytes(32).toString("base64url");
      expiries.set(token, now() + SESSION_TTL_MS);
      return token;
    },
    isValid(token) {
      if (typeof token !== "string") return false;
      const expiresAt = expiries.get(token);
      if (expiresAt === undefined) return false;
      if (expiresAt <= now()) {
        expiries.delete(token);
        return false;
      }
      return true;
    },
    destroy(token) {
      if (typeof token === "string") expiries.delete(token);
    },
  };
}
