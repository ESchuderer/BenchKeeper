import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";

const port = Number(process.env.PORT ?? 3000);
const staffPassword = process.env.STAFF_PASSWORD;

if (!staffPassword) {
  console.warn("STAFF_PASSWORD is not set: staff sign-in is disabled.");
}

const app = createApp({
  staffPassword,
  clientDir: join(dirname(fileURLToPath(import.meta.url)), "..", "client"),
  cookieSecure: process.env.COOKIE_SECURE === "true",
});

const server = app.listen(port, () => {
  console.log(`Weingut Kieselbrunnen bookings listening on http://localhost:${port}`);
});

for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
