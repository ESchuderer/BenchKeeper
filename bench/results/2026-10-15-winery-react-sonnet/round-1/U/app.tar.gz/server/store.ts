import { randomInt } from "node:crypto";
import type { Tasting } from "../shared/tastings.js";

export interface BookingRecord {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
}

export type NewBooking = Omit<BookingRecord, "reference">;

export type BookResult =
  | { ok: true; booking: BookingRecord }
  | { ok: false; reason: "unknown-tasting" }
  | { ok: false; reason: "capacity"; seatsLeft: number };

export interface TastingOverview extends Tasting {
  seatsLeft: number;
  bookings: BookingRecord[];
}

export interface BookingStore {
  find(tastingId: string): Tasting | undefined;
  book(input: NewBooking): BookResult;
  cancel(reference: string): boolean;
  seatsLeft(tastingId: string): number;
  list(): TastingOverview[];
}

// No I, L, O, 0 or 1: references get read aloud and typed in.
const REFERENCE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

function newReference(): string {
  let code = "";
  for (let i = 0; i < 8; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  return `KB-${code}`;
}

/**
 * In-memory store. `book` checks capacity and inserts in one synchronous step,
 * so concurrent requests on Node's single thread can never oversell a tasting.
 * Keep it synchronous: introducing an `await` between check and insert would break that guarantee.
 */
export function createBookingStore(tastings: readonly Tasting[]): BookingStore {
  const bookings = new Map<string, BookingRecord>();

  const taken = (tastingId: string) => {
    let seats = 0;
    for (const booking of bookings.values()) if (booking.tastingId === tastingId) seats += booking.guests;
    return seats;
  };

  const seatsLeft = (tastingId: string) => {
    const tasting = tastings.find((t) => t.id === tastingId);
    return tasting ? tasting.seats - taken(tastingId) : 0;
  };

  return {
    seatsLeft,

    find: (tastingId) => tastings.find((t) => t.id === tastingId),

    book(input) {
      const tasting = tastings.find((t) => t.id === input.tastingId);
      if (!tasting) return { ok: false, reason: "unknown-tasting" };
      const left = seatsLeft(tasting.id);
      if (input.guests > left) return { ok: false, reason: "capacity", seatsLeft: left };

      let reference = newReference();
      while (bookings.has(reference)) reference = newReference();
      const booking: BookingRecord = { ...input, reference };
      bookings.set(reference, booking);
      return { ok: true, booking };
    },

    cancel: (reference) => bookings.delete(reference),

    list: () =>
      tastings.map((tasting) => ({
        ...tasting,
        seatsLeft: seatsLeft(tasting.id),
        bookings: [...bookings.values()].filter((b) => b.tastingId === tasting.id),
      })),
  };
}
