import { z } from "zod";

export const MAX_GUESTS = 8;
export const MAX_NAME_LENGTH = 100;

export const bookingFieldsSchema = z.object({
  name: z
    .string({ error: "Enter your name." })
    .trim()
    .min(1, "Enter your name.")
    .max(MAX_NAME_LENGTH, `Name must be at most ${MAX_NAME_LENGTH} characters.`),
  email: z
    .string({ error: "Enter your email address." })
    .trim()
    .min(1, "Enter your email address.")
    .max(254, "Email address is too long.")
    .pipe(z.email("Enter a valid email address, like name@example.com.")),
  guests: z
    .number({ error: `Enter the number of guests, from 1 to ${MAX_GUESTS}.` })
    .int(`Enter a whole number of guests, from 1 to ${MAX_GUESTS}.`)
    .min(1, `Enter at least 1 guest.`)
    .max(MAX_GUESTS, `A booking can have at most ${MAX_GUESTS} guests.`),
});

export type BookingFields = z.infer<typeof bookingFieldsSchema>;
export type BookingField = keyof BookingFields;
export type FieldErrors = Partial<Record<BookingField, string>>;

export type ValidationResult = { ok: true; data: BookingFields } | { ok: false; errors: FieldErrors };

export function validateBooking(input: unknown): ValidationResult {
  const result = bookingFieldsSchema.safeParse(input);
  if (result.success) return { ok: true, data: result.data };

  const errors: FieldErrors = {};
  for (const issue of result.error.issues) {
    const field = issue.path[0];
    if (field === "name" || field === "email" || field === "guests") {
      errors[field] ??= issue.message;
    }
  }
  // A non-object payload has no field path; attribute it to the first field.
  if (Object.keys(errors).length === 0) errors.name = "Enter your name.";
  return { ok: false, errors };
}
