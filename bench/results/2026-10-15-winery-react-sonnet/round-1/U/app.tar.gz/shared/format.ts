export function formatPrice(cents: number): string {
  const euros = cents / 100;
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`;
}

export function totalCents(priceCents: number, guests: number): number {
  return priceCents * guests;
}

const DATE_FORMAT = new Intl.DateTimeFormat("en-GB", {
  weekday: "short",
  day: "numeric",
  month: "short",
  year: "numeric",
  timeZone: "UTC",
});

/** Renders the winery's wall-clock time as written, whatever the viewer's timezone. */
export function formatStart(startsAt: string): { date: string; time: string } {
  const [datePart = "", time = ""] = startsAt.split("T");
  const [year = 0, month = 1, day = 1] = datePart.split("-").map(Number);
  const date = DATE_FORMAT.format(new Date(Date.UTC(year, month - 1, day)))
    // ICU versions differ on whether en-GB puts a comma after the weekday; normalise it
    .replace(/^(\w{3}) /, "$1, ");
  return { date, time };
}
