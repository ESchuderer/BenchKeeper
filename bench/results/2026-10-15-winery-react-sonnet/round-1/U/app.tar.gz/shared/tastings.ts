export interface Tasting {
  id: string;
  title: string;
  /** Local wall-clock time at the winery, `YYYY-MM-DDTHH:mm`, deliberately without a timezone. */
  startsAt: string;
  priceCents: number;
  seats: number;
}

export const TASTINGS: readonly Tasting[] = [
  {
    id: "riesling-evening",
    title: "Riesling Evening",
    startsAt: "2026-11-06T18:00",
    priceCents: 2500,
    seats: 12,
  },
  {
    id: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    startsAt: "2026-11-14T15:00",
    priceCents: 3200,
    seats: 8,
  },
  {
    id: "winter-tasting",
    title: "Winter Tasting",
    startsAt: "2026-12-05T17:00",
    priceCents: 2800,
    seats: 10,
  },
];
