import type { BookingFields } from "../shared/booking";

export interface TastingView {
  id: string;
  title: string;
  startsAt: string;
  priceCents: number;
  seats: number;
  seatsLeft: number;
}

export interface ConfirmedBooking {
  reference: string;
  tastingId: string;
  tastingTitle: string;
  startsAt: string;
  guests: number;
  totalCents: number;
}

export interface StaffBooking {
  reference: string;
  name: string;
  email: string;
  guests: number;
}

export interface StaffTasting extends TastingView {
  bookings: StaffBooking[];
}

/** The server answered with an error status. `fieldErrors` is set for validation and capacity errors. */
export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
    readonly fieldErrors: Partial<Record<string, string>> = {},
  ) {
    super(message);
  }
}

/** The server could not be reached at all. */
export class NetworkError extends Error {
  constructor() {
    super("We could not reach the server. Check your connection and try again.");
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(path, init);
  } catch {
    throw new NetworkError();
  }
  const body = (await response.json().catch(() => null)) as {
    error?: string;
    errors?: Record<string, string>;
  } | null;
  if (!response.ok) {
    throw new ApiError(
      response.status,
      body?.error ?? "Something went wrong on our side. Please try again.",
      body?.errors,
    );
  }
  return body as T;
}

const json = (method: string, body: unknown): RequestInit => ({
  method,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body),
});

export const fetchTastings = () => request<TastingView[]>("/api/tastings");

export const createBooking = (tastingId: string, fields: BookingFields) =>
  request<{ booking: ConfirmedBooking }>("/api/bookings", json("POST", { tastingId, ...fields })).then(
    (r) => r.booking,
  );

export const fetchStaffSession = () =>
  request<{ signedIn: boolean }>("/api/staff/session").then((r) => r.signedIn);

export const fetchStaffBookings = () =>
  request<{ tastings: StaffTasting[] }>("/api/staff/bookings").then((r) => r.tastings);

export const staffSignIn = (password: string) =>
  request<null>("/api/staff/session", json("POST", { password }));

export const staffSignOut = () => request<null>("/api/staff/session", { method: "DELETE" });

export const cancelBooking = (reference: string) =>
  request<null>(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: "DELETE" });
