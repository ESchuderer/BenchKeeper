import type { ReactNode } from "react";
import { AlertIcon } from "./Icons";

export function Loading({ children }: { children: ReactNode }) {
  return (
    <div role="status" className="flex items-center gap-3 py-10 text-muted">
      <span
        aria-hidden="true"
        className="size-5 animate-spin rounded-full border-2 border-line border-t-wine"
      />
      {children}
    </div>
  );
}

export function ErrorNotice({ children, onRetry }: { children: ReactNode; onRetry?: () => void }) {
  return (
    <div role="alert" className="notice border-danger/40 bg-danger-soft text-danger">
      <AlertIcon className="mt-1 shrink-0" />
      <div className="flex flex-1 flex-col items-start gap-3 text-ink">
        <p className="font-semibold">{children}</p>
        {onRetry && (
          <button type="button" className="btn btn-quiet" onClick={onRetry}>
            Try again
          </button>
        )}
      </div>
    </div>
  );
}
