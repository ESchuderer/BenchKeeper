import type { SVGProps } from "react";

const base: SVGProps<SVGSVGElement> = {
  width: 20,
  height: 20,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
  focusable: false,
};

export const AlertIcon = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base} className="mt-0.5 shrink-0" width={18} height={18} {...p}>
    <circle cx="12" cy="12" r="10" />
    <path d="M12 7v6M12 16.5v.5" />
  </svg>
);

export const CheckIcon = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="10" />
    <path d="m7.5 12.5 3 3 6-7" />
  </svg>
);

export const ClockIcon = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="10" />
    <path d="M12 7v5l3 2" />
  </svg>
);

export const GlassIcon = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base} {...p}>
    <path d="M7 3h10c0 6-1.5 9-5 10-3.5-1-5-4-5-10Z" />
    <path d="M12 13v8M8 21h8" />
  </svg>
);

export function Logo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true" focusable="false">
      <circle cx="24" cy="24" r="23" fill="#6b1d2a" />
      <path d="M15 9h18c0 11-3 17-9 19-6-2-9-8-9-19Z" fill="#f6ecd9" />
      <path d="M15.6 19h16.8c-.5 6-3.2 9-8.4 9s-7.9-3-8.4-9Z" fill="#b24559" />
      <path d="M24 28v11M18 40h12" stroke="#f6ecd9" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}
