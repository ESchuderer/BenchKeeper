import { useEffect, useRef } from "react";
import { Link, Outlet, useLocation } from "react-router";
import { Logo } from "./Icons";

export function Layout() {
  const { pathname } = useLocation();
  const main = useRef<HTMLElement>(null);
  const first = useRef(true);

  // After client-side navigation, move focus to the new content (not on first load).
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    main.current?.focus();
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-10 focus:rounded focus:bg-paper focus:px-4 focus:py-2 focus:font-semibold"
      >
        Skip to content
      </a>
      <header className="border-b border-line bg-paper">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Link to="/" className="flex items-center gap-3 text-wine no-underline">
            <Logo className="size-11 shrink-0" />
            <span className="leading-tight">
              <span className="block font-display text-2xl font-bold">Weingut Kieselbrunnen</span>
              <span className="block text-xs font-semibold uppercase tracking-widest text-muted">
                Family winery
              </span>
            </span>
          </Link>
        </div>
        <div aria-hidden="true" className="h-1 bg-wine" />
      </header>

      <main
        id="content"
        ref={main}
        tabIndex={-1}
        className="mx-auto w-full max-w-4xl flex-1 px-4 py-8 sm:px-6 sm:py-12"
      >
        <Outlet />
      </main>

      <footer className="border-t border-line bg-parchment">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-x-6 gap-y-1 px-4 py-5 text-sm text-muted sm:px-6">
          <p>Weingut Kieselbrunnen &middot; a family winery</p>
          <Link to="/staff" className="inline-flex min-h-11 items-center text-muted">
            Staff sign-in
          </Link>
        </div>
      </footer>
    </div>
  );
}
