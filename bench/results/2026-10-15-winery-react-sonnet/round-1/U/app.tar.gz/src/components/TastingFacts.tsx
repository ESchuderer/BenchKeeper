import { formatPrice, formatStart } from "../../shared/format";
import type { TastingView } from "../api";
import { ClockIcon } from "./Icons";

export function seatsBadge(seatsLeft: number) {
  const full = seatsLeft === 0;
  const low = !full && seatsLeft <= 3;
  const tone = full
    ? "bg-danger-soft text-danger"
    : low
      ? "bg-amber-soft text-amber-ink"
      : "bg-vine-soft text-vine";
  return { full, tone };
}

export function SeatsLeft({ seatsLeft }: { seatsLeft: number }) {
  const { full, tone } = seatsBadge(seatsLeft);
  return (
    <span className="inline-flex flex-wrap items-center gap-2">
      <span className={`badge ${tone}`}>
        <span aria-hidden="true" className="size-2 rounded-full bg-current" />
        {seatsLeft} seats left
      </span>
      {full && <span className="badge bg-danger text-white">Fully booked</span>}
    </span>
  );
}

/** Date, time and price of a tasting; shared by the list and the booking form. */
export function TastingFacts({ tasting }: { tasting: TastingView }) {
  const { date, time } = formatStart(tasting.startsAt);
  return (
    <dl className="flex flex-wrap items-center gap-x-5 gap-y-1 text-[0.9375rem]">
      <div className="flex items-center gap-1.5">
        <dt className="sr-only">When</dt>
        <ClockIcon width={18} height={18} className="text-muted" />
        <dd>
          <span>{date}</span>
          <span aria-hidden="true"> · </span>
          <span className="sr-only">, </span>
          <span>{time}</span>
        </dd>
      </div>
      <div className="flex items-baseline gap-1.5">
        <dt className="text-muted">Price per guest</dt>
        <dd className="font-semibold">{formatPrice(tasting.priceCents)}</dd>
      </div>
    </dl>
  );
}
