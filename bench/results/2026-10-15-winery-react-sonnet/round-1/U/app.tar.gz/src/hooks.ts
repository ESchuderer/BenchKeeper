import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchTastings } from "./api";

const SITE = "Weingut Kieselbrunnen";

export function useDocumentTitle(title?: string) {
  useEffect(() => {
    document.title = title ? `${title} · ${SITE}` : `Wine tastings · ${SITE}`;
  }, [title]);
}

export const tastingsKey = ["tastings"] as const;

export function useTastings() {
  return useQuery({ queryKey: tastingsKey, queryFn: fetchTastings });
}
