import { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";
import { Link, useParams } from "react-router";
import { bookingFieldsSchema, MAX_GUESTS, type BookingField, type BookingFields } from "../../shared/booking";
import { formatPrice, formatStart } from "../../shared/format";
import { ApiError, createBooking, NetworkError, type ConfirmedBooking, type TastingView } from "../api";
import { ErrorNotice, Loading } from "../components/Feedback";
import { Field } from "../components/Field";
import { CheckIcon } from "../components/Icons";
import { SeatsLeft, TastingFacts } from "../components/TastingFacts";
import { tastingsKey, useDocumentTitle, useTastings } from "../hooks";

function BackLink() {
  return (
    <Link to="/" className="inline-flex min-h-11 items-center font-semibold">
      <span aria-hidden="true">←&nbsp;</span>All tastings
    </Link>
  );
}

function Confirmation({ booking }: { booking: ConfirmedBooking }) {
  const { date, time } = formatStart(booking.startsAt);
  const focusOnMount = (node: HTMLHeadingElement | null) => node?.focus();
  return (
    <section aria-labelledby="confirmed-heading" className="card overflow-hidden">
      <div className="flex items-center gap-3 bg-vine px-5 py-4 text-white sm:px-8">
        <CheckIcon width={28} height={28} />
        <h1 id="confirmed-heading" ref={focusOnMount} tabIndex={-1} className="!text-white text-3xl">
          Booking confirmed
        </h1>
      </div>
      <div className="space-y-6 p-5 sm:p-8">
        <p className="text-lg">Thank you. Your seats are reserved, and we look forward to seeing you.</p>
        <dl className="grid gap-x-8 gap-y-4 sm:grid-cols-2">
          <div>
            <dt className="text-sm font-semibold uppercase tracking-wider text-muted">Tasting</dt>
            <dd className="text-lg font-semibold">{booking.tastingTitle}</dd>
          </div>
          <div>
            <dt className="text-sm font-semibold uppercase tracking-wider text-muted">When</dt>
            <dd className="text-lg">
              {date}, {time}
            </dd>
          </div>
          <div>
            <dt className="text-sm font-semibold uppercase tracking-wider text-muted">Guests</dt>
            <dd className="text-lg">{booking.guests}</dd>
          </div>
          <div>
            <dt className="text-sm font-semibold uppercase tracking-wider text-muted">Total price</dt>
            <dd className="text-lg font-semibold">{formatPrice(booking.totalCents)}</dd>
          </div>
        </dl>
        <div className="rounded-md border border-dashed border-wine/50 bg-wine-soft p-4">
          <p className="text-sm font-semibold uppercase tracking-wider text-muted">Booking reference</p>
          <p className="mt-1 font-mono text-2xl font-bold tracking-wider text-wine select-all">
            {booking.reference}
          </p>
          <p className="mt-1 text-sm text-muted">
            Please keep this reference and quote it if you need to reach us.
          </p>
        </div>
        <p className="text-sm text-muted">The total is payable at the winery.</p>
        <BackLink />
      </div>
    </section>
  );
}

const FIELD_NAMES: readonly BookingField[] = ["name", "email", "guests"];

function BookingForm({
  tasting,
  onBooked,
}: {
  tasting: TastingView;
  onBooked: (b: ConfirmedBooking) => void;
}) {
  const queryClient = useQueryClient();
  const [formError, setFormError] = useState<string | null>(null);
  const inFlight = useRef(false);

  const {
    register,
    handleSubmit,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<BookingFields>({
    resolver: zodResolver(bookingFieldsSchema),
    defaultValues: { name: "", email: "", guests: 2 },
  });

  const guests = watch("guests");
  const total =
    Number.isInteger(guests) && guests >= 1 && guests <= MAX_GUESTS ? guests * tasting.priceCents : null;

  const onSubmit = async (values: BookingFields) => {
    if (inFlight.current) return;
    inFlight.current = true;
    setFormError(null);
    try {
      onBooked(await createBooking(tasting.id, values));
    } catch (error) {
      if (error instanceof ApiError && Object.keys(error.fieldErrors).length > 0) {
        let focused = false;
        for (const field of FIELD_NAMES) {
          const message = error.fieldErrors[field];
          if (message) {
            setError(field, { type: "server", message }, { shouldFocus: !focused });
            focused = true;
          }
        }
      } else if (error instanceof NetworkError || error instanceof ApiError) {
        setFormError(error.message);
      } else {
        setFormError("Something went wrong. Please try again.");
      }
    } finally {
      inFlight.current = false;
      // Seats may have changed, whatever the outcome.
      void queryClient.invalidateQueries({ queryKey: tastingsKey });
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-[1fr_20rem] md:items-start md:gap-8">
      <aside aria-label="About this tasting" className="card space-y-3 bg-parchment/60 p-5 md:order-2">
        <TastingFacts tasting={tasting} />
        <SeatsLeft seatsLeft={tasting.seatsLeft} />
      </aside>
      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="card space-y-5 p-5 sm:p-8 md:order-1"
        aria-label={`Book ${tasting.title}`}
      >
        <p className="text-muted">All fields are required.</p>
        <Field label="Name" error={errors.name?.message}>
          {(a11y) => (
            <input {...a11y} {...register("name")} type="text" autoComplete="name" className="input" />
          )}
        </Field>
        <Field label="Email" error={errors.email?.message}>
          {(a11y) => (
            <input {...a11y} {...register("email")} type="email" autoComplete="email" className="input" />
          )}
        </Field>
        <Field
          label="Guests"
          hint={`Between 1 and ${MAX_GUESTS} guests per booking.`}
          error={errors.guests?.message}
        >
          {(a11y) => (
            <input
              {...a11y}
              {...register("guests", { valueAsNumber: true })}
              type="number"
              inputMode="numeric"
              min={1}
              max={MAX_GUESTS}
              step={1}
              className="input sm:max-w-32"
            />
          )}
        </Field>

        {formError && <ErrorNotice>{formError}</ErrorNotice>}

        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-line pt-5">
          <p aria-live="polite" className="text-lg">
            {total !== null ? (
              <>
                Total <strong className="font-semibold">{formatPrice(total)}</strong>
              </>
            ) : (
              <span className="text-muted">Total shown once guests are set</span>
            )}
          </p>
          <button
            type="submit"
            className="btn w-full sm:w-auto sm:min-w-40"
            disabled={isSubmitting}
            aria-busy={isSubmitting}
          >
            {isSubmitting ? "Booking…" : "Book"}
          </button>
        </div>
      </form>
    </div>
  );
}

export function BookingPage() {
  const { tastingId = "" } = useParams();
  const { data, isError, refetch } = useTastings();
  const [confirmation, setConfirmation] = useState<ConfirmedBooking | null>(null);
  const tasting = data?.find((t) => t.id === tastingId);

  useDocumentTitle(confirmation ? "Booking confirmed" : tasting ? `Book ${tasting.title}` : "Booking");

  // The confirmation stays on screen even if this booking took the last seats.
  if (confirmation) return <Confirmation booking={confirmation} />;

  // A failed background refresh must not throw away a form the guest is filling in.
  if (!data) {
    return isError ? (
      <ErrorNotice onRetry={() => void refetch()}>We could not load this tasting.</ErrorNotice>
    ) : (
      <Loading>Loading tasting…</Loading>
    );
  }

  if (!tasting) {
    return (
      <div className="space-y-4">
        <h1 className="text-4xl">Tasting not found</h1>
        <p className="text-muted">We could not find that tasting. It may have been renamed or removed.</p>
        <BackLink />
      </div>
    );
  }

  if (tasting.seatsLeft === 0) {
    return (
      <div className="space-y-4">
        <h1 className="text-4xl">{tasting.title}</h1>
        <div role="status" className="notice border-danger/40 bg-danger-soft">
          <div>
            <p className="text-xl font-bold text-danger">Fully booked</p>
            <p>Every seat is taken for this tasting. Please have a look at our other dates.</p>
          </div>
        </div>
        <BackLink />
      </div>
    );
  }

  return (
    <>
      <BackLink />
      <h1 className="mb-6 mt-2 text-4xl sm:text-5xl">Book {tasting.title}</h1>
      <BookingForm tasting={tasting} onBooked={setConfirmation} />
    </>
  );
}
