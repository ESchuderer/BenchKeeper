import { Link } from "react-router";
import { formatPrice, formatStart } from "../../shared/format";
import type { TastingView } from "../api";
import { ErrorNotice, Loading } from "../components/Feedback";
import { SeatsLeft } from "../components/TastingFacts";
import { useDocumentTitle, useTastings } from "../hooks";

function DateTile({ startsAt, muted }: { startsAt: string; muted: boolean }) {
  const [, day = "", month = ""] = formatStart(startsAt).date.replace(",", "").split(" ");
  return (
    <div
      aria-hidden="true"
      className={`flex size-16 shrink-0 flex-col items-center justify-center rounded-md border font-display leading-none [font-variant-numeric:lining-nums] ${
        muted ? "border-line bg-parchment text-muted" : "border-wine bg-wine text-cream"
      }`}
    >
      <span className="text-3xl font-bold">{day}</span>
      <span className="mt-1 text-sm font-semibold uppercase tracking-wider">{month}</span>
    </div>
  );
}

function TastingCard({ tasting }: { tasting: TastingView }) {
  const { date, time } = formatStart(tasting.startsAt);
  const full = tasting.seatsLeft === 0;
  const headingId = `tasting-${tasting.id}`;
  return (
    <article
      aria-labelledby={headingId}
      className={`card flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:gap-6 ${full ? "bg-parchment/60" : ""}`}
    >
      <div className="flex flex-1 items-start gap-4 sm:items-center sm:gap-6">
        <DateTile startsAt={tasting.startsAt} muted={full} />
        <div className="min-w-0 flex-1 space-y-2">
          <h2 id={headingId} className={`text-2xl ${full ? "text-muted" : ""}`}>
            {tasting.title}
          </h2>
          <p className="text-[0.9375rem]">
            <span>{date}</span>
            <span aria-hidden="true"> · </span>
            <span className="sr-only">, </span>
            <span>{time}</span>
          </p>
          <p className="flex flex-wrap items-center gap-x-3 gap-y-2">
            <span className="font-semibold">{formatPrice(tasting.priceCents)}</span>
            <span className="text-sm text-muted">per guest</span>
            <SeatsLeft seatsLeft={tasting.seatsLeft} />
          </p>
        </div>
      </div>
      {full ? (
        <p className="text-sm text-muted sm:max-w-40 sm:text-right">Please check back for new dates.</p>
      ) : (
        <Link to={`/book/${tasting.id}`} className="btn w-full sm:w-auto">
          Book {tasting.title}
        </Link>
      )}
    </article>
  );
}

export function HomePage() {
  useDocumentTitle();
  const { data, isPending, isError, refetch } = useTastings();

  return (
    <>
      <section className="mb-8 max-w-2xl sm:mb-10">
        <p className="mb-2 text-sm font-semibold uppercase tracking-widest text-vine">
          Weingut Kieselbrunnen
        </p>
        <h1 className="text-4xl sm:text-5xl">Wine tastings at the winery</h1>
        <p className="mt-4 text-lg text-muted">
          Join us in the cellar for an evening with our wines. Pick a tasting, tell us how many of you are
          coming, and your seats are reserved.
        </p>
      </section>

      {isPending && <Loading>Loading tastings…</Loading>}
      {isError && <ErrorNotice onRetry={() => void refetch()}>We could not load the tastings.</ErrorNotice>}
      {data && (
        <ul className="space-y-4">
          {data.map((tasting) => (
            <li key={tasting.id}>
              <TastingCard tasting={tasting} />
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
