import { Link } from "react-router";
import { useDocumentTitle } from "../hooks";

export function NotFoundPage() {
  useDocumentTitle("Page not found");
  return (
    <div className="space-y-4">
      <h1 className="text-4xl">Page not found</h1>
      <p className="text-muted">The page you are looking for does not exist.</p>
      <Link to="/" className="inline-flex min-h-11 items-center font-semibold">
        <span aria-hidden="true">←&nbsp;</span>All tastings
      </Link>
    </div>
  );
}
