import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { formatStart } from "../../shared/format";
import {
  ApiError,
  cancelBooking,
  fetchStaffBookings,
  fetchStaffSession,
  staffSignIn,
  staffSignOut,
  type StaffTasting,
} from "../api";
import { ErrorNotice, Loading } from "../components/Feedback";
import { Field } from "../components/Field";
import { useDocumentTitle } from "../hooks";

const sessionKey = ["staff-session"] as const;
const staffKey = ["staff-bookings"] as const;
const signInSchema = z.object({ password: z.string().min(1, "Enter the staff password.") });
type SignInValues = z.infer<typeof signInSchema>;

function SignIn({ onSignedIn }: { onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<SignInValues>({ resolver: zodResolver(signInSchema), defaultValues: { password: "" } });
  const [formError, setFormError] = useState<string | null>(null);

  const onSubmit = async ({ password }: SignInValues) => {
    setFormError(null);
    try {
      await staffSignIn(password);
      onSignedIn();
    } catch (error) {
      if (error instanceof ApiError && error.fieldErrors.password) {
        setError("password", { type: "server", message: error.fieldErrors.password }, { shouldFocus: true });
      } else {
        setFormError(error instanceof Error ? error.message : "Sign-in failed. Please try again.");
      }
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-2 text-4xl">Staff sign-in</h1>
      <p className="mb-6 text-muted">Enter the staff password to see the bookings.</p>
      <form
        noValidate
        onSubmit={handleSubmit(onSubmit)}
        className="card space-y-5 p-5 sm:p-8"
        aria-label="Staff sign-in"
      >
        <Field label="Password" error={errors.password?.message}>
          {(a11y) => (
            <input
              {...a11y}
              {...register("password")}
              type="password"
              autoComplete="current-password"
              className="input"
            />
          )}
        </Field>
        {formError && <ErrorNotice>{formError}</ErrorNotice>}
        <button type="submit" className="btn w-full" disabled={isSubmitting}>
          Sign in
        </button>
      </form>
    </div>
  );
}

function TastingGroup({
  tasting,
  onCancel,
  cancelling,
}: {
  tasting: StaffTasting;
  onCancel: (reference: string) => void;
  cancelling: string | null;
}) {
  const { date, time } = formatStart(tasting.startsAt);
  const booked = tasting.seats - tasting.seatsLeft;
  const headingId = `staff-${tasting.id}`;
  return (
    <section aria-labelledby={headingId} className="card overflow-hidden">
      <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b border-line bg-parchment px-4 py-3 sm:px-6">
        <h2 id={headingId} className="text-2xl">
          {tasting.title}
        </h2>
        <p className="text-sm text-muted">
          {date}, {time} &middot; {booked} of {tasting.seats} seats booked
        </p>
      </div>
      {tasting.bookings.length === 0 ? (
        <p className="px-4 py-6 text-muted sm:px-6">No bookings yet.</p>
      ) : (
        <ul className="divide-y divide-line">
          {tasting.bookings.map((booking) => {
            const detailsId = `booking-${booking.reference}`;
            return (
              <li
                key={booking.reference}
                className="flex flex-wrap items-center justify-between gap-x-6 gap-y-3 px-4 py-4 sm:px-6"
              >
                <div id={detailsId} className="min-w-0 flex-1 basis-56">
                  <p className="font-semibold">{booking.name}</p>
                  <p className="break-all text-sm text-muted">{booking.email}</p>
                </div>
                <dl className="flex items-center gap-6 text-sm">
                  <div>
                    <dt className="text-muted">Guests</dt>
                    <dd className="text-base font-semibold">{booking.guests}</dd>
                  </div>
                  <div>
                    <dt className="text-muted">Reference</dt>
                    <dd className="font-mono text-base font-semibold text-wine">{booking.reference}</dd>
                  </div>
                </dl>
                <button
                  type="button"
                  className="btn btn-danger"
                  aria-describedby={detailsId}
                  disabled={cancelling === booking.reference}
                  onClick={() => onCancel(booking.reference)}
                >
                  Cancel
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function Overview({ tastings }: { tastings: StaffTasting[] }) {
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const [cancelling, setCancelling] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const signOut = useMutation({
    mutationFn: staffSignOut,
    onSettled: () => {
      // Drop booking data from memory and fall back to the sign-in form.
      queryClient.removeQueries({ queryKey: staffKey });
      queryClient.setQueryData(sessionKey, false);
    },
  });

  const onCancel = async (reference: string) => {
    setCancelling(reference);
    setError(null);
    try {
      await cancelBooking(reference);
      setMessage(`Booking ${reference} was cancelled and its seats are free again.`);
    } catch (e) {
      if (e instanceof ApiError && e.status === 404) {
        setMessage(`Booking ${reference} had already been cancelled.`);
      } else {
        setMessage("");
        setError(e instanceof Error ? e.message : "Could not cancel the booking.");
      }
    } finally {
      setCancelling(null);
      await queryClient.invalidateQueries({ queryKey: staffKey });
    }
  };

  const total = tastings.reduce((sum, t) => sum + t.bookings.length, 0);

  return (
    <>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl">Bookings</h1>
          <p className="text-muted">
            {total === 0
              ? "No bookings yet."
              : `${total} ${total === 1 ? "booking" : "bookings"} across all tastings.`}
          </p>
        </div>
        <button type="button" className="btn btn-quiet" onClick={() => signOut.mutate()}>
          Sign out
        </button>
      </div>

      <div role="status" className={message ? "notice mb-4 border-vine/40 bg-vine-soft text-ink" : "sr-only"}>
        {message}
      </div>
      {error && (
        <div className="mb-4">
          <ErrorNotice>{error}</ErrorNotice>
        </div>
      )}

      <div className="space-y-6">
        {tastings.map((tasting) => (
          <TastingGroup
            key={tasting.id}
            tasting={tasting}
            onCancel={(r) => void onCancel(r)}
            cancelling={cancelling}
          />
        ))}
      </div>
    </>
  );
}

export function StaffPage() {
  useDocumentTitle("Staff");
  const queryClient = useQueryClient();
  const session = useQuery({ queryKey: sessionKey, queryFn: fetchStaffSession, refetchOnWindowFocus: false });
  const signedIn = session.data === true;
  const bookings = useQuery({
    queryKey: staffKey,
    queryFn: fetchStaffBookings,
    enabled: signedIn,
    refetchOnWindowFocus: false,
  });

  // The session ended (for example it expired) while the page was open.
  const expired = bookings.error instanceof ApiError && bookings.error.status === 401;
  useEffect(() => {
    if (expired) {
      queryClient.removeQueries({ queryKey: staffKey });
      queryClient.setQueryData(sessionKey, false);
    }
  }, [expired, queryClient]);

  if (session.isPending) return <Loading>Checking sign-in…</Loading>;
  if (session.isError)
    return <ErrorNotice onRetry={() => void session.refetch()}>We could not check your sign-in.</ErrorNotice>;
  if (!signedIn) return <SignIn onSignedIn={() => queryClient.setQueryData(sessionKey, true)} />;
  if (bookings.data) return <Overview tastings={bookings.data} />;
  if (bookings.isError && !expired) {
    return <ErrorNotice onRetry={() => void bookings.refetch()}>We could not load the bookings.</ErrorNotice>;
  }
  return <Loading>Loading bookings…</Loading>;
}
