import request from "supertest";
import { beforeEach, describe, expect, it } from "vitest";
import { createApp } from "../server/app";
import { createBookingStore, type BookingStore } from "../server/store";
import { TASTINGS } from "../shared/tastings";

const PASSWORD = "correct horse battery staple";
const guest = { name: "Anna Weber", email: "anna@example.com", guests: 2 };

let store: BookingStore;
let clock: { now: number };
let app: ReturnType<typeof createApp>;

beforeEach(() => {
  store = createBookingStore(TASTINGS);
  clock = { now: Date.parse("2026-10-14T10:00:00Z") };
  app = createApp({ store, staffPassword: PASSWORD, now: () => clock.now });
});

const book = (body: Record<string, unknown>) => request(app).post("/api/bookings").send(body);
const seatsLeft = async (id: string) => {
  const res = await request(app).get("/api/tastings");
  return (res.body as { id: string; seatsLeft: number }[]).find((t) => t.id === id)?.seatsLeft;
};
async function staffAgent() {
  const agent = request.agent(app);
  await agent.post("/api/staff/session").send({ password: PASSWORD }).expect(204);
  return agent;
}

describe("GET /api/tastings", () => {
  it("lists the three tastings with full seats on a fresh start", async () => {
    const res = await request(app).get("/api/tastings").expect(200);
    expect(res.body).toEqual([
      {
        id: "riesling-evening",
        title: "Riesling Evening",
        startsAt: "2026-11-06T18:00",
        priceCents: 2500,
        seats: 12,
        seatsLeft: 12,
      },
      {
        id: "red-wine-cellar-tour",
        title: "Red Wine Cellar Tour",
        startsAt: "2026-11-14T15:00",
        priceCents: 3200,
        seats: 8,
        seatsLeft: 8,
      },
      {
        id: "winter-tasting",
        title: "Winter Tasting",
        startsAt: "2026-12-05T17:00",
        priceCents: 2800,
        seats: 10,
        seatsLeft: 10,
      },
    ]);
  });

  it("is never cached", async () => {
    const res = await request(app).get("/api/tastings");
    expect(res.headers["cache-control"]).toContain("no-store");
  });

  it("reflects bookings in seatsLeft and exposes no personal data", async () => {
    await book({ tastingId: "riesling-evening", ...guest, guests: 3 }).expect(201);
    const res = await request(app).get("/api/tastings").expect(200);
    expect(res.body[0].seatsLeft).toBe(9);
    expect(JSON.stringify(res.body)).not.toContain("Anna");
    expect(JSON.stringify(res.body)).not.toContain("anna@example.com");
  });
});

describe("POST /api/bookings", () => {
  it("creates a booking and returns confirmation data with a reference and total", async () => {
    const res = await book({ tastingId: "red-wine-cellar-tour", ...guest, guests: 3 }).expect(201);
    expect(res.body.booking).toMatchObject({
      tastingId: "red-wine-cellar-tour",
      tastingTitle: "Red Wine Cellar Tour",
      startsAt: "2026-11-14T15:00",
      guests: 3,
      totalCents: 9600,
    });
    expect(res.body.booking.reference).toMatch(/^KB-[A-Z2-9]{8}$/);
    expect(await seatsLeft("red-wine-cellar-tour")).toBe(5);
  });

  it("does not echo personal data back", async () => {
    const res = await book({ tastingId: "winter-tasting", ...guest }).expect(201);
    expect(JSON.stringify(res.body)).not.toContain("anna@example.com");
  });

  it("issues unique references", async () => {
    const refs = new Set<string>();
    for (let i = 0; i < 5; i++) {
      const res = await book({ tastingId: "winter-tasting", ...guest, guests: 1 }).expect(201);
      refs.add(res.body.booking.reference);
    }
    expect(refs.size).toBe(5);
  });

  it.each([
    ["name", { name: "" }],
    ["name", { name: "   " }],
    ["email", { email: "not-an-email" }],
    ["guests", { guests: 0 }],
    ["guests", { guests: 9 }],
    ["guests", { guests: 2.5 }],
    ["guests", { guests: "2" }],
    ["guests", { guests: null }],
  ])("rejects invalid %s with a field error and stores nothing (%j)", async (field, patch) => {
    const res = await book({ tastingId: "riesling-evening", ...guest, ...patch }).expect(422);
    expect(Object.keys(res.body.errors)).toEqual([field]);
    expect(await seatsLeft("riesling-evening")).toBe(12);
  });

  it("reports every invalid field at once", async () => {
    const res = await book({ tastingId: "riesling-evening", name: "", email: "x", guests: 99 }).expect(422);
    expect(Object.keys(res.body.errors).sort()).toEqual(["email", "guests", "name"]);
  });

  it("rejects an unknown tasting as not found", async () => {
    await book({ tastingId: "nope", ...guest }).expect(404);
    await book({ tastingId: "__proto__", ...guest }).expect(404);
    await book({ ...guest }).expect(404);
  });

  it("rejects more guests than seats left, naming the seats left on the guests field", async () => {
    await book({ tastingId: "red-wine-cellar-tour", ...guest, guests: 8 }).expect(201);
    await book({ tastingId: "winter-tasting", ...guest, guests: 8 }).expect(201); // 2 left
    const res = await book({ tastingId: "winter-tasting", ...guest, guests: 3 }).expect(409);
    expect(res.body.errors.guests).toMatch(/2/);
    expect(await seatsLeft("winter-tasting")).toBe(2);
  });

  it("accepts exactly the seats left and then reports the tasting fully booked", async () => {
    await book({ tastingId: "winter-tasting", ...guest, guests: 8 }).expect(201);
    await book({ tastingId: "winter-tasting", ...guest, guests: 2 }).expect(201);
    expect(await seatsLeft("winter-tasting")).toBe(0);
    const res = await book({ tastingId: "winter-tasting", ...guest, guests: 1 }).expect(409);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });

  it("never oversells when many requests race for the last seats", async () => {
    const results = await Promise.all(
      Array.from({ length: 10 }, () => book({ tastingId: "red-wine-cellar-tour", ...guest, guests: 5 })),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(1);
    expect(results.filter((r) => r.status === 409)).toHaveLength(9);
    expect(await seatsLeft("red-wine-cellar-tour")).toBe(3);
  });

  it("rejects malformed JSON and oversized bodies without crashing", async () => {
    await request(app)
      .post("/api/bookings")
      .set("Content-Type", "application/json")
      .send("{oops")
      .expect(400);
    await book({ tastingId: "winter-tasting", ...guest, name: "x".repeat(20_000) }).expect(413);
  });

  it("rejects non-JSON content types", async () => {
    await request(app).post("/api/bookings").type("form").send("tastingId=winter-tasting&name=A").expect(415);
  });

  it("rate limits bursts of booking requests", async () => {
    const limited = createApp({ store, staffPassword: PASSWORD, bookingRateLimit: { limit: 3 } });
    const codes: number[] = [];
    for (let i = 0; i < 5; i++) {
      codes.push(
        (
          await request(limited)
            .post("/api/bookings")
            .send({ tastingId: "winter-tasting", ...guest, guests: 1 })
        ).status,
      );
    }
    expect(codes).toEqual([201, 201, 201, 429, 429]);
  });
});

describe("staff session", () => {
  it("signs in with the configured password and sets a hardened cookie", async () => {
    const res = await request(app).post("/api/staff/session").send({ password: PASSWORD }).expect(204);
    const cookie = String(res.headers["set-cookie"]);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Strict/i);
    expect(cookie).toMatch(/Path=\//);
    expect(cookie).not.toContain(PASSWORD);
  });

  it("rejects a wrong password with an error for the password field", async () => {
    const res = await request(app).post("/api/staff/session").send({ password: "wrong" }).expect(401);
    expect(res.body.errors.password).toMatch(/\S/);
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("rejects empty, missing and non-string passwords", async () => {
    for (const body of [{ password: "" }, {}, { password: 123 }, { password: null }]) {
      await request(app).post("/api/staff/session").send(body).expect(401);
    }
  });

  it("fails closed when STAFF_PASSWORD is unset or empty", async () => {
    for (const staffPassword of [undefined, ""]) {
      const closed = createApp({ store, staffPassword });
      await request(closed).post("/api/staff/session").send({ password: "" }).expect(401);
      await request(closed).post("/api/staff/session").send({ password: "undefined" }).expect(401);
    }
  });

  it("limits repeated failed sign-ins", async () => {
    const limited = createApp({ store, staffPassword: PASSWORD, loginRateLimit: { limit: 3 } });
    const codes: number[] = [];
    for (let i = 0; i < 5; i++) {
      codes.push((await request(limited).post("/api/staff/session").send({ password: "bad" })).status);
    }
    expect(codes).toEqual([401, 401, 401, 429, 429]);
    const res = await request(limited).post("/api/staff/session").send({ password: "bad" });
    expect(res.body.errors.password).toMatch(/try again later/i);
  });

  it("reports session state with a plain 200 so the sign-in page needs no failing request", async () => {
    const anonymous = await request(app).get("/api/staff/session").expect(200);
    expect(anonymous.body).toEqual({ signedIn: false });
    const agent = await staffAgent();
    const signedIn = await agent.get("/api/staff/session").expect(200);
    expect(signedIn.body).toEqual({ signedIn: true });
  });

  it("expires sessions after 8 hours", async () => {
    const agent = await staffAgent();
    clock.now += 7 * 3600_000;
    expect((await agent.get("/api/staff/session")).body).toEqual({ signedIn: true });
    clock.now += 2 * 3600_000;
    expect((await agent.get("/api/staff/session")).body).toEqual({ signedIn: false });
    await agent.get("/api/staff/bookings").expect(401);
  });

  it("signs out and invalidates that session server-side, leaving other sessions alone", async () => {
    const login = () => request(app).post("/api/staff/session").send({ password: PASSWORD });
    const cookieA = String((await login()).headers["set-cookie"]).split(";")[0]!;
    const cookieB = String((await login()).headers["set-cookie"]).split(";")[0]!;
    await request(app).delete("/api/staff/session").set("Cookie", cookieA).expect(204);
    await request(app).get("/api/staff/bookings").set("Cookie", cookieA).expect(401);
    await request(app).get("/api/staff/bookings").set("Cookie", cookieB).expect(200);
  });

  it("ignores forged or garbage cookies", async () => {
    await request(app).get("/api/staff/bookings").set("Cookie", "kb_staff=forged").expect(401);
    await request(app).get("/api/staff/bookings").set("Cookie", "kb_staff=").expect(401);
  });
});

describe("staff bookings", () => {
  it("refuses unauthenticated list and cancel requests and leaks nothing", async () => {
    const created = await book({ tastingId: "winter-tasting", ...guest }).expect(201);
    const list = await request(app).get("/api/staff/bookings").expect(401);
    expect(JSON.stringify(list.body)).not.toContain("anna@example.com");
    await request(app).delete(`/api/staff/bookings/${created.body.booking.reference}`).expect(401);
    expect(await seatsLeft("winter-tasting")).toBe(8);
  });

  it("lists bookings grouped by tasting with name, email, guests and reference", async () => {
    const a = await book({ tastingId: "winter-tasting", ...guest, guests: 3 }).expect(201);
    const b = await book({
      tastingId: "winter-tasting",
      name: "Ben Koch",
      email: "ben@example.com",
      guests: 1,
    }).expect(201);
    const c = await book({ tastingId: "riesling-evening", ...guest, guests: 2 }).expect(201);
    const agent = await staffAgent();
    const res = await agent.get("/api/staff/bookings").expect(200);
    expect(res.headers["cache-control"]).toContain("no-store");
    const groups = res.body.tastings as {
      id: string;
      title: string;
      seatsLeft: number;
      bookings: Record<string, unknown>[];
    }[];
    expect(groups.map((g) => g.id)).toEqual(["riesling-evening", "red-wine-cellar-tour", "winter-tasting"]);
    expect(groups[1]!.bookings).toEqual([]);
    expect(groups[0]!.bookings).toEqual([
      expect.objectContaining({
        reference: c.body.booking.reference,
        name: "Anna Weber",
        email: "anna@example.com",
        guests: 2,
      }),
    ]);
    expect(groups[2]!.bookings.map((x) => x.reference)).toEqual([
      a.body.booking.reference,
      b.body.booking.reference,
    ]);
    expect(groups[2]!.seatsLeft).toBe(6);
  });

  it("cancels a booking and frees its seats", async () => {
    await book({ tastingId: "winter-tasting", ...guest, guests: 6 }).expect(201);
    const big = await book({ tastingId: "winter-tasting", ...guest, guests: 4 }).expect(201);
    expect(await seatsLeft("winter-tasting")).toBe(0);
    const agent = await staffAgent();
    await agent.delete(`/api/staff/bookings/${big.body.booking.reference}`).expect(204);
    expect(await seatsLeft("winter-tasting")).toBe(4);
    const list = await agent.get("/api/staff/bookings").expect(200);
    expect(list.body.tastings[2].bookings).toHaveLength(1);
    // freed seats can be booked again
    await book({ tastingId: "winter-tasting", ...guest, guests: 4 }).expect(201);
  });

  it("answers 404 when cancelling an unknown or already cancelled booking and changes nothing", async () => {
    const created = await book({ tastingId: "winter-tasting", ...guest, guests: 2 }).expect(201);
    const agent = await staffAgent();
    await agent.delete(`/api/staff/bookings/${created.body.booking.reference}`).expect(204);
    await agent.delete(`/api/staff/bookings/${created.body.booking.reference}`).expect(404);
    await agent.delete("/api/staff/bookings/KB-NOSUCHREF").expect(404);
    expect(await seatsLeft("winter-tasting")).toBe(10);
  });
});

describe("hardening", () => {
  it("sets security headers and hides the framework", async () => {
    const res = await request(app).get("/api/tastings");
    expect(res.headers["x-powered-by"]).toBeUndefined();
    expect(res.headers["x-content-type-options"]).toBe("nosniff");
    expect(res.headers["content-security-policy"]).toContain("default-src 'self'");
  });

  it("answers unknown API routes with JSON 404", async () => {
    const res = await request(app).get("/api/nope").expect(404);
    expect(res.body.error).toBeDefined();
  });

  it("denies powerful browser features", async () => {
    const res = await request(app).get("/api/tastings");
    expect(res.headers["permissions-policy"]).toContain("camera=()");
  });

  it("does not leak internals when the store throws", async () => {
    const broken = createApp({
      store: {
        ...store,
        list: () => {
          throw new Error("secret stack detail");
        },
      },
      staffPassword: PASSWORD,
    });
    const res = await request(broken).get("/api/tastings").expect(500);
    expect(JSON.stringify(res.body)).not.toContain("secret");
  });
});

describe("static hosting", () => {
  it("serves the built client and falls back to index.html for client routes", async () => {
    const { mkdtempSync, writeFileSync } = await import("node:fs");
    const { tmpdir } = await import("node:os");
    const { join } = await import("node:path");
    const dir = mkdtempSync(join(tmpdir(), "kb-client-"));
    writeFileSync(join(dir, "index.html"), "<!doctype html><title>Kieselbrunnen</title>");
    const hosted = createApp({ store, staffPassword: PASSWORD, clientDir: dir });
    for (const path of ["/", "/staff", "/book/winter-tasting", "/anything/else"]) {
      const res = await request(hosted).get(path).expect(200);
      expect(res.text).toContain("Kieselbrunnen");
    }
    await request(hosted).get("/api/nope").expect(404);
  });
});
