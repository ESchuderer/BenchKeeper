// @vitest-environment jsdom
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { renderApp, startBackend, type Backend } from "./helpers/harness";

let backend: Backend;
beforeEach(async () => {
  backend = await startBackend();
});
afterEach(async () => {
  await backend.stop();
});

const fill = async (
  user: ReturnType<typeof userEvent.setup>,
  v: { name?: string; email?: string; guests?: string },
) => {
  if (v.name !== undefined) {
    await user.clear(screen.getByLabelText("Name"));
    if (v.name) await user.type(screen.getByLabelText("Name"), v.name);
  }
  if (v.email !== undefined) {
    await user.clear(screen.getByLabelText("Email"));
    if (v.email) await user.type(screen.getByLabelText("Email"), v.email);
  }
  if (v.guests !== undefined) {
    await user.clear(screen.getByLabelText("Guests"));
    if (v.guests) await user.type(screen.getByLabelText("Guests"), v.guests);
  }
};

const openForm = async (id = "riesling-evening") => {
  const user = userEvent.setup();
  renderApp(`/book/${id}`);
  await screen.findByLabelText("Name");
  return user;
};

describe("booking form", () => {
  it("shows the tasting and the fields Name, Email, Guests and a Book button", async () => {
    await openForm();
    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent("Book Riesling Evening");
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toHaveAttribute("type", "email");
    expect(screen.getByLabelText("Guests")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Book" })).toBeEnabled();
    expect(screen.getByText("12 seats left")).toBeInTheDocument();
  });

  it("opens from the start page link", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await user.click(await screen.findByRole("link", { name: "Book Winter Tasting" }));
    expect(await screen.findByRole("heading", { level: 1, name: "Book Winter Tasting" })).toBeInTheDocument();
  });

  it("confirms a booking with tasting, guests, total price and reference", async () => {
    const user = await openForm("red-wine-cellar-tour");
    await fill(user, { name: "Anna Weber", email: "anna@example.com", guests: "3" });
    await user.click(screen.getByRole("button", { name: "Book" }));

    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
    const summary = screen.getByRole("region", { name: "Booking confirmed" });
    expect(within(summary).getByText("Red Wine Cellar Tour")).toBeInTheDocument();
    expect(within(summary).getByText("3")).toBeInTheDocument();
    expect(within(summary).getByText("EUR 96")).toBeInTheDocument();
    expect(within(summary).getByText(/^KB-[A-Z2-9]{8}$/)).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).not.toBeInTheDocument();
    expect(backend.store.seatsLeft("red-wine-cellar-tour")).toBe(5);
    expect(screen.getByRole("heading", { name: "Booking confirmed" })).toHaveFocus();
  });

  it("shows an error next to Name when it is blank and focuses it", async () => {
    const user = await openForm();
    await fill(user, { name: "", email: "anna@example.com", guests: "2" });
    await user.click(screen.getByRole("button", { name: "Book" }));
    const name = screen.getByLabelText("Name");
    await waitFor(() => expect(name).toHaveAttribute("aria-invalid", "true"));
    expect(name).toHaveAccessibleDescription(/enter your name/i);
    expect(name).toHaveFocus();
    expect(screen.getByLabelText("Email")).not.toHaveAttribute("aria-invalid", "true");
    expect(backend.requests.filter((r) => r.startsWith("POST"))).toHaveLength(0);
  });

  it("shows an error next to Email for an invalid address", async () => {
    const user = await openForm();
    await fill(user, { name: "Anna", email: "not-an-email", guests: "2" });
    await user.click(screen.getByRole("button", { name: "Book" }));
    const email = screen.getByLabelText("Email");
    await waitFor(() => expect(email).toHaveAccessibleDescription(/valid email/i));
    expect(email).toHaveAttribute("aria-invalid", "true");
  });

  it.each(["0", "9", "2.5", ""])("shows an error next to Guests for %j", async (value) => {
    const user = await openForm();
    await fill(user, { name: "Anna", email: "anna@example.com", guests: value });
    await user.click(screen.getByRole("button", { name: "Book" }));
    const guests = screen.getByLabelText("Guests");
    await waitFor(() => expect(guests).toHaveAttribute("aria-invalid", "true"));
    expect(guests).toHaveAccessibleDescription(/guest/i);
    expect(backend.store.seatsLeft("riesling-evening")).toBe(12);
  });

  it("shows several field errors at once and keeps what was typed", async () => {
    const user = await openForm();
    await fill(user, { name: "", email: "nope", guests: "12" });
    await user.click(screen.getByRole("button", { name: "Book" }));
    await waitFor(() => expect(screen.getByLabelText("Guests")).toHaveAttribute("aria-invalid", "true"));
    expect(screen.getByLabelText("Name")).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByLabelText("Email")).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByLabelText("Email")).toHaveValue("nope");
    expect(screen.getByLabelText("Guests")).toHaveValue(12);
  });

  it("rejects more guests than seats left next to Guests and refreshes the seats shown", async () => {
    backend.store.book({ tastingId: "winter-tasting", name: "A", email: "a@example.com", guests: 8 });
    const user = await openForm("winter-tasting");
    expect(screen.getByText("2 seats left")).toBeInTheDocument();
    await fill(user, { name: "Anna", email: "anna@example.com", guests: "3" });
    await user.click(screen.getByRole("button", { name: "Book" }));
    const guests = screen.getByLabelText("Guests");
    await waitFor(() => expect(guests).toHaveAccessibleDescription(/only 2 seats are left/i));
    expect(guests).toHaveAttribute("aria-invalid", "true");
    expect(guests).toHaveFocus();
    expect(screen.getByLabelText("Name")).toHaveValue("Anna");
    expect(backend.store.seatsLeft("winter-tasting")).toBe(2);
    expect(screen.queryByRole("heading", { name: "Booking confirmed" })).not.toBeInTheDocument();
  });

  it("clears a field error once the guest edits the field again", async () => {
    const user = await openForm();
    await fill(user, { name: "", email: "anna@example.com", guests: "2" });
    await user.click(screen.getByRole("button", { name: "Book" }));
    await waitFor(() => expect(screen.getByLabelText("Name")).toHaveAttribute("aria-invalid", "true"));
    await user.type(screen.getByLabelText("Name"), "Anna");
    await waitFor(() => expect(screen.getByLabelText("Name")).not.toHaveAttribute("aria-invalid", "true"));
  });

  it("creates only one booking when the button is clicked repeatedly", async () => {
    const user = await openForm();
    await fill(user, { name: "Anna", email: "anna@example.com", guests: "2" });
    const button = screen.getByRole("button", { name: "Book" });
    await user.dblClick(button);
    await screen.findByRole("heading", { name: "Booking confirmed" });
    expect(backend.requests.filter((r) => r === "POST /api/bookings")).toHaveLength(1);
    expect(backend.store.seatsLeft("riesling-evening")).toBe(10);
  });

  it("shows a retryable error and keeps the values when the server cannot be reached", async () => {
    const user = await openForm();
    await fill(user, { name: "Anna", email: "anna@example.com", guests: "2" });
    const realFetch = globalThis.fetch;
    vi.stubGlobal("fetch", () => Promise.reject(new TypeError("Failed to fetch")));
    await user.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByRole("alert")).toHaveTextContent(/could not reach|try again/i);
    expect(screen.getByLabelText("Name")).toHaveValue("Anna");
    expect(screen.getByRole("button", { name: "Book" })).toBeEnabled();

    vi.stubGlobal("fetch", realFetch);
    await user.click(screen.getByRole("button", { name: "Book" }));
    expect(await screen.findByRole("heading", { name: "Booking confirmed" })).toBeInTheDocument();
  });

  it("states that a fully booked tasting is fully booked instead of showing the form", async () => {
    backend.store.book({ tastingId: "red-wine-cellar-tour", name: "A", email: "a@example.com", guests: 8 });
    renderApp("/book/red-wine-cellar-tour");
    expect(await screen.findByText(/fully booked/i)).toBeInTheDocument();
    expect(screen.queryByLabelText("Name")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: /all tastings/i })).toHaveAttribute("href", "/");
  });

  it("shows not found with a link back for an unknown tasting", async () => {
    renderApp("/book/does-not-exist");
    expect(await screen.findByRole("heading", { name: /not found/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /all tastings/i })).toHaveAttribute("href", "/");
  });
});
