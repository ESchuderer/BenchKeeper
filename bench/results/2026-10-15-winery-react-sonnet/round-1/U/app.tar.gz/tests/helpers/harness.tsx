import { once } from "node:events";
import type { AddressInfo } from "node:net";
import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router";
import { vi } from "vitest";
import { App } from "../../src/App";
import { createApp } from "../../server/app";
import { createBookingStore, type BookingStore } from "../../server/store";
import { TASTINGS } from "../../shared/tastings";

export const STAFF_PASSWORD = "s3cret-for-tests";

export interface Backend {
  store: BookingStore;
  /** Every request the UI made, as "METHOD /path". */
  requests: string[];
  stop(): Promise<void>;
}

/**
 * Runs the real Express app on an ephemeral port and points the UI's relative
 * `/api` calls at it, with a minimal cookie jar so staff sessions work.
 */
export async function startBackend(): Promise<Backend> {
  const store = createBookingStore(TASTINGS);
  const server = createApp({ store, staffPassword: STAFF_PASSWORD }).listen(0);
  await once(server, "listening");
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

  const realFetch = globalThis.fetch;
  const jar = new Map<string, string>();
  const requests: string[] = [];

  vi.stubGlobal("fetch", async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const path = String(input);
    requests.push(`${init.method ?? "GET"} ${path}`);
    const headers = new Headers(init.headers);
    if (jar.size) headers.set("cookie", [...jar].map(([k, v]) => `${k}=${v}`).join("; "));
    const response = await realFetch(base + path, { ...init, headers });
    for (const cookie of response.headers.getSetCookie()) {
      const [pair = ""] = cookie.split(";");
      const [name = "", value = ""] = pair.split("=");
      if (!value || /expires=thu, 01 jan 1970/i.test(cookie)) jar.delete(name);
      else jar.set(name, value);
    }
    return response;
  });

  return {
    store,
    requests,
    async stop() {
      vi.unstubAllGlobals();
      server.close();
      server.closeAllConnections();
    },
  };
}

export function renderApp(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}
