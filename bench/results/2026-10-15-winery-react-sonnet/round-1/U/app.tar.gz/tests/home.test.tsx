// @vitest-environment jsdom
import { screen, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { renderApp, startBackend, type Backend } from "./helpers/harness";

let backend: Backend;
beforeEach(async () => {
  backend = await startBackend();
});
afterEach(async () => {
  await backend.stop();
});

describe("start page", () => {
  it("lists every tasting with title, date and time, price and seats left", async () => {
    renderApp("/");
    expect(screen.getByRole("heading", { level: 1 })).toBeInTheDocument();
    const riesling = await screen.findByRole("article", { name: "Riesling Evening" });
    expect(within(riesling).getByText("Fri, 6 Nov 2026")).toBeInTheDocument();
    expect(within(riesling).getByText("18:00")).toBeInTheDocument();
    expect(within(riesling).getByText("EUR 25")).toBeInTheDocument();
    expect(within(riesling).getByText("12 seats left")).toBeInTheDocument();

    const tour = screen.getByRole("article", { name: "Red Wine Cellar Tour" });
    expect(within(tour).getByText("EUR 32")).toBeInTheDocument();
    expect(within(tour).getByText("8 seats left")).toBeInTheDocument();

    const winter = screen.getByRole("article", { name: "Winter Tasting" });
    expect(within(winter).getByText("Sat, 5 Dec 2026")).toBeInTheDocument();
    expect(within(winter).getByText("17:00")).toBeInTheDocument();
    expect(within(winter).getByText("10 seats left")).toBeInTheDocument();
  });

  it("offers a 'Book <title>' link to each tasting's booking form", async () => {
    renderApp("/");
    const link = await screen.findByRole("link", { name: "Book Riesling Evening" });
    expect(link).toHaveAttribute("href", "/book/riesling-evening");
    expect(screen.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Book Winter Tasting" })).toBeInTheDocument();
  });

  it("shows current seats left after bookings were made", async () => {
    backend.store.book({ tastingId: "riesling-evening", name: "A", email: "a@example.com", guests: 3 });
    renderApp("/");
    expect(await screen.findByText("9 seats left")).toBeInTheDocument();
  });

  it("marks a fully booked tasting and offers no booking link for it", async () => {
    backend.store.book({ tastingId: "red-wine-cellar-tour", name: "A", email: "a@example.com", guests: 8 });
    renderApp("/");
    const tour = await screen.findByRole("article", { name: "Red Wine Cellar Tour" });
    expect(within(tour).getByText("Fully booked")).toBeInTheDocument();
    expect(within(tour).queryByRole("link")).not.toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Book Red Wine Cellar Tour" })).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Book Riesling Evening" })).toBeInTheDocument();
  });

  it("shows a loading state first", () => {
    renderApp("/");
    expect(screen.getByRole("status")).toHaveTextContent(/loading/i);
  });

  it("shows an error with a retry button when the tastings cannot be loaded", async () => {
    const realFetch = globalThis.fetch;
    vi.stubGlobal("fetch", () => Promise.reject(new TypeError("Failed to fetch")));
    const { default: userEvent } = await import("@testing-library/user-event");
    renderApp("/");
    const alert = await screen.findByRole("alert");
    expect(alert).toHaveTextContent(/could not load/i);

    vi.stubGlobal("fetch", realFetch);
    await userEvent.setup().click(screen.getByRole("button", { name: "Try again" }));
    expect(await screen.findByRole("link", { name: "Book Riesling Evening" })).toBeInTheDocument();
  });

  it("sets the document language-appropriate title", async () => {
    renderApp("/");
    await screen.findByRole("article", { name: "Riesling Evening" });
    expect(document.title).toMatch(/Kieselbrunnen/);
  });
});
