import { describe, expect, it } from "vitest";
import { TASTINGS } from "../shared/tastings";
import { MAX_GUESTS, validateBooking } from "../shared/booking";
import { formatPrice, formatStart, totalCents } from "../shared/format";

describe("tasting catalogue", () => {
  it("offers the three tastings of the brief with their price and seats", () => {
    expect(TASTINGS.map((t) => [t.title, t.startsAt, t.priceCents, t.seats])).toEqual([
      ["Riesling Evening", "2026-11-06T18:00", 2500, 12],
      ["Red Wine Cellar Tour", "2026-11-14T15:00", 3200, 8],
      ["Winter Tasting", "2026-12-05T17:00", 2800, 10],
    ]);
  });

  it("uses unique url-safe ids", () => {
    const ids = TASTINGS.map((t) => t.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const id of ids) expect(id).toMatch(/^[a-z0-9-]+$/);
  });
});

describe("validateBooking", () => {
  const valid = { name: "Anna Weber", email: "anna@example.com", guests: 2 };

  it("accepts valid input and trims name and email", () => {
    const result = validateBooking({ name: "  Anna Weber ", email: " anna@example.com ", guests: 2 });
    expect(result).toEqual({ ok: true, data: valid });
  });

  it("accepts the bounds 1 and 8", () => {
    expect(validateBooking({ ...valid, guests: 1 }).ok).toBe(true);
    expect(validateBooking({ ...valid, guests: MAX_GUESTS }).ok).toBe(true);
  });

  it("rejects a blank or whitespace-only name", () => {
    for (const name of ["", "   "]) {
      const result = validateBooking({ ...valid, name });
      expect(result.ok).toBe(false);
      if (!result.ok) expect(Object.keys(result.errors)).toEqual(["name"]);
    }
  });

  it("rejects a name longer than 100 characters", () => {
    const result = validateBooking({ ...valid, name: "x".repeat(101) });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.errors.name).toBeDefined();
  });

  it("rejects invalid emails", () => {
    for (const email of ["", "not-an-email", "a@b", "a b@example.com", "@example.com"]) {
      const result = validateBooking({ ...valid, email });
      expect(result.ok, email).toBe(false);
      if (!result.ok) expect(Object.keys(result.errors)).toEqual(["email"]);
    }
  });

  it("rejects guest counts that are out of range, fractional, empty or not numbers", () => {
    for (const guests of [0, -1, 9, 2.5, Number.NaN, "", "3", null, undefined, Infinity]) {
      const result = validateBooking({ ...valid, guests });
      expect(result.ok, String(guests)).toBe(false);
      if (!result.ok) expect(Object.keys(result.errors)).toEqual(["guests"]);
    }
  });

  it("reports an error for every invalid field, one message per field", () => {
    const result = validateBooking({ name: "", email: "x", guests: 0 });
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(Object.keys(result.errors).sort()).toEqual(["email", "guests", "name"]);
      for (const message of Object.values(result.errors)) expect(message).toMatch(/\S/);
    }
  });

  it("rejects non-object input without throwing", () => {
    for (const input of [null, undefined, "x", 5, []]) {
      expect(validateBooking(input).ok).toBe(false);
    }
  });

  it("ignores unknown extra properties", () => {
    const result = validateBooking({ ...valid, isAdmin: true });
    expect(result).toEqual({ ok: true, data: valid });
  });
});

describe("formatting", () => {
  it("formats prices as EUR with cents only when needed", () => {
    expect(formatPrice(2500)).toBe("EUR 25");
    expect(formatPrice(3200)).toBe("EUR 32");
    expect(formatPrice(2550)).toBe("EUR 25.50");
    expect(formatPrice(0)).toBe("EUR 0");
  });

  it("computes totals in integer cents", () => {
    expect(totalCents(2800, 3)).toBe(8400);
    expect(formatPrice(totalCents(3200, 3))).toBe("EUR 96");
  });

  it("formats the start as wall-clock date and time without timezone shift", () => {
    expect(formatStart("2026-11-06T18:00")).toEqual({ date: "Fri, 6 Nov 2026", time: "18:00" });
    expect(formatStart("2026-12-05T17:00")).toEqual({ date: "Sat, 5 Dec 2026", time: "17:00" });
  });
});
