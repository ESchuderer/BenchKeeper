// @vitest-environment jsdom
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { renderApp, startBackend, STAFF_PASSWORD, type Backend } from "./helpers/harness";

let backend: Backend;
beforeEach(async () => {
  backend = await startBackend();
});
afterEach(async () => {
  await backend.stop();
});

const book = (tastingId: string, name: string, guests: number) =>
  backend.store.book({
    tastingId,
    name,
    email: `${name.toLowerCase().replace(/\W/g, "")}@example.com`,
    guests,
  });

async function signIn(password = STAFF_PASSWORD) {
  const user = userEvent.setup();
  renderApp("/staff");
  await user.type(await screen.findByLabelText("Password"), password);
  await user.click(screen.getByRole("button", { name: "Sign in" }));
  return user;
}

describe("staff sign-in", () => {
  it("asks for a password and shows no booking data before signing in", async () => {
    book("winter-tasting", "Anna Weber", 2);
    renderApp("/staff");
    const password = await screen.findByLabelText("Password");
    expect(password).toHaveAttribute("type", "password");
    expect(screen.getByRole("button", { name: "Sign in" })).toBeInTheDocument();
    expect(screen.queryByText("Anna Weber")).not.toBeInTheDocument();
  });

  it("shows an error next to Password when it is wrong", async () => {
    await signIn("wrong");
    const password = await screen.findByLabelText("Password");
    await waitFor(() => expect(password).toHaveAttribute("aria-invalid", "true"));
    expect(password).toHaveAccessibleDescription(/not correct/i);
    expect(password).toHaveFocus();
  });

  it("shows an error next to Password when it is empty without calling the server", async () => {
    const user = userEvent.setup();
    renderApp("/staff");
    await screen.findByLabelText("Password");
    await user.click(screen.getByRole("button", { name: "Sign in" }));
    await waitFor(() => expect(screen.getByLabelText("Password")).toHaveAttribute("aria-invalid", "true"));
    expect(backend.requests.filter((r) => r.startsWith("POST"))).toHaveLength(0);
  });

  it("remembers the session on reload", async () => {
    await signIn();
    await screen.findByRole("heading", { name: "Winter Tasting" });
    document.body.innerHTML = "";
    renderApp("/staff");
    expect(await screen.findByRole("heading", { name: "Winter Tasting" })).toBeInTheDocument();
    expect(screen.queryByLabelText("Password")).not.toBeInTheDocument();
  });
});

describe("staff bookings overview", () => {
  it("groups bookings by tasting with name, email, guests and reference", async () => {
    const a = book("winter-tasting", "Anna Weber", 3);
    book("winter-tasting", "Ben Koch", 1);
    book("riesling-evening", "Clara Vogt", 2);
    if (!a.ok) throw new Error("setup");
    await signIn();

    const winter = (await screen.findByRole("heading", { name: "Winter Tasting" })).closest("section")!;
    expect(within(winter).getByText("Anna Weber")).toBeInTheDocument();
    expect(within(winter).getByText("anna weber".replace(" ", "") + "@example.com")).toBeInTheDocument();
    expect(within(winter).getByText(a.booking.reference)).toBeInTheDocument();
    expect(within(winter).getByText("Ben Koch")).toBeInTheDocument();
    expect(within(winter).queryByText("Clara Vogt")).not.toBeInTheDocument();
    expect(within(winter).getAllByRole("button", { name: "Cancel" })).toHaveLength(2);

    const riesling = screen.getByRole("heading", { name: "Riesling Evening" }).closest("section")!;
    expect(within(riesling).getByText("Clara Vogt")).toBeInTheDocument();
  });

  it("shows an empty state for tastings without bookings", async () => {
    await signIn();
    const tour = (await screen.findByRole("heading", { name: "Red Wine Cellar Tour" })).closest("section")!;
    expect(within(tour).getByText(/no bookings yet/i)).toBeInTheDocument();
  });

  it("cancels a booking, removes it from the list and frees its seats", async () => {
    book("winter-tasting", "Anna Weber", 6);
    book("winter-tasting", "Ben Koch", 4);
    const user = await signIn();
    const winter = (await screen.findByRole("heading", { name: "Winter Tasting" })).closest("section")!;
    const annaItem = within(winter).getByText("Anna Weber").closest("li")!;
    await user.click(within(annaItem).getByRole("button", { name: "Cancel" }));

    await waitFor(() => expect(within(winter).queryByText("Anna Weber")).not.toBeInTheDocument());
    expect(within(winter).getByText("Ben Koch")).toBeInTheDocument();
    expect(backend.store.seatsLeft("winter-tasting")).toBe(6);
    expect(screen.getByRole("status")).toHaveTextContent(/cancelled/i);
  });

  it("signs out and asks for the password again", async () => {
    const user = await signIn();
    await screen.findByRole("heading", { name: "Winter Tasting" });
    await user.click(screen.getByRole("button", { name: "Sign out" }));
    expect(await screen.findByLabelText("Password")).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Winter Tasting" })).not.toBeInTheDocument();
  });
});
