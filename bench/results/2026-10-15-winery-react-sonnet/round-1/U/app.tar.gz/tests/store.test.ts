import { beforeEach, describe, expect, it } from "vitest";
import { createBookingStore, type BookingStore } from "../server/store";
import { TASTINGS } from "../shared/tastings";

let store: BookingStore;
beforeEach(() => {
  store = createBookingStore(TASTINGS);
});

const input = (guests: number, tastingId = "winter-tasting") => ({
  tastingId,
  name: "Anna",
  email: "anna@example.com",
  guests,
});

describe("BookingStore", () => {
  it("starts with no bookings and full seats", () => {
    expect(store.list().every((t) => t.bookings.length === 0 && t.seatsLeft === t.seats)).toBe(true);
  });

  it("books, reduces seats and returns the booking", () => {
    const result = store.book(input(3));
    expect(result.ok).toBe(true);
    expect(store.seatsLeft("winter-tasting")).toBe(7);
  });

  it("refuses a booking above the seats left without changing state", () => {
    store.book(input(8));
    const result = store.book(input(3));
    expect(result).toEqual({ ok: false, reason: "capacity", seatsLeft: 2 });
    expect(store.seatsLeft("winter-tasting")).toBe(2);
  });

  it("refuses unknown tastings", () => {
    expect(store.book(input(1, "nope"))).toEqual({ ok: false, reason: "unknown-tasting" });
  });

  it("cancels and frees seats exactly once", () => {
    const result = store.book(input(5));
    if (!result.ok) throw new Error("expected booking");
    expect(store.cancel(result.booking.reference)).toBe(true);
    expect(store.cancel(result.booking.reference)).toBe(false);
    expect(store.seatsLeft("winter-tasting")).toBe(10);
  });

  it("keeps tastings independent", () => {
    store.book(input(8, "red-wine-cellar-tour"));
    expect(store.seatsLeft("red-wine-cellar-tour")).toBe(0);
    expect(store.seatsLeft("winter-tasting")).toBe(10);
  });
});
