Status: resolved
# 01 Booking store
Blocked by: none (seams confirmed by the user's instruction to proceed)

Seed tastings, seats left, book (never exceeding seats), cancel frees seats, totals in cents, unique references.
Tracer bullet: book 2 guests on Riesling Evening -> 10 seats left.
