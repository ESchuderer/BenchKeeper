Status: resolved
# 02 HTTP API + guest validation
Blocked by: 01

GET /api/tastings, POST /api/tastings/:id/bookings with per-field errors, 409 when over capacity. Server starts only with STAFF_PASSWORD.
