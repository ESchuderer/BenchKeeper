Status: resolved
# 03 Staff auth + booking admin API
Blocked by: 02

POST /api/staff/session, GET /api/staff/bookings (grouped), DELETE /api/staff/bookings/:ref. 401 without cookie.
