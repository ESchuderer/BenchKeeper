Status: resolved
# 04 Guest UI
Blocked by: 02

Start page, booking form with inline errors, confirmation, fully-booked state, responsive winery design.
