Status: resolved
# 05 Staff UI
Blocked by: 03

/staff sign-in, grouped bookings, Cancel.
