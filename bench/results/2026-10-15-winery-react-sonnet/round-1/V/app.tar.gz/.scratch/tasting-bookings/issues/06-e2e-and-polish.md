Status: resolved
# 06 Browser journeys, build/start scripts, review
Blocked by: 04, 05

Playwright journeys incl. phone viewport; npm run build/start on PORT; code-review pass.
