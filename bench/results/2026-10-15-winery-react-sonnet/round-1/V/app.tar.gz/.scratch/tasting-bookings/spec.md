# Tasting bookings — Weingut Kieselbrunnen

Status: ready-for-agent

Guests book wine tastings online; staff see and cancel bookings.

## Tastings (seed data, fixed)

| id | Tasting | Date and time | Price per guest | Seats |
|---|---|---|---|---|
| riesling-evening | Riesling Evening | 2026-11-06 18:00 | EUR 25 | 12 |
| red-wine-cellar-tour | Red Wine Cellar Tour | 2026-11-14 15:00 | EUR 32 | 8 |
| winter-tasting | Winter Tasting | 2026-12-05 17:00 | EUR 28 | 10 |

## Behaviour

### Guest
- Start page lists tastings: title, date and time, price per guest, "<n> seats left".
- Each tasting has "Book <title>" link/button -> booking form: "Name", "Email", "Guests" (1-8), "Book".
- Booking never takes more seats than are left (also under concurrent requests).
- Invalid input -> error message next to the field concerned (Name required, Email valid format, Guests integer 1-8 and <= seats left).
- Fully booked tasting: clear "Fully booked" state, no working booking path.
- Success -> "Booking confirmed" heading, tasting, number of guests, total price, booking reference.

### Staff
- `/staff`: "Password" field + "Sign in" button. Password from env `STAFF_PASSWORD`.
- Wrong password -> error message; no access to bookings.
- Signed in: bookings grouped by tasting (name, email, guests, reference); "Cancel" button per booking; cancelling frees the seats.
- Booking data endpoints must reject unauthenticated callers.

### Non-functional
- React UI, English, responsive (phone), coherent winery look; clear error/success/fully-booked states.
- Node 22. `npm install`, `npm run build`, `npm start` serves everything on `PORT` (default 3000).
- Starts with no bookings. In-memory storage is fine.
- Fail fast at startup if `STAFF_PASSWORD` is unset (no default password).

## Decisions
- Express 5 API + Vite/React 19 SPA with React Router, served by the same Express process.
- react-hook-form + zod for forms (zod schema is also the server-side validator).
- Tailwind CSS for styling.
- Staff session: signed HttpOnly cookie, compared in constant time.
- Money in integer cents internally; shown as "EUR 25".
- Booking reference: short, unguessable, human-readable (e.g. `KB-7F3K9Q`).
- Seat checks and writes happen in one synchronous step in the store (no await between check and write).

## Test seams (confirmed: user told the agent to proceed without waiting)
1. **Booking store** (`createBookingStore(tastings)`): list tastings with seats left, book, cancel, list bookings by tasting. Pure logic, no I/O.
2. **HTTP API** (supertest against the Express app, injected store + password): validation errors per field, over-booking -> rejected, staff auth, cancel frees seats.
3. **Browser journeys** (Playwright against `npm start`): guest books and sees confirmation; invalid input shows errors; fully booked; staff sign-in/cancel; phone viewport.
No mocking of own modules; only the clock/randomness if needed (reference generator injected).
