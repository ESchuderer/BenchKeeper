# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings online; staff see and cancel the bookings at `/staff`.

```sh
npm install
npm run build
STAFF_PASSWORD=choose-a-password npm start   # http://localhost:3000, or set PORT
```

`STAFF_PASSWORD` is required; the server refuses to start without it. Bookings live in memory and are
lost when the server restarts. Behind a reverse proxy set `TRUST_PROXY=1` so the staff login throttle (5 wrong
passwords per minute per client) sees real client addresses; serve over HTTPS there too. The three tastings are defined in `server/tastings.js`.

## Tests

```sh
npm test            # booking store + HTTP API (Vitest, supertest)
npm run test:e2e    # browser journeys incl. phone viewport (Playwright; builds and starts the app itself)
```

First time only: `npx playwright install chromium`.

## Layout

- `server/` Express 5 API (`app.js`), booking rules (`store.js`), staff session (`staffAuth.js`)
- `shared/bookingSchema.js` zod schema used by the form and the server, so the rules cannot drift apart
- `src/` React 19 + React Router single-page app, styled with Tailwind CSS
- `.scratch/tasting-bookings/` spec and plan
