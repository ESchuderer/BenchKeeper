import { expect, test } from "@playwright/test";

const card = (page, title) => page.getByRole("article").filter({ has: page.getByRole("heading", { name: title }) });

async function fillBooking(page, { name, email, guests }) {
  await page.getByLabel("Name").fill(name);
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Guests").fill(String(guests));
}

test("start page lists the tastings with date, price and seats left", async ({ page }) => {
  await page.goto("/");
  const riesling = card(page, "Riesling Evening");
  await expect(riesling).toContainText("2026-11-06 18:00");
  await expect(riesling).toContainText("EUR 25");
  await expect(riesling).toContainText("12 seats left");
  await expect(card(page, "Red Wine Cellar Tour")).toContainText("2026-11-14 15:00");
  await expect(card(page, "Red Wine Cellar Tour")).toContainText("EUR 32");
  await expect(card(page, "Red Wine Cellar Tour")).toContainText("8 seats left");
  await expect(card(page, "Winter Tasting")).toContainText("2026-12-05 17:00");
  await expect(card(page, "Winter Tasting")).toContainText("EUR 28");
  await expect(card(page, "Winter Tasting")).toContainText("10 seats left");
});

test("a guest books a tasting and sees the confirmation", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Book Riesling Evening" }).click();
  await fillBooking(page, { name: "Anna Weber", email: "anna@example.com", guests: 2 });
  await page.getByRole("button", { name: "Book", exact: true }).click();

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  const main = page.getByRole("main");
  await expect(main).toContainText("Riesling Evening");
  await expect(main).toContainText("2 guests");
  await expect(main).toContainText("EUR 50");
  await expect(main).toContainText(/KB-[A-Z2-9]{6}/);

  await page.goto("/");
  await expect(card(page, "Riesling Evening")).toContainText("10 seats left");
});

test("invalid input is rejected with an error next to each field", async ({ page }) => {
  await page.goto("/book/riesling-evening");
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByLabel("Name")).toHaveAccessibleDescription(/enter your name/i);
  await expect(page.getByLabel("Email")).toHaveAccessibleDescription(/email/i);
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toHaveCount(0);

  await fillBooking(page, { name: "Ben", email: "not-an-email", guests: 9 });
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByLabel("Email")).toHaveAccessibleDescription(/valid email/i);
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/between 1 and 8/i);
  await expect(page.getByLabel("Name")).not.toHaveAttribute("aria-invalid", "true");
});

test("a booking cannot take more seats than are left", async ({ page }) => {
  await page.goto("/book/winter-tasting");
  await fillBooking(page, { name: "Carla Voss", email: "carla@example.com", guests: 7 });
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await page.goto("/book/winter-tasting");
  await fillBooking(page, { name: "Dora Klein", email: "dora@example.com", guests: 4 });
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByLabel("Guests")).toHaveAccessibleDescription(/only 3 seats are left/i);
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toHaveCount(0);
});

test("a fully booked tasting says so and cannot be booked", async ({ page }) => {
  await page.goto("/book/red-wine-cellar-tour");
  await fillBooking(page, { name: "Emil Roth", email: "emil@example.com", guests: 8 });
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await page.goto("/");
  const tour = card(page, "Red Wine Cellar Tour");
  await expect(tour).toContainText("Fully booked");
  await expect(tour).toContainText("0 seats left");
  await expect(page.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toHaveCount(0);

  await page.goto("/book/red-wine-cellar-tour");
  await expect(page.getByRole("main")).toContainText(/fully booked/i);
  await expect(page.getByRole("button", { name: "Book", exact: true })).toHaveCount(0);
});

test("staff sign in, see bookings grouped by tasting, and cancel one to free its seats", async ({ page }) => {
  await page.goto("/staff");
  await page.getByLabel("Password").fill("wrong");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByLabel("Password")).toHaveAccessibleDescription(/not correct/i);
  await expect(page.getByText("emil@example.com")).toHaveCount(0);

  await page.getByLabel("Password").fill("e2e-password");
  await page.getByRole("button", { name: "Sign in" }).click();

  const tour = page.getByRole("region", { name: "Red Wine Cellar Tour" });
  await expect(tour).toContainText("Emil Roth");
  await expect(tour).toContainText("emil@example.com");
  await expect(tour).toContainText(/KB-[A-Z2-9]{6}/);
  await expect(page.getByRole("region", { name: "Riesling Evening" })).toContainText("Anna Weber");
  await expect(page.getByRole("region", { name: "Winter Tasting" })).toContainText("Carla Voss");

  await tour.getByRole("row", { name: /Emil Roth/ }).getByRole("button", { name: "Cancel" }).click();
  await expect(page.getByText("emil@example.com")).toHaveCount(0);

  await page.goto("/");
  await expect(card(page, "Red Wine Cellar Tour")).toContainText("8 seats left");
  await expect(page.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toBeVisible();
});

test("staff bookings stay hidden for a browser that has not signed in", async ({ page, context }) => {
  await context.clearCookies();
  await page.goto("/staff");
  await expect(page.getByLabel("Password")).toBeVisible();
  await expect(page.getByText("anna@example.com")).toHaveCount(0);
});

test.describe("on a phone", () => {
  test.use({ viewport: { width: 375, height: 700 } });

  for (const path of ["/", "/book/riesling-evening", "/staff"]) {
    test(`${path} fits the screen without sideways scrolling`, async ({ page }) => {
      await page.goto(path);
      await page.getByRole("heading", { level: 1 }).waitFor();
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
      expect(overflow).toBeLessThanOrEqual(0);
    });
  }

  test("the booking can be completed on a phone", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("link", { name: "Book Riesling Evening" }).click();
    await fillBooking(page, { name: "Finn Maier", email: "finn@example.com", guests: 1 });
    await page.getByRole("button", { name: "Book", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  });
});

test.describe("staff on a phone", () => {
  test.use({ viewport: { width: 375, height: 700 } });

  test("the bookings list fits the screen and every Cancel button is reachable", async ({ page, request }) => {
    const made = await request.post("/api/tastings/winter-tasting/bookings", {
      data: { name: "Greta Lang-Hoffmann", email: "greta.lang-hoffmann@example-winery-mail.com", guests: 1 },
    });
    expect(made.ok()).toBe(true);
    await page.goto("/staff");
    await page.getByLabel("Password").fill("e2e-password");
    await page.getByRole("button", { name: "Sign in" }).click();
    await expect(page.getByText("greta.lang-hoffmann@example-winery-mail.com")).toBeVisible();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    expect(overflow).toBeLessThanOrEqual(0);
    const cancel = page.getByRole("row", { name: /Greta Lang-Hoffmann/ }).getByRole("button", { name: "Cancel" });
    const box = await cancel.boundingBox();
    expect(box.x + box.width).toBeLessThanOrEqual(375);
  });
});

test.describe("very long names on a phone", () => {
  test.use({ viewport: { width: 375, height: 700 } });
  const longName = "W".repeat(100);
  const overflow = (page) => page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);

  test("confirmation and staff list still fit the screen", async ({ page }) => {
    await page.goto("/book/riesling-evening");
    await page.getByLabel("Name").fill(longName);
    await page.getByLabel("Email").fill("long@example.com");
    await page.getByLabel("Guests").fill("1");
    await page.getByRole("button", { name: "Book", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
    expect(await overflow(page)).toBeLessThanOrEqual(0);

    await page.goto("/staff");
    await page.getByLabel("Password").fill("e2e-password");
    await page.getByRole("button", { name: "Sign in" }).click();
    await expect(page.getByText(longName)).toBeVisible();
    expect(await overflow(page)).toBeLessThanOrEqual(0);
  });
});

test("going Back after booking does not return to a form that could book twice", async ({ page }) => {
  await page.goto("/book/riesling-evening");
  await page.getByLabel("Name").fill("Hanna Back");
  await page.getByLabel("Email").fill("hanna@example.com");
  await page.getByLabel("Guests").fill("1");
  await page.getByRole("button", { name: "Book", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  await page.goBack();
  await expect(page).not.toHaveURL(/\/book\//);
});

test("a corrupted saved confirmation shows the friendly empty state, not a crash", async ({ page }) => {
  await page.goto("/");
  await page.evaluate(() => sessionStorage.setItem("lastBooking", '{"booking":{}}'));
  await page.goto("/booking-confirmed");
  await expect(page.getByRole("heading", { name: "No recent booking" })).toBeVisible();
});
