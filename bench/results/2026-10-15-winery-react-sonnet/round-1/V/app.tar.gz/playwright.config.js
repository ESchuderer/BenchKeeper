import { defineConfig } from "@playwright/test";

const PORT = 3111;

export default defineConfig({
  testDir: "e2e",
  workers: 1, // the app keeps bookings in memory, so journeys share one server in order
  fullyParallel: false,
  use: { baseURL: `http://localhost:${PORT}`, trace: "retain-on-failure" },
  webServer: {
    command: "npm run build && npm start",
    url: `http://localhost:${PORT}`,
    env: { PORT: String(PORT), STAFF_PASSWORD: "e2e-password" },
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
