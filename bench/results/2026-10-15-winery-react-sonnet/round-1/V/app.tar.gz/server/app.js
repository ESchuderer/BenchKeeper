import express from "express";
import path from "node:path";
import { createStaffAuth } from "./staffAuth.js";
import { bookingSchema, fieldErrors, seatsLeftMessage } from "../shared/bookingSchema.js";

// trustProxy: set when running behind a reverse proxy so the login throttle sees real client IPs.
export function createApp({ store, staffPassword, staticDir, trustProxy }) {
  if (!staffPassword) throw new Error("staffPassword is required");

  const app = express();
  app.disable("x-powered-by");
  if (trustProxy) app.set("trust proxy", trustProxy);
  app.use(express.json({ limit: "10kb" }));

  const api = express.Router();

  api.get("/tastings", (req, res) => {
    res.json(store.listTastings());
  });

  api.post("/tastings/:id/bookings", (req, res) => {
    const tasting = store.getTasting(req.params.id);
    if (!tasting) return res.status(404).json({ error: "Tasting not found." });

    const parsed = bookingSchema.safeParse(req.body ?? {});
    if (!parsed.success) return res.status(422).json({ errors: fieldErrors(parsed.error) });

    const result = store.book(tasting.id, parsed.data);
    if (!result.ok) {
      return res.status(409).json({ errors: { guests: seatsLeftMessage(result.seatsLeft ?? 0) } });
    }
    res.status(201).json({ booking: result.booking, tasting: store.getTasting(tasting.id) });
  });

  const staff = createStaffAuth({ password: staffPassword });
  api.use("/staff", staff.router);
  api.get("/staff/bookings", staff.requireStaff, (req, res) => res.json(store.bookingsByTasting()));
  api.delete("/staff/bookings/:reference", staff.requireStaff, (req, res) => {
    if (!store.cancel(req.params.reference)) return res.status(404).json({ error: "Booking not found." });
    res.status(204).end();
  });

  app.use("/api", api);
  app.use("/api", (req, res) => res.status(404).json({ error: "Not found." }));

  if (staticDir) {
    app.use(express.static(staticDir, { index: false, maxAge: "1h" }));
    // Client-side routes (/book/..., /staff) all get the single-page app.
    app.get(/.*/, (req, res) => res.sendFile(path.join(staticDir, "index.html")));
  }

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === "entity.parse.failed") return res.status(400).json({ error: "Invalid JSON." });
    if (err.type === "entity.too.large") return res.status(413).json({ error: "Request too large." });
    console.error(err);
    res.status(500).json({ error: "Something went wrong." });
  });

  return app;
}
