import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";
import { createBookingStore } from "./store.js";
import { TASTINGS } from "./tastings.js";

const staffPassword = process.env.STAFF_PASSWORD;
if (!staffPassword) {
  console.error("STAFF_PASSWORD is not set. Set it to the password staff use at /staff, e.g.\n  STAFF_PASSWORD=choose-a-password npm start");
  process.exit(1);
}

const port = Number(process.env.PORT) || 3000;
const staticDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../dist");

if (!fs.existsSync(path.join(staticDir, "index.html"))) {
  console.error("The web app has not been built yet. Run `npm run build` first, then `npm start`.");
  process.exit(1);
}

const app = createApp({
  store: createBookingStore(TASTINGS),
  staffPassword,
  staticDir,
  trustProxy: process.env.TRUST_PROXY === "1" ? 1 : undefined,
});
app.listen(port, () => console.log(`Weingut Kieselbrunnen bookings on http://localhost:${port}`));
