import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import cookieParser from "cookie-parser";
import express from "express";

const COOKIE = "staff_session";
const COOKIE_OPTIONS = { httpOnly: true, sameSite: "strict", path: "/" };
const SESSION_MS = 8 * 60 * 60 * 1000;
const MAX_FAILURES = 5;
const FAILURE_WINDOW_MS = 60 * 1000;

const digest = (value) => createHash("sha256").update(value).digest();

function safeEqual(a, b) {
  return timingSafeEqual(digest(a), digest(b));
}

export function createStaffAuth({ password, now = Date.now }) {
  const secret = randomBytes(32); // sessions end when the server restarts
  const failures = new Map(); // ip -> { count, since }

  const sign = (expires) => createHmac("sha256", secret).update(String(expires)).digest("hex");

  const issueToken = () => {
    const expires = now() + SESSION_MS;
    return `${expires}.${sign(expires)}`;
  };

  const isValidToken = (token) => {
    if (typeof token !== "string") return false;
    const [expires, signature, ...rest] = token.split(".");
    if (rest.length || !/^\d+$/.test(expires ?? "") || !signature) return false;
    return safeEqual(signature, sign(expires)) && Number(expires) > now();
  };

  const isThrottled = (ip) => {
    const entry = failures.get(ip);
    if (!entry) return false;
    if (now() - entry.since > FAILURE_WINDOW_MS) {
      failures.delete(ip);
      return false;
    }
    return entry.count >= MAX_FAILURES;
  };

  const recordFailure = (ip) => {
    const entry = failures.get(ip);
    if (entry && now() - entry.since <= FAILURE_WINDOW_MS) entry.count += 1;
    else failures.set(ip, { count: 1, since: now() });
  };

  const requireStaff = (req, res, next) => {
    if (isValidToken(req.cookies?.[COOKIE])) return next();
    res.status(401).json({ error: "Please sign in." });
  };

  const router = express.Router();
  router.use(cookieParser());

  router.post("/session", (req, res) => {
    const ip = req.ip ?? "unknown";
    if (isThrottled(ip)) {
      return res.status(429).json({ error: "Too many attempts. Please wait a minute and try again." });
    }
    const given = req.body?.password;
    if (typeof given !== "string" || !safeEqual(given, password)) {
      recordFailure(ip);
      return res.status(401).json({ error: "That password is not correct." });
    }
    failures.delete(ip);
    res.cookie(COOKIE, issueToken(), { ...COOKIE_OPTIONS, maxAge: SESSION_MS });
    res.status(204).end();
  });

  router.get("/session", requireStaff, (req, res) => res.status(204).end());

  router.delete("/session", (req, res) => {
    res.clearCookie(COOKIE, COOKIE_OPTIONS);
    res.status(204).end();
  });

  return { router, requireStaff };
}
