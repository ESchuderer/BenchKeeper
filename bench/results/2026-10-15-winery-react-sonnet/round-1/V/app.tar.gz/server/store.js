import { randomBytes } from "node:crypto";

const REFERENCE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function randomReference() {
  const bytes = randomBytes(6);
  let code = "";
  for (const b of bytes) code += REFERENCE_ALPHABET[b % REFERENCE_ALPHABET.length];
  return `KB-${code}`;
}

// All operations are synchronous: the seat check and the write happen in one
// uninterrupted step, so concurrent requests can never over-book.
export function createBookingStore(tastings, { generateReference = randomReference } = {}) {
  const bookings = new Map();

  const seatsTaken = (tastingId) => {
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === tastingId) taken += b.guests;
    return taken;
  };

  const withSeats = (t) => ({ ...t, seatsLeft: t.capacity - seatsTaken(t.id) });

  return {
    listTastings: () => tastings.map(withSeats),

    getTasting(id) {
      const t = tastings.find((x) => x.id === id);
      return t ? withSeats(t) : undefined;
    },

    book(tastingId, { name, email, guests }) {
      const tasting = this.getTasting(tastingId);
      if (!tasting) return { ok: false, reason: "unknown-tasting" };
      if (!Number.isInteger(guests) || guests < 1) return { ok: false, reason: "invalid-guests" };
      if (guests > tasting.seatsLeft) {
        return { ok: false, reason: "insufficient-seats", seatsLeft: tasting.seatsLeft };
      }
      let reference = generateReference();
      while (bookings.has(reference)) reference = generateReference();
      const booking = {
        reference,
        tastingId,
        name,
        email,
        guests,
        totalCents: guests * tasting.priceCents,
      };
      bookings.set(reference, booking);
      return { ok: true, booking: { ...booking } };
    },

    cancel(reference) {
      return bookings.delete(reference);
    },

    bookingsByTasting() {
      return tastings.map((t) => ({
        tasting: withSeats(t),
        bookings: [...bookings.values()].filter((b) => b.tastingId === t.id).map((b) => ({ ...b })),
      }));
    },
  };
}
