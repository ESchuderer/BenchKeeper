import { z } from "zod";

export const MAX_GUESTS = 8;

const GUESTS_MESSAGE = `Please choose between 1 and ${MAX_GUESTS} guests.`;

// Form inputs deliver strings; JSON clients deliver numbers. Accept both, but
// only whole numbers: "", "abc" and "1.5" stay invalid.
const guestsField = z.preprocess(
  (v) => (typeof v === "string" && /^\s*\d+\s*$/.test(v) ? Number(v) : v),
  z
    .number({ error: GUESTS_MESSAGE })
    .int({ error: GUESTS_MESSAGE })
    .min(1, { error: GUESTS_MESSAGE })
    .max(MAX_GUESTS, { error: GUESTS_MESSAGE }),
);

export const bookingSchema = z.object({
  name: z
    .string({ error: "Please enter your name." })
    .trim()
    .min(1, { error: "Please enter your name." })
    .max(100, { error: "Please keep your name under 100 characters." }),
  email: z
    .string({ error: "Please enter your email address." })
    .trim()
    .min(1, { error: "Please enter your email address." })
    .max(254, { error: "That email address is too long." })
    .pipe(z.email({ error: "Please enter a valid email address, like name@example.com." })),
  guests: guestsField,
});

// Collapses zod issues into { field: firstMessage }.
export function fieldErrors(error) {
  const errors = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0] ?? "form");
    errors[field] ??= issue.message;
  }
  return errors;
}

export function seatsLeftMessage(seatsLeft) {
  if (seatsLeft <= 0) return "Sorry, this tasting is fully booked.";
  return `Only ${seatsLeft} ${seatsLeft === 1 ? "seat is" : "seats are"} left for this tasting.`;
}
