import { Route, Routes } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import BookingPage from "./pages/BookingPage.jsx";
import ConfirmationPage from "./pages/ConfirmationPage.jsx";
import NotFoundPage from "./pages/NotFoundPage.jsx";
import StaffPage from "./pages/StaffPage.jsx";
import TastingsPage from "./pages/TastingsPage.jsx";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<TastingsPage />} />
        <Route path="book/:tastingId" element={<BookingPage />} />
        <Route path="booking-confirmed" element={<ConfirmationPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
