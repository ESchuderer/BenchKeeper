export class ApiError extends Error {
  constructor(status, body) {
    super(body?.error ?? "Something went wrong. Please try again.");
    this.status = status;
    this.errors = body?.errors ?? {};
  }
}

async function request(path, { method = "GET", body } = {}) {
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method,
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, { error: "We could not reach the server. Please check your connection and try again." });
  }
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}

export const api = {
  tastings: () => request("/tastings"),
  book: (tastingId, booking) => request(`/tastings/${tastingId}/bookings`, { method: "POST", body: booking }),
  staffSession: () => request("/staff/session"),
  staffSignIn: (password) => request("/staff/session", { method: "POST", body: { password } }),
  staffSignOut: () => request("/staff/session", { method: "DELETE" }),
  staffBookings: () => request("/staff/bookings"),
  staffCancel: (reference) => request(`/staff/bookings/${encodeURIComponent(reference)}`, { method: "DELETE" }),
};
