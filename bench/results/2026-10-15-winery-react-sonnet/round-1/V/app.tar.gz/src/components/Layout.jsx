import { Link, Outlet, useLocation } from "react-router-dom";

function Grapes() {
  return (
    <svg viewBox="0 0 32 32" className="h-8 w-8 shrink-0" aria-hidden="true">
      <circle cx="16" cy="16" r="16" fill="#b8893b" />
      <g fill="#4a1425">
        <circle cx="11" cy="14" r="3.2" /><circle cx="17" cy="14" r="3.2" /><circle cx="23" cy="14" r="3.2" />
        <circle cx="14" cy="20" r="3.2" /><circle cx="20" cy="20" r="3.2" /><circle cx="17" cy="26" r="3.2" />
      </g>
      <path d="M17 11c0-3 1.5-5 5-6" stroke="#3f5a2a" strokeWidth="2" fill="none" strokeLinecap="round" />
    </svg>
  );
}

export default function Layout() {
  const { pathname } = useLocation();
  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-10 focus:rounded focus:bg-white focus:px-3 focus:py-2">
        Skip to content
      </a>
      <header className="bg-wine-900 text-cream">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <Link to="/" className="flex items-center gap-3 no-underline">
            <Grapes />
            <span className="font-display text-xl leading-tight text-cream sm:text-2xl">Weingut Kieselbrunnen</span>
          </Link>
        </div>
        <div className="h-1 bg-gold" />
      </header>

      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
        <Outlet />
      </main>

      <footer className="border-t border-line bg-parchment">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-6 text-sm text-muted sm:px-6">
          <p>Weingut Kieselbrunnen &middot; A family winery</p>
          {pathname !== "/staff" && (
            <Link to="/staff" className="underline underline-offset-2 hover:text-wine-700">
              Staff
            </Link>
          )}
        </div>
      </footer>
    </div>
  );
}
