import { forwardRef, useId } from "react";

const BUTTON_BASE =
  "inline-flex min-h-11 items-center justify-center rounded-md px-5 py-2 font-semibold no-underline transition-colors disabled:cursor-not-allowed disabled:opacity-60";
const BUTTON_STYLES = {
  primary: "bg-wine-900 text-cream hover:bg-wine-700",
  secondary: "border border-wine-900 bg-transparent text-wine-900 hover:bg-wine-100",
  danger: "border border-error bg-white text-error hover:bg-error-bg",
};

export const buttonClass = (variant = "primary", extra = "") => `${BUTTON_BASE} ${BUTTON_STYLES[variant]} ${extra}`;

export function Button({ variant = "primary", className = "", ...props }) {
  return <button type="button" className={buttonClass(variant, className)} {...props} />;
}

// A labelled input with its error message tied to it for screen readers.
export const Field = forwardRef(function Field({ label, error, hint, className = "", ...inputProps }, ref) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [error && errorId, hint && hintId].filter(Boolean).join(" ") || undefined;
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block font-semibold text-wine-900">
        {label}
      </label>
      <input
        id={id}
        ref={ref}
        aria-invalid={error ? "true" : undefined}
        aria-describedby={describedBy}
        className={`min-h-11 w-full rounded-md border bg-white px-3 py-2 text-base ${
          error ? "border-error bg-error-bg" : "border-line"
        }`}
        {...inputProps}
      />
      {hint && !error && (
        <p id={hintId} className="mt-1 text-sm text-muted">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} className="mt-1 flex items-start gap-1.5 text-sm font-medium text-error">
          <span aria-hidden="true">&#9888;</span>
          <span>{error}</span>
        </p>
      )}
    </div>
  );
});

export function Notice({ tone = "error", children, className = "", ...props }) {
  const tones = {
    error: "border-error bg-error-bg text-error",
    success: "border-leaf bg-leaf-bg text-leaf",
    info: "border-line bg-parchment text-ink",
  };
  return (
    <div className={`rounded-md border-l-4 px-4 py-3 ${tones[tone]} ${className}`} {...props}>
      {children}
    </div>
  );
}

export function Badge({ tone = "info", children }) {
  const tones = {
    info: "bg-parchment text-wine-900",
    full: "bg-wine-900 text-cream",
    low: "bg-gold/20 text-gold-dark",
  };
  return <span className={`inline-block rounded-full px-3 py-1 text-sm font-semibold ${tones[tone]}`}>{children}</span>;
}

export function Loading({ children = "Loading…" }) {
  return (
    <p role="status" className="text-muted">
      {children}
    </p>
  );
}
