export function formatPrice(cents) {
  const euros = cents / 100;
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`;
}

export function seatsLeftText(n) {
  return `${n} seats left`;
}

export function formatGuests(n) {
  return `${n} ${n === 1 ? "guest" : "guests"}`;
}

// "2026-11-06T18:00" -> { text: "2026-11-06 18:00", weekday: "Fri", day: "6", month: "Nov" }
// Parsed by hand so the winery's local time never shifts with the visitor's time zone.
export function describeStart(startsAt) {
  const [date, time] = startsAt.split("T");
  const [y, m, d] = date.split("-").map(Number);
  const when = new Date(Date.UTC(y, m - 1, d));
  const opts = { timeZone: "UTC" };
  return {
    text: `${date} ${time}`,
    weekday: when.toLocaleDateString("en-GB", { ...opts, weekday: "short" }),
    day: String(d),
    month: when.toLocaleDateString("en-GB", { ...opts, month: "short" }),
  };
}
