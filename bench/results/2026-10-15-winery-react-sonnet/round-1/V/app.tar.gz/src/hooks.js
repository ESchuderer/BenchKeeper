import { useCallback, useEffect, useState } from "react";
import { api } from "./api.js";

export function useTastings() {
  const [state, setState] = useState({ status: "loading", tastings: [] });

  const load = useCallback(() => {
    // Keep showing the current tastings while refreshing; only a failed load goes back to "loading".
    setState((s) => (s.status === "error" ? { ...s, status: "loading" } : s));
    return api.tastings().then(
      (tastings) => setState({ status: "ready", tastings }),
      (error) => setState({ status: "error", tastings: [], message: error.message }),
    );
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { ...state, reload: load };
}

export function useDocumentTitle(title) {
  useEffect(() => {
    document.title = title ? `${title} · Weingut Kieselbrunnen` : "Weingut Kieselbrunnen";
  }, [title]);
}
