import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useNavigate, useParams } from "react-router-dom";
import { bookingSchema, MAX_GUESTS } from "../../shared/bookingSchema.js";
import { ApiError, api } from "../api.js";
import { Button, Field, Loading, Notice, buttonClass } from "../components/ui.jsx";
import { describeStart, formatPrice, seatsLeftText } from "../format.js";
import { useDocumentTitle, useTastings } from "../hooks.js";

const FIELDS = ["name", "email", "guests"];

function BookingForm({ tasting, onSeatsChanged }) {
  const navigate = useNavigate();
  const [formError, setFormError] = useState(null);
  const {
    register,
    handleSubmit,
    setError,
    setFocus,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: "", email: "", guests: "2" },
    shouldFocusError: true,
  });

  async function onSubmit(values) {
    setFormError(null);
    try {
      const { booking } = await api.book(tasting.id, values);
      sessionStorage.setItem("lastBooking", JSON.stringify({ booking, tasting }));
      navigate("/booking-confirmed", { state: { booking, tasting }, replace: true });
    } catch (error) {
      if (!(error instanceof ApiError)) throw error;
      const fieldMessages = Object.entries(error.errors).filter(([field]) => FIELDS.includes(field));
      if (fieldMessages.length === 0) return setFormError(error.message);
      fieldMessages.forEach(([field, message]) => setError(field, { type: "server", message }));
      setFocus(fieldMessages[0][0]);
      if (error.status === 409) onSeatsChanged();
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid gap-5">
      {formError && <Notice role="alert">{formError}</Notice>}
      <Field label="Name" autoComplete="name" error={errors.name?.message} {...register("name")} />
      <Field
        label="Email"
        type="email"
        autoComplete="email"
        inputMode="email"
        error={errors.email?.message}
        {...register("email")}
      />
      <Field
        label="Guests"
        type="number"
        inputMode="numeric"
        min={1}
        max={MAX_GUESTS}
        hint={`1 to ${MAX_GUESTS} guests · ${seatsLeftText(tasting.seatsLeft)}`}
        error={errors.guests?.message}
        {...register("guests")}
      />
      <Button type="submit" disabled={isSubmitting} className="w-full sm:w-auto sm:justify-self-start">
        {isSubmitting ? "Booking…" : "Book"}
      </Button>
    </form>
  );
}

export default function BookingPage() {
  const { tastingId } = useParams();
  const { status, tastings, message, reload } = useTastings();
  const tasting = tastings.find((t) => t.id === tastingId);
  useDocumentTitle(tasting ? `Book ${tasting.title}` : "Book a tasting");

  if (status === "loading") return <Loading />;
  if (status === "error") return <Notice role="alert">{message}</Notice>;
  if (!tasting) {
    return (
      <>
        <h1 className="text-3xl">We could not find that tasting</h1>
        <p className="mt-4">
          <Link to="/" className="underline">Back to all tastings</Link>
        </p>
      </>
    );
  }

  const full = tasting.seatsLeft <= 0;
  const when = describeStart(tasting.startsAt);
  return (
    <div className="mx-auto max-w-xl">
      <Link to="/" className="text-sm text-muted underline underline-offset-2">&larr; All tastings</Link>
      <h1 className="mt-3 text-3xl sm:text-4xl">Book {tasting.title}</h1>
      <p className="mt-2 text-muted">
        <time dateTime={tasting.startsAt}>{when.text}</time> &middot; {formatPrice(tasting.priceCents)} per guest
      </p>

      <div className="mt-6 rounded-xl border border-line bg-white p-5 shadow-sm sm:p-6">
        {full ? (
          <div>
            <Notice tone="info" role="status">
              <strong>Fully booked.</strong> Every seat for this tasting has been taken ({seatsLeftText(0)}).
            </Notice>
            <Link to="/" className={buttonClass("secondary", "mt-4")}>See other tastings</Link>
          </div>
        ) : (
          <BookingForm key={tasting.id} tasting={tasting} onSeatsChanged={reload} />
        )}
      </div>
    </div>
  );
}
