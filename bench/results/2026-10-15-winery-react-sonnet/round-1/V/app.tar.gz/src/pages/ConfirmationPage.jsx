import { useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { buttonClass } from "../components/ui.jsx";
import { describeStart, formatGuests, formatPrice } from "../format.js";
import { useDocumentTitle } from "../hooks.js";

const isConfirmation = (d) =>
  Boolean(d?.booking?.reference && d?.tasting?.title && d.tasting.startsAt && Number.isFinite(d.booking.guests));

function lastBooking(state) {
  if (isConfirmation(state)) return state;
  try {
    const saved = JSON.parse(sessionStorage.getItem("lastBooking"));
    return isConfirmation(saved) ? saved : null;
  } catch {
    return null;
  }
}

export default function ConfirmationPage() {
  const { state } = useLocation();
  const data = lastBooking(state);
  useDocumentTitle("Booking confirmed");
  const heading = useRef(null);
  useEffect(() => heading.current?.focus(), [data]);

  if (!data) {
    return (
      <div className="mx-auto max-w-xl">
        <h1 className="text-3xl">No recent booking</h1>
        <p className="mt-3 text-muted">Pick a tasting to make a booking.</p>
        <Link to="/" className={buttonClass("primary", "mt-5")}>See the tastings</Link>
      </div>
    );
  }

  const { booking, tasting } = data;
  const rows = [
    ["Tasting", tasting.title],
    ["Date and time", describeStart(tasting.startsAt).text],
    ["Guests", formatGuests(booking.guests)],
    ["Total price", formatPrice(booking.totalCents)],
    ["Booking reference", booking.reference],
  ];
  return (
    <div className="mx-auto max-w-xl">
      <div className="rounded-xl border-t-4 border-leaf bg-white p-6 shadow-sm sm:p-8">
        <p className="mb-2 flex items-start gap-2 rounded-2xl bg-leaf-bg px-3 py-1 text-sm font-semibold text-leaf [overflow-wrap:anywhere]">
          <span aria-hidden="true">&#10003;</span> Thank you, {booking.name}
        </p>
        <h1 className="text-3xl sm:text-4xl" tabIndex={-1} ref={heading}>Booking confirmed</h1>
        <p className="mt-2 text-muted">We have reserved your seats. Please keep your booking reference.</p>
        <dl className="mt-6 divide-y divide-line">
          {rows.map(([label, value]) => (
            <div key={label} className="flex flex-wrap justify-between gap-x-4 gap-y-1 py-3">
              <dt className="text-muted">{label}</dt>
              <dd className={`font-semibold ${label === "Booking reference" ? "font-mono text-lg tracking-wider text-wine-900" : ""}`}>
                {value}
              </dd>
            </div>
          ))}
        </dl>
        <Link to="/" className={buttonClass("secondary", "mt-6")}>Back to all tastings</Link>
      </div>
    </div>
  );
}
