import { Link } from "react-router-dom";
import { buttonClass } from "../components/ui.jsx";
import { useDocumentTitle } from "../hooks.js";

export default function NotFoundPage() {
  useDocumentTitle("Page not found");
  return (
    <div className="mx-auto max-w-xl text-center">
      <h1 className="text-4xl">Page not found</h1>
      <p className="mt-3 text-muted">We could not find the page you were looking for.</p>
      <Link to="/" className={buttonClass("primary", "mt-6")}>See the tastings</Link>
    </div>
  );
}
