import { useCallback, useEffect, useState } from "react";
import { ApiError, api } from "../api.js";
import { Button, Field, Loading, Notice } from "../components/ui.jsx";
import { describeStart, formatGuests, seatsLeftText } from "../format.js";
import { useDocumentTitle } from "../hooks.js";

function SignIn({ onSignedIn }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.staffSignIn(password);
      onSignedIn();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Something went wrong. Please try again.");
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="text-3xl">Staff sign in</h1>
      <p className="mt-2 text-muted">Bookings are only visible to winery staff.</p>
      <form onSubmit={submit} noValidate className="mt-6 grid gap-5 rounded-xl border border-line bg-white p-5 shadow-sm">
        <Field
          label="Password"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={error}
        />
        <Button type="submit" disabled={busy}>
          {busy ? "Signing in…" : "Sign in"}
        </Button>
      </form>
    </div>
  );
}

// Below the sm breakpoint each row becomes a small card; the explicit roles keep the table semantics.
function BookingRow({ booking, onCancel, busy, failed }) {
  return (
    <tr
      role="row"
      className="grid grid-cols-[1fr_auto] gap-x-3 border-t border-line py-3 sm:table-row sm:py-0 sm:align-top"
    >
      <td role="cell" className="min-w-0 sm:py-3 sm:pr-3">
        <div id={`booking-${booking.reference}`} className="font-semibold [overflow-wrap:anywhere]">{booking.name}</div>
        <div className="break-words text-sm text-muted [overflow-wrap:anywhere]">{booking.email}</div>
        {failed && <div className="mt-1 text-sm font-medium text-error">{failed}</div>}
      </td>
      <td role="cell" className="col-start-1 text-sm sm:px-3 sm:py-3 sm:text-center sm:text-base">
        <span className="text-muted sm:hidden">Guests: </span>
        {booking.guests}
      </td>
      <td role="cell" className="col-start-1 font-mono text-sm sm:px-3 sm:py-3">
        <span className="font-sans text-muted sm:hidden">Reference: </span>
        {booking.reference}
      </td>
      <td role="cell" className="col-start-2 row-start-1 row-span-3 self-start sm:py-3 sm:pl-3 sm:text-right">
        <Button
          variant="danger"
          className="min-h-10 px-3"
          disabled={busy}
          aria-describedby={`booking-${booking.reference}`}
          onClick={() => onCancel(booking)}
        >
          Cancel
        </Button>
      </td>
    </tr>
  );
}

function TastingGroup({ group, onCancel, busyRef, failures }) {
  const { tasting, bookings } = group;
  const headingId = `tasting-${tasting.id}`;
  const guests = bookings.reduce((sum, b) => sum + b.guests, 0);
  return (
    <section aria-labelledby={headingId} className="min-w-0 rounded-xl border border-line bg-white p-5 shadow-sm">
      <h2 id={headingId} className="text-2xl">{tasting.title}</h2>
      <p className="text-sm text-muted">
        {describeStart(tasting.startsAt).text} &middot; {formatGuests(guests)} booked &middot; {seatsLeftText(tasting.seatsLeft)}
      </p>
      {bookings.length === 0 ? (
        <p className="mt-4 text-muted">No bookings yet.</p>
      ) : (
        <table role="table" className="mt-3 w-full text-left">
          <thead role="rowgroup" className="max-sm:sr-only text-sm text-muted">
            <tr role="row">
              <th role="columnheader" scope="col" className="pb-2 pr-3 font-medium">Name and email</th>
              <th role="columnheader" scope="col" className="px-3 pb-2 text-center font-medium">Guests</th>
              <th role="columnheader" scope="col" className="px-3 pb-2 font-medium">Reference</th>
              <th role="columnheader" scope="col" className="pb-2 pl-3"><span className="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody role="rowgroup" className="max-sm:block">
            {bookings.map((b) => (
              <BookingRow
                key={b.reference}
                booking={b}
                onCancel={onCancel}
                busy={busyRef === b.reference}
                failed={failures[b.reference]}
              />
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

function Bookings({ onSignedOut }) {
  const [groups, setGroups] = useState(null);
  const [loadError, setLoadError] = useState(null);
  const [busyRef, setBusyRef] = useState(null);
  const [failures, setFailures] = useState({});

  const load = useCallback(async () => {
    try {
      setGroups(await api.staffBookings());
      setLoadError(null);
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) return onSignedOut();
      setLoadError(e.message);
    }
  }, [onSignedOut]);

  useEffect(() => {
    load();
  }, [load]);

  async function cancel(booking) {
    setBusyRef(booking.reference);
    setFailures(({ [booking.reference]: _, ...rest }) => rest);
    try {
      await api.staffCancel(booking.reference);
      await load();
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) return onSignedOut();
      if (e instanceof ApiError && e.status === 404) await load(); // already gone
      else setFailures((f) => ({ ...f, [booking.reference]: "Could not cancel this booking. Please try again." }));
    } finally {
      setBusyRef(null);
    }
  }

  async function signOut() {
    await api.staffSignOut().catch(() => {});
    onSignedOut();
  }

  return (
    <>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl sm:text-4xl">Bookings</h1>
        <Button variant="secondary" onClick={signOut}>Sign out</Button>
      </div>
      {loadError && <Notice role="alert" className="mb-6">{loadError}</Notice>}
      {!groups && !loadError && <Loading>Loading bookings…</Loading>}
      {groups && (
        <div className="grid grid-cols-1 gap-6">
          {groups.map((g) => (
            <TastingGroup key={g.tasting.id} group={g} onCancel={cancel} busyRef={busyRef} failures={failures} />
          ))}
        </div>
      )}
    </>
  );
}

export default function StaffPage() {
  useDocumentTitle("Staff");
  const [auth, setAuth] = useState("checking"); // checking | signedOut | signedIn
  const signedOut = useCallback(() => setAuth("signedOut"), []);

  useEffect(() => {
    api.staffSession().then(
      () => setAuth("signedIn"),
      () => setAuth("signedOut"),
    );
  }, []);

  if (auth === "checking") return <Loading />;
  if (auth === "signedOut") return <SignIn onSignedIn={() => setAuth("signedIn")} />;
  return <Bookings onSignedOut={signedOut} />;
}
