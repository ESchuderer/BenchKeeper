import { Link } from "react-router-dom";
import { Badge, Loading, Notice, Button, buttonClass } from "../components/ui.jsx";
import { describeStart, formatPrice, seatsLeftText } from "../format.js";
import { useDocumentTitle, useTastings } from "../hooks.js";

function DateTile({ startsAt }) {
  const { weekday, day, month } = describeStart(startsAt);
  return (
    <div
      aria-hidden="true"
      className="flex h-20 w-20 shrink-0 flex-col items-center justify-center rounded-lg bg-wine-900 text-cream"
    >
      <span className="text-xs uppercase tracking-widest text-gold">{weekday}</span>
      <span className="font-display text-3xl leading-none">{day}</span>
      <span className="text-xs uppercase tracking-widest">{month}</span>
    </div>
  );
}

function TastingCard({ tasting }) {
  const full = tasting.seatsLeft <= 0;
  const low = !full && tasting.seatsLeft <= 3;
  const when = describeStart(tasting.startsAt);
  return (
    <article className={`flex flex-col gap-4 rounded-xl border border-line bg-white p-5 shadow-sm ${full ? "opacity-90" : ""}`}>
      <div className="flex min-h-24 items-start gap-4">
        <DateTile startsAt={tasting.startsAt} />
        <div className="min-w-0">
          <h2 className="text-2xl">{tasting.title}</h2>
          <p className="text-muted">
            <time dateTime={tasting.startsAt}>{when.text}</time>
          </p>
        </div>
      </div>
      <dl className="flex flex-wrap items-center gap-x-6 gap-y-2">
        <div>
          <dt className="sr-only">Price</dt>
          <dd className="font-display text-2xl text-wine-900">
            {formatPrice(tasting.priceCents)} <span className="font-sans text-sm text-muted">per guest</span>
          </dd>
        </div>
        <div className="flex items-center gap-2">
          <dt className="sr-only">Availability</dt>
          <dd className="flex flex-wrap items-center gap-2">
            <span className={full ? "text-muted" : ""}>{seatsLeftText(tasting.seatsLeft)}</span>
            {full && <Badge tone="full">Fully booked</Badge>}
            {low && <Badge tone="low">Almost full</Badge>}
          </dd>
        </div>
      </dl>
      <div className="mt-auto">
        {full ? (
          <p className="text-sm text-muted">This tasting is fully booked. Please check back, seats may become free again.</p>
        ) : (
          <Link
            to={`/book/${tasting.id}`}
            className={buttonClass("primary", "w-full sm:w-auto")}
          >
            Book {tasting.title}
          </Link>
        )}
      </div>
    </article>
  );
}

export default function TastingsPage() {
  useDocumentTitle("");
  const { status, tastings, message, reload } = useTastings();
  return (
    <>
      <section className="mb-10 max-w-2xl">
        <h1 className="text-4xl sm:text-5xl">Wine tastings at the winery</h1>
        <p className="mt-4 text-lg text-muted">
          Spend an evening with us among the vines and barrels. Choose a tasting, reserve your seats, and we will
          see you there.
        </p>
      </section>

      {status === "loading" && <Loading>Loading tastings…</Loading>}
      {status === "error" && (
        <Notice role="alert">
          <p>{message}</p>
          <Button variant="secondary" className="mt-3" onClick={reload}>
            Try again
          </Button>
        </Notice>
      )}
      {status === "ready" && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {tastings.map((t) => (
            <TastingCard key={t.id} tasting={t} />
          ))}
        </div>
      )}
    </>
  );
}
