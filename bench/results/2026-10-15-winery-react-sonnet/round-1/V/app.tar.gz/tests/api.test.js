import request from "supertest";
import { describe, expect, test } from "vitest";
import { createApp } from "../server/app.js";
import { createBookingStore } from "../server/store.js";
import { TASTINGS } from "../server/tastings.js";

const newApp = () => createApp({ store: createBookingStore(TASTINGS), staffPassword: "s3cret" });
const valid = { name: "Anna Weber", email: "anna@example.com", guests: 2 };
const book = (app, id, body) => request(app).post(`/api/tastings/${id}/bookings`).send(body);

describe("GET /api/tastings", () => {
  test("lists the three tastings with price and seats left", async () => {
    const res = await request(newApp()).get("/api/tastings");
    expect(res.status).toBe(200);
    expect(res.body.map((t) => [t.title, t.startsAt, t.priceCents, t.seatsLeft])).toEqual([
      ["Riesling Evening", "2026-11-06T18:00", 2500, 12],
      ["Red Wine Cellar Tour", "2026-11-14T15:00", 3200, 8],
      ["Winter Tasting", "2026-12-05T17:00", 2800, 10],
    ]);
  });
});

describe("POST /api/tastings/:id/bookings", () => {
  test("books seats and returns the confirmation details", async () => {
    const app = newApp();
    const res = await book(app, "riesling-evening", valid);
    expect(res.status).toBe(201);
    expect(res.body.booking).toMatchObject({ name: "Anna Weber", guests: 2, totalCents: 5000 });
    expect(res.body.booking.reference).toMatch(/^KB-/);
    expect(res.body.tasting.title).toBe("Riesling Evening");
    const list = await request(app).get("/api/tastings");
    expect(list.body[0].seatsLeft).toBe(10);
  });

  test.each([
    [{ ...valid, name: "" }, "name"],
    [{ ...valid, name: "   " }, "name"],
    [{ ...valid, email: "" }, "email"],
    [{ ...valid, email: "not-an-email" }, "email"],
    [{ ...valid, guests: 0 }, "guests"],
    [{ ...valid, guests: 9 }, "guests"],
    [{ ...valid, guests: 1.5 }, "guests"],
    [{ ...valid, guests: "" }, "guests"],
    [{ ...valid, guests: "abc" }, "guests"],
    [{ ...valid, guests: undefined }, "guests"],
    [{ ...valid, name: 42 }, "name"],
  ])("rejects %j with an error on the %s field", async (body, field) => {
    const app = newApp();
    const res = await book(app, "riesling-evening", body);
    expect(res.status).toBe(422);
    expect(Object.keys(res.body.errors)).toEqual([field]);
    expect(typeof res.body.errors[field]).toBe("string");
    const list = await request(app).get("/api/tastings");
    expect(list.body[0].seatsLeft).toBe(12);
  });

  test("reports every invalid field at once", async () => {
    const res = await book(newApp(), "riesling-evening", { name: "", email: "x", guests: 0 });
    expect(Object.keys(res.body.errors).sort()).toEqual(["email", "guests", "name"]);
  });

  test("accepts guests sent as a numeric string", async () => {
    const res = await book(newApp(), "riesling-evening", { ...valid, guests: "3" });
    expect(res.status).toBe(201);
    expect(res.body.booking.guests).toBe(3);
  });

  test("refuses more guests than seats left, with the error on the guests field", async () => {
    const app = newApp();
    await book(app, "red-wine-cellar-tour", { ...valid, guests: 6 });
    const res = await book(app, "red-wine-cellar-tour", { ...valid, guests: 3 });
    expect(res.status).toBe(409);
    expect(res.body.errors.guests).toMatch(/2 seats/);
    const list = await request(app).get("/api/tastings");
    expect(list.body[1].seatsLeft).toBe(2);
  });

  test("refuses any booking once the tasting is fully booked", async () => {
    const app = newApp();
    await book(app, "red-wine-cellar-tour", { ...valid, guests: 8 });
    const res = await book(app, "red-wine-cellar-tour", { ...valid, guests: 1 });
    expect(res.status).toBe(409);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
  });

  test("simultaneous requests cannot take more seats than exist", async () => {
    const app = newApp();
    const results = await Promise.all(
      Array.from({ length: 6 }, () => book(app, "red-wine-cellar-tour", { ...valid, guests: 2 })),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(4);
    expect(results.filter((r) => r.status === 409)).toHaveLength(2);
  });

  test("an unknown tasting gives 404", async () => {
    const res = await book(newApp(), "nope", valid);
    expect(res.status).toBe(404);
  });

  test("malformed JSON gives 400, not a crash", async () => {
    const res = await request(newApp())
      .post("/api/tastings/riesling-evening/bookings")
      .set("Content-Type", "application/json")
      .send("{oops");
    expect(res.status).toBe(400);
  });
});
