import request from "supertest";
import { describe, expect, test } from "vitest";
import { createApp } from "../server/app.js";
import { createBookingStore } from "../server/store.js";
import { TASTINGS } from "../server/tastings.js";

const newApp = () => createApp({ store: createBookingStore(TASTINGS), staffPassword: "s3cret" });
const valid = { name: "Anna Weber", email: "anna@example.com", guests: 2 };

async function signedInAgent(app) {
  const agent = request.agent(app);
  const res = await agent.post("/api/staff/session").send({ password: "s3cret" });
  expect(res.status).toBe(204);
  return agent;
}

describe("staff access", () => {
  test("bookings cannot be read without signing in", async () => {
    const app = newApp();
    await request(app).post("/api/tastings/riesling-evening/bookings").send(valid);
    const res = await request(app).get("/api/staff/bookings");
    expect(res.status).toBe(401);
    expect(JSON.stringify(res.body)).not.toContain("anna@example.com");
  });

  test("a wrong password is refused and gives no access", async () => {
    const app = newApp();
    const agent = request.agent(app);
    const res = await agent.post("/api/staff/session").send({ password: "wrong" });
    expect(res.status).toBe(401);
    expect(res.body.error).toMatch(/password/i);
    expect((await agent.get("/api/staff/bookings")).status).toBe(401);
  });

  test("a missing or non-string password is refused", async () => {
    const app = newApp();
    expect((await request(app).post("/api/staff/session").send({})).status).toBe(401);
    expect((await request(app).post("/api/staff/session").send({ password: ["s3cret"] })).status).toBe(401);
  });

  test("a forged session cookie is refused", async () => {
    const res = await request(newApp()).get("/api/staff/bookings").set("Cookie", "staff_session=9999999999999.abc");
    expect(res.status).toBe(401);
  });

  test("the session cookie is HttpOnly", async () => {
    const res = await request(newApp()).post("/api/staff/session").send({ password: "s3cret" });
    expect(res.headers["set-cookie"][0]).toMatch(/HttpOnly/i);
  });

  test("signing out ends the session", async () => {
    const agent = await signedInAgent(newApp());
    expect((await agent.get("/api/staff/session")).status).toBe(204);
    await agent.delete("/api/staff/session");
    expect((await agent.get("/api/staff/bookings")).status).toBe(401);
  });

  test("repeated wrong passwords are throttled, even for the right password afterwards", async () => {
    const app = newApp();
    for (let i = 0; i < 5; i++) await request(app).post("/api/staff/session").send({ password: "nope" });
    const res = await request(app).post("/api/staff/session").send({ password: "s3cret" });
    expect(res.status).toBe(429);
  });
});

describe("staff bookings", () => {
  test("lists bookings grouped by tasting with name, email, guests and reference", async () => {
    const app = newApp();
    const made = await request(app).post("/api/tastings/winter-tasting/bookings").send(valid);
    const agent = await signedInAgent(app);
    const res = await agent.get("/api/staff/bookings");
    expect(res.status).toBe(200);
    expect(res.body.map((g) => g.tasting.title)).toEqual([
      "Riesling Evening",
      "Red Wine Cellar Tour",
      "Winter Tasting",
    ]);
    expect(res.body[0].bookings).toEqual([]);
    expect(res.body[2].bookings).toEqual([
      expect.objectContaining({
        name: "Anna Weber",
        email: "anna@example.com",
        guests: 2,
        reference: made.body.booking.reference,
      }),
    ]);
  });

  test("cancelling a booking removes it and frees its seats", async () => {
    const app = newApp();
    const made = await request(app).post("/api/tastings/riesling-evening/bookings").send({ ...valid, guests: 5 });
    const agent = await signedInAgent(app);
    const del = await agent.delete(`/api/staff/bookings/${made.body.booking.reference}`);
    expect(del.status).toBe(204);
    const groups = (await agent.get("/api/staff/bookings")).body;
    expect(groups[0].bookings).toEqual([]);
    const list = await request(app).get("/api/tastings");
    expect(list.body[0].seatsLeft).toBe(12);
  });

  test("a fully booked tasting can be booked again after a cancellation", async () => {
    const app = newApp();
    const made = await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...valid, guests: 8 });
    const agent = await signedInAgent(app);
    await agent.delete(`/api/staff/bookings/${made.body.booking.reference}`);
    const again = await request(app).post("/api/tastings/red-wine-cellar-tour/bookings").send({ ...valid, guests: 8 });
    expect(again.status).toBe(201);
  });

  test("cancelling an unknown reference gives 404", async () => {
    const agent = await signedInAgent(newApp());
    expect((await agent.delete("/api/staff/bookings/KB-ZZZZZZ")).status).toBe(404);
  });

  test("cancelling requires signing in", async () => {
    const app = newApp();
    const made = await request(app).post("/api/tastings/riesling-evening/bookings").send(valid);
    const res = await request(app).delete(`/api/staff/bookings/${made.body.booking.reference}`);
    expect(res.status).toBe(401);
    expect((await request(app).get("/api/tastings")).body[0].seatsLeft).toBe(10);
  });
});
