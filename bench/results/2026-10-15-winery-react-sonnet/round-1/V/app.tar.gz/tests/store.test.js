import { describe, expect, test } from "vitest";
import { createBookingStore } from "../server/store.js";
import { TASTINGS } from "../server/tastings.js";

const guest = { name: "Anna Weber", email: "anna@example.com" };

describe("booking store", () => {
  test("booking 2 guests on Riesling Evening leaves 10 of 12 seats", () => {
    const store = createBookingStore(TASTINGS);
    const result = store.book("riesling-evening", { ...guest, guests: 2 });
    expect(result.ok).toBe(true);
    const riesling = store.listTastings().find((t) => t.id === "riesling-evening");
    expect(riesling.seatsLeft).toBe(10);
  });
});

describe("booking store capacity", () => {
  test("a booking larger than the seats left is rejected and changes nothing", () => {
    const store = createBookingStore(TASTINGS);
    store.book("red-wine-cellar-tour", { ...guest, guests: 6 });
    const result = store.book("red-wine-cellar-tour", { ...guest, guests: 3 });
    expect(result).toEqual({ ok: false, reason: "insufficient-seats", seatsLeft: 2 });
    expect(store.getTasting("red-wine-cellar-tour").seatsLeft).toBe(2);
  });

  test("the last seats can be booked and the tasting is then full", () => {
    const store = createBookingStore(TASTINGS);
    expect(store.book("red-wine-cellar-tour", { ...guest, guests: 8 }).ok).toBe(true);
    expect(store.getTasting("red-wine-cellar-tour").seatsLeft).toBe(0);
    expect(store.book("red-wine-cellar-tour", { ...guest, guests: 1 }).ok).toBe(false);
  });

  test("an unknown tasting is rejected", () => {
    const store = createBookingStore(TASTINGS);
    expect(store.book("nope", { ...guest, guests: 1 })).toEqual({ ok: false, reason: "unknown-tasting" });
  });

  test.each([0, -1, 1.5, NaN])("%s guests is rejected", (guests) => {
    const store = createBookingStore(TASTINGS);
    expect(store.book("winter-tasting", { ...guest, guests }).ok).toBe(false);
    expect(store.getTasting("winter-tasting").seatsLeft).toBe(10);
  });
});

describe("booking store totals and references", () => {
  test("total is guests times the price per guest", () => {
    const store = createBookingStore(TASTINGS);
    const { booking } = store.book("winter-tasting", { ...guest, guests: 3 });
    expect(booking.totalCents).toBe(8400); // 3 x EUR 28
  });

  test("references are unique even if the generator repeats itself", () => {
    const codes = ["KB-AAAAAA", "KB-AAAAAA", "KB-BBBBBB"];
    const store = createBookingStore(TASTINGS, { generateReference: () => codes.shift() });
    const a = store.book("winter-tasting", { ...guest, guests: 1 }).booking;
    const b = store.book("winter-tasting", { ...guest, guests: 1 }).booking;
    expect([a.reference, b.reference]).toEqual(["KB-AAAAAA", "KB-BBBBBB"]);
  });

  test("default references look like KB-XXXXXX", () => {
    const store = createBookingStore(TASTINGS);
    const { booking } = store.book("winter-tasting", { ...guest, guests: 1 });
    expect(booking.reference).toMatch(/^KB-[A-Z2-9]{6}$/);
  });
});

describe("booking store cancellation and listing", () => {
  test("cancelling a booking frees its seats", () => {
    const store = createBookingStore(TASTINGS);
    const { booking } = store.book("riesling-evening", { ...guest, guests: 4 });
    expect(store.cancel(booking.reference)).toBe(true);
    expect(store.getTasting("riesling-evening").seatsLeft).toBe(12);
  });

  test("cancelling an unknown reference does nothing", () => {
    const store = createBookingStore(TASTINGS);
    expect(store.cancel("KB-ZZZZZZ")).toBe(false);
  });

  test("bookings are grouped by tasting in tasting order", () => {
    const store = createBookingStore(TASTINGS);
    store.book("winter-tasting", { name: "B", email: "b@example.com", guests: 2 });
    store.book("riesling-evening", { name: "A", email: "a@example.com", guests: 1 });
    const groups = store.bookingsByTasting();
    expect(groups.map((g) => [g.tasting.id, g.bookings.map((b) => b.name)])).toEqual([
      ["riesling-evening", ["A"]],
      ["red-wine-cellar-tour", []],
      ["winter-tasting", ["B"]],
    ]);
  });
});
