import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: { proxy: { "/api": `http://localhost:${process.env.PORT || 3000}` } },
  test: { include: ["tests/**/*.test.js"] },
});
