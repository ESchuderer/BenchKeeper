# Weingut Kieselbrunnen – tasting bookings

Guests book wine tastings online; staff see and cancel bookings at `/staff`.

## Run it

Requires Node.js 22.

```sh
npm install
npm run build
STAFF_PASSWORD='choose-a-password' PORT=3000 npm start
```

- `PORT` – port to listen on (default `3000`).
- `STAFF_PASSWORD` – password for `/staff`. If it is not set, nobody can sign in (a warning is logged at start).

- `TRUST_PROXY` – number of reverse proxies in front of the app (default `0`). Set it to `1` behind a single TLS-terminating proxy so sign-in throttling applies per visitor instead of to the proxy's address, and so the session cookie is marked `Secure` for HTTPS requests.

The app starts with no bookings. Bookings are kept **in memory** and are lost when the server restarts.

## Pages

| Path | Purpose |
|---|---|
| `/` | Tastings with date, price and seats left |
| `/book/:id` | Booking form and confirmation |
| `/staff` | Staff sign-in, bookings grouped by tasting, cancel |

The three tastings are defined in `server/tastings.ts`.

## Development

```sh
npm run dev          # API on :3000 and Vite dev server with hot reload
npm test             # unit, API and component tests (Vitest)
npm run typecheck
npm run build && npx playwright install chromium && npm run test:e2e   # end-to-end tests against the built app
```

Layout: `shared/` (validation schema, formatting, types used by both sides), `server/` (Express API and the booking rules in `booking-service.ts`), `src/` (React app, Tailwind CSS), `e2e/` (Playwright). Specs and design notes are in `openspec/changes/book-wine-tastings/`.
