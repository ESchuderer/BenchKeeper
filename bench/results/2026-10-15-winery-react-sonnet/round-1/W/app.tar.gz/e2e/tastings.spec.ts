import { expect, test, type APIRequestContext, type Page } from '@playwright/test';

const PASSWORD = 'e2e-password';

/** Bookings live in the server's memory and are shared by all tests, so start each test from none. */
async function clearBookings(request: APIRequestContext) {
  await request.post('/api/staff/login', { data: { password: PASSWORD } });
  const { groups } = await (await request.get('/api/staff/bookings')).json();
  for (const g of groups) for (const b of g.bookings) await request.delete(`/api/staff/bookings/${b.reference}`);
}
test.beforeEach(async ({ request }) => clearBookings(request));

async function book(page: Page, tasting: string, who: { name: string; email: string; guests: number }) {
  await page.goto('/');
  await page.getByRole('link', { name: `Book ${tasting}` }).click();
  await page.getByLabel('Name').fill(who.name);
  await page.getByLabel('Email').fill(who.email);
  await page.getByLabel('Guests').fill(String(who.guests));
  await page.getByRole('button', { name: 'Book', exact: true }).click();
}

const noHorizontalScroll = (page: Page) =>
  page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth);

test('start page lists the three tastings with their seats', async ({ page }) => {
  await page.goto('/');
  const cards = page.getByRole('article');
  await expect(cards).toHaveCount(3);
  await expect(cards.nth(0)).toContainText('Riesling Evening');
  await expect(cards.nth(0)).toContainText('6 November 2026');
  await expect(cards.nth(0)).toContainText('18:00');
  await expect(cards.nth(0)).toContainText('EUR 25');
  await expect(cards.nth(0)).toContainText('12 seats left');
  await expect(cards.nth(1)).toContainText('Red Wine Cellar Tour');
  await expect(cards.nth(1)).toContainText('EUR 32');
  await expect(cards.nth(1)).toContainText('8 seats left');
  await expect(cards.nth(2)).toContainText('Winter Tasting');
  await expect(cards.nth(2)).toContainText('EUR 28');
  await expect(cards.nth(2)).toContainText('10 seats left');
  expect(await noHorizontalScroll(page)).toBe(true);
});

test('a guest books a tasting and sees the confirmation; seats go down', async ({ page }) => {
  await book(page, 'Riesling Evening', { name: 'Anna Weber', email: 'anna@example.com', guests: 3 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(page.getByText('Riesling Evening')).toBeVisible();
  await expect(page.getByText('EUR 75')).toBeVisible();
  await expect(page.getByText(/^KB-[A-Z2-9]{6}$/)).toBeVisible();
  expect(await noHorizontalScroll(page)).toBe(true);

  await page.getByRole('link', { name: 'All tastings' }).click();
  await expect(page.getByRole('article').first()).toContainText('9 seats left');
});

test('invalid input is rejected next to the field it concerns', async ({ page }) => {
  await page.goto('/book/winter-tasting');
  await page.getByLabel('Guests').fill('');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription(/enter your name/i);
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription(/enter your email/i);
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/guests/i);

  await page.getByLabel('Name').fill('Ben');
  await page.getByLabel('Email').fill('nope');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription(/valid email/i);
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/at most 8/i);
  await expect(page.getByLabel('Name')).toHaveValue('Ben');
  expect(await noHorizontalScroll(page)).toBe(true);
});

test('a booking can never take more seats than are left, and a full tasting is marked', async ({ page }) => {
  await book(page, 'Red Wine Cellar Tour', { name: 'Anna', email: 'anna@example.com', guests: 6 });
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await book(page, 'Red Wine Cellar Tour', { name: 'Ben', email: 'ben@example.com', guests: 3 });
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('Only 2 seats are available.');
  await expect(page.getByText('2 seats left')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toHaveCount(0);

  await page.getByLabel('Guests').fill('2');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  const card = page.getByRole('article').nth(1);
  await expect(card).toContainText('Fully booked');
  await expect(card).toContainText('0 seats left');

  await book(page, 'Red Wine Cellar Tour', { name: 'Cleo', email: 'cleo@example.com', guests: 1 });
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription('This tasting is fully booked.');
});

test('staff sign in, see bookings grouped by tasting and cancel to free the seats', async ({ page }) => {
  await book(page, 'Winter Tasting', { name: 'Clara Vogt', email: 'clara@example.com', guests: 4 });
  const reference = (await page.getByText(/^KB-/).textContent())!;

  await page.goto('/staff');
  await page.getByLabel('Password').fill('wrong');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByLabel('Password')).toHaveAccessibleDescription('Incorrect password.');
  await expect(page.getByText('Clara Vogt')).toHaveCount(0);

  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  const group = page.getByRole('region', { name: 'Winter Tasting' });
  await expect(group).toContainText('Clara Vogt');
  await expect(group).toContainText('clara@example.com');
  await expect(group).toContainText(reference);
  await expect(group).toContainText('4 of 10 seats booked');
  await expect(page.getByRole('region', { name: 'Riesling Evening' })).toContainText('No bookings yet');
  expect(await noHorizontalScroll(page)).toBe(true);

  await page.reload();
  await expect(group).toContainText('Clara Vogt');

  await group.getByRole('button', { name: 'Cancel' }).click();
  await expect(page.getByText('Clara Vogt')).toHaveCount(0);

  await page.goto('/');
  await expect(page.getByRole('article').nth(2)).toContainText('10 seats left');

  await page.goto('/staff');
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
});
