# Design

## Context

Greenfield repo (Node.js 22, npm). One small deployable: `npm run build` then `npm start` serves API and UI on `PORT`. Requirements are in `specs/`; motivation in `proposal.md`.

## Goals / Non-Goals

**Goals:**
- Server is the single authority for validation and capacity; the client only mirrors it for fast feedback.
- One process, no external services, no database.
- Business rules testable without HTTP or a browser.

**Non-Goals:**
- Payments, email sending, accounts, editing a booking, admin editing of tastings, i18n.
- Persistence across restarts. Rejecting bookings for tastings in the past (all three are in the future; revisit if tastings become editable).

## Decisions

**Stack: TypeScript everywhere; Express 5 server; React 19 + Vite + React Router; Tailwind CSS v4; react-hook-form with zod.**
Established, maintained libraries for each concern (server, routing, forms, validation, styling). A SPA fits: three screens, one API. Alternatives: Next.js/React Router framework mode (heavier, SSR not needed); plain CSS (more code for a polished, responsive result).

**Shared zod schema (`shared/`)** defines the booking input rules (name, email, guests 1-8) and is used by both the server and the form resolver, so rules cannot drift. Capacity is not part of the schema; it is checked by the domain code.

**Domain module `BookingService` (pure TypeScript, no Express).** Holds the tastings (seeded constants) and bookings in memory. `book()` validates capacity and inserts in one synchronous step; Node's single thread makes this atomic, which satisfies the "simultaneous bookings" scenario (also covered by a test firing parallel HTTP requests). `cancel(ref)` deletes. Seats left is always derived (capacity - sum of guests), never stored, so it cannot go out of sync. Alternative: a JSON file for persistence; rejected as extra failure modes (corrupt file, concurrent writes) for a requirement that allows in-memory.

**HTTP API** (JSON): `GET /api/tastings`, `GET /api/tastings/:id`, `POST /api/tastings/:id/bookings` (201 booking / 422 `{errors:{field:message}}` / 404), `POST /api/staff/login`, `POST /api/staff/logout`, `GET /api/staff/bookings`, `DELETE /api/staff/bookings/:reference`. Capacity errors use the same `errors.guests` shape as validation errors so the UI maps all of them to a field uniformly. Public endpoints never include guest data.

**Staff auth: `cookie-session` (signed, httpOnly, SameSite=Strict cookie) with a key generated at boot; password compared via `crypto.timingSafeEqual` on SHA-256 digests; `express-rate-limit` on login.** Stateless, no session store to manage; restart signs staff out, which is acceptable. SameSite=Strict plus JSON-only bodies covers CSRF for the cancel endpoint. If `STAFF_PASSWORD` is unset/empty, login always fails and the server logs a warning at start. `helmet` for security headers. Alternative: HTTP basic auth (no styled sign-in page, no sign-out).

**Booking reference:** `KB-` plus 6 characters from an unambiguous alphabet (no 0/O/1/I) via `crypto.randomInt`, regenerated on collision.

**Money** is kept in euro cents; formatted as "EUR 25" (whole euros) in the UI to match the brief.

**Front end:** routes `/` (catalog), `/book/:id` (form, replaced in place by the confirmation after success), `/staff`. Forms use `noValidate` so server and client errors render identically (inline under the field, linked with `aria-describedby`, `role="alert"` for the form-level error). Fully booked: badge + "0 seats left", muted card; the form stays reachable and the server rejects with the Guests error. Look: cream background, deep burgundy and muted gold, serif headings from the system font stack (no external font requests), mobile-first layout.

**Serving:** Express serves `dist/client` and falls back to `index.html` for non-API GETs. `npm run build` = `vite build` + `tsc` for the server into `dist/server`; `npm start` runs `node dist/server/server/index.js` (the server build keeps `shared/` next to `server/`).

**Tests:** Vitest for the domain and the API (supertest, includes auth and concurrency); Vitest + Testing Library for the form and staff components; Playwright end-to-end for the real flows on desktop and phone viewport (if a browser can be installed in the container).

## Risks / Trade-offs

- [Bookings lost on restart] → stated in the proposal; domain sits behind `BookingService` so a file/DB store can be added later.
- [Single shared staff password, no audit] → acceptable for a small winery; rate limit on login; password never logged.
- [Seat counts shown on the start page go stale while a guest reads it] → server re-checks on submit and the error shows the real seats left; the form refreshes its seat count after a capacity error.
- [Cancel has no confirmation step] → one click per booking is what the brief asks for; the list updates immediately so a mistaken cancel is visible. Revisit if it causes mistakes.

**Deployment:** behind a reverse proxy set `TRUST_PROXY` (hop count) so login throttling is per client and cookies get `Secure`. Known accepted limits from the security review: anonymous bookings are not rate limited or verified (four requests can fill every tasting; staff can cancel), and logout is stateless (cookie expires after 12 h).
