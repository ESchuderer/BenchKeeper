# Proposal

## Why

Weingut Kieselbrunnen sells its wine tastings by phone and email. Guests cannot see how many seats are left, and staff keep the guest list by hand. An online booking page lets guests book at any time and gives staff one reliable list per tasting.

## What Changes

- New public web app: start page listing the three upcoming tastings with date, price and seats left.
- Booking form per tasting (name, email, guests 1-8) with field-level errors, a hard guarantee against overbooking, and a confirmation with a booking reference.
- Password-protected `/staff` page: bookings grouped by tasting, with cancellation that frees the seats.
- A single warm, responsive visual design with clear error, success and fully-booked states.
- Bookings are kept in memory; the app starts empty. The staff password comes from `STAFF_PASSWORD`.

## Capabilities

### New Capabilities
- `tasting-catalog`: Public listing of tastings with price, date/time and live seats left, including the fully-booked state.
- `tasting-booking`: Guest booking flow: validation, capacity enforcement, confirmation and booking reference.
- `staff-bookings`: Staff sign-in, bookings overview grouped by tasting, cancellation.

### Modified Capabilities

## Impact

- New code base (the repo has no application code yet): React front end, Node.js 22 server, automated tests.
- New runtime configuration: `STAFF_PASSWORD` (required for staff sign-in), `PORT` (default 3000).
- No external services. Bookings are lost when the server restarts (accepted; see design.md).
