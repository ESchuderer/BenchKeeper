# Spec Delta

## Purpose

Lets winery staff see who has booked which tasting and cancel bookings, while keeping guests' personal data away from the public.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL show a sign-in form with a "Password" field and a "Sign in" button. Sign-in SHALL succeed only with the exact value of the environment variable `STAFF_PASSWORD`. If that variable is unset or empty, nobody can sign in.

#### Scenario: Correct password
- **WHEN** staff enter the configured password and activate "Sign in"
- **THEN** the bookings overview is shown

#### Scenario: Wrong password
- **WHEN** staff enter a wrong or empty password
- **THEN** an error is shown next to the Password field and no bookings are shown

#### Scenario: Password not configured
- **WHEN** `STAFF_PASSWORD` is not set and anyone tries to sign in
- **THEN** sign-in is refused

### Requirement: Booking data is protected
Guest names, emails and booking references of other guests SHALL be available only to signed-in staff. Without a valid staff session, requests for bookings or cancellation SHALL be refused. Public pages and public data SHALL not expose them.

#### Scenario: Not signed in
- **WHEN** a request for the bookings list or a cancellation is made without signing in
- **THEN** it is refused with an "unauthorized" response and no data

#### Scenario: Session survives reload
- **WHEN** signed-in staff reload `/staff`
- **THEN** the bookings overview is still shown

#### Scenario: Sign out
- **WHEN** signed-in staff activate "Sign out"
- **THEN** the sign-in form is shown and the bookings are no longer accessible

### Requirement: Bookings grouped by tasting
Signed-in staff SHALL see all bookings grouped by tasting, each showing name, email, guests and reference, with the tasting's seats taken out of capacity. Tastings without bookings SHALL be shown with an empty-state message.

#### Scenario: Two bookings for one tasting
- **WHEN** two bookings exist for Riesling Evening and none for the others
- **THEN** the Riesling Evening group lists both with name, email, guests and reference
- **AND** the other two groups show that there are no bookings yet

### Requirement: Cancel a booking
Each booking SHALL have a "Cancel" button. Cancelling SHALL remove the booking from the staff list and free its seats immediately; the reference SHALL no longer be valid.

#### Scenario: Cancel frees seats
- **WHEN** staff cancel a booking of 4 guests for a tasting with 5 seats left
- **THEN** the booking disappears from the list and the tasting has 9 seats left on the start page

#### Scenario: Fully booked tasting becomes bookable
- **WHEN** staff cancel a booking of a fully booked tasting
- **THEN** the "Fully booked" marker disappears and a guest can book the freed seats

#### Scenario: Already cancelled
- **WHEN** a cancellation is requested for a reference that no longer exists
- **THEN** it fails with a "not found" response and nothing else changes
