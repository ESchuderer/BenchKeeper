# Tasks

## 1. Project setup

- [x] 1.1 Initialise `package.json` (Node 22, scripts `dev`, `build`, `start`, `test`, `test:e2e`), TypeScript configs, Vite + Tailwind config, `.gitignore`; verify `npm install` and `npm run build` on an empty app skeleton succeed

## 2. Domain: tastings and bookings (test first)

- [x] 2.1 Write `BookingService` tests (seed data, seats left, book, capacity boundary, overbooking, cancel frees seats, unknown ids, unique references, totals) and watch them fail
- [x] 2.2 Implement shared zod booking schema and `BookingService` until the tests pass (`npm test`)

## 3. HTTP API and staff auth (test first)

- [x] 3.1 Write supertest tests for the public API (list, get, booking 201/422/404, field errors, capacity error, parallel bookings, no guest data in public responses) and for staff auth (login right/wrong/unconfigured password, 401 without session, list grouped, cancel, 404 on repeat cancel, logout) and watch them fail
- [x] 3.2 Implement the Express app (`createApp`), server entry honouring `PORT` and `STAFF_PASSWORD`, static serving with SPA fallback; verify API tests pass

## 4. Guest UI (test first)

- [x] 4.1 Write component tests for the catalog (listing, "<n> seats left", "Book <title>" links, fully-booked state, load error) and the booking form (labels, per-field errors, kept input, server capacity error, confirmation content, double submit) and watch them fail
- [x] 4.2 Implement layout, visual design (palette, typography, states), catalog page and booking page/confirmation; verify component tests pass and look at the pages at desktop and 360 px width

## 5. Staff UI (test first)

- [x] 5.1 Write component tests for sign-in (right/wrong password), grouped bookings, empty state, cancel, sign out and restored session, and watch them fail
- [x] 5.2 Implement the `/staff` page; verify component tests pass

## 6. End-to-end verification and documentation

- [x] 6.1 Add Playwright tests for the full flows (book, overbook attempt, fully booked, staff sign-in, cancel frees seats, phone viewport without horizontal scroll) and run them against `npm run build && npm start` with `STAFF_PASSWORD` set
- [x] 6.2 Write `README.md` (install, build, start, env vars, tests, in-memory note) and verify the documented commands work from a clean clone
- [x] 6.3 Run the code review and security review skills over the change, fix findings, and re-run `npm test` and the e2e suite

## Workflow follow-up

- Archive the change after review (`openspec archive book-wine-tastings`).
