# tasting-booking Specification

## Purpose
Lets a guest reserve seats for a tasting and receive proof of the booking, while guaranteeing that a tasting is never overbooked.

## Requirements

### Requirement: Booking form
The booking form for a tasting SHALL show the tasting title, date and time, price per guest and seats left, and SHALL have the fields "Name", "Email" and "Guests" and a button "Book". "Guests" accepts whole numbers from 1 to 8.

#### Scenario: Form content
- **WHEN** a guest opens the booking form for Winter Tasting
- **THEN** the form shows "Winter Tasting", its date and time, "EUR 28" and "10 seats left"
- **AND** fields labelled "Name", "Email" and "Guests" and a "Book" button are present

#### Scenario: Unknown tasting
- **WHEN** a guest opens the booking form for a tasting that does not exist
- **THEN** a "not found" message with a link back to the start page is shown

### Requirement: Input validation with field-level errors
A booking request SHALL be rejected, with no booking created, when Name is empty or blank, Email is not a plausible email address, or Guests is not a whole number from 1 to 8. Each error message SHALL be shown next to the field it concerns, and the data the guest entered SHALL be kept.

#### Scenario: Empty form
- **WHEN** a guest submits the form with all fields empty
- **THEN** an error is shown next to Name, next to Email and next to Guests
- **AND** no booking is created

#### Scenario: Invalid email
- **WHEN** a guest submits Email "not-an-email" with otherwise valid data
- **THEN** an error is shown next to Email only, and the other entered values are still in the form

#### Scenario: Guests out of range
- **WHEN** a guest submits Guests 0, 9 or 2.5
- **THEN** an error is shown next to Guests and no booking is created

#### Scenario: Same rules without the form
- **WHEN** a booking request with invalid data is sent directly to the server
- **THEN** the server rejects it with a per-field error and creates no booking

### Requirement: Never exceed capacity
A booking SHALL be accepted only if its guests do not exceed the seats left of the tasting at the moment it is processed. A rejected booking SHALL not change seats left. The error SHALL be shown next to Guests and state how many seats are available.

#### Scenario: More guests than seats left
- **WHEN** 6 seats are left and a guest books 7
- **THEN** the booking is rejected with an error next to Guests stating that 6 seats are available
- **AND** seats left remain 6

#### Scenario: Exactly the seats left
- **WHEN** 4 seats are left and a guest books 4
- **THEN** the booking is accepted and the tasting is fully booked

#### Scenario: Booking a fully booked tasting
- **WHEN** a tasting has 0 seats left and a guest submits the form with valid data
- **THEN** the booking is rejected with an error next to Guests saying the tasting is fully booked

#### Scenario: Simultaneous bookings
- **WHEN** two bookings of 5 guests each are submitted at the same time for a tasting with 8 seats left
- **THEN** exactly one is accepted and the other is rejected

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (guests times price per guest) and a booking reference that is unique among bookings.

#### Scenario: Successful booking
- **WHEN** a guest books 3 guests for Riesling Evening
- **THEN** the page shows the heading "Booking confirmed", "Riesling Evening", 3 guests, total "EUR 75" and a booking reference
- **AND** the start page shows 9 seats left for Riesling Evening

### Requirement: Clear feedback while submitting
While a booking is being submitted the form SHALL prevent a second submission, and if the server cannot be reached an error message SHALL be shown without losing the entered data.

#### Scenario: Double click
- **WHEN** a guest activates "Book" twice in quick succession
- **THEN** only one booking is created
