# tasting-catalog Specification

## Purpose
Lets guests see which wine tastings the winery offers, what they cost and how many seats are still free, so they can choose one to book.

## Requirements

### Requirement: Start page lists all tastings
The start page SHALL list every tasting with its title, date and time, price per guest and seats left. The offered tastings are Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats).

#### Scenario: Fresh start
- **WHEN** a guest opens the start page and no bookings exist
- **THEN** the three tastings are listed in date order
- **AND** each shows its title, date and time, price per guest (e.g. "EUR 25") and "12 seats left", "8 seats left", "10 seats left" respectively

### Requirement: Seats left reflect current bookings
The seats left of a tasting SHALL equal its capacity minus the guests of all active bookings, and SHALL be shown as "<n> seats left".

#### Scenario: After a booking
- **WHEN** a booking for 3 guests exists for Riesling Evening
- **THEN** the start page shows "9 seats left" for Riesling Evening and unchanged values for the others

#### Scenario: After a cancellation
- **WHEN** staff cancel that booking
- **THEN** the start page shows "12 seats left" for Riesling Evening again

### Requirement: Booking entry point per tasting
Each tasting SHALL have a link or button named "Book <tasting title>" that opens the booking form for that tasting.

#### Scenario: Open booking form
- **WHEN** a guest activates "Book Riesling Evening"
- **THEN** the booking form for Riesling Evening opens

### Requirement: Fully booked state
A tasting with no seats left SHALL be marked clearly as fully booked on the start page, and the page SHALL still show "0 seats left".

#### Scenario: Last seat taken
- **WHEN** all seats of a tasting are booked
- **THEN** the tasting shows a "Fully booked" marker and "0 seats left"

### Requirement: Usable on a phone
The start page SHALL be fully usable on a 360 px wide screen without horizontal scrolling.

#### Scenario: Narrow viewport
- **WHEN** the start page is opened at 360 px width
- **THEN** all tastings and their booking links are readable and reachable without horizontal scrolling
