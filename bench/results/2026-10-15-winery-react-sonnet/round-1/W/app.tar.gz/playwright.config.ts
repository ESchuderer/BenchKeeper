import { defineConfig, devices } from '@playwright/test';

const PORT = 3300;

export default defineConfig({
  testDir: 'e2e',
  fullyParallel: false,
  workers: 1,
  reporter: 'list',
  use: { baseURL: `http://localhost:${PORT}` },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'phone', use: { ...devices['Pixel 5'] } },
  ],
  // Tests run against the built app, exactly as `npm start` serves it. Run `npm run build` first.
  webServer: {
    command: 'npm start',
    url: `http://localhost:${PORT}/api/tastings`,
    env: { PORT: String(PORT), STAFF_PASSWORD: 'e2e-password' },
    reuseExistingServer: false,
  },
});
