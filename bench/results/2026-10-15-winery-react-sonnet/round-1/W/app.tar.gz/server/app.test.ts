import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createApp } from './app.js';

const PASSWORD = 'correct horse';
const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

const newApp = (staffPassword: string | undefined = PASSWORD) => createApp({ staffPassword });

async function signedInAgent(app = newApp()) {
  const agent = request.agent(app);
  await agent.post('/api/staff/login').send({ password: PASSWORD }).expect(204);
  return { agent, app };
}

describe('public API', () => {
  it('lists tastings with seats left', async () => {
    const res = await request(newApp()).get('/api/tastings').expect(200);
    expect(res.body.tastings.map((t: any) => [t.title, t.seatsLeft])).toEqual([
      ['Riesling Evening', 12],
      ['Red Wine Cellar Tour', 8],
      ['Winter Tasting', 10],
    ]);
  });

  it('returns one tasting or 404', async () => {
    const app = newApp();
    const ok = await request(app).get('/api/tastings/winter-tasting').expect(200);
    expect(ok.body).toMatchObject({ title: 'Winter Tasting', priceCents: 2800, seatsLeft: 10 });
    await request(app).get('/api/tastings/nope').expect(404);
  });

  it('creates a booking, returns the confirmation data and takes the seats', async () => {
    const app = newApp();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guest, guests: 3 }).expect(201);
    expect(res.body.booking).toMatchObject({ guests: 3, totalCents: 7500, tastingId: 'riesling-evening' });
    expect(res.body.booking.reference).toMatch(/^KB-/);
    expect(res.body.tasting).toMatchObject({ title: 'Riesling Evening', seatsLeft: 9 });
    const list = await request(app).get('/api/tastings').expect(200);
    expect(list.body.tastings[0].seatsLeft).toBe(9);
  });

  it('rejects invalid input with a 422 and a message per field, creating nothing', async () => {
    const app = newApp();
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').send({ name: '', email: 'x', guests: 9 }).expect(422);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
    expect((await request(app).get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(12);
  });

  it('rejects overbooking with the guests error and the current seats left', async () => {
    const app = newApp();
    await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 6 }).expect(201);
    const res = await request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 3 }).expect(422);
    expect(res.body.errors).toEqual({ guests: 'Only 2 seats are available.' });
    expect(res.body.tasting.seatsLeft).toBe(2);
  });

  it('books a tasting for an unknown id as 404', async () => {
    await request(newApp()).post('/api/tastings/nope/bookings').send(guest).expect(404);
  });

  it('accepts only one of two simultaneous bookings that do not both fit', async () => {
    const app = newApp();
    const results = await Promise.all(
      [1, 2].map(() => request(app).post('/api/tastings/red-wine-cellar-tour/bookings').send({ ...guest, guests: 5 })),
    );
    expect(results.map((r) => r.status).sort()).toEqual([201, 422]);
    expect((await request(app).get('/api/tastings/red-wine-cellar-tour')).body.seatsLeft).toBe(3);
  });

  it('answers malformed JSON with a 400 instead of crashing', async () => {
    await request(newApp())
      .post('/api/tastings/riesling-evening/bookings')
      .set('Content-Type', 'application/json')
      .send('{not json')
      .expect(400);
  });

  it('never exposes guest data on public endpoints', async () => {
    const app = newApp();
    const booked = await request(app).post('/api/tastings/riesling-evening/bookings').send(guest).expect(201);
    for (const path of ['/api/tastings', '/api/tastings/riesling-evening']) {
      const text = (await request(app).get(path)).text;
      expect(text).not.toContain('anna@example.com');
      expect(text).not.toContain('Anna');
      expect(text).not.toContain(booked.body.booking.reference);
    }
  });

  it('returns JSON 404 for unknown API paths', async () => {
    const res = await request(newApp()).get('/api/nothing').expect(404);
    expect(res.headers['content-type']).toMatch(/json/);
  });
});

describe('serving the client', () => {
  const clientDir = mkdtempSync(path.join(tmpdir(), 'client-'));
  writeFileSync(path.join(clientDir, 'index.html'), '<div id="root"></div>');
  mkdirSync(path.join(clientDir, 'assets'));
  writeFileSync(path.join(clientDir, 'assets', 'app.js'), 'console.log(1)');
  const app = createApp({ staffPassword: PASSWORD, clientDir });

  it('serves the app for client-side routes', async () => {
    for (const route of ['/', '/staff', '/book/riesling-evening']) {
      const res = await request(app).get(route).expect(200);
      expect(res.text).toContain('id="root"');
    }
  });

  it('serves real assets and answers 404 for missing ones instead of HTML', async () => {
    await request(app).get('/assets/app.js').expect(200);
    await request(app).get('/assets/missing.js').expect(404);
  });

  it('answers a booking POST without a body with field errors, not a crash', async () => {
    const res = await request(app).post('/api/tastings/riesling-evening/bookings').expect(422);
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });
});

describe('staff API', () => {
  it('refuses bookings and cancellation without a session', async () => {
    const app = newApp();
    await request(app).get('/api/staff/bookings').expect(401);
    await request(app).delete('/api/staff/bookings/KB-AAAAAA').expect(401);
  });

  it('rejects a wrong or empty password with an error for the password field', async () => {
    const app = newApp();
    const wrong = await request(app).post('/api/staff/login').send({ password: 'nope' }).expect(401);
    expect(wrong.body.errors.password).toBeTruthy();
    await request(app).post('/api/staff/login').send({ password: '' }).expect(401);
    await request(app).post('/api/staff/login').send({}).expect(401);
    await request(app).post('/api/staff/login').send({ password: ['x'] }).expect(401);
  });

  it('refuses every sign-in when no password is configured', async () => {
    for (const configured of [undefined, '']) {
      const app = newApp(configured);
      await request(app).post('/api/staff/login').send({ password: '' }).expect(401);
      await request(app).post('/api/staff/login').send({ password: 'anything' }).expect(401);
    }
  });

  it('lists bookings grouped by tasting once signed in, and keeps the session', async () => {
    const { agent, app } = await signedInAgent();
    await request(app).post('/api/tastings/riesling-evening/bookings').send(guest).expect(201);
    const res = await agent.get('/api/staff/bookings').expect(200);
    expect(res.body.groups).toHaveLength(3);
    expect(res.body.groups[0].tasting.id).toBe('riesling-evening');
    expect(res.body.groups[0].bookings[0]).toMatchObject({ name: 'Anna Weber', email: 'anna@example.com', guests: 2 });
    expect(res.body.groups[1].bookings).toEqual([]);
  });

  it('cancels a booking, frees the seats, and reports 404 the second time', async () => {
    const { agent, app } = await signedInAgent();
    const booked = await request(app).post('/api/tastings/riesling-evening/bookings').send({ ...guest, guests: 4 }).expect(201);
    const ref = booked.body.booking.reference;
    await agent.delete(`/api/staff/bookings/${ref}`).expect(204);
    expect((await request(app).get('/api/tastings/riesling-evening')).body.seatsLeft).toBe(12);
    await agent.delete(`/api/staff/bookings/${ref}`).expect(404);
  });

  it('signs out', async () => {
    const { agent } = await signedInAgent();
    await agent.post('/api/staff/logout').expect(204);
    await agent.get('/api/staff/bookings').expect(401);
  });

  it('does not accept a forged session cookie', async () => {
    const app = newApp();
    const forged = Buffer.from(JSON.stringify({ staff: true })).toString('base64');
    await request(app).get('/api/staff/bookings').set('Cookie', `session=${forged}`).expect(401);
  });

  it('sets a http-only, same-site strict session cookie', async () => {
    const res = await request(newApp()).post('/api/staff/login').send({ password: PASSWORD }).expect(204);
    const cookie = (res.headers['set-cookie'] as unknown as string[]).find((c) => c.startsWith('session='))!;
    expect(cookie).toMatch(/httponly/i);
    expect(cookie).toMatch(/samesite=strict/i);
  });

  it('throttles per real client when behind a trusted proxy, so one attacker cannot lock everyone out', async () => {
    const app = createApp({ staffPassword: PASSWORD, loginAttemptsPerWindow: 3, trustProxy: 1 });
    for (let i = 0; i < 3; i++) {
      await request(app).post('/api/staff/login').set('X-Forwarded-For', '203.0.113.9').send({ password: 'bad' }).expect(401);
    }
    await request(app).post('/api/staff/login').set('X-Forwarded-For', '203.0.113.9').send({ password: PASSWORD }).expect(429);
    await request(app).post('/api/staff/login').set('X-Forwarded-For', '198.51.100.7').send({ password: PASSWORD }).expect(204);
  });

  it('throttles repeated failed sign-ins', async () => {
    const app = createApp({ staffPassword: PASSWORD, loginAttemptsPerWindow: 3 });
    for (let i = 0; i < 3; i++) await request(app).post('/api/staff/login').send({ password: 'bad' }).expect(401);
    const res = await request(app).post('/api/staff/login').send({ password: PASSWORD }).expect(429);
    expect(res.body.errors.password).toBeTruthy();
  });
});
