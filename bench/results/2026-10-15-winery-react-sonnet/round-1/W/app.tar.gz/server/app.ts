import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { existsSync } from 'node:fs';
import path from 'node:path';
import express, { type ErrorRequestHandler, type RequestHandler } from 'express';
import helmet from 'helmet';
import cookieSession from 'cookie-session';
import { rateLimit } from 'express-rate-limit';
import { createBookingService, type BookingService } from './booking-service.js';

export interface AppOptions {
  /** The staff password; when unset or empty nobody can sign in. */
  staffPassword?: string;
  /** Directory with the built client; when given it is served with an SPA fallback. */
  clientDir?: string;
  /** Failed sign-in attempts allowed per IP per 15 minutes. */
  loginAttemptsPerWindow?: number;
  /** Number of reverse proxies in front of the app (Express `trust proxy`), so limits apply per real client IP. */
  trustProxy?: number;
  bookings?: BookingService;
}

const sha256 = (value: string) => createHash('sha256').update(value).digest();

function passwordMatches(expected: string | undefined, given: unknown): boolean {
  if (!expected || typeof given !== 'string') return false;
  return timingSafeEqual(sha256(expected), sha256(given));
}

const WRONG_PASSWORD = { errors: { password: 'Incorrect password.' } };

export function createApp(options: AppOptions = {}) {
  const service = options.bookings ?? createBookingService();
  const app = express();

  app.disable('x-powered-by');
  if (options.trustProxy) app.set('trust proxy', options.trustProxy);
  app.use(helmet());
  app.use(express.json({ limit: '10kb' }));
  app.use(
    cookieSession({
      name: 'session',
      keys: [randomBytes(32).toString('hex')],
      httpOnly: true,
      sameSite: 'strict',
      maxAge: 12 * 60 * 60 * 1000,
    }),
  );

  const api = express.Router();

  api.get('/tastings', (_req, res) => {
    res.json({ tastings: service.listTastings() });
  });

  api.get('/tastings/:id', (req, res) => {
    const tasting = service.getTasting(req.params.id);
    if (!tasting) return void res.status(404).json({ error: 'Tasting not found.' });
    res.json(tasting);
  });

  api.post('/tastings/:id/bookings', (req, res) => {
    const result = service.book(req.params.id, req.body);
    if (result.ok) {
      return void res.status(201).json({ booking: result.booking, tasting: service.getTasting(req.params.id) });
    }
    if (result.reason === 'not-found') return void res.status(404).json({ error: 'Tasting not found.' });
    res.status(422).json({ errors: result.errors, tasting: service.getTasting(req.params.id) });
  });

  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: options.loginAttemptsPerWindow ?? 10,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) =>
      void res.status(429).json({ errors: { password: 'Too many attempts. Please try again later.' } }),
  });

  api.post('/staff/login', loginLimiter, (req, res) => {
    if (!passwordMatches(options.staffPassword, req.body?.password)) {
      return void res.status(401).json(WRONG_PASSWORD);
    }
    req.session!.staff = true;
    res.status(204).end();
  });

  api.post('/staff/logout', (req, res) => {
    req.session = null;
    res.status(204).end();
  });

  const requireStaff: RequestHandler = (req, res, next) => {
    if (req.session?.staff === true) return next();
    res.status(401).json({ error: 'Please sign in.' });
  };

  api.get('/staff/bookings', requireStaff, (_req, res) => {
    res.json({ groups: service.listBookingsByTasting() });
  });

  api.delete('/staff/bookings/:reference', requireStaff, (req, res) => {
    if (!service.cancel(String(req.params.reference))) {
      return void res.status(404).json({ error: 'Booking not found.' });
    }
    res.status(204).end();
  });

  api.use((_req, res) => void res.status(404).json({ error: 'Not found.' }));
  app.use('/api', api);

  const { clientDir } = options;
  if (clientDir && existsSync(path.join(clientDir, 'index.html'))) {
    const indexHtml = path.resolve(clientDir, 'index.html');
    app.use(express.static(path.resolve(clientDir), { index: false }));
    app.use((req, res, next) => {
      // Missing files (e.g. a stale /assets/x.js) must 404, not return the app shell.
      if ((req.method !== 'GET' && req.method !== 'HEAD') || path.extname(req.path) !== '') return next();
      res.sendFile(indexHtml);
    });
  }

  const onError: ErrorRequestHandler = (err, _req, res, _next) => {
    const status = typeof err?.status === 'number' && err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) console.error(err);
    res.status(status).json({ error: status === 500 ? 'Something went wrong.' : 'Invalid request.' });
  };
  app.use(onError);

  return app;
}
