import { describe, it, expect, beforeEach } from 'vitest';
import { createBookingService, type BookingService } from './booking-service.js';

const guest = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 };

let service: BookingService;
beforeEach(() => {
  service = createBookingService();
});

describe('tastings', () => {
  it('offers the three tastings in date order with all seats free', () => {
    expect(service.listTastings()).toEqual([
      { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceCents: 2500, capacity: 12, seatsLeft: 12 },
      { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceCents: 3200, capacity: 8, seatsLeft: 8 },
      { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceCents: 2800, capacity: 10, seatsLeft: 10 },
    ]);
  });

  it('finds a tasting by id and returns undefined for an unknown id', () => {
    expect(service.getTasting('winter-tasting')?.title).toBe('Winter Tasting');
    expect(service.getTasting('nope')).toBeUndefined();
  });
});

describe('booking', () => {
  it('confirms a booking with total price and reference, and takes the seats', () => {
    const result = service.book('riesling-evening', { ...guest, guests: 3 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.booking).toMatchObject({
      tastingId: 'riesling-evening',
      name: 'Anna Weber',
      email: 'anna@example.com',
      guests: 3,
      totalCents: 7500,
    });
    expect(result.booking.reference).toMatch(/^KB-[A-HJ-NP-Z2-9]{6}$/);
    expect(service.getTasting('riesling-evening')?.seatsLeft).toBe(9);
    expect(service.getTasting('winter-tasting')?.seatsLeft).toBe(10);
  });

  it('trims name and email', () => {
    const result = service.book('riesling-evening', { name: '  Anna  ', email: ' anna@example.com ', guests: 1 });
    expect(result.ok && result.booking).toMatchObject({ name: 'Anna', email: 'anna@example.com' });
  });

  it('gives every booking a different reference', () => {
    const refs = new Set<string>();
    for (let i = 0; i < 12; i++) {
      const r = service.book('riesling-evening', { ...guest, guests: 1 });
      if (r.ok) refs.add(r.booking.reference);
    }
    expect(refs.size).toBe(12);
  });

  it('reports an unknown tasting', () => {
    expect(service.book('nope', guest)).toEqual({ ok: false, reason: 'not-found' });
  });
});

describe('validation', () => {
  it.each([
    ['empty name', { ...guest, name: '   ' }, 'name'],
    ['missing name', { email: guest.email, guests: 2 }, 'name'],
    ['bad email', { ...guest, email: 'not-an-email' }, 'email'],
    ['empty email', { ...guest, email: '' }, 'email'],
    ['zero guests', { ...guest, guests: 0 }, 'guests'],
    ['nine guests', { ...guest, guests: 9 }, 'guests'],
    ['fractional guests', { ...guest, guests: 2.5 }, 'guests'],
    ['text guests', { ...guest, guests: 'two' }, 'guests'],
    ['missing guests', { name: guest.name, email: guest.email }, 'guests'],
  ])('rejects %s with an error for that field only and books nothing', (_label, input, field) => {
    const result = service.book('riesling-evening', input);
    expect(result.ok).toBe(false);
    if (result.ok || result.reason !== 'invalid') throw new Error('expected invalid');
    expect(Object.keys(result.errors)).toEqual([field]);
    expect(result.errors[field as 'name']).toBeTruthy();
    expect(service.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });

  it('reports all invalid fields at once', () => {
    const result = service.book('riesling-evening', {});
    if (result.ok || result.reason !== 'invalid') throw new Error('expected invalid');
    expect(Object.keys(result.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it.each([undefined, null, 'text', 42, [], [guest]])('treats a non-object body (%j) as missing fields, with errors on real fields only', (body) => {
    const result = service.book('riesling-evening', body);
    if (result.ok || result.reason !== 'invalid') throw new Error('expected invalid');
    expect(Object.keys(result.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it.each(['0x3', '1e0', '3.0', '2.5', '', ' ', '-1', 'Infinity'])('rejects guests %j sent as a string', (guests) => {
    const result = service.book('riesling-evening', { ...guest, guests });
    if (result.ok || result.reason !== 'invalid') throw new Error('expected invalid');
    expect(Object.keys(result.errors)).toEqual(['guests']);
  });

  it('accepts a numeric string for guests', () => {
    expect(service.book('riesling-evening', { ...guest, guests: '4' }).ok).toBe(true);
  });
});

describe('capacity', () => {
  it('rejects more guests than seats left, naming the seats left, and changes nothing', () => {
    service.book('red-wine-cellar-tour', { ...guest, guests: 6 }); // 2 left
    const result = service.book('red-wine-cellar-tour', { ...guest, guests: 3 });
    if (result.ok || result.reason !== 'invalid') throw new Error('expected invalid');
    expect(result.errors.guests).toBe('Only 2 seats are available.');
    expect(service.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(2);
  });

  it('uses singular for one seat left', () => {
    service.book('red-wine-cellar-tour', { ...guest, guests: 7 });
    const result = service.book('red-wine-cellar-tour', { ...guest, guests: 2 });
    if (result.ok || result.reason !== 'invalid') throw new Error('expected invalid');
    expect(result.errors.guests).toBe('Only 1 seat is available.');
  });

  it('accepts exactly the seats left and then reports fully booked', () => {
    expect(service.book('red-wine-cellar-tour', { ...guest, guests: 8 }).ok).toBe(true);
    expect(service.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(0);
    const result = service.book('red-wine-cellar-tour', { ...guest, guests: 1 });
    if (result.ok || result.reason !== 'invalid') throw new Error('expected invalid');
    expect(result.errors.guests).toBe('This tasting is fully booked.');
  });
});

describe('listing and cancelling', () => {
  it('lists bookings grouped by tasting, including tastings without bookings', () => {
    service.book('riesling-evening', { ...guest, guests: 2 });
    service.book('riesling-evening', { name: 'Ben', email: 'ben@example.com', guests: 1 });
    const groups = service.listBookingsByTasting();
    expect(groups.map((g) => g.tasting.id)).toEqual(['riesling-evening', 'red-wine-cellar-tour', 'winter-tasting']);
    expect(groups[0].bookings.map((b) => b.name)).toEqual(['Anna Weber', 'Ben']);
    expect(groups[1].bookings).toEqual([]);
    expect(groups[0].tasting.seatsLeft).toBe(9);
  });

  it('cancelling removes the booking and frees its seats, even from fully booked', () => {
    const r = service.book('red-wine-cellar-tour', { ...guest, guests: 8 });
    if (!r.ok) throw new Error('booking failed');
    expect(service.cancel(r.booking.reference)).toBe(true);
    expect(service.getTasting('red-wine-cellar-tour')?.seatsLeft).toBe(8);
    expect(service.listBookingsByTasting()[1].bookings).toEqual([]);
    expect(service.book('red-wine-cellar-tour', { ...guest, guests: 8 }).ok).toBe(true);
  });

  it('cancelling an unknown or already cancelled reference returns false and changes nothing', () => {
    const r = service.book('riesling-evening', guest);
    if (!r.ok) throw new Error('booking failed');
    expect(service.cancel('KB-NOPE00')).toBe(false);
    expect(service.cancel(r.booking.reference)).toBe(true);
    expect(service.cancel(r.booking.reference)).toBe(false);
    expect(service.getTasting('riesling-evening')?.seatsLeft).toBe(12);
  });
});
