import { randomInt } from 'node:crypto';
import { bookingInputSchema, type FieldErrors } from '../shared/booking-schema.js';
import type { Booking, BookingGroup, Tasting } from '../shared/types.js';
import { TASTINGS } from './tastings.js';

export type BookResult =
  | { ok: true; booking: Booking }
  | { ok: false; reason: 'not-found' }
  | { ok: false; reason: 'invalid'; errors: FieldErrors };

export interface BookingService {
  listTastings(): Tasting[];
  getTasting(id: string): Tasting | undefined;
  book(tastingId: string, input: unknown): BookResult;
  cancel(reference: string): boolean;
  listBookingsByTasting(): BookingGroup[];
}

// No 0/O/1/I so references can be read out over the phone.
const REFERENCE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function newReference(taken: Map<string, Booking>): string {
  for (;;) {
    let code = '';
    for (let i = 0; i < 6; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
    const reference = `KB-${code}`;
    if (!taken.has(reference)) return reference;
  }
}

export function createBookingService(): BookingService {
  const bookings = new Map<string, Booking>();

  const seatsTaken = (tastingId: string) => {
    let taken = 0;
    for (const b of bookings.values()) if (b.tastingId === tastingId) taken += b.guests;
    return taken;
  };

  const getTasting = (id: string): Tasting | undefined => {
    const def = TASTINGS.find((t) => t.id === id);
    return def && { ...def, seatsLeft: def.capacity - seatsTaken(id) };
  };

  const listTastings = () => TASTINGS.map((t) => getTasting(t.id)!);

  return {
    listTastings,
    getTasting,

    // Validation, capacity check and insert run synchronously, so two requests can never both
    // pass the capacity check for the same seats. Keep it synchronous (no await) to preserve that.
    book(tastingId, input) {
      const tasting = getTasting(tastingId);
      if (!tasting) return { ok: false, reason: 'not-found' };

      const isRecord = typeof input === 'object' && input !== null && !Array.isArray(input);
      const parsed = bookingInputSchema.safeParse(isRecord ? input : {});
      if (!parsed.success) {
        const errors: FieldErrors = {};
        for (const issue of parsed.error.issues) {
          const field = issue.path[0] as keyof FieldErrors;
          errors[field] ??= issue.message;
        }
        return { ok: false, reason: 'invalid', errors };
      }

      const { name, email, guests } = parsed.data;
      if (guests > tasting.seatsLeft) {
        const message =
          tasting.seatsLeft === 0
            ? 'This tasting is fully booked.'
            : `Only ${tasting.seatsLeft} ${tasting.seatsLeft === 1 ? 'seat is' : 'seats are'} available.`;
        return { ok: false, reason: 'invalid', errors: { guests: message } };
      }

      const booking: Booking = {
        reference: newReference(bookings),
        tastingId,
        name,
        email,
        guests,
        totalCents: guests * tasting.priceCents,
      };
      bookings.set(booking.reference, booking);
      return { ok: true, booking };
    },

    cancel: (reference) => bookings.delete(reference),

    listBookingsByTasting: () =>
      listTastings().map((tasting) => ({
        tasting,
        bookings: [...bookings.values()].filter((b) => b.tastingId === tasting.id),
      })),
  };
}
