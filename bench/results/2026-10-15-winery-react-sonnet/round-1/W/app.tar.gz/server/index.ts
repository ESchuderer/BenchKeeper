import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';

const port = Number(process.env.PORT) || 3000;
const staffPassword = process.env.STAFF_PASSWORD;

if (!staffPassword) {
  console.warn('STAFF_PASSWORD is not set: nobody can sign in at /staff.');
}

// dist/server/server/index.js -> dist/client
const clientDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../client');

createApp({ staffPassword, clientDir, trustProxy: Number(process.env.TRUST_PROXY) || 0 }).listen(port, () => {
  console.log(`Weingut Kieselbrunnen tastings running on http://localhost:${port}`);
});
