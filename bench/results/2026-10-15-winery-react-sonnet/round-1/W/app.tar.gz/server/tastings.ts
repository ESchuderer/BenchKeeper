import type { Tasting } from '../shared/types.js';

type TastingDefinition = Omit<Tasting, 'seatsLeft'>;

export const TASTINGS: readonly TastingDefinition[] = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceCents: 2500, capacity: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceCents: 3200, capacity: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceCents: 2800, capacity: 10 },
];
