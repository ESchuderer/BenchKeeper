import { z } from 'zod';

export const MAX_GUESTS_PER_BOOKING = 8;

const guestsField = z.preprocess(
  // Form fields arrive as strings; accept plain digits only (no "0x3", "1e0", "3.0").
  (v) => (typeof v === 'string' && /^\s*\d+\s*$/.test(v) ? Number(v) : v),
  z
    .number({ error: `Enter a number of guests from 1 to ${MAX_GUESTS_PER_BOOKING}.` })
    .int('Guests must be a whole number.')
    .min(1, 'Book at least 1 guest.')
    .max(MAX_GUESTS_PER_BOOKING, `You can book at most ${MAX_GUESTS_PER_BOOKING} guests at a time.`),
);

export const bookingInputSchema = z.object({
  name: z
    .string({ error: 'Enter your name.' })
    .trim()
    .min(1, 'Enter your name.')
    .max(100, 'Name is too long.'),
  email: z
    .string({ error: 'Enter your email address.' })
    .trim()
    .min(1, 'Enter your email address.')
    .max(200, 'Email address is too long.')
    .pipe(z.email('Enter a valid email address, like name@example.com.')),
  guests: guestsField,
});

export type BookingInput = z.infer<typeof bookingInputSchema>;
export type FieldErrors = Partial<Record<keyof BookingInput, string>>;
