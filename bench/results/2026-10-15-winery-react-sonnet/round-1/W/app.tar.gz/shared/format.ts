/** "EUR 25", or "EUR 25.50" when the amount has cents. */
export function formatPrice(cents: number): string {
  const euros = cents / 100;
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`;
}

export function seatsLeftText(seatsLeft: number): string {
  // The brief fixes the wording as "<n> seats left", so there is no singular form.
  return `${seatsLeft} seats left`;
}

const dateFormat = new Intl.DateTimeFormat('en-GB', {
  weekday: 'long',
  day: 'numeric',
  month: 'long',
  year: 'numeric',
  timeZone: 'UTC',
});

/** "Friday, 6 November 2026 · 18:00" from a `YYYY-MM-DDTHH:mm` winery-local time (no zone shifting). */
export function formatStart(startsAt: string): string {
  const [date, time] = startsAt.split('T');
  const [y, m, d] = date.split('-').map(Number);
  return `${dateFormat.format(new Date(Date.UTC(y, m - 1, d)))} · ${time}`;
}
