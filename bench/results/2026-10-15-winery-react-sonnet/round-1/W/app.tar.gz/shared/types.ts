export interface Tasting {
  id: string;
  title: string;
  /** Local winery time, `YYYY-MM-DDTHH:mm`. */
  startsAt: string;
  priceCents: number;
  capacity: number;
  seatsLeft: number;
}

export interface Booking {
  reference: string;
  tastingId: string;
  name: string;
  email: string;
  guests: number;
  totalCents: number;
}

export interface BookingGroup {
  tasting: Tasting;
  bookings: Booking[];
}
