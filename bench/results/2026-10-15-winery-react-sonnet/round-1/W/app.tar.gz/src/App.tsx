import { Link, Route, Routes } from 'react-router';
import { Layout } from './components/Layout';
import { BookingPage } from './pages/BookingPage';
import { CatalogPage } from './pages/CatalogPage';
import { StaffPage } from './pages/StaffPage';

function NotFoundPage() {
  return (
    <section className="card mx-auto max-w-xl p-8 text-center">
      <h1 className="text-3xl font-semibold">Page not found</h1>
      <p className="mt-3 text-ink-soft">This page does not exist.</p>
      <Link to="/" className="btn-primary mt-6">
        All tastings
      </Link>
    </section>
  );
}

export function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<CatalogPage />} />
        <Route path="/book/:id" element={<BookingPage />} />
        <Route path="/staff" element={<StaffPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Layout>
  );
}
