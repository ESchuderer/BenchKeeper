import type { BookingInput, FieldErrors } from '../shared/booking-schema';
import type { Booking, BookingGroup, Tasting } from '../shared/types';

export class NetworkError extends Error {}
export class NotFoundError extends Error {}
export class UnauthorizedError extends Error {}

/** Per-field messages from the server; `password` is used by staff sign-in. */
export type ServerErrors = FieldErrors & { password?: string };

export class ValidationError extends Error {
  constructor(
    public errors: ServerErrors,
    public tasting?: Tasting,
  ) {
    super('validation failed');
  }
}

async function request(path: string, init?: RequestInit): Promise<Response> {
  try {
    return await fetch(path, {
      ...init,
      headers: init?.body ? { 'Content-Type': 'application/json' } : undefined,
    });
  } catch {
    throw new NetworkError('Could not reach the server.');
  }
}

async function readJson<T>(res: Response): Promise<T> {
  return (await res.json()) as T;
}

async function failFrom(res: Response): Promise<never> {
  if (res.status === 404) throw new NotFoundError();
  if (res.status === 401) {
    const body = await res.json().catch(() => ({}));
    throw body?.errors ? new ValidationError(body.errors) : new UnauthorizedError();
  }
  if (res.status === 422 || res.status === 429) {
    const body = await readJson<{ errors: ServerErrors; tasting?: Tasting }>(res);
    throw new ValidationError(body.errors, body.tasting);
  }
  throw new NetworkError(`Unexpected response (${res.status}).`);
}

export async function getTastings(): Promise<Tasting[]> {
  const res = await request('/api/tastings');
  if (!res.ok) return failFrom(res);
  return (await readJson<{ tastings: Tasting[] }>(res)).tastings;
}

export async function getTasting(id: string): Promise<Tasting> {
  const res = await request(`/api/tastings/${encodeURIComponent(id)}`);
  if (!res.ok) return failFrom(res);
  return readJson<Tasting>(res);
}

export async function createBooking(
  tastingId: string,
  input: BookingInput,
): Promise<{ booking: Booking; tasting: Tasting }> {
  const res = await request(`/api/tastings/${encodeURIComponent(tastingId)}/bookings`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
  if (!res.ok) return failFrom(res);
  return readJson(res);
}

export async function signIn(password: string): Promise<void> {
  const res = await request('/api/staff/login', { method: 'POST', body: JSON.stringify({ password }) });
  if (!res.ok) return failFrom(res);
}

export async function signOut(): Promise<void> {
  await request('/api/staff/logout', { method: 'POST' });
}

export async function getStaffBookings(): Promise<BookingGroup[]> {
  const res = await request('/api/staff/bookings');
  if (!res.ok) return failFrom(res);
  return (await readJson<{ groups: BookingGroup[] }>(res)).groups;
}

export async function cancelBooking(reference: string): Promise<void> {
  const res = await request(`/api/staff/bookings/${encodeURIComponent(reference)}`, { method: 'DELETE' });
  if (!res.ok && res.status !== 404) return failFrom(res);
}
