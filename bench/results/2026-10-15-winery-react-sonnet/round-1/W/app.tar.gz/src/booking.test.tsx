import { afterEach, describe, expect, it, vi } from 'vitest';
import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { fakeServer, renderApp, tasting, type FakeHandler } from './test-utils';

afterEach(() => vi.unstubAllGlobals());

const confirmed = (guests: number) => ({
  status: 201,
  body: {
    booking: { reference: 'KB-7F3K9Q', tastingId: 'riesling-evening', name: 'Anna', email: 'a@b.de', guests, totalCents: guests * 2500 },
    tasting: tasting({ seatsLeft: 12 - guests }),
  },
});

const serve = (post?: FakeHandler) =>
  fakeServer((req) => {
    if (req.method === 'GET') return { status: 200, body: tasting() };
    return post?.(req);
  });

async function openForm() {
  const user = userEvent.setup();
  renderApp('/book/riesling-evening');
  await screen.findByRole('heading', { name: 'Riesling Evening' });
  return user;
}

const fill = async (user: ReturnType<typeof userEvent.setup>, v: { name?: string; email?: string; guests?: string }) => {
  if (v.name !== undefined) await user.type(screen.getByLabelText('Name'), v.name);
  if (v.email !== undefined) await user.type(screen.getByLabelText('Email'), v.email);
  if (v.guests !== undefined) {
    await user.clear(screen.getByLabelText('Guests'));
    if (v.guests) await user.type(screen.getByLabelText('Guests'), v.guests);
  }
};

describe('booking form', () => {
  it('shows the tasting and the fields Name, Email and Guests with a Book button', async () => {
    serve();
    await openForm();
    expect(screen.getByText(/6 November 2026/)).toBeInTheDocument();
    expect(screen.getByText(/EUR 25/)).toBeInTheDocument();
    expect(screen.getByText('12 seats left')).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Guests')).toHaveAttribute('type', 'number');
    expect(screen.getByRole('button', { name: 'Book' })).toBeEnabled();
  });

  it('shows a not-found message with a way back for an unknown tasting', async () => {
    fakeServer(() => ({ status: 404, body: { error: 'Tasting not found.' } }));
    renderApp('/book/nope');
    expect(await screen.findByText(/could not find/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /all tastings/i })).toHaveAttribute('href', '/');
  });

  it('shows an error next to every empty field and sends nothing', async () => {
    const requests = serve();
    const user = await openForm();
    await user.clear(screen.getByLabelText('Guests'));
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByLabelText('Name')).toHaveAccessibleDescription(/enter your name/i);
    expect(screen.getByLabelText('Email')).toHaveAccessibleDescription(/enter your email/i);
    expect(screen.getByLabelText('Guests')).toHaveAccessibleDescription(/guests/i);
    expect(requests.filter((r) => r.method === 'POST')).toHaveLength(0);
  });

  it('rejects an invalid email only at the email field and keeps the other values', async () => {
    const requests = serve();
    const user = await openForm();
    await fill(user, { name: 'Anna', email: 'not-an-email', guests: '3' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByLabelText('Email')).toHaveAccessibleDescription(/valid email/i);
    expect(screen.getByLabelText('Name')).not.toHaveAccessibleDescription(/enter/i);
    expect(screen.getByLabelText('Name')).toHaveValue('Anna');
    expect(screen.getByLabelText('Guests')).toHaveValue(3);
    expect(requests.filter((r) => r.method === 'POST')).toHaveLength(0);
  });

  it.each(['0', '9'])('rejects %s guests next to the Guests field', async (guests) => {
    serve();
    const user = await openForm();
    await fill(user, { name: 'Anna', email: 'a@b.de', guests });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription(/at (least|most) \d guests?/i);
  });

  it('confirms a booking with heading, tasting, guests, total price and reference', async () => {
    const requests = serve(() => confirmed(3));
    const user = await openForm();
    await fill(user, { name: 'Anna', email: 'a@b.de', guests: '3' });
    await user.click(screen.getByRole('button', { name: 'Book' }));

    expect(await screen.findByRole('heading', { name: 'Booking confirmed' })).toBeInTheDocument();
    expect(screen.getByText('Riesling Evening')).toBeInTheDocument();
    expect(screen.getByText('3')).toBeInTheDocument();
    expect(screen.getByText('EUR 75')).toBeInTheDocument();
    expect(screen.getByText('KB-7F3K9Q')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Book' })).not.toBeInTheDocument();
    const post = requests.find((r) => r.method === 'POST')!;
    expect(post.path).toBe('/api/tastings/riesling-evening/bookings');
    expect(post.body).toEqual({ name: 'Anna', email: 'a@b.de', guests: 3 });
  });

  it('shows the server capacity error next to Guests, updates the seats left and keeps the input', async () => {
    serve(() => ({
      status: 422,
      body: { errors: { guests: 'Only 2 seats are available.' }, tasting: tasting({ seatsLeft: 2 }) },
    }));
    const user = await openForm();
    await fill(user, { name: 'Anna', email: 'a@b.de', guests: '5' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByLabelText('Guests')).toHaveAccessibleDescription('Only 2 seats are available.');
    expect(screen.getByText('2 seats left')).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toHaveValue('Anna');
    expect(screen.queryByRole('heading', { name: 'Booking confirmed' })).not.toBeInTheDocument();
  });

  it('announces a fully booked tasting on the form', async () => {
    fakeServer(() => ({ status: 200, body: tasting({ seatsLeft: 0 }) }));
    renderApp('/book/riesling-evening');
    expect(await screen.findByText('Fully booked')).toBeInTheDocument();
    expect(screen.getByText('0 seats left')).toBeInTheDocument();
  });

  it('submits only once when Book is activated twice quickly', async () => {
    let release: () => void = () => {};
    const gate = new Promise<void>((r) => (release = r));
    const requests = fakeServer((req) => (req.method === 'GET' ? { status: 200, body: tasting() } : confirmed(1)));
    const original = globalThis.fetch;
    vi.stubGlobal('fetch', async (...args: Parameters<typeof fetch>) => {
      if (args[1]?.method === 'POST') await gate;
      return original(...args);
    });
    const user = await openForm();
    await fill(user, { name: 'Anna', email: 'a@b.de', guests: '1' });
    const button = screen.getByRole('button', { name: 'Book' });
    await user.dblClick(button);
    release();
    await screen.findByRole('heading', { name: 'Booking confirmed' });
    expect(requests.filter((r) => r.method === 'POST')).toHaveLength(1);
  });

  it('shows an error and keeps the data when the server cannot be reached', async () => {
    serve(() => 'network-error');
    const user = await openForm();
    await fill(user, { name: 'Anna', email: 'a@b.de', guests: '2' });
    await user.click(screen.getByRole('button', { name: 'Book' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not reach/i);
    expect(screen.getByLabelText('Name')).toHaveValue('Anna');
    expect(screen.getByRole('button', { name: 'Book' })).toBeEnabled();
  });
});
