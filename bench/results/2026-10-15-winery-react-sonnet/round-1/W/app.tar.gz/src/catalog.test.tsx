import { afterEach, describe, expect, it, vi } from 'vitest';
import { screen, within } from '@testing-library/react';
import { allTastings, fakeServer, renderApp, tasting } from './test-utils';

afterEach(() => vi.unstubAllGlobals());

describe('start page', () => {
  it('lists every tasting with title, date and time, price per guest and seats left', async () => {
    fakeServer(() => ({ status: 200, body: { tastings: allTastings() } }));
    renderApp('/');

    const cards = await screen.findAllByRole('article');
    expect(cards).toHaveLength(3);

    const riesling = within(cards[0]);
    expect(riesling.getByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    expect(riesling.getByText(/6 November 2026/)).toHaveTextContent(/Friday.*18:00/);
    expect(riesling.getByText(/EUR 25/)).toBeInTheDocument();
    expect(riesling.getByText('12 seats left')).toBeInTheDocument();

    expect(within(cards[1]).getByText(/14 November 2026/)).toHaveTextContent(/15:00/);
    expect(within(cards[1]).getByText(/EUR 32/)).toBeInTheDocument();
    expect(within(cards[1]).getByText('8 seats left')).toBeInTheDocument();
    expect(within(cards[2]).getByText(/EUR 28/)).toBeInTheDocument();
    expect(within(cards[2]).getByText('10 seats left')).toBeInTheDocument();
  });

  it('has a "Book <title>" link per tasting that leads to its booking form', async () => {
    fakeServer(() => ({ status: 200, body: { tastings: allTastings() } }));
    renderApp('/');
    const link = await screen.findByRole('link', { name: 'Book Red Wine Cellar Tour' });
    expect(link).toHaveAttribute('href', '/book/red-wine-cellar-tour');
    expect(screen.getByRole('link', { name: 'Book Riesling Evening' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Book Winter Tasting' })).toBeInTheDocument();
  });

  it('marks a tasting without seats as fully booked and still says 0 seats left', async () => {
    fakeServer(() => ({
      status: 200,
      body: { tastings: [tasting({ seatsLeft: 0 }), ...allTastings().slice(1)] },
    }));
    renderApp('/');
    const [full, open] = await screen.findAllByRole('article');
    expect(within(full).getByText('Fully booked')).toBeInTheDocument();
    expect(within(full).getByText('0 seats left')).toBeInTheDocument();
    expect(within(open).queryByText('Fully booked')).not.toBeInTheDocument();
  });

  it('always uses the "<n> seats left" wording, as the brief specifies', async () => {
    fakeServer(() => ({ status: 200, body: { tastings: [tasting({ seatsLeft: 1 })] } }));
    renderApp('/');
    expect(await screen.findByText('1 seats left')).toBeInTheDocument();
  });

  it('shows a loading state, then an error with a retry when the server cannot be reached', async () => {
    fakeServer(() => 'network-error');
    renderApp('/');
    expect(screen.getByText(/loading/i)).toBeInTheDocument();
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not load/i);
    expect(screen.getByRole('button', { name: 'Try again' })).toBeInTheDocument();
  });
});
