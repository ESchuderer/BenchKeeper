import type { ReactNode } from 'react';

export function Spinner({ label = 'Loading…' }: { label?: string }) {
  return (
    <p role="status" className="flex items-center gap-3 py-10 text-ink-soft">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-line border-t-wine-700" aria-hidden="true" />
      {label}
    </p>
  );
}

export function ErrorBanner({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded-xl border-2 border-alert-700/40 bg-alert-100 px-4 py-3 text-alert-700">
      <p className="font-semibold">{children}</p>
      {action}
    </div>
  );
}

export function FieldError({ id, children }: { id: string; children: ReactNode }) {
  return (
    <p id={id} className="field-error">
      <svg viewBox="0 0 20 20" className="mt-0.5 h-4 w-4 shrink-0" fill="currentColor" aria-hidden="true">
        <path d="M10 1.500a8.500 8.500 0 1 0 0 17 8.500 8.500 0 0 0 0-17zM9.100 5.500h1.800v6H9.100v-6zm0 7.500h1.800v1.800H9.100V13z" />
      </svg>
      <span>{children}</span>
    </p>
  );
}
