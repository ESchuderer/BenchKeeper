import type { ReactNode } from 'react';
import { Link } from 'react-router';

function GrapeMark() {
  return (
    <svg viewBox="0 0 32 32" aria-hidden="true" className="h-9 w-9 shrink-0">
      <circle cx="16" cy="16" r="16" fill="#6e1f35" />
      <path d="M16 6c0 3-1.5 4.5-4 5 1.5 1.5 3.500 1.500 4-1 .5 2.500 2.500 2.500 4 1-2.500-.5-4-2-4-5z" fill="#b8893b" />
      {[[12, 15], [16, 15], [20, 15], [14, 19], [18, 19], [16, 23]].map(([cx, cy]) => (
        <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r="2.200" fill="#faf5ec" opacity="0.92" />
      ))}
    </svg>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b-4 border-gold bg-wine-800 text-cream">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <Link to="/" className="flex items-center gap-3 rounded-lg focus-visible:outline-gold">
            <GrapeMark />
            <span className="leading-tight">
              <span className="block font-serif text-xl font-semibold tracking-wide sm:text-2xl">Weingut Kieselbrunnen</span>
              <span className="block text-xs uppercase tracking-[0.2em] text-gold-soft">Family winery</span>
            </span>
          </Link>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">{children}</main>
      <footer className="border-t border-line bg-parchment">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-5 text-sm text-ink-soft sm:px-6">
          <span>© Weingut Kieselbrunnen</span>
          <Link to="/staff" className="underline decoration-line underline-offset-4 hover:text-wine-700">
            Staff
          </Link>
        </div>
      </footer>
    </div>
  );
}
