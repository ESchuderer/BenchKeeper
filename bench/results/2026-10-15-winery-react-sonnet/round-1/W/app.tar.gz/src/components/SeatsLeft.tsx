import { seatsLeftText } from '../../shared/format';
import type { Tasting } from '../../shared/types';

/** Seats-left text plus, when there are none, a clear "Fully booked" marker. */
export function SeatsLeft({ tasting }: { tasting: Tasting }) {
  const { seatsLeft } = tasting;
  const tone =
    seatsLeft === 0
      ? 'bg-alert-100 text-alert-700'
      : seatsLeft <= 3
        ? 'bg-amber-100 text-amber-800'
        : 'bg-leaf-100 text-leaf-700';
  return (
    <span className="inline-flex flex-wrap items-center gap-2">
      {seatsLeft === 0 && (
        <span className="badge bg-wine-800 text-cream">Fully booked</span>
      )}
      <span className={`badge ${tone}`}>{seatsLeftText(seatsLeft)}</span>
    </span>
  );
}
