import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router';
import { useForm, type Resolver } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { bookingInputSchema, MAX_GUESTS_PER_BOOKING, type BookingInput } from '../../shared/booking-schema';
import { formatPrice, formatStart } from '../../shared/format';
import type { Booking, Tasting } from '../../shared/types';
import { createBooking, getTasting, NetworkError, NotFoundError, ValidationError } from '../api';
import { ErrorBanner, FieldError, Spinner } from '../components/Feedback';
import { SeatsLeft } from '../components/SeatsLeft';

const resolver = zodResolver(bookingInputSchema) as unknown as Resolver<BookingInput>;

function Field({
  id,
  label,
  error,
  hint,
  children,
}: {
  id: string;
  label: string;
  error?: string;
  hint?: string;
  children: (describedBy: string | undefined) => React.ReactNode;
}) {
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  return (
    <div>
      <label htmlFor={id} className="field-label">
        {label}
      </label>
      {children(error ? errorId : hint ? hintId : undefined)}
      {error ? (
        <FieldError id={errorId}>{error}</FieldError>
      ) : (
        hint && (
          <p id={hintId} className="field-hint">
            {hint}
          </p>
        )
      )}
    </div>
  );
}

function TastingSummary({ tasting }: { tasting: Tasting }) {
  return (
    <section className="card h-fit p-6 lg:sticky lg:top-6">
      <h1 className="text-3xl font-semibold">{tasting.title}</h1>
      <p className="mt-3">
        <time dateTime={tasting.startsAt}>{formatStart(tasting.startsAt)}</time>
      </p>
      <p className="mt-1 text-ink-soft">
        <span className="font-semibold text-ink">{formatPrice(tasting.priceCents)}</span> per guest
      </p>
      <div className="mt-4">
        <SeatsLeft tasting={tasting} />
      </div>
      {tasting.seatsLeft === 0 && (
        <p className="mt-4 text-sm text-ink-soft">
          Every seat is taken. If seats become free again you can book them here.
        </p>
      )}
    </section>
  );
}

function Confirmation({ booking, tasting }: { booking: Booking; tasting: Tasting }) {
  const rows: { term: string; value: string; mono?: boolean }[] = [
    { term: 'Tasting', value: tasting.title },
    { term: 'Date and time', value: formatStart(tasting.startsAt) },
    { term: 'Guests', value: String(booking.guests) },
    { term: 'Total price', value: formatPrice(booking.totalCents) },
    { term: 'Booking reference', value: booking.reference, mono: true },
  ];
  return (
    <section className="card mx-auto max-w-xl overflow-hidden">
      <div className="bg-leaf-100 px-6 py-6 text-leaf-700">
        <p className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider">
          <svg viewBox="0 0 20 20" className="h-5 w-5" fill="currentColor" aria-hidden="true">
            <path d="M10 1.500a8.500 8.500 0 1 0 0 17 8.500 8.500 0 0 0 0-17zm-1.200 12.200L5.300 10.200l1.300-1.300 2.200 2.200 4.600-4.600 1.300 1.300-5.900 5.900z" />
          </svg>
          Success
        </p>
        <h1 className="mt-1 text-3xl font-semibold !text-leaf-700">Booking confirmed</h1>
        <p className="mt-2 text-ink">Thank you, {booking.name}. We look forward to welcoming you.</p>
      </div>
      <dl className="divide-y divide-line px-6">
        {rows.map(({ term, value, mono }) => (
          <div key={term} className="flex flex-wrap justify-between gap-x-6 gap-y-1 py-3.5">
            <dt className="text-ink-soft">{term}</dt>
            <dd className={`font-semibold ${mono ? 'font-mono text-lg tracking-wider' : ''}`}>{value}</dd>
          </div>
        ))}
      </dl>
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 pb-6 pt-2">
        <p className="text-sm text-ink-soft">Please keep your reference for the day of the tasting.</p>
        <Link to="/" className="btn-secondary">
          All tastings
        </Link>
      </div>
    </section>
  );
}

export function BookingPage() {
  const { id = '' } = useParams();
  const [tasting, setTasting] = useState<Tasting>();
  const [loadState, setLoadState] = useState<'loading' | 'ready' | 'not-found' | 'error'>('loading');
  const [confirmed, setConfirmed] = useState<Booking>();
  const [formError, setFormError] = useState<string>();
  const inFlight = useRef(false);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver,
    defaultValues: { name: '', email: '', guests: 2 },
  });

  useEffect(() => {
    let current = true;
    setLoadState('loading');
    getTasting(id).then(
      (t) => current && (setTasting(t), setLoadState('ready')),
      (e) => current && setLoadState(e instanceof NotFoundError ? 'not-found' : 'error'),
    );
    return () => {
      current = false;
    };
  }, [id]);

  if (loadState === 'loading') return <Spinner />;
  if (loadState === 'error') {
    return <ErrorBanner>Could not load this tasting. Please check your connection and reload the page.</ErrorBanner>;
  }
  if (loadState === 'not-found' || !tasting) {
    return (
      <section className="card mx-auto max-w-xl p-8 text-center">
        <h1 className="text-3xl font-semibold">Tasting not found</h1>
        <p className="mt-3 text-ink-soft">We could not find the tasting you are looking for.</p>
        <Link to="/" className="btn-primary mt-6">
          All tastings
        </Link>
      </section>
    );
  }
  if (confirmed) return <Confirmation booking={confirmed} tasting={tasting} />;

  const onSubmit = async (values: BookingInput) => {
    if (inFlight.current) return;
    inFlight.current = true;
    setFormError(undefined);
    try {
      const result = await createBooking(tasting.id, values);
      setTasting(result.tasting);
      setConfirmed(result.booking);
    } catch (e) {
      if (e instanceof ValidationError) {
        if (e.tasting) setTasting(e.tasting);
        for (const [field, message] of Object.entries(e.errors)) {
          setError(field as keyof BookingInput, { type: 'server', message });
        }
      } else if (e instanceof NetworkError) {
        setFormError('Could not reach the server. Please check your connection and try again.');
      } else {
        setFormError('Something went wrong. Please try again.');
      }
    } finally {
      inFlight.current = false;
    }
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
      <TastingSummary tasting={tasting} />
      <form onSubmit={handleSubmit(onSubmit)} noValidate className="card space-y-5 p-6">
        <h2 className="text-2xl font-semibold">Book your seats</h2>
        {formError && <ErrorBanner>{formError}</ErrorBanner>}

        <Field id="name" label="Name" error={errors.name?.message}>
          {(describedBy) => (
            <input
              id="name"
              type="text"
              autoComplete="name"
              className="field-input"
              aria-invalid={!!errors.name}
              aria-describedby={describedBy}
              {...register('name')}
            />
          )}
        </Field>

        <Field id="email" label="Email" error={errors.email?.message}>
          {(describedBy) => (
            <input
              id="email"
              type="email"
              autoComplete="email"
              inputMode="email"
              className="field-input"
              aria-invalid={!!errors.email}
              aria-describedby={describedBy}
              {...register('email')}
            />
          )}
        </Field>

        <Field
          id="guests"
          label="Guests"
          error={errors.guests?.message}
          hint={`From 1 to ${MAX_GUESTS_PER_BOOKING} guests per booking.`}
        >
          {(describedBy) => (
            <input
              id="guests"
              type="number"
              inputMode="numeric"
              min={1}
              max={MAX_GUESTS_PER_BOOKING}
              className="field-input sm:max-w-40"
              aria-invalid={!!errors.guests}
              aria-describedby={describedBy}
              {...register('guests', { valueAsNumber: true })}
            />
          )}
        </Field>

        <button type="submit" className="btn-primary w-full sm:w-auto" disabled={isSubmitting}>
          {isSubmitting ? 'Booking…' : 'Book'}
        </button>
      </form>
    </div>
  );
}
