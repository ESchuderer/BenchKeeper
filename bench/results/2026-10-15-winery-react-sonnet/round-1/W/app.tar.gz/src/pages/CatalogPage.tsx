import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router';
import { formatPrice, formatStart } from '../../shared/format';
import type { Tasting } from '../../shared/types';
import { getTastings } from '../api';
import { ErrorBanner, Spinner } from '../components/Feedback';
import { SeatsLeft } from '../components/SeatsLeft';

function TastingCard({ tasting }: { tasting: Tasting }) {
  const full = tasting.seatsLeft === 0;
  return (
    <article className={`card flex flex-col p-6 ${full ? 'bg-parchment/60' : ''}`}>
      <h2 className="text-2xl font-semibold">{tasting.title}</h2>
      <p className="mt-3 text-ink">
        <time dateTime={tasting.startsAt}>{formatStart(tasting.startsAt)}</time>
      </p>
      <p className="mt-1 text-ink-soft">
        <span className="font-semibold text-ink">{formatPrice(tasting.priceCents)}</span> per guest
      </p>
      <div className="mt-4">
        <SeatsLeft tasting={tasting} />
      </div>
      <div className="mt-auto pt-6">
        <Link to={`/book/${tasting.id}`} className={`w-full ${full ? 'btn-secondary' : 'btn-primary'}`}>
          Book {tasting.title}
          <span aria-hidden="true" className="ml-2">→</span>
        </Link>
      </div>
    </article>
  );
}

export function CatalogPage() {
  const [tastings, setTastings] = useState<Tasting[]>();
  const [failed, setFailed] = useState(false);

  const load = useCallback(() => {
    setFailed(false);
    getTastings().then(setTastings, () => setFailed(true));
  }, []);
  useEffect(load, [load]);

  return (
    <>
      <section className="mb-10 max-w-2xl">
        <h1 className="text-4xl font-semibold sm:text-5xl">Wine tastings</h1>
        <p className="mt-4 text-lg text-ink-soft">
          Join us in the cellars of our family winery. Pick a tasting, reserve your seats and we will take care of the
          rest.
        </p>
      </section>

      {failed ? (
        <ErrorBanner
          action={
            <button type="button" className="btn-quiet" onClick={load}>
              Try again
            </button>
          }
        >
          Could not load the tastings. Please check your connection.
        </ErrorBanner>
      ) : !tastings ? (
        <Spinner label="Loading tastings…" />
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {tastings.map((t) => (
            <TastingCard key={t.id} tasting={t} />
          ))}
        </div>
      )}
    </>
  );
}
