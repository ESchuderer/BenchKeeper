import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { formatStart } from '../../shared/format';
import {
  cancelBooking,
  getStaffBookings,
  signIn,
  signOut,
  UnauthorizedError,
  ValidationError,
} from '../api';
import type { BookingGroup } from '../../shared/types';
import { ErrorBanner, FieldError, Spinner } from '../components/Feedback';

function SignInForm({ onSignedIn }: { onSignedIn: () => void }) {
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<{ password: string }>({ defaultValues: { password: '' } });

  const onSubmit = async ({ password }: { password: string }) => {
    if (!password) return setError('password', { message: 'Enter the password.' });
    try {
      await signIn(password);
      onSignedIn();
    } catch (e) {
      const message = e instanceof ValidationError ? e.errors.password : undefined;
      setError('password', { message: message ?? 'Could not sign in. Please try again.' });
    }
  };

  const error = errors.password?.message;
  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="card mx-auto max-w-md space-y-5 p-6 sm:p-8">
      <h1 className="text-3xl font-semibold">Staff sign-in</h1>
      <p className="text-ink-soft">Bookings are only visible to the winery team.</p>
      <div>
        <label htmlFor="password" className="field-label">
          Password
        </label>
        <input
          id="password"
          type="password"
          autoComplete="current-password"
          className="field-input"
          aria-invalid={!!error}
          aria-describedby={error ? 'password-error' : undefined}
          {...register('password')}
        />
        {error && <FieldError id="password-error">{error}</FieldError>}
      </div>
      <button type="submit" className="btn-primary w-full" disabled={isSubmitting}>
        Sign in
      </button>
    </form>
  );
}

function BookingsOverview({
  groups,
  cancelling,
  error,
  onCancel,
  onSignOut,
}: {
  groups: BookingGroup[];
  cancelling?: string;
  error?: string;
  onCancel: (reference: string) => void;
  onSignOut: () => void;
}) {
  return (
    <>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-4xl font-semibold">Bookings</h1>
        <button type="button" className="btn-quiet" onClick={onSignOut}>
          Sign out
        </button>
      </div>
      {error && (
        <div className="mb-6">
          <ErrorBanner>{error}</ErrorBanner>
        </div>
      )}
      <div className="space-y-8">
        {groups.map(({ tasting, bookings }) => (
          <section key={tasting.id} aria-labelledby={`group-${tasting.id}`} className="card overflow-hidden">
            <header className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b border-line bg-parchment px-5 py-4">
              <div>
                <h2 id={`group-${tasting.id}`} className="text-2xl font-semibold">
                  {tasting.title}
                </h2>
                <p className="text-sm text-ink-soft">{formatStart(tasting.startsAt)}</p>
              </div>
              <p className="text-sm font-semibold text-wine-800">
                {tasting.capacity - tasting.seatsLeft} of {tasting.capacity} seats booked
              </p>
            </header>
            {bookings.length === 0 ? (
              <p className="px-5 py-6 text-ink-soft">No bookings yet.</p>
            ) : (
              <ul className="divide-y divide-line">
                {bookings.map((b) => (
                  <li key={b.reference} className="flex flex-wrap items-center justify-between gap-x-6 gap-y-3 px-5 py-4">
                    <div className="min-w-0">
                      <p className="font-semibold">{b.name}</p>
                      <p className="break-all text-sm text-ink-soft">{b.email}</p>
                    </div>
                    <p className="text-sm">
                      <span className="text-ink-soft">Guests </span>
                      <span className="font-semibold">{b.guests}</span>
                    </p>
                    <p className="font-mono text-sm tracking-wider">{b.reference}</p>
                    <button
                      type="button"
                      className="btn-danger"
                      disabled={cancelling === b.reference}
                      onClick={() => onCancel(b.reference)}
                    >
                      Cancel
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </div>
    </>
  );
}

export function StaffPage() {
  const [state, setState] = useState<'checking' | 'signed-out' | 'signed-in' | 'error'>('checking');
  const [groups, setGroups] = useState<BookingGroup[]>([]);
  const [cancelling, setCancelling] = useState<string>();
  const [actionError, setActionError] = useState<string>();

  const load = useCallback(async () => {
    try {
      setGroups(await getStaffBookings());
      setState('signed-in');
    } catch (e) {
      setState(e instanceof UnauthorizedError ? 'signed-out' : 'error');
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  const cancel = async (reference: string) => {
    setCancelling(reference);
    setActionError(undefined);
    try {
      await cancelBooking(reference);
      setGroups(await getStaffBookings());
    } catch (e) {
      if (e instanceof UnauthorizedError) setState('signed-out');
      else setActionError('Could not cancel the booking. Please check your connection and try again.');
    } finally {
      setCancelling(undefined);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    setGroups([]);
    setState('signed-out');
  };

  if (state === 'checking') return <Spinner />;
  if (state === 'error') {
    return (
      <ErrorBanner
        action={
          <button type="button" className="btn-quiet" onClick={() => void load()}>
            Try again
          </button>
        }
      >
        Could not load the bookings. Please check your connection.
      </ErrorBanner>
    );
  }
  if (state === 'signed-out') return <SignInForm onSignedIn={() => void load()} />;
  return <BookingsOverview groups={groups} cancelling={cancelling} error={actionError} onCancel={cancel} onSignOut={() => void handleSignOut()} />;
}
