import { afterEach, describe, expect, it, vi } from 'vitest';
import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { allTastings, fakeServer, renderApp } from './test-utils';
import type { Booking } from '../shared/types';

afterEach(() => vi.unstubAllGlobals());

const booking = (over: Partial<Booking>): Booking => ({
  reference: 'KB-AAAAAA',
  tastingId: 'riesling-evening',
  name: 'Anna Weber',
  email: 'anna@example.com',
  guests: 2,
  totalCents: 5000,
  ...over,
});

/** A tiny stand-in for the staff API with a password and a mutable list of bookings. */
function staffServer(initial: Booking[], { signedIn = false, password = 'secret' } = {}) {
  let bookings = [...initial];
  let session = signedIn;
  const requests = fakeServer((req) => {
    if (req.path === '/api/staff/login') {
      if (req.body.password !== password) return { status: 401, body: { errors: { password: 'Incorrect password.' } } };
      session = true;
      return { status: 204 };
    }
    if (req.path === '/api/staff/logout') {
      session = false;
      return { status: 204 };
    }
    if (!session) return { status: 401, body: { error: 'Please sign in.' } };
    if (req.path === '/api/staff/bookings' && req.method === 'GET') {
      const groups = allTastings().map((tasting) => {
        const mine = bookings.filter((b) => b.tastingId === tasting.id);
        return { tasting: { ...tasting, seatsLeft: tasting.capacity - mine.reduce((n, b) => n + b.guests, 0) }, bookings: mine };
      });
      return { status: 200, body: { groups } };
    }
    if (req.method === 'DELETE') {
      const ref = req.path.split('/').pop();
      const before = bookings.length;
      bookings = bookings.filter((b) => b.reference !== ref);
      return { status: bookings.length < before ? 204 : 404 };
    }
  });
  return requests;
}

const two = [
  booking({}),
  booking({ reference: 'KB-BBBBBB', name: 'Ben Fischer', email: 'ben@example.com', guests: 3 }),
  booking({ reference: 'KB-CCCCCC', tastingId: 'winter-tasting', name: 'Clara Vogt', email: 'clara@example.com', guests: 4 }),
];

describe('staff sign-in', () => {
  it('asks for a password first and shows no bookings', async () => {
    staffServer(two);
    renderApp('/staff');
    expect(await screen.findByLabelText('Password')).toHaveAttribute('type', 'password');
    expect(screen.getByRole('button', { name: 'Sign in' })).toBeInTheDocument();
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument();
  });

  it('shows an error next to the password field for a wrong password', async () => {
    staffServer(two);
    renderApp('/staff');
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Password'), 'wrong');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription('Incorrect password.');
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument();
  });

  it('asks for a password when the field is left empty', async () => {
    const requests = staffServer(two);
    renderApp('/staff');
    const user = userEvent.setup();
    await screen.findByLabelText('Password');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByLabelText('Password')).toHaveAccessibleDescription(/enter the password/i);
    expect(requests.filter((r) => r.path.endsWith('/login'))).toHaveLength(0);
  });

  it('shows the bookings after signing in with the right password', async () => {
    staffServer(two);
    renderApp('/staff');
    const user = userEvent.setup();
    await user.type(await screen.findByLabelText('Password'), 'secret');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));
    expect(await screen.findByText('Anna Weber')).toBeInTheDocument();
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument();
  });

  it('goes straight to the bookings when a session already exists', async () => {
    staffServer(two, { signedIn: true });
    renderApp('/staff');
    expect(await screen.findByText('Anna Weber')).toBeInTheDocument();
  });

  it('signs out and shows the sign-in form again', async () => {
    staffServer(two, { signedIn: true });
    renderApp('/staff');
    const user = userEvent.setup();
    await user.click(await screen.findByRole('button', { name: 'Sign out' }));
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
    expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument();
  });
});

describe('staff bookings overview', () => {
  it('groups bookings by tasting with name, email, guests and reference', async () => {
    staffServer(two, { signedIn: true });
    renderApp('/staff');
    const groups = await screen.findAllByRole('region');
    expect(groups).toHaveLength(3);

    const riesling = within(groups[0]);
    expect(riesling.getByRole('heading', { name: 'Riesling Evening' })).toBeInTheDocument();
    const rows = riesling.getAllByRole('listitem');
    expect(rows).toHaveLength(2);
    expect(within(rows[0]).getByText('Anna Weber')).toBeInTheDocument();
    expect(within(rows[0]).getByText('anna@example.com')).toBeInTheDocument();
    expect(within(rows[0]).getByText('KB-AAAAAA')).toBeInTheDocument();
    expect(within(rows[1]).getByText('Ben Fischer')).toBeInTheDocument();
    expect(riesling.getByText(/5 of 12 seats booked/)).toBeInTheDocument();

    expect(within(groups[2]).getByText('Clara Vogt')).toBeInTheDocument();
    expect(within(groups[2]).queryByText('Anna Weber')).not.toBeInTheDocument();
  });

  it('shows an empty-state message for a tasting without bookings', async () => {
    staffServer(two, { signedIn: true });
    renderApp('/staff');
    const groups = await screen.findAllByRole('region');
    expect(within(groups[1]).getByText(/no bookings yet/i)).toBeInTheDocument();
    expect(within(groups[1]).queryByRole('button', { name: 'Cancel' })).not.toBeInTheDocument();
  });

  it('cancels a booking: it disappears and its seats are freed', async () => {
    staffServer(two, { signedIn: true });
    renderApp('/staff');
    const user = userEvent.setup();
    const [riesling] = await screen.findAllByRole('region');
    const row = within(riesling).getAllByRole('listitem')[0];
    await user.click(within(row).getByRole('button', { name: 'Cancel' }));

    await vi.waitFor(() => expect(screen.queryByText('Anna Weber')).not.toBeInTheDocument());
    expect(screen.getByText('Ben Fischer')).toBeInTheDocument();
    expect(screen.getByText(/3 of 12 seats booked/)).toBeInTheDocument();
  });

  it('shows an error and keeps the booking when cancelling fails', async () => {
    const requests = staffServer(two, { signedIn: true });
    renderApp('/staff');
    const user = userEvent.setup();
    const [riesling] = await screen.findAllByRole('region');
    const original = globalThis.fetch;
    vi.stubGlobal('fetch', (input: RequestInfo | URL, init?: RequestInit) =>
      init?.method === 'DELETE' ? Promise.reject(new TypeError('offline')) : original(input, init),
    );
    await user.click(within(riesling).getAllByRole('button', { name: 'Cancel' })[0]);
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not cancel/i);
    expect(screen.getByText('Anna Weber')).toBeInTheDocument();
    expect(requests.length).toBeGreaterThan(0);
  });

  it('returns to the sign-in form when the session has expired while cancelling', async () => {
    staffServer(two, { signedIn: true });
    renderApp('/staff');
    const user = userEvent.setup();
    const [riesling] = await screen.findAllByRole('region');
    const original = globalThis.fetch;
    vi.stubGlobal('fetch', (input: RequestInfo | URL, init?: RequestInit) =>
      init?.method === 'DELETE'
        ? Promise.resolve(new Response('{}', { status: 401 }))
        : original(input, init),
    );
    await user.click(within(riesling).getAllByRole('button', { name: 'Cancel' })[0]);
    expect(await screen.findByLabelText('Password')).toBeInTheDocument();
  });
});
