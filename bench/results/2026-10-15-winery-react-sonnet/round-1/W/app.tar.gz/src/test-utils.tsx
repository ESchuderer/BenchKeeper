import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { vi } from 'vitest';
import { App } from './App';
import type { Tasting } from '../shared/types';

export type FakeResponse = { status: number; body?: unknown } | 'network-error';
export type FakeHandler = (req: { method: string; path: string; body: any }) => FakeResponse | undefined;

export const tasting = (overrides: Partial<Tasting> = {}): Tasting => ({
  id: 'riesling-evening',
  title: 'Riesling Evening',
  startsAt: '2026-11-06T18:00',
  priceCents: 2500,
  capacity: 12,
  seatsLeft: 12,
  ...overrides,
});

export const allTastings = (): Tasting[] => [
  tasting(),
  tasting({ id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceCents: 3200, capacity: 8, seatsLeft: 8 }),
  tasting({ id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceCents: 2800, capacity: 10, seatsLeft: 10 }),
];

/** Replaces `fetch` with a fake server; records every request it receives. */
export function fakeServer(handler: FakeHandler) {
  const requests: { method: string; path: string; body: any }[] = [];
  vi.stubGlobal(
    'fetch',
    vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const req = {
        method: init?.method ?? 'GET',
        path: String(input),
        body: init?.body ? JSON.parse(String(init.body)) : undefined,
      };
      requests.push(req);
      const res = handler(req);
      if (res === 'network-error') throw new TypeError('Failed to fetch');
      const { status, body } = res ?? { status: 404, body: { error: 'Not found.' } };
      return new Response(status === 204 ? null : JSON.stringify(body ?? {}), {
        status,
        headers: { 'Content-Type': 'application/json' },
      });
    }),
  );
  return requests;
}

export function renderApp(path: string) {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <App />
    </MemoryRouter>,
  );
}
