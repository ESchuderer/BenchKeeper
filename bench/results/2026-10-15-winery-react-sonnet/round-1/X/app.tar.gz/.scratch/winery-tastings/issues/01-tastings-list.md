Status: resolved

# Tastings list
Seed data, store, `GET /api/tastings`, start page with title, date and time, price, "<n> seats left", Book link.
