Status: resolved
Blocked by: 01

# Guest booking
Booking endpoint with validation and seat limit, form with field errors, confirmation (heading, tasting, guests, total, reference).
