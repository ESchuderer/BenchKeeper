Status: resolved
Blocked by: 01

# Staff sign-in
Login, logout, session expiry, failed-attempt limit, cookie flags, `/staff` login form.
