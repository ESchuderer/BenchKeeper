Status: resolved
Blocked by: 02, 03

# Staff bookings and cancel
Bookings grouped by tasting, Cancel button, seats freed.
