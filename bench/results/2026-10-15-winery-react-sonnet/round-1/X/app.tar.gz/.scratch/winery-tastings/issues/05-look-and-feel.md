Status: resolved
Blocked by: 02, 04

# Look and feel
Winery styling, error/success/fully-booked states, phone layout; verified in a browser at 375px and desktop.
