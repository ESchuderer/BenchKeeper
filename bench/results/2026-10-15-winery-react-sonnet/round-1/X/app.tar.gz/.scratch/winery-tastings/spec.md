# Winery tastings booking

Guests book tastings at Weingut Kieselbrunnen online; staff see and cancel bookings.

## Stack
- Server: Node 22, Express 5, zod (input validation), express-session (staff session), express-rate-limit (failed sign-ins), helmet (headers).
- Client: React 19, React Router, Vite, plain CSS.
- Tests: Vitest + supertest (API), browser check with Playwright MCP.
- Storage: in memory (see `docs/adr/0001-in-memory-bookings.md`).

## Behaviour
- Tastings are fixed seed data (title, date and time, price per guest in EUR, seats).
- `GET /api/tastings`: tastings with `seatsLeft`.
- `POST /api/tastings/:id/bookings` `{name, email, guests}`: 201 with booking, 400 `{errors:{field:msg}}` for invalid input, 409 `{errors:{guests:msg}}` when guests exceed seats left, 404 unknown tasting.
- Booking never takes more seats than left; checked and applied synchronously in one step.
- Staff: `POST /api/staff/login`, `POST /api/staff/logout`, `GET /api/staff/bookings`, `DELETE /api/staff/bookings/:reference`. Cancel removes the booking, which frees its seats.
- Pages: `/` list, `/book/:id` form and confirmation, `/staff`.

## Sign-in requirements
- Password from `STAFF_PASSWORD`; unset means nobody can sign in.
- Constant-time comparison, session regenerated on sign-in.
- Session expires after 8 hours, sign-out destroys it.
- 5 failed attempts per IP per 15 minutes, then 429.
- Cookie: HttpOnly, SameSite=Strict, Secure when the request is HTTPS (`TRUST_PROXY=1` behind a TLS proxy).

## Assumptions (no one to ask)
- "<n> seats left" is printed literally, also for 1. A fully booked tasting shows a "Fully booked" badge and "0 seats left"; its Book link stays so the form reports the error next to Guests.
- Cancel has no confirmation dialog.
- Booking reference: `KB-` plus 6 characters.
- Guest cannot look up or change a booking after the confirmation page.
- Names up to 100 characters; email must be syntactically valid.
