# Glossary

- **Tasting**: a scheduled wine tasting event with a date and time, a price per guest and a fixed number of seats.
- **Booking**: one guest party's reservation for a tasting: name, email, number of guests.
- **Guests**: the number of people in a booking (1 to 8). Each guest takes one seat.
- **Seats left**: tasting seats minus the guests of its bookings.
- **Booking reference**: the code (`KB-XXXXXX`) shown on the confirmation and in the staff list; identifies a booking.
- **Staff**: winery employees who sign in at `/staff` to see and cancel bookings.
