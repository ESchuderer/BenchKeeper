# Weingut Kieselbrunnen tastings

Guests book wine tastings at `/`; staff see and cancel bookings at `/staff`.

```
npm install
npm run build
STAFF_PASSWORD=<password> PORT=3000 npm start
```

- `STAFF_PASSWORD`: staff password. Unset means nobody can sign in.
- `PORT`: default 3000.
- `TRUST_PROXY=1`: set behind a TLS-terminating proxy so the session cookie gets `Secure` and failed sign-ins are counted per client IP.
- `npm test`: API tests. `npm run dev`: Vite dev server (proxies `/api` to port 3000).
- Bookings are kept in memory and are lost on restart (`docs/adr/0001-in-memory-bookings.md`).
