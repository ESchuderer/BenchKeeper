# 0001 Bookings are kept in memory

Bookings live in a process-local array. Restarting the server clears them, which the task allows ("starts with no bookings"). Seat checks and writes run in one synchronous step, so concurrent requests cannot overbook. Replace `server/store.js` with a database when bookings must survive restarts or run on more than one process.
