import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'
import express from 'express'
import session from 'express-session'
import { rateLimit } from 'express-rate-limit'
import helmet from 'helmet'
import { z } from 'zod'
import { createStore } from './store.js'

const bookingSchema = z.object({
  name: z.string('Enter your name.').trim().min(1, 'Enter your name.').max(100, 'Name must be 100 characters or fewer.'),
  email: z.string('Enter a valid email address.').trim().max(254, 'Enter a valid email address.').pipe(z.email('Enter a valid email address.')),
  // Only numbers and numeric strings count; z.coerce would also turn true or [2] into a number.
  guests: z.preprocess(
    (v) => (typeof v === 'string' && v.trim() !== '' ? Number(v) : v),
    z.number('Choose 1 to 8 guests.').int('Choose 1 to 8 guests.').min(1, 'Choose 1 to 8 guests.').max(8, 'Choose 1 to 8 guests.'),
  ),
})

const sha256 = (s) => createHash('sha256').update(s).digest()

export function createApp({ staffPassword, sessionMaxAgeMs = 8 * 60 * 60 * 1000, trustProxy, staticDir } = {}) {
  const store = createStore()
  const app = express()
  if (trustProxy) app.set('trust proxy', trustProxy)

  // upgrade-insecure-requests would break the app when it is served over plain HTTP on a LAN address.
  app.use(helmet({ contentSecurityPolicy: { directives: { 'upgrade-insecure-requests': null } } }))
  app.use(express.json({ limit: '10kb' }))
  app.use(
    session({
      name: 'kb.sid',
      // shortcut: sessions live in memory and end on restart, move to a persistent store with more than one process.
      secret: randomBytes(32).toString('hex'),
      resave: false,
      saveUninitialized: false,
      cookie: { httpOnly: true, sameSite: 'strict', secure: 'auto', maxAge: sessionMaxAgeMs },
    }),
  )

  const passwordMatches = (given) => Boolean(staffPassword) && typeof given === 'string' && timingSafeEqual(sha256(given), sha256(staffPassword))
  // express-session extends the stored session on every request, so the 8 hours are checked here from the sign-in time.
  const requireStaff = (req, res, next) => {
    if (req.session.staffSince && Date.now() - req.session.staffSince < sessionMaxAgeMs) return next()
    res.status(401).json({ error: 'Sign in required.' })
  }
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Too many failed attempts. Try again in 15 minutes.' },
  })

  app.get('/api/tastings', (req, res) => res.json(store.listTastings()))

  app.post('/api/tastings/:id/bookings', (req, res) => {
    const parsed = bookingSchema.safeParse(req.body ?? {})
    if (!parsed.success) {
      const errors = {}
      for (const issue of parsed.error.issues) errors[issue.path[0]] ??= issue.message
      return res.status(400).json({ errors })
    }
    const result = store.book(req.params.id, parsed.data)
    if (result.notFound) return res.status(404).json({ error: 'Tasting not found.' })
    if (result.errors) return res.status(409).json({ errors: result.errors })
    res.status(201).json(result.booking)
  })

  app.post('/api/staff/login', loginLimiter, (req, res, next) => {
    if (!passwordMatches(req.body?.password)) return res.status(401).json({ error: 'Wrong password.' })
    req.session.regenerate((err) => {
      if (err) return next(err)
      req.session.staffSince = Date.now()
      res.status(204).end()
    })
  })

  app.post('/api/staff/logout', (req, res, next) => {
    req.session.destroy((err) => {
      if (err) return next(err)
      res.clearCookie('kb.sid').status(204).end()
    })
  })

  app.get('/api/staff/bookings', requireStaff, (req, res) => res.json(store.listByTasting()))

  app.delete('/api/staff/bookings/:reference', requireStaff, (req, res) => res.status(store.cancel(req.params.reference) ? 204 : 404).end())

  if (staticDir) {
    app.use(express.static(staticDir))
    // Client-side routes (/, /book/:id, /staff) all serve the app shell.
    app.use((req, res, next) => (req.method === 'GET' && !req.path.startsWith('/api/') ? res.sendFile('index.html', { root: staticDir }) : next()))
  }

  app.use((err, req, res, next) => {
    if (err.status && err.status < 500) return res.status(err.status).json({ error: 'Invalid request.' })
    console.error(err)
    res.status(500).json({ error: 'Something went wrong.' })
  })

  return app
}
