import { describe, it, expect } from 'vitest'
import request from 'supertest'
import { createApp } from './app.js'

const newApp = (opts = {}) => createApp({ staffPassword: 'secret', ...opts })

describe('tastings', () => {
  it('lists the three tastings with seats left', async () => {
    const res = await request(newApp()).get('/api/tastings')
    expect(res.status).toBe(200)
    expect(res.body.map((t) => [t.id, t.title, t.startsAt, t.priceEur, t.seatsLeft])).toEqual([
      ['riesling-evening', 'Riesling Evening', '2026-11-06T18:00', 25, 12],
      ['red-wine-cellar-tour', 'Red Wine Cellar Tour', '2026-11-14T15:00', 32, 8],
      ['winter-tasting', 'Winter Tasting', '2026-12-05T17:00', 28, 10],
    ])
  })
})

const book = (app, id, body) => request(app).post(`/api/tastings/${id}/bookings`).send(body)
const ok = { name: 'Anna Weber', email: 'anna@example.com', guests: 2 }
const seatsLeft = async (app, id) => (await request(app).get('/api/tastings')).body.find((t) => t.id === id).seatsLeft

describe('booking', () => {
  it('confirms a booking, computes the total and reduces seats left', async () => {
    const app = newApp()
    const res = await book(app, 'riesling-evening', ok)
    expect(res.status).toBe(201)
    expect(res.body).toMatchObject({ tastingId: 'riesling-evening', guests: 2, totalEur: 50, name: 'Anna Weber' })
    expect(res.body.reference).toMatch(/^KB-[A-Z2-9]{6}$/)
    expect(await seatsLeft(app, 'riesling-evening')).toBe(10)
  })

  it('gives each booking its own reference', async () => {
    const app = newApp()
    const a = await book(app, 'riesling-evening', ok)
    const b = await book(app, 'riesling-evening', ok)
    expect(a.body.reference).not.toBe(b.body.reference)
  })

  it.each([
    ['name', { ...ok, name: '   ' }],
    ['name', { ...ok, name: 'x'.repeat(101) }],
    ['email', { ...ok, email: 'not-an-email' }],
    ['email', { ...ok, email: '' }],
    ['guests', { ...ok, guests: 0 }],
    ['guests', { ...ok, guests: 9 }],
    ['guests', { ...ok, guests: 1.5 }],
    ['guests', { ...ok, guests: 'abc' }],
    ['guests', { ...ok, guests: '' }],
    ['guests', { ...ok, guests: true }],
    ['guests', { ...ok, guests: [2] }],
    ['guests', { name: ok.name, email: ok.email }],
  ])('rejects invalid %s with a field error', async (field, body) => {
    const app = newApp()
    const res = await book(app, 'riesling-evening', body)
    expect(res.status).toBe(400)
    expect(Object.keys(res.body.errors)).toEqual([field])
    expect(res.body.errors[field]).toEqual(expect.any(String))
    expect(await seatsLeft(app, 'riesling-evening')).toBe(12)
  })

  it('reports every invalid field at once', async () => {
    const res = await book(newApp(), 'riesling-evening', { name: '', email: 'x', guests: 0 })
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name'])
  })

  it('accepts guests sent as a numeric string', async () => {
    const res = await book(newApp(), 'riesling-evening', { ...ok, guests: '3' })
    expect(res.status).toBe(201)
    expect(res.body.guests).toBe(3)
  })

  it('never takes more seats than are left', async () => {
    const app = newApp()
    expect((await book(app, 'red-wine-cellar-tour', { ...ok, guests: 6 })).status).toBe(201)
    const over = await book(app, 'red-wine-cellar-tour', { ...ok, guests: 3 })
    expect(over.status).toBe(409)
    expect(over.body.errors.guests).toMatch(/2 seats left/)
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(2)
    expect((await book(app, 'red-wine-cellar-tour', { ...ok, guests: 2 })).status).toBe(201)
    const full = await book(app, 'red-wine-cellar-tour', { ...ok, guests: 1 })
    expect(full.status).toBe(409)
    expect(full.body.errors.guests).toMatch(/fully booked/i)
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(0)
  })

  it('does not overbook under concurrent requests', async () => {
    const app = newApp()
    const results = await Promise.all(Array.from({ length: 10 }, () => book(app, 'red-wine-cellar-tour', { ...ok, guests: 3 })))
    expect(results.filter((r) => r.status === 201)).toHaveLength(2)
    expect(await seatsLeft(app, 'red-wine-cellar-tour')).toBe(2)
  })

  it('returns 404 for an unknown tasting and 400 for malformed JSON', async () => {
    const app = newApp()
    expect((await book(app, 'nope', ok)).status).toBe(404)
    const bad = await request(app).post('/api/tastings/riesling-evening/bookings').set('Content-Type', 'application/json').send('{oops')
    expect(bad.status).toBe(400)
  })
})

const signIn = (agent, password = 'secret') => agent.post('/api/staff/login').send({ password })

describe('staff', () => {
  it('rejects bookings access without a session', async () => {
    const app = newApp()
    expect((await request(app).get('/api/staff/bookings')).status).toBe(401)
    expect((await request(app).delete('/api/staff/bookings/KB-AAAAAA')).status).toBe(401)
  })

  it('rejects a wrong password and sets no session', async () => {
    const agent = request.agent(newApp())
    const res = await signIn(agent, 'wrong')
    expect(res.status).toBe(401)
    expect(res.headers['set-cookie']).toBeUndefined()
    expect((await agent.get('/api/staff/bookings')).status).toBe(401)
  })

  it('rejects every password when STAFF_PASSWORD is not set', async () => {
    const agent = request.agent(createApp({ staffPassword: undefined }))
    expect((await signIn(agent, '')).status).toBe(401)
    expect((await signIn(agent, 'undefined')).status).toBe(401)
  })

  it('sets an HttpOnly, SameSite=Strict cookie on sign-in', async () => {
    const res = await signIn(request(newApp()))
    expect(res.status).toBe(204)
    const cookie = res.headers['set-cookie'][0]
    expect(cookie).toMatch(/HttpOnly/)
    expect(cookie).toMatch(/SameSite=Strict/)
    expect(cookie).toMatch(/Expires=/)
    expect(cookie).not.toMatch(/Secure/)
  })

  it('sets the Secure flag when the request is HTTPS behind a trusted proxy', async () => {
    const res = await request(createApp({ staffPassword: 'secret', trustProxy: 1 })).post('/api/staff/login').set('X-Forwarded-Proto', 'https').send({ password: 'secret' })
    expect(res.headers['set-cookie'][0]).toMatch(/Secure/)
  })

  it('lists bookings grouped by tasting and cancels one, freeing its seats', async () => {
    const app = newApp()
    const a = (await book(app, 'riesling-evening', ok)).body
    const b = (await book(app, 'riesling-evening', { ...ok, name: 'Ben Roth', guests: 3 })).body
    await book(app, 'winter-tasting', { ...ok, guests: 1 })
    const agent = request.agent(app)
    await signIn(agent)

    const list = await agent.get('/api/staff/bookings')
    expect(list.status).toBe(200)
    expect(list.body.map((g) => [g.id, g.bookings.length])).toEqual([['riesling-evening', 2], ['red-wine-cellar-tour', 0], ['winter-tasting', 1]])
    expect(list.body[0].bookings[0]).toEqual(expect.objectContaining({ name: 'Anna Weber', email: 'anna@example.com', guests: 2, reference: a.reference }))
    expect(await seatsLeft(app, 'riesling-evening')).toBe(7)

    expect((await agent.delete(`/api/staff/bookings/${b.reference}`)).status).toBe(204)
    expect(await seatsLeft(app, 'riesling-evening')).toBe(10)
    expect((await agent.delete(`/api/staff/bookings/${b.reference}`)).status).toBe(404)
    expect((await agent.get('/api/staff/bookings')).body[0].bookings).toHaveLength(1)
  })

  it('does not expose bookings on the public tastings list', async () => {
    const app = newApp()
    await book(app, 'riesling-evening', ok)
    expect(JSON.stringify((await request(app).get('/api/tastings')).body)).not.toContain('anna@example.com')
  })

  it('ends the session on sign-out', async () => {
    const agent = request.agent(newApp())
    await signIn(agent)
    expect((await agent.get('/api/staff/bookings')).status).toBe(200)
    expect((await agent.post('/api/staff/logout')).status).toBe(204)
    expect((await agent.get('/api/staff/bookings')).status).toBe(401)
  })

  it('expires the session on the server even when the cookie is replayed', async () => {
    const app = createApp({ staffPassword: 'secret', sessionMaxAgeMs: 1000 })
    const cookie = (await signIn(request(app))).headers['set-cookie'][0].split(';')[0]
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(200)
    await new Promise((r) => setTimeout(r, 600))
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(200)
    await new Promise((r) => setTimeout(r, 600))
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401)
  })

  it('limits failed sign-ins and then refuses even the right password', async () => {
    const agent = request.agent(newApp())
    for (let i = 0; i < 5; i++) expect((await signIn(agent, 'wrong')).status).toBe(401)
    const blocked = await signIn(agent, 'wrong')
    expect(blocked.status).toBe(429)
    expect(blocked.body.error).toEqual(expect.any(String))
    expect((await signIn(agent)).status).toBe(429)
  })

  it('does not count successful sign-ins against the limit', async () => {
    const agent = request.agent(newApp())
    for (let i = 0; i < 8; i++) expect((await signIn(agent)).status).toBe(204)
  })
})
