import { fileURLToPath } from 'node:url'
import { createApp } from './app.js'

const staffPassword = process.env.STAFF_PASSWORD
if (!staffPassword) console.warn('STAFF_PASSWORD is not set: nobody can sign in at /staff.')

const app = createApp({
  staffPassword,
  trustProxy: Number(process.env.TRUST_PROXY) || undefined,
  staticDir: fileURLToPath(new URL('../dist', import.meta.url)),
})
const port = Number(process.env.PORT) || 3000
app.listen(port, () => console.log(`Listening on http://localhost:${port}`))
