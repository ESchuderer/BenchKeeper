import { randomInt } from 'node:crypto'

const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', startsAt: '2026-11-06T18:00', priceEur: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', startsAt: '2026-11-14T15:00', priceEur: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', startsAt: '2026-12-05T17:00', priceEur: 28, seats: 10 },
]

// No 0/O or 1/I, so references can be read out over the phone.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

export function createStore() {
  const bookings = []
  const seatsLeft = (t) => t.seats - bookings.filter((b) => b.tastingId === t.id).reduce((n, b) => n + b.guests, 0)
  const withSeats = (t) => ({ ...t, seatsLeft: seatsLeft(t) })

  const newReference = () => {
    const ref = () => 'KB-' + Array.from({ length: 6 }, () => ALPHABET[randomInt(ALPHABET.length)]).join('')
    let r = ref()
    while (bookings.some((b) => b.reference === r)) r = ref()
    return r
  }

  return {
    listTastings: () => TASTINGS.map(withSeats),

    // Check and write in one synchronous step so concurrent requests cannot overbook.
    book(tastingId, { name, email, guests }) {
      const tasting = TASTINGS.find((t) => t.id === tastingId)
      if (!tasting) return { notFound: true }
      const left = seatsLeft(tasting)
      if (guests > left) {
        const message = left === 0 ? 'This tasting is fully booked.' : `Only ${left} seats left for this tasting.`
        return { errors: { guests: message } }
      }
      const booking = { reference: newReference(), tastingId, name, email, guests, totalEur: guests * tasting.priceEur }
      bookings.push(booking)
      return { booking }
    },

    listByTasting: () => TASTINGS.map((t) => ({ ...t, bookings: bookings.filter((b) => b.tastingId === t.id), seatsLeft: seatsLeft(t) })),

    cancel(reference) {
      const i = bookings.findIndex((b) => b.reference === reference)
      if (i === -1) return false
      bookings.splice(i, 1)
      return true
    },
  }
}
