import { Link, Route, Routes } from 'react-router-dom'
import Tastings from './pages/Tastings.jsx'
import Booking from './pages/Booking.jsx'
import Staff from './pages/Staff.jsx'

export default function App() {
  return (
    <>
      <header className="site-header">
        <div className="wrap">
          <Link to="/" className="brand">
            Weingut Kieselbrunnen
            <span>Family winery</span>
          </Link>
        </div>
      </header>
      <main className="wrap">
        <Routes>
          <Route path="/" element={<Tastings />} />
          <Route path="/book/:id" element={<Booking />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <div className="wrap">
          <span>Weingut Kieselbrunnen</span>
          <Link to="/staff">Staff</Link>
        </div>
      </footer>
    </>
  )
}

function NotFound() {
  return (
    <section>
      <h1>Page not found</h1>
      <p>
        <Link to="/">See our tastings</Link>
      </p>
    </section>
  )
}
