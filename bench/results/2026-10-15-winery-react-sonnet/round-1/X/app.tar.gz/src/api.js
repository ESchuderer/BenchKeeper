// Resolves with { status, data } for every HTTP response; rejects only when the network fails.
export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await res.json().catch(() => null)
  return { status: res.status, data }
}

export const formatEur = (n) => `EUR ${n}`
export const formatStart = (startsAt) => startsAt.replace('T', ' ')
export const weekday = (startsAt) => new Date(`${startsAt}Z`).toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' })
