import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { api, formatEur, formatStart, weekday } from '../api.js'

export default function Booking() {
  const { id } = useParams()
  const [tasting, setTasting] = useState(undefined) // undefined: loading, null: unknown
  const [fields, setFields] = useState({ name: '', email: '', guests: '1' })
  const [errors, setErrors] = useState({})
  const [formError, setFormError] = useState('')
  const [busy, setBusy] = useState(false)
  const [booking, setBooking] = useState(null)

  useEffect(() => {
    api('/api/tastings')
      .then(({ data }) => setTasting(data?.find((t) => t.id === id) ?? null))
      .catch(() => setTasting(null))
  }, [id])

  if (tasting === undefined) return <p className="muted">Loading...</p>
  if (tasting === null)
    return (
      <section>
        <h1>Tasting not found</h1>
        <p>
          <Link to="/">See our tastings</Link>
        </p>
      </section>
    )

  if (booking)
    return (
      <section className="panel panel-success">
        <h1>Booking confirmed</h1>
        <p className="lead">Thank you, {booking.name}. Your seats are reserved. Please keep your booking reference.</p>
        <dl className="summary">
          <dt>Tasting</dt>
          <dd>
            {tasting.title}, {formatStart(tasting.startsAt)}
          </dd>
          <dt>Guests</dt>
          <dd>{booking.guests}</dd>
          <dt>Total price</dt>
          <dd>{formatEur(booking.totalEur)}</dd>
          <dt>Booking reference</dt>
          <dd className="reference">{booking.reference}</dd>
        </dl>
        <Link to="/" className="button button-quiet">
          Back to tastings
        </Link>
      </section>
    )

  const set = (field) => (e) => setFields({ ...fields, [field]: e.target.value })

  async function submit(e) {
    e.preventDefault()
    setBusy(true)
    setErrors({})
    setFormError('')
    try {
      const { status, data } = await api(`/api/tastings/${id}/bookings`, { method: 'POST', body: fields })
      if (status === 201) setBooking(data)
      else if (data?.errors) setErrors(data.errors)
      else setFormError('The booking could not be made. Please try again.')
      // Seats may have changed, so show the current count after a refusal.
      if (status !== 201) api('/api/tastings')
          .then(({ data }) => data && setTasting(data.find((t) => t.id === id) ?? null))
          .catch(() => {})
    } catch {
      setFormError('The server could not be reached. Please try again.')
    }
    setBusy(false)
  }

  const field = (name, label, props) => (
    <div className={`field${errors[name] ? ' field-invalid' : ''}`}>
      <label htmlFor={name}>{label}</label>
      <input id={name} name={name} value={fields[name]} onChange={set(name)} aria-invalid={Boolean(errors[name])} aria-describedby={errors[name] ? `${name}-error` : undefined} {...props} />
      {errors[name] && (
        <p className="field-error" id={`${name}-error`}>
          {errors[name]}
        </p>
      )}
    </div>
  )

  return (
    <section>
      <p>
        <Link to="/">&larr; All tastings</Link>
      </p>
      <p className="eyebrow">{weekday(tasting.startsAt)}</p>
      <h1>{tasting.title}</h1>
      <p className="lead">
        <time dateTime={tasting.startsAt}>{formatStart(tasting.startsAt)}</time> &middot; {formatEur(tasting.priceEur)} per guest
      </p>
      <p className="seats">
        {tasting.seatsLeft === 0 && <span className="badge">Fully booked</span>}
        <span>{tasting.seatsLeft} seats left</span>
      </p>
      {tasting.seatsLeft === 0 && <p className="notice notice-error">This tasting is fully booked. Please choose another date.</p>}
      <form className="panel" onSubmit={submit} noValidate>
        {formError && (
          <p className="notice notice-error" role="alert">
            {formError}
          </p>
        )}
        {field('name', 'Name', { type: 'text', autoComplete: 'name' })}
        {field('email', 'Email', { type: 'email', autoComplete: 'email' })}
        {field('guests', 'Guests', { type: 'number', min: 1, max: 8, inputMode: 'numeric' })}
        <button type="submit" className="button" disabled={busy}>
          Book
        </button>
      </form>
    </section>
  )
}
