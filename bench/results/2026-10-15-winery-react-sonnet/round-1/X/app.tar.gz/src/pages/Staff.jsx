import { useEffect, useState } from 'react'
import { api, formatStart } from '../api.js'

export default function Staff() {
  const [groups, setGroups] = useState(undefined) // undefined: loading, null: signed out
  const [failed, setFailed] = useState('')

  const load = () =>
    api('/api/staff/bookings')
      .then(({ status, data }) => {
        if (status === 200) setGroups(data)
        else if (status === 401) setGroups(null)
        else setFailed('The bookings could not be loaded.')
      })
      .catch(() => setFailed('The server could not be reached.'))

  useEffect(() => {
    load()
  }, [])

  if (failed) return <p className="notice notice-error" role="alert">{failed}</p>
  if (groups === undefined) return <p className="muted">Loading...</p>
  if (groups === null) return <SignIn onSignedIn={load} />
  return <Bookings groups={groups} reload={load} onSignedOut={() => setGroups(null)} />
}

function SignIn({ onSignedIn }) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setBusy(true)
    setError('')
    try {
      const { status, data } = await api('/api/staff/login', { method: 'POST', body: { password } })
      if (status === 204) return onSignedIn()
      setError(data?.error ?? 'Sign-in failed.')
    } catch {
      setError('The server could not be reached.')
    }
    setBusy(false)
  }

  return (
    <section>
      <h1>Staff</h1>
      <p className="lead">Sign in to see and manage bookings.</p>
      <form className="panel narrow" onSubmit={submit} noValidate>
        <div className={`field${error ? ' field-invalid' : ''}`}>
          <label htmlFor="password">Password</label>
          <input id="password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} aria-invalid={Boolean(error)} aria-describedby={error ? 'password-error' : undefined} />
          {error && (
            <p className="field-error" id="password-error">
              {error}
            </p>
          )}
        </div>
        <button type="submit" className="button" disabled={busy}>
          Sign in
        </button>
      </form>
    </section>
  )
}

function Bookings({ groups, reload, onSignedOut }) {
  const [error, setError] = useState('')

  async function cancel(reference) {
    setError('')
    try {
      const { status } = await api(`/api/staff/bookings/${reference}`, { method: 'DELETE' })
      if (status === 401) return onSignedOut()
      if (status !== 204 && status !== 404) setError('The booking could not be cancelled.')
    } catch {
      setError('The server could not be reached.')
    }
    reload()
  }

  async function signOut() {
    await api('/api/staff/logout', { method: 'POST' }).catch(() => {})
    onSignedOut()
  }

  return (
    <section>
      <div className="bar">
        <h1>Bookings</h1>
        <button type="button" className="button button-quiet" onClick={signOut}>
          Sign out
        </button>
      </div>
      {error && <p className="notice notice-error" role="alert">{error}</p>}
      {groups.map((t) => (
        <article key={t.id} className="panel group">
          <h2>{t.title}</h2>
          <p className="muted">
            {formatStart(t.startsAt)} &middot; {t.seats - t.seatsLeft} of {t.seats} seats booked
          </p>
          {t.bookings.length === 0 ? (
            <p className="muted">No bookings yet.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Guests</th>
                  <th>Reference</th>
                  <th>
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {t.bookings.map((b) => (
                  <tr key={b.reference}>
                    <td data-label="Name">{b.name}</td>
                    <td data-label="Email">{b.email}</td>
                    <td data-label="Guests">{b.guests}</td>
                    <td data-label="Reference" className="reference">{b.reference}</td>
                    <td>
                      <button type="button" className="button button-danger" onClick={() => cancel(b.reference)}>
                        Cancel
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </article>
      ))}
    </section>
  )
}
