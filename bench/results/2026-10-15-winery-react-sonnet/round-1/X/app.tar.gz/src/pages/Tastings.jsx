import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api, formatEur, formatStart, weekday } from '../api.js'

export default function Tastings() {
  const [tastings, setTastings] = useState(null)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    api('/api/tastings')
      .then(({ status, data }) => (status === 200 ? setTastings(data) : setFailed(true)))
      .catch(() => setFailed(true))
  }, [])

  return (
    <section>
      <h1>Wine tastings</h1>
      <p className="lead">Spend an evening at the winery. Choose a tasting and reserve your seats. Prices are per guest.</p>
      {failed && <p className="notice notice-error" role="alert">The tastings could not be loaded. Please reload the page.</p>}
      {!tastings && !failed && <p className="muted">Loading tastings...</p>}
      {tastings && (
        <ul className="cards">
          {tastings.map((t) => (
            <li key={t.id} className={`card${t.seatsLeft === 0 ? ' card-full' : ''}`}>
              <p className="eyebrow">{weekday(t.startsAt)}</p>
              <h2>{t.title}</h2>
              <p className="when">
                <time dateTime={t.startsAt}>{formatStart(t.startsAt)}</time>
              </p>
              <p className="price">{formatEur(t.priceEur)} per guest</p>
              <p className="seats">
                {t.seatsLeft === 0 && <span className="badge">Fully booked</span>}
                <span>{t.seatsLeft} seats left</span>
              </p>
              <Link to={`/book/${t.id}`} className={`button${t.seatsLeft === 0 ? ' button-quiet' : ''}`}>
                Book {t.title}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
