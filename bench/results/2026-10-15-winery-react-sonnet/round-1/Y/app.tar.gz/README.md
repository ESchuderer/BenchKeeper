# Weingut Kieselbrunnen: tasting bookings

Guests book wine tastings at `/`; staff see and cancel bookings at `/staff`.

```
npm install
npm run build
STAFF_PASSWORD=<password> npm start   # PORT defaults to 3000
```

- `STAFF_PASSWORD`: staff password. Without it, staff sign-in is refused.
- `PORT`: listen port (default 3000).
- Bookings are kept in memory and are lost on restart.
- `npm test`: API tests. `npm run test:e2e`: builds, then runs browser tests; set `CHROMIUM_PATH` to use an installed Chromium.
- Behind a reverse proxy, set `trust proxy` in `server/app.js` so the sign-in attempt limit sees client IPs.
