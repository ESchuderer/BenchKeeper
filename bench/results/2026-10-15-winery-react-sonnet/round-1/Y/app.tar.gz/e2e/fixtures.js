import { test as base, expect } from '@playwright/test';
import { createApp } from '../server/app.js';

export const PASSWORD = 'e2e-secret';

// Every test gets its own app instance, so bookings and sign-in limits never leak between tests.
export const test = base.extend({
  baseURL: async ({}, use) => {
    const server = createApp({ staffPassword: PASSWORD }).listen(0);
    await use(`http://localhost:${server.address().port}`);
    server.close();
  },
});
export { expect };
