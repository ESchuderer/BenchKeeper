import { test, expect } from './fixtures.js';

test('lists the tastings', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Riesling Evening' })).toBeVisible();
  await expect(page.getByText('EUR 25')).toBeVisible();
  await expect(page.getByText('18:00')).toBeVisible();
  await expect(page.getByText('12 seats left')).toBeVisible();
  await expect(page.getByText('8 seats left')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Book Winter Tasting' })).toBeVisible();
});

test('shows field errors and books with confirmation', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('link', { name: 'Book Riesling Evening' }).click();
  await page.getByLabel('Name').fill('');
  await page.getByLabel('Email').fill('not-an-email');
  await page.getByLabel('Guests').fill('9');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Name')).toHaveAccessibleDescription(/Enter your name/);
  await expect(page.getByLabel('Email')).toHaveAccessibleDescription(/valid email/);
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/At most 8/);

  await page.getByLabel('Name').fill('Anna Berg');
  await page.getByLabel('Email').fill('anna@example.com');
  await page.getByLabel('Guests').fill('3');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();
  await expect(page.getByText('Riesling Evening')).toBeVisible();
  await expect(page.getByText('EUR 75')).toBeVisible();
  await expect(page.getByText(/KB-[A-Z0-9]{6}/)).toBeVisible();

  await page.getByRole('link', { name: 'Back to tastings' }).click();
  await expect(page.getByText('9 seats left', { exact: true })).toBeVisible();
});

test('refuses more guests than seats left and shows fully booked', async ({ page }) => {
  const fill = async (guests) => {
    await page.getByLabel('Name').fill('Max');
    await page.getByLabel('Email').fill('max@example.com');
    await page.getByLabel('Guests').fill(String(guests));
    await page.getByRole('button', { name: 'Book', exact: true }).click();
  };
  await page.goto('/');
  await page.getByRole('link', { name: 'Book Red Wine Cellar Tour' }).click();
  await fill(8);
  await expect(page.getByRole('heading', { name: 'Booking confirmed' })).toBeVisible();

  await page.goto('/');
  await expect(page.getByText('0 seats left', { exact: true })).toBeVisible();
  await expect(page.getByText('Fully booked')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Book Red Wine Cellar Tour' })).toHaveCount(0);

  await page.goto('/book/red-wine-cellar-tour');
  await expect(page.getByText(/fully booked/i)).toBeVisible();
  await expect(page.getByRole('button', { name: 'Book', exact: true })).toHaveCount(0);
});

test('server rejects guests above seats left next to the field', async ({ page, request }) => {
  await request.post('/api/bookings', {
    data: { tastingId: 'winter-tasting', name: 'A', email: 'a@example.com', guests: 7 },
  });
  await page.goto('/book/winter-tasting');
  await page.getByLabel('Name').fill('Max');
  await page.getByLabel('Email').fill('max@example.com');
  await page.getByLabel('Guests').fill('4');
  await page.getByRole('button', { name: 'Book', exact: true }).click();
  await expect(page.getByLabel('Guests')).toHaveAccessibleDescription(/Only 3 seats left/);
});

test('is usable on a phone', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 700 });
  await page.goto('/');
  await expect(page.getByRole('link', { name: 'Book Winter Tasting' })).toBeVisible();
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow).toBeLessThanOrEqual(0);
});
