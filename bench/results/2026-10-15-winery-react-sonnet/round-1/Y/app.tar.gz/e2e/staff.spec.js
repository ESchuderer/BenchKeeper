import { test, expect, PASSWORD } from './fixtures.js';

test('rejects a wrong password next to the field', async ({ page }) => {
  await page.goto('/staff');
  await page.getByLabel('Password').fill('nope');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByLabel('Password')).toHaveAccessibleDescription(/Incorrect password/);
  await expect(page.getByRole('button', { name: 'Sign out' })).toHaveCount(0);
});

test('lists bookings grouped by tasting, cancels and signs out', async ({ page, request }) => {
  const { reference } = await (
    await request.post('/api/bookings', {
      data: { tastingId: 'winter-tasting', name: 'Greta Wein', email: 'greta@example.com', guests: 4 },
    })
  ).json();

  await page.goto('/staff');
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();

  const section = page.getByRole('region', { name: 'Winter Tasting' });
  const row = section.getByRole('row', { name: /Greta Wein/ });
  await expect(row).toContainText('greta@example.com');
  await expect(row).toContainText(reference);
  await expect(page.getByRole('region', { name: 'Riesling Evening' })).toContainText('No bookings yet');

  await row.getByRole('button', { name: 'Cancel' }).click();
  await expect(section.getByText('Greta Wein')).toHaveCount(0);
  await page.goto('/');
  await expect(page.getByText('10 seats left', { exact: true })).toBeVisible();

  await page.goto('/staff');
  await page.getByRole('button', { name: 'Sign out' }).click();
  await expect(page.getByLabel('Password')).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Password')).toBeVisible();
});
