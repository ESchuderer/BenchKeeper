# Design

## Context

Greenfield repository, Node.js 22, npm. Data is three fixed tastings and bookings in memory (see proposal.md).

## Goals / Non-Goals

**Goals:**
- One process serves the API and the built React app on `PORT`.
- Seat limit holds under concurrent requests.

**Non-Goals:**
- Persistence, payments, email, admin editing of tastings, per-user staff accounts, past-date handling, i18n.

## Decisions

- **Express 5 + Vite + React 19 + React Router.** Established, maintained; Vite builds to `dist/`, Express serves it with an SPA fallback. Alternative: Next.js, heavier than needed.
- **Validation with zod, shared by client and server** (`shared/booking.js`); client uses react-hook-form with the zod resolver, server revalidates and returns `{ errors: { field: message } }` which the form maps to fields. Seat-limit errors come from the server as a `guests` error.
- **Seat check and insert in one synchronous function** on the in-memory store. Node runs it without interleaving, so no overbooking. A database would need a transaction.
- **Booking reference:** `KB-` plus 6 characters from an unambiguous alphabet, regenerated on collision.
- **Staff session:** random 32-byte token in a server-side Map with expiry (2 h), cookie `HttpOnly; SameSite=Strict; Secure` when `req.secure` or `x-forwarded-proto: https`. Password compared as SHA-256 digests with `timingSafeEqual`. Failed attempts limited by `express-rate-limit` (5 per 15 min per IP, successful logins not counted). Unset `STAFF_PASSWORD` rejects every login. SameSite=Strict plus JSON-only mutations covers CSRF.
- **Seats text** follows the spec literally ("1 seats left" for one seat).
- **Confirmation** is passed through router state; a reload returns to the start page. Confirmation does not echo name or email.
- **Cancel** has no confirm dialog; a cancelled booking is deleted, not kept.
- **Styling:** plain CSS with custom properties, system serif/sans stacks (no external fonts), mobile-first.

## Risks / Trade-offs

- Restart loses bookings and sessions -> accepted by the brief.
- Rate limit keyed on IP; behind a reverse proxy all clients may share one IP -> set `trust proxy` when deployed behind one.
- No CSP/HSTS headers set -> add helmet when served on a public domain.
