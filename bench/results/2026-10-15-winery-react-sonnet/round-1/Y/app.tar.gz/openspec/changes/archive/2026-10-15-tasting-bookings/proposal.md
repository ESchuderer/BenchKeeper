# Proposal

## Why

Weingut Kieselbrunnen takes tasting bookings by hand. Guests need to book seats online, and staff need one place to see and cancel bookings. No issue exists: the project has no remote tracker, so this change is the spec of record.

## What Changes

- New web app: React front end, Node.js server, bookings kept in memory.
- Guests list three fixed tastings, book seats, and get a confirmation with a booking reference.
- Staff sign in with a password from `STAFF_PASSWORD`, see bookings grouped by tasting, and cancel bookings.
- Winery-styled, responsive interface in English.

## Capabilities

### New Capabilities
- `tasting-booking`: tasting list with seats left, booking form, validation, seat limit, confirmation.
- `staff-bookings`: password sign-in with session handling, bookings grouped by tasting, cancellation that frees seats.

### Modified Capabilities

## Impact

- New code: `server/`, `shared/`, `src/`, `tests/`, `e2e/`, build config.
- Dependencies: express, react, react-router, react-hook-form, zod, vite, express-rate-limit, cookie-parser; dev: vitest, supertest, Playwright.
- Environment: `STAFF_PASSWORD`, `PORT` (default 3000).
