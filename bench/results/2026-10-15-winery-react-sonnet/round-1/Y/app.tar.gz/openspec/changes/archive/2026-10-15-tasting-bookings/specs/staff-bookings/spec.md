# Spec Delta

## Purpose

Lets winery staff sign in with a shared password, review bookings grouped by tasting, and cancel bookings to free their seats.

## ADDED Requirements

### Requirement: Staff sign-in
The page `/staff` SHALL show a "Password" field and a "Sign in" button to visitors without a valid session. The correct password is the value of the environment variable `STAFF_PASSWORD`. If the variable is unset or empty, no password SHALL be accepted.

#### Scenario: Correct password
- **WHEN** a visitor submits the value of `STAFF_PASSWORD`
- **THEN** the bookings view is shown

#### Scenario: Wrong password
- **WHEN** a visitor submits another password
- **THEN** an error is shown next to the "Password" field and no bookings are shown

#### Scenario: Unauthenticated data access
- **WHEN** a request for staff booking data or cancellation carries no valid session
- **THEN** it is refused with status 401 and no booking data is returned

### Requirement: Session handling
A staff session SHALL expire after a fixed time, SHALL end on sign-out, and SHALL be held in a cookie marked HttpOnly and SameSite, and Secure when served over HTTPS.

#### Scenario: Sign out
- **WHEN** a signed-in staff member presses "Sign out"
- **THEN** the sign-in form is shown and the former session no longer grants access

#### Scenario: Session expiry
- **WHEN** a session is older than its lifetime
- **THEN** staff requests with it are refused with status 401

#### Scenario: Cookie attributes
- **WHEN** sign-in succeeds
- **THEN** the session cookie has HttpOnly and SameSite, and Secure when the request used HTTPS

### Requirement: Failed attempt limit
The system SHALL limit failed sign-in attempts per client; after 5 failures in 15 minutes further attempts SHALL be refused with status 429 and a message, even with the correct password.

#### Scenario: Lockout
- **WHEN** a client submits 5 wrong passwords and then the correct one
- **THEN** the last attempt is refused with status 429

### Requirement: Bookings overview
A signed-in staff member SHALL see all bookings grouped by tasting, each with name, email, guests and reference, and a "Cancel" button per booking. Tastings without bookings SHALL be shown with an empty state.

#### Scenario: Grouped list
- **WHEN** bookings exist for two tastings
- **THEN** each tasting lists its own bookings with name, email, guests and reference

### Requirement: Cancellation
Cancelling a booking SHALL remove it from the list and return its seats to the tasting.

#### Scenario: Seats freed
- **WHEN** a booking of 4 guests on a tasting with 8 seats left is cancelled
- **THEN** the booking disappears and the start page shows 12 seats left for a 12-seat tasting
