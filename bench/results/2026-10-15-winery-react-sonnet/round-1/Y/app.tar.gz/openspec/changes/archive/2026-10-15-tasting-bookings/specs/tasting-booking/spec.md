# Spec Delta

## Purpose

Lets guests see the available wine tastings and book seats online, with validation and a confirmation that carries a booking reference.

## ADDED Requirements

### Requirement: Tasting list
The start page SHALL list every tasting with its title, date and time, price per guest, and seats left shown as "<n> seats left". The tastings are Riesling Evening (2026-11-06 18:00, EUR 25, 12 seats), Red Wine Cellar Tour (2026-11-14 15:00, EUR 32, 8 seats) and Winter Tasting (2026-12-05 17:00, EUR 28, 10 seats).

#### Scenario: Initial list
- **WHEN** a guest opens the start page with no bookings
- **THEN** all three tastings are listed with "12 seats left", "8 seats left" and "10 seats left"

#### Scenario: Seats left update
- **WHEN** 3 guests are booked on Riesling Evening
- **THEN** the start page shows "9 seats left" for it

### Requirement: Fully booked tastings
A tasting with no seats left SHALL be marked "Fully booked" and SHALL NOT offer a booking action.

#### Scenario: Last seats taken
- **WHEN** all seats of a tasting are booked
- **THEN** the list shows "0 seats left" and a "Fully booked" marker and no "Book <title>" link for it

#### Scenario: Direct visit to a full tasting
- **WHEN** a guest opens the booking page of a fully booked tasting
- **THEN** a fully booked notice is shown instead of the form

### Requirement: Booking form
Each tasting with seats left SHALL have a link "Book <tasting title>" opening a booking form for that tasting with fields "Name", "Email" and "Guests" (1 to 8) and a button "Book".

#### Scenario: Open the form
- **WHEN** a guest follows "Book Riesling Evening"
- **THEN** the form for Riesling Evening opens with fields "Name", "Email", "Guests" and a "Book" button

### Requirement: Input validation
The system SHALL reject a booking with an empty name, a malformed email, or a guest count that is not a whole number from 1 to 8, and SHALL show the error message next to the field it concerns. Validation SHALL be enforced on the server.

#### Scenario: Invalid fields
- **WHEN** a guest submits an empty name, email "x" and 9 guests
- **THEN** an error is shown next to each of "Name", "Email" and "Guests" and no booking is created

### Requirement: Seat limit
The system SHALL never accept a booking whose guest count exceeds the seats left of the tasting, including under concurrent requests.

#### Scenario: More guests than seats left
- **WHEN** 5 seats are left and a guest books 6
- **THEN** the booking is rejected with an error next to "Guests" and the seats left stay 5

#### Scenario: Exactly the seats left
- **WHEN** 5 seats are left and a guest books 5
- **THEN** the booking is accepted and the tasting is fully booked

### Requirement: Booking confirmation
After a successful booking the guest SHALL see a confirmation with the heading "Booking confirmed", the tasting, the number of guests, the total price (guests times price per guest) and a booking reference unique among bookings.

#### Scenario: Confirmation content
- **WHEN** a guest books 3 guests on Red Wine Cellar Tour
- **THEN** the confirmation shows "Booking confirmed", "Red Wine Cellar Tour", 3 guests, "EUR 96" and a reference
