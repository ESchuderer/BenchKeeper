# Tasks

## 1. Scaffold

- [x] 1.1 Create `package.json` (type module, scripts build/start/test/test:e2e), `.gitignore`, Vite config, install dependencies; verify `npm install` and `npm run build` succeed
- [x] 1.2 Add `README.md` with run instructions and env vars; verify the commands run as written

## 2. Booking domain and API

- [x] 2.1 Write failing API tests (supertest) for tasting list, booking validation, seat limit, exact-fit, reference uniqueness; verify they fail
- [x] 2.2 Implement store, shared zod schema, `GET /api/tastings`, `POST /api/bookings`; verify the tests pass

## 3. Staff API

- [x] 3.1 Write failing tests for login (right, wrong, unset password), 401 without session, expiry, logout, rate limit 429, cookie attributes, list and cancel freeing seats; verify they fail
- [x] 3.2 Implement staff routes and session; verify the tests pass

## 4. Front end

- [x] 4.1 Write failing Playwright tests for the guest flow (list, form, field errors, seat limit, confirmation, fully booked); verify they fail
- [x] 4.2 Implement start page, booking form, confirmation, styling (responsive, error/success/fully-booked states); verify guest tests pass
- [x] 4.3 Write failing Playwright tests for staff flow (sign in, wrong password, grouped list, cancel, sign out); implement `/staff`; verify they pass

## 5. Verify

- [x] 5.1 Run `npm run build`, `npm test`, `npm run test:e2e`; check the app in a browser at desktop and 375 px width via Playwright MCP and take screenshots
