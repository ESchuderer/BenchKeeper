import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: 'e2e',
  use: {
    // Optional: use an installed Chromium instead of the one Playwright downloads.
    launchOptions: { executablePath: process.env.CHROMIUM_PATH || undefined },
  },
});
