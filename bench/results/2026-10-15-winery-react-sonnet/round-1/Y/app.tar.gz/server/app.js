import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import cookieParser from 'cookie-parser';
import { rateLimit } from 'express-rate-limit';
import { bookingSchema, fieldErrors } from '../shared/booking.js';
import { createStore } from './store.js';

const SESSION_MS = 2 * 60 * 60 * 1000;
const COOKIE = 'staff_session';
const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');

const digest = (s) => createHash('sha256').update(s).digest();

export function createApp({ staffPassword, now = Date.now } = {}) {
  const store = createStore();
  const sessions = new Map(); // token -> expiry ms
  const app = express();
  app.disable('x-powered-by');
  // shortcut: no trust proxy, sign-in limit sees the proxy IP behind a reverse proxy, set it on deploy
  app.use(express.json({ limit: '10kb' }), cookieParser());

  const api = express.Router();

  api.get('/tastings', (req, res) => res.json(store.tastings()));

  api.post('/bookings', (req, res) => {
    const { tastingId, ...fields } = req.body ?? {};
    const parsed = bookingSchema.safeParse(fields);
    if (!parsed.success) return res.status(400).json({ errors: fieldErrors(parsed.error) });
    const result = store.book(tastingId, parsed.data);
    if (result.notFound) return res.status(404).json({ error: 'Unknown tasting' });
    if (result.errors) return res.status(400).json({ errors: result.errors });
    const { booking, tasting, total } = result;
    res.status(201).json({
      reference: booking.reference,
      guests: booking.guests,
      total,
      tasting: { id: tasting.id, title: tasting.title, date: tasting.date, time: tasting.time },
    });
  });

  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    skipSuccessfulRequests: true,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many failed attempts. Try again in 15 minutes.' },
  });

  api.post('/staff/login', loginLimiter, (req, res) => {
    const given = typeof req.body?.password === 'string' ? req.body.password : '';
    const ok = Boolean(staffPassword) && timingSafeEqual(digest(given), digest(staffPassword));
    if (!ok) return res.status(401).json({ error: 'Incorrect password' });
    for (const [t, expires] of sessions) if (expires <= now()) sessions.delete(t);
    const token = randomBytes(32).toString('hex');
    sessions.set(token, now() + SESSION_MS);
    res.cookie(COOKIE, token, {
      httpOnly: true,
      sameSite: 'strict',
      secure: req.secure || req.get('x-forwarded-proto') === 'https',
      maxAge: SESSION_MS,
    });
    res.json({ ok: true });
  });

  const staffOnly = (req, res, next) => {
    const token = req.cookies[COOKIE];
    const expires = sessions.get(token);
    if (expires === undefined || expires <= now()) {
      sessions.delete(token);
      return res.status(401).json({ error: 'Not signed in' });
    }
    next();
  };

  api.post('/staff/logout', (req, res) => {
    sessions.delete(req.cookies[COOKIE]);
    res.clearCookie(COOKIE).json({ ok: true });
  });
  api.get('/staff/bookings', staffOnly, (req, res) => res.json(store.byTasting()));
  api.delete('/staff/bookings/:reference', staffOnly, (req, res) =>
    res.sendStatus(store.cancel(req.params.reference) ? 204 : 404),
  );
  api.use((req, res) => res.status(404).json({ error: 'Not found' }));

  app.use('/api', api);
  app.use(express.static(dist));
  app.get('/{*splat}', (req, res) => res.sendFile(path.join(dist, 'index.html')));

  // JSON parse errors and anything unexpected
  app.use((err, req, res, next) => {
    if (res.headersSent) return next(err);
    res.status(err.status ?? 500).json({ error: err.status ? 'Bad request' : 'Server error' });
  });
  return app;
}
