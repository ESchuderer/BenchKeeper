import { existsSync } from 'node:fs';
import { createApp } from './app.js';

const { STAFF_PASSWORD, PORT = 3000 } = process.env;
if (!existsSync(new URL('../dist/index.html', import.meta.url))) console.warn('dist/ is missing: run npm run build first.');
if (!STAFF_PASSWORD) console.warn('STAFF_PASSWORD is not set: staff sign-in is disabled.');

createApp({ staffPassword: STAFF_PASSWORD }).listen(PORT, () => console.log(`Listening on port ${PORT}`));
