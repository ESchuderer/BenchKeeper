import { randomInt } from 'node:crypto';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const TASTINGS = [
  { id: 'riesling-evening', title: 'Riesling Evening', date: '2026-11-06', time: '18:00', price: 25, seats: 12 },
  { id: 'red-wine-cellar-tour', title: 'Red Wine Cellar Tour', date: '2026-11-14', time: '15:00', price: 32, seats: 8 },
  { id: 'winter-tasting', title: 'Winter Tasting', date: '2026-12-05', time: '17:00', price: 28, seats: 10 },
];

export function createStore() {
  const bookings = new Map(); // reference -> booking

  const taken = (tastingId) =>
    [...bookings.values()].filter((b) => b.tastingId === tastingId).reduce((n, b) => n + b.guests, 0);
  const view = (t) => ({ ...t, seatsLeft: t.seats - taken(t.id) });

  function newReference() {
    let ref;
    do ref = 'KB-' + Array.from({ length: 6 }, () => ALPHABET[randomInt(ALPHABET.length)]).join('');
    while (bookings.has(ref));
    return ref;
  }

  return {
    tastings: () => TASTINGS.map(view),
    tasting: (id) => TASTINGS.map(view).find((t) => t.id === id),
    // Synchronous check-and-insert: no await between the seat check and the write.
    book(tastingId, { name, email, guests }) {
      const tasting = TASTINGS.find((t) => t.id === tastingId);
      if (!tasting) return { notFound: true };
      const left = view(tasting).seatsLeft;
      if (guests > left) {
        const message = left === 0 ? 'This tasting is fully booked' : `Only ${left} seats left`;
        return { errors: { guests: message } };
      }
      const booking = { reference: newReference(), tastingId, name, email, guests };
      bookings.set(booking.reference, booking);
      return { booking, tasting: view(tasting), total: guests * tasting.price };
    },
    byTasting: () =>
      TASTINGS.map((t) => ({ ...view(t), bookings: [...bookings.values()].filter((b) => b.tastingId === t.id) })),
    cancel: (reference) => bookings.delete(reference),
  };
}
