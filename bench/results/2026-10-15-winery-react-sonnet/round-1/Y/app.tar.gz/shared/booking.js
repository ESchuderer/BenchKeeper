import { z } from 'zod';

export const MAX_GUESTS = 8;

export const bookingSchema = z.object({
  name: z.string('Enter your name').trim().min(1, 'Enter your name').max(100, 'Name is too long'),
  email: z.string('Enter your email').trim().max(254, 'Email is too long').pipe(z.email('Enter a valid email address')),
  guests: z
    .number(`Enter a whole number from 1 to ${MAX_GUESTS}`)
    .int(`Enter a whole number from 1 to ${MAX_GUESTS}`)
    .min(1, `Enter a whole number from 1 to ${MAX_GUESTS}`)
    .max(MAX_GUESTS, `At most ${MAX_GUESTS} guests per booking`),
});

// First message per field: { name?: string, email?: string, guests?: string }
export function fieldErrors(error) {
  const errors = {};
  for (const issue of error.issues) errors[issue.path[0]] ??= issue.message;
  return errors;
}
