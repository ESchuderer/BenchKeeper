import { Link, Route, Routes } from 'react-router-dom';
import Tastings from './pages/Tastings.jsx';
import Book from './pages/Book.jsx';
import Confirmation from './pages/Confirmation.jsx';
import Staff from './pages/Staff.jsx';

export default function App() {
  return (
    <>
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-name">Weingut Kieselbrunnen</span>
          <span className="brand-tag">Family winery &middot; Tastings</span>
        </Link>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Tastings />} />
          <Route path="/book/:id" element={<Book />} />
          <Route path="/confirmation" element={<Confirmation />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="*" element={<p className="notice">Page not found. <Link to="/">Back to tastings</Link></p>} />
        </Routes>
      </main>
      <footer className="site-footer">Weingut Kieselbrunnen &middot; <Link to="/staff">Staff</Link></footer>
    </>
  );
}
