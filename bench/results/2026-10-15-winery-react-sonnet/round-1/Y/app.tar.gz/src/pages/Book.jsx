import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { bookingSchema, MAX_GUESTS } from '../../shared/booking.js';
import { api, formatWhen } from '../api.js';

function Field({ name, label, error, children }) {
  return (
    <div className={`field${error ? ' invalid' : ''}`}>
      <label htmlFor={name}>{label}</label>
      {children}
      {error && <p id={`${name}-error`} className="field-error">{error.message}</p>}
    </div>
  );
}

export default function Book() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tasting, setTasting] = useState(undefined); // undefined = loading, null = unknown
  const [formError, setFormError] = useState('');
  const {
    register, handleSubmit, setError, formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(bookingSchema), defaultValues: { name: '', email: '', guests: 2 } });

  const [loadFailed, setLoadFailed] = useState(false);
  const load = () =>
    api('GET', '/api/tastings').then(({ status, data }) => {
      if (status !== 200) return setLoadFailed(true);
      setTasting(data.find((t) => t.id === id) ?? null);
    });
  useEffect(() => { load(); }, [id]);

  if (loadFailed && tasting === undefined) return <p className="notice error" role="alert">The tasting could not be loaded. Please try again later.</p>;
  if (tasting === undefined) return <p className="notice">Loading...</p>;
  if (tasting === null) return <p className="notice">Tasting not found. <Link to="/">Back to tastings</Link></p>;
  if (tasting.seatsLeft === 0) {
    return (
      <>
        <h1>{tasting.title}</h1>
        <p className="notice warn">This tasting is fully booked. <Link to="/">Back to tastings</Link></p>
      </>
    );
  }

  async function onSubmit(values) {
    setFormError('');
    const { status, data } = await api('POST', '/api/bookings', { tastingId: id, ...values });
    if (status === 201) return navigate('/confirmation', { state: data });
    if (status === 400 && data?.errors) {
      for (const [field, message] of Object.entries(data.errors)) setError(field, { message });
      if (data.errors.guests) load(); // seats left changed
      return;
    }
    setFormError('Your booking could not be saved. Please try again.');
  }

  const props = (name) => ({
    id: name,
    'aria-invalid': errors[name] ? 'true' : undefined,
    'aria-describedby': errors[name] ? `${name}-error` : undefined,
  });

  return (
    <>
      <h1>Book {tasting.title}</h1>
      <p className="lead">
        {formatWhen(tasting)} &middot; EUR {tasting.price} per guest &middot; {tasting.seatsLeft} seats left
      </p>
      <form className="form" onSubmit={handleSubmit(onSubmit)} noValidate>
        <Field name="name" label="Name" error={errors.name}>
          <input type="text" autoComplete="name" {...props('name')} {...register('name')} />
        </Field>
        <Field name="email" label="Email" error={errors.email}>
          <input type="email" autoComplete="email" {...props('email')} {...register('email')} />
        </Field>
        <Field name="guests" label="Guests" error={errors.guests}>
          <input type="number" inputMode="numeric" min="1" max={MAX_GUESTS} {...props('guests')} {...register('guests', { valueAsNumber: true })} />
        </Field>
        {formError && <p className="notice error" role="alert">{formError}</p>}
        <button className="button" type="submit" disabled={isSubmitting}>Book</button>
        <Link to="/" className="link">Back to tastings</Link>
      </form>
    </>
  );
}
