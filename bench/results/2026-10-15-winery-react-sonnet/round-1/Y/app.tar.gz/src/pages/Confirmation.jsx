import { Link, Navigate, useLocation } from 'react-router-dom';
import { formatWhen } from '../api.js';

export default function Confirmation() {
  const booking = useLocation().state;
  if (!booking) return <Navigate to="/" replace />;
  const { tasting, guests, total, reference } = booking;
  return (
    <section className="notice success" aria-labelledby="confirmed">
      <h1 id="confirmed">Booking confirmed</h1>
      <p>Thank you! We look forward to welcoming you.</p>
      <dl className="summary">
        <dt>Tasting</dt><dd>{tasting.title}</dd>
        <dt>When</dt><dd>{formatWhen(tasting)}</dd>
        <dt>Guests</dt><dd>{guests}</dd>
        <dt>Total price</dt><dd>EUR {total}</dd>
        <dt>Booking reference</dt><dd className="ref">{reference}</dd>
      </dl>
      <Link to="/" className="button">Back to tastings</Link>
    </section>
  );
}
