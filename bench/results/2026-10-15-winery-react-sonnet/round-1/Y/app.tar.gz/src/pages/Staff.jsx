import { useEffect, useState } from 'react';
import { api, formatWhen } from '../api.js';

function SignIn({ onDone }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const { status, data } = await api('POST', '/api/staff/login', { password });
    setBusy(false);
    if (status === 200) return onDone();
    setError(status === 401 || status === 429 ? data.error : 'Sign-in failed. Please try again.');
  }

  return (
    <>
      <h1>Staff</h1>
      <form className="form" onSubmit={submit}>
        <div className={`field${error ? ' invalid' : ''}`}>
          <label htmlFor="password">Password</label>
          <input
            id="password" type="password" autoComplete="current-password" value={password}
            onChange={(e) => setPassword(e.target.value)}
            aria-invalid={error ? 'true' : undefined} aria-describedby={error ? 'password-error' : undefined}
          />
          {error && <p id="password-error" className="field-error">{error}</p>}
        </div>
        <button className="button" type="submit" disabled={busy}>Sign in</button>
      </form>
    </>
  );
}

export default function Staff() {
  const [groups, setGroups] = useState(undefined); // undefined = loading, null = signed out
  const [error, setError] = useState('');

  async function load() {
    const { status, data } = await api('GET', '/api/staff/bookings');
    setGroups(status === 200 ? data : null);
  }
  useEffect(() => { load(); }, []);

  async function cancel(reference) {
    setError('');
    const { status } = await api('DELETE', `/api/staff/bookings/${reference}`);
    if (status === 401) return setGroups(null);
    if (status !== 204 && status !== 404) setError('The booking could not be cancelled. Please try again.');
    load();
  }

  async function signOut() {
    await api('POST', '/api/staff/logout');
    setGroups(null);
  }

  if (groups === undefined) return <p className="notice">Loading...</p>;
  if (groups === null) return <SignIn onDone={load} />;

  return (
    <>
      <div className="bar">
        <h1>Bookings</h1>
        <button className="button secondary" onClick={signOut}>Sign out</button>
      </div>
      {error && <p className="notice error" role="alert">{error}</p>}
      {groups.map((t) => (
        <section key={t.id} className="group" aria-labelledby={`g-${t.id}`}>
          <h2 id={`g-${t.id}`}>{t.title}</h2>
          <p className="when">{formatWhen(t)} &middot; {t.seats - t.seatsLeft} of {t.seats} seats booked</p>
          {t.bookings.length === 0 ? (
            <p className="empty">No bookings yet</p>
          ) : (
            <table>
              <thead>
                <tr><th>Name</th><th>Email</th><th>Guests</th><th>Reference</th><th><span className="sr-only">Action</span></th></tr>
              </thead>
              <tbody>
                {t.bookings.map((b) => (
                  <tr key={b.reference}>
                    <td data-label="Name">{b.name}</td>
                    <td data-label="Email">{b.email}</td>
                    <td data-label="Guests">{b.guests}</td>
                    <td data-label="Reference" className="ref">{b.reference}</td>
                    <td><button className="button danger" onClick={() => cancel(b.reference)}>Cancel</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      ))}
    </>
  );
}
