import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, formatWhen } from '../api.js';

export default function Tastings() {
  const [tastings, setTastings] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    api('GET', '/api/tastings').then(({ status, data }) => (status === 200 ? setTastings(data) : setFailed(true)));
  }, []);

  if (failed) return <p className="notice error" role="alert">Tastings could not be loaded. Please try again later.</p>;
  if (!tastings) return <p className="notice">Loading tastings...</p>;

  return (
    <>
      <h1>Wine tastings</h1>
      <p className="lead">Join us at the estate. Book your seats online.</p>
      <ul className="cards">
        {tastings.map((t) => (
          <li key={t.id} className={`card${t.seatsLeft === 0 ? ' full' : ''}`}>
            <h2>{t.title}</h2>
            <p className="when">
              <time dateTime={`${t.date}T${t.time}`}>{formatWhen(t)}</time>
            </p>
            <p className="price">EUR {t.price} <span>per guest</span></p>
            <p className="seats">
              {t.seatsLeft === 0 && <span className="badge">Fully booked</span>}
              <span>{t.seatsLeft} seats left</span>
            </p>
            {t.seatsLeft > 0 && (
              <Link className="button" to={`/book/${t.id}`}>Book {t.title}</Link>
            )}
          </li>
        ))}
      </ul>
    </>
  );
}
