import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../server/app.js';

const RIESLING = 'riesling-evening';
const RED = 'red-wine-cellar-tour';
const valid = { tastingId: RIESLING, name: 'Anna Berg', email: 'anna@example.com', guests: 2 };

let now;
let app;
beforeEach(() => {
  now = 1_000_000;
  app = createApp({ staffPassword: 'secret', now: () => now });
});

const seatsLeft = async (id) =>
  (await request(app).get('/api/tastings')).body.find((t) => t.id === id).seatsLeft;
const book = (body) => request(app).post('/api/bookings').send(body);

describe('tastings', () => {
  it('lists the three tastings with full seats', async () => {
    const { body } = await request(app).get('/api/tastings');
    expect(body.map((t) => [t.title, t.date, t.time, t.price, t.seatsLeft])).toEqual([
      ['Riesling Evening', '2026-11-06', '18:00', 25, 12],
      ['Red Wine Cellar Tour', '2026-11-14', '15:00', 32, 8],
      ['Winter Tasting', '2026-12-05', '17:00', 28, 10],
    ]);
  });
});

describe('booking', () => {
  it('confirms with reference, total and reduces seats', async () => {
    const res = await book({ ...valid, tastingId: RED, guests: 3 });
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ tasting: { title: 'Red Wine Cellar Tour' }, guests: 3, total: 96 });
    expect(res.body.reference).toMatch(/^KB-[A-Z0-9]{6}$/);
    expect(await seatsLeft(RED)).toBe(5);
  });

  it('gives each booking a distinct reference', async () => {
    const refs = new Set();
    for (let i = 0; i < 12; i++) refs.add((await book({ ...valid, guests: 1 })).body.reference);
    expect(refs.size).toBe(12);
  });

  it.each([
    [{ name: '' }, 'name'],
    [{ name: '   ' }, 'name'],
    [{ email: 'x' }, 'email'],
    [{ guests: 0 }, 'guests'],
    [{ guests: 9 }, 'guests'],
    [{ guests: 1.5 }, 'guests'],
    [{ guests: '2' }, 'guests'],
    [{ guests: null }, 'guests'],
  ])('rejects %j with an error on %s', async (patch, field) => {
    const res = await book({ ...valid, ...patch });
    expect(res.status).toBe(400);
    expect(Object.keys(res.body.errors)).toEqual([field]);
    expect(await seatsLeft(RIESLING)).toBe(12);
  });

  it('reports every invalid field', async () => {
    const res = await book({ ...valid, name: '', email: 'x', guests: 9 });
    expect(Object.keys(res.body.errors).sort()).toEqual(['email', 'guests', 'name']);
  });

  it('rejects an unknown tasting', async () => {
    expect((await book({ ...valid, tastingId: 'nope' })).status).toBe(404);
  });

  it('rejects more guests than seats left', async () => {
    await book({ ...valid, tastingId: RED, guests: 8 });
    await book({ ...valid, tastingId: RED, guests: 8 }); // full now
    const res = await book({ ...valid, tastingId: RED, guests: 1 });
    expect(res.status).toBe(400);
    expect(res.body.errors.guests).toMatch(/fully booked/i);
    expect(await seatsLeft(RED)).toBe(0);
  });

  it('rejects guests above seats left but accepts the exact fit', async () => {
    await book({ ...valid, tastingId: RED, guests: 5 }); // 3 left
    const over = await book({ ...valid, tastingId: RED, guests: 4 });
    expect(over.status).toBe(400);
    expect(over.body.errors.guests).toMatch(/3 seats/);
    expect(await seatsLeft(RED)).toBe(3);
    expect((await book({ ...valid, tastingId: RED, guests: 3 })).status).toBe(201);
    expect(await seatsLeft(RED)).toBe(0);
  });

  it('never overbooks under concurrent requests', async () => {
    const results = await Promise.all(
      Array.from({ length: 10 }, () => book({ ...valid, tastingId: RED, guests: 3 })),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(2);
    expect(await seatsLeft(RED)).toBe(2);
  });
});

describe('staff', () => {
  const login = (password = 'secret') => request(app).post('/api/staff/login').send({ password });
  const cookieOf = (res) => res.headers['set-cookie'][0];
  const signedIn = async () => cookieOf(await login());

  it('refuses data without a session', async () => {
    expect((await request(app).get('/api/staff/bookings')).status).toBe(401);
    expect((await request(app).delete('/api/staff/bookings/KB-AAAAAA')).status).toBe(401);
  });

  it('refuses a wrong password', async () => {
    const res = await login('wrong');
    expect(res.status).toBe(401);
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('accepts no password when STAFF_PASSWORD is unset or empty', async () => {
    for (const staffPassword of [undefined, '']) {
      const a = createApp({ staffPassword });
      const res = await request(a).post('/api/staff/login').send({ password: '' });
      expect(res.status).toBe(401);
    }
  });

  it('sets an HttpOnly SameSite cookie, Secure only over HTTPS', async () => {
    const plain = cookieOf(await login());
    expect(plain).toMatch(/HttpOnly/i);
    expect(plain).toMatch(/SameSite=Strict/i);
    expect(plain).not.toMatch(/Secure/i);
    const https = cookieOf(await request(app).post('/api/staff/login').set('X-Forwarded-Proto', 'https').send({ password: 'secret' }));
    expect(https).toMatch(/Secure/i);
  });

  it('lists bookings grouped by tasting, including empty tastings', async () => {
    await book(valid);
    const cookie = await signedIn();
    const { body } = await request(app).get('/api/staff/bookings').set('Cookie', cookie);
    expect(body).toHaveLength(3);
    expect(body[0].bookings).toEqual([
      expect.objectContaining({ name: 'Anna Berg', email: 'anna@example.com', guests: 2, reference: expect.any(String) }),
    ]);
    expect(body[1].bookings).toEqual([]);
  });

  it('cancelling frees the seats', async () => {
    const { body: b } = await book({ ...valid, guests: 4 });
    const cookie = await signedIn();
    expect(await seatsLeft(RIESLING)).toBe(8);
    expect((await request(app).delete(`/api/staff/bookings/${b.reference}`).set('Cookie', cookie)).status).toBe(204);
    expect(await seatsLeft(RIESLING)).toBe(12);
    expect((await request(app).delete(`/api/staff/bookings/${b.reference}`).set('Cookie', cookie)).status).toBe(404);
  });

  it('ends the session on logout', async () => {
    const cookie = await signedIn();
    await request(app).post('/api/staff/logout').set('Cookie', cookie);
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });

  it('expires the session', async () => {
    const cookie = await signedIn();
    now += 2 * 60 * 60 * 1000 + 1;
    expect((await request(app).get('/api/staff/bookings').set('Cookie', cookie)).status).toBe(401);
  });

  it('locks out after 5 failed attempts, even with the right password', async () => {
    for (let i = 0; i < 5; i++) expect((await login('wrong')).status).toBe(401);
    const res = await login('secret');
    expect(res.status).toBe(429);
    expect(res.body.error).toBeTruthy();
  });

  it('does not count successful sign-ins against the limit', async () => {
    for (let i = 0; i < 7; i++) expect((await login()).status).toBe(200);
  });
});
