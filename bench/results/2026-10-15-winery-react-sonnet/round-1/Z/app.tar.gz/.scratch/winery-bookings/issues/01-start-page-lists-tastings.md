# 01: Start page lists the Tastings (tracer bullet)

**What to build:** Stand up the whole stack end to end. A Guest opens the site and sees the three Tastings, each with title, date and time, Price per guest and "<n> seats left", on a page with the winery's base look (header, footer, palette, type). `npm install`, `npm run build`, `npm start` serve it on `PORT` (default 3000). The browser-level test harness exists: it starts the built server on a free port per test.

**Blocked by:** None (can start immediately).

**Status:** ready-for-agent

- [x] Start page shows Riesling Evening, Red Wine Cellar Tour and Winter Tasting with date/time, "EUR 25"/"EUR 32"/"EUR 28" and "12 seats left"/"8 seats left"/"10 seats left"
- [x] Each Tasting has a link named "Book <title>"
- [x] `npm start` honours `PORT`, defaults to 3000; app starts with no Bookings
- [x] Test harness runs against the built app, one fresh server per test
