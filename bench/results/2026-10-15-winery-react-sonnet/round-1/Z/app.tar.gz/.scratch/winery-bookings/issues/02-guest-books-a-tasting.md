# 02: Guest books a Tasting and sees the confirmation

**What to build:** Following "Book <title>" opens that Tasting's booking form (Name, Email, Guests, Book). A valid submission creates a Booking and redirects to a confirmation headed "Booking confirmed" showing the Tasting, number of Guests, total price and Booking reference. The start page afterwards shows fewer Seats left.

**Blocked by:** 01

**Status:** ready-for-agent

- [x] Booking 3 Guests for Riesling Evening confirms with "EUR 75" total and a reference; reloading the confirmation shows the same page
- [x] Start page then shows "9 seats left" for Riesling Evening and unchanged others
- [x] Two Bookings get different references
- [x] Unknown Tasting or reference gives a friendly 404

