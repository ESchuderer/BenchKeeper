# 03: Invalid input and seat limits are rejected; Fully booked is clear

**What to build:** Bad input never makes a Booking and shows an error next to the field it concerns, keeping what was typed. A Booking can never take more Seats than are left, including under concurrent submissions. A Fully booked Tasting is clearly marked on the start page and booking page.

**Blocked by:** 02

**Status:** ready-for-agent

- [x] Empty name, bad email, and Guests of empty/0/-1/2.5/abc/9 each give a message beside the right field (Name / Email / Guests) and no Booking is made
- [x] Name and Email typed are still in the form after an error
- [x] Asking for more than Seats left gives "Only <n> seats left for this tasting." beside Guests; Seats left unchanged
- [x] Filling a Tasting to 0 shows "Fully booked" and "0 seats left" on the start page, a notice instead of the form on the booking page, and a direct post is refused
- [x] Parallel submissions never push Seats left below zero
