# 04: Staff sign in and see Bookings grouped by Tasting

**What to build:** `/staff` asks for "Password" with a "Sign in" button; the password is `STAFF_PASSWORD`. Signed in, Staff see every Tasting with its Bookings (name, email, guests, reference) and a "Sign out" button. Without signing in nothing is shown.

**Blocked by:** 02

**Status:** ready-for-agent

- [x] Wrong password shows an error next to the Password field and stays signed out
- [x] Right password shows Bookings grouped by Tasting, with "No bookings yet" for empty Tastings and seats taken out of total
- [x] Session persists across page loads; "Sign out" ends it
- [x] Unset or empty `STAFF_PASSWORD`: nobody can sign in (including with an empty password)
- [x] Booker name and email are shown only on the staff page, never on the confirmation page
