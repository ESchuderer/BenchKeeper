# 05: Staff cancel a Booking, which frees its Seats

**What to build:** Each Booking on the staff page has a "Cancel" button. Cancelling removes the Booking, shows a success notice, and the Seats are bookable again on the start page.

**Blocked by:** 03, 04

**Status:** ready-for-agent

- [x] Cancelling a 3-Guest Booking of Riesling Evening raises its Seats left by 3
- [x] A Fully booked Tasting becomes bookable again after a Cancel
- [x] The cancelled Booking's confirmation URL gives 404
- [x] A cancel request without a staff session is refused and changes nothing
