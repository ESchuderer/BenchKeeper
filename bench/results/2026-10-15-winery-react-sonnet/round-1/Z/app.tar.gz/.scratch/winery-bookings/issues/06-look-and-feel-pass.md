# 06: Look-and-feel pass, mobile and accessibility check

**What to build:** Review every page and state (start, booking form, field errors, Fully booked, confirmation, staff sign-in, staff list, cancel notice, 404) against the spec's design system, in a desktop and a phone viewport, and fix what is inconsistent or cramped.

**Blocked by:** 03, 05

**Status:** ready-for-agent

- [x] No horizontal scroll at 375px width on any page; tap targets at least 44px
- [x] Error, success and Fully booked states are visually distinct and not colour-only
- [x] Keyboard focus visible everywhere; every input has a label; errors tied with `aria-describedby`
- [x] Phone-viewport test runs the full guest journey
