# Online tasting bookings for Weingut Kieselbrunnen

**Status:** ready-for-agent

## Problem Statement

Weingut Kieselbrunnen is a family winery that runs a few Tastings. Guests have no way to reserve Seats online, and Staff have no single place that shows who is coming to which Tasting. Overbooking and lost reservations are the risk.

## Solution

A small website in English with two audiences:

- **Guests** see the Tastings on the start page, pick one, fill in name, email and number of Guests, and get an immediate confirmation with a Booking reference. The site never sells more Seats than a Tasting has.
- **Staff** sign in at `/staff` with a shared password and see all Bookings grouped by Tasting. They can Cancel a Booking, which frees its Seats.

The site looks like the winery's own: warm, calm, legible, and usable on a phone, with clear states for errors, success and Fully booked Tastings.

## User Stories

1. As a Guest, I want to see all Tastings on the start page, so that I can choose one.
2. As a Guest, I want each Tasting to show its title, date and time, Price per guest and Seats left, so that I can decide without opening anything.
3. As a Guest, I want Seats left shown as "<n> seats left", so that I know how much room remains.
4. As a Guest, I want a "Book <tasting title>" link on every Tasting, so that I can open the booking form for exactly that Tasting.
5. As a Guest, I want the booking form to repeat which Tasting I am booking, with its date, time and price, so that I do not book the wrong one.
6. As a Guest, I want the form fields labelled "Name", "Email" and "Guests" and a "Book" button, so that the form is obvious (and works with screen readers).
7. As a Guest, I want to choose 1 to 8 Guests, so that I can bring friends and family.
8. As a Guest, I want to be told next to the field which input is wrong, so that I can fix it quickly.
9. As a Guest, I want an empty name rejected with a message next to "Name".
10. As a Guest, I want a malformed email rejected with a message next to "Email".
11. As a Guest, I want a missing, zero, negative, fractional, non-numeric or more-than-8 number of Guests rejected with a message next to "Guests".
12. As a Guest, I want my typed Name and Email kept when the form shows an error, so that I do not retype.
13. As a Guest, I want to be refused if I ask for more Seats than are left, with a message next to "Guests" that says how many Seats are left, so that I can adjust.
14. As a Guest, I want the Seats check to hold even if someone else booked while my form was open, so that I am never promised a Seat that does not exist.
15. As a Guest, I want a Fully booked Tasting to be clearly marked on the start page and on its booking page, so that I do not waste time filling in a form.
16. As a Guest, I want a confirmation headed "Booking confirmed" showing the Tasting, number of Guests, total price and Booking reference, so that I have proof of my Booking.
17. As a Guest, I want the confirmation to still be there if I reload it, so that I can note the Booking reference without fear of double-booking.
18. As a Guest, I want the start page to show reduced Seats left after I book, so that the numbers are trustworthy.
19. As a Guest on a phone, I want every page readable and tappable without zooming or sideways scrolling.
20. As a Guest, I want the site to work with keyboard and screen reader, so that everyone can book.
21. As Staff, I want `/staff` to ask for a password ("Password" field, "Sign in" button), so that Guests' details stay private.
22. As Staff, I want a wrong password rejected with a message next to the field, so that I know to retry.
23. As Staff, I want the password to come from the environment variable `STAFF_PASSWORD`, so that it is not in the code and can be changed on deploy.
24. As Staff, I want to remain signed in across page loads until I sign out, so that I need not sign in repeatedly.
25. As Staff, I want a "Sign out" button, so that I can leave a shared computer safely.
26. As Staff, I want all Bookings grouped by Tasting, each showing name, email, number of Guests and Booking reference, so that I can prepare each event.
27. As Staff, I want to see Seats taken out of total per Tasting, so that I know how full it is.
28. As Staff, I want a Tasting without Bookings to say so, so that an empty list is not mistaken for a fault.
29. As Staff, I want a "Cancel" button on each Booking, so that I can remove Bookings that are called off.
30. As Staff, I want a cancelled Booking's Seats to become available to Guests immediately.
31. As Staff, I want to see that the cancellation happened (success message), so that I am sure it worked.
32. As the winery, I want the staff page and cancel action to be unusable without signing in, so that strangers cannot read or cancel Bookings.
33. As the winery, I want the app to start with no Bookings and need no external service, so that it is easy to run.

## Implementation Decisions

**Stack.** React with React Router in framework mode (server-rendered; its loaders/actions/`Form` give routing, server, forms and progressive enhancement without hand-rolled replacements), built by Vite and served by React Router's own production server (`react-router-serve`), which honours `PORT`. Tailwind CSS for styling. Zod for input validation. Fonts are bundled locally (no third-party requests at runtime). `npm run build` builds; `npm start` serves everything.

**Booking desk (the one deep module).** All business rules live behind one server-side module with a small interface: list Tastings with Seats left; get one Tasting; book (Tasting, name, email, guests as raw text) returning either a Booking or field-keyed errors; get a Booking by reference; list Bookings grouped by Tasting; cancel a Booking. Routes only translate HTTP to and from this interface. Validation, the Seats check and reference generation are inside it. The booking step checks Seats and records the Booking with no asynchronous gap between, so concurrent requests cannot overbook.

**Storage.** In memory, inside the server process, behind the Booking desk. The app starts with no Bookings; a restart empties them. Chosen over a file because the brief allows either, a fresh start must be guaranteed, and the desk is the only place that would change.

**Tasting catalogue.** Fixed in code (three Tastings: Riesling Evening 2026-11-06 18:00 EUR 25 12 seats; Red Wine Cellar Tour 2026-11-14 15:00 EUR 32 8 seats; Winter Tasting 2026-12-05 17:00 EUR 28 10 seats). Each has a URL-safe slug. Prices are held in cents internally and shown as "EUR 25".

**Routes.** Start page `/`; booking form `/tastings/:slug/book` (form posts to itself); confirmation `/bookings/:reference`; staff `/staff` (sign-in form when signed out, bookings when signed in); sign-out and cancel are POST actions. Unknown slug or reference gives a friendly 404.

**Validation rules.**
- Name: required after trimming, at most 100 characters.
- Email: required, valid address shape, at most 254 characters.
- Guests: whole number from 1 to 8 (typed text; rejects empty, 0, negative, fractional, non-numeric, 9 and above), and not above Seats left.
- Errors are per field, rendered directly under the field, tied to the input with `aria-describedby` and `aria-invalid`, plus a summary only where useful. The form uses `noValidate` so server messages always show, in the browser as without JavaScript. Submitted Name, Email and Guests are kept on error.
- Messages: "Please enter your name."; "Please enter your email address."; "Please enter a valid email address."; "Please enter the number of guests."; "Guests must be a whole number from 1 to 8."; "Only <n> seats left for this tasting." (and a Fully booked message when none are left).

**Guests input.** A number input labelled "Guests" (default 1), so any value can be typed and tested. Seats left and the 1 to 8 range are shown as hint text.

**Seats left wording.** Always "<n> seats left", exactly as in the brief, including "0 seats left" and "1 seats left". A Fully booked Tasting additionally carries a visible "Fully booked" badge.

**Fully booked.** The start page still lists the Tasting with its "Book <title>" link; the booking page shows a clear Fully booked notice instead of the form, with a link back. The server refuses a direct post as well.

**Booking reference.** `KB-` plus six characters from an unambiguous uppercase alphabet (no 0/O/1/I), random, unique among current Bookings.

**Total price.** Price per guest at booking time times Guests, stored on the Booking and shown as "EUR 50".

**Confirmation.** After a successful booking the browser is redirected to the confirmation page for the reference (so reload does not rebook). The page shows heading "Booking confirmed", Tasting title with date and time, number of Guests, total price and Booking reference. It does not show the Booker's name or email. The confirmation page needs no sign-in; the unguessable reference is the access.

**Staff authentication.** Password read from `STAFF_PASSWORD` on each sign-in attempt, compared in constant time. If the variable is unset or empty, nobody can sign in (no default password) and the sign-in page says staff sign-in is not configured. Sign-in creates a server-side session held in memory; the browser gets an HttpOnly, SameSite=Lax cookie carrying only an opaque id, signed with a secret that is random per process. Signing out destroys the session, so a copied cookie stops working; a restart signs everyone out. Staff loader and every staff action re-check the session on the server. Cancel removes the Booking from the desk (Seats free again) and the confirmation URL of a cancelled Booking becomes a 404.

**Staff page.** One section per Tasting (including those without Bookings, which say "No bookings yet"), showing Seats taken out of total, then each Booking as name, email, guests, reference and a "Cancel" button. Cancel is a plain button in a per-Booking form; its visible name is exactly "Cancel". A success notice appears after cancelling.

**Look and feel.** A coherent design system in Tailwind theme tokens: deep burgundy/wine and cream palette with muted slate-green accent, serif display face for headings (bundled) and a clean sans body, generous spacing, a header with the winery name and a footer. Components: Tasting card, status badge (seats left / fully booked), form field with error text, alert/notice (error, success, info), primary and secondary buttons with visible focus rings. Mobile first: single column on phones, cards in a grid from tablet up; tap targets at least 44px; inputs at 16px font so phones do not zoom. Contrast meets WCAG AA. Errors are never conveyed by colour alone.

**Config.** `PORT` (default 3000), `STAFF_PASSWORD`. Nothing else is required.

## Testing Decisions

**One seam: the running application over HTTP, driven by a real browser.** Tests (Playwright, Chromium) start the built production server on a free port per test with a chosen `STAFF_PASSWORD`, so every test begins with no Bookings and tests run in parallel without interference. They assert only what a Guest or Staff member sees: roles, labels and visible text from the brief. They never read the Booking desk's internals or the HTTP framework's. The Booking desk is covered through this seam; no separate unit-test seam is added.

A good test here is a short user journey: "guest books Riesling Evening for 3 and sees confirmation with EUR 75 and a reference"; "booking more than the seats left shows an error next to Guests and books nothing"; "cancelling frees seats on the start page". Expected values are literals from the brief (prices, seat counts), never recomputed from the application's data.

The concurrent-overbooking guarantee is tested through the same seam by sending parallel booking submissions and checking Seats left never goes below zero.

A mobile-width run (phone viewport) exercises the full guest journey to catch layout breakage and horizontal overflow.

Prior art: none in the repo (greenfield).

## Out of Scope

- Online payment. The Booking states the total price but nothing is charged.
- Email sending (no confirmation emails).
- Guest self-service cancellation or editing.
- Hiding or closing Tastings whose date has passed; the three Tastings are fixed.
- Editing Tastings or the catalogue from the UI.
- Persistence across restarts, multiple server instances, per-user staff accounts, brute-force rate limiting, localisation, analytics.
- Secure-only cookies (the app is plain HTTP on `PORT`; TLS is the deployment's concern).

## Further Notes

- Domain language follows `GLOSSARY.md`.
- Assumption recorded in place of an interview: the brief was fully specified, so ambiguities were settled by the decisions above instead of blocking on questions. In particular the test seam (the browser over HTTP) was taken from the brief's own description of the product as pages, labels and buttons.
