# Weingut Kieselbrunnen Tastings

How a family winery sells places at its wine tastings online, and how its staff keep track of who is coming.

## Language

**Tasting**:
A scheduled wine-tasting event at the winery with a fixed date and time, a price per guest and a limited number of seats.
_Avoid_: Event, session, tour, product

**Seat**:
One place at a Tasting, taken by exactly one Guest.
_Avoid_: Spot, ticket, slot

**Seats left**:
The number of Seats of a Tasting not yet taken by a Booking.
_Avoid_: Availability, remaining capacity

**Fully booked**:
A Tasting with no Seats left.
_Avoid_: Sold out, full

**Guest**:
A person attending a Tasting. Every Guest takes one Seat.
_Avoid_: Attendee, participant, customer, visitor

**Booker**:
The Guest who makes a Booking, identified by name and email.
_Avoid_: Customer, user, client

**Booking**:
A Booker's reservation of one or more Seats at one Tasting, for a number of Guests, at the Price per guest valid when booked.
_Avoid_: Reservation, order, ticket

**Booking reference**:
The short code that identifies one Booking to the Booker and to Staff.
_Avoid_: Booking ID, confirmation number, ticket number

**Price per guest**:
What one Guest pays for a Tasting, in euros. A Booking's total price is the Price per guest times its number of Guests.
_Avoid_: Ticket price, fee

**Staff**:
The winery's own people, who sign in with the shared staff password to see and cancel Bookings.
_Avoid_: Admin, employee, operator

**Cancel**:
Staff removing a Booking, which frees its Seats again. Only Staff cancel; Bookers do not.
_Avoid_: Delete, refund, void
