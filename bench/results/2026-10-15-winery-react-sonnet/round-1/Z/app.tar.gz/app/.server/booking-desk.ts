import { randomInt } from "node:crypto";
import { z } from "zod";
import { MAX_GUESTS_PER_BOOKING } from "~/booking-rules";
import { TASTINGS, type Tasting } from "./tastings";

export type TastingWithSeatsLeft = Tasting & { seatsLeft: number };

export type Booking = {
  reference: string;
  tastingSlug: string;
  name: string;
  email: string;
  guests: number;
  totalCents: number;
};

export type BookingRequest = {
  tastingSlug: string;
  name: string;
  email: string;
  guests: string;
};

export type BookingField = "name" | "email" | "guests";
export type FieldErrors = Partial<Record<BookingField, string>>;
export type BookingResult = { ok: true; booking: Booking } | { ok: false; errors: FieldErrors };

const GUESTS_RANGE_MESSAGE = `Guests must be a whole number from 1 to ${MAX_GUESTS_PER_BOOKING}.`;

// One schema per field, so every wrong field is reported at once and a valid
// number of guests can still be checked against the seats left.
const fieldSchemas = {
  name: z.string().trim().min(1, "Please enter your name.").max(100, "Please use at most 100 characters."),
  email: z
    .string()
    .trim()
    .min(1, "Please enter your email address.")
    .max(254, "Please use at most 254 characters.")
    .pipe(z.email("Please enter a valid email address.")),
  guests: z
    .string()
    .trim()
    .min(1, "Please enter the number of guests.")
    .regex(/^\d+$/, GUESTS_RANGE_MESSAGE)
    .transform(Number)
    .pipe(z.number().min(1, GUESTS_RANGE_MESSAGE).max(MAX_GUESTS_PER_BOOKING, GUESTS_RANGE_MESSAGE)),
};

function seatsLeftMessage(seatsLeft: number): string {
  if (seatsLeft === 0) return "This tasting is fully booked.";
  return `Only ${seatsLeft} ${seatsLeft === 1 ? "seat" : "seats"} left for this tasting.`;
}

export type TastingBookings = { tasting: TastingWithSeatsLeft; bookings: Booking[] };

export type BookingDesk = {
  listTastings(): TastingWithSeatsLeft[];
  getTasting(slug: string): TastingWithSeatsLeft | undefined;
  book(request: BookingRequest): BookingResult;
  getBooking(reference: string): (Booking & { tasting: Tasting }) | undefined;
  /** Every tasting with its bookings, oldest booking first. */
  listBookingsByTasting(): TastingBookings[];
  /** Removes a booking, freeing its seats. False if there is no such booking (any more). */
  cancel(reference: string): boolean;
};

// No 0/O or 1/I/L, which are easy to misread on paper or over the phone.
const REFERENCE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

function randomReference(): string {
  let code = "";
  for (let i = 0; i < 6; i++) code += REFERENCE_ALPHABET[randomInt(REFERENCE_ALPHABET.length)];
  return `KB-${code}`;
}

function parseField<F extends BookingField>(
  field: F,
  input: string,
  errors: FieldErrors,
): z.output<(typeof fieldSchemas)[F]> | undefined {
  const result = fieldSchemas[field].safeParse(input);
  if (result.success) return result.data as z.output<(typeof fieldSchemas)[F]>;
  errors[field] = result.error.issues[0].message;
  return undefined;
}

export function createBookingDesk(tastings: readonly Tasting[]): BookingDesk {
  const bookings = new Map<string, Booking>();

  function findTasting(slug: string): Tasting | undefined {
    return tastings.find((tasting) => tasting.slug === slug);
  }

  function seatsTaken(slug: string): number {
    let taken = 0;
    for (const booking of bookings.values()) if (booking.tastingSlug === slug) taken += booking.guests;
    return taken;
  }

  function withSeatsLeft(tasting: Tasting): TastingWithSeatsLeft {
    return { ...tasting, seatsLeft: tasting.seats - seatsTaken(tasting.slug) };
  }

  function uniqueReference(): string {
    let reference = randomReference();
    while (bookings.has(reference)) reference = randomReference();
    return reference;
  }

  return {
    listTastings: () => tastings.map(withSeatsLeft),

    getTasting(slug) {
      const tasting = findTasting(slug);
      return tasting && withSeatsLeft(tasting);
    },

    book(request) {
      const tasting = findTasting(request.tastingSlug);
      if (!tasting) throw new Error(`Unknown tasting: ${request.tastingSlug}`);

      const errors: FieldErrors = {};
      const name = parseField("name", request.name, errors);
      const email = parseField("email", request.email, errors);
      const guests = parseField("guests", request.guests, errors);

      // Check and write happen in one synchronous step, so concurrent requests
      // can never take the same seat twice.
      const seatsLeft = tasting.seats - seatsTaken(tasting.slug);
      if (seatsLeft === 0 || (guests !== undefined && guests > seatsLeft)) {
        errors.guests = seatsLeftMessage(seatsLeft);
      }
      if (name === undefined || email === undefined || guests === undefined || errors.guests) {
        return { ok: false, errors };
      }

      const booking: Booking = {
        reference: uniqueReference(),
        tastingSlug: tasting.slug,
        name,
        email,
        guests,
        totalCents: tasting.pricePerGuestCents * guests,
      };
      bookings.set(booking.reference, booking);
      return { ok: true, booking };
    },

    listBookingsByTasting() {
      return tastings.map((tasting) => ({
        tasting: withSeatsLeft(tasting),
        bookings: [...bookings.values()].filter((booking) => booking.tastingSlug === tasting.slug),
      }));
    },

    cancel: (reference) => bookings.delete(reference),

    getBooking(reference) {
      const booking = bookings.get(reference);
      const tasting = booking && findTasting(booking.tastingSlug);
      return booking && tasting ? { ...booking, tasting } : undefined;
    },
  };
}

// One desk per server process. Kept on globalThis so dev-server reloads keep
// the bookings made so far.
const globalForDesk = globalThis as typeof globalThis & { __bookingDesk?: BookingDesk };
export const bookingDesk = (globalForDesk.__bookingDesk ??= createBookingDesk(TASTINGS));
