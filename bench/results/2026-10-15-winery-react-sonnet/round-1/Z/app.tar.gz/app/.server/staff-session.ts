import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { createMemorySessionStorage, data } from "react-router";

// Sessions live in server memory: signing out really ends a session (a copied
// cookie stops working), and a restart signs everyone out. The cookie only carries
// an opaque id, signed with a secret generated per process, so no secret lives in
// the code or the repo.
const globalForSession = globalThis as typeof globalThis & { __staffSessionSecret?: string };
const secret = (globalForSession.__staffSessionSecret ??= randomBytes(32).toString("hex"));

const storage = createMemorySessionStorage({
  cookie: {
    name: "kb_staff",
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12,
    secrets: [secret],
  },
});

/** The staff password comes from the environment, read on every attempt. Unset or empty means nobody can sign in. */
function configuredPassword(): string | undefined {
  return process.env.STAFF_PASSWORD || undefined;
}

export function isStaffSignInConfigured(): boolean {
  return configuredPassword() !== undefined;
}

function digest(text: string): Buffer {
  return createHash("sha256").update(text).digest();
}

export function isCorrectStaffPassword(attempt: string): boolean {
  const expected = configuredPassword();
  if (expected === undefined) return false;
  // Hashing first gives both sides equal length, so the comparison runs in constant time.
  return timingSafeEqual(digest(attempt), digest(expected));
}

export async function isStaff(request: Request): Promise<boolean> {
  const session = await storage.getSession(request.headers.get("Cookie"));
  return session.get("staff") === true;
}

/** Throws a 403 unless the request carries a staff session. Guard every staff-only action with this. */
export async function requireStaff(request: Request): Promise<void> {
  if (!(await isStaff(request))) throw data(null, { status: 403 });
}

/** Headers that sign the caller in as staff. */
export async function signInHeaders(): Promise<Headers> {
  const session = await storage.getSession();
  session.set("staff", true);
  return new Headers({ "Set-Cookie": await storage.commitSession(session) });
}

/** Headers that end the caller's staff session. */
export async function signOutHeaders(request: Request): Promise<Headers> {
  const session = await storage.getSession(request.headers.get("Cookie"));
  return new Headers({ "Set-Cookie": await storage.destroySession(session) });
}
