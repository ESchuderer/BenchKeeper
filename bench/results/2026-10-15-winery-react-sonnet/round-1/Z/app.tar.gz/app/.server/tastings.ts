export type Tasting = {
  slug: string;
  title: string;
  /** Local date at the winery, YYYY-MM-DD. */
  date: string;
  /** Local time at the winery, HH:MM. */
  time: string;
  pricePerGuestCents: number;
  seats: number;
  blurb: string;
};

export const TASTINGS: readonly Tasting[] = [
  {
    slug: "riesling-evening",
    title: "Riesling Evening",
    date: "2026-11-06",
    time: "18:00",
    pricePerGuestCents: 2500,
    seats: 12,
    blurb:
      "An unhurried evening with our Rieslings, from bone-dry to gently sweet, poured with bread and cheese.",
  },
  {
    slug: "red-wine-cellar-tour",
    title: "Red Wine Cellar Tour",
    date: "2026-11-14",
    time: "15:00",
    pricePerGuestCents: 3200,
    seats: 8,
    blurb: "Walk down into the barrel cellar and taste our reds straight from the cask.",
  },
  {
    slug: "winter-tasting",
    title: "Winter Tasting",
    date: "2026-12-05",
    time: "17:00",
    pricePerGuestCents: 2800,
    seats: 10,
    blurb: "Our cosiest tasting: robust whites, Pinot Noir and a warm glass of mulled wine to finish.",
  },
];
