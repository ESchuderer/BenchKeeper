/** Most guests one booking may take. Shared so the form can show the same limit the server enforces. */
export const MAX_GUESTS_PER_BOOKING = 8;
