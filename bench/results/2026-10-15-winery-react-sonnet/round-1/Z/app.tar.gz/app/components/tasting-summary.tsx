import type { Tasting } from "~/.server/tastings";
import { formatEur, formatSeatsLeft } from "~/format";

export function TastingWhen({ tasting }: { tasting: Pick<Tasting, "date" | "time"> }) {
  return <time dateTime={`${tasting.date}T${tasting.time}`}>{`${tasting.date} ${tasting.time}`}</time>;
}

export function TastingPrice({ tasting }: { tasting: Pick<Tasting, "pricePerGuestCents"> }) {
  return (
    <>
      <span className="font-semibold">{formatEur(tasting.pricePerGuestCents)}</span>{" "}
      <span className="text-sm text-muted">per guest</span>
    </>
  );
}

/** "Fully booked" badge (only when no seats are left) next to the "<n> seats left" text. */
export function SeatsLeft({ seatsLeft }: { seatsLeft: number }) {
  const fullyBooked = seatsLeft === 0;
  return (
    <span className="flex flex-wrap items-center gap-2 text-sm">
      {fullyBooked && (
        <span className="rounded-full bg-ink px-3 py-1 font-semibold text-cream">Fully booked</span>
      )}
      <span className={fullyBooked ? "text-muted" : "font-medium text-leaf-700"}>
        {formatSeatsLeft(seatsLeft)}
      </span>
    </span>
  );
}
