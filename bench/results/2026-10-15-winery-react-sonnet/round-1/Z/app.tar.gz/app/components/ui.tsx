import { Link, type LinkProps } from "react-router";

const buttonBase =
  "inline-flex min-h-11 items-center justify-center rounded-md px-5 py-2 text-base font-medium transition-colors";

export const primaryButton = `${buttonBase} bg-wine-700 text-cream hover:bg-wine-800 disabled:opacity-60`;
export const secondaryButton = `${buttonBase} border border-wine-700 bg-paper text-wine-800 hover:bg-wine-50`;

export const dangerButton = `${buttonBase} border border-alert-700 bg-paper text-alert-700 hover:bg-alert-50`;

export function ButtonLink({
  variant = "primary",
  className = "",
  ...props
}: LinkProps & { variant?: "primary" | "secondary" }) {
  const style = variant === "primary" ? primaryButton : secondaryButton;
  return <Link {...props} className={`${style} ${className}`} />;
}

const inputBase =
  "mt-1 block min-h-11 w-full rounded-md border bg-white px-3 py-2 text-base text-ink shadow-sm placeholder:text-muted/70";

type FieldProps = {
  label: string;
  name: string;
  type?: string;
  defaultValue?: string;
  autoComplete?: string;
  hint?: string;
  error?: string;
  inputMode?: "numeric" | "email" | "text";
  min?: number;
  max?: number;
};

/** A labelled input. Its error, if any, sits directly beneath it and is linked to it for assistive tech. */
export function Field({ label, name, hint, error, type = "text", ...input }: FieldProps) {
  const hintId = `${name}-hint`;
  const errorId = `${name}-error`;
  const describedBy = [error && errorId, hint && hintId].filter(Boolean).join(" ") || undefined;
  return (
    <div>
      <label htmlFor={name} className="block font-medium text-ink">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        className={`${inputBase} ${error ? "border-2 border-alert-700 bg-alert-50" : "border-line"}`}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        {...input}
      />
      {error && (
        <p id={errorId} className="mt-1 flex items-start gap-1.5 text-sm font-medium text-alert-700">
          <StatusIcon kind="error" />
          <span>
            <span className="sr-only">Error: </span>
            {error}
          </span>
        </p>
      )}
      {hint && (
        <p id={hintId} className="mt-1 text-sm text-muted">
          {hint}
        </p>
      )}
    </div>
  );
}

type NoticeKind = "error" | "success" | "info";

const noticeStyle: Record<NoticeKind, string> = {
  error: "border-alert-700 bg-alert-50 text-alert-700",
  success: "border-leaf-700 bg-leaf-50 text-leaf-800",
  info: "border-wine-600 bg-wine-50 text-wine-900",
};

/** A banner-style message with an icon, so its meaning never rests on colour alone. */
export function Notice({
  kind,
  title,
  children,
}: {
  kind: NoticeKind;
  title: string;
  children?: React.ReactNode;
}) {
  return (
    <div
      role={kind === "error" ? "alert" : "status"}
      className={`flex items-start gap-3 rounded-lg border-l-4 p-4 ${noticeStyle[kind]}`}
    >
      <StatusIcon kind={kind} />
      <div>
        <p className="font-semibold">{title}</p>
        {children && <div className="mt-1 text-sm">{children}</div>}
      </div>
    </div>
  );
}

export function StatusIcon({
  kind,
  className = "mt-0.5 size-5 shrink-0",
}: {
  kind: NoticeKind;
  className?: string;
}) {
  const path = {
    error:
      "M12 8v5m0 3.5h.01M10.3 3.9 2.4 17.5A2 2 0 0 0 4.1 20.5h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z",
    success: "m5 12.5 4.5 4.5L19 7.5",
    info: "M12 11v5m0-8.5h.01M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z",
  }[kind];
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      className={className}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d={path} />
    </svg>
  );
}
