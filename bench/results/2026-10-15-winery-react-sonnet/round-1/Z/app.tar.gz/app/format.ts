/** 2500 -> "EUR 25", 2550 -> "EUR 25.50". */
export function formatEur(cents: number): string {
  const euros = cents / 100;
  return `EUR ${Number.isInteger(euros) ? euros : euros.toFixed(2)}`;
}

/** "<n> seats left", worded exactly like this for every n. */
export function formatSeatsLeft(seatsLeft: number): string {
  return `${seatsLeft} seats left`;
}

/** "3 of 12 seats booked". */
export function formatSeatsBooked(seats: number, seatsLeft: number): string {
  return `${seats - seatsLeft} of ${seats} seats booked`;
}
