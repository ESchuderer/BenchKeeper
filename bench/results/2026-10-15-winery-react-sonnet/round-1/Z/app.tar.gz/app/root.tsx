import { isRouteErrorResponse, Link, Links, Meta, Outlet, Scripts, ScrollRestoration } from "react-router";
import "@fontsource-variable/fraunces";
import "@fontsource-variable/inter";

import { ButtonLink } from "~/components/ui";
import type { Route } from "./+types/root";
import "./app.css";

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#571629" />
        <Meta />
        <Links />
      </head>
      <body className="flex min-h-dvh flex-col">
        <a
          href="#main"
          className="sr-only rounded bg-paper px-4 py-2 font-medium text-wine-800 focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-10"
        >
          Skip to content
        </a>
        <SiteHeader />
        <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6 sm:py-12">
          {children}
        </main>
        <SiteFooter />
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  );
}

function SiteHeader() {
  return (
    <header className="bg-wine-900 text-cream">
      <div className="mx-auto flex max-w-5xl items-baseline justify-between gap-4 px-4 py-4 sm:px-6">
        <Link to="/" className="font-display text-xl font-semibold tracking-tight sm:text-2xl">
          Weingut Kieselbrunnen
        </Link>
        <span className="hidden text-sm text-wine-100 sm:block">Family winery &middot; wine tastings</span>
      </div>
      <div className="h-1 bg-gold" aria-hidden="true" />
    </header>
  );
}

function SiteFooter() {
  return (
    <footer className="border-t border-line bg-paper">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-x-6 gap-y-2 px-4 py-6 text-sm text-muted sm:px-6">
        <p>Weingut Kieselbrunnen &middot; a family winery</p>
        <Link to="/staff" className="underline decoration-line underline-offset-4 hover:text-wine-700">
          Staff
        </Link>
      </div>
    </footer>
  );
}

export default function App() {
  return <Outlet />;
}

export function ErrorBoundary({ error }: Route.ErrorBoundaryProps) {
  const notFound = isRouteErrorResponse(error) && error.status === 404;
  return (
    <section className="mx-auto max-w-xl py-8 text-center">
      <h1 className="font-display text-3xl font-semibold text-wine-800">
        {notFound ? "We couldn't find that page" : "Something went wrong"}
      </h1>
      <p className="mt-3 text-muted">
        {notFound
          ? "The page or booking you are looking for does not exist (any more)."
          : "Please try again in a moment."}
      </p>
      <p className="mt-6">
        <ButtonLink to="/">Back to the tastings</ButtonLink>
      </p>
    </section>
  );
}
