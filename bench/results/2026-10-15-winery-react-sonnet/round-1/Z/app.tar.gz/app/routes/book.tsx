import { data, Form, redirect } from "react-router";
import { bookingDesk } from "~/.server/booking-desk";
import { MAX_GUESTS_PER_BOOKING } from "~/booking-rules";
import { ButtonLink, Field, Notice, primaryButton } from "~/components/ui";
import { SeatsLeft, TastingPrice, TastingWhen } from "~/components/tasting-summary";
import type { Route } from "./+types/book";

function requireTasting(slug: string) {
  const tasting = bookingDesk.getTasting(slug);
  if (!tasting) throw data(null, { status: 404 });
  return tasting;
}

export function meta({ loaderData }: Route.MetaArgs) {
  return [{ title: `Book ${loaderData?.tasting.title ?? "a tasting"} | Weingut Kieselbrunnen` }];
}

export function loader({ params }: Route.LoaderArgs) {
  return { tasting: requireTasting(params.slug) };
}

export async function action({ params, request }: Route.ActionArgs) {
  const tasting = requireTasting(params.slug);
  const form = await request.formData();
  const values = {
    name: String(form.get("name") ?? ""),
    email: String(form.get("email") ?? ""),
    guests: String(form.get("guests") ?? ""),
  };

  const result = bookingDesk.book({ tastingSlug: tasting.slug, ...values });
  if (!result.ok) return data({ errors: result.errors, values }, { status: 422 });
  return redirect(`/bookings/${result.booking.reference}`);
}

export default function Book({ loaderData, actionData }: Route.ComponentProps) {
  const { tasting } = loaderData;
  const fullyBooked = tasting.seatsLeft === 0;
  const errors = actionData?.errors ?? {};
  const values = actionData?.values;

  return (
    <div className="grid gap-8 md:grid-cols-5">
      <section className="md:col-span-2">
        <h1 className="font-display text-3xl font-semibold text-wine-900 sm:text-4xl">{tasting.title}</h1>
        <p className="mt-2 text-sm font-medium uppercase tracking-wide text-muted">
          <TastingWhen tasting={tasting} />
        </p>
        <p className="mt-4 text-muted">{tasting.blurb}</p>
        <p className="mt-4 text-lg">
          <TastingPrice tasting={tasting} />
        </p>
        <p className="mt-2">
          <SeatsLeft seatsLeft={tasting.seatsLeft} />
        </p>
      </section>

      <div className="md:col-span-3">
        {fullyBooked && !actionData ? (
          <Notice kind="info" title="This tasting is fully booked">
            <p>All seats have been taken. Please have a look at our other tastings.</p>
            <p className="mt-3">
              <ButtonLink to="/" variant="secondary">
                See all tastings
              </ButtonLink>
            </p>
          </Notice>
        ) : (
          <Form
            method="post"
            noValidate
            className="space-y-5 rounded-xl border border-line bg-paper p-5 shadow-sm sm:p-6"
          >
            <h2 className="font-display text-xl font-semibold text-wine-800">Your booking</h2>
            <Field
              label="Name"
              name="name"
              autoComplete="name"
              defaultValue={values?.name}
              error={errors.name}
            />
            <Field
              label="Email"
              name="email"
              type="email"
              autoComplete="email"
              defaultValue={values?.email}
              error={errors.email}
            />
            <Field
              label="Guests"
              name="guests"
              type="number"
              inputMode="numeric"
              min={1}
              max={MAX_GUESTS_PER_BOOKING}
              defaultValue={values?.guests ?? "1"}
              hint={`1 to ${MAX_GUESTS_PER_BOOKING} guests`}
              error={errors.guests}
            />
            <button type="submit" className={primaryButton}>
              Book
            </button>
          </Form>
        )}
      </div>
    </div>
  );
}
