import { data } from "react-router";
import { bookingDesk } from "~/.server/booking-desk";
import { ButtonLink, StatusIcon } from "~/components/ui";
import { TastingWhen } from "~/components/tasting-summary";
import { formatEur } from "~/format";
import type { Route } from "./+types/confirmation";

export function meta() {
  return [{ title: "Booking confirmed | Weingut Kieselbrunnen" }];
}

export function loader({ params }: Route.LoaderArgs) {
  const booking = bookingDesk.getBooking(params.reference);
  if (!booking) throw data(null, { status: 404 });
  return { booking };
}

export default function Confirmation({ loaderData }: Route.ComponentProps) {
  const { booking } = loaderData;
  return (
    <section className="mx-auto max-w-xl rounded-xl border border-leaf-700/30 bg-paper p-6 shadow-sm sm:p-8">
      <p className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-leaf-700">
        <span className="grid size-7 place-items-center rounded-full bg-leaf-700 text-paper">
          <StatusIcon kind="success" className="size-4" />
        </span>
        Thank you
      </p>
      <h1 className="mt-1 font-display text-3xl font-semibold text-wine-900 sm:text-4xl">
        Booking confirmed
      </h1>

      <dl className="mt-6 divide-y divide-line border-y border-line">
        <Row term="Tasting">
          <span className="font-medium">{booking.tasting.title}</span>
          <br />
          <span className="text-muted">
            <TastingWhen tasting={booking.tasting} />
          </span>
        </Row>
        <Row term="Guests">{booking.guests}</Row>
        <Row term="Total price">{formatEur(booking.totalCents)}</Row>
        <Row term="Booking reference">
          <span className="font-mono text-lg font-semibold tracking-wider text-wine-800">
            {booking.reference}
          </span>
        </Row>
      </dl>

      <p className="mt-6 text-muted">
        Please keep your booking reference. You will need it if you get in touch with us.
      </p>
      <ButtonLink to="/" variant="secondary" className="mt-6">
        Back to the tastings
      </ButtonLink>
    </section>
  );
}

function Row({ term, children }: { term: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-3 gap-4 py-3">
      <dt className="text-muted">{term}</dt>
      <dd className="col-span-2">{children}</dd>
    </div>
  );
}
