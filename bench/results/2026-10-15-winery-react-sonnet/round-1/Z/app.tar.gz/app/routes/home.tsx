import { ButtonLink } from "~/components/ui";
import { bookingDesk, type TastingWithSeatsLeft } from "~/.server/booking-desk";
import { SeatsLeft, TastingPrice, TastingWhen } from "~/components/tasting-summary";
import type { Route } from "./+types/home";

export function meta() {
  return [
    { title: "Wine tastings | Weingut Kieselbrunnen" },
    {
      name: "description",
      content: "Book a seat at a wine tasting at Weingut Kieselbrunnen, a family winery.",
    },
  ];
}

export function loader() {
  return { tastings: bookingDesk.listTastings() };
}

export default function Home({ loaderData }: Route.ComponentProps) {
  return (
    <>
      <section className="max-w-2xl">
        <h1 className="font-display text-balance text-3xl font-semibold leading-tight tracking-tight text-wine-900 sm:text-5xl">
          Wine tastings at Weingut Kieselbrunnen
        </h1>
        <p className="mt-4 text-lg text-muted">
          Join us at the family winery for an evening of wine, stories from the vineyard and good company.
          Choose a tasting and book your seats.
        </p>
      </section>

      <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {loaderData.tastings.map((tasting) => (
          <li key={tasting.slug} className="flex">
            <TastingCard tasting={tasting} />
          </li>
        ))}
      </ul>
    </>
  );
}

function TastingCard({ tasting }: { tasting: TastingWithSeatsLeft }) {
  const fullyBooked = tasting.seatsLeft === 0;
  return (
    <article
      className={`flex w-full flex-col rounded-xl border p-5 shadow-sm ${
        fullyBooked ? "border-ink/25 bg-cream" : "border-line bg-paper"
      }`}
    >
      <h2 className="font-display text-2xl font-semibold text-wine-800">{tasting.title}</h2>
      <p className="mt-1 text-sm font-medium uppercase tracking-wide text-muted">
        <TastingWhen tasting={tasting} />
      </p>
      <p className="mt-3 flex-1 text-muted">{tasting.blurb}</p>

      <p className="mt-4 text-lg">
        <TastingPrice tasting={tasting} />
      </p>

      <p className="mt-2">
        <SeatsLeft seatsLeft={tasting.seatsLeft} />
      </p>

      <ButtonLink
        to={`/tastings/${tasting.slug}/book`}
        variant={fullyBooked ? "secondary" : "primary"}
        className="mt-5"
      >
        {`Book ${tasting.title}`}
      </ButtonLink>
    </article>
  );
}
