import { data, Form, redirect } from "react-router";
import { bookingDesk, type TastingBookings } from "~/.server/booking-desk";
import {
  isCorrectStaffPassword,
  isStaff,
  isStaffSignInConfigured,
  requireStaff,
  signInHeaders,
  signOutHeaders,
} from "~/.server/staff-session";
import { dangerButton, Field, Notice, primaryButton, secondaryButton } from "~/components/ui";
import { TastingWhen } from "~/components/tasting-summary";
import { formatSeatsBooked } from "~/format";
import type { Route } from "./+types/staff";

export function meta() {
  return [{ title: "Staff | Weingut Kieselbrunnen" }, { name: "robots", content: "noindex" }];
}

export async function loader({ request }: Route.LoaderArgs) {
  if (!(await isStaff(request))) {
    return { signedIn: false as const, signInConfigured: isStaffSignInConfigured() };
  }
  return { signedIn: true as const, groups: bookingDesk.listBookingsByTasting() };
}

export async function action({ request }: Route.ActionArgs) {
  const form = await request.formData();
  const intent = String(form.get("intent") ?? "");

  if (intent === "sign-in") {
    if (!isStaffSignInConfigured()) {
      return data({ error: "Staff sign-in is not set up on this server." }, { status: 401 });
    }
    if (!isCorrectStaffPassword(String(form.get("password") ?? ""))) {
      return data({ error: "Incorrect password." }, { status: 401 });
    }
    return redirect("/staff", { headers: await signInHeaders() });
  }

  if (intent === "sign-out") {
    return redirect("/staff", { headers: await signOutHeaders(request) });
  }

  if (intent === "cancel") {
    await requireStaff(request);
    const reference = String(form.get("reference") ?? "");
    return { cancelled: reference, found: bookingDesk.cancel(reference) };
  }

  throw data(null, { status: 400 });
}

export default function Staff({ loaderData, actionData }: Route.ComponentProps) {
  if (!loaderData.signedIn) {
    const error = actionData && "error" in actionData ? actionData.error : undefined;
    return <SignIn signInConfigured={loaderData.signInConfigured} error={error} />;
  }
  const cancellation = actionData && "cancelled" in actionData ? actionData : undefined;
  return <Bookings groups={loaderData.groups} cancellation={cancellation} />;
}

function SignIn({ signInConfigured, error }: { signInConfigured: boolean; error?: string }) {
  return (
    <div className="mx-auto max-w-md">
      <h1 className="font-display text-3xl font-semibold text-wine-900 sm:text-4xl">Staff</h1>
      <p className="mt-2 text-muted">Sign in to see the bookings.</p>

      {!signInConfigured && (
        <div className="mt-6">
          <Notice kind="info" title="Staff sign-in is not set up">
            Whoever runs the server needs to set the STAFF_PASSWORD environment variable first.
          </Notice>
        </div>
      )}

      <Form
        method="post"
        noValidate
        className="mt-6 space-y-5 rounded-xl border border-line bg-paper p-5 shadow-sm sm:p-6"
      >
        <input type="hidden" name="intent" value="sign-in" />
        <Field
          label="Password"
          name="password"
          type="password"
          autoComplete="current-password"
          error={error}
        />
        <button type="submit" className={primaryButton}>
          Sign in
        </button>
      </Form>
    </div>
  );
}

type Cancellation = { cancelled: string; found: boolean };

function Bookings({ groups, cancellation }: { groups: TastingBookings[]; cancellation?: Cancellation }) {
  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-3xl font-semibold text-wine-900 sm:text-4xl">Bookings</h1>
        <Form method="post">
          <input type="hidden" name="intent" value="sign-out" />
          <button type="submit" className={secondaryButton}>
            Sign out
          </button>
        </Form>
      </div>

      {cancellation && (
        <div className="mt-6">
          {cancellation.found ? (
            <Notice kind="success" title={`Booking ${cancellation.cancelled} cancelled`}>
              Its seats are free again.
            </Notice>
          ) : (
            <Notice kind="info" title={`Booking ${cancellation.cancelled} was already cancelled`} />
          )}
        </div>
      )}

      <div className="mt-8 space-y-8">
        {groups.map(({ tasting, bookings }) => (
          <section key={tasting.slug} aria-labelledby={`tasting-${tasting.slug}`}>
            <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 border-b border-line pb-2">
              <h2
                id={`tasting-${tasting.slug}`}
                className="font-display text-2xl font-semibold text-wine-800"
              >
                {tasting.title}
              </h2>
              <p className="text-sm text-muted">
                <TastingWhen tasting={tasting} /> &middot;{" "}
                {formatSeatsBooked(tasting.seats, tasting.seatsLeft)}
              </p>
            </div>

            {bookings.length === 0 ? (
              <p className="mt-4 rounded-lg border border-dashed border-line bg-paper px-4 py-5 text-muted">
                No bookings yet
              </p>
            ) : (
              <ul className="mt-4 space-y-3">
                {bookings.map((booking) => (
                  <li
                    key={booking.reference}
                    className="rounded-lg border border-line bg-paper p-4 shadow-sm"
                  >
                    <div className="flex flex-wrap items-end justify-between gap-4">
                      <dl className="grid flex-1 gap-x-6 gap-y-2 sm:grid-cols-[1.2fr_1.6fr_auto_auto]">
                        <Detail term="Name">
                          <span className="font-medium">{booking.name}</span>
                        </Detail>
                        <Detail term="Email">
                          <span className="break-all">{booking.email}</span>
                        </Detail>
                        <Detail term="Guests">{booking.guests}</Detail>
                        <Detail term="Booking reference">
                          <span className="font-mono font-semibold tracking-wider text-wine-800">
                            {booking.reference}
                          </span>
                        </Detail>
                      </dl>
                      <Form method="post">
                        <input type="hidden" name="intent" value="cancel" />
                        <input type="hidden" name="reference" value={booking.reference} />
                        <button type="submit" className={dangerButton}>
                          Cancel
                        </button>
                      </Form>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </div>
    </>
  );
}

function Detail({ term, children }: { term: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-wide text-muted">{term}</dt>
      <dd>{children}</dd>
    </div>
  );
}
