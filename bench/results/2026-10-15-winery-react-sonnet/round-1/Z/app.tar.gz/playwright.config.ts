import { defineConfig, devices } from "@playwright/test";

// Every test starts its own production server (see tests/fixtures.ts), so there
// is no shared `webServer` here. Run `npm run build` first (`npm test` does).
export default defineConfig({
  testDir: "./tests",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  reporter: [["list"]],
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"] } },
    { name: "phone", use: { ...devices["Pixel 7"] } },
  ],
});
