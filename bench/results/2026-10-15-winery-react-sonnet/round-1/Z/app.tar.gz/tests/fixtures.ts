import { test as base, expect } from "@playwright/test";
import { spawn, type ChildProcess } from "node:child_process";
import { resolve } from "node:path";
import { createServer } from "node:net";

const serveBin = resolve("node_modules/.bin/react-router-serve");

export const STAFF_PASSWORD = "riesling-2026";

type Options = {
  /** Value of STAFF_PASSWORD for the server under test; "" leaves it unset. */
  staffPassword: string;
};

type Fixtures = {
  server: { url: string };
};

function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const probe = createServer();
    probe.once("error", reject);
    probe.listen(0, "127.0.0.1", () => {
      const { port } = probe.address() as { port: number };
      probe.close(() => resolve(port));
    });
  });
}

async function waitUntilServing(url: string, child: ChildProcess) {
  const deadline = Date.now() + 20_000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error("server exited during start");
    try {
      await fetch(url);
      return;
    } catch {
      await new Promise((r) => setTimeout(r, 100));
    }
  }
  throw new Error(`server did not start at ${url}`);
}

/**
 * The one test seam: the built production app, started fresh (no bookings) on
 * its own port for every test, driven through a real browser.
 */
export const test = base.extend<Fixtures & Options>({
  staffPassword: [STAFF_PASSWORD, { option: true }],

  server: async ({ staffPassword }, use) => {
    const port = await freePort();
    const env: NodeJS.ProcessEnv = { ...process.env, PORT: String(port), NODE_ENV: "production" };
    if (staffPassword) env.STAFF_PASSWORD = staffPassword;
    else delete env.STAFF_PASSWORD;

    const child = spawn(serveBin, ["./build/server/index.js"], {
      env,
      stdio: "ignore",
    });
    const url = `http://127.0.0.1:${port}`;
    try {
      await waitUntilServing(url, child);
      await use({ url });
    } finally {
      child.kill();
    }
  },

  baseURL: async ({ server }, use) => {
    await use(server.url);
  },
});

export { expect };
