import { test, expect } from "./fixtures";
import { book, makeBooking, seatsLeftText } from "./helpers";

test("guest books three seats and sees a confirmation with a reference", async ({ page }) => {
  await book(page, {
    tasting: "Riesling Evening",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "3",
  });

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  const confirmation = page.getByRole("main");
  await expect(confirmation).toContainText("Riesling Evening");
  await expect(confirmation).toContainText("2026-11-06 18:00");
  await expect(confirmation.getByText("Guests", { exact: true })).toBeVisible();
  await expect(confirmation).toContainText(/Guests\s*3/);
  await expect(confirmation).toContainText("EUR 75");
  await expect(confirmation).toContainText(/KB-[A-Z0-9]{6}/);
});

test("the confirmation survives a reload and does not book again", async ({ page }) => {
  const reference = await makeBooking(page, {
    tasting: "Winter Tasting",
    name: "Ben Fischer",
    email: "ben@example.com",
    guests: "2",
  });

  await page.reload();

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  await expect(page.getByRole("main")).toContainText(reference);
  expect(await seatsLeftText(page, "Winter Tasting")).toBe("8 seats left");
});

test("booking takes seats from that tasting only", async ({ page }) => {
  await book(page, {
    tasting: "Riesling Evening",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "3",
  });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  expect(await seatsLeftText(page, "Riesling Evening")).toBe("9 seats left");
  expect(await seatsLeftText(page, "Red Wine Cellar Tour")).toBe("8 seats left");
  expect(await seatsLeftText(page, "Winter Tasting")).toBe("10 seats left");
});

test("every booking gets its own reference", async ({ page }) => {
  const references: string[] = [];
  for (const name of ["Anna", "Ben"]) {
    references.push(
      await makeBooking(page, {
        tasting: "Riesling Evening",
        name,
        email: `${name}@example.com`,
        guests: "1",
      }),
    );
  }
  expect(references[0]).not.toBe(references[1]);
});

test("the booking form names the tasting being booked", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Book Red Wine Cellar Tour" }).click();

  await expect(page.getByRole("heading", { level: 1 })).toContainText("Red Wine Cellar Tour");
  await expect(page.getByRole("main")).toContainText("2026-11-14 15:00");
  await expect(page.getByRole("main")).toContainText("EUR 32");
});

test("unknown tastings and bookings show a friendly not-found page", async ({ page }) => {
  const missingTasting = await page.goto("/tastings/no-such-tasting/book");
  expect(missingTasting?.status()).toBe(404);
  await expect(page.getByRole("heading", { name: "We couldn't find that page" })).toBeVisible();

  const missingBooking = await page.goto("/bookings/KB-ZZZZZZ");
  expect(missingBooking?.status()).toBe(404);
  await expect(page.getByRole("heading", { name: "We couldn't find that page" })).toBeVisible();
});
