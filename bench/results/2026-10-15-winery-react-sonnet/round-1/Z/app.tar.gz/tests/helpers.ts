import { expect, type Page } from "@playwright/test";
import { STAFF_PASSWORD } from "./fixtures";

export type BookingDetails = { tasting: string; name: string; email: string; guests: string };

/** Opens a tasting's booking form from the start page, fills it in and submits. */
export async function book(page: Page, { tasting, name, email, guests }: BookingDetails) {
  await page.goto("/");
  await page.getByRole("link", { name: `Book ${tasting}` }).click();
  await page.getByLabel("Name").fill(name);
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Guests").fill(guests);
  await page.getByRole("button", { name: "Book" }).click();
}

/** Books, waits for the confirmation and returns the booking reference shown on it. */
export async function makeBooking(page: Page, details: BookingDetails): Promise<string> {
  await book(page, details);
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  return (await page.getByRole("main").textContent())!.match(/KB-[A-Z0-9]{6}/)![0];
}

/** Submits the staff sign-in form with the given password, without checking the outcome. */
export async function attemptStaffSignIn(page: Page, password: string) {
  await page.goto("/staff");
  await page.getByLabel("Password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
}

/** Signs in on /staff with the right password and waits until the bookings are shown. */
export async function signInAsStaff(page: Page) {
  await attemptStaffSignIn(page, STAFF_PASSWORD);
  await expect(page.getByRole("button", { name: "Sign out" })).toBeVisible();
}

/** Reads "<n> seats left" for one tasting from the start page. */
export async function seatsLeftText(page: Page, tasting: string) {
  await page.goto("/");
  const card = page.getByRole("article").filter({ hasText: tasting });
  await expect(card).toBeVisible();
  return (await card.textContent())?.match(/\d+ seats left/)?.[0];
}
