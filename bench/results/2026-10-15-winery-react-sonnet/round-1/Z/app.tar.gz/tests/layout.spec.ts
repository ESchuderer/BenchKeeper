import type { Page } from "@playwright/test";
import { test, expect } from "./fixtures";
import { makeBooking, signInAsStaff } from "./helpers";

async function expectNoSidewaysScroll(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow, "page is wider than the viewport").toBeLessThanOrEqual(0);
}

/** Every button, input and link in the page's main area is at least 44px tall, the usual touch minimum. */
async function expectComfortableTapTargets(page: Page) {
  const targets = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>("main button, main input:not([type=hidden]), main a")].map(
      (el) => ({
        name: el.textContent?.trim() || el.getAttribute("name") || el.tagName,
        height: el.getBoundingClientRect().height,
      }),
    ),
  );
  expect(targets.length, "no tap targets found to check").toBeGreaterThan(0);
  expect(targets.filter(({ height }) => height < 44)).toEqual([]);
}

async function expectPageFits(page: Page) {
  await expectNoSidewaysScroll(page);
  await expectComfortableTapTargets(page);
}

const BIG_PARTY = { name: "Anna Weber", email: "anna@example.com", guests: "8" };

test("start page fits the screen", async ({ page }) => {
  await page.goto("/");
  await expectPageFits(page);
});

test("booking form, with errors and a very long email, fits the screen", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Book Riesling Evening" }).click();
  await expect(page.getByLabel("Name")).toBeVisible();
  await expectPageFits(page);

  await page
    .getByLabel("Email")
    .fill("anna-with-a-rather-long-address-for-testing@example-winery-guests.example.com");
  await page.getByRole("button", { name: "Book" }).click();
  await expect(page.getByText("Please enter your name.")).toBeVisible();
  await expectPageFits(page);
});

test("confirmation fits the screen", async ({ page }) => {
  await makeBooking(page, { tasting: "Riesling Evening", ...BIG_PARTY });
  await expectPageFits(page);
});

test("fully booked start page and booking page fit the screen", async ({ page }) => {
  await makeBooking(page, { tasting: "Red Wine Cellar Tour", ...BIG_PARTY });

  await page.goto("/");
  await expectPageFits(page);
  await page.getByRole("link", { name: "Book Red Wine Cellar Tour" }).click();
  await expect(page.getByRole("main")).toContainText("fully booked");
  await expectPageFits(page);
});

test("staff sign-in and bookings fit the screen", async ({ page }) => {
  await page.goto("/staff");
  await expectPageFits(page);

  await makeBooking(page, { tasting: "Riesling Evening", ...BIG_PARTY });
  await signInAsStaff(page);
  await expectPageFits(page);
});

test("not-found page fits the screen", async ({ page }) => {
  await page.goto("/no-such-page");
  await expectPageFits(page);
});

test("the start page and booking form fit a very narrow phone", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 640 });

  await page.goto("/");
  await expectNoSidewaysScroll(page);

  await page.getByRole("link", { name: "Book Red Wine Cellar Tour" }).click();
  await expect(page.getByLabel("Name")).toBeVisible();
  await expectNoSidewaysScroll(page);
});
