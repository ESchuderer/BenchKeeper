import { test, expect } from "./fixtures";
import { makeBooking, seatsLeftText, signInAsStaff } from "./helpers";

test("cancelling a booking removes it and frees its seats", async ({ page }) => {
  const reference = await makeBooking(page, {
    tasting: "Riesling Evening",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "3",
  });
  await makeBooking(page, {
    tasting: "Riesling Evening",
    name: "Ben Fischer",
    email: "ben@example.com",
    guests: "2",
  });
  expect(await seatsLeftText(page, "Riesling Evening")).toBe("7 seats left");

  await signInAsStaff(page);
  await page
    .getByRole("listitem")
    .filter({ hasText: "Anna Weber" })
    .getByRole("button", { name: "Cancel" })
    .click();

  await expect(page.getByRole("status")).toContainText(`${reference} cancelled`);
  await expect(page.getByRole("main")).not.toContainText("Anna Weber");
  await expect(page.getByRole("main")).toContainText("Ben Fischer");
  await expect(page.getByRole("region", { name: "Riesling Evening" })).toContainText("2 of 12 seats booked");
  expect(await seatsLeftText(page, "Riesling Evening")).toBe("10 seats left");
});

test("a fully booked tasting can be booked again after a cancellation", async ({ page }) => {
  await makeBooking(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "8",
  });
  await page.goto("/");
  await expect(page.getByRole("article").filter({ hasText: "Red Wine Cellar Tour" })).toContainText(
    "Fully booked",
  );

  await signInAsStaff(page);
  await page.getByRole("button", { name: "Cancel" }).click();
  await expect(page.getByRole("status")).toBeVisible();

  await page.goto("/");
  const card = page.getByRole("article").filter({ hasText: "Red Wine Cellar Tour" });
  await expect(card).not.toContainText("Fully booked");
  await expect(card).toContainText("8 seats left");
  await makeBooking(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Ben Fischer",
    email: "ben@example.com",
    guests: "8",
  });
});

test("the confirmation of a cancelled booking is gone", async ({ page }) => {
  await makeBooking(page, {
    tasting: "Winter Tasting",
    name: "Cleo Braun",
    email: "cleo@example.com",
    guests: "2",
  });
  const confirmationUrl = page.url();

  await signInAsStaff(page);
  await page.getByRole("button", { name: "Cancel" }).click();
  await expect(page.getByRole("status")).toBeVisible();

  const response = await page.goto(confirmationUrl);
  expect(response?.status()).toBe(404);
});

test("a cancel request without a staff session is refused and changes nothing", async ({
  page,
  request,
  baseURL,
}) => {
  const reference = await makeBooking(page, {
    tasting: "Winter Tasting",
    name: "Cleo Braun",
    email: "cleo@example.com",
    guests: "2",
  });

  const response = await request.post(`${baseURL}/staff`, {
    form: { intent: "cancel", reference },
    maxRedirects: 0,
  });

  expect(response.status()).toBe(403);
  expect(await seatsLeftText(page, "Winter Tasting")).toBe("8 seats left");
});
