import { test, expect } from "./fixtures";
import { attemptStaffSignIn, makeBooking, signInAsStaff } from "./helpers";

test("the staff page asks for a password", async ({ page }) => {
  await page.goto("/staff");

  await expect(page.getByLabel("Password")).toBeVisible();
  await expect(page.getByRole("button", { name: "Sign in" })).toBeVisible();
  await expect(page.getByLabel("Password")).toHaveAttribute("type", "password");
});

test("a wrong password is rejected next to the Password field", async ({ page }) => {
  await attemptStaffSignIn(page, "not-the-password");

  const field = page.getByLabel("Password");
  await expect(field).toHaveAttribute("aria-invalid", "true");
  await expect(field).toHaveAccessibleDescription(/Incorrect password\./);
  await expect(page.getByRole("button", { name: "Sign in" })).toBeVisible();
  await expect(page.getByRole("button", { name: "Sign out" })).toHaveCount(0);
});

test("signed-in staff see bookings grouped by tasting", async ({ page, context }) => {
  const guest = await context.newPage();
  const annaRef = await makeBooking(guest, {
    tasting: "Riesling Evening",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "3",
  });
  const benRef = await makeBooking(guest, {
    tasting: "Riesling Evening",
    name: "Ben Fischer",
    email: "ben@example.com",
    guests: "2",
  });
  const cleoRef = await makeBooking(guest, {
    tasting: "Winter Tasting",
    name: "Cleo Braun",
    email: "cleo@example.com",
    guests: "4",
  });

  await signInAsStaff(page);

  const riesling = page.getByRole("region", { name: "Riesling Evening" });
  await expect(riesling).toContainText("5 of 12 seats booked");
  await expect(riesling).toContainText("Anna Weber");
  await expect(riesling).toContainText("anna@example.com");
  await expect(riesling).toContainText(annaRef);
  await expect(riesling).toContainText("Ben Fischer");
  await expect(riesling).toContainText("ben@example.com");
  await expect(riesling).toContainText(benRef);
  await expect(riesling).not.toContainText("Cleo Braun");

  const winter = page.getByRole("region", { name: "Winter Tasting" });
  await expect(winter).toContainText("4 of 10 seats booked");
  await expect(winter).toContainText("Cleo Braun");
  await expect(winter).toContainText(cleoRef);

  const cellar = page.getByRole("region", { name: "Red Wine Cellar Tour" });
  await expect(cellar).toContainText("No bookings yet");
});

test("each booking lists its number of guests", async ({ page, context }) => {
  const guest = await context.newPage();
  await makeBooking(guest, {
    tasting: "Winter Tasting",
    name: "Cleo Braun",
    email: "cleo@example.com",
    guests: "4",
  });

  await signInAsStaff(page);

  const row = page.getByRole("listitem").filter({ hasText: "Cleo Braun" });
  await expect(row.getByText("Guests", { exact: true })).toBeVisible();
  await expect(row).toContainText(/Guests\s*4/);
});

test("staff stay signed in across page loads until they sign out", async ({ page }) => {
  await signInAsStaff(page);
  await expect(page.getByRole("button", { name: "Sign out" })).toBeVisible();

  await page.reload();
  await expect(page.getByRole("button", { name: "Sign out" })).toBeVisible();
  await page.goto("/");
  await page.goto("/staff");
  await expect(page.getByRole("button", { name: "Sign out" })).toBeVisible();

  await page.getByRole("button", { name: "Sign out" }).click();

  await expect(page.getByLabel("Password")).toBeVisible();
  await page.reload();
  await expect(page.getByLabel("Password")).toBeVisible();
});

test("booking details are not visible without signing in", async ({ page }) => {
  await makeBooking(page, {
    tasting: "Winter Tasting",
    name: "Cleo Braun",
    email: "cleo@example.com",
    guests: "4",
  });
  await expect(page.getByRole("main")).not.toContainText("Cleo Braun");
  await expect(page.getByRole("main")).not.toContainText("cleo@example.com");

  await page.goto("/staff");

  await expect(page.getByLabel("Password")).toBeVisible();
  await expect(page.locator("body")).not.toContainText("Cleo Braun");
  await expect(page.locator("body")).not.toContainText("cleo@example.com");
});

test.describe("when no staff password is configured", () => {
  test.use({ staffPassword: "" });

  test("nobody can sign in, not even with an empty password", async ({ page }) => {
    await page.goto("/staff");
    await expect(page.getByRole("main")).toContainText("not set up");

    await page.getByRole("button", { name: "Sign in" }).click();
    await expect(page.getByRole("button", { name: "Sign out" })).toHaveCount(0);

    await page.getByLabel("Password").fill("anything");
    await page.getByRole("button", { name: "Sign in" }).click();
    await expect(page.getByRole("button", { name: "Sign out" })).toHaveCount(0);
  });
});

test("signing out ends the session for good, even if the old cookie is replayed", async ({
  page,
  context,
}) => {
  await signInAsStaff(page);
  await expect(page.getByRole("button", { name: "Sign out" })).toBeVisible();
  const [signedInCookie] = (await context.cookies()).filter((cookie) => cookie.httpOnly);

  await page.getByRole("button", { name: "Sign out" }).click();
  await expect(page.getByLabel("Password")).toBeVisible();

  await context.addCookies([signedInCookie]);
  await page.goto("/staff");

  await expect(page.getByLabel("Password")).toBeVisible();
  await expect(page.getByRole("button", { name: "Sign out" })).toHaveCount(0);
});
