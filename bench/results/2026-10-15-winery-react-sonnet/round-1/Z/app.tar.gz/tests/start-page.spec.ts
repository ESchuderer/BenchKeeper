import { test, expect } from "./fixtures";

test("start page lists the tastings with date, price and seats left", async ({ page }) => {
  await page.goto("/");

  await expect(page.getByRole("heading", { level: 1 })).toContainText("Kieselbrunnen");

  const riesling = page.getByRole("article").filter({ hasText: "Riesling Evening" });
  await expect(riesling).toContainText("2026-11-06 18:00");
  await expect(riesling).toContainText("EUR 25");
  await expect(riesling).toContainText("12 seats left");
  await expect(riesling.getByRole("link", { name: "Book Riesling Evening" })).toBeVisible();

  const cellar = page.getByRole("article").filter({ hasText: "Red Wine Cellar Tour" });
  await expect(cellar).toContainText("2026-11-14 15:00");
  await expect(cellar).toContainText("EUR 32");
  await expect(cellar).toContainText("8 seats left");
  await expect(cellar.getByRole("link", { name: "Book Red Wine Cellar Tour" })).toBeVisible();

  const winter = page.getByRole("article").filter({ hasText: "Winter Tasting" });
  await expect(winter).toContainText("2026-12-05 17:00");
  await expect(winter).toContainText("EUR 28");
  await expect(winter).toContainText("10 seats left");
  await expect(winter.getByRole("link", { name: "Book Winter Tasting" })).toBeVisible();
});

test("the server-rendered start page already contains the text, without JavaScript", async ({ request }) => {
  const html = await (await request.get("/")).text();

  for (const text of [
    "Riesling Evening",
    "2026-11-06 18:00",
    "EUR 25",
    "12 seats left",
    "Book Riesling Evening",
    "Book Red Wine Cellar Tour",
    "Book Winter Tasting",
  ]) {
    expect(html, text).toContain(text);
  }
});
