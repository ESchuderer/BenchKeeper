import type { Page } from "@playwright/test";
import { test, expect } from "./fixtures";
import { book, seatsLeftText } from "./helpers";

async function openForm(page: Page, tasting: string) {
  await page.goto("/");
  await page.getByRole("link", { name: `Book ${tasting}` }).click();
}

function escapeRegExp(text: string) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, (char) => `\\${char}`);
}

async function expectErrorNextTo(page: Page, field: string, message: string | RegExp) {
  const input = page.getByLabel(field);
  await expect(input).toHaveAttribute("aria-invalid", "true");
  await expect(input).toHaveAccessibleDescription(
    typeof message === "string" ? new RegExp(escapeRegExp(message)) : message,
  );
  await expect(page.getByRole("main").getByText(message)).toBeVisible();
}

test("an empty name is rejected next to the Name field", async ({ page }) => {
  await book(page, { tasting: "Riesling Evening", name: "   ", email: "anna@example.com", guests: "2" });

  await expectErrorNextTo(page, "Name", "Please enter your name.");
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toHaveCount(0);
  expect(await seatsLeftText(page, "Riesling Evening")).toBe("12 seats left");
});

for (const email of ["", "anna", "anna@", "anna@example", "a b@example.com"]) {
  test(`email ${JSON.stringify(email)} is rejected next to the Email field`, async ({ page }) => {
    await book(page, { tasting: "Riesling Evening", name: "Anna Weber", email, guests: "2" });

    await expectErrorNextTo(
      page,
      "Email",
      email === "" ? "Please enter your email address." : "Please enter a valid email address.",
    );
    expect(await seatsLeftText(page, "Riesling Evening")).toBe("12 seats left");
  });
}

for (const guests of ["0", "-1", "2.5", "9", "1e1"]) {
  test(`guests ${JSON.stringify(guests)} is rejected next to the Guests field`, async ({ page }) => {
    await book(page, { tasting: "Riesling Evening", name: "Anna Weber", email: "anna@example.com", guests });

    await expectErrorNextTo(page, "Guests", "Guests must be a whole number from 1 to 8.");
    expect(await seatsLeftText(page, "Riesling Evening")).toBe("12 seats left");
  });
}

test("a missing number of guests is rejected next to the Guests field", async ({ page }) => {
  await book(page, {
    tasting: "Riesling Evening",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "",
  });

  await expectErrorNextTo(page, "Guests", "Please enter the number of guests.");
});

test("each wrong field gets its own message at once, and what was typed is kept", async ({ page }) => {
  await book(page, { tasting: "Riesling Evening", name: "", email: "anna@example.com", guests: "0" });

  await expectErrorNextTo(page, "Name", "Please enter your name.");
  await expectErrorNextTo(page, "Guests", "Guests must be a whole number from 1 to 8.");
  await expect(page.getByLabel("Email")).toHaveValue("anna@example.com");
  await expect(page.getByLabel("Email")).not.toHaveAttribute("aria-invalid", "true");
  await expect(page.getByLabel("Guests")).toHaveValue("0");
});

test("a corrected form can be submitted after an error", async ({ page }) => {
  await book(page, { tasting: "Riesling Evening", name: "Anna Weber", email: "nope", guests: "2" });
  await expectErrorNextTo(page, "Email", "Please enter a valid email address.");

  await page.getByLabel("Email").fill("anna@example.com");
  await page.getByRole("button", { name: "Book" }).click();

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
});

test("a booking can not take more seats than are left", async ({ page }) => {
  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "6",
  });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Ben Fischer",
    email: "ben@example.com",
    guests: "3",
  });

  await expectErrorNextTo(page, "Guests", "Only 2 seats left for this tasting.");
  expect(await seatsLeftText(page, "Red Wine Cellar Tour")).toBe("2 seats left");
});

test("the last seats can still be booked exactly", async ({ page }) => {
  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "6",
  });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Ben Fischer",
    email: "ben@example.com",
    guests: "2",
  });

  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();
  expect(await seatsLeftText(page, "Red Wine Cellar Tour")).toBe("0 seats left");
});

test("a fully booked tasting is marked clearly and can not be booked", async ({ page }) => {
  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "8",
  });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await page.goto("/");
  const card = page.getByRole("article").filter({ hasText: "Red Wine Cellar Tour" });
  await expect(card).toContainText("Fully booked");
  await expect(card).toContainText("0 seats left");
  await expect(page.getByRole("article").filter({ hasText: "Winter Tasting" })).not.toContainText(
    "Fully booked",
  );

  await card.getByRole("link", { name: "Book Red Wine Cellar Tour" }).click();
  await expect(page.getByRole("main")).toContainText("fully booked");
  await expect(page.getByRole("button", { name: "Book" })).toHaveCount(0);
});

test("a form opened before the tasting filled up is refused on submit", async ({ page, context }) => {
  await openForm(page, "Red Wine Cellar Tour");
  await page.getByLabel("Name").fill("Late Larry");
  await page.getByLabel("Email").fill("larry@example.com");
  await page.getByLabel("Guests").fill("1");

  const other = await context.newPage();
  await book(other, {
    tasting: "Red Wine Cellar Tour",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "8",
  });
  await expect(other.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await page.getByRole("button", { name: "Book" }).click();

  await expectErrorNextTo(page, "Guests", "This tasting is fully booked.");
  expect(await seatsLeftText(page, "Red Wine Cellar Tour")).toBe("0 seats left");
});

test("a direct post to a fully booked tasting is refused", async ({ page, request, baseURL }) => {
  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "8",
  });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  const response = await request.post(`${baseURL}/tastings/red-wine-cellar-tour/book`, {
    form: { name: "Sneaky", email: "sneaky@example.com", guests: "1" },
    maxRedirects: 0,
  });

  expect(response.status()).toBeGreaterThanOrEqual(400);
  expect(await seatsLeftText(page, "Red Wine Cellar Tour")).toBe("0 seats left");
});

test("simultaneous bookings never sell more seats than exist", async ({ page, request, baseURL }) => {
  const attempts = Array.from({ length: 20 }, (_, i) =>
    request.post(`${baseURL}/tastings/red-wine-cellar-tour/book`, {
      form: { name: `Guest ${i}`, email: `guest${i}@example.com`, guests: "1" },
      maxRedirects: 0,
    }),
  );
  const responses = await Promise.all(attempts);

  const accepted = responses.filter((r) => r.status() >= 300 && r.status() < 400);
  expect(accepted).toHaveLength(8);
  expect(await seatsLeftText(page, "Red Wine Cellar Tour")).toBe("0 seats left");
});

test("the seat limit is reported even when another field is also wrong", async ({ page }) => {
  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "6",
  });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await book(page, { tasting: "Red Wine Cellar Tour", name: "", email: "ben@example.com", guests: "5" });

  await expectErrorNextTo(page, "Name", "Please enter your name.");
  await expectErrorNextTo(page, "Guests", "Only 2 seats left for this tasting.");
});

test("the seat limit message reads naturally for a single seat", async ({ page }) => {
  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Anna Weber",
    email: "anna@example.com",
    guests: "7",
  });
  await expect(page.getByRole("heading", { name: "Booking confirmed" })).toBeVisible();

  await book(page, {
    tasting: "Red Wine Cellar Tour",
    name: "Ben Fischer",
    email: "ben@example.com",
    guests: "2",
  });

  await expectErrorNextTo(page, "Guests", "Only 1 seat left for this tasting.");
});
