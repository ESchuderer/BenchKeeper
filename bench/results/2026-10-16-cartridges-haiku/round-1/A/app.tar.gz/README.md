# C.I.P. cartridges

A static reference for 25 C.I.P. cartridges, for reloaders, gunsmiths and engineers.
Modelled on the cartridge database of [OpenBallistics](https://openreloading.github.io/OpenBallistics/).
The data is the 25 OpenBallistics records (MIT, commit e83db43), copied unchanged into `data/cartridges.js`.

## Open it

- Double-click `index.html`. It works from `file://` in Chromium, with no server.
- Or serve the folder with any static file server.

The app has no build step, no framework and no runtime dependencies. It makes no network requests.

## Tests

```sh
npm install
npm test                 # unit tests (Node 22, node:test)
npm run test:browser     # end-to-end checks in headless Chromium (needs playwright-core's Chromium)
```

One-time browser install for the end-to-end checks: `npx playwright-core install chromium`.

The unit tests cover the value formatting, search and routing, the drawing rules for all 25
cartridges (hand-checked values for several), and label placement: no label overlaps another
label or any drawn line. The browser tests cover file:// loading, search, the family filter,
addresses and reloads, the one-page A4 print, dark mode and a phone-width layout.

## Layout

| Path | Purpose |
| --- | --- |
| `index.html`, `styles.css` | page shell, styles (light and dark, print) |
| `data/cartridges.js` | the 25 records |
| `js/format.js` | value, tolerance, angle, symbol and unit formatting; the grouped tables |
| `js/catalog.js` | search, family filter, count text, `#/cartridge/<key>` routes |
| `js/geometry.js` | the drawing rules: rim type, groove, body, shoulder, neck, bullet, walls, pocket |
| `js/drawing.js` | the drawing as data (lines, areas, label boxes) and its inline SVG |
| `js/app.js` | the page: list and detail views |
| `test/unit`, `test/browser` | tests |

## Decisions where the brief left room

- Rule points are read as `(r, z)`, as the brief writes them (`(R1/2, R)` is radius R1/2 at z = R).
- A belted ramp at angle δ to the axis rises Δz = Δr / tan δ.
- A straight case (no α, L1 or L2) has its wall taper linearly from tb at the body start to tn at the mouth.
- A heeled bullet (H2 − G1 ≤ 0.015) is drawn exposed at diameter H2 and seated at H2 − 2·tb.
- The shoulder angle α is labelled with a leader, not drawn as an arc (an arc centred on the
  shoulder's apex would sit inside the mouth).
- Units not named in the brief are taken as mm for lengths (including `u`, `s`, `Fe`, `deltaL`,
  `G`, `b`, `h`) and `—` for angles and counts, since an angle's value already carries its `°`.
- The title block says "Scale 1:1 nominal, fitted to width": the drawing is true to scale in mm
  and scales to the page; the 10 mm bar shows the scale on any copy.
- Anything a rule needs but the record lacks is named under the drawing ("Note: …") and left out.
