/*
 * Page wiring: the cartridge list (search, family filter, count) and the
 * detail view for the route #/cartridge/<key>. The DOM is built here; the
 * values, the search rules and the drawing come from the other scripts.
 */
(function () {
  'use strict';

  var CIP = window.CIP;
  var format = CIP.format;
  var catalog = CIP.catalog;
  var drawing = CIP.drawing;
  var records = window.CIP_CARTRIDGES;
  var SITE_TITLE = 'C.I.P. cartridges';

  var listView = document.getElementById('list-view');
  var detailView = document.getElementById('detail-view');
  var search = document.getElementById('search');
  var family = document.getElementById('family');
  var count = document.getElementById('count');
  var rows = document.getElementById('cartridge-rows');

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (name) {
      if (name === 'text') {
        node.textContent = attrs[name];
      } else {
        node.setAttribute(name, attrs[name]);
      }
    });
    (children || []).forEach(function (child) {
      node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
    });
    return node;
  }

  function l3Text(record) {
    var lengths = record.cartridge.lengths;
    var text = String(lengths.L3);
    if (lengths.L3Tol !== undefined) {
      text += ' ' + String(lengths.L3Tol);
    }
    return text + ' mm';
  }

  function renderList() {
    var found = catalog.filterCartridges(records, { query: search.value, family: family.value });
    var rowNodes = found.map(function (record) {
      return el('tr', {}, [
        el('td', {}, [el('a', { href: catalog.routeFor(record.key), text: record.name })]),
        el('td', { text: record.family }),
        el('td', { class: 'num', text: l3Text(record) })
      ]);
    });
    rows.replaceChildren.apply(rows, rowNodes);
    count.textContent = catalog.countText(found.length);
  }

  function factRow(term, description) {
    return el('div', {}, [el('dt', { text: term }), el('dd', {}, Array.isArray(description) ? description : [description])]);
  }

  function capacityNodes(record) {
    var capacity = record.annotations.publishedCapacity;
    if (!capacity) {
      return ['—'];
    }
    var text = String(capacity.grH2O) + ' gr H₂O';
    var nodes = [document.createTextNode(text + ' · source ')];
    if (capacity.url) {
      nodes.push(el('a', { href: capacity.url, rel: 'noopener', text: capacity.source }));
    } else {
      nodes.push(document.createTextNode(capacity.source));
    }
    if (capacity.note) {
      nodes.push(document.createTextNode(' (' + capacity.note + ')'));
    }
    return nodes;
  }

  function valuesTable(section) {
    var body = section.rows.map(function (row) {
      return el('tr', {}, [
        el('th', { scope: 'row', text: row.symbol }),
        el('td', { class: 'num', text: row.value }),
        el('td', { class: 'unit', text: row.unit })
      ]);
    });
    return el('table', { class: 'values' }, [
      el('thead', {}, [el('tr', {}, [
        el('th', { scope: 'col', text: 'Symbol' }),
        el('th', { scope: 'col', class: 'num', text: 'Value' }),
        el('th', { scope: 'col', text: 'Unit' })
      ])]),
      el('tbody', {}, body)
    ]);
  }

  function valueSections(record) {
    var sections = format.buildSections(record);
    var children = [];
    var scope = null;
    sections.forEach(function (section) {
      if (section.scope !== scope) {
        scope = section.scope;
        children.push(el('h2', { class: 'scope', text: section.scopeTitle + ' values' }));
      }
      children.push(el('section', { class: 'group' }, [
        el('h3', { text: section.title }),
        valuesTable(section)
      ]));
    });
    return children;
  }

  function parseSvg(markup) {
    var holder = document.createElement('template');
    holder.innerHTML = markup.trim();
    return holder.content.firstElementChild;
  }

  function renderDetail(record) {
    var ann = record.annotations;
    var names = record.alternativeNames && record.alternativeNames.length ? record.alternativeNames.join(', ') : '—';
    var heading = el('h1', { id: 'detail-heading', tabindex: '-1', text: record.name });
    var scene = drawing.buildScene(record);
    var figure = el('figure', { class: 'drawing' }, [
      parseSvg(drawing.renderSvg(scene))
    ]);
    var facts = el('dl', { class: 'facts' }, [
      factRow('Alternative names', names),
      factRow('Family', record.family),
      factRow('Category', ann.category),
      factRow('Primer type', ann.primerType),
      factRow('C.I.P. table', record.tab),
      factRow('Country', record.country),
      factRow('Published', record.published),
      factRow('Revised', record.revised),
      factRow('Pressure method', record.pressureMethod),
      factRow('Water capacity', capacityNodes(record))
    ]);
    var toolbar = el('div', { class: 'toolbar no-print' }, [
      el('a', { href: '#/', class: 'back', text: 'All cartridges' }),
      el('button', { type: 'button', class: 'print-button', text: 'Print', 'data-print': '' })
    ]);
    var footer = el('footer', { class: 'print-footer' }, [
      document.createTextNode('Source: C.I.P. TDCC, revised ' + record.revised + '. ' + record.name + '.')
    ]);
    return el('article', { class: 'detail', 'aria-labelledby': 'detail-heading' }, [
      toolbar,
      heading,
      facts,
      figure,
      el('div', { class: 'sections' }, valueSections(record)),
      footer
    ]);
  }

  function showList() {
    listView.hidden = false;
    detailView.hidden = true;
    detailView.replaceChildren();
    document.title = SITE_TITLE;
    renderList();
  }

  function showDetail(key) {
    var record = records.filter(function (r) { return r.key === key; })[0];
    listView.hidden = true;
    detailView.hidden = false;
    if (!record) {
      detailView.replaceChildren(el('article', { class: 'detail' }, [
        el('h1', { id: 'detail-heading', tabindex: '-1', text: 'Cartridge not found' }),
        el('p', {}, [document.createTextNode('No cartridge has the address ' + key + '. '),
          el('a', { href: '#/', text: 'All cartridges' })])
      ]));
      document.title = 'Not found · ' + SITE_TITLE;
    } else {
      detailView.replaceChildren(renderDetail(record));
      document.title = record.name + ' · ' + SITE_TITLE;
    }
    window.scrollTo(0, 0);
    var heading = document.getElementById('detail-heading');
    if (heading) {
      heading.focus({ preventScroll: true });
    }
  }

  function route() {
    var current = catalog.parseRoute(window.location.hash);
    if (current.view === 'detail') {
      showDetail(current.key);
    } else {
      showList();
    }
  }

  search.addEventListener('input', renderList);
  family.addEventListener('change', renderList);
  detailView.addEventListener('click', function (event) {
    if (event.target.closest && event.target.closest('[data-print]')) {
      window.print();
    }
  });
  window.addEventListener('hashchange', route);
  route();
})();
