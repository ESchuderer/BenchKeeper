/*
 * The cartridge list: search, family filter, ordering, the count text and
 * the hash routes (#/ for the list, #/cartridge/<key> for a detail view).
 * Pure functions, no DOM.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.catalog = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var DETAIL_PREFIX = '#/cartridge/';

  function normalise(text) {
    return String(text)
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  }

  function matchesQuery(record, query) {
    var needle = normalise(query);
    if (needle === '') {
      return true;
    }
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (name) {
      return normalise(name).indexOf(needle) !== -1;
    });
  }

  function sortByName(records) {
    return records.slice().sort(function (a, b) {
      return a.name.localeCompare(b.name, 'en', { numeric: true });
    });
  }

  function filterCartridges(records, options) {
    var family = options && options.family ? options.family : 'all';
    var query = options && options.query ? options.query : '';
    return sortByName(records).filter(function (record) {
      return (family === 'all' || record.family === family) && matchesQuery(record, query);
    });
  }

  function countText(n) {
    return n === 1 ? '1 cartridge' : n + ' cartridges';
  }

  function parseRoute(hash) {
    var text = String(hash || '');
    if (text.indexOf(DETAIL_PREFIX) === 0) {
      var raw = text.slice(DETAIL_PREFIX.length);
      var key = raw;
      try {
        key = decodeURIComponent(raw);
      } catch (error) {
        key = raw;
      }
      return { view: 'detail', key: key };
    }
    return { view: 'list' };
  }

  function routeFor(key) {
    return DETAIL_PREFIX + encodeURIComponent(key);
  }

  return {
    normalise: normalise,
    matchesQuery: matchesQuery,
    filterCartridges: filterCartridges,
    countText: countText,
    parseRoute: parseRoute,
    routeFor: routeFor
  };
});
