/*
 * The 2D cartridge drawing. buildScene() turns a record into drawing data in
 * mm (1 user unit = 1 mm, axis horizontal, head on the left): outline and
 * section polygons, dimension paths and label boxes. renderSvg() writes it as
 * inline SVG. Upper half: outside view; lower half: section with hatched walls.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.drawing = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var geometry = typeof require === 'function' ? require('./geometry.js') : globalThis.CIP.geometry;
  var format = typeof require === 'function' ? require('./format.js') : globalThis.CIP.format;

  var LABEL_SIZE = 3;
  var NOTE_SIZE = 2.4;
  var TITLE_SIZE = 3.2;
  var CHAR_WIDTH = 0.6; // em, generous for tabular digits
  var ARROW_LENGTH = 1.6;
  var ARROW_HALF_WIDTH = 0.5;
  var GAP = 1; // extension lines start this far off the outline
  var OVERSHOOT = 1; // and end this far past the dimension line
  var ROW_FIRST = 7; // first longitudinal dimension row below the outline
  var ROW_STEP = 8.5;
  var COLUMN_FIRST = 4; // first diameter column right of the bullet tip
  var COLUMN_STEP = 12.5;
  var DIAMETER_LABEL_SIZE = 2.8;
  var MARGIN = 2;

  var GROUP_OF = {
    R1: 'caseHead', R: 'caseHead', E1: 'caseHead',
    P1: 'powderChamber', P2: 'powderChamber',
    H1: 'collar', H2: 'collar',
    G1: 'projectile',
    L1: 'lengths', L2: 'lengths', L3: 'lengths', L6: 'lengths',
    alpha: 'junctionCone'
  };

  function measure(text, size) {
    return text.length * size * CHAR_WIDTH;
  }

  function boxFor(text, x, y, anchor, size) {
    var w = measure(text, size);
    var x0 = anchor === 'end' ? x - w : anchor === 'start' ? x : x - w / 2;
    return [x0, y - 0.75 * size, x0 + w, y + 0.25 * size];
  }

  function valueText(record, key) {
    var group = record.cartridge[GROUP_OF[key]];
    var value = group[key];
    var tol = group[key + 'Tol'];
    var text = format.symbolFor(key) + ' ' + format.formatValue(key, value);
    return tol === undefined ? text : text + ' ' + String(tol);
  }

  function escapeXml(text) {
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function buildScene(record) {
    var m = geometry.buildModel(record);
    var V = m.values;
    var F = m.features;
    var paths = [];
    var labels = [];

    function line(points, cls) {
      paths.push({ points: points, closed: false, cls: cls });
    }

    function polygon(points, cls) {
      paths.push({ points: points, closed: true, cls: cls });
    }

    function arrow(tip, inward) {
      var n = [-inward[1], inward[0]];
      var base = [tip[0] + inward[0] * ARROW_LENGTH, tip[1] + inward[1] * ARROW_LENGTH];
      polygon([
        tip,
        [base[0] + n[0] * ARROW_HALF_WIDTH, base[1] + n[1] * ARROW_HALF_WIDTH],
        [base[0] - n[0] * ARROW_HALF_WIDTH, base[1] - n[1] * ARROW_HALF_WIDTH]
      ], 'arrow');
    }

    function label(text, x, y, anchor, size, cls) {
      labels.push({ text: text, x: x, y: y, anchor: anchor, size: size, cls: cls, box: boxFor(text, x, y, anchor, size) });
    }

    var Rh = V.R1 / 2;
    var Rmax = Math.max.apply(null, m.outer.map(function (p) { return p[1]; }));
    if (m.bullet) {
      Rmax = Math.max(Rmax, m.bullet.Gx / 2);
    }
    var tipX = V.L6;

    // Outline: outside view in the upper half, from the axis at the head face to the tip.
    var outline = m.outer.map(function (p) { return [p[0], -p[1]]; });
    if (m.bullet) {
      m.bullet.exposed.forEach(function (p) {
        var q = [p[0], -p[1]];
        var last = outline[outline.length - 1];
        if (Math.abs(last[0] - q[0]) > 1e-9 || Math.abs(last[1] - q[1]) > 1e-9) {
          outline.push(q);
        }
      });
    }
    line(outline, 'outline');

    // Section: case walls in the lower half, with the primer pocket and the solid head.
    var section = [];
    var outerLower = m.outer.map(function (p) { return [p[0], p[1]]; });
    if (m.pocket) {
      section.push([0, m.pocket.diameter / 2]);
      outerLower.slice(1).forEach(function (p) { section.push(p); });
    } else {
      section = outerLower.slice();
    }
    for (var i = m.inner.length - 1; i >= 0; i -= 1) {
      section.push(m.inner[i]);
    }
    section.push([m.w, 0]);
    if (m.pocket) {
      section.push([m.pocket.depth, 0]);
      section.push([m.pocket.depth, m.pocket.diameter / 2]);
    }
    polygon(section, 'section');

    // Bullet: the seated part inside the case section, the exposed part beyond the mouth.
    if (m.bullet) {
      var bullet = m.bullet;
      var bulletSection = [[bullet.zb, 0], [bullet.zb, bullet.heelRadius], [V.L3, bullet.heelRadius]];
      bullet.exposed.forEach(function (p) { bulletSection.push(p); });
      polygon(bulletSection, 'bullet');
    }

    // Longitudinal dimensions, stacked below the lower outline, shortest nearest.
    var rows = [];
    if (V.R !== undefined) {
      rows.push({ key: 'R', to: V.R, feature: F.R, left: true });
    }
    if (F.L1) {
      rows.push({ key: 'L1', to: V.L1, feature: F.L1 });
    }
    if (F.L2) {
      rows.push({ key: 'L2', to: V.L2, feature: F.L2 });
    }
    rows.push({ key: 'L3', to: V.L3, feature: F.L3 });
    rows.push({ key: 'L6', to: V.L6, feature: F.L6 || [V.L6, 0] });

    var lastRowY = Rmax + ROW_FIRST + ROW_STEP * (rows.length - 1);
    line([[0, Rh + GAP], [0, lastRowY + OVERSHOOT]], 'ext');
    rows.forEach(function (row, index) {
      var y = Rmax + ROW_FIRST + ROW_STEP * index;
      var text = valueText(record, row.key);
      line([[0, y], [row.to, y]], 'dim');
      arrow([0, y], [1, 0]);
      arrow([row.to, y], [-1, 0]);
      line([[row.feature[0], row.feature[1] + GAP], [row.feature[0], y + OVERSHOOT]], 'ext');
      if (row.left) {
        label(text, -1.5, y + 0.9, 'end', LABEL_SIZE, 'dim-label');
      } else {
        // above the line, clear of the arrows and of the extension line at the far end;
        // below it when a long label would run into that extension line
        var half = measure(text, LABEL_SIZE) / 2;
        var cx = Math.max(row.to / 2, half + 2.5);
        var above = cx + half < row.to - 1.2;
        label(text, cx, above ? y - 1.6 : y + 3.75, 'middle', LABEL_SIZE, 'dim-label');
      }
    });

    // Head diameter, left of the head face.
    var headX = -6;
    line([[0, -Rh], [headX - OVERSHOOT, -Rh]], 'ext');
    line([[0, Rh], [headX - OVERSHOOT, Rh]], 'ext');
    line([[headX, -Rh], [headX, Rh]], 'dim');
    arrow([headX, -Rh], [0, 1]);
    arrow([headX, Rh], [0, -1]);
    label(valueText(record, 'R1'), headX - 1.5, 1.05, 'end', LABEL_SIZE, 'dim-label');

    // Diameters, in columns right of the tip, nearest the smallest radius.
    var diameters = [{ key: 'P1', feature: F.P1 }];
    if (F.P2) {
      diameters.push({ key: 'P2', feature: F.P2 });
    }
    if (F.H1) {
      diameters.push({ key: 'H1', feature: F.H1 });
    }
    diameters.push({ key: 'H2', feature: F.H2 });
    if (F.G1) {
      diameters.push({ key: 'G1', feature: F.G1 });
    }
    if (F.E1) {
      diameters.push({ key: 'E1', feature: F.E1 });
    }
    diameters = diameters.map(function (d, index) { return { key: d.key, feature: d.feature, order: index }; });
    diameters.sort(function (a, b) {
      return a.feature[1] - b.feature[1] || a.order - b.order;
    });
    diameters.forEach(function (d, index) {
      var x = tipX + COLUMN_FIRST + COLUMN_STEP * index;
      var rc = d.feature[1];
      var zf = d.feature[0];
      line([[zf, -rc], [x + OVERSHOOT, -rc]], 'ext');
      line([[zf, rc], [x + OVERSHOOT, rc]], 'ext');
      line([[x, -rc], [x, rc]], 'dim');
      arrow([x, -rc], [0, 1]);
      arrow([x, rc], [0, -1]);
      var level = index % 2;
      var baseline = -(Rmax + 4.5 + 4.5 * level);
      line([[x, -rc], [x, baseline + 1.2]], 'leader');
      label(valueText(record, d.key), x, baseline, 'middle', DIAMETER_LABEL_SIZE, 'dim-label');
    });

    // Shoulder angle, labelled above the shoulder.
    if (F.shoulderMid) {
      var zm = F.shoulderMid[0];
      var rm = F.shoulderMid[1];
      var alphaBase = -(Rmax + 4.5);
      line([[zm, -rm], [zm, alphaBase + 1.2]], 'leader');
      label(valueText(record, 'alpha'), zm, alphaBase, 'middle', DIAMETER_LABEL_SIZE, 'dim-label');
    }

    var axisEnd = Math.max(tipX + COLUMN_FIRST + COLUMN_STEP * diameters.length, tipX);
    line([[0, 0], [axisEnd, 0]], 'axis');

    // Title block beside the dimension rows, right of the tip (the rows end at the tip);
    // notes under the rows.
    var tbX = tipX + COLUMN_FIRST;
    var tbY = Rmax + 3;
    var tbW = 66;
    var tbH = 24;
    var titleBlock = {
      x: tbX,
      y: tbY,
      w: tbW,
      h: tbH,
      name: record.name,
      lines: [
        record.name,
        'C.I.P. table ' + record.tab + '  ·  revised ' + record.revised,
        'Dimensions in mm',
        'Scale 1:1 nominal, fitted to width'
      ],
      scaleBarMm: 10,
      scaleBarY: tbY + tbH - 3.5,
      scaleBarX: tbX + 3
    };
    var notesY = lastRowY + 4;
    var notes = m.missing.slice();
    var notesOut = notes.map(function (text, index) {
      return { text: text, x: 0, y: notesY + index * (NOTE_SIZE + 1.2) };
    });

    // The view box holds every drawn point, label box and the title block.
    var minX = Infinity;
    var minY = Infinity;
    var maxX = -Infinity;
    var maxY = -Infinity;
    function grow(x, y) {
      minX = Math.min(minX, x);
      maxX = Math.max(maxX, x);
      minY = Math.min(minY, y);
      maxY = Math.max(maxY, y);
    }
    paths.forEach(function (path) { path.points.forEach(function (p) { grow(p[0], p[1]); }); });
    labels.forEach(function (l) { grow(l.box[0], l.box[1]); grow(l.box[2], l.box[3]); });
    grow(tbX, tbY);
    grow(tbX + tbW, tbY + tbH);
    notesOut.forEach(function (n) { grow(n.x, n.y); grow(n.x + measure(n.text, NOTE_SIZE), n.y + NOTE_SIZE * 0.25); });

    return {
      name: record.name,
      ariaLabel: record.name + ' drawing',
      viewBox: [
        minX - MARGIN,
        minY - MARGIN,
        maxX - minX + 2 * MARGIN,
        maxY - minY + 2 * MARGIN
      ],
      outline: outline,
      section: section,
      bulletSection: m.bullet ? polygonPoints(paths, 'bullet') : [],
      paths: paths,
      labels: labels,
      titleBlock: titleBlock,
      notes: notesOut.map(function (n) { return n.text; }),
      noteLabels: notesOut,
      titleSize: TITLE_SIZE
    };
  }

  function polygonPoints(paths, cls) {
    for (var i = 0; i < paths.length; i += 1) {
      if (paths[i].cls === cls) {
        return paths[i].points;
      }
    }
    return [];
  }

  function pointsAttr(points) {
    return points.map(function (p) { return p[0].toFixed(3) + ',' + p[1].toFixed(3); }).join(' ');
  }

  function renderSvg(scene) {
    var out = [];
    var v = scene.viewBox;
    out.push('<svg xmlns="http://www.w3.org/2000/svg" class="cip-drawing" viewBox="' +
      v.map(function (n) { return Number(n.toFixed(3)); }).join(' ') + '" role="img" aria-label="' +
      escapeXml(scene.ariaLabel) + '">');
    out.push('<defs><pattern id="cip-hatch" width="1.3" height="1.3" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="1.3"/></pattern></defs>');
    scene.paths.forEach(function (path) {
      if (path.closed) {
        out.push('<polygon class="' + path.cls + '" points="' + pointsAttr(path.points) + '"/>');
      } else if (path.cls === 'axis') {
        out.push('<polyline class="axis" points="' + pointsAttr(path.points) + '"/>');
      } else {
        out.push('<polyline class="' + path.cls + '" points="' + pointsAttr(path.points) + '"/>');
      }
    });
    scene.labels.forEach(function (l) {
      out.push('<text class="' + l.cls + '" x="' + l.x.toFixed(3) + '" y="' + l.y.toFixed(3) +
        '" text-anchor="' + l.anchor + '" font-size="' + l.size + '">' + escapeXml(l.text) + '</text>');
    });
    var tb = scene.titleBlock;
    out.push('<g class="title-block"><rect x="' + tb.x + '" y="' + tb.y + '" width="' + tb.w + '" height="' + tb.h + '"/>');
    out.push('<text class="title" x="' + (tb.x + 2) + '" y="' + (tb.y + 4.6) + '" font-size="' + scene.titleSize + '">' + escapeXml(tb.lines[0]) + '</text>');
    tb.lines.slice(1).forEach(function (text, index) {
      out.push('<text x="' + (tb.x + 2) + '" y="' + (tb.y + 8.6 + index * 3.6) + '" font-size="2.4">' + escapeXml(text) + '</text>');
    });
    out.push('<polyline class="scale-bar" points="' + tb.scaleBarX + ',' + tb.scaleBarY + ' ' + (tb.scaleBarX + tb.scaleBarMm) + ',' + tb.scaleBarY + '"/>');
    out.push('<text x="' + (tb.scaleBarX + tb.scaleBarMm + 2) + '" y="' + (tb.scaleBarY + 0.8) + '" font-size="2.4">10 mm</text></g>');
    scene.noteLabels.forEach(function (n) {
      out.push('<text class="note" x="' + n.x + '" y="' + n.y.toFixed(3) + '" font-size="' + NOTE_SIZE + '">' + escapeXml('Note: ' + n.text) + '</text>');
    });
    out.push('</svg>');
    return out.join('');
  }

  return {
    buildScene: buildScene,
    renderSvg: renderSvg
  };
});
