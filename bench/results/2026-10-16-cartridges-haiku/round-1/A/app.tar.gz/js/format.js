/*
 * Formatting of record values for display: angles, tolerances, symbols,
 * units and the grouped Symbol / Value / Unit sections of the detail view.
 * Pure functions, no DOM. Loaded as a classic script and as a CommonJS module.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.format = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var ANGLE_KEYS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
  var COUNT_KEYS = ['N'];

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  var UNITS = {
    EE: 'J',
    M: 'g',
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    Q: 'mm²'
  };

  var GROUP_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling'
  };

  var SCOPES = [
    { scope: 'cartridge', title: 'Cartridge', object: 'cartridge' },
    { scope: 'chamber', title: 'Chamber', object: 'chamber' }
  ];

  function pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function isAngleKey(key) {
    return ANGLE_KEYS.indexOf(key) !== -1;
  }

  function formatAngle(angle) {
    if (typeof angle === 'number') {
      return String(angle) + '°';
    }
    return String(angle.degrees) + '°' + pad2(angle.minutes) + "'" + pad2(angle.seconds) + '"';
  }

  function formatValue(key, value) {
    return isAngleKey(key) ? formatAngle(value) : String(value);
  }

  function symbolFor(key) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, key) ? SYMBOLS[key] : key;
  }

  function unitFor(key) {
    if (isAngleKey(key) || COUNT_KEYS.indexOf(key) !== -1) {
      return '—';
    }
    return Object.prototype.hasOwnProperty.call(UNITS, key) ? UNITS[key] : 'mm';
  }

  function isTolerance(key, group) {
    if (!/Tol$/.test(key)) {
      return false;
    }
    return Object.prototype.hasOwnProperty.call(group, key.slice(0, -3));
  }

  /*
   * Rows of one record, grouped by section. A tolerance field `<X>Tol` is
   * written next to the value of `X` and never gets a row of its own.
   */
  function buildSections(record) {
    var sections = [];
    SCOPES.forEach(function (scopeInfo) {
      var root = record[scopeInfo.object] || {};
      Object.keys(root).forEach(function (group) {
        var fields = root[group];
        var rows = [];
        Object.keys(fields).forEach(function (key) {
          if (isTolerance(key, fields)) {
            return;
          }
          var text = formatValue(key, fields[key]);
          var tolKey = key + 'Tol';
          if (Object.prototype.hasOwnProperty.call(fields, tolKey)) {
            text += ' ' + String(fields[tolKey]);
          }
          rows.push({
            key: key,
            symbol: symbolFor(key),
            value: text,
            unit: unitFor(key)
          });
        });
        if (rows.length > 0) {
          sections.push({
            scope: scopeInfo.scope,
            scopeTitle: scopeInfo.title,
            group: group,
            title: GROUP_TITLES[group] || group,
            rows: rows
          });
        }
      });
    });
    return sections;
  }

  return {
    formatAngle: formatAngle,
    formatValue: formatValue,
    symbolFor: symbolFor,
    unitFor: unitFor,
    buildSections: buildSections
  };
});
