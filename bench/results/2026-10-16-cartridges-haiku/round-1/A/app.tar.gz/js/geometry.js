/*
 * Cartridge geometry from the record's published values, following the
 * drawing rules of the brief. Points are [z, r] in mm: z runs along the axis
 * from the head face (z = 0) to the mouth, r is the radius. Pure functions.
 * A value a rule needs but the record lacks is listed in `missing` and the
 * feature is left out; no number is invented.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.geometry = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var PRIMER_POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 }
  };

  var ARC_SAMPLES = 12;

  function radians(degrees) {
    return (degrees * Math.PI) / 180;
  }

  function angleDegrees(angle) {
    if (typeof angle === 'number') {
      return angle;
    }
    return angle.degrees + angle.minutes / 60 + angle.seconds / 3600;
  }

  function rimType(family, R1, P1) {
    if (family === 'belted') {
      return 'belted';
    }
    if (family === 'rimfire') {
      return 'rimfire';
    }
    var ratio = R1 / P1;
    if (ratio >= 1.05) {
      return 'rimmed';
    }
    if (ratio < 0.98) {
      return 'rebated';
    }
    return 'rimless';
  }

  function primerPocket(primerType) {
    if (!Object.prototype.hasOwnProperty.call(PRIMER_POCKETS, primerType)) {
      return null;
    }
    var pocket = PRIMER_POCKETS[primerType];
    return { diameter: pocket.diameter, depth: pocket.depth };
  }

  function dist(a, b) {
    return Math.hypot(b[0] - a[0], b[1] - a[1]);
  }

  function unit(v) {
    var length = Math.hypot(v[0], v[1]);
    return [v[0] / length, v[1] / length];
  }

  function sameAs(a, b) {
    return Math.abs(a[0] - b[0]) < 1e-12 && Math.abs(a[1] - b[1]) < 1e-12;
  }

  /*
   * Replace the corner p1 (between p0 and p2) by a circular arc of radius
   * `radius`, tangent to both legs. Returns the points from the tangent point
   * on the incoming leg to the one on the outgoing leg, both included.
   */
  function fillet(p0, p1, p2, radius) {
    var d1 = unit([p1[0] - p0[0], p1[1] - p0[1]]);
    var d2 = unit([p2[0] - p1[0], p2[1] - p1[1]]);
    var dot = Math.max(-1, Math.min(1, d1[0] * d2[0] + d1[1] * d2[1]));
    var turn = Math.acos(dot);
    if (turn < 1e-9 || !(radius > 0)) {
      return [p1];
    }
    var t = radius * Math.tan(turn / 2);
    var maxT = 0.45 * Math.min(dist(p0, p1), dist(p1, p2));
    var rho = radius;
    if (t > maxT) {
      t = maxT;
      rho = t / Math.tan(turn / 2);
    }
    var a = [p1[0] - d1[0] * t, p1[1] - d1[1] * t];
    var b = [p1[0] + d2[0] * t, p1[1] + d2[1] * t];
    var cross = d1[0] * d2[1] - d1[1] * d2[0];
    var normal = cross >= 0 ? [-d1[1], d1[0]] : [d1[1], -d1[0]];
    var centre = [a[0] + normal[0] * rho, a[1] + normal[1] * rho];
    var a0 = Math.atan2(a[1] - centre[1], a[0] - centre[0]);
    var a1 = Math.atan2(b[1] - centre[1], b[0] - centre[0]);
    var sweep = a1 - a0;
    while (sweep > Math.PI) {
      sweep -= 2 * Math.PI;
    }
    while (sweep < -Math.PI) {
      sweep += 2 * Math.PI;
    }
    var out = [];
    for (var i = 0; i <= ARC_SAMPLES; i += 1) {
      var angle = a0 + (sweep * i) / ARC_SAMPLES;
      out.push([centre[0] + rho * Math.cos(angle), centre[1] + rho * Math.sin(angle)]);
    }
    return out;
  }

  /* Round the interior corners that have a radius; radii[i] belongs to points[i]. */
  function roundCorners(points, radii) {
    var out = [points[0]];
    for (var i = 1; i < points.length - 1; i += 1) {
      var piece = radii[i] > 0 ? fillet(points[i - 1], points[i], points[i + 1], radii[i]) : [points[i]];
      piece.forEach(function (p) {
        if (!sameAs(out[out.length - 1], p)) {
          out.push(p);
        }
      });
    }
    var last = points[points.length - 1];
    if (!sameAs(out[out.length - 1], last)) {
      out.push(last);
    }
    return out;
  }

  /* The part of a polyline at or beyond z = zMin, with the crossing point added. */
  function clipFrom(points, zMin) {
    var out = [];
    for (var i = 0; i < points.length; i += 1) {
      var p = points[i];
      if (i > 0) {
        var q = points[i - 1];
        var crosses = (q[0] < zMin && p[0] > zMin) || (q[0] > zMin && p[0] < zMin);
        if (crosses) {
          var t = (zMin - q[0]) / (p[0] - q[0]);
          out.push([zMin, q[1] + t * (p[1] - q[1])]);
        }
      }
      if (p[0] >= zMin) {
        out.push(p);
      }
    }
    return out;
  }

  /* Radius of a z-monotone polyline at z (first segment that spans z). */
  function radiusAt(points, z) {
    for (var i = 1; i < points.length; i += 1) {
      var a = points[i - 1];
      var b = points[i];
      if (b[0] > a[0] && z >= a[0] && z <= b[0]) {
        return a[1] + ((z - a[0]) / (b[0] - a[0])) * (b[1] - a[1]);
      }
    }
    return NaN;
  }

  function nosePoints(shape, Gx, zN, n, L6) {
    var mouth;
    var points = [];
    var i;
    if (shape === 'pointy') {
      mouth = Math.max(0.08 * Gx, 1.27);
      var d = Gx / 2 - mouth / 2;
      var rho = (d * d + n * n) / (2 * d);
      var centre = Gx / 2 - rho;
      var phiEnd = Math.atan2(n, rho - d);
      for (i = 0; i <= ARC_SAMPLES; i += 1) {
        var phi = (phiEnd * i) / ARC_SAMPLES;
        points.push([zN + rho * Math.sin(phi), centre + rho * Math.cos(phi)]);
      }
      return { mouth: mouth, points: points };
    }
    if (shape === 'rounded') {
      mouth = 0.15 * Gx;
      var radial = Gx / 2 - mouth / 2;
      for (i = 0; i <= ARC_SAMPLES; i += 1) {
        var theta = (Math.PI / 2) * (i / ARC_SAMPLES);
        points.push([zN + n * Math.sin(theta), mouth / 2 + radial * Math.cos(theta)]);
      }
      return { mouth: mouth, points: points };
    }
    mouth = shape === 'semi_wadcutter' ? 0.6 * Gx : 0.55 * Gx;
    points.push([zN, Gx / 2]);
    points.push([L6, mouth / 2]);
    return { mouth: mouth, points: points };
  }

  function bulletModel(ann, values, Gx, heelRadius) {
    var G1 = values.G1;
    var L3 = values.L3;
    var L6 = values.L6;
    var shape = ann.defaultBulletShape || 'pointy';
    var pistol = ann.category === 'pistol';
    var s;
    var k;
    if (shape === 'pointy') {
      s = 1.0 * G1;
      k = 0.4;
    } else if (shape === 'semi_wadcutter') {
      s = 0.6 * G1;
      k = 0.78;
    } else if (shape === 'flat') {
      s = (pistol ? 0.4 : 0.8) * G1;
      k = pistol ? 0.7 : 0.6;
    } else {
      s = (pistol ? 0.4 : 0.8) * G1;
      k = pistol ? 0.65 : 0.55;
    }
    var zb = L3 - s;
    var Lb = L6 - zb;
    var zN = zb + k * Lb;
    var n = L6 - zN;
    var nose = nosePoints(shape, Gx, zN, n, L6);
    var full = [[zb, 0], [zb, Gx / 2], [zN, Gx / 2]].concat(nose.points, [[L6, nose.mouth / 2], [L6, 0]]);
    return {
      shape: shape,
      s: s,
      k: k,
      zb: zb,
      Lb: Lb,
      zN: zN,
      n: n,
      m: nose.mouth,
      tip: [L6, 0],
      Gx: Gx,
      exposedRadius: Gx / 2,
      heelRadius: heelRadius,
      zCylEnd: Math.max(zN, values.L3),
      seated: [[zb, 0], [zb, heelRadius], [L3, heelRadius]],
      exposed: clipFrom(full, L3)
    };
  }

  /*
   * The record's cartridge values turned into drawing geometry.
   * Throws only when a value that every drawing needs (R1, P1, L3, H2) is absent.
   */
  function buildModel(record) {
    var cartridge = record.cartridge || {};
    var head = cartridge.caseHead || {};
    var collar = cartridge.collar || {};
    var cone = cartridge.junctionCone || {};
    var lengths = cartridge.lengths || {};
    var pc = cartridge.powderChamber || {};
    var proj = cartridge.projectile || {};
    var ann = record.annotations || {};
    var missing = [];

    var values = {
      R1: head.R1,
      R: head.R,
      E: head.E,
      E1: head.E1,
      eMin: head.eMin,
      f: head.f,
      beta: head.beta === undefined ? undefined : angleDegrees(head.beta),
      delta: head.delta === undefined ? undefined : angleDegrees(head.delta),
      R3: head.R3,
      P1: pc.P1,
      P2: pc.P2,
      H1: collar.H1,
      H2: collar.H2,
      G1: proj.G1,
      L1: lengths.L1,
      L2: lengths.L2,
      L3: lengths.L3,
      L6: lengths.L6,
      alpha: cone.alpha === undefined ? undefined : angleDegrees(cone.alpha),
      r1Min: cone.r1Min,
      r2: cone.r2
    };
    if (values.R1 === undefined || values.P1 === undefined || values.L3 === undefined || values.H2 === undefined) {
      throw new Error('record lacks R1, P1, L3 or H2: no drawing possible');
    }

    var rim = rimType(record.family, values.R1, values.P1);
    var rimfire = rim === 'rimfire';
    var belted = rim === 'belted';
    var Rh = values.R1 / 2;
    var Rr = values.R === undefined ? 0 : values.R;
    if (values.R === undefined) {
      missing.push('R (rim thickness) not published: drawn as 0');
    }

    var groove = values.E !== undefined && values.E1 !== undefined;
    if (!groove && !rimfire) {
      missing.push('extractor groove not drawn: E, E1 not published');
    }
    if (groove && values.eMin === undefined) {
      missing.push('eMin not published: groove floor drawn as 0');
    }
    var eMin = values.eMin === undefined ? 0 : values.eMin;

    var bottleneck = values.alpha !== undefined && values.L1 !== undefined && values.L2 !== undefined;
    var straight = !bottleneck;
    var heeled = values.G1 !== undefined && values.H2 - values.G1 <= 0.015;
    var tn = values.G1 === undefined ? 0 : Math.max(0, (values.H2 - values.G1) / 2);
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * (values.P1 / 2));

    var pocket = rimfire ? null : primerPocket(ann.primerType);

    var outerRaw = [[0, 0]];
    var radiiRaw = [0];
    var rBack = Rh;
    var features = {};
    function push(z, r, radius) {
      outerRaw.push([z, r]);
      radiiRaw.push(radius || 0);
    }

    if (rimfire) {
      var rad = Math.min(Rr / 2, (values.R1 - values.P1) / 2);
      rBack = Rh - rad;
      push(0, Rh - rad);
      var steps = 2 * ARC_SAMPLES;
      for (var i = 1; i <= steps; i += 1) {
        var a = Math.PI - (Math.PI * i) / steps;
        push(rad + rad * Math.cos(a), Rh - rad + rad * Math.sin(a));
      }
      if (Rr > 2 * rad) {
        push(Rr, rBack);
      }
    } else {
      var chamfer = 0;
      if (values.f !== undefined && values.beta !== undefined && values.beta > 0 && values.beta < 90 && values.f <= Rr) {
        chamfer = Math.min(values.f * Math.tan(radians(values.beta)), Rh / 2);
      }
      if (chamfer > 0) {
        push(0, Rh - chamfer);
        push(values.f, Rh);
      } else {
        push(0, Rh);
      }
      push(Rr, Rh);
    }

    var zB;
    var beltRamp = null;
    if (groove) {
      push(Rr, values.E1 / 2);
      push(Rr + eMin, values.E1 / 2);
      features.E1 = [Rr + eMin, values.E1 / 2];
      if (belted && values.R3 !== undefined && values.delta !== undefined) {
        var zRamp = Rr + eMin + (values.R3 / 2 - values.E1 / 2) / Math.tan(radians(values.delta));
        if (zRamp < values.E) {
          push(zRamp, values.R3 / 2);
          push(values.E, values.R3 / 2);
          beltRamp = [zRamp, values.R3 / 2];
        }
      } else if (belted) {
        missing.push('R3 or delta not published: belt not drawn');
      }
      push(values.E, values.P1 / 2);
      zB = values.E;
    } else {
      push(Rr, values.P1 / 2);
      zB = Rr;
    }
    features.beltRampEnd = beltRamp;

    var zShoulderMid = null;
    if (straight) {
      push(values.L3, values.H2 / 2);
    } else {
      if (values.P2 !== undefined) {
        push(values.L1, values.P2 / 2, values.r1Min);
        features.P2 = [values.L1, values.P2 / 2];
        features.L1 = [values.L1, values.P2 / 2];
      } else {
        missing.push('P2 not published: body runs straight to the neck');
        features.P2 = null;
        features.L1 = null;
      }
      if (values.H1 === undefined) {
        missing.push('H1 not published: neck starts at H2');
      }
      var neckR = values.H1 === undefined ? values.H2 / 2 : values.H1 / 2;
      push(values.L2, neckR, values.r2);
      features.H1 = values.H1 === undefined ? null : [values.L2, values.H1 / 2];
      features.L2 = [values.L2, neckR];
      if (values.P2 !== undefined) {
        zShoulderMid = [(values.L1 + values.L2) / 2, (values.P2 / 2 + neckR) / 2];
      }
      push(values.L3, values.H2 / 2);
    }
    var outer = roundCorners(outerRaw, radiiRaw);

    var wall = function (z) {
      if (straight) {
        var span = values.L3 - zB;
        var t = span > 0 ? Math.min(1, Math.max(0, (z - zB) / span)) : 1;
        return tb + (tn - tb) * t;
      }
      if (z <= values.L1) {
        return tb;
      }
      if (z >= values.L2) {
        return tn;
      }
      return tb + (tn - tb) * ((z - values.L1) / (values.L2 - values.L1));
    };

    var w = Math.max(2.5, 0.25 * (values.P1 / 2));
    if (pocket) {
      w = Math.max(w, pocket.depth + 1.5);
    }
    if (beltRamp) {
      w = Math.max(w, beltRamp[0] + tb);
    } else if (groove) {
      w = Math.max(w, values.E + tb);
    }

    var inner = [[w, radiusAt(outer, w) - wall(w)]];
    outer.forEach(function (p) {
      if (p[0] > w) {
        inner.push([p[0], p[1] - wall(p[0])]);
      }
    });

    var bullet = null;
    if (values.G1 === undefined) {
      missing.push('G1 not published: bullet not drawn');
    } else {
      var Gx = heeled ? values.H2 : values.G1;
      var heelRadius = heeled ? (values.H2 - 2 * tb) / 2 : values.G1 / 2;
      bullet = bulletModel(ann, values, Gx, heelRadius);
      features.G1 = [bullet.zCylEnd, Gx / 2];
      features.L6 = [values.L6, bullet.m / 2];
    }
    features.R1 = [0, Rh];
    features.R = [Rr, rBack];
    features.P1 = [zB, values.P1 / 2];
    features.H2 = [values.L3, values.H2 / 2];
    features.L3 = [values.L3, values.H2 / 2];
    features.shoulderMid = zShoulderMid ? zShoulderMid : null;
    features.alpha = values.alpha === undefined ? null : values.alpha;

    return {
      name: record.name,
      key: record.key,
      family: record.family,
      rim: rim,
      category: ann.category,
      shape: ann.defaultBulletShape || 'pointy',
      primerType: ann.primerType,
      groove: groove,
      belted: belted,
      straight: straight,
      heeled: heeled,
      tn: tn,
      tb: tb,
      pocket: pocket,
      w: w,
      outer: outer,
      inner: inner,
      bullet: bullet,
      features: features,
      values: values,
      missing: missing
    };
  }

  return {
    buildModel: buildModel,
    rimType: rimType,
    primerPocket: primerPocket,
    roundCorners: roundCorners,
    fillet: fillet,
    clipFrom: clipFrom,
    radiusAt: radiusAt
  };
});
