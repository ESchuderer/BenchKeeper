'use strict';
// End-to-end checks in headless Chromium, straight from file:// (no server).
const { after, before, test } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright-core');
const records = require('../../data/cartridges.js');

const INDEX = pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;

let browser;

before(async () => {
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
});

async function open(options, hash = '') {
  const context = await browser.newContext({ viewport: { width: 1000, height: 800 }, ...options });
  const page = await context.newPage();
  const errors = [];
  const requests = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => {
    if (m.type() === 'error') {
      errors.push(m.text());
    }
  });
  page.on('request', (r) => requests.push(r.url()));
  await page.goto(INDEX + hash);
  return { context, page, errors, requests };
}

test('the list opens from file:// with 25 cartridges, no errors and no network requests', async () => {
  const { context, page, errors, requests } = await open({});
  try {
    assert.equal(await page.locator('#cartridge-rows a').count(), 25);
    assert.equal(await page.textContent('#count'), '25 cartridges');
    assert.equal(await page.textContent('h1'), 'Cartridges');
    const names = await page.locator('#cartridge-rows a').allTextContents();
    assert.deepEqual([...names].sort(), records.map((r) => r.name).sort());
    assert.ok(requests.every((url) => url.startsWith('file:')), requests.join(' '));
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('search filters by name and alternative name and updates the count', async () => {
  const { context, page } = await open({});
  try {
    await page.fill('#search', '7,62 x 51');
    assert.deepEqual(await page.locator('#cartridge-rows a').allTextContents(), ['308 Win.']);
    assert.equal(await page.textContent('#count'), '1 cartridge');
    await page.fill('#search', 'zzz-no-match');
    assert.equal(await page.locator('#cartridge-rows a').count(), 0);
    assert.equal(await page.textContent('#count'), '0 cartridges');
  } finally {
    await context.close();
  }
});

test('the family filter narrows the list and combines with the search', async () => {
  const { context, page } = await open({});
  try {
    await page.selectOption('#family', 'belted');
    assert.equal(await page.textContent('#count'), '2 cartridges');
    await page.fill('#search', 'mag');
    assert.deepEqual((await page.locator('#cartridge-rows a').allTextContents()).sort(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
    await page.selectOption('#family', 'rimfire');
    assert.equal(await page.textContent('#count'), '1 cartridge');
  } finally {
    await context.close();
  }
});

test('a cartridge name opens its own address, which survives a reload and can be bookmarked', async () => {
  const { context, page, errors } = await open({});
  try {
    await page.click('text=223 Rem.');
    await page.waitForURL(/#\/cartridge\/223_rem$/);
    assert.equal(await page.textContent('#detail-view h1'), '223 Rem.');
    assert.ok(await page.isVisible('svg[aria-label="223 Rem. drawing"]'));
    await page.reload();
    assert.equal(await page.textContent('#detail-view h1'), '223 Rem.');
    const bookmark = await open({}, '#/cartridge/6_5_creedmoor');
    try {
      assert.equal(await bookmark.page.textContent('#detail-view h1'), '6,5 Creedmoor');
    } finally {
      await bookmark.context.close();
    }
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('the detail view shows the header facts, grouped value tables and the back link', async () => {
  const { context, page } = await open({}, '#/cartridge/308_win');
  try {
    const facts = await page.locator('.facts').innerText();
    for (const text of ['308 Winchester', 'rimless', 'rifle', 'lr', 'I', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H₂O']) {
      assert.ok(facts.includes(text), `facts missing ${text}`);
    }
    const headers = await page.locator('.values thead').first().textContent();
    assert.match(headers, /Symbol\s*Value\s*Unit/);
    const l1 = page.locator('.values tr', { hasText: 'L1' }).first();
    assert.match(await l1.innerText(), /39\.62 -0\.2\s+mm/);
    assert.equal(await page.locator('.values tr', { hasText: 'L1Tol' }).count(), 0);
    assert.equal(await page.locator('a.back').textContent(), 'All cartridges');
    await page.click('a.back');
    await page.waitForSelector('#list-view', { state: 'visible' });
  } finally {
    await context.close();
  }
});

test('an unknown address says so and links back to the list', async () => {
  const { context, page } = await open({}, '#/cartridge/no_such_key');
  try {
    assert.equal(await page.textContent('#detail-view h1'), 'Cartridge not found');
    await page.click('#detail-view a');
    await page.waitForSelector('#list-view', { state: 'visible' });
  } finally {
    await context.close();
  }
});

test('print gives one A4 portrait page, with no navigation or buttons', async () => {
  const { context, page } = await open({}, '#/cartridge/338_lapua_mag');
  try {
    await page.emulateMedia({ media: 'print' });
    assert.equal(await page.isVisible('.print-button'), false);
    assert.equal(await page.isVisible('.site-header'), false);
    const pdf = await page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page(?!s)/g) || []).length;
    assert.equal(pages, 1);
  } finally {
    await context.close();
  }
});

test('the print button opens the print dialog', async () => {
  const { context, page, errors } = await open({}, '#/cartridge/223_rem');
  try {
    await page.evaluate(() => {
      window.__printed = 0;
      window.print = () => { window.__printed += 1; };
    });
    await page.click('.print-button');
    assert.equal(await page.evaluate(() => window.__printed), 1);
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('dark mode follows the system setting', async () => {
  const dark = await open({ colorScheme: 'dark' }, '#/cartridge/223_rem');
  const light = await open({ colorScheme: 'light' }, '#/cartridge/223_rem');
  try {
    const bgDark = await dark.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    const bgLight = await light.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.notEqual(bgDark, bgLight);
    assert.equal(bgDark, 'rgb(21, 25, 28)');
    assert.equal(bgLight, 'rgb(251, 250, 247)');
  } finally {
    await dark.context.close();
    await light.context.close();
  }
});

test('on a phone-width screen the detail view does not scroll sideways and the drawing fits', async () => {
  const { context, page } = await open({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true }, '#/cartridge/9_3_x_74_r');
  try {
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assert.equal(overflow, 0);
    const width = await page.locator('svg.cip-drawing').evaluate((svg) => svg.getBoundingClientRect().width);
    assert.ok(width <= 390, `drawing is ${width}px wide`);
  } finally {
    await context.close();
  }
});
