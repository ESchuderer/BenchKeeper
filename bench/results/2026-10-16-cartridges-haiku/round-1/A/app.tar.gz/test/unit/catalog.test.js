'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../../js/catalog.js');
const records = require('../../data/cartridges.js');

test('search by a name fragment finds the cartridge', () => {
  const found = catalog.filterCartridges(records, { query: '223', family: 'all' });
  assert.deepEqual(found.map((r) => r.name), ['223 Rem.']);
});

test('search matches alternative names: "7,62 x 51" finds 308 Win.', () => {
  const found = catalog.filterCartridges(records, { query: '7,62 x 51', family: 'all' });
  assert.deepEqual(found.map((r) => r.name), ['308 Win.']);
});

test('search ignores case, repeated spaces and accents', () => {
  assert.deepEqual(
    catalog.filterCartridges(records, { query: '  22   LANG FUR', family: 'all' }).map((r) => r.name),
    ['22 Long Rifle'],
  );
  assert.equal(catalog.filterCartridges(records, { query: '30-06', family: 'all' }).length, 1);
});

test('an empty search returns every cartridge', () => {
  assert.equal(catalog.filterCartridges(records, { query: '  ', family: 'all' }).length, 25);
});

test('family filter counts match the records, and combines with search', () => {
  const counts = {};
  for (const f of ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire']) {
    counts[f] = catalog.filterCartridges(records, { query: '', family: f }).length;
  }
  assert.deepEqual(counts, { rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 });
  assert.equal(catalog.filterCartridges(records, { query: '22', family: 'rimfire' }).length, 2);
  assert.equal(catalog.filterCartridges(records, { query: 'Long', family: 'rimfire' }).length, 1);
  assert.equal(catalog.filterCartridges(records, { query: 'Long', family: 'rimless' }).length, 0);
});

test('results are sorted by name and the count text is pluralised', () => {
  const names = catalog.filterCartridges(records, { query: '', family: 'all' }).map((r) => r.name);
  assert.deepEqual(names, [...names].sort((a, b) => a.localeCompare(b, 'en', { numeric: true })));
  assert.equal(catalog.countText(25), '25 cartridges');
  assert.equal(catalog.countText(1), '1 cartridge');
  assert.equal(catalog.countText(0), '0 cartridges');
});

test('routes: the list is the default, a detail address carries the key', () => {
  assert.deepEqual(catalog.parseRoute(''), { view: 'list' });
  assert.deepEqual(catalog.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(catalog.parseRoute('#/cartridge/223_rem'), { view: 'detail', key: '223_rem' });
  assert.equal(catalog.routeFor('6_5_creedmoor'), '#/cartridge/6_5_creedmoor');
});

test('a malformed encoded key is kept as typed rather than throwing', () => {
  assert.deepEqual(catalog.parseRoute('#/cartridge/%E4%B8'), { view: 'detail', key: '%E4%B8' });
});
