'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const records = require('../../data/cartridges.js');

const EXPECTED_NAMES = [
  '223 Rem.', '243 Win.', '6,5 Creedmoor', '6,5 x 55 SE', '270 Win.', '7 x 64',
  '308 Win.', '30-06 Spring.', '8 x 57 IS', '9,3 x 62', '338 Lapua Mag.',
  '300 Win. Mag.', '7 mm Rem. Mag.', '9,3 x 74 R', '7 x 65 R', '9 mm Luger',
  '45 Auto', '40 S.& W.', '38 Special', '357 Magnum', '44 Rem. Mag.',
  '22 Long Rifle', '22 Win. Mag. R.F.', '17 HMR', '7,62 x 39',
];

test('the data holds exactly the 25 published records, unchanged in count', () => {
  assert.equal(records.length, 25);
});

test('every record name matches the brief, as published', () => {
  assert.deepEqual(records.map((r) => r.name).sort(), [...EXPECTED_NAMES].sort());
});

test('keys are unique and each record has the sections the app reads', () => {
  const keys = records.map((r) => r.key);
  assert.equal(new Set(keys).size, 25);
  for (const r of records) {
    assert.ok(r.cartridge && r.chamber && r.annotations, r.key);
    assert.ok(r.cartridge.caseHead && r.cartridge.lengths && r.cartridge.projectile, r.key);
  }
});

test('spot-check published values are copied exactly', () => {
  const byKey = Object.fromEntries(records.map((r) => [r.key, r]));
  assert.equal(byKey['223_rem'].cartridge.lengths.L3, 44.7);
  assert.equal(byKey['223_rem'].cartridge.junctionCone.alpha, 46);
  assert.equal(byKey['308_win'].cartridge.lengths.L6, 71.12);
  assert.deepEqual(byKey['223_rem'].chamber.rifling.i, { degrees: 3, minutes: 10, seconds: 36 });
  assert.equal(byKey['22_long_rifle'].cartridge.collar.H1, undefined);
  assert.equal(byKey['9_mm_luger'].cartridge.junctionCone && Object.keys(byKey['9_mm_luger'].cartridge.junctionCone).length, 0);
});
