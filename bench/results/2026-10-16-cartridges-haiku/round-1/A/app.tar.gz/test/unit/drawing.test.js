'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const drawing = require('../../js/drawing.js');
const records = require('../../data/cartridges.js');

const byKey = Object.fromEntries(records.map((r) => [r.key, r]));

function segmentsOf(points, closed) {
  const out = [];
  for (let i = 1; i < points.length; i += 1) {
    out.push([points[i - 1], points[i]]);
  }
  if (closed && points.length > 2) {
    out.push([points[points.length - 1], points[0]]);
  }
  return out;
}

// Liang-Barsky: does the segment touch the closed rectangle box = [x0, y0, x1, y1]?
function segmentHitsBox(a, b, box) {
  const [x0, y0, x1, y1] = box;
  let t0 = 0;
  let t1 = 1;
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const tests = [[-dx, a[0] - x0], [dx, x1 - a[0]], [-dy, a[1] - y0], [dy, y1 - a[1]]];
  for (const [p, q] of tests) {
    if (p === 0) {
      if (q < 0) {
        return false;
      }
    } else {
      const t = q / p;
      if (p < 0) {
        if (t > t1) {
          return false;
        }
        if (t > t0) {
          t0 = t;
        }
      } else {
        if (t < t0) {
          return false;
        }
        if (t < t1) {
          t1 = t;
        }
      }
    }
  }
  return t0 <= t1;
}

function boxesOverlap(a, b) {
  return a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3];
}

function linework(scene) {
  const segments = [];
  scene.paths.forEach((path) => segments.push(...segmentsOf(path.points, path.closed)));
  return segments;
}

test('every drawing has an accessible name and a viewBox that holds all of it', () => {
  for (const r of records) {
    const scene = drawing.buildScene(r);
    assert.equal(scene.name, r.name);
    assert.equal(scene.ariaLabel, `${r.name} drawing`);
    const [x, y, w, h] = scene.viewBox;
    assert.ok(w > 0 && h > 0, r.key);
    for (const label of scene.labels) {
      const [x0, y0, x1, y1] = label.box;
      assert.ok(x0 >= x && y0 >= y && x1 <= x + w && y1 <= y + h, `${r.key} label ${label.text} outside viewBox`);
    }
  }
});

test('labels never overlap each other', () => {
  for (const r of records) {
    const labels = drawing.buildScene(r).labels;
    for (let i = 0; i < labels.length; i += 1) {
      for (let j = i + 1; j < labels.length; j += 1) {
        assert.equal(boxesOverlap(labels[i].box, labels[j].box), false,
          `${r.key}: "${labels[i].text}" overlaps "${labels[j].text}"`);
      }
    }
  }
});

test('labels never touch the outline, the section, the bullet or any dimension line', () => {
  for (const r of records) {
    const scene = drawing.buildScene(r);
    const segments = linework(scene);
    for (const label of scene.labels) {
      for (const segment of segments) {
        assert.equal(segmentHitsBox(segment[0], segment[1], label.box), false,
          `${r.key}: label "${label.text}" crosses a line at ${JSON.stringify(segment)}`);
      }
    }
  }
});

test('the dimensions the brief names are present, with symbol and value', () => {
  const texts = (r) => drawing.buildScene(r).labels.map((l) => l.text);
  const has = (r, prefix) => texts(r).some((t) => t.startsWith(prefix));
  const r223 = byKey['223_rem'];
  assert.ok(texts(r223).includes('L3 44.7'), texts(r223).join(' | '));
  assert.ok(texts(r223).includes('L1 36.52 -0.2'), texts(r223).join(' | '));
  assert.ok(has(r223, 'L6 57.4'));
  assert.ok(has(r223, 'R1 9.6'));
  assert.ok(has(r223, 'R 1.14'));
  assert.ok(has(r223, 'P1 9.58'));
  assert.ok(has(r223, 'P2 9 -0.2'));
  assert.ok(has(r223, 'H1 6.43'));
  assert.ok(has(r223, 'H2 6.43'));
  assert.ok(has(r223, 'G1 5.7'));
  assert.ok(has(r223, 'L2 39.55 -0.2'));
  assert.ok(has(r223, 'E1 8.43'));
  assert.ok(has(r223, 'α 46°'));
});

test('dimensions that are not published are left out, not invented', () => {
  const texts = (r) => drawing.buildScene(r).labels.map((l) => l.text);
  const t22 = texts(byKey['22_long_rifle']);
  assert.equal(t22.some((t) => t.startsWith('P2 ') || t.startsWith('H1 ') || t.startsWith('E1 ') || t.startsWith('α ')), false, t22.join(' | '));
  assert.ok(t22.includes('L3 15.57'));
  const t947 = texts(byKey['9_3_x_74_r']);
  assert.equal(t947.some((t) => t.startsWith('E1 ')), false);
});

test('the scene notes what it could not draw', () => {
  const scene = drawing.buildScene(byKey['9_3_x_74_r']);
  assert.ok(scene.notes.some((n) => /E, E1/.test(n)), scene.notes.join('; '));
  assert.equal(drawing.buildScene(byKey['223_rem']).notes.length, 0);
});

test('the title block carries name, C.I.P. table, revision date, units and scale', () => {
  const scene = drawing.buildScene(byKey['223_rem']);
  const text = scene.titleBlock.lines.join(' | ');
  assert.ok(text.includes('223 Rem.'));
  assert.ok(text.includes('C.I.P. table I'));
  assert.ok(text.includes('2017-05-17'));
  assert.ok(text.includes('Dimensions in mm'));
  assert.ok(text.includes('Scale'));
  assert.equal(scene.titleBlock.scaleBarMm, 10);
});

test('the outline is the outside view in the upper half, the section is in the lower half', () => {
  const scene = drawing.buildScene(byKey['308_win']);
  assert.ok(scene.outline.every((p) => p[1] <= 1e-9), 'outline above the axis');
  assert.ok(scene.section.every((p) => p[1] >= -1e-9), 'section below the axis');
  assert.ok(scene.bulletSection.every((p) => p[1] >= -1e-9));
});

test('the bullet is drawn exposed outside and seated inside the case section', () => {
  const scene = drawing.buildScene(byKey['223_rem']);
  const exposedTip = scene.outline[scene.outline.length - 1];
  assert.ok(Math.abs(exposedTip[0] - 57.4) < 1e-6);
  const seatedBase = scene.bulletSection.find((p) => Math.abs(p[0] - 39.0) < 1e-6 && Math.abs(p[1]) < 1e-9);
  assert.ok(seatedBase, 'bullet section starts at the base z = 39.0');
});
