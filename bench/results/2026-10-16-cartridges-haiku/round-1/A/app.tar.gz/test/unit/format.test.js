'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const format = require('../../js/format.js');
const records = require('../../data/cartridges.js');

const byKey = Object.fromEntries(records.map((r) => [r.key, r]));

test('angles: a number is shown as degrees, an object as degrees, minutes and seconds', () => {
  assert.equal(format.formatAngle(40), '40°');
  assert.equal(format.formatAngle(0), '0°');
  assert.equal(format.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(format.formatAngle({ degrees: 0, minutes: 17, seconds: 11 }), '0°17\'11"');
});

test('values are shown as published: decimal point, no thousands separator', () => {
  assert.equal(format.formatValue('Pmax', 4150), '4150');
  assert.equal(format.formatValue('L3', 51.18), '51.18');
  assert.equal(format.formatValue('N', 6), '6');
});

test('symbols follow the brief, other fields keep their name', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', E1: 'E1', G1: 'G1', i: 'i',
  };
  for (const [key, symbol] of Object.entries(expected)) {
    assert.equal(format.symbolFor(key), symbol, key);
  }
});

test('units: angles and counts carry no unit column, special units follow the brief', () => {
  assert.equal(format.unitFor('L1'), 'mm');
  assert.equal(format.unitFor('G1'), 'mm');
  assert.equal(format.unitFor('Pmax'), 'bar');
  assert.equal(format.unitFor('PK'), 'bar');
  assert.equal(format.unitFor('PE'), 'bar');
  assert.equal(format.unitFor('EE'), 'J');
  assert.equal(format.unitFor('M'), 'g');
  assert.equal(format.unitFor('Q'), 'mm²');
  assert.equal(format.unitFor('N'), '—');
  assert.equal(format.unitFor('alpha'), '—');
});

test('tolerance fields are merged into the value they belong to, never a row of their own', () => {
  const sections = format.buildSections(byKey['223_rem']);
  const rows = sections.flatMap((s) => s.rows);
  assert.equal(rows.some((r) => /Tol$/.test(r.key)), false);
  const l1 = rows.find((r) => r.key === 'L1');
  assert.equal(l1.value, '36.52 -0.2');
  assert.equal(l1.symbol, 'L1');
  assert.equal(l1.unit, 'mm');
  assert.equal(rows.find((r) => r.key === 'P2').value, '9 -0.2');
});

test('rows are grouped into cartridge and chamber sections with Symbol, Value and Unit', () => {
  const sections = format.buildSections(byKey['308_win']);
  assert.ok(sections.length > 0);
  assert.equal(sections[0].scope, 'cartridge');
  assert.ok(sections.some((s) => s.scope === 'chamber' && s.title === 'Rifling'));
  const alpha = sections.flatMap((s) => s.rows).find((r) => r.key === 'alpha' && r.symbol === 'α');
  assert.equal(alpha.value, '40°');
  const i = sections.flatMap((s) => s.rows).find((r) => r.key === 'alpha1' && r.symbol === 'α1');
  assert.equal(i.value, '71°25\'59"');
});

test('empty groups produce no section (pistol junction cone)', () => {
  const titles = format.buildSections(byKey['9_mm_luger']).map((s) => s.title);
  assert.equal(titles.includes('Junction cone'), false);
  assert.ok(titles.includes('Case head'));
});

test('every cartridge row has a symbol, a value and a unit', () => {
  for (const r of records) {
    for (const section of format.buildSections(r)) {
      for (const row of section.rows) {
        assert.ok(row.symbol && row.value !== undefined && row.unit, `${r.key} ${row.key}`);
      }
    }
  }
});
