'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const geometry = require('../../js/geometry.js');
const records = require('../../data/cartridges.js');

const byKey = Object.fromEntries(records.map((r) => [r.key, r]));
const close = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${a} != ${b}`);

test('rim type: family first, then R1/P1 for the rest', () => {
  assert.equal(geometry.buildModel(byKey['300_win_mag']).rim, 'belted');
  assert.equal(geometry.buildModel(byKey['22_long_rifle']).rim, 'rimfire');
  assert.equal(geometry.buildModel(byKey['38_special']).rim, 'rimmed');
  assert.equal(geometry.buildModel(byKey['223_rem']).rim, 'rimless');
  assert.equal(geometry.buildModel(byKey['40_s_w']).rim, 'rimless'); // 10.77 / 10.86 = 0.99
  assert.equal(geometry.rimType('pistol', 10.0, 10.5), 'rebated'); // 0.952
  assert.equal(geometry.rimType('rimmed', 11.0, 11.0), 'rimless'); // family rimmed, ratio 1.0
});

test('223 Rem.: extractor groove, tapered body, pocket and wall thicknesses', () => {
  const m = geometry.buildModel(byKey['223_rem']);
  assert.equal(m.groove, true);
  assert.equal(m.straight, false);
  assert.equal(m.heeled, false);
  close(m.tn, 0.365);
  close(m.tb, 0.6);
  assert.deepEqual(m.pocket, { diameter: 4.45, depth: 3.04 });
  close(m.w, 4.54); // max(2.5, 0.25 * P1/2, pocket depth + 1.5, E + tb)
  assert.deepEqual(m.missing, []);
});

test('223 Rem.: the bullet is a pointy 1.0·G1 seat with the tangent nose', () => {
  const b = geometry.buildModel(byKey['223_rem']).bullet;
  close(b.s, 5.7);
  close(b.zb, 39.0);
  close(b.k, 0.4);
  close(b.zN, 46.36);
  close(b.m, 1.27); // max(0.08 * 5.7, 1.27)
  close(b.tip[0], 57.4);
  close(b.tip[1], 0);
  const last = b.exposed[b.exposed.length - 1];
  close(last[0], 57.4);
  close(last[1], 0);
});

test('22 Long Rifle: straight, heeled, rimfire half-round rim, no pocket, rounded rimfire nose', () => {
  const m = geometry.buildModel(byKey['22_long_rifle']);
  assert.equal(m.straight, true);
  assert.equal(m.heeled, true);
  assert.equal(m.pocket, null);
  close(m.tn, 0);
  close(m.tb, 0.6);
  const b = m.bullet;
  close(b.s, 0.8 * 5.72);
  close(b.zb, 15.57 - 0.8 * 5.72);
  close(b.k, 0.55);
  close(b.m, 0.15 * 5.72);
  // the exposed bullet has the case's outside diameter, the seated heel the inside diameter
  close(b.exposedRadius, 5.72 / 2);
  close(b.heelRadius, (5.72 - 2 * m.tb) / 2);
  // half-round rim: outermost point at R1/2, rounding radius min(R/2, (R1 - P1)/2)
  const outermost = Math.max(...m.outer.map((p) => p[1]));
  close(outermost, 7.06 / 2);
});

test('9 mm Luger: straight case (no junction cone) with pistol seating depth', () => {
  const m = geometry.buildModel(byKey['9_mm_luger']);
  assert.equal(m.straight, true);
  close(m.bullet.s, 0.4 * 9.03);
  close(m.bullet.k, 0.65);
  close(m.bullet.zb, 19.15 - 0.4 * 9.03);
});

test('primer pockets: diameter and depth by primer type, none for rimfire', () => {
  assert.deepEqual(geometry.primerPocket('lr'), { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(geometry.primerPocket('lrm'), { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(geometry.primerPocket('lpm'), { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(geometry.primerPocket('sp'), { diameter: 4.45, depth: 3.04 });
  assert.equal(geometry.primerPocket('rimfire'), null);
});

test('belted: the groove ramps out at δ to the belt, then the belt runs to E', () => {
  const m = geometry.buildModel(byKey['300_win_mag']);
  const rampEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  close(m.features.beltRampEnd[0], rampEnd, 1e-6);
  close(m.features.beltRampEnd[1], 13.51 / 2);
  const belt = m.outer.filter((p) => Math.abs(p[1] - 13.51 / 2) < 1e-9);
  assert.ok(belt.some((p) => Math.abs(p[0] - 5.59) < 1e-9));
  assert.ok(m.w >= rampEnd + m.tb - 1e-9);
});

test('a case without a groove steps in at z = R and reports the missing values', () => {
  const m = geometry.buildModel(byKey['9_3_x_74_r']);
  assert.equal(m.groove, false);
  assert.ok(m.missing.some((text) => /E, E1/.test(text)), m.missing.join('; '));
  const step = m.outer.find((p) => Math.abs(p[0] - 1.4) < 1e-9 && Math.abs(p[1] - 11.9 / 2) < 1e-9);
  assert.ok(step, 'step to P1/2 at z = R');
});

test('bottleneck case: shoulder corners rounded, neck to the mouth, tip at L6', () => {
  const m = geometry.buildModel(byKey['223_rem']);
  const last = m.outer[m.outer.length - 1];
  close(last[0], 44.7);
  close(last[1], 6.43 / 2);
  assert.equal(m.straight, false);
  // the body-side corner is rounded, so the raw corner point is not in the outline
  assert.ok(!m.outer.some((p) => Math.abs(p[0] - 36.52) < 1e-9 && Math.abs(p[1] - 9 / 2) < 1e-9));
  // the profile never runs backwards along the axis
  for (let i = 1; i < m.outer.length; i += 1) {
    assert.ok(m.outer[i][0] >= m.outer[i - 1][0] - 1e-9, `z decreases at ${i}`);
  }
});

test('inner profile: body wall tb, neck wall tn, bullet fits the neck', () => {
  const m = geometry.buildModel(byKey['223_rem']);
  const innerMouth = m.inner[m.inner.length - 1];
  close(innerMouth[1], 5.7 / 2, 1e-6); // H2/2 - tn = G1/2
  // the body is straight between the groove and the shoulder: inner = outer - tb there
  close(interpolate(m.inner, 20), interpolate(m.outer, 20) - m.tb, 1e-6);
});

test('a value a rule needs but the record lacks is named and not invented', () => {
  const clone = JSON.parse(JSON.stringify(byKey['223_rem']));
  delete clone.cartridge.powderChamber.P2;
  delete clone.cartridge.powderChamber.P2Tol;
  const m = geometry.buildModel(clone);
  assert.ok(m.missing.some((text) => /P2/.test(text)), m.missing.join('; '));
  assert.equal(m.features.P2, null);
});

test('fillet: a rounded corner is tangent to both legs at the given radius', () => {
  const pts = geometry.roundCorners([[0, 0], [10, 0], [10, 10]], [undefined, 2, undefined]);
  assert.ok(pts.length > 3);
  const arcMid = pts[Math.floor(pts.length / 2)];
  assert.ok(arcMid[0] < 10 && arcMid[1] > 0, 'arc bulges inside the corner');
  close(pts[0][0], 0);
  close(pts[pts.length - 1][1], 10);
});

test('every record builds a model with monotone z and an outer profile that ends at the mouth', () => {
  for (const r of records) {
    const m = geometry.buildModel(r);
    const H2 = r.cartridge.collar.H2;
    const last = m.outer[m.outer.length - 1];
    close(last[0], r.cartridge.lengths.L3, 1e-9);
    close(last[1], H2 / 2, 1e-9);
    for (let i = 1; i < m.outer.length; i += 1) {
      assert.ok(m.outer[i][0] >= m.outer[i - 1][0] - 1e-9, `${r.key} z decreases at ${i}`);
    }
    assert.ok(m.bullet.tip, r.key);
    assert.ok(m.w > 0, r.key);
  }
});

function interpolate(points, z) {
  for (let i = 1; i < points.length; i += 1) {
    const [z0, r0] = points[i - 1];
    const [z1, r1] = points[i];
    if (z >= z0 && z <= z1 && z1 > z0) {
      return r0 + ((z - z0) / (z1 - z0)) * (r1 - r0);
    }
  }
  return NaN;
}
