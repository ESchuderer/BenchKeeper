// Page controller: renders the start page and the detail view, keeps them in step with the URL hash.
(function (global) {
  'use strict';
  var doc = global.document;
  var CIP = global.CIP;
  var records = global.CIP_CARTRIDGES;
  var FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  function esc(text) {
    return String(text == null ? '' : text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function el(tag, attrs, children) {
    var node = doc.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    (children || []).forEach(function (c) {
      node.appendChild(typeof c === 'string' ? doc.createTextNode(c) : c);
    });
    return node;
  }

  function setMain(node) {
    var main = doc.getElementById('app');
    main.innerHTML = '';
    main.appendChild(node);
  }

  // ---------- Start page ----------
  function renderList() {
    var title = 'Cartridges';
    doc.title = title + ' · C.I.P. reference';

    var q = el('input', { id: 'q', type: 'search', autocomplete: 'off', spellcheck: 'false' });
    var fam = el('select', { id: 'fam' });
    FAMILIES.forEach(function (f) {
      var opt = el('option', { value: f }, [f === 'all' ? 'All' : f]);
      fam.appendChild(opt);
    });
    var count = el('p', { class: 'count', id: 'count', 'aria-live': 'polite' });
    var tbody = el('tbody', { id: 'rows' });
    var table = el('table', { class: 'catalog' }, [
      el('thead', {}, [el('tr', {}, [
        el('th', { scope: 'col' }, ['Cartridge']),
        el('th', { scope: 'col' }, ['Family']),
        el('th', { scope: 'col', class: 'num' }, ['L3'])
      ])]),
      tbody
    ]);

    var controls = el('div', { class: 'controls' }, [
      el('label', { class: 'field', for: 'q' }, [el('span', {}, ['Search']), q]),
      el('label', { class: 'field', for: 'fam' }, [el('span', {}, ['Family']), fam])
    ]);

    var wrap = el('section', { class: 'page-list' }, [
      el('h1', {}, [title]),
      controls,
      count,
      table
    ]);
    setMain(wrap);

    function update() {
      var list = CIP.catalog.filter(records, { query: q.value, family: fam.value });
      count.textContent = CIP.catalog.countText(list.length);
      tbody.innerHTML = '';
      CIP.catalog.entries(list).forEach(function (e) {
        var link = el('a', { href: e.href }, [e.name]);
        tbody.appendChild(el('tr', {}, [
          el('td', {}, [link]),
          el('td', { class: 'fam' }, [e.family]),
          el('td', { class: 'num' }, [e.L3Text])
        ]));
      });
    }
    q.addEventListener('input', update);
    fam.addEventListener('change', update);
    update();
  }

  // ---------- Detail view ----------
  function metaRow(term, valueNode) {
    return el('div', { class: 'meta-row' }, [el('dt', {}, [term]), el('dd', {}, [valueNode])]);
  }

  // One table per group (Cartridge, Chamber): a single header, a row per section title, then values.
  function sectionTables(groups) {
    var frag = doc.createDocumentFragment();
    groups.forEach(function (group) {
      frag.appendChild(el('h2', {}, [group.title]));
      var body = [];
      group.sections.forEach(function (section) {
        body.push(el('tr', { class: 'section-row' }, [el('th', { colspan: '3', scope: 'colgroup' }, [section.title])]));
        section.rows.forEach(function (row) {
          body.push(el('tr', {}, [
            el('th', { scope: 'row' }, [row.symbol]),
            el('td', { class: 'num' }, [row.value]),
            el('td', { class: 'unit' }, [row.unit])
          ]));
        });
      });
      frag.appendChild(el('div', { class: 'group-cols' }, [
        el('table', { class: 'values' }, [
          el('thead', {}, [el('tr', {}, [
            el('th', { scope: 'col' }, ['Symbol']),
            el('th', { scope: 'col', class: 'num' }, ['Value']),
            el('th', { scope: 'col' }, ['Unit'])
          ])]),
          el('tbody', {}, body)
        ])
      ]));
    });
    return frag;
  }

  function renderDetail(record) {
    doc.title = record.name + ' · C.I.P. reference';
    var page = el('article', { class: 'page-detail', 'data-key': record.key });

    var nav = el('nav', { class: 'toolbar' }, [
      el('a', { href: '#/', class: 'back' }, ['All cartridges']),
      el('button', { type: 'button', id: 'print', class: 'print' }, ['Print'])
    ]);
    page.appendChild(nav);

    var header = el('header', { class: 'page-header' }, [el('h1', {}, [record.name])]);
    if (record.alternativeNames && record.alternativeNames.length) {
      header.appendChild(el('p', { class: 'alt' }, ['Also known as: ' + record.alternativeNames.join(', ')]));
    }
    page.appendChild(header);

    var ann = record.annotations || {};
    var meta = el('dl', { class: 'meta' });
    meta.appendChild(metaRow('Family', record.family));
    meta.appendChild(metaRow('Category', ann.category || '—'));
    meta.appendChild(metaRow('Primer type', ann.primerType || '—'));
    meta.appendChild(metaRow('C.I.P. table', record.tab));
    meta.appendChild(metaRow('Country', record.country));
    meta.appendChild(metaRow('Published', record.published));
    meta.appendChild(metaRow('Revised', record.revised));
    meta.appendChild(metaRow('Pressure method', record.pressureMethod));
    var cap = ann.publishedCapacity;
    if (cap) {
      var capNode = el('span', {}, [cap.grH2O + ' gr H2O · source ']);
      capNode.appendChild(el('a', { href: cap.url, rel: 'noopener' }, [cap.source]));
      if (cap.note) capNode.appendChild(doc.createTextNode(' (' + cap.note + ')'));
      meta.appendChild(metaRow('Water capacity', capNode));
    }
    page.appendChild(meta);

    var figure = el('figure', { class: 'drawing-wrap' });
    figure.innerHTML = CIP.drawing.toSvg(record);
    page.appendChild(figure);

    var tables = el('div', { class: 'tables' });
    tables.appendChild(sectionTables(CIP.sections.build(record)));
    page.appendChild(tables);

    page.appendChild(el('footer', { class: 'print-footer' }, [
      'Source: C.I.P. TDCC, revised ' + record.revised + ' · ' + record.name
    ]));

    setMain(page);
    doc.getElementById('print').addEventListener('click', function () {
      global.print();
    });
  }

  // ---------- Routing ----------
  function render() {
    var route = CIP.router.resolve(global.location.hash, records);
    if (route.view === 'detail') {
      renderDetail(route.record);
      global.scrollTo(0, 0);
    } else {
      renderList();
    }
  }

  // The script sits at the end of <body>, so the page elements already exist.
  global.addEventListener('hashchange', render);
  render();

  CIP.app = { render: render, renderList: renderList, renderDetail: renderDetail, FAMILIES: FAMILIES, esc: esc };
})(typeof window !== 'undefined' ? window : globalThis);
