// Start-page logic: search over name and alternative names, family filter, counts, entries.
(function (global) {
  'use strict';
  var CIP = global.CIP = global.CIP || {};
  var F = CIP.format;

  function normalise(text) {
    return String(text).replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function matches(record, query) {
    if (!query) return true;
    var q = normalise(query);
    if (normalise(record.name).indexOf(q) !== -1) return true;
    return (record.alternativeNames || []).some(function (alt) {
      return normalise(alt).indexOf(q) !== -1;
    });
  }

  function filter(records, opts) {
    var query = opts && opts.query ? opts.query : '';
    var family = opts && opts.family ? opts.family : 'all';
    return records.filter(function (r) {
      return (family === 'all' || r.family === family) && matches(r, query);
    });
  }

  function countText(n) {
    return n === 1 ? '1 cartridge' : n + ' cartridges';
  }

  function entries(records) {
    return records.map(function (r) {
      var L = (r.cartridge && r.cartridge.lengths) || {};
      return {
        key: r.key,
        name: r.name,
        family: r.family,
        L3Text: F.formatQuantity(L.L3, L.L3Tol) + ' mm',
        href: '#/cartridge/' + r.key
      };
    });
  }

  CIP.catalog = { filter: filter, countText: countText, entries: entries, normalise: normalise };
})(typeof window !== 'undefined' ? window : globalThis);
