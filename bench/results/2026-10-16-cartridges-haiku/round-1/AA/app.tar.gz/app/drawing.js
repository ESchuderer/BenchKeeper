// Drawing: a true-scale SVG (1 user unit = 1 mm) computed from the geometry.
// scene() returns plain data (outline, section, dimension lines, label boxes, title block) so the
// layout can be checked; toSvg() turns that data into markup.
(function (global) {
  'use strict';
  var CIP = global.CIP = global.CIP || {};
  var GEO = CIP.geometry;
  var F = CIP.format;

  var FONT = 3.2;          // label size, mm
  var CHAR_W = 0.6;        // estimated advance per character, em
  var ASC = 0.98 * FONT;   // ascent above the baseline (matches the rendered line box)
  var DESC = 0.4 * FONT;   // descent below the baseline
  var ARROW_L = 1.6;
  var ARROW_W = 0.5;
  var TIER_UP = 5.6;       // spacing of axial dimension tiers above the outline
  var TIER_DOWN = 5.0;     // spacing of radial label rows below the outline
  var ALPHA_R = 4.0;       // radius of the shoulder angle arc
  var EPS = 1e-9;

  function textWidth(text) {
    return Array.from(text).length * FONT * CHAR_W;
  }

  // Box of a label whose baseline is at y and whose anchor is at x.
  function labelBox(text, anchor, x, baseline) {
    var w = textWidth(text);
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0: x0, x1: x0 + w, y0: baseline - ASC, y1: baseline + DESC };
  }

  function seg(x1, y1, x2, y2, cls) {
    return { x1: x1, y1: y1, x2: x2, y2: y2, cls: cls || 'dim' };
  }

  // Arrowhead with its tip at p, pointing in direction d (unit vector in the drawing plane).
  function arrow(px, py, dx, dy) {
    var bx = px - dx * ARROW_L;
    var by = py - dy * ARROW_L;
    var perpX = -dy * ARROW_W;
    var perpY = dx * ARROW_W;
    return [
      seg(px, py, bx + perpX, by + perpY, 'arrow'),
      seg(px, py, bx - perpX, by - perpY, 'arrow')
    ];
  }

  // Largest radius of the upper outline at axial position z (vertical segments count fully).
  function envelopeR(polyline, z) {
    var best = 0;
    for (var i = 0; i + 1 < polyline.length; i++) {
      var a = polyline[i];
      var b = polyline[i + 1];
      var lo = Math.min(a.z, b.z) - EPS;
      var hi = Math.max(a.z, b.z) + EPS;
      if (z < lo || z > hi) continue;
      if (Math.abs(b.z - a.z) < EPS) {
        best = Math.max(best, a.r, b.r);
      } else {
        var t = (z - a.z) / (b.z - a.z);
        best = Math.max(best, a.r + t * (b.r - a.r));
      }
    }
    return best;
  }

  function closed(poly) {
    return poly.concat([poly[0]]);
  }

  function valueText(symbol, value, tol) {
    return symbol + ' ' + F.formatQuantity(value, tol);
  }

  function scene(record) {
    var g = GEO.build(record);
    var cart = record.cartridge || {};
    var lengths = cart.lengths || {};
    var ch = cart.caseHead || {};
    var pc = cart.powderChamber || {};
    if (!g.drawable) {
      return { drawable: false, key: record.key, name: record.name, notes: g.notes.map(function (n) { return n.text; }) };
    }
    var V = g.values;
    var L3 = V.L3;
    var L6 = V.L6;
    var upperZR = g.outer.slice();
    if (g.bullet) {
      upperZR = upperZR.concat(g.bullet.exposed, [{ z: L6, r: 0 }]);
    }
    var upper = upperZR.map(function (p) { return { x: p.z, y: -p.r }; });
    var caseSec = g.caseSection.map(function (p) { return { x: p.z, y: p.r }; });
    var bulletSec = g.bullet ? g.bullet.section.map(function (p) { return { x: p.z, y: p.r }; }) : null;
    var outline = [upper, closed(caseSec)];
    if (bulletSec) outline.push(closed(bulletSec));

    var Rup = 0;
    upperZR.forEach(function (p) { Rup = Math.max(Rup, p.r); });

    var lines = [];
    var labels = [];
    function addLabel(text, anchor, x, baseline) {
      labels.push({ text: text, anchor: anchor, x: x, y: baseline, box: labelBox(text, anchor, x, baseline) });
    }

    // ---- Axial dimensions above the outline, one tier each (R lowest, then by station)
    function axialTier(z1, z2, yT) {
      lines.push(seg(z1, yT, z2, yT));
      var span = z2 - z1;
      var outward = span < 2 * ARROW_L;
      var u = 1; // interior direction is +x
      var d1 = outward ? u : -u;
      var d2 = outward ? -u : u;
      lines = lines.concat(arrow(z1, yT, d1, 0), arrow(z2, yT, d2, 0));
      lines.push(seg(z1, -envelopeR(upperZR, z1) - 1.0, z1, yT - 1.0, 'ext'));
      lines.push(seg(z2, -envelopeR(upperZR, z2) - 1.0, z2, yT - 1.0, 'ext'));
    }
    function tierY(k) {
      return -(Rup + 3.0) - k * TIER_UP;
    }

    var axial = [];
    if (isNum(ch.R) && ch.R > 0) {
      axial.push({ sym: 'R', z1: 0, z2: ch.R, value: ch.R, tol: ch.RTol });
    }
    var axialLengths = [];
    if (g.shoulder.present) {
      axialLengths.push({ sym: 'L1', z: lengths.L1, tol: lengths.L1Tol }, { sym: 'L2', z: lengths.L2, tol: lengths.L2Tol });
    }
    axialLengths.push({ sym: 'L3', z: L3, tol: lengths.L3Tol }, { sym: 'L6', z: L6, tol: lengths.L6Tol });
    axialLengths.sort(function (a, b) { return a.z - b.z; });
    axialLengths.forEach(function (a) { axial.push({ sym: a.sym, z1: 0, z2: a.z, value: a.z, tol: a.tol }); });

    var topTierY = tierY(0);
    axial.forEach(function (item, k) {
      var yT = tierY(k);
      topTierY = yT;
      var text = valueText(item.sym, item.value, item.tol);
      axialTier(item.z1, item.z2, yT);
      var isRim = item.sym === 'R';
      if (isRim) {
        // Short dimension: label to the left of the head, level with its line.
        addLabel(text, 'end', -2.2, yT + (ASC - DESC) / 2);
      } else {
        // Keep the label clear of extension lines: its own (at z2) and those of longer
        // dimensions, whose lines pass through this tier.
        var w = textWidth(text);
        var right = item.z2;
        axial.forEach(function (other, j) { if (j > k) right = Math.min(right, other.z2); });
        right -= 0.6;
        var left = item.z1 + 0.6;
        var x0 = (item.z1 + item.z2) / 2 - w / 2;
        if (right - left >= w) {
          x0 = Math.max(left, Math.min(x0, right - w));
          addLabel(text, 'start', x0, yT - 1.6);
        } else {
          // Too wide for the gap: start just beyond the item's own extension line.
          addLabel(text, 'start', item.z2 + 0.6, yT - 1.6);
        }
      }
    });

    // ---- Radial (diameter) dimensions below the outline, rightmost station on the top row
    var stations = [];
    function station(sym, z, r, tol, value) {
      stations.push({ sym: sym, z: z, r: r, text: valueText(sym, value, tol) });
    }
    station('R1', ch.R / 2, V.R1 / 2, undefined, V.R1);
    if (g.groove.present) station('E1', ch.R + (isNum(ch.eMin) ? ch.eMin / 2 : 0), V.E1 / 2, undefined, V.E1);
    station('P1', g.groove.present ? V.E : V.R, V.P1 / 2, pc.P1Tol, V.P1);
    if (g.shoulder.present) {
      station('P2', lengths.L1, V.P2 / 2, pc.P2Tol, V.P2);
      station('H1', lengths.L2, V.H1 / 2, (cart.collar || {}).H1Tol, V.H1);
    }
    station('H2', L3, V.H2 / 2, (cart.collar || {}).H2Tol, V.H2);
    var rExp = g.bullet ? g.bullet.exposedRadius : V.G1 / 2;
    station('G1', (L3 + L6) / 2, rExp, undefined, V.G1);
    // Rows are shared by two groups whose label ranges never meet: the head group sits left of
    // its station (ordered so that no leader crosses a label above it), the rest sit right of it.
    var HEAD_LIMIT = 15;
    var headGroup = stations.filter(function (st) { return st.z < HEAD_LIMIT; })
      .sort(function (a, b) { return a.z - b.z; });
    var farGroup = stations.filter(function (st) { return st.z >= HEAD_LIMIT; })
      .sort(function (a, b) { return b.z - a.z; });

    var lowest = 0;
    function placeRow(st, row, anchor) {
      var yMid = Rup + 3.6 + row * TIER_DOWN;
      lowest = Math.max(lowest, yMid + 1.4);
      lines.push(seg(st.z, -st.r, st.z, st.r));
      lines = lines.concat(arrow(st.z, -st.r, 0, -1), arrow(st.z, st.r, 0, 1));
      lines.push(seg(st.z, st.r, st.z, yMid, 'ext'));
      var x = anchor === 'end' ? st.z - 0.6 : st.z + 0.6;
      addLabel(st.text, anchor, x, yMid + (ASC - DESC) / 2);
    }
    headGroup.forEach(function (st, row) { placeRow(st, row, 'end'); });
    farGroup.forEach(function (st, row) { placeRow(st, row, 'start'); });

    // ---- Shoulder angle alpha: arc at the cone apex, label above the axial tiers
    var notes = g.notes.map(function (n) { return n.text; });
    if (g.shoulder.present && isNum(V.alpha)) {
      var P2r = V.P2 / 2;
      var H1r = V.H1 / 2;
      var slope = (H1r - P2r) / (lengths.L2 - lengths.L1); // negative: the cone narrows to the mouth
      var apexZ = lengths.L1 - P2r / slope;
      var half = V.alpha * Math.PI / 360;
      var arcPts = [];
      // Full included angle: from the lower shoulder line (y > 0) to the upper one (y < 0).
      for (var i = 0; i <= 24; i++) {
        var th = -half + 2 * half * i / 24;
        arcPts.push({ x: apexZ - ALPHA_R * Math.cos(th), y: -ALPHA_R * Math.sin(th) });
      }
      for (var j = 0; j + 1 < arcPts.length; j++) {
        lines.push(seg(arcPts[j].x, arcPts[j].y, arcPts[j + 1].x, arcPts[j + 1].y, 'arc'));
      }
      var labelText = 'α ' + F.formatAngle(V.alphaPublished);
      var baseline = topTierY - 7.0;
      addLabel(labelText, 'middle', apexZ, baseline);
      var target = { x: apexZ - ALPHA_R * Math.cos(half / 2), y: -ALPHA_R * Math.sin(half / 2) };
      lines.push(seg(apexZ, baseline + DESC + 0.4, target.x, target.y, 'ext'));
    }

    // ---- Extents, title block
    var xs = [];
    var ys = [];
    upper.forEach(function (p) { xs.push(p.x); ys.push(p.y); });
    caseSec.forEach(function (p) { xs.push(p.x); ys.push(p.y); });
    labels.forEach(function (l) { xs.push(l.box.x0, l.box.x1); ys.push(l.box.y0, l.box.y1); });
    lines.forEach(function (l) { xs.push(l.x1, l.x2); ys.push(l.y1, l.y2); });
    var minX = Math.min.apply(null, xs);
    var maxX = Math.max.apply(null, xs);
    var minY = Math.min.apply(null, ys);
    var maxY = Math.max.apply(null, ys);

    var tbTop = Math.max(maxY, lowest, Rup) + 3.0;
    var tbLines = [
      record.name,
      'C.I.P. table ' + record.tab + '  ·  revised ' + record.revised,
      'Dimensions in mm  ·  Scale 1:1'
    ];
    var tbHeight = 4 + 3.6 * 2 + 2 + notes.length * 3.2 + 1.5;
    // The title block is at least as wide as its longest line.
    var tbNeeded = 3 + Math.max.apply(null, tbLines.map(function (t, i) {
      return Array.from(t).length * (i === 0 ? 4.2 : 2.8) * CHAR_W;
    }).concat(notes.map(function (n) { return Array.from(n).length * 2.8 * CHAR_W; })));
    var tbRight = Math.max(maxX, minX + tbNeeded);
    var tbBox = { x0: minX, y0: tbTop, x1: tbRight, y1: tbTop + tbHeight };

    var viewBox = {
      x: minX - 2,
      y: minY - 2,
      w: (tbRight - minX) + 4,
      h: (tbBox.y1 - minY) + 4
    };

    return {
      drawable: true,
      key: record.key,
      name: record.name,
      hatchId: 'hatch-' + record.key,
      viewBox: viewBox,
      outline: outline,
      section: bulletSec ? [caseSec, bulletSec] : [caseSec],
      centre: { x1: minX, x2: maxX, y: 0 },
      lines: lines,
      labels: labels,
      titleBlock: { box: tbBox, lines: tbLines },
      notes: notes
    };
  }

  function isNum(x) {
    return typeof x === 'number' && isFinite(x);
  }

  function round(v) {
    return Math.round(v * 1000) / 1000;
  }

  function esc(text) {
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function pathOf(points) {
    return points.map(function (p, i) {
      return (i === 0 ? 'M' : 'L') + round(p.x) + ' ' + round(p.y);
    }).join(' ');
  }

  function toSvg(record) {
    var s = scene(record);
    var label = esc(record.name) + ' drawing';
    if (!s.drawable) {
      return '<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' + label + '" viewBox="0 0 100 20">'
        + '<text x="2" y="10" font-size="4">Not drawn: ' + esc(s.notes.join(' ')) + '</text></svg>';
    }
    var vb = s.viewBox;
    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" class="drawing" role="img" aria-label="' + label + '"'
      + ' viewBox="' + round(vb.x) + ' ' + round(vb.y) + ' ' + round(vb.w) + ' ' + round(vb.h) + '">');
    out.push('<title>' + label + '</title>');
    out.push('<defs><pattern id="' + s.hatchId + '" patternUnits="userSpaceOnUse" width="1.4" height="1.4"'
      + ' patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="1.4" class="hatch"/></pattern></defs>');
    out.push('<line class="centre" x1="' + round(s.centre.x1) + '" y1="0" x2="' + round(s.centre.x2)
      + '" y2="0" stroke-dasharray="12 2.5 2.5 2.5" vector-effect="non-scaling-stroke"/>');
    s.section.forEach(function (poly) {
      out.push('<path class="section" d="' + pathOf(poly) + ' Z" fill="url(#' + s.hatchId + ')"/>');
    });
    out.push('<path class="outline" d="' + pathOf(s.outline[0]) + '"/>');
    s.outline.slice(1).forEach(function (poly) {
      out.push('<path class="outline" d="' + pathOf(poly) + '"/>');
    });
    var dims = s.lines.filter(function (l) { return l.cls === 'dim' || l.cls === 'ext' || l.cls === 'arc'; });
    var arrows = s.lines.filter(function (l) { return l.cls === 'arrow'; });
    dims.forEach(function (l) {
      out.push('<path class="' + (l.cls === 'ext' ? 'ext' : l.cls === 'arc' ? 'arc' : 'dim') + '" d="M'
        + round(l.x1) + ' ' + round(l.y1) + ' L' + round(l.x2) + ' ' + round(l.y2) + '"/>');
    });
    arrows.forEach(function (l) {
      out.push('<path class="arrow" d="M' + round(l.x1) + ' ' + round(l.y1) + ' L' + round(l.x2) + ' ' + round(l.y2) + '"/>');
    });
    s.labels.forEach(function (l) {
      out.push('<text class="label" x="' + round(l.x) + '" y="' + round(l.y) + '" text-anchor="'
        + l.anchor + '">' + esc(l.text) + '</text>');
    });
    var tb = s.titleBlock.box;
    out.push('<rect class="titleblock" x="' + round(tb.x0) + '" y="' + round(tb.y0) + '" width="' + round(tb.x1 - tb.x0)
      + '" height="' + round(tb.y1 - tb.y0) + '"/>');
    var ty = tb.y0 + 4.2;
    out.push('<text class="tb-name" x="' + round(tb.x0 + 1.5) + '" y="' + round(ty) + '">' + esc(s.titleBlock.lines[0]) + '</text>');
    out.push('<text class="tb-line" x="' + round(tb.x0 + 1.5) + '" y="' + round(ty + 3.6) + '">' + esc(s.titleBlock.lines[1]) + '</text>');
    out.push('<text class="tb-line" x="' + round(tb.x0 + 1.5) + '" y="' + round(ty + 7.2) + '">' + esc(s.titleBlock.lines[2]) + '</text>');
    s.notes.forEach(function (n, i) {
      out.push('<text class="tb-note" x="' + round(tb.x0 + 1.5) + '" y="' + round(ty + 10.2 + i * 3.2) + '">' + esc(n) + '</text>');
    });
    out.push('</svg>');
    return out.join('');
  }

  CIP.drawing = { scene: scene, toSvg: toSvg, labelBox: labelBox, textWidth: textWidth };
})(typeof window !== 'undefined' ? window : globalThis);
