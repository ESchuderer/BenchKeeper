// Value formatting, symbols and units for the cartridge tables.
// Plain browser script: exposes window.CIP.format (also reachable from Node via a vm loader in tests).
(function (global) {
  'use strict';
  var CIP = global.CIP = global.CIP || {};

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  var ANGLES = { alpha: true, alpha1: true, beta: true, delta: true, i: true };
  var COUNTS = { N: true };
  var UNITS = { Q: 'mm²', Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g' };

  function formatNumber(n) {
    return String(n);
  }

  function pad2(text) {
    var s = String(text);
    return s.length < 2 ? '0' + s : s;
  }

  // Numbers as published; a whole-number seconds field is padded to two digits.
  function formatAngle(a) {
    if (typeof a === 'number') return formatNumber(a) + '°';
    var minutes = pad2(typeof a.minutes === 'number' ? a.minutes : 0);
    var seconds = typeof a.seconds === 'number' && a.seconds % 1 !== 0
      ? formatNumber(a.seconds)
      : pad2(typeof a.seconds === 'number' ? a.seconds : 0);
    return a.degrees + '°' + minutes + '\'' + seconds + '"';
  }

  function formatQuantity(value, tolerance) {
    var text = typeof value === 'number' ? formatNumber(value) : String(value);
    if (tolerance !== undefined && tolerance !== null) {
      text += ' ' + formatNumber(tolerance);
    }
    return text;
  }

  function symbolFor(name) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, name) ? SYMBOLS[name] : name;
  }

  function isAngle(name) {
    return ANGLES[name] === true;
  }

  function isCount(name) {
    return COUNTS[name] === true;
  }

  function unitFor(name) {
    if (isAngle(name) || isCount(name)) return '';
    if (Object.prototype.hasOwnProperty.call(UNITS, name)) return UNITS[name];
    return 'mm';
  }

  CIP.format = {
    formatNumber: formatNumber,
    formatAngle: formatAngle,
    formatQuantity: formatQuantity,
    symbolFor: symbolFor,
    unitFor: unitFor,
    isAngle: isAngle,
    isCount: isCount
  };
})(typeof window !== 'undefined' ? window : globalThis);
