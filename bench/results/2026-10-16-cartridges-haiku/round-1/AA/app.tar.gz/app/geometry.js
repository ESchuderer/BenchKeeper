// Geometry engine: builds the outer profile, bullet, section walls and notes from a record.
// Coordinates are {z, r}: z along the axis from the head face (z = 0) to the mouth, r the radius.
// Units: mm. Angles are converted to radians internally. Nothing is invented: a feature whose
// published values are missing is left out and a note says which value is missing.
(function (global) {
  'use strict';
  var CIP = global.CIP = global.CIP || {};

  var RAD = Math.PI / 180;
  var EPS = 1e-9;

  function isNum(x) {
    return typeof x === 'number' && isFinite(x);
  }

  // Angle as degrees; accepts a number or {degrees, minutes, seconds}.
  function degrees(a) {
    if (isNum(a)) return a;
    if (a && typeof a === 'object' && isNum(a.degrees)) {
      return a.degrees + (isNum(a.minutes) ? a.minutes / 60 : 0) + (isNum(a.seconds) ? a.seconds / 3600 : 0);
    }
    return undefined;
  }

  function sub(a, b) { return { z: a.z - b.z, r: a.r - b.r }; }
  function add(a, b) { return { z: a.z + b.z, r: a.r + b.r }; }
  function scale(a, k) { return { z: a.z * k, r: a.r * k }; }
  function len(a) { return Math.hypot(a.z, a.r); }
  function unit(a) { var l = len(a); return l > 0 ? scale(a, 1 / l) : { z: 0, r: 0 }; }
  function dot(a, b) { return a.z * b.z + a.r * b.r; }

  function wrapAngle(a) {
    while (a <= -Math.PI) a += 2 * Math.PI;
    while (a > Math.PI) a -= 2 * Math.PI;
    return a;
  }

  // Rounded corner between the segments prev->corner->next, radius r. The arc is sampled.
  function fillet(prev, corner, next, radius, samples) {
    var n = samples || 12;
    var u1 = unit(sub(prev, corner));
    var u2 = unit(sub(next, corner));
    var theta = Math.acos(Math.max(-1, Math.min(1, dot(u1, u2))));
    var t = radius / Math.tan(theta / 2);
    var t1 = add(corner, scale(u1, t));
    var t2 = add(corner, scale(u2, t));
    var bis = unit(add(u1, u2));
    var centre = add(corner, scale(bis, radius / Math.sin(theta / 2)));
    var a1 = Math.atan2(t1.r - centre.r, t1.z - centre.z);
    var a2 = Math.atan2(t2.r - centre.r, t2.z - centre.z);
    var sweep = wrapAngle(a2 - a1);
    var points = [];
    for (var i = 0; i <= n; i++) {
      var a = a1 + sweep * i / n;
      points.push({ z: centre.z + radius * Math.cos(a), r: centre.r + radius * Math.sin(a) });
    }
    // Snap the end points exactly onto the tangent points.
    points[0] = t1;
    points[n] = t2;
    return { radius: radius, tangent: t, centre: { z: centre.z, r: centre.r }, start: t1, end: t2, points: points };
  }

  function rimType(record) {
    var c = record.cartridge || {};
    var ch = c.caseHead || {};
    var pc = c.powderChamber || {};
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    var ratio = ch.R1 / pc.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Primer pocket for centrefire cases (brief rule 8). Rimfire and unknown types have none.
  var POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  function radiusAt(points, z) {
    for (var i = 0; i + 1 < points.length; i++) {
      var a = points[i];
      var b = points[i + 1];
      if (b.z - a.z <= EPS) continue;
      if (z >= a.z - EPS && z <= b.z + EPS) {
        var t = (z - a.z) / (b.z - a.z);
        return a.r + t * (b.r - a.r);
      }
    }
    return undefined;
  }

  // Nose of the bullet from the cylinder end (zs) to the tip (L6).
  function noseFor(shape, Rexp, G1, zs, L6) {
    var n = L6 - zs;
    if (shape === 'pointy') {
      var m = Math.max(0.08 * G1, 1.27);
      var d = Rexp - m / 2;
      var rho = (d * d + n * n) / (2 * d);
      var phiEnd = Math.atan2(n, rho - d);
      var centreR = Rexp - rho;
      var pts = [];
      var steps = 32;
      for (var i = 0; i <= steps; i++) {
        var phi = phiEnd * i / steps;
        pts.push({ z: zs + rho * Math.sin(phi), r: centreR + rho * Math.cos(phi) });
      }
      return { m: m, points: pts, ogiveRadius: rho };
    }
    if (shape === 'rounded') {
      var mr = 0.15 * G1;
      var a = Rexp - mr / 2;
      var out = [];
      var k = 32;
      for (var j = 0; j <= k; j++) {
        var th = (Math.PI / 2) * j / k;
        out.push({ z: zs + n * Math.sin(th), r: mr / 2 + a * Math.cos(th) });
      }
      return { m: mr, points: out, ogiveRadius: null };
    }
    if (shape === 'flat') {
      var mf = 0.55 * G1;
      return { m: mf, points: [{ z: zs, r: Rexp }, { z: L6, r: mf / 2 }], ogiveRadius: null };
    }
    if (shape === 'semi_wadcutter') {
      var ms = 0.6 * G1;
      return { m: ms, points: [{ z: zs, r: Rexp }, { z: L6, r: ms / 2 }], ogiveRadius: null };
    }
    return null;
  }

  // Seating depth s and cylinder fraction k (brief rule 7).
  function bulletProportions(shape, category, G1) {
    var rifleOrRimfire = category !== 'pistol';
    if (shape === 'pointy') return { s: G1, k: 0.40 };
    if (shape === 'rounded') return rifleOrRimfire ? { s: 0.8 * G1, k: 0.55 } : { s: 0.4 * G1, k: 0.65 };
    if (shape === 'flat') return rifleOrRimfire ? { s: 0.8 * G1, k: 0.60 } : { s: 0.4 * G1, k: 0.70 };
    if (shape === 'semi_wadcutter') return { s: 0.6 * G1, k: 0.78 };
    return null;
  }

  function build(record) {
    var ann = record.annotations || {};
    var c = record.cartridge || {};
    var ch = c.caseHead || {};
    var J = c.junctionCone || {};
    var L = c.lengths || {};
    var PC = c.powderChamber || {};
    var CO = c.collar || {};
    var PR = c.projectile || {};
    var notes = [];

    function note(symbol, text) {
      notes.push({ missing: symbol, text: text });
    }

    var R1 = ch.R1;
    var R = ch.R;
    var E = ch.E;
    var E1 = ch.E1;
    var eMin = ch.eMin;
    var f = ch.f;
    var beta = degrees(ch.beta);
    var delta = degrees(ch.delta);
    var R3 = ch.R3;
    var P1 = PC.P1;
    var P2 = PC.P2;
    var H1 = CO.H1;
    var H2 = CO.H2;
    var G1 = PR.G1;
    var L1 = L.L1;
    var L2 = L.L2;
    var L3 = L.L3;
    var L6 = L.L6;
    var alpha = degrees(J.alpha);
    var r1Min = J.r1Min;
    var r2 = J.r2;

    var essentials = { R1: R1, P1: P1, R: R, L3: L3, L6: L6, G1: G1, H2: H2 };
    var lacking = Object.keys(essentials).filter(function (k) { return !isNum(essentials[k]); });
    if (lacking.length) {
      notes.push({ missing: lacking.join(', '), text: 'Not drawn: ' + lacking.join(', ') + ' not published.' });
      return { key: record.key, name: record.name, drawable: false, notes: notes };
    }

    var rim = rimType(record);
    var bulletShape = ann.defaultBulletShape;
    var category = ann.category;
    var hasGroove = isNum(E) && isNum(E1);
    if (isNum(E) !== isNum(E1)) {
      note(isNum(E) ? 'E1' : 'E', 'Extractor groove not drawn: ' + (isNum(E) ? 'E1' : 'E') + ' not published.');
    }

    // ---- Head face and rim edge (brief rule 2)
    var outer = [{ z: 0, r: 0 }];
    if (rim === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      var cr = R1 / 2 - rho;
      // The half-round is sampled directly: centre (cr, rho), radius rho, from the face to the rim top.
      var halfRound = [];
      for (var i = 0; i <= 12; i++) {
        var th = -Math.PI / 2 + Math.PI * i / 12;
        halfRound.push({ z: rho + rho * Math.sin(th), r: cr + rho * Math.cos(th) });
      }
      outer = outer.concat(halfRound);
      if (2 * rho < R - EPS) outer.push({ z: R, r: cr });
    } else {
      var hasChamfer = isNum(beta) && isNum(f) && beta < 90;
      if (!hasChamfer && (!isNum(beta) || !isNum(f))) {
        var missingHead = !isNum(beta) ? 'beta' : 'f';
        note(missingHead, 'Head chamfer not drawn: ' + missingHead + ' not published.');
      }
      if (isNum(beta) && isNum(f) && beta >= 90) {
        note('beta', 'Head chamfer not drawn: beta is 90° or more.');
      }
      if (hasChamfer) {
        var x = Math.min(f * Math.tan(beta * RAD), R1 / 4);
        outer.push({ z: 0, r: R1 / 2 - x }, { z: f, r: R1 / 2 });
      } else {
        outer.push({ z: 0, r: R1 / 2 });
      }
      outer.push({ z: R, r: R1 / 2 });
    }

    // ---- Extractor groove (brief rule 3) and body start
    var groove = { present: false };
    var bodyStart;
    var belt = null;
    var rampEnd;
    if (hasGroove) {
      var floorZ = isNum(eMin) ? R + eMin : R;
      if (!isNum(eMin)) note('e min', 'Groove floor not drawn: e min not published.');
      outer.push({ z: R, r: E1 / 2 }, { z: floorZ, r: E1 / 2 });
      groove = { present: true, E: E, E1: E1, floorZ: floorZ };
      var useBelt = rim === 'belted' && isNum(R3) && isNum(delta);
      if (rim === 'belted' && !useBelt) {
        note(!isNum(R3) ? 'R3' : 'delta', 'Belt ramp not drawn: ' + (!isNum(R3) ? 'R3' : 'delta') + ' not published; a straight ramp is drawn.');
      }
      if (useBelt) {
        var beltR = R3 / 2;
        rampEnd = floorZ + (beltR - E1 / 2) / Math.tan(delta * RAD);
        belt = { radius: beltR, rampEnd: rampEnd };
        outer.push({ z: rampEnd, r: beltR }, { z: E, r: beltR });
        groove.rampEnd = rampEnd;
      }
      outer.push({ z: E, r: P1 / 2 });
      bodyStart = E;
    } else {
      outer.push({ z: R, r: P1 / 2 });
      bodyStart = R;
    }

    // ---- Body, shoulder and neck (brief rules 4-6)
    var anyShoulderValue = isNum(alpha) || isNum(P2) || isNum(H1) || isNum(L1) || isNum(L2);
    var bottleneck = isNum(alpha) && isNum(P2) && isNum(H1) && isNum(L1) && isNum(L2);
    if (anyShoulderValue && !bottleneck) {
      var shoulderMissing = ['alpha', 'P2', 'H1', 'L1', 'L2'].filter(function (k) {
        var v = { alpha: alpha, P2: P2, H1: H1, L1: L1, L2: L2 }[k];
        return !isNum(v);
      });
      note(shoulderMissing.join(', '), 'Shoulder not drawn: ' + shoulderMissing.join(', ') + ' not published; the case is drawn straight.');
    }

    var shoulder = { present: false, alphaDeg: alpha, fillets: { body: null, neck: null } };
    if (bottleneck) {
      var A = { z: bodyStart, r: P1 / 2 };
      var B = { z: L1, r: P2 / 2 };
      var C = { z: L2, r: H1 / 2 };
      var D = { z: L3, r: H2 / 2 };
      var fBody = null;
      var fNeck = null;
      if (isNum(r1Min)) {
        fBody = fillet(A, B, C, r1Min);
        if (fBody.tangent > len(sub(B, A)) || fBody.tangent > len(sub(C, B))) {
          note('r1 min', 'Shoulder corner at the body: r1 min does not fit the adjacent lines; drawn sharp.');
          fBody = null;
        }
      } else {
        note('r1 min', 'Shoulder corner at the body not rounded: r1 min not published.');
      }
      if (isNum(r2)) {
        fNeck = fillet(B, C, D, r2);
        if (fNeck.tangent > len(sub(C, B)) || fNeck.tangent > len(sub(D, C))) {
          note('r2', 'Shoulder corner at the neck: r2 does not fit the adjacent lines; drawn sharp.');
          fNeck = null;
        }
      } else {
        note('r2', 'Shoulder corner at the neck not rounded: r2 not published.');
      }
      if (fBody) outer = outer.concat(fBody.points);
      else outer.push(B);
      if (fNeck) outer = outer.concat(fNeck.points);
      else outer.push(C);
      outer.push(D);
      shoulder = {
        present: true,
        alphaDeg: alpha,
        body: B,
        neck: C,
        fillets: { body: fBody, neck: fNeck }
      };
    } else {
      outer.push({ z: L3, r: H2 / 2 });
    }
    var mouthOuter = { z: L3, r: H2 / 2 };

    // ---- Bullet (brief rule 7)
    var heeled = H2 - G1 <= 0.015;
    var Rexp = heeled ? H2 / 2 : G1 / 2;
    var bullet = null;
    var prop = bulletProportions(bulletShape, category, G1);
    if (!prop) {
      note('nose shape', 'Bullet not drawn: nose shape (defaultBulletShape) not published.');
    } else {
      var s = prop.s;
      var zb = L3 - s;
      var Lb = L6 - zb;
      var zs = zb + prop.k * Lb;
      var nose = noseFor(bulletShape, Rexp, G1, zs, L6);
      var exposed = [{ z: L3, r: Rexp }].concat(nose.points);
      bullet = {
        shape: bulletShape,
        s: s,
        k: prop.k,
        zb: zb,
        Lb: Lb,
        zs: zs,
        n: L6 - zs,
        m: nose.m,
        ogiveRadius: nose.ogiveRadius,
        heeled: heeled,
        exposedRadius: Rexp,
        nose: nose.points,
        exposed: exposed
      };
    }

    // ---- Section walls (brief rule 8)
    var tn = (H2 - G1) / 2;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
    var walls = { tn: tn, tb: tb };
    if (bullet) {
      if (heeled) {
        bullet.heelRadius = H2 / 2 - tb;
        bullet.section = [{ z: bullet.zb, r: 0 }, { z: bullet.zb, r: H2 / 2 - tb }, { z: L3, r: H2 / 2 - tb }]
          .concat(bullet.exposed)
          .concat([{ z: L6, r: 0 }]);
      } else {
        bullet.section = [{ z: bullet.zb, r: 0 }, { z: bullet.zb, r: G1 / 2 }]
          .concat(bullet.exposed)
          .concat([{ z: L6, r: 0 }]);
      }
    }

    var pocket = null;
    var pType = ann.primerType;
    if (isNum(POCKET_DIAMETER[pType])) {
      pocket = { diameter: POCKET_DIAMETER[pType], depth: POCKET_DEPTH[pType] };
    } else if (rim !== 'rimfire') {
      note('primer type', 'Primer pocket not drawn: primer type ' + (pType || '(none)') + ' is not a centrefire type.');
    }

    var termGroove = 0;
    if (rim === 'belted' && belt) termGroove = belt.rampEnd + tb;
    else if (groove.present) termGroove = E + tb;
    var w = Math.max(2.5, 0.25 * P1 / 2, pocket ? pocket.depth + 1.5 : 0, termGroove);

    // Inner (cavity) profile from the solid head to the mouth.
    var rOuterW = radiusAt(outer, w);
    var rInW = rOuterW - tb;
    var inner;
    if (bottleneck) {
      inner = [
        { z: w, r: rInW },
        { z: L1, r: P2 / 2 - tb },
        { z: L2, r: H1 / 2 - tn },
        { z: L3, r: H2 / 2 - tn }
      ];
    } else {
      inner = [{ z: w, r: rInW }, { z: L3, r: H2 / 2 - tb }];
    }
    var rInnerMouth = inner[inner.length - 1].r;

    // Section polygon in the half plane r >= 0: outer profile, mouth, inner profile back to the axis.
    var start = pocket
      ? [{ z: pocket.depth, r: 0 }, { z: pocket.depth, r: pocket.diameter / 2 }, { z: 0, r: pocket.diameter / 2 }]
      : [{ z: 0, r: 0 }];
    var reversedInner = inner.slice().reverse();
    var caseSection = start
      .concat(outer.slice(1))
      .concat(reversedInner)
      .concat([{ z: w, r: 0 }]);

    return {
      key: record.key,
      name: record.name,
      drawable: true,
      rimType: rim,
      category: category,
      bulletShape: bulletShape,
      outer: outer,
      mouth: { z: L3, rOuter: mouthOuter.r, rInner: rInnerMouth },
      groove: groove,
      shoulder: shoulder,
      bullet: bullet,
      walls: walls,
      w: w,
      pocket: pocket,
      inner: inner,
      caseSection: caseSection,
      values: {
        R1: R1, R: R, P1: P1, P2: P2, H1: H1, H2: H2, G1: G1, E: E, E1: E1,
        L1: L1, L2: L2, L3: L3, L6: L6, alpha: alpha, alphaPublished: J.alpha
      },
      notes: notes
    };
  }

  CIP.geometry = {
    build: build,
    rimType: rimType,
    fillet: fillet,
    degrees: degrees
  };
})(typeof window !== 'undefined' ? window : globalThis);
