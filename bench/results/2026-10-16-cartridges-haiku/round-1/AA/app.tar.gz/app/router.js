// Hash routing: '#/' is the list, '#/cartridge/<key>' is a detail view.
(function (global) {
  'use strict';
  var CIP = global.CIP = global.CIP || {};

  var PREFIX = '#/cartridge/';

  function parse(hash) {
    var h = String(hash || '');
    if (h.indexOf(PREFIX) === 0 && h.length > PREFIX.length) {
      try {
        return { view: 'detail', key: decodeURIComponent(h.slice(PREFIX.length)) };
      } catch (e) {
        return { view: 'list' }; // malformed escape sequence: treat as unknown
      }
    }
    return { view: 'list' };
  }

  function resolve(hash, records) {
    var route = parse(hash);
    if (route.view !== 'detail') return { view: 'list' };
    var record = null;
    for (var i = 0; i < records.length; i++) {
      if (records[i].key === route.key) { record = records[i]; break; }
    }
    return record ? { view: 'detail', record: record } : { view: 'list' };
  }

  function hrefFor(key) {
    return PREFIX + encodeURIComponent(key);
  }

  CIP.router = { parse: parse, resolve: resolve, hrefFor: hrefFor };
})(typeof window !== 'undefined' ? window : globalThis);
