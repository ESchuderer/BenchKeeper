// Builds the grouped value tables (Symbol, Value, Unit) for a cartridge record.
(function (global) {
  'use strict';
  var CIP = global.CIP = global.CIP || {};
  var F = CIP.format;

  function sectionTitle(key) {
    var words = key.replace(/([A-Z])/g, ' $1').toLowerCase();
    return words.charAt(0).toUpperCase() + words.slice(1);
  }

  function isTolerance(key, container) {
    return /Tol$/.test(key) && Object.prototype.hasOwnProperty.call(container, key.slice(0, -3));
  }

  function valueText(key, value, container) {
    if (value !== null && typeof value === 'object') return F.formatAngle(value);
    if (typeof value === 'number') {
      if (F.isAngle(key)) return F.formatAngle(value);
      var tol = container[key + 'Tol'];
      return F.formatQuantity(value, typeof tol === 'number' ? tol : undefined);
    }
    return String(value);
  }

  function rowsFor(container) {
    var rows = [];
    Object.keys(container).forEach(function (key) {
      if (isTolerance(key, container)) return;
      var value = container[key];
      rows.push({
        symbol: F.symbolFor(key),
        value: valueText(key, value, container),
        unit: F.unitFor(key)
      });
    });
    return rows;
  }

  function sectionsFor(block) {
    if (!block) return [];
    return Object.keys(block)
      .filter(function (key) { return block[key] !== null && typeof block[key] === 'object'; })
      .map(function (key) {
        return { title: sectionTitle(key), rows: rowsFor(block[key]) };
      });
  }

  function build(record) {
    var cartridge = record.cartridge || {};
    var chamber = record.chamber || {};
    return [
      { title: 'Cartridge', sections: sectionsFor(cartridge) },
      { title: 'Chamber', sections: sectionsFor(chamber) }
    ];
  }

  CIP.sections = { build: build, sectionTitle: sectionTitle };
})(typeof window !== 'undefined' ? window : globalThis);
