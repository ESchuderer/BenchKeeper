# Design

## Context

The repository is empty apart from `AGENTS.md` and the OpenSpec scaffolding. The app must open from `file://` in Chromium, so ES modules and `fetch` of local JSON are unavailable; plain classic `<script>` tags and a data file that defines a global are required. See proposal.md for motivation.

## Goals / Non-Goals

**Goals:**
- One static page, no build step, no runtime dependencies, no network.
- Geometry and formatting are pure functions, testable in Node without a browser.
- Drawing is deterministic SVG computed from the record, with no overlapping labels.

**Non-Goals:**
- Bullet ballistics, pressure calculations, or any values beyond those in the records.
- Editing, sorting, or other catalogue features not in the brief.
- Internationalisation (the UI is English).

## Decisions

**1. Classic scripts with a global namespace.** Files are loaded with plain `<script src>` in dependency order. Each module ends with a UMD-style export: it sets `window.CIP.<module>` in the browser and `module.exports` under Node. Alternative considered: ES modules. Rejected: Chromium blocks module scripts over `file://`.

**2. Data as a generated JS file.** `data/cartridges.jsonl` is the verbatim source (the 25 records, one per line, `\"` in the brief read as `"`). `cartridges-data.js` assigns `window.CIP_CARTRIDGES = [...]` and is generated from the JSONL by `scripts/build-data.js`. A test checks that the generated file parses to exactly the JSONL records. Alternative: hand-maintained JS literal. Rejected: no independent check of transcription.

**3. Hash routing.** Detail addresses are `#/cartridge/<key>`; the root is `#/` (or empty). `hashchange` re-renders. Unknown keys fall back to the list. Works on `file://` and any static server, survives reload and bookmarks.

**4. Coordinates in the geometry engine are `(z, r)`** — z along the axis from the head face, r the radius, as in the brief. Points are arrays of `{z, r}`. The drawing module maps them to SVG as `x = X0 + z`, upper half `y = Y0 - r`, lower half `y = Y0 + r`. Keeping the brief's convention avoids transposition mistakes against the rules.

**5. Fillets.** Shoulder fillets are computed from the deflection angle at each corner: tangent length `t = r·tan(φ/2)`, with φ the angle between the adjacent segments. The engine emits sampled arc points so the drawing needs no arc primitives. Inner (section) shoulder corners are sharp.

**6. Bullet nose geometry** follows the brief exactly: tangent ogive for pointy (centre on the radial line at the nose start), quarter ellipse for rounded (tangent to the cylinder at its start and perpendicular to the axis at the tip), straight cones for flat and semi-wadcutter.

**6a. Belted solid head.** The brief lists "E + tb where a groove exists" and "the belt ramp end + tb on belted cases" as alternatives. The engine uses the belt ramp end for belted cases and E + tb for other grooved cases; reading both as terms of the maximum makes the belt term never apply (E is always beyond the ramp end).

**6b. Body taper.** A case with no alpha, L1 or L2 has no shoulder; its body still runs from P1/2 to H2/2 as rule 4 states.

**7. Units for undocumented fields.** The brief gives units for lengths, diameters, pressures, EE, M, Q, N and angles. Fields it does not name (`S`, `Fe`, `deltaL`, `G`, `b`, `h`, `s`, `u`, `Z`, `F`, `G2`, `L4`, `L5`, `R3`) are shown in `mm`: they are all dimensional quantities in the source. `S` is the least certain of these and is flagged in the summary for confirmation.

**8. Label placement by search, verified by tests.** Axial dimensions (L1, L2, L3, L6) go in stacked tiers above the outline, ordered by station so that no extension line crosses a shorter dimension's label. Radial dimensions (diameters) use a full-span vertical dimension line with arrowheads at the outline, a vertical leader, and a label placed by a greedy search over candidate positions below the lower outline, where the section carries no other annotation. The angle α is drawn as an arc inside the empty outside-view area, with its label placed by the same search. Each candidate is checked against outline segments, placed labels, and dimension lines. Text width is estimated from character count with a fixed em factor; the tests assert the estimate is conservative for the font used.

**9. Title block and scale.** The title block is part of the SVG, below the section. The scale reads `1:1` in model units; the printed scale depends on fit-to-width and is not claimed.

**10. Print.** A print stylesheet hides navigation, search, filters and buttons, sets A4 portrait with 12 mm margins, black on white, and lays each group's value table in four columns at a small font. The drawing fills the printed width up to a fixed height (116 mm): full width is kept for wide drawings, while tall drawings (which the full-width rule cannot fit with the tables on one page) are limited by height. Chromium is the reference for the page-count check; all 25 records print on one page.

**11. Dark mode.** `prefers-color-scheme` drives CSS custom properties; the drawing uses `currentColor` / CSS variables so it follows the scheme on screen and is forced to black on white in print.

## Risks / Trade-offs

- [Label overlap in dense areas (head: R1, E1, P1, R all within 10 mm)] → Greedy search over offsets and tiers, tests assert no overlap for all 25 records, and the drawing is re-checked visually with a headless browser screenshot.
- [Missing values produce partial drawings] → Explicit notes in the drawing's footer list each omitted feature; tests cover 338 Lapua Mag. (no `r1Min`) and rimless cases without a groove.
- [Text width estimate differs from the browser's font] → Estimate is conservative (0.62 em per character at the chosen size); the end-to-end test measures real text boxes with `getBBox` in Chromium.
- [Print is not one page for long tables] → Two-column tables and a checked page count in the end-to-end test; if it fails, font size is reduced rather than content dropped.

## Migration Plan

Greenfield: no migration. Rollback is deleting the new files.

## Open Questions

None that change the specs or the task breakdown. The unit of `S` is assumed to be mm (see decision 7) and will be reported in the summary.
