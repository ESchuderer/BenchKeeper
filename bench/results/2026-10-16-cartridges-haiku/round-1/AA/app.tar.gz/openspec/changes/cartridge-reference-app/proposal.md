## Why

Reloaders, gunsmiths and engineers need a quick, offline reference for C.I.P.-published cartridge data, with a scaled drawing of each case and chamber. The OpenBallistics cartridge database shows what is wanted, but it is a hosted, framework-built site. This change delivers a single static page that works from disk, with the 25 supplied records as its only data.

## What Changes

- Add a static single-page reference app: `index.html` with `styles.css` and classic JavaScript files, no build step, no runtime dependencies, no network requests.
- Start page: list of all 25 cartridges (name link, family, case length L3), a "Search" field matching names and alternative names, a "Family" select, and a "<n> cartridges" count.
- Detail view per cartridge, addressed by its own bookmarkable URL fragment: heading, alternative names, metadata, published water capacity with source link, an inline SVG drawing computed from the record, and all cartridge and chamber values in sectioned tables.
- Geometry engine that derives the outside profile, the section walls, and the bullet from the record using the rules in the brief, and reports any feature that could not be drawn because a value is missing.
- Print: a "Print" button opening the browser print dialog; a print stylesheet producing one A4 portrait, black-on-white page per cartridge.
- Light and dark colour schemes following the system setting on screen; print is always light.
- Development-only test tooling (Node's built-in test runner; a browser driver for end-to-end checks) kept out of the app.

Breaking changes: none (greenfield).

## Capabilities

### New Capabilities

- `cartridge-catalog`: the start page, search and family filter, the count, and hash-based navigation to detail views.
- `cartridge-detail`: the detail view contents (metadata, value tables, grouping, symbols, units, value formatting), the print output, and the back link.
- `cartridge-drawing`: the computed 2D drawing (geometry rules, dimensions, labels, title block, scaling and print legibility).

### Modified Capabilities

None.

## Impact

- New files at the repository root: `index.html`, `styles.css`, `app/*.js` (plain scripts, including the generated `app/cartridges-data.js`), `data/cartridges.jsonl` (verbatim source records), `scripts/build-data.js` (generates the data script), `package.json` (scripts only), `tests/` (unit and end-to-end tests).
- Dev dependencies only: `playwright` for end-to-end tests. No runtime dependencies.
- No server code, no CDN, no web fonts, no analytics.
