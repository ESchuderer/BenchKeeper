## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL have the heading "Cartridges" and SHALL list every record in the dataset (25 records). Each entry SHALL show the cartridge's family and its case length L3 (with tolerance when published), and its name SHALL be a link whose visible text is exactly the record's `name`. Following the link SHALL open that cartridge's detail view.

#### Scenario: All records listed
- **WHEN** the start page is shown with no filter applied
- **THEN** 25 entries are listed, each with a link whose text equals the record's `name` (for example `6,5 Creedmoor`)
- **AND** the count text reads `25 cartridges`

### Requirement: Search filters by name and alternative names
A text field labelled "Search" SHALL filter the list as the user types. A cartridge matches when the query, compared case-insensitively with runs of whitespace collapsed, is a substring of its `name` or of any of its `alternativeNames`.

#### Scenario: Alternative name match
- **WHEN** the user types `7,62 x 51` into Search
- **THEN** `308 Win.` is listed (its alternative names include `7,62 x 51`)

#### Scenario: Empty query
- **WHEN** the Search field is empty
- **THEN** no name filter is applied

### Requirement: Family filter
A select labelled "Family" SHALL offer the options All, rimless, rimmed, belted, pistol and rimfire. Selecting a family SHALL list only cartridges whose `family` equals it; All SHALL apply no family filter. The family filter and the search SHALL combine (both must match).

#### Scenario: Family and search combined
- **WHEN** Family is set to `rimless` and Search is `308`
- **THEN** only `308 Win.` is listed, and no rimmed, belted, pistol or rimfire cartridge is listed

#### Scenario: Family counts
- **WHEN** Family is set to each of rimless, rimmed, belted, pistol and rimfire in turn (no search)
- **THEN** the counts are 12, 2, 2, 6 and 3 respectively

### Requirement: Result count
The page SHALL show the text `<n> cartridges`, where `<n>` is the number of cartridges currently listed, and SHALL update with every filter change.

#### Scenario: Count follows filter
- **WHEN** Family is set to `rimfire`
- **THEN** the count text reads `3 cartridges`

### Requirement: Bookmarkable detail addresses
Each cartridge SHALL have its own address in the form of a URL fragment derived from the record's `key`. Loading that address directly, reloading the page while on it, or navigating with the browser back button SHALL show that cartridge's detail view. The start page SHALL be shown for the root address.

#### Scenario: Reload keeps the detail view
- **WHEN** the user opens the detail view of `223 Rem.` and reloads the page
- **THEN** the detail view of `223 Rem.` is shown again

#### Scenario: Unknown address
- **WHEN** the address names no existing cartridge
- **THEN** the start page is shown
