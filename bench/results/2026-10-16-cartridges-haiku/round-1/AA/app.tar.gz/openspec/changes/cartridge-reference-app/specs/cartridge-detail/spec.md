## ADDED Requirements

### Requirement: Detail view header and metadata
The detail view SHALL show, in order: a heading with the cartridge's `name`; its alternative names (when any); its family, category, primer type (`primerType`), C.I.P. table (`tab`), country, published date and revised date (shown as published, for example `1984-06-14`), pressure method; and the published water capacity (`grH2O`, shown as `30.5 gr H2O`) with its source (`publishedCapacity.source`) as a link to `publishedCapacity.url`, plus `publishedCapacity.note` when present.

#### Scenario: Water capacity with source link
- **WHEN** the detail view of `223 Rem.` is shown
- **THEN** it shows `30.5 gr H2O` with a link labelled with the source `kwk` whose target is `http://kwk.us/cases.html`

#### Scenario: No published capacity
- **WHEN** a record has no `publishedCapacity`
- **THEN** the water capacity row is omitted

### Requirement: Value tables grouped by section
All cartridge values (`cartridge.*`) and all chamber values (`chamber.*`) SHALL be shown in tables grouped by section (for example Case head, Collar, Junction cone, Lengths, Misc, Powder chamber, Pressures, Projectile; Barrel, Breech, Collar, Grooves, Junction cone, Lengths, Powder chamber, Rifling). Each table SHALL have the column headings "Symbol", "Value" and "Unit".

#### Scenario: Section tables
- **WHEN** the detail view of `308 Win.` is shown
- **THEN** a cartridge section table lists `E`, `E1`, `R`, `R1`, `beta` and the other published values of `cartridge.caseHead`, with columns Symbol, Value and Unit

### Requirement: Symbols and units
The Symbol column SHALL show the field name, except: `eMin` as "e min", `r1Min` as "r1 min", `r1Max` as "r1 max", `alpha` as "α", `alpha1` as "α1", `beta` as "β", `delta` as "δ", `deltaL` as "delta L", `L3PlusG` as "L3 + G". The Unit column SHALL show `mm` for lengths and diameters, `mm²` for `Q`, `bar` for `Pmax`, `PK` and `PE`, `J` for `EE`, `g` for `M`, and SHALL be empty for angles and for counts (`N`).

#### Scenario: Symbol substitution
- **WHEN** a junction cone with `r1Min` is shown
- **THEN** the Symbol cell reads `r1 min`

### Requirement: Value formatting
Values SHALL be shown as published: decimal point, no thousands separator, no added precision (`51.18 mm`, `4150 bar`). A tolerance field `<X>Tol` SHALL be shown in the Value cell of `X` after the value, separated by a space (for example `39.62 -0.2`), and SHALL NOT appear as a row of its own. Angles given as a number of degrees SHALL be shown as `40°`; angles given as `{degrees, minutes, seconds}` SHALL be shown as `39°59'49"` with minutes and seconds in two digits.

#### Scenario: Tolerance next to value
- **WHEN** `L1` is 39.62 with `L1Tol` -0.2
- **THEN** the Value cell reads `39.62 -0.2` and there is no row for `L1Tol`

#### Scenario: Angle object
- **WHEN** `delta` is `{degrees: 36, minutes: 52, seconds: 12}`
- **THEN** the Value cell reads `36°52'12"`

### Requirement: Print
A "Print" button SHALL open the browser's print dialog. The printed detail view SHALL be one A4 portrait page, black on white, containing the page header with the name, the drawing at full width with every label legible, and the tables, with no navigation, search, filter or buttons. The page footer SHALL state the source: "C.I.P. TDCC" with the revised date.

#### Scenario: Print output
- **WHEN** the detail view of `223 Rem.` is printed
- **THEN** the output is one A4 portrait page and contains no buttons, links to other views, search field or filter

### Requirement: Navigation back to list
The detail view SHALL have a link labelled "All cartridges" that returns to the start page.

#### Scenario: Back link
- **WHEN** the user activates "All cartridges" on a detail view
- **THEN** the start page is shown
