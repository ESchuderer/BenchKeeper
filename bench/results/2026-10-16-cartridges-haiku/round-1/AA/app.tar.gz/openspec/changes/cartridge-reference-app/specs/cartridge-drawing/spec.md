## ADDED Requirements

### Requirement: Inline SVG computed from the record
Each detail view SHALL contain an inline SVG drawing computed from the record's values. The SVG SHALL be true to scale: one user unit equals one millimetre, the axis is horizontal, and the head is on the left. Its accessible name SHALL be `<name> drawing`.

#### Scenario: Accessible name
- **WHEN** the detail view of `9 mm Luger` is shown
- **THEN** the drawing has the accessible name `9 mm Luger drawing`

### Requirement: Outside view and section
The upper half of the drawing SHALL be the outside view (the outer profile, including the exposed bullet and hiding the seated part). The lower half SHALL be a section with the cut walls (case, solid head, bullet) hatched. A dash-dot centre line SHALL run along the axis.

#### Scenario: Seated bullet
- **WHEN** a cartridge is drawn
- **THEN** the seated part of the bullet is visible only in the section half

### Requirement: Profile geometry
The outer profile SHALL be built from the rules of the brief: rim type (belted, rimfire, rimmed, rebated, rimless), head face and chamfer, rim edge (half-round for rimfire), extractor groove (straight ramp, or belt ramp at angle δ for belted cases), body (tapered to the shoulder, or straight for cases without alpha, L1 or L2), shoulder with fillets at r1 min and r2 where published, neck, and mouth face.

#### Scenario: Straight case
- **WHEN** a record has no `alpha`, `L1` or `L2`
- **THEN** the body runs straight to the mouth without a shoulder

### Requirement: Bullet
The bullet SHALL be drawn from the mouth to its tip at `L6`, with shank diameter `G1`, the seating depth and cylinder and nose proportions of the brief for the record's `annotations.defaultBulletShape` and category, and the nose shape for pointy (tangent ogive with a meplat), rounded (quarter ellipse), flat (cone) and semi_wadcutter (cone). Heeled cases (`H2 - G1 <= 0.015`) SHALL show the exposed bullet with the case outside diameter and the seated heel with the case inside diameter `H2 - 2·tb`.

#### Scenario: Heeled rimfire
- **WHEN** `22 Long Rifle` is drawn
- **THEN** the exposed bullet has diameter `H2` and the seated heel is inside the case

### Requirement: Section walls
Neck wall thickness SHALL be `tn = (H2 - G1)/2` and body wall thickness SHALL be `tb = min(max(1.3·tn, 0.6), 0.35·P1/2)`. The inner wall SHALL follow the outer profile at these thicknesses (tb along the body, tn along the neck, linearly blended across the shoulder). The solid head SHALL extend from the head face to `w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb with an extractor groove, belt ramp end + tb on belted cases)`. Centrefire primer pockets SHALL be cut into the head face with the diameter and depth of the brief; rimfire cases have no pocket.

#### Scenario: Primer pocket
- **WHEN** the primer type is `lr`
- **THEN** the pocket is 5.33 mm in diameter and 3.04 mm deep

### Requirement: Missing values are reported, never invented
If a value needed by a feature is missing, the feature SHALL be omitted from the drawing and the drawing SHALL state which value is missing. No number SHALL be substituted for a missing published value.

#### Scenario: Missing fillet radius
- **WHEN** `r1Min` is not published for a cartridge with a shoulder
- **THEN** the body-side shoulder corner is drawn sharp and the note names `r1 min`

### Requirement: Dimension lines and labels
The drawing SHALL include dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α where published. Each SHALL be labelled with its symbol and value (for example `L3 51.18`, `R 1.14`). Labels SHALL NOT overlap each other or the outline. A label MAY cross an extension line of a longer dimension only where the gap between dimensions is narrower than the label; the drawing SHALL place such a label beyond its own extension line.

#### Scenario: Label clearance
- **WHEN** any cartridge is drawn
- **THEN** no two labels overlap, and no label overlaps the drawn outline

### Requirement: Title block
The drawing SHALL include a title block with the cartridge name, the C.I.P. table (`tab`), the revision date, the text "Dimensions in mm", and the scale.

#### Scenario: Title block content
- **WHEN** `308 Win.` is drawn
- **THEN** the title block shows `308 Win.`, table `I`, the revised date `2008-09-23`, and `Dimensions in mm`

### Requirement: Scaling and print legibility
The drawing SHALL scale to the width of a phone screen and SHALL print legibly at the full width of an A4 portrait page.

#### Scenario: Phone width
- **WHEN** the detail view is displayed at 360 px viewport width
- **THEN** the drawing fits the width without horizontal scrolling
