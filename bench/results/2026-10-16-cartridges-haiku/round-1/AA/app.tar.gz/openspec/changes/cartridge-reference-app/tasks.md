# Tasks

## 1. Project setup and data

- [x] 1.1 Create `package.json` with `"test": "node --test tests/"` and dev dependencies only; verify `npm test` runs with zero test files and exits 0.
- [x] 1.2 Write `data/cartridges.jsonl` with the 25 records exactly as supplied (JSON, one per line); verify `wc -l` is 25 and every line parses as JSON.
- [x] 1.3 Write `scripts/build-data.js` that generates `cartridges-data.js` (`window.CIP_CARTRIDGES = [...]`) from the JSONL and a UMD export; test (`tests/data.test.js`): the generated file's array equals the parsed JSONL, has 25 entries, and every `key` is unique.

## 2. Formatting and symbols (tests first)

- [x] 2.1 Test `tests/format.test.js`: value formatting (`51.18 mm`, `4150`), tolerance attachment (`39.62 -0.2`, no row for `*Tol`), angle formatting (`40°`, `39°59'49"`, minutes/seconds padded, `36°52'12"`), symbol map (all nine substitutions, plain names otherwise), unit map (mm, mm², bar, J, g, empty for angles and N).
- [x] 2.2 Implement `app/format.js` to pass 2.1; verify with `npm test`.
- [x] 2.3 Test grouping: `tests/sections.test.js` builds section tables for `223 Rem.` and `308 Win.` with columns Symbol, Value, Unit, and no `*Tol` rows; implement `app/sections.js` to pass.

## 3. Geometry engine (tests first, one rule group at a time)

- [x] 3.1 Rim type tests (belted, rimfire, rimmed, rebated, rimless with the R1/P1 thresholds) and implement `rimType`.
- [x] 3.2 Head face and rim edge tests (chamfer points, square corner, rimfire half-round with `min(R/2, (R1-P1)/2)`) and implement.
- [x] 3.3 Extractor groove tests (straight ramp; belted ramp at angle δ up to R3/2, step to P1/2; no groove step) and implement.
- [x] 3.4 Body, shoulder and neck tests (straight case, bottleneck line to (P2/2, L1), shoulder through published points, α/2 check on 223 Rem., fillets r1 min and r2 with tangent lengths, neck to mouth) and implement.
- [x] 3.5 Bullet tests (seating depth `s` per shape and category, base `zb`, cylinder end `k`, meplat `m`, tangent-ogive radius for 223 Rem., quarter-ellipse for 22 Long Rifle, flat and SWC cones, heeled exposed/seated diameters) and implement.
- [x] 3.6 Section tests (`tn`, `tb`, inner wall blending, `w` value per rule including pocket depth and groove/belt terms, primer pocket diameter and depth for sp/lp/lr, no pocket for rimfire) and implement.
- [x] 3.7 Missing-value tests: 338 Lapua Mag. with no `r1Min` reports `r1 min` and draws a sharp corner; a record with alpha but no P2 reports the omission; no number is invented. Implement `notes`.

## 4. Drawing (tests first)

- [x] 4.1 SVG structure tests: `role="img"`, `aria-label="<name> drawing"`, true-scale coordinates (1 unit = 1 mm: a point at z=L3 maps to x = X0 + L3), upper half outside and lower half section, dash-dot centre line, hatch pattern for cut walls. Implement `app/drawing.js` base.
- [x] 4.2 Dimension item tests: every required dimension present where published (L3, L6, R1, R, P1 always; P2, H1, H2, G1, L1, L2, E1, α when published), each label text `<symbol> <value>`, arrowheads present. Implement dimension list.
- [x] 4.3 Layout tests over all 25 records: no two label boxes overlap, no label box intersects the outline segments or a dimension line, all labels inside the viewBox. Implement the placement search and tune until green.
- [x] 4.4 Title block tests: name, table, revision date, "Dimensions in mm", scale text. Implement.
- [x] 4.5 Notes tests: missing values appear as a text note in the drawing. Implement.

## 5. Catalogue and routing (tests first)

- [x] 5.1 Filter tests: search over name and alternative names (`7,62 x 51` finds `308 Win.`), whitespace and case handling, family filter values, combined filter, counts (rimless 12, rimmed 2, belted 2, pistol 6, rimfire 3, all 25). Implement `app/catalog.js`.
- [x] 5.2 Route tests: `#/cartridge/<key>` parsing, root and unknown key fall back to list. Implement `app/router.js`.

## 6. Pages, styles and print

- [x] 6.1 Write `index.html` and `app/app.js` rendering the start page (heading, Search, Family select with labels, count, list with name links) and detail view (heading, metadata, water capacity with link, drawing, tables, Print button, "All cartridges" link). Verify in the browser at the end of group 7.
- [x] 6.2 Write `styles.css`: dense typography with tabular numbers, `prefers-color-scheme` dark theme, responsive drawing width, and `@media print` (A4 portrait, black on white, navigation hidden, two-column tables, footer with "C.I.P. TDCC, revised <date>").

## 7. End-to-end verification

- [x] 7.1 Install a browser driver as a dev dependency and a Chromium build; write `tests/e2e/app.e2e.test.js` that opens `index.html` via `file://`: list has 25 links, search and family behave, detail view via hash, reload keeps detail, back link works, drawing has accessible name, no console errors, no network requests.
- [x] 7.2 E2E print check: emulate print media for `223 Rem.`, verify the document is one A4 page (PDF page count 1) and contains no buttons or navigation.
- [x] 7.3 E2E layout check: measure rendered label boxes with `getBBox` for all 25 drawings and assert no overlaps; take screenshots of three drawings (`223 Rem.`, `22 Long Rifle`, `338 Lapua Mag.`) at 360 px and A4 width and inspect them.
- [x] 7.4 Serve the folder with a static server and repeat 7.1 on `http://`.

## 8. Review and close-out

- [x] 8.1 Run the code-review skill over the change against the specs; fix the findings.
- [x] 8.2 Run `openspec validate cartridge-reference-app` and `openspec verify`; confirm all tasks are checked.

## Workflow follow-up

- Archive the change with `openspec archive cartridge-reference-app` once verification passes (not done in this session unless requested).
