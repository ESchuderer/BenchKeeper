'use strict';
// End-to-end checks in Chromium, opening index.html from disk (file://).
// Set CHROMIUM_PATH to use a specific Chromium binary; otherwise Playwright's own build is used.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require('playwright');

// APP_URL runs the same checks against a static server instead of file://.
const INDEX = process.env.APP_URL || pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;
const APP_ORIGIN = process.env.APP_URL ? new URL(process.env.APP_URL).origin : null;
const KEYS = [
  '223_rem', '243_win', '6_5_creedmoor', '6_5_x_55_se', '270_win', '7_x_64', '308_win', '30_06_spring',
  '8_x_57_is', '9_3_x_62', '7_62_x_39', '338_lapua_mag', '300_win_mag', '7_mm_rem_mag', '9_3_x_74_r',
  '7_x_65_r', '9_mm_luger', '45_auto', '40_s_w', '38_special', '357_magnum', '44_rem_mag',
  '22_long_rifle', '22_win_mag_r_f', '17_hmr',
];

let browser;
let context;

before(async () => {
  const opts = { headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] };
  if (process.env.CHROMIUM_PATH) {
    opts.executablePath = process.env.CHROMIUM_PATH;
    opts.args.push('--disable-gpu', '--no-zygote');
  }
  browser = await chromium.launch(opts);
});

after(async () => {
  if (browser) await browser.close();
});

async function newPage(options = {}) {
  context = await browser.newContext({ viewport: { width: 1100, height: 900 }, ...options });
  const page = await context.newPage();
  page.errors = [];
  page.requests = [];
  page.on('pageerror', (e) => page.errors.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error') page.errors.push(m.text()); });
  // Only requests that leave the app itself count as network use (file:// or the app's own origin are fine).
  page.on('request', (r) => {
    const u = r.url();
    if (u.startsWith('file:') || u.startsWith('data:') || (APP_ORIGIN && u.startsWith(APP_ORIGIN))) return;
    page.requests.push(u);
  });
  return page;
}

async function open(page, hash = '') {
  await page.goto(INDEX + hash);
  await page.waitForSelector('main#app h1');
}

test('start page: heading, 25 named links, count, no errors, no network', async () => {
  const page = await newPage();
  await open(page);
  assert.equal(await page.textContent('main h1'), 'Cartridges');
  assert.equal(await page.locator('#rows a').count(), 25);
  assert.equal(await page.textContent('#count'), '25 cartridges');
  const names = await page.$$eval('#rows a', (as) => as.map((a) => a.textContent));
  assert.ok(names.includes('6,5 Creedmoor') && names.includes('9 mm Luger'));
  assert.deepEqual(page.errors, []);
  assert.deepEqual(page.requests, []);
  await page.context().close();
});

test('search finds 308 Win. by its alternative name "7,62 x 51"', async () => {
  const page = await newPage();
  await open(page);
  await page.fill('#q', '7,62 x 51');
  assert.deepEqual(await page.$$eval('#rows a', (as) => as.map((a) => a.textContent)), ['308 Win.']);
  assert.equal(await page.textContent('#count'), '1 cartridge');
  await page.context().close();
});

test('family select filters and the count follows', async () => {
  const page = await newPage();
  await open(page);
  await page.selectOption('#fam', 'rimfire');
  assert.equal(await page.locator('#rows a').count(), 3);
  assert.equal(await page.textContent('#count'), '3 cartridges');
  await page.selectOption('#fam', 'all');
  assert.equal(await page.textContent('#count'), '25 cartridges');
  await page.context().close();
});

test('detail view opens from the link, survives reload, and returns with "All cartridges"', async () => {
  const page = await newPage();
  await open(page);
  await page.click('#rows a:text-is("223 Rem.")');
  await page.waitForSelector('article.page-detail');
  assert.equal(new URL(page.url()).hash, '#/cartridge/223_rem');
  assert.equal(await page.textContent('article h1'), '223 Rem.');
  await page.reload();
  await page.waitForSelector('article.page-detail');
  assert.equal(await page.textContent('article h1'), '223 Rem.');
  await page.click('a:text-is("All cartridges")');
  await page.waitForSelector('#rows');
  assert.equal(await page.textContent('main h1'), 'Cartridges');
  await page.context().close();
});

test('bookmarked address opens directly; unknown address shows the list', async () => {
  const page = await newPage();
  await open(page, '#/cartridge/338_lapua_mag');
  assert.equal(await page.textContent('article h1'), '338 Lapua Mag.');
  await open(page, '#/cartridge/does_not_exist');
  assert.equal(await page.textContent('main h1'), 'Cartridges');
  await page.context().close();
});

test('detail view shows metadata, water capacity link, grouped tables with Symbol/Value/Unit', async () => {
  const page = await newPage();
  await open(page, '#/cartridge/223_rem');
  const meta = await page.textContent('dl.meta');
  for (const s of ['rimless', 'Transducer', '2017-05-17', '1984-06-14', 'sr']) assert.ok(meta.includes(s), s);
  assert.ok(meta.includes('30.5 gr H2O'));
  const link = page.locator('dl.meta a[href="http://kwk.us/cases.html"]');
  assert.equal(await link.textContent(), 'kwk');
  const heads = await page.$$eval('table.values thead th', (ths) => ths.map((t) => t.textContent));
  assert.ok(heads.length > 0 && heads.every((h, i) => ['Symbol', 'Value', 'Unit'][i % 3] === h));
  const tol = await page.$$eval('table.values td.num', (tds) => tds.map((t) => t.textContent));
  assert.ok(tol.includes('36.52 -0.2'), 'tolerance next to value');
  assert.ok(!(await page.textContent('table.values')).includes('L1Tol'));
  assert.ok(tol.includes('3°10\'36"'), 'angle object');
  await page.context().close();
});

test('every drawing: accessible name, label boxes never overlap, labels stay clear of the outline', async () => {
  const page = await newPage();
  for (const key of KEYS) {
    await open(page, '#/cartridge/' + key);
    const result = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const name = svg.getAttribute('aria-label');
      const labels = [...svg.querySelectorAll('text.label')].map((t) => {
        const b = t.getBBox();
        return { text: t.textContent, x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height };
      });
      const overlaps = [];
      labels.forEach((a, i) => labels.forEach((b, j) => {
        if (j > i && a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1) overlaps.push(a.text + ' / ' + b.text);
      }));
      // Sample the outline paths and see whether any point falls inside a label box.
      const hits = [];
      svg.querySelectorAll('path.outline').forEach((p) => {
        const len = p.getTotalLength();
        for (let s = 0; s <= len; s += 0.25) {
          const pt = p.getPointAtLength(s);
          for (const l of labels) {
            if (pt.x > l.x0 + 0.2 && pt.x < l.x1 - 0.2 && pt.y > l.y0 + 0.2 && pt.y < l.y1 - 0.2) hits.push(l.text);
          }
        }
      });
      // Title-block text must stay inside its box.
      const box = svg.querySelector('rect.titleblock').getBBox();
      const spill = [...svg.querySelectorAll('.tb-name, .tb-line, .tb-note')].filter((t) => {
        const b = t.getBBox();
        return b.x + b.width > box.x + box.width + 0.2;
      }).map((t) => t.textContent);
      return { name, labels: labels.length, overlaps, hits: [...new Set(hits)], spill };
    });
    assert.equal(result.name, (await page.textContent('article h1')) + ' drawing', key);
    assert.deepEqual(result.overlaps, [], key + ' label overlap');
    assert.deepEqual(result.hits, [], key + ' label on outline');
    assert.deepEqual(result.spill, [], key + ' title block text overflows');
  }
  await page.context().close();
});

test('print: every cartridge is one A4 portrait page with no buttons or navigation', async () => {
  const page = await newPage();
  for (const key of KEYS) {
    await open(page, '#/cartridge/' + key);
    await page.emulateMedia({ media: 'print' });
    const hidden = await page.evaluate(() => {
      const q = (s) => getComputedStyle(document.querySelector(s)).display;
      return { toolbar: q('nav.toolbar'), print: q('button#print'), footer: q('.print-footer') };
    });
    assert.equal(hidden.toolbar, 'none', key);
    assert.equal(hidden.print, 'none', key);
    assert.equal(hidden.footer, 'block', key);
    const pdf = await page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page(?!s)/g) || []).length;
    assert.equal(pages, 1, key + ' page count');
    await page.emulateMedia({ media: 'screen' });
  }
  await page.context().close();
});

test('print button calls window.print', async () => {
  const page = await newPage();
  await open(page, '#/cartridge/223_rem');
  await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.click('button#print');
  assert.equal(await page.evaluate(() => window.__printed), 1);
  await page.context().close();
});

test('dark scheme follows the system setting on screen', async () => {
  const light = await newPage({ colorScheme: 'light' });
  await open(light, '#/cartridge/223_rem');
  const lightBg = await light.evaluate(() => getComputedStyle(document.body).backgroundColor);
  await light.context().close();
  const dark = await newPage({ colorScheme: 'dark' });
  await open(dark, '#/cartridge/223_rem');
  const darkBg = await dark.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.notEqual(lightBg, darkBg);
  await dark.context().close();
});

test('phone width: the drawing fits 360 px without horizontal scrolling', async () => {
  const page = await newPage({ viewport: { width: 360, height: 780 }, isMobile: true });
  await open(page, '#/cartridge/338_lapua_mag');
  const fits = await page.evaluate(() => {
    const svg = document.querySelector('svg.drawing').getBoundingClientRect();
    return { svgRight: svg.right, vw: document.documentElement.clientWidth, sw: document.documentElement.scrollWidth };
  });
  assert.ok(fits.svgRight <= fits.vw + 1, 'svg inside viewport');
  assert.ok(fits.sw <= fits.vw + 1, 'no horizontal scroll');
  await page.context().close();
});
