'use strict';
// Loads the browser scripts into a fresh vm context, exactly as index.html would
// (classic scripts sharing one global). The app code is not modified for tests.

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..', '..');

const SCRIPTS = [
  'app/cartridges-data.js',
  'app/format.js',
  'app/sections.js',
  'app/geometry.js',
  'app/drawing.js',
  'app/catalog.js',
  'app/router.js',
];

function loadApp(files = SCRIPTS) {
  const ctx = vm.createContext({ console });
  ctx.window = ctx;
  ctx.globalThis = ctx;
  for (const rel of files) {
    const file = path.join(ROOT, rel);
    if (!fs.existsSync(file)) continue;
    vm.runInContext(fs.readFileSync(file, 'utf8'), ctx, { filename: rel });
  }
  return ctx;
}

function record(ctx, key) {
  const found = ctx.CIP_CARTRIDGES.find((r) => r.key === key);
  if (!found) throw new Error('no record ' + key);
  return found;
}

module.exports = { loadApp, record, ROOT };

// Wraps a module's functions so their results are plain Node-realm data (for deepStrictEqual).
function plainApi(api) {
  const out = {};
  for (const k of Object.keys(api)) {
    out[k] = typeof api[k] === 'function'
      ? (...args) => JSON.parse(JSON.stringify(api[k](...args)))
      : api[k];
  }
  return out;
}
module.exports.plainApi = plainApi;
