'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadApp } = require('../helpers/load-app');

const app = loadApp(['app/cartridges-data.js', 'app/format.js', 'app/catalog.js']);
const { plainApi } = require('../helpers/load-app');
const C = plainApi(app.CIP.catalog);
const all = app.CIP_CARTRIDGES;
const names = (list) => list.map((r) => r.name);

test('no filter lists all 25 cartridges and the count reads "25 cartridges"', () => {
  assert.equal(C.filter(all, { query: '', family: 'all' }).length, 25);
  assert.equal(C.countText(25), '25 cartridges');
  assert.equal(C.countText(1), '1 cartridge');
});

test('search matches the name case-insensitively', () => {
  assert.deepEqual(names(C.filter(all, { query: 'CREEDMOOR', family: 'all' })), ['6,5 Creedmoor']);
});

test('search matches alternative names: "7,62 x 51" finds 308 Win.', () => {
  assert.deepEqual(names(C.filter(all, { query: '7,62 x 51', family: 'all' })), ['308 Win.']);
});

test('search collapses runs of whitespace in the query', () => {
  assert.deepEqual(names(C.filter(all, { query: '7,62   x  51', family: 'all' })), ['308 Win.']);
});

test('search also matches the 9 mm alternative "9 x 19 (mm)"', () => {
  assert.deepEqual(names(C.filter(all, { query: '9 x 19', family: 'all' })), ['9 mm Luger']);
});

test('family filter lists only that family', () => {
  assert.deepEqual(names(C.filter(all, { query: '', family: 'rimfire' })),
    ['22 Long Rifle', '22 Win. Mag. R.F.', '17 HMR']);
});

test('family counts match the brief', () => {
  const counts = {};
  for (const f of ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire']) {
    counts[f] = C.filter(all, { query: '', family: f }).length;
  }
  assert.deepEqual(counts, { rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 });
});

test('search and family combine: "308" within rimless only finds 308 Win.', () => {
  assert.deepEqual(names(C.filter(all, { query: '308', family: 'rimless' })), ['308 Win.']);
  assert.deepEqual(names(C.filter(all, { query: '308', family: 'pistol' })), []);
});

test('count text follows the filtered list', () => {
  assert.equal(C.countText(C.filter(all, { query: '', family: 'rimfire' }).length), '3 cartridges');
});

test('start-page entries: name, family and L3 with tolerance', () => {
  const e = C.entries(all);
  const creedmoor = e.find((x) => x.name === '6,5 Creedmoor');
  assert.equal(creedmoor.family, 'rimless');
  assert.equal(creedmoor.L3Text, '48.77 mm');
  const nine = e.find((x) => x.name === '9 mm Luger');
  assert.equal(nine.L3Text, '19.15 -0.25 mm');
  assert.equal(nine.href, '#/cartridge/9_mm_luger');
});
