'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { loadApp, ROOT } = require('../helpers/load-app');
const { readRecords, render, target } = require('../../scripts/build-data.js');

const jsonl = readRecords(fs.readFileSync(path.join(ROOT, 'data', 'cartridges.jsonl'), 'utf8'));

test('the JSONL source holds exactly the 25 supplied records', () => {
  assert.equal(jsonl.length, 25);
  const keys = new Set(jsonl.map((r) => r.key));
  assert.equal(keys.size, 25);
});

test('the generated browser data equals the JSONL source, record for record', () => {
  const ctx = loadApp(['app/cartridges-data.js']);
  assert.deepEqual(JSON.parse(JSON.stringify(ctx.CIP_CARTRIDGES)), jsonl);
});

test('family counts match the brief (rimless 12, rimmed 2, belted 2, pistol 6, rimfire 3)', () => {
  const counts = {};
  for (const r of jsonl) counts[r.family] = (counts[r.family] || 0) + 1;
  assert.deepEqual(counts, { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3 });
});

test('generated file is up to date with the source (no drift); the test does not rewrite it', () => {
  assert.equal(fs.readFileSync(target, 'utf8'), render(jsonl));
});
