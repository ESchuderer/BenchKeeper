'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadApp, record } = require('../helpers/load-app');

const app = loadApp([
  'app/cartridges-data.js',
  'app/format.js',
  'app/geometry.js',
  'app/drawing.js',
]);
const D = app.CIP.drawing;
const plain = (x) => JSON.parse(JSON.stringify(x));
const scene = (key) => plain(D.scene(record(app, key)));

function segHitsBox(s, b) {
  // Liang-Barsky clip against the open box; a touching segment does not count.
  let t0 = 0;
  let t1 = 1;
  const dx = s.x2 - s.x1;
  const dy = s.y2 - s.y1;
  const p = [-dx, dx, -dy, dy];
  const q = [s.x1 - b.x0, b.x1 - s.x1, s.y1 - b.y0, b.y1 - s.y1];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) {
      if (q[i] <= 0) return false;
    } else {
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
      else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
  }
  return t1 - t0 > 1e-9;
}

function boxesOverlap(a, b) {
  return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
}

function boxInside(a, v) {
  return a.x0 >= v.x && a.y0 >= v.y && a.x1 <= v.x + v.w && a.y1 <= v.y + v.h;
}

function polylineSegments(poly) {
  const out = [];
  for (let i = 0; i + 1 < poly.length; i++) {
    out.push({ x1: poly[i].x, y1: poly[i].y, x2: poly[i + 1].x, y2: poly[i + 1].y });
  }
  return out;
}

test('every record draws', () => {
  for (const r of app.CIP_CARTRIDGES) {
    const s = plain(D.scene(r));
    assert.equal(s.drawable, true, r.key);
  }
});

test('labels never overlap each other, a dimension line, or the outline (all 25 records)', () => {
  for (const r of app.CIP_CARTRIDGES) {
    const s = plain(D.scene(r));
    // Dimension and arrow lines are checked; extension lines of longer dimensions may pass a
    // narrow gap (the brief forbids overlaps of labels with each other and the outline only).
    const segs = s.lines.filter((l) => l.cls !== 'ext').concat(...s.outline.map(polylineSegments));
    s.labels.forEach((a, i) => {
      s.labels.forEach((b, j) => {
        if (j > i) assert.equal(boxesOverlap(a.box, b.box), false, r.key + ': "' + a.text + '" overlaps "' + b.text + '"');
      });
      for (const seg of segs) {
        assert.equal(segHitsBox(seg, a.box), false, r.key + ': "' + a.text + '" crosses a line');
      }
    });
  }
});

test('all labels and the title block lie inside the viewBox', () => {
  for (const r of app.CIP_CARTRIDGES) {
    const s = plain(D.scene(r));
    for (const l of s.labels) assert.ok(boxInside(l.box, s.viewBox), r.key + ': ' + l.text);
  }
});

test('223 Rem. carries every required dimension with symbol and value', () => {
  const texts = scene('223_rem').labels.map((l) => l.text);
  for (const t of [
    'L3 44.7', 'L6 57.4', 'R1 9.6', 'R 1.14', 'P1 9.58', 'P2 9 -0.2', 'H1 6.43', 'H2 6.43',
    'G1 5.7', 'L1 36.52 -0.2', 'L2 39.55 -0.2', 'E1 8.43', 'α 46°',
  ]) {
    assert.ok(texts.includes(t), 'missing label ' + t + ' in ' + texts.join(' | '));
  }
});

test('22 Long Rifle omits dimensions that are not published', () => {
  const texts = scene('22_long_rifle').labels.map((l) => l.text);
  for (const prefix of ['E1 ', 'α ', 'P2 ', 'H1 ', 'L1 ', 'L2 ']) {
    assert.ok(!texts.some((t) => t.startsWith(prefix)), 'unexpected ' + prefix);
  }
  for (const prefix of ['R1 ', 'R ', 'P1 ', 'L3 ', 'L6 ', 'G1 ', 'H2 ']) {
    assert.ok(texts.some((t) => t.startsWith(prefix)), 'missing ' + prefix);
  }
});

test('the scene is true to scale: outline points keep the mm values of the record', () => {
  const s = scene('223_rem');
  const mouth = s.outline[0].find((p) => Math.abs(p.x - 44.7) < 1e-9);
  assert.ok(mouth, 'a point at x = L3 exists');
  const tip = s.outline[0][s.outline[0].length - 1];
  assert.ok(Math.abs(tip.x - 57.4) < 1e-9, 'tip at x = L6');
});

test('title block holds name, C.I.P. table, revision date, "Dimensions in mm" and the scale', () => {
  const tb = scene('308_win').titleBlock.lines.join(' | ');
  assert.ok(tb.includes('308 Win.'));
  assert.ok(tb.includes('table I'), 'C.I.P. table');
  assert.ok(tb.includes('2008-09-23'));
  assert.ok(tb.includes('Dimensions in mm'));
  assert.ok(tb.includes('Scale 1:1'));
});

test('missing values are named in the drawing notes (338 Lapua Mag. has no r1 min)', () => {
  const s = scene('338_lapua_mag');
  assert.ok(s.notes.some((n) => n.includes('r1 min')));
});

test('SVG markup: img role, accessible name, viewBox, dash-dot centre line, hatch, arrowheads', () => {
  const svg = D.toSvg(record(app, '223_rem'));
  assert.ok(svg.startsWith('<svg'), 'starts with svg');
  assert.ok(svg.includes('role="img"'));
  assert.ok(svg.includes('aria-label="223 Rem. drawing"'));
  assert.ok(/viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/.test(svg), 'viewBox');
  assert.ok(svg.includes('class="centre"') && svg.includes('stroke-dasharray'), 'centre line');
  assert.ok(svg.includes('<pattern'), 'hatch pattern');
  assert.ok(svg.includes('class="arrow"'), 'arrowheads');
  assert.ok(svg.includes('L3 44.7'), 'label text in markup');
});

test('the drawing for each record has a unique hatch id (safe for several drawings)', () => {
  const a = D.toSvg(record(app, '223_rem'));
  const b = D.toSvg(record(app, '308_win'));
  assert.notEqual(a.match(/id="([^"]+)"/)[1], b.match(/id="([^"]+)"/)[1]);
});
