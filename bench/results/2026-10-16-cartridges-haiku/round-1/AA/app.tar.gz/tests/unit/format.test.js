'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadApp } = require('../helpers/load-app');

const app = loadApp(['app/format.js']);
const F = app.CIP.format;

test('numbers are shown as published, with a decimal point and no separators', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(4150.0), '4150');
  assert.equal(F.formatNumber(0.1), '0.1');
  assert.equal(F.formatNumber(-0.2), '-0.2');
  assert.equal(F.formatNumber(0), '0');
});

test('a value with a tolerance shows the tolerance next to it', () => {
  assert.equal(F.formatQuantity(39.62, -0.2), '39.62 -0.2');
  assert.equal(F.formatQuantity(9.0, -0.2), '9 -0.2');
  assert.equal(F.formatQuantity(51.18, undefined), '51.18');
});

test('an angle given as degrees is shown with a degree sign', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(35.0), '35°');
  assert.equal(F.formatAngle(0), '0°');
});

test('an angle given as degrees, minutes and seconds is shown as d°mm\'ss"', () => {
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 36, minutes: 52, seconds: 12 }), '36°52\'12"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(F.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(F.formatAngle({ degrees: 10, minutes: 58, seconds: 0 }), '10°58\'00"');
});

test('symbols are the field names, except for the nine published substitutions', () => {
  assert.equal(F.symbolFor('eMin'), 'e min');
  assert.equal(F.symbolFor('r1Min'), 'r1 min');
  assert.equal(F.symbolFor('r1Max'), 'r1 max');
  assert.equal(F.symbolFor('alpha'), 'α');
  assert.equal(F.symbolFor('alpha1'), 'α1');
  assert.equal(F.symbolFor('beta'), 'β');
  assert.equal(F.symbolFor('delta'), 'δ');
  assert.equal(F.symbolFor('deltaL'), 'delta L');
  assert.equal(F.symbolFor('L3PlusG'), 'L3 + G');
  assert.equal(F.symbolFor('R1'), 'R1');
  assert.equal(F.symbolFor('Pmax'), 'Pmax');
  assert.equal(F.symbolFor('G1'), 'G1');
});

test('units: lengths and diameters mm, Q mm², pressures bar, EE J, M g', () => {
  assert.equal(F.unitFor('L3'), 'mm');
  assert.equal(F.unitFor('P1'), 'mm');
  assert.equal(F.unitFor('G1'), 'mm');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
});

test('angles and the count N have no unit', () => {
  for (const name of ['alpha', 'alpha1', 'beta', 'delta', 'i', 'N']) {
    assert.equal(F.unitFor(name), '', name);
  }
  assert.equal(F.isAngle('alpha'), true);
  assert.equal(F.isAngle('L1'), false);
  assert.equal(F.isCount('N'), true);
});
