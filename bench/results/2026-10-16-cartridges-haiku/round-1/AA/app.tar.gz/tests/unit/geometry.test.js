'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadApp, record } = require('../helpers/load-app');

const app = loadApp(['app/cartridges-data.js', 'app/geometry.js']);
const G = app.CIP.geometry;
const plain = (x) => JSON.parse(JSON.stringify(x));
const build = (key) => plain(G.build(record(app, key)));

const close = (actual, expected, eps = 1e-6, msg) =>
  assert.ok(Math.abs(actual - expected) <= eps, (msg || '') + ' expected ' + expected + ' got ' + actual);

// Finds the first outer-profile point with the given z and r (within eps).
function hasPoint(points, z, r, eps = 1e-6) {
  return points.some((p) => Math.abs(p.z - z) <= eps && Math.abs(p.r - r) <= eps);
}

// ---------- 1. Rim type ----------
test('rim type: belted and rimfire come from the family', () => {
  assert.equal(build('300_win_mag').rimType, 'belted');
  assert.equal(build('22_long_rifle').rimType, 'rimfire');
});

test('rim type: R1/P1 >= 1.05 is rimmed, < 0.98 rebated, otherwise rimless', () => {
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 10.5 }, powderChamber: { P1: 10.0 } } }), 'rimmed');
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 9.7 }, powderChamber: { P1: 10.0 } } }), 'rebated');
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 9.8 }, powderChamber: { P1: 10.0 } } }), 'rimless');
});

test('rim type from real records: 223 Rem. rimless, 9,3 x 74 R rimmed, 357 Magnum rimmed by the ratio rule', () => {
  assert.equal(build('223_rem').rimType, 'rimless');
  assert.equal(build('9_3_x_74_r').rimType, 'rimmed');
  assert.equal(build('357_magnum').rimType, 'rimmed');
});

// ---------- 2. Head face and rim edge ----------
test('223 Rem. head: chamfer from (R1/2 - f·tanβ, 0) to (R1/2, f), then up to R', () => {
  const g = build('223_rem');
  const x = 0.45 * Math.tan(35 * Math.PI / 180); // 0.31509
  close(x, 0.315093, 1e-5);
  assert.ok(hasPoint(g.outer, 0, 4.8 - x, 1e-5), 'chamfer start');
  assert.ok(hasPoint(g.outer, 0.45, 4.8), 'chamfer end');
  assert.ok(hasPoint(g.outer, 1.14, 4.8), 'rim top corner at z = R');
});

test('chamfer depth is capped at R1/4', () => {
  const rec = record(app, '223_rem');
  const capped = plain(G.build(Object.assign({}, rec, {
    cartridge: Object.assign({}, rec.cartridge, {
      caseHead: Object.assign({}, rec.cartridge.caseHead, { f: 5.0, beta: 80 }),
    }),
  })));
  // R1/4 = 2.4, and f tan(80) = 28, so the start is at R1/2 - 2.4 = 2.4
  assert.ok(hasPoint(capped.outer, 0, 4.8 - 2.4, 1e-6), 'capped chamfer start');
});

test('22 Long Rifle rimfire edge: half-round of radius min(R/2, (R1-P1)/2) bulging to R1/2', () => {
  const g = build('22_long_rifle');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2); // 0.545
  close(rho, 0.545, 1e-9);
  const centreR = 7.06 / 2 - rho; // 2.985
  const bulge = g.outer.filter((p) => p.z > 0 && p.z < 2 * rho);
  assert.ok(bulge.length >= 5, 'arc is sampled');
  const maxR = Math.max(...bulge.map((p) => p.r));
  close(maxR, 7.06 / 2, 1e-6, 'outermost point at R1/2');
  assert.ok(hasPoint(g.outer, 0, centreR, 1e-6), 'arc starts on the head face at R1/2 - rho');
  for (const p of bulge) {
    const d = Math.hypot(p.r - centreR, p.z - rho);
    close(d, rho, 1e-6, 'arc point on the circle');
  }
});

// ---------- 3. Extractor groove ----------
test('223 Rem. groove: floor at E1/2 from R to R + eMin, then straight ramp to (P1/2, E)', () => {
  const g = build('223_rem');
  assert.ok(hasPoint(g.outer, 1.14, 4.215), 'in from rim to E1/2');
  assert.ok(hasPoint(g.outer, 1.14 + 0.76, 4.215), 'floor end');
  assert.ok(hasPoint(g.outer, 3.13, 4.79), 'ramp meets body at (P1/2, E)');
});

test('belted 300 Win. Mag. groove: ramp at δ to the axis up to R3/2, belt to E, step to P1/2', () => {
  const g = build('300_win_mag');
  const floorR = 12.07 / 2; // 6.035
  const beltR = 13.51 / 2; // 6.755
  const floorZ = 1.27 + 0.94; // R + eMin = 2.21
  const rampEnd = floorZ + (beltR - floorR) / Math.tan(35 * Math.PI / 180);
  close(rampEnd, 3.238267, 1e-5);
  assert.ok(hasPoint(g.outer, floorZ, floorR), 'floor end');
  assert.ok(hasPoint(g.outer, rampEnd, beltR, 1e-5), 'ramp reaches belt');
  assert.ok(hasPoint(g.outer, 5.59, beltR), 'belt followed to E');
  assert.ok(hasPoint(g.outer, 5.59, 13.03 / 2), 'step in to P1/2');
});

test('without E and E1 there is no groove: step from the rim to P1/2 at z = R', () => {
  const g = build('9_3_x_74_r');
  assert.ok(hasPoint(g.outer, 1.4, 13.35 / 2), 'rim top corner');
  assert.ok(hasPoint(g.outer, 1.4, 11.9 / 2), 'step to P1/2 at R');
  assert.equal(g.groove.present, false);
});

// ---------- 4. Body, shoulder, neck ----------
test('straight case (no alpha, L1 or L2): body runs from P1/2 to (H2/2, L3)', () => {
  const g = build('9_mm_luger');
  assert.equal(g.shoulder.present, false);
  const last = g.outer[g.outer.length - 1];
  close(last.z, 19.15, 1e-9);
  close(last.r, 9.65 / 2, 1e-9);
});

test('223 Rem. shoulder lies at α/2 to the axis between the published points', () => {
  const g = build('223_rem');
  const slope = (4.5 - 3.215) / (39.55 - 36.52); // dr/dz of the published points
  close(Math.atan(slope) * 180 / Math.PI, 23, 0.1, 'half angle of 46°');
  assert.equal(g.shoulder.alphaDeg, 46);
});

test('fillets: body-side corner uses r1 min, neck-side corner uses r2; each arc is tangent-length r·tan(φ/2)', () => {
  const g = build('223_rem');
  const r1 = g.shoulder.fillets.body;
  const r2 = g.shoulder.fillets.neck;
  assert.equal(r1.radius, 0.64);
  assert.equal(r2.radius, 2.54);
  // Deflection angles computed from the published points (body line, shoulder, neck).
  const ang = (dz, dr) => Math.atan2(dr, dz);
  const body = ang(36.52 - 3.13, 4.5 - 4.79);
  const shoulder = ang(39.55 - 36.52, 3.215 - 4.5);
  const neck = ang(44.7 - 39.55, 0);
  const phiBody = Math.abs(shoulder - body);
  const phiNeck = Math.abs(neck - shoulder);
  close(r1.tangent, 0.64 * Math.tan(phiBody / 2), 1e-6, 'body tangent');
  close(r2.tangent, 2.54 * Math.tan(phiNeck / 2), 1e-6, 'neck tangent');
  for (const f of [r1, r2]) {
    for (const p of f.points) {
      close(Math.hypot(p.z - f.centre.z, p.r - f.centre.r), f.radius, 1e-6, 'fillet point on circle');
    }
  }
});

test('missing r1 min: the body-side corner stays sharp and the note names r1 min', () => {
  const g = build('338_lapua_mag');
  assert.equal(g.shoulder.fillets.body, null);
  assert.ok(hasPoint(g.outer, 54.9, 13.82 / 2), 'sharp corner at (L1, P2/2)');
  assert.ok(g.notes.some((n) => /r1 min/.test(n.text)), 'note mentions r1 min');
});

// ---------- 5. Bullet ----------
test('223 Rem. bullet: pointy, s = G1, base at L3 - s, cylinder to zb + 0.40·Lb', () => {
  const b = build('223_rem').bullet;
  close(b.s, 5.7, 1e-9);
  close(b.zb, 39.0, 1e-9);
  close(b.Lb, 18.4, 1e-9);
  close(b.zs, 46.36, 1e-9);
  close(b.n, 11.04, 1e-9);
});

test('223 Rem. pointy meplat is max(0.08·G1, 1.27) and the ogive is tangent to the cylinder', () => {
  const b = build('223_rem').bullet;
  close(b.m, 1.27, 1e-9);
  const d = 5.7 / 2 - 1.27 / 2;
  const rho = (d * d + 11.04 * 11.04) / (2 * d);
  close(b.ogiveRadius, rho, 1e-6);
  const centre = { z: b.zs, r: 5.7 / 2 - rho };
  const tip = b.exposed[b.exposed.length - 1];
  close(tip.z, 57.4, 1e-9);
  close(tip.r, 1.27 / 2, 1e-9);
  const arc = b.exposed.filter((p) => p.z > b.zs + 1e-9 && p.z < 57.4 - 1e-9);
  for (const p of arc) close(Math.hypot(p.z - centre.z, p.r - centre.r), rho, 1e-6, 'nose point on ogive');
});

test('22 Long Rifle rounded rimfire bullet: s = 0.8·G1, k = 0.55, quarter ellipse with m = 0.15·G1', () => {
  const b = build('22_long_rifle').bullet;
  close(b.s, 0.8 * 5.72, 1e-9);
  close(b.zb, 15.57 - 0.8 * 5.72, 1e-9);
  close(b.zs, b.zb + 0.55 * b.Lb, 1e-9);
  close(b.m, 0.15 * 5.72, 1e-9);
  const a = 2.86 - b.m / 2;
  const bb = b.n;
  for (const p of b.exposed.filter((q) => q.z > b.zs + 1e-9 && q.z < 25.4 - 1e-9)) {
    close(Math.pow((p.r - b.m / 2) / a, 2) + Math.pow((p.z - b.zs) / bb, 2), 1, 1e-6, 'on quarter ellipse');
  }
});

test('pistol rounded bullet uses the pistol seating (0.4·G1) and cylinder (0.65) factors', () => {
  const b = build('9_mm_luger').bullet;
  close(b.s, 0.4 * 9.03, 1e-9);
  close(b.zs, b.zb + 0.65 * b.Lb, 1e-9);
  close(b.m, 0.15 * 9.03, 1e-9);
});

test('pistol flat bullet: s = 0.4·G1, k = 0.70, straight cone to m = 0.55·G1 (40 S&W)', () => {
  const b = build('40_s_w').bullet;
  close(b.s, 0.4 * 10.17, 1e-9);
  close(b.zs, b.zb + 0.7 * b.Lb, 1e-9);
  close(b.m, 0.55 * 10.17, 1e-9);
  assert.equal(b.nose.length, 2, 'straight cone has two points');
});

test('semi-wadcutter (357 Magnum): s = 0.6·G1, k = 0.78, cone to 0.6·G1', () => {
  const b = build('357_magnum').bullet;
  close(b.s, 0.6 * 9.12, 1e-9);
  close(b.zs, b.zb + 0.78 * b.Lb, 1e-9);
  close(b.m, 0.6 * 9.12, 1e-9);
});

test('heeled 22 Long Rifle: exposed bullet has the case outside diameter; the seated heel the inside diameter H2 - 2·tb', () => {
  const g = build('22_long_rifle');
  assert.equal(g.bullet.heeled, true);
  close(g.bullet.exposedRadius, 5.72 / 2, 1e-9);
  close(g.bullet.heelRadius, 5.72 / 2 - g.walls.tb, 1e-9);
  assert.ok(g.bullet.section.some((p) => Math.abs(p.r - g.bullet.heelRadius) < 1e-9), 'heel in section');
});

test('non-heeled bullets have no heel step', () => {
  assert.equal(build('223_rem').bullet.heeled, false);
});

// ---------- 6. Section walls and head ----------
test('223 Rem. walls: tn = (H2 - G1)/2 and tb = 0.6 (the minimum)', () => {
  const g = build('223_rem');
  close(g.walls.tn, 0.365, 1e-9);
  close(g.walls.tb, 0.6, 1e-9);
});

test('body wall: 1.3·tn when that exceeds 0.6; capped at 0.35·P1/2 for a narrow powder chamber', () => {
  // Synthetic variants of 223 Rem. (only the two values under test change).
  const rec = record(app, '223_rem');
  const variant = (collarH2, p1) => {
    const v = JSON.parse(JSON.stringify(rec));
    v.cartridge.collar.H2 = collarH2;
    v.cartridge.powderChamber.P1 = p1;
    return plain(G.build(v));
  };
  // H2 - G1 = 1.2 -> tn = 0.6 -> 1.3·tn = 0.78
  const grown = variant(5.7 + 1.2, 9.58);
  close(grown.walls.tn, 0.6, 1e-9);
  close(grown.walls.tb, 0.78, 1e-9);
  // P1 = 2.0 -> cap 0.35·1.0 = 0.35 beats the 0.6 minimum
  const capped = variant(6.43, 2.0);
  close(capped.walls.tb, 0.35, 1e-9);
});

test('no published record needs more than the 0.6 minimum for tb', () => {
  for (const r of app.CIP_CARTRIDGES) {
    const g = plain(G.build(r));
    close(g.walls.tb, 0.6, 1e-9, r.key);
  }
});

test('solid head: w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb with a groove) gives 4.54 for 223 Rem.', () => {
  const g = build('223_rem');
  close(g.w, 4.54, 1e-9);
});

test('belted solid head: the belt ramp end + tb term applies when it is the largest (synthetic)', () => {
  // Remove the primer type so the pocket term is absent; the belt term (3.238 + 0.6) then decides.
  const rec = JSON.parse(JSON.stringify(record(app, '300_win_mag')));
  rec.annotations.primerType = 'rimfire';
  const g = plain(G.build(rec));
  close(g.w, 3.238267 + 0.6, 1e-5);
});

test('300 Win. Mag. (lrm): pocket depth 3.3 + 1.5 = 4.8 beats the belt ramp term', () => {
  close(build('300_win_mag').w, 4.8, 1e-9);
});

test('primer pocket: sr 4.45 x 3.04; lr 5.33 x 3.3; rimfire none', () => {
  assert.deepEqual(plainPocket(build('223_rem')), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(plainPocket(build('308_win')), { diameter: 5.33, depth: 3.3 });
  assert.equal(build('22_long_rifle').pocket, null);
});

function plainPocket(g) {
  return { diameter: g.pocket.diameter, depth: g.pocket.depth };
}

test('section polygon is closed, starts and ends on the axis, and the pocket is excluded', () => {
  const g = build('223_rem');
  const poly = g.caseSection;
  assert.ok(poly.length > 10);
  assert.ok(poly.every((p) => p.r >= -1e-9), 'half plane r >= 0');
  // The pocket floor sits on the axis at z = depth
  assert.ok(hasPoint(poly, 3.04, 0, 1e-9));
  assert.ok(hasPoint(poly, 3.04, 4.45 / 2, 1e-9));
});

test('section inner mouth radius is G1/2 for a bottleneck case (H2/2 - tn)', () => {
  const g = build('223_rem');
  close(g.mouth.rInner, 5.7 / 2, 1e-6);
});

test('straight case inner mouth radius is H2/2 - tb (the heel fits inside it)', () => {
  const g = build('22_long_rifle');
  close(g.mouth.rInner, 5.72 / 2 - g.walls.tb, 1e-6);
});

// ---------- 7. Missing values ----------
test('a shoulder without P2 is reported and drawn straight', () => {
  const rec = record(app, '223_rem');
  const broken = JSON.parse(JSON.stringify(rec));
  delete broken.cartridge.powderChamber.P2;
  const g = plain(G.build(broken));
  assert.equal(g.shoulder.present, false);
  assert.ok(g.notes.some((n) => /P2/.test(n.text)), 'note names P2');
});

test('no number is invented: a missing eMin draws the floor with zero length and says so', () => {
  const rec = record(app, '223_rem');
  const broken = JSON.parse(JSON.stringify(rec));
  delete broken.cartridge.caseHead.eMin;
  const g = plain(G.build(broken));
  assert.ok(g.notes.some((n) => /e min/.test(n.text)));
  assert.ok(hasPoint(g.outer, 1.14, 4.215), 'no floor: groove starts at the rim');
});

// ---------- 8. Invariants over all 25 records ----------
test('every record builds finite geometry with the expected end points', () => {
  for (const r of app.CIP_CARTRIDGES) {
    const g = plain(G.build(r));
    const L3 = r.cartridge.lengths.L3;
    const L6 = r.cartridge.lengths.L6;
    assert.ok(g.outer.length >= 4, r.key);
    for (const p of g.outer) {
      assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r), r.key + ' finite');
      assert.ok(p.r >= 0, r.key + ' r >= 0');
    }
    for (let i = 1; i < g.outer.length; i++) {
      assert.ok(g.outer[i].z >= g.outer[i - 1].z - 1e-9, r.key + ' z is monotonic from head to mouth');
    }
    const mouth = g.outer[g.outer.length - 1];
    close(mouth.z, L3, 1e-9, r.key + ' mouth z');
    const tip = g.bullet.exposed[g.bullet.exposed.length - 1];
    close(tip.z, L6, 1e-9, r.key + ' tip z');
    assert.ok(g.bullet.section.every((p) => Number.isFinite(p.z) && Number.isFinite(p.r)), r.key + ' bullet finite');
    assert.ok(g.caseSection.every((p) => Number.isFinite(p.z) && Number.isFinite(p.r)), r.key + ' section finite');
  }
});

test('the 25 records draw without an exception and report notes as an array', () => {
  for (const r of app.CIP_CARTRIDGES) {
    const g = plain(G.build(r));
    assert.ok(Array.isArray(g.notes), r.key);
  }
});
