'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadApp } = require('../helpers/load-app');

const app = loadApp(['app/cartridges-data.js', 'app/router.js']);
const { plainApi } = require('../helpers/load-app');
const R = plainApi(app.CIP.router);

test('root and empty hashes show the list', () => {
  assert.deepEqual(R.parse(''), { view: 'list' });
  assert.deepEqual(R.parse('#/'), { view: 'list' });
  assert.deepEqual(R.parse('#'), { view: 'list' });
});

test('a cartridge address opens its detail view', () => {
  assert.deepEqual(R.parse('#/cartridge/223_rem'), { view: 'detail', key: '223_rem' });
});

test('an unknown key falls back to the list', () => {
  assert.deepEqual(R.resolve('#/cartridge/nope', app.CIP_CARTRIDGES), { view: 'list' });
});

test('a known key resolves to its record', () => {
  const r = R.resolve('#/cartridge/308_win', app.CIP_CARTRIDGES);
  assert.equal(r.view, 'detail');
  assert.equal(r.record.name, '308 Win.');
});

test('hrefFor builds the bookmarkable address', () => {
  assert.equal(R.hrefFor('22_long_rifle'), '#/cartridge/22_long_rifle');
});
