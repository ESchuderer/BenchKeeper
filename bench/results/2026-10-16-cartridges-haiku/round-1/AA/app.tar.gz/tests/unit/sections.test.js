'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadApp, record } = require('../helpers/load-app');

const app = loadApp(['app/cartridges-data.js', 'app/format.js', 'app/sections.js']);
// Results come from the vm realm; normalise them so deepStrictEqual compares plain data.
const plain = (x) => JSON.parse(JSON.stringify(x));
const S = { build: (r) => plain(app.CIP.sections.build(r)) };

function rowsOf(sections, title) {
  const s = sections.find((x) => x.title === title);
  assert.ok(s, 'missing section ' + title);
  return s.rows;
}

test('223 Rem. case head rows, in data order, with symbols and units', () => {
  const r = record(app, '223_rem');
  const groups = S.build(r);
  assert.deepEqual(groups.map((g) => g.title), ['Cartridge', 'Chamber']);
  const caseHead = rowsOf(groups[0].sections, 'Case head');
  assert.deepEqual(caseHead, [
    { symbol: 'E', value: '3.13', unit: 'mm' },
    { symbol: 'E1', value: '8.43', unit: 'mm' },
    { symbol: 'R', value: '1.14', unit: 'mm' },
    { symbol: 'R1', value: '9.6', unit: 'mm' },
    { symbol: 'β', value: '35°', unit: '' },
    { symbol: 'δ', value: '25°', unit: '' },
    { symbol: 'e min', value: '0.76', unit: 'mm' },
    { symbol: 'f', value: '0.45', unit: 'mm' },
  ]);
});

test('tolerances are attached to their value and never get a row of their own', () => {
  const groups = S.build(record(app, '223_rem'));
  const lengths = rowsOf(groups[0].sections, 'Lengths');
  assert.deepEqual(lengths, [
    { symbol: 'L1', value: '36.52 -0.2', unit: 'mm' },
    { symbol: 'L2', value: '39.55 -0.2', unit: 'mm' },
    { symbol: 'L3', value: '44.7', unit: 'mm' },
    { symbol: 'L6', value: '57.4', unit: 'mm' },
  ]);
  const everything = groups.flatMap((g) => g.sections.flatMap((s) => s.rows));
  assert.equal(everything.some((row) => /Tol$/.test(row.symbol)), false);
});

test('the chamber side uses the chamber values, including the angle object for i', () => {
  const groups = S.build(record(app, '223_rem'));
  const rifling = rowsOf(groups[1].sections, 'Rifling');
  assert.deepEqual(rifling, [
    { symbol: 'G', value: '2.18', unit: 'mm' },
    { symbol: 'G1', value: '5.69', unit: 'mm' },
    { symbol: 'α1', value: '90°', unit: '' },
    { symbol: 'h', value: '0.38', unit: 'mm' },
    { symbol: 'i', value: '3°10\'36"', unit: '' },
    { symbol: 's', value: '1.01', unit: 'mm' },
  ]);
});

test('308 Win. shows E with its tolerance and the pressure units', () => {
  const groups = S.build(record(app, '308_win'));
  const caseHead = rowsOf(groups[0].sections, 'Case head');
  assert.equal(caseHead[0].symbol, 'E');
  assert.equal(caseHead[0].value, '3.85');
  const pressures = rowsOf(groups[0].sections, 'Pressures');
  assert.deepEqual(pressures, [
    { symbol: 'EE', value: '3920', unit: 'J' },
    { symbol: 'M', value: '25', unit: 'g' },
    { symbol: 'PE', value: '5190', unit: 'bar' },
    { symbol: 'PK', value: '4773', unit: 'bar' },
    { symbol: 'Pmax', value: '4150', unit: 'bar' },
  ]);
});

test('300 Win. Mag. shows the belt and the groove tolerance', () => {
  const groups = S.build(record(app, '300_win_mag'));
  const caseHead = rowsOf(groups[0].sections, 'Case head');
  const e = caseHead.find((row) => row.symbol === 'E');
  assert.equal(e.value, '5.59 -0.2');
  assert.ok(caseHead.some((row) => row.symbol === 'R3' && row.value === '13.51'));
});

test('section titles are readable words, not camel case keys', () => {
  const groups = S.build(record(app, '223_rem'));
  const titles = groups[0].sections.map((s) => s.title);
  assert.deepEqual(titles, [
    'Case head', 'Collar', 'Junction cone', 'Lengths', 'Misc', 'Powder chamber', 'Pressures', 'Projectile',
  ]);
});
