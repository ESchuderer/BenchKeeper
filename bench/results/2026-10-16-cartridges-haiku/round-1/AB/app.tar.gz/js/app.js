// Application views and hash routing: the start page (#/) and one detail view per cartridge (#/cartridge/<key>).
(function (root) {
  'use strict';

  var CIP = root.CIP;
  var records = CIP.records;
  var format = CIP.format;
  var catalogue = CIP.catalogue;
  var drawing = CIP.drawing;

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function findRecord(key) {
    for (var i = 0; i < records.length; i++) {
      if (records[i].key === key) {
        return records[i];
      }
    }
    return null;
  }

  function appRoot() {
    return document.getElementById('app');
  }

  function setTitle(text) {
    document.title = text;
  }

  // Start page: heading, search and family filter, count and the list.
  function renderCatalogue() {
    setTitle('Cartridges');
    var familyOptions = catalogue.FAMILIES.map(function (f) {
      return '<option value="' + f + '">' + (f === 'all' ? 'All' : f) + '</option>';
    }).join('');
    appRoot().innerHTML =
      '<h1>Cartridges</h1>' +
      '<form class="toolbar" role="search" onsubmit="return false">' +
        '<label class="field"><span>Search</span>' +
          '<input type="search" id="search" autocomplete="off" spellcheck="false"></label>' +
        '<label class="field"><span>Family</span>' +
          '<select id="family">' + familyOptions + '</select></label>' +
      '</form>' +
      '<p class="count" id="count" aria-live="polite"></p>' +
      '<div class="table-wrap"><table class="list">' +
        '<thead><tr><th scope="col">Name</th><th scope="col">Family</th><th scope="col" class="num">L3</th></tr></thead>' +
        '<tbody id="rows"></tbody>' +
      '</table></div>';

    var search = document.getElementById('search');
    var family = document.getElementById('family');
    var rows = document.getElementById('rows');
    var count = document.getElementById('count');

    function update() {
      var list = catalogue.filterCartridges(records, search.value, family.value);
      rows.innerHTML = list.map(function (r) {
        return '<tr><td><a href="#/cartridge/' + encodeURIComponent(r.key) + '">' + escapeHtml(r.name) + '</a></td>' +
          '<td>' + escapeHtml(r.family) + '</td>' +
          '<td class="num">' + escapeHtml(format.formatNumber(r.cartridge.lengths.L3)) + ' mm</td></tr>';
      }).join('');
      count.textContent = catalogue.countText(list.length);
    }

    search.addEventListener('input', update);
    family.addEventListener('change', update);
    update();
  }

  function factRow(label, valueHtml) {
    return '<dt>' + escapeHtml(label) + '</dt><dd>' + valueHtml + '</dd>';
  }

  function capacityHtml(record) {
    var pc = record.annotations && record.annotations.publishedCapacity;
    if (!pc) {
      return 'not published';
    }
    var text = escapeHtml(format.formatNumber(pc.grH2O)) + ' ' + escapeHtml(format.unit('grH2O'));
    var source = pc.url
      ? '<a href="' + escapeHtml(pc.url) + '">' + escapeHtml(pc.source) + '</a>'
      : escapeHtml(pc.source);
    var note = pc.note ? ' (' + escapeHtml(pc.note) + ')' : '';
    return text + ', source ' + source + note;
  }

  // Detail view for one cartridge.
  function renderDetail(key) {
    var record = findRecord(key);
    if (!record) {
      setTitle('Not found · Cartridges');
      appRoot().innerHTML =
        '<h1>Cartridge not found</h1>' +
        '<p>No cartridge has the address <code>' + escapeHtml(key) + '</code>.</p>' +
        '<p><a href="#/">All cartridges</a></p>';
      return;
    }
    setTitle(record.name + ' · Cartridges');
    var a = record.annotations || {};
    var facts = '';
    if (record.alternativeNames && record.alternativeNames.length) {
      facts += factRow('Alternative names', record.alternativeNames.map(escapeHtml).join(', '));
    }
    facts += factRow('Family', escapeHtml(record.family));
    facts += factRow('Category', escapeHtml(a.category || ''));
    facts += factRow('Primer type', escapeHtml(a.primerType || ''));
    facts += factRow('C.I.P. table', escapeHtml(record.tab));
    facts += factRow('Country', escapeHtml(record.country));
    facts += factRow('Published', escapeHtml(record.published));
    facts += factRow('Revised', escapeHtml(record.revised));
    facts += factRow('Pressure method', escapeHtml(record.pressureMethod));
    facts += factRow('Water capacity', capacityHtml(record));

    var rendered = drawing.render(record);
    var groups = format.recordSections(record).map(function (section) {
      var kind = section.kind === 'cartridge' ? 'Cartridge' : 'Chamber';
      var rows = section.rows.map(function (r) {
        return '<tr><td>' + escapeHtml(r.symbol) + '</td><td class="num">' + escapeHtml(r.value) +
          '</td><td>' + escapeHtml(r.unit) + '</td></tr>';
      }).join('');
      return '<section class="group"><h2>' + kind + ' · ' + escapeHtml(section.title) + '</h2>' +
        '<div class="table-wrap"><table>' +
          '<thead><tr><th scope="col">Symbol</th><th scope="col" class="num">Value</th><th scope="col">Unit</th></tr></thead>' +
          '<tbody>' + rows + '</tbody></table></div></section>';
    }).join('');

    appRoot().innerHTML =
      '<p class="nav no-print"><a href="#/">All cartridges</a></p>' +
      '<header class="detail-head">' +
        '<h1>' + escapeHtml(record.name) + '</h1>' +
        '<button type="button" class="print-button no-print" id="print">Print</button>' +
      '</header>' +
      '<dl class="facts">' + facts + '</dl>' +
      '<figure class="drawing">' + rendered.svg + '</figure>' +
      '<div class="groups">' + groups + '</div>' +
      '<footer class="print-footer">Source: C.I.P. TDCC, revised ' + escapeHtml(record.revised) + '</footer>';

    document.getElementById('print').addEventListener('click', function () {
      root.print();
    });
  }

  function route() {
    var hash = root.location.hash || '#/';
    var match = /^#\/cartridge\/(.+)$/.exec(hash);
    if (match) {
      renderDetail(decodeURIComponent(match[1]));
      root.scrollTo(0, 0);
    } else {
      renderCatalogue();
    }
  }

  CIP.app = { route: route, renderCatalogue: renderCatalogue, renderDetail: renderDetail };

  // Render on load (not during parsing), then on every hash change.
  root.addEventListener('load', route);
  root.addEventListener('hashchange', route);
}(typeof window !== 'undefined' ? window : globalThis));
