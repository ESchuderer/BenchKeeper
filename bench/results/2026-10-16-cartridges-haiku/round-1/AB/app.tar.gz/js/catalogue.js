// Start page rules: sort order, search over names, family filter and the count text.
(function (root) {
  'use strict';

  var CIP = root.CIP = root.CIP || {};

  var collator = (typeof Intl !== 'undefined')
    ? new Intl.Collator('en', { numeric: true, sensitivity: 'base' })
    : null;

  function compareText(a, b) {
    if (collator) {
      return collator.compare(a, b);
    }
    return a.toLowerCase() < b.toLowerCase() ? -1 : (a.toLowerCase() > b.toLowerCase() ? 1 : 0);
  }

  function sortByName(records) {
    return records.slice().sort(function (a, b) {
      return compareText(a.name, b.name);
    });
  }

  // Trim, collapse runs of whitespace and lower-case, so that "7,62  x 51" matches "7,62 x 51".
  function normalise(text) {
    return String(text).replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function matchesQuery(record, query) {
    var q = normalise(query);
    if (q === '') {
      return true;
    }
    if (normalise(record.name).indexOf(q) !== -1) {
      return true;
    }
    var alternatives = record.alternativeNames || [];
    for (var i = 0; i < alternatives.length; i++) {
      if (normalise(alternatives[i]).indexOf(q) !== -1) {
        return true;
      }
    }
    return false;
  }

  // family: 'all' or one of the family names. Returns a new sorted array.
  function filterCartridges(records, query, family) {
    return sortByName(records).filter(function (record) {
      var familyOk = family === 'all' || family === undefined || record.family === family;
      return familyOk && matchesQuery(record, query);
    });
  }

  function countText(n) {
    return n + ' cartridges';
  }

  CIP.catalogue = {
    sortByName: sortByName,
    matchesQuery: matchesQuery,
    filterCartridges: filterCartridges,
    countText: countText,
    FAMILIES: ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = CIP.catalogue;
  }
}(typeof window !== 'undefined' ? window : globalThis));
