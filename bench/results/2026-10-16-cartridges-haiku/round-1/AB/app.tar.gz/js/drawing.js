// SVG drawing of a cartridge, computed from the geometry model. Coordinates are mm; 1 user unit = 1 mm.
// SVG x = z (head face at x = 0, mouth to the right). SVG y = -r for the outside view (above the axis)
// and +r for the section (below the axis).
// Layout: diameters and the shoulder angle are labelled above the drawing in a staircase (one level per
// label, the rightmost lowest), so no leader crosses another label. Lengths are dimensioned below the
// section, nested (the shortest closest to the drawing), so no extension line crosses a dimension line.
(function (root) {
  'use strict';

  var CIP = root.CIP = root.CIP || {};
  var geometry = CIP.geometry || (typeof require !== 'undefined' ? require('./geometry.js') : null);
  var format = CIP.format || (typeof require !== 'undefined' ? require('./format.js') : null);

  var LABEL_SIZE = 3.0;
  var LABEL_HEIGHT = 3.4;
  var LABEL_CHAR_WIDTH = 0.55 * LABEL_SIZE;
  var LEVEL_STEP = 4.8;
  var GUTTER_X = { R1: -4, P1: -9 };
  // Height of the drawing on the printed page; css/style.css sets the same value for print.
  var PRINT_HEIGHT_MM = 96;
  var NOTE_CHARS = 62;
  var MIN_TITLE_WIDTH = 84;

  function escapeXml(text) {
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function num(n) {
    return Number(n.toFixed(3)).toString();
  }

  function rad(deg) {
    return deg * Math.PI / 180;
  }

  // Outline radius at a station: the largest r of the outline points at z, else interpolated.
  function topAt(points, z) {
    var best = null;
    points.forEach(function (p) {
      if (Math.abs(p.z - z) < 1e-6 && (best === null || p.r > best)) {
        best = p.r;
      }
    });
    if (best !== null) {
      return best;
    }
    for (var j = 0; j < points.length - 1; j++) {
      var a = points[j], b = points[j + 1];
      if (a.z !== b.z && z >= Math.min(a.z, b.z) && z <= Math.max(a.z, b.z)) {
        return a.r + (b.r - a.r) * (z - a.z) / (b.z - a.z);
      }
    }
    return 0;
  }

  // Smallest outline radius at z (a belt can share the body-start station with the step).
  function lowestAt(points, z) {
    var best = null;
    points.forEach(function (p) {
      if (Math.abs(p.z - z) < 1e-6 && (best === null || p.r < best)) {
        best = p.r;
      }
    });
    return best === null ? topAt(points, z) : best;
  }

  function labelText(field, value, tolerance) {
    var text = format.formatValue(field, value);
    if (tolerance !== undefined) {
      text += ' ' + format.formatNumber(tolerance);
    }
    return format.symbol(field) + ' ' + text;
  }

  // The dimensions of a record, each with the geometry it needs.
  function dimensions(model, record) {
    var v = model.values;
    var outline = model.outline;
    var cart = record.cartridge || {};
    var collar = cart.collar || {};
    var lengths = cart.lengths || {};
    var powder = cart.powderChamber || {};
    var caseHead = cart.caseHead || {};
    var projectile = cart.projectile || {};
    var dims = [];
    function tolOf(group, field) {
      return group[field + 'Tol'];
    }

    // Lengths from the head face (z = 0).
    [
      { field: 'R', to: v.R, group: caseHead },
      { field: 'L1', to: v.L1, group: lengths },
      { field: 'L2', to: v.L2, group: lengths },
      { field: 'L3', to: v.L3, group: lengths },
      { field: 'L6', to: v.L6, group: lengths }
    ].forEach(function (d) {
      if (d.to === undefined || d.to === null) {
        return;
      }
      dims.push({
        kind: 'length',
        field: d.field,
        text: labelText(d.field, d.to, tolOf(d.group, d.field)),
        x0: 0,
        x1: d.to,
        ext: [{ x: 0, r: topAt(outline, 0) }, { x: d.to, r: topAt(outline, d.to) }]
      });
    });

    // Diameters: vertical dimension lines. R1 and P1 sit in the gutter, with extension lines.
    dims.push({
      kind: 'diameter',
      field: 'R1',
      text: labelText('R1', v.R1, tolOf(caseHead, 'R1')),
      x: GUTTER_X.R1,
      r: v.R1 / 2,
      extFrom: v.R,
      extR: v.R1 / 2
    });
    var bodyZ = model.groove ? model.groove.bodyZ : v.R;
    var p1r = lowestAt(outline, bodyZ);
    dims.push({
      kind: 'diameter',
      field: 'P1',
      text: labelText('P1', v.P1, tolOf(powder, 'P1')),
      x: GUTTER_X.P1,
      r: v.P1 / 2,
      extFrom: bodyZ,
      extR: p1r
    });
    if (model.shoulder) {
      dims.push({
        kind: 'diameter',
        field: 'P2',
        text: labelText('P2', v.P2, tolOf(powder, 'P2')),
        x: v.L1,
        r: v.P2 / 2
      });
      if (v.H1 !== undefined) {
        dims.push({
          kind: 'diameter',
          field: 'H1',
          text: labelText('H1', v.H1, tolOf(collar, 'H1')),
          x: v.L2,
          r: v.H1 / 2
        });
      }
    }
    var neckX = model.straight ? v.L3 : v.L3 - 1.5;
    dims.push({
      kind: 'diameter',
      field: 'H2',
      text: labelText('H2', v.H2, tolOf(collar, 'H2')),
      x: neckX,
      r: topAt(outline, neckX) || v.H2 / 2
    });
    if (model.bullet) {
      dims.push({
        kind: 'diameter',
        field: 'G1',
        text: labelText('G1', v.G1, tolOf(projectile, 'G1')),
        x: Math.min(v.L3 + 2, (model.bullet.zs + v.L3) / 2),
        r: model.bullet.Rexp
      });
    }
    if (model.groove) {
      dims.push({
        kind: 'diameter',
        field: 'E1',
        text: labelText('E1', v.E1, tolOf(caseHead, 'E1')),
        x: v.R + v.eMin / 2,
        r: v.E1 / 2
      });
    }

    // Shoulder angle: the cone apex lies on the axis at L1 + (P2/2) / tan(alpha/2). The arc joins the
    // two shoulder lines, with both ends on the shoulder between L1 and L2.
    if (model.shoulder) {
      var half = rad(model.shoulder.alpha / 2);
      var apex = v.L1 + (v.P2 / 2) / Math.tan(half);
      var arcR = (Math.hypot(apex - v.L1, v.P2 / 2) + Math.hypot(apex - v.L2, v.H1 / 2)) / 2;
      var alphaValue = record.cartridge.junctionCone.alpha;
      dims.push({
        kind: 'angle',
        field: 'alpha',
        text: format.symbol('alpha') + ' ' + format.formatAngle(alphaValue),
        apex: apex,
        arcR: arcR,
        half: half,
        x: apex - arcR * Math.cos(half),
        r: arcR * Math.sin(half)
      });
    }
    return dims;
  }

  // Axis-aligned obstacle tests in SVG coordinates (y down).
  function rectOverlap(a, b, margin) {
    return a.x0 < b.x1 + margin && b.x0 < a.x1 + margin && a.y0 < b.y1 + margin && b.y0 < a.y1 + margin;
  }

  function segHitsRect(s, r, margin) {
    return Math.min(s.x0, s.x1) < r.x1 + margin && r.x0 < Math.max(s.x0, s.x1) + margin &&
      Math.min(s.y0, s.y1) < r.y1 + margin && r.y0 < Math.max(s.y0, s.y1) + margin;
  }

  function segsCross(a, b, margin) {
    return Math.min(a.x0, a.x1) < Math.max(b.x0, b.x1) + margin && Math.min(b.x0, b.x1) < Math.max(a.x0, a.x1) + margin &&
      Math.min(a.y0, a.y1) < Math.max(b.y0, b.y1) + margin && Math.min(b.y0, b.y1) < Math.max(a.y0, a.y1) + margin;
  }

  // Lines that start at the head face (x = 0) share that origin: their meeting there is not a crossing.
  function startsAtOrigin(s) {
    return Math.abs(s.x0) < 0.01 || Math.abs(s.x1) < 0.01;
  }

  // True when a rectangle touches the outline polyline (sampled every 0.25 mm).
  function rectHitsOutline(rect, svgOutline, margin) {
    for (var i = 0; i < svgOutline.length - 1; i++) {
      var a = svgOutline[i], b = svgOutline[i + 1];
      var n = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 0.25));
      for (var k = 0; k <= n; k++) {
        var x = a.x + (b.x - a.x) * k / n, y = a.y + (b.y - a.y) * k / n;
        if (x >= rect.x0 - margin && x <= rect.x1 + margin && y >= rect.y0 - margin && y <= rect.y1 + margin) {
          return true;
        }
      }
    }
    return false;
  }

  // Lays out every dimension. Lines are fixed: the staircase above, the nested lengths below. A length
  // label may sit at several places along its line; the first that clears every other line, every
  // placed label and the outline is used. Returns the placed items and the names of any that cannot be placed.
  function layout(dims, model) {
    var outline = model.outline;
    var svgOutline = outline.map(function (p) { return { x: p.z, y: -p.r }; });
    var outlineTop = Math.max.apply(null, outline.map(function (p) { return p.r; }));
    var upper = dims.filter(function (d) { return d.kind !== 'length'; });
    var lower = dims.filter(function (d) { return d.kind === 'length'; });

    // Staircase above: the rightmost label is the lowest. Each further left sits one level higher.
    upper.sort(function (a, b) { return b.x - a.x; });
    upper.forEach(function (d, i) {
      var level = outlineTop + 2.5 + i * LEVEL_STEP;
      d.level = level;
      d.rect = { x0: d.x - 0.3, x1: d.x + labelWidth(d.text), y0: -level - LABEL_HEIGHT, y1: -level };
      d.leader = { x0: d.x, y0: -d.r, x1: d.x, y1: -level };
      d.textX = d.x + 0.6;
      d.textY = -level - 0.8;
      d.obstacles = [d.leader];
    });

    // Nested below: the shortest length is closest to the drawing.
    lower.sort(function (a, b) { return a.x1 - b.x1; });
    lower.forEach(function (d, i) {
      var level = outlineTop + 2.5 + i * LEVEL_STEP;
      d.level = level;
      d.line = { x0: d.x0, y0: level, x1: d.x1, y1: level };
      d.exts = d.ext.map(function (e) { return { x0: e.x, y0: e.r, x1: e.x, y1: level }; });
      d.obstacles = [d.line].concat(d.exts);
    });

    var allLines = [];
    dims.forEach(function (d) { d.obstacles.forEach(function (s) { allLines.push({ owner: d, s: s }); }); });
    var placed = [];
    var omitted = [];

    function fits(rect, d) {
      var own = d.obstacles;
      var others = allLines.filter(function (l) { return l.owner !== d; }).map(function (l) { return l.s; });
      if (rectHitsOutline(rect, svgOutline, 0.3)) { return false; }
      if (others.some(function (s) { return segHitsRect(s, rect, 0.2); })) { return false; }
      if (placed.some(function (o) { return rectOverlap(rect, o.rect, 0.2); })) { return false; }
      if (own.some(function (s) { return placed.some(function (o) { return segHitsRect(s, o.rect, 0.2); }); })) { return false; }
      return !own.some(function (s) {
        return others.some(function (t) {
          return segsCross(s, t, 0.2) && !(startsAtOrigin(s) && startsAtOrigin(t));
        });
      });
    }

    upper.forEach(function (d) {
      if (fits(d.rect, d)) {
        placed.push(d);
      } else {
        omitted.push(d.text);
      }
    });
    lower.forEach(function (d) {
      var w = labelWidth(d.text);
      var mid = (d.x0 + d.x1) / 2;
      var options = [Math.max(mid - w / 2, 1.0), 1.0, mid, mid - w / 2, -1.0 - w];
      var chosen = options.filter(function (x0) {
        return fits({ x0: x0, x1: x0 + w, y0: d.level + 0.6, y1: d.level + 0.6 + LABEL_HEIGHT }, d);
      })[0];
      if (chosen === undefined) {
        omitted.push(d.text);
        return;
      }
      d.rect = { x0: chosen, x1: chosen + w, y0: d.level + 0.6, y1: d.level + 0.6 + LABEL_HEIGHT };
      d.textX = (d.rect.x0 + d.rect.x1) / 2;
      d.textY = d.level + 0.6 + LABEL_HEIGHT - 0.7;
      placed.push(d);
    });
    return { placed: placed, omitted: omitted, svgOutline: svgOutline, outlineTop: outlineTop };
  }

  function labelWidth(text) {
    return Math.max(1, text.length) * LABEL_CHAR_WIDTH + 1.4;
  }

  function render(record) {
    var model = geometry.buildModel(record);
    var name = record.name;
    if (model.incomplete) {
      return {
        svg: '<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" viewBox="0 0 120 20" role="img" aria-label="' +
          escapeXml(name) + ' drawing"><text x="2" y="10" font-size="4">Drawing not possible: ' +
          escapeXml(model.missing.join('; ')) + '</text></svg>',
        labels: [], omitted: [], missing: model.missing, warnings: model.warnings, model: model
      };
    }
    var dims = dimensions(model, record);
    var lay = layout(dims, model);
    var outlineTop = lay.outlineTop;
    var L6 = model.values.L6;

    // Bounds of the drawing, the labels and the title block.
    var xMin = -12, xMax = L6 + 3, yMin = -outlineTop;
    var yMaxLabels = outlineTop;
    lay.placed.forEach(function (d) {
      xMin = Math.min(xMin, d.rect.x0);
      xMax = Math.max(xMax, d.rect.x1);
      yMin = Math.min(yMin, d.rect.y0);
      yMaxLabels = Math.max(yMaxLabels, d.rect.y1);
    });
    xMin -= 1.5; xMax += 1.5; yMin -= 1.5;
    var tbTop = yMaxLabels + 3;
    var notes = wrapNotes(model.missing.concat(model.warnings), NOTE_CHARS);
    var tbHeight = 19 + notes.length * 3.0 + 1.5;
    var width = Math.max(xMax - xMin, MIN_TITLE_WIDTH);
    if (xMax - xMin < MIN_TITLE_WIDTH) {
      xMax = xMin + width;
    }
    var yMax = tbTop + tbHeight + 1.5;
    var hatchId = 'hatch-' + record.key;

    var svg = [];
    svg.push('<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img" aria-label="' +
      escapeXml(name) + ' drawing" viewBox="' + num(xMin) + ' ' + num(yMin) + ' ' + num(width) + ' ' + num(yMax - yMin) +
      '">');
    svg.push('<defs><pattern id="' + hatchId + '" patternUnits="userSpaceOnUse" width="1.4" height="1.4" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="1.4" class="hatch-line"/></pattern></defs>');
    svg.push('<line class="centre-line" x1="' + num(xMin + 1) + '" y1="0" x2="' + num(L6 + 2) + '" y2="0"/>');
    svg.push('<path class="outline" fill="none" d="' + pathOf(lay.svgOutline, false) + '"/>');
    if (model.caseSection) {
      svg.push('<path class="section" fill="url(#' + hatchId + ')" d="' + pathOf(caseSectionSvg(model)) + '"/>');
    }
    if (model.bulletSection) {
      svg.push('<path class="section" fill="url(#' + hatchId + ')" d="' + pathOf(model.bulletSection.map(function (p) {
        return { x: p.z, y: p.r };
      })) + '"/>');
    }

    var lines = [];
    lay.placed.forEach(function (d) {
      if (d.kind === 'length') {
        lines.push(lineSvg(d.line.x0, d.line.y0, d.line.x1, d.line.y1, 'dim-line'));
        lines.push(arrowSvg(d.x0, d.level, 1, 0, 'dim-arrow'));
        lines.push(arrowSvg(d.x1, d.level, -1, 0, 'dim-arrow'));
        d.exts.forEach(function (e) {
          lines.push(lineSvg(e.x0, e.y0, e.x1, e.y1, 'ext-line'));
        });
        return;
      }
      lines.push(lineSvg(d.x, -d.r, d.x, d.r, 'dim-line'));
      lines.push(arrowSvg(d.x, -d.r, 0, 1, 'dim-arrow'));
      lines.push(arrowSvg(d.x, d.r, 0, -1, 'dim-arrow'));
      lines.push(lineSvg(d.leader.x0, d.leader.y0, d.leader.x1, d.leader.y1, 'leader'));
      if (d.extFrom !== undefined) {
        lines.push(lineSvg(d.extFrom, -d.extR, d.x, -d.extR, 'ext-line'));
        lines.push(lineSvg(d.extFrom, d.extR, d.x, d.extR, 'ext-line'));
      }
      if (d.kind === 'angle') {
        lines.push(angleArcSvg(d));
      }
    });
    svg.push('<g class="dimensions">' + lines.join('') + '</g>');

    svg.push('<g class="labels">' + lay.placed.map(function (d) {
      var anchor = d.kind === 'length' ? 'middle' : 'start';
      return '<text class="dim-label" x="' + num(d.textX) + '" y="' + num(d.textY) + '" text-anchor="' + anchor +
        '" font-size="' + LABEL_SIZE + '">' + escapeXml(d.text) + '</text>';
    }).join('') + '</g>');

    svg.push(titleBlockSvg(record, xMin, tbTop, width, tbHeight, notes, yMax - yMin));
    svg.push('</svg>');

    return {
      svg: svg.join(''),
      labels: lay.placed.map(function (d) { return { text: d.text, box: d.rect }; }),
      omitted: lay.omitted,
      missing: model.missing,
      warnings: model.warnings,
      model: model,
      viewBox: { x: xMin, y: yMin, width: width, height: yMax - yMin },
      printScale: printScale(yMax - yMin),
      outline: lay.svgOutline
    };
  }

  // Printed length over true length: the printed height of the drawing over its height in mm, as "n : 1".
  function printScale(trueHeight) {
    return (PRINT_HEIGHT_MM / trueHeight).toFixed(2) + ' : 1';
  }

  function pathOf(points, closed) {
    return points.map(function (p, i) {
      return (i === 0 ? 'M' : 'L') + num(p.x) + ' ' + num(p.y);
    }).join(' ') + (closed === false ? '' : ' Z');
  }

  // The case section (r >= 0) with the primer pocket as a notch from the head face along the axis.
  function caseSectionSvg(model) {
    var pts = model.caseSection.slice();
    if (model.pocket) {
      var pd = model.pocket.diameter / 2, d = model.pocket.depth;
      pts[0] = { z: 0, r: pd };
      pts.push({ z: d, r: 0 });
      pts.push({ z: d, r: pd });
    }
    return pts.map(function (p) { return { x: p.z, y: p.r }; });
  }

  function lineSvg(x0, y0, x1, y1, cls) {
    return '<line class="' + cls + '" x1="' + num(x0) + '" y1="' + num(y0) + '" x2="' + num(x1) + '" y2="' + num(y1) + '"/>';
  }

  // Filled arrowhead with its tip at (x, y), pointing along (dx, dy).
  function arrowSvg(x, y, dx, dy, cls) {
    var len = 1.6, half = 0.5;
    var bx = x - dx * len, by = y - dy * len;
    var px = -dy * half, py = dx * half;
    return '<path class="' + cls + '" d="M' + num(x) + ' ' + num(y) + ' L' + num(bx + px) + ' ' + num(by + py) +
      ' L' + num(bx - px) + ' ' + num(by - py) + ' Z"/>';
  }

  // The shoulder angle arc, from one shoulder line to the other, centred on the cone apex.
  function angleArcSvg(d) {
    var pts = [];
    for (var i = 0; i <= 12; i++) {
      var phi = -d.half + 2 * d.half * i / 12;
      pts.push({ x: d.apex - d.arcR * Math.cos(phi), y: -d.arcR * Math.sin(phi) });
    }
    return '<path class="dim-arc" fill="none" d="' + pts.map(function (p, i) {
      return (i === 0 ? 'M' : 'L') + num(p.x) + ' ' + num(p.y);
    }).join(' ') + '"/>';
  }

  function wrapNotes(items, width) {
    var lines = [];
    items.forEach(function (text) {
      var line = '';
      String(text).split(' ').forEach(function (w) {
        if ((line + ' ' + w).trim().length > width) {
          lines.push(line);
          line = w;
        } else {
          line = (line + ' ' + w).trim();
        }
      });
      if (line) {
        lines.push(line);
      }
    });
    return lines;
  }

  // Title block: name, C.I.P. table and revision, units, scale, then any notes on missing values.
  function titleBlockSvg(record, x, y, width, height, notes, trueHeight) {
    var out = [];
    out.push('<g class="title-block">');
    out.push('<rect class="tb-frame" x="' + num(x + 0.5) + '" y="' + num(y) + '" width="' + num(width - 1) + '" height="' + num(height) + '"/>');
    out.push('<text class="tb-name" x="' + num(x + 2) + '" y="' + num(y + 5.5) + '" font-size="4.4">' + escapeXml(record.name) + '</text>');
    out.push('<text class="tb-meta" x="' + num(x + 2) + '" y="' + num(y + 9.2) + '" font-size="2.9">C.I.P. table ' +
      escapeXml(record.tab) + ' · revised ' + escapeXml(record.revised) + '</text>');
    out.push('<text class="tb-meta" x="' + num(x + 2) + '" y="' + num(y + 12.4) + '" font-size="2.9">Dimensions in mm</text>');
    out.push('<text class="tb-meta" x="' + num(x + 2) + '" y="' + num(y + 15.6) + '" font-size="2.9">' +
      '<tspan class="scale-screen">Scale fit to width</tspan><tspan class="scale-print">Scale ' +
      escapeXml(printScale(trueHeight)) + '</tspan></text>');
    notes.forEach(function (line, i) {
      out.push('<text class="tb-note" x="' + num(x + 2) + '" y="' + num(y + 19 + i * 3.0) + '" font-size="2.4">' + escapeXml(line) + '</text>');
    });
    out.push('</g>');
    return out.join('');
  }

  CIP.drawing = {
    render: render,
    dimensions: dimensions,
    layout: layout,
    LABEL_SIZE: LABEL_SIZE,
    PRINT_HEIGHT_MM: PRINT_HEIGHT_MM
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = CIP.drawing;
  }
}(typeof window !== 'undefined' ? window : globalThis));
