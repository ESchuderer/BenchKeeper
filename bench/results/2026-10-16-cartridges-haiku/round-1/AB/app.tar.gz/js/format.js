// Display rules for cartridge values: how numbers, tolerances, angles, symbols and units are shown.
(function (root) {
  'use strict';

  var CIP = root.CIP = root.CIP || {};

  // Groups of the record, in display order, with their headings.
  var SECTIONS = [
    { kind: 'cartridge', group: 'caseHead', title: 'Case head' },
    { kind: 'cartridge', group: 'collar', title: 'Collar' },
    { kind: 'cartridge', group: 'junctionCone', title: 'Junction cone' },
    { kind: 'cartridge', group: 'lengths', title: 'Lengths' },
    { kind: 'cartridge', group: 'misc', title: 'Miscellaneous' },
    { kind: 'cartridge', group: 'powderChamber', title: 'Powder chamber' },
    { kind: 'cartridge', group: 'pressures', title: 'Pressures' },
    { kind: 'cartridge', group: 'projectile', title: 'Projectile' },
    { kind: 'chamber', group: 'barrel', title: 'Barrel' },
    { kind: 'chamber', group: 'breech', title: 'Breech' },
    { kind: 'chamber', group: 'collar', title: 'Collar' },
    { kind: 'chamber', group: 'grooves', title: 'Grooves' },
    { kind: 'chamber', group: 'junctionCone', title: 'Junction cone' },
    { kind: 'chamber', group: 'lengths', title: 'Lengths' },
    { kind: 'chamber', group: 'powderChamber', title: 'Powder chamber' },
    { kind: 'chamber', group: 'rifling', title: 'Rifling' }
  ];

  var ANGLE_FIELDS = { alpha: true, alpha1: true, beta: true, delta: true, i: true };

  // Units by field. Fields not listed here are lengths, diameters or radii in mm.
  var UNITS = {
    Pmax: 'bar', PK: 'bar', PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: '',
    S: 'mm',
    grH2O: 'gr H2O'
  };

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  function pad2(n) {
    return (n < 10 ? '0' : '') + String(n);
  }

  // A number is shown as published: no thousands separator, no trailing ".0".
  function formatNumber(n) {
    return String(n);
  }

  // An angle is a number of degrees, or {degrees, minutes, seconds}.
  function formatAngle(a) {
    if (typeof a === 'number') {
      return formatNumber(a) + '°';
    }
    return formatNumber(a.degrees) + '°' + pad2(a.minutes) + "'" + pad2(a.seconds) + '"';
  }

  function formatValue(field, value) {
    if (ANGLE_FIELDS[field]) {
      return formatAngle(value);
    }
    return formatNumber(value);
  }

  function symbol(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unit(field) {
    if (ANGLE_FIELDS[field]) {
      return '';
    }
    if (Object.prototype.hasOwnProperty.call(UNITS, field)) {
      return UNITS[field];
    }
    return 'mm';
  }

  // Value text for a field, with its tolerance from `<field>Tol` appended with a space.
  function valueWithTolerance(field, value, tolerance) {
    var text = formatValue(field, value);
    if (tolerance !== undefined) {
      text += ' ' + formatNumber(tolerance);
    }
    return text;
  }

  // Rows of one group. A `<X>Tol` field is folded into the row of X and gets no row of its own.
  function groupRows(groupObject) {
    var rows = [];
    Object.keys(groupObject).forEach(function (field) {
      if (/Tol$/.test(field) && Object.prototype.hasOwnProperty.call(groupObject, field.slice(0, -3))) {
        return;
      }
      var base = field;
      var tolKey = field + 'Tol';
      var tolerance = Object.prototype.hasOwnProperty.call(groupObject, tolKey) ? groupObject[tolKey] : undefined;
      rows.push({
        field: base,
        symbol: symbol(base),
        value: valueWithTolerance(base, groupObject[base], tolerance),
        unit: unit(base)
      });
    });
    return rows;
  }

  // All sections of a record that have at least one row, cartridge first, then chamber.
  function recordSections(record) {
    var out = [];
    SECTIONS.forEach(function (s) {
      var source = record[s.kind] && record[s.kind][s.group];
      if (!source) {
        return;
      }
      var rows = groupRows(source);
      if (rows.length) {
        out.push({ kind: s.kind, group: s.group, title: s.title, rows: rows });
      }
    });
    return out;
  }

  // Water capacity line: "30.5 gr H2O", or "not published".
  function capacityText(record) {
    var pc = record.annotations && record.annotations.publishedCapacity;
    if (!pc) {
      return null;
    }
    return formatNumber(pc.grH2O) + ' ' + UNITS.grH2O;
  }

  CIP.format = {
    SECTIONS: SECTIONS,
    formatNumber: formatNumber,
    formatAngle: formatAngle,
    formatValue: formatValue,
    symbol: symbol,
    unit: unit,
    valueWithTolerance: valueWithTolerance,
    groupRows: groupRows,
    recordSections: recordSections,
    capacityText: capacityText
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = CIP.format;
  }
}(typeof window !== 'undefined' ? window : globalThis));
