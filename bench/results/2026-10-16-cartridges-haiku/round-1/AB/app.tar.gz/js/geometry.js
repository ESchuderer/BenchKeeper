// Cartridge geometry model. Builds the profiles of the drawing in mm from the published values.
// Points are {z, r}: z runs along the axis from the head face (z = 0) to the mouth, r is the radius.
// The brief writes points as (r, z); the rules below follow it with the names of the record's values.
(function (root) {
  'use strict';

  var CIP = root.CIP = root.CIP || {};

  var ARC_STEPS = 12;

  // Primer pockets: diameter and depth by primer type (rule 8).
  var POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  function toDegrees(angle) {
    if (typeof angle === 'number') {
      return angle;
    }
    return angle.degrees + angle.minutes / 60 + angle.seconds / 3600;
  }

  function rad(deg) {
    return deg * Math.PI / 180;
  }

  function has(obj, key) {
    return obj[key] !== undefined && obj[key] !== null;
  }

  // The numbers the drawing uses, read from the record's nested groups.
  function readValues(record) {
    var c = record.cartridge || {};
    var ch = c.caseHead || {};
    var collar = c.collar || {};
    var junction = c.junctionCone || {};
    var lengths = c.lengths || {};
    var powder = c.powderChamber || {};
    var projectile = c.projectile || {};
    var annotations = record.annotations || {};
    return {
      R1: ch.R1, R: ch.R, R3: ch.R3, E: ch.E, E1: ch.E1, eMin: ch.eMin,
      beta: ch.beta, delta: ch.delta, f: ch.f,
      H1: collar.H1, H2: collar.H2,
      P1: powder.P1, P2: powder.P2,
      L1: lengths.L1, L2: lengths.L2, L3: lengths.L3, L6: lengths.L6,
      alpha: junction.alpha, r1Min: junction.r1Min, r2: junction.r2,
      G1: projectile.G1,
      primerType: annotations.primerType,
      category: annotations.category,
      bulletShape: annotations.defaultBulletShape,
      family: record.family
    };
  }

  // Rim classification (rule 1).
  function rimType(v, missing) {
    if (v.family === 'belted') {
      return 'belted';
    }
    if (v.family === 'rimfire') {
      return 'rimfire';
    }
    if (!has(v, 'R1') || !has(v, 'P1')) {
      missing.push('R1 or P1: rim type assumed rimless');
      return 'rimless';
    }
    var ratio = v.R1 / v.P1;
    if (ratio >= 1.05) {
      return 'rimmed';
    }
    if (ratio < 0.98) {
      return 'rebated';
    }
    return 'rimless';
  }

  // Samples an arc: z = cz + rho sin(a), r = cr + rho cos(a), for a from a0 to a1 (radians).
  function arcPoints(cz, cr, rho, a0, a1, steps) {
    var out = [];
    for (var i = 0; i <= steps; i++) {
      var a = a0 + (a1 - a0) * i / steps;
      out.push({ z: cz + rho * Math.sin(a), r: cr + rho * Math.cos(a) });
    }
    return out;
  }

  // Replaces the corner at `vertex` between `prev` and `next` by an arc tangent to both sides.
  // Returns the points that replace the vertex, from the first tangent point to the second.
  function roundCorner(prev, vertex, next, rho) {
    var ux = prev.z - vertex.z, uy = prev.r - vertex.r;
    var wx = next.z - vertex.z, wy = next.r - vertex.r;
    var lu = Math.hypot(ux, uy), lw = Math.hypot(wx, wy);
    ux /= lu; uy /= lu; wx /= lw; wy /= lw;
    var cosT = Math.max(-1, Math.min(1, ux * wx + uy * wy));
    var half = Math.acos(cosT) / 2;
    if (half < 1e-6 || half > Math.PI / 2 - 1e-6) {
      return [vertex];
    }
    var t = Math.min(rho / Math.tan(half), lu * 0.5, lw * 0.5);
    var radius = t * Math.tan(half);
    var d = radius / Math.sin(half);
    var bx = ux + wx, by = uy + wy;
    var lb = Math.hypot(bx, by);
    var cz = vertex.z + bx / lb * d, cr = vertex.r + by / lb * d;
    var t1 = { z: vertex.z + ux * t, r: vertex.r + uy * t };
    var t2 = { z: vertex.z + wx * t, r: vertex.r + wy * t };
    // Angles in the arcPoints convention: sin gives the z offset, cos the r offset.
    var a0 = Math.atan2(t1.z - cz, t1.r - cr);
    var a1 = Math.atan2(t2.z - cz, t2.r - cr);
    var sweep = a1 - a0;
    while (sweep > Math.PI) { sweep -= 2 * Math.PI; }
    while (sweep < -Math.PI) { sweep += 2 * Math.PI; }
    return arcPoints(cz, cr, radius, a0, a0 + sweep, ARC_STEPS);
  }

  // Head face and rim edge (rule 2), then groove or belt (rule 3) and the step to the body start.
  function headProfile(v, type, missing, warnings) {
    var Rh = v.R1 / 2;
    var P1h = v.P1 / 2;
    var pts = [{ z: 0, r: 0 }];
    var rimEnd;
    if (type === 'rimfire') {
      var rho = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
      pts.push({ z: 0, r: Rh - rho });
      arcPoints(rho, Rh - rho, rho, -Math.PI / 2, Math.PI / 2, ARC_STEPS).forEach(function (p) {
        pts.push(p);
      });
      rimEnd = { z: 2 * rho, r: Rh - rho };
    } else {
      var beta = has(v, 'beta') ? toDegrees(v.beta) : 90;
      if (has(v, 'f') && beta > 0 && beta < 90) {
        var cut = Math.min(v.f * Math.tan(rad(beta)), v.R1 / 4);
        pts.push({ z: 0, r: Rh - cut });
        pts.push({ z: v.f, r: Rh });
      } else {
        pts.push({ z: 0, r: Rh });
      }
      pts.push({ z: v.R, r: Rh });
      rimEnd = { z: v.R, r: Rh };
    }

    var groove = null;
    var wantGroove = has(v, 'E') && has(v, 'E1');
    if (wantGroove && !has(v, 'eMin')) {
      missing.push('eMin: extractor groove not drawn');
      wantGroove = false;
    }
    if (wantGroove) {
      var E1h = v.E1 / 2;
      var floorZ = rimEnd.z + v.eMin;
      pts.push({ z: rimEnd.z, r: E1h });
      pts.push({ z: floorZ, r: E1h });
      groove = { E: v.E, E1: v.E1, floorZ: floorZ, bodyZ: v.E, beltRampEnd: undefined };
      if (type === 'belted') {
        if (!has(v, 'R3') || !has(v, 'delta')) {
          missing.push('R3 or delta: belt ramp not drawn');
          pts.push({ z: v.E, r: P1h });
        } else {
          var R3h = v.R3 / 2;
          var rampEnd = floorZ + (R3h - E1h) / Math.tan(rad(toDegrees(v.delta)));
          if (rampEnd > v.E) {
            warnings.push('belt ramp ends at z ' + rampEnd.toFixed(2) + ', beyond E = ' + v.E);
          }
          groove.beltRampEnd = rampEnd;
          pts.push({ z: rampEnd, r: R3h });
          pts.push({ z: v.E, r: R3h });
          pts.push({ z: v.E, r: P1h });
        }
      } else {
        pts.push({ z: v.E, r: P1h });
      }
    } else {
      pts.push({ z: rimEnd.z, r: P1h });
    }
    return { points: pts, groove: groove, bodyZ: groove ? groove.bodyZ : rimEnd.z, rimEnd: rimEnd };
  }

  // Body, shoulder and neck (rules 4 and 5). Without alpha, L1 or L2 the case is straight.
  function bodyProfile(v, bodyZ, missing) {
    var P1h = v.P1 / 2;
    var H2h = v.H2 / 2;
    var mouth = { z: v.L3, r: H2h };
    var start = { z: bodyZ, r: P1h };
    var shoulderGiven = has(v, 'alpha') || has(v, 'L1') || has(v, 'L2');
    if (shoulderGiven) {
      var absent = ['P2', 'L1', 'L2', 'alpha', 'H1'].filter(function (k) { return !has(v, k); });
      if (absent.length) {
        missing.push(absent.join(', ') + ' missing: shoulder not drawn, case drawn straight');
      } else {
        var corner1 = { z: v.L1, r: v.P2 / 2 };
        var corner2 = { z: v.L2, r: v.H1 / 2 };
        var pts = [start];
        pts = pts.concat(has(v, 'r1Min') ? roundCorner(start, corner1, corner2, v.r1Min) : [corner1]);
        var neckSide = has(v, 'r2') ? roundCorner(corner1, corner2, mouth, v.r2) : [corner2];
        pts = pts.concat(neckSide);
        pts.push(mouth);
        return {
          points: pts,
          straight: false,
          shoulder: { P2h: corner1.r, L1: v.L1, H1h: corner2.r, L2: v.L2, alpha: toDegrees(v.alpha) }
        };
      }
    }
    return { points: [start, mouth], straight: true, shoulder: null };
  }

  // Primer pocket by primer type (rule 8). Rimfire cases have none.
  function pocketFor(v, type, missing) {
    if (type === 'rimfire') {
      return null;
    }
    if (!has(v, 'primerType')) {
      missing.push('primerType: primer pocket not drawn');
      return null;
    }
    if (!Object.prototype.hasOwnProperty.call(POCKET_DIAMETER, v.primerType)) {
      missing.push('primerType "' + v.primerType + '": primer pocket not drawn');
      return null;
    }
    return { diameter: POCKET_DIAMETER[v.primerType], depth: POCKET_DEPTH[v.primerType] };
  }

  // Seating, nose parameters by default bullet shape and category (rule 7). Null for unknown shapes.
  function bulletParams(v) {
    var pistol = v.category === 'pistol';
    var G1 = v.G1;
    switch (v.bulletShape) {
      case 'pointy':
        return { shape: 'pointy', seat: 1.0 * G1, k: 0.40, m: Math.max(0.08 * G1, 1.27) };
      case 'rounded':
        return pistol
          ? { shape: 'rounded', seat: 0.4 * G1, k: 0.65, m: 0.15 * G1 }
          : { shape: 'rounded', seat: 0.8 * G1, k: 0.55, m: 0.15 * G1 };
      case 'flat':
        return pistol
          ? { shape: 'flat', seat: 0.4 * G1, k: 0.70, m: 0.55 * G1 }
          : { shape: 'flat', seat: 0.8 * G1, k: 0.60, m: 0.55 * G1 };
      case 'semi_wadcutter':
        return { shape: 'semi_wadcutter', seat: 0.6 * G1, k: 0.78, m: 0.6 * G1 };
      default:
        return null;
    }
  }

  // Quarter ellipse from (zs, rs) to (L6, m/2), the start point excluded.
  function ellipsePoints(zs, rs, L6, m, steps) {
    var a = L6 - zs;
    var cr = m / 2;
    var b = rs - m / 2;
    var out = [];
    for (var i = 1; i <= steps; i++) {
      var t = (Math.PI / 2) * i / steps;
      out.push({ z: zs + a * Math.sin(t), r: cr + b * Math.cos(t) });
    }
    return out;
  }

  // Tangent ogive from (zs, rs) to (L6, m/2), the start point excluded. Radius rho = (d² + n²)/(2d).
  function ogivePoints(zs, rs, L6, m, steps) {
    var n = L6 - zs;
    var d = rs - m / 2;
    var rho = (d * d + n * n) / (2 * d);
    var cr = rs - rho;
    var end = Math.atan2(n / rho, (m / 2 - cr) / rho);
    return arcPoints(zs, cr, rho, 0, end, steps).slice(1);
  }

  function nosePoints(shape, zs, rs, L6, m) {
    if (shape === 'pointy') {
      return ogivePoints(zs, rs, L6, m, ARC_STEPS);
    }
    if (shape === 'rounded') {
      return ellipsePoints(zs, rs, L6, m, ARC_STEPS);
    }
    return [{ z: L6, r: m / 2 }];
  }

  // Inner wall of the case from the mouth to the body start (rule 8), as points ordered mouth first.
  // Along the body the wall is tb; along the neck tn, or the heel wall tb for a heeled case; a straight
  // case steps to the neck wall at the bullet base zb, and a bottleneck case blends across the shoulder.
  function innerWall(v, body, bodyZ, tb, tn, heeled, zb) {
    var H2h = v.H2 / 2, P1h = v.P1 / 2;
    var mouthR = heeled ? H2h - tb : H2h - tn;
    if (body.shoulder) {
      var s = body.shoulder;
      return [
        { z: v.L3, r: mouthR },
        { z: s.L2, r: s.H1h - tn },
        { z: s.L1, r: s.P2h - tb },
        { z: bodyZ, r: P1h - tb }
      ];
    }
    var outerAtBase = P1h + (H2h - P1h) * (zb - bodyZ) / (v.L3 - bodyZ);
    return [
      { z: v.L3, r: mouthR },
      { z: zb, r: mouthR },
      { z: zb, r: outerAtBase - tb },
      { z: bodyZ, r: P1h - tb }
    ];
  }

  // Cavity points from the mouth inward to z = w, then the cavity floor at z = w down to the axis.
  function cavityPoints(wall, w) {
    var ascending = wall.slice().reverse(); // body start first
    var rW = ascending[0].r;
    for (var i = 0; i < ascending.length - 1; i++) {
      var a = ascending[i], b = ascending[i + 1];
      if (w >= a.z && w <= b.z) {
        rW = a.r + (b.r - a.r) * (w - a.z) / (b.z - a.z);
        break;
      }
    }
    var above = wall.filter(function (p) { return p.z > w; });
    return { points: above.concat([{ z: w, r: rW }, { z: w, r: 0 }]), wallAtW: rW };
  }

  function dedupe(points) {
    var out = [];
    points.forEach(function (p) {
      var last = out[out.length - 1];
      if (!last || Math.abs(last.z - p.z) > 1e-9 || Math.abs(last.r - p.r) > 1e-9) {
        out.push({ z: p.z, r: p.r });
      }
    });
    return out;
  }

  function buildModel(record) {
    var missing = [];
    var warnings = [];
    var v = readValues(record);
    var model = {
      key: record.key,
      name: record.name,
      tab: record.tab,
      revised: record.revised,
      family: record.family,
      rimType: null,
      missing: missing,
      warnings: warnings,
      incomplete: false,
      values: v
    };

    ['R1', 'R', 'P1', 'H2', 'G1', 'L3', 'L6'].forEach(function (k) {
      if (!has(v, k)) {
        missing.push(k + ' missing: no drawing');
      }
    });
    if (missing.length) {
      model.incomplete = true;
      return model;
    }

    var type = rimType(v, missing);
    var head = headProfile(v, type, missing, warnings);
    var body = bodyProfile(v, head.bodyZ, missing);
    var outer = dedupe(head.points.concat(body.points));
    var Gh = v.G1 / 2;
    var H2h = v.H2 / 2;
    var heeled = (v.H2 - v.G1) <= 0.015;

    model.rimType = type;
    model.caseOuter = outer;
    model.groove = head.groove;
    model.shoulder = body.shoulder;
    model.straight = body.straight;

    var tn = Math.max(0, (v.H2 - v.G1) / 2);
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * v.P1 / 2);
    model.tn = tn;
    model.tb = tb;
    model.heeled = heeled;

    var bp = bulletParams(v);
    if (bp === null) {
      missing.push('defaultBulletShape missing or unknown: no bullet drawn');
      model.outline = outer.concat([{ z: v.L3, r: 0 }]);
      model.caseSection = null;
      model.bullet = null;
      return model;
    }

    // Bullet (rule 7).
    var L3 = v.L3, L6 = v.L6;
    var zb = L3 - bp.seat;
    var zs = zb + bp.k * (L6 - zb);
    var Rexp = heeled ? H2h : Gh;
    var Rseat = heeled ? (H2h - tb) : Gh;
    var exposed = [{ z: L3, r: Rexp }, { z: zs, r: Rexp }].concat(nosePoints(bp.shape, zs, Rexp, L6, bp.m));
    if (zs < L3) {
      warnings.push('bullet cylinder ends before the mouth; nose drawn from the mouth');
    }
    model.bullet = {
      shape: bp.shape, seat: bp.seat, k: bp.k, m: bp.m,
      zb: zb, Lb: L6 - zb, zs: zs, heeled: heeled, Rexp: Rexp, Rseat: Rseat
    };
    model.outline = dedupe(outer.concat(exposed).concat([{ z: L6, r: 0 }]));
    model.bulletSection = dedupe(
      [{ z: zb, r: 0 }, { z: zb, r: Rseat }, { z: L3, r: Rseat }]
        .concat(exposed)
        .concat([{ z: L6, r: 0 }])
    );

    // Section walls, solid head and primer pocket (rule 8).
    var wall = innerWall(v, body, head.bodyZ, tb, tn, heeled, v.L3 - bp.seat);
    var pk = pocketFor(v, type, missing);
    var wCandidates = [2.5, 0.25 * v.P1 / 2];
    if (pk) { wCandidates.push(pk.depth + 1.5); }
    if (head.groove) { wCandidates.push(head.groove.E + tb); }
    if (head.groove && head.groove.beltRampEnd !== undefined) { wCandidates.push(head.groove.beltRampEnd + tb); }
    var w = Math.max.apply(null, wCandidates);
    var cavity = cavityPoints(wall, w);
    model.w = w;
    model.caseSection = dedupe(outer.concat(cavity.points));
    model.wallAtW = cavity.wallAtW;
    model.pocket = pk;
    model.pocketPoly = pk ? dedupe([
      { z: 0, r: 0 }, { z: 0, r: pk.diameter / 2 }, { z: pk.depth, r: pk.diameter / 2 }, { z: pk.depth, r: 0 }
    ]) : null;
    return model;
  }

  CIP.geometry = {
    buildModel: buildModel,
    toDegrees: toDegrees,
    roundCorner: roundCorner,
    arcPoints: arcPoints,
    rimType: function (record) {
      return rimType(readValues(record), []);
    },
    POCKET_DIAMETER: POCKET_DIAMETER,
    POCKET_DEPTH: POCKET_DEPTH
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = CIP.geometry;
  }
}(typeof window !== 'undefined' ? window : globalThis));
