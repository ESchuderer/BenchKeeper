# Design

## Context

The project is empty apart from the OpenSpec scaffold, so there is no existing code to match. The app must open from `file://` in Chromium, which blocks ES module imports and `fetch` of local files; scripts therefore load as classic `<script>` tags in a fixed order and share one global namespace. See proposal.md for motivation and specs/ for the observable behaviour.

## Goals / Non-Goals

**Goals:**
- Plain files: `index.html`, `css/style.css`, `js/*.js`, and the embedded data in `js/data.js`.
- Pure, testable modules for formatting, catalogue filtering, geometry and SVG markup, so that the drawing rules can be checked numerically for all 25 records.
- A browser end-to-end check of the detail views, `file://` loading, hash navigation and the single-page A4 print.

**Non-Goals:**
- No framework, bundler, transpiler, service worker or offline cache beyond the files themselves.
- No editing, sorting by user choice, unit conversion or additional data.
- No server code and no runtime npm dependencies.

## Decisions

**1. Module layout and namespace.** Every script wraps itself in an IIFE that writes to `window.CIP` (a single namespace), and ends with `module.exports` guarded by `typeof module`, so the same file runs in the browser and under `node:test`. Load order in `index.html`: `data.js`, `format.js`, `catalogue.js`, `geometry.js`, `drawing.js`, `app.js`. *Alternative:* ES modules — rejected because they fail from `file://`.

**2. Coordinates.** The brief writes points as `(r, z)`; the code stores `{z, r}` objects. The axis is `r = 0`. The SVG maps `x = z` (plus a left margin) and the upper half to `y = cy - r`; the section is the same polygon with `r` negated. One SVG user unit is one mm, so the `viewBox` is in mm and the SVG has `width: 100%; height: auto`.

**3. Drawing is a string.** `drawing.js` returns SVG markup as a string from the geometry model; `app.js` inserts it with `innerHTML`. This keeps the drawing testable in Node without a DOM. The markup escapes every text value.

**4. Profile construction.** `geometry.js` builds, for each record:
- the rim type (rule 1), then the head face and rim edge (chamfer, square corner, or rimfire half-round arc);
- the groove or belt (rule 3), the body, the shoulder with its α/2 line and fillets (`r1Min`, `r2`), and the neck (rule 5);
- the bullet exposed and seated profile (rule 7), including the nose as an ogive arc (`ρ = (d² + n²)/(2d)`, `d = G1/2 - m/2`), a quarter ellipse, or a cone;
- the case section polygon: outer wall, mouth face, inner wall with `tb` along the body, `tn` along the neck (a straight case steps to `tn` at the bullet base; a heeled case ends at the heel wall `tb`), a linear blend across the shoulder, closed to the axis at the solid head (`z = w`), with the primer pocket as a notch from the head face along the axis;
- the bullet section polygon.

Fillets are arcs sampled at fixed angle steps. Missing values disable the dependent feature, and the model records a `missing` entry (for example `"P2 missing: shoulder drawn without it"`) that the drawing prints under the title block. *Alternative:* keep the fillets as SVG path arcs — rejected because sampled points make the label-collision and bounds checks direct.

**5. Dimension placement.** The layout is deterministic, not searched. Diameters (R1, P1, P2, H1, H2, G1, E1) and the shoulder angle α are labelled above the outside view as a staircase: one level per label, ordered by station with the rightmost lowest, so every leader runs up past no label. Each label starts at its leader, and its box is estimated as `0.55 × font size × characters`. Lengths (R, L1, L2, L3, L6) are dimensioned below the section, nested: the shortest sits closest to the drawing, so no extension line crosses a dimension line. A length label may take one of a few positions along its line, and the first that clears every other line, label and the outline is used. Extension lines that start at the head face share that origin, and their meeting there is not counted as a crossing. A verification pass checks every label and line; a dimension that still clashes is named in the title block rather than drawn over the outline. *Alternative:* a greedy search over tiers — tried first, but wide labels blocked the leaders of their neighbours, and the search could not escape.

**6. Routing and state.** `app.js` renders from `location.hash` on `hashchange`; `#/` shows the catalogue and `#/cartridge/<key>` shows the detail view. The catalogue keeps its search and family state in the DOM only, so reopening the list starts with no filter (the brief does not ask for filter persistence). Search and family filtering are pure functions in `catalogue.js`.

**7. Formatting.** `format.js` owns the display rules: value as published (`String(value)`, so `51.18` and `4150` stay as given), the tolerance appended with a space, angles as `40°` or `3°10'36"` (minutes and seconds zero-padded to two digits), the symbol map and the unit map. Unit map decisions not stated in the brief: `S` is shown in mm, since it is neither an angle nor a listed unit, and it is a radius-type value; `grH2O` is shown as `gr H2O`. Both are recorded here so they can be checked against the source. *Alternative:* leave them unitless — rejected, a unitless number is less useful for a reference sheet.

**8. Theme and print.** Colours are CSS custom properties with a `prefers-color-scheme: dark` override. The print stylesheet resets them to black on white. Print uses `@page { size: A4 portrait; margin: 12mm }`; the detail sheet hides the navigation, search, select and buttons, lays out the sections in four columns and prints a footer "Source: C.I.P. TDCC, revised <date>". The drawing prints at a fixed height of 96 mm (the same value as `PRINT_HEIGHT_MM` in `drawing.js`), so its width follows its proportions. A full-width drawing would push the tables onto a second page, so the width is not fixed; this is the one deliberate departure from a full-width print, and the title block states the resulting scale.

**9. Tests.** Unit tests use `node:test` (built into Node 22, so no test runner dependency). Browser tests use `playwright` as a devDependency with the Chromium binary it installs; they open `index.html` by `file://` and also through a local static server, and check navigation, print, and page count (a PDF of the detail page must be exactly one page). Screenshots of drawings are taken for review but are not pixel-compared.

## Risks / Trade-offs

- **[Label placement fails for some record]** → the search is bounded, and an omitted dimension is named in the title block, so the sheet is never silently wrong. A browser test checks no label overlaps (the estimated boxes are generous, and screenshots are reviewed).
- **[Text width estimate is off in the browser]** → use a generous 0.6 em factor and a fixed label font; the e2e check measures the real `getBBox()` of every label and fails on overlap.
- **[Print does not fit one page on long records]** → two-column sections and a 8.5 pt table font; the e2e PDF page-count test checks the longest record (`300 Win. Mag.`, `338 Lapua Mag.`, `9,3 x 62`).
- **[Unit assumptions for `S` and `grH2O`]** → stated above and reported to the user; changing them is a one-line change in `format.js`.
- **[Bullet or case geometry contradicts a value (for example `E` beyond `L3`)]** → the model clamps nothing silently: it records a warning and draws the rule as written.

## Migration Plan

Not applicable: a new project. Rollback is deleting the new files.

## Open Questions

None that change the specs or the task breakdown. The `S` and `grH2O` unit assumptions are recorded above and will be reported at completion.
