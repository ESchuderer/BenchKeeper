# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick, offline reference for C.I.P. cartridge dimensions, pressures and chamber data. The 25 records supplied with this change are the only data; the app presents them in the form the OpenBallistics cartridge database does, as a searchable list, a detail page per cartridge with a scaled 2D drawing, and a printable data sheet. The app must run from disk with no server, so it can be carried on a laptop or phone in the field.

## What Changes

- Add a static web app in the project root: `index.html`, a stylesheet, and JavaScript files, with no framework, no build step, no runtime dependencies and no network requests.
- Embed the 25 records exactly as supplied. No data is added, changed or fetched.
- Start page: heading "Cartridges", a list of every cartridge (name link, family, case length L3), a "Search" field, a "Family" select and a "<n> cartridges" count.
- Detail view per cartridge at its own hash address (survives reload, can be bookmarked): header fields, C.I.P. table, country, dates, pressure method, published water capacity with source link, the 2D drawing, grouped cartridge and chamber value tables, a "Print" button and an "All cartridges" link.
- Inline SVG drawing computed from the record with the geometry rules of the brief (true to scale, 1 SVG unit = 1 mm, outside view above the axis, hatched section below, dimension lines, title block).
- Print layout: one A4 portrait page, black on white, header, drawing, tables and source footer.
- Light and dark appearance following the system setting; usable on a phone.

No existing behaviour is changed; this is a new project (no prior specs or code).

## Capabilities

### New Capabilities

- `app-shell`: how the app is packaged and delivered (plain files, works from `file://` and static servers, no network, hash routing, theme and responsive layout).
- `cartridge-data`: the embedded records and how their values, tolerances, angles, units and symbols are displayed.
- `cartridge-catalogue`: the start page list, search by name and alternative names, family filter and count.
- `cartridge-detail`: the detail view, its header fields, grouped value and chamber tables, navigation and addressing.
- `cartridge-drawing`: the computed, to-scale SVG drawing of the outside view and section, its dimension lines, labels and title block.
- `cartridge-print`: the print button and the A4 print layout with its source footer.

### Modified Capabilities

None. The project has no existing specs.

## Impact

- New files only: `index.html`, `css/` stylesheet, `js/` scripts (data, formatting, geometry, drawing, views), tests under `test/`, and a `package.json` declaring test tooling as devDependencies only.
- No runtime dependencies, no build output, no server code, no external fonts or scripts.
- Browser targets: current Chromium (desktop and Android) and any modern browser that supports SVG and hash routing.
