# Spec Delta

## Purpose

How the application is delivered and behaves as a whole: plain files that run by opening `index.html` from disk or from any static server, with no network requests, hash-based addresses, a theme that follows the system, and a layout that works on a phone.

## ADDED Requirements

### Requirement: Runs from disk and from a static server
The application SHALL run fully when `index.html` is opened directly from disk in Chromium (file://) and when its folder is served by any static file server, without a build step or server code.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened from disk in Chromium
- **THEN** the start page shows all cartridges and every detail view works

#### Scenario: Served statically
- **WHEN** the project folder is served by a static file server
- **THEN** the application behaves exactly as when opened from disk

### Requirement: No network requests and no runtime dependencies
The application SHALL make no network requests: no CDNs, web fonts, analytics, or remote images or scripts. Its scripts and styles SHALL be local files that are loaded without modules or fetch, so that they load under file://.

#### Scenario: No external resources
- **WHEN** the application loads
- **THEN** every script, style and image is a local file of the project

#### Scenario: Only user-initiated links leave the page
- **WHEN** the user activates the source link of a water capacity
- **THEN** the browser navigates there; the application does not request it itself

### Requirement: Hash-based addresses
The application SHALL use the URL fragment for its addresses: `#/` for the start page and `#/cartridge/<key>` for a cartridge's detail view. Navigating to an address SHALL show the matching view without a reload, and the document title SHALL name the view.

#### Scenario: Address changes view
- **WHEN** the user follows a link to `#/cartridge/308_win`
- **THEN** the detail view of `308 Win.` is shown and the document title contains "308 Win."

#### Scenario: Back button
- **WHEN** the user goes back from a detail view
- **THEN** the previous view is shown

### Requirement: Theme follows the system
The application SHALL use a light appearance and a dark appearance, chosen by the system's colour-scheme setting, with tabular numerals for all values. Print SHALL always use the light appearance.

#### Scenario: Dark system setting
- **WHEN** the system prefers a dark colour scheme
- **THEN** the application is shown in the dark appearance

#### Scenario: Tabular numerals
- **WHEN** a value is displayed in a table
- **THEN** its digits are tabular so that decimal points align in a column

### Requirement: Usable on a phone
The application SHALL be usable on a phone-width screen of 360 CSS pixels: text is readable without zooming, the search, family select and links are reachable, and the value tables scroll horizontally inside their own container instead of the page.

#### Scenario: Phone width
- **WHEN** the application is viewed at 360 CSS pixels wide
- **THEN** the page has no horizontal scrolling, and a wide table scrolls within its own container
