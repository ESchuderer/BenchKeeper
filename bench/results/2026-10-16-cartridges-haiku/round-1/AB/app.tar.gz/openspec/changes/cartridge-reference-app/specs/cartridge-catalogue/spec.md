# Spec Delta

## Purpose

The start page: a searchable, filterable list of all cartridges, from which each cartridge's detail view is opened. It is the entry point for finding a cartridge by any of its published names.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL have the heading "Cartridges" and SHALL list every cartridge with its name, family and case length L3. The list is sorted by name, ignoring case, with numbers compared by value.

#### Scenario: Full list on load
- **WHEN** the start page is opened without a search or filter
- **THEN** the heading "Cartridges" is shown and all 25 cartridges are listed with name, family and L3

#### Scenario: Sorted by name
- **WHEN** the list is shown
- **THEN** `7 x 64` is listed before `8 x 57 IS`, and `6,5 Creedmoor` is listed before `7 mm Rem. Mag.`

#### Scenario: L3 shown with unit
- **WHEN** the cartridge `22 Long Rifle` is listed
- **THEN** its L3 is shown as `15.57 mm`

### Requirement: Each name opens its detail view
Each cartridge name in the list SHALL be a link whose text is exactly the record's `name` and whose address is the cartridge's own detail address.

#### Scenario: Link text
- **WHEN** the list is shown
- **THEN** each name link's text equals the record's `name` exactly

#### Scenario: Opening a cartridge
- **WHEN** the user activates the link for `308 Win.`
- **THEN** the detail view for `308 Win.` opens

### Requirement: Search filters by name and alternative names
A field labelled "Search" SHALL filter the list as the user types. A cartridge matches when the query, ignoring case and extra spaces, is contained in its `name` or in any of its `alternativeNames`.

#### Scenario: Alternative name finds cartridge
- **WHEN** the user types `7,62 x 51` into Search
- **THEN** `308 Win.` is listed, because it has the alternative name `7,62 x 51`

#### Scenario: Name match is case-insensitive
- **WHEN** the user types `creedmoor`
- **THEN** `6,5 Creedmoor` is listed

#### Scenario: Empty search shows all
- **WHEN** the Search field is empty
- **THEN** all cartridges that match the family filter are listed

### Requirement: Family select filters the list
A select labelled "Family" SHALL offer All, rimless, rimmed, belted, pistol and rimfire. It filters the list by the record's `family`, and applies together with the search.

#### Scenario: Family filter
- **WHEN** the user selects "rimfire"
- **THEN** only the rimfire cartridges are listed

#### Scenario: Family and search combine
- **WHEN** the family is "rimless" and the search is `308`
- **THEN** only rimless cartridges matching `308` are listed

#### Scenario: All families
- **WHEN** the family is "All"
- **THEN** the family filter does not remove any cartridge

### Requirement: Count of listed cartridges
The page SHALL show the text "<n> cartridges", where <n> is the number of cartridges currently listed, and SHALL update with every change of search or family.

#### Scenario: Count after filtering
- **WHEN** the family "belted" is selected
- **THEN** the page shows "2 cartridges"

#### Scenario: No match
- **WHEN** the search matches no cartridge
- **THEN** the page shows "0 cartridges" and no list rows
