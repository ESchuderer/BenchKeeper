# Spec Delta

## Purpose

Defines the embedded cartridge records and how their values, tolerances, angles, units and symbols are shown. Every other capability reads cartridge data through these rules, so the published values appear unchanged.

## ADDED Requirements

### Requirement: Embedded records are the only data
The system SHALL embed exactly the 25 supplied cartridge records and SHALL NOT add, change, derive or fetch any cartridge data. Each record is identified by its `key` and displayed under its `name`.

#### Scenario: All records are available
- **WHEN** the application starts
- **THEN** exactly 25 cartridge records are available, each with its `key` and `name` as supplied

#### Scenario: Names are shown as published
- **WHEN** a record is displayed anywhere in the application
- **THEN** its name is shown exactly as published, for example `6,5 Creedmoor` and `308 Win.`

### Requirement: Numeric values are shown as published
The system SHALL show each numeric value with the decimal point as published, without thousands separators, and SHALL NOT round or re-format it. A value is followed by its unit.

#### Scenario: Value with unit
- **WHEN** a value `51.18` in millimetres is displayed
- **THEN** it reads `51.18 mm`

#### Scenario: Pressure without separator
- **WHEN** the pressure `Pmax` with value `4150` is displayed
- **THEN** it reads `4150 bar`

### Requirement: Units follow the field
The system SHALL assign units by field: lengths, diameters and radii in mm; `Pmax`, `PK`, `PE` in bar; `EE` in J; `M` in g; `Q` in mm²; `N` is a count with no unit; angle fields are shown as angles; `S` in mm; `grH2O` (water capacity) in gr H2O.

#### Scenario: Count has no unit
- **WHEN** the groove count `N` is displayed
- **THEN** its unit cell is empty

#### Scenario: Area unit
- **WHEN** the groove area `Q` is displayed
- **THEN** its unit is mm²

### Requirement: Tolerances are shown beside their value
The system SHALL show a field `<X>Tol` next to the value of `X` in the same cell, separated by a space, and SHALL NOT give it a row of its own. The tolerance is shown with its sign as published.

#### Scenario: Tolerance next to value
- **WHEN** a record has `L1` 39.62 and `L1Tol` -0.2
- **THEN** the value of `L1` reads `39.62 -0.2` and there is no separate row for `L1Tol`

### Requirement: Angles are shown as degrees or degrees, minutes and seconds
The system SHALL show a numeric angle as degrees followed by `°`, and an angle given as `{degrees, minutes, seconds}` as degrees, minutes and seconds with a two-digit minute and second, for example `39°59'49"`.

#### Scenario: Plain angle
- **WHEN** an angle `alpha` of 46 is displayed
- **THEN** it reads `46°`

#### Scenario: Angle with minutes and seconds
- **WHEN** an angle `i` with degrees 3, minutes 10 and seconds 36 is displayed
- **THEN** it reads `3°10'36"`

### Requirement: Symbols are field names with listed exceptions
The system SHALL use the field name as the symbol, except: `eMin` shows "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", and `L3PlusG` "L3 + G".

#### Scenario: Greek symbol
- **WHEN** the field `beta` is displayed
- **THEN** its symbol is "β"

#### Scenario: Ordinary field
- **WHEN** the field `P2` is displayed
- **THEN** its symbol is "P2"
