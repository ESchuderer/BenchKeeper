# Spec Delta

## Purpose

The detail view of one cartridge: its header facts, drawing, grouped cartridge and chamber values, and the links that move between it and the list. Each cartridge has its own bookmarkable address.

## ADDED Requirements

### Requirement: Each cartridge has its own address
Each cartridge SHALL have a detail address containing its `key`, so that opening, reloading or bookmarking the address shows the same cartridge. An unknown key SHALL show a "not found" message with a link to the start page.

#### Scenario: Reload keeps the cartridge
- **WHEN** the detail view of `223 Rem.` is open and the page is reloaded
- **THEN** the detail view of `223 Rem.` is shown again

#### Scenario: Unknown key
- **WHEN** the address names a key that is not in the data
- **THEN** a "not found" message is shown with a link to the start page

### Requirement: Heading and header facts
The detail view SHALL have the cartridge's name as its heading and SHALL show, in this order: alternative names (only when present), family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method and the published water capacity.

#### Scenario: Heading is the name
- **WHEN** the detail view of `9 mm Luger` is shown
- **THEN** its heading reads `9 mm Luger`

#### Scenario: Alternative names
- **WHEN** the cartridge `308 Win.` is shown
- **THEN** its alternative names `308 Winchester`, `7,62 x 51` are shown

#### Scenario: No alternative names
- **WHEN** the cartridge `223 Rem.` is shown
- **THEN** no alternative names line is shown

### Requirement: Water capacity with source
The detail view SHALL show the published water capacity (`grH2O` with the note, when present) and its source as a link to the source's `url`. When no capacity is published, it SHALL say so.

#### Scenario: Capacity with source link
- **WHEN** the cartridge `223 Rem.` is shown
- **THEN** the water capacity `30.5 gr H2O` is shown with the link text "kwk" pointing to its `url`

#### Scenario: No capacity published
- **WHEN** a cartridge without `publishedCapacity` is shown
- **THEN** the water capacity line reads "not published"

### Requirement: Values and chamber in grouped tables
The detail view SHALL show every value of the record in tables grouped by section, cartridge sections first and then chamber sections, with the columns "Symbol", "Value" and "Unit". Each table row shows one field, and a tolerance is shown in its value's cell.

#### Scenario: Every value is shown
- **WHEN** the detail view of any cartridge is shown
- **THEN** every numeric field of its record appears exactly once in the tables

#### Scenario: Column headings
- **WHEN** a values table is shown
- **THEN** its columns are headed "Symbol", "Value" and "Unit"

#### Scenario: Tolerance in value cell
- **WHEN** the table shows `L3` with `L3Tol` -0.25 for a pistol cartridge
- **THEN** the value cell of `L3` reads `19.15 -0.25` and no row is shown for `L3Tol`

### Requirement: Actions and navigation
The detail view SHALL have a "Print" button that opens the browser's print dialog, and a link "All cartridges" that returns to the start page.

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** the browser's print dialog opens

#### Scenario: Back to list
- **WHEN** the user activates "All cartridges"
- **THEN** the start page is shown

### Requirement: Drawing is shown on the detail view
The detail view SHALL show the cartridge's 2D drawing after the header facts and before the tables.

#### Scenario: Order of sections
- **WHEN** the detail view is shown
- **THEN** the header facts appear first, then the drawing, then the tables
