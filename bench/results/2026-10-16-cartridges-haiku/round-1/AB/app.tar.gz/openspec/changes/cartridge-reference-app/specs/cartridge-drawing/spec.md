# Spec Delta

## Purpose

The 2D drawing of a cartridge: an inline SVG computed from the record's published values, true to scale, showing the outside view above the axis and a hatched section below it, with dimension lines and a title block. It lets a reloader or gunsmith check chamber and case geometry at a glance.

## ADDED Requirements

### Requirement: True-scale inline SVG
The drawing SHALL be an inline SVG with the accessible name "<name> drawing", in which 1 user unit equals 1 mm. The axis SHALL be horizontal with the case head on the left (z = 0 at the head face) and the mouth on the right. The SVG SHALL scale to the width of its container while keeping its proportions.

#### Scenario: Accessible name
- **WHEN** the detail view of `308 Win.` is shown
- **THEN** the SVG has the accessible name "308 Win. drawing"

#### Scenario: Head on the left
- **WHEN** the drawing of any cartridge is shown
- **THEN** the head face lies at the left end and the mouth at the right end of the axis

#### Scenario: Scales to phone width
- **WHEN** the container is 360 CSS pixels wide
- **THEN** the drawing is displayed 360 pixels wide, with its proportions unchanged

### Requirement: Outside view and section
The upper half of the drawing SHALL show the outside view of the cartridge and the lower half a section, in which the cut walls of case and bullet are hatched. A dash-dot centre line SHALL lie on the axis.

#### Scenario: Section hatching
- **WHEN** the drawing is shown
- **THEN** the cut walls in the lower half are hatched and the upper half is not

#### Scenario: Centre line
- **WHEN** the drawing is shown
- **THEN** a dash-dot line is drawn along the axis

### Requirement: Rim type from the published values
The system SHALL classify the rim: family `belted` is belted, `rimfire` is rimfire; otherwise a ratio R1/P1 of 1.05 or more is rimmed, below 0.98 rebated, and anything else rimless.

#### Scenario: Rimmed cartridge
- **WHEN** the family is `rimmed` (for example `7 x 65 R`)
- **THEN** the rim is drawn as a rimmed rim

#### Scenario: Rimless by ratio
- **WHEN** the family is `rimless` and R1/P1 is between 0.98 and 1.05
- **THEN** the rim is drawn as rimless

### Requirement: Head face and rim edge
The head face SHALL run from the axis outward; where β and f are published and β is below 90°, it SHALL have a chamfer from `(R1/2 - min(f·tan β, R1/4), 0)` to `(R1/2, f)`, then rise to `(R1/2, R)`. A rimfire rim edge SHALL be a half-round of radius min(R/2, (R1 - P1)/2) whose outermost point lies at R1/2. Otherwise the corner is square.

#### Scenario: Chamfered head
- **WHEN** β and f are published with β below 90°
- **THEN** the chamfer runs from the head face to `(R1/2, f)`

#### Scenario: Rimfire half-round
- **WHEN** the cartridge is rimfire
- **THEN** the rim edge is a half-round whose outermost point is at R1/2

### Requirement: Extractor groove and belt
Where E and E1 are published, the outline SHALL include the extractor groove: from `(R1/2, R)` inward to `(E1/2, R)`, along the floor to `(E1/2, R + eMin)`, then a straight ramp to `(P1/2, E)`. For belted cases the ramp SHALL run at the angle δ to the axis up to the belt radius R3/2, follow the belt to z = E, then step in to P1/2. Without a groove the outline steps in from `(R1/2, R)` to `(P1/2, R)`.

#### Scenario: Groove drawn
- **WHEN** E and E1 are published for `223 Rem.`
- **THEN** the extractor groove is drawn between z = 0 and z = E

#### Scenario: Belted case
- **WHEN** the family is `belted` (for example `300 Win. Mag.`)
- **THEN** the ramp follows the angle δ up to the belt radius R3/2 and the belt runs to z = E

#### Scenario: No groove
- **WHEN** E or E1 is not published
- **THEN** the outline steps in from the rim to P1/2 without a groove, and the drawing reports that the groove is omitted because E or E1 is missing

### Requirement: Body, shoulder and neck
The outline SHALL run from P1/2 at the body start to `(P2/2, L1)` on a bottleneck case, then along the shoulder through `(H1/2, L2)` with the included cone angle α (the line at α/2 to the axis), with the body-side corner rounded by r1 min and the neck-side corner by r2 where published, then to `(H2/2, L3)` and the mouth. A case without α, L1 or L2 SHALL be straight, running to `(H2/2, L3)`.

#### Scenario: Bottleneck
- **WHEN** `308 Win.` is drawn
- **THEN** the outline runs body, shoulder, neck and mouth in that order

#### Scenario: Straight case
- **WHEN** `22 Long Rifle` (no shoulder) is drawn
- **THEN** the body runs straight to the mouth at L3

#### Scenario: Shoulder angle label
- **WHEN** α is published
- **THEN** the shoulder angle is labelled α with its value

### Requirement: Bullet by nose shape
The bullet SHALL run from the mouth to the tip at z = L6 with shank diameter G1 and its nose from `annotations.defaultBulletShape`. The seating depth s is 1.0·G1 for pointy; 0.8·G1 for rounded or flat on rifle and rimfire; 0.4·G1 for rounded or flat on pistol; 0.6·G1 for semi_wadcutter. The base is at zb = L3 - s and the bullet length Lb = L6 - zb. The cylinder runs to zb + k·Lb with k as published by the shape, and the nose ends at a flat tip (meplat) of diameter m as given by the shape.

#### Scenario: Pointy bullet
- **WHEN** `308 Win.` (pointy) is drawn
- **THEN** the bullet is seated 1.0·G1 below the mouth and its nose is a tangent ogive with meplat m = max(0.08·G1, 1.27)

#### Scenario: Semi-wadcutter pistol bullet
- **WHEN** `38 Special` (semi_wadcutter) is drawn
- **THEN** the bullet is seated 0.6·G1 below the mouth, its cylinder ends at 0.78 of its length and its nose is a straight cone with meplat 0.6·G1

### Requirement: Heeled cases
When H2 - G1 is 0.015 mm or less, the exposed bullet SHALL have the case's outside diameter, and the seated heel SHALL have the case's inside diameter H2 - 2·tb.

#### Scenario: Rimfire heeled bullet
- **WHEN** `22 Long Rifle` is drawn, with H2 5.72 and G1 5.72
- **THEN** the exposed bullet has the outside diameter of the case and the seated heel the inside diameter

### Requirement: Section walls
In the section the neck wall SHALL be tn = (H2 - G1)/2 and the body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner line SHALL follow the outer body, shoulder and neck at these wall thicknesses. The solid head SHALL run from the head face to z = w, where w is the largest of 2.5, 0.25·P1/2, the pocket depth + 1.5, E + tb where a groove exists, and the belt ramp end + tb on belted cases.

#### Scenario: Wall thicknesses
- **WHEN** `223 Rem.` is drawn
- **THEN** the neck wall is (H2 - G1)/2 and the body wall is min(max(1.3·tn, 0.6), 0.35·P1/2)

### Requirement: Primer pocket
Centrefire cases SHALL show a primer pocket of diameter 4.45 for primer types sp, spm, sr and 5.33 for lp, lpm, lr, lrm, and of depth 3.04 for sp, spm, sr, lp, lpm and 3.3 for lr, lrm. Rimfire cases have no pocket.

#### Scenario: Rifle primer pocket
- **WHEN** a case with primer type `lr` is drawn
- **THEN** its primer pocket has diameter 5.33 and depth 3.3

#### Scenario: Rimfire has no pocket
- **WHEN** a rimfire case is drawn
- **THEN** the drawing shows no primer pocket

### Requirement: Dimension lines
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α where published. Each SHALL carry a label of its symbol and value, for example `L3 51.18`. Labels SHALL NOT overlap each other or the outline.

#### Scenario: Mandatory dimensions
- **WHEN** any cartridge is drawn
- **THEN** dimension lines for L3, L6, R1, R and P1 are present with their labels

#### Scenario: Optional dimension omitted
- **WHEN** P2 is not published
- **THEN** no dimension line for P2 is drawn

#### Scenario: Labels do not collide
- **WHEN** the drawing of any of the 25 cartridges is shown
- **THEN** no two labels overlap and no label overlaps the outline

### Requirement: Title block
The drawing SHALL include a title block with the cartridge's name, its C.I.P. table and revision date, the text "Dimensions in mm", and the scale. On screen the scale reads "fit to width"; in print it reads as the ratio of paper length to true length, for example "1.55 : 1".

#### Scenario: Title block contents
- **WHEN** the drawing of `9 mm Luger` is shown on screen
- **THEN** the title block shows the name, the C.I.P. table IV, the revision date 2008-09-23, "Dimensions in mm" and "fit to width"

#### Scenario: Printed scale
- **WHEN** the drawing is printed across a 186 mm wide area and is 120 mm true length
- **THEN** the title block reads "1.55 : 1"

### Requirement: Missing values are reported, never invented
When a value that a rule needs is missing, the drawing SHALL omit the feature that depends on it and SHALL state which value is missing. The system SHALL NOT substitute a number for a missing published value.

#### Scenario: Missing dimension reported
- **WHEN** a cartridge has no `P2` value needed for the shoulder
- **THEN** the shoulder is drawn without that feature and the drawing states that P2 is missing
