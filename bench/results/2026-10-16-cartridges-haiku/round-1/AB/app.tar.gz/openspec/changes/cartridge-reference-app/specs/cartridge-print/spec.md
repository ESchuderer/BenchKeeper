# Spec Delta

## Purpose

The printed data sheet of one cartridge: a single A4 portrait page in black on white, carrying the header, drawing, values and source, so that a reloader can keep a paper copy at the bench.

## ADDED Requirements

### Requirement: Print opens the print dialog
The "Print" button of the detail view SHALL open the browser's print dialog for the cartridge shown.

#### Scenario: Print dialog for shown cartridge
- **WHEN** the user activates "Print" on the detail view of `44 Rem. Mag.`
- **THEN** the print dialog opens for that page

### Requirement: One A4 portrait page
The printed detail view SHALL fit on one A4 portrait page, black on white, containing a page header with the name, the drawing with every label legible, and then the value and chamber tables. The drawing SHALL print at a fixed height of 96 mm, so its width follows its proportions; it therefore fills the printable width only when its proportions allow it, because the tables must fit on the same page. The printed page SHALL NOT contain navigation, the search field, or buttons.

#### Scenario: Single page
- **WHEN** the detail view of `223 Rem.` is printed
- **THEN** the output is one A4 portrait page

#### Scenario: Printed drawing height
- **WHEN** the detail view of any cartridge is printed
- **THEN** the drawing is 96 mm high on the page and its title block states the printed scale as a ratio of paper length to true length

#### Scenario: Only the sheet is printed
- **WHEN** the detail view is printed
- **THEN** the "Print" button, the "All cartridges" link and the search and family controls are not printed

#### Scenario: Black on white
- **WHEN** the detail view is printed while the screen uses the dark appearance
- **THEN** the printed page is black text on a white background

### Requirement: Print footer with source
The printed page SHALL have a footer stating the source as "C.I.P. TDCC" and the record's revised date.

#### Scenario: Footer text
- **WHEN** the detail view of `6,5 Creedmoor` is printed
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2020-04-21"

### Requirement: Tables fit the page
The printed value and chamber tables SHALL be laid out in several columns of sections, so that the whole page, including the drawing, fits the A4 page.

#### Scenario: Longest record fits
- **WHEN** the detail view of the cartridge with the most values is printed
- **THEN** all its tables and the drawing fit on one page without the content being cut off
