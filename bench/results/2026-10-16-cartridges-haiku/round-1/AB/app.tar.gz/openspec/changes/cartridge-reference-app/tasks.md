# Tasks

## 1. Project scaffold and embedded data

- [x] 1.1 Create `package.json` with `"test": "node --test \"test/unit/*.test.js\""` and `"test:e2e": "node --test \"test/e2e/*.test.js\""`, with `playwright` as the only devDependency; verify `npm install` succeeds and `npm test` runs (50 unit tests pass)
- [x] 1.2 Create `js/data.js` holding the 25 records exactly as supplied, one JSON object per line in a classic-script array; verify a unit test loads 25 records, all `key` values are unique, and every `<X>Tol` has a matching `X` in its group
- [x] 1.3 Create `index.html` with the document skeleton, viewport meta, `css/style.css` link and script tags in the order `data`, `format`, `catalogue`, `geometry`, `drawing`, `app`; verify the file loads with no console errors and no network requests other than local files, from `file://` in Chromium (Playwright)

## 2. Value formatting

- [x] 2.1 Implement `js/format.js`: value as published, tolerance appended with a space, angle formatting (`40°`, `3°10'36"`), symbol map, unit map (including `S` in mm and `grH2O` as `gr H2O`); verify unit tests cover `51.18 mm`, `4150 bar`, `39.62 -0.2`, `46°`, `3°10'36"`, `β`, `delta L`, `L3 + G`, `Q` in mm², and an empty unit for `N`
- [x] 2.2 Implement the section and row builder in `format.js`: each group's fields as rows with `Symbol`, `Value`, `Unit`, `Tol` folded into its value, and no row for any `Tol` field; verify unit test over all 25 records that no row has a symbol ending in `Tol` and that each record's row count equals its non-tolerance field count

## 3. Catalogue

- [x] 3.1 Implement `js/catalogue.js`: `sortByName` (ignore case, numeric compare), `matchesQuery` (case-insensitive, whitespace-collapsed substring over name and alternative names), `filterCartridges(records, query, family)`; verify unit tests: `7,62 x 51` finds `308 Win.`, `creedmoor` finds `6,5 Creedmoor`, `7 x 64` sorts before `8 x 57 IS`, family counts are rimless 12, rimmed 2, belted 2, pistol 6, rimfire 3, and the search and family filters combine
- [x] 3.2 Add the count text helper returning `<n> cartridges` for any `n` including 0 and 1; verify unit tests for `0`, `1`, `2`, `25`

## 4. Geometry model

- [x] 4.1 Implement the rim classification and head face / rim edge in `js/geometry.js` (rules 1 and 2): verify unit tests for `6,5 Creedmoor` (rimless), `7 x 65 R` (rimmed), `300 Win. Mag.` (belted), `22 Long Rifle` (rimfire half-round ending at `z = R`), and the chamfer end point for `223 Rem.`
- [x] 4.2 Implement the extractor groove and belt ramp (rule 3) and the body, shoulder with α/2 line and r1Min / r2 fillets, neck and straight case path (rule 4 and 5): verify unit tests for the groove floor and ramp end of `223 Rem.`, the belt ramp end for `300 Win. Mag.` (≈3.24 mm), the shoulder angle of `308 Win.`, and that `22 Long Rifle` has no shoulder point
- [x] 4.3 Implement the bullet model (rule 7): seating depth, base, cylinder end, nose shapes (ogive arc, quarter ellipse, cone) and meplat per `defaultBulletShape`, heeled exposure; verify unit tests: `308 Win.` ogive arc starts tangent to the cylinder at `z = zb + 0.40·Lb` and ends at `(L6, m/2)`, `9 mm Luger` seats 0.4·G1, `22 Long Rifle` is heeled with exposed radius H2/2
- [x] 4.4 Implement the section (rule 8): walls `tn` and `tb`, inner profile with the shoulder blend, solid head `w`, primer pocket diameter and depth per primer type, rimfire without pocket; verify unit tests for `223 Rem.` (`tn = (6.43 - 5.7)/2 = 0.365`), `lr` pocket 5.33 × 3.3, and `22 Long Rifle` with no pocket
- [x] 4.5 Record missing values (rule 9): verify a unit test with a record copy where `P2` is removed reports `P2 missing`, draws a straight body from the `P1` station to the mouth, and never substitutes a number

## 5. SVG drawing and dimensions

- [x] 5.1 Implement `js/drawing.js` markup: outside view above the axis, hatched section below (pattern, primer pocket as a notch), dash-dot centre line, outline stroke, mm `viewBox`, `role="img"` and `aria-label="<name> drawing"`, all text escaped; verify unit tests parse the markup well-formedly (balanced tags) and that the `viewBox` covers z from 0 to L6 and the full diameter for all 25 records
- [x] 5.2 Add dimension lines (arrowheads, extension lines) for L3, L6, R1, R, P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and α, with labels `<symbol> <value>` and the deterministic staircase / nested layout of design decision 5; verify unit tests that every mandatory dimension is present for all 25 records and that optional ones are absent when unpublished
- [x] 5.3 Add the title block (name, C.I.P. table, revision date, "Dimensions in mm", scale "fit to width" on screen and the printed ratio in print) and the missing-values note; verify unit test that the title text contains name, `tab` and `revised`
- [x] 5.4 Label collision check: for all 25 records, the label boxes do not overlap each other, any dimension line, or the sampled outline, and no dimension is omitted; verify the unit tests pass (the first greedy placement omitted labels, so the layout was changed to the staircase / nested scheme, not the data)

## 6. Application views and routing

- [x] 6.1 Implement `js/app.js` hash routing: `#/` catalogue, `#/cartridge/<key>` detail, unknown key shows "not found" with a link; set `document.title` per view; verify with Playwright on `file://` that a detail address survives reload and that back/forward work
- [x] 6.2 Implement the catalogue view: heading "Cartridges", Search field (label "Search") and Family select (label "Family", options All, rimless, rimmed, belted, pistol, rimfire), list rows with name link, family and L3, and the "<n> cartridges" count updating live; verify Playwright: searching `7,62 x 51` lists `308 Win.` only and the count reads `1 cartridges`
- [x] 6.3 Implement the detail view: heading, header facts in the specified order, water capacity with source link (or "not published"), drawing, grouped tables with columns Symbol / Value / Unit, "Print" button and "All cartridges" link; verify Playwright on `223 Rem.` that the table count and the `L1` row (`36.52 -0.2`) are right and the header order is correct
- [x] 6.4 Write `css/style.css`: light and dark custom properties from `prefers-color-scheme`, tabular numerals, phone layout at 360 px with no page-level horizontal scroll and horizontally scrolling tables; verify Playwright at 360 px width that the document does not scroll sideways and that dark mode colours apply when emulated

## 7. Print

- [x] 7.1 Add the `@media print` stylesheet: A4 portrait, 12 mm margins, black on white for all colours, hide navigation, search, select and buttons, the sections in four columns, drawing at 96 mm height, footer "Source: C.I.P. TDCC, revised <date>"; verify Playwright `page.pdf()` produces exactly one page for `338 Lapua Mag.`, `300 Win. Mag.`, `22 Long Rifle` and `9 mm Luger`, and the footer text is shown in print media
- [x] 7.2 Wire the "Print" button to `window.print()`; verify Playwright that the button click calls `window.print` (stubbed in the page)

## 8. Verification and review

- [x] 8.1 Run the complete unit and e2e suites: the e2e suite opens the app from `file://` and through a local static server; all 50 unit tests and 17 browser tests pass
- [x] 8.2 Review the drawings of all 25 records visually: a contact sheet at desktop width and one at phone width (360 CSS px cells). Layout, labels, hatching and title blocks were checked; the geometry defects found (straight-case wall taper, title-block overlap, placement clashes) were fixed in the geometry and layout code, not the data
- [x] 8.3 Run `openspec validate cartridge-reference-app --strict` (passes); each requirement scenario is covered by a unit or browser test, except the visual checks in 8.2, which are manual

## Workflow follow-up

- Archive the change after the project's review requirements are satisfied.
