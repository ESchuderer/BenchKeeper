'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, fileUrl, serve } = require('./support');

let browser;

test.before(async () => {
  browser = await launch();
});

test.after(async () => {
  await browser.close();
});

// Opens a page and collects its console errors and every request it makes.
async function openPage(options = {}) {
  const context = await browser.newContext({ viewport: options.viewport || { width: 1100, height: 900 }, colorScheme: options.colorScheme });
  const page = await context.newPage();
  const errors = [];
  const requests = [];
  page.on('console', (m) => { if (m.type() === 'error') { errors.push(m.text()); } });
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('request', (r) => requests.push(r.url()));
  return { context, page, errors, requests };
}

test('opens from file:// with no errors and no network requests other than local files', async () => {
  const { context, page, errors, requests } = await openPage();
  await page.goto(fileUrl('#/'));
  await page.waitForSelector('#count');
  await page.waitForTimeout(300);
  assert.deepEqual(errors, []);
  requests.forEach((url) => assert.ok(url.startsWith('file://'), `request to ${url}`));
  await context.close();
});

test('the start page has the heading, the count, and one link per cartridge with the exact name', async () => {
  const { context, page } = await openPage();
  await page.goto(fileUrl('#/'));
  await page.waitForSelector('#count');
  await page.waitForTimeout(300);
  assert.equal(await page.textContent('h1'), 'Cartridges');
  assert.equal(await page.textContent('#count'), '25 cartridges');
  const links = await page.$$eval('#rows a', (as) => as.map((a) => a.textContent));
  assert.equal(links.length, 25);
  assert.ok(links.includes('6,5 Creedmoor'));
  assert.ok(links.includes('308 Win.'));
  await context.close();
});

test('search filters as the user types, including alternative names, and the count follows', async () => {
  const { context, page } = await openPage();
  await page.goto(fileUrl('#/'));
  await page.waitForSelector('#count');
  await page.waitForTimeout(300);
  await page.fill('#search', '7,62 x 51');
  await page.waitForTimeout(100);
  assert.equal(await page.textContent('#count'), '1 cartridges');
  assert.deepEqual(await page.$$eval('#rows a', (as) => as.map((a) => a.textContent)), ['308 Win.']);
  await page.fill('#search', '');
  await page.waitForTimeout(100);
  assert.equal(await page.textContent('#count'), '25 cartridges');
  await context.close();
});

test('the family select filters the list and combines with the search', async () => {
  const { context, page } = await openPage();
  await page.goto(fileUrl('#/'));
  await page.waitForSelector('#count');
  await page.waitForTimeout(300);
  await page.selectOption('#family', 'rimfire');
  await page.waitForTimeout(100);
  assert.equal(await page.textContent('#count'), '3 cartridges');
  await page.fill('#search', '17');
  await page.waitForTimeout(100);
  assert.deepEqual(await page.$$eval('#rows a', (as) => as.map((a) => a.textContent)), ['17 HMR']);
  await page.selectOption('#family', 'pistol');
  await page.waitForTimeout(100);
  assert.equal(await page.textContent('#count'), '0 cartridges');
  await context.close();
});

test('the detail view keeps its address on reload and shows the header, tables and drawing', async () => {
  const { context, page, errors } = await openPage();
  await page.goto(fileUrl('#/cartridge/223_rem'));
  await page.waitForSelector('svg.cartridge-drawing');
  await page.reload();
  await page.waitForSelector('svg.cartridge-drawing');
  assert.equal(page.url().endsWith('#/cartridge/223_rem'), true);
  assert.equal(await page.textContent('h1'), '223 Rem.');
  const facts = await page.$$eval('.facts dt', (dts) => dts.map((d) => d.textContent));
  assert.deepEqual(facts.slice(0, 4), ['Family', 'Category', 'Primer type', 'C.I.P. table']);
  assert.equal(await page.$eval('.facts dd:nth-of-type(4)', (d) => d.textContent), 'I');
  assert.equal(await page.$$eval('table', (t) => t.length), 16);
  const headers = await page.$$eval('.groups table thead th', (ths) => [...new Set(ths.map((t) => t.textContent))]);
  assert.deepEqual(headers, ['Symbol', 'Value', 'Unit']);
  const l1 = await page.$$eval('tr', (rows) => rows.map((r) => [...r.cells].map((c) => c.textContent)).find((c) => c[0] === 'L1'));
  assert.deepEqual(l1, ['L1', '36.52 -0.2', 'mm']);
  const symbols = await page.$$eval('.groups tbody td:first-child', (tds) => tds.map((t) => t.textContent));
  assert.equal(symbols.some((s) => s.endsWith('Tol')), false, 'no tolerance row');
  assert.equal(await page.getAttribute('svg.cartridge-drawing', 'aria-label'), '223 Rem. drawing');
  assert.deepEqual(errors, []);
  await context.close();
});

test('the water capacity shows its source as a link to the source address', async () => {
  const { context, page } = await openPage();
  await page.goto(fileUrl('#/cartridge/223_rem'));
  await page.waitForSelector('svg.cartridge-drawing');
  const href = await page.getAttribute('.facts a', 'href');
  assert.equal(href, 'http://kwk.us/cases.html');
  assert.equal(await page.textContent('.facts a'), 'kwk');
  await context.close();
});

test('an unknown cartridge address shows "not found" with a link back', async () => {
  const { context, page } = await openPage();
  await page.goto(fileUrl('#/cartridge/no_such_key'));
  await page.waitForSelector('h1');
  assert.equal(await page.textContent('h1'), 'Cartridge not found');
  assert.equal(await page.getAttribute('a[href="#/"]', 'href'), '#/');
  await context.close();
});

test('"All cartridges" returns to the list and "Print" calls the print dialog', async () => {
  const { context, page } = await openPage();
  await page.goto(fileUrl('#/cartridge/308_win'));
  await page.waitForSelector('svg.cartridge-drawing');
  await page.evaluate(() => { window.__printCalls = 0; window.print = () => { window.__printCalls += 1; }; });
  await page.click('#print');
  assert.equal(await page.evaluate(() => window.__printCalls), 1);
  await page.click('text=All cartridges');
  await page.waitForSelector('#count');
  assert.equal(await page.evaluate(() => location.hash), '#/');
  await context.close();
});

test('light and dark appearance follow the system colour scheme', async () => {
  const light = await openPage({ colorScheme: 'light' });
  await light.page.goto(fileUrl('#/cartridge/223_rem'));
  await light.page.waitForSelector('svg.cartridge-drawing');
  assert.equal(await light.page.evaluate(() => getComputedStyle(document.body).backgroundColor), 'rgb(255, 255, 255)');
  await light.context.close();

  const dark = await openPage({ colorScheme: 'dark' });
  await dark.page.goto(fileUrl('#/cartridge/223_rem'));
  await dark.page.waitForSelector('svg.cartridge-drawing');
  assert.equal(await dark.page.evaluate(() => getComputedStyle(document.body).backgroundColor), 'rgb(17, 20, 24)');
  await dark.context.close();
});

test('at 360 CSS pixels the page does not scroll sideways, and the drawing fits the width', async () => {
  const { context, page } = await openPage({ viewport: { width: 360, height: 740 } });
  await page.goto(fileUrl('#/cartridge/338_lapua_mag'));
  await page.waitForSelector('svg.cartridge-drawing');
  const scroll = await page.evaluate(() => ({ page: document.documentElement.scrollWidth, client: document.documentElement.clientWidth }));
  assert.ok(scroll.page <= scroll.client, `page scrollWidth ${scroll.page} > ${scroll.client}`);
  const box = await (await page.$('svg.cartridge-drawing')).boundingBox();
  assert.ok(box.width <= 360, `drawing width ${box.width}`);
  await context.close();
});

test('a static server serves the same app as file://', async () => {
  const server = await serve();
  const { port } = server.address();
  const { context, page, errors } = await openPage();
  await page.goto(`http://127.0.0.1:${port}/index.html#/cartridge/223_rem`);
  await page.waitForSelector('svg.cartridge-drawing');
  assert.equal(await page.textContent('h1'), '223 Rem.');
  assert.deepEqual(errors, []);
  await context.close();
  await new Promise((resolve) => server.close(resolve));
});

test('back and forward move between the list and a detail view', async () => {
  const { context, page } = await openPage();
  await page.goto(fileUrl('#/'));
  await page.waitForSelector('#count');
  await page.waitForTimeout(300);
  await page.click('text=308 Win.');
  await page.waitForSelector('svg.cartridge-drawing');
  assert.equal(await page.textContent('h1'), '308 Win.');
  await page.goBack();
  await page.waitForSelector('#count');
  assert.equal(await page.evaluate(() => location.hash), '#/');
  await page.goForward();
  await page.waitForSelector('svg.cartridge-drawing');
  assert.equal(await page.textContent('h1'), '308 Win.');
  await context.close();
});
