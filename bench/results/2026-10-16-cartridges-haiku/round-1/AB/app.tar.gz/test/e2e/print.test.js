'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, fileUrl } = require('./support');

let browser;

test.before(async () => {
  browser = await launch();
});

test.after(async () => {
  await browser.close();
});

// Counts the pages of a PDF: each page object is "/Type /Page" not followed by "s" (that would be /Pages).
function pageCount(pdf) {
  const text = pdf.toString('latin1');
  return (text.match(/\/Type\s*\/Page(?!s)/g) || []).length;
}

test('print media hides navigation, search and buttons, and shows the source footer', async () => {
  const context = await browser.newContext({ viewport: { width: 1100, height: 900 }, colorScheme: 'dark' });
  const page = await context.newPage();
  await page.goto(fileUrl('#/cartridge/6_5_creedmoor'));
  await page.waitForSelector('svg.cartridge-drawing');
  await page.emulateMedia({ media: 'print' });
  const shown = await page.evaluate(() => ({
    nav: getComputedStyle(document.querySelector('.nav')).display,
    button: getComputedStyle(document.getElementById('print')).display,
    footer: getComputedStyle(document.querySelector('.print-footer')).display,
    footerText: document.querySelector('.print-footer').textContent,
    background: getComputedStyle(document.body).backgroundColor,
    colour: getComputedStyle(document.body).color
  }));
  assert.equal(shown.nav, 'none');
  assert.equal(shown.button, 'none');
  assert.equal(shown.footer, 'block');
  assert.equal(shown.footerText, 'Source: C.I.P. TDCC, revised 2020-04-21');
  assert.equal(shown.background, 'rgb(255, 255, 255)');
  assert.equal(shown.colour, 'rgb(0, 0, 0)');
  await context.close();
});

for (const key of ['338_lapua_mag', '300_win_mag', '22_long_rifle', '9_mm_luger']) {
  test(`printing ${key} gives one A4 portrait page`, async () => {
    const context = await browser.newContext({ viewport: { width: 1100, height: 900 } });
    const page = await context.newPage();
    await page.goto(fileUrl(`#/cartridge/${key}`));
    await page.waitForSelector('svg.cartridge-drawing');
    const pdf = await page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true });
    assert.equal(pageCount(pdf), 1, `${key} prints on one page`);
    await context.close();
  });
}
