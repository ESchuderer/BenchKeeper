'use strict';

// Browser helpers for the end-to-end tests. Playwright's own Chromium is used unless CHROMIUM_EXECUTABLE
// names another Chromium binary; CHROMIUM_ARGS may hold extra launch flags as a JSON array.
const path = require('node:path');
const http = require('node:http');
const fs = require('node:fs');
const { chromium } = require('playwright');

const ROOT = path.join(__dirname, '..', '..');

function launch() {
  const options = { headless: true };
  if (process.env.CHROMIUM_EXECUTABLE) {
    options.executablePath = process.env.CHROMIUM_EXECUTABLE;
  }
  if (process.env.CHROMIUM_ARGS) {
    options.args = JSON.parse(process.env.CHROMIUM_ARGS);
  }
  return chromium.launch(options);
}

function fileUrl(hash = '') {
  return 'file://' + path.join(ROOT, 'index.html') + hash;
}

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8'
};

// A static file server for the project folder, for the "served by any static server" check.
function serve() {
  const server = http.createServer((req, res) => {
    const urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    const file = path.join(ROOT, urlPath === '/' ? 'index.html' : urlPath);
    if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404);
      res.end('not found');
      return;
    }
    res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}

module.exports = { launch, fileUrl, serve, ROOT };
