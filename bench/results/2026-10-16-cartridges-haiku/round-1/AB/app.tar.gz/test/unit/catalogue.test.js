'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { records, catalogue, recordByKey } = require('./helpers');

const names = (list) => list.map((r) => r.name);

test('the list is sorted by name, ignoring case, with numbers compared by value', () => {
  const sorted = names(catalogue.sortByName(records));
  assert.ok(sorted.indexOf('7 x 64') < sorted.indexOf('8 x 57 IS'));
  assert.ok(sorted.indexOf('6,5 Creedmoor') < sorted.indexOf('7 mm Rem. Mag.'));
  assert.equal(sorted.length, 25);
});

test('search matches a published alternative name', () => {
  assert.deepEqual(names(catalogue.filterCartridges(records, '7,62 x 51', 'all')), ['308 Win.']);
});

test('search ignores case and extra spaces', () => {
  assert.deepEqual(names(catalogue.filterCartridges(records, '  CREEDMOOR ', 'all')), ['6,5 Creedmoor']);
  assert.deepEqual(names(catalogue.filterCartridges(records, '7,62   x 51', 'all')), ['308 Win.']);
});

test('an empty search lists every cartridge', () => {
  assert.equal(catalogue.filterCartridges(records, '', 'all').length, 25);
});

test('the family filter lists only that family', () => {
  assert.deepEqual(catalogue.filterCartridges(records, '', 'rimfire').map((r) => r.family), ['rimfire', 'rimfire', 'rimfire']);
  assert.equal(catalogue.filterCartridges(records, '', 'belted').length, 2);
  assert.equal(catalogue.filterCartridges(records, '', 'pistol').length, 6);
  assert.equal(catalogue.filterCartridges(records, '', 'rimless').length, 12);
  assert.equal(catalogue.filterCartridges(records, '', 'rimmed').length, 2);
});

test('the family filter and the search combine', () => {
  assert.equal(catalogue.filterCartridges(records, '308', 'rimless').length, 1);
  assert.equal(catalogue.filterCartridges(records, '308', 'rimfire').length, 0);
});

test('the count text shows the number, including zero and one', () => {
  assert.equal(catalogue.countText(0), '0 cartridges');
  assert.equal(catalogue.countText(1), '1 cartridges');
  assert.equal(catalogue.countText(25), '25 cartridges');
});

test('search finds a cartridge by name', () => {
  const found = catalogue.filterCartridges(records, 'rem. mag', 'all');
  assert.deepEqual(names(found), ['7 mm Rem. Mag.', '44 Rem. Mag.']);
  assert.equal(recordByKey(found, '223_rem'), undefined);
});
