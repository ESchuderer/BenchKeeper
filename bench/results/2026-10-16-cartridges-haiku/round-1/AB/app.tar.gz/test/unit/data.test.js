'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { records } = require('./helpers');

test('the embedded data holds the 25 supplied records', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
});

test('family counts match the brief', () => {
  const counts = {};
  records.forEach((r) => { counts[r.family] = (counts[r.family] || 0) + 1; });
  assert.deepEqual(counts, { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3 });
});

test('every <X>Tol field has its base value in the same group', () => {
  records.forEach((r) => {
    ['cartridge', 'chamber'].forEach((side) => {
      Object.entries(r[side]).forEach(([group, fields]) => {
        Object.keys(fields).forEach((field) => {
          if (/Tol$/.test(field)) {
            assert.ok(field.slice(0, -3) in fields, `${r.key}: ${side}.${group}.${field} has no base value`);
          }
        });
      });
    });
  });
});
