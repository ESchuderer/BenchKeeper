'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { records, drawing, recordByKey } = require('./helpers');

const xml = (text) => text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const rendered = new Map(records.map((r) => [r.key, drawing.render(r)]));
const labelTexts = (key) => rendered.get(key).labels.map((l) => l.text);

function overlap(a, b) {
  return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
}

function boxHitsPolyline(box, points) {
  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i], b = points[i + 1];
    const n = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 0.25));
    for (let k = 0; k <= n; k++) {
      const x = a.x + (b.x - a.x) * k / n, y = a.y + (b.y - a.y) * k / n;
      if (x >= box.x0 && x <= box.x1 && y >= box.y0 && y <= box.y1) { return true; }
    }
  }
  return false;
}

test('every record renders an SVG with the accessible name "<name> drawing" and a mm viewBox', () => {
  records.forEach((r) => {
    const out = rendered.get(r.key);
    assert.ok(out.svg.includes(`role="img" aria-label="${xml(r.name)} drawing"`), r.key);
    assert.match(out.svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/, r.key);
  });
});

test('the markup is balanced for every record', () => {
  records.forEach((r) => {
    const svg = rendered.get(r.key).svg;
    ['svg', 'g', 'text', 'tspan', 'defs', 'pattern'].forEach((tag) => {
      const opens = (svg.match(new RegExp(`<${tag}[ >]`, 'g')) || []).length;
      const closes = (svg.match(new RegExp(`</${tag}>`, 'g')) || []).length;
      assert.equal(opens, closes, `${r.key}: <${tag}>`);
    });
  });
});

test('no record omits a dimension', () => {
  records.forEach((r) => assert.deepEqual(rendered.get(r.key).omitted, [], r.key));
});

test('no two labels overlap, and no label is outside the viewBox', () => {
  records.forEach((r) => {
    const out = rendered.get(r.key);
    const vb = out.viewBox;
    out.labels.forEach((a, i) => {
      assert.ok(a.box.x0 >= vb.x && a.box.x1 <= vb.x + vb.width, `${r.key}: ${a.text} inside width`);
      assert.ok(a.box.y0 >= vb.y && a.box.y1 <= vb.y + vb.height, `${r.key}: ${a.text} inside height`);
      out.labels.forEach((b, j) => {
        if (i < j) { assert.ok(!overlap(a.box, b.box), `${r.key}: ${a.text} overlaps ${b.text}`); }
      });
    });
  });
});

test('no label overlaps the outline', () => {
  records.forEach((r) => {
    const out = rendered.get(r.key);
    out.labels.forEach((l) => {
      assert.ok(!boxHitsPolyline(l.box, out.outline), `${r.key}: ${l.text} touches the outline`);
    });
  });
});

test('mandatory dimensions are present for every record', () => {
  records.forEach((r) => {
    const texts = labelTexts(r.key).join(' | ');
    ['L3 ', 'L6 ', 'R1 ', 'R ', 'P1 '].forEach((sym) => {
      assert.ok(texts.split(' | ').some((t) => t.startsWith(sym)), `${r.key}: ${sym.trim()} dimension`);
    });
  });
});

test('optional dimensions appear only where published', () => {
  const has = (key, sym) => labelTexts(key).some((t) => t.startsWith(sym + ' '));
  assert.ok(has('308_win', 'P2') && has('308_win', 'H1') && has('308_win', 'L1') && has('308_win', 'L2') && has('308_win', 'α'));
  assert.ok(has('308_win', 'E1') && has('308_win', 'G1') && has('308_win', 'H2'));
  assert.ok(!has('9_mm_luger', 'P2') && !has('9_mm_luger', 'L1') && !has('9_mm_luger', 'α'), '9 mm Luger has no shoulder');
  assert.ok(!has('22_long_rifle', 'E1'), '22 Long Rifle has no groove');
  assert.ok(!has('22_long_rifle', 'P2'), '22 Long Rifle has no shoulder');
});

test('labels show the symbol and value, with the tolerance beside the value', () => {
  assert.ok(labelTexts('223_rem').includes('L3 44.7'));
  assert.ok(labelTexts('223_rem').includes('L1 36.52 -0.2'));
  assert.ok(labelTexts('223_rem').includes('R1 9.6'));
  assert.ok(labelTexts('223_rem').some((t) => /^α 46°$/.test(t)));
  assert.ok(labelTexts('6_5_creedmoor').includes('L3 48.77'));
});

test('the title block carries the name, the C.I.P. table, the revision and the units', () => {
  records.forEach((r) => {
    const svg = rendered.get(r.key).svg;
    assert.ok(svg.includes(`>${xml(r.name)}</text>`), `${r.key}: name`);
    assert.ok(svg.includes(`C.I.P. table ${r.tab} · revised ${r.revised}`), `${r.key}: table and revision`);
    assert.ok(svg.includes('Dimensions in mm'), `${r.key}: units`);
  });
});

test('a missing P2 is reported in the title block and the shoulder is drawn without it', () => {
  const copy = JSON.parse(JSON.stringify(recordByKey(records, '308_win')));
  delete copy.cartridge.powderChamber.P2;
  const out = drawing.render(copy);
  assert.ok(out.missing.some((m) => /P2/.test(m)));
  assert.ok(out.svg.includes('P2 missing'), 'title block names the missing value');
  assert.ok(!out.labels.some((l) => l.text.startsWith('P2 ')), 'no P2 dimension is drawn');
});

test('the printed scale is the printed drawing height (96 mm) over the drawing height in mm', () => {
  const out = rendered.get('338_lapua_mag');
  const expected = (96 / out.viewBox.height).toFixed(2) + ' : 1';
  assert.equal(out.printScale, expected);
  assert.ok(out.svg.includes('Scale ' + expected), 'title block shows the printed scale');
});

test('the section is hatched and the primer pocket is cut for centrefire cases', () => {
  const svg = rendered.get('223_rem').svg;
  assert.ok(svg.includes('fill="url(#hatch-223_rem)"'));
  assert.ok(svg.includes('class="centre-line"'));
  assert.ok(svg.includes('class="outline"'));
});

test('the viewBox covers the full length from the head face to the tip, and the full diameter', () => {
  records.forEach((r) => {
    const out = rendered.get(r.key);
    const vb = out.viewBox;
    const L6 = r.cartridge.lengths.L6;
    const R1 = r.cartridge.caseHead.R1;
    assert.ok(vb.x <= 0 && vb.x + vb.width >= L6, `${r.key}: x range covers 0..L6`);
    assert.ok(vb.y <= -R1 / 2 && vb.y + vb.height >= R1 / 2 + 1, `${r.key}: y range covers the full diameter`);
  });
});
