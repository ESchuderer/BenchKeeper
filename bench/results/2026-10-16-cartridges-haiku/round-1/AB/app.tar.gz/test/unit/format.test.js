'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { records, format, recordByKey } = require('./helpers');

test('numbers are shown as published, without a trailing ".0" or separators', () => {
  assert.equal(format.formatValue('L3', 51.18), '51.18');
  assert.equal(format.formatValue('Pmax', 4150), '4150');
  assert.equal(format.formatValue('P2', 9.0), '9');
});

test('a tolerance is shown beside its value, with its sign as published', () => {
  assert.equal(format.valueWithTolerance('L1', 39.62, -0.2), '39.62 -0.2');
  assert.equal(format.valueWithTolerance('L3', 51.18, undefined), '51.18');
});

test('angles are shown as degrees, or degrees with two-digit minutes and seconds', () => {
  assert.equal(format.formatAngle(46), '46°');
  assert.equal(format.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(format.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
});

test('symbols are field names with the listed exceptions', () => {
  assert.equal(format.symbol('eMin'), 'e min');
  assert.equal(format.symbol('r1Min'), 'r1 min');
  assert.equal(format.symbol('r1Max'), 'r1 max');
  assert.equal(format.symbol('alpha'), 'α');
  assert.equal(format.symbol('alpha1'), 'α1');
  assert.equal(format.symbol('beta'), 'β');
  assert.equal(format.symbol('delta'), 'δ');
  assert.equal(format.symbol('deltaL'), 'delta L');
  assert.equal(format.symbol('L3PlusG'), 'L3 + G');
  assert.equal(format.symbol('P2'), 'P2');
});

test('units follow the field', () => {
  assert.equal(format.unit('L3'), 'mm');
  assert.equal(format.unit('R1'), 'mm');
  assert.equal(format.unit('Pmax'), 'bar');
  assert.equal(format.unit('PK'), 'bar');
  assert.equal(format.unit('PE'), 'bar');
  assert.equal(format.unit('EE'), 'J');
  assert.equal(format.unit('M'), 'g');
  assert.equal(format.unit('Q'), 'mm²');
  assert.equal(format.unit('N'), '');
  assert.equal(format.unit('alpha'), '');
  assert.equal(format.unit('S'), 'mm');
  assert.equal(format.unit('grH2O'), 'gr H2O');
});

test('a group yields one row per field, and no row for a tolerance', () => {
  const rows = format.groupRows({ L1: 39.62, L1Tol: -0.2, L2: 45.83 });
  assert.deepEqual(rows.map((r) => r.symbol), ['L1', 'L2']);
  assert.equal(rows[0].value, '39.62 -0.2');
  assert.equal(rows[1].value, '45.83');
});

test('every record shows each of its values once, with no tolerance rows', () => {
  records.forEach((r) => {
    const expected = [];
    ['cartridge', 'chamber'].forEach((side) => {
      Object.values(r[side]).forEach((fields) => {
        Object.keys(fields).forEach((f) => {
          if (!/Tol$/.test(f)) { expected.push(f); }
        });
      });
    });
    const shown = format.recordSections(r).reduce((all, s) => all.concat(s.rows.map((row) => row.field)), []);
    assert.deepEqual(shown.sort(), expected.sort(), r.key);
    shown.forEach((f) => assert.ok(!/Tol$/.test(f), `${r.key}: ${f} has its own row`));
  });
});

test('the water capacity line gives the value and unit, or null when unpublished', () => {
  assert.equal(format.capacityText(recordByKey(records, '223_rem')), '30.5 gr H2O');
  assert.equal(format.capacityText(recordByKey(records, '7_x_64')), null);
});
