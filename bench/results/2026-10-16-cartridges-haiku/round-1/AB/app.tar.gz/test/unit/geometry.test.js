'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { records, geometry, recordByKey } = require('./helpers');

const model = (key) => geometry.buildModel(recordByKey(records, key));
const near = (a, b, tol, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg}: ${a} vs ${b}`);
const at = (points, z) => points.filter((p) => Math.abs(p.z - z) < 1e-6);

test('rim type follows the family first, then R1/P1', () => {
  assert.equal(model('6_5_creedmoor').rimType, 'rimless');
  assert.equal(model('7_x_65_r').rimType, 'rimmed');
  assert.equal(model('300_win_mag').rimType, 'belted');
  assert.equal(model('22_long_rifle').rimType, 'rimfire');
});

test('the head chamfer runs from the head face to (R1/2, f)', () => {
  const m = model('223_rem');
  const r1 = 9.6 / 2;
  const cut = Math.min(0.45 * Math.tan(35 * Math.PI / 180), 9.6 / 4);
  const face = at(m.caseOuter, 0);
  near(face[1].r, r1 - cut, 1e-9, 'chamfer start');
  const corner = at(m.caseOuter, 0.45).find((p) => Math.abs(p.r - r1) < 1e-9);
  assert.ok(corner, 'chamfer end at (R1/2, f)');
});

test('the rimfire rim edge is a half-round whose outermost point is R1/2', () => {
  const m = model('22_long_rifle');
  const outer = Math.max(...m.caseOuter.map((p) => p.r));
  near(outer, 7.06 / 2, 1e-9, 'half-round outermost point');
});

test('the extractor groove of 223 Rem. runs from R to E, with its floor at E1/2', () => {
  const m = model('223_rem');
  near(m.groove.floorZ, 1.14 + 0.76, 1e-9, 'groove floor end');
  assert.ok(m.caseOuter.some((p) => Math.abs(p.z - 1.14) < 1e-9 && Math.abs(p.r - 8.43 / 2) < 1e-9), 'groove start on floor');
  assert.ok(m.caseOuter.some((p) => Math.abs(p.z - 3.13) < 1e-9 && Math.abs(p.r - 9.58 / 2) < 1e-9), 'ramp ends at (P1/2, E)');
});

test('the belt ramp of 300 Win. Mag. runs at delta to the axis up to R3/2 and ends near z = 3.24', () => {
  const m = model('300_win_mag');
  near(m.groove.beltRampEnd, 2.21 + (6.755 - 6.035) / Math.tan(35 * Math.PI / 180), 1e-6, 'belt ramp end');
  near(m.groove.beltRampEnd, 3.24, 0.01, 'belt ramp end value');
});

test('a bottleneck case has its shoulder at alpha/2 to the axis and its neck at H2/2', () => {
  const m = model('308_win');
  // The straight shoulder is one segment between two outline points that span z = 41.
  const i = m.caseOuter.findIndex((p, k) => k < m.caseOuter.length - 1 && p.z <= 41 && m.caseOuter[k + 1].z >= 41);
  assert.ok(i >= 0, 'shoulder segment spans z = 41');
  const first = m.caseOuter[i], last = m.caseOuter[i + 1];
  const angle = Math.atan((first.r - last.r) / (last.z - first.z)) * 180 / Math.PI;
  near(angle, 40 / 2, 0.5, 'shoulder angle to axis');
  near(m.caseOuter[m.caseOuter.length - 1].r, 8.72 / 2, 1e-9, 'mouth outside radius');
  assert.equal(m.shoulder.alpha, 40);
});

test('a straight case has no shoulder and its body runs to the mouth', () => {
  const m = model('22_long_rifle');
  assert.equal(m.shoulder, null);
  assert.equal(m.straight, true);
});

test('the pointy bullet is seated 1.0·G1 below the mouth, with its cylinder ending at 0.40 of its length', () => {
  const m = model('223_rem');
  const b = m.bullet;
  near(b.zb, 44.7 - 5.7, 1e-9, 'base');
  near(b.zs, b.zb + 0.4 * (57.4 - b.zb), 1e-9, 'nose start');
  near(b.m, Math.max(0.08 * 5.7, 1.27), 1e-9, 'meplat');
});

test('the nose of a pointy bullet is tangent to the cylinder at its start and ends at the meplat on z = L6', () => {
  const m = model('308_win');
  const b = m.bullet;
  const nose = m.outline.filter((p) => p.z >= b.zs - 1e-9);
  assert.ok(Math.abs(nose[0].r - b.Rexp) < 1e-9);
  const meplat = nose.find((p) => Math.abs(p.z - 71.12) < 1e-9 && p.r > 0);
  assert.ok(meplat, 'meplat point on z = L6');
  near(meplat.r, b.m / 2, 1e-6, 'meplat radius');
  near(nose[1].r, b.Rexp, 0.03, 'tangent at nose start (drop over the first step)');
});

test('a rounded pistol bullet is seated 0.4·G1 and uses k = 0.65', () => {
  const m = model('9_mm_luger');
  near(m.bullet.zb, 19.15 - 0.4 * 9.03, 1e-9, 'pistol seat');
  near(m.bullet.k, 0.65, 1e-9, 'pistol k');
});

test('a heeled case (H2 - G1 <= 0.015) exposes the case outside diameter and seats a heel of H2 - 2·tb', () => {
  const m = model('22_long_rifle');
  assert.equal(m.bullet.heeled, true);
  near(m.bullet.Rexp, 5.72 / 2, 1e-9, 'exposed radius');
  near(m.bullet.Rseat, 5.72 / 2 - m.tb, 1e-9, 'heel radius');
});

test('the neck and body walls follow rule 8', () => {
  const m = model('223_rem');
  near(m.tn, (6.43 - 5.7) / 2, 1e-9, 'neck wall');
  near(m.tb, Math.min(Math.max(1.3 * m.tn, 0.6), 0.35 * 9.58 / 2), 1e-9, 'body wall');
  const inner = m.caseSection.filter((p) => p.z > m.w + 1e-9 && p.z < 44.7 - 1e-9);
  assert.ok(inner.length > 0);
});

test('the solid head extends to at least pocket depth + 1.5 and E + tb', () => {
  const m = model('223_rem');
  assert.ok(m.w >= 3.04 + 1.5 - 1e-9);
  assert.ok(m.w >= 3.13 + m.tb - 1e-9);
});

test('primer pockets follow the primer type; rimfire cases have none', () => {
  assert.deepEqual([model('223_rem').pocket.diameter, model('223_rem').pocket.depth], [4.45, 3.04]);
  assert.deepEqual([model('7_x_65_r').pocket.diameter, model('7_x_65_r').pocket.depth], [5.33, 3.3]);
  assert.equal(model('22_long_rifle').pocket, null);
});

test('the outline ends at the bullet tip on the axis', () => {
  records.forEach((r) => {
    const m = geometry.buildModel(r);
    const last = m.outline[m.outline.length - 1];
    assert.equal(last.r, 0, r.key);
    near(last.z, r.cartridge.lengths.L6, 1e-6, `${r.key} tip`);
  });
});

test('a missing P2 is reported and the shoulder is not drawn, never invented', () => {
  const copy = JSON.parse(JSON.stringify(recordByKey(records, '308_win')));
  delete copy.cartridge.powderChamber.P2;
  const m = geometry.buildModel(copy);
  assert.ok(m.missing.some((s) => /P2/.test(s)), 'P2 named as missing');
  assert.equal(m.straight, true);
  assert.equal(m.shoulder, null);
});

test('each record builds a complete model with no missing values or warnings', () => {
  records.forEach((r) => {
    const m = geometry.buildModel(r);
    assert.equal(m.incomplete, false, r.key);
    assert.deepEqual(m.missing, [], r.key);
    assert.deepEqual(m.warnings, [], r.key);
  });
});

test('the computed shoulder apex agrees with the published S within 0.25 mm', () => {
  records.filter((r) => r.cartridge.junctionCone && r.cartridge.junctionCone.S && r.cartridge.junctionCone.alpha !== undefined && r.cartridge.lengths.L1)
    .forEach((r) => {
      const half = geometry.toDegrees(r.cartridge.junctionCone.alpha) / 2 * Math.PI / 180;
      const apex = r.cartridge.lengths.L1 + (r.cartridge.powderChamber.P2 / 2) / Math.tan(half);
      near(apex, r.cartridge.junctionCone.S, 0.25, r.key);
    });
});
