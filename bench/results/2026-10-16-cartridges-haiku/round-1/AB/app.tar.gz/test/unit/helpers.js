'use strict';

// Loads the browser modules into Node. Each file attaches itself to globalThis.CIP and exports its namespace.
const path = require('node:path');

const JS = path.join(__dirname, '..', '..', 'js');

function load(name) {
  return require(path.join(JS, name));
}

module.exports = {
  records: load('data.js'),
  format: load('format.js'),
  catalogue: load('catalogue.js'),
  geometry: load('geometry.js'),
  drawing: load('drawing.js'),
  recordByKey(records, key) {
    return records.find((r) => r.key === key);
  }
};
