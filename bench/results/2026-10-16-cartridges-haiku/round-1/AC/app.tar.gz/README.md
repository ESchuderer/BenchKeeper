# C.I.P. cartridge reference

A static reference for 25 C.I.P. cartridges (reloaders, gunsmiths, engineers), modelled on
OpenBallistics. Open `index.html` in a browser, or serve the folder with any static server.
No build step, no runtime dependencies, no network requests.

- `data/cartridges.js`: the 25 records, one per line, as published (OpenBallistics, MIT).
- `src/format.js`: symbols, units, value and angle formatting, search.
- `src/geometry.js`: case profile, bullet nose, section walls, primer pocket (the brief's rules).
- `src/drawing.js`: inline SVG drawing, dimension and label layout.
- `src/app.js`: hash routing (`#/` list, `#/cartridge/<key>` detail), search, family filter, print.
- `styles.css`: light and dark themes, phone layout, one-page A4 print.

Tests: `npm test` (Node 22, built-in `node:test`).

The specification and plan are in `specs/001-cartridge-reference/`.
