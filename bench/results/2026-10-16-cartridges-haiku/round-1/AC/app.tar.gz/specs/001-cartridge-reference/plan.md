# Implementation Plan: C.I.P. Cartridge Reference

**Spec**: `specs/001-cartridge-reference/spec.md`

## Technical Context

**Language/Version**: Browser JavaScript (ES2020, classic scripts), HTML5, CSS3. Node.js 22 for tests only.

**Primary Dependencies**: None at runtime. Tests use `node:test` and `node:assert` (built in); no npm dev dependencies.

**Storage**: None. The records are embedded in `data/cartridges.js`.

**Testing**: `npm test` runs `node --test tests/`. Browser checks (file:// load, search, routing, print to one PDF page, screenshots) are run with headless Chromium through a scratch `playwright-core` install outside the project.

**Target Platform**: Chromium on desktop and phone (file:// and any static server).

**Project Type**: Static web app (no build step, no server code).

**Constraints**: No network requests, CDNs, web fonts, analytics or frameworks. `index.html` must work from `file://`, so no `fetch` and no `type="module"` scripts (both are blocked for file origins in Chromium).

## Constitution Check

`.specify/memory/constitution.md` is still the unfilled template, so there are no project principles to gate on. The brief's rules (no framework, no build, no network, test-first for the geometry) are followed instead.

## Project Structure

```text
index.html                 # shell: header, search, family select, #view
styles.css                 # light/dark tokens, layout, tables, print rules
data/cartridges.js         # window.CIP_CARTRIDGES = [ 25 records, one per line ]
src/format.js              # symbols, units, value and angle formatting, table sections
src/geometry.js            # profile, bullet, walls, primer pocket (pure, unit-tested)
src/drawing.js             # SVG drawing: dimension and label layout (pure, unit-tested)
src/app.js                 # hash routing, list, search, filter, detail, print button
tests/                     # node:test files, one per module
specs/001-cartridge-reference/
package.json               # "test" script only; no dependencies
```

Each `src/*.js` file attaches its API to `window.CIP` in the browser and exports it with `module.exports` under Node, so the same file is tested unchanged.

## Decisions

Where the brief leaves a choice open, these apply:

1. **Routing**: `#/` is the list, `#/cartridge/<key>` the detail view. Hash routing is the only address form that works from `file://`.
2. **Values**: `String(number)` (`4150.0` → `4150`). Angles: `40°`, `39°59'49"` with two-digit minutes and seconds. Tolerances are appended with their sign (`39.62 -0.2`).
3. **Units**: lengths and diameters mm; pressures bar; EE J; M g; Q mm²; grH2O for capacity; N and angles have no unit column text (`—`).
4. **Heeled bullet** (`H2 - G1 <= 0.015`): the exposed bullet uses diameter `H2`; the seated heel has radius `H2/2 - tb`. The neck wall is `tb` (not `tn`, which is zero for heeled bullets) so the case still has a wall.
5. **Straight case** (no alpha, L1 or L2): the brief gives no mouth length, so the inner wall blends linearly from `tb` at the body start to `tn` at the mouth. This keeps the bullet fitting the mouth.
6. **Rim type** (rule 1) is computed and reported in the drawing note. It does not change the geometry beyond the rimfire and belted cases already in the brief.
7. **Dimension layout**: axial dimensions (L1, L2, L3, L6) stack above the outline, nearest to the part for shorter lengths. R sits below the section. Diameters are vertical lines in columns beyond the tip, nearest the part for smaller radii, so no extension line crosses a dimension line; R1 is in a column left of the head. Diameter labels are rotated 90° beside their line. Any label that an extension line crosses is drawn on a paper-coloured backing, which the usual drafting text-gap convention.
8. **α**: the arc sits at the body/shoulder junction, between the axis-parallel line and the shoulder, outside the case. It therefore shows α/2 to the axis; the label gives the published α, as the brief asks.
9. **Missing values**: a feature whose inputs are missing is omitted and named in a note under the drawing.
10. **Pluralisation**: "1 cartridge", "n cartridges".
11. **Scale**: the title block carries a 10 mm scale bar, which stays correct at any print size.
12. **Print**: `@page` A4 portrait, light colours forced, one page enforced by a compact two-column table layout, footer with source and revised date.

## Testing Strategy (test first)

- `tests/format.test.js`: symbols, units, value and angle formatting, tolerance merging, section grouping.
- `tests/geometry.test.js`: rim type, chamfer, groove, belted groove, rimfire half-round, bullet `s`/`k`/`m` for each nose, heeled case, walls, `w`, primer pocket, missing-value notes.
- `tests/drawing.test.js`: SVG structure, accessible name, dimension presence, and **no label overlaps with other labels or the outline for all 25 records**.
- `tests/data.test.js`: 25 records, unique keys, every record accepted by the geometry without throwing.
- Browser checks (scratch, not committed): file:// load, zero network requests, search, family filter, routing and reload, dark mode, print to PDF with one page, screenshots at phone and A4 widths.
