# Feature Specification: C.I.P. Cartridge Reference

**Feature Directory**: `specs/001-cartridge-reference`

**Status**: Draft

**Input**: User description: "Static web app: a reference database of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on OpenBallistics. Data is the 25 JSONL records in the brief only."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Find a cartridge (Priority: P1)

A reader opens the app and sees every cartridge with its name, family and case length L3. They type part of any name or alternative name into "Search" (for example `7,62 x 51` finds `308 Win.`), or pick a family, and the list narrows as they type. A count line says how many cartridges are listed.

**Why this priority**: Without a list and search, nothing else is reachable.

**Independent Test**: Open the start page, type `7,62 x 51`, and confirm only `308 Win.` is listed; choose family `pistol` and confirm six cartridges are listed (9 mm Luger, 45 Auto, 40 S.& W., 38 Special, 357 Magnum, 44 Rem. Mag.) with the count "6 cartridges".

**Acceptance Scenarios**:

1. **Given** the start page, **When** the page loads, **Then** 25 names are listed, each a link whose text is exactly the record's `name`, with family and `L3`.
2. **Given** the start page, **When** the user types `7,62 x 51`, **Then** only `308 Win.` is listed and the count reads "1 cartridge".
3. **Given** the start page, **When** the user selects family `rimfire`, **Then** only the rimfire cartridges are listed.

### User Story 2 - Read a cartridge's data (Priority: P2)

A reader opens a cartridge. The detail view shows the heading, alternative names, family, category, primer type, C.I.P. table, country, dates, pressure method and the published water capacity with its source link. Below that, every cartridge value and every chamber value appears in tables grouped by section, with columns Symbol, Value and Unit. Tolerances sit beside their value.

**Why this priority**: This is the reference content itself.

**Independent Test**: Open `308 Win.`; confirm the water capacity reads 56.0 grH2O with its kwk link, and that `L1` shows `39.62 -0.2 mm`.

**Acceptance Scenarios**:

1. **Given** a detail view, **When** it renders, **Then** every field in the record appears exactly once, except tolerance fields, which appear next to their value.
2. **Given** an angle stored as `{degrees, minutes, seconds}`, **When** it renders, **Then** it reads `39°59'49"` style; a plain number reads `40°`.
3. **Given** an unknown address such as `#/cartridge/nope`, **When** the page loads, **Then** a "not found" message and a link back to the list appear.

### User Story 3 - See the cartridge drawing (Priority: P3)

A reader sees a true-to-scale 2D drawing: the outside view above the axis, the section below with cut walls hatched, a centre line, dimension lines with labels for each required dimension, and a title block. The drawing scales to the phone width.

**Why this priority**: It is the main technical visual, but the tables already give every value.

**Independent Test**: Open any cartridge; confirm an SVG with accessible name `<name> drawing` exists and that no two labels overlap each other or the outline (checked automatically for all 25 records).

**Acceptance Scenarios**:

1. **Given** a rimless bottleneck cartridge, **When** the drawing renders, **Then** it shows the case, shoulder, neck, bullet with the nose shape from the record, and dimensions for L3, L6, R1, R, P1 and each published of P2, H1, H2, G1, L1, L2, E1 and α.
2. **Given** a value needed by a rule is missing, **When** the drawing renders, **Then** that feature is left out and the note under the drawing names the missing value.

### User Story 4 - Print one page (Priority: P4)

A reader presses "Print" and gets one black-on-white A4 portrait page: header with the name, the drawing at full width, the tables, and a footer with the source (C.I.P. TDCC, revised date). Navigation, search and buttons are not printed.

**Why this priority**: Reference users keep paper copies.

**Independent Test**: Print the detail view of the longest record (`9,3 x 74 R` or `338 Lapua Mag.`) to PDF in headless Chromium; the result has exactly one page.

### Edge Cases

- A search with no hits shows "0 cartridges" and an empty list.
- A cartridge with no shoulder (pistol, rimfire, `22 Win. Mag. R.F.`) draws a straight case with no shoulder or neck section.
- A rimfire rim is drawn as a half-round, not a square corner.
- A heeled bullet (`22 Long Rifle`, `H2 - G1 <= 0.015`) draws its exposed bullet at the case outside diameter.
- A published value that the drawing rules need but that is absent (e.g. `r1Min` for `17 HMR`) removes only that feature and is named in the drawing note.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The start page MUST list all 25 records with name (a link to the detail view), family and L3.
- **FR-002**: The "Search" field MUST filter by name and alternative names as the user types, case-insensitively, and treat `,` and `.` as equal.
- **FR-003**: The "Family" select MUST offer All, rimless, rimmed, belted, pistol, rimfire and filter by family.
- **FR-004**: The text "<n> cartridges" MUST show the number listed (singular "1 cartridge").
- **FR-005**: Each detail view MUST have its own hash address (`#/cartridge/<key>`) that survives reload and can be bookmarked; an unknown key MUST show a not-found message.
- **FR-006**: Detail view MUST show heading, alternative names, family, category, primer type, C.I.P. table, country, published and revised dates, pressure method, water capacity with source link.
- **FR-007**: Values MUST be shown as published with `.` as decimal point and no thousands separator; names as published.
- **FR-008**: A `<X>Tol` field MUST be shown next to X's value, never as its own row.
- **FR-009**: Symbols MUST use the field name except the mappings in the brief (`eMin` → "e min", `alpha` → "α", …).
- **FR-010**: Angles MUST show as `40°` or `39°59'49"`; minutes and seconds are zero-padded to two digits.
- **FR-011**: Cartridge and chamber values MUST be tables grouped by section with columns Symbol, Value, Unit.
- **FR-012**: The drawing MUST follow the geometry rules in the brief, 1 SVG unit = 1 mm, head on the left, upper half outside view, lower half section, accessible name `<name> drawing`.
- **FR-013**: Dimension labels MUST NOT overlap each other or the outline (automatically verified for all 25 records).
- **FR-014**: The drawing MUST have a title block with name, C.I.P. table, revision date, "Dimensions in mm" and a scale bar.
- **FR-015**: Print MUST produce one A4 portrait page with header, drawing, tables and footer, and no navigation/search/buttons.
- **FR-016**: Light and dark themes MUST follow `prefers-color-scheme`; print is always light.
- **FR-017**: The app MUST run from `file://` in Chromium and from any static server, with no network requests, CDNs, web fonts, or runtime dependencies.

### Key Entities

- **Cartridge record**: one JSON object from the brief; `key` is the URL identifier.
- **Profile**: the outer half-profile and bullet derived from a record by the geometry rules.
- **Drawing**: SVG built from a profile plus dimension and label layout.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: All 25 cartridges are listed on the start page and each opens its detail view by link.
- **SC-002**: Searching `7,62 x 51` returns exactly `308 Win.`.
- **SC-003**: For every record, the drawing has no label-label or label-outline overlap (automated test).
- **SC-004**: Printing any detail view produces exactly one page in headless Chromium.
- **SC-005**: The app loads and works with no network access.

## Assumptions

- The 25 records in the brief are the only data; they are embedded in `data/cartridges.js` because `fetch` does not work from `file://`.
- The C.I.P. constitution template in `.specify/memory` is unfilled, so no project principles are enforced beyond the brief's rules.
- Where the brief leaves a rule open, the choices recorded in `plan.md` ("Decisions") apply.
- Rimfire and belted rules follow the family; other rim types follow the R1/P1 ratio.
