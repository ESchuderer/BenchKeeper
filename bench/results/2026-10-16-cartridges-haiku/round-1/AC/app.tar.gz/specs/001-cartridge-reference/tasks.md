# Tasks: C.I.P. Cartridge Reference

**Input**: `spec.md`, `plan.md`. Tests were written before the code they cover (red, then green).

## Phase 1: Setup

- [X] T001 Create `package.json` with the `test` script only (no dependencies)
- [X] T002 Embed the 25 records verbatim in `data/cartridges.js` (classic script, works from file://)
- [X] T003 Test helpers that load the browser-style sources into Node (`tests/helpers.js`)

## Phase 2: Format (User Story 2)

- [X] T004 Tests for symbols, units, values, angles, tolerances, sections, search, count label (`tests/format.test.js`)
- [X] T005 Implement `src/format.js`

## Phase 3: Geometry (User Story 3)

- [X] T006 Tests for rim type, head chamfer, groove, belted groove, rimfire half-round, bullet s/k/m per nose, heeled case, walls, w, primer pocket, missing-value notes (`tests/geometry.test.js`)
- [X] T007 Implement `src/geometry.js`

## Phase 4: Drawing (User Story 3)

- [X] T008 Tests for required and published dimension labels, label/label and label/outline overlap for all 25 records, view box, inline SVG attributes, title block, notes (`tests/drawing.test.js`)
- [X] T009 Implement `src/drawing.js` (lanes, columns, α arc, title block, knock-out labels)
- [X] T010 Enlarge label font to 3 mm for phone legibility; re-run overlap tests

## Phase 5: Application (User Stories 1 and 2)

- [X] T011 Implement `index.html`, `src/app.js` (list, search, family filter, count, detail, not-found, hash routing, print button)
- [X] T012 Implement `styles.css` (light and dark, phone layout, A4 print)

## Phase 6: Verification (User Story 4 and all)

- [X] T013 Headless Chromium from file://: 25 rows, link text equals name, search `7,62 x 51` → `308 Win.`, family filters, detail by link, reload keeps view, not-found, zero network requests, no console errors
- [X] T014 Print to PDF: every record prints to exactly one A4 page (print footer kept in flow; four-column tables)
- [X] T015 Phone width (390 px): no horizontal overflow on any detail view

## Polish

- [X] T016 README and this task list

## Notes

- Decisions where the brief is open are recorded in `plan.md` under "Decisions".
- The constitution in `.specify/memory/constitution.md` was not filled in; no gate was applied.
