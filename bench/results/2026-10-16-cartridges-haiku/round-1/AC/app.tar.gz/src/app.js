(function () {
  'use strict';

  // Hash routing: #/ lists the cartridges, #/cartridge/<key> shows one. Works from file://.
  const { format, drawing } = window.CIP;
  const records = window.CIP_CARTRIDGES;
  const byKey = new Map(records.map((r) => [r.key, r]));
  const view = document.getElementById('view');

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    for (const [name, value] of Object.entries(attrs || {})) {
      if (value === undefined || value === null || value === false) continue;
      if (name === 'className') node.className = value;
      else if (name.startsWith('on')) node.addEventListener(name.slice(2), value);
      else node.setAttribute(name, value === true ? '' : value);
    }
    for (const child of [].concat(children || [])) {
      if (child === undefined || child === null || child === false) continue;
      node.append(child instanceof Node ? child : document.createTextNode(String(child)));
    }
    return node;
  }

  const link = (href, text) => el('a', { href }, text);
  const cartridgeHref = (record) => `#/cartridge/${encodeURIComponent(record.key)}`;

  function labelled(text, control) {
    return el('div', { className: 'field' }, [el('label', { for: control.id }, text), control]);
  }

  function renderList() {
    document.title = 'C.I.P. cartridges';
    const search = el('input', { type: 'search', id: 'search', autocomplete: 'off', spellcheck: 'false' });
    const family = el('select', { id: 'family' }, [
      el('option', { value: '' }, 'All'),
      ...format.FAMILIES.map((f) => el('option', { value: f }, f)),
    ]);
    const count = el('p', { className: 'count', 'aria-live': 'polite' });
    const list = el('ul', { className: 'cartridge-list' });

    const update = () => {
      const matches = records.filter((r) => (family.value === '' || r.family === family.value)
        && format.matchesSearch(r, search.value));
      list.replaceChildren(...matches.map((r) => el('li', { className: 'cartridge-row' }, [
        el('a', { className: 'cartridge-name', href: cartridgeHref(r) }, r.name),
        el('span', { className: 'cartridge-family' }, r.family),
        el('span', { className: 'cartridge-l3' }, `L3 ${format.fieldText(r.cartridge, 'L3')} mm`),
      ])));
      count.textContent = format.countLabel(matches.length);
    };
    search.addEventListener('input', update);
    family.addEventListener('change', update);

    view.replaceChildren(
      el('h1', {}, 'Cartridges'),
      el('div', { className: 'filters' }, [labelled('Search', search), labelled('Family', family)]),
      count,
      list,
    );
    update();
  }

  function valueRows(section) {
    return section.rows.map((row) => el('tr', {}, [
      el('th', { scope: 'row' }, row.symbol),
      el('td', { className: 'value' }, row.value),
      el('td', { className: 'unit' }, row.unit),
    ]));
  }

  function valueTables(groups) {
    return groups.map((group) => el('section', { className: 'section' }, [
      el('h3', {}, group.title),
      el('table', { className: 'values' }, [
        el('thead', {}, el('tr', {}, [el('th', { scope: 'col' }, 'Symbol'), el('th', { scope: 'col' }, 'Value'), el('th', { scope: 'col' }, 'Unit')])),
        el('tbody', {}, valueRows(group)),
      ]),
    ]));
  }

  function capacityCell(record) {
    const capacity = record.annotations.publishedCapacity;
    if (!capacity) return 'not published';
    return [
      format.formatCapacity(capacity),
      ' · source: ',
      el('a', { href: capacity.url, rel: 'noopener' }, capacity.source),
      capacity.note ? el('span', { className: 'note' }, ` — ${capacity.note}`) : null,
    ];
  }

  function renderDetail(record) {
    document.title = `${record.name} · C.I.P. cartridges`;
    const meta = [
      ['Alternative names', (record.alternativeNames || []).join(', ') || '—'],
      ['Family', record.family],
      ['Category', record.annotations.category],
      ['Primer type', record.annotations.primerType],
      ['C.I.P. table', record.tab],
      ['Country', record.country],
      ['Published', record.published],
      ['Revised', record.revised],
      ['Pressure method', record.pressureMethod],
      ['Water capacity', capacityCell(record)],
    ];

    let figure;
    let notes;
    try {
      const lay = drawing.layout(record);
      figure = el('figure', { className: 'drawing-figure' });
      figure.innerHTML = drawing.svg(record);
      notes = el('ul', { className: 'drawing-notes' }, [...lay.info, ...lay.notes].map((n) => el('li', {}, n)));
    } catch (error) {
      figure = el('p', { className: 'error' }, `The drawing could not be built: ${error.message}`);
      notes = null;
    }

    const sides = format.sectionsOf(record);
    view.replaceChildren(
      el('nav', { className: 'toolbar no-print' }, [
        link('#/', 'All cartridges'),
        el('button', { type: 'button', className: 'print-button', onclick: () => window.print() }, 'Print'),
      ]),
      el('h1', { className: 'detail-title' }, record.name),
      el('dl', { className: 'meta' }, meta.flatMap(([term, value]) => [
        el('dt', {}, term),
        el('dd', {}, value),
      ])),
      figure,
      notes,
      el('div', { className: 'values' }, [
        el('h2', { className: 'side-title' }, 'Cartridge'),
        ...valueTables(sides.cartridge),
        el('h2', { className: 'side-title' }, 'Chamber'),
        ...valueTables(sides.chamber),
      ]),
      el('footer', { className: 'print-footer' }, `Source: C.I.P. TDCC, revised ${record.revised}`),
    );
  }

  function renderNotFound(key) {
    document.title = 'Not found · C.I.P. cartridges';
    view.replaceChildren(
      el('h1', {}, 'Cartridge not found'),
      el('p', {}, `No cartridge has the address #/cartridge/${key}.`),
      link('#/', 'All cartridges'),
    );
  }

  function route() {
    const match = /^#\/cartridge\/(.+)$/.exec(location.hash);
    if (!match) {
      renderList();
      return;
    }
    const key = decodeURIComponent(match[1]);
    const record = byKey.get(key);
    if (record) renderDetail(record);
    else renderNotFound(key);
  }

  window.addEventListener('hashchange', route);
  route();
})();
