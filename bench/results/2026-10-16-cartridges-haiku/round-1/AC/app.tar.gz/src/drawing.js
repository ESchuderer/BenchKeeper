(function (root) {
  'use strict';

  // Inline SVG drawing. One SVG user unit is 1 mm, the axis is horizontal and the head is on the
  // left. Upper half: outside view (y = -r). Lower half: section (y = +r), cut walls hatched.
  // Dimensions: axial lengths stack above the outline (lanes); R sits below the section; diameters
  // are vertical lines in columns beyond the tip, with R1 in a column left of the head; α is an arc
  // at the shoulder. All coordinates here are SVG {x, y} with x = z.

  const deps = () => (typeof module !== 'undefined' && module.exports
    ? { geometry: require('./geometry.js'), format: require('./format.js') }
    : { geometry: root.CIP.geometry, format: root.CIP.format });

  const FONT = 3.0;
  const GLYPH = 0.6;
  const ARROW_LEN = 1.8;
  const ARROW_HALF = 0.6;
  const GAP = 0.6;
  const OVERSHOOT = 0.8;
  const LANE_STEP = 4.4;
  const LANE_OFFSET = 3.0;
  const COL_GAP = 3.5;
  const COL_STEP = 5.0;
  const LEFT_COL_X = -3.5;
  const ALPHA_RADIUS = 4;
  const TB_WIDTH = 66;
  const TB_HEIGHT = 14;
  const ARC_STEPS = 8;

  const UP = { x: 0, y: -1 };
  const DOWN = { x: 0, y: 1 };
  const LEFT = { x: -1, y: 0 };
  const RIGHT = { x: 1, y: 0 };

  const escapeXml = (text) => String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

  const num = (value) => Number(value.toFixed(3));

  // Text box of a label. Rotated labels read upwards; their ascent points left.
  function labelBox(text, x, y, anchor, rotated) {
    const width = text.length * GLYPH * FONT;
    if (rotated) {
      return { x0: x - 0.75 * FONT, x1: x + 0.25 * FONT, y0: y - width / 2, y1: y + width / 2 };
    }
    let x0 = x;
    if (anchor === 'middle') x0 = x - width / 2;
    if (anchor === 'end') x0 = x - width;
    return { x0, x1: x0 + width, y0: y - 0.75 * FONT, y1: y + 0.25 * FONT };
  }

  // Filled arrowhead with its tip at `tip`, pointing along `outward` (away from the dimension line).
  function arrowAt(tip, outward) {
    const perp = { x: -outward.y, y: outward.x };
    const base = { x: tip.x - outward.x * ARROW_LEN, y: tip.y - outward.y * ARROW_LEN };
    return [
      { x: tip.x, y: tip.y },
      { x: base.x + perp.x * ARROW_HALF, y: base.y + perp.y * ARROW_HALF },
      { x: base.x - perp.x * ARROW_HALF, y: base.y - perp.y * ARROW_HALF },
    ];
  }

  const valueOf = (record, field) => deps().format.fieldText(record.cartridge, field);

  const pathPoints = (points) => points.map((q) => ({ x: q.z, y: q.r }));
  const mirrorPoints = (points) => points.map((q) => ({ x: q.z, y: -q.r }));

  function layout(record) {
    const { geometry, format } = deps();
    const p = geometry.profile(record);
    const V = p.values;
    const bullet = p.bullet;
    const R1h = V.R1 / 2;
    const labels = [];
    const lines = [];
    const arrows = [];
    const info = [`Rim: ${p.rim}`];
    if (p.heeled) info.push('Heeled bullet: exposed diameter is H2, the heel is H2 − 2 tb');
    info.push(`Bullet nose: ${record.annotations.defaultBulletShape}`);

    const addLabel = (symbol, value, x, y, anchor, rotated) => {
      const text = `${format.symbolFor(symbol)} ${value}`;
      labels.push({ symbol, text, x: num(x), y: num(y), anchor, rotated, box: labelBox(text, x, y, anchor, rotated) });
    };
    const dimLine = (a, b) => lines.push({ x1: a.x, y1: a.y, x2: b.x, y2: b.y, cls: 'dim' });
    const extLine = (a, b) => lines.push({ x1: a.x, y1: a.y, x2: b.x, y2: b.y, cls: 'ext' });
    const arrowsAt = (a, outA, b, outB) => arrows.push(arrowAt(a, outA), arrowAt(b, outB));

    const rAt = (z) => geometry.radiusAt(p.outer, z);
    const tipR = bullet ? bullet.nose[bullet.nose.length - 1].r : 0;

    // Axial dimensions above the outline, one lane each, shorter lengths nearest the part.
    const axial = [];
    if (V.L1 !== undefined) axial.push({ field: 'L1', z: V.L1, r: rAt(V.L1) });
    if (V.L2 !== undefined) axial.push({ field: 'L2', z: V.L2, r: rAt(V.L2) });
    axial.push({ field: 'L3', z: V.L3, r: V.H2 / 2 });
    axial.push({ field: 'L6', z: V.L6, r: tipR });
    const originR = p.outer[1].r;
    axial.forEach((dim, k) => {
      const laneY = -(R1h + LANE_OFFSET + k * LANE_STEP);
      extLine({ x: 0, y: -(originR + GAP) }, { x: 0, y: laneY - OVERSHOOT });
      extLine({ x: dim.z, y: -(dim.r + GAP) }, { x: dim.z, y: laneY - OVERSHOOT });
      dimLine({ x: 0, y: laneY }, { x: dim.z, y: laneY });
      arrowsAt({ x: 0, y: laneY }, LEFT, { x: dim.z, y: laneY }, RIGHT);
      addLabel(dim.field, valueOf(record, dim.field), dim.z / 2, laneY - 0.9, 'middle', false);
    });

    // R: below the section, from the head face to the rim corner.
    const rLaneY = R1h + LANE_OFFSET;
    extLine({ x: 0, y: originR + GAP }, { x: 0, y: rLaneY + OVERSHOOT });
    extLine({ x: V.R, y: R1h + GAP }, { x: V.R, y: rLaneY + OVERSHOOT });
    dimLine({ x: 0, y: rLaneY }, { x: V.R, y: rLaneY });
    arrowsAt({ x: 0, y: rLaneY }, LEFT, { x: V.R, y: rLaneY }, RIGHT);
    addLabel('R', valueOf(record, 'R'), V.R / 2, rLaneY + 3.1, 'middle', false);

    // Diameters: columns beyond the tip, nearest the part for the smaller radii.
    const diameters = [{ field: 'P1', r: V.P1 / 2, z: p.zBody }];
    if (V.P2 !== undefined && V.L1 !== undefined) diameters.push({ field: 'P2', r: V.P2 / 2, z: V.L1 });
    if (V.H1 !== undefined && V.L2 !== undefined) diameters.push({ field: 'H1', r: V.H1 / 2, z: V.L2 });
    diameters.push({ field: 'H2', r: V.H2 / 2, z: V.L3 });
    if (bullet) diameters.push({ field: 'G1', r: bullet.Rn, z: bullet.zs });
    if (p.groove) diameters.push({ field: 'E1', r: V.E1 / 2, z: V.R + p.groove.eMin / 2 });
    diameters.sort((a, b) => a.r - b.r);
    diameters.forEach((dim, j) => {
      const x = V.L6 + COL_GAP + j * COL_STEP;
      dimLine({ x, y: -dim.r }, { x, y: dim.r });
      extLine({ x: dim.z + GAP, y: -dim.r }, { x: x + OVERSHOOT, y: -dim.r });
      extLine({ x: dim.z + GAP, y: dim.r }, { x: x + OVERSHOOT, y: dim.r });
      arrowsAt({ x, y: -dim.r }, UP, { x, y: dim.r }, DOWN);
      addLabel(dim.field, valueOf(record, dim.field), x + 2.5, 0, 'middle', true);
    });
    const leftX = LEFT_COL_X;
    extLine({ x: -GAP, y: -R1h }, { x: leftX - OVERSHOOT, y: -R1h });
    extLine({ x: -GAP, y: R1h }, { x: leftX - OVERSHOOT, y: R1h });
    dimLine({ x: leftX, y: -R1h }, { x: leftX, y: R1h });
    arrowsAt({ x: leftX, y: -R1h }, UP, { x: leftX, y: R1h }, DOWN);
    addLabel('R1', valueOf(record, 'R1'), leftX - 1.2, 0, 'middle', true);

    // α: arc at the body/shoulder junction, from the axis-parallel line to the shoulder.
    if (p.shoulder && V.alpha !== undefined) {
      const jx = p.shoulder.L1;
      const jy = -p.shoulder.P2 / 2;
      const theta = Math.atan2(p.shoulder.P2 / 2 - p.shoulder.H1 / 2, p.shoulder.L2 - p.shoulder.L1);
      const arc = [];
      for (let i = 0; i <= ARC_STEPS; i += 1) {
        const a = (theta * i) / ARC_STEPS;
        arc.push({ x: jx + ALPHA_RADIUS * Math.cos(a), y: jy + ALPHA_RADIUS * Math.sin(a) });
      }
      for (let i = 1; i <= ARC_STEPS; i += 1) dimLine(arc[i - 1], arc[i]);
      arrowsAt(arc[0], UP, arc[ARC_STEPS], { x: -Math.sin(theta), y: Math.cos(theta) });
      addLabel('alpha', valueOf(record, 'alpha'), jx + ALPHA_RADIUS + 0.8, jy - 1.5, 'start', false);
    }

    // Outlines in SVG coordinates: upper = outside view, bullet = section of the bullet, cut = case section.
    const outlines = {
      upper: mirrorPoints(p.outer.concat(bullet ? bullet.exposed : [])),
      bullet: bullet ? pathPoints(bullet.full) : [],
      cut: pathPoints(p.cut),
    };

    const top = rLaneY + 5.0;
    const titleBlock = { x: 0, y: top, w: TB_WIDTH, h: TB_HEIGHT };
    const centre = { x1: -2, y1: 0, x2: V.L6 + 0.5, y2: 0 };

    // View box from everything drawn, plus a margin. Whole millimetres.
    const xs = [];
    const ys = [];
    const grow = (x, y) => { xs.push(x); ys.push(y); };
    labels.forEach((l) => { grow(l.box.x0, l.box.y0); grow(l.box.x1, l.box.y1); });
    lines.forEach((l) => { grow(l.x1, l.y1); grow(l.x2, l.y2); });
    arrows.forEach((poly) => poly.forEach((q) => grow(q.x, q.y)));
    [outlines.upper, outlines.bullet, outlines.cut].forEach((poly) => poly.forEach((q) => grow(q.x, q.y)));
    grow(titleBlock.x, titleBlock.y);
    grow(titleBlock.x + titleBlock.w, titleBlock.y + titleBlock.h);
    const margin = 1.5;
    const vx = Math.floor(Math.min(...xs) - margin);
    const vy = Math.floor(Math.min(...ys) - margin);
    const viewBox = {
      x: vx,
      y: vy,
      w: Math.ceil(Math.max(...xs) + margin) - vx,
      h: Math.ceil(Math.max(...ys) + margin) - vy,
    };

    return {
      key: record.key,
      name: record.name,
      profile: p,
      viewBox,
      labels,
      lines,
      arrows,
      outlines,
      centre,
      titleBlock,
      notes: p.notes.slice(),
      info,
    };
  }

  // Overlap checks: label/label, label/outline and label/title block. Used by the tests.
  function overlapProblems(lay) {
    const problems = [];
    const overlaps = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
    const tb = lay.titleBlock;
    const tbBox = { x0: tb.x, y0: tb.y, x1: tb.x + tb.w, y1: tb.y + tb.h };
    const outlineSegments = [lay.outlines.upper, lay.outlines.bullet, lay.outlines.cut];
    lay.labels.forEach((a, i) => {
      lay.labels.forEach((b, j) => {
        if (j > i && overlaps(a.box, b.box)) problems.push(`label ${a.text} / ${b.text}`);
      });
      if (overlaps(a.box, tbBox)) problems.push(`label ${a.text} / title block`);
      outlineSegments.forEach((poly) => {
        for (let k = 1; k < poly.length; k += 1) {
          const s = poly[k - 1];
          const e = poly[k];
          const steps = Math.max(1, Math.ceil(Math.hypot(e.x - s.x, e.y - s.y) / 0.05));
          for (let t = 0; t <= steps; t += 1) {
            const x = s.x + ((e.x - s.x) * t) / steps;
            const y = s.y + ((e.y - s.y) * t) / steps;
            if (x > a.box.x0 - 0.2 && x < a.box.x1 + 0.2 && y > a.box.y0 - 0.2 && y < a.box.y1 + 0.2) {
              problems.push(`label ${a.text} / outline`);
              return;
            }
          }
        }
      });
    });
    return [...new Set(problems)];
  }

  const pathOf = (points, closed) => {
    const body = points.map((q, i) => `${i === 0 ? 'M' : 'L'}${num(q.x)} ${num(q.y)}`).join(' ');
    return closed ? `${body} Z` : body;
  };

  function svg(record) {
    const lay = layout(record);
    const vb = lay.viewBox;
    const tb = lay.titleBlock;
    const name = escapeXml(record.name);
    const hatch = `hatch-${record.key}`;
    const row = (dy) => num(tb.y + dy);
    const parts = [];
    parts.push(`<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="${vb.x} ${vb.y} ${vb.w} ${vb.h}" role="img" aria-label="${name} drawing">`);
    parts.push(`<defs><pattern id="${hatch}" patternUnits="userSpaceOnUse" width="1.5" height="1.5" patternTransform="rotate(45)"><line class="hatch" x1="0" y1="0" x2="0" y2="1.5"/></pattern></defs>`);
    const c = lay.centre;
    parts.push(`<line class="centre" x1="${c.x1}" y1="${c.y1}" x2="${c.x2}" y2="${c.y2}" stroke-dasharray="6 1.5 1 1.5"/>`);
    parts.push(`<path class="cut" d="${pathOf(lay.outlines.cut, true)}" fill="url(#${hatch})"/>`);
    if (lay.outlines.bullet.length) parts.push(`<path class="bullet-section" d="${pathOf(lay.outlines.bullet, false)}"/>`);
    parts.push(`<path class="outline" d="${pathOf(lay.outlines.upper, false)}"/>`);
    parts.push('<g class="dims">');
    for (const l of lay.lines) {
      parts.push(`<line class="${l.cls || 'ext'}" x1="${num(l.x1)}" y1="${num(l.y1)}" x2="${num(l.x2)}" y2="${num(l.y2)}"/>`);
    }
    parts.push('</g>');
    parts.push('<g class="arrows">');
    for (const poly of lay.arrows) {
      parts.push(`<polygon points="${poly.map((q) => `${num(q.x)},${num(q.y)}`).join(' ')}"/>`);
    }
    parts.push('</g>');
    parts.push('<g class="labels">');
    for (const l of lay.labels) {
      const b = l.box;
      parts.push(`<rect class="knock" x="${num(b.x0 - 0.3)}" y="${num(b.y0 - 0.3)}" width="${num(b.x1 - b.x0 + 0.6)}" height="${num(b.y1 - b.y0 + 0.6)}"/>`);
      const transform = l.rotated ? ` transform="rotate(-90 ${l.x} ${l.y})"` : '';
      parts.push(`<text class="label" x="${l.x}" y="${l.y}" text-anchor="${l.anchor}"${transform}>${escapeXml(l.text)}</text>`);
    }
    parts.push('</g>');
    parts.push('<g class="titleblock">');
    parts.push(`<rect class="tb" x="${tb.x}" y="${num(tb.y)}" width="${tb.w}" height="${tb.h}"/>`);
    parts.push(`<text class="tb-name" x="${tb.x + 2}" y="${row(4.6)}">${name}</text>`);
    parts.push(`<text class="tb-text" x="${tb.x + 2}" y="${row(8.4)}">C.I.P. table ${escapeXml(record.tab)}</text>`);
    parts.push(`<text class="tb-text" x="${tb.x + 2}" y="${row(11.8)}">Revised ${escapeXml(record.revised)}</text>`);
    parts.push(`<text class="tb-text" x="${tb.x + 36}" y="${row(8.4)}">Dimensions in mm</text>`);
    parts.push(`<text class="tb-text" x="${tb.x + 36}" y="${row(11.8)}">Scale</text>`);
    parts.push(`<line class="scalebar" x1="${tb.x + 44}" y1="${row(11.2)}" x2="${tb.x + 54}" y2="${row(11.2)}"/>`);
    parts.push(`<line class="scalebar" x1="${tb.x + 44}" y1="${row(10.4)}" x2="${tb.x + 44}" y2="${row(12.0)}"/>`);
    parts.push(`<line class="scalebar" x1="${tb.x + 54}" y1="${row(10.4)}" x2="${tb.x + 54}" y2="${row(12.0)}"/>`);
    parts.push(`<text class="tb-text" x="${tb.x + 55.5}" y="${row(11.8)}">10 mm</text>`);
    parts.push('</g>');
    parts.push('</svg>');
    return parts.join('');
  }

  const api = { layout, svg, overlapProblems, labelBox, escapeXml };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = Object.assign(root.CIP || {}, { drawing: api });
  }
})(typeof window !== 'undefined' ? window : globalThis);
