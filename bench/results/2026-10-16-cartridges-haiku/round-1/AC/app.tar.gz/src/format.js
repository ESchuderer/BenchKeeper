(function (root) {
  'use strict';

  // Symbols: the field name, except where the brief maps it.
  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };

  // Angles are shown with a degree sign, from a number or {degrees, minutes, seconds}.
  const ANGLE_FIELDS = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const PRESSURE_UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g' };
  const COUNT_FIELDS = new Set(['N']);

  const SECTION_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling',
  };

  const SECTION_ORDER = {
    cartridge: ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile'],
    chamber: ['barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling'],
  };

  const DASH = '—';

  function symbolFor(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unitFor(field) {
    if (ANGLE_FIELDS.has(field) || COUNT_FIELDS.has(field)) return DASH;
    if (Object.prototype.hasOwnProperty.call(PRESSURE_UNITS, field)) return PRESSURE_UNITS[field];
    if (field === 'Q') return 'mm²';
    return 'mm';
  }

  function formatNumber(value) {
    return String(value);
  }

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  function formatAngle(value) {
    if (typeof value === 'number') return `${formatNumber(value)}°`;
    return `${formatNumber(value.degrees)}°${pad2(value.minutes)}'${pad2(value.seconds)}"`;
  }

  function isAngleValue(value) {
    return typeof value === 'object' && value !== null && 'degrees' in value;
  }

  function formatValue(field, value) {
    if (ANGLE_FIELDS.has(field) || isAngleValue(value)) return formatAngle(value);
    return formatNumber(value);
  }

  function formatTolerance(tol) {
    return `${tol > 0 ? '+' : ''}${formatNumber(tol)}`;
  }

  // Every published leaf of one side ("cartridge" or "chamber"), tolerances included.
  function publishedLeaves(side) {
    const leaves = [];
    for (const [section, fields] of Object.entries(side)) {
      for (const [field, value] of Object.entries(fields)) {
        leaves.push({ section, field, value });
      }
    }
    return leaves;
  }

  function sectionsOf(record) {
    const result = {};
    for (const side of ['cartridge', 'chamber']) {
      const sides = record[side];
      const groups = [];
      for (const sectionKey of SECTION_ORDER[side]) {
        const fields = sides[sectionKey];
        if (!fields) continue;
        const rows = [];
        for (const [field, value] of Object.entries(fields)) {
          if (/Tol$/.test(field)) continue;
          const tolKey = `${field}Tol`;
          let text = formatValue(field, value);
          if (Object.prototype.hasOwnProperty.call(fields, tolKey)) {
            text = `${text} ${formatTolerance(fields[tolKey])}`;
          }
          rows.push({ symbol: symbolFor(field), value: text, unit: unitFor(field) });
        }
        if (rows.length) groups.push({ title: SECTION_TITLES[sectionKey], rows });
      }
      result[side] = groups;
    }
    return result;
  }

  // A field's text with its tolerance, searched through the sections of one side.
  function fieldText(side, field) {
    for (const section of Object.values(side)) {
      if (section && Object.prototype.hasOwnProperty.call(section, field)) {
        let text = formatValue(field, section[field]);
        const tol = section[`${field}Tol`];
        if (tol !== undefined) text += ` ${formatTolerance(tol)}`;
        return text;
      }
    }
    return undefined;
  }

  function formatCapacity(capacity) {
    if (!capacity) return undefined;
    return `${formatNumber(capacity.grH2O)} grH2O`;
  }

  function normalizeText(text) {
    return String(text).toLowerCase().replace(/,/g, '.').replace(/\s+/g, ' ').trim();
  }

  function matchesSearch(record, query) {
    const needle = normalizeText(query);
    if (needle === '') return true;
    const names = [record.name, ...(record.alternativeNames || [])];
    return names.some((name) => normalizeText(name).includes(needle));
  }

  function countLabel(count) {
    return count === 1 ? '1 cartridge' : `${count} cartridges`;
  }

  const api = {
    symbolFor,
    unitFor,
    formatNumber,
    formatAngle,
    formatValue,
    formatTolerance,
    publishedLeaves,
    sectionsOf,
    fieldText,
    formatCapacity,
    matchesSearch,
    countLabel,
    FAMILIES: ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'],
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = Object.assign(root.CIP || {}, { format: api });
  }
})(typeof window !== 'undefined' ? window : globalThis);
