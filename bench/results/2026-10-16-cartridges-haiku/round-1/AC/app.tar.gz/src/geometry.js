(function (root) {
  'use strict';

  // Profile geometry from the brief. Points are {z, r} in mm: z runs along the axis from the
  // head face (z = 0) towards the mouth, r is the radius. The brief writes some pairs as (r, z);
  // they are converted here once, so the rules below read in the brief's own terms.

  const EPS = 1e-9;
  const ARC_STEPS = 16;
  const PI = Math.PI;

  const PRIMER_POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 },
  };

  const has = (value) => value !== undefined && value !== null;
  const rad = (deg) => (deg * PI) / 180;

  // Angles are a number of degrees or {degrees, minutes, seconds}.
  function degreesOf(value) {
    if (!has(value)) return undefined;
    if (typeof value === 'number') return value;
    return value.degrees + value.minutes / 60 + value.seconds / 3600;
  }

  function rimTypeOf(family, R1, P1) {
    if (family === 'belted') return 'belted';
    if (family === 'rimfire') return 'rimfire';
    if (has(R1) && has(P1)) {
      const ratio = R1 / P1;
      if (ratio >= 1.05) return 'rimmed';
      if (ratio < 0.98) return 'rebated';
      return 'rimless';
    }
    return family === 'rimmed' ? 'rimmed' : 'rimless';
  }

  function radiusAt(points, z) {
    for (let i = 1; i < points.length; i += 1) {
      const a = points[i - 1];
      const b = points[i];
      if (b.z - a.z > EPS && z >= a.z - EPS && z <= b.z + EPS) {
        return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
      }
    }
    const exact = points.find((p) => Math.abs(p.z - z) < EPS);
    return exact ? exact.r : NaN;
  }

  // Tangent arc of radius rho in the corner at `corner`, between the segments to `prev` and `next`.
  function filletArc(prev, corner, next, rho) {
    const toPrev = { z: prev.z - corner.z, r: prev.r - corner.r };
    const toNext = { z: next.z - corner.z, r: next.r - corner.r };
    const lenPrev = Math.hypot(toPrev.z, toPrev.r);
    const lenNext = Math.hypot(toNext.z, toNext.r);
    const ua = { z: toPrev.z / lenPrev, r: toPrev.r / lenPrev };
    const ub = { z: toNext.z / lenNext, r: toNext.r / lenNext };
    const theta = Math.acos(Math.min(1, Math.max(-1, ua.z * ub.z + ua.r * ub.r)));
    if (theta < 1e-6 || theta > PI - 1e-6) return null;
    const d = rho / Math.tan(theta / 2);
    if (d > 0.5 * lenPrev || d > 0.5 * lenNext) return null;
    const t1 = { z: corner.z + ua.z * d, r: corner.r + ua.r * d };
    const t2 = { z: corner.z + ub.z * d, r: corner.r + ub.r * d };
    const bis = { z: ua.z + ub.z, r: ua.r + ub.r };
    const bisLen = Math.hypot(bis.z, bis.r);
    const centreDist = rho / Math.sin(theta / 2);
    const c = { z: corner.z + (bis.z / bisLen) * centreDist, r: corner.r + (bis.r / bisLen) * centreDist };
    const a1 = Math.atan2(t1.r - c.r, t1.z - c.z);
    const a2 = Math.atan2(t2.r - c.r, t2.z - c.z);
    let sweep = a2 - a1;
    while (sweep > PI) sweep -= 2 * PI;
    while (sweep < -PI) sweep += 2 * PI;
    const pts = [];
    for (let i = 0; i <= ARC_STEPS; i += 1) {
      const ang = a1 + (sweep * i) / ARC_STEPS;
      pts.push({ z: c.z + rho * Math.cos(ang), r: c.r + rho * Math.sin(ang) });
    }
    return { pts, filleted: true };
  }

  // Polyline through `verts`, with each interior vertex having an optional `rho` fillet.
  function expandCorners(verts, notes, label) {
    const out = [{ z: verts[0].z, r: verts[0].r }];
    for (let i = 1; i < verts.length - 1; i += 1) {
      const v = verts[i];
      if (v.rho > 0) {
        const arc = filletArc(verts[i - 1], v, verts[i + 1], v.rho);
        if (arc) {
          out.push(...arc.pts);
          continue;
        }
        notes.push(`${label} does not fit the shoulder: corner drawn sharp`);
      }
      out.push({ z: v.z, r: v.r });
    }
    const last = verts[verts.length - 1];
    out.push({ z: last.z, r: last.r });
    return out;
  }

  // Bullet nose and seating, from the brief's rules for each nose shape.
  function bulletFor(spec) {
    const { shape, category, G1, H2, L3, L6 } = spec;
    const heeled = H2 - G1 <= 0.015;
    const D = heeled ? H2 : G1;
    const pistol = category === 'pistol';
    let s;
    let k;
    let m;
    if (shape === 'pointy') {
      s = G1;
      k = 0.4;
      m = Math.max(0.08 * D, 1.27);
    } else if (shape === 'rounded') {
      s = (pistol ? 0.4 : 0.8) * G1;
      k = pistol ? 0.65 : 0.55;
      m = 0.15 * D;
    } else if (shape === 'flat') {
      s = (pistol ? 0.4 : 0.8) * G1;
      k = pistol ? 0.7 : 0.6;
      m = 0.55 * D;
    } else if (shape === 'semi_wadcutter') {
      s = 0.6 * G1;
      k = 0.78;
      m = 0.6 * D;
    } else {
      return null;
    }
    const zb = L3 - s;
    const Lb = L6 - zb;
    const zs = zb + k * Lb;
    const n = L6 - zs;
    const Rn = D / 2;
    const rm = m / 2;
    const nose = [];
    if (shape === 'pointy') {
      const a = Rn - rm;
      const rho = (a * a + n * n) / (2 * a);
      const centreR = Rn - rho;
      const end = Math.atan2(n, rho - a);
      for (let i = 0; i <= ARC_STEPS; i += 1) {
        const th = (end * i) / ARC_STEPS;
        nose.push({ z: zs + rho * Math.sin(th), r: centreR + rho * Math.cos(th) });
      }
    } else if (shape === 'rounded') {
      const a = Rn - rm;
      for (let i = 0; i <= ARC_STEPS; i += 1) {
        const th = ((PI / 2) * i) / ARC_STEPS;
        nose.push({ z: zs + n * Math.sin(th), r: rm + a * Math.cos(th) });
      }
    } else {
      nose.push({ z: zs, r: Rn }, { z: L6, r: rm });
    }
    return { shape, kind: pistol ? 'pistol' : 'rifle', s, k, m, D, Rn, heeled, zb, Lb, zs, n, nose };
  }

  function profile(record) {
    const notes = [];
    const { cartridge: c, annotations: ann } = record;
    const ch = c.caseHead;
    const L = c.lengths;
    const pc = c.powderChamber;
    const jc = c.junctionCone || {};
    const H = c.collar;
    const G1 = c.projectile.G1;
    const L3 = L.L3;
    const L6 = L.L6;
    const R1 = ch.R1;
    const P1 = pc.P1;
    const H2 = H.H2;
    if (![L3, L6, R1, P1, H2, G1].every(has)) {
      throw new Error(`${record.key}: L3, L6, R1, P1, H2 and G1 are required to draw the case`);
    }

    const rim = rimTypeOf(record.family, R1, P1);
    const rimfire = rim === 'rimfire';
    const belted = rim === 'belted';
    let R = ch.R;
    if (!has(R)) {
      notes.push('R not published: rim corner drawn at the face');
      R = has(ch.f) ? ch.f : 0;
    }

    // Head face, rim edge, extractor groove or step: the head part of the outer profile.
    const head = [{ z: 0, r: 0 }];
    let zBody;
    let groove = null;
    let belt = null;
    if (rimfire) {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      const rc = R1 / 2 - rho;
      for (let i = 0; i <= ARC_STEPS; i += 1) {
        const phi = PI - (PI * i) / ARC_STEPS;
        head.push({ z: rho + rho * Math.cos(phi), r: rc + rho * Math.sin(phi) });
      }
      if (2 * rho < R - EPS) head.push({ z: R, r: rc });
      head.push({ z: R, r: P1 / 2 });
      zBody = R;
    } else {
      const beta = degreesOf(ch.beta);
      const f = ch.f;
      if (has(beta) && has(f) && beta < 90) {
        const chamfer = Math.min(f * Math.tan(rad(beta)), R1 / 4);
        head.push({ z: 0, r: R1 / 2 - chamfer }, { z: f, r: R1 / 2 });
      } else {
        head.push({ z: 0, r: R1 / 2 });
        if (has(beta) !== has(f)) notes.push(`${has(beta) ? 'f' : 'beta'} not published: head chamfer not drawn`);
      }
      head.push({ z: R, r: R1 / 2 });

      const E = ch.E;
      const E1 = ch.E1;
      const hasGroove = has(E) && has(E1);
      if (hasGroove) {
        const eMin = has(ch.eMin) ? ch.eMin : 0;
        if (!has(ch.eMin)) notes.push('eMin not published: groove floor drawn with no length');
        const floorZ = R + eMin;
        head.push({ z: R, r: E1 / 2 }, { z: floorZ, r: E1 / 2 });
        groove = { E, E1, eMin };
        const delta = degreesOf(ch.delta);
        const haveBelt = belted && has(ch.R3) && has(delta);
        if (belted && !haveBelt) notes.push('R3 or delta not published: belt not drawn, groove ramps straight');
        if (haveBelt) {
          const rampEnd = floorZ + (ch.R3 / 2 - E1 / 2) / Math.tan(rad(delta));
          if (rampEnd < E) {
            belt = { rampEnd, R3: ch.R3, delta };
            head.push({ z: rampEnd, r: ch.R3 / 2 }, { z: E, r: ch.R3 / 2 }, { z: E, r: P1 / 2 });
          } else {
            notes.push('belt ramp does not fit before E: belt not drawn');
            head.push({ z: E, r: P1 / 2 });
          }
        } else {
          head.push({ z: E, r: P1 / 2 });
        }
        zBody = E;
      } else {
        if (has(E) || has(E1)) notes.push(`${has(E) ? 'E1' : 'E'} not published: extractor groove not drawn`);
        head.push({ z: R, r: P1 / 2 });
        zBody = R;
      }
    }

    // Body, shoulder and neck. The shoulder needs alpha, L1 and L2; without them the case is straight.
    const jcAlpha = jc.alpha;
    const hasShoulder = has(jcAlpha) && has(L.L1) && has(L.L2);
    const shoulderPartial = !hasShoulder && (has(jcAlpha) || has(L.L1) || has(L.L2));
    if (shoulderPartial) notes.push('alpha, L1 or L2 not published: case drawn straight');
    const shoulderOk = hasShoulder && has(pc.P2) && has(H.H1);
    if (hasShoulder && !shoulderOk) notes.push('P2 or H1 not published: case drawn straight');
    const shoulder = shoulderOk
      ? { alpha: jcAlpha, L1: L.L1, L2: L.L2, P2: pc.P2, H1: H.H1, r1Min: jc.r1Min, r2: jc.r2 }
      : null;
    if (shoulder && !has(jc.r1Min)) notes.push('r1 min not published: body corner drawn sharp');
    if (shoulder && !has(jc.r2)) notes.push('r2 not published: neck corner drawn sharp');

    const bodyVerts = [{ z: zBody, r: P1 / 2 }];
    if (shoulder) {
      bodyVerts.push({ z: shoulder.L1, r: shoulder.P2 / 2, rho: shoulder.r1Min });
      bodyVerts.push({ z: shoulder.L2, r: shoulder.H1 / 2, rho: shoulder.r2 });
    }
    bodyVerts.push({ z: L3, r: H2 / 2 });
    const body = expandCorners(bodyVerts, notes, 'shoulder fillet');

    const outer = head.slice(0, -1).concat(body);

    // Bullet.
    const shape = ann.defaultBulletShape;
    const category = ann.category;
    const bulletSpec = bulletFor({ shape, category, G1, H2, L3, L6 });
    if (!bulletSpec) notes.push(`bullet shape "${shape}" not known: bullet not drawn`);

    // Walls: tn along the neck, tb along the body, blended across the shoulder.
    const tn = Math.max(0, (H2 - G1) / 2);
    const heeled = bulletSpec ? bulletSpec.heeled : H2 - G1 <= 0.015;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * (P1 / 2));
    const tnNeck = heeled ? tb : tn;
    const wall = (z) => {
      if (shoulder) {
        if (z <= shoulder.L1) return tb;
        if (z >= shoulder.L2) return tnNeck;
        return tb + ((tnNeck - tb) * (z - shoulder.L1)) / (shoulder.L2 - shoulder.L1);
      }
      const t = Math.min(1, Math.max(0, (z - zBody) / (L3 - zBody)));
      return tb + (tnNeck - tb) * t;
    };

    // Primer pocket and cavity bottom.
    let pocket = null;
    if (!rimfire) {
      const known = PRIMER_POCKETS[ann.primerType];
      if (known) pocket = { diameter: known.diameter, r: known.diameter / 2, depth: known.depth };
      else notes.push(`primer type "${ann.primerType}" not known: no primer pocket drawn`);
    }
    const terms = [2.5, 0.25 * (P1 / 2)];
    if (pocket) terms.push(pocket.depth + 1.5);
    if (groove) terms.push(belt ? belt.rampEnd + tb : groove.E + tb);
    const w = Math.max(...terms);

    const inner = [{ z: w, r: radiusAt(outer, w) - wall(w) }];
    for (const p of outer) {
      if (p.z > w + EPS && p.z < L3 - EPS) inner.push({ z: p.z, r: p.r - wall(p.z) });
    }
    inner.push({ z: L3, r: radiusAt(outer, L3) - wall(L3) });

    // Section polygon of the case, in (z, r): outer profile, mouth, inner wall, cavity bottom, pocket.
    const cut = [];
    if (pocket) cut.push({ z: 0, r: pocket.r });
    else cut.push({ z: 0, r: 0 });
    for (const p of outer.slice(1)) {
      if (!(p.z < EPS && pocket && p.r < pocket.r)) cut.push(p);
    }
    for (let i = inner.length - 1; i >= 0; i -= 1) cut.push(inner[i]);
    cut.push({ z: w, r: 0 });
    if (pocket) cut.push({ z: pocket.depth, r: 0 }, { z: pocket.depth, r: pocket.r });

    // Bullet outlines: exposed (outside view) and full (section).
    let bullet = null;
    if (bulletSpec) {
      const heelR = heeled ? H2 / 2 - tb : bulletSpec.Rn;
      const exposed = [{ z: L3, r: bulletSpec.Rn }, ...bulletSpec.nose, { z: L6, r: 0 }];
      const full = [
        { z: bulletSpec.zb, r: 0 },
        { z: bulletSpec.zb, r: heelR },
        { z: L3, r: heelR },
        { z: L3, r: bulletSpec.Rn },
        ...bulletSpec.nose,
        { z: L6, r: 0 },
      ];
      bullet = Object.assign(bulletSpec, { heelR, exposed, full });
    }

    return {
      key: record.key,
      rim,
      heeled,
      notes,
      values: { L3, L6, R1, R, P1, P2: has(pc.P2) ? pc.P2 : undefined, H1: has(H.H1) ? H.H1 : undefined, H2, G1,
        L1: has(L.L1) ? L.L1 : undefined, L2: has(L.L2) ? L.L2 : undefined, E1: has(ch.E1) ? ch.E1 : undefined,
        alpha: has(jcAlpha) ? jcAlpha : undefined },
      outer,
      inner,
      cut,
      w,
      tb,
      tn,
      tnNeck,
      pocket,
      groove,
      belt,
      shoulder,
      zBody,
      bullet,
      L3,
      L6,
      zs: bullet ? bullet.zs : undefined,
      zb: bullet ? bullet.zb : undefined,
    };
  }

  const api = { profile, bulletFor, radiusAt, filletArc, rimTypeOf, PRIMER_POCKETS, degreesOf };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = Object.assign(root.CIP || {}, { geometry: api });
  }
})(typeof window !== 'undefined' ? window : globalThis);
