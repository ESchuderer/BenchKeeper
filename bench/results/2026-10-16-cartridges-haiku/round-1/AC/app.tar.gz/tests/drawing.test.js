'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const drawing = require('../src/drawing.js');
const { loadRecords, recordByKey } = require('./helpers.js');

const labelTexts = (layout) => layout.labels.map((l) => l.text);

test('the 308 Win. drawing carries every required and published dimension with its value', () => {
  const texts = labelTexts(drawing.layout(recordByKey('308_win')));
  for (const expected of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96',
    'P2 11.53 -0.2', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62 -0.2', 'L2 43.48 -0.2',
    'E1 10.39', 'α 40°']) {
    assert.ok(texts.includes(expected), `missing label ${expected}: ${texts.join(' | ')}`);
  }
});

test('dimensions appear only where published', () => {
  const texts = labelTexts(drawing.layout(recordByKey('22_long_rifle')));
  const symbols = new Set(texts.map((t) => t.split(' ')[0]));
  for (const s of ['L3', 'L6', 'R1', 'R', 'P1', 'H2', 'G1']) assert.ok(symbols.has(s), s);
  for (const s of ['P2', 'H1', 'L1', 'L2', 'E1', 'α']) assert.ok(!symbols.has(s), `${s} should not be drawn`);
});

test('every record: required dimensions are present and each published one is labelled', () => {
  for (const record of loadRecords()) {
    const layout = drawing.layout(record);
    const symbols = layout.labels.map((l) => l.symbol);
    for (const s of ['L3', 'L6', 'R1', 'R', 'P1', 'H2', 'G1']) {
      assert.ok(symbols.includes(s), `${record.key} ${s}`);
    }
    const { lengths, powderChamber: pc, collar } = record.cartridge;
    const jc = record.cartridge.junctionCone || {};
    if (lengths.L1 !== undefined && jc.alpha !== undefined) {
      assert.ok(symbols.includes('L1') && symbols.includes('alpha'), `${record.key} shoulder dims`);
    }
    if (pc.P2 !== undefined && layout.profile.shoulder) assert.ok(symbols.includes('P2'), `${record.key} P2`);
    if (collar.H1 !== undefined && layout.profile.shoulder) assert.ok(symbols.includes('H1'), `${record.key} H1`);
    if (record.cartridge.caseHead.E1 !== undefined && layout.profile.groove) {
      assert.ok(symbols.includes('E1'), `${record.key} E1`);
    }
  }
});

test('no two labels overlap, no label overlaps the outline, and no label overlaps the title block', () => {
  for (const record of loadRecords()) {
    const layout = drawing.layout(record);
    const problems = drawing.overlapProblems(layout);
    assert.deepEqual(problems, [], `${record.key} overlaps`);
  }
});

test('labels and the title block lie inside the view box', () => {
  for (const record of loadRecords()) {
    const { viewBox } = drawing.layout(record);
    for (const label of drawing.layout(record).labels) {
      const b = label.box;
      assert.ok(b.x0 >= viewBox.x && b.x1 <= viewBox.x + viewBox.w, `${record.key} ${label.text} x`);
      assert.ok(b.y0 >= viewBox.y && b.y1 <= viewBox.y + viewBox.h, `${record.key} ${label.text} y`);
    }
  }
});

test('svg is inline, true to scale (no transform), with the accessible name and a viewBox in mm', () => {
  const svg = drawing.svg(recordByKey('308_win'));
  assert.match(svg, /^<svg\b/);
  assert.match(svg, /role="img"/);
  assert.match(svg, /aria-label="308 Win\. drawing"/);
  assert.match(svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/);
  assert.ok(!/transform="scale/.test(svg), 'no scaling transform');
  assert.match(svg, /stroke-dasharray/, 'dash-dot centre line');
  assert.match(svg, /<pattern /, 'hatch pattern for the cut walls');
});

test('the title block holds the name, C.I.P. table, revision date, units and a 10 mm scale bar', () => {
  const svg = drawing.svg(recordByKey('308_win'));
  for (const text of ['308 Win.', 'C.I.P. table I', '2008-09-23', 'Dimensions in mm', 'Scale', '10 mm']) {
    assert.ok(svg.includes(text), text);
  }
});

test('notes name the values that were missing (and nothing for a complete record)', () => {
  const notes = drawing.layout(recordByKey('338_lapua_mag')).notes.join(' | ');
  assert.match(notes, /r1 min/);
  assert.equal(drawing.layout(recordByKey('223_rem')).notes.length, 0);
  assert.match(drawing.layout(recordByKey('22_long_rifle')).info.join(' '), /Heeled/);
});
