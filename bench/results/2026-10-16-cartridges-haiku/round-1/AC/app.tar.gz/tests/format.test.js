'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const format = require('../src/format.js');
const { loadRecords, recordByKey } = require('./helpers.js');

test('symbols use the field name except the mapped ones', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
    L3: 'L3', R1: 'R1', E1: 'E1', r2: 'r2', Pmax: 'Pmax',
  };
  for (const [field, symbol] of Object.entries(expected)) {
    assert.equal(format.symbolFor(field), symbol, field);
  }
});

test('units follow the brief: mm by default, with the listed exceptions', () => {
  assert.equal(format.unitFor('L3'), 'mm');
  assert.equal(format.unitFor('R1'), 'mm');
  assert.equal(format.unitFor('Fe'), 'mm');
  assert.equal(format.unitFor('Pmax'), 'bar');
  assert.equal(format.unitFor('PK'), 'bar');
  assert.equal(format.unitFor('PE'), 'bar');
  assert.equal(format.unitFor('EE'), 'J');
  assert.equal(format.unitFor('M'), 'g');
  assert.equal(format.unitFor('Q'), 'mm²');
  assert.equal(format.unitFor('N'), '—');
  assert.equal(format.unitFor('alpha'), '—');
  assert.equal(format.unitFor('i'), '—');
});

test('numbers print with a point and no thousands separator', () => {
  assert.equal(format.formatNumber(51.18), '51.18');
  assert.equal(format.formatNumber(4150.0), '4150');
  assert.equal(format.formatNumber(9.0), '9');
  assert.equal(format.formatNumber(-0.2), '-0.2');
});

test('angles: plain degrees and degrees-minutes-seconds', () => {
  assert.equal(format.formatAngle(40), '40°');
  assert.equal(format.formatAngle(46.0), '46°');
  assert.equal(format.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(format.formatAngle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
  assert.equal(format.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
});

test('a tolerance is merged into its value, never a row of its own', () => {
  const rows = format.sectionsOf(recordByKey('308_win')).cartridge;
  const lengths = rows.find((s) => s.title === 'Lengths');
  const l1 = lengths.rows.find((r) => r.symbol === 'L1');
  assert.deepEqual(l1, { symbol: 'L1', value: '39.62 -0.2', unit: 'mm' });
  assert.ok(!lengths.rows.some((r) => /Tol/.test(r.symbol)));
  const head = rows.find((s) => s.title === 'Case head');
  assert.equal(head.rows.find((r) => r.symbol === 'E').value, '3.85');
  assert.equal(recordByKey('300_win_mag').cartridge.caseHead.ETol, -0.2);
  const e = format.sectionsOf(recordByKey('300_win_mag')).cartridge
    .find((s) => s.title === 'Case head').rows.find((r) => r.symbol === 'E');
  assert.equal(e.value, '5.59 -0.2');
});

test('cartridge and chamber sections are grouped with their published names', () => {
  const groups = format.sectionsOf(recordByKey('223_rem'));
  assert.deepEqual(groups.cartridge.map((s) => s.title), [
    'Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous',
    'Powder chamber', 'Pressures', 'Projectile',
  ]);
  assert.deepEqual(groups.chamber.map((s) => s.title), [
    'Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths',
    'Powder chamber', 'Rifling',
  ]);
});

test('every published field of every record appears exactly once in the tables', () => {
  for (const record of loadRecords()) {
    const groups = format.sectionsOf(record);
    for (const side of ['cartridge', 'chamber']) {
      const rows = groups[side].flatMap((s) => s.rows).map((r) => r.symbol);
      assert.equal(new Set(rows).size, rows.length, `${record.key} ${side} duplicate symbol`);
      const published = format.publishedLeaves(record[side]).filter((p) => !/Tol$/.test(p.field));
      assert.equal(rows.length, published.length, `${record.key} ${side} row count`);
    }
  }
});

test('empty sections are left out, so a pistol has no junction cone table', () => {
  const groups = format.sectionsOf(recordByKey('9_mm_luger'));
  assert.ok(!groups.cartridge.some((s) => s.title === 'Junction cone'));
  assert.ok(!groups.chamber.some((s) => s.title === 'Junction cone'));
});

test('capacity and dates format as published', () => {
  const r = recordByKey('308_win');
  assert.equal(format.formatCapacity(r.annotations.publishedCapacity), '56 grH2O');
  assert.equal(format.formatCapacity(recordByKey('22_long_rifle').annotations.publishedCapacity), undefined);
});

test('search matches names and alternative names, ignoring case and comma/point', () => {
  const r = recordByKey('308_win');
  assert.equal(format.matchesSearch(r, '7,62 x 51'), true);
  assert.equal(format.matchesSearch(r, '7.62 X 51'), true);
  assert.equal(format.matchesSearch(r, '308'), true);
  assert.equal(format.matchesSearch(r, '6,5'), false);
  assert.equal(format.matchesSearch(recordByKey('6_5_creedmoor'), '6.5 creed'), true);
  assert.equal(format.matchesSearch(r, '   '), true);
});

test('plural labels for the count line', () => {
  assert.equal(format.countLabel(0), '0 cartridges');
  assert.equal(format.countLabel(1), '1 cartridge');
  assert.equal(format.countLabel(25), '25 cartridges');
});
