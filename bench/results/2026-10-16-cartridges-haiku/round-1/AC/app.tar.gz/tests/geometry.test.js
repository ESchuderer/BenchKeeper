'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const geometry = require('../src/geometry.js');
const { loadRecords, recordByKey } = require('./helpers.js');

const EPS = 1e-6;
const near = (actual, expected, message) =>
  assert.ok(Math.abs(actual - expected) < EPS, `${message || ''} expected ${expected}, got ${actual}`);

function hasPoint(points, z, r) {
  return points.some((p) => Math.abs(p.z - z) < 1e-4 && Math.abs(p.r - r) < 1e-4);
}

test('rim type follows the family first, then the R1/P1 ratio', () => {
  assert.equal(geometry.profile(recordByKey('223_rem')).rim, 'rimless');
  assert.equal(geometry.profile(recordByKey('9_3_x_74_r')).rim, 'rimmed');
  assert.equal(geometry.profile(recordByKey('300_win_mag')).rim, 'belted');
  assert.equal(geometry.profile(recordByKey('22_long_rifle')).rim, 'rimfire');
  assert.equal(geometry.profile(recordByKey('38_special')).rim, 'rimmed');
  assert.equal(geometry.profile(recordByKey('9_mm_luger')).rim, 'rimless');
  const rebated = Object.assign({}, recordByKey('223_rem'), {
    cartridge: { ...recordByKey('223_rem').cartridge, caseHead: { E: 3.13, R: 1.14, R1: 10.0, beta: 35, f: 0.45 },
      powderChamber: { P1: 10.5, P2: 9.0 } },
  });
  assert.equal(geometry.profile(rebated).rim, 'rebated');
});

test('head face: chamfer from the axis side to the rim, then up to R', () => {
  const p = geometry.profile(recordByKey('223_rem'));
  const c = Math.min(0.45 * Math.tan(35 * Math.PI / 180), 9.6 / 4);
  near(p.outer[0].z, 0); near(p.outer[0].r, 0);
  near(p.outer[1].r, 4.8 - c, 'chamfer start radius');
  near(p.outer[1].z, 0);
  assert.ok(hasPoint(p.outer, 0.45, 4.8), 'chamfer end at (f, R1/2)');
  assert.ok(hasPoint(p.outer, 1.14, 4.8), 'rim edge up to R');
});

test('extractor groove of a bottleneck case: floor, then ramp to the body at E', () => {
  const p = geometry.profile(recordByKey('223_rem'));
  const seq = [[1.14, 4.8], [1.14, 4.215], [1.9, 4.215], [3.13, 4.79]];
  let last = -1;
  for (const [z, r] of seq) {
    const i = p.outer.findIndex((q, idx) => idx > last && Math.abs(q.z - z) < 1e-4 && Math.abs(q.r - r) < 1e-4);
    assert.ok(i > last, `groove point (${z}, ${r}) in order`);
    last = i;
  }
});

test('belted groove ramps at angle delta to the belt, follows it to E, then steps to the body', () => {
  const p = geometry.profile(recordByKey('300_win_mag'));
  const floorEnd = 1.27 + 0.94;
  const rampEnd = floorEnd + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  assert.ok(hasPoint(p.outer, rampEnd, 13.51 / 2), 'ramp reaches the belt');
  assert.ok(hasPoint(p.outer, 5.59, 13.51 / 2), 'belt runs to E');
  assert.ok(hasPoint(p.outer, 5.59, 13.03 / 2), 'steps in to P1/2 at E');
  near(p.belt.rampEnd, rampEnd, 'rampEnd');
});

test('rimfire rim is a half-round whose outermost point is R1/2', () => {
  const p = geometry.profile(recordByKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const outermost = Math.max(...p.outer.filter((q) => q.z <= 1.09 + EPS).map((q) => q.r));
  near(outermost, 7.06 / 2, 'outermost rim radius');
  assert.ok(hasPoint(p.outer, rho, 7.06 / 2), 'half-round apex at z = rho');
});

test('no groove and no E: the rim steps straight to the body at R', () => {
  const p = geometry.profile(recordByKey('9_3_x_74_r'));
  assert.ok(hasPoint(p.outer, 1.4, 13.35 / 2));
  assert.ok(hasPoint(p.outer, 1.4, 11.9 / 2), 'step to P1/2 at R');
  assert.equal(p.groove, null);
});

test('bullet, pointy: s = 1.0 G1, k = 0.40, tangent ogive ending on the meplat', () => {
  const b = geometry.profile(recordByKey('223_rem')).bullet;
  near(b.s, 5.7, 's'); near(b.zb, 39.0, 'zb'); near(b.Lb, 18.4, 'Lb');
  near(b.zs, 46.36, 'zs'); near(b.m, 1.27, 'meplat');
  const tip = b.nose[b.nose.length - 1];
  near(tip.z, 57.4, 'tip z'); near(tip.r, 0.635, 'meplat radius');
  near(b.nose[0].z, b.zs); near(b.nose[0].r, 2.85, 'nose starts on the shank');
});

test('bullet, rounded pistol: s = 0.4 G1, k = 0.65, quarter-ellipse nose with m = 0.15 G1', () => {
  const b = geometry.profile(recordByKey('9_mm_luger')).bullet;
  near(b.s, 0.4 * 9.03, 's');
  near(b.zb, 19.15 - 0.4 * 9.03, 'zb');
  near(b.zs, b.zb + 0.65 * (29.69 - b.zb), 'zs');
  near(b.m, 0.15 * 9.03, 'meplat');
  const tip = b.nose[b.nose.length - 1];
  near(tip.z, 29.69); near(tip.r, 0.15 * 9.03 / 2);
});

test('bullet, semi-wadcutter: s = 0.6 G1, k = 0.78, straight cone ending at m = 0.6 G1', () => {
  const b = geometry.profile(recordByKey('357_magnum')).bullet;
  near(b.s, 0.6 * 9.12, 's');
  near(b.zs, b.zb + 0.78 * (40.39 - b.zb), 'zs');
  near(b.m, 0.6 * 9.12, 'meplat');
  const tip = b.nose[b.nose.length - 1];
  near(tip.z, 40.39); near(tip.r, 0.6 * 9.12 / 2);
});

test('bullet, flat rifle: s = 0.8 G1, k = 0.60; flat pistol: s = 0.4 G1, k = 0.70', () => {
  const rifleFlat = geometry.bulletFor({ shape: 'flat', category: 'rifle', G1: 8, L3: 50, L6: 70, H2: 9 });
  near(rifleFlat.s, 6.4, 's rifle'); near(rifleFlat.k, 0.6, 'k rifle');
  const pistolFlat = geometry.bulletFor({ shape: 'flat', category: 'pistol', G1: 9, L3: 20, L6: 30, H2: 10 });
  near(pistolFlat.s, 3.6, 's pistol'); near(pistolFlat.k, 0.7, 'k pistol');
});

test('heeled bullet (22 Long Rifle): exposed diameter is H2, the heel is H2 - 2 tb', () => {
  const p = geometry.profile(recordByKey('22_long_rifle'));
  assert.equal(p.heeled, true);
  near(p.bullet.D, 5.72, 'exposed diameter');
  near(p.bullet.heelR, 5.72 / 2 - p.tb, 'heel radius');
  assert.equal(geometry.profile(recordByKey('308_win')).heeled, false);
});

test('section walls: tn = (H2 - G1)/2, tb = min(max(1.3 tn, 0.6), 0.35 P1/2)', () => {
  const p = geometry.profile(recordByKey('223_rem'));
  near(p.tn, (6.43 - 5.7) / 2, 'tn');
  near(p.tb, 0.6, 'tb');
  const inner = p.inner;
  near(inner[inner.length - 1].r, 6.43 / 2 - p.tn, 'mouth inner radius equals G1/2');
  near(inner[inner.length - 1].z, 44.7, 'inner ends at the mouth');
});

test('cavity bottom w is the largest of the brief terms; primer pocket by primer type', () => {
  const p223 = geometry.profile(recordByKey('223_rem'));
  near(p223.pocket.diameter, 4.45); near(p223.pocket.depth, 3.04);
  near(p223.w, 3.04 + 1.5, 'w pocket term');
  const p65 = geometry.profile(recordByKey('6_5_creedmoor'));
  near(p65.pocket.diameter, 5.33); near(p65.pocket.depth, 3.3);
  assert.equal(geometry.profile(recordByKey('22_long_rifle')).pocket, null);
  const belted = geometry.profile(recordByKey('300_win_mag'));
  const beltTerm = belted.belt.rampEnd + belted.tb;
  assert.ok(beltTerm < belted.w, 'belt term is below the pocket term here');
  near(belted.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, beltTerm), 'belted w is the max of the terms');
});

test('a missing value is named in the notes instead of being invented', () => {
  const notesOf = (key) => geometry.profile(recordByKey(key)).notes.join(' | ');
  assert.match(notesOf('338_lapua_mag'), /r1 min/);
  assert.match(notesOf('17_hmr'), /r1 min/);
  assert.match(notesOf('17_hmr'), /r2/);
  assert.equal(notesOf('9_mm_luger'), '', 'a straight pistol case needs no notes');
  assert.equal(notesOf('223_rem'), '');
});

test('every record builds without error and has a monotone outer profile and a valid bullet', () => {
  for (const record of loadRecords()) {
    const p = geometry.profile(record);
    for (let i = 1; i < p.outer.length; i += 1) {
      assert.ok(p.outer[i].z >= p.outer[i - 1].z - EPS, `${record.key} outer z monotone at ${i}`);
    }
    assert.ok(p.bullet.zs >= p.L3 - EPS, `${record.key} nose starts outside the mouth`);
    assert.ok(p.inner.every((q) => q.r >= 0), `${record.key} inner radius non-negative`);
    assert.ok(p.cut.length >= 4, `${record.key} section polygon exists`);
  }
});
