'use strict';

// Loads the browser-style sources into Node. Each src file attaches to `window`
// when it is not running under CommonJS, so the same files serve both targets.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.join(__dirname, '..');

function loadRecords() {
  const sandbox = { window: {} };
  vm.runInNewContext(fs.readFileSync(path.join(ROOT, 'data', 'cartridges.js'), 'utf8'), sandbox);
  return sandbox.window.CIP_CARTRIDGES;
}

function recordByKey(key) {
  const record = loadRecords().find((r) => r.key === key);
  if (!record) throw new Error(`no record ${key}`);
  return record;
}

module.exports = { loadRecords, recordByKey, ROOT };
