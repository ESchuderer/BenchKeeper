// Page logic: the start page (list, search, family filter) and the detail view, routed by the URL hash.
(function () {
  var app = document.getElementById('app');
  var FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var query = '';
  var family = 'all';

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function renderList() {
    document.title = 'Cartridges · C.I.P. reference';
    app.innerHTML =
      '<h1>Cartridges</h1>' +
      '<form class="filters" role="search" onsubmit="return false">' +
      '<label>Search <input type="search" id="q" autocomplete="off" value="' + esc(query) + '"></label>' +
      '<label>Family <select id="family">' +
      FAMILIES.map(function (f) {
        return '<option value="' + f + '"' + (f === family ? ' selected' : '') + '>' + (f === 'all' ? 'All' : f) + '</option>';
      }).join('') +
      '</select></label>' +
      '</form>' +
      '<p class="count" id="count" aria-live="polite"></p>' +
      '<table class="list"><thead><tr><th>Name</th><th>Family</th><th class="num">L3</th></tr></thead>' +
      '<tbody id="rows"></tbody></table>';
    var input = document.getElementById('q');
    input.addEventListener('input', function () {
      query = input.value;
      updateList();
    });
    document.getElementById('family').addEventListener('change', function (e) {
      family = e.target.value;
      updateList();
    });
    updateList();
  }

  function updateList() {
    var list = filterCartridges(CARTRIDGES, query, family);
    document.getElementById('count').textContent = countText(list.length);
    document.getElementById('rows').innerHTML = list
      .map(function (r) {
        return '<tr><td><a href="#/cartridge/' + encodeURIComponent(r.key) + '">' + esc(r.name) + '</a></td>' +
          '<td>' + esc(r.family) + '</td>' +
          '<td class="num">' + esc(r.cartridge.lengths.L3) + ' mm</td></tr>';
      })
      .join('');
  }

  function capacityHtml(cap) {
    if (!cap) return '–';
    var html = esc(cap.grH2O) + ' grH2O, source <a href="' + esc(cap.url) + '">' + esc(cap.source) + '</a>';
    if (cap.note) html += ' (' + esc(cap.note) + ')';
    return html;
  }

  function factsHtml(rec) {
    var ann = rec.annotations || {};
    var rows = [];
    if (rec.alternativeNames && rec.alternativeNames.length) rows.push(['Alternative names', rec.alternativeNames.join(', ')]);
    rows.push(['Family', rec.family], ['Category', ann.category], ['Primer type', ann.primerType],
      ['C.I.P. table', rec.tab], ['Country', rec.country], ['Published', rec.published], ['Revised', rec.revised],
      ['Pressure method', rec.pressureMethod]);
    return '<dl class="facts">' + rows.map(function (r) {
      return '<dt>' + esc(r[0]) + '</dt><dd>' + esc(r[1]) + '</dd>';
    }).join('') + '<dt>Water capacity</dt><dd>' + capacityHtml(ann.publishedCapacity) + '</dd></dl>';
  }

  function tablesHtml(rec) {
    return recordSections(rec).map(function (section) {
      return '<section class="section"><h2>' + esc(section.title) + '</h2><div class="groups">' +
        section.groups.map(function (g) {
          return '<div class="group"><h3>' + esc(g.title) + '</h3><table><thead><tr><th>Symbol</th><th>Value</th><th>Unit</th></tr></thead><tbody>' +
            g.rows.map(function (row) {
              return '<tr><td>' + esc(row.symbol) + '</td><td class="num">' + esc(row.value) + '</td><td>' + esc(row.unit) + '</td></tr>';
            }).join('') +
            '</tbody></table></div>';
        }).join('') +
        '</div></section>';
    }).join('');
  }

  function renderDetail(key) {
    var rec = CARTRIDGES.find(function (r) { return r.key === key; });
    if (!rec) {
      document.title = 'Not found · Cartridges';
      app.innerHTML = '<h1>Cartridge not found</h1><p><a href="#/">All cartridges</a></p>';
      return;
    }
    var drawing = buildDrawing(rec);
    document.title = rec.name + ' · Cartridges';
    var notDrawn = drawing.missing.length
      ? '<p class="note">Not drawn, not published: ' + esc(drawing.missing.map(symbolOf).join(', ')) + '.</p>'
      : '';
    app.innerHTML =
      '<nav class="actions no-print"><button type="button" id="print">Print</button> <a href="#/">All cartridges</a></nav>' +
      '<h1>' + esc(rec.name) + '</h1>' +
      factsHtml(rec) +
      '<figure class="drawing-wrap">' + drawingSvg(drawing) + notDrawn + '</figure>' +
      tablesHtml(rec) +
      '<footer class="source">Source: C.I.P. TDCC, revised ' + esc(rec.revised) + '. Data: OpenBallistics (MIT).</footer>';
    document.getElementById('print').addEventListener('click', function () { window.print(); });
  }

  function route() {
    var m = /^#\/cartridge\/(.+)$/.exec(location.hash);
    if (m) renderDetail(decodeURIComponent(m[1]));
    else renderList();
    window.scrollTo(0, 0);
  }

  window.addEventListener('hashchange', route);
  route();
})();
