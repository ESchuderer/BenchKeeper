// Cartridge drawing: case profile, seated bullet, walls and dimensions, computed from one record.
// Rules are written as [r, z] pairs in mm. The SVG uses x = z, and y = -r for the outside (upper half)
// or y = +r for the section (lower half), so 1 user unit = 1 mm.

var DRAWING_FONT = 3.2;       // label size, mm
var DRAWING_OVERSHOOT = 1.2;  // dimension lines run this far past the outline
var DRAWING_ARC_STEPS = 8;
var DRAWING_CHAR_WIDTH = 0.62; // label width estimate, em per character

function toRad(deg) {
  return (deg * Math.PI) / 180;
}

function angleDeg(v) {
  return typeof v === 'number' ? v : v.degrees + v.minutes / 60 + v.seconds / 3600;
}

function rimTypeOf(rec) {
  if (rec.family === 'belted' || rec.family === 'rimfire') return rec.family;
  const ratio = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
  return ratio >= 1.05 ? 'rimmed' : ratio < 0.98 ? 'rebated' : 'rimless';
}

function pocketOf(primer) {
  if (!primer || primer === 'rimfire') return null;
  const large = primer.charAt(0) === 'l';
  const depth = primer === 'lr' || primer === 'lrm' ? 3.3 : 3.04;
  return { r: (large ? 5.33 : 4.45) / 2, depth };
}

// Radius of the outline at height z (linear between points); NaN if z is outside the profile.
function radiusAt(pts, z) {
  for (let i = 0; i + 1 < pts.length; i++) {
    const [r0, z0] = pts[i];
    const [r1, z1] = pts[i + 1];
    if (z0 <= z && z <= z1 && z1 > z0) return r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
  }
  return NaN;
}

// Largest radius of a profile at height z, including vertical steps.
function edgeAt(pts, z) {
  let best = NaN;
  for (const [r, zi] of pts) if (Math.abs(zi - z) < 1e-9) best = isNaN(best) ? r : Math.max(best, r);
  return isNaN(best) ? radiusAt(pts, z) : best;
}

// Points on the arc that rounds the corner v between the segments a-v and v-b, radius rho.
function roundCorner(a, v, b, rho) {
  const unit = (p) => {
    const l = Math.hypot(p[0], p[1]);
    return [p[0] / l, p[1] / l];
  };
  const d1 = [a[0] - v[0], a[1] - v[1]];
  const d2 = [b[0] - v[0], b[1] - v[1]];
  const u1 = unit(d1);
  const u2 = unit(d2);
  const phi = Math.acos(Math.max(-1, Math.min(1, u1[0] * u2[0] + u1[1] * u2[1])));
  const t = Math.min(rho / Math.tan(phi / 2), 0.5 * Math.min(Math.hypot(...d1), Math.hypot(...d2)));
  const r = t * Math.tan(phi / 2);
  const bis = unit([u1[0] + u2[0], u1[1] + u2[1]]);
  const dist = r / Math.sin(phi / 2);
  const c = [v[0] + bis[0] * dist, v[1] + bis[1] * dist];
  const t1 = [v[0] + u1[0] * t, v[1] + u1[1] * t];
  const t2 = [v[0] + u2[0] * t, v[1] + u2[1] * t];
  const a1 = Math.atan2(t1[1] - c[1], t1[0] - c[0]);
  let da = Math.atan2(t2[1] - c[1], t2[0] - c[0]) - a1;
  if (da > Math.PI) da -= 2 * Math.PI;
  if (da < -Math.PI) da += 2 * Math.PI;
  const out = [];
  for (let i = 0; i <= DRAWING_ARC_STEPS; i++) {
    const th = a1 + (da * i) / DRAWING_ARC_STEPS;
    out.push([c[0] + r * Math.cos(th), c[1] + r * Math.sin(th)]);
  }
  return out;
}

// Nose from the end of the cylinder (rs, zc) to the meplat (m/2, L6); the first point is excluded.
function noseSamples(shape, rs, m, zc, L6) {
  const n = L6 - zc;
  const out = [];
  for (let i = 1; i <= DRAWING_ARC_STEPS; i++) {
    const f = i / DRAWING_ARC_STEPS;
    if (shape === 'pointy') {
      // tangent ogive: centre on the radial line through the nose start, radius rho
      const a = rs - m / 2;
      const rho = (a * a + n * n) / (2 * a);
      const th = Math.atan2(n, rho - a) * f;
      out.push([rs - rho + rho * Math.cos(th), zc + rho * Math.sin(th)]);
    } else if (shape === 'rounded') {
      const ph = (Math.PI / 2) * f;
      out.push([m / 2 + (rs - m / 2) * Math.cos(ph), zc + n * Math.sin(ph)]);
    } else {
      out.push([rs + (m / 2 - rs) * f, zc + n * f]);
    }
  }
  return out;
}

function arrowAt(tip, u) {
  const L = 1.2;
  const W = 0.4;
  const bx = tip[0] + u[0] * L;
  const by = tip[1] + u[1] * L;
  const nx = -u[1] * W;
  const ny = u[0] * W;
  return [tip, [bx + nx, by + ny], [bx - nx, by - ny]];
}

function unitVec(a, b) {
  const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
  return [(b[0] - a[0]) / l, (b[1] - a[1]) / l];
}

function buildDrawing(rec) {
  const c = rec.cartridge;
  const ann = rec.annotations || {};
  const V = Object.assign({}, c.caseHead, c.collar, c.junctionCone, c.lengths, c.powderChamber, c.projectile);
  const has = (...k) => k.every((x) => V[x] != null);
  const absent = (...k) => k.filter((x) => V[x] == null);
  const missing = [];
  const rim = rimTypeOf(rec);
  const R = V.R;
  const R1h = V.R1 / 2;
  const P1h = V.P1 / 2;
  const H2h = V.H2 / 2;
  const G1h = V.G1 / 2;
  const groove = has('E', 'E1', 'eMin');
  const belt = rim === 'belted' && groove && has('R3', 'delta');
  const bottleneck = has('alpha', 'L1', 'L2', 'P2', 'H1');
  const chamfer = rim !== 'rimfire' && has('beta', 'f') && angleDeg(V.beta) < 90;
  const outline = [[0, 0]]; // [r, z] from the axis at the head face to the mouth
  const corners = [];
  let bodyZ;
  let zBelt = null;
  let rimRho = 0;

  // head face and rim edge
  if (rim === 'rimfire') {
    const rho = Math.min(R / 2, (V.R1 - V.P1) / 2);
    rimRho = rho;
    for (let i = 0; i <= DRAWING_ARC_STEPS; i++) {
      const t = -Math.PI / 2 + (Math.PI * i) / DRAWING_ARC_STEPS;
      outline.push([R1h - rho + rho * Math.cos(t), rho + rho * Math.sin(t)]);
    }
    bodyZ = 2 * rho;
    outline.push([P1h, bodyZ]);
  } else {
    if (chamfer) {
      const x = Math.min(V.f * Math.tan(toRad(angleDeg(V.beta))), R1h / 2);
      outline.push([R1h - x, 0], [R1h, V.f]);
    } else {
      outline.push([R1h, 0]);
    }
    outline.push([R1h, R]);
    // extractor groove, or the belt ramp for belted cases
    if (belt) {
      const zFloor = R + V.eMin;
      const R3h = V.R3 / 2;
      zBelt = zFloor + (R3h - V.E1 / 2) / Math.tan(toRad(angleDeg(V.delta)));
      outline.push([V.E1 / 2, R], [V.E1 / 2, zFloor], [R3h, zBelt], [R3h, V.E], [P1h, V.E]);
      bodyZ = V.E;
    } else if (groove) {
      outline.push([V.E1 / 2, R], [V.E1 / 2, R + V.eMin], [P1h, V.E]);
      bodyZ = V.E;
    } else {
      outline.push([P1h, R]);
      bodyZ = R;
    }
  }

  // body, shoulder and neck
  if (bottleneck) {
    if (V.r1Min != null) corners.push({ i: outline.length, rho: V.r1Min });
    outline.push([V.P2 / 2, V.L1]);
    if (V.r2 != null) corners.push({ i: outline.length, rho: V.r2 });
    outline.push([V.H1 / 2, V.L2]);
    missing.push(...absent('r1Min', 'r2'));
  } else {
    missing.push(...absent('alpha', 'L1', 'L2', 'P2', 'H1'));
  }
  outline.push([H2h, V.L3]);
  for (const k of corners.sort((a, b) => b.i - a.i)) {
    outline.splice(k.i, 1, ...roundCorner(outline[k.i - 1], outline[k.i], outline[k.i + 1], k.rho));
  }
  if (!groove) missing.push(...absent('E', 'E1', 'eMin'));
  if (rim === 'belted' && !belt) missing.push(...absent('R3', 'delta'));
  if (rim !== 'rimfire' && !chamfer) missing.push(...absent('beta', 'f'));

  // walls: neck tn, body tb, and the solid head up to w
  const pocket = pocketOf(ann.primerType);
  const tn = Math.max(0, (V.H2 - V.G1) / 2);
  const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1h);
  const wallAt = (z) => {
    if (!bottleneck || z <= V.L1) return tb;
    if (z >= V.L2) return tn;
    return tb + ((tn - tb) * (z - V.L1)) / (V.L2 - V.L1);
  };
  let w = Math.max(2.5, 0.25 * P1h);
  if (pocket) w = Math.max(w, pocket.depth + 1.5);
  if (groove) w = Math.max(w, V.E + tb);
  if (zBelt != null) w = Math.max(w, zBelt + tb);
  const cavity = [[radiusAt(outline, w) - wallAt(w), w]];
  for (const p of outline) if (p[1] > w) cavity.push([p[0] - wallAt(p[1]), p[1]]);
  cavity.reverse();
  const pr = pocket ? pocket.r : 0;
  const pd = pocket ? pocket.depth : 0;
  const notch = pocket ? [[0, pd], [pr, pd], [pr, 0]] : [];
  const sectionWall = [[pr, 0]].concat(outline.slice(1), cavity, [[0, w]]);
  const sectionFill = sectionWall.concat(notch);

  // seated bullet, from the mouth to the tip at z = L6
  const shape = ann.defaultBulletShape;
  let bulletPts = [];
  const bullet = { zb: null, zc: null };
  const heeled = V.H2 - V.G1 <= 0.015;
  const rs = heeled ? H2h : G1h;
  if (shape) {
    const pistol = ann.category === 'pistol';
    const sFrac = shape === 'pointy' ? 1 : shape === 'semi_wadcutter' ? 0.6 : pistol ? 0.4 : 0.8;
    const kFrac = shape === 'pointy' ? 0.4 : shape === 'semi_wadcutter' ? 0.78 : shape === 'rounded' ? (pistol ? 0.65 : 0.55) : pistol ? 0.7 : 0.6;
    const m = shape === 'pointy' ? Math.max(0.08 * V.G1, 1.27) : shape === 'rounded' ? 0.15 * V.G1 : shape === 'flat' ? 0.55 * V.G1 : 0.6 * V.G1;
    const zb = V.L3 - sFrac * V.G1;
    const zc = zb + kFrac * (V.L6 - zb);
    bullet.zb = zb;
    bullet.zc = zc;
    if (heeled) bulletPts.push([H2h - tb, zb], [H2h - tb, V.L3], [rs, V.L3]);
    else bulletPts.push([rs, zb]);
    bulletPts.push([rs, zc], ...noseSamples(shape, rs, m, zc, V.L6), [0, V.L6]);
  }
  const exposed = [[rs, V.L3]].concat(bulletPts.filter((p) => p[1] > V.L3));

  // to SVG coordinates
  const sv = (pts, side) => pts.map(([r, z]) => [z, side * r]);
  const outside = sv(outline, -1);
  const bulletOutside = sv(exposed, -1);
  const wallSvg = sv(sectionWall, 1);
  const fillSvg = sv(sectionFill, 1);
  const bulletSection = bulletPts.length ? sv([[0, bullet.zb]].concat(bulletPts), 1) : [];

  // dimensions and labels
  const Rall = Math.max(...outline.map((p) => p[0]), ...bulletPts.map((p) => p[0]), 0);
  const top = (z) => {
    const vals = [edgeAt(outline, z), edgeAt(exposed, z)].filter((v) => !isNaN(v));
    return vals.length ? Math.max(...vals) : 0;
  };
  const OV = DRAWING_OVERSHOOT;
  const fs = DRAWING_FONT;
  const items = [];
  const label = (k) => `${symbolOf(k)} ${formatValue(k, V[k])}`;

  // lengths from the head face (R, L1, L2, L3, L6), stacked below the drawing, shortest nearest
  const lengths = ['R'];
  if (bottleneck) lengths.push('L1', 'L2');
  lengths.push('L3', 'L6');
  lengths.forEach((k, level) => {
    const zEnd = V[k];
    const yL = Rall + 3 + 6.5 * level;
    const A = [0, yL];
    const B = [zEnd, yL];
    items.push({
      text: label(k),
      lines: [[A, B], [[0, top(0) + 1], [0, yL + OV]], [[zEnd, top(zEnd) + 1], [zEnd, yL + OV]]],
      arrows: [arrowAt(A, unitVec(A, B)), arrowAt(B, unitVec(B, A))],
      cands: [
        { x: zEnd / 2, y: yL + OV + 1 + 0.8 * fs, anchor: 'middle' },
        { x: zEnd + 1.2, y: yL + 0.35 * fs, anchor: 'start' },
        { x: -1.2, y: yL + 0.35 * fs, anchor: 'end' }
      ]
    });
  });

  // R1: rim diameter in the margin in front of the head, with extension lines to the rim
  const zd = -4;
  const ze = rim === 'rimfire' ? rimRho : chamfer ? V.f : 0;
  items.push({
    text: label('R1'),
    lines: [[[zd, -R1h], [zd, R1h]], [[ze, -R1h], [zd - OV, -R1h]], [[ze, R1h], [zd - OV, R1h]]],
    arrows: [arrowAt([zd, -R1h], [0, 1]), arrowAt([zd, R1h], [0, -1])],
    cands: [
      { x: zd - 1.2, y: -R1h - 1.6, anchor: 'end' },
      { x: zd - 1.2, y: R1h + 1.6 + 0.8 * fs, anchor: 'end' },
      { x: zd - 1.2, y: 0.35 * fs, anchor: 'end' }
    ]
  });

  // diameters and the shoulder angle: called out above the drawing on staggered rows.
  // Sorted by leader position, a leader never crosses the label of a neighbour.
  const callouts = [];
  const diameter = (k, z, r) => {
    callouts.push({
      text: label(k),
      x: z,
      y: -(r + OV),
      dims: [[[z, -(r + OV)], [z, r + OV]]],
      arrows: [arrowAt([z, -r], [0, 1]), arrowAt([z, r], [0, -1])]
    });
  };
  if (has('P1')) diameter('P1', bodyZ, P1h);
  if (bottleneck) {
    diameter('P2', V.L1 - 0.6, V.P2 / 2);
    diameter('H1', V.L2, V.H1 / 2);
  }
  if (has('H2')) diameter('H2', V.L3 - 0.8, H2h);
  if (groove && has('E1')) diameter('E1', R + V.eMin / 2, V.E1 / 2);
  if (bullet.zb != null && has('G1')) diameter('G1', (V.L3 + bullet.zc) / 2, rs);

  // shoulder angle: an arc inside the cone, from the axis to the shoulder line
  if (bottleneck && has('alpha') && Math.abs(V.P2 - V.H1) > 1e-9) {
    const half = toRad(angleDeg(V.alpha)) / 2;
    const zA = V.L1 + ((V.P2 / 2) * (V.L2 - V.L1)) / (V.P2 / 2 - V.H1 / 2);
    const rA = (Math.hypot(zA - V.L1, V.P2 / 2) + Math.hypot(zA - V.L2, V.H1 / 2)) / 2;
    const arc = [];
    for (let i = 0; i <= DRAWING_ARC_STEPS; i++) {
      const th = (half * i) / DRAWING_ARC_STEPS;
      arc.push([zA - rA * Math.cos(th), -rA * Math.sin(th)]);
    }
    const n = arc.length - 1;
    const mid = arc[DRAWING_ARC_STEPS / 2];
    callouts.push({
      text: label('alpha'),
      x: mid[0],
      y: mid[1],
      dims: [arc],
      arrows: [arrowAt(arc[0], unitVec(arc[0], arc[1])), arrowAt(arc[n], unitVec(arc[n], arc[n - 1]))]
    });
  }
  callouts.sort((a, b) => b.x - a.x).forEach((c, k) => {
    const rowY = -(Rall + 2.5 + 4.6 * k);
    items.push({
      text: c.text,
      lines: c.dims.concat([[[c.x, c.y], [c.x, rowY]]]),
      arrows: c.arrows,
      cands: [{ x: c.x + 0.8, y: rowY, anchor: 'start' }]
    });
  });

  // obstacles: every drawn line, sampled, plus the case and bullet outlines
  const obstacles = [];
  const addLine = (pts) => {
    for (let i = 0; i + 1 < pts.length; i++) {
      const [a, b] = [pts[i], pts[i + 1]];
      const steps = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 0.25));
      for (let s = 0; s <= steps; s++) obstacles.push([a[0] + ((b[0] - a[0]) * s) / steps, a[1] + ((b[1] - a[1]) * s) / steps]);
    }
  };
  for (const pts of [outside, bulletOutside, wallSvg, bulletSection]) addLine(pts);
  for (const it of items) for (const seg of it.lines) addLine(seg);
  const labels = placeLabels(items, obstacles);

  // bounds, then the title block below everything
  const xs = obstacles.map((p) => p[0]).concat(labels.flatMap((l) => [l.x0, l.x1]));
  const ys = obstacles.map((p) => p[1]).concat(labels.flatMap((l) => [l.y0, l.y1]));
  const tbLines = [
    { text: rec.name, size: 3.6 },
    { text: `C.I.P. table ${rec.tab} · revised ${rec.revised}`, size: 2.8 },
    { text: 'Dimensions in mm', size: 2.8 },
    { text: 'Scale 1:1', size: 2.8 }
  ];
  const tbW = Math.max(70, Math.max(...tbLines.map((l) => l.text.length * DRAWING_CHAR_WIDTH * l.size)) + 6);
  const tbX = Math.min(...xs);
  const tbY = Math.max(...ys) + 3;
  const tbH = 21;
  const bounds = { x0: Math.min(...xs), x1: Math.max(Math.min(...xs) + tbW, ...xs), y0: Math.min(...ys), y1: tbY + tbH };
  const titleBlock = { x: tbX, y: tbY, w: tbW, h: tbH, lines: tbLines };

  return {
    key: rec.key,
    name: rec.name,
    rim,
    missing: [...new Set(missing)],
    outside,
    bulletOutside,
    section: { wall: wallSvg, fill: fillSvg, notch: sv(notch, 1) },
    pocket: pocket ? { r: pocket.r, depth: pocket.depth } : null,
    walls: { tn, tb, w },
    bullet: { zb: bullet.zb, zc: bullet.zc, section: bulletSection },
    dims: items.map((it) => ({ text: it.text, lines: it.lines, arrows: it.arrows })),
    labels,
    centre: { x0: bounds.x0, x1: bounds.x1 },
    titleBlock,
    bounds
  };
}

function textBox(cand, text, fs) {
  const w = text.length * DRAWING_CHAR_WIDTH * fs;
  const x0 = cand.anchor === 'start' ? cand.x : cand.anchor === 'end' ? cand.x - w : cand.x - w / 2;
  return { x0, x1: x0 + w, y0: cand.y - 0.8 * fs, y1: cand.y + 0.25 * fs };
}

// Takes the first candidate position whose box touches no drawn line and no earlier label.
function placeLabels(items, obstacles) {
  const placed = [];
  const margin = 0.5;
  const hits = (b) => {
    if (obstacles.some((p) => p[0] > b.x0 - margin && p[0] < b.x1 + margin && p[1] > b.y0 - margin && p[1] < b.y1 + margin)) return true;
    return placed.some((o) => b.x0 < o.x1 + margin && o.x0 < b.x1 + margin && b.y0 < o.y1 + margin && o.y0 < b.y1 + margin);
  };
  for (const it of items) {
    let pick = it.cands.find((c) => !hits(textBox(c, it.text, DRAWING_FONT))) || it.cands[0];
    const box = textBox(pick, it.text, DRAWING_FONT);
    placed.push(box);
    it.placed = Object.assign({ text: it.text, x: pick.x, y: pick.y, anchor: pick.anchor }, box);
  }
  return items.map((it) => it.placed);
}

function drawingSvg(m) {
  const path = (pts, closed) => pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(3)} ${p[1].toFixed(3)}`).join('') + (closed ? 'Z' : '');
  const b = m.bounds;
  const tb = m.titleBlock;
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const vb = [b.x0 - 2, b.y0 - 2, b.x1 - b.x0 + 4, b.y1 - b.y0 + 4].map((v) => v.toFixed(3)).join(' ');
  const dims = m.dims
    .map((d) => d.lines.map((seg) => `<path d="${path(seg)}"/>`).join('') + d.arrows.map((a) => `<path class="arrow" d="${path(a, true)}"/>`).join(''))
    .join('');
  const labels = m.labels.map((l) => `<text x="${l.x.toFixed(3)}" y="${l.y.toFixed(3)}" text-anchor="${l.anchor}">${esc(l.text)}</text>`).join('');
  const block = `<rect x="${tb.x}" y="${tb.y}" width="${tb.w}" height="${tb.h}"/>` +
    tb.lines.map((l, i) => `<text x="${tb.x + 2}" y="${(tb.y + 4.6 + i * 4.6).toFixed(3)}" font-size="${l.size}"${i ? '' : ' font-weight="600"'}>${esc(l.text)}</text>`).join('');
  return `<svg class="drawing" xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" role="img" aria-label="${esc(m.name)} drawing">` +
    `<defs><pattern id="hatch-${m.key}" patternUnits="userSpaceOnUse" width="1.2" height="1.2" patternTransform="rotate(45)"><path d="M0 0V1.2" stroke="currentColor" stroke-width="0.15"/></pattern></defs>` +
    `<path class="centre" d="M${m.centre.x0.toFixed(3)} 0H${m.centre.x1.toFixed(3)}"/>` +
    `<path class="outline" d="${path(m.outside)}"/>` +
    `<path class="outline" d="${path(m.bulletOutside)}"/>` +
    `<path class="fill" d="${path(m.section.fill, true)}" fill="url(#hatch-${m.key})" stroke="none"/>` +
    `<path class="line" d="${path(m.section.wall)}"/>` +
    (m.section.notch.length ? `<path class="line" d="${path(m.section.notch)}"/>` : '') +
    `<path class="line" d="${path(m.bullet.section, true)}"/>` +
    `<g class="dims">${dims}</g>` +
    `<g class="labels" font-size="${DRAWING_FONT}">${labels}</g>` +
    `<g class="titleblock">${block}</g>` +
    `</svg>`;
}
