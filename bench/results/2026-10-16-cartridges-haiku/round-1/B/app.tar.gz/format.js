// Display rules for the cartridge records: symbols, units, value cells, tables and search.

var SYMBOL_OVERRIDES = {
  eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
  beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
};
var ANGLE_FIELDS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
var UNIT_OVERRIDES = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
var GROUP_TITLES = {
  caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
  misc: 'Misc', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
  barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
};

function symbolOf(key) {
  return Object.prototype.hasOwnProperty.call(SYMBOL_OVERRIDES, key) ? SYMBOL_OVERRIDES[key] : key;
}

function isAngleField(key) {
  return ANGLE_FIELDS.indexOf(key) >= 0;
}

// Lengths and diameters are mm; the other units come from the brief.
function unitOf(key) {
  if (Object.prototype.hasOwnProperty.call(UNIT_OVERRIDES, key)) return UNIT_OVERRIDES[key];
  return isAngleField(key) ? '' : 'mm';
}

function formatAngle(v) {
  if (typeof v === 'number') return v + '°';
  return v.degrees + "°" + v.minutes + "'" + v.seconds + '"';
}

function formatValue(key, v) {
  return isAngleField(key) ? formatAngle(v) : String(v);
}

// One table per record group. "<X>Tol" is printed after X, not as a row of its own.
function groupRows(group) {
  const rows = [];
  for (const key of Object.keys(group)) {
    if (/Tol$/.test(key) && key.slice(0, -3) in group) continue;
    const tol = key + 'Tol' in group ? ' ' + group[key + 'Tol'] : '';
    rows.push({ symbol: symbolOf(key), value: formatValue(key, group[key]) + tol, unit: unitOf(key) });
  }
  return rows;
}

function sectionOf(title, obj) {
  const groups = [];
  for (const gKey of Object.keys(obj || {})) {
    const rows = groupRows(obj[gKey]);
    if (rows.length) groups.push({ title: GROUP_TITLES[gKey] || gKey, rows });
  }
  return { title, groups };
}

function recordSections(rec) {
  return [sectionOf('Cartridge', rec.cartridge), sectionOf('Chamber', rec.chamber)];
}

function normalizeSearch(s) {
  return s.toLowerCase().replace(/\s+/g, '');
}

// Spaces and case are ignored, so "7,62 x 51" and "7,62x51" both find "308 Win.".
function cartridgeMatches(rec, query) {
  const q = normalizeSearch(query);
  if (!q) return true;
  return [rec.name].concat(rec.alternativeNames || []).some((n) => normalizeSearch(n).indexOf(q) >= 0);
}

function filterCartridges(list, query, family) {
  return list.filter((r) => (!family || family === 'all' || r.family === family) && cartridgeMatches(r, query));
}

function countText(n) {
  return n + (n === 1 ? ' cartridge' : ' cartridges');
}
