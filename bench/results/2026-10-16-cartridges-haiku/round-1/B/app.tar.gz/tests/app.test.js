const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');

const ROOT = path.join(__dirname, '..');
const SCRIPTS = ['data.js', 'format.js', 'drawing.js', 'app.js'];

// Runs index.html's scripts in a DOM the way the browser does, with the hash set before loading.
function open(hash = '') {
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8').replace(/<script[^>]*><\/script>/g, '');
  const dom = new JSDOM(html, { url: 'file:///index.html' + hash, runScripts: 'outside-only' });
  const w = dom.window;
  w.scrollTo = () => {};
  w.print = () => { w.printed = (w.printed || 0) + 1; };
  for (const f of SCRIPTS) w.eval(fs.readFileSync(path.join(ROOT, f), 'utf8'));
  return w;
}

const input = (w, value) => {
  const q = w.document.getElementById('q');
  q.value = value;
  q.dispatchEvent(new w.Event('input'));
};
const names = (w) => [...w.document.querySelectorAll('#rows a')].map((a) => a.textContent);

test('start page: heading, 25 links with the exact names, count text, L3 column', () => {
  const w = open('#/');
  assert.equal(w.document.querySelector('h1').textContent, 'Cartridges');
  assert.equal(names(w).length, 25);
  assert.equal(w.document.getElementById('count').textContent, '25 cartridges');
  const row = w.document.querySelector('#rows tr');
  assert.equal(row.children[0].querySelector('a').getAttribute('href'), '#/cartridge/223_rem');
  assert.equal(row.children[2].textContent, '44.7 mm');
});

test('search finds by alternative name and updates the count', () => {
  const w = open('#/');
  input(w, '7,62 x 51');
  assert.deepEqual(names(w), ['308 Win.']);
  assert.equal(w.document.getElementById('count').textContent, '1 cartridge');
  input(w, '');
  assert.equal(names(w).length, 25);
});

test('family select filters, and combines with search', () => {
  const w = open('#/');
  const sel = w.document.getElementById('family');
  sel.value = 'rimfire';
  sel.dispatchEvent(new w.Event('change'));
  assert.equal(names(w).length, 3);
  assert.deepEqual([...sel.options].map((o) => o.textContent), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  input(w, '22');
  assert.deepEqual(names(w), ['22 Long Rifle', '22 Win. Mag. R.F.']);
});

test('detail view: heading, facts, drawing, tables grouped by section, print and back links', () => {
  const w = open('#/cartridge/223_rem');
  const d = w.document;
  assert.equal(d.querySelector('h1').textContent, '223 Rem.');
  assert.equal(d.title, '223 Rem. · Cartridges');
  assert.ok(d.querySelector('dl.facts').textContent.includes('C.I.P. table'));
  assert.ok(d.querySelector('dl.facts').textContent.includes('30.5 grH2O'));
  assert.equal(d.querySelector('dl.facts a').getAttribute('href'), 'http://kwk.us/cases.html');
  const svg = d.querySelector('svg.drawing');
  assert.equal(svg.getAttribute('aria-label'), '223 Rem. drawing');
  assert.equal(svg.getAttribute('role'), 'img');
  const headers = [...d.querySelectorAll('.section h2')].map((h) => h.textContent);
  assert.deepEqual(headers, ['Cartridge', 'Chamber']);
  const first = d.querySelector('.group table');
  assert.deepEqual([...first.querySelectorAll('th')].map((t) => t.textContent), ['Symbol', 'Value', 'Unit']);
  assert.ok([...d.querySelectorAll('td')].some((td) => td.textContent === '36.52 -0.2'));
  assert.ok(![...d.querySelectorAll('td')].some((td) => td.textContent === 'L1Tol'));
  d.getElementById('print').click();
  assert.equal(w.printed, 1);
  assert.equal(d.querySelector('a[href="#/"]').textContent, 'All cartridges');
  assert.ok(d.querySelector('footer.source').textContent.includes('C.I.P. TDCC, revised 2017-05-17'));
});

test('routing: a detail address renders on load and after hashchange; unknown key says so', () => {
  const w = open('#/cartridge/40_s_w');
  assert.equal(w.document.querySelector('h1').textContent, '40 S.& W.');
  assert.ok(w.document.querySelector('svg.drawing[aria-label="40 S.& W. drawing"]'));
  w.location.hash = '#/';
  w.dispatchEvent(new w.HashChangeEvent('hashchange'));
  assert.equal(w.document.querySelector('h1').textContent, 'Cartridges');
  w.location.hash = '#/cartridge/nope';
  w.dispatchEvent(new w.HashChangeEvent('hashchange'));
  assert.equal(w.document.querySelector('h1').textContent, 'Cartridge not found');
});

test('a drawing with unpublished values says which ones are not drawn', () => {
  const w = open('#/cartridge/22_long_rifle');
  const note = w.document.querySelector('.drawing-wrap .note');
  assert.ok(note.textContent.includes('e min'));
  assert.ok(note.textContent.includes('α'));
});
