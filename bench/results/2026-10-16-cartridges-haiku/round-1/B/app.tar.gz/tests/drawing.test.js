const { test } = require('node:test');
const assert = require('node:assert/strict');
const { load, plain } = require('./helpers');

const ctx = load(['format.js', 'drawing.js']);
const rec = (key) => ctx.CARTRIDGES.find((r) => r.key === key);
const model = (key) => plain(ctx.buildDrawing(rec(key)));
const near = (a, b, tol = 1e-3) => assert.ok(Math.abs(a - b) <= tol, `expected ${a} ≈ ${b}`);
const hasPoint = (pts, x, y, tol = 1e-3) => pts.some((p) => Math.abs(p[0] - x) <= tol && Math.abs(p[1] - y) <= tol);
const keys = ctx.CARTRIDGES.map((r) => r.key);

// Label boxes are [x0, x1] x [y0, y1]; sampled outline and dimension points must stay outside them.
function overlaps(box, p, margin = 0.3) {
  return p[0] > box.x0 - margin && p[0] < box.x1 + margin && p[1] > box.y0 - margin && p[1] < box.y1 + margin;
}

test('every record draws with finite coordinates and a label per dimension', () => {
  for (const key of keys) {
    const m = model(key);
    const all = [...m.outside, ...m.bulletOutside, ...m.section.wall, ...m.section.fill, ...m.bullet.section];
    for (const p of all) assert.ok(Number.isFinite(p[0]) && Number.isFinite(p[1]), key);
    assert.ok(m.labels.length >= 4, key);
    assert.ok(m.dims.length >= 4, key);
  }
});

test('labels never overlap each other, the outline, or dimension lines', () => {
  for (const key of keys) {
    const m = model(key);
    const pts = [...m.outside, ...m.bulletOutside, ...m.section.wall, ...m.bullet.section];
    for (const d of m.dims) for (const seg of d.lines) pts.push(...seg.flatMap((p, i) => (i ? [...samples([seg[i - 1], p])] : [p])));
    m.labels.forEach((a, i) => {
      for (const p of pts) assert.ok(!overlaps(a, p), `${key}: label ${a.text} touches a line at ${p}`);
      m.labels.slice(i + 1).forEach((b) => {
        const apart = a.x1 <= b.x0 || b.x1 <= a.x0 || a.y1 <= b.y0 || b.y1 <= a.y0;
        assert.ok(apart, `${key}: ${a.text} overlaps ${b.text}`);
      });
    });
    for (const a of m.labels) {
      assert.ok(a.x0 >= m.bounds.x0 && a.x1 <= m.bounds.x1 && a.y0 >= m.bounds.y0 && a.y1 <= m.bounds.y1, key);
    }
  }
});

function samples([a, b]) {
  const n = Math.max(2, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 0.25));
  return Array.from({ length: n + 1 }, (_, i) => [a[0] + ((b[0] - a[0]) * i) / n, a[1] + ((b[1] - a[1]) * i) / n]);
}

test('rim type follows the family and the R1/P1 ratio', () => {
  assert.equal(model('223_rem').rim, 'rimless');
  assert.equal(model('300_win_mag').rim, 'belted');
  assert.equal(model('22_long_rifle').rim, 'rimfire');
  assert.equal(model('7_x_65_r').rim, 'rimmed');
  assert.equal(model('38_special').rim, 'rimmed');
  assert.equal(model('40_s_w').rim, 'rimless');
});

test('wall thicknesses, solid head and primer pocket of 223 Rem.', () => {
  const m = model('223_rem');
  near(m.walls.tn, 0.365);
  near(m.walls.tb, 0.6);
  near(m.walls.w, 4.54);
  near(m.pocket.r, 4.45 / 2);
  near(m.pocket.depth, 3.04);
});

test('large rifle primers use the large pocket, with the deeper pocket for lr and lrm', () => {
  const p = model('338_lapua_mag').pocket;
  near(p.r, 5.33 / 2);
  near(p.depth, 3.3);
  assert.equal(model('22_long_rifle').pocket, null);
});

test('extractor groove: rim edge, floor and ramp follow E, E1 and e min', () => {
  const m = model('223_rem');
  // (r, z) = (4.215, 1.14) and (4.215, 1.90) on the upper outside outline
  assert.ok(hasPoint(m.outside, 1.14, -4.215));
  assert.ok(hasPoint(m.outside, 1.9, -4.215));
  assert.ok(hasPoint(m.outside, 3.13, -4.79));
});

test('belt ramp of 300 Win. Mag. runs out at delta to the axis and ends at z where the belt starts', () => {
  const m = model('300_win_mag');
  const zBelt = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  assert.ok(hasPoint(m.outside, zBelt, -13.51 / 2, 1e-2));
  assert.ok(hasPoint(m.outside, 5.59, -13.51 / 2));
  assert.ok(hasPoint(m.outside, 5.59, -13.03 / 2));
});

test('rimfire rim edge is a half round that ends at 2 * radius', () => {
  const m = model('22_long_rifle');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.ok(hasPoint(m.outside, 2 * rho, -(7.06 / 2 - rho), 1e-2));
});

test('heeled bullet: the seated heel has the case inside diameter H2 - 2 tb', () => {
  const m = model('22_long_rifle');
  near(m.walls.tb, 0.6);
  assert.ok(hasPoint(m.bullet.section, 15.57, 5.72 / 2 - 0.6, 1e-3));
  assert.ok(hasPoint(m.bulletOutside, 15.57, -5.72 / 2));
});

test('pointy bullet of 223 Rem.: base, cylinder end and tangent ogive to the meplat', () => {
  const m = model('223_rem');
  const G1 = 5.7, L3 = 44.7, L6 = 57.4;
  const zb = L3 - G1;
  const Lb = L6 - zb;
  const zc = zb + 0.4 * Lb;
  const rs = G1 / 2;
  const meplat = Math.max(0.08 * G1, 1.27);
  const n = L6 - zc;
  const a = rs - meplat / 2;
  const rho = (a * a + n * n) / (2 * a);
  near(m.bullet.zb, zb);
  near(m.bullet.zc, zc, 1e-2);
  assert.ok(hasPoint(m.bullet.section, zb, rs));
  assert.ok(hasPoint(m.bulletOutside, L6, -meplat / 2, 1e-2));
  // every nose sample lies on the ogive circle, centred on the radial line through the nose start
  const arc = m.bullet.section.filter((p) => p[0] > zc + 1e-6 && p[1] > meplat / 2 + 1e-3);
  assert.ok(arc.length > 3);
  for (const p of arc) near(Math.hypot(p[0] - zc, p[1] - (rs - rho)), rho, 1e-6);
});

test('seating depth: 0.6 G1 for semi wadcutters, 0.4 G1 for pistol rounded noses', () => {
  near(model('357_magnum').bullet.zb, 32.77 - 0.6 * 9.12, 1e-6);
  near(model('9_mm_luger').bullet.zb, 19.15 - 0.4 * 9.03, 1e-6);
  near(model('22_long_rifle').bullet.zb, 15.57 - 0.8 * 5.72, 1e-6);
});

test('a missing value removes its feature and is reported by name', () => {
  const rimfire = model('22_long_rifle');
  for (const k of ['E', 'E1', 'eMin', 'L1', 'L2', 'alpha', 'P2', 'H1']) assert.ok(rimfire.missing.includes(k), k);
  assert.ok(!rimfire.missing.includes('beta'));
  assert.ok(!rimfire.missing.includes('G1'));
  const luger = model('9_mm_luger');
  assert.ok(!luger.missing.includes('E'));
  assert.ok(luger.missing.includes('alpha'));
  assert.deepEqual(model('223_rem').missing, []);
});

test('the drawing is an accessible inline SVG with 1 unit = 1 mm and the scale in the title block', () => {
  const svg = ctx.drawingSvg(ctx.buildDrawing(rec('40_s_w')));
  assert.ok(svg.startsWith('<svg'));
  assert.ok(svg.includes('role="img"'));
  assert.ok(svg.includes('aria-label="40 S.&amp; W. drawing"'));
  assert.ok(svg.includes('viewBox="'));
  assert.ok(svg.includes('Scale 1:1'));
  assert.ok(svg.includes('Dimensions in mm'));
});

test('labels carry the symbol and the published value', () => {
  const texts = model('223_rem').labels.map((l) => l.text);
  for (const t of ['L3 44.7', 'L6 57.4', 'R1 9.6', 'R 1.14', 'P1 9.58', 'α 46°', 'E1 8.43']) {
    assert.ok(texts.includes(t), `${t} in ${texts}`);
  }
});
