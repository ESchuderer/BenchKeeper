const { test } = require('node:test');
const assert = require('node:assert/strict');
const { load, plain } = require('./helpers');

const ctx = load(['format.js']);
const rec = (key) => ctx.CARTRIDGES.find((r) => r.key === key);

test('symbols are the field name except the mapped ones', () => {
  const s = (k) => ctx.symbolOf(k);
  assert.equal(s('eMin'), 'e min');
  assert.equal(s('r1Min'), 'r1 min');
  assert.equal(s('r1Max'), 'r1 max');
  assert.equal(s('alpha'), 'α');
  assert.equal(s('alpha1'), 'α1');
  assert.equal(s('beta'), 'β');
  assert.equal(s('delta'), 'δ');
  assert.equal(s('deltaL'), 'delta L');
  assert.equal(s('L3PlusG'), 'L3 + G');
  assert.equal(s('E1'), 'E1');
  assert.equal(s('i'), 'i');
  assert.equal(s('r2'), 'r2');
});

test('angles are shown as degrees, or degrees minutes seconds', () => {
  assert.equal(ctx.formatAngle(40), '40°');
  assert.equal(ctx.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
});

test('units follow the brief; N and angles have no unit cell', () => {
  assert.equal(ctx.unitOf('Pmax'), 'bar');
  assert.equal(ctx.unitOf('PE'), 'bar');
  assert.equal(ctx.unitOf('EE'), 'J');
  assert.equal(ctx.unitOf('M'), 'g');
  assert.equal(ctx.unitOf('Q'), 'mm²');
  assert.equal(ctx.unitOf('N'), '');
  assert.equal(ctx.unitOf('alpha'), '');
  assert.equal(ctx.unitOf('L3'), 'mm');
});

test('a tolerance is shown next to its value and never as a row', () => {
  const rows = plain(ctx.recordSections(rec('223_rem')))[0].groups.find((g) => g.title === 'Lengths').rows;
  const l1 = rows.find((r) => r.symbol === 'L1');
  assert.deepEqual(l1, { symbol: 'L1', value: '36.52 -0.2', unit: 'mm' });
  assert.ok(!rows.some((r) => r.symbol.endsWith('Tol')));
});

test('cartridge and chamber values are grouped in sections, values as published', () => {
  const sections = plain(ctx.recordSections(rec('223_rem')));
  assert.deepEqual(sections.map((s) => s.title), ['Cartridge', 'Chamber']);
  const cart = sections[0].groups;
  assert.equal(cart[0].title, 'Case head');
  assert.deepEqual(cart[0].rows[0], { symbol: 'E', value: '3.13', unit: 'mm' });
  const beta = cart[0].rows.find((r) => r.symbol === 'β');
  assert.deepEqual(beta, { symbol: 'β', value: '35°', unit: '' });
  const pmax = cart.find((g) => g.title === 'Pressures').rows.find((r) => r.symbol === 'Pmax');
  assert.deepEqual(pmax, { symbol: 'Pmax', value: '4300', unit: 'bar' });
  const i = sections[1].groups.find((g) => g.title === 'Rifling').rows.find((r) => r.symbol === 'i');
  assert.equal(i.value, `3°10'36"`);
  const n = sections[1].groups.find((g) => g.title === 'Grooves').rows.find((r) => r.symbol === 'N');
  assert.deepEqual(n, { symbol: 'N', value: '6', unit: '' });
});

test('empty groups are left out', () => {
  const pistol = plain(ctx.recordSections(rec('9_mm_luger')))[0].groups.map((g) => g.title);
  assert.ok(!pistol.includes('Junction cone'));
});

test('search matches name and alternative names, ignoring spaces and case', () => {
  const names = (q, fam = 'all') => plain(ctx.filterCartridges(ctx.CARTRIDGES, q, fam)).map((r) => r.key);
  assert.deepEqual(names('7,62 x 51'), ['308_win']);
  assert.deepEqual(names('7,62x51'), ['308_win']);
  assert.deepEqual(names('308 win'), ['308_win']);
  assert.deepEqual(names('22lr'), ['22_long_rifle']);
  assert.deepEqual(names('  '), names(''));
  assert.equal(names('').length, 25);
});

test('family filter combines with search', () => {
  assert.equal(ctx.filterCartridges(ctx.CARTRIDGES, '', 'rimfire').length, 3);
  assert.equal(ctx.filterCartridges(ctx.CARTRIDGES, '', 'belted').length, 2);
  assert.equal(ctx.filterCartridges(ctx.CARTRIDGES, '', 'rimmed').length, 2);
  assert.equal(ctx.filterCartridges(ctx.CARTRIDGES, '', 'pistol').length, 6);
  assert.equal(ctx.filterCartridges(ctx.CARTRIDGES, '', 'rimless').length, 12);
  assert.deepEqual(ctx.filterCartridges(ctx.CARTRIDGES, '308', 'pistol').length, 0);
});

test('count text is pluralised', () => {
  assert.equal(ctx.countText(1), '1 cartridge');
  assert.equal(ctx.countText(25), '25 cartridges');
  assert.equal(ctx.countText(0), '0 cartridges');
});
