// Loads the browser scripts into one vm context, as the page does with plain <script> tags.
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');

function load(files = ['format.js', 'drawing.js']) {
  const ctx = {};
  vm.createContext(ctx);
  for (const f of ['data.js', ...files]) {
    vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), ctx, { filename: f });
  }
  return ctx;
}

// Objects made inside the vm context have another realm's prototypes; copy them out before deepStrictEqual.
const plain = (x) => JSON.parse(JSON.stringify(x));

module.exports = { load, plain };
