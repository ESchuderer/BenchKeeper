// Start page, detail view and hash routing. Uses CARTRIDGES, format.js and drawing.js.
var catalogueState = { query: '', family: 'All' };

function normalizeText(text) {
  return text.toLowerCase().replace(/\s+/g, ' ').trim();
}

function filterCartridges(list, options) {
  const query = normalizeText(options.query || '');
  const family = options.family || 'All';
  return list.filter((c) => {
    if (family !== 'All' && c.family !== family) return false;
    if (query === '') return true;
    return [c.name, ...(c.alternativeNames || [])].some((n) => normalizeText(n).includes(query));
  });
}

function countText(n) {
  return n === 1 ? '1 cartridge' : `${n} cartridges`;
}

function escapeHtml(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function renderResults(list) {
  const shown = filterCartridges(list, catalogueState);
  document.getElementById('count').textContent = countText(shown.length);
  document.getElementById('results').innerHTML = shown.map((c) => `
    <tr>
      <td><a href="#/cartridge/${escapeHtml(c.key)}">${escapeHtml(c.name)}</a></td>
      <td>${escapeHtml(c.family)}</td>
      <td class="num">${escapeHtml(formatWithTol(c.cartridge.lengths.L3, c.cartridge.lengths.L3Tol))} mm</td>
    </tr>`).join('');
}

function renderList(root, list) {
  const families = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']
    .map((f) => `<option${f === catalogueState.family ? ' selected' : ''}>${f}</option>`).join('');
  root.innerHTML = `
    <h1>Cartridges</h1>
    <form class="controls" role="search" onsubmit="return false">
      <label>Search <input id="search" type="search" autocomplete="off" value="${escapeHtml(catalogueState.query)}"></label>
      <label>Family <select id="family">${families}</select></label>
    </form>
    <p id="count" class="count"></p>
    <table class="cartridges">
      <thead><tr><th>Name</th><th>Family</th><th class="num">L3</th></tr></thead>
      <tbody id="results"></tbody>
    </table>`;
  document.getElementById('search').addEventListener('input', (e) => {
    catalogueState.query = e.target.value;
    renderResults(list);
  });
  document.getElementById('family').addEventListener('change', (e) => {
    catalogueState.family = e.target.value;
    renderResults(list);
  });
  renderResults(list);
}

function fieldList(pairs) {
  return pairs.map(([term, value]) => `<dt>${term}</dt><dd>${value}</dd>`).join('');
}

function renderDetail(root, c) {
  const cap = c.annotations.publishedCapacity;
  const dash = (v) => (v === undefined || v === '' ? '—' : escapeHtml(v));
  const water = cap
    ? `${escapeHtml(cap.grH2O)} grH2O, source <a href="${escapeHtml(cap.url)}">${escapeHtml(cap.source)}</a>${cap.note ? `<span class="note">${escapeHtml(cap.note)}</span>` : ''}`
    : '—';
  const drawing = renderDrawing(c);
  const missing = drawing.missing.length ? `<p class="notes">Not drawn, value missing: ${escapeHtml(drawing.missing.join(', '))}</p>` : '';
  const sections = sectionsOf(c);
  const table = (s) => `
    <section class="table">
      <h3>${escapeHtml(s.title)}</h3>
      <table>
        <thead><tr><th>Symbol</th><th class="num">Value</th><th>Unit</th></tr></thead>
        <tbody>${s.rows.map((r) => `<tr><td>${escapeHtml(r.symbol)}</td><td class="num">${escapeHtml(r.value)}</td><td>${escapeHtml(r.unit)}</td></tr>`).join('')}</tbody>
      </table>
    </section>`;
  root.innerHTML = `
    <div class="controls-bar">
      <a class="back" href="#/">All cartridges</a>
      <button type="button" class="print" id="print">Print</button>
    </div>
    <article class="detail">
      <h1>${escapeHtml(c.name)}</h1>
      <dl class="header">
        ${fieldList([
          ['Alternative names', dash((c.alternativeNames || []).join(', ') || undefined)],
          ['Family', dash(c.family)],
          ['Category', dash(c.annotations.category)],
          ['Primer type', dash(c.annotations.primerType)],
          ['C.I.P. table', dash(c.tab)],
          ['Country', dash(c.country)],
          ['Published', dash(c.published)],
          ['Revised', dash(c.revised)],
          ['Pressure method', dash(c.pressureMethod)],
          ['Water capacity', water],
        ])}
      </dl>
      <figure class="drawing-wrap">${drawing.svg}${missing}</figure>
      <div class="sections">
        <h2>Cartridge</h2>
        ${sections.cartridge.map(table).join('')}
        <h2>Chamber</h2>
        ${sections.chamber.map(table).join('')}
      </div>
      <footer class="source">Source: C.I.P. TDCC, revised ${escapeHtml(c.revised)}</footer>
    </article>`;
  document.getElementById('print').addEventListener('click', () => window.print());
}

function renderNotFound(root) {
  root.innerHTML = `<h1>Cartridge not found</h1><p><a href="#/">All cartridges</a></p>`;
}

// Returns "" for a malformed percent-encoding, which then matches no cartridge.
function safeDecode(text) {
  try {
    return decodeURIComponent(text);
  } catch (e) {
    return "";
  }
}

function render() {
  const root = document.getElementById('app');
  const match = /^#\/cartridge\/(.+)$/.exec(location.hash);
  if (!match && !/^#\/cartridge\//.test(location.hash)) {
    document.title = 'Cartridges';
    renderList(root, CARTRIDGES);
    return;
  }
  const key = safeDecode(match ? match[1] : '');
  const c = key && CARTRIDGES.find((r) => r.key === key);
  if (!c) {
    document.title = 'Cartridge not found';
    renderNotFound(root);
    return;
  }
  document.title = `${c.name} · Cartridges`;
  renderDetail(root, c);
  window.scrollTo(0, 0);
}

if (typeof module !== 'undefined') {
  module.exports = { filterCartridges, countText, normalizeText };
} else {
  window.addEventListener('hashchange', render);
  render();
}
