// Scaled cartridge drawing. Geometry is in (z, r) millimetres: z runs along the axis from the head
// face, r is the radius. The SVG draws the outside view at y = -r and the section at y = +r.
var drawingFormat = typeof module !== 'undefined'
  ? require('./format.js')
  : { degrees: degrees, formatAngle: formatAngle, formatNumber: formatNumber };

var TEXT_HEIGHT = 3;
var CHAR_WIDTH = 0.6 * TEXT_HEIGHT;
var ARROW_LENGTH = 2;
var ARROW_HALF_WIDTH = 0.6;
var POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };
// s: seating depth below the mouth, k: cylinder length fraction of Lb, m: meplat diameter (all times G1 or mm).
var BULLET_SHAPES = {
  pointy: (g) => ({ s: g, k: 0.40, m: Math.max(0.08 * g, 1.27) }),
  rounded: (g, pistol) => ({ s: pistol ? 0.4 * g : 0.8 * g, k: pistol ? 0.65 : 0.55, m: 0.15 * g }),
  flat: (g, pistol) => ({ s: pistol ? 0.4 * g : 0.8 * g, k: pistol ? 0.70 : 0.60, m: 0.55 * g }),
  semi_wadcutter: (g) => ({ s: 0.6 * g, k: 0.78, m: 0.6 * g }),
};

function rimTypeOf(record) {
  if (record.family === 'belted' || record.family === 'rimfire') return record.family;
  const ratio = record.cartridge.caseHead.R1 / record.cartridge.powderChamber.P1;
  if (ratio >= 1.05) return 'rimmed';
  if (ratio < 0.98) return 'rebated';
  return 'rimless';
}

// Radius of a profile at z, from the first non-vertical segment that spans z.
function radiusAt(profile, z) {
  for (let i = 1; i < profile.length; i++) {
    const [z0, r0] = profile[i - 1];
    const [z1, r1] = profile[i];
    if (z1 !== z0 && z >= Math.min(z0, z1) && z <= Math.max(z0, z1)) {
      return r0 + (r1 - r0) * (z - z0) / (z1 - z0);
    }
  }
  return undefined;
}

// Tangent arc of radius rho at the corner prev-corner-next; null when the tangent points do not fit.
function filletArc(prev, corner, next, rho) {
  const dist = (a, b) => Math.hypot(b[0] - a[0], b[1] - a[1]);
  const unit = (a, b) => {
    const d = dist(a, b);
    return [(b[0] - a[0]) / d, (b[1] - a[1]) / d];
  };
  const d1 = unit(prev, corner);
  const d2 = unit(corner, next);
  const cross = d1[0] * d2[1] - d1[1] * d2[0];
  const turn = Math.acos(Math.min(1, Math.max(-1, d1[0] * d2[0] + d1[1] * d2[1])));
  if (turn < 1e-6) return [corner];
  const t = rho * Math.tan(turn / 2);
  if (t > 0.5 * Math.min(dist(prev, corner), dist(corner, next))) return null;
  const t1 = [corner[0] - d1[0] * t, corner[1] - d1[1] * t];
  const t2 = [corner[0] + d2[0] * t, corner[1] + d2[1] * t];
  const side = cross > 0 ? 1 : -1;
  const o = [t1[0] - d1[1] * side * rho, t1[1] + d1[0] * side * rho];
  const a1 = Math.atan2(t1[1] - o[1], t1[0] - o[0]);
  const sweep0 = Math.atan2(t2[1] - o[1], t2[0] - o[0]) - a1;
  const sweep = Math.atan2(Math.sin(sweep0), Math.cos(sweep0));
  const arc = [];
  for (let i = 0; i <= 12; i++) {
    const a = a1 + sweep * i / 12;
    arc.push([o[0] + rho * Math.cos(a), o[1] + rho * Math.sin(a)]);
  }
  return arc;
}

function svgEscape(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Outer profile from the axis at the head face to the mouth, with fillets, and the wall function.
function caseProfile(record, missing) {
  const { cartridge: c } = record;
  const cap = c.caseHead;
  const ln = c.lengths;
  const jc = c.junctionCone || {};
  const deg = drawingFormat.degrees;
  const { R, R1, E, E1, eMin } = cap;
  const Rh = R1 / 2;
  const P1 = c.powderChamber.P1;
  const Rb = P1 / 2;
  const { L3 } = ln;
  const H2 = c.collar.H2;
  const G1 = c.projectile.G1;
  const rim = rimTypeOf(record);
  const groove = E !== undefined && E1 !== undefined && eMin !== undefined;
  const bottleneck = jc.alpha !== undefined && ln.L1 !== undefined && ln.L2 !== undefined
    && c.powderChamber.P2 !== undefined && c.collar.H1 !== undefined;
  const raw = [{ p: [0, 0] }];
  let rimR = Rh;
  let rampEnd;
  let beltDrawn = false;

  if (rim === 'rimfire') {
    const rho = Math.min(R / 2, (R1 - P1) / 2);
    for (let i = 0; i <= 12; i++) {
      const th = -Math.PI / 2 + Math.PI * i / 12;
      raw.push({ p: [rho + rho * Math.sin(th), (Rh - rho) + rho * Math.cos(th)] });
    }
    rimR = Rh - rho;
    if (R > 2 * rho + 1e-9) raw.push({ p: [R, rimR] });
  } else {
    if (cap.beta !== undefined && cap.f !== undefined && deg(cap.beta) < 90) {
      const cut = Math.min(cap.f * Math.tan(deg(cap.beta) * Math.PI / 180), R1 / 4);
      raw.push({ p: [0, Rh - cut] }, { p: [cap.f, Rh] });
    } else {
      raw.push({ p: [0, Rh] });
    }
    raw.push({ p: [R, Rh] });
  }

  if (groove) {
    raw.push({ p: [R, E1 / 2] }, { p: [R + eMin, E1 / 2] });
    if (rim === 'belted' && cap.R3 !== undefined && cap.delta !== undefined) {
      const rampLength = (cap.R3 / 2 - E1 / 2) / Math.tan(deg(cap.delta) * Math.PI / 180);
      rampEnd = R + eMin + rampLength;
      if (rampEnd < E) {
        raw.push({ p: [rampEnd, cap.R3 / 2] }, { p: [E, cap.R3 / 2] });
        beltDrawn = true;
      }
    } else if (rim === 'belted') {
      missing.push(cap.R3 === undefined ? 'R3' : 'delta');
    }
    raw.push({ p: [E, Rb] });
  } else {
    raw.push({ p: [R, Rb] });
  }
  const bodyStart = raw[raw.length - 1].p[0];

  if (bottleneck) {
    raw.push({ p: [ln.L1, c.powderChamber.P2 / 2], fillet: jc.r1Min === undefined ? undefined : { name: 'r1Min', rho: jc.r1Min } });
    raw.push({ p: [ln.L2, c.collar.H1 / 2], fillet: jc.r2 === undefined ? undefined : { name: 'r2', rho: jc.r2 } });
  }
  raw.push({ p: [L3, H2 / 2] });

  const outer = [];
  raw.forEach((item, i) => {
    if (!item.fillet) {
      outer.push(item.p);
      return;
    }
    const arc = filletArc(raw[i - 1].p, item.p, raw[i + 1].p, item.fillet.rho);
    if (arc) {
      outer.push(...arc);
    } else {
      outer.push(item.p);
      missing.push(`${item.fillet.name} (fillet does not fit)`);
    }
  });

  const tn = (H2 - G1) / 2;
  const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * Rb);
  const zA = bottleneck ? ln.L1 : bodyStart;
  const zB = bottleneck ? ln.L2 : L3;
  const wall = (z) => (z <= zA ? tb : z >= zB ? tn : tb + (tn - tb) * (z - zA) / (zB - zA));
  return { outer, rim, groove, bottleneck, beltDrawn, rampEnd, tb, tn, wall, Rh, Rb, R, E, E1, eMin, H2, G1, L3, bodyStart };
}

function pocketOf(primerType, missing) {
  if (POCKET_DIAMETER[primerType] === undefined) {
    missing.push('primerType');
    return null;
  }
  return { d: POCKET_DIAMETER[primerType], depth: POCKET_DEPTH[primerType] };
}

// Bullet outline from the base to the tip. `full` closes the section, `exposed` is the outside view.
function bulletProfile(record, cp, missing) {
  const { cartridge: c, annotations: ann } = record;
  const G1 = c.projectile.G1;
  const { L3, L6 } = c.lengths;
  const shape = BULLET_SHAPES[ann.defaultBulletShape];
  if (L6 === undefined || !shape) {
    missing.push(L6 === undefined ? 'L6' : 'defaultBulletShape');
    return null;
  }
  const { s, k, m } = shape(G1, ann.category === 'pistol');
  const heeled = c.collar.H2 - G1 <= 0.015;
  const rsExp = heeled ? c.collar.H2 / 2 : G1 / 2;
  const r0 = heeled ? c.collar.H2 / 2 - cp.tb : G1 / 2;
  const zb = L3 - s;
  const zc = zb + k * (L6 - zb);
  const n = L6 - zc;
  const rm = m / 2;
  const nose = [];
  if (ann.defaultBulletShape === 'pointy') {
    const rr = rsExp - rm;
    const rhoN = (rr * rr + n * n) / (2 * rr);
    const rc = rsExp - rhoN;
    for (let i = 0; i <= 12; i++) {
      const r = rsExp + (rm - rsExp) * i / 12;
      nose.push([zc + Math.sqrt(Math.max(0, rhoN * rhoN - (r - rc) ** 2)), r]);
    }
  } else if (ann.defaultBulletShape === 'rounded') {
    for (let i = 0; i <= 12; i++) {
      const th = Math.PI / 2 * i / 12;
      nose.push([zc + n * Math.sin(th), rm + (rsExp - rm) * Math.cos(th)]);
    }
  } else {
    nose.push([zc, rsExp], [L6, rm]);
  }
  const seated = [[zb, 0], [zb, r0]];
  if (heeled) seated.push([L3, r0], [L3, rsExp]);
  return {
    full: [...seated, ...nose, [L6, 0]],
    exposed: [[L3, rsExp], [zc, rsExp], ...nose.slice(1), [L6, 0]],
    zc, L6, meplat: rm, rsExp,
  };
}

function arrowPolygon(tip, out) {
  const base = [tip[0] - out[0] * ARROW_LENGTH, tip[1] - out[1] * ARROW_LENGTH];
  const perp = [-out[1] * ARROW_HALF_WIDTH, out[0] * ARROW_HALF_WIDTH];
  return [tip, [base[0] + perp[0], base[1] + perp[1]], [base[0] - perp[0], base[1] - perp[1]]];
}

// Label box in SVG coordinates. Horizontal: (x, y) is the centre of the baseline. Rotated -90°: (x, y) is
// the baseline position on x and the centre on y.
function labelAt(text, x, y, rotated) {
  const w = text.length * CHAR_WIDTH;
  const box = rotated
    ? { x0: x - TEXT_HEIGHT, x1: x + 0.6, y0: y - w / 2, y1: y + w / 2 }
    : { x0: x - w / 2, x1: x + w / 2, y0: y - TEXT_HEIGHT, y1: y + 0.6 };
  return { text, x, y, rotated, box };
}

function jcAlpha(c) {
  return (c.junctionCone || {}).alpha;
}

// Builds the complete drawing model: outlines, dimension lines, arrowheads, labels and bounds.
function drawingModel(record) {
  const missing = [];
  const { cartridge: c, annotations: ann } = record;
  const required = {
    'caseHead.R': c.caseHead.R, 'caseHead.R1': c.caseHead.R1, 'powderChamber.P1': c.powderChamber.P1,
    'lengths.L3': c.lengths.L3, 'collar.H2': c.collar.H2, 'projectile.G1': c.projectile.G1,
  };
  for (const [name, v] of Object.entries(required)) if (v === undefined) missing.push(name);
  if (missing.length) return { key: record.key, name: record.name, ok: false, missing };

  const fmt = drawingFormat.formatNumber;
  const angle = drawingFormat.formatAngle;
  const cp = caseProfile(record, missing);
  const pocket = cp.rim === 'rimfire' ? null : pocketOf(ann.primerType, missing);
  const bullet = bulletProfile(record, cp, missing);
  const { Rh, Rb, R, L3, H2, G1, outer } = cp;

  // Section: solid head to w, cavity inside the walls, primer pocket.
  const wCands = [2.5, 0.25 * Rb];
  if (pocket) wCands.push(pocket.depth + 1.5);
  if (cp.beltDrawn) wCands.push(cp.rampEnd + cp.tb);
  else if (cp.groove) wCands.push(cp.E + cp.tb);
  const w = Math.max(...wCands);
  const inner = [[w, radiusAt(outer, w) - cp.wall(w)]];
  for (const [z, r] of outer) if (z > w) inner.push([z, r - cp.wall(z)]);
  const section = [pocket ? [0, pocket.d / 2] : [0, 0], ...outer.slice(1), ...inner.slice().reverse(), [w, 0]];
  if (pocket) section.push([pocket.depth, 0], [pocket.depth, pocket.d / 2]);

  // Dimension annotations.
  const lines = [];
  const arrows = [];
  const labels = [];
  // Label defaults to the centre above the line; labelX and labelY override it.
  const dimH = (x1, x2, y, text, labelX, labelY) => {
    lines.push([x1, y, x2, y]);
    arrows.push(arrowPolygon([x1, y], [-1, 0]), arrowPolygon([x2, y], [1, 0]));
    labels.push(labelAt(text, labelX ?? (x1 + x2) / 2, labelY ?? y - 0.8, false));
  };
  const dimV = (x, y1, y2) => {
    lines.push([x, y1, x, y2]);
    arrows.push(arrowPolygon([x, y1], [0, Math.sign(y1 - y2)]), arrowPolygon([x, y2], [0, Math.sign(y2 - y1)]));
  };
  const ext = (x1, y1, x2, y2) => lines.push([x1, y1, x2, y2]);

  // Top rows, nearest the part for the shortest span. Extension lines run from the object point to the row.
  const rows = { L1: -Rh - 4, L2: -Rh - 9, L3: -Rh - 14, L6: -Rh - 19 };
  const topDim = (key, x, yObj) => {
    ext(x, yObj - 0.5, x, rows[key] - 1);
    dimH(0, x, rows[key], `${key} ${fmt(c.lengths[key])}`);
  };
  ext(0, -Rh - 0.5, 0, rows.L6 - 1);
  if (cp.bottleneck) topDim('L1', c.lengths.L1, -c.powderChamber.P2 / 2);
  if (cp.bottleneck) topDim('L2', c.lengths.L2, -c.collar.H1 / 2);
  topDim('L3', L3, -H2 / 2);
  if (bullet) topDim('L6', bullet.L6, -bullet.meplat);

  // R1 left of the head; R along the bottom of the rim.
  dimV(-4, -Rh, Rh);
  labels.push(labelAt(`R1 ${fmt(c.caseHead.R1)}`, -6.4, 0, true));
  ext(-0.5, -Rh, -5, -Rh);
  ext(-0.5, Rh, -5, Rh);
  const rimAtR = radiusAt(outer, R) ?? Rh;
  const rText = `R ${fmt(R)}`;
  dimH(0, R, Rh + 3, rText, R + 1.5 + (rText.length * CHAR_WIDTH) / 2, Rh + 3.8);
  ext(0, Rh + 0.5, 0, Rh + 4);
  ext(R, rimAtR, R, Rh + 4);

  // Diameters: vertical dimension columns beyond the tip, labels alternating above and below the axis.
  const diameters = [];
  if (bullet) diameters.push({ key: 'G1', z: bullet.zc, r: bullet.rsExp, value: G1 });
  diameters.push({ key: 'H2', z: L3, r: H2 / 2, value: H2 });
  if (cp.bottleneck) diameters.push({ key: 'H1', z: c.lengths.L2, r: c.collar.H1 / 2, value: c.collar.H1 });
  if (cp.groove) diameters.push({ key: 'E1', z: R + cp.eMin, r: cp.E1 / 2, value: cp.E1 });
  if (cp.bottleneck) diameters.push({ key: 'P2', z: c.lengths.L1, r: c.powderChamber.P2 / 2, value: c.powderChamber.P2 });
  diameters.push({ key: 'P1', z: cp.groove ? cp.E : R, r: Rb, value: c.powderChamber.P1 });
  const columnStart = (bullet ? bullet.L6 : L3) + 9;
  diameters.forEach((d, i) => {
    const x = columnStart + 8 * i;
    ext(d.z, d.r, x + 1, d.r);
    ext(d.z, -d.r, x + 1, -d.r);
    dimV(x, -d.r, d.r);
    labels.push(labelAt(`${d.key} ${fmt(d.value)}`, x, i % 2 === 0 ? -(Rb + 4.2) : Rb + 4.2, false));
  });
  const columnEnd = columnStart + 8 * (diameters.length - 1) + 4;

  let alphaArc = null;
  // Included shoulder angle alpha: arc about the cone apex from one shoulder line to the other; label below the shoulder.
  if (cp.bottleneck && jcAlpha(c) !== undefined && c.junctionCone.S !== undefined) {
    const half = drawingFormat.degrees(c.junctionCone.alpha) * Math.PI / 360;
    const S = c.junctionCone.S;
    const midZ = (c.lengths.L1 + c.lengths.L2) / 2;
    const midR = (c.powderChamber.P2 / 2 + c.collar.H1 / 2) / 2;
    const rho = Math.hypot(S - midZ, midR);
    const arc = [];
    for (let i = 0; i <= 10; i++) {
      const phi = -half + 2 * half * i / 10;
      arc.push([S - rho * Math.cos(phi), -rho * Math.sin(phi)]);
    }
    alphaArc = { apex: [S, 0], rho, points: arc };
    for (let i = 1; i < arc.length; i++) ext(arc[i - 1][0], arc[i - 1][1], arc[i][0], arc[i][1]);
    const unit = (a, b) => {
      const d = Math.hypot(b[0] - a[0], b[1] - a[1]);
      return [(b[0] - a[0]) / d, (b[1] - a[1]) / d];
    };
    const last = arc.length - 1;
    arrows.push(arrowPolygon(arc[0], unit(arc[1], arc[0])), arrowPolygon(arc[last], unit(arc[last - 1], arc[last])));
    labels.push(labelAt(`α ${angle(c.junctionCone.alpha)}`, midZ, Rb + 4.2, false));
  }

  // Bounds in mm: from the R1 label on the left to the last diameter column, title block below.
  const bounds = { x0: -10, x1: Math.max(columnEnd + 3, L3 + 9), y0: -(Rh + 23), y1: Rh + 17 };
  return {
    key: record.key, name: record.name, ok: true, missing: [...new Set(missing)],
    upper: [...outer.map(([z, r]) => [z, -r]), ...(bullet ? bullet.exposed.map(([z, r]) => [z, -r]) : [])],
    section, bulletSection: bullet ? bullet.full : null,
    lines, arrows, labels, bounds, Rh, pocket, w, inner, cp, bullet, alphaArc, record,
  };
}

// Plain segments and closed outlines a label must not touch (used by tests and rendering checks).
function outlineSegments(model) {
  const segs = [];
  const chain = (pts) => { for (let i = 1; i < pts.length; i++) segs.push([...pts[i - 1], ...pts[i]]); };
  chain(model.upper);
  chain(model.section);
  if (model.bulletSection) chain(model.bulletSection);
  for (const seg of model.lines) segs.push(seg);
  return segs;
}

function renderDrawing(record) {
  const model = drawingModel(record);
  if (!model.ok) return { svg: '', missing: model.missing };
  const { bounds: b } = model;
  const pts = (list) => list.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(3)} ${y.toFixed(3)}`).join(' ');
  const hatch = `hatch-${model.key}`;
  const seg = (s, cls) => `<line class="${cls}" x1="${s[0].toFixed(3)}" y1="${s[1].toFixed(3)}" x2="${s[2].toFixed(3)}" y2="${s[3].toFixed(3)}"/>`;
  const labels = model.labels.map((l) => {
    const t = `<text x="${l.x.toFixed(3)}" y="${l.y.toFixed(3)}" text-anchor="middle"${l.rotated ? ` transform="rotate(-90 ${l.x.toFixed(3)} ${l.y.toFixed(3)})"` : ''}>${svgEscape(l.text)}</text>`;
    return t;
  }).join('');
  const titleY = model.Rh + 11;
  const cols = (x) => x.toFixed(3);
  const svg = [
    `<svg class="drawing" xmlns="http://www.w3.org/2000/svg" viewBox="${cols(b.x0)} ${cols(b.y0)} ${cols(b.x1 - b.x0)} ${cols(b.y1 - b.y0)}" width="100%" role="img" aria-label="${svgEscape(model.name)} drawing">`,
    `<defs><pattern id="${hatch}" width="1.2" height="1.2" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="1.2" stroke="currentColor" stroke-width="0.12"/></pattern></defs>`,
    `<line class="centre" x1="${cols(b.x0 + 1)}" y1="0" x2="${cols(b.x1 - 1)}" y2="0"/>`,
    `<path class="outline" d="${pts(model.upper)}"/>`,
    `<path class="section" fill="url(#${hatch})" d="${pts(model.section)} Z"/>`,
    model.bulletSection ? `<path class="section" fill="url(#${hatch})" d="${pts(model.bulletSection)} Z"/>` : '',
    model.lines.map((s) => seg(s, 'dim')).join(''),
    model.arrows.map((a) => `<path class="arrow" d="${pts(a)} Z"/>`).join(''),
    `<g class="labels" font-size="${TEXT_HEIGHT}">${labels}</g>`,
    `<g class="title">`,
    `<line class="frame" x1="${cols(b.x0)}" y1="${cols(titleY - 3)}" x2="${cols(b.x1)}" y2="${cols(titleY - 3)}"/>`,
    `<text x="${cols(b.x0 + 1)}" y="${cols(titleY + 1)}" font-size="4" font-weight="bold">${svgEscape(model.name)}</text>`,
    `<text x="${cols(b.x0 + 1)}" y="${cols(titleY + 4.5)}" font-size="3">C.I.P. table ${svgEscape(record.tab)} · revised ${svgEscape(record.revised)}</text>`,
    `<text x="${cols(b.x1 - 1)}" y="${cols(titleY + 1)}" font-size="3" text-anchor="end">Dimensions in mm</text>`,
    `<text x="${cols(b.x1 - 1)}" y="${cols(titleY + 4.5)}" font-size="3" text-anchor="end">Scale 1:1</text>`,
    `</g>`,
    `</svg>`,
  ].join('');
  return { svg, missing: model.missing };
}

if (typeof module !== 'undefined') {
  module.exports = { drawingModel, outlineSegments, renderDrawing, rimTypeOf, filletArc, radiusAt, svgEscape, labelAt };
}
