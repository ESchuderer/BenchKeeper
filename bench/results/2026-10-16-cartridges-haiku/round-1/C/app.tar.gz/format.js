// Value formatting, symbols, units and section tables for one cartridge record.
var SYMBOL_OVERRIDES = {
  eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β',
  delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
};

var ANGLE_FIELDS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];

var UNIT_OVERRIDES = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '—' };

var SECTION_TITLES = {
  caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
  misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures',
  projectile: 'Projectile', barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves',
  rifling: 'Rifling',
};

function formatNumber(n) {
  return String(n);
}

function degrees(a) {
  return typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600;
}

function formatAngle(a) {
  if (typeof a === 'number') return formatNumber(a) + '°';
  const pad = (n) => String(n).padStart(2, '0');
  return formatNumber(a.degrees) + '°' + pad(a.minutes) + "'" + pad(a.seconds) + '"';
}

function formatWithTol(value, tol) {
  return tol === undefined ? String(value) : String(value) + ' ' + formatNumber(tol);
}

function symbolOf(field) {
  return SYMBOL_OVERRIDES[field] || field;
}

function unitOf(field) {
  if (ANGLE_FIELDS.includes(field)) return '—';
  return UNIT_OVERRIDES[field] || 'mm';
}

// One section (for example "lengths") to a table: rows of symbol, value and unit.
function sectionRows(group) {
  return Object.keys(group)
    .filter((field) => !field.endsWith('Tol'))
    .map((field) => {
      const raw = group[field];
      const formatted = typeof raw === 'object' || ANGLE_FIELDS.includes(field)
        ? formatAngle(raw)
        : formatNumber(raw);
      const tol = group[field + 'Tol'];
      return {
        field,
        symbol: symbolOf(field),
        value: formatWithTol(formatted, tol),
        unit: unitOf(field),
      };
    });
}

// The "cartridge" and "chamber" groups of a record, each a list of non-empty tables.
function sectionsOf(record) {
  const tables = (side) => Object.keys(side)
    .filter((name) => Object.keys(side[name]).length > 0)
    .map((name) => ({ title: SECTION_TITLES[name], rows: sectionRows(side[name]) }));
  return { cartridge: tables(record.cartridge), chamber: tables(record.chamber) };
}

if (typeof module !== 'undefined') {
  module.exports = { formatNumber, degrees, formatAngle, formatWithTol, symbolOf, unitOf, sectionsOf };
}
