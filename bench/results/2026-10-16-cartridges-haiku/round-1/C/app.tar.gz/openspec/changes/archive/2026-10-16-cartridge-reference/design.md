# Design

## Context

- The repository has no application code yet (commit `chore: project setup`). Node.js 22 is in the container. No npm packages are installed.
- Chromium opens `file://` pages with classic scripts only: `fetch`, XHR and ES modules from `file://` are blocked. The data and every script must load through plain `<script src>` tags.
- Spec behaviour: see `specs/*/spec.md`. Geometry rules are given in the brief and are referenced by requirement name there.

## Goals / Non-Goals

**Goals:**
- Pure functions for formatting, data model and drawing geometry, testable in Node without a DOM.
- Same files work from `file://` and from a static server.

**Non-Goals:**
- No build step, bundler, framework, service worker, or runtime dependency.
- No data edits, no unit conversion, no extra fields (`annotations.confidence`, `implausible`, `defaultBullet` are not shown).
- No support for records other than the 25 supplied (the code reads any record of the same shape).

## Decisions

- **File layout (root):** `index.html`, `styles.css`, `cartridges.js` (data, `var CARTRIDGES = [...]`), `format.js` (symbols, units, number and angle formatting, section model), `drawing.js` (geometry and SVG string), `app.js` (list, search, filter, hash routing, print button). Alternative considered: one JS file. Rejected to keep geometry testable separately.
- **Module export:** each `.js` file is a classic script with top-level functions. Each ends with `if (typeof module !== 'undefined') module.exports = {...}` so `node --test` loads it without a bundler. Browser globals come from the same declarations.
- **Data as a script:** the 25 records are a JS array literal (valid JSON per line, joined with commas). Alternative: `fetch('cartridges.jsonl')`, rejected because it fails on `file://`.
- **Routing:** hash routes `#/` (list) and `#/cartridge/<key>` (detail). Alternative: query string, rejected because it is less readable in a bookmark. The list state (search text and family) is kept in memory across detail views.
- **Number formatting:** `String(value)`: `4150.0` → `4150`, `51.18` → `51.18`. Angles: integer or decimal degrees followed by `°`; the object form pads minutes and seconds to two digits.
- **Geometry in (z, r):** all profile points are `[z, r]` with `z` along the axis from the head face and `r ≥ 0`. The SVG maps the upper half to `y = -r` (outside view) and the lower half to `y = +r` (section). This keeps every rule in the brief literal.
- **Profile construction:** outer profile is a polyline from the axis at the head face to the mouth; fillets are sampled arcs. Inner profile = outer vertices with `z ≥ w`, each offset by thickness `t(z)`: `tb` up to the body end, linear blend to `tn` at the neck start, `tn` after. The section polygon is outer + mouth face + inner reversed + the head closure through the primer pocket.
- **Bullet:** polyline from the base to the tip, cylinder then nose. The nose formulas come from the brief. Heeled bullets use radius `H2/2 - tb` below the mouth and `H2/2` above it.
- **Dimension placement (fixed rows, not solved):**
  - Top side, rows from highest to lowest: L6, L3, L2, L1. Larger span is placed higher, so an extension line never crosses a dimension line of a longer span.
  - Head side: R1 vertical dimension at `z = -3`, left of the head face.
  - Bottom side: R dimension at the head; the diameters (P1, P2, H1, H2, G1, E1) use vertical dimension lines in columns beyond the tip, with horizontal extension lines from each outline point. Columns are spaced 8 mm; labels are horizontal, centred on their column, alternating above and below the outline at Rb + 4.2 mm from the axis, so that neighbouring labels and the extension lines do not overlap.
  - α: arc centred on the virtual cone apex `S` with a label beside it. (`S` is the junction cone value and matches the apex position of the published points, for example `S` 47.12 with `L1` 36.52 and `P2/2` 4.5 for 223 Rem.)
  - Label text is 3 mm high; the estimated box uses 0.6 em per character. A test checks that label boxes do not overlap each other or the outline polylines.
- **Scale and print:** the SVG has `viewBox` in mm and `width="100%"`. Print uses `@page { size: A4 portrait }`, two-column tables, and the drawing at full content width.
- **Missing values:** a rule whose input is missing skips the feature and adds the value name to a note list below the SVG.
- **Theme:** CSS `prefers-color-scheme` with variables for background, foreground and the hatch colour; the SVG uses `currentColor` for lines so it follows the theme. Print forces light colours.

## Risks / Trade-offs

- [Label overlap with dense values] → fixed row and column layout, plus a pairwise label test across all 25 records.
- [Fillets that do not fit] → draw the corner sharp and name the value in the drawing notes, as the spec requires. No record in the data triggers this (checked for all 25); the path is covered by the geometry tests only if a fitting case is constructed, see `test/drawing-geometry.test.js`.
- [Phone width scales labels down] → accepted: the spec requires scaling to the width, and print is the legibility target.
- [Unit of `grooves.u` is not stated in the brief] → shown as mm; the values (305 for 223 Rem., 203 for 6,5 Creedmoor, 406 for 22 LR) match the rifling pitch lengths of 1:12", 1:8" and 1:16" twists. Flagged in the final report.
- [Browser print scaling] → the print page is checked by emulated A4 print in Chromium (one page), not by a printer.

## Migration Plan

Not applicable: new application, no existing data or users.

## Open Questions

None.
