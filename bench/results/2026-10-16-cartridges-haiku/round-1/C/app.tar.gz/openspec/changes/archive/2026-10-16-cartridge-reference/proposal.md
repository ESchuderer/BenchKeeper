# Proposal

## Why

The project holds 25 C.I.P. cartridge records (OpenBallistics data, MIT, commit e83db43). Reloaders, gunsmiths and engineers need to find a cartridge, read its C.I.P. dimensions and pressures, and see a scaled drawing, without a server or a build step.

## What Changes

- Static app in `index.html` with `styles.css` and classic `.js` scripts. Opens from `file://` and from any static server. No framework, no network requests, no runtime dependencies.
- Data: the 25 records, used as published, in `cartridges.js`.
- Start page: list of all cartridges (name link, family, L3), search by name and alternative names, family filter, count line.
- Detail page at its own hash address: header fields, all cartridge and chamber values in tables, drawing, print button, back link.
- Drawing: inline SVG, 1 unit = 1 mm, computed from the record by fixed geometry rules; dimension lines for the listed symbols; title block.
- Print: one A4 portrait page, black on white, no navigation.
- Light and dark theme follow the system setting on screen.
- Development test runner (`node:test`) as the only dev dependency.
- No change to the data.

## Capabilities

### New Capabilities

- `cartridge-catalogue`: start page, search, family filter, count, links to detail views, hash routing.
- `cartridge-detail`: detail view content, value formatting, symbols, units, tolerances, tables, print output.
- `cartridge-drawing`: SVG drawing geometry, dimension annotations, title block, scaling.

### Modified Capabilities

None (`openspec/specs/` is empty).

## Impact

- New files in the project root: `index.html`, `styles.css`, `cartridges.js`, `app.js`, plus the drawing and format modules and tests.
- `package.json` with `node:test` script; no runtime dependency.
- No effect on existing code (the repository has none).
