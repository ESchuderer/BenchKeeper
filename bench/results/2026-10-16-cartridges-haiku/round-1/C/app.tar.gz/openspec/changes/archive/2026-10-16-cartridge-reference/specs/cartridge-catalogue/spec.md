# Spec Delta

## Purpose

Lets a technical reader find a C.I.P. cartridge in the reference list by name, alternative name or family, and open its detail view at an address that can be bookmarked.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" and one entry per record, each with its family and case length L3. The entry name SHALL be a link whose text is exactly the record `name`.

#### Scenario: All records listed
- **WHEN** the start page loads with all 25 records
- **THEN** 25 entries are listed, and each name link text equals the record `name`

#### Scenario: Entry shows family and L3
- **WHEN** an entry for "223 Rem." is shown
- **THEN** it shows family "rimless" and L3 "44.7" with unit "mm"

### Requirement: Search filters by name and alternative names
The page SHALL provide a field labelled "Search". The list SHALL update on each input and show the records whose `name` or any `alternativeNames` entry contains the typed text, ignoring letter case and repeated whitespace.

#### Scenario: Alternative name finds record
- **WHEN** the user types "7,62 x 51"
- **THEN** the list shows "308 Win." and no record whose name and alternative names lack "7,62 x 51"

#### Scenario: Empty search shows all
- **WHEN** the search field is empty
- **THEN** all records allowed by the family filter are shown

### Requirement: Family filter
The page SHALL provide a select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire. Selecting an option SHALL show only records with that `family`; All shows every family. The filter SHALL combine with the search.

#### Scenario: Family selected
- **WHEN** the user selects "belted"
- **THEN** only the records with family "belted" are listed

#### Scenario: Family and search combined
- **WHEN** the family is "rimfire" and the search is "17"
- **THEN** only "17 HMR" is listed

### Requirement: Count line
The page SHALL show the text "<n> cartridges" with n equal to the number of listed records, updated with the search and the family filter. For n equal to 1 the text SHALL read "1 cartridge".

#### Scenario: Count after filtering
- **WHEN** the family filter is "pistol"
- **THEN** the count text reads "6 cartridges"

#### Scenario: Single result
- **WHEN** the search matches only "17 HMR"
- **THEN** the count text reads "1 cartridge"

### Requirement: Detail address
Each cartridge SHALL have a detail address containing its `key`, for example `#/cartridge/223_rem`. Opening that address, or reloading it, SHALL show the detail view for that record. An address with an unknown key SHALL show a "Cartridge not found" message with a link to the start page.

#### Scenario: Bookmarked address
- **WHEN** the page is opened directly at `#/cartridge/308_win`
- **THEN** the detail view of "308 Win." is shown

#### Scenario: Unknown key
- **WHEN** the page is opened at `#/cartridge/unknown`
- **THEN** the text "Cartridge not found" and a link "All cartridges" are shown

### Requirement: Navigation between list and detail
Selecting a name link SHALL open the detail address of that record. The "All cartridges" link in the detail view SHALL return to the start page.

#### Scenario: Open and return
- **WHEN** the user selects the link "223 Rem." and then "All cartridges"
- **THEN** the start page is shown again with the search text and family selection it had before the link was opened
