# Spec Delta

## Purpose

Draws each C.I.P. cartridge as a true-to-scale two-part technical drawing (outside view and section) from the record values, with dimension annotations and a title block, so the dimensions can be read on screen and on paper.

## ADDED Requirements

### Requirement: Inline SVG at true scale
The drawing SHALL be an inline SVG with accessible name "<name> drawing" in which one user unit equals 1 mm, the axis is horizontal and the head is on the left. Its width SHALL be 100% of the container so that it scales to a phone width.

#### Scenario: Units
- **WHEN** a 25 mm length is measured in the SVG user coordinate system
- **THEN** it equals 25 user units

#### Scenario: Accessible name
- **WHEN** the detail view of "9 mm Luger" is shown
- **THEN** the SVG has the accessible name "9 mm Luger drawing"

### Requirement: Outside view and section
The upper half of the drawing SHALL be the outside view (outline only). The lower half SHALL be a section in which the cut walls of the case, the solid head and the seated bullet are hatched. A dash-dot centre line SHALL run along the axis.

#### Scenario: Halves
- **WHEN** the drawing of any record is shown
- **THEN** the outline of the outside view is above the axis, the hatched section is below it, and a dash-dot line lies on the axis

### Requirement: Rim type
Family "belted" SHALL draw a belt, family "rimfire" SHALL draw a half-round rim edge, and every other family SHALL draw a square or chamfered rim edge. Where R1/P1 is 1.05 or more the rim is rimmed, below 0.98 it is rebated, and otherwise rimless; rimmed, rebated and rimless share the same outline rules.

#### Scenario: Rimfire edge
- **WHEN** the record "22 Long Rifle" is drawn
- **THEN** its head edge is a half-round of radius min(R/2, (R1 - P1)/2) whose outermost point lies at R1/2

#### Scenario: Belted case
- **WHEN** the record "300 Win. Mag." is drawn
- **THEN** the drawing has a belt of diameter R3 from the ramp end to z = E

### Requirement: Head face, chamfer and rim
The head face SHALL run from the axis at z = 0 to the rim radius R1/2. Where beta and f are published and beta is below 90°, the outer corner SHALL be chamfered from (R1/2 - min(f·tan β, R1/4), 0) to (R1/2, f). The rim edge SHALL then run to (R1/2, R). Without a chamfer the corner SHALL be square.

#### Scenario: Chamfer
- **WHEN** the record "9 mm Luger" is drawn (beta 45, f 0.3)
- **THEN** the chamfer runs from radius R1/2 - 0.3 at z = 0 to radius R1/2 at z = 0.3

### Requirement: Extractor groove
Where E and E1 are published, the outline SHALL run from (R1/2, R) inward to (E1/2, R), along the groove floor to (E1/2, R + eMin), then ramp out to (P1/2, E). Belted cases SHALL ramp out from the floor end at the angle delta to the axis up to radius R3/2, follow the belt to z = E, and step in to P1/2. Without E and E1 the outline SHALL step from (R1/2, R) to (P1/2, R).

#### Scenario: Groove on 223 Rem.
- **WHEN** the record "223 Rem." is drawn
- **THEN** the floor is at radius E1/2 between z = R and z = R + eMin, and the ramp ends at radius P1/2, z = E

### Requirement: Body, shoulder and neck
The body SHALL run from (P1/2, E) to (P2/2, L1) on a bottleneck case, otherwise to (H2/2, L3). The shoulder SHALL run through (P2/2, L1) and (H1/2, L2) with included angle alpha, and SHALL be rounded with r1Min at the body side and r2 at the neck side where those values are published. The neck SHALL run from (H1/2, L2) to (H2/2, L3), then the mouth face.

#### Scenario: Straight case
- **WHEN** a case has no alpha, L1 or L2
- **THEN** the body runs straight from (P1/2, E) to (H2/2, L3)

#### Scenario: Fillet does not fit
- **WHEN** a fillet radius is larger than the room its tangent points need on the adjacent segments
- **THEN** that corner is drawn sharp and the drawing notes name the value that was not drawn

### Requirement: Bullet
The bullet SHALL run from the mouth to the tip at z = L6 with shank diameter G1 and the nose shape of `annotations.defaultBulletShape`. The seating depth s is 1.0·G1 for pointy; 0.8·G1 for rounded and flat on rifle and rimfire; 0.4·G1 for rounded and flat on pistol; 0.6·G1 for semi_wadcutter. The base is at zb = L3 - s and the bullet length Lb = L6 - zb.

#### Scenario: Pointy rifle bullet
- **WHEN** the record "223 Rem." is drawn (pointy, G1 5.7, L3 44.7, L6 57.4)
- **THEN** s is 5.7, the base is at z = 39.0, the cylinder ends at z = 46.36, and the tip is at z = 57.4

#### Scenario: Nose shapes
- **WHEN** a pointy bullet is drawn
- **THEN** the nose is a tangent ogive with meplat diameter max(0.08·G1, 1.27)
- **AND WHEN** a rounded bullet is drawn, the nose is a quarter ellipse with meplat 0.15·G1
- **AND WHEN** a flat bullet is drawn, the nose is a straight cone with meplat 0.55·G1
- **AND WHEN** a semi_wadcutter is drawn, the nose is a straight cone with meplat 0.6·G1

### Requirement: Bullet cylinder length
The cylinder SHALL run from the base to zb + k·Lb, with k = 0.40 for pointy, 0.55 for rounded rifle and rimfire, 0.65 for rounded pistol, 0.60 for flat rifle and rimfire, 0.70 for flat pistol and 0.78 for semi_wadcutter.

#### Scenario: Pointy cylinder
- **WHEN** the record "223 Rem." is drawn (base 39.0, Lb 18.4)
- **THEN** the cylinder ends at z = 39.0 + 0.40 × 18.4 = 46.36

### Requirement: Heeled bullets
Where H2 - G1 is 0.015 or less, the exposed bullet SHALL have the case outside diameter H2 and the seated heel SHALL have the case inside diameter H2 - 2·tb.

#### Scenario: 22 Long Rifle heel
- **WHEN** the record "22 Long Rifle" is drawn (H2 5.72, G1 5.72)
- **THEN** the exposed bullet has diameter 5.72 and the seated heel has diameter 5.72 - 2·tb

### Requirement: Section walls and head
The neck wall SHALL be tn = (H2 - G1)/2 and the body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner line SHALL follow the outer body at tb, the neck at tn, and blend linearly across the shoulder. On a straight case (no shoulder) the wall is tb at the body start and blends linearly to tn at the mouth face, z = L3. The solid head SHALL run from the head face to z = w, where w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb with a groove, or belt ramp end + tb on belted cases).

#### Scenario: Wall thickness
- **WHEN** the record "223 Rem." is drawn (H2 6.43, G1 5.7, P1 9.58)
- **THEN** tn is 0.365 and tb is 0.6

### Requirement: Primer pocket
Centrefire cases SHALL have a primer pocket in the head: diameter 4.45 for primer types sp, spm and sr, and 5.33 for lp, lpm, lr and lrm; depth 3.04 for sp, spm, sr, lp and lpm, and 3.3 for lr and lrm. Rimfire cases SHALL have no pocket.

#### Scenario: Pocket on 308 Win.
- **WHEN** the record "308 Win." is drawn (primer type lr)
- **THEN** the pocket is 5.33 mm in diameter and 3.3 mm deep

### Requirement: Missing values
When a value needed by a rule is missing, the drawing SHALL omit that feature and SHALL list the missing value names in a note below the drawing. No value SHALL be invented.

#### Scenario: Missing value needed by a rule
- **WHEN** a belted record has no `cartridge.caseHead.R3`
- **THEN** the belt is not drawn, the groove ends at P1/2 as without a belt, and the note lists "R3"

### Requirement: Dimension annotations
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle alpha where those values are published. Each SHALL be labelled with its symbol and value, for example "L3 51.18". The alpha dimension SHALL be an arc about the cone apex whose ends lie on the two shoulder lines, so that its span equals alpha.

#### Scenario: Labels present
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the labels "L3 51.18", "L6 71.12", "R1 12.01" and "P1 11.96" are present, each with a dimension line with two arrowheads and extension lines

### Requirement: Labels clear of each other and the outline
No dimension label SHALL overlap another label, a dimension line or the outline of the cartridge.

#### Scenario: Label clearance
- **WHEN** the drawing of any of the 25 records is generated
- **THEN** the estimated text boxes of all labels are pairwise disjoint and do not intersect the outline polylines

### Requirement: Title block
The drawing SHALL include a title block with the name, the C.I.P. table, the revised date, the text "Dimensions in mm" and the scale "1:1".

#### Scenario: Title block
- **WHEN** the drawing of "9 mm Luger" is shown
- **THEN** the title block shows "9 mm Luger", table "IV", the revised date "2008-09-23", "Dimensions in mm" and "1:1"

### Requirement: Legible print
The drawing SHALL print at the full width of an A4 portrait page with every label legible at its printed size. Where the full-width drawing would be taller than 88 mm, the printed drawing SHALL be limited to 88 mm height with its aspect ratio kept, so that the detail view stays on one page.

#### Scenario: Printed labels
- **WHEN** the drawing is printed at the full width of an A4 page
- **THEN** every label text is at least 2.5 mm high on paper

#### Scenario: Tall drawing limited
- **WHEN** the drawing of "9 mm Luger" is printed
- **THEN** its height is at most 88 mm and it is centred within the page width
