# Tasks

## 1. Setup

- [x] 1.1 Create `package.json` (private, name `cartridge-reference`, script `test` = `node --test`, no dependencies) and verify `npm test` exits 0 with no test files
- [x] 1.2 Copy the 25 records from the brief into `cartridges.js` as `var CARTRIDGES = [...]`, one object per former line, unchanged; verify `node -e "require('./cartridges.js')"` loads and returns 25 objects

## 2. Data and formatting

- [x] 2.1 Write `test/data.test.js`: 25 records, unique `key`, `name` values as listed in the brief, every `<X>Tol` has a matching `X`; verify it fails before 1.2 and passes after
- [x] 2.2 Write `test/format.test.js` for `formatNumber` (4150 → "4150", 51.18 → "51.18"), `formatAngle` (40 → "40°", `{50,35,2}` → `50°35'02"`, `{1,30,0}` → `1°30'00"`), tolerance join ("19.15 -0.25"), symbol map (all 13 overrides), unit map (mm, bar, J, g, mm², count, angles); verify it fails before the code exists
- [x] 2.3 Implement `format.js` with these functions and their module export; verify `npm test` passes 2.1 and 2.2
- [x] 2.4 Add `sectionsOf(record)` to `format.js` returning the Cartridge and Chamber groups, each a list of tables with rows `{symbol, value, unit}`; tolerance keys excluded; verify with a test that 223 Rem. chamber "Rifling" has rows G, G1, alpha1, h, i and no `Tol` rows

## 3. Drawing geometry

- [x] 3.1 Write `test/drawing-profile.test.js` with exact values for 223 Rem.: groove floor radius E1/2 at z R to R + eMin, ramp to (P1/2, E), chamfer for 9 mm Luger, rimfire half-round for 22 Long Rifle, belt ramp angle for 300 Win. Mag.; verify it fails before 3.2
- [x] 3.2 Implement head, rim, groove, belt, body, shoulder with fillets (r1Min, r2; skipped with a note when they do not fit), and neck in `drawing.js`; verify 3.1 passes
- [x] 3.3 Write `test/drawing-bullet.test.js`: 223 Rem. base z 39.0, cylinder end 46.36, tip 57.4, meplat 1.27; heeled 22 Long Rifle diameters; nose shapes for pointy, rounded, flat and semi_wadcutter; verify it fails before 3.4
- [x] 3.4 Implement the bullet (seating depth, cylinder fraction k, nose by shape, heel) in `drawing.js`; verify 3.3 passes
- [x] 3.5 Write `test/drawing-section.test.js`: tn and tb for 223 Rem. (0.365, 0.6); primer pocket diameter and depth per primer type; no pocket for rimfire; `w` rule for 223 Rem. (4.54) and 300 Win. Mag. (belt rule); verify it fails before 3.6
- [x] 3.6 Implement the inner profile, section polygon with primer pocket, and the head solid to `w` in `drawing.js`; verify 3.5 passes
- [x] 3.7 Implement missing-value handling: a feature whose input is absent is omitted and its name collected into `missing`; test that a belted record without R3 is still drawn and lists "R3"; verify with `npm test`

## 4. Drawing annotations and SVG

- [x] 4.1 Write `test/drawing-labels.test.js`: for all 25 records the estimated label boxes are pairwise disjoint and do not intersect the outline polylines; verify it fails before 4.2
- [x] 4.2 Implement dimension lines (arrowheads, extension lines) for L3, L6, R1, R, P1, P2, H1, H2, G1, L1, L2, E1 and α, with the fixed row and column placement in `design.md`, plus label boxes; verify 4.1 passes
- [x] 4.3 Write `test/drawing-svg.test.js`: the SVG string has `viewBox` in mm, `width="100%"`, `aria-label="<name> drawing"`, a dash-dot centre line, a title block with name, table, revised date, "Dimensions in mm" and "1:1", escapes `&` in "40 S.& W."; verify it fails before 4.4
- [x] 4.4 Implement `renderDrawing(record)` returning the SVG string and the missing-value note in `drawing.js`; verify 4.3 passes and `node -e` renders all 25 records without error

## 5. Application

- [x] 5.1 Create `index.html` (title, `<main>`, `<script src>` for `cartridges.js`, `format.js`, `drawing.js`, `app.js`, `styles.css` link) and `styles.css` with light and dark variables, tabular numerals, print rules (A4 portrait, black on white, controls hidden, two-column sections, footer source line); verify the page opens from `file://` in Playwright MCP with no console errors
- [x] 5.2 Write `test/catalogue.test.js` for `filterCartridges(list, {query, family})`: query matches name and alternative names case-insensitively; "7,62 x 51" finds "308 Win."; family All returns all; the count text "1 cartridge" and "25 cartridges"; verify it fails before 5.3
- [x] 5.3 Implement `filterCartridges` and the count text in `app.js` with the module export; verify 5.2 passes
- [x] 5.4 Implement the list view in `app.js`: heading "Cartridges", entries with name link, family and L3 with unit, Search field, Family select, count line; verify in Playwright MCP that 25 entries show and typing "7,62 x 51" leaves "308 Win."
- [x] 5.5 Implement hash routing and the detail view in `app.js`: heading, header fields, water capacity with source link, drawing, sections tables with Symbol, Value, Unit, Print button, "All cartridges" link, "Cartridge not found" for unknown keys, list state kept across navigation; verify in Playwright MCP that `#/cartridge/223_rem` survives a reload and the 223 Rem. tables show "39.62 -0.2" for L1
- [x] 5.6 Verify the phone layout in Playwright MCP at 360 px wide: no horizontal page scroll on the list and on the detail view of "6,5 Creedmoor"; drawing fills the width; fix CSS until it passes

## 6. Print and theme checks

- [x] 6.1 Verify print with the Playwright library from a scratch directory outside the repository (emulated print media, A4 portrait PDF): the detail view of all 25 records prints to exactly one page; the page contains no buttons or links to navigation; fix CSS until it passes
- [x] 6.2 Verify dark system setting in Playwright MCP (`browser_emulate_media` colorScheme dark): page background is dark and text light; verify light setting likewise

## 7. Review and wrap-up

- [x] 7.1 Run `npm test` and report pass and fail counts; all tests pass with no test skipped or removed
- [x] 7.2 Run the code-review agent on the branch diff (no remote, so the review runs before reporting done); fix every confirmed correctness finding and rerun `npm test`
- [x] 7.3 Confirm the app makes no network request: `browser_network_requests` on `file://` shows only `index.html`, the four scripts and `styles.css`

## Workflow follow-up

- No GitHub remote and no `gh`: no issue, no pull request. The branch `feat/cartridge-reference` stays local.
- Archive the change with `openspec-archive-change` on this branch after 7.3.
