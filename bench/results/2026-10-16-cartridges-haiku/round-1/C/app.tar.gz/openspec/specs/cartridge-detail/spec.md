# cartridge-detail Specification

## Purpose
Shows every published value of one C.I.P. cartridge record for technical readers, in the published form, units and symbols, and as a one-page print.

## Requirements

### Requirement: Detail header
The detail view SHALL show a heading with the record `name`, then alternative names, family, category (`annotations.category`), primer type (`annotations.primerType`), C.I.P. table (`tab`), country, published date, revised date, pressure method, and the published water capacity. Fields absent from the record SHALL be shown as "—".

#### Scenario: Header of 308 Win.
- **WHEN** the detail view of "308 Win." is shown
- **THEN** it shows the alternative names "308 Winchester", "7,62 x 51", the family "rimless", the category "rifle", the primer type "lr", the C.I.P. table "I", the country "US", the dates "1984-06-14" and "2008-09-23", and the pressure method "Transducer"

### Requirement: Water capacity with source
The water capacity SHALL be shown as the published `publishedCapacity.grH2O` with unit "grH2O", the source name `publishedCapacity.source` as a link to `publishedCapacity.url`, and `publishedCapacity.note` when present.

#### Scenario: Capacity with note
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** it shows "30.5 grH2O" and the source "kwk" linking to "http://kwk.us/cases.html"

### Requirement: Value tables by section
The detail view SHALL show every value under `cartridge` and `chamber` in tables grouped by section, with the columns "Symbol", "Value" and "Unit". Each section heading names the section (for example "Case head", "Junction cone", "Rifling"). Tolerance fields are not rows.

#### Scenario: Sections present
- **WHEN** the detail view of any record is shown
- **THEN** a "Cartridge" group and a "Chamber" group contain one table for each non-empty section, and each table has the headers "Symbol", "Value" and "Unit"

#### Scenario: Tolerance not a row
- **WHEN** a record has `cartridge.lengths.L1` 39.62 and `L1Tol` -0.2
- **THEN** the L1 row shows the value "39.62 -0.2" and no row exists for "L1Tol"

### Requirement: Number format
Numbers SHALL be shown in their published decimal form with a decimal point and no thousands separator, with trailing zeros omitted, for example "51.18", "4150" and "0.4". A tolerance SHALL follow its value after one space, with its published sign.

#### Scenario: Pressure without decimals
- **WHEN** `pressures.Pmax` is 4150.0
- **THEN** the value is shown as "4150"

#### Scenario: Tolerance sign
- **WHEN** `cartridge.lengths.L3Tol` is -0.25 and L3 is 19.15
- **THEN** the value is shown as "19.15 -0.25"

### Requirement: Angle format
An angle given as a number of degrees SHALL be shown as the number followed by "°", for example "40°". An angle given as `{degrees, minutes, seconds}` SHALL be shown as degrees, "°", minutes padded to two digits, "'", seconds padded to two digits and `"`, for example "39°59'49\"" and "1°30'00\"".

#### Scenario: Degrees object
- **WHEN** `alpha` is `{degrees: 50, minutes: 35, seconds: 2}`
- **THEN** the value is shown as `50°35'02"`

#### Scenario: Plain degrees
- **WHEN** `beta` is 35.0
- **THEN** the value is shown as "35°"

### Requirement: Symbols
The Symbol column SHALL show the field name, except: `eMin` as "e min", `r1Min` as "r1 min", `r1Max` as "r1 max", `alpha` as "α", `alpha1` as "α1", `beta` as "β", `delta` as "δ", `deltaL` as "delta L" and `L3PlusG` as "L3 + G".

#### Scenario: Symbol override
- **WHEN** the case head contains `delta` 25.0 and `eMin` 0.76
- **THEN** the rows show the symbols "δ" and "e min"

### Requirement: Units
The Unit column SHALL show "mm" for lengths and diameters, "bar" for Pmax, PK and PE, "J" for EE, "g" for M, "mm²" for Q, and "—" for N (a count) and for angles (the unit is part of the value). The unit of `grooves.u` SHALL be "mm" (rifling pitch length).

#### Scenario: Unit of pressure
- **WHEN** `pressures.EE` is 2890.0
- **THEN** the row shows the value "2890" and the unit "J"

#### Scenario: Count has no unit
- **WHEN** `grooves.N` is 6.0
- **THEN** the row shows the value "6" and the unit "—"

### Requirement: Drawing in detail view
The detail view SHALL show the drawing defined by `cartridge-drawing` after the header and before the tables.

#### Scenario: Drawing order
- **WHEN** the detail view is shown
- **THEN** the drawing element appears after the header block and before the first value table

### Requirement: Print button and navigation
The detail view SHALL have a "Print" button that opens the browser print dialog, and a link "All cartridges" to the start page.

#### Scenario: Print opens dialog
- **WHEN** the user selects "Print"
- **THEN** the browser print dialog opens for the current view

### Requirement: Printed page
In print, the detail view SHALL be one A4 portrait page in black on white. It SHALL show a page header with the record name, the drawing at full width, the tables, and a footer "Source: C.I.P. TDCC, revised <revised>". Navigation, the search field, the family filter, the Print button and the back link SHALL NOT be printed.

#### Scenario: One page
- **WHEN** the detail view of any of the 25 records is printed to A4 portrait
- **THEN** the output has exactly one page with all labels of the drawing legible

#### Scenario: Controls hidden
- **WHEN** the detail view is printed
- **THEN** the Print button, the "All cartridges" link and the search and family controls are not in the output

### Requirement: Light and dark theme
On screen the page SHALL follow the system color scheme (light or dark). Tables SHALL use tabular numerals.

#### Scenario: Dark system setting
- **WHEN** the system color scheme is dark
- **THEN** the page uses a dark background and light text

### Requirement: Phone layout
The page SHALL be usable at a phone width of 360 CSS pixels: no horizontal scroll for text or tables, and the drawing SHALL scale to the available width.

#### Scenario: Narrow viewport
- **WHEN** the detail view is shown at 360 px width
- **THEN** the page does not scroll horizontally and the drawing fills the content width
