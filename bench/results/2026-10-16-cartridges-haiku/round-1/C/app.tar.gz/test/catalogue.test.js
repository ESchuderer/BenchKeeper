const test = require('node:test');
const assert = require('node:assert/strict');
const CARTRIDGES = require('../cartridges.js');
const { filterCartridges, countText, normalizeText } = require('../app.js');

test('search matches name and alternative names, ignoring case and repeated spaces', () => {
  const names = (q, family = 'All') => filterCartridges(CARTRIDGES, { query: q, family }).map((c) => c.name);
  assert.deepEqual(names('7,62 x 51'), ['308 Win.']);
  assert.deepEqual(names('  22  LR '), ['22 Long Rifle']);
  assert.deepEqual(names('30-06'), ['30-06 Spring.']);
  assert.equal(names('').length, 25);
});

test('family filter combines with search', () => {
  assert.deepEqual(filterCartridges(CARTRIDGES, { query: '17', family: 'rimfire' }).map((c) => c.name), ['17 HMR']);
  assert.equal(filterCartridges(CARTRIDGES, { query: '', family: 'pistol' }).length, 6);
  assert.equal(filterCartridges(CARTRIDGES, { query: '', family: 'All' }).length, 25);
});

test('count text', () => {
  assert.equal(countText(25), '25 cartridges');
  assert.equal(countText(1), '1 cartridge');
  assert.equal(countText(0), '0 cartridges');
});

test('normalizeText collapses whitespace and lowercases', () => {
  assert.equal(normalizeText('  7,62   X 51 '), '7,62 x 51');
});
