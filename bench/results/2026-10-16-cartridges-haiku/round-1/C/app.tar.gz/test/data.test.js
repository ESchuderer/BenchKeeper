const test = require('node:test');
const assert = require('node:assert/strict');
const CARTRIDGES = require('../cartridges.js');

const NAMES = [
  '223 Rem.', '243 Win.', '6,5 Creedmoor', '6,5 x 55 SE', '270 Win.', '7 x 64', '308 Win.',
  '30-06 Spring.', '8 x 57 IS', '9,3 x 62', '7,62 x 39', '338 Lapua Mag.', '300 Win. Mag.',
  '7 mm Rem. Mag.', '9,3 x 74 R', '7 x 65 R', '9 mm Luger', '45 Auto', '40 S.& W.',
  '38 Special', '357 Magnum', '44 Rem. Mag.', '22 Long Rifle', '22 Win. Mag. R.F.', '17 HMR',
];

test('25 records in the published order with published names', () => {
  assert.deepEqual(CARTRIDGES.map((c) => c.name), NAMES);
});

test('keys are unique', () => {
  const keys = CARTRIDGES.map((c) => c.key);
  assert.equal(new Set(keys).size, 25);
});

test('every tolerance field has its base value', () => {
  for (const c of CARTRIDGES) {
    for (const section of [c.cartridge, c.chamber]) {
      for (const group of Object.values(section)) {
        for (const field of Object.keys(group)) {
          if (field.endsWith('Tol')) {
            assert.ok(field.slice(0, -3) in group, `${c.key}: ${field} has no base value`);
          }
        }
      }
    }
  }
});
