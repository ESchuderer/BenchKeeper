const test = require('node:test');
const assert = require('node:assert/strict');
const CARTRIDGES = require('../cartridges.js');
const D = require('../drawing.js');

const byKey = (key) => CARTRIDGES.find((c) => c.key === key);
const near = (actual, expected, tol = 0.01, msg = '') => assert.ok(Math.abs(actual - expected) <= tol, `${msg} ${actual} ≉ ${expected}`);
const hasPoint = (pts, z, r, tol = 0.01) => pts.some(([pz, pr]) => Math.abs(pz - z) <= tol && Math.abs(pr - r) <= tol);

test('rim type from family and R1/P1 ratio', () => {
  assert.equal(D.rimTypeOf(byKey('22_long_rifle')), 'rimfire');
  assert.equal(D.rimTypeOf(byKey('300_win_mag')), 'belted');
  assert.equal(D.rimTypeOf(byKey('38_special')), 'rimmed');
  assert.equal(D.rimTypeOf(byKey('9_mm_luger')), 'rimless');
});

test('223 Rem. groove: floor at E1/2 from R to R+eMin, ramp to (E, P1/2)', () => {
  const m = D.drawingModel(byKey('223_rem'));
  const outer = m.cp.outer;
  assert.ok(hasPoint(outer, 1.14, 4.215), 'floor start');
  assert.ok(hasPoint(outer, 1.90, 4.215), 'floor end');
  assert.ok(hasPoint(outer, 3.13, 4.79), 'ramp end at E');
});

test('9 mm Luger chamfer from (R1/2 - f·tan β) at z 0 to (R1/2) at z f', () => {
  const m = D.drawingModel(byKey('9_mm_luger'));
  near(4.98 - 0.3, 4.68);
  assert.ok(hasPoint(m.cp.outer, 0, 4.68), 'chamfer start');
  assert.ok(hasPoint(m.cp.outer, 0.3, 4.98), 'chamfer end');
});

test('22 Long Rifle half-round rim with radius min(R/2, (R1-P1)/2)', () => {
  const m = D.drawingModel(byKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  near(Math.max(...m.cp.outer.map((p) => p[1])), 7.06 / 2, 0.001, 'outermost point at R1/2');
  assert.ok(hasPoint(m.cp.outer, 0, 7.06 / 2 - rho), 'half-round starts at z 0');
});

test('300 Win. Mag. belt: ramp at angle delta to the belt R3/2, then the belt to z = E', () => {
  const m = D.drawingModel(byKey('300_win_mag'));
  const rampEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  near(m.cp.rampEnd, rampEnd, 0.001);
  assert.ok(hasPoint(m.cp.outer, rampEnd, 13.51 / 2), 'ramp reaches belt');
  assert.ok(hasPoint(m.cp.outer, 5.59, 13.51 / 2), 'belt ends at E');
});

test('bottleneck shoulder passes through (P2/2, L1) and (H1/2, L2), straight case ends at (H2/2, L3)', () => {
  const m = D.drawingModel(byKey('223_rem'));
  assert.ok(!hasPoint(m.cp.outer, 36.52, 4.5, 0.001), 'corner at L1 is replaced by the fillet arc');
  assert.ok(m.cp.outer.some(([z, r]) => z > 36.4 && z < 36.7 && Math.abs(r - 4.5) < 0.1), 'fillet points near L1');
  assert.ok(hasPoint(m.cp.outer, 44.7, 6.43 / 2), 'mouth at L3');
  const straight = D.drawingModel(byKey('9_mm_luger'));
  const last = straight.cp.outer[straight.cp.outer.length - 1];
  near(last[0], 19.15, 0.001);
  near(last[1], 9.65 / 2, 0.001);
});

test('fillet that does not fit is drawn sharp and named in missing', () => {
  const rec = JSON.parse(JSON.stringify(byKey('6_5_x_55_se')));
  rec.cartridge.lengths.L2 = rec.cartridge.lengths.L1 + 0.5; // shoulder 0.5 mm long, r1Min 3.5 needs more
  const m = D.drawingModel(rec);
  assert.ok(m.ok);
  assert.ok(m.missing.includes('r1Min (fillet does not fit)'), m.missing.join(', '));
});

test('filletArc tangent points lie at radius rho from the arc centre', () => {
  const arc = D.filletArc([0, 0], [10, 0], [10, -10], 2);
  assert.ok(arc);
  assert.deepEqual(arc[0].map((v) => +v.toFixed(6)), [8, 0]);
  assert.deepEqual(arc[arc.length - 1].map((v) => +v.toFixed(6)), [10, -2]);
});

test('bullet 223 Rem.: base at L3 - G1, cylinder to zb + 0.4·Lb, tip at L6 with meplat max(0.08·G1, 1.27)', () => {
  const m = D.drawingModel(byKey('223_rem'));
  const b = m.bullet;
  near(b.full[0][0], 39.0, 0.001, 'base');
  near(b.zc, 39.0 + 0.4 * (57.4 - 39.0), 0.001, 'cylinder end');
  near(b.meplat, 0.635, 0.001, 'meplat radius');
  near(b.full[b.full.length - 2][0], 57.4, 0.001, 'tip z');
});

test('22 Long Rifle heeled bullet: exposed diameter H2, seated heel H2 - 2·tb', () => {
  const m = D.drawingModel(byKey('22_long_rifle'));
  near(m.bullet.rsExp, 5.72 / 2, 0.001, 'exposed radius');
  const seated = m.bullet.full.filter(([z]) => z < 15.57);
  assert.ok(seated.some(([, r]) => Math.abs(r - (5.72 / 2 - 0.6)) < 0.001), 'heel radius');
});

test('nose shapes: flat pistol meplat 0.55·G1, rounded pistol 0.15·G1, semi_wadcutter 0.6·G1', () => {
  const flat = D.drawingModel(byKey('40_s_w')).bullet;
  near(flat.meplat, 0.55 * 10.17 / 2, 0.001, 'flat');
  const rounded = D.drawingModel(byKey('9_mm_luger')).bullet;
  near(rounded.meplat, 0.15 * 9.03 / 2, 0.001, 'rounded');
  const sw = D.drawingModel(byKey('357_magnum')).bullet;
  near(sw.meplat, 0.6 * 9.12 / 2, 0.001, 'semi_wadcutter');
  const zb = 32.77 - 0.6 * 9.12;
  near(sw.zc, zb + 0.78 * (40.39 - zb), 0.001, 'semi cylinder end');
});

test('wall thickness tn and tb for 223 Rem.', () => {
  const m = D.drawingModel(byKey('223_rem'));
  near(m.cp.tn, 0.365, 0.001, 'tn');
  near(m.cp.tb, 0.6, 0.001, 'tb');
});

test('primer pocket diameter and depth per primer type', () => {
  const sr = D.drawingModel(byKey('223_rem')).pocket;
  assert.deepEqual(sr, { d: 4.45, depth: 3.04 });
  const lr = D.drawingModel(byKey('308_win')).pocket;
  assert.deepEqual(lr, { d: 5.33, depth: 3.3 });
  assert.equal(D.drawingModel(byKey('22_long_rifle')).pocket, null);
});

test('solid head length w follows the brief', () => {
  near(D.drawingModel(byKey('223_rem')).w, 4.54, 0.001, '223 pocket+1.5');
  near(D.drawingModel(byKey('300_win_mag')).w, 4.8, 0.001, '300 WM pocket+1.5 (depth 3.3)');
});

test('belted case without R3 draws without the belt and names R3', () => {
  const rec = JSON.parse(JSON.stringify(byKey('300_win_mag')));
  delete rec.cartridge.caseHead.R3;
  const m = D.drawingModel(rec);
  assert.ok(m.ok);
  assert.ok(m.missing.includes('R3'));
  assert.ok(!hasPoint(m.cp.outer, 5.59, 6.755, 0.01), 'no belt');
});

test('missing required value returns no drawing and names it', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete rec.cartridge.projectile.G1;
  const m = D.drawingModel(rec);
  assert.equal(m.ok, false);
  assert.ok(m.missing.includes('projectile.G1'));
});
