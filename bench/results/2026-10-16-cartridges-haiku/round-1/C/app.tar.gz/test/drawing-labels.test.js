const test = require('node:test');
const assert = require('node:assert/strict');
const CARTRIDGES = require('../cartridges.js');
const D = require('../drawing.js');

// Liang-Barsky clip: true when the segment passes through the box.
function segmentHitsBox([x1, y1, x2, y2], b) {
  let t0 = 0;
  let t1 = 1;
  const dx = x2 - x1;
  const dy = y2 - y1;
  const clip = (p, q) => {
    if (p === 0) return q >= 0;
    const r = q / p;
    if (p < 0) {
      if (r > t1) return false;
      if (r > t0) t0 = r;
    } else {
      if (r < t0) return false;
      if (r < t1) t1 = r;
    }
    return true;
  };
  return clip(-dx, x1 - b.x0) && clip(dx, b.x1 - x1) && clip(-dy, y1 - b.y0) && clip(dy, b.y1 - y1) && t0 <= t1;
}

const boxesOverlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

for (const record of CARTRIDGES) {
  test(`labels of ${record.name} are disjoint and clear of the outline`, () => {
    const m = D.drawingModel(record);
    assert.ok(m.ok, `${record.name} draws`);
    const segs = D.outlineSegments(m);
    m.labels.forEach((label, i) => {
      for (const seg of segs) {
        assert.ok(!segmentHitsBox(seg, label.box), `${record.name}: "${label.text}" touches a line ${seg.map((v) => v.toFixed(2))}`);
      }
      m.labels.slice(i + 1).forEach((other) => {
        assert.ok(!boxesOverlap(label.box, other.box), `${record.name}: "${label.text}" overlaps "${other.text}"`);
      });
    });
  });
}

test('every dimension symbol required by the spec is labelled for 308 Win.', () => {
  const m = D.drawingModel(CARTRIDGES.find((c) => c.key === '308_win'));
  const texts = m.labels.map((l) => l.text);
  for (const sym of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(texts.includes(sym) || texts.some((t) => t.startsWith(sym.split(' ')[0] + ' ') && t === sym), `${sym} missing in ${texts}`);
  }
});
