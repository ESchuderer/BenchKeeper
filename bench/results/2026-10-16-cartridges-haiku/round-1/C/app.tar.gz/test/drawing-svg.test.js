const test = require('node:test');
const assert = require('node:assert/strict');
const CARTRIDGES = require('../cartridges.js');
const D = require('../drawing.js');

const rec = (key) => CARTRIDGES.find((c) => c.key === key);

test('SVG has mm viewBox, full width and the accessible name', () => {
  const { svg } = D.renderDrawing(rec('223_rem'));
  assert.match(svg, /<svg class="drawing"[^>]*viewBox="-?[\d.]+ -?[\d.]+ [\d.]+ [\d.]+"/);
  assert.match(svg, /width="100%"/);
  assert.match(svg, /aria-label="223 Rem\. drawing"/);
});

test('SVG has a dash-dot centre line on the axis', () => {
  const { svg } = D.renderDrawing(rec('223_rem'));
  assert.match(svg, /<line class="centre" x1="[-\d.]+" y1="0" x2="[-\d.]+" y2="0"\/>/);
});

test('title block has name, C.I.P. table, revised date, units and scale', () => {
  const { svg } = D.renderDrawing(rec('9_mm_luger'));
  for (const text of ['9 mm Luger', 'C.I.P. table IV · revised 2008-09-23', 'Dimensions in mm', 'Scale 1:1']) {
    assert.ok(svg.includes(text), text);
  }
});

test('names are escaped in the SVG', () => {
  const { svg } = D.renderDrawing(rec('40_s_w'));
  assert.ok(svg.includes('aria-label="40 S.&amp; W. drawing"'));
  assert.ok(!svg.includes('S.& W.'));
});

test('alpha dimension is labelled with the included angle', () => {
  const m = D.drawingModel(rec('223_rem'));
  const alpha = m.labels.find((l) => l.text.startsWith('α'));
  assert.equal(alpha.text, 'α 46°');
});

test('alpha arc spans the included angle about the cone apex', () => {
  const m = D.drawingModel(rec('223_rem'));
  const { apex, rho, points } = m.alphaArc;
  const half = 46 * Math.PI / 360;
  const angle = (p) => Math.atan2(-p[1], apex[0] - p[0]);
  const span = angle(points[points.length - 1]) - angle(points[0]);
  assert.ok(Math.abs(span - 2 * half) < 1e-6, `span ${span}`);
  for (const p of points) assert.ok(Math.abs(Math.hypot(p[0] - apex[0], p[1]) - rho) < 1e-9);
});
