const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../format.js');
const CARTRIDGES = require('../cartridges.js');

const byKey = (key) => CARTRIDGES.find((c) => c.key === key);

test('numbers keep the decimal point and drop thousands separators', () => {
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(4150.0), '4150');
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(0.4), '0.4');
});

test('angles as degrees and as degree-minute-second object', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle({ degrees: 50, minutes: 35, seconds: 2 }), '50°35\'02"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
});

test('value followed by its tolerance after one space', () => {
  assert.equal(F.formatWithTol(19.15, -0.25), '19.15 -0.25');
  assert.equal(F.formatWithTol(39.62, undefined), '39.62');
});

test('symbol overrides', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β',
    delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', E1: 'E1', R3: 'R3',
  };
  for (const [field, symbol] of Object.entries(expected)) {
    assert.equal(F.symbolOf(field), symbol, field);
  }
});

test('units by field', () => {
  assert.equal(F.unitOf('L3'), 'mm');
  assert.equal(F.unitOf('G1'), 'mm');
  assert.equal(F.unitOf('Pmax'), 'bar');
  assert.equal(F.unitOf('PK'), 'bar');
  assert.equal(F.unitOf('PE'), 'bar');
  assert.equal(F.unitOf('EE'), 'J');
  assert.equal(F.unitOf('M'), 'g');
  assert.equal(F.unitOf('Q'), 'mm²');
  assert.equal(F.unitOf('N'), '—');
  assert.equal(F.unitOf('alpha'), '—');
  assert.equal(F.unitOf('i'), '—');
});

test('sections of 223 Rem. have no tolerance rows and angles keep their degree sign', () => {
  const { cartridge, chamber } = F.sectionsOf(byKey('223_rem'));
  const titles = cartridge.map((s) => s.title);
  assert.deepEqual(titles, ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile']);
  const lengths = cartridge.find((s) => s.title === 'Lengths');
  assert.deepEqual(lengths.rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  assert.equal(lengths.rows[0].value, '36.52 -0.2');
  assert.equal(lengths.rows[0].unit, 'mm');
  const rifling = chamber.find((s) => s.title === 'Rifling');
  assert.deepEqual(rifling.rows.map((r) => r.symbol), ['G', 'G1', 'α1', 'h', 'i', 's']);
  assert.equal(rifling.rows[2].value, '90°');
  assert.equal(rifling.rows[4].value, '3°10\'36"');
});

test('empty sections are omitted', () => {
  const { chamber } = F.sectionsOf(byKey('9_mm_luger'));
  assert.ok(!chamber.some((s) => s.title === 'Junction cone'));
});
