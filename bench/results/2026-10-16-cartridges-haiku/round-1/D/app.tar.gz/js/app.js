// Page controller: start page list and cartridge detail view, rendered from the hash route.
(function () {
  'use strict';

  var C = window.Cartridges;
  var records = CARTRIDGE_RECORDS;
  var app = document.getElementById('app');
  var state = { query: '', family: 'All' };

  function esc(text) { return C.esc(text); }

  function renderList() {
    var options = C.FAMILIES.map(function (f) {
      return '<option value="' + esc(f) + '"' + (f === state.family ? ' selected' : '') + '>' + esc(f) + '</option>';
    }).join('');
    app.innerHTML =
      '<section class="list-view">' +
      '<h1>Cartridges</h1>' +
      '<div class="controls">' +
      '<label class="field">Search<input type="search" id="search" autocomplete="off" value="' + esc(state.query) + '"></label>' +
      '<label class="field">Family<select id="family">' + options + '</select></label>' +
      '</div>' +
      '<p class="count" id="count" aria-live="polite"></p>' +
      '<ul class="cartridge-list" id="list"></ul>' +
      '</section>';
    document.title = 'Cartridges';
    document.getElementById('search').addEventListener('input', function (e) {
      state.query = e.target.value;
      updateList();
    });
    document.getElementById('family').addEventListener('change', function (e) {
      state.family = e.target.value;
      updateList();
    });
    updateList();
  }

  function updateList() {
    var found = C.filterCartridges(records, state);
    document.getElementById('count').textContent = C.countText(found.length);
    document.getElementById('list').innerHTML = found.map(function (rec) {
      return '<li><a href="' + esc(C.hashFor(rec.key)) + '">' + esc(rec.name) + '</a>' +
        '<span class="meta"><span class="family">' + esc(rec.family) + '</span>' +
        '<span class="l3">L3 ' + esc(rec.cartridge.lengths.L3) + ' mm</span></span></li>';
    }).join('');
  }

  function field(label, valueHtml) {
    return '<dt>' + esc(label) + '</dt><dd>' + valueHtml + '</dd>';
  }

  function valueTables(rec, section) {
    return C.valueGroups(rec, section).map(function (group) {
      return '<section class="value-group"><h3>' + esc(group.title) + '</h3>' +
        '<table><thead><tr><th scope="col">Symbol</th><th scope="col">Value</th><th scope="col">Unit</th></tr></thead><tbody>' +
        group.rows.map(function (row) {
          return '<tr><td>' + esc(row.symbol) + '</td><td class="num">' + esc(row.value) + '</td><td>' + esc(row.unit) + '</td></tr>';
        }).join('') +
        '</tbody></table></section>';
    }).join('');
  }

  function renderDetail(key) {
    var rec = records.filter(function (r) { return r.key === key; })[0];
    if (!rec) {
      document.title = 'Cartridge not found · Cartridges';
      app.innerHTML =
        '<section class="detail">' +
        '<nav class="toolbar"><a href="#/">All cartridges</a></nav>' +
        '<h1>Cartridge not found</h1>' +
        '<p>No cartridge has the key <code>' + esc(key) + '</code>.</p>' +
        '</section>';
      return;
    }
    document.title = rec.name + ' · Cartridges';
    var a = rec.annotations;
    var cap = a.publishedCapacity;
    var fields = [];
    if (rec.alternativeNames && rec.alternativeNames.length) {
      fields.push(field('Alternative names', rec.alternativeNames.map(esc).join(', ')));
    }
    fields.push(field('Family', esc(rec.family)));
    fields.push(field('Category', esc(a.category)));
    fields.push(field('Primer type', esc(a.primerType)));
    fields.push(field('C.I.P. table', esc(rec.tab)));
    fields.push(field('Country', esc(rec.country)));
    fields.push(field('Published', esc(rec.published)));
    fields.push(field('Revised', esc(rec.revised)));
    fields.push(field('Pressure method', esc(rec.pressureMethod)));
    if (cap) {
      var capHtml = esc(C.formatCapacity(cap)) + ', source <a href="' + esc(cap.url) + '">' + esc(cap.source) + '</a>';
      if (cap.note) capHtml += '<span class="note">' + esc(cap.note) + '</span>';
      fields.push(field('Water capacity', capHtml));
    }
    app.innerHTML =
      '<article class="detail">' +
      '<nav class="toolbar"><a href="#/">All cartridges</a><button type="button" id="print-button">Print</button></nav>' +
      '<h1>' + esc(rec.name) + '</h1>' +
      '<dl class="facts">' + fields.join('') + '</dl>' +
      '<figure class="drawing">' + C.drawingSvg(rec) + '</figure>' +
      '<h2>Cartridge</h2><div class="value-groups">' + valueTables(rec, 'cartridge') + '</div>' +
      '<h2>Chamber</h2><div class="value-groups">' + valueTables(rec, 'chamber') + '</div>' +
      '<p class="print-footer">Source: C.I.P. TDCC, revised ' + esc(rec.revised) + '</p>' +
      '</article>';
    document.getElementById('print-button').addEventListener('click', function () {
      window.print();
    });
  }

  function render() {
    var route = C.parseHash(window.location.hash);
    if (route.view === 'detail') renderDetail(route.key);
    else renderList();
  }

  window.addEventListener('hashchange', render);
  render();
})();
