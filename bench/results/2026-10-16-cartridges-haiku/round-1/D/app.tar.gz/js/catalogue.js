// Start page filtering: name and alternative-name search, family filter, result count.
(function (global) {
  'use strict';

  var FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  function matches(record, needle) {
    if (record.name.toLowerCase().indexOf(needle) !== -1) return true;
    return (record.alternativeNames || []).some(function (alt) {
      return alt.toLowerCase().indexOf(needle) !== -1;
    });
  }

  function filterCartridges(records, options) {
    var needle = options.query.trim().toLowerCase();
    var family = options.family;
    return records.filter(function (record) {
      if (family && family !== 'All' && record.family !== family) return false;
      return needle === '' || matches(record, needle);
    });
  }

  function countText(count) {
    return count === 1 ? '1 cartridge' : count + ' cartridges';
  }

  var api = {
    FAMILIES: FAMILIES,
    filterCartridges: filterCartridges,
    countText: countText
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.Cartridges = Object.assign(global.Cartridges || {}, api);
})(typeof window !== 'undefined' ? window : globalThis);
