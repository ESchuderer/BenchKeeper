// Inline SVG drawing of one cartridge, 1 SVG unit = 1 mm, axis horizontal, head on the left.
// Upper half: outside view (y = -r). Lower half: section (y = +r), cut walls hatched.
(function (global) {
  'use strict';

  var fmt = typeof require === 'function' ? require('./format.js') : global.Cartridges;
  var geo = typeof require === 'function' ? require('./geometry.js') : global.Cartridges;

  var FS = 2.6;          // label font size (mm)
  var CHAR_W = 0.7;      // conservative glyph width (em) for label boxes, wider than system-ui digits
  var ARROW_LEN = 1.6;
  var ARROW_HALF = 0.5;
  var ROW_GAP = 4;       // section edge to first axial dimension row
  var ROW_PITCH = 4.6;   // spacing of axial dimension rows

  function esc(text) {
    return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function num(n) {
    return String(Number(n.toFixed(3)));
  }

  function textBox(text, x, y, anchor) {
    var w = text.length * CHAR_W * FS;
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0: x0, x1: x0 + w, y0: y - 1.0 * FS, y1: y + 0.35 * FS };
  }

  function boxesOverlap(a, b, pad) {
    return a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
  }

  function pointInBox(p, b, pad) {
    return p[0] > b.x0 - pad && p[0] < b.x1 + pad && p[1] > b.y0 - pad && p[1] < b.y1 + pad;
  }

  // Points along a polyline at most `step` apart.
  function sample(poly, step) {
    var out = [];
    for (var i = 0; i < poly.length - 1; i++) {
      var a = poly[i];
      var b = poly[i + 1];
      var n = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / step));
      for (var k = 0; k < n; k++) {
        out.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]);
      }
    }
    out.push(poly[poly.length - 1]);
    return out;
  }

  // Closed arrowhead with its tip at `tip`, opening back against the unit direction `dir`.
  function arrowD(tip, dir) {
    var base = [tip[0] - dir[0] * ARROW_LEN, tip[1] - dir[1] * ARROW_LEN];
    var perp = [-dir[1] * ARROW_HALF, dir[0] * ARROW_HALF];
    return 'M' + num(tip[0]) + ' ' + num(tip[1]) +
      'L' + num(base[0] + perp[0]) + ' ' + num(base[1] + perp[1]) +
      'L' + num(base[0] - perp[0]) + ' ' + num(base[1] - perp[1]) + 'Z';
  }

  function polyD(poly, close) {
    return 'M' + poly.map(function (p) { return num(p[0]) + ' ' + num(p[1]); }).join('L') + (close ? 'Z' : '');
  }

  function valueText(sym, value, tol) {
    return sym + ' ' + fmt.formatWithTolerance(value, tol);
  }

  function layoutDrawing(record) {
    var g = geo.buildGeometry(record);
    var c = record.cartridge;
    var ch = c.caseHead;
    var co = c.collar;
    var jc = c.junctionCone || {};
    var lg = c.lengths;
    var pc = c.powderChamber;
    var pj = c.projectile;
    var bullet = g.bullet;

    var up = function (p) { return [p[1], -p[0]]; };
    var down = function (p) { return [p[1], p[0]]; };

    // Outline in SVG coordinates: used for label clearance and the bounds.
    var upperLines = [g.outer.map(up)];
    if (bullet) upperLines.push([up(g.mouth)].concat(bullet.exposed.map(up)));
    var sectionPolys = g.section ? [g.section.map(down)] : [];
    var bulletPolys = bullet ? [bullet.cut.map(down)] : [];
    var outlinePoints = [];
    upperLines.concat(sectionPolys, bulletPolys).forEach(function (poly) {
      outlinePoints = outlinePoints.concat(sample(poly, 0.2));
    });

    var R1h = ch.R1 / 2;
    var Rmax = Math.max(R1h, ch.R3 !== undefined ? ch.R3 / 2 : 0);
    var headR = g.outer[1][0];
    var lines = [];
    var arrows = [];
    var arcs = [];
    var leaders = [];
    var labels = [];
    var placed = [];

    function dimension(a, b) {
      lines.push([a[0], a[1], b[0], b[1]]);
      var dx = b[0] - a[0];
      var dy = b[1] - a[1];
      var l = Math.hypot(dx, dy);
      var u = [dx / l, dy / l];
      arrows.push(arrowD(a, u));
      arrows.push(arrowD(b, [-u[0], -u[1]]));
    }

    function addLabel(text, x, y, anchor) {
      var box = textBox(text, x, y, anchor);
      labels.push({ text: text, x: x, y: y, anchor: anchor, box: box });
      placed.push(box);
    }

    // Axial dimension in a row below the section, extension lines from the two features.
    function axial(row, text, z0, z1, rA, rB) {
      var y = Rmax + ROW_GAP + ROW_PITCH * row;
      lines.push([z0, rA + 0.6, z0, y + 0.6]);
      lines.push([z1, rB + 0.6, z1, y + 0.6]);
      dimension([z0, y], [z1, y]);
      if (row === 0) {
        addLabel(text, -1.5, y + 1.1, 'end');
      } else {
        addLabel(text, (z0 + z1) / 2, y - 1.0, 'middle');
      }
    }

    // Lowest-top outline point in the x range; the label sits above it.
    function envelopeTop(x0, x1, fallback) {
      var top = null;
      outlinePoints.forEach(function (p) {
        if (p[0] >= x0 && p[0] <= x1 && (top === null || p[1] < top)) top = p[1];
      });
      return top === null ? fallback : top;
    }

    // Label above the upper outline, stepped up until it clears placed labels; leader to its tip.
    function placeAbove(text, x, tipY) {
      var w = text.length * CHAR_W * FS;
      var base = envelopeTop(x - w / 2 - 1, x + w / 2 + 1, tipY) - 0.35 * FS - 0.8;
      var box = textBox(text, x, base, 'middle');
      while (placed.some(function (p) { return boxesOverlap(p, box, 0.6); })) {
        base -= 1.4 * FS + 0.8;
        box = textBox(text, x, base, 'middle');
      }
      placed.push(box);
      labels.push({ text: text, x: x, y: base, anchor: 'middle', box: box });
      if (tipY - (base + 0.35 * FS) > 0.2) leaders.push([x, base + 0.35 * FS, x, tipY]);
    }

    // Diameter: extension lines from the feature (upper and lower), vertical dimension line across the axis.
    function diameter(text, zf, xD, d) {
      var rad = d / 2;
      var dir = xD >= zf ? 1 : -1;
      lines.push([zf + dir * 0.6, -rad, xD, -rad]);
      lines.push([zf + dir * 0.6, rad, xD, rad]);
      dimension([xD, -rad], [xD, rad]);
      placeAbove(text, xD, -rad - 0.8);
    }

    // Head and rim corner: the R dimension runs from the head face to the rim corner level.
    axial(0, valueText('R', ch.R, ch.RTol), 0, ch.R, headR, R1h);
    if (g.bottleneck) {
      axial(1, valueText('L1', lg.L1, lg.L1Tol), 0, lg.L1, headR, pc.P2 / 2);
      axial(2, valueText('L2', lg.L2, lg.L2Tol), 0, lg.L2, headR, co.H1 / 2);
    }
    axial(3, valueText('L3', lg.L3, lg.L3Tol), 0, lg.L3, headR, co.H2 / 2);
    if (bullet) axial(4, valueText('L6', lg.L6, undefined), 0, lg.L6, headR, bullet.tipR);

    // Diameters, ordered by their dimension line position.
    var beta = ch.beta === undefined ? 90 : fmt.angleDegrees(ch.beta);
    var zf1 = g.rim === 'rimfire'
      ? Math.min(ch.R / 2, (ch.R1 - pc.P1) / 2)
      : (beta < 90 && ch.f !== undefined ? ch.f : 0);
    var dias = [{ text: valueText('R1', ch.R1, undefined), zf: zf1, xD: zf1 - 5.5, d: ch.R1 }];
    if (g.groove) {
      dias.push({ text: valueText('E1', ch.E1, undefined), zf: ch.R + ch.eMin / 2, xD: ch.R + ch.eMin + 1.2, d: ch.E1 });
    }
    dias.push({ text: valueText('P1', pc.P1, undefined), zf: g.bodyStart, xD: g.bodyStart + 3, d: pc.P1 });
    if (g.bottleneck) {
      dias.push({ text: valueText('P2', pc.P2, pc.P2Tol), zf: lg.L1, xD: lg.L1 + 2.5, d: pc.P2 });
      dias.push({ text: valueText('H1', co.H1, undefined), zf: lg.L2, xD: lg.L2 + 2.5, d: co.H1 });
    }
    dias.push({ text: valueText('H2', co.H2, undefined), zf: lg.L3, xD: lg.L3 + 2.5, d: co.H2 });
    if (bullet) dias.push({ text: valueText('G1', pj.G1, undefined), zf: bullet.zn, xD: bullet.zn + 2.5, d: pj.G1 });
    dias.sort(function (a, b) { return a.xD - b.xD; });
    dias.forEach(function (dm) { diameter(dm.text, dm.zf, dm.xD, dm.d); });

    // Included shoulder angle: arc about the apex of the shoulder cone, with arrowheads.
    if (g.bottleneck && jc.alpha !== undefined) {
      var alpha = fmt.angleDegrees(jc.alpha) * Math.PI / 180;
      var P2h = pc.P2 / 2;
      var H1h = co.H1 / 2;
      var zA = lg.L1 + P2h * (lg.L2 - lg.L1) / (P2h - H1h);
      var Ra = Math.max(3, 0.5 * (zA - lg.L1));
      var arc = [];
      for (var i = 0; i <= 12; i++) {
        var phi = -alpha / 2 + alpha * i / 12;
        arc.push([zA - Ra * Math.cos(phi), Ra * Math.sin(phi)]);
      }
      arcs.push(polyD(arc, false));
      var tangentUp = [-Math.sin(-alpha / 2), -Math.cos(-alpha / 2)];
      var tangentLow = [Math.sin(alpha / 2), Math.cos(alpha / 2)];
      arrows.push(arrowD(arc[0], tangentUp));
      arrows.push(arrowD(arc[arc.length - 1], tangentLow));
      outlinePoints = outlinePoints.concat(sample(arc, 0.2));
      placeAbove('α ' + fmt.formatAngle(jc.alpha), arc[0][0], arc[0][1]);
    }

    // Bounds of everything drawn so far.
    var xs = [];
    var ys = [];
    lines.forEach(function (l) { xs.push(l[0], l[2]); ys.push(l[1], l[3]); });
    labels.forEach(function (l) { xs.push(l.box.x0, l.box.x1); ys.push(l.box.y0, l.box.y1); });
    outlinePoints.forEach(function (p) { xs.push(p[0]); ys.push(p[1]); });

    // Title block below the axial rows.
    var tbY = Rmax + ROW_GAP + ROW_PITCH * 4 + 4.5;
    var tbX = Math.min.apply(null, xs) + 1;
    var tb = [
      { text: record.name, size: 3.4, bold: true, y: tbY + 3.4 },
      { text: 'C.I.P. table ' + record.tab, size: FS, bold: false, y: tbY + 7.8 },
      { text: 'Revised ' + record.revised, size: FS, bold: false, y: tbY + 11.4 },
      { text: 'Dimensions in mm', size: FS, bold: false, y: tbY + 15 }
    ];
    if (g.missing.length) {
      tb.push({ text: 'Not drawn: ' + g.missing.join(', '), size: FS, bold: false, y: tbY + 18.6 });
    }
    var barY = tbY + (g.missing.length ? 23 : 19.5);
    var scaleBar = { x0: tbX, x1: tbX + 10, y: barY };
    tb.forEach(function (t) {
      t.x = tbX;
      xs.push(tbX, tbX + t.text.length * CHAR_W * t.size);
      ys.push(t.y + 0.8 * t.size, t.y - 0.8 * t.size);
    });
    xs.push(scaleBar.x1 + 6);
    ys.push(barY + 1.2);

    var minX = Math.min.apply(null, xs) - 2;
    var maxX = Math.max.apply(null, xs) + 2;
    var minY = Math.min.apply(null, ys) - 2;
    var maxY = Math.max.apply(null, ys) + 2;

    return {
      key: record.key,
      name: record.name,
      missing: g.missing,
      viewBox: { x: minX, y: minY, w: maxX - minX, h: maxY - minY },
      centreLine: [minX, 0, maxX, 0],
      upperLines: upperLines,
      sectionPolys: sectionPolys,
      bulletPolys: bulletPolys,
      lines: lines,
      arrows: arrows,
      arcs: arcs,
      leaders: leaders,
      labels: labels,
      titleBlock: tb,
      scaleBar: scaleBar,
      outlinePoints: outlinePoints
    };
  }

  function renderSvg(layout) {
    var id = 'hatch-' + layout.key;
    var v = layout.viewBox;
    var out = [];
    out.push('<svg class="cartridge-drawing" role="img" aria-label="' + esc(layout.name) + ' drawing"' +
      ' viewBox="' + num(v.x) + ' ' + num(v.y) + ' ' + num(v.w) + ' ' + num(v.h) + '"' +
      ' xmlns="http://www.w3.org/2000/svg">');
    out.push('<defs><pattern id="' + id + '" width="1.2" height="1.2" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="1.2" stroke="currentColor" stroke-width="0.25"/></pattern></defs>');
    var c = layout.centreLine;
    out.push('<line class="centre" x1="' + num(c[0]) + '" y1="0" x2="' + num(c[2]) + '" y2="0" stroke="currentColor" stroke-width="0.2" stroke-dasharray="6 1.2 1.2 1.2"/>');
    out.push('<g class="outside">' + layout.upperLines.map(function (p) {
      return '<path d="' + polyD(p, false) + '"/>';
    }).join('') + '</g>');
    out.push('<g class="section">' + layout.sectionPolys.concat(layout.bulletPolys).map(function (p) {
      return '<path d="' + polyD(p, true) + '" fill="url(#' + id + ')"/>';
    }).join('') + '</g>');
    out.push('<g class="dims"><path d="' + layout.lines.map(function (l) {
      return 'M' + num(l[0]) + ' ' + num(l[1]) + 'L' + num(l[2]) + ' ' + num(l[3]);
    }).concat(layout.leaders.map(function (l) {
      return 'M' + num(l[0]) + ' ' + num(l[1]) + 'L' + num(l[2]) + ' ' + num(l[3]);
    })).join('') + '"/>');
    out.push('<path class="arc" d="' + layout.arcs.join('') + '"/>');
    out.push('<path class="arrow" d="' + layout.arrows.join('') + '"/></g>');
    out.push('<g class="labels">' + layout.labels.map(function (l) {
      return '<text x="' + num(l.x) + '" y="' + num(l.y) + '" text-anchor="' + l.anchor + '" font-size="' + FS + '">' + esc(l.text) + '</text>';
    }).join('') + '</g>');
    var sb = layout.scaleBar;
    out.push('<g class="titleblock">' + layout.titleBlock.map(function (t) {
      return '<text x="' + num(t.x) + '" y="' + num(t.y) + '" font-size="' + t.size + '"' +
        (t.bold ? ' font-weight="bold"' : '') + '>' + esc(t.text) + '</text>';
    }).join('') +
      '<path d="M' + num(sb.x0) + ' ' + num(sb.y) + 'L' + num(sb.x1) + ' ' + num(sb.y) +
      'M' + num(sb.x0) + ' ' + num(sb.y - 0.8) + 'L' + num(sb.x0) + ' ' + num(sb.y + 0.8) +
      'M' + num(sb.x1) + ' ' + num(sb.y - 0.8) + 'L' + num(sb.x1) + ' ' + num(sb.y + 0.8) + '" stroke="currentColor" stroke-width="0.25" fill="none"/>' +
      '<text x="' + num(sb.x1 + 1.5) + '" y="' + num(sb.y + 1.1) + '" font-size="' + FS + '">10 mm</text>' +
      '</g>');
    out.push('</svg>');
    return out.join('');
  }

  function drawingSvg(record) {
    return renderSvg(layoutDrawing(record));
  }

  var api = {
    layoutDrawing: layoutDrawing,
    renderSvg: renderSvg,
    drawingSvg: drawingSvg,
    boxesOverlap: boxesOverlap,
    pointInBox: pointInBox,
    esc: esc
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.Cartridges = Object.assign(global.Cartridges || {}, api);
})(typeof window !== 'undefined' ? window : globalThis);
