// Display rules for cartridge values: symbols, units, number and angle formats, tolerances, rim type.
(function (global) {
  'use strict';

  var ANGLE_FIELDS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  // Fields not listed here are lengths or diameters in mm.
  var UNITS = {
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: '',
    grH2O: 'gr H2O'
  };

  var SECTION_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Misc',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling'
  };

  function symbolOf(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unitOf(field) {
    if (ANGLE_FIELDS.indexOf(field) !== -1) return '';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  function formatNumber(value) {
    return String(value);
  }

  function formatAngle(value) {
    if (typeof value === 'number') return formatNumber(value) + '°';
    return value.degrees + '°' + value.minutes + "'" + value.seconds + '"';
  }

  function angleDegrees(value) {
    if (typeof value === 'number') return value;
    return value.degrees + value.minutes / 60 + value.seconds / 3600;
  }

  function formatWithTolerance(value, tolerance) {
    if (tolerance === undefined) return formatNumber(value);
    return formatNumber(value) + ' ' + formatNumber(tolerance);
  }

  // Rim type per the brief: family first, then R1/P1 ratio.
  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    var ratio = record.cartridge.caseHead.R1 / record.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Groups of display rows for record.cartridge or record.chamber.
  // A field X with a sibling XTol is shown as one row "X value tol"; the Tol field has no row.
  function valueGroups(record, section) {
    var root = record[section];
    var groups = [];
    Object.keys(root).forEach(function (groupKey) {
      var values = root[groupKey];
      var rows = [];
      Object.keys(values).forEach(function (field) {
        if (/Tol$/.test(field) && Object.prototype.hasOwnProperty.call(values, field.slice(0, -3))) return;
        var value = values[field];
        var tolKey = field + 'Tol';
        var shown = ANGLE_FIELDS.indexOf(field) !== -1
          ? formatAngle(value)
          : formatWithTolerance(value, values[tolKey]);
        rows.push({ symbol: symbolOf(field), value: shown, unit: unitOf(field) });
      });
      if (rows.length) {
        groups.push({ title: SECTION_TITLES[groupKey] || groupKey, rows: rows });
      }
    });
    return groups;
  }

  function formatCapacity(capacity) {
    return formatNumber(capacity.grH2O) + ' gr H2O';
  }

  var api = {
    symbolOf: symbolOf,
    unitOf: unitOf,
    formatNumber: formatNumber,
    formatAngle: formatAngle,
    angleDegrees: angleDegrees,
    formatWithTolerance: formatWithTolerance,
    rimType: rimType,
    valueGroups: valueGroups,
    formatCapacity: formatCapacity,
    ANGLE_FIELDS: ANGLE_FIELDS
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.Cartridges = Object.assign(global.Cartridges || {}, api);
})(typeof window !== 'undefined' ? window : globalThis);
