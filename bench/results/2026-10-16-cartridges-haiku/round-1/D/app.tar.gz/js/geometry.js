// Cartridge profile geometry from the record values. Points are [r, z] in mm:
// r is the radius, z runs from the head face (z = 0) to the mouth. Rules follow the brief.
(function (global) {
  'use strict';

  var fmt = typeof require === 'function' ? require('./format.js') : global.Cartridges;

  var ARC_STEPS = 24;
  var POCKETS = {
    sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04],
    lp: [5.33, 3.04], lpm: [5.33, 3.04],
    lr: [5.33, 3.3], lrm: [5.33, 3.3]
  };

  function sub(a, b) { return [a[0] - b[0], a[1] - b[1]]; }
  function add(a, b) { return [a[0] + b[0], a[1] + b[1]]; }
  function scale(a, s) { return [a[0] * s, a[1] * s]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1]; }
  function len(a) { return Math.hypot(a[0], a[1]); }
  function unit(a) { var l = len(a); return [a[0] / l, a[1] / l]; }
  function clamp(x, lo, hi) { return Math.min(hi, Math.max(lo, x)); }
  function rad(deg) { return deg * Math.PI / 180; }

  // Tangent arc replacing the corner v between the segments prev-v and v-next.
  function filletPoints(prev, v, next, rho, steps) {
    var u1 = unit(sub(prev, v));
    var u2 = unit(sub(next, v));
    var phi = Math.acos(clamp(dot(u1, u2), -1, 1));
    if (!(rho > 0) || phi < 1e-9 || phi > Math.PI - 1e-9) return [v];
    var half = phi / 2;
    var d = rho / Math.tan(half);
    var t1 = add(v, scale(u1, d));
    var t2 = add(v, scale(u2, d));
    var c = add(v, scale(unit(add(u1, u2)), rho / Math.sin(half)));
    var a1 = Math.atan2(t1[1] - c[1], t1[0] - c[0]);
    var sweep = Math.atan2(t2[1] - c[1], t2[0] - c[0]) - a1;
    while (sweep > Math.PI) sweep -= 2 * Math.PI;
    while (sweep <= -Math.PI) sweep += 2 * Math.PI;
    var pts = [];
    for (var i = 0; i <= steps; i++) {
      var a = a1 + sweep * i / steps;
      pts.push([c[0] + rho * Math.cos(a), c[1] + rho * Math.sin(a)]);
    }
    return pts;
  }

  // Fillet limited so that the tangent points stay on the two segments.
  function corner(prev, v, next, rho) {
    if (!(rho > 0)) return [v];
    var phi = Math.acos(clamp(dot(unit(sub(prev, v)), unit(sub(next, v))), -1, 1));
    var maxRho = 0.5 * Math.min(len(sub(prev, v)), len(sub(next, v))) * Math.tan(phi / 2);
    return filletPoints(prev, v, next, Math.min(rho, maxRho), ARC_STEPS);
  }

  // Bullet nose from the cylinder end (zn) to the flat tip at z = L6.
  function nosePoints(shape, rShank, zn, L6, n, tipR) {
    var pts = [];
    var i;
    if (shape === 'pointy') {
      var a = rShank - tipR;
      var rho = (a * a + n * n) / (2 * a);
      var centre = rShank - rho;
      var sweep = Math.atan2(n, rho - a);
      for (i = 0; i <= ARC_STEPS; i++) {
        var t = sweep * i / ARC_STEPS;
        pts.push([centre + rho * Math.cos(t), zn + rho * Math.sin(t)]);
      }
    } else if (shape === 'rounded') {
      for (i = 0; i <= ARC_STEPS; i++) {
        var q = Math.PI / 2 * i / ARC_STEPS;
        pts.push([tipR + (rShank - tipR) * Math.cos(q), zn + n * Math.sin(q)]);
      }
    } else {
      pts.push([rShank, zn], [tipR, L6]);
    }
    return pts;
  }

  function bulletFactors(shape, category, G1) {
    var pistol = category === 'pistol';
    var table = {
      pointy: { seat: 1.0, k: 0.40, tip: Math.max(0.08 * G1, 1.27) },
      rounded: { seat: pistol ? 0.4 : 0.8, k: pistol ? 0.65 : 0.55, tip: 0.15 * G1 },
      flat: { seat: pistol ? 0.4 : 0.8, k: pistol ? 0.70 : 0.60, tip: 0.55 * G1 },
      semi_wadcutter: { seat: 0.6, k: 0.78, tip: 0.6 * G1 }
    };
    return Object.prototype.hasOwnProperty.call(table, shape) ? table[shape] : null;
  }

  function buildBullet(G1, H2, L3, L6, shape, category, tb) {
    var f = bulletFactors(shape, category, G1);
    if (!f) return null;
    var heeled = H2 - G1 <= 0.015;
    var rShank = heeled ? H2 / 2 : G1 / 2;
    var heelR = heeled ? H2 / 2 - tb : G1 / 2;
    var zb = L3 - f.seat * G1;
    var zn = zb + f.k * (L6 - zb);
    var n = L6 - zn;
    var tipR = f.tip / 2;
    var nose = nosePoints(shape, rShank, zn, L6, n, tipR);
    var cut = [[0, zb], [heelR, zb]];
    if (heeled) cut.push([heelR, L3], [rShank, L3]);
    cut = cut.concat(nose, [[0, L6]]);
    return {
      shape: shape,
      zb: zb,
      zn: zn,
      heeled: heeled,
      shankR: rShank,
      heelR: heelR,
      tipR: tipR,
      cut: cut,
      exposed: [[rShank, L3]].concat(nose)
    };
  }

  // Wall thickness along z: tb along the body, tn along the neck, linear across the shoulder.
  function wallAt(z, walls, lg, bottleneck, bodyStart) {
    if (bottleneck) {
      if (z <= lg.L1) return walls.tb;
      if (z >= lg.L2) return walls.tn;
      return walls.tb + (walls.tn - walls.tb) * (z - lg.L1) / (lg.L2 - lg.L1);
    }
    return walls.tb + (walls.tn - walls.tb) * clamp((z - bodyStart) / (lg.L3 - bodyStart), 0, 1);
  }

  // Points with z >= z0, adding the crossing point at z0.
  function clipAbove(pts, z0) {
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i];
      if (p[1] < z0) continue;
      if (out.length === 0 && i > 0) {
        var q = pts[i - 1];
        var t = (z0 - q[1]) / (p[1] - q[1]);
        out.push([q[0] + t * (p[0] - q[0]), z0]);
      }
      out.push(p);
    }
    return out;
  }

  function buildGeometry(record) {
    var annot = record.annotations || {};
    var c = record.cartridge;
    var ch = c.caseHead;
    var co = c.collar;
    var jc = c.junctionCone || {};
    var lg = c.lengths;
    var pc = c.powderChamber;
    var pj = c.projectile;
    var missing = [];
    function miss(name) { if (missing.indexOf(name) === -1) missing.push(name); }

    var rim = fmt.rimType(record);
    var R = ch.R;
    var R1h = ch.R1 / 2;
    var P1h = pc.P1 / 2;
    var H2h = co.H2 / 2;
    var outer = [[0, 0]];
    var i;

    // Head face and rim edge.
    if (rim === 'rimfire') {
      var rho = Math.min(R / 2, (ch.R1 - pc.P1) / 2);
      var cx = R1h - rho;
      for (i = 0; i <= 16; i++) {
        var th = -Math.PI / 2 + Math.PI * i / 16;
        outer.push([cx + rho * Math.cos(th), rho + rho * Math.sin(th)]);
      }
      if (Math.abs(2 * rho - R) > 1e-9) outer.push([cx, R]);
      outer.push([P1h, R]);
    } else {
      var beta = ch.beta === undefined ? undefined : fmt.angleDegrees(ch.beta);
      if (beta !== undefined && beta < 90 && ch.f !== undefined) {
        var chamfer = Math.min(ch.f * Math.tan(rad(beta)), ch.R1 / 4);
        outer.push([R1h - chamfer, 0], [R1h, ch.f]);
      } else {
        outer.push([R1h, 0]);
      }
      outer.push([R1h, R]);
    }

    // Extractor groove or belt, then the body start.
    var E = ch.E;
    var E1 = ch.E1;
    var belted = rim === 'belted';
    var groove = E !== undefined && E1 !== undefined;
    if (!groove && (E !== undefined || E1 !== undefined)) miss(E === undefined ? 'E' : 'E1');
    if (groove && ch.eMin === undefined) { miss('eMin'); groove = false; }
    var belt = false;
    var beltEnd = null;
    var bodyStart;
    if (groove) {
      var E1h = E1 / 2;
      outer.push([E1h, R], [E1h, R + ch.eMin]);
      if (belted && ch.R3 !== undefined && ch.delta !== undefined) {
        belt = true;
        var R3h = ch.R3 / 2;
        beltEnd = R + ch.eMin + (R3h - E1h) / Math.tan(rad(fmt.angleDegrees(ch.delta)));
        outer.push([R3h, beltEnd], [R3h, E], [P1h, E]);
      } else {
        if (belted) miss(ch.R3 === undefined ? 'R3' : 'delta');
        outer.push([P1h, E]);
      }
      bodyStart = E;
    } else {
      outer.push([P1h, R]);
      bodyStart = R;
    }
    var bodyIndex = outer.length - 1;

    // Body, shoulder and neck.
    var mouth = [H2h, lg.L3];
    var bottleneck = jc.alpha !== undefined;
    if (bottleneck) {
      var needed = { L1: lg.L1, L2: lg.L2, P2: pc.P2, H1: co.H1 };
      Object.keys(needed).forEach(function (name) { if (needed[name] === undefined) miss(name); });
      bottleneck = needed.L1 !== undefined && needed.L2 !== undefined && needed.P2 !== undefined && needed.H1 !== undefined;
    }
    if (bottleneck) {
      var v1 = [pc.P2 / 2, lg.L1];
      var v2 = [co.H1 / 2, lg.L2];
      var bodyEnd = outer[outer.length - 1];
      outer = outer.concat(corner(bodyEnd, v1, v2, jc.r1Min), corner(v1, v2, mouth, jc.r2), [mouth]);
    } else {
      outer.push(mouth);
    }

    // Section walls, solid head and primer pocket.
    var G1 = pj.G1;
    var walls = null;
    if (G1 === undefined) {
      miss('G1');
    } else {
      var tn = (co.H2 - G1) / 2;
      walls = { tn: tn, tb: Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1h) };
    }
    var pocketSpec = rim === 'rimfire' ? undefined : POCKETS[annot.primerType];
    var pocket = pocketSpec ? { diameter: pocketSpec[0], depth: pocketSpec[1] } : null;
    var w = Math.max(2.5, 0.25 * P1h, pocket ? pocket.depth + 1.5 : 0);
    if (walls && groove) w = Math.max(w, E + walls.tb);
    if (walls && belt) w = Math.max(w, beltEnd + walls.tb);

    var inner = null;
    var section = null;
    if (walls) {
      var clipped = clipAbove(outer.slice(bodyIndex), w);
      inner = clipped.map(function (p) {
        return [p[0] - wallAt(p[1], walls, lg, bottleneck, bodyStart), p[1]];
      });
      var sec = pocket ? [[pocket.diameter / 2, 0]].concat(outer.slice(1)) : outer.slice(0);
      sec = sec.concat(inner.slice().reverse());
      sec.push([0, w]);
      if (pocket) sec.push([0, pocket.depth], [pocket.diameter / 2, pocket.depth]);
      section = sec;
    }

    if (lg.L6 === undefined) miss('L6');
    // Bullet.
    var bullet = null;
    if (G1 !== undefined && lg.L6 !== undefined && annot.defaultBulletShape) {
      if (walls) bullet = buildBullet(G1, co.H2, lg.L3, lg.L6, annot.defaultBulletShape, annot.category, walls.tb);
      if (!bullet && !bulletFactors(annot.defaultBulletShape, annot.category, G1)) miss('defaultBulletShape');
    }

    return {
      rim: rim,
      missing: missing,
      bottleneck: bottleneck,
      groove: groove,
      belt: belt,
      bodyStart: bodyStart,
      outer: outer,
      bodyIndex: bodyIndex,
      mouth: mouth,
      walls: walls,
      w: w,
      pocket: pocket,
      inner: inner,
      section: section,
      bullet: bullet
    };
  }

  var api = { buildGeometry: buildGeometry, filletPoints: filletPoints };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.Cartridges = Object.assign(global.Cartridges || {}, api);
})(typeof window !== 'undefined' ? window : globalThis);
