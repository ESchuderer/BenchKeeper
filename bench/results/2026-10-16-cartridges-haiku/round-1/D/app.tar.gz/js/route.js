// Hash routes: #/ for the list, #/cartridge/<key> for one cartridge.
(function (global) {
  'use strict';

  var PREFIX = '#/cartridge/';

  function parseHash(hash) {
    if (hash && hash.indexOf(PREFIX) === 0) {
      var key = hash.slice(PREFIX.length);
      try { key = decodeURIComponent(key); } catch (e) { return { view: 'detail', key: key }; }
      return { view: 'detail', key: key };
    }
    return { view: 'list' };
  }

  function hashFor(key) {
    return PREFIX + encodeURIComponent(key);
  }

  var api = { parseHash: parseHash, hashFor: hashFor };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.Cartridges = Object.assign(global.Cartridges || {}, api);
})(typeof window !== 'undefined' ? window : globalThis);
