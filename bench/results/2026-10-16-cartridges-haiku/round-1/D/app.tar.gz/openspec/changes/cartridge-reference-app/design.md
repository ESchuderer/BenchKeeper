# Design

## Context

- The repository has only project setup files. No application code exists yet.
- The app must run from `file://` in Chromium. Browsers block `fetch` and ES module imports for `file://` pages, so the data and scripts are loaded as classic `<script>` tags.
- Requirements are in `specs/*/spec.md`. This document records how they are met.

## Goals / Non-Goals

**Goals:**
- Static files only: `index.html`, `styles.css`, `data/cartridges.js`, and `js/*.js`.
- Pure functions for formatting, search, routing and geometry, so `node:test` can run them without a DOM.

**Non-Goals:**
- No build step, bundler, framework, or service worker.
- No data editing or fetching. The records are copied verbatim from the brief.
- No CAD-grade dimensioning standard (ISO/ASME). The layout follows the brief's rules only.

## Decisions

**File layout.** `data/cartridges.js` sets `var CARTRIDGE_RECORDS = [...]` with the 25 objects unchanged. `js/format.js`, `js/catalogue.js`, `js/route.js`, `js/geometry.js`, `js/drawing.js` and `js/app.js` each wrap their code in an IIFE and attach to one global namespace `window.Cartridges`. Each file also sets `module.exports` when `module` exists, so tests can `require` them. Alternative: ES modules. Rejected: blocked on `file://`.

**Routing.** Hash routes: `#/` for the list and `#/cartridge/<key>` for the detail. Alternative: `history.pushState`. Rejected: needs a server for deep links on reload.

**Units and symbols.** Unit table in `js/format.js` keyed by field name. Fields not in the table are mm, which covers `S`, `F`, `Z`, `G`, `G1`, `G2`, `b`, `h`, `s`, `u`, `Fe`, `deltaL`, `L4`, `L5`, `R3`, `r`. `grH2O` is shown as "gr H2O" (assumption: the brief does not name this unit). `N` has no unit.

**Count text.** "1 cartridge" for one result, "<n> cartridges" otherwise (assumption; the brief shows only the plural form).

**Geometry model.** `js/geometry.js` builds all outlines as arrays of `[r, z]` points, following the brief's `(r, z)` notation. It returns named polylines: `outer` (head face to mouth, from the axis), `inner` (section inner line), `bullet` (outline from the base to the tip), `pocket` and warnings for missing values. Arcs (fillets, ogive, quarter ellipse, half-round rim) are sampled at about 0.1 mm steps so the SVG uses plain polylines. Sampling keeps the drawing code free of arc arithmetic.

**Drawing projection.** `js/drawing.js` maps `(r, z)` to SVG `x = z`, `y = -r` for the outside view and `y = +r` for the section. The SVG viewBox is computed from the geometry bounding box plus the dimension rows and margins. Width and height attributes are omitted and CSS sets `width: 100%`.

**Dimensions.** Three placements:
- Axial dimensions (L1, L2, L3, L6, R) run in rows below the section, nearest row for the shortest dimension. Extension lines drop from the feature to the row. Ordering by length avoids crossing extension lines.
- Diameter dimensions (R1, E1, P1, P2, H1, H2, G1) are vertical dimension lines across the axis at a z offset from the feature. Their labels sit above the outline. Label y is the outline envelope maximum over the label's x span plus a gap. When labels collide, the label moves up one row and a thin leader connects it to its dimension line.
- α is an arc centred on the shoulder apex, with arrowheads, and its label uses the same leader rule.

**Label collision check.** Labels are placed in priority order with a text-width estimate (0.6 em per character). The check is done in `js/drawing.js` before rendering. Browser verification uses `getBBox()` on rendered labels for all 25 drawings.

**Section.** The cut polygon is built from the outer profile, the mouth face, the inner profile and the solid-head closure. The primer pocket is a notch at the head. The bullet cut is a second polygon and is hatched too. Both use one `<pattern>` hatch.

**Theme and print.** CSS custom properties with `@media (prefers-color-scheme: dark)`. `@media print` forces light colours, `@page { size: A4 portrait; margin: 12mm }`, and hides navigation, search, filter and buttons. The print footer text is a `<footer>` element that is shown only in print.

**Testing.** `node --test` with `test/*.test.js`. Covered by unit tests: format rules, rim type, search and family filter, routing parse, geometry formulas (ogive radius, belt ramp, wall thickness, primer pocket, heeled bullet). Browser checks use the Playwright MCP: list, search, detail, print preview, dark and light, overlap check.

**Dependencies.** None at runtime. `package.json` holds only the `test` script. No dev dependency is required because `node:test` ships with Node 22.

## Risks / Trade-offs

- [Label overlap is hard to guarantee for 25 drawings] → Browser `getBBox` check across all drawings in verification; the placer's row stacking is the fallback.
- [Diameter dimension lines cross the axis and cut section] → Accepted; dimension lines may cross geometry, labels may not. Visual check in verification.
- [Geometry rules are literal and some records are odd (for example 22 LR is heeled and 9 mm Luger is straight)] → Each rule has a unit test with a record from the dataset.
- [Sampled arcs make the SVG path long] → 25 drawings, a few hundred points each; no performance concern.

## Open Questions

None that change the specs. The assumptions above (gr H2O unit, singular count text, sampled arcs, α arc placement) are recorded here and can be changed without changing the specs.
