# Proposal

## Why

The project has no cartridge reference. The 25 C.I.P. cartridge records (OpenBallistics, MIT, commit e83db43) are supplied as JSON lines and need a browsable, printable, bookmarkable reference for reloaders, gunsmiths and engineers, with a dimensioned 2D drawing per cartridge.

## What Changes

- Add a static web app in `index.html` with its CSS and JavaScript files. No framework, no build step, no server code, no runtime dependencies, no network requests. It works when `index.html` is opened from `file://` and when the folder is served by a static file server.
- Embed the 25 records as a classic script (`file://` blocks `fetch` and ES modules). The records are used as given; no data is added, changed or fetched.
- Add a start page listing every cartridge (name, family, L3) with a name search (matches names and alternative names) and a family filter, and a count of listed cartridges.
- Add a detail view per cartridge at its own address (hash route), reloadable and bookmarkable, with header fields, the C.I.P. table, grouped value tables, the drawing, a Print button and a link back to the list.
- Add an inline SVG drawing per cartridge, computed from the record values by the geometry rules in the brief, true to scale (1 SVG unit = 1 mm), with dimension lines, extension lines, labels and a title block.
- Light and dark theme following the system setting; print is always light and A4 portrait.
- Add unit tests for the data, formatting, routing, search, and geometry modules with `node:test` (Node 22 built in).

## Capabilities

### New Capabilities

- `cartridge-data`: the embedded cartridge records and the display rules for their values (units, symbols, number and angle formats, tolerances, family and rim type).
- `cartridge-catalogue`: the start page list, name and alternative-name search, family filter, result count and links to detail views.
- `cartridge-detail`: the detail view at a per-cartridge address, header fields, C.I.P. table, grouped value tables, navigation, Print output and theme behaviour.
- `cartridge-drawing`: the inline SVG 2D drawing geometry, section walls, primer pocket, bullet, dimensions, labels, title block and missing-value handling.

### Modified Capabilities

None. The repository has no existing specs.

## Impact

- New files in the project root: `index.html`, `styles.css`, the data script, and the JavaScript modules for formatting, routing, catalogue, detail and drawing.
- New dev dependencies: none required. Tests use `node:test`; `package.json` is added with test scripts only.
- No changes to existing code (the repository contains only project setup files).
- Browser verification uses the Playwright MCP in this container (Chromium).
