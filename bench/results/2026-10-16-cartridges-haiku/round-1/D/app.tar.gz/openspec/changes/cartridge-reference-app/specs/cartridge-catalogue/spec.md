# Spec Delta

## Purpose

Defines the start page: the list of all cartridges, the name and alternative-name search, the family filter and the result count. It is the entry point to the cartridge detail views.

## ADDED Requirements

### Requirement: Cartridge list
The start page SHALL have the heading "Cartridges" and SHALL list every cartridge with its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name` and that opens the detail view of that cartridge.

#### Scenario: All cartridges listed
- **WHEN** the start page is opened with no search text and family All
- **THEN** all 25 cartridges are listed, each with its name, family and L3

#### Scenario: Name link text
- **WHEN** the list shows the cartridge with name "308 Win."
- **THEN** the link text is exactly "308 Win." and the link opens its detail view

### Requirement: Name search
The start page SHALL have a text field labelled "Search". It SHALL filter the list as the user types, matching case-insensitively against each cartridge's `name` and each entry of its `alternativeNames`.

#### Scenario: Alternative name match
- **WHEN** the user types "7,62 x 51" in Search
- **THEN** the list shows "308 Win." and no other cartridge

#### Scenario: Partial name match
- **WHEN** the user types "6,5"
- **THEN** the list shows "6,5 Creedmoor" and "6,5 x 55 SE"

#### Scenario: Case-insensitive match
- **WHEN** the user types "creedmoor"
- **THEN** the list shows "6,5 Creedmoor"

### Requirement: Family filter
The start page SHALL have a select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire. Selecting a family SHALL list only the cartridges of that family. All SHALL list every family.

#### Scenario: Family selected
- **WHEN** the user selects "belted"
- **THEN** the list shows only the belted cartridges, "300 Win. Mag." and "7 mm Rem. Mag."

#### Scenario: Search and family combined
- **WHEN** the family is "rimless" and the user types "Win"
- **THEN** the list shows only rimless cartridges whose name or alternative names contain "Win"

### Requirement: Result count
The start page SHALL show the text "<n> cartridges" with the number of listed cartridges, updated with every search or filter change. For a count of 1 it SHALL show "1 cartridge".

#### Scenario: Count updates
- **WHEN** the family is "pistol"
- **THEN** the count text shows "6 cartridges"

#### Scenario: No match
- **WHEN** the user types text that matches no cartridge
- **THEN** the count text shows "0 cartridges" and the list is empty
