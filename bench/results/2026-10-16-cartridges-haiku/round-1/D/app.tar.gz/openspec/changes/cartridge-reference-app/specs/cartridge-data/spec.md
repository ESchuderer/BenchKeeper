# Spec Delta

## Purpose

Defines the embedded C.I.P. cartridge dataset and the rules that turn its raw values into displayed symbols, units, numbers, angles and tolerances. Every other capability reads values through these rules.

## ADDED Requirements

### Requirement: Embedded dataset
The application SHALL embed exactly the 25 cartridge records supplied in the brief as a classic script. It SHALL NOT fetch, add, change or derive any record, and SHALL NOT make any network request.

#### Scenario: Records loaded from file
- **WHEN** `index.html` is opened from `file://` with no web server
- **THEN** the 25 records are available to the application and no network request is made

### Requirement: Symbols
The application SHALL show each field by its field name, except that these fields SHALL be shown as: `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G".

#### Scenario: Mapped symbol
- **WHEN** a record has the field `eMin`
- **THEN** its symbol is shown as "e min"

#### Scenario: Unmapped symbol
- **WHEN** a record has the field `L6`
- **THEN** its symbol is shown as "L6"

### Requirement: Units
The application SHALL show these units: lengths and diameters in mm; `Pmax`, `PK` and `PE` in bar; `EE` in J; `M` in g; `Q` in mm²; `N` as a count with no unit; `alpha`, `alpha1`, `beta`, `delta` and `i` as angles. `grH2O` SHALL be shown in gr H2O. Any other numeric field SHALL be shown in mm.

#### Scenario: Pressure unit
- **WHEN** the field `Pmax` has the value 4150
- **THEN** it is shown as "4150 bar"

#### Scenario: Count has no unit
- **WHEN** the field `N` has the value 6
- **THEN** it is shown as "6" with an empty unit

#### Scenario: Unlisted length
- **WHEN** the field `S` has the value 47.12
- **THEN** it is shown as "47.12 mm"

### Requirement: Number format
Numeric values SHALL be shown as published, with a decimal point, without a thousands separator and without a trailing ".0" (a published value 4150.0 is shown as 4150).

#### Scenario: Whole number published as decimal
- **WHEN** the published value of `Pmax` is 4150.0
- **THEN** the value is shown as "4150"

#### Scenario: Decimal kept
- **WHEN** the published value of `L3` is 51.18
- **THEN** the value is shown as "51.18"

### Requirement: Angle format
An angle published as a number SHALL be shown as that number followed by "°" (for example `40°`). An angle published as an object with `degrees`, `minutes` and `seconds` SHALL be shown as `D°M'S"` (for example `39°59'49"`).

#### Scenario: Angle as number
- **WHEN** the field `alpha` is 40
- **THEN** it is shown as "40°"

#### Scenario: Angle as object
- **WHEN** the field `alpha1` is `{degrees: 39, minutes: 59, seconds: 49}`
- **THEN** it is shown as `39°59'49"`

### Requirement: Tolerances
A field `<X>Tol` SHALL be shown next to the value of `X` in the same row, separated by a space (for example `39.62 -0.2`). A tolerance field SHALL NOT appear as a row of its own.

#### Scenario: Tolerance next to value
- **WHEN** `lengths.L1` is 39.62 and `lengths.L1Tol` is -0.2
- **THEN** the value of `L1` is shown as "39.62 -0.2" and no row exists for `L1Tol`

### Requirement: Names
Cartridge names, alternative names and family names SHALL be shown exactly as published (for example "6,5 Creedmoor").

#### Scenario: Name with comma
- **WHEN** the record key `6_5_creedmoor` has the name "6,5 Creedmoor"
- **THEN** the name is shown as "6,5 Creedmoor"

### Requirement: Rim type
The application SHALL derive a rim type for each record: `belted` when the family is belted, `rimfire` when the family is rimfire; otherwise `rimmed` when R1/P1 is at least 1.05, `rebated` when R1/P1 is below 0.98, and `rimless` in all other cases.

#### Scenario: Rimless by ratio
- **WHEN** a rimless-family record has R1 9.6 and P1 9.58
- **THEN** its rim type is rimless

#### Scenario: Rimmed by ratio
- **WHEN** a record of family rimmed has R1 13.35 and P1 11.9
- **THEN** its rim type is rimmed
