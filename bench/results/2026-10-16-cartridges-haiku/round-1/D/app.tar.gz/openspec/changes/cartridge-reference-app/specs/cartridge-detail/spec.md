# Spec Delta

## Purpose

Defines the detail view of one cartridge: its address, header fields, C.I.P. table, grouped value tables, navigation, the printed page and the theme behaviour. The drawing is specified in `cartridge-drawing`.

## ADDED Requirements

### Requirement: Address per cartridge
Each cartridge SHALL have its own detail address in the form `#/cartridge/<key>`, where `<key>` is the record's `key`. Reloading or bookmarking that address SHALL show the same detail view. An unknown key SHALL show a message that the cartridge was not found, with a link "All cartridges".

#### Scenario: Reload keeps the view
- **WHEN** the user opens `#/cartridge/308_win` and reloads the page
- **THEN** the detail view of "308 Win." is shown again

#### Scenario: Unknown key
- **WHEN** the user opens `#/cartridge/unknown`
- **THEN** a not-found message is shown with the link "All cartridges"

### Requirement: Header fields
The detail view SHALL have the heading with the cartridge's name, and SHALL show, when published: alternative names, family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method, and the published water capacity with its source. The water capacity SHALL show the value, the source name and a link to the source `url`; a published `note` SHALL be shown with it.

#### Scenario: Header of 308 Win.
- **WHEN** the detail view of "308 Win." is shown
- **THEN** it shows the heading "308 Win.", the alternative names "308 Winchester" and "7,62 x 51", family "rimless", C.I.P. table "I", country "US", published "1984-06-14", revised "2008-09-23" and pressure method "Transducer"

#### Scenario: Water capacity with source link
- **WHEN** the record has `publishedCapacity` with grH2O 56.0, source "kwk" and url "http://kwk.us/cases.html"
- **THEN** the view shows "56 gr H2O", the source "kwk" and a link to "http://kwk.us/cases.html"

### Requirement: Value tables
The detail view SHALL show every value of the record's `cartridge` and `chamber` sections in tables grouped by section, with the columns "Symbol", "Value" and "Unit". Each subsection (for example Case head, Collar, Junction cone, Lengths) SHALL be its own group. Only published values SHALL be shown as rows.

#### Scenario: Grouped tables
- **WHEN** the detail view of any cartridge is shown
- **THEN** every published value of the `cartridge` and `chamber` sections appears once, in a table of its group with the columns "Symbol", "Value" and "Unit"

### Requirement: Navigation
The detail view SHALL have a link "All cartridges" to the start page.

#### Scenario: Back to list
- **WHEN** the user activates "All cartridges"
- **THEN** the start page is shown

### Requirement: Print
The detail view SHALL have a "Print" button that opens the browser print dialog. The printed output SHALL be one A4 portrait page, black on white, with: a page header with the name, the drawing at full width with every label legible, the tables, and a footer with the source "C.I.P. TDCC" and the revised date. Navigation, search, the family filter and buttons SHALL NOT be printed.

#### Scenario: Print output
- **WHEN** the user activates "Print" on the detail view of "223 Rem."
- **THEN** the print dialog opens and the printed page is one A4 portrait page with the name "223 Rem.", the drawing, the tables and the footer "C.I.P. TDCC, revised 2017-05-17"

### Requirement: Theme
The application SHALL follow the system colour scheme: light when the system is light, dark when the system is dark. Printed output SHALL always be light.

#### Scenario: Dark system setting
- **WHEN** the system colour scheme is dark
- **THEN** the screen is shown with a dark background and light text

### Requirement: Phone layout
The detail view SHALL be usable on a phone-width screen: the drawing scales to the screen width and the tables remain readable without horizontal page scrolling of the document.

#### Scenario: Narrow screen
- **WHEN** the viewport is 375 px wide
- **THEN** the drawing fits the viewport width and no page-level horizontal scrollbar is shown
