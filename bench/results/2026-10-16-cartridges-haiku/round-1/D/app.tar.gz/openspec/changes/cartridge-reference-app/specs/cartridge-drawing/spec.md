# Spec Delta

## Purpose

Defines the inline SVG 2D drawing of each cartridge: its geometry, section, bullet, dimensions, labels, title block and scaling. The drawing is computed from the record values only.

## ADDED Requirements

### Requirement: Drawing frame and scale
The drawing SHALL be an inline SVG with the accessible name "<name> drawing". It SHALL be true to scale: 1 SVG user unit equals 1 mm. The axis SHALL be horizontal with the head face on the left (z = 0) and the mouth on the right.

#### Scenario: Accessible name
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** the SVG has the accessible name "223 Rem. drawing"

#### Scenario: True scale
- **WHEN** the drawing of a cartridge with L6 57.4 is rendered
- **THEN** the distance between the head face and the tip measures 57.4 user units

### Requirement: Outside view and section
The upper half of the drawing SHALL be the outside view. The lower half SHALL be a section of the case walls, head and bullet, with the cut walls hatched. A dash-dot centre line SHALL run along the axis.

#### Scenario: Halves
- **WHEN** any cartridge is drawn
- **THEN** the outline above the axis is the outside view, the cut areas below the axis are hatched, and a dash-dot line lies on the axis

### Requirement: Rim type geometry
The head SHALL follow the rim type derived in `cartridge-data`. A rimfire rim edge SHALL be a half-round of radius min(R/2, (R1 - P1)/2) whose outermost point lies at R1/2. A belted case SHALL have its belt at R3/2. A rimmed, rimless or rebated case SHALL have a square rim corner, or a chamfer when β and f are published and β is below 90°.

#### Scenario: Chamfered head
- **WHEN** a rimless case has beta 35 and f 0.45 with R1 9.6
- **THEN** the head face runs from the axis to r = R1/2 - min(f·tan β, R1/4) at z = 0, then chamfers to (R1/2, f), then rises to (R1/2, R)

#### Scenario: Rimfire half-round
- **WHEN** a rimfire case has R 1.09, R1 7.06 and P1 5.74
- **THEN** the rim edge is a half-round of radius 0.545 with its outermost point at r = 3.53

### Requirement: Extractor groove and belt
Where E and E1 are published, the outline SHALL run from (R1/2, R) inward to (E1/2, R), along the groove floor to (E1/2, R + eMin), then outward to (P1/2, E). A belted case SHALL instead ramp outward at angle δ from the floor end up to radius R3/2, follow the belt to z = E, then step in to P1/2. Without a groove, the outline SHALL step inward from (R1/2, R) to (P1/2, R).

#### Scenario: Groove without belt
- **WHEN** a rimless case has E 3.13, E1 8.43, R 1.14 and eMin 0.76
- **THEN** the groove floor is at z from 1.14 to 1.90 at r = 4.215, then a straight ramp runs to (4.79, 3.13)

#### Scenario: Belted groove
- **WHEN** a belted case has R3 13.51, E1 12.07 and δ 35
- **THEN** the ramp rises from r = 6.035 to r = 6.755 at angle δ to the axis, the belt runs at r = 6.755 to z = E, then steps in to P1/2

### Requirement: Body, shoulder and neck
The body SHALL run straight from (P1/2, body start) to (P2/2, L1) on a bottleneck case, then the shoulder runs straight to (H1/2, L2), then the neck runs straight to (H2/2, L3), where the mouth face is. The shoulder SHALL be drawn through the published points, and its included angle α SHALL be labelled. A case without α, L1 or L2 SHALL be straight: the body runs from P1/2 to (H2/2, L3).

#### Scenario: Bottleneck
- **WHEN** a case has P2 9.0, L1 36.52, H1 6.43, L2 39.55 and L3 44.7
- **THEN** the outline passes (4.5, 36.52), (3.215, 39.55) and (3.215, 44.7) in (r, z) order

#### Scenario: Straight case
- **WHEN** a case has no alpha, L1 or L2, such as "9 mm Luger"
- **THEN** the body runs straight from P1/2 to (H2/2, L3) and no shoulder is drawn

### Requirement: Fillets
The corner at the body end of the shoulder SHALL be rounded with radius r1Min, and the corner at the neck end with radius r2, where these are published. Each fillet SHALL be tangent to both adjoining lines.

#### Scenario: Fillet radii
- **WHEN** a bottleneck case publishes r1Min 0.64 and r2 2.54
- **THEN** the body-end corner is rounded with radius 0.64 and the neck-end corner with radius 2.54

### Requirement: Bullet geometry
The bullet SHALL sit with its base at zb = L3 - s, where s is 1.0·G1 for pointy bullets; 0.8·G1 for rounded or flat bullets of rifle and rimfire cartridges; 0.4·G1 for rounded or flat bullets of pistol cartridges; 0.6·G1 for semi_wadcutter bullets. Its tip SHALL be at z = L6. The shank diameter SHALL be G1 unless the heeled rule applies.

#### Scenario: Pointy seating
- **WHEN** a pointy rifle bullet has G1 5.7 and L3 44.7
- **THEN** the base is at zb = 39.0

### Requirement: Bullet nose
The cylinder SHALL run from the base to zb + k·Lb, where Lb = L6 - zb and k is 0.40 pointy, 0.55 rounded rifle or rimfire, 0.65 rounded pistol, 0.60 flat rifle, 0.70 flat pistol, 0.78 semi_wadcutter. The nose SHALL end in a flat tip of diameter m: pointy uses a tangent ogive with m = max(0.08·G1, 1.27); rounded uses a quarter ellipse with m = 0.15·G1; flat uses a straight cone with m = 0.55·G1; semi_wadcutter uses a straight cone with m = 0.6·G1.

#### Scenario: Pointy ogive radius
- **WHEN** a pointy bullet has G1 5.7 and nose length n 11.04
- **THEN** the ogive radius is ((2.85 - 0.635)² + 11.04²) / (2 · 2.215) and its centre lies on the nose start at r = G1/2 - ρ

### Requirement: Heeled bullet
A heeled case (H2 - G1 at most 0.015) SHALL draw the exposed bullet with the case's outside diameter H2. The seated heel SHALL have diameter H2 - 2·tb and is drawn inside the case in the section.

#### Scenario: 22 Long Rifle
- **WHEN** the case is "22 Long Rifle" with H2 5.72 and G1 5.72
- **THEN** the exposed bullet has diameter 5.72 and the seated heel has diameter 5.72 - 2·tb

### Requirement: Section walls
The neck wall SHALL be tn = (H2 - G1)/2. The body wall SHALL be tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner profile SHALL follow the outer profile at tb along the body, at tn along the neck, and blend linearly between them across the shoulder. The cut walls SHALL be hatched.

#### Scenario: Wall thickness
- **WHEN** H2 is 6.43, G1 is 5.7 and P1 is 9.58
- **THEN** tn is 0.365, tb is 0.6 and the neck inner radius is 2.85

### Requirement: Solid head and primer pocket
The solid head SHALL run from the head face to z = w, where w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or belt ramp end + tb on belted cases). On centrefire cases the primer pocket SHALL have diameter 4.45 for sp, spm and sr, and 5.33 for lp, lpm, lr and lrm; depth 3.04 for sp, spm, sr, lp and lpm, and 3.3 for lr and lrm. Rimfire cases SHALL have no pocket.

#### Scenario: Small rifle primer
- **WHEN** the primer type is sr
- **THEN** the pocket is 4.45 in diameter and 3.04 deep

#### Scenario: Large rifle magnum primer
- **WHEN** the primer type is lrm
- **THEN** the pocket is 5.33 in diameter and 3.3 deep

### Requirement: Dimension lines
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and for P2, H1, H2, G1, L1, L2, E1 and α where published. Each label SHALL show its symbol and its value with the tolerance next to the value where one is published (for example "L3 51.18" and "L1 39.62 -0.2"). α SHALL be labelled with its value in degrees (for example "α 46°").

#### Scenario: Labels with tolerance
- **WHEN** a cartridge publishes L1 39.62 with L1Tol -0.2
- **THEN** the L1 dimension label reads "L1 39.62 -0.2"

#### Scenario: Missing optional dimension
- **WHEN** a cartridge does not publish E1
- **THEN** no E1 dimension is drawn

### Requirement: Label placement
No label SHALL overlap another label, and no label SHALL overlap the outline of the drawing.

#### Scenario: No overlap with outline
- **WHEN** any of the 25 drawings is rendered
- **THEN** the bounding box of every label is free of the outline and of every other label

### Requirement: Title block
The drawing SHALL have a title block with the cartridge name, the C.I.P. table, the revision date, the text "Dimensions in mm" and a scale bar in mm.

#### Scenario: Title block content
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the title block shows "308 Win.", "C.I.P. table I", "2008-09-23", "Dimensions in mm" and a scale bar

### Requirement: Missing values
If a value needed by a geometry rule is not published, the drawing SHALL omit that feature and SHALL state the missing value in a note under the title block. No value SHALL be invented.

#### Scenario: Missing bottleneck value
- **WHEN** a case publishes alpha but not L2
- **THEN** no shoulder is drawn and the note names "L2" as missing

### Requirement: Scaling and print
The drawing SHALL scale to the full width of the content area on a phone and remain legible when printed at full width on A4 portrait, with all labels legible.

#### Scenario: Phone width
- **WHEN** the detail view is shown at 375 px width
- **THEN** the drawing is 375 px wide or less without clipping any label
