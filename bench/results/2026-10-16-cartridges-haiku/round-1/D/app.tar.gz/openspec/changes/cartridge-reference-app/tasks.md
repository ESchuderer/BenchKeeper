# Tasks

## 1. Project setup and dataset

- [x] 1.1 Add `package.json` with name, `private: true`, and `"test": "node --test test/"`; verify `npm test` runs and reports 0 tests with exit code 0
- [x] 1.2 Create `data/cartridges.js` with `var CARTRIDGE_RECORDS = [...]` holding the 25 records from the brief verbatim; add a test that loads the file in a `vm` context and checks 25 records, unique `key` values, and that `name` of `308_win` is "308 Win."

## 2. Data display rules (`js/format.js`)

- [x] 2.1 Write failing tests for units per field (`Pmax` bar, `EE` J, `M` g, `Q` mm², `N` no unit, angles, unlisted fields mm, `grH2O` gr H2O), then implement the unit table; verify the tests pass
- [x] 2.2 Write failing tests for number format (4150.0 → "4150", 51.18 → "51.18", no thousands separator) and angle format (40 → "40°", `{39,59,49}` → `39°59'49"`), then implement; verify the tests pass
- [x] 2.3 Write failing tests for tolerance (`L1` 39.62 with `L1Tol` -0.2 → "39.62 -0.2"; no row for `L1Tol`) and symbol mapping (all mapped symbols from the spec), then implement; verify the tests pass
- [x] 2.4 Write failing tests for rim type (belted, rimfire, rimmed by ratio, rebated, rimless) against the 25 records, then implement; verify the tests pass

## 3. Catalogue, search and routing (`js/catalogue.js`, `js/route.js`)

- [x] 3.1 Write failing tests for the search (case-insensitive match on `name` and `alternativeNames`; "7,62 x 51" returns only 308 Win.; "6,5" returns two records), then implement; verify the tests pass
- [x] 3.2 Write failing tests for the family filter combined with search and for the count text ("1 cartridge", "6 cartridges", "0 cartridges"), then implement; verify the tests pass
- [x] 3.3 Write failing tests for route parsing (`#/` → list, `#/cartridge/308_win` → detail with key, `#/cartridge/unknown` → not found), then implement; verify the tests pass

## 4. Geometry (`js/geometry.js`)

- [x] 4.1 Write failing tests for the head face and rim edge (chamfer point formula, square corner, rimfire half-round with outermost point at R1/2), then implement; verify the tests pass
- [x] 4.2 Write failing tests for the extractor groove (groove floor, ramp to (P1/2, E)), the belted ramp (angle δ, belt R3/2 to z = E), and the no-groove step, then implement; verify the tests pass
- [x] 4.3 Write failing tests for body, shoulder and neck points on 223 Rem. (P2/2 at L1, H1/2 at L2, H2/2 at L3), straight cases (9 mm Luger), and fillets tangent to both lines, then implement; verify the tests pass
- [x] 4.4 Write failing tests for the bullet base (zb = L3 - s per shape and category), cylinder end (k factors), nose (pointy ogive radius formula, rounded quarter ellipse, flat and semi_wadcutter cones), and heeled bullet (22 Long Rifle), then implement; verify the tests pass
- [x] 4.5 Write failing tests for section walls (tn, tb, inner profile blend), solid head w, primer pocket diameter and depth per primer type, and rimfire without pocket, then implement; verify the tests pass
- [x] 4.6 Write failing tests for missing values (no alpha → straight; no E1 → no groove; the returned `missing` list names the value), then implement; verify the tests pass

## 5. Drawing (`js/drawing.js`)

- [x] 5.1 Write failing tests that the SVG markup for one record has the accessible name "<name> drawing", a dash-dot centre line, a hatched section pattern, and a title block with name, "C.I.P. table", revision date, "Dimensions in mm" and a scale bar, then implement the SVG frame, outlines and hatching; verify the tests pass
- [x] 5.2 Implement dimension lines with arrowheads and extension lines for L3, L6, R1, R, P1 and the optional P2, H1, H2, G1, L1, L2, E1, α; verify in the Playwright MCP on 223 Rem. and 9 mm Luger that every listed dimension is present and labelled with symbol and value
- [x] 5.3 Implement the label placer (axial rows below the section, diameter labels above the outline with leaders on collision, α label); verify with a Playwright `getBBox` check on the 223 Rem. and 22 Long Rifle drawings that no two labels overlap and no label overlaps the outline

## 6. App shell, list and detail view (`index.html`, `styles.css`, `js/app.js`)

- [x] 6.1 Build `index.html` with the list page: heading "Cartridges", Search field, Family select, count text, and the list of name links with family and L3; verify in the Playwright MCP that 25 links are listed and the search and family filter behave as the cartridge-catalogue spec
- [x] 6.2 Build the detail view: heading, header fields, water capacity with source link, grouped Symbol/Value/Unit tables with tolerances, drawing container, "All cartridges" link, not-found message; verify in the Playwright MCP that the detail of 308 Win. is reachable by its address and survives a reload
- [x] 6.3 Add the stylesheet with light and dark themes from `prefers-color-scheme`, tabular numbers, and phone layout; verify in the Playwright MCP at 375 px width that there is no page-level horizontal scrollbar and that the dark theme renders with the dark colour scheme emulated
- [x] 6.4 Add the print stylesheet and the Print button (`window.print()`): one A4 portrait page, black on white, header with name, drawing at full width, tables, footer "C.I.P. TDCC, revised <date>", no navigation or buttons; verify with the Playwright MCP print media emulation that the layout fits one page

## 7. Integration checks

- [x] 7.1 Open `index.html` through `file://` in the Playwright MCP, record network requests, and verify there are none to other origins and no console errors
- [x] 7.2 Render all 25 drawings and verify the label overlap check passes for each, and that the drawing of each record fits the phone width; record any failing record and fix it before the change is reported done
- [x] 7.3 Run `npm test` and verify all tests pass; verify no em dash (U+2014), emoji or emoticon appears in the changed files with a grep

## Workflow follow-up

- Run the project's review (`requesting-code-review`) on the branch before reporting done (no remote, so no pull request).
- Archive the change with `openspec-archive-change` on the branch after the review.
