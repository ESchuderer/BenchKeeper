'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const cat = require('../js/catalogue.js');
const route = require('../js/route.js');
const { loadRecords } = require('./helpers.js');

const records = loadRecords();
const names = (list) => list.map((r) => r.name).sort();

test('search matches name and alternative names case-insensitively', () => {
  assert.deepEqual(names(cat.filterCartridges(records, { query: '7,62 x 51', family: 'All' })), ['308 Win.']);
  assert.deepEqual(names(cat.filterCartridges(records, { query: '6,5', family: 'All' })), ['6,5 Creedmoor', '6,5 x 55 SE']);
  assert.deepEqual(names(cat.filterCartridges(records, { query: 'creedmoor', family: 'All' })), ['6,5 Creedmoor']);
  assert.deepEqual(names(cat.filterCartridges(records, { query: '22 WMR', family: 'All' })), ['22 Win. Mag. R.F.']);
});

test('empty search returns all records', () => {
  assert.equal(cat.filterCartridges(records, { query: '', family: 'All' }).length, 25);
  assert.equal(cat.filterCartridges(records, { query: '   ', family: 'All' }).length, 25);
});

test('family filter lists only that family', () => {
  assert.deepEqual(names(cat.filterCartridges(records, { query: '', family: 'belted' })), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(cat.filterCartridges(records, { query: '', family: 'pistol' }).length, 6);
  assert.equal(cat.filterCartridges(records, { query: '', family: 'rimfire' }).length, 3);
  assert.equal(cat.filterCartridges(records, { query: '', family: 'rimmed' }).length, 2);
  assert.equal(cat.filterCartridges(records, { query: '', family: 'rimless' }).length, 12);
});

test('search and family combine', () => {
  assert.deepEqual(names(cat.filterCartridges(records, { query: 'Win', family: 'rimless' })), ['243 Win.', '270 Win.', '308 Win.']);
});

test('count text', () => {
  assert.equal(cat.countText(1), '1 cartridge');
  assert.equal(cat.countText(6), '6 cartridges');
  assert.equal(cat.countText(0), '0 cartridges');
});

test('route: list and detail addresses', () => {
  assert.deepEqual(route.parseHash(''), { view: 'list' });
  assert.deepEqual(route.parseHash('#/'), { view: 'list' });
  assert.deepEqual(route.parseHash('#/cartridge/308_win'), { view: 'detail', key: '308_win' });
  assert.deepEqual(route.parseHash('#/cartridge/unknown'), { view: 'detail', key: 'unknown' });
  assert.equal(route.hashFor('308_win'), '#/cartridge/308_win');
});

test('route: malformed percent-encoding falls back to the raw key', () => {
  assert.deepEqual(route.parseHash('#/cartridge/%'), { view: 'detail', key: '%' });
});
