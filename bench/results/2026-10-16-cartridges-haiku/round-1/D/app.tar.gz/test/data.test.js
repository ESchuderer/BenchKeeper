'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadRecords() {
  const src = fs.readFileSync(path.join(__dirname, '..', 'data', 'cartridges.js'), 'utf8');
  const ctx = {};
  vm.createContext(ctx);
  vm.runInContext(src, ctx);
  return ctx.CARTRIDGE_RECORDS;
}

test('dataset has 25 records with unique keys', () => {
  const records = loadRecords();
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
});

test('308_win record is the published 308 Win.', () => {
  const rec = loadRecords().find((r) => r.key === '308_win');
  assert.equal(rec.name, '308 Win.');
  assert.equal(rec.cartridge.lengths.L3, 51.18);
  assert.deepEqual([...rec.alternativeNames], ['308 Winchester', '7,62 x 51']);
});
