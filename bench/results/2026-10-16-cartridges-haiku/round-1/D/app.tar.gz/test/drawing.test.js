'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const drawing = require('../js/drawing.js');
const { loadRecords } = require('./helpers.js');

const records = loadRecords();
const rec = (key) => structuredClone(records.find((r) => r.key === key));
const labelTexts = (key, mutate) => {
  const r = rec(key);
  if (mutate) mutate(r);
  return drawing.layoutDrawing(r).labels.map((l) => l.text);
};

test('svg frame: accessible name, centre line, hatch pattern, title block', () => {
  const svg = drawing.drawingSvg(rec('223_rem'));
  assert.match(svg, /<svg[^>]*role="img"/);
  assert.match(svg, /aria-label="223 Rem\. drawing"/);
  assert.match(svg, /class="centre"[^>]*stroke-dasharray/);
  assert.match(svg, /<pattern id="hatch-223_rem"/);
  for (const text of ['223 Rem.', 'C.I.P. table I', 'Revised 2017-05-17', 'Dimensions in mm']) {
    assert.ok(svg.includes(text), `title block has ${text}`);
  }
});

test('labels carry symbol, value and tolerance', () => {
  const t = labelTexts('223_rem');
  for (const text of ['L1 36.52 -0.2', 'L2 39.55 -0.2', 'L3 44.7', 'L6 57.4', 'R1 9.6', 'R 1.14', 'P1 9.58', 'P2 9 -0.2', 'H1 6.43', 'H2 6.43', 'G1 5.7', 'E1 8.43', 'α 46°']) {
    assert.ok(t.includes(text), `label ${text}`);
  }
});

test('optional dimensions: no E1 without a groove, no shoulder labels for straight cases', () => {
  const luger = labelTexts('9_mm_luger');
  assert.ok(luger.includes('H2 9.65'));
  assert.ok(luger.includes('P1 9.93'));
  assert.ok(!luger.some((t) => /^(L1|L2|P2|H1|α)/.test(t)));
  const lr = labelTexts('22_long_rifle');
  assert.ok(!lr.some((t) => t.startsWith('E1')));
  assert.ok(lr.includes('R 1.09 -0.18'));
});

test('missing value: the note names it and the shoulder is not drawn', () => {
  const r = rec('223_rem');
  delete r.cartridge.lengths.L2;
  const layout = drawing.layoutDrawing(r);
  assert.ok(layout.missing.includes('L2'));
  assert.ok(!layout.labels.some((l) => l.text.startsWith('L2')));
  assert.ok(drawing.renderSvg(layout).includes('Not drawn: L2'));
});

test('labels do not overlap each other or the outline, for all 25 drawings', () => {
  for (const r of records) {
    const layout = drawing.layoutDrawing(r);
    const { labels, outlinePoints } = layout;
    for (let i = 0; i < labels.length; i++) {
      for (let j = i + 1; j < labels.length; j++) {
        assert.ok(!drawing.boxesOverlap(labels[i].box, labels[j].box, 0), `${r.key}: "${labels[i].text}" overlaps "${labels[j].text}"`);
      }
      for (const p of outlinePoints) {
        assert.ok(!drawing.pointInBox(p, labels[i].box, 0.2), `${r.key}: "${labels[i].text}" touches the outline at ${p}`);
      }
    }
  }
});
