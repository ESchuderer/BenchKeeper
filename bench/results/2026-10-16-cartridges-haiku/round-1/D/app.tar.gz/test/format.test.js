'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fmt = require('../js/format.js');
const { loadRecords } = require('./helpers.js');

const records = loadRecords();
const byKey = (k) => records.find((r) => r.key === k);

test('units per field', () => {
  assert.equal(fmt.unitOf('Pmax'), 'bar');
  assert.equal(fmt.unitOf('PK'), 'bar');
  assert.equal(fmt.unitOf('PE'), 'bar');
  assert.equal(fmt.unitOf('EE'), 'J');
  assert.equal(fmt.unitOf('M'), 'g');
  assert.equal(fmt.unitOf('Q'), 'mm²');
  assert.equal(fmt.unitOf('N'), '');
  assert.equal(fmt.unitOf('alpha'), '');
  assert.equal(fmt.unitOf('alpha1'), '');
  assert.equal(fmt.unitOf('beta'), '');
  assert.equal(fmt.unitOf('delta'), '');
  assert.equal(fmt.unitOf('i'), '');
  assert.equal(fmt.unitOf('L3'), 'mm');
  assert.equal(fmt.unitOf('S'), 'mm');
  assert.equal(fmt.unitOf('u'), 'mm');
  assert.equal(fmt.unitOf('grH2O'), 'gr H2O');
});

test('number format: as published, no thousands separator, no trailing .0', () => {
  assert.equal(fmt.formatNumber(4150.0), '4150');
  assert.equal(fmt.formatNumber(51.18), '51.18');
  assert.equal(fmt.formatNumber(6.0), '6');
  assert.equal(fmt.formatNumber(-0.2), '-0.2');
});

test('angle format: number and degrees-minutes-seconds object', () => {
  assert.equal(fmt.formatAngle(40), '40°');
  assert.equal(fmt.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(fmt.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), `3°10'36"`);
});

test('angle in degrees for geometry', () => {
  assert.equal(fmt.angleDegrees(35), 35);
  assert.equal(fmt.angleDegrees({ degrees: 36, minutes: 52, seconds: 12 }), 36 + 52 / 60 + 12 / 3600);
});

test('tolerance is shown next to its value', () => {
  assert.equal(fmt.formatWithTolerance(39.62, -0.2), '39.62 -0.2');
  assert.equal(fmt.formatWithTolerance(51.18, undefined), '51.18');
});

test('symbols: mapped fields and unmapped fields', () => {
  assert.equal(fmt.symbolOf('eMin'), 'e min');
  assert.equal(fmt.symbolOf('r1Min'), 'r1 min');
  assert.equal(fmt.symbolOf('r1Max'), 'r1 max');
  assert.equal(fmt.symbolOf('alpha'), 'α');
  assert.equal(fmt.symbolOf('alpha1'), 'α1');
  assert.equal(fmt.symbolOf('beta'), 'β');
  assert.equal(fmt.symbolOf('delta'), 'δ');
  assert.equal(fmt.symbolOf('deltaL'), 'delta L');
  assert.equal(fmt.symbolOf('L3PlusG'), 'L3 + G');
  assert.equal(fmt.symbolOf('L6'), 'L6');
});

test('rim type from family and R1/P1 ratio', () => {
  assert.equal(fmt.rimType(byKey('223_rem')), 'rimless');
  assert.equal(fmt.rimType(byKey('9_3_x_74_r')), 'rimmed');
  assert.equal(fmt.rimType(byKey('300_win_mag')), 'belted');
  assert.equal(fmt.rimType(byKey('17_hmr')), 'rimfire');
  assert.equal(fmt.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 10 }, powderChamber: { P1: 9.4 } } }), 'rimmed');
  assert.equal(fmt.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 10 }, powderChamber: { P1: 10.4 } } }), 'rebated');
});

test('value groups: tolerance folded into its value, no row for Tol fields', () => {
  const groups = fmt.valueGroups(byKey('223_rem'), 'cartridge');
  const lengths = groups.find((g) => g.title === 'Lengths');
  const l1 = lengths.rows.find((r) => r.symbol === 'L1');
  assert.deepEqual(l1, { symbol: 'L1', value: '36.52 -0.2', unit: 'mm' });
  assert.ok(!lengths.rows.some((r) => r.symbol.endsWith('Tol')));
  const head = groups.find((g) => g.title === 'Case head');
  assert.ok(head.rows.some((r) => r.symbol === 'β' && r.value === '35°' && r.unit === ''));
});

test('value groups omit empty sections and keep count and angle units', () => {
  const groups = fmt.valueGroups(byKey('9_mm_luger'), 'cartridge');
  assert.ok(!groups.some((g) => g.title === 'Junction cone'));
  const chamberGroups = fmt.valueGroups(byKey('17_hmr'), 'chamber');
  const grooves = chamberGroups.find((g) => g.title === 'Grooves');
  assert.deepEqual(grooves.rows.find((r) => r.symbol === 'N'), { symbol: 'N', value: '6', unit: '' });
  const rifling = chamberGroups.find((g) => g.title === 'Rifling');
  assert.equal(rifling.rows.find((r) => r.symbol === 'i').value, '1°30\'0"');
});

test('water capacity display', () => {
  assert.equal(fmt.formatCapacity(byKey('308_win').annotations.publishedCapacity), '56 gr H2O');
});
