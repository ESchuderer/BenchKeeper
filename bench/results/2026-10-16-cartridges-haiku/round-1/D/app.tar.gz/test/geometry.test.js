'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const geo = require('../js/geometry.js');
const { loadRecords } = require('./helpers.js');

const records = loadRecords();
const rec = (key) => structuredClone(records.find((r) => r.key === key));
const close = (a, b, tol = 1e-6) => assert.ok(Math.abs(a - b) <= tol, `expected ${a} ≈ ${b}`);
const hasPoint = (pts, r, z, tol = 1e-6) =>
  pts.some((p) => Math.abs(p[0] - r) <= tol && Math.abs(p[1] - z) <= tol);

test('fillet is tangent to both lines and sits on the requested radius', () => {
  // Right-angle corner at the origin, rho 2: tangent points (0,2) and (2,0), centre (2,2).
  const pts = geo.filletPoints([0, 10], [0, 0], [10, 0], 2, 16);
  close(pts[0][0], 0); close(pts[0][1], 2);
  close(pts[pts.length - 1][0], 2); close(pts[pts.length - 1][1], 0);
  const mid = pts[8];
  close(Math.hypot(mid[0] - 2, mid[1] - 2), 2);
  close(mid[0], 2 - 2 / Math.SQRT2, 1e-6);
});

test('head: chamfer point and rim corner for a rimless case with beta and f', () => {
  const g = geo.buildGeometry(rec('223_rem'));
  // R1/2 - min(f·tan β, R1/4) with f 0.45, β 35°
  const c = 0.45 * Math.tan((35 * Math.PI) / 180);
  assert.ok(hasPoint(g.outer, 4.8 - c, 0));
  assert.ok(hasPoint(g.outer, 4.8, 0.45));
  assert.ok(hasPoint(g.outer, 4.8, 1.14));
});

test('head: square corner without chamfer', () => {
  const r = rec('223_rem');
  delete r.cartridge.caseHead.beta;
  const g = geo.buildGeometry(r);
  assert.ok(hasPoint(g.outer, 4.8, 0));
  assert.ok(hasPoint(g.outer, 4.8, 1.14));
});

test('head: rimfire half-round with outermost point at R1/2', () => {
  const g = geo.buildGeometry(rec('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const cx = 7.06 / 2 - rho;
  assert.ok(hasPoint(g.outer, cx, 0));
  assert.ok(hasPoint(g.outer, cx + rho, rho, 1e-6));
  assert.ok(Math.max(...g.outer.map((p) => p[0])) <= 7.06 / 2 + 1e-9);
});

test('groove: floor, ramp to (P1/2, E)', () => {
  const g = geo.buildGeometry(rec('223_rem'));
  assert.ok(hasPoint(g.outer, 4.215, 1.14));
  assert.ok(hasPoint(g.outer, 4.215, 1.14 + 0.76));
  assert.ok(hasPoint(g.outer, 9.58 / 2, 3.13));
});

test('belted groove: ramp at angle delta up to R3/2, belt to E, step to P1/2', () => {
  const g = geo.buildGeometry(rec('300_win_mag'));
  const dz = (6.755 - 6.035) / Math.tan((35 * Math.PI) / 180);
  assert.ok(hasPoint(g.outer, 6.755, 1.27 + 0.94 + dz, 1e-6));
  assert.ok(hasPoint(g.outer, 6.755, 5.59));
  assert.ok(hasPoint(g.outer, 13.03 / 2, 5.59));
});

test('no groove: step in from R1/2 at R to P1/2 at R', () => {
  const g = geo.buildGeometry(rec('9_3_x_74_r'));
  assert.ok(hasPoint(g.outer, 13.35 / 2, 1.4));
  assert.ok(hasPoint(g.outer, 11.9 / 2, 1.4));
  assert.equal(g.groove, false);
});

test('bottleneck: body, shoulder and neck end at the published points', () => {
  const g = geo.buildGeometry(rec('223_rem'));
  assert.equal(g.bottleneck, true);
  const last = g.outer[g.outer.length - 1];
  close(last[0], 6.43 / 2); close(last[1], 44.7);
  // the shoulder line runs from (P2/2, L1) to (H1/2, L2): points between the fillets lie on it
  const slope = (4.5 - 3.215) / (39.55 - 36.52);
  // The straight part between the two fillets has no samples; its tangent points lie on the line.
  const onLine = g.outer.filter((p) => p[1] > 36.52 && p[1] < 39.55 && Math.abs(p[0] - (4.5 - (p[1] - 36.52) * slope)) < 0.01);
  assert.ok(onLine.length >= 2);
});

test('straight case: body runs from P1/2 to (H2/2, L3) with no shoulder', () => {
  const g = geo.buildGeometry(rec('9_mm_luger'));
  assert.equal(g.bottleneck, false);
  const n = g.outer.length;
  close(g.outer[n - 1][0], 9.65 / 2); close(g.outer[n - 1][1], 19.15);
  assert.deepEqual(g.missing, []);
});

test('fillets: r1Min at the body end and r2 at the neck end', () => {
  const g = geo.buildGeometry(rec('223_rem'));
  // r1Min 0.64 rounds the corner (4.5, 36.52): no outline point sits on that vertex
  assert.ok(!hasPoint(g.outer, 4.5, 36.52, 1e-3));
  assert.ok(g.outer.some((p) => p[1] > 36.52 && p[1] < 37.2 && p[0] < 4.5));
});

test('bullet: base, cylinder end and tip for a pointy rifle bullet', () => {
  const g = geo.buildGeometry(rec('223_rem'));
  const b = g.bullet;
  close(b.zb, 44.7 - 5.7);
  close(b.zn, 39 + 0.4 * (57.4 - 39));
  const tip = b.exposed[b.exposed.length - 1];
  close(tip[0], 0.635); close(tip[1], 57.4);
  assert.equal(b.shape, 'pointy');
});

test('bullet: pointy ogive points lie on the arc of radius rho centred on the nose start', () => {
  const g = geo.buildGeometry(rec('223_rem'));
  const G1h = 5.7 / 2;
  const m = Math.max(0.08 * 5.7, 1.27);
  const a = G1h - m / 2;
  const n = 57.4 - g.bullet.zn;
  const rho = (a * a + n * n) / (2 * a);
  const centre = [G1h - rho, g.bullet.zn];
  for (const p of g.bullet.exposed.slice(1)) {
    close(Math.hypot(p[0] - centre[0], p[1] - centre[1]), rho, 1e-6);
  }
});

test('bullet: rounded pistol bullet uses k 0.65 and a flat tip of 0.15·G1', () => {
  const g = geo.buildGeometry(rec('9_mm_luger'));
  const b = g.bullet;
  close(b.zb, 19.15 - 0.4 * 9.03);
  close(b.zn, b.zb + 0.65 * (29.69 - b.zb));
  const tip = b.exposed[b.exposed.length - 1];
  close(tip[0], 0.15 * 9.03 / 2); close(tip[1], 29.69);
});

test('bullet: heeled 22 Long Rifle exposes H2 and seats a heel of H2 - 2·tb', () => {
  const g = geo.buildGeometry(rec('22_long_rifle'));
  assert.equal(g.bullet.heeled, true);
  close(g.bullet.exposed[0][0], 5.72 / 2);
  close(g.bullet.heelR, 5.72 / 2 - g.walls.tb);
});

test('walls: tn from the neck, tb from the body with its bounds', () => {
  const g = geo.buildGeometry(rec('223_rem'));
  close(g.walls.tn, (6.43 - 5.7) / 2);
  close(g.walls.tb, 0.6);
});

test('solid head w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb)', () => {
  const g = geo.buildGeometry(rec('223_rem'));
  close(g.w, 3.04 + 1.5);
  const belt = geo.buildGeometry(rec('300_win_mag'));
  close(belt.w, Math.max(2.5, 0.25 * 13.03 / 2, 4.8, 5.59 + belt.walls.tb, 1.27 + 0.94 + (6.755 - 6.035) / Math.tan((35 * Math.PI) / 180) + belt.walls.tb));
});

test('primer pocket per primer type; rimfire has none', () => {
  assert.deepEqual(geo.buildGeometry(rec('223_rem')).pocket, { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(geo.buildGeometry(rec('300_win_mag')).pocket, { diameter: 5.33, depth: 3.3 });
  assert.equal(geo.buildGeometry(rec('22_long_rifle')).pocket, null);
});

test('missing: alpha present but L2 absent draws straight and names L2', () => {
  const r = rec('223_rem');
  delete r.cartridge.lengths.L2;
  const g = geo.buildGeometry(r);
  assert.ok(g.missing.includes('L2'));
  assert.equal(g.bottleneck, false);
});

test('missing: E1 absent draws no groove without inventing values', () => {
  const r = rec('223_rem');
  delete r.cartridge.caseHead.E1;
  const g = geo.buildGeometry(r);
  assert.equal(g.groove, false);
  assert.ok(hasPoint(g.outer, 4.79, 1.14));
});

test('sections exist for every record and every polygon is closed by the axis or the pocket', () => {
  for (const r of records) {
    const g = geo.buildGeometry(r);
    assert.ok(g.section, `${r.key} has a section`);
    assert.ok(g.section.length >= 6, `${r.key} section has points`);
  }
});
