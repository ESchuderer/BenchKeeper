'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Loads data/cartridges.js the way the browser does (classic script, global var).
function loadRecords() {
  const src = fs.readFileSync(path.join(__dirname, '..', 'data', 'cartridges.js'), 'utf8');
  const ctx = {};
  vm.createContext(ctx);
  vm.runInContext(src, ctx);
  // Copy out of the vm realm so array and object prototypes match this realm.
  return JSON.parse(JSON.stringify(ctx.CARTRIDGE_RECORDS));
}

module.exports = { loadRecords };
