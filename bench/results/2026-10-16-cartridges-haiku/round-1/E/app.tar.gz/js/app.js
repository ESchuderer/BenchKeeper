(function () {
  'use strict';

  const catalog = window.CartridgeCatalog;
  const format = window.CartridgeFormat;
  const drawing = window.CartridgeDrawing;
  const records = catalog.parseRecords(window.CARTRIDGE_JSONL);
  const app = document.getElementById('app');
  const SITE_TITLE = 'Cartridges';

  function el(tag, attributes, children) {
    const node = document.createElement(tag);
    for (const [name, value] of Object.entries(attributes || {})) {
      node.setAttribute(name, value);
    }
    for (const child of children || []) {
      node.append(typeof child === 'string' ? document.createTextNode(child) : child);
    }
    return node;
  }

  function cartridgeHref(record) {
    return `#/cartridge/${encodeURIComponent(record.key)}`;
  }

  function currentKey() {
    const match = /^#\/cartridge\/(.+)$/.exec(window.location.hash);
    if (!match) return null;
    try {
      return decodeURIComponent(match[1]);
    } catch (error) {
      return match[1];
    }
  }

  function renderList() {
    document.title = SITE_TITLE;
    const search = el('input', { id: 'search', type: 'search', autocomplete: 'off', 'aria-describedby': 'count' });
    const familySelect = el(
      'select',
      { id: 'family' },
      catalog.FAMILIES.map((family) => el('option', { value: family }, [family === 'all' ? 'All' : family])),
    );
    const count = el('p', { id: 'count', class: 'count', 'aria-live': 'polite' });
    const body = el('tbody');
    const table = el('table', { class: 'cartridge-list' }, [
      el('thead', {}, [el('tr', {}, [el('th', { scope: 'col' }, ['Name']), el('th', { scope: 'col' }, ['Family']), el('th', { scope: 'col', class: 'num' }, ['L3 (mm)'])])]),
      body,
    ]);

    function update() {
      const listed = catalog.filterRecords(records, { query: search.value, family: familySelect.value });
      body.replaceChildren(
        ...listed.map((record) =>
          el('tr', {}, [
            el('td', {}, [el('a', { href: cartridgeHref(record) }, [record.name])]),
            el('td', {}, [record.family]),
            el('td', { class: 'num' }, [format.formatNumber(record.cartridge.lengths.L3)]),
          ]),
        ),
      );
      count.textContent = catalog.countText(listed.length);
    }

    search.addEventListener('input', update);
    familySelect.addEventListener('change', update);
    update();

    const filters = el('form', { class: 'filters', role: 'search' }, [
      el('div', { class: 'field' }, [el('label', { for: 'search' }, ['Search']), search]),
      el('div', { class: 'field' }, [el('label', { for: 'family' }, ['Family']), familySelect]),
    ]);
    filters.addEventListener('submit', (event) => event.preventDefault());

    app.replaceChildren(
      el('section', { 'aria-labelledby': 'list-heading' }, [
        el('h1', { id: 'list-heading' }, ['Cartridges']),
        filters,
        count,
        table,
      ]),
    );
  }

  function metaRow(term, value) {
    return [el('dt', {}, [term]), el('dd', {}, Array.isArray(value) ? value : [value])];
  }

  function capacityNodes(capacity) {
    const nodes = [`${format.formatNumber(capacity.grH2O)} gr H2O`];
    if (capacity.note) nodes.push(` (${capacity.note})`);
    nodes.push(`. Source: ${capacity.source}, `);
    nodes.push(el('a', { href: capacity.url }, [capacity.source]));
    return nodes;
  }

  function sectionTable(title, section) {
    const rows = format.sectionRows(section).map((row) =>
      el('tr', {}, [el('th', { scope: 'row' }, [row.symbol]), el('td', { class: 'num' }, [row.value]), el('td', {}, [row.unit])]),
    );
    return el('section', { class: 'value-section' }, [
      el('h3', {}, [title]),
      el('table', { class: 'values' }, [
        el('thead', {}, [el('tr', {}, [el('th', { scope: 'col' }, ['Symbol']), el('th', { scope: 'col', class: 'num' }, ['Value']), el('th', { scope: 'col' }, ['Unit'])])]),
        el('tbody', {}, rows),
      ]),
    ]);
  }

  function valueGroup(heading, groups) {
    const sections = Object.entries(groups).map(([key, section]) => sectionTable(format.sectionTitle(key), section));
    return el('section', { class: 'value-group' }, [el('h2', {}, [heading]), ...sections]);
  }

  function renderDetail(record) {
    const missing = window.CartridgeGeometry.buildModel(record).missing;
    const annotations = record.annotations || {};
    document.title = `${record.name} · ${SITE_TITLE}`;

    const figure = el('figure', { class: 'drawing-figure' });
    figure.innerHTML = drawing.drawingSvg(record);

    const missingNote = missing.length
      ? el('p', { class: 'missing' }, [`Missing values: ${missing.join(', ')}.`])
      : null;

    const meta = el('dl', { class: 'meta' }, [
      ...(record.alternativeNames ? metaRow('Alternative names', record.alternativeNames.join(' | ')) : []),
      ...metaRow('Family', record.family),
      ...metaRow('Category', annotations.category),
      ...metaRow('Primer type', annotations.primerType),
      ...metaRow('C.I.P. table', record.tab),
      ...metaRow('Country', record.country),
      ...metaRow('Published', record.published),
      ...metaRow('Revised', record.revised),
      ...metaRow('Pressure method', record.pressureMethod),
      ...(annotations.publishedCapacity ? metaRow('Water capacity', capacityNodes(annotations.publishedCapacity)) : []),
    ]);

    app.replaceChildren(
      el('article', { class: 'detail' }, [
        el('nav', { class: 'toolbar no-print', 'aria-label': 'Cartridge' }, [
          el('a', { href: '#/' }, ['All cartridges']),
          el('button', { type: 'button', id: 'print-button' }, ['Print']),
        ]),
        el('h1', { class: 'name' }, [record.name]),
        meta,
        figure,
        ...(missingNote ? [missingNote] : []),
        el('div', { class: 'tables' }, [
          valueGroup('Cartridge', record.cartridge),
          valueGroup('Chamber', record.chamber),
        ]),
        el('footer', { class: 'print-footer' }, [`Source: C.I.P. TDCC, revised ${record.revised}`]),
      ]),
    );
    document.getElementById('print-button').addEventListener('click', () => window.print());
  }

  function renderNotFound() {
    document.title = `Not found · ${SITE_TITLE}`;
    app.replaceChildren(
      el('section', {}, [
        el('h1', {}, ['Cartridge not found']),
        el('p', {}, [el('a', { href: '#/' }, ['All cartridges'])]),
      ]),
    );
  }

  function render() {
    window.scrollTo(0, 0);
    const key = currentKey();
    if (key === null) {
      renderList();
      return;
    }
    const record = catalog.findByKey(records, key);
    if (record) {
      renderDetail(record);
    } else {
      renderNotFound();
    }
  }

  window.addEventListener('hashchange', render);
  render();
})();
