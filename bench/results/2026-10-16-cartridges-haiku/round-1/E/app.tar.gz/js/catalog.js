(function (root) {
  'use strict';

  const FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  function parseRecords(jsonl) {
    return jsonl
      .split('\n')
      .filter((line) => line.trim() !== '')
      .map((line) => JSON.parse(line));
  }

  function matchesQuery(record, query) {
    const needle = query.toLowerCase();
    const names = [record.name, ...(record.alternativeNames || [])];
    return names.some((name) => name.toLowerCase().includes(needle));
  }

  function filterRecords(records, { query, family }) {
    const needle = query.trim();
    return records.filter((record) => {
      const familyOk = family === 'all' || record.family === family;
      return familyOk && (needle === '' || matchesQuery(record, needle));
    });
  }

  function countText(count) {
    return `${count} cartridges`;
  }

  function findByKey(records, key) {
    return records.find((record) => record.key === key);
  }

  const api = { FAMILIES, parseRecords, filterRecords, countText, findByKey };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
  root.CartridgeCatalog = api;
})(typeof window !== 'undefined' ? window : globalThis);
