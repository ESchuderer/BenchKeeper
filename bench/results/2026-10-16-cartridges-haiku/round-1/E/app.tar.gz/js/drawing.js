(function (root) {
  'use strict';

  const format = typeof module !== 'undefined' && module.exports ? require('./format.js') : root.CartridgeFormat;
  const geometry = typeof module !== 'undefined' && module.exports ? require('./geometry.js') : root.CartridgeGeometry;

  const LABEL_SIZE = 2.6;
  const CHAR_WIDTH = 0.6 * LABEL_SIZE;
  const LABEL_STEP = LABEL_SIZE + 0.6;
  const LABEL_MARGIN = 0.3;
  const GAP = 0.8;
  const OVERSHOOT = 0.5;
  const SIDE_OFFSET = 2.5;
  const LEVEL_OFFSET = 6;
  const LEVEL_STEP = 4.5;
  const ARROW_LENGTH = 1.6;
  const ARROW_HALF = 0.5;
  const MARGIN = 2;
  const MIN_WIDTH = 100;
  const TITLE_WIDTH = 66;
  const TITLE_HEIGHT = 17;
  const CENTRE_EXTEND = 2;

  function labelWidth(text) {
    return text.length * CHAR_WIDTH;
  }

  // Box in drawing coordinates (z along the axis, r up). The baseline sits 0.2 label sizes above y0.
  function makeBox(text, x0, y0) {
    return { x0, y0, x1: x0 + labelWidth(text), y1: y0 + LABEL_SIZE };
  }

  function labelText(record, section, field) {
    const values = record.cartridge[section] || {};
    const raw = values[field];
    if (raw === undefined) return null;
    const tolerance = values[`${field}Tol`];
    const value = format.isAngleField(field) ? format.formatAngle(raw) : format.formatValue(raw, tolerance);
    return `${format.symbolOf(field)} ${value}`;
  }

  function mirror(points) {
    return points.map((p) => ({ z: p.z, r: -p.r }));
  }

  function polylineSegments(points, closed = false) {
    const segments = [];
    for (let i = 0; i < points.length - 1; i += 1) {
      segments.push([points[i], points[i + 1]]);
    }
    if (closed && points.length > 2) {
      segments.push([points[points.length - 1], points[0]]);
    }
    return segments;
  }

  // Liang-Barsky clipping: true when segment a-b meets the box grown by margin.
  function segmentHitsBox(a, b, box, margin = 0) {
    const x0 = box.x0 - margin;
    const x1 = box.x1 + margin;
    const y0 = box.y0 - margin;
    const y1 = box.y1 + margin;
    const dz = b.z - a.z;
    const dr = b.r - a.r;
    let t0 = 0;
    let t1 = 1;
    const clip = (p, q) => {
      if (p === 0) return q >= 0;
      const t = q / p;
      if (p < 0) {
        if (t > t1) return false;
        if (t > t0) t0 = t;
      } else {
        if (t < t0) return false;
        if (t < t1) t1 = t;
      }
      return true;
    };
    return clip(-dz, a.z - x0) && clip(dz, x1 - a.z) && clip(-dr, a.r - y0) && clip(dr, y1 - a.r) && t0 <= t1;
  }

  function segmentsCross(p1, p2, p3, p4) {
    const side = (a, b, c) => (b.z - a.z) * (c.r - a.r) - (b.r - a.r) * (c.z - a.z);
    const d1 = side(p3, p4, p1);
    const d2 = side(p3, p4, p2);
    const d3 = side(p1, p2, p3);
    const d4 = side(p1, p2, p4);
    return d1 * d2 < 0 && d3 * d4 < 0;
  }

  function boxesOverlap(a, b, margin = 0) {
    return a.x0 < b.x1 + margin && b.x0 < a.x1 + margin && a.y0 < b.y1 + margin && b.y0 < a.y1 + margin;
  }

  function add(a, b) {
    return { z: a.z + b.z, r: a.r + b.r };
  }

  function scale(a, k) {
    return { z: a.z * k, r: a.r * k };
  }

  function length(a) {
    return Math.hypot(a.z, a.r);
  }

  function horizontalArrow(tip, direction, length = ARROW_LENGTH) {
    return [
      tip,
      { z: tip.z + direction * length, r: tip.r + ARROW_HALF },
      { z: tip.z + direction * length, r: tip.r - ARROW_HALF },
    ];
  }

  function verticalArrow(tip, direction) {
    return [
      tip,
      { z: tip.z + ARROW_HALF, r: tip.r + direction * ARROW_LENGTH },
      { z: tip.z - ARROW_HALF, r: tip.r + direction * ARROW_LENGTH },
    ];
  }

  function radialCandidates(text, dimZ, radius, preferLeft, tipZ) {
    const width = labelWidth(text);
    const candidates = [];
    for (let k = 0; k < 8; k += 1) {
      const bottom = radius + GAP + k * LABEL_STEP;
      candidates.push({ x0: dimZ - width / 2, y0: bottom }, { x0: dimZ + 0.5, y0: bottom }, { x0: dimZ - width - 0.5, y0: bottom });
    }
    for (let k = 0; k < 8; k += 1) {
      const bottom = -radius - GAP - LABEL_SIZE - k * LABEL_STEP;
      candidates.push({ x0: dimZ - width / 2, y0: bottom }, { x0: dimZ + 0.5, y0: bottom });
    }
    const mid = [{ x0: dimZ + GAP, y0: -LABEL_SIZE / 2 }, { x0: dimZ - GAP - width, y0: -LABEL_SIZE / 2 }];
    const beyondTip = [-2, -1, 0, 1, 2].map((k) => ({ x0: tipZ + 1.5, y0: (k * LABEL_STEP) - LABEL_SIZE / 2 }));
    return preferLeft ? [mid[1], mid[0], ...candidates, ...beyondTip] : [...candidates, ...mid, ...beyondTip];
  }

  // Inside the outside view, just left of the shoulder, needs no leader. The others need a clear leader.
  function alphaCandidates(text, mid, tipZ, shoulderZ) {
    const width = labelWidth(text);
    const candidates = [];
    for (const y0 of [0.6, 1.2]) {
      candidates.push({ x0: shoulderZ - width - 1, y0, leader: false });
    }
    for (let k = 0; k < 2; k += 1) {
      candidates.push({ x0: tipZ + 1.5, y0: mid.r + 3 + k * LABEL_STEP, leader: true });
    }
    for (let k = 0; k < 6; k += 1) {
      const bottom = mid.r + 3 + k * LABEL_STEP;
      candidates.push({ x0: mid.z + 3, y0: bottom, leader: true }, { x0: mid.z - width - 3, y0: bottom, leader: true });
    }
    return candidates;
  }

  function layoutDrawing(record) {
    const model = geometry.buildModel(record);
    const layout = {
      model,
      labels: [],
      unplaced: [],
      lines: [],
      arrows: [],
      leaders: [],
      outlineSegments: [],
      titleBox: null,
      titleLines: [],
      centre: null,
      bounds: null,
    };
    if (!model.outline) return layout;

    const cap = record.cartridge;
    const { anchors, outline } = model;
    const R1 = cap.caseHead.R1;
    const Rmax = Math.max(...outline.map((p) => p.r));
    const labelBoxes = [];
    const dimensionSegments = [];

    const addLabel = (text, x0, y0) => {
      const box = makeBox(text, x0, y0);
      labelBoxes.push(box);
      layout.labels.push({ text, box });
    };

    layout.outlineSegments.push(
      ...polylineSegments(outline),
      ...polylineSegments(mirror(outline)),
      ...polylineSegments(model.caseSection, true),
      ...polylineSegments(mirror(model.caseSection), true),
      ...polylineSegments(model.bulletSection),
      ...polylineSegments(mirror(model.bulletSection)),
    );

    // Title block sits under the section, right of the rim labels.
    const titleX0 = Math.max(4, anchors.zTip - TITLE_WIDTH);
    const titleY1 = -(Rmax + LEVEL_OFFSET);
    const titleLines = [record.name, `C.I.P. table ${record.tab} · revised ${record.revised}`, 'Dimensions in mm · Scale 1:1'];
    layout.titleLines = titleLines;
    layout.titleBox = {
      x0: titleX0,
      x1: titleX0 + TITLE_WIDTH,
      y0: titleY1 - TITLE_HEIGHT,
      y1: titleY1,
      lines: [
        { text: titleLines[0], x: titleX0 + 2, y: titleY1 - 4.5, size: 3.4 },
        { text: titleLines[1], x: titleX0 + 2, y: titleY1 - 8.3, size: 2.4 },
        { text: titleLines[2], x: titleX0 + 2, y: titleY1 - 11.6, size: 2.4 },
      ],
      scale: { x: titleX0 + 2, y: titleY1 - 15, length: 10, label: { text: '10 mm', x: titleX0 + 14, y: titleY1 - 15.6, size: 2.4 } },
    };
    const titleOutline = [
      { z: titleX0, r: titleY1 },
      { z: titleX0 + TITLE_WIDTH, r: titleY1 },
      { z: titleX0 + TITLE_WIDTH, r: titleY1 - TITLE_HEIGHT },
      { z: titleX0, r: titleY1 - TITLE_HEIGHT },
    ];
    layout.outlineSegments.push(...polylineSegments(titleOutline, true));

    const isFree = (box, blockers) =>
      !blockers.some(([a, b]) => segmentHitsBox(a, b, box, LABEL_MARGIN)) &&
      !labelBoxes.some((other) => boxesOverlap(other, box, LABEL_MARGIN)) &&
      !boxesOverlap(layout.titleBox, box, LABEL_MARGIN);

    const findSpot = (text, candidates, blockers) =>
      candidates.find((c) => isFree(makeBox(text, c.x0, c.y0), blockers));

    const commitDimension = ({ lines, arrows }) => {
      layout.lines.push(...lines);
      layout.arrows.push(...arrows);
      dimensionSegments.push(...lines);
    };

    // Axial dimensions from the head face: shorter lengths lower, so their extension lines never cross.
    const axial = [{ field: 'L3', z: anchors.zMouth }, { field: 'L6', z: anchors.zTip }];
    if (model.shoulderDrawn) {
      axial.push({ field: 'L1', z: anchors.zShoulder }, { field: 'L2', z: anchors.zNeck });
    }
    axial.sort((a, b) => a.z - b.z);
    axial.forEach((def, k) => {
      const y = Rmax + LEVEL_OFFSET + k * LEVEL_STEP;
      const origin = { z: 0, r: y };
      const end = { z: def.z, r: y };
      commitDimension({
        lines: [
          [origin, end],
          [{ z: 0, r: R1 / 2 + GAP }, { z: 0, r: y + OVERSHOOT }],
          [{ z: def.z, r: geometry.topAt(outline, def.z) + GAP }, { z: def.z, r: y + OVERSHOOT }],
        ],
        arrows: [horizontalArrow(origin, 1), horizontalArrow(end, -1)],
      });
      const text = labelText(record, 'lengths', def.field);
      addLabel(text, Math.max(GAP, def.z / 2 - labelWidth(text) / 2), y + OVERSHOOT + 0.3);
    });

    // Rim length R, dimensioned below the section on the head side. Short spans get shorter arrowheads.
    const rimArrow = Math.min(ARROW_LENGTH, cap.caseHead.R / 2.5);
    const yR = -(Rmax + LEVEL_OFFSET - 0.5);
    const rimEnd = { z: cap.caseHead.R, r: yR };
    commitDimension({
      lines: [
        [{ z: 0, r: yR }, rimEnd],
        [{ z: 0, r: -(R1 / 2 + GAP) }, { z: 0, r: yR - OVERSHOOT }],
        [{ z: cap.caseHead.R, r: -(geometry.topAt(outline, cap.caseHead.R) + GAP) }, { z: cap.caseHead.R, r: yR - OVERSHOOT }],
      ],
      arrows: [horizontalArrow({ z: 0, r: yR }, 1, rimArrow), horizontalArrow(rimEnd, -1, rimArrow)],
    });
    const rimText = labelText(record, 'caseHead', 'R');
    addLabel(rimText, -GAP - labelWidth(rimText), yR - LABEL_SIZE / 2);

    // Diameters: vertical dimension lines beside their feature, with horizontal extension lines.
    // Each tries a few offsets from the feature; the first one whose label fits is kept.
    const { caseHead, collar, powderChamber, projectile } = cap;
    const radial = [
      { field: 'R1', section: 'caseHead', radius: R1 / 2, zf: 0, side: -1, first: SIDE_OFFSET + 1 },
      { field: 'P1', section: 'powderChamber', radius: powderChamber.P1 / 2, zf: anchors.zBody, side: 1, first: SIDE_OFFSET },
    ];
    if (anchors.grooveRadius !== undefined) {
      radial.push({ field: 'E1', section: 'caseHead', radius: anchors.grooveRadius, zf: anchors.zGroove, side: 1, first: SIDE_OFFSET });
    }
    if (model.shoulderDrawn) {
      radial.push({ field: 'P2', section: 'powderChamber', radius: powderChamber.P2 / 2, zf: anchors.zShoulder, side: 1, first: SIDE_OFFSET });
      radial.push({ field: 'H1', section: 'collar', radius: collar.H1 / 2, zf: anchors.zNeck, side: 1, first: SIDE_OFFSET });
    }
    radial.push({ field: 'H2', section: 'collar', radius: collar.H2 / 2, zf: anchors.zMouth, side: 1, first: SIDE_OFFSET });
    radial.push({ field: 'G1', section: 'projectile', radius: projectile.G1 / 2, zf: anchors.zNoseStart, side: 1, first: SIDE_OFFSET });

    const radialDimension = (def, zd) => {
      const sign = zd >= def.zf ? 1 : -1;
      const top = { z: zd, r: def.radius };
      const bottom = { z: zd, r: -def.radius };
      return {
        lines: [
          [top, bottom],
          [{ z: def.zf, r: def.radius }, { z: zd + sign * OVERSHOOT, r: def.radius }],
          [{ z: def.zf, r: -def.radius }, { z: zd + sign * OVERSHOOT, r: -def.radius }],
        ],
        arrows: [verticalArrow(top, -1), verticalArrow(bottom, 1)],
      };
    };

    for (const def of radial) {
      const text = labelText(record, def.section, def.field);
      const reaches = [def.first, def.first + SIDE_OFFSET, def.first + 2 * SIDE_OFFSET];
      let committed = false;
      for (const reach of reaches) {
        const zd = def.zf + def.side * reach;
        const dimension = radialDimension(def, zd);
        if (dimension.lines.some(([a, b]) => labelBoxes.some((box) => segmentHitsBox(a, b, box, LABEL_MARGIN)))) continue;
        const blockers = [...layout.outlineSegments, ...dimensionSegments, ...dimension.lines];
        const spot = findSpot(text, radialCandidates(text, zd, def.radius, def.side < 0, anchors.zTip), blockers);
        if (!spot) continue;
        commitDimension(dimension);
        addLabel(text, spot.x0, spot.y0);
        committed = true;
        break;
      }
      if (!committed) {
        const zd = def.zf + def.side * reaches[0];
        commitDimension(radialDimension(def, zd));
        layout.unplaced.push(text);
        addLabel(text, zd - labelWidth(text) / 2, def.radius + GAP);
      }
    }

    if (model.shoulderDrawn && cap.junctionCone.alpha !== undefined) {
      const text = labelText(record, 'junctionCone', 'alpha');
      const mid = { z: (anchors.zShoulder + anchors.zNeck) / 2, r: (powderChamber.P2 / 2 + collar.H1 / 2) / 2 };
      const normal = { z: powderChamber.P2 / 2 - collar.H1 / 2, r: anchors.zNeck - anchors.zShoulder };
      const unit = scale(normal, 1 / length(normal));
      const start = add(mid, scale(unit, GAP + 0.3));
      const leaderEnd = (c) => ({ z: c.x0 - 0.3, r: c.y0 + LABEL_SIZE / 2 });
      const leaderClear = (c) => {
        const end = leaderEnd(c);
        return (
          !layout.outlineSegments.some(([p, q]) => segmentsCross(start, end, p, q)) &&
          !labelBoxes.some((box) => segmentHitsBox(start, end, box, 0))
        );
      };
      const blockers = [...layout.outlineSegments, ...dimensionSegments];
      const spot = alphaCandidates(text, mid, anchors.zTip, anchors.zShoulder).find(
        (c) => isFree(makeBox(text, c.x0, c.y0), blockers) && (!c.leader || leaderClear(c)),
      );
      if (spot) {
        if (spot.leader) layout.leaders.push([start, leaderEnd(spot)]);
        addLabel(text, spot.x0, spot.y0);
      } else {
        layout.unplaced.push(text);
        addLabel(text, mid.z + 3, mid.r + 3);
      }
    }

    layout.centre = [{ z: -CENTRE_EXTEND * 2, r: 0 }, { z: anchors.zTip + CENTRE_EXTEND, r: 0 }];

    const points = [...outline, ...mirror(outline), ...labelBoxes.flatMap((b) => [{ z: b.x0, r: b.y0 }, { z: b.x1, r: b.y1 }])];
    points.push({ z: layout.titleBox.x0, r: layout.titleBox.y0 }, { z: layout.titleBox.x1, r: layout.titleBox.y1 });
    const xs = points.map((p) => p.z);
    const ys = points.map((p) => p.r);
    const x0 = Math.min(...xs) - MARGIN;
    let x1 = Math.max(...xs) + MARGIN;
    if (x1 - x0 < MIN_WIDTH) x1 = x0 + MIN_WIDTH;
    layout.bounds = { x0, x1, y0: Math.min(...ys) - MARGIN, y1: Math.max(...ys) + MARGIN };
    return layout;
  }

  function escapeXml(text) {
    return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function num(value) {
    return Number(value.toFixed(3));
  }

  // Upper half: world r maps to svg y = -r. Lower half (section): svg y = r.
  function pathData(points, lower) {
    return points
      .map((p, i) => `${i === 0 ? 'M' : 'L'}${num(p.z)} ${num(lower ? p.r : -p.r)}`)
      .join(' ');
  }

  function segmentsData(segments, lower) {
    return segments.map(([a, b]) => pathData([a, b], lower)).join(' ');
  }

  function drawingSvg(record) {
    const layout = layoutDrawing(record);
    if (!layout.bounds) return '';
    const { model } = layout;
    const { x0, x1, y0, y1 } = layout.bounds;
    const arrows = layout.arrows.map((tri) => `${pathData(tri, false)} Z`).join(' ');
    const title = layout.titleBox;
    const labels = layout.labels
      .map((l) => `<text class="drawing-label" x="${num(l.box.x0)}" y="${num(-(l.box.y0 + 0.2 * LABEL_SIZE))}" font-size="${LABEL_SIZE}">${escapeXml(l.text)}</text>`)
      .join('');
    const titleText = title.lines
      .map((t) => `<text class="drawing-title-text" x="${num(t.x)}" y="${num(-t.y)}" font-size="${t.size}">${escapeXml(t.text)}</text>`)
      .join('');
    const scale = title.scale;
    const scaleText = `<text class="drawing-title-text" x="${num(scale.label.x)}" y="${num(-scale.label.y)}" font-size="${scale.label.size}">${escapeXml(scale.label.text)}</text>`;
    const scaleY = -scale.y;
    const scaleDraw = `M${num(scale.x)} ${num(scaleY)} H${num(scale.x + scale.length)} M${num(scale.x)} ${num(scaleY - 0.8)} V${num(scaleY + 0.8)} M${num(scale.x + scale.length)} ${num(scaleY - 0.8)} V${num(scaleY + 0.8)}`;

    return [
      `<svg class="drawing" xmlns="http://www.w3.org/2000/svg" viewBox="${num(x0)} ${num(-y1)} ${num(x1 - x0)} ${num(y1 - y0)}" role="img" aria-label="${escapeXml(record.name)} drawing">`,
      '<defs><pattern id="cip-section-hatch" width="1.4" height="1.4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="1.4" class="drawing-hatch"/></pattern></defs>',
      `<path class="drawing-centre" d="${pathData(layout.centre, false)}"/>`,
      `<path class="drawing-outline" d="${pathData(model.outline, false)}"/>`,
      `<path class="drawing-section" fill="url(#cip-section-hatch)" d="${pathData(model.caseSection, true)} Z"/>`,
      `<path class="drawing-outline" d="${pathData(model.outline, true)}"/>`,
      `<path class="drawing-bullet" d="${pathData(model.bulletSection, true)}"/>`,
      `<path class="drawing-dim" d="${segmentsData(layout.lines, false)}"/>`,
      `<path class="drawing-arrow" d="${arrows}"/>`,
      layout.leaders.length ? `<path class="drawing-leader" d="${segmentsData(layout.leaders, false)}"/>` : '',
      labels,
      `<rect class="drawing-title" x="${num(title.x0)}" y="${num(-title.y1)}" width="${num(title.x1 - title.x0)}" height="${num(title.y1 - title.y0)}"/>`,
      titleText,
      `<path class="drawing-scale" d="${scaleDraw}"/>`,
      scaleText,
      '</svg>',
    ].join('\n');
  }

  const api = { layoutDrawing, drawingSvg, segmentHitsBox };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
  root.CartridgeDrawing = api;
})(typeof window !== 'undefined' ? window : globalThis);
