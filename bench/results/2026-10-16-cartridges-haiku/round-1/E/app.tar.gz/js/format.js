(function (root) {
  'use strict';

  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };

  const ANGLE_FIELDS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];

  const UNITS = {
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: '',
  };

  const SECTION_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling',
  };

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  function formatNumber(value) {
    return String(value);
  }

  function angleToDegrees(angle) {
    if (typeof angle === 'number') {
      return angle;
    }
    return angle.degrees + angle.minutes / 60 + angle.seconds / 3600;
  }

  function formatAngle(angle) {
    if (typeof angle === 'number') {
      return `${formatNumber(angle)}°`;
    }
    return `${formatNumber(angle.degrees)}°${pad2(angle.minutes)}'${pad2(angle.seconds)}"`;
  }

  function formatValue(value, tolerance) {
    if (tolerance === undefined) {
      return formatNumber(value);
    }
    return `${formatNumber(value)} ${formatNumber(tolerance)}`;
  }

  function isAngleField(field) {
    return ANGLE_FIELDS.includes(field);
  }

  function symbolOf(field) {
    return SYMBOLS[field] || field;
  }

  function unitOf(field) {
    if (isAngleField(field)) {
      return '';
    }
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  function sectionTitle(key) {
    return SECTION_TITLES[key] || key;
  }

  function sectionRows(section) {
    const rows = [];
    for (const field of Object.keys(section)) {
      const base = field.endsWith('Tol') ? field.slice(0, -3) : null;
      if (base && Object.prototype.hasOwnProperty.call(section, base)) {
        continue;
      }
      const raw = section[field];
      const toleranceField = `${field}Tol`;
      const hasTolerance = Object.prototype.hasOwnProperty.call(section, toleranceField);
      const text = isAngleField(field) ? formatAngle(raw) : formatValue(raw, hasTolerance ? section[toleranceField] : undefined);
      rows.push({ field, symbol: symbolOf(field), value: text, unit: unitOf(field) });
    }
    return rows;
  }

  const api = {
    formatNumber,
    formatValue,
    formatAngle,
    angleToDegrees,
    isAngleField,
    symbolOf,
    unitOf,
    sectionTitle,
    sectionRows,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
  root.CartridgeFormat = api;
})(typeof window !== 'undefined' ? window : globalThis);
