(function (root) {
  'use strict';

  const format = typeof module !== 'undefined' && module.exports ? require('./format.js') : root.CartridgeFormat;

  const ARC_STEPS = 12;
  const PRIMER_POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 },
  };
  const HEELED_TOLERANCE = 0.015;

  function toRadians(angle) {
    return (format.angleToDegrees(angle) * Math.PI) / 180;
  }

  function sub(a, b) {
    return { z: a.z - b.z, r: a.r - b.r };
  }

  function add(a, b) {
    return { z: a.z + b.z, r: a.r + b.r };
  }

  function scale(a, k) {
    return { z: a.z * k, r: a.r * k };
  }

  function length(a) {
    return Math.hypot(a.z, a.r);
  }

  function normalise(a) {
    return scale(a, 1 / length(a));
  }

  function dot(a, b) {
    return a.z * b.z + a.r * b.r;
  }

  function reversed(points) {
    return points.slice().reverse();
  }

  // Samples an arc of the circle (z, r) = centre + radius (cos t, sin t) from angle a0 to a1.
  function sampleArc(centre, radius, a0, a1, steps = ARC_STEPS) {
    const points = [];
    for (let i = 0; i <= steps; i += 1) {
      const t = a0 + ((a1 - a0) * i) / steps;
      points.push({ z: centre.z + radius * Math.cos(t), r: centre.r + radius * Math.sin(t) });
    }
    return points;
  }

  // Replaces corner C of the path P-C-N by an arc tangent to both segments. Returns the arc points.
  function roundCorner(p, c, n, radius) {
    const v1 = normalise(sub(p, c));
    const v2 = normalise(sub(n, c));
    const interior = Math.acos(Math.max(-1, Math.min(1, dot(v1, v2))));
    if (interior < 1e-9 || Math.PI - interior < 1e-9) {
      return null;
    }
    const half = interior / 2;
    let tangent = radius / Math.tan(half);
    const maxTangent = Math.min(length(sub(p, c)), length(sub(n, c))) * 0.999;
    let effective = radius;
    if (tangent > maxTangent) {
      tangent = maxTangent;
      effective = tangent * Math.tan(half);
    }
    const bisector = normalise(add(v1, v2));
    const centre = add(c, scale(bisector, effective / Math.sin(half)));
    const a0 = Math.atan2(c.r + v1.r * tangent - centre.r, c.z + v1.z * tangent - centre.z);
    const a1 = Math.atan2(c.r + v2.r * tangent - centre.r, c.z + v2.z * tangent - centre.z);
    let sweep = a1 - a0;
    while (sweep > Math.PI) sweep -= 2 * Math.PI;
    while (sweep <= -Math.PI) sweep += 2 * Math.PI;
    return sampleArc(centre, effective, a0, a0 + sweep);
  }

  function applyFillets(points, radii) {
    let out = points.slice();
    const indices = Object.keys(radii)
      .map(Number)
      .filter((i) => radii[i] > 0)
      .sort((a, b) => b - a);
    for (const i of indices) {
      const arc = roundCorner(out[i - 1], out[i], out[i + 1], radii[i]);
      if (arc) {
        out = [...out.slice(0, i), ...arc, ...out.slice(i + 1)];
      }
    }
    return out;
  }

  function radiusAt(points, z) {
    for (let i = 0; i < points.length - 1; i += 1) {
      const a = points[i];
      const b = points[i + 1];
      if (a.z < b.z && z >= a.z && z <= b.z) {
        return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
      }
    }
    return points[points.length - 1].r;
  }

  function topAt(points, z) {
    let top = 0;
    for (let i = 0; i < points.length - 1; i += 1) {
      const a = points[i];
      const b = points[i + 1];
      if (z < Math.min(a.z, b.z) || z > Math.max(a.z, b.z)) continue;
      const r = a.z === b.z ? Math.max(a.r, b.r) : radiusAt([a, b], z);
      top = Math.max(top, r);
    }
    return top;
  }

  function bulletParams(shape, category) {
    const pistol = category === 'pistol';
    switch (shape) {
      case 'pointy':
        return { seat: 1.0, cylinder: 0.4, meplat: (g) => Math.max(0.08 * g, 1.27), nose: 'ogive' };
      case 'rounded':
        return { seat: pistol ? 0.4 : 0.8, cylinder: pistol ? 0.65 : 0.55, meplat: (g) => 0.15 * g, nose: 'ellipse' };
      case 'flat':
        return { seat: pistol ? 0.4 : 0.8, cylinder: pistol ? 0.7 : 0.6, meplat: (g) => 0.55 * g, nose: 'cone' };
      case 'semi_wadcutter':
        return { seat: 0.6, cylinder: 0.78, meplat: (g) => 0.6 * g, nose: 'cone' };
      default:
        return null;
    }
  }

  // Nose from (zs, diameter/2) to the flat tip (tipZ, meplat/2). Points run from the start to the tip.
  function noseSamples(kind, zs, halfDiameter, halfMeplat, tipZ) {
    const n = tipZ - zs;
    if (kind === 'ogive') {
      const d = halfDiameter - halfMeplat;
      const rho = (d * d + n * n) / (2 * d);
      const centre = { z: zs, r: halfDiameter - rho };
      const end = Math.atan2(halfMeplat - centre.r, n);
      return sampleArc(centre, rho, Math.PI / 2, end);
    }
    if (kind === 'ellipse') {
      const b = halfDiameter - halfMeplat;
      const points = [];
      for (let i = 0; i <= ARC_STEPS; i += 1) {
        const t = ((Math.PI / 2) * i) / ARC_STEPS;
        points.push({ z: zs + n * Math.sin(t), r: halfMeplat + b * Math.cos(t) });
      }
      return points;
    }
    return [
      { z: zs, r: halfDiameter },
      { z: tipZ, r: halfMeplat },
    ];
  }

  function rimTypeOf(family, ratio) {
    if (family === 'belted') return 'belted';
    if (family === 'rimfire') return 'rimfire';
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function wallThicknesses(tn, P1) {
    const neck = Math.max(tn, 0);
    return { tn: neck, tb: Math.min(Math.max(1.3 * neck, 0.6), 0.35 * (P1 / 2)) };
  }

  function buildModel(record) {
    const cap = record.cartridge;
    const annotations = record.annotations || {};
    const caseHead = cap.caseHead || {};
    const lengths = cap.lengths || {};
    const collar = cap.collar || {};
    const junction = cap.junctionCone || {};
    const powder = cap.powderChamber || {};
    const projectile = cap.projectile || {};
    const missing = [];
    const model = { key: record.key, name: record.name, missing, outline: null, caseSection: null, bulletSection: null };

    const required = {
      R1: caseHead.R1,
      P1: powder.P1,
      R: caseHead.R,
      L3: lengths.L3,
      L6: lengths.L6,
      G1: projectile.G1,
      H2: collar.H2,
    };
    for (const [symbol, value] of Object.entries(required)) {
      if (value === undefined) missing.push(symbol);
    }
    const bulletParamsFor = bulletParams(annotations.defaultBulletShape, annotations.category);
    if (!bulletParamsFor) missing.push('defaultBulletShape');
    if (missing.length > 0) return model;

    const { R1, P1, R, L3, L6, G1, H2 } = required;
    const rimType = rimTypeOf(record.family, R1 / P1);
    const { E, E1, eMin, R3, delta, f, beta } = { ...caseHead };
    const points = [{ z: 0, r: 0 }];
    const radii = {};
    let zTop;

    if (rimType === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      const centre = { z: rho, r: R1 / 2 - rho };
      zTop = 2 * rho;
      points.push(...sampleArc(centre, rho, Math.PI, 0));
    } else {
      const chamfered = beta !== undefined && f !== undefined && format.angleToDegrees(beta) < 90;
      if (chamfered) {
        const chamfer = Math.min(f * Math.tan(toRadians(beta)), R1 / 4);
        points.push({ z: 0, r: R1 / 2 - chamfer }, { z: f, r: R1 / 2 });
      } else {
        points.push({ z: 0, r: R1 / 2 });
      }
      zTop = R;
      points.push({ z: zTop, r: R1 / 2 });
    }

    const grooved = E !== undefined && E1 !== undefined && eMin !== undefined;
    let beltEnd;
    let zBody;
    if (grooved) {
      points.push({ z: zTop, r: E1 / 2 }, { z: zTop + eMin, r: E1 / 2 });
      if (rimType === 'belted' && R3 !== undefined && delta !== undefined) {
        const rise = (R3 / 2 - E1 / 2) / Math.tan(toRadians(delta));
        beltEnd = zTop + eMin + rise;
        points.push({ z: beltEnd, r: R3 / 2 }, { z: E, r: R3 / 2 }, { z: E, r: P1 / 2 });
      } else {
        if (rimType === 'belted') {
          if (R3 === undefined) missing.push('R3');
          if (delta === undefined) missing.push('delta');
        }
        points.push({ z: E, r: P1 / 2 });
      }
      zBody = E;
    } else {
      points.push({ z: zTop, r: P1 / 2 });
      zBody = zTop;
    }

    const { alpha } = junction;
    const { L1, L2 } = lengths;
    const { P2 } = powder;
    const { H1 } = collar;
    const bottleneck = alpha !== undefined && L1 !== undefined && L2 !== undefined;
    const shoulderDrawn = bottleneck && P2 !== undefined && H1 !== undefined;
    if (bottleneck && P2 === undefined) missing.push('P2');
    if (bottleneck && H1 === undefined) missing.push('H1');

    let zA;
    let zB;
    if (shoulderDrawn) {
      points.push({ z: L1, r: P2 / 2 }, { z: L2, r: H1 / 2 }, { z: L3, r: H2 / 2 });
      radii[points.length - 3] = junction.r1Min;
      radii[points.length - 2] = junction.r2;
      zA = L1;
      zB = L2;
    } else {
      points.push({ z: L3, r: H2 / 2 });
      zA = zBody;
      zB = L3;
    }
    const caseOuter = applyFillets(points, radii);

    const heeled = H2 - G1 <= HEELED_TOLERANCE;
    const exposedRadius = (heeled ? H2 : G1) / 2;
    const { tn, tb } = wallThicknesses((H2 - G1) / 2, P1);

    const shape = bulletParamsFor;
    const seat = shape.seat * G1;
    const zBase = L3 - seat;
    const zCylinderEnd = zBase + shape.cylinder * (L6 - zBase);
    const zNose = Math.max(zCylinderEnd, L3);
    const meplat = shape.meplat(G1);
    const nose = noseSamples(shape.nose, zNose, exposedRadius, meplat / 2, L6);
    const bulletOuter = [{ z: L3, r: exposedRadius }];
    if (zNose > L3) bulletOuter.push({ z: zNose, r: exposedRadius });
    bulletOuter.push(...nose.slice(1), { z: L6, r: 0 });

    const seatRadius = heeled ? (H2 - 2 * tb) / 2 : G1 / 2;
    const bulletSection = [{ z: zBase, r: 0 }, { z: zBase, r: seatRadius }];
    if (seatRadius !== exposedRadius) bulletSection.push({ z: L3, r: seatRadius });
    bulletSection.push(...bulletOuter);

    const primer = PRIMER_POCKETS[annotations.primerType];
    const pocket = rimType !== 'rimfire' && primer ? { radius: primer.diameter / 2, depth: primer.depth } : null;
    const wTerms = [2.5, P1 / 8];
    if (pocket) wTerms.push(pocket.depth + 1.5);
    if (grooved) wTerms.push(E + tb);
    if (beltEnd !== undefined) wTerms.push(beltEnd + tb);
    const w = Math.max(...wTerms);

    const thickness = (z) => {
      if (z <= zA) return tb;
      if (z >= zB) return tn;
      return tb + ((tn - tb) * (z - zA)) / (zB - zA);
    };
    const inner = [{ z: w, r: radiusAt(caseOuter, w) - thickness(w) }];
    for (const p of caseOuter.slice(1, -1)) {
      if (p.z > w) inner.push({ z: p.z, r: p.r - thickness(p.z) });
    }
    inner.push({ z: L3, r: H2 / 2 - tn });

    const head = caseOuter.slice(1);
    const caseSection = pocket
      ? [{ z: 0, r: pocket.radius }, ...head, ...reversed(inner), { z: w, r: 0 }, { z: pocket.depth, r: 0 }, { z: pocket.depth, r: pocket.radius }]
      : [{ z: 0, r: 0 }, ...head, ...reversed(inner), { z: w, r: 0 }];

    const outline = [...caseOuter];
    for (const p of bulletOuter) {
      const last = outline[outline.length - 1];
      if (last.z !== p.z || last.r !== p.r) outline.push(p);
    }

    Object.assign(model, {
      rimType,
      heeled,
      tb,
      tn,
      w,
      pocket,
      shoulderDrawn,
      anchors: {
        zTop,
        zGroove: grooved ? zTop + eMin / 2 : zTop,
        zBody,
        zShoulder: L1,
        zNeck: L2,
        zMouth: L3,
        zTip: L6,
        zNoseStart: zNose,
        zBase,
        grooveRadius: grooved ? E1 / 2 : undefined,
      },
      outline,
      caseSection,
      bulletSection,
    });
    return model;
  }

  const api = {
    buildModel,
    roundCorner,
    topAt,
    radiusAt,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
  root.CartridgeGeometry = api;
})(typeof window !== 'undefined' ? window : globalThis);
