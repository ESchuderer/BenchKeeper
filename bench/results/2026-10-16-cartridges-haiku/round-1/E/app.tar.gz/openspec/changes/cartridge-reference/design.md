# Design

## Context

The repository is empty apart from project setup (Node.js 22, no dependencies, no existing app code). The app must run from `file://` in Chromium, so `fetch()` of a data file and ES module imports are unavailable. See proposal.md - Why and What Changes.

## Goals / Non-Goals

**Goals:**
- Pure logic (formatting, search, geometry, label placement) testable with `node --test` without a browser.
- Every value of each record shown, nothing invented; drawing computed from the published values by the rules in the brief.

**Non-Goals:**
- No drawing for records whose values are insufficient beyond the missing-value note.
- No editing, no export other than the browser print dialog, no build output.

## Decisions

- **Files and loading.** Classic scripts loaded in order from `index.html`: `data/cartridges.js`, `js/format.js`, `js/catalog.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js`. Alternative: ES modules, rejected because Chromium blocks module scripts over `file://` without a server.
- **Data.** `data/cartridges.js` assigns the JSONL text to a global string, one record per line, parsed at start-up. Alternative: a JS array literal; rejected because it would reformat the supplied lines.
- **Module pattern.** Each file wraps its API in an IIFE that sets a global and, when `module` exists, sets `module.exports`. This gives browser globals and CommonJS for `node --test` with no bundler.
- **Routing.** `location.hash` with `#/` for the list and `#/cartridge/<key>` for detail. Alternative: History API; rejected because it needs server rewrites for bookmarks.
- **Units.** Fields not in the brief's unit list are shown in mm (this includes `S`, `u`, `h`, `s`, `b`, `G`, `Fe`, `deltaL`, `L4`, `L5`). `grH2O` is shown as `gr H2O`, inferred from the field name; the brief does not state the unit.
- **Numbers.** Shown with `String(value)`, which drops a trailing `.0` (`4150.0` → `4150`) and keeps the decimal point.
- **Geometry representation.** Profiles are arrays of `{z, r}` points in mm, with arcs sampled to short polylines. Sampling keeps the drawing code and the overlap test on one representation.
- **Dimension layout.** Axial dimensions (L1, L2, L3, L6) stack above the drawing from the head face, shorter lengths lower, so their extension lines never cross. Diameters are vertical dimension lines 2.5 mm to the right of their feature (R1 to the left of the head), with horizontal extension lines. Labels are placed by a greedy search over candidate positions that rejects any box touching the outline, another label, or a dimension line. The title block is at a fixed position below the section.
- **Scaling.** The SVG `viewBox` is the bounding box of the drawing with a 100 mm minimum width. Strokes use `vector-effect: non-scaling-stroke` so line weight stays constant when a small cartridge is enlarged to full width.
- **Print.** `@media print` hides navigation, search and buttons, sets A4 portrait, forces light colours and lays the two table groups side by side.
- **Theme.** CSS custom properties with `prefers-color-scheme: dark`; the print rule overrides them to light.
- **Tests.** `node --test` on `test/*.test.js` for format, catalog, geometry, drawing (label overlap for all 25 records) and the data file (25 records, names, keys). Browser behaviour is checked with the Playwright MCP against the running page.

## Risks / Trade-offs

- [Geometry rules leave cases underdetermined, for example a bottleneck with alpha but no H1] → draw the body straight and report the missing value.
- [Greedy label placement can fail for a crowded record] → the label-overlap test covers all 25 records; a failure is reported with the record key.
- [Labels are small on a phone] → the drawing is scaled to the container; font size is in mm, so labels scale with it. Accepted: legibility is achieved by zoom on the device.
- [The unit of `S` and `u` is not stated in the brief] → shown in mm; listed in the final report as an assumption to confirm.
