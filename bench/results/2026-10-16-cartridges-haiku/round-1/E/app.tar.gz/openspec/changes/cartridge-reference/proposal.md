# Proposal

## Why

The project needs a static, offline reference of 25 C.I.P. cartridge records for reloaders, gunsmiths and engineers. The data is fixed (the 25 OpenBallistics records supplied with the request); the app presents it as a searchable list, a detail view with all published values, and a dimensioned drawing computed from the values.

## What Changes

- Add a static web app in the project root: `index.html`, `css/style.css`, `js/*.js`, `data/cartridges.js` (the 25 records verbatim, one JSON object per line, in a JS string).
- Start page: heading "Cartridges", a list of every record (name link, family, L3), a "Search" field matching name and alternative names, a "Family" select (All, rimless, rimmed, belted, pistol, rimfire), and the count text "<n> cartridges".
- Detail view at `#/cartridge/<key>`: name, alternative names, family, category, primer type, C.I.P. table, country, dates, pressure method, water capacity with source link, drawing, value tables grouped by section (Symbol, Value, Unit), "Print" and "All cartridges" controls.
- Value formatting: values as published, tolerances shown next to their value, angles as `40°` or `39°59'49"`, symbols and units per the brief.
- Drawing: inline SVG, 1 user unit = 1 mm, outside view above the axis, section below, dimension lines for the required and published features, title block, scale.
- Print: `window.print()` produces one A4 portrait page, black on white, with no navigation or controls and a source footer (C.I.P. TDCC, revision date).
- Light and dark theme following `prefers-color-scheme`; print always light.
- Pure logic (formatting, search, geometry, label placement) is covered by tests run with the Node.js built-in test runner (`node --test`). No runtime dependencies, no build step, no network requests.

## Capabilities

### New Capabilities

- `cartridge-catalog`: the start page, search and family filter, the result count, the name links, and the hash routing between list and detail views.
- `cartridge-detail`: the detail view contents, value formatting (numbers, tolerances, angles, symbols, units), the tables grouped by section, the water capacity source line, the print layout and the theme.
- `cartridge-drawing`: the geometry rules that turn a record into an outline, a section and a bullet, the dimension and label layout, the title block, and the scaling of the SVG.

### Modified Capabilities

None (no existing specs in the project).

## Impact

- New files only: `index.html`, `css/style.css`, `js/format.js`, `js/catalog.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js`, `data/cartridges.js`, `package.json` (scripts only, no dependencies), `test/*.test.js`.
- No server, no network, no framework. Works from `file://` in Chromium and from any static server.
- Unit assumptions recorded in `design.md`: fields not listed in the brief's unit list are shown in mm; `grH2O` is shown as `gr H2O`.
