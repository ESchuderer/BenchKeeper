# Spec Delta

## Purpose

Lets a technical user find one of the 25 published C.I.P. cartridges by name, alternative name or family and open its detail view from a list that works offline.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" and one entry per record, showing the record's name as a link, its family and its L3 value.

#### Scenario: All records listed
- **WHEN** the start page is shown with no filter
- **THEN** every one of the 25 records is listed and the count text reads "25 cartridges"

#### Scenario: Name link text
- **WHEN** a list entry is inspected
- **THEN** the link text is exactly the record's `name` and the link opens that cartridge's detail view

### Requirement: Search filters by name and alternative names
The start page SHALL provide a field labelled "Search" that filters the list as the user types, matching case-insensitively against `name` and every entry of `alternativeNames`.

#### Scenario: Alternative name match
- **WHEN** the user types `7,62 x 51`
- **THEN** the list contains "308 Win." and no other cartridge

#### Scenario: Empty match
- **WHEN** the user types a string that matches no name or alternative name
- **THEN** the list is empty and the count text reads "0 cartridges"

### Requirement: Family filter
The start page SHALL provide a select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire. Selecting a family SHALL list only records of that family. The filter SHALL combine with the search field.

#### Scenario: Family selected
- **WHEN** the user selects "belted"
- **THEN** only the records whose family is `belted` are listed

#### Scenario: Family and search combined
- **WHEN** the family is "rimfire" and the search text is "22"
- **THEN** only rimfire records whose name or alternative name contains "22" are listed

### Requirement: Result count
The start page SHALL show the text "<n> cartridges" where n is the number of listed records.

#### Scenario: Count follows filter
- **WHEN** a filter changes the listed records
- **THEN** the count text shows the new number of listed records

### Requirement: Detail views have their own address
Each cartridge SHALL have a detail view at the address `#/cartridge/<key>`, where `<key>` is the record's `key`. Opening that address directly, after a reload, or from a bookmark SHALL show that cartridge's detail view.

#### Scenario: Direct address
- **WHEN** the page is opened at `#/cartridge/223_rem`
- **THEN** the detail view of "223 Rem." is shown

#### Scenario: Unknown key
- **WHEN** the page is opened at `#/cartridge/unknown`
- **THEN** a message states that the cartridge was not found and a link returns to the list

#### Scenario: Back to list
- **WHEN** the user activates the "All cartridges" link in a detail view
- **THEN** the start page is shown
