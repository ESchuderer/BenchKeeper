# Spec Delta

## Purpose

Presents every published value of one cartridge record, formatted as published, so a reloader or gunsmith can read the C.I.P. data without opening the source file.

## ADDED Requirements

### Requirement: Detail view header and metadata
The detail view SHALL show the cartridge name as its heading, followed by alternative names, family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method and the published water capacity with its source link.

#### Scenario: Metadata shown
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the heading is "308 Win." and the page shows "308 Winchester" and "7,62 x 51" as alternative names, family "rimless", primer type "lr", tab "I", published "1984-06-14", revised "2008-09-23" and pressure method "Transducer"

#### Scenario: Water capacity with source
- **WHEN** a record has `publishedCapacity`
- **THEN** the page shows the value `grH2O` in gr H2O, the `note` when present, and the `source` name linked to its `url`

#### Scenario: Missing optional field
- **WHEN** a record has no alternative names
- **THEN** the alternative names row is omitted

### Requirement: Values as published
Numeric values SHALL be shown as published with a decimal point and no thousands separator, without trailing zeros (for example `4150` and `51.18`). Names SHALL be shown exactly as published (for example `6,5 Creedmoor`).

#### Scenario: Integer pressure
- **WHEN** a pressure value is published as 4150.0
- **THEN** the value cell shows `4150`

#### Scenario: Name with comma
- **WHEN** the record name is `6,5 Creedmoor`
- **THEN** the heading shows `6,5 Creedmoor`

### Requirement: Tolerances next to their value
A field `<X>Tol` SHALL be shown in the value cell of X, after the value, and SHALL NOT have a row of its own.

#### Scenario: Length with tolerance
- **WHEN** `lengths.L1` is 39.62 and `lengths.L1Tol` is -0.2
- **THEN** the L1 value cell reads `39.62 -0.2` and no row labelled L1Tol exists

### Requirement: Angles
Angle values SHALL be shown as `<degrees>°` when published as a number, and as `<d>°<mm>'<ss>"` when published as an object with `degrees`, `minutes` and `seconds`, with minutes and seconds in two digits.

#### Scenario: Degrees object
- **WHEN** an angle is `{degrees: 39, minutes: 59, seconds: 49}`
- **THEN** it is shown as `39°59'49"`

#### Scenario: Plain number
- **WHEN** an angle is 40
- **THEN** it is shown as `40°`

### Requirement: Symbols and units
Each row SHALL show the field name as its symbol, except that `eMin` is shown as "e min", `r1Min` as "r1 min", `r1Max` as "r1 max", `alpha` as "α", `alpha1` as "α1", `beta` as "β", `delta` as "δ", `deltaL` as "delta L", `L3PlusG` as "L3 + G". Units SHALL be `bar` for Pmax, PK and PE; `J` for EE; `g` for M; `mm²` for Q; empty for N; empty for the angles; `mm` for every other numeric field. The unit column SHALL be empty for N and for angles.

#### Scenario: Pressure units
- **WHEN** `pressures.Pmax` is 4150
- **THEN** the row shows symbol `Pmax`, value `4150` and unit `bar`

#### Scenario: Symbol override
- **WHEN** the field is `L3PlusG`
- **THEN** the symbol is "L3 + G"

### Requirement: Value tables grouped by section
The detail view SHALL show all cartridge values under a "Cartridge" heading and all chamber values under a "Chamber" heading, each section group as its own table with the columns "Symbol", "Value" and "Unit", and every record field appears exactly once.

#### Scenario: Section grouping
- **WHEN** the detail view of any record is shown
- **THEN** the cartridge tables contain the sections of `cartridge` and the chamber tables contain the sections of `chamber`, with every non-tolerance field present as one row

### Requirement: Print
The detail view SHALL have a "Print" button that opens the browser print dialog. The printed output SHALL be one A4 portrait page in black on white, showing the name heading, the drawing at full width with every label legible, and the tables. Navigation, search fields and buttons SHALL NOT be printed. The printed page SHALL end with a footer naming the source "C.I.P. TDCC" and the revision date.

#### Scenario: One page
- **WHEN** a detail view is printed in Chromium
- **THEN** the output is a single A4 portrait page with no navigation, search field or button

### Requirement: Theme
The interface SHALL use a light or dark colour scheme following the system setting. Printed output SHALL always use the light scheme.

#### Scenario: Dark system setting
- **WHEN** the system colour scheme is dark
- **THEN** the page background is dark and text is light, and printing still produces black on white
