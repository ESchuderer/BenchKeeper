# Spec Delta

## Purpose

Shows each cartridge as a dimensioned, to-scale drawing computed only from its published values, so the geometry can be checked against the C.I.P. data.

## ADDED Requirements

### Requirement: Drawing is an inline SVG to scale
The detail view SHALL contain one inline SVG drawing with the accessible name "<name> drawing". In the SVG, 1 user unit SHALL equal 1 mm, the axis SHALL be horizontal, the head SHALL be on the left, and the drawing SHALL scale to the width of its container.

#### Scenario: Accessible name
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** an SVG element has the accessible name "223 Rem. drawing"

#### Scenario: Phone width
- **WHEN** the container is 360 CSS pixels wide
- **THEN** the drawing is 360 pixels wide and its height follows the aspect ratio

### Requirement: Outside view and section
The upper half of the drawing SHALL show the outside view of the cartridge and bullet. The lower half SHALL show the section, with cut walls hatched, and a dash-dot centre line along the axis.

#### Scenario: Section walls
- **WHEN** a bottleneck case is drawn
- **THEN** the lower half shows the case walls hatched between the outer profile and an inner profile offset by the body wall thickness along the body and by the neck wall thickness along the neck

#### Scenario: Solid head
- **WHEN** a case with a primer pocket is drawn
- **THEN** the section shows a solid head from the head face to the computed head depth, with the primer pocket open at the head face

### Requirement: Rim type
The drawing SHALL classify the rim as belted when `family` is `belted`, rimfire when `family` is `rimfire`, and otherwise as rimmed when R1/P1 is 1.05 or more, rebated when R1/P1 is below 0.98, and rimless in all other cases. The rim edge SHALL be a half-round for rimfire cases and a chamfer or a square corner otherwise.

#### Scenario: Rimfire rim
- **WHEN** the record's family is `rimfire`
- **THEN** the rim edge is a half-round of radius min(R/2, (R1 - P1)/2) whose outermost point lies at R1/2

#### Scenario: Chamfer
- **WHEN** `beta` and `f` are published and beta is below 90°
- **THEN** the head corner is chamfered from radius R1/2 minus min(f·tan β, R1/4) at the head face to radius R1/2 at height f

### Requirement: Extractor groove and belt
Where E and E1 are published, the drawing SHALL draw the extractor groove at radius E1/2 between heights R and R + eMin, with a ramp to radius P1/2 at height E. For belted cases the groove SHALL end in a ramp at angle δ to the axis up to radius R3/2, follow the belt to height E, then step in to P1/2. Without a groove the rim SHALL step in to P1/2 at height R (or at the rimfire rim height).

#### Scenario: Groove
- **WHEN** E and E1 are published on a rimless case
- **THEN** the outline contains a groove at radius E1/2 between heights R and R + eMin

#### Scenario: Belt
- **WHEN** a belted case is drawn
- **THEN** the outline follows radius R3/2 from the end of the ramp to height E

### Requirement: Body, shoulder and neck
A case without alpha, L1 or L2 SHALL be drawn straight from the body start to radius H2/2 at L3. A bottleneck case SHALL be drawn from the body start to (P2/2, L1), then to (H1/2, L2), then to (H2/2, L3), using the published points. The body-side corner SHALL be rounded with r1Min and the neck-side corner with r2 where those values are published.

#### Scenario: Straight case
- **WHEN** a pistol record has no alpha, L1 or L2
- **THEN** the body runs straight to (H2/2, L3)

#### Scenario: Shoulder corners
- **WHEN** r1Min and r2 are published for a bottleneck case
- **THEN** the body-side corner is an arc of radius r1Min and the neck-side corner an arc of radius r2

### Requirement: Bullet seating depth
The bullet base SHALL sit at zb = L3 - s, where s is 1.0·G1 for pointy bullets, 0.8·G1 for rounded or flat bullets on rifle and rimfire cases, 0.4·G1 for rounded or flat bullets on pistol cases, and 0.6·G1 for semi_wadcutter bullets, with s taken from `annotations.defaultBulletShape` and `annotations.category`.

#### Scenario: Rounded pistol bullet
- **WHEN** `defaultBulletShape` is `rounded` and the category is `pistol`
- **THEN** s equals 0.4·G1 and the base is at L3 - s

#### Scenario: Semi-wadcutter bullet
- **WHEN** `defaultBulletShape` is `semi_wadcutter`
- **THEN** s equals 0.6·G1

### Requirement: Bullet cylinder end
The shank cylinder SHALL run from zb to zb + k·Lb, where Lb = L6 - zb and k is 0.40 for pointy, 0.55 for rounded rifle or rimfire, 0.65 for rounded pistol, 0.60 for flat rifle or rimfire, 0.70 for flat pistol, and 0.78 for semi_wadcutter.

#### Scenario: Pointy bullet cylinder
- **WHEN** `defaultBulletShape` is `pointy`
- **THEN** the cylinder ends at zb + 0.40·Lb

### Requirement: Bullet nose
The nose SHALL run from the cylinder end to a flat tip at z = L6 with meplat diameter m: pointy m = max(0.08·G1, 1.27) as a tangent ogive; rounded m = 0.15·G1 as a quarter ellipse; flat m = 0.55·G1 and semi_wadcutter m = 0.6·G1 as straight cones.

#### Scenario: Pointy nose
- **WHEN** `defaultBulletShape` is `pointy`
- **THEN** the nose is a tangent arc to the cylinder ending at the tip with a flat meplat of diameter max(0.08·G1, 1.27)

#### Scenario: Heeled case
- **WHEN** H2 - G1 is 0.015 or less
- **THEN** the exposed bullet has diameter H2 and the seated heel has diameter H2 - 2·tb inside the case section

#### Scenario: Outside view hides seated bullet
- **WHEN** the bullet is drawn in the outside view
- **THEN** only the part from the mouth to the tip is shown

### Requirement: Section wall thickness
The neck wall SHALL be tn = (H2 - G1)/2. The body wall SHALL be tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The solid head SHALL extend to height w = max(2.5, 0.25·P1/2, primer pocket depth + 1.5, E + tb where a groove exists, belt ramp end + tb on belted cases). Primer pockets on centrefire cases SHALL have diameter 4.45 mm for sp, spm, sr and 5.33 mm for lp, lpm, lr, lrm, and depth 3.04 mm for sp, spm, sr, lp, lpm and 3.30 mm for lr, lrm. Rimfire cases SHALL have no primer pocket.

#### Scenario: Thin neck
- **WHEN** tn is 0.375 and P1/2 is 4.79
- **THEN** tb is 0.6 mm

#### Scenario: Rimfire pocket
- **WHEN** `primerType` is `rimfire`
- **THEN** the section has no primer pocket

### Requirement: Dimensions
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α where those values are published. Each dimension SHALL be labelled with its symbol and value, for example `L3 51.18`, and the label SHALL include the tolerance when one is published.

#### Scenario: Required dimensions
- **WHEN** any record is drawn
- **THEN** dimension labels exist for L3, L6, R1, R and P1

#### Scenario: Optional dimension absent
- **WHEN** a record has no E1
- **THEN** no E1 dimension is drawn

### Requirement: Labels do not overlap
No dimension label SHALL overlap another label, the title block, or the outline (including the mirrored lower half).

#### Scenario: All 25 records
- **WHEN** the layout is computed for each of the 25 records
- **THEN** no two label boxes intersect and no label box intersects an outline segment

### Requirement: Title block and scale
The drawing SHALL include a title block with the cartridge name, the C.I.P. table and revision date, the text "Dimensions in mm", the scale "1:1" and a 10 mm scale bar.

#### Scenario: Title block content
- **WHEN** the drawing of "9 mm Luger" is shown
- **THEN** the title block shows "9 mm Luger", "Dimensions in mm", the table "IV", the revision "2008-09-23" and a scale bar of 10 mm

### Requirement: Missing values
When a value needed by a rule is missing, the drawing SHALL omit the feature that needs it and the detail view SHALL state which value is missing. The drawing SHALL NOT use an invented number.

#### Scenario: Bottleneck without H1
- **WHEN** alpha, L1 and L2 are published but H1 is missing
- **THEN** the drawing omits the shoulder, and the detail view states that H1 is missing
