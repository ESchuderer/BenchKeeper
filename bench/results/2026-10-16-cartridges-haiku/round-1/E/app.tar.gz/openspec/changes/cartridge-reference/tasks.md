# Tasks

## 1. Project scaffold and data

- [x] 1.1 Add `package.json` (private, no dependencies, `"test": "node --test test/*.test.js"`); verify `npm test` runs with zero tests and exits 0.
- [x] 1.2 Write `test/data.test.js` asserting 25 records, unique `key`, names and families as in the brief; verify it fails (no data file yet).
- [x] 1.3 Create `data/cartridges.js` with the 25 JSONL lines verbatim in a template string; verify `npm test` for data passes.

## 2. Formatting and catalog logic

- [x] 2.1 Write `test/format.test.js` for number, angle (number and DMS object), tolerance pairing, symbol override, unit mapping; verify it fails.
- [x] 2.2 Implement `js/format.js` to pass 2.1.
- [x] 2.3 Write `test/catalog.test.js` for search on `name` and `alternativeNames` (`7,62 x 51` finds `308 Win.`), family filter, combined filter, count, key lookup; verify it fails.
- [x] 2.4 Implement `js/catalog.js` (JSONL parse, filter, lookup) to pass 2.3.

## 3. Geometry

- [x] 3.1 Write `test/geometry.test.js` for rim type classification (all 25 records), chamfer point, rimfire half-round, groove and belt points, bullet nose tip at L6 and meplat diameter, wall thickness `tb` and `tn`, head depth `w`, missing-value reporting for a record with H1 removed; verify it fails.
- [x] 3.2 Implement `js/geometry.js` (rim, case outer profile, bullet, inner profile, primer pocket, missing list) to pass 3.1.

## 4. Drawing

- [x] 4.1 Write `test/drawing.test.js`: for all 25 records, no label box intersects another label, the title block or any outline segment (both halves); verify it fails.
- [x] 4.2 Implement `js/drawing.js` (dimension set, greedy label placement, SVG string with hatch pattern, title block, scale bar, viewBox) to pass 4.1.
- [x] 4.3 Verify the drawing in the browser for `223 Rem.` (bottleneck with groove) and `9 mm Luger` (pistol, straight, no groove) and `22 Long Rifle` (heeled rimfire) with the Playwright MCP; screenshots reviewed for overlaps and scale.

## 5. Application shell

- [ ] 5.1 Create `index.html` with script order `data/cartridges.js`, `js/format.js`, `js/catalog.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js`; verify it loads from `file://` without console errors.
- [x] 5.2 Implement `js/app.js`: hash routing, list view (heading, search field labelled "Search", select labelled "Family", "<n> cartridges", name links), detail view (header metadata, water capacity source link, drawing, grouped tables with Symbol/Value/Unit, missing-value note, "Print" button, "All cartridges" link); verify in the browser against the list and detail scenarios of the catalog and detail specs.
- [ ] 5.3 Implement `css/style.css`: light and dark themes, phone layout, print rules (A4 portrait, black on white, hidden controls, two-column tables, source footer); verify with `page.pdf` in Chromium that a detail view prints to one A4 page.

## 6. Verification and review

- [x] 6.1 Run `npm test` and report the result.
- [x] 6.2 Run the Playwright MCP checks for the list, search, family filter, bookmark reload of a detail address, and the unknown-key message; record results.
- [x] 6.3 Run `openspec validate cartridge-reference --strict` and fix reported issues in the artifacts.
- [x] 6.4 Run the `code-reviewer` agent on the diff and fix CRITICAL and HIGH findings.

## Workflow follow-up

- Archive with `openspec-archive-change` on this branch before any pull request is merged (no remote is configured yet).
