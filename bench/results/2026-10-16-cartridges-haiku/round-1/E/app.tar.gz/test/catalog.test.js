const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const catalog = require('../js/catalog.js');

const source = fs.readFileSync(path.join(__dirname, '..', 'data', 'cartridges.js'), 'utf8');
const sandbox = { window: {} };
vm.runInNewContext(source, sandbox);
const records = catalog.parseRecords(sandbox.window.CARTRIDGE_JSONL);

test('parseRecords returns the 25 records', () => {
  assert.equal(records.length, 25);
});

test('search matches the name and alternative names', () => {
  const found = catalog.filterRecords(records, { query: '7,62 x 51', family: 'all' });
  assert.deepEqual(found.map((r) => r.name), ['308 Win.']);
});

test('search is case-insensitive and ignores surrounding spaces', () => {
  const found = catalog.filterRecords(records, { query: '  22 lr ', family: 'all' });
  assert.deepEqual(found.map((r) => r.name), ['22 Long Rifle']);
});

test('an empty query lists every record in source order', () => {
  const found = catalog.filterRecords(records, { query: '', family: 'all' });
  assert.equal(found.length, 25);
  assert.equal(found[0].key, '223_rem');
});

test('family filter lists only that family', () => {
  const found = catalog.filterRecords(records, { query: '', family: 'belted' });
  assert.deepEqual(found.map((r) => r.key), ['300_win_mag', '7_mm_rem_mag']);
});

test('family and search combine', () => {
  const found = catalog.filterRecords(records, { query: '22', family: 'rimfire' });
  assert.deepEqual(found.map((r) => r.key), ['22_long_rifle', '22_win_mag_r_f']);
});

test('a query matching nothing gives an empty list', () => {
  assert.deepEqual(catalog.filterRecords(records, { query: 'zzz', family: 'all' }), []);
});

test('count text uses the brief wording', () => {
  assert.equal(catalog.countText(25), '25 cartridges');
  assert.equal(catalog.countText(0), '0 cartridges');
});

test('findByKey returns the record or undefined', () => {
  assert.equal(catalog.findByKey(records, '17_hmr').name, '17 HMR');
  assert.equal(catalog.findByKey(records, 'nope'), undefined);
});
