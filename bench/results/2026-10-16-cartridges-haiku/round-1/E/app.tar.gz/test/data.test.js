const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'data', 'cartridges.js'), 'utf8');
const sandbox = { window: {} };
vm.runInNewContext(source, sandbox);
const lines = sandbox.window.CARTRIDGE_JSONL.split('\n').filter((line) => line.trim() !== '');
const records = lines.map((line) => JSON.parse(line));

const EXPECTED_FAMILY_COUNTS = { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3 };

test('data file holds 25 records, one JSON object per line', () => {
  assert.equal(lines.length, 25);
  assert.equal(records.length, 25);
});

test('record keys are unique and as published', () => {
  const keys = records.map((record) => record.key);
  assert.equal(new Set(keys).size, 25);
  assert.ok(keys.includes('223_rem'));
  assert.ok(keys.includes('6_5_creedmoor'));
});

test('family counts match the brief', () => {
  const counts = {};
  for (const record of records) {
    counts[record.family] = (counts[record.family] || 0) + 1;
  }
  assert.deepEqual(counts, EXPECTED_FAMILY_COUNTS);
});

test('every record has the sections the drawing and tables use', () => {
  for (const record of records) {
    assert.ok(record.name, `name in ${record.key}`);
    assert.ok(record.cartridge.lengths.L3 > 0, `L3 in ${record.key}`);
    assert.ok(record.chamber, `chamber in ${record.key}`);
  }
});
