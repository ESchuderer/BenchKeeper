const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const catalog = require('../js/catalog.js');
const drawing = require('../js/drawing.js');

const source = fs.readFileSync(path.join(__dirname, '..', 'data', 'cartridges.js'), 'utf8');
const sandbox = { window: {} };
vm.runInNewContext(source, sandbox);
const records = catalog.parseRecords(sandbox.window.CARTRIDGE_JSONL);

function overlaps(a, b, margin = 0) {
  return a.x0 < b.x1 + margin && b.x0 < a.x1 + margin && a.y0 < b.y1 + margin && b.y0 < a.y1 + margin;
}

test('every label is placed, none is left overlapping', () => {
  for (const record of records) {
    const layout = drawing.layoutDrawing(record);
    assert.deepEqual(layout.unplaced, [], `unplaced labels in ${record.key}`);
    const boxes = layout.labels.map((label) => label.box);
    boxes.forEach((box, i) => {
      for (let j = i + 1; j < boxes.length; j += 1) {
        assert.ok(!overlaps(box, boxes[j]), `${record.key}: ${layout.labels[i].text} overlaps ${layout.labels[j].text}`);
      }
      assert.ok(!overlaps(box, layout.titleBox), `${record.key}: ${layout.labels[i].text} overlaps the title block`);
    });
  }
});

test('no label touches the outline or the section outline', () => {
  for (const record of records) {
    const layout = drawing.layoutDrawing(record);
    for (const label of layout.labels) {
      for (const [a, b] of [...layout.outlineSegments, ...layout.lines]) {
        assert.ok(!drawing.segmentHitsBox(a, b, label.box, 0), `${record.key}: ${label.text} touches an outline or dimension line`);
      }
    }
  }
});

test('labels carry symbol and value, with the tolerance next to the value', () => {
  const layout = drawing.layoutDrawing(records.find((r) => r.key === '223_rem'));
  const texts = layout.labels.map((label) => label.text);
  assert.ok(texts.includes('L3 44.7'), `labels: ${texts.join(' | ')}`);
  assert.ok(texts.includes('L1 36.52 -0.2'), `labels: ${texts.join(' | ')}`);
  assert.ok(texts.includes('α 46°'), `labels: ${texts.join(' | ')}`);
});

test('the title block lists name, table and revision date', () => {
  const layout = drawing.layoutDrawing(records.find((r) => r.key === '9_mm_luger'));
  assert.deepEqual(layout.titleLines.slice(0, 2), ['9 mm Luger', 'C.I.P. table IV · revised 2008-09-23']);
  assert.ok(layout.titleLines.includes('Dimensions in mm · Scale 1:1'));
});

test('svg is labelled with the cartridge name and escapes special characters', () => {
  const svg = drawing.drawingSvg(records.find((r) => r.key === '40_s_w'));
  assert.ok(svg.startsWith('<svg'));
  assert.ok(svg.includes('aria-label="40 S.&amp; W. drawing"'));
});
