const test = require('node:test');
const assert = require('node:assert/strict');
const format = require('../js/format.js');

test('numbers are shown as published, without trailing zeros or separators', () => {
  assert.equal(format.formatNumber(4150.0), '4150');
  assert.equal(format.formatNumber(51.18), '51.18');
  assert.equal(format.formatNumber(35.0), '35');
  assert.equal(format.formatNumber(-0.2), '-0.2');
});

test('a value with a tolerance shows the tolerance after the value', () => {
  assert.equal(format.formatValue(39.62, -0.2), '39.62 -0.2');
  assert.equal(format.formatValue(51.18, undefined), '51.18');
});

test('a plain angle is shown with a degree sign', () => {
  assert.equal(format.formatAngle(40), '40°');
  assert.equal(format.formatAngle(0), '0°');
});

test('an angle object is shown as degrees, minutes and seconds', () => {
  assert.equal(format.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.formatAngle({ degrees: 40, minutes: 0, seconds: 0 }), '40°00\'00"');
  assert.equal(format.angleToDegrees({ degrees: 36, minutes: 30, seconds: 0 }), 36.5);
});

test('symbols are the field name except for the listed overrides', () => {
  assert.equal(format.symbolOf('E'), 'E');
  assert.equal(format.symbolOf('eMin'), 'e min');
  assert.equal(format.symbolOf('r1Min'), 'r1 min');
  assert.equal(format.symbolOf('r1Max'), 'r1 max');
  assert.equal(format.symbolOf('alpha'), 'α');
  assert.equal(format.symbolOf('alpha1'), 'α1');
  assert.equal(format.symbolOf('beta'), 'β');
  assert.equal(format.symbolOf('delta'), 'δ');
  assert.equal(format.symbolOf('deltaL'), 'delta L');
  assert.equal(format.symbolOf('L3PlusG'), 'L3 + G');
});

test('units follow the brief: pressures in bar, EE in J, M in g, Q in mm², N and angles without unit', () => {
  assert.equal(format.unitOf('Pmax'), 'bar');
  assert.equal(format.unitOf('PK'), 'bar');
  assert.equal(format.unitOf('PE'), 'bar');
  assert.equal(format.unitOf('EE'), 'J');
  assert.equal(format.unitOf('M'), 'g');
  assert.equal(format.unitOf('Q'), 'mm²');
  assert.equal(format.unitOf('N'), '');
  assert.equal(format.unitOf('alpha'), '');
  assert.equal(format.unitOf('i'), '');
  assert.equal(format.unitOf('L3'), 'mm');
  assert.equal(format.unitOf('G1'), 'mm');
});

test('a section becomes one row per field, tolerances folded into their value', () => {
  const rows = format.sectionRows({
    L1: 39.62,
    L1Tol: -0.2,
    L3: 51.94,
    alpha: { degrees: 40, minutes: 25, seconds: 44 },
    N: 6,
  });
  assert.deepEqual(rows, [
    { field: 'L1', symbol: 'L1', value: '39.62 -0.2', unit: 'mm' },
    { field: 'L3', symbol: 'L3', value: '51.94', unit: 'mm' },
    { field: 'alpha', symbol: 'α', value: '40°25\'44"', unit: '' },
    { field: 'N', symbol: 'N', value: '6', unit: '' },
  ]);
});

test('a tolerance without its value keeps its own row', () => {
  const rows = format.sectionRows({ RTol: -0.25 });
  assert.deepEqual(rows, [{ field: 'RTol', symbol: 'RTol', value: '-0.25', unit: 'mm' }]);
});

test('section titles are readable', () => {
  assert.equal(format.sectionTitle('caseHead'), 'Case head');
  assert.equal(format.sectionTitle('powderChamber'), 'Powder chamber');
  assert.equal(format.sectionTitle('lengths'), 'Lengths');
});
