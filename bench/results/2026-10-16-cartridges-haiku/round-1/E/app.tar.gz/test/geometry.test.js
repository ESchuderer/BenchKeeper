const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const catalog = require('../js/catalog.js');
const geometry = require('../js/geometry.js');

const source = fs.readFileSync(path.join(__dirname, '..', 'data', 'cartridges.js'), 'utf8');
const sandbox = { window: {} };
vm.runInNewContext(source, sandbox);
const records = catalog.parseRecords(sandbox.window.CARTRIDGE_JSONL);
const byKey = (key) => catalog.findByKey(records, key);
const modelOf = (key) => geometry.buildModel(byKey(key));

const near = (a, b, tolerance = 1e-6) => Math.abs(a - b) <= tolerance;
const hasPoint = (points, z, r, tolerance = 1e-3) =>
  points.some((p) => near(p.z, z, tolerance) && near(p.r, r, tolerance));

test('every record is drawable with no missing values', () => {
  for (const record of records) {
    const model = geometry.buildModel(record);
    assert.ok(model.outline, `outline for ${record.key}`);
    assert.deepEqual(model.missing, [], `missing values for ${record.key}`);
  }
});

test('rim type follows family and R1/P1 for all 25 records', () => {
  const expected = {
    '9_3_x_74_r': 'rimmed',
    '7_x_65_r': 'rimmed',
    '357_magnum': 'rimmed',
    '38_special': 'rimmed',
    '44_rem_mag': 'rimmed',
    '300_win_mag': 'belted',
    '7_mm_rem_mag': 'belted',
    '22_long_rifle': 'rimfire',
    '22_win_mag_r_f': 'rimfire',
    '17_hmr': 'rimfire',
    '9_mm_luger': 'rimless',
    '45_auto': 'rimless',
    '40_s_w': 'rimless',
    '9_3_x_62': 'rimless',
  };
  for (const [key, rimType] of Object.entries(expected)) {
    assert.equal(modelOf(key).rimType, rimType, key);
  }
  const rimless = records.filter((r) => modelOf(r.key).rimType === 'rimless');
  assert.equal(rimless.length, 15);
});

test('outline runs from the axis at the head face to the axis at the tip', () => {
  const outline = modelOf('223_rem').outline;
  assert.deepEqual(outline[0], { z: 0, r: 0 });
  const last = outline[outline.length - 1];
  assert.ok(near(last.z, 57.4) && near(last.r, 0), 'tip at L6 on the axis');
});

test('chamfer runs from R1/2 - f·tan(beta) at the head face to R1/2 at height f', () => {
  // 223 Rem.: R1 = 9.6, beta = 35, f = 0.45
  const chamfer = 0.45 * Math.tan((35 * Math.PI) / 180);
  const points = modelOf('223_rem').outline;
  assert.ok(hasPoint(points, 0, 4.8 - chamfer));
  assert.ok(hasPoint(points, 0.45, 4.8));
});

test('rimfire rim is a half-round whose outermost point lies at R1/2', () => {
  // 22 Long Rifle: R = 1.09, R1 = 7.06, P1 = 5.74 => rho = min(0.545, 0.66) = 0.545
  const model = modelOf('22_long_rifle');
  const rho = 0.545;
  assert.ok(hasPoint(model.outline, rho, 7.06 / 2, 2e-3), 'outermost point');
  assert.ok(hasPoint(model.outline, 2 * rho, 7.06 / 2 - rho, 2e-3), 'rim top');
});

test('groove runs at E1/2 between R and R + eMin and ramps to P1/2 at E', () => {
  // 9 mm Luger: R = 1.27, E = 2.98, E1 = 8.79, eMin = 0.9, P1 = 9.93
  const points = modelOf('9_mm_luger').outline;
  assert.ok(hasPoint(points, 1.27, 8.79 / 2));
  assert.ok(hasPoint(points, 1.27 + 0.9, 8.79 / 2));
  assert.ok(hasPoint(points, 2.98, 9.93 / 2));
});

test('belt ramp rises at angle delta to R3/2 and the belt runs to height E', () => {
  // 300 Win. Mag.: R = 1.27, eMin = 0.94, E1 = 12.07, R3 = 13.51, delta = 35, E = 5.59
  const rise = (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  const points = modelOf('300_win_mag').outline;
  assert.ok(hasPoint(points, 1.27 + 0.94 + rise, 13.51 / 2, 2e-3), 'ramp end');
  assert.ok(hasPoint(points, 5.59, 13.51 / 2), 'belt end at E');
});

test('shoulder corners are rounded with r1Min and r2', () => {
  // 223 Rem.: r1Min = 0.64 at (L1, P2/2) = (36.52, 4.5), r2 = 2.54 at (L2, H1/2) = (39.55, 3.215)
  const model = modelOf('223_rem');
  const sharpBodyCorner = hasPoint(model.outline, 36.52, 4.5, 1e-6);
  assert.equal(sharpBodyCorner, false, 'corner replaced by an arc');
  const neckCorner = hasPoint(model.outline, 39.55, 3.215, 1e-6);
  assert.equal(neckCorner, false, 'neck corner replaced by an arc');
});

test('pointy bullet: flat tip of diameter max(0.08·G1, 1.27) at L6', () => {
  // 223 Rem.: G1 = 5.7 => m = 1.27
  const outline = modelOf('223_rem').outline;
  assert.ok(hasPoint(outline, 57.4, 0.635));
});

test('pointy bullet nose starts at the cylinder end zb + 0.40·Lb on the bullet radius', () => {
  // 223 Rem.: s = G1 = 5.7, zb = 39.0, Lb = 18.4, cylinder end = 46.36
  const outline = modelOf('223_rem').outline;
  assert.ok(hasPoint(outline, 46.36, 2.85, 1e-2));
});

test('wall thicknesses: tn = (H2 - G1)/2 and tb = min(max(1.3·tn, 0.6), 0.35·P1/2)', () => {
  const model = modelOf('223_rem');
  // H2 = 6.43, G1 = 5.7 => tn = 0.365; 1.3·tn < 0.6 => tb = 0.6; 0.35·P1/2 = 1.68
  assert.ok(near(model.tn, 0.365, 1e-9));
  assert.equal(model.tb, 0.6);
});

test('solid head depth w is the largest of the rules (primer pocket depth + 1.5 here)', () => {
  // 223 Rem.: pocket depth 3.04 + 1.5 = 4.54 beats 2.5, P1/8 = 1.1975, E + tb = 3.73
  assert.ok(near(modelOf('223_rem').w, 4.54, 1e-9));
});

test('primer pocket: 5.33 mm diameter for lr, 3.3 mm deep', () => {
  const model = modelOf('6_5_creedmoor');
  assert.deepEqual(model.pocket, { radius: 5.33 / 2, depth: 3.3 });
  assert.equal(modelOf('22_long_rifle').pocket, null, 'rimfire has no pocket');
});

test('heeled case: exposed bullet takes the case outside diameter', () => {
  // 22 Long Rifle: H2 = 5.72, G1 = 5.72 => heeled
  const model = modelOf('22_long_rifle');
  assert.equal(model.heeled, true);
  assert.ok(hasPoint(model.outline, 15.57, 2.86, 1e-3));
});

test('a bottleneck record with H1 removed draws the body straight and reports H1', () => {
  const record = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete record.cartridge.collar.H1;
  const model = geometry.buildModel(record);
  assert.ok(model.missing.includes('H1'));
  assert.ok(model.outline, 'the rest of the drawing is still produced');
  assert.equal(model.shoulderDrawn, false);
});

test('roundCorner replaces a corner by a tangent arc between the two segments', () => {
  const arc = geometry.roundCorner({ z: 0, r: 0 }, { z: 10, r: 0 }, { z: 10, r: 10 }, 2);
  assert.ok(near(arc[0].z, 8, 1e-6) && near(arc[0].r, 0, 1e-6), 'start on the first segment');
  const end = arc[arc.length - 1];
  assert.ok(near(end.z, 10, 1e-6) && near(end.r, 2, 1e-6), 'end on the second segment');
});
