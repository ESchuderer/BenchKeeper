# Cartridges · C.I.P. reference

A static reference for 25 C.I.P. cartridges, for reloaders, gunsmiths and engineers. Modelled on the
OpenBallistics cartridge database. Data: OpenBallistics (MIT, commit e83db43), as given in `data/cartridges.jsonl`.

## Use

- Open `index.html` in Chromium (or any browser). No server, no build, no network.
- Or serve the folder with any static file server, for example `npx http-server . -p 8080`.
- Each cartridge has its own address, `index.html#/cartridge/<key>`, which survives a reload and can be bookmarked.
- The detail view has a **Print** button. A printed detail view is one A4 portrait page.

## Files

| Path | Purpose |
| --- | --- |
| `index.html`, `css/style.css` | App shell, screen and print styles (light and dark follow the system) |
| `js/format.js` | Numbers, angles, tolerances, symbols and units |
| `js/catalog.js` | Search, family filter, routes, value tables |
| `js/geometry.js` | Geometry model for the drawing (pure functions) |
| `js/drawing.js` | Inline SVG drawing, dimensions, label placement, title block |
| `js/app.js` | List and detail views, events, print |
| `data/cartridges.jsonl` | The 25 records, verbatim |
| `data/cartridges.js` | Generated from the JSONL (`npm run build:data`) |
| `tests/unit/` | Unit tests (`npm test`) |
| `tests/e2e/run.js` | Browser checks over `file://` and HTTP (`npm run test:e2e`) |
| `SPEC.md`, `tasks/` | Specification, plan and task list |

## Development

- Node.js 22. No runtime dependencies. Dev dependency: `playwright-core`, used only by the browser checks.
- `npm test` runs the unit tests with the Node test runner.
- `npm run test:e2e` needs a Chromium. Either run `npx playwright install chromium`, or set
  `CHROMIUM_PATH` to a Chromium binary.
- `npm run build:data` regenerates `data/cartridges.js` after a change to the JSONL. `npm run check:data` fails if they differ.

## Conventions

- Values are shown as published: decimal point, no thousands separator (`4150`, `51.18`).
- Tolerances are shown next to their value (`39.62 -0.2`), never as rows of their own.
- Angles show as `40°` or `39°59'49"`.
- Drawing: 1 SVG unit = 1 mm. Upper half: outside view. Lower half: section. Head on the left.
