# Spec: C.I.P. Cartridge Reference (static web app)

## Objective

A static, offline reference for 25 C.I.P. cartridges, for reloaders, gunsmiths and engineers. Modelled on the OpenBallistics cartridge database. Two views: a searchable list, and a detail view per cartridge with value tables, a to-scale 2D drawing, and a print layout (one A4 portrait page).

Success = every requirement in the brief is met, verified by automated tests (Node `node:test`) and by a headless-browser check (Playwright Chromium) of the list, detail, drawing, file:// loading, and printing.

## Assumptions (made without asking, per the brief)

1. The 25 records in the brief are the only data. They are embedded verbatim (`data/cartridges.jsonl` is the source; `data/cartridges.js` is generated from it and a test asserts equality).
2. Values display as JS numbers: `4300.0` -> `4300`, `35.0` -> `35`, matching the brief's example `4150 bar`.
3. `Fe` is a length in mm (the brief lists no unit for it and every other field is mm, bar, J, g, mm², count or angle).
4. `grH2O` is shown as "gr H2O" (grains of water); it is not a unit the brief lists.
5. Unit column: mm, bar, J, g, mm²; `—` for counts (`N`) and angles (the angle itself carries `°`).
6. Drawing labels include tolerances (`L1 36.52 -0.2`), same as tables.
7. Routing uses the hash: `index.html#/` (list) and `index.html#/cartridge/<key>` (detail). Hash routing works on `file://` and any static server.
8. Scripts are classic (non-module) scripts, because ES modules do not load over `file://` in Chromium.
9. Data quirk, not changed: `7 mm Rem. Mag.` has `projectile.G2` = 68.61, equal to its `L3PlusG`. Shown as published; flagged in the final report.

## Tech Stack

- Plain HTML, CSS, JavaScript (ES2017+, no build, no runtime dependencies).
- Dev only: Node 22 built-in test runner (`node --test`) for unit tests; `playwright-core` + a Chromium binary for browser checks (dev dependency, not used by the app).

## Commands

- Unit tests: `npm test` (runs `node --test tests/unit/*.test.js`)
- Browser checks: `CHROMIUM_PATH=<chromium> npm run test:e2e` (Playwright against `file://` and a static server)
- Regenerate data module from JSONL: `npm run build:data`
- Serve for manual check: `npx --yes http-server . -p 8080` (optional; the app needs no server)

## Project Structure

```
index.html            app shell (loads CSS and classic scripts)
css/style.css         screen, dark mode, phone layout, print (A4)
js/format.js          number, angle, tolerance, symbol, unit formatting
js/catalog.js         search normalisation, family filter, sections for tables, route parsing
js/geometry.js        pure geometry model: rim type, profile, bullet, walls, notes
js/drawing.js         SVG generation: profile, hatch, dimensions, label placement, title block
js/app.js             rendering of list and detail views, events, print
data/cartridges.jsonl source records (verbatim from the brief)
data/cartridges.js    generated: window-free global `CIP.cartridges` array
scripts/build-data.js regenerates data/cartridges.js from the JSONL
tests/                node:test unit tests and the e2e script
tasks/                plan.md, todo.md
```

Each JS file is an IIFE that attaches to `globalThis.CIP` and also works under `require()` in Node tests.

## Code Style

```js
(function (root) {
  'use strict';
  const format = {};
  format.angle = function (value) { ... };
  root.CIP = root.CIP || {};
  root.CIP.format = format;
})(typeof globalThis !== 'undefined' ? globalThis : this);
```

- Two-space indent, single quotes, semicolons, `const`/`let`, no classes needed.
- Pure functions in `js/` modules; DOM only in `js/app.js`.
- Geometry points are `{ z, r }` (z along the axis from the head face, r radius). SVG x = z, SVG y = axis - r (upper half) or axis + r (lower half).
- Comments only where a rule from the brief is not obvious from the code.

## Testing Strategy

- Unit (node:test), TDD: formatting, symbols, tolerances, search/filter, route parsing, rim classification, profile and bullet geometry, missing-value notes, dimension label collision checks for all 25 records, data equality with JSONL.
- Browser (Playwright, Chromium): list renders 25 links with exact names; search and family filter; detail URL reload and bookmark; SVG accessible name; no network requests (`file://`); print emulation yields one A4 page; dark and light colour schemes.
- Coverage: every pure module function has at least one test; no coverage threshold number is imposed.

## Boundaries

- Always: use the 25 records as given; never invent a number (missing values produce a note, not a guess); no network requests from the app; run tests before reporting done.
- Ask first: adding a runtime dependency; changing any record value; a different data source.
- Never: fetch remote fonts, scripts or data; add a build step to the app; edit records to "fix" data.

## Drawing rules (from the brief, summarised for the test plan)

- Scale 1 SVG unit = 1 mm. Upper half: outside view. Lower half: section with hatched cut walls. Dash-dot centre line.
- Dimensions: L3, L6, R1, R, P1 always when available; P2, H1, H2, G1, L1, L2, E1, alpha when published. Labels `SYM value tol`.
- Title block: name, C.I.P. table, revision date, "Dimensions in mm", scale.
- Labels never overlap each other or the outline (checked by test with approximate text boxes).

## Success Criteria

- [x] List: heading "Cartridges", 25 entries, each link text exactly the record's `name`, family and L3 shown.
- [x] Search `7,62 x 51` lists `308 Win.`; family select (All, rimless, rimmed, belted, pistol, rimfire) filters; "N cartridges" count text updates.
- [x] Detail: heading, alternative names, family, category, primer type, tab, country, published, revised, pressure method, water capacity with source link.
- [x] Detail: cartridge and chamber tables grouped by section, columns Symbol / Value / Unit; no tolerance rows.
- [x] Detail: Print button; "All cartridges" link; bookmarkable hash URL survives reload.
- [x] Drawing: inline SVG, accessible name `<name> drawing`, true scale, head on left, all listed dimensions, title block, notes for missing values.
- [x] Dark and light via `prefers-color-scheme`; print always black on white, one A4 portrait page, footer with C.I.P. TDCC source and revised date.
- [x] Works from `file://` in Chromium and from a static server; zero network requests.

## Open Questions

- None blocking. Assumptions 2–9 above are the ones to confirm.

## Decisions made during the build

- Diameter dimensions (P1, P2, H1, H2, G1, E1) sit in columns beyond the bullet tip, smallest nearest the case. Their labels are stacked at the end of each extension line, joined by a short leader, because labels beside the columns collide with the extension lines of the larger diameters.
- Belt ramp: delta is the angle between the ramp and the axis, so tan(delta) = (radius change) / (axial change).
- Heeled bullet: the exposed diameter is H2 and the seated heel is H2 - 2tb, as the brief states.
- Shoulder angle alpha: an arc at the cone apex inside the cavity, with its ends on the shoulder lines. Labelled with the published value (for example 10°58'00").
- Print: body min-height is not forced in print, and the two value sections print side by side, so one A4 page holds the header, drawing and tables.
