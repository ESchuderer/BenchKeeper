(function (root) {
  'use strict';

  // Rendering and events. Everything else is pure and lives in the other modules.
  const { catalog, format, drawing } = root.CIP;
  const records = root.CIP.cartridges;
  const app = document.getElementById('app');
  const BASE_TITLE = 'Cartridges · C.I.P. reference';

  const esc = (text) => String(text)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const dash = (unit) => (unit === '' ? '—' : esc(unit));

  // ---- List view -------------------------------------------------------------------------

  const listState = { query: '', family: 'all' };

  function rowHtml(record) {
    const l3 = record.cartridge.lengths.L3;
    const tol = record.cartridge.lengths.L3Tol;
    return '<tr>' +
      '<td><a href="#/cartridge/' + esc(record.key) + '">' + esc(record.name) + '</a></td>' +
      '<td>' + esc(record.family) + '</td>' +
      '<td class="num">' + esc(format.withTolerance(format.number(l3), tol)) + ' <span class="unit">mm</span></td>' +
      '</tr>';
  }

  function renderList() {
    app.innerHTML =
      '<h1>Cartridges</h1>' +
      '<div class="toolbar" role="search">' +
        '<label class="field field-search"><span>Search</span>' +
          '<input id="search" type="search" autocomplete="off" spellcheck="false" ' +
          'placeholder="Name or alternative name" value="' + esc(listState.query) + '"></label>' +
        '<label class="field field-family"><span>Family</span><select id="family">' +
          catalog.FAMILIES.map((f) => '<option value="' + f.value + '"' +
            (f.value === listState.family ? ' selected' : '') + '>' + esc(f.label) + '</option>').join('') +
        '</select></label>' +
      '</div>' +
      '<p class="count" id="count" aria-live="polite"></p>' +
      '<table class="cartridge-table">' +
        '<thead><tr><th scope="col">Name</th><th scope="col">Family</th><th scope="col" class="num">L3</th></tr></thead>' +
        '<tbody id="rows"></tbody>' +
      '</table>';
    document.getElementById('search').addEventListener('input', (event) => {
      listState.query = event.target.value;
      refreshList();
    });
    document.getElementById('family').addEventListener('change', (event) => {
      listState.family = event.target.value;
      refreshList();
    });
    refreshList();
  }

  // Only the rows and the count change while typing, so the search field keeps focus.
  function refreshList() {
    const hits = catalog.filter(records, listState);
    document.getElementById('rows').innerHTML = hits.map(rowHtml).join('');
    document.getElementById('count').textContent = catalog.countText(hits.length);
  }

  // ---- Detail view -----------------------------------------------------------------------

  function sectionHtml(title, groups) {
    return '<section class="values-section"><h2>' + esc(title) + '</h2>' +
      groups.map((group) =>
        '<div class="group"><h3>' + esc(group.title) + '</h3>' +
        '<table class="values">' +
          '<thead><tr><th scope="col">Symbol</th><th scope="col" class="num">Value</th><th scope="col">Unit</th></tr></thead>' +
          '<tbody>' + group.rows.map((row) =>
            '<tr><th scope="row">' + esc(row.symbol) + '</th>' +
            '<td class="num">' + esc(row.value) + '</td>' +
            '<td>' + dash(row.unit) + '</td></tr>').join('') +
          '</tbody></table></div>').join('') +
      '</section>';
  }

  function factsHtml(record) {
    const items = [];
    const add = (term, detail) => items.push('<dt>' + esc(term) + '</dt><dd>' + detail + '</dd>');
    if (record.alternativeNames && record.alternativeNames.length) {
      add('Alternative names', record.alternativeNames.map(esc).join(', '));
    }
    add('Family', esc(record.family));
    add('Category', esc(record.annotations.category));
    add('Primer type', esc(record.annotations.primerType));
    add('C.I.P. table', esc(record.tab));
    add('Country', esc(record.country));
    add('Published', esc(record.published));
    add('Revised', esc(record.revised));
    add('Pressure method', esc(record.pressureMethod));
    const water = catalog.waterCapacity(record);
    if (water) {
      const link = '<a href="' + esc(water.url) + '" rel="noopener">' + esc(water.source) + '</a>';
      add('Water capacity', esc(water.text) + (water.note ? ' <span class="note">(' + esc(water.note) + ')</span>' : '') +
        ' · source ' + link);
    }
    return '<dl class="facts">' + items.join('') + '</dl>';
  }

  function drawingHtml(record) {
    const out = drawing.layout(record);
    if (!out.svg) {
      return '<figure class="drawing drawing-unavailable"><p>' + out.notes.map(esc).join(' ') + '</p></figure>';
    }
    return '<figure class="drawing">' + out.svg + '</figure>';
  }

  function renderDetail(record) {
    const sections = catalog.sections(record);
    document.title = record.name + ' · ' + BASE_TITLE;
    app.innerHTML =
      '<nav class="topbar no-print">' +
        '<a class="back" href="#/">All cartridges</a>' +
        '<button type="button" class="print-button" id="print">Print</button>' +
      '</nav>' +
      '<article class="detail">' +
        '<h1 id="title" tabindex="-1">' + esc(record.name) + '</h1>' +
        factsHtml(record) +
        drawingHtml(record) +
        '<div class="value-sections">' +
          sectionHtml('Cartridge', sections.cartridge) +
          sectionHtml('Chamber', sections.chamber) +
        '</div>' +
        '<footer class="source">Source: C.I.P. TDCC, revised ' + esc(record.revised) + '. ' +
          'Data: OpenBallistics (MIT).</footer>' +
      '</article>';
    document.getElementById('print').addEventListener('click', () => root.print());
    document.getElementById('title').focus({ preventScroll: true });
  }

  function renderNotFound(key) {
    document.title = BASE_TITLE;
    app.innerHTML =
      '<nav class="topbar no-print"><a class="back" href="#/">All cartridges</a></nav>' +
      '<h1>Cartridge not found</h1>' +
      '<p>No cartridge has the key <code>' + esc(key) + '</code>.</p>';
  }

  // ---- Routing ---------------------------------------------------------------------------

  function route() {
    const r = catalog.parseRoute(root.location.hash);
    if (r.view === 'detail') {
      const record = catalog.find(records, r.key);
      if (record) return renderDetail(record);
      return renderNotFound(r.key);
    }
    document.title = BASE_TITLE;
    if (!app.querySelector('#rows')) renderList();
    else refreshList();
  }

  root.addEventListener('hashchange', route);
  route();
})(typeof globalThis !== 'undefined' ? globalThis : this);
