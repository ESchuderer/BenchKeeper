(function (root) {
  'use strict';

  const catalog = {};

  // Group titles for the value tables, in the order the record lists them.
  const CARTRIDGE_GROUPS = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
  };
  const CHAMBER_GROUPS = {
    barrel: 'Barrel',
    breech: 'Breech',
    collar: 'Collar',
    grooves: 'Grooves',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    powderChamber: 'Powder chamber',
    rifling: 'Rifling',
  };

  catalog.FAMILIES = [
    { value: 'all', label: 'All' },
    { value: 'rimless', label: 'rimless' },
    { value: 'rimmed', label: 'rimmed' },
    { value: 'belted', label: 'belted' },
    { value: 'pistol', label: 'pistol' },
    { value: 'rimfire', label: 'rimfire' },
  ];

  // Case-insensitive; whitespace collapsed; decimal comma and dot are the same, so "6.5" finds "6,5".
  catalog.normalize = function (text) {
    return String(text).toLowerCase().replace(/,/g, '.').replace(/\s+/g, ' ').trim();
  };

  catalog.matches = function (record, query) {
    const q = catalog.normalize(query);
    if (q === '') return true;
    const names = [record.name].concat(record.alternativeNames || []);
    return names.some((name) => catalog.normalize(name).indexOf(q) !== -1);
  };

  catalog.filter = function (records, options) {
    const family = options.family || 'all';
    return records.filter((record) => {
      if (family !== 'all' && record.family !== family) return false;
      return catalog.matches(record, options.query || '');
    });
  };

  catalog.countText = function (n) {
    return n + (n === 1 ? ' cartridge' : ' cartridges');
  };

  catalog.find = function (records, key) {
    return records.find((record) => record.key === key);
  };

  // Hash routes: #/ is the list, #/cartridge/<key> is a detail view. Anything else is the list.
  catalog.parseRoute = function (hash) {
    const path = String(hash || '').replace(/^#/, '');
    const match = /^\/cartridge\/(.*)$/.exec(path);
    if (match) {
      let key = match[1];
      try {
        key = decodeURIComponent(key);
      } catch (error) {
        // Keep the raw text; it will simply not be found.
      }
      return { view: 'detail', key: key };
    }
    return { view: 'list' };
  };

  function rowsOf(group) {
    const rows = [];
    const keys = Object.keys(group).filter((key) => !/Tol$/.test(key));
    for (const key of keys) {
      const tolKey = key + 'Tol';
      const tolerance = Object.prototype.hasOwnProperty.call(group, tolKey) ? group[tolKey] : undefined;
      rows.push({
        key: key,
        symbol: root.CIP.format.symbol(key),
        value: root.CIP.format.rowText(key, group[key], tolerance),
        unit: root.CIP.format.unit(key),
      });
    }
    return rows;
  }

  // Tables for one record: cartridge and chamber sections, each a list of groups with rows.
  catalog.sections = function (record) {
    const build = (section, titles) => {
      const source = record[section] || {};
      const result = [];
      for (const groupKey of Object.keys(source)) {
        const group = source[groupKey];
        const rows = rowsOf(group);
        if (rows.length === 0) continue;
        result.push({ id: groupKey, title: titles[groupKey] || groupKey, rows: rows });
      }
      return result;
    };
    return {
      cartridge: build('cartridge', CARTRIDGE_GROUPS),
      chamber: build('chamber', CHAMBER_GROUPS),
    };
  };

  catalog.waterCapacity = function (record) {
    const pc = record.annotations.publishedCapacity;
    if (!pc) return null;
    return {
      text: pc.grH2O + ' gr H2O',
      note: pc.note || '',
      source: pc.source,
      url: pc.url,
    };
  };

  root.CIP = root.CIP || {};
  root.CIP.catalog = catalog;
  root.CIP.cartridges = root.CIP.cartridges || [];
})(typeof globalThis !== 'undefined' ? globalThis : this);
