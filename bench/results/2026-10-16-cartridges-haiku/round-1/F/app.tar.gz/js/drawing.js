(function (root) {
  'use strict';

  // SVG drawing of one cartridge. 1 user unit = 1 mm. Head on the left, axis horizontal.
  // Upper half: outside view. Lower half: section with hatched cut walls.
  // SVG y grows downwards: upper half has y = -r, lower half has y = +r.
  const drawing = {};
  const FONT = 3.0;          // dimension labels, mm
  const FONT_TITLE = 2.8;    // title block
  const FONT_NOTE = 2.4;     // notes about values that could not be used
  const ARROW_LEN = 1.6;
  const ARROW_HALF = 0.5;
  const GAP = 0.8;           // extension lines start this far from the feature
  const OVERSHOOT = 1.0;     // and run this far beyond the dimension line
  const COLUMN_STEP = 5.5;   // spacing of diameter dimension lines beyond the tip
  const LABEL_STACK = 3.6;   // minimum baseline spacing of stacked diameter labels
  const LEADER_RUN = 4.5;    // horizontal run of the leader from a diameter line to its label
  const fmt = root.CIP.format;

  const f3 = (x) => (Math.round(x * 1000) / 1000).toString();
  const esc = (text) => String(text)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const hasNum = (x) => typeof x === 'number' && isFinite(x);
  const up = (p) => ({ x: p.z, y: -p.r });
  const down = (p) => ({ x: p.z, y: p.r });

  function pathOf(pts, close) {
    if (pts.length === 0) return '';
    let d = 'M' + f3(pts[0].x) + ' ' + f3(pts[0].y);
    for (let i = 1; i < pts.length; i++) d += ' L' + f3(pts[i].x) + ' ' + f3(pts[i].y);
    return d + (close ? ' Z' : '');
  }

  function segmentsOf(pts) {
    const out = [];
    for (let i = 1; i < pts.length; i++) out.push({ p: pts[i - 1], q: pts[i] });
    return out;
  }

  function boxFor(text, fs, anchor, x, y) {
    const w = text.length * 0.6 * fs;
    const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0: x0, y0: y - 0.75 * fs, x1: x0 + w, y1: y + 0.22 * fs };
  }

  function boxesOverlap(a, b) {
    return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
  }

  function segmentHitsBox(s, box, pad) {
    const len = Math.hypot(s.q.x - s.p.x, s.q.y - s.p.y);
    const steps = Math.max(1, Math.ceil(len / 0.2));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = s.p.x + (s.q.x - s.p.x) * t;
      const y = s.p.y + (s.q.y - s.p.y) * t;
      if (x >= box.x0 - pad && x <= box.x1 + pad && y >= box.y0 - pad && y <= box.y1 + pad) return true;
    }
    return false;
  }

  // Arrowheads at both ends of a straight dimension line; the tips sit on the extension lines.
  function arrowsAlong(a, b) {
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    const ux = (b.x - a.x) / len;
    const uy = (b.y - a.y) / len;
    const nx = -uy;
    const ny = ux;
    const head = (tip, dx, dy) => {
      const bx = tip.x + dx * ARROW_LEN;
      const by = tip.y + dy * ARROW_LEN;
      return 'M' + f3(tip.x) + ' ' + f3(tip.y) + ' L' + f3(bx + nx * ARROW_HALF) + ' ' + f3(by + ny * ARROW_HALF) +
        ' L' + f3(bx - nx * ARROW_HALF) + ' ' + f3(by - ny * ARROW_HALF) + ' Z';
    };
    return head(a, ux, uy) + ' ' + head(b, -ux, -uy);
  }

  // Extension line for a horizontal dimension at height yDim, from a feature at (xF, yF).
  function extensionForHorizontal(xF, yF, yDim) {
    const s = Math.sign(yDim - yF) || 1;
    return { p: { x: xF, y: yF + s * GAP }, q: { x: xF, y: yDim + s * OVERSHOOT } };
  }

  // Extension line for a vertical dimension at x = xDim, from a feature at (xF, yF).
  function extensionForVertical(xF, yF, xDim) {
    const s = Math.sign(xDim - xF) || 1;
    return { p: { x: xF + s * GAP, y: yF }, q: { x: xDim + s * OVERSHOOT, y: yF } };
  }

  function horizontalDim(id, text, xa, xb, yDim, featureA, featureB) {
    const line = { p: { x: xa, y: yDim }, q: { x: xb, y: yDim } };
    const mid = (xa + xb) / 2;
    const left = Math.min(xa, xb);
    const right = Math.max(xa, xb);
    const above = yDim - 1.0;
    const below = yDim + 1.0 + 0.75 * FONT;
    const side = yDim + 0.22 * FONT;
    return {
      id: id, text: text, fs: FONT,
      cands: [
        { anchor: 'middle', x: mid, y: above }, { anchor: 'middle', x: mid, y: below },
        { anchor: 'start', x: right + 1.0, y: side }, { anchor: 'end', x: left - 1.0, y: side },
        { anchor: 'start', x: left + 1.0, y: above }, { anchor: 'end', x: right - 1.0, y: above },
        { anchor: 'start', x: left + 1.0, y: below }, { anchor: 'end', x: right - 1.0, y: below },
      ],
      segments: [line, extensionForHorizontal(featureA.x, featureA.y, yDim),
        extensionForHorizontal(featureB.x, featureB.y, yDim)],
      arrows: arrowsAlong(line.p, line.q),
    };
  }

  function verticalDim(id, text, xDim, yTop, yBottom, featureTop, featureBottom) {
    const line = { p: { x: xDim, y: yTop }, q: { x: xDim, y: yBottom } };
    const mid = (yTop + yBottom) / 2;
    return {
      id: id, text: text, fs: FONT,
      cands: [
        { anchor: 'start', x: xDim + 1.0, y: mid + 0.22 * FONT },
        { anchor: 'end', x: xDim - 1.0, y: mid + 0.22 * FONT },
        { anchor: 'middle', x: xDim, y: yTop - 1.0 },
        { anchor: 'middle', x: xDim, y: yBottom + 1.0 + 0.75 * FONT },
      ],
      segments: [line, extensionForVertical(featureTop.x, featureTop.y, xDim),
        extensionForVertical(featureBottom.x, featureBottom.y, xDim)],
      arrows: arrowsAlong(line.p, line.q),
    };
  }

  function valueText(value, tol) {
    const text = fmt.number(value);
    return tol === undefined ? text : fmt.withTolerance(text, tol);
  }

  function labelOf(symbol, value, tol) {
    return symbol + ' ' + valueText(value, tol);
  }

  drawing.layout = function (record) {
    const model = root.CIP.geometry.buildModel(record);
    if (!model.ok) {
      return { svg: null, notes: model.notes, labels: [], obstacles: [], warnings: [], bounds: null, model: model };
    }
    const v = model.values;
    const tol = v.tol;
    const up2 = model.upper.map(up);
    const low2 = model.upper.map(down);
    const innerLow = model.inner.map(down);
    const bulletLow = model.bullet ? model.bullet.profile.map(down) : [];
    const pocketLow = model.pocket ? [
      down({ z: 0, r: model.pocket.diameter / 2 }),
      down({ z: model.pocket.depth, r: model.pocket.diameter / 2 }),
      down({ z: model.pocket.depth, r: 0 }),
    ] : [];
    const fixed = [up2, low2, innerLow];
    if (bulletLow.length) fixed.push(bulletLow);
    if (pocketLow.length) fixed.push(pocketLow);

    const Rout = Math.max.apply(null, model.upper.map((p) => p.r));
    const yTop = -(Rout + 5);
    const rowY = (i) => Rout + 5 + 4.5 * i;
    const tipR = model.bullet ? model.bullet.profile[model.bullet.profile.length - 1].r : 0;
    const dims = [];

    // Overall length, measured above the case from the head face to the tip.
    if (model.bullet) {
      dims.push(horizontalDim('L6', labelOf('L6', v.L6), 0, v.L6, yTop,
        { x: 0, y: -v.R1 / 2 }, { x: v.L6, y: -tipR }));
    }

    // Head diameter, left of the head face.
    const xR1 = -4.5;
    dims.push(verticalDim('R1', labelOf('R1', v.R1), xR1, -v.R1 / 2, v.R1 / 2,
      { x: 0, y: -v.R1 / 2 }, { x: 0, y: v.R1 / 2 }));

    // Lengths and the rim thickness, below the case; shortest span nearest the drawing.
    const rows = [{ id: 'R', symbol: 'R', value: v.R, tol: tol.R, z: v.R, feature: v.R1 / 2 }];
    if (model.shoulder) {
      rows.push({ id: 'L1', symbol: 'L1', value: model.shoulder.L1, tol: tol.L1, z: model.shoulder.L1,
        feature: model.shoulder.P2 / 2 });
      rows.push({ id: 'L2', symbol: 'L2', value: model.shoulder.L2, tol: tol.L2, z: model.shoulder.L2,
        feature: model.shoulder.H1 / 2 });
    }
    rows.push({ id: 'L3', symbol: 'L3', value: v.L3, tol: tol.L3, z: v.L3, feature: v.H2 / 2 });
    rows.sort((a, b) => a.z - b.z);
    rows.forEach((row, i) => {
      const yRow = rowY(i);
      dims.push(horizontalDim(row.id, labelOf(row.symbol, row.value, row.tol), 0, row.z, yRow,
        { x: 0, y: v.R1 / 2 }, { x: row.z, y: row.feature }));
    });

    // Diameters: one dimension line per diameter, smallest nearest the case.
    const diameters = [{ id: 'P1', symbol: 'P1', value: v.P1, d: v.P1, z: model.body.z, r: v.P1 / 2 }];
    if (model.shoulder) {
      diameters.push({ id: 'P2', symbol: 'P2', value: v.P2, tol: tol.P2, d: v.P2, z: model.shoulder.L1, r: v.P2 / 2 });
      diameters.push({ id: 'H1', symbol: 'H1', value: v.H1, d: v.H1, z: model.shoulder.L2, r: v.H1 / 2 });
    }
    diameters.push({ id: 'H2', symbol: 'H2', value: v.H2, d: v.H2, z: v.L3, r: v.H2 / 2 });
    if (model.bullet) {
      diameters.push({ id: 'G1', symbol: 'G1', value: v.G1, d: v.G1, z: model.bullet.zc, r: model.bullet.G / 2 });
    }
    if (model.groove) {
      const zf = v.R + (hasNum(v.eMin) ? v.eMin / 2 : 0);
      diameters.push({ id: 'E1', symbol: 'E1', value: v.E1, d: v.E1, z: zf, r: v.E1 / 2 });
    }
    diameters.sort((a, b) => a.d - b.d);
    const columnBase = (model.bullet ? v.L6 : v.L3) + 5;
    const columnLast = columnBase + COLUMN_STEP * (diameters.length - 1);
    const xLabel = columnLast + 2.5;
    const diameterLabels = [];
    diameters.forEach((dm, i) => {
      const xc = columnBase + COLUMN_STEP * i;
      const half = dm.d / 2;
      const line = { p: { x: xc, y: -half }, q: { x: xc, y: half } };
      const upperExt = extensionForVertical(dm.z, -dm.r, xLabel);
      const lowerExt = extensionForVertical(dm.z, dm.r, xc);
      dims.push({
        id: dm.id, text: labelOf(dm.symbol, dm.value, dm.tol), fs: FONT, cands: [],
        segments: [line, upperExt, lowerExt],
        arrows: arrowsAlong(line.p, line.q),
        fixed: true,
      });
      diameterLabels.push({ dim: dims[dims.length - 1], y: -half });
    });

    // Shoulder angle: an arc at the cone apex with its ends on the two shoulder lines.
    if (model.shoulder) {
      const sh = model.shoulder;
      const half = fmt.angleDegrees(sh.alpha) * Math.PI / 360;
      const start = { z: sh.L1, r: sh.P2 / 2 };
      const rho = 0.5 * Math.hypot(start.z - sh.apexZ, start.r);
      const arc = [];
      for (let i = 0; i <= 12; i++) {
        const th = -half + 2 * half * i / 12;
        arc.push({ x: sh.apexZ + rho * Math.cos(th), y: rho * Math.sin(th) });
      }
      const mid = arc[6];
      dims.push({
        id: 'alpha', text: 'α ' + fmt.angle(sh.alphaPublished), fs: FONT,
        cands: [
          { anchor: 'start', x: mid.x + 1.0, y: mid.y - 1.0 },
          { anchor: 'start', x: mid.x + 1.0, y: mid.y + 1.0 + 0.75 * FONT },
          { anchor: 'middle', x: mid.x, y: -(Rout + 1) },
          { anchor: 'end', x: mid.x - 1.0, y: mid.y - 1.0 },
        ],
        segments: [{ pts: arc }, { p: { x: sh.apexZ, y: 0 }, q: arc[0] }, { p: { x: sh.apexZ, y: 0 }, q: arc[arc.length - 1] }],
        arrows: arrowsAlong(arc[0], arc[1]) + ' ' + arrowsAlong(arc[arc.length - 1], arc[arc.length - 2]),
      });
    }

    // Centre line: from just behind the head face to just beyond the tip.
    const centre = { p: { x: -1, y: 0 }, q: { x: (model.bullet ? v.L6 : v.L3) + 2, y: 0 } };

    // Everything a label must avoid.
    const lines = [];
    for (const poly of fixed) lines.push(...segmentsOf(poly));
    lines.push(centre);
    for (const dim of dims) {
      for (const seg of dim.segments) {
        if (seg.pts) lines.push(...segmentsOf(seg.pts));
        else lines.push(seg);
      }
    }

    // Labels for the dimensions with candidate positions: take the first candidate that touches
    // no placed label and no line. Diameter labels are stacked at the end of their extension lines.
    const placed = [];
    const warnings = [];
    const labels = [];
    for (const dim of dims) {
      if (dim.fixed) continue;
      let chosen = null;
      for (const c of dim.cands) {
        const box = boxFor(dim.text, dim.fs, c.anchor, c.x, c.y);
        if (placed.some((b) => boxesOverlap(b, box))) continue;
        if (lines.some((s) => segmentHitsBox(s, box, 0.15))) continue;
        chosen = { c: c, box: box };
        break;
      }
      if (!chosen) {
        warnings.push(dim.text);
        const c = dim.cands[0];
        chosen = { c: c, box: boxFor(dim.text, dim.fs, c.anchor, c.x, c.y) };
      }
      placed.push(chosen.box);
      labels.push({ id: dim.id, text: dim.text, anchor: chosen.c.anchor, x: chosen.c.x, y: chosen.c.y,
        fs: dim.fs, box: chosen.box, arrows: dim.arrows, segments: dim.segments });
    }
    // Stacked labels keep the order of their extension lines; each is joined to its line by a leader.
    diameterLabels.sort((a, b) => a.y - b.y);
    let stackedBaseline = -Infinity;
    for (const dl of diameterLabels) {
      const baseline = Math.max(dl.y + 0.27 * FONT, stackedBaseline + LABEL_STACK);
      stackedBaseline = baseline;
      const x = xLabel + LEADER_RUN;
      const box = boxFor(dl.dim.text, FONT, 'start', x, baseline);
      placed.push(box);
      labels.push({ id: dl.dim.id, text: dl.dim.text, anchor: 'start', x: x, y: baseline,
        fs: FONT, box: box, arrows: dl.dim.arrows,
        segments: dl.dim.segments.concat([{ p: { x: xLabel, y: dl.y }, q: { x: x - 0.5, y: baseline - 0.27 * FONT } }]) });
    }

    // Bounds from geometry, dimensions and labels.
    const xs = [];
    const ys = [];
    for (const poly of fixed) for (const p of poly) { xs.push(p.x); ys.push(p.y); }
    for (const s of lines) { xs.push(s.p.x, s.q.x); ys.push(s.p.y, s.q.y); }
    for (const l of labels) { xs.push(l.box.x0, l.box.x1); ys.push(l.box.y0, l.box.y1); }
    const bx0 = Math.min.apply(null, xs);
    const maxY = Math.max.apply(null, ys);
    const minY = Math.min.apply(null, ys);
    const tbWidth = Math.max(Math.max.apply(null, xs) - bx0, 84);

    // Title block under everything, then notes, both full width.
    const tbTop = maxY + 3;
    const tbHeight = 15;
    const notes = model.notes.slice();
    const noteTop = tbTop + tbHeight + 2.5;
    const noteLines = notes.map((n, i) => ({ text: n, y: noteTop + 3.2 * i }));
    const bottom = noteLines.length ? noteLines[noteLines.length - 1].y + 1 : tbTop + tbHeight;
    const bounds = { x0: bx0 - 1.5, y0: minY - 1.5, x1: bx0 + tbWidth + 1.5, y1: bottom + 1.5 };

    // SVG output.
    const hatchId = 'cip-hatch-' + String(record.key).replace(/[^a-z0-9]/gi, '');
    const parts = [];
    parts.push('<svg xmlns="http://www.w3.org/2000/svg" class="cip-drawing" role="img" aria-label="' + esc(record.name) +
      ' drawing" viewBox="' + f3(bounds.x0) + ' ' + f3(bounds.y0) + ' ' + f3(bounds.x1 - bounds.x0) + ' ' +
      f3(bounds.y1 - bounds.y0) + '" width="' + f3(bounds.x1 - bounds.x0) + 'mm" height="' + f3(bounds.y1 - bounds.y0) + 'mm">');
    parts.push('<title>' + esc(record.name) + ' drawing</title>');
    parts.push('<defs><pattern id="' + hatchId + '" patternUnits="userSpaceOnUse" width="1.4" height="1.4" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="1.4" stroke="currentColor" stroke-width="0.14"/></pattern></defs>');
    parts.push('<path class="centre-line" d="' + pathOf([centre.p, centre.q], false) +
      '" fill="none" stroke="currentColor" stroke-width="0.18" stroke-dasharray="8 1.2 1.2 1.2"/>');
    // Section: case wall with the primer pocket as a hole (evenodd), and the bullet.
    const pocketPath = model.pocket ? ' ' + pathOf(model.pocketPoly.map(down), true) : '';
    parts.push('<path class="section" fill="url(#' + hatchId + ')" fill-rule="evenodd" d="' +
      pathOf(model.solidPoly.map(down), true) + pocketPath + '"/>');
    if (model.bullet) {
      parts.push('<path class="section" fill="url(#' + hatchId + ')" d="' + pathOf(model.bulletPoly.map(down), true) + '"/>');
    }
    // Outside view (upper half) and section boundaries (lower half).
    parts.push('<path class="outline" fill="none" stroke="currentColor" stroke-width="0.45" d="' + pathOf(up2, false) + '"/>');
    parts.push('<path class="outline" fill="none" stroke="currentColor" stroke-width="0.45" d="' + pathOf(low2, false) + '"/>');
    parts.push('<path class="inner" fill="none" stroke="currentColor" stroke-width="0.3" d="' + pathOf(innerLow, false) + '"/>');
    if (bulletLow.length) {
      parts.push('<path class="bullet-outline" fill="none" stroke="currentColor" stroke-width="0.3" d="' + pathOf(bulletLow, false) + '"/>');
    }
    if (pocketLow.length) {
      parts.push('<path class="pocket" fill="none" stroke="currentColor" stroke-width="0.3" d="' + pathOf(pocketLow, false) + '"/>');
    }

    // Dimension lines, extension lines and arrowheads.
    parts.push('<g class="dimensions" fill="none" stroke="currentColor" stroke-width="0.22">');
    for (const l of labels) {
      for (const seg of l.segments) {
        if (seg.pts) parts.push('<path class="extension" d="' + pathOf(seg.pts, false) + '"/>');
        else parts.push('<path class="dimension-line" d="M' + f3(seg.p.x) + ' ' + f3(seg.p.y) + ' L' + f3(seg.q.x) + ' ' + f3(seg.q.y) + '"/>');
      }
      parts.push('<path class="arrow" fill="currentColor" stroke="none" d="' + l.arrows + '"/>');
    }
    parts.push('</g>');
    for (const l of labels) {
      parts.push('<text class="dim-label" x="' + f3(l.x) + '" y="' + f3(l.y) + '" font-size="' + f3(l.fs) +
        '" text-anchor="' + l.anchor + '" data-dim="' + esc(l.id) + '">' + esc(l.text) + '</text>');
    }

    // Title block.
    parts.push('<g class="title-block">');
    parts.push('<rect x="' + f3(bx0) + '" y="' + f3(tbTop) + '" width="' + f3(tbWidth) + '" height="' + f3(tbHeight) +
      '" fill="none" stroke="currentColor" stroke-width="0.25"/>');
    parts.push('<text x="' + f3(bx0 + 1.5) + '" y="' + f3(tbTop + 4.6) + '" font-size="3.6" font-weight="700">' + esc(record.name) + '</text>');
    parts.push('<text x="' + f3(bx0 + 1.5) + '" y="' + f3(tbTop + 8.6) + '" font-size="' + f3(FONT_TITLE) + '">C.I.P. table ' +
      esc(record.tab) + ' · Revised ' + esc(record.revised) + '</text>');
    parts.push('<text x="' + f3(bx0 + 1.5) + '" y="' + f3(tbTop + 12.4) + '" font-size="' + f3(FONT_TITLE) + '">Dimensions in mm · Scale 1:1</text>');
    parts.push('</g>');
    if (noteLines.length) {
      parts.push('<g class="drawing-missing">');
      for (const n of noteLines) {
        parts.push('<text x="' + f3(bx0 + 1.5) + '" y="' + f3(n.y) + '" font-size="' + f3(FONT_NOTE) + '">' + esc(n.text) + '</text>');
      }
      parts.push('</g>');
    }
    parts.push('</svg>');

    return {
      svg: parts.join('\n'),
      notes: notes,
      labels: labels.map((l) => ({ id: l.id, text: l.text, box: l.box })),
      obstacles: fixed,
      warnings: warnings,
      bounds: bounds,
      model: model,
    };
  };

  drawing.render = function (record) {
    return drawing.layout(record).svg;
  };

  root.CIP = root.CIP || {};
  root.CIP.drawing = drawing;
})(typeof globalThis !== 'undefined' ? globalThis : this);
