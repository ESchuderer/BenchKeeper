(function (root) {
  'use strict';

  // Value, symbol, unit and angle formatting for the cartridge tables and drawing labels.
  const ANGLE_KEYS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };
  const UNITS = {
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: '',
  };

  const format = {};

  // Numbers as published: decimal point, no thousands separator, no trailing zeros.
  format.number = function (value) {
    return String(Number(value));
  };

  function pad2(value) {
    const text = String(value);
    return text.length < 2 ? '0' + text : text;
  }

  // A number of degrees is shown as 40°; {degrees, minutes, seconds} as 39°59'49".
  format.angle = function (value) {
    if (typeof value === 'number') return format.number(value) + '°';
    return format.number(value.degrees) + '°' + pad2(value.minutes) + "'" + pad2(value.seconds) + '"';
  };

  // Decimal degrees of an angle given either way.
  format.angleDegrees = function (value) {
    if (value === undefined || value === null) return undefined;
    if (typeof value === 'number') return value;
    return value.degrees + value.minutes / 60 + value.seconds / 3600;
  };

  format.withTolerance = function (text, tolerance) {
    if (tolerance === undefined || tolerance === null) return text;
    const sign = tolerance > 0 ? '+' : '';
    return text + ' ' + sign + format.number(tolerance);
  };

  format.symbol = function (key) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, key) ? SYMBOLS[key] : key;
  };

  format.isAngle = function (key) {
    return ANGLE_KEYS.indexOf(key) !== -1;
  };

  format.unit = function (key) {
    if (format.isAngle(key)) return '';
    return Object.prototype.hasOwnProperty.call(UNITS, key) ? UNITS[key] : 'mm';
  };

  // The value text of one field, tolerance included, without its unit.
  format.rowText = function (key, value, tolerance) {
    const text = format.isAngle(key) ? format.angle(value) : format.number(value);
    return format.withTolerance(text, tolerance);
  };

  root.CIP = root.CIP || {};
  root.CIP.format = format;
})(typeof globalThis !== 'undefined' ? globalThis : this);
