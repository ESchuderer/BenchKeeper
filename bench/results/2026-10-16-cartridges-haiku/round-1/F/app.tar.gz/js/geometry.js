(function (root) {
  'use strict';

  // Pure geometry model for the cartridge drawing. Points are {z, r}: z runs along the axis
  // from the head face (z = 0) to the mouth, r is the radius. Units: mm.
  const geometry = {};
  const TAU = Math.PI * 2;

  const CORE = ['L3', 'P1', 'R1', 'R', 'H2'];
  const PRIMERS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 },
  };

  const hasNum = (x) => typeof x === 'number' && isFinite(x);
  const rad = (deg) => deg * Math.PI / 180;
  const dist = (a, b) => Math.hypot(a.z - b.z, a.r - b.r);

  geometry.rimType = function (record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    const ch = record.cartridge.caseHead || {};
    const pc = record.cartridge.powderChamber || {};
    if (!hasNum(ch.R1) || !hasNum(pc.P1)) return 'unknown';
    const ratio = ch.R1 / pc.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  };

  // Rounds the corner at p between the segments a-p and p-b with a fillet of the given radius.
  // Returns the points that replace p (tangent point, arc samples, tangent point).
  function fillet(a, p, b, radius) {
    const l1 = dist(a, p);
    const l2 = dist(p, b);
    if (!(radius > 0) || l1 === 0 || l2 === 0) return [p];
    const d1 = { z: (p.z - a.z) / l1, r: (p.r - a.r) / l1 };
    const d2 = { z: (b.z - p.z) / l2, r: (b.r - p.r) / l2 };
    const dot = Math.max(-1, Math.min(1, d1.z * d2.z + d1.r * d2.r));
    const turn = Math.acos(dot);
    if (turn < 1e-9) return [p];
    let t = radius * Math.tan(turn / 2);
    const tMax = 0.5 * Math.min(l1, l2);
    let rad2 = radius;
    if (t > tMax) {
      t = tMax;
      rad2 = t / Math.tan(turn / 2);
    }
    const p1 = { z: p.z - d1.z * t, r: p.r - d1.r * t };
    const p2 = { z: p.z + d2.z * t, r: p.r + d2.r * t };
    const cross = d1.z * d2.r - d1.r * d2.z;
    const side = cross >= 0 ? 1 : -1;
    const c = { z: p1.z - d1.r * side * rad2, r: p1.r + d1.z * side * rad2 };
    const a1 = Math.atan2(p1.r - c.r, p1.z - c.z);
    const a2 = Math.atan2(p2.r - c.r, p2.z - c.z);
    let sweep = a2 - a1;
    while (sweep > Math.PI) sweep -= TAU;
    while (sweep <= -Math.PI) sweep += TAU;
    const out = [];
    const steps = 12;
    for (let i = 0; i <= steps; i++) {
      const ang = a1 + sweep * i / steps;
      out.push({ z: c.z + rad2 * Math.cos(ang), r: c.r + rad2 * Math.sin(ang) });
    }
    return out;
  }

  function roundCorners(points) {
    const out = [];
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      if (p.fillet > 0 && i > 0 && i < points.length - 1) {
        const arc = fillet(points[i - 1], p, points[i + 1], p.fillet);
        for (const q of arc) out.push(q);
      } else {
        out.push({ z: p.z, r: p.r });
      }
    }
    return out;
  }

  // Radius of the outer profile at axial position z (profile is non-decreasing in z).
  function radiusAt(profile, z) {
    for (let i = 1; i < profile.length; i++) {
      const a = profile[i - 1];
      const b = profile[i];
      if (z >= a.z && z <= b.z && b.z - a.z > 1e-12) {
        return a.r + (b.r - a.r) * (z - a.z) / (b.z - a.z);
      }
    }
    return profile[profile.length - 1].r;
  }

  // Part of a polyline at or beyond zMin, starting with the interpolated point at zMin.
  function clipFrom(points, zMin) {
    const out = [];
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      if (p.z < zMin - 1e-9) continue;
      if (out.length === 0 && i > 0 && points[i - 1].z < zMin - 1e-9 && p.z - points[i - 1].z > 1e-12) {
        const a = points[i - 1];
        const t = (zMin - a.z) / (p.z - a.z);
        out.push({ z: zMin, r: a.r + (p.r - a.r) * t });
      }
      out.push(p);
    }
    return out;
  }

  function bulletParameters(shape, category, G) {
    const pistol = category === 'pistol';
    switch (shape) {
      case 'pointy':
        return { s: G, k: 0.40, m: Math.max(0.08 * G, 1.27) };
      case 'rounded':
        return { s: (pistol ? 0.4 : 0.8) * G, k: pistol ? 0.65 : 0.55, m: 0.15 * G };
      case 'flat':
        return { s: (pistol ? 0.4 : 0.8) * G, k: pistol ? 0.70 : 0.60, m: 0.55 * G };
      case 'semi_wadcutter':
        return { s: 0.6 * G, k: 0.78, m: 0.6 * G };
      default:
        return null;
    }
  }

  geometry.buildModel = function (record) {
    const notes = [];
    const missing = [];
    const cart = record.cartridge || {};
    const ann = record.annotations || {};
    const ch = cart.caseHead || {};
    const col = cart.collar || {};
    const jc = cart.junctionCone || {};
    const len = cart.lengths || {};
    const pc = cart.powderChamber || {};
    const pr = cart.projectile || {};
    const values = {
      L1: len.L1, L2: len.L2, L3: len.L3, L6: len.L6,
      R1: ch.R1, R: ch.R, E: ch.E, E1: ch.E1, eMin: ch.eMin, beta: ch.beta, f: ch.f, R3: ch.R3,
      delta: ch.delta === undefined ? undefined : root.CIP.format.angleDegrees(ch.delta),
      P1: pc.P1, P2: pc.P2, H1: col.H1, H2: col.H2, G1: pr.G1,
      alpha: jc.alpha === undefined ? undefined : root.CIP.format.angleDegrees(jc.alpha),
      r1Min: jc.r1Min, r2: jc.r2,
      tol: { L1: len.L1Tol, L2: len.L2Tol, L3: len.L3Tol, P2: pc.P2Tol, R: ch.RTol, E: ch.ETol },
    };
    const rimType = geometry.rimType(record);
    const base = { name: record.name, rimType: rimType, values: values, notes: notes, missing: missing };

    for (const key of CORE) {
      if (!hasNum(values[key])) missing.push(key);
    }
    if (missing.length > 0) {
      notes.push('Drawing not available: ' + missing.map((k) => 'value ' + k + ' is not published').join('; ') + '.');
      return Object.assign(base, { ok: false, outer: [], upper: [], bullet: null, inner: [], solidPoly: [],
        bulletPoly: [], pocketPoly: [], pocket: null, rim: null, groove: null, belt: null, shoulder: null,
        walls: null, w: null, body: null });
    }

    const { L3, P1, R1, R, H2 } = values;
    const family = record.family;
    const pts = [{ z: 0, r: 0 }];

    // Head face and rim edge.
    let rim = null;
    if (family === 'rimfire') {
      const rho = Math.max(0, Math.min(R / 2, (R1 - P1) / 2));
      const rb = R1 / 2 - rho;
      rim = { rho: rho, rb: rb };
      const steps = 16;
      for (let i = 0; i <= steps; i++) {
        const theta = Math.PI - Math.PI * i / steps;
        pts.push({ z: rho + rho * Math.cos(theta), r: rb + rho * Math.sin(theta) });
      }
      if (R > 2 * rho + 1e-9) pts.push({ z: R, r: rb });
    } else {
      if (hasNum(values.beta) && hasNum(values.f) && values.beta < 90) {
        const c = Math.min(values.f * Math.tan(rad(values.beta)), R1 / 4);
        pts.push({ z: 0, r: R1 / 2 - c });
        pts.push({ z: values.f, r: R1 / 2 });
      } else {
        pts.push({ z: 0, r: R1 / 2 });
      }
      pts.push({ z: R, r: R1 / 2 });
    }

    // Extractor groove, belt, or a plain step to the body.
    let groove = null;
    let belt = null;
    let bodyZ;
    const hasGroove = hasNum(values.E) && hasNum(values.E1);
    const E = values.E;
    if (hasGroove) {
      groove = { E: E, E1: values.E1, eMin: values.eMin };
      pts.push({ z: R, r: values.E1 / 2 });
      let floorEnd = R;
      if (hasNum(values.eMin)) {
        floorEnd = R + values.eMin;
      } else {
        notes.push('Value eMin is not published: groove floor not drawn.');
      }
      const beltWanted = family === 'belted';
      const beltOk = beltWanted && hasNum(values.R3) && hasNum(values.delta) && values.delta > 0;
      if (beltWanted && !beltOk) {
        const lacking = [!hasNum(values.R3) && 'R3', !hasNum(values.delta) && 'delta'].filter(Boolean);
        notes.push('Value ' + lacking.join(' and ') + ' not published: belt not drawn, plain groove used.');
      }
      if (beltOk) {
        const rampEnd = floorEnd + (values.R3 / 2 - values.E1 / 2) / Math.tan(rad(values.delta));
        const beltEnd = Math.max(E, rampEnd);
        belt = { rampEnd: rampEnd, beltEnd: beltEnd, R3: values.R3, delta: values.delta };
        pts.push({ z: floorEnd, r: values.E1 / 2 });
        pts.push({ z: rampEnd, r: values.R3 / 2 });
        pts.push({ z: beltEnd, r: values.R3 / 2 });
        pts.push({ z: beltEnd, r: P1 / 2 });
        bodyZ = beltEnd;
      } else {
        pts.push({ z: floorEnd, r: values.E1 / 2 });
        pts.push({ z: E, r: P1 / 2 });
        bodyZ = E;
      }
    } else {
      if (family === 'belted') notes.push('Values E and E1 not published: no extractor groove or belt drawn.');
      pts.push({ z: R, r: P1 / 2 });
      bodyZ = R;
    }

    // Body, shoulder and neck.
    let shoulder = null;
    const bottleneck = hasNum(values.alpha) && hasNum(values.L1) && hasNum(values.L2);
    if (bottleneck && hasNum(values.P2) && hasNum(values.H1)) {
      const apexZ = values.L1 - (values.P2 / 2) / Math.tan(rad(values.alpha) / 2);
      shoulder = { L1: values.L1, L2: values.L2, P2: values.P2, H1: values.H1, alpha: values.alpha,
        alphaPublished: jc.alpha, apexZ: apexZ };
      pts.push({ z: values.L1, r: values.P2 / 2, fillet: hasNum(values.r1Min) ? values.r1Min : 0 });
      pts.push({ z: values.L2, r: values.H1 / 2, fillet: hasNum(values.r2) ? values.r2 : 0 });
    } else if (bottleneck) {
      const lacking = [!hasNum(values.P2) && 'P2', !hasNum(values.H1) && 'H1'].filter(Boolean);
      notes.push('Value ' + lacking.join(' and ') + ' not published: shoulder not drawn, body runs straight to the mouth.');
    }
    pts.push({ z: L3, r: H2 / 2 });
    const outer = roundCorners(pts);

    // Walls.
    const G1 = values.G1;
    let tn = 0;
    if (hasNum(G1)) {
      tn = Math.max(0, (H2 - G1) / 2);
    } else {
      notes.push('Value G1 is not published: neck wall taken as 0.');
    }
    const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
    const walls = { tn: tn, tb: tb };
    const wall = (z) => {
      if (!shoulder) return tb;
      if (z <= shoulder.L1) return tb;
      if (z >= shoulder.L2) return tn;
      return tb + (tn - tb) * (z - shoulder.L1) / (shoulder.L2 - shoulder.L1);
    };

    // Primer pocket.
    let pocket = null;
    const primer = ann.primerType;
    if (primer !== 'rimfire' && primer !== undefined) {
      if (PRIMERS[primer]) {
        pocket = { diameter: PRIMERS[primer].diameter, depth: PRIMERS[primer].depth, primerType: primer };
      } else {
        notes.push('Primer type ' + primer + ' has no pocket size in the table: no pocket drawn.');
      }
    }

    // Solid head: from the head face to w.
    let w = Math.max(2.5, 0.25 * P1 / 2);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (belt) w = Math.max(w, belt.rampEnd + tb);
    else if (groove) w = Math.max(w, E + tb);

    // Bullet.
    let bullet = null;
    const L6 = values.L6;
    if (!hasNum(G1) || !hasNum(L6)) {
      const lacking = [!hasNum(G1) && 'G1', !hasNum(L6) && 'L6'].filter(Boolean);
      notes.push('Value ' + lacking.join(' and ') + ' not published: bullet not drawn.');
    } else {
      const shape = ann.defaultBulletShape;
      const category = ann.category;
      const heeled = hasNum(H2) && (H2 - G1) <= 0.015;
      const G = heeled ? H2 : G1;                 // exposed diameter (heeled: the case outside diameter)
      const params = bulletParameters(shape, category, G);
      if (!params) {
        notes.push('Bullet shape ' + shape + ' is not drawn.');
      } else {
        const Rx = G / 2;
        const m2 = params.m / 2;
        const zb = L3 - params.s;
        const Lb = L6 - zb;
        const zc = zb + params.k * Lb;
        const rSeat = heeled ? (H2 - 2 * tb) / 2 : Rx;
        const profile = [{ z: zb, r: rSeat }];
        if (heeled && zb < L3 && L3 < zc) {
          profile.push({ z: L3, r: rSeat }, { z: L3, r: Rx });
        }
        profile.push({ z: zc, r: Rx });
        const n = L6 - zc;
        if (shape === 'pointy') {
          const a = Rx - m2;
          const rho = (a * a + n * n) / (2 * a);
          const rc = Rx - rho;
          const phiEnd = Math.atan2(n, rho - a);
          const steps = 24;
          for (let i = 1; i <= steps; i++) {
            const phi = phiEnd * i / steps;
            profile.push({ z: zc + rho * Math.sin(phi), r: rc + rho * Math.cos(phi) });
          }
        } else if (shape === 'rounded') {
          const A = Rx - m2;
          const steps = 24;
          for (let i = 1; i <= steps; i++) {
            const t = (Math.PI / 2) * i / steps;
            profile.push({ z: zc + n * Math.sin(t), r: m2 + A * Math.cos(t) });
          }
        } else {
          profile.push({ z: L6, r: m2 });
        }
        profile[profile.length - 1] = { z: L6, r: m2 };
        bullet = {
          shape: shape,
          category: category,
          heeled: heeled,
          s: params.s, k: params.k, m: params.m,
          zb: zb, zc: zc, Lb: Lb, G: G,
          profile: profile,
          exposed: clipFrom(profile, L3),
        };
      }
    }

    // Outside view: the case, then the exposed bullet down to the axis at the tip.
    const upper = bullet ? outer.concat(bullet.exposed, [{ z: L6, r: 0 }]) : outer.slice();

    // Inner (bore) line at the section walls, from the solid head to the mouth.
    const inner = [];
    if (w < L3 - 1e-9) {
      inner.push({ z: w, r: Math.max(0, radiusAt(outer, w) - wall(w)) });
      for (const p of outer) {
        if (p.z > w + 1e-9) inner.push({ z: p.z, r: Math.max(0, p.r - wall(p.z)) });
      }
    } else {
      notes.push('Solid head reaches the mouth: no cavity drawn.');
    }

    const solidPoly = inner.length
      ? outer.concat(inner.slice().reverse(), [{ z: w, r: 0 }])
      : outer.concat([{ z: 0, r: 0 }]);
    const pocketPoly = pocket
      ? [{ z: 0, r: 0 }, { z: pocket.depth, r: 0 }, { z: pocket.depth, r: pocket.diameter / 2 }, { z: 0, r: pocket.diameter / 2 }]
      : [];
    const bulletPoly = bullet
      ? [{ z: bullet.zb, r: 0 }].concat(bullet.profile, [{ z: L6, r: 0 }])
      : [];

    return Object.assign(base, {
      ok: true,
      outer: outer,
      upper: upper,
      bullet: bullet,
      walls: walls,
      w: w,
      inner: inner,
      pocket: pocket,
      pocketPoly: pocketPoly,
      solidPoly: solidPoly,
      bulletPoly: bulletPoly,
      rim: rim,
      groove: groove,
      belt: belt,
      shoulder: shoulder,
      body: { z: bodyZ },
    });
  };

  root.CIP = root.CIP || {};
  root.CIP.geometry = geometry;
})(typeof globalThis !== 'undefined' ? globalThis : this);
