# Plan: C.I.P. cartridge reference

Source of truth: `SPEC.md`. Order of work, each step verified before the next:

1. Data: JSONL verbatim, generated JS module, equality test. (done)
2. Pure formatting and catalog logic (format, search, family filter, routes, value tables). Tests first. (done)
3. Geometry model: rim type, head, groove or belt, body, shoulder, neck, bullet, walls, pocket, notes. Tests first. (done)
4. Drawing: SVG paths, hatching, dimensions, label placement with overlap checks for all 25 records. (done)
5. App shell: index.html, list view, detail view, routing, print button, CSS for screen, dark mode and A4 print. (done)
6. Browser checks: file:// and HTTP, search, filter, routes, reload, bookmarks, dark mode, phone width, print page count. (done)
7. Review: independent review did not return; self-review and browser checks instead.

Risks and how they were handled:
- Drawing legibility on a phone: labels are 3 mm in the SVG; at phone width they are roughly 7 px. Users can zoom.
- Print must be one page: measured at A4 width; the page count is checked for all 25 records.
- Labels overlapping: candidate positions are rejected when they touch another label or a line; tests cover all 25.
