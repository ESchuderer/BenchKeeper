# Tasks

- [x] Spec written (SPEC.md)
- [x] Data files and generator
- [x] Unit tests: format, catalog, data, geometry, drawing
- [x] Geometry and drawing modules
- [x] App shell, styles, routing, print
- [x] Browser checks (npm run test:e2e)
- [ ] Independent review: not completed (reviewer stopped without a report); self-review only
- [ ] Final verification run and report
