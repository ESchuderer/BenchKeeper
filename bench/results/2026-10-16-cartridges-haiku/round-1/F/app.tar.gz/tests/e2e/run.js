'use strict';
// Browser checks against the real app, over file:// and over a static server.
// Chromium: set CHROMIUM_PATH to a Chromium binary, or install one with `npx playwright install chromium`.
const { chromium } = require('playwright-core');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const assert = require('node:assert/strict');

const root = path.join(__dirname, '..', '..');
const results = [];

function check(name, fn) {
  results.push({ name, fn });
}

function serve(dir) {
  const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript', '.jsonl': 'text/plain' };
  const server = http.createServer((req, res) => {
    const file = path.join(dir, decodeURIComponent(req.url.split('?')[0]).replace(/^\/+/, '') || 'index.html');
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404); res.end('not found'); return; }
      res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream' });
      res.end(data);
    });
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

async function openPage(browser, url, options = {}) {
  const context = await browser.newContext(options.context || {});
  const page = await context.newPage();
  const errors = [];
  const requests = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('request', (r) => requests.push(r.url()));
  await page.goto(url);
  await page.waitForLoadState('load');
  return { context, page, errors, requests };
}

async function pdfPages(page) {
  await page.emulateMedia({ media: 'print' });
  const buffer = await page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true });
  const pages = buffer.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || [];
  return pages.length;
}

async function run(baseUrl, label, browser) {
  const index = baseUrl + 'index.html';
  const hashUrl = (key) => index + '#/cartridge/' + key;

  // 1. List: heading, 25 links with exact names, count, no errors, no remote requests.
  {
    const { context, page, errors, requests } = await openPage(browser, index);
    await page.waitForSelector('#rows a');
    assert.equal(await page.locator('h1').first().innerText(), 'Cartridges');
    assert.equal(await page.locator('#rows a').count(), 25);
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    const names = await page.locator('#rows a').allInnerTexts();
    assert.ok(names.includes('6,5 Creedmoor') && names.includes('223 Rem.') && names.includes('22 Long Rifle'));
    assert.equal(await page.locator('#rows tr').first().locator('td').nth(1).innerText(), 'rimless');
    assert.equal(await page.locator('#rows tr').first().locator('td').nth(2).innerText(), '44.7 mm');
    assert.deepEqual(errors, [], label + ' console errors on list');
    const remote = requests.filter((u) => !u.startsWith('file:') && !u.startsWith(baseUrl));
    assert.deepEqual(remote, [], label + ' remote requests');
    await context.close();
  }
  // 2. Search and family filter, combined; search field keeps focus while typing.
  {
    const { context, page } = await openPage(browser, index);
    await page.waitForSelector('#rows a');
    await page.fill('#search', '7,62 x 51');
    assert.deepEqual(await page.locator('#rows a').allInnerTexts(), ['308 Win.']);
    assert.equal(await page.locator('#count').innerText(), '1 cartridge');
    await page.fill('#search', '');
    await page.selectOption('#family', 'pistol');
    assert.equal(await page.locator('#rows a').count(), 6);
    await page.selectOption('#family', 'all');
    assert.equal(await page.locator('#rows a').count(), 25);
    await page.fill('#search', '22');
    await page.selectOption('#family', 'rimfire');
    assert.deepEqual((await page.locator('#rows a').allInnerTexts()).sort(), ['22 Long Rifle', '22 Win. Mag. R.F.']);
    await page.fill('#search', 'zzz');
    assert.equal(await page.locator('#count').innerText(), '0 cartridges');
    await context.close();
  }
  // 3. Detail by clicking a name; URL is the detail address; reload keeps it; bookmark opens it.
  {
    const { context, page, errors, requests } = await openPage(browser, index);
    await page.waitForSelector('#rows a');
    await page.click('text=308 Win.');
    await page.waitForSelector('h1#title');
    assert.equal(await page.locator('h1#title').innerText(), '308 Win.');
    assert.ok(page.url().endsWith('#/cartridge/308_win'), page.url());
    await page.reload();
    await page.waitForSelector('h1#title');
    assert.equal(await page.locator('h1#title').innerText(), '308 Win.');
    const bookmark = await openPage(browser, hashUrl('308_win'));
    await bookmark.page.waitForSelector('h1#title');
    assert.equal(await bookmark.page.locator('h1#title').innerText(), '308 Win.');
    await bookmark.context.close();
    assert.deepEqual(errors, [], label + ' console errors on detail');
    const remote = requests.filter((u) => !u.startsWith('file:') && !u.startsWith(baseUrl));
    assert.deepEqual(remote, [], label + ' remote requests on detail');
    await context.close();
  }
  // 4. Detail content: facts, drawing label, tables with Symbol/Value/Unit, All cartridges link, Print button.
  {
    const { context, page } = await openPage(browser, hashUrl('308_win'));
    await page.waitForSelector('h1#title');
    const text = await page.locator('.facts').innerText();
    for (const expected of ['Alternative names', '308 Winchester', 'Family', 'rimless', 'Category', 'rifle',
      'Primer type', 'lr', 'C.I.P. table', 'Country', 'US', 'Published', '1984-06-14', 'Revised', '2008-09-23',
      'Pressure method', 'Transducer', 'Water capacity', '56 gr H2O']) {
      assert.ok(text.includes(expected), 'facts contain ' + expected);
    }
    const water = page.locator('.facts a', { hasText: 'kwk' });
    assert.equal(await water.getAttribute('href'), 'http://kwk.us/cases.html');
    assert.equal(await page.locator('svg[aria-label="308 Win. drawing"]').count(), 1);
    const headers = await page.locator('table.values thead').first().locator('th').allInnerTexts();
    assert.deepEqual(headers, ['Symbol', 'Value', 'Unit']);
    assert.ok(await page.locator('table.values').count() >= 10);
    assert.equal(await page.locator('.values').first().locator('tr').nth(1).locator('th').innerText(), 'E');
    assert.equal(await page.locator('text=L1 39.62 -0.2').count() > 0, true);
    assert.equal(await page.locator('.values th', { hasText: /^e min$/ }).count(), 1, 'the e min symbol is shown');
    assert.equal(await page.getByRole('link', { name: 'All cartridges' }).count(), 1);
    assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.waitForSelector('#rows a');
    assert.equal(await page.locator('#rows a').count(), 25);
    await context.close();
  }
  // 5. Dark and light follow the system setting.
  {
    const dark = await openPage(browser, hashUrl('223_rem'), { context: { colorScheme: 'dark' } });
    await dark.page.waitForSelector('h1#title');
    const darkBg = await dark.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.notEqual(darkBg, 'rgb(255, 255, 255)');
    assert.ok(/rgb\((2[0-9]|1[0-9]|[0-9]), /.test(darkBg), 'dark background ' + darkBg);
    await dark.context.close();
    const light = await openPage(browser, hashUrl('223_rem'), { context: { colorScheme: 'light' } });
    await light.page.waitForSelector('h1#title');
    const lightBg = await light.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.ok(/rgb\(2[0-9][0-9], 2[0-9][0-9], 2[0-9][0-9]\)/.test(lightBg), 'light background ' + lightBg);
    await light.context.close();
  }
  // 6. Phone: no horizontal overflow on the list and the detail view.
  {
    const ctx = { viewport: { width: 360, height: 740 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 };
    const { context, page } = await openPage(browser, index, { context: ctx });
    await page.waitForSelector('#rows a');
    const listOverflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    assert.ok(listOverflow <= 0, 'list overflow ' + listOverflow);
    await page.goto(hashUrl('300_win_mag'));
    await page.waitForSelector('h1#title');
    const detailOverflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    assert.ok(detailOverflow <= 0, 'detail overflow ' + detailOverflow);
    const svgWidth = await page.locator('svg.cip-drawing').evaluate((el) => el.getBoundingClientRect().width);
    assert.ok(svgWidth <= 360, 'drawing fits the phone width: ' + svgWidth);
    await context.close();
  }
  // 7. Print: one A4 portrait page for every cartridge; print media hides navigation.
  {
    const { context, page } = await openPage(browser, index);
    await page.waitForSelector('#rows a');
    const keys = await page.evaluate(() => globalThis.CIP.cartridges.map((c) => c.key));
    const badPages = [];
    for (const key of keys) {
      await page.goto(hashUrl(key));
      await page.waitForSelector('h1#title');
      const n = await pdfPages(page);
      if (n !== 1) badPages.push(key + ':' + n);
    }
    assert.deepEqual(badPages, [], 'cartridges whose print is not one page');
    await page.goto(hashUrl('308_win'));
    await page.waitForSelector('h1#title');
    await page.emulateMedia({ media: 'print' });
    assert.equal(await page.locator('.topbar').evaluate((el) => getComputedStyle(el).display), 'none');
    assert.equal(await page.locator('.source').evaluate((el) => getComputedStyle(el).display) !== 'none', true);
    await page.emulateMedia({ media: 'screen' });
    await context.close();
  }
  // 8. Missing values are named in the drawing, and a detail page for an unknown key says so.
  {
    const { context, page } = await openPage(browser, hashUrl('no_such_key'));
    await page.waitForSelector('h1');
    assert.equal(await page.locator('h1').innerText(), 'Cartridge not found');
    await context.close();
  }
}

(async () => {
  const executablePath = process.env.CHROMIUM_PATH || undefined;
  const browser = await chromium.launch({ executablePath, args: ['--no-sandbox'] });
  const failures = [];
  const server = await serve(root);
  const baseUrl = 'http://127.0.0.1:' + server.address().port + '/';
  const fileUrl = pathToFileURL(root).href + '/';
  const runs = [['file://', fileUrl], ['static server', baseUrl]];
  for (const [label, url] of runs) {
    try {
      await run(url, label, browser);
      console.log('ok   ' + label);
    } catch (error) {
      failures.push(label + ': ' + (error && error.message));
      console.log('FAIL ' + label + ': ' + (error && error.message));
    }
  }
  await browser.close();
  server.close();
  if (failures.length) {
    console.error(failures.join('\n'));
    process.exit(1);
  }
  console.log('all browser checks passed');
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
