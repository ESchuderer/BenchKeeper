'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../../data/cartridges.js');
require('../../js/format.js');
require('../../js/catalog.js');
const { catalog } = globalThis.CIP;
const all = globalThis.CIP.cartridges;

const byKey = (key) => all.find((c) => c.key === key);

test('the data holds 25 cartridges with unique keys', () => {
  assert.equal(all.length, 25);
  assert.equal(new Set(all.map((c) => c.key)).size, 25);
});

test('normalize lowercases, collapses spaces and treats decimal comma as dot', () => {
  assert.equal(catalog.normalize('  7,62   x 51 '), '7.62 x 51');
  assert.equal(catalog.normalize('6.5 CREED'), '6.5 creed');
});

test('search matches names and alternative names', () => {
  const hits = catalog.filter(all, { query: '7,62 x 51', family: 'all' });
  assert.deepEqual(hits.map((c) => c.key), ['308_win']);
  assert.equal(catalog.filter(all, { query: '30-06', family: 'all' }).map((c) => c.key)[0], '30_06_spring');
  assert.equal(catalog.filter(all, { query: '6.5 creed', family: 'all' })[0].key, '6_5_creedmoor');
});

test('empty search returns everything; no match returns nothing', () => {
  assert.equal(catalog.filter(all, { query: '', family: 'all' }).length, 25);
  assert.equal(catalog.filter(all, { query: 'zzz', family: 'all' }).length, 0);
});

test('family filter counts match the records', () => {
  const count = (family) => catalog.filter(all, { query: '', family }).length;
  assert.equal(count('rimless'), 12);
  assert.equal(count('rimmed'), 2);
  assert.equal(count('belted'), 2);
  assert.equal(count('pistol'), 6);
  assert.equal(count('rimfire'), 3);
  assert.equal(count('all'), 25);
});

test('search and family filter combine', () => {
  assert.deepEqual(catalog.filter(all, { query: '22', family: 'rimfire' }).map((c) => c.key).sort(),
    ['22_long_rifle', '22_win_mag_r_f']);
  assert.equal(catalog.filter(all, { query: '22', family: 'pistol' }).length, 0);
});

test('family options are All plus the five families, in order', () => {
  assert.deepEqual(catalog.FAMILIES.map((f) => f.value), ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  assert.equal(catalog.FAMILIES[0].label, 'All');
});

test('count text', () => {
  assert.equal(catalog.countText(25), '25 cartridges');
  assert.equal(catalog.countText(1), '1 cartridge');
  assert.equal(catalog.countText(0), '0 cartridges');
});

test('routes: list, detail by key, percent-encoded keys, missing key', () => {
  assert.deepEqual(catalog.parseRoute(''), { view: 'list' });
  assert.deepEqual(catalog.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(catalog.parseRoute('#/cartridge/308_win'), { view: 'detail', key: '308_win' });
  assert.deepEqual(catalog.parseRoute('#/cartridge/%33%30%38_win'), { view: 'detail', key: '308_win' });
  assert.deepEqual(catalog.parseRoute('#/cartridge/'), { view: 'detail', key: '' });
  assert.deepEqual(catalog.parseRoute('#/unknown/page'), { view: 'list' });
});

test('find returns the record by key', () => {
  assert.equal(catalog.find(all, '223_rem').name, '223 Rem.');
  assert.equal(catalog.find(all, 'nope'), undefined);
});

test('sections: cartridge and chamber groups in order, rows with symbol, value, unit', () => {
  const s = catalog.sections(byKey('308_win'));
  assert.deepEqual(s.cartridge.map((g) => g.title), [
    'Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile',
  ]);
  assert.deepEqual(s.chamber.map((g) => g.title), [
    'Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling',
  ]);
  const head = s.cartridge[0].rows;
  assert.deepEqual(head.find((r) => r.key === 'E'), { key: 'E', symbol: 'E', value: '3.85', unit: 'mm' });
  assert.equal(head.find((r) => r.key === 'beta').value, '35°');
  assert.equal(head.find((r) => r.key === 'beta').unit, '');
});

test('tolerance fields are attached to their value, never a row of their own', () => {
  const s = catalog.sections(byKey('308_win'));
  const rows = s.cartridge.flatMap((g) => g.rows);
  assert.equal(rows.some((r) => /Tol$/.test(r.key)), false);
  assert.equal(rows.find((r) => r.key === 'L1').value, '39.62 -0.2');
  assert.equal(rows.find((r) => r.key === 'L3').value, '51.18');
  const r9 = catalog.sections(byKey('9_mm_luger')).cartridge.flatMap((g) => g.rows);
  assert.equal(r9.find((r) => r.key === 'L3').value, '19.15 -0.25');
});

test('symbols and units in rows', () => {
  const rows = catalog.sections(byKey('223_rem')).cartridge.flatMap((g) => g.rows);
  assert.equal(rows.find((r) => r.key === 'eMin').symbol, 'e min');
  assert.equal(rows.find((r) => r.key === 'L3PlusG').symbol, 'L3 + G');
  assert.equal(rows.find((r) => r.key === 'Pmax').unit, 'bar');
  assert.equal(rows.find((r) => r.key === 'Pmax').value, '4300');
  assert.equal(rows.find((r) => r.key === 'EE').unit, 'J');
  assert.equal(rows.find((r) => r.key === 'M').unit, 'g');
  const chamber = catalog.sections(byKey('223_rem')).chamber.flatMap((g) => g.rows);
  assert.equal(chamber.find((r) => r.key === 'Q').unit, 'mm²');
  assert.equal(chamber.find((r) => r.key === 'N').unit, '');
  assert.equal(chamber.find((r) => r.key === 'u').unit, 'mm');
});

test('empty and absent groups are not shown', () => {
  const pistol = catalog.sections(byKey('9_mm_luger'));
  assert.equal(pistol.cartridge.some((g) => g.title === 'Junction cone'), false);
  const rimfire = catalog.sections(byKey('22_win_mag_r_f'));
  assert.equal(rimfire.chamber.some((g) => g.title === 'Junction cone'), false);
});

test('water capacity text and source', () => {
  assert.equal(catalog.waterCapacity(byKey('223_rem')).text, '30.5 gr H2O');
  assert.equal(catalog.waterCapacity(byKey('223_rem')).source, 'kwk');
  assert.equal(catalog.waterCapacity(byKey('223_rem')).url, 'http://kwk.us/cases.html');
  assert.equal(catalog.waterCapacity(byKey('223_rem')).note, 'kwk 31, Wikipedia 28.8; the mean');
});
