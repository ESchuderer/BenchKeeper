'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const root = path.join(__dirname, '..', '..');

test('data/cartridges.js equals the JSONL source, record by record', () => {
  delete require.cache[require.resolve('../../data/cartridges.js')];
  require('../../data/cartridges.js');
  const fromJs = globalThis.CIP.cartridges;
  const fromJsonl = fs.readFileSync(path.join(root, 'data', 'cartridges.jsonl'), 'utf8')
    .split('\n').filter((l) => l.trim() !== '').map((l) => JSON.parse(l));
  assert.deepEqual(fromJs, fromJsonl);
  assert.equal(fromJsonl.length, 25);
});

test('generated module is up to date with the source', () => {
  execFileSync(process.execPath, [path.join(root, 'scripts', 'build-data.js'), '--check'], { stdio: 'pipe' });
});

test('app files make no network requests (no http(s) URLs in the app code)', () => {
  const files = ['index.html', ...fs.readdirSync(path.join(root, 'js')).map((f) => 'js/' + f),
    ...fs.readdirSync(path.join(root, 'css')).map((f) => 'css/' + f)];
  for (const f of files) {
    // The SVG namespace is an identifier, not a request.
    const text = fs.readFileSync(path.join(root, f), 'utf8').split('http://www.w3.org/2000/svg').join('');
    assert.doesNotMatch(text, /https?:\/\//, f);
    assert.doesNotMatch(text, /@import|<link[^>]+href=["']https?/i, f);
  }
});
