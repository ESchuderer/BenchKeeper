'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../../data/cartridges.js');
require('../../js/format.js');
require('../../js/catalog.js');
require('../../js/geometry.js');
require('../../js/drawing.js');
const { drawing } = globalThis.CIP;
const all = globalThis.CIP.cartridges;
const byKey = (key) => all.find((c) => c.key === key);

function segmentsOf(poly) {
  const out = [];
  for (let i = 1; i < poly.length; i++) out.push([poly[i - 1], poly[i]]);
  return out;
}

function boxHitsPoint(box, x, y, pad) {
  return x >= box.x0 - pad && x <= box.x1 + pad && y >= box.y0 - pad && y <= box.y1 + pad;
}

function boxesOverlap(a, b) {
  return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
}

function segmentHitsBox(p, q, box) {
  const steps = Math.ceil(Math.hypot(q.x - p.x, q.y - p.y) / 0.2) + 1;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    if (boxHitsPoint(box, p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, 0.15)) return true;
  }
  return false;
}

test('svg has role img and the accessible name "<name> drawing", with a viewBox in mm', () => {
  const { svg } = drawing.layout(byKey('308_win'));
  assert.match(svg, /^<svg\b/);
  assert.match(svg, /role="img"/);
  assert.match(svg, /aria-label="308 Win\. drawing"/);
  assert.match(svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/);
  assert.match(svg, /<title>308 Win\. drawing<\/title>/);
});

test('centre line is dash-dot, and cut walls use a hatch pattern', () => {
  const { svg } = drawing.layout(byKey('308_win'));
  assert.match(svg, /class="centre-line"[^>]*stroke-dasharray="[\d.]+ [\d.]+ [\d.]+ [\d.]+"/);
  assert.match(svg, /<pattern id="[^"]+"/);
  assert.match(svg, /fill="url\(#[^)]+\)"/);
});

test('required dimension labels show symbol and value (with tolerance)', () => {
  const texts = drawing.layout(byKey('308_win')).labels.map((l) => l.text);
  for (const expected of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53 -0.2',
    'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62 -0.2', 'L2 43.48 -0.2', 'E1 10.39', 'α 40°']) {
    assert.ok(texts.includes(expected), expected + ' in ' + texts.join(' | '));
  }
});

test('labels for a straight case omit the shoulder dimensions', () => {
  const texts = drawing.layout(byKey('9_mm_luger')).labels.map((l) => l.text);
  assert.ok(texts.includes('L3 19.15 -0.25'));
  assert.ok(texts.includes('R1 9.96'));
  assert.equal(texts.some((t) => /^α/.test(t)), false);
  assert.equal(texts.some((t) => /^L1 /.test(t)), false);
});

test('title block: name, C.I.P. table, revision date, Dimensions in mm, scale', () => {
  const { svg } = drawing.layout(byKey('308_win'));
  assert.match(svg, /class="title-block"/);
  assert.match(svg, />308 Win\.</);
  assert.match(svg, /C\.I\.P\. table I/);
  assert.match(svg, /Revised 2008-09-23/);
  assert.match(svg, /Dimensions in mm/);
  assert.match(svg, /Scale 1:1/);
});

test('names are escaped in the svg', () => {
  const { svg } = drawing.layout(byKey('40_s_w'));
  assert.match(svg, /40 S\.&amp; W\. drawing/);
  assert.doesNotMatch(svg, /40 S\.& W\./);
});

test('notes list values the drawing could not use', () => {
  const r = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete r.cartridge.caseHead.eMin;
  const out = drawing.layout(r);
  assert.ok(out.notes.some((n) => /eMin/.test(n)));
  assert.match(out.svg, /class="drawing-missing"/);
});

test('an unusable case (missing core value) yields no svg and a message', () => {
  const r = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete r.cartridge.caseHead.R;
  const out = drawing.layout(r);
  assert.equal(out.svg, null);
  assert.ok(out.notes.some((n) => /\bR\b/.test(n)));
});

for (const record of all) {
  test(`${record.key}: no label overlaps another label or the outline, and nothing is left unplaced`, () => {
    const out = drawing.layout(record);
    assert.deepEqual(out.warnings, [], 'unplaced labels');
    assert.ok(out.labels.length >= 5, 'labels');
    for (let i = 0; i < out.labels.length; i++) {
      for (let j = i + 1; j < out.labels.length; j++) {
        assert.equal(boxesOverlap(out.labels[i].box, out.labels[j].box), false,
          `${out.labels[i].text} overlaps ${out.labels[j].text}`);
      }
      for (const poly of out.obstacles) {
        for (const [p, q] of segmentsOf(poly)) {
          assert.equal(segmentHitsBox(p, q, out.labels[i].box), false,
            `${out.labels[i].text} overlaps outline`);
        }
      }
    }
    for (const label of out.labels) {
      const b = out.bounds;
      assert.ok(label.box.x0 >= b.x0 - 1e-6 && label.box.x1 <= b.x1 + 1e-6 &&
        label.box.y0 >= b.y0 - 1e-6 && label.box.y1 <= b.y1 + 1e-6, label.text + ' inside viewBox');
    }
  });
}
