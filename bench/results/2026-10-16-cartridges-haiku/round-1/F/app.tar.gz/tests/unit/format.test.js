'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../../js/format.js');
const { format } = globalThis.CIP;

test('numbers are shown as published: decimal point, no thousands separator, no trailing zeros', () => {
  assert.equal(format.number(4150), '4150');
  assert.equal(format.number(4150.0), '4150');
  assert.equal(format.number(51.18), '51.18');
  assert.equal(format.number(1825.0), '1825');
  assert.equal(format.number(-0.2), '-0.2');
  assert.equal(format.number(0), '0');
});

test('angle given as a number of degrees', () => {
  assert.equal(format.angle(40), '40°');
  assert.equal(format.angle(0), '0°');
  assert.equal(format.angle(180.0), '180°');
});

test('angle given as {degrees, minutes, seconds}', () => {
  assert.equal(format.angle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(format.angle({ degrees: 3, minutes: 10, seconds: 36 }), `3°10'36"`);
  assert.equal(format.angle({ degrees: 1, minutes: 30, seconds: 0 }), `1°30'00"`);
  assert.equal(format.angle({ degrees: 50.0, minutes: 35.0, seconds: 2.0 }), `50°35'02"`);
});

test('a tolerance is shown next to its value, signed', () => {
  assert.equal(format.withTolerance('39.62', -0.2), '39.62 -0.2');
  assert.equal(format.withTolerance('12', 0.1), '12 +0.1');
  assert.equal(format.withTolerance('12', undefined), '12');
});

test('symbols: field name unless the brief maps it', () => {
  const cases = {
    E1: 'E1', eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Fe: 'Fe', G2: 'G2',
    Pmax: 'Pmax', r2: 'r2', i: 'i', N: 'N', Q: 'Q',
  };
  for (const [key, symbol] of Object.entries(cases)) {
    assert.equal(format.symbol(key), symbol, key);
  }
});

test('units: mm for lengths and diameters, bar, J, g, mm², none for counts and angles', () => {
  assert.equal(format.unit('L3'), 'mm');
  assert.equal(format.unit('G1'), 'mm');
  assert.equal(format.unit('deltaL'), 'mm');
  assert.equal(format.unit('Pmax'), 'bar');
  assert.equal(format.unit('PK'), 'bar');
  assert.equal(format.unit('PE'), 'bar');
  assert.equal(format.unit('EE'), 'J');
  assert.equal(format.unit('M'), 'g');
  assert.equal(format.unit('Q'), 'mm²');
  assert.equal(format.unit('N'), '');
  assert.equal(format.unit('alpha'), '');
});

test('angle keys are alpha, alpha1, beta, delta and i only', () => {
  for (const key of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(format.isAngle(key), true, key);
  for (const key of ['deltaL', 'L3', 'R', 'G1']) assert.equal(format.isAngle(key), false, key);
});

test('rowText combines a value with its tolerance; angles keep their degree sign', () => {
  assert.equal(format.rowText('L1', 39.62, -0.2), '39.62 -0.2');
  assert.equal(format.rowText('L3', 51.18), '51.18');
  assert.equal(format.rowText('beta', 35.0), '35°');
  assert.equal(format.rowText('i', { degrees: 3, minutes: 10, seconds: 36 }), `3°10'36"`);
});
