'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../../data/cartridges.js');
require('../../js/format.js');
require('../../js/catalog.js');
require('../../js/geometry.js');
const { geometry } = globalThis.CIP;
const all = globalThis.CIP.cartridges;
const byKey = (key) => all.find((c) => c.key === key);
const nearest = (m, z, r) => Math.min(...m.outer.map((p) => Math.hypot(p.z - z, p.r - r)));
const close = (actual, expected, eps = 0.01, msg) => assert.ok(Math.abs(actual - expected) <= eps, `${msg || ''} expected ${expected} got ${actual}`);
const clone = (x) => JSON.parse(JSON.stringify(x));

test('rim type: family first, then R1/P1 ratio', () => {
  assert.equal(geometry.rimType(byKey('300_win_mag')), 'belted');
  assert.equal(geometry.rimType(byKey('22_long_rifle')), 'rimfire');
  assert.equal(geometry.rimType(byKey('9_3_x_74_r')), 'rimmed');
  assert.equal(geometry.rimType(byKey('38_special')), 'rimmed');
  assert.equal(geometry.rimType(byKey('223_rem')), 'rimless');
  assert.equal(geometry.rimType(byKey('9_3_x_62')), 'rimless');
  const rebated = clone(byKey('223_rem'));
  rebated.cartridge.powderChamber.P1 = 10.5;
  assert.equal(geometry.rimType(rebated), 'rebated');
});

test('every record builds a model with finite points, and the case outline runs from the head face to the mouth', () => {
  for (const record of all) {
    const m = geometry.buildModel(record);
    assert.equal(m.ok, true, record.key + ' ' + m.missing.join(','));
    assert.deepEqual(m.outer[0], { z: 0, r: 0 }, record.key);
    for (const p of m.outer) {
      assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r), record.key);
      assert.ok(p.r >= 0, record.key);
    }
    for (let i = 1; i < m.outer.length; i++) {
      assert.ok(m.outer[i].z >= m.outer[i - 1].z - 1e-9, record.key + ' z must not decrease');
    }
    const mouth = m.outer[m.outer.length - 1];
    close(mouth.z, record.cartridge.lengths.L3, 1e-9, record.key + ' mouth z');
    close(mouth.r, record.cartridge.collar.H2 / 2, 1e-9, record.key + ' mouth r');
  }
});

test('223 Rem.: chamfer from f·tan(β), groove floor at E1/2 between R and R+eMin, ramp to the body at E', () => {
  const m = geometry.buildModel(byKey('223_rem'));
  const chamfer = 0.45 * Math.tan(35 * Math.PI / 180);
  close(m.outer[1].r, 9.6 / 2 - chamfer, 1e-6, 'chamfer start radius');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 0.45) < 1e-9 && Math.abs(p.r - 4.8) < 1e-9), 'chamfer end at (f, R1/2)');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 1.14) < 1e-9 && Math.abs(p.r - 4.8) < 1e-9), 'rim back corner at (R, R1/2)');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 1.14) < 1e-9 && Math.abs(p.r - 8.43 / 2) < 1e-9), 'groove start (R, E1/2)');
  assert.ok(m.outer.some((p) => Math.abs(p.z - (1.14 + 0.76)) < 1e-9 && Math.abs(p.r - 8.43 / 2) < 1e-9), 'groove floor end');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 3.13) < 1e-9 && Math.abs(p.r - 9.58 / 2) < 1e-9), 'body start (E, P1/2)');
  assert.equal(m.groove.E, 3.13);
  assert.equal(m.belt, null);
});

test('223 Rem.: shoulder runs (P2/2, L1) to (H1/2, L2) and implies the published α', () => {
  const m = geometry.buildModel(byKey('223_rem'));
  assert.ok(m.shoulder, 'bottleneck');
  const dr = 9.0 / 2 - 6.43 / 2;
  const dz = 39.55 - 36.52;
  const alphaDeg = 2 * Math.atan(dr / dz) * 180 / Math.PI;
  close(alphaDeg, 46, 0.05, 'implied alpha');
  close(m.shoulder.alpha, 46, 1e-9);
  assert.ok(nearest(m, 36.52, 4.5) < 0.15, 'shoulder start corner is filleted, not cut');
  assert.ok(nearest(m, 39.55, 6.43 / 2) < 0.15, 'shoulder end corner is filleted, not cut');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 44.7) < 1e-9 && Math.abs(p.r - 6.43 / 2) < 1e-9), 'mouth at (L3, H2/2)');
});

test('straight cases (no alpha, L1 or L2) run from the body start to (H2/2, L3)', () => {
  const m = geometry.buildModel(byKey('9_mm_luger'));
  assert.equal(m.shoulder, null);
  const last = m.outer[m.outer.length - 1];
  assert.ok(Math.abs(last.z - 19.15) < 1e-9 && Math.abs(last.r - 9.65 / 2) < 1e-9);
  const body = m.outer.find((p) => Math.abs(p.z - 2.98) < 1e-9 && Math.abs(p.r - 9.93 / 2) < 1e-9);
  assert.ok(body, 'body start at (E, P1/2)');
});

test('rimfire 22 Long Rifle: half-round rim edge with outermost point at R1/2', () => {
  const m = geometry.buildModel(byKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  close(m.rim.rho, rho, 1e-9, 'rho');
  const maxR = Math.max(...m.outer.map((p) => p.r));
  close(maxR, 7.06 / 2, 1e-6, 'outermost rim point');
  assert.ok(m.outer.some((p) => Math.abs(p.z - rho) < 1e-6 && Math.abs(p.r - 7.06 / 2) < 1e-6), 'outermost point at z = rho');
  assert.equal(m.groove, null);
});

test('belted 300 Win. Mag.: ramp at δ from the floor to the belt R3/2, belt to z = E, then step to P1/2', () => {
  const m = geometry.buildModel(byKey('300_win_mag'));
  assert.ok(m.belt);
  const rampEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  close(m.belt.rampEnd, rampEnd, 1e-9, 'ramp end z');
  assert.ok(m.outer.some((p) => Math.abs(p.z - rampEnd) < 1e-6 && Math.abs(p.r - 13.51 / 2) < 1e-6), 'belt starts at ramp end');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 5.59) < 1e-9 && Math.abs(p.r - 13.51 / 2) < 1e-9), 'belt ends at z = E');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 5.59) < 1e-9 && Math.abs(p.r - 13.03 / 2) < 1e-9), 'step to P1/2 at E');
});

test('bullet 223: s = G1, base at L3 - s, cylinder to zb + 0.40·Lb, flat meplat m = max(0.08·G1, 1.27)', () => {
  const b = geometry.buildModel(byKey('223_rem')).bullet;
  close(b.s, 5.7, 1e-9, 's');
  close(b.zb, 44.7 - 5.7, 1e-9, 'zb');
  close(b.Lb, 57.4 - 39.0, 1e-9, 'Lb');
  close(b.zc, 39.0 + 0.4 * 18.4, 1e-9, 'zc');
  close(b.m, 1.27, 1e-9, 'm');
  const tip = b.profile[b.profile.length - 1];
  close(tip.z, 57.4, 1e-9, 'tip z');
  close(tip.r, 0.635, 1e-9, 'tip r');
});

test('bullet 223 pointy: the nose is a tangent arc of radius ρ from (G1/2, zc) to the meplat', () => {
  const b = geometry.buildModel(byKey('223_rem')).bullet;
  const G = 5.7, m = 1.27, n = 57.4 - b.zc;
  const a = G / 2 - m / 2;
  const rho = (a * a + n * n) / (2 * a);
  const nosePts = b.profile.filter((p) => p.z > b.zc + 1e-9);
  assert.ok(nosePts.length > 5);
  const rc = G / 2 - rho;
  for (const p of nosePts) {
    const d = Math.hypot(p.z - b.zc, p.r - rc);
    close(d, rho, 1e-6, 'point on arc');
  }
  const first = nosePts[0];
  assert.ok(Math.abs(first.r - G / 2) < 0.2 && first.z - b.zc < 1.0, 'nose starts on the cylinder');
});

test('bullet shapes: rounded rifle, rounded pistol, flat pistol, semi-wadcutter', () => {
  const rifle = geometry.buildModel(byKey('6_5_creedmoor')).bullet; // rifle pointy
  assert.equal(rifle.shape, 'pointy');
  const lu = geometry.buildModel(byKey('9_mm_luger')).bullet;       // pistol rounded
  close(lu.s, 0.4 * 9.03, 1e-9, 'pistol rounded s');
  close(lu.k, 0.65, 1e-9, 'pistol rounded k');
  close(lu.m, 0.15 * 9.03, 1e-9, 'rounded m');
  const fl = geometry.buildModel(byKey('40_s_w')).bullet;           // pistol flat
  close(fl.s, 0.4 * 10.17, 1e-9, 'pistol flat s');
  close(fl.k, 0.70, 1e-9, 'pistol flat k');
  close(fl.m, 0.55 * 10.17, 1e-9, 'flat m');
  const sw = geometry.buildModel(byKey('357_magnum')).bullet;       // semi-wadcutter
  close(sw.s, 0.6 * 9.12, 1e-9, 'semi s');
  close(sw.k, 0.78, 1e-9, 'semi k');
  close(sw.m, 0.6 * 9.12, 1e-9, 'semi m');
});

test('rifle and rimfire rounded/flat use 0.8·G1 and k 0.55 / 0.60', () => {
  const rimfire = geometry.buildModel(byKey('22_long_rifle')).bullet;
  assert.equal(rimfire.shape, 'rounded');
  close(rimfire.s, 0.8 * 5.72, 1e-9, 'rimfire rounded s');
  close(rimfire.k, 0.55, 1e-9, 'rimfire rounded k');
});

test('heeled case (H2 - G1 <= 0.015): exposed bullet has the case outside diameter, heel has the inside diameter', () => {
  const m = geometry.buildModel(byKey('22_long_rifle'));
  assert.equal(m.bullet.heeled, true);
  close(m.walls.tb, 0.6, 1e-9, 'tb');
  close(m.walls.tn, 0, 1e-9, 'tn');
  const exposed = m.bullet.exposed.filter((p) => p.z > m.values.L3 + 1e-9);
  assert.ok(exposed.every((p) => p.r <= 5.72 / 2 + 1e-9));
  const heel = m.bullet.profile.filter((p) => p.z < m.values.L3 - 1e-9);
  assert.ok(heel.length > 0 && heel.every((p) => Math.abs(p.r - (5.72 - 1.2) / 2) < 1e-6), 'heel radius = (H2 - 2tb)/2');
  assert.equal(geometry.buildModel(byKey('223_rem')).bullet.heeled, false);
});

test('section walls: tn = (H2 - G1)/2, tb = min(max(1.3·tn, 0.6), 0.35·P1/2)', () => {
  const m = geometry.buildModel(byKey('223_rem'));
  close(m.walls.tn, (6.43 - 5.7) / 2, 1e-9, 'tn');
  close(m.walls.tb, 0.6, 1e-9, 'tb');
});

test('solid head: w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb)', () => {
  const m = geometry.buildModel(byKey('223_rem'));
  close(m.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + 0.6), 1e-9, 'w');
});

test('primer pockets: diameter and depth from the primer type; rimfire has none', () => {
  const sr = geometry.buildModel(byKey('223_rem')).pocket;
  assert.deepEqual([sr.diameter, sr.depth], [4.45, 3.04]);
  const lrm = geometry.buildModel(byKey('338_lapua_mag')).pocket;
  assert.deepEqual([lrm.diameter, lrm.depth], [5.33, 3.3]);
  const lr = geometry.buildModel(byKey('308_win')).pocket;
  assert.deepEqual([lr.diameter, lr.depth], [5.33, 3.3]);
  assert.equal(geometry.buildModel(byKey('22_long_rifle')).pocket, null);
});

test('belted case without δ falls back to a plain groove and names the missing value', () => {
  const r = clone(byKey('300_win_mag'));
  delete r.cartridge.caseHead.delta;
  const m = geometry.buildModel(r);
  assert.equal(m.belt, null);
  assert.ok(m.notes.some((n) => /delta/.test(n)), m.notes.join(' | '));
  assert.equal(m.ok, true);
});

test('missing core values make the drawing unavailable and name the value', () => {
  const r = clone(byKey('223_rem'));
  delete r.cartridge.caseHead.R;
  const m = geometry.buildModel(r);
  assert.equal(m.ok, false);
  assert.ok(m.missing.includes('R'));
});

test('a groove without eMin is drawn with zero floor and a note names eMin', () => {
  const r = clone(byKey('223_rem'));
  delete r.cartridge.caseHead.eMin;
  const m = geometry.buildModel(r);
  assert.equal(m.ok, true);
  assert.ok(m.notes.some((n) => /eMin/.test(n)), m.notes.join(' | '));
});

test('a shoulder without P2 is not drawn (straight body) and a note names P2', () => {
  const r = clone(byKey('223_rem'));
  delete r.cartridge.powderChamber.P2;
  const m = geometry.buildModel(r);
  assert.equal(m.shoulder, null);
  assert.ok(m.notes.some((n) => /P2/.test(n)), m.notes.join(' | '));
});

test('no record needs a note for the published data', () => {
  for (const record of all) {
    const m = geometry.buildModel(record);
    assert.deepEqual(m.notes, [], record.key);
  }
});

test('the upper outline (outside view) hides the seated bullet; the section contains it', () => {
  const m = geometry.buildModel(byKey('223_rem'));
  const hidden = m.upper.filter((p) => p.z < 44.7 - 1e-9 && p.z > 39.0 + 1e-9 && p.r < 2.85 - 1e-9);
  assert.equal(hidden.length, 0, 'no seated bullet points in the outside outline');
  assert.ok(m.bulletPoly.length > 10, 'section polygon of the bullet exists');
  assert.ok(m.solidPoly.length > 10, 'section polygon of the case exists');
});

