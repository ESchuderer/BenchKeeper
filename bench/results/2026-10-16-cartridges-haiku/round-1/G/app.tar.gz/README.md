# C.I.P. cartridge reference

A static reference of 25 C.I.P. cartridges (data from OpenBallistics, MIT, commit e83db43): a searchable list, a detail view per cartridge with every published value, a true-to-scale half-section drawing, and a one-page A4 print.

## Open it

Open `index.html` in Chromium (works from `file://`), or serve the folder with any static server. No build step, no runtime dependencies, no network requests.

## Develop

    npm install
    npm test                 # unit tests (node:test, Node 22)
    npm run test:browser     # browser checks with Playwright (needs a Chromium it can start)

The app is `index.html` with `css/app.css` and `js/*.js` (classic scripts; `js/data.js` holds the records). Tests load the same files into a `vm` context.

## Layout

- `js/format.js` numbers, angles, units, symbols, tolerances
- `js/model.js` rim type, sections, search, routes, primer pockets
- `js/geometry.js` case, cavity, pocket and bullet geometry from the brief's rules
- `js/drawing.js` inline SVG, label boxes and outline polylines (used by the layout tests)
- `js/app.js` list, detail view and routing
- `docs/superpowers/specs/` the design decisions

Design decisions and the calls made in the build are in `docs/superpowers/specs/2026-10-16-cip-cartridge-reference-design.md`.
