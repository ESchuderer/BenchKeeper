# C.I.P. cartridge reference: design

Date: 2026-10-16. Status: built from the brief in the task (no interactive review round; the brief was complete).

## Intent

A static, single-folder reference of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on OpenBallistics. The reader looks up a cartridge, reads every published value with its tolerance, sees a true-to-scale half-section drawing, and prints one A4 page.

## Goals

- List of the 25 records with search (name and alternative names) and family filter.
- Detail view with an address per cartridge (`#/cartridge/<key>`), surviving reload and bookmarks.
- Every cartridge value and chamber value, grouped by section, with Symbol / Value / Unit.
- Inline SVG drawing computed from the record with the geometry rules in the brief.
- Print: one A4 portrait page, black on white, no chrome.
- Light and dark on screen, following the system setting.

## Non-goals

- No data entry, editing, or fetching. The 25 records are the only data.
- No server, build step, framework, runtime dependency, CDN, web font or analytics.
- No display of data-quality annotations (`confidence`, `implausible`); they are in the record but outside the brief's detail view.

## Anti-goals

- A drawing that looks plausible but is not to scale.
- Invented numbers. A rule whose input is missing is drawn without that feature and the missing value is named.
- Tolerances as their own rows.

## Constraints

- Must run from `file://` in Chromium. Therefore: classic scripts (no ES modules, which Chromium blocks from `file://`), data embedded as a JS file, no `fetch`.
- Node 22 for development tests. Tests use `node:test` (built in), so the only dev dependency is an optional browser harness.

## Decisions taken as the builder's calls

1. **Script layout.** Plain `<script>` files under `js/`, sharing one namespace `window.CIP`. `js/data.js` holds the records, one JSON object per line. Tests load the same files into a `vm` context.
2. **Number formatting.** Numbers are JSON numbers, so trailing zeros are lost (`35.0` shows as `35`, `64.0` as `64`). The brief's examples (`51.18 mm`, `4150 bar`, `40°`) are reproduced. This is the one place "as published" is approximated.
3. **Angles.** Number = degrees, shown as `40°`. Object = `d°mm'ss"`, minutes and seconds zero-padded (`1°30'00"`).
4. **Units.** Pressures `Pmax PK PE` bar; `EE` J; `M` g; `Q` mm²; `N` count (unit shown as `—`); angles `alpha alpha1 beta delta i`; everything else mm, including `S`, `Fe`, `deltaL`, `u`, `G2`, `L3PlusG`, `h`, `s`, `b`, `G`.
5. **Rim geometry.** Read the rule tuples as (radius, z). `R` is the z of the rim top, `E` the z where the body starts, `E1` the groove diameter, `eMin` the groove floor length (z). Rimfire rim is a semicircle of radius `min(R/2, (R1-P1)/2)`, drawn from z = 0 to z = 2ρ.
6. **Belted groove.** The ramp at angle δ is taken as making δ with the axis (`dz = dr / tan δ`), so it is a shallow ramp, then the belt at `R3/2` runs to `z = E`.
7. **Straight cases.** Wall `tb` along the body. Heeled cases keep `tb` at the mouth (so the heel diameter `H2 - 2·tb` matches the inside). Non-heeled straight cases blend the wall from `tb` at the body start to `tn` at the mouth, so the bullet fits the mouth.
8. **Seated bullet.** Non-heeled: the seated part is `min(G1/2, inner wall radius)`, so a shank wider than the body bore (9 mm Luger) is drawn crimped to the bore instead of overlapping the wall. Heeled: the heel is `H2/2 - tb`.
9. **Cavity floor.** `w` as in the brief, clamped to be at least `body start + tb` so the floor always lies in the body.
10. **Fillets.** Corners at the shoulder use `r1Min` (body side) and `r2` (neck side). A fillet tangent length is clamped to half of each adjacent segment.
11. **Dimensions.** Lengths (`R`, `L1`, `L2`, `L3`, `L6`) are horizontal dimension rows above the drawing, ordered so ext lines do not cross other rows' spans. Diameters (`R1` left; `P1`, `P2`, `H1`, `H2`, `G1`, `E1` right) are vertical dimension lanes with horizontal extension lines. α is an arc at the cone apex, drawn in the outside view. Labels carry a halo so an extension line passing behind one stays legible; labels never touch the outline.
12. **Drawing scale and size.** Kept true to scale. On narrow screens the drawing scrolls sideways (minimum width 560 px) rather than shrinking the labels; in print it is full width, capped at 112 mm in height so short cartridges stay on one page.
13. **Drawing scale.** 1 SVG unit = 1 mm. The title block states `Scale 1:1` for the geometry; on screen and in print the SVG is scaled to the available width.
14. **Tolerances.** Shown after the value (`39.62 -0.2`), never as rows. Tolerance is looked up as `<field>Tol` in the same section.
15. **Singular label.** The count reads `1 cartridge` for one result and `<n> cartridges` otherwise.
16. **Print.** Single-page A4 portrait. Tables use two columns (cartridge | chamber) so the page fits; the footer is fixed and reads `Source: C.I.P. TDCC, revised <date>`.
17. **Primer pockets.** Diameter 4.45 mm for `sp spm sr` and 5.33 mm for `lp lpm lr lrm`; depth 3.04 mm for `sp spm sr lp lpm` and 3.30 mm for `lr lrm`. Rimfire cases have no pocket.

## Left to the builder (decided above)

Everything in the list above. Nothing else is open.

## Acceptance

- `npm test` passes (unit tests for formatting, routing, search, rim type, geometry rules, bullet, sections, drawing bounds and label overlap).
- All 25 cartridges render a drawing without exception; each missing-value note is listed in the page.
- Browser check (if Chromium can be obtained): page loads from `file://`, search and family filter work, the detail route survives reload, print to PDF gives one page.
