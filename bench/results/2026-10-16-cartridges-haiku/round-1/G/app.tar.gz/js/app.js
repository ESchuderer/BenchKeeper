/*
 * Page controller: the cartridge list (search and family filter), the detail view, and hash routing.
 * Content is built with DOM methods; the drawing SVG comes from window.CIP.drawing, which escapes its text.
 */
(function () {
  'use strict';
  var CIP = window.CIP;
  var F = CIP.format;
  var M = CIP.model;
  var D = CIP.drawing;
  var records = window.CIP_RECORDS;
  var root = document.getElementById('app');

  var FAMILIES = [
    { value: 'all', label: 'All' },
    { value: 'rimless', label: 'rimless' },
    { value: 'rimmed', label: 'rimmed' },
    { value: 'belted', label: 'belted' },
    { value: 'pistol', label: 'pistol' },
    { value: 'rimfire', label: 'rimfire' }
  ];

  // The list keeps its search and filter while the user looks at a detail view and comes back.
  var listState = { query: '', family: 'all' };

  function h(tag, attrs, kids) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === undefined || v === null || v === false) return;
        if (k === 'text') node.textContent = v;
        else if (k === 'className') node.className = v;
        else if (k.indexOf('on') === 0) node.addEventListener(k.slice(2), v);
        else node.setAttribute(k, v === true ? '' : String(v));
      });
    }
    (kids || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return node;
  }

  function setTitle(text) {
    document.title = text;
  }

  function l3Text(rec) {
    var L = rec.cartridge.lengths;
    return F.withTol(F.number(L.L3), L.L3Tol) + ' mm';
  }

  // ---------- list view ----------

  function listItems(list) {
    return list.map(function (rec) {
      return h('li', { className: 'list-item' }, [
        h('a', { href: '#/cartridge/' + encodeURIComponent(rec.key), className: 'name' }, [rec.name]),
        h('span', { className: 'family' }, [rec.family]),
        h('span', { className: 'l3' }, ['L3 ' + l3Text(rec)])
      ]);
    });
  }

  function renderList() {
    setTitle('Cartridges · C.I.P. reference');
    var count = h('p', { className: 'count', 'aria-live': 'polite' });
    var list = h('ul', { className: 'list' });

    function refresh() {
      var shown = M.filter(records, listState);
      count.textContent = M.countLabel(shown.length);
      list.textContent = '';
      listItems(shown).forEach(function (li) { list.appendChild(li); });
      if (shown.length === 0) {
        list.appendChild(h('li', { className: 'empty' }, ['No cartridge matches this search.']));
      }
    }

    var search = h('input', {
      id: 'cip-search', type: 'search', autocomplete: 'off', spellcheck: 'false',
      value: listState.query,
      oninput: function (e) { listState.query = e.target.value; refresh(); }
    });
    var select = h('select', {
      id: 'cip-family',
      onchange: function (e) { listState.family = e.target.value; refresh(); }
    }, FAMILIES.map(function (f) {
      return h('option', { value: f.value }, [f.label]);
    }));
    select.value = listState.family;

    root.textContent = '';
    root.appendChild(h('header', { className: 'page-head' }, [h('h1', { text: 'Cartridges' })]));
    root.appendChild(h('div', { className: 'controls' }, [
      h('div', { className: 'field' }, [h('label', { for: 'cip-search' }, ['Search']), search]),
      h('div', { className: 'field' }, [h('label', { for: 'cip-family' }, ['Family']), select])
    ]));
    root.appendChild(count);
    root.appendChild(list);
    refresh();
  }

  // ---------- detail view ----------

  function metaRow(term, value) {
    return h('div', { className: 'meta-row' }, [h('dt', { text: term }), h('dd', null, [value])]);
  }

  function capacityNode(rec) {
    var w = M.waterCapacity(rec);
    if (!w) return '—';
    var parts = [w.value + ' grH2O'];
    if (w.note) parts.push(' (' + w.note + ')');
    parts.push(' · source: ');
    if (w.url) {
      parts.push(h('a', { href: w.url, rel: 'noopener noreferrer' }, [w.source || w.url]));
    } else {
      parts.push(w.source);
    }
    return h('span', null, parts);
  }

  function metaList(rec) {
    var alt = (rec.alternativeNames || []).join(', ');
    return h('dl', { className: 'meta' }, [
      metaRow('Alternative names', alt || '—'),
      metaRow('Family', rec.family),
      metaRow('Category', rec.annotations.category),
      metaRow('Primer type', rec.annotations.primerType),
      metaRow('C.I.P. table', rec.tab),
      metaRow('Country', rec.country),
      metaRow('Published', rec.published),
      metaRow('Revised', rec.revised),
      metaRow('Pressure method', rec.pressureMethod),
      metaRow('Water capacity', capacityNode(rec))
    ]);
  }

  function valueTable(sectionObj) {
    var head = h('thead', null, [h('tr', null, [
      h('th', { scope: 'col', text: 'Symbol' }),
      h('th', { scope: 'col', className: 'num', text: 'Value' }),
      h('th', { scope: 'col', text: 'Unit' })
    ])]);
    var rows = sectionObj.rows.map(function (row) {
      return h('tr', null, [
        h('th', { scope: 'row', text: row.symbol }),
        h('td', { className: 'num', text: row.value }),
        h('td', { text: row.unit })
      ]);
    });
    if (rows.length === 0) {
      rows = [h('tr', null, [h('td', { colspan: 3, className: 'none', text: 'No values published' })])];
    }
    return h('table', null, [head, h('tbody', null, rows)]);
  }

  function sectionBlocks(sections) {
    return sections.map(function (s) {
      return h('section', { className: 'value-section' }, [
        h('h3', { text: s.id }),
        valueTable(s)
      ]);
    });
  }

  function valueTables(rec) {
    var sections = M.sections(rec);
    return h('div', { className: 'tables' }, [
      h('div', { className: 'table-col' }, [h('h2', { text: 'Cartridge values' })].concat(sectionBlocks(sections.cartridge))),
      h('div', { className: 'table-col' }, [h('h2', { text: 'Chamber values' })].concat(sectionBlocks(sections.chamber)))
    ]);
  }

  function drawingBlock(rec) {
    var d = D.build(rec);
    var figure = h('figure', { className: 'drawing' });
    if (d.ok) {
      figure.innerHTML = d.svg;
    } else {
      figure.appendChild(h('p', { className: 'note', text: 'Drawing not available: missing ' + d.missing.join(', ') + '.' }));
    }
    var notes = [];
    if (d.ok && d.missing.length) {
      notes.push(h('p', { className: 'note', text: 'Drawn without these rule inputs (not published): ' + d.missing.join(', ') + '.' }));
    }
    return h('div', { className: 'drawing-block' }, [figure].concat(notes));
  }

  function renderDetail(key) {
    var rec = records.filter(function (r) { return r.key === key; })[0];
    root.textContent = '';
    if (!rec) {
      setTitle('Not found · C.I.P. reference');
      root.appendChild(h('header', { className: 'page-head' }, [h('h1', { text: 'Cartridge not found' })]));
      root.appendChild(h('p', null, ['No cartridge has the key “' + key + '”.']));
      root.appendChild(h('p', null, [h('a', { href: '#/' }, ['All cartridges'])]));
      return;
    }
    setTitle(rec.name + ' · C.I.P. reference');
    root.appendChild(h('nav', { className: 'toolbar' }, [
      h('a', { href: '#/', className: 'back' }, ['All cartridges']),
      h('button', { type: 'button', className: 'print', onclick: function () { window.print(); } }, ['Print'])
    ]));
    root.appendChild(h('header', { className: 'page-head' }, [h('h1', { text: rec.name })]));
    root.appendChild(metaList(rec));
    root.appendChild(drawingBlock(rec));
    root.appendChild(valueTables(rec));
    root.appendChild(h('footer', { className: 'print-footer' }, [
      'Source: C.I.P. TDCC, revised ' + rec.revised + ' · ' + rec.name
    ]));
    window.scrollTo(0, 0);
  }

  // ---------- routing ----------

  function render() {
    var route = M.parseRoute(window.location.hash);
    if (route.view === 'detail') renderDetail(route.key);
    else renderList();
  }

  window.addEventListener('hashchange', render);
  render();
})();
