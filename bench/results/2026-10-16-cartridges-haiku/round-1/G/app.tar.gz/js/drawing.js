/*
 * Inline SVG drawing of a cartridge: outside view above the axis, half section below it.
 * 1 SVG unit = 1 mm. X is z (head on the left), Y is -r above the axis and +r below.
 * Attaches window.CIP.drawing. build(rec) returns the SVG string plus the label boxes and
 * outline polylines that the tests use to check the layout rules.
 */
(function () {
  'use strict';
  window.CIP = window.CIP || {};
  var F = window.CIP.format;
  var G = window.CIP.geometry;

  var FS = 3.0;            // label font size, mm
  var GLYPH = 0.56;        // average glyph width as a fraction of the font size
  var ARROW_L = 1.6;
  var ARROW_W = 0.5;
  var ROW_GAP = 4.6;       // spacing of the horizontal dimension rows
  var LANE_GAP = 5.4;      // spacing of the vertical diameter lanes
  var LANE_OFFSET = 6;     // first lane is this far beyond the tip
  var LEFT_LANE = -6;      // R1 lane, left of the head face
  var XMIN = -12;

  function num(v) {
    return (Math.round(v * 1000) / 1000).toString();
  }

  function pathOf(points, toXY) {
    return points.map(function (p, i) {
      var q = toXY(p);
      return (i === 0 ? 'M' : 'L') + num(q.x) + ' ' + num(q.y);
    }).join(' ');
  }

  function up(p) { return { x: p.z, y: -p.r }; }
  function down(p) { return { x: p.z, y: p.r }; }

  function polyline(points) {
    return points.map(function (p) { return { x: p.x, y: p.y }; });
  }

  // Estimated box of a text label, in SVG units. Anchor is 'start', 'middle' or 'end'.
  function horizontalBox(text, x, y, anchor) {
    var w = text.length * GLYPH * FS;
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0: x0, x1: x0 + w, y0: y - 0.75 * FS, y1: y + 0.25 * FS };
  }

  // Box of text rotated by -90 degrees, centred on y = yc, with its baseline at x = xb.
  function verticalBox(text, xb, yc) {
    var w = text.length * GLYPH * FS;
    return { x0: xb - 0.75 * FS, x1: xb + 0.25 * FS, y0: yc - w / 2, y1: yc + w / 2 };
  }

  // True when any outline segment passes within margin of the box. Segments are sampled.
  function touchesOutline(box, outlines, margin) {
    for (var i = 0; i < outlines.length; i++) {
      var line = outlines[i];
      for (var j = 1; j < line.length; j++) {
        var a = line[j - 1];
        var b = line[j];
        var n = Math.max(2, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 0.05));
        for (var k = 0; k <= n; k++) {
          var x = a.x + (b.x - a.x) * k / n;
          var y = a.y + (b.y - a.y) * k / n;
          if (x >= box.x0 - margin && x <= box.x1 + margin && y >= box.y0 - margin && y <= box.y1 + margin) return true;
        }
      }
    }
    return false;
  }

  function dimLabel(sym, value, tol) {
    return sym + ' ' + F.withTol(value, tol);
  }

  function arrowAt(x, y, dir) {
    // dir = +1 points the tip toward +x; the arrow lies on the dimension line through (x, y)
    var bx = x - dir * ARROW_L;
    return '<path class="arrow" d="M' + num(x) + ' ' + num(y) + ' L' + num(bx) + ' ' + num(y - ARROW_W) +
      ' L' + num(bx) + ' ' + num(y + ARROW_W) + ' Z"/>';
  }

  function arrowVertical(x, y, dirY) {
    // tip at (x, y); dirY = +1 points the tip toward +y
    var by = y - dirY * ARROW_L;
    return '<path class="arrow" d="M' + num(x) + ' ' + num(y) + ' L' + num(x - ARROW_W) + ' ' + num(by) +
      ' L' + num(x + ARROW_W) + ' ' + num(by) + ' Z"/>';
  }

  function build(rec) {
    var g = G.build(rec);
    if (!g.ok) return { ok: false, missing: g.missing, svg: '', labels: [], outlines: [] };

    var c = rec.cartridge;
    var ch = c.caseHead;
    var col = c.collar;
    var L = c.lengths;
    var pc = c.powderChamber;
    var pr = c.projectile;
    var jc = c.junctionCone;
    var labels = [];
    var outlines = [];
    var parts = [];
    var rMax = g.rMax;
    var L6 = L.L6;

    // Outside view, upper half: the case outline from the axis at the head face to the mouth.
    var upperCase = g.outer.map(up);
    outlines.push(polyline(upperCase));
    var bullet = g.bullet;
    var rExp = bullet ? bullet.rExp : g.H2h;
    var mouthUp = [{ x: L.L3, y: -g.H2h }, { x: L.L3, y: -rExp }];
    outlines.push(mouthUp);
    if (bullet) {
      var exposedUp = bullet.exposed.map(up);
      outlines.push(polyline(exposedUp));
      parts.push('<path class="outline" d="' + pathOf(exposedUp, function (q) { return q; }) + '"/>');
    }
    parts.push('<path class="outline" d="' + pathOf(upperCase, function (q) { return q; }) + '"/>');
    parts.push('<path class="outline" d="' + pathOf(mouthUp, function (q) { return q; }) + '"/>');

    // Section, lower half: solid case walls (hatched), cavity, primer pocket, seated bullet.
    var pocket = g.pocket;
    var cavity = g.cavity;
    var outerLow = g.outer.map(down);
    var innerLow = cavity.inner.map(down);
    var floorZ = cavity.floor.z;
    var solid = outerLow.concat([{ x: L.L3, y: 0 }]);
    var cavityPoly = [{ x: floorZ, y: 0 }].concat(innerLow, [{ x: L.L3, y: 0 }]);
    var pocketPoly = pocket ? [{ x: 0, y: 0 }, { x: 0, y: pocket.r }, { x: pocket.depth, y: pocket.r }, { x: pocket.depth, y: 0 }] : null;
    var hatchD = pathOf(solid, function (q) { return q; }) + ' Z ' + pathOf(cavityPoly, function (q) { return q; }) + ' Z';
    if (pocketPoly) hatchD += ' ' + pathOf(pocketPoly, function (q) { return q; }) + ' Z';
    var hatchId = 'cip-hatch-' + rec.key;
    parts.push('<pattern id="' + hatchId + '" patternUnits="userSpaceOnUse" width="1.4" height="1.4" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="1.4" class="hatch"/></pattern>');
    parts.push('<path class="section-fill" fill="url(#' + hatchId + ')" fill-rule="evenodd" d="' + hatchD + '"/>');

    var sectionOutline = [];
    if (pocket) sectionOutline.push({ z: 0, r: pocket.r });
    var sectionPts = (pocket ? sectionOutline : []).concat(g.outer.slice(1), cavity.inner.slice().reverse(), [{ z: floorZ, r: 0 }]);
    var sectionXY = sectionPts.map(down);
    outlines.push(polyline(sectionXY));
    parts.push('<path class="outline" d="' + pathOf(sectionXY, function (q) { return q; }) + '"/>');
    if (pocket) {
      var pocketXY = pocketPoly.slice(1, 4);
      outlines.push(polyline(pocketXY));
      parts.push('<path class="outline" d="' + pathOf(pocketXY, function (q) { return q; }) + '"/>');
    }

    if (bullet) {
      var seatedLow = [{ z: bullet.zb, r: 0 }].concat(bullet.seated, bullet.exposed);
      var bulletLowXY = seatedLow.map(down);
      outlines.push(polyline(bulletLowXY));
      parts.push('<path class="outline" d="' + pathOf(bulletLowXY, function (q) { return q; }) + '"/>');
    }

    // Dimension rows above the drawing, ordered so that extension lines do not cross other spans.
    var rowBase = -(rMax + 5);
    var rows = [];
    rows.push({ key: 'R', a: 0, b: g.R, fa: { x: 0, y: -g.R1h }, fb: { x: g.R, y: -g.R1h },
      text: dimLabel('R', F.number(ch.R), ch.RTol) });
    if (g.bottleneck) {
      rows.push({ key: 'L1', a: 0, b: L.L1, fa: { x: 0, y: -g.R1h }, fb: { x: L.L1, y: -g.P2h },
        text: dimLabel('L1', F.number(L.L1), L.L1Tol) });
      rows.push({ key: 'L2', a: 0, b: L.L2, fa: { x: 0, y: -g.R1h }, fb: { x: L.L2, y: -g.H1h },
        text: dimLabel('L2', F.number(L.L2), L.L2Tol) });
    }
    rows.push({ key: 'L3', a: 0, b: L.L3, fa: { x: 0, y: -g.R1h }, fb: { x: L.L3, y: -g.H2h },
      text: dimLabel('L3', F.number(L.L3), L.L3Tol) });
    var tipR = bullet ? bullet.m / 2 : 0;
    rows.push({ key: 'L6', a: 0, b: L6, fa: { x: 0, y: -g.R1h }, fb: { x: L6, y: -tipR },
      text: dimLabel('L6', F.number(L6), L.L6Tol) });
    rows.forEach(function (row, k) {
      row.y = rowBase - ROW_GAP * k;
    });

    rows.forEach(function (row) {
      var y = row.y;
      var extA = row.fa.y - 1;
      var extB = y - 1;
      parts.push('<path class="dim" d="M' + num(row.fa.x) + ' ' + num(extA) + ' L' + num(row.fa.x) + ' ' + num(extB) + '"/>');
      parts.push('<path class="dim" d="M' + num(row.fb.x) + ' ' + num(row.fb.y - 1) + ' L' + num(row.fb.x) + ' ' + num(extB) + '"/>');
      parts.push('<path class="dim" d="M' + num(row.a) + ' ' + num(y) + ' L' + num(row.b) + ' ' + num(y) + '"/>');
      parts.push(arrowAt(row.a, y, -1));
      parts.push(arrowAt(row.b, y, +1));
      var xm = (row.a + row.b) / 2;
      var box = horizontalBox(row.text, xm, y + 1.0, 'middle');
      labels.push({ text: row.text, box: box });
      parts.push('<text class="lbl" x="' + num(xm) + '" y="' + num(y + 1.0) + '" text-anchor="middle">' + F.escapeHtml(row.text) + '</text>');
    });

    // Angle dimension at the shoulder apex (outside view). The arc sits inside the case silhouette.
    if (g.alpha) {
      var al = g.alpha;
      var pts = [];
      for (var i = 0; i <= 12; i++) {
        var phi = al.halfAngle * i / 12;
        pts.push({ x: al.apexZ - al.radius * Math.cos(phi), y: -al.radius * Math.sin(phi) });
      }
      parts.push('<path class="dim" d="' + pathOf(pts, function (q) { return q; }) + '"/>');
      var end = pts[pts.length - 1];
      var prev = pts[pts.length - 2];
      var tx = end.x - prev.x, ty = end.y - prev.y;
      var tl = Math.hypot(tx, ty);
      tx /= tl; ty /= tl;
      var nx = -ty, ny = tx;
      parts.push('<path class="arrow" d="M' + num(end.x) + ' ' + num(end.y) + ' L' + num(end.x - tx * ARROW_L + nx * ARROW_W) + ' ' +
        num(end.y - ty * ARROW_L + ny * ARROW_W) + ' L' + num(end.x - tx * ARROW_L - nx * ARROW_W) + ' ' +
        num(end.y - ty * ARROW_L - ny * ARROW_W) + ' Z"/>');
      var alphaText = 'α ' + al.value;
      var ax = al.apexZ - 1.5;
      // Start above the neck and step up until the label clears the shoulder and case outline.
      var ay = -(Math.max(g.H2h, g.H1h) + 3.0);
      var alphaBox = horizontalBox(alphaText, ax, ay, 'end');
      for (var step = 0; step < 40 && touchesOutline(alphaBox, outlines, 0.5); step++) {
        ay -= 0.5;
        alphaBox = horizontalBox(alphaText, ax, ay, 'end');
      }
      labels.push({ text: alphaText, box: alphaBox });
      parts.push('<text class="lbl" x="' + num(ax) + '" y="' + num(ay) + '" text-anchor="end">' + F.escapeHtml(alphaText) + '</text>');
    }

    // Diameter lanes to the right of the tip. Lanes sorted by radius so extension lines do not cross lanes.
    var lanes = [];
    if (bullet) lanes.push({ key: 'G1', z: bullet.zc + 0.5, r: g.bullet.G1h, text: dimLabel('G1', F.number(pr.G1), pr.G1Tol) });
    if (g.bottleneck) lanes.push({ key: 'H1', z: L.L2 + 0.8, r: g.H1h, text: dimLabel('H1', F.number(col.H1), col.H1Tol) });
    lanes.push({ key: 'H2', z: L.L3 + 0.8, r: g.H2h, text: dimLabel('H2', F.number(col.H2), col.H2Tol) });
    if (g.groove) lanes.push({ key: 'E1', z: g.groove.floorMidZ, r: g.groove.E1h, text: dimLabel('E1', F.number(ch.E1), ch.E1Tol) });
    if (g.bottleneck) lanes.push({ key: 'P2', z: L.L1 + 0.8, r: g.P2h, text: dimLabel('P2', F.number(pc.P2), pc.P2Tol) });
    lanes.push({ key: 'P1', z: g.bodyStart + 0.8, r: g.P1h, text: dimLabel('P1', F.number(pc.P1), pc.P1Tol) });
    lanes.sort(function (a, b) { return a.r - b.r; });
    var laneX = function (i) { return L6 + LANE_OFFSET + LANE_GAP * i; };

    lanes.forEach(function (ln, i) {
      var x = laneX(i);
      parts.push('<path class="dim" d="M' + num(ln.z) + ' ' + num(-ln.r) + ' L' + num(x + 1) + ' ' + num(-ln.r) + '"/>');
      parts.push('<path class="dim" d="M' + num(ln.z) + ' ' + num(ln.r) + ' L' + num(x + 1) + ' ' + num(ln.r) + '"/>');
      parts.push('<path class="dim" d="M' + num(x) + ' ' + num(-ln.r) + ' L' + num(x) + ' ' + num(ln.r) + '"/>');
      parts.push(arrowVertical(x, -ln.r, -1));
      parts.push(arrowVertical(x, ln.r, +1));
      var xb = x + 1 + 0.75 * FS;
      labels.push({ text: ln.text, box: verticalBox(ln.text, xb, 0) });
      parts.push('<text class="lbl" transform="rotate(-90 ' + num(xb) + ' 0)" x="' + num(xb) + '" y="0" text-anchor="middle">' + F.escapeHtml(ln.text) + '</text>');
    });

    // R1 lane, left of the head face.
    var r1Text = dimLabel('R1', F.number(ch.R1), ch.R1Tol);
    parts.push('<path class="dim" d="M0 ' + num(-g.R1h - 0.0) + ' L' + num(LEFT_LANE - 1) + ' ' + num(-g.R1h) + '"/>');
    parts.push('<path class="dim" d="M0 ' + num(g.R1h) + ' L' + num(LEFT_LANE - 1) + ' ' + num(g.R1h) + '"/>');
    parts.push('<path class="dim" d="M' + num(LEFT_LANE) + ' ' + num(-g.R1h) + ' L' + num(LEFT_LANE) + ' ' + num(g.R1h) + '"/>');
    parts.push(arrowVertical(LEFT_LANE, -g.R1h, -1));
    parts.push(arrowVertical(LEFT_LANE, g.R1h, +1));
    var r1xb = LEFT_LANE - 1 - 0.25 * FS;
    labels.push({ text: r1Text, box: verticalBox(r1Text, r1xb, 0) });
    parts.push('<text class="lbl" transform="rotate(-90 ' + num(r1xb) + ' 0)" x="' + num(r1xb) + '" y="0" text-anchor="middle">' + F.escapeHtml(r1Text) + '</text>');

    // Dash-dot centre line from the head face to just past the tip.
    var axisEnd = L6 + 2;
    parts.push('<path class="axis" d="M0 0 L' + num(axisEnd) + ' 0"/>');

    // Title block below the drawing.
    var tbTop = rMax + 3;
    var tbBottom = tbTop + 15;
    var tbLeft = XMIN + 1;
    var lanesEnd = laneX(lanes.length - 1) + 4;
    var tbRight = Math.max(lanesEnd, L6 + 2);
    var xMaxVB = tbRight + 1;
    parts.push('<rect class="tb" x="' + num(tbLeft) + '" y="' + num(tbTop) + '" width="' + num(tbRight - tbLeft) +
      '" height="' + num(tbBottom - tbTop) + '"/>');
    parts.push('<text class="tb-name" x="' + num(tbLeft + 2) + '" y="' + num(tbTop + 5.5) + '">' + F.escapeHtml(rec.name) + '</text>');
    parts.push('<text class="tb-text" x="' + num(tbLeft + 2) + '" y="' + num(tbTop + 9.6) + '">C.I.P. table ' +
      F.escapeHtml(rec.tab) + ' · revised ' + F.escapeHtml(rec.revised) + '</text>');
    parts.push('<text class="tb-text" x="' + num(tbLeft + 2) + '" y="' + num(tbTop + 13) + '">Dimensions in mm</text>');
    parts.push('<text class="tb-text" x="' + num(tbRight - 2) + '" y="' + num(tbTop + 13) + '" text-anchor="end">Scale 1:1</text>');

    // The viewBox grows to take in every label, so nothing is clipped.
    var yMinVB = rowBase - ROW_GAP * (rows.length - 1) - 3.5;
    var x0VB = XMIN;
    labels.forEach(function (l) {
      x0VB = Math.min(x0VB, l.box.x0 - 1);
      xMaxVB = Math.max(xMaxVB, l.box.x1 + 1);
      yMinVB = Math.min(yMinVB, l.box.y0 - 1);
    });
    var viewBox = [x0VB, yMinVB, xMaxVB - x0VB, tbBottom + 1 - yMinVB];
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" class="cip-drawing" role="img" aria-label="' +
      F.escapeHtml(rec.name) + ' drawing" viewBox="' + viewBox.map(num).join(' ') + '">' +
      '<title>' + F.escapeHtml(rec.name) + ' drawing</title>' + parts.join('') + '</svg>';

    return {
      ok: true,
      missing: g.missing,
      svg: svg,
      viewBox: viewBox,
      labels: labels,
      outlines: outlines,
      titleBlock: { top: tbTop, bottom: tbBottom }
    };
  }

  window.CIP.drawing = { build: build };
})();
