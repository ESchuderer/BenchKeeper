/*
 * Value formatting: numbers as published, angles, units, symbols, tolerances.
 * Attaches window.CIP.format.
 */
(function () {
  'use strict';
  window.CIP = window.CIP || {};

  // Field names whose published symbol differs from the field name.
  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  // Angle fields: a number is degrees; an object is {degrees, minutes, seconds}.
  var ANGLE_FIELDS = { alpha: true, alpha1: true, beta: true, delta: true, i: true };

  // Units by field name; anything not listed is a length or diameter in mm.
  var UNITS = {
    Pmax: 'bar', PK: 'bar', PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: ''
  };

  function number(v) {
    return String(Number(v));
  }

  function pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function isAngleObject(v) {
    return v !== null && typeof v === 'object' && 'degrees' in v;
  }

  function angleDegrees(v) {
    if (isAngleObject(v)) {
      return Number(v.degrees) + Number(v.minutes || 0) / 60 + Number(v.seconds || 0) / 3600;
    }
    return Number(v);
  }

  function angle(v) {
    if (isAngleObject(v)) {
      return v.degrees + '°' + pad2(v.minutes) + '\'' + pad2(v.seconds) + '"';
    }
    return number(v) + '°';
  }

  function isAngleField(key) {
    return ANGLE_FIELDS[key] === true;
  }

  function value(key, v) {
    if (isAngleField(key)) return angle(v);
    return number(v);
  }

  function withTol(valueText, tol) {
    if (tol === undefined || tol === null) return valueText;
    return valueText + ' ' + number(tol);
  }

  function symbol(key) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, key) ? SYMBOLS[key] : key;
  }

  function unit(key) {
    if (isAngleField(key)) return ''; // the angle itself already carries the degree sign
    if (Object.prototype.hasOwnProperty.call(UNITS, key)) return UNITS[key];
    return 'mm';
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  window.CIP.format = {
    number: number,
    angle: angle,
    angleDegrees: angleDegrees,
    isAngleObject: isAngleObject,
    isAngleField: isAngleField,
    value: value,
    withTol: withTol,
    symbol: symbol,
    unit: unit,
    escapeHtml: escapeHtml
  };
})();
