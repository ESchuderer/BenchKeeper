/*
 * Case, cavity, primer pocket and bullet geometry, computed from a record by the brief's rules.
 * Points are {z, r}: z runs from the head face (z = 0) to the mouth, r is the radius, both in mm.
 * Attaches window.CIP.geometry. Pure functions, no DOM.
 */
(function () {
  'use strict';
  window.CIP = window.CIP || {};
  var F = window.CIP.format;
  var M = window.CIP.model;

  var DEG = Math.PI / 180;

  function has(v) {
    return v !== undefined && v !== null;
  }

  function clamp(v, lo, hi) {
    return Math.min(hi, Math.max(lo, v));
  }

  function unit2(dz, dr) {
    var len = Math.hypot(dz, dr);
    return len === 0 ? null : { z: dz / len, r: dr / len };
  }

  function sameAs(a, b) {
    return a.z === b.z && a.r === b.r;
  }

  function dedupe(points) {
    return points.filter(function (p, i) { return i === 0 || !sameAs(p, points[i - 1]); });
  }

  // Piecewise-linear radius along a polyline of {z, r} sorted by z; clamps at both ends.
  function radiusAt(line, z) {
    if (z <= line[0].z) return line[0].r;
    for (var i = 1; i < line.length; i++) {
      var a = line[i - 1];
      var b = line[i];
      if (z <= b.z) {
        var t = b.z === a.z ? 0 : (z - a.z) / (b.z - a.z);
        return a.r + (b.r - a.r) * t;
      }
    }
    return line[line.length - 1].r;
  }

  // Rounds the corner at V between segments A-V and V-B with radius rad (brief rule 5).
  // Returns the arc points from the first tangent point to the second; [V] when there is no bend.
  function fillet(A, V, B, rad) {
    var d1 = unit2(V.z - A.z, V.r - A.r);
    var d2 = unit2(B.z - V.z, B.r - V.r);
    if (!d1 || !d2 || !(rad > 0)) return [V];
    var delta = Math.acos(clamp(d1.z * d2.z + d1.r * d2.r, -1, 1));
    if (delta < 1e-9) return [V];
    var lenA = Math.hypot(V.z - A.z, V.r - A.r);
    var lenB = Math.hypot(B.z - V.z, B.r - V.r);
    var t = rad * Math.tan(delta / 2);
    var maxT = 0.5 * Math.min(lenA, lenB);
    if (t > maxT) {
      t = maxT;
      rad = t / Math.tan(delta / 2);
    }
    var T1 = { z: V.z - d1.z * t, r: V.r - d1.r * t };
    var T2 = { z: V.z + d2.z * t, r: V.r + d2.r * t };
    var cross = d1.z * d2.r - d1.r * d2.z;
    var nz = cross > 0 ? -d1.r : d1.r;
    var nr = cross > 0 ? d1.z : -d1.z;
    var C = { z: T1.z + nz * rad, r: T1.r + nr * rad };
    var a1 = Math.atan2(T1.r - C.r, T1.z - C.z);
    var a2 = Math.atan2(T2.r - C.r, T2.z - C.z);
    var diff = a2 - a1;
    while (diff > Math.PI) diff -= 2 * Math.PI;
    while (diff < -Math.PI) diff += 2 * Math.PI;
    var n = Math.max(2, Math.ceil(Math.abs(diff) / (Math.PI / 24)));
    var out = [];
    for (var i = 0; i <= n; i++) {
      var a = a1 + diff * i / n;
      out.push({ z: C.z + rad * Math.cos(a), r: C.r + rad * Math.sin(a) });
    }
    return out;
  }

  // Bullet seating, cylinder fraction, meplat and nose type from the default bullet shape (rule 7).
  function bulletSpec(shape, category, G1) {
    var rifle = category !== 'pistol';
    switch (shape) {
      case 'pointy':
        return { s: 1.0 * G1, k: 0.40, m: Math.max(0.08 * G1, 1.27), nose: 'ogive' };
      case 'rounded':
        return { s: (rifle ? 0.8 : 0.4) * G1, k: rifle ? 0.55 : 0.65, m: 0.15 * G1, nose: 'ellipse' };
      case 'flat':
        return { s: (rifle ? 0.8 : 0.4) * G1, k: rifle ? 0.60 : 0.70, m: 0.55 * G1, nose: 'cone' };
      case 'semi_wadcutter':
        return { s: 0.6 * G1, k: 0.78, m: 0.6 * G1, nose: 'cone' };
      default:
        return null;
    }
  }

  function noseSamples(nose, zc, n, G1h, m, L6) {
    var out = [];
    var N = 24;
    if (nose === 'ogive') {
      var a = G1h - m / 2;
      var rho = (a * a + n * n) / (2 * a);
      var cx = G1h - rho;
      var thetaT = Math.atan2(n, rho - a);
      for (var i = 1; i <= N; i++) {
        var th = thetaT * i / N;
        out.push({ z: zc + rho * Math.sin(th), r: cx + rho * Math.cos(th) });
      }
    } else if (nose === 'ellipse') {
      var A = G1h - m / 2;
      for (var j = 1; j <= N; j++) {
        var t = (Math.PI / 2) * j / N;
        out.push({ z: zc + n * Math.sin(t), r: m / 2 + A * Math.cos(t) });
      }
    } else {
      out.push({ z: L6, r: m / 2 });
    }
    return out;
  }

  function build(rec) {
    var c = rec.cartridge || {};
    var ann = rec.annotations || {};
    var ch = c.caseHead || {};
    var col = c.collar || {};
    var jc = c.junctionCone || {};
    var L = c.lengths || {};
    var pc = c.powderChamber || {};
    var pr = c.projectile || {};
    var missing = [];
    var note = function (name) { if (missing.indexOf(name) === -1) missing.push(name); };

    var rim = M.rimType(rec);
    var required = [['caseHead.R1', ch.R1], ['powderChamber.P1', pc.P1], ['caseHead.R', ch.R],
      ['collar.H2', col.H2], ['lengths.L3', L.L3], ['lengths.L6', L.L6]];
    var absent = required.filter(function (x) { return !has(x[1]); }).map(function (x) { return x[0]; });
    if (absent.length) return { ok: false, rim: rim, missing: absent, outer: [] };

    var R = ch.R;
    var R1h = ch.R1 / 2;
    var P1h = pc.P1 / 2;
    var H2h = col.H2 / 2;
    var L3 = L.L3;
    var L6 = L.L6;

    // Head face and rim edge (rule 2).
    var pts = [{ z: 0, r: 0 }];
    var rho = 0;
    var betaDeg = has(ch.beta) ? F.angleDegrees(ch.beta) : 0;
    var chamfer = has(ch.beta) && has(ch.f) && betaDeg > 0 && betaDeg < 90;
    if (has(ch.f) && !has(ch.beta)) note('caseHead.beta');
    if (has(ch.beta) && betaDeg > 0 && !has(ch.f)) note('caseHead.f');
    if (rim === 'rimfire') {
      rho = Math.min(R / 2, (ch.R1 - pc.P1) / 2);
      var cr = R1h - rho;
      for (var i = 0; i <= 24; i++) {
        var phi = -Math.PI / 2 + Math.PI * i / 24;
        pts.push({ z: rho + rho * Math.sin(phi), r: cr + rho * Math.cos(phi) });
      }
    } else if (chamfer) {
      var x = Math.min(ch.f * Math.tan(betaDeg * DEG), R1h / 2);
      pts.push({ z: 0, r: R1h - x });
      if (ch.f < R) pts.push({ z: ch.f, r: R1h });
      pts.push({ z: R, r: R1h });
    } else {
      pts.push({ z: 0, r: R1h }, { z: R, r: R1h });
    }
    var top = pts[pts.length - 1];
    var zTop = top.z;

    // Extractor groove or step to the body (rule 3).
    var E = ch.E;
    var E1 = ch.E1;
    var hasGroove = has(E) && has(E1);
    if (has(E) !== has(E1)) note(has(E) ? 'caseHead.E1' : 'caseHead.E');
    var trans = [];
    var bodyStart;
    var beltEnd = null;
    var groove = null;
    if (hasGroove) {
      var E1h = E1 / 2;
      if (!has(ch.eMin)) note('caseHead.eMin');
      var floorEnd = zTop + (has(ch.eMin) ? ch.eMin : 0);
      trans.push({ z: zTop, r: E1h }, { z: floorEnd, r: E1h });
      groove = { E: E, E1h: E1h, floorMidZ: (zTop + floorEnd) / 2 };
      bodyStart = E;
      var belted = rim === 'belted' && has(ch.delta);
      if (rim === 'belted' && !has(ch.delta)) note('caseHead.delta');
      if (belted) {
        var R3h = (has(ch.R3) ? ch.R3 : ch.R1) / 2;
        if (!has(ch.R3)) note('caseHead.R3');
        var zr = floorEnd + (R3h - E1h) / Math.tan(F.angleDegrees(ch.delta) * DEG);
        trans.push({ z: zr, r: R3h }, { z: E, r: R3h }, { z: E, r: P1h });
        beltEnd = zr;
        groove.belt = { R3h: R3h, rampEndZ: zr };
      } else {
        trans.push({ z: E, r: P1h });
      }
    } else {
      trans.push({ z: zTop, r: P1h });
      bodyStart = zTop;
    }

    // Body, shoulder and neck (rule 4 and 5).
    var alphaPresent = has(jc.alpha);
    var bottleneck = alphaPresent && has(L.L1) && has(L.L2) && has(pc.P2) && has(col.H1);
    if (alphaPresent && !bottleneck) {
      [['junctionCone.alpha', true], ['lengths.L1', has(L.L1)], ['lengths.L2', has(L.L2)],
        ['powderChamber.P2', has(pc.P2)], ['collar.H1', has(col.H1)]]
        .forEach(function (x) { if (!x[1]) note(x[0]); });
    }
    var P2h = bottleneck ? pc.P2 / 2 : 0;
    var H1h = bottleneck ? col.H1 / 2 : 0;
    var bodyLine = [{ z: bodyStart, r: P1h }];
    if (bottleneck) {
      bodyLine.push({ z: L.L1, r: P2h }, { z: L.L2, r: H1h });
    }
    bodyLine.push({ z: L3, r: H2h });

    var outer = dedupe(pts.concat(trans, bodyLine.slice(1)));

    if (bottleneck) {
      var bodyCorner = { z: L.L1, r: P2h };
      var neckCorner = { z: L.L2, r: H1h };
      if (has(jc.r1Min)) outer = replaceVertex(outer, bodyCorner, jc.r1Min);
      if (has(jc.r2)) outer = replaceVertex(outer, neckCorner, jc.r2);
    }

    // Wall thickness (rule 8). tn is the neck wall, tb the body wall.
    var G1 = pr.G1;
    var tn = has(G1) ? Math.max(0, (col.H2 - G1) / 2) : 0;
    if (!has(G1)) note('projectile.G1');
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1h);
    var heeled = has(G1) && (col.H2 - G1) <= 0.015;
    var tnStraight = heeled ? tb : tn;
    function wallAt(z) {
      if (bottleneck) {
        if (z <= L.L1) return tb;
        if (z >= L.L2) return tn;
        return tb + (tn - tb) * (z - L.L1) / (L.L2 - L.L1);
      }
      var t = clamp((z - bodyStart) / (L3 - bodyStart), 0, 1);
      return tb + (tnStraight - tb) * t;
    }

    // Primer pocket (rule 8). Rimfire has no pocket.
    var pk = M.primerPocket(ann.primerType);
    var pocket = pk ? { diameter: pk.diameter, depth: pk.depth, r: pk.diameter / 2 } : null;

    // Solid head: cavity floor at z = w.
    var w = Math.max(2.5, 0.25 * P1h);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (hasGroove) w = Math.max(w, E + tb);
    if (beltEnd !== null) w = Math.max(w, beltEnd + tb);
    w = Math.max(w, bodyStart + tb);

    var inner = [{ z: w, r: radiusAt(bodyLine, w) - wallAt(w) }];
    bodyLine.slice(1, -1).forEach(function (p) {
      if (p.z > w) inner.push({ z: p.z, r: p.r - wallAt(p.z) });
    });
    inner.push({ z: L3, r: H2h - wallAt(L3) });

    // Bullet (rule 7) and its seated part (rule 7 and 8).
    var bullet = null;
    var spec = has(G1) ? bulletSpec(ann.defaultBulletShape, ann.category, G1) : null;
    if (spec) {
      var G1h = G1 / 2;
      var zb = L3 - spec.s;
      var zc = zb + spec.k * (L6 - zb);
      var n = L6 - zc;
      var rExp = heeled ? H2h : G1h;
      var rHeel = heeled ? H2h - tb : undefined;
      var seatedR = function (z) {
        return heeled ? rHeel : Math.min(G1h, radiusAt(inner, z));
      };
      var seated = [];
      for (var k = 0; k <= 32; k++) {
        var zs = zb + (L3 - zb) * k / 32;
        seated.push({ z: zs, r: seatedR(zs) });
      }
      var exposed = [{ z: L3, r: rExp }, { z: zc, r: rExp }]
        .concat(noseSamples(spec.nose, zc, n, G1h, spec.m, L6));
      if (spec.nose !== 'cone') exposed.push({ z: L6, r: spec.m / 2 });
      exposed.push({ z: L6, r: 0 });
      bullet = {
        shape: ann.defaultBulletShape, category: ann.category,
        s: spec.s, k: spec.k, m: spec.m, n: n, zb: zb, Lb: L6 - zb, zc: zc, zTip: L6, G1h: G1h,
        rExp: rExp, heeled: heeled, rHeel: rHeel, seated: seated, exposed: exposed
      };
    } else if (has(G1)) {
      note('defaultBulletShape');
    }

    // Shoulder angle: apex of the drawn cone and its half angle (rule 5, α label).
    var alpha = null;
    if (bottleneck) {
      var slope = (H1h - P2h) / (L.L2 - L.L1);
      var apexZ = L.L1 - P2h / slope;
      var halfAngle = Math.atan(-slope);
      alpha = {
        apexZ: apexZ,
        halfAngle: halfAngle,
        radius: Math.min(5, 0.6 * Math.hypot(apexZ - L.L2, H1h)),
        value: F.value('alpha', jc.alpha)
      };
    }

    var rMax = 0;
    outer.forEach(function (p) { if (p.r > rMax) rMax = p.r; });

    return {
      ok: true,
      rim: rim,
      missing: missing,
      bottleneck: bottleneck,
      heeled: heeled,
      bodyStart: bodyStart,
      zTop: zTop,
      rTop: top.r,
      R: R,
      rho: rho,
      R1h: R1h,
      P1h: P1h,
      P2h: P2h,
      H1h: H1h,
      H2h: H2h,
      rMax: rMax,
      L1: L.L1,
      L2: L.L2,
      L3: L3,
      L6: L6,
      groove: groove,
      pocket: pocket,
      walls: { tn: tn, tb: tb },
      outer: outer,
      cavity: { floor: inner[0], inner: inner },
      bullet: bullet,
      alpha: alpha
    };
  }

  function replaceVertex(points, vertex, rad) {
    var i = points.findIndex(function (p) { return sameAs(p, vertex); });
    if (i <= 0 || i >= points.length - 1) return points;
    var arc = fillet(points[i - 1], points[i], points[i + 1], rad);
    return points.slice(0, i).concat(arc, points.slice(i + 1));
  }

  window.CIP.geometry = {
    build: build,
    fillet: fillet,
    radiusAt: radiusAt
  };
})();
