/*
 * Record model: rim type, table sections, search and family filter, routes, primer pockets.
 * Attaches window.CIP.model. Pure functions, no DOM.
 */
(function () {
  'use strict';
  window.CIP = window.CIP || {};
  var F = window.CIP.format;

  var CARTRIDGE_SECTIONS = ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile'];
  var CHAMBER_SECTIONS = ['barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling'];

  // Centrefire primer pockets: diameter and depth by primer type (brief, rule 8).
  var POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 }
  };

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    var ch = rec.cartridge.caseHead;
    var pc = rec.cartridge.powderChamber;
    if (!ch || !pc || ch.R1 === undefined || pc.P1 === undefined) return 'rimless';
    var ratio = ch.R1 / pc.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function primerPocket(primerType) {
    if (!Object.prototype.hasOwnProperty.call(POCKETS, primerType)) return null;
    return { diameter: POCKETS[primerType].diameter, depth: POCKETS[primerType].depth };
  }

  // Rows for one section. Every non-Tol field becomes a row; its <field>Tol, if present, is folded into the value.
  function rowsOf(sectionObj) {
    var rows = [];
    if (!sectionObj) return rows;
    Object.keys(sectionObj).forEach(function (key) {
      if (/Tol$/.test(key)) return;
      var v = sectionObj[key];
      var tolKey = key + 'Tol';
      var tol = Object.prototype.hasOwnProperty.call(sectionObj, tolKey) ? sectionObj[tolKey] : undefined;
      var unitText = F.unit(key);
      rows.push({
        key: key,
        symbol: F.symbol(key),
        value: F.withTol(F.value(key, v), tol),
        unit: unitText === '' ? '—' : unitText
      });
    });
    return rows;
  }

  function sections(rec) {
    var c = rec.cartridge || {};
    var ch = rec.chamber || {};
    return {
      cartridge: CARTRIDGE_SECTIONS.filter(function (id) { return c[id] !== undefined; })
        .map(function (id) { return { id: id, rows: rowsOf(c[id]) }; }),
      chamber: CHAMBER_SECTIONS.filter(function (id) { return ch[id] !== undefined; })
        .map(function (id) { return { id: id, rows: rowsOf(ch[id]) }; })
    };
  }

  function normalise(s) {
    return String(s).toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function searchTexts(rec) {
    var names = [rec.name].concat(rec.alternativeNames || []);
    return names.map(normalise);
  }

  function matches(rec, query) {
    var q = normalise(query);
    if (q === '') return true;
    var qCompact = q.replace(/ /g, '');
    return searchTexts(rec).some(function (t) {
      return t.indexOf(q) !== -1 || t.replace(/ /g, '').indexOf(qCompact) !== -1;
    });
  }

  function filter(records, opts) {
    var family = (opts && opts.family) || 'all';
    var query = (opts && opts.query) || '';
    return records.filter(function (rec) {
      if (family !== 'all' && rec.family !== family) return false;
      return matches(rec, query);
    });
  }

  function countLabel(n) {
    return n + (n === 1 ? ' cartridge' : ' cartridges');
  }

  function parseRoute(hash) {
    var m = /^#\/cartridge\/(.+)$/.exec(hash || '');
    if (m) return { view: 'detail', key: decodeURIComponent(m[1]) };
    return { view: 'list' };
  }

  function waterCapacity(rec) {
    var p = rec.annotations && rec.annotations.publishedCapacity;
    if (!p) return null;
    return { value: F.number(p.grH2O), note: p.note || '', source: p.source || '', url: p.url || '' };
  }

  window.CIP.model = {
    rimType: rimType,
    primerPocket: primerPocket,
    sections: sections,
    filter: filter,
    countLabel: countLabel,
    parseRoute: parseRoute,
    waterCapacity: waterCapacity
  };
})();
