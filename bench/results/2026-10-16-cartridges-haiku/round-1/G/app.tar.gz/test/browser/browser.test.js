'use strict';
// Browser checks against index.html opened from file://. Run with: npm run test:browser
const test = require('node:test');
const { before, after } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');

const INDEX = pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;
const SHOTS = process.env.CIP_SHOTS || '';

let browser;
let context;
const requests = [];
const consoleErrors = [];

before(async () => {
  browser = await chromium.launch();
});

after(async () => {
  await browser.close();
});

async function newPage(opts = {}) {
  context = await browser.newContext({ colorScheme: opts.colorScheme || 'light', viewport: opts.viewport || { width: 1280, height: 900 } });
  const page = await context.newPage();
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  page.on('pageerror', (e) => consoleErrors.push(String(e)));
  page.on('request', (r) => { if (!r.url().startsWith('file:')) requests.push(r.url()); });
  return page;
}

test('list: heading, 25 links, count, search and family filter', async () => {
  const page = await newPage();
  await page.goto(INDEX);
  await page.waitForSelector('h1');
  assert.equal(await page.textContent('h1'), 'Cartridges');
  assert.equal(await page.locator('ul.list a.name').count(), 25);
  assert.equal(await page.textContent('.count'), '25 cartridges');
  assert.equal(await page.locator('ul.list a.name', { hasText: /^223 Rem\.$/ }).count(), 1);

  await page.fill('#cip-search', '7,62 x 51');
  assert.equal(await page.locator('ul.list a.name').count(), 1);
  assert.equal(await page.textContent('ul.list a.name'), '308 Win.');
  assert.equal(await page.textContent('.count'), '1 cartridge');

  await page.fill('#cip-search', '');
  await page.selectOption('#cip-family', 'rimfire');
  assert.equal(await page.locator('ul.list a.name').count(), 3);
  assert.equal(await page.textContent('.count'), '3 cartridges');
  await page.close();
});

test('detail: route survives reload, drawing and tables present, back link works', async () => {
  const page = await newPage();
  await page.goto(INDEX + '#/cartridge/223_rem');
  await page.waitForSelector('h1');
  assert.equal(await page.textContent('h1'), '223 Rem.');
  await page.reload();
  await page.waitForSelector('h1');
  assert.equal(await page.textContent('h1'), '223 Rem.');
  assert.equal(await page.getAttribute('svg.cip-drawing', 'aria-label'), '223 Rem. drawing');
  assert.ok(await page.locator('table').count() >= 16);
  assert.ok(await page.locator('button.print').count() === 1);
  await page.click('a.back');
  await page.waitForSelector('ul.list');
  assert.equal(await page.locator('ul.list a.name').count(), 25);
  await page.close();
});

test('list links open the detail view by name', async () => {
  const page = await newPage();
  await page.goto(INDEX);
  await page.click('ul.list a.name:text-is("9 mm Luger")');
  await page.waitForFunction(() => document.querySelector('h1').textContent === '9 mm Luger');
  assert.equal(await page.textContent('h1'), '9 mm Luger');
  assert.match(page.url(), /#\/cartridge\/9_mm_luger$/);
  await page.close();
});

test('every detail view draws and prints on one A4 page', async () => {
  const page = await newPage();
  const keys = JSON.parse(await page.evaluate(() => JSON.stringify(window.CIP_RECORDS.map((r) => r.key))).catch(() => '[]'));
  await page.goto(INDEX);
  const recordKeys = await page.evaluate(() => window.CIP_RECORDS.map((r) => r.key));
  assert.equal(recordKeys.length, 25);
  for (const key of recordKeys) {
    await page.goto(INDEX + '#/cartridge/' + key);
    await page.waitForSelector('svg.cip-drawing');
    await page.emulateMedia({ media: 'print' });
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    assert.equal(pages, 1, `${key} prints on ${pages} pages`);
    await page.emulateMedia({ media: 'screen' });
  }
  assert.ok(keys.length >= 0);
  await page.close();
});

test('phone width: no horizontal overflow on the detail view', async () => {
  const page = await newPage({ viewport: { width: 390, height: 844 } });
  for (const key of ['223_rem', '300_win_mag', '22_long_rifle', '338_lapua_mag']) {
    await page.goto(INDEX + '#/cartridge/' + key);
    await page.waitForSelector('svg.cip-drawing');
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assert.ok(overflow <= 1, `${key} overflows by ${overflow}px`);
    if (SHOTS) await page.screenshot({ path: path.join(SHOTS, `phone-${key}.png`), fullPage: true });
  }
  await page.close();
});

test('dark scheme and desktop screenshots', async () => {
  const dark = await newPage({ colorScheme: 'dark' });
  await dark.goto(INDEX + '#/cartridge/300_win_mag');
  await dark.waitForSelector('svg.cip-drawing');
  const bg = await dark.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.notEqual(bg, 'rgb(255, 255, 255)', 'dark background applied');
  if (SHOTS) await dark.screenshot({ path: path.join(SHOTS, 'dark-300_win_mag.png'), fullPage: true });
  await dark.close();
  const light = await newPage();
  await light.goto(INDEX + '#/cartridge/223_rem');
  await light.waitForSelector('svg.cip-drawing');
  if (SHOTS) await light.screenshot({ path: path.join(SHOTS, 'light-223_rem.png'), fullPage: true });
  await light.emulateMedia({ media: 'print' });
  if (SHOTS) await light.pdf({ path: path.join(SHOTS, 'print-223_rem.pdf'), preferCSSPageSize: true, printBackground: true });
  await light.close();
});

test('no network requests leave the file, and no console errors', () => {
  assert.deepEqual(requests, []);
  assert.deepEqual(consoleErrors, []);
});
