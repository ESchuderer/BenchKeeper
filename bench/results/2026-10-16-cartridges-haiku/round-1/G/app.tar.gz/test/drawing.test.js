'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { load, byKey } = require('./helpers');

const ctx = load();
const { drawing } = ctx.CIP;
const draw = (k) => drawing.build(byKey(ctx, k));

function overlaps(a, b, m = 0) {
  return a.x0 < b.x1 + m && b.x0 < a.x1 + m && a.y0 < b.y1 + m && b.y0 < a.y1 + m;
}

// Samples each outline segment and reports whether any sample lies inside the box grown by margin.
function touches(box, polylines, margin) {
  for (const line of polylines) {
    for (let i = 1; i < line.length; i++) {
      const a = line[i - 1];
      const b = line[i];
      const n = Math.max(2, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 0.05));
      for (let k = 0; k <= n; k++) {
        const x = a.x + (b.x - a.x) * k / n;
        const y = a.y + (b.y - a.y) * k / n;
        if (x >= box.x0 - margin && x <= box.x1 + margin && y >= box.y0 - margin && y <= box.y1 + margin) return true;
      }
    }
  }
  return false;
}

test('every record draws an accessible SVG with a viewBox in mm', () => {
  for (const rec of ctx.CIP_RECORDS) {
    const d = drawing.build(rec);
    assert.equal(d.ok, true, rec.key);
    assert.ok(d.svg.startsWith('<svg'), rec.key);
    const escaped = rec.name.replace(/&/g, '&amp;');
    assert.ok(d.svg.includes(`role="img" aria-label="${escaped} drawing"`), rec.key);
    assert.ok(d.viewBox[2] > 45 && d.viewBox[2] < 260, `${rec.key} width ${d.viewBox[2]}`);
  }
});

test('labels never overlap each other (all records)', () => {
  for (const rec of ctx.CIP_RECORDS) {
    const { labels } = drawing.build(rec);
    for (let i = 0; i < labels.length; i++) {
      for (let j = i + 1; j < labels.length; j++) {
        assert.ok(!overlaps(labels[i].box, labels[j].box), `${rec.key}: "${labels[i].text}" overlaps "${labels[j].text}"`);
      }
    }
  }
});

test('labels never touch the outline (all records)', () => {
  for (const rec of ctx.CIP_RECORDS) {
    const { labels, outlines } = drawing.build(rec);
    for (const l of labels) {
      assert.ok(!touches(l.box, outlines, 0.3), `${rec.key}: "${l.text}" touches the outline`);
    }
  }
});

test('labels lie inside the viewBox (all records)', () => {
  for (const rec of ctx.CIP_RECORDS) {
    const d = drawing.build(rec);
    const [x, y, w, h] = d.viewBox;
    for (const l of d.labels) {
      assert.ok(l.box.x0 >= x && l.box.x1 <= x + w && l.box.y0 >= y && l.box.y1 <= y + h, `${rec.key}: ${l.text}`);
    }
  }
});

test('223 Rem labels carry symbol, value and tolerance', () => {
  const texts = draw('223_rem').labels.map((l) => l.text);
  for (const t of ['R 1.14', 'L1 36.52 -0.2', 'L2 39.55 -0.2', 'L3 44.7', 'L6 57.4', 'R1 9.6', 'P1 9.58', 'P2 9 -0.2', 'H2 6.43', 'G1 5.7', 'E1 8.43', 'α 46°']) {
    assert.ok(texts.includes(t), `missing label ${t}; got ${texts.join(' | ')}`);
  }
});

test('the case outline is to scale: head at 0, mouth at L3, rim radius R1/2', () => {
  const d = draw('223_rem');
  const upper = d.outlines[0];
  const xs = upper.map((p) => p.x);
  const ys = upper.map((p) => p.y);
  assert.equal(Math.min(...xs), 0);
  assert.ok(Math.abs(Math.max(...xs) - 44.7) < 1e-9, 'mouth at z = L3');
  assert.ok(Math.abs(Math.min(...ys) + 9.6 / 2) < 1e-9, 'rim radius R1/2 above the axis');
});

test('the section is below the axis and the outside view above it', () => {
  const d = draw('223_rem');
  const lowerSection = d.outlines[d.outlines.length - 1];
  assert.ok(lowerSection.every((p) => p.y >= -1e-9));
  assert.ok(d.outlines[0].every((p) => p.y <= 1e-9));
});

test('title block sits below the drawing, clear of the outline', () => {
  for (const rec of ctx.CIP_RECORDS) {
    const d = drawing.build(rec);
    const lowest = Math.max(...d.outlines.flat().map((p) => p.y));
    assert.ok(d.titleBlock.top > lowest, rec.key);
  }
});

test('missing values are reported and not invented', () => {
  const broken = { key: 'x', name: 'x', family: 'rimless', annotations: {}, cartridge: { caseHead: {}, collar: {}, lengths: {}, powderChamber: {}, projectile: {}, junctionCone: {} } };
  const d = drawing.build(broken);
  assert.equal(d.ok, false);
  assert.ok(d.missing.length > 0);
});
