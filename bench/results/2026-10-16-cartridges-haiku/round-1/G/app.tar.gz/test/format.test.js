'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const eq = (a, b, m) => assert.deepStrictEqual(plain(a), b, m);
const { load } = require('./helpers');

const { format } = (() => { const c = load(['js/format.js']); return c.CIP; })();

test('angles: number is degrees, object is d°mm\'ss"', () => {
  assert.equal(format.angle(40), '40°');
  assert.equal(format.angle(35.0), '35°');
  assert.equal(format.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.angle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(format.angle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
});

test('numbers keep the decimal point and have no thousands separator', () => {
  assert.equal(format.number(51.18), '51.18');
  assert.equal(format.number(4150), '4150');
  assert.equal(format.number(-0.2), '-0.2');
});

test('units by field name', () => {
  assert.equal(format.unit('L3'), 'mm');
  assert.equal(format.unit('G1'), 'mm');
  assert.equal(format.unit('u'), 'mm');
  assert.equal(format.unit('Pmax'), 'bar');
  assert.equal(format.unit('PK'), 'bar');
  assert.equal(format.unit('PE'), 'bar');
  assert.equal(format.unit('EE'), 'J');
  assert.equal(format.unit('M'), 'g');
  assert.equal(format.unit('Q'), 'mm²');
  assert.equal(format.unit('N'), '');
  assert.equal(format.unit('alpha'), '');
  assert.equal(format.unit('i'), '');
});

test('symbols: field name except the published overrides', () => {
  const cases = {
    E1: 'E1', eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3',
  };
  for (const [key, symbol] of Object.entries(cases)) assert.equal(format.symbol(key), symbol, key);
});

test('a tolerance is shown next to its value', () => {
  assert.equal(format.withTol('39.62', -0.2), '39.62 -0.2');
  assert.equal(format.withTol('51.18', undefined), '51.18');
});

test('value formats angles as angles and numbers as numbers', () => {
  assert.equal(format.value('delta', { degrees: 36, minutes: 52, seconds: 12 }), '36°52\'12"');
  assert.equal(format.value('L1', 39.62), '39.62');
});
