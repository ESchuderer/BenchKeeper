'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const eq = (a, b, m) => assert.deepStrictEqual(plain(a), b, m);
const { load, byKey, plain } = require('./helpers');

const ctx = load(['js/data.js', 'js/format.js', 'js/model.js', 'js/geometry.js']);
const { geometry } = ctx.CIP;
const build = (k) => geometry.build(byKey(ctx, k));
const near = (a, b, tol = 0.01, msg = '') => assert.ok(Math.abs(a - b) <= tol, `${msg} expected ${b}, got ${a}`);
const hasPoint = (pts, z, r, tol = 0.01) => pts.some((p) => Math.abs(p.z - z) <= tol && Math.abs(p.r - r) <= tol);

test('every record builds with no missing values', () => {
  for (const r of ctx.CIP_RECORDS) {
    const g = geometry.build(r);
    eq(g.missing, [], r.key);
    assert.ok(g.outer.length > 4, r.key);
    eq(g.outer[0], { z: 0, r: 0 }, r.key);
    const last = g.outer[g.outer.length - 1];
    near(last.z, r.cartridge.lengths.L3, 1e-9, r.key + ' mouth z');
  }
});

test('223 Rem: chamfered head, groove, shoulder', () => {
  const g = build('223_rem');
  assert.equal(g.rim, 'rimless');
  // chamfer: x = min(0.45 * tan 35, 9.6/4) = 0.315
  assert.ok(hasPoint(g.outer, 0, 4.8 - 0.315), 'chamfer start');
  assert.ok(hasPoint(g.outer, 0.45, 4.8), 'chamfer end');
  assert.ok(hasPoint(g.outer, 1.14, 4.8), 'rim top at z = R');
  // groove: floor at E1/2 from z=R to z=R+eMin, ramp to P1/2 at z=E
  assert.ok(hasPoint(g.outer, 1.14, 4.215), 'groove step');
  assert.ok(hasPoint(g.outer, 1.90, 4.215), 'groove floor end');
  assert.ok(hasPoint(g.outer, 3.13, 4.79), 'ramp end at body start');
  assert.equal(g.bodyStart, 3.13);
  // mouth
  const last = g.outer[g.outer.length - 1];
  near(last.r, 6.43 / 2, 1e-9, 'mouth r');
  assert.equal(g.bottleneck, true);
});

test('straight pistol case uses the body line to the mouth and no shoulder', () => {
  const g = build('9_mm_luger');
  assert.equal(g.bottleneck, false);
  assert.ok(hasPoint(g.outer, 19.15, 9.65 / 2));
  assert.ok(hasPoint(g.outer, 1.27, 9.96 / 2), 'rim top');
  assert.ok(hasPoint(g.outer, 2.17, 8.79 / 2), 'groove floor end');
  assert.ok(hasPoint(g.outer, 2.98, 9.93 / 2), 'body start');
});

test('rimfire rim is a half-round of radius min(R/2, (R1-P1)/2) ending at z = 2 rho', () => {
  const g = build('22_long_rifle');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.equal(g.rim, 'rimfire');
  assert.ok(hasPoint(g.outer, 0, 7.06 / 2 - rho), 'half-round start on the face');
  assert.ok(hasPoint(g.outer, 2 * rho, 7.06 / 2 - rho), 'half-round end');
  // apex of the half-round is at R1/2
  assert.ok(g.outer.some((p) => Math.abs(p.r - 7.06 / 2) < 1e-6), 'outermost point at R1/2');
  assert.ok(hasPoint(g.outer, 2 * rho, 5.74 / 2), 'steps in to P1/2 at the same z');
});

test('belted case: groove ramp at angle delta to the axis, then the belt to z = E', () => {
  const g = build('300_win_mag');
  assert.equal(g.rim, 'belted');
  const floorEnd = 1.27 + 0.94;
  const zr = floorEnd + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  near(zr, 3.2382, 0.001);
  assert.ok(hasPoint(g.outer, zr, 13.51 / 2, 0.01), 'belt starts at ramp end');
  assert.ok(hasPoint(g.outer, 5.59, 13.51 / 2), 'belt ends at E');
  assert.ok(hasPoint(g.outer, 5.59, 13.03 / 2), 'step in to P1/2 at E');
});

test('rimmed case without a groove steps from the rim to P1/2 at z = R', () => {
  const g = build('7_x_65_r');
  assert.equal(g.rim, 'rimmed');
  assert.ok(hasPoint(g.outer, 1.4, 13.32 / 2));
  assert.ok(hasPoint(g.outer, 1.4, 11.89 / 2));
  assert.equal(g.bodyStart, 1.4);
});

test('bullet seating, cylinder end and nose for a pointy rifle bullet (223 Rem)', () => {
  const b = build('223_rem').bullet;
  near(b.s, 5.7, 1e-9, 's'); near(b.zb, 39.0, 1e-9, 'zb'); near(b.Lb, 18.4, 1e-9, 'Lb');
  near(b.zc, 39.0 + 0.4 * 18.4, 1e-9, 'zc'); near(b.n, 57.4 - (39.0 + 0.4 * 18.4), 1e-9, 'n');
  near(b.m, 1.27, 1e-9, 'meplat (max of 0.08 G1 and 1.27)');
  assert.equal(b.heeled, false);
  near(b.rExp, 5.7 / 2, 1e-9);
  const tip = b.exposed[b.exposed.length - 1];
  near(tip.z, 57.4, 1e-9, 'tip z'); near(tip.r, 0, 1e-9, 'tip on axis');
});

test('ogive: tangent to the cylinder at z = zc and ends at the meplat', () => {
  const b = build('223_rem').bullet;
  const i = b.exposed.findIndex((p) => Math.abs(p.z - b.zc) < 1e-6 && Math.abs(p.r - 5.7 / 2) < 1e-6);
  assert.ok(i >= 0, 'nose starts at zc on the shank');
  const next = b.exposed[i + 1];
  near(next.r, 5.7 / 2, 0.05, 'tangent: radius stays at G1/2 for the first sample'); 
});

test('rounded pistol bullet: seating 0.4 G1, k 0.65, meplat 0.15 G1', () => {
  const b = build('9_mm_luger').bullet;
  near(b.s, 0.4 * 9.03, 1e-9); near(b.zb, 19.15 - 0.4 * 9.03, 1e-9);
  near(b.zc, b.zb + 0.65 * (29.69 - b.zb), 1e-9);
  near(b.m, 0.15 * 9.03, 1e-9);
});

test('rifle rounded and rimfire flat use their own factors; heeled 22 LR', () => {
  const b = build('22_long_rifle').bullet;
  assert.equal(b.heeled, true);
  near(b.s, 0.8 * 5.72, 1e-9, 'rimfire rounded seats 0.8 G1');
  near(b.zc, b.zb + 0.55 * (25.4 - b.zb), 1e-9, 'rounded rifle or rimfire k = 0.55');
  near(b.rExp, 5.72 / 2, 1e-9, 'exposed bullet has the case outside diameter');
  near(b.rHeel, 5.72 / 2 - 0.6, 1e-9, 'heel has the case inside diameter H2 - 2 tb');
});

test('walls: tn = (H2 - G1)/2, tb = min(max(1.3 tn, 0.6), 0.35 P1/2)', () => {
  const w = build('223_rem').walls;
  near(w.tn, (6.43 - 5.7) / 2, 1e-9); near(w.tb, 0.6, 1e-9);
  const p = build('9_mm_luger').walls;
  near(p.tn, (9.65 - 9.03) / 2, 1e-9); near(p.tb, 0.6, 1e-9);
});

test('solid head: w = max(2.5, 0.25 P1/2, pocket depth + 1.5, E + tb)', () => {
  near(build('223_rem').cavity.floor.z, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + 0.6), 1e-9);
  near(build('243_win').cavity.floor.z, 3.3 + 1.5, 1e-9, 'lr pocket depth 3.3 governs');
  near(build('300_win_mag').cavity.floor.z, 5.59 + 0.6, 1e-9, 'E + tb governs for belted');
});

test('primer pocket is drawn for centrefire and omitted for rimfire', () => {
  eq(build('223_rem').pocket, { diameter: 4.45, depth: 3.04, r: 4.45 / 2 });
  assert.equal(build('22_long_rifle').pocket, null);
});

test('alpha: apex from the published shoulder points, arc endpoints on the drawn cone', () => {
  const a = build('223_rem').alpha;
  const apex = 36.52 + 4.5 * (39.55 - 36.52) / (4.5 - 3.215);
  near(a.apexZ, apex, 1e-6);
  const h = Math.atan((4.5 - 3.215) / (39.55 - 36.52));
  near(a.halfAngle, h, 1e-9);
  assert.equal(build('9_mm_luger').alpha, null);
});

test('fillet: 90 degree corner with radius 2 gives tangent points at 2 and a circular arc', () => {
  const pts = geometry.fillet({ z: 0, r: 0 }, { z: 10, r: 0 }, { z: 10, r: 10 }, 2);
  assert.ok(hasPoint(pts, 8, 0, 1e-9), 'start tangent point');
  assert.ok(hasPoint(pts, 10, 2, 1e-9), 'end tangent point');
  const mid = pts.find((p) => Math.abs(p.z - (8 + 2 * Math.cos(Math.PI / 4))) < 0.2 && Math.abs(p.r - (2 - 2 * Math.sin(Math.PI / 4))) < 0.2);
  assert.ok(mid, 'arc passes near the 45 degree point');
  for (const p of pts) near(Math.hypot(p.z - 8, p.r - 2), 2, 1e-6, 'on the circle');
});

test('fillet clamps its tangent length to half of the shorter neighbour', () => {
  const pts = geometry.fillet({ z: 0, r: 0 }, { z: 2, r: 0 }, { z: 2, r: 2 }, 50);
  assert.ok(pts.every((p) => p.z <= 2 + 1e-9 && p.r >= -1e-9));
});

test('pistol bullet with shape flat uses a straight cone to m = 0.55 G1 at 0.7 k', () => {
  const b = build('40_s_w').bullet;
  near(b.m, 0.55 * 10.17, 1e-9);
  near(b.zc, b.zb + 0.7 * (28.83 - b.zb), 1e-9);
  assert.equal(b.exposed.length >= 3, true);
});

test('semi-wadcutter: s = 0.6 G1, k = 0.78, m = 0.6 G1', () => {
  const b = build('357_magnum').bullet;
  near(b.s, 0.6 * 9.12, 1e-9); near(b.zc, b.zb + 0.78 * (40.39 - b.zb), 1e-9); near(b.m, 0.6 * 9.12, 1e-9);
});
