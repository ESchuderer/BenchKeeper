'use strict';
// Loads the browser scripts into a fresh vm context so the same files run in tests and in the app.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.join(__dirname, '..');
const FILES = ['js/data.js', 'js/format.js', 'js/model.js', 'js/geometry.js', 'js/drawing.js'];

function load(files = FILES) {
  const ctx = { console };
  ctx.window = ctx;
  vm.createContext(ctx);
  for (const f of files) {
    vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), ctx, { filename: f });
  }
  return ctx;
}

const byKey = (ctx, key) => ctx.CIP_RECORDS.find((r) => r.key === key);

module.exports = { load, byKey, ROOT };

// Objects built inside the vm context have another Object prototype, so strict deep equality
// needs a plain copy first.
function plain(x) {
  return JSON.parse(JSON.stringify(x));
}
module.exports.plain = plain;
