'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const eq = (a, b, m) => assert.deepStrictEqual(plain(a), b, m);
const { load, byKey, plain } = require('./helpers');

const ctx = load(['js/data.js', 'js/format.js', 'js/model.js']);
const { model } = ctx.CIP;
const rec = (k) => byKey(ctx, k);

test('there are 25 records with unique keys', () => {
  assert.equal(ctx.CIP_RECORDS.length, 25);
  assert.equal(new Set(ctx.CIP_RECORDS.map((r) => r.key)).size, 25);
});

test('rim type from family, then from R1/P1', () => {
  assert.equal(model.rimType(rec('223_rem')), 'rimless');       // 9.6 / 9.58 = 1.002
  assert.equal(model.rimType(rec('300_win_mag')), 'belted');
  assert.equal(model.rimType(rec('22_long_rifle')), 'rimfire');
  assert.equal(model.rimType(rec('7_x_65_r')), 'rimmed');       // 13.32 / 11.92 = 1.12
  assert.equal(model.rimType({ family: 'pistol', cartridge: { caseHead: { R1: 10 }, powderChamber: { P1: 10.5 } } }), 'rebated');
  assert.equal(model.rimType({ family: 'pistol', cartridge: { caseHead: { R1: 10.5 }, powderChamber: { P1: 10 } } }), 'rimmed');
});

test('primer pockets', () => {
  eq(model.primerPocket('sr'), { diameter: 4.45, depth: 3.04 });
  eq(model.primerPocket('spm'), { diameter: 4.45, depth: 3.04 });
  eq(model.primerPocket('lp'), { diameter: 5.33, depth: 3.04 });
  eq(model.primerPocket('lrm'), { diameter: 5.33, depth: 3.3 });
  eq(model.primerPocket('lr'), { diameter: 5.33, depth: 3.3 });
  assert.equal(model.primerPocket('rimfire'), null);
});

test('sections: cartridge and chamber, tolerances folded into values, no Tol rows', () => {
  const s = model.sections(rec('223_rem'));
  eq(s.cartridge.map((x) => x.id),
    ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile']);
  eq(s.chamber.map((x) => x.id),
    ['barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling']);
  const head = s.cartridge[0].rows;
  eq(head.find((r) => r.symbol === 'E1'), { symbol: 'E1', value: '8.43', unit: 'mm', key: 'E1' });
  assert.equal(head.find((r) => r.symbol === 'β').value, '35°');
  assert.equal(head.find((r) => r.symbol === 'δ').value, '25°');
  const lengths = s.cartridge[3].rows;
  assert.equal(lengths.find((r) => r.symbol === 'L1').value, '36.52 -0.2');
  assert.equal(lengths.find((r) => r.symbol === 'L3').value, '44.7');
  const rifling = s.chamber[7].rows;
  assert.equal(rifling.find((r) => r.symbol === 'i').value, '3°10\'36"');
});

test('no row anywhere is a tolerance field', () => {
  for (const r of ctx.CIP_RECORDS) {
    for (const sec of [...model.sections(r).cartridge, ...model.sections(r).chamber]) {
      for (const row of sec.rows) assert.ok(!/Tol$/.test(row.key), `${r.key} ${row.key}`);
    }
  }
});

test('tolerances of the 9 mm Luger case head and mouth are shown where published', () => {
  const s = model.sections(rec('9_mm_luger'));
  const lengths = s.cartridge.find((x) => x.id === 'lengths').rows;
  assert.equal(lengths.find((r) => r.symbol === 'L3').value, '19.15 -0.25');
});

test('counts: every record in the list, with count labels', () => {
  assert.equal(model.countLabel(25), '25 cartridges');
  assert.equal(model.countLabel(1), '1 cartridge');
  assert.equal(model.countLabel(0), '0 cartridges');
});

test('search matches name and alternative names, case-insensitively, ignoring spacing', () => {
  const keys = (q, fam = 'all') => model.filter(ctx.CIP_RECORDS, { query: q, family: fam }).map((r) => r.key);
  eq(keys('7,62 x 51'), ['308_win']);
  eq(keys('308 Win.'), ['308_win']);
  eq(keys('7,62x51'), ['308_win']);
  eq(keys('30-06'), ['30_06_spring']);
  eq(keys('22 lr'), ['22_long_rifle']);
  eq(keys('22lr'), ['22_long_rifle']);
  assert.equal(keys('').length, 25);
  eq(keys('zzz'), []);
});

test('family filter with All', () => {
  const count = (f) => model.filter(ctx.CIP_RECORDS, { query: '', family: f }).length;
  assert.equal(count('all'), 25);
  assert.equal(count('rimless'), 12);
  assert.equal(count('rimmed'), 2);
  assert.equal(count('belted'), 2);
  assert.equal(count('pistol'), 6);
  assert.equal(count('rimfire'), 3);
});

test('routes: list or detail by hash, unknown keys reported', () => {
  eq(model.parseRoute(''), { view: 'list' });
  eq(model.parseRoute('#/'), { view: 'list' });
  eq(model.parseRoute('#/cartridge/223_rem'), { view: 'detail', key: '223_rem' });
  eq(model.parseRoute('#/cartridge/nope'), { view: 'detail', key: 'nope' });
});

test('water capacity line and source link', () => {
  const w = model.waterCapacity(rec('223_rem'));
  assert.equal(w.value, '30.5');
  assert.equal(w.note, 'kwk 31, Wikipedia 28.8; the mean');
  assert.equal(w.source, 'kwk');
  assert.equal(w.url, 'http://kwk.us/cases.html');
});
