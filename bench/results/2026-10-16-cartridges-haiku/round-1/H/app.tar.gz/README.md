# C.I.P. cartridge reference

A static reference page for 25 C.I.P. cartridges: a searchable list, a detail view per
cartridge at its own address, a to-scale 2D drawing, and a one-page A4 print.

Plain HTML, CSS and JavaScript. No build step and no runtime dependencies. Open
`index.html` directly in a browser, or serve the folder with any static file server.

- `index.html`, `styles.css`: the page
- `data/cartridges.js`: the 25 records, verbatim from OpenBallistics (MIT, commit e83db43)
- `src/format.js`: symbols, units, angles, tolerances
- `src/catalog.js`: search, family filter, routing
- `src/geometry.js`: profile, walls, bullet, from the rules in the brief
- `src/drawing.js`: drawing scene and SVG rendering, dimensions and label layout
- `src/app.js`: page behaviour

## Tests

    npm install
    npm test            # unit tests (Node 22, node:test)
    npm run test:e2e    # Chromium checks via Playwright (npx playwright install chromium)
