'use strict';

// End-to-end checks in Chromium, opening index.html straight from file://.
// Needs the Playwright browser to be installed (npx playwright install chromium).

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');

const INDEX = pathToFileURL(path.join(__dirname, '..', 'index.html')).href;

let browser;

test.before(async () => {
  browser = await chromium.launch();
});

test.after(async () => {
  await browser.close();
});

async function open(hash = '', options = {}) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, ...options });
  const page = await context.newPage();
  const requests = [];
  const errors = [];
  page.on('request', (request) => requests.push(request.url()));
  page.on('pageerror', (error) => errors.push(String(error)));
  await page.goto(INDEX + hash);
  return { page, context, requests, errors };
}

test('the list shows 25 cartridges, each linked by its exact name', async () => {
  const { page, context, errors } = await open();
  try {
    await page.getByRole('heading', { name: 'Cartridges', exact: true }).waitFor();
    assert.equal(await page.locator('#cartridge-rows a').count(), 25);
    assert.equal(await page.locator('#count').textContent(), '25 cartridges');
    assert.ok(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).isVisible());
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('searching by an alternative name finds 308 Win.', async () => {
  const { page, context } = await open();
  try {
    await page.getByLabel('Search').fill('7,62 x 51');
    assert.equal(await page.locator('#count').textContent(), '1 cartridge');
    assert.equal(await page.locator('#cartridge-rows a').textContent(), '308 Win.');
  } finally {
    await context.close();
  }
});

test('the family select narrows the list and combines with the search', async () => {
  const { page, context } = await open();
  try {
    await page.getByLabel('Family').selectOption('rimfire');
    assert.equal(await page.locator('#count').textContent(), '3 cartridges');
    await page.getByLabel('Search').fill('mag');
    assert.equal(await page.locator('#count').textContent(), '1 cartridge');
    assert.equal(await page.locator('#cartridge-rows a').textContent(), '22 Win. Mag. R.F.');
    await page.getByLabel('Search').fill('');
    await page.getByLabel('Family').selectOption('All');
    assert.equal(await page.locator('#count').textContent(), '25 cartridges');
  } finally {
    await context.close();
  }
});

test('a cartridge name opens its own address, and that address survives a reload', async () => {
  const { page, context, errors } = await open();
  try {
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    assert.equal(new URL(page.url()).hash, '#/cartridge/308_win');
    await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
    await page.reload();
    await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
    assert.ok(await page.getByRole('img', { name: '308 Win. drawing' }).isVisible());
    assert.deepEqual(errors, []);
  } finally {
    await context.close();
  }
});

test('the detail view has the facts, the drawing and grouped value tables with Symbol, Value and Unit', async () => {
  const { page, context } = await open('#/cartridge/223_rem');
  try {
    await page.getByRole('heading', { level: 1, name: '223 Rem.' }).waitFor();
    const facts = await page.locator('#facts').innerText();
    for (const term of ['Alternative names', 'Family', 'Category', 'Primer type', 'C.I.P. table', 'Country', 'Published', 'Revised', 'Pressure method', 'Water capacity']) {
      assert.ok(facts.includes(term), term);
    }
    assert.match(facts, /30\.5 grH2O/);
    assert.equal(await page.locator('#facts a[href="http://kwk.us/cases.html"]').count(), 1);
    const headers = await page.locator('table.values thead tr').first().innerText();
    assert.match(headers, /symbol/i);
    assert.match(headers, /value/i);
    assert.match(headers, /unit/i);
    const bodyText = await page.locator('#sections').innerText();
    assert.match(bodyText, /39°|46°/);
    assert.match(bodyText, /3°10'36"/);
    assert.match(bodyText, /L3 \+ G/);
    assert.match(bodyText, /e min/);
    assert.match(bodyText, /delta L/);
    assert.match(bodyText, /mm²/);
    assert.match(await page.locator('#sections').innerText(), /36\.52 -0\.2/);
    assert.equal(await page.locator('#sections').innerText().then((t) => t.includes('ETol')), false);
    assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
    assert.equal(await page.getByRole('link', { name: 'All cartridges' }).count(), 1);
  } finally {
    await context.close();
  }
});

test('an unknown cartridge address says it was not found', async () => {
  const { page, context } = await open('#/cartridge/nope');
  try {
    await page.getByRole('heading', { name: 'Cartridge not found' }).waitFor();
    assert.equal(await page.locator('#detail-view').isVisible(), false);
  } finally {
    await context.close();
  }
});

test('the page makes no network requests beyond the local file', async () => {
  const { page, context, requests } = await open('#/cartridge/9_mm_luger');
  try {
    await page.getByRole('heading', { level: 1, name: '9 mm Luger' }).waitFor();
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.getByRole('heading', { name: 'Cartridges', exact: true }).waitFor();
    const external = requests.filter((url) => !url.startsWith('file:'));
    assert.deepEqual(external, []);
  } finally {
    await context.close();
  }
});

test('a phone-width viewport keeps the drawing inside the screen', async () => {
  const { page, context } = await open('#/cartridge/300_win_mag', { viewport: { width: 375, height: 800 } });
  try {
    await page.getByRole('img', { name: '300 Win. Mag. drawing' }).waitFor();
    const box = await page.locator('figure svg').boundingBox();
    assert.ok(box.width <= 375, `drawing width ${box.width}`);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assert.ok(overflow <= 1, `horizontal overflow ${overflow}px`);
  } finally {
    await context.close();
  }
});

test('print gives one A4 portrait page with the name, the drawing, the tables and the source', async () => {
  const { page, context } = await open('#/cartridge/223_rem');
  try {
    await page.getByRole('heading', { level: 1, name: '223 Rem.' }).waitFor();
    await page.emulateMedia({ media: 'print' });
    const pdf = await page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page\b(?!s)/g) || []).length;
    assert.equal(pages, 1, `printed pages: ${pages}`);
    const hidden = await page.evaluate(() => getComputedStyle(document.querySelector('.toolbar')).display);
    assert.equal(hidden, 'none');
  } finally {
    await context.close();
  }
});

test('dark mode follows the system setting', async () => {
  const { page, context } = await open('#/cartridge/223_rem', { colorScheme: 'dark' });
  try {
    await page.getByRole('heading', { level: 1, name: '223 Rem.' }).waitFor();
    const background = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.notEqual(background, 'rgb(245, 244, 239)');
  } finally {
    await context.close();
  }
});
