/**
 * Page behaviour: the cartridge list with search and family filter, the detail view at
 * its own hash address, and printing. Everything runs from file:// with no network.
 */
(function (root) {
  const CIP = root.CIP;
  const { catalog, format, geometry, drawing } = CIP;
  const records = CIP.records;

  /** Section groups in display order, with the labels shown above each table. */
  const CARTRIDGE_GROUPS = [
    ['caseHead', 'Case head'],
    ['collar', 'Collar'],
    ['junctionCone', 'Junction cone'],
    ['lengths', 'Lengths'],
    ['misc', 'Miscellaneous'],
    ['powderChamber', 'Powder chamber'],
    ['pressures', 'Pressures'],
    ['projectile', 'Projectile'],
  ];
  const CHAMBER_GROUPS = [
    ['barrel', 'Barrel'],
    ['breech', 'Breech'],
    ['collar', 'Collar'],
    ['grooves', 'Grooves'],
    ['junctionCone', 'Junction cone'],
    ['lengths', 'Lengths'],
    ['powderChamber', 'Powder chamber'],
    ['rifling', 'Rifling'],
  ];
  const DATA_SOURCE = 'Data: OpenBallistics (MIT licence, commit e83db43)';

  const byKey = new Map(records.map((record) => [record.key, record]));

  /**
   * @param {string} tag
   * @param {Record<string, string>} [attributes]
   * @param {(Node | string)[]} [children]
   */
  function element(tag, attributes, children) {
    const node = document.createElement(tag);
    for (const [name, value] of Object.entries(attributes || {})) node.setAttribute(name, value);
    for (const child of children || []) {
      node.append(typeof child === 'string' ? document.createTextNode(child) : child);
    }
    return node;
  }

  function $(id) {
    return document.getElementById(id);
  }

  function setList(parent, nodes) {
    parent.replaceChildren(...nodes);
  }

  function showView(id) {
    for (const view of ['list-view', 'detail-view', 'not-found']) {
      $(view).hidden = view !== id;
    }
  }

  // ---- list view ------------------------------------------------------------

  function renderList() {
    const query = $('search-input').value;
    const family = $('family-select').value;
    const matches = catalog.filterCartridges(records, { query, family });
    $('count').textContent = format.countLabel(matches.length);
    const rows = matches.map((record) => {
      const summary = catalog.summarise(record);
      return element('tr', {}, [
        element('td', {}, [element('a', { href: catalog.routeHash(record.key) }, [summary.name])]),
        element('td', {}, [summary.family]),
        element('td', { class: 'num' }, [summary.l3]),
      ]);
    });
    setList($('cartridge-rows'), rows);
  }

  function setupFilters() {
    const select = $('family-select');
    setList(select, catalog.FAMILY_OPTIONS.map((family) => element('option', { value: family }, [family])));
    $('search-input').addEventListener('input', renderList);
    select.addEventListener('change', renderList);
  }

  // ---- detail view ----------------------------------------------------------

  /** A term and its definition; the definition is text or a list of nodes and text. */
  function factRow(term, definition) {
    const children = Array.isArray(definition) ? definition : [definition];
    return [element('dt', {}, [term]), element('dd', {}, children)];
  }

  function waterCapacityNodes(capacity) {
    const text = format.waterCapacityText(capacity);
    if (text === null) return ['—'];
    const nodes = [text];
    const sourceParts = [];
    if (capacity.source) {
      sourceParts.push(' (source: ');
      sourceParts.push(capacity.url
        ? element('a', { href: capacity.url, rel: 'noopener' }, [capacity.source])
        : capacity.source);
      sourceParts.push(')');
    }
    nodes.push(...sourceParts);
    if (capacity.note) nodes.push(`. ${capacity.note}`);
    return nodes;
  }

  function renderFacts(record) {
    const { annotations } = record;
    const alternatives = record.alternativeNames && record.alternativeNames.length
      ? record.alternativeNames.join(', ')
      : '—';
    const nodes = [
      ...factRow('Alternative names', alternatives),
      ...factRow('Family', record.family),
      ...factRow('Category', annotations.category),
      ...factRow('Primer type', annotations.primerType),
      ...factRow('C.I.P. table', record.tab),
      ...factRow('Country', record.country),
      ...factRow('Published', record.published),
      ...factRow('Revised', record.revised),
      ...factRow('Pressure method', record.pressureMethod),
    ];
    if (annotations.publishedCapacity) {
      nodes.push(...factRow('Water capacity', waterCapacityNodes(annotations.publishedCapacity)));
    }
    setList($('facts'), nodes);
  }

  function renderDrawing(record, model) {
    const figure = $('figure');
    const scene = drawing.buildScene(record, model);
    if (!scene) {
      setList(figure, [element('p', {}, ['No drawing: the required values are not published.'])]);
      return;
    }
    const parsed = new DOMParser().parseFromString(drawing.renderSvg(scene), 'image/svg+xml');
    figure.replaceChildren(document.importNode(parsed.documentElement, true));
  }

  function renderNotes(model) {
    setList($('drawing-notes'), model.notes.map((note) => element('li', {}, [note])));
  }

  /** One table per group that has values, each with Symbol, Value and Unit columns. */
  function groupTables(section, groups) {
    const tables = [];
    const seen = new Set();
    const ordered = [...groups.map(([key]) => key), ...Object.keys(section)];
    for (const key of ordered) {
      if (seen.has(key) || !(key in section)) continue;
      seen.add(key);
      const label = (groups.find(([groupKey]) => groupKey === key) || [key, key])[1];
      const rows = format.sectionRows(section[key]);
      if (rows.length === 0) continue;
      tables.push(element('section', { class: 'group' }, [
        element('h3', {}, [label]),
        element('table', { class: 'values' }, [
          element('thead', {}, [element('tr', {}, [
            element('th', { scope: 'col' }, ['Symbol']),
            element('th', { scope: 'col', class: 'num' }, ['Value']),
            element('th', { scope: 'col' }, ['Unit']),
          ])]),
          element('tbody', {}, rows.map((row) => element('tr', {}, [
            element('th', { scope: 'row' }, [row.symbol]),
            element('td', { class: 'num' }, [row.value]),
            element('td', {}, [row.unit]),
          ]))),
        ]),
      ]));
    }
    return tables;
  }

  function renderSections(record) {
    setList($('sections'), [
      element('section', { class: 'part' }, [
        element('h2', {}, ['Cartridge']),
        ...groupTables(record.cartridge, CARTRIDGE_GROUPS),
      ]),
      element('section', { class: 'part' }, [
        element('h2', {}, ['Chamber']),
        ...groupTables(record.chamber, CHAMBER_GROUPS),
      ]),
    ]);
  }

  function renderFooter(record) {
    setList($('source'), [
      element('p', {}, [`Source: C.I.P. TDCC, revised ${record.revised}.`]),
      element('p', {}, [DATA_SOURCE]),
    ]);
  }

  function renderDetail(record) {
    $('detail-title').textContent = record.name;
    document.title = `${record.name} · C.I.P. reference`;
    const model = geometry.buildModel(record);
    renderFacts(record);
    renderDrawing(record, model);
    renderNotes(model);
    renderSections(record);
    renderFooter(record);
  }

  // ---- routing --------------------------------------------------------------

  function render() {
    const route = catalog.parseRoute(root.location.hash);
    if (route.view === 'cartridge') {
      const record = byKey.get(route.key);
      if (record) {
        renderDetail(record);
        showView('detail-view');
        $('detail-title').focus({ preventScroll: false });
        return;
      }
      showView('not-found');
      return;
    }
    document.title = 'Cartridges · C.I.P. reference';
    showView('list-view');
    renderList();
  }

  function init() {
    setupFilters();
    $('print-button').addEventListener('click', () => root.print());
    root.addEventListener('hashchange', render);
    render();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
