/**
 * Catalogue logic for the list view and the hash router. No DOM access.
 */
(function (root) {
  root.CIP = root.CIP || {};

  /** Family filter options in display order; "All" means no family filter. */
  const FAMILY_OPTIONS = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  const ROUTE_PREFIX = '#/cartridge/';

  /**
   * Lower-case, trimmed, with runs of whitespace collapsed to one space.
   * @param {string} text
   */
  function normalise(text) {
    return text.toLowerCase().replace(/\s+/g, ' ').trim();
  }

  /**
   * @param {{ name: string, alternativeNames?: string[] }} record
   * @param {string} query already normalised
   */
  function matchesQuery(record, query) {
    if (query === '') return true;
    const names = [record.name, ...(record.alternativeNames || [])];
    return names.some((name) => normalise(name).includes(query));
  }

  /**
   * @param {any[]} records
   * @param {{ query: string, family: string }} criteria
   */
  function filterCartridges(records, criteria) {
    const query = normalise(criteria.query);
    const family = criteria.family;
    return records.filter((record) => {
      const familyOk = family === 'All' || record.family === family;
      return familyOk && matchesQuery(record, query);
    });
  }

  /**
   * @param {any} record
   * @returns {{ key: string, name: string, family: string, l3: string }}
   */
  function summarise(record) {
    const l3Row = root.CIP.format.sectionRows(record.cartridge.lengths).find((row) => row.symbol === 'L3');
    return {
      key: record.key,
      name: record.name,
      family: record.family,
      l3: `${l3Row.value} ${l3Row.unit}`,
    };
  }

  /** @param {string} key */
  function routeHash(key) {
    return ROUTE_PREFIX + encodeURIComponent(key);
  }

  /**
   * @param {string} hash e.g. "#/cartridge/308_win" or ""
   * @returns {{ view: 'list' } | { view: 'cartridge', key: string }}
   */
  function parseRoute(hash) {
    if (hash.startsWith(ROUTE_PREFIX)) {
      return { view: 'cartridge', key: decodeURIComponent(hash.slice(ROUTE_PREFIX.length)) };
    }
    return { view: 'list' };
  }

  root.CIP.catalog = {
    FAMILY_OPTIONS,
    normalise,
    filterCartridges,
    summarise,
    routeHash,
    parseRoute,
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
