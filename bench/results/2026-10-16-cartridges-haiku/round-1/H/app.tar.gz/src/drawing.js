/**
 * Builds the cartridge drawing as a scene (outlines, dimensions, labels, title block)
 * and renders it to an SVG string. One SVG unit is one millimetre, so the drawing is
 * true to scale before the browser fits it to the available width.
 *
 * The scene keeps label rectangles and outline polylines apart so the layout can be
 * checked for overlaps in Node (see test/drawing.test.js).
 */
(function (root) {
  root.CIP = root.CIP || {};

  /** Label font size, mm. */
  const FONT = 3.3;
  /** Distance from the outline to the first dimension row, mm. */
  const ROW_BASE = 3.4;
  /** Spacing between dimension rows, mm. */
  const ROW_GAP = 4.8;
  /** Gap between the outline and the start of an extension line, mm. */
  const EXT_GAP = 0.8;
  /** Extension lines run this far past their dimension line, mm. */
  const EXT_OVERSHOOT = 1.0;
  /** Arrowhead length and half width, mm. */
  const ARROW_LENGTH = 1.6;
  const ARROW_HALF = 0.5;
  /** Column for R1, left of the head face. */
  const LEFT_COLUMN_X = -3.6;
  /** First diameter column beyond the bullet tip, and the spacing between columns. */
  const RIGHT_COLUMN_START = 4.0;
  const COLUMN_SPACING = 5.0;
  /** Gap between a rotated label and its column, measured to the label's baseline, mm. */
  const ROTATED_LABEL_OFFSET = 2.6;
  /** Angle dimension radius, mm. */
  const ANGLE_RADIUS = 4.5;
  /** Minimum title block width, mm. */
  const TITLE_MIN_WIDTH = 74;
  /** Dash-dot centre line runs from just before the head face to just past the tip. */
  const CENTRE_LEAD = 1.0;
  const CENTRE_TAIL = 1.5;

  /**
   * Width of a label in mm: a per-character estimate, slightly generous.
   * @param {string} text
   * @param {number} size font size in mm
   */
  function textWidth(text, size) {
    let em = 0;
    for (const ch of text) {
      if (ch === ' ' || ch === '.' || ch === ',' || ch === "'" || ch === '"') em += 0.28;
      else if (ch === '°') em += 0.42;
      else em += 0.58;
    }
    return em * size;
  }

  /**
   * Value text with its tolerance next to it, e.g. "39.62 -0.2".
   * @param {Record<string, any>} section
   * @param {string} name
   * @returns {string | undefined}
   */
  function valueText(section, name) {
    const format = root.CIP.format;
    if (section[name] === undefined) return undefined;
    const text = format.formatValue(name, section[name]);
    const tolerance = section[`${name}Tol`];
    return typeof tolerance === 'number' ? `${text} ${format.formatNumber(tolerance)}` : text;
  }

  /** @param {number} value */
  function num(value) {
    return String(Math.round(value * 1000) / 1000);
  }

  /** @param {number[][]} points */
  function toPath(points) {
    return points.map(([z, r], i) => `${i === 0 ? 'M' : 'L'}${num(z)} ${num(r)}`).join(' ');
  }

  /**
   * Arrowhead with its tip at (x, y), pointing along (dx, dy).
   * @returns {string} path data of a filled triangle
   */
  function arrowhead(x, y, dx, dy) {
    const bx = x - dx * ARROW_LENGTH;
    const by = y - dy * ARROW_LENGTH;
    const px = -dy * ARROW_HALF;
    const py = dx * ARROW_HALF;
    return `M${num(x)} ${num(y)} L${num(bx + px)} ${num(by + py)} L${num(bx - px)} ${num(by - py)} Z`;
  }

  /**
   * Dimension line between two positions with arrowheads. Arrows sit inside the
   * dimension when there is room and point outward when there is not.
   *
   * @param {'h' | 'v'} axis h: along z at height `offset`; v: along r at column `offset`
   * @param {number} a
   * @param {number} b
   * @param {number} offset
   */
  function linearDimension(axis, a, b, offset) {
    const lo = Math.min(a, b);
    const hi = Math.max(a, b);
    const inside = hi - lo >= 3 * ARROW_LENGTH;
    const points = axis === 'h'
      ? [[lo, offset], [hi, offset]]
      : [[offset, lo], [offset, hi]];
    const line = `M${num(points[0][0])} ${num(points[0][1])} L${num(points[1][0])} ${num(points[1][1])}`;
    // Arrow tips sit on the ends and point outward when inside, inward when outside.
    const loDir = inside ? -1 : 1;
    const hiDir = inside ? 1 : -1;
    const heads = axis === 'h'
      ? `${arrowhead(lo, offset, loDir, 0)} ${arrowhead(hi, offset, hiDir, 0)}`
      : `${arrowhead(offset, lo, 0, loDir)} ${arrowhead(offset, hi, 0, hiDir)}`;
    return { line, heads, points };
  }

  /**
   * Label rectangle for horizontal text with its baseline at y.
   * @param {string} text
   * @param {number} x anchor point
   * @param {number} y baseline
   * @param {'middle' | 'end'} anchor
   */
  function horizontalLabelRect(text, x, y, anchor) {
    const width = textWidth(text, FONT);
    const left = anchor === 'middle' ? x - width / 2 : x - width;
    return { x0: left, x1: left + width, y0: y - FONT * 0.75, y1: y + FONT * 0.25 };
  }

  /**
   * Label rectangle for text rotated -90 degrees: centred on y = 0, glyphs extend
   * towards -x from the baseline at `baselineX`.
   * @param {string} text
   * @param {number} baselineX
   */
  function rotatedLabelRect(text, baselineX) {
    const length = textWidth(text, FONT);
    return { x0: baselineX - FONT * 0.75, x1: baselineX + FONT * 0.25, y0: -length / 2, y1: length / 2 };
  }

  /**
   * Interpolated outer radius at z, from the geometry module.
   * @param {number[][]} outer
   * @param {number} z
   */
  function radiusAt(outer, z) {
    return root.CIP.geometry.interpolate(outer, z);
  }

  /**
   * Scene for one cartridge.
   * @param {any} record
   * @param {any} model from geometry.buildModel
   * @returns {any | null} null when the model cannot be drawn
   */
  function buildScene(record, model) {
    if (!model.drawable) return null;
    const { format, geometry } = root.CIP;
    const cp = record.cartridge;
    const { caseHead, collar, junctionCone, powderChamber, lengths, projectile } = cp;
    const outer = model.profile.outer;
    const bullet = model.bullet;
    const L3 = lengths.L3;
    const L6 = bullet ? bullet.tip : L3;
    const maxR = Math.max(...outer.map((p) => p[1]), bullet ? bullet.exposedRadius : 0);
    const rimRadius = caseHead.R1 / 2;

    const scene = {
      key: record.key,
      name: record.name,
      upper: outer.map(([z, r]) => [z, -r]),
      bulletUpper: bullet ? bullet.outside.map(([z, r]) => [z, -r]) : null,
      cut: [model.profile.section, ...(bullet ? [bullet.section] : [])],
      extensions: [],
      dimensions: [],
      labels: [],
      points: [],
    };

    // Length dimensions: one row each above the outline, in order L1, L2, L3, L6.
    const lengthDims = [];
    if (model.bottleneck) {
      lengthDims.push({ name: 'L1', to: lengths.L1, featureR: powderChamber.P2 / 2, section: lengths });
      lengthDims.push({ name: 'L2', to: lengths.L2, featureR: collar.H1 / 2, section: lengths });
    }
    lengthDims.push({ name: 'L3', to: L3, featureR: collar.H2 / 2, section: lengths });
    if (bullet) lengthDims.push({ name: 'L6', to: L6, featureR: bullet.meplatRadius, section: lengths });
    lengthDims.forEach((dim, i) => {
      const row = -(maxR + ROW_BASE + i * ROW_GAP);
      addLinear(scene, 'h', 0, dim.to, row, dim.name, valueText(dim.section, dim.name), row - 0.9, 'middle');
      addExtension(scene, [dim.to, -(dim.featureR + EXT_GAP)], [dim.to, row - EXT_OVERSHOOT]);
    });
    if (lengthDims.length > 0) {
      const top = -(maxR + ROW_BASE + (lengthDims.length - 1) * ROW_GAP);
      addExtension(scene, [0, -(rimRadius + EXT_GAP)], [0, top - EXT_OVERSHOOT]);
    }

    // Rim thickness R: below the outline, with its label under the dimension line.
    const rimText = valueText(caseHead, 'R');
    if (rimText !== undefined) {
      const row = maxR + ROW_BASE;
      addLinear(scene, 'h', 0, caseHead.R, row, 'R', rimText, row + 3.1, 'middle');
      addExtension(scene, [0, rimRadius + EXT_GAP], [0, row + EXT_OVERSHOOT]);
      addExtension(scene, [caseHead.R, rimRadius + EXT_GAP], [caseHead.R, row + EXT_OVERSHOOT]);
    }

    // Shoulder angle: an arc at the apex of the shoulder lines, which lie at alpha/2 to the axis.
    if (model.bottleneck) addShoulderAngle(scene, record, model);

    // Diameters: vertical dimension lines in columns, the R1 column left of the head face
    // and the others beyond the bullet tip, each labelled rotated beside its line.
    const diameters = [{ name: 'R1', z: 0, section: caseHead, column: 'left' }];
    diameters.push({ name: 'P1', z: model.bodyStart, section: powderChamber, column: 'right' });
    if (model.groove) diameters.push({ name: 'E1', z: caseHead.R + caseHead.eMin, section: caseHead, column: 'right' });
    if (model.bottleneck) {
      diameters.push({ name: 'P2', z: lengths.L1, section: powderChamber, column: 'right' });
      diameters.push({ name: 'H1', z: lengths.L2, section: collar, column: 'right' });
    }
    diameters.push({ name: 'H2', z: L3, section: collar, column: 'right' });
    if (bullet) diameters.push({ name: 'G1', z: L3, section: projectile, column: 'right' });
    let rightIndex = 0;
    for (const item of diameters) {
      const text = valueText(item.section, item.name);
      if (text === undefined) continue;
      const diameter = item.section[item.name];
      const half = diameter / 2;
      let columnX;
      if (item.column === 'left') {
        columnX = LEFT_COLUMN_X;
      } else {
        columnX = L6 + RIGHT_COLUMN_START + COLUMN_SPACING * rightIndex;
        rightIndex += 1;
      }
      addVertical(scene, item.z, columnX, half, item.name, text, item.column);
    }

    scene.centreLine = [-CENTRE_LEAD, L6 + CENTRE_TAIL];
    scene.points.push(...scene.upper, ...(scene.bulletUpper || []), ...scene.cut.flat());
    const content = boundsOf(scene.points);
    scene.title = titleBlock(record, content);
    scene.bounds = boundsOf([...scene.points, ...scene.title.points]);
    return scene;
  }

  /** Adds a horizontal dimension with its label. */
  function addLinear(scene, axis, a, b, offset, name, valueTextOrNull, baseline, anchor) {
    const dim = linearDimension(axis, a, b, offset);
    scene.dimensions.push({ id: name, line: dim.line, heads: dim.heads });
    scene.points.push(...dim.points);
    const text = `${root.CIP.format.symbolFor(name)} ${valueTextOrNull}`;
    const x = (a + b) / 2;
    const rect = horizontalLabelRect(text, x, baseline, anchor);
    scene.labels.push({ id: name, text, x, baseline, anchor, rect });
    scene.points.push([rect.x0, rect.y0], [rect.x1, rect.y1]);
  }

  /** Adds a vertical diameter dimension in a column, with extension lines back to the feature. */
  function addVertical(scene, featureZ, columnX, half, name, text, column) {
    const dim = linearDimension('v', -half, half, columnX);
    scene.dimensions.push({ id: name, line: dim.line, heads: dim.heads });
    scene.points.push(...dim.points);
    addExtension(scene, [featureZ, -half], [columnX, -half]);
    addExtension(scene, [featureZ, half], [columnX, half]);
    const label = `${root.CIP.format.symbolFor(name)} ${text}`;
    const baseline = column === 'left' ? columnX - 0.5 : columnX + ROTATED_LABEL_OFFSET;
    const rect = rotatedLabelRect(label, baseline);
    scene.labels.push({ id: name, text: label, rotated: true, baseline, rect });
    scene.points.push([rect.x0, rect.y0], [rect.x1, rect.y1]);
  }

  /** Extension line between two points, recorded for the bounds. */
  function addExtension(scene, from, to) {
    scene.extensions.push(`M${num(from[0])} ${num(from[1])} L${num(to[0])} ${num(to[1])}`);
    scene.points.push(from, to);
  }

  /** Angle dimension for the included shoulder angle alpha, drawn as an arc at the apex. */
  function addShoulderAngle(scene, record, model) {
    const { geometry, format } = root.CIP;
    const { lengths, powderChamber, collar, junctionCone } = record.cartridge;
    const alpha = junctionCone.alpha;
    const P2h = powderChamber.P2 / 2;
    const H1h = collar.H1 / 2;
    const L1 = lengths.L1;
    const L2 = lengths.L2;
    if (P2h <= H1h) return;
    const apex = L1 + (P2h * (L2 - L1)) / (P2h - H1h);
    const half = (geometry.angleDegrees(alpha) * Math.PI) / 360;
    const rho = Math.min(ANGLE_RADIUS, apex - L1 - 0.5);
    const up = [apex - rho * Math.cos(half), -rho * Math.sin(half)];
    const low = [apex - rho * Math.cos(half), rho * Math.sin(half)];
    scene.dimensions.push({
      id: 'alpha',
      path: `M${num(up[0])} ${num(up[1])} A${num(rho)} ${num(rho)} 0 0 0 ${num(low[0])} ${num(low[1])}`,
    });
    scene.points.push(up, low);
    const text = `${format.symbolFor('alpha')} ${format.formatAngle(alpha)}`;
    // Keep the label clear of the bullet base line in the section, which lies just before the apex.
    const baseZ = model.bullet ? model.bullet.base : Infinity;
    const x = Math.min(apex - rho - 0.8, baseZ - 0.8);
    const rect = horizontalLabelRect(text, x, 1.0, 'end');
    scene.labels.push({ id: 'alpha', text, x, baseline: 1.0, anchor: 'end', rect });
    scene.points.push([rect.x0, rect.y0], [rect.x1, rect.y1]);
  }

  /**
   * Title block below the drawing: name, C.I.P. table and revision date, units and scale.
   * @param {any} record
   * @param {{x0: number, x1: number, y1: number}} box extent of the drawing above the block
   */
  function titleBlock(record, box) {
    const width = Math.max(box.x1 - box.x0, TITLE_MIN_WIDTH);
    const x0 = box.x0;
    const y0 = box.y1 + 3;
    const height = 13.5;
    const lines = [
      { text: record.name, size: 4.2, weight: 700, y: y0 + 5.2 },
      { text: `C.I.P. table ${record.tab} · Revised ${record.revised}`, size: FONT, weight: 400, y: y0 + 9.2 },
      { text: 'Dimensions in mm · Scale 1:1', size: FONT, weight: 400, y: y0 + 12.4 },
    ].map((line) => ({ ...line, x: x0 + 1.5 }));
    const frame = { x0, x1: x0 + width, y0, y1: y0 + height };
    return { frame, lines, points: [[frame.x0, frame.y0], [frame.x1, frame.y1]] };
  }

  /** @param {number[][]} points */
  function boundsOf(points) {
    const xs = points.map((p) => p[0]);
    const ys = points.map((p) => p[1]);
    return { x0: Math.min(...xs), x1: Math.max(...xs), y0: Math.min(...ys), y1: Math.max(...ys) };
  }

  /**
   * Renders the scene as an SVG string, with the viewBox fitted to the content.
   * @param {any} scene
   */
  function renderSvg(scene) {
    const b = scene.bounds;
    const pad = 1.5;
    const viewBox = [b.x0 - pad, b.y0 - pad, b.x1 - b.x0 + 2 * pad, b.y1 - b.y0 + 2 * pad].map(num).join(' ');
    const hatch = `hatch-${scene.key}`;
    const out = [];
    out.push(`<svg class="drawing" xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}" role="img" aria-label="${escapeXml(scene.name)} drawing">`);
    out.push(`<defs><pattern id="${hatch}" patternUnits="userSpaceOnUse" width="1.4" height="1.4" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="1.4"/></pattern></defs>`);
    out.push(`<line class="centre" x1="${num(scene.centreLine[0])}" y1="0" x2="${num(scene.centreLine[1])}" y2="0"/>`);
    out.push(`<path class="outline" d="${toPath(scene.upper)}"/>`);
    if (scene.bulletUpper) out.push(`<path class="outline" d="${toPath(scene.bulletUpper)}"/>`);
    for (const polygon of scene.cut) {
      out.push(`<path class="cut" fill="url(#${hatch})" d="${toPath(polygon)} Z"/>`);
    }
    for (const d of scene.extensions) out.push(`<path class="ext" d="${d}"/>`);
    for (const dim of scene.dimensions) {
      if (dim.path) out.push(`<path class="dim" d="${dim.path}"/>`);
      else out.push(`<path class="dim" d="${dim.line}"/><path class="dim-head" d="${dim.heads}"/>`);
    }
    for (const label of scene.labels) {
      if (label.rotated) {
        out.push(`<text class="label" transform="translate(${num(label.baseline)} 0) rotate(-90)" text-anchor="middle" font-size="${FONT}">${escapeXml(label.text)}</text>`);
      } else {
        out.push(`<text class="label" x="${num(label.x)}" y="${num(label.baseline)}" text-anchor="${label.anchor}" font-size="${FONT}">${escapeXml(label.text)}</text>`);
      }
    }
    const { frame, lines } = scene.title;
    out.push(`<g class="title"><rect class="title-frame" x="${num(frame.x0)}" y="${num(frame.y0)}" width="${num(frame.x1 - frame.x0)}" height="${num(frame.y1 - frame.y0)}"/>`);
    for (const line of lines) {
      out.push(`<text x="${num(line.x)}" y="${num(line.y)}" font-size="${line.size}" font-weight="${line.weight}">${escapeXml(line.text)}</text>`);
    }
    out.push('</g></svg>');
    return out.join('');
  }

  /** @param {string} text */
  function escapeXml(text) {
    return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  root.CIP.drawing = {
    FONT,
    buildScene,
    renderSvg,
    textWidth,
    horizontalLabelRect,
    rotatedLabelRect,
    escapeXml,
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
