/**
 * Display formatting for cartridge values: symbols, units, angles and tolerances.
 * Pure functions, no DOM, so they can be unit tested in Node.
 */
(function (root) {
  root.CIP = root.CIP || {};

  /** Field names whose published symbol differs from the field name. */
  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };

  /** Fields that are angles: a number of degrees or a {degrees, minutes, seconds} object. */
  const ANGLE_FIELDS = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);

  /** Fields with a unit other than mm. */
  const UNITS = {
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: '—',
  };

  const NO_UNIT = '—';

  /** @param {number} value */
  function formatNumber(value) {
    return String(value);
  }

  /** @param {number} value */
  function padTwo(value) {
    return String(value).padStart(2, '0');
  }

  /**
   * @param {number | {degrees: number, minutes: number, seconds: number}} angle
   * @returns {string}
   */
  function formatAngle(angle) {
    if (typeof angle === 'number') {
      return `${formatNumber(angle)}°`;
    }
    const { degrees, minutes, seconds } = angle;
    return `${formatNumber(degrees)}°${padTwo(minutes)}'${padTwo(seconds)}"`;
  }

  /** @param {string} name */
  function symbolFor(name) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, name) ? SYMBOLS[name] : name;
  }

  /** @param {string} name */
  function unitFor(name) {
    if (ANGLE_FIELDS.has(name)) return NO_UNIT;
    return Object.prototype.hasOwnProperty.call(UNITS, name) ? UNITS[name] : 'mm';
  }

  /**
   * @param {string} name
   * @param {unknown} value
   * @returns {string}
   */
  function formatValue(name, value) {
    if (ANGLE_FIELDS.has(name)) return formatAngle(/** @type {any} */ (value));
    return formatNumber(/** @type {number} */ (value));
  }

  /**
   * Table rows for one section. A `<X>Tol` entry is folded into the row of X
   * ("3.13 -0.2") and never gets a row of its own.
   *
   * @param {Record<string, unknown>} section
   * @returns {{ symbol: string, value: string, unit: string }[]}
   */
  function sectionRows(section) {
    const rows = [];
    for (const name of Object.keys(section)) {
      if (isTolerance(name)) {
        const parent = name.slice(0, -TOLERANCE_SUFFIX.length);
        if (!(parent in section)) {
          rows.push({ symbol: symbolFor(name), value: formatNumber(section[name]), unit: unitFor(name) });
        }
        continue;
      }
      const tolerance = name + TOLERANCE_SUFFIX;
      const value = tolerance in section
        ? `${formatValue(name, section[name])} ${formatNumber(section[tolerance])}`
        : formatValue(name, section[name]);
      rows.push({ symbol: symbolFor(name), value, unit: unitFor(name) });
    }
    return rows;
  }

  const TOLERANCE_SUFFIX = 'Tol';

  /** @param {string} name */
  function isTolerance(name) {
    return name.length > TOLERANCE_SUFFIX.length && name.endsWith(TOLERANCE_SUFFIX);
  }

  /** @param {number} count */
  function countLabel(count) {
    return count === 1 ? '1 cartridge' : `${count} cartridges`;
  }

  /**
   * @param {{ grH2O: number, source?: string, url?: string, note?: string } | undefined} capacity
   * @returns {string | null}
   */
  function waterCapacityText(capacity) {
    if (!capacity) return null;
    return `${formatNumber(capacity.grH2O)} grH2O`;
  }

  root.CIP.format = {
    SYMBOLS,
    formatNumber,
    formatAngle,
    formatValue,
    symbolFor,
    unitFor,
    sectionRows,
    countLabel,
    waterCapacityText,
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
