/**
 * Cartridge geometry in millimetres, built from one record by the rules of the brief.
 *
 * Coordinates are [z, r] pairs: z runs along the axis from the head face (z = 0)
 * towards the mouth, r is the radius. Everything is in mm, so drawing units are mm.
 * No DOM access: this module is unit tested in Node.
 */
(function (root) {
  root.CIP = root.CIP || {};

  const DEG = Math.PI / 180;
  /** Arc sampling step, radians. */
  const ARC_STEP = 3 * DEG;
  /** Samples along the bullet nose. */
  const NOSE_SAMPLES = 60;
  /** Largest difference between H2 and G1 that counts as a heeled bullet, mm. */
  const HEEL_LIMIT = 0.015;

  /** Primer pocket by primer type: diameter and depth, mm. Rimfire has none. */
  const PRIMER_POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 },
  };

  /**
   * An angle is a number of degrees or a {degrees, minutes, seconds} object.
   * @param {unknown} value
   * @returns {number | undefined}
   */
  function angleDegrees(value) {
    if (typeof value === 'number') return value;
    if (value && typeof value === 'object') {
      const { degrees, minutes, seconds } = /** @type {any} */ (value);
      return degrees + minutes / 60 + seconds / 3600;
    }
    return undefined;
  }

  /** @param {unknown} value */
  function isNumber(value) {
    return typeof value === 'number' && Number.isFinite(value);
  }

  /** @param {number} value @param {number} low @param {number} high */
  function clamp(value, low, high) {
    return Math.min(high, Math.max(low, value));
  }

  /**
   * Rim class: belted and rimfire by family, otherwise by R1/P1.
   * @param {any} record
   * @returns {'belted' | 'rimfire' | 'rimmed' | 'rebated' | 'rimless' | 'unknown'}
   */
  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    const R1 = record.cartridge.caseHead.R1;
    const P1 = record.cartridge.powderChamber.P1;
    if (!isNumber(R1) || !isNumber(P1) || P1 <= 0) return 'unknown';
    const ratio = R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  /**
   * Linear interpolation on a polyline sorted by z.
   * @param {number[][]} polyline [z, r] pairs
   * @param {number} z
   */
  function interpolate(polyline, z) {
    for (let i = 1; i < polyline.length; i += 1) {
      const [z0, r0] = polyline[i - 1];
      const [z1, r1] = polyline[i];
      if (z >= z0 && z <= z1 && z1 > z0) return r0 + ((z - z0) / (z1 - z0)) * (r1 - r0);
    }
    return polyline[polyline.length - 1][1];
  }

  /**
   * Replace each vertex that carries a fillet radius with a circular arc tangent
   * to both neighbouring segments. Vertices without `rad` pass through unchanged.
   * @param {{ z: number, r: number, rad?: number }[]} points
   * @returns {number[][]}
   */
  function roundCorners(points) {
    const out = [];
    for (let i = 0; i < points.length; i += 1) {
      const p = points[i];
      const a = points[i - 1];
      const b = points[i + 1];
      if (!p.rad || !a || !b) {
        out.push([p.z, p.r]);
        continue;
      }
      out.push(...filletArc(a, p, b, p.rad));
    }
    return out;
  }

  /**
   * @param {{ z: number, r: number }} a
   * @param {{ z: number, r: number }} p corner
   * @param {{ z: number, r: number }} b
   * @param {number} radius
   * @returns {number[][]} points from the first tangent point to the second
   */
  function filletArc(a, p, b, radius) {
    const v1 = unit(a.z - p.z, a.r - p.r);
    const v2 = unit(b.z - p.z, b.r - p.r);
    if (!v1 || !v2) return [[p.z, p.r]];
    const cosTheta = clamp(v1[0] * v2[0] + v1[1] * v2[1], -1, 1);
    const theta = Math.acos(cosTheta);
    if (theta < 1e-6 || Math.PI - theta < 1e-6) return [[p.z, p.r]];
    const halfTan = Math.tan(theta / 2);
    const maxDistance = Math.min(Math.hypot(a.z - p.z, a.r - p.r), Math.hypot(b.z - p.z, b.r - p.r));
    const distance = Math.min(radius / halfTan, maxDistance * 0.999);
    const effectiveRadius = distance * halfTan;
    const bis = unit(v1[0] + v2[0], v1[1] + v2[1]);
    const centreDistance = effectiveRadius / Math.sin(theta / 2);
    const cz = p.z + bis[0] * centreDistance;
    const cr = p.r + bis[1] * centreDistance;
    const t1 = [p.z + v1[0] * distance, p.r + v1[1] * distance];
    const t2 = [p.z + v2[0] * distance, p.r + v2[1] * distance];
    const start = Math.atan2(t1[1] - cr, t1[0] - cz);
    const end = Math.atan2(t2[1] - cr, t2[0] - cz);
    let sweep = end - start;
    while (sweep > Math.PI) sweep -= 2 * Math.PI;
    while (sweep < -Math.PI) sweep += 2 * Math.PI;
    const steps = Math.max(2, Math.ceil(Math.abs(sweep) / ARC_STEP));
    const arc = [];
    for (let i = 0; i <= steps; i += 1) {
      const angle = start + (sweep * i) / steps;
      arc.push([cz + effectiveRadius * Math.cos(angle), cr + effectiveRadius * Math.sin(angle)]);
    }
    return arc;
  }

  /** @returns {[number, number] | null} */
  function unit(dz, dr) {
    const length = Math.hypot(dz, dr);
    return length > 0 ? [dz / length, dr / length] : null;
  }

  /**
   * Drop consecutive duplicate points (within a tiny tolerance).
   * @param {number[][]} points
   */
  function dedupe(points) {
    const out = [];
    for (const point of points) {
      const last = out[out.length - 1];
      if (!last || Math.abs(last[0] - point[0]) > 1e-9 || Math.abs(last[1] - point[1]) > 1e-9) {
        out.push(point);
      }
    }
    return out;
  }

  /**
   * Head face and rim, then the extractor groove or the step to the body.
   * Returns the vertices (some with fillet radii) and where the body starts.
   */
  function headAndRim(input) {
    const { R1h, Rt, rimType: rim } = input;
    const verts = [{ z: 0, r: 0 }];
    let back;
    if (rim === 'rimfire') {
      const rr = Math.max(0, Math.min(Rt / 2, (input.R1 - input.P1) / 2));
      const rc = R1h - rr;
      const zc = Rt / 2;
      verts.push({ z: 0, r: rc });
      if (rr < Rt / 2) verts.push({ z: zc - rr, r: rc });
      const arcSteps = 16;
      for (let i = 0; i <= arcSteps; i += 1) {
        const phi = -Math.PI / 2 + (Math.PI * i) / arcSteps;
        verts.push({ z: zc + rr * Math.sin(phi), r: rc + rr * Math.cos(phi) });
      }
      back = { z: Rt, r: rc };
      if (rr < Rt / 2) verts.push(back);
    } else {
      const chamfer = input.chamfer;
      if (chamfer) {
        verts.push({ z: 0, r: R1h - chamfer.x }, { z: chamfer.f, r: R1h });
      } else {
        verts.push({ z: 0, r: R1h });
      }
      back = { z: Rt, r: R1h };
      verts.push(back);
    }
    return { verts, back };
  }

  /**
   * Outer half-profile from the head face to the mouth, before rounding.
   * @param {any} input
   */
  function outerVertices(input) {
    const { verts, back } = headAndRim(input);
    const { E1h, Rt, eMin, P1h, groove, belted, beltRamp, E, L1, L2, L3, P2h, H1h, H2h, r1, r2, bottleneck } = input;
    let bodyStart = Rt;
    let beltEnd;
    if (groove) {
      verts.push({ z: back.z, r: E1h }, { z: Rt + eMin, r: E1h });
      if (belted) {
        const R3h = beltRamp.R3h;
        const zRamp = Rt + eMin + (R3h - E1h) / Math.tan(beltRamp.delta * DEG);
        verts.push({ z: zRamp, r: R3h }, { z: E, r: R3h });
        beltEnd = zRamp;
      }
      verts.push({ z: E, r: P1h });
      bodyStart = E;
    } else {
      verts.push({ z: back.z, r: P1h });
    }
    if (bottleneck) {
      verts.push({ z: L1, r: P2h, rad: r1 }, { z: L2, r: H1h, rad: r2 });
    }
    verts.push({ z: L3, r: H2h });
    return { points: dedupe(roundCorners(verts)), bodyStart, beltEnd };
  }

  /**
   * Inner (cavity) line: the outer line offset inward by the wall thickness at each z.
   * @param {number[][]} outer
   * @param {number} startZ head solid top w
   * @param {(z: number) => number} thickness
   * @param {number} mouthRadius inner radius at the mouth
   * @param {number} mouthZ
   */
  function innerLine(outer, startZ, thickness, mouthRadius, mouthZ) {
    const cut = [[startZ, interpolate(outer, startZ)]];
    for (const point of outer) if (point[0] > startZ) cut.push(point);
    const points = cut.map((point, i) => {
      const prev = cut[Math.max(0, i - 1)];
      const next = cut[Math.min(cut.length - 1, i + 1)];
      const dz = next[0] - prev[0];
      const dr = next[1] - prev[1];
      const length = Math.hypot(dz, dr) || 1;
      // Outward normal of the outer line is (-dr, dz)/length; move against it by the wall.
      const t = thickness(point[0]);
      return [point[0] + (dr / length) * t, point[1] - (dz / length) * t];
    });
    const last = points.length - 1;
    points[last] = [mouthZ, mouthRadius];
    return points;
  }

  /**
   * Bullet seating, nose and section, from the rules in the brief.
   * @param {any} record
   * @param {{ G1: number, H2: number, L3: number, L6: number, tb: number, heeled: boolean }} input
   */
  function buildBullet(record, input) {
    const shape = record.annotations.defaultBulletShape;
    const category = record.annotations.category;
    const isPistol = category === 'pistol';
    const { G1, H2, L3, L6, tb, heeled } = input;
    const rules = BULLET_RULES[shape];
    if (!rules) return null;
    const seatDepth = rules.seat(isPistol) * G1;
    const zb = L3 - seatDepth;
    const k = rules.k(isPistol);
    const exposedD = heeled ? H2 : G1;
    const exposedR = exposedD / 2;
    const seatR = heeled ? H2 / 2 - tb : G1 / 2;
    const meplat = rules.meplat(exposedD);
    const zs = zb + k * (L6 - zb);
    const nose = noseRadius(rules.nose, exposedD / 2, meplat / 2, zs, L6);
    const profile = [[zb, seatR]];
    if (zs > L3) profile.push([L3, seatR], [L3, exposedR]);
    profile.push([zs, exposedR]);
    for (let i = 1; i <= NOSE_SAMPLES; i += 1) {
      const z = zs + ((L6 - zs) * i) / NOSE_SAMPLES;
      profile.push([z, nose(z)]);
    }
    profile[profile.length - 1] = [L6, meplat / 2];
    const outside = profile.filter(([z]) => z >= L3 - 1e-12);
    const exposedOutside = [[L3, exposedR], ...outside.filter(([z]) => z > L3 + 1e-12), [L6, 0]];
    return {
      shape,
      category,
      base: zb,
      tip: L6,
      seatDepth,
      noseStart: zs,
      radius: G1 / 2,
      exposedRadius: exposedR,
      seatRadius: seatR,
      meplatRadius: meplat / 2,
      heeled,
      profile,
      section: [[zb, 0], ...profile, [L6, 0]],
      outside: exposedOutside,
    };
  }

  /** Seating depth, shank length fraction and meplat per bullet shape. */
  const BULLET_RULES = {
    pointy: {
      seat: () => 1.0,
      k: () => 0.4,
      meplat: (d) => Math.max(0.08 * d, 1.27),
      nose: 'ogive',
    },
    rounded: {
      seat: (pistol) => (pistol ? 0.4 : 0.8),
      k: (pistol) => (pistol ? 0.65 : 0.55),
      meplat: (d) => 0.15 * d,
      nose: 'ellipse',
    },
    flat: {
      seat: (pistol) => (pistol ? 0.4 : 0.8),
      k: (pistol) => (pistol ? 0.7 : 0.6),
      meplat: (d) => 0.55 * d,
      nose: 'cone',
    },
    semi_wadcutter: {
      seat: () => 0.6,
      k: () => 0.78,
      meplat: (d) => 0.6 * d,
      nose: 'cone',
    },
  };

  /**
   * Radius of the nose as a function of z, for nose start zs and tip L6.
   * @param {'ogive' | 'ellipse' | 'cone'} type
   * @param {number} radius bullet radius at the nose start
   * @param {number} meplatRadius
   * @param {number} zs
   * @param {number} zt tip z
   */
  function noseRadius(type, radius, meplatRadius, zs, zt) {
    const n = zt - zs;
    if (type === 'ogive') {
      const d = radius - meplatRadius;
      const rho = (d * d + n * n) / (2 * d);
      const centre = radius - rho;
      return (z) => centre + Math.sqrt(Math.max(0, rho * rho - (z - zs) * (z - zs)));
    }
    if (type === 'ellipse') {
      const a = radius - meplatRadius;
      return (z) => (radius - a) + a * Math.sqrt(Math.max(0, 1 - ((z - zs) / n) * ((z - zs) / n)));
    }
    return (z) => radius + (meplatRadius - radius) * ((z - zs) / n);
  }

  /**
   * Full model for drawing and tables. Missing values that a rule needs produce a note
   * and the feature is left out; nothing is invented.
   * @param {any} record
   */
  function buildModel(record) {
    const cp = record.cartridge;
    const head = cp.caseHead || {};
    const collar = cp.collar || {};
    const junction = cp.junctionCone || {};
    const lengths = cp.lengths || {};
    const pc = cp.powderChamber || {};
    const proj = cp.projectile || {};
    const notes = [];
    const rim = rimType(record);
    const base = { key: record.key, name: record.name, rimType: rim, notes };

    const required = { R1: cp.caseHead.R1, P1: pc.P1, R: head.R, L3: lengths.L3, H2: collar.H2, G1: proj.G1 };
    const missingRequired = Object.keys(required).filter((name) => !isNumber(required[name]));
    if (missingRequired.length > 0) {
      notes.push(`Not drawn: ${missingRequired.join(', ')} not published.`);
      return { ...base, drawable: false };
    }

    const R1h = cp.caseHead.R1 / 2;
    const P1h = pc.P1 / 2;
    const H2h = collar.H2 / 2;
    const Rt = head.R;
    const L3 = lengths.L3;
    const L6 = lengths.L6;
    const G1 = proj.G1;
    const H2 = collar.H2;
    const L1 = lengths.L1;
    const L2 = lengths.L2;
    const alpha = angleDegrees(junction.alpha);
    const bottleneckBasis = isNumber(alpha) && isNumber(L1) && isNumber(L2);
    const bottleneck = bottleneckBasis && isNumber(pc.P2) && isNumber(collar.H1);
    if (bottleneckBasis && !bottleneck) notes.push('Shoulder not drawn: P2 or H1 not published.');

    const groove = isNumber(head.E) && isNumber(head.E1);
    const eMin = isNumber(head.eMin) ? head.eMin : null;
    const grooveDrawn = groove && eMin !== null;
    if (groove && eMin === null) notes.push('Extractor groove not drawn: eMin not published.');

    const beta = angleDegrees(head.beta);
    const chamferDrawn = rim !== 'rimfire' && isNumber(beta) && beta < 90 && isNumber(head.f) && head.f < Rt;
    if (rim !== 'rimfire' && isNumber(beta) && beta < 90 && !isNumber(head.f)) {
      notes.push('Chamfer not drawn: f not published.');
    }

    const belted = rim === 'belted';
    const beltOk = belted && grooveDrawn && isNumber(head.R3) && isNumber(angleDegrees(head.delta));
    if (belted && grooveDrawn && !beltOk) notes.push('Belt ramp not drawn: R3 or delta not published.');

    const r1 = isNumber(junction.r1Min) ? junction.r1Min : undefined;
    const r2 = isNumber(junction.r2) ? junction.r2 : undefined;
    const tn = Math.max(0, (H2 - G1) / 2);
    const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1h);
    const heeled = H2 - G1 <= HEEL_LIMIT;

    const outerInput = {
      R1h,
      R1: cp.caseHead.R1,
      P1: pc.P1,
      P1h,
      Rt,
      rimType: rim,
      chamfer: chamferDrawn ? { f: head.f, x: Math.min(head.f * Math.tan(beta * DEG), R1h / 2) } : null,
      E1h: grooveDrawn ? head.E1 / 2 : 0,
      eMin: grooveDrawn ? eMin : 0,
      groove: grooveDrawn,
      belted: beltOk,
      beltRamp: beltOk ? { R3h: head.R3 / 2, delta: angleDegrees(head.delta) } : null,
      E: grooveDrawn ? head.E : 0,
      bottleneck,
      L1,
      L2,
      L3,
      P2h: bottleneck ? pc.P2 / 2 : 0,
      H1h: bottleneck ? collar.H1 / 2 : 0,
      H2h,
      r1: bottleneck ? r1 : undefined,
      r2: bottleneck ? r2 : undefined,
    };
    const { points: outer, bodyStart, beltEnd } = outerVertices(outerInput);
    const mouthZ = L3;
    const thickness = (z) => {
      if (!bottleneck) return tb + (tn - tb) * clamp((z - bodyStart) / (mouthZ - bodyStart), 0, 1);
      if (z <= L1) return tb;
      if (z >= L2) return tn;
      return tb + ((tn - tb) * (z - L1)) / (L2 - L1);
    };

    const pocket = primerPocket(record.annotations.primerType, rim, notes);
    let w = Math.max(2.5, 0.25 * P1h);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (belted && beltEnd !== undefined) w = Math.max(w, beltEnd + tb);
    else if (grooveDrawn) w = Math.max(w, head.E + tb);

    const inner = innerLine(outer, w, thickness, H2h - tn, mouthZ);

    const sectionPolygon = caseSectionPolygon(outer, inner, w, pocket);
    const bullet = buildBulletOrNote(record, { G1, H2, L3, L6, tb, heeled }, notes);

    return {
      ...base,
      drawable: true,
      bottleneck,
      groove: grooveDrawn,
      belted: beltOk,
      heeled,
      wall: { tb, tn },
      head: { w, pocket },
      profile: { outer, inner, section: sectionPolygon },
      bullet,
      bodyStart,
      notes,
    };
  }

  /** @returns {{ radius: number, depth: number } | null} */
  function primerPocket(primerType, rim, notes) {
    if (rim === 'rimfire' || primerType === 'rimfire') return null;
    const entry = PRIMER_POCKETS[primerType];
    if (!entry) {
      notes.push(`Primer pocket not drawn: primer type ${primerType} is not in the table.`);
      return null;
    }
    return { radius: entry.diameter / 2, depth: entry.depth };
  }

  /** @returns {object | null} */
  function buildBulletOrNote(record, input, notes) {
    if (!isNumber(input.L6)) {
      notes.push('Bullet not drawn: L6 not published.');
      return null;
    }
    const bullet = buildBullet(record, input);
    if (!bullet) {
      notes.push(`Bullet not drawn: defaultBulletShape ${record.annotations.defaultBulletShape} is not known.`);
    }
    return bullet;
  }

  /**
   * Closed polygon of the cut case in the (z, r) half-plane: the solid head, the
   * walls from the head top to the mouth, and the primer pocket as a void.
   */
  function caseSectionPolygon(outer, inner, w, pocket) {
    const poly = [];
    if (pocket) {
      poly.push([0, pocket.radius], [pocket.depth, pocket.radius], [pocket.depth, 0]);
    } else {
      poly.push([0, 0]);
    }
    poly.push([w, 0]);
    for (const point of inner) poly.push(point);
    for (let i = outer.length - 1; i >= 1; i -= 1) poly.push(outer[i]);
    return poly;
  }

  root.CIP.geometry = {
    angleDegrees,
    rimType,
    interpolate,
    roundCorners,
    buildModel,
    PRIMER_POCKETS,
    BULLET_RULES,
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
