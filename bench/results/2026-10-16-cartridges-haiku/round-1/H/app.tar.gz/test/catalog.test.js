'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

require('../data/cartridges.js');
require('../src/format.js');
require('../src/catalog.js');

const { catalog } = globalThis.CIP;
const records = globalThis.CIP.records;
const byKey = (key) => records.find((r) => r.key === key);

test('the data holds 25 cartridges with unique keys and names', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
  assert.equal(new Set(records.map((r) => r.name)).size, 25);
});

test('search matches the name case-insensitively', () => {
  const hits = catalog.filterCartridges(records, { query: '223 rem', family: 'All' });
  assert.deepEqual(hits.map((r) => r.key), ['223_rem']);
});

test('search matches alternative names, so 7,62 x 51 finds 308 Win.', () => {
  const hits = catalog.filterCartridges(records, { query: '7,62 x 51', family: 'All' });
  assert.deepEqual(hits.map((r) => r.key), ['308_win']);
});

test('search ignores surrounding and repeated whitespace', () => {
  const hits = catalog.filterCartridges(records, { query: '  7,62   x 51 ', family: 'All' });
  assert.deepEqual(hits.map((r) => r.key), ['308_win']);
});

test('an empty search lists everything', () => {
  assert.equal(catalog.filterCartridges(records, { query: '  ', family: 'All' }).length, 25);
});

test('the family filter narrows by family and combines with search', () => {
  const rimfire = catalog.filterCartridges(records, { query: '', family: 'rimfire' });
  assert.deepEqual(rimfire.map((r) => r.key).sort(), ['17_hmr', '22_long_rifle', '22_win_mag_r_f']);
  assert.deepEqual(
    catalog.filterCartridges(records, { query: 'mag', family: 'rimfire' }).map((r) => r.key),
    ['22_win_mag_r_f'],
  );
});

test('the family options are All then the five families in the brief', () => {
  assert.deepEqual(catalog.FAMILY_OPTIONS, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('summaries carry the name, family and case length L3 with its tolerance', () => {
  assert.deepEqual(catalog.summarise(byKey('223_rem')), {
    key: '223_rem',
    name: '223 Rem.',
    family: 'rimless',
    l3: '44.7 mm',
  });
});

test('routes: the root and empty hash show the list, a cartridge hash shows its detail', () => {
  assert.deepEqual(catalog.parseRoute(''), { view: 'list' });
  assert.deepEqual(catalog.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(catalog.parseRoute('#/cartridge/308_win'), { view: 'cartridge', key: '308_win' });
  assert.deepEqual(catalog.parseRoute('#/cartridge/9_mm_luger'), { view: 'cartridge', key: '9_mm_luger' });
});

test('an unknown cartridge route is kept so the page can say it was not found', () => {
  assert.deepEqual(catalog.parseRoute('#/cartridge/nope'), { view: 'cartridge', key: 'nope' });
});

test('route hashes round-trip and survive a reload', () => {
  for (const record of records) {
    const hash = catalog.routeHash(record.key);
    assert.deepEqual(catalog.parseRoute(hash), { view: 'cartridge', key: record.key });
  }
  assert.equal(catalog.routeHash('308_win'), '#/cartridge/308_win');
});
