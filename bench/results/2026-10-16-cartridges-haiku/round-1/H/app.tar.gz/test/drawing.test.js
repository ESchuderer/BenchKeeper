'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

require('../data/cartridges.js');
require('../src/format.js');
require('../src/geometry.js');
require('../src/drawing.js');

const { geometry, drawing } = globalThis.CIP;
const records = globalThis.CIP.records;
const scenes = new Map(records.map((r) => [r.key, drawing.buildScene(r, geometry.buildModel(r))]));
const MARGIN = 0.3;

test('every cartridge has a scene', () => {
  for (const [key, scene] of scenes) assert.ok(scene, key);
});

test('labels do not overlap each other or the outline, for all 25 cartridges', () => {
  for (const scene of scenes.values()) {
    const outlines = segmentsOf(scene);
    scene.labels.forEach((label, i) => {
      for (const other of scene.labels.slice(i + 1)) {
        assert.ok(!overlaps(label.rect, other.rect, MARGIN), `${scene.key}: ${label.text} overlaps ${other.text}`);
      }
      for (const [p, q] of outlines) {
        assert.ok(!segmentHitsRect(p, q, label.rect, MARGIN), `${scene.key}: ${label.text} touches the outline`);
      }
    });
  }
});

test('the drawing is labelled, scaled in mm and carries the title block', () => {
  const scene = scenes.get('223_rem');
  const svg = drawing.renderSvg(scene);
  assert.match(svg, /role="img"/);
  assert.match(svg, /aria-label="223 Rem\. drawing"/);
  assert.match(svg, /<svg class="drawing"[^>]*viewBox="/);
  assert.match(svg, />223 Rem\.</);
  assert.match(svg, /C\.I\.P\. table I · Revised 2017-05-17/);
  assert.match(svg, /Dimensions in mm · Scale 1:1/);
});

test('dimensions carry their symbol and value, with the tolerance next to the value', () => {
  const labels = scenes.get('223_rem').labels.map((l) => l.text);
  assert.ok(labels.includes('L3 44.7'), labels.join(' | '));
  assert.ok(labels.includes('L1 36.52 -0.2'), labels.join(' | '));
  assert.ok(labels.includes('P1 9.58'), labels.join(' | '));
  assert.ok(labels.includes('α 46°'), labels.join(' | '));
  assert.ok(labels.includes('R 1.14'), labels.join(' | '));
});

test('a heeled 22 Long Rifle shows the shoulder-free layout, with no alpha label', () => {
  const labels = scenes.get('22_long_rifle').labels.map((l) => l.text);
  assert.equal(labels.some((t) => t.startsWith('α')), false);
  assert.ok(labels.includes('L3 15.57'), labels.join(' | '));
});

test('the search for SVG names escapes characters that are special in XML', () => {
  const svg = drawing.renderSvg(scenes.get('40_s_w'));
  assert.match(svg, /40 S\.&amp; W\. drawing/);
});

function segmentsOf(scene) {
  const segments = [];
  const add = (points, closed) => {
    for (let i = 0; i + 1 < points.length + (closed ? 1 : 0); i += 1) {
      const p = points[i];
      const q = points[(i + 1) % points.length];
      if (p[1] === 0 && q[1] === 0) continue;
      segments.push([p, q]);
    }
  };
  add(scene.upper, false);
  if (scene.bulletUpper) add(scene.bulletUpper, false);
  for (const polygon of scene.cut) add(polygon, true);
  return segments;
}

function overlaps(a, b, margin) {
  return a.x0 < b.x1 + margin && b.x0 < a.x1 + margin && a.y0 < b.y1 + margin && b.y0 < a.y1 + margin;
}

function segmentHitsRect(p, q, rect, margin) {
  const length = Math.hypot(q[0] - p[0], q[1] - p[1]);
  const steps = Math.max(1, Math.ceil(length / 0.02));
  for (let i = 0; i <= steps; i += 1) {
    const t = i / steps;
    const x = p[0] + (q[0] - p[0]) * t;
    const y = p[1] + (q[1] - p[1]) * t;
    if (x >= rect.x0 - margin && x <= rect.x1 + margin && y >= rect.y0 - margin && y <= rect.y1 + margin) {
      return true;
    }
  }
  return false;
}
