'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

require('../data/cartridges.js');
require('../src/format.js');

const { format } = globalThis.CIP;
const records = globalThis.CIP.records;

test('plain numbers keep their published decimals and have no thousands separator', () => {
  assert.equal(format.formatNumber(51.18), '51.18');
  assert.equal(format.formatNumber(4150), '4150');
  assert.equal(format.formatNumber(4150.0), '4150');
  assert.equal(format.formatNumber(-0.2), '-0.2');
});

test('numeric angles show as whole degrees with a degree sign', () => {
  assert.equal(format.formatAngle(40), '40°');
  assert.equal(format.formatAngle(35.0), '35°');
  assert.equal(format.formatAngle(0), '0°');
});

test('angle objects show as degrees, minutes and seconds with two-digit fields', () => {
  assert.equal(format.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(format.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
});

test('symbols follow the brief, falling back to the field name', () => {
  const expected = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
    L3: 'L3',
    E1: 'E1',
    i: 'i',
  };
  for (const [name, symbol] of Object.entries(expected)) {
    assert.equal(format.symbolFor(name), symbol, name);
  }
});

test('units follow the brief: mm for lengths, bar, J, g, mm² and no unit for counts and angles', () => {
  assert.equal(format.unitFor('L3'), 'mm');
  assert.equal(format.unitFor('G1'), 'mm');
  assert.equal(format.unitFor('Pmax'), 'bar');
  assert.equal(format.unitFor('PK'), 'bar');
  assert.equal(format.unitFor('PE'), 'bar');
  assert.equal(format.unitFor('EE'), 'J');
  assert.equal(format.unitFor('M'), 'g');
  assert.equal(format.unitFor('Q'), 'mm²');
  assert.equal(format.unitFor('N'), '—');
  assert.equal(format.unitFor('alpha'), '—');
  assert.equal(format.unitFor('i'), '—');
});

test('a tolerance is folded into the value of the field it belongs to', () => {
  const rows = format.sectionRows({ E: 3.13, ETol: -0.2, E1: 8.43 });
  assert.deepEqual(rows, [
    { symbol: 'E', value: '3.13 -0.2', unit: 'mm' },
    { symbol: 'E1', value: '8.43', unit: 'mm' },
  ]);
});

test('an orphan tolerance is shown as its own row rather than dropped', () => {
  const rows = format.sectionRows({ L9Tol: 0.1 });
  assert.deepEqual(rows, [{ symbol: 'L9Tol', value: '0.1', unit: 'mm' }]);
});

test('angle fields in a section are formatted as angles', () => {
  const rows = format.sectionRows({ alpha: { degrees: 46, minutes: 0, seconds: 0 }, beta: 35 });
  assert.deepEqual(rows, [
    { symbol: 'α', value: '46°00\'00"', unit: '—' },
    { symbol: 'β', value: '35°', unit: '—' },
  ]);
});

test('every tolerance in the 25 records has a field to attach to', () => {
  for (const record of records) {
    for (const group of [record.cartridge, record.chamber]) {
      for (const section of Object.values(group)) {
        for (const name of Object.keys(section)) {
          const match = /^(.+)Tol$/.exec(name);
          if (match) {
            assert.ok(name in section || match[1] in section, `${record.key}: ${name} has no parent`);
            assert.ok(match[1] in section, `${record.key}: ${name} parent ${match[1]} missing`);
          }
        }
      }
    }
  }
});

test('count labels read naturally for 0, 1 and many', () => {
  assert.equal(format.countLabel(0), '0 cartridges');
  assert.equal(format.countLabel(1), '1 cartridge');
  assert.equal(format.countLabel(25), '25 cartridges');
});

test('the water capacity line carries its value, unit and source', () => {
  const kwk = records.find((r) => r.key === '223_rem');
  assert.equal(format.waterCapacityText(kwk.annotations.publishedCapacity), '30.5 grH2O');
  assert.equal(format.waterCapacityText(undefined), null);
});
