'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

require('../data/cartridges.js');
require('../src/format.js');
require('../src/geometry.js');

const { geometry } = globalThis.CIP;
const records = globalThis.CIP.records;
const byKey = (key) => records.find((r) => r.key === key);
const models = new Map(records.map((r) => [r.key, geometry.buildModel(r)]));
const near = (actual, expected, tolerance = 1e-6, message = '') =>
  assert.ok(Math.abs(actual - expected) <= tolerance, `${message} expected ${expected}, got ${actual}`);

test('every record builds a drawable model', () => {
  for (const model of models.values()) {
    assert.equal(model.drawable, true, model.key);
    assert.ok(model.profile.outer.length >= 4, model.key);
    assert.ok(model.profile.inner.length >= 2, model.key);
  }
});

test('rim type follows the family first, then the R1/P1 ratio', () => {
  const expected = {
    '223_rem': 'rimless',
    '300_win_mag': 'belted',
    '22_long_rifle': 'rimfire',
    '9_mm_luger': 'rimless',
    '38_special': 'rimmed',
    '357_magnum': 'rimmed',
    '9_3_x_74_r': 'rimmed',
  };
  for (const [key, type] of Object.entries(expected)) {
    assert.equal(models.get(key).rimType, type, key);
  }
});

test('rim type classes by R1/P1 ratio: at least 1.05 rimmed, under 0.98 rebated, otherwise rimless', () => {
  assert.equal(geometry.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 10.6 }, powderChamber: { P1: 10 } } }), 'rimmed');
  assert.equal(geometry.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 9.7 }, powderChamber: { P1: 10 } } }), 'rebated');
  assert.equal(geometry.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 10 }, powderChamber: { P1: 10 } } }), 'rimless');
});

test('223 Rem. head: chamfer, rim edge, extractor groove and body start', () => {
  const { outer } = models.get('223_rem').profile;
  const has = (z, r) => outer.some(([pz, pr]) => Math.abs(pz - z) < 1e-6 && Math.abs(pr - r) < 1e-6);
  assert.equal(outer[0][0], 0);
  assert.equal(outer[0][1], 0, 'starts on the axis at the head face');
  near(outer[1][0], 0, 1e-6, 'head face');
  const chamferX = Math.min(0.45 * Math.tan(35 * Math.PI / 180), 9.6 / 4);
  near(outer[1][1], 4.8 - chamferX, 1e-6, 'chamfer start on the head face');
  assert.ok(has(0.45, 4.8), 'chamfer meets the rim at f');
  assert.ok(has(1.14, 4.8), 'rim back face at R');
  assert.ok(has(1.14, 4.215), 'groove wall at E1/2');
  assert.ok(has(1.9, 4.215), 'groove floor ends at R + eMin');
  assert.ok(has(3.13, 4.79), 'body starts at E with radius P1/2');
});

test('223 Rem. shoulder and neck pass through the published points', () => {
  const { outer } = models.get('223_rem').profile;
  const last = outer[outer.length - 1];
  near(last[0], 44.7, 1e-6, 'mouth z = L3');
  near(last[1], 6.43 / 2, 1e-6, 'mouth r = H2/2');
  const shoulder = outer.filter(([z]) => z > 36.6 && z < 39.4);
  assert.ok(shoulder.length > 0, 'shoulder samples exist between L1 and L2');
});

test('223 Rem. bullet: seated 1.0 x G1 for a pointy bullet, tip at L6, meplat radius max(0.08 G1, 1.27)/2', () => {
  const { bullet } = models.get('223_rem');
  near(bullet.base, 44.7 - 5.7, 1e-9, 'base at L3 - s');
  near(bullet.tip, 57.4, 1e-9, 'tip at L6');
  near(bullet.meplatRadius, 1.27 / 2, 1e-9, 'meplat');
  near(bullet.radius, 5.7 / 2, 1e-9, 'bullet radius is G1/2');
  assert.equal(bullet.heeled, false);
});

test('pointy ogive is tangent to the cylinder where the nose starts', () => {
  const { bullet } = models.get('223_rem');
  const radiusAt = (z) => geometry.interpolate(bullet.profile, z);
  near(radiusAt(bullet.noseStart), bullet.radius, 1e-9, 'radius at nose start equals G1/2');
  // Tangent: the radius falls off with the square of the distance from the nose start.
  const drop = bullet.radius - radiusAt(bullet.noseStart + 0.05);
  assert.ok(drop < 0.001, `tangent start, drop ${drop}`);
});

test('every nose ends in the flat tip of its meplat radius at L6', () => {
  for (const model of models.values()) {
    if (!model.bullet) continue;
    const last = model.bullet.profile[model.bullet.profile.length - 1];
    near(last[0], model.bullet.tip, 1e-9, model.key);
    near(last[1], model.bullet.meplatRadius, 1e-6, model.key);
  }
});

test('pistol seating depth is 0.4 x G1 for a rounded bullet (9 mm Luger)', () => {
  const { bullet } = models.get('9_mm_luger');
  near(bullet.base, 19.15 - 0.4 * 9.03, 1e-9);
  assert.equal(bullet.shape, 'rounded');
});

test('rimfire rounded bullets seat 0.8 x G1 (22 Long Rifle)', () => {
  const { bullet } = models.get('22_long_rifle');
  near(bullet.base, 15.57 - 0.8 * 5.72, 1e-9);
  assert.equal(bullet.heeled, true);
});

test('heeled case: exposed bullet takes the case outside diameter, the seated heel the inside diameter', () => {
  const model = models.get('22_long_rifle');
  near(model.bullet.exposedRadius, 5.72 / 2, 1e-9, 'exposed radius is H2/2');
  near(model.bullet.seatRadius, 5.72 / 2 - model.wall.tb, 1e-9, 'heel radius is (H2 - 2 tb)/2');
});

test('neck and body walls follow the brief: tn = (H2 - G1)/2, tb = min(max(1.3 tn, 0.6), 0.35 P1/2)', () => {
  const { wall } = models.get('223_rem');
  near(wall.tn, (6.43 - 5.7) / 2, 1e-9);
  near(wall.tb, 0.6, 1e-9);
  const big = models.get('9_3_x_62').wall;
  near(big.tn, (9.92 - 9.3) / 2, 1e-9);
  near(big.tb, 0.6, 1e-9);
});

test('the section wall is wall-thick along the body and reaches the neck wall at the mouth', () => {
  const model = models.get('223_rem');
  const { outer, inner } = model.profile;
  const innerMouth = inner[inner.length - 1];
  near(innerMouth[0], 44.7, 1e-9);
  near(innerMouth[1], 6.43 / 2 - model.wall.tn, 1e-9, 'inner mouth radius');
  for (const [z, r] of inner) {
    const outerR = outerRadiusAt(outer, z);
    assert.ok(r < outerR, `inner below outer at z=${z}`);
  }
});

test('solid head runs to w = max(2.5, 0.25 P1/2, pocket depth + 1.5, E + tb)', () => {
  const model = models.get('223_rem');
  near(model.head.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + model.wall.tb), 1e-9);
  near(model.head.pocket.radius, 4.45 / 2, 1e-9, 'small rifle primer diameter');
  near(model.head.pocket.depth, 3.04, 1e-9);
  assert.equal(models.get('6_5_creedmoor').head.pocket.depth, 3.3, 'lr pocket depth');
  assert.equal(models.get('22_long_rifle').head.pocket, null, 'rimfire has no pocket');
});

test('straight cases have no shoulder and no neck', () => {
  const model = models.get('9_mm_luger');
  assert.equal(model.bottleneck, false);
  const last = model.profile.outer[model.profile.outer.length - 1];
  near(last[0], 19.15, 1e-9);
});

test('belted case: the extractor ramp leaves the groove at angle delta to the axis, then the belt runs to E', () => {
  const model = models.get('300_win_mag');
  assert.equal(model.rimType, 'belted');
  const grooveEnd = 1.27 + 0.94;
  const belt = model.profile.outer.filter(([z, r]) => z > grooveEnd && Math.abs(r - 13.51 / 2) < 1e-9);
  assert.ok(belt.length >= 2, 'belt has a run of points at R3/2');
  const beltStart = belt[0][0];
  const expectedRampZ = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  near(beltStart, expectedRampZ, 1e-6, 'belt starts where the ramp ends');
  assert.ok(model.head.w >= beltStart + model.wall.tb - 1e-9);
});

test('a case without a groove steps from the rim to the body at z = R', () => {
  const { outer } = models.get('9_3_x_74_r').profile;
  const bodyStart = outer.find(([z, r]) => z > 1.39 && r < 11.9 / 2 + 1e-9);
  assert.ok(bodyStart, 'body starts after the rim');
  near(bodyStart[0], 1.4, 1e-6, 'step is at z = R');
});

test('no record uses an unknown bullet shape or primer type silently', () => {
  for (const model of models.values()) {
    assert.ok(model.bullet, `${model.key} has a bullet`);
    assert.ok(['pointy', 'rounded', 'flat', 'semi_wadcutter'].includes(model.bullet.shape), model.key);
  }
  assert.equal(models.get('22_win_mag_r_f').head.pocket, null);
});

test('all 25 records draw without skipped features except for notes naming the missing values', () => {
  for (const model of models.values()) {
    for (const note of model.notes) {
      assert.equal(typeof note, 'string');
      assert.ok(note.length > 0, model.key);
    }
  }
  // 9,3 x 74 R has no extractor groove published: that is not a missing value.
  assert.deepEqual(models.get('9_3_x_74_r').notes, []);
});

test('the outside profile is monotone in z so the drawing never folds back', () => {
  for (const model of models.values()) {
    const { outer } = model.profile;
    for (let i = 1; i < outer.length; i += 1) {
      assert.ok(outer[i][0] >= outer[i - 1][0] - 1e-9, `${model.key} at index ${i}`);
    }
  }
});

test('the secant chamfer uses min(f tan beta, R1/4) for the head face', () => {
  const model = models.get('6_5_x_55_se');
  const { outer } = model.profile;
  const expected = Math.min(0.5 * Math.tan(45 * Math.PI / 180), 12.2 / 4);
  near(outer[1][1], 12.2 / 2 - expected, 1e-6);
});

function outerRadiusAt(outer, z) {
  for (let i = 1; i < outer.length; i += 1) {
    const [z0, r0] = outer[i - 1];
    const [z1, r1] = outer[i];
    if (z >= z0 - 1e-12 && z <= z1 + 1e-12 && z1 > z0) {
      return r0 + ((z - z0) / (z1 - z0)) * (r1 - r0);
    }
  }
  return outer[outer.length - 1][1];
}

test('the cut case and bullet sections are simple polygons for all 25 records', () => {
  for (const model of models.values()) {
    assert.ok(!selfIntersects(model.profile.section), `${model.key} case section crosses itself`);
    if (model.bullet) {
      assert.ok(!selfIntersects(model.bullet.section), `${model.key} bullet section crosses itself`);
    }
  }
});

function selfIntersects(polygon) {
  const segments = [];
  for (let i = 0; i < polygon.length; i += 1) {
    segments.push([polygon[i], polygon[(i + 1) % polygon.length]]);
  }
  for (let i = 0; i < segments.length; i += 1) {
    for (let j = i + 2; j < segments.length; j += 1) {
      if (i === 0 && j === segments.length - 1) continue;
      if (properCross(segments[i], segments[j])) return true;
    }
  }
  return false;
}

function properCross([[ax, ay], [bx, by]], [[cx, cy], [dx, dy]]) {
  const d1 = orient(cx, cy, dx, dy, ax, ay);
  const d2 = orient(cx, cy, dx, dy, bx, by);
  const d3 = orient(ax, ay, bx, by, cx, cy);
  const d4 = orient(ax, ay, bx, by, dx, dy);
  const eps = 1e-9;
  return (d1 * d2 < -eps) && (d3 * d4 < -eps);
}

function orient(ax, ay, bx, by, cx, cy) {
  return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
}
