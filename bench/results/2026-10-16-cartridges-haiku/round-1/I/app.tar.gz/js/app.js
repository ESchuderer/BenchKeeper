// Start page (list with search and family filter) and detail view, routed by hash
// so every cartridge has its own bookmarkable address that survives a reload.
(function () {
  'use strict';

  var CIP = window.CIP;
  var F = CIP.format;
  var FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var main = document.getElementById('app');

  function normalise(text) {
    return String(text).toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function matches(rec, query) {
    if (!query) return true;
    return [rec.name].concat(rec.alternativeNames || []).some(function (name) {
      return normalise(name).indexOf(query) !== -1;
    });
  }

  function cartridgeHref(rec) {
    return '#/cartridge/' + encodeURIComponent(rec.key);
  }

  function lengthText(rec) {
    var L = rec.cartridge.lengths;
    return F.formatValue('L3', L.L3, L.L3Tol) + ' mm';
  }

  function renderList() {
    document.title = 'Cartridges · C.I.P. reference';
    main.innerHTML =
      '<h1>Cartridges</h1>' +
      '<div class="controls">' +
        '<label class="field">Search <input id="search" type="search" autocomplete="off" spellcheck="false"></label>' +
        '<label class="field">Family <select id="family">' +
          FAMILIES.map(function (f) {
            return '<option value="' + f + '">' + f + '</option>';
          }).join('') +
        '</select></label>' +
      '</div>' +
      '<p class="count" id="count" aria-live="polite"></p>' +
      '<table class="list">' +
        '<thead><tr><th scope="col">Name</th><th scope="col">Family</th><th scope="col">L3</th></tr></thead>' +
        '<tbody id="rows"></tbody>' +
      '</table>';

    var search = document.getElementById('search');
    var family = document.getElementById('family');
    var rows = document.getElementById('rows');
    var count = document.getElementById('count');

    function update() {
      var query = normalise(search.value);
      var list = CIP.cartridges.filter(function (rec) {
        return (family.value === 'All' || rec.family === family.value) && matches(rec, query);
      });
      rows.innerHTML = list.map(function (rec) {
        return '<tr>' +
          '<th scope="row"><a href="' + cartridgeHref(rec) + '">' + F.escapeHtml(rec.name) + '</a></th>' +
          '<td>' + F.escapeHtml(rec.family) + '</td>' +
          '<td class="num">' + F.escapeHtml(lengthText(rec)) + '</td>' +
        '</tr>';
      }).join('');
      count.textContent = list.length + (list.length === 1 ? ' cartridge' : ' cartridges');
    }

    search.addEventListener('input', update);
    family.addEventListener('change', update);
    update();
  }

  function factRows(rec) {
    var facts = [];
    if (rec.alternativeNames && rec.alternativeNames.length) {
      facts.push(['Alternative names', rec.alternativeNames.join(', ')]);
    }
    facts.push(['Family', rec.family]);
    facts.push(['Category', rec.annotations.category]);
    facts.push(['Primer type', rec.annotations.primerType]);
    facts.push(['C.I.P. table', rec.tab]);
    facts.push(['Country', rec.country]);
    facts.push(['Published', rec.published]);
    facts.push(['Revised', rec.revised]);
    facts.push(['Pressure method', rec.pressureMethod]);
    return facts.map(function (fact) {
      return '<div><dt>' + F.escapeHtml(fact[0]) + '</dt><dd>' + F.escapeHtml(fact[1]) + '</dd></div>';
    }).join('');
  }

  function capacityHtml(rec) {
    var cap = rec.annotations.publishedCapacity;
    if (!cap) return '<dd>not published</dd>';
    var text = F.escapeHtml(cap.grH2O + ' gr H2O');
    var source = cap.url
      ? '<a href="' + F.escapeHtml(cap.url) + '" rel="noopener noreferrer">' + F.escapeHtml(cap.source) + '</a>'
      : F.escapeHtml(cap.source);
    var note = cap.note ? ' · ' + F.escapeHtml(cap.note) : '';
    return '<dd>' + text + ' · source: ' + source + note + '</dd>';
  }

  function groupHtml(group) {
    return '<section class="group"><h3>' + F.escapeHtml(group.title) + '</h3>' +
      '<table class="values"><thead><tr><th scope="col">Symbol</th><th scope="col">Value</th><th scope="col">Unit</th></tr></thead><tbody>' +
      group.rows.map(function (row) {
        return '<tr><th scope="row">' + F.escapeHtml(row.symbol) + '</th>' +
          '<td class="num">' + F.escapeHtml(row.value) + '</td>' +
          '<td>' + F.escapeHtml(row.unit) + '</td></tr>';
      }).join('') +
      '</tbody></table></section>';
  }

  function renderDetail(key) {
    var rec = CIP.cartridges.filter(function (c) {
      return c.key === key;
    })[0];
    if (!rec) {
      document.title = 'Not found · Cartridges';
      main.innerHTML = '<h1>Not found</h1><p><a href="#/">All cartridges</a></p>';
      return;
    }

    var geo = CIP.geometry.buildGeometry(rec);
    var drawing = CIP.drawing.render(geo, { name: rec.name, tab: rec.tab, revised: rec.revised });
    document.title = rec.name + ' · Cartridges';

    var notDrawn = geo.missing.length
      ? '<p class="notes">Not drawn: ' + geo.missing.map(F.escapeHtml).join('; ') + '.</p>'
      : '';

    main.innerHTML =
      '<nav class="toolbar no-print">' +
        '<a href="#/">All cartridges</a>' +
        '<button type="button" id="print-button">Print</button>' +
      '</nav>' +
      '<h1>' + F.escapeHtml(rec.name) + '</h1>' +
      '<dl class="facts">' + factRows(rec) +
        '<div class="wide"><dt>Published water capacity</dt>' + capacityHtml(rec) + '</div>' +
      '</dl>' +
      '<figure class="figure">' + drawing.svg + notDrawn + '</figure>' +
      '<h2>Cartridge</h2>' +
      '<div class="groups">' + F.sections(rec.cartridge).map(groupHtml).join('') + '</div>' +
      '<h2>Chamber</h2>' +
      '<div class="groups">' + F.sections(rec.chamber).map(groupHtml).join('') + '</div>' +
      '<footer class="print-footer">Source: C.I.P. TDCC, revised ' + F.escapeHtml(rec.revised) + '</footer>';

    document.getElementById('print-button').addEventListener('click', function () {
      window.print();
    });
  }

  function route() {
    var match = /^#\/cartridge\/(.+)$/.exec(location.hash);
    if (match) {
      renderDetail(decodeURIComponent(match[1]));
    } else {
      renderList();
    }
  }

  window.addEventListener('hashchange', route);
  route();
})();
