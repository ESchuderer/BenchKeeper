// Inline SVG drawing, 1 user unit = 1 mm. Upper half: outside view.
// Lower half: section with cut walls hatched. Axial dimensions sit in tiers above
// the drawing, diameters and the shoulder angle in tiers below it. Each label is
// placed in the first tier where it clashes with no other label or dimension.
window.CIP = window.CIP || {};
window.CIP.drawing = (function () {
  'use strict';

  var FS = 3.2;        // label font size, mm
  var TIER = 5;        // distance between label tiers, mm
  var GAP = 1.2;       // gap between outline and start of extension line
  var ARROW_LEN = 1.1;
  var ARROW_HALF = 0.4;
  var MAX_TIERS = 30;
  var ARC_STEPS = 12;

  var esc = window.CIP.format.escapeHtml;

  function n(x) {
    return +x.toFixed(3);
  }

  function rect(x0, x1, y0, y1, kind) {
    return {
      x0: Math.min(x0, x1), x1: Math.max(x0, x1),
      y0: Math.min(y0, y1), y1: Math.max(y0, y1),
      kind: kind
    };
  }

  function overlap(a, b) {
    return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
  }

  // Labels clash with everything; dimension lines clash with each other only.
  // Extension lines may cross dimension lines and other extension lines.
  function clash(a, b) {
    if (a.kind === 'label' || b.kind === 'label') return overlap(a, b);
    if (a.kind === 'dim' && b.kind === 'dim') return overlap(a, b);
    return false;
  }

  function fits(group, placed) {
    return group.every(function (g) {
      return placed.every(function (p) {
        return !clash(g, p);
      });
    });
  }

  function labelWidth(text) {
    return text.length * FS * 0.6 + 1;
  }

  // Arrowhead with its tip at (x, y), pointing along (dx, dy).
  function arrow(x, y, dx, dy) {
    var bx = x - dx * ARROW_LEN, by = y - dy * ARROW_LEN;
    var px = -dy * ARROW_HALF, py = dx * ARROW_HALF;
    return '<path class="arrow" d="M' + n(x) + ' ' + n(y) +
      'L' + n(bx + px) + ' ' + n(by + py) +
      'L' + n(bx - px) + ' ' + n(by - py) + 'Z"/>';
  }

  // Outline or section edges. Edges lying on the axis (r = 0) are not stroked.
  function edgePath(points, sign, closed) {
    var d = '';
    var pen = false;
    var count = closed ? points.length : points.length - 1;
    for (var i = 0; i < count; i++) {
      var a = points[i];
      var b = points[(i + 1) % points.length];
      if (a.r === 0 && b.r === 0) {
        pen = false;
        continue;
      }
      if (!pen) {
        d += 'M' + n(a.z) + ' ' + n(sign * a.r);
        pen = true;
      }
      d += 'L' + n(b.z) + ' ' + n(sign * b.r);
    }
    return d;
  }

  function fillPath(points, sign) {
    return 'M' + points.map(function (p) {
      return n(p.z) + ' ' + n(sign * p.r);
    }).join('L') + 'Z';
  }

  // Axial dimensions: horizontal line in a tier above the drawing.
  function placeAxial(dims, maxR, rects, out) {
    dims.forEach(function (d) {
      var width = labelWidth(d.text);
      for (var t = 0; t < MAX_TIERS; t++) {
        var yd = -(maxR + 3.5 + t * TIER);
        var base = yd - 1.2;
        var dim = rect(d.z0, d.z1, yd - 0.12, yd + 0.12, 'dim');
        var ext0 = rect(d.z0 - 0.1, d.z0 + 0.1, yd, -(d.r0 + GAP), 'ext');
        var ext1 = rect(d.z1 - 0.1, d.z1 + 0.1, yd, -(d.r1 + GAP), 'ext');
        var lab = rect(d.z1 + 0.8, d.z1 + 0.8 + width, base - 0.8 * FS, base + 0.25 * FS, 'label');
        var group = [dim, lab, ext0, ext1];
        if (fits(group, rects)) {
          rects.push.apply(rects, group);
          out.push('<path class="dim" d="M' + n(d.z0) + ' ' + n(yd) + 'H' + n(d.z1) + '"/>');
          out.push(arrow(d.z0, yd, -1, 0), arrow(d.z1, yd, 1, 0));
          out.push('<path class="ext" d="M' + n(d.z0) + ' ' + n(-(d.r0 + GAP)) + 'V' + n(yd) + '"/>');
          out.push('<path class="ext" d="M' + n(d.z1) + ' ' + n(-(d.r1 + GAP)) + 'V' + n(yd) + '"/>');
          out.push('<text class="dim-label" x="' + n(lab.x0) + '" y="' + n(base) + '" font-size="' + FS +
            '" text-anchor="start">' + esc(d.text) + '</text>');
          return;
        }
      }
    });
  }

  // Diameters and the shoulder angle: labels in tiers below the drawing, joined
  // to their feature by an extension line. Diameters also get a dimension line.
  // Each label starts just beyond its feature (to the right of the extension line).
  function placeBelow(items, maxR, rects, out) {
    items.forEach(function (d) {
      var width = labelWidth(d.text);
      for (var t = 0; t < MAX_TIERS; t++) {
        var top = maxR + 3.5 + t * TIER;
        var lab = rect(d.z + 0.8, d.z + 0.8 + width, top, top + 1.05 * FS, 'label');
        var ext = rect(d.z - 0.1, d.z + 0.1, d.r + GAP, top, 'ext');
        if (fits([lab, ext], rects)) {
          rects.push(lab, ext);
          if (d.dimension) {
            out.push('<path class="dim" d="M' + n(d.z) + ' ' + n(-d.r) + 'V' + n(d.r) + '"/>');
            out.push(arrow(d.z, -d.r, 0, -1), arrow(d.z, d.r, 0, 1));
          }
          out.push('<path class="ext" d="M' + n(d.z) + ' ' + n(d.r + GAP) + 'V' + n(top) + '"/>');
          out.push('<text class="dim-label" x="' + n(lab.x0) + '" y="' + n(top + 0.8 * FS) + '" font-size="' + FS +
            '" text-anchor="start">' + esc(d.text) + '</text>');
          return;
        }
      }
    });
  }

  // Shoulder angle: arc about the apex, from the axis to the shoulder line (upper half).
  function angleArc(angle, out) {
    var pts = [];
    var dirs = [];
    for (var i = 0; i <= ARC_STEPS; i++) {
      var th = angle.halfAngle * i / ARC_STEPS;
      pts.push(n(angle.apexZ - angle.radius * Math.cos(th)) + ' ' + n(-angle.radius * Math.sin(th)));
      dirs.push([Math.sin(th), -Math.cos(th)]);
    }
    out.push('<path class="dim" d="M' + pts.join('L') + '"/>');
    var first = { x: angle.apexZ - angle.radius, y: 0 };
    var last = { x: angle.apexZ - angle.radius * Math.cos(angle.halfAngle), y: -angle.radius * Math.sin(angle.halfAngle) };
    out.push(arrow(first.x, first.y, 0, 1));
    out.push(arrow(last.x, last.y, dirs[ARC_STEPS][0], dirs[ARC_STEPS][1]));
  }

  // Returns { svg, rects, viewBox } for a geometry from geometry.buildGeometry.
  function render(geo, meta) {
    var rects = [];
    var dims = [];
    var lastZ = 0;
    geo.outline.forEach(function (p) {
      lastZ = Math.max(lastZ, p.z);
    });

    // Items furthest out are placed first, labels start beyond their feature, so
    // the extension lines of later (nearer) items never pass through an earlier label.
    var axial = geo.axial.slice().sort(function (a, b) {
      return b.z1 - a.z1;
    });
    placeAxial(axial, geo.maxR, rects, dims);

    var below = geo.diameters.map(function (d) {
      return { text: d.text, z: d.z, r: d.r, dimension: true };
    });
    if (geo.angle) {
      below.push({ text: geo.angle.text, z: geo.angle.z, r: geo.angle.r, dimension: false });
    }
    below.sort(function (a, b) {
      return b.z - a.z;
    });
    placeBelow(below, geo.maxR, rects, dims);
    if (geo.angle) angleArc(geo.angle, dims);

    var lowest = geo.maxR;
    var x0 = 0;
    var x1 = lastZ;
    var y0 = -geo.maxR;
    rects.forEach(function (r) {
      lowest = Math.max(lowest, r.y1);
      x0 = Math.min(x0, r.x0);
      x1 = Math.max(x1, r.x1);
      y0 = Math.min(y0, r.y0);
    });
    x0 -= 1.5;
    x1 += 1.5;
    // The title block must hold its text, so very short drawings get widened.
    var titleText = Math.max(
      meta.name.length * 4.2 * 0.66,
      ('C.I.P. table ' + meta.tab + ' · revised ' + meta.revised).length * 2.8 * 0.6
    ) + 8;
    x1 = Math.max(x1, x0 + titleText);
    y0 -= 1.5;
    var titleTop = lowest + 3;
    var titleH = 16;
    var y1 = titleTop + titleH + 1.5;

    var hatchId = 'cip-hatch';
    var svg = [];
    svg.push('<svg class="drawing" xmlns="http://www.w3.org/2000/svg" viewBox="' +
      [n(x0), n(y0), n(x1 - x0), n(y1 - y0)].join(' ') +
      '" role="img" aria-label="' + esc(meta.name) + ' drawing">');
    svg.push('<defs><pattern id="' + hatchId + '" width="1.4" height="1.4" patternUnits="userSpaceOnUse" ' +
      'patternTransform="rotate(45)"><path class="hatch" d="M0 0V1.4"/></pattern></defs>');
    svg.push('<path class="axis" d="M' + n(x0 + 0.5) + ' 0H' + n(x1 - 0.5) + '"/>');
    svg.push('<path class="outline" d="' + edgePath(geo.outline, -1, false) + '"/>');
    svg.push('<path class="section-fill" fill="url(#' + hatchId + ')" d="' + fillPath(geo.caseSection, 1) + '"/>');
    svg.push('<path class="section-fill" fill="url(#' + hatchId + ')" d="' + fillPath(geo.bulletSection, 1) + '"/>');
    svg.push('<path class="outline" d="' + edgePath(geo.caseSection, 1, true) + '"/>');
    svg.push('<path class="outline" d="' + edgePath(geo.bulletSection, 1, true) + '"/>');
    svg.push(dims.join(''));

    svg.push('<rect class="titleblock" x="' + n(x0 + 1) + '" y="' + n(titleTop) + '" width="' +
      n(x1 - x0 - 2) + '" height="' + n(titleH) + '"/>');
    svg.push('<text class="title-name" x="' + n(x0 + 3) + '" y="' + n(titleTop + 5.6) + '" font-size="4.2">' +
      esc(meta.name) + '</text>');
    svg.push('<text class="title-line" x="' + n(x0 + 3) + '" y="' + n(titleTop + 9.9) + '" font-size="2.8">' +
      esc('C.I.P. table ' + meta.tab + ' · revised ' + meta.revised) + '</text>');
    svg.push('<text class="title-line" x="' + n(x0 + 3) + '" y="' + n(titleTop + 13.5) + '" font-size="2.8">' +
      esc('Dimensions in mm · Scale 1:1') + '</text>');
    svg.push('</svg>');

    return {
      svg: svg.join(''),
      rects: rects,
      viewBox: [x0, y0, x1 - x0, y1 - y0]
    };
  }

  return {
    render: render
  };
})();
