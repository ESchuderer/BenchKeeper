// Display rules: symbols, units, angles and number text, as published.
window.CIP = window.CIP || {};
window.CIP.format = (function () {
  'use strict';

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  var ANGLE_KEYS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];

  var UNITS = {
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: '—'
  };

  var TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling'
  };

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function has(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
  }

  function symbol(key) {
    return has(SYMBOLS, key) ? SYMBOLS[key] : key;
  }

  function isAngle(key) {
    return ANGLE_KEYS.indexOf(key) !== -1;
  }

  function unit(key) {
    if (isAngle(key)) return '°';
    return has(UNITS, key) ? UNITS[key] : 'mm';
  }

  function sectionTitle(key) {
    return has(TITLES, key) ? TITLES[key] : key;
  }

  function padDigits(n) {
    return Number.isInteger(n) ? String(n).padStart(2, '0') : String(n);
  }

  // A plain number is a count of degrees; an object is degrees, minutes, seconds.
  function formatAngle(angle) {
    if (typeof angle === 'number') return angle + '°';
    return angle.degrees + '°' + padDigits(angle.minutes) + "'" + padDigits(angle.seconds) + '"';
  }

  function formatValue(key, value, tol) {
    if (isAngle(key)) return formatAngle(value);
    var text = String(value);
    return tol === undefined ? text : text + ' ' + String(tol);
  }

  // Text for a drawing label, e.g. "L3 51.18" or "L1 39.62 -0.2".
  function label(key, value, tol) {
    return symbol(key) + ' ' + formatValue(key, value, tol);
  }

  // Rows of one record section. A `<X>Tol` field is merged into the row of X.
  function rows(section) {
    return Object.keys(section)
      .filter(function (key) {
        return !(key.slice(-3) === 'Tol' && has(section, key.slice(0, -3)));
      })
      .map(function (key) {
        var tol = has(section, key + 'Tol') ? section[key + 'Tol'] : undefined;
        return {
          key: key,
          symbol: symbol(key),
          value: formatValue(key, section[key], tol),
          unit: unit(key)
        };
      });
  }

  // Named groups of a record part (cartridge or chamber), empty groups dropped.
  function sections(part) {
    return Object.keys(part)
      .filter(function (key) {
        return part[key] !== null && typeof part[key] === 'object' && !Array.isArray(part[key]);
      })
      .map(function (key) {
        return { key: key, title: sectionTitle(key), rows: rows(part[key]) };
      })
      .filter(function (group) {
        return group.rows.length > 0;
      });
  }

  return {
    symbol: symbol,
    unit: unit,
    isAngle: isAngle,
    sectionTitle: sectionTitle,
    formatAngle: formatAngle,
    formatValue: formatValue,
    label: label,
    escapeHtml: escapeHtml,
    rows: rows,
    sections: sections
  };
})();
