// Cartridge geometry in mm. Points are {z, r}: z runs from the head face (z = 0)
// towards the mouth along the axis, r is the radius. Both halves are built from
// the same profile; the drawing mirrors them about the axis.
window.CIP = window.CIP || {};
window.CIP.geometry = (function () {
  'use strict';

  var F = window.CIP.format;
  var ARC_STEPS = 8;
  var NOSE_STEPS = 16;

  function rad(degrees) {
    return degrees * Math.PI / 180;
  }

  function deg(angle) {
    return typeof angle === 'number' ? angle : angle.degrees + angle.minutes / 60 + angle.seconds / 3600;
  }

  function half(value) {
    return value === undefined ? undefined : value / 2;
  }

  function clamp(x, lo, hi) {
    return Math.min(hi, Math.max(lo, x));
  }

  function has(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
  }

  function rimTypeOf(family, R1, P1) {
    if (family === 'belted' || family === 'rimfire') return family;
    var ratio = R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Fraction of the seating depth below the mouth, in units of G1.
  function seatFactor(shape, category) {
    if (shape === 'pointy') return 1.0;
    if (shape === 'semi_wadcutter') return 0.6;
    if (shape === 'rounded' || shape === 'flat') return category === 'pistol' ? 0.4 : 0.8;
    return undefined;
  }

  // Where the cylinder ends, as a fraction of the bullet length Lb.
  function cylinderFactor(shape, category) {
    var pistol = category === 'pistol';
    if (shape === 'pointy') return 0.40;
    if (shape === 'rounded') return pistol ? 0.65 : 0.55;
    if (shape === 'flat') return pistol ? 0.70 : 0.60;
    if (shape === 'semi_wadcutter') return 0.78;
    return undefined;
  }

  function dedupe(points) {
    var out = [];
    points.forEach(function (p) {
      var last = out[out.length - 1];
      if (!last || Math.abs(last.z - p.z) > 1e-9 || Math.abs(last.r - p.r) > 1e-9) {
        out.push({ z: p.z, r: p.r });
      }
    });
    return out;
  }

  // Rounds the corner p between prev and next with the given radius.
  // Returns the sampled arc from the first to the last tangent point, or null
  // when the corner is straight or degenerate.
  function fillet(prev, p, next, radius) {
    var ax = prev.z - p.z, ay = prev.r - p.r;
    var bx = next.z - p.z, by = next.r - p.r;
    var la = Math.hypot(ax, ay), lb = Math.hypot(bx, by);
    var theta = Math.acos(clamp((ax * bx + ay * by) / (la * lb), -1, 1));
    if (!(radius > 0) || theta < 1e-6 || Math.PI - theta < 1e-6) return null;

    var halfAngle = theta / 2;
    var t = Math.min(radius / Math.tan(halfAngle), 0.5 * Math.min(la, lb));
    var rr = t * Math.tan(halfAngle);
    var ua = [ax / la, ay / la], ub = [bx / lb, by / lb];
    var bis = [ua[0] + ub[0], ua[1] + ub[1]];
    var bl = Math.hypot(bis[0], bis[1]);
    var dC = rr / Math.sin(halfAngle);
    var C = { z: p.z + bis[0] / bl * dC, r: p.r + bis[1] / bl * dC };
    var A = { z: p.z + ua[0] * t, r: p.r + ua[1] * t };
    var B = { z: p.z + ub[0] * t, r: p.r + ub[1] * t };
    var a0 = Math.atan2(A.r - C.r, A.z - C.z);
    var sweep = Math.atan2(B.r - C.r, B.z - C.z) - a0;
    if (sweep > Math.PI) sweep -= 2 * Math.PI;
    if (sweep < -Math.PI) sweep += 2 * Math.PI;

    var arc = [];
    for (var i = 0; i <= ARC_STEPS; i++) {
      var a = a0 + sweep * i / ARC_STEPS;
      arc.push({ z: C.z + rr * Math.cos(a), r: C.r + rr * Math.sin(a) });
    }
    return arc;
  }

  // Items may carry `fr`, a fillet radius for their corner.
  function expandCorners(items) {
    var out = [];
    items.forEach(function (p, i) {
      var arc = p.fr && i > 0 && i < items.length - 1 ? fillet(items[i - 1], p, items[i + 1], p.fr) : null;
      if (arc) {
        out.push.apply(out, arc);
      } else {
        out.push({ z: p.z, r: p.r });
      }
    });
    return dedupe(out);
  }

  // Radius of a profile (z non-decreasing) at a given z.
  function radiusAt(points, z) {
    for (var i = 1; i < points.length; i++) {
      var a = points[i - 1], b = points[i];
      if (z >= a.z && z <= b.z && b.z > a.z) {
        return a.r + (b.r - a.r) * (z - a.z) / (b.z - a.z);
      }
    }
    return undefined;
  }

  // Nose from z = zs to the tip at z = L6. Returns the points and the meplat radius mr.
  function nose(shape, Rx, zs, L6) {
    var G = 2 * Rx;
    var n = L6 - zs;
    var points = [];
    var i;
    if (shape === 'pointy') {
      var mr = Math.max(0.08 * G, 1.27) / 2;
      var d = Rx - mr;
      var rho = (d * d + n * n) / (2 * d);
      var rc = Rx - rho;
      var phiEnd = Math.asin(clamp(n / rho, -1, 1));
      for (i = 0; i <= NOSE_STEPS; i++) {
        var phi = phiEnd * i / NOSE_STEPS;
        points.push({ z: zs + rho * Math.sin(phi), r: rc + rho * Math.cos(phi) });
      }
      return { points: points, mr: mr };
    }
    if (shape === 'rounded') {
      var mrR = 0.15 * G / 2;
      var a = Rx - mrR;
      for (i = 0; i <= NOSE_STEPS; i++) {
        var psi = Math.PI / 2 * i / NOSE_STEPS;
        points.push({ z: zs + n * Math.sin(psi), r: mrR + a * Math.cos(psi) });
      }
      return { points: points, mr: mrR };
    }
    var mrCone = (shape === 'flat' ? 0.55 : 0.6) * G / 2;
    return { points: [{ z: zs, r: Rx }, { z: L6, r: mrCone }], mr: mrCone };
  }

  // Bullet outline from the mouth to the tip and the section of the seated bullet.
  function bulletGeometry(o) {
    var Rx = o.Gd / 2;
    var L3 = o.L3, L6 = o.L6;
    var s = seatFactor(o.shape, o.category) * o.Gd;
    var zb = L3 - s;
    var Lb = L6 - zb;
    var zc = Math.max(zb + cylinderFactor(o.shape, o.category) * Lb, L3);
    var nz = nose(o.shape, Rx, zc, L6);
    var exposed = dedupe([{ z: L3, r: Rx }, { z: zc, r: Rx }].concat(nz.points, [{ z: L6, r: 0 }]));
    var seated = [{ z: zb, r: 0 }, { z: zb, r: o.seatR }, { z: L3, r: o.seatR }];
    return {
      exposed: exposed,
      section: dedupe(seated.concat(exposed)),
      zc: zc,
      mr: nz.mr
    };
  }

  var PRIMER_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var PRIMER_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  function buildGeometry(rec) {
    var c = rec.cartridge;
    var ann = rec.annotations || {};
    var ch = c.caseHead;
    var col = c.collar || {};
    var jc = c.junctionCone || {};
    var Ln = c.lengths || {};
    var pc = c.powderChamber || {};
    var pr = c.projectile || {};
    var missing = [];

    var shape = ann.defaultBulletShape;
    var category = ann.category;
    if (seatFactor(shape, category) === undefined) {
      missing.push('defaultBulletShape "' + shape + '" unknown: bullet drawn as pointy');
      shape = 'pointy';
    }

    var rimType = rimTypeOf(rec.family, ch.R1, pc.P1);
    var Rt = ch.R;
    var R1h = ch.R1 / 2;
    var P1h = pc.P1 / 2;
    var P2h = half(pc.P2);
    var H1h = half(col.H1);
    var H2h = col.H2 / 2;
    var G1 = pr.G1;
    var L1 = Ln.L1, L2 = Ln.L2, L3 = Ln.L3, L6 = Ln.L6;
    var E = ch.E, E1 = ch.E1, eMin = ch.eMin;

    var heeled = col.H2 - G1 <= 0.015;
    var tn = Math.max(0, (col.H2 - G1) / 2);
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1h);

    var bottle = jc.alpha !== undefined && L1 !== undefined && L2 !== undefined;
    if (bottle && (pc.P2 === undefined || col.H1 === undefined)) {
      missing.push('powderChamber.P2 or collar.H1 missing: drawn as a straight case');
      bottle = false;
    }
    if (bottle && jc.r1Min === undefined) missing.push('junctionCone.r1Min missing: body-side corner not rounded');
    if (bottle && jc.r2 === undefined) missing.push('junctionCone.r2 missing: neck-side corner not rounded');

    var pocket = null;
    if (has(PRIMER_DIAMETER, ann.primerType)) {
      pocket = { r: PRIMER_DIAMETER[ann.primerType] / 2, depth: PRIMER_DEPTH[ann.primerType] };
    }

    var groove = E !== undefined && E1 !== undefined;
    if (groove && eMin === undefined) missing.push('caseHead.eMin missing: groove floor not drawn');
    var eMinV = eMin || 0;
    var belt = rimType === 'belted' && ch.R3 !== undefined && ch.delta !== undefined;
    if (rimType === 'belted' && !belt) missing.push('caseHead.R3 or caseHead.delta missing: belt not drawn');

    // Outer profile, head face to mouth.
    var items = [{ z: 0, r: 0 }];
    if (rimType === 'rimfire') {
      var rho = Math.min(Rt / 2, R1h - P1h);
      var rc = R1h - rho;
      for (var i = 0; i <= ARC_STEPS; i++) {
        var phi = -Math.PI / 2 + Math.PI * i / ARC_STEPS;
        items.push({ z: Rt / 2 + rho * Math.sin(phi), r: rc + rho * Math.cos(phi) });
      }
      items.push({ z: Rt, r: rc });
    } else {
      var chamfer = ch.beta !== undefined && ch.f !== undefined && deg(ch.beta) < 90;
      if (chamfer) {
        var cut = Math.min(ch.f * Math.tan(rad(deg(ch.beta))), R1h / 2);
        items.push({ z: 0, r: R1h - cut }, { z: ch.f, r: R1h });
      } else {
        items.push({ z: 0, r: R1h });
      }
      items.push({ z: Rt, r: R1h });
    }

    var bodyStart;
    var rampEnd;
    if (groove) {
      var E1h = E1 / 2;
      items.push({ z: Rt, r: E1h }, { z: Rt + eMinV, r: E1h });
      if (belt) {
        var R3h = ch.R3 / 2;
        rampEnd = Rt + eMinV + (R3h - E1h) / Math.tan(rad(deg(ch.delta)));
        items.push({ z: rampEnd, r: R3h }, { z: E, r: R3h });
      }
      items.push({ z: E, r: P1h });
      bodyStart = E;
    } else {
      items.push({ z: Rt, r: P1h });
      bodyStart = Rt;
    }

    if (bottle) {
      items.push({ z: L1, r: P2h, fr: jc.r1Min }, { z: L2, r: H1h, fr: jc.r2 }, { z: L3, r: H2h });
    } else {
      items.push({ z: L3, r: H2h });
    }
    var caseOuter = expandCorners(items);

    // Bullet: exposed outline and seated section.
    var Gd = heeled ? col.H2 : G1;
    var seatR = heeled ? col.H2 / 2 - tb : G1 / 2;
    var bul = bulletGeometry({ Gd: Gd, seatR: seatR, shape: shape, category: category, L3: L3, L6: L6 });

    // Section: solid head to w, walls tb (body) and tn (neck) inside the outer profile.
    var w = Math.max(
      2.5,
      0.25 * P1h,
      pocket ? pocket.depth + 1.5 : 0,
      groove ? (belt ? rampEnd + tb : E + tb) : 0
    );

    function thickness(z) {
      if (bottle) {
        if (z <= L1) return tb;
        if (z >= L2) return tn;
        return tb + (tn - tb) * (z - L1) / (L2 - L1);
      }
      return tb + (tn - tb) * clamp((z - bodyStart) / (L3 - bodyStart), 0, 1);
    }

    var inner = [{ z: w, r: radiusAt(caseOuter, w) - thickness(w) }];
    caseOuter.forEach(function (p) {
      if (p.z > w) inner.push({ z: p.z, r: p.r - thickness(p.z) });
    });

    var section = [];
    section.push(pocket ? { z: pocket.depth, r: 0 } : { z: 0, r: 0 });
    section.push({ z: w, r: 0 });
    section = section.concat(inner);
    section = section.concat(caseOuter.slice().reverse().filter(function (p) {
      if (p.z === 0 && p.r === 0) return false;
      if (pocket && p.z === 0 && p.r < pocket.r) return false;
      return true;
    }));
    if (pocket) section.push({ z: 0, r: pocket.r }, { z: pocket.depth, r: pocket.r });

    // Dimensions for the drawing.
    var axial = [];
    var diameters = [];
    if (Rt !== undefined) {
      axial.push({ text: F.label('R', ch.R, ch.RTol), z0: 0, z1: Rt, r0: R1h, r1: R1h });
    }
    if (bottle) {
      axial.push({ text: F.label('L2', L2, Ln.L2Tol), z0: 0, z1: L2, r0: R1h, r1: H1h });
      axial.push({ text: F.label('L1', L1, Ln.L1Tol), z0: 0, z1: L1, r0: R1h, r1: P2h });
    }
    axial.push({ text: F.label('L3', L3, Ln.L3Tol), z0: 0, z1: L3, r0: R1h, r1: H2h });
    axial.push({ text: F.label('L6', L6, Ln.L6Tol), z0: 0, z1: L6, r0: R1h, r1: bul.mr });

    diameters.push({ text: F.label('R1', ch.R1), z: Rt / 2, r: R1h });
    diameters.push({ text: F.label('P1', pc.P1), z: (bodyStart + (bottle ? L1 : L3)) / 2, r: P1h });
    if (bottle) {
      diameters.push({ text: F.label('P2', pc.P2, pc.P2Tol), z: L1, r: P2h });
      diameters.push({ text: F.label('H1', col.H1), z: L2, r: H1h });
    }
    diameters.push({ text: F.label('H2', col.H2), z: L3, r: H2h });
    diameters.push({ text: F.label('G1', G1), z: (L3 + bul.zc) / 2, r: Gd / 2 });
    if (groove) {
      diameters.push({ text: F.label('E1', E1), z: Rt + eMinV / 2, r: E1 / 2 });
    }

    var angle = null;
    if (bottle) {
      angle = {
        text: F.label('alpha', jc.alpha),
        z: (L1 + L2) / 2,
        r: (P2h + H1h) / 2,
        apexZ: L1 + P2h * (L2 - L1) / (P2h - H1h),
        halfAngle: rad(deg(jc.alpha)) / 2,
        radius: 6
      };
    }

    var outline = dedupe(caseOuter.concat(bul.exposed));
    var maxR = Math.max(R1h, H2h, P1h, Gd / 2, ch.R3 ? ch.R3 / 2 : 0);

    return {
      name: rec.name,
      rimType: rimType,
      bottleneck: bottle,
      heeled: heeled,
      tb: tb,
      tn: tn,
      w: w,
      pocket: pocket,
      missing: missing,
      outline: outline,
      caseSection: section,
      bulletSection: bul.section,
      axial: axial,
      diameters: diameters,
      angle: angle,
      maxR: maxR
    };
  }

  return {
    buildGeometry: buildGeometry,
    rimTypeOf: rimTypeOf,
    seatFactor: seatFactor,
    cylinderFactor: cylinderFactor,
    fillet: fillet,
    radiusAt: radiusAt,
    bulletGeometry: bulletGeometry,
    nose: nose
  };
})();
