'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCip } = require('./load.js');

const CIP = loadCip();
const F = CIP.format;
const G = CIP.geometry;
const D = CIP.drawing;
const records = CIP.cartridges;
const byKey = (key) => records.find((r) => r.key === key);
// Values built inside the vm sandbox have another realm; compare them as plain JSON.
const plain = (value) => JSON.parse(JSON.stringify(value));

test('data: 25 unique cartridge records', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
  assert.equal(new Set(records.map((r) => r.name)).size, 25);
});

test('format: symbols follow the brief', () => {
  assert.equal(F.symbol('eMin'), 'e min');
  assert.equal(F.symbol('r1Min'), 'r1 min');
  assert.equal(F.symbol('r1Max'), 'r1 max');
  assert.equal(F.symbol('alpha'), 'α');
  assert.equal(F.symbol('alpha1'), 'α1');
  assert.equal(F.symbol('beta'), 'β');
  assert.equal(F.symbol('delta'), 'δ');
  assert.equal(F.symbol('deltaL'), 'delta L');
  assert.equal(F.symbol('L3PlusG'), 'L3 + G');
  assert.equal(F.symbol('L3'), 'L3');
});

test('format: units', () => {
  assert.equal(F.unit('L3'), 'mm');
  assert.equal(F.unit('Pmax'), 'bar');
  assert.equal(F.unit('EE'), 'J');
  assert.equal(F.unit('M'), 'g');
  assert.equal(F.unit('Q'), 'mm²');
  assert.equal(F.unit('N'), '—');
  assert.equal(F.unit('i'), '°');
});

test('format: angles as degrees or degrees-minutes-seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(F.formatAngle({ degrees: 0, minutes: 17, seconds: 11 }), '0°17\'11"');
});

test('format: values as published, tolerance next to its value', () => {
  assert.equal(F.formatValue('L1', 39.62, -0.2), '39.62 -0.2');
  assert.equal(F.formatValue('Pmax', 4300.0), '4300');
  assert.equal(F.label('L3', 51.18), 'L3 51.18');
  assert.equal(F.label('L1', 39.62, -0.2), 'L1 39.62 -0.2');
});

test('format: tolerance fields are merged, not shown as rows', () => {
  const rows = F.rows({ E: 5.59, ETol: -0.2, R: 1.27 });
  assert.deepEqual(plain(rows.map((r) => r.symbol)), ['E', 'R']);
  assert.equal(rows[0].value, '5.59 -0.2');
  assert.equal(rows[1].value, '1.27');
});

test('format: section groups for the 223 Rem. chamber', () => {
  const groups = F.sections(byKey('223_rem').chamber);
  const titles = groups.map((g) => g.title);
  assert.ok(titles.includes('Rifling'));
  const rifling = groups.find((g) => g.title === 'Rifling').rows;
  assert.equal(rifling.find((r) => r.symbol === 'i').value, '3°10\'36"');
});

test('geometry: rim types from family and R1/P1', () => {
  assert.equal(G.rimTypeOf('rimless', 9.96, 9.93), 'rimless');
  assert.equal(G.rimTypeOf('pistol', 13.32, 11.89), 'rimmed');
  assert.equal(G.rimTypeOf('pistol', 11.0, 11.5), 'rebated');
  assert.equal(G.rimTypeOf('belted', 13.51, 13.03), 'belted');
  assert.equal(G.rimTypeOf('rimfire', 7.06, 5.74), 'rimfire');
});

test('geometry: bottleneck, straight and heeled cases', () => {
  assert.equal(G.buildGeometry(byKey('223_rem')).bottleneck, true);
  assert.equal(G.buildGeometry(byKey('9_mm_luger')).bottleneck, false);
  assert.equal(G.buildGeometry(byKey('22_long_rifle')).heeled, true);
  assert.equal(G.buildGeometry(byKey('9_mm_luger')).heeled, false);
});

test('geometry: primer pocket and wall thickness', () => {
  const g = G.buildGeometry(byKey('223_rem'));
  assert.deepEqual(plain(g.pocket), { r: 4.45 / 2, depth: 3.04 });
  assert.equal(g.tb, 0.6);
  // w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb) = max(2.5, 2.395, 4.54, 3.73)
  assert.ok(Math.abs(g.w - 4.54) < 1e-9);
  assert.equal(G.buildGeometry(byKey('22_long_rifle')).pocket, null);
  assert.equal(G.buildGeometry(byKey('45_auto')).pocket.depth, 3.04);
  assert.equal(G.buildGeometry(byKey('7_x_64')).pocket.r, 5.33 / 2);
});

test('geometry: missing values are reported, not invented', () => {
  const lapua = G.buildGeometry(byKey('338_lapua_mag'));
  assert.ok(lapua.missing.some((m) => m.startsWith('junctionCone.r1Min')));
  const hmr = G.buildGeometry(byKey('17_hmr'));
  assert.ok(hmr.missing.some((m) => m.startsWith('junctionCone.r1Min')));
  assert.ok(hmr.missing.some((m) => m.startsWith('junctionCone.r2')));
  assert.deepEqual(plain(G.buildGeometry(byKey('223_rem')).missing), []);
});

test('geometry: profile runs from the head face to the mouth and the tip', () => {
  for (const rec of records) {
    const g = G.buildGeometry(rec);
    const outline = g.outline;
    for (let i = 1; i < outline.length; i++) {
      assert.ok(outline[i].z >= outline[i - 1].z - 1e-9, rec.key + ' z decreases at ' + i);
    }
    assert.equal(outline[0].z, 0, rec.key);
    assert.equal(outline[0].r, 0, rec.key);
    const tip = outline[outline.length - 1];
    assert.ok(Math.abs(tip.z - rec.cartridge.lengths.L6) < 1e-9, rec.key + ' tip not at L6');
    assert.equal(tip.r, 0, rec.key);
  }
});

test('geometry: bullet mouth and seating for a pointy bullet', () => {
  // 223 Rem.: s = 1.0·G1, so the base sits 5.70 mm below the mouth at L3 = 44.70.
  const bullet = G.bulletGeometry({ Gd: 5.7, seatR: 2.85, shape: 'pointy', category: 'rifle', L3: 44.7, L6: 57.4 });
  assert.ok(Math.abs(bullet.zc - (39.0 + 0.4 * 18.4)) < 1e-9);
  const meplat = G.nose('pointy', 2.85, bullet.zc, 57.4).mr;
  assert.ok(Math.abs(meplat - 1.27 / 2) < 1e-9);
});

test('geometry: fillet is tangent-length limited and sampled', () => {
  const arc = G.fillet({ z: 0, r: 5 }, { z: 2, r: 0 }, { z: 4, r: 5 }, 1);
  assert.ok(arc && arc.length > 2);
  assert.ok(Math.abs(arc[0].z - 2) > 0 && Math.abs(arc[arc.length - 1].z - 2) > 0);
  assert.equal(G.fillet({ z: 0, r: 5 }, { z: 2, r: 5 }, { z: 4, r: 5 }, 1), null);
});

test('drawing: every record renders with all its dimension labels', () => {
  for (const rec of records) {
    const g = G.buildGeometry(rec);
    const out = D.render(g, { name: rec.name, tab: rec.tab, revised: rec.revised });
    const labels = out.svg.match(/class="dim-label"/g) || [];
    const expected = g.axial.length + g.diameters.length + (g.angle ? 1 : 0);
    assert.equal(labels.length, expected, rec.key + ' labels');
    assert.ok(out.svg.includes('aria-label="' + F.escapeHtml(rec.name) + ' drawing"'), rec.key + ' accessible name');
  }
});

test('drawing: labels do not overlap each other, dimensions or the outline', () => {
  for (const rec of records) {
    const g = G.buildGeometry(rec);
    const { rects } = D.render(g, { name: rec.name, tab: rec.tab, revised: rec.revised });
    const labels = rects.filter((r) => r.kind === 'label');
    const dims = rects.filter((r) => r.kind !== 'label');
    const overlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
    labels.forEach((a, i) => {
      labels.slice(i + 1).forEach((b) => assert.ok(!overlap(a, b), rec.key + ' labels overlap'));
      dims.forEach((d) => assert.ok(!overlap(a, d), rec.key + ' label crosses a dimension line'));
      // Labels stay outside the outline band (|y| <= maxR), above or below it.
      assert.ok(a.y1 < -g.maxR || a.y0 > g.maxR, rec.key + ' label on the outline');
    });
  }
});

test('drawing: viewBox holds the title block text', () => {
  for (const rec of records) {
    const g = G.buildGeometry(rec);
    const { viewBox } = D.render(g, { name: rec.name, tab: rec.tab, revised: rec.revised });
    const [x0, , w] = viewBox;
    assert.ok(w >= rec.name.length * 4.2 * 0.6, rec.key + ' viewBox too narrow for the title');
    assert.ok(x0 <= 0, rec.key + ' head face outside the viewBox');
  }
});
