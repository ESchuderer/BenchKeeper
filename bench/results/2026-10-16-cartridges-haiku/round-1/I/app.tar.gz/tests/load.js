'use strict';
// Loads the browser scripts into a sandbox so the tests exercise the same code the page runs.
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');

function loadCip() {
  const sandbox = {};
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  for (const file of ['data.js', 'format.js', 'geometry.js', 'drawing.js']) {
    const source = fs.readFileSync(path.join(__dirname, '..', 'js', file), 'utf8');
    vm.runInContext(source, sandbox, { filename: file });
  }
  return sandbox.CIP;
}

module.exports = { loadCip };
