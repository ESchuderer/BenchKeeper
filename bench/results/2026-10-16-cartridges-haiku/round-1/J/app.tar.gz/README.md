# Cartridge reference

A static reference for 25 C.I.P. cartridges: values, section tables and a drawing computed from each record.
Plain HTML, CSS and JavaScript; no framework, no build step, no network requests.

## Open it

- Double-click `index.html` (works from `file://` in Chromium), or
- serve the folder with any static file server.

Each cartridge has its own address, for example `index.html#/cartridge/308_win`.

## Files

- `index.html`, `styles/app.css`: page and styles (light and dark, print rules).
- `js/data.js`: the 25 records, generated from `data/cartridges.jsonl`.
- `js/format.js`, `js/catalogue.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js`: formatting, search and routing, geometry, drawing and the app shell.
- `openspec/changes/cartridge-reference-app/`: the specification, design and task list.

## Development

    npm install        # dev dependencies only (test runner support)
    npm test           # unit and DOM tests (Node 22)
    npm run build:data # regenerate js/data.js after changing data/cartridges.jsonl

The app itself needs none of these.
