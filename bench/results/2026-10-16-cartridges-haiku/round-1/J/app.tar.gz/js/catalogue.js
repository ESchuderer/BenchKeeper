/* Start-page logic: search normalisation, family filter, count text and hash routes.
   Pure functions, no DOM. */
var CartridgeCatalogue = (function () {
  'use strict';

  var FAMILY_OPTIONS = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var DETAIL_PREFIX = '#/cartridge/';

  // Ignore case, whitespace, hyphens, dots and commas so that "7,62 x 51" finds "7.62x51".
  function normalise(text) {
    return String(text).toLowerCase().replace(/[\s\-.,]/g, '');
  }

  function matchesQuery(record, normalisedQuery) {
    var candidates = [record.name].concat(record.alternativeNames || []);
    return candidates.some(function (candidate) {
      return normalise(candidate).indexOf(normalisedQuery) !== -1;
    });
  }

  function filterRecords(records, options) {
    var query = normalise(options.query || '');
    var family = options.family || 'All';
    return records.filter(function (record) {
      if (family !== 'All' && record.family !== family) return false;
      return query === '' || matchesQuery(record, query);
    });
  }

  function countLabel(n) {
    return n === 1 ? '1 cartridge' : n + ' cartridges';
  }

  function routeFor(key) {
    return DETAIL_PREFIX + encodeURIComponent(key);
  }

  function parseRoute(hash) {
    var text = String(hash || '');
    if (text.indexOf(DETAIL_PREFIX) === 0) {
      return { view: 'detail', key: decodeURIComponent(text.slice(DETAIL_PREFIX.length)) };
    }
    return { view: 'list' };
  }

  function findRecord(records, key) {
    for (var i = 0; i < records.length; i++) {
      if (records[i].key === key) return records[i];
    }
    return undefined;
  }

  return {
    FAMILY_OPTIONS: FAMILY_OPTIONS,
    normalise: normalise,
    filterRecords: filterRecords,
    countLabel: countLabel,
    routeFor: routeFor,
    parseRoute: parseRoute,
    findRecord: findRecord
  };
})();

if (typeof module !== 'undefined') module.exports = CartridgeCatalogue;
