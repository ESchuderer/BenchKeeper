/* Cartridge drawing: an inline SVG in millimetres (1 unit = 1 mm), axis horizontal, head on the left.
   The upper half is the outside view, the lower half a section with hatched cut walls.
   Dimensions and labels are placed from candidate positions and checked against every line and outline. */
var CartridgeDrawing = (function () {
  'use strict';

  var G = typeof CartridgeGeometry !== 'undefined' ? CartridgeGeometry : require('./geometry.js');
  var F = typeof CartridgeFormat !== 'undefined' ? CartridgeFormat : require('./format.js');

  var FS = 3.2;            // label font size, mm
  var ARROW_LEN = 1.6;
  var ARROW_HALF = 0.5;
  var EXT_GAP = 0.8;       // extension lines overshoot the dimension line by this much
  var ROW_GAP = 3.0;       // outline to first dimension row
  var ROW_STEP = FS + 1.6;
  var LOWER_BASE = 3.4;    // lower labels start this far below the widest radius
  var LEVEL_STEP = FS + 1.2;
  var PAD = 0.3;

  function escapeXml(text) {
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function num(value) {
    return Number(value.toFixed(3)).toString();
  }

  function pathOf(points, close) {
    var parts = points.map(function (p, i) {
      return (i === 0 ? 'M' : 'L') + num(p[0]) + ' ' + num(p[1]);
    });
    return parts.join(' ') + (close ? ' Z' : '');
  }

  function textWidth(text) {
    return text.length * FS * 0.6 + 0.6;
  }

  function boxFor(text, x, y, anchor) {
    var w = textWidth(text);
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0: x0, x1: x0 + w, y0: y - 0.75 * FS, y1: y + 0.2 * FS };
  }

  function boxesOverlap(a, b) {
    return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
  }

  function segmentHits(seg, box) {
    var x1 = seg[0], y1 = seg[1], x2 = seg[2], y2 = seg[3];
    var steps = Math.max(2, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 0.2));
    for (var i = 0; i <= steps; i++) {
      var x = x1 + ((x2 - x1) * i) / steps;
      var y = y1 + ((y2 - y1) * i) / steps;
      if (x > box.x0 - PAD && x < box.x1 + PAD && y > box.y0 - PAD && y < box.y1 + PAD) return true;
    }
    return false;
  }

  // Published value with its tolerance, e.g. "36.52 -0.2"; tolerance key is <key>Tol.
  function valueText(group, key) {
    var tol = group[key + 'Tol'];
    return F.formatValue(group[key], tol);
  }

  function build(record) {
    var a = G.analyse(record);
    if (!a.drawable) {
      return { drawable: false, name: record.name, notes: a.notes.slice(), svg: undefined };
    }
    var cp = record.cartridge;
    var has = function (value) { return value !== undefined && value !== null; };
    var v = a.values;
    var b = a.bullet;
    var outer = a.outer;
    var notes = a.notes.slice();
    var R1h = v.R1 / 2;
    var H2h = v.H2 / 2;
    var P1h = v.P1 / 2;
    var Rmax = Math.max.apply(null, outer.map(function (p) { return p[1]; }).concat([b.exposedRadius]));

    // ---- geometry in SVG coordinates (x = z, y = -r above the axis, +r below) ---------
    var upper = outer.map(function (p) { return [p[0], -p[1]]; })
      .concat(b.exposed.map(function (p) { return [p[0], -p[1]]; }))
      .concat([[v.L6, 0]]);
    var walls = a.sectionPolygon;
    var wallsMirror = walls.map(function (p) { return [p[0], -p[1]]; });
    var bulletLower = b.section.slice(0, -1); // open at the axis
    var bulletMirror = bulletLower.map(function (p) { return [p[0], -p[1]]; });

    var obstacles = [];
    var dimLines = [];
    var extLines = [];
    var arrows = [];
    var dims = [];
    var pending = [];   // labels to place: {symbol, text, candidates, level}
    var lowerLabels = [];

    function addSegments(points) {
      for (var i = 1; i < points.length; i++) {
        obstacles.push([points[i - 1][0], points[i - 1][1], points[i][0], points[i][1]]);
      }
    }
    addSegments(upper);
    addSegments(walls);
    addSegments(wallsMirror);
    addSegments(bulletLower);
    addSegments(bulletMirror);

    function dimLine(x1, y1, x2, y2) {
      dimLines.push([x1, y1, x2, y2]);
      obstacles.push([x1, y1, x2, y2]);
    }
    function extLine(x1, y1, x2, y2) {
      extLines.push([x1, y1, x2, y2]);
      obstacles.push([x1, y1, x2, y2]);
    }
    // Arrow with its tip at (tx, ty); the body extends from the tip in direction (dx, dy).
    function arrow(tx, ty, dx, dy) {
      var px = -dy;
      var py = dx;
      var bx = tx + dx * ARROW_LEN;
      var by = ty + dy * ARROW_LEN;
      arrows.push('M' + num(tx) + ' ' + num(ty) +
        ' L' + num(bx + px * ARROW_HALF) + ' ' + num(by + py * ARROW_HALF) +
        ' L' + num(bx - px * ARROW_HALF) + ' ' + num(by - py * ARROW_HALF) + ' Z');
    }

    // ---- length dimensions in rows above the outline -------------------------------
    var rowY = function (k) { return -(Rmax + ROW_GAP + k * ROW_STEP); };
    var headTop = rowY(4) - EXT_GAP;
    extLine(0, -R1h - EXT_GAP, 0, headTop);

    function lengthDim(symbol, k, xEnd, features) {
      var y = rowY(k);
      dimLine(0, y, xEnd, y);
      arrow(0, y, 1, 0);
      arrow(xEnd, y, -1, 0);
      features.forEach(function (f) { extLine(f[0], f[1] - EXT_GAP, f[0], y - EXT_GAP); });
      dims.push({ symbol: symbol, kind: 'length', from: [0, y], to: [xEnd, y], arrows: 2, extensions: features.length + 1 });
      pending.push({
        symbol: symbol,
        text: null,
        candidates: [
          { x: xEnd / 2, y: y - 1.0, anchor: 'middle' },
          { x: 0.8, y: y - 1.0, anchor: 'start' },
          { x: -0.8, y: y - 1.0, anchor: 'end' },
          { x: xEnd - 0.8, y: y - 1.0, anchor: 'end' }
        ],
        value: valueText(cp.lengths, symbol)
      });
    }

    var shoulder = a.shoulder;
    var arcPolyline = null;
    var P2h = shoulder ? shoulder.start[1] : P1h;
    var H1h = shoulder ? shoulder.end[1] : H2h;
    lengthDim('R', 0, v.R, [[0, -R1h], [v.R, -R1h]]);
    pending[pending.length - 1].value = valueText(cp.caseHead, 'R');
    if (shoulder) {
      lengthDim('L1', 1, v.L1, [[v.L1, -P2h]]);
      lengthDim('L2', 2, v.L2, [[v.L2, -H1h]]);
    }
    lengthDim('L3', 3, v.L3, [[v.L3, -H2h]]);
    lengthDim('L6', 4, v.L6, [[v.L6, -b.m / 2]]);

    // ---- diameter dimensions: a dimension line across the part, labelled below it --
    function diameterDim(symbol, xFeature, radius, xDim, group, key) {
      dimLine(xDim, -radius, xDim, radius);
      arrow(xDim, -radius, 0, 1);
      arrow(xDim, radius, 0, -1);
      extLine(xFeature, -radius, xDim, -radius);
      extLine(xFeature, radius, xDim, radius);
      dims.push({ symbol: symbol, kind: 'diameter', from: [xDim, -radius], to: [xDim, radius], arrows: 2, extensions: 2 });
      lowerLabels.push({ symbol: symbol, value: valueText(group, key), x: xDim });
    }

    diameterDim('P1', a.bodyStart, P1h, a.bodyStart + 1.5, cp.powderChamber, 'P1');
    if (shoulder && has(cp.powderChamber.P2)) {
      diameterDim('P2', shoulder.start[0], P2h, shoulder.start[0] + 1.5, cp.powderChamber, 'P2');
      diameterDim('H1', shoulder.end[0], H1h, shoulder.end[0] + 1.5, cp.collar, 'H1');
    }
    diameterDim('H2', v.L3, H2h, v.L3 + 1.5, cp.collar, 'H2');
    if (a.groove) {
      var floorMid = v.R + v.eMin / 2;
      diameterDim('E1', floorMid, v.E1 / 2, v.R + v.eMin + 1.5, cp.caseHead, 'E1');
    }

    // R1: a dimension line in front of the head face
    var xR1 = -3.0;
    dimLine(xR1, -R1h, xR1, R1h);
    arrow(xR1, -R1h, 0, 1);
    arrow(xR1, R1h, 0, -1);
    extLine(0, -R1h, xR1, -R1h);
    extLine(0, R1h, xR1, R1h);
    dims.push({ symbol: 'R1', kind: 'diameter', from: [xR1, -R1h], to: [xR1, R1h], arrows: 2, extensions: 2 });
    pending.push({
      symbol: 'R1',
      value: valueText(cp.caseHead, 'R1'),
      candidates: [
        { x: xR1 - 1.6, y: -R1h / 2 + 1.1, anchor: 'end' },
        { x: xR1 - 1.6, y: -R1h / 2 - 0.5, anchor: 'end' }
      ]
    });

    // G1: the bullet diameter, dimensioned beyond the tip
    var xG1 = v.L6 + 3.0;
    var re = b.exposedRadius;
    extLine(b.zc, -re, xG1, -re);
    extLine(b.zc, re, xG1, re);
    dimLine(xG1, -re, xG1, re);
    arrow(xG1, -re, 0, 1);
    arrow(xG1, re, 0, -1);
    dims.push({ symbol: 'G1', kind: 'diameter', from: [xG1, -re], to: [xG1, re], arrows: 2, extensions: 2 });
    pending.push({
      symbol: 'G1',
      value: valueText(cp.projectile, 'G1'),
      candidates: [
        { x: xG1 + 1.0, y: -re - 1.0, anchor: 'start' },
        { x: xG1 + 1.0, y: re + FS + 1.0, anchor: 'start' }
      ]
    });

    // Shoulder angle α: an arc across the axis between the two shoulder lines
    if (shoulder && v.alpha !== undefined) {
      var apexZ = shoulder.apexZ;
      if (apexZ !== null) {
        var half = (v.alpha * Math.PI / 180) / 2;
        var dist = Math.hypot(shoulder.start[0] - apexZ, shoulder.start[1]);
        var ra = Math.min(6, dist / 2);
        var arcPts = [];
        for (var i = 0; i <= 24; i++) {
          var th = -half + (2 * half * i) / 24;
          arcPts.push([apexZ + ra * Math.cos(th), ra * Math.sin(th)]);
        }
        for (var j = 1; j < arcPts.length; j++) {
          obstacles.push([arcPts[j - 1][0], arcPts[j - 1][1], arcPts[j][0], arcPts[j][1]]);
        }
        arrow(arcPts[0][0], arcPts[0][1], Math.sin(half), Math.cos(half));
        arrow(arcPts[arcPts.length - 1][0], arcPts[arcPts.length - 1][1], Math.sin(half), -Math.cos(half));
        dims.push({ symbol: 'α', kind: 'angle', from: arcPts[0], to: arcPts[arcPts.length - 1], arrows: 2, extensions: 0 });
        pending.push({
          symbol: 'α',
          value: F.formatAngle(cp.junctionCone.alpha),
          candidates: [
            { x: apexZ + ra + 1.2, y: -1.0, anchor: 'start' },
            { x: apexZ + ra + 1.2, y: FS + 1.2, anchor: 'start' },
            { x: apexZ, y: -(Rmax + 1.8), anchor: 'middle' }
          ]
        });
        arcPolyline = arcPts;
      }
    }

    // ---- place labels --------------------------------------------------------------------
    var placed = [];
    function fits(box) {
      for (var p = 0; p < placed.length; p++) {
        if (boxesOverlap(box, placed[p].box)) return false;
      }
      for (var o = 0; o < obstacles.length; o++) {
        if (segmentHits(obstacles[o], box)) return false;
      }
      return true;
    }

    var labels = [];
    pending.forEach(function (item) {
      var text = item.symbol + ' ' + item.value;
      var chosen = null;
      for (var c = 0; c < item.candidates.length && !chosen; c++) {
        var cand = item.candidates[c];
        var box = boxFor(text, cand.x, cand.y, cand.anchor);
        if (fits(box)) chosen = { box: box, x: cand.x, y: cand.y, anchor: cand.anchor };
      }
      if (!chosen) {
        var first = item.candidates[0];
        chosen = { box: boxFor(text, first.x, first.y, first.anchor), x: first.x, y: first.y, anchor: first.anchor, failed: true };
        notes.push('label ' + text + ' could not be placed clear of the drawing');
      }
      placed.push({ box: chosen.box });
      labels.push({ symbol: item.symbol, text: text, box: chosen.box, x: chosen.x, y: chosen.y, anchor: chosen.anchor });
    });

    // Diameter labels sit below the section, stacked where they would collide.
    lowerLabels.sort(function (p, q) { return p.x - q.x; });
    lowerLabels.forEach(function (item) {
      var text = item.symbol + ' ' + item.value;
      var chosen = null;
      for (var level = 0; level < 12 && !chosen; level++) {
        var y = Rmax + LOWER_BASE + FS * 0.75 + level * LEVEL_STEP;
        var box = boxFor(text, item.x, y, 'middle');
        var clash = placed.some(function (p) { return boxesOverlap(box, p.box); });
        if (!clash) chosen = { box: box, x: item.x, y: y, anchor: 'middle' };
      }
      placed.push({ box: chosen.box });
      labels.push({ symbol: item.symbol, text: text, box: chosen.box, x: chosen.x, y: chosen.y, anchor: 'middle' });
    });

    // ---- bounds and title block ----------------------------------------------------
    var xs = [];
    var ys = [];
    obstacles.forEach(function (s) { xs.push(s[0], s[2]); ys.push(s[1], s[3]); });
    labels.forEach(function (l) { xs.push(l.box.x0, l.box.x1); ys.push(l.box.y0, l.box.y1); });
    var yBottom = Math.max.apply(null, ys);
    var tbLines = [
      record.name,
      'C.I.P. table ' + record.tab + ' · revised ' + record.revised,
      'Dimensions in mm',
      'Scale 1:1'
    ];
    var tbWidth = Math.max.apply(null, tbLines.map(function (t) { return textWidth(t); })) + 4;
    xs.push(Math.min.apply(null, xs) + 2 + tbWidth);
    var xMin = Math.min.apply(null, xs) - 2;
    var xMax = Math.max.apply(null, xs) + 2;
    var tbX = xMin + 2;
    var tbTop = yBottom + 3;
    var tbHeight = 4 * 4.2 + 2;
    var yMin = Math.min(-Rmax, Math.min.apply(null, ys)) - 2;
    var yMax = tbTop + tbHeight + 2;
    var viewBox = [xMin, yMin, xMax - xMin, yMax - yMin];

    // ---- SVG ----------------------------------------------------------------------------
    var idPart = String(record.key).replace(/[^A-Za-z0-9_-]/g, '_');
    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img"' +
      ' aria-label="' + escapeXml(record.name + ' drawing') + '"' +
      ' viewBox="' + viewBox.map(num).join(' ') + '">');
    out.push('<defs><pattern id="hatch-' + idPart + '" patternUnits="userSpaceOnUse" width="1.1" height="1.1"' +
      ' patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="1.1" stroke="currentColor" stroke-width="0.12"/></pattern></defs>');
    out.push('<line class="centre-line" x1="' + num(xMin + 1) + '" y1="0" x2="' + num(xMax - 1) + '" y2="0"' +
      ' stroke="currentColor" stroke-width="0.15" stroke-dasharray="7 1.2 1.2 1.2"/>');
    out.push('<path class="section-wall" d="' + pathOf(walls, true) + '" fill="url(#hatch-' + idPart + ')" stroke="currentColor" stroke-width="0.3"/>');
    out.push('<path class="bullet" d="' + pathOf(bulletLower, false) + '" fill="none" stroke="currentColor" stroke-width="0.3"/>');
    out.push('<path class="bullet" d="' + pathOf(bulletMirror, false) + '" fill="none" stroke="currentColor" stroke-width="0.3"/>');
    out.push('<path class="outline" d="' + pathOf(upper, false) + '" fill="none" stroke="currentColor" stroke-width="0.35"/>');
    if (arcPolyline) {
      out.push('<path class="dim" d="' + pathOf(arcPolyline, false) + '" fill="none" stroke="currentColor" stroke-width="0.18"/>');
    }
    out.push('<path class="dim" d="' + dimLines.map(function (s) { return 'M' + num(s[0]) + ' ' + num(s[1]) + ' L' + num(s[2]) + ' ' + num(s[3]); }).join(' ') +
      '" fill="none" stroke="currentColor" stroke-width="0.18"/>');
    out.push('<path class="ext" d="' + extLines.map(function (s) { return 'M' + num(s[0]) + ' ' + num(s[1]) + ' L' + num(s[2]) + ' ' + num(s[3]); }).join(' ') +
      '" fill="none" stroke="currentColor" stroke-width="0.14"/>');
    out.push('<path class="arrow" d="' + arrows.join(' ') + '" fill="currentColor"/>');
    labels.forEach(function (l) {
      out.push('<text class="label" x="' + num(l.x) + '" y="' + num(l.y) + '" font-size="' + FS + '" text-anchor="' + l.anchor + '" fill="currentColor">' +
        escapeXml(l.text) + '</text>');
    });
    out.push('<g class="title-block"><rect x="' + num(tbX) + '" y="' + num(tbTop) + '" width="' + num(tbWidth) +
      '" height="' + num(tbHeight) + '" fill="none" stroke="currentColor" stroke-width="0.25"/>');
    tbLines.forEach(function (t, i) {
      out.push('<text x="' + num(tbX + 2) + '" y="' + num(tbTop + 4.2 * (i + 1)) + '" font-size="' + FS + '" fill="currentColor">' + escapeXml(t) + '</text>');
    });
    out.push('</g></svg>');

    return {
      drawable: true,
      name: record.name,
      key: record.key,
      viewBox: viewBox,
      svg: out.join(''),
      labels: labels,
      obstacles: obstacles,
      dims: dims,
      notes: notes
    };
  }

  return {
    build: build,
    escapeXml: escapeXml
  };
})();

if (typeof module !== 'undefined') module.exports = CartridgeDrawing;
