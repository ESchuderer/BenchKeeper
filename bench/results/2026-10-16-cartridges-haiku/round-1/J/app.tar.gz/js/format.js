/* Value formatting: numbers, tolerances, angles, symbols, units and table sections.
   Pure functions, no DOM. Loaded as a classic script in the browser and via require() in tests. */
var CartridgeFormat = (function () {
  'use strict';

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  var ANGLE_FIELDS = { alpha: true, alpha1: true, beta: true, delta: true, i: true };
  var BAR_FIELDS = { Pmax: true, PK: true, PE: true };
  var OTHER_UNITS = { EE: 'J', M: 'g', Q: 'mm²' };
  var DASH = '—';

  var CARTRIDGE_GROUPS = [
    'caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile'
  ];
  var CHAMBER_GROUPS = [
    'barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling'
  ];
  var TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Misc',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling'
  };

  function formatNumber(n) {
    return String(n);
  }

  function pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function isAngleObject(a) {
    return a !== null && typeof a === 'object' && 'degrees' in a;
  }

  function formatAngle(a) {
    if (isAngleObject(a)) {
      return a.degrees + '°' + pad2(a.minutes) + "'" + pad2(a.seconds) + '"';
    }
    return formatNumber(a) + '°';
  }

  function formatTolerance(tol) {
    return (tol > 0 ? '+' : '') + formatNumber(tol);
  }

  function formatValue(value, tol, isAngle) {
    var text = isAngle || isAngleObject(value) ? formatAngle(value) : formatNumber(value);
    if (tol === undefined) return text;
    return text + ' ' + formatTolerance(tol);
  }

  function symbolFor(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unitFor(field) {
    if (ANGLE_FIELDS[field] || field === 'N') return DASH;
    if (BAR_FIELDS[field]) return 'bar';
    if (Object.prototype.hasOwnProperty.call(OTHER_UNITS, field)) return OTHER_UNITS[field];
    return 'mm';
  }

  function isToleranceField(field) {
    return /Tol$/.test(field);
  }

  function sectionsFrom(source, groups) {
    var sections = [];
    groups.forEach(function (group) {
      var values = source ? source[group] : undefined;
      if (!values) return;
      var rows = [];
      Object.keys(values).forEach(function (field) {
        if (isToleranceField(field)) return;
        var tolKey = field + 'Tol';
        var tol = Object.prototype.hasOwnProperty.call(values, tolKey) ? values[tolKey] : undefined;
        rows.push({
          field: field,
          symbol: symbolFor(field),
          value: formatValue(values[field], tol, ANGLE_FIELDS[field] === true),
          unit: unitFor(field)
        });
      });
      if (rows.length > 0) {
        sections.push({ key: group, title: TITLES[group], rows: rows });
      }
    });
    return sections;
  }

  function buildSections(record) {
    return {
      cartridge: sectionsFrom(record.cartridge, CARTRIDGE_GROUPS),
      chamber: sectionsFrom(record.chamber, CHAMBER_GROUPS)
    };
  }

  function formatCapacity(record) {
    var capacity = record.annotations && record.annotations.publishedCapacity;
    if (!capacity) return null;
    return {
      value: formatNumber(capacity.grH2O) + ' gr H2O',
      note: capacity.note === undefined ? null : capacity.note,
      source: capacity.source,
      url: capacity.url
    };
  }

  return {
    formatNumber: formatNumber,
    formatAngle: formatAngle,
    formatValue: formatValue,
    symbolFor: symbolFor,
    unitFor: unitFor,
    buildSections: buildSections,
    formatCapacity: formatCapacity
  };
})();

if (typeof module !== 'undefined') module.exports = CartridgeFormat;
