/* Cartridge geometry: the outline, bullet and section of one cartridge, computed from its record.
   Points are [z, r] in mm: z along the axis from the head face (z = 0), r the radius (diameter / 2).
   Pure functions, no DOM. Rules follow the brief's drawing rules 1 to 9. */
var CartridgeGeometry = (function () {
  'use strict';

  var PI = Math.PI;
  var STEP = 2 * PI / 180; // sample curves every 2 degrees

  function has(value) {
    return value !== undefined && value !== null;
  }

  function toDegrees(angle) {
    if (!has(angle)) return undefined;
    if (typeof angle === 'number') return angle;
    return angle.degrees + angle.minutes / 60 + angle.seconds / 3600;
  }

  function rimTypeOf(R1, P1) {
    var ratio = R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function pocketFor(primerType) {
    switch (primerType) {
      case 'sp':
      case 'spm':
      case 'sr':
        return { diameter: 4.45, depth: 3.04 };
      case 'lp':
      case 'lpm':
        return { diameter: 5.33, depth: 3.04 };
      case 'lr':
      case 'lrm':
        return { diameter: 5.33, depth: 3.3 };
      default:
        return null;
    }
  }

  function sampleCount(sweep) {
    return Math.max(2, 2 * Math.ceil(Math.abs(sweep) / STEP / 2));
  }

  // Corner rounding: replaces points[i] by the tangent points and the arc between them.
  function fillet(points, i, radius) {
    var C = points[i];
    var P = points[i - 1];
    var N = points[i + 1];
    var toP = [P[0] - C[0], P[1] - C[1]];
    var toN = [N[0] - C[0], N[1] - C[1]];
    var lenP = Math.hypot(toP[0], toP[1]);
    var lenN = Math.hypot(toN[0], toN[1]);
    var u1 = [toP[0] / lenP, toP[1] / lenP];
    var u2 = [toN[0] / lenN, toN[1] / lenN];
    var cosT = Math.max(-1, Math.min(1, u1[0] * u2[0] + u1[1] * u2[1]));
    var half = Math.acos(cosT) / 2;
    var rho = radius;
    var t = rho / Math.tan(half);
    var maxT = Math.min(lenP, lenN) * 0.5;
    if (t > maxT) {
      t = maxT;
      rho = t * Math.tan(half);
    }
    var T1 = [C[0] + u1[0] * t, C[1] + u1[1] * t];
    var T2 = [C[0] + u2[0] * t, C[1] + u2[1] * t];
    var bx = u1[0] + u2[0];
    var by = u1[1] + u2[1];
    var bl = Math.hypot(bx, by);
    var dM = rho / Math.sin(half);
    var M = [C[0] + (bx / bl) * dM, C[1] + (by / bl) * dM];
    var a1 = Math.atan2(T1[1] - M[1], T1[0] - M[0]);
    var a2 = Math.atan2(T2[1] - M[1], T2[0] - M[0]);
    var sweep = a2 - a1;
    while (sweep > PI) sweep -= 2 * PI;
    while (sweep < -PI) sweep += 2 * PI;
    var n = sampleCount(sweep);
    var arc = [];
    for (var k = 0; k <= n; k++) {
      var a = a1 + (sweep * k) / n;
      arc.push([M[0] + rho * Math.cos(a), M[1] + rho * Math.sin(a)]);
    }
    return points.slice(0, i).concat(arc, points.slice(i + 1));
  }

  function values(record) {
    var cp = record.cartridge || {};
    var ch = cp.caseHead || {};
    var col = cp.collar || {};
    var pc = cp.powderChamber || {};
    var len = cp.lengths || {};
    var jc = cp.junctionCone || {};
    var ann = record.annotations || {};
    return {
      R1: ch.R1, R: ch.R, E: ch.E, E1: ch.E1, eMin: ch.eMin, R3: ch.R3,
      beta: toDegrees(ch.beta), f: ch.f, delta: toDegrees(ch.delta),
      H1: col.H1, H2: col.H2,
      P1: pc.P1, P2: pc.P2,
      L1: len.L1, L2: len.L2, L3: len.L3, L6: len.L6,
      G1: (cp.projectile || {}).G1,
      alpha: toDegrees((jc).alpha), r1Min: jc.r1Min, r2: jc.r2,
      family: record.family,
      category: ann.category,
      primerType: ann.primerType,
      shape: ann.defaultBulletShape
    };
  }

  var ESSENTIAL = ['R1', 'R', 'P1', 'H2', 'G1', 'L3', 'L6'];

  function analyse(record) {
    var v = values(record);
    var notes = [];
    var missing = ESSENTIAL.filter(function (key) { return !has(v[key]); });
    if (missing.length > 0) {
      return {
        drawable: false, values: v, notes: missing.map(function (key) {
          return key + ' not published: drawing not available';
        })
      };
    }

    var rimfire = v.family === 'rimfire';
    var belted = v.family === 'belted';
    var rimType = belted ? 'belted' : rimfire ? 'rimfire' : rimTypeOf(v.R1, v.P1);
    var pocket = rimfire ? null : pocketFor(v.primerType);
    if (!rimfire && !has(v.primerType)) notes.push('primerType not published: primer pocket not drawn');

    if (has(v.E) !== has(v.E1)) {
      notes.push((has(v.E) ? 'E1' : 'E') + ' not published: groove not drawn');
    }
    var groove = !rimfire && has(v.E) && has(v.E1) && has(v.eMin);
    if (!rimfire && has(v.E) && has(v.E1) && !has(v.eMin)) notes.push('eMin not published: groove not drawn');
    var belt = groove && belted && has(v.R3) && has(v.delta);
    if (groove && belted && !has(v.R3)) notes.push('R3 not published: belt not drawn');
    if (groove && belted && has(v.R3) && !has(v.delta)) notes.push('delta not published: belt not drawn');

    var bottleneck = has(v.alpha) && has(v.L1) && has(v.L2);
    var P2r = has(v.P2) ? v.P2 / 2 : v.P1 / 2;
    var H1r = has(v.H1) ? v.H1 / 2 : v.H2 / 2;
    if (bottleneck && !has(v.P2)) notes.push('P2 not published: body drawn without taper');
    if (bottleneck && !has(v.H1)) notes.push('H1 not published: neck starts at H2/2');

    var shape = v.shape || 'pointy';
    if (!['pointy', 'rounded', 'flat', 'semi_wadcutter'].includes(shape)) {
      notes.push('defaultBulletShape "' + shape + '" not recognised: drawn as pointy');
      shape = 'pointy';
    }
    var heeled = (v.H2 - v.G1) <= 0.015;

    // ---- outer profile: head face to mouth (rules 2 to 6) ----------------------
    var R1 = v.R1, R = v.R, P1 = v.P1;
    var pts = [[0, 0]];
    var z0;
    if (rimfire) {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      var rc = R1 / 2 - rho;
      pts.push([0, rc]);
      var rn = sampleCount(PI);
      for (var k = 1; k <= rn; k++) {
        var phi = (PI * k) / rn;
        pts.push([rho - rho * Math.cos(phi), rc + rho * Math.sin(phi)]);
      }
      z0 = 2 * rho;
      pts.push([z0, P1 / 2]);
    } else {
      var chamfer = has(v.beta) && has(v.f) && v.beta < 90;
      if (chamfer) {
        var x = Math.min(v.f * Math.tan(v.beta * PI / 180), R1 / 4);
        pts.push([0, R1 / 2 - x]);
        pts.push([v.f, R1 / 2]);
      } else {
        pts.push([0, R1 / 2]);
      }
      pts.push([R, R1 / 2]);
      if (groove) {
        pts.push([R, v.E1 / 2]);
        pts.push([R + v.eMin, v.E1 / 2]);
        var zRamp = belt ? R + v.eMin + (v.R3 / 2 - v.E1 / 2) / Math.tan(v.delta * PI / 180) : null;
        if (belt && zRamp <= v.E) {
          pts.push([zRamp, v.R3 / 2]);
          pts.push([v.E, v.R3 / 2]);
        }
        pts.push([v.E, P1 / 2]);
        z0 = v.E;
      } else {
        pts.push([R, P1 / 2]);
        z0 = R;
      }
    }

    if (bottleneck) {
      pts.push([v.L1, P2r]);
      pts.push([v.L2, H1r]);
      pts.push([v.L3, v.H2 / 2]);
      var iL1 = pts.length - 3;
      var iL2 = pts.length - 2;
      if (has(v.r2)) pts = fillet(pts, iL2, v.r2);
      if (has(v.r1Min)) pts = fillet(pts, iL1, v.r1Min);
    } else {
      pts.push([v.L3, v.H2 / 2]);
    }
    var outer = pts;

    // ---- bullet (rule 7) ----------------------------------------------------------
    var pistol = v.category === 'pistol';
    var G1 = v.G1;
    var L3 = v.L3;
    var L6 = v.L6;
    var tn = (v.H2 - G1) / 2;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
    var reExp = heeled ? v.H2 / 2 : G1 / 2;
    var heelR = heeled ? v.H2 / 2 - tb : null;

    var s, k2, m;
    if (shape === 'pointy') {
      s = G1; k2 = 0.40; m = Math.max(0.08 * G1, 1.27);
    } else if (shape === 'semi_wadcutter') {
      s = 0.6 * G1; k2 = 0.78; m = 0.6 * G1;
    } else if (shape === 'rounded') {
      s = (pistol ? 0.4 : 0.8) * G1; k2 = pistol ? 0.65 : 0.55; m = 0.15 * G1;
    } else {
      s = (pistol ? 0.4 : 0.8) * G1; k2 = pistol ? 0.70 : 0.60; m = 0.55 * G1;
    }
    var zb = L3 - s;
    var zc = zb + k2 * (L6 - zb);
    if (zc < L3) zc = L3;
    var n = L6 - zc;
    var nose = noseProfile(shape, zc, reExp, m, L6, n);

    var exposed = [[L3, reExp]].concat(nose);
    var head = heeled ? [[zb, 0], [zb, heelR], [L3, heelR], [L3, reExp]] : [[zb, 0], [zb, reExp]];
    var bulletSection = head.concat(nose, [[L6, 0]]);

    // ---- section walls (rule 8) ----------------------------------------------------
    var z0Body = z0;
    var outerBody = function (z) {
      return P1 / 2 + ((has(v.P2) ? P2r : P1 / 2) - P1 / 2) * (z - z0Body) / (v.L1 - z0Body);
    };
    var pocketDepth = pocket ? pocket.depth : 0;
    var grooveEnd = groove && !belt ? v.E + tb : -Infinity;
    var beltEnd = belt ? (R + v.eMin + (v.R3 / 2 - v.E1 / 2) / Math.tan(v.delta * PI / 180)) + tb : -Infinity;
    var w = Math.max(2.5, 0.25 * P1 / 2, pocket ? pocketDepth + 1.5 : -Infinity, grooveEnd, beltEnd);

    var inner;
    if (bottleneck) {
      var rwInner = outerBody(w) - tb;
      inner = [[w, rwInner]];
      if (v.L1 > w) inner.push([v.L1, P2r - tb]);
      inner.push([v.L2, H1r - tn]);
      inner.push([v.L3, v.H2 / 2 - tn]);
    } else {
      var rwStraight = P1 / 2 + (v.H2 / 2 - P1 / 2) * (w - z0Body) / (v.L3 - z0Body);
      var offsetW = tb + (tn - tb) * (w - z0Body) / (v.L3 - z0Body);
      inner = [[w, rwStraight - offsetW], [v.L3, v.H2 / 2 - tn]];
    }

    var pd = pocket ? pocket.diameter / 2 : 0;
    var poly = [[0, pd]].concat(outer.slice(1), [[v.L3, v.H2 / 2 - tn]]);
    for (var j = inner.length - 1; j >= 0; j--) poly.push(inner[j]);
    poly.push([w, 0]);
    if (pocket) poly.push([pocket.depth, 0], [pocket.depth, pd]);

    var shoulder = bottleneck ? {
      start: [v.L1, P2r],
      end: [v.L2, H1r],
      apexZ: P2r - H1r !== 0 ? v.L1 - P2r * (v.L2 - v.L1) / (P2r - H1r) : null
    } : null;

    return {
      drawable: true,
      family: v.family,
      rimType: rimType,
      primerType: v.primerType,
      pocket: pocket,
      groove: groove,
      belt: belt,
      bottleneck: bottleneck,
      heeled: heeled,
      values: v,
      outer: outer,
      bodyStart: z0,
      shoulder: shoulder,
      bullet: {
        shape: shape,
        s: s,
        zb: zb,
        zc: zc,
        n: n,
        m: m,
        k: k2,
        tipZ: L6,
        exposedRadius: reExp,
        heelRadius: heelR,
        exposed: exposed,
        section: bulletSection
      },
      walls: { tn: tn, tb: tb, w: w },
      inner: inner,
      sectionPolygon: poly,
      notes: notes
    };
  }

  // Nose from (zc, re) on the cylinder to the meplat at (L6, m/2); returns points after the cylinder.
  function noseProfile(shape, zc, re, m, L6, n) {
    var tipR = m / 2;
    var d = re - tipR;
    if (shape === 'pointy' && d > 1e-9) {
      var rho = (d * d + n * n) / (2 * d);
      var centreR = re - rho;
      var thetaEnd = Math.atan2(rho - d, n);
      var cnt = sampleCount(PI / 2 - thetaEnd);
      var out = [];
      for (var i = 0; i <= cnt; i++) {
        var th = PI / 2 - (PI / 2 - thetaEnd) * i / cnt;
        out.push([zc + rho * Math.cos(th), centreR + rho * Math.sin(th)]);
      }
      return out;
    }
    if (shape === 'rounded' && d > 1e-9) {
      var cnt2 = sampleCount(PI / 2);
      var arr = [];
      for (var j = 0; j <= cnt2; j++) {
        var t = (PI / 2) * j / cnt2;
        arr.push([zc + n * Math.sin(t), tipR + d * Math.cos(t)]);
      }
      return arr;
    }
    return [[zc, re], [L6, tipR]];
  }

  return {
    analyse: analyse,
    fillet: fillet,
    rimTypeOf: rimTypeOf,
    pocketFor: pocketFor,
    toDegrees: toDegrees
  };
})();

if (typeof module !== 'undefined') module.exports = CartridgeGeometry;
