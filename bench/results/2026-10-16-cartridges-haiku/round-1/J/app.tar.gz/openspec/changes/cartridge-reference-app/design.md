# Design

## Context

The repository holds only OpenSpec scaffolding. The brief supplies 25 cartridge records as JSON Lines and a long geometry rule set. See proposal.md for motivation and specs/ for the behaviour contract. The app must work from `file://`, which rules out ES modules (Chromium blocks module scripts from `file://`), `fetch` of local data, and any server.

## Goals / Non-Goals

**Goals:**
- Classic `<script>` files, one global namespace, pure logic separated from DOM code so it can be tested in Node.
- Drawing geometry computed from the record and tested for label collisions on all 25 records.
- Print output that fits one A4 page for every cartridge (checked by rendering to PDF).

**Non-Goals:**
- Editing, filtering beyond name/family, sorting, or any data source other than the embedded records.
- Bullet and rifling drawings beyond the bullet silhouette in the drawing rules.
- Verifying the published data against any external source.

## Decisions

### File layout
- `index.html` loads `styles/app.css`, then `js/data.js`, `js/format.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js` as classic scripts.
- `data/cartridges.jsonl` is the verbatim supplied data. `js/data.js` (`window.CARTRIDGE_RECORDS = [...]`) is generated from it by `scripts/build-data.js`; a test asserts the two agree. The app never needs the generator.
- Each module is an IIFE that exposes one global (`CartridgeFormat`, `CartridgeGeometry`, `CartridgeDrawing`, `CartridgeApp`) and sets `module.exports` when loaded by Node.
- Test tooling: Node 22 built-in `node --test`. `jsdom` is a dev dependency for the DOM tests only.

### Numbers and text
- Numbers display as JavaScript's shortest form (`String(n)`), which matches the brief (`4150 bar` from a record that stores `4150.0`) and keeps `51.18` as is.
- Tolerances are formatted as ` -0.2` (or ` +0.1`) appended to the value. The tolerance keys are `<X>Tol` for X in the same group.
- Angles: a number `n` shows `n°`; an object shows `d°mm'ss"` with two-digit minutes and seconds.
- Units: pressures bar (Pmax, PK, PE), EE J, M g, Q mm², `N` no unit (dash), angles dash (the unit is in the value), water capacity `gr H2O`. All other numeric fields are dimensional and show `mm`. The brief gives no unit for `S`, `s`, `G`, `Fe`, `deltaL`; these are treated as mm and flagged for the user.
- Pluralisation: "1 cartridge", otherwise "<n> cartridges".

### Search and routing
- Search normalises by lowercasing and removing whitespace, hyphens, dots and commas from both the query and the candidate strings, then tests for substring match in `name` and each `alternativeNames` entry. This makes "7,62 x 51" and "308 Win." agree.
- Routes are hash-based: `#/` (list) and `#/cartridge/<key>` (detail). Plain hash routing needs no server and survives reload. List state (search text, family) lives in memory, so returning from a detail view keeps it.

### Geometry (`js/geometry.js`, pure)
- Internal coordinates are `(z, r)`: z along the axis from the head face, r the radius (diameter/2). The brief's rule text writes some points as `(r, z)`; the implementation follows the brief's meaning, not its tuple order. For example, `(R1/2, R)` is radius R1/2 at z = R.
- Rim type (rule 1): belted and rimfire by family; otherwise `R1/P1 >= 1.05` rimmed, `< 0.98` rebated, else rimless. Rebated is recorded but drawn like rimless.
- Rimfire rim edge: a half-round of radius ρ = min(R/2, (R1−P1)/2), centre at (R1/2 − ρ, ρ), spanning z from 0 to 2ρ. The rim top is then at 2ρ. All 3 rimfire records give ρ = R/2.
- The head-face chamfer is applied only where beta and f are published and beta < 90°. For rimfire, the half-round replaces the chamfer.
- Belt ramp (belted): the ramp leaves the groove floor end `(E1/2, R+eMin)` at an angle δ **to the axis**, so Δz = Δr / tan δ up to R3/2. Interpreted as "angle to the axis" (the brief's wording), not to the radial plane.
- Body and shoulder: body from `(P1/2, bodyStart)` to `(P2/2, L1)`, where bodyStart = E after a groove, else R. Shoulder from `(P2/2, L1)` to `(H1/2, L2)`. Corner fillets use the cartridge's `r1Min` at the body side and `r2` at the neck side; the fillet tangent length is r / tan(θ/2) with θ the interior angle.
- A bottleneck case needs alpha, L1 and L2; without them the case is straight. A bottleneck case missing P2 or H1 draws the shoulder from P1/2 (no taper) and notes the missing value.
- Bullet: exactly the brief's rules. The ogive is sampled as a polyline (about 2° steps); the quarter ellipse likewise. Polylines keep the arc maths testable and avoid SVG arc sweep-flag errors.
- Heeled case (H2 − G1 ≤ 0.015): exposed radius H2/2, seated heel radius H2/2 − tb.
- For `22 Long Rifle`, the brief's formula gives tn = 0, so the mouth wall has zero thickness. The formula is applied as written and the result is reported to the user rather than changed.

### Section (`js/geometry.js`)
- tn = (H2 − G1)/2; tb = min(max(1.3·tn, 0.6), 0.35·P1/2).
- Inner profile: offset tb along the body, tn along the neck, linear blend across the shoulder. A straight case blends linearly from tb at the body start to tn at the mouth.
- Solid head: from the head face to z = w, minus the primer pocket. The section polygon is: head face from the pocket edge to the outer profile, the outer profile to the mouth, the mouth face, the inner profile back to z = w, the floor at z = w, the axis, the pocket bottom and wall.
- Pocket mapping: sp, spm, sr → Ø4.45; lp, lpm, lr, lrm → Ø5.33. Depth 3.3 for lr and lrm; 3.04 otherwise. Rimfire: none.

### Drawing (`js/drawing.js`)
- SVG user unit = 1 mm. x = z, and y = −r for the outside view (upper half) and +r for the section (lower half). The viewBox is the bounding box of the geometry, labels and title block, plus a margin. Width is 100 %, so scaling is uniform.
- Length dimensions (L1, L2, L3, L6, R): horizontal rows above the outline. Their extension lines run from each feature up to its row. Rows are ordered so no extension line crosses another row: R lowest, then L1, L2, L3, L6 highest.
- R1: vertical dimension line to the left of the head (free space), with extension lines from the rim corners.
- Diameters (P1, P2, H1, H2, G1, E1): vertical dimension line spanning ±r at a small offset to the right of the feature, with horizontal extension lines from the feature edges to the dimension line. Where a neighbour's outline would be crossed, the offset and label position are chosen from candidates.
- Shoulder angle α: an arc centred on the shoulder apex on the axis, between the two shoulder lines, labelled `α 46°`.
- Labels are placed from an ordered list of candidate positions. The first candidate that does not overlap a placed label, the outline polylines, or the title block is used. If none is free, the best candidate is kept and the test fails, so the layout is never silently wrong.
- Title block: below the section, with name, C.I.P. table, revision date, "Dimensions in mm", and "Scale 1:1". Drawn in mm so it prints at the same proportions as the drawing.
- Missing values are listed in an HTML note beneath the drawing and are never drawn as a guess.

### Styling and print
- CSS custom properties for light (default) and dark (`prefers-color-scheme: dark`). The SVG uses the same variables, so it follows the theme.
- `@media print` forces light variables, hides navigation, search, filter and buttons, sets A4 portrait, and lays out the cartridge and chamber tables in two columns to fit one page. A source footer is printed at the end: "Source: C.I.P. TDCC, revised <date>".
- Fonts: system UI stack; numbers use `font-variant-numeric: tabular-nums`.

## Risks / Trade-offs

- [The brief's tuple order is inconsistent between rules] → Follow the meaning of each rule (see Geometry) and cover the typical cases with tests.
- [Label collisions in tight drawings, e.g. 9 mm Luger with small L6] → Candidate placement with automatic collision checks, tested on all 25 records.
- [A single A4 page for the longest cartridge (9,3 x 74 R)] → Two-column tables in print; verify the page count on all 25 via a headless browser PDF render, if a browser is available.
- [`file://` script loading] → Only classic scripts, no fetch, no module imports; verified in a headless browser if available.
- [22 Long Rifle zero mouth wall] → Reported, not altered.

## Migration Plan

Not applicable. New files only; rollback means deleting the new files.

## Open Questions

None that change behaviour. The unit assumption for `S`, `s`, `G`, `Fe` and `deltaL` (mm) is flagged in the final report for the user to confirm.
