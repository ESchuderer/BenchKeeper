## Why

Reloaders, gunsmiths and engineers need a quick, precise reference for C.I.P. cartridges: dimensions, pressures, tolerances and a true-to-scale drawing. No such tool exists in this project, and the 25 records supplied with the brief are the only data the app may use.

## What Changes

- Add a static, dependency-free web app in the project root: `index.html`, a stylesheet, JavaScript files and the 25 cartridge records embedded as data. It runs from `file://` in Chromium and from any static file server.
- Start page: heading "Cartridges", a list of all cartridges (name link, family, case length L3), a "Search" field matching names and alternative names, a "Family" select and a count line.
- Detail view at its own bookmarkable address: identity block, C.I.P. table, country, dates, pressure method, published water capacity with source link, the 2D drawing, and all cartridge and chamber values grouped by section.
- Values use the brief's formatting rules: units, angles in degrees (and degrees/minutes/seconds), tolerances shown beside their value, and the symbol table.
- Procedurally computed 2D drawing (inline SVG), true to scale in mm, with dimension lines, extension lines, labels, title block and centre line.
- Print: a "Print" button opens the browser print dialog; the printed detail is one A4 portrait page, black on white, with a source footer.
- Light and dark colour schemes follow the system setting on screen; print is always light. Layout works on phone widths.
- **No** data changes, no network requests, no framework, no build step at runtime.

## Capabilities

### New Capabilities

- `cartridge-catalogue`: start page listing, name search, family filter, count, and routing to detail views.
- `cartridge-detail`: detail view content, section tables, navigation, bookmarkable addresses.
- `cartridge-values`: how values, units, tolerances, angles and symbols are rendered.
- `cartridge-drawing`: the computed cross-section and outside-view drawing, its dimensions, labels and title block.
- `cartridge-print`: the printed page and its footer.
- `app-platform`: static delivery, offline operation, colour schemes, responsive layout, and the development test setup.

### Modified Capabilities

None. The repository has no existing specs.

## Impact

- New files only: `index.html`, `styles/`, `js/`, `data/`, `tests/`, `package.json` (dev dependencies only, for tests), `README.md`.
- No existing code is affected (the repository holds only project scaffolding).
- Dependencies: the app has none at runtime. Development uses Node 22's built-in test runner; a DOM implementation and a headless browser may be dev dependencies for verification only.
