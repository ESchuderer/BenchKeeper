## ADDED Requirements

### Requirement: Static, dependency-free delivery
The app SHALL be `index.html` in the project root with its stylesheet and JavaScript files. It SHALL use plain HTML, CSS and JavaScript with no framework, no build step, no server code, no runtime dependencies, and no network requests (no CDNs, web fonts or analytics).

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened in Chromium from a `file://` address
- **THEN** the start page renders completely and all cartridge details and drawings work without a server

#### Scenario: Served by any static server
- **WHEN** the project folder is served by any static file server
- **THEN** the app behaves identically

#### Scenario: No network
- **WHEN** the app is run with network access blocked
- **THEN** it works fully

### Requirement: Data
The 25 records SHALL be embedded in the app exactly as supplied, without changes, additions or fetches. Each record is used as published; the app SHALL NOT alter a record's values.

#### Scenario: Data fidelity
- **WHEN** the embedded data is compared with the supplied JSON Lines records
- **THEN** every record is identical in every field

### Requirement: Colour scheme
On screen the app SHALL follow the system light or dark setting. Print is always light.

#### Scenario: Dark system setting
- **WHEN** the system prefers a dark colour scheme
- **THEN** the page uses a dark background with light text and remains legible, including the drawing

### Requirement: Typography
The interface SHALL use a dense, calm, technical style with tabular numerals in tables and values. The interface language is English.

#### Scenario: Numerals align
- **WHEN** a table of values is shown
- **THEN** the numerals are tabular so that decimal points align within a column

### Requirement: Development tests
The repository SHALL include automated tests of the data, formatting, search and filter logic, routing, geometry and drawing, runnable with `npm test` on Node.js 22. Test tooling SHALL be a development dependency only.

#### Scenario: Test run
- **WHEN** `npm test` is run on Node.js 22
- **THEN** all tests run and report pass or fail
