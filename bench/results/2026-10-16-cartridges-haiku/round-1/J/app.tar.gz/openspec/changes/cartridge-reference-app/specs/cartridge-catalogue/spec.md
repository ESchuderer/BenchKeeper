## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" and one entry per cartridge record (all 25). Each entry SHALL show the cartridge's name as a link, its family, and its case length L3 with unit mm. The link text SHALL be exactly the record's `name`, and activating it SHALL open that cartridge's detail view.

#### Scenario: Initial page
- **WHEN** the start page is opened with no search text and family "All"
- **THEN** all 25 cartridges are listed in the order of the data file, and the count line reads "25 cartridges"

#### Scenario: Link text is the published name
- **WHEN** the entry for the cartridge named `308 Win.` is inspected
- **THEN** its link text is exactly `308 Win.`

### Requirement: Name search
A field labelled "Search" SHALL filter the list as the user types. A cartridge matches when the query occurs in its `name` or in any of its `alternativeNames`. Matching SHALL ignore letter case, whitespace, hyphens, dots and commas, so that "7,62 x 51", "7.62x51" and "762x51" all match the same cartridges. An empty query matches everything.

#### Scenario: Alternative name finds a cartridge
- **WHEN** the user types `7,62 x 51`
- **THEN** the list contains "308 Win." and the count reads "1 cartridge"

#### Scenario: No match
- **WHEN** the user types a string that matches no name or alternative name
- **THEN** the list is empty and the count reads "0 cartridges"

### Requirement: Family filter
A select labelled "Family" SHALL offer the options All, rimless, rimmed, belted, pistol and rimfire. Choosing a family SHALL show only cartridges of that family (the record's `family` field). The family filter and the search SHALL combine with AND.

#### Scenario: Combined filter
- **WHEN** the family is "pistol" and the search text is "38"
- **THEN** only the pistol cartridges whose name or alternative names contain "38" are listed

### Requirement: Count line
The page SHALL show the text "<n> cartridges" giving the number of listed cartridges. When exactly one cartridge is listed the text SHALL read "1 cartridge".

#### Scenario: Count updates
- **WHEN** the search text changes
- **THEN** the count line updates to the number of listed cartridges

### Requirement: Bookmarkable detail routes
Each cartridge SHALL have its own address of the form `#/cartridge/<key>`, where `<key>` is the record's `key`. Opening that address SHALL show the detail view, and it SHALL survive a page reload. The addresses SHALL work when the app is opened from `file://`. An unknown key SHALL show a "Cartridge not found" message with a link to the list.

#### Scenario: Reload keeps the detail view
- **WHEN** the detail view for `223 Rem.` is open and the page is reloaded
- **THEN** the detail view for `223 Rem.` is shown again

#### Scenario: Unknown key
- **WHEN** the address is `#/cartridge/unknown`
- **THEN** a "Cartridge not found" message and a link "All cartridges" are shown

### Requirement: Return to the list
Each detail view SHALL have a link "All cartridges" that returns to the start page. Returning SHALL keep the search text and family filter that were active before the detail view was opened.

#### Scenario: Filter survives a round trip
- **WHEN** the user searches for "22", opens "22 Long Rifle", and follows "All cartridges"
- **THEN** the search field still reads "22" and the same results are listed
