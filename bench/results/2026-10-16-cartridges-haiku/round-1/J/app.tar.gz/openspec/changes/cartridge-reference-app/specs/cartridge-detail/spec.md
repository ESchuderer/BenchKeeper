## ADDED Requirements

### Requirement: Identity block
The detail view SHALL show a heading with the cartridge's name, followed by: alternative names (when published), family, category, primer type, the C.I.P. table (`tab`), country, published date, revised date, pressure method, and the published water capacity with its source link. Dates SHALL be shown as published (for example `1984-06-14`). The water capacity SHALL be shown with unit "gr H2O", with its `note` when one is published. The source link SHALL point to the record's `publishedCapacity.url`, and its text SHALL be the record's `source`. Fields that are not published SHALL be omitted, not shown as blank.

#### Scenario: Water capacity with source
- **WHEN** the detail view for `308 Win.` is shown
- **THEN** it shows "56 gr H2O", the note "Lapua brass measures 55.8 (lapua-308)", and a link with text "kwk" to `http://kwk.us/cases.html`

#### Scenario: Alternative names
- **WHEN** the detail view for `308 Win.` is shown
- **THEN** the alternative names "308 Winchester" and "7,62 x 51" are shown

### Requirement: Section tables
Below the drawing, all cartridge values SHALL be shown in one table per section (case head, collar, junction cone, lengths, misc, powder chamber, pressures, projectile), and all chamber values in one table per chamber section (barrel, breech, collar, grooves, junction cone, lengths, powder chamber, rifling). Each table SHALL have the columns "Symbol", "Value" and "Unit". A value that is not published SHALL NOT produce a row. Tolerances SHALL NOT produce rows of their own (see cartridge-values).

#### Scenario: Section structure
- **WHEN** the detail view for `223 Rem.` is shown
- **THEN** there is a "Lengths" table in the cartridge values containing the rows L1, L2, L3 and L6, and a "Grooves" table in the chamber values containing N, Q, b and u

### Requirement: Print and navigation controls
The detail view SHALL have a "Print" button that opens the browser print dialog, and a link "All cartridges" to the start page. These controls and the search and filter controls SHALL NOT be part of the printed page.

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** the browser's print dialog opens for the current page

### Requirement: Layout on small and large screens
The detail view SHALL be usable on a phone-width screen: the drawing SHALL scale to the available width, and wide tables SHALL scroll horizontally inside their container rather than widen the page.

#### Scenario: Phone width
- **WHEN** the detail view is shown at 360 px viewport width
- **THEN** the page does not scroll horizontally, and the drawing fits the width of the screen
