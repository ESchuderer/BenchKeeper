## ADDED Requirements

### Requirement: Drawing is an inline SVG to scale
Each detail view SHALL contain one inline SVG drawing with accessible name "<name> drawing". The drawing SHALL be computed from the record's values at display time. One SVG user unit SHALL equal 1 mm, the cartridge axis SHALL be horizontal with the head on the left, and the drawing SHALL be true to scale in mm. The SVG SHALL scale to the width of its container.

#### Scenario: Accessible name
- **WHEN** the detail view for `308 Win.` is shown
- **THEN** the SVG has the accessible name "308 Win. drawing"

### Requirement: Outside view and section
The upper half of the drawing SHALL be the outside view: the silhouette of the case, with the seated bullet hidden and the exposed bullet shown. The lower half SHALL be a section through the axis in which the cut walls of the case are hatched and the seated bullet is shown inside the case. A dash-dot centre line SHALL run along the axis.

#### Scenario: Section shows the seated bullet
- **WHEN** the drawing of `223 Rem.` is shown
- **THEN** the lower half shows the bullet outline from its base inside the case up to the tip, and the upper half shows only the bullet part beyond the mouth

### Requirement: Outer profile
The outer half-profile SHALL be built from the axis at the head face to the mouth, then mirrored at the axis. The rim type SHALL be determined by the family and the ratio R1/P1: family `belted` is belted; family `rimfire` is rimfire; otherwise R1/P1 ≥ 1.05 is rimmed, R1/P1 < 0.98 is rebated, and any other ratio is rimless.

#### Scenario: Rim type from ratio
- **WHEN** the cartridge is `38 Special` (family pistol, R1 11.18, P1 9.63)
- **THEN** its rim type is rimmed

#### Scenario: Rimfire rim
- **WHEN** the cartridge is `22 Long Rifle` (family rimfire)
- **THEN** its rim edge is a half-round of radius min(R/2, (R1 − P1)/2) whose outermost point is at R1/2

#### Scenario: Chamfer
- **WHEN** beta and f are published and beta is less than 90°
- **THEN** the head face has a chamfer from (R1/2 − min(f·tan β, R1/4), 0) to (R1/2, f), then runs up to (R1/2, R)

#### Scenario: Square rim corner
- **WHEN** the chamfer rule does not apply and the cartridge is not rimfire
- **THEN** the rim corner is square, from (R1/2, 0) up to (R1/2, R)

### Requirement: Extractor groove and belt
Where E and E1 are published, the profile SHALL run from (R1/2, R) in to (E1/2, R), along the groove floor to (E1/2, R + eMin), then ramp out to (P1/2, E). For a belted cartridge the ramp SHALL go from the floor end at the angle δ to the axis up to the belt radius R3/2, follow the belt to z = E, then step in to P1/2. Where no groove is published, the profile SHALL step in from (R1/2, R) to (P1/2, R).

#### Scenario: Groove
- **WHEN** the cartridge is `308 Win.` (E 3.85, E1 10.39, eMin 1.4, R 1.37)
- **THEN** the profile has a groove of diameter 10.39 between z = 1.37 and z = 2.77 and a ramp to the body start at z = 3.85

#### Scenario: Belt
- **WHEN** the cartridge is `300 Win. Mag.` (belted, R3 13.51, δ 35°)
- **THEN** the belt ramp leaves the groove floor at the angle δ to the axis and reaches R3/2, the belt continues to z = E, then steps in to P1/2

#### Scenario: No groove
- **WHEN** the cartridge is `9,3 x 74 R` (no E or E1 published)
- **THEN** the rim steps in directly from (R1/2, R) to (P1/2, R)

### Requirement: Body, shoulder and neck
A bottleneck cartridge with alpha, L1 and L2 published SHALL have a body that is a straight line from the body start (P1/2) to (P2/2, L1), a shoulder from (P2/2, L1) to (H1/2, L2) drawn through the published points with the included angle α (the line lies at α/2 to the axis), and a neck from (H1/2, L2) to (H2/2, L3), then the mouth face. The corner at the body side SHALL be rounded with r1 min and the corner at the neck side with r2, where published. Any other case SHALL be drawn straight, with the body running from the body start to (H2/2, L3) and the mouth face after it.

#### Scenario: Bottleneck
- **WHEN** the cartridge is `223 Rem.`
- **THEN** the shoulder runs from (4.5, 36.52) to (3.215, 39.55), the included shoulder angle is 46°, and the corners are rounded with r1 min 0.64 and r2 2.54

#### Scenario: Straight case
- **WHEN** the cartridge is `9 mm Luger` (no alpha, L1 or L2)
- **THEN** the body runs straight from the body start to (H2/2, L3) with no shoulder

### Requirement: Bullet
The exposed and seated bullet SHALL be drawn from the mouth to the tip at z = L6 with shank diameter G1, with the nose shape of `annotations.defaultBulletShape`:
- The seating depth below the mouth is s = 1.0·G1 for pointy; 0.8·G1 for rounded or flat rifle and rimfire; 0.4·G1 for rounded or flat pistol; 0.6·G1 for semi_wadcutter. The base is at zb = L3 − s and the bullet length Lb = L6 − zb.
- The cylinder runs from the base to zb + k·Lb, with k = 0.40 pointy; 0.55 rounded rifle or rimfire; 0.65 rounded pistol; 0.60 flat rifle; 0.70 flat pistol; 0.78 semi_wadcutter.
- The nose ends in a flat tip (meplat) of diameter m. Pointy: tangent ogive with m = max(0.08·G1, 1.27) and arc radius ρ = ((G1/2 − m/2)² + n²) / (2·(G1/2 − m/2)), n being the nose length, centred on the radial line where the nose starts. Rounded: quarter ellipse with m = 0.15·G1. Flat: straight cone with m = 0.55·G1. Semi_wadcutter: straight cone with m = 0.6·G1.
- Heeled case (H2 − G1 ≤ 0.015, such as 22 Long Rifle): the exposed bullet has the case's outside diameter H2, and the seated heel has diameter H2 − 2·tb.

#### Scenario: Pointy bullet
- **WHEN** the bullet of `223 Rem.` is drawn
- **THEN** its base is at 39.0 mm, the cylinder ends at 46.36 mm, and the nose is a tangent ogive ending in a meplat of diameter 1.27 mm

#### Scenario: Heeled bullet
- **WHEN** the cartridge is `22 Long Rifle`
- **THEN** the exposed bullet has diameter 5.72 and the seated heel has diameter H2 − 2·tb

### Requirement: Section walls, solid head and primer pocket
In the section, the neck wall is tn = (H2 − G1)/2 and the body wall is tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner line SHALL follow the outer body at tb, the neck at tn, and blend linearly across the shoulder. The solid head SHALL run from the head face to z = w, where w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or the belt ramp end + tb on belted cases). Centrefire cases SHALL have a primer pocket: diameter 4.45 for sp, spm and sr, and 5.33 for lp, lpm, lr and lrm; depth 3.04 for sp, spm, sr, lp and lpm, and 3.3 for lr and lrm. Rimfire cases have no pocket.

#### Scenario: Primer pocket
- **WHEN** the cartridge is `223 Rem.` (primer sr)
- **THEN** the pocket is 4.45 mm in diameter and 3.04 mm deep, and the solid head extends to z = 4.54

### Requirement: Missing values
If a value that a rule needs is not published, the drawing SHALL omit that feature and SHALL name the missing value in the drawing's notes. The drawing SHALL NOT invent a number.

#### Scenario: Missing shoulder value
- **WHEN** a bottleneck cartridge has no P2
- **THEN** the drawing omits the taper of the body, and the note names P2 as missing

### Requirement: Dimensions and labels
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and, where published, for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value, for example `L3 51.18`, and its tolerance when published (for example `L1 36.52 -0.2`). Labels SHALL NOT overlap each other, and SHALL NOT overlap the outline of the drawing. The shoulder angle SHALL be labelled `α 46°`.

#### Scenario: Labels do not collide
- **WHEN** the drawing of any of the 25 cartridges is computed
- **THEN** no two labels overlap, and no label overlaps the outline

### Requirement: Title block
The drawing SHALL include a title block with the cartridge name, the C.I.P. table (`tab`), the revision date, the text "Dimensions in mm", and the scale.

#### Scenario: Title block
- **WHEN** the drawing of `22 Long Rifle` is shown
- **THEN** the title block shows "22 Long Rifle", "Table V", "2024-05-14", "Dimensions in mm" and a scale

### Requirement: Legible at phone width and in print
The drawing SHALL be legible at a phone-width screen and when printed at full width on A4. Label text SHALL be at least 2.5 mm high in drawing units.

#### Scenario: Phone
- **WHEN** the drawing is shown at 360 px width
- **THEN** the drawing scales to fit the width and its labels remain readable
