## ADDED Requirements

### Requirement: Print opens the browser print dialog
Activating "Print" on a detail view SHALL open the browser's print dialog for that page.

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** the browser print dialog opens

### Requirement: One A4 portrait page
The printed detail view SHALL fit on one A4 portrait page, in black on white, with no colour. It SHALL show a page header with the cartridge name, the drawing at full width with every label legible, then the tables. Navigation, the search and filter controls, and buttons SHALL NOT appear.

#### Scenario: Print layout
- **WHEN** the detail view for `308 Win.` is printed
- **THEN** the output is one A4 portrait page with the name in the header, the drawing spanning the page width, the tables below it, and no buttons or navigation

#### Scenario: Print colours
- **WHEN** the page is printed while the system is in dark mode
- **THEN** the output is still black on white

### Requirement: Source footer
Each printed page SHALL have a footer that names the source "C.I.P. TDCC" and the record's revised date.

#### Scenario: Footer
- **WHEN** the detail view for `223 Rem.` is printed
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2017-05-17"
