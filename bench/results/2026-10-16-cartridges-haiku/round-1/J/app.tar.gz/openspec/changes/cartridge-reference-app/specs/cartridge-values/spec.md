## ADDED Requirements

### Requirement: Numbers are shown as published
Numeric values SHALL be shown with a decimal point and no thousands separator, without rounding or re-scaling, using the digits of the record (for example `51.18 mm`, `4150 bar`). Fractional digits that are zero in the record are not shown (`9.0` reads `9`), as in the brief's example `4150 bar`.

#### Scenario: Length and pressure
- **WHEN** L3 (44.7) and Pmax (4150.0) of `223 Rem.` are shown
- **THEN** they read `44.7 mm` and `4150 bar`

### Requirement: Units
Pmax, PK and PE SHALL be shown in bar, EE in J, M in g, and Q in mm². Lengths, diameters, radii, depths, groove widths, twist values and other dimensional fields SHALL be shown in mm. The count N SHALL show no unit; its unit cell shows a dash. Angles carry their unit in the value (see Angles) and their unit cell shows a dash. Water capacity is shown in gr H2O.

#### Scenario: Count has no unit
- **WHEN** N of the grooves of `223 Rem.` (6) is shown
- **THEN** the value is `6` and the unit cell shows a dash

#### Scenario: Groove width and twist
- **WHEN** the grooves of `223 Rem.` are shown
- **THEN** b reads `1.88` in mm, Q reads `25.03` in mm², and u reads `305` in mm

### Requirement: Tolerances sit beside their value
A field `<X>Tol` SHALL be shown in the same Value cell as X, after X's value and separated by a space (for example `39.62 -0.2`). A tolerance SHALL NOT produce a row of its own. A positive tolerance SHALL be shown with a leading "+".

#### Scenario: Length with tolerance
- **WHEN** the lengths of `223 Rem.` are shown
- **THEN** the L1 value cell reads `36.52 -0.2` and no row is labelled "L1Tol"

#### Scenario: Head dimension with tolerance
- **WHEN** the case head of `22 Win. Mag. R.F.` is shown
- **THEN** the R value cell reads `1.27 -0.18`

### Requirement: Angles
Angles (alpha, alpha1, beta, delta and i) SHALL be shown in degrees with the degree sign. A plain number SHALL be shown as `<n>°` (for example `40°`). An object `{degrees, minutes, seconds}` SHALL be shown as `<d>°<mm>'<ss>"`, with minutes and seconds written as two digits (for example `39°59'49"`, `1°30'00"`).

#### Scenario: Plain and structured angles
- **WHEN** the shoulder angle alpha of `223 Rem.` (46) and of `6,5 x 55 SE` (`{50, 35, 2}`) are shown
- **THEN** they read `46°` and `50°35'02"`

### Requirement: Symbols
The Symbol column SHALL show the field name, except for these fields: `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G".

#### Scenario: Mapped symbols
- **WHEN** the case head of `223 Rem.` is shown
- **THEN** the symbol for `eMin` reads "e min", the symbol for `beta` reads "β", and the symbol for `E1` reads "E1"

### Requirement: Missing values
A value that is not published SHALL be omitted from the tables. The app SHALL NOT compute, estimate or fill in a missing value in a table.

#### Scenario: Missing value omitted
- **WHEN** the junction cone of `9 mm Luger` (no junction cone is published) is shown
- **THEN** the junction cone table is omitted or empty and no value is invented
