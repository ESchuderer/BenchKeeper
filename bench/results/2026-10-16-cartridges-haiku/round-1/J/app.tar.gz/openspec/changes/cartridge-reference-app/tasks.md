# Tasks

## 1. Data and project setup

- [x] 1.1 Write `data/cartridges.jsonl` with the 25 supplied records verbatim, one per line. Verify: 25 lines, each parses as JSON.
- [x] 1.2 Write `tests/data.test.js` (failing first): 25 records, unique `key`s, every record has `name`, `family`, `cartridge`, `chamber`; `js/data.js` matches the JSONL record-for-record. Then add `scripts/build-data.js` (JSONL → `js/data.js`) and `package.json` (`"test": "node --test tests/"`, dev dependencies only). Verify: `npm test` passes the data tests.
- [x] 1.3 Add `README.md` describing how to open the app, run tests, and regenerate `js/data.js`. Verify: the commands in it run as written.

## 2. Value formatting

- [x] 2.1 Write `tests/format.test.js` (failing first) covering: number display (`4150.0` → `4150`, `51.18` → `51.18`); tolerance text (`-0.2` → ` -0.2`, positive → ` +0.1`); angles (`40` → `40°`, `{50,35,2}` → `50°35'02"`, `{1,30,0}` → `1°30'00"`); unit mapping (Pmax bar, EE J, M g, Q mm², N dash, angles dash, other dimensional mm); symbol mapping for every name in the brief; the row list omits `*Tol` keys. Then implement `js/format.js`. Verify: format tests pass.
- [x] 2.2 Write `tests/format.test.js` cases for the sections: cartridge sections in order (case head, collar, junction cone, lengths, misc, powder chamber, pressures, projectile) and chamber sections (barrel, breech, collar, grooves, junction cone, lengths, powder chamber, rifling), with empty sections omitted. Verify: section tests pass for `223 Rem.` and `9 mm Luger`.

## 3. Catalogue logic

- [x] 3.1 Write `tests/catalogue.test.js` (failing first): `normalise` ignores case, whitespace, hyphens, dots and commas; `7,62 x 51` finds `308 Win.`; family filter with All; AND combination with search; count text ("1 cartridge", "25 cartridges", "0 cartridges"); route parsing for `#/`, `#/cartridge/223_rem`, and unknown keys. Then implement `js/catalogue.js`. Verify: catalogue tests pass.

## 4. Geometry

- [x] 4.1 Write `tests/geometry.test.js` (failing first) for: rim type (`38 Special` rimmed, `22 Long Rifle` rimfire, `9 mm Luger` rimless, `300 Win. Mag.` belted); pocket mapping for every primer type; head chamfer applied only when beta and f are published; rimfire half-round radius ρ = R/2 and outermost point at R1/2; groove points for `308 Win.` (E1/2 at z 1.37 to 2.77); belt ramp for `300 Win. Mag.` reaches R3/2 at the angle δ to the axis; no-groove step for `9,3 x 74 R`. Verify: tests fail for the expected reason.
- [x] 4.2 Implement the outer profile and rim logic in `js/geometry.js` to pass 4.1. Verify: `npm test -- tests/geometry.test.js` passes.
- [x] 4.3 Add tests then code for the shoulder and neck: `223 Rem.` shoulder included angle 46° (tan(α/2) matches the points within 1e-6), fillets r1Min and r2 tangent to both lines, a straight case when alpha, L1 or L2 is missing, and the missing-P2 note. Verify: tests pass.
- [x] 4.4 Add tests then code for the bullet: base, cylinder end, meplat and the ogive radius formula for `223 Rem.` (base 39.0, cylinder end 46.36, meplat 1.27); quarter-ellipse rounded nose; flat cone; semi-wadcutter; heeled `22 Long Rifle`. Verify: tests pass.
- [x] 4.5 Add tests then code for the section: tb and tn values (`223 Rem.`: tn 0.365, tb 0.6); solid head w (`223 Rem.`: 4.54); inner profile offsets; section polygon closed and with the pocket removed. Verify: tests pass.
- [x] 4.6 Add tests then code for missing-value notes: each missing value needed by a rule produces a note naming it, and no number is invented (for example a bottleneck with H1 removed). Verify: tests pass.

## 5. Drawing

- [x] 5.1 Write `tests/drawing.test.js` (failing first): for all 25 records, the SVG has accessible name "<name> drawing", a viewBox in mm, an outside view and a section, a dash-dot centre line; dimension lines with arrowheads and extension lines exist for L3, L6, R1, R, P1 and each published optional symbol; labels read "<symbol> <value>" with tolerance when published; no label overlaps another label or the outline; the title block contains name, table, revision date, "Dimensions in mm" and scale. Then implement `js/drawing.js` (candidate label placement, dimension rows, diameter columns, α arc, title block). Verify: all drawing tests pass for the 25 records.
- [x] 5.2 Add a test that the drawing is scale-true: for `223 Rem.`, the SVG's L6 extension lines sit exactly 57.4 units apart and the 9,3 x 74 R is 96.5 units long. Verify: test passes.

## 6. App shell and views

- [x] 6.1 Write `tests/app.test.js` (jsdom, failing first): start page heading, one link per cartridge with exact name text, search and family controls labelled "Search" and "Family", count text, detail view heading, identity block, section tables with columns Symbol/Value/Unit, "Print" button, "All cartridges" link, "Cartridge not found" for unknown keys, filter survives a round trip. Then implement `index.html` and `js/app.js`. Verify: app tests pass.
- [x] 6.2 Verify `index.html` contains no external URL (`http`, `//` CDN, `@import`, `<link>` to remote). Add a test for it in `tests/app.test.js`. Verify: test passes.

## 7. Styling, dark mode and print

- [ ] 7.1 Write `styles/app.css`: dense, tabular technical styling; light and dark variables following `prefers-color-scheme`; responsive layout with horizontal scrolling for wide tables; drawing scales to container width. Verify: visual check in a headless browser at 360 px and 1280 px, light and dark (screenshots).
- [x] 7.2 Add print styles: A4 portrait, black on white, no navigation/search/filter/buttons, two-column tables, footer "Source: C.I.P. TDCC, revised <date>". Verify: printing each of the 25 detail views to PDF gives one page.

## 8. Final verification

- [ ] 8.1 Run `npm test` and the full browser check: open `index.html` via `file://`, load every cartridge's detail route, check no console errors and no network requests. Verify: report the result with output.
- [x] 8.2 Run `openspec validate cartridge-reference-app` and fix any findings. Verify: validation passes.
- [ ] 8.3 Review the diff for the brief's rules (data unchanged, no runtime dependencies, no network requests, symbols and formats as specified). Verify: a written checklist against the specs, with any deviations listed in the final report.

## Status notes

- 7.1, 8.1 and 8.3 are open. The start page could not be screenshotted or browser-tested here: the sandboxed headless Chromium crashes when it paints a native `<select>`. The start page is covered by jsdom tests against the real `index.html`. The detail views were checked in the browser (all 25: drawing present, no console errors, no network requests, one A4 page when printed, no overflow at 360 px).

## Workflow follow-up

- Archive the change with `openspec archive cartridge-reference-app` once the user accepts the result.
