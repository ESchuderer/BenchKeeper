'use strict';
// DOM tests run against the real index.html, loaded from disk the way a browser opens file://.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM, VirtualConsole } = require('jsdom');
const records = require('../js/data.js');

const ROOT = path.join(__dirname, '..');

async function loadApp() {
  const virtualConsole = new VirtualConsole();
  virtualConsole.on('jsdomError', (error) => {
    if (!/Not implemented/.test(String(error.message))) console.error(error);
  });
  const dom = await JSDOM.fromFile(path.join(ROOT, 'index.html'), {
    runScripts: 'dangerously',
    resources: 'usable',
    pretendToBeVisual: true,
    virtualConsole
  });
  await new Promise((resolve, reject) => {
    if (dom.window.document.readyState === 'complete') return resolve();
    dom.window.addEventListener('load', resolve);
    dom.window.addEventListener('error', reject);
  });
  // The app starts in a task after load; wait until it has rendered the start page.
  for (let i = 0; i < 200 && !dom.window.document.querySelector('.catalogue'); i++) {
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
  return dom;
}

function go(dom, hash) {
  dom.window.location.hash = hash;
  dom.window.dispatchEvent(new dom.window.HashChangeEvent('hashchange'));
}

function typeSearch(dom, text) {
  const input = dom.window.document.querySelector('input[type="search"]');
  input.value = text;
  input.dispatchEvent(new dom.window.Event('input', { bubbles: true }));
}

function chooseFamily(dom, family) {
  const select = dom.window.document.querySelector('select');
  select.value = family;
  select.dispatchEvent(new dom.window.Event('change', { bubbles: true }));
}

function listedNames(dom) {
  return [...dom.window.document.querySelectorAll('.cartridge-list a')].map((a) => a.textContent);
}

function countText(dom) {
  return dom.window.document.querySelector('.count').textContent;
}

function labelled(dom, text) {
  const doc = dom.window.document;
  const label = [...doc.querySelectorAll('label')].find((l) => l.textContent.trim() === text);
  assert.ok(label, `no label "${text}"`);
  return doc.getElementById(label.htmlFor);
}

// ---- start page -------------------------------------------------------------------

test('the start page has the heading "Cartridges" and one link per cartridge with its exact name', async () => {
  const dom = await loadApp();
  const doc = dom.window.document;
  const h1 = doc.querySelector('h1');
  assert.equal(h1.textContent, 'Cartridges');
  assert.deepEqual(listedNames(dom), records.map((r) => r.name));
  for (const link of doc.querySelectorAll('.cartridge-list a')) {
    assert.ok(link.getAttribute('href').startsWith('#/cartridge/'));
  }
  assert.equal(countText(dom), '25 cartridges');
});

test('each row shows the family and the case length L3 with its unit', async () => {
  const dom = await loadApp();
  const row = [...dom.window.document.querySelectorAll('.cartridge-list li')]
    .find((li) => li.querySelector('a').textContent === '223 Rem.');
  assert.ok(row.textContent.includes('rimless'));
  assert.ok(row.textContent.includes('L3 44.7 mm'), row.textContent);
});

test('the Search field filters by name and alternative names', async () => {
  const dom = await loadApp();
  assert.ok(labelled(dom, 'Search').getAttribute('type') === 'search');
  typeSearch(dom, '7,62 x 51');
  assert.deepEqual(listedNames(dom), ['308 Win.']);
  assert.equal(countText(dom), '1 cartridge');
});

test('the Family select filters by family and offers All, rimless, rimmed, belted, pistol, rimfire', async () => {
  const dom = await loadApp();
  const select = labelled(dom, 'Family');
  assert.deepEqual([...select.options].map((o) => o.value), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  chooseFamily(dom, 'pistol');
  const pistols = records.filter((r) => r.family === 'pistol').map((r) => r.name);
  assert.deepEqual(listedNames(dom), pistols);
  assert.equal(countText(dom), `${pistols.length} cartridges`);
});

test('search and family combine', async () => {
  const dom = await loadApp();
  chooseFamily(dom, 'rimfire');
  typeSearch(dom, '22');
  assert.deepEqual(listedNames(dom), ['22 Long Rifle', '22 Win. Mag. R.F.']);
});

// ---- detail view ----------------------------------------------------------------------

test('the detail view shows the identity block, the drawing, and the value tables', async () => {
  const dom = await loadApp();
  go(dom, '#/cartridge/308_win');
  const doc = dom.window.document;
  assert.equal(doc.querySelector('h1').textContent, '308 Win.');
  const text = doc.querySelector('.detail').textContent;
  assert.ok(text.includes('308 Winchester'), 'alternative names');
  assert.ok(text.includes('rimless'), 'family');
  assert.ok(text.includes('rifle'), 'category');
  assert.ok(text.includes('lr'), 'primer type');
  assert.ok(text.includes('1984-06-14'), 'published');
  assert.ok(text.includes('2008-09-23'), 'revised');
  assert.ok(text.includes('Transducer'), 'pressure method');
  assert.ok(text.includes('56 gr H2O'), 'water capacity');
  const kwk = [...doc.querySelectorAll('.detail a')].find((a) => a.textContent === 'kwk');
  assert.equal(kwk.getAttribute('href'), 'http://kwk.us/cases.html');
  assert.ok(doc.querySelector('svg[aria-label="308 Win. drawing"]'), 'drawing');
});

test('value tables have Symbol, Value and Unit columns, grouped by section', async () => {
  const dom = await loadApp();
  go(dom, '#/cartridge/223_rem');
  const doc = dom.window.document;
  const tables = [...doc.querySelectorAll('.detail table')];
  assert.ok(tables.length >= 14, `tables: ${tables.length}`);
  for (const table of tables) {
    const heads = [...table.querySelectorAll('thead th')].map((th) => th.textContent);
    assert.deepEqual(heads, ['Symbol', 'Value', 'Unit']);
  }
  const headings = [...doc.querySelectorAll('.detail h3')].map((h) => h.textContent);
  assert.ok(headings.includes('Lengths') && headings.includes('Grooves'));
});

test('a tolerance appears in its value cell and never as its own row', async () => {
  const dom = await loadApp();
  go(dom, '#/cartridge/223_rem');
  const doc = dom.window.document;
  const rows = [...doc.querySelectorAll('.detail tbody tr')];
  const l1 = rows.find((tr) => tr.children[0].textContent === 'L1');
  assert.equal(l1.children[1].textContent, '36.52 -0.2');
  assert.ok(!rows.some((tr) => /Tol/.test(tr.children[0].textContent)));
});

test('the detail view has a Print button and an "All cartridges" link', async () => {
  const dom = await loadApp();
  go(dom, '#/cartridge/223_rem');
  const doc = dom.window.document;
  const button = [...doc.querySelectorAll('button')].find((b) => b.textContent === 'Print');
  assert.ok(button, 'Print button');
  const back = [...doc.querySelectorAll('a')].find((a) => a.textContent === 'All cartridges');
  assert.equal(back.getAttribute('href'), '#/');
});

test('Print calls the browser print dialog', async () => {
  const dom = await loadApp();
  let printed = 0;
  dom.window.print = () => { printed++; };
  go(dom, '#/cartridge/223_rem');
  const button = [...dom.window.document.querySelectorAll('button')].find((b) => b.textContent === 'Print');
  button.click();
  assert.equal(printed, 1);
});

test('each cartridge has its own address that opens its detail view on load', async () => {
  const dom = await loadApp();
  for (const record of records) {
    go(dom, `#/cartridge/${record.key}`);
    assert.equal(dom.window.document.querySelector('h1').textContent, record.name);
  }
});

test('an unknown key shows "Cartridge not found" with a link back', async () => {
  const dom = await loadApp();
  go(dom, '#/cartridge/unknown');
  const doc = dom.window.document;
  assert.ok(doc.body.textContent.includes('Cartridge not found'));
  assert.ok([...doc.querySelectorAll('a')].some((a) => a.textContent === 'All cartridges'));
});

test('returning to the list keeps the search text and family filter', async () => {
  const dom = await loadApp();
  chooseFamily(dom, 'rimfire');
  typeSearch(dom, '22');
  go(dom, '#/cartridge/22_long_rifle');
  go(dom, '#/');
  assert.equal(labelled(dom, 'Search').value, '22');
  assert.equal(labelled(dom, 'Family').value, 'rimfire');
  assert.deepEqual(listedNames(dom), ['22 Long Rifle', '22 Win. Mag. R.F.']);
});

test('the page title names the cartridge', async () => {
  const dom = await loadApp();
  go(dom, '#/cartridge/9_mm_luger');
  assert.ok(dom.window.document.title.startsWith('9 mm Luger'), dom.window.document.title);
});

// ---- self-containment --------------------------------------------------------------

test('index.html loads only local files: no CDN, font, network or module scripts', () => {
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  assert.ok(!/https?:\/\//.test(html), 'no absolute URLs in index.html');
  assert.ok(!/type="module"/.test(html), 'no module scripts (they fail from file://)');
  for (const file of ['styles/app.css', 'js/app.js']) {
    const text = fs.readFileSync(path.join(ROOT, file), 'utf8');
    assert.ok(!/@import|https?:\/\/|fetch\(|XMLHttpRequest/.test(text), `${file} makes network requests`);
  }
});
