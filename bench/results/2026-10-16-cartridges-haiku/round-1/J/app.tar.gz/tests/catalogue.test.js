'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../js/catalogue.js');
const records = require('../js/data.js');

const names = (list) => list.map((r) => r.name);

test('normalise ignores case, whitespace, hyphens, dots and commas', () => {
  assert.equal(C.normalise('7,62 x 51'), '762x51');
  assert.equal(C.normalise('7.62x51'), '762x51');
  assert.equal(C.normalise('30-06 Spring.'), '3006spring');
  assert.equal(C.normalise('  22 LR '), '22lr');
});

test('a search for an alternative name finds the cartridge', () => {
  const found = C.filterRecords(records, { query: '7,62 x 51', family: 'All' });
  assert.deepEqual(names(found), ['308 Win.']);
});

test('the same cartridge is found by 7.62x51 and by 762x51', () => {
  assert.deepEqual(names(C.filterRecords(records, { query: '7.62x51', family: 'All' })), ['308 Win.']);
  assert.deepEqual(names(C.filterRecords(records, { query: '762x51', family: 'All' })), ['308 Win.']);
});

test('a search matches names as well as alternative names', () => {
  assert.deepEqual(names(C.filterRecords(records, { query: '44 mag', family: 'All' })), ['44 Rem. Mag.']);
});

test('an empty search with family All lists every cartridge', () => {
  assert.equal(C.filterRecords(records, { query: '', family: 'All' }).length, 25);
});

test('a family filter lists only that family', () => {
  const pistols = C.filterRecords(records, { query: '', family: 'pistol' });
  assert.ok(pistols.length > 0);
  assert.ok(pistols.every((r) => r.family === 'pistol'));
  assert.equal(pistols.length, records.filter((r) => r.family === 'pistol').length);
});

test('family and search combine with AND', () => {
  const found = C.filterRecords(records, { query: '38', family: 'pistol' });
  assert.deepEqual(names(found), ['38 Special']);
});

test('a search that matches nothing lists nothing', () => {
  assert.deepEqual(C.filterRecords(records, { query: 'zzz', family: 'All' }), []);
});

test('the count line reads "1 cartridge" for one and "<n> cartridges" otherwise', () => {
  assert.equal(C.countLabel(1), '1 cartridge');
  assert.equal(C.countLabel(0), '0 cartridges');
  assert.equal(C.countLabel(25), '25 cartridges');
});

test('the family options are All, rimless, rimmed, belted, pistol and rimfire', () => {
  assert.deepEqual(C.FAMILY_OPTIONS, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('routes: the list is at #/ and a cartridge is at #/cartridge/<key>', () => {
  assert.deepEqual(C.parseRoute(''), { view: 'list' });
  assert.deepEqual(C.parseRoute('#'), { view: 'list' });
  assert.deepEqual(C.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(C.parseRoute('#/cartridge/223_rem'), { view: 'detail', key: '223_rem' });
  assert.deepEqual(C.parseRoute('#/cartridge/unknown'), { view: 'detail', key: 'unknown' });
});

test('an unknown path falls back to the list', () => {
  assert.deepEqual(C.parseRoute('#/something/else'), { view: 'list' });
});

test('routeFor builds a bookmarkable address that parseRoute reads back', () => {
  const hash = C.routeFor('6_5_creedmoor');
  assert.equal(hash, '#/cartridge/6_5_creedmoor');
  assert.deepEqual(C.parseRoute(hash), { view: 'detail', key: '6_5_creedmoor' });
});

test('findRecord returns the record for a key or undefined', () => {
  assert.equal(C.findRecord(records, '308_win').name, '308 Win.');
  assert.equal(C.findRecord(records, 'nope'), undefined);
});
