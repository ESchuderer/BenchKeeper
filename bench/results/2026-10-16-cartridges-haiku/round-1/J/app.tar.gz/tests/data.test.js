'use strict';
// Data fidelity: js/data.js must hold exactly the supplied records.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const lines = fs.readFileSync(path.join(ROOT, 'data', 'cartridges.jsonl'), 'utf8')
  .split('\n')
  .filter((line) => line.trim() !== '');
const sourceRecords = lines.map((line) => JSON.parse(line));
const embedded = require(path.join(ROOT, 'js', 'data.js'));

test('the supplied data file holds 25 records, one per line', () => {
  assert.equal(lines.length, 25);
});

test('the embedded data equals the supplied records, field for field', () => {
  assert.deepStrictEqual(embedded, sourceRecords);
});

test('every record has a unique key and a name', () => {
  const keys = embedded.map((r) => r.key);
  assert.equal(new Set(keys).size, 25);
  for (const record of embedded) {
    assert.equal(typeof record.name, 'string');
    assert.ok(record.name.length > 0, `empty name for ${record.key}`);
  }
});

test('every family is one of the five families or pistol', () => {
  const allowed = new Set(['rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  for (const record of embedded) {
    assert.ok(allowed.has(record.family), `${record.key}: ${record.family}`);
  }
});

test('every record has the cartridge and chamber sections the app reads', () => {
  for (const record of embedded) {
    assert.ok(record.cartridge && record.cartridge.caseHead, record.key);
    assert.ok(record.cartridge.lengths && record.cartridge.lengths.L3 !== undefined, record.key);
    assert.ok(record.chamber && record.chamber.powderChamber, record.key);
  }
});
