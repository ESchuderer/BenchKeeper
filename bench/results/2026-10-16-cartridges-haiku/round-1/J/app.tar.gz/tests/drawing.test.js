'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../js/drawing.js');
const G = require('../js/geometry.js');
const records = require('../js/data.js');

const byKey = (key) => records.find((r) => r.key === key);
const models = new Map(records.map((r) => [r.key, D.build(r)]));
const model = (key) => models.get(key);

function boxesOverlap(a, b) {
  return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
}

function segmentHitsBox(seg, box, pad) {
  const [x1, y1, x2, y2] = seg;
  const steps = Math.max(2, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 0.2));
  for (let i = 0; i <= steps; i++) {
    const x = x1 + ((x2 - x1) * i) / steps;
    const y = y1 + ((y2 - y1) * i) / steps;
    if (x > box.x0 - pad && x < box.x1 + pad && y > box.y0 - pad && y < box.y1 + pad) return true;
  }
  return false;
}

// ---- every drawing -----------------------------------------------------------

test('every supplied record produces a drawing', () => {
  for (const record of records) {
    const m = model(record.key);
    assert.equal(m.drawable, true, record.key);
    assert.ok(m.svg.startsWith('<svg'), record.key);
  }
});

test('the SVG has the accessible name "<name> drawing" (escaped for markup)', () => {
  for (const record of records) {
    const label = D.escapeXml(`${record.name} drawing`);
    assert.ok(model(record.key).svg.includes(`aria-label="${label}"`), record.key);
  }
});

test('the viewBox is in millimetres and is not empty', () => {
  for (const record of records) {
    const [x, y, w, h] = model(record.key).viewBox;
    assert.ok(w > 0 && h > 0, record.key);
    assert.ok(Number.isFinite(x) && Number.isFinite(y), record.key);
  }
});

test('every drawing has an outside view, a hatched section and a dash-dot centre line', () => {
  for (const record of records) {
    const svg = model(record.key).svg;
    assert.ok(svg.includes('class="outline"'), `${record.key}: outside view`);
    assert.ok(svg.includes('class="section-wall"'), `${record.key}: section walls`);
    assert.ok(svg.includes('url(#hatch-'), `${record.key}: hatching`);
    assert.ok(/class="centre-line"[^>]*stroke-dasharray="[0-9.]+ [0-9.]+ [0-9.]+ [0-9.]+"/.test(svg), `${record.key}: dash-dot`);
  }
});

test('no two labels overlap each other, in any drawing', () => {
  for (const record of records) {
    const labels = model(record.key).labels;
    for (let i = 0; i < labels.length; i++) {
      for (let j = i + 1; j < labels.length; j++) {
        assert.ok(!boxesOverlap(labels[i].box, labels[j].box),
          `${record.key}: "${labels[i].text}" overlaps "${labels[j].text}"`);
      }
    }
  }
});

test('no label overlaps the outline (or any dimension line), in any drawing', () => {
  for (const record of records) {
    const m = model(record.key);
    for (const label of m.labels) {
      for (const seg of m.obstacles) {
        assert.ok(!segmentHitsBox(seg, label.box, 0.3),
          `${record.key}: "${label.text}" touches ${JSON.stringify(seg.map((v) => +v.toFixed(2)))}`);
      }
    }
  }
});

test('the title block names the cartridge, its C.I.P. table, revision date, units and scale', () => {
  const svg = model('22_long_rifle').svg;
  assert.ok(svg.includes('22 Long Rifle'), 'name');
  assert.ok(svg.includes('C.I.P. table V'), 'table');
  assert.ok(svg.includes('2024-05-14'), 'revision date');
  assert.ok(svg.includes('Dimensions in mm'), 'units');
  assert.ok(svg.includes('Scale 1:1'), 'scale');
});

// ---- required dimensions ------------------------------------------------------------

const REQUIRED = ['L3', 'L6', 'R1', 'R', 'P1'];

test('required dimensions L3, L6, R1, R and P1 are present with arrowheads and extension lines', () => {
  for (const record of records) {
    const m = model(record.key);
    for (const symbol of REQUIRED) {
      const dim = m.dims.find((d) => d.symbol === symbol);
      assert.ok(dim, `${record.key}: ${symbol} missing`);
      assert.equal(dim.arrows, 2, `${record.key}: ${symbol} arrowheads`);
      assert.ok(dim.extensions >= 1, `${record.key}: ${symbol} extension lines`);
    }
  }
});

test('optional dimensions appear exactly where the value is published', () => {
  for (const record of records) {
    const m = model(record.key);
    const present = new Set(m.dims.map((d) => d.symbol));
    const c = record.cartridge;
    const expectOptional = {
      P2: c.powderChamber.P2 !== undefined && G.analyse(record).bottleneck,
      H1: c.collar.H1 !== undefined && G.analyse(record).bottleneck,
      H2: true,
      G1: true,
      L1: c.lengths.L1 !== undefined && G.analyse(record).bottleneck,
      L2: c.lengths.L2 !== undefined && G.analyse(record).bottleneck,
      E1: c.caseHead.E1 !== undefined && G.analyse(record).groove,
      'α': (c.junctionCone || {}).alpha !== undefined && G.analyse(record).bottleneck,
    };
    for (const [symbol, expected] of Object.entries(expectOptional)) {
      assert.equal(present.has(symbol), expected, `${record.key}: ${symbol}`);
    }
  }
});

test('labels read "<symbol> <value>" and carry their tolerance when published', () => {
  const m = model('223_rem');
  const texts = m.labels.map((l) => l.text);
  assert.ok(texts.includes('L3 44.7'), texts.join(' | '));
  assert.ok(texts.includes('L1 36.52 -0.2'), texts.join(' | '));
  assert.ok(texts.includes('α 46°'), texts.join(' | '));
  assert.ok(texts.includes('R1 9.6'), texts.join(' | '));
});

test('a length dimension is true to scale: L6 of 223 Rem. is 57.4 units from the head face', () => {
  const dim = model('223_rem').dims.find((d) => d.symbol === 'L6');
  assert.ok(Math.abs(dim.to[0] - dim.from[0] - 57.4) < 1e-9, `span ${dim.to[0] - dim.from[0]}`);
});

test('9,3 x 74 R, the longest case, spans 96.5 units for L6', () => {
  const dim = model('9_3_x_74_r').dims.find((d) => d.symbol === 'L6');
  assert.ok(Math.abs(dim.to[0] - dim.from[0] - 96.5) < 1e-9);
});

// ---- notes for missing values -----------------------------------------------------

test('a missing value is named in the notes and the drawing still renders', () => {
  const r = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete r.cartridge.powderChamber.P2;
  const m = D.build(r);
  assert.equal(m.drawable, true);
  assert.ok(m.notes.some((n) => /P2/.test(n)), m.notes.join('; '));
  assert.ok(!m.dims.some((d) => d.symbol === 'P2'), 'no P2 dimension without P2');
});

test('a drawing with missing essentials is not drawn and says which value is missing', () => {
  const r = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete r.cartridge.lengths.L6;
  const m = D.build(r);
  assert.equal(m.drawable, false);
  assert.ok(m.notes.some((n) => /L6/.test(n)));
  assert.equal(m.svg, undefined);
});

test('a complete record has no drawing notes', () => {
  for (const record of records) {
    assert.deepEqual(model(record.key).notes, [], record.key);
  }
});
