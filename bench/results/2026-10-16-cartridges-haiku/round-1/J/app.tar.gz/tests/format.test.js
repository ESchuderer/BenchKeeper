'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../js/format.js');
const records = require('../js/data.js');

const byKey = (key) => records.find((r) => r.key === key);

test('numbers are shown as published: no thousands separator, shortest digits', () => {
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(4150.0), '4150');
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(9.0), '9');
  assert.equal(F.formatNumber(-0.2), '-0.2');
});

test('a tolerance is appended to its value with a space; positive gets a plus', () => {
  assert.equal(F.formatValue(39.62, -0.2), '39.62 -0.2');
  assert.equal(F.formatValue(1.0, 0.1), '1 +0.1');
  assert.equal(F.formatValue(44.7, undefined), '44.7');
});

test('plain angles show degrees with the degree sign', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(35.0), '35°');
  assert.equal(F.formatAngle(46.5), '46.5°');
});

test('structured angles show degrees, minutes and seconds with two-digit parts', () => {
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(F.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
});

test('symbols are the field name except for the brief\'s mapping', () => {
  const expected = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
    E1: 'E1',
    R1: 'R1',
    EE: 'EE',
    Q: 'Q',
    i: 'i',
  };
  for (const [field, symbol] of Object.entries(expected)) {
    assert.equal(F.symbolFor(field), symbol, field);
  }
});

test('units: bar for pressures, J, g, mm², dash for counts and angles, mm otherwise', () => {
  assert.equal(F.unitFor('Pmax', 'pressures'), 'bar');
  assert.equal(F.unitFor('PK', 'pressures'), 'bar');
  assert.equal(F.unitFor('PE', 'pressures'), 'bar');
  assert.equal(F.unitFor('EE', 'pressures'), 'J');
  assert.equal(F.unitFor('M', 'pressures'), 'g');
  assert.equal(F.unitFor('Q', 'grooves'), 'mm²');
  assert.equal(F.unitFor('N', 'grooves'), '—');
  assert.equal(F.unitFor('alpha', 'junctionCone'), '—');
  assert.equal(F.unitFor('i', 'rifling'), '—');
  assert.equal(F.unitFor('L3', 'lengths'), 'mm');
  assert.equal(F.unitFor('b', 'grooves'), 'mm');
});

test('cartridge sections keep the published groups in order, with empty groups omitted', () => {
  const sections = F.buildSections(byKey('223_rem'));
  assert.deepEqual(sections.cartridge.map((s) => s.title), [
    'Case head', 'Collar', 'Junction cone', 'Lengths', 'Misc', 'Powder chamber', 'Pressures', 'Projectile',
  ]);
  const chamberTitles = F.buildSections(byKey('223_rem')).chamber.map((s) => s.title);
  assert.deepEqual(chamberTitles, [
    'Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling',
  ]);
});

test('an empty junction cone produces no section', () => {
  const titles = F.buildSections(byKey('9_mm_luger')).cartridge.map((s) => s.title);
  assert.ok(!titles.includes('Junction cone'));
  const chamberTitles = F.buildSections(byKey('9_mm_luger')).chamber.map((s) => s.title);
  assert.ok(!chamberTitles.includes('Junction cone'));
});

test('a tolerance sits in its value cell and produces no row', () => {
  const lengths = F.buildSections(byKey('223_rem')).cartridge.find((s) => s.title === 'Lengths');
  const l1 = lengths.rows.find((row) => row.symbol === 'L1');
  assert.equal(l1.value, '36.52 -0.2');
  assert.equal(l1.unit, 'mm');
  assert.ok(!lengths.rows.some((row) => /Tol/.test(row.symbol) || /Tol/.test(row.field)));
});

test('rows carry symbol, value and unit for the table columns', () => {
  const head = F.buildSections(byKey('223_rem')).cartridge.find((s) => s.title === 'Case head');
  const beta = head.rows.find((row) => row.field === 'beta');
  assert.deepEqual(beta, { field: 'beta', symbol: 'β', value: '35°', unit: '—' });
  const eMin = head.rows.find((row) => row.field === 'eMin');
  assert.equal(eMin.symbol, 'e min');
  assert.equal(eMin.value, '0.76');
});

test('the rifling twist angle as an object shows minutes and seconds', () => {
  const rifling = F.buildSections(byKey('223_rem')).chamber.find((s) => s.title === 'Rifling');
  const i = rifling.rows.find((row) => row.field === 'i');
  assert.equal(i.value, '3°10\'36"');
});

test('the count N shows a dash unit and no tolerance', () => {
  const grooves = F.buildSections(byKey('223_rem')).chamber.find((s) => s.title === 'Grooves');
  const n = grooves.rows.find((row) => row.field === 'N');
  assert.deepEqual({ value: n.value, unit: n.unit }, { value: '6', unit: '—' });
});

test('water capacity is shown with its unit, note and source link', () => {
  const capacity = F.formatCapacity(byKey('308_win'));
  assert.equal(capacity.value, '56 gr H2O');
  assert.equal(capacity.note, 'Lapua brass measures 55.8 (lapua-308)');
  assert.equal(capacity.source, 'kwk');
  assert.equal(capacity.url, 'http://kwk.us/cases.html');
});

test('water capacity is omitted when none is published', () => {
  assert.equal(F.formatCapacity({ annotations: {} }), null);
});
