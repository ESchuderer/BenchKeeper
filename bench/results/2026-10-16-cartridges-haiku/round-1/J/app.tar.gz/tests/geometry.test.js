'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../js/geometry.js');
const records = require('../js/data.js');

const byKey = (key) => records.find((r) => r.key === key);
const close = (actual, expected, tol = 1e-3, msg = '') =>
  assert.ok(Math.abs(actual - expected) <= tol, `${msg} expected ${expected}, got ${actual}`);
const hasPoint = (points, z, r, tol = 1e-3) =>
  points.some((p) => Math.abs(p[0] - z) <= tol && Math.abs(p[1] - r) <= tol);

// ---- rim type (rule 1) -------------------------------------------------------

test('rim type: belted and rimfire come from the family', () => {
  assert.equal(G.analyse(byKey('300_win_mag')).rimType, 'belted');
  assert.equal(G.analyse(byKey('22_long_rifle')).rimType, 'rimfire');
});

test('rim type: otherwise R1/P1 decides rimmed, rebated or rimless', () => {
  assert.equal(G.analyse(byKey('38_special')).rimType, 'rimmed');   // 11.18 / 9.63 = 1.16
  assert.equal(G.analyse(byKey('9_mm_luger')).rimType, 'rimless');  // 9.96 / 9.93 = 1.003
  assert.equal(G.analyse(byKey('223_rem')).rimType, 'rimless');     // 9.6 / 9.58
  assert.equal(G.rimTypeOf(10, 12), 'rebated');                     // 10 / 12 = 0.83
  assert.equal(G.rimTypeOf(12, 11), 'rimmed');                      // 1.09
  assert.equal(G.rimTypeOf(11, 11), 'rimless');
});

// ---- pocket (rule 8) ---------------------------------------------------------

test('primer pocket: diameter and depth follow the primer type', () => {
  assert.deepEqual(G.pocketFor('sp'), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(G.pocketFor('spm'), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(G.pocketFor('sr'), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(G.pocketFor('lp'), { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(G.pocketFor('lpm'), { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(G.pocketFor('lr'), { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(G.pocketFor('lrm'), { diameter: 5.33, depth: 3.3 });
  assert.equal(G.pocketFor('rimfire'), null);
  assert.equal(G.pocketFor(undefined), null);
});

// ---- head, chamfer and rim (rules 2 and 3) -------------------------------------

test('223 Rem.: the head chamfer runs from the head face to (R1/2, f)', () => {
  const a = G.analyse(byKey('223_rem'));
  // (r, z) = (R1/2 - f·tan β, 0) -> (R1/2, f): in (z, r) that is (0, 4.8 - 0.3151) -> (0.45, 4.8)
  close(a.outer[1][1], 4.8 - 0.45 * Math.tan(35 * Math.PI / 180), 1e-6, 'chamfer start radius');
  assert.deepEqual(a.outer[1][0], 0);
  assert.ok(hasPoint(a.outer, 0.45, 4.8), 'chamfer top at z = f');
  assert.ok(hasPoint(a.outer, 1.14, 4.8), 'rim edge up to z = R');
});

test('rimless without beta and f: square corner from (R1/2, 0) up to (R1/2, R)', () => {
  const r = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete r.cartridge.caseHead.beta;
  delete r.cartridge.caseHead.f;
  const a = G.analyse(r);
  assert.ok(hasPoint(a.outer, 0, 4.8), 'square corner at the head face');
  assert.ok(hasPoint(a.outer, 1.14, 4.8), 'rim edge up to R');
  assert.ok(!a.outer.some((p) => Math.abs(p[0] - 0.45) < 1e-9), 'no chamfer top');
});

test('223 Rem.: groove from (R1/2, R) in to (E1/2, R), along the floor, then a ramp to (P1/2, E)', () => {
  const a = G.analyse(byKey('223_rem'));
  assert.ok(hasPoint(a.outer, 1.14, 4.215), 'groove starts at R, r = E1/2 = 4.215');
  assert.ok(hasPoint(a.outer, 1.9, 4.215), 'floor ends at R + eMin = 1.9');
  assert.ok(hasPoint(a.outer, 3.13, 4.79), 'ramp meets the body at E, r = P1/2 = 4.79');
});

test('300 Win. Mag. (belted): the ramp leaves the floor at δ to the axis and reaches R3/2', () => {
  const a = G.analyse(byKey('300_win_mag'));
  // floor end (z 2.21, r 6.035); belt r = 6.755; dz = 0.72 / tan 35° = 1.0282
  const zRamp = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  close(zRamp, 3.2382, 1e-3, 'ramp end');
  assert.ok(hasPoint(a.outer, zRamp, 13.51 / 2), 'ramp reaches the belt');
  assert.ok(hasPoint(a.outer, 5.59, 13.51 / 2), 'belt continues to z = E');
  assert.ok(hasPoint(a.outer, 5.59, 13.03 / 2), 'then steps in to P1/2 at E');
  assert.ok(a.notes.length === 0, 'no notes for a complete belted case');
});

test('9,3 x 74 R has no E or E1: the rim steps in from (R1/2, R) to (P1/2, R)', () => {
  const a = G.analyse(byKey('9_3_x_74_r'));
  assert.equal(a.groove, false);
  assert.ok(hasPoint(a.outer, 1.4, 13.35 / 2), 'rim top');
  assert.ok(hasPoint(a.outer, 1.4, 11.9 / 2), 'step in to P1/2 at R');
});

test('22 Long Rifle (rimfire): half-round rim of radius min(R/2, (R1-P1)/2) with outer point at R1/2', () => {
  const a = G.analyse(byKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2); // 0.545
  assert.ok(hasPoint(a.outer, rho, 7.06 / 2), 'outermost point of the half-round at R1/2, z = rho');
  assert.ok(hasPoint(a.outer, 2 * rho, 7.06 / 2 - rho), 'half-round ends at z = 2*rho');
  assert.equal(a.rimType, 'rimfire');
  assert.equal(a.pocket, null);
});

// ---- shoulder and neck (rule 4 and 5) ----------------------------------------

test('223 Rem.: the body runs from P1/2 to (P2/2, L1) and the shoulder to (H1/2, L2)', () => {
  const a = G.analyse(byKey('223_rem'));
  const body = a.outer.filter((p) => p[0] > 3.2 && p[0] < 35);
  for (const p of body) close(p[1], 4.79 - (4.79 - 4.5) * (p[0] - 3.13) / (36.52 - 3.13), 1e-6, 'body taper');
  assert.deepEqual(a.outer[a.outer.length - 1], [44.7, 3.215]);
  assert.equal(a.bottleneck, true);
});

test('223 Rem.: the included shoulder angle is 46°, the line lying at α/2 to the axis', () => {
  const a = G.analyse(byKey('223_rem'));
  const halfAngle = Math.atan2(4.5 - 3.215, 39.55 - 36.52);
  close(2 * halfAngle * 180 / Math.PI, 46, 0.6, 'included angle from the published points');
  assert.equal(a.values.alpha, 46);
});

test('223 Rem.: body-side corner is rounded with r1 min and neck-side corner with r2', () => {
  const a = G.analyse(byKey('223_rem'));
  // The rounded corners add points that are NOT the sharp corners themselves.
  const sharpShoulderStart = a.outer.some((p) => Math.abs(p[0] - 36.52) < 1e-9 && Math.abs(p[1] - 4.5) < 1e-9);
  assert.equal(sharpShoulderStart, false, 'the sharp corner is replaced by a fillet');
  assert.ok(a.outer.length > 20, 'the fillets add sampled points');
});

test('a case without alpha, L1 or L2 is straight: the body runs to (H2/2, L3)', () => {
  const a = G.analyse(byKey('9_mm_luger'));
  assert.equal(a.bottleneck, false);
  const last = a.outer[a.outer.length - 1];
  assert.ok(Math.abs(last[0] - 19.15) < 1e-9 && Math.abs(last[1] - 9.65 / 2) < 1e-9);
});

test('a bottleneck case missing P2 draws the body without taper and says so', () => {
  const r = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete r.cartridge.powderChamber.P2;
  const a = G.analyse(r);
  assert.ok(a.notes.some((n) => /P2/.test(n)), a.notes.join('; '));
  // the straight body stays at P1/2 up to the body-side fillet, whose tangent point is at r = P1/2
  assert.ok(a.outer.some((p) => p[0] > 36.2 && p[0] < 36.52 && Math.abs(p[1] - 4.79) < 1e-9), 'body reaches P1/2 before the fillet');
  assert.ok(a.outer.every((p) => !(p[0] > 3.2 && p[0] < 36.2) || Math.abs(p[1] - 4.79) < 1e-9), 'no taper');
});

// ---- bullet (rule 7) -----------------------------------------------------------

test('223 Rem. pointy bullet: base 39.0, cylinder ends 46.36, meplat 1.27', () => {
  const b = G.analyse(byKey('223_rem')).bullet;
  close(b.s, 5.7, 1e-9, 's');
  close(b.zb, 39.0, 1e-9, 'base');
  close(b.zc, 46.36, 1e-6, 'cylinder end');
  close(b.m, 1.27, 1e-9, 'meplat');
  assert.equal(b.shape, 'pointy');
});

test('223 Rem. pointy ogive: tangent to the cylinder, meeting the meplat at the tip', () => {
  const b = G.analyse(byKey('223_rem')).bullet;
  const nose = b.exposed.filter((p) => p[0] >= b.zc - 1e-9);
  const start = nose[0];
  const tip = b.exposed[b.exposed.length - 1];
  close(start[0], 46.36, 1e-6, 'nose starts at zc');
  close(start[1], 2.85, 1e-6, 'nose starts on the bullet radius');
  close(tip[0], 57.4, 1e-6, 'tip at L6');
  close(tip[1], 0.635, 1e-6, 'tip radius is the meplat radius');
  // every sampled nose point is at distance rho from the centre (z = zc, r = G1/2 - rho)
  const d = 2.85 - 0.635;
  const rho = (d * d + 11.04 * 11.04) / (2 * d);
  const centre = [46.36, 2.85 - rho];
  for (const p of nose) {
    const dist = Math.hypot(p[0] - centre[0], p[1] - centre[1]);
    close(dist, rho, 1e-6, 'point on the ogive arc');
  }
});

test('9 mm Luger (rounded pistol): seated 0.4·G1, cylinder to 0.65 of the bullet length, meplat 0.15·G1', () => {
  const b = G.analyse(byKey('9_mm_luger')).bullet;
  close(b.s, 0.4 * 9.03, 1e-9, 's');
  close(b.zb, 19.15 - 0.4 * 9.03, 1e-9, 'base');
  const lb = 29.69 - b.zb;
  close(b.zc, b.zb + 0.65 * lb, 1e-9, 'cylinder end');
  close(b.m, 0.15 * 9.03, 1e-9, 'meplat');
  assert.equal(b.shape, 'rounded');
});

test('semi_wadcutter (357 Magnum): seated 0.6·G1, cylinder to 0.78, straight cone to 0.6·G1 meplat', () => {
  const b = G.analyse(byKey('357_magnum')).bullet;
  close(b.s, 0.6 * 9.12, 1e-9, 's');
  close(b.m, 0.6 * 9.12, 1e-9, 'meplat');
  const lb = 40.39 - b.zb;
  close(b.zc, b.zb + 0.78 * lb, 1e-9, 'cylinder end');
});

test('flat pistol (40 S&W): seated 0.4·G1, cylinder to 0.70, meplat 0.55·G1', () => {
  const b = G.analyse(byKey('40_s_w')).bullet;
  close(b.s, 0.4 * 10.17, 1e-9, 's');
  close(b.m, 0.55 * 10.17, 1e-9, 'meplat');
  const lb = 28.83 - b.zb;
  close(b.zc, b.zb + 0.70 * lb, 1e-9, 'cylinder end');
});

test('heeled case (22 Long Rifle): exposed bullet has the case outside diameter, the heel H2 - 2·tb', () => {
  const a = G.analyse(byKey('22_long_rifle'));
  assert.equal(a.heeled, true);
  close(a.bullet.exposedRadius, 5.72 / 2, 1e-9, 'exposed radius');
  close(a.bullet.heelRadius, 5.72 / 2 - a.walls.tb, 1e-9, 'heel radius');
});

test('a non-heeled case has no heel', () => {
  assert.equal(G.analyse(byKey('223_rem')).heeled, false);
});

// ---- section walls and head (rule 8) ------------------------------------------

test('223 Rem.: tn = 0.365, tb = 0.6, solid head to w = 4.54', () => {
  const a = G.analyse(byKey('223_rem'));
  close(a.walls.tn, 0.365, 1e-9, 'tn');
  close(a.walls.tb, 0.6, 1e-9, 'tb');
  close(a.walls.w, 4.54, 1e-9, 'w');
});

test('body wall is limited to 0.35·P1/2 on small cases', () => {
  const a = G.analyse(byKey('22_long_rifle'));
  close(a.walls.tb, Math.min(Math.max(1.3 * a.walls.tn, 0.6), 0.35 * 5.74 / 2), 1e-9, 'tb limited');
});

test('section polygon is closed, starts at the pocket edge and includes the solid head', () => {
  const a = G.analyse(byKey('223_rem'));
  const poly = a.sectionPolygon;
  assert.ok(poly.length > 10);
  assert.deepEqual(poly[0], [0, 4.45 / 2], 'starts at the pocket edge on the head face');
  assert.ok(poly.some((p) => Math.abs(p[0] - 4.54) < 1e-9 && Math.abs(p[1]) < 1e-9), 'floor of the solid head at w on the axis');
  assert.ok(poly.some((p) => Math.abs(p[0] - 3.04) < 1e-9 && Math.abs(p[1]) < 1e-9), 'pocket bottom on the axis');
});

test('the inner profile is the outer offset by tb along the body and tn along the neck', () => {
  const a = G.analyse(byKey('223_rem'));
  const mouthInner = a.inner[a.inner.length - 1];
  close(mouthInner[0], 44.7, 1e-9, 'inner ends at the mouth');
  close(mouthInner[1], 3.215 - 0.365, 1e-9, 'inner mouth radius H2/2 - tn');
  const bodyInner = a.inner.find((p) => Math.abs(p[0] - 36.52) < 1e-9);
  close(bodyInner[1], 4.5 - 0.6, 1e-9, 'inner shoulder start P2/2 - tb');
});

test('the primer pocket for 223 Rem. is 4.45 across and 3.04 deep', () => {
  const a = G.analyse(byKey('223_rem'));
  assert.deepEqual(a.pocket, { diameter: 4.45, depth: 3.04 });
});

// ---- missing values (rule 9) ---------------------------------------------------

test('missing values produce notes naming the value, never a guessed number', () => {
  const r = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete r.chamber; // not needed by the drawing; must not change the outline
  delete r.cartridge.caseHead.E1;
  const a = G.analyse(r);
  assert.equal(a.groove, false, 'no groove without E1');
  assert.ok(a.notes.some((n) => /E1/.test(n)), a.notes.join('; '));
});

test('the outline of every record is defined and monotonic in z', () => {
  for (const record of records) {
    const a = G.analyse(record);
    assert.equal(a.drawable, true, record.key);
    let last = -Infinity;
    for (const [z] of a.outer) {
      assert.ok(z >= last - 1e-9, `${record.key}: z goes backwards`);
      last = z;
    }
    assert.ok(Math.abs(a.outer[a.outer.length - 1][0] - record.cartridge.lengths.L3) < 1e-9, record.key);
  }
});

test('every record has its bullet tip at L6 and its nose start after the mouth', () => {
  for (const record of records) {
    const a = G.analyse(record);
    assert.ok(Math.abs(a.bullet.tipZ - record.cartridge.lengths.L6) < 1e-9, record.key);
    assert.ok(a.bullet.zc >= record.cartridge.lengths.L3 - 1e-9, `${record.key}: nose starts inside the case`);
  }
});

test('every supplied record is complete enough to draw without a note', () => {
  for (const record of records) {
    assert.deepEqual(G.analyse(record).notes, [], record.key);
  }
});
