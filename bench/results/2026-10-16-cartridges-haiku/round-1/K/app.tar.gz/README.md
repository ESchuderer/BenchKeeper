# Cartridge reference

A static reference of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers,
modelled on the OpenBallistics cartridge database. Plain HTML, CSS and JavaScript:
no framework, no build step, no runtime dependencies and no network requests.

## Use

Open `index.html` in Chromium (it works from `file://`), or serve the folder with any
static file server. Each cartridge has its own address (`#/cartridge/<key>`) that can be
bookmarked and survives a reload. The Print button prints one A4 portrait page.

## Layout

- `index.html`, `styles.css`: the page and its styles (light and dark, phone and print).
- `data/cartridges.js`: the 25 records, as given (OpenBallistics, MIT, commit e83db43).
- `src/`: pure functions for formatting, search, routing, geometry, label layout,
  the SVG drawing and the detail view, plus `app.js` which wires them to the page.
- `test/`: unit tests (`npm test`). `e2e/`: browser tests (`npm run test:e2e`).
- `openspec/`: the specification and the design, tasks and decisions for this app.

## Development

```sh
npm install          # dev dependency: playwright-core (browser tests only)
npm test             # unit tests, Node 22 built-in test runner
npm run test:e2e     # browser tests; set CHROME_PATH to a Chromium binary
```

The browser tests are skipped when no browser can be launched.
