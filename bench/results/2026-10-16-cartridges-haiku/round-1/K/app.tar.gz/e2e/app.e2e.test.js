'use strict';
// End-to-end checks in Chromium, loading index.html from file://.
// Set CHROME_PATH to a Chromium binary (and CHROME_LIB_PATH if it needs extra
// shared libraries). Without a browser the suite is skipped, not failed.
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

let chromium;
try {
  ({ chromium } = require('playwright-core'));
} catch {
  chromium = null;
}

const ROOT = path.resolve(__dirname, '..');
const APP_URL = pathToFileURL(path.join(ROOT, 'index.html')).href;

async function launch() {
  if (!chromium) return null;
  const options = { headless: true };
  if (process.env.CHROME_PATH) {
    options.executablePath = process.env.CHROME_PATH;
    options.args = ['--no-sandbox', '--disable-gpu', '--no-zygote', '--single-process'];
    if (process.env.CHROME_LIB_PATH) {
      options.env = { ...process.env, LD_LIBRARY_PATH: process.env.CHROME_LIB_PATH };
    }
  }
  try {
    return await chromium.launch(options);
  } catch (error) {
    console.warn(`Skipping browser tests: ${String(error).split('\n')[0]}`);
    return null;
  }
}

async function withPage(options, run) {
  const browser = await launch();
  if (!browser) return 'skip';
  try {
    const context = await browser.newContext(options);
    const page = await context.newPage();
    const external = [];
    page.on('request', (request) => {
      if (!request.url().startsWith('file:') && !request.url().startsWith('data:')) external.push(request.url());
    });
    const errors = [];
    page.on('pageerror', (error) => errors.push(String(error)));
    await page.goto(APP_URL);
    await run(page, { external, errors });
  } finally {
    await browser.close();
  }
  return 'done';
}

test('the start page lists 25 cartridges with the heading and count', async (t) => {
  const outcome = await withPage({}, async (page, { errors }) => {
    assert.equal(await page.locator('h1').textContent(), 'Cartridges');
    assert.equal(await page.locator('.cartridge-item').count(), 25);
    assert.equal(await page.locator('#count').textContent(), '25 cartridges');
    assert.deepEqual(errors, []);
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('search finds 308 Win. by its alternative name and keeps focus while typing', async (t) => {
  const outcome = await withPage({}, async (page) => {
    const input = page.locator('#search-input');
    await input.click();
    await page.keyboard.type('7,62 x 51');
    assert.equal(await input.inputValue(), '7,62 x 51');
    assert.equal(await input.evaluate((el) => el === document.activeElement), true);
    assert.deepEqual(await page.locator('.cartridge-item a').allTextContents(), ['308 Win.']);
    assert.equal(await page.locator('#count').textContent(), '1 cartridge');
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('the family select filters the list and combines with search', async (t) => {
  const outcome = await withPage({}, async (page) => {
    await page.locator('#family-select').selectOption('rimfire');
    assert.equal(await page.locator('#count').textContent(), '3 cartridges');
    await page.locator('#search-input').fill('17');
    assert.deepEqual(await page.locator('.cartridge-item a').allTextContents(), ['17 HMR']);
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('a name opens its detail view at a bookmarkable address that survives reload', async (t) => {
  const outcome = await withPage({}, async (page) => {
    await page.locator('.cartridge-item a', { hasText: /^223 Rem\.$/ }).click();
    await page.waitForFunction(() => location.hash === '#/cartridge/223_rem' && document.querySelector('h1')?.textContent === '223 Rem.');
    assert.match(page.url(), /#\/cartridge\/223_rem$/);
    await page.reload();
    assert.equal(await page.locator('h1').textContent(), '223 Rem.');
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.waitForFunction(() => document.querySelector('h1')?.textContent === 'Cartridges');
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('the detail view shows the drawing with its accessible name and the value tables', async (t) => {
  const outcome = await withPage({}, async (page) => {
    await page.goto(`${APP_URL}#/cartridge/308_win`);
    const drawing = page.getByRole('img', { name: '308 Win. drawing' });
    assert.equal(await drawing.count(), 1);
    assert.equal(await page.locator('.value-section h3', { hasText: 'Lengths' }).count(), 2);
    assert.equal(await page.locator('td.num', { hasText: '4150' }).count() > 0, true);
    assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('an unknown address says the cartridge is not found', async (t) => {
  const outcome = await withPage({}, async (page) => {
    await page.goto(`${APP_URL}#/cartridge/nope`);
    assert.equal(await page.locator('h1').textContent(), 'Cartridge not found');
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('the page makes no network requests beyond file:// assets', async (t) => {
  const outcome = await withPage({}, async (page, { external }) => {
    await page.goto(`${APP_URL}#/cartridge/9_3_x_74_r`);
    await page.waitForTimeout(200);
    assert.deepEqual(external, []);
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('on a 360 px phone the page does not scroll sideways', async (t) => {
  const outcome = await withPage({ viewport: { width: 360, height: 780 } }, async (page) => {
    for (const hash of ['', '#/cartridge/9_3_x_74_r', '#/cartridge/300_win_mag']) {
      await page.goto(`${APP_URL}${hash}`);
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      assert.ok(overflow <= 0, `${hash || 'list'} overflows by ${overflow}px`);
    }
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('printing a detail view produces one A4 portrait page', async (t) => {
  const outcome = await withPage({}, async (page) => {
    await page.goto(`${APP_URL}#/cartridge/9_3_x_74_r`);
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) ?? []).length;
    assert.equal(pages, 1, `printed pages: ${pages}`);
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('the printed page omits the navigation, the search and the buttons', async (t) => {
  const outcome = await withPage({}, async (page) => {
    await page.goto(`${APP_URL}#/cartridge/223_rem`);
    await page.emulateMedia({ media: 'print' });
    for (const selector of ['.controls', '.toolbar', '#print-button', '.site']) {
      const visible = await page.locator(selector).first().isVisible();
      assert.equal(visible, false, `${selector} is visible in print`);
    }
    assert.equal(await page.locator('.source').isVisible(), true);
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('dark system setting uses the dark palette', async (t) => {
  const outcome = await withPage({ colorScheme: 'dark' }, async (page) => {
    const background = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.notEqual(background, 'rgb(247, 246, 242)');
  });
  if (outcome === 'skip') t.skip('no browser');
});

test('every one of the 25 detail views prints on one A4 portrait page', async (t) => {
  const outcome = await withPage({}, async (page) => {
    const records = require(path.join(ROOT, 'data', 'cartridges.js'));
    const failures = [];
    for (const record of records) {
      await page.goto(`${APP_URL}#/cartridge/${encodeURIComponent(record.key)}`);
      await page.waitForFunction((name) => document.querySelector('h1')?.textContent === name, record.name);
      const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
      const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) ?? []).length;
      if (pages !== 1) failures.push(`${record.key}: ${pages} pages`);
    }
    assert.deepEqual(failures, []);
  });
  if (outcome === 'skip') t.skip('no browser');
});
