# Design

## Context

The project is empty apart from the OpenSpec scaffold and the git history. The app must run from `file://` in Chromium, so it cannot use `fetch` for data or ES module imports; scripts must be classic scripts. The behaviour is in `specs/`. See proposal.md for motivation.

## Goals / Non-Goals

**Goals:**
- Pure, testable functions for formatting, geometry and SVG/HTML output, so the rules can be checked in Node without a browser.
- A thin DOM layer that only routes hashes, binds the search and filter controls, and writes HTML strings into the page.
- Every geometry rule in `specs/cartridge-drawing` covered by a test with a value from a real record.

**Non-Goals:**
- Editing, adding or fetching data; unit conversion; a unit or tolerance model beyond display.
- Pixel-perfect printing across browsers; the target is Chromium and A4 portrait.
- Dimensioning features the data does not publish (no invented values).

## Decisions

**Layout of files.** `data/cartridges.js` sets one global array. `src/*.js` each wrap an IIFE that attaches its API to `globalThis.CIP` and sets `module.exports` when present, so the same file serves the browser and `node --test`. Alternatives: ES modules (blocked on `file://` by Chromium's CORS rules), a bundler (forbidden: no build step), and inlining everything into `index.html` (hard to test).

**Coordinates.** Geometry is computed in (z, r) with z along the axis from the head face and r the radius. The SVG maps z to x and r to −y for the upper half and +y for the lower section, so 1 user unit is 1 mm and the head is at the left. Alternative: compute directly in SVG space; rejected because the spec's rules are written in (z, r).

**Profiles.** The outer half-profile is an array of vertices, each tagged with a role (rim, groove, body, shoulder, neck, mouth, belt). Corners are rounded by sampling tangent arcs. The section polygon is built from the outer profile plus the inner profile, which offsets each vertex radially by its wall (tb, tn, or tb for heeled mouths). Alternative: offset the whole outline with a polygon library; rejected as a dependency, and radial offset is exact for these profiles.

**Bullet.** The bullet is built from the exposed radius (H2/2 when heeled, otherwise G1/2), the cylinder end, and the nose formulas in the spec. The seated part for the section uses G1/2, or H2/2 − tb when heeled.

**Labels.** Dimension geometry is fixed by rule. Labels are placed greedily from a short list of candidate positions per dimension (above, below, left, right of the dimension anchor), taking the first candidate that clears all placed labels, the extension and dimension lines, and the outline samples. Text width is estimated from the character count. Alternative: a force-directed or optimisation layout; rejected as more code than the 25 records need. A test asserts zero unresolved collisions for all 25 records.

**Units and symbols.** The unit table is explicit: mm for lengths and diameters, the units the brief names for pressures, energy, mass and groove area, and no unit for counts and for `S`, `u`, `Fe`, `b`, `h`, `s`, which the brief does not give a unit for. The Unit column is left empty for those rather than guessed.

**Routing and rendering.** The hash `#/cartridge/<key>` selects the detail view; `#/` or no hash selects the list. Rendering returns HTML strings with escaping, so the output is testable and the search input keeps focus because only the list container is replaced.

**Print.** `@media print` sets A4 portrait, hides the chrome, forces light colours, and lays the tables out in two columns (cartridge in the left, chamber in the right) to fit one page. Tables and drawing use physical units so the page fits.

## Risks / Trade-offs

- [Label overlap estimated by character width] → Use a conservative width of 0.62 em per character and a padding margin; check drawings visually in a browser if one is available.
- [Print may run to two pages] → Verify page count with a headless print if Chromium is available; otherwise tighten the table row height and report that the page count is unverified.
- [Unit ambiguity for S, u, Fe, b, h, s] → Leave the unit blank and say so in the final report; the data owner can supply the unit.
- [Phone-width legibility of labels at about 2.8 px/mm for the longest cartridges] → Labels are 3.2 mm font; the drawing scales with the container, so long cartridges are smaller on screen. Accepted, and noted.
- [Missing values make geometry partially undefined] → Each missing value is recorded in the drawing's notes and the feature is skipped; tests cover every record's note list.
