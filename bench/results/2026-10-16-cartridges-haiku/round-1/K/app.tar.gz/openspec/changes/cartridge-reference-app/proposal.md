# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick, offline reference for C.I.P. cartridge dimensions, pressures and drawings. The project has data for 25 cartridges (OpenBallistics records, MIT, commit e83db43) but no way to browse or read them. The app must work from disk with no server, no network and no build step, so the data can be checked and carried around as plain files.

## What Changes

- Add a static reference app at `index.html` with its own CSS and JavaScript. It opens from `file://` in Chromium and from any static file server.
- Add the 25 cartridge records as given, with no edits, additions or fetched data.
- Start page: heading, every cartridge with name link, family and case length L3, a name/alternative-name search, a family filter and a count.
- Detail view at its own hash address: identity block, all cartridge and chamber values grouped by section, and a scale-true 2D drawing with dimension lines.
- Drawing rules: the case half-profile is built from the record's values (rim type, head, extractor groove, body, shoulder, neck, bullet with nose shape, section walls, primer pocket). Missing values are omitted and named, never invented.
- Print: a Print button that produces one A4 portrait page in black on white.
- Light and dark colour schemes following the system setting; phone-width layout.
- **BREAKING**: none (new project).

## Capabilities

### New Capabilities

- `cartridge-catalog`: browsing, searching and filtering the cartridge list, and the hash routes that open a cartridge.
- `cartridge-detail`: the detail view's identity block, values tables, navigation and data-to-display formatting (units, tolerances, angles, symbols).
- `cartridge-drawing`: the inline SVG drawing geometry, dimensions, labels and title block.
- `cartridge-print`: the one-page A4 print layout.
- `reference-app-platform`: static delivery, no network, file:// operation, theming and responsive layout.

### Modified Capabilities

None. There are no existing specs.

## Impact

- New files: `index.html`, `styles.css`, `data/cartridges.js`, `src/*.js` (formatting, catalog, geometry, drawing, rendering, routing), `test/*.test.js`, `package.json` (scripts only; no runtime dependencies).
- Tests use the Node 22 built-in test runner; no runtime dependencies and no build step.
- Data: 25 records, unchanged, source OpenBallistics (MIT).
