# Spec Delta

## Purpose

Lets a reader find one of the 25 C.I.P. cartridges by name, alternative name or family, and open its detail view from a stable address.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" and one list entry per record in the data, in data order. Each entry SHALL show the family and the case length L3 with its tolerance and unit.

#### Scenario: Full list on load
- **WHEN** the start page is opened with no search or filter
- **THEN** all 25 cartridges are listed and the count text reads "25 cartridges"

#### Scenario: Entry content
- **WHEN** the entry for "308 Win." is shown
- **THEN** it shows the family "rimless" and the case length "51.18 mm"

### Requirement: Name links open the detail view
Each cartridge name SHALL be a link whose text is exactly the record's `name`. The link SHALL point to the detail address `#/cartridge/<key>` for that record.

#### Scenario: Link text and target
- **WHEN** the entry for "6,5 Creedmoor" is inspected
- **THEN** the link text is "6,5 Creedmoor" and its target is `#/cartridge/6_5_creedmoor`

### Requirement: Search filters by name and alternative names
A text field labelled "Search" SHALL filter the list as the user types. A match is a case-insensitive substring of the record's `name` or of any of its `alternativeNames`. Runs of whitespace in the query and in the compared text SHALL count as one space.

#### Scenario: Alternative name match
- **WHEN** the user types "7,62 x 51"
- **THEN** the list shows only "308 Win." and the count text reads "1 cartridge"

#### Scenario: No match
- **WHEN** the user types a query that matches no name or alternative name
- **THEN** the list is empty and the count text reads "0 cartridges"

#### Scenario: Focus is kept while typing
- **WHEN** the user types into the search field
- **THEN** the field keeps focus and its value; only the list and count change

### Requirement: Family select filters by family
A select labelled "Family" SHALL offer "All", "rimless", "rimmed", "belted", "pistol" and "rimfire". Choosing a family SHALL show only records of that family. The search and the family filter SHALL apply together.

#### Scenario: Family and search combined
- **WHEN** the family is "rimless" and the search is "308"
- **THEN** only "308 Win." is listed

#### Scenario: All families
- **WHEN** the family is "All"
- **THEN** the search alone decides which records are listed

### Requirement: Count text shows the number listed
The start page SHALL show the text "<n> cartridges" with the number of listed records, updated on every search or filter change. A count of one SHALL read "1 cartridge".

#### Scenario: Count after filter
- **WHEN** the family is "rimfire"
- **THEN** the count text reads "3 cartridges"

### Requirement: Detail address opens its cartridge and survives reload
Each cartridge SHALL have its own address `#/cartridge/<key>`. Opening that address, bookmarking it, or reloading the page SHALL show that cartridge's detail view. An unknown key SHALL show a "Cartridge not found" message with a link "All cartridges".

#### Scenario: Reload keeps the detail view
- **WHEN** the address `#/cartridge/223_rem` is loaded or reloaded
- **THEN** the detail view of "223 Rem." is shown

#### Scenario: Unknown key
- **WHEN** the address `#/cartridge/unknown` is loaded
- **THEN** the page shows "Cartridge not found" and a link "All cartridges" to the start page

### Requirement: Start address shows the list
The address without a cartridge key, `#/` or no hash, SHALL show the start page. The link "All cartridges" in a detail view SHALL return to it.

#### Scenario: Back to list
- **WHEN** the user activates the link "All cartridges" on a detail view
- **THEN** the start page is shown
