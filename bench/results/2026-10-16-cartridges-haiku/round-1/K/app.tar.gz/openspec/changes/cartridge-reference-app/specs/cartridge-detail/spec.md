# Spec Delta

## Purpose

Shows everything the data holds about one cartridge, in the names, units and tolerances a reloader or gunsmith expects to read.

## ADDED Requirements

### Requirement: Detail heading and identity block
The detail view SHALL have a level-one heading with the cartridge's `name`. It SHALL then show, in this order: alternative names, family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method, and the published water capacity. Each value SHALL be shown as published.

#### Scenario: Identity block for 308 Win.
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the heading is "308 Win." and the alternative names include "308 Winchester" and "7,62 x 51"

#### Scenario: No alternative names
- **WHEN** a record has no `alternativeNames`
- **THEN** the alternative names row shows "none"

### Requirement: Water capacity with source link
When a record has `publishedCapacity`, the detail view SHALL show `grH2O` with the unit "grH2O", the `source` as link text, linked to the record's `url`, and the `note` when present. When it has no `publishedCapacity`, it SHALL show "not published".

#### Scenario: Capacity with note
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the water capacity reads "56 grH2O", the source "kwk" links to "http://kwk.us/cases.html", and the note "Lapua brass measures 55.8 (lapua-308)" is shown

#### Scenario: No published capacity
- **WHEN** the detail view of "7 x 64" is shown
- **THEN** the water capacity reads "not published"

### Requirement: Values grouped by section in tables
All values of `cartridge` and of `chamber` SHALL appear in tables grouped by section (for example case head, collar, junction cone, lengths, powder chamber, rifling). Each table SHALL have the columns "Symbol", "Value" and "Unit". Every value of the record SHALL appear exactly once.

#### Scenario: Section tables
- **WHEN** the detail view of any cartridge is shown
- **THEN** the cartridge values appear in sections under a "Cartridge" heading and the chamber values under a "Chamber" heading, each table with the columns "Symbol", "Value" and "Unit"

### Requirement: Symbols use the published names
The Symbol column SHALL show the field name, except: `eMin` as "e min", `r1Min` as "r1 min", `r1Max` as "r1 max", `alpha` as "α", `alpha1` as "α1", `beta` as "β", `delta` as "δ", `deltaL` as "delta L", and `L3PlusG` as "L3 + G".

#### Scenario: Greek and renamed symbols
- **WHEN** the case head table of "223 Rem." is shown
- **THEN** the symbols include "β", "δ", "e min" and "E1"

### Requirement: Tolerances sit beside their value
A field `<X>Tol` SHALL NOT have a row of its own. Its value SHALL be shown in the Value column of the row for `<X>`, after the value of X, as in `39.62 -0.2`.

#### Scenario: Tolerance beside length
- **WHEN** the lengths table of "223 Rem." is shown
- **THEN** the row L1 has the value "36.52 -0.2" and the unit "mm", and there is no row named "L1Tol"

### Requirement: Value and unit formatting
Values SHALL use a decimal point and no thousands separator, as in "51.18" and "4150". The unit SHALL be in the Unit column: "mm" for lengths and diameters, "bar" for Pmax, PK and PE, "J" for EE, "g" for M and "mm²" for Q. Angles SHALL be shown in the Value column as degrees with a degree sign, such as "40°", or as `39°59'49"` when the record gives degrees, minutes and seconds. Counts (N) and fields the data gives no unit for SHALL have an empty Unit cell.

#### Scenario: Pressure in bar
- **WHEN** the pressures table of "308 Win." is shown
- **THEN** the Pmax row shows the value "4150" and the unit "bar"

#### Scenario: Angle in degrees, minutes and seconds
- **WHEN** a record's `alpha` is `{degrees: 50, minutes: 35, seconds: 2}`
- **THEN** its value is shown as `50°35'02"`

#### Scenario: Count has no unit
- **WHEN** the grooves table of "223 Rem." is shown
- **THEN** the N row shows the value "6" and an empty unit

### Requirement: Drawing and missing-value notes on the detail view
The detail view SHALL include the drawing of the cartridge (see cartridge-drawing) below the identity block. When the drawing omits any feature because a value is missing, the detail view SHALL list the omitted features and the missing values under the drawing.

#### Scenario: Missing value noted
- **WHEN** a record has no `r1Min` and a bottleneck shoulder
- **THEN** the note under the drawing names "r1 min" as not published

### Requirement: Print button and navigation
The detail view SHALL have a button labelled "Print" that opens the browser's print dialog, and a link labelled "All cartridges" to the start page. Navigation, search and the buttons SHALL NOT appear in the printed page.

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** the browser print dialog opens for the current detail view

### Requirement: Footer with source
The detail view SHALL end with a footer that names the source "C.I.P. TDCC" and the revised date of the record.

#### Scenario: Footer text
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2017-05-17"
