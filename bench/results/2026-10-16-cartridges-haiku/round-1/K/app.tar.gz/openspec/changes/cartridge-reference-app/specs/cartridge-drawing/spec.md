# Spec Delta

## Purpose

Gives a true-to-scale, computed 2D drawing of each cartridge with dimensioned values, so the geometry can be read and checked against the published numbers.

## ADDED Requirements

### Requirement: Inline SVG at true scale
The drawing SHALL be an inline SVG whose user unit is 1 mm, with the axis horizontal and the head on the left. Its accessible name SHALL be "<name> drawing". It SHALL scale to the width of the container, including a phone screen.

#### Scenario: Accessible name and scale
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** the SVG has the accessible name "223 Rem. drawing" and a viewBox whose unit is 1 mm

#### Scenario: Phone width
- **WHEN** the container is 360 CSS pixels wide
- **THEN** the SVG is drawn at that width with its height following the aspect ratio

### Requirement: Outside view above, section below
The upper half SHALL show the outside view of the case and the exposed bullet. The lower half SHALL show a section through the axis in which the cut case walls and solid head are hatched, and the bullet is outlined with its seated part inside the case. A dash-dot centre line SHALL lie on the axis.

#### Scenario: Seated bullet hidden outside
- **WHEN** the outside view is drawn
- **THEN** only the bullet part from the mouth (L3) to the tip (L6) appears in the upper half

#### Scenario: Section hatch
- **WHEN** the section is drawn
- **THEN** the case wall and the solid head are hatched and the primer pocket, when present, is open

### Requirement: Rim type from the record
The rim type SHALL be "belted" when the family is `belted`, "rimfire" when the family is `rimfire`. Otherwise it SHALL be "rimmed" when R1/P1 is at least 1.05, "rebated" when R1/P1 is below 0.98, and "rimless" in every other case.

#### Scenario: Rimmed 7 x 65 R
- **WHEN** the record "7 x 65 R" is drawn
- **THEN** its rim type is "rimmed"

#### Scenario: Belted and rimfire by family
- **WHEN** the family is "belted" or "rimfire"
- **THEN** the rim type is "belted" or "rimfire" regardless of the diameter ratio

### Requirement: Head face and rim edge
From the axis at the head face, the outline SHALL run outward along the head face. Where `beta` and `f` are published and `beta` is below 90°, the head face SHALL have a chamfer from `(R1/2 - min(f·tan β, R1/4))` to `(R1/2, f)`, then the rim cylinder to `z = R`. Otherwise the corner SHALL be square. For rimfire, the rim edge SHALL be a half-round of radius `min(R/2, (R1 - P1)/2)` whose outermost point lies at R1/2.

#### Scenario: Chamfered rim
- **WHEN** the head of "7 x 65 R" is drawn with beta 45° and f 0.3
- **THEN** the head face runs from the axis to the chamfer start at R1/2 − 0.3 and the chamfer ends at (R1/2, 0.3)

#### Scenario: Rimfire half-round
- **WHEN** the rimfire record "22 Long Rifle" is drawn
- **THEN** the rim edge is a half-round of radius 0.545 whose outermost point lies at R1/2

### Requirement: Extractor groove
Where `E` and `E1` are published, the outline SHALL step inward from the rim at `z = R` to diameter E1, run along the groove floor for `eMin`, and then ramp out to `(P1/2, E)`. For belted cases the ramp SHALL leave the floor at the angle δ to the axis until it reaches R3/2, follow the belt to `z = E`, then step in to P1/2. Without a groove the outline SHALL step from R1/2 at `z = R` to P1/2.

#### Scenario: Groove of 223 Rem.
- **WHEN** "223 Rem." is drawn
- **THEN** the floor is at diameter 8.43 from z = 1.14 to z = 1.90 and the ramp ends at (P1/2, 3.13)

#### Scenario: Belted groove
- **WHEN** "300 Win. Mag." is drawn
- **THEN** the outline follows the belt at R3/2 from the ramp end to z = 5.59 before stepping in to P1/2

### Requirement: Body, shoulder and neck
A bottleneck case with `alpha`, `L1`, `L2`, `H1` and `P2` published SHALL have a straight body from `(P1/2, body start)` to `(P2/2, L1)`, a straight shoulder through `(P2/2, L1)` and `(H1/2, L2)` with the included cone angle `alpha` (the line lies at alpha/2 to the axis), and a neck from `(H1/2, L2)` to `(H2/2, L3)`. Any other case SHALL have a straight body from `(P1/2, body start)` to `(H2/2, L3)`.

#### Scenario: Bottleneck shoulder angle
- **WHEN** "223 Rem." is drawn
- **THEN** the shoulder line through (4.50, 36.52) and (3.215, 39.55) lies at 23° to the axis, so its included angle is 46°

#### Scenario: Straight case
- **WHEN** "9 mm Luger" is drawn, which publishes no `L1` or `alpha`
- **THEN** the body runs straight from the body start to (H2/2, L3) and no shoulder is drawn

### Requirement: Rounded corners
Where `r1Min` is published, the body-side corner of the shoulder SHALL be rounded with radius `r1Min`. Where `r2` is published, the neck-side corner SHALL be rounded with radius `r2`. Each rounding SHALL be tangent to both adjoining lines.

#### Scenario: Shoulder corners
- **WHEN** "223 Rem." is drawn
- **THEN** the body-side corner has a tangent arc of radius 0.64 and the neck-side corner an arc of radius 2.54

### Requirement: Bullet geometry
The bullet SHALL run from the mouth to a tip at `z = L6`, with shank diameter `G1` and nose shape from `annotations.defaultBulletShape`. The seating depth below the mouth `s` SHALL be 1.0·G1 for pointy bullets, 0.8·G1 for rounded or flat rifle and rimfire bullets, 0.4·G1 for rounded or flat pistol bullets, and 0.6·G1 for semi_wadcutter bullets. The base SHALL be at `zb = L3 − s`.

#### Scenario: Pointy bullet of 223 Rem.
- **WHEN** "223 Rem." is drawn
- **THEN** the base is at z = 39.0 and the tip is at z = 57.4

#### Scenario: Nose shapes
- **WHEN** the nose is drawn
- **THEN** a pointy nose is a tangent ogive ending in a flat tip of diameter max(0.08·G1, 1.27); a rounded nose is a quarter ellipse ending in a tip of diameter 0.15·G1; a flat nose is a straight cone to 0.55·G1; a semi_wadcutter is a straight cone to 0.6·G1

#### Scenario: Cylinder length
- **WHEN** the cylinder is drawn
- **THEN** it runs from the base to zb + k·Lb, where k is 0.40 pointy, 0.55 rounded rifle or rimfire, 0.65 rounded pistol, 0.60 flat rifle, 0.70 flat pistol and 0.78 semi_wadcutter, and Lb = L6 − zb

### Requirement: Heeled bullets
When H2 − G1 is at most 0.015, the case is heeled: the exposed bullet SHALL have the diameter H2, and the seated heel SHALL have the diameter H2 − 2·tb inside the case.

#### Scenario: Heeled 22 Long Rifle
- **WHEN** "22 Long Rifle" is drawn
- **THEN** the exposed bullet diameter is 5.72 and the seated heel diameter is 5.72 − 2·tb

### Requirement: Section walls and solid head
The neck wall SHALL be tn = (H2 − G1)/2 and the body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2). For heeled cases the neck wall SHALL be tb. The inner line SHALL follow the outer body at tb, the neck at tn, and blend linearly across the shoulder. The solid head SHALL run from the head face to z = w, where w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, belt ramp end + tb on belted cases).

#### Scenario: Walls of 223 Rem.
- **WHEN** "223 Rem." is drawn
- **THEN** tn is 0.365, tb is 0.6, and w is 4.54

#### Scenario: Heeled neck wall
- **WHEN** "22 Long Rifle" is drawn
- **THEN** the mouth wall equals tb = 0.6

### Requirement: Primer pocket
Centrefire cases SHALL have a primer pocket open at the head face. Its diameter is 4.45 for primer types sp, spm and sr, and 5.33 for lp, lpm, lr and lrm. Its depth is 3.04 for sp, spm, sr, lp and lpm, and 3.3 for lr and lrm. Rimfire cases SHALL have no pocket.

#### Scenario: Large rifle primer
- **WHEN** "308 Win." (primer lr) is drawn
- **THEN** the pocket has diameter 5.33 and depth 3.3

### Requirement: Dimension lines and labels
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and, where published and drawable, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each label SHALL show the symbol and value, with the tolerance beside the value where one is published, for example "L3 51.18" or "L3 19.15 -0.25". Axial dimensions SHALL be measured from the head face at z = 0.

#### Scenario: Labelled length
- **WHEN** "223 Rem." is drawn
- **THEN** the L3 dimension line runs from z = 0 to z = 44.7 with the label "L3 44.7"

#### Scenario: Shoulder angle label
- **WHEN** "223 Rem." is drawn
- **THEN** the label "α 46°" is drawn next to the shoulder

#### Scenario: Labels do not collide
- **WHEN** any of the 25 cartridges is drawn
- **THEN** no two labels overlap, and no label overlaps the outline of the case or the bullet

### Requirement: Title block
The drawing SHALL have a title block with the cartridge name, the C.I.P. table and revision date, the rim type, the text "Dimensions in mm", and a scale bar of 10 mm.

#### Scenario: Title block of 308 Win.
- **WHEN** "308 Win." is drawn
- **THEN** the title block shows "308 Win.", "C.I.P. table I", "revised 2008-09-23" and "Dimensions in mm"

### Requirement: Missing values are named, never invented
If a value a rule needs is missing, the drawing SHALL omit that feature and report the missing value in the detail view. It SHALL NOT substitute a number for it.

#### Scenario: Pistol without shoulder values
- **WHEN** "38 Special" is drawn, which publishes no junction cone
- **THEN** no shoulder, neck or P2 dimension is drawn, the body runs straight to (H2/2, L3), and the detail view does not invent shoulder values
