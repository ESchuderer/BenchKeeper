# Spec Delta

## Purpose

Lets a reader print one cartridge's full reference sheet on a single A4 portrait page that is legible on paper.

## ADDED Requirements

### Requirement: One A4 portrait page
A printed detail view SHALL fit on one A4 portrait page, black on white. It SHALL contain a page header with the cartridge name, the drawing at the full printable width with every label legible, and the value tables.

#### Scenario: One page for a long record
- **WHEN** the detail view of "9,3 x 74 R" is printed
- **THEN** the output is a single A4 portrait page

#### Scenario: Black on white
- **WHEN** a detail view is printed in dark colour mode
- **THEN** the text and lines print in black on a white background

### Requirement: Print removes interface elements
The print output SHALL NOT contain the navigation, the search and filter controls, the Print button, or the "All cartridges" link.

#### Scenario: No controls on paper
- **WHEN** the detail view of "223 Rem." is printed
- **THEN** no button, link to the list or form control appears in the output

### Requirement: Print footer with source
The printed page SHALL end with a footer that gives the source "C.I.P. TDCC" and the revised date.

#### Scenario: Footer on paper
- **WHEN** the detail view of "7,62 x 39" is printed
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2013-05-22"

### Requirement: Print button opens the print dialog
The Print button SHALL open the browser's print dialog for the current detail view. It SHALL NOT print any other cartridge.

#### Scenario: Print current view
- **WHEN** the user activates "Print" on the detail view of "7 x 64"
- **THEN** the print dialog opens with the detail view of "7 x 64"
