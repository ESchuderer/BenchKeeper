# Spec Delta

## Purpose

Defines how the reference app is delivered and runs: as plain files that open directly from disk, with no network access, no build step and no server code.

## ADDED Requirements

### Requirement: Opens from disk and from a static server
`index.html` in the project root, with its CSS and JavaScript files, SHALL work fully when opened directly from disk in Chromium (`file://`) and when the folder is served by any static file server. No server-side code SHALL be required.

#### Scenario: Opened from file
- **WHEN** `index.html` is opened from disk in Chromium without a web server
- **THEN** the start page lists 25 cartridges and every detail view opens

#### Scenario: Served statically
- **WHEN** the folder is served by a static file server
- **THEN** the behaviour is identical to the file-based case

### Requirement: No network requests
The app SHALL make no network requests at run time: no CDN, web font, analytics or remote script. All assets SHALL be files in the project.

#### Scenario: No external references
- **WHEN** the files of the app are searched for "http://" or "https://" references that load a resource
- **THEN** none are found, except the text of the source links to the publisher's own pages in the data

### Requirement: No runtime dependencies or build step
The app SHALL use plain HTML, CSS and JavaScript with no framework and no build step. Development tools MAY be npm dev dependencies; the app itself SHALL NOT need them.

#### Scenario: Run without install
- **WHEN** the app is opened from disk after cloning the project, without running npm
- **THEN** it works

### Requirement: Light and dark colour schemes
The on-screen app SHALL follow the system colour-scheme setting, with light and dark palettes. Text SHALL meet a contrast ratio of at least 4.5:1 in both.

#### Scenario: Dark system setting
- **WHEN** the system prefers a dark colour scheme
- **THEN** the page and drawing use the dark palette

### Requirement: Phone layout
The layout SHALL be usable on a phone-width screen of 360 CSS pixels: no horizontal page scrolling, the drawing scaled to the width, and wide tables scrollable within their own container.

#### Scenario: Phone width
- **WHEN** the page is viewed at 360 CSS pixels wide
- **THEN** the page does not scroll horizontally, and the drawing fits the width

### Requirement: English interface
All interface text SHALL be in English.

#### Scenario: Labels in English
- **WHEN** any view is shown
- **THEN** its labels and messages are in English
