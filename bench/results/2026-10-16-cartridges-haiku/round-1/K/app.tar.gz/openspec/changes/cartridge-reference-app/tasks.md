# Tasks

## 1. Project scaffold and data

- [x] 1.1 Add `package.json` (private, no runtime dependencies, `test` and `test:e2e` scripts, `playwright-core` as the only dev dependency) and verify `npm test` runs
- [x] 1.2 Add `data/cartridges.js` with the 25 records as given, and verify `test/data.test.js`: count 25, unique keys, golden fields from the brief for every record

## 2. Formatting and value tables

- [x] 2.1 Add `src/format.js` (numbers, angles, tolerances, unit and symbol tables) and verify `test/format.test.js` against the spec examples (`40°`, `50°35'02"`, `36.52 -0.2`, `4150`, `α1`, `delta L`, `L3 + G`)
- [x] 2.2 Add the section model (grouped rows of symbol, value and unit) and verify in `test/format.test.js` that every value appears once, tolerances get no row, and N has an empty unit

## 3. Catalog and routing

- [x] 3.1 Add `src/catalog.js` (search over names and alternative names, family filter, count text, escaped list HTML) and verify `test/catalog.test.js`: "7,62 x 51" finds only 308 Win., rimfire count is 3, whitespace folding, `&` escaped
- [x] 3.2 Add `src/router.js` and verify `test/catalog.test.js` for `#/`, empty hash, detail keys, an unknown key and percent-encoded keys

## 4. Geometry

- [x] 4.1 Add `src/geometry.js` rim classification and verify `test/geometry.test.js`: 7 x 65 R rimmed, 22 Long Rifle rimfire, belted family overrides the ratio
- [x] 4.2 Add head face, chamfer, rimfire half-round, extractor groove and belted ramp, and verify `test/geometry.test.js` with 223 Rem. (floor 8.43 from z 1.14 to 1.90, ramp to (P1/2, 3.13)) and 300 Win. Mag. (belt to z 5.59)
- [x] 4.3 Add body, shoulder, neck, straight-case handling and tangent fillets, and verify `test/geometry.test.js`: 223 Rem. shoulder at 23° (included 46°), fillet arcs present, 9 mm Luger straight
- [x] 4.4 Add the bullet (seating, cylinder end, pointy, rounded, flat and semi_wadcutter noses, heeled exposure), and verify `test/geometry.test.js`: 223 Rem. base 39.0 and tip 57.4, quarter-ellipse tip for rounded, 22 Long Rifle heeled exposure 5.72
- [x] 4.5 Add section walls, inner profile, solid head depth w, primer pocket and missing-value notes, and verify `test/geometry.test.js`: 223 Rem. tn 0.365, tb 0.6, w 4.54; 308 Win. pocket 5.33 by 3.3; rimfire has no pocket; a missing r1 min is named in notes; every record builds with a finite outline

## 5. Drawing

- [x] 5.1 Add `src/drawing.js` outline, section hatch, bullet and dash-dot centre line as SVG with a viewBox in mm, and verify `test/drawing.test.js`: accessible name, outside view above the axis, section hatched, centre line on the axis
- [x] 5.2 Add dimension lines, extension lines, arrowheads and label placement (`src/layout.js`), and verify `test/labels.test.js` for all 25 records: no label overlaps another, none touches a drawn line, all inside the viewBox, none unresolved
- [x] 5.3 Add the title block (name, C.I.P. table, revision, rim type, "Dimensions in mm", 10 mm scale bar), and verify `test/drawing.test.js` for the 308 Win. text and that the block fits the viewBox for all 25 records

## 6. Detail view and app shell

- [x] 6.1 Add `src/detail.js` (identity block, water capacity with source link, section tables, drawing with notes, Print and "All cartridges" controls, footer), and verify `test/detail.test.js`
- [x] 6.2 Add `index.html`, `styles.css` (light and dark, phone layout, print rules) and `src/app.js` (hash routing, search and family bindings, Print button), and verify `e2e/app.e2e.test.js`: start page, search focus, family filter, detail reload, not-found, phone width without horizontal scroll, no network requests, dark palette

## 7. Print

- [x] 7.1 Make the print rules produce one A4 portrait page, and verify `e2e/app.e2e.test.js` that all 25 detail views print to one page and that navigation, search and buttons are hidden in print

## 8. Integration checks

- [x] 8.1 Run `npm test` and `openspec validate cartridge-reference-app --strict`, and verify both pass
- [x] 8.2 Run `npm run test:e2e` against headless Chromium loading `index.html` from `file://`, and verify the browser scenarios pass (the server-hosted case is not separately run; the page uses no server features)

## Workflow follow-up

- Review the implementation with the code-reviewer agent and address CRITICAL and HIGH findings.
- Archive the change with `openspec archive cartridge-reference-app` once the review is settled.
