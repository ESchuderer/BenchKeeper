/**
 * Browser glue: routes the hash to the start page or a detail view, binds the
 * search and family controls, and handles Print. All markup comes from the
 * pure modules, which escape their output.
 */
(function (root) {
  'use strict';

  const { records } = root.CIP;
  const { detail, drawing, router } = root.CIP;

  const view = document.getElementById('view');
  const criteria = { query: '', family: 'all' };

  /** Count text and list only; the controls keep focus while typing. */
  function renderResults() {
    const results = detail.resultsHtml(records, criteria);
    document.getElementById('count').textContent = results.count;
    document.getElementById('results').innerHTML = results.list;
  }

  function showList() {
    document.title = 'Cartridges';
    view.innerHTML = detail.listShellHtml();
    document.getElementById('search-input').value = criteria.query;
    document.getElementById('family-select').value = criteria.family;
    renderResults();
  }

  /** @param {string} key */
  function showDetail(key) {
    const record = records.find((candidate) => candidate.key === key);
    if (!record) {
      document.title = 'Cartridge not found · Cartridges';
      view.innerHTML = detail.notFoundHtml(key);
      return;
    }
    document.title = `${record.name} · Cartridges`;
    view.innerHTML = detail.detailHtml(record, drawing.buildDrawing(record));
  }

  function render() {
    const route = router.parseRoute(window.location.hash);
    if (route.view === 'list') showList();
    else showDetail(route.key);
    window.scrollTo(0, 0);
  }

  view.addEventListener('input', (event) => {
    if (event.target.id !== 'search-input') return;
    criteria.query = event.target.value;
    renderResults();
  });

  view.addEventListener('change', (event) => {
    if (event.target.id !== 'family-select') return;
    criteria.family = event.target.value;
    renderResults();
  });

  view.addEventListener('submit', (event) => event.preventDefault());

  view.addEventListener('click', (event) => {
    if (event.target.id === 'print-button') window.print();
  });

  window.addEventListener('hashchange', render);
  render();
})(typeof globalThis !== 'undefined' ? globalThis : window);
