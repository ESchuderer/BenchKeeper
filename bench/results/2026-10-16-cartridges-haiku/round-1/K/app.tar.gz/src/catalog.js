/**
 * Start page: search over name and alternative names, family filter, count
 * text and the list markup. Pure functions; the caller supplies the records.
 */
(function (root) {
  'use strict';

  const format = typeof module === 'object' && module.exports ? require('./format.js') : root.CIP.format;

  /** Families offered by the select, in display order. */
  const FAMILIES = Object.freeze(['rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  const ALL_FAMILIES = 'all';

  /**
   * Case-fold and collapse whitespace, so "7,62  x 51" matches "7,62 x 51".
   * @param {string} text
   */
  function normalise(text) {
    return String(text).replace(/\s+/g, ' ').trim().toLowerCase();
  }

  /**
   * @param {{name: string, alternativeNames?: string[]}} record
   * @param {string} query
   */
  function matchesQuery(record, query) {
    const needle = normalise(query);
    if (needle === '') return true;
    const names = [record.name, ...(record.alternativeNames ?? [])];
    return names.some((name) => normalise(name).includes(needle));
  }

  /**
   * @param {object[]} records
   * @param {{query?: string, family?: string}} [criteria]
   */
  function filterRecords(records, criteria = {}) {
    const family = criteria.family ?? ALL_FAMILIES;
    return records.filter((record) => {
      const familyOk = family === ALL_FAMILIES || record.family === family;
      return familyOk && matchesQuery(record, criteria.query ?? '');
    });
  }

  /** @param {number} count */
  function countText(count) {
    return count === 1 ? '1 cartridge' : `${count} cartridges`;
  }

  /**
   * Link target for a cartridge's detail view.
   * @param {string} key
   */
  function detailHref(key) {
    return `#/cartridge/${encodeURIComponent(key)}`;
  }

  /**
   * One list entry: name link, family and case length L3 with tolerance.
   * @param {object} record
   */
  function listItemHtml(record) {
    const esc = format.escapeHtml;
    const l3 = record.cartridge.lengths.L3;
    const l3Tol = record.cartridge.lengths.L3Tol;
    const l3Text = l3Tol === undefined ? `${l3} mm` : `${l3} ${l3Tol} mm`;
    return [
      '<li class="cartridge-item">',
      `<a href="${esc(detailHref(record.key))}">${esc(record.name)}</a>`,
      `<span class="meta">${esc(record.family)}</span>`,
      `<span class="meta">L3 <span class="num">${esc(l3Text)}</span></span>`,
      '</li>',
    ].join('');
  }

  /** @param {object[]} records */
  function listHtml(records) {
    if (records.length === 0) return '<p class="empty">No cartridge matches the search.</p>';
    return `<ul class="cartridge-list">${records.map(listItemHtml).join('')}</ul>`;
  }

  const api = Object.freeze({
    FAMILIES,
    ALL_FAMILIES,
    normalise,
    matchesQuery,
    filterRecords,
    countText,
    detailHref,
    listItemHtml,
    listHtml,
  });

  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP.catalog = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
