/**
 * HTML for the start page's controls and results, the detail view and the
 * not-found message. Returns escaped markup strings; no DOM access.
 */
(function (root) {
  'use strict';

  const isNode = typeof module === 'object' && module.exports;
  const format = isNode ? require('./format.js') : root.CIP.format;
  const catalog = isNode ? require('./catalog.js') : root.CIP.catalog;
  const drawingModule = isNode ? require('./drawing.js') : root.CIP.drawing;
  const router = isNode ? require('./router.js') : root.CIP.router;

  const esc = format.escapeHtml;
  const FAMILY_LABELS = Object.freeze({ all: 'All', rimless: 'rimless', rimmed: 'rimmed', belted: 'belted', pistol: 'pistol', rimfire: 'rimfire' });

  /** Start page shell: heading, search, family select, count and results area. */
  function listShellHtml() {
    const options = [catalog.ALL_FAMILIES, ...catalog.FAMILIES]
      .map((family) => `<option value="${esc(family)}">${esc(FAMILY_LABELS[family])}</option>`)
      .join('');
    return [
      '<h1>Cartridges</h1>',
      '<form class="controls" role="search">',
      '<label for="search-input">Search</label>',
      '<input id="search-input" type="search" autocomplete="off" spellcheck="false" placeholder="Name or alternative name">',
      '<label for="family-select">Family</label>',
      `<select id="family-select">${options}</select>`,
      '</form>',
      '<p class="count" id="count" aria-live="polite"></p>',
      '<div id="results"></div>',
    ].join('');
  }

  /** Count text and list for the current criteria. */
  function resultsHtml(records, criteria) {
    const listed = catalog.filterRecords(records, criteria);
    return { count: catalog.countText(listed.length), list: catalog.listHtml(listed) };
  }

  /** Identity block rows, in the order the spec gives. */
  function identityRows(record) {
    const annotations = record.annotations ?? {};
    const alternatives = record.alternativeNames?.length ? record.alternativeNames.join(', ') : 'none';
    const capacity = annotations.publishedCapacity;
    let capacityHtml = 'not published';
    if (capacity) {
      const source = `<a href="${esc(capacity.url)}" rel="noopener">${esc(capacity.source)}</a>`;
      const note = capacity.note ? ` · ${esc(capacity.note)}` : '';
      capacityHtml = `<span class="num">${esc(format.formatNumber(capacity.grH2O))} grH2O</span> · source ${source}${note}`;
    }
    return [
      ['Alternative names', esc(alternatives)],
      ['Family', esc(record.family)],
      ['Category', esc(annotations.category ?? '')],
      ['Primer type', esc(annotations.primerType ?? '')],
      ['C.I.P. table', esc(record.tab)],
      ['Country', esc(record.country)],
      ['Published', `<span class="num">${esc(record.published)}</span>`],
      ['Revised', `<span class="num">${esc(record.revised)}</span>`],
      ['Pressure method', esc(record.pressureMethod)],
      ['Water capacity', capacityHtml],
    ];
  }

  /** One value table for a section. */
  function tableHtml(section) {
    const rows = section.rows
      .map((row) => `<tr><th scope="row">${esc(row.symbol)}</th><td class="num">${esc(row.value)}</td><td>${esc(row.unit)}</td></tr>`)
      .join('');
    return [
      `<section class="value-section">`,
      `<h3>${esc(section.title)}</h3>`,
      '<table>',
      '<thead><tr><th scope="col">Symbol</th><th scope="col">Value</th><th scope="col">Unit</th></tr></thead>',
      `<tbody>${rows}</tbody>`,
      '</table>',
      '</section>',
    ].join('');
  }

  /** The value tables grouped under Cartridge and Chamber. */
  function valuesHtml(record) {
    const sections = format.buildSections(record);
    const group = (heading, list) => `<div class="value-group"><h2>${esc(heading)}</h2>${list.map(tableHtml).join('')}</div>`;
    return `<div class="values">${group('Cartridge', sections.cartridge)}${group('Chamber', sections.chamber)}</div>`;
  }

  /** Notes about values the drawing could not use. */
  function drawingNotesHtml(notes) {
    if (notes.length === 0) return '';
    return `<ul class="drawing-notes">${notes.map((note) => `<li>${esc(note)}</li>`).join('')}</ul>`;
  }

  /**
   * Detail view for one record.
   * @param {object} record
   * @param {ReturnType<typeof drawingModule.buildDrawing>} drawing
   */
  function detailHtml(record, drawing) {
    const annotations = record.annotations ?? {};
    const identity = identityRows(record).map(([term, value]) => `<dt>${esc(term)}</dt><dd>${value}</dd>`).join('');
    const figure = drawing.svg
      ? `<figure class="drawing">${drawing.svg}${drawingNotesHtml(drawing.notes)}</figure>`
      : `<figure class="drawing"><p>No drawing: ${esc(drawing.notes.join(' '))}</p></figure>`;
    return [
      '<article class="cartridge">',
      '<nav class="toolbar" aria-label="Cartridge">',
      `<a href="#/">All cartridges</a>`,
      '<button type="button" id="print-button">Print</button>',
      '</nav>',
      `<h1>${esc(record.name)}</h1>`,
      `<dl class="identity">${identity}</dl>`,
      `<section class="drawing-section" aria-label="Drawing">${figure}</section>`,
      valuesHtml(record),
      `<footer class="source">Source: C.I.P. TDCC, revised <span class="num">${esc(record.revised)}</span></footer>`,
      '</article>',
    ].join('');
  }

  /** Message for an unknown cartridge key. */
  function notFoundHtml(key) {
    return [
      '<article class="not-found">',
      '<h1>Cartridge not found</h1>',
      `<p>No cartridge has the key <code>${esc(key)}</code>.</p>`,
      '<p><a href="#/">All cartridges</a></p>',
      '</article>',
    ].join('');
  }

  const api = Object.freeze({
    listShellHtml,
    resultsHtml,
    detailHtml,
    notFoundHtml,
    identityRows,
    valuesHtml,
    route: router.parseRoute,
  });

  if (isNode) {
    module.exports = api;
  } else {
    root.CIP.detail = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
