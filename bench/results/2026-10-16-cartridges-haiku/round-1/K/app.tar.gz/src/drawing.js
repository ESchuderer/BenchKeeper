/**
 * Inline SVG drawing of one cartridge, true to scale (1 user unit = 1 mm).
 * The upper half is the outside view, the lower half the section. Dimension
 * lines carry labels placed by layout.js. Pure string output.
 */
(function (root) {
  'use strict';

  const isNode = typeof module === 'object' && module.exports;
  const geometry = isNode ? require('./geometry.js') : root.CIP.geometry;
  const layout = isNode ? require('./layout.js') : root.CIP.layout;
  const format = isNode ? require('./format.js') : root.CIP.format;

  const LABEL_FONT = 3.2;
  const TITLE_FONT = 4.6;
  const SMALL_FONT = 3;
  const ARROW_LENGTH = 1.8;
  const ARROW_HALF_WIDTH = 0.6;
  const OVERSHOOT = 1.0;
  const LEVEL_STEP = 4.8;
  const LEVEL_OFFSET = 2.5;
  const LABEL_BELOW = 2.0;
  const TITLE_PAD = 2;
  const TITLE_HEIGHT = 24;
  const SCALE_BAR = 10;
  /** Width the scale bar and its label need on the title block's last row. */
  const TITLE_BAR_ROW = SCALE_BAR + 16;

  /** @param {number} n @returns {string} */
  const fmt = (n) => String(Number(n.toFixed(3)));

  /**
   * Map a (z, r) point to SVG coordinates: upper half above the axis (-r),
   * lower half, the section, below it (+r).
   */
  const upper = (p) => ({ x: p.z, y: -p.r });
  const lower = (p) => ({ x: p.z, y: p.r });

  /** @param {{x:number,y:number}[]} points @param {boolean} close */
  function pathOf(points, close = false) {
    const body = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${fmt(p.x)} ${fmt(p.y)}`).join(' ');
    return close ? `${body} Z` : body;
  }

  /** Segments of a polyline. @param {{x:number,y:number}[]} points */
  function segmentsOf(points, close = false) {
    const segs = [];
    for (let i = 1; i < points.length; i += 1) segs.push({ a: points[i - 1], b: points[i] });
    if (close && points.length > 2) segs.push({ a: points[points.length - 1], b: points[0] });
    return segs;
  }

  /** Arrowhead with its tip on `tip`, pointing away from `from`. */
  function arrowPath(tip, from) {
    const dx = tip.x - from.x;
    const dy = tip.y - from.y;
    const len = Math.hypot(dx, dy);
    const ux = dx / len;
    const uy = dy / len;
    const base = { x: tip.x - ux * ARROW_LENGTH, y: tip.y - uy * ARROW_LENGTH };
    const left = { x: base.x - uy * ARROW_HALF_WIDTH, y: base.y + ux * ARROW_HALF_WIDTH };
    const right = { x: base.x + uy * ARROW_HALF_WIDTH, y: base.y - ux * ARROW_HALF_WIDTH };
    return pathOf([tip, left, right], true);
  }

  /** `L3 51.18` or `L3 19.15 -0.25`. */
  function labelText(symbol, value, tolerance) {
    const tol = tolerance === undefined ? '' : ` ${format.formatNumber(tolerance)}`;
    return `${symbol} ${format.formatNumber(value)}${tol}`;
  }

  /**
   * Dimension definitions for the record: axial dimensions on levels above
   * the drawing, diameters as vertical lines, and the shoulder angle.
   * @returns {{axial: object[], radial: object[], angle: object|null}}
   */
  function dimensionsOf(record, model) {
    const c = record.cartridge;
    const v = model.values;
    const tipR = model.bullet ? model.bullet.tipR : 0;
    const headR = v.R1 / 2;
    const levelY = (k) => -(headR + LEVEL_OFFSET) - LEVEL_STEP * k;
    const axial = [];
    const add = (id, length, tol, level, extra) => {
      if (length === undefined) return;
      axial.push({ id, length, tol, level, y: levelY(level), ...extra });
    };

    add('R', v.R, c.caseHead.RTol, 0, { ext: [{ z: v.R, r: headR }] });
    if (model.bottleneck) {
      add('L1', v.L1, c.lengths.L1Tol, 1, { ext: [{ z: v.L1, r: v.P2 / 2 }] });
      add('L2', v.L2, c.lengths.L2Tol, 2, { ext: [{ z: v.L2, r: v.H1 / 2 }] });
    }
    add('L3', v.L3, c.lengths.L3Tol, 3, { ext: [{ z: v.L3, r: v.H2 / 2 }] });
    if (model.bullet) add('L6', v.L6, c.lengths.L6Tol, 4, { ext: [{ z: v.L6, r: tipR }] });

    const radial = [];
    const diameter = (id, value, tol, z, radius) => {
      if (value === undefined || z === undefined) return;
      radial.push({ id, value, tol, z, radius });
    };
    diameter('R1', v.R1, undefined, model.anchors.outermostRimZ ?? 0, headR);
    if (model.anchors.grooveFloorEnd !== undefined) {
      const mid = (v.R + model.anchors.grooveFloorEnd) / 2;
      diameter('E1', v.E1, undefined, mid, v.E1 / 2);
    }
    diameter('P1', v.P1, undefined, model.anchors.bodyStart + 0.6, v.P1 / 2);
    if (model.bottleneck) {
      diameter('P2', v.P2, c.powderChamber.P2Tol, v.L1, v.P2 / 2);
      diameter('H1', v.H1, undefined, v.L2, v.H1 / 2);
    }
    diameter('H2', v.H2, undefined, v.L3 - 0.6, v.H2 / 2);
    if (model.bullet) diameter('G1', v.G1, undefined, model.anchors.bulletMidZ, model.bullet.Rexp);

    const angle = model.bottleneck
      ? { id: 'alpha', text: `α ${format.formatAngle(c.junctionCone.alpha)}`, z: (v.L1 + v.L2) / 2, r: (v.P2 / 2 + v.H1 / 2) / 2 }
      : null;
    return { axial, radial, angle };
  }

  /** Dimension geometry, extension lines and label anchors for one record. */
  function dimensionGraphics(model, dims) {
    const lines = [];
    const arrows = [];
    const labels = [];
    const headTop = upper(model.outer[1]);

    for (const dim of dims.axial) {
      const yLine = dim.y;
      lines.push({ a: { x: 0, y: yLine }, b: { x: dim.length, y: yLine } });
      arrows.push(arrowPath({ x: 0, y: yLine }, { x: dim.length, y: yLine }));
      arrows.push(arrowPath({ x: dim.length, y: yLine }, { x: 0, y: yLine }));
      lines.push({ a: { x: 0, y: headTop.y }, b: { x: 0, y: yLine - OVERSHOOT } });
      for (const e of dim.ext ?? []) {
        const start = upper(e);
        lines.push({ a: start, b: { x: e.z, y: yLine - OVERSHOOT } });
      }
      labels.push({
        id: dim.id,
        text: labelText(dim.id, dim.length, dim.tol),
        fontSize: LABEL_FONT,
        anchor: { x: dim.length / 2, y: yLine - LABEL_BELOW },
      });
    }

    for (const dim of dims.radial) {
      const x = dim.z;
      const r = dim.radius;
      if (dim.id === 'R1') {
        const left = -6;
        lines.push({ a: { x, y: -r }, b: { x: left, y: -r } }, { a: { x, y: r }, b: { x: left, y: r } });
        lines.push({ a: { x: left, y: -r }, b: { x: left, y: r } });
        arrows.push(arrowPath({ x: left, y: -r }, { x: left, y: r }), arrowPath({ x: left, y: r }, { x: left, y: -r }));
        labels.push({ id: dim.id, text: labelText(dim.id, dim.value, dim.tol), fontSize: LABEL_FONT, anchor: { x: left, y: r + LABEL_BELOW } });
        continue;
      }
      lines.push({ a: { x, y: -r }, b: { x, y: r } });
      arrows.push(arrowPath({ x, y: -r }, { x, y: r }), arrowPath({ x, y: r }, { x, y: -r }));
      labels.push({ id: dim.id, text: labelText(dim.id, dim.value, dim.tol), fontSize: LABEL_FONT, anchor: { x, y: r + LABEL_BELOW } });
    }

    if (dims.angle) {
      labels.push({
        id: dims.angle.id,
        text: dims.angle.text,
        fontSize: LABEL_FONT,
        anchor: { x: dims.angle.z, y: -dims.angle.r - LABEL_BELOW },
      });
    }
    return { lines, arrows, labels };
  }

  /**
   * Compute the whole drawing for one record.
   * @param {object} record
   * @returns {{drawable: boolean, notes: string[], svg: string|null, labels: object[], unresolved: string[], viewBox: object|null, segments: object[], model: object}}
   */
  function buildDrawing(record) {
    const model = geometry.buildModel(record);
    const notes = [...model.notes];
    if (!model.drawable) return { drawable: false, notes, svg: null, labels: [], unresolved: [], viewBox: null, segments: [], model };

    const upperPoints = [...model.outer, ...(model.bullet ? model.bullet.outline : [])].map(upper);
    const sectionPoints = model.section ? model.section.map(lower) : [];
    const seatedPoints = model.bullet ? model.bullet.seated.map(lower) : [];
    const dims = dimensionsOf(record, model);
    const graphics = dimensionGraphics(model, dims);
    const centreY = 0;
    const L6 = record.cartridge.lengths.L6 ?? model.outer[model.outer.length - 1].z;
    const centreLine = { a: { x: -8, y: centreY }, b: { x: L6 + 4, y: centreY } };

    const segments = [
      ...segmentsOf(upperPoints),
      ...segmentsOf(sectionPoints, true),
      ...segmentsOf(seatedPoints, true),
      ...graphics.lines.map((s) => ({ a: s.a, b: s.b })),
      centreLine,
    ];
    const bounds = { x0: -34, x1: L6 + 34, y0: -(record.cartridge.caseHead.R1 / 2 + 36), y1: record.cartridge.caseHead.R1 / 2 + 36 };
    const { placed, unresolved } = layout.placeLabels(graphics.labels, segments, bounds);

    const outlineTop = Math.min(...upperPoints.map((p) => p.y));
    const outlineBottom = Math.max(...sectionPoints.map((p) => p.y), 0);
    const labelTop = Math.min(outlineTop, ...placed.map((l) => l.box.y0));
    const labelBottom = Math.max(outlineBottom, ...placed.map((l) => l.box.y1));
    const left = Math.min(0, ...placed.map((l) => l.box.x0), -8);
    const right = Math.max(L6, ...placed.map((l) => l.box.x1));
    const titleTop = labelBottom + 5;
    const titleBottom = titleTop + TITLE_HEIGHT;
    const titleWidth = titleBlockWidth(record, model);
    const viewBox = {
      x: left - 2,
      y: labelTop - 2,
      width: Math.max(right, left + titleWidth) - left + 4,
      height: titleBottom + 2 - (labelTop - 2),
    };

    const svg = svgMarkup(record, model, {
      upperPoints, sectionPoints, seatedPoints, graphics, placed, centreLine, left, titleTop, viewBox,
    });
    return { drawable: true, notes, svg, labels: placed, unresolved, viewBox, segments, model };
  }

  /** @returns {string} the SVG element for the drawing */
  function svgMarkup(record, model, parts) {
    const esc = format.escapeHtml;
    const key = esc(record.key);
    const name = esc(record.name);
    const { viewBox } = parts;
    const hatch = `hatch-${record.key}`;
    const rows = [];
    rows.push(`<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img" aria-label="${name} drawing" viewBox="${fmt(viewBox.x)} ${fmt(viewBox.y)} ${fmt(viewBox.width)} ${fmt(viewBox.height)}" font-size="${LABEL_FONT}" data-key="${key}">`);
    rows.push(`<defs><pattern id="${hatch}" width="1.2" height="1.2" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="1.2" stroke="currentColor" stroke-width="0.15"/></pattern></defs>`);
    rows.push(`<path class="centre-line" d="${pathOf([{ x: -8, y: 0 }, { x: parts.centreLine.b.x, y: 0 }])}" fill="none" stroke="currentColor" stroke-width="0.2" stroke-dasharray="7 1.2 1.2 1.2"/>`);
    if (parts.sectionPoints.length > 0) {
      rows.push(`<path class="section" d="${pathOf(parts.sectionPoints, true)}" fill="url(#${hatch})" stroke="currentColor" stroke-width="0.3" stroke-linejoin="round"/>`);
    }
    if (parts.seatedPoints.length > 0) {
      rows.push(`<path class="bullet-section" d="${pathOf(parts.seatedPoints, true)}" fill="none" stroke="currentColor" stroke-width="0.25" stroke-linejoin="round"/>`);
    }
    rows.push(`<path class="outline" d="${pathOf(parts.upperPoints)}" fill="none" stroke="currentColor" stroke-width="0.35" stroke-linejoin="round"/>`);
    rows.push(`<g class="dimensions" fill="none" stroke="currentColor" stroke-width="0.15">`);
    for (const line of parts.graphics.lines) rows.push(`<path d="${pathOf([line.a, line.b])}"/>`);
    rows.push('</g>');
    rows.push(`<g class="arrows" fill="currentColor">${parts.graphics.arrows.map((d) => `<path d="${d}"/>`).join('')}</g>`);
    rows.push('<g class="labels" fill="currentColor">');
    for (const label of parts.placed) {
      rows.push(`<text x="${fmt(label.box.x0)}" y="${fmt(label.box.y0 + label.fontSize * 0.8)}" data-dim="${esc(label.id)}">${esc(label.text)}</text>`);
    }
    rows.push('</g>');
    rows.push(titleBlockMarkup(record, model, parts.left, parts.titleTop));
    rows.push('</svg>');
    return rows.join('');
  }

  /** The title block's text lines as [text, font size, font weight]. */
  function titleLines(record, model) {
    return [
      [record.name, TITLE_FONT, 600],
      [`C.I.P. table ${record.tab} · revised ${record.revised}`, SMALL_FONT + 0.2, 400],
      [`Rim type: ${model.rim} · Dimensions in mm`, SMALL_FONT + 0.2, 400],
    ];
  }

  /** Title block width: its widest line, or the scale bar row, plus padding. */
  function titleBlockWidth(record, model) {
    const widest = Math.max(...titleLines(record, model).map(([text, size]) => layout.textWidth(text, size)));
    return Math.max(widest, TITLE_BAR_ROW) + 2 * TITLE_PAD;
  }

  /** Title block: name, C.I.P. table and revision, rim type, units and scale bar. */
  function titleBlockMarkup(record, model, x0, y0) {
    const esc = format.escapeHtml;
    const width = titleBlockWidth(record, model);
    const [name, revision, rim] = titleLines(record, model);
    const textAt = (y, [text, size, weight]) => {
      const weightAttr = weight > 400 ? ` font-weight="${weight}"` : '';
      return `<text x="${fmt(x0 + TITLE_PAD)}" y="${fmt(y)}" font-size="${size}"${weightAttr}>${esc(text)}</text>`;
    };
    const barX = x0 + TITLE_PAD;
    const barY = y0 + 19;
    const bar = `<path d="M${fmt(barX)} ${fmt(barY)} H${fmt(barX + SCALE_BAR)} M${fmt(barX)} ${fmt(barY - 1)} V${fmt(barY + 1)} M${fmt(barX + SCALE_BAR)} ${fmt(barY - 1)} V${fmt(barY + 1)}" fill="none" stroke="currentColor" stroke-width="0.3"/>`;
    const barLabel = `<text x="${fmt(barX + SCALE_BAR + 1.5)}" y="${fmt(barY + 1)}" font-size="${SMALL_FONT}">10 mm</text>`;
    return [
      '<g class="title-block" fill="currentColor">',
      `<rect x="${fmt(x0)}" y="${fmt(y0)}" width="${fmt(width)}" height="${TITLE_HEIGHT}" fill="none" stroke="currentColor" stroke-width="0.3"/>`,
      textAt(y0 + 6, name),
      textAt(y0 + 10.5, revision),
      textAt(y0 + 14.5, rim),
      bar,
      barLabel,
      '</g>',
    ].join('');
  }

  const api = Object.freeze({
    buildDrawing,
    dimensionsOf,
    labelText,
    arrowPath,
    LABEL_FONT,
  });

  if (isNode) {
    module.exports = api;
  } else {
    root.CIP.drawing = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
