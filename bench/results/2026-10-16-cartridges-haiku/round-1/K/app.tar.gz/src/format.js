/**
 * Display formatting for cartridge values: numbers as published, angles,
 * tolerances, symbols, units and the grouped section model.
 * Pure functions only; no DOM access.
 */
(function (root) {
  'use strict';

  /** Symbols that differ from the field name (spec: cartridge-detail). */
  const SYMBOLS = Object.freeze({
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  });

  /** Fields whose values are angles (degrees, or degrees/minutes/seconds). */
  const ANGLE_KEYS = Object.freeze(['alpha', 'alpha1', 'beta', 'delta', 'i']);

  /**
   * Units named by the brief. Lengths and diameters are mm. Fields the brief
   * gives no unit for (S, u, Fe, b, h, s, G) and counts (N) get no unit.
   */
  const UNITS = Object.freeze({
    mm: [
      'E', 'E1', 'R', 'R1', 'R3', 'r', 'eMin', 'f', 'H1', 'H2',
      'L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L3PlusG', 'G1', 'G2',
      'P1', 'P2', 'F', 'Z', 'r1Min', 'r1Max', 'r2', 'deltaL',
    ],
    bar: ['PE', 'PK', 'Pmax'],
    J: ['EE'],
    g: ['M'],
    'mm²': ['Q'],
  });

  const UNIT_BY_KEY = (() => {
    const map = {};
    for (const [unit, keys] of Object.entries(UNITS)) {
      for (const key of keys) map[key] = unit;
    }
    return Object.freeze(map);
  })();

  const SECTION_TITLES = Object.freeze({
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling',
  });

  const CARTRIDGE_ORDER = Object.freeze([
    'caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile',
  ]);
  const CHAMBER_ORDER = Object.freeze([
    'barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling',
  ]);

  /** @param {unknown} text @returns {string} */
  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /** @param {number|undefined|null} value @returns {string} */
  function formatNumber(value) {
    return value === undefined || value === null ? '' : String(value);
  }

  /** Two-digit zero padding for minutes and seconds. @param {number} n */
  function pad2(n) {
    return String(n).padStart(2, '0');
  }

  /**
   * Angle as published: a number of degrees (`40°`) or an object with
   * degrees, minutes and seconds (`39°59'49"`).
   * @param {number|{degrees:number,minutes:number,seconds:number}} angle
   * @returns {string}
   */
  function formatAngle(angle) {
    if (typeof angle === 'number') return `${String(angle)}°`;
    return `${String(angle.degrees)}°${pad2(angle.minutes)}'${pad2(angle.seconds)}"`;
  }

  /**
   * Angle in decimal degrees, for geometry.
   * @param {number|{degrees:number,minutes:number,seconds:number}} angle
   * @returns {number}
   */
  function angleToDegrees(angle) {
    if (typeof angle === 'number') return angle;
    return angle.degrees + angle.minutes / 60 + angle.seconds / 3600;
  }

  /** @param {string} key @param {unknown} value @returns {string} */
  function formatValue(key, value) {
    if (ANGLE_KEYS.includes(key)) return formatAngle(value);
    return formatNumber(value);
  }

  /** @param {string} key @returns {string} */
  function symbolOf(key) {
    return SYMBOLS[key] ?? key;
  }

  /** @param {string} key @returns {string} */
  function unitOf(key) {
    if (ANGLE_KEYS.includes(key)) return '';
    return UNIT_BY_KEY[key] ?? '';
  }

  /** @param {string} key @returns {boolean} */
  function isToleranceKey(key) {
    return key.endsWith('Tol') && key.length > 3;
  }

  /** @param {string} sectionId @returns {string} */
  function sectionTitle(sectionId) {
    return SECTION_TITLES[sectionId] ?? sectionId;
  }

  /**
   * Rows for one section object. A `<X>Tol` field is shown beside X and never
   * gets a row of its own; a tolerance without a base keeps its own row.
   * @param {Record<string, unknown>} fields
   * @returns {{key:string,symbol:string,value:string,unit:string}[]}
   */
  function rowsOf(fields) {
    const rows = [];
    for (const key of Object.keys(fields)) {
      const isAttachedTol = isToleranceKey(key) && key.slice(0, -3) in fields;
      if (isAttachedTol) continue;
      const tolKey = `${key}Tol`;
      const tol = fields[tolKey];
      const withTol = tol === undefined ? '' : ` ${formatNumber(tol)}`;
      rows.push({
        key,
        symbol: symbolOf(key),
        value: `${formatValue(key, fields[key])}${withTol}`,
        unit: unitOf(key),
      });
    }
    return rows;
  }

  /**
   * @param {Record<string, Record<string, unknown>>|undefined} group
   * @param {readonly string[]} order
   */
  function sectionsOf(group, order) {
    if (!group) return [];
    const ids = [
      ...order.filter((id) => id in group),
      ...Object.keys(group).filter((id) => !order.includes(id)),
    ];
    return ids.map((id) => ({ id, title: sectionTitle(id), rows: rowsOf(group[id]) }));
  }

  /**
   * Grouped tables for the detail view: `cartridge` and `chamber` values.
   * @param {{cartridge?: object, chamber?: object}} record
   * @returns {{cartridge: ReturnType<typeof sectionsOf>, chamber: ReturnType<typeof sectionsOf>}}
   */
  function buildSections(record) {
    return {
      cartridge: sectionsOf(record.cartridge, CARTRIDGE_ORDER),
      chamber: sectionsOf(record.chamber, CHAMBER_ORDER),
    };
  }

  const api = Object.freeze({
    SYMBOLS,
    ANGLE_KEYS,
    UNITS,
    escapeHtml,
    formatNumber,
    formatAngle,
    angleToDegrees,
    formatValue,
    symbolOf,
    unitOf,
    isToleranceKey,
    sectionTitle,
    buildSections,
  });

  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.format = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
