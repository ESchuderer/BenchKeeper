/**
 * Cartridge geometry from one record, in the spec's (z, r) frame: z runs along
 * the axis from the head face (z = 0) to the mouth, r is the radius. Pure
 * functions. A feature whose values are missing is left out and named in
 * `notes`; no number is ever invented.
 */
(function (root) {
  'use strict';

  const format = typeof module === 'object' && module.exports ? require('./format.js') : root.CIP.format;

  const ARC_SAMPLES = 16;
  const NOSE_SAMPLES = 32;
  const HEELED_TOLERANCE = 0.015;
  const PRIMER_POCKETS = Object.freeze({
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 },
  });

  /**
   * Rim type: the family decides belted and rimfire; otherwise R1/P1 decides
   * rimmed (>= 1.05), rebated (< 0.98) or rimless.
   * @param {object} record
   * @returns {'belted'|'rimfire'|'rimmed'|'rebated'|'rimless'}
   */
  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    const head = record.cartridge?.caseHead ?? {};
    const body = record.cartridge?.powderChamber ?? {};
    if (head.R1 === undefined || body.P1 === undefined) return 'rimless';
    const ratio = head.R1 / body.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  /** @param {number} degrees */
  const radians = (degrees) => (degrees * Math.PI) / 180;

  /** Published values the geometry reads; angles are decimal degrees. */
  function readValues(record) {
    const c = record.cartridge ?? {};
    const head = c.caseHead ?? {};
    const jc = c.junctionCone ?? {};
    const len = c.lengths ?? {};
    const pc = c.powderChamber ?? {};
    const deg = (a) => (a === undefined ? undefined : format.angleToDegrees(a));
    return {
      family: record.family,
      E: head.E, E1: head.E1, R: head.R, R1: head.R1, R3: head.R3,
      beta: deg(head.beta), delta: deg(head.delta), eMin: head.eMin, f: head.f,
      H1: c.collar?.H1, H2: c.collar?.H2,
      alpha: deg(jc.alpha), r1Min: jc.r1Min, r2: jc.r2,
      L1: len.L1, L2: len.L2, L3: len.L3, L6: len.L6,
      P1: pc.P1, P2: pc.P2,
      G1: c.projectile?.G1,
      shape: record.annotations?.defaultBulletShape,
      category: record.annotations?.category,
      primerType: record.annotations?.primerType,
    };
  }

  /** Remove consecutive duplicate points. @param {{z:number,r:number}[]} points */
  function dedupe(points) {
    const out = [];
    for (const p of points) {
      const last = out[out.length - 1];
      if (last && Math.abs(last.z - p.z) < 1e-9 && Math.abs(last.r - p.r) < 1e-9) continue;
      out.push(p);
    }
    return out;
  }

  /**
   * Tangent arc replacing the corner between a run from `prev` and a run out to
   * `next`. Returns the arc points from tangent to tangent, or null when the
   * arc does not fit on both runs.
   * @returns {{points: {z:number,r:number}[]} | null}
   */
  function fillet(prev, corner, next, radius) {
    const toPrev = { z: prev.z - corner.z, r: prev.r - corner.r };
    const toNext = { z: next.z - corner.z, r: next.r - corner.r };
    const lenPrev = Math.hypot(toPrev.z, toPrev.r);
    const lenNext = Math.hypot(toNext.z, toNext.r);
    const a = { z: toPrev.z / lenPrev, r: toPrev.r / lenPrev };
    const b = { z: toNext.z / lenNext, r: toNext.r / lenNext };
    const interior = Math.acos(Math.min(1, Math.max(-1, a.z * b.z + a.r * b.r)));
    const tangent = radius / Math.tan(interior / 2);
    if (tangent > lenPrev || tangent > lenNext) return null;

    const bisector = { z: a.z + b.z, r: a.r + b.r };
    const bisectorLen = Math.hypot(bisector.z, bisector.r);
    const centreDistance = radius / Math.sin(interior / 2);
    const centre = {
      z: corner.z + (bisector.z / bisectorLen) * centreDistance,
      r: corner.r + (bisector.r / bisectorLen) * centreDistance,
    };
    const start = { z: corner.z + a.z * tangent, r: corner.r + a.r * tangent };
    const end = { z: corner.z + b.z * tangent, r: corner.r + b.r * tangent };
    const angleStart = Math.atan2(start.r - centre.r, start.z - centre.z);
    let sweep = Math.atan2(end.r - centre.r, end.z - centre.z) - angleStart;
    if (sweep > Math.PI) sweep -= 2 * Math.PI;
    if (sweep < -Math.PI) sweep += 2 * Math.PI;

    const points = [];
    for (let i = 0; i <= ARC_SAMPLES; i += 1) {
      const angle = angleStart + (sweep * i) / ARC_SAMPLES;
      points.push({ z: centre.z + radius * Math.cos(angle), r: centre.r + radius * Math.sin(angle) });
    }
    points[0] = start;
    points[ARC_SAMPLES] = end;
    return { points };
  }

  /**
   * Rimfire rim: a half-round of radius rr whose outermost point lies at R1/2,
   * running from the head face to z = 2·rr. Samples from the head face.
   */
  function rimfireArc(headR, rr) {
    const centreR = headR - rr;
    const points = [];
    for (let i = 0; i <= ARC_SAMPLES; i += 1) {
      const theta = (Math.PI * i) / ARC_SAMPLES;
      points.push({ z: rr - rr * Math.cos(theta), r: centreR + rr * Math.sin(theta), role: 'rim' });
    }
    return points;
  }

  /**
   * Head face, rim and extractor groove or belt for every non-rimfire case.
   * Returns the vertices in z order, the body start z and the anchors.
   */
  function headAndGroove(v, notes) {
    const headR = v.R1 / 2;
    const vertices = [{ z: 0, r: 0, role: 'axis' }];
    const chamfer = v.beta !== undefined && v.beta < 90 && v.f !== undefined;
    let outermostRimZ = 0;
    if (chamfer) {
      const inset = Math.min(v.f * Math.tan(radians(v.beta)), headR / 2);
      vertices.push({ z: 0, r: headR - inset, role: 'head' });
      vertices.push({ z: v.f, r: headR, role: 'rim' });
      outermostRimZ = v.f;
    } else {
      vertices.push({ z: 0, r: headR, role: 'rim' });
      if (v.beta !== undefined) notes.push('f not published: head corner drawn square.');
    }
    const rimTop = Math.max(v.R, outermostRimZ);
    vertices.push({ z: rimTop, r: headR, role: 'rim' });

    const absent = ['E', 'E1'].filter((key) => v[key] === undefined);
    if (absent.length > 0) {
      if (absent.length === 1) notes.push(`${absent[0]} not published: extractor groove not drawn.`);
      vertices.push({ z: rimTop, r: v.P1 / 2, role: 'body' });
      return { vertices: dedupe(vertices), bodyStart: rimTop, outermostRimZ, groove: null };
    }

    const floorEnd = v.eMin === undefined ? rimTop : rimTop + v.eMin;
    if (v.eMin === undefined) notes.push('eMin not published: groove floor not drawn.');
    vertices.push({ z: rimTop, r: v.E1 / 2, role: 'groove' });
    vertices.push({ z: floorEnd, r: v.E1 / 2, role: 'groove' });

    const belted = v.family === 'belted';
    if (belted && v.R3 !== undefined && v.delta !== undefined) {
      const rampRun = (v.R3 / 2 - v.E1 / 2) / Math.tan(radians(v.delta));
      const beltRampEnd = floorEnd + rampRun;
      const beltEnd = Math.max(v.E, beltRampEnd);
      vertices.push({ z: beltRampEnd, r: v.R3 / 2, role: 'belt' });
      vertices.push({ z: beltEnd, r: v.R3 / 2, role: 'belt' });
      vertices.push({ z: v.E, r: v.P1 / 2, role: 'body' });
      return {
        vertices: dedupe(vertices),
        bodyStart: v.E,
        outermostRimZ,
        beltRampEnd,
        groove: { floorStart: rimTop, floorEnd },
      };
    }
    if (belted) notes.push('R3 or delta not published: belt not drawn.');
    vertices.push({ z: v.E, r: v.P1 / 2, role: 'body' });
    return {
      vertices: dedupe(vertices),
      bodyStart: v.E,
      outermostRimZ,
      groove: { floorStart: rimTop, floorEnd },
    };
  }

  /** Rimfire head: half-round rim, then a step to P1/2 at the rim back. */
  function rimfireHead(v) {
    const headR = v.R1 / 2;
    const rr = Math.max(0, Math.min(v.R / 2, (v.R1 - v.P1) / 2));
    const rimBack = 2 * rr;
    const vertices = [
      { z: 0, r: 0, role: 'axis' },
      { z: 0, r: headR - rr, role: 'head' },
      ...rimfireArc(headR, rr),
      { z: rimBack, r: v.P1 / 2, role: 'body' },
    ];
    return { vertices: dedupe(vertices), bodyStart: rimBack, outermostRimZ: rr, groove: null };
  }

  /**
   * Walls of the section (spec): tn = (H2 − G1)/2 at the neck, tb =
   * min(max(1.3·tn, 0.6), 0.35·P1/2) along the body. Heeled cases use tb at the
   * mouth, since their seated heel has the inside diameter H2 − 2·tb.
   */
  function wallsFor(v) {
    const tn = (v.H2 - v.G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * (v.P1 / 2));
    const heeled = v.H2 - v.G1 <= HEELED_TOLERANCE;
    return { tn, tb, mouth: heeled ? tb : tn, heeled };
  }

  /**
   * Seating depth s, cylinder factor k and meplat diameter m for a bullet.
   * @returns {{s:number,k:number,m:number}|null} null for an unknown shape
   */
  function bulletParameters(shape, category, G1) {
    const pistol = category === 'pistol';
    switch (shape) {
      case 'pointy':
        return { s: G1, k: 0.4, m: Math.max(0.08 * G1, 1.27) };
      case 'rounded':
        return { s: (pistol ? 0.4 : 0.8) * G1, k: pistol ? 0.65 : 0.55, m: 0.15 * G1 };
      case 'flat':
        return { s: (pistol ? 0.4 : 0.8) * G1, k: pistol ? 0.7 : 0.6, m: 0.55 * G1 };
      case 'semi_wadcutter':
        return { s: 0.6 * G1, k: 0.78, m: 0.6 * G1 };
      default:
        return null;
    }
  }

  /**
   * Nose from (zs, Rexp) to the tip (L6, m/2): pointy is a tangent ogive,
   * rounded a quarter ellipse, flat and semi_wadcutter a straight cone.
   * @returns {{z:number,r:number}[]}
   */
  function noseShape(shape, Rexp, zs, L6, m) {
    const n = L6 - zs;
    const tipR = m / 2;
    const points = [];
    if (shape === 'pointy') {
      const a = Rexp - tipR;
      const rho = (a * a + n * n) / (2 * a);
      const centreR = Rexp - rho;
      const thetaEnd = Math.atan2(n, tipR - centreR);
      for (let i = 0; i <= NOSE_SAMPLES; i += 1) {
        const theta = (thetaEnd * i) / NOSE_SAMPLES;
        points.push({ z: zs + rho * Math.sin(theta), r: centreR + rho * Math.cos(theta) });
      }
    } else if (shape === 'rounded') {
      const radial = Rexp - tipR;
      for (let i = 0; i <= NOSE_SAMPLES; i += 1) {
        const t = ((Math.PI / 2) * i) / NOSE_SAMPLES;
        points.push({ z: zs + n * Math.sin(t), r: tipR + radial * Math.cos(t) });
      }
    } else {
      points.push({ z: zs, r: Rexp }, { z: L6, r: tipR });
    }
    points[0] = { z: zs, r: Rexp };
    points[points.length - 1] = { z: L6, r: tipR };
    return points;
  }

  /**
   * Bullet from the mouth to the tip. `outline` is the exposed silhouette;
   * `seated` closes the bullet's section inside the case.
   * @returns {object|null} null (with a note) when a value is missing
   */
  function buildBullet(v, walls, notes) {
    const missing = ['G1', 'L6', 'shape'].filter((key) => v[key] === undefined);
    if (missing.length > 0) {
      notes.push(`Bullet not drawn: ${missing.join(', ')} not published.`);
      return null;
    }
    const params = bulletParameters(v.shape, v.category, v.G1);
    if (params === null) {
      notes.push(`Bullet not drawn: nose shape "${v.shape}" is not in the drawing rules.`);
      return null;
    }
    const { s, k, m } = params;
    const Rexp = walls.heeled ? v.H2 / 2 : v.G1 / 2;
    const Rseat = walls.heeled ? v.H2 / 2 - walls.tb : v.G1 / 2;
    const zb = v.L3 - s;
    const Lb = v.L6 - zb;
    const zs = zb + k * Lb;
    const nose = noseShape(v.shape, Rexp, zs, v.L6, m);
    return {
      s, k, m, zb, zs, Lb, Rexp, Rseat, nose,
      tipR: m / 2,
      outline: [{ z: v.L3, r: Rexp }, ...nose, { z: v.L6, r: 0 }],
      seated: [
        { z: zb, r: 0 }, { z: zb, r: Rseat }, { z: v.L3, r: Rseat },
        { z: v.L3, r: Rexp }, ...nose, { z: v.L6, r: 0 },
      ],
    };
  }

  /** Clip a z-ordered polyline at z = cut, starting with the interpolated point. */
  function clipAt(points, cut) {
    const first = points.findIndex((p) => p.z > cut);
    const before = points[first - 1];
    const after = points[first];
    const t = (cut - before.z) / (after.z - before.z);
    const start = { z: cut, r: before.r + (after.r - before.r) * t };
    return [start, ...points.slice(first)];
  }

  /**
   * Primer pocket for centrefire cases; null for rimfire or an unknown type.
   * @returns {{pocket: {diameter:number,depth:number}|null, note?: string}}
   */
  function pocketFor(rim, primerType) {
    if (rim === 'rimfire') return { pocket: null };
    const rule = PRIMER_POCKETS[primerType];
    if (!rule) return { pocket: null, note: `Primer type "${primerType}" has no pocket dimensions: no pocket drawn.` };
    return { pocket: { diameter: rule.diameter, depth: rule.depth } };
  }

  /**
   * Solid head depth w and the section polygon (half, in (z, r)).
   * The polygon runs along the outer profile, the mouth face, the inner
   * profile back to the cavity floor at z = w, then closes on the axis.
   */
  function sectionFor(v, vertices, outer, walls, rim, anchors, pocket, notes) {
    const tb = walls.tb;
    const candidates = [2.5, 0.25 * (v.P1 / 2)];
    if (pocket) candidates.push(pocket.depth + 1.5);
    if (anchors.grooveFloorEnd !== undefined) candidates.push(v.E + tb);
    if (rim === 'belted' && anchors.beltRampEnd !== undefined) candidates.push(anchors.beltRampEnd + tb);
    const w = Math.max(...candidates);
    if (w >= v.L3) {
      notes.push('Solid head reaches the mouth: section not drawn.');
      return { w, polygon: null };
    }
    const wallOf = (role) => (role === 'neck' || role === 'mouth' ? walls.mouth : tb);
    const inner = vertices.filter((p) => p.role !== 'axis').map((p) => ({ z: p.z, r: Math.max(0, p.r - wallOf(p.role)) }));
    const cavityBack = [...clipAt(inner, w)].reverse();
    const start = pocket ? { z: 0, r: pocket.diameter / 2 } : { z: 0, r: 0 };
    const closing = [{ z: w, r: 0 }];
    if (pocket) closing.push({ z: pocket.depth, r: 0 }, { z: pocket.depth, r: pocket.diameter / 2 });
    return { w, polygon: dedupe([start, ...outer.slice(1), ...cavityBack, ...closing]) };
  }

  /**
   * Full model for one record.
   * @param {object} record one entry of the cartridge data
   */
  function buildModel(record) {
    const v = readValues(record);
    const rim = rimType(record);
    const notes = [];
    const base = { key: record.key, name: record.name, rim, notes, values: v };

    const absent = ['R1', 'R', 'P1', 'H2', 'L3'].filter((key) => v[key] === undefined);
    if (absent.length > 0) {
      notes.push(`Drawing not available: ${absent.join(', ')} not published.`);
      return { ...base, drawable: false, outer: [], vertices: [], fillets: [], bullet: null, section: null, anchors: {} };
    }

    const head = rim === 'rimfire' ? rimfireHead(v) : headAndGroove(v, notes);
    const shoulderMissing = ['alpha', 'L1', 'L2', 'H1', 'P2'].filter((key) => v[key] === undefined);
    const bottleneck = shoulderMissing.length === 0;
    if (!bottleneck && shoulderMissing.length < 5) {
      notes.push(`Shoulder not drawn: ${shoulderMissing.join(', ')} not published.`);
    }

    const vertices = [...head.vertices];
    if (bottleneck) {
      vertices.push({ z: v.L1, r: v.P2 / 2, role: 'shoulderStart' });
      vertices.push({ z: v.L2, r: v.H1 / 2, role: 'neck' });
    }
    vertices.push({ z: v.L3, r: v.H2 / 2, role: 'mouth' });
    const profile = dedupe(vertices);

    const fillets = [];
    const corners = new Map();
    if (bottleneck) {
      const specs = [
        { role: 'shoulderStart', radius: v.r1Min, label: 'r1 min' },
        { role: 'neck', radius: v.r2, label: 'r2' },
      ];
      for (const spec of specs) {
        if (spec.radius === undefined) {
          notes.push(`${spec.label} not published: corner drawn sharp.`);
          continue;
        }
        const index = profile.findIndex((p) => p.role === spec.role);
        const built = fillet(profile[index - 1], profile[index], profile[index + 1], spec.radius);
        if (built === null) {
          notes.push(`${spec.label} arc does not fit the shoulder: corner drawn sharp.`);
          continue;
        }
        corners.set(index, built.points);
        fillets.push({ role: spec.role, radius: spec.radius, points: built.points });
      }
    }
    const outer = dedupe(profile.flatMap((p, index) => (corners.has(index) ? corners.get(index) : [{ z: p.z, r: p.r }])));

    const pocketInfo = pocketFor(rim, v.primerType);
    if (pocketInfo.note) notes.push(pocketInfo.note);
    const pocket = pocketInfo.pocket;

    const anchors = {
      bodyStart: head.bodyStart,
      outermostRimZ: head.outermostRimZ,
      beltRampEnd: head.beltRampEnd,
      grooveFloorEnd: head.groove?.floorEnd,
    };
    if (bottleneck) anchors.shoulderMid = { z: (v.L1 + v.L2) / 2, r: (v.P2 / 2 + v.H1 / 2) / 2 };

    if (v.G1 === undefined) {
      notes.push('G1 not published: section walls and bullet not drawn.');
      return { ...base, drawable: true, bottleneck, outer, vertices: profile, fillets, pocket, anchors, bullet: null, section: null, heeled: undefined, walls: null, w: undefined };
    }

    const walls = wallsFor(v);
    const bullet = buildBullet(v, walls, notes);
    if (bullet) anchors.bulletMidZ = (v.L3 + bullet.zs) / 2;
    const { w, polygon } = sectionFor(v, profile, outer, walls, rim, anchors, pocket, notes);
    return {
      ...base,
      drawable: true,
      bottleneck,
      heeled: walls.heeled,
      walls,
      w,
      pocket,
      outer,
      vertices: profile,
      fillets,
      bullet,
      section: polygon,
      anchors,
    };
  }

  const api = Object.freeze({
    buildModel,
    rimType,
    bulletParameters,
    noseShape,
    fillet,
    PRIMER_POCKETS,
  });

  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP.geometry = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
