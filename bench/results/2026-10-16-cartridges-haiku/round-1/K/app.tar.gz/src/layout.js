/**
 * Label placement for dimension text. Each label starts at its anchor and
 * moves to the nearest free position, checked against the other labels, the
 * drawn lines (outline, section, dimension and extension lines) and the
 * drawing bounds. Plain geometry in millimetres; no DOM.
 */
(function (root) {
  'use strict';

  /** Width per character in em, for a proportional sans-serif face. */
  const CHAR_WIDTH_EM = 0.6;
  /** Box height in em (cap height plus descender). */
  const LINE_HEIGHT_EM = 1.05;
  /** Clear space kept between a label and anything it must not touch, in mm. */
  const CLEARANCE = 0.4;
  const STEP = 0.5;
  const MAX_DISTANCE = 40;
  /** Preferred directions, in SVG coordinates (y grows downwards). */
  const DIRECTIONS = [-90, 90, 0, 180, -45, 45, -135, 135].map((deg) => (deg * Math.PI) / 180);

  /** @param {string} text @param {number} fontSize @returns {number} */
  function textWidth(text, fontSize) {
    return [...text].length * fontSize * CHAR_WIDTH_EM;
  }

  /**
   * Axis-aligned box centred on (cx, cy).
   * @returns {{x0:number,y0:number,x1:number,y1:number}}
   */
  function boxAt(cx, cy, width, height) {
    return { x0: cx - width / 2, x1: cx + width / 2, y0: cy - height / 2, y1: cy + height / 2 };
  }

  /** @param {{x0:number,y0:number,x1:number,y1:number}} a @param {{x0:number,y0:number,x1:number,y1:number}} b */
  function boxesOverlap(a, b, clearance = CLEARANCE) {
    return a.x0 < b.x1 + clearance && b.x0 < a.x1 + clearance && a.y0 < b.y1 + clearance && b.y0 < a.y1 + clearance;
  }

  /** @param {{x0:number,y0:number,x1:number,y1:number}} box @param {{x:number,y:number}} p */
  function boxHasPoint(box, p) {
    return p.x >= box.x0 && p.x <= box.x1 && p.y >= box.y0 && p.y <= box.y1;
  }

  /** Segment (a-b) against an axis-aligned box, with clearance. */
  function segmentHitsBox(a, b, box, clearance = CLEARANCE) {
    const grown = { x0: box.x0 - clearance, y0: box.y0 - clearance, x1: box.x1 + clearance, y1: box.y1 + clearance };
    if (boxHasPoint(grown, a) || boxHasPoint(grown, b)) return true;
    if (Math.max(a.x, b.x) < grown.x0 || Math.min(a.x, b.x) > grown.x1) return false;
    if (Math.max(a.y, b.y) < grown.y0 || Math.min(a.y, b.y) > grown.y1) return false;
    const corners = [
      { x: grown.x0, y: grown.y0 }, { x: grown.x1, y: grown.y0 },
      { x: grown.x1, y: grown.y1 }, { x: grown.x0, y: grown.y1 },
    ];
    for (let i = 0; i < 4; i += 1) {
      if (segmentsCross(a, b, corners[i], corners[(i + 1) % 4])) return true;
    }
    return false;
  }

  /** @returns {boolean} true when segments p1-p2 and q1-q2 intersect. */
  function segmentsCross(p1, p2, q1, q2) {
    const orient = (a, b, c) => Math.sign((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x));
    const d1 = orient(q1, q2, p1);
    const d2 = orient(q1, q2, p2);
    const d3 = orient(p1, p2, q1);
    const d4 = orient(p1, p2, q2);
    return d1 * d2 < 0 && d3 * d4 < 0;
  }

  /**
   * Place labels greedily in the order given.
   * @param {{id:string,text:string,fontSize:number,anchor:{x:number,y:number}}[]} labels
   * @param {{a:{x:number,y:number},b:{x:number,y:number}}[]} segments lines a label must not cross
   * @param {{x0:number,y0:number,x1:number,y1:number}} bounds where labels may sit
   * @returns {{placed: {id:string,text:string,fontSize:number,box:object}[], unresolved: string[]}}
   */
  function placeLabels(labels, segments, bounds) {
    const placed = [];
    const unresolved = [];
    for (const label of labels) {
      const width = textWidth(label.text, label.fontSize);
      const height = label.fontSize * LINE_HEIGHT_EM;
      const box = findFreeBox(label.anchor, width, height, placed, segments, bounds);
      if (box === null) {
        unresolved.push(label.id);
        placed.push({ ...label, box: boxAt(label.anchor.x, label.anchor.y, width, height) });
      } else {
        placed.push({ ...label, box });
      }
    }
    return { placed, unresolved };
  }

  /** Nearest free box to the anchor, searching outward in rings. */
  function findFreeBox(anchor, width, height, placed, segments, bounds) {
    const fits = (box) => {
      if (box.x0 < bounds.x0 || box.x1 > bounds.x1 || box.y0 < bounds.y0 || box.y1 > bounds.y1) return false;
      if (placed.some((other) => boxesOverlap(box, other.box))) return false;
      return !segments.some((s) => segmentHitsBox(s.a, s.b, box));
    };
    for (let d = 0; d <= MAX_DISTANCE; d += STEP) {
      const angles = d === 0 ? [0] : DIRECTIONS;
      for (const angle of angles) {
        const box = boxAt(anchor.x + d * Math.cos(angle), anchor.y + d * Math.sin(angle), width, height);
        if (fits(box)) return box;
      }
    }
    return null;
  }

  const api = Object.freeze({
    textWidth,
    boxAt,
    boxesOverlap,
    segmentHitsBox,
    segmentsCross,
    placeLabels,
    CLEARANCE,
  });

  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP.layout = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
