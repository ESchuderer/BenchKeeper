/**
 * Hash routes: `#/` (or no hash) is the start page; `#/cartridge/<key>` is a
 * detail view. Pure parsing; the app decides what to show for unknown keys.
 */
(function (root) {
  'use strict';

  const DETAIL_PATTERN = /^#\/cartridge\/(.+)$/;

  /**
   * @param {string} hash e.g. `location.hash`
   * @returns {{view: 'list'} | {view: 'detail', key: string}}
   */
  function parseRoute(hash) {
    const match = DETAIL_PATTERN.exec(hash ?? '');
    if (!match) return { view: 'list' };
    let key;
    try {
      key = decodeURIComponent(match[1]);
    } catch {
      key = match[1];
    }
    return { view: 'detail', key };
  }

  /** @param {string} key @returns {string} */
  function routeFor(key) {
    return `#/cartridge/${encodeURIComponent(key)}`;
  }

  const api = Object.freeze({ parseRoute, routeFor });

  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP.router = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
