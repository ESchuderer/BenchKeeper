'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../src/catalog.js');
const R = require('../src/router.js');
const records = require('../data/cartridges.js');

const names = (list) => list.map((r) => r.name);

test('an empty search lists all 25 cartridges and reads "25 cartridges"', () => {
  const listed = C.filterRecords(records, { query: '' });
  assert.equal(listed.length, 25);
  assert.equal(C.countText(listed.length), '25 cartridges');
});

test('"7,62 x 51" finds 308 Win. through its alternative name', () => {
  const listed = C.filterRecords(records, { query: '7,62 x 51' });
  assert.deepEqual(names(listed), ['308 Win.']);
  assert.equal(C.countText(listed.length), '1 cartridge');
});

test('search matches a substring of the name case-insensitively', () => {
  assert.deepEqual(names(C.filterRecords(records, { query: 'LAPUA' })), ['338 Lapua Mag.']);
});

test('search folds runs of whitespace', () => {
  assert.deepEqual(names(C.filterRecords(records, { query: '7,62   x 51' })), ['308 Win.']);
});

test('search with no match gives an empty list and "0 cartridges"', () => {
  const listed = C.filterRecords(records, { query: 'no such cartridge' });
  assert.equal(listed.length, 0);
  assert.equal(C.countText(0), '0 cartridges');
  assert.match(C.listHtml(listed), /No cartridge matches/);
});

test('the family filter lists only that family and "All" lists every family', () => {
  const rimfire = C.filterRecords(records, { family: 'rimfire' });
  assert.equal(rimfire.length, 3);
  assert.equal(C.countText(rimfire.length), '3 cartridges');
  assert.equal(C.filterRecords(records, { family: 'all' }).length, 25);
});

test('search and family combine', () => {
  const listed = C.filterRecords(records, { query: '308', family: 'rimless' });
  assert.deepEqual(names(listed), ['308 Win.']);
  assert.equal(C.filterRecords(records, { query: '308', family: 'belted' }).length, 0);
});

test('list entries link the exact name to the detail address with L3 and its tolerance', () => {
  const pistol = records.find((r) => r.key === '9_mm_luger');
  const html = C.listItemHtml(pistol);
  assert.match(html, /<a href="#\/cartridge\/9_mm_luger">9 mm Luger<\/a>/);
  assert.match(html, /pistol/);
  assert.match(html, /L3 <span class="num">19\.15 -0\.25 mm<\/span>/);
});

test('list HTML escapes the name', () => {
  const html = C.listItemHtml(records.find((r) => r.key === '40_s_w'));
  assert.match(html, />40 S\.&amp; W\.</);
});

test('routes: list for the root, detail for a cartridge key', () => {
  assert.deepEqual(R.parseRoute(''), { view: 'list' });
  assert.deepEqual(R.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(R.parseRoute('#/cartridge/223_rem'), { view: 'detail', key: '223_rem' });
});

test('routes: an unknown key is still a detail route for the app to reject', () => {
  assert.deepEqual(R.parseRoute('#/cartridge/unknown'), { view: 'detail', key: 'unknown' });
});

test('routes: percent-encoded keys decode, malformed ones keep their text', () => {
  assert.deepEqual(R.parseRoute('#/cartridge/9%5Fmm_luger'), { view: 'detail', key: '9_mm_luger' });
  assert.deepEqual(R.parseRoute('#/cartridge/%E0%A4%A'), { view: 'detail', key: '%E0%A4%A' });
});

test('routeFor and detailHref agree on the address format', () => {
  assert.equal(R.routeFor('223_rem'), '#/cartridge/223_rem');
  assert.equal(C.detailHref('223_rem'), '#/cartridge/223_rem');
});
