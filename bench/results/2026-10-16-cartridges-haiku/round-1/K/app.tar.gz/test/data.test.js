'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const records = require('../data/cartridges.js');

// Golden values typed from the brief, independently of the data file.
// [key, name, family, tab, revised, L3, L6, Pmax, G1]
const GOLDEN = [
  ['223_rem', '223 Rem.', 'rimless', 'I', '2017-05-17', 44.7, 57.4, 4300, 5.7],
  ['243_win', '243 Win.', 'rimless', 'I', '2002-05-15', 51.94, 68.83, 4150, 6.17],
  ['6_5_creedmoor', '6,5 Creedmoor', 'rimless', 'I', '2020-04-21', 48.77, 71.76, 4350, 6.72],
  ['6_5_x_55_se', '6,5 x 55 SE', 'rimless', 'I', '2013-05-22', 55.0, 80.0, 3800, 6.71],
  ['270_win', '270 Win.', 'rimless', 'I', '2002-05-15', 64.52, 84.84, 4300, 7.06],
  ['7_x_64', '7 x 64', 'rimless', 'I', '2002-05-15', 64.0, 84.0, 4150, 7.25],
  ['308_win', '308 Win.', 'rimless', 'I', '2008-09-23', 51.18, 71.12, 4150, 7.85],
  ['30_06_spring', '30-06 Spring.', 'rimless', 'I', '2008-09-23', 63.35, 84.84, 4050, 7.85],
  ['8_x_57_is', '8 x 57 IS', 'rimless', 'I', '2016-05-18', 57.0, 82.0, 3900, 8.22],
  ['9_3_x_62', '9,3 x 62', 'rimless', 'I', '2002-05-15', 62.0, 83.6, 3900, 9.3],
  ['338_lapua_mag', '338 Lapua Mag.', 'rimless', 'I', '2016-10-18', 69.2, 93.5, 4200, 8.61],
  ['300_win_mag', '300 Win. Mag.', 'belted', 'III', '2002-05-15', 66.55, 84.84, 4300, 7.85],
  ['7_mm_rem_mag', '7 mm Rem. Mag.', 'belted', 'III', '2002-05-15', 63.5, 83.57, 4300, 7.23],
  ['9_3_x_74_r', '9,3 x 74 R', 'rimmed', 'II', '2006-05-16', 74.7, 96.5, 3400, 9.3],
  ['7_x_65_r', '7 x 65 R', 'rimmed', 'II', '2002-05-15', 65.0, 83.6, 3800, 7.25],
  ['9_mm_luger', '9 mm Luger', 'pistol', 'IV', '2008-09-23', 19.15, 29.69, 2350, 9.03],
  ['45_auto', '45 Auto', 'pistol', 'IV', '2020-04-21', 22.81, 32.39, 1300, 11.48],
  ['40_s_w', '40 S.& W.', 'pistol', 'IV', '2000-06-07', 21.59, 28.83, 2250, 10.17],
  ['38_special', '38 Special', 'pistol', 'IV', '2000-06-07', 29.34, 39.37, 1500, 9.12],
  ['357_magnum', '357 Magnum', 'pistol', 'IV', '2006-06-14', 32.77, 40.39, 3000, 9.12],
  ['44_rem_mag', '44 Rem. Mag.', 'pistol', 'IV', '2020-11-10', 32.64, 40.89, 2800, 10.97],
  ['22_long_rifle', '22 Long Rifle', 'rimfire', 'V', '2024-05-14', 15.57, 25.4, 1700, 5.72],
  ['22_win_mag_r_f', '22 Win. Mag. R.F.', 'rimfire', 'V', '2008-09-23', 26.8, 34.29, 1600, 5.7],
  ['17_hmr', '17 HMR', 'rimfire', 'V', '2012-09-25', 27.03, 34.67, 1800, 4.38],
];

test('data holds exactly 25 records with unique keys', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
});

test('each record matches the golden fields from the brief', () => {
  const byKey = new Map(records.map((r) => [r.key, r]));
  for (const [key, name, family, tab, revised, L3, L6, Pmax, G1] of GOLDEN) {
    const r = byKey.get(key);
    assert.ok(r, `missing record ${key}`);
    assert.equal(r.name, name, `${key} name`);
    assert.equal(r.family, family, `${key} family`);
    assert.equal(r.tab, tab, `${key} tab`);
    assert.equal(r.revised, revised, `${key} revised`);
    assert.equal(r.cartridge.lengths.L3, L3, `${key} L3`);
    assert.equal(r.cartridge.lengths.L6, L6, `${key} L6`);
    assert.equal(r.cartridge.pressures.Pmax, Pmax, `${key} Pmax`);
    assert.equal(r.cartridge.projectile.G1, G1, `${key} G1`);
  }
});

test('every record has the cartridge and chamber sections the views rely on', () => {
  for (const r of records) {
    assert.ok(r.cartridge.caseHead, `${r.key} caseHead`);
    assert.ok(r.cartridge.lengths.L3 !== undefined, `${r.key} L3`);
    assert.ok(r.cartridge.pressures.Pmax !== undefined, `${r.key} Pmax`);
    assert.ok(r.chamber.lengths.L3 !== undefined, `${r.key} chamber L3`);
    assert.ok(r.annotations.defaultBulletShape, `${r.key} bullet shape`);
  }
});

test('families are the five the filter offers', () => {
  const families = new Set(records.map((r) => r.family));
  assert.deepEqual([...families].sort(), ['belted', 'pistol', 'rimfire', 'rimless', 'rimmed']);
});
