'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const Detail = require('../src/detail.js');
const D = require('../src/drawing.js');
const records = require('../data/cartridges.js');

const detailOf = (key) => {
  const record = records.find((r) => r.key === key);
  return Detail.detailHtml(record, D.buildDrawing(record));
};

test('the heading is the cartridge name and the start page has "Cartridges"', () => {
  assert.match(detailOf('308_win'), /<h1>308 Win\.<\/h1>/);
  assert.match(Detail.listShellHtml(), /<h1>Cartridges<\/h1>/);
});

test('the identity block lists alternative names, family, category, primer, table, country, dates, pressure method', () => {
  const html = detailOf('308_win');
  assert.match(html, /<dt>Alternative names<\/dt><dd>308 Winchester, 7,62 x 51<\/dd>/);
  assert.match(html, /<dt>Family<\/dt><dd>rimless<\/dd>/);
  assert.match(html, /<dt>Category<\/dt><dd>rifle<\/dd>/);
  assert.match(html, /<dt>Primer type<\/dt><dd>lr<\/dd>/);
  assert.match(html, /<dt>C\.I\.P\. table<\/dt><dd>I<\/dd>/);
  assert.match(html, /<dt>Country<\/dt><dd>US<\/dd>/);
  assert.match(html, /<dt>Published<\/dt><dd><span class="num">1984-06-14<\/span><\/dd>/);
  assert.match(html, /<dt>Revised<\/dt><dd><span class="num">2008-09-23<\/span><\/dd>/);
  assert.match(html, /<dt>Pressure method<\/dt><dd>Transducer<\/dd>/);
});

test('the water capacity shows its unit, source link and note', () => {
  const html = detailOf('308_win');
  assert.match(html, /<span class="num">56 grH2O<\/span> · source <a href="http:\/\/kwk\.us\/cases\.html" rel="noopener">kwk<\/a> · Lapua brass measures 55\.8 \(lapua-308\)/);
});

test('a record without publishedCapacity says so', () => {
  assert.match(detailOf('7_x_64'), /<dt>Water capacity<\/dt><dd>not published<\/dd>/);
});

test('a record without alternative names says "none"', () => {
  assert.match(detailOf('223_rem'), /<dt>Alternative names<\/dt><dd>none<\/dd>/);
});

test('value tables are grouped under Cartridge and Chamber with Symbol, Value and Unit columns', () => {
  const html = detailOf('308_win');
  assert.match(html, /<h2>Cartridge<\/h2>/);
  assert.match(html, /<h2>Chamber<\/h2>/);
  assert.equal((html.match(/<th scope="col">Symbol<\/th><th scope="col">Value<\/th><th scope="col">Unit<\/th>/g) ?? []).length > 10, true);
});

test('Pmax of 308 Win. reads 4150 in bar, and tolerances sit beside their values', () => {
  const html = detailOf('308_win');
  assert.match(html, /<th scope="row">Pmax<\/th><td class="num">4150<\/td><td>bar<\/td>/);
  assert.match(html, /<th scope="row">L1<\/th><td class="num">39\.62 -0\.2<\/td><td>mm<\/td>/);
  assert.equal(html.includes('L1Tol'), false);
});

test('Greek and renamed symbols appear in the tables', () => {
  const html = detailOf('223_rem');
  assert.match(html, /<th scope="row">β<\/th>/);
  assert.match(html, /<th scope="row">e min<\/th>/);
  assert.match(html, /<th scope="row">α1<\/th>/);
});

test('the drawing is inline SVG with the accessible name', () => {
  const html = detailOf('223_rem');
  assert.match(html, /<svg [^>]*aria-label="223 Rem\. drawing"/);
});

test('the toolbar has a Print button and an "All cartridges" link to the start page', () => {
  const html = detailOf('223_rem');
  assert.match(html, /<button type="button" id="print-button">Print<\/button>/);
  assert.match(html, /<a href="#\/">All cartridges<\/a>/);
});

test('the footer names the source and the revised date', () => {
  assert.match(detailOf('7_62_x_39'), /Source: C\.I\.P\. TDCC, revised <span class="num">2013-05-22<\/span>/);
});

test('missing values are listed under the drawing', () => {
  const record = JSON.parse(JSON.stringify(records.find((r) => r.key === '223_rem')));
  delete record.cartridge.junctionCone.r1Min;
  const html = Detail.detailHtml(record, D.buildDrawing(record));
  assert.match(html, /<ul class="drawing-notes"><li>r1 min not published/);
});

test('the not-found message names the key and links back', () => {
  const html = Detail.notFoundHtml('nope<');
  assert.match(html, /<h1>Cartridge not found<\/h1>/);
  assert.match(html, /<code>nope&lt;<\/code>/);
  assert.match(html, /<a href="#\/">All cartridges<\/a>/);
});

test('the list shell has the Search and Family controls with labels', () => {
  const html = Detail.listShellHtml();
  assert.match(html, /<label for="search-input">Search<\/label>/);
  assert.match(html, /<label for="family-select">Family<\/label>/);
  for (const option of ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']) {
    assert.match(html, new RegExp(`<option value="[a-z]*">${option}</option>`));
  }
});

test('results: the count text and list follow the criteria', () => {
  const { count, list } = Detail.resultsHtml(records, { query: '7,62 x 51', family: 'all' });
  assert.equal(count, '1 cartridge');
  assert.match(list, /<a href="#\/cartridge\/308_win">308 Win\.<\/a>/);
});
