'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../src/drawing.js');
const L = require('../src/layout.js');
const records = require('../data/cartridges.js');

const drawingOf = (key) => D.buildDrawing(records.find((r) => r.key === key));

test('every record produces a drawing with its accessible name', () => {
  for (const record of records) {
    const d = D.buildDrawing(record);
    assert.equal(d.drawable, true, `${record.key} drawable`);
    const escaped = record.name.replace(/&/g, '&amp;');
    assert.ok(d.svg.includes(`aria-label="${escaped} drawing"`), `${record.key} aria-label`);
  }
});

test('the viewBox is in millimetres and starts at the head side', () => {
  const d = drawingOf('223_rem');
  assert.match(d.svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/);
  assert.ok(d.viewBox.width > 57.4, 'wide enough for the overall length');
  assert.ok(d.viewBox.x < 0, 'margin for the diameter dimension at the head');
});

test('the outside view is drawn above the axis and the section below it', () => {
  const d = drawingOf('308_win');
  const outline = /<path class="outline" d="([^"]+)"/.exec(d.svg);
  assert.ok(outline, 'outline path exists');
  const ys = [...outline[1].matchAll(/[ML]([-\d.]+) ([-\d.]+)/g)].map((m) => Number(m[2]));
  assert.ok(ys.every((y) => y <= 0), 'outside view is on or above the axis');
  assert.ok(ys.some((y) => y < -1), 'outside view has height above the axis');
  const section = /<path class="section" d="M([-\d.]+) ([-\d.]+)/.exec(d.svg);
  assert.ok(section, 'section path exists');
  assert.ok(d.svg.includes('fill="url(#hatch-308_win)"'), 'cut walls are hatched');
});

test('a dash-dot centre line is on the axis', () => {
  const d = drawingOf('9_mm_luger');
  assert.match(d.svg, /class="centre-line" d="M-8 0 L[-\d.]+ 0"/);
  assert.match(d.svg, /stroke-dasharray="7 1\.2 1\.2 1\.2"/);
});

test('dimensions for L3, L6, R1, R, P1 and the bottleneck items are labelled with symbol and value', () => {
  const d = drawingOf('223_rem');
  const ids = new Set(d.labels.map((l) => l.id));
  for (const id of ['L3', 'L6', 'R1', 'R', 'P1', 'P2', 'H1', 'H2', 'G1', 'L1', 'L2', 'E1', 'alpha']) {
    assert.ok(ids.has(id), `label ${id}`);
  }
  const texts = d.labels.map((l) => l.text);
  assert.ok(texts.includes('L3 44.7'), 'L3 44.7');
  assert.ok(texts.includes('L1 36.52 -0.2'), 'tolerance beside the value');
  assert.ok(texts.includes('α 46°'), 'shoulder angle');
});

test('a straight pistol case gets no shoulder or P2 dimension', () => {
  const ids = new Set(drawingOf('38_special').labels.map((l) => l.id));
  assert.equal(ids.has('P2'), false);
  assert.equal(ids.has('L1'), false);
  assert.equal(ids.has('alpha'), false);
  assert.ok(ids.has('L3'));
});

test('the title block carries name, table, revision, rim type, units and scale bar', () => {
  const d = drawingOf('308_win');
  assert.match(d.svg, />308 Win\.</);
  assert.match(d.svg, /C\.I\.P\. table I · revised 2008-09-23/);
  assert.match(d.svg, /Rim type: rimless · Dimensions in mm/);
  assert.match(d.svg, /10 mm/);
});

test('the title block sits inside the viewBox', () => {
  for (const record of records) {
    const d = D.buildDrawing(record);
    const { x, y, width, height } = d.viewBox;
    const rect = /<rect x="([-\d.]+)" y="([-\d.]+)" width="([\d.]+)" height="([\d.]+)"/.exec(d.svg);
    assert.ok(rect, `${record.key} title rect`);
    assert.ok(Number(rect[1]) + Number(rect[3]) <= x + width, `${record.key} title fits width`);
    assert.ok(Number(rect[2]) + Number(rect[4]) <= y + height, `${record.key} title fits height`);
  }
});

test('a missing G1 still draws the outside view and names what is missing', () => {
  const record = JSON.parse(JSON.stringify(records.find((r) => r.key === '223_rem')));
  delete record.cartridge.projectile.G1;
  const d = D.buildDrawing(record);
  assert.equal(d.drawable, true);
  assert.ok(d.notes.some((n) => /G1 not published/.test(n)));
  assert.equal(d.svg.includes('class="section"'), false);
});

test('label text is escaped before it goes into the SVG', () => {
  const d = drawingOf('40_s_w');
  assert.match(d.svg, /40 S\.&amp; W\./);
  assert.equal(d.svg.includes('40 S.& W.'), false);
});

test('labelText formats symbol, value and optional tolerance', () => {
  assert.equal(D.labelText('L3', 51.18), 'L3 51.18');
  assert.equal(D.labelText('L3', 19.15, -0.25), 'L3 19.15 -0.25');
});

test('arrowheads point away from the middle of the dimension', () => {
  const path = D.arrowPath({ x: 10, y: 0 }, { x: 0, y: 0 });
  assert.match(path, /^M10 0 /);
  assert.match(path, / Z$/);
});

test('label collision helpers agree on overlapping and separated boxes', () => {
  const a = L.boxAt(0, 0, 4, 2);
  assert.equal(L.boxesOverlap(a, L.boxAt(3, 0, 4, 2)), true);
  assert.equal(L.boxesOverlap(a, L.boxAt(10, 0, 4, 2)), false);
  assert.equal(L.segmentHitsBox({ x: -5, y: 0 }, { x: 5, y: 0 }, a), true);
  assert.equal(L.segmentHitsBox({ x: -5, y: 5 }, { x: 5, y: 5 }, a), false);
});
