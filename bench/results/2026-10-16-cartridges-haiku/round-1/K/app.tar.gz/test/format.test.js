'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../src/format.js');
const records = require('../data/cartridges.js');

const byKey = (key) => records.find((r) => r.key === key);

test('angles show as degrees or degrees, minutes and seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(F.formatAngle({ degrees: 50, minutes: 35, seconds: 2 }), `50°35'02"`);
});

test('angles convert to decimal degrees for geometry', () => {
  assert.equal(F.angleToDegrees(46), 46);
  assert.equal(F.angleToDegrees({ degrees: 1, minutes: 30, seconds: 0 }), 1.5);
});

test('numbers show as published with a decimal point and no grouping', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(-0.2), '-0.2');
});

test('symbols use the published names from the brief', () => {
  assert.equal(F.symbolOf('eMin'), 'e min');
  assert.equal(F.symbolOf('r1Min'), 'r1 min');
  assert.equal(F.symbolOf('r1Max'), 'r1 max');
  assert.equal(F.symbolOf('alpha'), 'α');
  assert.equal(F.symbolOf('alpha1'), 'α1');
  assert.equal(F.symbolOf('beta'), 'β');
  assert.equal(F.symbolOf('delta'), 'δ');
  assert.equal(F.symbolOf('deltaL'), 'delta L');
  assert.equal(F.symbolOf('L3PlusG'), 'L3 + G');
  assert.equal(F.symbolOf('E1'), 'E1');
});

test('units follow the brief; counts and unstated units stay empty', () => {
  assert.equal(F.unitOf('L3'), 'mm');
  assert.equal(F.unitOf('E1'), 'mm');
  assert.equal(F.unitOf('Pmax'), 'bar');
  assert.equal(F.unitOf('PK'), 'bar');
  assert.equal(F.unitOf('EE'), 'J');
  assert.equal(F.unitOf('M'), 'g');
  assert.equal(F.unitOf('Q'), 'mm²');
  assert.equal(F.unitOf('N'), '');
  assert.equal(F.unitOf('S'), '');
  assert.equal(F.unitOf('u'), '');
  assert.equal(F.unitOf('alpha'), '');
});

test('formatValue shows angle keys as angles and other keys as numbers', () => {
  assert.equal(F.formatValue('alpha', { degrees: 50, minutes: 35, seconds: 2 }), `50°35'02"`);
  assert.equal(F.formatValue('i', 3), '3°');
  assert.equal(F.formatValue('L1', 36.52), '36.52');
});

test('section rows attach tolerances to their value and never get their own row', () => {
  const sections = F.buildSections(byKey('223_rem'));
  const lengths = sections.cartridge.find((s) => s.id === 'lengths');
  const l1 = lengths.rows.find((row) => row.key === 'L1');
  assert.deepEqual(l1, { key: 'L1', symbol: 'L1', value: '36.52 -0.2', unit: 'mm' });
  assert.equal(lengths.rows.some((row) => row.key === 'L1Tol'), false);
});

test('section rows show the angle and count forms from the brief', () => {
  const sections = F.buildSections(byKey('223_rem'));
  const caseHead = sections.cartridge.find((s) => s.id === 'caseHead');
  const beta = caseHead.rows.find((row) => row.key === 'beta');
  assert.equal(beta.symbol, 'β');
  assert.equal(beta.value, '35°');
  const grooves = sections.chamber.find((s) => s.id === 'grooves');
  assert.equal(grooves.rows.find((row) => row.key === 'N').unit, '');
  assert.equal(grooves.rows.find((row) => row.key === 'N').value, '6');
});

test('escapeHtml neutralises markup characters in names', () => {
  assert.equal(F.escapeHtml('40 S.& W.'), '40 S.&amp; W.');
  assert.equal(F.escapeHtml(`<a href="x">'`), '&lt;a href=&quot;x&quot;&gt;&#39;');
});

test('every record value appears exactly once in the tables; tolerances are merged, not listed', () => {
  for (const record of records) {
    const sections = F.buildSections(record);
    const rows = [...sections.cartridge, ...sections.chamber].flatMap((section) => section.rows);
    const leaves = [];
    for (const group of [record.cartridge, record.chamber]) {
      for (const fields of Object.values(group)) {
        for (const key of Object.keys(fields)) {
          if (!(F.isToleranceKey(key) && key.slice(0, -3) in fields)) leaves.push(key);
        }
      }
    }
    assert.equal(rows.length, leaves.length, `${record.key}: row count`);
    for (const section of [...sections.cartridge, ...sections.chamber]) {
      const keys = section.rows.map((row) => row.key);
      assert.equal(new Set(keys).size, keys.length, `${record.key} ${section.id}: duplicate rows`);
    }
  }
});
