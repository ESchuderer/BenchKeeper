'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../src/geometry.js');
const records = require('../data/cartridges.js');

const model = (key) => G.buildModel(records.find((r) => r.key === key));
const close = (actual, expected, tol = 1e-6, message = '') =>
  assert.ok(Math.abs(actual - expected) <= tol, `${message} expected ${expected}, got ${actual}`);
const near = (point, z, r, tol = 1e-6) => {
  close(point.z, z, tol, 'z');
  close(point.r, r, tol, 'r');
};

test('rim type: family decides belted and rimfire; otherwise the R1/P1 ratio', () => {
  assert.equal(model('7_x_65_r').rim, 'rimmed', '7 x 65 R: R1/P1 = 1.12');
  assert.equal(model('22_long_rifle').rim, 'rimfire');
  assert.equal(model('300_win_mag').rim, 'belted');
  assert.equal(model('223_rem').rim, 'rimless', '223 Rem.: R1/P1 = 1.00');
  assert.equal(model('9_mm_luger').rim, 'rimless', '9 mm Luger: R1/P1 = 1.00');
  assert.equal(model('38_special').rim, 'rimmed', '38 Special: R1/P1 = 1.16');
});

test('rim type of a rebated case when R1/P1 is below 0.98', () => {
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 9, R: 1 }, powderChamber: { P1: 10 } } }), 'rebated');
});

test('head face: chamfer from R1/2 − f·tan β to (R1/2, f) for 7 x 65 R', () => {
  const m = model('7_x_65_r');
  const head = m.outer.slice(0, 3);
  near(head[0], 0, 0);
  near(head[1], 0, 13.32 / 2 - 0.3 * Math.tan(Math.PI / 4), 1e-6);
  near(head[2], 0.3, 13.32 / 2, 1e-6);
});

test('rimfire rim is a half-round of radius min(R/2, (R1−P1)/2) reaching R1/2', () => {
  const m = model('22_long_rifle');
  const rr = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  close(rr, 0.545, 1e-9);
  const outermost = m.outer.reduce((best, p) => (p.r > best.r ? p : best));
  close(outermost.r, 7.06 / 2, 1e-6, 'outermost radius');
  close(outermost.z, rr, 1e-6, 'outermost z');
});

test('223 Rem. groove: floor at diameter E1 from z = R to R + eMin, ramp to (P1/2, E)', () => {
  const m = model('223_rem');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 1.14) < 1e-9 && Math.abs(p.r - 8.43 / 2) < 1e-9), 'step in at z = R');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 1.9) < 1e-9 && Math.abs(p.r - 8.43 / 2) < 1e-9), 'floor end at z = 1.90');
  const body = m.outer.find((p) => Math.abs(p.z - 3.13) < 1e-9);
  near(body, 3.13, 9.58 / 2);
});

test('belted groove: ramp at δ to the axis up to R3/2, belt to z = E, then step to P1/2', () => {
  const m = model('300_win_mag');
  const delta = (35 * Math.PI) / 180;
  const rampEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(delta);
  assert.ok(m.outer.some((p) => Math.abs(p.z - rampEnd) < 1e-6 && Math.abs(p.r - 13.51 / 2) < 1e-9), 'ramp reaches the belt');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 5.59) < 1e-9 && Math.abs(p.r - 13.51 / 2) < 1e-9), 'belt reaches z = E');
  assert.ok(m.outer.some((p) => Math.abs(p.z - 5.59) < 1e-9 && Math.abs(p.r - 13.03 / 2) < 1e-9), 'step to P1/2 at E');
  assert.equal(m.anchors.beltRampEnd.toFixed(3), rampEnd.toFixed(3));
});

test('223 Rem. shoulder runs at alpha/2 = 23° to the axis between the published points', () => {
  const m = model('223_rem');
  const body = m.vertices.find((v) => v.role === 'shoulderStart');
  const neck = m.vertices.find((v) => v.role === 'neck');
  near(body, 36.52, 9.0 / 2);
  near(neck, 39.55, 6.43 / 2);
  const angle = Math.atan2(body.r - neck.r, neck.z - body.z) * (180 / Math.PI);
  close(angle, 23.0, 0.05, 'shoulder angle');
  close(2 * angle, 46.0, 0.1, 'included angle');
});

test('a case without L1 or alpha is straight from the body start to the mouth', () => {
  const m = model('9_mm_luger');
  assert.equal(m.bottleneck, false);
  const last = m.outer[m.outer.length - 1];
  near(last, 19.15, 9.65 / 2);
  assert.equal(m.vertices.some((v) => v.role === 'shoulderStart'), false);
});

test('223 Rem. shoulder corners are rounded with r1 min 0.64 and r2 2.54 as tangent arcs', () => {
  const m = model('223_rem');
  assert.equal(m.fillets.length, 2);
  for (const fillet of m.fillets) {
    assert.ok(fillet.points.length > 3, 'arc has samples');
    close(fillet.radius, fillet.role === 'shoulderStart' ? 0.64 : 2.54, 1e-9);
  }
});

test('bullet of 223 Rem.: pointy, base at L3 − G1 = 39.0, tip at L6 = 57.4', () => {
  const b = model('223_rem').bullet;
  close(b.s, 5.7, 1e-9, 's');
  close(b.zb, 39.0, 1e-6, 'zb');
  close(b.zs, 39.0 + 0.4 * (57.4 - 39.0), 1e-6, 'cylinder end');
  const tip = b.outline[b.outline.length - 2];
  near(tip, 57.4, 1.27 / 2);
  assert.equal(b.m, 1.27);
});

test('pointy ogive meets the cylinder tangentially (dz/dr = 0 at the start)', () => {
  const b = model('223_rem').bullet;
  const first = b.nose[0];
  const second = b.nose[1];
  assert.ok(second.z > first.z, 'moves along the axis');
  assert.ok(Math.abs(second.r - first.r) < 0.01 * (second.z - first.z), 'tangent to the cylinder at the start');
});

test('rounded pistol bullet: base at 0.4·G1 below the mouth, quarter-ellipse tip of diameter 0.15·G1', () => {
  const b = model('9_mm_luger').bullet;
  close(b.s, 0.4 * 9.03, 1e-9, 's');
  close(b.k, 0.65, 1e-9, 'k');
  const tip = b.nose[b.nose.length - 1];
  near(tip, 29.69, 0.15 * 9.03 / 2);
});

test('heeled 22 Long Rifle: exposed bullet has the case outside diameter H2', () => {
  const m = model('22_long_rifle');
  assert.equal(m.heeled, true);
  close(m.bullet.Rexp, 5.72 / 2, 1e-9, 'exposed radius');
  close(m.walls.tb, 0.6, 1e-9, 'tb');
  close(m.bullet.Rseat, 5.72 / 2 - m.walls.tb, 1e-9, 'heel radius H2/2 − tb');
});

test('walls of 223 Rem.: tn 0.365, tb 0.6, solid head to w = 4.54', () => {
  const m = model('223_rem');
  close(m.walls.tn, 0.365, 1e-9, 'tn');
  close(m.walls.tb, 0.6, 1e-9, 'tb');
  close(m.w, 4.54, 1e-9, 'w');
});

test('primer pocket: lr is 5.33 by 3.3; sr is 4.45 by 3.04; rimfire has none', () => {
  assert.deepEqual(model('308_win').pocket, { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(model('223_rem').pocket, { diameter: 4.45, depth: 3.04 });
  assert.equal(model('22_long_rifle').pocket, null);
});

test('a missing value is named in the notes and never invented', () => {
  const r = JSON.parse(JSON.stringify(records.find((x) => x.key === '223_rem')));
  delete r.cartridge.junctionCone.r1Min;
  const m = G.buildModel(r);
  assert.ok(m.notes.some((n) => /r1 min not published/.test(n)));
  assert.equal(m.fillets.length, 1);
});

test('a missing G1 leaves out the bullet and says so', () => {
  const r = JSON.parse(JSON.stringify(records.find((x) => x.key === '223_rem')));
  delete r.cartridge.projectile.G1;
  const m = G.buildModel(r);
  assert.equal(m.bullet, null);
  assert.ok(m.notes.some((n) => /G1 not published/.test(n)));
});

test('every record builds without throwing and has a finite outline', () => {
  for (const record of records) {
    const m = G.buildModel(record);
    assert.ok(m.outer.length >= 4, `${record.key} outline`);
    for (const p of m.outer) {
      assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r), `${record.key} finite`);
    }
    assert.ok(m.section.length >= 6, `${record.key} section`);
  }
});

test('belted cases take both the groove term E + tb and the belt term in the solid head depth w', () => {
  const m = model('300_win_mag');
  close(m.walls.tb, 0.6, 1e-9, 'tb');
  close(m.w, 5.59 + 0.6, 1e-9, 'w = E + tb');
  assert.ok(m.section === null || m.section.every((p) => p.z >= 0), 'section stays in the head');
});

test('a solid head that would reach the mouth leaves the section out and says so', () => {
  const r = JSON.parse(JSON.stringify(records.find((x) => x.key === '223_rem')));
  r.cartridge.lengths.L3 = 4;
  const m = G.buildModel(r);
  assert.equal(m.section, null);
  assert.ok(m.notes.some((n) => /Solid head reaches the mouth/.test(n)));
});
