'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../src/drawing.js');
const L = require('../src/layout.js');
const records = require('../data/cartridges.js');

test('for all 25 records no two dimension labels overlap', () => {
  for (const record of records) {
    const { labels } = D.buildDrawing(record);
    for (let i = 0; i < labels.length; i += 1) {
      for (let j = i + 1; j < labels.length; j += 1) {
        const overlap = L.boxesOverlap(labels[i].box, labels[j].box, 0);
        assert.equal(overlap, false, `${record.key}: ${labels[i].id} overlaps ${labels[j].id}`);
      }
    }
  }
});

test('for all 25 records no label touches the outline, a section or a dimension line', () => {
  for (const record of records) {
    const { labels, segments } = D.buildDrawing(record);
    for (const label of labels) {
      for (const segment of segments) {
        const hit = L.segmentHitsBox(segment.a, segment.b, label.box, 0);
        assert.equal(hit, false, `${record.key}: ${label.id} touches a drawn line`);
      }
    }
  }
});

test('for all 25 records every label lies inside the viewBox', () => {
  for (const record of records) {
    const { labels, viewBox } = D.buildDrawing(record);
    for (const label of labels) {
      assert.ok(label.box.x0 >= viewBox.x && label.box.x1 <= viewBox.x + viewBox.width, `${record.key}: ${label.id} x`);
      assert.ok(label.box.y0 >= viewBox.y && label.box.y1 <= viewBox.y + viewBox.height, `${record.key}: ${label.id} y`);
    }
  }
});

test('no label is left unresolved in any record', () => {
  for (const record of records) {
    assert.deepEqual(D.buildDrawing(record).unresolved, [], record.key);
  }
});
