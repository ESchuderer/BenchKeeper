var CIP = CIP || {};

CIP.app = (function () {
  var M = CIP.model;
  var FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var state = { q: '', family: 'all' };
  var app = document.getElementById('app');

  function el(tag, props, kids) {
    var node = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      if (k === 'text') node.textContent = props[k];
      else if (k === 'className') node.className = props[k];
      else if (k === 'onClick') node.addEventListener('click', props[k]);
      else node.setAttribute(k, props[k]);
    });
    (kids || []).forEach(function (kid) {
      if (kid === null || kid === undefined) return;
      node.appendChild(typeof kid === 'string' ? document.createTextNode(kid) : kid);
    });
    return node;
  }

  function keyFromHash(text) {
    try { return decodeURIComponent(text); } catch (e) { return null; }
  }

  function byKey(key) {
    return CIP_CARTRIDGES.filter(function (r) { return r.key === key; })[0];
  }

  function listItem(r) {
    return el('li', {}, [
      el('a', { href: '#/cartridge/' + encodeURIComponent(r.key), text: r.name }),
      el('span', { className: 'family', text: r.family }),
      el('span', { className: 'l3', text: 'L3 ' + r.cartridge.lengths.L3 + ' mm' })
    ]);
  }

  function renderList() {
    var search = el('input', { type: 'search', id: 'q', autocomplete: 'off', value: state.q });
    var family = el('select', { id: 'family' }, FAMILIES.map(function (f) {
      return el('option', { value: f, text: f === 'all' ? 'All' : f });
    }));
    family.value = state.family;
    var count = el('p', { className: 'count', 'aria-live': 'polite' });
    var list = el('ul', { className: 'cartridge-list' });

    function update() {
      var shown = CIP_CARTRIDGES.filter(function (r) {
        return (state.family === 'all' || r.family === state.family) && M.matches(r, state.q);
      });
      list.textContent = '';
      shown.forEach(function (r) { list.appendChild(listItem(r)); });
      count.textContent = shown.length + (shown.length === 1 ? ' cartridge' : ' cartridges');
    }
    search.addEventListener('input', function () { state.q = search.value; update(); });
    family.addEventListener('change', function () { state.family = family.value; update(); });

    app.replaceChildren(
      el('h1', { text: 'Cartridges' }),
      el('div', { className: 'filters' }, [
        el('label', { 'for': 'q', text: 'Search' }), search,
        el('label', { 'for': 'family', text: 'Family' }), family
      ]),
      count,
      list
    );
    update();
  }

  function fact(term, value) {
    return [el('dt', { text: term }), el('dd', {}, Array.isArray(value) ? value : [value])];
  }

  function capacity(rec) {
    var pc = rec.annotations.publishedCapacity;
    if (!pc) return 'not published';
    var parts = [pc.grH2O + " gr H2O"];
    if (pc.note) parts.push(" (" + pc.note + ")");
    parts.push(" source: ", el("a", { href: pc.url, text: pc.source }));
    return parts;
  }

  function dataTables(rec, side, heading) {
    var nodes = [el('h2', { text: heading })];
    M.sections(rec, side).forEach(function (sec) {
      nodes.push(el('table', { className: 'values' }, [
        el('caption', { text: sec.title }),
        el('thead', {}, [el('tr', {}, [el('th', { scope: 'col', text: 'Symbol' }), el('th', { scope: 'col', text: 'Value' }), el('th', { scope: 'col', text: 'Unit' })])]),
        el('tbody', {}, sec.rows.map(function (row) {
          return el('tr', {}, [el('td', { text: row.symbol }), el('td', { className: 'num', text: row.value }), el('td', { text: row.unit })]);
        }))
      ]));
    });
    return nodes;
  }

  function renderDetail(rec) {
    var geo = null;
    var drawing = el('figure', { className: 'drawing' });
    try {
      geo = CIP.geometry.build(rec);
      drawing.innerHTML = CIP.drawing.draw(rec, geo).svg;
    } catch (e) {
      drawing.textContent = 'Drawing not available: ' + e.message;
    }
    var titleBlock = el('div', { className: 'titleblock' }, [
      el('p', { className: 'tb-name', text: rec.name }),
      el('p', { text: 'C.I.P. table ' + rec.tab }),
      el('p', { text: 'Revised ' + rec.revised }),
      el('p', { text: 'Dimensions in mm' }),
      el('p', { text: 'Scale 1:1, fitted to width' })
    ]);
    var notes = geo && geo.notes.length ? el('ul', { className: 'notes' }, geo.notes.map(function (t) {
      return el('li', { text: t });
    })) : null;

    var facts = el('dl', { className: 'facts' }, [].concat(
      fact('Alternative names', (rec.alternativeNames || []).join(', ') || 'none'),
      fact('Family', rec.family),
      fact('Category', rec.annotations.category),
      fact('Primer type', rec.annotations.primerType),
      fact('C.I.P. table', rec.tab),
      fact('Country', rec.country),
      fact('Published', rec.published),
      fact('Revised', rec.revised),
      fact('Pressure method', rec.pressureMethod),
      fact('Water capacity', capacity(rec))
    ));

    app.replaceChildren(
      el('nav', { className: 'toolbar screen-only' }, [
        el('a', { href: '#/', text: 'All cartridges' }),
        el('button', { type: 'button', text: 'Print', onClick: function () { window.print(); } })
      ]),
      el('article', { className: 'detail' }, [
        el('h1', { text: rec.name }),
        facts,
        drawing,
        titleBlock,
        notes,
        el('div', { className: 'tables' }, dataTables(rec, 'cartridge', 'Cartridge').concat(dataTables(rec, 'chamber', 'Chamber'))),
        el('p', { className: 'print-footer print-only', text: 'Source: C.I.P. TDCC, revised ' + rec.revised })
      ])
    );
    document.title = rec.name + ': C.I.P. reference';
  }

  function renderMissing() {
    app.replaceChildren(
      el('h1', { text: 'Cartridge not found' }),
      el('p', {}, [el('a', { href: '#/', text: 'All cartridges' })])
    );
    document.title = 'Cartridges: C.I.P. reference';
  }

  function route() {
    var m = /^#\/cartridge\/(.+)$/.exec(location.hash);
    if (!m) { renderList(); document.title = 'Cartridges: C.I.P. reference'; window.scrollTo(0, 0); return; }
    var rec = byKey(keyFromHash(m[1]));
    if (rec) renderDetail(rec); else renderMissing();
    window.scrollTo(0, 0);
  }

  return { route: route };
})();

window.addEventListener('hashchange', CIP.app.route);
CIP.app.route();
