var CIP = CIP || {};

CIP.drawing = (function () {
  var M = CIP.model, GEO = CIP.geometry;
  var F = 3.4, ARROW = 2.4, HALF = 0.8, GAP = 0.5, ROW = 6.5;

  function n(v) { return Math.round(v * 1000) / 1000; }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function textWidth(s) { return s.length * F * 0.6; }
  function fmt(obj, field) {
    var text = String(obj[field]);
    if (obj[field + 'Tol'] !== undefined) text += ' ' + obj[field + 'Tol'];
    return M.symbol(field) + ' ' + text;
  }
  function pts(list, sy) {
    return list.map(function (p) { return n(p[0]) + ',' + n(sy * p[1]); }).join(' ');
  }

  function draw(rec, g) {
    var c = rec.cartridge, L = c.lengths, H = c.caseHead, Co = c.collar, PC = c.powderChamber;
    var P = c.projectile, J = c.junctionCone || {}, info = g.info, up = g.outline, rMax = info.rMax;
    var lines = [], arrows = [], labels = [], boxes = [], box = [Infinity, Infinity, -Infinity, -Infinity];

    function track(x, y) {
      box[0] = Math.min(box[0], x); box[1] = Math.min(box[1], y);
      box[2] = Math.max(box[2], x); box[3] = Math.max(box[3], y);
    }
    function seg(x1, y1, x2, y2) {
      lines.push('<line x1="' + n(x1) + '" y1="' + n(y1) + '" x2="' + n(x2) + '" y2="' + n(y2) + '"/>');
      track(x1, y1); track(x2, y2);
    }
    function arrow(x, y, dx, dy) {
      var bx = x - ARROW * dx, by = y - ARROW * dy, px = -dy, py = dx;
      arrows.push('<polygon points="' + pts([[x, y], [bx + HALF * px, by + HALF * py], [bx - HALF * px, by - HALF * py]], 1) + '"/>');
      track(x, y);
    }
    function hLabel(x, y, s, anchor) {
      var w = textWidth(s) + 1, x0 = anchor === 'start' ? x - 0.5 : x - w / 2;
      labels.push('<rect class="halo" x="' + n(x0) + '" y="' + n(y - F / 2 - 0.5) + '" width="' + n(w) + '" height="' + n(F + 1) + '"/>' +
        '<text x="' + n(x) + '" y="' + n(y) + '" text-anchor="' + anchor + '" dominant-baseline="central">' + esc(s) + '</text>');
      boxes.push([x0, y - F / 2 - 0.5, x0 + w, y + F / 2 + 0.5]);
      track(x0, y - F / 2 - 0.5); track(x0 + w, y + F / 2 + 0.5);
    }
    function vLabel(x, y, s) {
      var len = textWidth(s) + 1;
      labels.push('<rect class="halo" x="' + n(x - (F + 1) / 2) + '" y="' + n(y - len / 2) + '" width="' + n(F + 1) + '" height="' + n(len) + '"/>' +
        '<text transform="rotate(-90 ' + n(x) + ' ' + n(y) + ')" x="' + n(x) + '" y="' + n(y) + '" text-anchor="middle" dominant-baseline="central">' + esc(s) + '</text>');
      boxes.push([x - (F + 1) / 2, y - len / 2, x + (F + 1) / 2, y + len / 2]);
      track(x - (F + 1) / 2, y - len / 2); track(x + (F + 1) / 2, y + len / 2);
    }
    function rAt(z) { return GEO.radiusAt(up, z); }

    // Horizontal length dimension above (sign -1) or below (sign +1) the outline.
    function hDim(z1, z2, y, sign, s, anchor) {
      seg(z1, y, z2, y);
      arrow(z1, y, -1, 0); arrow(z2, y, 1, 0);
      [z1, z2].forEach(function (z) {
        seg(z, sign * (rAt(z) + GAP), z, y + sign * HALF);
      });
      var cx = anchor === 'start' ? z2 + 1.5 : Math.max((z1 + z2) / 2, (textWidth(s) + 1) / 2 + 0.5);
      if (s) hLabel(cx, y + sign * (1.2 + F / 2), s, anchor || 'middle');
    }

    // Diameter dimension in a column at x; ext lines start at zRef. Label above or below the ends.
    function vDim(x, zRef, r, s, below) {
      seg(x, -r, x, r);
      arrow(x, -r, 0, -1); arrow(x, r, 0, 1);
      var dir = x < zRef ? -1 : 1;
      [-1, 1].forEach(function (sy) {
        seg(zRef, sy * (r + GAP), x + dir, sy * (r + GAP));
      });
      var reach = r + 1 + (textWidth(s) + 1) / 2;
      vLabel(x, below ? reach : -reach, s);
    }

    // Length rows above the outline, shortest nearest the case.
    var rows = ['L1', 'L2', 'L3', 'L6'].filter(function (f) { return L[f] !== undefined; });
    rows.forEach(function (f, i) {
      var y = -(rMax + 3 + i * ROW);
      hDim(0, L[f], y, -1, fmt(L, f));
    });

    // Rim thickness below the outline.
    hDim(0, H.R, rMax + 3, 1, M.symbol('R') + ' ' + H.R, 'start');

    // Shoulder angle: leader from the lower shoulder to a label below.
    if (info.bottleneck && J.alpha !== undefined) {
      var zm = (L.L1 + L.L2) / 2, yA = rMax + 9.5;
      seg(zm, rAt(zm) + GAP, zm, yA - F / 2 - GAP);
      hLabel(zm, yA, 'α ' + M.angleText(J.alpha), 'middle');
    }

    // Diameter columns: left of the head and right of the tip, largest first.
    var left = [], right = [];
    if (H.R1 !== undefined) left.push({ s: fmt(H, 'R1'), zRef: info.zRim / 2, r: H.R1 / 2 });
    if (PC.P1 !== undefined) left.push({ s: fmt(PC, 'P1'), zRef: info.zs, r: PC.P1 / 2 });
    if (info.groove && H.E1 !== undefined) left.push({ s: fmt(H, 'E1'), zRef: info.zRim + H.eMin / 2, r: H.E1 / 2 });
    if (P.G1 !== undefined) right.push({ s: fmt(P, 'G1'), zRef: info.zc, r: P.G1 / 2 });
    if (info.bottleneck && Co.H1 !== undefined) right.push({ s: fmt(Co, 'H1'), zRef: L.L2, r: Co.H1 / 2 });
    if (Co.H2 !== undefined) right.push({ s: fmt(Co, 'H2'), zRef: L.L3, r: Co.H2 / 2 });
    if (info.bottleneck && PC.P2 !== undefined) right.push({ s: fmt(PC, 'P2'), zRef: L.L1, r: PC.P2 / 2 });
    left.sort(function (a, b) { return b.r - a.r; });
    right.sort(function (a, b) { return b.r - a.r; });
    left.forEach(function (d, i) { vDim(-4 - i * 5.5, d.zRef, d.r, d.s, true); });
    right.forEach(function (d, i) { vDim(L.L6 + 4 + i * 5.5, d.zRef, d.r, d.s, false); });

    seg(-3, 0, L.L6 + 3, 0);
    var centre = lines.pop();

    var outline = '<polyline class="outline" points="' + pts(up, -1) + '"/>';
    up.forEach(function (p) { track(p[0], -p[1]); });
    var section = '<polygon class="section" points="' + pts(g.section, 1) + '"/>';
    var bullet = '<polyline class="outline" points="' + pts(g.bulletSection, 1) + '"/>';

    var pad = 2, x0 = box[0] - pad, y0 = box[1] - pad;
    var w = box[2] - box[0] + 2 * pad, h = box[3] - box[1] + 2 * pad;
    var svg = '<svg class="drawing-svg" viewBox="' + n(x0) + ' ' + n(y0) + ' ' + n(w) + ' ' + n(h) + '" width="' + n(w) + 'mm" role="img" aria-label="' +
      esc(rec.name) + ' drawing" font-size="' + F + '">' +
      '<defs><pattern id="cip-hatch" width="1.6" height="1.6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
      '<line class="hatch" x1="0" y1="0" x2="0" y2="1.6"/></pattern></defs>' +
      '<g class="centre">' + centre + '</g>' + section + bullet + outline +
      '<g class="dim">' + lines.join('') + '</g><g class="arrow">' + arrows.join('') + '</g>' +
      '<g class="labels">' + labels.join('') + '</g></svg>';
    return { svg: svg, boxes: boxes, outline: up };
  }

  // Lines and labels are drawn in one pass; the bounding box covers all of them.
  return { draw: draw };
})();
