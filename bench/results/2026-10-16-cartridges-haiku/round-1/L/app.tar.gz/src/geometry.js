var CIP = CIP || {};

CIP.geometry = (function () {
  var M = CIP.model;
  var DEG = Math.PI / 180;

  // Arc points that round the corner at P between A and B with radius r.
  function fillet(A, P, B, r) {
    var ux = A[0] - P[0], uy = A[1] - P[1], vx = B[0] - P[0], vy = B[1] - P[1];
    var la = Math.hypot(ux, uy), lb = Math.hypot(vx, vy);
    ux /= la; uy /= la; vx /= lb; vy /= lb;
    var th = Math.acos(Math.max(-1, Math.min(1, ux * vx + uy * vy)));
    if (th < 1e-6 || Math.PI - th < 1e-6) return [P];
    var t = r / Math.tan(th / 2);
    var tMax = Math.min(la, lb) * 0.5;
    if (t > tMax) { t = tMax; r = t * Math.tan(th / 2); }
    var T1 = [P[0] + ux * t, P[1] + uy * t], T2 = [P[0] + vx * t, P[1] + vy * t];
    var bx = ux + vx, by = uy + vy, bl = Math.hypot(bx, by);
    var dc = r / Math.sin(th / 2);
    var C = [P[0] + (bx / bl) * dc, P[1] + (by / bl) * dc];
    var a1 = Math.atan2(T1[1] - C[1], T1[0] - C[0]);
    var d = Math.atan2(T2[1] - C[1], T2[0] - C[0]) - a1;
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d < -Math.PI) d += 2 * Math.PI;
    var pts = [];
    for (var k = 0; k <= 12; k++) {
      var a = a1 + (d * k) / 12;
      pts.push([C[0] + r * Math.cos(a), C[1] + r * Math.sin(a)]);
    }
    return pts;
  }

  // Vertices {p, rad} to polyline; rad rounds the corner at p.
  function roundVertices(vs) {
    var out = [];
    for (var i = 0; i < vs.length; i++) {
      var v = vs[i];
      if (!v.rad || i === 0 || i === vs.length - 1) out.push(v.p);
      else out = out.concat(fillet(vs[i - 1].p, v.p, vs[i + 1].p, v.rad));
    }
    return out;
  }

  // Largest radius of a polyline at axial position z; NaN when z is outside it.
  function radiusAt(pts, z) {
    var best = NaN;
    for (var i = 0; i + 1 < pts.length; i++) {
      var a = pts[i], b = pts[i + 1];
      if (z < Math.min(a[0], b[0]) - 1e-9 || z > Math.max(a[0], b[0]) + 1e-9) continue;
      var r;
      if (Math.abs(b[0] - a[0]) < 1e-9) r = Math.max(a[1], b[1]);
      else r = a[1] + ((z - a[0]) / (b[0] - a[0])) * (b[1] - a[1]);
      if (isNaN(best) || r > best) best = r;
    }
    return best;
  }

  // Nose from (zc, G/2) to the tip at z = L6, ending with meplat radius m/2.
  function nose(shape, zc, L6, G) {
    var n = L6 - zc, pts = [], N = 24, k, m, a, rho, rc, th, ph;
    if (shape === 'pointy') {
      m = Math.max(0.08 * G, 1.27);
      a = G / 2 - m / 2;
      rho = (a * a + n * n) / (2 * a);
      rc = G / 2 - rho;
      th = Math.acos((m / 2 - rc) / rho);
      for (k = 0; k <= N; k++) {
        ph = (th * k) / N;
        pts.push([zc + rho * Math.sin(ph), rc + rho * Math.cos(ph)]);
      }
    } else if (shape === 'rounded') {
      m = 0.15 * G;
      a = G / 2 - m / 2;
      for (k = 0; k <= N; k++) {
        ph = (Math.PI / 2) * (k / N);
        pts.push([zc + n * Math.sin(ph), m / 2 + a * Math.cos(ph)]);
      }
    } else {
      m = (shape === 'semi_wadcutter' ? 0.6 : 0.55) * G;
      pts.push([zc, G / 2], [L6, m / 2]);
    }
    return { pts: pts, m: m };
  }

  function build(rec) {
    var c = rec.cartridge, ann = rec.annotations, notes = [];
    var H = c.caseHead, J = c.junctionCone || {}, Lg = c.lengths, Co = c.collar;
    var PC = c.powderChamber, P = c.projectile;
    var type = M.rimType(rec);
    var belted = type === 'belted';
    var L3 = Lg.L3, L6 = Lg.L6, P1 = PC.P1, Rr = H.R1 / 2, H2 = Co.H2, G1 = P.G1;

    // Head face and rim (z = axial position, r = radius).
    var vs = [{ p: [0, 0] }], zRim = H.R, rimTop = Rr;
    if (type === 'rimfire') {
      var rr = Math.min(H.R / 2, (H.R1 - P1) / 2), cr = Rr - rr;
      zRim = 2 * rr;
      rimTop = cr;
      for (var k = 0; k <= 12; k++) {
        var ang = Math.PI - (Math.PI * k) / 12;
        vs.push({ p: [rr + rr * Math.cos(ang), cr + rr * Math.sin(ang)] });
      }
    } else {
      if (H.beta !== undefined && H.f !== undefined && H.beta < 90) {
        var cut = Math.min(H.f * Math.tan(H.beta * DEG), Rr / 2);
        vs.push({ p: [0, Rr - cut] }, { p: [H.f, Rr] });
      } else {
        vs.push({ p: [0, Rr] });
        notes.push('Head chamfer not drawn: beta or f missing.');
      }
      vs.push({ p: [zRim, Rr] });
    }

    // Extractor groove (or belt), then body start zs.
    var zs, rampEnd = null, E = H.E, E1 = H.E1, groove = E !== undefined && E1 !== undefined && H.eMin !== undefined;
    if (groove) {
      vs.push({ p: [zRim, E1 / 2] }, { p: [zRim + H.eMin, E1 / 2] });
      if (belted && H.R3 !== undefined && H.delta !== undefined) {
        var dr = H.R3 / 2 - E1 / 2;
        rampEnd = Math.min(zRim + H.eMin + dr / Math.tan(M.angleDegrees(H.delta) * DEG), E);
        vs.push({ p: [rampEnd, H.R3 / 2] }, { p: [E, H.R3 / 2] });
      } else if (belted) {
        notes.push('Belt not drawn: R3 or delta missing.');
      }
      vs.push({ p: [E, P1 / 2] });
      zs = E;
    } else {
      vs.push({ p: [zRim, P1 / 2] });
      zs = zRim;
    }

    // Body, shoulder and neck.
    var bottleneck = J.alpha !== undefined && Lg.L1 !== undefined && Lg.L2 !== undefined && PC.P2 !== undefined;
    if (bottleneck) {
      var H1 = Co.H1;
      if (H1 === undefined) { H1 = H2; notes.push('Neck diameter H1 missing: neck drawn at H2.'); }
      if (J.r1Min === undefined) notes.push('Shoulder rounding r1 min missing: corner not rounded.');
      if (J.r2 === undefined) notes.push('Shoulder rounding r2 missing: corner not rounded.');
      vs.push({ p: [Lg.L1, PC.P2 / 2], rad: J.r1Min }, { p: [Lg.L2, H1 / 2], rad: J.r2 });
    } else if (PC.P2 !== undefined || Lg.L1 !== undefined) {
      notes.push('Shoulder not drawn: alpha, L1, L2 or P2 missing; case drawn straight.');
    }
    vs.push({ p: [L3, H2 / 2] });
    var caseOuter = roundVertices(vs);

    // Bullet: seating, cylinder, nose.
    var heeled = H2 - G1 <= 0.015;
    var Gx = heeled ? H2 : G1;
    var shape = ann.defaultBulletShape, pistol = ann.category === 'pistol';
    var s, kk;
    if (shape === 'pointy') { s = G1; kk = 0.4; }
    else if (shape === 'semi_wadcutter') { s = 0.6 * G1; kk = 0.78; }
    else if (shape === 'rounded') { s = (pistol ? 0.4 : 0.8) * G1; kk = pistol ? 0.65 : 0.55; }
    else if (shape === 'flat') { s = (pistol ? 0.4 : 0.8) * G1; kk = pistol ? 0.7 : 0.6; }
    else throw new Error('Unknown defaultBulletShape: ' + shape);
    var zb = L3 - s, zc = zb + kk * (L6 - zb);
    if (zc < L3) { notes.push('Bullet cylinder ends inside the case: nose starts at the mouth.'); zc = L3; }
    var nz = nose(shape, zc, L6, Gx);
    var tail = [[L3, Gx / 2]];
    if (zc > L3) tail.push([zc, Gx / 2]);
    tail = tail.concat(nz.pts.slice(1), [[L6, 0]]);
    var upper = caseOuter.concat(tail);

    // Walls: tn along the neck, tb along the body, linear across the shoulder.
    var tn = (H2 - G1) / 2, tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
    var wall = function (z) {
      if (bottleneck) {
        if (z <= Lg.L1) return tb;
        if (z >= Lg.L2) return tn;
        return tb + ((tn - tb) * (z - Lg.L1)) / (Lg.L2 - Lg.L1);
      }
      if (z <= zs) return tb;
      return tb + ((tn - tb) * (z - zs)) / (L3 - zs);
    };

    // Solid head and primer pocket.
    var pocket = M.primerPocket(ann.primerType);
    var w = Math.max(2.5, 0.25 * P1 / 2, pocket ? pocket.depth + 1.5 : 0);
    if (belted && rampEnd !== null) w = Math.max(w, rampEnd + tb);
    else if (groove) w = Math.max(w, E + tb);

    var inner = [[w, radiusAt(caseOuter, w) - wall(w)]];
    caseOuter.forEach(function (p) {
      if (p[0] > w) inner.push([p[0], p[1] - wall(p[0])]);
    });

    var section = [];
    if (pocket) section.push([0, pocket.diameter / 2], [pocket.depth, pocket.diameter / 2], [pocket.depth, 0]);
    else section.push([0, 0]);
    section.push([w, 0]);
    section = section.concat(inner, caseOuter.slice().reverse());

    // Seated bullet (lower half of the section).
    var rs = heeled ? (H2 - 2 * tb) / 2 : G1 / 2;
    var bulletSection = [[zb, 0], [zb, rs], [L3, rs]].concat(tail);

    return {
      outline: upper,
      section: section,
      bulletSection: bulletSection,
      pocket: pocket,
      w: w,
      notes: notes,
      info: {
        rimType: type, zs: zs, zRim: zRim, rimTop: rimTop, groove: groove, rampEnd: rampEnd,
        bottleneck: bottleneck, zb: zb, zc: zc, Gx: Gx, heeled: heeled, tip: nz.m,
        rMax: Math.max.apply(null, upper.map(function (p) { return p[1]; })),
        zMax: L6, tb: tb, tn: tn
      }
    };
  }

  return { build: build, radiusAt: radiusAt, fillet: fillet };
})();
