var CIP = CIP || {};

CIP.model = (function () {
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = {
    Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '', u: '',
    grH2O: 'gr H2O'
  };
  var SECTIONS = {
    cartridge: [
      ['caseHead', 'Case head'], ['collar', 'Collar'], ['junctionCone', 'Junction cone'],
      ['lengths', 'Lengths'], ['misc', 'Misc'], ['powderChamber', 'Powder chamber'],
      ['pressures', 'Pressures'], ['projectile', 'Projectile']
    ],
    chamber: [
      ['barrel', 'Barrel'], ['breech', 'Breech'], ['collar', 'Collar'], ['grooves', 'Grooves'],
      ['junctionCone', 'Junction cone'], ['lengths', 'Lengths'],
      ['powderChamber', 'Powder chamber'], ['rifling', 'Rifling']
    ]
  };
  var PRIMER_POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 }, spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 }, lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 }, lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 }
  };

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function angleDegrees(v) {
    if (typeof v === 'number') return v;
    return v.degrees + v.minutes / 60 + v.seconds / 3600;
  }

  function angleText(v) {
    if (typeof v === 'number') return v + '°';
    return v.degrees + '°' + pad(v.minutes) + "'" + pad(v.seconds) + '"';
  }

  function symbol(field) {
    return SYMBOLS[field] || field;
  }

  function unit(field) {
    if (ANGLES[field]) return '';
    if (Object.prototype.hasOwnProperty.call(UNITS, field)) return UNITS[field];
    return 'mm';
  }

  function sections(record, side) {
    var out = [];
    SECTIONS[side].forEach(function (pair) {
      var data = record[side] && record[side][pair[0]];
      if (!data) return;
      var rows = [];
      Object.keys(data).forEach(function (field) {
        if (/Tol$/.test(field)) {
          if (Object.prototype.hasOwnProperty.call(data, field.slice(0, -3))) return;
        }
        var v = data[field];
        var text = ANGLES[field] ? angleText(v) : String(v);
        var tol = data[field + 'Tol'];
        if (tol !== undefined) text += ' ' + tol;
        rows.push({ symbol: symbol(field), value: text, unit: unit(field) });
      });
      out.push({ title: pair[1], rows: rows });
    });
    return out;
  }

  function rimType(record) {
    var c = record.cartridge;
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    var ratio = c.caseHead.R1 / c.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function primerPocket(primerType) {
    return PRIMER_POCKETS[primerType] || null;
  }

  function matches(record, query) {
    var q = String(query).toLowerCase().replace(/\s+/g, ' ').trim();
    if (q === '') return true;
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (n) {
      return n.toLowerCase().replace(/\s+/g, ' ').indexOf(q) !== -1;
    });
  }

  return {
    angleDegrees: angleDegrees, angleText: angleText, symbol: symbol, unit: unit,
    sections: sections, rimType: rimType, primerPocket: primerPocket, matches: matches
  };
})();
