const { test } = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load.js');

const { CIP, CIP_CARTRIDGES: DATA } = load();
const byKey = (k) => DATA.find((r) => r.key === k);
const draw = (rec) => CIP.drawing.draw(rec, CIP.geometry.build(rec));

// Points of the outline in both halves, subdivided so thin labels cannot slip between vertices.
function outlinePoints(outline) {
  const out = [];
  for (let i = 0; i + 1 < outline.length; i++) {
    const [a, b] = [outline[i], outline[i + 1]];
    const n = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 0.2));
    for (let k = 0; k <= n; k++) {
      const t = k / n;
      const z = a[0] + (b[0] - a[0]) * t, r = a[1] + (b[1] - a[1]) * t;
      out.push([z, r], [z, -r]);
    }
  }
  return out;
}

test('drawing carries the accessible name and the length labels', () => {
  const d = draw(byKey('223_rem'));
  assert.match(d.svg, /role="img" aria-label="223 Rem\. drawing"/);
  assert.match(d.svg, />L3 44\.7</);
  assert.match(d.svg, />L6 57\.4</);
  assert.match(d.svg, />R1 9\.6</);
});

test('tolerance is shown next to its value in labels', () => {
  assert.match(draw(byKey('223_rem')).svg, />L1 36\.52 -0\.2</);
});

test('shoulder angle is labelled with DMS form where published', () => {
  assert.match(draw(byKey('6_5_x_55_se')).svg, />α 50°35'02&quot;</);
});

test('labels do not overlap each other or the outline (all 25 records)', () => {
  DATA.forEach((rec) => {
    const { boxes, outline } = draw(rec);
    const pts = outlinePoints(outline);
    const m = 0.3;
    boxes.forEach((b, i) => {
      pts.forEach((p) => {
        const hit = p[0] > b[0] - m && p[0] < b[2] + m && p[1] > b[1] - m && p[1] < b[3] + m;
        assert.ok(!hit, `${rec.key}: label ${i} ${JSON.stringify(b)} touches outline at ${p}`);
      });
      boxes.slice(i + 1).forEach((c, j) => {
        const apart = b[2] + m <= c[0] || c[2] + m <= b[0] || b[3] + m <= c[1] || c[3] + m <= b[1];
        assert.ok(apart, `${rec.key}: labels ${i} and ${i + j + 1} overlap`);
      });
    });
  });
});
