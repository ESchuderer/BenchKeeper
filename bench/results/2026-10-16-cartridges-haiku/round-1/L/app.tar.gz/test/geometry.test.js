const { test } = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load.js');

const { CIP, CIP_CARTRIDGES: DATA } = load();
const byKey = (k) => DATA.find((r) => r.key === k);
const close = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${a} != ${b}`);

test('every record builds a finite outline from the axis at the head to the axis at the tip', () => {
  DATA.forEach((rec) => {
    const g = CIP.geometry.build(rec);
    const o = g.outline;
    assert.deepEqual([o[0][0], o[0][1]], [0, 0], rec.key);
    assert.deepEqual([o[o.length - 1][0], o[o.length - 1][1]], [rec.cartridge.lengths.L6, 0], rec.key);
    o.concat(g.section).forEach((p) => assert.ok(isFinite(p[0]) && isFinite(p[1]), rec.key));
  });
});

test('outline runs monotonically along the axis (no backtracking)', () => {
  DATA.forEach((rec) => {
    const o = CIP.geometry.build(rec).outline;
    for (let i = 1; i < o.length; i++) assert.ok(o[i][0] >= o[i - 1][0] - 1e-9, `${rec.key} at ${i}`);
  });
});

test('pointy bullet: nose starts at zb + 0.40 Lb (223 Rem.)', () => {
  const g = CIP.geometry.build(byKey('223_rem'));
  close(g.info.zb, 44.7 - 5.7);
  close(g.info.zc, (44.7 - 5.7) + 0.4 * (57.4 - (44.7 - 5.7)), 1e-6);
  close(g.info.tip, Math.max(0.08 * 5.7, 1.27));
});

test('heeled case: 22 Long Rifle exposes the case outside diameter', () => {
  const g = CIP.geometry.build(byKey('22_long_rifle'));
  assert.equal(g.info.heeled, true);
  close(g.info.Gx, 5.72);
  assert.equal(CIP.geometry.build(byKey('9_mm_luger')).info.heeled, false);
});

test('neck wall: inner line at the mouth sits at G1/2 when not heeled (223 Rem.)', () => {
  const g = CIP.geometry.build(byKey('223_rem'));
  const inner = g.section.filter((p) => Math.abs(p[0] - 44.7) < 1e-6);
  assert.ok(inner.some((p) => Math.abs(p[1] - 5.7 / 2) < 1e-6), JSON.stringify(inner));
});

test('missing values are reported, not invented', () => {
  assert.ok(CIP.geometry.build(byKey('338_lapua_mag')).notes.some((t) => /r1 min missing/.test(t)));
  assert.ok(CIP.geometry.build(byKey('9_mm_luger')).notes.every((t) => !/Shoulder/.test(t)));
  assert.deepEqual(CIP.geometry.build(byKey('22_win_mag_r_f')).info.groove, false);
});

test('rimfire rim is a half-round whose top lies at R1/2', () => {
  const rec = byKey('22_long_rifle');
  const g = CIP.geometry.build(rec);
  const rMax = Math.max(...g.outline.map((p) => p[1]));
  close(rMax, rec.cartridge.caseHead.R1 / 2, 1e-6);
});

test('fillet keeps arc points at the requested radius from the centre', () => {
  // Right angle at the origin, radius 2: centre at (2, 2).
  const pts = CIP.geometry.fillet([0, 10], [0, 0], [10, 0], 2);
  pts.forEach((p) => close(Math.hypot(p[0] - 2, p[1] - 2), 2, 1e-9));
  close(pts[0][0], 0); close(pts[0][1], 2);
  close(pts[pts.length - 1][0], 2); close(pts[pts.length - 1][1], 0);
});

test('radiusAt returns the largest radius at a position, NaN outside', () => {
  const pts = [[0, 1], [5, 1], [5, 3], [10, 3]];
  assert.equal(CIP.geometry.radiusAt(pts, 2), 1);
  assert.equal(CIP.geometry.radiusAt(pts, 5), 3);
  assert.ok(Number.isNaN(CIP.geometry.radiusAt(pts, 11)));
});

test('belt ramp never runs past E, even at a shallow delta (synthetic 300 Win. Mag. with delta 10)', () => {
  const rec = JSON.parse(JSON.stringify(byKey('300_win_mag')));
  rec.cartridge.caseHead.delta = 10;
  const g = CIP.geometry.build(rec);
  const o = g.outline;
  for (let i = 1; i < o.length; i++) assert.ok(o[i][0] >= o[i - 1][0] - 1e-9, `step ${i}`);
  assert.ok(g.info.rampEnd <= rec.cartridge.caseHead.E + 1e-9);
});
