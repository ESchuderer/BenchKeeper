const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');

// Loads the browser scripts in order into one global object, as index.html does.
module.exports = function load() {
  const ctx = {};
  ['data/cartridges.js', 'src/model.js', 'src/geometry.js', 'src/drawing.js'].forEach((f) => {
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, '..', f), 'utf8'), ctx);
  });
  return ctx;
};
