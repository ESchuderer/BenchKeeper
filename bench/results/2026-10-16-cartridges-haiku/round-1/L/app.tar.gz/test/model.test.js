const { test } = require('node:test');
const assert = require('node:assert/strict');
const load = require('./load.js');

const { CIP, CIP_CARTRIDGES: DATA } = load();
const byKey = (k) => DATA.find((r) => r.key === k);
// vm-context objects have another Object prototype; compare copies.
const plain = (v) => JSON.parse(JSON.stringify(v));

test('data holds the 25 records with unique keys', () => {
  assert.equal(DATA.length, 25);
  assert.equal(new Set(DATA.map((r) => r.key)).size, 25);
});

test('symbols use the mapping from the brief', () => {
  assert.equal(CIP.model.symbol('eMin'), 'e min');
  assert.equal(CIP.model.symbol('r1Min'), 'r1 min');
  assert.equal(CIP.model.symbol('alpha'), 'α');
  assert.equal(CIP.model.symbol('alpha1'), 'α1');
  assert.equal(CIP.model.symbol('beta'), 'β');
  assert.equal(CIP.model.symbol('delta'), 'δ');
  assert.equal(CIP.model.symbol('deltaL'), 'delta L');
  assert.equal(CIP.model.symbol('L3PlusG'), 'L3 + G');
  assert.equal(CIP.model.symbol('L3'), 'L3');
});

test('angles show as degrees or degrees, minutes, seconds', () => {
  assert.equal(CIP.model.angleText(40), '40°');
  assert.equal(CIP.model.angleText({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(CIP.model.angleText({ degrees: 50, minutes: 5, seconds: 2 }), '50°05\'02"');
});

test('tolerances sit next to their value and get no row', () => {
  const rows = CIP.model.sections(byKey('223_rem'), 'cartridge').flatMap((s) => s.rows);
  const l1 = rows.find((r) => r.symbol === 'L1');
  assert.deepEqual(plain(l1), { symbol: 'L1', value: '36.52 -0.2', unit: 'mm' });
  assert.equal(rows.some((r) => /Tol/.test(r.symbol)), false);
  const e = rows.find((r) => r.symbol === 'E');
  assert.equal(e.value, '3.13');
});

test('units and published number forms', () => {
  const rows = CIP.model.sections(byKey('223_rem'), 'cartridge').flatMap((s) => s.rows);
  const get = (sym) => rows.find((r) => r.symbol === sym);
  assert.deepEqual(plain(get('PE')), { symbol: 'PE', value: '5375', unit: 'bar' });
  assert.deepEqual(plain(get('EE')), { symbol: 'EE', value: '1825', unit: 'J' });
  assert.deepEqual(plain(get('M')), { symbol: 'M', value: '25', unit: 'g' });
  assert.equal(get('β').value, '35°');
  assert.equal(get('β').unit, '');
  const chamber = CIP.model.sections(byKey('223_rem'), 'chamber').flatMap((s) => s.rows);
  assert.equal(chamber.find((r) => r.symbol === 'Q').unit, 'mm²');
  assert.equal(chamber.find((r) => r.symbol === 'N').value, '6');
  assert.equal(chamber.find((r) => r.symbol === 'i').value, '3°10\'36"');
});

test('rim type follows family and R1/P1', () => {
  assert.equal(CIP.model.rimType(byKey('300_win_mag')), 'belted');
  assert.equal(CIP.model.rimType(byKey('22_long_rifle')), 'rimfire');
  assert.equal(CIP.model.rimType(byKey('9_3_x_74_r')), 'rimmed');
  assert.equal(CIP.model.rimType(byKey('223_rem')), 'rimless');
  assert.equal(CIP.model.rimType(byKey('9_mm_luger')), 'rimless');
});

test('primer pockets per primer type', () => {
  assert.deepEqual(plain(CIP.model.primerPocket('sr')), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(plain(CIP.model.primerPocket('lrm')), { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(plain(CIP.model.primerPocket('lp')), { diameter: 5.33, depth: 3.04 });
  assert.equal(CIP.model.primerPocket('rimfire'), null);
});

test('search matches names and alternative names, case-insensitively', () => {
  const find = (q) => plain(DATA.filter((r) => CIP.model.matches(r, q)).map((r) => r.key));
  assert.deepEqual(find('7,62 x 51'), ['308_win']);
  assert.deepEqual(find('creedmoor'), ['6_5_creedmoor']);
  assert.deepEqual(find('  30-06 '), ['30_06_spring']);
  assert.equal(find('').length, 25);
});
