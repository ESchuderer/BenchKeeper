# Cartridge reference Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A static, offline web app listing 25 C.I.P. cartridges with a detail view, a true-to-scale SVG drawing, search, family filter and A4 print.

**Architecture:** Plain HTML/CSS/JS with classic scripts. Pure modules (`format`, `geometry`, `drawing`) run in the browser (attached to `window`) and under `node:test` (`module.exports`). `app.js` owns the DOM and hash routing. Data is embedded as `data/cartridges.js` so `file://` works.

**Tech Stack:** HTML5, CSS (custom properties, `prefers-color-scheme`, `@media print`), ES2017 JavaScript, Node 22 `node:test` for tests. No npm runtime dependencies.

**Spec:** `docs/superpowers/specs/2026-10-16-cartridge-reference-design.md` (includes the decisions that deviate from or refine the brief; read it first).

## Global Constraints

- No network requests, CDNs, web fonts or analytics.
- No build step, no server code, no runtime dependencies.
- Values appear as published: no thousands separator, decimal point, `51.18 mm`, `4150 bar`.
- Names appear as published (`6,5 Creedmoor`).
- No em dash (U+2014), emojis or emoticons in code, comments, UI or docs.
- Interface language: English.

## Review Focus

1. Search input with regex characters, empty string, leading or trailing spaces: must match literally, and empty input shows all 25.
2. Hash to an unknown or malformed key (`#/cartridge/nope`, `#/cartridge/`): shows the list with a "not found" line, no exception.
3. Cartridges without a groove (`E` or `E1` absent, e.g. 38 Special, 22 Long Rifle) and with a belt: the outline must close without a gap.
4. Heeled case (22 Long Rifle, `H2 - G1 <= 0.015`): the heel fits inside the mouth wall, no negative wall thickness.
5. Missing values (`r1Min` absent in 22 Win. Mag. R.F., `P2` absent in several): the drawing draws without the feature and names the missing value; no `NaN` in the SVG.

Each line gets its test in the owning task (Tasks 2, 3, 4 and 5).

---

### Task 1: Project scaffold and data

**Files:**
- Create: `package.json` (`"test": "node --test test/"`, `"private": true`, no dependencies)
- Create: `data/cartridges.js`
- Create: `test/data.test.js`

**Interfaces:**
- Produces: `window.CARTRIDGE_DATA` (array of 25 objects) and, under Node, `module.exports = CARTRIDGE_DATA`. Each element is one record from the brief, unchanged.

- [ ] **Step 1: Write the failing test**

`test/data.test.js` loads `data/cartridges.js` with `require`, then asserts: `length === 25`; every `key` is unique; every record has `name`, `family`, `cartridge.lengths.L3`; the set of keys equals the 25 keys from the brief (`223_rem`, `243_win`, `6_5_creedmoor`, `6_5_x_55_se`, `270_win`, `7_x_64`, `308_win`, `30_06_spring`, `8_x_57_is`, `9_3_x_62`, `338_lapua_mag`, `300_win_mag`, `7_mm_rem_mag`, `9_3_x_74_r`, `7_x_65_r`, `9_mm_luger`, `45_auto`, `40_s_w`, `38_special`, `357_magnum`, `44_rem_mag`, `22_long_rifle`, `22_win_mag_r_f`, `17_hmr`, `7_62_x_39`).

Note: that list has 25 keys; check the count in the test too (the brief lists 25 records, `7_62_x_39` is among them).

- [ ] **Step 2: Run test to verify it fails**

Run: `npm test`
Expected: FAIL, `Cannot find module` for `data/cartridges.js`.

- [ ] **Step 3: Write `data/cartridges.js`**

One record per line, as in the brief, inside an array literal, followed by:

```js
const CARTRIDGE_DATA = [ ...25 JSON objects, one per line... ];
if (typeof window !== "undefined") window.CARTRIDGE_DATA = CARTRIDGE_DATA;
if (typeof module !== "undefined") module.exports = CARTRIDGE_DATA;
```

Do not edit any value.

- [ ] **Step 4: Run test to verify it passes**

Run: `npm test`
Expected: PASS, 5 tests.

- [ ] **Step 5: Commit**

```bash
git add package.json data/cartridges.js test/data.test.js docs/superpowers/
git commit -m "chore: add test runner, cartridge data and design docs"
```

---

### Task 2: Formatting, search and sections (`js/format.js`)

**Files:**
- Create: `js/format.js`
- Test: `test/format.test.js`

**Interfaces:**
- Produces:
  - `formatNumber(n: number): string` returns `String(n)` (so `36.0` gives `36`, `51.18` gives `51.18`).
  - `formatAngle(a: number | {degrees, minutes, seconds}): string` gives `40°` or `39°59'49"`; minutes and seconds padded to two digits.
  - `symbolFor(field: string): string` maps `eMin` to `e min`, `r1Min` to `r1 min`, `r1Max` to `r1 max`, `alpha` to `α`, `alpha1` to `α1`, `beta` to `β`, `delta` to `δ`, `deltaL` to `delta L`, `L3PlusG` to `L3 + G`; other fields return themselves.
  - `unitFor(field: string, value): string` returns `°` for angles (`alpha`, `alpha1`, `beta`, `delta`, `i`), `bar` for `Pmax`, `PK`, `PE`, `J` for `EE`, `g` for `M`, `mm²` for `Q`, `""` for `N`, and `mm` otherwise. Angles with object value still return `°`.
  - `valueText(field: string, value, tol?): string` returns the number text plus ` <tol>` when a tolerance is present (e.g. `39.62 -0.2`); angle values use `formatAngle`.
  - `sectionTables(record): Array<{title, rows: Array<{symbol, value, unit}>}>` for `cartridge` and `chamber` sections, skipping `*Tol` keys and attaching each `XTol` to `X`.
  - `matchesQuery(record, query): boolean` (trimmed, case-insensitive substring over `name` and `alternativeNames`; empty matches all).
  - `filterCartridges(records, query, family): records` (`family` is `"All"` or a family value).
  - `countLabel(n): string` gives `1 cartridge` or `n cartridges`.

- [ ] **Step 1: Write the failing tests**

Assert at least: `formatAngle(40)` is `"40°"`; `formatAngle({degrees: 39, minutes: 59, seconds: 49})` is `"39°59'49\""`; `formatAngle({degrees: 1, minutes: 30, seconds: 0})` is `"1°30'00\""`; `valueText("L1", 39.62, -0.2)` is `"39.62 -0.2"`; `symbolFor("L3PlusG")` is `"L3 + G"`; `sectionTables` for 223 Rem. has a `Case head` table containing a row `{symbol: "E", value: "3.13", unit: "mm"}`, the `E` row's value is `"3.13"` and the table has no row for `ETol`, and the `delta` row is `"25°"`; `matchesQuery(record308, "7,62 x 51")` is true; `matchesQuery(record308, "  ")` is true; `filterCartridges(all, "", "pistol")` returns 6 records (9 mm Luger, 45 Auto, 40 S.& W., 38 Special, 357 Magnum, 44 Rem. Mag.); `countLabel(1)` is `"1 cartridge"`.

- [ ] **Step 2: Run test to verify it fails**

Run: `npm test`
Expected: FAIL, `Cannot find module '../js/format.js'`.

- [ ] **Step 3: Implement the functions in `js/format.js`**

Attach to `window` when present and to `module.exports` otherwise, using the same pattern as Task 1. Section titles: `Cartridge: <Section>` and `Chamber: <Section>` with section names from the key (`caseHead` to `Case head`, `powderChamber` to `Powder chamber`, etc.). Skip the tolerance keys in the row list. Keep the field order from the record.

- [ ] **Step 4: Run test to verify it passes**

Run: `npm test`
Expected: PASS for all format tests.

- [ ] **Step 5: Commit**

```bash
git add js/format.js test/format.test.js
git commit -m "feat: add value formatting, sections and search"
```

---

### Task 3: Geometry (`js/geometry.js`)

**Files:**
- Create: `js/geometry.js`
- Test: `test/geometry.test.js`

**Interfaces:**
- Consumes: record objects from `data/cartridges.js`; formatting is not needed here.
- Produces:
  - `rimType(record): "belted" | "rimfire" | "rimmed" | "rebated" | "rimless"`.
  - `bulletSpec(record): {s, zb, k, zc, m, shape, D, heeled, Lb}` (all lengths mm). Uses `annotations.defaultBulletShape` and `annotations.category`. `D` is `G1`, or `H2` when heeled. `s` follows rule 7; `k` follows rule 7; `zc = zb + k*Lb`.
  - `wallSpec(record): {tn, tb, heeled, mouthWall}`.
  - `buildProfile(record): {outline, caseSection, bulletSection, missing}`:
    - `outline`: upper-half silhouette, array of `[z, r]` from `(0, 0)` to `(L6, 0)`, with fillets sampled.
    - `caseSection`: closed polygon of the case section (the mirrored lower half is drawn by the renderer), with the primer pocket notch.
    - `bulletSection`: closed polygon of the bullet section (seated part included).
    - `missing`: array of symbols the drawing could not place (e.g. `["r1 min"]`); empty when nothing is missing.
  - `primerPocket(record): {diameter, depth} | null`.
  - `headDepth(record): number` (`w` from rule 8).

- [ ] **Step 1: Write the failing tests**

Test cases, using the data file:
- `rimType`: 9 mm Luger gives `rimless`; 9,3 x 74 R gives `rimmed`; 300 Win. Mag. gives `belted`; 22 Long Rifle gives `rimfire`; 38 Special gives `rimmed` (R1/P1 = 11.18/9.63 = 1.16).
- `bulletSpec` for 223 Rem.: `shape` `pointy`, `s` = `5.7` (1.0·G1), `zb` = `39.0` (44.7 − 5.7), `Lb` = `18.4` (57.4 − 39.0), `k` = `0.4`, `D` = `5.7`, `heeled` false.
- `bulletSpec` for 22 Long Rifle: `heeled` true, `D` = `5.72`, `s` = `4.576` (0.8·G1), `k` = `0.55`.
- `bulletSpec` for 9 mm Luger: `s` = `3.612` (0.4·G1), `k` = `0.65`.
- `wallSpec` for 223 Rem.: `tn` ≈ `0.365`, `tb` = `0.6`.
- `wallSpec` for 22 Long Rifle: `heeled` true, `mouthWall` = `tb`.
- `buildProfile` for every record: `outline` starts at `[0, 0]`, ends at `[L6, 0]`, and contains no `NaN`; `outline` is non-decreasing in `z`.
- `buildProfile` for 22 Long Rifle: `missing` is `[]`.
- `buildProfile` for 22 Win. Mag. R.F. (no `E`, no `alpha`, no `beta`/`f`): `missing` is `[]` and the outline has no `NaN`. It is a straight case with no shoulder, so no `alpha` label is required.
- Nose endpoint: for every pointy record the last point of the nose is at `z = L6`, `r = m/2` with `m = max(0.08·G1, 1.27)`.
- Fillets: for 223 Rem. the outline has a sample at `z` between `L1 − 0.6` and `L1 + 0.6` (the rounded corner exists).

- [ ] **Step 2: Run test to verify it fails**

Run: `npm test`
Expected: FAIL, module missing.

- [ ] **Step 3: Implement `js/geometry.js`**

Coordinates: points are `[z, r]`. Build the outline in this order: head face, chamfer or half-round, rim, groove or step, body, shoulder (with fillets), neck, mouth face, exposed bullet, nose, tip.

Key formulas (from the design doc, rules 1–8):
- Groove: `E1/2 < R1/2`; floor from `(R1/2, R)` to `(E1/2, R)`, then to `(E1/2, R + eMin)`, ramp to `(P1/2, E)`.
- Belted: ramp from `(E1/2, R + eMin)` to `(R3/2, R + eMin + (R3/2 − E1/2)/tan δ)`, belt to `(R3/2, E)`, step to `(P1/2, E)`.
- Rimfire arc: centre `(R1/2 − ρ, ρ)`, radius `ρ = min(R/2, (R1 − P1)/2)`, sampled from `(R1/2 − ρ, 0)` through `(R1/2, ρ)` to `(R1/2 − ρ, 2ρ)`.
- Fillets: corner `V` between segments to `A` and `B`, radius `r`; tangent distance `d = r / tan(θ/2)` with `θ` the interior angle; clamp `d` to 0.9 of the shorter adjacent segment; sample the arc as points. Use `r1Min` at `(P2/2, L1)` and `r2` at `(H1/2, L2)`.
- Straight case: body from `(P1/2, z0)` to `(H2/2, L3)`; `z0` is `E` with a groove or `R` without; the inner wall blends from `tb` at `z0` to `mouthWall` at `L3`.
- Bottleneck: body to `(P2/2, L1)`, shoulder to `(H1/2, L2)`, neck to `(H2/2, L3)`.
- Case section polygon: start at the pocket bottom on the axis, pocket wall, head face, outer profile to the mouth, mouth face to the inner mouth, inner profile back to `(w, inner(w))`, down to `(w, 0)`, along the axis to start.
- Bullet section: `(zb, 0)`, up the base, cylinder to `zc`, nose to `(L6, m/2)`, `(L6, 0)`. Heeled: heel radius `H2/2 − tb` for `z` in `[zb, L3]`, exposed `D/2` after.
- Missing values: a rule that needs an absent value (e.g. `r1Min` absent but `alpha` present) is skipped and its symbol added to `missing`; never produce `NaN`.

- [ ] **Step 4: Run test to verify it passes**

Run: `npm test`
Expected: PASS for all geometry tests.

- [ ] **Step 5: Commit**

```bash
git add js/geometry.js test/geometry.test.js
git commit -m "feat: add cartridge geometry from the record values"
```

---

### Task 4: Drawing layout and SVG (`js/drawing.js`)

**Files:**
- Create: `js/drawing.js`
- Test: `test/drawing.test.js`

**Interfaces:**
- Consumes: `buildProfile(record)`, `bulletSpec`, `wallSpec`, `primerPocket`, `headDepth` (Task 3); `symbolFor`, `valueText` (Task 2).
- Produces:
  - `dimensions(record, profile): Array<{kind: "h"|"v", symbol, text, from, to, lane, ...}>`: the dimension list (horizontal for L3, L6, R; vertical for R1, P1, P2, H1, H2, G1, E1 where published; α with a leader). Each `text` is `"<symbol> <valueText>"`.
  - `labelBox(text, x, y, anchor): {x0, y0, x1, y1}`: estimated box, width `0.6 × fontSize × chars`, font size 3.2 mm (constant, in SVG units).
  - `layoutLabels(dims): Array<{dim, x, y, anchor}>`: assigns lanes so no two label boxes overlap and no label box overlaps the outline bounding polygon.
  - `drawingSvg(record): string`: SVG markup, `viewBox` from the extent of outline, dims and labels plus margin; `role="img"` and `aria-label="<name> drawing"`; `<title>`; hatch patterns in `<defs>`; centre line dash-dot; title block below.

- [ ] **Step 1: Write the failing tests**

- `dimensions` for 223 Rem. include `L3`, `L6`, `R1`, `R`, `P1`, `P2`, `H1`, `H2`, `G1`, `L1`, `L2`, `E1`, `α`; for 22 Long Rifle the list does not include `E1`, `L1`, `α`.
- `labelBox("L3 51.18", 0, 0, "middle")` width equals `0.6 × 3.2 × 8` within 0.01.
- For every one of the 25 records, `layoutLabels(dimensions(...))` returns no two overlapping label boxes (test with the estimated boxes), and none of them overlaps the outline bounding box.
- `drawingSvg(record)` for every record: contains `aria-label="<name> drawing"` (escaped), no `NaN`, no `undefined`, `viewBox` width and height are finite and positive.
- A record with a value a rule needs but the data lacks (use a copy of 223 Rem. with `junctionCone.r1Min` deleted, built in the test) gives `missing` containing `"r1 min"`, and the SVG contains a note listing it; the SVG has no `NaN`.

- [ ] **Step 2: Run test to verify it fails**

Run: `npm test`
Expected: FAIL, module missing.

- [ ] **Step 3: Implement `js/drawing.js`**

- SVG coordinates: `x = z`, `y = −r` upper half (outside), `y = +r` lower half (section). Centre line at `y = 0`.
- Horizontal dims (L3, L6, R): lanes above the outline; each with arrowheads (filled triangles, length 1.2 mm) and extension lines starting 0.8 mm from the feature and extending 1.5 mm past the dim line.
- Diameter dims: vertical line at `x = z_f` from `y = −r` to `y = +r` with arrows at both ends; label in a lane below the drawing reached by a vertical leader from `(z_f, +r)` downward. R1 is placed at `x = −3` (left of head face) with horizontal ext lines.
- α: label near the shoulder, leader from the shoulder midpoint outward.
- Hatch: `<pattern>` with 45° lines for case, −45° for bullet.
- Title block: a rectangle below all lanes with name, `C.I.P. table <tab>`, `Revised <revised>`, `Dimensions in mm`, `Scale 1:1 (1 unit = 1 mm), fitted to width`.
- Escape `&`, `<`, `>`, `"` in all text (names include `&`).
- Font size: 3.2 mm for labels; stroke 0.25 mm for outline; ext lines 0.15 mm.

- [ ] **Step 4: Run test to verify it passes**

Run: `npm test`
Expected: PASS for all drawing tests.

- [ ] **Step 5: Commit**

```bash
git add js/drawing.js test/drawing.test.js
git commit -m "feat: add dimensioned cartridge drawing"
```

---

### Task 5: Page, routing and styles (`index.html`, `js/app.js`, `styles.css`)

**Files:**
- Create: `index.html`, `js/app.js`, `styles.css`
- Test: `test/app.test.js` (pure `parseRoute(hash)` in `js/app.js`)

**Interfaces:**
- Consumes: `CARTRIDGE_DATA`; `filterCartridges`, `countLabel`, `sectionTables`, `valueText`; `drawingSvg`.
- Produces: `parseRoute(hash: string): {view: "list"} | {view: "detail", key: string}`.

- [ ] **Step 1: Write the failing test**

`parseRoute("")` and `parseRoute("#/")` give `{view: "list"}`; `parseRoute("#/cartridge/308_win")` gives `{view: "detail", key: "308_win"}`; `parseRoute("#/cartridge/")` gives `{view: "detail", key: ""}`; `parseRoute("#/cartridge/a%20b")` decodes to `a b`.

- [ ] **Step 2: Run test to verify it fails**

Run: `npm test`
Expected: FAIL, module missing.

- [ ] **Step 3: Implement**

- `index.html`: `<main>`, `<section id="list">` with `<h1>Cartridges</h1>`, a `<label>` "Search" input, a `<label>` "Family" select (All, rimless, rimmed, belted, pistol, rimfire), `<p id="count">`, `<ul>` of entries (each `<a>` text exactly `name`, then family and `L3 <value>` in `mm`). `<section id="detail" hidden>` with heading, meta `<dl>` (alternative names, family, category, primer type, C.I.P. table, country, published, revised, pressure method, water capacity with source link), drawing container, missing list, tables container, a Print button and "All cartridges" link. Load scripts in order: `data/cartridges.js`, `js/format.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js`.
- `js/app.js`: `render()` on `hashchange` and `load`; list filter on `input` and `change` events; detail builds headings and tables via `textContent` (no HTML injection from data); drawing via `innerHTML` of the SVG string produced by `drawingSvg`. Print button calls `window.print()`.
- `styles.css`: CSS custom properties for light and dark (`@media (prefers-color-scheme: dark)`); `font-variant-numeric: tabular-nums`; `@media print`: `@page { size: A4 portrait; margin: 12mm }`, hide `#list`, header nav, buttons; show a page header with the name and footer `Source: C.I.P. TDCC, revised <date>` (the footer is generated in `app.js` into `#print-footer`); svg `width: 100%; height: auto`.

- [ ] **Step 4: Run test to verify it passes**

Run: `npm test`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add index.html js/app.js styles.css test/app.test.js
git commit -m "feat: add list, detail, search, filter and print views"
```

---

### Task 6: Browser verification

**Files:**
- Modify only where a check fails (`js/drawing.js`, `styles.css`, `js/app.js`).

- [ ] **Step 1: Open `file:///work/index.html` in Playwright MCP and check the list**

Expected: heading `Cartridges`; 25 links; `25 cartridges`; search `7,62 x 51` lists only `308 Win.`; family `pistol` lists 6; console has no errors.

- [ ] **Step 2: Open detail views**

For each of the 25 keys, navigate to `#/cartridge/<key>` and check via `browser_evaluate`: the SVG exists, its `aria-label` is set, and label bounding boxes (from `getBBox` of the label `<text>` elements) do not overlap each other. Fix any failure in `js/drawing.js` and re-run `npm test`.

- [ ] **Step 3: Check print and dark mode**

`browser_emulate_media` with `print` and `dark`; screenshot the 223 Rem. detail page; confirm no navigation or buttons in print media.

- [ ] **Step 4: Check a static server**

Serve the folder from a scratch directory outside the repository (`/tmp/serve`, by copying files) and load the list. Expected: same result as `file://`.

- [ ] **Step 5: Commit fixes (if any)**

```bash
git add -p
git commit -m "fix: <what the browser check found>"
```

---

### Task 7: Review before reporting done

- [ ] **Step 1: Run `superpowers:requesting-code-review` on the branch diff against `main`.**
- [ ] **Step 2: Apply `superpowers:receiving-code-review` to the findings; fix correctness issues, re-run `npm test` and the browser checks.**
- [ ] **Step 3: Report the result with the choices from the design doc.**
