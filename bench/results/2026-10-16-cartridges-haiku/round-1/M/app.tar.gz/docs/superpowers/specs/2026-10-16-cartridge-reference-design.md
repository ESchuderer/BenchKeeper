# Cartridge reference: design

Date: 2026-10-16. Source of requirements: the user's brief (static web app, 25 C.I.P. cartridge records, modelled on OpenBallistics).

## Intent

A static, offline reference of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers. Each cartridge has a list entry, a detail page with all published values, and a drawing computed from those values.

## Goals

- List, search and filter the 25 records.
- Detail view per cartridge with its own bookmarkable address.
- Drawing computed from the record, true to scale (1 SVG unit = 1 mm).
- Printable detail view on one A4 portrait page.
- Works from `file://` in Chromium and from any static server.

## Non-goals

- Editing data, fetching data, any network request.
- Annotation display beyond the brief (`confidence`, `implausible`, `defaultBullet`).
- Server code, build step, runtime dependencies.

## Constraints

- Plain HTML, CSS and JavaScript. Classic `<script>` tags (no modules), so `file://` works.
- Data is embedded as a script (`data/cartridges.js`), because `fetch` of local files is blocked on `file://`.
- Tests use `node:test` (built into Node 22). No npm dependencies. `npm test` is the test command.
- English UI.

## Structure

| File | Role |
|---|---|
| `index.html` | Shell: list view, detail view, print header/footer. |
| `styles.css` | Light and dark (`prefers-color-scheme`), print rules, phone layout. |
| `data/cartridges.js` | The 25 records, verbatim, as `window.CARTRIDGE_DATA`. |
| `js/format.js` | Value and angle formatting, symbols, units, table sections, search and filter. |
| `js/geometry.js` | Rim type, profile points, bullet, section walls, missing-value list. |
| `js/drawing.js` | Dimension layout and SVG string output. |
| `js/app.js` | Hash routing, list and detail rendering, print button. |
| `test/*.test.js` | Unit tests for format, geometry, drawing layout, data. |

Modules attach to `window` in the browser and to `module.exports` under Node (`typeof module !== "undefined"`).

## Routing

- List: `index.html#/` (or no hash).
- Detail: `index.html#/cartridge/<key>`, where `<key>` is the record's `key`.
- Unknown key: shows the list with a short "not found" line.

## Decisions (my calls)

1. Units. Lengths, diameters and unlisted fields (`S`, `u`, `G`, `h`, `b`, `s`, `Fe`, `deltaL`, `L3PlusG`, `R3`, `r`) are mm. `N` has no unit (empty cell). `grH2O` is shown as `gr H2O` from its field name; the brief's unit list does not name it (unverified against the source).
2. Angles: a number shows as `40°`; an object shows as `D°MM'SS"` with minutes and seconds padded to two digits.
3. Numbers are printed as JavaScript prints them (`36.0` shows `36`, `51.18` shows `51.18`), so values appear as published.
4. Tolerances: `XTol` appears in the value cell of `X`, for example `39.62 -0.2`.
5. Symbols as the brief lists; any other symbol is the field name.
6. C.I.P. table shows the published value (`I`, `II`...), not "Table I".
7. Count text: `1 cartridge`, `n cartridges` otherwise.
8. Search: case-insensitive substring over `name` and every `alternativeNames` entry, whitespace-trimmed.
9. Rim type (brief rule 1) is computed and used for the rimfire and belted branches. Rimmed, rebated and rimless share one geometry (the brief defines no difference).
10. Rimfire rim edge is the half-round; the chamfer applies only to non-rimfire cases with `beta` and `f`. The half-round's top point (`R1/2 - ρ`, `2ρ`) is the start of the step to `P1/2`.
11. Belted ramp: from the floor end `(E1/2, R + eMin)` to the belt `(R3/2, z)` with `Δz = Δr / tan δ`, where `Δr = R3/2 - E1/2`. `δ` is the angle to the axis.
12. Heeled cases (`H2 - G1 <= 0.015`): the mouth/neck wall is `tb`, not `tn = 0`. With `tn = 0` the neck has no wall and the heel (`H2 - 2·tb`) would not fit. This is a deviation from rule 8 as written.
13. Straight cases (no alpha, L1 or L2): the inner wall thickness blends linearly from `tb` at the body start to the mouth wall (`tn`, or `tb` if heeled) at the bullet base `zb`, then stays at the mouth wall to the mouth (at L3 when `zb` is not past the body start). Rule 8 gives tb all the way, which puts the seated bullet (G1) inside the wall at the mouth. This is a deviation.
14. Fillets: `r1Min` at the body-side corner and `r2` at the neck-side corner, on the outer profile only; the inner profile stays sharp. Arcs are sampled to polylines (no SVG arc flags).
15. Bullet diameter for the exposed part is `G1` (`projectile.G1`). Heeled: exposed diameter is `H2`.
16. Primer pocket: from the table in rule 8, only for centrefire cases. Rimfire has no pocket term in `w`.
17. Drawing layout:
    - Upper half (outside view): above the centre line, `y = -r`.
    - Lower half (section): below, `y = +r`, cut walls hatched, bullet hatched with the opposite angle.
    - Horizontal dimensions (L1, L2, L3, L6, R) sit in lanes above the drawing, with ext lines from the feature points. R takes the lane nearest the drawing, label left of the head; the other lengths follow, longest nearest; each label starts right of its own end.
    - Diameter dimensions (R1, P1, P2, H1, H2, G1, E1) are vertical lines across the centre line with arrowheads at the outline. Their labels sit in lanes below the drawing, reached by a leader from the lower edge point. Labels are left of their leader; diameters within 16 mm in x share a staircase of lanes.
    - R1 is placed left of the head face, so no line crosses the head.
    - α is labelled near the shoulder with a short leader.
    - Label placement: depth-first search over the candidates with a fixed budget; greedy fallback counts any label without a free position. Checked in the browser with getBBox: no label overlaps another label, touches the outline or section, or leaves the viewBox, for all 25 records.
18. Missing values: the drawing omits the feature and the detail view lists which values were missing under the drawing.
19. Title block: HTML box under the drawing (name, C.I.P. table and revised date, "Dimensions in mm", "Scale 1:1, fitted to width"). It is outside the SVG so the print height fits one page. The SVG keeps a note line for values it could not draw.
20. Print: `@page { size: A4 portrait }`, black on white; hides list, search and buttons; source line `Source: C.I.P. TDCC, revised <date>` at the end. Tables in five columns. The drawing keeps full width but its height is capped at 134 mm in print, so the tall drawings (7,62 x 39, 17 HMR) are scaled down and centred. Measured in the browser at a 186 mm content width: every record fits 273 mm (printable A4 height with 12 mm margins); not checked with a real print job.

## Process

- No GitHub remote and no `gh`: local branch `feat/cartridge-reference`, no issue, no pull request. A review runs before reporting done.
- The approved description is the brief above plus the decisions in this file.

## Left to the builder

- Exact label font sizes and lane spacing (set so labels fit at phone width and on the A4 print).
- Hatch pattern spacing.
- Test cases beyond the ones named in the plan.
