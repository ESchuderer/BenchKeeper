// Page behaviour: hash routing, list with search and family filter, detail view, print.
var App = (function () {
  function parseRoute(hash) {
    const m = /^#\/cartridge\/(.*)$/.exec(hash || "");
    if (!m) return { view: "list" };
    try {
      return { view: "detail", key: decodeURIComponent(m[1]) };
    } catch (e) {
      return { view: "detail", key: m[1] };
    }
  }

  if (typeof document === "undefined") return { parseRoute };

  const records = CARTRIDGE_DATA;

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v !== undefined && v !== null) node.setAttribute(k, v);
    }
    for (const child of children || []) {
      node.append(typeof child === "string" ? document.createTextNode(child) : child);
    }
    return node;
  }

  function setVisible(node, visible) {
    node.hidden = !visible;
  }

  const listView = document.getElementById("list-view");
  const detailView = document.getElementById("detail-view");
  const notFound = document.getElementById("not-found");
  const search = document.getElementById("search");
  const family = document.getElementById("family");
  const count = document.getElementById("count");
  const list = document.getElementById("cartridge-list");
  const detailName = document.getElementById("detail-name");
  const facts = document.getElementById("facts");
  const drawing = document.getElementById("drawing");
  const tables = document.getElementById("tables");
  const source = document.getElementById("source");

  function renderList() {
    const matches = Format.filterCartridges(records, search.value, family.value);
    count.textContent = Format.countLabel(matches.length);
    list.replaceChildren(
      ...matches.map((r) =>
        el("li", { class: "entry" }, [
          el("a", { href: `#/cartridge/${encodeURIComponent(r.key)}` }, [r.name]),
          el("span", { class: "family" }, [r.family]),
          el("span", { class: "l3" }, [
            `L3 ${Format.valueText("L3", r.cartridge.lengths.L3, r.cartridge.lengths.L3Tol)} mm`,
          ]),
        ]),
      ),
    );
  }

  function factRow(term, value) {
    return [el("dt", {}, [term]), el("dd", {}, Array.isArray(value) ? value : [value])];
  }

  function renderFacts(r) {
    const rows = [];
    if (r.alternativeNames) rows.push(factRow("Alternative names", r.alternativeNames.join(", ")));
    rows.push(factRow("Family", r.family));
    rows.push(factRow("Category", r.annotations.category));
    rows.push(factRow("Primer type", r.annotations.primerType));
    rows.push(factRow("C.I.P. table", r.tab));
    rows.push(factRow("Country", r.country));
    rows.push(factRow("Published", r.published));
    rows.push(factRow("Revised", r.revised));
    rows.push(factRow("Pressure method", r.pressureMethod));
    const cap = r.annotations.publishedCapacity;
    if (cap) {
      const link = el("a", { href: cap.url }, [cap.source]);
      const text = `${Format.valueText("grH2O", cap.grH2O)} ${Format.unitFor("grH2O", cap.grH2O)}, `;
      const value = [text, link];
      if (cap.note) value.push(`: ${cap.note}`);
      rows.push(factRow("Water capacity (published)", value));
    }
    facts.replaceChildren(...rows.flat());
  }

  function renderTables(r) {
    const nodes = [];
    for (const t of Format.sectionTables(r)) {
      nodes.push(el("h3", {}, [t.title]));
      nodes.push(
        el("table", {}, [
          el("thead", {}, [el("tr", {}, [el("th", { scope: "col" }, ["Symbol"]), el("th", { scope: "col", class: "num" }, ["Value"]), el("th", { scope: "col" }, ["Unit"])])]),
          el(
            "tbody",
            {},
            t.rows.map((row) =>
              el("tr", {}, [el("th", { scope: "row" }, [row.symbol]), el("td", { class: "num" }, [row.value]), el("td", {}, [row.unit])]),
            ),
          ),
        ]),
      );
    }
    tables.replaceChildren(...nodes);
  }

  function renderDetail(key) {
    const r = records.find((x) => x.key === key);
    setVisible(listView, false);
    setVisible(notFound, !r);
    setVisible(detailView, Boolean(r));
    if (!r) {
      document.title = "Cartridges";
      return;
    }
    document.title = `${r.name}: Cartridges`;
    detailName.textContent = r.name;
    renderFacts(r);
    drawing.innerHTML = Drawing.drawingSvg(r);
    drawing.append(
      el(
        "div",
        { class: "title-block" },
        Drawing.titleRows(r).map((row) => el("p", { class: row.bold ? "tb-name" : null }, [row.text])),
      ),
    );
    renderTables(r);
    source.textContent = `Source: C.I.P. TDCC, revised ${r.revised}`;
  }

  function render() {
    const route = parseRoute(window.location.hash);
    if (route.view === "list") {
      document.title = "Cartridges";
      setVisible(listView, true);
      setVisible(detailView, false);
      setVisible(notFound, false);
      renderList();
    } else {
      renderDetail(route.key);
    }
  }

  search.addEventListener("input", renderList);
  family.addEventListener("change", renderList);
  document.getElementById("print-button").addEventListener("click", () => window.print());
  window.addEventListener("hashchange", render);
  render();

  return { parseRoute };
})();

if (typeof module !== "undefined") module.exports = App;
