// Dimensioned SVG drawing of a cartridge. Units: 1 SVG user unit = 1 mm.
// x = z (head face at 0, mouth to the right); outside view above the axis (y = -r), section below (y = +r).
var Drawing = (function (Geometry, Format) {
  const FS = 3.4;
  const TB_FS = 3.0;
  const CHAR_W = 0.6;
  const GAP = 0.8;
  const OVER = 1.2;
  const ARROW = 1.4;
  const HALF = 0.5;
  const LEFT_X = -3.8;
  const TOP_START = 2.6;
  const TOP_STEP = 4.6;
  const BOT_START = 2.6;
  const BOT_STEP = 4.6;

  const esc = (s) =>
    String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const num = (n) => Number(n.toFixed(3)).toString();
  const has = (x) => x !== undefined && x !== null;
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
  const unit = (a) => {
    const l = Math.hypot(a[0], a[1]);
    return [a[0] / l, a[1] / l];
  };

  function label(field, value, tol) {
    return `${Format.symbolFor(field)} ${Format.valueText(field, value, tol)}`;
  }

  // Dimension specs for the values the record publishes (horizontal: x is the length from the head face).
  function dimensions(rec) {
    const c = rec.cartridge;
    const ch = c.caseHead;
    const col = c.collar;
    const pc = c.powderChamber;
    const L = c.lengths;
    const jc = c.junctionCone || {};
    const p = Geometry.buildProfile(rec);
    const specs = [];
    const h = (field, value, tol, x) =>
      specs.push({ kind: "h", symbol: Format.symbolFor(field), text: label(field, value, tol), x });
    const v = (field, value, tol, x, r) =>
      specs.push({ kind: "v", symbol: Format.symbolFor(field), text: label(field, value, tol), x, r });
    if (has(ch.R)) h("R", ch.R, ch.RTol, ch.R);
    if (has(L.L1)) h("L1", L.L1, L.L1Tol, L.L1);
    if (has(L.L2)) h("L2", L.L2, L.L2Tol, L.L2);
    h("L3", L.L3, L.L3Tol, L.L3);
    h("L6", L.L6, undefined, L.L6);
    v("R1", ch.R1, undefined, LEFT_X, ch.R1 / 2);
    v("P1", pc.P1, undefined, p.z0, pc.P1 / 2);
    if (has(pc.P2) && has(L.L1)) v("P2", pc.P2, pc.P2Tol, L.L1, pc.P2 / 2);
    if (has(col.H1) && has(L.L2)) v("H1", col.H1, undefined, L.L2, col.H1 / 2);
    v("H2", col.H2, undefined, L.L3, col.H2 / 2);
    v("G1", c.projectile.G1, undefined, (L.L3 + p.bullet.zc) / 2, p.bullet.D / 2);
    if (has(ch.E1)) v("E1", ch.E1, undefined, p.rimZ + (has(ch.eMin) ? ch.eMin / 2 : 0), ch.E1 / 2);
    if (has(jc.alpha) && has(L.L1) && has(L.L2) && has(pc.P2) && has(col.H1)) {
      specs.push({
        kind: "a",
        symbol: Format.symbolFor("alpha"),
        text: label("alpha", jc.alpha),
        z1: L.L1,
        z2: L.L2,
        r1: pc.P2 / 2,
        r2: col.H1 / 2,
      });
    }
    return specs;
  }

  function boxFor(text, x, y, anchor) {
    const w = text.length * CHAR_W * FS;
    const x0 = anchor === "middle" ? x - w / 2 : anchor === "end" ? x - w : x;
    return { x0, x1: x0 + w, y0: y - 0.97 * FS, y1: y + 0.3 * FS };
  }

  function boxesOverlap(a, b, margin) {
    return a.x0 < b.x1 + margin && b.x0 < a.x1 + margin && a.y0 < b.y1 + margin && b.y0 < a.y1 + margin;
  }

  function segmentsIntersect(p1, p2, p3, p4) {
    const o = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
    const d1 = o(p3, p4, p1);
    const d2 = o(p3, p4, p2);
    const d3 = o(p1, p2, p3);
    const d4 = o(p1, p2, p4);
    return d1 * d2 < 0 && d3 * d4 < 0;
  }

  function segmentHitsBox(seg, b, margin) {
    const x0 = b.x0 - margin;
    const x1 = b.x1 + margin;
    const y0 = b.y0 - margin;
    const y1 = b.y1 + margin;
    const inside = (q) => q[0] >= x0 && q[0] <= x1 && q[1] >= y0 && q[1] <= y1;
    if (inside(seg[0]) || inside(seg[1])) return true;
    const edges = [
      [[x0, y0], [x1, y0]],
      [[x1, y0], [x1, y1]],
      [[x1, y1], [x0, y1]],
      [[x0, y1], [x0, y0]],
    ];
    return edges.some((e) => segmentsIntersect(seg[0], seg[1], e[0], e[1]));
  }

  function arrow(tip, dir) {
    const base = [tip[0] - dir[0] * ARROW, tip[1] - dir[1] * ARROW];
    const perp = [-dir[1] * HALF, dir[0] * HALF];
    return {
      tri: [tip, [base[0] + perp[0], base[1] + perp[1]], [base[0] - perp[0], base[1] - perp[1]]],
      seg: [tip, base],
    };
  }

  function candidate(segs, arrows, text, x, baseline, anchor) {
    return {
      segs,
      arrows,
      label: { text, x, y: baseline, anchor },
      box: boxFor(text, x, baseline, anchor),
    };
  }

  // Largest outline radius at z = x (outline in [z, r]).
  function radiusAt(outline, x) {
    let best = 0;
    for (let i = 0; i < outline.length - 1; i++) {
      const [z1, r1] = outline[i];
      const [z2, r2] = outline[i + 1];
      if (x < Math.min(z1, z2) - 1e-9 || x > Math.max(z1, z2) + 1e-9) continue;
      const r = z2 === z1 ? Math.max(r1, r2) : r1 + ((r2 - r1) * (x - z1)) / (z2 - z1);
      best = Math.max(best, r);
    }
    return best;
  }

  // Dimension `index` (sorted longest first) uses lane `index`: every longer dimension's extension line
  // stays below this label, and the label starts right of its own end, beyond every shorter extension line.
  function horizontalCandidates(spec, outline, top, index) {
    const x1 = 0;
    const x2 = spec.x;
    const out = [];
    for (let k = index; k < index + 12; k++) {
      const y = -(top + TOP_START + TOP_STEP * k);
      const segs = [
        [[x1, y], [x2, y]],
        [[x1, -(radiusAt(outline, x1) + GAP)], [x1, y - OVER]],
        [[x2, -(radiusAt(outline, x2) + GAP)], [x2, y - OVER]],
      ];
      const arrows = [arrow([x1, y], [-1, 0]), arrow([x2, y], [1, 0])];
      if (spec.symbol === "R") out.push(candidate(segs, arrows, spec.text, x1 - 1, y - 0.3 - 0.3 * FS, "end"));
      out.push(candidate(segs, arrows, spec.text, x2 + 1, y - 0.3 - 0.3 * FS, "start"));
      out.push(candidate(segs, arrows, spec.text, x2 + 1, y + 0.3 + 0.97 * FS, "start"));
      out.push(candidate(segs, arrows, spec.text, (x1 + x2) / 2, y - 0.3 - 0.3 * FS, "middle"));
    }
    return out;
  }

  // Diameter `index` (by x) uses lane `index` with the label left of its leader first: a label to the left
  // of a leader never reaches a leader further right, so the staircase of lanes has no crossings.
  function diameterCandidates(spec, bottom, lane, index) {
    const x = spec.x;
    const r = spec.r;
    const out = [];
    const arrows = [arrow([x, -r], [0, -1]), arrow([x, r], [0, 1])];
    if (x === LEFT_X) {
      // Left of the dimension line, vertically centred on the axis.
      const segs = [[[x, -r], [x, r]], [[-GAP, -r], [x - OVER, -r]], [[-GAP, r], [x - OVER, r]]];
      out.push(candidate(segs, arrows, spec.text, x - 1, 0.335 * FS, "end"));
    }
    const lanes = [...Array(12).keys()].map((n) => lane + n).concat([...Array(12).keys()].map((n) => index + n));
    for (const k of lanes) {
      const yLane = bottom + BOT_START + BOT_STEP * k;
      const segs = [[[x, -r], [x, yLane]]];
      const base = yLane + 0.3 + 0.97 * FS;
      for (const [dx, anchor] of [[-0.6, "end"], [0, "middle"], [0.6, "start"]]) {
        out.push(candidate(segs, arrows, spec.text, x + dx, base, anchor));
      }
    }
    return out;
  }

  // Leader from just outside the cone surface along its outward normal, turned by a few angles; arrow at the surface.
  function alphaCandidates(spec, bottom, reach) {
    const dz = spec.z2 - spec.z1;
    const dr = spec.r2 - spec.r1;
    const base = Math.atan2(dz, -dr);
    const zm = (spec.z1 + spec.z2) / 2;
    const rm = (spec.r1 + spec.r2) / 2;
    const out = [];
    for (const turn of [0, 25, -25, 50, -50, 75, -75]) {
      for (const len of [5, 8, 11, 14, 18, 22]) {
        const th = base + (turn * Math.PI) / 180;
        const nz = Math.cos(th);
        const nr = Math.sin(th);
        const s = [zm + nz * 0.5, -(rm + nr * 0.5)];
        const e = [zm + nz * (0.5 + len), -(rm + nr * (0.5 + len))];
        const arrows = [arrow(s, unit(sub(s, e)))];
        const anchor = nz >= 0 ? "start" : "end";
        out.push(candidate([[s, e]], arrows, spec.text, e[0], e[1] - 0.3 - 0.3 * FS, anchor));
      }
    }
    // Below the drawing: from the cone surface on the section side to a lane right of the diameter leaders.
    for (let k = 0; k < 9; k++) {
      for (const dx of [0, 6, 12, 18]) {
        const s = [zm, rm];
        const e = [reach + dx, bottom + BOT_START + BOT_STEP * k];
        const arrows = [arrow(s, unit(sub(s, e)))];
        out.push(candidate([[s, e]], arrows, spec.text, e[0], e[1] + 0.3 + 0.97 * FS, "start"));
      }
    }
    return out;
  }

  // Two dimension lines on the same line and overlapping in span would read as one line.
  function collinearOverlap(a, b) {
    const horiz = (q) => Math.abs(q[0][1] - q[1][1]) < 1e-9;
    const vert = (q) => Math.abs(q[0][0] - q[1][0]) < 1e-9;
    if (horiz(a) && horiz(b) && Math.abs(a[0][1] - b[0][1]) < 0.05) {
      return Math.min(Math.max(a[0][0], a[1][0]), Math.max(b[0][0], b[1][0])) > Math.max(Math.min(a[0][0], a[1][0]), Math.min(b[0][0], b[1][0]));
    }
    if (vert(a) && vert(b) && Math.abs(a[0][0] - b[0][0]) < 0.05) {
      return Math.min(Math.max(a[0][1], a[1][1]), Math.max(b[0][1], b[1][1])) > Math.max(Math.min(a[0][1], a[1][1]), Math.min(b[0][1], b[1][1]));
    }
    return false;
  }

  function fits(c, placed, obstacles) {
    for (const d of placed.dims) if (collinearOverlap(c.segs[0], d)) return false;
    for (const seg of obstacles) if (segmentHitsBox(seg, c.box, 0.2)) return false;
    for (const b of placed.boxes) if (boxesOverlap(c.box, b, 0.3)) return false;
    for (const seg of placed.segs) if (segmentHitsBox(seg, c.box, 0.2)) return false;
    for (const seg of c.segs) {
      if (segmentHitsBox(seg, c.box, 0.2)) return false;
      for (const b of placed.boxes) if (segmentHitsBox(seg, b, 0.2)) return false;
    }
    return true;
  }

  function polygonSegments(points) {
    return points.map((p, i) => [p, points[(i + 1) % points.length]]);
  }

  // Place every dimension label; returns the chosen candidates and the geometry around them.
  function layoutDrawing(rec) {
    const prof = Geometry.buildProfile(rec);
    const top = Math.max(...prof.outline.map((p) => p[1]));
    const upper = prof.outline.map(([z, r]) => [z, -r]);
    const caseLower = prof.caseSection.map(([z, r]) => [z, r]);
    const bulletLower = prof.bulletSection.map(([z, r]) => [z, r]);
    const obstacles = [
      ...upper.slice(1).map((p, i) => [upper[i], p]),
      ...polygonSegments(caseLower),
      ...polygonSegments(bulletLower),
    ];

    const specs = dimensions(rec);
    // R (rim thickness) takes the lane nearest the drawing; the other lengths follow, longest nearest.
    const hs = specs.filter((s) => s.kind === "h");
    const rim = hs.filter((s) => s.symbol === "R");
    const horizontal = [...rim, ...hs.filter((s) => s.symbol !== "R").sort((a, b) => b.x - a.x)];
    const diameters = specs.filter((s) => s.kind === "v").sort((a, b) => a.x - b.x);
    const alphas = specs.filter((s) => s.kind === "a");
    const placed = { segs: [], boxes: [], chosen: [], dims: [] };
    const reach = Math.max(...diameters.map((d) => d.x)) + 4;
    // Lane = number of earlier diameters whose labels would share the same x range (a staircase per cluster).
    const groups = [
      ...horizontal.map((s, i) => horizontalCandidates(s, prof.outline, top, i)),
      ...diameters.map((s, i) => diameterCandidates(s, top, diameters.slice(0, i).filter((d) => Math.abs(d.x - s.x) < 16).length, i)),
      ...alphas.map((s) => alphaCandidates(s, top, reach)),
    ];
    const push = (c) => {
      placed.segs.push(...c.segs, ...c.arrows.map((a) => a.seg));
      placed.boxes.push(c.box);
      placed.chosen.push(c);
      placed.dims.push(c.segs[0]);
    };
    const pop = (mark) => {
      placed.segs.length = mark.segs;
      placed.boxes.length = mark.boxes;
      placed.chosen.length = mark.chosen;
      placed.dims.length = mark.dims;
    };
    // Depth-first search over the candidates (first fit in each group, backtracking on a dead end).
    let budget = 200000;
    const search = (i) => {
      if (i === groups.length) return true;
      for (const c of groups[i]) {
        if (--budget < 0) return false;
        if (!fits(c, placed, obstacles)) continue;
        const mark = { segs: placed.segs.length, boxes: placed.boxes.length, chosen: placed.chosen.length, dims: placed.dims.length };
        push(c);
        if (search(i + 1)) return true;
        pop(mark);
      }
      return false;
    };
    let fallbacks = 0;
    if (!search(0)) {
      // No free layout within the budget: place each group at its first candidate and count the overlaps.
      pop({ segs: 0, boxes: 0, chosen: 0, dims: 0 });
      for (const cands of groups) {
        const pick = cands.find((c) => fits(c, placed, obstacles));
        if (!pick) fallbacks++;
        push(pick || cands[0]);
      }
    }

    return {
      prof,
      upper,
      caseLower,
      bulletLower,
      placed,
      fallbacks,
      obstacles,
      labels: placed.chosen.map((c) => ({ box: c.box, ...c.label })),
      outlineSegments: obstacles,
    };
  }

  function drawingSvg(rec) {
    const L = layoutDrawing(rec);
    const key = rec.key;
    const name = rec.name;

    const xs = [];
    const ys = [];
    const grow = (p) => {
      xs.push(p[0]);
      ys.push(p[1]);
    };
    L.upper.forEach(grow);
    L.caseLower.forEach(grow);
    L.bulletLower.forEach(grow);
    L.placed.segs.forEach((s) => s.forEach(grow));
    L.placed.boxes.forEach((b) => {
      grow([b.x0, b.y0]);
      grow([b.x1, b.y1]);
    });

    const notes = L.prof.missing.length
      ? [`Not drawn (value missing): ${L.prof.missing.map(Format.symbolFor).join(", ")}`]
      : [];
    const minX = Math.min(...xs);
    const maxY = Math.max(...ys);
    const noteBase = maxY + 3 + TB_FS;
    for (const t of notes) {
      xs.push(minX + t.length * CHAR_W * TB_FS);
      ys.push(noteBase + 0.3 * TB_FS);
    }

    const minXv = Math.min(...xs) - 1.5;
    const minYv = Math.min(...ys) - 1.5;
    const width = Math.max(...xs) - minXv + 1.5;
    const height = Math.max(...ys) - minYv + 1.5;

    const pathOf = (pts, closed) =>
      "M" + pts.map((p) => `${num(p[0])} ${num(p[1])}`).join(" L") + (closed ? " Z" : "");
    const centreEnd = L.prof.outline[L.prof.outline.length - 1][0] + 1.5;
    const dimD = L.placed.chosen
      .flatMap((c) => c.segs)
      .map((s) => pathOf(s, false))
      .join(" ");
    const arrowD = L.placed.chosen
      .flatMap((c) => c.arrows)
      .map((a) => pathOf(a.tri, true))
      .join(" ");
    const labels = L.placed.chosen
      .map(
        (c) =>
          `<text class="dim-label" x="${num(c.label.x)}" y="${num(c.label.y)}" text-anchor="${
            c.label.anchor
          }">${esc(c.label.text)}</text>`,
      )
      .join("");
    const note = notes
      .map((t) => `<text class="tb-text" x="${num(minX)}" y="${num(noteBase)}">${esc(t)}</text>`)
      .join("");

    return [
      `<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" viewBox="${num(minXv)} ${num(
        minYv,
      )} ${num(width)} ${num(height)}" role="img" aria-label="${esc(name)} drawing">`,
      `<title>${esc(name)} drawing</title>`,
      `<defs>`,
      `<pattern id="hatch-case-${key}" patternUnits="userSpaceOnUse" width="1.2" height="1.2" patternTransform="rotate(45)"><path d="M0 0 V1.2" class="hatch"/></pattern>`,
      `<pattern id="hatch-bullet-${key}" patternUnits="userSpaceOnUse" width="1.2" height="1.2" patternTransform="rotate(-45)"><path d="M0 0 V1.2" class="hatch"/></pattern>`,
      `</defs>`,
      `<path class="centre" d="${pathOf([[-1, 0], [centreEnd, 0]], false)}"/>`,
      `<path class="section" fill="url(#hatch-case-${key})" d="${pathOf(L.caseLower, true)}"/>`,
      `<path class="section" fill="url(#hatch-bullet-${key})" d="${pathOf(L.bulletLower, true)}"/>`,
      `<path class="outline" d="${pathOf(L.upper, false)}"/>`,
      `<path class="dim" d="${dimD}"/>`,
      `<path class="arrow" d="${arrowD}"/>`,
      labels,
      note,
      `</svg>`,
    ].join("");
  }

  // Title block lines, rendered as HTML under the drawing.
  function titleRows(rec) {
    return [
      { text: rec.name, bold: true },
      { text: `C.I.P. table ${rec.tab}, revised ${rec.revised}` },
      { text: "Dimensions in mm" },
      { text: "Scale 1:1, fitted to width" },
    ];
  }

  return {
    dimensions,
    layoutDrawing,
    drawingSvg,
    titleRows,
    boxesOverlap,
    segmentHitsBox,
  };
})(
  typeof module !== "undefined" ? require("./geometry.js") : Geometry,
  typeof module !== "undefined" ? require("./format.js") : Format,
);

if (typeof module !== "undefined") module.exports = Drawing;
