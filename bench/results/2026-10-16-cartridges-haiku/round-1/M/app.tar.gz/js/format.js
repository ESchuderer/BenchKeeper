// Value formatting, symbols, units, detail tables, search and filter.
var Format = (function () {
  const ANGLE_FIELDS = ["alpha", "alpha1", "beta", "delta", "i"];
  const SYMBOLS = {
    eMin: "e min",
    r1Min: "r1 min",
    r1Max: "r1 max",
    alpha: "α",
    alpha1: "α1",
    beta: "β",
    delta: "δ",
    deltaL: "delta L",
    L3PlusG: "L3 + G",
  };
  const UNITS = {
    Pmax: "bar",
    PK: "bar",
    PE: "bar",
    EE: "J",
    M: "g",
    Q: "mm²",
    N: "",
    grH2O: "gr H2O",
  };
  const SECTION_TITLES = {
    caseHead: "Case head",
    collar: "Collar",
    junctionCone: "Junction cone",
    lengths: "Lengths",
    misc: "Misc",
    powderChamber: "Powder chamber",
    pressures: "Pressures",
    projectile: "Projectile",
    barrel: "Barrel",
    breech: "Breech",
    grooves: "Grooves",
    rifling: "Rifling",
  };

  function formatNumber(n) {
    return String(n);
  }

  function formatAngle(a) {
    if (typeof a === "number") return `${formatNumber(a)}°`;
    const pad = (n) => formatNumber(n).padStart(2, "0");
    return `${formatNumber(a.degrees)}°${pad(a.minutes)}'${pad(a.seconds)}"`;
  }

  function symbolFor(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unitFor(field, value) {
    if (ANGLE_FIELDS.includes(field) || typeof value === "object") return "";
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : "mm";
  }

  function valueText(field, value, tol) {
    if (ANGLE_FIELDS.includes(field) || typeof value === "object") return formatAngle(value);
    return tol === undefined ? formatNumber(value) : `${formatNumber(value)} ${formatNumber(tol)}`;
  }

  function sectionTables(record) {
    const tables = [];
    for (const [root, label] of [
      [record.cartridge, "Cartridge"],
      [record.chamber, "Chamber"],
    ]) {
      for (const [section, values] of Object.entries(root)) {
        const rows = [];
        for (const [field, value] of Object.entries(values)) {
          if (field.endsWith("Tol")) continue;
          const tol = values[`${field}Tol`];
          rows.push({
            symbol: symbolFor(field),
            value: valueText(field, value, tol),
            unit: unitFor(field, value),
          });
        }
        if (rows.length === 0) continue;
        tables.push({ title: `${label}: ${SECTION_TITLES[section] || section}`, rows });
      }
    }
    return tables;
  }

  function matchesQuery(record, query) {
    const q = query.trim().toLowerCase();
    if (q === "") return true;
    const names = [record.name, ...(record.alternativeNames || [])];
    return names.some((name) => name.toLowerCase().includes(q));
  }

  function filterCartridges(records, query, family) {
    return records.filter(
      (r) => (family === "All" || r.family === family) && matchesQuery(r, query),
    );
  }

  function countLabel(n) {
    return n === 1 ? "1 cartridge" : `${n} cartridges`;
  }

  return {
    formatNumber,
    formatAngle,
    symbolFor,
    unitFor,
    valueText,
    sectionTables,
    matchesQuery,
    filterCartridges,
    countLabel,
  };
})();

if (typeof module !== "undefined") module.exports = Format;
