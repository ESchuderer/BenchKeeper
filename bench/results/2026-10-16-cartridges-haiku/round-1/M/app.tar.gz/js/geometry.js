// Cartridge geometry from record values (rules 1 to 9 of the brief).
// Profile points are [z, r]: z along the axis from the head face (z = 0), r the radius, both in mm.
var Geometry = (function () {
  const DEG = Math.PI / 180;
  const POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  const POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  const has = (x) => x !== undefined && x !== null;
  const hasOwn = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  const angle = (a) => (typeof a === "number" ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
  const len = (a) => Math.hypot(a[0], a[1]);
  const unit = (a) => {
    const l = len(a);
    return [a[0] / l, a[1] / l];
  };
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1];

  function rimType(rec) {
    if (rec.family === "belted") return "belted";
    if (rec.family === "rimfire") return "rimfire";
    const ratio = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return "rimmed";
    if (ratio < 0.98) return "rebated";
    return "rimless";
  }

  function primerPocket(rec) {
    const p = rec.annotations.primerType;
    if (!hasOwn(POCKET_DIAMETER, p)) return null;
    return { diameter: POCKET_DIAMETER[p], depth: POCKET_DEPTH[p] };
  }

  function wallSpec(rec) {
    const c = rec.cartridge;
    const gap = c.collar.H2 - c.projectile.G1;
    const heeled = gap <= 0.015;
    const tn = gap / 2;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * c.powderChamber.P1) / 2);
    return { tn, tb, heeled, mouthWall: heeled ? tb : tn };
  }

  function bulletSpec(rec) {
    const c = rec.cartridge;
    const G1 = c.projectile.G1;
    const L3 = c.lengths.L3;
    const L6 = c.lengths.L6;
    const shape = rec.annotations.defaultBulletShape;
    const pistol = rec.annotations.category === "pistol";
    const heeled = c.collar.H2 - G1 <= 0.015;
    const D = heeled ? c.collar.H2 : G1;
    let s;
    let k;
    let m;
    switch (shape) {
      case "pointy":
        s = G1;
        k = 0.4;
        m = Math.max(0.08 * D, 1.27);
        break;
      case "rounded":
        s = (pistol ? 0.4 : 0.8) * G1;
        k = pistol ? 0.65 : 0.55;
        m = 0.15 * D;
        break;
      case "flat":
        s = (pistol ? 0.4 : 0.8) * G1;
        k = pistol ? 0.7 : 0.6;
        m = 0.55 * D;
        break;
      case "semi_wadcutter":
        s = 0.6 * G1;
        k = 0.78;
        m = 0.6 * D;
        break;
      default:
        throw new Error(`unknown defaultBulletShape: ${shape}`);
    }
    const zb = L3 - s;
    const Lb = L6 - zb;
    const zc = zb + k * Lb;
    return { shape, D, heeled, s, zb, Lb, k, zc, m, L6 };
  }

  // Tangent fillet of radius r at corner V between A and B, sampled as points from the first tangent point to the second.
  function filletArc(A, V, B, r) {
    const ua = unit(sub(A, V));
    const ub = unit(sub(B, V));
    const half = Math.acos(Math.max(-1, Math.min(1, dot(ua, ub)))) / 2;
    const maxD = 0.9 * Math.min(len(sub(A, V)), len(sub(B, V)));
    let d = r / Math.tan(half);
    if (!(d <= maxD)) d = maxD;
    if (!(d > 1e-9)) return [V];
    const rr = d * Math.tan(half);
    const T1 = [V[0] + ua[0] * d, V[1] + ua[1] * d];
    const T2 = [V[0] + ub[0] * d, V[1] + ub[1] * d];
    const bis = unit([ua[0] + ub[0], ua[1] + ub[1]]);
    const cd = rr / Math.sin(half);
    const C = [V[0] + bis[0] * cd, V[1] + bis[1] * cd];
    const a1 = Math.atan2(T1[1] - C[1], T1[0] - C[0]);
    let delta = Math.atan2(T2[1] - C[1], T2[0] - C[0]) - a1;
    while (delta > Math.PI) delta -= 2 * Math.PI;
    while (delta <= -Math.PI) delta += 2 * Math.PI;
    const N = Math.max(2, Math.ceil(Math.abs(delta) / (Math.PI / 60)));
    const pts = [];
    for (let i = 0; i <= N; i++) {
      const t = a1 + (delta * i) / N;
      pts.push([C[0] + rr * Math.cos(t), C[1] + rr * Math.sin(t)]);
    }
    pts[0] = T1;
    pts[N] = T2;
    return pts;
  }

  // radii[i] rounds vertex i (0 and the last vertex are never rounded); missing radii leave the corner sharp.
  function roundCorners(V, radii) {
    const out = [V[0]];
    for (let i = 1; i < V.length - 1; i++) {
      if (radii[i] > 0) out.push(...filletArc(V[i - 1], V[i], V[i + 1], radii[i]));
      else out.push(V[i]);
    }
    out.push(V[V.length - 1]);
    return out;
  }

  // Nose from (zc, D/2) to the meplat corner (L6, m/2).
  function nose(b) {
    const R0 = b.D / 2;
    const mh = b.m / 2;
    const n = b.L6 - b.zc;
    const N = 24;
    const pts = [];
    if (b.shape === "pointy") {
      const gap = R0 - mh;
      const rho = (gap * gap + n * n) / (2 * gap);
      const cr = R0 - rho;
      const t1 = Math.atan2(mh - cr, n);
      for (let i = 0; i <= N; i++) {
        const t = Math.PI / 2 + ((t1 - Math.PI / 2) * i) / N;
        pts.push([b.zc + rho * Math.cos(t), cr + rho * Math.sin(t)]);
      }
    } else if (b.shape === "rounded") {
      for (let i = 0; i <= N; i++) {
        const phi = ((Math.PI / 2) * i) / N;
        pts.push([b.zc + n * Math.sin(phi), mh + (R0 - mh) * Math.cos(phi)]);
      }
    } else {
      return [[b.zc, R0], [b.L6, mh]];
    }
    pts[pts.length - 1] = [b.L6, mh];
    return pts;
  }

  function layout(rec) {
    const c = rec.cartridge;
    const ch = c.caseHead;
    const col = c.collar;
    const pc = c.powderChamber;
    const L = c.lengths;
    const jc = c.junctionCone || {};
    const missing = [];
    const need = (field, value) => {
      if (has(value)) return true;
      if (!missing.includes(field)) missing.push(field);
      return false;
    };

    const rt = rimType(rec);
    const wall = wallSpec(rec);
    const bullet = bulletSpec(rec);
    const pocket = primerPocket(rec);
    const R1h = ch.R1 / 2;
    const P1h = pc.P1 / 2;
    const H2h = col.H2 / 2;
    const L3 = L.L3;
    const R = need("R", ch.R) ? ch.R : 0;

    // Head face and rim edge.
    const caseOuter = [[0, 0]];
    let rimZ;
    if (rt === "rimfire") {
      const rho = Math.min(R / 2, (ch.R1 - pc.P1) / 2);
      const N = 16;
      for (let i = 0; i <= N; i++) {
        const phi = Math.PI - (Math.PI * i) / N;
        caseOuter.push([rho + rho * Math.cos(phi), R1h - rho + rho * Math.sin(phi)]);
      }
      rimZ = 2 * rho;
    } else {
      const chamfer = has(ch.f) && has(ch.beta) && angle(ch.beta) < 90;
      if (chamfer) {
        const x = Math.min(ch.f * Math.tan(angle(ch.beta) * DEG), R1h / 2);
        caseOuter.push([0, R1h - x], [ch.f, R1h]);
      } else {
        caseOuter.push([0, R1h]);
      }
      caseOuter.push([R, R1h]);
      rimZ = R;
    }

    // Extractor groove, belted ramp, or step to the body.
    const hasE = has(ch.E);
    const hasE1 = has(ch.E1);
    if (hasE !== hasE1) missing.push(hasE ? "E1" : "E");
    let groove = hasE && hasE1;
    if (groove && !need("eMin", ch.eMin)) groove = false;
    let belted = false;
    let rampEnd = null;
    let z0 = rimZ;
    if (groove) {
      const E = ch.E;
      const E1h = ch.E1 / 2;
      caseOuter.push([rimZ, E1h], [rimZ + ch.eMin, E1h]);
      if (rt === "belted" && need("R3", ch.R3) && need("delta", ch.delta)) {
        const R3h = ch.R3 / 2;
        rampEnd = rimZ + ch.eMin + (R3h - E1h) / Math.tan(angle(ch.delta) * DEG);
        caseOuter.push([rampEnd, R3h], [E, R3h]);
        belted = true;
      }
      caseOuter.push([E, P1h]);
      z0 = E;
    } else {
      caseOuter.push([rimZ, P1h]);
    }

    // Body, shoulder and neck.
    let bottleneck = has(jc.alpha) && has(L.L1) && has(L.L2);
    if (bottleneck && !need("P2", pc.P2)) bottleneck = false;
    if (bottleneck && !need("H1", col.H1)) bottleneck = false;
    if (bottleneck) {
      const r1 = need("r1Min", jc.r1Min) ? jc.r1Min : undefined;
      const r2 = need("r2", jc.r2) ? jc.r2 : undefined;
      const body = roundCorners(
        [[z0, P1h], [L.L1, pc.P2 / 2], [L.L2, col.H1 / 2], [L3, H2h]],
        [undefined, r1, r2, undefined],
      );
      caseOuter.push(...body.slice(1));
    } else {
      caseOuter.push([L3, H2h]);
    }

    // Wall thickness along the outer profile and the outer and inner radii at z.
    const tb = wall.tb;
    const mw = wall.mouthWall;
    const zt = bottleneck ? null : Math.min(Math.max(bullet.zb, z0), L3);
    const wallAt = (z) => {
      if (bottleneck) {
        if (z <= L.L1) return tb;
        if (z <= L.L2) return tb + ((mw - tb) * (z - L.L1)) / (L.L2 - L.L1);
        return mw;
      }
      if (z <= z0) return tb;
      if (zt - z0 <= 0 || z >= zt) return mw;
      return tb + ((mw - tb) * (z - z0)) / (zt - z0);
    };
    const outerAt = (z) => {
      for (let i = 0; i < caseOuter.length - 1; i++) {
        const [z1, r1] = caseOuter[i];
        const [z2, r2] = caseOuter[i + 1];
        if (z2 > z1 && z >= z1 && z <= z2) return r1 + ((r2 - r1) * (z - z1)) / (z2 - z1);
      }
      return H2h;
    };
    const innerAt = (z) => outerAt(z) - wallAt(z);

    // Solid head depth w (rule 8).
    const terms = [2.5, P1h / 4];
    if (pocket) terms.push(pocket.depth + 1.5);
    if (belted) terms.push(rampEnd + tb);
    else if (groove) terms.push(ch.E + tb);
    const w = Math.max(...terms);

    // Case section: outer profile, mouth face, inner profile back to the cavity bottom, axis.
    const inner = [[w, innerAt(w)]];
    for (const [z, r] of caseOuter) {
      if (z > w && z < L3) inner.push([z, r - wallAt(z)]);
    }
    if (zt !== null && zt > w && zt < L3 && zt > z0) inner.push([zt, outerAt(zt) - mw]);
    inner.push([L3, H2h - mw]);
    inner.sort((a, b) => a[0] - b[0]);
    const caseSection = [];
    if (pocket) {
      const pr = pocket.diameter / 2;
      caseSection.push([pocket.depth, 0], [pocket.depth, pr], [0, pr]);
    } else {
      caseSection.push([0, 0]);
    }
    caseSection.push(...caseOuter.slice(1), ...inner.slice().reverse(), [w, 0]);

    // Bullet: exposed part in the outline, seated part in the section.
    const D2 = bullet.D / 2;
    const tip = nose(bullet);
    const outline = caseOuter.slice();
    if (D2 !== H2h) outline.push([L3, D2]);
    outline.push(...tip, [bullet.L6, 0]);

    const seatR = bullet.heeled ? H2h - tb : D2;
    const bulletSection = [[bullet.zb, 0], [bullet.zb, seatR]];
    if (bullet.heeled) bulletSection.push([L3, seatR], [L3, D2]);
    bulletSection.push(...tip, [bullet.L6, 0]);

    return {
      outline,
      caseSection,
      bulletSection,
      missing,
      rimType: rt,
      heeled: wall.heeled,
      bullet,
      wall,
      pocket,
      w,
      z0,
      rimZ,
      groove,
      bottleneck,
      innerAt,
      outerAt,
    };
  }

  function buildProfile(rec) {
    const l = layout(rec);
    return {
      outline: l.outline,
      caseSection: l.caseSection,
      bulletSection: l.bulletSection,
      missing: l.missing,
      z0: l.z0,
      rimZ: l.rimZ,
      groove: l.groove,
      bottleneck: l.bottleneck,
      bullet: l.bullet,
    };
  }

  function headDepth(rec) {
    return layout(rec).w;
  }

  function innerRadius(rec, z) {
    return layout(rec).innerAt(z);
  }

  return { rimType, primerPocket, wallSpec, bulletSpec, buildProfile, headDepth, innerRadius };
})();

if (typeof module !== "undefined") module.exports = Geometry;
