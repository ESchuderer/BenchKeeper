const test = require("node:test");
const assert = require("node:assert/strict");
const App = require("../js/app.js");

test("parseRoute gives the list for an empty or root hash", () => {
  assert.deepEqual(App.parseRoute(""), { view: "list" });
  assert.deepEqual(App.parseRoute("#/"), { view: "list" });
  assert.deepEqual(App.parseRoute(undefined), { view: "list" });
});

test("parseRoute gives the detail view for a cartridge key", () => {
  assert.deepEqual(App.parseRoute("#/cartridge/308_win"), { view: "detail", key: "308_win" });
});

test("parseRoute decodes percent-encoded keys and keeps an empty key", () => {
  assert.deepEqual(App.parseRoute("#/cartridge/a%20b"), { view: "detail", key: "a b" });
  assert.deepEqual(App.parseRoute("#/cartridge/"), { view: "detail", key: "" });
});

test("parseRoute keeps a malformed escape as written instead of throwing", () => {
  assert.deepEqual(App.parseRoute("#/cartridge/%E0%A4%A"), { view: "detail", key: "%E0%A4%A" });
});
