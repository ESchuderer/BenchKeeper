const test = require("node:test");
const assert = require("node:assert/strict");
const records = require("../data/cartridges.js");

const KEYS = [
  "223_rem", "243_win", "6_5_creedmoor", "6_5_x_55_se", "270_win", "7_x_64", "308_win",
  "30_06_spring", "8_x_57_is", "9_3_x_62", "338_lapua_mag", "300_win_mag", "7_mm_rem_mag",
  "9_3_x_74_r", "7_x_65_r", "9_mm_luger", "45_auto", "40_s_w", "38_special", "357_magnum",
  "44_rem_mag", "22_long_rifle", "22_win_mag_r_f", "17_hmr", "7_62_x_39",
];

test("data holds the 25 published records", () => {
  assert.equal(records.length, 25);
  assert.deepEqual(records.map((r) => r.key).sort(), [...KEYS].sort());
});

test("every record has a name, family and case length L3", () => {
  for (const r of records) {
    assert.equal(typeof r.name, "string", r.key);
    assert.equal(typeof r.family, "string", r.key);
    assert.equal(typeof r.cartridge.lengths.L3, "number", r.key);
  }
});

test("keys are unique", () => {
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
});

test("family values are the five published families", () => {
  const families = new Set(records.map((r) => r.family));
  assert.deepEqual([...families].sort(), ["belted", "pistol", "rimfire", "rimless", "rimmed"]);
});
