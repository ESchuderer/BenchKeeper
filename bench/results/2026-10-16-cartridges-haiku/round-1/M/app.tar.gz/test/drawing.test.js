const test = require("node:test");
const assert = require("node:assert/strict");
const D = require("../js/drawing.js");
const records = require("../data/cartridges.js");

const byKey = (key) => records.find((r) => r.key === key);
const symbols = (r) => D.dimensions(r).map((d) => d.symbol);

test("dimensions: L3, L6, R1, R, P1 always; the other published values where they exist", () => {
  const full = symbols(byKey("223_rem"));
  for (const s of ["L3", "L6", "R1", "R", "P1", "P2", "H1", "H2", "G1", "L1", "L2", "E1", "α"]) {
    assert.ok(full.includes(s), `223 Rem. has ${s}`);
  }
  const rimfire = symbols(byKey("22_long_rifle"));
  assert.ok(rimfire.includes("L3") && rimfire.includes("R1") && rimfire.includes("P1"));
  for (const s of ["L1", "L2", "P2", "H1", "E1", "α"]) {
    assert.equal(rimfire.includes(s), false, `22 LR has no ${s}`);
  }
});

test("labels read symbol and value with the tolerance next to the value", () => {
  const spec = D.dimensions(byKey("223_rem")).find((d) => d.symbol === "L3");
  assert.equal(spec.text, "L3 44.7");
  const l1 = D.dimensions(byKey("223_rem")).find((d) => d.symbol === "L1");
  assert.equal(l1.text, "L1 36.52 -0.2");
});

test("every label of every record is placed without overlapping another label or the outline", () => {
  for (const r of records) {
    const layout = D.layoutDrawing(r);
    assert.equal(layout.fallbacks, 0, `${r.key}: a label had no free position`);
    const boxes = layout.labels.map((l) => l.box);
    for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        assert.equal(D.boxesOverlap(boxes[i], boxes[j], 0), false, `${r.key}: labels ${i} and ${j}`);
      }
      for (const seg of layout.outlineSegments) {
        assert.equal(D.segmentHitsBox(seg, boxes[i], 0), false, `${r.key}: label ${i} on outline`);
      }
    }
  }
});

test("drawingSvg is an accessible SVG with the name in its label and no NaN", () => {
  for (const r of records) {
    const svg = D.drawingSvg(r);
    assert.ok(svg.startsWith("<svg"), r.key);
    assert.ok(svg.includes(`aria-label="${r.name.replace(/&/g, "&amp;")} drawing"`), r.key);
    assert.equal(svg.includes("NaN"), false, r.key);
    assert.equal(svg.includes("undefined"), false, r.key);
    const vb = svg.match(/viewBox="([^"]+)"/)[1].split(" ").map(Number);
    assert.ok(vb.every(Number.isFinite) && vb[2] > 0 && vb[3] > 0, r.key);
  }
});

test("drawingSvg writes the label text", () => {
  const svg = D.drawingSvg(byKey("223_rem"));
  assert.ok(svg.includes(">L3 44.7<"));
});

test("titleRows gives the name, C.I.P. table, revision, units and scale", () => {
  const rows = D.titleRows(byKey("223_rem")).map((r) => r.text);
  assert.deepEqual(rows, ["223 Rem.", "C.I.P. table I, revised 2017-05-17", "Dimensions in mm", "Scale 1:1, fitted to width"]);
});

test("a value the drawing cannot place is named under the drawing", () => {
  const svg = D.drawingSvg(byKey("338_lapua_mag"));
  assert.ok(svg.includes("Not drawn (value missing): r1 min"));
});

test("the name is escaped in the SVG (names contain &)", () => {
  const svg = D.drawingSvg(byKey("40_s_w"));
  assert.ok(svg.includes("40 S.&amp; W. drawing"));
});
