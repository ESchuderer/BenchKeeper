const test = require("node:test");
const assert = require("node:assert/strict");
const F = require("../js/format.js");
const records = require("../data/cartridges.js");

const byKey = (key) => records.find((r) => r.key === key);

test("formatNumber prints the published value without a trailing .0", () => {
  assert.equal(F.formatNumber(36.0), "36");
  assert.equal(F.formatNumber(51.18), "51.18");
  assert.equal(F.formatNumber(-0.2), "-0.2");
});

test("formatAngle shows a degree number or a degrees-minutes-seconds object", () => {
  assert.equal(F.formatAngle(40), "40°");
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), "39°59'49\"");
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), "1°30'00\"");
});

test("symbolFor maps the brief's special symbols and keeps other field names", () => {
  assert.equal(F.symbolFor("eMin"), "e min");
  assert.equal(F.symbolFor("r1Min"), "r1 min");
  assert.equal(F.symbolFor("r1Max"), "r1 max");
  assert.equal(F.symbolFor("alpha"), "α");
  assert.equal(F.symbolFor("alpha1"), "α1");
  assert.equal(F.symbolFor("beta"), "β");
  assert.equal(F.symbolFor("delta"), "δ");
  assert.equal(F.symbolFor("deltaL"), "delta L");
  assert.equal(F.symbolFor("L3PlusG"), "L3 + G");
  assert.equal(F.symbolFor("R1"), "R1");
});

test("unitFor returns the unit the brief names and mm for lengths", () => {
  assert.equal(F.unitFor("Pmax", 4300), "bar");
  assert.equal(F.unitFor("PK", 4945), "bar");
  assert.equal(F.unitFor("PE", 5375), "bar");
  assert.equal(F.unitFor("EE", 1825), "J");
  assert.equal(F.unitFor("M", 25), "g");
  assert.equal(F.unitFor("Q", 25.03), "mm²");
  assert.equal(F.unitFor("N", 6), "");
  assert.equal(F.unitFor("alpha", 46), "");
  assert.equal(F.unitFor("L1", 36.52), "mm");
  assert.equal(F.unitFor("u", 305), "mm");
});

test("valueText appends the tolerance to its value", () => {
  assert.equal(F.valueText("L1", 39.62, -0.2), "39.62 -0.2");
  assert.equal(F.valueText("L3", 51.18), "51.18");
  assert.equal(F.valueText("alpha", { degrees: 50, minutes: 35, seconds: 2 }), "50°35'02\"");
});

test("sectionTables groups cartridge and chamber values and folds tolerances into their value", () => {
  const tables = F.sectionTables(byKey("223_rem"));
  const titles = tables.map((t) => t.title);
  assert.ok(titles.includes("Cartridge: Case head"));
  assert.ok(titles.includes("Chamber: Rifling"));

  const caseHead = tables.find((t) => t.title === "Cartridge: Case head");
  const e = caseHead.rows.find((row) => row.symbol === "E");
  assert.deepEqual(e, { symbol: "E", value: "3.13", unit: "mm" });
  assert.equal(caseHead.rows.some((row) => row.symbol.endsWith("Tol")), false);
  assert.deepEqual(caseHead.rows.find((row) => row.symbol === "δ"), {
    symbol: "δ",
    value: "25°",
    unit: "",
  });

  const lengths = tables.find((t) => t.title === "Cartridge: Lengths");
  assert.deepEqual(lengths.rows.find((row) => row.symbol === "L1"), {
    symbol: "L1",
    value: "36.52 -0.2",
    unit: "mm",
  });
});

test("sectionTables omits empty sections and shows angle objects as DMS", () => {
  const tables = F.sectionTables(byKey("9_mm_luger"));
  assert.equal(tables.some((t) => t.title === "Cartridge: Junction cone"), false);
  const rifling = F.sectionTables(byKey("223_rem")).find((t) => t.title === "Chamber: Rifling");
  assert.deepEqual(rifling.rows.find((row) => row.symbol === "i"), {
    symbol: "i",
    value: "3°10'36\"",
    unit: "",
  });
});

test("matchesQuery searches names and alternative names, case-insensitively", () => {
  const w308 = byKey("308_win");
  assert.equal(F.matchesQuery(w308, "7,62 x 51"), true);
  assert.equal(F.matchesQuery(w308, "308 win"), true);
  assert.equal(F.matchesQuery(w308, "  308  "), true);
  assert.equal(F.matchesQuery(w308, "223"), false);
});

test("matchesQuery treats an empty or blank query as a match for every record", () => {
  assert.equal(F.matchesQuery(byKey("223_rem"), ""), true);
  assert.equal(F.matchesQuery(byKey("223_rem"), "   "), true);
});

test("matchesQuery matches regular expression characters literally", () => {
  assert.equal(F.matchesQuery(byKey("308_win"), ".*"), false);
  assert.equal(F.matchesQuery(byKey("308_win"), "("), false);
});

test("filterCartridges applies the search and the family select", () => {
  assert.equal(F.filterCartridges(records, "", "All").length, 25);
  assert.equal(F.filterCartridges(records, "", "pistol").length, 6);
  assert.equal(F.filterCartridges(records, "", "belted").length, 2);
  assert.deepEqual(
    F.filterCartridges(records, "7,62 x 51", "All").map((r) => r.key),
    ["308_win"],
  );
  assert.equal(F.filterCartridges(records, "7,62 x 51", "pistol").length, 0);
});

test("countLabel uses the singular for one cartridge", () => {
  assert.equal(F.countLabel(1), "1 cartridge");
  assert.equal(F.countLabel(0), "0 cartridges");
  assert.equal(F.countLabel(25), "25 cartridges");
});
