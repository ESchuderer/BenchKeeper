const test = require("node:test");
const assert = require("node:assert/strict");
const G = require("../js/geometry.js");
const records = require("../data/cartridges.js");

const byKey = (key) => records.find((r) => r.key === key);
const near = (a, b, eps = 0.01) => Math.abs(a - b) <= eps;
const hasPoint = (pts, z, r, eps = 0.01) => pts.some((p) => near(p[0], z, eps) && near(p[1], r, eps));

test("rimType follows the family for belted and rimfire and the R1/P1 ratio otherwise", () => {
  assert.equal(G.rimType(byKey("9_mm_luger")), "rimless");
  assert.equal(G.rimType(byKey("9_3_x_74_r")), "rimmed");
  assert.equal(G.rimType(byKey("38_special")), "rimmed");
  assert.equal(G.rimType(byKey("300_win_mag")), "belted");
  assert.equal(G.rimType(byKey("22_long_rifle")), "rimfire");
});

test("bulletSpec for a pointy rifle bullet (223 Rem.)", () => {
  const b = G.bulletSpec(byKey("223_rem"));
  assert.equal(b.heeled, false);
  assert.ok(near(b.s, 5.7, 1e-9), "s = 1.0 G1");
  assert.ok(near(b.zb, 39.0, 1e-9), "zb = L3 - s");
  assert.ok(near(b.Lb, 18.4, 1e-9), "Lb = L6 - zb");
  assert.equal(b.k, 0.4);
  assert.ok(near(b.m, 1.27, 1e-9), "m = max(0.08 G1, 1.27)");
  assert.ok(b.zc > 44.7, "exposed cylinder ends past the mouth");
});

test("bulletSpec for a heeled rimfire bullet (22 Long Rifle)", () => {
  const b = G.bulletSpec(byKey("22_long_rifle"));
  assert.equal(b.heeled, true);
  assert.equal(b.D, 5.72);
  assert.ok(near(b.s, 0.8 * 5.72, 1e-9), "rounded rifle or rimfire: 0.8 G1");
  assert.equal(b.k, 0.55);
});

test("bulletSpec for a pistol rounded bullet and a semi-wadcutter", () => {
  const luger = G.bulletSpec(byKey("9_mm_luger"));
  assert.ok(near(luger.s, 0.4 * 9.03, 1e-9), "pistol rounded: 0.4 G1");
  assert.equal(luger.k, 0.65);
  const magnum = G.bulletSpec(byKey("44_rem_mag"));
  assert.ok(near(magnum.s, 0.6 * 10.97, 1e-9), "semi-wadcutter: 0.6 G1");
  assert.equal(magnum.k, 0.78);
});

test("wallSpec: neck and body walls, heeled cases use the body wall at the mouth", () => {
  const w = G.wallSpec(byKey("223_rem"));
  assert.ok(near(w.tn, (6.43 - 5.7) / 2, 1e-9));
  assert.equal(w.tb, 0.6);
  assert.equal(w.heeled, false);
  assert.equal(w.mouthWall, w.tn);

  const h = G.wallSpec(byKey("22_long_rifle"));
  assert.equal(h.heeled, true);
  assert.equal(h.mouthWall, h.tb);
});

test("primerPocket gives the diameter and depth for centrefire primers and null for rimfire", () => {
  assert.deepEqual(G.primerPocket(byKey("223_rem")), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(G.primerPocket(byKey("6_5_creedmoor")), { diameter: 5.33, depth: 3.3 });
  assert.equal(G.primerPocket(byKey("22_long_rifle")), null);
});

test("buildProfile outline runs from the axis at the head face to the axis at the tip, z never decreases", () => {
  for (const r of records) {
    const { outline } = G.buildProfile(r);
    assert.deepEqual(outline[0], [0, 0], r.key);
    assert.deepEqual(outline[outline.length - 1], [r.cartridge.lengths.L6, 0], r.key);
    for (const [z, rad] of outline) {
      assert.ok(Number.isFinite(z) && Number.isFinite(rad), r.key);
    }
    for (let i = 1; i < outline.length; i++) {
      assert.ok(outline[i][0] >= outline[i - 1][0] - 1e-9, `${r.key} z order at ${i}`);
    }
  }
});

test("section polygons contain only finite values for all records", () => {
  for (const r of records) {
    const p = G.buildProfile(r);
    for (const pt of [...p.caseSection, ...p.bulletSection]) {
      assert.ok(pt.every(Number.isFinite), r.key);
    }
  }
});

test("the nose ends at the meplat: pointy meplat diameter is max(0.08 G1, 1.27)", () => {
  const { outline } = G.buildProfile(byKey("223_rem"));
  assert.ok(hasPoint(outline, 57.4, 0.635), "meplat corner at (L6, m/2)");
});

test("a fillet rounds the body-side shoulder corner at L1 (223 Rem.)", () => {
  const { outline } = G.buildProfile(byKey("223_rem"));
  const near_l1 = outline.filter((p) => Math.abs(p[0] - 36.52) < 0.2);
  assert.ok(near_l1.length >= 3, "several samples on the arc");
});

test("belted case: the ramp reaches the belt radius R3/2 and the belt runs to z = E", () => {
  const { outline } = G.buildProfile(byKey("300_win_mag"));
  const dz = (6.755 - 6.035) / Math.tan((35 * Math.PI) / 180);
  assert.ok(hasPoint(outline, 1.27 + 0.94 + dz, 6.755), "ramp end on the belt");
  assert.ok(hasPoint(outline, 5.59, 6.755), "belt end at z = E");
  assert.ok(hasPoint(outline, 5.59, 6.515), "step in to P1/2 at z = E");
});

test("rimfire rim is a half-round whose outermost point is R1/2", () => {
  const { outline } = G.buildProfile(byKey("22_long_rifle"));
  const top = outline.reduce((a, b) => (b[1] > a[1] ? b : a));
  assert.ok(near(top[1], 7.06 / 2, 1e-6), "outermost radius is R1/2");
  assert.ok(near(top[0], Math.min(1.09 / 2, (7.06 - 5.74) / 2), 0.02), "outermost point at rho");
});

test("heeled case: cavity wall at the mouth equals the heel radius H2/2 - tb", () => {
  const b = G.bulletSpec(byKey("22_long_rifle"));
  const w = G.wallSpec(byKey("22_long_rifle"));
  const heel = 5.72 / 2 - w.tb;
  for (let z = b.zb; z <= 15.57; z += 0.5) {
    assert.ok(G.innerRadius(byKey("22_long_rifle"), z) >= heel - 1e-9, `z=${z}`);
  }
});

test("the case cavity never cuts into the seated bullet (all records)", () => {
  for (const r of records) {
    const b = G.bulletSpec(r);
    const w = G.wallSpec(r);
    const L3 = r.cartridge.lengths.L3;
    const seat = b.heeled ? r.cartridge.collar.H2 / 2 - w.tb : b.D / 2;
    for (let z = b.zb; z <= L3; z += 0.25) {
      assert.ok(G.innerRadius(r, z) >= seat - 1e-6, `${r.key} z=${z}`);
    }
  }
});

test("headDepth: w is at least 2.5 and at least the pocket depth plus 1.5 when a pocket exists", () => {
  assert.ok(G.headDepth(byKey("223_rem")) >= 4.54 - 1e-9);
  assert.ok(G.headDepth(byKey("22_long_rifle")) >= 2.5 - 1e-9);
  for (const r of records) {
    assert.ok(Number.isFinite(G.headDepth(r)), r.key);
  }
});

test("missing values are reported by field name and the drawing skips them", () => {
  assert.deepEqual(G.buildProfile(byKey("223_rem")).missing, []);
  assert.deepEqual(G.buildProfile(byKey("22_long_rifle")).missing, []);
  assert.ok(G.buildProfile(byKey("338_lapua_mag")).missing.includes("r1Min"));
  const m17 = G.buildProfile(byKey("17_hmr")).missing;
  assert.ok(m17.includes("r1Min") && m17.includes("r2"));
});

function crosses(p1, p2, p3, p4) {
  const o = (a, b, c) => Math.sign((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]));
  return o(p1, p2, p3) * o(p1, p2, p4) < 0 && o(p3, p4, p1) * o(p3, p4, p2) < 0;
}

test("section polygons do not cross themselves (all records)", () => {
  for (const r of records) {
    for (const poly of [G.buildProfile(r).caseSection, G.buildProfile(r).bulletSection]) {
      const n = poly.length;
      for (let i = 0; i < n; i++) {
        for (let j = i + 2; j < n; j++) {
          if (i === 0 && j === n - 1) continue;
          assert.ok(!crosses(poly[i], poly[(i + 1) % n], poly[j], poly[(j + 1) % n]), `${r.key} edges ${i} ${j}`);
        }
      }
    }
  }
});

test("the case wall has positive thickness along the body and neck (all records)", () => {
  for (const r of records) {
    const L3 = r.cartridge.lengths.L3;
    const H2 = r.cartridge.collar.H2 / 2;
    const wall = G.wallSpec(r);
    assert.ok(near(H2 - G.innerRadius(r, L3), wall.mouthWall, 1e-9), r.key);
    assert.ok(G.innerRadius(r, L3 - 0.5) > 0, r.key);
  }
});
