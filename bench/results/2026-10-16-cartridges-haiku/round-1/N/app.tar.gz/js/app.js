// Page behaviour: start page list with search and family filter, detail view per cartridge, print.
(function (ns) {
  'use strict';

  const { formatWithTol, sectionGroups } = ns.format;
  const { FAMILIES, filterCartridges } = ns.list;
  const { build } = ns.geometry;
  const { planDrawing, toSvg } = ns.drawing;
  const records = ns.records;
  const main = document.getElementById('app');
  const listState = { query: '', family: 'All' };

  const esc = (text) =>
    String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  const recordByKey = (key) => records.find((record) => record.key === key);

  function listView() {
    document.title = 'Cartridges';
    main.innerHTML = `
      <h1>Cartridges</h1>
      <form class="filters" role="search">
        <label>Search <input id="query" type="search" autocomplete="off" value="${esc(listState.query)}"></label>
        <label>Family <select id="family">${FAMILIES.map(
          (family) => `<option value="${esc(family)}"${family === listState.family ? ' selected' : ''}>${esc(family)}</option>`,
        ).join('')}</select></label>
      </form>
      <p id="count" class="count" aria-live="polite"></p>
      <table class="cartridge-list">
        <thead><tr><th scope="col">Name</th><th scope="col">Family</th><th scope="col">L3</th></tr></thead>
        <tbody id="rows"></tbody>
      </table>`;
    const query = document.getElementById('query');
    const family = document.getElementById('family');
    const update = () => {
      listState.query = query.value;
      listState.family = family.value;
      renderRows();
    };
    document.querySelector('.filters').addEventListener('submit', (event) => event.preventDefault());
    query.addEventListener('input', update);
    family.addEventListener('change', update);
    renderRows();
  }

  function renderRows() {
    const found = filterCartridges(records, listState);
    document.getElementById('rows').innerHTML = found
      .map(
        (record) => `<tr>
          <td><a href="#/cartridges/${esc(record.key)}">${esc(record.name)}</a></td>
          <td>${esc(record.family)}</td>
          <td class="num">${esc(formatWithTol(record.cartridge.lengths.L3, record.cartridge.lengths.L3Tol))} mm</td>
        </tr>`,
      )
      .join('');
    document.getElementById('count').textContent = `${found.length} cartridges`;
  }

  const metaRow = (label, valueHtml) => `<dt>${esc(label)}</dt><dd>${valueHtml}</dd>`;

  function waterCapacityHtml(capacity) {
    if (!capacity) return 'Not published';
    const { grH2O, source, url, note } = capacity;
    const link = /^https?:\/\//.test(url || '') ? `<a href="${esc(url)}">${esc(source)}</a>` : esc(source);
    return `${esc(grH2O)} gr H2O, source ${link}${note ? `. ${esc(note)}` : ''}`;
  }

  function valueTables(section) {
    return sectionGroups(section)
      .map(
        (group) => `<h3>${esc(group.title)}</h3>
        <table class="values">
          <thead><tr><th scope="col">Symbol</th><th scope="col">Value</th><th scope="col">Unit</th></tr></thead>
          <tbody>${group.rows
            .map((row) => `<tr><th scope="row">${esc(row.symbol)}</th><td class="num">${esc(row.value)}</td><td>${esc(row.unit)}</td></tr>`)
            .join('')}</tbody>
        </table>`,
      )
      .join('');
  }

  function drawingHtml(record) {
    const model = build(record);
    if (!model.ok) return '<p class="notice">Drawing not available: cartridge outline values missing.</p>';
    const svg = toSvg(planDrawing(record, model), record.name);
    const notes = model.missing.map((item) => `<li>Not drawn: ${esc(item.feature)} (${esc(item.values.join(', '))} missing)</li>`);
    return `<figure class="drawing">${svg}${notes.length ? `<figcaption><ul>${notes.join('')}</ul></figcaption>` : ''}</figure>`;
  }

  function detailView(record) {
    const { annotations: a, cartridge: c } = record;
    document.title = `${record.name} | Cartridges`;
    const alternatives = record.alternativeNames && record.alternativeNames.length ? record.alternativeNames.join(', ') : 'None';
    main.innerHTML = `
      <nav class="toolbar">
        <a href="#/">All cartridges</a>
        <button type="button" id="print">Print</button>
      </nav>
      <article class="detail">
        <h1>${esc(record.name)}</h1>
        <dl class="meta">
          ${metaRow('Alternative names', esc(alternatives))}
          ${metaRow('Family', esc(record.family))}
          ${metaRow('Category', esc(a.category))}
          ${metaRow('Primer type', esc(a.primerType))}
          ${metaRow('C.I.P. table', esc(record.tab))}
          ${metaRow('Country', esc(record.country))}
          ${metaRow('Published', esc(record.published))}
          ${metaRow('Revised', esc(record.revised))}
          ${metaRow('Pressure method', esc(record.pressureMethod))}
          ${metaRow('Water capacity', waterCapacityHtml(a.publishedCapacity))}
        </dl>
        ${drawingHtml(record)}
        <div class="values-grid">
          <section>
            <h2>Cartridge</h2>
            ${valueTables(c)}
          </section>
          <section>
            <h2>Chamber</h2>
            ${valueTables(record.chamber)}
          </section>
        </div>
        <footer class="source">Source: C.I.P. TDCC, revised ${esc(record.revised)}</footer>
      </article>`;
    document.getElementById('print').addEventListener('click', () => window.print());
  }

  function notFoundView(key) {
    document.title = 'Not found | Cartridges';
    main.innerHTML = `<nav class="toolbar"><a href="#/">All cartridges</a></nav>
      <h1>Not found</h1><p>No cartridge with the key <code>${esc(key)}</code>.</p>`;
  }

  function route() {
    const match = /^#\/cartridges\/(.+)$/.exec(location.hash);
    if (!match) {
      listView();
      return;
    }
    let key;
    try {
      key = decodeURIComponent(match[1]);
    } catch (error) {
      notFoundView(match[1]);
      return;
    }
    const record = recordByKey(key);
    if (record) detailView(record);
    else notFoundView(key);
    window.scrollTo(0, 0);
  }

  window.addEventListener('hashchange', route);
  route();
})(globalThis.Cip);
