// Cartridge drawing as SVG in mm (1 user unit = 1 mm). Outside view above the axis (y < 0), section below (y > 0).
// Axial and R labels sit at fixed positions left of the head; diameter and R1 labels are placed by search: the
// first free position that touches no line, outline, title block or other label.
(function (ns) {
  const RAD = Math.PI / 180;
  const FONT = 2.5;
  const GAP = 0.6; // gap between an extension line and the outline
  const LANE_BASE = 5.5; // first axial dimension lane above the largest radius
  const LANE_GAP = 4.6;
  const REAR_OFFSET = 2.4; // lower R dimension below the rim
  const RIM_X = -3; // R1 dimension line, left of the head face
  const RIM_EXT_X = -4;
  const LABEL_X = -1.2; // right edge of fixed labels left of the head face
  const TITLE_W = 56;
  const TITLE_H = 22;
  const LABEL_DIRS = [-90, -60, -120, -30, -150, 0, 180, 30, 150, 60, 90].map((d) => d * RAD);

  const esc = (text) =>
    String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  const textWidth = (text) => text.length * 0.6 * FONT + 0.6;

  function segmentsOf(points) {
    return points.slice(1).map((p, i) => [...points[i], ...p]);
  }

  // Liang-Barsky clip of a segment against a rectangle grown by margin.
  function segmentHitsRect([x1, y1, x2, y2], rect, margin) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const p = [-dx, dx, -dy, dy];
    const q = [x1 - rect.x0 + margin, rect.x1 + margin - x1, y1 - rect.y0 + margin, rect.y1 + margin - y1];
    let t0 = 0;
    let t1 = 1;
    for (let i = 0; i < 4; i++) {
      if (p[i] === 0) {
        if (q[i] < 0) return false;
      } else {
        const t = q[i] / p[i];
        if (p[i] < 0) {
          if (t > t1) return false;
          t0 = Math.max(t0, t);
        } else {
          if (t < t0) return false;
          t1 = Math.min(t1, t);
        }
      }
    }
    return true;
  }

  function rectsOverlap(a, b, margin = 0) {
    return a.x0 < b.x1 + margin && b.x0 < a.x1 + margin && a.y0 < b.y1 + margin && b.y0 < a.y1 + margin;
  }

  // Obstacles are segments [x1, y1, x2, y2] or { rect }.
  function hitsObstacles(rect, obstacles) {
    return obstacles.some((o) => (o.length === 4 ? segmentHitsRect(o, rect, 0.4) : rectsOverlap(o.rect, rect, 0.4)));
  }

  function labelAt(text, x, y, anchor) {
    const w = textWidth(text);
    const x0 = anchor === 'end' ? x - w : x - w / 2;
    return { text, anchor, rect: { x0, x1: x0 + w, y0: y - FONT / 2, y1: y + FONT / 2 }, baseline: [x, y + 0.35 * FONT] };
  }

  // First free position around the anchor, searching outward in LABEL_DIRS order.
  function searchLabel(text, anchor, state) {
    const w = textWidth(text);
    const h = FONT;
    for (let rho = 0; rho <= 12; rho += 0.5) {
      for (const angle of LABEL_DIRS) {
        const ux = Math.cos(angle);
        const uy = Math.sin(angle);
        const dist = rho + 0.8 + (Math.abs(ux) * w) / 2 + (Math.abs(uy) * h) / 2;
        const cx = anchor[0] + ux * dist;
        const cy = anchor[1] + uy * dist;
        const rect = { x0: cx - w / 2, x1: cx + w / 2, y0: cy - h / 2, y1: cy + h / 2 };
        const inside = rect.x0 >= state.bounds.x0 && rect.x1 <= state.bounds.x1 && rect.y0 >= state.bounds.y0 && rect.y1 <= state.bounds.y1;
        if (inside && !hitsObstacles(rect, state.obstacles) && !state.placed.some((p) => rectsOverlap(p, rect))) {
          return labelAt(text, cx, cy, 'middle');
        }
      }
    }
    return { text, anchor: 'middle', rect: null, baseline: null };
  }

  // Symbol and value with its published tolerance, e.g. "L1 39.62 -0.2".
  function valueText(field, value, tol) {
    const { formatWithTol, symbolFor } = ns.format;
    return `${symbolFor(field)} ${formatWithTol(value, tol)}`;
  }

  // Shoulder angle arc about the apex of the shoulder line; points are [z, v] with v > 0 in the outside half.
  function alphaArc(L1, L2, P2, H1) {
    const zApex = L1 + ((P2 / 2) * (L2 - L1)) / (P2 / 2 - H1 / 2);
    const rho = Math.hypot(L2 - zApex, H1 / 2);
    const start = Math.atan2(H1 / 2, L2 - zApex);
    const end = 2 * Math.PI - start;
    const steps = 24;
    const points = Array.from({ length: steps + 1 }, (_, i) => {
      const t = start + ((end - start) * i) / steps;
      return [zApex + rho * Math.cos(t), rho * Math.sin(t)];
    });
    return { points };
  }

  function planDrawing(record, model) {
    if (!model.ok) return null;
    const c = record.cartridge;
    const { caseHead: cf, collar, lengths, powderChamber: pc, projectile } = c;
    const { R, R1, E, eMin } = cf;
    const { L3, L6 } = lengths;
    const outerMax = Math.max(...model.outline.map(([, r]) => r));
    const headR = model.outline[1][1];
    const bodyStart = model.grooveDrawn ? E : R;
    const bullet = model.bullet;
    const mirror = (points, sign) => points.map(([z, r]) => [z, sign * r]);

    const lines = []; // [x1, y1, x2, y2, arrows]
    const arrowHeads = []; // SVG path data for arrowheads drawn outside their line
    const fixed = [];
    const searched = [];

    // Axial dimensions in lanes above the part; longer spans sit higher, so no line crosses another.
    const lanes = [];
    if (model.bottleneck && lengths.L1 !== undefined && pc.P2 !== undefined) lanes.push({ field: 'L1', value: lengths.L1, tol: lengths.L1Tol, z: lengths.L1, r: pc.P2 / 2 });
    if (model.bottleneck && lengths.L2 !== undefined && collar.H1 !== undefined) lanes.push({ field: 'L2', value: lengths.L2, tol: lengths.L2Tol, z: lengths.L2, r: collar.H1 / 2 });
    lanes.push({ field: 'L3', value: L3, tol: lengths.L3Tol, z: L3, r: collar.H2 / 2 });
    if (bullet) lanes.push({ field: 'L6', value: L6, tol: undefined, z: L6, r: bullet.m / 2 });
    lanes.sort((a, b) => a.value - b.value);
    const laneY = (k) => -(outerMax + LANE_BASE + LANE_GAP * k);
    lanes.forEach((lane, k) => {
      const y = laneY(k);
      lines.push([0, y, lane.value, y, true]);
      lines.push([0, -(headR + GAP), 0, y - 1, false]);
      lines.push([lane.z, -(lane.r + GAP), lane.z, y - 1, false]);
      fixed.push(labelAt(valueText(lane.field, lane.value, lane.tol), LABEL_X, y, 'end'));
    });

    // Diameters: a vertical dimension line across the full diameter at the feature.
    const diameters = [];
    const diameter = (field, z, value, tol) => {
      lines.push([z, -value / 2, z, value / 2, true]);
      diameters.push({ text: valueText(field, value, tol), anchor: [z, -value / 2 - GAP] });
    };
    if (model.grooveDrawn && cf.E1 !== undefined) diameter('E1', R + eMin / 2, cf.E1, cf.E1Tol);
    diameter('P1', bodyStart, pc.P1, pc.P1Tol);
    if (model.bottleneck && pc.P2 !== undefined) diameter('P2', lengths.L1, pc.P2, pc.P2Tol);
    if (model.bottleneck && collar.H1 !== undefined) diameter('H1', lengths.L2, collar.H1, collar.H1Tol);
    diameter('H2', L3, collar.H2, collar.H2Tol);
    if (bullet) diameter('G1', (L3 + bullet.zc) / 2, projectile.G1, projectile.G1Tol);

    // R1 across the rim, left of the head face.
    lines.push([RIM_X, -R1 / 2, RIM_X, R1 / 2, true]);
    lines.push([R / 2, -R1 / 2, RIM_EXT_X, -R1 / 2, false]);
    lines.push([R / 2, R1 / 2, RIM_EXT_X, R1 / 2, false]);
    diameters.push({ text: valueText('R1', R1, undefined), anchor: [RIM_X, 0] });

    // R across the rim thickness, below the section, labelled left of the head.
    const yRim = R1 / 2 + REAR_OFFSET;
    // Arrowheads are 2.2 mm long; below that span they sit outside the gap, as filled triangles.
    const ARROW = 2.2;
    const outsideArrows = R < 2 * ARROW;
    if (outsideArrows) {
      lines.push([-ARROW, yRim, 0, yRim, false], [R, yRim, R + ARROW, yRim, false]);
      arrowHeads.push(`M0 ${yRim} L${-ARROW} ${(yRim - ARROW / 2).toFixed(3)} L${-ARROW} ${(yRim + ARROW / 2).toFixed(3)} Z`);
      arrowHeads.push(`M${R} ${yRim} L${(R + ARROW).toFixed(3)} ${(yRim - ARROW / 2).toFixed(3)} L${(R + ARROW).toFixed(3)} ${(yRim + ARROW / 2).toFixed(3)} Z`);
    } else {
      lines.push([0, yRim, R, yRim, true]);
    }
    lines.push([0, headR + GAP, 0, yRim + 1, false]);
    lines.push([R, R1 / 2 + GAP, R, yRim + 1, false]);
    fixed.push(labelAt(valueText('R', R, cf.RTol), outsideArrows ? LABEL_X - ARROW : LABEL_X, yRim, 'end'));

    // Shoulder angle: arc about the apex, labelled below the shoulder.
    const arcSegments = [];
    if (model.bottleneck && c.junctionCone.alpha !== undefined && pc.P2 / 2 > collar.H1 / 2) {
      const arc = alphaArc(lengths.L1, lengths.L2, pc.P2, collar.H1);
      for (let i = 0; i < arc.points.length - 1; i++) {
        const [z1, v1] = arc.points[i];
        const [z2, v2] = arc.points[i + 1];
        arcSegments.push([z1, -v1, z2, -v2]);
      }
      const { formatAngle } = ns.format;
      fixed.push(labelAt(`α ${formatAngle(c.junctionCone.alpha)}`, (lengths.L1 + lengths.L2) / 2, pc.P2 / 2 + 3.4, 'middle'));
    }

    // Bounds and title block.
    const xMax = L6 + 14;
    const titleY0 = yRim + 4.5;
    const titleRect = { x0: Math.min(-16, xMax - TITLE_W), x1: xMax, y0: titleY0, y1: titleY0 + TITLE_H };
    const xMin = Math.min(-16, ...fixed.map((l) => l.rect.x0 - 1.5), titleRect.x0);
    const bounds = { x0: xMin, x1: xMax, y0: laneY(lanes.length - 1) - 4.5, y1: titleRect.y1 + 1 };

    const obstacles = [];
    obstacles.push(...segmentsOf(mirror(model.outline, -1)), ...segmentsOf(mirror(model.outline, 1)));
    if (bullet) obstacles.push(...segmentsOf(mirror(bullet.outline, 1)));
    for (const ring of [model.headPolygon, model.wallPolygon]) obstacles.push(...segmentsOf([...ring, ring[0]]));
    obstacles.push([bounds.x0, 0, xMax, 0]);
    for (const [x1, y1, x2, y2] of lines) obstacles.push([x1, y1, x2, y2]);
    obstacles.push(...arcSegments);
    obstacles.push({ rect: titleRect });

    const state = { bounds, obstacles, placed: fixed.map((l) => l.rect) };
    for (const d of diameters) {
      const label = searchLabel(d.text, d.anchor, state);
      if (label.rect) state.placed.push(label.rect);
      searched.push(label);
    }

    const labels = [...fixed, ...searched];
    return {
      name: record.name,
      viewBox: { x: bounds.x0, y: bounds.y0, w: bounds.x1 - bounds.x0, h: bounds.y1 - bounds.y0 },
      outline: { top: mirror(model.outline, -1), bottom: mirror(model.outline, 1) },
      section: {
        head: model.headPolygon,
        wall: model.wallPolygon,
        bullet: bullet ? mirror(bullet.outline, 1) : null,
      },
      lines,
      arrowHeads,
      arcs: arcSegments,
      centreLine: [bounds.x0, 0, xMax, 0],
      title: {
        rect: titleRect,
        lines: [
          { text: record.name, bold: true },
          { text: `C.I.P. table ${record.tab}` },
          { text: `Revised ${record.revised}` },
          { text: 'Dimensions in mm' },
          { text: 'Scale 1:1' },
        ],
      },
      labels,
      obstacles,
    };
  }

  function pathOf(points, closed = false) {
    const d = points.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(3)} ${y.toFixed(3)}`).join(' ');
    return closed ? d + ' Z' : d;
  }

  function toSvg(plan, name) {
    const { x, y, w, h } = plan.viewBox;
    const num = (v) => v.toFixed(3);
    const lines = plan.lines
      .map(([x1, y1, x2, y2, arrows]) => `<line x1="${num(x1)}" y1="${num(y1)}" x2="${num(x2)}" y2="${num(y2)}"${arrows ? ' class="dim" marker-start="url(#cip-arrow)" marker-end="url(#cip-arrow)"' : ' class="ext"'}/>`)
      .join('');
    const arcs = plan.arcs.map(([x1, y1, x2, y2]) => `<line x1="${num(x1)}" y1="${num(y1)}" x2="${num(x2)}" y2="${num(y2)}" class="dim"/>`).join('');
    const labels = plan.labels
      .filter((label) => label.baseline)
      .map((label) => `<text class="dim-label" x="${num(label.baseline[0])}" y="${num(label.baseline[1])}" text-anchor="${label.anchor}">${esc(label.text)}</text>`)
      .join('');
    const [cx0, , cx1] = plan.centreLine;
    const t = plan.title;
    const titleLines = t.lines
      .map((line, i) => `<text class="title-line${line.bold ? ' title-name' : ''}" x="${num(t.rect.x0 + 1.2)}" y="${num(t.rect.y0 + 4 + i * 3.4)}">${esc(line.text)}</text>`)
      .join('');
    return [
      `<svg class="cartridge-drawing" viewBox="${num(x)} ${num(y)} ${num(w)} ${num(h)}" role="img" aria-label="${esc(name)} drawing" xmlns="http://www.w3.org/2000/svg">`,
      '<defs>',
      '<marker id="cip-arrow" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="2.2" markerHeight="2.2" markerUnits="userSpaceOnUse" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="currentColor"/></marker>',
      '<pattern id="cip-hatch" width="1.4" height="1.4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0,0 V1.4" stroke="currentColor" stroke-width="0.25"/></pattern>',
      '</defs>',
      `<line x1="${num(cx0)}" y1="0" x2="${num(cx1)}" y2="0" class="centre" stroke-dasharray="8 1.5 1.5 1.5"/>`,
      `<path d="${pathOf(plan.section.head, true)}" class="section" fill="url(#cip-hatch)"/>`,
      `<path d="${pathOf(plan.section.wall, true)}" class="section" fill="url(#cip-hatch)"/>`,
      `<path d="${pathOf(plan.outline.top)}" class="outline" fill="none"/>`,
      `<path d="${pathOf(plan.outline.bottom)}" class="outline" fill="none"/>`,
      plan.section.bullet ? `<path d="${pathOf(plan.section.bullet)}" class="outline" fill="none"/>` : '',
      lines,
      arcs,
      plan.arrowHeads.map((d) => `<path d="${d}" fill="currentColor"/>`).join(''),
      labels,
      `<rect x="${num(t.rect.x0)}" y="${num(t.rect.y0)}" width="${num(t.rect.x1 - t.rect.x0)}" height="${num(t.rect.y1 - t.rect.y0)}" class="title-box" fill="none"/>`,
      titleLines,
      '</svg>',
    ].join('');
  }

  ns.drawing = { planDrawing, toSvg, hitsObstacles, rectsOverlap };
})(globalThis.Cip = globalThis.Cip || {});
