// Display rules for cartridge values: numbers, tolerances, angles, symbols, units and grouped table rows.
(function (ns) {
  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };
  const ANGLE_FIELDS = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling',
  };

  function formatNumber(value) {
    return String(value);
  }

  function formatWithTol(value, tol) {
    return tol === undefined ? formatNumber(value) : `${formatNumber(value)} ${formatNumber(tol)}`;
  }

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  function formatAngle(angle) {
    if (typeof angle === 'number') return `${formatNumber(angle)}°`;
    return `${angle.degrees}°${pad2(angle.minutes)}'${pad2(angle.seconds)}"`;
  }

  function symbolFor(field) {
    return Object.hasOwn(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unitFor(field) {
    if (ANGLE_FIELDS.has(field)) return '';
    return Object.hasOwn(UNITS, field) ? UNITS[field] : 'mm';
  }

  function valueFor(field, value, tol) {
    return ANGLE_FIELDS.has(field) ? formatAngle(value) : formatWithTol(value, tol);
  }

  function groupRows(values) {
    return Object.keys(values)
      .filter((field) => !field.endsWith('Tol'))
      .map((field) => ({
        symbol: symbolFor(field),
        value: valueFor(field, values[field], values[field + 'Tol']),
        unit: unitFor(field),
      }));
  }

  function sectionGroups(section) {
    return Object.keys(section)
      .map((group) => ({
        title: Object.hasOwn(TITLES, group) ? TITLES[group] : group,
        rows: groupRows(section[group]),
      }))
      .filter((group) => group.rows.length > 0);
  }

  ns.format = {
    formatNumber,
    formatWithTol,
    formatAngle,
    symbolFor,
    unitFor,
    sectionGroups,
  };
})(globalThis.Cip = globalThis.Cip || {});
