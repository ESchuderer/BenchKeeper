// Cartridge and bullet profile in mm. Points are [z, r]: z is the axial distance from the head face, r the radius.
// The brief's (r, z) tuples are converted here; the outline runs from the axis at the head face to the axis at the bullet tip.
(function (ns) {
  const RAD = Math.PI / 180;
  const ARC_STEP = 5 * RAD;
  const POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 },
  };
  const CASE_NEEDS = [
    ['caseHead', 'R'],
    ['caseHead', 'R1'],
    ['powderChamber', 'P1'],
    ['collar', 'H2'],
    ['projectile', 'G1'],
    ['lengths', 'L3'],
    ['lengths', 'L6'],
  ];

  const toDegrees = (angle) => (typeof angle === 'number' ? angle : angle.degrees + angle.minutes / 60 + angle.seconds / 3600);
  const tanDeg = (angle) => Math.tan(toDegrees(angle) * RAD);
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
  const add = (a, b) => [a[0] + b[0], a[1] + b[1]];
  const scale = (a, s) => [a[0] * s, a[1] * s];
  const unit = (a) => scale(a, 1 / Math.hypot(a[0], a[1]));

  // Points on a circle from angle `from` to angle `to` (radians), both ends included.
  function arcPoints(centre, radius, from, to) {
    const steps = Math.max(2, Math.ceil(Math.abs(to - from) / ARC_STEP));
    return Array.from({ length: steps + 1 }, (_, i) => {
      const t = from + ((to - from) * i) / steps;
      return [centre[0] + radius * Math.cos(t), centre[1] + radius * Math.sin(t)];
    });
  }

  // Replaces the corner between `from` and `to` by a tangent arc of `radius`; returns the arc, ends included.
  function fillet(from, corner, to, radius) {
    if (!(radius > 0)) return [corner];
    const u1 = unit(sub(corner, from));
    const u2 = unit(sub(to, corner));
    const phi = Math.acos(clamp(u1[0] * u2[0] + u1[1] * u2[1], -1, 1));
    if (phi < 1e-6) return [corner];
    const d = radius * Math.tan(phi / 2);
    const t1 = sub(corner, scale(u1, d));
    const t2 = add(corner, scale(u2, d));
    const centre = add(corner, scale(unit(sub(u2, u1)), radius / Math.cos(phi / 2)));
    const start = Math.atan2(t1[1] - centre[1], t1[0] - centre[0]);
    let sweep = Math.atan2(t2[1] - centre[1], t2[0] - centre[0]) - start;
    if (sweep > Math.PI) sweep -= 2 * Math.PI;
    if (sweep < -Math.PI) sweep += 2 * Math.PI;
    return arcPoints(centre, radius, start, start + sweep);
  }

  function rimTypeOf(record) {
    const { family } = record;
    if (family === 'belted' || family === 'rimfire') return family;
    const ratio = record.cartridge.caseHead.R1 / record.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Splits a path at axial position z0; both halves contain the interpolated cut point.
  function splitAt(path, z0) {
    const before = path.filter(([z]) => z <= z0);
    const after = path.filter(([z]) => z > z0);
    const p = before.at(-1);
    const q = after[0];
    const cut = [z0, p[1] + ((q[1] - p[1]) * (z0 - p[0])) / (q[0] - p[0])];
    return { before: [...before, cut], after: [cut, ...after] };
  }

  function bulletSpec(shape, isPistol, G1) {
    const seatRoundFlat = isPistol ? 0.4 : 0.8;
    switch (shape) {
      case 'pointy':
        return { s: G1, k: 0.4, m: Math.max(0.08 * G1, 1.27), nose: 'ogive' };
      case 'rounded':
        return { s: seatRoundFlat * G1, k: isPistol ? 0.65 : 0.55, m: 0.15 * G1, nose: 'ellipse' };
      case 'flat':
        return { s: seatRoundFlat * G1, k: isPistol ? 0.7 : 0.6, m: 0.55 * G1, nose: 'cone' };
      case 'semi_wadcutter':
        return { s: 0.6 * G1, k: 0.78, m: 0.6 * G1, nose: 'cone' };
      default:
        return null;
    }
  }

  // Nose from [zc, rStart] to the tip at [L6, m/2].
  function noseOf(spec, zc, n, rStart, L6) {
    const a = rStart - spec.m / 2;
    const samples = 24;
    if (spec.nose === 'ogive') {
      const rho = (a * a + n * n) / (2 * a);
      const phiEnd = Math.asin(n / rho);
      const points = Array.from({ length: samples + 1 }, (_, i) => {
        const phi = (phiEnd * i) / samples;
        return [zc + rho * Math.sin(phi), rStart - rho + rho * Math.cos(phi)];
      });
      return { rho, points };
    }
    if (spec.nose === 'ellipse') {
      const points = Array.from({ length: samples + 1 }, (_, i) => {
        const t = ((Math.PI / 2) * i) / samples;
        return [zc + n * Math.sin(t), spec.m / 2 + a * Math.cos(t)];
      });
      return { rho: undefined, points };
    }
    return { rho: undefined, points: [[zc, rStart], [L6, spec.m / 2]] };
  }

  function buildBullet(record, dims) {
    const { L3, L6, G1, H2, tb, tn } = dims;
    const shape = record.annotations.defaultBulletShape;
    const spec = bulletSpec(shape, record.annotations.category === 'pistol', G1);
    if (spec === null) return { bullet: null, missing: [{ feature: 'bullet nose', values: ['defaultBulletShape'] }] };
    const heeled = H2 - G1 <= 0.015;
    const zb = L3 - spec.s;
    const Lb = L6 - zb;
    const zc = zb + spec.k * Lb;
    const rExposed = heeled ? H2 / 2 : G1 / 2;
    const rSeated = heeled ? (H2 - 2 * tb) / 2 : G1 / 2;
    const nose = noseOf(spec, zc, L6 - zc, rExposed, L6);
    const seated = [[zb, 0], [zb, rSeated], [L3, rSeated]];
    if (rExposed !== rSeated) seated.push([L3, rExposed]);
    return {
      bullet: {
        shape,
        s: spec.s,
        k: spec.k,
        m: spec.m,
        rho: nose.rho,
        zb,
        zc,
        Lb,
        heeled,
        rExposed,
        rSeated,
        outline: [...seated, ...nose.points.slice(1), [L6, 0]],
      },
      exposedOutline: [...(heeled ? [] : [[L3, G1 / 2]]), ...nose.points, [L6, 0]],
      missing: [],
    };
  }

  function build(record) {
    const c = record.cartridge;
    const cf = c.caseHead;
    const missingBase = CASE_NEEDS.filter(([group, key]) => (c[group] || {})[key] === undefined).map(([, key]) => key);
    if (missingBase.length) return { ok: false, missing: [{ feature: 'cartridge outline', values: missingBase }] };

    const { R, R1, E, E1, eMin, beta, f, delta } = cf;
    const { P1, P2 } = c.powderChamber;
    const { H1, H2 } = c.collar;
    const { L1, L2, L3, L6 } = c.lengths;
    const { G1 } = c.projectile;
    const rimType = rimTypeOf(record);
    const tn = (H2 - G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * P1) / 2);
    const missing = [];

    // Head face and rim edge.
    const head = [[0, 0]];
    if (rimType === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      const rc = R1 / 2 - rho;
      if (R / 2 - rho > 1e-9) head.push([0, rc]);
      head.push(...arcPoints([R / 2, rc], rho, Math.PI, 0));
    } else {
      const chamfer = beta !== undefined && f !== undefined && toDegrees(beta) < 90;
      if (chamfer) {
        head.push([0, R1 / 2 - Math.min(f * tanDeg(beta), R1 / 4)], [f, R1 / 2]);
      } else {
        head.push([0, R1 / 2]);
      }
      head.push([R, R1 / 2]);
    }

    // Extractor groove (belted: ramp at delta to the belt), or a step to the body.
    let grooveDrawn = false;
    let rampEnd;
    if (E !== undefined && E1 !== undefined) {
      const needs = rimType === 'belted' ? { eMin, R3: c.caseHead.R3, delta } : { eMin };
      const absent = Object.keys(needs).filter((key) => needs[key] === undefined);
      if (absent.length) missing.push({ feature: 'extractor groove', values: absent });
      else grooveDrawn = true;
    }
    if (grooveDrawn) {
      head.push([R, E1 / 2], [R + eMin, E1 / 2]);
      if (rimType === 'belted') {
        const rBelt = c.caseHead.R3 / 2;
        rampEnd = R + eMin + (rBelt - E1 / 2) / tanDeg(delta);
        head.push([rampEnd, rBelt], [E, rBelt]);
      }
      head.push([E, P1 / 2]);
    } else {
      head.push([R, P1 / 2]);
    }
    const bodyStart = grooveDrawn ? E : R;

    // Body, shoulder and neck.
    const junction = c.junctionCone || {};
    const wantsShoulder = junction.alpha !== undefined && L1 !== undefined && L2 !== undefined;
    const shoulderAbsent = wantsShoulder ? [['P2', P2], ['H1', H1]].filter(([, v]) => v === undefined).map(([k]) => k) : [];
    if (shoulderAbsent.length) missing.push({ feature: 'shoulder', values: shoulderAbsent });
    const bottleneck = wantsShoulder && shoulderAbsent.length === 0;
    const mouth = [L3, H2 / 2];
    const body = [[bodyStart, P1 / 2]];
    if (bottleneck) {
      const shoulderStart = [L1, P2 / 2];
      const shoulderEnd = [L2, H1 / 2];
      body.push(...fillet([bodyStart, P1 / 2], shoulderStart, shoulderEnd, junction.r1Min));
      body.push(...fillet(shoulderStart, shoulderEnd, mouth, junction.r2));
    }
    body.push(mouth);
    const caseOuter = head.concat(body.slice(1));

    const offsetAt = (z) => {
      if (!bottleneck) return lerp(tb, tn, clamp((z - bodyStart) / (L3 - bodyStart), 0, 1));
      if (z <= L1) return tb;
      if (z >= L2) return tn;
      return lerp(tb, tn, (z - L1) / (L2 - L1));
    };

    // Primer pocket and solid head.
    const primerType = record.annotations.primerType;
    const pocketSpec = rimType !== 'rimfire' && Object.hasOwn(POCKETS, primerType) ? POCKETS[primerType] : null;
    const pocket = pocketSpec && { ...pocketSpec, r: pocketSpec.diameter / 2 };
    const floorTerm = grooveDrawn ? (rimType === 'belted' ? rampEnd : E) + tb : 0;
    const w = Math.max(2.5, (0.25 * P1) / 2, pocket ? pocket.depth + 1.5 : 0, floorTerm);

    const { before, after } = splitAt(caseOuter, w);
    const headPolygon = pocket ? [[0, pocket.r], ...before.slice(1)] : before.slice();
    headPolygon.push([w, 0]);
    if (pocket) headPolygon.push([pocket.depth, 0], [pocket.depth, pocket.r]);
    const inner = after.map(([z, r]) => [z, r - offsetAt(z)]).reverse();
    const wallPolygon = after.concat(inner);

    const { bullet, exposedOutline, missing: bulletMissing } = buildBullet(record, { L3, L6, G1, H2, tb });
    missing.push(...bulletMissing);
    const outline = exposedOutline ? caseOuter.concat(exposedOutline) : caseOuter;

    return {
      ok: true,
      rimType,
      outline,
      caseOuter,
      headPolygon,
      wallPolygon,
      w,
      tn,
      tb,
      pocket,
      bullet,
      bottleneck,
      grooveDrawn,
      missing,
    };
  }

  ns.geometry = { build, rimTypeOf, fillet };
})(globalThis.Cip = globalThis.Cip || {});
