// Start-page filtering: search over name and alternative names, then family.
(function (ns) {
  const FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  function normalize(text) {
    return text.toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function matchesQuery(record, normalizedQuery) {
    if (normalizedQuery === '') return true;
    const names = [record.name, ...(record.alternativeNames || [])];
    return names.some((name) => normalize(name).includes(normalizedQuery));
  }

  function filterCartridges(records, { query, family }) {
    const normalizedQuery = normalize(query);
    return records.filter(
      (record) => (family === 'All' || record.family === family) && matchesQuery(record, normalizedQuery),
    );
  }

  ns.list = { FAMILIES, filterCartridges };
})(globalThis.Cip = globalThis.Cip || {});
