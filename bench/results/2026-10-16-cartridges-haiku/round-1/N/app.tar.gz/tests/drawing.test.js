const test = require('node:test');
const assert = require('node:assert/strict');
const { load } = require('./load.js');

const Cip = load('format', 'geometry', 'drawing');
const { planDrawing, toSvg } = Cip.drawing;

const byKey = (key) => Cip.records.find((r) => r.key === key);
const plan = (key) => {
  const record = byKey(key);
  return planDrawing(record, Cip.geometry.build(record));
};
const labelTexts = (key) => plan(key).labels.map((label) => label.text);

test('the 308 Win. drawing carries every published dimension with symbol and value', () => {
  const texts = labelTexts('308_win');
  for (const expected of ['L1 39.62 -0.2', 'L2 43.48 -0.2', 'L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53 -0.2', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'E1 10.39', 'α 40°']) {
    assert.ok(texts.includes(expected), `missing label ${expected}: ${texts.join(' | ')}`);
  }
});

test('a dimension is drawn only when its value is published', () => {
  const nine = labelTexts('9_mm_luger');
  assert.ok(!nine.some((t) => t.startsWith('L1 ') || t.startsWith('L2 ') || t.startsWith('α ')));
  assert.ok(nine.includes('L3 19.15 -0.25'));
  const rimfire = labelTexts('22_win_mag_r_f');
  assert.ok(!rimfire.some((t) => t.startsWith('E1 ')));
});

test('labels never overlap each other or any line or outline, for all 25 records', () => {
  for (const record of Cip.records) {
    const drawing = planDrawing(record, Cip.geometry.build(record));
    assert.ok(drawing, record.key);
    for (const label of drawing.labels) {
      assert.ok(label.rect, `${record.key}: no free position for ${label.text}`);
      assert.ok(!Cip.drawing.hitsObstacles(label.rect, drawing.obstacles), `${record.key}: ${label.text} hits a line`);
    }
    for (let i = 0; i < drawing.labels.length; i++) {
      for (let j = i + 1; j < drawing.labels.length; j++) {
        assert.ok(!Cip.drawing.rectsOverlap(drawing.labels[i].rect, drawing.labels[j].rect), `${record.key}: ${drawing.labels[i].text} / ${drawing.labels[j].text}`);
      }
    }
  }
});

test('the SVG has an accessible name, the title block, and the hatch pattern', () => {
  const svg = toSvg(plan('308_win'), '308 Win.');
  assert.match(svg, /<svg[^>]*role="img"[^>]*aria-label="308 Win\. drawing"/);
  assert.match(svg, /Dimensions in mm/);
  assert.match(svg, /Scale 1:1/);
  assert.match(svg, /C\.I\.P\. table I/);
  assert.match(svg, /Revised 2008-09-23/);
  assert.match(svg, /cip-hatch/);
  assert.match(svg, /stroke-dasharray/);
});

test('names are escaped in the SVG', () => {
  const svg = toSvg(plan('40_s_w'), '40 S.& W.');
  assert.match(svg, /40 S\.&amp; W\. drawing/);
  assert.ok(!/S\.& W/.test(svg));
});
