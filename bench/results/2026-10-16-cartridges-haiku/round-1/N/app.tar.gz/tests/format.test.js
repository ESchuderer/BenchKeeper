const test = require('node:test');
const assert = require('node:assert/strict');
const { load } = require('./load.js');

const Cip = load('format');
const { formatNumber, formatWithTol, formatAngle, symbolFor, unitFor, sectionGroups } = Cip.format;

test('numbers are shown as published, without trailing zeros or separators', () => {
  assert.equal(formatNumber(35.0), '35');
  assert.equal(formatNumber(51.18), '51.18');
  assert.equal(formatNumber(4150), '4150');
  assert.equal(formatNumber(-0.2), '-0.2');
});

test('a tolerance is shown next to its value', () => {
  assert.equal(formatWithTol(39.62, -0.2), '39.62 -0.2');
  assert.equal(formatWithTol(19.15, -0.25), '19.15 -0.25');
  assert.equal(formatWithTol(51.18, undefined), '51.18');
});

test('angles are shown as degrees or degrees, minutes and seconds', () => {
  assert.equal(formatAngle(40), '40°');
  assert.equal(formatAngle(35.0), '35°');
  assert.equal(formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), `1°30'00"`);
  assert.equal(formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), `3°10'36"`);
});

test('symbols are the field name except for the published mapping', () => {
  assert.equal(symbolFor('eMin'), 'e min');
  assert.equal(symbolFor('r1Min'), 'r1 min');
  assert.equal(symbolFor('r1Max'), 'r1 max');
  assert.equal(symbolFor('alpha'), 'α');
  assert.equal(symbolFor('alpha1'), 'α1');
  assert.equal(symbolFor('beta'), 'β');
  assert.equal(symbolFor('delta'), 'δ');
  assert.equal(symbolFor('deltaL'), 'delta L');
  assert.equal(symbolFor('L3PlusG'), 'L3 + G');
  assert.equal(symbolFor('L1'), 'L1');
});

test('units follow the published unit list', () => {
  assert.equal(unitFor('Pmax'), 'bar');
  assert.equal(unitFor('PK'), 'bar');
  assert.equal(unitFor('PE'), 'bar');
  assert.equal(unitFor('EE'), 'J');
  assert.equal(unitFor('M'), 'g');
  assert.equal(unitFor('Q'), 'mm²');
  assert.equal(unitFor('N'), '');
  assert.equal(unitFor('alpha'), '');
  assert.equal(unitFor('G1'), 'mm');
  assert.equal(unitFor('L3PlusG'), 'mm');
});

test('section groups list every value and fold each Tol field into its value', () => {
  const record = Cip.records.find((r) => r.key === '308_win');
  const groups = sectionGroups(record.cartridge);
  const lengths = groups.find((g) => g.title === 'Lengths');
  assert.deepEqual(lengths.rows[0], { symbol: 'L1', value: '39.62 -0.2', unit: 'mm' });
  assert.ok(!lengths.rows.some((row) => row.symbol.endsWith('Tol')));
  const caseHead = groups.find((g) => g.title === 'Case head');
  assert.deepEqual(caseHead.rows.find((row) => row.symbol === 'β'), {
    symbol: 'β',
    value: '35°',
    unit: '',
  });
});

test('angle objects in the record render as degrees, minutes and seconds', () => {
  const record = Cip.records.find((r) => r.key === '308_win');
  const rifling = sectionGroups(record.chamber).find((g) => g.title === 'Rifling');
  const alpha1 = rifling.rows.find((row) => row.symbol === 'α1');
  assert.equal(alpha1.value, `71°25'59"`);
});
