const test = require('node:test');
const assert = require('node:assert/strict');
const { load } = require('./load.js');

const Cip = load('geometry');
const { build, rimTypeOf, fillet } = Cip.geometry;

const byKey = (key) => Cip.records.find((r) => r.key === key);
const near = (actual, expected, eps = 1e-3) => assert.ok(Math.abs(actual - expected) < eps, `${actual} != ${expected}`);
const hasPoint = (path, z, r) => path.some(([pz, pr]) => Math.abs(pz - z) < 1e-6 && Math.abs(pr - r) < 1e-6);

test('rim type follows family, then R1/P1 thresholds', () => {
  assert.equal(rimTypeOf(byKey('300_win_mag')), 'belted');
  assert.equal(rimTypeOf(byKey('22_long_rifle')), 'rimfire');
  assert.equal(rimTypeOf(byKey('9_3_x_74_r')), 'rimmed');
  assert.equal(rimTypeOf(byKey('6_5_creedmoor')), 'rimless');
  const synthetic = (R1, P1) => ({ family: 'rimless', cartridge: { caseHead: { R1 }, powderChamber: { P1 } } });
  assert.equal(rimTypeOf(synthetic(12.6, 12)), 'rimmed');
  assert.equal(rimTypeOf(synthetic(11.5, 12)), 'rebated');
});

test('head chamfer and rim edge: (R1/2 - min(f·tan β, R1/4), 0) to (R1/2, f) to (R1/2, R)', () => {
  const { outline } = build(byKey('308_win'));
  const c = Math.min(0.38 * Math.tan((35 * Math.PI) / 180), 12.01 / 4);
  assert.ok(hasPoint(outline, 0, 12.01 / 2 - c));
  assert.ok(hasPoint(outline, 0.38, 12.01 / 2));
  assert.ok(hasPoint(outline, 1.37, 12.01 / 2));
});

test('extractor groove: floor at E1/2 from R to R+eMin, ramp to (P1/2, E)', () => {
  const { outline } = build(byKey('308_win'));
  assert.ok(hasPoint(outline, 1.37, 10.39 / 2));
  assert.ok(hasPoint(outline, 1.37 + 1.4, 10.39 / 2));
  assert.ok(hasPoint(outline, 3.85, 11.96 / 2));
});

test('belted groove: ramp at angle δ to the axis reaches the belt R3/2, then follows it to E', () => {
  const { outline } = build(byKey('300_win_mag'));
  const rampEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  assert.ok(hasPoint(outline, rampEnd, 13.51 / 2));
  assert.ok(hasPoint(outline, 5.59, 13.51 / 2));
  assert.ok(hasPoint(outline, 5.59, 13.03 / 2));
});

test('rimfire rim edge is a half-round whose outermost point is at R1/2', () => {
  const { outline } = build(byKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.ok(hasPoint(outline, 1.09 / 2, 7.06 / 2));
  near(Math.max(...outline.map(([, r]) => r)), 7.06 / 2, 1e-6);
  assert.ok(rho > 0);
});

test('bottleneck shoulder passes the published corners, which are rounded by r1 min and r2', () => {
  const { outline } = build(byKey('308_win'));
  const distanceTo = (z, r) => Math.min(...outline.map(([pz, pr]) => Math.hypot(pz - z, pr - r)));
  assert.ok(distanceTo(39.62, 11.53 / 2) < 0.3);
  assert.ok(distanceTo(43.48, 8.72 / 2) < 0.3);
  assert.ok(hasPoint(outline, 51.18, 8.72 / 2));
});

test('pointy bullet: seat 1.0·G1, cylinder to zb + 0.40·Lb, ogive radius from the published formula', () => {
  const { bullet } = build(byKey('308_win'));
  const G1 = 7.85;
  const zb = 51.18 - G1;
  const Lb = 71.12 - zb;
  const zc = zb + 0.4 * Lb;
  const m = Math.max(0.08 * G1, 1.27);
  const a = G1 / 2 - m / 2;
  const n = 71.12 - zc;
  const rho = (a * a + n * n) / (2 * a);
  near(bullet.zb, zb);
  near(bullet.zc, zc);
  near(bullet.m, m);
  near(bullet.rho, rho);
  near(bullet.outline.at(-1)[0], 71.12);
  near(bullet.outline.at(-1)[1], 0);
});

test('rounded pistol bullet: seat 0.4·G1, k = 0.65, meplat 0.15·G1', () => {
  const { bullet } = build(byKey('9_mm_luger'));
  near(bullet.s, 0.4 * 9.03);
  near(bullet.zc, 19.15 - 0.4 * 9.03 + 0.65 * (29.69 - (19.15 - 0.4 * 9.03)));
  near(bullet.m, 0.15 * 9.03);
});

test('heeled case (H2 - G1 <= 0.015): exposed bullet has the case outside diameter', () => {
  const model = build(byKey('22_long_rifle'));
  assert.equal(model.bullet.heeled, true);
  near(model.bullet.rExposed, 5.72 / 2);
  near(model.bullet.rSeated, (5.72 - 2 * model.tb) / 2);
});

test('walls: tn = (H2 - G1)/2, tb = min(max(1.3·tn, 0.6), 0.35·P1/2), inner neck at the mouth is G1/2', () => {
  const model = build(byKey('308_win'));
  near(model.tn, (8.72 - 7.85) / 2);
  near(model.tb, 0.6);
  const inner = model.wallPolygon.filter(([z]) => Math.abs(z - 51.18) < 1e-6);
  assert.ok(inner.some(([, r]) => Math.abs(r - 7.85 / 2) < 1e-3));
});

test('solid head to w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb) and primer pocket table', () => {
  const rifle = build(byKey('308_win'));
  near(rifle.w, 4.8);
  near(rifle.pocket.diameter, 5.33);
  near(rifle.pocket.depth, 3.3);
  const pistol = build(byKey('9_mm_luger'));
  near(pistol.pocket.diameter, 4.45);
  near(pistol.pocket.depth, 3.04);
  assert.equal(build(byKey('22_long_rifle')).pocket, null);
});

test('fillet replaces a corner with a tangent arc of radius r', () => {
  const arc = fillet([0, 10], [0, 0], [10, 0], 2);
  near(arc[0][0], 0, 1e-9);
  near(arc[0][1], 2, 1e-9);
  near(arc.at(-1)[0], 2, 1e-9);
  near(arc.at(-1)[1], 0, 1e-9);
  for (const [z, r] of arc) near(Math.hypot(z - 2, r - 2), 2, 1e-6);
});

test('missing values: a groove without eMin is not drawn and eMin is reported', () => {
  const record = JSON.parse(JSON.stringify(byKey('308_win')));
  delete record.cartridge.caseHead.eMin;
  const model = build(record);
  assert.deepEqual(model.missing, [{ feature: 'extractor groove', values: ['eMin'] }]);
  assert.ok(!hasPoint(model.outline, 1.37 + 1.4, 10.39 / 2));
});

test('all 25 records build a finite, monotone outline inside [0, L6]', () => {
  for (const record of Cip.records) {
    const model = build(record);
    assert.equal(model.ok, true, record.key);
    const L6 = record.cartridge.lengths.L6;
    let previousZ = -Infinity;
    for (const [z, r] of model.outline) {
      assert.ok(Number.isFinite(z) && Number.isFinite(r), record.key);
      assert.ok(r >= -1e-9, record.key);
      assert.ok(z >= previousZ - 1e-9 && z <= L6 + 1e-9, `${record.key} z=${z}`);
      previousZ = z;
    }
  }
});
