const test = require('node:test');
const assert = require('node:assert/strict');
const { load } = require('./load.js');

const Cip = load('list');
const { filterCartridges, FAMILIES } = Cip.list;
const all = Cip.records;

test('family options are All and the five published families', () => {
  assert.deepEqual(FAMILIES, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('an empty search and All return every cartridge', () => {
  assert.equal(filterCartridges(all, { query: '', family: 'All' }).length, 25);
  assert.equal(filterCartridges(all, { query: '   ', family: 'All' }).length, 25);
});

test('search matches alternative names, so 7,62 x 51 finds 308 Win.', () => {
  const found = filterCartridges(all, { query: '7,62 x 51', family: 'All' });
  assert.deepEqual(found.map((r) => r.key), ['308_win']);
});

test('search is case-insensitive and ignores extra spaces', () => {
  const found = filterCartridges(all, { query: '  22   lr ', family: 'All' });
  assert.ok(found.some((r) => r.key === '22_long_rifle'));
});

test('family filter counts each published family', () => {
  const count = (family) => filterCartridges(all, { query: '', family }).length;
  assert.equal(count('rimless'), 12);
  assert.equal(count('rimmed'), 2);
  assert.equal(count('belted'), 2);
  assert.equal(count('pistol'), 6);
  assert.equal(count('rimfire'), 3);
});

test('search and family filter combine', () => {
  const found = filterCartridges(all, { query: 'magnum', family: 'rimfire' });
  assert.deepEqual(found.map((r) => r.key), ['22_win_mag_r_f']);
});
