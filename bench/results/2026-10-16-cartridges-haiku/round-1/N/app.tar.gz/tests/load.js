// Loads the classic browser scripts into a shared namespace for node:test.
const path = require('node:path');

// Usage: const Cip = load('format', 'list'); the data file is always loaded first.
function load(...modules) {
  globalThis.Cip = globalThis.Cip || {};
  for (const name of ['data', ...modules]) {
    require(path.join(__dirname, '..', 'js', name + '.js'));
  }
  return globalThis.Cip;
}

module.exports = { load };
