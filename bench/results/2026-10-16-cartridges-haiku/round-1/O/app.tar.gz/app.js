// The start page (list, search, family filter) and the detail view, with hash routing:
// #/ is the list, #/cartridge/<key> a detail view. The pure helpers are testable without a DOM.
var App = (function () {
  var FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  function matches(rec, query) {
    var q = query.trim().toLowerCase();
    if (q === '') return true;
    var names = [rec.name].concat(rec.alternativeNames || []);
    return names.some(function (n) { return n.toLowerCase().indexOf(q) >= 0; });
  }

  function filter(records, query, family) {
    return records.filter(function (rec) {
      return (family === 'All' || rec.family === family) && matches(rec, query);
    });
  }

  function countText(n) {
    return n + ' cartridges';
  }

  // Hash route: { view: 'list' } or { view: 'detail', key }. An unknown key falls back to the list.
  function route(hash, records) {
    var m = /^#\/cartridge\/(.+)$/.exec(hash || '');
    var key = null;
    try { key = m ? decodeURIComponent(m[1]) : null; } catch (e) { key = null; } // a malformed escape is an unknown key
    var known = records.some(function (r) { return r.key === key; });
    return known ? { view: 'detail', key: key } : { view: 'list' };
  }

  function hashFor(key) {
    return '#/cartridge/' + encodeURIComponent(key);
  }

  return { FAMILIES: FAMILIES, matches: matches, filter: filter, countText: countText, route: route, hashFor: hashFor };
})();

if (typeof document !== 'undefined' && document.getElementById('app')) {
  (function () {
    var records = CARTRIDGES;
    var lastView = null;

    function el(tag, props, children) {
      var node = document.createElement(tag);
      Object.keys(props || {}).forEach(function (k) {
        if (k === 'text') node.textContent = props[k];
        else if (k === 'className') node.className = props[k];
        else node.setAttribute(k, props[k]);
      });
      (children || []).forEach(function (c) { node.appendChild(c); });
      return node;
    }

    function renderList() {
      var search = document.getElementById('search');
      var family = document.getElementById('family');
      var rows = document.getElementById('rows');
      var shown = App.filter(records, search.value, family.value);
      rows.textContent = '';
      shown.forEach(function (rec) {
        rows.appendChild(el('tr', {}, [
          el('td', {}, [el('a', { href: App.hashFor(rec.key), text: rec.name })]),
          el('td', { text: rec.family }),
          el('td', { className: 'num', text: Format.formatNumber(rec.cartridge.lengths.L3) })
        ]));
      });
      document.getElementById('count').textContent = App.countText(shown.length);
    }

    function factRow(dl, term, text) {
      dl.appendChild(el('dt', { text: term }));
      dl.appendChild(el('dd', { text: text }));
    }

    function valueTable(title, values) {
      var rows = Format.sectionRows(values).map(function (r) {
        return el('tr', {}, [el('td', { text: r.symbol }), el('td', { className: 'num', text: r.value }), el('td', { text: r.unit })]);
      });
      return el('section', { className: 'values' }, [
        el('h3', { text: title }),
        el('table', { className: 'values-table' }, [
          el('thead', {}, [el('tr', {}, [el('th', { text: 'Symbol' }), el('th', { text: 'Value' }), el('th', { text: 'Unit' })])]),
          el('tbody', {}, rows)
        ])
      ]);
    }

    function renderDetail(rec) {
      var view = document.getElementById('detail');
      view.textContent = '';
      document.title = rec.name + ' · Cartridges';

      view.appendChild(el('h1', { text: rec.name }));
      var facts = el('dl', { className: 'facts' });
      if (rec.alternativeNames && rec.alternativeNames.length) factRow(facts, 'Alternative names', rec.alternativeNames.join(', '));
      factRow(facts, 'Family', rec.family);
      factRow(facts, 'Category', rec.annotations.category);
      factRow(facts, 'Primer type', rec.annotations.primerType);
      factRow(facts, 'C.I.P. table', rec.tab);
      factRow(facts, 'Country', rec.country);
      factRow(facts, 'Published', rec.published);
      factRow(facts, 'Revised', rec.revised);
      factRow(facts, 'Pressure method', rec.pressureMethod);
      var cap = Format.capacity(rec);
      if (cap) {
        var text = cap.value + ' ' + cap.unit + (cap.note ? ' (' + cap.note + ')' : '');
        var dd = el('dd', { text: text + ' · source: ' });
        dd.appendChild(el('a', { href: cap.url, text: cap.source }));
        facts.appendChild(el('dt', { text: 'Water capacity' }));
        facts.appendChild(dd);
      } else {
        factRow(facts, 'Water capacity', 'not published');
      }
      view.appendChild(facts);

      var figure = el('section', { className: 'drawing-block' });
      var holder = el('div', { className: 'drawing-holder' });
      holder.innerHTML = Drawing.svg(Drawing.model(rec), rec.key);
      figure.appendChild(holder);
      view.appendChild(figure);

      [['Cartridge', rec.cartridge], ['Chamber', rec.chamber]].forEach(function (group) {
        view.appendChild(el('h2', { text: group[0] }));
        var cols = el('div', { className: 'cols' });
        Object.keys(group[1]).forEach(function (s) {
          cols.appendChild(valueTable(Format.sectionTitle(s), group[1][s]));
        });
        view.appendChild(cols);
      });
      document.getElementById('print-source').textContent =
        'Source: C.I.P. TDCC, revised ' + rec.revised + ' · ' + rec.name;
    }

    function render() {
      var r = App.route(location.hash, records);
      var listView = document.getElementById('list-view');
      var detailView = document.getElementById('detail-view');
      if (r.view === 'detail') {
        listView.hidden = true;
        detailView.hidden = false;
        renderDetail(records.find(function (x) { return x.key === r.key; }));
        window.scrollTo(0, 0);
      } else {
        // Coming back from a detail view clears the filters, as "All cartridges" promises.
        if (lastView === 'detail') {
          document.getElementById('search').value = '';
          document.getElementById('family').value = 'All';
        }
        listView.hidden = false;
        detailView.hidden = true;
        document.title = 'Cartridges · C.I.P. reference';
        renderList();
      }
      lastView = r.view;
    }

    var family = document.getElementById('family');
    App.FAMILIES.forEach(function (f) { family.appendChild(el('option', { value: f, text: f })); });
    document.getElementById('search').addEventListener('input', renderList);
    family.addEventListener('change', renderList);
    document.getElementById('print').addEventListener('click', function () { window.print(); });
    window.addEventListener('hashchange', render);
    render();
  })();
}
