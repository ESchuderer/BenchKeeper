// The cartridge drawing. model() builds it in SVG user units (1 unit = 1 mm) and
// svg() renders the model. Upper half: outside view (y = -r). Lower half: section (y = +r).
var Drawing = (function () {
  var FONT = 3.0;            // label font size, mm: 2.5 mm printed at the smallest A4 scale
  var CHAR = 0.58;           // average glyph width, in font sizes
  var ARROW_L = 1.6, ARROW_W = 0.5;
  var GAP = 0.5, OVER = 1.0; // extension line gap and overshoot, mm
  var ROW_GAP = 5;           // spacing of length dimension rows, mm
  var COL_GAP = 1.5;         // spacing of diameter label columns, mm

  function unit(v) { var d = Math.hypot(v[0], v[1]); return [v[0] / d, v[1] / d]; }

  function label(text, x, y, anchor) {
    var w = text.length * CHAR * FONT;
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { text: text, x: x, y: y, anchor: anchor, box: { x0: x0, y0: y - 0.75 * FONT, x1: x0 + w, y1: y + 0.25 * FONT } };
  }

  // Arrowhead as a closed triangle: the tip touches the line end, dir points outward from the line.
  function arrow(tip, dir) {
    var n = [-dir[1], dir[0]];
    var bx = tip[0] - dir[0] * ARROW_L, by = tip[1] - dir[1] * ARROW_L;
    return [tip, [bx + n[0] * ARROW_W, by + n[1] * ARROW_W], [bx - n[0] * ARROW_W, by - n[1] * ARROW_W]];
  }

  // A dimension line from a to b with an arrow at each end.
  function dimLine(a, b) {
    var d = unit([b[0] - a[0], b[1] - a[1]]);
    return { lines: [[a, b]], arrows: [arrow(a, [-d[0], -d[1]]), arrow(b, d)] };
  }

  function polySegs(poly) {
    var out = [];
    for (var i = 0; i < poly.length - 1; i++) out.push([poly[i], poly[i + 1]]);
    return out;
  }

  function closedSegs(poly) { return polySegs(poly.concat([poly[0]])); }

  function arrowSegs(arrows) {
    return arrows.reduce(function (acc, a) { return acc.concat(closedSegs(a)); }, []);
  }

  function crosses(p1, p2, p3, p4) {
    function o(a, b, c) { return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]); }
    var d1 = o(p3, p4, p1), d2 = o(p3, p4, p2), d3 = o(p1, p2, p3), d4 = o(p1, p2, p4);
    return d1 * d2 < 0 && d3 * d4 < 0;
  }

  // Does segment a-b touch the box (grown by pad)?
  function segHitsBox(a, b, box, pad) {
    var x0 = box.x0 - pad, x1 = box.x1 + pad, y0 = box.y0 - pad, y1 = box.y1 + pad;
    function inside(p) { return p[0] >= x0 && p[0] <= x1 && p[1] >= y0 && p[1] <= y1; }
    if (inside(a) || inside(b)) return true;
    var edges = [[[x0, y0], [x1, y0]], [[x1, y0], [x1, y1]], [[x1, y1], [x0, y1]], [[x0, y1], [x0, y0]]];
    return edges.some(function (e) { return crosses(a, b, e[0], e[1]); });
  }

  function boxesOverlap(a, b, pad) {
    return a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
  }

  function clear(lab, lines, placed) {
    return lines.every(function (s) { return !segHitsBox(s[0], s[1], lab.box, 0.3); }) &&
      placed.every(function (b) { return !boxesOverlap(lab.box, b, 0.3); });
  }

  // The first candidate label that clears every line and every placed label; the first candidate otherwise.
  function place(candidates, lines, placed) {
    var found = candidates.find(function (lab) { return clear(lab, lines, placed); });
    return found || candidates[0];
  }

  // The clear position nearest to (cx, cy), searched on a grid above and around it.
  function nearest(text, cx, cy, lines, placed) {
    var best = null;
    for (var dy = -1.2; dy >= -22; dy -= 0.6) {
      for (var dx = -24; dx <= 24; dx += 0.6) {
        var d = dx * dx + dy * dy;
        if (best && d >= best.d) continue;
        var lab = label(text, cx + dx, cy + dy, 'middle');
        if (clear(lab, lines, placed)) best = { d: d, lab: lab };
      }
    }
    return best ? best.lab : label(text, cx, cy - 1.2, 'middle');
  }

  // Mirror a [z, r] point to SVG coordinates on a side: -1 upper (outside), +1 lower (section).
  function side(p, s) { return [p[0], s * p[1]]; }

  function model(rec) {
    var P = Profile.build(rec);
    var F = Format;
    var c = rec.cartridge, col = c.collar, L = c.lengths;
    var L3 = L.L3, L6 = L.L6, bullet = P.bullet;
    var Rmax = Math.max.apply(null, P.outer.map(function (p) { return p[1]; }));
    var headTop = P.outer[1][1];

    var upper = P.outside.map(function (p) { return side(p, -1); });
    var sections = [{ points: P.caseSection.map(function (p) { return side(p, 1); }) },
      { points: P.bulletSection.map(function (p) { return side(p, 1); }) }];
    if (P.pocket) sections.push({ points: P.pocket.hole.map(function (p) { return side(p, 1); }), hole: true });
    var centre = [[-2, 0], [L6 + 2, 0]];

    // Pass 1: every dimension line, extension line and arrow, with its label candidates.
    var specs = [];
    function spec(key, dl, ext, cands) {
      specs.push({ key: key, dl: dl, ext: ext, cands: cands });
    }

    // Length dimensions in rows above the drawing. Longer spans sit lower, so no
    // extension line crosses a dimension line of a longer span.
    // Shortest span nearest the outline: an extension line from a feature crosses only longer rows above it.
    var rows = [];
    if (P.shoulder) rows.push(['L1', L.L1, P.anchors.L1], ['L2', L.L2, P.anchors.L2]);
    rows.push(['L3', L3, P.anchors.L3], ['L6', L6, P.anchors.L6]);
    rows.forEach(function (row, k) {
      var key = row[0], span = row[1], feat = row[2];
      var y = -(Rmax + 4.5 + ROW_GAP * k);
      var text = F.symbol(key) + ' ' + F.formatValue(key, L[key]);
      spec(key, dimLine([0, y], [span, y]),
        [[[0, -headTop - GAP], [0, y - OVER]], [[feat[0], -feat[1] - GAP], [feat[0], y - OVER]]],
        [label(text, span * 0.5, y - 1.6, 'middle'), label(text, span * 0.25, y - 1.6, 'middle'),
          label(text, span * 0.75, y - 1.6, 'middle'), label(text, span + 1.2, y + 0.9, 'start')]);
    });

    // Rim thickness R below the drawing.
    var yR = Rmax + 4.5, rimFeat = P.anchors.R;
    spec('R', dimLine([0, yR], [rimFeat[0], yR]),
      [[[0, Math.abs(headTop) + GAP], [0, yR + OVER]], [[rimFeat[0], rimFeat[1] + GAP], [rimFeat[0], yR + OVER]]],
      [label('R ' + F.formatValue('R', c.caseHead.R), rimFeat[0] + 1.2, yR + 0.9, 'start')]);

    // Shoulder angle: an arc at the apex from the axis to the shoulder line.
    var alpha = null;
    if (P.alpha) {
      var A = P.alpha.apex, from = P.alpha.from;
      var ra = Math.min(8, 0.5 * Math.hypot(from[0] - A[0], from[1] - A[1]));
      var phi = Math.atan2(from[1], A[0] - from[0]);
      var arc = [];
      for (var j = 0; j <= 12; j++) {
        var t = Math.PI + phi * j / 12;
        arc.push([A[0] + ra * Math.cos(t), ra * Math.sin(t)]);
      }
      var d0 = unit([arc[1][0] - arc[0][0], arc[1][1] - arc[0][1]]);
      var d1 = unit([arc[arc.length - 2][0] - arc[arc.length - 1][0], arc[arc.length - 2][1] - arc[arc.length - 1][1]]);
      var aText = 'α ' + F.formatValue('alpha', c.junctionCone.alpha);
      var mz = (from[0] + A[0]) / 2, mr = from[1] / 2;
      alpha = { apex: A, arc: arc, arrows: [arrow(arc[0], [-d0[0], -d0[1]]), arrow(arc[arc.length - 1], d1)] };
      var bis = phi / 2 + Math.PI;
      spec('alpha', { lines: [], arrows: alpha.arrows }, [], null);
      specs[specs.length - 1].text = aText;
      specs[specs.length - 1].at = [A[0] + 0.5 * ra * Math.cos(bis), 0.5 * ra * Math.sin(bis)];
    }

    // Diameters in columns right of the bullet, in ascending size: an extension line only
    // passes columns of smaller diameter, so it never crosses a larger dimension line.
    var diam = [
      { key: 'R1', feat: P.anchors.R1, D: c.caseHead.R1, value: c.caseHead.R1 },
      { key: 'P1', feat: P.anchors.P1, D: c.powderChamber.P1, value: c.powderChamber.P1 }
    ];
    if (P.shoulder) {
      diam.push({ key: 'P2', feat: P.anchors.P2, D: c.powderChamber.P2, value: c.powderChamber.P2 });
      diam.push({ key: 'H1', feat: P.anchors.H1, D: col.H1, value: col.H1 });
    }
    diam.push({ key: 'H2', feat: P.anchors.H2, D: col.H2, value: col.H2 });
    diam.push({ key: 'G1', feat: P.anchors.G1, D: bullet.Dx, value: c.projectile.G1 });
    if (P.anchors.E1) diam.push({ key: 'E1', feat: P.anchors.E1, D: c.caseHead.E1, value: c.caseHead.E1 });
    diam.sort(function (a, b) { return a.D - b.D; });
    // Columns start beyond the shoulder apex, which can lie past the bullet tip on flat shoulders.
    var x = Math.max(L6 + 6, alpha ? alpha.apex[0] + 2 : 0);
    diam.forEach(function (d) {
      var r = d.D / 2;
      var text = F.symbol(d.key) + ' ' + F.formatValue(d.key, d.value);
      var ext = [-1, 1].map(function (s) {
        var y = s * d.feat[1];
        return [[d.feat[0] + GAP, y], [x + OVER, y]];
      });
      spec(d.key, dimLine([x, -r], [x, r]), ext, [label(text, x + 1.2, 1.0, 'start')]);
      x = label(text, x + 1.2, 1.0, 'start').box.x1 + COL_GAP;
    });
    var xMax = Math.max(L6, x);

    // Every line of the drawing is an obstacle for every label.
    var lines = polySegs(upper).concat([centre]);
    sections.forEach(function (s) { lines = lines.concat(closedSegs(s.points)); });
    specs.forEach(function (s) {
      lines = lines.concat(s.dl.lines, s.ext, arrowSegs(s.dl.arrows));
    });
    if (alpha) lines = lines.concat(polySegs(alpha.arc));

    // Pass 2: place each label where it clears every line and every label already placed.
    var placed = [], dims = [];
    specs.forEach(function (s) {
      var lab = s.cands ? place(s.cands, lines, placed) : nearest(s.text, s.at[0], s.at[1], lines, placed);
      placed.push(lab.box);
      if (s.key === 'alpha') { alpha.label = lab; return; }
      dims.push({ key: s.key, lines: s.dl.lines.concat(s.ext), arrows: s.dl.arrows, label: lab });
    });

    // Title block below the drawing: name, C.I.P. table, revision, units, scale, and what was not drawn.
    var titleTop = yR + 9;
    var titleLines = [
      { text: rec.name, size: 3.6, bold: true },
      { text: 'C.I.P. table ' + rec.tab + ' · Revised ' + rec.revised, size: FONT },
      { text: 'Dimensions in mm · Scale 1:1', size: FONT }
    ].concat(P.missing.map(function (n) { return { text: n, size: FONT }; }));
    var titleH = 3.6 + 2 + (titleLines.length - 1) * (FONT + 1.2) + 2;
    var bottom = titleTop + titleH + 2;
    var top = -(Rmax + 4.5 + ROW_GAP * (rows.length - 1)) - 6;

    return {
      key: rec.key, name: rec.name,
      viewBox: { x: -2, y: top, w: xMax + 4, h: bottom - top },
      upper: upper, sections: sections, centre: centre,
      dims: dims, alpha: alpha, lines: lines,
      labels: dims.map(function (d) { return d.label; }).concat(alpha ? [alpha.label] : []),
      notes: P.missing,
      title: { top: titleTop, height: titleH, x0: -2, x1: xMax + 2, lines: titleLines }
    };
  }

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function path(list, close) {
    return 'M ' + list.map(function (p) { return p[0].toFixed(3) + ' ' + p[1].toFixed(3); }).join(' L') + (close ? ' Z' : '');
  }

  function labelSvg(l) {
    return '<text class="label" x="' + l.x.toFixed(3) + '" y="' + l.y.toFixed(3) + '" font-size="' + FONT +
      '" text-anchor="' + l.anchor + '">' + esc(l.text) + '</text>';
  }

  function svg(m, id) {
    var vb = m.viewBox, out = [];
    out.push('<svg class="drawing" xmlns="http://www.w3.org/2000/svg" width="' + vb.w.toFixed(1) + 'mm" viewBox="' + vb.x + ' ' + vb.y + ' ' + vb.w + ' ' + vb.h +
      '" role="img" aria-label="' + esc(m.name) + ' drawing">');
    out.push('<defs><pattern id="hatch-' + id + '" patternUnits="userSpaceOnUse" width="1.2" height="1.2" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="1.2" stroke="currentColor" stroke-width="0.12"/></pattern></defs>');
    out.push('<path class="centre" d="' + path(m.centre) + '"/>');
    m.sections.forEach(function (s) {
      var fill = s.hole ? '' : ' fill="url(#hatch-' + id + ')"';
      out.push('<path class="section' + (s.hole ? ' hole' : '') + '"' + fill + ' d="' + path(s.points, true) + '"/>');
      if (!s.hole) out.push('<path class="outline" d="' + path(s.points, true) + '"/>');
    });
    out.push('<path class="outline" d="' + path(m.upper) + '"/>');
    m.dims.forEach(function (d) {
      d.lines.forEach(function (l) { out.push('<path class="dim" d="' + path(l) + '"/>'); });
      d.arrows.forEach(function (a) { out.push('<path class="dim fill" d="' + path(a, true) + '"/>'); });
      out.push(labelSvg(d.label));
    });
    if (m.alpha) {
      out.push('<path class="dim" d="' + path(m.alpha.arc) + '"/>');
      m.alpha.arrows.forEach(function (a) { out.push('<path class="dim fill" d="' + path(a, true) + '"/>'); });
      out.push(labelSvg(m.alpha.label));
    }
    var t = m.title, y = t.top + 3.6 + 1.0;
    out.push('<rect class="title" x="' + t.x0 + '" y="' + t.top + '" width="' + (t.x1 - t.x0) + '" height="' + t.height + '"/>');
    t.lines.forEach(function (ln, i) {
      out.push('<text x="' + (t.x0 + 1.5) + '" y="' + y.toFixed(2) + '" font-size="' + ln.size + '"' +
        (ln.bold ? ' font-weight="600"' : '') + '>' + esc(ln.text) + '</text>');
      y += i === 0 ? 2 + ln.size : ln.size + 1.2;
    });
    out.push('</svg>');
    return out.join('');
  }

  return { model: model, svg: svg, label: label, place: place, segHitsBox: segHitsBox, boxesOverlap: boxesOverlap };
})();
