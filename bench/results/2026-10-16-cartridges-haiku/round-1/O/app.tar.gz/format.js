// How published values are written: symbol, number, unit and tolerance.
var Format = (function () {
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²' };
  var NO_UNIT = ['N'];
  var SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Misc', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
  };

  function symbol(field) {
    return SYMBOLS[field] || field;
  }

  function unit(field) {
    if (ANGLES.indexOf(field) >= 0 || NO_UNIT.indexOf(field) >= 0) return '';
    return UNITS[field] || 'mm';
  }

  // Published numbers print as JavaScript writes them: 4150, 51.18, 35.
  function formatNumber(n) {
    return String(n);
  }

  function pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function formatAngle(a) {
    if (typeof a === 'number') return formatNumber(a) + '°';
    return a.degrees + '°' + pad2(a.minutes) + '\'' + pad2(a.seconds) + '"';
  }

  function formatValue(field, v) {
    return ANGLES.indexOf(field) >= 0 ? formatAngle(v) : formatNumber(v);
  }

  // One row per field. A <X>Tol field joins the row of X and is not a row itself.
  function sectionRows(values) {
    var rows = [];
    Object.keys(values).forEach(function (field) {
      if (/Tol$/.test(field) && values[field.slice(0, -3)] !== undefined) return;
      var text = formatValue(field, values[field]);
      var tol = values[field + 'Tol'];
      if (tol !== undefined) text += ' ' + formatNumber(tol);
      rows.push({ symbol: symbol(field), value: text, unit: unit(field) });
    });
    return rows;
  }

  // The published water capacity, or null when the record has none.
  function capacity(record) {
    var pc = record.annotations && record.annotations.publishedCapacity;
    if (!pc) return null;
    return {
      value: formatNumber(pc.grH2O), unit: 'gr H2O',
      note: pc.note || '', source: pc.source, url: pc.url
    };
  }

  function sectionTitle(section) {
    return SECTION_TITLES[section] || section;
  }

  return {
    symbol: symbol, unit: unit, formatNumber: formatNumber, formatAngle: formatAngle,
    formatValue: formatValue, sectionRows: sectionRows, capacity: capacity, sectionTitle: sectionTitle
  };
})();
