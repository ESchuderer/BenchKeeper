# Design

## Context

The app is plain HTML, CSS and JavaScript. It must work from `file://` in Chromium, so it cannot use `fetch`, ES modules or any network resource. Scripts are classic scripts loaded in order, each declaring one global. The only data is the 25 records in `data.js`.

## Files

- `index.html`: the page shell (header, list view, detail view, print footer). Loads `data.js`, `format.js`, `profile.js`, `drawing.js`, `app.js` in that order, and `styles.css`.
- `data.js`: `var CARTRIDGES = [...]`, the 25 records as given.
- `format.js`: `var Format`: value formatting, symbols, units, angles, tolerance pairing, field tables per section. Pure.
- `profile.js`: `var Profile`: rim type, outer profile, bullet, section walls, primer pocket, missing-value notes. Pure, in (z, r) mm.
- `drawing.js`: `var Drawing`: dimension and label layout, and the SVG markup. Pure; returns a model that tests can inspect.
- `app.js`: `var App` for the pure helpers (filter, route parsing), plus DOM rendering that runs only when `document` has the app root.
- `styles.css`: screen (light and dark via `prefers-color-scheme`), print (black on white, A4 portrait).
- `test/*.test.js`: Node 22 `node:test`, no npm dependencies. A small loader runs the browser scripts in a `vm` context so the app files stay unchanged.

## Decisions

- **Coordinates.** Geometry is computed as `[z, r]` pairs in mm: z along the axis from the head face, r the radius. The SVG maps `x = z` and `y = -r` for the upper outside half and `y = +r` for the lower section half. The spec's `(r, z)` notation is converted once, in `profile.js`.
- **Curves as polylines.** Fillets, the tangent ogive and the elliptical nose are sampled to short segments (about 1 mm apart, at least 8 per arc). This keeps the SVG and the tests simple and is smooth at print scale.
- **Routing.** Hash routes: `#/` for the list and `#/cartridge/<key>` for a detail view. Hash routes work from `file://`, reload and bookmark.
- **Values in tables.** Each table row is one field. A `<X>Tol` field is merged into the row of X and is never its own row. Tables come from the record's `cartridge` and `chamber` sections in data order.
- **Number format.** `String(n)` in JavaScript gives the published form without trailing zeros (4150, 35, 5.7). Angles are integers or `d°m'ss"`.
- **Water capacity unit.** The field is `grH2O`; it is shown as "gr H2O". The brief names no unit for it; this is read from the field name.
- **Labels.** Length dimensions (L6, L3, L2, L1) sit in rows above the drawing, ordered so that extension lines never cross a dimension line of a longer span. R sits in a row below the drawing for the same reason. Diameter dimensions sit in columns to the right of the bullet, ordered by ascending diameter, so an extension line never crosses a larger dimension. The columns start beyond the shoulder apex, which can lie past the bullet tip on flat shoulders. Labelling runs in two passes: every dimension line is built first, then each label takes the first candidate position that clears every line and every placed label. The α label uses a nearest-clear grid search around its arc, because the length extension lines and the body outline can leave no fixed candidate clear. Every label is checked against every other label and every line in tests.
- **Straight cases.** Without a shoulder the inner wall blends linearly from tn at the mouth to tb at the body start, so the bullet seats in the mouth without overlapping the wall.
- **Heeled cases.** For H2 - G1 <= 0.015 the exposed bullet has diameter H2 and the seated heel has diameter H2 - 2·tb. With tn = 0 the neck wall is zero-thickness, as the rules give it; the drawing follows the rules.
- **Section hatch.** An SVG `<pattern>` with a unique id per drawing. Case walls, the solid head and the cut bullet are hatched. The primer pocket is a hole in the head polygon (`fill-rule="evenodd"`).
- **Print.** `@media print` hides navigation, search and buttons, forces black on white, sets the page to A4 portrait and makes the drawing full width. The value tables run in four columns and the facts in two pairs per row, so every detail view fits one page (checked for all 25 records). A static print-only footer shows "Source: C.I.P. TDCC, revised <date>".

## Risks

- Label collisions on the drawing are the hardest part to get right by eye. The overlap check runs on all 25 records in tests, so it does not depend on looking at the screen.
- The drawing rules are followed as written. Where they give an odd result, such as the zero-thickness neck of heeled cases, the drawing follows the rule and the design does not invent a value.
- No browser is installed in the container. Browser checks use a headless browser if one can be installed; otherwise the verification is the Node test suite plus a static check of the HTML and CSS.
