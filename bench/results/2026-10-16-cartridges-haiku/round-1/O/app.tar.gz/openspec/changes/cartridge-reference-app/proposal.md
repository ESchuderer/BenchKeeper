# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick, offline reference for C.I.P. cartridge dimensions, pressures and chamber data. The 25 published records must be browsable, searchable, and viewable as a technical drawing that can be printed on one A4 page. The app is modelled on the OpenBallistics cartridge database, but is a static site with no server, no build step and no network requests.

## What Changes

- Add a single-page static app in `index.html` with its own CSS and JavaScript files. It works when opened directly from disk (`file://`) in Chromium and when served by any static file server.
- Add the 25 cartridge records, as published, as the only data source.
- Start page lists every cartridge (name, family, case length L3). The name links to its detail view. A search field and a family select filter the list; a count shows how many are listed.
- Detail view per cartridge, with its own bookmarkable address: header facts, a computed 2D drawing, and tables of all cartridge and chamber values. A Print button and a link back to the list.
- Print produces one A4 portrait page, black on white, with no navigation or controls.
- Light and dark colour schemes follow the system setting on screen; print is always light.
- **BREAKING**: none. This is a new project; there is no previous behaviour to break.

## Capabilities

### New Capabilities

- `cartridge-catalogue`: the start page list, search by name and alternative names, family filter, result count, and links to detail views.
- `cartridge-detail`: the detail view layout, bookmarkable addresses, value tables grouped by section, the Print action, and the printed page.
- `cartridge-drawing`: the computed inline SVG cartridge drawing (outside view, section, dimension lines, title block) and its geometry rules.
- `cartridge-presentation`: how published values are formatted: units, symbols, tolerances next to values, angles, and names.

### Modified Capabilities

None. `openspec/specs/` is empty.

## Impact

- New files: `index.html`, `styles.css`, `data.js` (the 25 records), `geometry.js` (pure computation: rim type, profile, dimension values, formatting), `app.js` (rendering, routing, search and filter), and tests under `test/`.
- No runtime dependencies, no network access, no build step. Node.js 22's built-in test runner is used for tests; it needs no npm dependencies.
- Browser verification needs a headless Chromium; it is a development tool and is not part of the app.
