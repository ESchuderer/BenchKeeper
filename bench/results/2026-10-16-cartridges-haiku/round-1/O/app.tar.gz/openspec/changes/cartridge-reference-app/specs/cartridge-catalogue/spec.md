# Spec Delta

## Purpose

Lets a technical user find any of the 25 published cartridges by name, alternative name or family, and open its detail view from the start page.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL have the heading "Cartridges" and SHALL list every cartridge record once, showing its name, family and case length L3.

#### Scenario: Full list on first load
- **WHEN** the app is opened without a search or family filter
- **THEN** all 25 cartridges are listed, each with its name, family and L3 value

### Requirement: Each name links to its detail view
Each cartridge name on the start page SHALL be a link whose text is exactly the record's `name`, and which opens that cartridge's detail view.

#### Scenario: Open a detail view from the list
- **WHEN** the user activates the link "308 Win."
- **THEN** the detail view of the cartridge with name "308 Win." is shown

### Requirement: Search filters by name and alternative names
The start page SHALL have a text field labelled "Search" that filters the list as the user types, matching against each cartridge's `name` and `alternativeNames`, ignoring letter case and surrounding whitespace.

#### Scenario: Alternative name finds the cartridge
- **WHEN** the user types "7,62 x 51" into Search
- **THEN** the list shows "308 Win." and no cartridge whose names do not contain "7,62 x 51"

#### Scenario: Empty search shows all
- **WHEN** the Search field is empty
- **THEN** the search places no restriction on the list

### Requirement: Family select filters by family
The start page SHALL have a select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire. Choosing an option other than All SHALL list only cartridges of that family.

#### Scenario: Filter to rimfire
- **WHEN** the user selects "rimfire"
- **THEN** only cartridges whose family is "rimfire" are listed

#### Scenario: Search and family combine
- **WHEN** the user selects "rimless" and types "Win" into Search
- **THEN** only rimless cartridges whose names or alternative names contain "Win" are listed

### Requirement: Result count
The start page SHALL show the text "<n> cartridges" where <n> is the number of cartridges currently listed.

#### Scenario: Count follows the filters
- **WHEN** the filters leave 3 cartridges listed
- **THEN** the count text reads "3 cartridges"

#### Scenario: Count of one uses the same form
- **WHEN** the filters leave 1 cartridge listed
- **THEN** the count text is still in the form "<n> cartridges", reading "1 cartridges"
