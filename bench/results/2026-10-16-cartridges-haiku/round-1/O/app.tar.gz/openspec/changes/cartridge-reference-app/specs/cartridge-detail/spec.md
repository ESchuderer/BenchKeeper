# Spec Delta

## Purpose

Shows everything the published record says about one cartridge on one bookmarkable page, and prints that page as a single A4 reference sheet.

## ADDED Requirements

### Requirement: Detail view has its own address
Each cartridge SHALL have a detail view at an address that identifies that cartridge, that displays the same view when reloaded, and that can be bookmarked. The app SHALL work when `index.html` is opened from disk without a web server.

#### Scenario: Reload keeps the view
- **WHEN** the user opens the detail view of "223 Rem." and reloads the page
- **THEN** the detail view of "223 Rem." is shown again

#### Scenario: Unknown address
- **WHEN** the address names no cartridge in the data
- **THEN** the app shows the start page instead

### Requirement: Detail view header
The detail view SHALL show, in this order: the cartridge's `name` as the heading; its `alternativeNames`, if any; `family`; `category`; the primer type (`primerType`); the C.I.P. table (`tab`); `country`; the `published` and `revised` dates; the `pressureMethod`; and the published water capacity (`publishedCapacity`) with its value, unit, note if any, and a link to its source URL. When a field is absent from the record, its row SHALL say "not published".

#### Scenario: Water capacity with a source link
- **WHEN** the detail view of "308 Win." is shown
- **THEN** it shows the water capacity "56" with its note "Lapua brass measures 55.8 (lapua-308)" and a link to the source URL "http://kwk.us/cases.html"

#### Scenario: Missing water capacity
- **WHEN** the record has no `publishedCapacity`
- **THEN** the water capacity row reads "not published" and contains no link

### Requirement: Detail view shows the drawing
The detail view SHALL show the cartridge drawing defined in the cartridge-drawing capability between the header and the value tables.

#### Scenario: Drawing position
- **WHEN** the detail view is shown
- **THEN** the drawing appears below the header and above the first value table

### Requirement: Value tables grouped by section
The detail view SHALL show every value of the record's `cartridge` and `chamber` objects in tables, one table per section (for example "Case head", "Collar", "Lengths", "Pressures", "Rifling"), each with the columns "Symbol", "Value" and "Unit". Every table row SHALL be a value of the record; tolerance fields SHALL appear next to their value and not as rows.

#### Scenario: Tolerance beside its value
- **WHEN** the `lengths` section of the cartridge "308 Win." is shown
- **THEN** the row for L1 reads "39.62 -0.2" with unit "mm", and no row shows L1Tol

#### Scenario: Chamber values are included
- **WHEN** the `chamber` section "Breech" of "223 Rem." is shown
- **THEN** a table lists its R1 value with unit "mm"

### Requirement: Navigation back to the list
The detail view SHALL have a link "All cartridges" that opens the start page.

#### Scenario: Back to list
- **WHEN** the user activates "All cartridges"
- **THEN** the start page is shown with the search and family filter cleared

### Requirement: Print button prints the detail view
The detail view SHALL have a "Print" button that opens the browser's print dialog.

#### Scenario: Print opens the dialog
- **WHEN** the user activates "Print"
- **THEN** the browser print dialog opens for the detail view

### Requirement: Printed page layout
When printed, the detail view SHALL be one A4 portrait page in black on white, with a page header showing the name, the drawing at full width with every label legible, then the value tables, and a footer naming the source "C.I.P. TDCC" and the `revised` date. Navigation, the search and filter fields, and buttons SHALL NOT appear on the printed page.

#### Scenario: Print output
- **WHEN** the detail view of any cartridge is printed
- **THEN** the output is a single A4 portrait page with no navigation, controls or buttons, and its footer reads "Source: C.I.P. TDCC, revised <date>"
