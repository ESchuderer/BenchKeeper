# Spec Delta

## Purpose

Draws each cartridge as a true-to-scale 2D technical drawing from its published values, so that a reloader or gunsmith can read the case, chamber and bullet geometry and print it.

## ADDED Requirements

### Requirement: Drawing is a true-scale inline SVG
The detail view SHALL show the drawing as one inline SVG element with the accessible name "<name> drawing", where 1 SVG user unit equals 1 mm, the axis is horizontal, and the case head is on the left. The SVG SHALL be no wider than its container. When printed it SHALL keep its mm scale, and it SHALL be scaled down uniformly only when it is wider than the printable width.

#### Scenario: Accessible name
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the drawing SVG has the accessible name "308 Win. drawing"

#### Scenario: Head on the left
- **WHEN** any cartridge is drawn
- **THEN** the head face (z = 0) is the leftmost part of the drawing and the mouth and bullet tip are to the right

### Requirement: Upper half outside view, lower half section
The drawing SHALL show the outside view of the cartridge in the upper half, and a section in the lower half in which the cut case walls, the solid head and the cut bullet are hatched. A dash-dot centre line SHALL lie on the axis. In the outside view the seated part of the bullet SHALL NOT be drawn; in the section it SHALL be drawn inside the case.

#### Scenario: Seated bullet is hidden outside
- **WHEN** the outside view of "223 Rem." is drawn
- **THEN** no bullet outline is drawn between the mouth L3 and the bullet base, and the bullet outline is drawn from the mouth to the tip L6

#### Scenario: Section shows the seated bullet
- **WHEN** the section of "223 Rem." is drawn
- **THEN** the seated bullet is drawn as a hatched cut inside the case neck

### Requirement: Rim type from family and R1/P1
The rim type SHALL be taken from the family and the ratio R1/P1: family belted is belted; family rimfire is rimfire; otherwise a ratio of 1.05 or more is rimmed, a ratio below 0.98 is rebated, and anything else is rimless.

#### Scenario: Rimmed case
- **WHEN** the record for "9,3 x 74 R" is drawn
- **THEN** its rim is drawn as rimmed, because R1/P1 is 1.12

#### Scenario: Belted case
- **WHEN** the record for "300 Win. Mag." is drawn
- **THEN** its extractor groove follows the belt rule, with the ramp at angle δ up to the belt diameter R3

### Requirement: Outside outline from the published values
The outside outline SHALL run from the head face at z = 0, through the rim or belt, the extractor groove where E and E1 are published, and the body, to the shoulder through the published points (P2 at L1 to H1 at L2) and the neck from H1 at L2 to H2 at L3, then the mouth face and the exposed bullet. A case without alpha, L1 or L2 SHALL be drawn straight, with the body running to H2 at L3.

#### Scenario: Rimfire rim edge
- **WHEN** the record for "22 Long Rifle" is drawn
- **THEN** its rim edge is a half-round of radius min(R/2, (R1 - P1)/2) whose outermost point lies at R1/2

#### Scenario: Straight case
- **WHEN** the record for "9 mm Luger" is drawn, which has no L1 or L2
- **THEN** the body runs straight from the groove to H2 at L3 with no shoulder

### Requirement: Shoulder and neck fillets
The body-side corner of the shoulder SHALL be rounded with r1 min, and the neck-side corner with r2, where those values are published. A fillet SHALL be drawn tangent to both adjoining lines.

#### Scenario: Fillets drawn
- **WHEN** the record for "223 Rem." is drawn
- **THEN** the body-side shoulder corner is rounded with radius 0.64 and the neck-side corner with radius 2.54

### Requirement: Bullet seating depth
The bullet SHALL be seated at depth s below the mouth, where s is 1.0·G1 for a pointy bullet; 0.8·G1 for a rounded or flat rifle or rimfire bullet; 0.4·G1 for a rounded or flat pistol bullet; and 0.6·G1 for a semi-wadcutter. Its base SHALL be at L3 - s.

#### Scenario: Semi-wadcutter pistol bullet
- **WHEN** the record for "357 Magnum" is drawn
- **THEN** the seating depth is 0.6·G1 and the base is at L3 - 0.6·G1

### Requirement: Bullet cylinder length
The cylinder SHALL run from the base to the base plus k times the bullet length Lb = L6 - base, where k is 0.40 pointy, 0.55 rounded rifle or rimfire, 0.65 rounded pistol, 0.60 flat rifle, 0.70 flat pistol and 0.78 semi-wadcutter.

#### Scenario: Semi-wadcutter cylinder
- **WHEN** the record for "357 Magnum" is drawn
- **THEN** the cylinder ends at the base plus 0.78 of the bullet length

#### Scenario: Heeled rimfire bullet
- **WHEN** the record for "22 Long Rifle" is drawn
- **THEN** the exposed bullet has the outside diameter H2 and the seated heel has the inside diameter H2 - 2·tb

### Requirement: Heeled cartridge bullet
When H2 - G1 is at most 0.015 mm the cartridge is heeled: the exposed bullet SHALL have the case outside diameter H2, and the seated heel SHALL have the case inside diameter H2 - 2·tb.

#### Scenario: Heeled rimfire bullet
- **WHEN** the record for "22 Long Rifle" is drawn
- **THEN** the exposed bullet has the outside diameter H2 and the seated heel has the inside diameter H2 - 2·tb

#### Scenario: Non-heeled bullet
- **WHEN** the record for "308 Win." is drawn
- **THEN** the seated part has the bullet diameter G1 and no heel step is drawn

### Requirement: Bullet nose
The nose SHALL take the shape given by `annotations.defaultBulletShape`. A pointy nose SHALL be a tangent ogive with meplat diameter max(0.08·G1, 1.27), whose radius is ρ = ((G1/2 - m/2)² + n²) / (2·(G1/2 - m/2)) for nose length n. A rounded nose SHALL be a quarter ellipse with meplat 0.15·G1. A flat nose SHALL be a straight cone with meplat 0.55·G1, and a semi-wadcutter nose a straight cone with meplat 0.6·G1.

#### Scenario: Pointy rifle bullet
- **WHEN** the record for "308 Win." is drawn
- **THEN** the nose is a tangent ogive with meplat diameter 1.27, because 0.08·G1 (0.63) is the smaller of the two

#### Scenario: Semi-wadcutter nose
- **WHEN** the record for "357 Magnum" is drawn
- **THEN** the straight nose ends in a meplat of 0.6·G1

### Requirement: Wall thickness and solid head
The section SHALL use the neck wall tn = (H2 - G1)/2 and the body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner line SHALL follow the outer body at tb, the neck at tn, and blend linearly across the shoulder. The solid head SHALL extend from the head face to z = w, where w is the largest of 2.5, 0.25·P1/2, the primer pocket depth plus 1.5, E + tb where a groove exists, and the belt ramp end plus tb on belted cases.

#### Scenario: Wall thicknesses
- **WHEN** the record for "223 Rem." is drawn
- **THEN** the neck wall is (6.43 - 5.7)/2 and the body wall is the larger of 1.3 times the neck wall and 0.6, capped at 0.35·P1/2

#### Scenario: Primer pocket on centrefire cases
- **WHEN** a centrefire case with primer type "lr" is drawn
- **THEN** the primer pocket is a void of diameter 5.33 and depth 3.3 at the centre of the head face

#### Scenario: Rimfire has no pocket
- **WHEN** a rimfire case is drawn
- **THEN** no primer pocket is drawn

### Requirement: Dimension lines and labels
The drawing SHALL show a dimension line with arrowheads and extension lines for L3, L6, R1, R and P1, and for each of P2, H1, H2, G1, L1, L2 and E1 that is published, and for the shoulder angle α when it is published. Each dimension SHALL be labelled with its symbol and value, for example "L3 51.18". No label SHALL overlap another label or any outline or dimension line of the drawing.

#### Scenario: Published dimensions appear
- **WHEN** the record for "308 Win." is drawn
- **THEN** the drawing shows dimensions labelled L3 51.18, L6 71.12, R1 12.01, R 1.37, P1 11.96, P2 11.53, H1 8.72, H2 8.72, G1 7.85, L1 39.62, L2 43.48, E1 10.39 and α 40°

#### Scenario: Unpublished dimension is omitted
- **WHEN** the record has no `collar.H1` value
- **THEN** no H1 dimension is drawn

#### Scenario: Labels stay clear
- **WHEN** any of the 25 cartridges is drawn
- **THEN** no two labels overlap, and no label overlaps the outline

### Requirement: Missing values are reported, never invented
If a value that a drawing rule needs is missing, the drawing SHALL omit the feature that needs it and SHALL state which value is missing in a note on the drawing. The drawing SHALL NOT substitute a number for a missing value.

#### Scenario: Missing shoulder fillet
- **WHEN** the record for "17 HMR" is drawn, which has no `junctionCone.r1Min`
- **THEN** both shoulder corners are drawn sharp and the note reads "not drawn: r1 min, r2 (not published)"

#### Scenario: Missing extractor groove
- **WHEN** the record for "22 Long Rifle" is drawn, which has no E or E1 value
- **THEN** no extractor groove is drawn and the case steps in from the rim to the body

### Requirement: Title block
The drawing SHALL include a title block showing the cartridge's name, its C.I.P. table (`tab`), its revision date (`revised`), the text "Dimensions in mm", and the scale.

#### Scenario: Title block content
- **WHEN** "9 mm Luger" is drawn
- **THEN** the title block shows "9 mm Luger", "C.I.P. table IV", "Revised 2008-09-23", "Dimensions in mm" and the scale

### Requirement: Legible when scaled and printed
The drawing SHALL remain legible when it is scaled to a phone screen width and when printed on A4 at its mm scale: each label SHALL have a printed height of at least 2.5 mm.

#### Scenario: Printed label height
- **WHEN** the detail view is printed
- **THEN** every label text is at least 2.5 mm high on the page
