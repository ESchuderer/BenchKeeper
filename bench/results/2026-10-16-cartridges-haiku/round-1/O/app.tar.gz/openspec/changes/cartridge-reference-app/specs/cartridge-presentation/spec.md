# Spec Delta

## Purpose

Defines how published cartridge values are shown: the symbol, the number, the unit and the tolerance of each value, so that every figure reads exactly as it is published.

## ADDED Requirements

### Requirement: Values are shown as published
Numbers SHALL be shown with a decimal point and without a thousands separator, with no trailing zeros (for example 4150 bar, 51.18 mm, 35 degrees). Names SHALL be shown exactly as published, including comma decimals such as "6,5 Creedmoor".

#### Scenario: Pressure without separator
- **WHEN** the pressure Pmax of "7 x 64" is shown (published as 4150.0)
- **THEN** it reads "4150" with unit "bar"

#### Scenario: Comma name
- **WHEN** the name of the record "6_5_creedmoor" is shown
- **THEN** it reads "6,5 Creedmoor"

### Requirement: Symbols
Each value SHALL be labelled with its field name as its symbol, except: eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L", and L3PlusG "L3 + G".

#### Scenario: Symbol exceptions
- **WHEN** the value `junctionCone.alpha` is shown
- **THEN** its symbol is "α"

#### Scenario: Default symbol
- **WHEN** the value `caseHead.R1` is shown
- **THEN** its symbol is "R1"

### Requirement: Units
Lengths and diameters SHALL have the unit "mm". Pmax, PK and PE SHALL have the unit "bar", EE the unit "J", M the unit "g", and Q the unit "mm²". N SHALL have no unit. Angles SHALL have no unit column entry, because the degree sign is part of the value.

#### Scenario: Energy unit
- **WHEN** the value `pressures.EE` of "223 Rem." is shown
- **THEN** it reads "2890" with unit "J"

#### Scenario: Count has no unit
- **WHEN** the value `chamber.grooves.N` of "308 Win." is shown
- **THEN** it reads "4" and its unit cell is empty

### Requirement: Tolerances sit beside their value
A field `<X>Tol` SHALL be shown next to the value of X, in the same cell, as "<X value> <tolerance>". It SHALL NOT be shown as a row of its own.

#### Scenario: Tolerance in the value cell
- **WHEN** the record "223 Rem." has `lengths.L3` 44.7 and no tolerance, and `lengths.L1` 36.52 with `L1Tol` -0.2
- **THEN** the L1 row reads "36.52 -0.2" and no row is labelled L1Tol

#### Scenario: Tolerance on a radius
- **WHEN** the record "22 Win. Mag. R.F." has `caseHead.R` 1.27 with `RTol` -0.18
- **THEN** the R row reads "1.27 -0.18"

### Requirement: Angles
An angle given as a number of degrees SHALL be shown as that number followed by "°", for example "40°". An angle given as an object with degrees, minutes and seconds SHALL be shown as "<d>°<mm>'<ss>\"" with minutes and seconds as two digits, for example "39°59'49\"" or "50°35'02\"". Angle values are not converted to other units.

#### Scenario: Degree number
- **WHEN** the value `junctionCone.alpha` of "308 Win." (40) is shown
- **THEN** it reads "40°"

#### Scenario: Degrees minutes seconds
- **WHEN** the value `junctionCone.alpha` of "6,5 x 55 SE" (50 degrees, 35 minutes, 2 seconds) is shown
- **THEN** it reads "50°35'02\""

### Requirement: Header facts
The detail view header SHALL show `tab` as the C.I.P. table, `country`, `published` and `revised` dates as published, and `pressureMethod` as published. Dates SHALL be shown exactly as they appear in the record.

#### Scenario: Dates as published
- **WHEN** the detail view of "7,62 x 39" is shown
- **THEN** it shows "1989-01-04" as published and "2013-05-22" as revised
