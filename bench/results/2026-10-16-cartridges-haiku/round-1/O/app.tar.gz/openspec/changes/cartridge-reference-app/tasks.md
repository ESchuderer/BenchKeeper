# Tasks

## 1. Data and test harness

- [x] 1.1 Write `data.js` with the 25 records exactly as given, as `var CARTRIDGES`.
- [x] 1.2 Write `test/load.js`: runs the browser scripts in a `vm` context and returns their globals.
- [x] 1.3 Write a data test: 25 records, unique keys, every `name` present, every value in the record kept unchanged.

## 2. Presentation (format.js)

- [x] 2.1 Tests first: number formatting (4150, 51.18, 35), symbol exceptions, units per field, tolerance pairing (`L1` with `L1Tol`), angle formatting (number and d°m'ss").
- [x] 2.2 Implement `Format`: `symbol`, `unit`, `formatNumber`, `formatAngle`, `formatValue`, `sectionRows(section)`, `caseCapacity`.

## 3. Geometry (profile.js)

- [x] 3.1 Tests first: rim type for all 25 records (rimless, rimmed, belted, rimfire, plus the rebated rule), straight vs bottleneck, the groove rule, the heeled rule, the bullet seating and cylinder rules, ogive tangency and meplat diameter.
- [x] 3.2 Implement `Profile.rimType`, `Profile.outline` (outer profile, mouth, exposed bullet), and `Profile.section` (inner walls, head, bullet, primer pocket). Missing-value notes come from the same function.
- [x] 3.3 Test the wall rules (tn, tb, w) and the inner line for 223 Rem. against hand-computed values.

## 4. Drawing (drawing.js)

- [x] 4.1 Tests first: dimension set per record (only published ones), label rectangles do not overlap each other or any outline segment for all 25 records, notes name each missing value.
- [x] 4.2 Implement `Drawing.model(cart)`: outline, section polygons, dimensions, labels, notes, title block, and the viewBox.
- [x] 4.3 Implement `Drawing.svg(model, name)`: the SVG markup with accessible name, hatch pattern, dash-dot centre line, arrowheads and the title block.

## 5. App (index.html, app.js, styles.css)

- [x] 5.1 Tests first: `App.filter` (name, alternative names, case, family, combined), `App.route` (list and detail hashes, unknown key falls back to the list), count text.
- [x] 5.2 Implement the pure helpers in `app.js`.
- [x] 5.3 Build `index.html` with the list view and the detail view shell; DOM rendering in `app.js`: list, search, family select, count, detail header, drawing, tables, Print, All cartridges link.
- [x] 5.4 Write `styles.css`: a dense technical layout, tabular numbers, light and dark via `prefers-color-scheme`, print styles for A4 portrait, black on white, and the drawing at full width.

## 6. Verify and review

- [x] 6.1 Run the full Node test suite (`node --test`) and fix failures.
- [x] 6.2 Check the app loads from `file://` with no network requests: no `http(s)://` references in the app files apart from the data's source URLs and link targets.
- [x] 6.3 Render the drawing to an image and check it by eye, if a headless browser can be installed; otherwise state that it was not checked visually.
- [x] 6.4 Run `openspec validate cartridge-reference-app --strict`.
- [x] 6.5 Review the change against the specs (code review pass) and fix findings. Fixed: malformed hash fallback, belted head height, length-row order, primer pocket fill, print width at true scale, label font 3.0 mm. Declined: a note for an absent groove (the groove is conditional on E and E1 being published).
