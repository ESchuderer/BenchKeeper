// Cartridge geometry in mm, as [z, r] pairs: z along the axis from the head face
// (z = 0), r the radius. Curves are sampled into short segments.
var Profile = (function () {
  var PI = Math.PI;
  var DEG = PI / 180;
  var PRIMER = {
    sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04],
    lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3]
  };

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    var ratio = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }
  function unit(v) { var d = Math.hypot(v[0], v[1]); return [v[0] / d, v[1] / d]; }

  // Rounds the corner at pts[i] with radius r, tangent to both neighbours.
  // shortcut: a corner whose tangent length exceeds a neighbour is left sharp.
  function fillet(pts, i, r) {
    var A = pts[i - 1], C = pts[i], B = pts[i + 1];
    var u = unit([A[0] - C[0], A[1] - C[1]]);
    var v = unit([B[0] - C[0], B[1] - C[1]]);
    var theta = Math.acos(Math.max(-1, Math.min(1, u[0] * v[0] + u[1] * v[1])));
    if (theta < 1e-6 || PI - theta < 1e-6) return pts;
    var d = r / Math.tan(theta / 2);
    if (d > dist(A, C) || d > dist(B, C)) return pts;
    var T1 = [C[0] + u[0] * d, C[1] + u[1] * d];
    var T2 = [C[0] + v[0] * d, C[1] + v[1] * d];
    var b = unit([u[0] + v[0], u[1] + v[1]]);
    var k = r / Math.sin(theta / 2);
    var O = [C[0] + b[0] * k, C[1] + b[1] * k];
    var a1 = Math.atan2(T1[1] - O[1], T1[0] - O[0]);
    var da = Math.atan2(T2[1] - O[1], T2[0] - O[0]) - a1;
    while (da > PI) da -= 2 * PI;
    while (da < -PI) da += 2 * PI;
    var n = Math.max(4, Math.ceil(Math.abs(da) * r / 0.5));
    var arc = [];
    for (var j = 0; j <= n; j++) {
      var a = a1 + da * j / n;
      arc.push([O[0] + r * Math.cos(a), O[1] + r * Math.sin(a)]);
    }
    return pts.slice(0, i).concat(arc, pts.slice(i + 1));
  }

  // The radius of a polyline at axial position z (linear between points).
  function radiusAt(pts, z) {
    for (var i = 0; i < pts.length - 1; i++) {
      var p = pts[i], q = pts[i + 1];
      if (q[0] - p[0] < 1e-12) continue;
      if (z >= p[0] - 1e-9 && z <= q[0] + 1e-9) {
        return p[1] + (q[1] - p[1]) * (z - p[0]) / (q[0] - p[0]);
      }
    }
    return NaN;
  }

  function bulletNose(shape, Dx, zc, L6, m) {
    var a = Dx / 2 - m / 2, n = L6 - zc, pts = [];
    if (shape === 'pointy') {
      var rho = (a * a + n * n) / (2 * a);
      var thetaT = Math.asin(n / rho);
      var steps = Math.max(8, Math.ceil(n / 0.5));
      for (var i = 0; i <= steps; i++) {
        var t = thetaT * i / steps;
        pts.push([zc + rho * Math.sin(t), Dx / 2 - rho + rho * Math.cos(t)]);
      }
      return { pts: pts, rho: rho };
    }
    if (shape === 'rounded') {
      for (var j = 0; j <= 16; j++) {
        var phi = (PI / 2) * j / 16;
        pts.push([zc + n * Math.sin(phi), m / 2 + a * Math.cos(phi)]);
      }
      return { pts: pts, rho: null };
    }
    return { pts: [[zc, Dx / 2], [L6, m / 2]], rho: null };
  }

  function build(rec) {
    var c = rec.cartridge, ann = rec.annotations || {};
    var ch = c.caseHead, col = c.collar, L = c.lengths, pc = c.powderChamber, pr = c.projectile;
    var cj = c.junctionCone || {};
    var rim = rimType(rec);
    var missing = [];
    var R1h = ch.R1 / 2, P1h = pc.P1 / 2, Rr = ch.R, H2h = col.H2 / 2;
    var anchors = {}, outer, bodyStart, groove = false, beltRamp = null, tb, tn;
    var catPistol = ann.category === 'pistol';
    // shortcut: an unknown bullet shape is drawn as rounded and reported, until the data names every shape.
    var known = ['pointy', 'rounded', 'flat', 'semi_wadcutter'];
    var shape = known.indexOf(ann.defaultBulletShape) >= 0 ? ann.defaultBulletShape : 'rounded';
    if (shape !== ann.defaultBulletShape) missing.push('bullet shape');

    // Head face and rim edge (r, z) in the brief's notation.
    if (rim === 'rimfire') {
      var rho = Math.min(Rr / 2, (ch.R1 - pc.P1) / 2);
      var cr = R1h - rho;
      outer = [[0, 0], [0, cr]];
      for (var i = 1; i < 8; i++) {
        var th = PI * (1 - i / 8);
        outer.push([rho + rho * Math.cos(th), cr + rho * Math.sin(th)]);
      }
      outer.push([2 * rho, cr], [2 * rho, P1h]);
      bodyStart = 2 * rho;
      anchors.R1 = [rho, R1h];
      anchors.R = [2 * rho, cr];
    } else {
      var x = 0;
      if (ch.beta !== undefined && ch.beta < 90 && ch.f !== undefined) {
        x = Math.min(ch.f * Math.tan(ch.beta * DEG), ch.R1 / 4);
        outer = [[0, 0], [0, R1h - x], [ch.f, R1h]];
      } else {
        outer = [[0, 0], [0, R1h]];
      }
      outer.push([Rr, R1h]);
      anchors.R1 = [Rr, R1h];
      anchors.R = [Rr, R1h];
      // The groove is optional: it is drawn only where E and E1 are published.
      var needs = [];
      if (ch.E === undefined) needs.push('E');
      if (ch.E1 === undefined) needs.push('E1');
      if (ch.eMin === undefined) needs.push('e min');
      if (rim === 'belted') {
        if (ch.R3 === undefined) needs.push('R3');
        if (ch.delta === undefined) needs.push('delta');
      }
      var published = ch.E !== undefined || ch.E1 !== undefined;
      if (needs.length === 0) {
        var R3h = rim === 'belted' ? ch.R3 / 2 : 0, E1h = ch.E1 / 2;
        if (rim === 'belted') {
          var zRamp = Rr + ch.eMin + (R3h - E1h) / Math.tan(ch.delta * DEG);
          outer.push([Rr, E1h], [Rr + ch.eMin, E1h], [zRamp, R3h], [ch.E, R3h], [ch.E, P1h]);
          beltRamp = zRamp;
          groove = 'belted';
        } else {
          outer.push([Rr, E1h], [Rr + ch.eMin, E1h], [ch.E, P1h]);
          groove = true;
        }
        bodyStart = ch.E;
        anchors.E1 = [Rr + ch.eMin, E1h];
      } else {
        if (published) missing.push('extractor groove (' + needs.join(', ') + ' not published)');
        outer.push([Rr, P1h]);
        bodyStart = Rr;
      }
    }
    anchors.P1 = [bodyStart, P1h];

    // Shoulder and neck, or straight body.
    var cornerBody = -1, cornerNeck = -1, shoulder = false;
    var L1 = L.L1, L2 = L.L2, P2h = pc.P2 !== undefined ? pc.P2 / 2 : undefined, H1h = col.H1 !== undefined ? col.H1 / 2 : undefined;
    var hasShoulder = cj.alpha !== undefined && L1 !== undefined && L2 !== undefined;
    if (hasShoulder && P2h !== undefined && H1h !== undefined) {
      shoulder = true;
      outer.push([L1, P2h]); cornerBody = outer.length - 1;
      outer.push([L2, H1h]); cornerNeck = outer.length - 1;
      outer.push([L.L3, H2h]);
      anchors.P2 = [L1, P2h];
      anchors.H1 = [L2, H1h];
      anchors.L1 = [L1, P2h];
      anchors.L2 = [L2, H1h];
      if (cj.r1Min === undefined) missing.push('r1 min');
      if (cj.r2 === undefined) missing.push('r2');
    } else {
      var someShoulder = cj.alpha !== undefined || L1 !== undefined || L2 !== undefined;
      if (someShoulder) missing.push('shoulder (' + ['alpha', 'L1', 'L2', 'P2', 'H1'].filter(function (f) {
        return f === 'alpha' ? cj.alpha === undefined : f === 'L1' ? L1 === undefined : f === 'L2' ? L2 === undefined :
          f === 'P2' ? pc.P2 === undefined : col.H1 === undefined;
      }).join(', ') + ' not published)');
      outer.push([L.L3, H2h]);
    }
    var raw = outer.slice();
    if (shoulder) {
      if (cj.r2 !== undefined) outer = fillet(outer, cornerNeck, cj.r2);
      if (cj.r1Min !== undefined) outer = fillet(outer, cornerBody, cj.r1Min);
    }
    var mouthZ = L.L3;
    anchors.H2 = [mouthZ, H2h];
    anchors.L3 = [mouthZ, H2h];

    // Walls and solid head.
    var G1 = pr.G1;
    var tn = (col.H2 - G1) / 2;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1h);
    var heeled = col.H2 - G1 <= 0.015;
    var pocketSpec = ann.primerType === 'rimfire' ? null : PRIMER[ann.primerType];
    if (ann.primerType !== 'rimfire' && !pocketSpec) missing.push('primer type');
    var pocket = pocketSpec ? { diameter: pocketSpec[0], depth: pocketSpec[1] } : null;
    var w = Math.max(2.5, 0.25 * P1h,
      pocket ? pocket.depth + 1.5 : 0,
      groove ? ch.E + tb : 0,
      groove === 'belted' ? beltRamp + tb : 0);

    function thicknessAt(z) {
      if (!shoulder) return z >= bodyStart ? tn + (tb - tn) * (mouthZ - z) / (mouthZ - bodyStart) : tb;
      if (z >= L2) return tn;
      if (z >= L1) return tb + (tn - tb) * (z - L1) / (L2 - L1);
      return tb;
    }
    var innerAtW = radiusAt(raw, w) - thicknessAt(w);
    var inner = [[mouthZ, H2h - tn]];
    if (shoulder) inner.push([L2, H1h - tn], [L1, P2h - tb]);
    inner.push([w, innerAtW]);

    // Bullet.
    var Dx = heeled ? col.H2 : G1;
    var seatR = heeled ? (col.H2 - 2 * tb) / 2 : G1 / 2;
    var s, k, m;
    if (shape === 'pointy') { s = G1; k = 0.40; m = Math.max(0.08 * G1, 1.27); }
    else if (shape === 'semi_wadcutter') { s = 0.6 * G1; k = 0.78; m = 0.6 * G1; }
    else if (shape === 'flat') { s = (catPistol ? 0.4 : 0.8) * G1; k = catPistol ? 0.70 : 0.60; m = 0.55 * G1; }
    else { s = (catPistol ? 0.4 : 0.8) * G1; k = catPistol ? 0.65 : 0.55; m = 0.15 * G1; }
    var L6 = L.L6, zb = mouthZ - s, zc = zb + k * (L6 - zb);
    var nose = bulletNose(shape, Dx, zc, L6, m);
    var bulletOuter = [[mouthZ, Dx / 2], [zc, Dx / 2]].concat(nose.pts.slice(1));
    bulletOuter.push([L6, 0]);
    var bulletSection = [[zb, 0], [zb, seatR], [mouthZ, seatR]].concat(bulletOuter.slice(0, -1));
    if (seatR === Dx / 2) bulletSection.splice(2, 1);
    bulletSection.push([L6, 0]);
    anchors.G1 = [zc, Dx / 2];
    anchors.L6 = [L6, m / 2];

    // Section of the case and its pocket.
    var caseSection = outer.concat(inner, [[w, 0]]);
    var pocketHole = pocket ? [[0, 0], [pocket.depth, 0], [pocket.depth, pocket.diameter / 2], [0, pocket.diameter / 2]] : null;
    if (pocket) pocket.hole = pocketHole;

    // Shoulder apex on the axis, for the angle dimension.
    var alpha = null;
    if (shoulder && P2h > H1h) {
      var zApex = L1 + P2h * (L2 - L1) / (P2h - H1h);
      alpha = { apex: [zApex, 0], from: [L1, P2h] };
    }

    return {
      rim: rim, shoulder: shoulder, groove: groove, heeled: heeled, bodyStart: bodyStart,
      outer: outer, raw: raw, bulletOuter: bulletOuter,
      outside: outer.concat(bulletOuter),
      inner: inner, caseSection: caseSection, bulletSection: bulletSection,
      walls: { tn: tn, tb: tb }, w: w, pocket: pocket,
      bullet: { shape: shape, Dx: Dx, seatR: seatR, s: s, k: k, m: m, zb: zb, zc: zc, Lb: L6 - zb, rho: nose.rho, G1: G1 },
      anchors: anchors, alpha: alpha, missing: missingNotes(missing)
    };
  }

  // Merge the shoulder fillet names into one note, as the drawing states them.
  function missingNotes(list) {
    var fillets = list.filter(function (t) { return t === 'r1 min' || t === 'r2'; });
    var rest = list.filter(function (t) { return fillets.indexOf(t) < 0; });
    var notes = rest.map(function (t) { return 'not drawn: ' + t; });
    if (fillets.length) notes.push('not drawn: ' + fillets.join(', ') + ' (not published)');
    return notes;
  }

  return { rimType: rimType, build: build, fillet: fillet, radiusAt: radiusAt };
})();
