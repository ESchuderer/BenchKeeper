const test = require('node:test');
const assert = require('node:assert/strict');
const { load, plain } = require('./load');

const ctx = load('data.js', 'format.js', 'profile.js', 'drawing.js', 'app.js');
const { App, CARTRIDGES } = ctx;
const records = plain(CARTRIDGES);
const names = (list) => list.map((r) => r.name);

test('the family select offers All and the five families of the brief', () => {
  assert.deepEqual(plain(App.FAMILIES), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('an empty search lists everything', () => {
  assert.equal(App.filter(records, '', 'All').length, 25);
  assert.equal(App.filter(records, '   ', 'All').length, 25);
});

test('search matches the name, ignoring case', () => {
  assert.deepEqual(names(App.filter(records, '223', 'All')), ['223 Rem.']);
  assert.ok(names(App.filter(records, 'MAGNUM', 'All')).includes('357 Magnum'));
});

test('search matches alternative names: "7,62 x 51" finds 308 Win.', () => {
  assert.deepEqual(names(App.filter(records, '7,62 x 51', 'All')), ['308 Win.']);
  assert.deepEqual(names(App.filter(records, '30-06', 'All')), ['30-06 Spring.']);
});

test('the family filter lists only that family', () => {
  const rimfire = App.filter(records, '', 'rimfire');
  assert.equal(rimfire.length, 3);
  assert.ok(rimfire.every((r) => r.family === 'rimfire'));
});

test('search and family combine', () => {
  assert.deepEqual(names(App.filter(records, 'win', 'belted')), ['300 Win. Mag.']);
  assert.ok(names(App.filter(records, 'Win', 'rimless')).includes('308 Win.'));
  assert.ok(!names(App.filter(records, 'Win', 'rimless')).includes('357 Magnum'));
});

test('the count text is "<n> cartridges"', () => {
  assert.equal(App.countText(3), '3 cartridges');
  assert.equal(App.countText(25), '25 cartridges');
});

test('a detail route names its cartridge; the list route is the default', () => {
  assert.deepEqual(plain(App.route('#/cartridge/308_win', records)), { view: 'detail', key: '308_win' });
  assert.deepEqual(plain(App.route('#/', records)), { view: 'list' });
  assert.deepEqual(plain(App.route('', records)), { view: 'list' });
});

test('an unknown cartridge key falls back to the list', () => {
  assert.deepEqual(plain(App.route('#/cartridge/nope', records)), { view: 'list' });
});

test('hashFor and route round-trip for every cartridge', () => {
  for (const r of records) {
    assert.deepEqual(plain(App.route(App.hashFor(r.key), records)), { view: 'detail', key: r.key });
  }
});
