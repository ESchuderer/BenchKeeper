const test = require('node:test');
const assert = require('node:assert/strict');
const { load, plain } = require('./load');

const { CARTRIDGES } = load('data.js');
const records = plain(CARTRIDGES);

test('there are 25 records with unique keys and names', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
  assert.equal(new Set(records.map((r) => r.name)).size, 25);
});

test('every record has the published sections', () => {
  for (const r of records) {
    assert.ok(r.cartridge, r.key);
    assert.ok(r.chamber, r.key);
    assert.ok(r.cartridge.lengths.L3 > 0, r.key);
    assert.ok(['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'].includes(r.family), r.key);
  }
});

test('spot checks against the brief', () => {
  const byKey = Object.fromEntries(records.map((r) => [r.key, r]));
  assert.equal(byKey['308_win'].cartridge.lengths.L3, 51.18);
  assert.equal(byKey['308_win'].cartridge.lengths.L1Tol, -0.2);
  assert.deepEqual(byKey['308_win'].alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.deepEqual(byKey['7_x_64'].cartridge.junctionCone.alpha, { degrees: 40, minutes: 25, seconds: 44 });
  assert.deepEqual(byKey['7_x_64'].chamber.junctionCone.alpha, { degrees: 40, minutes: 31, seconds: 33 });
  assert.equal(byKey['22_long_rifle'].cartridge.projectile.G1, 5.72);
  assert.equal(byKey['17_hmr'].cartridge.junctionCone.r1Min, undefined);
});
