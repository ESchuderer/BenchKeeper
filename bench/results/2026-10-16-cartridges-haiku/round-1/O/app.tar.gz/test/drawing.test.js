const test = require('node:test');
const assert = require('node:assert/strict');
const { load, plain } = require('./load');

const ctx = load('data.js', 'format.js', 'profile.js', 'drawing.js');
const { Drawing, CARTRIDGES } = ctx;
const records = plain(CARTRIDGES);
const byKey = Object.fromEntries(records.map((r) => [r.key, r]));
const texts = (m) => m.labels.map((l) => l.text);

test('every label clears every other label and every line, for all 25 records', () => {
  for (const r of records) {
    const m = Drawing.model(r);
    m.labels.forEach((lab, i) => {
      m.lines.forEach(([a, b]) => {
        assert.ok(!Drawing.segHitsBox(a, b, lab.box, 0.3), `${r.key}: label "${lab.text}" touches a line`);
      });
      m.labels.forEach((other, j) => {
        if (j > i) assert.ok(!Drawing.boxesOverlap(lab.box, other.box, 0.3), `${r.key}: "${lab.text}" overlaps "${other.text}"`);
      });
    });
  }
});

test('labels stay inside the view box', () => {
  for (const r of records) {
    const m = Drawing.model(r);
    const vb = m.viewBox;
    for (const lab of m.labels) {
      assert.ok(lab.box.x0 >= vb.x && lab.box.x1 <= vb.x + vb.w, `${r.key} ${lab.text} x`);
      assert.ok(lab.box.y0 >= vb.y && lab.box.y1 <= vb.y + vb.h, `${r.key} ${lab.text} y`);
    }
  }
});

test('the 308 Win. drawing carries every published dimension with its symbol and value', () => {
  const t = texts(Drawing.model(byKey['308_win']));
  for (const want of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72',
    'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(t.includes(want), `missing ${want} in ${t.join(' | ')}`);
  }
});

test('unpublished dimensions are not drawn', () => {
  const t = texts(Drawing.model(byKey['9_mm_luger']));
  assert.ok(!t.some((x) => /^(L1|L2|P2|H1|α) /.test(x)), t.join(' | '));
  assert.ok(t.includes('L3 19.15') && t.includes('H2 9.65'));
});

test('missing values are named in the notes and in the title block', () => {
  const m = Drawing.model(byKey['17_hmr']);
  assert.deepEqual(plain(m.notes), ['not drawn: r1 min, r2 (not published)']);
  assert.ok(m.title.lines.some((l) => l.text === 'not drawn: r1 min, r2 (not published)'));
  assert.deepEqual(plain(Drawing.model(byKey['308_win']).notes), []);
});

test('the title block carries name, table, revision, units and scale', () => {
  const lines = Drawing.model(byKey['9_mm_luger']).title.lines.map((l) => l.text);
  assert.ok(lines.includes('9 mm Luger'));
  assert.ok(lines.includes('C.I.P. table IV · Revised 2008-09-23'));
  assert.ok(lines.includes('Dimensions in mm · Scale 1:1'));
});

test('the svg has the accessible name, hatch pattern, centre line and section paths', () => {
  const svg = Drawing.svg(Drawing.model(byKey['308_win']), 'x');
  assert.ok(svg.includes('aria-label="308 Win. drawing"'));
  assert.ok(svg.includes('<pattern id="hatch-x"'));
  assert.ok(svg.includes('class="centre"'));
  assert.ok(svg.includes('fill="url(#hatch-x)"'));
  assert.ok(svg.startsWith('<svg'));
});

test('a 1 mm scale: the view box width is the drawing width in mm', () => {
  const m = Drawing.model(byKey['223_rem']);
  assert.ok(m.viewBox.w > 57.4, 'wider than the case');
  assert.equal(m.viewBox.w, m.viewBox.w.toFixed ? Number(m.viewBox.w) : m.viewBox.w);
});
