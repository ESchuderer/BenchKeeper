const test = require('node:test');
const assert = require('node:assert/strict');
const { load, plain } = require('./load');

const ctx = load('data.js', 'format.js');
const { Format, CARTRIDGES } = ctx;
const records = plain(CARTRIDGES);
const byKey = Object.fromEntries(records.map((r) => [r.key, r]));

test('numbers print as published, without trailing zeros or separators', () => {
  assert.equal(Format.formatNumber(4150), '4150');
  assert.equal(Format.formatNumber(51.18), '51.18');
  assert.equal(Format.formatNumber(35), '35');
  assert.equal(Format.formatNumber(-0.2), '-0.2');
});

test('symbols are the field name except for the published exceptions', () => {
  assert.equal(Format.symbol('L1'), 'L1');
  assert.equal(Format.symbol('eMin'), 'e min');
  assert.equal(Format.symbol('r1Min'), 'r1 min');
  assert.equal(Format.symbol('r1Max'), 'r1 max');
  assert.equal(Format.symbol('alpha'), 'α');
  assert.equal(Format.symbol('alpha1'), 'α1');
  assert.equal(Format.symbol('beta'), 'β');
  assert.equal(Format.symbol('delta'), 'δ');
  assert.equal(Format.symbol('deltaL'), 'delta L');
  assert.equal(Format.symbol('L3PlusG'), 'L3 + G');
});

test('units follow the brief: lengths mm, pressures bar, EE J, M g, Q mm², N and angles none', () => {
  assert.equal(Format.unit('L3'), 'mm');
  assert.equal(Format.unit('G1'), 'mm');
  assert.equal(Format.unit('Pmax'), 'bar');
  assert.equal(Format.unit('PK'), 'bar');
  assert.equal(Format.unit('PE'), 'bar');
  assert.equal(Format.unit('EE'), 'J');
  assert.equal(Format.unit('M'), 'g');
  assert.equal(Format.unit('Q'), 'mm²');
  assert.equal(Format.unit('N'), '');
  assert.equal(Format.unit('alpha'), '');
  assert.equal(Format.unit('i'), '');
});

test('angles: a number is degrees, an object is d°mm\'ss"', () => {
  assert.equal(Format.formatAngle(40), '40°');
  assert.equal(Format.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(Format.formatAngle({ degrees: 50, minutes: 35, seconds: 2 }), '50°35\'02"');
  assert.equal(Format.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
});

test('a tolerance joins its value and is never a row of its own', () => {
  const rows = Format.sectionRows(byKey['223_rem'].cartridge.lengths);
  const l1 = rows.find((r) => r.symbol === 'L1');
  assert.deepEqual(plain(l1), { symbol: 'L1', value: '36.52 -0.2', unit: 'mm' });
  assert.ok(!rows.some((r) => r.symbol.includes('Tol')));
  assert.ok(!rows.some((r) => r.symbol === 'L1Tol'));
  // a value without tolerance keeps its own cell
  assert.equal(rows.find((r) => r.symbol === 'L3').value, '44.7');
});

test('the rows of a section keep the published field order', () => {
  const keys = plain(Format.sectionRows(byKey['308_win'].cartridge.lengths).map((r) => r.symbol));
  assert.deepEqual(keys, ['L1', 'L2', 'L3', 'L6']);
});

test('angle rows show the degree form and no unit', () => {
  const row = Format.sectionRows(byKey['6_5_x_55_se'].cartridge.junctionCone).find((r) => r.symbol === 'α');
  assert.deepEqual(plain(row), { symbol: 'α', value: '50°35\'02"', unit: '' });
});

test('the water capacity comes with its unit, note and source', () => {
  const cap = Format.capacity(byKey['308_win']);
  assert.equal(cap.value, '56');
  assert.equal(cap.unit, 'gr H2O');
  assert.equal(cap.note, 'Lapua brass measures 55.8 (lapua-308)');
  assert.equal(cap.url, 'http://kwk.us/cases.html');
  assert.equal(Format.capacity(byKey['7_x_64']), null);
});

test('section titles are readable', () => {
  assert.equal(Format.sectionTitle('caseHead'), 'Case head');
  assert.equal(Format.sectionTitle('powderChamber'), 'Powder chamber');
  assert.equal(Format.sectionTitle('junctionCone'), 'Junction cone');
});

test('every cartridge and chamber value appears exactly once in some table row', () => {
  for (const r of records) {
    for (const root of ['cartridge', 'chamber']) {
      for (const [section, values] of Object.entries(r[root])) {
        const rows = Format.sectionRows(values);
        const fields = Object.keys(values).filter((k) => !k.endsWith('Tol'));
        assert.equal(rows.length, fields.length, `${r.key} ${root}.${section}`);
      }
    }
  }
});
