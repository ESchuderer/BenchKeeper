// Runs the browser scripts (classic scripts, no modules) in one vm context,
// so the app files stay exactly as the browser loads them.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');

function load(...files) {
  const ctx = vm.createContext({ console, Math, Number, String, Object, Array, JSON });
  for (const file of files) {
    vm.runInContext(fs.readFileSync(path.join(ROOT, file), 'utf8'), ctx, { filename: file });
  }
  return ctx;
}

// Cross-realm objects fail deepStrictEqual on prototypes; compare plain copies.
function plain(value) {
  return JSON.parse(JSON.stringify(value));
}

module.exports = { load, plain, ROOT };
