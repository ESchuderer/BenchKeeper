const test = require('node:test');
const assert = require('node:assert/strict');
const { load, plain } = require('./load');

const ctx = load('data.js', 'format.js', 'profile.js');
const { Profile, CARTRIDGES } = ctx;
const records = plain(CARTRIDGES);
const byKey = Object.fromEntries(records.map((r) => [r.key, r]));
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${a} != ${b}`);

test('rim type for all 25 records follows family and R1/P1', () => {
  const expected = {
    '223_rem': 'rimless', '243_win': 'rimless', '6_5_creedmoor': 'rimless', '6_5_x_55_se': 'rimless',
    '270_win': 'rimless', '7_x_64': 'rimless', '308_win': 'rimless', '30_06_spring': 'rimless',
    '8_x_57_is': 'rimless', '9_3_x_62': 'rimless', '7_62_x_39': 'rimless', '338_lapua_mag': 'rimless',
    '9_mm_luger': 'rimless', '45_auto': 'rimless', '40_s_w': 'rimless',
    '9_3_x_74_r': 'rimmed', '7_x_65_r': 'rimmed', '38_special': 'rimmed', '357_magnum': 'rimmed',
    '44_rem_mag': 'rimmed', '300_win_mag': 'belted', '7_mm_rem_mag': 'belted',
    '22_long_rifle': 'rimfire', '22_win_mag_r_f': 'rimfire', '17_hmr': 'rimfire'
  };
  for (const r of records) assert.equal(Profile.rimType(r), expected[r.key], r.key);
});

test('rebated when R1/P1 is below 0.98', () => {
  const fake = { family: 'pistol', cartridge: { caseHead: { R1: 9, R: 1 }, powderChamber: { P1: 10 } } };
  assert.equal(Profile.rimType(fake), 'rebated');
});

test('bottleneck when alpha, L1 and L2 are published, straight otherwise', () => {
  for (const key of ['223_rem', '17_hmr', '9_3_x_74_r', '338_lapua_mag']) {
    assert.equal(Profile.build(byKey[key]).shoulder, true, key);
  }
  for (const key of ['9_mm_luger', '22_long_rifle', '22_win_mag_r_f', '357_magnum', '44_rem_mag']) {
    assert.equal(Profile.build(byKey[key]).shoulder, false, key);
  }
});

test('the groove is drawn only where E and E1 are published', () => {
  assert.ok(Profile.build(byKey['223_rem']).anchors.E1);
  assert.equal(Profile.build(byKey['22_long_rifle']).groove, false);
  assert.equal(Profile.build(byKey['9_3_x_74_r']).groove, false);
  assert.equal(Profile.build(byKey['300_win_mag']).groove, 'belted');
});

test('heeled only where H2 - G1 is at most 0.015: the 22 Long Rifle', () => {
  for (const r of records) {
    const heeled = Profile.build(r).heeled;
    assert.equal(heeled, r.key === '22_long_rifle', r.key);
  }
});

test('the outline starts at the head face and ends at the mouth', () => {
  const m = plain(Profile.build(byKey['308_win']));
  assert.deepEqual(m.outer[0], [0, 0]);
  const mouth = m.outer[m.outer.length - 1];
  near(mouth[0], 51.18);
  near(mouth[1], 8.72 / 2);
});

test('straight 9 mm body runs to H2 at L3 without a shoulder', () => {
  const m = Profile.build(byKey['9_mm_luger']);
  const mouth = m.outer[m.outer.length - 1];
  near(mouth[0], 19.15);
  near(mouth[1], 9.65 / 2);
});

test('bullet: 308 Win. pointy seating, cylinder, meplat and tip', () => {
  const m = Profile.build(byKey['308_win']);
  const b = m.bullet;
  near(b.s, 7.85);            // 1.0 * G1
  near(b.zb, 51.18 - 7.85);
  near(b.zc, b.zb + 0.4 * (71.12 - b.zb));
  near(b.m, 1.27);            // max(0.08 * G1, 1.27)
  const tip = m.bulletOuter[m.bulletOuter.length - 2];
  near(tip[0], 71.12);
  near(tip[1], 1.27 / 2);
});

test('pointy nose is a tangent ogive: every nose point lies on the arc', () => {
  const m = Profile.build(byKey['308_win']);
  const b = m.bullet;
  const nose = m.bulletOuter.filter((p) => p[0] >= b.zc - 1e-9 && p[0] <= 71.12 + 1e-9 && p[1] > 0);
  const centre = [b.zc, 7.85 / 2 - b.rho];
  for (const p of nose) {
    const d = Math.hypot(p[0] - centre[0], p[1] - centre[1]);
    near(d, b.rho, 1e-6);
  }
  near(b.rho, ((7.85 / 2 - 1.27 / 2) ** 2 + (71.12 - b.zc) ** 2) / (2 * (7.85 / 2 - 1.27 / 2)), 1e-9);
});

test('semi-wadcutter pistol bullet: seating 0.6 G1, cylinder 0.78, meplat 0.6 G1', () => {
  const rec = byKey['357_magnum'];
  const G1 = rec.cartridge.projectile.G1;
  const L3 = rec.cartridge.lengths.L3;
  const L6 = rec.cartridge.lengths.L6;
  const b = Profile.build(rec).bullet;
  near(b.s, 0.6 * G1);
  near(b.zb, L3 - 0.6 * G1);
  near(b.zc, b.zb + 0.78 * (L6 - b.zb));
  near(b.m, 0.6 * G1);
});

test('walls for 223 Rem.: tn = (6.43 - 5.7)/2, tb = 0.6', () => {
  const m = Profile.build(byKey['223_rem']);
  near(m.walls.tn, (6.43 - 5.7) / 2);
  near(m.walls.tb, 0.6);
});

test('solid head top w for 223 Rem. is the primer pocket depth plus 1.5', () => {
  const m = Profile.build(byKey['223_rem']);
  near(m.w, 3.04 + 1.5);
  assert.deepEqual({ diameter: m.pocket.diameter, depth: m.pocket.depth }, { diameter: 4.45, depth: 3.04 });
});

test('primer pockets: lr 5.33 deep 3.3, sp 4.45 deep 3.04, rimfire none', () => {
  const pocket = (key) => { const p = Profile.build(byKey[key]).pocket; return p && { diameter: p.diameter, depth: p.depth }; };
  assert.deepEqual(pocket('308_win'), { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(pocket('9_mm_luger'), { diameter: 4.45, depth: 3.04 });
  assert.equal(Profile.build(byKey['22_long_rifle']).pocket, null);
});

test('missing values are named, never invented', () => {
  assert.ok(Profile.build(byKey['17_hmr']).missing.some((t) => /r1 min, r2/.test(t)));
  assert.ok(Profile.build(byKey['338_lapua_mag']).missing.some((t) => /r1 min/.test(t)));
  assert.deepEqual(plain(Profile.build(byKey['308_win']).missing), []);
});

test('rimfire rim edge is a half-round outermost at R1/2', () => {
  const m = Profile.build(byKey['22_long_rifle']);
  const maxR = Math.max(...m.outer.map((p) => p[1]));
  near(maxR, 7.06 / 2);
});

test('belted 300 Win. Mag.: ramp at delta reaches the belt, belt runs to E', () => {
  const m = Profile.build(byKey['300_win_mag']);
  const belt = m.outer.filter((p) => Math.abs(p[1] - 13.51 / 2) < 1e-9);
  assert.ok(belt.length >= 2);
  near(Math.max(...belt.map((p) => p[0])), 5.59);
});
