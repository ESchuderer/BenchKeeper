# Cartridge Reference Constitution

## Core Principles

### I. Static and Offline
The app is plain HTML, CSS and JavaScript: no framework, no build step, no server code, no runtime dependencies, no network requests (no CDNs, web fonts or analytics). `index.html` must work when opened directly from disk (`file://`) in Chromium, so scripts are classic scripts and data is embedded in JavaScript, not fetched.

### II. Data Fidelity
The 25 records supplied in the brief are the only data. They are used as published: never edited, invented, completed or fetched. A value a rule needs but the record lacks is never made up; the drawing omits that feature and says which value is missing.

### III. Test First
Behaviour is specified by tests under `tests/` (Node's built-in `node:test`, no test dependency needed) written and seen to fail before the code that satisfies them. Geometry and layout rules are checked on all 25 records.

### IV. Technical Reading Surface
Dense, calm, precise. Values are shown as published, tabular numerals, light and dark themes following the system, legible on a phone, and legible when printed on one A4 portrait page in black on white.

### V. Simplicity
The smallest code that fully meets the brief. No abstraction, option or feature the brief does not ask for. Shared helpers live in one place.

## Governance

The brief for this project is the governing requirement. Changes to these principles are recorded here with a version bump.

**Version**: 1.0.0 | **Ratified**: 2026-10-16 | **Last Amended**: 2026-10-16
