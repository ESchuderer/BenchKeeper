// DOM for the cartridge reference: list with search and family filter, detail view by hash route, print.
(function () {
  'use strict';

  const CIP = window.CIP;
  const FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  const records = CIP.sortByName(CIP.records);
  const app = document.getElementById('app');
  const state = { query: '', family: 'all' };

  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const byKey = (key) => records.find((r) => r.key === key);

  function renderList() {
    document.title = 'Cartridges';
    app.innerHTML = `
      <h1>Cartridges</h1>
      <div class="filters" role="search">
        <div class="field"><label for="q">Search</label>
          <input id="q" type="search" autocomplete="off" spellcheck="false" value="${esc(state.query)}"></div>
        <div class="field"><label for="family">Family</label>
          <select id="family">${['all', ...FAMILIES].map((f) =>
            `<option value="${f}"${f === state.family ? ' selected' : ''}>${f === 'all' ? 'All' : f}</option>`).join('')}</select></div>
      </div>
      <p class="count" id="count" aria-live="polite"></p>
      <ul class="cartridges" id="list"></ul>`;
    const q = document.getElementById('q');
    const family = document.getElementById('family');
    q.addEventListener('input', () => { state.query = q.value; drawList(); });
    family.addEventListener('change', () => { state.family = family.value; drawList(); });
    drawList();
  }

  function drawList() {
    const found = CIP.filterRecords(records, state.query, state.family);
    document.getElementById('count').textContent = CIP.countText(found.length);
    document.getElementById('list').innerHTML = found.map((r) => `
      <li class="cartridge-row">
        <a href="#/cartridge/${encodeURIComponent(r.key)}">${esc(r.name)}</a>
        <span class="family">${esc(r.family)}</span>
        <span class="l3">L3 <span class="num">${esc(CIP.valueWithTolerance(r.cartridge.lengths, 'L3'))}</span> mm</span>
      </li>`).join('');
  }

  function capacityHtml(cap) {
    if (!cap) return '—';
    const note = cap.note ? ` <span class="note">(${esc(cap.note)})</span>` : '';
    return `<span class="num">${esc(cap.grH2O)}</span> gr H2O, source <a href="${esc(cap.url)}">${esc(cap.source)}</a>${note}`;
  }

  function renderDetail(key) {
    const r = byKey(key);
    if (!r) {
      document.title = 'Cartridges';
      app.innerHTML = `<p class="nav"><a href="#/">All cartridges</a></p>
        <h1>Cartridge not found</h1><p>No cartridge has the key “${esc(key)}”.</p>`;
      return;
    }
    document.title = `${r.name} · Cartridges`;
    const a = r.annotations;
    const facts = [
      ['Alternative names', (r.alternativeNames || []).map(esc).join('; ') || '—'],
      ['Family', esc(r.family)],
      ['Category', esc(a.category)],
      ['Primer type', esc(a.primerType)],
      ['C.I.P. table', esc(r.tab)],
      ['Country', esc(r.country)],
      ['Published', esc(r.published)],
      ['Revised', esc(r.revised)],
      ['Pressure method', esc(r.pressureMethod)],
      ['Water capacity', capacityHtml(a.publishedCapacity)],
    ];
    const drawing = CIP.buildDrawing(r);
    const notes = drawing.notes.length
      ? `<ul class="notes">${drawing.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>` : '';
    const groups = CIP.sectionsOf(r).map((g) => `
      <section class="group">
        <h2>${esc(g.title)}</h2>
        ${g.sections.map((s) => `
          <table class="values">
            <caption>${esc(s.title)}</caption>
            <thead><tr><th scope="col">Symbol</th><th scope="col">Value</th><th scope="col">Unit</th></tr></thead>
            <tbody>${s.rows.map((row) => `
              <tr><th scope="row">${esc(row.symbol)}</th><td class="num">${esc(row.value)}</td><td>${esc(row.unit)}</td></tr>`).join('')}
            </tbody>
          </table>`).join('')}
      </section>`).join('');

    app.innerHTML = `
      <article class="cartridge">
        <p class="nav no-print"><a href="#/">All cartridges</a> <button type="button" class="print" id="print">Print</button></p>
        <h1>${esc(r.name)}</h1>
        <dl class="facts">${facts.map(([t, d]) => `<div><dt>${t}</dt><dd>${d}</dd></div>`).join('')}</dl>
        <figure class="drawing-figure">${drawing.svg || ''}</figure>
        ${notes}
        <div class="sections">${groups}</div>
        <footer class="print-only">Source: C.I.P. TDCC, revised ${esc(r.revised)}.</footer>
      </article>`;
    document.getElementById('print').addEventListener('click', () => window.print());
  }

  function render() {
    const route = CIP.parseRoute(location.hash);
    if (route.view === 'cartridge') renderDetail(route.key);
    else renderList();
  }

  window.addEventListener('hashchange', render);
  render();
})();
