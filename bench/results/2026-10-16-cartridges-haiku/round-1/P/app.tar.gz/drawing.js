// Drawing geometry for one cartridge, in mm at true scale (1 SVG unit = 1 mm).
// x = z along the axis, head face at 0. Outside view above the axis (y = -r), section below (y = +r).
(function (root, factory) {
  const api = factory(typeof require === 'function' ? require('./model.js') : root.CIP);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CIP = Object.assign(root.CIP || {}, api);
})(typeof window !== 'undefined' ? window : globalThis, function (M) {
  'use strict';

  const FONT = 3.4;               // label font size, mm
  const CAP = 2.6;                // label box height, mm
  const CHAR_W = 0.62 * FONT;     // advance per label character, mm (over-estimate, so boxes never under-size)
  const TB_W = 62, TB_H = 20;     // title block size, mm
  const PX_PER_MM = 4.2;          // screen scale of the drawing; the SVG shrinks to the container width
  const PRIMER_POCKET = {
    sp: { d: 4.45, depth: 3.04 }, spm: { d: 4.45, depth: 3.04 }, sr: { d: 4.45, depth: 3.04 },
    lp: { d: 5.33, depth: 3.04 }, lpm: { d: 5.33, depth: 3.04 }, lr: { d: 5.33, depth: 3.3 }, lrm: { d: 5.33, depth: 3.3 },
  };
  const SHAPES = ['pointy', 'rounded', 'flat', 'semi_wadcutter'];

  const deg = (a) => (a * Math.PI) / 180;
  // An angle is a number of degrees or {degrees, minutes, seconds}.
  const angleDeg = (v) => (typeof v === 'number' ? v : v && v.degrees + v.minutes / 60 + v.seconds / 3600);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const fmt = (v) => String(Math.round(v * 1000) / 1000);

  function rimType(rec) {
    const cap = rec.cartridge.caseHead, P1 = rec.cartridge.powderChamber.P1;
    if (rec.family === 'belted' || rec.family === 'rimfire') return rec.family;
    const ratio = cap.R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Bullet seating depth s and cylinder fraction k, from the shape and the category.
  function bulletRule(shape, pistol, G1) {
    if (shape === 'rounded') return pistol ? { s: 0.4 * G1, k: 0.65 } : { s: 0.8 * G1, k: 0.55 };
    if (shape === 'flat') return pistol ? { s: 0.4 * G1, k: 0.7 } : { s: 0.8 * G1, k: 0.6 };
    if (shape === 'semi_wadcutter') return { s: 0.6 * G1, k: 0.78 };
    return { s: G1, k: 0.4 };
  }

  // Nose points from (z1, D/2) to the tip (L6, m/2), and the meplat diameter m.
  function noseOf(shape, D, G1, z1, L6) {
    const n = L6 - z1, N = 24, nose = [];
    if (shape === 'pointy') {
      const m = Math.max(0.08 * G1, 1.27), a = D / 2 - m / 2;
      const rho = (a * a + n * n) / (2 * a), phiEnd = Math.atan2(n, rho - a);
      for (let i = 0; i <= N; i++) {
        const phi = (phiEnd * i) / N;
        nose.push([z1 + rho * Math.sin(phi), D / 2 - rho + rho * Math.cos(phi)]);
      }
      return { nose, m };
    }
    if (shape === 'rounded') {
      const m = 0.15 * G1, b = D / 2 - m / 2;
      for (let i = 0; i <= N; i++) {
        const th = (Math.PI / 2) * (i / N);
        nose.push([z1 + n * Math.sin(th), m / 2 + b * Math.cos(th)]);
      }
      return { nose, m };
    }
    const m = (shape === 'flat' ? 0.55 : 0.6) * G1;
    return { nose: [[z1, D / 2], [L6, m / 2]], m };
  }

  // Radius of the polyline at z: the largest r where it is vertical (a step), else interpolated.
  function radiusAt(pts, z) {
    let best = -Infinity;
    for (let i = 0; i + 1 < pts.length; i++) {
      const [z1, r1] = pts[i], [z2, r2] = pts[i + 1];
      if (Math.abs(z1 - z) < 1e-9 && Math.abs(z2 - z) < 1e-9) best = Math.max(best, r1, r2);
      else if (z2 !== z1 && z >= Math.min(z1, z2) && z <= Math.max(z1, z2)) {
        best = Math.max(best, r1 + ((z - z1) / (z2 - z1)) * (r2 - r1));
      }
    }
    return best;
  }

  function dedupe(pts) {
    const out = [];
    for (const p of pts) {
      const q = out[out.length - 1];
      if (!q || Math.abs(q[0] - p[0]) > 1e-9 || Math.abs(q[1] - p[1]) > 1e-9) out.push(p);
    }
    return out;
  }

  // Replace corner c (between a and b) by a circular arc of radius rad, tangent to both legs.
  function fillet(a, c, b, rad) {
    const ux = a[0] - c[0], uy = a[1] - c[1], vx = b[0] - c[0], vy = b[1] - c[1];
    const lu = Math.hypot(ux, uy), lv = Math.hypot(vx, vy);
    const theta = Math.acos(Math.max(-1, Math.min(1, (ux * vx + uy * vy) / (lu * lv))));
    let d = rad / Math.tan(theta / 2), r = rad;
    const maxD = 0.5 * Math.min(lu, lv);
    if (d > maxD) { d = maxD; r = d * Math.tan(theta / 2); }
    const t1 = [c[0] + (ux / lu) * d, c[1] + (uy / lu) * d];
    const t2 = [c[0] + (vx / lv) * d, c[1] + (vy / lv) * d];
    const bx = ux / lu + vx / lv, by = uy / lu + vy / lv, lb = Math.hypot(bx, by);
    const dist = r / Math.sin(theta / 2);
    const o = [c[0] + (bx / lb) * dist, c[1] + (by / lb) * dist];
    const a1 = Math.atan2(t1[1] - o[1], t1[0] - o[0]);
    let sweep = Math.atan2(t2[1] - o[1], t2[0] - o[0]) - a1;
    if (sweep > Math.PI) sweep -= 2 * Math.PI;
    if (sweep < -Math.PI) sweep += 2 * Math.PI;
    const out = [];
    for (let i = 0; i <= 8; i++) {
      const ang = a1 + (sweep * i) / 8;
      out.push([o[0] + r * Math.cos(ang), o[1] + r * Math.sin(ang)]);
    }
    return out;
  }

  // rOf(point) gives the fillet radius of that corner point, or undefined.
  function roundCorners(pts, rOf) {
    const out = [pts[0]];
    for (let i = 1; i < pts.length - 1; i++) {
      const r = rOf(pts[i]);
      if (r) out.push(...fillet(pts[i - 1], pts[i], pts[i + 1], r));
      else out.push(pts[i]);
    }
    out.push(pts[pts.length - 1]);
    return out;
  }

  // Liang-Barsky: does segment [x1,y1,x2,y2] touch the box (grown by pad)?
  function segmentHitsBox(seg, box, pad) {
    const [x1, y1, x2, y2] = seg;
    const xmin = box.x - pad, xmax = box.x + box.w + pad, ymin = box.y - pad, ymax = box.y + box.h + pad;
    const dx = x2 - x1, dy = y2 - y1;
    const p = [-dx, dx, -dy, dy], q = [x1 - xmin, xmax - x1, y1 - ymin, ymax - y1];
    let t0 = 0, t1 = 1;
    for (let i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; continue; }
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; t0 = Math.max(t0, t); }
      else { if (t < t0) return false; t1 = Math.min(t1, t); }
    }
    return true;
  }

  const orient = (p, q, r) => Math.sign((q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]));
  const segmentsCrossSeg = (s, t) => {
    const a = [s[0], s[1]], b = [s[2], s[3]], c = [t[0], t[1]], d = [t[2], t[3]];
    return orient(a, b, c) * orient(a, b, d) < 0 && orient(c, d, a) * orient(c, d, b) < 0;
  };

  const boxesOverlap = (a, b, pad) =>
    a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;

  function polySegments(poly) {
    const out = [];
    for (let i = 0; i + 1 < poly.length; i++) out.push([poly[i][0], poly[i][1], poly[i + 1][0], poly[i + 1][1]]);
    return out;
  }

  const pathOf = (poly, close) =>
    'M' + poly.map((p) => `${fmt(p[0])} ${fmt(p[1])}`).join('L') + (close ? 'Z' : '');
  const triangle = (a, b, c) => [a, b, c];

  function buildDrawing(rec) {
    const c = rec.cartridge, ann = rec.annotations;
    const cap = c.caseHead, col = c.collar, jc = c.junctionCone || {}, L = c.lengths, pc = c.powderChamber, pr = c.projectile;
    const notes = [];
    const R = cap.R, R1 = cap.R1, P1 = pc.P1, H2 = col.H2, G1 = pr.G1, L3 = L.L3, L6 = L.L6;

    const absent = [['R', R], ['R1', R1], ['P1', P1], ['H2', H2], ['G1', G1], ['L3', L3], ['L6', L6]]
      .filter(([, v]) => v === undefined).map(([s]) => s);
    if (absent.length) {
      return { svg: null, notes: [`${absent.join(', ')} not published: no drawing`], labels: [], segments: [], viewBox: null, model: null };
    }

    const rim = rimType(rec), rimfire = rim === 'rimfire', belted = rim === 'belted', pistol = ann.category === 'pistol';
    const cornerR = new Map();   // corner point (by reference) -> fillet radius
    const pts = [[0, 0]];

    // Head face and rim edge.
    if (rimfire) {
      const rho = Math.min(R / 2, (R1 - P1) / 2), rc = R1 / 2 - rho;
      pts.push([0, rc]);
      for (let i = 0; i <= 12; i++) {
        const a = Math.PI - (Math.PI * i) / 12;
        pts.push([R / 2 + rho * Math.cos(a), rc + rho * Math.sin(a)]);
      }
      pts.push([R, rc]);
    } else {
      const beta = angleDeg(cap.beta), f = cap.f;
      if (beta !== undefined && f !== undefined && beta < 90) {
        const ch = Math.min(f * Math.tan(deg(beta)), R1 / 4);
        pts.push([0, R1 / 2 - ch], [f, R1 / 2]);
      } else {
        pts.push([0, R1 / 2]);
      }
      pts.push([R, R1 / 2]);
    }

    // Extractor groove, or the belt on belted cases, or a step in to the powder chamber.
    const E = cap.E, E1 = cap.E1, eMin = cap.eMin;
    const grooved = E !== undefined && E1 !== undefined && eMin !== undefined;
    if (!grooved && (E !== undefined || E1 !== undefined || eMin !== undefined)) {
      const missing = [['E', E], ['E1', E1], ['e min', eMin]].filter(([, v]) => v === undefined).map(([s]) => s);
      notes.push(`${missing.join(', ')} not published: no extractor groove drawn`);
    }
    let bodyStart = R, beltEnd;
    if (grooved) {
      pts.push([R, E1 / 2], [R + eMin, E1 / 2]);
      if (belted) {
        const R3 = cap.R3, delta = angleDeg(cap.delta);
        if (R3 !== undefined && delta !== undefined) {
          beltEnd = R + eMin + (R3 / 2 - E1 / 2) / Math.tan(deg(delta));
          pts.push([beltEnd, R3 / 2], [E, R3 / 2]);
        } else {
          const missing = [['R3', R3], ['delta', delta]].filter(([, v]) => v === undefined).map(([s]) => s);
          notes.push(`${missing.join(', ')} not published: belt not drawn`);
        }
      }
      pts.push([E, P1 / 2]);
      bodyStart = E;
    } else {
      pts.push([R, P1 / 2]);
    }

    // Body, shoulder and neck. A case without alpha, L1 or L2 is straight.
    const L1 = L.L1, L2 = L.L2, P2 = pc.P2, H1 = col.H1, alpha = angleDeg(jc.alpha);
    let shoulder = alpha !== undefined && L1 !== undefined && L2 !== undefined;
    if (shoulder && (P2 === undefined || H1 === undefined)) {
      const missing = [['P2', P2], ['H1', H1]].filter(([, v]) => v === undefined).map(([s]) => s);
      notes.push(`${missing.join(', ')} not published: case drawn straight`);
      shoulder = false;
    }
    if (shoulder) {
      const p1 = [L1, P2 / 2], p2 = [L2, H1 / 2];
      pts.push(p1, p2);
      cornerR.set(p1, jc.r1Min);
      cornerR.set(p2, jc.r2);
      if (jc.r1Min === undefined) notes.push('cartridge r1 min not published: shoulder corner not rounded');
      if (jc.r2 === undefined) notes.push('cartridge r2 not published: neck corner not rounded');
    }
    pts.push([L3, H2 / 2]);
    const caseLine = dedupe(roundCorners(dedupe(pts), (p) => cornerR.get(p)));

    // Bullet: exposed diameter D (a heeled bullet takes the case outside diameter).
    const heeled = H2 - G1 <= 0.015;
    const D = heeled ? H2 : G1;
    let shape = ann.defaultBulletShape;
    if (!SHAPES.includes(shape)) {
      notes.push(`defaultBulletShape ${shape ?? 'not published'}: bullet drawn pointy`);
      shape = 'pointy';
    }
    const rule = bulletRule(shape, pistol, G1);
    const zb = L3 - rule.s, Lb = L6 - zb, z1 = zb + rule.k * Lb;
    const { nose, m } = noseOf(shape, D, G1, z1, L6);
    const exposed = dedupe([[L3, D / 2], ...nose, [L6, 0]]);

    // Section walls.
    const tn = (H2 - G1) / 2, tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * P1) / 2);
    const rSeat = heeled ? (H2 - 2 * tb) / 2 : G1 / 2;
    // A straight, non-heeled case has no neck: its mouth wall is tn, so the seated bullet (G1/2) fits inside.
    // The brief does not define this case; the wall tapers linearly from tb at the body start to tn at the mouth.
    const wallT = (z) => {
      if (!shoulder && !heeled) return tb + ((tn - tb) * (z - bodyStart)) / (L3 - bodyStart);
      if (!shoulder || z <= L1) return tb;
      if (z >= L2) return tn;
      return tb + ((tn - tb) * (z - L1)) / (L2 - L1);
    };

    // Primer pocket and solid head.
    const pocket = rimfire ? null : PRIMER_POCKET[ann.primerType] || null;
    if (!rimfire && !pocket) notes.push(`primerType ${ann.primerType ?? 'not published'}: no primer pocket drawn`);
    let w = Math.max(2.5, (0.25 * P1) / 2, pocket ? pocket.depth + 1.5 : 0);
    if (belted && beltEnd !== undefined) w = Math.max(w, beltEnd + tb);
    else if (grooved) w = Math.max(w, E + tb);

    const profile = dedupe([...caseLine, ...exposed]);
    const rOut = (z) => radiusAt(caseLine, z);
    const head = dedupe([[0, 0], ...caseLine.filter((p) => p[0] < w), [w, rOut(w)], [w, 0]]);
    const pocketPoly = pocket ? [[0, 0], [pocket.depth, 0], [pocket.depth, pocket.d / 2], [0, pocket.d / 2]] : null;
    const innerLine = [[w, rOut(w) - wallT(w)], ...caseLine.filter((p) => p[0] > w).map((p) => [p[0], p[1] - wallT(p[0])])];
    const wall = dedupe([[w, rOut(w)], ...caseLine.filter((p) => p[0] > w), ...innerLine.slice().reverse()]);
    const bullet = dedupe([[zb, 0], [zb, rSeat], [L3, rSeat], ...exposed]);

    // Dimensions. Lines are obstacles for label placement.
    const rMax = Math.max(...profile.map((p) => p[1]));
    const tierY = (i) => -(rMax + 3 + 6 * i);
    const lines = [];
    const arrows = [];
    const dimArrowPair = (x1, y1, x2, y2, a) => {
      const ux = Math.sign(x2 - x1) || 1;
      arrows.push(triangle([x1, y1], [x1 + ux * a, y1 - 0.4], [x1 + ux * a, y1 + 0.4]));
      arrows.push(triangle([x2, y2], [x2 - ux * a, y2 - 0.4], [x2 - ux * a, y2 + 0.4]));
    };

    const hdims = [{ field: 'R', obj: cap, z: R }];
    if (L1 !== undefined) hdims.push({ field: 'L1', obj: L, z: L1 });
    if (L2 !== undefined) hdims.push({ field: 'L2', obj: L, z: L2 });
    hdims.push({ field: 'L3', obj: L, z: L3 }, { field: 'L6', obj: L, z: L6 });
    hdims.sort((a, b) => a.z - b.z);
    hdims.forEach((d, i) => {
      const y = tierY(i), a = Math.min(1.2, d.z / 3);
      lines.push([0, y, d.z, y], [d.z, -radiusAt(profile, d.z) - 0.8, d.z, y - 0.8], [0, -radiusAt(profile, 0) - 0.8, 0, y - 0.8]);
      dimArrowPair(0, y, d.z, y, a);
    });

    // R1 is dimensioned left of the head face, with extension lines; the others sit on their feature.
    const ddims = [{ field: 'R1', obj: cap, zf: -4, rad: R1 / 2, ext: true }, { field: 'P1', obj: pc, zf: bodyStart, rad: P1 / 2 }];
    if (grooved) ddims.push({ field: 'E1', obj: cap, zf: R + eMin / 2, rad: E1 / 2 });
    if (shoulder) ddims.push({ field: 'P2', obj: pc, zf: L1, rad: P2 / 2 }, { field: 'H1', obj: col, zf: L2, rad: H1 / 2 });
    ddims.push({ field: 'H2', obj: col, zf: L3, rad: H2 / 2 }, { field: 'G1', obj: pr, zf: (L3 + z1) / 2, rad: D / 2 });
    for (const d of ddims) {
      lines.push([d.zf, -d.rad, d.zf, d.rad]);
      if (d.ext) lines.push([0, -d.rad, d.zf - 0.8, -d.rad], [0, d.rad, d.zf - 0.8, d.rad]);
      arrows.push(triangle([d.zf, -d.rad], [d.zf - 0.4, -d.rad + 1.2], [d.zf + 0.4, -d.rad + 1.2]));
      arrows.push(triangle([d.zf, d.rad], [d.zf - 0.4, d.rad - 1.2], [d.zf + 0.4, d.rad - 1.2]));
    }

    const outlineSegs = [...polySegments(profile.map((p) => [p[0], -p[1]])), ...polySegments(profile)];
    const obstacles = [...outlineSegs, ...lines];
    // Candidate boxes for every label, nearest to its dimension first.
    const items = [];
    hdims.forEach((d, i) => {
      const y = tierY(i), z = d.z;
      const text = `${M.symbol(d.field)} ${M.valueWithTolerance(d.obj, d.field)}`;
      const w = text.length * CHAR_W;
      items.push({ text, w, cands: [
        { x: z / 2 - w / 2, y: y - 1 - CAP, cost: 0 },
        { x: -0.8 - w, y: y - 1 - CAP, cost: 1 },
        { x: z + 0.8, y: y - CAP / 2, cost: 2 },
      ] });
    });
    for (const d of ddims) {
      const text = `${M.symbol(d.field)} ${M.valueWithTolerance(d.obj, d.field)}`;
      const w = text.length * CHAR_W, cands = [];
      for (const side of [1, -1]) {
        const tip = [d.zf, side * d.rad];
        for (let k = 0; k < 12; k++) {
          const y = side > 0 ? d.rad + 1 + k * 4.2 : -d.rad - 1 - CAP - k * 4.2;
          for (const x of [d.zf + 0.8, d.zf - 0.8 - w]) {
            // nearest point of the label box to the arrow tip
            const nx = Math.min(Math.max(tip[0], x), x + w), ny = Math.min(Math.max(tip[1], y), y + CAP);
            const cost = Math.hypot(nx - tip[0], ny - tip[1]);
            // labels above the outline share the space with the length dimensions, so they come last
            cands.push({ x, y, cost: side > 0 ? cost : cost + 8, leader: cost > 1.5 ? { from: tip, to: [nx, ny] } : null });
          }
        }
      }
      cands.sort((a, b) => a.cost - b.cost);
      items.push({ text, w, cands });
    }
    if (shoulder && alpha !== undefined) {
      const text = `${M.symbol('alpha')} ${M.formatValue(jc.alpha, 'alpha')}`;
      const w = text.length * CHAR_W, zm = (L1 + L2) / 2, rb = P2 / 2 + 1.2;
      const cands = [];
      for (let k = 0; k < 4; k++) {
        cands.push({ x: zm - w / 2, y: rb + k * 4.2, cost: 0.5 + k }, { x: zm - w / 2, y: -rb - CAP - k * 4.2, cost: 8.5 + k });
      }
      items.push({ text, w, cands });
    }

    // Depth-first search: every label takes a clear box (no other label, leader line, outline or
    // dimension line in the way). Falls back to first-fit if no full arrangement is found in time.
    const placed = [];
    const leaderSegs = [];   // placed leader lines; labels must not cross them
    const fits = (w, cand) => {
      const box = { x: cand.x, y: cand.y, w, h: CAP };
      if (placed.some((q) => boxesOverlap(q, box, 0.3))) return false;
      if (obstacles.some((s) => segmentHitsBox(s, box, 0.3))) return false;
      if (leaderSegs.some((s) => segmentHitsBox(s, box, 0.3))) return false;
      if (!cand.leader) return true;
      const seg = [...cand.leader.from, ...cand.leader.to];
      return !placed.some((q) => segmentHitsBox(seg, q, 0.3)) && !leaderSegs.some((s) => segmentsCrossSeg(s, seg));
    };
    const commit = (item, cand) => {
      const box = { text: item.text, x: cand.x, y: cand.y, w: item.w, h: CAP, leader: cand.leader || null };
      placed.push(box);
      if (cand.leader) leaderSegs.push([...cand.leader.from, ...cand.leader.to]);
      return box;
    };
    const uncommit = (cand) => {
      placed.pop();
      if (cand.leader) leaderSegs.pop();
    };
    // Branch and bound on the total candidate cost, within a step budget.
    const chosen = [];
    let steps = 0, best = null, bestCost = Infinity;
    const search = (i, cost) => {
      if (i === items.length) {
        bestCost = cost;
        best = chosen.slice();
        return;
      }
      for (const cand of items[i].cands) {
        if (cost + cand.cost >= bestCost || ++steps > 100000) break;
        if (!fits(items[i].w, cand)) continue;
        chosen[i] = commit(items[i], cand);
        search(i + 1, cost + cand.cost);
        uncommit(cand);
      }
    };
    search(0, 0);
    if (best) {
      chosen.splice(0, chosen.length, ...best);
    } else {
      placed.length = 0;
      leaderSegs.length = 0;
      items.forEach((item, i) => {
        const cand = item.cands.find((c) => fits(item.w, c)) || item.cands[0];
        chosen[i] = commit(item, cand);
      });
    }
    const labels = chosen;

    // Viewbox and title block below everything.
    const xMin = Math.min(-1, ...labels.map((b) => b.x)) - 1;
    const xMax = Math.max(L6 + 1, ...labels.map((b) => b.x + b.w)) + 1;
    const yTop = Math.min(-rMax, ...labels.map((b) => b.y)) - 1;
    const yBot = Math.max(rMax, ...labels.map((b) => b.y + b.h));
    const tbX = xMin + 1, tbY = yBot + 3;
    const viewBox = [xMin, yTop, Math.max(xMax, tbX + TB_W + 1) - xMin, tbY + TB_H + 1 - yTop];

    const svg = [];
    const hatch = `hatch-${rec.key}`;
    // One screen scale for every cartridge (PX_PER_MM), so label size is the same from drawing to drawing.
    svg.push(`<svg xmlns="http://www.w3.org/2000/svg" class="drawing" style="width:${fmt(viewBox[2] * PX_PER_MM)}px" viewBox="${viewBox.map(fmt).join(' ')}" role="img" aria-label="${esc(rec.name)} drawing">`);
    svg.push(`<defs><pattern id="${hatch}" width="1.2" height="1.2" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="1.2"/></pattern></defs>`);
    svg.push(`<path class="axis" d="M${fmt(xMin)} 0L${fmt(Math.max(xMax, tbX + TB_W))} 0"/>`);
    svg.push(`<path class="outline" d="${pathOf(profile.map((p) => [p[0], -p[1]]), false)}${pathOf(profile, false)}"/>`);
    const cut = [pathOf(head, true)];
    if (pocketPoly) cut.push(pathOf(pocketPoly, true));
    cut.push(pathOf(wall, true), pathOf(bullet, true));
    svg.push(`<path class="cut" fill="url(#${hatch})" d="${cut.join('')}"/>`);
    svg.push(`<path class="dim" d="${lines.map(([x1, y1, x2, y2]) => `M${fmt(x1)} ${fmt(y1)}L${fmt(x2)} ${fmt(y2)}`).join('')}"/>`);
    svg.push(`<path class="dim-arrow" d="${arrows.map((t) => pathOf(t, true)).join('')}"/>`);
    const leaders = labels.filter((b) => b.leader).map((b) => {
      const to = b.leader.to;
      return `M${fmt(b.leader.from[0])} ${fmt(b.leader.from[1])}L${fmt(to[0])} ${fmt(to[1])}`;
    });
    if (leaders.length) svg.push(`<path class="leader" d="${leaders.join('')}"/>`);
    for (const b of labels) {
      svg.push(`<text class="dim-label" x="${fmt(b.x)}" y="${fmt(b.y + CAP)}" font-size="${FONT}">${esc(b.text)}</text>`);
    }
    const titleBlock = [
      `<g class="titleblock"><rect x="${fmt(tbX)}" y="${fmt(tbY)}" width="${TB_W}" height="${TB_H}"/>`,
      `<text class="tb-name" x="${fmt(tbX + 2)}" y="${fmt(tbY + 6)}" font-size="4.4">${esc(rec.name)}</text>`,
      `<text x="${fmt(tbX + 2)}" y="${fmt(tbY + 10.5)}" font-size="3">C.I.P. table ${esc(rec.tab)}</text>`,
      `<text x="${fmt(tbX + 2)}" y="${fmt(tbY + 14.5)}" font-size="3">Revised ${esc(rec.revised)}</text>`,
      `<text x="${fmt(tbX + 2)}" y="${fmt(tbY + 18.5)}" font-size="3">Dimensions in mm</text>`,
      `<text x="${fmt(tbX + 36)}" y="${fmt(tbY + 10.5)}" font-size="3">Scale</text>`,
      `<rect class="scalebar" x="${fmt(tbX + 36)}" y="${fmt(tbY + 13.5)}" width="10" height="1"/>`,
      `<text x="${fmt(tbX + 47)}" y="${fmt(tbY + 14.6)}" font-size="3">10 mm</text></g>`,
    ];
    svg.push(...titleBlock, '</svg>');

    const segments = outlineSegs;
    return {
      svg: svg.join(''),
      notes,
      labels: labels.map(({ text, x, y, w, h }) => ({ text, x, y, w, h })),
      segments,
      viewBox,
      model: {
        rim, groove: grooved, shoulder, profile, beltEnd: beltEnd ?? null,
        bullet: { shape, s: rule.s, k: rule.k, zb, z1, Lb, m, D, rSeat, heeled },
        walls: { tn, tb, w, mouth: H2 / 2 - wallT(L3) },
        pocket: pocket ? { d: pocket.d, depth: pocket.depth } : null,
        labelSearch: { solved: best !== null, steps, cost: bestCost },
      },
    };
  }

  return { buildDrawing, rimType };
});
