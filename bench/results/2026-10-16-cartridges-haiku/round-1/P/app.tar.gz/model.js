// Pure logic for the cartridge reference: how values, symbols, units and sections are shown,
// and how the list is searched, filtered, sorted and routed.
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CIP = Object.assign(root.CIP || {}, api);
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  const ANGLE_FIELDS = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β',
    delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²' };
  const SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };
  const GROUPS = [['cartridge', 'Cartridge'], ['chamber', 'Chamber']];

  const pad2 = (n) => String(n).padStart(2, '0');

  function formatAngle(a) {
    if (typeof a === 'number') return `${a}°`;
    return `${a.degrees}°${pad2(a.minutes)}'${pad2(a.seconds)}"`;
  }

  function formatValue(v, field) {
    return field && ANGLE_FIELDS.has(field) ? formatAngle(v) : String(v);
  }

  // The tolerance `<field>Tol` sits next to its value and is never a row of its own.
  function valueWithTolerance(obj, field) {
    const text = formatValue(obj[field], field);
    const tol = obj[`${field}Tol`];
    return tol === undefined ? text : `${text} ${tol}`;
  }

  function symbol(field) {
    return SYMBOLS[field] || field;
  }

  function unitOf(field) {
    if (ANGLE_FIELDS.has(field) || field === 'N') return '—';
    return UNITS[field] || 'mm';
  }

  function sectionsOf(record) {
    return GROUPS.map(([group, title]) => ({
      title,
      sections: Object.entries(record[group])
        .map(([key, obj]) => ({
          key,
          title: SECTION_TITLES[key] || key,
          rows: Object.keys(obj)
            .filter((field) => !field.endsWith('Tol'))
            .map((field) => ({
              field,
              symbol: symbol(field),
              value: valueWithTolerance(obj, field),
              unit: unitOf(field),
            })),
        }))
        .filter((section) => section.rows.length > 0),
    }));
  }

  // Case and whitespace are ignored, so "7,62 x 51" and "7,62x51" both match.
  const squash = (s) => String(s).toLowerCase().replace(/\s+/g, '');

  function filterRecords(records, query, family) {
    const q = squash(query || '');
    return records.filter((r) =>
      (family === 'all' || r.family === family) &&
      (q === '' || [r.name, ...(r.alternativeNames || [])].some((n) => squash(n).includes(q))));
  }

  const collator = new Intl.Collator('en', { numeric: true, sensitivity: 'base' });
  const sortByName = (records) => records.slice().sort((a, b) => collator.compare(a.name, b.name));

  const countText = (n) => (n === 1 ? '1 cartridge' : `${n} cartridges`);

  function parseRoute(hash) {
    const m = /^#\/cartridge\/([^/]+)$/.exec(hash || '');
    if (!m) return { view: 'list' };
    try {
      return { view: 'cartridge', key: decodeURIComponent(m[1]) };
    } catch (e) {
      return { view: 'cartridge', key: m[1] };
    }
  }

  return {
    formatValue, valueWithTolerance, symbol, unitOf, sectionsOf,
    filterRecords, sortByName, countText, parseRoute,
  };
});
