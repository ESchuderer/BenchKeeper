# Implementation Plan: Cartridge Reference

**Spec**: [spec.md](spec.md) | **Constitution**: [../../.specify/memory/constitution.md](../../.specify/memory/constitution.md)

## Technical Context

Plain HTML, CSS and classic JavaScript. No framework, no build, no runtime dependencies, no network. Tests use Node's built-in `node:test` (`npm test`), so `package.json` has no dependencies.

Classic scripts are used because Chromium blocks ES module scripts and `fetch` on `file://`. The data is embedded as a JSON Lines string in `data.js`.

## Files

| File | Role |
|------|------|
| `index.html` | Shell: header, main region, script and style links |
| `styles.css` | Theme variables, list, detail, tables, print rules |
| `data.js` | The 25 records as JSON Lines, verbatim, parsed into `records` |
| `model.js` | Pure logic: value and tolerance formatting, symbols, units, sections, search, family filter, route parsing |
| `drawing.js` | Pure logic: geometry from record values, label placement, SVG string |
| `app.js` | DOM: list view, search and filter, detail view, print button, hash routing |
| `tests/*.test.js` | `node:test` suites for model, data, drawing |

Each logic file is a UMD-style module: `module.exports` under Node, `window.CIP` in the browser.

## Key Decisions

- **Hash routing** (`#/cartridge/<key>`): works on `file://` and survives reload.
- **Sort**: list sorted by name with a numeric collator; the data order is not meaningful.
- **Drawing coordinates**: `x = z`, the axis is `y = 0`, the outside view is `y = -r`, the section is `y = +r`. Arcs are sampled to polylines, so every outline is one list of points that the label check can test.
- **Label placement**: each label has candidate boxes. The first candidate that touches no outline segment, dimension line or placed label wins. A displaced diameter label gets a leader line. Tests assert no overlaps for all 25 records.
- **Missing values**: a rule that needs a missing value skips that feature and adds a note, shown under the drawing.
- **Print**: one A4 page. Tables use two columns and a smaller font; the drawing is capped in height so the page holds.

## Constitution Check

- I (static, offline): classic scripts, embedded data, no fetch. ✔
- II (data fidelity): `data.js` holds the brief's lines verbatim; no field is derived into the record. ✔
- III (test first): suites written before the modules they cover. ✔
- IV (reading surface): tabular numerals, theme variables, print stylesheet. ✔
- V (simplicity): three logic files and one DOM file; no framework. ✔
