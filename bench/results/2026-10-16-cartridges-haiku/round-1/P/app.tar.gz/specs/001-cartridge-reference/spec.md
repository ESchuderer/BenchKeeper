# Feature Specification: Cartridge Reference

**Created**: 2026-10-16
**Status**: Draft
**Source**: the project brief (C.I.P. cartridge reference modelled on OpenBallistics)

## User Scenarios & Testing

### User Story 1 - Find a cartridge (Priority: P1)

A reloader, gunsmith or engineer opens the page and sees all 25 cartridges with name, family and case length L3. They type part of a name or an alternative name and the list narrows; they pick a family from a select to narrow it further.

**Independent Test**: type `7,62 x 51` in Search; "308 Win." is the only result. Choose family "pistol"; only pistol cartridges remain. The count text matches the list.

**Acceptance Scenarios**:
1. **Given** the start page, **When** it loads, **Then** the heading "Cartridges" and 25 name links are shown, each with family and L3.
2. **Given** an empty Search, **When** the user types `7,62 x 51`, **Then** only "308 Win." is listed and the text reads "1 cartridge".
3. **Given** the Family select set to "rimfire", **Then** only the three rimfire cartridges are listed.

### User Story 2 - Read a cartridge's data (Priority: P2)

The user opens a cartridge. The detail view gives its identity and publication facts, then every cartridge value and chamber value in tables grouped by section, with a Symbol, Value and Unit column. Tolerances sit next to their value.

**Independent Test**: open `#/cartridge/308_win`; reload; the same view appears. Every field of the record appears once, except `XTol` fields, which appear beside `X`.

### User Story 3 - See the drawing (Priority: P2)

Each detail view has an inline SVG drawing at true scale (1 unit = 1 mm): the outside view above the axis and a section with hatched walls below it, with dimension lines and labels, a title block, and a scale bar. Labels never overlap each other or the outline.

**Independent Test**: for every record, the drawing builds, labels do not overlap each other or the outline, and missing values are named in a note rather than invented.

### User Story 4 - Print a cartridge (Priority: P3)

"Print" opens the browser print dialog. The printed page is one A4 portrait page, black on white: header with the name, the drawing, the tables, and a footer with the source (C.I.P. TDCC and the revised date). No navigation, search or buttons appear.

**Independent Test**: print preview of any detail view shows one page with no buttons or navigation.

## Requirements

- **FR-001** Records are exactly the 25 supplied; no field is added, changed or fetched.
- **FR-002** Values show as published: decimal point, no thousands separator. Angles show as `40°` or `39°59'49"`.
- **FR-003** Symbols follow the brief (`eMin` "e min", `alpha` "α", `L3PlusG` "L3 + G", and so on).
- **FR-004** Units: mm for lengths and diameters (also for fields the brief does not name, such as `u`, `S`, `s`, `h`, `b`, `G`), bar for `Pmax`, `PK`, `PE`, J for `EE`, g for `M`, mm² for `Q`, none for `N`.
- **FR-005** Hash addresses: `#/` is the list, `#/cartridge/<key>` is a detail view. Both survive reload and bookmarking.
- **FR-006** Works from `file://` in Chromium and from any static server; no network requests.
- **FR-007** Light and dark on screen following the system setting; print always light.
- **FR-008** Drawing rules: rim type, head and rim, extractor groove, body, shoulder, neck, bullet (seating, cylinder, nose, heeled case), section walls, solid head, primer pocket, and missing-value notes, as in the brief.

## Success Criteria

- **SC-001** All tests in `tests/` pass with `npm test`, which needs no installed packages.
- **SC-002** All 25 drawings build; no label overlaps another label or the outline.
- **SC-003** The printed detail view fits one A4 portrait page for the longest record.

## Decisions and Deviations

Where the brief is silent or cannot be met as written:

- **Units of unlisted fields**: `u` (groove twist), `S`, `s`, `h`, `b`, `G`, `F`, `Z`, `Fe`, `deltaL`, `R3`, `r`, `L4`, `L5` are shown in mm, because the brief lists only the other units. `u` as a twist pitch matches the values (305 mm = 1 in 12 in).
- **Water capacity** is shown as `<value> gr H2O` (grains of water). The brief names no unit; the unit comes from the field name.
- **Angles** show as the value text (`40°`, `39°59'49"`); the Unit column shows `—`. Minutes and seconds are padded to two digits.
- **Sort order**: the list is sorted by name (numeric collation), not in data order.
- **Count text**: "1 cartridge" for one, "<n> cartridges" otherwise.
- **Extension lines**: drawn for L1, L2, L3, L6, R and R1. **Gap**: the brief asks for an extension line on P1 too; none is drawn, because a horizontal extension from the body start would cross the rim, which is wider. Other diameters (P2, H1, H2, G1, E1) sit on their feature, with the feature's outline as the extension, as the brief does not ask for more.
- **Gap, shoulder angle α**: the brief asks for a dimension line with arrowheads and extension lines. It is drawn as a label beside the shoulder with its value, not as a dimension, because the cone apex lies beyond the case mouth.
- **Straight cases, mouth wall**: the brief defines no wall for a case without a neck. A straight, non-heeled case tapers its wall linearly from tb at the body start to tn at the mouth, so the seated bullet (G1/2) fits inside. Heeled cases keep tb, as the heel rule requires.
- **Label placement** is a branch-and-bound search over candidate positions, preferring short distances from each label to its dimension. It stops after a step budget, so the result is a good arrangement, not a proven minimum (the budget is reached for about half the records). Labels avoid each other, the outline, dimension lines and leader lines. Label widths use 0.62 em per character, an over-estimate.
- **Print**: one A4 page. The drawing is at full width but capped at 100 mm high so the tables fit; the tables flow into three columns.
- **Screen scale**: every drawing is shown at 4.2 px per mm (shrinking to the container width), so labels keep one size across cartridges. The title block shows a 10 mm scale bar rather than a ratio, because the displayed size varies.
- **Not shown**: `confidence`, `implausible` and `defaultBullet` annotations (not in the brief's list).
