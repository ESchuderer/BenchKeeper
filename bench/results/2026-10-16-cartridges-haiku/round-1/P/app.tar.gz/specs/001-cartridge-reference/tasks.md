# Tasks: Cartridge Reference

Tests come before the code they cover (constitution III). `[P]` marks tasks that touch separate files.

- [x] T001 Project scaffold: `package.json` (`npm test` runs `node --test`), `.gitignore` not needed
- [x] T002 `data.js`: the 25 records as JSON Lines, verbatim
- [x] T003 [P] `tests/data.test.js`: 25 records parse, keys unique, spot values match the brief
- [x] T004 [P] `tests/model.test.js`: value, angle, tolerance, symbol, unit, section, search, family, route rules
- [x] T005 [P] `tests/drawing.test.js`: all 25 build; rim, groove, shoulder, bullet, walls, pocket rules; labels never overlap; notes for missing values
- [x] T006 `model.js` to satisfy T004
- [x] T007 `drawing.js` to satisfy T005
- [x] T008 `index.html`, `styles.css`: list, detail, drawing frame, theme, print sheet
- [x] T009 `app.js`: list, search, family filter, count text, hash routing, detail, print button
- [ ] T010 Browser verification from `file://` (headless Chromium in a temp folder, outside the project): detail view, drawings (all 25 on contact sheets), dark theme, phone width, print fit (measured, one A4 page). The list view's `<select>` could not be rendered in the sandbox's Chromium (it crashes the renderer on any visible select, with or without app.js), so the list was checked by unit tests only
- [ ] T011 Independent review against the brief's rules and the spec
