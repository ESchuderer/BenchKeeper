'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { records } = require('../data.js');

const byKey = (key) => records.find((r) => r.key === key);

test('there are exactly 25 records with unique keys and names', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
  assert.equal(new Set(records.map((r) => r.name)).size, 25);
});

test('every record has the blocks the app reads', () => {
  for (const r of records) {
    assert.ok(r.cartridge && r.chamber && r.annotations, r.key);
    assert.ok(['rifle', 'pistol', 'rimfire'].includes(r.annotations.category), r.key);
  }
});

test('published values are used as given (spot checks against the brief)', () => {
  const c308 = byKey('308_win');
  assert.equal(c308.name, '308 Win.');
  assert.deepEqual(c308.alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(c308.cartridge.lengths.L3, 51.18);
  assert.equal(c308.cartridge.lengths.L1Tol, -0.2);
  assert.equal(byKey('223_rem').cartridge.junctionCone.alpha, 46.0);
  assert.deepEqual(byKey('6_5_x_55_se').cartridge.junctionCone.alpha, { degrees: 50, minutes: 35, seconds: 2 });
  assert.equal(byKey('22_long_rifle').cartridge.projectile.G1, 5.72);
  assert.equal(byKey('9_mm_luger').cartridge.lengths.L6, 29.69);
  assert.equal(byKey('300_win_mag').cartridge.caseHead.R3, 13.51);
});
