'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { records } = require('../data.js');
const { buildDrawing, rimType } = require('../drawing.js');

const byKey = (key) => records.find((r) => r.key === key);
const clone = (r) => JSON.parse(JSON.stringify(r));
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) < eps, `${a} != ${b}`);

function overlaps(a, b) {
  return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
}

// Liang-Barsky: does the segment touch the rectangle (grown by pad)?
function segmentHitsRect(seg, rect, pad = 0.2) {
  const [x1, y1, x2, y2] = seg;
  const xmin = rect.x - pad, xmax = rect.x + rect.w + pad, ymin = rect.y - pad, ymax = rect.y + rect.h + pad;
  const dx = x2 - x1, dy = y2 - y1;
  const p = [-dx, dx, -dy, dy], q = [x1 - xmin, xmax - x1, y1 - ymin, ymax - y1];
  let t0 = 0, t1 = 1;
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) {
      if (q[i] < 0) return false;
    } else {
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; t0 = Math.max(t0, t); }
      else { if (t < t0) return false; t1 = Math.min(t1, t); }
    }
  }
  return true;
}

test('rim type follows the family and the R1/P1 ratio', () => {
  assert.equal(rimType(byKey('223_rem')), 'rimless');
  assert.equal(rimType(byKey('300_win_mag')), 'belted');
  assert.equal(rimType(byKey('22_long_rifle')), 'rimfire');
  assert.equal(rimType(byKey('9_mm_luger')), 'rimless');
  assert.equal(rimType(byKey('7_x_65_r')), 'rimmed');
  const synthetic = clone(byKey('223_rem'));
  synthetic.cartridge.caseHead.R1 = 9.3; // 9.3 / 9.58 = 0.97, below 0.98
  assert.equal(rimType(synthetic), 'rebated');
});

test('all 25 drawings build as SVG with the accessible name', () => {
  for (const r of records) {
    const d = buildDrawing(r);
    assert.ok(d.svg && d.svg.startsWith('<svg'), r.key);
    assert.ok(d.svg.includes(`aria-label="${r.name.replace(/&/g, '&amp;')} drawing"`), r.key);
    assert.ok(!/NaN|undefined|Infinity/.test(d.svg), r.key);
    assert.ok(Array.isArray(d.notes), r.key);
  }
});

test('the label search finds a clear arrangement for every drawing', () => {
  for (const r of records) assert.equal(buildDrawing(r).model.labelSearch.solved, true, r.key);
});

test('the outside profile runs along the axis from the head face to the mouth', () => {
  for (const r of records) {
    const p = buildDrawing(r).model.profile;
    assert.equal(p[0][0], 0, r.key);
    for (let i = 1; i < p.length; i++) assert.ok(p[i][0] >= p[i - 1][0] - 1e-9, `${r.key} z at ${i}`);
    assert.ok(p.every(([z, rad]) => rad >= -1e-9 && Number.isFinite(z)), r.key);
  }
});

test('labels never overlap each other, the outline, or leave the drawing', () => {
  for (const r of records) {
    const d = buildDrawing(r);
    const [vx, vy, vw, vh] = d.viewBox;
    d.labels.forEach((a, i) => {
      assert.ok(a.x >= vx && a.y >= vy && a.x + a.w <= vx + vw && a.y + a.h <= vy + vh, `${r.key} ${a.text} outside`);
      d.labels.forEach((b, j) => {
        if (i < j) assert.ok(!overlaps(a, b), `${r.key}: "${a.text}" overlaps "${b.text}"`);
      });
      d.segments.forEach((seg) => assert.ok(!segmentHitsRect(seg, a), `${r.key}: "${a.text}" hits the outline`));
    });
  }
});

test('the rule constants are applied: 223 Rem. pointy bullet and pocket', () => {
  const { bullet, walls, pocket, groove } = buildDrawing(byKey('223_rem')).model;
  near(bullet.zb, 39.0);
  near(bullet.z1, 46.36);
  assert.equal(bullet.shape, 'pointy');
  near(bullet.m, 1.27);
  assert.equal(groove, true);
  near(walls.tn, (6.43 - 5.7) / 2);
  near(walls.tb, 0.6);
  near(walls.w, 4.54);
  assert.deepEqual(pocket, { d: 4.45, depth: 3.04 });
});

test('9 mm Luger: pistol rounded bullet seats 0.4 G1 below the mouth', () => {
  const { bullet } = buildDrawing(byKey('9_mm_luger')).model;
  near(bullet.s, 0.4 * 9.03);
  near(bullet.zb, 19.15 - 0.4 * 9.03);
  near(bullet.z1, bullet.zb + 0.65 * (29.69 - bullet.zb));
});

test('22 Long Rifle is heeled: seated heel has the case inside diameter', () => {
  const { bullet, walls, pocket } = buildDrawing(byKey('22_long_rifle')).model;
  assert.equal(bullet.heeled, true);
  near(walls.tb, 0.6);
  near(bullet.rSeat, (5.72 - 2 * 0.6) / 2);
  assert.equal(pocket, null);
});

test('belted case: the belt ramp at angle delta ends where the rules say', () => {
  const d = buildDrawing(byKey('300_win_mag')).model;
  assert.equal(d.rim, 'belted');
  near(d.beltEnd, 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180), 1e-9);
  // the 300 Win. Mag. primer pocket (lrm, depth 3.3) sets w here, not the belt ramp
  near(d.walls.w, Math.max(3.3 + 1.5, d.beltEnd + d.walls.tb));
});

test('the seated bullet fits inside the case mouth in every drawing', () => {
  for (const r of records) {
    const { bullet, walls } = buildDrawing(r).model;
    assert.ok(walls.mouth >= bullet.rSeat - 1e-9, `${r.key}: mouth ${walls.mouth} < seated ${bullet.rSeat}`);
  }
});

test('the solid head ends before the bullet base in every drawing', () => {
  for (const r of records) {
    const { bullet, walls } = buildDrawing(r).model;
    assert.ok(walls.w < bullet.zb, r.key);
  }
});

test('a case without an extractor groove has no groove and no E note', () => {
  const d = buildDrawing(byKey('357_magnum'));
  assert.equal(d.model.groove, false);
  assert.ok(!d.notes.some((n) => /\bE1?\b/.test(n)));
});

test('a bottleneck case: the shoulder line passes through the published points', () => {
  const r = byKey('223_rem');
  const { profile } = buildDrawing(r).model;
  const L1 = r.cartridge.lengths.L1, L2 = r.cartridge.lengths.L2;
  const p1 = [L1, r.cartridge.powderChamber.P2 / 2], p2 = [L2, r.cartridge.collar.H1 / 2];
  // the fillets end about 0.13 mm after L1 and 0.52 mm before L2 for this case
  // the straight leg of the shoulder is the long segment between the two fillets
  const legs = [];
  for (let i = 0; i + 1 < profile.length; i++) {
    const [za, ra] = profile[i], [zb, rb] = profile[i + 1];
    if (Math.abs(zb - za) > 0.5 && za >= L1 - 0.5 && zb <= L2 + 0.5) legs.push([[za, ra], [zb, rb]]);
  }
  assert.equal(legs.length, 1);
  for (const [za, ra] of legs[0]) {
    const t = (za - p1[0]) / (p2[0] - p1[0]);
    near(ra, p1[1] + t * (p2[1] - p1[1]), 1e-6);
  }
});

test('missing values are named in notes and the feature is left out', () => {
  const noE1 = clone(byKey('223_rem'));
  delete noE1.cartridge.caseHead.E1;
  let d = buildDrawing(noE1);
  assert.equal(d.model.groove, false);
  assert.ok(d.notes.some((n) => n.includes('E1')), d.notes.join('; '));

  const noR3 = clone(byKey('300_win_mag'));
  delete noR3.cartridge.caseHead.R3;
  d = buildDrawing(noR3);
  assert.equal(d.model.rim, 'belted');
  assert.ok(d.notes.some((n) => n.includes('R3')), d.notes.join('; '));

  const r17 = buildDrawing(byKey('17_hmr'));
  assert.ok(r17.notes.some((n) => n.includes('r1 min')), r17.notes.join('; '));
  assert.ok(r17.notes.some((n) => n.includes('r2')), r17.notes.join('; '));
});
