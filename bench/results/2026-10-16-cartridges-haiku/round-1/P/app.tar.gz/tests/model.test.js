'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const m = require('../model.js');
const { records } = require('../data.js');

const byKey = (key) => records.find((r) => r.key === key);

test('numbers are shown as published: decimal point, no thousands separator', () => {
  assert.equal(m.formatValue(51.18), '51.18');
  assert.equal(m.formatValue(4150.0), '4150');
  assert.equal(m.formatValue(1825.0), '1825');
  assert.equal(m.formatValue(0.1), '0.1');
});

test('angles show as degrees or degrees, minutes and seconds', () => {
  assert.equal(m.formatValue(40, 'alpha'), '40°');
  assert.equal(m.formatValue({ degrees: 39, minutes: 59, seconds: 49 }, 'alpha'), `39°59'49"`);
  assert.equal(m.formatValue({ degrees: 3, minutes: 10, seconds: 36 }, 'i'), `3°10'36"`);
  assert.equal(m.formatValue({ degrees: 50, minutes: 35, seconds: 2 }, 'alpha'), `50°35'02"`);
});

test('a tolerance is shown next to its value, with its sign', () => {
  const lengths = byKey('308_win').cartridge.lengths;
  assert.equal(m.valueWithTolerance(lengths, 'L1'), '39.62 -0.2');
  assert.equal(m.valueWithTolerance(lengths, 'L3'), '51.18');
});

test('symbols follow the brief, the field name otherwise', () => {
  const cases = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L6: 'L6', Pmax: 'Pmax',
  };
  for (const [field, symbol] of Object.entries(cases)) assert.equal(m.symbol(field), symbol, field);
});

test('units follow the brief; lengths and unlisted fields are mm', () => {
  assert.equal(m.unitOf('Pmax'), 'bar');
  assert.equal(m.unitOf('PK'), 'bar');
  assert.equal(m.unitOf('PE'), 'bar');
  assert.equal(m.unitOf('EE'), 'J');
  assert.equal(m.unitOf('M'), 'g');
  assert.equal(m.unitOf('Q'), 'mm²');
  assert.equal(m.unitOf('N'), '—');
  assert.equal(m.unitOf('alpha'), '—');
  assert.equal(m.unitOf('L1'), 'mm');
  assert.equal(m.unitOf('u'), 'mm');
});

test('sections list every field once; tolerance fields are not rows', () => {
  for (const r of records) {
    const fields = [];
    for (const group of ['cartridge', 'chamber']) {
      for (const obj of Object.values(r[group])) for (const k of Object.keys(obj)) if (!k.endsWith('Tol')) fields.push(k);
    }
    const rows = m.sectionsOf(r).flatMap((g) => g.sections.flatMap((s) => s.rows));
    assert.equal(rows.length, fields.length, r.key);
    assert.ok(rows.every((row) => !/Tol$/.test(row.field)), r.key);
  }
});

test('section rows carry symbol, value with tolerance, and unit', () => {
  const groups = m.sectionsOf(byKey('308_win'));
  assert.deepEqual(groups.map((g) => g.title), ['Cartridge', 'Chamber']);
  const lengths = groups[0].sections.find((s) => s.key === 'lengths');
  assert.equal(lengths.title, 'Lengths');
  assert.deepEqual(lengths.rows.find((row) => row.symbol === 'L1'), { field: 'L1', symbol: 'L1', value: '39.62 -0.2', unit: 'mm' });
  const junction = groups[0].sections.find((s) => s.key === 'junctionCone');
  assert.equal(junction.rows.find((row) => row.symbol === 'α').value, '40°');
});

test('search matches name and alternative names, ignoring case and spaces', () => {
  const names = (list) => list.map((r) => r.name);
  assert.deepEqual(names(m.filterRecords(records, '7,62 x 51', 'all')), ['308 Win.']);
  assert.deepEqual(names(m.filterRecords(records, '7,62x51', 'all')), ['308 Win.']);
  assert.deepEqual(names(m.filterRecords(records, '30-06', 'all')), ['30-06 Spring.']);
  assert.deepEqual(names(m.filterRecords(records, '22 lr', 'all')), ['22 Long Rifle']);
  assert.equal(m.filterRecords(records, '', 'all').length, 25);
  assert.equal(m.filterRecords(records, '  ', 'all').length, 25);
});

test('family filter combines with search', () => {
  assert.equal(m.filterRecords(records, '', 'all').length, 25);
  assert.equal(m.filterRecords(records, '', 'rimfire').length, 3);
  assert.equal(m.filterRecords(records, '', 'pistol').length, 6);
  assert.equal(m.filterRecords(records, '22', 'rimfire').length, 2);
  assert.equal(m.filterRecords(records, '22', 'pistol').length, 0);
});

test('list is sorted by name with numbers in natural order', () => {
  const names = m.sortByName(records).map((r) => r.name);
  assert.equal(names[0], '6,5 Creedmoor');
  assert.ok(names.indexOf('9 mm Luger') < names.indexOf('17 HMR'));
  assert.ok(names.indexOf('17 HMR') < names.indexOf('22 Long Rifle'));
  assert.ok(names.indexOf('6,5 Creedmoor') < names.indexOf('7 x 64'));
  assert.ok(names.indexOf('7 x 64') < names.indexOf('30-06 Spring.'));
});

test('count text', () => {
  assert.equal(m.countText(1), '1 cartridge');
  assert.equal(m.countText(0), '0 cartridges');
  assert.equal(m.countText(25), '25 cartridges');
});

test('routes: list at the root, cartridge at #/cartridge/<key>', () => {
  assert.deepEqual(m.parseRoute(''), { view: 'list' });
  assert.deepEqual(m.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(m.parseRoute('#/cartridge/308_win'), { view: 'cartridge', key: '308_win' });
  assert.deepEqual(m.parseRoute('#/cartridge/unknown'), { view: 'cartridge', key: 'unknown' });
});
