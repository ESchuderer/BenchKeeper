# Design

## Context

The project is empty apart from tooling. The app must open from `file://` in Chromium, which blocks `fetch` of local files and ES module scripts (CORS on the `file` origin). The data therefore has to be embedded in a classic script. See proposal.md for motivation and specs/ for requirements.

## Goals / Non-Goals

**Goals:** a dependency-free app; pure, testable geometry and formatting logic; a drawing computed from the record; print output that is a single A4 page.

**Non-Goals:** editing data, unit conversion, ballistic calculations, a build step, a framework, client-side routing libraries.

## Decisions

- **Classic scripts, global namespace.** Each source file is a classic script wrapped in an IIFE that assigns one namespace object on `window` and, when `module` exists, exports the same object for Node tests. Alternative: ES modules (rejected: blocked on `file://`).
- **Data as JSON Lines inside a JS file.** `data/cartridges.js` holds the 25 lines verbatim in a template string; the app parses them with `JSON.parse` per line. Alternative: a generated JS object (rejected: a second copy to keep in sync).
- **Hash routing.** `#/cartridge/<key>` is parsed on `hashchange` and on load. Works on `file://` and static servers, bookmarkable, survives reload.
- **Search is substring over normalised name + alternative names.** Simple and predictable for the `7,62 x 51` example.
- **Drawing is pure SVG string generation** from a geometry model (`src/geometry.js`), with fixed mm coordinates and a `viewBox` in mm, so it scales with CSS width and prints at true proportions.
- **Geometry model separated from rendering.** `src/geometry.js` builds polylines and dimension specs in mm; `src/drawing.js` renders them to SVG. Label placement is checked in tests with rectangle/segment intersections.
- **Units by field name.** The brief fixes units for some fields. Fields the brief does not assign a unit to (`S`, `G`, `Fe`, `s`) are shown without a unit rather than an invented one. Length fields not named by the brief (`h`, `b`, `u`, `F`, `Z`, `G1`, `G2`, `deltaL`, `r`, `r1Min`, `r1Max`, `r2`, `R3`, `L4`, `L5`) are mm, as are all other length and diameter fields.
- **Print.** `@media print` hides chrome and forces light colours; the detail view prints one A4 portrait page with `@page { size: A4 portrait; margin: 12mm }`. Print scaling of tables uses a smaller font.
- **Tests.** Node's built-in `node --test` on pure modules (no dependencies). Browser-level checks (routing, DOM, layout, print) use a headless Chromium; if it cannot be installed, these checks are done by reasoning and stated as not run.

## Risks / Trade-offs

- [Geometry rules are underspecified in places (rebated rims, missing P2)] -> implement the stated rules; missing values produce a note, never an invented value.
- [Label overlap is hard to guarantee for all 25 records] -> compute label boxes in mm and test pairwise overlap and overlap with the outline for every record.
- [Transcribing 25 JSON records] -> a test checks record count, unique keys, and parse success; the file is written from the brief verbatim.

## Migration Plan

None: new project. Rollback is deleting the new files.

## Open Questions

None that change specs or tasks. Units of `S`, `G`, `Fe`, `s` are not stated by the brief and are shown without a unit.
