## Why

Reloaders, gunsmiths and engineers need a quick, offline reference for C.I.P. cartridge dimensions. The project has the 25 OpenBallistics records but no way to browse them. This change adds a static, dependency-free web app that lists the records, shows each one in a detail view with tables and a scaled 2D drawing, and prints as an A4 page.

## What Changes

- Add `index.html`, `styles.css` and classic JavaScript files that run from `file://` in Chromium and from any static server.
- Embed the 25 records, unchanged, as a JavaScript data file (no fetch, since `file://` cannot fetch).
- Start page: heading, searchable and family-filterable list with links to detail views, and a count.
- Detail view at a bookmarkable hash address: name, alternative names, metadata, all cartridge and chamber values in grouped tables, water capacity with source, and notes for implausible or missing values.
- SVG drawing computed from the record with the geometry rules of the brief (1 user unit = 1 mm), with dimension lines, title block and scale.
- Print: A4 portrait, black on white, drawing and tables, source footer.
- Light and dark theme following the system setting; phone layout.
- Development tooling: Node's built-in test runner (no runtime dependencies).

No existing capability is modified; the repository has no prior application code.

## Capabilities

### New Capabilities

- `cartridge-catalog`: the start page list, name and alternative-name search, family filter, count, and hash routing to the detail view.
- `cartridge-detail`: the detail view contents, value formatting, tolerances, notes, print output and the cartridge data contract.
- `cartridge-drawing`: the geometry rules that turn a record into the outside-and-section drawing with dimension annotations and title block.

### Modified Capabilities

None.

## Impact

- New files at the project root: `index.html`, `styles.css`, `src/*.js`, `data/cartridges.js`, tests under `test/`, `package.json` (dev-only test script, no runtime dependencies).
- No network requests, no CDNs, no fonts, no server code.
- Out of scope: editing the data, unit conversion, bullet-library or ballistic calculations, multi-language UI.
