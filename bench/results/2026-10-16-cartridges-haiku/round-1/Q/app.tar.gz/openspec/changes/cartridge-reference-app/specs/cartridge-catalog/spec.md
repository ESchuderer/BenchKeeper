## ADDED Requirements

### Requirement: Cartridge list on the start page
The start page SHALL show the heading "Cartridges" and one entry per cartridge with its name, family and case length L3. Each name SHALL be a link whose visible text is exactly the record's `name` and which opens that cartridge's detail view.

#### Scenario: All cartridges listed
- **WHEN** the start page is opened without a filter
- **THEN** all 25 cartridges are listed, each with name, family and L3
- **AND** the text "25 cartridges" is shown

### Requirement: Search by name and alternative names
The page SHALL provide a text field labelled "Search" that filters the list as the user types, matching against the name and every alternative name. Matching SHALL be a case-insensitive substring match after trimming surrounding whitespace and collapsing internal runs of whitespace, so that `7,62 x 51` finds "308 Win." through its alternative name "7,62 x 51".

#### Scenario: Alternative name finds a cartridge
- **WHEN** the user types `7,62 x 51` into Search
- **THEN** "308 Win." is listed

#### Scenario: No match
- **WHEN** the query matches no cartridge
- **THEN** the list is empty and the count reads "0 cartridges"

### Requirement: Family filter
The page SHALL provide a select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire. Choosing an option SHALL list only cartridges of that family, and it SHALL combine with the Search filter.

#### Scenario: Filter by family
- **WHEN** the user selects "belted"
- **THEN** only 300 Win. Mag. and 7 mm Rem. Mag. are listed

### Requirement: Result count
The page SHALL show the text "<n> cartridges" with the number of listed cartridges after filtering, for every value of n including 1 and 0.

### Requirement: Hash routing
Each detail view SHALL have its own address of the form `#/cartridge/<key>`, where `<key>` is the record's `key`. Reloading or bookmarking that address SHALL show the same detail view. An unknown key SHALL show a "not found" message with a link back to the list.

#### Scenario: Reload keeps the detail view
- **WHEN** the user opens the detail of "223 Rem." and reloads the page
- **THEN** the detail view of "223 Rem." is shown again
