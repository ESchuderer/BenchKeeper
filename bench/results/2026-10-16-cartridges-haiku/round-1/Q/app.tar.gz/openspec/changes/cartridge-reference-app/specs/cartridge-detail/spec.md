## ADDED Requirements

### Requirement: Detail header
The detail view SHALL show the cartridge's name as its heading, then alternative names (when any), family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method and the published water capacity with its source link.

### Requirement: Value tables
The detail view SHALL show every cartridge value and every chamber value in tables grouped by section, with columns "Symbol", "Value" and "Unit". Field names SHALL be used as symbols, except the symbols listed in the brief (for example `alpha` shown as "α", `eMin` as "e min").

#### Scenario: Tolerance shown beside its value
- **WHEN** a record has `L3` 51.18 and no `L3Tol`
- **THEN** the L3 row shows "51.18 mm"
- **AND** a record with `L1` 39.62 and `L1Tol` -0.2 shows "39.62 -0.2 mm" in the L1 row and no separate row for L1Tol

#### Scenario: Angle formats
- **WHEN** an angle is a number of degrees such as 40
- **THEN** it is shown as `40°`
- **WHEN** an angle is `{degrees: 39, minutes: 59, seconds: 49}`
- **THEN** it is shown as `39°59'49"`

### Requirement: Value format
Values SHALL be shown as published, with a decimal point and no thousands separator (for example "51.18 mm" and "4150 bar"). Names SHALL be shown as published (for example "6,5 Creedmoor").

### Requirement: Units
Lengths and diameters are mm; Pmax, PK and PE are bar; EE is J; M is g; Q is mm²; N is a count with no unit; alpha, alpha1, beta, delta and i are angles. Fields with no unit stated by the brief SHALL show no unit rather than an invented one.

### Requirement: Missing and implausible data
When a record has a published note about implausible values, the detail view SHALL show that message. When the drawing cannot use a value, the view SHALL say which value is missing.

### Requirement: Print
A "Print" button SHALL open the browser print dialog. The printed detail view SHALL be one A4 portrait page in black on white, with the page header (name), the drawing at full width, the tables, and a footer with the source (C.I.P. TDCC and the revised date). Navigation, search and buttons SHALL NOT be printed.

### Requirement: Navigation
A link "All cartridges" SHALL return to the start page.

### Requirement: Presentation
The app SHALL follow the system light or dark setting on screen, SHALL be usable on a phone, and SHALL use tabular numerals for values. It SHALL make no network requests.

### Requirement: Data contract
The app SHALL use the 25 records as given, without adding, changing or fetching data.
