## ADDED Requirements

### Requirement: Scaled drawing
The detail view SHALL show an inline SVG drawing of the cartridge, true to scale with 1 user unit = 1 mm, axis horizontal and head on the left. Its accessible name SHALL be "<name> drawing". The upper half SHALL be the outside view, the lower half a section with cut walls hatched, and a dash-dot centre line SHALL be shown.

### Requirement: Geometry from published values
The outline SHALL be computed from the record's cartridge values using the rim-type, head, extractor groove, body, shoulder, neck, bullet and wall rules of the brief. A value that a rule needs and that is missing SHALL cause that feature to be omitted and the omission to be stated under the drawing; no value SHALL be invented.

### Requirement: Dimension annotations
Dimension lines with arrowheads and extension lines SHALL be shown for L3, L6, R1, R and P1, and for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α where published. Each SHALL be labelled with its symbol and value (for example "L3 51.18"). Labels SHALL NOT overlap each other or the outline.

### Requirement: Title block
The drawing SHALL include a title block with the name, C.I.P. table and revision date, the text "Dimensions in mm", and the scale.

### Requirement: Responsive and printable
The drawing SHALL scale to the width of a phone screen and SHALL print with every label legible.
