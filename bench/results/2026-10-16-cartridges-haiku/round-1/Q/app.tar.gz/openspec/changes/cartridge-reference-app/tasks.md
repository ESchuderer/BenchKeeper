# Tasks

## 1. Project scaffold and data

- [ ] 1.1 Add `package.json` (private, no runtime dependencies, `test` script runs `node --test`); verify `npm test` runs with zero tests failing.
- [ ] 1.2 Add `data/cartridges.js` containing the 25 JSON Lines records verbatim; verify a test parses 25 lines, unique `key`s, and every record has `name`, `family`, `cartridge`, `chamber`.

## 2. Formatting and units (tests first)

- [ ] 2.1 Write failing tests for value formatting (`51.18 mm`, `4150 bar`, `6,5 Creedmoor`, tolerance beside value, angle `40°` and `39°59'49"`, symbol mapping `eMin` -> "e min", `alpha` -> "α").
- [ ] 2.2 Implement `src/format.js` and `src/units.js` to pass 2.1.

## 3. Catalog logic (tests first)

- [ ] 3.1 Write failing tests for search (substring, case-insensitive, alternative names, `7,62 x 51` finds `308 Win.`), family filter, combined filter, count text, and the hash route parser.
- [ ] 3.2 Implement `src/catalog.js` to pass 3.1.

## 4. Geometry (tests first)

- [ ] 4.1 Write failing tests for rim type classification (belted, rimfire, rimmed, rimless, rebated) across the 25 records.
- [ ] 4.2 Write failing tests for head/rim profile, extractor groove, belt, body, shoulder fillets, neck, mouth, and missing-value notes.
- [ ] 4.3 Write failing tests for the bullet: seating depth, base, cylinder end, nose shape and meplat for pointy, rounded, flat and semi-wadcutter; heeled case.
- [ ] 4.4 Write failing tests for wall thickness, inner profile, solid head `w`, primer pocket.
- [ ] 4.5 Implement `src/geometry.js` to pass 4.1 to 4.4.

## 5. Drawing (tests first)

- [ ] 5.1 Write failing tests that label boxes do not overlap each other and do not intersect the outline for all 25 records, and that the required dimension labels are present with symbol and value.
- [ ] 5.2 Implement `src/drawing.js` (SVG output with `aria-label`, title block, scale, dash-dot centre line, hatch pattern) and label placement to pass 5.1.

## 6. App shell and styles

- [ ] 6.1 Write `index.html`, `styles.css`, `src/app.js`: start page list, search, family select, count, hash routing, detail view with grouped tables, notes, "All cartridges" link, Print button.
- [ ] 6.2 Styles: light/dark via `prefers-color-scheme`, phone layout, tabular numerals, `@media print` A4 portrait, black on white, footer with source.

## 7. Verification and review

- [ ] 7.1 Run `npm test` and confirm all tests pass.
- [ ] 7.2 Load `index.html` from disk (`file://`) in a headless Chromium if one can be installed; check console has no errors, search/filter/routing work, drawings render, and print layout is one page. Record what was and was not run.
- [ ] 7.3 Run a multi-axis code review of the change and fix Critical and Required findings.
