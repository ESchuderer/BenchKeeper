# Cartridge Reference Implementation Plan

> **Spec:** docs/superpowers/specs/2026-10-15-cartridge-reference-design.md (calls 1-17 are the decisions taken during the build).

**Goal:** Static offline C.I.P. cartridge reference: list with search and family filter, bookmarkable detail view with an SVG drawing and value tables, one-page A4 print.

**Architecture:** Classic scripts, no build step. `js/core.js` holds pure logic (formatting, classification, tables, geometry, dimension layout) and is unit-tested with `node --test`. `js/drawing.js` builds the SVG string. `js/app.js` renders the list and detail views and routes on the hash. `css/style.css` holds the screen, dark, phone and print styles.

**Tech stack:** HTML, CSS, JavaScript (ES5 style, IIFEs). Dev only: Node 22 test runner; Playwright for the browser check.

## Tasks (all done)

1. **Data** — `js/data.js`: the 25 records as given, exposed as `CARTRIDGE_DATA`. Verify: `npm test` (count and key uniqueness).
2. **Formatting and symbols** — `formatNumber`, `formatAngle` (two-digit minutes and seconds), `symbolFor`, `unitFor`. Verify: core tests.
3. **Classification and search** — `rimTypeOf`, `primerPocket`, `matchesQuery`, `filterCartridges`. Verify: core tests.
4. **Tables** — `sectionTables` merges `<X>Tol` into the value, no tolerance rows. Verify: core tests.
5. **Case geometry** — head (chamfer, rimfire half-round), groove and belt, body, fillets, walls, primer pocket, section polygons. Verify: core tests (formulas), notes for missing values.
6. **Bullet geometry** — seating, cylinder end, nose (ogive, ellipse, cone), heeled case. Verify: core tests (point-on-arc, ellipse, meplat, zb/zk).
7. **Dimension layout** — lanes outside the outline, label placement with collision checks. Verify: core tests (no label overlap, no overlap with outline, viewBox contains everything, for all 25).
8. **SVG renderer** — `drawingFor`, accessible name, no NaN. Verify: drawing tests.
9. **App shell** — list, search, family select, detail view, hash routing, print button, not-found view. Verify: browser check.
10. **Styles** — light and dark, phone layout, one-page A4 print. Verify: browser check and the one-page print check for all 25 cartridges.

## Verification

- `npm test` — unit tests (core and drawing).
- `CHROMIUM_PATH=<chromium> node tests/browser.check.js` — opens `index.html` from `file://`, checks list, search, filter, detail view, reload, phone width, dark mode, print (one page), print button, no network requests, no console errors.

## Review

- Self-review against the brief (spec coverage, missing-value notes).
- Independent read-only review; its findings were fixed (missing-value notes, R1 handling, angle padding, duplicate notes, malformed hash). The α treatment stays as recorded in design call 15.
