# Cartridge Reference: Design

## Intent
A static, offline reference of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on OpenBallistics. Data is fixed (the 25 records supplied with the brief, from OpenBallistics commit e83db43, MIT). Every value is shown as published.

## Goals
- List with name link, family, case length L3; search by name and alternative names; family filter; count.
- Detail view per cartridge at a bookmarkable hash address (`#/cartridge/<key>`).
- Tables of cartridge and chamber values grouped by section.
- Inline SVG 2D drawing, true to scale (1 user unit = 1 mm), with dimension lines and a title block.
- Print to one A4 portrait page, black on white.
- Light and dark theme following the system setting; responsive to phone width.

## Non-goals
- No data editing, no fetching, no server code, no build step, no runtime dependencies, no network requests.
- No internationalisation: English UI.

## Constraints
- Plain HTML, CSS, JavaScript. Classic scripts only (ES module scripts are blocked on `file://` in Chromium).
- Works from `file://` and from any static server.
- Node 22 test runner (`node --test`) as the only dev tooling; optional headless browser check as a dev dependency.

## Calls made (not stated in the brief)
1. **Routing:** hash routing (`#/` and `#/cartridge/<key>`), because `history.pushState` is unreliable on `file://`.
2. **Script layout:** `js/data.js` (records), `js/core.js` (pure logic: formatting, geometry, dimension layout; UMD export for Node tests), `js/drawing.js` (SVG rendering), `js/app.js` (DOM, routing, print button).
3. **Units in tables:** published values are shown as-is; the unit column uses the brief's list (mm, bar, J, g, mm², count, degrees).
4. **Missing values:** a row for a symbol that is absent from the record is omitted from the tables. In the drawing, a feature whose value is missing is omitted and a note in the drawing's notes line names the missing value.
5. **Rim type ratio:** `caseHead.R1 / powderChamber.P1`, falling back to `chamber` values if not present.
6. **Bullet diameter for heeled cases:** the exposed bullet uses `H2` (case outside diameter) as its diameter; nose geometry uses that diameter. For 22 Long Rifle G1 = H2 so the choice does not change the drawing.
7. **Zero neck wall:** for 22 Long Rifle `tn = (H2 - G1)/2 = 0`; the neck section is drawn as a single line with no hatch.
8. **Angle display:** `{degrees, minutes, seconds}` shown as `39°59'49"`; numeric angles as `40°`. Seconds shown as integers when the value is whole.
9. **Groove without eMin:** if `E` and `E1` are present but `eMin` is absent, the floor is drawn at zero length and the drawing notes `eMin` missing.
10. **Belt without R3:** if a belted record lacks `R3`, the belt is not drawn; the notes name `R3`.
11. **Builder check:** the brainstorming skill's reviewer subagent step was skipped because the brief is a complete specification and the user asked for an unattended build; the design is the brief.

12. **Belted head depth:** for belted cases the solid-head term is belt ramp end + tb (the brief's "or" clause), not E + tb.
13. **Label font:** scales with the cartridge length, fs = clamp(0.03 (L6 + 10), 1.2, 3.2) mm, so labels stay legible on screen for short and long cases alike.
14. **Print fit:** one A4 portrait page via multi-column value tables (4 columns), an 8 pt base size and a 100 mm cap on the drawing height in print. The drawing is full width unless the height cap applies.
15. **Alpha:** α is labelled with a leader from the shoulder midpoint (label only, no arrowheads or arc). The brief lists α among the dimensioned features; the published α is the included cone angle and the drawn shoulder is through the published points, so an arc at the apex would not match the drawn shoulder. This is a known deviation from the dimension-line list.
16. **Count wording:** the count reads "1 cartridge" for one result and "<n> cartridges" otherwise.
17. **Missing values:** notes are shown under each drawing ("Drawing notes: ..."). Where R1 is missing the rim is drawn at P1 and R1 is not dimensioned.

## Drawing conventions
- Coordinates: x = z (mm, axis, head at 0); y = -r in the upper half (outside view), y = +r in the lower half (section).
- Upper half: outer silhouette including the exposed bullet. Lower half: section with hatched walls, primer pocket, solid head, and seated bullet heel.
- Dimension lines: arrowheads, extension lines, labels as `symbol value`. Layout by greedy placement against lanes; labels must not overlap each other or the outline (checked by tests across all 25 records).
- Title block under the drawing: name, C.I.P. table, revised date, "Dimensions in mm", scale 1:1.

## Open for the user
None blocking. Calls 1-17 can be reversed in review.
