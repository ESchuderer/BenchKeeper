/* Application shell: list view, detail view, hash routing and print. Classic script, no network. */
(function () {
  "use strict";

  var core = window.CartridgeCore;
  var drawing = window.CartridgeDrawing;
  var records = window.CARTRIDGE_DATA || [];
  var FAMILIES = ["All", "rimless", "rimmed", "belted", "pistol", "rimfire"];
  var app = document.getElementById("app");

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === "text") node.textContent = attrs[k];
        else if (k === "className") node.className = attrs[k];
        else node.setAttribute(k, attrs[k]);
      });
    }
    (children || []).forEach(function (c) {
      if (c === null || c === undefined) return;
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  function findRecord(key) {
    for (var i = 0; i < records.length; i++) if (records[i].key === key) return records[i];
    return null;
  }

  function setTitle(text) {
    document.title = text ? text + " · Cartridges" : "Cartridges";
  }

  // ---------- list view ----------
  function renderList() {
    setTitle("");
    var q = el("input", { id: "q", type: "search", autocomplete: "off", spellcheck: "false" });
    var fam = el("select", { id: "fam" }, FAMILIES.map(function (f) {
      return el("option", { value: f, text: f });
    }));
    var count = el("p", { id: "count", className: "count", "aria-live": "polite" });
    var list = el("ul", { id: "list", className: "cartlist" });

    function update() {
      var rows = core.filterCartridges(records, q.value, fam.value);
      count.textContent = rows.length + (rows.length === 1 ? " cartridge" : " cartridges");
      list.replaceChildren.apply(list, rows.map(function (rec) {
        var l3 = rec.cartridge.lengths && core.isNum(rec.cartridge.lengths.L3) ? rec.cartridge.lengths.L3 : null;
        return el("li", { className: "cartrow" }, [
          el("a", { href: "#/cartridge/" + encodeURIComponent(rec.key), text: rec.name }),
          el("span", { className: "meta", text: rec.family }),
          el("span", { className: "meta num", text: l3 === null ? "L3 —" : "L3 " + core.formatNumber(l3) + " mm" })
        ]);
      }));
    }
    q.addEventListener("input", update);
    fam.addEventListener("change", update);

    app.replaceChildren(
      el("h1", { text: "Cartridges" }),
      el("div", { className: "controls", role: "search" }, [
        el("div", { className: "field" }, [el("label", { for: "q", text: "Search" }), q]),
        el("div", { className: "field" }, [el("label", { for: "fam", text: "Family" }), fam])
      ]),
      count,
      list
    );
    update();
  }

  // ---------- detail view ----------
  function factRow(term, valueNodes) {
    return [el("dt", { text: term }), el("dd", null, valueNodes)];
  }

  function capacityNodes(cap) {
    if (!cap) return ["—"];
    var out = [core.formatNumber(cap.grH2O) + " grH2O"];
    if (cap.source) {
      out.push(" (source: ");
      out.push(cap.url ? el("a", { href: cap.url, text: cap.source, rel: "noopener" }) : cap.source);
      out.push(")");
    }
    if (cap.note) out.push(el("span", { className: "note", text: " " + cap.note }));
    return out;
  }

  function sectionTable(section) {
    var tbody = el("tbody", null, section.rows.map(function (r) {
      return el("tr", null, [
        el("th", { scope: "row", text: r.symbol }),
        el("td", { className: "num", text: r.value }),
        el("td", { className: "unit", text: r.unit })
      ]);
    }));
    return el("section", { className: "valuesection" }, [
      el("h3", { text: section.title }),
      el("table", { className: "values" }, [
        el("thead", null, [el("tr", null, [
          el("th", { scope: "col", text: "Symbol" }),
          el("th", { scope: "col", className: "num", text: "Value" }),
          el("th", { scope: "col", text: "Unit" })
        ])]),
        tbody
      ])
    ]);
  }

  function titleBlock(rec, geom) {
    function cell(label, value) {
      return el("div", { className: "tb-cell" }, [
        el("span", { className: "tb-label", text: label }),
        el("span", { className: "tb-value", text: value })
      ]);
    }
    return el("div", { className: "titleblock" }, [
      cell("Name", rec.name),
      cell("C.I.P. table", rec.tab || "—"),
      cell("Revised", rec.revised || "—"),
      cell("Dimensions", "Dimensions in mm"),
      cell("Scale", "True to scale (1 mm = 1 unit); fitted to width")
    ]);
  }

  function renderDetail(rec) {
    setTitle(rec.name);
    var ann = rec.annotations || {};
    var tables = core.sectionTables(rec);
    var draw = drawing.drawingFor(rec);

    var figure = el("figure", { className: "drawing" });
    figure.innerHTML = draw.svg;
    var notes = el("p", { className: "drawing-notes" });
    if (draw.notes.length) notes.textContent = "Drawing notes: " + draw.notes.join("; ") + ".";

    var facts = el("dl", { className: "facts" }, [].concat(
      factRow("Alternative names", [(rec.alternativeNames && rec.alternativeNames.length) ? rec.alternativeNames.join(", ") : "—"]),
      factRow("Family", [rec.family]),
      factRow("Category", [ann.category || "—"]),
      factRow("Primer type", [ann.primerType || "—"]),
      factRow("C.I.P. table", [rec.tab || "—"]),
      factRow("Country", [rec.country || "—"]),
      factRow("Published", [rec.published || "—"]),
      factRow("Revised", [rec.revised || "—"]),
      factRow("Pressure method", [rec.pressureMethod || "—"]),
      factRow("Water capacity", capacityNodes(ann.publishedCapacity))
    ));

    var back = el("a", { className: "back", href: "#/", text: "All cartridges" });
    var printBtn = el("button", { type: "button", className: "print", text: "Print" });
    printBtn.addEventListener("click", function () { window.print(); });

    var cartSections = el("div", { className: "tables" }, tables.cartridge.map(sectionTable));
    var chamberSections = el("div", { className: "tables" }, tables.chamber.map(sectionTable));

    var parts = [
      el("nav", { className: "toolbar no-print" }, [back, printBtn]),
      el("h1", { className: "cart-name", text: rec.name }),
      facts,
      el("section", { className: "drawing-block" }, [figure, titleBlock(rec, draw.geometry), notes]),
      el("h2", { text: "Cartridge values" }),
      cartSections,
      el("h2", { text: "Chamber values" }),
      chamberSections,
      el("footer", { className: "source", text: "Source: C.I.P. TDCC, revised " + (rec.revised || "—") + "." })
    ];
    app.replaceChildren.apply(app, parts.filter(function (p) { return p !== null; }));
  }

  // ---------- routing ----------
  function safeDecode(s) {
    try { return decodeURIComponent(s); } catch (e) { return s; }
  }

  function route() {
    var hash = window.location.hash || "";
    var m = /^#\/cartridge\/(.+)$/.exec(hash);
    if (m) {
      var key = safeDecode(m[1]);
      var rec = findRecord(key);
      if (rec) { renderDetail(rec); window.scrollTo(0, 0); return; }
      setTitle("Not found");
      app.replaceChildren(
        el("p", { className: "back-row" }, [el("a", { className: "back", href: "#/", text: "All cartridges" })]),
        el("h1", { text: "Cartridge not found" }),
        el("p", { text: "No cartridge has the key \u201c" + key + "\u201d." })
      );
      return;
    }
    renderList();
    window.scrollTo(0, 0);
  }

  window.addEventListener("hashchange", route);
  route();
})();
