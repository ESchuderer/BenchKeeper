/* Pure logic for the cartridge reference: formatting, classification, tables,
   case and bullet geometry, and dimension layout. No DOM access.
   Units: lengths and diameters in mm; geometry points are [z, r] with z along
   the axis from the head face (z = 0) and r the radius. The drawing maps
   x = z and y = -r (outside view, upper half) or y = +r (section, lower half). */
(function (root, factory) {
  "use strict";
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.CartridgeCore = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";

  var PI = Math.PI;

  // ---------- basic helpers ----------
  function isNum(v) { return typeof v === "number" && isFinite(v); }
  function rad(deg) { return (deg * PI) / 180; }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  function angleDegrees(a) {
    if (isNum(a)) return a;
    if (a && isNum(a.degrees)) {
      return a.degrees + (isNum(a.minutes) ? a.minutes : 0) / 60 + (isNum(a.seconds) ? a.seconds : 0) / 3600;
    }
    return undefined;
  }

  function formatNumber(n) {
    if (Object.is(n, -0)) return "0";
    return String(n);
  }

  function pad2(n) {
    var s = formatNumber(n);
    return s.length < 2 ? "0" + s : s;
  }

  function formatAngle(a) {
    if (isNum(a)) return formatNumber(a) + "°";
    if (a && isNum(a.degrees)) {
      return formatNumber(a.degrees) + "°" + pad2(a.minutes || 0) + "'" + pad2(a.seconds || 0) + '"';
    }
    return String(a);
  }

  // ---------- symbols and units ----------
  var ANGLE_FIELDS = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var SYMBOLS = {
    eMin: "e min", r1Min: "r1 min", r1Max: "r1 max", alpha: "α", alpha1: "α1",
    beta: "β", delta: "δ", deltaL: "delta L", L3PlusG: "L3 + G"
  };
  var UNITS = { Pmax: "bar", PK: "bar", PE: "bar", EE: "J", M: "g", Q: "mm²", N: "—" };

  function isAngleField(field) { return !!ANGLE_FIELDS[field]; }

  function formatValue(field, v) {
    if (isAngleField(field)) return formatAngle(v);
    if (isNum(v)) return formatNumber(v);
    return String(v);
  }

  function symbolFor(field) { return SYMBOLS[field] || field; }

  function unitFor(field) {
    if (isAngleField(field)) return "—";
    if (UNITS[field]) return UNITS[field];
    return "mm";
  }

  // ---------- classification ----------
  function rimTypeOf(rec) {
    var family = rec.family;
    if (family === "belted") return "belted";
    if (family === "rimfire") return "rimfire";
    var ch = (rec.cartridge && rec.cartridge.caseHead) || {};
    var pc = (rec.cartridge && rec.cartridge.powderChamber) || {};
    var chamber = rec.chamber || {};
    var R1 = isNum(ch.R1) ? ch.R1 : (chamber.breech && isNum(chamber.breech.R1) ? chamber.breech.R1 : undefined);
    var P1 = isNum(pc.P1) ? pc.P1 : (chamber.powderChamber && isNum(chamber.powderChamber.P1) ? chamber.powderChamber.P1 : undefined);
    if (R1 === undefined || P1 === undefined || P1 === 0) {
      return family === "rimmed" ? "rimmed" : "rimless";
    }
    var ratio = R1 / P1;
    if (ratio >= 1.05) return "rimmed";
    if (ratio < 0.98) return "rebated";
    return "rimless";
  }

  function primerPocket(primer) {
    switch (primer) {
      case "sp": case "spm": case "sr":
        return { diameter: 4.45, depth: 3.04 };
      case "lp": case "lpm":
        return { diameter: 5.33, depth: 3.04 };
      case "lr": case "lrm":
        return { diameter: 5.33, depth: 3.3 };
      default:
        return null;
    }
  }

  // ---------- search and filter ----------
  function squash(s) { return String(s).toLowerCase().replace(/\s+/g, ""); }

  function matchesQuery(rec, query) {
    var q = squash(query || "");
    if (q === "") return true;
    var names = [rec.name].concat(rec.alternativeNames || []);
    for (var i = 0; i < names.length; i++) {
      if (squash(names[i]).indexOf(q) !== -1) return true;
    }
    return false;
  }

  function filterCartridges(records, query, family) {
    return records.filter(function (rec) {
      if (family && family !== "All" && rec.family !== family) return false;
      return matchesQuery(rec, query);
    });
  }

  // ---------- tables ----------
  var SECTION_TITLES = {
    caseHead: "Case head", collar: "Collar", junctionCone: "Junction cone", lengths: "Lengths",
    misc: "Miscellaneous", powderChamber: "Powder chamber", pressures: "Pressures",
    projectile: "Projectile", barrel: "Barrel", breech: "Breech", grooves: "Grooves", rifling: "Rifling"
  };

  function sectionRows(obj) {
    var rows = [];
    if (!obj) return rows;
    Object.keys(obj).forEach(function (key) {
      if (/Tol$/.test(key) && Object.prototype.hasOwnProperty.call(obj, key.slice(0, -3))) return;
      var v = obj[key];
      var value = formatValue(key, v);
      var tolKey = key + "Tol";
      if (Object.prototype.hasOwnProperty.call(obj, tolKey)) {
        value += " " + formatNumber(obj[tolKey]);
      }
      rows.push({ symbol: symbolFor(key), value: value, unit: unitFor(key) });
    });
    return rows;
  }

  function sectionTables(rec) {
    function build(group) {
      var out = [];
      if (!group) return out;
      Object.keys(group).forEach(function (id) {
        var rows = sectionRows(group[id]);
        if (rows.length) out.push({ id: id, title: SECTION_TITLES[id] || id, rows: rows });
      });
      return out;
    }
    return {
      cartridge: build(rec.cartridge),
      chamber: build(rec.chamber)
    };
  }

  // ---------- geometry helpers ----------
  // Maximum radius of a polyline at a given z (vertical segments give their larger radius).
  function radiusAt(poly, z) {
    var best = NaN;
    for (var i = 0; i < poly.length - 1; i++) {
      var a = poly[i], b = poly[i + 1];
      var z1 = a[0], z2 = b[0];
      var lo = Math.min(z1, z2), hi = Math.max(z1, z2);
      if (z < lo - 1e-12 || z > hi + 1e-12) continue;
      var r;
      if (Math.abs(z2 - z1) < 1e-12) {
        r = Math.max(a[1], b[1]);
      } else {
        r = a[1] + ((z - z1) / (z2 - z1)) * (b[1] - a[1]);
      }
      if (isNaN(best) || r > best) best = r;
    }
    return best;
  }

  function dedupe(poly) {
    var out = [];
    poly.forEach(function (p) {
      var last = out[out.length - 1];
      if (!last || Math.abs(last[0] - p[0]) > 1e-12 || Math.abs(last[1] - p[1]) > 1e-12) out.push(p);
    });
    return out;
  }

  // Round the corner pts[i] with radius radii[i] (tangent arc, sampled).
  function applyFillets(pts, radii) {
    var out = [pts[0]];
    for (var i = 1; i < pts.length - 1; i++) {
      var r = radii[i];
      if (!isNum(r) || r <= 0) { out.push(pts[i]); continue; }
      var A = pts[i - 1], C = pts[i], B = pts[i + 1];
      var ua = unit2(A[0] - C[0], A[1] - C[1]);
      var ub = unit2(B[0] - C[0], B[1] - C[1]);
      var cosPhi = clamp(ua[0] * ub[0] + ua[1] * ub[1], -1, 1);
      var phi = Math.acos(cosPhi);
      if (phi < 1e-6 || phi > PI - 1e-6) { out.push(C); continue; }
      var t = r / Math.tan(phi / 2);
      var maxT = 0.45 * Math.min(Math.hypot(A[0] - C[0], A[1] - C[1]), Math.hypot(B[0] - C[0], B[1] - C[1]));
      var rr = r;
      if (t > maxT) { t = maxT; rr = t * Math.tan(phi / 2); }
      var T1 = [C[0] + ua[0] * t, C[1] + ua[1] * t];
      var T2 = [C[0] + ub[0] * t, C[1] + ub[1] * t];
      var bis = unit2(ua[0] + ub[0], ua[1] + ub[1]);
      var d = rr / Math.sin(phi / 2);
      var O = [C[0] + bis[0] * d, C[1] + bis[1] * d];
      var a1 = Math.atan2(T1[1] - O[1], T1[0] - O[0]);
      var a2 = Math.atan2(T2[1] - O[1], T2[0] - O[0]);
      var sweep = a2 - a1;
      while (sweep > PI) sweep -= 2 * PI;
      while (sweep <= -PI) sweep += 2 * PI;
      var N = 12;
      out.push(T1);
      for (var j = 1; j < N; j++) {
        var a = a1 + (sweep * j) / N;
        out.push([O[0] + rr * Math.cos(a), O[1] + rr * Math.sin(a)]);
      }
      out.push(T2);
    }
    out.push(pts[pts.length - 1]);
    return out;
  }

  function unit2(x, y) {
    var l = Math.hypot(x, y) || 1;
    return [x / l, y / l];
  }

  // ---------- geometry ----------
  function computeGeometry(rec) {
    var notes = [];
    var annotations = rec.annotations || {};
    var cart = rec.cartridge || {};
    var ch = cart.caseHead || {};
    var col = cart.collar || {};
    var jc = cart.junctionCone || {};
    var len = cart.lengths || {};
    var pc = cart.powderChamber || {};
    var pr = cart.projectile || {};
    var chamber = rec.chamber || {};
    var primer = annotations.primerType;
    var rimType = rimTypeOf(rec);
    var rimfire = rimType === "rimfire";
    var belted = rimType === "belted";

    var R = isNum(ch.R) ? ch.R : undefined;
    var R1 = isNum(ch.R1) ? ch.R1 : (chamber.breech && isNum(chamber.breech.R1) ? chamber.breech.R1 : undefined);
    var R1published = R1;
    var P1 = isNum(pc.P1) ? pc.P1 : undefined;
    var P2 = isNum(pc.P2) ? pc.P2 : undefined;
    var H1 = isNum(col.H1) ? col.H1 : undefined;
    var H2 = isNum(col.H2) ? col.H2 : undefined;
    var L1 = isNum(len.L1) ? len.L1 : undefined;
    var L2 = isNum(len.L2) ? len.L2 : undefined;
    var L3 = isNum(len.L3) ? len.L3 : undefined;
    var L6 = isNum(len.L6) ? len.L6 : undefined;
    var G1 = isNum(pr.G1) ? pr.G1 : undefined;
    var E = isNum(ch.E) ? ch.E : undefined;
    var E1 = isNum(ch.E1) ? ch.E1 : undefined;
    var eMin = isNum(ch.eMin) ? ch.eMin : undefined;
    var f = isNum(ch.f) ? ch.f : undefined;
    var beta = angleDegrees(ch.beta);
    var delta = angleDegrees(ch.delta);
    var R3 = isNum(ch.R3) ? ch.R3 : undefined;
    var alpha = angleDegrees(jc.alpha);
    var r1Min = isNum(jc.r1Min) ? jc.r1Min : undefined;
    var r2 = isNum(jc.r2) ? jc.r2 : undefined;

    if (R1 === undefined) { notes.push("R1 missing; rim drawn at P1 and not dimensioned"); R1 = P1; }
    if (P1 === undefined) notes.push("P1 missing");
    if (R === undefined) notes.push("R missing");
    if (R === undefined) R = 0;
    if (R1 === undefined) R1 = 0;
    if (P1 === undefined) P1 = 0;
    if (L3 === undefined) notes.push("L3 missing");
    if (H2 === undefined) notes.push("H2 missing");
    if (L6 === undefined) notes.push("L6 missing");
    if (G1 === undefined) notes.push("G1 missing");

    // ----- primer pocket and rim type -----
    if (!rimfire && !primer) notes.push("primerType missing; no primer pocket drawn");
    var pocket = rimfire ? null : primerPocket(primer);
    var pocketR = pocket ? pocket.diameter / 2 : 0;

    // ----- head and extractor groove -----
    var outer = [[0, 0]];
    var z0;
    var groove = false;
    var belt = null;
    var rimMidZ;
    var E_ok = E !== undefined && E1 !== undefined && !rimfire;
    if (rimfire && R > 0 && R1 > 0 && P1 > 0) {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      var cr = R1 / 2 - rho;
      outer.push([0, cr]);
      for (var s = 1; s <= 12; s++) {
        var phi = PI - (PI * s) / 12;
        outer.push([rho + rho * Math.cos(phi), cr + rho * Math.sin(phi)]);
      }
      outer.push([2 * rho, P1 / 2]);
      z0 = 2 * rho;
      rimMidZ = rho;
    } else {
      var chamferC = null;
      if (beta !== undefined && beta > 0 && beta < 90 && f !== undefined) {
        chamferC = Math.min(f * Math.tan(rad(beta)), R1 / 4);
        outer.push([0, R1 / 2 - chamferC]);
        outer.push([f, R1 / 2]);
        rimMidZ = (f + R) / 2;
      } else {
        outer.push([0, R1 / 2]);
        rimMidZ = R / 2;
      }
      outer.push([R, R1 / 2]);
      if (E_ok) {
        var floorEnd = R + (eMin !== undefined ? eMin : 0);
        if (eMin === undefined) notes.push("eMin missing; groove floor drawn at zero length");
        groove = true;
        outer.push([R, E1 / 2], [floorEnd, E1 / 2]);
        if (belted && R3 !== undefined && delta !== undefined && R3 / 2 > E1 / 2) {
          var zr = floorEnd + (R3 / 2 - E1 / 2) / Math.tan(rad(delta));
          if (zr < E) {
            outer.push([zr, R3 / 2], [E, R3 / 2]);
            belt = { radius: R3 / 2, rampEndZ: zr, rampStartZ: floorEnd };
          } else {
            notes.push("belt ramp ends after E; belt not drawn");
          }
        } else if (belted) {
          notes.push(R3 === undefined ? "R3 missing; belt not drawn" : "delta missing; belt not drawn");
        }
        outer.push([E, P1 / 2]);
        z0 = E;
      } else {
        if (!rimfire) {
          if (E === undefined && E1 === undefined) notes.push("E and E1 missing; no extractor groove drawn");
          else if (E === undefined) notes.push("E missing; no extractor groove drawn");
          else if (E1 === undefined) notes.push("E1 missing; no extractor groove drawn");
        }
        outer.push([R, P1 / 2]);
        z0 = R;
      }
    }
    if (belted && !belt && !groove) notes.push("belt not drawn");

    // ----- body, shoulder and neck -----
    var bottleneck = alpha !== undefined && L1 !== undefined && L2 !== undefined && P2 !== undefined && H1 !== undefined;
    if (!bottleneck && (alpha !== undefined || L1 !== undefined || L2 !== undefined || P2 !== undefined || H1 !== undefined)) {
      var missingShoulder = [];
      if (alpha === undefined) missingShoulder.push("alpha");
      if (L1 === undefined) missingShoulder.push("L1");
      if (L2 === undefined) missingShoulder.push("L2");
      if (P2 === undefined) missingShoulder.push("P2");
      if (H1 === undefined) missingShoulder.push("H1");
      notes.push(missingShoulder.join(", ") + " missing; case drawn straight");
    }
    if (bottleneck && r1Min === undefined) notes.push("r1Min missing; body corner sharp");
    if (bottleneck && r2 === undefined) notes.push("r2 missing; neck corner sharp");
    var shoulder = { bottleneck: bottleneck, alpha: alpha, L1: L1, L2: L2, P2: P2, H1: H1, r1Min: r1Min, r2: r2 };

    if (bottleneck) {
      var corners = [[z0, P1 / 2], [L1, P2 / 2], [L2, H1 / 2]];
      if (L3 !== undefined && H2 !== undefined) corners.push([L3, H2 / 2]);
      var radii = [];
      radii[1] = r1Min;
      radii[2] = r2;
      var body = applyFillets(corners, radii);
      for (var bi = 1; bi < body.length; bi++) outer.push(body[bi]);
    } else if (L3 !== undefined && H2 !== undefined) {
      outer.push([L3, H2 / 2]);
    }

    // ----- walls -----
    var tn = (H2 !== undefined && G1 !== undefined) ? (H2 - G1) / 2 : 0;
    if (tn < 0) tn = 0;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * (P1 / 2));
    var wallsE = E !== undefined ? E : 0;
    var w = 2.5;
    if (P1 > 0) w = Math.max(w, 0.25 * (P1 / 2));
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (belt) w = Math.max(w, belt.rampEndZ + tb);
    else if (groove) w = Math.max(w, wallsE + tb);
    var mouthZ = L3 !== undefined ? L3 : z0;

    function th(z) {
      if (bottleneck) {
        if (z <= L1) return tb;
        if (z >= L2) return tn;
        return tb + ((tn - tb) * (z - L1)) / (L2 - L1);
      }
      var span = mouthZ - z0;
      if (span <= 0) return tb;
      return tb + ((tn - tb) * clamp((z - z0) / span, 0, 1));
    }

    var rw = radiusAt(outer, w);
    if (isNaN(rw)) rw = P1 / 2;
    var inner = [[w, rw - th(w)]];
    for (var oi = 0; oi < outer.length; oi++) {
      var p = outer[oi];
      if (p[0] > w + 1e-12) inner.push([p[0], p[1] - th(p[0])]);
    }
    // the mouth is the last outer point; its inner counterpart uses tn
    var caseSection = [];
    if (pocket) caseSection.push([0, pocketR]); else caseSection.push([0, 0]);
    for (var oj = 1; oj < outer.length; oj++) caseSection.push(outer[oj]);
    for (var ik = inner.length - 1; ik >= 0; ik--) caseSection.push(inner[ik]);
    caseSection.push([w, 0]);
    if (pocket) {
      caseSection.push([pocket.depth, 0]);
      caseSection.push([pocket.depth, pocketR]);
    }
    caseSection = dedupe(caseSection);

    // ----- bullet -----
    var bullet = null;
    if (annotations.defaultBulletShape === undefined) notes.push("defaultBulletShape missing; drawn pointy");
    var bulletShape = annotations.defaultBulletShape || "pointy";
    if (L3 !== undefined && L6 !== undefined && G1 !== undefined) {
      var knownShapes = { pointy: 1, rounded: 1, flat: 1, semi_wadcutter: 1 };
      if (!knownShapes[bulletShape]) { notes.push("bullet shape " + bulletShape + " unknown; drawn pointy"); bulletShape = "pointy"; }
      var heeled = H2 !== undefined && H2 - G1 <= 0.015;
      var Dx = heeled ? H2 : G1;
      var Rb = Dx / 2;
      var isPistol = annotations.category === "pistol";
      var s, k, m, nose;
      if (bulletShape === "pointy") {
        s = 1.0 * G1; k = 0.4; m = Math.max(0.08 * Dx, 1.27); nose = "ogive";
      } else if (bulletShape === "rounded") {
        s = (isPistol ? 0.4 : 0.8) * G1; k = isPistol ? 0.65 : 0.55; m = 0.15 * Dx; nose = "ellipse";
      } else if (bulletShape === "flat") {
        s = (isPistol ? 0.4 : 0.8) * G1; k = isPistol ? 0.7 : 0.6; m = 0.55 * Dx; nose = "cone";
      } else {
        s = 0.6 * G1; k = 0.78; m = 0.6 * Dx; nose = "cone";
      }
      var zb = L3 - s;
      var Lb = L6 - zb;
      var zk = zb + k * Lb;
      var n = L6 - zk;
      var nosePoints = [];
      if (n <= 0) {
        notes.push("bullet nose has no length; drawn as flat");
        nosePoints = [[zk, Rb], [L6, 0]];
      } else if (nose === "ogive") {
        var aa = Rb - m / 2;
        var rho2 = (aa * aa + n * n) / (2 * aa);
        var cr2 = Rb - rho2;
        var phiEnd = Math.atan2(rho2 - aa, n);
        for (var q = 0; q <= 24; q++) {
          var ph = PI / 2 + (phiEnd - PI / 2) * (q / 24);
          nosePoints.push([zk + rho2 * Math.cos(ph), cr2 + rho2 * Math.sin(ph)]);
        }
        nosePoints[0] = [zk, Rb];
        nosePoints[nosePoints.length - 1] = [L6, m / 2];
      } else if (nose === "ellipse") {
        var bb = Rb - m / 2;
        for (var qe = 0; qe <= 24; qe++) {
          var t = (PI / 2) * (qe / 24);
          nosePoints.push([zk + n * Math.sin(t), m / 2 + bb * Math.cos(t)]);
        }
        nosePoints[0] = [zk, Rb];
        nosePoints[nosePoints.length - 1] = [L6, m / 2];
      } else {
        nosePoints = [[zk, Rb], [L6, m / 2]];
      }
      var seatedRadius = heeled ? (H2 - 2 * tb) / 2 : Rb;
      var exposedPoints = [[L3, Rb]].concat(nosePoints);
      bullet = {
        shape: bulletShape,
        nose: nose,
        heeled: heeled,
        s: s, k: k, m: m, zb: zb, Lb: Lb, zk: zk, n: n,
        exposedRadius: Rb,
        seatedRadius: seatedRadius,
        nosePoints: nosePoints,
        exposedPoints: exposedPoints,
        diameter: Dx
      };
    }

    // ----- silhouette and section polygons -----
    var exterior = outer.slice();
    if (bullet) {
      exterior = exterior.concat(bullet.exposedPoints);
      exterior.push([L6, 0]);
    }
    exterior = dedupe(exterior);

    var bulletSection = [];
    if (bullet) {
      bulletSection = [[bullet.zb, 0], [bullet.zb, bullet.seatedRadius], [L3, bullet.seatedRadius]]
        .concat(bullet.exposedPoints)
        .concat([[L6, 0]]);
      bulletSection = dedupe(bulletSection);
    }

    return {
      key: rec.key,
      name: rec.name,
      record: rec,
      rimType: rimType,
      family: rec.family,
      primer: primer,
      pocket: pocket,
      groove: groove,
      belt: belt,
      shoulder: shoulder,
      walls: { tn: tn, tb: tb, w: w },
      bullet: bullet,
      outer: outer,
      exterior: exterior,
      caseSection: caseSection,
      bulletSection: bulletSection,
      z0: z0,
      rimMidZ: rimMidZ,
      values: {
        R: R, R1: R1published, P1: P1, P2: P2, H1: H1, H2: H2, L1: L1, L2: L2, L3: L3, L6: L6, G1: G1,
        E: E, E1: E1, eMin: eMin, alpha: alpha
      },
      notes: notes
    };
  }

  // ---------- label and layout geometry ----------
  function boxesOverlap(a, b) {
    return a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3];
  }

  function orient(ax, ay, bx, by, cx, cy) {
    return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
  }

  function segmentsCross(s, t) {
    var d1 = orient(t[0], t[1], t[2], t[3], s[0], s[1]);
    var d2 = orient(t[0], t[1], t[2], t[3], s[2], s[3]);
    var d3 = orient(s[0], s[1], s[2], s[3], t[0], t[1]);
    var d4 = orient(s[0], s[1], s[2], s[3], t[2], t[3]);
    return d1 * d2 < 0 && d3 * d4 < 0;
  }

  function pointInBox(x, y, b) { return x > b[0] && x < b[2] && y > b[1] && y < b[3]; }

  // true when segment s (x1,y1,x2,y2) passes through the interior of box b
  function boxSegmentOverlap(b, s) {
    if (pointInBox(s[0], s[1], b) || pointInBox(s[2], s[3], b)) return true;
    var edges = [
      [b[0], b[1], b[2], b[1]], [b[2], b[1], b[2], b[3]],
      [b[2], b[3], b[0], b[3]], [b[0], b[3], b[0], b[1]]
    ];
    for (var i = 0; i < 4; i++) if (segmentsCross(s, edges[i])) return true;
    return false;
  }

  function textWidth(text, fs) { return text.length * 0.6 * fs; }

  function labelBox(text, xc, yc, fs) {
    var w = textWidth(text, fs);
    return [xc - w / 2, yc - fs / 1.6, xc + w / 2, yc + fs / 1.6];
  }

  function valueText(section, key) {
    if (!section || !isNum(section[key])) return null;
    var t = symbolFor(key) + " " + formatValue(key, section[key]);
    if (Object.prototype.hasOwnProperty.call(section, key + "Tol")) t += " " + formatNumber(section[key + "Tol"]);
    return t;
  }

  // Build the list of drawn outline segments for the given geometry.
  function outlineSegmentsOf(geom) {
    var out = [];
    var ex = geom.exterior;
    for (var i = 0; i < ex.length - 1; i++) {
      var a = ex[i], b = ex[i + 1];
      out.push([a[0], -a[1], b[0], -b[1]]);
      out.push([a[0], a[1], b[0], b[1]]);
    }
    return out;
  }

  function layoutDrawing(geom) {
    var notes = geom.notes.slice();
    var V = geom.values;
    var outlineSegs = outlineSegmentsOf(geom);
    var Rg = 0;
    geom.exterior.forEach(function (p) { Rg = Math.max(Rg, p[1]); });
    var Lmax = V.L6 !== undefined ? V.L6 : (V.L3 !== undefined ? V.L3 : 30);
    var fs = clamp(0.03 * (Lmax + 10), 1.2, 3.2);
    var sp = fs * 1.9 + 1.0;
    var gap = 0.8;
    var arrow = 0.6 * fs + 0.4;
    var hw = arrow * 0.35;
    var K = 10;
    var placed = { lines: [], labels: [], arrows: [] };
    var result = [];

    function arrowAt(tx, ty, dx, dy) {
      var l = Math.hypot(dx, dy) || 1;
      return [tx, ty, dx / l, dy / l];
    }

    function evaluate(cand) {
      for (var i = 0; i < placed.labels.length; i++) {
        if (boxesOverlap(padBox(cand.label.box, 0.3), padBox(placed.labels[i].box, 0.3))) return null;
      }
      for (var j = 0; j < outlineSegs.length; j++) {
        if (boxSegmentOverlap(padBox(cand.label.box, 0.3), outlineSegs[j])) return null;
      }
      var cost = 0;
      cand.lines.forEach(function (ln) {
        placed.lines.forEach(function (pl) { if (segmentsCross(ln, pl)) cost++; });
        placed.labels.forEach(function (pb) { if (boxSegmentOverlap(pb.box, ln)) cost += 2; });
      });
      placed.lines.forEach(function (pl) { if (boxSegmentOverlap(cand.label.box, pl)) cost += 2; });
      return cost;
    }

    function padBox(b, p) { return [b[0] - p, b[1] - p, b[2] + p, b[3] + p]; }

    function place(item, candidates) {
      var best = null, bestCost = Infinity;
      candidates.forEach(function (c) {
        var cost = evaluate(c);
        if (cost !== null && cost < bestCost) { best = c; bestCost = cost; }
      });
      if (!best) { notes.push(item.id + " label could not be placed"); return; }
      best.lines.forEach(function (ln) { placed.lines.push(ln); });
      placed.labels.push({ text: best.label.text, box: best.label.box, id: item.id });
      placed.arrows = placed.arrows.concat(best.arrows);
      result.push({ id: item.id, text: best.label.text, box: best.label.box, lines: best.lines, arrows: best.arrows, x: best.label.x, y: best.label.y });
    }

    // Horizontal length dimension between two features on the axis direction.
    function hCandidates(xa, ra, xb, rb, pref, text, id) {
      var cands = [];
      [pref, -pref].forEach(function (side) {
        for (var k = 0; k < K; k++) {
          var yl = side * (Rg + 2.6 + k * sp);
          var mid = (xa + xb) / 2;
          var yc = yl + side * (0.8 + fs / 2);
          var dir = xb >= xa ? 1 : -1;
          var lines = [
            [xa, side * (ra + gap), xa, yl + side * 1.0],
            [xb, side * (rb + gap), xb, yl + side * 1.0],
            [xa, yl, xb, yl]
          ];
          var arrows = [arrowAt(xa, yl, -dir, 0), arrowAt(xb, yl, dir, 0)];
          cands.push({ lines: lines, arrows: arrows, label: { text: text, x: mid, y: yc, box: labelBox(text, mid, yc, fs) } });
        }
      });
      return cands;
    }

    // Diametral dimension: vertical dimension line across the feature, label in a lane outside.
    function vCandidates(zf, r, pref, text) {
      var cands = [];
      [pref, -pref].forEach(function (side) {
        for (var k = 0; k < K; k++) {
          var yc = side * (Rg + 2.6 + fs / 2 + k * sp);
          var edge = yc - side * fs / 2;
          var lines = [
            [zf, -r, zf, r],
            [zf, edge, zf, side * r]
          ];
          var arrows = [arrowAt(zf, -r, 0, -1), arrowAt(zf, r, 0, 1)];
          cands.push({ lines: lines, arrows: arrows, label: { text: text, x: zf, y: yc, box: labelBox(text, zf, yc, fs) } });
        }
      });
      return cands;
    }

    function leaderOnly(zf, rr, pref, text) {
      var cands = [];
      [pref, -pref].forEach(function (side) {
        for (var k = 0; k < K; k++) {
          var yc = side * (Rg + 2.6 + fs / 2 + k * sp);
          var edge = yc - side * fs / 2;
          cands.push({ lines: [[zf, edge, zf, side * rr]], arrows: [], label: { text: text, x: zf, y: yc, box: labelBox(text, zf, yc, fs) } });
        }
      });
      return cands;
    }

    var items = [];
    function addH(id, xa, ra, xb, rb, pref, valueSec, key) {
      var text = valueText(valueSec, key);
      if (!isNum(xa) || !isNum(xb) || !isNum(ra) || !isNum(rb) || text === null) {
        notes.push(id + " dimension omitted: value missing");
        return;
      }
      items.push({ id: id, make: function () { return hCandidates(xa, ra, xb, rb, pref, text, id); } });
    }
    function addV(id, zf, r, pref, text) {
      if (!isNum(zf) || !isNum(r) || r <= 0 || text === null) { notes.push(id + " dimension omitted: value missing"); return; }
      items.push({ id: id, make: function () { return vCandidates(zf, r, pref, text); } });
    }

    var rec = geom.record;
    var cart = rec.cartridge;
    var R1r = V.R1 !== undefined ? V.R1 / 2 : V.P1 / 2;
    var P1r = V.P1 / 2;
    var rimZ = geom.rimMidZ;
    var bn = geom.shoulder.bottleneck;
    var mouthR = V.H2 !== undefined ? V.H2 / 2 : 0;
    var tipR = geom.bullet ? geom.bullet.m / 2 : 0;

    addH("L6", 0, R1r, V.L6, tipR, -1, cart.lengths, "L6");
    addH("L3", 0, R1r, V.L3, mouthR, 1, cart.lengths, "L3");
    if (bn) {
      addH("L1", 0, R1r, V.L1, V.P2 / 2, 1, cart.lengths, "L1");
      addH("L2", 0, R1r, V.L2, V.H1 / 2, -1, cart.lengths, "L2");
    }
    if (V.R > 0) addH("R", 0, R1r, V.R, R1r, -1, cart.caseHead, "R");

    addV("R1", rimZ, R1r, -1, valueText(cart.caseHead, "R1"));
    addV("P1", geom.z0, P1r, -1, valueText(cart.powderChamber, "P1"));
    if (geom.groove && V.E1 !== undefined) {
      addV("E1", V.R + (V.eMin !== undefined ? V.eMin / 2 : 0), V.E1 / 2, -1, valueText(cart.caseHead, "E1"));
    }
    if (bn) {
      addV("P2", V.L1, V.P2 / 2, -1, valueText(cart.powderChamber, "P2"));
      addV("H1", V.L2, V.H1 / 2, -1, valueText(cart.collar, "H1"));
    }
    if (V.H2 !== undefined) {
      var zH2 = V.L3 - (bn ? Math.min(1.2, 0.3 * (V.L3 - V.L2)) : 1.2);
      addV("H2", zH2, V.H2 / 2, -1, valueText(cart.collar, "H2"));
    }
    if (geom.bullet) {
      var zm = (geom.bullet.zk + V.L3) / 2;
      addV("G1", zm, geom.bullet.exposedRadius, -1, valueText(cart.projectile, "G1"));
    }
    if (bn && geom.shoulder.alpha !== undefined) {
      var zA = (V.L1 + V.L2) / 2;
      var rA = (V.P2 / 2 + V.H1 / 2) / 2;
      var alphaText = "α " + formatAngle(cart.junctionCone.alpha);
      items.push({ id: "alpha", make: function () { return leaderOnly(zA, rA, -1, alphaText); } });
    }

    items.forEach(function (it) { place(it, it.make()); });

    // Bounding box of everything drawn.
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    function grow(x, y) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
    outlineSegs.forEach(function (s) { grow(s[0], s[1]); grow(s[2], s[3]); });
    result.forEach(function (r) {
      grow(r.box[0], r.box[1]);
      grow(r.box[2], r.box[3]);
      r.lines.forEach(function (ln) { grow(ln[0], ln[1]); grow(ln[2], ln[3]); });
    });
    var pad = 1.5;
    var viewBox = { x: minX - pad, y: minY - pad, w: maxX - minX + 2 * pad, h: maxY - minY + 2 * pad };

    var labels = result.map(function (r) { return { text: r.text, box: r.box, x: r.x, y: r.y, id: r.id }; });
    var lines = [];
    result.forEach(function (r) { r.lines.forEach(function (ln) { lines.push(ln); }); });
    var arrows = [];
    result.forEach(function (r) { r.arrows.forEach(function (a) { arrows.push(a); }); });

    return {
      fs: fs,
      arrowLength: arrow,
      arrowHalfWidth: hw,
      labels: labels,
      lines: lines,
      arrows: arrows,
      outlineSegments: outlineSegs,
      viewBox: viewBox,
      notes: notes,
      Rg: Rg
    };
  }

  return {
    isNum: isNum,
    angleDegrees: angleDegrees,
    formatNumber: formatNumber,
    formatAngle: formatAngle,
    formatValue: formatValue,
    symbolFor: symbolFor,
    unitFor: unitFor,
    rimTypeOf: rimTypeOf,
    primerPocket: primerPocket,
    matchesQuery: matchesQuery,
    filterCartridges: filterCartridges,
    sectionTables: sectionTables,
    radiusAt: radiusAt,
    applyFillets: applyFillets,
    computeGeometry: computeGeometry,
    layoutDrawing: layoutDrawing,
    boxesOverlap: boxesOverlap,
    boxSegmentOverlap: boxSegmentOverlap,
    segmentsCross: segmentsCross
  };
});
