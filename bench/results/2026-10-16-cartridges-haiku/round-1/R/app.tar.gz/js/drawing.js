/* Inline SVG drawing of a cartridge: outside view (upper half), section (lower half),
   dimension lines and labels. One SVG user unit is one millimetre. */
(function (root, factory) {
  "use strict";
  var api = factory(
    typeof module === "object" && module.exports
      ? require("./core.js")
      : root.CartridgeCore
  );
  if (typeof module === "object" && module.exports) module.exports = api;
  root.CartridgeDrawing = api;
})(typeof window !== "undefined" ? window : globalThis, function (core) {
  "use strict";

  function esc(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function num(v) {
    var s = Number(v).toFixed(3);
    s = s.replace(/\.?0+$/, "");
    if (s === "-0") s = "0";
    return s;
  }

  function pathFromPoints(points, mapY, close) {
    var d = "";
    points.forEach(function (p, i) {
      d += (i === 0 ? "M" : "L") + num(p[0]) + " " + num(mapY(p[1])) + " ";
    });
    return d + (close ? "Z" : "");
  }

  function linesPath(lines) {
    var d = "";
    lines.forEach(function (l) {
      d += "M" + num(l[0]) + " " + num(l[1]) + "L" + num(l[2]) + " " + num(l[3]);
    });
    return d;
  }

  function arrowsPath(arrows, len, hw) {
    var d = "";
    arrows.forEach(function (a) {
      var tx = a[0], ty = a[1], dx = a[2], dy = a[3];
      var bx = tx - dx * len, by = ty - dy * len;
      var px = -dy * hw, py = dx * hw;
      d += "M" + num(tx) + " " + num(ty) + "L" + num(bx + px) + " " + num(by + py) +
        "L" + num(bx - px) + " " + num(by - py) + "Z";
    });
    return d;
  }

  // Returns { svg, geometry, layout } for a record.
  function drawingFor(record) {
    var geom = core.computeGeometry(record);
    var lay = core.layoutDrawing(geom);
    var vb = lay.viewBox;
    var id = "hatch-" + String(record.key).replace(/[^a-zA-Z0-9_-]/g, "_");
    var name = record.name;

    var outlineD = pathFromPoints(geom.exterior, function (r) { return -r; }, true);
    var caseD = pathFromPoints(geom.caseSection, function (r) { return r; }, true);
    var bulletD = geom.bulletSection.length
      ? pathFromPoints(geom.bulletSection, function (r) { return r; }, true)
      : "";

    var parts = [];
    parts.push('<svg xmlns="http://www.w3.org/2000/svg" class="cart-drawing" role="img" aria-label="' +
      esc(name) + ' drawing" viewBox="' + [num(vb.x), num(vb.y), num(vb.w), num(vb.h)].join(" ") +
      '" preserveAspectRatio="xMidYMid meet">');
    parts.push("<defs><pattern id=\"" + id + "\" patternUnits=\"userSpaceOnUse\" width=\"1.1\" height=\"1.1\" patternTransform=\"rotate(45)\">" +
      "<line x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1.1\" stroke=\"currentColor\" stroke-width=\"0.12\"/></pattern></defs>");
    parts.push("<line class=\"centre\" x1=\"" + num(vb.x) + "\" y1=\"0\" x2=\"" + num(vb.x + vb.w) + "\" y2=\"0\"/>");
    parts.push("<path class=\"outline\" d=\"" + outlineD + "\"/>");
    parts.push("<path class=\"section\" fill=\"url(#" + id + ")\" d=\"" + caseD + "\"/>");
    if (bulletD) parts.push("<path class=\"section\" fill=\"url(#" + id + ")\" d=\"" + bulletD + "\"/>");
    parts.push("<path class=\"dim\" d=\"" + linesPath(lay.lines) + "\"/>");
    parts.push("<path class=\"arrow\" d=\"" + arrowsPath(lay.arrows, lay.arrowLength, lay.arrowHalfWidth) + "\"/>");
    lay.labels.forEach(function (l) {
      parts.push("<text class=\"dimlabel\" x=\"" + num(l.x) + "\" y=\"" + num(l.y) +
        "\" font-size=\"" + num(lay.fs) + "\" text-anchor=\"middle\" dominant-baseline=\"central\">" +
        esc(l.text) + "</text>");
    });
    parts.push("</svg>");

    return { svg: parts.join(""), geometry: geom, layout: lay, notes: lay.notes };
  }

  return { drawingFor: drawingFor, esc: esc };
});
