"use strict";
// Dev-only browser check (Playwright + Chromium). Opens index.html from disk (file://),
// verifies list, search, filter, detail view, reload, phone layout, dark mode and print.
// Run: node tests/browser.check.js   (screenshots and the print PDF go to /tmp/cartridge-check)
const path = require("path");
const fs = require("fs");
const assert = require("assert/strict");
const { chromium } = require("playwright");

const INDEX = "file://" + path.resolve(__dirname, "..", "index.html");
const OUT = "/tmp/cartridge-check";

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || undefined,
    args: process.env.CHROMIUM_PATH ? ["--no-sandbox", "--disable-gpu", "--no-zygote"] : []
  });
  const failures = [];
  const requests = [];
  const consoleErrors = [];
  const check = async (name, fn) => {
    try { await fn(); console.log("ok   " + name); }
    catch (e) { failures.push(name + ": " + e.message); console.log("FAIL " + name + "\n     " + e.message); }
  };

  const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, colorScheme: "light" });
  context.on("request", (r) => requests.push(r.url()));
  const page = await context.newPage();
  page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text()); });
  page.on("pageerror", (e) => consoleErrors.push(String(e)));

  const clearSearch = async () => {
    await page.focus("#q");
    await page.keyboard.press("Control+A");
    await page.keyboard.press("Backspace");
  };

  await check("opens from file:// with title and heading", async () => {
    await page.goto(INDEX);
    assert.equal(await page.title(), "Cartridges");
    assert.equal(await page.locator("h1").first().textContent(), "Cartridges");
  });

  await check("lists 25 cartridges with exact name links", async () => {
    assert.equal(await page.locator("#count").textContent(), "25 cartridges");
    const names = await page.locator("#list a").allTextContents();
    assert.equal(names.length, 25);
    assert.ok(names.includes("6,5 Creedmoor"));
    assert.ok(names.includes("22 Long Rifle"));
  });

  await check("search finds 308 Win. by alternative name '7,62 x 51'", async () => {
    await page.fill("#q", "7,62 x 51");
    assert.equal(await page.locator("#count").textContent(), "1 cartridge");
    assert.equal(await page.locator("#list a").first().textContent(), "308 Win.");
    await clearSearch();
  });

  await check("family select filters (rimfire = 3)", async () => {
    await page.selectOption("#fam", "rimfire");
    assert.equal(await page.locator("#count").textContent(), "3 cartridges");
    await page.selectOption("#fam", "All");
    assert.equal(await page.locator("#count").textContent(), "25 cartridges");
  });

  await check("labels are associated with controls", async () => {
    assert.equal(await page.getByLabel("Search").count(), 1);
    assert.equal(await page.getByLabel("Family").count(), 1);
  });

  await check("detail view opens from a name link and has its own address", async () => {
    await page.locator("#list a", { hasText: /^223 Rem\.$/ }).click();
    await page.waitForURL(/#\/cartridge\/223_rem$/);
    assert.equal(await page.locator("h1.cart-name").textContent(), "223 Rem.");
    assert.equal(await page.locator('svg[aria-label="223 Rem. drawing"]').count(), 1);
  });

  await check("detail view survives reload", async () => {
    await page.reload();
    assert.equal(await page.locator("h1.cart-name").textContent(), "223 Rem.");
    assert.ok((await page.locator(".values").count()) >= 10);
  });

  await check("tables show tolerance next to value and no tolerance rows", async () => {
    const rows = await page.locator("table.values tbody tr").allTextContents();
    assert.ok(rows.some((t) => t.includes("L1") && t.includes("36.52 -0.2")), "L1 row");
    assert.ok(!rows.some((t) => /Tol/.test(t)), "no Tol rows");
  });

  await check("drawing labels show the symbol and value", async () => {
    const labels = await page.locator("svg.cart-drawing text.dimlabel").allTextContents();
    assert.ok(labels.includes("L3 44.7"), labels.join("|"));
    assert.ok(labels.some((t) => t.startsWith("α ")));
  });

  await check("'All cartridges' link returns to the list", async () => {
    await page.locator("a.back").first().click();
    await page.waitForURL(/#\/?$/);
    assert.equal(await page.locator("#count").textContent(), "25 cartridges");
  });

  await check("unknown key shows not-found message", async () => {
    await page.goto(INDEX + "#/cartridge/nope");
    assert.equal(await page.locator("h1").textContent(), "Cartridge not found");
  });

  await page.goto(INDEX + "#/cartridge/22_long_rifle");
  await page.screenshot({ path: OUT + "/desktop-22lr.png", fullPage: true });

  await check("no horizontal overflow on a phone (390 px)", async () => {
    const phone = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
    const p = await phone.newPage();
    p.on("pageerror", (e) => consoleErrors.push(String(e)));
    await p.goto(INDEX + "#/cartridge/9_3_x_74_r");
    await p.waitForSelector("svg.cart-drawing");
    const { sw, cw } = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    assert.ok(sw <= cw + 1, "scrollWidth " + sw + " > " + cw);
    await p.screenshot({ path: OUT + "/phone-93x74r.png", fullPage: false });
    await p.goto(INDEX);
    await p.screenshot({ path: OUT + "/phone-list.png", fullPage: false });
    await phone.close();
  });

  await check("dark mode follows the system setting", async () => {
    const dark = await browser.newContext({ viewport: { width: 1000, height: 800 }, colorScheme: "dark" });
    const p = await dark.newPage();
    await p.goto(INDEX + "#/cartridge/308_win");
    const bg = await p.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.notEqual(bg, "rgb(255, 255, 255)");
    assert.notEqual(bg, "rgba(0, 0, 0, 0)");
    await p.screenshot({ path: OUT + "/dark-308.png", fullPage: true });
    await dark.close();
  });

  await check("print: one A4 portrait page, no navigation or buttons", async () => {
    await page.goto(INDEX + "#/cartridge/308_win");
    await page.emulateMedia({ media: "print" });
    const hidden = await page.evaluate(() => getComputedStyle(document.querySelector(".toolbar")).display);
    assert.equal(hidden, "none");
    const pdf = await page.pdf({ format: "A4", printBackground: true, preferCSSPageSize: true });
    fs.writeFileSync(OUT + "/print-308.pdf", pdf);
    const pages = (pdf.toString("latin1").match(/\/Type\s*\/Page[^s]/g) || []).length;
    assert.equal(pages, 1, "pages = " + pages);
    await page.emulateMedia({ media: "screen" });
  });

  await check("print button calls window.print", async () => {
    await page.goto(INDEX + "#/cartridge/308_win");
    await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
    await page.locator("button.print").click();
    assert.equal(await page.evaluate(() => window.__printed), 1);
  });

  await check("no network requests other than file://", async () => {
    const bad = requests.filter((u) => !u.startsWith("file://") && !u.startsWith("data:"));
    assert.deepEqual(bad, []);
  });

  await check("no console errors", async () => {
    assert.deepEqual(consoleErrors, []);
  });

  await browser.close();
  if (failures.length) {
    console.log("\n" + failures.length + " browser check(s) failed");
    process.exit(1);
  }
  console.log("\nall browser checks passed; artefacts in " + OUT);
})().catch((e) => { console.error(e); process.exit(1); });
