"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const records = require("../js/data.js");
const C = require("../js/core.js");

const rec = (key) => {
  const r = records.find((x) => x.key === key);
  if (!r) throw new Error("no record " + key);
  return r;
};
const near = (a, b, eps, msg) =>
  assert.ok(Math.abs(a - b) <= (eps || 1e-6), (msg || "") + " expected " + b + " got " + a);
const tan = (deg) => Math.tan((deg * Math.PI) / 180);

// ---------- data ----------
test("data: 25 records with unique keys", () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
});

// ---------- formatting ----------
test("formatNumber keeps published values, no thousands separator", () => {
  assert.equal(C.formatNumber(51.18), "51.18");
  assert.equal(C.formatNumber(4150), "4150");
  assert.equal(C.formatNumber(-0.2), "-0.2");
  assert.equal(C.formatNumber(0), "0");
});

test("formatAngle: numeric degrees and {degrees, minutes, seconds}", () => {
  assert.equal(C.formatAngle(40), "40°");
  assert.equal(C.formatAngle(0), "0°");
  assert.equal(C.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), "39°59'49\"");
  assert.equal(C.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), "3°10'36\"");
});

test("symbols follow the brief", () => {
  const cases = {
    eMin: "e min", r1Min: "r1 min", r1Max: "r1 max", alpha: "α", alpha1: "α1",
    beta: "β", delta: "δ", deltaL: "delta L", L3PlusG: "L3 + G", L3: "L3", r2: "r2", H1: "H1",
  };
  for (const [field, sym] of Object.entries(cases)) assert.equal(C.symbolFor(field), sym, field);
});

test("units follow the brief; lengths default to mm", () => {
  assert.equal(C.unitFor("Pmax"), "bar");
  assert.equal(C.unitFor("PE"), "bar");
  assert.equal(C.unitFor("EE"), "J");
  assert.equal(C.unitFor("M"), "g");
  assert.equal(C.unitFor("Q"), "mm²");
  assert.equal(C.unitFor("N"), "—");
  assert.equal(C.unitFor("alpha"), "—");
  assert.equal(C.unitFor("L1"), "mm");
  assert.equal(C.unitFor("u"), "mm");
});

// ---------- classification ----------
test("rim type: belted, rimfire, rimmed, rimless", () => {
  assert.equal(C.rimTypeOf(rec("300_win_mag")), "belted");
  assert.equal(C.rimTypeOf(rec("22_long_rifle")), "rimfire");
  assert.equal(C.rimTypeOf(rec("9_3_x_74_r")), "rimmed");
  assert.equal(C.rimTypeOf(rec("38_special")), "rimmed");
  assert.equal(C.rimTypeOf(rec("9_mm_luger")), "rimless");
  assert.equal(C.rimTypeOf(rec("223_rem")), "rimless");
});

test("rim type: R1/P1 below 0.98 is rebated", () => {
  const synthetic = { family: "rimless", cartridge: { caseHead: { R1: 9 }, powderChamber: { P1: 10 } } };
  assert.equal(C.rimTypeOf(synthetic), "rebated");
});

test("primer pocket diameter and depth", () => {
  assert.deepEqual(C.primerPocket("sp"), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(C.primerPocket("spm"), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(C.primerPocket("sr"), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(C.primerPocket("lp"), { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(C.primerPocket("lpm"), { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(C.primerPocket("lr"), { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(C.primerPocket("lrm"), { diameter: 5.33, depth: 3.3 });
  assert.equal(C.primerPocket("rimfire"), null);
});

// ---------- search and filter ----------
test("search matches names and alternative names, ignoring spaces and case", () => {
  assert.ok(C.matchesQuery(rec("308_win"), "7,62 x 51"));
  assert.ok(C.matchesQuery(rec("308_win"), "7,62x51"));
  assert.ok(C.matchesQuery(rec("6_5_creedmoor"), "creedmoor"));
  assert.ok(C.matchesQuery(rec("22_long_rifle"), "22lr"));
  assert.ok(C.matchesQuery(rec("22_long_rifle"), ""));
  assert.ok(!C.matchesQuery(rec("308_win"), "223"));
});

test("family filter and family counts", () => {
  const count = (fam) => C.filterCartridges(records, "", fam).length;
  assert.equal(count("All"), 25);
  assert.equal(count("rimless"), 12);
  assert.equal(count("rimmed"), 2);
  assert.equal(count("belted"), 2);
  assert.equal(count("pistol"), 6);
  assert.equal(count("rimfire"), 3);
  assert.equal(C.filterCartridges(records, "308", "rimless").length, 1);
});

// ---------- tables ----------
test("tables merge tolerances into the value and never make a row for them", () => {
  const t = C.sectionTables(rec("223_rem"));
  const lengths = t.cartridge.find((s) => s.id === "lengths");
  const l1 = lengths.rows.find((r) => r.symbol === "L1");
  assert.equal(l1.value, "36.52 -0.2");
  assert.equal(l1.unit, "mm");
  assert.ok(!lengths.rows.some((r) => /Tol/.test(r.symbol)));
});

test("table angles and numbers are formatted", () => {
  const t = C.sectionTables(rec("223_rem"));
  const rifling = t.chamber.find((s) => s.id === "rifling");
  assert.equal(rifling.rows.find((r) => r.symbol === "i").value, "3°10'36\"");
  const head = t.cartridge.find((s) => s.id === "caseHead");
  assert.equal(head.rows.find((r) => r.symbol === "β").value, "35°");
  assert.equal(head.rows.find((r) => r.symbol === "e min").value, "0.76");
  assert.equal(t.cartridge.find((s) => s.id === "pressures").rows.find((r) => r.symbol === "Pmax").value, "4300");
});

// ---------- geometry: bullet ----------
test("bullet seating, cylinder end and nose start for a pointy bullet (223 Rem.)", () => {
  const g = C.computeGeometry(rec("223_rem"));
  const b = g.bullet;
  assert.equal(b.shape, "pointy");
  near(b.zb, 44.7 - 5.7, 1e-9, "zb");
  const Lb = 57.4 - (44.7 - 5.7);
  near(b.zk, b.zb + 0.4 * Lb, 1e-9, "zk");
  near(b.m, 1.27, 1e-9, "meplat m = max(0.08 G1, 1.27)");
});

test("pointy ogive is a tangent arc of radius rho ending at the meplat", () => {
  const g = C.computeGeometry(rec("223_rem"));
  const b = g.bullet;
  const G1 = 5.7;
  const m = 1.27;
  const R = G1 / 2;
  const n = 57.4 - b.zk;
  const a = R - m / 2;
  const rho = (a * a + n * n) / (2 * a);
  const cz = b.zk;
  const cr = R - rho;
  const pts = b.nosePoints;
  assert.ok(pts.length > 5);
  for (const [z, r] of pts) {
    const d = Math.hypot(z - cz, r - cr);
    near(d, rho, 1e-6, "point on arc");
  }
  const last = pts[pts.length - 1];
  near(last[0], 57.4, 1e-9, "tip z");
  near(last[1], m / 2, 1e-9, "meplat radius");
  near(pts[0][0], b.zk, 1e-9, "nose starts at zk");
  near(pts[0][1], R, 1e-9, "nose starts at G1/2");
});

test("rounded pistol bullet: seating 0.4 G1, k 0.65, quarter-ellipse nose with m = 0.15 G1", () => {
  const g = C.computeGeometry(rec("9_mm_luger"));
  const b = g.bullet;
  assert.equal(b.shape, "rounded");
  const G1 = 9.03;
  near(b.zb, 19.15 - 0.4 * G1, 1e-9, "zb");
  const Lb = 29.69 - b.zb;
  near(b.zk, b.zb + 0.65 * Lb, 1e-9, "zk");
  const m = 0.15 * G1;
  near(b.m, m, 1e-9, "m");
  const R = G1 / 2;
  const n = 29.69 - b.zk;
  const bb = R - m / 2;
  for (const [z, r] of b.nosePoints) {
    const e = ((z - b.zk) / n) ** 2 + ((r - m / 2) / bb) ** 2;
    near(e, 1, 1e-6, "ellipse");
  }
});

test("flat pistol bullet: k 0.70 and straight cone to m = 0.55 G1", () => {
  const g = C.computeGeometry(rec("40_s_w"));
  const b = g.bullet;
  assert.equal(b.shape, "flat");
  const G1 = 10.17;
  near(b.m, 0.55 * G1, 1e-9);
  const Lb = 28.83 - b.zb;
  near(b.zk, b.zb + 0.7 * Lb, 1e-9);
  const first = b.nosePoints[0];
  const last = b.nosePoints[b.nosePoints.length - 1];
  near(last[1], 0.55 * G1 / 2, 1e-9);
  near(last[0], 28.83, 1e-9);
  near(first[0], b.zk, 1e-9);
});

test("semi-wadcutter seats at 0.6 G1 with k 0.78 and m = 0.6 G1", () => {
  const g = C.computeGeometry(rec("357_magnum"));
  const b = g.bullet;
  assert.equal(b.shape, "semi_wadcutter");
  const G1 = 9.12;
  near(b.zb, 32.77 - 0.6 * G1, 1e-9);
  near(b.m, 0.6 * G1, 1e-9);
});

test("heeled 22 Long Rifle: exposed bullet has case outside diameter, heel has H2 - 2 tb", () => {
  const g = C.computeGeometry(rec("22_long_rifle"));
  assert.equal(g.bullet.heeled, true);
  near(g.bullet.exposedRadius, 5.72 / 2, 1e-9);
  near(g.walls.tb, 0.6, 1e-9);
  near(g.bullet.seatedRadius, (5.72 - 2 * 0.6) / 2, 1e-9);
});

// ---------- geometry: walls and head ----------
test("walls: tn = (H2 - G1)/2 and tb = min(max(1.3 tn, 0.6), 0.35 P1/2)", () => {
  const g = C.computeGeometry(rec("223_rem"));
  near(g.walls.tn, (6.43 - 5.7) / 2, 1e-9);
  near(g.walls.tb, 0.6, 1e-9);
  const g2 = C.computeGeometry(rec("9_3_x_62"));
  near(g2.walls.tn, (9.92 - 9.3) / 2, 1e-9);
});

test("solid head depth w for a centrefire rifle case with a groove (223 Rem.)", () => {
  const g = C.computeGeometry(rec("223_rem"));
  assert.deepEqual(g.pocket, { diameter: 4.45, depth: 3.04 });
  near(g.walls.w, 3.04 + 1.5, 1e-9);
});

test("rimfire: no primer pocket, w = max(2.5, 0.25 P1/2)", () => {
  const g = C.computeGeometry(rec("22_long_rifle"));
  assert.equal(g.pocket, null);
  near(g.walls.w, 2.5, 1e-9);
});

test("belted 300 Win. Mag.: belt ramp at angle delta from the axis, w uses ramp end + tb", () => {
  const g = C.computeGeometry(rec("300_win_mag"));
  const r = g.belt;
  assert.ok(r, "belt present");
  near(r.rampEndZ, (0.94 + 1.27) + (13.51 / 2 - 12.07 / 2) / tan(35), 1e-9);
  near(r.radius, 13.51 / 2, 1e-9);
  near(g.walls.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, r.rampEndZ + g.walls.tb), 1e-9);
});

// ---------- geometry: case outline ----------
test("chamfer on the 9,3 x 74 R head (beta 45, f 0.3)", () => {
  const g = C.computeGeometry(rec("9_3_x_74_r"));
  const pts = g.outer;
  const R1h = 13.35 / 2;
  near(pts[1][0], 0, 1e-9);
  near(pts[1][1], R1h - 0.3, 1e-9, "chamfer start on face");
  near(pts[2][0], 0.3, 1e-9);
  near(pts[2][1], R1h, 1e-9, "chamfer end at rim");
});

test("rimfire rim: half-round whose outermost point is at R1/2", () => {
  const g = C.computeGeometry(rec("22_long_rifle"));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const maxR = Math.max(...g.outer.map((p) => p[1]));
  near(maxR, 7.06 / 2, 1e-6, "outermost rim point");
  assert.ok(g.outer.some(([z, r]) => Math.abs(z - rho) < 1e-6 && Math.abs(r - 7.06 / 2) < 1e-6));
});

test("no extractor groove steps from R to P1/2 (9,3 x 74 R has no E)", () => {
  const g = C.computeGeometry(rec("9_3_x_74_r"));
  assert.equal(g.groove, false);
  const last = g.outer[g.outer.length - 1];
  assert.ok(g.outer.some(([z, r]) => z === 1.4 && Math.abs(r - 11.9 / 2) < 1e-9));
  assert.ok(last[0] > 1.5);
});

test("extractor groove follows R, E1/2 floor and ramp to P1/2 at E", () => {
  const g = C.computeGeometry(rec("223_rem"));
  assert.ok(g.outer.some(([z, r]) => z === 1.14 && Math.abs(r - 8.43 / 2) < 1e-9), "floor start");
  assert.ok(g.outer.some(([z, r]) => Math.abs(z - (1.14 + 0.76)) < 1e-9 && Math.abs(r - 8.43 / 2) < 1e-9), "floor end");
  assert.ok(g.outer.some(([z, r]) => Math.abs(z - 3.13) < 1e-9 && Math.abs(r - 9.58 / 2) < 1e-9), "ramp to body");
});

test("bottleneck: body corner rounded with r1 min, neck corner with r2", () => {
  const g = C.computeGeometry(rec("223_rem"));
  assert.equal(g.shoulder.bottleneck, true);
  assert.ok(g.outer.some(([z]) => z > 36.52 - 1 && z < 36.52 + 0.1), "points near L1");
  // the fillets keep the outline monotonic in z
  for (let i = 1; i < g.outer.length; i++) assert.ok(g.outer[i][0] >= g.outer[i - 1][0] - 1e-9, "monotone z at " + i);
});

test("straight case (9 mm Luger): body runs from P1/2 to H2/2 at L3", () => {
  const g = C.computeGeometry(rec("9_mm_luger"));
  assert.equal(g.shoulder.bottleneck, false);
  const last = g.outer.find((p) => p[0] === 19.15);
  assert.ok(last, "mouth point");
  near(last[1], 9.65 / 2, 1e-9);
});

// ---------- missing values ----------
test("a missing value is reported and its feature omitted, never invented", () => {
  const r = JSON.parse(JSON.stringify(rec("223_rem")));
  delete r.cartridge.powderChamber.P2;
  const g = C.computeGeometry(r);
  assert.ok(g.notes.some((n) => /P2/.test(n)), "P2 reported");
  assert.equal(g.shoulder.bottleneck, false);
});

// ---------- layout ----------
test("dimension labels: symbol and value, tolerance next to value", () => {
  const lay = C.layoutDrawing(C.computeGeometry(rec("223_rem")));
  const texts = lay.labels.map((l) => l.text);
  assert.ok(texts.includes("L3 44.7"), texts.join(" | "));
  assert.ok(texts.includes("L1 36.52 -0.2"), texts.join(" | "));
  assert.ok(texts.includes("L6 57.4"));
  assert.ok(texts.some((t) => t.startsWith("α ")), "alpha label");
});

test("labels do not overlap each other or the outline, for all 25 cartridges", () => {
  for (const r of records) {
    const lay = C.layoutDrawing(C.computeGeometry(r));
    const boxes = lay.labels.map((l) => l.box);
    for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        assert.ok(!C.boxesOverlap(boxes[i], boxes[j]), r.key + ": labels " + lay.labels[i].text + " / " + lay.labels[j].text);
      }
      for (const seg of lay.outlineSegments) {
        assert.ok(!C.boxSegmentOverlap(boxes[i], seg), r.key + ": label " + lay.labels[i].text + " overlaps outline");
      }
    }
  }
});

test("view box contains every drawn element", () => {
  for (const r of records) {
    const lay = C.layoutDrawing(C.computeGeometry(r));
    const vb = lay.viewBox;
    for (const b of lay.labels.map((l) => l.box)) {
      assert.ok(b[0] >= vb.x && b[2] <= vb.x + vb.w && b[1] >= vb.y && b[3] <= vb.y + vb.h, r.key + " label in view");
    }
    for (const seg of lay.outlineSegments) {
      assert.ok(seg[0] >= vb.x && seg[2] >= vb.x && seg[0] <= vb.x + vb.w && seg[1] >= vb.y && seg[1] <= vb.y + vb.h, r.key + " outline in view");
    }
  }
});
