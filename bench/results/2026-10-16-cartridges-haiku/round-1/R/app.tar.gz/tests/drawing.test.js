"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const records = require("../js/data.js");
const D = require("../js/drawing.js");

test("every cartridge yields an SVG with the accessible name and no NaN or undefined", () => {
  for (const r of records) {
    const out = D.drawingFor(r);
    assert.ok(out.svg.startsWith("<svg"), r.key);
    assert.ok(out.svg.includes('aria-label="' + D.esc(r.name) + ' drawing"'), r.key + " aria-label");
    assert.ok(!/NaN|undefined|Infinity/.test(out.svg), r.key + " has invalid number");
    assert.ok(out.svg.includes('class="outline"'), r.key + " outline");
    assert.ok(out.svg.includes('class="centre"'), r.key + " centre line");
  }
});

test("labels in the SVG are the symbol and value; 22 LR drawing notes missing values only", () => {
  const out = D.drawingFor(records.find((r) => r.key === "223_rem"));
  assert.ok(out.svg.includes(">L3 44.7</text>"));
  assert.ok(out.svg.includes(">L6 57.4</text>"));
  const rf = D.drawingFor(records.find((r) => r.key === "22_long_rifle"));
  assert.ok(rf.svg.includes('class="section"'), "rimfire section drawn");
});

test("the 22 Long Rifle has no pocket and a zero-thickness neck; drawing still produced", () => {
  const out = D.drawingFor(records.find((r) => r.key === "22_long_rifle"));
  assert.equal(out.geometry.pocket, null);
  assert.equal(out.geometry.walls.tn, 0);
});
