# Spec: C.I.P. Cartridge Reference

## Objective

A static, offline reference of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on OpenBallistics. Users find a cartridge in a list, open its detail view (tables, scaled 2D drawing, water capacity, source), bookmark that view, and print it as one A4 page.

Data is the 25 records in `data/cartridges.jsonl` (OpenBallistics, MIT, commit e83db43). They are used as published. No data is added, changed or fetched.

## Decisions and assumptions (approval gate skipped by instruction)

1. Units: lengths and diameters mm. Pressures bar (`Pmax`, `PK`, `PE`), `EE` J, `M` g, `Q` mm², `N` count, angles (`alpha`, `alpha1`, `beta`, `delta`, `i`).
   Not specified by the brief, assumed: `S` (junction cone surface) mm²; `G`, `G2`, `F`, `Z`, `b`, `h`, `s`, `u`, `Fe`, `deltaL`, `r`, `R3`, `L4`, `L5` mm.
2. Tolerances (`XTol`) are shown in the value cell after X, in X's unit. `ETol`/`RTol` attach to `E`/`R`.
3. Number format: JS number to string (`4150`, `51.18`, `9`). Angles: `40°`; object form `39°59'49"` with minutes and seconds zero-padded to two digits.
4. Symbols: field name, except the map in the brief.
5. Data is embedded as `js/data.js` (generated from `data/cartridges.jsonl` by `scripts/build-data.mjs`) because `fetch` does not work from `file://`.
6. Routing: hash routes `#/` (list) and `#/cartridge/<key>` (detail), so reload and bookmark work on `file://`.
7. Search: case-insensitive, whitespace collapsed, substring match on name and every alternative name.
8. Count text: "1 cartridge" for one, otherwise "<n> cartridges".
9. Drawing geometry follows the brief. Where the brief leaves a choice open, the choice is recorded in `js/geometry.js` and tested:
   - Coordinates in the brief's tuples are `(r, z)`.
   - Rim thickness is `R`; the groove sits from `R` to `E`.
   - Straight cases (no alpha, L1 or L2): the inner wall blends linearly from `tb` at the body start to `tn` at the mouth.
   - Heeled cases: the neck wall is `tb` (the heel is the case inside diameter `H2 - 2tb`), because `tn = 0` there.
   - Heeled exposed bullet radius is `H2/2`; the seated heel radius is `(H2 - 2tb)/2`.
   - Missing values: the feature is omitted and a note names the missing value (shown under the drawing and in the print output).
10. Print: `window.print()` with a print stylesheet (A4 portrait, black on white, one page), footer with source "C.I.P. TDCC, revised <date>".
11. Dark mode follows `prefers-color-scheme`. Print is always light.
12. Not displayed (not in the brief): `annotations.confidence`, `annotations.implausible`, `defaultBullet` details.

## Tech stack
Plain HTML, CSS, ES2017-style JavaScript, no framework, no build step, no runtime dependencies, no network requests. Dev only: Node 22 built-in test runner (`node --test`), no npm dependencies.

## Commands
- Test: `npm test` (runs `node --test tests/`)
- Regenerate data module: `node scripts/build-data.mjs`
- Browser check (optional, needs Chromium and `playwright-core` dev dependency): `npm run test:e2e`

## Project structure
```
index.html              app shell (opens from file://)
css/app.css             screen, dark mode and print styles
js/data.js              generated from data/cartridges.jsonl
js/format.js            field catalogue, symbols, units, value formatting
js/catalog.js           search and family filter (pure)
js/geometry.js          profile, bullet, walls, dimension model (pure)
js/drawing.js           SVG string for the 2D drawing (pure)
js/app.js               DOM rendering, routing, print button
data/cartridges.jsonl   source records
scripts/build-data.mjs  generates js/data.js from the jsonl file
tests/                  node:test unit and data tests
```

## Code style
Small pure functions with explicit units in names. Pure modules export through a UMD wrapper so `node --test` can load them and the browser can use them as globals.

## Testing strategy
- Unit tests (node:test): formatting, search/filter, rim type, profile points, bullet nose, wall thickness, primer pocket, dimension lanes, label non-overlap, SVG structure, data integrity (25 records, data.js equals jsonl).
- Browser tests (optional e2e, Chromium): list, search, family filter, navigation, bookmark URL, print layout.

## Boundaries
- Always: use the 25 records as given; keep the app free of network requests and build steps.
- Ask first: adding runtime dependencies.
- Never: change, add or fetch data; invent a missing dimension.

## Success criteria
- `index.html` works from `file://` in Chromium: list, search, filter, detail, drawing, print.
- Every record renders a detail view with all published values and the drawing.
- Drawing has no label overlapping another label or the outline (tested for all 25).
- Print of one detail view fits one A4 portrait page.
- All unit tests pass.
