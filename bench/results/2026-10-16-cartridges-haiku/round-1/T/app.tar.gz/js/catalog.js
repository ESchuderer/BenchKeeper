/* Search and family filter for the cartridge list. Pure; no DOM. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CipCatalog = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const FAMILY_OPTIONS = [
    { value: 'all', label: 'All' },
    { value: 'rimless', label: 'rimless' },
    { value: 'rimmed', label: 'rimmed' },
    { value: 'belted', label: 'belted' },
    { value: 'pistol', label: 'pistol' },
    { value: 'rimfire', label: 'rimfire' },
  ];

  function normalise(text) {
    return String(text).toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function matchesQuery(record, query) {
    const needle = normalise(query);
    if (needle === '') return true;
    const haystacks = [record.name].concat(record.alternativeNames || []);
    return haystacks.some((text) => normalise(text).indexOf(needle) !== -1);
  }

  function matchesFamily(record, family) {
    return !family || family === 'all' || record.family === family;
  }

  function filterCartridges(records, options = {}) {
    return records.filter((record) =>
      matchesQuery(record, options.query || '') && matchesFamily(record, options.family));
  }

  function countText(count) {
    return count === 1 ? '1 cartridge' : `${count} cartridges`;
  }

  return { FAMILY_OPTIONS, normalise, matchesQuery, filterCartridges, countText };
});
