/* Field catalogue, symbols, units and value formatting. Pure; no DOM. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CipFormat = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };

  const ANGLE_KEYS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
  const COUNT_KEYS = ['N'];
  const UNITS = {
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    S: 'mm²',
  };

  const GROUP_LABELS = {
    cartridge: {
      caseHead: 'Case head',
      collar: 'Collar',
      junctionCone: 'Junction cone',
      lengths: 'Lengths',
      misc: 'Miscellaneous',
      powderChamber: 'Powder chamber',
      pressures: 'Pressures',
      projectile: 'Projectile',
    },
    chamber: {
      barrel: 'Barrel',
      breech: 'Breech',
      collar: 'Collar',
      grooves: 'Grooves',
      junctionCone: 'Junction cone',
      lengths: 'Lengths',
      powderChamber: 'Powder chamber',
      rifling: 'Rifling',
    },
  };

  const SECTION_LABELS = { cartridge: 'Cartridge', chamber: 'Chamber' };

  function symbolFor(key) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, key) ? SYMBOLS[key] : key;
  }

  function isAngleKey(key) {
    return ANGLE_KEYS.indexOf(key) !== -1;
  }

  function unitFor(key) {
    if (isAngleKey(key) || COUNT_KEYS.indexOf(key) !== -1) return '–';
    if (Object.prototype.hasOwnProperty.call(UNITS, key)) return UNITS[key];
    return 'mm';
  }

  function formatNumber(value) {
    return String(value);
  }

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  function formatAngle(value) {
    if (typeof value === 'number') return `${formatNumber(value)}°`;
    const degrees = value.degrees || 0;
    const minutes = value.minutes || 0;
    const seconds = value.seconds || 0;
    return `${formatNumber(degrees)}°${pad2(minutes)}'${pad2(seconds)}"`;
  }

  function formatWithTolerance(value, tolerance) {
    if (tolerance === undefined || tolerance === null) return formatNumber(value);
    const sign = tolerance > 0 ? '+' : '';
    return `${formatNumber(value)} ${sign}${formatNumber(tolerance)}`;
  }

  function groupLabel(section, group) {
    const labels = GROUP_LABELS[section] || {};
    return Object.prototype.hasOwnProperty.call(labels, group) ? labels[group] : group;
  }

  function sectionLabel(section) {
    return SECTION_LABELS[section] || section;
  }

  /* Flattens one section object (record.cartridge or record.chamber) into display rows.
     Tolerance keys (XTol) are folded into the value of X and produce no row. */
  function rowsFor(sectionObject, section = 'cartridge') {
    const rows = [];
    for (const group of Object.keys(sectionObject)) {
      const fields = sectionObject[group];
      if (!fields || typeof fields !== 'object') continue;
      for (const key of Object.keys(fields)) {
        if (/Tol$/.test(key) && Object.prototype.hasOwnProperty.call(fields, key.slice(0, -3))) continue;
        const raw = fields[key];
        const tolerance = fields[`${key}Tol`];
        const isAngle = isAngleKey(key);
        let value;
        if (isAngle) {
          value = formatAngle(raw);
        } else if (tolerance !== undefined) {
          value = formatWithTolerance(raw, tolerance);
        } else {
          value = formatNumber(raw);
        }
        rows.push({
          key,
          group: groupLabel(section, group),
          symbol: symbolFor(key),
          value,
          unit: unitFor(key),
        });
      }
    }
    return rows;
  }

  function formatCapacity(capacity) {
    if (!capacity || capacity.grH2O === undefined) return null;
    return `${formatNumber(capacity.grH2O)} gr H2O`;
  }

  return {
    symbolFor,
    isAngleKey,
    unitFor,
    formatNumber,
    formatAngle,
    formatWithTolerance,
    groupLabel,
    sectionLabel,
    rowsFor,
    formatCapacity,
  };
});
