/* Cartridge geometry model. Pure; no DOM.
 *
 * Coordinates: every point is [r, z] (radius, axial distance from the head face), as in the brief.
 * z = 0 is the head face, z increases toward the mouth and the bullet tip.
 * Outer profile: from the axis at the head face to the case mouth. The drawing mirrors it at the axis.
 * Angles are in degrees inside this module. Values are mm unless noted.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CipGeometry = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const DEG = Math.PI / 180;
  const EPS = 1e-9;

  /* Primer pocket: [diameter mm, depth mm] for centrefire primer codes (rule 8). */
  const POCKETS = {
    sp: [4.45, 3.04],
    spm: [4.45, 3.04],
    sr: [4.45, 3.04],
    lp: [5.33, 3.04],
    lpm: [5.33, 3.04],
    lr: [5.33, 3.3],
    lrm: [5.33, 3.3],
  };

  /* Bullet nose table (rule 7). s = seating depth factor of G1, k = cylinder fraction of Lb,
     m = meplat diameter factor of G1 (pointy uses max(0.08 G1, 1.27) instead). */
  function bulletTable(shape, pistol) {
    switch (shape) {
      case 'pointy':
        return { s: 1.0, k: 0.40, nose: 'ogive' };
      case 'rounded':
        return { s: pistol ? 0.4 : 0.8, k: pistol ? 0.65 : 0.55, nose: 'ellipse', m: 0.15 };
      case 'flat':
        return { s: pistol ? 0.4 : 0.8, k: pistol ? 0.70 : 0.60, nose: 'cone', m: 0.55 };
      case 'semi_wadcutter':
        return { s: 0.6, k: 0.78, nose: 'cone', m: 0.6 };
      default:
        return null;
    }
  }

  function num(value) {
    return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
  }

  /* Angle as degrees: a plain number, or {degrees, minutes, seconds}. */
  function angleDeg(value) {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (value && typeof value === 'object') {
      return (value.degrees || 0) + (value.minutes || 0) / 60 + (value.seconds || 0) / 3600;
    }
    return undefined;
  }

  const add = (a, b) => [a[0] + b[0], a[1] + b[1]];
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
  const scale = (a, k) => [a[0] * k, a[1] * k];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1];
  const len = (a) => Math.hypot(a[0], a[1]);
  const unit = (a) => {
    const l = len(a);
    return l > EPS ? scale(a, 1 / l) : [0, 0];
  };

  /* Rounds the corner V between the segments V-prev and V-next with radius r (tangent arcs).
     Returns { T1, T2, d, points } where points run from T1 to T2 inclusive, or null if it does not fit. */
  function fillet(prev, V, next, r) {
    if (!(r > 0)) return null;
    const a = sub(prev, V);
    const b = sub(next, V);
    const la = len(a);
    const lb = len(b);
    if (la < EPS || lb < EPS) return null;
    const u1 = scale(a, 1 / la);
    const u2 = scale(b, 1 / lb);
    const theta = Math.acos(Math.max(-1, Math.min(1, dot(u1, u2))));
    if (theta < 1e-6 || theta > Math.PI - 1e-6) return null;
    const d = r / Math.tan(theta / 2);
    if (d >= Math.min(la, lb)) return null;
    const T1 = add(V, scale(u1, d));
    const T2 = add(V, scale(u2, d));
    const bisector = unit(add(u1, u2));
    const centre = add(V, scale(bisector, r / Math.sin(theta / 2)));
    const v1 = unit(sub(T1, centre));
    const v2 = unit(sub(T2, centre));
    const N = 12;
    const points = [];
    for (let i = 0; i <= N; i++) {
      const s = i / N;
      const dir = unit([v1[0] * (1 - s) + v2[0] * s, v1[1] * (1 - s) + v2[1] * s]);
      points.push(add(centre, scale(dir, r)));
    }
    points[0] = T1;
    points[N] = T2;
    return { T1, T2, d, points, radius: r };
  }

  function dedupe(points) {
    const out = [];
    for (const p of points) {
      const last = out[out.length - 1];
      if (!last || Math.abs(last[0] - p[0]) > 1e-9 || Math.abs(last[1] - p[1]) > 1e-9) out.push(p);
    }
    return out;
  }

  /* Rim type (rule 1). Missing R1 or P1 falls back to rimless (buildModel reports the gap). */
  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    const R1 = num(record.cartridge && record.cartridge.caseHead && record.cartridge.caseHead.R1);
    const P1 = num(record.cartridge && record.cartridge.powderChamber && record.cartridge.powderChamber.P1);
    if (R1 === undefined || P1 === undefined) return 'rimless';
    const ratio = R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function interpolateR(points, z) {
    for (let i = 1; i < points.length; i++) {
      const [r0, z0] = points[i - 1];
      const [r1, z1] = points[i];
      if (z1 > z0 + EPS && z >= z0 - EPS && z <= z1 + EPS) {
        return r0 + (r1 - r0) * (z - z0) / (z1 - z0);
      }
    }
    return undefined;
  }

  /* Nose of the exposed bullet from (Rexp, zs) to (m/2, L6). */
  function noseOf(kind, Rexp, zs, L6, m) {
    const n = L6 - zs;
    if (kind === 'ogive') {
      const d = Rexp - m / 2;
      const rho = (d * d + n * n) / (2 * d);
      const rc = Rexp - rho;
      const phiEnd = Math.asin(Math.min(1, n / rho));
      const points = [];
      const N = 24;
      for (let i = 0; i <= N; i++) {
        const phi = (phiEnd * i) / N;
        points.push([rc + rho * Math.cos(phi), zs + rho * Math.sin(phi)]);
      }
      points[0] = [Rexp, zs];
      points[N] = [m / 2, L6];
      return points;
    }
    if (kind === 'ellipse') {
      const a = Rexp - m / 2;
      const b = n;
      const points = [];
      const N = 24;
      for (let i = 0; i <= N; i++) {
        const theta = (Math.PI / 2) * i / N;
        points.push([m / 2 + a * Math.cos(theta), zs + b * Math.sin(theta)]);
      }
      points[0] = [Rexp, zs];
      points[N] = [m / 2, L6];
      return points;
    }
    return [[Rexp, zs], [m / 2, L6]];
  }

  /* Bullet (rule 7). Returns null when the shape is unknown. */
  function bulletGeometry(opts) {
    const { G1, L3, L6, shape, pistol, heeled, H2, tb } = opts;
    const t = bulletTable(shape, pistol);
    if (!t) return null;
    const m = shape === 'pointy' ? Math.max(0.08 * G1, 1.27) : t.m * G1;
    const s = t.s * G1;
    const zb = L3 - s;
    const Lb = L6 - zb;
    const zs = zb + t.k * Lb;
    const Rexp = (heeled ? H2 : G1) / 2;
    const Rseat = (heeled ? H2 - 2 * tb : G1) / 2;
    const nosePoints = noseOf(t.nose, Rexp, zs, L6, m);
    const exposed = dedupe([[Rexp, L3], [Rexp, zs]].concat(nosePoints, [[0, L6]]));
    const section = dedupe([[0, zb], [Rseat, zb], [Rseat, L3]].concat(exposed));
    return {
      shape,
      nose: t.nose,
      s,
      zb,
      Lb,
      k: t.k,
      zs,
      n: L6 - zs,
      m,
      Rexp,
      Rseat,
      exposed,
      section,
    };
  }

  /* Builds the full model for one record. Never invents a value: a missing value removes the
     feature it drives and is named in `notes` and `missing`. A missing value the outline cannot
     be drawn without sets `error`. */
  function buildModel(record) {
    const notes = [];
    const missing = [];
    const c = record.cartridge || {};
    const ann = record.annotations || {};
    const head = c.caseHead || {};
    const col = c.collar || {};
    const lens = c.lengths || {};
    const pc = c.powderChamber || {};
    const jc = c.junctionCone || {};
    const proj = c.projectile || {};
    const key = record.key;
    const name = record.name;

    const R1 = num(head.R1);
    const P1 = num(pc.P1);
    const L3 = num(lens.L3);
    const H2 = num(col.H2);
    const R = num(head.R);
    const G1 = num(proj.G1);
    const required = [['R1', R1], ['P1', P1], ['L3', L3], ['H2', H2], ['R', R], ['G1', G1]];
    const absent = required.filter(([, v]) => v === undefined).map(([n]) => n);
    if (absent.length) {
      return { key, name, error: `Cannot draw: missing ${absent.join(', ')}`, notes, missing: absent };
    }

    const type = rimType(record);
    const E = num(head.E);
    const E1 = num(head.E1);
    const eMin = num(head.eMin);
    const R3 = num(head.R3);
    const f = num(head.f);
    const beta = angleDeg(head.beta);
    const delta = angleDeg(head.delta);
    const L1 = num(lens.L1);
    const L2 = num(lens.L2);
    const L6 = num(lens.L6);
    const P2 = num(pc.P2);
    const H1 = num(col.H1);
    const alpha = angleDeg(jc.alpha);
    const r1 = num(jc.r1Min);
    const r2 = num(jc.r2);
    const shape = ann.defaultBulletShape;
    const category = ann.category;
    const primer = ann.primerType;
    const heeled = H2 - G1 <= 0.015;
    const R1h = R1 / 2;
    const P1h = P1 / 2;
    const H2h = H2 / 2;
    const L3z = L3;

    /* Head: chamfer or half-round rim edge (rule 2). */
    const pts = [[0, 0]];
    let rimR;
    let chamfer = null;
    if (type === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      const cx = R1h - rho;
      const zc = R / 2;
      pts.push([cx, 0]);
      const N = 12;
      for (let i = 0; i <= N; i++) {
        const th = -Math.PI / 2 + Math.PI * i / N;
        pts.push([cx + rho * Math.cos(th), zc + rho * Math.sin(th)]);
      }
      pts.push([cx, R]);
      rimR = cx;
    } else {
      const chamferWanted = beta === undefined || (beta > 0 && beta < 90);
      if (beta === undefined) missing.push('beta');
      if (f === undefined && chamferWanted) missing.push('f');
      if (beta !== undefined && f !== undefined && beta > 0 && beta < 90) {
        chamfer = { width: Math.min(f * Math.tan(beta * DEG), R1 / 4), height: f };
        pts.push([R1h - chamfer.width, 0], [R1h, chamfer.height]);
      } else {
        pts.push([R1h, 0]);
      }
      if (R > (chamfer ? chamfer.height : 0)) pts.push([R1h, R]);
      rimR = R1h;
      const gone = [];
      if (beta === undefined) gone.push('beta');
      if (f === undefined && chamferWanted) gone.push('f');
      if (gone.length) notes.push(`Head chamfer not drawn: ${gone.join(', ')} not published.`);
    }

    /* Extractor groove or belt (rule 3). */
    let groove = 'none';
    let bodyStart = R;
    let beltEnd;
    const hasE = E !== undefined;
    const hasE1 = E1 !== undefined;
    if (hasE !== hasE1) {
      const which = hasE ? 'E1' : 'E';
      missing.push(which);
      notes.push(`Extractor groove not drawn: ${which} not published.`);
    }
    if (hasE && hasE1 && eMin === undefined) {
      missing.push('eMin');
      notes.push('Extractor groove not drawn: e min not published.');
    }
    const grooveValues = hasE && hasE1 && eMin !== undefined;
    if (grooveValues) {
      pts.push([E1 / 2, R], [E1 / 2, R + eMin]);
      const belted = type === 'belted';
      if (belted && R3 !== undefined && delta !== undefined) {
        const R3h = R3 / 2;
        const zr = R + eMin + (R3h - E1 / 2) / Math.tan(delta * DEG);
        if (zr <= E) {
          pts.push([R3h, zr], [R3h, E]);
          beltEnd = zr;
          groove = 'belt';
        }
      }
      if (groove === 'none') {
        if (belted) notes.push('Belt ramp not drawn: R3 or delta not published.');
        groove = 'groove';
      }
      pts.push([P1h, E]);
      bodyStart = E;
    } else {
      pts.push([P1h, R]);
    }

    /* Body, shoulder and neck (rules 4 to 6). */
    const shoulderValues = { alpha, L1, L2, P2, H1 };
    const shoulderPresent = Object.keys(shoulderValues).filter((k) => shoulderValues[k] !== undefined);
    const bottleneck = shoulderPresent.length === 5;
    const shoulder = { present: false };
    const fillets = { body: { applied: false }, neck: { applied: false } };
    if (bottleneck) {
      const V1 = [P2 / 2, L1];
      const V2 = [H1 / 2, L2];
      const Mouth = [H2h, L3z];
      const start = [P1h, bodyStart];
      let f1 = r1 !== undefined ? fillet(start, V1, V2, r1) : null;
      let f2 = r2 !== undefined ? fillet(V1, V2, Mouth, r2) : null;
      if (f1 && f2 && f1.d + f2.d >= len(sub(V2, V1))) {
        notes.push('r2 does not fit on the shoulder: neck corner drawn sharp.');
        f2 = null;
      }
      if (r1 === undefined) notes.push('r1 min not published: body corner drawn sharp.');
      else if (!f1) notes.push('r1 min does not fit on the body and shoulder: body corner drawn sharp.');
      if (r2 === undefined) notes.push('r2 not published: neck corner drawn sharp.');
      else if (!f2) notes.push('r2 not drawn: does not fit on the shoulder or missing.');
      fillets.body = f1 ? { applied: true, radius: r1, d: f1.d } : { applied: false, radius: r1 };
      fillets.neck = f2 ? { applied: true, radius: r2, d: f2.d } : { applied: false, radius: r2 };
      if (f1) pts.push(...f1.points); else pts.push(V1);
      if (f2) pts.push(...f2.points); else pts.push(V2);
      pts.push(Mouth);
      shoulder.present = true;
      shoulder.start = V1;
      shoulder.end = V2;
    } else {
      if (shoulderPresent.length > 0) {
        const absentParts = ['alpha', 'L1', 'L2', 'P2', 'H1'].filter((k) => shoulderValues[k] === undefined);
        notes.push(`Shoulder not drawn: ${absentParts.join(', ')} not published; body drawn straight.`);
        missing.push(...absentParts);
      }
      pts.push([H2h, L3z]);
    }
    const outerPts = dedupe(pts);

    /* Walls (rule 8). */
    const tn0 = (H2 - G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn0, 0.6), 0.35 * P1h);
    const tn = heeled ? tb : tn0;

    /* Wall offset t(z): tb along the body, tn along the neck, linear across the shoulder. */
    const t = (z) => {
      const z0 = bottleneck ? L1 : bodyStart;
      const z1 = bottleneck ? L2 : L3z;
      if (z <= z0) return tb;
      if (z >= z1) return tn;
      return tb + (tn - tb) * (z - z0) / (z1 - z0);
    };

    /* Primer pocket (centrefire only). */
    let pocket = null;
    if (type !== 'rimfire') {
      if (primer === undefined) {
        notes.push('Primer pocket not drawn: primerType not published.');
        missing.push('primerType');
      } else if (POCKETS[primer]) {
        pocket = { diameter: POCKETS[primer][0], depth: POCKETS[primer][1] };
      } else {
        notes.push(`Primer pocket not drawn: primer type "${primer}" has no pocket size.`);
      }
    }

    /* Solid head ends at z = w (rule 8). */
    const candidates = [2.5, 0.25 * P1h];
    if (pocket) candidates.push(pocket.depth + 1.5);
    if (groove === 'groove') candidates.push(E + tb);
    if (groove === 'belt') candidates.push(beltEnd + tb);
    const w = Math.max(...candidates);

    /* Inner line: mouth, then the outer vertices above w, then the point at w. */
    const innerPts = [[H2h - t(L3z), L3z]];
    for (let i = outerPts.length - 1; i >= 0; i--) {
      const [r, z] = outerPts[i];
      if (z > w + EPS && z < L3z - EPS) innerPts.push([r - t(z), z]);
    }
    const rAtW = interpolateR(outerPts, w);
    innerPts.push([rAtW - t(w), w]);
    const inner = dedupe(innerPts);

    /* Case section (upper half, closed): outer profile, mouth face, inner line, solid head, pocket. */
    const sectionStart = pocket ? [pocket.diameter / 2, 0] : [0, 0];
    const caseSectionPts = [sectionStart].concat(outerPts.slice(1), inner, [[0, w]]);
    if (pocket) caseSectionPts.push([0, pocket.depth], [pocket.diameter / 2, pocket.depth]);
    const caseSection = dedupe(caseSectionPts);

    /* Bullet (rule 7). */
    let bullet = null;
    const bulletNotes = [];
    if (shape === undefined) {
      bulletNotes.push('Bullet not drawn: defaultBulletShape not published.');
      missing.push('defaultBulletShape');
    } else if (L6 === undefined) {
      bulletNotes.push('Bullet not drawn: L6 not published.');
      missing.push('L6');
    } else if (!bulletTable(shape, false)) {
      bulletNotes.push(`Bullet not drawn: unknown bullet shape "${shape}".`);
    } else {
      if (category === undefined) {
        bulletNotes.push('Bullet category not published: drawn with rifle rules.');
        missing.push('category');
      }
      bullet = bulletGeometry({
        G1,
        L3: L3z,
        L6,
        shape,
        pistol: category === 'pistol',
        heeled,
        H2,
        tb,
      });
    }
    notes.push(...bulletNotes);

    const outside = bullet ? dedupe(outerPts.concat(bullet.exposed)) : outerPts.slice();
    const model = {
      key,
      name,
      rimType: type,
      groove,
      bodyStart,
      heeled,
      tn,
      tb,
      w,
      pocket,
      outer: outerPts,
      outside,
      shoulder,
      fillets,
      mouthInner: inner[0],
      inner,
      caseSection,
      heelRadius: heeled ? (H2 - 2 * tb) / 2 : undefined,
      exposedRadius: H2 / 2,
      bullet,
      notes,
      missing: Array.from(new Set(missing)),
    };
    return model;
  }

  return { buildModel, rimType, fillet, bulletGeometry, noseOf, angleDeg, POCKETS, bulletTable };
});
