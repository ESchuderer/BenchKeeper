# Implementation Plan: C.I.P. Cartridge Reference

Source of truth: `SPEC.md`. Vertical slices, each leaves the app working from `file://`.

## Architecture
- Pure modules (format, catalog, geometry, drawing) with UMD exports; tested with `node --test`.
- `js/app.js` is the only DOM code. Routing by hash.
- Data: generated `js/data.js` (classic script), because `fetch` fails on `file://`.
- Drawing: geometry model -> SVG string. Labels placed by a collision checker that is also tested.

## Task list
- [x] T0 Data file verbatim (`data/cartridges.jsonl`), generator, `js/data.js`
- [ ] T1 Format module (symbols, units, values, angles) + tests
- [ ] T2 Catalog (search, family filter, count text) + tests
- [ ] T3 Geometry: rim type, outer profile, groove, body/shoulder/neck, fillets + tests
- [ ] T4 Geometry: walls, primer pocket, head width w, inner profile + tests
- [ ] T5 Geometry: bullet (shape, seating, heel, nose) + tests
- [ ] T6 Drawing: SVG paths (outside, section, centre line, hatch, title block) + tests
- [ ] T7 Drawing: dimensions and label placement without overlap, for all 25 records + tests
- [ ] T8 App shell: list page, search, family filter, routing
- [ ] T9 Detail view: tables, drawing, water capacity, print button, back link
- [ ] T10 Styles: light/dark, phone layout, print stylesheet (A4 one page)
- [ ] T11 Browser verification from file:// (Chromium), print check, review pass

## Checkpoints
- After T2: unit tests green, list works in a browser.
- After T5: geometry for all 25 records passes invariant tests.
- After T7: drawings have no label collisions for all 25 records.
- After T10: print and dark mode checked in Chromium.

## Risks
| Risk | Mitigation |
|---|---|
| Label collisions in dense drawings | Automatic placement with tested collision check; fallback candidates |
| Ambiguous geometry rules (straight cases, heeled walls) | Decisions recorded in SPEC.md, tested |
| Print not on one page | Print CSS sized for A4, verified with Chromium PDF page count |
| Browser not available in CI | e2e tests skip when Chromium is not present |
