'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../js/catalog.js');
const { loadRecords } = require('./helpers.js');

const records = loadRecords();
const names = (list) => list.map((r) => r.name);

test('search matches the cartridge name, ignoring case and extra spaces', () => {
  assert.deepEqual(names(catalog.filterCartridges(records, { query: '  223 REM ' })), ['223 Rem.']);
});

test('search also matches alternative names: "7,62 x 51" finds 308 Win.', () => {
  assert.deepEqual(names(catalog.filterCartridges(records, { query: '7,62 x 51' })), ['308 Win.']);
});

test('search matches the 30-06 alternative name', () => {
  assert.ok(names(catalog.filterCartridges(records, { query: '30-06' })).includes('30-06 Spring.'));
});

test('an empty or blank query lists every cartridge', () => {
  assert.equal(catalog.filterCartridges(records, { query: '' }).length, 25);
  assert.equal(catalog.filterCartridges(records, { query: '   ' }).length, 25);
});

test('family filter keeps only the chosen family; "all" keeps everything', () => {
  const rimfire = names(catalog.filterCartridges(records, { family: 'rimfire' }));
  assert.deepEqual(rimfire.sort(), ['17 HMR', '22 Long Rifle', '22 Win. Mag. R.F.'].sort());
  assert.equal(catalog.filterCartridges(records, { family: 'all' }).length, 25);
  assert.equal(catalog.filterCartridges(records, {}).length, 25);
});

test('search and family filter combine', () => {
  assert.deepEqual(names(catalog.filterCartridges(records, { query: '22', family: 'rimfire' })).sort(),
    ['22 Long Rifle', '22 Win. Mag. R.F.']);
  assert.deepEqual(catalog.filterCartridges(records, { query: '22', family: 'pistol' }), []);
});

test('the list keeps the data order', () => {
  assert.equal(catalog.filterCartridges(records, { family: 'belted' })[0].name, '300 Win. Mag.');
});

test('count text is singular for one and plural otherwise', () => {
  assert.equal(catalog.countText(1), '1 cartridge');
  assert.equal(catalog.countText(0), '0 cartridges');
  assert.equal(catalog.countText(25), '25 cartridges');
});

test('families are offered in the brief\'s order', () => {
  assert.deepEqual(catalog.FAMILY_OPTIONS.map((o) => o.value),
    ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  assert.equal(catalog.FAMILY_OPTIONS[0].label, 'All');
});

test('every record family is one of the offered families', () => {
  const offered = new Set(catalog.FAMILY_OPTIONS.map((o) => o.value));
  for (const record of records) assert.ok(offered.has(record.family), record.key);
});
