'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fmt = require('../js/format.js');

test('symbols use the field name except for the brief\'s mapped keys', () => {
  assert.equal(fmt.symbolFor('L1'), 'L1');
  assert.equal(fmt.symbolFor('E1'), 'E1');
  assert.equal(fmt.symbolFor('eMin'), 'e min');
  assert.equal(fmt.symbolFor('r1Min'), 'r1 min');
  assert.equal(fmt.symbolFor('r1Max'), 'r1 max');
  assert.equal(fmt.symbolFor('alpha'), 'α');
  assert.equal(fmt.symbolFor('alpha1'), 'α1');
  assert.equal(fmt.symbolFor('beta'), 'β');
  assert.equal(fmt.symbolFor('delta'), 'δ');
  assert.equal(fmt.symbolFor('deltaL'), 'delta L');
  assert.equal(fmt.symbolFor('L3PlusG'), 'L3 + G');
});

test('numbers are shown as published: decimal point, no thousands separator', () => {
  assert.equal(fmt.formatNumber(4150), '4150');
  assert.equal(fmt.formatNumber(51.18), '51.18');
  assert.equal(fmt.formatNumber(9), '9');
  assert.equal(fmt.formatNumber(-0.2), '-0.2');
  assert.equal(fmt.formatNumber(1825), '1825');
});

test('angles: a plain number is shown as degrees, an object as degrees minutes seconds', () => {
  assert.equal(fmt.formatAngle(40), '40°');
  assert.equal(fmt.formatAngle(0), '0°');
  assert.equal(fmt.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(fmt.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(fmt.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(fmt.formatAngle({ degrees: 0, minutes: 42, seconds: 9 }), '0°42\'09"');
});

test('a tolerance is shown after its value with a sign', () => {
  assert.equal(fmt.formatWithTolerance(39.62, -0.2), '39.62 -0.2');
  assert.equal(fmt.formatWithTolerance(4.2, 0.1), '4.2 +0.1');
  assert.equal(fmt.formatWithTolerance(9, undefined), '9');
});

test('units follow the brief; unitless values have no unit', () => {
  assert.equal(fmt.unitFor('L1'), 'mm');
  assert.equal(fmt.unitFor('H2'), 'mm');
  assert.equal(fmt.unitFor('Pmax'), 'bar');
  assert.equal(fmt.unitFor('PK'), 'bar');
  assert.equal(fmt.unitFor('PE'), 'bar');
  assert.equal(fmt.unitFor('EE'), 'J');
  assert.equal(fmt.unitFor('M'), 'g');
  assert.equal(fmt.unitFor('Q'), 'mm²');
  assert.equal(fmt.unitFor('S'), 'mm²');
  assert.equal(fmt.unitFor('N'), '–');
  assert.equal(fmt.unitFor('alpha'), '–');
  assert.equal(fmt.unitFor('i'), '–');
});

test('an angle key is recognised for formatting', () => {
  assert.equal(fmt.isAngleKey('beta'), true);
  assert.equal(fmt.isAngleKey('alpha1'), true);
  assert.equal(fmt.isAngleKey('i'), true);
  assert.equal(fmt.isAngleKey('L1'), false);
});

test('a record section becomes grouped rows, tolerances folded into their value', () => {
  const cartridge = {
    caseHead: { E: 5.59, E1: 12.07, ETol: -0.2, R: 1.27, beta: 35, delta: { degrees: 35, minutes: 0, seconds: 0 } },
    lengths: { L1: 55.78, L1Tol: -0.2, L3: 66.55, L6: 84.84 },
    pressures: { Pmax: 4300, EE: 4935 },
  };
  const rows = fmt.rowsFor(cartridge);
  const byKey = Object.fromEntries(rows.map((row) => [row.key, row]));

  assert.equal(rows.some((row) => /Tol$/.test(row.key)), false, 'no tolerance is a row of its own');
  assert.deepEqual(byKey.E, { key: 'E', group: 'Case head', symbol: 'E', value: '5.59 -0.2', unit: 'mm' });
  assert.equal(byKey.L1.value, '55.78 -0.2');
  assert.equal(byKey.L3.value, '66.55');
  assert.equal(byKey.Pmax.unit, 'bar');
  assert.equal(byKey.EE.unit, 'J');
  assert.equal(byKey.beta.value, '35°');
  assert.equal(byKey.delta.value, '35°00\'00"');
  assert.equal(byKey.delta.symbol, 'δ');
});

test('groups keep their published order and the group label is human-readable', () => {
  const rows = fmt.rowsFor({ lengths: { L3: 1 }, caseHead: { E: 1 } });
  assert.deepEqual(rows.map((row) => row.group), ['Lengths', 'Case head']);
});

test('chamber section names are mapped to labels', () => {
  assert.equal(fmt.groupLabel('chamber', 'rifling'), 'Rifling');
  assert.equal(fmt.groupLabel('cartridge', 'caseHead'), 'Case head');
});

test('water capacity is shown as published with its unit', () => {
  assert.equal(fmt.formatCapacity({ grH2O: 30.5 }), '30.5 gr H2O');
  assert.equal(fmt.formatCapacity(undefined), null);
});
