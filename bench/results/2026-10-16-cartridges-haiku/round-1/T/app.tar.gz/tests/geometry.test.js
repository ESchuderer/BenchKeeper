'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const geo = require('../js/geometry.js');
const { loadRecords } = require('./helpers.js');

const records = loadRecords();
const byKey = Object.fromEntries(records.map((r) => [r.key, r]));
const models = Object.fromEntries(records.map((r) => [r.key, geo.buildModel(r)]));
const close = (actual, expected, eps = 1e-6) =>
  assert.ok(Math.abs(actual - expected) <= eps, `expected ${expected}, got ${actual}`);

/* ---- Rim type (rule 1) ---- */
test('rim type: belted and rimfire follow the family; otherwise R1/P1 decides', () => {
  assert.equal(geo.rimType(byKey['300_win_mag']), 'belted');
  assert.equal(geo.rimType(byKey['22_long_rifle']), 'rimfire');
  assert.equal(geo.rimType(byKey['9_3_x_74_r']), 'rimmed');
  assert.equal(geo.rimType(byKey['38_special']), 'rimmed');
  assert.equal(geo.rimType(byKey['223_rem']), 'rimless');
  assert.equal(geo.rimType(byKey['9_mm_luger']), 'rimless');
});

test('rim type thresholds: >= 1.05 rimmed, < 0.98 rebated, otherwise rimless', () => {
  const make = (R1, P1) => ({ family: 'rimless', cartridge: { caseHead: { R1 }, powderChamber: { P1 } } });
  assert.equal(geo.rimType(make(10.5, 10)), 'rimmed');
  assert.equal(geo.rimType(make(9.7, 10)), 'rebated');
  assert.equal(geo.rimType(make(10, 10)), 'rimless');
  assert.equal(geo.rimType(make(9.8, 10)), 'rimless');
});

/* ---- Head, chamfer and groove (rules 2 and 3) ---- */
test('223 Rem: chamfer, square rim edge and extractor groove points', () => {
  const m = models['223_rem'];
  const c = 0.45 * Math.tan(35 * Math.PI / 180);
  close(m.outer[0][0], 0); close(m.outer[0][1], 0);
  close(m.outer[1][0], 9.6 / 2 - c); close(m.outer[1][1], 0);
  close(m.outer[2][0], 9.6 / 2); close(m.outer[2][1], 0.45);
  close(m.outer[3][0], 9.6 / 2); close(m.outer[3][1], 1.14);
  // groove: in to E1/2 at z = R, floor to z = R + eMin, ramp to (P1/2, E)
  close(m.outer[4][0], 8.43 / 2); close(m.outer[4][1], 1.14);
  close(m.outer[5][0], 8.43 / 2); close(m.outer[5][1], 1.14 + 0.76);
  close(m.outer[6][0], 9.58 / 2); close(m.outer[6][1], 3.13);
  assert.equal(m.bodyStart, 3.13);
});

test('chamfer width is min(f·tan β, R1/4)', () => {
  const m = models['9_mm_luger'];
  // beta 45, f 0.3: chamfer 0.3 wide
  close(m.outer[1][0], 9.96 / 2 - 0.3); close(m.outer[2][0], 9.96 / 2); close(m.outer[2][1], 0.3);
});

test('no groove without E and E1: step in from the rim edge to P1/2 at z = R', () => {
  const m = models['9_3_x_74_r'];
  const last = m.outer[m.outer.length - 1];
  close(m.bodyStart, 1.4);
  assert.ok(m.outer.some(([r, z]) => Math.abs(r - 11.9 / 2) < 1e-9 && Math.abs(z - 1.4) < 1e-9),
    'body starts at P1/2 on z = R');
  assert.equal(m.groove, 'none');
  assert.ok(last[0] > 0);
});

test('rimfire: half-round rim edge with outermost point at R1/2, no chamfer', () => {
  const m = models['22_long_rifle'];
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const cx = 7.06 / 2 - rho;
  const maxR = Math.max(...m.outer.map((p) => p[0]));
  close(maxR, 7.06 / 2, 1e-6);
  assert.ok(m.outer.some(([r, z]) => Math.abs(r - cx) < 1e-9 && Math.abs(z) < 1e-9),
    'arc starts on the head face at r = R1/2 - rho');
  assert.equal(m.groove, 'none');
});

test('belted: ramp at angle δ to the axis up to the belt R3/2, belt to z = E, step in', () => {
  const m = models['300_win_mag'];
  const R3h = 13.51 / 2, E1h = 12.07 / 2;
  const zr = 1.27 + 0.94 + (R3h - E1h) / Math.tan(35 * Math.PI / 180);
  const belt = m.outer.filter(([r, z]) => Math.abs(r - R3h) < 1e-9 && z > 2);
  assert.ok(belt.length >= 2, 'belt points present');
  close(Math.min(...belt.map((p) => p[1])), zr, 1e-6);
  close(Math.max(...belt.map((p) => p[1])), 5.59, 1e-6);
  assert.equal(m.groove, 'belt');
  close(m.bodyStart, 5.59);
});

/* ---- Body, shoulder, neck (rules 4 to 6) ---- */
test('bottleneck: body to (P2/2, L1), shoulder to (H1/2, L2), neck to (H2/2, L3)', () => {
  const m = models['223_rem'];
  const last = m.outer[m.outer.length - 1];
  close(last[0], 6.43 / 2); close(last[1], 44.7);
  assert.equal(m.shoulder.present, true);
  close(m.shoulder.start[0], 9.0 / 2); close(m.shoulder.start[1], 36.52);
  close(m.shoulder.end[0], 6.43 / 2); close(m.shoulder.end[1], 39.55);
});

test('case without alpha, L1 or L2 is straight: body runs to (H2/2, L3)', () => {
  const m = models['9_mm_luger'];
  const last = m.outer[m.outer.length - 1];
  close(last[0], 9.65 / 2); close(last[1], 19.15);
  assert.equal(m.shoulder.present, false);
  assert.equal(m.notes.length >= 0, true);
});

test('shoulder corners are rounded with r1 min (body side) and r2 (neck side)', () => {
  const m = models['223_rem'];
  const sharpBody = [9.0 / 2, 36.52];
  assert.ok(!m.outer.some(([r, z]) => Math.abs(r - sharpBody[0]) < 1e-9 && Math.abs(z - sharpBody[1]) < 1e-9),
    'the sharp corner point itself is replaced by the arc');
  assert.ok(m.fillets.body && m.fillets.body.applied, 'body corner filleted');
  assert.ok(m.fillets.neck && m.fillets.neck.applied, 'neck corner filleted');
  close(m.fillets.body.radius, 0.64);
  close(m.fillets.neck.radius, 2.54);
});

test('a fillet that does not fit on the shoulder is dropped and noted', () => {
  // artificial case: r1 far too large for a very short shoulder
  const rec = JSON.parse(JSON.stringify(byKey['223_rem']));
  rec.cartridge.junctionCone.r1Min = 30;
  const m = geo.buildModel(rec);
  assert.equal(m.fillets.body.applied, false);
  assert.ok(m.notes.some((n) => /r1 min/.test(n)));
});

test('missing r1 min draws the body corner sharp and notes it', () => {
  const m = models['338_lapua_mag'];
  assert.equal(m.fillets.body.applied, false);
  assert.ok(m.notes.some((n) => /r1 min/.test(n)));
});

/* ---- Walls and inner line (rule 8) ---- */
test('wall thicknesses: tn = (H2 - G1)/2, tb = min(max(1.3·tn, 0.6), 0.35·P1/2)', () => {
  const m = models['223_rem'];
  close(m.tn, (6.43 - 5.7) / 2);
  close(m.tb, 0.6);
  const m2 = models['9_3_x_62'];
  close(m2.tn, (9.92 - 9.3) / 2);
  close(m2.tb, Math.min(Math.max(1.3 * (9.92 - 9.3) / 2, 0.6), 0.35 * 12.13 / 2));
});

test('inner wall: tb along the body, tn along the neck, linear across the shoulder', () => {
  const m = models['223_rem'];
  const expectedT = (z) => {
    if (z <= 36.52) return m.tb;
    if (z >= 39.55) return m.tn;
    return m.tb + (m.tn - m.tb) * (z - 36.52) / (39.55 - 36.52);
  };
  let checked = 0;
  for (const [r, z] of m.inner) {
    close(outerRadiusAt(m.outer, z) - r, expectedT(z), 1e-6);
    checked++;
  }
  assert.ok(checked >= 4, 'inner line has the expected vertices');
  assert.ok(m.inner.some(([, z]) => z > 39.55), 'inner line reaches the neck');
});

test('the mouth inner point is at G1/2 for a non-heeled case', () => {
  const m = models['223_rem'];
  close(m.mouthInner[0], 5.7 / 2, 1e-6);
  close(m.mouthInner[1], 44.7, 1e-9);
});

test('heeled case (22 Long Rifle): neck wall is tb and the seated heel is H2 - 2tb', () => {
  const m = models['22_long_rifle'];
  assert.equal(m.heeled, true);
  close(m.tn, m.tb);
  close(m.heelRadius, (5.72 - 2 * m.tb) / 2, 1e-9);
  close(m.exposedRadius, 5.72 / 2, 1e-9);
});

test('solid head runs to z = w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb)', () => {
  const m = models['223_rem'];
  close(m.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + m.tb));
  const r = models['22_long_rifle'];
  close(r.w, Math.max(2.5, 0.25 * 5.74 / 2));
});

test('primer pocket: 4.45 / 3.04 for sr, 5.33 / 3.3 for lr and lrm', () => {
  assert.deepEqual(models['223_rem'].pocket, { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(models['308_win'].pocket, { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(models['338_lapua_mag'].pocket, { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(models['9_mm_luger'].pocket, { diameter: 4.45, depth: 3.04 });
  assert.equal(models['22_long_rifle'].pocket, null, 'rimfire has no pocket');
});

test('a primer type that is not in the pocket table draws no pocket and says so', () => {
  const rec = JSON.parse(JSON.stringify(byKey['223_rem']));
  rec.annotations.primerType = 'xx';
  const m = geo.buildModel(rec);
  assert.equal(m.pocket, null);
  assert.ok(m.notes.some((n) => /primer/.test(n)));
});

/* ---- Bullet (rule 7) ---- */
test('223 Rem bullet: pointy, s = G1, base at L3 - s, cylinder to zb + 0.40·Lb', () => {
  const b = models['223_rem'].bullet;
  close(b.s, 5.7); close(b.zb, 39.0); close(b.Lb, 18.4);
  close(b.zs, 39.0 + 0.4 * 18.4); close(b.m, 1.27); assert.equal(b.nose, 'ogive');
});

test('pistol rounded bullet: s = 0.4·G1, k = 0.65, quarter ellipse, m = 0.15·G1', () => {
  const b = models['9_mm_luger'].bullet;
  close(b.s, 0.4 * 9.03); close(b.zb, 19.15 - 0.4 * 9.03);
  close(b.zs, b.zb + 0.65 * (29.69 - b.zb)); close(b.m, 0.15 * 9.03); assert.equal(b.nose, 'ellipse');
});

test('rifle/rimfire rounded bullet uses k = 0.55 and s = 0.8·G1', () => {
  const b = models['22_long_rifle'].bullet;
  close(b.s, 0.8 * 5.72); close(b.zs, b.zb + 0.55 * b.Lb);
});

test('pistol flat bullet: s = 0.4·G1, k = 0.70, cone m = 0.55·G1', () => {
  const b = models['40_s_w'].bullet;
  close(b.s, 0.4 * 10.17); close(b.zs, b.zb + 0.70 * b.Lb); close(b.m, 0.55 * 10.17); assert.equal(b.nose, 'cone');
});

test('semi-wadcutter: s = 0.6·G1, k = 0.78, cone m = 0.6·G1', () => {
  const b = models['357_magnum'].bullet;
  close(b.s, 0.6 * 9.12); close(b.zs, b.zb + 0.78 * b.Lb); close(b.m, 0.6 * 9.12);
});

test('tangent ogive: the nose arc ends at the meplat edge on the tip plane', () => {
  const b = models['223_rem'].bullet;
  const last = b.exposed[b.exposed.length - 1];
  close(last[0], 0); close(last[1], 57.4);
  const edge = b.exposed[b.exposed.length - 2];
  close(edge[0], b.m / 2, 1e-6); close(edge[1], 57.4, 1e-6);
});

test('the exposed bullet starts at the mouth, the seated part is in the section only', () => {
  const b = models['223_rem'].bullet;
  close(b.exposed[0][1], 44.7);
  assert.ok(b.section.some(([, z]) => z < 44.7), 'seated part is in the section');
});

test('heeled bullet: seated heel radius and exposed radius differ only by the wall', () => {
  const b = models['22_long_rifle'].bullet;
  close(b.Rseat, (5.72 - 2 * models['22_long_rifle'].tb) / 2);
  close(b.Rexp, 5.72 / 2);
});

test('missing bullet shape draws no bullet and notes it', () => {
  const rec = JSON.parse(JSON.stringify(byKey['223_rem']));
  delete rec.annotations.defaultBulletShape;
  const m = geo.buildModel(rec);
  assert.equal(m.bullet, null);
  assert.ok(m.notes.some((n) => /[Bb]ullet/.test(n)));
});

/* ---- Notes for missing values (rule 9) ---- */
test('missing beta and f: no chamfer, and the missing values are named', () => {
  const rec = JSON.parse(JSON.stringify(byKey['223_rem']));
  delete rec.cartridge.caseHead.beta;
  delete rec.cartridge.caseHead.f;
  const m = geo.buildModel(rec);
  assert.ok(m.notes.some((n) => /beta/.test(n) && /f/.test(n)));
  assert.ok(m.missing.includes('beta'));
  assert.ok(m.missing.includes('f'));
});

test('a cartridge with no junction cone object still builds (22 Win. Mag. R.F.)', () => {
  const m = models['22_win_mag_r_f'];
  assert.equal(m.shoulder.present, false);
  assert.equal(m.error, undefined);
});

test('a missing value that the drawing cannot do without is an error, not an invented number', () => {
  const rec = JSON.parse(JSON.stringify(byKey['223_rem']));
  delete rec.cartridge.caseHead.R1;
  const m = geo.buildModel(rec);
  assert.ok(m.error && /R1/.test(m.error));
});

/* ---- Invariants over all 25 records ---- */
test('all 25 records build without error', () => {
  assert.equal(records.length, 25);
  for (const r of records) {
    const m = models[r.key];
    assert.equal(m.error, undefined, `${r.key}: ${m.error}`);
  }
});

test('invariants: finite points, outer profile non-decreasing in z, mouth at L3', () => {
  for (const r of records) {
    const m = models[r.key];
    for (const [rr, zz] of m.outer) {
      assert.ok(Number.isFinite(rr) && Number.isFinite(zz), r.key);
      assert.ok(rr >= 0, r.key);
    }
    for (let i = 1; i < m.outer.length; i++) {
      assert.ok(m.outer[i][1] >= m.outer[i - 1][1] - 1e-9, `${r.key} z decreases at ${i}`);
    }
    const mouth = m.outer[m.outer.length - 1];
    close(mouth[1], r.cartridge.lengths.L3, 1e-9);
  }
});

test('invariants: the solid head ends before the bullet base (powder space exists)', () => {
  for (const r of records) {
    const m = models[r.key];
    if (!m.bullet) continue;
    assert.ok(m.w < m.bullet.zb, `${r.key}: w ${m.w} >= zb ${m.bullet.zb}`);
  }
});

test('invariants: the nose starts outside the case mouth and before the tip', () => {
  for (const r of records) {
    const m = models[r.key];
    if (!m.bullet) continue;
    assert.ok(m.bullet.zs > r.cartridge.lengths.L3, `${r.key}: nose starts inside the case`);
    assert.ok(m.bullet.zs < r.cartridge.lengths.L6, `${r.key}: nose longer than bullet`);
  }
});

test('invariants: inner line stays inside the outer line everywhere', () => {
  for (const r of records) {
    const m = models[r.key];
    for (const [ri, zi] of m.inner) {
      const outerR = outerRadiusAt(m.outer, zi);
      assert.ok(ri > 0 && ri < outerR, `${r.key}: inner ${ri} vs outer ${outerR} at z ${zi}`);
    }
  }
});

test('the heeled case is exactly the H2 - G1 <= 0.015 rule (only 22 Long Rifle here)', () => {
  const heeled = records.filter((r) => r.cartridge.collar.H2 - r.cartridge.projectile.G1 <= 0.015);
  assert.deepEqual(heeled.map((r) => r.key), ['22_long_rifle']);
  assert.equal(models['22_long_rifle'].heeled, true);
});

test('section polygons are closed loops of finite points', () => {
  for (const r of records) {
    const m = models[r.key];
    assert.ok(m.caseSection.length >= 6, r.key);
    if (m.bullet) assert.ok(m.bullet.section.length >= 4, r.key);
  }
});

function outerRadiusAt(outer, z) {
  let best = 0;
  for (let i = 1; i < outer.length; i++) {
    const [r0, z0] = outer[i - 1];
    const [r1, z1] = outer[i];
    if (z >= Math.min(z0, z1) - 1e-9 && z <= Math.max(z0, z1) + 1e-9 && z1 !== z0) {
      const t = (z - z0) / (z1 - z0);
      best = Math.max(best, r0 + (r1 - r0) * t);
    }
  }
  return best;
}

/* ---- Fillet helper ---- */
test('fillet: tangent points lie on both segments and the arc radius is r', () => {
  const f = geo.fillet([0, 0], [10, 0], [10, 10], 2);
  assert.ok(f);
  close(f.T1[0], 10 - 2, 1e-9); close(f.T1[1], 0, 1e-9);
  close(f.T2[0], 10, 1e-9); close(f.T2[1], 2, 1e-9);
  for (const [x, y] of f.points) {
    const d = Math.hypot(x - 8, y - 2);
    close(d, 2, 1e-6);
  }
});
