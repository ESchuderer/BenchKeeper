'use strict';
const fs = require('node:fs');
const path = require('node:path');

/* Loads the 25 records exactly as published in data/cartridges.jsonl. */
function loadRecords() {
  const file = path.join(__dirname, '..', 'data', 'cartridges.jsonl');
  return fs.readFileSync(file, 'utf8')
    .split('\n')
    .filter((line) => line.trim() !== '')
    .map((line) => JSON.parse(line));
}

module.exports = { loadRecords };
