/*
 * Application shell: routing, start page, detail view and print.
 * Pure helpers are exported for Node tests; the DOM part runs only in a browser.
 */
(function (root, factory) {
  const isNode = typeof module !== 'undefined' && module.exports;
  const api = factory(root, isNode);
  root.CIP = Object.assign(root.CIP || {}, { app: api });
  if (isNode) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root, isNode) {
  'use strict';

  const CIP = isNode ? null : root.CIP;
  const data = isNode ? require('../data/cartridges.js') : null;
  const F = isNode ? require('./format.js') : CIP.format;
  const S = isNode ? require('./search.js') : CIP.search;
  const GEO = isNode ? require('./geometry.js') : CIP.geometry;
  const LAY = isNode ? require('./layout.js') : CIP.layout;
  const SVG = isNode ? require('./svg.js') : CIP.svg;
  const DATA = isNode ? data.DATA : root.CIP.DATA;

  // A4 portrait printable height in mm (297 - 2 x 10 margin).
  const PRINT_HEIGHT_MM = 275;

  // ---- Routing ------------------------------------------------------------

  function cartridgeHref(key) {
    return '#/cartridge/' + encodeURIComponent(key);
  }

  function parseRoute(hash) {
    const h = String(hash || '');
    if (h === '' || h === '#' || h === '#/') return { view: 'list' };
    const m = /^#\/cartridge\/([^/]+)$/.exec(h);
    if (m) return { view: 'detail', key: decodeURIComponent(m[1]) };
    return { view: 'notfound', key: h };
  }

  function findByKey(key, records) {
    return (records || DATA).find((r) => r.key === key) || null;
  }

  // ---- Model helpers (pure) -----------------------------------------------

  function capacityText(cap) {
    if (!cap) return null;
    return {
      value: F.formatNumber(cap.grH2O) + ' gr H2O',
      note: cap.note || null,
      source: cap.source || null,
      url: cap.url || null,
    };
  }

  // Printed height of a detail view at full sheet width, in mm, for the print fit.
  function printHeightMm(record, sheetWidthMm, layoutResult) {
    const lay = layoutResult || LAY.layout(record, GEO.build(record));
    const vb = lay.ok ? lay.viewBox : null;
    const drawingH = vb ? (vb.h / vb.w) * sheetWidthMm * 1.07 + 12 : 0; // notes and padding
    const rows = F.sectionsFor(record).reduce((n, s) => n + s.rows.length, 0);
    // Calibrated on the print layout (three value columns): about 2 mm per row plus headings.
    const valuesMm = rows * 2.1 + 50;
    const headerMm = 56;
    const footerMm = 8;
    return headerMm + drawingH + valuesMm + footerMm;
  }

  const API = {
    cartridgeHref,
    parseRoute,
    findByKey,
    capacityText,
    printHeightMm,
    PRINT_HEIGHT_MM,
  };

  if (isNode) return API;

  // ---- DOM (browser only) -------------------------------------------------

  function el(tag, props, children) {
    const node = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (v === undefined || v === null || v === false) continue;
        if (k === 'class') node.className = v;
        else if (k === 'text') node.textContent = v;
        else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
        else node.setAttribute(k, v === true ? '' : String(v));
      }
    }
    for (const c of children || []) {
      if (c === null || c === undefined || c === false) continue;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return node;
  }

  const main = () => document.getElementById('app');

  // List state survives returning from a detail view.
  const listState = { query: '', family: 'all' };

  function setTitle(text) {
    document.title = text ? text + ' · C.I.P. cartridge reference' : 'C.I.P. cartridge reference';
  }

  function renderList(container) {
    setTitle('Cartridges');
    const search = el('input', {
      id: 'search',
      type: 'search',
      autocomplete: 'off',
      spellcheck: 'false',
      value: listState.query,
      oninput: (e) => {
        listState.query = e.target.value;
        updateList();
      },
    });
    const select = el(
      'select',
      {
        id: 'family',
        onchange: (e) => {
          listState.family = e.target.value;
          updateList();
        },
      },
      S.FAMILY_OPTIONS.map((o) =>
        el('option', { value: o.value, selected: o.value === listState.family ? true : null }, [o.label]),
      ),
    );
    const count = el('p', { class: 'count', id: 'count', 'aria-live': 'polite' });
    const list = el('ul', { class: 'cartridge-list', id: 'list' });

    container.appendChild(el('h1', null, ['Cartridges']));
    container.appendChild(
      el('form', { class: 'filters', role: 'search', onsubmit: (e) => e.preventDefault() }, [
        el('div', { class: 'field' }, [el('label', { for: 'search' }, ['Search']), search]),
        el('div', { class: 'field' }, [el('label', { for: 'family' }, ['Family']), select]),
      ]),
    );
    container.appendChild(count);
    container.appendChild(list);

    function updateList() {
      const found = S.filterCartridges(DATA, listState);
      count.textContent = F.countText(found.length);
      list.textContent = '';
      if (found.length === 0) {
        list.appendChild(el('li', { class: 'empty' }, ['No cartridge matches these filters.']));
        return;
      }
      for (const r of found) {
        list.appendChild(
          el('li', { class: 'row' }, [
            el('a', { class: 'name', href: cartridgeHref(r.key) }, [r.name]),
            el('span', { class: 'family' }, [r.family]),
            el('span', { class: 'l3' }, [
              el('span', { class: 'sym' }, ['L3']),
              ' ' + F.formatNumber(r.cartridge.lengths.L3),
              el('span', { class: 'unit' }, [' mm']),
            ]),
          ]),
        );
      }
    }
    updateList();
  }

  function factList(record) {
    const cap = capacityText(record.annotations.publishedCapacity);
    const items = [];
    const add = (label, value) => {
      if (value === null || value === undefined || value === '') return;
      items.push(el('div', null, [el('dt', null, [label]), el('dd', null, [value])]));
    };
    add('Alternative names', (record.alternativeNames || []).join(' · ') || null);
    add('Family', record.family);
    add('Category', record.annotations.category);
    add('Primer type', record.annotations.primerType);
    add('C.I.P. table', record.tab);
    add('Country', record.country);
    add('Published', F.formatDate(record.published));
    add('Revised', F.formatDate(record.revised));
    add('Pressure method', record.pressureMethod);
    if (cap) {
      const parts = [cap.value];
      if (cap.note) parts.push(cap.note);
      const dd = el('dd', null, [parts.join(' · ') + ' · Source: ']);
      if (cap.url) dd.appendChild(el('a', { href: cap.url, rel: 'noopener' }, [cap.source || cap.url]));
      else dd.appendChild(document.createTextNode(cap.source || ''));
      items.push(el('div', null, [el('dt', null, ['Water capacity']), dd]));
    } else {
      add('Water capacity', 'Not published');
    }
    return el('dl', { class: 'facts' }, items);
  }

  function valuesTable(section) {
    return el('table', { class: 'values-table' }, [
      el('thead', null, [
        el('tr', null, [
          el('th', { scope: 'col' }, ['Symbol']),
          el('th', { scope: 'col', class: 'num' }, ['Value']),
          el('th', { scope: 'col' }, ['Unit']),
        ]),
      ]),
      el(
        'tbody',
        null,
        section.rows.map((row) =>
          el('tr', null, [
            el('td', { class: 'sym' }, [row.symbol]),
            el('td', { class: 'num' }, [row.value]),
            el('td', { class: 'unit' }, [row.unit]),
          ]),
        ),
      ),
    ]);
  }

  function valuesGroup(title, sections, groupName) {
    const items = sections.filter((s) => s.group === groupName);
    if (items.length === 0) return [];
    return [
      el('h2', null, [title]),
      ...items.map((s) =>
        el('section', { class: 'values-section', 'aria-label': s.title }, [el('h3', null, [s.title]), valuesTable(s)]),
      ),
    ];
  }

  function renderDetail(container, record) {
    setTitle(record.name);
    const geom = GEO.build(record);
    const lay = geom.ok ? LAY.layout(record, geom) : null;
    const notes = [].concat(lay ? lay.notes : geom.notes).filter((n, i, a) => a.indexOf(n) === i);

    const toolbar = el('nav', { class: 'toolbar no-print', 'aria-label': 'Cartridge' }, [
      el('a', { href: '#/', class: 'back' }, ['All cartridges']),
      el(
        'button',
        {
          type: 'button',
          class: 'print',
          onclick: () => window.print(),
        },
        ['Print'],
      ),
    ]);

    const drawing = el('figure', { class: 'drawing' });
    if (lay) drawing.innerHTML = SVG.render(record, lay);
    else drawing.appendChild(el('p', { class: 'missing' }, ['The drawing cannot be built from the published values.']));

    const noteList = notes.length
      ? el('ul', { class: 'notes' }, notes.map((n) => el('li', null, [n])))
      : null;

    const sections = F.sectionsFor(record);
    const sheet = el('article', { class: 'cartridge', 'aria-labelledby': 'cartridge-title' }, [
      el('header', { class: 'cartridge-head' }, [el('h1', { id: 'cartridge-title' }, [record.name]), factList(record)]),
      el('section', { class: 'drawing-section', 'aria-labelledby': 'drawing-title' }, [
        el('h2', { id: 'drawing-title' }, ['Drawing']),
        drawing,
        noteList ? el('div', { class: 'drawing-notes' }, [el('h3', null, ['Drawing notes']), noteList]) : null,
      ]),
      el('div', { class: 'values' }, [
        ...valuesGroup('Cartridge values', sections, 'cartridge'),
        ...valuesGroup('Chamber values', sections, 'chamber'),
      ]),
      el('footer', { class: 'print-footer' }, [
        `Source: C.I.P. TDCC, table ${record.tab}, revised ${record.revised}. Data: OpenBallistics (MIT), commit e83db43.`,
      ]),
    ]);
    // Print fit: the sheet is laid out at full printable width and scaled to one page.
    const estimate = printHeightMm(record, 190, lay);
    const scale = Math.min(1, PRINT_HEIGHT_MM / estimate);
    const fit = el('div', { class: 'print-fit' }, [sheet]);
    fit.style.setProperty('--print-scale', String(scale));
    fit.style.setProperty('--print-height', (estimate * scale).toFixed(1) + 'mm');

    container.appendChild(toolbar);
    container.appendChild(fit);
  }

  function renderNotFound(container, key) {
    setTitle('Not found');
    const prefix = '#/cartridge/';
    container.appendChild(el('h1', null, ['Cartridge not found']));
    if (key && key.indexOf(prefix) === 0) {
      container.appendChild(el('p', null, ['No cartridge has the key ', el('code', null, [key.slice(prefix.length)])]));
    } else {
      container.appendChild(el('p', null, ['This address is not part of the reference.']));
    }
    container.appendChild(el('p', null, [el('a', { href: '#/' }, ['All cartridges'])]));
  }

  function render() {
    const route = parseRoute(location.hash);
    const container = main();
    container.textContent = '';
    if (route.view === 'list') renderList(container);
    else if (route.view === 'detail') {
      const record = findByKey(route.key);
      if (record) renderDetail(container, record);
      else renderNotFound(container, '#/cartridge/' + route.key);
    } else renderNotFound(container, route.key);
    container.focus({ preventScroll: false });
    window.scrollTo(0, 0);
  }

  function start() {
    window.addEventListener('hashchange', render);
    render();
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
  }

  return API;
});
