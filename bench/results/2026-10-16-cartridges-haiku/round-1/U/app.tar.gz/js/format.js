/*
 * Value, unit and symbol formatting for the cartridge reference.
 * Pure functions only: no DOM access, so they can be tested in Node.
 */
(function (root, factory) {
  const api = factory();
  root.CIP = Object.assign(root.CIP || {}, { format: api });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // Fields whose values are angles (degrees, or {degrees, minutes, seconds}).
  const ANGLE_FIELDS = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);

  // Units that differ from the default. Lengths and diameters default to mm.
  const UNITS = {
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: '',
  };

  // Symbols that differ from the field name.
  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };

  const CARTRIDGE_SECTIONS = [
    ['caseHead', 'Case head'],
    ['collar', 'Collar'],
    ['junctionCone', 'Junction cone'],
    ['lengths', 'Lengths'],
    ['misc', 'Misc'],
    ['powderChamber', 'Powder chamber'],
    ['pressures', 'Pressures'],
    ['projectile', 'Projectile'],
  ];

  const CHAMBER_SECTIONS = [
    ['barrel', 'Barrel'],
    ['breech', 'Breech'],
    ['collar', 'Collar'],
    ['grooves', 'Grooves'],
    ['junctionCone', 'Junction cone'],
    ['lengths', 'Lengths'],
    ['powderChamber', 'Powder chamber'],
    ['rifling', 'Rifling'],
  ];

  function pad2(n) {
    const s = String(n);
    return s.length < 2 ? '0' + s : s;
  }

  function formatNumber(n) {
    return String(n);
  }

  function formatAngle(a) {
    if (typeof a === 'number') return String(a) + '°';
    return String(a.degrees) + '°' + pad2(a.minutes) + "'" + pad2(a.seconds) + '"';
  }

  function isAngleValue(field, value) {
    return ANGLE_FIELDS.has(field) || (value !== null && typeof value === 'object');
  }

  function formatValue(field, value) {
    return isAngleValue(field, value) ? formatAngle(value) : formatNumber(value);
  }

  function symbolFor(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unitFor(field) {
    if (ANGLE_FIELDS.has(field)) return '';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  // Rows for one section object. Tolerance keys (<X>Tol) are merged into X.
  function rowsFor(section, sectionId) {
    const rows = [];
    for (const field of Object.keys(section)) {
      if (/Tol$/.test(field)) continue;
      const value = section[field];
      let text = formatValue(field, value);
      const tolKey = field + 'Tol';
      if (Object.prototype.hasOwnProperty.call(section, tolKey)) {
        text += ' ' + formatNumber(section[tolKey]);
      }
      rows.push({
        section: sectionId,
        field,
        symbol: symbolFor(field),
        value: text,
        unit: unitFor(field),
      });
    }
    return rows;
  }

  function hasEntries(obj) {
    return obj !== null && typeof obj === 'object' && Object.keys(obj).length > 0;
  }

  // Grouped sections for a record: cartridge values first, then chamber values.
  // Sections with no published values are omitted.
  function sectionsFor(record) {
    const out = [];
    const add = (group, source, titles) => {
      if (!source) return;
      const known = titles.filter(([id]) => hasEntries(source[id]));
      const knownIds = new Set(titles.map(([id]) => id));
      const extra = Object.keys(source).filter((id) => !knownIds.has(id) && hasEntries(source[id]));
      for (const [id, title] of known) {
        out.push({ group, id, title, rows: rowsFor(source[id], id) });
      }
      for (const id of extra) {
        out.push({ group, id, title: id, rows: rowsFor(source[id], id) });
      }
    };
    add('cartridge', record.cartridge, CARTRIDGE_SECTIONS);
    add('chamber', record.chamber, CHAMBER_SECTIONS);
    return out;
  }

  function formatDate(published) {
    return String(published);
  }

  function countText(n) {
    return n === 1 ? '1 cartridge' : n + ' cartridges';
  }

  return {
    formatNumber,
    formatAngle,
    formatValue,
    symbolFor,
    unitFor,
    rowsFor,
    sectionsFor,
    formatDate,
    countText,
    ANGLE_FIELDS,
  };
});
