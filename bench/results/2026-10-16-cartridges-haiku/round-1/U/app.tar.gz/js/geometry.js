/*
 * Cartridge geometry for the drawing. Pure functions, millimetres, no DOM.
 *
 * Points are {r, z}: r is the radius, z the distance along the axis from the
 * head face (z = 0). Outlines are the half-profile from the axis at the head
 * face to the mouth (case) or from the mouth to the axis at the tip (bullet).
 * Curves are sampled into points.
 */
(function (root, factory) {
  const api = factory();
  root.CIP = Object.assign(root.CIP || {}, { geometry: api });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const DEG = Math.PI / 180;
  const MAX_STEP = 3 * DEG; // angular step for sampled curves
  const CENTREFIRE_PRIMERS = new Set(['sp', 'spm', 'sr', 'lp', 'lpm', 'lr', 'lrm']);
  const PRIMER_POCKET = {
    sp: { d: 4.45, depth: 3.04 },
    spm: { d: 4.45, depth: 3.04 },
    sr: { d: 4.45, depth: 3.04 },
    lp: { d: 5.33, depth: 3.04 },
    lpm: { d: 5.33, depth: 3.04 },
    lr: { d: 5.33, depth: 3.3 },
    lrm: { d: 5.33, depth: 3.3 },
  };

  function isNum(x) {
    return typeof x === 'number' && Number.isFinite(x);
  }

  // Angle values are a number of degrees or {degrees, minutes, seconds}.
  function deg(x) {
    if (isNum(x)) return x;
    if (x && isNum(x.degrees)) {
      return x.degrees + (isNum(x.minutes) ? x.minutes / 60 : 0) + (isNum(x.seconds) ? x.seconds / 3600 : 0);
    }
    return undefined;
  }

  function sub(a, b) {
    return { r: a.r - b.r, z: a.z - b.z };
  }
  function len(a) {
    return Math.hypot(a.r, a.z);
  }
  function unit(a) {
    const l = len(a);
    return l === 0 ? { r: 0, z: 0 } : { r: a.r / l, z: a.z / l };
  }
  function add(a, b) {
    return { r: a.r + b.r, z: a.z + b.z };
  }
  function scale(a, s) {
    return { r: a.r * s, z: a.z * s };
  }

  function classifyRim(family, R1, P1) {
    if (family === 'belted') return 'belted';
    if (family === 'rimfire') return 'rimfire';
    const ratio = R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Tangent arc between segment A-C and C-B with radius rad.
  // Returns { t1, t2, arc } where arc runs from t1 to t2 (both included), or null.
  function fillet(A, C, B, rad) {
    if (!isNum(rad) || rad <= 0) return null;
    const u1 = unit(sub(A, C));
    const u2 = unit(sub(B, C));
    const cos = Math.max(-1, Math.min(1, u1.r * u2.r + u1.z * u2.z));
    const theta = Math.acos(cos); // interior angle at C
    if (theta < 1e-6 || Math.abs(Math.PI - theta) < 1e-6) return null;
    const half = theta / 2;
    let t = rad / Math.tan(half);
    const maxT = 0.45 * Math.min(len(sub(A, C)), len(sub(B, C)));
    const reduced = t > maxT;
    if (reduced) t = maxT;
    const effRad = t * Math.tan(half);
    const bis = unit(add(u1, u2));
    const O = add(C, scale(bis, effRad / Math.sin(half)));
    const T1 = add(C, scale(u1, t));
    const T2 = add(C, scale(u2, t));
    const e1 = unit(sub(T1, O));
    const e2 = unit(sub(T2, O));
    const steps = Math.max(2, Math.ceil((Math.PI - theta) / MAX_STEP));
    const arc = [];
    for (let i = 0; i <= steps; i++) {
      const s = i / steps;
      const dir = unit({ r: (1 - s) * e1.r + s * e2.r, z: (1 - s) * e1.z + s * e2.z });
      arc.push(add(O, scale(dir, effRad)));
    }
    arc[0] = T1;
    arc[arc.length - 1] = T2;
    return { t1: T1, t2: T2, arc, reduced, radius: effRad };
  }

  // Sampled circular arc from angle a0 to a1 (radians) in the (r, z) plane.
  function arcSample(cr, cz, rad, a0, a1) {
    const steps = Math.max(2, Math.ceil(Math.abs(a1 - a0) / MAX_STEP));
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const a = a0 + ((a1 - a0) * i) / steps;
      pts.push({ r: cr + rad * Math.cos(a), z: cz + rad * Math.sin(a) });
    }
    return pts;
  }

  function push(list, p) {
    const last = list[list.length - 1];
    if (last && Math.abs(last.r - p.r) < 1e-12 && Math.abs(last.z - p.z) < 1e-12) return;
    list.push(p);
  }

  function pushAll(list, pts) {
    for (const p of pts) push(list, p);
  }

  // Interpolated radius of an outline at height z (outline is monotonic in z).
  function radiusAt(outline, z) {
    for (let i = 0; i < outline.length - 1; i++) {
      const a = outline[i];
      const b = outline[i + 1];
      const lo = Math.min(a.z, b.z);
      const hi = Math.max(a.z, b.z);
      if (z < lo - 1e-12 || z > hi + 1e-12) continue;
      if (hi - lo < 1e-12) return Math.max(a.r, b.r);
      const k = (z - a.z) / (b.z - a.z);
      return a.r + k * (b.r - a.r);
    }
    return undefined;
  }

  function bulletParameters(shape, category, G) {
    const pistol = category === 'pistol';
    switch (shape) {
      case 'pointy':
        return { s: 1.0 * G, k: 0.4, m: Math.max(0.08 * G, 1.27), nose: 'ogive' };
      case 'rounded':
        return { s: (pistol ? 0.4 : 0.8) * G, k: pistol ? 0.65 : 0.55, m: 0.15 * G, nose: 'ellipse' };
      case 'flat':
        return { s: (pistol ? 0.4 : 0.8) * G, k: pistol ? 0.7 : 0.6, m: 0.55 * G, nose: 'cone' };
      case 'semi_wadcutter':
        return { s: 0.6 * G, k: 0.78, m: 0.6 * G, nose: 'cone' };
      default:
        return null;
    }
  }

  function buildBullet(record, v, notes, walls, heeled) {
    const ann = record.annotations || {};
    const shape = ann.defaultBulletShape;
    const category = ann.category;
    const G1 = v.G1;
    const L3 = v.L3;
    const L6 = v.L6;
    const params = bulletParameters(shape, category, G1);
    if (!params) {
      notes.push('Bullet shape not published: bullet not drawn');
      return null;
    }
    if (!isNum(L6)) {
      notes.push('L6 missing: bullet not drawn');
      return null;
    }
    const Gx = heeled ? v.H2 : G1; // exposed diameter
    const s = params.s;
    const zb = L3 - s;
    const Lb = L6 - zb;
    const zc = zb + params.k * Lb;
    const n = L6 - zc;
    const m = params.m;
    const exposedR = Gx / 2;
    const seatR = heeled ? v.H2 / 2 - walls.tb : Gx / 2;

    const nose = [];
    if (params.nose === 'ogive') {
      const d = exposedR - m / 2;
      const rho = (d * d + n * n) / (2 * d);
      const cr = exposedR - rho;
      const phiEnd = Math.atan2(n, m / 2 - cr);
      const arc = arcSample(cr, zc, rho, 0, phiEnd);
      arc[arc.length - 1] = { r: m / 2, z: L6 };
      pushAll(nose, arc);
    } else if (params.nose === 'ellipse') {
      const ar = exposedR - m / 2;
      const arcPts = [];
      const steps = Math.ceil((Math.PI / 2) / MAX_STEP) + 1;
      for (let i = 0; i <= steps; i++) {
        const t = ((Math.PI / 2) * i) / steps;
        arcPts.push({ r: m / 2 + ar * Math.cos(t), z: zc + n * Math.sin(t) });
      }
      arcPts[0] = { r: exposedR, z: zc };
      arcPts[arcPts.length - 1] = { r: m / 2, z: L6 };
      pushAll(nose, arcPts);
    } else {
      push(nose, { r: m / 2, z: L6 });
    }

    const outline = [];
    push(outline, { r: exposedR, z: L3 });
    push(outline, { r: exposedR, z: zc });
    pushAll(outline, nose);
    push(outline, { r: 0, z: L6 });

    // Section of the bullet: seated heel, then the exposed bullet to the tip.
    const section = [{ r: 0, z: zb }, { r: seatR, z: zb }, { r: seatR, z: L3 }];
    push(section, { r: exposedR, z: L3 });
    push(section, { r: exposedR, z: zc });
    pushAll(section, nose);
    push(section, { r: 0, z: L6 });

    return {
      shape,
      category,
      G: Gx,
      heeled,
      s,
      k: params.k,
      m,
      zb,
      Lb,
      zc,
      tipZ: L6,
      exposedR,
      seatR,
      outline,
      section,
    };
  }

  function build(record) {
    const notes = [];
    const cf = record.cartridge || {};
    const cd = cf.caseHead || {};
    const col = cf.collar || {};
    const jc = cf.junctionCone || {};
    const len_ = cf.lengths || {};
    const pc = cf.powderChamber || {};
    const proj = cf.projectile || {};
    const ann = record.annotations || {};

    const v = {
      R1: cd.R1,
      R: cd.R,
      E: cd.E,
      E1: cd.E1,
      eMin: cd.eMin,
      f: cd.f,
      beta: deg(cd.beta),
      delta: deg(cd.delta),
      R3: cd.R3,
      P1: pc.P1,
      P2: pc.P2,
      H1: col.H1,
      H2: col.H2,
      L1: len_.L1,
      L2: len_.L2,
      L3: len_.L3,
      L6: len_.L6,
      S: jc.S,
      alpha: deg(jc.alpha),
      r1Min: jc.r1Min,
      r2: jc.r2,
      G1: proj.G1,
    };

    const core = ['R1', 'P1', 'R', 'H2', 'L3', 'G1'];
    const missing = core.filter((k) => !isNum(v[k]));
    if (missing.length > 0) {
      notes.push(`Cannot draw the case: ${missing.join(', ')} missing`);
      return { ok: false, notes };
    }

    const family = record.family;
    const rimType = classifyRim(family, v.R1, v.P1);
    const rimR = v.R1 / 2;
    const rimfire = rimType === 'rimfire';

    // ---- Head face and rim edge -------------------------------------------
    const outer = [{ r: 0, z: 0 }];
    let topZ;
    let rimTop;
    if (rimfire) {
      const rho = Math.max(0, Math.min(v.R / 2, (v.R1 - v.P1) / 2));
      if (rho > 0) {
        const headEnd = rimR - rho;
        push(outer, { r: headEnd, z: 0 });
        pushAll(outer, arcSample(headEnd, rho, rho, -Math.PI / 2, Math.PI / 2));
        topZ = 2 * rho;
        rimTop = { r: headEnd, z: topZ };
      } else {
        push(outer, { r: rimR, z: 0 });
        push(outer, { r: rimR, z: v.R });
        topZ = v.R;
        rimTop = { r: rimR, z: topZ };
      }
    } else {
      const chamfer = isNum(v.beta) && v.beta < 90 && isNum(v.f);
      if (chamfer) {
        const c = Math.min(v.f * Math.tan(v.beta * DEG), rimR / 2);
        push(outer, { r: rimR - c, z: 0 });
        push(outer, { r: rimR, z: v.f });
      } else {
        push(outer, { r: rimR, z: 0 });
        if (!isNum(v.beta) || !isNum(v.f)) notes.push('beta or f not published: head corner drawn square');
      }
      push(outer, { r: rimR, z: v.R });
      topZ = v.R;
      rimTop = { r: rimR, z: topZ };
    }

    // ---- Extractor groove or step -----------------------------------------
    const hasE = isNum(v.E);
    const hasE1 = isNum(v.E1);
    let groove = false;
    let beltEndZ;
    let bodyZ;
    if (hasE && hasE1) {
      groove = true;
      const floorLen = isNum(v.eMin) ? v.eMin : 0;
      if (!isNum(v.eMin)) notes.push('eMin missing: groove floor drawn with zero length');
      push(outer, { r: v.E1 / 2, z: topZ });
      push(outer, { r: v.E1 / 2, z: topZ + floorLen });
      const floorEnd = { r: v.E1 / 2, z: topZ + floorLen };
      const belt = rimType === 'belted';
      if (belt && isNum(v.R3) && isNum(v.delta) && v.delta > 0) {
        const beltR = v.R3 / 2;
        const dz = (beltR - v.E1 / 2) / Math.tan(v.delta * DEG);
        const zr = floorEnd.z + dz;
        if (zr < v.E) {
          push(outer, { r: beltR, z: zr });
          push(outer, { r: beltR, z: v.E });
          beltEndZ = zr;
        } else {
          notes.push('belt ramp does not fit before E: straight ramp drawn');
        }
      } else if (belt) {
        notes.push('R3 or delta missing: belt not drawn, straight ramp drawn');
      }
      push(outer, { r: v.P1 / 2, z: v.E });
      bodyZ = v.E;
    } else {
      if (hasE !== hasE1) notes.push(`${hasE ? 'E1' : 'E'} missing: no extractor groove drawn`);
      push(outer, { r: v.P1 / 2, z: topZ });
      bodyZ = topZ;
    }

    // ---- Body and shoulder ------------------------------------------------
    const hasAlpha = isNum(v.alpha);
    let bottleneck = hasAlpha && isNum(v.L1) && isNum(v.L2);
    if (bottleneck && !(isNum(v.P2) && isNum(v.H1))) {
      notes.push('P2 or H1 missing: shoulder not drawn, case drawn straight');
      bottleneck = false;
    }
    const mouth = { r: v.H2 / 2, z: v.L3 };
    let shoulder = null;
    if (bottleneck) {
      const A = { r: v.P1 / 2, z: bodyZ };
      const C1 = { r: v.P2 / 2, z: v.L1 };
      const C2 = { r: v.H1 / 2, z: v.L2 };
      const B = mouth;
      if (!isNum(v.r1Min)) notes.push('r1 min missing: body-side corner drawn sharp');
      if (!isNum(v.r2)) notes.push('r2 missing: neck-side corner drawn sharp');
      const f1 = fillet(A, C1, C2, v.r1Min);
      const f2 = fillet(C1, C2, B, v.r2);
      if (f1) pushAll(outer, f1.arc); else push(outer, C1);
      if (f2) pushAll(outer, f2.arc); else push(outer, C2);
      push(outer, B);
      const apexComputed = C1.z - (C1.r * (C2.z - C1.z)) / (C2.r - C1.r);
      shoulder = {
        halfAngle: Math.atan2(Math.abs(C1.r - C2.r), Math.abs(C2.z - C1.z)) / DEG,
        apexZ: isNum(v.S) ? v.S : apexComputed,
        apexComputed,
        C1,
        C2,
      };
    } else {
      if (hasAlpha && !isNum(v.L1)) notes.push('L1 missing: case drawn straight');
      push(outer, mouth);
    }

    // ---- Walls and cavity -------------------------------------------------
    const tn = (v.H2 - v.G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * v.P1 / 2);
    const walls = { tn, tb };
    const heeled = v.H2 - v.G1 <= 0.015;

    const bullet = buildBullet(record, v, notes, walls, heeled);

    // primer pocket
    let pocket = null;
    const primer = ann.primerType;
    if (rimfire) {
      pocket = null;
    } else if (CENTREFIRE_PRIMERS.has(primer)) {
      const p = PRIMER_POCKET[primer];
      pocket = { r: p.d / 2, depth: p.depth, d: p.d, primer };
    } else {
      notes.push('primer type not published: no primer pocket drawn');
    }

    // solid head depth w
    const wTerms = [2.5, 0.25 * v.P1 / 2];
    if (pocket) wTerms.push(pocket.depth + 1.5);
    if (groove && beltEndZ !== undefined) wTerms.push(beltEndZ + tb);
    else if (groove) wTerms.push(v.E + tb);
    const w = Math.max(...wTerms);

    // inner cavity: outer offset by the wall, never narrower than the bullet
    const seatR = heeled ? v.H2 / 2 - tb : v.G1 / 2;
    const wallAt = (z) => {
      if (!bottleneck) return tb;
      if (z <= v.L1) return tb;
      if (z >= v.L2) return tn;
      return tb + ((z - v.L1) / (v.L2 - v.L1)) * (tn - tb);
    };
    const innerR = (r, z) => Math.max(r - wallAt(z), seatR);

    const outerAtW = radiusAt(outer, w);
    const cavity = [];
    if (outerAtW !== undefined) {
      cavity.push({ r: innerR(outerAtW, w), z: w });
      for (const p of outer) {
        if (p.z > w + 1e-9) push(cavity, { r: innerR(p.r, p.z), z: p.z });
      }
    }

    const sectionCase = [];
    if (pocket) push(sectionCase, { r: pocket.r, z: 0 });
    for (const p of outer.slice(pocket ? 1 : 0)) push(sectionCase, p);
    for (let i = cavity.length - 1; i >= 0; i--) push(sectionCase, cavity[i]);
    push(sectionCase, { r: 0, z: w });
    if (pocket) {
      push(sectionCase, { r: 0, z: pocket.depth });
      push(sectionCase, { r: pocket.r, z: pocket.depth });
    }

    const result = {
      ok: true,
      notes,
      rimType,
      rimTopZ: topZ,
      rimTop,
      rimR,
      bodyZ,
      groove,
      bottleneck,
      heeled,
      outer,
      shoulder,
      walls,
      w,
      pocket,
      bullet,
      values: v,
      section: { case: sectionCase },
      outline: bullet ? outer.concat(bullet.outline) : outer.slice(),
    };
    return result;
  }

  return { build, classifyRim, fillet, bulletParameters, radiusAt, deg };
});
