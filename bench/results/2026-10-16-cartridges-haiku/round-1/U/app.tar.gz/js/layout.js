/*
 * Dimension, label and title-block layout for the cartridge drawing.
 *
 * SVG coordinates: x = z (mm, head at 0), and y = -r for the outside view
 * (upper half) or y = +r for the section (lower half). One unit is one mm.
 * Pure functions: no DOM access.
 */
(function (root, factory) {
  const api = factory(
    typeof module !== 'undefined' && module.exports ? require('./format.js') : root.CIP.format,
    typeof module !== 'undefined' && module.exports ? require('./geometry.js') : root.CIP.geometry,
  );
  root.CIP = Object.assign(root.CIP || {}, { layout: api });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (F, GEO) {
  'use strict';

  const FS = 3.2; // label font size, mm
  const CW = 0.62 * FS; // estimated character width
  const LH = 1.5 * FS; // row pitch
  const MARGIN = 0.25;

  function textBox(text, x, yBase, anchor) {
    const w = text.length * CW;
    const x1 = anchor === 'start' ? x : anchor === 'end' ? x - w : x - w / 2;
    return { text, x1, x2: x1 + w, y1: yBase - 0.8 * FS, y2: yBase + 0.2 * FS, x, y: yBase, anchor };
  }

  function grow(b, m) {
    return { x1: b.x1 - m, x2: b.x2 + m, y1: b.y1 - m, y2: b.y2 + m };
  }

  function boxHitsSeg(b, s) {
    const minX = Math.min(s.x1, s.x2);
    const maxX = Math.max(s.x1, s.x2);
    const minY = Math.min(s.y1, s.y2);
    const maxY = Math.max(s.y1, s.y2);
    return maxX >= b.x1 && minX <= b.x2 && maxY >= b.y1 && minY <= b.y2;
  }

  function boxes(a, b) {
    return a.x1 < b.x2 && b.x1 < a.x2 && a.y1 < b.y2 && b.y1 < a.y2;
  }

  // Interior crossing of two axis-aligned segments (touching ends do not count).
  function crosses(p, q) {
    const pH = p.y1 === p.y2;
    const qH = q.y1 === q.y2;
    if (pH === qH) return false;
    const h = pH ? p : q;
    const v = pH ? q : p;
    const vx = v.x1;
    const hy = h.y1;
    const hMin = Math.min(h.x1, h.x2);
    const hMax = Math.max(h.x1, h.x2);
    const vMin = Math.min(v.y1, v.y2);
    const vMax = Math.max(v.y1, v.y2);
    return vx > hMin + 1e-9 && vx < hMax - 1e-9 && hy > vMin + 1e-9 && hy < vMax - 1e-9;
  }

  function polylineSegments(pts, kind, mapY) {
    const out = [];
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i];
      const b = pts[i + 1];
      out.push({ x1: a.z, y1: mapY(a.r), x2: b.z, y2: mapY(b.r), kind });
    }
    return out;
  }

  // Collision state shared by all placements of one drawing.
  function Board(outlineSegs) {
    this.boxes = [];
    this.segs = [];
    this.outline = outlineSegs;
  }

  Board.prototype.fits = function (newBoxes, newSegs, opts) {
    const useOutline = !opts || opts.outline !== false;
    for (const b of newBoxes) {
      const g = grow(b, MARGIN);
      for (const p of this.boxes) if (boxes(g, p)) return false;
      for (const s of this.segs) if (boxHitsSeg(g, s)) return false;
      if (useOutline) for (const s of this.outline) if (boxHitsSeg(g, s)) return false;
    }
    for (const s of newSegs) {
      for (const p of this.boxes) if (boxHitsSeg(grow(p, MARGIN), s)) return false;
      for (const q of this.segs) if (crosses(s, q)) return false;
    }
    return true;
  };

  Board.prototype.add = function (newBoxes, newSegs) {
    for (const b of newBoxes) this.boxes.push(b);
    for (const s of newSegs) this.segs.push(s);
  };

  function arrowAt(x, y, dx, dy) {
    return { x, y, dx, dy };
  }

  function layout(record, geom) {
    const notes = geom.notes.slice();
    const empty = {
      ok: false,
      notes,
      dims: [],
      labelBoxes: [],
      outlineSegments: [],
      angle: null,
      titleBlock: { box: { x1: 0, x2: 0, y1: 0, y2: 0 }, lines: [] },
      viewBox: { x: 0, y: 0, w: 100, h: 60 },
    };
    if (!geom.ok) return empty;

    const v = geom.values;
    const bullet = geom.bullet;
    const outlineUpper = geom.outline; // case outer + bullet outline (r, z)
    const sectionPts = geom.section.case.concat(bullet ? bullet.section : []);
    const maxOutR = Math.max(...outlineUpper.map((p) => p.r));
    const maxSecR = Math.max(...sectionPts.map((p) => p.r));

    const upperSegs = polylineSegments(outlineUpper, 'outline', (r) => -r);
    const lowerSegs = polylineSegments(geom.section.case, 'outline', (r) => r);
    const bulletLowerSegs = bullet ? polylineSegments(bullet.section, 'outline', (r) => r) : [];
    const board = new Board(upperSegs.concat(lowerSegs, bulletLowerSegs));

    // Radius of the complete lower outline at height z.
    const lowerR = (z) => {
      let best = 0;
      for (const pts of [geom.outer, bullet ? bullet.outline : []]) {
        const r = GEO.radiusAt(pts, z);
        if (r !== undefined && r > best) best = r;
      }
      return best;
    };

    const dims = [];
    const fmt = (value) => F.formatNumber(value);

    // ---- Axial dimensions: one tier per dimension below the section --------
    // Tiers are ordered by span, so an extension line never crosses a shorter
    // dimension line. R is labelled beside its line, the others above it.
    const axial = [];
    const addAxial = (symbol, a, b, valueText) => {
      if (!(b > a)) return;
      axial.push({ symbol, a, b, text: `${symbol} ${valueText}` });
    };
    addAxial("R", 0, v.R, fmt(v.R));
    addAxial("L3", 0, v.L3, fmt(v.L3));
    if (bullet) addAxial("L6", 0, v.L6, fmt(v.L6));
    if (geom.bottleneck) {
      addAxial("L1", 0, v.L1, fmt(v.L1));
      addAxial("L2", 0, v.L2, fmt(v.L2));
    }
    axial.sort((p, q) => p.b - q.b);

    const tierBase = maxSecR + 6.5;
    axial.forEach((d, k) => {
      const yt = tierBase + k * LH;
      const ya = lowerR(d.a) + 1;
      const yb = lowerR(d.b) + 1;
      const line = { x1: d.a, y1: yt, x2: d.b, y2: yt, kind: "dim" };
      const ext1 = { x1: d.a, y1: ya, x2: d.a, y2: yt + 1, kind: "ext" };
      const ext2 = { x1: d.b, y1: yb, x2: d.b, y2: yt + 1, kind: "ext" };
      // Extension lines of longer dimensions pass this tier at x = 0 and x = b_i.
      const passing = [0].concat(axial.slice(k + 1).map((o) => o.b));
      const clear = (box) => passing.every((x) => x < box.x1 - 0.5 || x > box.x2 + 0.5);
      const middle = textBox(d.text, (d.a + d.b) / 2, yt - 1.1, "middle");
      const beside = textBox(d.text, d.b + 1.0, yt - 1.1, "start");
      const left = textBox(d.text, d.a - 1.0, yt - 1.1, "end");
      const label = [middle, beside, left].find((c) => clear(c)) || middle;
      board.add([label], [line, ext1, ext2]);
      dims.push({
        id: d.symbol,
        kind: "axial",
        label,
        segments: [line, ext1, ext2],
        extensions: [ext1, ext2],
        arrows: [arrowAt(d.a, yt, -1, 0), arrowAt(d.b, yt, 1, 0)],
      });
    });
    const maxTier = Math.max(0, axial.length - 1);

    // ---- Diameter dimensions: one row per dimension above the outside view --
    // Rows are ordered by feature position, largest z nearest the part. Each
    // label starts to the right of its own dimension line, so no line passes
    // through a label and no shelf crosses another dimension line.
    const diam = [];
    const addDiam = (symbol, z, r, valueText) => {
      if (!(r > 0)) return;
      diam.push({ symbol, z, r, text: `${symbol} ${valueText}` });
    };
    addDiam("R1", geom.rimType === "rimfire" ? geom.rimTopZ / 2 : v.R / 2, v.R1 / 2, fmt(v.R1));
    addDiam("P1", geom.bodyZ, v.P1 / 2, fmt(v.P1));
    if (geom.bottleneck) {
      addDiam("P2", v.L1, v.P2 / 2, fmt(v.P2));
      addDiam("H1", v.L2, v.H1 / 2, fmt(v.H1));
    }
    addDiam("H2", v.L3, v.H2 / 2, fmt(v.H2));
    if (bullet) addDiam("G1", (v.L3 + bullet.zc) / 2, bullet.exposedR, fmt(v.G1));
    if (geom.groove && Number.isFinite(v.E1)) {
      addDiam("E1", geom.rimTopZ + (Number.isFinite(v.eMin) ? v.eMin / 2 : 0), v.E1 / 2, fmt(v.E1));
    }
    diam.sort((p, q) => q.z - p.z);

    // Labels are packed into shared rows: a label goes in the lowest row where
    // it does not overlap another label, and no dimension line of a feature in
    // its span rises through that row.
    const placedDiam = [];
    diam.forEach((d) => {
      const labelX = d.z + 1.7;
      const width = d.text.length * CW;
      let row = 0;
      for (;; row++) {
        const x1 = labelX - 0.6;
        const x2 = labelX + width + 0.6;
        const rowClash = placedDiam.some((p) => p.row === row && p.x1 < x2 && x1 < p.x2);
        const lineClash = placedDiam.some((p) => p.z >= d.z - 1e-9 && p.z <= x2 && p.row >= row);
        if (!rowClash && !lineClash) break;
      }
      const shelfY = -(maxOutR + 3.8) - row * LH;
      const label = textBox(d.text, labelX, shelfY - 0.9, "start");
      const dimLine = { x1: d.z, y1: -d.r, x2: d.z, y2: shelfY, kind: "dim" };
      const shelf = { x1: d.z, y1: shelfY, x2: d.z + 1.5, y2: shelfY, kind: "ext" };
      placedDiam.push({ z: d.z, row, x1: labelX, x2: labelX + width });
      board.add([label], [dimLine, shelf]);
      dims.push({
        id: d.symbol,
        kind: "diameter",
        label,
        segments: [dimLine, shelf],
        extensions: [shelf],
        arrows: [arrowAt(d.z, -d.r, 0, 1)],
      });
    });

    // ---- Shoulder angle -----------------------------------------------------
    let angle = null;
    if (geom.shoulder && Number.isFinite(v.alpha)) {
      const apexX = geom.shoulder.apexZ;
      const halfRad = (v.alpha / 2) * Math.PI / 180;
      const C1 = geom.shoulder.C1;
      const reach = Math.hypot(C1.r, apexX - C1.z);
      const rho = Math.min(0.5 * reach, 8);
      const arcPts = [];
      const steps = 8;
      for (let i = 0; i <= steps; i++) {
        const phi = (halfRad * i) / steps;
        arcPts.push({ x: apexX - rho * Math.cos(phi), y: -rho * Math.sin(phi) });
      }
      const arcSegs = [];
      for (let i = 0; i < arcPts.length - 1; i++) {
        arcSegs.push({ x1: arcPts[i].x, y1: arcPts[i].y, x2: arcPts[i + 1].x, y2: arcPts[i + 1].y, kind: 'dim' });
      }
      const legAxis = { x1: apexX - rho - 1.2, y1: 0, x2: apexX, y2: 0, kind: 'ext' };
      const legShoulder = {
        x1: apexX,
        y1: 0,
        x2: apexX - (rho + 1.2) * Math.cos(halfRad),
        y2: -(rho + 1.2) * Math.sin(halfRad),
        kind: 'ext',
      };
      const segs = arcSegs.concat([legShoulder]);
      const text = `α ${F.formatValue('alpha', record.cartridge.junctionCone.alpha)}`;
      const candidates = [];
      for (const phiDeg of [halfRad * 0.5]) {
        const R = rho + 2.4;
        candidates.push(textBox(text, apexX - R * Math.cos(phiDeg), -R * Math.sin(phiDeg), 'middle'));
      }
      // Above the silhouette, beside the apex, clear of the diameter lines.
      // Beside the G1 dimension line, which rises at the bullet, or beside the apex.
      const gx = bullet ? (v.L3 + bullet.zc) / 2 : apexX;
      candidates.push(textBox(text, Math.max(apexX, gx) + 1.2, -(maxOutR + 0.1), 'start'));
      candidates.push(textBox(text, apexX + 0.5, -(maxOutR + 0.1), 'start'));
      candidates.push(textBox(text, apexX - 0.5, -(maxOutR + 0.1), 'end'));
      for (const label of candidates) {
        if (board.fits([label], segs)) {
          board.add([label], segs);
          angle = { apexX, arc: arcPts, label };
          dims.push({
            id: 'alpha',
            kind: 'angle',
            label,
            segments: segs,
            extensions: [legShoulder, legAxis],
            arrows: [arrowAt(arcPts[0].x, arcPts[0].y, 0, 1)],
          });
          break;
        }
      }
      if (!angle) notes.push('α dimension could not be placed without overlap');
    }

    // ---- Title block ---------------------------------------------------------
    const titleTop = tierBase + (maxTier + 1) * LH + 1.5;
    const titleLines = [
      record.name,
      `C.I.P. TDCC table ${record.tab} · revised ${record.revised}`,
      `Dimensions in mm · Scale 1:1`,
    ];
    const tFs = 3.0;
    const tCw = 0.62 * tFs;
    const longest = Math.max(...titleLines.map((t) => t.length));
    const tbWidth = Math.max(60, longest * tCw + 6);
    const tbBox = { x1: 0, x2: tbWidth, y1: titleTop, y2: titleTop + 4.6 * titleLines.length + 2.5 };
    const lines = titleLines.map((t, i) => ({
      text: t,
      x: 2,
      y: titleTop + 4.6 * (i + 1) - 0.4,
      size: i === 0 ? 3.6 : tFs,
      weight: i === 0 ? 700 : 400,
    }));

    // ---- Centre line, overall view box ---------------------------------------
    const allBoxes = board.boxes.concat([tbBox]);
    const minX = Math.min(-2, ...allBoxes.map((b) => b.x1));
    const maxX = Math.max(v.L6 + 2, ...allBoxes.map((b) => b.x2));
    const minY = Math.min(-maxOutR, ...allBoxes.map((b) => b.y1));
    const maxY = tbBox.y2;
    const pad = 3;
    const viewBox = {
      x: minX - pad,
      y: minY - pad,
      w: maxX - minX + 2 * pad,
      h: maxY - minY + 2 * pad,
    };

    return {
      ok: true,
      notes,
      dims,
      labelBoxes: dims.map((d) => d.label),
      outlineSegments: upperSegs.concat(lowerSegs, bulletLowerSegs),
      upperPoints: outlineUpper.map((p) => ({ x: p.z, y: -p.r })),
      caseSection: geom.section.case.map((p) => ({ x: p.z, y: p.r })),
      bulletSection: bullet ? bullet.section.map((p) => ({ x: p.z, y: p.r })) : null,
      centreLine: { x1: -2, x2: v.L6 + 2, y: 0 },
      angle,
      titleBlock: { box: tbBox, lines },
      viewBox,
    };
  }

  return { layout, FS };
});
