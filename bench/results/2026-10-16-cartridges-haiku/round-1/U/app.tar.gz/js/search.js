/*
 * Search and family filtering for the cartridge list. Pure functions.
 */
(function (root, factory) {
  const api = factory();
  root.CIP = Object.assign(root.CIP || {}, { search: api });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const FAMILY_OPTIONS = [
    { value: 'all', label: 'All' },
    { value: 'rimless', label: 'rimless' },
    { value: 'rimmed', label: 'rimmed' },
    { value: 'belted', label: 'belted' },
    { value: 'pistol', label: 'pistol' },
    { value: 'rimfire', label: 'rimfire' },
  ];

  // Lower case, decimal comma treated as decimal point, whitespace collapsed.
  function normalise(text) {
    return String(text)
      .toLowerCase()
      .replace(/,/g, '.')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function matchesQuery(record, query) {
    const q = normalise(query);
    if (q === '') return true;
    const haystacks = [record.name].concat(record.alternativeNames || []);
    return haystacks.some((text) => normalise(text).includes(q));
  }

  function matchesFamily(record, family) {
    if (!family || family === 'all') return true;
    return record.family === family;
  }

  function filterCartridges(records, options) {
    const opts = options || {};
    return records.filter((record) => matchesFamily(record, opts.family) && matchesQuery(record, opts.query || ''));
  }

  return { FAMILY_OPTIONS, normalise, matchesQuery, filterCartridges };
});
