/*
 * SVG markup for the cartridge drawing. Takes the geometry and layout results
 * and returns a string. No DOM access, so it can be tested in Node.
 */
(function (root, factory) {
  const api = factory();
  root.CIP = Object.assign(root.CIP || {}, { svg: api });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const ARROW_LEN = 1.1;
  const ARROW_HALF = 0.35;
  const FONT = 3.2;

  function esc(text) {
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function num(n) {
    return Number(n.toFixed(3)).toString();
  }

  function pathOf(points, close) {
    if (points.length === 0) return '';
    const parts = points.map((p, i) => (i === 0 ? 'M' : 'L') + num(p.x) + ' ' + num(p.y));
    return parts.join(' ') + (close ? ' Z' : '');
  }

  function line(seg, cls) {
    return `<line class="${cls}" x1="${num(seg.x1)}" y1="${num(seg.y1)}" x2="${num(seg.x2)}" y2="${num(seg.y2)}"/>`;
  }

  // Arrowhead with its tip at (x, y), pointing along (dx, dy).
  function arrow(a) {
    const len = Math.hypot(a.dx, a.dy) || 1;
    const ux = a.dx / len;
    const uy = a.dy / len;
    const px = -uy;
    const py = ux;
    const bx = a.x - ux * ARROW_LEN;
    const by = a.y - uy * ARROW_LEN;
    const p1 = [bx + px * ARROW_HALF, by + py * ARROW_HALF];
    const p2 = [bx - px * ARROW_HALF, by - py * ARROW_HALF];
    return `<path class="arrow" d="M${num(a.x)} ${num(a.y)} L${num(p1[0])} ${num(p1[1])} L${num(p2[0])} ${num(p2[1])} Z"/>`;
  }

  function text(t) {
    const anchor = t.anchor === 'start' ? 'start' : t.anchor === 'end' ? 'end' : 'middle';
    return `<text x="${num(t.x)}" y="${num(t.y)}" text-anchor="${anchor}" font-size="${num(FONT)}">${esc(t.text)}</text>`;
  }

  // Full SVG for one cartridge. `lay` is the result of CIP.layout.layout().
  function render(record, lay) {
    const key = String(record.key).replace(/[^A-Za-z0-9_-]/g, '_');
    const vb = lay.viewBox;
    const parts = [];
    parts.push(
      `<svg class="drawing" xmlns="http://www.w3.org/2000/svg" viewBox="${num(vb.x)} ${num(vb.y)} ${num(vb.w)} ${num(vb.h)}" role="img" aria-label="${esc(record.name)} drawing">`,
    );
    parts.push(
      `<defs><pattern id="hatch-${key}" width="1.3" height="1.3" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="1.3" stroke="currentColor" stroke-width="0.12"/></pattern></defs>`,
    );
    parts.push(`<path class="section" fill="url(#hatch-${key})" d="${pathOf(lay.caseSection, true)}"/>`);
    if (lay.bulletSection) {
      parts.push(`<path class="section" fill="url(#hatch-${key})" d="${pathOf(lay.bulletSection, true)}"/>`);
    }
    parts.push(`<path class="outline" fill="none" d="${pathOf(lay.upperPoints, false)}"/>`);
    const c = lay.centreLine;
    parts.push(`<line class="centre" x1="${num(c.x1)}" y1="${num(c.y)}" x2="${num(c.x2)}" y2="${num(c.y)}" stroke-dasharray="8 1.2 1.2 1.2"/>`);
    for (const dim of lay.dims) {
      for (const seg of dim.segments) parts.push(line(seg, seg.kind === 'ext' ? 'ext' : 'dim'));
      for (const a of dim.arrows) parts.push(arrow(a));
    }
    if (lay.angle) {
      parts.push(`<path class="dim" fill="none" d="${pathOf(lay.angle.arc, false)}"/>`);
    }
    for (const dim of lay.dims) parts.push(text(dim.label));
    const tb = lay.titleBlock;
    parts.push(
      `<rect class="titleblock" x="${num(tb.box.x1)}" y="${num(tb.box.y1)}" width="${num(tb.box.x2 - tb.box.x1)}" height="${num(tb.box.y2 - tb.box.y1)}"/>`,
    );
    for (const l of tb.lines) {
      const weight = l.weight && l.weight !== 400 ? ` font-weight="${l.weight}"` : '';
      parts.push(
        `<text class="tb" x="${num(l.x)}" y="${num(l.y)}" font-size="${num(l.size)}"${weight}>${esc(l.text)}</text>`,
      );
    }
    parts.push('</svg>');
    return parts.join('');
  }

  return { render, pathOf, arrow, esc, num };
});
