# Design

## Context

The project is empty apart from `AGENTS.md` and the OpenSpec scaffold. The app must open from `file://` in Chromium, so ES module scripts (blocked for `file://` origins) and `fetch()` of a JSON file (blocked) are unavailable. See proposal.md for motivation.

## Goals / Non-Goals

**Goals:**
- A single static page that works identically from `file://` and from a static server.
- Pure, unit-testable functions for formatting, search, and drawing geometry; DOM code kept thin.
- Drawing geometry that is verifiable numerically (scale, tangency, label overlap) for all 25 records.

**Non-Goals:**
- Chamber drawings, ballistics, unit conversion, editing data, service workers, offline caching beyond the files themselves.
- Browser-engine-specific CSS or JS features beyond what current Chromium and mobile browsers support.

## Decisions

### D1. Classic scripts with a shared global namespace
Files are loaded with plain `<script src>` tags in order. Each file attaches to `window.CIP` (or `globalThis.CIP`) and, when `module.exports` exists (Node tests), also exports. This avoids ES modules, which are blocked on `file://`, and avoids a bundler.
*Alternative rejected:* ES modules with import maps (blocked on file://), a single bundled file (violates "its CSS and JavaScript files" wording and makes review harder).

### D2. Data embedded as a JavaScript file
`data/cartridges.js` assigns the 25 records, unchanged, to `CIP.DATA` as an array literal of the same JSON objects (one per line of the brief). Values are not transformed at load time.
*Alternative rejected:* `fetch('cartridges.json')` (fails on file://), XHR (same).

### D3. Hash routing
`#/` (or empty hash) is the list. `#/cartridge/<key>` is the detail view. Keys are the record's `key` (unique, URL-safe ASCII). A `hashchange` listener renders the route; unknown keys render a not-found message.
*Alternative rejected:* History API paths (need server rewrites, fail on file://).

### D4. Pure modules
- `js/format.js`: number, angle, symbol, unit, and tolerance formatting; name normalisation for search.
- `js/search.js`: matching and family filter.
- `js/geometry.js`: rim type, outline half-profile (points), bullet, walls, cavity, primer pocket, missing-value notes. Output is plain data in millimetres, `(r, z)` order as in the brief.
- `js/layout.js`: dimension and label placement, returns boxes and lines.
- `js/svg.js`: turns geometry and layout into SVG markup (string builder, no DOM access) so it can be tested in Node.
- `js/app.js`: DOM rendering, routing, events, print button. Uses `innerHTML` only with values produced by the pure modules, and escapes all text.

### D5. Geometry in (r, z), arcs as sampled points
All profiles are computed as arrays of `{r, z}` points in mm, with arcs (rounded corners, ogive, quarter ellipse) sampled at fixed angular steps (at most 3° per step). The brief asks for points; sampling keeps the section offset and the bounding checks simple. Fillet tangency is verified by tests.

### D6. Coordinates in SVG
SVG `x = z` (head at left, x = 0 at head face), SVG `y = r` for the section (below the axis) and `y = -r` for the outside view (above the axis). One user unit is one millimetre; the `viewBox` is the drawing extent plus margins, and the SVG has `width="100%"` so it scales to the container width.

### D7. Corner rounding
A fillet between two consecutive segments is computed from the tangent length `t = r · tan(φ/2)` where φ is the deflection angle. Corners whose radius is missing are left sharp and reported. If `t` exceeds half of either adjacent segment, the radius is reduced to the largest that fits and the reduction is reported as a note (never silent).

### D8. Section cavity
The cavity boundary is the outer profile offset radially by the wall thickness `t(z)`: `tb` for `z` up to the shoulder start `L1`, `tn` from `L2` on, linear between. The solid head is the region from the head face to `z = w`. The primer pocket is a rectangle `r < d/2`, `z < depth` removed from the head. Heeled bullets: exposed diameter `H2`, seated heel radius `H2/2 - tb`.

### D9. Dimension placement
- Axial dimensions (R, L1, L2, L3, L6) each take one tier below the section, ordered by span so extension lines never cross a shorter dimension line. The label is centred on its line, or beside the line end (R, and any dimension whose centred label would cover an extension line), or beside the start.
- Diameter dimensions (R1, P1, P2, H1, H2, G1, E1) rise from the outline to a shelf above the outside view. Features are processed by decreasing z; each label starts to the right of its own line and goes in the lowest row where it overlaps no label and no line of a feature in its span rises through that row. Shelves are 1.5 mm long so they do not cross neighbouring lines.
- The shoulder angle alpha is an arc about the cone apex (S when published, else the apex computed from the two shoulder points). Its label is tried at several positions above the silhouette, checked against lines, labels and the outline.
- Text width is estimated as 0.62 × font-size × characters. Tests check the same model; a browser check of rendered text boxes (Chromium) found no overlaps for the 25 records.

### D10. Print
A `@media print` block sets A4 portrait, 10 mm margins, black on white, hides the toolbar, filters and count, and shows a footer with the source and revision date. The drawing is laid out at the full 190 mm sheet width. The value tables use three CSS columns with sections kept whole. The sheet height at full width is about 320–420 mm, so the app computes a fit factor from a calibrated estimate (`printHeightMm`) and scales the sheet with a CSS transform inside a wrapper whose height is set to the scaled height, so pagination stays at one page. CSS `zoom` was tried first and gave inconsistent pagination in Chromium.

### D11. Theme and layout
CSS custom properties with `prefers-color-scheme` for light and dark. Tables use `font-variant-numeric: tabular-nums`. A single-column layout under 640 px; tables scroll horizontally in their wrapper rather than squeezing. Touch targets are at least 44 px.

### D12. Testing
Node's built-in test runner (`node --test`) with no dependencies. Tests cover format, search, geometry, layout, and SVG output for all 25 records. A browser check is run with headless Chromium on `file://` where available.

## Risks / Trade-offs

- [One A4 page versus full-width drawing] A full-width drawing is about 180–200 mm tall, and the tables need roughly 150 mm more in three columns. One page therefore requires the sheet to be scaled to about 63–100 %, which makes the drawing narrower than the paper on the tallest records. Alternatives considered: two pages (violates the brief), reducing the label font (illegible). Recorded as a known deviation for review.
- [Straight pistol cases: wall versus bullet] The rule tb = 0.6 mm for straight cases would put the cavity narrower than the bullet for 9 mm Luger and similar cases. The cavity is clamped to the bullet radius, so the body wall there is thinner than tb. This follows from the rules as written and is recorded here.
- [Geometry rules are interpreted from a compact brief] → Explicit interpretation notes in the code and tests (for example, `tan δ = dr / dz` for ramps, verified against 223 Rem.: δ = 25° and the groove ramp angle is 25.05°).
- [Labels can crowd on narrow phones] → Drawing scales to width; label font size is the only fixed size, checked by the overlap test in user units, so relative spacing is preserved when scaled.
- [Hatched bullet section may compete visually with case walls] → Bullet section uses the same hatch but the seated part is outlined separately.
- [Missing values make some drawings partial] → Each omission produces a visible note; no value is invented.

## Migration Plan

Not applicable: new project, no existing users or data. Rollback is removing the new files.

## Open Questions

None that change the specs. The unit for `Fe` (not named in the brief's unit list) is shown as `mm` because it is a length-scale value; this is recorded in the code comment and reviewed in the summary.
