# Proposal

## Why

Reloaders, gunsmiths and engineers need a fast, static, offline reference for C.I.P. cartridge dimensions. The project has 25 published C.I.P. records (OpenBallistics, MIT, commit e83db43) but no way to browse, search or read them, nor a scaled drawing derived from the published values.

## What Changes

- A static web app in the project root: `index.html`, `styles.css`, and plain JavaScript files. No framework, no build step, no runtime dependencies, no network requests. It works from `file://` in Chromium and from any static file server.
- The 25 records are embedded unchanged as data (one JSON object per record, values as given).
- Start page: heading "Cartridges", a list of every cartridge (name link, family, case length L3), a "Search" field matching names and alternative names, a "Family" select, and a "<n> cartridges" count.
- Detail view per cartridge, addressed by a hash URL that survives reload and can be bookmarked: header fields, all cartridge and chamber values grouped by section, a "Print" button, and an "All cartridges" link.
- An inline SVG drawing computed from the cartridge values with the geometry rules in the brief, true to scale (1 user unit = 1 mm), with dimension lines, a centre line, a title block, and a legend of values that could not be drawn.
- A print stylesheet: one A4 portrait page, black on white, no navigation or controls, footer with source and revision date.
- Light and dark colour schemes following the system setting; responsive layout for phone widths.
- Development-only tooling: Node.js built-in test runner (`node --test`) with a `package.json` that declares no runtime dependencies.

### Capabilities

- `cartridge-catalog`: start page list, search, family filter, count, links to detail views.
- `cartridge-detail`: detail view content, value formatting, tables, routing, print action.
- `cartridge-drawing`: geometry and SVG rendering of the cartridge drawing.
- `cartridge-print`: print layout of the detail view.

## Capabilities

### New Capabilities

- `cartridge-catalog`: browsing, searching and filtering the cartridge list.
- `cartridge-detail`: the per-cartridge reference page, its values, formatting and addressing.
- `cartridge-drawing`: the computed, to-scale 2D drawing of a cartridge case and bullet.
- `cartridge-print`: the one-page A4 print layout of a detail view.

### Modified Capabilities

None. The `openspec/specs/` directory is empty; there are no existing capabilities.

## Impact

- New files only: `index.html`, `styles.css`, `js/*.js`, `data/cartridges.js`, `tests/*`, `package.json`.
- No server code, no CDN, no fonts, no analytics.
- Dev dependencies: none required; tests use `node:test` from Node 22.
- Out of scope: editing or fetching cartridge data, chamber drawings, ballistics calculations, unit conversion, internationalisation, a build pipeline.
