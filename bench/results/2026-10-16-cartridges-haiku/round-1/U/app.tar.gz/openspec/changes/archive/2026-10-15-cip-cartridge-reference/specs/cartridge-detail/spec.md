# Spec Delta

## Purpose

Gives technical users a complete, addressable reference page for each C.I.P. cartridge: its identification, publication data, all published cartridge and chamber values with their units, and its drawing.

## ADDED Requirements

### Requirement: Detail view heading and identification
The detail view SHALL have a heading equal to the cartridge's `name`, followed by its alternative names (if any), family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method, and the published water capacity with its source link.

#### Scenario: Identification fields
- **WHEN** the detail view for "223 Rem." is shown
- **THEN** the heading reads "223 Rem."
- **AND** the page shows family "rimless", category "rifle", primer type "sr", tab "I", country "US", published "1984-06-14", revised "2017-05-17" and pressure method "Transducer"

#### Scenario: Alternative names shown when present
- **WHEN** the detail view for "308 Win." is shown
- **THEN** the alternative names "308 Winchester" and "7,62 x 51" are shown

#### Scenario: Water capacity with source
- **WHEN** a cartridge has a published `publishedCapacity`
- **THEN** the page shows the value (for example `54 gr H2O`), the note if present, and the source as a link to its `url`

### Requirement: Cartridge and chamber values in grouped tables
The detail view SHALL show every cartridge value and every chamber value in tables grouped by section, with the columns "Symbol", "Value" and "Unit". Sections with no values SHALL be omitted.

#### Scenario: Sections
- **WHEN** the detail view for "308 Win." is shown
- **THEN** cartridge sections (case head, collar, junction cone, lengths, misc, powder chamber, pressures, projectile) and chamber sections (barrel, breech, collar, grooves, junction cone, lengths, powder chamber, rifling) are each a table with headers "Symbol", "Value" and "Unit"

#### Scenario: Symbols
- **WHEN** a field is shown
- **THEN** its symbol is the field name, except `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", and `L3PlusG` "L3 + G"

#### Scenario: Tolerances are not rows
- **WHEN** a field `<X>Tol` is published
- **THEN** no row is shown for `<X>Tol`
- **AND** the tolerance is shown after the value of `X` in the same cell, for example `39.62 -0.2` for L1 with L1Tol -0.2

### Requirement: Numeric display
Numeric values SHALL be shown with a decimal point and no thousands separator, without trailing zeros after the decimal point.

#### Scenario: Plain number
- **WHEN** Pmax is 4150.0
- **THEN** the value reads `4150`

#### Scenario: Decimal value
- **WHEN** L3 is 51.18
- **THEN** the value reads `51.18`

### Requirement: Units by field
Lengths and diameters SHALL have unit `mm`. `Pmax`, `PK` and `PE` SHALL have unit `bar`, `EE` SHALL have unit `J`, `M` SHALL have unit `g`, and `Q` SHALL have unit `mm²`. `N` SHALL have no unit.

#### Scenario: Pressure unit
- **WHEN** Pmax is shown
- **THEN** its unit cell reads `bar`

#### Scenario: Count without unit
- **WHEN** grooves `N` is 6
- **THEN** the value reads `6` and the unit cell is empty

### Requirement: Angle display
An angle that is a number of degrees SHALL be shown as `D°` in the value cell. An angle object SHALL be shown as `D°MM'SS"` with zero-padded minutes and seconds. The unit cell of an angle SHALL be empty.

#### Scenario: Angle number
- **WHEN** alpha is `46.0`
- **THEN** the value reads `46°`

#### Scenario: Angle object
- **WHEN** a rifling twist `i` is `{degrees: 3, minutes: 10, seconds: 36}`
- **THEN** the value reads `3°10'36"`

#### Scenario: Zero-padded seconds
- **WHEN** an angle object has minutes 0 and seconds 5
- **THEN** the value reads `D°00'05"`

### Requirement: Names and dates as published
Cartridge names and alternative names SHALL be shown exactly as published (for example `6,5 Creedmoor`). Dates SHALL be shown exactly as published (`YYYY-MM-DD`).

#### Scenario: Name with decimal comma
- **WHEN** the detail view for "6,5 Creedmoor" is shown
- **THEN** the heading reads "6,5 Creedmoor"

### Requirement: Addressable detail views
Each detail view SHALL have its own address, of the form `#/cartridge/<key>`, that restores the same view when loaded again or bookmarked. An unknown key SHALL show a "not found" message with a link back to the list.

#### Scenario: Reload keeps the view
- **WHEN** the user is on the detail view for "22 Long Rifle" and reloads the page
- **THEN** the detail view for "22 Long Rifle" is shown again

#### Scenario: Unknown key
- **WHEN** the address names a key that is not in the data set
- **THEN** a "not found" message is shown with a link to "All cartridges"

### Requirement: Navigation and actions
The detail view SHALL have a "Print" button that opens the browser print dialog, and a link labelled "All cartridges" that returns to the start page.

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** the browser print dialog opens

#### Scenario: Back to list
- **WHEN** the user activates "All cartridges"
- **THEN** the start page is shown
