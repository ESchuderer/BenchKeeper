# Spec Delta

## Purpose

Shows each C.I.P. cartridge as a true-to-scale 2D drawing computed only from its published cartridge values, so a reader can check case, shoulder, neck and bullet dimensions visually and see which values were too incomplete to draw.

## ADDED Requirements

### Requirement: Drawing is an inline SVG, true to scale
The detail view SHALL contain an inline SVG drawing with the accessible name "<name> drawing". The SVG SHALL use a coordinate system where 1 user unit equals 1 mm, the cartridge axis is horizontal, and the head is on the left. The drawing SHALL scale to the width of the container, including phone widths.

#### Scenario: Accessible name
- **WHEN** the detail view for "9 mm Luger" is shown
- **THEN** an element with role "img" and accessible name "9 mm Luger drawing" is present

#### Scenario: Scale
- **WHEN** the drawing is rendered
- **THEN** the distance between two points 10 mm apart along the axis in the SVG user space is 10 units

### Requirement: Outside view and section
The upper half of the drawing SHALL be the outside view and the lower half SHALL be a section in which the cut case walls are hatched. A dash-dot centre line SHALL lie on the axis.

#### Scenario: Halves
- **WHEN** the drawing is rendered for any cartridge
- **THEN** the outside view and the section are both drawn, mirrored about the axis
- **AND** the cut walls of the case are hatched

### Requirement: Rim type
The rim type SHALL be belted when the family is `belted`, rimfire when the family is `rimfire`, and otherwise rimmed when R1/P1 is 1.05 or more, rebated when R1/P1 is below 0.98, and rimless in all other cases.

#### Scenario: Rimmed family
- **WHEN** the family is "rimmed" (for example "7 x 65 R")
- **THEN** the drawing treats the case as rimmed

#### Scenario: Rimless by ratio
- **WHEN** the family is "rimless" and R1/P1 is between 0.98 and 1.05 (for example "223 Rem.")
- **THEN** the drawing treats the case as rimless

### Requirement: Head face and rim edge
The head face and rim edge SHALL run from the axis at z = 0 outward. Where beta and f are published and beta is under 90°, the head face SHALL have a chamfer that reaches the rim at height f. Rimfire rim edges SHALL be a half-round of radius min(R/2, (R1 − P1)/2) whose outermost point lies at R1/2. Otherwise the corner SHALL be square.

#### Scenario: Chamfer
- **WHEN** the drawing for "223 Rem." is rendered (beta 35°, f 0.45)
- **THEN** the head face meets the rim at (R1/2, f) through a chamfer of length f·tan(beta)

#### Scenario: Rimfire half-round
- **WHEN** the drawing for "22 Long Rifle" is rendered
- **THEN** the rim edge is a half-round whose outermost point lies at R1/2

### Requirement: Extractor groove
When E and E1 are published, the outline SHALL run from the rim top inward to E1/2, along the groove floor to R + eMin, then a straight ramp to P1/2 at z = E. Without a groove, the outline SHALL step in from the rim top to P1/2 at z = R.

#### Scenario: Rimless groove
- **WHEN** the drawing for "223 Rem." is rendered
- **THEN** the ramp runs from (E1/2, R + eMin) to (P1/2, E), at an angle to the axis equal to delta (25°)

#### Scenario: No groove
- **WHEN** a case has no E or E1 (for example "357 Magnum")
- **THEN** the outline steps in from the rim top at z = R to P1/2

### Requirement: Belted extractor groove
On belted cases the groove ramp SHALL run from the floor at angle delta to the axis up to the belt radius R3/2, follow the belt to z = E, and then step in to P1/2.

#### Scenario: Belt
- **WHEN** the drawing for "300 Win. Mag." is rendered
- **THEN** the ramp runs at delta (35°) to the axis up to radius R3/2
- **AND** the belt continues at R3/2 to z = E, then steps in to P1/2

#### Scenario: Missing belt radius
- **WHEN** R3 is not published for a belted case
- **THEN** the groove is drawn as a straight ramp to (P1/2, E) and the note states that R3 is missing

### Requirement: Bottleneck body and straight body
For bottleneck cases the body SHALL be a straight line from P1/2 at the body start to (P2/2, L1). A case without alpha, L1 or L2 is straight: its body runs to (H2/2, L3) and no shoulder is drawn.

#### Scenario: Straight case
- **WHEN** the drawing for "9 mm Luger" is rendered
- **THEN** no shoulder is drawn and the body runs to (H2/2, L3)

### Requirement: Shoulder geometry
The shoulder SHALL be the line from (P2/2, L1) to (H1/2, L2), lying at alpha/2 to the axis. The body-side corner SHALL be rounded with r1 min and the neck-side corner with r2 where those values are published.

#### Scenario: Shoulder angle
- **WHEN** the drawing for "223 Rem." is rendered
- **THEN** the shoulder line lies at 23° to the axis (alpha 46° divided by 2)
- **AND** the shoulder passes through (P2/2, L1) and (H1/2, L2) before corner rounding

#### Scenario: Corner rounding
- **WHEN** r1 min and r2 are published
- **THEN** each corner is replaced by a tangent arc of the published radius

### Requirement: Neck and mouth
The neck SHALL run from (H1/2, L2) to (H2/2, L3), and the mouth face SHALL close the case at z = L3.

#### Scenario: Neck
- **WHEN** the drawing for "308 Win." is rendered
- **THEN** the neck runs from (H1/2, L2) to (H2/2, L3)

### Requirement: Bullet placement
The bullet SHALL run from the mouth to a tip at z = L6 with shank diameter G1. Its base SHALL be at zb = L3 − s, where s is 1.0·G1 for pointy, 0.8·G1 for rounded or flat rifle and rimfire, 0.4·G1 for rounded or flat pistol, and 0.6·G1 for semi-wadcutter.

#### Scenario: Pointy bullet seating
- **WHEN** the drawing for "223 Rem." is rendered (pointy, G1 5.7)
- **THEN** the base is at z = 44.7 − 5.7 = 39.0

### Requirement: Bullet cylinder and nose
The cylinder SHALL run from the base to zb + k·Lb, where Lb = L6 − zb and k is 0.40 (pointy), 0.55 (rounded rifle or rimfire), 0.65 (rounded pistol), 0.60 (flat rifle), 0.70 (flat pistol) or 0.78 (semi-wadcutter).

#### Scenario: Cylinder end
- **WHEN** the shape is flat and the cartridge is a pistol cartridge
- **THEN** the cylinder ends at zb + 0.70·Lb

### Requirement: Nose shapes
The nose SHALL run from the cylinder end to a flat meplat at z = L6. A pointy nose SHALL be a tangent ogive with meplat diameter max(0.08·G1, 1.27). A rounded nose SHALL be a quarter ellipse to a meplat of 0.15·G1. A flat nose SHALL be a straight cone to a meplat of 0.55·G1. A semi-wadcutter nose SHALL be a straight cone to a meplat of 0.6·G1.

#### Scenario: Pointy nose
- **WHEN** the shape is pointy
- **THEN** the ogive arc is tangent to the cylinder at the nose start and ends at the meplat diameter max(0.08·G1, 1.27)

#### Scenario: Rounded nose
- **WHEN** the shape is rounded
- **THEN** the nose is a quarter ellipse from the cylinder at the nose start to the meplat of diameter 0.15·G1 at the tip

#### Scenario: Flat and semi-wadcutter noses
- **WHEN** the shape is flat or semi-wadcutter
- **THEN** the nose is a straight cone to a meplat of diameter 0.55·G1 (flat) or 0.6·G1 (semi-wadcutter)

### Requirement: Heeled bullet
When H2 − G1 is 0.015 or less, the case is heeled: the exposed bullet SHALL have the case outside diameter H2, and the seated heel in the section SHALL have diameter H2 − 2·tb.

#### Scenario: Heeled case
- **WHEN** the drawing for "22 Long Rifle" is rendered
- **THEN** the exposed bullet is drawn with diameter H2 (5.72 mm)
- **AND** the seated heel in the section has diameter H2 − 2·tb

### Requirement: Outside view hides the seated bullet
The outside view SHALL show only the part of the bullet above the mouth. The section SHALL show the seated part inside the case.

#### Scenario: Outside view
- **WHEN** the outside view is drawn
- **THEN** no part of the bullet below the mouth is drawn in the upper half

### Requirement: Wall thickness
The section SHALL use neck wall thickness tn = (H2 − G1)/2 and body wall thickness tb = min(max(1.3·tn, 0.6), 0.35·P1/2).

#### Scenario: Wall thickness
- **WHEN** the section for "223 Rem." is drawn
- **THEN** tn = 0.365 mm and tb = 0.6 mm

### Requirement: Inner cavity
The inner cavity SHALL follow the outer body at tb, the neck at tn, and blend linearly between them across the shoulder.

#### Scenario: Blend across shoulder
- **WHEN** the section has a shoulder
- **THEN** the wall thickness changes linearly from tb at z = L1 to tn at z = L2

### Requirement: Solid head
The solid head SHALL run from the head face to z = w, where w is the largest of 2.5, 0.25·P1/2, the primer pocket depth plus 1.5, E + tb where an extractor groove exists, and on belted cases the belt ramp end plus tb.

#### Scenario: Head depth
- **WHEN** the section for "223 Rem." is drawn
- **THEN** the solid head reaches at least E + tb = 3.13 + 0.6

### Requirement: Primer pocket
Centrefire cases SHALL have a primer pocket at the head. Its diameter SHALL be 4.45 mm for sp, spm and sr, and 5.33 mm for lp, lpm, lr and lrm. Its depth SHALL be 3.04 mm for sp, spm, sr, lp and lpm, and 3.3 mm for lr and lrm.

#### Scenario: Small pistol primer
- **WHEN** the primer type is "sp" (for example "9 mm Luger")
- **THEN** the pocket has diameter 4.45 mm and depth 3.04 mm

#### Scenario: Large rifle primer
- **WHEN** the primer type is "lr" (for example "308 Win.")
- **THEN** the pocket has diameter 5.33 mm and depth 3.3 mm

### Requirement: Rimfire has no primer pocket
Rimfire cases SHALL NOT have a primer pocket.

#### Scenario: Rimfire
- **WHEN** a rimfire cartridge is drawn
- **THEN** no primer pocket is drawn

### Requirement: Missing values are reported, never invented
If a value needed by a rule is missing, the drawing SHALL omit only the feature that depends on it and SHALL list the missing value in a visible note under the drawing. No value SHALL be assumed.

#### Scenario: Missing r1 min
- **WHEN** the shoulder corner radius r1 min is not published (for example for "338 Lapua Mag.")
- **THEN** the body-side corner is drawn unrounded
- **AND** the note states that r1 min is missing

#### Scenario: Missing bullet diameter or length
- **WHEN** G1 or L6 is missing
- **THEN** the bullet is not drawn and the note states which value is missing

### Requirement: Dimension lines
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle alpha where the values are published. Each SHALL be labelled with its symbol and value (for example `L3 51.18`).

#### Scenario: Required dimensions
- **WHEN** the drawing for "308 Win." is rendered
- **THEN** labels for L3, L6, R1, R and P1 are present, and labels for P2, H1, H2, G1, L1, L2, E1 and alpha are present because those values are published

### Requirement: Labels do not collide
Dimension labels SHALL NOT overlap each other or the outline.

#### Scenario: Labels do not collide
- **WHEN** the drawing is rendered for any cartridge in the data set
- **THEN** no two text labels have overlapping bounding boxes
- **AND** no label box covers a point of the outline

### Requirement: Title block
The drawing SHALL include a title block containing the cartridge name, the C.I.P. table, the revision date, the text "Dimensions in mm", and the scale.

#### Scenario: Title block content
- **WHEN** the drawing for "45 Auto" is rendered
- **THEN** the title block shows "45 Auto", the table "IV", the revised date "2020-04-21", "Dimensions in mm" and the scale
