# Tasks

## 1. Project scaffold

- [x] 1.1 Create `package.json` with `"private": true`, no runtime dependencies, and scripts `test` (`node --test tests/`).
- [x] 1.2 Create the directory layout: `index.html`, `styles.css`, `js/`, `data/`, `tests/`.
- [x] 1.3 Add `.gitignore` entries for `node_modules/` if any dev tooling is installed.

## 2. Data

- [x] 2.1 Write `data/cartridges.js` with the 25 records from the brief, unchanged, as `CIP.DATA`.
- [x] 2.2 Test: exactly 25 records, unique `key`, names as published, `6,5 Creedmoor` present with comma.

## 3. Formatting (cartridge-detail)

- [x] 3.1 Red: tests for number formatting (`51.18`, `4150`, `35`, `0.1`), units by field, tolerance placement (`39.62 -0.2`), symbols map, angle formatting (`40°`, `3°10'36"`, zero padding), N without unit, dates as published.
- [x] 3.2 Green: implement `js/format.js`.
- [x] 3.3 Test: tolerance fields never produce their own row in the section tables.

## 4. Search and filters (cartridge-catalog)

- [x] 4.1 Red: tests for matching by name, alternative name, `7,62 x 51` finds `308 Win.`, `7.62` equivalent to `7,62`, case and whitespace, family filter, combined filter, zero results, count text with singular and plural.
- [x] 4.2 Green: implement `js/search.js`.

## 5. Geometry (cartridge-drawing)

- [x] 5.1 Red: tests for rim type classification (belted, rimfire, rimmed, rebated, rimless) across all 25 records.
- [x] 5.2 Red: tests for head face and chamfer, rimfire half-round, square corner.
- [x] 5.3 Red: tests for extractor groove (rimless ramp to (P1/2, E); belted ramp at delta, belt R3/2, step in), and for no-groove step.
- [x] 5.4 Red: tests for body and shoulder: shoulder line at alpha/2 to the axis, passes through (P2/2, L1) and (H1/2, L2) before rounding, fillet tangency, straight-case body, missing r1Min reported.
- [x] 5.5 Red: tests for bullet: seating depth per shape, cylinder end k·Lb per shape, ogive tangency and meplat diameter, quarter ellipse, cone meplat values, heeled case (22 Long Rifle).
- [x] 5.6 Red: tests for section walls tn and tb, cavity, solid head w (all four terms), primer pocket diameters and depths by primer type, no pocket for rimfire.
- [x] 5.7 Red: tests that a missing value omits only its feature and produces a note.
- [x] 5.8 Green: implement `js/geometry.js` until tests pass.

## 6. Layout and SVG (cartridge-drawing)

- [x] 6.1 Red: tests that labels for L3, L6, R1, R, P1 always exist; P2, H1, H2, G1, L1, L2, E1, alpha only where published.
- [x] 6.2 Red: test that no two label boxes overlap and no label box covers an outline sample point, for all 25 records.
- [x] 6.3 Red: test that the SVG has `role="img"`, accessible name `<name> drawing`, a dash-dot centre line, and a title block with name, tab, revised date, "Dimensions in mm", and scale.
- [x] 6.4 Green: implement `js/layout.js` and `js/svg.js`.

## 7. App shell and routing (cartridge-catalog, cartridge-detail)

- [x] 7.1 Write `index.html` with `lang="en"`, title, viewport meta, script tags in dependency order, and the start page structure (heading, search, family select, count live region, list).
- [x] 7.2 Implement `js/app.js`: hash routing, list rendering, search and family events, detail rendering with header fields, grouped value tables, drawing, Print button, "All cartridges" link, not-found view.
- [x] 7.3 Verify by test: the link text equals the record name; route keys resolve; unknown key shows not-found.

## 8. Styling (cartridge-detail, cartridge-print)

- [x] 8.1 Write `styles.css`: light and dark via `prefers-color-scheme`, tabular numbers, responsive layout, touch targets, focus styles.
- [x] 8.2 Write `@media print` rules: A4 portrait, black on white, navigation and controls hidden, footer with source and revision date.

## 9. Verification

- [x] 9.1 Run `npm test` and confirm all tests pass.
- [x] 9.2 Open `index.html` from disk in headless Chromium if available; check list, search, detail, drawing, print preview, and console errors.
- [x] 9.3 Confirm no network requests and no external URLs except the publisher's source link (`kwk.us`, `wikipedia`) which is an `<a href>` only.

## 10. Review

- [x] 10.1 Review the diff against the specs; check the Definition of Done in `.opencode/references/definition-of-done.md`.
