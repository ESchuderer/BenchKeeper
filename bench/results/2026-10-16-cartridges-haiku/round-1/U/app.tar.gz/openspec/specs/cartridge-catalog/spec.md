# cartridge-catalog Specification

## Purpose
Lets technical users find a C.I.P. cartridge in the reference by browsing, searching by name or alternative name, and filtering by family, then open its detail view.

## Requirements

### Requirement: Start page lists every cartridge
The start page SHALL have the heading "Cartridges" and SHALL list every cartridge in the data set, showing for each its name, family and case length L3.

#### Scenario: Full list on load
- **WHEN** the start page is opened without a search or family filter
- **THEN** all 25 cartridges are listed
- **AND** the count reads "25 cartridges"

#### Scenario: Row content
- **WHEN** a cartridge row is shown
- **THEN** it shows the family and the L3 value with its unit (for example `51.18 mm`)

### Requirement: Cartridge names link to detail views
Each cartridge name on the start page SHALL be a link whose visible text is exactly the record's `name`, and which opens that cartridge's detail view.

#### Scenario: Link text is the published name
- **WHEN** the start page is shown
- **THEN** each cartridge name link's text equals the record's `name` exactly (for example `6,5 Creedmoor`)

#### Scenario: Following a link opens the detail view
- **WHEN** the user activates the link for "308 Win."
- **THEN** the detail view for "308 Win." is shown at its own address

### Requirement: Search filters by name and alternative names
The start page SHALL provide a text field labelled "Search". As the user types, the list SHALL show only cartridges whose `name` or one of whose `alternativeNames` contains the typed text, ignoring letter case and surrounding or repeated whitespace, and treating a decimal comma and a decimal point as equivalent.

#### Scenario: Alternative name finds a cartridge
- **WHEN** the user types `7,62 x 51`
- **THEN** the list contains "308 Win."

#### Scenario: Decimal comma and point are equivalent
- **WHEN** the user types `7.62`
- **THEN** the list contains "7,62 x 39", "308 Win." and "30-06 Spring."

#### Scenario: No match
- **WHEN** the user types text that matches no name or alternative name
- **THEN** the list is empty and the count reads "0 cartridges"

### Requirement: Family select filters the list
The start page SHALL provide a select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire. Selecting an option SHALL show only cartridges of that family; All SHALL show every family. The family filter combines with the search filter.

#### Scenario: Filter by family
- **WHEN** the user selects "belted"
- **THEN** only "300 Win. Mag." and "7 mm Rem. Mag." are listed

#### Scenario: Combined filters
- **WHEN** the family is "rimless" and the search text is `6,5`
- **THEN** only the rimless cartridges whose name or alternative name contains `6,5` are listed

### Requirement: Count of listed cartridges
The start page SHALL show the text "<n> cartridges" where <n> is the number of cartridges currently listed. A count of one SHALL read "1 cartridge".

#### Scenario: Count follows filters
- **WHEN** the search or family filter changes
- **THEN** the count text is updated to the number of listed cartridges

### Requirement: Filters are announced to assistive technology
The count text SHALL be in a live region so that changes to the listed cartridges are announced.

#### Scenario: Live count
- **WHEN** the filtered result changes
- **THEN** the updated count is exposed through an `aria-live` region
