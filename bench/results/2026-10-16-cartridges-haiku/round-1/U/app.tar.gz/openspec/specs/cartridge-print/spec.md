# cartridge-print Specification

## Purpose
Lets a reader print a single cartridge reference as one A4 portrait page that stands on its own on paper: header, drawing, tables and the data source, with no screen-only controls.

## Requirements

### Requirement: Print action opens the print dialog
Activating "Print" on a detail view SHALL open the browser's print dialog for that view.

#### Scenario: Print dialog
- **WHEN** the user activates "Print"
- **THEN** the browser print dialog is opened

### Requirement: One A4 portrait page
A printed detail view SHALL fit on one A4 portrait page, in black on white, regardless of the colour scheme on screen. The drawing SHALL span the full printable width, and every drawing label SHALL remain legible.

#### Scenario: Single page
- **WHEN** the detail view for any cartridge is printed to A4 portrait
- **THEN** the output is one page

#### Scenario: Colours
- **WHEN** the system is set to dark mode and the detail view is printed
- **THEN** the printed output is black text on a white background

### Requirement: Printed content
A printed detail view SHALL show the page header with the cartridge name, the drawing, and then the tables. It SHALL NOT show navigation, the search field, the family filter, or buttons. Its footer SHALL show the source "C.I.P. TDCC" and the revision date.

#### Scenario: Elements removed from print
- **WHEN** a detail view is printed
- **THEN** the "Print" button, the "All cartridges" link and any navigation are not printed

#### Scenario: Footer source
- **WHEN** the detail view for "223 Rem." is printed
- **THEN** the footer reads with source "C.I.P. TDCC" and revision "2017-05-17"
