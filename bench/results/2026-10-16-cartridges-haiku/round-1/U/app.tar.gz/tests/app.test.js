'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const A = require('../js/app.js');
const { DATA } = require('../data/cartridges.js');

test('the start page is the empty hash, "#" or "#/"', () => {
  assert.deepEqual(A.parseRoute(''), { view: 'list' });
  assert.deepEqual(A.parseRoute('#'), { view: 'list' });
  assert.deepEqual(A.parseRoute('#/'), { view: 'list' });
});

test('a detail view has its own address, #/cartridge/<key>', () => {
  assert.deepEqual(A.parseRoute('#/cartridge/223_rem'), { view: 'detail', key: '223_rem' });
  assert.equal(A.cartridgeHref('223_rem'), '#/cartridge/223_rem');
});

test('keys are decoded from the address and round-trip through cartridgeHref', () => {
  for (const r of DATA) {
    assert.deepEqual(A.parseRoute(A.cartridgeHref(r.key)), { view: 'detail', key: r.key });
  }
});

test('an unknown address is a not-found route', () => {
  assert.equal(A.parseRoute('#/nope/x').view, 'notfound');
});

test('every key is unique and every key resolves to its record', () => {
  for (const r of DATA) assert.equal(A.findByKey(r.key), r);
  assert.equal(A.findByKey('missing'), null);
});

test('water capacity is shown with its published note and source', () => {
  const cap = A.capacityText({ grH2O: 30.5, note: 'kwk 31', source: 'kwk', url: 'http://kwk.us/cases.html' });
  assert.equal(cap.value, '30.5 gr H2O');
  assert.equal(cap.note, 'kwk 31');
  assert.equal(cap.source, 'kwk');
  assert.equal(cap.url, 'http://kwk.us/cases.html');
  assert.equal(A.capacityText(undefined), null);
});

test('the print height estimate is at least the printed height of the sheet (about 190 mm wide)', () => {
  // Measured in the print layout: 223 Rem. about 407 mm, 22 Long Rifle about 318 mm.
  const h223 = A.printHeightMm(DATA.find((r) => r.key === '223_rem'), 190);
  const h22 = A.printHeightMm(DATA.find((r) => r.key === '22_long_rifle'), 190);
  assert.ok(h223 >= 407, `223 Rem. estimate ${h223}`);
  assert.ok(h22 >= 318, `22 Long Rifle estimate ${h22}`);
  assert.ok(h223 > h22);
});
