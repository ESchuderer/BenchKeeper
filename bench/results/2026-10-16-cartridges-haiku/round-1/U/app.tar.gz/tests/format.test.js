'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../js/format.js');
const { DATA } = require('../data/cartridges.js');

const byKey = (key) => DATA.find((r) => r.key === key);

test('numbers are shown with a decimal point and no trailing .0', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150.0), '4150');
  assert.equal(F.formatNumber(35.0), '35');
  assert.equal(F.formatNumber(0.1), '0.1');
  assert.equal(F.formatNumber(0.0), '0');
});

test('no thousands separator is ever inserted', () => {
  assert.equal(F.formatNumber(1825.0), '1825');
  assert.doesNotMatch(F.formatNumber(5375.0), /[ ,.]\d{3}$/);
});

test('angle number is shown as degrees with a degree sign', () => {
  assert.equal(F.formatAngle(46.0), '46°');
  assert.equal(F.formatAngle(0.0), '0°');
});

test('angle object is shown as D°MM\'SS" with zero-padded minutes and seconds', () => {
  assert.equal(F.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(F.formatAngle({ degrees: 0, minutes: 0, seconds: 5 }), '0°00\'05"');
});

test('symbols are the field name except for the published exceptions', () => {
  const expected = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };
  for (const [key, symbol] of Object.entries(expected)) {
    assert.equal(F.symbolFor(key), symbol, key);
  }
  assert.equal(F.symbolFor('E1'), 'E1');
  assert.equal(F.symbolFor('L6'), 'L6');
  assert.equal(F.symbolFor('Pmax'), 'Pmax');
});

test('units follow the brief for each field', () => {
  assert.equal(F.unitFor('L1'), 'mm');
  assert.equal(F.unitFor('R1'), 'mm');
  assert.equal(F.unitFor('G1'), 'mm');
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('N'), '');
  assert.equal(F.unitFor('beta'), '');
  assert.equal(F.unitFor('alpha'), '');
  assert.equal(F.unitFor('i'), '');
});

test('tolerance is shown next to its value, for example 39.62 -0.2', () => {
  const row = F.rowsFor(byKey('308_win').cartridge.lengths, 'lengths').find((r) => r.field === 'L1');
  assert.equal(row.value, '39.62 -0.2');
  assert.equal(row.unit, 'mm');
});

test('tolerance fields never produce their own row', () => {
  for (const record of DATA) {
    for (const [sectionName, section] of Object.entries(record.cartridge)) {
      const rows = F.rowsFor(section, sectionName);
      for (const row of rows) {
        assert.doesNotMatch(row.field, /Tol$/, `${record.key} ${row.field}`);
      }
    }
  }
});

test('angles in rows use the angle display and an empty unit', () => {
  const rows = F.rowsFor(byKey('223_rem').chamber.rifling, 'rifling');
  const i = rows.find((r) => r.field === 'i');
  assert.equal(i.value, '3°10\'36"');
  assert.equal(i.unit, '');
  assert.equal(i.symbol, 'i');
});

test('count N has no unit', () => {
  const rows = F.rowsFor(byKey('223_rem').chamber.grooves, 'grooves');
  const n = rows.find((r) => r.field === 'N');
  assert.equal(n.value, '6');
  assert.equal(n.unit, '');
});

test('sections of a record are grouped with their rows', () => {
  const sections = F.sectionsFor(byKey('308_win'));
  const cartridge = sections.filter((s) => s.group === 'cartridge').map((s) => s.id);
  const chamber = sections.filter((s) => s.group === 'chamber').map((s) => s.id);
  assert.deepEqual(cartridge, ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile']);
  assert.deepEqual(chamber, ['barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling']);
  for (const s of sections) {
    assert.ok(s.rows.length > 0, `${s.id} has rows`);
    assert.equal(s.title.length > 0, true);
  }
});

test('sections with no published values are omitted', () => {
  const sections = F.sectionsFor(byKey('9_mm_luger'));
  const ids = sections.map((s) => s.id);
  assert.ok(!ids.includes('junctionCone'), 'empty junction cone omitted');
  assert.ok(!ids.includes('lengths') || sections.find((s) => s.id === 'lengths').rows.length > 0);
});

test('chamber junction cone r1Max keeps its symbol and mm unit', () => {
  const rows = F.rowsFor(byKey('308_win').chamber.junctionCone, 'junctionCone');
  const r1 = rows.find((r) => r.field === 'r1Max');
  assert.equal(r1.symbol, 'r1 max');
  assert.equal(r1.unit, 'mm');
});

test('names and dates are shown exactly as published', () => {
  assert.equal(byKey('6_5_creedmoor').name, '6,5 Creedmoor');
  assert.equal(F.formatDate('1984-06-14'), '1984-06-14');
});

test('count text pluralises for zero, one and many', () => {
  assert.equal(F.countText(0), '0 cartridges');
  assert.equal(F.countText(1), '1 cartridge');
  assert.equal(F.countText(25), '25 cartridges');
});
