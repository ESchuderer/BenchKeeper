'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../js/geometry.js');
const { DATA } = require('../data/cartridges.js');

const byKey = (key) => DATA.find((r) => r.key === key);
const close = (a, b, eps = 1e-6, msg) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} expected ${b}, got ${a}`);
const dist = (p, q) => Math.hypot(p.r - q.r, p.z - q.z);
const hasPoint = (pts, r, z, eps = 1e-6) => pts.some((p) => Math.abs(p.r - r) <= eps && Math.abs(p.z - z) <= eps);
const angleFromAxis = (p, q) => Math.atan2(Math.abs(q.r - p.r), Math.abs(q.z - p.z)) * 180 / Math.PI;

// Point-in-polygon (even-odd) for (r, z) polygons.
function inside(poly, p) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const b = poly[j];
    if ((a.z > p.z) !== (b.z > p.z) && p.r < ((b.r - a.r) * (p.z - a.z)) / (b.z - a.z) + a.r) c = !c;
  }
  return c;
}

test('every record can be built, or reports the missing core value', () => {
  for (const record of DATA) {
    const g = G.build(record);
    assert.equal(typeof g.ok, 'boolean', record.key);
    assert.ok(Array.isArray(g.notes), record.key);
    if (g.ok) {
      assert.ok(g.outer.length >= 3, record.key);
      assert.ok(g.section.case.length >= 4, record.key);
    }
  }
});

test('rim type: belted and rimfire follow the family', () => {
  assert.equal(G.build(byKey('300_win_mag')).rimType, 'belted');
  assert.equal(G.build(byKey('7_mm_rem_mag')).rimType, 'belted');
  assert.equal(G.build(byKey('22_long_rifle')).rimType, 'rimfire');
  assert.equal(G.build(byKey('17_hmr')).rimType, 'rimfire');
});

test('rim type: ratio R1/P1 decides rimmed and rimless for other families', () => {
  assert.equal(G.build(byKey('9_mm_luger')).rimType, 'rimless'); // 9.96 / 9.93
  assert.equal(G.build(byKey('223_rem')).rimType, 'rimless'); // 9.6 / 9.58
  assert.equal(G.build(byKey('38_special')).rimType, 'rimmed'); // 11.18 / 9.63 >= 1.05
  assert.equal(G.build(byKey('7_x_65_r')).rimType, 'rimmed'); // 13.32 / 11.89
});

test('head: chamfer from (R1/2 - f·tan β, 0) to (R1/2, f) then up to (R1/2, R)', () => {
  const g = G.build(byKey('223_rem'));
  const c = 0.45 * Math.tan(35 * Math.PI / 180);
  close(g.outer[1].r, 9.6 / 2 - c, 1e-9, 'chamfer start r');
  close(g.outer[1].z, 0, 1e-9, 'chamfer start z');
  close(g.outer[2].r, 9.6 / 2, 1e-9, 'rim r');
  close(g.outer[2].z, 0.45, 1e-9, 'rim chamfer end z');
  assert.ok(hasPoint(g.outer, 9.6 / 2, 1.14), 'rim top at (R1/2, R)');
});

test('head: rimfire half-round has radius min(R/2, (R1-P1)/2) and its outermost point at R1/2', () => {
  const g = G.build(byKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const maxR = Math.max(...g.outer.map((p) => p.r));
  close(maxR, 7.06 / 2, 1e-9, 'outermost point');
  const at = g.outer.find((p) => Math.abs(p.r - 7.06 / 2) < 1e-9);
  close(at.z, rho, 1e-6, 'outermost point height is the radius');
  close(g.rimTopZ, 2 * rho, 1e-9, 'rim top height');
});

test('head: square corner when beta or f is not published, with a note', () => {
  const g = G.build(byKey('22_win_mag_r_f'));
  assert.equal(g.rimType, 'rimfire');
  const g2 = G.build(byKey('7_x_65_r')); // beta 45, f 0.3 published
  assert.ok(g2.outer.length > 3);
});

test('groove (rimless): shelf to E1/2, floor to R + eMin, straight ramp to (P1/2, E)', () => {
  const g = G.build(byKey('223_rem'));
  assert.ok(hasPoint(g.outer, 8.43 / 2, 1.14), 'shelf end at (E1/2, R)');
  assert.ok(hasPoint(g.outer, 8.43 / 2, 1.14 + 0.76), 'floor end at (E1/2, R + eMin)');
  assert.ok(hasPoint(g.outer, 9.58 / 2, 3.13), 'ramp end at (P1/2, E)');
});

test('groove (rimless): ramp angle to the axis equals delta', () => {
  const g = G.build(byKey('223_rem'));
  const floor = { r: 8.43 / 2, z: 1.14 + 0.76 };
  const end = { r: 9.58 / 2, z: 3.13 };
  close(angleFromAxis(floor, end), 25.0, 0.1, 'ramp angle ~ delta 25');
});

test('groove (belted): ramp at delta to the axis up to R3/2, belt to z = E, then step in to P1/2', () => {
  const g = G.build(byKey('300_win_mag'));
  const rb = 13.51 / 2;
  const floorZ = 1.27 + 0.94;
  const dz = (rb - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  assert.ok(hasPoint(g.outer, rb, floorZ + dz, 1e-6), 'ramp reaches belt radius at computed z');
  assert.ok(hasPoint(g.outer, rb, 5.59), 'belt continues to z = E');
  assert.ok(hasPoint(g.outer, 13.03 / 2, 5.59), 'steps in to P1/2 at E');
  close(angleFromAxis({ r: 12.07 / 2, z: floorZ }, { r: rb, z: floorZ + dz }), 35.0, 1e-6, 'ramp angle is delta');
});

test('no groove: step in from the rim top to (P1/2, R)', () => {
  const g = G.build(byKey('357_magnum'));
  assert.ok(hasPoint(g.outer, 9.63 / 2, 1.52), 'step to (P1/2, R)');
  assert.ok(!g.outer.some((p) => Math.abs(p.r - 9.02 / 2) < 1e-9 && p.z > 1.5), 'no groove points');
});

test('shoulder: line at alpha/2 to the axis and through the cone apex S', () => {
  const g = G.build(byKey('223_rem'));
  close(g.shoulder.halfAngle, 23.0, 0.1, 'half angle 46/2');
  close(g.shoulder.apexZ, 47.12, 0.05, 'apex close to published S');
});

test('shoulder: corners are rounded with r1 min and r2, the arc tangent to both lines', () => {
  const g = G.build(byKey('223_rem'));
  assert.ok(g.outer.length > 12, 'arc points present');
  // the uncorrected corner (P2/2, L1) is not a vertex any more
  assert.ok(!hasPoint(g.outer, 9.0 / 2, 36.52), 'body corner rounded');
});

test('shoulder: missing r1 min is drawn sharp and reported', () => {
  const g = G.build(byKey('338_lapua_mag'));
  assert.equal(g.ok, true);
  assert.ok(g.notes.some((n) => /r1 min/.test(n)), g.notes.join(' | '));
  // body-side corner (P2/2, L1) stays a vertex because it is not rounded
  assert.ok(hasPoint(g.outer, 13.82 / 2, 54.9), 'corner (P2/2, L1) is sharp');
});

test('straight case: no shoulder, body runs from P1/2 straight to (H2/2, L3)', () => {
  const g = G.build(byKey('9_mm_luger'));
  assert.equal(g.bottleneck, false);
  const n = g.outer.length;
  close(g.outer[n - 1].r, 9.65 / 2, 1e-9, 'mouth r');
  close(g.outer[n - 1].z, 19.15, 1e-9, 'mouth z');
  close(g.outer[n - 2].r, 9.93 / 2, 1e-9, 'body start r');
  close(g.outer[n - 2].z, 2.98, 1e-9, 'body start z (E)');
});

test('bullet pointy 223: seating depth s = G1, base at L3 - s, cylinder to zb + 0.4·Lb', () => {
  const g = G.build(byKey('223_rem'));
  const b = g.bullet;
  close(b.s, 5.7, 1e-9, 's');
  close(b.zb, 44.7 - 5.7, 1e-9, 'zb');
  close(b.Lb, 57.4 - (44.7 - 5.7), 1e-9, 'Lb');
  close(b.zc, b.zb + 0.4 * b.Lb, 1e-9, 'zc');
  close(b.m, 1.27, 1e-9, 'meplat = max(0.08·G1, 1.27)');
  assert.equal(b.tipZ, 57.4);
});

test('bullet pointy: tangent ogive, every nose point lies on the arc of radius rho', () => {
  const g = G.build(byKey('223_rem'));
  const b = g.bullet;
  const d = b.G / 2 - b.m / 2;
  const n = b.tipZ - b.zc;
  const rho = (d * d + n * n) / (2 * d);
  const cr = b.G / 2 - rho;
  const nose = b.outline.filter((p) => p.z >= b.zc - 1e-9 && p.z <= b.tipZ + 1e-9 && p.r > 1e-9);
  assert.ok(nose.length > 5);
  for (const p of nose) {
    const dd = Math.hypot(p.r - cr, p.z - b.zc);
    if (Math.abs(p.z - b.tipZ) < 1e-9) continue; // meplat corner
    close(dd, rho, 1e-6, 'ogive point distance');
  }
  // tangent to the cylinder at the nose start
  assert.ok(hasPoint(b.outline, b.G / 2, b.zc));
});

test('bullet rounded (pistol): quarter ellipse to meplat 0.15·G1', () => {
  const g = G.build(byKey('9_mm_luger'));
  const b = g.bullet;
  close(b.s, 0.4 * 9.03, 1e-9, 's pistol rounded');
  close(b.k, 0.65, 1e-9, 'k pistol rounded');
  close(b.m, 0.15 * 9.03, 1e-9, 'meplat');
  const ar = b.G / 2 - b.m / 2;
  const bz = b.tipZ - b.zc;
  for (const p of b.outline.filter((q) => q.z > b.zc + 1e-9 && q.z < b.tipZ - 1e-9)) {
    close(Math.pow((p.r - b.m / 2) / ar, 2) + Math.pow((p.z - b.zc) / bz, 2), 1, 1e-6, 'ellipse');
  }
});

test('bullet flat (pistol 40 S&W): straight cone to meplat 0.55·G1 with k = 0.70', () => {
  const g = G.build(byKey('40_s_w'));
  const b = g.bullet;
  close(b.s, 0.4 * 10.17, 1e-9, 's');
  close(b.k, 0.70, 1e-9, 'k');
  close(b.m, 0.55 * 10.17, 1e-9, 'meplat');
  const after = b.outline.filter((p) => p.z > b.zc + 1e-9);
  assert.equal(after.length, 2, 'cone has one point at the tip edge');
});

test('bullet semi-wadcutter (357 Magnum): s = 0.6·G1, k = 0.78, meplat 0.6·G1', () => {
  const g = G.build(byKey('357_magnum'));
  const b = g.bullet;
  close(b.s, 0.6 * 9.12, 1e-9, 's');
  close(b.k, 0.78, 1e-9, 'k');
  close(b.m, 0.6 * 9.12, 1e-9, 'meplat');
});

test('bullet rifle rounded (rimfire 22 WMR is pointy; 6,5 Creedmoor pointy): s and k for rifle rounded', () => {
  // Rifle rounded is not in the data set; its rule is covered by the k and s table in code.
  assert.equal(G.bulletParameters('rounded', 'rifle', 10).s, 8);
  assert.equal(G.bulletParameters('rounded', 'rifle', 10).k, 0.55);
  assert.equal(G.bulletParameters('flat', 'rimfire', 10).k, 0.60);
  assert.equal(G.bulletParameters('flat', 'pistol', 10).s, 4);
});

test('heeled case (22 Long Rifle): exposed bullet has the case outside diameter, seated heel H2 - 2·tb', () => {
  const g = G.build(byKey('22_long_rifle'));
  const b = g.bullet;
  assert.equal(b.heeled, true);
  close(b.exposedR, 5.72 / 2, 1e-9, 'exposed radius');
  close(b.seatR, 5.72 / 2 - g.walls.tb, 1e-9, 'heel radius');
});

test('section walls: tn = (H2 - G1)/2 and tb = min(max(1.3·tn, 0.6), 0.35·P1/2)', () => {
  const g = G.build(byKey('223_rem'));
  close(g.walls.tn, (6.43 - 5.7) / 2, 1e-9, 'tn');
  close(g.walls.tb, 0.6, 1e-9, 'tb');
});

test('section: cavity mouth radius equals the bullet radius G1/2 (non-heeled)', () => {
  const g = G.build(byKey('223_rem'));
  const mouth = g.section.case.filter((p) => Math.abs(p.z - 44.7) < 1e-9);
  const minR = Math.min(...mouth.map((p) => p.r));
  close(minR, 5.7 / 2, 1e-6, 'mouth inner radius');
});

test('section: solid head reaches w = max(2.5, 0.25·P1/2, pocket + 1.5, E + tb)', () => {
  const g = G.build(byKey('223_rem'));
  close(g.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + 0.6), 1e-9, 'w');
  assert.ok(inside(g.section.case, { r: 0.5, z: g.w - 0.2 }), 'solid just below w');
  assert.ok(!inside(g.section.case, { r: 0.5, z: g.w + 0.5 }), 'cavity above w');
});

test('primer pockets: diameter and depth by primer type', () => {
  const cases = [
    ['9_mm_luger', 'sp', 4.45, 3.04],
    ['223_rem', 'sr', 4.45, 3.04],
    ['357_magnum', 'spm', 4.45, 3.04],
    ['45_auto', 'lp', 5.33, 3.04],
    ['44_rem_mag', 'lpm', 5.33, 3.04],
    ['308_win', 'lr', 5.33, 3.3],
    ['300_win_mag', 'lrm', 5.33, 3.3],
  ];
  for (const [key, primer, dia, depth] of cases) {
    const g = G.build(byKey(key));
    assert.equal(byKey(key).annotations.primerType, primer, key);
    assert.ok(g.pocket, key);
    close(g.pocket.r * 2, dia, 1e-9, `${key} diameter`);
    close(g.pocket.depth, depth, 1e-9, `${key} depth`);
    assert.ok(!inside(g.section.case, { r: 0.1, z: depth / 2 }), `${key} pocket is empty`);
  }
});

test('rimfire cases have no primer pocket', () => {
  assert.equal(G.build(byKey('22_long_rifle')).pocket, null);
});

test('missing core value: drawing not built and the missing value is named', () => {
  const broken = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete broken.cartridge.powderChamber.P1;
  const g = G.build(broken);
  assert.equal(g.ok, false);
  assert.ok(g.notes.some((n) => /P1/.test(n)), g.notes.join(' | '));
});

test('missing bullet diameter: bullet omitted and the note names G1', () => {
  const broken = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete broken.cartridge.projectile.G1;
  const g = G.build(broken);
  assert.equal(g.ok, false);
  assert.ok(g.notes.some((n) => /G1/.test(n)));
});

test('missing E1 only removes the groove and reports it', () => {
  const broken = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete broken.cartridge.caseHead.E1;
  const g = G.build(broken);
  assert.equal(g.ok, true);
  assert.ok(g.notes.some((n) => /E1/.test(n)));
  assert.equal(g.groove, false);
});

test('every record: bullet mouth junction is above the mouth and zc is beyond the mouth', () => {
  for (const record of DATA) {
    const g = G.build(record);
    if (!g.ok || !g.bullet) continue;
    assert.ok(g.bullet.zc >= g.bullet.zb, record.key);
    assert.ok(g.bullet.tipZ > g.bullet.zc, record.key);
  }
});

test('every record builds fully, with finite points only', () => {
  for (const record of DATA) {
    const g = G.build(record);
    assert.equal(g.ok, true, `${record.key} ${g.notes.join(' | ')}`);
    const all = g.outer.concat(g.section.case, g.bullet ? g.bullet.outline : [], g.bullet ? g.bullet.section : []);
    for (const p of all) {
      assert.ok(Number.isFinite(p.r) && Number.isFinite(p.z), `${record.key} non-finite point`);
      assert.ok(p.r >= -1e-9, `${record.key} negative radius`);
    }
  }
});

test('every record: the case outline runs monotonically from the head face to the mouth', () => {
  for (const record of DATA) {
    const g = G.build(record);
    for (let i = 1; i < g.outer.length; i++) {
      assert.ok(g.outer[i].z >= g.outer[i - 1].z - 1e-9, `${record.key} z decreases at ${i}`);
    }
    const last = g.outer[g.outer.length - 1];
    close(last.z, record.cartridge.lengths.L3, 1e-9, `${record.key} mouth`);
  }
});

test('every record: the bullet cylinder reaches the mouth, so the nose is outside the case', () => {
  for (const record of DATA) {
    const g = G.build(record);
    assert.ok(g.bullet.zc >= record.cartridge.lengths.L3 - 1e-9, `${record.key} zc ${g.bullet.zc} < L3`);
  }
});

test('every record: the solid head and the cavity do not overlap the bullet seat', () => {
  for (const record of DATA) {
    const g = G.build(record);
    const mouthZ = record.cartridge.lengths.L3;
    const midZ = (g.bullet.zb + mouthZ) / 2;
    // midpoint of the seated bullet lies inside the cavity, not inside the case wall
    const bulletR = g.bullet.seatR * 0.5;
    assert.ok(!inside(g.section.case, { r: bulletR, z: midZ }) || g.w > midZ, `${record.key} seated bullet in solid`);
  }
});
