'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const close = (a, b, eps, msg) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} expected ${b}, got ${a}`);
const G = require('../js/geometry.js');
const L = require('../js/layout.js');
const { DATA } = require('../data/cartridges.js');

const byKey = (key) => DATA.find((r) => r.key === key);

function layoutOf(key) {
  const record = byKey(key);
  const geom = G.build(record);
  return { record, geom, lay: L.layout(record, geom) };
}

const labelTexts = (lay) => lay.dims.map((d) => d.label.text);
const has = (lay, prefix) => labelTexts(lay).some((t) => t === prefix || t.startsWith(prefix + ' '));

function overlap(a, b) {
  return a.x1 < b.x2 && b.x1 < a.x2 && a.y1 < b.y2 && b.y1 < a.y2;
}

test('labels: L3, L6, R1, R and P1 are always present', () => {
  for (const record of DATA) {
    const { lay } = layoutOf(record.key);
    for (const sym of ['L3', 'L6', 'R1', 'R', 'P1']) {
      assert.ok(has(lay, sym), `${record.key} has ${sym}: ${labelTexts(lay).join(' | ')}`);
    }
  }
});

test('labels: P2, H1, H2, G1, L1, L2, E1 and alpha appear when published', () => {
  const full = layoutOf('308_win').lay;
  for (const sym of ['P2', 'H1', 'H2', 'G1', 'L1', 'L2', 'E1', 'α']) {
    assert.ok(has(full, sym), `308 Win. has ${sym}`);
  }
  const straight = layoutOf('9_mm_luger').lay;
  for (const sym of ['P2', 'H1', 'L1', 'L2', 'α']) {
    assert.ok(!has(straight, sym), `9 mm Luger has no ${sym}`);
  }
});

test('labels show the symbol and the published value, for example L3 51.18', () => {
  const { lay } = layoutOf('308_win');
  assert.ok(labelTexts(lay).includes('L3 51.18'), labelTexts(lay).join(' | '));
  assert.ok(labelTexts(lay).includes('L6 71.12'));
  assert.ok(labelTexts(lay).includes('α 40°'));
});

test('labels do not overlap each other, for every cartridge', () => {
  for (const record of DATA) {
    const { lay } = layoutOf(record.key);
    const boxes = lay.labelBoxes;
    for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        assert.ok(!overlap(boxes[i], boxes[j]), `${record.key}: ${boxes[i].text} overlaps ${boxes[j].text}`);
      }
    }
  }
});

function segmentHitsBox(s, b) {
  const minX = Math.min(s.x1, s.x2);
  const maxX = Math.max(s.x1, s.x2);
  const minY = Math.min(s.y1, s.y2);
  const maxY = Math.max(s.y1, s.y2);
  return maxX >= b.x1 && minX <= b.x2 && maxY >= b.y1 && minY <= b.y2;
}

test('labels do not cover the outline, for every cartridge', () => {
  for (const record of DATA) {
    const { lay } = layoutOf(record.key);
    for (const b of lay.labelBoxes) {
      for (const seg of lay.outlineSegments) {
        assert.ok(!segmentHitsBox(seg, b), `${record.key}: ${b.text} touches outline`);
      }
    }
  }
});

test('labels do not cover other dimension lines', () => {
  for (const record of DATA) {
    const { lay } = layoutOf(record.key);
    for (const b of lay.labelBoxes) {
      for (const dim of lay.dims) {
        if (dim.label === b) continue;
        for (const seg of dim.segments) {
          assert.ok(!segmentHitsBox(seg, b), `${record.key}: ${b.text} covers a dimension line of ${dim.label.text}`);
        }
      }
    }
  }
});

test('every dimension has at least one arrowhead, and extension lines for the required dimensions', () => {
  const { lay } = layoutOf('223_rem');
  for (const dim of lay.dims) {
    assert.ok(dim.arrows.length >= 1, dim.label.text);
    assert.ok(dim.extensions.length >= 1, `${dim.label.text} has extension lines`);
  }
});

test('the viewBox contains every label, line and outline point', () => {
  for (const record of DATA) {
    const { lay } = layoutOf(record.key);
    const v = lay.viewBox;
    for (const b of lay.labelBoxes) {
      assert.ok(b.x1 >= v.x && b.x2 <= v.x + v.w && b.y1 >= v.y && b.y2 <= v.y + v.h, `${record.key} ${b.text}`);
    }
    for (const seg of lay.outlineSegments) {
      for (const [x, y] of [[seg.x1, seg.y1], [seg.x2, seg.y2]]) {
        assert.ok(x >= v.x && x <= v.x + v.w && y >= v.y && y <= v.y + v.h, `${record.key} outline`);
      }
    }
  }
});

test('the drawing uses 1 user unit = 1 mm: outline x equals z in mm', () => {
  const { lay } = layoutOf('223_rem');
  const xs = lay.outlineSegments.flatMap((s) => [s.x1, s.x2]);
  close(Math.max(...xs), 57.4, 1e-9, 'tip at L6');
  close(Math.min(...xs), 0, 1e-9, 'head face at x = 0');
});

test('title block: name, C.I.P. table, revised date, "Dimensions in mm" and scale', () => {
  const { lay } = layoutOf('45_auto');
  const text = lay.titleBlock.lines.map((l) => l.text).join(' | ');
  assert.ok(text.includes('45 Auto'), text);
  assert.ok(text.includes('IV'), text);
  assert.ok(text.includes('2020-04-21'), text);
  assert.ok(text.includes('Dimensions in mm'), text);
  assert.ok(/Scale/.test(text), text);
});

test('title block lies below every label and dimension line', () => {
  for (const record of DATA) {
    const { lay } = layoutOf(record.key);
    const tb = lay.titleBlock.box;
    for (const b of lay.labelBoxes) {
      assert.ok(b.y2 <= tb.y1 + 1e-9, `${record.key} ${b.text} not above title block`);
    }
  }
});

test('alpha arc is centred on the cone apex and spans alpha/2 from the axis', () => {
  const { lay, geom } = layoutOf('223_rem');
  assert.ok(lay.angle, 'angle present');
  assert.ok(Math.abs(lay.angle.apexX - geom.shoulder.apexZ) < 1e-9);
  assert.ok(lay.angle.arc.length > 2);
});

test('missing L6 is reported and the layout still builds', () => {
  const broken = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete broken.cartridge.lengths.L6;
  const geom = G.build(broken);
  const lay = L.layout(broken, geom);
  assert.ok(lay.notes.some((n) => /L6/.test(n)));
});
