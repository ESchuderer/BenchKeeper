'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const S = require('../js/search.js');
const { DATA } = require('../data/cartridges.js');

const names = (list) => list.map((r) => r.name);

test('family options are All, rimless, rimmed, belted, pistol and rimfire, in that order', () => {
  assert.deepEqual(
    S.FAMILY_OPTIONS.map((o) => [o.value, o.label]),
    [
      ['all', 'All'],
      ['rimless', 'rimless'],
      ['rimmed', 'rimmed'],
      ['belted', 'belted'],
      ['pistol', 'pistol'],
      ['rimfire', 'rimfire'],
    ],
  );
});

test('an empty query lists every cartridge', () => {
  assert.equal(S.filterCartridges(DATA, { query: '', family: 'all' }).length, 25);
  assert.equal(S.filterCartridges(DATA, { query: '   ', family: 'all' }).length, 25);
});

test('search matches the name', () => {
  assert.deepEqual(names(S.filterCartridges(DATA, { query: '223 rem', family: 'all' })), ['223 Rem.']);
});

test('search matches an alternative name: 7,62 x 51 finds 308 Win.', () => {
  const found = names(S.filterCartridges(DATA, { query: '7,62 x 51', family: 'all' }));
  assert.ok(found.includes('308 Win.'), found.join(', '));
});

test('search is case-insensitive', () => {
  assert.ok(S.filterCartridges(DATA, { query: 'LONG RIFLE', family: 'all' }).some((r) => r.key === '22_long_rifle'));
});

test('a decimal comma and a decimal point are equivalent', () => {
  const comma = names(S.filterCartridges(DATA, { query: '7,62', family: 'all' })).sort();
  const point = names(S.filterCartridges(DATA, { query: '7.62', family: 'all' })).sort();
  assert.deepEqual(point, comma);
  assert.ok(point.includes('7,62 x 39'));
  assert.ok(point.includes('308 Win.'));
  assert.ok(point.includes('30-06 Spring.'));
});

test('extra spaces in the query are ignored', () => {
  assert.ok(S.filterCartridges(DATA, { query: '  7,62   x 51 ', family: 'all' }).some((r) => r.key === '308_win'));
});

test('a query that matches nothing gives an empty list', () => {
  assert.equal(S.filterCartridges(DATA, { query: 'zzz-no-such', family: 'all' }).length, 0);
});

test('family filter shows only the selected family', () => {
  assert.deepEqual(
    names(S.filterCartridges(DATA, { query: '', family: 'belted' })).sort(),
    ['300 Win. Mag.', '7 mm Rem. Mag.'],
  );
  assert.ok(S.filterCartridges(DATA, { query: '', family: 'rimfire' }).every((r) => r.family === 'rimfire'));
  assert.equal(S.filterCartridges(DATA, { query: '', family: 'pistol' }).length, 6);
});

test('family and search combine', () => {
  const found = S.filterCartridges(DATA, { query: '6,5', family: 'rimless' });
  assert.ok(found.length > 0);
  assert.ok(found.every((r) => r.family === 'rimless'));
  assert.ok(found.every((r) => /6[,.]5/.test(r.name) || (r.alternativeNames || []).some((a) => /6[,.]5/.test(a))));
});

test('filtering keeps the published order of the records', () => {
  const keys = S.filterCartridges(DATA, { query: '', family: 'rimless' }).map((r) => r.key);
  const original = DATA.filter((r) => r.family === 'rimless').map((r) => r.key);
  assert.deepEqual(keys, original);
});

test('an unknown family value matches no cartridge', () => {
  assert.equal(S.filterCartridges(DATA, { query: '', family: 'nope' }).length, 0);
});
