'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../js/geometry.js');
const L = require('../js/layout.js');
const S = require('../js/svg.js');
const { DATA } = require('../data/cartridges.js');

const byKey = (key) => DATA.find((r) => r.key === key);
const render = (key) => {
  const record = byKey(key);
  return S.render(record, L.layout(record, G.build(record)));
};

test('the drawing is an inline SVG with the accessible name "<name> drawing"', () => {
  const svg = render('9_mm_luger');
  assert.match(svg, /^<svg /);
  assert.match(svg, /role="img"/);
  assert.match(svg, /aria-label="9 mm Luger drawing"/);
});

test('the drawing has a viewBox and a dash-dot centre line on the axis', () => {
  const svg = render('223_rem');
  assert.match(svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/);
  assert.match(svg, /class="centre"[^>]*stroke-dasharray="8 1.2 1.2 1.2"/);
});

test('cut walls are hatched through a pattern fill', () => {
  const svg = render('308_win');
  assert.match(svg, /<pattern id="hatch-308_win"/);
  assert.match(svg, /fill="url\(#hatch-308_win\)"/);
});

test('the title block carries name, table, revision date, units and scale', () => {
  const svg = render('45_auto');
  assert.match(svg, />45 Auto</);
  assert.match(svg, /C\.I\.P\. TDCC table IV · revised 2020-04-21/);
  assert.match(svg, /Dimensions in mm · Scale 1:1/);
});

test('every dimension label appears as text, and no raw markup leaks', () => {
  const svg = render('6_5_creedmoor');
  assert.match(svg, />L3 48\.77</);
  assert.match(svg, />R1 11\.99</);
  assert.ok(!/undefined|NaN/.test(svg));
});

test('names are escaped in the markup', () => {
  const record = JSON.parse(JSON.stringify(byKey('223_rem')));
  record.name = 'A & <B>';
  const svg = S.render(record, L.layout(record, G.build(record)));
  assert.match(svg, /aria-label="A &amp; &lt;B&gt; drawing"/);
  assert.ok(svg.includes('A &amp; &lt;B&gt;</text>'), 'name escaped in title block');
});
