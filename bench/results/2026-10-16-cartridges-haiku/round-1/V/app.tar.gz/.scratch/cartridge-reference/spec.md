# Cartridge reference (static web app)

Status: ready-for-agent

A static, offline reference for 25 C.I.P. cartridges, for reloaders, gunsmiths and engineers. Modelled on the OpenBallistics cartridge database. The 25 records in `data/cartridges.jsonl` (OpenBallistics commit e83db43, MIT) are the only data; they are used exactly as given.

## Constraints

- Plain HTML, CSS and classic JavaScript. No framework, no build step for the app, no runtime dependencies, no network requests.
- Works when `index.html` is opened from disk (`file://`) in Chromium, and when the folder is served by any static server. Therefore data is loaded through a classic script (`js/data.js`), not `fetch` and not ES modules.
- Dev tooling may use npm dev dependencies (test runner, browser automation).
- Interface in English.

## Screens

### List (`#/`)

- Heading "Cartridges".
- Search field labelled "Search": filters by name and alternative names as the user types, case-insensitive substring. `7,62 x 51` finds "308 Win.".
- Select labelled "Family": All, rimless, rimmed, belted, pistol, rimfire.
- Count text "<n> cartridges" ("1 cartridge" for one).
- Table: name (link, text exactly the record's `name`, target `#/cartridge/<key>`), family, `L3` with unit.

### Detail (`#/cartridge/<key>`)

- Bookmarkable and reload-safe because the state is the hash.
- Heading = `name`. Then alternative names, family, category, primer type, C.I.P. table (`tab`), country, published and revised dates, pressure method, and published water capacity (value, note, source name linked to `url`).
- The drawing (see below).
- Tables per section, columns "Symbol", "Value", "Unit". Cartridge values first, then chamber values.
- "Print" button (calls `window.print()`) and a "All cartridges" link back to the list.
- Unknown key: a "not found" message with the link back.

## Formatting rules

- Numbers as published: `String(n)`, so `51.18`, `4150`. No thousands separators.
- Tolerance `<X>Tol` is shown in X's value cell: `39.62 -0.2`. Never its own row.
- Angles: number → `40°`; object → `D°MM'SS"` with minutes and seconds padded to two digits (`39°59'49"`, `1°30'00"`).
- Symbols: field name, except `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G".
- Units: angles `°`; `Pmax`, `PK`, `PE` bar; `EE` J; `M` g; `Q` mm²; `N` count (unit shown as "—"); everything else `mm`.
  - `S` is the distance from the head face to the shoulder apex (checked numerically: `L1 + (P2/2)/tan(α/2)` gives 47.12 for 223 Rem.), so mm.
  - `u` is the twist length in mm (305 mm ≈ 1:12 in).
  - `Fe`, `deltaL`, `F`, `Z`, `G`, `G1`, `G2`, `b`, `h`, `s`, `r`, `r1Min`, `r1Max`, `r2`, `R3`, `L4`, `L5` are lengths in mm.
- Capacity shown as `30.5 gr H₂O`.

## Drawing

Inline SVG, `role="img"`, accessible name "<name> drawing". 1 SVG unit = 1 mm, axis horizontal, head on the left, `z` along the axis, `r` radius. Upper half: outside view (silhouette). Lower half: section, cut walls and solid head hatched, bullet cut hatched. Dash-dot centre line.

Geometry follows the rules in the brief. Interpretations made where the brief leaves room:

1. Points are written `(r, z)` in the brief: `(R1/2, R)` is radius R1/2 at z = R.
2. Rimfire rim edge: head face to `R1/2 - ρ`, half-round of radius `ρ = min(R/2, (R1-P1)/2)`, apex at `(R1/2, ρ)`, top at `(R1/2 - ρ, 2ρ)`. That top point replaces `(R1/2, R)` for the groove and the step.
3. Belted groove: the ramp from the floor end is at angle δ to the axis, from radius `E1/2` to `R3/2`. It then follows the belt to `z = E` and steps in to `P1/2`.
4. Straight cases (no α, L1 or L2, or no P2/H1 when a shoulder would be needed): the body runs to `(H2/2, L3)`. For a heeled straight case (22 Long Rifle) the inner wall stays `tb` to the mouth, giving the seated heel radius `H2/2 - tb` the brief requires. For an unheeled straight case the wall tapers linearly from `tb` at the body start to `tn` at the mouth, so the seated bullet fits the mouth.
5. Heeled bullet (`H2 - G1 <= 0.015`): exposed diameter is `H2` and is used in place of `G1` for all bullet geometry. The seated heel has radius `(H2 - 2·tb)/2`. Seating, cylinder and nose factors still use the published `G1` values as given.
6. Walls: `tn = (H2 - G1)/2`, `tb = min(max(1.3·tn, 0.6), 0.35·P1/2)`. The inner line is radially offset from the outer line by `tb` on the body, `tn` on the neck, blended linearly across the shoulder (by `z`).
7. Solid head `w = max(2.5, 0.25·P1/2, pocket depth + 1.5 [centrefire only], E + tb [groove], belt ramp end + tb [belted])`. The belt ramp end is the `z` where the ramp reaches `R3/2`.
8. Primer pocket for centrefire primer types (`sp`, `spm`, `sr`, `lp`, `lpm`, `lr`, `lrm`), diameter 4.45 or 5.33, depth 3.04 or 3.3, as specified. Rimfire has none.
9. Missing values: the feature is left out and a note names the missing value. Notes appear under the title block. Examples: `r1 min` (338 Lapua Mag., 17 HMR), `E`/`E1`/`eMin` (no extractor groove), `P2`/`H1` (pistols).
10. Bullet's exposed profile: cylinder from `L3` to `zc`, nose from `zc` to the tip at `L6`. Nose per shape and `m` as specified. Tip meplat from `(m/2, L6)` to `(0, L6)`. The outside view hides the seated part.

Dimensions:

- Axial (L1, L2, L3, L6, R): horizontal dimension lines above the outline, all starting at the head face. Stacked by length, shortest nearest the case, 4.2 mm apart. Labels centred above the line. `R` is labelled to the left of the head face, because its line is too short for a label.
- R1: vertical dimension on the left of the head, horizontal extension lines from the rim edges.
- Diameters (P1, P2, H1, H2, G1, E1): vertical dimension lines in a column to the right of the tip, 5.5 mm apart. Columns are ordered by ascending diameter from left to right, so extension lines do not cross other dimension lines. Their labels are rotated and stand above the columns, in one row.
- α: small arc at the shoulder start, between the horizontal and the shoulder line. Its label sits above the body with a leader to the arc.
- Extension lines run exactly along the feature edge (no gap), so each dimension spans the true diameter.
- Labels show the nominal value only (`L3 51.18`). Tolerances are in the tables, next to the value.
- Title block below the section: name, C.I.P. table and revision date, "Dimensions in mm", "Scale 1:1" with a 10 mm scale bar. Missing values are named in one line, "Not drawn: r1 min, r2".

Label placement: labels must not overlap the outline or each other. The layout tests check this for all 25 records.

## Print

- `@media print`: A4 portrait, black on white, 7 mm margins; navigation and buttons hidden.
- One A4 page: header with the name and the published values, the drawing at full width, the tables in three columns, a footer "Source: C.I.P. TDCC, revised <date>".
- Checked by the browser tests: every one of the 25 cartridges prints on one page.

## Look and feel

- Technical reference: dense, calm, tabular numerals (`font-variant-numeric: tabular-nums`).
- Light and dark, following `prefers-color-scheme`. Print is always light.
- Usable on a phone: the drawing scales to the viewport width; tables and list reflow.

## Process and verification

- Node's built-in test runner for unit tests on pure functions (formatting, geometry, label layout).
- Browser end-to-end tests with Playwright against `file://`: list, search, filter, detail routing, reload, dark and print media, and one-page print for all 25 records.
- Not yet tested: a static server (`npx http-server` or similar). The app uses only relative paths and no fetch, so it should behave the same.
- Build step for the data file only: `scripts/build-data.js` converts `data/cartridges.jsonl` to `js/data.js`. The app does not need it at run time.
