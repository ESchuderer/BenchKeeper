# Cartridges

A static, offline reference for 25 C.I.P. cartridges: a searchable list, a detail view per cartridge with a scaled drawing and the published values, and a one-page print. Plain HTML, CSS and JavaScript; no framework, no build step and no network requests.

## Use

Open `index.html` in a browser. It also works when the folder is served by any static file server.

## Data

`data/cartridges.jsonl` holds the records as published (OpenBallistics, MIT, commit e83db43). `js/data.js` is generated from it:

    npm run build:data

## Tests

    npm install
    npm test          # unit tests (Node's built-in test runner)
    npm run test:e2e  # browser tests (needs `npx playwright install chromium`)

The design notes and the interpretations of the drawing rules are in `.scratch/cartridge-reference/spec.md`.
