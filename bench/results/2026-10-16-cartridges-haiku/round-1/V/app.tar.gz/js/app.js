// Page behaviour: the cartridge list, the detail view and hash routing.
// Runs only in a browser document; the unit tests load the other scripts without it.

var appState = { query: '', family: 'All' };

function el(tag, attributes, children) {
  const node = document.createElement(tag);
  for (const [name, value] of Object.entries(attributes || {})) {
    if (value === undefined || value === null || value === false) continue;
    if (name === 'text') node.textContent = value;
    else node.setAttribute(name, value === true ? '' : String(value));
  }
  for (const child of children || []) {
    if (child === undefined || child === null) continue;
    node.append(typeof child === 'string' ? document.createTextNode(child) : child);
  }
  return node;
}

function cartridgeHref(record) {
  return '#/cartridge/' + encodeURIComponent(record.key);
}

function currentKey() {
  const match = /^#\/cartridge\/(.+)$/.exec(location.hash);
  return match ? decodeURIComponent(match[1]) : null;
}

function renderRoute() {
  const app = document.getElementById('app');
  const key = currentKey();
  const record = key === null ? null : findCartridge(CARTRIDGE_DATA, key);
  if (key !== null) {
    document.title = record ? `${record.name} · Cartridges` : 'Cartridge not found · Cartridges';
    app.replaceChildren(record ? detailView(record) : notFoundView(key));
    window.scrollTo(0, 0);
  } else {
    document.title = 'Cartridges';
    app.replaceChildren(listView());
    updateList();
  }
}

function notFoundView(key) {
  return el('main', { class: 'page' }, [
    el('p', { class: 'toolbar' }, [el('a', { href: '#/', text: 'All cartridges' })]),
    el('h1', { text: 'Cartridge not found' }),
    el('p', { text: `No cartridge has the key "${key}".` }),
  ]);
}

function listView() {
  const select = el('select', { id: 'family', name: 'family' }, FAMILY_OPTIONS.map((family) =>
    el('option', { value: family, text: family === 'All' ? 'All' : family, selected: family === appState.family })),
  );
  const search = el('input', {
    id: 'query',
    type: 'search',
    name: 'query',
    autocomplete: 'off',
    spellcheck: 'false',
    value: appState.query,
  });
  search.addEventListener('input', () => {
    appState.query = search.value;
    updateList();
  });
  select.addEventListener('change', () => {
    appState.family = select.value;
    updateList();
  });
  return el('main', { class: 'page' }, [
    el('h1', { text: 'Cartridges' }),
    el('div', { class: 'filters', role: 'search' }, [
      el('label', { class: 'field' }, [el('span', { text: 'Search' }), search]),
      el('label', { class: 'field' }, [el('span', { text: 'Family' }), select]),
    ]),
    el('p', { id: 'count', class: 'count', 'aria-live': 'polite' }),
    el('table', { class: 'list' }, [
      el('thead', {}, [el('tr', {}, [el('th', { scope: 'col', text: 'Name' }), el('th', { scope: 'col', text: 'Family' }), el('th', { scope: 'col', class: 'num', text: 'L3' })])]),
      el('tbody', { id: 'rows' }),
    ]),
  ]);
}

function updateList() {
  const rows = document.getElementById('rows');
  const count = document.getElementById('count');
  if (!rows || !count) return;
  const matches = filterCartridges(CARTRIDGE_DATA, appState);
  count.textContent = countLabel(matches.length);
  if (matches.length === 0) {
    rows.replaceChildren(el('tr', {}, [el('td', { colspan: 3, class: 'empty', text: 'No cartridge matches.' })]));
    return;
  }
  rows.replaceChildren(...matches.map((record) => {
    const row = listRow(record);
    return el('tr', {}, [
      el('td', {}, [el('a', { href: cartridgeHref(record), text: row.name })]),
      el('td', { text: row.family }),
      el('td', { class: 'num', text: row.l3 }),
    ]);
  }));
}

function factRow(term, value) {
  return [el('dt', { text: term }), el('dd', {}, Array.isArray(value) ? value : [value])];
}

function capacityNodes(record) {
  const capacity = formatCapacity(record);
  if (!capacity) return ['not published'];
  const nodes = [capacity.value];
  if (capacity.note) nodes.push(` (${capacity.note})`);
  nodes.push(' · source: ', el('a', { href: capacity.url, text: capacity.source }));
  return nodes;
}

function tablesFor(title, sections) {
  return sections.map((section) =>
    el('section', { class: 'group' }, [
      el('h3', { text: `${title}: ${section.title}` }),
      el('table', {}, [
        el('thead', {}, [el('tr', {}, [el('th', { scope: 'col', text: 'Symbol' }), el('th', { scope: 'col', class: 'num', text: 'Value' }), el('th', { scope: 'col', text: 'Unit' })])]),
        el('tbody', {}, section.rows.map((row) =>
          el('tr', {}, [el('th', { scope: 'row', text: row.symbol }), el('td', { class: 'num', text: row.value }), el('td', { text: row.unit })]),
        )),
      ]),
    ]),
  );
}

function detailView(record) {
  const alternatives = (record.alternativeNames || []).join('; ');
  const facts = el('dl', { class: 'facts' }, [
    ...(alternatives ? [factRow('Alternative names', alternatives)] : []),
    factRow('Family', record.family),
    factRow('Category', record.annotations.category),
    factRow('Primer type', record.annotations.primerType),
    factRow('C.I.P. table', record.tab),
    factRow('Country', record.country),
    factRow('Published', record.published),
    factRow('Revised', record.revised),
    factRow('Pressure method', record.pressureMethod),
    factRow('Water capacity', capacityNodes(record)),
  ].flat());

  const figure = el('figure', { class: 'figure' });
  figure.innerHTML = renderDrawing(record);

  const printButton = el('button', { type: 'button', class: 'print', text: 'Print' });
  printButton.addEventListener('click', () => window.print());

  const footer = el('footer', { class: 'source' }, [
    el('p', { text: `Source: C.I.P. TDCC, revised ${record.revised}.` }),
    el('p', { text: 'Data: OpenBallistics (github.com/PiMetry/OpenBallistics), MIT licence.' }),
  ]);

  return el('main', { class: 'page' }, [
    el('nav', { class: 'toolbar no-print' }, [
      el('a', { href: '#/', text: 'All cartridges' }),
      printButton,
    ]),
    el('h1', { class: 'title', text: record.name }),
    facts,
    figure,
    el('div', { class: 'tables' }, [
      el('div', { class: 'column' }, [el('h2', { text: 'Cartridge values' }), ...tablesFor('Cartridge', cartridgeSections(record))]),
      el('div', { class: 'column' }, [el('h2', { text: 'Chamber values' }), ...tablesFor('Chamber', chamberSections(record))]),
    ]),
    footer,
  ]);
}

if (typeof document !== 'undefined' && document.getElementById('app')) {
  window.addEventListener('hashchange', renderRoute);
  renderRoute();
}
