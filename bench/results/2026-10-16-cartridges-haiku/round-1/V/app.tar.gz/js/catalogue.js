// Searching, filtering and list rows for the cartridge list.

var FAMILY_OPTIONS = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

function searchableNames(record) {
  return [record.name].concat(record.alternativeNames || []);
}

function filterCartridges(records, options) {
  const query = (options.query || '').trim().toLowerCase();
  const family = options.family || 'All';
  return records.filter((record) => {
    if (family !== 'All' && record.family !== family) return false;
    if (query === '') return true;
    return searchableNames(record).some((name) => name.toLowerCase().includes(query));
  });
}

function countLabel(count) {
  return count + (count === 1 ? ' cartridge' : ' cartridges');
}

function findCartridge(records, key) {
  return records.find((record) => record.key === key);
}

function listRow(record) {
  return {
    name: record.name,
    family: record.family,
    l3: formatNumber(record.cartridge.lengths.L3) + ' mm',
  };
}
