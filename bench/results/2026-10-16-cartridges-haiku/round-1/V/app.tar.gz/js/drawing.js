// Inline SVG drawing of a cartridge: outside view above the axis, section below it.
// 1 SVG unit = 1 mm, axis horizontal, head face on the left (z = 0).
// Classic script (no modules) so that index.html works from file://.

var DRAWING_STYLE = {
  fontSize: 3,
  titleSize: 4.2,
  noteSize: 2.4,
  arrowLength: 1.8,
  arrowHalf: 0.45,
  extGap: 0.6, // axial extension lines start this far beyond the outline
  firstLevel: 2.5, // distance from the largest radius to the lowest axial dimension line
  levelStep: 4.2,
  columnStart: 5, // distance from the bullet tip to the first diameter column
  columnStep: 5.5,
  leftColumn: -6, // R1 dimension line
  alphaArc: 4.5,
};

function labelBox(text, x, y, size, anchor, rotated) {
  const width = text.length * size * 0.6;
  if (!rotated) {
    const x0 = anchor === 'middle' ? x - width / 2 : anchor === 'end' ? x - width : x;
    return { x0, y0: y - 0.75 * size, x1: x0 + width, y1: y + 0.25 * size };
  }
  // Rotated -90: glyphs extend to the left of the baseline and the text runs upward from the anchor.
  const along = anchor === 'middle' ? [y - width / 2, y + width / 2] : anchor === 'end' ? [y, y + width] : [y - width, y];
  return { x0: x - 0.75 * size, y0: along[0], x1: x + 0.25 * size, y1: along[1] };
}

function arrowHead(tip, dir) {
  const S = DRAWING_STYLE;
  const bx = tip.x - dir.x * S.arrowLength;
  const by = tip.y - dir.y * S.arrowLength;
  const px = -dir.y * S.arrowHalf;
  const py = dir.x * S.arrowHalf;
  return [tip, { x: bx + px, y: by + py }, { x: bx - px, y: by - py }];
}

function segmentHitsBox(a, b, box, margin) {
  const x0 = box.x0 - margin;
  const x1 = box.x1 + margin;
  const y0 = box.y0 - margin;
  const y1 = box.y1 + margin;
  // Liang-Barsky clipping of the segment against the box.
  let t0 = 0;
  let t1 = 1;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const tests = [
    [-dx, a.x - x0],
    [dx, x1 - a.x],
    [-dy, a.y - y0],
    [dy, y1 - a.y],
  ];
  for (const [p, q] of tests) {
    if (p === 0) {
      if (q < 0) return false;
    } else {
      const t = q / p;
      if (p < 0) {
        if (t > t1) return false;
        if (t > t0) t0 = t;
      } else {
        if (t < t0) return false;
        if (t < t1) t1 = t;
      }
    }
  }
  return t0 <= t1;
}

function polylineHitsBox(points, box, margin) {
  for (let i = 0; i < points.length - 1; i++) {
    if (segmentHitsBox(points[i], points[i + 1], box, margin)) return true;
  }
  return false;
}

function boxesOverlap(a, b, margin) {
  return a.x0 < b.x1 + margin && b.x0 < a.x1 + margin && a.y0 < b.y1 + margin && b.y0 < a.y1 + margin;
}

// Lists every place where a label overlaps the outline, a section, another label or a dimension line.
function labelConflicts(drawing) {
  const conflicts = [];
  const margin = 0.2;
  for (const label of drawing.labels) {
    for (const outline of drawing.outlines) {
      if (polylineHitsBox(outline, label.box, margin)) conflicts.push(`${label.text} crosses the outline`);
    }
    for (const line of drawing.lines) {
      if (line.kind === 'centre' || line.kind === 'leader' || line.kind === 'arc') continue;
      if (segmentHitsBox({ x: line.x1, y: line.y1 }, { x: line.x2, y: line.y2 }, label.box, margin)) {
        conflicts.push(`${label.text} crosses a ${line.kind} line`);
      }
    }
  }
  for (let i = 0; i < drawing.labels.length; i++) {
    for (let j = i + 1; j < drawing.labels.length; j++) {
      if (boxesOverlap(drawing.labels[i].box, drawing.labels[j].box, margin)) {
        conflicts.push(`${drawing.labels[i].text} overlaps ${drawing.labels[j].text}`);
      }
    }
  }
  return conflicts;
}

function dimensionValue(key, record) {
  const c = record.cartridge;
  const sources = {
    L1: c.lengths.L1,
    L2: c.lengths.L2,
    L3: c.lengths.L3,
    L6: c.lengths.L6,
    R: c.caseHead.R,
    R1: c.caseHead.R1,
    P1: c.powderChamber.P1,
    P2: c.powderChamber.P2,
    H1: c.collar.H1,
    H2: c.collar.H2,
    G1: c.projectile.G1,
    E1: c.caseHead.E1,
  };
  return sources[key];
}

// Drawing labels show the nominal value only; tolerances are in the tables.
function valueText(key, record) {
  return `${key} ${formatNumber(dimensionValue(key, record))}`;
}

function buildDrawing(record) {
  const S = DRAWING_STYLE;
  const m = buildCaseModel(record);
  const c = record.cartridge;
  const ch = c.caseHead;
  const features = m.features;
  const up = (p) => ({ x: p.z, y: -p.r });
  const down = (p) => ({ x: p.z, y: p.r });

  const outline = m.outer.concat(m.bullet ? m.bullet.exposed : []).map(up);
  const outlines = [outline, m.section.map(down)];
  if (m.bullet) outlines.push(m.bullet.section.map(down));

  const Rmax = Math.max(...outline.map((p) => -p.y));
  const lines = [];
  const arrows = [];
  const labels = [];
  const dim = (a, b) => lines.push({ x1: a.x, y1: a.y, x2: b.x, y2: b.y, kind: 'dim' });
  const ext = (a, b) => lines.push({ x1: a.x, y1: a.y, x2: b.x, y2: b.y, kind: 'ext' });
  const label = (text, x, y, size, anchor, rotated) => {
    labels.push({ text, x, y, size, anchor, rotated, box: labelBox(text, x, y, size, anchor, rotated) });
  };

  // Axial dimensions above the outline, stacked by length: shortest nearest the case.
  const R1half = ch.R1 / 2;
  const L = c.lengths;
  const axial = [{ key: 'R', x0: 0, x1: ch.R, base1: R1half }];
  if (L.L1 !== undefined && features.bottleneck) {
    axial.push({ key: 'L1', x0: 0, x1: L.L1, base1: c.powderChamber.P2 / 2 });
    axial.push({ key: 'L2', x0: 0, x1: L.L2, base1: c.collar.H1 / 2 });
  }
  axial.push({ key: 'L3', x0: 0, x1: L.L3, base1: c.collar.H2 / 2 });
  axial.push({ key: 'L6', x0: 0, x1: L.L6, base1: m.bullet ? m.bullet.m / 2 : 0 });
  axial.forEach((d, i) => {
    const levelY = -(Rmax + S.firstLevel + i * S.levelStep);
    const left = { x: d.x0, y: levelY };
    const right = { x: d.x1, y: levelY };
    dim(left, right);
    arrows.push(arrowHead(left, { x: -1, y: 0 }), arrowHead(right, { x: 1, y: 0 }));
    ext({ x: d.x0, y: -(R1half + S.extGap) }, { x: d.x0, y: levelY - 1 });
    ext({ x: d.x1, y: -(d.base1 + S.extGap) }, { x: d.x1, y: levelY - 1 });
    const text = d.key === 'R' ? `R ${formatNumber(ch.R)}` : valueText(d.key, record);
    if (d.key === 'R') {
      label(text, d.x0 - 0.8, levelY - 1.3, S.fontSize, 'end', false);
    } else {
      label(text, (d.x0 + d.x1) / 2, levelY - 1.3, S.fontSize, 'middle', false);
    }
  });

  // R1 diameter on the left of the head face.
  const xR1 = S.leftColumn;
  dim({ x: xR1, y: -R1half }, { x: xR1, y: R1half });
  arrows.push(arrowHead({ x: xR1, y: -R1half }, { x: 0, y: -1 }), arrowHead({ x: xR1, y: R1half }, { x: 0, y: 1 }));
  ext({ x: -0.6, y: -R1half }, { x: xR1 - 1.2, y: -R1half });
  ext({ x: -0.6, y: R1half }, { x: xR1 - 1.2, y: R1half });
  label(`R1 ${formatNumber(ch.R1)}`, xR1 - 1.6 - 0.25 * S.fontSize, 0, S.fontSize, 'middle', true);

  // Diameters in columns to the right of the bullet tip, smallest nearest the case.
  const diameters = [{ key: 'P1', z: features.bodyZ, r: c.powderChamber.P1 / 2 }];
  if (features.bottleneck) {
    diameters.push({ key: 'P2', z: c.lengths.L1, r: c.powderChamber.P2 / 2 });
    diameters.push({ key: 'H1', z: c.lengths.L2, r: c.collar.H1 / 2 });
  }
  if (m.bullet) {
    const zc = m.bullet.zc;
    diameters.push({ key: 'H2', z: m.heeled ? zc : c.lengths.L3, r: c.collar.H2 / 2 });
    diameters.push({ key: 'G1', z: zc, r: m.bullet.exposedDiameter / 2, value: c.projectile.G1 });
  } else {
    diameters.push({ key: 'H2', z: c.lengths.L3, r: c.collar.H2 / 2 });
  }
  if (features.groove && ch.E1 !== undefined) {
    const floor = ch.eMin !== undefined ? ch.R + ch.eMin : ch.R;
    diameters.push({ key: 'E1', z: floor, r: ch.E1 / 2 });
  }
  diameters.sort((a, b) => a.r - b.r);
  const tipZ = L.L6;
  const diameterTop = Math.max(...diameters.map((d) => d.r));
  diameters.forEach((d, i) => {
    const X = tipZ + S.columnStart + i * S.columnStep;
    dim({ x: X, y: -d.r }, { x: X, y: d.r });
    arrows.push(arrowHead({ x: X, y: -d.r }, { x: 0, y: -1 }), arrowHead({ x: X, y: d.r }, { x: 0, y: 1 }));
    ext({ x: d.z, y: -d.r }, { x: X + 1.2, y: -d.r });
    ext({ x: d.z, y: d.r }, { x: X + 1.2, y: d.r });
    const text = d.key === 'G1' ? `G1 ${formatNumber(d.value)}` : d.key === 'E1' ? `E1 ${formatNumber(ch.E1)}` : valueText(d.key, record);
    label(text, X + 1.6 + 0.75 * S.fontSize, -(diameterTop + 1.6), S.fontSize, 'start', true);
  });

  // Shoulder angle: arc at the shoulder start, label with a leader.
  const notes = m.notes.slice();
  if (features.bottleneck && features.alpha !== undefined) {
    const a = (features.alpha * DEG) / 2;
    const ra = S.alphaArc;
    const L1 = c.lengths.L1;
    const P2half = c.powderChamber.P2 / 2;
    const start = { x: L1 + ra, y: -P2half };
    const end = { x: L1 + ra * Math.cos(a), y: -P2half + ra * Math.sin(a) };
    const mid = { x: L1 + ra * Math.cos(a / 2), y: -P2half + ra * Math.sin(a / 2) };
    lines.push({ kind: 'arc', d: `M ${start.x} ${start.y} A ${ra} ${ra} 0 0 1 ${end.x} ${end.y}` });
    const anchor = { x: L1 - 1.8, y: -(c.powderChamber.P1 / 2 + 2.4) };
    lines.push({ x1: anchor.x + 0.3, y1: anchor.y + 0.5, x2: mid.x, y2: mid.y, kind: 'leader' });
    label(`α ${formatAngle(c.junctionCone.alpha)}`, anchor.x, anchor.y, S.fontSize, 'end', false);
  }

  // Centre line.
  const xmaxObjects = tipZ + S.columnStart + diameters.length * S.columnStep;
  lines.push({ x1: -10, y1: 0, x2: xmaxObjects, y2: 0, kind: 'centre' });

  // Title block below the section.
  const frameTop = Rmax + 2.5;
  const titleLines = [
    { text: m.name, size: S.titleSize, weight: 'bold', y: frameTop + 4.2 },
    { text: `C.I.P. table ${record.tab} · revised ${record.revised}`, size: S.fontSize, y: frameTop + 7.6 },
    { text: 'Dimensions in mm', size: S.fontSize, y: frameTop + 10.6 },
    { text: 'Scale 1:1', size: S.fontSize, y: frameTop + 13.6 },
  ];
  const scale = { x0: 13, x1: 23, y: frameTop + 13 };
  if (notes.length) {
    const names = [...new Set(notes.map((note) => note.split(/ not | : /)[0]))];
    titleLines.push({ text: `Not drawn: ${names.join(', ')}`, size: S.noteSize, y: frameTop + 17 });
  }
  const frameBottom = frameTop + (notes.length ? 19 : 15.5);

  const xs = outline.map((p) => p.x).concat(labels.map((l) => l.box.x0), labels.map((l) => l.box.x1));
  const ys = outline.map((p) => p.y).concat(labels.map((l) => l.box.y0), labels.map((l) => l.box.y1));
  const left = Math.min(-12, ...xs) - 1;
  const right = Math.max(xmaxObjects + 2, ...xs) + 1;
  const top = Math.min(...ys) - 1.5;
  const bottom = Math.max(frameBottom, ...ys) + 1.5;

  return {
    name: record.name,
    key: record.key,
    viewBox: { x: left, y: top, width: right - left, height: bottom - top },
    outlines,
    lines,
    arrows,
    labels,
    notes,
    titleBlock: { frame: { x0: -10, y0: frameTop, x1: right - 1, y1: frameBottom }, lines: titleLines, scale },
    section: m.section,
  };
}

function pathData(points, close) {
  const parts = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${round3(p.x)} ${round3(p.y)}`);
  return parts.join(' ') + (close ? ' Z' : '');
}

function round3(value) {
  return String(Math.round(value * 1000) / 1000);
}

function escapeXml(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function renderDrawing(record) {
  const d = buildDrawing(record);
  const v = d.viewBox;
  const hatch = `hatch-${d.key}`;
  const out = [];
  out.push(
    `<svg class="drawing" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${escapeXml(d.name)} drawing" viewBox="${round3(v.x)} ${round3(v.y)} ${round3(v.width)} ${round3(v.height)}">`,
  );
  out.push(
    `<defs><pattern id="${hatch}" width="1.2" height="1.2" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="1.2" class="hatch"/></pattern></defs>`,
  );
  for (const line of d.lines) {
    if (line.kind === 'arc') {
      out.push(`<path class="dim" d="${line.d}"/>`);
    } else if (line.kind === 'centre') {
      out.push(`<line class="centre" x1="${round3(line.x1)}" y1="0" x2="${round3(line.x2)}" y2="0"/>`);
    } else if (line.kind === 'leader') {
      out.push(`<line class="ext" x1="${round3(line.x1)}" y1="${round3(line.y1)}" x2="${round3(line.x2)}" y2="${round3(line.y2)}"/>`);
    } else {
      out.push(`<line class="${line.kind}" x1="${round3(line.x1)}" y1="${round3(line.y1)}" x2="${round3(line.x2)}" y2="${round3(line.y2)}"/>`);
    }
  }
  out.push(`<path class="outline" d="${pathData(d.outlines[0], false)}"/>`);
  out.push(`<path class="cut" fill="url(#${hatch})" d="${pathData(d.outlines[1], true)}"/>`);
  if (d.outlines[2]) out.push(`<path class="cut" fill="url(#${hatch})" d="${pathData(d.outlines[2], true)}"/>`);
  for (const arrow of d.arrows) {
    out.push(`<path class="arrow" d="${pathData(arrow, true)}"/>`);
  }
  for (const label of d.labels) {
    const transform = label.rotated ? ` transform="rotate(-90 ${round3(label.x)} ${round3(label.y)})"` : '';
    out.push(
      `<text class="label" x="${round3(label.x)}" y="${round3(label.y)}" font-size="${label.size}" text-anchor="${label.anchor}"${transform}>${escapeXml(label.text)}</text>`,
    );
  }
  const tb = d.titleBlock;
  out.push(
    `<rect class="frame" x="${round3(tb.frame.x0)}" y="${round3(tb.frame.y0)}" width="${round3(tb.frame.x1 - tb.frame.x0)}" height="${round3(tb.frame.y1 - tb.frame.y0)}"/>`,
  );
  for (const line of tb.lines) {
    const weight = line.weight ? ` font-weight="${line.weight}"` : '';
    out.push(`<text class="title" x="${-9}" y="${round3(line.y)}" font-size="${line.size}"${weight}>${escapeXml(line.text)}</text>`);
  }
  out.push(`<line class="dim" x1="${tb.scale.x0}" y1="${round3(tb.scale.y)}" x2="${tb.scale.x1}" y2="${round3(tb.scale.y)}"/>`);
  out.push(`<text class="title" x="${tb.scale.x1 + 1.5}" y="${round3(tb.scale.y + 1)}" font-size="${DRAWING_STYLE.fontSize}">10 mm</text>`);
  out.push('</svg>');
  return out.join('');
}
