// Presentation rules for the cartridge records: numbers, angles, symbols, units and table sections.
// Classic script (no modules) so that index.html works from file://.

var SYMBOL_OVERRIDES = {
  eMin: 'e min',
  r1Min: 'r1 min',
  r1Max: 'r1 max',
  alpha: 'α',
  alpha1: 'α1',
  beta: 'β',
  delta: 'δ',
  deltaL: 'delta L',
  L3PlusG: 'L3 + G',
};

var ANGLE_KEYS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];

var UNIT_OVERRIDES = {
  alpha: '°',
  alpha1: '°',
  beta: '°',
  delta: '°',
  i: '°',
  Pmax: 'bar',
  PK: 'bar',
  PE: 'bar',
  EE: 'J',
  M: 'g',
  Q: 'mm²',
  N: '—',
};

var CARTRIDGE_SECTIONS = [
  ['caseHead', 'Case head'],
  ['collar', 'Collar'],
  ['junctionCone', 'Junction cone'],
  ['lengths', 'Lengths'],
  ['misc', 'Miscellaneous'],
  ['powderChamber', 'Powder chamber'],
  ['pressures', 'Pressures'],
  ['projectile', 'Projectile'],
];

var CHAMBER_SECTIONS = [
  ['barrel', 'Barrel'],
  ['breech', 'Breech'],
  ['collar', 'Collar'],
  ['grooves', 'Grooves'],
  ['junctionCone', 'Junction cone'],
  ['lengths', 'Lengths'],
  ['powderChamber', 'Powder chamber'],
  ['rifling', 'Rifling'],
];

function formatNumber(value) {
  return String(value);
}

function angleDegrees(value) {
  if (value === undefined || value === null) return undefined;
  if (typeof value === 'number') return value;
  return value.degrees + value.minutes / 60 + value.seconds / 3600;
}

function formatAngle(value) {
  if (typeof value === 'number') return formatNumber(value) + '°';
  const two = (n) => String(n).padStart(2, '0');
  return `${value.degrees}°${two(value.minutes)}'${two(value.seconds)}"`;
}

function formatValue(key, value) {
  if (ANGLE_KEYS.includes(key) || (value !== null && typeof value === 'object')) {
    return formatAngle(value);
  }
  return formatNumber(value);
}

function symbolFor(key) {
  return Object.prototype.hasOwnProperty.call(SYMBOL_OVERRIDES, key) ? SYMBOL_OVERRIDES[key] : key;
}

function unitFor(key) {
  if (Object.prototype.hasOwnProperty.call(UNIT_OVERRIDES, key)) return UNIT_OVERRIDES[key];
  return 'mm';
}

// Rows of one section object. A <X>Tol field is folded into the value of X.
function sectionRows(section) {
  const rows = [];
  for (const key of Object.keys(section)) {
    if (/Tol$/.test(key)) continue;
    let value = formatValue(key, section[key]);
    const tolerance = section[key + 'Tol'];
    if (tolerance !== undefined) value += ' ' + formatNumber(tolerance);
    rows.push({ key, symbol: symbolFor(key), value, unit: unitFor(key) });
  }
  return rows;
}

function groupSections(container, order) {
  const sections = [];
  for (const [id, title] of order) {
    const section = container[id];
    if (!section) continue;
    const rows = sectionRows(section);
    if (rows.length === 0) continue;
    sections.push({ id, title, rows });
  }
  return sections;
}

function cartridgeSections(record) {
  return groupSections(record.cartridge, CARTRIDGE_SECTIONS);
}

function chamberSections(record) {
  return groupSections(record.chamber, CHAMBER_SECTIONS);
}

function formatCapacity(record) {
  const capacity = record.annotations && record.annotations.publishedCapacity;
  if (!capacity) return null;
  return {
    value: formatNumber(capacity.grH2O) + ' gr H₂O',
    note: capacity.note,
    source: capacity.source,
    url: capacity.url,
  };
}
