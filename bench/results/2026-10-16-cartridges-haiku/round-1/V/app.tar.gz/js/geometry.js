// Geometry of a cartridge case and its bullet, from the published values.
// Points are {r, z}: r is the radius, z the distance from the head face along the axis (mm).
// Classic script (no modules) so that index.html works from file://.

var DEG = Math.PI / 180;

var PRIMER_POCKETS = {
  sp: { diameter: 4.45, depth: 3.04 },
  spm: { diameter: 4.45, depth: 3.04 },
  sr: { diameter: 4.45, depth: 3.04 },
  lp: { diameter: 5.33, depth: 3.04 },
  lpm: { diameter: 5.33, depth: 3.04 },
  lr: { diameter: 5.33, depth: 3.3 },
  lrm: { diameter: 5.33, depth: 3.3 },
};

function primerPocket(primerType) {
  if (!Object.prototype.hasOwnProperty.call(PRIMER_POCKETS, primerType)) return null;
  const pocket = PRIMER_POCKETS[primerType];
  return { diameter: pocket.diameter, depth: pocket.depth };
}

// Rim type: belted and rimfire from the family, otherwise from R1/P1.
function rimType(record) {
  if (record.family === 'belted') return { type: 'belted' };
  if (record.family === 'rimfire') return { type: 'rimfire' };
  const R1 = record.cartridge.caseHead.R1;
  const P1 = record.cartridge.powderChamber.P1;
  const ratio = R1 / P1;
  if (ratio >= 1.05) return { type: 'rimmed', ratio };
  if (ratio < 0.98) return { type: 'rebated', ratio };
  return { type: 'rimless', ratio };
}

// Seating depth factor, cylinder fraction and meplat for each bullet shape.
// Rifle and rimfire cartridges share one group, pistol cartridges the other.
function bulletRules(shape, category) {
  const pistol = category === 'pistol';
  switch (shape) {
    case 'pointy':
      return { seat: 1.0, cylinder: 0.4, nose: 'ogive' };
    case 'rounded':
      return { seat: pistol ? 0.4 : 0.8, cylinder: pistol ? 0.65 : 0.55, nose: 'ellipse', meplat: 0.15 };
    case 'flat':
      return { seat: pistol ? 0.4 : 0.8, cylinder: pistol ? 0.7 : 0.6, nose: 'cone', meplat: 0.55 };
    case 'semi_wadcutter':
      return { seat: 0.6, cylinder: 0.78, nose: 'cone', meplat: 0.6 };
    default:
      return null;
  }
}

function unitVector(from, to) {
  const dr = to.r - from.r;
  const dz = to.z - from.z;
  const length = Math.hypot(dr, dz);
  return { r: dr / length, z: dz / length };
}

function lengthOf(from, to) {
  return Math.hypot(to.r - from.r, to.z - from.z);
}

// Points of a circular fillet of radius rho at corner P between the segments A-P and P-B.
// The radius is reduced if the tangent points would not fit on the segments.
function filletPoints(A, P, B, rho) {
  const u1 = unitVector(P, A);
  const u2 = unitVector(P, B);
  const cosTheta = Math.max(-1, Math.min(1, u1.r * u2.r + u1.z * u2.z));
  const theta = Math.acos(cosTheta);
  if (theta < 1e-6 || theta > Math.PI - 1e-6) return null;
  const half = theta / 2;
  let d = rho / Math.tan(half);
  const maxD = 0.5 * Math.min(lengthOf(P, A), lengthOf(P, B));
  if (d > maxD) {
    d = maxD;
    rho = d * Math.tan(half);
  }
  const T1 = { r: P.r + u1.r * d, z: P.z + u1.z * d };
  const T2 = { r: P.r + u2.r * d, z: P.z + u2.z * d };
  const bis = unitVector({ r: 0, z: 0 }, { r: u1.r + u2.r, z: u1.z + u2.z });
  const distC = rho / Math.sin(half);
  const C = { r: P.r + bis.r * distC, z: P.z + bis.z * distC };
  const a1 = Math.atan2(T1.z - C.z, T1.r - C.r);
  let sweep = Math.atan2(T2.z - C.z, T2.r - C.r) - a1;
  while (sweep > Math.PI) sweep -= 2 * Math.PI;
  while (sweep < -Math.PI) sweep += 2 * Math.PI;
  const steps = 12;
  const points = [];
  for (let i = 0; i <= steps; i++) {
    const a = a1 + (sweep * i) / steps;
    points.push({ r: C.r + rho * Math.cos(a), z: C.z + rho * Math.sin(a) });
  }
  points[0] = T1;
  points[steps] = T2;
  return points;
}

// Polyline through points, with the interior corners rounded where radii[i] > 0.
// Returns the rounded points and the radius actually used at each corner.
function roundPolyline(points, radii) {
  const out = [points[0]];
  const used = [];
  for (let i = 1; i < points.length - 1; i++) {
    const rho = radii[i] || 0;
    const arc = rho > 0 ? filletPoints(points[i - 1], points[i], points[i + 1], rho) : null;
    if (arc) {
      for (const p of arc) out.push(p);
      used[i] = rho;
    } else {
      out.push(points[i]);
    }
  }
  out.push(points[points.length - 1]);
  return { points: out, used };
}

// Points of an arc around centre (cr, cz) of radius rho, from angle a0 to a1 (radians).
function arcPoints(cr, cz, rho, a0, a1, steps) {
  const points = [];
  for (let i = 0; i <= steps; i++) {
    const a = a0 + ((a1 - a0) * i) / steps;
    points.push({ r: cr + rho * Math.cos(a), z: cz + rho * Math.sin(a) });
  }
  return points;
}

// Keeps the points at or beyond z0, starting with the point where the line crosses z0.
function clipFromZ(points, z0) {
  const out = [];
  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i];
    const b = points[i + 1];
    if (a.z < z0 && b.z >= z0) {
      const t = (z0 - a.z) / (b.z - a.z);
      out.push({ r: a.r + (b.r - a.r) * t, z: z0 });
    }
  }
  for (const p of points) {
    if (p.z > z0) out.push(p);
  }
  return out;
}

// Case outer half-profile, from the head face on the axis to the mouth at (H2/2, L3).
function caseOuterProfile(record, rim, notes) {
  const c = record.cartridge;
  const ch = c.caseHead;
  const pc = c.powderChamber;
  const L = c.lengths;
  const beta = angleDegrees(ch.beta);
  const R1 = ch.R1;
  const P1 = pc.P1;
  const R = ch.R;
  const H2 = c.collar.H2;
  const L3 = L.L3;
  const features = {};
  const outer = [{ r: 0, z: 0 }];

  // Rim edge. Rimfire: half-round of radius rho whose apex lies at R1/2.
  let topR;
  let topZ;
  if (rim.type === 'rimfire') {
    const rho = Math.min(R / 2, (R1 - P1) / 2);
    const cr = R1 / 2 - rho;
    outer.push({ r: cr, z: 0 });
    for (const p of arcPoints(cr, rho, rho, -Math.PI / 2, Math.PI / 2, 16).slice(1, -1)) outer.push(p);
    topR = cr;
    topZ = 2 * rho;
    outer.push({ r: topR, z: topZ });
    features.halfRoundRadius = rho;
  } else {
    if (beta !== undefined && beta < 90 && ch.f !== undefined) {
      const chamfer = Math.min(ch.f * Math.tan(beta * DEG), R1 / 4);
      outer.push({ r: R1 / 2 - chamfer, z: 0 }, { r: R1 / 2, z: ch.f });
    } else {
      outer.push({ r: R1 / 2, z: 0 });
    }
    topR = R1 / 2;
    topZ = R;
    outer.push({ r: topR, z: topZ });
  }

  // Extractor groove, or a step in from the rim top.
  const grooved = ch.E !== undefined && ch.E1 !== undefined;
  let bodyZ;
  features.groove = grooved;
  features.belt = false;
  if (grooved) {
    outer.push({ r: ch.E1 / 2, z: topZ });
    let floorEnd = topZ;
    if (ch.eMin !== undefined) {
      floorEnd = topZ + ch.eMin;
      outer.push({ r: ch.E1 / 2, z: floorEnd });
    } else {
      notes.push('e min not published: groove floor not drawn');
    }
    const delta = angleDegrees(ch.delta);
    const R3 = ch.R3;
    if (rim.type === 'belted' && R3 !== undefined && delta !== undefined) {
      features.belt = true;
      const rampEnd = floorEnd + (R3 / 2 - ch.E1 / 2) / Math.tan(delta * DEG);
      features.beltRampEnd = rampEnd;
      // Ramp out at delta to the axis up to the belt, follow the belt to E, step in to P1/2.
      outer.push({ r: R3 / 2, z: rampEnd }, { r: R3 / 2, z: ch.E });
    } else {
      if (rim.type === 'belted') notes.push('R3 or delta not published: belt not drawn');
    }
    outer.push({ r: P1 / 2, z: ch.E });
    bodyZ = ch.E;
  } else {
    outer.push({ r: P1 / 2, z: topZ });
    bodyZ = topZ;
  }
  features.bodyZ = bodyZ;
  features.bodyIndex = outer.length - 1;

  // Body, shoulder and neck. A case without alpha, L1 or L2 is straight.
  const junction = c.junctionCone || {};
  const alpha = angleDegrees(junction.alpha);
  const L1 = L.L1;
  const L2 = L.L2;
  const P2 = pc.P2;
  const H1 = c.collar.H1;
  const hasShoulder = alpha !== undefined && L1 !== undefined && L2 !== undefined;
  features.bottleneck = hasShoulder && P2 !== undefined && H1 !== undefined;
  if (features.bottleneck) {
    const body = outer[outer.length - 1];
    const shoulderStart = { r: P2 / 2, z: L1 };
    const neck = { r: H1 / 2, z: L2 };
    const mouth = { r: H2 / 2, z: L3 };
    const radii = [0, junction.r1Min, junction.r2, 0];
    if (junction.r1Min === undefined) notes.push('r1 min not published: corner not rounded');
    if (junction.r2 === undefined) notes.push('r2 not published: corner not rounded');
    const rounded = roundPolyline([body, shoulderStart, neck, mouth], radii);
    for (const p of rounded.points.slice(1)) outer.push(p);
    features.alpha = alpha;
  } else {
    if (hasShoulder) notes.push('P2 or H1 not published: shoulder not drawn');
    outer.push({ r: H2 / 2, z: L3 });
  }
  return { outer, features, topR, topZ };
}

// Wall thickness at axial position z.
function wallFunction(model) {
  const { tb, tn, bottleneck, heeled, bodyZ, L1, L2, L3 } = model;
  if (bottleneck) {
    return (z) => {
      if (z <= L1) return tb;
      if (z >= L2) return tn;
      return tb + ((tn - tb) * (z - L1)) / (L2 - L1);
    };
  }
  if (heeled) return () => tb;
  // A straight, unheeled case tapers from the body wall to the neck wall at the mouth.
  return (z) => tb + ((tn - tb) * (z - bodyZ)) / (L3 - bodyZ);
}

// Bullet nose and profile for the case model.
function buildBullet(record, model) {
  const c = record.cartridge;
  const G1 = c.projectile.G1;
  const H2 = c.collar.H2;
  const L3 = c.lengths.L3;
  const L6 = c.lengths.L6;
  const shape = record.annotations.defaultBulletShape;
  const category = record.annotations.category;
  const rules = bulletRules(shape, category);
  if (!rules) return null;

  const heeled = H2 - G1 <= 0.015;
  const D = heeled ? H2 : G1;
  const seated = heeled ? (H2 - 2 * model.tb) / 2 : D / 2;

  const zb = L3 - rules.seat * G1;
  const Lb = L6 - zb;
  const zc = zb + rules.cylinder * Lb;
  const n = L6 - zc;

  let nose;
  let m;
  if (rules.nose === 'ogive') {
    m = Math.max(0.08 * D, 1.27);
    const a = D / 2 - m / 2;
    const rho = (a * a + n * n) / (2 * a);
    const rc = D / 2 - rho;
    const cosEnd = (m / 2 - rc) / rho;
    const thetaEnd = Math.acos(Math.max(-1, Math.min(1, cosEnd)));
    nose = arcPoints(rc, zc, rho, 0, thetaEnd, 40);
  } else if (rules.nose === 'ellipse') {
    m = rules.meplat * D;
    const radial = D / 2 - m / 2;
    nose = [];
    for (let i = 0; i <= 40; i++) {
      const t = (Math.PI / 2) * (i / 40);
      nose.push({ r: m / 2 + radial * Math.cos(t), z: zc + n * Math.sin(t) });
    }
  } else {
    m = rules.meplat * D;
    nose = [
      { r: D / 2, z: zc },
      { r: m / 2, z: L6 },
    ];
  }
  nose[0] = { r: D / 2, z: zc };
  nose[nose.length - 1] = { r: m / 2, z: L6 };

  const exposed = [{ r: D / 2, z: L3 }].concat(nose, [{ r: 0, z: L6 }]);
  const section = [{ r: 0, z: zb }, { r: seated, z: zb }, { r: seated, z: L3 }];
  if (heeled) section.push({ r: D / 2, z: L3 });
  section.push(...nose, { r: 0, z: L6 });

  return {
    shape,
    category,
    heeled,
    exposedDiameter: D,
    seatedRadius: seated,
    zb,
    zc,
    n,
    m,
    nose,
    exposed,
    section,
  };
}

// Full model of a cartridge: outer profile, inner wall, primer pocket, section and bullet.
function buildCaseModel(record) {
  const c = record.cartridge;
  const ch = c.caseHead;
  const pc = c.powderChamber;
  const notes = [];
  const rim = rimType(record);
  const pocket = rim.type === 'rimfire' ? null : primerPocket(record.annotations.primerType);
  const H2 = c.collar.H2;
  const H1 = c.collar.H1;
  const G1 = c.projectile.G1;
  const P1 = pc.P1;
  const L3 = c.lengths.L3;

  const profile = caseOuterProfile(record, rim, notes);
  const features = profile.features;
  features.rimType = rim.type;
  features.pocket = pocket;

  const tn = (H2 - G1) / 2;
  const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * P1) / 2);

  const model = {
    name: record.name,
    key: record.key,
    rimType: rim.type,
    features,
    outer: profile.outer,
    tb,
    tn,
    L1: c.lengths.L1,
    L2: c.lengths.L2,
    L3,
    bodyZ: features.bodyZ,
    bottleneck: Boolean(features.bottleneck),
    heeled: H2 - G1 <= 0.015,
  };

  // Solid head: the largest of the listed lengths.
  const candidates = [2.5, (0.25 * P1) / 2];
  if (pocket) candidates.push(pocket.depth + 1.5);
  if (features.groove && ch.E !== undefined) candidates.push(ch.E + tb);
  if (features.belt) candidates.push(features.beltRampEnd + tb);
  const w = Math.max(...candidates);
  model.w = w;

  const wall = wallFunction(model);
  const tail = profile.outer.slice(features.bodyIndex);
  const inner = clipFromZ(tail, w).map((p) => ({ r: p.r - wall(p.z), z: p.z }));
  model.inner = inner;
  model.pocket = pocket;

  // Section of the case (radius >= 0): head face, outer wall, mouth, inner wall, cavity floor.
  const section = [];
  if (pocket) {
    const pr = pocket.diameter / 2;
    section.push({ r: pr, z: 0 });
    for (const p of profile.outer.slice(1)) {
      if (p.z > 0 || p.r > pr) section.push(p);
    }
  } else {
    section.push(...profile.outer);
  }
  for (let i = inner.length - 1; i >= 0; i--) section.push(inner[i]);
  section.push({ r: 0, z: w });
  if (pocket) {
    section.push({ r: 0, z: pocket.depth }, { r: pocket.diameter / 2, z: pocket.depth });
  }
  model.section = section;

  const bullet = buildBullet(record, model);
  if (bullet) {
    model.bullet = bullet;
  } else {
    notes.push('defaultBulletShape not recognised: bullet not drawn');
  }
  model.notes = notes;
  return model;
}
