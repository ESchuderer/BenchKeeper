// Browser checks against index.html opened from file://, as a user would open it.
'use strict';

const test = require('node:test');
const assert = require('../helpers/assert');
const path = require('node:path');
const { chromium } = require('playwright');
const { loadRecords } = require('../helpers/load');

const url = (hash = '') => 'file://' + path.join(__dirname, '..', '..', 'index.html') + hash;
let browser;

test.before(async () => {
  browser = await chromium.launch();
});
test.after(async () => {
  await browser.close();
});

async function open(hash, options = {}) {
  const page = await browser.newPage({ viewport: { width: 1000, height: 900 }, ...options });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(url(hash));
  return { page, errors };
}

test('list shows every cartridge with name, family and L3', async () => {
  const { page, errors } = await open('#/');
  assert.equal(await page.locator('h1').first().textContent(), 'Cartridges');
  assert.equal(await page.locator('#count').textContent(), '25 cartridges');
  assert.equal(await page.locator('table.list tbody tr').count(), 25);
  assert.equal(await page.locator('table.list tbody a').first().textContent(), '223 Rem.');
  assert.deepEqual(errors, []);
  await page.close();
});

test('search finds 308 Win. by its alternative name 7,62 x 51', async () => {
  const { page } = await open('#/');
  await page.fill('#query', '7,62 x 51');
  assert.equal(await page.locator('#count').textContent(), '1 cartridge');
  assert.equal(await page.locator('table.list tbody a').textContent(), '308 Win.');
  await page.close();
});

test('family select filters the list and combines with search', async () => {
  const { page } = await open('#/');
  await page.selectOption('#family', 'rimfire');
  assert.equal(await page.locator('#count').textContent(), '3 cartridges');
  await page.fill('#query', 'magnum');
  assert.equal(await page.locator('#count').textContent(), '1 cartridge');
  await page.close();
});

test('a link opens its detail view at its own address, which survives reload', async () => {
  const { page, errors } = await open('#/');
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  await page.waitForSelector('h1:text-is("308 Win.")');
  await page.reload();
  assert.equal(await page.locator('h1').first().textContent(), '308 Win.');
  assert.ok(await page.getByRole('img', { name: '308 Win. drawing' }).isVisible());
  assert.deepEqual(errors, []);
  await page.close();
});

test('detail view: facts, tables and back link', async () => {
  const { page } = await open('#/cartridge/308_win');
  const facts = await page.locator('dl.facts').innerText();
  assert.match(facts, /Alternative names/);
  assert.match(facts, /308 Winchester/);
  assert.match(facts, /56 gr H₂O/);
  assert.equal(await page.locator('table').count(), 16);
  await page.getByRole('link', { name: 'All cartridges' }).first().click();
  await page.waitForSelector('table.list');
  await page.close();
});

test('unknown cartridge key shows a not-found message', async () => {
  const { page } = await open('#/cartridge/nope');
  assert.match(await page.locator('h1').first().textContent(), /not found/i);
  await page.close();
});

test('dark system setting gives a dark page; print forces light', async () => {
  const { page } = await open('#/cartridge/308_win', { colorScheme: 'dark' });
  const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.notEqual(bg, 'rgb(255, 255, 255)');
  assert.notEqual(bg, 'rgba(0, 0, 0, 0)');
  await page.emulateMedia({ media: 'print' });
  const printBg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.equal(printBg, 'rgb(255, 255, 255)');
  await page.close();
});

test('every printed detail view is one A4 portrait page', async () => {
  for (const { key } of loadRecords()) {
    const { page } = await open(`#/cartridge/${key}`);
    await page.emulateMedia({ media: 'print' });
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page\b/g) || []).length;
    assert.equal(pages, 1, `${key} prints on ${pages} pages`);
    await page.close();
  }
});
