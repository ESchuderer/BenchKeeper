// Strict assertions, with deepEqual comparing plain copies of the values.
// Values built inside a vm context come from another realm, so their prototypes differ from ours.
'use strict';

const strict = require('node:assert/strict');

const plain = (value) => (value === undefined ? value : JSON.parse(JSON.stringify(value)));

module.exports = Object.assign({}, strict, {
  deepEqual: (actual, expected, message) => strict.deepEqual(plain(actual), expected, message),
});
