// Loads the browser scripts into a fresh vm context, exactly as index.html does,
// so unit tests exercise the same top-level functions the browser uses.
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..', '..');
const scripts = ['js/data.js', 'js/format.js', 'js/catalogue.js', 'js/geometry.js', 'js/drawing.js'];

function loadScripts(files = scripts) {
  const context = vm.createContext({ console });
  for (const file of files) {
    const code = fs.readFileSync(path.join(root, file), 'utf8');
    vm.runInContext(code, context, { filename: file });
  }
  return context;
}

function loadRecords() {
  const context = loadScripts(['js/data.js']);
  return vm.runInContext('CARTRIDGE_DATA', context);
}

module.exports = { loadScripts, loadRecords, root };
