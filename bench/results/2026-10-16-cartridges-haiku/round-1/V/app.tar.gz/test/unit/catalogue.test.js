'use strict';

const test = require('node:test');
const assert = require('../helpers/assert');
const { loadScripts, loadRecords } = require('../helpers/load');

const ctx = loadScripts(['js/data.js', 'js/format.js', 'js/catalogue.js']);
const records = loadRecords();
const keysOf = (list) => list.map((record) => record.key).sort();

test('family options are All plus the five families', () => {
  assert.deepEqual(ctx.FAMILY_OPTIONS, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('empty query and All list every cartridge', () => {
  assert.equal(ctx.filterCartridges(records, { query: '', family: 'All' }).length, 25);
  assert.equal(ctx.filterCartridges(records, { query: '   ', family: 'All' }).length, 25);
});

test('search matches alternative names, so 7,62 x 51 finds 308 Win.', () => {
  assert.deepEqual(keysOf(ctx.filterCartridges(records, { query: '7,62 x 51', family: 'All' })), ['308_win']);
});

test('search matches the name, ignores case and surrounding spaces', () => {
  assert.deepEqual(keysOf(ctx.filterCartridges(records, { query: '  LAPUA ', family: 'All' })), ['338_lapua_mag']);
  assert.deepEqual(keysOf(ctx.filterCartridges(records, { query: '22 wmr', family: 'All' })), ['22_win_mag_r_f']);
});

test('family filter', () => {
  assert.equal(ctx.filterCartridges(records, { query: '', family: 'rimfire' }).length, 3);
  assert.equal(ctx.filterCartridges(records, { query: '', family: 'belted' }).length, 2);
  assert.equal(ctx.filterCartridges(records, { query: '', family: 'rimmed' }).length, 2);
  assert.equal(ctx.filterCartridges(records, { query: '', family: 'pistol' }).length, 6);
  assert.equal(ctx.filterCartridges(records, { query: '', family: 'rimless' }).length, 12);
});

test('search and family combine', () => {
  assert.deepEqual(
    keysOf(ctx.filterCartridges(records, { query: 'magnum', family: 'pistol' })),
    ['357_magnum', '44_rem_mag'],
  );
  assert.equal(ctx.filterCartridges(records, { query: 'magnum', family: 'rimfire' }).length, 1);
});

test('count label', () => {
  assert.equal(ctx.countLabel(25), '25 cartridges');
  assert.equal(ctx.countLabel(1), '1 cartridge');
  assert.equal(ctx.countLabel(0), '0 cartridges');
});

test('lookup by key', () => {
  assert.equal(ctx.findCartridge(records, '308_win').name, '308 Win.');
  assert.equal(ctx.findCartridge(records, 'nope'), undefined);
});

test('list row: name, family and L3 in mm', () => {
  assert.deepEqual(ctx.listRow(records.find((r) => r.key === '308_win')), {
    name: '308 Win.',
    family: 'rimless',
    l3: '51.18 mm',
  });
});
