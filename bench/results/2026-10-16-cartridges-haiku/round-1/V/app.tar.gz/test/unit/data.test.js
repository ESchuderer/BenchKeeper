'use strict';

const test = require('node:test');
const assert = require('../helpers/assert');
const fs = require('node:fs');
const path = require('node:path');
const { loadRecords, root } = require('../helpers/load');

test('js/data.js holds exactly the records of data/cartridges.jsonl, in order', () => {
  const lines = fs
    .readFileSync(path.join(root, 'data', 'cartridges.jsonl'), 'utf8')
    .split('\n')
    .filter((line) => line.trim() !== '');
  const expected = lines.map((line) => JSON.parse(line));
  const actual = JSON.parse(JSON.stringify(loadRecords()));
  assert.equal(actual.length, 25);
  assert.deepEqual(actual, expected);
});

test('record keys are unique', () => {
  const keys = loadRecords().map((record) => record.key);
  assert.equal(new Set(keys).size, keys.length);
});
