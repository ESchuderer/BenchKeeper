'use strict';

const test = require('node:test');
const assert = require('../helpers/assert');
const { loadScripts, loadRecords } = require('../helpers/load');

const ctx = loadScripts();
const records = loadRecords();
const byKey = (key) => records.find((record) => record.key === key);
const texts = (key) => ctx.buildDrawing(byKey(key)).labels.map((label) => label.text);

test('no label overlaps the outline, another label, or a dimension line, for any cartridge', () => {
  for (const record of records) {
    const conflicts = ctx.labelConflicts(ctx.buildDrawing(record));
    assert.deepEqual(conflicts, [], `${record.key}: ${conflicts.join('; ')}`);
  }
});

test('308 Win. shows every published dimension with its nominal value', () => {
  const t = texts('308_win');
  for (const expected of [
    'L3 51.18',
    'L6 71.12',
    'L1 39.62',
    'L2 43.48',
    'R 1.37',
    'R1 12.01',
    'P1 11.96',
    'P2 11.53',
    'H1 8.72',
    'H2 8.72',
    'G1 7.85',
    'E1 10.39',
    'α 40°',
  ]) {
    assert.ok(t.includes(expected), `missing label "${expected}" in ${t.join(', ')}`);
  }
});

test('9 mm Luger (no shoulder) has no L1, L2, P2, H1 or α labels', () => {
  const t = texts('9_mm_luger').join(' ');
  assert.match(t, /L3 19\.15/);
  assert.match(t, /R1 9\.96/);
  assert.doesNotMatch(t, /\bL1\b|\bL2\b|\bP2\b|\bH1\b|α/);
});

test('22 Long Rifle (rimfire, no groove) has no E1 label', () => {
  const t = texts('22_long_rifle').join(' ');
  assert.match(t, /L3 15\.57/);
  assert.doesNotMatch(t, /E1/);
});

test('the notes name missing values that stop a feature being drawn', () => {
  assert.deepEqual(ctx.buildDrawing(byKey('223_rem')).notes, []);
  const hmr = ctx.buildDrawing(byKey('17_hmr')).notes.join(' | ');
  assert.match(hmr, /r1 min/);
  assert.match(hmr, /\br2\b/);
});

test('SVG markup: accessible name, image role, viewBox in mm, no NaN or undefined', () => {
  for (const record of records) {
    const svg = ctx.renderDrawing(record);
    assert.match(svg, /^<svg[^>]*role="img"/, record.key);
    assert.ok(svg.includes(`aria-label="${record.name.replace(/&/g, '&amp;')} drawing"`), record.key);
    assert.match(svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/, record.key);
    assert.doesNotMatch(svg, /NaN|undefined|Infinity/, record.key);
  }
});

test('true scale: the outline reaches z = L6 and the case mouth sits at L3', () => {
  const d = ctx.buildDrawing(byKey('308_win'));
  const xs = d.outlines[0].map((p) => p.x);
  assert.ok(Math.abs(Math.max(...xs) - 71.12) < 1e-6, `tip at L6, got ${Math.max(...xs)}`);
  const top = Math.min(...d.outlines[0].map((p) => p.y));
  assert.ok(top < -6, 'upper half is above the centre line');
  assert.ok(Math.max(...d.outlines[1].map((p) => p.y)) > 6, 'lower half is the section');
});
