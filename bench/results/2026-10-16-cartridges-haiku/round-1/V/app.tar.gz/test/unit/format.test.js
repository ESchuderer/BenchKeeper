'use strict';

const test = require('node:test');
const assert = require('../helpers/assert');
const { loadScripts, loadRecords } = require('../helpers/load');

const ctx = loadScripts(['js/data.js', 'js/format.js', 'js/catalogue.js']);
const records = loadRecords();
const byKey = (key) => records.find((record) => record.key === key);
const rowOf = (sections, sectionId, symbol) => {
  const section = sections.find((s) => s.id === sectionId);
  assert.ok(section, `section ${sectionId} exists`);
  const row = section.rows.find((r) => r.key === symbol);
  assert.ok(row, `row ${symbol} exists in ${sectionId}`);
  return row;
};

test('numbers are shown as published, with a decimal point and no separators', () => {
  assert.equal(ctx.formatNumber(51.18), '51.18');
  assert.equal(ctx.formatNumber(4150), '4150');
  assert.equal(ctx.formatNumber(-0.2), '-0.2');
  assert.equal(ctx.formatNumber(0), '0');
});

test('angles: a number of degrees or a degrees/minutes/seconds object', () => {
  assert.equal(ctx.formatAngle(40), '40°');
  assert.equal(ctx.formatAngle(0), '0°');
  assert.equal(ctx.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(ctx.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), `1°30'00"`);
});

test('angle value to decimal degrees', () => {
  assert.equal(ctx.angleDegrees(40), 40);
  assert.equal(ctx.angleDegrees({ degrees: 1, minutes: 30, seconds: 0 }), 1.5);
  assert.equal(ctx.angleDegrees(undefined), undefined);
});

test('symbols are the field names, with the published overrides', () => {
  const expected = {
    E1: 'E1',
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
    Pmax: 'Pmax',
  };
  for (const [key, symbol] of Object.entries(expected)) {
    assert.equal(ctx.symbolFor(key), symbol, key);
  }
});

test('units: angles, pressures, energy, mass, groove area, count and mm', () => {
  assert.equal(ctx.unitFor('beta'), '°');
  assert.equal(ctx.unitFor('i'), '°');
  assert.equal(ctx.unitFor('Pmax'), 'bar');
  assert.equal(ctx.unitFor('PE'), 'bar');
  assert.equal(ctx.unitFor('EE'), 'J');
  assert.equal(ctx.unitFor('M'), 'g');
  assert.equal(ctx.unitFor('Q'), 'mm²');
  assert.equal(ctx.unitFor('N'), '—');
  assert.equal(ctx.unitFor('L3'), 'mm');
  assert.equal(ctx.unitFor('S'), 'mm');
});

test('cartridge sections are grouped, fold tolerances into the value, and never list a Tol row', () => {
  const sections = ctx.cartridgeSections(byKey('308_win'));
  assert.deepEqual(
    sections.map((s) => s.title),
    ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile'],
  );
  for (const section of sections) {
    for (const row of section.rows) {
      assert.doesNotMatch(row.symbol, /Tol$/);
    }
  }
  assert.equal(rowOf(sections, 'lengths', 'L1').value, '39.62 -0.2');
  assert.equal(rowOf(sections, 'lengths', 'L3').value, '51.18');
  assert.equal(rowOf(sections, 'lengths', 'L3').unit, 'mm');
  assert.equal(rowOf(sections, 'powderChamber', 'P2').value, '11.53 -0.2');
  assert.equal(rowOf(sections, 'pressures', 'EE').value, '3920');
  assert.equal(rowOf(sections, 'pressures', 'EE').unit, 'J');
  assert.equal(rowOf(sections, 'caseHead', 'E').value, '3.85');
  assert.equal(rowOf(sections, 'caseHead', 'eMin').symbol, 'e min');
});

test('caseHead R carries its own tolerance on rimmed and rimfire cases', () => {
  const sections = ctx.cartridgeSections(byKey('9_3_x_74_r'));
  assert.equal(rowOf(sections, 'caseHead', 'R').value, '1.4 -0.25');
});

test('angle rows: alpha, beta and delta show degrees, DMS objects are kept', () => {
  const sections = ctx.cartridgeSections(byKey('6_5_x_55_se'));
  assert.equal(rowOf(sections, 'junctionCone', 'alpha').value, `50°35'02"`);
  assert.equal(rowOf(sections, 'caseHead', 'beta').value, '45°');
  const chamber = ctx.chamberSections(byKey('223_rem'));
  assert.equal(rowOf(chamber, 'rifling', 'i').value, `3°10'36"`);
});

test('chamber sections list every chamber value in its section', () => {
  const sections = ctx.chamberSections(byKey('223_rem'));
  assert.deepEqual(
    sections.map((s) => s.title),
    ['Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling'],
  );
  assert.equal(rowOf(sections, 'rifling', 'G1').value, '5.69');
  assert.equal(rowOf(sections, 'grooves', 'N').unit, '—');
});

test('empty sections are left out', () => {
  const sections = ctx.cartridgeSections(byKey('9_mm_luger'));
  assert.equal(sections.find((s) => s.id === 'junctionCone'), undefined);
});

test('published water capacity: value, note and source', () => {
  assert.deepEqual(ctx.formatCapacity(byKey('308_win')), {
    value: '56 gr H₂O',
    note: 'Lapua brass measures 55.8 (lapua-308)',
    source: 'kwk',
    url: 'http://kwk.us/cases.html',
  });
  assert.equal(ctx.formatCapacity(byKey('243_win')).note, undefined);
  assert.equal(ctx.formatCapacity(byKey('7_x_64')), null);
  assert.equal(ctx.formatCapacity({ key: 'x', annotations: {} }), null);
});
