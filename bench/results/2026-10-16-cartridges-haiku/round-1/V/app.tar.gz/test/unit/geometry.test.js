'use strict';

const test = require('node:test');
const assert = require('../helpers/assert');
const { loadScripts, loadRecords } = require('../helpers/load');

const ctx = loadScripts(['js/data.js', 'js/format.js', 'js/geometry.js']);
const records = loadRecords();
const byKey = (key) => records.find((record) => record.key === key);
const near = (actual, expected, tol = 1e-6, message = '') =>
  assert.ok(Math.abs(actual - expected) <= tol, `${message} expected ${expected}, got ${actual}`);
const hasPoint = (points, r, z, tol = 1e-6) =>
  points.some((p) => Math.abs(p.r - r) <= tol && Math.abs(p.z - z) <= tol);

test('rim type from family, then R1/P1', () => {
  assert.equal(ctx.rimType(byKey('223_rem')).type, 'rimless');
  assert.equal(ctx.rimType(byKey('9_3_x_74_r')).type, 'rimmed');
  assert.equal(ctx.rimType(byKey('22_long_rifle')).type, 'rimfire');
  assert.equal(ctx.rimType(byKey('300_win_mag')).type, 'belted');
  assert.equal(ctx.rimType(byKey('38_special')).type, 'rimmed');
  assert.equal(ctx.rimType(byKey('40_s_w')).type, 'rimless');
  const rebated = { family: 'rimless', cartridge: { caseHead: { R1: 10 }, powderChamber: { P1: 10.5 } } };
  assert.equal(ctx.rimType(rebated).type, 'rebated');
});

test('primer pockets: diameter and depth by primer type', () => {
  assert.deepEqual(ctx.primerPocket('sr'), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(ctx.primerPocket('spm'), { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(ctx.primerPocket('lp'), { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(ctx.primerPocket('lpm'), { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(ctx.primerPocket('lr'), { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(ctx.primerPocket('lrm'), { diameter: 5.33, depth: 3.3 });
  assert.equal(ctx.primerPocket('rimfire'), null);
});

test('walls: tn = (H2 - G1)/2 and tb = min(max(1.3 tn, 0.6), 0.35 P1/2)', () => {
  const m = ctx.buildCaseModel(byKey('223_rem'));
  near(m.tn, 0.365, 1e-9, 'tn');
  near(m.tb, 0.6, 1e-9, 'tb');
});

test('solid head w: largest of 2.5, P1/4 radius, pocket depth + 1.5, E + tb', () => {
  near(ctx.buildCaseModel(byKey('223_rem')).w, 4.54, 1e-9, '223 w (sr pocket 3.04 + 1.5)');
  near(ctx.buildCaseModel(byKey('308_win')).w, 4.8, 1e-9, '308 w (lr pocket 3.3 + 1.5)');
  near(ctx.buildCaseModel(byKey('300_win_mag')).w, 6.19, 0.01, '300 WM w (E + tb)');
});

test('outer profile starts on the axis at the head face and ends at the mouth', () => {
  const m = ctx.buildCaseModel(byKey('308_win'));
  assert.deepEqual(m.outer[0], { r: 0, z: 0 });
  const last = m.outer[m.outer.length - 1];
  near(last.r, 8.72 / 2, 1e-9, 'mouth radius H2/2');
  near(last.z, 51.18, 1e-9, 'mouth z = L3');
});

test('head chamfer where beta and f are published and beta < 90', () => {
  const m = ctx.buildCaseModel(byKey('308_win'));
  const rimRadius = 12.01 / 2;
  near(0.38 * Math.tan((35 * Math.PI) / 180), 0.2661, 1e-3, 'chamfer width');
  assert.ok(hasPoint(m.outer, rimRadius - 0.38 * Math.tan((35 * Math.PI) / 180), 0));
  assert.ok(hasPoint(m.outer, rimRadius, 0.38));
  assert.ok(hasPoint(m.outer, rimRadius, 1.37), 'rim edge up to R');
});

test('extractor groove: E1 floor to R + e min, ramp to P1/2 at E', () => {
  const m = ctx.buildCaseModel(byKey('308_win'));
  assert.equal(m.features.groove, true);
  assert.ok(hasPoint(m.outer, 10.39 / 2, 1.37), 'in to E1/2 at R');
  assert.ok(hasPoint(m.outer, 10.39 / 2, 1.37 + 1.4), 'floor to R + eMin');
  assert.ok(hasPoint(m.outer, 11.96 / 2, 3.85), 'ramp reaches P1/2 at E');
});

test('no groove without E and E1: step in from the rim top to P1/2 at R', () => {
  const m = ctx.buildCaseModel(byKey('9_3_x_74_r'));
  assert.equal(m.features.groove, false);
  assert.ok(hasPoint(m.outer, 13.35 / 2, 1.4), 'rim top');
  assert.ok(hasPoint(m.outer, 11.9 / 2, 1.4), 'step in to P1/2 at R');
});

test('rimfire: half-round rim edge with apex at R1/2, top at 2 rho', () => {
  const m = ctx.buildCaseModel(byKey('22_long_rifle'));
  assert.equal(m.features.rimType, 'rimfire');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  near(rho, 0.545, 1e-9);
  assert.ok(hasPoint(m.outer, 7.06 / 2, rho, 1e-9), 'apex');
  assert.ok(hasPoint(m.outer, 7.06 / 2 - rho, 2 * rho, 1e-9), 'top of half-round');
  assert.ok(hasPoint(m.outer, 5.74 / 2, 2 * rho, 1e-9), 'step in to P1/2');
});

test('belted: ramp at delta to the axis up to R3/2, belt to E, step in to P1/2', () => {
  const m = ctx.buildCaseModel(byKey('300_win_mag'));
  assert.equal(m.features.belt, true);
  const floorEnd = 1.27 + 0.94;
  const rampEnd = floorEnd + (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  near(rampEnd, 3.238, 0.01, 'belt ramp end');
  assert.ok(hasPoint(m.outer, 13.51 / 2, rampEnd, 1e-6), 'reaches belt');
  assert.ok(hasPoint(m.outer, 13.51 / 2, 5.59), 'belt to E');
  assert.ok(hasPoint(m.outer, 13.03 / 2, 5.59), 'step in to P1/2 at E');
});

test('bottleneck shoulder: the corners are rounded, not sharp', () => {
  const m = ctx.buildCaseModel(byKey('308_win'));
  assert.equal(m.features.bottleneck, true);
  const sharp = [
    { r: 11.96 / 2, z: 39.62 },
    { r: 8.72 / 2, z: 43.48 },
  ];
  for (const corner of sharp) {
    const nearby = m.outer.filter((p) => Math.hypot(p.r - corner.r, p.z - corner.z) < 1);
    assert.ok(nearby.length >= 4, `corner ${JSON.stringify(corner)} has a fillet (${nearby.length} points near it)`);
  }
});

test('the shoulder line lies at alpha/2 to the axis', () => {
  const r = byKey('308_win');
  const alphaDeg = r.cartridge.junctionCone.alpha;
  const slope = (r.cartridge.powderChamber.P2 - r.cartridge.collar.H1) / 2 / (r.cartridge.lengths.L2 - r.cartridge.lengths.L1);
  near(Math.atan(slope) * 180 / Math.PI, alphaDeg / 2, 0.05, 'alpha/2');
});

test('straight case: body runs to (H2/2, L3) with no shoulder', () => {
  const m = ctx.buildCaseModel(byKey('9_mm_luger'));
  assert.equal(m.features.bottleneck, false);
  assert.ok(hasPoint(m.outer, 9.65 / 2, 19.15), 'mouth at H2/2');
});

test('22 Long Rifle is straight and heeled: exposed bullet at case OD, seated heel at H2 - 2 tb', () => {
  const m = ctx.buildCaseModel(byKey('22_long_rifle'));
  assert.equal(m.bullet.heeled, true);
  near(m.bullet.exposedDiameter, 5.72, 1e-9);
  near(m.bullet.seatedRadius, (5.72 - 2 * m.tb) / 2, 1e-9, 'heel radius');
});

test('pointy bullet 223 Rem: base, cylinder end, ogive length and meplat', () => {
  const b = ctx.buildCaseModel(byKey('223_rem')).bullet;
  near(b.zb, 44.7 - 5.7, 1e-9, 'base at L3 - 1.0 G1');
  near(b.zc, 39.0 + 0.4 * (57.4 - 39.0), 1e-9, 'cylinder end');
  near(b.m, 1.27, 1e-9, 'meplat (max(0.08 G1, 1.27))');
  const tip = b.nose[b.nose.length - 1];
  near(tip.r, 0.635, 1e-9);
  near(tip.z, 57.4, 1e-9);
});

test('pointy ogive is a circular arc tangent to the cylinder and through the meplat', () => {
  const b = ctx.buildCaseModel(byKey('223_rem')).bullet;
  const a = 5.7 / 2 - 1.27 / 2;
  const n = 57.4 - b.zc;
  const rho = (a * a + n * n) / (2 * a);
  const rc = 5.7 / 2 - rho;
  for (const p of b.nose) {
    near(Math.hypot(p.r - rc, p.z - b.zc), rho, 1e-6, 'on the arc');
  }
  near(b.nose[0].r, 5.7 / 2, 1e-9, 'starts on the cylinder');
  near(b.nose[0].z, b.zc, 1e-9, 'starts at the cylinder end');
});

test('rounded rimfire bullet: 0.8 G1 seating, cylinder 0.55, meplat 0.15 G1', () => {
  const b = ctx.buildCaseModel(byKey('22_long_rifle')).bullet;
  near(b.zb, 15.57 - 0.8 * 5.72, 1e-9);
  near(b.zc, b.zb + 0.55 * (25.4 - b.zb), 1e-9);
  near(b.m, 0.15 * 5.72, 1e-9);
});

test('rounded pistol bullet: 0.4 G1 seating, cylinder 0.65', () => {
  const b = ctx.buildCaseModel(byKey('9_mm_luger')).bullet;
  near(b.zb, 19.15 - 0.4 * 9.03, 1e-9);
  near(b.zc, b.zb + 0.65 * (29.69 - b.zb), 1e-9);
});

test('semi-wadcutter bullet: 0.6 G1 seating, cylinder 0.78, straight cone to 0.6 G1 meplat', () => {
  const b = ctx.buildCaseModel(byKey('357_magnum')).bullet;
  near(b.zb, 32.77 - 0.6 * 9.12, 1e-9);
  near(b.zc, b.zb + 0.78 * (40.39 - b.zb), 1e-9);
  near(b.m, 0.6 * 9.12, 1e-9);
});

test('missing values are left out and named in notes', () => {
  assert.deepEqual(ctx.buildCaseModel(byKey('223_rem')).notes, []);
  assert.ok(ctx.buildCaseModel(byKey('338_lapua_mag')).notes.some((n) => /r1 min/.test(n)));
  const hmr = ctx.buildCaseModel(byKey('17_hmr')).notes.join(' | ');
  assert.match(hmr, /r1 min/);
  assert.match(hmr, /\br2\b/);
});

test('section: pocket and inner wall for a centrefire case', () => {
  const m = ctx.buildCaseModel(byKey('308_win'));
  assert.deepEqual(m.section[0], { r: 5.33 / 2, z: 0 }, 'pocket edge at the head face');
  assert.ok(m.section.some((p) => Math.abs(p.r) < 1e-9 && Math.abs(p.z - 3.3) < 1e-9), 'pocket floor on axis');
  const mouthInner = m.inner[m.inner.length - 1];
  near(mouthInner.r, 8.72 / 2 - m.tn, 1e-6, 'inner mouth radius = H2/2 - tn');
  near(mouthInner.z, 51.18, 1e-9);
});

test('no pocket on rimfire: the head face runs from the axis', () => {
  const m = ctx.buildCaseModel(byKey('22_long_rifle'));
  assert.deepEqual(m.section[0], { r: 0, z: 0 });
});

test('every record builds a model without NaN', () => {
  for (const record of records) {
    const m = ctx.buildCaseModel(record);
    const all = [...m.outer, ...m.inner, ...m.section, ...m.bullet.nose, ...m.bullet.section];
    for (const p of all) {
      assert.ok(Number.isFinite(p.r) && Number.isFinite(p.z), `${record.key}: ${JSON.stringify(p)}`);
    }
  }
});
