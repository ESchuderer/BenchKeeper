# Cartridges · C.I.P. reference

A static reference of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers. Each cartridge has a
detail view with its identification, C.I.P. values, chamber values, and a 2D drawing computed from the
published dimensions. The data is from [OpenBallistics](https://github.com/PiMetry/OpenBallistics)
(MIT, commit e83db43) and is used unchanged.

## Open it

- **From disk:** double-click `index.html` (Chromium, `file://`). No server needed.
- **Served:** any static file server pointing at this folder, for example `npx serve .` or
  `python3 -m http.server`.

There is no build step and no runtime dependency. The app makes no network requests.

## Use it

- The start page lists every cartridge. **Search** matches names and alternative names, ignoring case and
  spaces (`7,62 x 51` finds `308 Win.`). **Family** filters the list.
- Each cartridge has its own address, `index.html#/cartridge/<key>`, which survives a reload and can be bookmarked.
- **Print** opens the browser's print dialog. A printed detail view is one A4 portrait page in black on white.

## Tests

```sh
npm test
```

The tests use Node's built-in runner (Node 22 or later) and have no dependencies. They cover the data
set, value formatting, search and routing, the geometry rules for representative and all 25 records,
and label placement for all 25 drawings (no label overlaps the outline, the dimension lines or another label).

## Drawing assumptions

The drawing follows the rules in the project brief. Where the brief leaves a case open, these choices apply:

- **Straight cases** (no shoulder): the case wall blends linearly from the body thickness to the neck
  thickness, so the bullet fits the mouth. **Heeled** cases (22 Long Rifle) keep the body thickness to the
  mouth, so the case's inside diameter matches the seated heel.
- **Rimfire rims** use a half-round of radius min(R/2, (R1 − P1)/2) with straight flanks if the radius is smaller than R/2.
- **Missing values**: a feature that needs a value which is not published is drawn without that feature. The
  drawing caption names the missing value. No number is invented.
- **Labels**: diameters are labelled in a row above the drawing, with leader lines. Lengths are labelled under
  their dimension lines.
- **Title block**: short cases (pistol and rimfire) carry the title block beside the drawing rather than below it.
