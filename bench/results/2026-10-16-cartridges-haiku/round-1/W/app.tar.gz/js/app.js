// Page logic: the start page (list), the detail view and the hash routes.
(function () {
  'use strict';

  var F = window.CartridgeFormat;
  var B = window.CartridgeBrowse;
  var D = window.CartridgeDrawing;
  var DATA = window.CARTRIDGE_DATA;
  var SORTED = B.sortCartridges(DATA);
  var app = document.getElementById('app');

  // Filter state survives a visit to a detail view, so "All cartridges" returns to the same list.
  var listState = { query: '', family: 'All' };

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (name) {
      if (name === 'text') {
        node.textContent = attrs[name];
      } else if (attrs[name] !== null && attrs[name] !== undefined) {
        node.setAttribute(name, attrs[name]);
      }
    });
    (children || []).forEach(function (child) {
      if (child !== null && child !== undefined) {
        node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
      }
    });
    return node;
  }

  function setTitle(text) {
    document.title = text;
  }

  function lengthText(record) {
    var lengths = F.buildSections(record).cartridge.filter(function (s) { return s.key === 'lengths'; })[0];
    var row = lengths && lengths.rows.filter(function (r) { return r.field === 'L3'; })[0];
    return row ? row.value + ' ' + row.unit : '';
  }

  // ---- Start page ---------------------------------------------------------

  function listItems(records) {
    return records.map(function (record) {
      return el('li', { class: 'cartridge-item' }, [
        el('a', { href: B.routeHash(record.key), class: 'cartridge-name', text: record.name }),
        el('span', { class: 'cartridge-family', text: record.family }),
        el('span', { class: 'cartridge-l3', text: 'L3 ' + lengthText(record) })
      ]);
    });
  }

  function renderList() {
    setTitle('Cartridges · C.I.P. reference');
    var search = el('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false', value: listState.query });
    var familySelect = el('select', { id: 'family' }, B.FAMILY_OPTIONS.map(function (name) {
      return el('option', { value: name, text: name, selected: name === listState.family ? 'selected' : null });
    }));
    var count = el('p', { class: 'count', 'aria-live': 'polite' });
    var list = el('ul', { class: 'cartridge-list' });

    function update() {
      listState.query = search.value;
      listState.family = familySelect.value;
      var shown = B.filterCartridges(SORTED, listState);
      count.textContent = B.countText(shown.length);
      list.innerHTML = '';
      listItems(shown).forEach(function (item) { list.appendChild(item); });
    }

    search.addEventListener('input', update);
    familySelect.addEventListener('change', update);

    var form = el('form', { class: 'filters', role: 'search' }, [
      el('div', { class: 'field' }, [el('label', { for: 'search', text: 'Search' }), search]),
      el('div', { class: 'field' }, [el('label', { for: 'family', text: 'Family' }), familySelect])
    ]);
    form.addEventListener('submit', function (event) { event.preventDefault(); });

    app.innerHTML = '';
    app.appendChild(el('section', { class: 'list-view' }, [
      el('h1', { text: 'Cartridges' }),
      form,
      count,
      list
    ]));
    update();
  }

  // ---- Detail view --------------------------------------------------------

  function factRow(term, valueNodes) {
    return [el('dt', { text: term }), el('dd', null, valueNodes)];
  }

  function waterCapacityNodes(record) {
    var cap = F.waterCapacity(record);
    if (!cap) {
      return ['not published'];
    }
    var nodes = [cap.text + ' · source '];
    nodes.push(el('a', { href: cap.url, text: cap.source }));
    if (cap.note) {
      nodes.push(' · ' + cap.note);
    }
    return nodes;
  }

  function valueTable(section) {
    var body = el('tbody', null, section.rows.map(function (row) {
      return el('tr', null, [
        el('th', { scope: 'row', text: row.symbol }),
        el('td', { class: 'num', text: row.value }),
        el('td', { class: 'unit', text: row.unit })
      ]);
    }));
    return el('section', { class: 'value-section' }, [
      el('h3', { text: section.title }),
      el('table', { class: 'values' }, [
        el('thead', null, [el('tr', null, [
          el('th', { scope: 'col', text: 'Symbol' }),
          el('th', { scope: 'col', text: 'Value' }),
          el('th', { scope: 'col', text: 'Unit' })
        ])]),
        body
      ])
    ]);
  }

  function valueGroup(title, sections) {
    return el('section', { class: 'value-group' }, [el('h2', { text: title })].concat(sections.map(valueTable)));
  }

  function drawingFigure(record) {
    var figure = el('figure', { class: 'drawing-figure' });
    figure.innerHTML = D.renderDrawing(record);
    var layout = D.layoutDrawing(record);
    if (layout.ok && layout.notes.length) {
      figure.appendChild(el('figcaption', { class: 'drawing-notes' }, [
        el('strong', { text: 'Not drawn or not labelled: ' }),
        layout.notes.join('; ')
      ]));
    }
    return figure;
  }

  function printButton() {
    var button = el('button', { type: 'button', class: 'print-button', text: 'Print' });
    button.addEventListener('click', function () { window.print(); });
    return button;
  }

  function renderDetail(record) {
    setTitle(record.name + ' · Cartridges');
    var sections = F.buildSections(record);
    var facts = el('dl', { class: 'facts' }, [].concat(
      factRow('Family', [record.family]),
      factRow('Category', [record.annotations.category]),
      factRow('Primer type', [record.annotations.primerType]),
      factRow('C.I.P. table', [record.tab]),
      factRow('Country', [record.country]),
      factRow('Published', [record.published]),
      factRow('Revised', [record.revised]),
      factRow('Pressure method', [record.pressureMethod]),
      factRow('Water capacity', waterCapacityNodes(record))
    ));
    var alt = (record.alternativeNames || []).length
      ? el('p', { class: 'alt-names' }, ['Also known as ', record.alternativeNames.join(', ')])
      : null;

    app.innerHTML = '';
    app.appendChild(el('article', { class: 'detail' }, [
      el('nav', { class: 'toolbar no-print' }, [
        el('a', { href: '#/', class: 'back', text: 'All cartridges' }),
        printButton()
      ]),
      el('header', { class: 'detail-head' }, [el('h1', { text: record.name }), alt, facts]),
      drawingFigure(record),
      el('div', { class: 'value-tables' }, [
        valueGroup('Cartridge', sections.cartridge),
        valueGroup('Chamber', sections.chamber)
      ]),
      el('footer', { class: 'source-line', text: F.sourceLine(record) })
    ]));
    window.scrollTo(0, 0);
  }

  function renderNotFound() {
    setTitle('Cartridge not found · Cartridges');
    app.innerHTML = '';
    app.appendChild(el('section', { class: 'not-found' }, [
      el('h1', { text: 'Cartridge not found' }),
      el('p', null, [el('a', { href: '#/', text: 'All cartridges' })])
    ]));
  }

  // ---- Routing ------------------------------------------------------------

  function byKey(key) {
    return DATA.filter(function (record) { return record.key === key; })[0] || null;
  }

  function route() {
    var target = B.parseRoute(window.location.hash);
    if (target.view === 'list') {
      renderList();
      return;
    }
    var record = byKey(target.key);
    if (record) {
      renderDetail(record);
    } else {
      renderNotFound();
    }
  }

  window.addEventListener('hashchange', route);
  route();
})();
