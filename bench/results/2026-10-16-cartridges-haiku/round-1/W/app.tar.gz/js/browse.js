// Start-page logic: sorting, search, family filter, count text and the hash routes.
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CartridgeBrowse = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var FAMILY_OPTIONS = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var collator = new Intl.Collator('en', { numeric: true, sensitivity: 'base' });

  function sortCartridges(list) {
    return list.slice().sort(function (a, b) {
      return collator.compare(a.name, b.name);
    });
  }

  // Lower case, single spaces; `squash` also drops every space, so "7,62x51" finds "7,62 x 51".
  function normalise(text) {
    return String(text).toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function squash(text) {
    return normalise(text).replace(/ /g, '');
  }

  function matchesQuery(record, query) {
    var needle = normalise(query);
    if (needle === '') {
      return true;
    }
    var needleSquashed = squash(query);
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (name) {
      return normalise(name).indexOf(needle) !== -1 || squash(name).indexOf(needleSquashed) !== -1;
    });
  }

  function filterCartridges(list, filter) {
    var family = filter.family || 'All';
    return list.filter(function (record) {
      return (family === 'All' || record.family === family) && matchesQuery(record, filter.query || '');
    });
  }

  function countText(n) {
    return n + (n === 1 ? ' cartridge' : ' cartridges');
  }

  function parseRoute(hash) {
    var match = /^#?\/cartridge\/(.+)$/.exec(hash || '');
    if (match) {
      return { view: 'detail', key: decodeURIComponent(match[1]) };
    }
    return { view: 'list' };
  }

  function routeHash(key) {
    return '#/cartridge/' + encodeURIComponent(key);
  }

  return {
    FAMILY_OPTIONS: FAMILY_OPTIONS,
    sortCartridges: sortCartridges,
    matchesQuery: matchesQuery,
    filterCartridges: filterCartridges,
    countText: countText,
    parseRoute: parseRoute,
    routeHash: routeHash
  };
});
