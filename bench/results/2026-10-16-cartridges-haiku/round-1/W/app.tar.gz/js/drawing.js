// SVG drawing of a cartridge: outside view above the axis, axial section below it,
// dimension lines with labels placed so that they do not collide, and a title block.
// Coordinates are millimetres: x = z (head on the left), y = -r above the axis, +r below.
(function (root, factory) {
  var api;
  if (typeof module === 'object' && module.exports) {
    api = factory(require('./geometry.js'), require('./format.js'));
  } else {
    api = factory(root.CartridgeGeometry, root.CartridgeFormat);
  }
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CartridgeDrawing = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (G, F) {
  'use strict';

  var FS = 2.6;        // label font size, mm
  var CHAR_W = 0.6;    // estimated glyph width in em (deliberately generous)
  var GAP = 0.6;       // gap between the outline and an extension line
  var OVER = 0.8;      // extension line overshoot beyond its dimension line
  var PAD = 0.25;      // clearance kept around labels when checking collisions
  var LEADER_GAP = 0.3;
  var ROW_STEP = 3.2;  // spacing of label rows above the drawing
  var ARROW_L = 1.1;
  var ARROW_W = 0.35;
  var PI = Math.PI;

  // The cartridge section that holds each dimensioned field.
  var SECTION_OF = {
    R: 'caseHead', R1: 'caseHead', E1: 'caseHead',
    L1: 'lengths', L2: 'lengths', L3: 'lengths', L6: 'lengths',
    P1: 'powderChamber', P2: 'powderChamber',
    H1: 'collar', H2: 'collar',
    G1: 'projectile',
    alpha: 'junctionCone'
  };

  function esc(text) {
    return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function num(v) {
    return Math.round(v * 1000) / 1000;
  }

  // Label text for a published value: symbol and value with its tolerance, e.g. "L1 39.62 -0.2".
  function labelFor(record, field) {
    var groups = F.buildSections(record).cartridge;
    for (var i = 0; i < groups.length; i++) {
      if (groups[i].key !== SECTION_OF[field]) {
        continue;
      }
      for (var j = 0; j < groups[i].rows.length; j++) {
        if (groups[i].rows[j].field === field) {
          return F.symbolFor(field) + ' ' + groups[i].rows[j].value;
        }
      }
    }
    return null;
  }

  // Radius of the outline at axial position z (interpolated along the polyline).
  function radiusAt(points, z) {
    var best = null;
    for (var i = 0; i < points.length - 1; i++) {
      var a = points[i];
      var b = points[i + 1];
      if (z >= Math.min(a.z, b.z) - 1e-9 && z <= Math.max(a.z, b.z) + 1e-9) {
        var t = a.z === b.z ? 0 : (z - a.z) / (b.z - a.z);
        var r = a.r + t * (b.r - a.r);
        best = best === null ? r : Math.max(best, r);
      }
    }
    return best === null ? 0 : best;
  }

  // Liang-Barsky: does segment a-b touch the rectangle r?
  function segmentTouchesRect(a, b, r) {
    var dx = b.x - a.x;
    var dy = b.y - a.y;
    var p = [-dx, dx, -dy, dy];
    var q = [a.x - r.x0, r.x1 - a.x, a.y - r.y0, r.y1 - a.y];
    var t0 = 0;
    var t1 = 1;
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) {
        if (q[i] < 0) {
          return false;
        }
      } else {
        var t = q[i] / p[i];
        if (p[i] < 0) {
          if (t > t1) {
            return false;
          }
          if (t > t0) {
            t0 = t;
          }
        } else {
          if (t < t0) {
            return false;
          }
          if (t < t1) {
            t1 = t;
          }
        }
      }
    }
    return true;
  }

  // Proper crossing of two segments (touching at an end point does not count).
  function segmentsCross(p1, p2, p3, p4) {
    function orient(a, b, c) {
      return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    }
    var d1 = orient(p3, p4, p1);
    var d2 = orient(p3, p4, p2);
    var d3 = orient(p1, p2, p3);
    var d4 = orient(p1, p2, p4);
    return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
  }

  function rectsOverlap(a, b) {
    return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
  }

  function inflate(r, d) {
    return { x0: r.x0 - d, y0: r.y0 - d, x1: r.x1 + d, y1: r.y1 + d };
  }

  // Estimated bounding box of a label: anchor x, baseline y and text-anchor.
  function labelBox(text, x, y, anchor) {
    var w = text.length * FS * CHAR_W;
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0: x0, x1: x0 + w, y0: y - FS * 0.75, y1: y + FS * 0.25 };
  }

  // Checks a candidate label (and its leader, if any) against drawing lines and placed labels.
  function collisionsFor(candidate, obstacles, placed) {
    var hits = [];
    var grown = inflate(candidate.box, PAD);
    obstacles.forEach(function (s) {
      if (segmentTouchesRect(s.a, s.b, grown)) {
        hits.push('line ' + (s.owner || 'outline'));
      }
    });
    placed.forEach(function (other) {
      if (rectsOverlap(grown, inflate(other.box, PAD))) {
        hits.push('label ' + other.text);
      }
    });
    if (candidate.leader) {
      var lead = candidate.leader;
      obstacles.forEach(function (s) {
        if (s.owner !== candidate.owner && segmentsCross(lead.a, lead.b, s.a, s.b)) {
          hits.push('leader of ' + candidate.text + ' crosses ' + (s.owner || 'outline'));
        }
      });
      placed.forEach(function (other) {
        if (segmentTouchesRect(lead.a, lead.b, inflate(other.box, PAD))) {
          hits.push('leader crosses label ' + other.text);
        }
      });
    }
    return hits;
  }

  // Arrowheads at both ends of a dimension line from a to b (filled triangles).
  function arrowPath(a, b) {
    var dx = b.x - a.x;
    var dy = b.y - a.y;
    var len = Math.hypot(dx, dy);
    var ux = dx / len;
    var uy = dy / len;
    var px = -uy;
    var py = ux;
    function head(tip, dir) {
      var bx = tip.x - dir.x * ARROW_L;
      var by = tip.y - dir.y * ARROW_L;
      return 'M' + num(tip.x) + ' ' + num(tip.y) + 'L' + num(bx + px * ARROW_W) + ' ' + num(by + py * ARROW_W) +
        'L' + num(bx - px * ARROW_W) + ' ' + num(by - py * ARROW_W) + 'Z';
    }
    return head(a, { x: ux, y: uy }) + head(b, { x: -ux, y: -uy });
  }

  function pathOf(points) {
    return points.map(function (p, i) {
      return (i === 0 ? 'M' : 'L') + num(p.x) + ' ' + num(p.y);
    }).join('');
  }

  // Length dimension: horizontal line at height y between z1 and z2, extension lines down to the features.
  // The label sits beside its line, on the side away from the outline when possible.
  function lengthDim(o) {
    var id = o.id;
    var ext = [
      { a: { x: o.z1, y: o.side * (o.rA + GAP) }, b: { x: o.z1, y: o.y + o.side * OVER }, owner: id },
      { a: { x: o.z2, y: o.side * (o.rB + GAP) }, b: { x: o.z2, y: o.y + o.side * OVER }, owner: id }
    ];
    var mid = (o.z1 + o.z2) / 2;
    // "beyond" is the side of the line away from the outline, "inside" the side towards it.
    var beyond = o.side > 0 ? o.y + 1.2 + FS * 0.75 : o.y - 1.2;
    var inside = o.side > 0 ? o.y - 1.2 : o.y + 1.2 + FS * 0.75;
    var candidates = [];
    if (o.labelLeft) {
      candidates.push({ x: o.z1 - 1.9, y: o.y + FS * 0.35, anchor: 'end' });
    }
    [0, -4, 4, -8, 8].forEach(function (dx) {
      candidates.push({ x: mid + dx, y: beyond, anchor: 'middle' });
    });
    [0, -6, 6].forEach(function (dx) {
      candidates.push({ x: mid + dx, y: inside, anchor: 'middle' });
    });
    return {
      id: id,
      field: o.field,
      segments: [{ a: { x: o.z1, y: o.y }, b: { x: o.z2, y: o.y }, owner: id }].concat(ext),
      arrows: [{ a: { x: o.z1, y: o.y }, b: { x: o.z2, y: o.y } }],
      ext: ext,
      candidates: candidates
    };
  }

  // Diameter: vertical line at z = zd spanning the diameter, extension lines from the feature at zf.
  // The label goes in a row above the drawing, joined to the dimension by a leader.
  function diameterDim(o, rows) {
    var id = o.id;
    var r = o.r + GAP;
    var dirZ = o.zd >= o.zf ? 1 : -1;
    var ext = [
      { a: { x: o.zf, y: -r }, b: { x: o.zd + dirZ * OVER, y: -r }, owner: id },
      { a: { x: o.zf, y: r }, b: { x: o.zd + dirZ * OVER, y: r }, owner: id }
    ];
    var dimLine = { a: { x: o.zd, y: -r }, b: { x: o.zd, y: r }, owner: id };
    var candidates = [];
    if (o.labelLeft) {
      candidates.push({ x: o.zd - 0.8, y: FS * 0.35, anchor: 'end' });
    }
    rows.forEach(function (baseline) {
      ['middle', 'start', 'end'].forEach(function (mode) {
        candidates.push({
          x: mode === 'middle' ? o.zd : mode === 'start' ? o.zd - 0.5 : o.zd + 0.5,
          y: baseline,
          anchor: mode,
          leader: { a: { x: o.zd, y: -r }, b: { x: o.zd, y: baseline + FS * 0.25 + LEADER_GAP }, owner: id }
        });
      });
    });
    return {
      id: id,
      field: o.field,
      segments: [dimLine].concat(ext),
      arrows: [{ a: dimLine.a, b: dimLine.b }],
      ext: ext,
      candidates: candidates,
      leaderStart: o.labelLeft ? null : dimLine.a
    };
  }

  // Shoulder angle: an arc at the cone apex on the axis, between the axis and the shoulder line.
  // The label sits above the shoulder with a leader down to it.
  function angleDim(o, rows) {
    var id = o.id;
    var h = o.halfRad;
    var rho = o.rho;
    var start = { x: o.apexZ - rho, y: 0 };
    var end = { x: o.apexZ + rho * Math.cos(PI + h), y: rho * Math.sin(PI + h) };
    var candidates = [];
    rows.forEach(function (baseline) {
      ['middle', 'start', 'end'].forEach(function (mode) {
        candidates.push({
          x: mode === 'middle' ? o.zMid : mode === 'start' ? o.zMid - 0.5 : o.zMid + 0.5,
          y: baseline,
          anchor: mode,
          leader: { a: { x: o.zMid, y: -o.rMid - GAP }, b: { x: o.zMid, y: baseline + FS * 0.25 + LEADER_GAP }, owner: id }
        });
      });
    });
    return {
      id: id,
      field: o.field,
      segments: [{ a: start, b: end, owner: id }],
      arrows: [],
      arc: { start: start, end: end, radius: rho },
      ext: [],
      candidates: candidates,
      leaderStart: { x: o.zMid, y: -(o.rMid + GAP) }
    };
  }

  function layoutDrawing(record) {
    var g = G.computeGeometry(record);
    if (!g.ok) {
      return { ok: false, key: record.key, name: record.name, notes: g.notes, labels: [], viewBox: null };
    }
    var c = record.cartridge;
    var ch = c.caseHead;
    var lens = c.lengths;
    var pc = c.powderChamber;
    var col = c.collar;
    var jc = c.junctionCone;
    var bullet = g.bullet;
    var r1h = ch.R1 / 2;
    var notes = g.notes.slice();

    // Outline: upper half (outside) and lower half (section), in SVG coordinates.
    var outside = g.outer.map(function (p) { return { x: p.z, y: -p.r }; });
    if (bullet) {
      bullet.exposed.forEach(function (p) { outside.push({ x: p.z, y: -p.r }); });
    }
    var sectionPts = g.section.map(function (p) { return { x: p.z, y: p.r }; });
    var bulletPts = bullet ? bullet.full.map(function (p) { return { x: p.z, y: p.r }; }) : [];

    var obstacles = [];
    function addPolyline(points, owner) {
      for (var i = 0; i < points.length - 1; i++) {
        obstacles.push({ a: points[i], b: points[i + 1], owner: owner || null });
      }
    }
    addPolyline(outside);
    addPolyline(sectionPts.concat([sectionPts[0]]));
    addPolyline(bulletPts);

    var Rm = r1h;
    g.outer.forEach(function (p) { Rm = Math.max(Rm, p.r); });
    if (bullet) {
      Rm = Math.max(Rm, bullet.Rc);
    }
    var mouthR = col.H2 / 2;
    var zs = g.zs;

    // Rows of diameter labels above the drawing, nearest first.
    var rows = [];
    for (var k = 0; k < 8; k++) {
      rows.push(-(Rm + 4.6 + ROW_STEP * k));
    }

    var dimSpecs = [];
    // Length dimensions: R beside its short line above the head, the others stacked below the outline.
    dimSpecs.push({ kind: 'length', id: 'R', field: 'R', z1: 0, z2: ch.R, side: -1, y: -(Rm + 2.6), rA: r1h, rB: r1h, labelLeft: true });
    dimSpecs.push({ kind: 'length', id: 'L1', field: 'L1', z1: 0, z2: lens.L1, side: 1, y: Rm + 1.8, rA: r1h, rB: pc.P2 / 2, present: g.bottleneck });
    dimSpecs.push({ kind: 'length', id: 'L2', field: 'L2', z1: 0, z2: lens.L2, side: 1, y: Rm + 6.2, rA: r1h, rB: col.H1 / 2, present: g.bottleneck });
    dimSpecs.push({ kind: 'length', id: 'L3', field: 'L3', z1: 0, z2: lens.L3, side: 1, y: Rm + 10.6, rA: r1h, rB: mouthR });
    dimSpecs.push({ kind: 'length', id: 'L6', field: 'L6', z1: 0, z2: lens.L6, side: 1, y: Rm + 15.0, rA: r1h, rB: 0 });
    // Diameters, with leaders to label rows above the drawing.
    dimSpecs.push({ kind: 'diameter', id: 'R1', field: 'R1', zf: 0, zd: -2.8, r: r1h, labelLeft: true });
    dimSpecs.push({ kind: 'diameter', id: 'P1', field: 'P1', zf: zs, zd: zs + 1.4, r: pc.P1 / 2 });
    dimSpecs.push({ kind: 'diameter', id: 'P2', field: 'P2', zf: lens.L1, zd: lens.L1 - 1.4, r: pc.P2 / 2, present: g.bottleneck });
    dimSpecs.push({ kind: 'diameter', id: 'H1', field: 'H1', zf: lens.L2, zd: lens.L2 + 1.4, r: col.H1 / 2, present: g.bottleneck });
    dimSpecs.push({ kind: 'diameter', id: 'H2', field: 'H2', zf: lens.L3, zd: lens.L3 + 1.4, r: mouthR });
    if (bullet) {
      dimSpecs.push({ kind: 'diameter', id: 'G1', field: 'G1', zf: bullet.zc, zd: bullet.zc + 1.4, r: c.projectile.G1 / 2 });
    }
    if (g.groove) {
      var floorEnd = ch.R + ch.eMin;
      dimSpecs.push({ kind: 'diameter', id: 'E1', field: 'E1', zf: floorEnd, zd: ch.R + ch.eMin / 2, r: ch.E1 / 2 });
    }
    if (g.bottleneck && g.shoulderHalfAngleDeg !== null) {
      var halfRad = (g.shoulderHalfAngleDeg * PI) / 180;
      var apexZ = lens.L1 + (pc.P2 / 2) / Math.tan(halfRad);
      var zMid = (lens.L1 + lens.L2) / 2;
      dimSpecs.push({ kind: 'angle', id: 'alpha', field: 'alpha', apexZ: apexZ, halfRad: halfRad, rho: 6, zMid: zMid, rMid: radiusAt(outside.map(function (p) { return { z: p.x, r: -p.y }; }), zMid) });
    }

    // Build the dimension geometry; the lines of every dimension become obstacles for the labels.
    var dims = [];
    dimSpecs.forEach(function (s) {
      if (s.present === false) {
        return;
      }
      var d;
      if (s.kind === 'length') {
        d = lengthDim(s);
      } else if (s.kind === 'diameter') {
        d = diameterDim(s, rows);
      } else {
        d = angleDim(s, rows);
      }
      d.kind = s.kind;
      dims.push(d);
      d.segments.forEach(function (seg) { obstacles.push(seg); });
    });

    var labels = [];
    var placed = [];
    function commit(d, text, chosen) {
      var entry = {
        id: d.id,
        text: text,
        x: chosen.x,
        y: chosen.y,
        anchor: chosen.anchor,
        box: chosen.box,
        leader: chosen.leader || null
      };
      placed.push(entry);
      labels.push(entry);
      if (entry.leader) {
        obstacles.push({ a: entry.leader.a, b: entry.leader.b, owner: d.id });
      }
    }
    function fail(d, text) {
      notes.push('Label ' + text + ' could not be placed clear of the drawing');
    }

    // Lengths and R1: the first candidate that clears the drawing, the other labels and the leaders.
    var slotDims = [];
    dims.forEach(function (d) {
      var text = labelFor(record, d.field);
      if (!text) {
        notes.push('Dimension ' + d.id + ' not drawn: value missing');
        return;
      }
      if (d.leaderStart) {
        slotDims.push({ d: d, text: text });
        return;
      }
      var chosen = null;
      var fallback = null;
      for (var i = 0; i < d.candidates.length && !chosen; i++) {
        var cand = d.candidates[i];
        var box = labelBox(text, cand.x, cand.y, cand.anchor);
        var probe = { box: box, leader: null, owner: d.id, text: text };
        if (collisionsFor(probe, obstacles, placed).length === 0) {
          chosen = { x: cand.x, y: cand.y, anchor: cand.anchor, box: box };
        } else if (!fallback) {
          fallback = { x: cand.x, y: cand.y, anchor: cand.anchor, box: box };
        }
      }
      if (!chosen) {
        chosen = fallback;
        fail(d, text);
      }
      commit(d, text, chosen);
    });

    // Diameters and the shoulder angle: one row above the drawing, in order of their position along
    // the axis. Each label starts at its own feature or right of the previous label, so leaders
    // never cross and labels never overlap.
    var rowY = -(Rm + 4.6);
    var nextX = -Infinity;
    slotDims.sort(function (a, b) { return a.d.leaderStart.x - b.d.leaderStart.x; });
    slotDims.forEach(function (item) {
      var d = item.d;
      var x = Math.max(d.leaderStart.x, nextX);
      nextX = x + item.text.length * FS * CHAR_W + 1.0;
      var box = labelBox(item.text, x, rowY, 'start');
      var leader = { a: d.leaderStart, b: { x: x + 0.4, y: box.y1 + LEADER_GAP }, owner: d.id };
      var probe = { box: box, leader: leader, owner: d.id, text: item.text };
      if (collisionsFor(probe, obstacles, placed).length) {
        fail(d, item.text);
      }
      commit(d, item.text, { x: x, y: rowY, anchor: 'start', box: box, leader: leader });
    });

    // Bounds of everything drawn, then the title block below it.
    var xs = [];
    var ys = [];
    function include(p) { xs.push(p.x); ys.push(p.y); }
    outside.concat(sectionPts, bulletPts).forEach(include);
    obstacles.forEach(function (s) { include(s.a); include(s.b); });
    dims.forEach(function (d) {
      if (d.arc) { include(d.arc.start); include(d.arc.end); }
    });
    labels.forEach(function (l) { include({ x: l.box.x0, y: l.box.y0 }); include({ x: l.box.x1, y: l.box.y1 }); });
    var minX = Math.min.apply(null, xs) - 2;
    var maxX = Math.max.apply(null, xs) + 2;
    var minY = Math.min.apply(null, ys) - 2;
    var maxY = Math.max.apply(null, ys) + 2;
    var titleLines = [
      { text: record.name, size: 3.6, bold: true },
      { text: 'C.I.P. table ' + record.tab + ' · revised ' + record.revised, size: 2.6 },
      { text: 'Dimensions in mm · Scale 1:1', size: 2.6 }
    ];
    // The title block goes under a wide drawing, and beside a tall one (short cases), to keep the figure
    // close to the page width.
    var titleH = 13;
    var title;
    if ((maxY - minY) > 0.6 * (maxX - minX)) {
      var beside = { x: maxX + 3, y: minY, w: 64 };
      title = { x0: beside.x, y0: beside.y, w: beside.w };
      maxX = beside.x + beside.w + 1;
    } else {
      title = { x0: minX, y0: maxY + 1.5, w: maxX - minX };
      maxY = title.y0 + titleH + 1.5;
    }

    return {
      ok: true,
      key: record.key,
      name: record.name,
      notes: notes,
      geometry: g,
      outside: outside,
      sectionPts: sectionPts,
      bulletPts: bulletPts,
      dims: dims,
      labels: labels,
      obstacles: obstacles,
      viewBox: { x: num(minX), y: num(minY), w: num(maxX - minX), h: num(maxY - minY) },
      title: { x: num(title.x0 + 2), y: num(title.y0), h: titleH, lines: titleLines, minX: title.x0, width: title.w }
    };
  }

  // Collision check used by the tests: every label against the drawing, the leaders and the other labels.
  function findLabelCollisions(layout) {
    var problems = [];
    layout.labels.forEach(function (l, i) {
      var others = layout.labels.filter(function (o, j) { return j !== i; });
      var probe = { box: l.box, leader: null, owner: l.id, text: l.text };
      collisionsFor(probe, layout.obstacles, others)
        .forEach(function (h) { problems.push(l.text + ' overlaps ' + h); });
      var b = layout.viewBox;
      if (l.box.x0 < b.x || l.box.x1 > b.x + b.w || l.box.y0 < b.y || l.box.y1 > b.y + b.h) {
        problems.push(l.text + ' outside viewBox');
      }
    });
    return problems;
  }

  function renderDrawing(record) {
    var layout = layoutDrawing(record);
    var name = record.name;
    if (!layout.ok) {
      return '<p class="drawing-missing">' + esc(name) + ' cannot be drawn: ' + esc(layout.notes.join('; ')) + '</p>';
    }
    var g = layout.geometry;
    var vb = layout.viewBox;
    var out = [];
    out.push('<svg class="drawing" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' + esc(name) +
      ' drawing" viewBox="' + vb.x + ' ' + vb.y + ' ' + vb.w + ' ' + vb.h + '">');
    out.push('<defs><pattern id="hatch-' + esc(record.key) + '" width="1.3" height="1.3" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
      '<line class="hatch-line" x1="0" y1="0" x2="0" y2="1.3"/></pattern></defs>');
    out.push('<line class="centre-line" x1="' + num(vb.x + 1) + '" y1="0" x2="' + num(vb.x + vb.w - 1) + '" y2="0"/>');
    out.push('<path class="outline" d="' + pathOf(layout.outside) + '"/>');
    out.push('<path class="section" fill="url(#hatch-' + esc(record.key) + ')" d="' + pathOf(layout.sectionPts) + 'Z"/>');
    if (layout.bulletPts.length) {
      out.push('<path class="bullet-section" d="' + pathOf(layout.bulletPts) + 'Z"/>');
    }
    var dimParts = [];
    layout.dims.forEach(function (d) {
      if (d.arc) {
        dimParts.push('<path class="dim" d="M' + num(d.arc.start.x) + ' ' + num(d.arc.start.y) +
          ' A' + num(d.arc.radius) + ' ' + num(d.arc.radius) + ' 0 0 1 ' + num(d.arc.end.x) + ' ' + num(d.arc.end.y) + '"/>');
      } else {
        d.segments.forEach(function (s) {
          dimParts.push('<path class="' + (d.ext.indexOf(s) !== -1 ? 'ext' : 'dim') + '" d="' + pathOf([s.a, s.b]) + '"/>');
        });
      }
      d.arrows.forEach(function (a) {
        dimParts.push('<path class="dim-arrow" d="' + arrowPath(a.a, a.b) + '"/>');
      });
    });
    layout.labels.forEach(function (l) {
      if (l.leader) {
        dimParts.push('<path class="leader" d="' + pathOf([l.leader.a, l.leader.b]) + '"/>');
      }
    });
    out.push('<g class="dimensions">' + dimParts.join('') + '</g>');
    var labelParts = layout.labels.map(function (l) {
      return '<text class="dim-label" x="' + num(l.x) + '" y="' + num(l.y) + '" text-anchor="' + l.anchor + '">' + esc(l.text) + '</text>';
    });
    out.push('<g class="labels">' + labelParts.join('') + '</g>');
    var t = layout.title;
    var tb = ['<g class="title-block">',
      '<rect x="' + num(t.minX + 1) + '" y="' + num(t.y - 1) + '" width="' + num(t.width - 2) + '" height="' + num(t.h + 2) + '"/>'];
    var lineY = t.y + 3.4;
    t.lines.forEach(function (line) {
      tb.push('<text class="' + (line.bold ? 'title-name' : 'title-line') + '" x="' + num(t.x) + '" y="' + num(lineY) +
        '" font-size="' + line.size + '">' + esc(line.text) + '</text>');
      lineY += line.size + 1.6;
    });
    tb.push('</g>');
    out.push(tb.join(''));
    out.push('</svg>');
    return out.join('');
  }

  return {
    layoutDrawing: layoutDrawing,
    renderDrawing: renderDrawing,
    findLabelCollisions: findLabelCollisions,
    labelBox: labelBox,
    segmentTouchesRect: segmentTouchesRect,
    segmentsCross: segmentsCross
  };
});
