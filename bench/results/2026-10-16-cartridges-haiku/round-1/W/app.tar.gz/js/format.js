// Display formatting for cartridge records: numbers, angles, tolerances,
// symbols, units and the value tables of the detail view.
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CartridgeFormat = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var ANGLE_FIELDS = { alpha: true, alpha1: true, beta: true, delta: true, i: true };
  var COUNT_FIELDS = { N: true };
  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };
  var PRESSURE_UNITS = { PK: 'bar', PE: 'bar', Pmax: 'bar', EE: 'J', M: 'g' };

  // Cartridge and chamber sections in display order, with their headings.
  var CARTRIDGE_SECTIONS = [
    ['caseHead', 'Case head'],
    ['collar', 'Collar'],
    ['junctionCone', 'Junction cone'],
    ['lengths', 'Lengths'],
    ['misc', 'Misc'],
    ['powderChamber', 'Powder chamber'],
    ['pressures', 'Pressures'],
    ['projectile', 'Projectile']
  ];
  var CHAMBER_SECTIONS = [
    ['barrel', 'Barrel'],
    ['breech', 'Breech'],
    ['collar', 'Collar'],
    ['grooves', 'Grooves'],
    ['junctionCone', 'Junction cone'],
    ['lengths', 'Lengths'],
    ['powderChamber', 'Powder chamber'],
    ['rifling', 'Rifling']
  ];

  function pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function formatNumber(value) {
    return String(value);
  }

  function formatAngle(angle) {
    if (typeof angle === 'number') {
      return formatNumber(angle) + '°';
    }
    return formatNumber(angle.degrees) + '°' + pad2(angle.minutes) + "'" + pad2(angle.seconds) + '"';
  }

  function formatValue(field, value) {
    return ANGLE_FIELDS[field] ? formatAngle(value) : formatNumber(value);
  }

  function symbolFor(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unitFor(sectionKey, field) {
    if (ANGLE_FIELDS[field] || COUNT_FIELDS[field]) {
      return '';
    }
    if (sectionKey === 'pressures' && PRESSURE_UNITS[field]) {
      return PRESSURE_UNITS[field];
    }
    if (field === 'Q') {
      return 'mm²';
    }
    return 'mm';
  }

  // Rows of one section. A `<X>Tol` field is folded into the value of X and never listed.
  function sectionRows(values, sectionKey) {
    var rows = [];
    Object.keys(values).forEach(function (field) {
      if (/Tol$/.test(field) && Object.prototype.hasOwnProperty.call(values, field.slice(0, -3))) {
        return;
      }
      var text = formatValue(field, values[field]);
      var tol = field + 'Tol';
      if (Object.prototype.hasOwnProperty.call(values, tol)) {
        text += ' ' + formatNumber(values[tol]);
      }
      rows.push({
        field: field,
        symbol: symbolFor(field),
        value: text,
        unit: unitFor(sectionKey, field)
      });
    });
    return rows;
  }

  function buildGroup(source, sectionList) {
    var groups = [];
    sectionList.forEach(function (entry) {
      var values = source && source[entry[0]];
      if (!values) {
        return;
      }
      groups.push({ key: entry[0], title: entry[1], rows: sectionRows(values, entry[0]) });
    });
    return groups;
  }

  // Sections of a record, grouped as "cartridge" and "chamber".
  function buildSections(record) {
    return {
      cartridge: buildGroup(record.cartridge, CARTRIDGE_SECTIONS),
      chamber: buildGroup(record.chamber, CHAMBER_SECTIONS)
    };
  }

  function waterCapacity(record) {
    var pub = record.annotations.publishedCapacity;
    if (!pub) {
      return null;
    }
    return {
      text: formatNumber(pub.grH2O) + ' grH2O',
      source: pub.source,
      url: pub.url,
      note: pub.note || ''
    };
  }

  function sourceLine(record) {
    return 'Source: C.I.P. TDCC, revised ' + record.revised;
  }

  return {
    formatNumber: formatNumber,
    formatAngle: formatAngle,
    formatValue: formatValue,
    symbolFor: symbolFor,
    unitFor: unitFor,
    sectionRows: sectionRows,
    buildSections: buildSections,
    waterCapacity: waterCapacity,
    sourceLine: sourceLine
  };
});
