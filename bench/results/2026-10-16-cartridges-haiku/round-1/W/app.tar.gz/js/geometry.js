// Cartridge geometry for the drawing. Pure functions, millimetres.
// Points are {z, r}: z runs along the axis from the head face (z = 0) to the mouth,
// r is the radius. Angles in the record are converted to radians here.
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CartridgeGeometry = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var PI = Math.PI;
  var ARC_STEPS = 8;
  var NOSE_STEPS = 24;

  // Primer type -> [pocket diameter, pocket depth] in mm (centrefire only).
  var POCKETS = {
    sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04],
    lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3]
  };

  function isNum(v) {
    return typeof v === 'number' && isFinite(v);
  }

  function rad(deg) {
    return deg * PI / 180;
  }

  // An angle is a number of degrees or {degrees, minutes, seconds}.
  function angleDegrees(a) {
    if (typeof a === 'number') {
      return a;
    }
    if (a && isNum(a.degrees)) {
      return a.degrees + (a.minutes || 0) / 60 + (a.seconds || 0) / 3600;
    }
    return undefined;
  }

  function pt(z, r) {
    return { z: z, r: r };
  }

  // A value is present when it is a finite number, or an angle object with degrees.
  function has(v) {
    return isNum(v) || angleDegrees(v) !== undefined;
  }

  function dedupe(points) {
    var out = [];
    points.forEach(function (p) {
      var last = out[out.length - 1];
      if (!last || Math.abs(last.z - p.z) > 1e-9 || Math.abs(last.r - p.r) > 1e-9) {
        out.push(p);
      }
    });
    return out;
  }

  // Rim type from the family, then the R1/P1 ratio (brief, rule 1).
  function rimTypeOf(family, R1, P1) {
    if (family === 'belted') {
      return 'belted';
    }
    if (family === 'rimfire') {
      return 'rimfire';
    }
    var ratio = R1 / P1;
    if (ratio >= 1.05) {
      return 'rimmed';
    }
    if (ratio < 0.98) {
      return 'rebated';
    }
    return 'rimless';
  }

  // Rounds the corner C between the straight lines C-A and C-B with radius rho.
  // Returns the points of the arc, from the tangent point on C-A to the one on C-B.
  function fillet(a, c, b, rho) {
    var la = Math.hypot(a.z - c.z, a.r - c.r);
    var lb = Math.hypot(b.z - c.z, b.r - c.r);
    var u1 = { z: (a.z - c.z) / la, r: (a.r - c.r) / la };
    var u2 = { z: (b.z - c.z) / lb, r: (b.r - c.r) / lb };
    var phi = Math.acos(Math.max(-1, Math.min(1, u1.z * u2.z + u1.r * u2.r)));
    if (phi < 1e-6 || PI - phi < 1e-6) {
      return [c];
    }
    var t = rho / Math.tan(phi / 2);
    var limit = 0.5 * Math.min(la, lb);
    if (t > limit) {
      t = limit;
      rho = t * Math.tan(phi / 2);
    }
    var t1 = pt(c.z + u1.z * t, c.r + u1.r * t);
    var t2 = pt(c.z + u2.z * t, c.r + u2.r * t);
    var bis = { z: u1.z + u2.z, r: u1.r + u2.r };
    var bl = Math.hypot(bis.z, bis.r);
    var dc = rho / Math.sin(phi / 2);
    var o = pt(c.z + bis.z / bl * dc, c.r + bis.r / bl * dc);
    var a1 = Math.atan2(t1.r - o.r, t1.z - o.z);
    var a2 = Math.atan2(t2.r - o.r, t2.z - o.z);
    var sweep = a2 - a1;
    while (sweep > PI) { sweep -= 2 * PI; }
    while (sweep <= -PI) { sweep += 2 * PI; }
    var out = [];
    for (var i = 0; i <= ARC_STEPS; i++) {
      var ang = a1 + sweep * i / ARC_STEPS;
      out.push(pt(o.z + rho * Math.cos(ang), o.r + rho * Math.sin(ang)));
    }
    return out;
  }

  // Points of the bullet nose from the cylinder end (zc, rc) to the meplat at z = L6.
  function nosePoints(shape, zc, rc, L6, m) {
    var n = L6 - zc;
    var out = [];
    var i;
    if (shape === 'pointy') {
      var d = rc - m / 2;
      if (d <= 0 || n <= 0) {
        return [pt(zc, rc), pt(L6, m / 2)];
      }
      var rho = (d * d + n * n) / (2 * d);
      var phiEnd = Math.asin(Math.min(1, n / rho));
      for (i = 0; i <= NOSE_STEPS; i++) {
        var phi = phiEnd * i / NOSE_STEPS;
        out.push(pt(zc + rho * Math.sin(phi), rc - rho + rho * Math.cos(phi)));
      }
    } else if (shape === 'rounded') {
      for (i = 0; i <= NOSE_STEPS; i++) {
        var th = (PI / 2) * i / NOSE_STEPS;
        out.push(pt(zc + n * Math.sin(th), m / 2 + (rc - m / 2) * Math.cos(th)));
      }
    } else {
      return [pt(zc, rc), pt(L6, m / 2)];
    }
    out[out.length - 1] = pt(L6, m / 2);
    return out;
  }

  // Seating factor, cylinder end factor and meplat diameter for a nose shape (brief, rule 7).
  function bulletParameters(shape, pistol, G1) {
    if (shape === 'pointy') {
      return { s: 1.0 * G1, k: 0.40, m: Math.max(0.08 * G1, 1.27) };
    }
    if (shape === 'rounded') {
      return pistol
        ? { s: 0.4 * G1, k: 0.65, m: 0.15 * G1 }
        : { s: 0.8 * G1, k: 0.55, m: 0.15 * G1 };
    }
    if (shape === 'flat') {
      return pistol
        ? { s: 0.4 * G1, k: 0.70, m: 0.55 * G1 }
        : { s: 0.8 * G1, k: 0.60, m: 0.55 * G1 };
    }
    if (shape === 'semi_wadcutter') {
      return { s: 0.6 * G1, k: 0.78, m: 0.6 * G1 };
    }
    return null;
  }

  // Keeps the part of a polyline at or beyond z = w, starting with the point at z = w.
  function clipFrom(points, w) {
    var out = [];
    for (var i = 0; i < points.length; i++) {
      var p = points[i];
      if (p.z < w) {
        continue;
      }
      if (out.length === 0 && i > 0) {
        var q = points[i - 1];
        var t = (w - q.z) / (p.z - q.z);
        out.push(pt(w, q.r + t * (p.r - q.r)));
      }
      out.push(p);
    }
    return out;
  }

  function computeGeometry(record) {
    var c = record.cartridge || {};
    var ch = c.caseHead || {};
    var lens = c.lengths || {};
    var pc = c.powderChamber || {};
    var col = c.collar || {};
    var jc = c.junctionCone || {};
    var proj = c.projectile || {};
    var ann = record.annotations || {};
    var notes = [];
    var key = record.key;
    var name = record.name;

    var required = { R1: ch.R1, P1: pc.P1, R: ch.R, L3: lens.L3, H2: col.H2, G1: proj.G1 };
    var missing = Object.keys(required).filter(function (k) { return !isNum(required[k]); });
    if (missing.length) {
      return { ok: false, key: key, name: name, missing: missing, notes: ['Not drawn: ' + missing.join(', ') + ' missing'] };
    }

    var R1 = ch.R1;
    var P1 = pc.P1;
    var R = ch.R;
    var L3 = lens.L3;
    var H2 = col.H2;
    var G1 = proj.G1;
    var r1h = R1 / 2;
    var rim = rimTypeOf(record.family, R1, P1);

    // Head face and rim edge (rule 2). The last point is the rim back corner.
    var outer = [pt(0, 0)];
    if (rim === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      var rc = r1h - rho;
      var zc = R / 2;
      outer.push(pt(0, rc));
      for (var i = 0; i <= ARC_STEPS; i++) {
        var th = PI * (1 - i / ARC_STEPS);
        outer.push(pt(zc + rho * Math.cos(th), rc + rho * Math.sin(th)));
      }
      outer.push(pt(R, rc));
    } else {
      var beta = angleDegrees(ch.beta);
      var f = ch.f;
      var hasBeta = beta !== undefined;
      var hasF = isNum(f);
      if (hasBeta && hasF && beta < 90) {
        var cham = Math.min(f * Math.tan(rad(beta)), R1 / 4);
        outer.push(pt(0, r1h - cham), pt(f, r1h));
      } else {
        if (hasBeta !== hasF) {
          notes.push('Head chamfer not drawn: ' + (hasBeta ? 'f' : 'beta') + ' missing');
        }
        outer.push(pt(0, r1h));
      }
      outer.push(pt(R, r1h));
    }

    // Extractor groove (rule 3).
    var belted = rim === 'belted';
    var grooveFields = belted
      ? { E: ch.E, E1: ch.E1, eMin: ch.eMin, R3: ch.R3, delta: ch.delta }
      : { E: ch.E, E1: ch.E1, eMin: ch.eMin };
    var presentG = Object.keys(grooveFields).filter(function (k) { return has(grooveFields[k]); });
    var missingG = Object.keys(grooveFields).filter(function (k) { return !has(grooveFields[k]); });
    var groove = false;
    var zs;
    var beltRampEnd;
    var keys = [];
    if (presentG.length > 0 && missingG.length === 0) {
      groove = true;
    } else if (presentG.length > 0) {
      notes.push('Extractor groove not drawn: ' + missingG.join(', ') + ' missing');
    }
    var E;
    var E1;
    if (groove) {
      E = ch.E;
      E1 = ch.E1;
      var eMin = ch.eMin;
      var e1h = E1 / 2;
      outer.push(pt(R, e1h), pt(R + eMin, e1h));
      if (belted) {
        var r3h = ch.R3 / 2;
        beltRampEnd = R + eMin + (r3h - e1h) / Math.tan(rad(angleDegrees(ch.delta)));
        outer.push(pt(beltRampEnd, r3h), pt(E, r3h), pt(E, P1 / 2));
        keys.push({ z: beltRampEnd, r: r3h, t: 'tb' }, { z: E, r: r3h, t: 'tb' });
      } else {
        outer.push(pt(E, P1 / 2));
      }
      zs = E;
    } else {
      outer.push(pt(R, P1 / 2));
      zs = R;
    }
    keys.push({ z: zs, r: P1 / 2, t: 'tb' });

    // Body, shoulder and neck (rule 4 and 5). Bottleneck needs all five values.
    var shoulderFields = { alpha: jc.alpha, L1: lens.L1, L2: lens.L2, P2: pc.P2, H1: col.H1 };
    var presentS = Object.keys(shoulderFields).filter(function (k) { return has(shoulderFields[k]); });
    var missingS = Object.keys(shoulderFields).filter(function (k) { return !has(shoulderFields[k]); });
    var bottleneck = missingS.length === 0;
    if (!bottleneck && presentS.length > 0) {
      notes.push('Shoulder not drawn: ' + missingS.join(', ') + ' missing');
    }

    var tn = (H2 - G1) / 2;
    var heeled = H2 - G1 <= 0.015;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
    var neckWall = heeled ? tb : tn;

    var shoulderHalfAngleDeg = null;
    var points = { bodyStart: pt(zs, P1 / 2) };
    if (bottleneck) {
      var c1 = pt(lens.L1, pc.P2 / 2);
      var c2 = pt(lens.L2, col.H1 / 2);
      var mouth = pt(L3, H2 / 2);
      var body = pt(zs, P1 / 2);
      outer.push.apply(outer, isNum(jc.r1Min) ? fillet(body, c1, c2, jc.r1Min) : [c1]);
      outer.push.apply(outer, isNum(jc.r2) ? fillet(c1, c2, mouth, jc.r2) : [c2]);
      outer.push(mouth);
      keys.push({ z: c1.z, r: c1.r, t: 'tb' }, { z: c2.z, r: c2.r, t: 'neck' });
      points.shoulderStart = c1;
      points.shoulderEnd = c2;
      shoulderHalfAngleDeg = Math.atan2(c1.r - c2.r, c2.z - c1.z) * 180 / PI;
    } else {
      outer.push(pt(L3, H2 / 2));
    }
    keys.push({ z: L3, r: H2 / 2, t: 'neck' });

    // Inner wall: each key point of the outer profile is offset inward by its wall thickness.
    var inner = keys.map(function (k) {
      return pt(k.z, k.r - (k.t === 'neck' ? neckWall : tb));
    });
    var pocket = null;
    if (rim !== 'rimfire') {
      var primer = ann.primerType;
      if (POCKETS[primer]) {
        pocket = { diameter: POCKETS[primer][0], depth: POCKETS[primer][1] };
      } else {
        notes.push('Primer pocket not drawn: primerType missing or unknown');
      }
    }

    var w = Math.max(2.5, P1 / 8, pocket ? pocket.depth + 1.5 : 0);
    if (groove) {
      w = Math.max(w, belted ? beltRampEnd + tb : E + tb);
    }
    var innerClipped = clipFrom(inner, w);

    // Section polygon (upper half, z-r coordinates). The solid head ends at z = w.
    var section = [];
    section.push(pocket ? pt(0, pocket.diameter / 2) : pt(0, 0));
    section.push.apply(section, outer.slice(1));
    section.push.apply(section, innerClipped.slice().reverse());
    section.push(pt(w, 0));
    if (pocket) {
      section.push(pt(pocket.depth, 0), pt(pocket.depth, pocket.diameter / 2));
    }
    section = dedupe(section);

    var bullet = null;
    var shape = ann.defaultBulletShape;
    var L6 = lens.L6;
    if (!isNum(L6) || !shape) {
      notes.push('Bullet not drawn: ' + (!isNum(L6) ? 'L6' : 'defaultBulletShape') + ' missing');
    } else {
      var pistol = ann.category === 'pistol';
      var params = bulletParameters(shape, pistol, G1);
      if (!params) {
        notes.push('Bullet not drawn: unknown defaultBulletShape "' + shape + '"');
      } else {
        bullet = buildBullet(params, { L3: L3, L6: L6, G1: G1, H2: H2, heeled: heeled, tb: tb, shape: shape });
      }
    }

    return {
      ok: true,
      key: key,
      name: name,
      rimType: rim,
      groove: groove,
      bottleneck: bottleneck,
      heeled: heeled,
      tn: tn,
      tb: tb,
      neckWall: neckWall,
      w: w,
      zs: zs,
      beltRampEnd: beltRampEnd,
      pocket: pocket,
      points: points,
      shoulderHalfAngleDeg: shoulderHalfAngleDeg,
      outer: dedupe(outer),
      inner: innerClipped,
      section: section,
      bullet: bullet,
      notes: notes,
      missing: []
    };
  }

  function buildBullet(params, d) {
    var L3 = d.L3;
    var L6 = d.L6;
    var G1 = d.G1;
    var s = params.s;
    var zb = L3 - s;
    var Lb = L6 - zb;
    var zc = zb + params.k * Lb;
    var n = L6 - zc;
    var Rc = d.heeled ? d.H2 / 2 : G1 / 2;
    var rSeat = d.heeled ? d.H2 / 2 - d.tb : G1 / 2;

    var full = [pt(zb, 0), pt(zb, rSeat)];
    if (rSeat !== Rc) {
      full.push(pt(L3, rSeat), pt(L3, Rc));
    }
    full.push(pt(zc, Rc));
    full.push.apply(full, nosePoints(d.shape, zc, Rc, L6, params.m));
    full.push(pt(L6, 0));
    full = dedupe(full);

    var exposed = [pt(L3, Rc)].concat(full.filter(function (p) { return p.z > L3 + 1e-9; }));
    exposed = dedupe(exposed);
    return {
      shape: d.shape,
      s: s,
      k: params.k,
      m: params.m,
      zb: zb,
      zc: zc,
      n: n,
      Lb: Lb,
      Rc: Rc,
      rSeat: rSeat,
      heeled: d.heeled,
      full: full,
      exposed: exposed
    };
  }

  return {
    computeGeometry: computeGeometry,
    rimTypeOf: rimTypeOf,
    fillet: fillet,
    nosePoints: nosePoints,
    bulletParameters: bulletParameters,
    POCKETS: POCKETS
  };
});
