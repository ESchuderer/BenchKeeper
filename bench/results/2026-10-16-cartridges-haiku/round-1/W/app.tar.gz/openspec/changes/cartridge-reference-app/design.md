# Design

## Context

The project is empty apart from OpenSpec and agent configuration. The app must run from `file://` in Chromium, which blocks `fetch` of local JSON and ES module scripts from an opaque origin. See proposal.md for motivation; the requirements are in `specs/`.

## Goals / Non-Goals

**Goals:**
- One static bundle: `index.html`, `css/app.css`, and classic scripts under `js/`.
- Geometry, formatting and filtering are pure functions that Node's built-in test runner can exercise without a DOM.
- The drawing is deterministic from the record, so its rules can be tested per cartridge.

**Non-Goals:**
- Editing, fetching or extending the data.
- Showing `confidence`, `implausible`, `key`, `defaultBullet` or `publishedCapacity` beyond what the spec asks for.
- Pixel-perfect CIP drawings: the brief's rules are followed, not CIP engineering drawings.

## Decisions

### Classic scripts with a UMD-style export
Each file in `js/` assigns one global namespace (for example `CartridgeGeometry`) and also exports through `module.exports` when loaded by Node. The data is `js/cartridges-data.js`, assigning the array of 25 records. **Why:** ES modules fail on `file://`; a shared global keeps the code reachable from both the page and tests. **Alternative:** a single bundle built by a script — rejected because the brief forbids a build step.

### Hash routing
Detail views live at `index.html#/cartridge/<key>`; the list is `index.html#/` (or no hash). **Why:** `history.pushState` paths do not resolve on `file://`, while hash addresses survive reload and bookmarks in both delivery modes.

### Geometry in (z, r) millimetres
`js/geometry.js` returns polylines of `{z, r}` points: outer half-profile, inner profile, bullet outline, and the section polygon. The SVG layer maps `x = z` and `y = -r` for the outside view and `y = +r` for the section. **Why:** this keeps the brief's rules testable as numbers, independent of SVG.

### Wall thickness for straight cases
The brief defines tb along the body and tn along the neck, but a straight case has no neck. Non-heeled straight cases blend linearly from tb at the body start to tn at the mouth, so the bullet fits the mouth (inner mouth radius = G1/2). Heeled cases keep tb to the mouth, so the case's inside diameter at the mouth equals H2 − 2·tb, matching the seated heel. **Why:** constant tb would put a 9 mm mouth inside the bullet. **Alternative:** clip the inner wall at G1/2 — rejected, it hides a real wall.

### Rimfire half-round
Semicircle of radius ρ = min(R/2, (R1−P1)/2) centred at (z = R/2, r = R1/2 − ρ). When ρ < R/2 the flanks are straight segments to the head face and rim back. **Why:** this is exact for every rimfire record in the data (ρ = R/2) and degrades without inventing geometry otherwise.

### Bullet nose and heeled radii
Nose formulas use the cylinder radius Rc (G1/2, or H2/2 for heeled cases) so the nose joins the cylinder tangentially. The seated heel radius is H2/2 − tb for heeled cases and G1/2 otherwise.

### Dimension placement
Dimension tiers sit at fixed offsets from the maximum outline radius: horizontal length dimensions on the upper side (R, then L3) and lower side (L1, L2, L6), diameters and the angle beside the features they measure, R1 to the left of the head. Labels are placed by trying candidate positions in a fixed order and taking the first whose estimated bounding box clears the outline, the dimension lines and other labels. Text width is estimated at 0.6 em per character, which is deliberately wide. **Why:** a fixed table would need hand-tuning for 25 different profiles, and the check can run for all records in the test suite.

### Missing values
Each rule records the names of the values it needed but could not find. These are listed in a notes line under the drawing and in the same SVG title block, so a printed drawing also states them.

### Presentation
- Light/dark via `prefers-color-scheme`; print forces light via `@media print`.
- Tables are two-column on wide screens and stack on phones; the print layout places cartridge and chamber tables side by side, with the drawing at full width.
- The list is sorted alphabetically with numeric collation (`6,5 Creedmoor` before `7 x 64`). This is a presentation choice not fixed by the brief.
- Unit column: blank for angles and counts (the value already carries `°`).

### Testing
- `node --test` with no dependencies covers formatting, filtering, routing helpers, geometry for all 25 records, and label collisions.
- Browser checks (screenshots, print-to-PDF page count) are run from a Playwright dev dependency when a browser is available; they are verification steps, not part of the app.

## Risks / Trade-offs

- [Label estimate is approximate] → 0.6 em per character over-estimates most glyphs, so the real text is never wider than the check assumes. The check cannot see font kerning or the phone's font size.
- [One-page print depends on the browser] → print CSS sets explicit sizes and the page is verified with a print-to-PDF page count when Chromium is available.
- [Brief geometry is not CIP-exact] → the drawing follows the brief's rules; deviations (the straight-case wall blend, the flank segments in rimfire rims) are listed here and in the final report.
- [Inner-profile corners are sharp] → the section's inner corners are not filleted; only the outer r1 min and r2 fillets are drawn. This keeps the wall offsets simple.

## Migration Plan

None: the project is new. Rollback is removing the new files.

## Open Questions

None. The choices above are recorded so they can be changed in one place.
