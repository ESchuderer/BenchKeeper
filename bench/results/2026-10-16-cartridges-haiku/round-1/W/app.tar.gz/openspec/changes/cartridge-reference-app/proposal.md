# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick, trustworthy reference for C.I.P. cartridge dimensions. The project has the data (25 records from OpenBallistics, MIT) but no way to browse it or see a cartridge's geometry. A static, dependency-free web page built on those records fills that gap and can be opened straight from disk.

## What Changes

- Add a static reference app at `index.html` with its CSS and JavaScript, embedding the 25 supplied cartridge records unchanged.
- Start page: a searchable, family-filterable list of cartridges (name, family, L3), each name linking to its detail view.
- Detail view: identification fields, C.I.P. table, country, dates, pressure method, published water capacity with source link, every cartridge and chamber value in grouped tables, and a computed 2D drawing. Each detail view has its own bookmarkable address.
- Drawing: an inline SVG computed from the record with the geometry rules in the brief (outside view above the axis, section below, dimension lines, title block).
- Print: a Print button that produces one A4 portrait, black-on-white page with the drawing and tables.
- Light and dark colour schemes that follow the system setting; responsive layout for phone widths.
- No framework, no build step, no network requests, no server code. Works from `file://` in Chromium and from any static server.

## Capabilities

### New Capabilities

- `cartridge-browse`: the start page listing, search, family filter and navigation to a cartridge's address.
- `cartridge-detail`: the per-cartridge view, its addressing, value formatting, tables, metadata and print output.
- `cartridge-drawing`: the computed 2D technical drawing of a cartridge (geometry, dimensions, title block, scaling).
- `static-app-delivery`: how the app is packaged and runs (static files, `file://` operation, offline, theming, development tooling boundaries).

### Modified Capabilities

None. The `openspec/specs/` directory is empty.

## Impact

- New files only: `index.html`, `css/`, `js/`, the embedded data module, tests under `test/`, and a `package.json` whose only role is to run the test suite (Node's built-in test runner, no runtime dependencies).
- No existing code is affected. No external services, fonts or CDNs are used.
- Out of scope: editing or extending the data, fetching newer data, showing the `confidence`, `implausible`, `key` and bullet annotation fields, and bullet-level data beyond what the drawing rules need.
