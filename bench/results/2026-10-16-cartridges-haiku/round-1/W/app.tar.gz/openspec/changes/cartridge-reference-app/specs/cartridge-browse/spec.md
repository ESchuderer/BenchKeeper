# Spec Delta

## Purpose

Lets a technical user find a cartridge in the reference by name, alternative name or family, and open its detail view at a stable address.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" followed by one entry per cartridge record, sorted alphabetically by name. Each entry SHALL show the cartridge's family and its case length L3 with unit.

#### Scenario: All records listed on load
- **WHEN** the start page is opened with no filter applied
- **THEN** every one of the 25 cartridge records is listed
- **AND** the count text reads "25 cartridges"

#### Scenario: Entry content
- **WHEN** a cartridge entry is shown
- **THEN** it shows the family and the L3 value with unit (for example "51.18 mm")

### Requirement: Cartridge name links to its detail view
Each cartridge name SHALL be a link whose visible text is exactly the record's `name`. Activating it SHALL open that cartridge's detail view.

#### Scenario: Link text exact
- **WHEN** the start page is rendered
- **THEN** each cartridge name link's text equals the record's `name` exactly (for example "6,5 Creedmoor")

#### Scenario: Activating a link
- **WHEN** the user activates the link for "308 Win."
- **THEN** the detail view for that cartridge opens at its own address

### Requirement: Search filters by name and alternative names
A text field labelled "Search" SHALL filter the list as the user types. A cartridge matches when the query is found, ignoring letter case and whitespace differences, in its `name` or in any of its `alternativeNames`.

#### Scenario: Alternative name finds a cartridge
- **WHEN** the user types "7,62 x 51"
- **THEN** the list shows "308 Win." and no other cartridge

#### Scenario: Case-insensitive match
- **WHEN** the user types "creedmoor"
- **THEN** the list shows "6,5 Creedmoor"

#### Scenario: No match
- **WHEN** the user types a query that matches no cartridge
- **THEN** the list is empty and the count text reads "0 cartridges"

### Requirement: Family select filters the list
A select labelled "Family" SHALL offer the options All, rimless, rimmed, belted, pistol and rimfire. Choosing an option SHALL list only cartridges of that family. "All" SHALL list every cartridge. The search and family filters SHALL combine (both must match).

#### Scenario: Family filter
- **WHEN** the user selects "rimfire"
- **THEN** only "22 Long Rifle", "22 Win. Mag. R.F." and "17 HMR" are listed

#### Scenario: Filters combine
- **WHEN** the family is "rimless" and the search is "308"
- **THEN** the list shows "308 Win." and "7,62 x 39" is not listed

### Requirement: Count text reflects the visible list
The text "<n> cartridges" SHALL state how many cartridges are currently listed and SHALL update with every change of filter. The singular form "1 cartridge" SHALL be used when n is 1.

#### Scenario: Count updates
- **WHEN** the user narrows the list to one cartridge
- **THEN** the count text reads "1 cartridge"

### Requirement: Start page is the list address
The start page SHALL be addressed without a cartridge identifier (the application's root address) and a detail view SHALL be addressed by the cartridge's `key`. Opening either address directly, or reloading it, SHALL show the same view.

#### Scenario: Reload of a detail view
- **WHEN** the user reloads the browser on a detail view address
- **THEN** the same cartridge's detail view is shown again

#### Scenario: Unknown key
- **WHEN** the address names a key that matches no cartridge
- **THEN** the page shows "Cartridge not found" and a link "All cartridges" to the start page
