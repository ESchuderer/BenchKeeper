# Spec Delta

## Purpose

Shows everything the C.I.P. record publishes for one cartridge, in a form a reloader, gunsmith or engineer can read, copy and print.

## ADDED Requirements

### Requirement: Detail view identifies the cartridge
The detail view SHALL have the cartridge's `name` as its heading, followed by its alternative names (when any), family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method and the published water capacity. The water capacity SHALL show `publishedCapacity.grH2O` with its `source` as a link to `publishedCapacity.url`, and the `note` when one is published.

#### Scenario: Identification fields
- **WHEN** the detail view for "223 Rem." is shown
- **THEN** the heading reads "223 Rem."
- **AND** the page shows family "rimless", category "rifle", primer type "sr", C.I.P. table "I", country "US", published "1984-06-14", revised "2017-05-17" and pressure method "Transducer"

#### Scenario: Water capacity with source link
- **WHEN** the detail view for "223 Rem." is shown
- **THEN** the water capacity reads "30.5 grH2O"
- **AND** the source "kwk" is a link to "http://kwk.us/cases.html"
- **AND** the note "kwk 31, Wikipedia 28.8; the mean" is shown

#### Scenario: No alternative names
- **WHEN** a cartridge has no `alternativeNames`
- **THEN** no alternative-names line is shown

### Requirement: Values are shown as published
Numbers SHALL be shown as published, with a decimal point and no thousands separator. Names SHALL be shown exactly as published. Angles SHALL be shown in degrees, using the form `40°` for a number and `39°59'49"` for an object with degrees, minutes and seconds (minutes and seconds padded to two digits). Symbols SHALL be the field name, except as listed in the Symbol requirement below.

#### Scenario: Number formatting
- **WHEN** a value of 4150 bar is shown
- **THEN** it reads "4150 bar" with no thousands separator

#### Scenario: Angle object
- **WHEN** the rifling twist angle `i` of "223 Rem." is shown
- **THEN** it reads "3°10'36""

#### Scenario: Angle number
- **WHEN** the shoulder angle `alpha` of "223 Rem." is shown
- **THEN** it reads "46°"

### Requirement: Symbols
Symbols SHALL use these display forms: `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G". Every other symbol is the field name as published.

#### Scenario: Greek and special symbols
- **WHEN** the detail tables are shown for a cartridge with `beta`, `eMin` and `L3PlusG`
- **THEN** the symbols read "β", "e min" and "L3 + G"

### Requirement: Tolerances sit beside their value
A field `<X>Tol` SHALL be shown in the Value cell of X, after X's value, and SHALL never appear as a row of its own.

#### Scenario: Tolerance beside value
- **WHEN** a cartridge has `lengths.L1` 39.62 and `L1Tol` -0.2
- **THEN** the L1 row's value reads "39.62 -0.2"
- **AND** no row labelled "L1Tol" exists

### Requirement: Value tables grouped by section
The detail view SHALL show every value under `cartridge` and every value under `chamber` in tables grouped by section (for example "Case head", "Lengths", "Rifling"), each table with the columns "Symbol", "Value" and "Unit". Every field present in a record SHALL appear in its tables, and no absent field SHALL appear.

#### Scenario: Cartridge and chamber sections
- **WHEN** the detail view for "308 Win." is shown
- **THEN** tables exist for the cartridge sections (case head, collar, junction cone, lengths, misc, powder chamber, pressures, projectile) and for the chamber sections (barrel, breech, collar, grooves, junction cone, lengths, powder chamber, rifling)

#### Scenario: Units
- **WHEN** the pressure "Pmax" of "308 Win." is shown
- **THEN** its row reads Symbol "Pmax", Value "4150", Unit "bar"

#### Scenario: Missing field stays out
- **WHEN** a record has no `L4` field
- **THEN** no "L4" row appears in any table for that cartridge

### Requirement: Detail view address
Each cartridge's detail view SHALL have its own address that identifies the cartridge by its `key`. The address SHALL survive a reload and SHALL work when bookmarked.

#### Scenario: Bookmarked address
- **WHEN** the user opens the address of "9 mm Luger" in a new browser session
- **THEN** the detail view for "9 mm Luger" is shown

### Requirement: Navigation back to the list
The detail view SHALL contain a link labelled "All cartridges" that opens the start page.

#### Scenario: Back link
- **WHEN** the user activates "All cartridges" on a detail view
- **THEN** the start page is shown with no cartridge selected

### Requirement: Print button
The detail view SHALL have a "Print" button that opens the browser's print dialog for the current view.

#### Scenario: Print invoked
- **WHEN** the user activates "Print"
- **THEN** the browser print dialog opens

### Requirement: Printed page layout
When the detail view is printed, the output SHALL be one A4 portrait page in black on white. The page SHALL show a header with the cartridge name, the drawing at full page width with every label legible, then the value tables. Navigation, search fields and buttons SHALL NOT be printed. A footer SHALL state the source as "C.I.P. TDCC" with the record's `revised` date.

#### Scenario: Print output
- **WHEN** the detail view for "223 Rem." is printed
- **THEN** the printed output fits on one A4 portrait page
- **AND** the output contains no "Print" button, no "All cartridges" link and no search field
- **AND** the footer reads "Source: C.I.P. TDCC, revised 2017-05-17"

### Requirement: Colour scheme
The application SHALL render in a light scheme or a dark scheme following the system's colour-scheme preference. Print output SHALL always use the light scheme.

#### Scenario: Dark system setting
- **WHEN** the system colour-scheme preference is dark
- **THEN** the page background is dark and the text is light

### Requirement: Usable on a phone
The detail view SHALL remain readable and usable at a phone-width viewport. Tables SHALL not force the page to scroll horizontally at a 360 px wide viewport.

#### Scenario: Narrow viewport
- **WHEN** the detail view is shown at 360 px width
- **THEN** the page does not scroll horizontally
