# Spec Delta

## Purpose

Draws each cartridge's outside view and axial section to scale from its published C.I.P. dimensions, with dimensions, a title block and missing-value notes, so that a reader can check the record against a picture.

## ADDED Requirements

### Requirement: Inline SVG drawing to scale
The detail view SHALL include an inline SVG drawing, labelled with the accessible name "<name> drawing". Its coordinate system SHALL be in millimetres (1 user unit = 1 mm), with the cartridge axis horizontal and the head on the left, and it SHALL scale to the width of its container.

#### Scenario: Accessible name
- **WHEN** the detail view for "9 mm Luger" is shown
- **THEN** the drawing has the accessible name "9 mm Luger drawing"

#### Scenario: Scale
- **WHEN** the drawing is generated
- **THEN** one user unit equals one millimetre of the record's lengths and diameters

### Requirement: Outside view and section
The upper half of the drawing SHALL be the outside view (the outline of the case and the exposed bullet). The lower half SHALL be an axial section in which the cut case walls and solid head are hatched. A dash-dot centre line SHALL run along the axis.

#### Scenario: Halves
- **WHEN** the drawing for "308 Win." is generated
- **THEN** the outside outline lies above the axis and the hatched section lies below it
- **AND** a dash-dot centre line is drawn along the axis

### Requirement: Profile construction
The outer half-profile SHALL be built from the head face (z = 0) to the mouth using the record's values, and mirrored at the axis. Rim type SHALL be derived as: family `belted` is belted; family `rimfire` is rimfire; otherwise R1/P1 of at least 1.05 is rimmed, below 0.98 is rebated, and anything else is rimless.

#### Scenario: Rim type
- **WHEN** rim type is derived for "9,3 x 74 R" (family rimmed, R1 13.35, P1 11.9)
- **THEN** the rim type is rimmed

#### Scenario: Belted family
- **WHEN** rim type is derived for "300 Win. Mag." (family belted)
- **THEN** the rim type is belted

### Requirement: Head face and rim edge
The head face SHALL run from the axis outward. Where `beta` and `f` are published and beta is below 90°, a chamfer from (R1/2 − min(f·tan β, R1/4), 0) to (R1/2, f) SHALL be drawn, followed by the rim outside at R1/2 up to R. For rimfire cases, the rim edge SHALL be a half-round of radius min(R/2, (R1 − P1)/2) whose outermost point lies at R1/2. Otherwise the rim corner SHALL be square.

#### Scenario: Chamfered head
- **WHEN** the drawing for "308 Win." is generated (beta 35, f 0.38)
- **THEN** the head face has a chamfer of radial width min(0.38·tan 35°, R1/4)

#### Scenario: Rimfire rim edge
- **WHEN** the drawing for "22 Long Rifle" is generated
- **THEN** the rim edge is a half-round of radius min(R/2, (R1 − P1)/2)

### Requirement: Extractor groove
Where `E` and `E1` are published, the extractor groove SHALL be drawn: from the rim back face inward to the groove diameter E1, along the groove floor for `eMin`, then a straight ramp out to P1/2 at z = E. For belted cases, the ramp SHALL instead leave the floor at angle δ to the axis up to the belt radius R3/2, follow the belt to z = E, and step in to P1/2. Without a groove, the rim back face SHALL step in to P1/2.

#### Scenario: Groove present
- **WHEN** the drawing for "223 Rem." is generated
- **THEN** the outline shows the groove floor at E1/2 between R and R + eMin, and a ramp reaching P1/2 at z = E

#### Scenario: Belted groove
- **WHEN** the drawing for "300 Win. Mag." is generated
- **THEN** the ramp from the floor reaches R3/2 at the angle δ and the belt runs to z = E

#### Scenario: No groove
- **WHEN** the drawing for "22 Win. Mag. R.F." is generated (no E or E1)
- **THEN** the rim back face steps in to P1/2 at z = R and no groove is drawn

### Requirement: Body, shoulder and neck
A case with `alpha`, `L1` and `L2` published SHALL be drawn as a bottleneck: a straight body from P1/2 at the body start to (P2/2, L1), a shoulder from there to (H1/2, L2) with the body-side corner rounded by r1 min and the neck-side corner by r2 where published, and a neck from (H1/2, L2) to (H2/2, L3). Any other case SHALL be drawn as a straight body from P1/2 at the body start to (H2/2, L3).

#### Scenario: Bottleneck
- **WHEN** the drawing for "6,5 x 55 SE" is generated
- **THEN** the shoulder runs from (P2/2, L1) to (H1/2, L2) and the neck to (H2/2, L3)

#### Scenario: Straight case
- **WHEN** the drawing for "9 mm Luger" is generated (no alpha, L1 or L2)
- **THEN** the body runs straight from P1/2 to (H2/2, L3)

#### Scenario: Shoulder angle
- **WHEN** the shoulder is drawn for a case with `alpha` 46
- **THEN** the shoulder line lies at 23° to the axis, so that its included angle is 46°

### Requirement: Bullet
The bullet SHALL be drawn from its base to the tip at z = L6 with shank diameter G1, and its nose shape SHALL be taken from `annotations.defaultBulletShape`.

#### Scenario: Pointy 308 bullet
- **WHEN** the bullet of "308 Win." is drawn
- **THEN** the base is at z = 51.18 − 7.85 and the cylinder ends at zb + 0.40·Lb

### Requirement: Bullet seating depth and cylinder
The seating depth s below the mouth SHALL be 1.0·G1 for pointy, 0.8·G1 for rounded or flat on rifle and rimfire cartridges, 0.4·G1 for rounded or flat on pistol cartridges, and 0.6·G1 for semi-wadcutter. The base SHALL sit at zb = L3 − s. The cylinder SHALL run from the base to zb + k·Lb, where Lb = L6 − zb and k is 0.40 pointy, 0.55 rounded rifle or rimfire, 0.65 rounded pistol, 0.60 flat rifle or rimfire, 0.70 flat pistol and 0.78 semi-wadcutter.

#### Scenario: Rounded pistol seating
- **WHEN** the bullet of "9 mm Luger" is drawn (rounded, pistol)
- **THEN** s is 0.4·G1 and the cylinder ends at zb + 0.65·Lb

#### Scenario: Rounded pistol bullet
- **WHEN** the bullet of "9 mm Luger" is drawn
- **THEN** s is 0.4·G1 and the nose is a quarter ellipse with flat tip of diameter 0.15·G1 at z = L6

### Requirement: Nose shapes
A pointy nose SHALL be a tangent ogive to a flat tip (meplat) of diameter m = max(0.08·G1, 1.27), with nose length n and arc radius ρ = ((G1/2 − m/2)² + n²) / (2·(G1/2 − m/2)). A rounded nose SHALL be a quarter ellipse to a meplat of 0.15·G1. A flat nose SHALL be a straight cone to a meplat of 0.55·G1. A semi-wadcutter nose SHALL be a straight cone to a meplat of 0.6·G1.

#### Scenario: Tangent ogive
- **WHEN** a pointy nose is drawn
- **THEN** the arc is tangent to the cylinder at its start and meets the meplat at z = L6

### Requirement: Heeled cases
When H2 − G1 is at most 0.015 mm, the case is heeled. The exposed bullet SHALL then have the case's outside diameter H2, and the seated heel SHALL have the case's inside diameter H2 − 2·tb.

#### Scenario: 22 Long Rifle heel
- **WHEN** the drawing for "22 Long Rifle" is generated
- **THEN** the exposed bullet diameter is 5.72 mm and the seated heel diameter is 5.72 − 2·tb

### Requirement: Section walls
The neck wall SHALL be tn = (H2 − G1)/2 and the body wall SHALL be tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner profile SHALL follow the outer profile at these walls: tb along the body, tn along the neck, blended linearly across the shoulder. The solid head SHALL run from the head face to z = w, where w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or the belt ramp end + tb on belted cases).

#### Scenario: Head length
- **WHEN** the section of "223 Rem." is generated
- **THEN** the solid head ends at z = max(2.5, 1.2, 4.54, 3.73) = 4.54

### Requirement: Primer pocket
Centrefire cases SHALL have a primer pocket in the solid head of diameter 4.45 mm (types sp, spm, sr) or 5.33 mm (lp, lpm, lr, lrm) and depth 3.04 mm (sp, spm, sr, lp, lpm) or 3.3 mm (lr, lrm). Rimfire cases SHALL have no pocket.

#### Scenario: Pocket
- **WHEN** the section of "9 mm Luger" (primer type sp) is generated
- **THEN** the pocket is 4.45 mm in diameter and 3.04 mm deep

### Requirement: Outside view hides the seated bullet
The outside view SHALL show only the part of the bullet beyond the mouth. The section SHALL show the seated part inside the case.

#### Scenario: Seated bullet
- **WHEN** the section of "308 Win." is generated
- **THEN** the seated part of the bullet, from its base to the mouth, appears in the section only

### Requirement: Dimension lines
The drawing SHALL include dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value (for example "L3 51.18"), and the tolerance SHALL follow the value as in the detail view (for example "L1 39.62 -0.2").

#### Scenario: Labelled dimensions
- **WHEN** the drawing for "308 Win." is generated
- **THEN** a dimension labelled "L3 51.18" spans the case length from the head face to the mouth

#### Scenario: Optional dimensions only when published
- **WHEN** the drawing for "9 mm Luger" is generated (no alpha, no L1)
- **THEN** no dimension labelled α or L1 is drawn

### Requirement: Labels do not collide
No dimension label SHALL overlap another label or the drawn outline, and labels SHALL lie within the drawing's bounds.

#### Scenario: Automatic check
- **WHEN** the drawing is generated for each of the 25 cartridges
- **THEN** the labels' estimated bounding boxes overlap neither each other nor the outline segments

### Requirement: Title block
The drawing SHALL include a title block with the cartridge's name, its C.I.P. table and revised date, the text "Dimensions in mm", and the scale.

#### Scenario: Title block content
- **WHEN** the drawing for "45 Auto" is generated
- **THEN** the title block shows "45 Auto", C.I.P. table "IV", revised "2020-04-21", "Dimensions in mm" and the scale

### Requirement: Missing values are reported
If a value that a rule needs is missing, the feature SHALL be drawn without that feature, and the drawing's notes SHALL name the missing value. No number SHALL be invented.

#### Scenario: Missing P2
- **WHEN** a record has alpha and L1 but no P2
- **THEN** the case is drawn as a straight body and the notes state that P2 is missing

### Requirement: Print and scaling
The drawing SHALL scale to the width of a phone screen on screen, and SHALL print legibly at full page width on A4 paper.

#### Scenario: Phone width
- **WHEN** the drawing is shown at 360 px width
- **THEN** the drawing fits the width of the viewport without horizontal scrolling
