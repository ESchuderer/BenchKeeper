# Spec Delta

## Purpose

Defines how the reference is delivered: static files only, usable straight from disk in Chromium and from any static file server, with no network access and no build step needed to run it.

## ADDED Requirements

### Requirement: Runs from disk
The application SHALL work fully when `index.html` is opened directly from the file system in Chromium (a `file://` address), without a web server. Its data SHALL be bundled with the application rather than fetched at run time.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened from disk in Chromium
- **THEN** the start page lists all 25 cartridges and every detail view renders

### Requirement: Runs from any static server
The same files SHALL work when the project folder is served by any static file server, with no server-side code.

#### Scenario: Served folder
- **WHEN** the project folder is served by a static file server
- **THEN** the start page and detail views behave as they do from disk

### Requirement: No network requests and no runtime dependencies
The application SHALL make no network requests at run time: no CDN scripts, web fonts, analytics or remote images. It SHALL have no runtime dependency and no build step. Development tools MAY be listed as development dependencies and SHALL NOT be needed to run the application.

#### Scenario: Network silence
- **WHEN** the application is loaded and used
- **THEN** no request is made to any host other than the page's own files

### Requirement: Plain web files
The application SHALL consist of `index.html` together with its CSS and JavaScript files, written in plain HTML, CSS and JavaScript without a framework. Its interface text SHALL be English.

#### Scenario: Entry point
- **WHEN** the repository is inspected
- **THEN** `index.html` in the project root references the CSS and JavaScript files it needs

### Requirement: Print styling
The application's print styles SHALL hide navigation, search, the family filter and buttons, and SHALL use black on white throughout, regardless of the system colour scheme.

#### Scenario: Print styles
- **WHEN** the page is printed while the system uses a dark scheme
- **THEN** the printed page is black text on a white background

### Requirement: Automated checks
The project SHALL provide an automated test command that checks the geometry, formatting and listing behaviour without needing a browser.

#### Scenario: Test command
- **WHEN** the test command is run in the project folder
- **THEN** the unit tests run and report pass or fail
