# Tasks

## 1. Scaffolding and data

- [x] 1.1 Create `package.json` (private, `test` script running `node --test test/`, no runtime dependencies), `index.html` shell, `css/app.css` and `js/` folder; verify `npm test` runs and exits 0 with no tests
- [x] 1.2 Embed the 25 supplied records unchanged in `js/cartridges-data.js` as a classic script; verify with a test that there are 25 records, the names and keys match the brief in order, and every JSON object parses with its original field values

## 2. Value formatting (`js/format.js`)

- [x] 2.1 Test first, then implement: number display as published (`4150`, `51.18`, no separators); angle display (`40°`, `3°10'36"`, `1°30'00"`); tolerance pairing (`39.62 -0.2`); symbol map (`eMin` → "e min", `beta` → "β", `L3PlusG` → "L3 + G", and the rest); unit map by field; verify all these tests pass under `npm test`

## 3. Browse logic (`js/browse.js`)

- [x] 3.1 Test first, then implement: alphabetical sort with numeric collation; search matching `name` and `alternativeNames` (case-insensitive, whitespace-insensitive, so "7,62 x 51" finds "308 Win."); family filter with "All"; combined filters; count text with singular for 1; route parsing (`#/` and `#/cartridge/<key>`, unknown key); verify the tests pass

## 4. Geometry (`js/geometry.js`)

- [x] 4.1 Test first, then implement the profile pieces: rim type; head face (chamfer, square, rimfire half-round); extractor groove (plain and belted); body, shoulder with r1 min and r2 fillets, neck; straight case; verify the tests for "223 Rem.", "300 Win. Mag.", "22 Win. Mag. R.F.", "9 mm Luger" and "6,5 x 55 SE" match hand-calculated values
- [x] 4.2 Test first, then implement the bullet: seating depth, cylinder end, pointy/rounded/flat/semi-wadcutter noses with meplat sizes, heeled exposed and seated radii; verify the "308 Win." pointy bullet numbers and the "9 mm Luger" rounded nose
- [x] 4.3 Test first, then implement walls (tn, tb, inner profile, w), primer pocket, and the missing-value notes; verify "223 Rem." head length 4.54 and the pocket of "9 mm Luger"; verify that a record with alpha but no P2 is drawn straight and listed in the notes
- [x] 4.4 Test that all 25 records produce finite, non-empty outline, section and bullet profiles with no NaN, and that every listed missing value appears in the notes

## 5. Drawing SVG (`js/drawing.js`)

- [x] 5.1 Test first, then implement the dimension set (L3, L6, R1, R, P1 always; P2, H1, H2, G1, L1, L2, E1, α when published) with arrowheads, extension lines, and labels in the form "L3 51.18" and "L1 39.62 -0.2"; verify dimension labels for "308 Win." and that "9 mm Luger" has no α or L1
- [x] 5.2 Test first, then implement label placement that avoids other labels, dimension lines and the outline; verify automatically for all 25 records that no estimated label box overlaps another or an outline segment, and that every label lies inside the viewBox
- [x] 5.3 Implement the SVG assembly: accessible name "<name> drawing", viewBox in mm, hatch pattern for the section, dash-dot centre line, title block (name, C.I.P. table, revised date, "Dimensions in mm", scale), notes line; verify with a test that the SVG string contains the accessible name, the title block text and the centre line for every record

## 6. App shell, styles and documentation

- [x] 6.1 Implement `js/app.js`: start page (heading, Search and Family controls with labels, count text, list of links with family and L3); detail view (heading, identification fields, water capacity with source link, drawing, tables grouped by section with Symbol/Value/Unit columns, Print button, "All cartridges" link); hash routing and "Cartridge not found"; verify by loading `index.html` from `file://` in a browser and checking the list count and one detail view
- [x] 6.2 Implement `css/app.css`: dense technical typography with tabular numbers; light and dark via `prefers-color-scheme`; phone layout with no horizontal page scroll at 360 px; print styles (A4 portrait, black on white, navigation and buttons hidden, two-column tables, footer "Source: C.I.P. TDCC, revised <date>"); verify with a 360 px screenshot and a print-to-PDF page count of 1 for each record
- [x] 6.3 Write `README.md`: how to open the app (double-click `index.html`), how to serve it, how to run `npm test`, and the geometry assumptions (straight-case wall blend, rimfire flanks, missing-value notes); verify the commands in it run as written

## 7. Integration verification

- [ ] 7.1 Verify in Chromium from `file://` with no console errors and no network requests other than the page's own files: list count 25, search and family filters, a bookmark-style reload of a detail view, the unknown-key page, and the Print button calling the print dialog
- [ ] 7.2 Review the drawings of all 25 records visually at desktop and phone widths and fix any label collisions or clipped labels found; verify with screenshots

## Workflow follow-up

- Archive the change after the review findings are addressed.
