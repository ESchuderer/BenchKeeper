'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const B = require('../js/browse.js');
const CARTRIDGES = require('../js/cartridges-data.js');

const names = (list) => list.map((c) => c.name);

test('the list is sorted by name with numeric collation', () => {
  const sorted = names(B.sortCartridges(CARTRIDGES));
  assert.equal(sorted.length, 25);
  assert.equal(sorted[0], '6,5 Creedmoor');
  assert.equal(sorted[sorted.length - 1], '357 Magnum');
  assert.ok(sorted.indexOf('6,5 Creedmoor') < sorted.indexOf('7 x 64'), 'numeric order: 6 before 7');
  assert.ok(sorted.indexOf('22 Long Rifle') < sorted.indexOf('30-06 Spring.'), 'numeric order: 22 before 30');
  assert.deepEqual(names(CARTRIDGES).slice(0, 2), ['223 Rem.', '243 Win.'], 'sorting does not reorder the source');
});

test('search finds a cartridge by an alternative name', () => {
  const found = B.filterCartridges(CARTRIDGES, { query: '7,62 x 51', family: 'All' });
  assert.deepEqual(names(found), ['308 Win.']);
});

test('search ignores letter case', () => {
  assert.deepEqual(names(B.filterCartridges(CARTRIDGES, { query: 'CREEDMOOR', family: 'All' })), ['6,5 Creedmoor']);
});

test('search ignores whitespace differences', () => {
  assert.deepEqual(names(B.filterCartridges(CARTRIDGES, { query: '7,62x51', family: 'All' })), ['308 Win.']);
  assert.deepEqual(names(B.filterCartridges(CARTRIDGES, { query: '  308   win ', family: 'All' })), ['308 Win.']);
});

test('search also matches a name with alternative-name suffixes', () => {
  assert.deepEqual(names(B.filterCartridges(CARTRIDGES, { query: '30-06', family: 'All' })), ['30-06 Spring.']);
  assert.deepEqual(names(B.filterCartridges(CARTRIDGES, { query: '22 wmr', family: 'All' })), ['22 Win. Mag. R.F.']);
});

test('an empty search keeps every cartridge', () => {
  assert.equal(B.filterCartridges(CARTRIDGES, { query: '   ', family: 'All' }).length, 25);
});

test('no match gives an empty list', () => {
  assert.equal(B.filterCartridges(CARTRIDGES, { query: 'zzz', family: 'All' }).length, 0);
});

test('family filter lists only that family', () => {
  assert.deepEqual(
    names(B.filterCartridges(CARTRIDGES, { query: '', family: 'rimfire' })).sort(),
    ['17 HMR', '22 Long Rifle', '22 Win. Mag. R.F.'],
  );
  assert.equal(B.filterCartridges(CARTRIDGES, { query: '', family: 'belted' }).length, 2);
  assert.equal(B.filterCartridges(CARTRIDGES, { query: '', family: 'rimmed' }).length, 2);
  assert.equal(B.filterCartridges(CARTRIDGES, { query: '', family: 'pistol' }).length, 6);
  assert.equal(B.filterCartridges(CARTRIDGES, { query: '', family: 'rimless' }).length, 12);
});

test('family and search combine', () => {
  assert.deepEqual(names(B.filterCartridges(CARTRIDGES, { query: '308', family: 'rimless' })), ['308 Win.']);
  assert.deepEqual(names(B.filterCartridges(CARTRIDGES, { query: '308', family: 'pistol' })), []);
});

test('the family options are All and the five families', () => {
  assert.deepEqual(B.FAMILY_OPTIONS, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('count text reads "<n> cartridges" and the singular for one', () => {
  assert.equal(B.countText(25), '25 cartridges');
  assert.equal(B.countText(0), '0 cartridges');
  assert.equal(B.countText(1), '1 cartridge');
});

test('routes: the start page and detail addresses', () => {
  assert.deepEqual(B.parseRoute(''), { view: 'list' });
  assert.deepEqual(B.parseRoute('#'), { view: 'list' });
  assert.deepEqual(B.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(B.parseRoute('#/cartridge/308_win'), { view: 'detail', key: '308_win' });
  assert.deepEqual(B.parseRoute('#/unknown/thing'), { view: 'list' });
});

test('a detail address round-trips through routeHash', () => {
  const hash = B.routeHash('9_mm_luger');
  assert.equal(hash, '#/cartridge/9_mm_luger');
  assert.deepEqual(B.parseRoute(hash), { view: 'detail', key: '9_mm_luger' });
});

test('route keys are decoded, so an encoded key still matches', () => {
  assert.deepEqual(B.parseRoute('#/cartridge/22%5Flong_rifle'), { view: 'detail', key: '22_long_rifle' });
});
