'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const CARTRIDGES = require('../js/cartridges-data.js');

// Expected names and keys, in the order the records were supplied.
const EXPECTED = [
  ['223 Rem.', '223_rem'],
  ['243 Win.', '243_win'],
  ['6,5 Creedmoor', '6_5_creedmoor'],
  ['6,5 x 55 SE', '6_5_x_55_se'],
  ['270 Win.', '270_win'],
  ['7 x 64', '7_x_64'],
  ['308 Win.', '308_win'],
  ['30-06 Spring.', '30_06_spring'],
  ['8 x 57 IS', '8_x_57_is'],
  ['9,3 x 62', '9_3_x_62'],
  ['7,62 x 39', '7_62_x_39'],
  ['338 Lapua Mag.', '338_lapua_mag'],
  ['300 Win. Mag.', '300_win_mag'],
  ['7 mm Rem. Mag.', '7_mm_rem_mag'],
  ['9,3 x 74 R', '9_3_x_74_r'],
  ['7 x 65 R', '7_x_65_r'],
  ['9 mm Luger', '9_mm_luger'],
  ['45 Auto', '45_auto'],
  ['40 S.& W.', '40_s_w'],
  ['38 Special', '38_special'],
  ['357 Magnum', '357_magnum'],
  ['44 Rem. Mag.', '44_rem_mag'],
  ['22 Long Rifle', '22_long_rifle'],
  ['22 Win. Mag. R.F.', '22_win_mag_r_f'],
  ['17 HMR', '17_hmr'],
];

test('the data set holds the 25 supplied records in order', () => {
  assert.equal(CARTRIDGES.length, 25);
  assert.deepEqual(CARTRIDGES.map((c) => [c.name, c.key]), EXPECTED);
});

test('every record has the top-level fields the app reads', () => {
  for (const record of CARTRIDGES) {
    assert.equal(typeof record.name, 'string', record.key);
    assert.equal(typeof record.family, 'string', record.key);
    assert.equal(typeof record.tab, 'string', record.key);
    assert.equal(typeof record.country, 'string', record.key);
    assert.equal(typeof record.published, 'string', record.key);
    assert.equal(typeof record.revised, 'string', record.key);
    assert.equal(typeof record.pressureMethod, 'string', record.key);
    assert.ok(record.cartridge && record.chamber && record.annotations, record.key);
  }
});

test('spot-check published values against the supplied records', () => {
  const byKey = Object.fromEntries(CARTRIDGES.map((c) => [c.key, c]));
  const rifle308 = byKey['308_win'];
  assert.equal(rifle308.cartridge.lengths.L3, 51.18);
  assert.equal(rifle308.cartridge.lengths.L1Tol, -0.2);
  assert.equal(rifle308.cartridge.projectile.G1, 7.85);
  assert.equal(rifle308.cartridge.pressures.Pmax, 4150);
  assert.deepEqual(rifle308.alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.deepEqual(byKey['223_rem'].cartridge.caseHead.alpha, undefined);
  assert.equal(byKey['223_rem'].cartridge.junctionCone.alpha, 46);
  assert.deepEqual(byKey['223_rem'].chamber.rifling.i, { degrees: 3, minutes: 10, seconds: 36 });
  assert.equal(byKey['22_long_rifle'].cartridge.collar.H2, 5.72);
  assert.equal(byKey['300_win_mag'].cartridge.caseHead.R3, 13.51);
  assert.equal(byKey['9_3_x_74_r'].cartridge.caseHead.RTol, -0.25);
});
