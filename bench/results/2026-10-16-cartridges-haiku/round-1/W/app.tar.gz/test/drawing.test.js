'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../js/drawing.js');
const CARTRIDGES = require('../js/cartridges-data.js');

const byKey = Object.fromEntries(CARTRIDGES.map((c) => [c.key, c]));

test('the SVG has the accessible name, a viewBox in mm and the centre line', () => {
  const svg = D.renderDrawing(byKey['9_mm_luger']);
  assert.match(svg, /<svg[^>]*role="img"/);
  assert.match(svg, /aria-label="9 mm Luger drawing"/);
  assert.match(svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/);
  assert.match(svg, /class="centre-line"/);
});

test('dimension labels carry the symbol and the value, with tolerance beside it', () => {
  const labels = D.layoutDrawing(byKey['308_win']).labels.map((l) => l.text);
  assert.ok(labels.includes('L3 51.18'), labels.join(' | '));
  assert.ok(labels.includes('L6 71.12'));
  assert.ok(labels.includes('L1 39.62 -0.2'));
  assert.ok(labels.includes('L2 43.48 -0.2'));
  assert.ok(labels.includes('R1 12.01'));
  assert.ok(labels.includes('G1 7.85'));
  assert.ok(labels.includes('α 40°'));
  assert.ok(labels.includes('H2 8.72'));
  assert.ok(labels.includes('P1 11.96'));
});

test('optional dimensions appear only when published', () => {
  const labels = D.layoutDrawing(byKey['9_mm_luger']).labels.map((l) => l.text);
  assert.ok(!labels.some((t) => t.startsWith('α')), labels.join(' | '));
  assert.ok(!labels.some((t) => t.startsWith('L1 ')));
  assert.ok(!labels.some((t) => t.startsWith('H1 ')));
  assert.ok(labels.some((t) => t.startsWith('L3 ')));
});

test('the title block carries name, C.I.P. table, revised date, units and scale', () => {
  const svg = D.renderDrawing(byKey['45_auto']);
  assert.match(svg, />45 Auto</);
  assert.match(svg, /C\.I\.P\. table IV/);
  assert.match(svg, /revised 2020-04-21/);
  assert.match(svg, /Dimensions in mm/);
  assert.match(svg, /Scale 1:1/);
});

test('a missing value is named in the notes and nothing is invented', () => {
  const rec = JSON.parse(JSON.stringify(byKey['308_win']));
  delete rec.cartridge.powderChamber.P2;
  const layout = D.layoutDrawing(rec);
  assert.ok(layout.notes.some((n) => /P2/.test(n)), layout.notes.join(' | '));
  assert.ok(!layout.labels.some((l) => /^P2 /.test(l.text)), 'P2 is not labelled when missing');
});

test('labels never overlap each other, the outline or the dimension lines, for all 25 records', () => {
  for (const record of CARTRIDGES) {
    const layout = D.layoutDrawing(record);
    const problems = D.findLabelCollisions(layout);
    assert.deepEqual(problems, [], `${record.key}: ${problems.join('; ')}`);
  }
});

test('every label lies inside the viewBox for all 25 records', () => {
  for (const record of CARTRIDGES) {
    const layout = D.layoutDrawing(record);
    const b = layout.viewBox;
    for (const l of layout.labels) {
      assert.ok(l.box.x0 >= b.x && l.box.x1 <= b.x + b.w && l.box.y0 >= b.y && l.box.y1 <= b.y + b.h,
        `${record.key}: ${l.text} outside viewBox`);
    }
  }
});

test('every record renders an SVG with the drawing name', () => {
  for (const record of CARTRIDGES) {
    const svg = D.renderDrawing(record);
    const escaped = record.name.replace(/&/g, '&amp;');
    assert.ok(svg.includes(`aria-label="${escaped} drawing"`), record.key);
    assert.ok(svg.includes('Dimensions in mm'), record.key);
    assert.ok(!/NaN|Infinity/.test(svg), `${record.key} contains NaN`);
  }
});

test('the drawing is built from the same geometry as the tests of the geometry module', () => {
  const layout = D.layoutDrawing(byKey['223_rem']);
  assert.ok(layout.labels.some((l) => l.text === 'L3 44.7'));
  assert.ok(layout.labels.some((l) => l.text === 'R 1.14'));
});
