'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../js/format.js');
const CARTRIDGES = require('../js/cartridges-data.js');

const byKey = Object.fromEntries(CARTRIDGES.map((c) => [c.key, c]));

test('numbers are shown as published, with no thousands separator', () => {
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(4150.0), '4150');
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(-0.2), '-0.2');
  assert.equal(F.formatNumber(0.0), '0');
});

test('angles: a number shows as degrees, an object as degrees minutes seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(46.0), '46°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'00"');
  assert.equal(F.formatAngle({ degrees: 0, minutes: 47, seconds: 33 }), '0°47\'33"');
});

test('formatValue uses angle form for the angle fields only', () => {
  assert.equal(F.formatValue('alpha', 46), '46°');
  assert.equal(F.formatValue('i', { degrees: 1, minutes: 0, seconds: 5 }), '1°00\'05"');
  assert.equal(F.formatValue('L1', 36.52), '36.52');
});

test('symbols use the display forms given in the brief', () => {
  assert.equal(F.symbolFor('eMin'), 'e min');
  assert.equal(F.symbolFor('r1Min'), 'r1 min');
  assert.equal(F.symbolFor('r1Max'), 'r1 max');
  assert.equal(F.symbolFor('alpha'), 'α');
  assert.equal(F.symbolFor('alpha1'), 'α1');
  assert.equal(F.symbolFor('beta'), 'β');
  assert.equal(F.symbolFor('delta'), 'δ');
  assert.equal(F.symbolFor('deltaL'), 'delta L');
  assert.equal(F.symbolFor('L3PlusG'), 'L3 + G');
  assert.equal(F.symbolFor('E1'), 'E1');
  assert.equal(F.symbolFor('G1'), 'G1');
  assert.equal(F.symbolFor('Fe'), 'Fe');
});

test('units follow the brief: mm by default, bar, J, g, mm², blank for angles and counts', () => {
  assert.equal(F.unitFor('lengths', 'L1'), 'mm');
  assert.equal(F.unitFor('caseHead', 'R1'), 'mm');
  assert.equal(F.unitFor('pressures', 'Pmax'), 'bar');
  assert.equal(F.unitFor('pressures', 'PK'), 'bar');
  assert.equal(F.unitFor('pressures', 'PE'), 'bar');
  assert.equal(F.unitFor('pressures', 'EE'), 'J');
  assert.equal(F.unitFor('pressures', 'M'), 'g');
  assert.equal(F.unitFor('grooves', 'Q'), 'mm²');
  assert.equal(F.unitFor('grooves', 'N'), '');
  assert.equal(F.unitFor('junctionCone', 'alpha'), '');
  assert.equal(F.unitFor('rifling', 'alpha1'), '');
  assert.equal(F.unitFor('rifling', 'i'), '');
  assert.equal(F.unitFor('caseHead', 'beta'), '');
});

test('tolerance is paired to its value; no row is created for a Tol field', () => {
  const rows = F.sectionRows(byKey['308_win'].cartridge.lengths, 'lengths');
  const l1 = rows.find((r) => r.field === 'L1');
  assert.equal(l1.value, '39.62 -0.2');
  assert.equal(l1.symbol, 'L1');
  assert.equal(l1.unit, 'mm');
  assert.ok(!rows.some((r) => r.field === 'L1Tol' || r.symbol.includes('Tol')));
});

test('an orphan tolerance with no base value is never shown as a row', () => {
  const rows = F.sectionRows({ RTol: -0.25, R: 1.4 }, 'caseHead');
  assert.deepEqual(rows.map((r) => r.field), ['R']);
  assert.equal(rows[0].value, '1.4 -0.25');
});

test('sections: cartridge and chamber groups list every section present, in order', () => {
  const groups = F.buildSections(byKey['223_rem']);
  assert.deepEqual(groups.cartridge.map((s) => s.title), [
    'Case head', 'Collar', 'Junction cone', 'Lengths', 'Misc', 'Powder chamber', 'Pressures', 'Projectile',
  ]);
  assert.deepEqual(groups.chamber.map((s) => s.title), [
    'Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling',
  ]);
});

test('sections hold every value of the record and no value that is absent', () => {
  const groups = F.buildSections(byKey['9_3_x_74_r']);
  const caseHead = groups.cartridge.find((s) => s.title === 'Case head');
  assert.deepEqual(caseHead.rows.map((r) => r.field), ['R', 'R1', 'beta', 'f']);
  const shown = [...groups.cartridge, ...groups.chamber].flatMap((s) => s.rows.map((r) => r.field));
  assert.ok(!shown.includes('E'), 'E is absent from this record');
  assert.ok(!shown.includes('L4'), 'L4 is absent from this record');
  assert.ok(shown.includes('L3'), 'L3 is published for this record');
});

test('L4 and L5 are shown when a record publishes them', () => {
  const groups = F.buildSections(byKey['7_x_64']);
  const lengths = groups.cartridge.find((s) => s.title === 'Lengths');
  assert.ok(lengths.rows.some((r) => r.field === 'L4' && r.value === '70.4' && r.unit === 'mm'));
});

test('pressure rows show their unit and value as published', () => {
  const groups = F.buildSections(byKey['308_win']);
  const pressures = groups.cartridge.find((s) => s.title === 'Pressures');
  const pmax = pressures.rows.find((r) => r.field === 'Pmax');
  assert.deepEqual(pmax, { field: 'Pmax', symbol: 'Pmax', value: '4150', unit: 'bar' });
});

test('water capacity line shows the value, its unit and the source link', () => {
  const cap = F.waterCapacity(byKey['223_rem']);
  assert.equal(cap.text, '30.5 grH2O');
  assert.equal(cap.source, 'kwk');
  assert.equal(cap.url, 'http://kwk.us/cases.html');
  assert.equal(cap.note, 'kwk 31, Wikipedia 28.8; the mean');
});

test('a record without a note returns an empty note', () => {
  assert.equal(F.waterCapacity(byKey['308_win']).note, 'Lapua brass measures 55.8 (lapua-308)');
  assert.equal(F.waterCapacity(byKey['9_mm_luger']).note, '');
});

test('a record that publishes no water capacity returns null', () => {
  assert.equal(F.waterCapacity(byKey['22_long_rifle']), null);
});

test('the print footer names the source and the revised date', () => {
  assert.equal(F.sourceLine(byKey['223_rem']), 'Source: C.I.P. TDCC, revised 2017-05-17');
});
