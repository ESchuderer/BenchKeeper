'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../js/geometry.js');
const CARTRIDGES = require('../js/cartridges-data.js');

const byKey = Object.fromEntries(CARTRIDGES.map((c) => [c.key, c]));
const geo = (key) => G.computeGeometry(byKey[key]);
const near = (actual, expected, tol = 0.001) => assert.ok(Math.abs(actual - expected) <= tol, `${actual} != ${expected}`);
const clone = (v) => JSON.parse(JSON.stringify(v));
const pointAt = (points, z) => points.find((p) => Math.abs(p.z - z) < 1e-9 && p.r !== undefined);

test('rim type follows the family first, then the R1/P1 ratio', () => {
  assert.equal(geo('223_rem').rimType, 'rimless');
  assert.equal(geo('9_3_x_74_r').rimType, 'rimmed');
  assert.equal(geo('300_win_mag').rimType, 'belted');
  assert.equal(geo('22_win_mag_r_f').rimType, 'rimfire');
  assert.equal(geo('38_special').rimType, 'rimmed', 'R1/P1 = 11.18/9.63 is at least 1.05');
});

test('rebated is R1/P1 below 0.98', () => {
  const rec = clone(byKey['223_rem']);
  rec.cartridge.caseHead.R1 = 9.0;
  assert.equal(G.computeGeometry(rec).rimType, 'rebated');
});

test('chamfered head: from (R1/2 - f·tan β, 0) to (R1/2, f) then up to R, for 308 Win.', () => {
  const g = geo('308_win');
  const r1h = 12.01 / 2;
  near(g.outer[1].z, 0);
  near(g.outer[1].r, r1h - 0.38 * Math.tan(35 * Math.PI / 180));
  near(g.outer[2].z, 0.38);
  near(g.outer[2].r, r1h);
  near(g.outer[3].z, 1.37);
  near(g.outer[3].r, r1h);
});

test('square head when beta is not published', () => {
  const rec = clone(byKey['308_win']);
  delete rec.cartridge.caseHead.beta;
  const g = G.computeGeometry(rec);
  near(g.outer[1].z, 0);
  near(g.outer[1].r, 12.01 / 2);
  near(g.outer[2].z, 1.37);
  near(g.outer[2].r, 12.01 / 2);
});

test('rimfire rim edge is a half-round of radius min(R/2, (R1-P1)/2) whose outermost point is at R1/2', () => {
  const g = geo('22_long_rifle');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const outermost = Math.max(...g.outer.map((p) => p.r));
  near(outermost, 7.06 / 2, 1e-6);
  const arcTop = g.outer.find((p) => Math.abs(p.r - 7.06 / 2) < 1e-6);
  near(arcTop.z, 1.09 / 2, 1e-6);
  assert.ok(g.outer.some((p) => Math.abs(p.z - (1.09 / 2 - rho)) < 1e-6 && Math.abs(p.r - (7.06 / 2 - rho)) < 1e-6));
});

test('extractor groove: floor at E1/2 between R and R + eMin, then ramp to P1/2 at z = E (223 Rem.)', () => {
  const g = geo('223_rem');
  near(pointAt(g.outer, 1.14).r, 9.6 / 2);
  assert.ok(g.outer.some((p) => Math.abs(p.z - 1.14) < 1e-9 && Math.abs(p.r - 8.43 / 2) < 1e-9));
  assert.ok(g.outer.some((p) => Math.abs(p.z - (1.14 + 0.76)) < 1e-9 && Math.abs(p.r - 8.43 / 2) < 1e-9));
  assert.ok(g.outer.some((p) => Math.abs(p.z - 3.13) < 1e-9 && Math.abs(p.r - 9.58 / 2) < 1e-9));
});

test('belted groove: the ramp leaves the floor at δ to the axis and reaches the belt R3/2 (300 Win. Mag.)', () => {
  const g = geo('300_win_mag');
  const dz = (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  const zBelt = 1.27 + 0.94 + dz;
  assert.ok(g.outer.some((p) => Math.abs(p.z - zBelt) < 1e-6 && Math.abs(p.r - 13.51 / 2) < 1e-6));
  assert.ok(g.outer.some((p) => Math.abs(p.z - 5.59) < 1e-9 && Math.abs(p.r - 13.51 / 2) < 1e-9), 'belt runs to z = E');
  assert.ok(g.outer.some((p) => Math.abs(p.z - 5.59) < 1e-9 && Math.abs(p.r - 13.03 / 2) < 1e-9), 'then steps in to P1/2');
});

test('no groove: the rim back steps in to P1/2 at z = R (22 Win. Mag. R.F.)', () => {
  const g = geo('22_win_mag_r_f');
  assert.ok(g.outer.some((p) => Math.abs(p.z - 1.27) < 1e-9 && Math.abs(p.r - 6.15 / 2) < 1e-9));
  assert.ok(g.notes.every((n) => !/groove/.test(n)), 'no groove note for a rimfire record with no E');
});

test('bottleneck: body to (P2/2, L1), shoulder to (H1/2, L2), neck to (H2/2, L3) (6,5 x 55 SE)', () => {
  const rec = byKey['6_5_x_55_se'].cartridge;
  const g = geo('6_5_x_55_se');
  assert.equal(g.bottleneck, true);
  near(g.points.shoulderStart.z, rec.lengths.L1, 1e-9);
  near(g.points.shoulderStart.r, rec.powderChamber.P2 / 2, 1e-9);
  near(g.points.shoulderEnd.z, rec.lengths.L2, 1e-9);
  near(g.points.shoulderEnd.r, rec.collar.H1 / 2, 1e-9);
  const mouth = g.outer[g.outer.length - 1];
  near(mouth.z, rec.lengths.L3, 1e-9);
  near(mouth.r, rec.collar.H2 / 2, 1e-9);
});

test('shoulder included angle equals the published alpha (223 Rem.: 46°)', () => {
  const g = geo('223_rem');
  near(g.shoulderHalfAngleDeg * 2, 46, 0.05);
});

test('a case without alpha, L1 or L2 is straight to (H2/2, L3) (9 mm Luger)', () => {
  const g = geo('9_mm_luger');
  assert.equal(g.bottleneck, false);
  const last = g.outer[g.outer.length - 1];
  near(last.z, 19.15);
  near(last.r, 9.65 / 2);
});

test('a bottleneck record missing P2 is drawn straight and the note names P2', () => {
  const rec = clone(byKey['308_win']);
  delete rec.cartridge.powderChamber.P2;
  const g = G.computeGeometry(rec);
  assert.equal(g.bottleneck, false);
  assert.ok(g.notes.some((n) => /P2/.test(n)), g.notes.join(' | '));
});

test('bullet seating: base at L3 − 1.0·G1 for pointy, cylinder ends at zb + 0.40·Lb (308 Win.)', () => {
  const b = geo('308_win').bullet;
  near(b.s, 7.85);
  near(b.zb, 51.18 - 7.85);
  near(b.Lb, 71.12 - (51.18 - 7.85));
  near(b.zc, b.zb + 0.4 * b.Lb);
  near(b.m, 1.27, 1e-9);
});

test('rounded pistol bullet: s = 0.4·G1, cylinder to zb + 0.65·Lb, meplat 0.15·G1 (9 mm Luger)', () => {
  const b = geo('9_mm_luger').bullet;
  near(b.s, 0.4 * 9.03);
  near(b.zc, b.zb + 0.65 * b.Lb);
  near(b.m, 0.15 * 9.03);
  const exposed = b.exposed;
  const tip = exposed[exposed.length - 2];
  near(tip.z, 29.69);
  near(tip.r, b.m / 2, 1e-9);
});

test('pointy nose is a tangent ogive ending at the meplat at z = L6', () => {
  const b = geo('308_win').bullet;
  const last = b.exposed[b.exposed.length - 2];
  near(last.z, 71.12, 1e-9);
  near(last.r, 1.27 / 2, 1e-6);
  const n = 71.12 - b.zc;
  const d = 7.85 / 2 - 1.27 / 2;
  const rho = (d * d + n * n) / (2 * d);
  const x = b.exposed.find((p) => p.z > b.zc + 1e-6 && p.z < b.zc + n - 1e-6);
  near(Math.hypot(x.z - b.zc, x.r - (7.85 / 2 - rho)), rho, 1e-3);
});

test('heeled case: 22 Long Rifle exposes the case OD and seats the inside-diameter heel', () => {
  const g = geo('22_long_rifle');
  assert.equal(g.heeled, true);
  near(g.tn, 0);
  near(g.tb, 0.6);
  near(g.bullet.rSeat, 5.72 / 2 - 0.6);
  near(g.bullet.Rc, 5.72 / 2);
  near(g.bullet.zb, 15.57 - 0.8 * 5.72);
});

test('wall thickness: tn = (H2 − G1)/2 and tb = min(max(1.3·tn, 0.6), 0.35·P1/2) (223 Rem.)', () => {
  const g = geo('223_rem');
  near(g.tn, (6.43 - 5.7) / 2);
  near(g.tb, 0.6);
});

test('solid head length w = max(2.5, P1/8, pocket depth + 1.5, E + tb) (223 Rem. -> 4.54)', () => {
  near(geo('223_rem').w, 4.54);
});

test('solid head length uses the belt ramp end + tb on belted cases', () => {
  const g = geo('300_win_mag');
  const dz = (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  near(g.w, Math.max(2.5, 13.03 / 8, 3.3 + 1.5, 1.27 + 0.94 + dz + g.tb));
});

test('primer pockets: sp 4.45 × 3.04, lp 5.33 × 3.04, lrm 5.33 × 3.3, rimfire none', () => {
  assert.deepEqual(geo('9_mm_luger').pocket, { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(geo('45_auto').pocket, { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(geo('300_win_mag').pocket, { diameter: 5.33, depth: 3.3 });
  assert.equal(geo('22_long_rifle').pocket, null);
});

test('every record gives finite profiles and no NaN, and every drawn record has a bullet', () => {
  for (const record of CARTRIDGES) {
    const g = G.computeGeometry(record);
    assert.equal(g.ok, true, `${record.key} should draw`);
    const all = [...g.outer, ...g.inner, ...g.section, ...g.bullet.full, ...g.bullet.exposed];
    for (const p of all) {
      assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r), `${record.key} non-finite point ${JSON.stringify(p)}`);
    }
    assert.ok(g.bullet.exposed.length > 2, record.key);
    assert.ok(Array.isArray(g.notes), record.key);
  }
});

test('a record missing a value the case needs is reported as not drawable, naming the value', () => {
  const rec = clone(byKey['308_win']);
  delete rec.cartridge.caseHead.R1;
  const g = G.computeGeometry(rec);
  assert.equal(g.ok, false);
  assert.deepEqual(g.missing, ['R1']);
});

test('missing bullet data is reported and the bullet is left out', () => {
  const rec = clone(byKey['308_win']);
  delete rec.cartridge.lengths.L6;
  const g = G.computeGeometry(rec);
  assert.equal(g.ok, true);
  assert.equal(g.bullet, null);
  assert.ok(g.notes.some((n) => /L6/.test(n)));
});

test('partially published groove reports the value that is missing', () => {
  const rec = clone(byKey['223_rem']);
  delete rec.cartridge.caseHead.E1;
  const g = G.computeGeometry(rec);
  assert.equal(g.groove, false);
  assert.ok(g.notes.some((n) => /E1/.test(n)), g.notes.join(' | '));
});
