Status: resolved
Type: task
Blocked by: none

# 01 Model

- Data file `js/cartridges.js`: the 25 JSONL lines, verbatim, parsed at load.
- `js/model.js`: number formatting, angle formatting (decimal and DMS), symbol and unit tables, tolerance merge, table groups, search and family filter, rim type.
- Tests first: `test/model.test.js`.
