Status: resolved
Type: task
Blocked by: 01

# 02 Geometry

- `js/geometry.js`: profile points (r, z) from the head face to the mouth, rim types, groove, body, shoulder fillets, neck, section walls, primer pocket, bullet with nose shapes, missing-value notes.
- Tests first: `test/geometry.test.js` (rule outputs for known records, bullet formulas, heeled case).
