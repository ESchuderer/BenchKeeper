Status: resolved
Type: task
Blocked by: 02

# 03 Drawing

- `js/drawing.js`: SVG string from the geometry. Outside view above the axis, hatched section below, dash-dot axis, dimension lines and arrowheads, label placement without overlaps, title block.
- Tests first: `test/drawing.test.js` (labels do not overlap each other or the outline; accessible name).
