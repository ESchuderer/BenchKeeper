Status: resolved
Type: task
Blocked by: 01, 03

# 04 App

- `index.html`, `css/app.css`, `js/app.js`: list view, detail view, hash routing, Print button, print CSS (A4 portrait, one page), dark mode via `prefers-color-scheme`.
- No network requests, no external fonts.
