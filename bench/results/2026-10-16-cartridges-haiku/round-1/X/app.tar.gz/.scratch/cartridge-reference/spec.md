# Cartridge reference (static app)

Static HTML/CSS/JS reference for 25 C.I.P. cartridges, modelled on OpenBallistics. Source brief: the task message that started this feature. Data: the 25 JSON lines (OpenBallistics, MIT, commit e83db43), used unchanged.

## Requirements

- List page: heading "Cartridges"; every cartridge with name link (text = `name`), family, L3. Search field (label "Search") matches name and alternative names, ignoring case and whitespace. Family select (label "Family": All, rimless, rimmed, belted, pistol, rimfire). Count text "<n> cartridges".
- Detail page at `#/cartridge/<key>` (survives reload, bookmarkable): name heading; alternative names, family, category, primer type, C.I.P. table, country, published, revised, pressure method, water capacity with source link; 2D drawing; cartridge and chamber tables (Symbol, Value, Unit) grouped by section; "Print" button; "All cartridges" link.
- Drawing: inline SVG, 1 user unit = 1 mm, head left, upper half outside view, lower half section with hatched cut walls, dash-dot axis, dimension lines with arrowheads, labels not overlapping each other or the outline, title block. Accessible name "<name> drawing".
- Print: A4 portrait, black on white, one page: header with name, drawing at full width, tables, footer "Source: C.I.P. TDCC, revised <date>". No navigation, search or buttons.
- Plain HTML/CSS/JS, no build step, no runtime dependencies, no network requests. Works from `file://` and from a static server.

## Decisions (made without a user answer)

- Data is embedded as a JS string of the JSONL lines and parsed at load. `fetch` of a JSON file does not work over `file://`.
- Routing is by `location.hash`.
- Numbers print with JavaScript's shortest form (`4150`, `0.1`, `5`), no trailing zeros.
- Angles: a number is `<n>°`; an object is `<d>°<mm>'<ss>"` with minutes and seconds zero-padded to two digits.
- Units: as in the brief for named units. `grH2O` unit shown as `gr H2O`. Other length-like fields (`G`, `s`, `b`, `h`, `u`, `Fe`) shown in mm; `u` read as twist length (305 mm ≈ 1:12 in). `N` has no unit.
- List sorted by name (numeric collation). Count reads "1 cartridge" for one.
- Tolerance fields `<X>Tol` appear in the value cell of X (`39.62 -0.2`), unit column unchanged.
- Drawing: radial dimensions are drawn across the feature with a flag leader to the label; z dimensions are rows above the outline. Label positions are chosen by a collision check (rectangles against outline, leaders and other labels).
- Rim type: family `belted` / `rimfire` as given, otherwise R1/P1 ratio. Only belted and rimfire branch the geometry.
- Water capacity absent: "not published".

## Tickets

- `issues/01-model.md`: data, formatting, symbols, units, table groups, search and family filter.
- `issues/02-geometry.md`: outer profile, section walls, primer pocket, bullet, notes for missing values.
- `issues/03-drawing.md`: SVG, dimensions, label placement, title block.
- `issues/04-app.md`: index.html, list view, detail view, routing, print CSS, dark mode.
- `issues/05-verify.md`: tests, browser checks, code review.

## Status

Implemented on branch `feat/cartridge-reference`. No GitHub remote: no issue, no pull request, no push. Review: code-review findings fixed.
