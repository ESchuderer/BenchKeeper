// Page logic: list view, detail view, hash routing, print.
(() => {
  const app = document.getElementById('app');
  const LIST = Model.sortByName(CARTRIDGES);

  function h(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [name, value] of Object.entries(props || {})) {
      if (value === undefined || value === false) continue;
      if (name === 'text') node.textContent = value;
      else node.setAttribute(name, value === true ? '' : value);
    }
    node.append(...children.filter((c) => c !== undefined && c !== false));
    return node;
  }

  function cartridgeItem(c) {
    return h('li', {},
      h('a', { href: `#/cartridge/${c.key}`, text: c.name }),
      ' ',
      h('span', { class: 'meta', text: c.family }),
      ' ',
      h('span', { class: 'meta', text: `L3 ${Model.valueOf(c.cartridge.lengths, 'L3')} mm` }));
  }

  function renderList() {
    document.title = 'Cartridges';
    const query = h('input', { id: 'q', type: 'search', autocomplete: 'off', spellcheck: 'false' });
    const family = h('select', { id: 'family' },
      ...Model.FAMILIES.map((f) => h('option', { value: f, text: f === 'all' ? 'All' : f })));
    const count = h('p', { class: 'count', 'aria-live': 'polite' });
    const items = h('ul', { class: 'cartridge-list' });
    const update = () => {
      const rows = Model.filterCartridges(LIST, { query: query.value, family: family.value });
      count.textContent = Model.countLabel(rows.length);
      items.replaceChildren(...rows.map(cartridgeItem));
    };
    query.addEventListener('input', update);
    family.addEventListener('change', update);
    update();
    app.replaceChildren(
      h('h1', { text: 'Cartridges' }),
      h('div', { class: 'filters', role: 'search' },
        h('label', { for: 'q', text: 'Search' }), query,
        h('label', { for: 'family', text: 'Family' }), family),
      count,
      items,
    );
  }

  function factRows(c) {
    const rows = [];
    if (c.alternativeNames) rows.push(['Alternative names', c.alternativeNames.join(', ')]);
    rows.push(['Family', c.family], ['Category', c.annotations.category], ['Primer type', c.annotations.primerType],
      ['C.I.P. table', c.tab], ['Country', c.country], ['Published', c.published], ['Revised', c.revised],
      ['Pressure method', c.pressureMethod]);
    return rows;
  }

  function waterCapacityDd(c) {
    const wc = Model.waterCapacity(c);
    if (!wc) return h('dd', { text: 'not published' });
    return h('dd', {},
      `${wc.value} ${wc.unit}`,
      wc.note ? ` (${wc.note})` : '',
      ' Source: ',
      h('a', { href: wc.url, target: '_blank', rel: 'noopener', text: wc.source }));
  }

  function tableSection(title, groups) {
    return h('section', { class: 'table-section' },
      h('h2', { text: title }),
      ...groups.map((g) => h('div', { class: 'group' },
        h('h3', { text: g.title }),
        h('table', {},
          h('thead', {}, h('tr', {},
            h('th', { scope: 'col', text: 'Symbol' }),
            h('th', { scope: 'col', text: 'Value' }),
            h('th', { scope: 'col', text: 'Unit' }))),
          h('tbody', {}, ...g.rows.map((r) => h('tr', {},
            h('td', { text: r.symbol }), h('td', { class: 'num', text: r.value }), h('td', { text: r.unit }))))))));
  }

  function renderDetail(key) {
    const c = CARTRIDGES.find((r) => r.key === key);
    if (!c) {
      document.title = 'Not found · Cartridges';
      app.replaceChildren(h('h1', { text: 'Cartridge not found' }), h('p', {}, h('a', { href: '#/', text: 'All cartridges' })));
      return;
    }
    document.title = `${c.name} · Cartridges`;
    const layout = Drawing.plan(c);
    const print = h('button', { type: 'button', text: 'Print' });
    print.addEventListener('click', () => window.print());
    const figure = h('figure', { class: 'drawing-figure' });
    figure.innerHTML = Drawing.svg(c, layout);
    const notes = [...layout.g.notes, ...layout.unplaced.map((t) => `label not placed: ${t}`)];
    app.replaceChildren(
      h('p', { class: 'toolbar no-print' }, h('a', { href: '#/', text: 'All cartridges' }), print),
      h('h1', { text: c.name }),
      h('dl', { class: 'facts' },
        ...factRows(c).flatMap(([term, value]) => [h('dt', { text: term }), h('dd', { text: value })]),
        h('dt', { text: 'Water capacity' }), waterCapacityDd(c)),
      figure,
      ...(notes.length ? [h('p', { class: 'notes', text: `Not drawn: ${notes.join('; ')}.` })] : []),
      h('div', { class: 'tables' },
        tableSection('Cartridge', Model.sectionTables(c, 'cartridge')),
        tableSection('Chamber', Model.sectionTables(c, 'chamber'))),
      h('p', { class: 'source', text: `Source: C.I.P. TDCC, revised ${c.revised}.` }),
    );
  }

  function route() {
    const match = /^#\/cartridge\/(.+)$/.exec(location.hash);
    let key = null;
    if (match) {
      try {
        key = decodeURIComponent(match[1]);
      } catch {
        key = match[1];
      }
    }
    if (key === null) renderList();
    else renderDetail(key);
    window.scrollTo(0, 0);
  }

  window.addEventListener('hashchange', route);
  route();
})();
