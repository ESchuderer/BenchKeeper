// SVG drawing of one cartridge, 1 user unit = 1 mm. Upper half: outside view. Lower half: section.
var Drawing = (() => {
  const FONT = 2.8;
  const CHAR_W = 0.6 * FONT;
  const CAP = 0.75 * FONT;
  const GAP = 0.8;
  const ROW_STEP = 3.2;
  const ROW_BASE = 3;
  const SHELVES = 14;
  const ARROW_LEN = 1.1;
  const ARROW_HALF = 0.4;
  const TITLE_W = 66;
  const TITLE_H = 15;

  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const n3 = (v) => Number(v.toFixed(3));
  const pathOf = (pts) => pts.map((p, i) => `${i ? 'L' : 'M'}${n3(p[0])} ${n3(p[1])}`).join(' ');
  const up = ([r, z]) => [z, -r];
  const down = ([r, z]) => [z, r];
  const segsOf = (pts) => pts.slice(1).map((p, i) => [pts[i][0], pts[i][1], p[0], p[1]]);

  // Text box for a label whose baseline is at (x, y).
  function textRect(text, x, y, anchor) {
    const w = text.length * CHAR_W;
    const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0: x0 - 0.2, x1: x0 + w + 0.2, y0: y - CAP - 0.2, y1: y + 0.5 };
  }

  function rectsOverlap(a, b) {
    return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
  }

  // Liang-Barsky test: does segment [x1, y1, x2, y2] touch rectangle R?
  function segHitsRect(s, R) {
    const [x1, y1, x2, y2] = s;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const p = [-dx, dx, -dy, dy];
    const q = [x1 - R.x0, R.x1 - x1, y1 - R.y0, R.y1 - y1];
    let t0 = 0;
    let t1 = 1;
    for (let i = 0; i < 4; i++) {
      if (p[i] === 0) {
        if (q[i] < 0) return false;
      } else {
        const t = q[i] / p[i];
        if (p[i] < 0) {
          if (t > t1) return false;
          if (t > t0) t0 = t;
        } else {
          if (t < t0) return false;
          if (t < t1) t1 = t;
        }
      }
    }
    return t0 <= t1;
  }

  // Arrowhead with its tip at `tip`, opening towards `inward` (unit vector into the dimension).
  function arrow(tip, inward) {
    const bx = tip[0] + inward[0] * ARROW_LEN;
    const by = tip[1] + inward[1] * ARROW_LEN;
    const px = -inward[1] * ARROW_HALF;
    const py = inward[0] * ARROW_HALF;
    return `M${n3(tip[0])} ${n3(tip[1])} L${n3(bx + px)} ${n3(by + py)} L${n3(bx - px)} ${n3(by - py)} Z`;
  }

  // Layout: geometry, dimension lines, labels with rectangles. Labels are placed by a collision check.
  function plan(record, geometry = Geometry.build(record)) {
    const g = geometry;
    const { caseHead: H, collar: Cl, junctionCone: J = {}, lengths: Ln, powderChamber: P, projectile: PR } = record.cartridge;
    const R1h = H.R1 / 2;
    const P1h = P.P1 / 2;
    const H2h = Cl.H2 / 2;
    const L3 = Ln.L3;
    const L6 = Ln.L6;
    const meplatHalf = g.bullet.meplat / 2;
    const Ro = Math.max(...g.outline.map((p) => p[0]), R1h);

    const wall = [...segsOf(g.outline.map(up)), ...segsOf(g.outline.map(down))];
    const segs = [];   // dimension and extension lines, then placed leaders
    const dimArrows = [];
    const texts = [];  // {text, x, y, anchor, rect}
    const unplaced = [];
    const rects = [];

    const hits = (rect) => wall.some((s) => segHitsRect(s, rect))
      || rects.some((r) => rectsOverlap(r, rect))
      || segs.some((s) => segHitsRect(s, rect));

    // Rows above the outline for longitudinal dimensions, nearest to the outline first.
    const zDims = [];
    if (H.R !== undefined) zDims.push({ text: `R ${Model.valueOf(H, 'R')}`, a: 0, b: H.R, yb: -R1h });
    if (g.shoulder) {
      zDims.push({ text: `L1 ${Model.valueOf(Ln, 'L1')}`, a: 0, b: Ln.L1, yb: -P.P2 / 2 });
      zDims.push({ text: `L2 ${Model.valueOf(Ln, 'L2')}`, a: 0, b: Ln.L2, yb: -Cl.H1 / 2 });
    }
    zDims.push({ text: `L3 ${Model.valueOf(Ln, 'L3')}`, a: 0, b: L3, yb: -H2h });
    zDims.push({ text: `L6 ${Model.valueOf(Ln, 'L6')}`, a: 0, b: L6, yb: -meplatHalf });

    // Dimension rows above the outline, nearest first. Lines first; labels after the flags.
    const rowTop = -(Ro + ROW_BASE + ROW_STEP * (zDims.length - 1));
    zDims.forEach((d, k) => {
      const rowY = -(Ro + ROW_BASE + ROW_STEP * k);
      d.rowY = rowY;
      segs.push([d.a, rowY, d.b, rowY]);
      segs.push([d.a, -R1h - GAP, d.a, rowY - 1]);
      segs.push([d.b, d.yb - GAP, d.b, rowY - 1]);
      dimArrows.push(arrow([d.a, rowY], [1, 0]), arrow([d.b, rowY], [-1, 0]));
    });

    // Diameter dimensions: across the feature, with a flag leader up to a label above the rows.
    const radial = [];
    radial.push({ text: `R1 ${Model.valueOf(H, 'R1')}`, x: H.R / 2, h: R1h });
    if (g.groove) radial.push({ text: `E1 ${Model.valueOf(H, 'E1')}`, x: H.R + H.eMin / 2, h: H.E1 / 2 });
    radial.push({ text: `P1 ${Model.valueOf(P, 'P1')}`, x: g.bodyStart + 0.8, h: P1h });
    if (g.shoulder) {
      radial.push({ text: `P2 ${Model.valueOf(P, 'P2')}`, x: Ln.L1 - 0.8, h: P.P2 / 2 });
      radial.push({ text: `H1 ${Model.valueOf(Cl, 'H1')}`, x: Ln.L2 + 0.8, h: Cl.H1 / 2 });
    }
    radial.push({ text: `H2 ${Model.valueOf(Cl, 'H2')}`, x: L3 - 0.8, h: H2h });
    const zs = g.bullet.zs;
    radial.push({ text: `G1 ${Model.valueOf(PR, 'G1')}`, x: L3 + (zs - L3) / 2, h: g.bullet.Rx });
    radial.sort((a, b) => b.x - a.x);

    // Flags: leader from the feature to a shelf, label beside the leader end. Shelves are above the rows or below the section.
    const shelfTop = (k) => rowTop - ROW_STEP * (k + 1);
    const shelfBottom = (k) => Ro + ROW_BASE + ROW_STEP * k;
    const placeFlag = (text, x, yStart, shelf) => {
      for (const anchor of ['start', 'end']) {
        for (let k = 0; k <= SHELVES; k++) {
          const shelfY = shelf(k);
          const leader = [x, yStart, x, shelfY];
          if (rects.some((r) => segHitsRect(leader, r))) continue;
          const bx = anchor === 'start' ? x + GAP : x - GAP;
          const baseY = shelfY + 0.9;
          const rect = textRect(text, bx, baseY, anchor);
          if (!hits(rect)) {
            rects.push(rect);
            segs.push(leader);
            texts.push({ text, x: bx, y: baseY, anchor, rect });
            return true;
          }
        }
      }
      unplaced.push(text);
      return false;
    };

    radial.forEach((d) => {
      segs.push([d.x, -d.h, d.x, d.h]);
      dimArrows.push(arrow([d.x, -d.h], [0, 1]), arrow([d.x, d.h], [0, -1]));
      placeFlag(d.text, d.x, d.h, shelfBottom);
    });

    // Shoulder angle: arc from the axis to the shoulder, centred on the cone apex.
    let angleArc = null;
    if (g.shoulder && g.shoulder.apex) {
      const apexX = g.shoulder.apex[1];
      const start = [Ln.L1 - apexX, -P.P2 / 2];
      const d1 = Math.hypot(start[0], start[1]);
      const neck = [Ln.L2 - apexX, -Cl.H1 / 2];
      const d2 = Math.hypot(neck[0], neck[1]);
      const rho = (d1 + d2) / 2;
      const u = [start[0] / d1, start[1] / d1];
      const a0 = [apexX - rho, 0];
      const a1 = [apexX + rho * u[0], rho * u[1]];
      const theta1 = Math.atan2(u[1], u[0]);
      const travel1 = [-Math.sin(theta1), Math.cos(theta1)];
      const bis = [-1 + u[0], u[1]];
      const bl = Math.hypot(bis[0], bis[1]);
      const mid = [apexX + rho * bis[0] / bl, rho * bis[1] / bl];
      angleArc = { d: `M${n3(a0[0])} ${n3(a0[1])} A${n3(rho)} ${n3(rho)} 0 0 1 ${n3(a1[0])} ${n3(a1[1])}` };
      dimArrows.push(arrow(a0, [0, -1]), arrow(a1, [-travel1[0], -travel1[1]]));
      placeFlag(`α ${Model.formatAngle(J.alpha)}`, mid[0], mid[1], shelfTop);
    }

    // Row labels last: the free position nearest the middle of the dimension line.
    zDims.forEach((d) => {
      const baseY = d.rowY - 0.9;
      const w = d.text.length * CHAR_W;
      const mid = (d.a + d.b) / 2;
      const xs = [];
      for (let x = -w - 2; x <= d.b + w + 2; x += 0.5) xs.push(x);
      xs.sort((p, q) => Math.abs(p - mid) - Math.abs(q - mid));
      const found = xs.map((x) => ({ x, rect: textRect(d.text, x, baseY, 'middle') })).find((c) => !hits(c.rect));
      if (found) {
        rects.push(found.rect);
        texts.push({ text: d.text, x: found.x, y: baseY, anchor: 'middle', rect: found.rect });
      } else {
        unplaced.push(d.text);
      }
    });

    // Title block below the lowest label.
    const titleTop = Math.max(Ro, ...texts.map((t) => t.rect.y1)) + 2.5;
    const maxX = Math.max(L6, TITLE_W, ...texts.map((t) => t.rect.x1));
    const minX = Math.min(-4, ...texts.map((t) => t.rect.x0));
    const minY = Math.min(...texts.map((t) => t.rect.y0), -Ro - 2);

    return {
      g,
      wall,
      texts,
      unplaced,
      segs,
      dimArrows,
      angleArc,
      zDims,
      radial,
      viewBox: { x0: minX - 1, y0: minY - 1.5, x1: maxX + 2, y1: titleTop + TITLE_H + 1 },
      titleTop,
      Ro,
    };
  }

  function svg(record, p = plan(record)) {
    const { g } = p;
    const { lengths: Ln } = record.cartridge;
    const vb = p.viewBox;
    const hatchId = `hatch-${record.key}`;
    const casePts = Geometry.casePolygon(g).map(down);
    const bulletPts = Geometry.bulletPolygon(g).map(down);
    const caseEdges = [
      g.secOuter.map(down),
      [g.secOuter[g.secOuter.length - 1], ...g.inner].map(down),
      [g.inner[g.inner.length - 1], [0, g.floorZ]].map(down),
    ];
    if (g.pocket) caseEdges.push([[0, g.pocket.depth], [g.pocket.r, g.pocket.depth], [g.pocket.r, 0]].map(down));
    const bulletEdges = [[[0, g.bullet.zb], ...g.bullet.profile].map(down)];
    const upperOutline = g.outline.map(up);
    const axisX0 = vb.x0 + 1;
    const axisX1 = Math.max(Ln.L6, vb.x1) - 2;

    const dims = p.segs.map((s) => `M${n3(s[0])} ${n3(s[1])} L${n3(s[2])} ${n3(s[3])}`).join(' ');
    const texts = p.texts.map((t) => `<text class="label" x="${n3(t.x)}" y="${n3(t.y)}" text-anchor="${t.anchor}">${esc(t.text)}</text>`).join('');
    const title = [
      `<rect class="frame" x="0" y="${n3(p.titleTop)}" width="${TITLE_W}" height="${TITLE_H}"/>`,
      `<text class="title" x="2" y="${n3(p.titleTop + 5)}">${esc(record.name)}</text>`,
      `<text class="small" x="2" y="${n3(p.titleTop + 9.2)}">C.I.P. table ${esc(record.tab)}, revised ${esc(record.revised)}</text>`,
      `<line class="ext" x1="0" y1="${n3(p.titleTop + 10.8)}" x2="${TITLE_W}" y2="${n3(p.titleTop + 10.8)}"/>`,
      `<text class="small" x="2" y="${n3(p.titleTop + 13.8)}">Dimensions in mm</text>`,
      `<text class="small" x="${TITLE_W - 2}" y="${n3(p.titleTop + 13.8)}" text-anchor="end">Scale 1:1 (1 unit = 1 mm)</text>`,
    ].join('');

    return [
      `<svg class="drawing" role="img" aria-label="${esc(record.name)} drawing" xmlns="http://www.w3.org/2000/svg"`,
      ` viewBox="${n3(vb.x0)} ${n3(vb.y0)} ${n3(vb.x1 - vb.x0)} ${n3(vb.y1 - vb.y0)}">`,
      `<defs><pattern id="${hatchId}" patternUnits="userSpaceOnUse" width="1.2" height="1.2" patternTransform="rotate(45)">`,
      `<line class="hatch" x1="0" y1="0" x2="0" y2="1.2"/></pattern></defs>`,
      `<line class="axis" x1="${n3(axisX0)}" y1="0" x2="${n3(axisX1)}" y2="0"/>`,
      `<path class="section" fill="url(#${hatchId})" d="${pathOf(casePts)} Z"/>`,
      `<path class="section" fill="url(#${hatchId})" d="${pathOf(bulletPts)} Z"/>`,
      `<path class="edge" d="${caseEdges.map(pathOf).join(' ')} ${bulletEdges.map(pathOf).join(' ')}"/>`,
      `<path class="outline" d="${pathOf(upperOutline)}"/>`,
      `<path class="dim" d="${dims}"/>`,
      `<path class="arrow" d="${p.dimArrows.join(' ')}"/>`,
      p.angleArc ? `<path class="dim" d="${p.angleArc.d}"/>` : '',
      `<g class="labels">${texts}</g>`,
      `<g class="title-block">${title}</g>`,
      '</svg>',
    ].join('');
  }

  return { plan, svg, segHitsRect, rectsOverlap };
})();
