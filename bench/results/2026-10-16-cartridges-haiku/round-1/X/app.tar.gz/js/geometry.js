// Profile geometry for the drawing. Points are [r, z] in mm: r is the radius, z runs from the head face (z = 0) to the mouth.
var Geometry = (() => {
  const RAD = Math.PI / 180;
  const tanDeg = (angle) => Math.tan(Model.angleDegrees(angle) * RAD);

  const PRIMER_POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 },
  };

  function rimType(record) {
    const { family } = record;
    if (family === 'belted' || family === 'rimfire') return family;
    const ratio = record.cartridge.caseHead.R1 / record.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Appends p unless it repeats the last point.
  function push(list, p) {
    const last = list[list.length - 1];
    if (!last || Math.abs(last[0] - p[0]) > 1e-9 || Math.abs(last[1] - p[1]) > 1e-9) list.push(p);
    return list;
  }

  // Arc tangent to segments p0-v and v-p1 with radius r. Returns the tangent points and the arc between them.
  function fillet(p0, v, p1, r, steps = 6) {
    if (!(r > 0)) return [v];
    const unit = (x, y) => { const d = Math.hypot(x, y); return [x / d, y / d]; };
    const a = unit(p0[0] - v[0], p0[1] - v[1]);
    const b = unit(p1[0] - v[0], p1[1] - v[1]);
    const theta = Math.acos(Math.max(-1, Math.min(1, a[0] * b[0] + a[1] * b[1])));
    if (theta < 1e-9 || Math.PI - theta < 1e-9) return [v];
    const d = r / Math.tan(theta / 2);
    const bis = unit(a[0] + b[0], a[1] + b[1]);
    const c = [v[0] + bis[0] * r / Math.sin(theta / 2), v[1] + bis[1] * r / Math.sin(theta / 2)];
    const t1 = [v[0] + a[0] * d, v[1] + a[1] * d];
    const t2 = [v[0] + b[0] * d, v[1] + b[1] * d];
    const a1 = Math.atan2(t1[1] - c[1], t1[0] - c[0]);
    let da = Math.atan2(t2[1] - c[1], t2[0] - c[0]) - a1;
    while (da > Math.PI) da -= 2 * Math.PI;
    while (da < -Math.PI) da += 2 * Math.PI;
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = a1 + da * i / steps;
      pts.push([c[0] + r * Math.cos(t), c[1] + r * Math.sin(t)]);
    }
    return pts;
  }

  function build(record) {
    const notes = [];
    const { caseHead: H, collar: C, junctionCone: J = {}, lengths: L, powderChamber: P, projectile: PR } = record.cartridge;
    const { category, primerType, defaultBulletShape: shape } = record.annotations;
    const rim = rimType(record);

    // Records that lack a value a feature needs: the feature is skipped and named in notes.
    const need = (feature, values) => {
      const missing = Object.keys(values).filter((k) => values[k] === undefined);
      if (missing.length) notes.push(`${feature} not drawn: ${missing.join(', ')} missing`);
      return missing.length === 0;
    };

    const R = H.R;
    const R1 = H.R1 / 2;
    const P1 = P.P1 / 2;
    const H2 = C.H2 / 2;
    const G1 = PR.G1;
    const L3 = L.L3;
    const L6 = L.L6;
    const belt = rim === 'belted';

    // Head face, rim edge.
    const outer = [[0, 0]];
    let rimTop;
    if (rim === 'rimfire') {
      const rho = Math.min(R / 2, (H.R1 - P.P1) / 2);
      const cx = R1 - rho;
      push(outer, [cx, 0]);
      for (let i = 0; i <= 8; i++) {
        const t = -Math.PI / 2 + Math.PI * i / 8;
        push(outer, [cx + rho * Math.cos(t), rho + rho * Math.sin(t)]);
      }
      rimTop = 2 * rho;
    } else {
      const chamfer = H.beta !== undefined && H.f !== undefined && Model.angleDegrees(H.beta) < 90
        ? Math.min(H.f * tanDeg(H.beta), R1 / 2)
        : 0;
      if (chamfer > 0) push(outer, [R1 - chamfer, 0]);
      push(outer, chamfer > 0 ? [R1, H.f] : [R1, 0]);
      push(outer, [R1, R]);
      rimTop = R;
    }

    // Extractor groove, belt, or a plain step in to the body.
    let bodyStart = rimTop;
    let groove = null;
    let beltEnd = null;
    if ((H.E !== undefined || H.E1 !== undefined) && need('groove', { E: H.E, E1: H.E1, eMin: H.eMin })) {
      const E1 = H.E1 / 2;
      const floor = R + H.eMin;
      push(outer, [E1, R]);
      push(outer, [E1, floor]);
      groove = { E: H.E, E1, floorEnd: floor };
      if (belt && need('belt', { R3: H.R3, delta: H.delta })) {
        const R3 = H.R3 / 2;
        beltEnd = floor + (R3 - E1) / tanDeg(H.delta);
        push(outer, [R3, beltEnd]);
        push(outer, [R3, H.E]);
      }
      push(outer, [P1, H.E]);
      bodyStart = H.E;
    } else {
      push(outer, [P1, rimTop]);
    }

    // Body, shoulder and neck to the mouth.
    const shoulderValues = J.alpha !== undefined && L.L1 !== undefined && L.L2 !== undefined;
    let shoulder = null;
    if (!shoulderValues && (L.L1 !== undefined || L.L2 !== undefined)) notes.push('shoulder not drawn: junctionCone.alpha missing');
    if (shoulderValues && need('shoulder', { P2: P.P2, H1: C.H1 })) {
      const P2 = P.P2 / 2;
      const H1 = C.H1 / 2;
      const corner1 = [P2, L.L1];
      const corner2 = [H1, L.L2];
      const body0 = [P1, bodyStart];
      const mouth = [H2, L3];
      fillet(body0, corner1, corner2, J.r1Min).forEach((p) => push(outer, p));
      fillet(corner1, corner2, mouth, J.r2).forEach((p) => push(outer, p));
      push(outer, mouth);
      const apexZ = P2 === H1 ? null : L.L1 + P2 * (L.L2 - L.L1) / (P2 - H1);
      shoulder = { start: corner1, neck: corner2, apex: apexZ === null ? null : [0, apexZ], alpha: J.alpha, L1: L.L1, L2: L.L2 };
    } else {
      push(outer, [H2, L3]);
    }

    // Section walls.
    const tn = Math.max(0, (C.H2 - G1) / 2);
    const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1);
    const rBody = (z) => {
      const end = shoulder ? [P.P2 / 2, L.L1] : [H2, L3];
      return P1 + (end[0] - P1) * (z - bodyStart) / (end[1] - bodyStart);
    };

    // Primer pocket (centrefire only).
    let pocket = null;
    if (rim !== 'rimfire' && primerType !== 'rimfire') {
      if (primerType === undefined) notes.push('primer pocket not drawn: primerType missing');
      else if (PRIMER_POCKETS[primerType]) {
        const pk = PRIMER_POCKETS[primerType];
        pocket = { r: pk.diameter / 2, depth: pk.depth };
      } else notes.push(`primer pocket not drawn: unknown primerType ${primerType}`);
    }

    // Solid head up to the cavity floor.
    let floorZ = Math.max(2.5, 0.25 * P1);
    if (pocket) floorZ = Math.max(floorZ, pocket.depth + 1.5);
    if (belt && beltEnd !== null) floorZ = Math.max(floorZ, beltEnd + tb);
    else if (groove) floorZ = Math.max(floorZ, groove.E + tb);

    const secOuter = pocket ? [[pocket.r, 0], ...outer.slice(1)] : outer.slice();
    const inner = shoulder ? [[H2 - tn, L3], [C.H1 / 2 - tn, shoulder.L2]] : [[H2 - tb, L3]];
    if (shoulder) push(inner, [shoulder.start[0] - tb, shoulder.start[1]]);
    push(inner, [rBody(floorZ) - tb, floorZ]);

    // Bullet: seated depth, cylinder, nose.
    const heeled = C.H2 - G1 <= 0.015;
    const Rx = heeled ? H2 : G1 / 2;
    const rh = (C.H2 - 2 * tb) / 2;
    const seatFactor = shape === 'pointy' ? 1 : shape === 'semi_wadcutter' ? 0.6 : category === 'pistol' ? 0.4 : 0.8;
    const zb = L3 - seatFactor * G1;
    const Lb = L6 - zb;
    const cylFactor = {
      pointy: 0.4,
      rounded: category === 'pistol' ? 0.65 : 0.55,
      flat: category === 'pistol' ? 0.7 : 0.6,
      semi_wadcutter: 0.78,
    }[shape] ?? 0.4;
    const zs = zb + cylFactor * Lb;
    const meplat = {
      pointy: Math.max(0.08 * G1, 1.27),
      rounded: 0.15 * G1,
      flat: 0.55 * G1,
      semi_wadcutter: 0.6 * G1,
    }[shape] ?? 0.55 * G1;
    const m2 = meplat / 2;
    const nose = [];
    if (shape === 'pointy') {
      const a = Rx - m2;
      const n = L6 - zs;
      const rho = (a * a + n * n) / (2 * a);
      const phiMax = Math.atan2(n, rho - a);
      for (let i = 1; i <= 8; i++) {
        const phi = phiMax * i / 8;
        nose.push([Rx - rho + rho * Math.cos(phi), zs + rho * Math.sin(phi)]);
      }
    } else if (shape === 'rounded') {
      const A = Rx - m2;
      const B = L6 - zs;
      for (let i = 1; i <= 8; i++) {
        const t = Math.PI / 2 * i / 8;
        nose.push([m2 + A * Math.cos(t), zs + B * Math.sin(t)]);
      }
    } else {
      nose.push([m2, L6]);
    }
    if (!shape) notes.push('bullet nose not drawn as published: defaultBulletShape missing');
    nose.push([0, L6]);
    const exposed = [[Rx, L3], [Rx, zs], ...nose];
    const profile = heeled
      ? [[rh, zb], [rh, L3], [Rx, L3], [Rx, zs], ...nose]
      : [[Rx, zb], [Rx, zs], ...nose];
    const outline = outer.slice();
    exposed.forEach((p) => push(outline, p));

    return {
      rim,
      notes,
      outer,
      outline,
      secOuter,
      inner,
      floorZ,
      tb,
      tn,
      pocket,
      groove,
      beltEnd,
      shoulder,
      bodyStart,
      bullet: { heeled, Rx, rh, zb, zs, Lb, meplat, exposed, profile },
    };
  }

  // Closed polygon of the case cut face (head, walls, neck). Axis segments are part of the polygon.
  function casePolygon(g) {
    const poly = [...g.secOuter, ...g.inner, [0, g.floorZ]];
    if (g.pocket) poly.push([0, g.pocket.depth], [g.pocket.r, g.pocket.depth]);
    return poly;
  }

  // Closed polygon of the bullet cut face, from the base to the tip.
  function bulletPolygon(g) {
    return [[0, g.bullet.zb], ...g.bullet.profile];
  }

  return { rimType, fillet, build, casePolygon, bulletPolygon };
})();
