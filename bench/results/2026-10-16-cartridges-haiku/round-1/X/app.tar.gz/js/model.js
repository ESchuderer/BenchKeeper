// Formatting, symbols, units, table groups, search and filter for the cartridge records.
var Model = (() => {
  const SYMBOL_OVERRIDES = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };

  // Units per field. 'deg' values are angles and print with their own degree sign.
  const UNITS = {
    E: 'mm', E1: 'mm', R: 'mm', R1: 'mm', R3: 'mm', eMin: 'mm', f: 'mm',
    beta: 'deg', delta: 'deg', alpha: 'deg', alpha1: 'deg', i: 'deg',
    H1: 'mm', H2: 'mm', S: 'mm', r1Min: 'mm', r1Max: 'mm', r2: 'mm', r: 'mm',
    L1: 'mm', L2: 'mm', L3: 'mm', L4: 'mm', L5: 'mm', L6: 'mm',
    Fe: 'mm', deltaL: 'mm', P1: 'mm', P2: 'mm', L3PlusG: 'mm',
    EE: 'J', M: 'g', PE: 'bar', PK: 'bar', Pmax: 'bar',
    G1: 'mm', G2: 'mm', F: 'mm', Z: 'mm', G: 'mm', s: 'mm', h: 'mm', b: 'mm', u: 'mm',
    Q: 'mm²', N: '',
    grH2O: 'gr H2O',
  };

  const GROUPS = {
    cartridge: {
      caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
      misc: 'Misc', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    },
    chamber: {
      barrel: 'Barrel', breech: 'Breech', collar: 'Collar', grooves: 'Grooves',
      junctionCone: 'Junction cone', lengths: 'Lengths', powderChamber: 'Powder chamber', rifling: 'Rifling',
    },
  };

  const FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  const collator = new Intl.Collator('en', { numeric: true, sensitivity: 'base' });

  const pad2 = (n) => String(n).padStart(2, '0');

  function formatNumber(n) {
    return String(n);
  }

  function isDms(a) {
    return typeof a === 'object' && a !== null;
  }

  function formatAngle(a) {
    if (!isDms(a)) return `${formatNumber(a)}°`;
    return `${a.degrees}°${pad2(a.minutes)}'${pad2(a.seconds)}"`;
  }

  function angleDegrees(a) {
    if (!isDms(a)) return a;
    return a.degrees + a.minutes / 60 + a.seconds / 3600;
  }

  function symbolOf(field) {
    return SYMBOL_OVERRIDES[field] || field;
  }

  function formatField(field, raw) {
    if (UNITS[field] === 'deg' || isDms(raw)) return formatAngle(raw);
    return formatNumber(raw);
  }

  function unitOf(field) {
    const unit = UNITS[field] || '';
    return unit === 'deg' ? '' : unit;
  }

  // Value of one field with its tolerance, e.g. '39.62 -0.2'.
  function valueOf(group, field) {
    const tol = group[`${field}Tol`];
    return formatField(field, group[field]) + (tol === undefined ? '' : ` ${formatNumber(tol)}`);
  }

  // Rows for one group. Each <X>Tol is folded into the row of X.
  function groupRows(group) {
    const rows = [];
    for (const [field, raw] of Object.entries(group)) {
      if (field.endsWith('Tol') && field.slice(0, -3) in group) continue;
      rows.push({ symbol: symbolOf(field), value: valueOf(group, field), unit: unitOf(field) });
    }
    return rows;
  }

  // Groups of one section ('cartridge' or 'chamber') in GROUPS order, empty groups omitted.
  function sectionTables(record, section) {
    const data = record[section];
    return Object.entries(GROUPS[section])
      .filter(([key]) => data[key] && Object.keys(data[key]).length > 0)
      .map(([key, title]) => ({ key, title, rows: groupRows(data[key]) }));
  }

  function waterCapacity(record) {
    const cap = record.annotations.publishedCapacity;
    if (!cap) return null;
    return {
      value: formatNumber(cap.grH2O), unit: UNITS.grH2O, note: cap.note || '', source: cap.source, url: cap.url,
    };
  }

  const normalize = (text) => text.toLowerCase().replace(/\s+/g, '');

  function matchesQuery(record, query) {
    const q = normalize(query);
    if (q === '') return true;
    return [record.name, ...(record.alternativeNames || [])].some((n) => normalize(n).includes(q));
  }

  function filterCartridges(records, { query, family }) {
    return records.filter((c) => (family === 'all' || c.family === family) && matchesQuery(c, query));
  }

  function sortByName(records) {
    return [...records].sort((a, b) => collator.compare(a.name, b.name));
  }

  function countLabel(n) {
    return n === 1 ? '1 cartridge' : `${n} cartridges`;
  }

  return {
    FAMILIES,
    formatNumber,
    formatAngle,
    angleDegrees,
    valueOf,
    sectionTables,
    waterCapacity,
    matchesQuery,
    filterCartridges,
    sortByName,
    countLabel,
    symbolOf,
    unitOf,
  };
})();
