const test = require('node:test');
const assert = require('node:assert/strict');
require('./load.js')('js/cartridges.js', 'js/model.js', 'js/geometry.js', 'js/drawing.js');

const byKey = (key) => CARTRIDGES.find((c) => c.key === key);

const overlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
const segHits = (s, R) => {
  const [x1, y1, x2, y2] = s; const dx = x2 - x1; const dy = y2 - y1;
  let t0 = 0; let t1 = 1;
  const p = [-dx, dx, -dy, dy]; const q = [x1 - R.x0, R.x1 - x1, y1 - R.y0, R.y1 - y1];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; } else {
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
  }
  return t0 <= t1;
};

test('svg has the accessible name, a viewBox in mm and both halves', () => {
  const svg = Drawing.svg(byKey('223_rem'));
  assert.match(svg, /<svg[^>]*role="img"[^>]*aria-label="223 Rem\. drawing"/);
  assert.match(svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/);
  assert.match(svg, /class="section"/);
  assert.match(svg, /class="outline"/);
});

test('dimension labels carry symbol and value, tolerance included', () => {
  const texts = Drawing.plan(byKey('223_rem')).texts.map((t) => t.text);
  for (const t of ['L3 44.7', 'L6 57.4', 'R1 9.6', 'R 1.14', 'P1 9.58', 'P2 9 -0.2', 'H1 6.43', 'H2 6.43', 'G1 5.7', 'L1 36.52 -0.2', 'L2 39.55 -0.2', 'E1 8.43', 'α 46°']) {
    assert.ok(texts.includes(t), `missing label ${t}`);
  }
  const nine = Drawing.plan(byKey('9_mm_luger')).texts.map((t) => t.text);
  assert.ok(nine.includes('L3 19.15 -0.25'));
  assert.ok(!nine.some((t) => t.startsWith('α')), 'no shoulder angle on a straight case');
});

test('labels do not overlap each other or the outline, for all 25 records', () => {
  for (const rec of CARTRIDGES) {
    const plan = Drawing.plan(rec);
    plan.texts.forEach((t, i) => {
      plan.texts.forEach((u, j) => {
        if (j > i) assert.equal(overlap(t.rect, u.rect), false, `${rec.key}: "${t.text}" overlaps "${u.text}"`);
      });
      assert.equal(plan.wall.some((s) => segHits(s, t.rect)), false, `${rec.key}: "${t.text}" hits the outline`);
    });
    assert.equal(plan.unplaced.length, 0, `${rec.key}: unplaced ${plan.unplaced.join(', ')}`);
  }
});

test('title block: name, C.I.P. table, revision, units and scale', () => {
  const svg = Drawing.svg(byKey('300_win_mag'));
  assert.ok(svg.includes('300 Win. Mag.'));
  assert.ok(svg.includes('C.I.P. table III, revised 2002-05-15'));
  assert.ok(svg.includes('Dimensions in mm'));
  assert.ok(svg.includes('Scale 1:1'));
});

test('names are escaped in the markup', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  rec.name = 'A & <B>';
  const svg = Drawing.svg(rec);
  assert.ok(svg.includes('A &amp; &lt;B&gt; drawing'));
  assert.ok(!svg.includes('<B>'));
});
