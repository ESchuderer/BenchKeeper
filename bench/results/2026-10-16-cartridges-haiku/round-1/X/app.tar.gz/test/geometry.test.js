const test = require('node:test');
const assert = require('node:assert/strict');
require('./load.js')('js/cartridges.js', 'js/model.js', 'js/geometry.js');

const byKey = (key) => CARTRIDGES.find((c) => c.key === key);
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `expected ${a} ≈ ${b}`);
const hasPoint = (pts, r, z, eps = 1e-6) => pts.some((p) => Math.abs(p[0] - r) <= eps && Math.abs(p[1] - z) <= eps);

test('rimType: family first, then R1/P1 ratio', () => {
  assert.equal(Geometry.rimType(byKey('223_rem')), 'rimless');
  assert.equal(Geometry.rimType(byKey('300_win_mag')), 'belted');
  assert.equal(Geometry.rimType(byKey('22_long_rifle')), 'rimfire');
  assert.equal(Geometry.rimType(byKey('9_3_x_74_r')), 'rimmed');
  assert.equal(Geometry.rimType(byKey('38_special')), 'rimmed');
});

test('outer profile runs from the axis at the head face to the mouth', () => {
  const g = Geometry.build(byKey('223_rem'));
  assert.deepEqual(g.outer[0], [0, 0]);
  const mouth = g.outer[g.outer.length - 1];
  near(mouth[0], 6.43 / 2); near(mouth[1], 44.7);
});

test('head chamfer from beta and f', () => {
  const g = Geometry.build(byKey('223_rem'));
  near(4.8 - 0.45 * Math.tan(35 * Math.PI / 180), g.outer[1][0]);
  assert.deepEqual(g.outer[2], [4.8, 0.45]);
  assert.ok(hasPoint(g.outer, 4.8, 1.14));
});

test('groove: floor at E1/2 from R to R+eMin, ramp to P1/2 at E', () => {
  const g = Geometry.build(byKey('223_rem'));
  assert.ok(hasPoint(g.outer, 8.43 / 2, 1.14));
  assert.ok(hasPoint(g.outer, 8.43 / 2, 1.14 + 0.76));
  assert.ok(hasPoint(g.outer, 9.58 / 2, 3.13));
  assert.equal(g.groove.E, 3.13);
});

test('belted groove: ramp at delta to R3/2, belt to E, step in to P1/2', () => {
  const g = Geometry.build(byKey('300_win_mag'));
  const r3 = 13.51 / 2;
  const zr = 1.27 + 0.94 + (r3 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  assert.ok(hasPoint(g.outer, r3, zr, 1e-9), 'belt start');
  assert.ok(hasPoint(g.outer, r3, 5.59), 'belt end');
  assert.ok(hasPoint(g.outer, 13.03 / 2, 5.59), 'step in');
});

test('rimfire rim: half-round of radius min(R/2, (R1-P1)/2) whose apex is at R1/2', () => {
  const g = Geometry.build(byKey('22_long_rifle'));
  const apex = Math.max(...g.outer.map((p) => p[0]));
  near(apex, 7.06 / 2, 1e-9);
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.ok(hasPoint(g.outer, 7.06 / 2 - rho, 0, 1e-9));
  assert.ok(hasPoint(g.outer, 7.06 / 2 - rho, 2 * rho, 1e-9));
});

test('straight case without shoulder: body runs to (H2/2, L3)', () => {
  const g = Geometry.build(byKey('9_mm_luger'));
  assert.equal(g.shoulder, null);
  const mouth = g.outer[g.outer.length - 1];
  near(mouth[0], 9.65 / 2); near(mouth[1], 19.15);
});

test('shoulder: fillets replace the corners, neck ends at (H2/2, L3)', () => {
  const g = Geometry.build(byKey('223_rem'));
  assert.ok(!hasPoint(g.outer, 9.0 / 2, 36.52), 'body corner rounded away');
  assert.ok(!hasPoint(g.outer, 6.43 / 2, 39.55), 'neck corner rounded away');
  near(g.shoulder.apex[0], 0);
  near(g.shoulder.apex[1], 47.12, 0.05);
});

test('section walls: tn from H2 and G1, tb from tn and P1, w from pocket', () => {
  const g = Geometry.build(byKey('223_rem'));
  near(g.tn, (6.43 - 5.7) / 2);
  near(g.tb, 0.6);
  assert.deepEqual(g.pocket, { r: 4.45 / 2, depth: 3.04 });
  near(g.floorZ, 3.04 + 1.5);
});

test('primer pocket: lp/lpm/lr/lrm sizes, none for rimfire', () => {
  assert.deepEqual(Geometry.build(byKey('308_win')).pocket, { r: 5.33 / 2, depth: 3.3 });
  assert.deepEqual(Geometry.build(byKey('30_06_spring')).pocket, { r: 5.33 / 2, depth: 3.3 });
  assert.deepEqual(Geometry.build(byKey('300_win_mag')).pocket, { r: 5.33 / 2, depth: 3.3 });
  assert.equal(Geometry.build(byKey('22_long_rifle')).pocket, null);
});

test('heeled case: 22 Long Rifle has an exposed bullet of H2 diameter and a heel of H2 - 2tb', () => {
  const g = Geometry.build(byKey('22_long_rifle'));
  assert.equal(g.bullet.heeled, true);
  near(g.bullet.Rx, 5.72 / 2);
  near(g.bullet.rh, (5.72 - 2 * g.tb) / 2);
  assert.equal(Geometry.build(byKey('223_rem')).bullet.heeled, false);
});

test('bullet pointy: seating 1.0·G1, cylinder to zb + 0.40·Lb, flat tip m = max(0.08·G1, 1.27)', () => {
  const b = Geometry.build(byKey('223_rem')).bullet;
  const zb = 44.7 - 5.7; const Lb = 57.4 - zb;
  near(b.zb, zb); near(b.zs, zb + 0.4 * Lb);
  const tip = b.exposed[b.exposed.length - 1];
  assert.deepEqual(tip, [0, 57.4]);
  near(b.exposed[b.exposed.length - 2][0], 1.27 / 2, 1e-9);
});

test('bullet pointy nose is a tangent arc of radius rho through the meplat edge', () => {
  const b = Geometry.build(byKey('223_rem')).bullet;
  const Rx = 5.7 / 2; const m = 1.27; const a = Rx - m / 2;
  const n = 57.4 - b.zs; const rho = (a * a + n * n) / (2 * a);
  const cr = Rx - rho; const cz = b.zs;
  for (const [r, z] of b.exposed.slice(1, -1)) {
    near(Math.hypot(r - cr, z - cz), rho, 1e-6);
  }
});

test('bullet rounded pistol: seating 0.4·G1, quarter ellipse with meplat 0.15·G1', () => {
  const g = Geometry.build(byKey('9_mm_luger'));
  const G1 = 9.03; const zb = 19.15 - 0.4 * G1; const Lb = 29.69 - zb;
  near(g.bullet.zb, zb);
  const zs = zb + 0.65 * Lb; near(g.bullet.zs, zs);
  const m = 0.15 * G1; const A = G1 / 2 - m / 2; const B = 29.69 - zs;
  for (const [r, z] of g.bullet.exposed.slice(2, -2)) {
    near(((r - m / 2) / A) ** 2 + ((z - zs) / B) ** 2, 1, 1e-6);
  }
  near(g.bullet.exposed[g.bullet.exposed.length - 2][0], m / 2, 1e-9);
});

test('bullet semi_wadcutter: seating 0.6·G1, cylinder to 0.78·Lb, cone to m = 0.6·G1', () => {
  const b = Geometry.build(byKey('357_magnum')).bullet;
  const G1 = 9.12; const zb = 32.77 - 0.6 * G1; const Lb = 40.39 - zb;
  near(b.zb, zb); near(b.zs, zb + 0.78 * Lb);
  near(b.exposed[b.exposed.length - 2][0], 0.3 * G1, 1e-9);
});

test('missing value: belted case without R3 is drawn without the belt and says so', () => {
  const rec = JSON.parse(JSON.stringify(byKey('300_win_mag')));
  delete rec.cartridge.caseHead.R3;
  const g = Geometry.build(rec);
  assert.ok(g.notes.some((n) => /R3/.test(n)));
  assert.equal(hasPoint(g.outer, 13.51 / 2, 5.59), false);
});

test('every record builds; the section polygon has no self-intersections', () => {
  const segs = (pts) => pts.slice(1).map((p, i) => [pts[i], p]);
  const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  const meet = (s, t) => {
    const [a, b] = s; const [c, d] = t;
    return cross(a, b, c) * cross(a, b, d) < -1e-12 && cross(c, d, a) * cross(c, d, b) < -1e-12;
  };
  for (const rec of CARTRIDGES) {
    const g = Geometry.build(rec);
    assert.ok(Array.isArray(g.notes), rec.key);
    const poly = Geometry.casePolygon(g);
    const edges = segs([...poly, poly[0]]);
    for (let i = 0; i < edges.length; i++) {
      for (let j = i + 2; j < edges.length; j++) {
        if (i === 0 && j === edges.length - 1) continue;
        assert.equal(meet(edges[i], edges[j]), false, `${rec.key} segment ${i} crosses ${j}`);
      }
    }
  }
});

test('missing junctionCone.alpha: the shoulder is dropped and the note says why', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete rec.cartridge.junctionCone.alpha;
  const g = Geometry.build(rec);
  assert.equal(g.shoulder, null);
  assert.ok(g.notes.some((n) => /alpha/.test(n)));
});

test('bullet wider than the neck: neck wall is not negative', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  rec.cartridge.projectile.G1 = 6.55;
  assert.equal(Geometry.build(rec).tn, 0);
});
