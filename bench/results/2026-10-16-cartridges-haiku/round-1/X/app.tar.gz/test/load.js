// Loads the browser scripts into the Node global scope, in page order.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

module.exports = function load(...files) {
  for (const file of files) {
    const src = fs.readFileSync(path.join(__dirname, '..', file), 'utf8');
    vm.runInThisContext(src, { filename: file });
  }
};
