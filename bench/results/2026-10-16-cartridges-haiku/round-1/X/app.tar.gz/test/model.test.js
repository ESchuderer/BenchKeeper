const test = require('node:test');
const assert = require('node:assert/strict');
require('./load.js')('js/cartridges.js', 'js/model.js');

const byKey = (key) => CARTRIDGES.find((c) => c.key === key);

test('data: 25 records with unique keys and names', () => {
  assert.equal(CARTRIDGES.length, 25);
  assert.equal(new Set(CARTRIDGES.map((c) => c.key)).size, 25);
  assert.equal(new Set(CARTRIDGES.map((c) => c.name)).size, 25);
});

test('formatNumber prints the shortest decimal form', () => {
  assert.equal(Model.formatNumber(51.18), '51.18');
  assert.equal(Model.formatNumber(4150), '4150');
  assert.equal(Model.formatNumber(35.0), '35');
  assert.equal(Model.formatNumber(0.1), '0.1');
});

test('formatAngle: number is degrees, object is DMS with padding', () => {
  assert.equal(Model.formatAngle(40), '40°');
  assert.equal(Model.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(Model.formatAngle({ degrees: 50, minutes: 35, seconds: 2 }), '50°35\'02"');
  assert.equal(Model.formatAngle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
});

test('angleDegrees converts DMS to decimal degrees', () => {
  assert.equal(Model.angleDegrees(90), 90);
  assert.ok(Math.abs(Model.angleDegrees({ degrees: 1, minutes: 30, seconds: 0 }) - 1.5) < 1e-12);
});

test('tableRows: tolerance is shown with its value and is not a row', () => {
  const sections = Model.sectionTables(byKey('223_rem'), 'cartridge');
  const lengths = sections.find((g) => g.key === 'lengths');
  const l1 = lengths.rows.find((r) => r.symbol === 'L1');
  assert.deepEqual(l1, { symbol: 'L1', value: '36.52 -0.2', unit: 'mm' });
  assert.ok(!lengths.rows.some((r) => r.symbol === 'L1Tol'));
  const caseHead = sections.find((g) => g.key === 'caseHead');
  assert.deepEqual(caseHead.rows.find((r) => r.symbol === 'e min'), { symbol: 'e min', value: '0.76', unit: 'mm' });
  assert.deepEqual(caseHead.rows.find((r) => r.symbol === 'β'), { symbol: 'β', value: '35°', unit: '' });
});

test('tableRows: symbols, units and pressures without thousands separator', () => {
  const sections = Model.sectionTables(byKey('223_rem'), 'cartridge');
  const pressures = sections.find((g) => g.key === 'pressures').rows;
  assert.deepEqual(pressures.find((r) => r.symbol === 'Pmax'), { symbol: 'Pmax', value: '4300', unit: 'bar' });
  assert.deepEqual(pressures.find((r) => r.symbol === 'EE'), { symbol: 'EE', value: '1825', unit: 'J' });
  const projectile = sections.find((g) => g.key === 'projectile').rows;
  assert.deepEqual(projectile.find((r) => r.symbol === 'L3 + G'), { symbol: 'L3 + G', value: '46.88', unit: 'mm' });
});

test('tableRows: chamber section and angle objects', () => {
  const chamber = Model.sectionTables(byKey('223_rem'), 'chamber');
  const rifling = chamber.find((g) => g.key === 'rifling').rows;
  assert.deepEqual(rifling.find((r) => r.symbol === 'α1'), { symbol: 'α1', value: '90°', unit: '' });
  assert.deepEqual(rifling.find((r) => r.symbol === 'i'), { symbol: 'i', value: '3°10\'36"', unit: '' });
  const grooves = chamber.find((g) => g.key === 'grooves').rows;
  assert.deepEqual(grooves.find((r) => r.symbol === 'N'), { symbol: 'N', value: '6', unit: '' });
  assert.deepEqual(grooves.find((r) => r.symbol === 'Q'), { symbol: 'Q', value: '25.03', unit: 'mm²' });
});

test('tableRows: groups keep the record order and omit empty groups', () => {
  const sections = Model.sectionTables(byKey('9_mm_luger'), 'cartridge');
  assert.deepEqual(sections.map((g) => g.key), ['caseHead', 'collar', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile']);
});

test('search matches name and alternative names, ignoring case and spaces', () => {
  const ref = byKey('308_win');
  assert.equal(Model.matchesQuery(ref, '7,62 x 51'), true);
  assert.equal(Model.matchesQuery(ref, '7,62x51'), true);
  assert.equal(Model.matchesQuery(ref, '308 WIN'), true);
  assert.equal(Model.matchesQuery(byKey('223_rem'), '308'), false);
  assert.equal(Model.matchesQuery(byKey('22_long_rifle'), '22 lfb'), true);
  assert.equal(Model.matchesQuery(ref, '   '), true);
});

test('filterCartridges combines query and family', () => {
  assert.equal(Model.filterCartridges(CARTRIDGES, { query: '', family: 'all' }).length, 25);
  const rimfire = Model.filterCartridges(CARTRIDGES, { query: '', family: 'rimfire' });
  assert.deepEqual(rimfire.map((c) => c.key).sort(), ['17_hmr', '22_long_rifle', '22_win_mag_r_f']);
  assert.equal(Model.filterCartridges(CARTRIDGES, { query: '22', family: 'pistol' }).length, 0);
});

test('sortByName orders names with numeric collation', () => {
  const names = Model.sortByName(CARTRIDGES).map((c) => c.name);
  assert.equal(names[0], '6,5 Creedmoor');
  assert.ok(names.indexOf('7 mm Rem. Mag.') < names.indexOf('7 x 64'));
});

test('countLabel', () => {
  assert.equal(Model.countLabel(25), '25 cartridges');
  assert.equal(Model.countLabel(1), '1 cartridge');
  assert.equal(Model.countLabel(0), '0 cartridges');
});

test('waterCapacity: value, unit, note and source; absent when not published', () => {
  assert.deepEqual(Model.waterCapacity(byKey('223_rem')), {
    value: '30.5', unit: 'gr H2O', note: 'kwk 31, Wikipedia 28.8; the mean', source: 'kwk', url: 'http://kwk.us/cases.html',
  });
  assert.equal(Model.waterCapacity(byKey('22_win_mag_r_f')), null);
});
