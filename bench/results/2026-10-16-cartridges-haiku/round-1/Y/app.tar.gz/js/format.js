/* Formatting, symbols, units, value tables, search, routes and header facts.
   Browser: global CIP.format. Node: require('./format.js'). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CIP = Object.assign(root.CIP || {}, { format: factory() });
})(globalThis, function () {
  'use strict';

  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const ANGLE_KEYS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const GROUP_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures',
    projectile: 'Projectile', barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };
  const SECTION_TITLES = { cartridge: 'Cartridge', chamber: 'Chamber' };

  function loadRecords(jsonl) {
    return jsonl.split('\n').filter((line) => line.trim() !== '').map((line) => JSON.parse(line));
  }

  function formatNumber(n) {
    return String(n);
  }

  const pad2 = (n) => String(n).padStart(2, '0');

  function formatAngle(v) {
    if (typeof v === 'number') return `${formatNumber(v)}°`;
    return `${formatNumber(v.degrees)}°${pad2(v.minutes)}'${pad2(v.seconds)}"`;
  }

  function isAngleKey(key) {
    return ANGLE_KEYS.includes(key);
  }

  // Degrees for a number or a {degrees, minutes, seconds} object; undefined otherwise.
  function angleDegrees(v) {
    if (typeof v === 'number') return v;
    if (v !== null && typeof v === 'object') return v.degrees + v.minutes / 60 + v.seconds / 3600;
    return undefined;
  }

  function formatForKey(key, value) {
    return isAngleKey(key) || (value !== null && typeof value === 'object') ? formatAngle(value) : formatNumber(value);
  }

  function symbolFor(key) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, key) ? SYMBOLS[key] : key;
  }

  function unitFor(key) {
    if (Object.prototype.hasOwnProperty.call(UNITS, key)) return UNITS[key];
    return isAngleKey(key) ? '' : 'mm';
  }

  // Published value followed by its tolerance (<key>Tol), with no tolerance row of its own.
  function valueWithTol(group, key) {
    const tol = group[`${key}Tol`];
    const text = formatForKey(key, group[key]);
    return tol === undefined ? text : `${text} ${formatNumber(tol)}`;
  }

  function buildValueTables(record) {
    const tables = [];
    for (const section of ['cartridge', 'chamber']) {
      for (const [group, fields] of Object.entries(record[section] || {})) {
        const rows = [];
        for (const [key, value] of Object.entries(fields)) {
          if (/Tol$/.test(key)) continue;
          rows.push({
            symbol: symbolFor(key),
            value: valueWithTol(fields, key),
            unit: unitFor(key),
          });
        }
        if (rows.length > 0) tables.push({ section: SECTION_TITLES[section], title: GROUP_TITLES[group] || group, rows });
      }
    }
    return tables;
  }

  const normalizeText = (s) => s.toLowerCase().replace(/\s+/g, ' ').trim();

  function filterCartridges(records, query, family) {
    const q = normalizeText(query || '');
    return records.filter((r) => {
      if (family && family !== 'all' && r.family !== family) return false;
      if (q === '') return true;
      return [r.name, ...(r.alternativeNames || [])].some((t) => normalizeText(t).includes(q));
    });
  }

  function countText(n) {
    return n === 1 ? '1 cartridge' : `${n} cartridges`;
  }

  function parseRoute(hash) {
    const m = /^#\/cartridge\/([^/?#]+)$/.exec(hash || '');
    if (!m) return null;
    try {
      return { key: decodeURIComponent(m[1]) };
    } catch (e) {
      return null;
    }
  }

  function cartridgeHash(key) {
    return `#/cartridge/${encodeURIComponent(key)}`;
  }

  function buildFacts(record) {
    const facts = [];
    const add = (label, text, extra) => facts.push(Object.assign({ label, text }, extra));
    if (record.alternativeNames) add('Alternative names', record.alternativeNames.join(', '));
    add('Family', record.family);
    add('Category', record.annotations.category);
    add('Primer type', record.annotations.primerType);
    add('C.I.P. table', record.tab);
    add('Country', record.country);
    add('Published', record.published);
    add('Revised', record.revised);
    add('Pressure method', record.pressureMethod);
    const cap = record.annotations.publishedCapacity;
    if (cap) {
      add('Water capacity', `${formatNumber(cap.grH2O)} grH2O`, {
        note: cap.note,
        link: { text: cap.source, href: cap.url },
      });
    }
    return facts;
  }

  return {
    loadRecords, formatNumber, formatAngle, angleDegrees, formatForKey, isAngleKey,
    symbolFor, unitFor, valueWithTol, buildValueTables, normalizeText, filterCartridges, countText,
    parseRoute, cartridgeHash, buildFacts,
  };
});
