/* 2D cartridge drawing model: profile, bullet, section walls, dimensions and label placement.
   Profile points are [r, z] (radius, axial distance from the head face), as in the brief.
   Drawing points are [x, y] with x = z; the outside view is above the axis (y = -r),
   the section below it (y = +r). Axial dimensions sit below the drawing, diameters above. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'));
  else root.CIP = Object.assign(root.CIP || {}, { geometry: factory(root.CIP.format) });
})(globalThis, function (F) {
  'use strict';

  const FS = 3.0; // label font size, mm
  const PAD = 0.25; // clearance between a label and any line
  const TITLE_H = 15;
  const TITLE_MIN_W = 64;
  const BULLET_SHAPES = ['pointy', 'rounded', 'flat', 'semi_wadcutter'];
  const PRIMERS = {
    sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04],
    lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3],
  };

  const toRad = (d) => (d * Math.PI) / 180;
  const angle = F.angleDegrees;

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    const R1 = rec.cartridge.caseHead.R1;
    const P1 = rec.cartridge.powderChamber.P1;
    if (R1 === undefined || P1 === undefined) return 'rimless';
    if (R1 / P1 >= 1.05) return 'rimmed';
    if (R1 / P1 < 0.98) return 'rebated';
    return 'rimless';
  }

  function inputs(rec) {
    const c = rec.cartridge;
    const h = c.caseHead || {};
    const l = c.lengths || {};
    const p = c.powderChamber || {};
    const j = c.junctionCone || {};
    const col = c.collar || {};
    const pr = c.projectile || {};
    return {
      R1: h.R1, R: h.R, E: h.E, E1: h.E1, eMin: h.eMin, f: h.f, R3: h.R3,
      beta: angle(h.beta), delta: angle(h.delta),
      P1: p.P1, P2: p.P2, L1: l.L1, L2: l.L2, L3: l.L3, L6: l.L6,
      H1: col.H1, H2: col.H2,
      alpha: angle(j.alpha), S: j.S, r1Min: j.r1Min, r2: j.r2,
      G1: pr.G1,
      category: rec.annotations.category,
      shape: rec.annotations.defaultBulletShape,
      primer: rec.annotations.primerType,
    };
  }

  // Tangent arc of radius rho at corner c between segments a-c and c-b, as points from the first to the second tangent point.
  function fillet(a, c, b, rho) {
    const va = [a[0] - c[0], a[1] - c[1]];
    const vb = [b[0] - c[0], b[1] - c[1]];
    const la = Math.hypot(va[0], va[1]);
    const lb = Math.hypot(vb[0], vb[1]);
    const ua = [va[0] / la, va[1] / la];
    const ub = [vb[0] / lb, vb[1] / lb];
    const theta = Math.acos(Math.max(-1, Math.min(1, ua[0] * ub[0] + ua[1] * ub[1])));
    if (theta < 1e-3 || theta > Math.PI - 1e-3) return null;
    const half = theta / 2;
    const t = Math.min(rho / Math.tan(half), 0.45 * la, 0.45 * lb);
    const r = t * Math.tan(half);
    const t1 = [c[0] + ua[0] * t, c[1] + ua[1] * t];
    const t2 = [c[0] + ub[0] * t, c[1] + ub[1] * t];
    const bx = ua[0] + ub[0];
    const by = ua[1] + ub[1];
    const bl = Math.hypot(bx, by);
    const d = r / Math.sin(half);
    const o = [c[0] + (bx / bl) * d, c[1] + (by / bl) * d];
    const a1 = Math.atan2(t1[1] - o[1], t1[0] - o[0]);
    const a2 = Math.atan2(t2[1] - o[1], t2[0] - o[0]);
    let da = a2 - a1;
    if (da > Math.PI) da -= 2 * Math.PI;
    if (da < -Math.PI) da += 2 * Math.PI;
    const steps = Math.max(2, Math.ceil(Math.abs(da) / (Math.PI / 36)));
    const arc = [];
    for (let k = 0; k <= steps; k++) {
      const ang = a1 + (da * k) / steps;
      arc.push([o[0] + r * Math.cos(ang), o[1] + r * Math.sin(ang)]);
    }
    return arc;
  }

  function roundCorners(list) {
    const out = [];
    for (let i = 0; i < list.length; i++) {
      const { p, rho } = list[i];
      if (rho && i > 0 && i < list.length - 1) {
        const arc = fillet(list[i - 1].p, p, list[i + 1].p, rho);
        if (arc) {
          out.push(...arc);
          continue;
        }
      }
      out.push(p);
    }
    return out;
  }

  // Half-circle of the rim edge from (rc, 0) through (R1/2, rho) to (rc, 2·rho), as [r, z].
  function halfRound(rc, rho) {
    const pts = [];
    for (let k = 0; k <= 12; k++) {
      const a = -Math.PI / 2 + (Math.PI * k) / 12;
      pts.push([rc + rho * Math.cos(a), rho + rho * Math.sin(a)]);
    }
    return pts;
  }

  // Largest outer radius at axial position z, or null when no segment reaches z.
  function outlineRadiusAt(list, z) {
    let best = null;
    for (let i = 0; i + 1 < list.length; i++) {
      const [r0, z0] = list[i];
      const [r1, z1] = list[i + 1];
      if (z < Math.min(z0, z1) - 1e-9 || z > Math.max(z0, z1) + 1e-9) continue;
      const r = Math.max(r0, r1);
      best = best === null ? r : Math.max(best, r);
    }
    return best;
  }

  // Outer radius where the profile crosses axial position z going outward in z.
  function crossingRadius(list, z) {
    for (let i = 0; i + 1 < list.length; i++) {
      const [r0, z0] = list[i];
      const [r1, z1] = list[i + 1];
      if (z0 <= z && z < z1) return r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
    }
    return null;
  }

  // Bullet nose from (Rb, zn) to the meplat edge (m/2, L6), as [r, z] points.
  function noseCurve(shape, Rb, m, zn, n, L6) {
    const pts = [];
    const N = 24;
    if (shape === 'pointy') {
      const a = Rb - m / 2;
      const rho = (a * a + n * n) / (2 * a);
      const rc = Rb - rho;
      const phiEnd = Math.atan2(n, m / 2 - rc);
      for (let k = 0; k <= N; k++) {
        const phi = (phiEnd * k) / N;
        pts.push([rc + rho * Math.cos(phi), zn + rho * Math.sin(phi)]);
      }
    } else if (shape === 'rounded') {
      const a = Rb - m / 2;
      for (let k = 0; k <= N; k++) {
        const t = ((Math.PI / 2) * k) / N;
        pts.push([m / 2 + a * Math.cos(t), zn + n * Math.sin(t)]);
      }
    } else {
      pts.push([Rb, zn], [m / 2, L6]);
    }
    pts[pts.length - 1] = [m / 2, L6];
    return pts;
  }

  // True when segment p-q meets the rectangle grown by PAD (Liang-Barsky).
  function segmentHitsRect(p, q, rect) {
    const x0 = rect.x0 - PAD;
    const x1 = rect.x1 + PAD;
    const y0 = rect.y0 - PAD;
    const y1 = rect.y1 + PAD;
    let t0 = 0;
    let t1 = 1;
    const dx = q[0] - p[0];
    const dy = q[1] - p[1];
    const clip = (pp, qq) => {
      if (pp === 0) return qq >= 0;
      const t = qq / pp;
      if (pp < 0) {
        if (t > t1) return false;
        if (t > t0) t0 = t;
      } else {
        if (t < t0) return false;
        if (t < t1) t1 = t;
      }
      return true;
    };
    return clip(-dx, p[0] - x0) && clip(dx, x1 - p[0]) && clip(-dy, p[1] - y0) && clip(dy, y1 - p[1]) && t0 <= t1;
  }

  function labelRect(x, y, anchor, text) {
    const w = text.length * FS * 0.58;
    const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0, x1: x0 + w, y0: y - 0.75 * FS, y1: y + 0.2 * FS };
  }

  function rectsOverlap(a, b) {
    return a.x0 - PAD < b.x1 && b.x0 - PAD < a.x1 && a.y0 - PAD < b.y1 && b.y0 - PAD < a.y1;
  }

  function segmentsOf(points, closed) {
    const out = [];
    for (let i = 1; i < points.length; i++) out.push([points[i - 1], points[i]]);
    if (closed && points.length > 2) out.push([points[points.length - 1], points[0]]);
    return out;
  }

  function arrowAt(tip, inward) {
    const len = 1.3;
    const half = 0.45;
    const bx = tip[0] + inward[0] * len;
    const by = tip[1] + inward[1] * len;
    return [tip, [bx - inward[1] * half, by + inward[0] * half], [bx + inward[1] * half, by - inward[0] * half]];
  }

  const arrowEdges = (arrows) => arrows.flatMap((a) => [[a[0], a[1]], [a[1], a[2]], [a[2], a[0]]]);

  // Each item tries its options in order; an option is a set of lines and arrows plus label candidates.
  // The first option and candidate that clears the outline, earlier lines and earlier labels is kept.
  function placeItems(items, fixedSegments) {
    const segments = fixedSegments.slice();
    const rects = [];
    return items.map((item) => {
      let pick = null;
      let fallback = null;
      for (const opt of item.options) {
        const optSegs = [];
        for (const l of opt.lines) optSegs.push(...segmentsOf(l.points, l.closed));
        optSegs.push(...arrowEdges(opt.arrows));
        const linesClear = !rects.some((r) => optSegs.some((s) => segmentHitsRect(s[0], s[1], r)));
        for (const c of opt.candidates) {
          const rect = labelRect(c.x, c.y, c.anchor, item.text);
          if (fallback === null) fallback = { opt, c, rect, optSegs };
          const clear =
            linesClear &&
            !optSegs.some((s) => segmentHitsRect(s[0], s[1], rect)) &&
            !segments.some((s) => segmentHitsRect(s[0], s[1], rect)) &&
            !rects.some((r) => rectsOverlap(r, rect));
          if (clear) {
            pick = { opt, c, rect, optSegs };
            break;
          }
        }
        if (pick) break;
      }
      const chosen = pick || fallback;
      segments.push(...chosen.optSegs);
      rects.push(chosen.rect);
      return {
        symbol: item.symbol,
        text: item.text,
        x: chosen.c.x,
        y: chosen.c.y,
        anchor: chosen.c.anchor,
        rect: chosen.rect,
        clear: pick !== null,
        lines: chosen.opt.lines,
        arrows: chosen.opt.arrows,
      };
    });
  }

  function labelCollisions(labels, segments) {
    const out = [];
    labels.forEach((l, i) => {
      if (!l.clear) out.push(`${l.symbol} has no clear position`);
      if (segments.some(([p, q]) => segmentHitsRect(p, q, l.rect))) out.push(`${l.symbol} over a line`);
      labels.slice(i + 1).forEach((o) => {
        if (rectsOverlap(l.rect, o.rect)) out.push(`${l.symbol} over ${o.symbol}`);
      });
    });
    return out;
  }

  const segmentsOfAll = (lines) => lines.flatMap((l) => segmentsOf(l.points, l.closed));

  function buildDrawing(rec) {
    const v = inputs(rec);
    const cart = rec.cartridge;
    const missing = [];
    const note = (key, feature) => {
      if (!missing.some((m) => m.key === key)) missing.push({ key, symbol: F.symbolFor(key), feature });
    };

    const required = { R1: 'rim', P1: 'body', H2: 'mouth', L3: 'mouth', L6: 'bullet tip', G1: 'bullet', shape: 'bullet nose' };
    let ok = true;
    for (const [key, feature] of Object.entries(required)) {
      if (v[key] === undefined) {
        note(key === 'shape' ? 'defaultBulletShape' : key, feature);
        ok = false;
      }
    }
    if (v.shape !== undefined && !BULLET_SHAPES.includes(v.shape)) {
      note('defaultBulletShape', 'bullet nose not recognised');
      ok = false;
    }
    if (!ok) return { ok: false, name: rec.name, missing };

    const rim = rimType(rec);
    const P = [];
    const add = (r, z, rho) => {
      const last = P[P.length - 1];
      if (last && last.p[0] === r && last.p[1] === z) {
        if (rho) last.rho = rho;
        return;
      }
      P.push({ p: [r, z], rho });
    };

    // Head face and rim edge.
    add(0, 0);
    let top;
    if (rim === 'rimfire') {
      let rho = (v.R1 - v.P1) / 2;
      if (v.R !== undefined) rho = Math.min(v.R / 2, rho);
      else note('R', 'rim edge');
      const rc = v.R1 / 2 - rho;
      for (const q of halfRound(rc, rho)) add(q[0], q[1]);
      top = 2 * rho;
    } else {
      const chamfer = v.beta !== undefined && v.beta < 90 && v.f !== undefined;
      if (chamfer) {
        add(v.R1 / 2 - Math.min(v.f * Math.tan(toRad(v.beta)), v.R1 / 4), 0);
        add(v.R1 / 2, v.f);
      } else {
        add(v.R1 / 2, 0);
      }
      if (v.R !== undefined) {
        top = v.R;
      } else {
        note('R', 'rim corner');
        top = chamfer ? v.f : 0;
      }
      add(v.R1 / 2, top);
    }

    // Extractor groove or step, and body start.
    const grooveOK = v.E !== undefined && v.E1 !== undefined && v.eMin !== undefined;
    let bodyStart;
    let beltZ = null;
    if (grooveOK) {
      add(v.E1 / 2, top);
      add(v.E1 / 2, top + v.eMin);
      if (rim === 'belted') {
        if (v.R3 !== undefined && v.delta !== undefined) {
          const zr = top + v.eMin + (v.R3 / 2 - v.E1 / 2) / Math.tan(toRad(v.delta));
          if (zr < v.E) {
            beltZ = zr;
            add(v.R3 / 2, zr);
            add(v.R3 / 2, v.E);
          } else {
            note('R3', 'belt not drawn: ramp reaches E');
          }
        } else {
          note(v.R3 === undefined ? 'R3' : 'delta', 'belt');
        }
      }
      add(v.P1 / 2, v.E);
      bodyStart = v.E;
    } else {
      for (const key of ['E', 'E1', 'eMin']) {
        if (v[key] === undefined && (v.E !== undefined || v.E1 !== undefined || v.eMin !== undefined)) {
          note(key, 'extractor groove');
        }
      }
      add(v.P1 / 2, top);
      bodyStart = top;
    }

    // Body, shoulder and neck. A case without alpha, L1 or L2 is straight.
    const shouldered = v.alpha !== undefined && v.L1 !== undefined && v.L2 !== undefined;
    let shoulderDrawn = false;
    if (shouldered && v.P2 !== undefined && v.H1 !== undefined) {
      shoulderDrawn = true;
      add(v.P2 / 2, v.L1, v.r1Min);
      add(v.H1 / 2, v.L2, v.r2);
    } else if (shouldered) {
      note(v.P2 === undefined ? 'P2' : 'H1', 'shoulder (drawn straight)');
    }
    add(v.H2 / 2, v.L3);
    const outline = roundCorners(P);

    // Bullet: seated depth s, cylinder to zn, nose to the meplat at L6.
    const G1 = v.G1;
    const isPistol = v.category === 'pistol';
    const heeled = v.H2 - G1 <= 0.015;
    const exposedR = heeled ? v.H2 / 2 : G1 / 2;
    const sFactor = { pointy: 1.0, semi_wadcutter: 0.6 }[v.shape] || (isPistol ? 0.4 : 0.8);
    const kCyl = { pointy: 0.4, semi_wadcutter: 0.78 }[v.shape] ||
      (v.shape === 'rounded' ? (isPistol ? 0.65 : 0.55) : isPistol ? 0.7 : 0.6);
    const mScale = { rounded: 0.15, flat: 0.55, semi_wadcutter: 0.6 }[v.shape];
    const m = v.shape === 'pointy' ? Math.max(0.08 * G1, 1.27) : mScale * G1;
    const s = sFactor * G1;
    const zb = v.L3 - s;
    const Lb = v.L6 - zb;
    const zn = zb + kCyl * Lb;
    const nose = noseCurve(v.shape, exposedR, m, zn, v.L6 - zn, v.L6);

    // Section walls: tn along the neck, tb along the body, blended across the shoulder.
    const tn = (v.H2 - G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * v.P1) / 2);
    const thickness = (z) => {
      if (!shoulderDrawn || z <= v.L1) return tb;
      if (z >= v.L2) return tn;
      return tb + ((tn - tb) * (z - v.L1)) / (v.L2 - v.L1);
    };
    const primer = { diameter: 0, depth: 0 };
    if (rim !== 'rimfire') {
      const pocket = PRIMERS[v.primer];
      if (pocket) {
        primer.diameter = pocket[0];
        primer.depth = pocket[1];
      } else {
        note('primerType', 'primer pocket');
      }
    }
    const terms = [2.5, (0.25 * v.P1) / 2, primer.depth + 1.5];
    if (beltZ !== null) terms.push(beltZ + tb);
    else if (grooveOK) terms.push(v.E + tb);
    const w = Math.max(...terms);

    // Section polygon (upper half): head face, outer profile, mouth, inner profile down to z = w, floor, axis, pocket.
    const cutR = crossingRadius(outline, w);
    const inner = outline
      .filter((p) => p[1] > w)
      .reverse()
      .map(([r, z]) => [r - thickness(z), z]);
    inner.push([cutR - thickness(w), w]);
    const pd = primer.diameter / 2;
    const wall = [[pd, 0], ...outline.slice(1), ...inner, [0, w], [0, primer.depth], [pd, primer.depth]];

    const heelR = heeled ? v.H2 / 2 - tb : undefined;
    const shank = heeled
      ? [[heelR, zb], [heelR, v.L3], [exposedR, v.L3], [exposedR, zn]]
      : [[exposedR, zb], [exposedR, zn]];
    const bulletSection = [[0, zb], ...shank, ...nose.slice(1), [0, v.L6]];
    const bulletOutside = [
      ...(heeled ? [] : [[v.H2 / 2, v.L3]]),
      [exposedR, v.L3], [exposedR, zn], ...nose.slice(1), [0, v.L6],
    ];

    // Drawing lines in [x, y] with x = z.
    const up = (pts) => pts.map(([r, z]) => [z, -r]);
    const down = (pts) => pts.map(([r, z]) => [z, r]);
    const drawn = [
      { cls: 'outline', points: up(outline) },
      { cls: 'outline', points: up(bulletOutside) },
      { cls: 'section', points: down(bulletSection), closed: true },
      { cls: 'wall', points: down(wall), closed: true },
    ];
    const fixedSegments = drawn.flatMap((l) => segmentsOf(l.points, l.closed));

    const Rmax = Math.max(...outline.map((p) => p[0]), exposedR);
    const tipR = m / 2;
    const headR = outlineRadiusAt(outline, 0) || v.R1 / 2;
    const items = [];

    // Axial dimensions in rows below the drawing, nearest row first.
    const rowY = (k) => Rmax + 3.5 + 4.5 * k;
    const rowsSpec = [];
    const rowLines = [];
    const rowArrows = [];
    if (v.R !== undefined && rim !== 'rimfire') rowsSpec.push({ key: 'R', at: v.R, group: cart.caseHead });
    if (shoulderDrawn) {
      rowsSpec.push({ key: 'L1', at: v.L1, group: cart.lengths });
      rowsSpec.push({ key: 'L2', at: v.L2, group: cart.lengths });
    }
    rowsSpec.push({ key: 'L3', at: v.L3, group: cart.lengths });
    rowsSpec.push({ key: 'L6', at: v.L6, group: cart.lengths });
    rowsSpec.forEach((row, k) => {
      const y = rowY(k);
      const endR = row.key === 'L6' ? tipR : outlineRadiusAt(outline, row.at) || 0;
      const lines = [
        { cls: 'ext', points: [[0, headR + 0.8], [0, y]] },
        { cls: 'ext', points: [[row.at, endR + 0.8], [row.at, y]] },
        { cls: 'dim', points: [[0, y], [row.at, y]] },
      ];
      const arrows = [arrowAt([0, y], [1, 0]), arrowAt([row.at, y], [-1, 0])];
      rowLines.push(...lines);
      rowArrows.push(...arrows);
      items.push({
        symbol: F.symbolFor(row.key),
        text: `${row.key} ${F.valueWithTol(row.group, row.key)}`,
        options: [{
          lines,
          arrows,
          candidates: [
            { x: row.at / 2, y: y - 1.0, anchor: 'middle' },
            { x: 1.5, y: y - 1.0, anchor: 'start' },
            { x: row.at / 4, y: y - 1.0, anchor: 'middle' },
            { x: (3 * row.at) / 4, y: y - 1.0, anchor: 'middle' },
            { x: row.at + 1.2, y: y + 0.9, anchor: 'start' },
            { x: -1.2, y: y + 0.9, anchor: 'end' },
            { x: 1.5, y: y + 1.0 + 0.75 * FS, anchor: 'start' },
            { x: row.at / 2, y: y + 1.0 + 0.75 * FS, anchor: 'middle' },
          ],
        }],
      });
    });

    // Diameters above the drawing: vertical dimension line with horizontal extension lines.
    const diameter = (key, group, xs, rho, offsets) => {
      const options = offsets.map((off) => {
        const xd = xs + off;
        const lines = [
          { cls: 'ext', points: [[xs, -rho], [xd, -rho]] },
          { cls: 'ext', points: [[xs, rho], [xd, rho]] },
          { cls: 'dim', points: [[xd, -rho], [xd, rho]] },
        ];
        const arrows = [arrowAt([xd, -rho], [0, 1]), arrowAt([xd, rho], [0, -1])];
        const candidates = [
          { x: xd, y: -rho - 1.0, anchor: 'middle' },
          { x: xd + 1.0, y: 0.9, anchor: 'start' },
          { x: xd - 1.0, y: 0.9, anchor: 'end' },
          { x: xd + 1.0, y: -rho - 1.0, anchor: 'start' },
          { x: xd - 1.0, y: -rho - 1.0, anchor: 'end' },
          { x: xd, y: -rho - 1.0 - 4.5, anchor: 'middle' },
          { x: xd, y: -rho - 1.0 - 9.0, anchor: 'middle' },
          { x: xd + 1.0, y: -rho - 1.0 - 4.5, anchor: 'start' },
          { x: xd - 1.0, y: -rho - 1.0 - 4.5, anchor: 'end' },
          { x: xd, y: -rho - 1.0 - 13.5, anchor: 'middle' },
        ];
        return { lines, arrows, candidates };
      });
      items.push({ symbol: F.symbolFor(key), text: `${key} ${F.valueWithTol(group, key)}`, options });
    };
    diameter('R1', cart.caseHead, 0, v.R1 / 2, [-3, -6, -9]);
    diameter('P1', cart.powderChamber, bodyStart, v.P1 / 2, [3, -3, 6, -6, 9, -9]);
    if (shoulderDrawn) {
      diameter('P2', cart.powderChamber, v.L1, v.P2 / 2, [3, -3, 6, -6, 9, -9]);
      diameter('H1', cart.collar, v.L2, v.H1 / 2, [3, -3, 6, -6, 9, -9]);
    }
    diameter('H2', cart.collar, v.L3, v.H2 / 2, [3, -3, 6, -6, 9, -9]);
    diameter('G1', cart.projectile, zn, G1 / 2, [3, -3, 6, -6, 9, -9]);
    if (grooveOK) diameter('E1', cart.caseHead, top + v.eMin, v.E1 / 2, [3, -3, 6, -6, 9, -9]);

    // Shoulder angle: arc at the apex of the cone, beyond the body-side corner.
    const alphaArc = [];
    if (shoulderDrawn && v.alpha !== undefined && v.S !== undefined) {
      const half = toRad(v.alpha) / 2;
      const rhoA = Math.hypot(v.S - v.L1, v.P2 / 2) + 1.5;
      const arc = [];
      for (let k = 0; k <= 24; k++) {
        const th = -half + (2 * half * k) / 24;
        arc.push([v.S - rhoA * Math.cos(th), -rhoA * Math.sin(th)]);
      }
      // Tangent of the arc in the direction of increasing theta; arrows point inward along the arc.
      const tangent = (th) => [Math.sin(th), -Math.cos(th)];
      const arrows = [
        arrowAt(arc[arc.length - 1], tangent(half).map((x) => -x)),
        arrowAt(arc[0], tangent(-half)),
      ];
      alphaArc.push(...arc);
      const top0 = arc[arc.length - 1];
      const bottom0 = arc[0];
      const alphaText = `α ${F.valueWithTol(cart.junctionCone, 'alpha')}`;
      items.push({
        symbol: 'α',
        text: alphaText,
        options: [{
          lines: [{ cls: 'dim', points: arc }],
          arrows,
          candidates: [
            { x: top0[0] - 1.0, y: top0[1] - 0.9, anchor: 'end' },
            { x: top0[0] - 1.0, y: top0[1] - 5.4, anchor: 'end' },
            { x: top0[0] - 1.0, y: bottom0[1] + 2.9, anchor: 'end' },
            { x: top0[0] + 1.0, y: top0[1] - 5.4, anchor: 'start' },
            { x: top0[0] - 1.0, y: top0[1] - 10.5, anchor: 'end' },
            { x: top0[0] + 1.0, y: bottom0[1] + 2.9, anchor: 'start' },
            { x: top0[0] - 1.0, y: bottom0[1] + 7.4, anchor: 'end' },
          ],
        }],
      });
    }

    const labels = placeItems(items, [
      ...fixedSegments, ...segmentsOfAll(rowLines), ...arrowEdges(rowArrows), ...segmentsOf(alphaArc, false),
    ]);
    const allLines = [
      { cls: 'centre', points: [[-6, 0], [v.L6 + 3, 0]] },
      ...drawn,
      ...labels.flatMap((l) => l.lines),
    ];
    const arrows = labels.flatMap((l) => l.arrows);
    const segments = [...fixedSegments, ...labels.flatMap((l) => l.lines.flatMap((x) => segmentsOf(x.points, x.closed))), ...arrowEdges(arrows)];

    const bottomY = Math.max(...labels.map((l) => l.rect.y1), rowY(rowsSpec.length - 1), Rmax);
    const xsAll = [-8, v.L6 + 3, ...labels.flatMap((l) => [l.rect.x0, l.rect.x1])];
    const x0 = Math.min(...xsAll);
    const x1 = Math.max(...xsAll);
    const cx = (x0 + x1) / 2;
    const tw = Math.max(x1 - x0, TITLE_MIN_W);
    const titleBlock = {
      x0: cx - tw / 2,
      x1: cx + tw / 2,
      y0: bottomY + 3,
      y1: bottomY + 3 + TITLE_H,
      lines: [rec.name, `C.I.P. table ${rec.tab}`, `Revised ${rec.revised}`, 'Dimensions in mm', 'Scale 1:1'],
    };
    const topY = Math.min(...labels.map((l) => l.rect.y0), -Rmax) - 1;

    return {
      ok: true,
      name: rec.name,
      rim,
      outline,
      bulletOutside,
      bullet: {
        shape: v.shape, s, zb, Lb, zn, m, tip: [tipR, v.L6], heeled, exposedR,
        heelR,
      },
      walls: { tn, tb, w },
      primer,
      missing,
      lines: allLines,
      arrows,
      labels,
      collisions: labelCollisions(labels, segments),
      titleBlock,
      bounds: {
        x0: Math.min(x0, titleBlock.x0) - 1,
        y0: topY,
        x1: Math.max(x1, titleBlock.x1) + 1,
        y1: titleBlock.y1 + 1,
      },
    };
  }

  return { rimType, buildDrawing };
});
