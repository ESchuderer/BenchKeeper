/* DOM rendering: start page (list, search, family filter), detail view, drawing, print. */
(function () {
  'use strict';

  const F = globalThis.CIP.format;
  const G = globalThis.CIP.geometry;
  const RECORDS = F.loadRecords(globalThis.CARTRIDGE_JSONL);
  const FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  const NS = 'http://www.w3.org/2000/svg';
  const app = document.getElementById('app');
  const state = { query: '', family: 'all' };

  function el(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value === undefined || value === null || value === false) continue;
      if (key === 'class') node.className = value;
      else node.setAttribute(key, value === true ? '' : String(value));
    }
    for (const child of children.flat()) {
      if (child === undefined || child === null || child === false) continue;
      node.append(child instanceof Node ? child : document.createTextNode(String(child)));
    }
    return node;
  }

  function svgEl(tag, attrs) {
    const node = document.createElementNS(NS, tag);
    for (const [key, value] of Object.entries(attrs || {})) node.setAttribute(key, String(value));
    return node;
  }

  const round = (n) => Math.round(n * 1000) / 1000;
  const pointList = (points) => points.map(([x, y]) => `${round(x)},${round(y)}`).join(' ');

  function renderRoute() {
    const route = F.parseRoute(location.hash);
    const record = route && RECORDS.find((r) => r.key === route.key);
    if (record) renderDetail(record);
    else renderList();
  }

  // ---- Start page ----

  function renderList() {
    document.title = 'Cartridges';
    const count = el('p', { class: 'count', 'aria-live': 'polite' });
    const items = el('ul', { class: 'cartridge-list' });
    const query = el('input', { id: 'q', type: 'search', autocomplete: 'off', spellcheck: 'false' });
    query.value = state.query;
    const family = el('select', { id: 'family' },
      FAMILIES.map((f) => el('option', { value: f }, f === 'all' ? 'All' : f)));
    family.value = state.family;

    const update = () => {
      const list = F.filterCartridges(RECORDS, state.query, state.family);
      count.textContent = F.countText(list.length);
      items.replaceChildren(...list.map((r) => el('li', {},
        el('a', { href: F.cartridgeHash(r.key) }, r.name),
        el('span', { class: 'family' }, r.family),
        el('span', { class: 'l3' }, `L3 ${F.valueWithTol(r.cartridge.lengths, 'L3')} ${F.unitFor('L3')}`))));
    };
    query.addEventListener('input', () => { state.query = query.value; update(); });
    family.addEventListener('change', () => { state.family = family.value; update(); });

    app.replaceChildren(
      el('h1', {}, 'Cartridges'),
      el('div', { class: 'controls' },
        el('label', { for: 'q' }, 'Search', query),
        el('label', { for: 'family' }, 'Family', family)),
      count,
      items,
    );
    update();
  }

  // ---- Drawing ----

  function drawingSVG(record, d) {
    const b = d.bounds;
    const width = b.x1 - b.x0;
    const hatchId = `hatch-${record.key}`;
    const svg = svgEl('svg', {
      viewBox: `${round(b.x0)} ${round(b.y0)} ${round(width)} ${round(b.y1 - b.y0)}`,
      role: 'img',
      'aria-label': `${record.name} drawing`,
      preserveAspectRatio: 'xMidYMid meet',
    });
    svg.style.setProperty('--w', `${round(width)}mm`);

    const defs = svgEl('defs', {});
    const pattern = svgEl('pattern', {
      id: hatchId, width: 1.2, height: 1.2, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)',
    });
    pattern.append(svgEl('line', { x1: 0, y1: 0, x2: 0, y2: 1.2, stroke: 'currentColor', 'stroke-width': 0.15 }));
    defs.append(pattern);
    svg.append(defs);

    for (const line of d.lines) {
      const tag = line.closed ? 'polygon' : 'polyline';
      const fill = line.cls === 'wall' ? `url(#${hatchId})` : 'none';
      svg.append(svgEl(tag, { class: line.cls, points: pointList(line.points), fill }));
    }
    for (const arrow of d.arrows) {
      svg.append(svgEl('polygon', { class: 'arrow', points: pointList(arrow) }));
    }
    for (const label of d.labels) {
      const text = svgEl('text', { x: round(label.x), y: round(label.y), 'text-anchor': label.anchor });
      text.textContent = label.text;
      svg.append(text);
    }

    const tb = d.titleBlock;
    svg.append(svgEl('rect', {
      class: 'titleblock', x: round(tb.x0), y: round(tb.y0), width: round(tb.x1 - tb.x0), height: round(tb.y1 - tb.y0),
    }));
    const [name, table, revised, dims, scale] = tb.lines;
    const row1 = tb.y0 + 4.2;
    const row2 = tb.y0 + 8.4;
    const row3 = tb.y0 + 12.6;
    const put = (x, y, anchor, text, cls) => {
      const t = svgEl('text', { x: round(x), y: round(y), 'text-anchor': anchor, class: cls });
      t.textContent = text;
      svg.append(t);
    };
    put(tb.x0 + 1, row1, 'start', name, 'title-text');
    put(tb.x1 - 1, row1, 'end', table);
    put(tb.x0 + 1, row2, 'start', revised);
    put(tb.x0 + 1, row3, 'start', dims);
    put(tb.x1 - 1, row3, 'end', scale);
    return svg;
  }

  // ---- Detail view ----

  function valuesSection(title, groups) {
    return el('section', { 'aria-label': title }, el('h2', {}, title), el('div', { class: 'groups' }, groups.map((g) => el('section', {},
      el('h3', {}, g.title),
      el('table', {},
        el('thead', {}, el('tr', {},
          el('th', { scope: 'col' }, 'Symbol'),
          el('th', { scope: 'col', class: 'value' }, 'Value'),
          el('th', { scope: 'col' }, 'Unit'))),
        el('tbody', {}, g.rows.map((row) => el('tr', {},
          el('td', { class: 'symbol' }, row.symbol),
          el('td', { class: 'value' }, row.value),
          el('td', { class: 'unit' }, row.unit)))))))));
  }

  function renderDetail(record) {
    document.title = `${record.name} | Cartridges`;
    const d = G.buildDrawing(record);
    const tables = F.buildValueTables(record);
    const group = (section) => tables.filter((t) => t.section === section).map((t) => ({ title: t.title, rows: t.rows }));

    const factsList = el('dl', { class: 'facts' }, F.buildFacts(record).map((f) => el('div', {},
      el('dt', {}, f.label),
      el('dd', {},
        f.link ? [f.text, ' (', el('a', { href: f.link.href }, f.link.text), ')'] : f.text,
        f.note ? el('div', { class: 'note' }, f.note) : null))));

    const missing = d.missing.map((m) => el('li', {}, `Not drawn: ${m.symbol} (${m.feature})`));
    const drawing = d.ok
      ? el('figure', { class: 'drawing' }, drawingSVG(record, d), missing.length ? el('ul', { class: 'missing' }, missing) : null)
      : el('figure', { class: 'drawing' }, el('p', {}, 'Drawing not available: required values missing.'),
        el('ul', { class: 'missing' }, missing));

    const printButton = el('button', { type: 'button', id: 'print' }, 'Print');
    printButton.addEventListener('click', () => window.print());

    app.replaceChildren(
      el('article', { class: 'detail' },
        el('header', {},
          el('h1', {}, record.name),
          el('nav', { class: 'actions' },
            el('a', { href: '#/' }, 'All cartridges'),
            printButton)),
        factsList,
        drawing,
        el('div', { class: 'values' },
          valuesSection('Cartridge', group('Cartridge')),
          valuesSection('Chamber', group('Chamber'))),
        el('footer', { class: 'source' }, `Source: C.I.P. TDCC, revised ${record.revised}`)),
    );
  }

  window.addEventListener('hashchange', renderRoute);
  renderRoute();
})();
