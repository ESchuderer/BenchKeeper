## Context

No code exists. The 25 records are fixed. The app must open from `file://` in Chromium, so browser scripts are classic scripts (ES modules are blocked from `file://` by CORS) and the data is embedded in a script file.

## Decisions

- **Files.** `data/cartridges.js` holds the 25 JSON lines verbatim as one template string, parsed at start-up. `js/format.js` (formatting, symbols, units, value tables, search, routing parse, header facts) and `js/geometry.js` (drawing model, label placement) hold pure logic, loaded in the browser and by `node --test` through a UMD wrapper. `js/render.js` holds DOM code (list, detail, SVG, print). `css/style.css` holds layout, dark theme and `@media print`.
- **Routing.** Hash routes: `#/` (list) and `#/cartridge/<key>` (detail). Works from `file://` and survives reload and bookmarks.
- **Dimension layout.** Axial dimensions (R, L1, L2, L3, L6) are rows below the drawing, diameters sit above it at their stations, and the angle arc sits at the cone apex. Each item tries its options in order and keeps the first clear one.
- **Coordinates.** Profile points are `[r, z]` as in the brief. SVG x = z, SVG y = -r for the outside view (above the axis) and +r for the section (below).
- **Fillets.** Shoulder corners use tangent arcs (tangent length = radius / tan(θ/2), clamped to half the adjacent segment).
- **Labels.** Each label has candidate positions. The first candidate whose text box does not hit the outline, any dimension or extension line, or another label is used. If none fits, the first candidate is kept and reported, so the test fails visibly.
- **Units not listed in the brief.** `S` (axial intersection of the shoulder cone with the axis, consistent with the published values), `u` (twist length per turn), `Fe`, `deltaL`, `h`, `s`, `b`, `G`, `F`, `Z` are lengths and shown in mm. `grH2O` is shown with its field name as the unit.
- **Angle values.** Shown with `°`, the unit cell is empty.
- **Tables.** Print uses a two-column grid of section tables so the page fits on one A4 sheet.
- **Test runner.** Node.js built-in `node:test`, no npm dependencies.

## Risks

- A straight case whose bullet is wider than the body wall `tb` (for example 45 Auto) will overlap the hatch in the section. This follows the brief's wall rule literally.
- Extension lines from groove and head features cross the outside silhouette. Thin lines only.
- Printed scale differs from 1:1 when the drawing is scaled to full page width.
