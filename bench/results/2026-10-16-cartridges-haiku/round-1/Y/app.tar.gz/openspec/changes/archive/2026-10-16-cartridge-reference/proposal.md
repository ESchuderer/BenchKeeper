## Why

Reloaders, gunsmiths and engineers need a browsable reference of C.I.P. cartridge and chamber dimensions with a true-to-scale drawing. The 25 records supplied with the brief (OpenBallistics e83db43, MIT) are the only data source.

## What Changes

- Static web app at `index.html` (plain HTML, CSS, JavaScript; no framework, build step, server code, runtime dependency or network request). Works from `file://` and from any static server.
- Start page: list of all cartridges (name link, family, L3), search by name and alternative names, family filter, count.
- Detail page with its own bookmarkable address: header facts, all cartridge and chamber values in tables, the 2D drawing, "Print" and "All cartridges" controls.
- Inline SVG drawing computed from the record values by the geometry rules in `specs/cartridge-drawing/spec.md`.
- Print output: one A4 portrait page, black on white, with source footer.
- Light and dark theme following the system setting.
- Dev-only test runner (`node --test`, built into Node.js 22). No npm runtime dependencies.

## Capabilities

### New Capabilities

- `cartridge-reference`: list, search, filter, detail view, values tables, routing, print and theme of the cartridge reference.
- `cartridge-drawing`: geometry, dimensions, section and label placement of the 2D cartridge drawing.

### Modified Capabilities

None. The repository has no existing specs.

## Impact

- New files: `index.html`, `css/style.css`, `js/format.js`, `js/geometry.js`, `js/render.js`, `data/cartridges.js`, `test/*.test.js`, `package.json`.
- Dependencies: none at runtime. Node.js 22 test runner for development.
- No network access, no fonts, no analytics.
