## 1. Data and project setup

- [x] 1.1 Write `data/cartridges.js` with the 25 JSON lines verbatim; add `package.json` with a `test` script (`node --test`) and no runtime dependencies
- [x] 1.2 Test: 25 records parse and keys are unique (`test/format.test.js`); every record has L3 and L6 (`test/geometry.test.js`)

## 2. Formatting and search (core)

- [x] 2.1 Tests first: value formatting (decimal point, tolerance after value, angle formats), symbol and unit mapping, table sections, search and family filter, hash route parsing
- [x] 2.2 Implement in `js/format.js`

## 3. Geometry (core)

- [x] 3.1 Tests first: rim type classification, chamfer and rimfire half-round, groove and belt ramp, shoulder fillets, bullet nose lengths and meplat, wall thicknesses, `w`, primer pocket, missing-value reporting
- [x] 3.2 Implement in `js/geometry.js`: outer profile, bullet, section walls and missing-value list
- [x] 3.3 Tests first: dimension placement, label non-overlap for all 25 records
- [x] 3.4 Implement dimensions, angle arc, title block data and label placement

## 4. Rendering and app

- [x] 4.1 `index.html`, `css/style.css` (light and dark, phone width, print)
- [x] 4.2 `js/render.js`: list with search and family filter, detail view, SVG drawing, Print button, routing
- [x] 4.3 Browser check with Playwright on `file://` and on a static server: list, search, filter, detail, reload, print preview, phone width, dark mode

## 5. Verify and ship

- [x] 5.1 `npm test` passes
- [x] 5.2 Code review of the branch before reporting done
- [x] 5.3 Commits by step, `openspec-archive-change` on the branch
