# cartridge-drawing Specification

## Purpose

True-to-scale 2D drawing of each cartridge, computed from the record values, for technical reading and printing. Geometry follows the rules in the change brief: `z` runs from the head face (z = 0) to the mouth; `r` is the radius.

## Requirements

### Requirement: Drawing form
The drawing SHALL be an inline SVG with accessible name "<name> drawing", where 1 user unit = 1 mm, the axis is horizontal, and the head is on the left. The upper half SHALL show the outside view and the lower half a section with the case walls hatched. A dash-dot centre line SHALL be drawn on the axis.

#### Scenario: Scale
- **WHEN** a cartridge with L6 = 84.84 is drawn
- **THEN** the drawing's horizontal extent from head face to tip is 84.84 user units

### Requirement: Rim type
The rim type SHALL be `belted` for family belted, `rimfire` for family rimfire, otherwise `rimmed` when R1/P1 >= 1.05, `rebated` when R1/P1 < 0.98, and `rimless` otherwise.

#### Scenario: Rim classification
- **WHEN** family is "rimless" and R1/P1 = 1.12
- **THEN** the rim type is rimmed

### Requirement: Outer profile
The outer profile SHALL start at the head face on the axis and run to the case mouth through the head chamfer, extractor groove (or step), body, shoulder (with corners rounded by r1 min and r2 when published) and neck, as specified in the change brief. The lower half SHALL be its mirror.

#### Scenario: Shoulder through published points
- **WHEN** a bottleneck case is drawn
- **THEN** the shoulder line passes through (P2/2, L1) and (H1/2, L2)

### Requirement: Bullet
The bullet SHALL extend from the mouth to the tip at z = L6 with shank diameter G1 and nose shape from `annotations.defaultBulletShape`, using the seating depth, cylinder length, meplat and nose rules of the brief. The outside view SHALL show the exposed part only. The section SHALL show the seated part inside the case.

#### Scenario: Heeled case
- **WHEN** H2 - G1 <= 0.015
- **THEN** the exposed bullet has the outside diameter H2 and the seated heel has diameter H2 - 2·tb

### Requirement: Section walls
Neck wall thickness SHALL be tn = (H2 - G1)/2 and body wall thickness SHALL be tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The solid head SHALL extend to z = w with w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb with a groove, or belt ramp end + tb on belted cases). Centrefire cases SHALL show a primer pocket with the diameter and depth given by primer type. Rimfire cases SHALL NOT have a pocket.

#### Scenario: Primer pocket
- **WHEN** primerType is "lr"
- **THEN** the pocket is 5.33 mm in diameter and 3.3 mm deep

### Requirement: Dimensions
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α where the value is published. Each label SHALL show the symbol and value, with the tolerance after the value when published (for example "L3 51.18", "L1 36.52 -0.2").

#### Scenario: Labels
- **WHEN** the drawing is rendered for any of the 25 records
- **THEN** no label overlaps another label, a dimension line or the drawn outline

### Requirement: Title block
The drawing SHALL carry a title block with the name, the C.I.P. table and revision date, "Dimensions in mm", and the scale "1:1".

#### Scenario: Title block
- **WHEN** the drawing is rendered
- **THEN** the title block shows the name, "C.I.P. table <tab>", "Revised <revised>", "Dimensions in mm" and "Scale 1:1"

### Requirement: Missing values
When a value a rule needs is missing, the drawing SHALL omit that feature, SHALL NOT invent a number, and SHALL state the missing value below the drawing.

#### Scenario: Missing extractor groove value
- **WHEN** E1 is not published
- **THEN** the groove is not drawn and "E1" is listed as missing

### Requirement: Scaling
The drawing SHALL scale to the container width on a phone and SHALL keep labels legible when printed at full width of an A4 page.

#### Scenario: Phone width
- **WHEN** the detail view is shown at 360 px width
- **THEN** the drawing fits the width without horizontal scrolling
