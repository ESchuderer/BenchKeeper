# cartridge-reference Specification

## Purpose

Browsable reference of 25 C.I.P. cartridges with their published cartridge and chamber values, for reloaders, gunsmiths and engineers. Data is fixed to the supplied records and is not fetched or edited.

## Requirements

### Requirement: Cartridge list
The start page SHALL list every record with its `name` as a link, its `family`, and its `L3` value with tolerance when published. The link text SHALL equal the record's `name` exactly and SHALL open the detail view of that record.

#### Scenario: All records listed
- **WHEN** the start page is opened
- **THEN** the page shows a heading "Cartridges" and 25 entries, each with a name link, family and L3

#### Scenario: Count text
- **WHEN** the list has n entries after filtering
- **THEN** the text "<n> cartridges" is shown (singular "1 cartridge" for n = 1)

### Requirement: Search
A field labelled "Search" SHALL filter the list as the user types, matching case-insensitively against `name` and every entry of `alternativeNames`. Whitespace runs in query and text SHALL be collapsed before matching.

#### Scenario: Alternative name match
- **WHEN** the user types `7,62 x 51`
- **THEN** "308 Win." is listed

#### Scenario: No match
- **WHEN** the query matches no name or alternative name
- **THEN** no cartridge is listed and the count reads "0 cartridges"

### Requirement: Family filter
A select labelled "Family" SHALL offer All, rimless, rimmed, belted, pistol and rimfire, and SHALL restrict the list to records of that `family`. The search and the family filter SHALL combine.

#### Scenario: Family selected
- **WHEN** the user selects "pistol"
- **THEN** only records with family "pistol" are listed

### Requirement: Detail view address
Each detail view SHALL have its own address of the form `#/cartridge/<key>`. Opening that address directly, reloading it, or bookmarking it SHALL show the same record. An unknown key SHALL show the start page.

#### Scenario: Reload
- **WHEN** the detail view of "223 Rem." is open and the page is reloaded
- **THEN** the detail view of "223 Rem." is shown again

### Requirement: Detail header facts
The detail view SHALL show the record's name as heading, then alternative names, family, category, primer type, C.I.P. table (`tab`), country, published and revised dates, pressure method, and the published water capacity (`grH2O` with its `note` when present) with a link to its `source` at `url`. Missing optional fields are omitted.

#### Scenario: Water capacity link
- **WHEN** a record with `publishedCapacity` is shown
- **THEN** the value and unit appear as "<grH2O> grH2O" and the source label links to `url`

### Requirement: Values tables
The detail view SHALL show every published field of `cartridge` and `chamber` in tables grouped by section, with columns "Symbol", "Value" and "Unit". Fields `<X>Tol` SHALL NOT be rows; they SHALL be shown after the value of `X`.

#### Scenario: Tolerance shown with value
- **WHEN** `cartridge.lengths` has `L1` 39.62 and `L1Tol` -0.2
- **THEN** the row for L1 shows "39.62 -0.2" and no row exists for L1Tol

#### Scenario: Angle formats
- **WHEN** an angle is a number of degrees
- **THEN** it is shown as "<n>°"
- **WHEN** an angle is `{degrees, minutes, seconds}`
- **THEN** it is shown as "<d>°<mm>'<ss>\""

#### Scenario: Number formats
- **WHEN** a value is shown
- **THEN** it uses a decimal point and no thousands separator (for example "51.18" and "4150")

#### Scenario: Symbols and units
- **WHEN** a field is listed
- **THEN** its symbol is the field name, except the mapped symbols "e min", "r1 min", "r1 max", "α", "α1", "β", "δ", "delta L" and "L3 + G"
- **AND** pressures Pmax, PK, PE are in bar, EE in J, M in g, Q in mm², N has no unit, and angles show no unit cell text, and all other lengths and diameters are in mm

### Requirement: Print
The "Print" button SHALL open the browser print dialog. A printed detail view SHALL be one A4 portrait page, black on white, containing the name, the drawing at full width, and the tables. Navigation, search, buttons and the theme SHALL NOT appear. A footer SHALL state "Source: C.I.P. TDCC, revised <revised>".

#### Scenario: Print layout
- **WHEN** the detail view is printed
- **THEN** the output is one A4 portrait page without buttons or links to navigation
- **AND** the footer reads "Source: C.I.P. TDCC, revised" followed by the record's revised date

### Requirement: Theme and layout
The interface SHALL follow the system light or dark setting, SHALL use tabular numbers, and SHALL be usable on a phone-width viewport. The interface text SHALL be English.

#### Scenario: Phone width
- **WHEN** the page is viewed at 360 px width
- **THEN** no horizontal page scrolling is needed for the list, the detail facts, or the drawing

### Requirement: Offline operation
The app SHALL work when `index.html` is opened from disk (`file://`) and when the folder is served by a static server. It SHALL make no network requests.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened from `file://` in Chromium
- **THEN** the list, search, filter, detail view and print work without a server
