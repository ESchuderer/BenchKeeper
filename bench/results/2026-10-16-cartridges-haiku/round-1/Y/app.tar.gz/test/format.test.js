'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../data/cartridges.js');
const F = require('../js/format.js');

const records = F.loadRecords(globalThis.CARTRIDGE_JSONL);
const byKey = (k) => records.find((r) => r.key === k);

test('loads the 25 records with unique keys', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
});

test('numbers keep a decimal point and no grouping', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(-0.2), '-0.2');
});

test('angles show degrees or degrees, minutes and seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), `1°30'00"`);
});

test('symbols follow the brief', () => {
  const cases = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', E1: 'E1', Pmax: 'Pmax',
  };
  for (const [key, symbol] of Object.entries(cases)) assert.equal(F.symbolFor(key), symbol, key);
});

test('units follow the brief', () => {
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('N'), '');
  assert.equal(F.unitFor('alpha'), '');
  assert.equal(F.unitFor('L1'), 'mm');
  assert.equal(F.unitFor('G1'), 'mm');
});

test('value tables are grouped by section with tolerances merged', () => {
  const tables = F.buildValueTables(byKey('223_rem'));
  const titles = tables.map((t) => `${t.section} / ${t.title}`);
  assert.deepEqual(titles.slice(0, 3), ['Cartridge / Case head', 'Cartridge / Collar', 'Cartridge / Junction cone']);
  assert.ok(titles.includes('Chamber / Rifling'));
  const lengths = tables.find((t) => t.title === 'Lengths' && t.section === 'Cartridge');
  assert.deepEqual(lengths.rows.find((r) => r.symbol === 'L1'), { symbol: 'L1', value: '36.52 -0.2', unit: 'mm' });
  assert.ok(!tables.some((t) => t.rows.some((r) => /Tol$/.test(r.symbol))), 'no tolerance rows');
});

test('angle rows use the angle format and no unit', () => {
  const tables = F.buildValueTables(byKey('223_rem'));
  const head = tables.find((t) => t.title === 'Case head');
  assert.deepEqual(head.rows.find((r) => r.symbol === 'β'), { symbol: 'β', value: '35°', unit: '' });
  const rifling = tables.find((t) => t.title === 'Rifling');
  assert.deepEqual(rifling.rows.find((r) => r.symbol === 'i'), { symbol: 'i', value: `3°10'36"`, unit: '' });
});

test('search matches name and alternative names, case and spacing insensitive', () => {
  const keys = (list) => list.map((r) => r.key).sort();
  assert.deepEqual(keys(F.filterCartridges(records, '7,62 x 51', 'all')), ['308_win']);
  assert.deepEqual(keys(F.filterCartridges(records, '7,62   X 51', 'all')), ['308_win']);
  assert.deepEqual(keys(F.filterCartridges(records, '22 wmr', 'all')), ['22_win_mag_r_f']);
  assert.equal(F.filterCartridges(records, '', 'all').length, 25);
  assert.equal(F.filterCartridges(records, 'zzz', 'all').length, 0);
});

test('family filter combines with search', () => {
  assert.equal(F.filterCartridges(records, '', 'pistol').length, 6);
  assert.equal(F.filterCartridges(records, '', 'rimless').length, 12);
  assert.equal(F.filterCartridges(records, '22 l', 'rimless').length, 0);
  assert.equal(F.filterCartridges(records, '22 l', 'rimfire').length, 1);
});

test('count text', () => {
  assert.equal(F.countText(0), '0 cartridges');
  assert.equal(F.countText(1), '1 cartridge');
  assert.equal(F.countText(25), '25 cartridges');
});

test('hash routes', () => {
  assert.deepEqual(F.parseRoute('#/cartridge/223_rem'), { key: '223_rem' });
  assert.equal(F.parseRoute('#/'), null);
  assert.equal(F.parseRoute(''), null);
  assert.equal(F.parseRoute('#/cartridge/%E0%A4%A'), null);
  assert.equal(F.cartridgeHash('6_5_creedmoor'), '#/cartridge/6_5_creedmoor');
});

test('header facts', () => {
  const facts = Object.fromEntries(F.buildFacts(byKey('308_win')).map((f) => [f.label, f]));
  assert.equal(facts['Alternative names'].text, '308 Winchester, 7,62 x 51');
  assert.equal(facts['C.I.P. table'].text, 'I');
  assert.equal(facts['Published'].text, '1984-06-14');
  const water = facts['Water capacity'];
  assert.equal(water.text, '56 grH2O');
  assert.equal(water.note, 'Lapua brass measures 55.8 (lapua-308)');
  assert.equal(water.link.text, 'kwk');
  assert.equal(water.link.href, 'http://kwk.us/cases.html');
  assert.equal(F.buildFacts(byKey('223_rem')).some((f) => f.label === 'Alternative names'), false);
});
