'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../data/cartridges.js');
const F = require('../js/format.js');
const G = require('../js/geometry.js');

const records = F.loadRecords(globalThis.CARTRIDGE_JSONL);
const byKey = (k) => records.find((r) => r.key === k);
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${a} != ${b}`);

// Minimal record builder for synthetic cases; values overridden per test.
function synth(over = {}) {
  const base = {
    key: 'synth', name: 'synth', family: 'rimless',
    annotations: { category: 'rifle', defaultBulletShape: 'pointy', primerType: 'lr' },
    cartridge: {
      caseHead: { E: 3, E1: 8, R: 1, R1: 10, beta: 35, eMin: 0.8, f: 0.4 },
      collar: { H1: 7, H2: 8 },
      junctionCone: {},
      lengths: { L1: 30, L2: 34, L3: 40, L6: 60 },
      powderChamber: { P1: 9.8, P2: 9 },
      projectile: { G1: 7.8 },
    },
    chamber: {},
  };
  return Object.assign(base, over);
}
const withCart = (cart) => synth({ cartridge: cart });

test('rim type follows family and R1/P1', () => {
  assert.equal(G.rimType(byKey('300_win_mag')), 'belted');
  assert.equal(G.rimType(byKey('22_long_rifle')), 'rimfire');
  assert.equal(G.rimType(byKey('9_3_x_74_r')), 'rimmed');
  assert.equal(G.rimType(byKey('9_mm_luger')), 'rimless');
  assert.equal(G.rimType(synth({ cartridge: { caseHead: { R1: 9 }, powderChamber: { P1: 10 } } })), 'rebated');
});

test('outer profile starts on the axis at the head face and ends at the mouth', () => {
  const d = G.buildDrawing(byKey('223_rem'));
  assert.deepEqual(d.outline[0], [0, 0]);
  assert.deepEqual(d.outline[d.outline.length - 1], [6.43 / 2, 44.7]);
});

test('head chamfer and rim corner use the brief formulas', () => {
  const d = G.buildDrawing(byKey('223_rem'));
  // (R1/2 - min(f·tanβ, R1/4), 0), (R1/2, f), (R1/2, R)
  near(d.outline[1][0], 9.6 / 2 - Math.min(0.45 * Math.tan(35 * Math.PI / 180), 9.6 / 4));
  near(d.outline[1][1], 0);
  assert.deepEqual(d.outline[2], [4.8, 0.45]);
  assert.deepEqual(d.outline[3], [4.8, 1.14]);
});

test('extractor groove: radial step, floor, ramp to body start', () => {
  const d = G.buildDrawing(byKey('223_rem'));
  assert.deepEqual(d.outline.slice(4, 7), [[8.43 / 2, 1.14], [8.43 / 2, 1.9], [9.58 / 2, 3.13]]);
});

test('belted groove: ramp at delta to the belt, belt to E, step to P1/2', () => {
  const d = G.buildDrawing(byKey('300_win_mag'));
  const tan35 = Math.tan(35 * Math.PI / 180);
  const zr = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / tan35;
  const i = d.outline.findIndex((p) => p[0] === 13.51 / 2 && Math.abs(p[1] - zr) < 1e-9);
  assert.ok(i > 0, 'belt ramp end point present');
  assert.deepEqual(d.outline[i + 1], [13.51 / 2, 5.59]);
  assert.deepEqual(d.outline[i + 2], [13.03 / 2, 5.59]);
});

test('rimfire rim edge is a half-round of radius min(R/2, (R1-P1)/2)', () => {
  const d = G.buildDrawing(byKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const outer = d.outline.reduce((m, p) => (p[0] > m[0] ? p : m), [0, 0]);
  near(outer[0], 7.06 / 2, 1e-6);
  near(outer[1], rho, 1e-3);
});

test('shoulder passes through the published points when corners are not rounded', () => {
  const rec = withCart({
    caseHead: { E: 3, E1: 8, R: 1, R1: 10, beta: 35, eMin: 0.8, f: 0.4 },
    collar: { H1: 7, H2: 8 },
    junctionCone: { alpha: 40 },
    lengths: { L1: 30, L2: 34, L3: 40, L6: 60 },
    powderChamber: { P1: 9.8, P2: 9 },
    projectile: { G1: 7.8 },
  });
  const d = G.buildDrawing(rec);
  assert.deepEqual(d.outline.find((p) => p[1] === 30), [4.5, 30]);
  assert.deepEqual(d.outline.find((p) => p[1] === 34), [3.5, 34]);
  assert.equal(d.missing.length, 0);
});

test('shoulder corners are rounded with r1 min and r2 when published', () => {
  const d = G.buildDrawing(byKey('223_rem'));
  assert.ok(!d.outline.some((p) => p[0] === 9.0 / 2 && p[1] === 36.52), 'sharp body corner removed');
  assert.ok(!d.outline.some((p) => p[0] === 6.43 / 2 && p[1] === 39.55), 'sharp neck corner removed');
  assert.ok(d.outline.some((p) => p[1] > 36.52 && p[1] < 36.7 && p[0] > 4.4), 'fillet points present');
});

test('straight case without alpha or L1 runs to the mouth', () => {
  const d = G.buildDrawing(byKey('9_mm_luger'));
  assert.deepEqual(d.outline[d.outline.length - 1], [9.65 / 2, 19.15]);
  assert.equal(d.outline.length, 8);
  assert.ok(!d.outline.some((p) => p[1] > 27 && p[1] < 30), 'no shoulder');
});

test('pointy bullet: seating depth, cylinder end, meplat and tip', () => {
  const d = G.buildDrawing(byKey('223_rem'));
  const zb = 44.7 - 5.7;
  const Lb = 57.4 - zb;
  const m = Math.max(0.08 * 5.7, 1.27);
  assert.equal(d.bullet.zb, zb);
  near(d.bullet.zn, zb + 0.4 * Lb);
  assert.deepEqual(d.bullet.tip, [m / 2, 57.4]);
  const tipPoint = d.bulletOutside[d.bulletOutside.length - 2];
  assert.deepEqual(tipPoint, [m / 2, 57.4]);
});

test('pointy ogive radius follows the brief formula and passes through the tip', () => {
  const d = G.buildDrawing(byKey('223_rem'));
  const G1 = 5.7, m = Math.max(0.08 * G1, 1.27), a = G1 / 2 - m / 2, n = 57.4 - d.bullet.zn;
  const rho = (a * a + n * n) / (2 * a);
  const rc = G1 / 2 - rho;
  const tip = d.bullet.tip;
  near(Math.hypot(tip[0] - rc, tip[1] - d.bullet.zn), rho, 1e-6);
});

test('rounded pistol bullet: seated depth 0.4·G1 and cylinder to 0.65·Lb', () => {
  const d = G.buildDrawing(byKey('9_mm_luger'));
  const G1 = 9.03, zb = 19.15 - 0.4 * G1, Lb = 29.69 - zb;
  near(d.bullet.zb, zb);
  near(d.bullet.zn, zb + 0.65 * Lb);
  near(d.bullet.tip[0], 0.15 * G1 / 2);
});

test('heeled case: exposed bullet has the case outside diameter, heel has the inside diameter', () => {
  const d = G.buildDrawing(byKey('22_long_rifle'));
  assert.equal(d.bullet.heeled, true);
  near(d.bullet.exposedR, 5.72 / 2);
  near(d.bullet.heelR, 5.72 / 2 - d.walls.tb);
});

test('wall thicknesses follow the brief', () => {
  const d = G.buildDrawing(byKey('223_rem'));
  near(d.walls.tn, (6.43 - 5.7) / 2);
  near(d.walls.tb, 0.6);
  const e = G.buildDrawing(byKey('9_3_x_74_r'));
  near(e.walls.tb, Math.min(Math.max(1.3 * (8.6 - 7.92) / 2, 0.6), 0.35 * 11.35 / 2));
});

test('solid head ends at w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb)', () => {
  const d = G.buildDrawing(byKey('223_rem'));
  near(d.walls.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + 0.6));
  const r = G.buildDrawing(byKey('22_long_rifle'));
  near(r.walls.w, 2.5);
  assert.equal(r.primer.diameter, 0);
});

test('primer pockets by primer type', () => {
  const sr = G.buildDrawing(byKey('223_rem')).primer;
  assert.deepEqual([sr.diameter, sr.depth], [4.45, 3.04]);
  const lr = G.buildDrawing(byKey('308_win')).primer;
  assert.deepEqual([lr.diameter, lr.depth], [5.33, 3.3]);
  const lp = G.buildDrawing(byKey('44_rem_mag')).primer;
  assert.deepEqual([lp.diameter, lp.depth], [5.33, 3.04]);
  const sp = G.buildDrawing(byKey('9_mm_luger')).primer;
  assert.deepEqual([sp.diameter, sp.depth], [4.45, 3.04]);
});

test('missing values are reported and not invented', () => {
  const rec = synth();
  delete rec.cartridge.caseHead.E1;
  const d = G.buildDrawing(rec);
  assert.ok(d.missing.some((m) => m.key === 'E1'));
  assert.ok(!d.labels.some((l) => l.text.startsWith('E1 ')));
  assert.deepEqual(d.outline[d.outline.length - 1], [8 / 2, 40]);
});

test('unknown bullet nose is reported and no drawing is made', () => {
  const rec = synth({ annotations: { category: 'rifle', defaultBulletShape: 'round_nose', primerType: 'lr' } });
  const d = G.buildDrawing(rec);
  assert.equal(d.ok, false);
  assert.ok(d.missing.some((m) => m.key === 'defaultBulletShape'));
});

test('required values missing: no drawing, reason given', () => {
  const rec = synth();
  delete rec.cartridge.powderChamber.P1;
  const d = G.buildDrawing(rec);
  assert.equal(d.ok, false);
  assert.ok(d.missing.some((m) => m.key === 'P1'));
});

test('every record draws with all required dimensions', () => {
  for (const rec of records) {
    const d = G.buildDrawing(rec);
    assert.equal(d.ok, true, rec.key);
    for (const sym of ['L3', 'L6', 'R1', 'P1', 'G1']) {
      assert.ok(d.labels.some((l) => l.symbol === sym), `${rec.key} ${sym}`);
    }
  }
});

test('labels do not overlap each other, the outline or dimension lines (all 25 records)', () => {
  for (const rec of records) {
    const d = G.buildDrawing(rec);
    assert.deepEqual(d.collisions, [], rec.key);
  }
});

test('title block carries name, table, revision, dimensions and scale', () => {
  const d = G.buildDrawing(byKey('300_win_mag'));
  assert.deepEqual(d.titleBlock.lines, [
    '300 Win. Mag.', 'C.I.P. table III', 'Revised 2002-05-15', 'Dimensions in mm', 'Scale 1:1',
  ]);
});
