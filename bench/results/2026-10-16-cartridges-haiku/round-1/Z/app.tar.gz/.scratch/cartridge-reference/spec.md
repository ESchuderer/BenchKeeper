## Problem Statement

Reloaders, gunsmiths and engineers need a quick, accurate reference for C.I.P. cartridges: dimensions, tolerances, pressures and a to-scale drawing. The data exists (OpenBallistics, MIT), but a self-contained page that opens from disk, works offline and prints a clean A4 sheet is not available.

## Solution

A static web app of 25 cartridge records. A start page lists the cartridges with search and family filter. Each cartridge has a detail page (its own bookmarkable address) with identity, C.I.P. table, water capacity, all cartridge and chamber values grouped by section, and an SVG drawing computed from the values, true to scale. A print view produces one A4 portrait page.

## User Stories

1. As a reloader, I want to see the list of all 25 cartridges with their family and case length, so that I can find the one I need.
2. As a reloader, I want each cartridge name to open its detail view, so that I can read its dimensions.
3. As a reloader, I want to search by name or alternative name while typing, so that `7,62 x 51` finds `308 Win.`.
4. As a reloader, I want to filter by family (All, rimless, rimmed, belted, pistol, rimfire), so that I can narrow the list.
5. As a reader, I want the count of listed cartridges shown, so that I know how many results the filter gives.
6. As a gunsmith, I want the detail view to show the C.I.P. table, country, published and revised dates and pressure method, so that I can judge the source.
7. As a reloader, I want the published water capacity with its source link, so that I can check the powder space.
8. As a reader, I want values shown as published with their tolerances next to them, so that I see the allowed range without a separate row.
9. As an engineer, I want all cartridge and chamber values in grouped tables with Symbol, Value and Unit columns, so that I can compare them with other sources.
10. As an engineer, I want a to-scale 2D drawing with upper outside view and lower section, so that I can see the case and bullet geometry.
11. As an engineer, I want dimension lines with symbol and value for the principal dimensions, so that I can read the drawing without the tables.
12. As an engineer, I want a note saying which value is missing when a feature cannot be drawn, so that I know the drawing is incomplete and why.
13. As a user on a phone, I want the drawing to scale to the screen width and the tables to stay usable, so that I can read it on the shop floor.
14. As a user in dark mode, I want the page to follow my system setting, so that it is comfortable to read at night.
15. As a user, I want a Print button that prints one A4 portrait black-on-white page with a header, drawing, tables and source footer, so that I can keep a paper copy.
16. As a user, I want a link back to the full list from the detail view, so that I can navigate without the browser back button.
17. As a user, I want the detail view address to survive a reload and to be bookmarkable, so that I can return to the same cartridge.
18. As a user opening the file from disk, I want the app to work with no server and no network, so that it works offline.

## Implementation Decisions

- Data is a classic script file that defines the 25 records as a JavaScript array, so that the app works from `file://` (no fetch). The records are used exactly as given.
- Navigation uses the URL hash. A cartridge's address is `#/cartridge/<key>`. The list is `#/` (or empty hash).
- Modules: a formatting module (values, angles, symbols, units, tolerance attachment, section grouping); a geometry module (rim type, outer profile, section walls, primer pocket, bullet, missing-value list) that returns plain point data; a drawing module that turns geometry plus values into an SVG string with dimension lines; an application module that renders the list and detail views and handles search, filter, routing and print.
- Geometry convention: every point is `(r, z)` in mm; `z` is axial from the head face, `r` radial. The outer profile is built from axis to mouth and mirrored.
- Rim type: belted and rimfire from family; otherwise R1/P1 >= 1.05 rimmed, < 0.98 rebated, else rimless.
- Rimfire rim edge is a half-round of radius min(R/2, (R1-P1)/2), outermost point at R1/2.
- Chamfer only when beta and f are both published and beta < 90°.
- Extractor groove only when E and E1 are published. Belted groove: ramp at angle delta to the axis up to R3/2, belt to z = E, step to P1/2.
- Heeled case: when H2 - G1 <= 0.015, the exposed bullet has diameter H2 and the seated heel has diameter H2 - 2·tb.
- Section walls: tn = (H2 - G1)/2 (0 if heeled-equivalent), tb = min(max(1.3·tn, 0.6), 0.35·P1/2). Wall thickness is tb along the body, tn along the neck, linear across the shoulder. For straight cases the wall blends from tb at the body start to tn at the mouth, and stays tb throughout when heeled.
- Solid head to z = w, with w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb with a groove, belt ramp end + tb on belted cases).
- Primer pocket on centrefire cases only: diameter 4.45 (sp, spm, sr) or 5.33 (lp, lpm, lr, lrm); depth 3.04 (sp, spm, sr, lp, lpm) or 3.3 (lr, lrm).
- Bullet: seating depth s and cylinder factor k from the shape and category table in the brief. Rimfire is treated as rifle for the rifle/rimfire rows. Nose geometry per shape: pointy tangent ogive, rounded quarter ellipse, flat and semi_wadcutter straight cones, each with its meplat diameter m.
- Missing values: a feature whose rule needs a missing value is omitted and the drawing lists the missing value names. No numbers are invented.
- Angles: a number is shown as `40°`; an object is shown as `39°59'49"` (minutes and seconds zero-padded to two digits).
- Numbers are shown with JavaScript's shortest decimal form (51.18, 4150, 9), with no thousands separator. Tolerances (`<X>Tol`) are attached to row X in the same section, displayed as `value tol`.
- Units: mm for lengths and diameters (including unlisted fields such as G, Fe, h, s, b, u), bar for Pmax, PK, PE, J for EE, g for M, mm² for Q, empty for count N and for angles (the degree sign belongs to the value), gr H2O for the water capacity.
- Symbols: field name, except the mapping in the brief (e min, r1 min, r1 max, α, α1, β, δ, delta L, L3 + G).
- Styling: system colour scheme via prefers-color-scheme; print is forced light via @media print; A4 portrait @page; no web fonts; tabular numerals.
- No network requests, no CDNs, no runtime dependencies. Dev tooling only: node:test (built into Node 22) runs tests with no npm dependency.

## Testing Decisions

- Good tests check external behaviour: a value formats to the published text, a geometry function returns the expected points for a known cartridge, the list filters to the expected names.
- Pure modules are tested directly under `node --test`. Expected values come from the brief's worked examples and from hand calculation with the rule formulas (for example the 223 Rem. shoulder slope gives alpha 46°).
- The app-level DOM behaviour (search, filter, routing, print) is verified in a real Chromium from `file://` where available.
- Prior art: none in this repo; this is a new project.

## Out of Scope

- Editing or adding cartridge data; fetching data from the network.
- Displaying the `annotations.confidence`, `implausible` and `defaultBullet` fields beyond what the brief lists (drawing uses defaultBulletShape only).
- Chamber geometry in the drawing (the drawing uses the cartridge values as the brief specifies).
- Service worker, offline cache, analytics.

## Further Notes

- The brief is the source of truth. Where the brief is silent, the decisions above are recorded so they can be reviewed.
- Data source: OpenBallistics, MIT, commit e83db43.
