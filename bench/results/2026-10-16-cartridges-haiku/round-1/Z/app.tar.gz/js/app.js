/*
 * Application: start page (list, search, family filter) and detail view
 * (identity, C.I.P. table, drawing, grouped value tables, print).
 * Built with DOM APIs; the only markup strings are generated SVG and are
 * escaped by the drawing module.
 */
(function () {
  'use strict';

  var CIP = window.CIP;
  var CARTRIDGES = window.CIP_DATA.CARTRIDGES;
  var app = document.getElementById('app');
  var footer = document.getElementById('print-footer');
  var byKey = {};
  CARTRIDGES.forEach(function (r) { byKey[r.key] = r; });

  var state = { query: '', family: 'All' }; // kept while navigating back to the list

  function el(tag, attrs, kids) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === 'text') node.textContent = attrs[k];
        else if (k === 'class') node.className = attrs[k];
        else node.setAttribute(k, attrs[k]);
      });
    }
    (kids || []).forEach(function (kid) {
      if (kid === null || kid === undefined || kid === false) return;
      node.appendChild(typeof kid === 'string' ? document.createTextNode(kid) : kid);
    });
    return node;
  }

  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  function lengthText(rec) {
    return CIP.format.valueWithTol(rec.cartridge.lengths, 'L3') + ' mm';
  }

  /* ---------- Start page ---------- */

  function renderList() {
    document.title = 'Cartridges';
    footer.textContent = '';
    clear(app);

    var count = el('p', { class: 'count', 'aria-live': 'polite' });
    var tbody = el('tbody');
    var query = el('input', { type: 'search', id: 'q', autocomplete: 'off', spellcheck: 'false', value: state.query });
    var family = el('select', { id: 'family' }, CIP.catalog.FAMILIES.map(function (f) {
      var opt = el('option', { value: f, text: f });
      if (f === state.family) opt.selected = true;
      return opt;
    }));

    function refresh() {
      state.query = query.value;
      state.family = family.value;
      var rows = CIP.catalog.filterCartridges(CARTRIDGES, { query: state.query, family: state.family });
      clear(tbody);
      rows.forEach(function (rec) {
        tbody.appendChild(el('tr', null, [
          el('td', null, [el('a', { href: CIP.catalog.routeFor(rec.key), text: rec.name })]),
          el('td', { text: rec.family }),
          el('td', { class: 'num', text: lengthText(rec) })
        ]));
      });
      count.textContent = CIP.catalog.countText(rows.length);
    }

    query.addEventListener('input', refresh);
    family.addEventListener('change', refresh);

    app.appendChild(el('h1', { text: 'Cartridges' }));
    var filters = el('form', { class: 'filters', role: 'search' }, [
      el('label', { class: 'field' }, [el('span', { text: 'Search' }), query]),
      el('label', { class: 'field' }, [el('span', { text: 'Family' }), family])
    ]);
    filters.addEventListener('submit', function (e) { e.preventDefault(); });
    app.appendChild(filters);
    app.appendChild(count);
    app.appendChild(el('table', { class: 'list' }, [
      el('thead', null, [el('tr', null, [
        el('th', { scope: 'col', text: 'Name' }),
        el('th', { scope: 'col', text: 'Family' }),
        el('th', { scope: 'col', text: 'L3' })
      ])]),
      tbody
    ]));
    refresh();
  }

  /* ---------- Detail view ---------- */

  function factRow(term, value) {
    return [el('dt', { text: term }), el('dd', null, Array.isArray(value) ? value : [value])];
  }

  function sectionTable(group) {
    return el('section', { class: 'group' }, [
      el('h3', { text: group.title }),
      el('table', { class: 'values' }, [
        el('thead', null, [el('tr', null, [
          el('th', { scope: 'col', text: 'Symbol' }),
          el('th', { scope: 'col', text: 'Value' }),
          el('th', { scope: 'col', text: 'Unit' })
        ])]),
        el('tbody', null, group.rows.map(function (row) {
          return el('tr', null, [
            el('td', { class: 'sym', text: row.symbol }),
            el('td', { class: 'num', text: row.value }),
            el('td', { class: 'unit', text: row.unit })
          ]);
        }))
      ])
    ]);
  }

  function drawingBlock(rec) {
    var d = CIP.drawing.computeDrawing(rec);
    var wrap = el('div', { class: 'drawing' });
    if (d.drawable) {
      var holder = el('div', { class: 'drawing-svg' });
      holder.innerHTML = CIP.drawing.renderSvg(d, 'd-' + rec.key);
      wrap.appendChild(holder);
    } else {
      wrap.appendChild(el('p', { class: 'drawing-missing', text: 'Drawing not available. Missing: ' + d.missing.join(', ') }));
    }
    var notes = [];
    (d.missing || []).forEach(function (m) { notes.push('Missing: ' + m); });
    (d.notes || []).forEach(function (n) { notes.push(n); });
    if (d.warnings && d.warnings.length) {
      notes.push('Label overlap could not be avoided: ' + d.warnings.join(', '));
    }
    if (notes.length) {
      wrap.appendChild(el('ul', { class: 'drawing-notes' }, notes.map(function (n) {
        return el('li', { text: n });
      })));
    }
    return wrap;
  }

  function waterValue(rec) {
    var pc = rec.annotations.publishedCapacity;
    if (!pc) return 'not published';
    var parts = [CIP.format.formatNumber(pc.grH2O) + ' gr H2O · source: '];
    parts.push(pc.url ? el('a', { href: pc.url, text: pc.source }) : pc.source);
    if (pc.note) parts.push(' (' + pc.note + ')');
    return parts;
  }

  function renderDetail(key) {
    var rec = byKey[key];
    clear(app);
    footer.textContent = '';
    if (!rec) {
      document.title = 'Not found · Cartridges';
      app.appendChild(el('p', { class: 'nav' }, [el('a', { href: '#/', text: 'All cartridges' })]));
      app.appendChild(el('h1', { text: 'Cartridge not found' }));
      app.appendChild(el('p', { text: 'No cartridge with the key "' + key + '".' }));
      return;
    }
    document.title = rec.name + ' · Cartridges';
    var A = rec.annotations;
    var source = 'Source: C.I.P. TDCC, revised ' + rec.revised + '. Data: OpenBallistics (MIT).';
    footer.textContent = source;

    var sections = CIP.format.buildSections(rec);
    var toolbar = el('div', { class: 'toolbar print-hide' }, [
      el('a', { class: 'nav', href: '#/', text: 'All cartridges' }),
      el('button', { type: 'button', class: 'button', text: 'Print' })
    ]);
    toolbar.querySelector('button').addEventListener('click', function () { window.print(); });

    var head = el('header', { class: 'detail-head' }, [
      el('h1', { text: rec.name }),
      rec.alternativeNames && rec.alternativeNames.length
        ? el('p', { class: 'alt', text: 'Also known as: ' + rec.alternativeNames.join(', ') })
        : null
    ]);

    var facts = el('dl', { class: 'facts' }, [].concat(
      factRow('Family', rec.family),
      factRow('Category', A.category),
      factRow('Primer type', A.primerType),
      factRow('C.I.P. table', rec.tab),
      factRow('Country', rec.country),
      factRow('Published', rec.published),
      factRow('Revised', rec.revised),
      factRow('Pressure method', rec.pressureMethod),
      factRow('Water capacity', waterValue(rec))
    ));

    var cartridge = el('section', { class: 'values-block' }, [el('h2', { text: 'Cartridge' })].concat(
      sections.cartridge.map(sectionTable)));
    var chamber = el('section', { class: 'values-block' }, [el('h2', { text: 'Chamber' })].concat(
      sections.chamber.map(sectionTable)));

    app.appendChild(toolbar);
    app.appendChild(head);
    app.appendChild(facts);
    app.appendChild(drawingBlock(rec));
    app.appendChild(el('div', { class: 'values-wrap' }, [cartridge, chamber]));
  }

  /* ---------- Routing ---------- */

  function route() {
    var r = CIP.catalog.parseRoute(window.location.hash);
    if (r.view === 'detail') {
      renderDetail(r.key);
      window.scrollTo(0, 0);
    } else {
      renderList();
    }
  }

  window.addEventListener('hashchange', route);
  route();
})();
