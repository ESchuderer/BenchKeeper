/*
 * Start-page logic and routes: search, family filter, count text, hash routes.
 */
(function (root, factory) {
  var api = factory(root.CIP && root.CIP.format ? root.CIP.format : require('./format.js'));
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.catalog = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (F) {
  'use strict';

  var FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  function searchable(rec) {
    var names = [rec.name].concat(rec.alternativeNames || []);
    return names.map(function (n) { return F.normalizeQuery(n); });
  }

  function filterCartridges(list, opts) {
    var q = F.normalizeQuery(opts.query);
    var fam = opts.family || 'All';
    return list.filter(function (rec) {
      if (fam !== 'All' && rec.family !== fam) return false;
      if (!q) return true;
      return searchable(rec).some(function (n) { return n.indexOf(q) !== -1; });
    });
  }

  function countText(n) {
    return n + (n === 1 ? ' cartridge' : ' cartridges');
  }

  function routeFor(key) {
    return '#/cartridge/' + encodeURIComponent(key);
  }

  function parseRoute(hash) {
    var m = /^#\/cartridge\/(.+)$/.exec(hash || '');
    if (m) {
      var key = m[1];
      try {
        key = decodeURIComponent(key);
      } catch (e) {
        // malformed escape: keep the raw key, the detail view reports it as not found
      }
      return { view: 'detail', key: key };
    }
    return { view: 'list' };
  }

  return {
    FAMILIES: FAMILIES,
    filterCartridges: filterCartridges,
    countText: countText,
    routeFor: routeFor,
    parseRoute: parseRoute
  };
});
