/*
 * Cartridge drawing: layout of dimension lines and labels, and the SVG markup.
 * Units: 1 SVG user unit = 1 mm. x = z (head face at x = 0, head on the left),
 * the upper half (y < 0) is the outside view, the lower half (y > 0) the section.
 */
(function (root, factory) {
  var api = factory(root.CIP ? root.CIP : (typeof require === 'function' ? {
    format: require('./format.js'),
    geometry: require('./geometry.js')
  } : {}));
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.drawing = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (CIP) {
  'use strict';

  var F = CIP.format;
  var G = CIP.geometry;

  var FS = 3.0;          // label font size, mm
  var GAP = 0.9;         // gap between feature and extension line
  var ARROW_L = 1.3;     // arrowhead length
  var ARROW_W = 0.45;    // arrowhead half width
  var CHAR_W = 0.6 * FS; // monospace advance (tabular digits)

  function valueText(group, key) {
    return F.valueWithTol(group, key);
  }

  function seg(x1, y1, x2, y2) { return { x1: x1, y1: y1, x2: x2, y2: y2 }; }

  function arrowAt(P, Q) {
    // tip at P, pointing away from Q
    var dx = P[0] - Q[0], dy = P[1] - Q[1];
    var l = Math.hypot(dx, dy) || 1;
    dx /= l; dy /= l;
    var bx = P[0] - dx * ARROW_L, by = P[1] - dy * ARROW_L;
    var nx = -dy * ARROW_W, ny = dx * ARROW_W;
    return [[P[0], P[1]], [bx + nx, by + ny], [bx - nx, by - ny]];
  }

  /* Build the drawing model for one cartridge. */
  function computeDrawing(rec) {
    var geo = G.buildGeometry(rec);
    if (!geo.drawable) {
      return { drawable: false, missing: geo.missing, notes: geo.notes, name: rec.name };
    }
    var c = rec.cartridge || {};
    var head = c.caseHead || {}, coll = c.collar || {}, jc = c.junctionCone || {};
    var len = c.lengths || {}, pc = c.powderChamber || {}, proj = c.projectile || {};
    var f = geo.features, v = geo.values, bullet = geo.bullet;
    var rr = v.R1 / 2;
    var H2h = v.H2 / 2;
    var arrows = [];
    var dims = [];

    var maxR = 0;
    geo.silhouette.forEach(function (p) { if (p[0] > maxR) maxR = p[0]; });
    geo.sectionPolygon.forEach(function (p) { if (p[0] > maxR) maxR = p[0]; });
    var maxZ = bullet ? v.L6 : v.L3;

    var levelT1 = -(maxR + 3);
    var levelT2 = -(maxR + 3 + 5.5);
    var levelB1 = maxR + 3;
    var levelB2 = maxR + 3 + 5.5;
    var levelB3 = maxR + 3 + 11;

    function addDim(d) { dims.push(d); }

    /* Axial dimension between z1 and z2 at a horizontal level. */
    function axial(id, label, z1, z2, level, fromA, fromB) {
      var sgn = Math.sign(level - fromA[1]) || -1;
      var sgnB = Math.sign(level - fromB[1]) || -1;
      var ext = [seg(fromA[0], fromA[1], fromA[0], level + sgn * 1), seg(fromB[0], fromB[1], fromB[0], level + sgnB * 1)];
      var dim = seg(z1, level, z2, level);
      var a1 = arrowAt([z1, level], [z2, level]);
      var a2 = arrowAt([z2, level], [z1, level]);
      addDim({ id: id, label: label, lines: ext.concat([dim]), arrows: [a1, a2], kind: 'axial', level: level, z1: z1, z2: z2, top: level < 0 });
    }

    /* Diameter dimension: vertical line at xc, extension lines from feature at z, radius r. */
    function radial(id, label, z, r, xc, lane) {
      var yT = -(r + GAP), yB = r + GAP;
      var sgn = Math.sign(xc - z) || 1;
      var ext = [seg(z, yT, xc + sgn * 1, yT), seg(z, yB, xc + sgn * 1, yB)];
      var dim = seg(xc, yT, xc, yB);
      var a1 = arrowAt([xc, yT], [xc, yB]);
      var a2 = arrowAt([xc, yB], [xc, yT]);
      var lines = ext.concat([dim]);
      if (lane) {
        lines.push(seg(xc, lane.y + 1.6, xc, yT));
      }
      addDim({ id: id, label: label, lines: lines, arrows: [a1, a2], kind: 'radial', xc: xc, z: z, r: r, lane: lane });
    }

    // Axial dimensions above the outline (outside view).
    axial('L3', 'L3 ' + valueText(len, 'L3'), 0, v.L3, levelT1, [0, -(rr + GAP)], [v.L3, -(H2h + GAP)]);
    if (bullet) {
      var tipR = bullet.m / 2;
      axial('L6', 'L6 ' + valueText(len, 'L6'), 0, v.L6, levelT2, [0, -(rr + GAP)], [v.L6, -(tipR + GAP)]);
    }
    // Axial dimensions below the outline (section side).
    if (geo.dims.R !== null) {
      var rAt = f.rimfireRadius !== null ? rr - f.rimfireRadius : rr;
      axial('R', 'R ' + valueText(head, 'R'), 0, v.R, levelB1, [0, rr + GAP], [v.R, rAt + GAP]);
    }
    if (f.shoulder) {
      axial('L1', 'L1 ' + valueText(len, 'L1'), 0, v.L1, levelB2, [0, rr + GAP], [v.L1, v.P2 / 2 + GAP]);
      axial('L2', 'L2 ' + valueText(len, 'L2'), 0, v.L2, levelB3, [0, rr + GAP], [v.L2, v.H1 / 2 + GAP]);
    }

    // Diameter dimensions. Left: rim and groove floor. Right: body, shoulder, neck, bullet.
    var colLeft1 = -8, colLeft2 = -4;
    var rowY = function (k) { return levelT2 - 4 - k * (FS + 1.8); };
    radial('R1', 'R1 ' + valueText(head, 'R1'), 0, rr, colLeft1, { x: colLeft1 - 1, y: rowY(0), anchor: 'end' });
    if (f.groove) {
      var zg = v.R + v.eMin / 2;
      radial('E1', 'E1 ' + valueText(head, 'E1'), zg, v.E1 / 2, colLeft2, { x: colLeft2 - 1, y: rowY(1), anchor: 'start' });
    }
    var colStart = maxZ + 5, step = 12;
    var order = [];
    if (bullet) order.push({ id: 'G1', z: bullet.zn, r: bullet.rExp, label: 'G1 ' + valueText(proj, 'G1') });
    order.push({ id: 'H2', z: v.L3, r: H2h, label: 'H2 ' + valueText(coll, 'H2') });
    if (f.shoulder) {
      order.push({ id: 'H1', z: v.L2, r: v.H1 / 2, label: 'H1 ' + valueText(coll, 'H1') });
      order.push({ id: 'P2', z: v.L1, r: v.P2 / 2, label: 'P2 ' + valueText(pc, 'P2') });
    }
    order.push({ id: 'P1', z: f.zB, r: v.P1 / 2, label: 'P1 ' + valueText(pc, 'P1') });
    order.forEach(function (o, k) {
      var xc = colStart + step * k;
      radial(o.id, o.label, o.z, o.r, xc, { x: xc, y: rowY(k % 2), anchor: 'middle' });
    });

    // Shoulder angle: an arc at the apex of the shoulder cone, between the axis and the shoulder line.
    if (f.shoulder && v.alpha !== undefined) {
      var half = (v.alpha / 2) * Math.PI / 180;
      var tanH = Math.tan(half);
      var apexZ = v.L1 + (v.P2 / 2) / tanH;
      var rho = 0.5 * (apexZ - v.L1);
      var pA = [apexZ - rho, 0];
      var pB = [apexZ - rho * Math.cos(half), rho * Math.sin(half)];
      var arcPts = [];
      for (var i = 0; i <= 12; i++) {
        var phi = Math.PI - half * i / 12;
        arcPts.push([apexZ + rho * Math.cos(phi), -(rho * Math.sin(phi))]);
      }
      var arcSegs = [];
      for (var j = 1; j < arcPts.length; j++) {
        arcSegs.push(seg(arcPts[j - 1][0], arcPts[j - 1][1], arcPts[j][0], arcPts[j][1]));
      }
      var tA = arrowAt([pA[0], -pA[1]], [pA[0] + 1, -pA[1]]);
      var tB = arrowAt([pB[0], -pB[1]], arcPts[arcPts.length - 2]);
      var mid = arcPts[Math.floor(arcPts.length / 2)];
      var alphaLane = { x: mid[0], y: rowY(2), anchor: 'middle' };
      arcSegs.push(seg(alphaLane.x, alphaLane.y + 1.6, mid[0], mid[1]));
      addDim({
        id: 'alpha', label: 'α ' + F.formatAngle(jc.alpha), lines: arcSegs, arrows: [tA, tB], kind: 'angle',
        apex: [apexZ, 0], rho: rho, lane: alphaLane
      });
    }

    // Centre line (dash-dot) from the head face to the tip.
    var centre = { x1: 0, y1: 0, x2: maxZ + 4, y2: 0 };

    // Outline and section paths (in SVG coordinates).
    var upper = geo.silhouette.map(function (p) { return [p[1], -p[0]]; });
    var lower = geo.sectionPolygon.map(function (p) { return [p[1], p[0]]; });
    var bulletLower = geo.bulletSection ? geo.bulletSection.map(function (p) { return [p[1], p[0]]; }) : null;

    // Collision geometry: outline segments plus every dimension segment.
    var outlineSegs = [];
    function addPolySegs(pl, out) {
      for (var i = 1; i < pl.length; i++) out.push(seg(pl[i - 1][0], pl[i - 1][1], pl[i][0], pl[i][1]));
    }
    addPolySegs(upper, outlineSegs);
    addPolySegs(lower.concat([lower[0]]), outlineSegs);
    if (bulletLower) addPolySegs(bulletLower.concat([bulletLower[0]]), outlineSegs);

    var allDimSegs = [];
    dims.forEach(function (d) { d.lines.forEach(function (s) { allDimSegs.push(s); }); });

    // Label placement.
    var placed = [];
    var warnings = [];
    dims.forEach(function (d) {
      var cands = labelCandidates(d);
      var chosen = null;
      for (var k = 0; k < cands.length && !chosen; k++) {
        var box = boxFor(cands[k]);
        if (!collides(box, placed, outlineSegs, allDimSegs)) chosen = cands[k];
      }
      if (!chosen) {
        chosen = cands[0];
        warnings.push(d.id);
      }
      d.label_at = chosen;
      d.box = boxFor(chosen);
      placed.push(d.box);
    });

    function labelCandidates(d) {
      var out = [];
      var n = d.label.length;
      var w = n * CHAR_W;
      function cand(x, y, anchor) { return { x: x, y: y, anchor: anchor, text: d.label, w: w }; }
      if (d.kind === 'axial') {
        // Extension lines overhang the dimension line by 1 mm, away from the object;
        // labels sit beyond that overhang, centred or hard against either end.
        var mid = (d.z1 + d.z2) / 2;
        var lv = d.level;
        var rows = d.top
          ? [lv - 2.2, lv - 2.2 - FS - 1.4]
          : [lv + 3.5, lv - 2.2, lv + 3.5 + FS + 1.4];
        rows.forEach(function (y) {
          out.push(cand(mid, y, 'middle'));
          if (d.top) {
            out.push(cand(d.z1 + 1.5, y, 'start'));
            out.push(cand(d.z2 - 1.5, y, 'end'));
          } else {
            out.push(cand(d.z2 + 1.5, y, 'start'));
            out.push(cand(d.z1 - 1.5, y, 'end'));
          }
        });
      } else if (d.kind === 'radial') {
        if (d.lane) {
          out.push(cand(d.lane.x, d.lane.y, d.lane.anchor));
          return out;
        }
        out.push(cand(d.xc + 1.5, FS / 2, 'start'));
        out.push(cand(d.xc - 1.5, FS / 2, 'end'));
        [-1, 1].forEach(function (s) {
          var yy = s * (d.r + 1.5 + FS);
          out.push(cand(d.xc + 1.5, yy + FS / 2, 'start'));
          out.push(cand(d.xc - 1.5, yy + FS / 2, 'end'));
        });
        out.push(cand(d.xc + 1.5, -(d.r + 1.5 + FS) + FS / 2, 'start'));
      } else {
        out.push(cand(d.lane.x, d.lane.y, d.lane.anchor));
      }
      return out;
    }

    function boxFor(c) {
      var x0 = c.anchor === 'start' ? c.x : c.anchor === 'end' ? c.x - c.w : c.x - c.w / 2;
      return { x0: x0, x1: x0 + c.w, y0: c.y - FS * 0.75, y1: c.y + FS * 0.2 };
    }

    function collides(box, others, outline, dimSegs) {
      var pad = 0.3;
      var b = { x0: box.x0 - pad, x1: box.x1 + pad, y0: box.y0 - pad, y1: box.y1 + pad };
      for (var i = 0; i < others.length; i++) {
        var o = others[i];
        if (b.x0 < o.x1 && o.x0 < b.x1 && b.y0 < o.y1 && o.y0 < b.y1) return true;
      }
      var all = outline.concat(dimSegs);
      for (var s = 0; s < all.length; s++) {
        if (segHitsBox(all[s], b)) return true;
      }
      return false;
    }

    function segHitsBox(s, b) {
      var n = Math.max(2, Math.ceil(Math.hypot(s.x2 - s.x1, s.y2 - s.y1) / 0.2));
      for (var i = 0; i <= n; i++) {
        var t = i / n;
        var x = s.x1 + (s.x2 - s.x1) * t, y = s.y1 + (s.y2 - s.y1) * t;
        if (x > b.x0 && x < b.x1 && y > b.y0 && y < b.y1) return true;
      }
      return false;
    }

    // View box: geometry, dimensions, labels and the title block.
    var xs = [], ys = [];
    function grow(x, y) { xs.push(x); ys.push(y); }
    upper.forEach(function (p) { grow(p[0], p[1]); });
    lower.forEach(function (p) { grow(p[0], p[1]); });
    var segs = outlineSegs.concat(allDimSegs);
    segs.forEach(function (s) { grow(s.x1, s.y1); grow(s.x2, s.y2); });
    placed.forEach(function (b) { grow(b.x0, b.y0); grow(b.x1, b.y1); });
    var minX = Math.min.apply(null, xs) - 2, maxX = Math.max.apply(null, xs) + 2;
    var minY = Math.min.apply(null, ys) - 2, maxY = Math.max.apply(null, ys) + 2;
    var titleTop = maxY + 4;
    var titleH = 17;
    var vb = { x: minX, y: minY, w: maxX - minX, h: (titleTop + titleH) - minY };

    return {
      drawable: true,
      name: rec.name,
      geo: geo,
      viewBox: vb,
      upper: upper,
      lower: lower,
      bulletLower: bulletLower,
      centre: centre,
      dims: dims,
      warnings: warnings,
      missing: geo.missing,
      notes: geo.notes,
      titleBlock: {
        x: minX, y: titleTop, w: vb.w, h: titleH,
        lines: [
          { text: rec.name, bold: true },
          { text: 'C.I.P. table ' + rec.tab + ' · revised ' + rec.revised },
          { text: 'Rim: ' + geo.rimType + ' · Dimensions in mm · Scale 1:1 (1 mm = 1 unit)' }
        ]
      }
    };
  }

  function pts(pl) {
    return pl.map(function (p, i) { return (i ? 'L' : 'M') + String(round3(p[0])) + ' ' + String(round3(p[1])); }).join(' ');
  }
  function round3(n) { return Math.round(n * 1000) / 1000; }

  function escapeXml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* SVG markup for a computed drawing. `id` must be unique on the page. */
  function renderSvg(d, id) {
    if (!d.drawable) return '';
    var vb = d.viewBox;
    var out = [];
    out.push('<svg class="cartridge-drawing" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' +
      escapeXml(d.name) + ' drawing" viewBox="' + [vb.x, vb.y, vb.w, vb.h].map(round3).join(' ') + '">');
    out.push('<title>' + escapeXml(d.name) + ' drawing</title>');
    out.push('<defs><pattern id="' + id + '-hatch" patternUnits="userSpaceOnUse" width="1.6" height="1.6" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="1.6" class="hatch"/></pattern></defs>');
    var c = d.centre;
    out.push('<line class="centre" x1="' + round3(c.x1) + '" y1="0" x2="' + round3(c.x2) + '" y2="0"/>');
    out.push('<path class="outline" d="' + pts(d.upper) + '"/>');
    out.push('<path class="cut" fill="url(#' + id + '-hatch)" d="' + pts(d.lower) + ' Z"/>');
    if (d.bulletLower) out.push('<path class="cut" fill="url(#' + id + '-hatch)" d="' + pts(d.bulletLower) + ' Z"/>');
    var dimD = [];
    var arrowD = [];
    d.dims.forEach(function (dim) {
      dim.lines.forEach(function (s) {
        dimD.push('M' + round3(s.x1) + ' ' + round3(s.y1) + 'L' + round3(s.x2) + ' ' + round3(s.y2));
      });
      dim.arrows.forEach(function (tri) {
        arrowD.push('M' + tri.map(function (p) { return round3(p[0]) + ' ' + round3(p[1]); }).join('L') + 'Z');
      });
    });
    out.push('<path class="dim" d="' + dimD.join('') + '"/>');
    out.push('<path class="arrow" d="' + arrowD.join('') + '"/>');
    d.dims.forEach(function (dim) {
      var l = dim.label_at;
      out.push('<text class="label" x="' + round3(l.x) + '" y="' + round3(l.y) + '" text-anchor="' + l.anchor + '">' + escapeXml(dim.label) + '</text>');
    });
    var tb = d.titleBlock;
    out.push('<g class="titleblock"><rect x="' + round3(tb.x) + '" y="' + round3(tb.y) + '" width="' + round3(tb.w) + '" height="' + round3(tb.h) + '" class="tb-frame"/>');
    tb.lines.forEach(function (ln, i) {
      out.push('<text class="tb-text' + (ln.bold ? ' tb-bold' : '') + '" x="' + round3(tb.x + 2) + '" y="' + round3(tb.y + 5 + i * 5) + '">' + escapeXml(ln.text) + '</text>');
    });
    out.push('</g></svg>');
    return out.join('');
  }

  return {
    computeDrawing: computeDrawing,
    renderSvg: renderSvg,
  };
});
