/*
 * Formatting for cartridge values: numbers, angles, symbols, units,
 * tolerances, and the grouped section tables shown in the detail view.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.format = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var ANGLE_KEYS = { alpha: true, alpha1: true, beta: true, delta: true, i: true };

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '', grH2O: 'gr H2O' };

  var SECTION_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling'
  };

  var CARTRIDGE_SECTIONS = ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile'];
  var CHAMBER_SECTIONS = ['barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling'];

  function formatNumber(n) {
    return String(n);
  }

  function isAngle(v) {
    return typeof v === 'number' || (v !== null && typeof v === 'object' && 'degrees' in v);
  }

  function pad2(n) {
    return String(n).padStart(2, '0');
  }

  function formatAngle(v) {
    if (typeof v === 'number') {
      return String(v) + '°';
    }
    var m = v.minutes === undefined ? 0 : v.minutes;
    var s = v.seconds === undefined ? 0 : v.seconds;
    return String(v.degrees) + '°' + pad2(m) + "'" + pad2(s) + '"';
  }

  function formatValue(key, v) {
    return ANGLE_KEYS[key] && isAngle(v) ? formatAngle(v) : formatNumber(v);
  }

  function unitFor(key) {
    if (ANGLE_KEYS[key]) {
      return '';
    }
    if (Object.prototype.hasOwnProperty.call(UNITS, key)) {
      return UNITS[key];
    }
    return 'mm';
  }

  function symbolFor(key) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, key) ? SYMBOLS[key] : key;
  }

  function sectionTitle(id) {
    return SECTION_TITLES[id] || id;
  }

  /* Value text with its tolerance: "36.52 -0.2". Tolerance is <key>Tol in the same group. */
  function valueWithTol(group, key) {
    var text = formatValue(key, group[key]);
    var tolKey = key + 'Tol';
    if (Object.prototype.hasOwnProperty.call(group, tolKey)) text += ' ' + formatNumber(group[tolKey]);
    return text;
  }

  function buildGroup(obj, id) {
    var rows = [];
    if (!obj || typeof obj !== 'object') {
      return { id: id, title: sectionTitle(id), rows: rows };
    }
    Object.keys(obj).forEach(function (key) {
      if (/Tol$/.test(key)) {
        return; // tolerances are shown next to their value, never as a row
      }
      var v = obj[key];
      if (!isAngle(v)) {
        return;
      }
      rows.push({ key: key, symbol: symbolFor(key), value: valueWithTol(obj, key), unit: unitFor(key) });
    });
    return { id: id, title: sectionTitle(id), rows: rows };
  }

  function buildSections(rec) {
    var c = rec.cartridge || {};
    var ch = rec.chamber || {};
    var cartridge = CARTRIDGE_SECTIONS.map(function (id) {
      return buildGroup(c[id], id);
    }).filter(function (g) { return g.rows.length > 0; });
    var chamber = CHAMBER_SECTIONS.map(function (id) {
      return buildGroup(ch[id], id);
    }).filter(function (g) { return g.rows.length > 0; });
    return { cartridge: cartridge, chamber: chamber };
  }

  /* Text used for search: lower case, no spaces, decimal comma read as dot. */
  function normalizeQuery(text) {
    return String(text || '').toLowerCase().replace(/\s+/g, '').replace(/,/g, '.');
  }

  return {
    formatNumber: formatNumber,
    isAngle: isAngle,
    formatAngle: formatAngle,
    formatValue: formatValue,
    unitFor: unitFor,
    symbolFor: symbolFor,
    sectionTitle: sectionTitle,
    buildSections: buildSections,
    valueWithTol: valueWithTol,
    normalizeQuery: normalizeQuery
  };
});
