/*
 * Cartridge geometry in millimetres. Every point is [r, z]:
 *   z runs along the axis from the head face (z = 0) to the mouth,
 *   r is the radius (half the diameter).
 * The outer half-profile runs from the axis at the head face to the mouth
 * and is mirrored at the axis by the drawing. Missing values are reported
 * by name in `missing`; the feature that needs them is left out.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CIP = root.CIP || {};
    root.CIP.geometry = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var DEG = Math.PI / 180;
  var HEEL_LIMIT = 0.015; // H2 - G1 at or below this (mm): heeled bullet
  var ARC_STEPS = 12;

  function isNum(v) {
    return typeof v === 'number' && Number.isFinite(v);
  }

  function toDeg(v) {
    if (isNum(v)) {
      return v;
    }
    if (v && typeof v === 'object' && isNum(v.degrees)) {
      return v.degrees + (v.minutes || 0) / 60 + (v.seconds || 0) / 3600;
    }
    return undefined;
  }

  function rimType(rec) {
    var fam = rec.family;
    if (fam === 'belted') return 'belted';
    if (fam === 'rimfire') return 'rimfire';
    var head = (rec.cartridge || {}).caseHead || {};
    var P1 = ((rec.cartridge || {}).powderChamber || {}).P1;
    if (!isNum(head.R1) || !isNum(P1) || P1 === 0) return 'unknown';
    var ratio = head.R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  /* Primer pocket: diameter and depth by C.I.P. primer type. */
  var POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  function pocketFor(primer, rim) {
    if (rim === 'rimfire' || !primer || !POCKET_DIAMETER[primer]) return null;
    return { diameter: POCKET_DIAMETER[primer], depth: POCKET_DEPTH[primer] };
  }

  /* Expand items into points, rounding those with a fillet radius. */
  function expandItems(items) {
    var out = [];
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (it.fillet > 0 && i > 0 && i < items.length - 1) {
        var arc = filletPoints(items[i - 1].p, it.p, items[i + 1].p, it.fillet);
        arc.forEach(function (p) { out.push(p); });
      } else {
        out.push(it.p);
      }
    }
    return out;
  }

  /* Tangent arc of radius rho at corner V between segments A->V and V->B. */
  function filletPoints(A, V, B, rho) {
    var ux = V[0] - A[0], uy = V[1] - A[1];
    var lenA = Math.hypot(ux, uy);
    var vx = B[0] - V[0], vy = B[1] - V[1];
    var lenB = Math.hypot(vx, vy);
    if (lenA === 0 || lenB === 0) return [V];
    ux /= lenA; uy /= lenA; vx /= lenB; vy /= lenB;
    var cos = Math.max(-1, Math.min(1, ux * vx + uy * vy));
    var theta = Math.acos(cos); // deflection angle
    if (theta < 1e-9) return [V];
    var t = rho * Math.tan(theta / 2);
    var tMax = 0.5 * Math.min(lenA, lenB);
    if (t > tMax) {
      t = tMax;
      rho = t / Math.tan(theta / 2);
    }
    var T1 = [V[0] - t * ux, V[1] - t * uy];
    var T2 = [V[0] + t * vx, V[1] + t * vy];
    // inward normal at T1: perpendicular to u, on the side of v
    var dot = vx * ux + vy * uy;
    var nx = vx - dot * ux, ny = vy - dot * uy;
    var nl = Math.hypot(nx, ny);
    nx /= nl; ny /= nl;
    var C = [T1[0] + rho * nx, T1[1] + rho * ny];
    var a1 = Math.atan2(T1[1] - C[1], T1[0] - C[0]);
    var a2 = Math.atan2(T2[1] - C[1], T2[0] - C[0]);
    var sweep = a2 - a1;
    while (sweep > Math.PI) sweep -= 2 * Math.PI;
    while (sweep < -Math.PI) sweep += 2 * Math.PI;
    var pts = [];
    for (var i = 0; i <= ARC_STEPS; i++) {
      var a = a1 + sweep * i / ARC_STEPS;
      pts.push([C[0] + rho * Math.cos(a), C[1] + rho * Math.sin(a)]);
    }
    return pts;
  }

  /* Radius of the polyline at height z (first matching segment). */
  function radiusAt(pl, z) {
    for (var i = 1; i < pl.length; i++) {
      var z0 = pl[i - 1][1], z1 = pl[i][1];
      if (z0 === z1) continue;
      if ((z0 <= z && z <= z1) || (z1 <= z && z <= z0)) {
        var t = (z - z0) / (z1 - z0);
        return pl[i - 1][0] + t * (pl[i][0] - pl[i - 1][0]);
      }
    }
    return undefined;
  }

  var BULLET_SHAPES = { pointy: true, rounded: true, flat: true, semi_wadcutter: true };

  function buildBullet(rec, v, notes, tb) {
    var shape = (rec.annotations || {}).defaultBulletShape;
    var category = (rec.annotations || {}).category;
    if (!BULLET_SHAPES[shape]) {
      notes.push('defaultBulletShape missing or unknown: bullet not drawn');
      return null;
    }
    var pistol = category === 'pistol';
    var G1 = v.G1, L3 = v.L3, L6 = v.L6;
    var heeled = (v.H2 - G1) <= HEEL_LIMIT;
    var Dx = heeled ? v.H2 : G1;               // exposed diameter
    var s, k, m;
    if (shape === 'pointy') {
      s = 1.0 * G1; k = 0.40; m = Math.max(0.08 * G1, 1.27);
    } else if (shape === 'rounded') {
      s = (pistol ? 0.4 : 0.8) * G1; k = pistol ? 0.65 : 0.55; m = 0.15 * G1;
    } else if (shape === 'flat') {
      s = (pistol ? 0.4 : 0.8) * G1; k = pistol ? 0.70 : 0.60; m = 0.55 * G1;
    } else {
      s = 0.6 * G1; k = 0.78; m = 0.6 * G1;
    }
    var zb = L3 - s;
    var Lb = L6 - zb;
    var zn = zb + k * Lb;
    var n = L6 - zn;
    var R = Dx / 2;
    var mr = m / 2;
    var rho = null;
    var nose = [];
    if (shape === 'pointy') {
      var d = R - mr;
      rho = (d * d + n * n) / (2 * d);
      var rc = R - rho;
      var phiEnd = Math.atan2(L6 - zn, mr - rc);
      for (var i = 0; i <= 16; i++) {
        var phi = phiEnd * i / 16;
        nose.push([rc + rho * Math.cos(phi), zn + rho * Math.sin(phi)]);
      }
    } else if (shape === 'rounded') {
      var a = R - mr, bb = n;
      for (var j = 0; j <= 16; j++) {
        var f = (Math.PI / 2) * j / 16;
        nose.push([mr + a * Math.cos(f), zn + bb * Math.sin(f)]);
      }
    } else {
      nose.push([mr, L6]);
    }
    nose[nose.length - 1] = [mr, L6];
    var rSeat = heeled ? (v.H2 - 2 * tb) / 2 : R;
    var prof = [[rSeat, zb], [rSeat, L3]];
    if (rSeat !== R) prof.push([R, L3]);
    prof.push([R, zn]);
    nose.forEach(function (p) { prof.push(p); });
    prof.push([0, L6]);
    return {
      shape: shape,
      heeled: heeled,
      G1: G1,
      s: s, k: k, m: m,
      zb: zb, Lb: Lb, zn: zn, n: n,
      rho: rho,
      rSeat: rSeat,
      rExp: R,
      L3: L3,
      profile: prof
    };
  }

  function buildGeometry(rec) {
    var missing = [];
    var notes = [];
    var c = rec.cartridge || {};
    var head = c.caseHead || {};
    var coll = c.collar || {};
    var jc = c.junctionCone || {};
    var len = c.lengths || {};
    var pc = c.powderChamber || {};
    var proj = c.projectile || {};
    var v = {
      R1: head.R1, R: head.R, E: head.E, E1: head.E1, eMin: head.eMin, f: head.f,
      beta: toDeg(head.beta), delta: toDeg(head.delta), R3: head.R3,
      H1: coll.H1, H2: coll.H2,
      L1: len.L1, L2: len.L2, L3: len.L3, L6: len.L6,
      P1: pc.P1, P2: pc.P2,
      G1: proj.G1,
      alpha: toDeg(jc.alpha), r1Min: jc.r1Min, r2: jc.r2
    };
    var essential = ['R1', 'P1', 'L3', 'H2', 'R'].filter(function (k) { return !isNum(v[k]); });
    if (essential.length) {
      return { drawable: false, missing: essential.map(function (k) { return k + ' (required)'; }), notes: [] };
    }

    var type = rimType(rec);
    var rr = v.R1 / 2, rb = v.P1 / 2;
    var primer = (rec.annotations || {}).primerType;
    var pocket = pocketFor(primer, type);
    if (type !== 'rimfire' && !primer) notes.push('primerType missing: no primer pocket drawn');

    var items = [];
    var features = { groove: false, belt: false, shoulder: false, chamfer: false, heeled: false, pocket: pocket, rimfireRadius: null };
    var zB, rampEnd = null, zRimTop = null;

    items.push({ p: [0, 0] });

    if (type === 'rimfire') {
      var rho = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
      features.rimfireRadius = rho;
      var rc = rr - rho;
      for (var i = 0; i <= ARC_STEPS; i++) {
        var th = -Math.PI / 2 + Math.PI * i / ARC_STEPS;
        items.push({ p: [rc + rho * Math.cos(th), rho + rho * Math.sin(th)] });
      }
      zRimTop = 2 * rho;
      if (Math.abs(rb - rc) > 1e-12) items.push({ p: [rb, zRimTop] });
      zB = zRimTop;
    } else {
      var chamfer = isNum(v.beta) && v.beta < 90;
      if (chamfer && !isNum(v.f)) {
        missing.push('f (chamfer not drawn: square corner)');
        chamfer = false;
      }
      if (chamfer) {
        var x = Math.min(v.f * Math.tan(v.beta * DEG), rr / 2);
        items.push({ p: [rr - x, 0] });
        items.push({ p: [rr, v.f] });
        features.chamfer = true;
      } else {
        items.push({ p: [rr, 0] });
      }
      zRimTop = v.R;
      items.push({ p: [rr, zRimTop] });

      var grooveOK = isNum(v.E) && isNum(v.E1);
      if (grooveOK && !isNum(v.eMin)) {
        missing.push('eMin (groove not drawn: step at rim)');
        grooveOK = false;
      }
      if (!grooveOK && type === 'belted' && (!isNum(v.E) || !isNum(v.E1))) {
        missing.push('E or E1 (belt not drawn: no groove)');
      }
      if (grooveOK) {
        features.groove = true;
        var floorEnd = zRimTop + v.eMin;
        items.push({ p: [v.E1 / 2, zRimTop] });
        items.push({ p: [v.E1 / 2, floorEnd] });
        if (type === 'belted') {
          if (isNum(v.R3)) {
            features.belt = true;
            var Rb = v.R3 / 2;
            if (isNum(v.delta) && v.delta > 0) {
              rampEnd = floorEnd + (Rb - v.E1 / 2) / Math.tan(v.delta * DEG);
            } else {
              missing.push('delta (belt ramp drawn straight to the belt)');
              rampEnd = v.E;
            }
            items.push({ p: [Rb, rampEnd] });
            if (rampEnd !== v.E) items.push({ p: [Rb, v.E] });
          } else {
            missing.push('R3 (belt not drawn)');
            rampEnd = v.E;
          }
        } else {
          rampEnd = v.E;
        }
        items.push({ p: [rb, v.E] });
        zB = v.E;
      } else {
        items.push({ p: [rb, zRimTop] });
        zB = zRimTop;
      }
    }
    items.push({ p: [rb, zB] }); // body start (de-duplicated below if equal)

    // Body, shoulder and neck.
    var shoulderData = isNum(v.alpha) && isNum(v.L1) && isNum(v.L2);
    if (shoulderData && isNum(v.P2) && isNum(v.H1)) {
      features.shoulder = true;
      if (!isNum(v.r1Min)) notes.push('r1Min missing: body corner of the shoulder is sharp');
      if (!isNum(v.r2)) notes.push('r2 missing: neck corner of the shoulder is sharp');
      items.push({ p: [v.P2 / 2, v.L1], fillet: isNum(v.r1Min) ? v.r1Min : 0 });
      items.push({ p: [v.H1 / 2, v.L2], fillet: isNum(v.r2) ? v.r2 : 0 });
      items.push({ p: [v.H2 / 2, v.L3] });
    } else {
      if (shoulderData) {
        var lacking = [];
        if (!isNum(v.P2)) lacking.push('P2');
        if (!isNum(v.H1)) lacking.push('H1');
        missing.push(lacking.join(' and ') + ' (shoulder not drawn: body runs straight to H2)');
      }
      items.push({ p: [v.H2 / 2, v.L3] });
    }

    // Remove consecutive duplicates in the raw items (keeps fillets intact).
    var dedup = [];
    items.forEach(function (it) {
      var last = dedup[dedup.length - 1];
      if (last && Math.abs(last.p[0] - it.p[0]) < 1e-12 && Math.abs(last.p[1] - it.p[1]) < 1e-12) {
        if (it.fillet) last.fillet = it.fillet;
        return;
      }
      dedup.push(it);
    });
    var outer = expandItems(dedup);

    // Section walls: neck wall tn = (H2 - G1)/2, body wall tb.
    var heeledNow = isNum(v.G1) && (v.H2 - v.G1) <= HEEL_LIMIT;
    var tnRaw = isNum(v.G1) ? Math.max(0, (v.H2 - v.G1) / 2) : 0;
    var wallsKnown = isNum(v.G1);
    if (!wallsKnown) missing.push('G1 (section walls not drawn: wall thickness needs G1)');
    var tn = heeledNow ? 0 : tnRaw;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * rb);
    var tnEff = heeledNow ? tb : tn;
    features.tb = tb;
    features.tn = tn;
    features.heeled = heeledNow;

    // Bullet.
    var bulletOK = true;
    if (!isNum(v.G1)) { missing.push('G1 (bullet not drawn)'); bulletOK = false; }
    if (!isNum(v.L6)) { missing.push('L6 (bullet not drawn)'); bulletOK = false; }
    var bullet = null;
    if (bulletOK) {
      bullet = buildBullet(rec, v, notes, tb);
    }

    var tAt = function (z) {
      if (features.shoulder) {
        if (z <= v.L1) return tb;
        if (z >= v.L2) return tnEff;
        return tb + (tnEff - tb) * (z - v.L1) / (v.L2 - v.L1);
      }
      if (features.heeled) return tb;
      if (z <= zB) return tb;
      if (z >= v.L3) return tnEff;
      return tb + (tnEff - tb) * (z - zB) / (v.L3 - zB);
    };

    var w = Math.max(2.5, 0.25 * rb);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (type === 'belted' && rampEnd !== null) {
      w = Math.max(w, rampEnd + tb);
    } else if (features.groove) {
      w = Math.max(w, v.E + tb);
    }
    features.w = w;
    features.zB = zB;
    features.rampEnd = rampEnd;
    features.heelDiameter = features.heeled ? v.H2 - 2 * tb : null;

    // Inner (cavity) line from the solid head to the mouth.
    var rOuterW = radiusAt(outer, w);
    var sectionInner = [];
    if (wallsKnown && rOuterW !== undefined) {
      sectionInner.push([rOuterW - tAt(w), w]);
      outer.forEach(function (p) {
        if (p[1] > w) sectionInner.push([p[0] - tAt(p[1]), p[1]]);
      });
    }
    // Make the mouth of the inner line end at the bullet/heel radius.
    if (sectionInner.length) {
      var mouth = sectionInner[sectionInner.length - 1];
      mouth[0] = v.H2 / 2 - tAt(v.L3);
    }

    // Case section: solid head, walls, cavity floor at z = w, primer pocket.
    var sectionPolygon = [];
    var outerCase = outer.slice();
    if (pocket) outerCase[0] = [pocket.diameter / 2, 0];
    if (wallsKnown) {
      outerCase.forEach(function (p) { sectionPolygon.push(p); });
      for (var q = sectionInner.length - 1; q >= 0; q--) sectionPolygon.push(sectionInner[q]);
    } else {
      // Without G1 the walls are not drawn: the section shows the solid head only.
      outerCase.forEach(function (p) { if (p[1] <= w) sectionPolygon.push(p); });
      if (rOuterW !== undefined) sectionPolygon.push([rOuterW, w]);
    }
    sectionPolygon.push([0, w]);
    if (pocket) {
      sectionPolygon.push([0, pocket.depth]);
      sectionPolygon.push([pocket.diameter / 2, pocket.depth]);
    }

    // Silhouette (upper, outside view): case outline, mouth face, exposed bullet.
    var silhouette = outer.slice();
    if (bullet) {
      var exposed = bullet.profile.filter(function (p) { return p[1] >= v.L3 - 1e-12; });
      exposed.forEach(function (p) { silhouette.push(p); });
    } else {
      silhouette.push([0, v.L3]);
    }

    // Bullet section polygon (sits in the cavity, closed on the axis).
    var bulletSection = null;
    if (bullet) {
      bulletSection = [[0, bullet.zb]].concat(bullet.profile);
    }

    var dims = {
      L3: v.L3, L6: bullet ? v.L6 : null, R1: v.R1, R: isNum(v.R) ? v.R : null,
      P1: v.P1, P2: features.shoulder ? v.P2 : null, H1: features.shoulder ? v.H1 : null,
      H2: v.H2, G1: bullet ? bullet.G1 : null, L1: features.shoulder ? v.L1 : null,
      L2: features.shoulder ? v.L2 : null, E1: features.groove ? v.E1 : null,
      E: features.groove ? v.E : null, alpha: features.shoulder ? v.alpha : null,
      eMin: features.groove ? v.eMin : null
    };

    return {
      drawable: true,
      rimType: type,
      missing: missing,
      notes: notes,
      features: features,
      values: v,
      dims: dims,
      outer: outer,
      silhouette: silhouette,
      sectionInner: sectionInner,
      sectionPolygon: sectionPolygon,
      bullet: bullet,
      bulletSection: bulletSection
    };
  }

  return {
    rimType: rimType,
    buildGeometry: buildGeometry,
    filletPoints: filletPoints,
    radiusAt: radiusAt,
    pocketFor: pocketFor
  };
});
