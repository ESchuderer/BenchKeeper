'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../js/catalog.js');
const CARTRIDGES = require('../data/cartridges.js').CARTRIDGES;
const keys = (list) => list.map((r) => r.key);

test('all 25 records are listed with no filter', () => {
  assert.equal(C.filterCartridges(CARTRIDGES, { query: '', family: 'All' }).length, 25);
  assert.equal(C.filterCartridges(CARTRIDGES, { query: '   ', family: '' }).length, 25);
});

test('search finds alternative names: "7,62 x 51" finds 308 Win.', () => {
  assert.deepEqual(keys(C.filterCartridges(CARTRIDGES, { query: '7,62 x 51', family: 'All' })), ['308_win']);
});

test('search matches the name case-insensitively, ignoring spaces', () => {
  assert.deepEqual(keys(C.filterCartridges(CARTRIDGES, { query: '22lr', family: 'All' })), ['22_long_rifle']);
  assert.ok(keys(C.filterCartridges(CARTRIDGES, { query: '308 WIN', family: 'All' })).includes('308_win'));
});

test('family filter: each family selects its records, All selects everything', () => {
  const count = (family) => C.filterCartridges(CARTRIDGES, { query: '', family }).length;
  assert.equal(count('rimless'), 12);
  assert.equal(count('rimmed'), 2);
  assert.equal(count('belted'), 2);
  assert.equal(count('pistol'), 6);
  assert.equal(count('rimfire'), 3);
  assert.equal(count('All'), 25);
});

test('search and family combine', () => {
  const out = C.filterCartridges(CARTRIDGES, { query: '22', family: 'rimfire' });
  assert.deepEqual(keys(out).sort(), ['22_long_rifle', '22_win_mag_r_f'].sort());
});

test('count text', () => {
  assert.equal(C.countText(25), '25 cartridges');
  assert.equal(C.countText(1), '1 cartridge');
  assert.equal(C.countText(0), '0 cartridges');
});

test('routes: list and detail addresses survive a round trip', () => {
  assert.deepEqual(C.parseRoute(''), { view: 'list' });
  assert.deepEqual(C.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(C.parseRoute('#/cartridge/308_win'), { view: 'detail', key: '308_win' });
  assert.equal(C.routeFor('308_win'), '#/cartridge/308_win');
  assert.equal(C.parseRoute('#/cartridge/' + encodeURIComponent('22_win_mag_r_f')).key, '22_win_mag_r_f');
  assert.deepEqual(C.parseRoute('#/nonsense'), { view: 'list' });
});

test('each name is unique and each key is URL-safe', () => {
  assert.equal(new Set(CARTRIDGES.map((r) => r.key)).size, 25);
  assert.ok(CARTRIDGES.every((r) => /^[a-z0-9_]+$/.test(r.key)));
});

test('a malformed escape in the hash does not throw; the key is kept raw', () => {
  assert.doesNotThrow(() => C.parseRoute('#/cartridge/%E0%A4%A'));
  assert.equal(C.parseRoute('#/cartridge/%E0%A4%A').key, '%E0%A4%A');
});
