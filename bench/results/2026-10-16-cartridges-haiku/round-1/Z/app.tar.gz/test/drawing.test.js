'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../js/drawing.js');
const CARTRIDGES = require('../data/cartridges.js').CARTRIDGES;
const byKey = (k) => CARTRIDGES.find((r) => r.key === k);

test('every record produces a drawing with the required dimension labels', () => {
  for (const rec of CARTRIDGES) {
    const d = D.computeDrawing(rec);
    assert.equal(d.drawable, true, rec.key);
    const ids = d.dims.map((x) => x.id);
    for (const req of ['L3', 'R1', 'P1', 'L6']) {
      if (req === 'L6' && !rec.cartridge.lengths.L6) continue;
      assert.ok(ids.includes(req), `${rec.key} has ${req}`);
    }
    assert.ok(ids.includes('R') === (rec.cartridge.caseHead.R !== undefined), rec.key + ' R');
    const shoulder = rec.cartridge.junctionCone && rec.cartridge.junctionCone.alpha !== undefined && rec.cartridge.lengths.L1 !== undefined;
    assert.equal(ids.includes('alpha'), !!shoulder, rec.key + ' alpha');
    assert.equal(ids.includes('L1'), !!shoulder, rec.key + ' L1');
  }
});

test('labels are symbol and value: L3 51.18, with tolerance next to the value', () => {
  const d = D.computeDrawing(byKey('308_win'));
  const l3 = d.dims.find((x) => x.id === 'L3');
  assert.equal(l3.label, 'L3 51.18');
  const l1 = D.computeDrawing(byKey('223_rem')).dims.find((x) => x.id === 'L1');
  assert.equal(l1.label, 'L1 36.52 -0.2');
  const al = D.computeDrawing(byKey('223_rem')).dims.find((x) => x.id === 'alpha');
  assert.equal(al.label, 'α 46°');
});

test('dimension labels do not overlap each other, the outline or other dimension lines', () => {
  for (const rec of CARTRIDGES) {
    const d = D.computeDrawing(rec);
    assert.deepEqual(d.warnings, [], `${rec.key} labels colliding: ${d.warnings}`);
  }
});

test('the upper half is the outside view and the lower half the section', () => {
  const d = D.computeDrawing(byKey('223_rem'));
  assert.ok(d.upper.every((p) => p[1] <= 0 + 1e-9), 'outside view above the axis');
  assert.ok(d.lower.every((p) => p[1] >= 0 - 1e-9), 'section below the axis');
  assert.equal(d.upper[0][0], 0, 'starts on the head face');
});

test('SVG: accessible name, title block, centre line and hatched cut', () => {
  const d = D.computeDrawing(byKey('22_long_rifle'));
  const svg = D.renderSvg(d, 'x');
  assert.match(svg, /aria-label="22 Long Rifle drawing"/);
  assert.match(svg, /class="centre"/);
  assert.match(svg, /url\(#x-hatch\)/);
  assert.match(svg, />C\.I\.P\. table V/);
  assert.match(svg, /Dimensions in mm/);
  assert.match(svg, /Scale 1:1/);
});

test('missing values are reported and the drawing still builds', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete rec.cartridge.lengths.L1;
  const d = D.computeDrawing(rec);
  assert.equal(d.drawable, true);
  assert.equal(d.dims.some((x) => x.id === 'L1'), false);
  assert.equal(d.dims.some((x) => x.id === 'alpha'), false);
});

test('centre line starts at the head face and runs past the mouth', () => {
  const d = D.computeDrawing(byKey('223_rem'));
  assert.equal(d.centre.x1, 0);
  assert.ok(d.centre.x2 > 57.4);
});

test('the missing list uses "Missing:" wording in the app and names the value', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete rec.cartridge.lengths.L6;
  const d = D.computeDrawing(rec);
  assert.ok(d.missing.some((m) => /^L6/.test(m)));
});
