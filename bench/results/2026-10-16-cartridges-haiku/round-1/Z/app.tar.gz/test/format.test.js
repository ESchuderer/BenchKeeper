'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../js/format.js');
const CARTRIDGES = require('../data/cartridges.js').CARTRIDGES;
const byKey = (k) => CARTRIDGES.find((r) => r.key === k);

test('numbers are shown as published, without thousands separators', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(9.0), '9');
  assert.equal(F.formatNumber(-0.2), '-0.2');
});

test('angles: number shows degrees, object shows degrees minutes seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(0), '0°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), "39°59'49\"");
  assert.equal(F.formatAngle({ degrees: 3, minutes: 10, seconds: 0 }), "3°10'00\"");
});

test('symbols follow the brief mapping, falling back to the field name', () => {
  assert.equal(F.symbolFor('eMin'), 'e min');
  assert.equal(F.symbolFor('r1Min'), 'r1 min');
  assert.equal(F.symbolFor('r1Max'), 'r1 max');
  assert.equal(F.symbolFor('alpha'), 'α');
  assert.equal(F.symbolFor('alpha1'), 'α1');
  assert.equal(F.symbolFor('beta'), 'β');
  assert.equal(F.symbolFor('delta'), 'δ');
  assert.equal(F.symbolFor('deltaL'), 'delta L');
  assert.equal(F.symbolFor('L3PlusG'), 'L3 + G');
  assert.equal(F.symbolFor('G1'), 'G1');
  assert.equal(F.symbolFor('R3'), 'R3');
});

test('units: pressures, energy, mass, area, count and angles', () => {
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('N'), '');
  assert.equal(F.unitFor('alpha'), '');
  assert.equal(F.unitFor('L3'), 'mm');
  assert.equal(F.unitFor('G1'), 'mm');
});

test('section rows: tolerance is shown next to its value, never as a row', () => {
  const s = F.buildSections(byKey('223_rem'));
  const lengths = s.cartridge.find((x) => x.id === 'lengths');
  const l1 = lengths.rows.find((r) => r.key === 'L1');
  assert.deepEqual(l1, { key: 'L1', symbol: 'L1', value: '36.52 -0.2', unit: 'mm' });
  assert.ok(!lengths.rows.some((r) => r.key === 'L1Tol'));
  const l6 = lengths.rows.find((r) => r.key === 'L6');
  assert.equal(l6.value, '57.4');
});

test('section rows: tolerances on E, R, P2 and L3 attach to their own values', () => {
  const belted = F.buildSections(byKey('300_win_mag'));
  const e = belted.cartridge.find((x) => x.id === 'caseHead').rows.find((r) => r.key === 'E');
  assert.equal(e.value, '5.59 -0.2');
  const pistol = F.buildSections(byKey('9_mm_luger'));
  const l3 = pistol.cartridge.find((x) => x.id === 'lengths').rows.find((r) => r.key === 'L3');
  assert.equal(l3.value, '19.15 -0.25');
});

test('section rows: angle objects and numbers, with unit blank for angles', () => {
  const s = F.buildSections(byKey('223_rem'));
  const rifling = F.buildSections(byKey('223_rem')).chamber.find((x) => x.id === 'rifling');
  const i = rifling.rows.find((r) => r.key === 'i');
  assert.deepEqual(i, { key: 'i', symbol: 'i', value: "3°10'36\"", unit: '' });
  const alpha = s.cartridge.find((x) => x.id === 'junctionCone').rows.find((r) => r.key === 'alpha');
  assert.equal(alpha.symbol, 'α');
  assert.equal(alpha.value, '46°');
});

test('sections keep all cartridge and chamber fields, in published order', () => {
  const s = F.buildSections(byKey('22_long_rifle'));
  const cartridgeKeys = s.cartridge.flatMap((x) => x.rows.map((r) => r.key));
  assert.deepEqual(cartridgeKeys.slice(0, 4), ['R', 'R1', 'beta', 'delta']);
  assert.ok(cartridgeKeys.includes('L6'));
  assert.ok(cartridgeKeys.includes('G1'));
  assert.ok(cartridgeKeys.includes('Pmax'));
  const chamberKeys = s.chamber.flatMap((x) => x.rows.map((r) => r.key));
  assert.ok(chamberKeys.includes('Z'));
  assert.ok(chamberKeys.includes('u'));
  assert.ok(!cartridgeKeys.some((k) => k.endsWith('Tol')));
});

test('section titles are human readable and sections with no rows are dropped', () => {
  const s = F.buildSections(byKey('9_mm_luger'));
  const titles = s.cartridge.map((x) => x.title);
  assert.ok(titles.includes('Case head'));
  assert.ok(titles.includes('Powder chamber'));
  assert.ok(s.cartridge.every((x) => x.rows.length > 0));
  assert.ok(s.chamber.every((x) => x.rows.length > 0));
});

test('search normalisation: case, spaces and comma/dot decimal are ignored', () => {
  assert.equal(F.normalizeQuery('7,62 x 51'), '7.62x51');
  assert.equal(F.normalizeQuery('  308 WIN '), '308win');
});
