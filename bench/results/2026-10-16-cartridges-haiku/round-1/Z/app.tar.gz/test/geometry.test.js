'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../js/geometry.js');
const CARTRIDGES = require('../data/cartridges.js').CARTRIDGES;
const byKey = (k) => CARTRIDGES.find((r) => r.key === k);
const close = (a, b, tol, msg) => assert.ok(Math.abs(a - b) <= tol, (msg || '') + ` expected ${b} got ${a}`);

test('rim type: family first, then R1/P1 ratio thresholds', () => {
  assert.equal(G.rimType(byKey('300_win_mag')), 'belted');
  assert.equal(G.rimType(byKey('22_long_rifle')), 'rimfire');
  assert.equal(G.rimType(byKey('9_3_x_74_r')), 'rimmed');   // 13.35 / 11.9
  assert.equal(G.rimType(byKey('223_rem')), 'rimless');     // 9.6 / 9.58
  const rebated = { family: 'rimless', cartridge: { caseHead: { R1: 9 }, powderChamber: { P1: 10 } } };
  assert.equal(G.rimType(rebated), 'rebated');
});

test('223 Rem.: primer pocket and solid head', () => {
  const g = G.buildGeometry(byKey('223_rem'));
  assert.equal(g.drawable, true);
  assert.deepEqual(g.features.pocket, { diameter: 4.45, depth: 3.04 });
  // w = max(2.5, 0.25*P1/2, pocket depth + 1.5, E + tb)
  close(g.features.w, 3.04 + 1.5, 1e-9, 'w');
  close(g.features.tb, 0.6, 1e-9, 'tb');
  close(g.features.tn, 0.365, 1e-9, 'tn');
});

test('223 Rem.: groove runs from the rim corner to the floor and ramps to the body', () => {
  const g = G.buildGeometry(byKey('223_rem'));
  const o = g.outer;
  // rim corner, groove floor start, groove floor end, ramp end on body
  const find = (r, z) => o.find((p) => Math.abs(p[0] - r) < 1e-9 && Math.abs(p[1] - z) < 1e-9);
  assert.ok(find(9.6 / 2, 1.14), 'rim corner (R1/2, R)');
  assert.ok(find(8.43 / 2, 1.14), 'groove start (E1/2, R)');
  assert.ok(find(8.43 / 2, 1.14 + 0.76), 'groove floor end (E1/2, R+eMin)');
  assert.ok(find(9.58 / 2, 3.13), 'ramp end on body (P1/2, E)');
});

test('223 Rem.: shoulder half-angle reproduces the published alpha 46 degrees', () => {
  const g = G.buildGeometry(byKey('223_rem'));
  const { P2, H1, L1, L2 } = { P2: 9.0, H1: 6.43, L1: 36.52, L2: 39.55 };
  const halfAngle = Math.atan(((P2 - H1) / 2) / (L2 - L1)) * 180 / Math.PI;
  close(2 * halfAngle, 46.0, 0.1, 'alpha');
  assert.equal(g.features.shoulder, true);
});

test('223 Rem.: pointy bullet, ogive radius from the published formula', () => {
  const g = G.buildGeometry(byKey('223_rem'));
  const b = g.bullet;
  assert.equal(b.shape, 'pointy');
  close(b.s, 5.7, 1e-9, 's');
  close(b.zb, 44.7 - 5.7, 1e-9, 'zb');
  close(b.Lb, 57.4 - 39.0, 1e-9, 'Lb');
  close(b.zn, 39.0 + 0.4 * 18.4, 1e-9, 'zn');
  close(b.m, 1.27, 1e-9, 'm');
  // rho = ((G1/2 - m/2)^2 + n^2) / (2 (G1/2 - m/2)), n = L6 - zn
  const d = 2.85 - 0.635;
  const n = 57.4 - (39.0 + 0.4 * 18.4);
  close(b.rho, (d * d + n * n) / (2 * d), 1e-6, 'rho');
  // the arc passes through the published tip radius m/2 at z = L6
  const tip = g.bullet.profile[g.bullet.profile.length - 2];
  close(tip[0], 0.635, 1e-9, 'meplat radius');
  close(tip[1], 57.4, 1e-9, 'tip z');
});

test('223 Rem.: section walls and the inner line', () => {
  const g = G.buildGeometry(byKey('223_rem'));
  // the inner mouth radius equals the bullet radius when the neck wall is tn
  const innerMouth = g.sectionInner[g.sectionInner.length - 1];
  close(innerMouth[1], 44.7, 1e-9, 'inner mouth z');
  close(innerMouth[0], 2.85, 1e-6, 'inner mouth r = G1/2');
});

test('9 mm Luger: straight-walled to a mouth, pistol rounded bullet', () => {
  const g = G.buildGeometry(byKey('9_mm_luger'));
  assert.equal(g.features.shoulder, false);
  assert.equal(g.bullet.shape, 'rounded');
  close(g.bullet.s, 0.4 * 9.03, 1e-9, 's pistol rounded');
  close(g.bullet.k, 0.65, 1e-9, 'k pistol rounded');
  close(g.bullet.m, 0.15 * 9.03, 1e-9, 'm rounded');
  assert.deepEqual(g.features.pocket, { diameter: 4.45, depth: 3.04 });
});

test('22 Long Rifle: heeled bullet, rimfire half-round rim, no pocket', () => {
  const g = G.buildGeometry(byKey('22_long_rifle'));
  assert.equal(g.rimType, 'rimfire');
  assert.equal(g.features.heeled, true);
  close(g.features.tb, 0.6, 1e-9, 'tb');
  close(g.features.heelDiameter, 5.72 - 1.2, 1e-9, 'heel diameter');
  assert.equal(g.features.pocket, null);
  // half-round radius min(R/2, (R1-P1)/2) with R = 1.09, R1 = 7.06, P1 = 5.74
  close(g.features.rimfireRadius, Math.min(1.09 / 2, (7.06 - 5.74) / 2), 1e-9, 'rimfire radius');
  // outermost point of the half-round lies at R1/2
  const maxR = Math.max(...g.outer.map((p) => p[0]));
  close(maxR, 7.06 / 2, 1e-9, 'half-round outermost');
});

test('300 Win. Mag.: belt ramp at delta, belt to E, step to body', () => {
  const g = G.buildGeometry(byKey('300_win_mag'));
  assert.equal(g.rimType, 'belted');
  assert.equal(g.features.belt, true);
  const rampEnd = g.features.rampEnd;
  // ramp: dz = (R3/2 - E1/2) / tan(delta) from z = R + eMin
  close(rampEnd, 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180), 1e-6, 'ramp end');
  const belt = g.outer.filter((p) => Math.abs(p[0] - 13.51 / 2) < 1e-9);
  assert.ok(belt.some((p) => Math.abs(p[1] - 5.59) < 1e-9), 'belt reaches z = E');
  // the solid head stops at belt ramp end + tb
  // primer lrm: pocket depth 3.3, so pocket depth + 1.5 = 4.8 is the largest term
  close(g.features.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, rampEnd + g.features.tb), 1e-6, 'w belted');
  close(g.features.w, 4.8, 1e-9, 'pocket term governs here');
});

test('chamfer only when beta and f are published and beta < 90', () => {
  const g = G.buildGeometry(byKey('223_rem'));
  // x = min(f tan(beta), R1/4) = min(0.45 * tan 35, 9.6/4)
  const x = Math.min(0.45 * Math.tan(35 * Math.PI / 180), 9.6 / 4);
  assert.ok(g.outer.some((p) => Math.abs(p[0] - (9.6 / 2 - x)) < 1e-9 && p[1] === 0), 'chamfer start');
  assert.ok(g.outer.some((p) => Math.abs(p[0] - 9.6 / 2) < 1e-9 && Math.abs(p[1] - 0.45) < 1e-9), 'chamfer end');
});

test('missing values: each is named and the feature is left out, never invented', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete rec.cartridge.powderChamber.P2;
  delete rec.cartridge.junctionCone.r1Min;
  delete rec.cartridge.lengths.L6;
  const g = G.buildGeometry(rec);
  assert.equal(g.drawable, true);
  assert.equal(g.features.shoulder, false, 'no P2 means straight body');
  assert.ok(g.missing.some((m) => /P2/.test(m)), 'P2 named');
  assert.equal(g.bullet, null, 'no L6 means no bullet');
  assert.ok(g.missing.some((m) => /L6/.test(m)), 'L6 named');
});

test('a record without the essential mouth or body values is not drawable', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete rec.cartridge.powderChamber.P1;
  const g = G.buildGeometry(rec);
  assert.equal(g.drawable, false);
  assert.ok(g.missing.some((m) => /P1/.test(m)));
});

test('every record builds, every profile is finite, and no radius is negative', () => {
  for (const rec of CARTRIDGES) {
    const g = G.buildGeometry(rec);
    assert.equal(g.drawable, true, rec.key);
    for (const pl of [g.outer, g.sectionInner, g.sectionPolygon, g.bullet && g.bullet.profile].filter(Boolean)) {
      for (const [r, z] of pl) {
        assert.ok(Number.isFinite(r) && Number.isFinite(z), rec.key);
        assert.ok(r >= -1e-9, rec.key + ' negative radius');
      }
    }
  }
});

test('section walls never let the bullet overlap the case wall', () => {
  for (const rec of CARTRIDGES) {
    const g = G.buildGeometry(rec);
    if (!g.bullet) continue;
    for (const [r, z] of g.sectionInner) {
      if (z < g.bullet.zb || z > g.bullet.L3) continue;
      const seated = g.features.heeled ? g.features.heelDiameter / 2 : g.bullet.rSeat;
      assert.ok(r >= seated - 1e-6, `${rec.key} inner ${r} < bullet ${seated} at z ${z}`);
    }
  }
});

test('missing R: the rim cannot be drawn, so the drawing is not produced and R is named', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete rec.cartridge.caseHead.R;
  const g = G.buildGeometry(rec);
  assert.equal(g.drawable, false);
  assert.ok(g.missing.some((m) => /^R\b/.test(m)));
});

test('missing G1: bullet and section walls are left out and named; the solid head is kept', () => {
  const rec = JSON.parse(JSON.stringify(byKey('223_rem')));
  delete rec.cartridge.projectile.G1;
  const g = G.buildGeometry(rec);
  assert.equal(g.drawable, true);
  assert.equal(g.bullet, null);
  assert.equal(g.sectionInner.length, 0, 'no cavity line without walls');
  assert.ok(g.missing.some((m) => /G1/.test(m)));
  assert.ok(g.sectionPolygon.every((p) => p[1] <= g.features.w + 1e-9), 'section stops at the solid head');
});

test('belted case without E: the belt is not drawn and the missing value is named', () => {
  const rec = JSON.parse(JSON.stringify(byKey('300_win_mag')));
  delete rec.cartridge.caseHead.E;
  const g = G.buildGeometry(rec);
  assert.equal(g.features.belt, false);
  assert.ok(g.missing.some((m) => /E or E1/.test(m)));
});
