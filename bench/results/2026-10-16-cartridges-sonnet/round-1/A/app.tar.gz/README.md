# C.I.P. cartridge reference

A static reference database of 25 C.I.P. cartridges with a computed, true-to-scale 2D drawing for each.
Plain HTML, CSS and JavaScript: no framework, no build step, no runtime dependencies, no network requests.

## Use

Open `index.html` directly from disk (Chromium, `file://`), or serve the folder with any static server:

    npm run serve        # http://127.0.0.1:8080/

* `#/` – the list (search, family filter, `<n> cartridges`)
* `#/cartridge/<key>` – detail view, e.g. `#/cartridge/308_win`; reload and bookmarks work
* **Print** – one A4 portrait page, black on white

## Files

| Path | Purpose |
| --- | --- |
| `index.html`, `css/app.css` | shell, screen (light/dark) and print styles |
| `js/data.js` | the 25 records exactly as supplied (OpenBallistics, MIT, commit e83db43) |
| `js/format.js` | numbers, angles, tolerances, symbols, units, sections, search |
| `js/geometry.js` | pure geometry: profile, bullet, section, wall thicknesses, dimension targets |
| `js/layout.js` | collision-free placement of dimension lines and labels |
| `js/drawing.js` | geometry + layout → inline SVG (1 user unit = 1 mm) |
| `js/app.js` | hash router and views |
| `docs/SPEC.md` | reading of the brief and decisions where it leaves room |

## Tests (development only)

    npm install
    npm test             # unit tests, node:test, no browser
    npx playwright install chromium
    npm run test:e2e     # Playwright: file:// and http, label overlap with real text metrics,
                         # print emulation and PDF page count for all 25 cartridges

Playwright needs the usual Chromium system libraries (`npx playwright install-deps` as root).

## Data

Values are shown as published. A feature whose input value is missing is left out of the drawing and
listed under it ("Not drawn: … not published"); no number is ever invented.
