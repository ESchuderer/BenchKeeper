# C.I.P. cartridge reference — specification and design decisions

Source of truth is the brief. This file records how each requirement is read, the
decisions taken where the brief leaves room, and how each one is verified.

## Architecture

| File | Role | Test |
| --- | --- | --- |
| `index.html` | shell, loads scripts in order (classic scripts, no modules: ES modules and `fetch` do not work from `file://`) | e2e |
| `js/data.js` | the 25 records, verbatim, as `CIP.data` | unit (shape, count) |
| `js/format.js` | numbers, angles, tolerances, symbols, units, sections | unit |
| `js/geometry.js` | pure geometry: record -> profile, bullet, section, landmarks, notes | unit |
| `js/layout.js` | pure dimension/label placement (collision-free) | unit |
| `js/drawing.js` | geometry + layout -> SVG DOM | e2e |
| `js/app.js` | hash router, list, detail, print | e2e |
| `css/app.css` | screen (light/dark) and print | e2e (PDF) |

Every module is a classic script that attaches to `window.CIP` and also exports through
`module.exports`, so `node --test` loads the same files the browser runs.

## Decisions on points the brief leaves open

* **Address of a detail view**: `#/cartridge/<key>`; the list is `#/`. Filters live in the hash query
  (`#/?q=…&family=…`) and are written with `replaceState`, so Back returns to the filtered list and
  the "All cartridges" link (`#/`) shows everything.
* **Search** ignores case, whitespace and the difference between `,` and `.` in numbers.
* **Count text** is literally `<n> cartridges` (also for 1).
* **Angles**: number -> `40°`; object -> `39°59'49"` with all three parts as published.
* **Tolerance** is shown as `value tol` (`39.62 -0.2`), a positive tolerance gets an explicit `+`.
* **Units**: `mm` for lengths and diameters (this includes `u`, `s`, `h`, `b`, `Fe`, `deltaL`, …),
  `bar`, `J`, `g`, `mm²`; angles `deg`; `N` has no unit.
* **Drawing labels** show symbol and value only; tolerances are in the tables.
* **Angle α** is the included cone angle; its cone apex lies in front of the mouth, inside the
  seated bullet, so it cannot be drawn as an arc at the apex. α is shown as a leader with an
  arrowhead on the shoulder line and the label `α 40°`.
* **Straight pistol/rimfire cases** use the neck wall `tn` over the seating depth (so the bullet does
  not overlap the wall), blended linearly from `tb` over one seating depth. Heeled cases use `tb`
  all the way (the heel has the inside diameter `H2 - 2·tb`).
* **Missing values** never invent numbers: the feature is left out and the page lists
  "Not drawn: <feature> (<value> not published)" under the drawing.
* **Print scale**: the drawing is `190 mm` wide on A4 (10 mm margins), so the title block states
  `190 / viewBox width`. On screen it states the nominal scale (96 dpi CSS pixels).
* The viewBox is at least 100 mm wide so tiny cartridges do not blow up to an unprintable height.

## Verification plan

1. Unit tests (written first) for format, data, geometry rules 1–9, layout collisions.
2. E2E (Playwright, Chromium, `file://` and static server): start page, search/filter, detail
   content, routing/reload, drawing accessibility and true scale, label overlap measured with real
   `getBBox`, no network requests, print emulation and PDF (one A4 page, black on white).
3. Visual review of screenshots of all 25 drawings, light/dark, 360 px wide.
