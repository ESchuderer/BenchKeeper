/* Router and views: the list of cartridges (#/) and the detail view (#/cartridge/<key>). */
(function () {
  const { data, format: F, drawing: Drawing } = window.CIP;
  const main = document.getElementById('main');
  const byKey = new Map(data.map(r => [r.key, r]));

  function h(tag, attrs, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat()) {
      if (c === null || c === undefined || c === false) continue;
      e.append(c.nodeType ? c : document.createTextNode(c));
    }
    return e;
  }

  const detailHref = key => `#/cartridge/${encodeURIComponent(key)}`;
  let cleanup = [];
  let afterMount = [];
  function onCleanup(fn) { cleanup.push(fn); }

  // ---- list ----------------------------------------------------------------------------------
  function listView(params) {
    const state = { q: params.get('q') || '', family: params.get('family') || '' };
    if (!F.FAMILIES.includes(state.family)) state.family = '';

    const search = h('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false', value: state.q });
    const family = h('select', { id: 'family' },
      h('option', { value: '' }, 'All'),
      F.FAMILIES.map(f => h('option', { value: f, selected: f === state.family }, f)));
    const count = h('p', { class: 'count', role: 'status', 'aria-live': 'polite' });
    const tbody = h('tbody');
    const empty = h('p', { class: 'empty', hidden: true }, 'No cartridge matches.');

    function update() {
      const rows = F.filter(data, state).map(F.listRow);
      tbody.replaceChildren(...rows.map(r => h('tr', {},
        h('th', { scope: 'row' }, h('a', { href: detailHref(r.key) }, r.name)),
        h('td', {}, r.family),
        h('td', { class: 'num' }, r.l3))));
      count.textContent = `${rows.length} cartridges`;
      empty.hidden = rows.length > 0;
      const q = new URLSearchParams();
      if (state.q) q.set('q', state.q);
      if (state.family) q.set('family', state.family);
      const hash = '#/' + (q.toString() ? '?' + q : '');
      try { history.replaceState(null, '', hash); } catch (e) { /* file:// quirks: the list still works */ }
    }
    search.addEventListener('input', () => { state.q = search.value; update(); });
    family.addEventListener('change', () => { state.family = family.value; update(); });

    const view = h('div', { class: 'view list-view' },
      h('h1', { id: 'view-title' }, 'Cartridges'),
      h('form', { class: 'filters', role: 'search', onsubmit: e => e.preventDefault() },
        h('div', { class: 'field' }, h('label', { for: 'search' }, 'Search'), search),
        h('div', { class: 'field' }, h('label', { for: 'family' }, 'Family'), family),
        count),
      h('table', { class: 'cartridges' },
        h('thead', {}, h('tr', {},
          h('th', { scope: 'col' }, 'Name'), h('th', { scope: 'col' }, 'Family'),
          h('th', { scope: 'col', class: 'num' }, 'L3 (mm)'))),
        tbody),
      empty);
    update();
    document.title = 'Cartridges – C.I.P. reference';
    return view;
  }

  // ---- detail --------------------------------------------------------------------------------
  function metaList(rec) {
    const dl = h('dl', { class: 'meta' });
    for (const m of F.metadata(rec)) {
      let value;
      if (m.linkText) {
        const source = m.href ? h('a', { href: m.href, rel: 'noopener noreferrer', target: '_blank' }, m.linkText) : m.linkText;
        value = [m.text, ' (source: ', source, ')', m.note ? h('span', { class: 'note' }, ` ${m.note}`) : null];
      } else {
        value = m.text || h('span', { class: 'none' }, m.label === 'Water capacity' ? 'not published' : 'none');
      }
      dl.append(h('div', {}, h('dt', {}, m.label), h('dd', {}, value)));
    }
    return dl;
  }

  function valueTables(rec, group) {
    const secs = F.sections(rec, group);
    const id = `${group}-values`;
    return h('section', { class: 'values', 'aria-labelledby': id },
      h('h2', { id }, F.SECTIONS[group].title),
      h('div', { class: 'tables' }, secs.map(s => h('table', { class: 'values-table', 'data-section': `${group}.${s.id}` },
        h('caption', {}, s.title),
        h('thead', {}, h('tr', {}, h('th', { scope: 'col' }, 'Symbol'), h('th', { scope: 'col', class: 'num' }, 'Value'),
          h('th', { scope: 'col' }, 'Unit'))),
        h('tbody', {}, s.rows.map(r => h('tr', {},
          h('th', { scope: 'row' }, r.symbol),
          h('td', { class: 'num' }, r.value, r.tol === null ? null : [' ', h('span', { class: 'tol' }, r.tol)]),
          h('td', { class: 'unit' }, r.unit)))))))
    );
  }

  function drawingFigure(rec) {
    const out = Drawing.render(rec, document);
    const fig = h('figure', { class: 'drawing-figure' });
    if (out.error) {
      fig.append(h('p', { class: 'drawing-error' }, out.error));
      return fig;
    }
    fig.append(out.svg);
    const notes = out.geometry.notes;
    if (notes.length) {
      fig.append(h('figcaption', { class: 'drawing-notes' }, notes.map(n => h('p', {}, n.text))));
    }
    // On screen the scale is nominal (96 dpi CSS pixels); in print the drawing is 190 mm wide.
    const mq = window.matchMedia ? window.matchMedia('print') : null;
    let forcePrint = false;
    const update = () => {
      if (forcePrint || (mq && mq.matches)) Drawing.printScale(out.svg);
      else Drawing.screenScale(out.svg);
    };
    const enter = () => { forcePrint = true; update(); };
    const leave = () => { forcePrint = false; update(); };
    afterMount.push(update);
    if (window.ResizeObserver) {
      const ro = new ResizeObserver(update);
      ro.observe(out.svg);
      onCleanup(() => ro.disconnect());
    }
    window.addEventListener('beforeprint', enter);
    window.addEventListener('afterprint', leave);
    if (mq && mq.addEventListener) mq.addEventListener('change', update);
    onCleanup(() => {
      window.removeEventListener('beforeprint', enter);
      window.removeEventListener('afterprint', leave);
      if (mq && mq.removeEventListener) mq.removeEventListener('change', update);
    });
    return fig;
  }

  function detailView(rec) {
    document.title = `${rec.name} – C.I.P. reference`;
    return h('article', { class: 'view detail-view' },
      h('header', { class: 'detail-head' },
        h('p', { class: 'eyebrow' }, 'C.I.P. TDCC cartridge data sheet'),
        h('h1', { id: 'view-title' }, rec.name),
        h('div', { class: 'actions' },
          h('button', { type: 'button', class: 'button', onclick: () => window.print() }, 'Print'),
          h('a', { class: 'button', href: '#/' }, 'All cartridges'))),
      metaList(rec),
      drawingFigure(rec),
      h('div', { class: 'value-groups' }, valueTables(rec, 'cartridge'), valueTables(rec, 'chamber')),
      h('p', { class: 'print-footer' }, `Source: C.I.P. TDCC, revised ${rec.revised}`));
  }

  function notFound(what) {
    document.title = 'Not found – C.I.P. reference';
    return h('div', { class: 'view' },
      h('h1', { id: 'view-title' }, 'Not found'),
      h('p', {}, `There is no ${what}. `, h('a', { href: '#/' }, 'All cartridges')));
  }

  // ---- router --------------------------------------------------------------------------------
  let first = true;
  function route() {
    for (const fn of cleanup) fn();
    cleanup = [];
    afterMount = [];
    const [path, query] = (location.hash.slice(1) || '/').split('?');
    let view;
    const m = /^\/cartridge\/([^/]+)\/?$/.exec(path);
    if (m) {
      let key = null;
      try { key = decodeURIComponent(m[1]); } catch (e) { /* malformed escape: not found */ }
      const rec = byKey.get(key);
      view = rec ? detailView(rec) : notFound('cartridge with this address');
    } else if (path === '/' || path === '') {
      view = listView(new URLSearchParams(query || ''));
    } else {
      view = notFound('page at this address');
    }
    main.replaceChildren(view);
    for (const fn of afterMount) fn();
    if (!first) {
      window.scrollTo(0, 0);
      const title = document.getElementById('view-title');
      if (title) { title.setAttribute('tabindex', '-1'); title.focus({ preventScroll: true }); }
    }
    first = false;
  }
  window.addEventListener('hashchange', route);
  route();
})();
