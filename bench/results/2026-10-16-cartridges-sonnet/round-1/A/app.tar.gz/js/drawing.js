/* Builds the inline SVG drawing of a cartridge: 1 user unit = 1 mm, axis horizontal, head on the left,
 * outside view above the axis, section below it. All numbers come from geometry.js / layout.js. */
(function (root, factory) {
  const dep = name => (typeof module === 'object' && module.exports ? require('./' + name + '.js') : root.CIP[name]);
  const api = factory(dep('geometry'), dep('layout'));
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.drawing = api; }
})(typeof self !== 'undefined' ? self : this, function (Geometry, Layout) {
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const PRINT_WIDTH_MM = 190;      // A4 portrait, 10 mm margins
  const CSS_PX_MM = 25.4 / 96;
  const FONT_SIZE = 2.5;

  const n3 = v => String(Math.round(v * 1000) / 1000);
  const pt = (z, y) => `${n3(z)} ${n3(y)}`;
  const upper = pts => pts.map(([r, z]) => [z, -r]);
  const lower = pts => pts.map(([r, z]) => [z, r]);
  const poly = (pts, close) => 'M' + pts.map(([x, y]) => pt(x, y)).join('L') + (close ? 'Z' : '');

  function formatScale(s) {
    return s >= 1 ? `${s.toFixed(1)} : 1` : `1 : ${(1 / s).toFixed(1)}`;
  }
  const scaleText = s => `Scale ${formatScale(s)}`;

  function titleRows(rec) {
    return [
      [{ role: 'name', text: rec.name, size: 1.25 }],
      [{ role: 'tab', text: `C.I.P. table ${rec.tab}` }, { role: 'revised', text: `Revised ${rec.revised}` }],
      [{ role: 'units', text: 'Dimensions in mm' }, { role: 'scale', text: 'Scale', reserve: 14 }]
    ];
  }

  /** Render the drawing. Returns { svg, geometry, scene }, or { error, geometry } when it cannot be drawn. */
  function render(rec, doc) {
    doc = doc || document;
    const g = Geometry.build(rec);
    if (!g.ok) return { error: g.error, geometry: g };
    const scene = Layout.layout(g, { fontSize: FONT_SIZE, titleRows: titleRows(rec) });
    const { x0, y0, x1, y1 } = scene.bounds;
    const w = x1 - x0, h = y1 - y0;

    const el = (name, attrs, parent, text) => {
      const e = doc.createElementNS(SVG_NS, name);
      for (const k in attrs) e.setAttribute(k, attrs[k]);
      if (text !== undefined) e.textContent = text;
      if (parent) parent.appendChild(e);
      return e;
    };

    const label = `${rec.name} drawing`;
    const svg = el('svg', {
      viewBox: `${n3(x0)} ${n3(y0)} ${n3(w)} ${n3(h)}`,
      role: 'img', 'aria-label': label, class: 'drawing', preserveAspectRatio: 'xMidYMid meet',
      'data-unit': 'mm', 'data-view-width-mm': n3(w), 'data-view-height-mm': n3(h)
    });
    el('title', {}, svg, label);

    const defs = el('defs', {}, svg);
    const pat = el('pattern', {
      id: 'hatch', width: '0.5', height: '0.5', patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)'
    }, defs);
    el('rect', { width: '0.5', height: '0.5', class: 'hatch-bg' }, pat);
    el('line', { x1: '0', y1: '0', x2: '0', y2: '0.5', class: 'hatch-line' }, pat);

    const L3 = rec.cartridge.lengths.L3;
    const body = el('g', { class: 'cartridge' }, svg);

    // bullet first: the case then hides the seated part in the outside view
    let bulletPath = null;
    if (g.bullet) {
      const pts = g.bullet.pts;
      const d = poly(upper(pts), false) + 'L' + poly(lower(pts.slice().reverse()), false).slice(1) + 'Z';
      bulletPath = el('path', { class: 'bullet', 'data-part': 'bullet', d }, body);
    }

    const prof = g.profile;
    const outside = upper(prof).concat([[L3, 0]]);
    el('path', { class: 'case-fill', d: poly(outside, true) }, body);
    el('path', { class: 'case-cut', 'data-part': 'section', d: poly(lower(g.section.cut), true) }, body);

    const outline = upper(prof).reverse().concat(lower(prof));
    el('path', { class: 'case-outline', 'data-part': 'case', d: poly(outline, false) }, body);

    const sec = g.section;
    const lines = [
      poly(lower(sec.inner), false), poly(lower(sec.floor), false), poly(lower(sec.mouthFace), false)
    ];
    if (sec.pocketLine.length) lines.push(poly(lower(sec.pocketLine), false));
    el('path', { class: 'section-lines', d: lines.join('') }, body);
    if (g.bullet && g.bullet.radius < g.landmarks.mouth.r - 1e-6) {
      el('path', {
        class: 'mouth-ring',
        d: poly(upper([[g.bullet.radius, L3], [g.landmarks.mouth.r, L3]]), false)
      }, body);
    }
    el('path', {
      class: 'centreline', d: `M${pt(-4, 0)}L${pt(g.zMax + 4, 0)}`, 'data-part': 'centreline'
    }, body);

    // dimensions
    const dims = el('g', { class: 'dimensions' }, svg);
    const A = Layout.ARROW;
    for (const it of scene.items) {
      const gd = el('g', { class: `dim dim-${it.kind}`, 'data-dim': it.id }, dims);
      for (const l of it.lines) {
        el('line', {
          class: l.role === 'ext' ? 'ext-line' : 'dim-line',
          x1: n3(l.x1), y1: n3(l.y1), x2: n3(l.x2), y2: n3(l.y2)
        }, gd);
      }
      for (const a of it.arrows) {
        const bx = a.x - a.dx * A.len, by = a.y - a.dy * A.len;
        const px = -a.dy * A.half, py = a.dx * A.half;
        el('path', {
          class: 'arrow',
          d: `M${pt(a.x, a.y)}L${pt(bx + px, by + py)}L${pt(bx - px, by - py)}Z`
        }, gd);
      }
      el('text', {
        class: 'dim-text', x: n3(it.text.x), y: n3(it.text.y), 'text-anchor': it.text.anchor, 'font-size': scene.fs
      }, gd, it.text.str);
    }

    // title block
    const tb = scene.titleBlock;
    const tg = el('g', { class: 'title-block' }, svg);
    el('rect', { class: 'tb-frame', x: n3(tb.x), y: n3(tb.y), width: n3(tb.w), height: n3(tb.h) }, tg);
    for (const c of tb.cells) {
      el('text', {
        class: `tb-text tb-${c.role}`, x: n3(c.x), y: n3(c.y), 'font-size': n3(scene.fs * c.size), 'data-role': c.role
      }, tg, c.text);
    }
    for (const y of tb.rules) {
      el('line', { class: 'tb-rule', x1: n3(tb.x), y1: n3(y), x2: n3(tb.x + tb.w), y2: n3(y) }, tg);
    }

    return { svg, geometry: g, scene, viewWidthMm: w, viewHeightMm: h, bulletPath };
  }

  /** Writes the scale into the title block. `widthMm` is the rendered width of the SVG in mm. */
  function setScale(svg, widthMm) {
    const vb = Number(svg.getAttribute('data-view-width-mm'));
    const text = svg.querySelector('[data-role="scale"]');
    if (!text || !vb || !widthMm) return null;
    const s = widthMm / vb;
    text.textContent = scaleText(s);
    return s;
  }
  const printScale = svg => setScale(svg, PRINT_WIDTH_MM);
  const screenScale = svg => {
    const px = svg.getBoundingClientRect().width;
    return setScale(svg, px * CSS_PX_MM);
  };

  return { render, setScale, printScale, screenScale, scaleText, formatScale, PRINT_WIDTH_MM };
});
