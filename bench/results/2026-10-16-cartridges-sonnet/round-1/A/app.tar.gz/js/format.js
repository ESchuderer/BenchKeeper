/* Formatting and data shaping: numbers, angles, tolerances, symbols, units, sections, search. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.format = api; }
})(typeof self !== 'undefined' ? self : this, function () {
  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const BAR = new Set(['Pmax', 'PK', 'PE']);

  const SECTIONS = {
    cartridge: {
      order: ['caseHead', 'collar', 'junctionCone', 'lengths', 'powderChamber', 'projectile', 'pressures', 'misc'],
      title: 'Cartridge values'
    },
    chamber: {
      order: ['breech', 'powderChamber', 'collar', 'junctionCone', 'lengths', 'barrel', 'grooves', 'rifling'],
      title: 'Chamber values'
    }
  };
  const SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    powderChamber: 'Powder chamber', projectile: 'Projectile', pressures: 'Pressures', misc: 'Miscellaneous',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
  };
  const FIELD_ORDER = {
    caseHead: ['R1', 'R', 'E1', 'E', 'eMin', 'f', 'R3', 'beta', 'delta'],
    collar: ['H1', 'H2'],
    junctionCone: ['S', 'alpha', 'r1Min', 'r1Max', 'r2'],
    lengths: ['L1', 'L2', 'L3', 'L4', 'L5', 'L6'],
    powderChamber: ['P1', 'P2', 'E'],
    projectile: ['G1', 'G2', 'L3PlusG'],
    pressures: ['Pmax', 'PK', 'PE', 'EE', 'M'],
    misc: ['Fe', 'deltaL'],
    barrel: ['F', 'Z'],
    breech: ['R1', 'R3', 'R', 'r'],
    grooves: ['N', 'b', 'Q', 'u'],
    rifling: ['G', 'G1', 'alpha1', 'h', 'i', 's']
  };

  const num = n => String(n);
  const isAngle = field => ANGLES.has(field);
  const isAngleObject = a => a !== null && typeof a === 'object';

  function angle(a) {
    if (isAngleObject(a)) return `${num(a.degrees)}°${num(a.minutes)}'${num(a.seconds)}"`;
    return `${num(a)}°`;
  }
  function angleDegrees(a) {
    if (isAngleObject(a)) return a.degrees + a.minutes / 60 + a.seconds / 3600;
    return a;
  }
  function tolerance(t) { return (t > 0 ? '+' : '') + num(t); }
  function symbol(field) { return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field; }
  function unit(field) {
    if (isAngle(field)) return 'deg';
    if (BAR.has(field)) return 'bar';
    if (field === 'EE') return 'J';
    if (field === 'M') return 'g';
    if (field === 'Q') return 'mm²';
    if (field === 'N') return '';
    return 'mm';
  }
  function value(field, v) { return isAngle(field) ? angle(v) : num(v); }

  function sectionTitle(id) {
    if (SECTION_TITLES[id]) return SECTION_TITLES[id];
    const words = id.replace(/([A-Z])/g, ' $1').toLowerCase();
    return words.charAt(0).toUpperCase() + words.slice(1);
  }
  function rank(list, key) {
    const i = list.indexOf(key);
    return i < 0 ? list.length : i;
  }

  /** The sections of `group` ('cartridge' | 'chamber') ready to render as tables. */
  function sections(record, group) {
    const data = record[group] || {};
    const order = SECTIONS[group].order;
    const ids = Object.keys(data).sort((a, b) => rank(order, a) - rank(order, b));
    const out = [];
    for (const id of ids) {
      const sec = data[id];
      const fields = Object.keys(sec).filter(k => !(k.endsWith('Tol') && k.slice(0, -3) in sec));
      if (!fields.length) continue;
      const fo = FIELD_ORDER[id] || [];
      fields.sort((a, b) => rank(fo, a) - rank(fo, b));
      out.push({
        id,
        title: sectionTitle(id),
        rows: fields.map(f => ({
          field: f,
          symbol: symbol(f),
          value: value(f, sec[f]),
          tol: (f + 'Tol') in sec ? tolerance(sec[f + 'Tol']) : null,
          unit: unit(f)
        }))
      });
    }
    return out;
  }

  function normalise(s) { return String(s).toLowerCase().replace(/,/g, '.').replace(/\s+/g, ''); }
  function matches(record, query) {
    const q = normalise(query || '');
    if (!q) return true;
    return [record.name].concat(record.alternativeNames || []).some(n => normalise(n).includes(q));
  }
  function filter(records, { q = '', family = '' } = {}) {
    return records.filter(r => (!family || r.family === family) && matches(r, q));
  }

  function metadata(record) {
    const ann = record.annotations || {};
    const cap = ann.publishedCapacity;
    return [
      { label: 'Alternative names', text: (record.alternativeNames || []).join(', ') },
      { label: 'Family', text: record.family },
      { label: 'Category', text: ann.category || '' },
      { label: 'Primer type', text: ann.primerType || '' },
      { label: 'C.I.P. table', text: record.tab },
      { label: 'Country', text: record.country },
      { label: 'Published', text: record.published },
      { label: 'Revised', text: record.revised },
      { label: 'Pressure method', text: record.pressureMethod },
      cap
        ? { label: 'Water capacity', text: `${num(cap.grH2O)} gr H2O`, href: cap.url || undefined, linkText: cap.source, note: cap.note || '' }
        : { label: 'Water capacity', text: '' }
    ];
  }

  function listRow(record) {
    const l3 = record.cartridge && record.cartridge.lengths && record.cartridge.lengths.L3;
    return { key: record.key, name: record.name, family: record.family, l3: l3 === undefined ? '' : num(l3) };
  }

  return {
    num, angle, angleDegrees, tolerance, symbol, unit, isAngle, sections, matches, filter, metadata, listRow,
    SECTIONS, FAMILIES: ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire']
  };
});
