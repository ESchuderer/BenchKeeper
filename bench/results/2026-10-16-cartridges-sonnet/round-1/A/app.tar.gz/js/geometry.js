/* Pure geometry of a cartridge: record -> half-profile, bullet, section, dimension targets.
 * Coordinates are [r, z] in mm: z along the axis from the head face (0) to the mouth, r the radius. */
(function (root, factory) {
  const F = typeof module === 'object' && module.exports ? require('./format.js') : root.CIP.format;
  const api = factory(F);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.geometry = api; }
})(typeof self !== 'undefined' ? self : this, function (F) {
  const RAD = Math.PI / 180;
  const has = v => typeof v === 'number' && Number.isFinite(v);
  const hasAngle = v => has(v) || (v !== null && typeof v === 'object' && has(v.degrees));
  const deg = a => F.angleDegrees(a);
  const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);

  const PRIMERS = {
    sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04],
    lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3]
  };
  const HEEL_LIMIT = 0.015;

  /** Rule 1. */
  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    const ratio = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  /** Round the corner B of the path A-B-C with radius rho; t is the tangent length (limited by maxT). */
  function fillet(A, B, C, rho, segments = 12, maxT = Infinity) {
    const ab = dist(A, B), bc = dist(B, C);
    const u = [(B[0] - A[0]) / ab, (B[1] - A[1]) / ab];
    const v = [(C[0] - B[0]) / bc, (C[1] - B[1]) / bc];
    const phi = Math.acos(clamp(u[0] * v[0] + u[1] * v[1], -1, 1));
    if (phi < 1e-9 || !(rho > 0)) return { pts: [B], t: 0, radius: 0 };
    let t = rho * Math.tan(phi / 2);
    if (t > maxT) { t = maxT; rho = t / Math.tan(phi / 2); }
    const left = u[0] * v[1] - u[1] * v[0] > 0;
    const T1 = [B[0] - u[0] * t, B[1] - u[1] * t];
    const n = left ? [-u[1], u[0]] : [u[1], -u[0]];
    const c = [T1[0] + n[0] * rho, T1[1] + n[1] * rho];
    const a1 = Math.atan2(T1[1] - c[1], T1[0] - c[0]);
    const sweep = left ? phi : -phi;
    const pts = [];
    for (let i = 0; i <= segments; i++) {
      const a = a1 + sweep * i / segments;
      pts.push([c[0] + rho * Math.cos(a), c[1] + rho * Math.sin(a)]);
    }
    pts[0] = T1;
    pts[pts.length - 1] = [B[0] + v[0] * t, B[1] + v[1] * t];
    return { pts, t, radius: rho };
  }

  /** Largest radius of the outline at z (vertical segments count at their own z). */
  function outerRadiusAt(pts, z) {
    const eps = 1e-9;
    let best = null;
    for (let i = 1; i < pts.length; i++) {
      const [r0, z0] = pts[i - 1], [r1, z1] = pts[i];
      const lo = Math.min(z0, z1), hi = Math.max(z0, z1);
      if (z < lo - eps || z > hi + eps) continue;
      const r = hi - lo < eps ? Math.max(r0, r1) : r0 + (r1 - r0) * (z - z0) / (z1 - z0);
      if (best === null || r > best) best = r;
    }
    return best;
  }

  /** Radius of a z-monotone polyline, held constant before its first point. */
  function monotoneRadiusAt(pts, z) {
    if (z <= pts[0][1]) return pts[0][0];
    for (let i = 1; i < pts.length; i++) {
      const [r0, z0] = pts[i - 1], [r1, z1] = pts[i];
      if (z <= z1) return z1 === z0 ? r1 : r0 + (r1 - r0) * (z - z0) / (z1 - z0);
    }
    return pts[pts.length - 1][0];
  }

  function arc(cr, cz, rho, from, to, segments) {
    const out = [];
    for (let i = 0; i <= segments; i++) {
      const a = from + (to - from) * i / segments;
      out.push([cr + rho * Math.cos(a), cz + rho * Math.sin(a)]);
    }
    return out;
  }

  function note(notes, feature, missing) {
    notes.push({
      feature, missing,
      text: `Not drawn: ${feature} (${missing.map(F.symbol).join(', ')} not published)`
    });
  }

  /** Rule 7. */
  function buildBullet(rec, ctx) {
    const { L3, L6, G1, H2, walls, notes } = ctx;
    const shape = rec.annotations && rec.annotations.defaultBulletShape;
    const category = rec.annotations && rec.annotations.category;
    const pistol = category === 'pistol';
    const known = ['pointy', 'rounded', 'flat', 'semi_wadcutter'];
    if (!known.includes(shape)) {
      note(notes, 'bullet', ['defaultBulletShape']);
      return null;
    }
    const sFactor = { pointy: 1.0, semi_wadcutter: 0.6 }[shape] || (pistol ? 0.4 : 0.8);
    const k = {
      pointy: 0.40, semi_wadcutter: 0.78,
      rounded: pistol ? 0.65 : 0.55,
      flat: pistol ? 0.70 : 0.60
    }[shape];
    const heeled = H2 - G1 <= HEEL_LIMIT;
    const shank = heeled ? H2 : G1;
    const R = shank / 2;
    const s = sFactor * G1;
    const zb = L3 - s;
    const Lb = L6 - zb;
    const zc = zb + k * Lb;
    const n = L6 - zc;
    const m = { pointy: Math.max(0.08 * G1, 1.27), rounded: 0.15 * G1, flat: 0.55 * G1, semi_wadcutter: 0.6 * G1 }[shape];
    const a = R - m / 2;

    const pts = [[0, zb]];
    let heelRadius = null;
    if (heeled) {
      heelRadius = (H2 - 2 * walls.tb) / 2;
      pts.push([heelRadius, zb], [heelRadius, L3], [R, L3]);
      if (zc > L3 + 1e-9) pts.push([R, zc]);
    } else {
      pts.push([R, zb], [R, zc]);
    }
    const SEG = 24;
    if (shape === 'pointy' && n > a && a > 0) {
      const rho = (a * a + n * n) / (2 * a);
      const cr = R - rho;
      const end = Math.asin(n / rho);
      for (let i = 1; i < SEG; i++) {
        const phi = end * i / SEG;
        pts.push([cr + rho * Math.cos(phi), zc + rho * Math.sin(phi)]);
      }
    } else if (shape === 'rounded') {
      for (let i = 1; i < SEG; i++) {
        const t = (Math.PI / 2) * i / SEG;
        pts.push([m / 2 + a * Math.cos(t), zc + n * Math.sin(t)]);
      }
    }
    pts.push([m / 2, L6], [0, L6]);
    return { shape, s, k, zb, zc, Lb, n, m, heeled, heelRadius, shank, radius: R, pts };
  }

  function build(rec) {
    const c = rec.cartridge || {};
    const head = c.caseHead || {}, collar = c.collar || {}, cone = c.junctionCone || {};
    const len = c.lengths || {}, pc = c.powderChamber || {}, proj = c.projectile || {};
    const required = [['R1', head.R1], ['R', head.R], ['P1', pc.P1], ['H2', collar.H2], ['G1', proj.G1], ['L3', len.L3], ['L6', len.L6]];
    const absent = required.filter(([, v]) => !has(v)).map(([k]) => k);
    if (absent.length) return { ok: false, error: `Cannot draw: ${absent.join(', ')} not published`, notes: [] };

    const { R1, R, E, E1, eMin, f, R3 } = head;
    const { P1, P2 } = pc;
    const { H1, H2 } = collar;
    const { G1 } = proj;
    const { L1, L2, L3, L6 } = len;
    const notes = [];
    const rim = rimType(rec);
    const P = [];
    const push = (r, z) => P.push([r, z]);

    // Rule 2: head face and rim edge
    push(0, 0);
    let chamfer = null;
    if (rim === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      if (rho > 1e-9) {
        for (const p of arc(R1 / 2 - rho, rho, rho, -Math.PI / 2, Math.PI / 2, 16)) push(p[0], p[1]);
        if (2 * rho < R - 1e-9) push(R1 / 2 - rho, R);
      } else {
        push(R1 / 2, 0); push(R1 / 2, R);
      }
    } else {
      if (hasAngle(head.beta) && has(f) ? deg(head.beta) < 90 : false) {
        const cut = Math.min(f * Math.tan(deg(head.beta) * RAD), R1 / 4);
        chamfer = cut;
        push(R1 / 2 - cut, 0); push(R1 / 2, f);
      } else {
        const missing = [];
        if (!hasAngle(head.beta)) missing.push('beta');
        if (!has(f)) missing.push('f');
        if (missing.length) note(notes, 'head chamfer', missing);
        push(R1 / 2, 0);
      }
      push(R1 / 2, R);
    }

    // Rule 3: extractor groove, belt, or plain step
    let bodyStart = R;
    let beltRampEnd = null;
    const groove = has(E) && has(E1) && has(eMin);
    if (groove) {
      push(E1 / 2, R);
      push(E1 / 2, R + eMin);
      if (rim === 'belted' && has(R3) && hasAngle(head.delta) && R3 > E1) {
        const zr = R + eMin + (R3 / 2 - E1 / 2) / Math.tan(deg(head.delta) * RAD);
        beltRampEnd = zr;
        push(R3 / 2, zr);
        push(R3 / 2, E);
      }
      push(P1 / 2, E);
      bodyStart = E;
    } else {
      if (rim === 'rimless' || rim === 'belted' || rim === 'rebated') {
        note(notes, 'extractor groove', ['E', 'E1', 'eMin'].filter(k => !has(head[k])));
      }
      push(P1 / 2, R);
    }
    if (rim === 'belted' && groove && beltRampEnd === null) {
      const missing = [!has(R3) ? 'R3' : null, !hasAngle(head.delta) ? 'delta' : null].filter(Boolean);
      if (missing.length) note(notes, 'belt', missing);
      else notes.push({ feature: 'belt', missing: [], text: 'Not drawn: belt (R3 is not larger than E1)' });
    }
    const bodyIdx = P.length - 1;

    // Rules 4-6: body, shoulder, neck
    const shoulderValues = { alpha: cone.alpha, L1, L2, P2, H1 };
    const present = Object.entries(shoulderValues).filter(([, v]) => (v !== undefined && v !== null));
    const bottleneck = hasAngle(cone.alpha) && has(L1) && has(L2) && has(P2) && has(H1);
    if (!bottleneck && present.length) {
      note(notes, 'shoulder', Object.keys(shoulderValues).filter(k => !present.some(([p]) => p === k)));
    }
    const mouth = { r: H2 / 2, z: L3 };
    let shoulderStart = null, shoulderEnd = null, t1 = 0, t2 = 0;
    if (bottleneck) {
      const A = [P1 / 2, bodyStart], B = [P2 / 2, L1], N = [H1 / 2, L2], M = [H2 / 2, L3];
      const Ls = dist(B, N);
      const f1 = has(cone.r1Min) ? fillet(A, B, N, cone.r1Min, 12) : null;
      const f2 = has(cone.r2) ? fillet(B, N, M, cone.r2, 12) : null;
      let want1 = f1 ? f1.t : 0, want2 = f2 ? f2.t : 0;
      let lim1 = Math.min(want1, 0.45 * dist(A, B)), lim2 = Math.min(want2, 0.45 * dist(N, M));
      if (lim1 + lim2 > 0.9 * Ls) { const q = 0.9 * Ls / (lim1 + lim2); lim1 *= q; lim2 *= q; }
      if (!has(cone.r1Min)) note(notes, 'body-side shoulder corner rounding', ['r1Min']);
      if (!has(cone.r2)) note(notes, 'neck-side shoulder corner rounding', ['r2']);
      const g1 = has(cone.r1Min) ? fillet(A, B, N, cone.r1Min, 12, lim1) : { pts: [B], t: 0 };
      const g2 = has(cone.r2) ? fillet(B, N, M, cone.r2, 12, lim2) : { pts: [N], t: 0 };
      for (const p of g1.pts) push(p[0], p[1]);
      for (const p of g2.pts) push(p[0], p[1]);
      push(M[0], M[1]);
      shoulderStart = { r: B[0], z: B[1] };
      shoulderEnd = { r: N[0], z: N[1] };
      t1 = g1.t; t2 = g2.t;
    } else {
      push(H2 / 2, L3);
    }

    // Rule 8: walls, primer pocket, solid head
    const tn = Math.max(0, (H2 - G1) / 2);
    const tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
    const heeled = H2 - G1 <= HEEL_LIMIT;
    const tnEff = heeled ? tb : tn;
    const walls = { tn, tb, tnEff, heeled };

    let pocket = null;
    if (rim !== 'rimfire') {
      const pr = PRIMERS[(rec.annotations || {}).primerType];
      if (pr) pocket = { diameter: pr[0], depth: pr[1] };
      else note(notes, 'primer pocket', ['primerType']);
    }
    let w = Math.max(2.5, 0.25 * P1 / 2);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (beltRampEnd !== null) w = Math.max(w, beltRampEnd + tb);
    else if (groove) w = Math.max(w, E + tb);

    const bullet = buildBullet(rec, { L3, L6, G1, H2, walls, notes });
    const zb = bullet ? bullet.zb : L3;
    const seat = bullet ? bullet.s : 0;

    const body = P.slice(bodyIdx);
    const wallAt = z => {
      if (bottleneck) {
        if (z <= L1) return tb;
        if (z >= L2) return tnEff;
        return tb + (tnEff - tb) * (z - L1) / (L2 - L1);
      }
      if (heeled || !bullet) return tb;
      const z0 = zb - seat;
      if (z <= z0) return tb;
      if (z >= zb) return tnEff;
      return tb + (tnEff - tb) * (z - z0) / (zb - z0);
    };
    const breaks = bottleneck ? [L1, L2] : (bullet && !heeled ? [zb - seat, zb] : []);
    const zs = [w, L3];
    for (const p of body) if (p[1] > w && p[1] < L3) zs.push(p[1]);
    for (const z of breaks) if (z > w && z < L3) zs.push(z);
    zs.sort((a, b) => a - b);
    const inner = [];
    for (const z of zs) {
      if (inner.length && Math.abs(z - inner[inner.length - 1][1]) < 1e-9) continue;
      inner.push([monotoneRadiusAt(body, z) - wallAt(z), z]);
    }
    const rInMouth = inner[inner.length - 1][0];
    const pocketLine = pocket
      ? [[pocket.diameter / 2, 0], [pocket.diameter / 2, pocket.depth], [0, pocket.depth]] : [];
    const cut = [[pocket ? pocket.diameter / 2 : 0, 0]];
    for (const p of P.slice(1)) cut.push(p);
    cut.push([rInMouth, L3]);
    for (let i = inner.length - 1; i >= 0; i--) cut.push(inner[i]);
    cut.push([0, w]);
    if (pocket) cut.push([0, pocket.depth], [pocket.diameter / 2, pocket.depth]);
    const section = {
      cut, inner, pocketLine,
      floor: [inner[0], [0, w]],
      mouthFace: [[H2 / 2, L3], [rInMouth, L3]]
    };

    // Dimension targets
    const rMax = Math.max(...P.map(p => p[0]));
    const silhouetteR = z => {
      let r = z <= L3 + 1e-9 ? outerRadiusAt(P, z) : null;
      if (bullet && z >= bullet.zb - 1e-9) {
        const br = outerRadiusAt(bullet.pts.slice(1), z);
        if (br !== null && (r === null || br > r)) r = br;
      }
      return r === null ? 0 : r;
    };
    const dims = [];
    const label = (sym, v) => `${sym} ${F.num(v)}`;
    const length = (id, z1, v, r1) => dims.push({
      id, kind: 'length', symbol: id, text: label(id, v), z0: 0, z1, r0: R1 / 2, r1
    });
    length('R', R, R, R1 / 2);
    if (bottleneck) { length('L1', L1, L1, P2 / 2); length('L2', L2, L2, H1 / 2); }
    length('L3', L3, L3, silhouetteR(L3));
    length('L6', L6, L6, bullet ? bullet.m / 2 : H2 / 2);

    const diameter = (id, z, v, r) => dims.push({ id, kind: 'diameter', symbol: id, text: label(id, v), z, r });
    const zR1 = clamp(Math.max(R / 2, chamfer !== null ? f + 0.1 : 0), 0.05, R - 0.05);
    diameter('R1', zR1, R1, outerRadiusAt(P, zR1));
    if (groove) diameter('E1', R + eMin / 2, E1, E1 / 2);
    const zP1 = Math.min(bodyStart + 0.8, bottleneck ? L1 - t1 - 0.5 : L3 - 1);
    diameter('P1', zP1, P1, outerRadiusAt(P, zP1));
    if (bottleneck) {
      const zP2 = Math.max(zP1 + 0.8, L1 - t1 - 0.5);
      diameter('P2', zP2, P2, outerRadiusAt(P, zP2));
      const zH1 = Math.min(L2 + t2 + 0.5, L3 - 0.3);
      diameter('H1', zH1, H1, outerRadiusAt(P, zH1));
    }
    const zH2 = bottleneck ? Math.max(L3 - 1, L2 + t2 + 1.4) : L3 - 1;
    diameter('H2', Math.min(zH2, L3 - 0.3), H2, outerRadiusAt(P, Math.min(zH2, L3 - 0.3)));
    if (bullet) {
      const exposed = Math.min(bullet.zc, L6) - L3;
      if (exposed > 0.15) diameter('G1', L3 + Math.min(exposed / 2, 2.5), G1, bullet.radius);
      else notes.push({ feature: 'G1 dimension', missing: [], text: 'Not drawn: G1 dimension (no straight part of the bullet shank is exposed)' });
    }
    if (bottleneck) {
      dims.push({
        id: 'alpha', kind: 'angle', symbol: 'α', text: `α ${F.angle(cone.alpha)}`,
        z: (L1 + L2) / 2, r: (P2 + H1) / 4
      });
    }

    return {
      ok: true, rimType: rim, profile: P, bodyIndex: bodyIdx, rMax, zMax: Math.max(L3, L6),
      landmarks: { bodyStart, bottleneck, shoulderStart, shoulderEnd, t1, t2, mouth, beltRampEnd, chamfer },
      walls, pocket, w, section, bullet, dims, notes
    };
  }

  return { build, rimType, fillet, outerRadiusAt, monotoneRadiusAt, PRIMERS };
});
