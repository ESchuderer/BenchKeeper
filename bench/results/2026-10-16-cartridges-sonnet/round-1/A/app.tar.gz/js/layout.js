/* Pure placement of dimension lines, extension lines, arrowheads and labels around the cartridge.
 * Diameters (and the shoulder angle) hang from stems above the outside view; lengths run in lanes
 * under the section; a title block closes the sheet. Labels are placed so that they overlap
 * neither each other nor any dimension line. Text width is estimated for a monospace face. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.layout = api; }
})(typeof self !== 'undefined' ? self : this, function () {
  const CHAR_W = 0.62;          // advance of one character, in font sizes (monospace is 0.6)
  const ASCENT = 0.85, DESCENT = 0.2;
  const ARROW = { len: 1.6, half: 0.28 };
  const EXT_GAP = 0.8, EXT_OVER = 0.9, PAD = 0.5, MIN_WIDTH = 100;

  const overlap = (a, b, pad = 0) => a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;

  function layout(g, opts = {}) {
    const fs = opts.fontSize || 2.2;
    const cw = CHAR_W * fs, boxH = (ASCENT + DESCENT) * fs;
    const rMax = g.rMax;
    const textW = s => s.length * cw;
    const makeBox = (x, base, w, anchor) => {
      const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'start' ? x : x - w;
      return { x0, x1: x0 + w, y0: base - ASCENT * fs, y1: base + DESCENT * fs };
    };
    const pitch = boxH + 0.5;
    const rowBottom = row => -(rMax + 1.8) - row * pitch;

    // --- stems above the outside view -------------------------------------------------------
    const specs = g.dims.filter(d => d.kind === 'diameter' || d.kind === 'angle')
      .map(d => ({ d, x: d.z, yEnd: -d.r, w: textW(d.text) }));
    const candidate = (spec, row, anchor) => {
      const bottom = rowBottom(row);
      const base = bottom - DESCENT * fs;
      const tx = anchor === 'middle' ? spec.x : anchor === 'start' ? spec.x - 0.35 : spec.x + 0.35;
      return {
        spec, row, anchor, tx, base,
        box: makeBox(tx, base, spec.w, anchor),
        stem: { x0: spec.x - 0.06, x1: spec.x + 0.06, y0: bottom, y1: spec.yEnd }
      };
    };
    // Iterative deepening on the number of rows, branch and bound on the cost within it.
    const order = specs.slice().sort((p, q) => p.x - q.x);
    const clashes = (c, p) =>
      overlap(c.box, p.box, PAD) || overlap(c.box, p.stem, PAD * 0.6) || overlap(c.stem, p.box, PAD * 0.6);
    const MAX_ROWS = 12;
    let best = null;
    for (let maxRow = 0; maxRow <= MAX_ROWS && !best; maxRow++) {
      let bestCost = Infinity, bestSet = null;
      const chosen = [];
      const dfs = (i, cost) => {
        if (cost >= bestCost) return;
        if (i === order.length) { bestCost = cost; bestSet = chosen.slice(); return; }
        for (let row = 0; row <= maxRow; row++) {
          for (const anchor of ['middle', 'start', 'end']) {
            const c = candidate(order[i], row, anchor);
            if (chosen.some(p => clashes(c, p))) continue;
            chosen.push(c);
            dfs(i + 1, cost + row * 10 + (anchor === 'middle' ? 0 : 1));
            chosen.pop();
          }
        }
      };
      dfs(0, 0);
      if (bestSet) best = { placed: bestSet, cost: bestCost };
    }
    if (!best) throw new Error('layout: no collision-free placement found');

    const items = [];
    const arrow = (x, y, dx, dy) => ({ x, y, dx, dy });
    for (const c of best.placed) {
      const d = c.spec.d, bottom = rowBottom(c.row);
      const item = {
        id: d.id, kind: d.kind, lines: [], arrows: [],
        text: { str: d.text, x: c.tx, y: c.base, anchor: c.anchor, box: c.box }
      };
      if (d.kind === 'diameter') {
        item.lines.push({ x1: d.z, y1: -d.r, x2: d.z, y2: d.r, role: 'dim' });
        item.lines.push({ x1: d.z, y1: -d.r, x2: d.z, y2: bottom, role: 'ext' });
        item.arrows.push(arrow(d.z, -d.r, 0, -1), arrow(d.z, d.r, 0, 1));
      } else {
        item.lines.push({ x1: d.z, y1: -d.r, x2: d.z, y2: bottom, role: 'dim' });
        item.arrows.push(arrow(d.z, -d.r, 0, 1));
      }
      items.push(item);
    }

    // --- length lanes under the section ------------------------------------------------------
    const laneH = boxH + 1.4;
    const laneY = k => rMax + 2.8 + k * laneH;
    const lengths = g.dims.filter(d => d.kind === 'length');
    lengths.forEach((d, k) => {
      const y = laneY(k);
      const small = d.z1 - d.z0 < 2 * ARROW.len + 2 * fs;
      const item = { id: d.id, kind: 'length', lines: [], arrows: [] };
      const ext = (z, r) => ({ x1: z, y1: r + EXT_GAP, x2: z, y2: y + EXT_OVER, role: 'ext' });
      item.lines.push(ext(d.z0, d.r0), ext(d.z1, d.r1));
      if (small) {
        const x0 = d.z0 - ARROW.len - 1.2, x1 = d.z1 + ARROW.len + 1.2;
        item.lines.push({ x1: x0, y1: y, x2: x1, y2: y, role: 'dim' });
        item.arrows.push(arrow(d.z0, y, 1, 0), arrow(d.z1, y, -1, 0));
        const tx = x0 - 0.8, base = y + 0.3 * fs;
        item.text = { str: d.text, x: tx, y: base, anchor: 'end', box: makeBox(tx, base, textW(d.text), 'end') };
      } else {
        item.lines.push({ x1: d.z0, y1: y, x2: d.z1, y2: y, role: 'dim' });
        item.arrows.push(arrow(d.z0, y, -1, 0), arrow(d.z1, y, 1, 0));
        const tx = (d.z0 + d.z1) / 2, base = y - 0.55;
        item.text = { str: d.text, x: tx, y: base, anchor: 'middle', box: makeBox(tx, base, textW(d.text), 'middle') };
      }
      items.push(item);
    });

    // --- title block -----------------------------------------------------------------------
    const rows = (opts.titleRows || []).map(r => r.map(c => ({ ...c })));
    const nameSize = 1.25;
    const rowW = row => row.reduce((w, c) => w + Math.max(c.text.length, c.reserve || 0) * cw * (c.size || 1), 0)
      + (row.length - 1) * 3 * cw;
    const padB = 1.0;
    const rowHeights = rows.map(r => Math.max(...r.map(c => c.size || 1)) * 1.5 * fs);
    const tbW = (rows.length ? Math.max(...rows.map(rowW)) : 0) + 2 * padB;
    const tbH = rowHeights.reduce((a, b) => a + b, 0) + 2 * padB;

    // --- bounds ------------------------------------------------------------------------------
    let x0 = -4, x1 = g.zMax + 4, y0 = -(rMax + 2);
    for (const it of items) {
      x0 = Math.min(x0, it.text.box.x0); x1 = Math.max(x1, it.text.box.x1); y0 = Math.min(y0, it.text.box.y0);
    }
    x0 -= 2; x1 += 2; y0 -= 2;
    x1 = Math.max(x1, x0 + MIN_WIDTH, x0 + tbW + 4);
    const lanesBottom = lengths.length ? laneY(lengths.length - 1) + EXT_OVER : rMax + 2;
    const tbY = lanesBottom + 2.5;
    const titleBlock = { x: x1 - 2 - tbW, y: tbY, w: tbW, h: tbH, cells: [], rules: [] };
    let cy = tbY + padB;
    rows.forEach((row, i) => {
      let cx = titleBlock.x + padB;
      for (const c of row) {
        const size = c.size || 1;
        titleBlock.cells.push({ role: c.role, text: c.text, size, x: cx, y: cy + rowHeights[i] * 0.68 });
        cx += Math.max(c.text.length, c.reserve || 0) * cw * size + 3 * cw;
      }
      cy += rowHeights[i];
      if (i < rows.length - 1) titleBlock.rules.push(cy);
    });
    const y1 = tbY + tbH + 2;
    return { fs, items, titleBlock, bounds: { x0, y0, x1, y1 }, nameSize };
  }

  return { layout, ARROW };
});
