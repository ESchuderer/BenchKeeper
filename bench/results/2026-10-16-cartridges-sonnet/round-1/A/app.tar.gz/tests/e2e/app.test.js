const { test, before, after, describe } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');
const data = require('../../js/data.js');

const INDEX = pathToFileURL(path.resolve(__dirname, '../../index.html')).href;
let browser, server, httpBase;

before(async () => {
  browser = await chromium.launch();
  const { serve } = await import('../../tools/serve.mjs');
  server = await serve(0);
  httpBase = `http://127.0.0.1:${server.address().port}/`;
});
after(async () => { await browser.close(); server.close(); });

async function open(url, opts = {}) {
  const context = await browser.newContext({ viewport: { width: 1200, height: 900 }, ...opts });
  const page = await context.newPage();
  const errors = [], requests = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('request', r => requests.push(r.url()));
  await page.goto(url);
  return { page, context, errors, requests };
}

for (const [mode, base] of [['file://', () => INDEX], ['http', () => httpBase]]) {
  describe(`start page (${mode})`, () => {
    test('lists every cartridge with a link whose text is the name, family and L3', async () => {
      const { page, context, errors } = await open(base());
      assert.equal(await page.locator('h1').innerText(), 'Cartridges');
      assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
      for (const r of data) {
        const link = page.getByRole('link', { name: r.name, exact: true });
        assert.equal(await link.count(), 1, r.name);
        const row = page.locator('tr', { has: link });
        const cells = await row.locator('th, td').allInnerTexts();
        assert.deepEqual(cells, [r.name, r.family, String(r.cartridge.lengths.L3)]);
      }
      assert.deepEqual(errors, []);
      await context.close();
    });

    test('search filters by name and alternative names while typing; family select filters', async () => {
      const { page, context } = await open(base());
      const search = page.getByLabel('Search');
      await search.pressSequentially('7,62 x 51');
      assert.deepEqual(await page.locator('table.cartridges tbody th a').allInnerTexts(), ['308 Win.']);
      assert.equal(await page.getByText('1 cartridges', { exact: true }).count(), 1);
      await search.fill('');
      await search.pressSequentially('22');
      const names = await page.locator('table.cartridges tbody th a').allInnerTexts();
      assert.ok(names.includes('22 Long Rifle') && names.includes('223 Rem.') && names.includes('22 Win. Mag. R.F.'));
      await search.fill('');
      const family = page.getByLabel('Family');
      assert.deepEqual(await family.locator('option').allInnerTexts(), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
      await family.selectOption({ label: 'pistol' });
      assert.equal(await page.getByText('6 cartridges', { exact: true }).count(), 1);
      await search.fill('mag');
      assert.deepEqual(await page.locator('table.cartridges tbody th a').allInnerTexts(), ['357 Magnum', '44 Rem. Mag.']);
      await search.fill('nothing like this');
      assert.equal(await page.getByText('0 cartridges', { exact: true }).count(), 1);
      await family.selectOption({ label: 'All' });
      await search.fill('');
      assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
      await context.close();
    });

    test('the filter survives Back from a detail view, "All cartridges" resets it', async () => {
      const { page, context } = await open(base());
      await page.getByLabel('Search').fill('308');
      await page.getByRole('link', { name: '308 Win.', exact: true }).click();
      await page.goBack();
      assert.equal(await page.getByLabel('Search').inputValue(), '308');
      await page.getByRole('link', { name: '308 Win.', exact: true }).click();
      await page.getByRole('link', { name: 'All cartridges' }).click();
      assert.equal(await page.getByLabel('Search').inputValue(), '');
      assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
      await context.close();
    });
  });

  describe(`detail view (${mode})`, () => {
    test('opens from the list, has its own address and survives a reload', async () => {
      const { page, context } = await open(base());
      await page.getByRole('link', { name: '308 Win.', exact: true }).click();
      await page.locator('h1', { hasText: '308 Win.' }).waitFor();
      assert.match(page.url(), /#\/cartridge\/308_win$/);
      await page.reload();
      assert.equal(await page.locator('h1').innerText(), '308 Win.');
      const direct = await context.newPage();
      await direct.goto(page.url());
      assert.equal(await direct.locator('h1').innerText(), '308 Win.');
      await context.close();
    });

    test('shows metadata, tables with Symbol/Value/Unit, tolerances beside values', async () => {
      const { page, context } = await open(`${base()}#/cartridge/308_win`);
      const dl = await page.locator('dl.meta').innerText();
      for (const s of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) {
        assert.ok(dl.includes(s), s);
      }
      const link = page.locator('dl.meta a');
      assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
      const lengths = page.locator('table[data-section="cartridge.lengths"]');
      assert.deepEqual(await lengths.locator('thead th').allInnerTexts(), ['Symbol', 'Value', 'Unit']);
      const l1 = lengths.locator('tbody tr', { hasText: 'L1' });
      assert.equal((await l1.locator('td').first().innerText()).replace(/\s+/g, ' '), '39.62 -0.2');
      assert.equal(await l1.locator('td').last().innerText(), 'mm');
      assert.equal(await lengths.locator('tbody tr').count(), 4);
      const cone = page.locator('table[data-section="cartridge.junctionCone"]');
      assert.equal(await cone.locator('tbody tr', { has: page.locator('th', { hasText: /^α$/ }) }).locator('td').first().innerText(), '40°');
      assert.ok((await page.locator('table[data-section="chamber.rifling"]').innerText()).includes('71°25\'59"'));
      assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
      assert.equal(await page.getByRole('link', { name: 'All cartridges' }).count(), 1);
      await context.close();
    });

    test('the Print button opens the print dialog', async () => {
      const { page, context } = await open(`${base()}#/cartridge/308_win`);
      await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
      await page.getByRole('button', { name: 'Print' }).click();
      assert.equal(await page.evaluate(() => window.__printed), 1);
      await context.close();
    });

    test('a malformed address does not break the page', async () => {
      const { page, context, errors } = await open(`${base()}#/cartridge/%E0%A4%A`);
      assert.equal(await page.locator('h1').innerText(), 'Not found');
      assert.deepEqual(errors, []);
      await context.close();
    });

    test('unknown address shows a way back', async () => {
      const { page, context } = await open(`${base()}#/cartridge/nope`);
      assert.equal(await page.locator('h1').innerText(), 'Not found');
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await page.locator('h1', { hasText: 'Cartridges' }).waitFor();
      await context.close();
    });
  });
}

describe('drawing', () => {
  test('accessible name, units and true scale (all 25)', async () => {
    const { page, context, errors } = await open(`${INDEX}#/`);
    for (const r of data) {
      await page.goto(`${INDEX}#/cartridge/${r.key}`);
      await page.reload();
      const svg = page.getByRole('img', { name: `${r.name} drawing`, exact: true });
      assert.equal(await svg.count(), 1, r.name);
      const m = await page.evaluate(() => {
        const svg = document.querySelector('svg.drawing');
        const box = s => { const b = svg.querySelector(s).getBBox(); return { x: b.x, y: b.y, w: b.width, h: b.height }; };
        const vb = svg.viewBox.baseVal;
        return { vb: [vb.x, vb.y, vb.width, vb.height], kase: box('path[data-part="case"]'), bullet: box('path[data-part="bullet"]') };
      });
      const c = r.cartridge;
      const near = (a, b, msg) => assert.ok(Math.abs(a - b) < 1e-2, `${r.name} ${msg}: ${a} vs ${b}`);
      near(m.kase.x, 0, 'case starts at the head face');
      near(m.kase.w, c.lengths.L3, 'case length = L3');
      near(m.kase.h, Math.max(c.caseHead.R1, c.caseHead.R3 || 0, c.powderChamber.P1), 'max case diameter');
      near(m.kase.y, -m.kase.h / 2, 'axis in the middle');
      near(m.bullet.x + m.bullet.w, c.lengths.L6, 'bullet tip at L6');
      near(m.bullet.h, c.projectile.G1, 'bullet diameter');
    }
    assert.deepEqual(errors, []);
    await context.close();
  });

  test('every dimension label is there and none overlaps another label or the outline (all 25)', async () => {
    const { page, context } = await open(`${INDEX}#/`);
    const G = require('../../js/geometry.js');
    for (const r of data) {
      await page.goto(`${INDEX}#/cartridge/${r.key}`);
      await page.reload();
      const res = await page.evaluate(() => {
        const svg = document.querySelector('svg.drawing');
        const parts = [...svg.querySelectorAll('.case-outline, .bullet, .section-lines, .mouth-ring, .centreline')];
        const texts = [...svg.querySelectorAll('.dim-text')].map(t => {
          const b = t.getBBox();
          return { s: t.textContent, x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height, len: t.getComputedTextLength() };
        });
        const hits = [];
        for (const t of texts) {
          for (let x = t.x0; x <= t.x1; x += 0.25) {
            for (let y = t.y0; y <= t.y1; y += 0.25) {
              const p = new DOMPoint(x, y);
              for (const part of parts) {
                if (part.isPointInStroke(p) || (part.classList.contains('bullet') && part.isPointInFill(p))) hits.push([t.s, part.getAttribute('class')]);
              }
            }
          }
        }
        const vb = svg.viewBox.baseVal;
        return { texts, hits, vb: [vb.x, vb.y, vb.x + vb.width, vb.y + vb.height] };
      });
      const expected = G.build(r).dims.map(d => d.text).sort();
      assert.deepEqual(res.texts.map(t => t.s).sort(), expected, r.name);
      for (let i = 0; i < res.texts.length; i++) {
        const a = res.texts[i];
        assert.ok(a.x0 >= res.vb[0] && a.x1 <= res.vb[2] && a.y0 >= res.vb[1] && a.y1 <= res.vb[3], `${r.name} ${a.s} inside viewBox`);
        for (let j = i + 1; j < res.texts.length; j++) {
          const b = res.texts[j];
          const ov = a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
          assert.ok(!ov, `${r.name}: "${a.s}" overlaps "${b.s}"`);
        }
      }
      assert.deepEqual(res.hits, [], `${r.name}: label touches the outline`);
    }
    await context.close();
  });

  test('every dimension has a line, arrowheads and (for lengths) extension lines', async () => {
    const { page, context } = await open(`${INDEX}#/cartridge/308_win`);
    for (const id of ['L3', 'L6', 'R1', 'R', 'P1', 'P2', 'H1', 'H2', 'G1', 'L1', 'L2', 'E1', 'alpha']) {
      const g = page.locator(`g.dim[data-dim="${id}"]`);
      assert.equal(await g.count(), 1, id);
      assert.ok(await g.locator('.dim-line').count() >= 1, id);
      assert.ok(await g.locator('.arrow').count() >= 1, id);
      assert.ok(await g.locator('text').count() === 1, id);
    }
    for (const id of ['L3', 'L6', 'R', 'L1', 'L2']) assert.ok(await page.locator(`g.dim[data-dim="${id}"] .ext-line`).count() >= 2, id);
    assert.equal(await page.getByText('L3 51.18', { exact: true }).count(), 1);
    assert.equal(await page.getByText('α 40°', { exact: true }).count(), 1);
    await context.close();
  });

  test('title block and omitted-feature notes', async () => {
    const { page, context } = await open(`${INDEX}#/cartridge/308_win`);
    const tb = await page.locator('g.title-block').textContent();
    for (const s of ['308 Win.', 'C.I.P. table I', 'Revised 2008-09-23', 'Dimensions in mm']) assert.ok(tb.includes(s), s);
    assert.match(await page.locator('[data-role="scale"]').textContent(), /^Scale \d+(\.\d)? : 1$|^Scale 1 : \d+(\.\d)?$/);
    assert.equal(await page.locator('.drawing-notes').count(), 0);
    await page.goto(`${INDEX}#/cartridge/338_lapua_mag`);
    assert.match(await page.locator('.drawing-notes').innerText(), /Not drawn: .*r1 min not published/);
    await context.close();
  });

  test('scales to a phone screen without horizontal scrolling', async () => {
    const { page, context } = await open(`${INDEX}#/cartridge/338_lapua_mag`, { viewport: { width: 360, height: 740 }, deviceScaleFactor: 2 });
    const m = await page.evaluate(() => ({
      sw: document.documentElement.scrollWidth, iw: window.innerWidth,
      svg: document.querySelector('svg.drawing').getBoundingClientRect().width
    }));
    assert.ok(m.sw <= m.iw, `page scrolls horizontally: ${m.sw} > ${m.iw}`);
    assert.ok(m.svg <= 360 && m.svg > 300, `svg width ${m.svg}`);
    await page.goto(`${INDEX}#/`);
    const sw = await page.evaluate(() => document.documentElement.scrollWidth);
    assert.ok(sw <= 360);
    await context.close();
  });
});

describe('look and feel', () => {
  test('follows the system colour scheme', async () => {
    const light = await open(`${INDEX}#/cartridge/308_win`, { colorScheme: 'light' });
    const dark = await open(`${INDEX}#/cartridge/308_win`, { colorScheme: 'dark' });
    const bg = p => p.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    const lum = c => c.match(/\d+/g).slice(0, 3).map(Number).reduce((a, b) => a + b, 0) / 3;
    assert.ok(lum(await bg(light)) > 200);
    assert.ok(lum(await bg(dark)) < 60);
    await light.context.close(); await dark.context.close();
  });

  test('makes no network requests besides its own files', async () => {
    const { page, context, requests } = await open(`${INDEX}#/cartridge/308_win`);
    await page.goto(`${INDEX}#/`);
    assert.ok(requests.length > 0);
    for (const u of requests) assert.ok(u.startsWith('file://'), u);
    const h = await open(`${httpBase}#/cartridge/308_win`);
    for (const u of h.requests) assert.ok(u.startsWith(httpBase), u);
    await context.close(); await h.context.close();
  });
});

describe('print', () => {
  test('hides navigation, is black on white, drawing is 190 mm wide with the true scale', async () => {
    const { page, context } = await open(`${INDEX}#/cartridge/308_win`, { colorScheme: 'dark' });
    await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
    await page.waitForTimeout(300);
    const res = await page.evaluate(() => {
      const vis = s => [...document.querySelectorAll(s)].some(e => e.offsetParent !== null || getComputedStyle(e).position === 'fixed' && getComputedStyle(e).display !== 'none');
      const colors = new Set();
      for (const e of document.querySelectorAll('main *, body')) {
        const cs = getComputedStyle(e);
        if (e.closest('svg') && !e.matches('svg')) continue;
        colors.add(cs.color);
      }
      const svg = document.querySelector('svg.drawing');
      return {
        nav: vis('.site-header, .actions, .filters, .skip-link, .site-footer'),
        bg: getComputedStyle(document.body).backgroundColor,
        colors: [...colors],
        mm: svg.getBoundingClientRect().width / (96 / 25.4),
        vb: Number(svg.dataset.viewWidthMm),
        scale: document.querySelector('[data-role="scale"]').textContent,
        footer: document.querySelector('.print-footer').innerText
      };
    });
    assert.equal(res.nav, false);
    assert.match(res.bg, /rgb\(255, 255, 255\)|rgba\(0, 0, 0, 0\)/);
    assert.deepEqual(res.colors, ['rgb(0, 0, 0)']);
    assert.ok(Math.abs(res.mm - 190) < 0.5, `drawing width ${res.mm} mm`);
    assert.equal(res.scale, `Scale ${(190 / res.vb).toFixed(1)} : 1`);
    assert.match(res.footer, /Source: C\.I\.P\. TDCC, revised 2008-09-23/);
    await context.close();
  });

  test('each detail view prints on exactly one A4 portrait page (all 25)', async () => {
    const { page, context } = await open(`${INDEX}#/`);
    for (const r of data) {
      await page.goto(`${INDEX}#/cartridge/${r.key}`);
      await page.reload();
      await page.emulateMedia({ media: 'print' });
      const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
      const text = pdf.toString('latin1');
      const pages = (text.match(/\/Type\s*\/Page[^s]/g) || []).length;
      const box = text.match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/);
      assert.equal(pages, 1, `${r.name}: ${pages} pages`);
      assert.ok(Math.abs(Number(box[1]) - 595.28) < 1 && Math.abs(Number(box[2]) - 841.89) < 1, `${r.name}: media box ${box.slice(1)}`);
      await page.emulateMedia({ media: 'screen' });
    }
    await context.close();
  });
});
