const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');

test('there are exactly 25 records with unique keys and names', () => {
  assert.equal(data.length, 25);
  assert.equal(new Set(data.map(r => r.key)).size, 25);
  assert.equal(new Set(data.map(r => r.name)).size, 25);
});

test('the five families of the records, counts as supplied', () => {
  const count = {};
  for (const r of data) count[r.family] = (count[r.family] || 0) + 1;
  assert.deepEqual(count, { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3 });
});

test('every record has the fields the app needs', () => {
  for (const r of data) {
    for (const k of ['key', 'name', 'family', 'country', 'tab', 'published', 'revised', 'pressureMethod']) {
      assert.ok(r[k], `${r.key}.${k}`);
    }
    assert.ok(r.cartridge && r.chamber && r.annotations, r.key);
    for (const k of ['L3', 'L6']) assert.equal(typeof r.cartridge.lengths[k], 'number', `${r.key} ${k}`);
  }
});

test('values are exactly as supplied (spot checks)', () => {
  const by = Object.fromEntries(data.map(r => [r.key, r]));
  assert.equal(by['308_win'].cartridge.lengths.L3, 51.18);
  assert.equal(by['308_win'].cartridge.pressures.Pmax, 4150);
  assert.deepEqual(by['308_win'].alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(by['223_rem'].chamber.rifling.i.seconds, 36);
  assert.equal(by['22_long_rifle'].cartridge.lengths.L6, 25.4);
  assert.equal(by['17_hmr'].cartridge.junctionCone.S, 28.79);
  assert.equal(by['6_5_creedmoor'].name, '6,5 Creedmoor');
  assert.equal(by['300_win_mag'].cartridge.caseHead.ETol, -0.2);
  assert.equal(by['44_rem_mag'].chamber.rifling.i, 5);
  assert.equal(by['22_long_rifle'].alternativeNames[1], '22 lang für Büchsen');
  assert.equal(by['338_lapua_mag'].cartridge.junctionCone.r1Min, undefined);
  assert.equal(by['7_mm_rem_mag'].cartridge.projectile.G2, 68.61);
});
