const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const F = require('../../js/format.js');
const rec = key => data.find(r => r.key === key);

test('num prints the value as published: decimal point, no grouping', () => {
  assert.equal(F.num(51.18), '51.18');
  assert.equal(F.num(4150), '4150');
  assert.equal(F.num(25), '25');
  assert.equal(F.num(0.1), '0.1');
  assert.equal(F.num(1825), '1825');
  assert.equal(F.num(-0.2), '-0.2');
});

test('angle: degrees number or d/m/s object', () => {
  assert.equal(F.angle(40), '40°');
  assert.equal(F.angle(35.0), '35°');
  assert.equal(F.angle(0), '0°');
  assert.equal(F.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.angle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
  assert.equal(F.angle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
});

test('angleDegrees converts to decimal degrees', () => {
  assert.equal(F.angleDegrees(40), 40);
  assert.ok(Math.abs(F.angleDegrees({ degrees: 50, minutes: 35, seconds: 2 }) - 50.58389) < 1e-4);
});

test('tolerance is signed and shown as published', () => {
  assert.equal(F.tolerance(-0.2), '-0.2');
  assert.equal(F.tolerance(0.25), '+0.25');
});

test('symbols follow the brief', () => {
  const expect = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax', PK: 'PK', Q: 'Q', E1: 'E1', R1: 'R1'
  };
  for (const [k, v] of Object.entries(expect)) assert.equal(F.symbol(k), v, k);
});

test('units', () => {
  const expect = {
    L3: 'mm', H2: 'mm', R1: 'mm', u: 'mm', h: 'mm', deltaL: 'mm', Fe: 'mm', L3PlusG: 'mm',
    Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '',
    alpha: 'deg', alpha1: 'deg', beta: 'deg', delta: 'deg', i: 'deg'
  };
  for (const [k, v] of Object.entries(expect)) assert.equal(F.unit(k), v, k);
});

test('sections: tolerance sits next to its value and never has a row of its own', () => {
  const secs = F.sections(rec('308_win'), 'cartridge');
  const lengths = secs.find(s => s.id === 'lengths');
  assert.equal(lengths.title, 'Lengths');
  assert.deepEqual(lengths.rows.map(r => r.field), ['L1', 'L2', 'L3', 'L6']);
  const l1 = lengths.rows[0];
  assert.equal(l1.symbol, 'L1');
  assert.equal(l1.value, '39.62');
  assert.equal(l1.tol, '-0.2');
  assert.equal(l1.unit, 'mm');
  for (const s of secs) for (const r of s.rows) assert.ok(!/Tol$/.test(r.field), r.field);
});

test('sections: angles, counts and pressures', () => {
  const ch = F.sections(rec('223_rem'), 'chamber');
  const rifling = ch.find(s => s.id === 'rifling');
  assert.equal(rifling.rows.find(r => r.field === 'i').value, '3°10\'36"');
  assert.equal(rifling.rows.find(r => r.field === 'alpha1').value, '90°');
  assert.equal(rifling.rows.find(r => r.field === 'alpha1').symbol, 'α1');
  const grooves = ch.find(s => s.id === 'grooves');
  assert.equal(grooves.rows.find(r => r.field === 'N').value, '6');
  assert.equal(grooves.rows.find(r => r.field === 'N').unit, '');
  assert.equal(grooves.rows.find(r => r.field === 'Q').unit, 'mm²');
  const pr = F.sections(rec('308_win'), 'cartridge').find(s => s.id === 'pressures');
  assert.equal(pr.rows.find(r => r.field === 'Pmax').value, '4150');
  assert.equal(pr.rows.find(r => r.field === 'EE').unit, 'J');
});

test('sections: empty sections are left out and every value is covered', () => {
  const pistol = F.sections(rec('9_mm_luger'), 'cartridge');
  assert.ok(!pistol.some(s => s.id === 'junctionCone'));
  for (const r of data) {
    for (const group of ['cartridge', 'chamber']) {
      const secs = F.sections(r, group);
      let expected = 0;
      for (const sec of Object.values(r[group])) {
        for (const k of Object.keys(sec)) if (!(k.endsWith('Tol') && k.slice(0, -3) in sec)) expected++;
      }
      assert.equal(secs.reduce((n, s) => n + s.rows.length, 0), expected, `${r.key} ${group}`);
    }
  }
});

test('search matches name and alternative names, ignoring case, spaces and comma/point', () => {
  const r = rec('308_win');
  assert.ok(F.matches(r, '7,62 x 51'));
  assert.ok(F.matches(r, '7.62x51'));
  assert.ok(F.matches(r, '308 winchester'));
  assert.ok(F.matches(r, '308'));
  assert.ok(F.matches(r, ''));
  assert.ok(!F.matches(r, '9 mm'));
  assert.ok(F.matches(rec('22_long_rifle'), '22 lang für'));
});

test('filter combines query and family', () => {
  assert.equal(F.filter(data, { q: '', family: '' }).length, 25);
  assert.equal(F.filter(data, { q: '', family: 'pistol' }).length, 6);
  assert.deepEqual(F.filter(data, { q: '7,62 x 51' }).map(r => r.name), ['308 Win.']);
  assert.equal(F.filter(data, { q: '7,62', family: 'rimless' }).length, 3);
  assert.equal(F.filter(data, { q: 'zzz' }).length, 0);
});

test('metadata rows', () => {
  const m = F.metadata(rec('308_win'));
  const get = l => m.find(x => x.label === l);
  assert.equal(get('Alternative names').text, '308 Winchester, 7,62 x 51');
  assert.equal(get('Family').text, 'rimless');
  assert.equal(get('Category').text, 'rifle');
  assert.equal(get('Primer type').text, 'lr');
  assert.equal(get('C.I.P. table').text, 'I');
  assert.equal(get('Country').text, 'US');
  assert.equal(get('Published').text, '1984-06-14');
  assert.equal(get('Revised').text, '2008-09-23');
  assert.equal(get('Pressure method').text, 'Transducer');
  const cap = get('Water capacity');
  assert.equal(cap.text, '56 gr H2O');
  assert.equal(cap.href, 'http://kwk.us/cases.html');
  assert.equal(cap.linkText, 'kwk');
  assert.equal(cap.note, 'Lapua brass measures 55.8 (lapua-308)');
  const none = F.metadata(rec('223_rem')).find(x => x.label === 'Alternative names');
  assert.equal(none.text, '');
  const nocap = F.metadata(rec('7_x_64')).find(x => x.label === 'Water capacity');
  assert.equal(nocap.text, '');
});

test('list row shows name, family and L3', () => {
  assert.deepEqual(F.listRow(rec('308_win')), { key: '308_win', name: '308 Win.', family: 'rimless', l3: '51.18' });
});

test('review: a capacity without url keeps source and note', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.annotations.publishedCapacity.url;
  const cap = F.metadata(r).find(x => x.label === 'Water capacity');
  assert.equal(cap.href, undefined);
  assert.equal(cap.linkText, 'kwk');
  assert.equal(cap.note, 'Lapua brass measures 55.8 (lapua-308)');
});
