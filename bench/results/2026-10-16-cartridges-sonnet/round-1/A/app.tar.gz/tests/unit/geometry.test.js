const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const F = require('../../js/format.js');
const G = require('../../js/geometry.js');
const rec = key => data.find(r => r.key === key);
const near = (a, b, eps = 1e-6, msg) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} ${a} vs ${b}`);
const hasPoint = (pts, r, z, eps = 1e-6) => pts.some(p => Math.abs(p[0] - r) <= eps && Math.abs(p[1] - z) <= eps);
const clone = r => JSON.parse(JSON.stringify(r));

test('rule 1: rim type', () => {
  assert.equal(G.rimType(rec('300_win_mag')), 'belted');
  assert.equal(G.rimType(rec('22_long_rifle')), 'rimfire');
  assert.equal(G.rimType(rec('38_special')), 'rimmed');
  assert.equal(G.rimType(rec('9_3_x_74_r')), 'rimmed');
  assert.equal(G.rimType(rec('223_rem')), 'rimless');
  assert.equal(G.rimType(rec('9_mm_luger')), 'rimless');
  assert.equal(G.rimType(rec('45_auto')), 'rimless');
  assert.equal(G.rimType(rec('7_62_x_39')), 'rimless');
  const reb = clone(rec('223_rem')); reb.cartridge.caseHead.R1 = 9.0; // 9.0 / 9.58 = 0.939
  assert.equal(G.rimType(reb), 'rebated');
  const edge = clone(rec('223_rem')); edge.cartridge.caseHead.R1 = 9.58 * 1.05;
  assert.equal(G.rimType(edge), 'rimmed');
  const edge2 = clone(rec('223_rem')); edge2.cartridge.caseHead.R1 = 9.58 * 0.98;
  assert.equal(G.rimType(edge2), 'rimless');
});

test('rule 2: chamfered head face and rim edge (223 Rem.)', () => {
  const g = G.build(rec('223_rem'));
  const p = g.profile;
  assert.deepEqual(p[0], [0, 0]);
  const c = Math.min(0.45 * Math.tan(35 * Math.PI / 180), 9.6 / 4);
  near(p[1][0], 4.8 - c); near(p[1][1], 0);
  assert.deepEqual(p[2], [4.8, 0.45]);
  assert.deepEqual(p[3], [4.8, 1.14]);
});

test('rule 2: chamfer is capped at R1/4 and skipped without f or beta >= 90', () => {
  const r = clone(rec('223_rem')); r.cartridge.caseHead.f = 10; r.cartridge.caseHead.beta = 80;
  const g = G.build(r);
  near(g.profile[1][0], 4.8 - 9.6 / 4);
  const r2 = clone(rec('223_rem')); r2.cartridge.caseHead.beta = 90;
  assert.deepEqual(G.build(r2).profile[1], [4.8, 0]);
  const r3 = clone(rec('223_rem')); delete r3.cartridge.caseHead.f;
  const g3 = G.build(r3);
  assert.deepEqual(g3.profile[1], [4.8, 0]);
  assert.ok(g3.notes.some(n => /head chamfer/.test(n.text) && /f/.test(n.text)));
});

test('rule 2: rimfire half-round, outermost at R1/2', () => {
  const g = G.build(rec('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const rs = g.profile.map(p => p[0]);
  near(Math.max(...rs), 7.06 / 2);
  assert.ok(hasPoint(g.profile, 7.06 / 2, rho));
  assert.ok(hasPoint(g.profile, 7.06 / 2 - rho, 0));
  assert.deepEqual(g.profile[0], [0, 0]);
  assert.ok(hasPoint(g.profile, 5.74 / 2, 1.09));
});

test('rule 2: rimfire radius limited by (R1 - P1)/2', () => {
  const r = clone(rec('22_long_rifle')); r.cartridge.caseHead.R1 = 5.74 + 0.4; // (R1-P1)/2 = 0.2 < R/2
  const g = G.build(r);
  near(Math.max(...g.profile.map(p => p[0])), (5.74 + 0.4) / 2);
  assert.ok(hasPoint(g.profile, (5.74 + 0.4) / 2 - 0.2, 0));
});

test('rule 3: extractor groove (223 Rem.)', () => {
  const g = G.build(rec('223_rem'));
  assert.ok(hasPoint(g.profile, 8.43 / 2, 1.14));
  assert.ok(hasPoint(g.profile, 8.43 / 2, 1.14 + 0.76));
  assert.ok(hasPoint(g.profile, 9.58 / 2, 3.13));
  assert.equal(g.landmarks.bodyStart, 3.13);
  assert.equal(g.rimType, 'rimless');
});

test('rule 3: without a groove, step in at z = R (rimmed)', () => {
  const g = G.build(rec('38_special'));
  assert.ok(hasPoint(g.profile, 11.18 / 2, 1.5));
  assert.ok(hasPoint(g.profile, 9.63 / 2, 1.5));
  assert.equal(g.landmarks.bodyStart, 1.5);
  assert.deepEqual(g.notes, []);
});

test('rule 3: belted ramp at angle delta to the axis up to the belt, then step in', () => {
  const g = G.build(rec('300_win_mag'));
  const zr = 1.27 + 0.94 + ((13.51 - 12.07) / 2) / Math.tan(35 * Math.PI / 180);
  assert.ok(hasPoint(g.profile, 13.51 / 2, zr, 1e-9));
  assert.ok(hasPoint(g.profile, 13.51 / 2, 5.59));
  assert.ok(hasPoint(g.profile, 13.03 / 2, 5.59));
  near(g.landmarks.beltRampEnd, zr, 1e-9);
  assert.equal(g.landmarks.bodyStart, 5.59);
});

test('rule 4: straight case runs to (H2/2, L3); bottleneck to (P2/2, L1)', () => {
  const s = G.build(rec('9_mm_luger'));
  assert.equal(s.landmarks.bottleneck, false);
  assert.deepEqual(s.profile[s.profile.length - 1], [9.65 / 2, 19.15]);
  const b = G.build(rec('308_win'));
  assert.equal(b.landmarks.bottleneck, true);
  assert.deepEqual(b.profile[b.profile.length - 1], [8.72 / 2, 51.18]);
  const r = clone(rec('308_win')); delete r.cartridge.junctionCone.alpha;
  assert.equal(G.build(r).landmarks.bottleneck, false);
  const r2 = clone(rec('308_win')); delete r2.cartridge.lengths.L2;
  assert.equal(G.build(r2).landmarks.bottleneck, false);
});

test('rule 5: shoulder passes through the published points; alpha is the included angle', () => {
  for (const r of data) {
    const g = G.build(r);
    if (!g.landmarks.bottleneck) continue;
    const c = r.cartridge;
    const dr = c.powderChamber.P2 / 2 - c.collar.H1 / 2;
    const dz = c.lengths.L2 - c.lengths.L1;
    const half = Math.atan2(dr, dz) * 180 / Math.PI;
    near(half, F.angleDegrees(c.junctionCone.alpha) / 2, 0.3, r.key);
    assert.deepEqual(g.landmarks.shoulderStart, { r: c.powderChamber.P2 / 2, z: c.lengths.L1 });
    assert.deepEqual(g.landmarks.shoulderEnd, { r: c.collar.H1 / 2, z: c.lengths.L2 });
  }
});

test('rule 5: fillets are tangent and use r1 min / r2', () => {
  const g = G.build(rec('308_win'));
  const { t1, t2 } = g.landmarks;
  const half = Math.atan2(5.765 - 4.36, 43.48 - 39.62);
  const taper = Math.atan2(5.98 - 5.765, 39.62 - 3.85);
  near(t1, 0.76 * Math.tan((half - taper) / 2), 1e-3);
  near(t2, 3.18 * Math.tan(half / 2), 1e-3);
  assert.equal(g.profile.some(p => p[0] === 5.765 && p[1] === 39.62), false, 'sharp corner replaced by arc');
  // outline stays inside the sharp polygon and touches both tangent points
  assert.ok(g.profile.length > 20);
});

test('rule 5/9: missing r1 min or r2 leave a sharp corner and are reported', () => {
  const g = G.build(rec('338_lapua_mag'));
  assert.ok(hasPoint(g.profile, 13.82 / 2, 54.9));
  assert.ok(g.notes.some(n => /r1 min/.test(n.text)));
  assert.ok(!g.notes.some(n => /r2/.test(n.text)));
  const h = G.build(rec('17_hmr'));
  assert.ok(h.notes.some(n => /r1 min/.test(n.text)) && h.notes.some(n => /r2/.test(n.text)));
  assert.equal(G.build(rec('223_rem')).notes.length, 0);
});

test('rule 6: neck ends at the mouth', () => {
  const g = G.build(rec('308_win'));
  assert.deepEqual(g.landmarks.mouth, { r: 8.72 / 2, z: 51.18 });
});

test('rule 7: bullet seating, cylinder and nose by shape', () => {
  const cases = [
    // key, s factor, k, meplat factor
    ['308_win', 1.0 * 7.85, 0.40],
    ['22_long_rifle', 0.8 * 5.72, 0.55],
    ['9_mm_luger', 0.4 * 9.03, 0.65],
    ['40_s_w', 0.4 * 10.17, 0.70],
    ['357_magnum', 0.6 * 9.12, 0.78],
    ['17_hmr', 1.0 * 4.38, 0.40]
  ];
  for (const [key, s, k] of cases) {
    const r = rec(key), g = G.build(r), b = g.bullet;
    const L3 = r.cartridge.lengths.L3, L6 = r.cartridge.lengths.L6;
    near(b.s, s, 1e-9, key);
    near(b.zb, L3 - s, 1e-9, key);
    near(b.zc, b.zb + k * (L6 - b.zb), 1e-9, key);
    assert.equal(b.shape, r.annotations.defaultBulletShape);
    const tip = b.pts[b.pts.length - 2];
    near(tip[1], L6, 1e-9, key);
    near(tip[0], b.m / 2, 1e-9, key);
    assert.deepEqual(b.pts[b.pts.length - 1], [0, L6]);
  }
  near(G.build(rec('308_win')).bullet.m, 1.27);
  near(G.build(rec('9_mm_luger')).bullet.m, 0.15 * 9.03);
  near(G.build(rec('40_s_w')).bullet.m, 0.55 * 10.17);
  near(G.build(rec('357_magnum')).bullet.m, 0.6 * 9.12);
  near(G.build(rec('17_hmr')).bullet.m, Math.max(0.08 * 4.38, 1.27));
});

test('rule 7: tangent ogive is an arc of the stated radius, tangent to the shank', () => {
  const g = G.build(rec('308_win')), b = g.bullet;
  const G1 = 7.85, a = G1 / 2 - b.m / 2, n = 71.12 - b.zc;
  const rho = (a * a + n * n) / (2 * a);
  const cr = G1 / 2 - rho;
  const arc = b.pts.filter(p => p[1] > b.zc + 1e-9 && p[1] < 71.12 - 1e-9);
  assert.ok(arc.length > 8);
  for (const [r, z] of arc) near(Math.hypot(r - cr, z - b.zc), rho, 1e-6, 'on arc');
  assert.ok(hasPoint(b.pts, G1 / 2, b.zc));
});

test('rule 7: rounded nose is a quarter ellipse', () => {
  const g = G.build(rec('9_mm_luger')), b = g.bullet;
  const m = 0.15 * 9.03, a = 9.03 / 2 - m / 2, n = 29.69 - b.zc;
  const arc = b.pts.filter(p => p[1] > b.zc + 1e-9 && p[1] < 29.69 - 1e-9);
  assert.ok(arc.length > 6);
  for (const [r, z] of arc) near(((r - m / 2) / a) ** 2 + ((z - b.zc) / n) ** 2, 1, 1e-9);
});

test('rule 7: flat and semi-wadcutter noses are straight cones', () => {
  for (const key of ['40_s_w', '357_magnum']) {
    const b = G.build(rec(key)).bullet;
    const nose = b.pts.filter(p => p[1] >= b.zc - 1e-9);
    assert.equal(nose.length, 3, key); // start, tip rim, axis
  }
});

test('rule 7: heeled case (22 Long Rifle) - exposed bullet has the case OD, heel the ID', () => {
  const g = G.build(rec('22_long_rifle'));
  assert.equal(g.bullet.heeled, true);
  near(g.walls.tb, 0.6);
  near(g.bullet.heelRadius, (5.72 - 2 * 0.6) / 2);
  assert.ok(hasPoint(g.bullet.pts, 5.72 / 2, 15.57));
  assert.ok(hasPoint(g.bullet.pts, g.bullet.heelRadius, 15.57));
  assert.equal(G.build(rec('22_win_mag_r_f')).bullet.heeled, false);
  assert.equal(G.build(rec('308_win')).bullet.heeled, false);
});

test('rule 8: wall thicknesses', () => {
  const g = G.build(rec('308_win'));
  near(g.walls.tn, (8.72 - 7.85) / 2);
  near(g.walls.tb, 0.6);
  const r = clone(rec('308_win')); r.cartridge.collar.H2 = 8.72; r.cartridge.projectile.G1 = 6.0; // tn 1.36
  near(G.build(r).walls.tb, 1.3 * 1.36);
  const r2 = clone(rec('308_win')); r2.cartridge.collar.H2 = 8.72; r2.cartridge.projectile.G1 = 2.0; // 1.3*3.36 > 0.35*P1/2
  near(G.build(r2).walls.tb, 0.35 * 11.96 / 2);
});

test('rule 8: primer pockets', () => {
  const exp = { '223_rem': [4.45, 3.04], '308_win': [5.33, 3.3], '300_win_mag': [5.33, 3.3], '9_mm_luger': [4.45, 3.04],
    '45_auto': [5.33, 3.04], '357_magnum': [4.45, 3.04], '44_rem_mag': [5.33, 3.04], '338_lapua_mag': [5.33, 3.3] };
  for (const [k, [d, h]] of Object.entries(exp)) {
    const p = G.build(rec(k)).pocket;
    assert.deepEqual([p.diameter, p.depth], [d, h], k);
  }
  for (const k of ['22_long_rifle', '22_win_mag_r_f', '17_hmr']) assert.equal(G.build(rec(k)).pocket, null, k);
  const r = clone(rec('308_win')); r.annotations.primerType = 'xx';
  const g = G.build(r);
  assert.equal(g.pocket, null);
  assert.ok(g.notes.some(n => /primer pocket/.test(n.text)));
});

test('rule 8: solid head depth w', () => {
  near(G.build(rec('223_rem')).w, 3.04 + 1.5);
  near(G.build(rec('308_win')).w, 3.3 + 1.5);
  near(G.build(rec('300_win_mag')).w, Math.max(3.3 + 1.5, 1.27 + 0.94 + 0.72 / Math.tan(35 * Math.PI / 180) + 0.6));
  near(G.build(rec('22_long_rifle')).w, 2.5);
  near(G.build(rec('9_mm_luger')).w, 3.04 + 1.5);
  near(G.build(rec('38_special')).w, 3.04 + 1.5);
  const r = clone(rec('223_rem')); r.cartridge.caseHead.E = 6; // E + tb = 6.6 wins
  near(G.build(r).w, 6 + 0.6);
});

test('rule 8: inner line follows the outside at tb on the body and tn on the neck', () => {
  const g = G.build(rec('308_win'));
  const { tb, tn } = g.walls;
  const inner = g.section.inner; // [r, z], ascending z
  const at = z => {
    for (let i = 1; i < inner.length; i++) {
      if (inner[i][1] >= z) {
        const [r0, z0] = inner[i - 1], [r1, z1] = inner[i];
        return z1 === z0 ? r1 : r0 + (r1 - r0) * (z - z0) / (z1 - z0);
      }
    }
  };
  near(at(g.w), G.outerRadiusAt(g.profile, g.w) - tb, 1e-6);
  near(at(20), G.outerRadiusAt(g.profile, 20) - tb, 1e-6);
  near(at(47), G.outerRadiusAt(g.profile, 47) - tn, 1e-6);
  const z = 41.55; // middle of the shoulder
  near(at(z), G.outerRadiusAt(g.profile, z) - (tb + tn) / 2, 1e-2);
  near(inner[0][1], g.w);
  near(inner[inner.length - 1][1], 51.18);
});

test('section polygon starts at the pocket edge and closes along the axis', () => {
  const g = G.build(rec('223_rem'));
  const cut = g.section.cut;
  assert.deepEqual(cut[0], [4.45 / 2, 0]);
  assert.ok(hasPoint(cut, 0, g.w));
  assert.ok(hasPoint(cut, 0, 3.04));
  assert.ok(hasPoint(cut, 4.45 / 2, 3.04));
  const rf = G.build(rec('22_long_rifle'));
  assert.deepEqual(rf.section.cut[0], [0, 0]);
  assert.deepEqual(rf.section.pocketLine, []);
});

test('bullet never overlaps the case wall in the section (all 25)', () => {
  for (const r of data) {
    const g = G.build(r);
    const L3 = r.cartridge.lengths.L3;
    for (const [rb, z] of g.bullet.pts) {
      if (z >= L3 - 1e-9 || z < g.bullet.zb) continue;
      const inner = g.section.inner;
      let rin = null;
      for (let i = 1; i < inner.length; i++) {
        if (inner[i][1] >= z - 1e-9) {
          const [r0, z0] = inner[i - 1], [r1, z1] = inner[i];
          rin = z1 === z0 ? r1 : r0 + (r1 - r0) * (z - z0) / (z1 - z0);
          break;
        }
      }
      assert.ok(rb <= rin + 0.011, `${r.key} z=${z} bullet r ${rb} > inner r ${rin}`);
    }
  }
});

test('every record builds without notes other than the known missing values', () => {
  const expected = {
    '338_lapua_mag': ['r1 min'], '17_hmr': ['r1 min', 'r2']
  };
  for (const r of data) {
    const g = G.build(r);
    assert.equal(g.ok, true, r.key);
    const miss = g.notes.flatMap(n => n.missing.map(F.symbol)).sort();
    assert.deepEqual(miss, (expected[r.key] || []).sort(), r.key);
    assert.ok(g.profile.length > 5);
    for (const p of g.profile) assert.ok(p.every(Number.isFinite), r.key);
    for (const p of g.bullet.pts) assert.ok(p.every(Number.isFinite), r.key);
  }
});

test('rule 9: a missing required value is reported, nothing is invented', () => {
  const r = clone(rec('308_win')); delete r.cartridge.lengths.L6;
  const g = G.build(r);
  assert.equal(g.ok, false);
  assert.match(g.error, /L6/);
  const r2 = clone(rec('308_win')); delete r2.annotations.defaultBulletShape;
  const g2 = G.build(r2);
  assert.equal(g2.bullet, null);
  assert.ok(g2.notes.some(n => /bullet/.test(n.text)));
});

test('dimensions: the required set, plus the published optional ones', () => {
  const ids = key => G.build(rec(key)).dims.map(d => d.id).sort();
  assert.deepEqual(ids('308_win'), ['E1', 'G1', 'H1', 'H2', 'L1', 'L2', 'L3', 'L6', 'P1', 'P2', 'R', 'R1', 'alpha'].sort());
  assert.deepEqual(ids('9_mm_luger'), ['E1', 'G1', 'H2', 'L3', 'L6', 'P1', 'R', 'R1']);
  assert.deepEqual(ids('38_special'), ['G1', 'H2', 'L3', 'L6', 'P1', 'R', 'R1']);
  assert.deepEqual(ids('22_long_rifle'), ['G1', 'H2', 'L3', 'L6', 'P1', 'R', 'R1']);
  assert.ok(ids('17_hmr').includes('alpha'));
});

test('dimension labels carry symbol and value as published', () => {
  const g = G.build(rec('308_win'));
  const text = Object.fromEntries(g.dims.map(d => [d.id, d.text]));
  assert.equal(text.L3, 'L3 51.18');
  assert.equal(text.L6, 'L6 71.12');
  assert.equal(text.R1, 'R1 12.01');
  assert.equal(text.alpha, 'α 40°');
  assert.equal(G.build(rec('6_5_x_55_se')).dims.find(d => d.id === 'alpha').text, 'α 50°35\'2"');
});

test('diameter dimensions touch the outline at the stated radius', () => {
  const g = G.build(rec('308_win'));
  for (const d of g.dims.filter(d => d.kind === 'diameter')) {
    assert.ok(d.r > 0 && Number.isFinite(d.z), d.id);
  }
  const p1 = g.dims.find(d => d.id === 'P1');
  near(p1.r, G.outerRadiusAt(g.profile, p1.z), 1e-9);
  near(p1.r, 11.96 / 2, 0.05);
  const g1 = g.dims.find(d => d.id === 'G1');
  near(g1.r, 7.85 / 2);
  assert.ok(g1.z > 51.18 && g1.z < g.bullet.zc);
  const e1 = g.dims.find(d => d.id === 'E1');
  near(e1.r, 10.39 / 2);
});

test('fillet helper: tangent arc between two lines', () => {
  const f = G.fillet([0, 0], [0, 10], [5, 15], 2, 16);
  const [t1] = f.pts, t2 = f.pts[f.pts.length - 1];
  const turn = Math.PI / 4;
  near(f.t, 2 * Math.tan(turn / 2), 1e-9);
  near(Math.hypot(t1[0], t1[1] - 10), f.t, 1e-9);
  near(Math.hypot(t2[0] - 0, t2[1] - 10), f.t, 1e-9);
  const c = [2, t1[1]];
  for (const p of f.pts) near(Math.hypot(p[0] - c[0], p[1] - c[1]), 2, 1e-9);
});

test('review: beta given as degrees/minutes/seconds still draws the chamfer', () => {
  const r = clone(rec('223_rem')); r.cartridge.caseHead.beta = { degrees: 35, minutes: 0, seconds: 0 };
  const g = G.build(r);
  near(g.profile[1][0], 4.8 - 0.45 * Math.tan(35 * Math.PI / 180));
  assert.deepEqual(g.notes, []);
});

test('review: a belt that cannot be drawn is reported with a sensible message', () => {
  const r = clone(rec('300_win_mag')); r.cartridge.caseHead.R3 = 12.0; // R3 <= E1
  const g = G.build(r);
  const n = g.notes.find(x => /belt/.test(x.text));
  assert.ok(n, 'belt note');
  assert.doesNotMatch(n.text, /\(\s*not published/);
});

test('review: diameter stems never lie beyond the mouth (short neck)', () => {
  const r = clone(rec('308_win')); r.cartridge.lengths.L2 = 50.9; // neck only 0.28 long
  const g = G.build(r);
  for (const d of g.dims.filter(x => x.kind === 'diameter')) {
    assert.ok(d.r > 0, d.id);
    if (d.id !== 'G1') assert.ok(d.z <= 51.18, `${d.id} z=${d.z}`);
  }
});
