const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const G = require('../../js/geometry.js');
const L = require('../../js/layout.js');

const titleRows = r => [[{ role: 'name', text: r.name, size: 1.25 }], [{ role: 'tab', text: `C.I.P. table ${r.tab}` }, { role: 'revised', text: `Revised ${r.revised}` }], [{ role: 'units', text: 'Dimensions in mm' }, { role: 'scale', text: 'Scale 2.0 : 1', reserve: 14 }]];
const scene = r => L.layout(G.build(r), { titleRows: titleRows(r) });
const overlap = (a, b, pad = 0) =>
  a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
const stemRect = l => ({ x0: Math.min(l.x1, l.x2) - 0.05, x1: Math.max(l.x1, l.x2) + 0.05, y0: Math.min(l.y1, l.y2), y1: Math.max(l.y1, l.y2) });

test('every dimension is placed with its label text, line and arrowheads', () => {
  for (const r of data) {
    const g = G.build(r), s = scene(r);
    assert.deepEqual(s.items.map(i => i.id).sort(), g.dims.map(d => d.id).sort(), r.key);
    for (const it of s.items) {
      const d = g.dims.find(x => x.id === it.id);
      assert.equal(it.text.str, d.text, `${r.key} ${it.id}`);
      assert.ok(it.lines.some(l => l.role === 'dim'), `${r.key} ${it.id} dimension line`);
      assert.ok(it.arrows.length >= 1, `${r.key} ${it.id} arrowheads`);
      if (it.kind === 'length') assert.ok(it.lines.filter(l => l.role === 'ext').length >= 2, `${r.key} ${it.id} extension lines`);
      if (it.kind === 'diameter') assert.equal(it.arrows.length, 2);
    }
  }
});

test('labels overlap neither each other, nor lines of other dimensions, nor the outline zone', () => {
  for (const r of data) {
    const g = G.build(r), s = scene(r);
    const boxes = s.items.map(i => ({ id: i.id, ...i.text.box }));
    for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        assert.ok(!overlap(boxes[i], boxes[j], 0.3), `${r.key}: ${boxes[i].id} overlaps ${boxes[j].id}`);
      }
    }
    for (const it of s.items) {
      for (const other of s.items) {
        if (other === it) continue;
        for (const l of other.lines) {
          assert.ok(!overlap(it.text.box, stemRect(l), 0.2), `${r.key}: label ${it.id} crosses a line of ${other.id}`);
        }
      }
      const b = it.text.box;
      const aboveOrBelow = b.y1 < -g.rMax || b.y0 > g.rMax;
      assert.ok(aboveOrBelow, `${r.key}: label ${it.id} sits on the outline zone`);
      assert.ok(b.x0 >= s.bounds.x0 && b.x1 <= s.bounds.x1 && b.y0 >= s.bounds.y0 && b.y1 <= s.bounds.y1, `${r.key}: ${it.id} inside bounds`);
    }
    const tb = s.titleBlock;
    for (const it of s.items) assert.ok(!overlap(it.text.box, { x0: tb.x, y0: tb.y, x1: tb.x + tb.w, y1: tb.y + tb.h }), `${r.key} title block`);
    assert.ok(tb.x >= s.bounds.x0 && tb.x + tb.w <= s.bounds.x1 && tb.y + tb.h <= s.bounds.y1);
  }
});

test('labels are tied to their feature (stem or lane touches the label)', () => {
  const s = scene(data.find(r => r.key === '308_win'));
  for (const it of s.items) {
    const b = it.text.box;
    const touches = it.lines.some(l => {
      const rect = stemRect(l);
      return overlap({ x0: b.x0 - 1.5, x1: b.x1 + 1.5, y0: b.y0 - 1.5, y1: b.y1 + 1.5 }, rect);
    });
    assert.ok(touches, it.id);
  }
});

test('the viewBox is at least 100 mm wide and covers the whole cartridge', () => {
  for (const r of data) {
    const s = scene(r);
    assert.ok(s.bounds.x1 - s.bounds.x0 >= 100 - 1e-9, r.key);
    assert.ok(s.bounds.x0 < -2 && s.bounds.x1 > r.cartridge.lengths.L6 + 2, r.key);
    assert.ok(s.bounds.y0 < -G.build(r).rMax && s.bounds.y1 > G.build(r).rMax, r.key);
  }
});

test('lengths are measured from the head face, in lanes below the section', () => {
  const s = scene(data.find(r => r.key === '308_win'));
  const l3 = s.items.find(i => i.id === 'L3');
  const dim = l3.lines.find(l => l.role === 'dim');
  assert.equal(dim.y1, dim.y2);
  assert.ok(dim.y1 > 6);
  assert.deepEqual([dim.x1, dim.x2].sort((a, b) => a - b), [0, 51.18]);
  const exts = l3.lines.filter(l => l.role === 'ext');
  assert.deepEqual(exts.map(l => l.x1).sort((a, b) => a - b), [0, 51.18]);
});

test('diameters are vertical lines across the outline at the feature', () => {
  const g = G.build(data.find(r => r.key === '308_win'));
  const s = L.layout(g, { titleRows: titleRows(data[0]) });
  const p1 = s.items.find(i => i.id === 'P1');
  const d = g.dims.find(x => x.id === 'P1');
  const dim = p1.lines.find(l => l.role === 'dim');
  assert.equal(dim.x1, d.z);
  assert.deepEqual([dim.y1, dim.y2].sort((a, b) => a - b), [-d.r, d.r]);
});

test('review: the viewBox is wide enough for a long title block', () => {
  const r = JSON.parse(JSON.stringify(data.find(x => x.key === '22_long_rifle')));
  r.name = 'A very long cartridge designation that exceeds the minimum drawing width by far';
  const s = L.layout(G.build(r), { titleRows: titleRows(r) });
  assert.ok(s.titleBlock.x >= s.bounds.x0 + 1.9 && s.titleBlock.x + s.titleBlock.w <= s.bounds.x1);
});
