# 01: Data file and app shell

**What to build:** index.html opens from disk, loads the generated data script, and the 25 records equal the JSONL unchanged.

**Blocked by:** None (can start immediately)

**Status:** done

- [x] js/data.js equals data/cartridges.jsonl record for record
- [x] index.html loads under file:// with no network request
