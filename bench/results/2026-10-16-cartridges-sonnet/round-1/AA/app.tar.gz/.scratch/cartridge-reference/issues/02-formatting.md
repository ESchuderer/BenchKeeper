# 02: Formatting contract

**What to build:** Numbers, angles, symbols, units and tolerances render as published; a detail model groups all values by section.

**Blocked by:** 01

**Status:** done

- [x] 4150 bar, 51.18, 39°59'49", 40°
- [x] <X>Tol never a row of its own; symbols per the brief
