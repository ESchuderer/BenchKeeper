# 03: Start page with search and family filter

**What to build:** Heading Cartridges, 25 linked names with family and L3, Search, Family, count.

**Blocked by:** 01, 02

**Status:** done

- [x] 7,62 x 51 finds 308 Win.
- [x] Family belted lists 2
- [x] n cartridges text
