# 04: Detail view and addresses

**What to build:** Detail view with header facts, value tables, Print button, All cartridges link, hash address surviving reload.

**Blocked by:** 02, 03

**Status:** done

- [x] Tables with Symbol/Value/Unit
- [x] Reload keeps the view; unknown key shows not found
