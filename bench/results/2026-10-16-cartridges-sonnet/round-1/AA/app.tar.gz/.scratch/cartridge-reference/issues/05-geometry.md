# 05: Drawing geometry

**What to build:** Pure geometry model implementing rules 1-9 for all 25 records, with missing-value notes.

**Blocked by:** 01

**Status:** done

- [x] Rim type, profile, walls, pocket, bullet per rules
- [x] Missing value => feature omitted, noted
