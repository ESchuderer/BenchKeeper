# 06: Dimensions, labels, title block, SVG

**What to build:** Inline SVG with dimension lines, non-overlapping labels, title block, accessible name, shown in the detail view.

**Blocked by:** 04, 05

**Status:** done

- [x] Labels L3, L6, R1, R, P1 (+ published others)
- [x] No overlaps on all 25
- [x] Phone width
