# 07: Print sheet

**What to build:** One A4 portrait page per detail view, light, header/drawing/tables/footer.

**Blocked by:** 06

**Status:** done

- [x] PDF of every record is 1 page A4
- [x] No nav/buttons in print
