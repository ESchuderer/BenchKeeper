# 08: Theme, phone layout, verification

**What to build:** Light/dark by system, phone usable, verified on file:// and static server.

**Blocked by:** 06, 07

**Status:** done

- [x] Screenshots reviewed at 360 px and desktop in both themes
