# Spec: C.I.P. cartridge reference (static web app)

Formal requirements with scenarios: `openspec/changes/cartridge-reference-app/` (proposal, specs, design, tasks). The originating brief defines the 25 records, the drawing rules (rules 1-9) and the print layout; this file records the testing decisions and the ticket breakdown.

Status: implemented

## Problem Statement
Reloaders, gunsmiths and engineers want a calm, dense, offline reference of 25 C.I.P. cartridges (cartridge and chamber values, true-to-scale drawing) that opens from a file.

## Solution
Static `index.html` + CSS + classic JS. Start page (search, family filter, count), detail view (meta, drawing, value tables, print), hash addresses, A4 print sheet.

## User Stories
1. As a reloader, I want to type `7,62 x 51` and find "308 Win.", so that I can look up a cartridge by any of its names.
2. As a reloader, I want to filter by family, so that I can see only belted or pistol cartridges.
3. As a gunsmith, I want all cartridge and chamber values in tables with symbol, value and unit, so that I can read a dimension at a glance.
4. As a gunsmith, I want tolerances next to the value, so that I do not have to look them up.
5. As an engineer, I want angles as `39°59'49"`, so that precision is preserved.
6. As an engineer, I want a drawing true to scale with dimension lines, so that I can see how the values relate.
7. As an engineer, I want the drawing to say which feature is not drawn and why, so that I never mistake an assumption for data.
8. As a user on a phone, I want the drawing to fit the screen with legible labels.
9. As a user, I want to bookmark a cartridge, so that I return to it after a reload.
10. As a workshop user, I want a one-page A4 print, so that I can pin it up.
11. As a user in a dark room, I want the dark theme to follow my system, so that the page does not glare.
12. As a user, I want to open `index.html` from disk without a server.

## Implementation Decisions
See `design.md` in the OpenSpec change (hash routing, generated data script, deep modules for format/catalog/geometry/drawing, DOM shell).

## Testing Decisions
- Tests verify external behaviour only. Seams: (1) the browser UI via Playwright on `file://` and a static server; (2) the pure geometry/drawing model in Node; (3) the formatting contract in Node. No mocks.
- Expected values come from the brief and the data (literals), not recomputed by the code under test.
- Prior art: none (greenfield).

## Out of Scope
Editing or adding data, unit conversion, network access, build tooling, bullet databases, ballistics.

## Further Notes
Seams were taken from the brief because it was delivered as a one-shot instruction; they match its "highest seam possible" (the browser), plus two pure seams where the brief's rules are numeric.
