# C.I.P. cartridge reference

A static reference database of 25 C.I.P. cartridges (cartridge and chamber values, true-to-scale drawing, A4 print sheet), modelled on the OpenBallistics cartridge database.

## Use

Open `index.html` directly in a browser (works from `file://`), or serve the folder with any static file server. No build step, no dependencies, no network requests.

Addresses: `index.html` is the list, `index.html#/cartridge/<key>` is a detail view (for example `#/cartridge/308_win`).

## Data

`data/cartridges.jsonl` holds the 25 records (OpenBallistics, MIT, commit e83db43), used unchanged. `js/data.js` is generated from it (`npm run build:data`), because a classic script is the only way to load data from `file://`.

## Development

Dev dependency: Playwright (tests only). Node.js 22.

```
npm install
npx playwright install chromium   # once; on a bare Linux image also: npx playwright install-deps chromium
npm test                          # unit tests: formatting, search, geometry, drawing layout, data
npm run test:e2e                  # browser tests on file:// and a static server, drawing, phone width, A4 print
```

Modules (classic scripts, each also loadable from Node): `js/format.js` (how values are shown), `js/catalog.js` (search and filter), `js/geometry.js` (rules 1-9 of the drawing brief), `js/drawing.js` (dimensions, label placement, SVG), `js/app.js` (DOM and hash routing).

Planning artefacts: `openspec/changes/cartridge-reference-app/` and `.scratch/cartridge-reference/`.
