/* App shell: DOM and hash routing only. The logic lives in CipFormat, CipCatalog, CipGeometry and CipDrawing. */
(function () {
  'use strict';

  var records = window.CIP_CARTRIDGES;
  var Format = window.CipFormat, Catalog = window.CipCatalog, Drawing = window.CipDrawing;
  var ROUTE = /^#\/cartridge\/([^/?#]+)$/;

  var listView = document.getElementById('list-view');
  var detailView = document.getElementById('detail-view');
  var searchInput = document.getElementById('search');
  var familySelect = document.getElementById('family');
  var countEl = document.getElementById('count');
  var emptyEl = document.getElementById('empty');
  var tbody = document.querySelector('#cartridge-list tbody');
  var firstRoute = true;
  var listScroll = 0;

  function h(tag, props) {
    var node = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      if (k === 'text') node.textContent = props[k]; else node.setAttribute(k, props[k]);
    });
    for (var i = 2; i < arguments.length; i++) {
      var kid = arguments[i];
      if (kid !== null && kid !== undefined) node.appendChild(typeof kid === 'string' ? document.createTextNode(kid) : kid);
    }
    return node;
  }

  function addressOf(key) { return '#/cartridge/' + encodeURIComponent(key); }

  // ---- start page ----

  function renderList() {
    var shown = Catalog.filter(records, { query: searchInput.value, family: familySelect.value });
    tbody.textContent = '';
    shown.forEach(function (r) {
      var row = Format.listRow(r);
      tbody.appendChild(h('tr', {},
        h('th', { scope: 'row' }, h('a', { href: addressOf(row.key), text: row.name })),
        h('td', { text: row.family }),
        h('td', { class: 'num', text: row.l3 })));
    });
    countEl.textContent = Catalog.countText(shown.length);
    emptyEl.hidden = shown.length !== 0;
    document.getElementById('cartridge-list').hidden = shown.length === 0;
  }

  function initList() {
    Catalog.FAMILIES.forEach(function (f) {
      familySelect.appendChild(h('option', { value: f, text: f === 'all' ? 'All' : f }));
    });
    document.querySelector('.filters').addEventListener('submit', function (e) { e.preventDefault(); });
    searchInput.addEventListener('input', renderList);
    familySelect.addEventListener('change', renderList);
    renderList();
  }

  // ---- detail view ----

  function factValue(fact) {
    var dd = h('dd', {});
    dd.appendChild(document.createTextNode(fact.value));
    if (fact.link) {
      dd.appendChild(document.createTextNode(', source '));
      dd.appendChild(h('a', { href: fact.link.url, target: '_blank', rel: 'noopener noreferrer', text: fact.link.text }));
    }
    if (fact.note) dd.appendChild(h('span', { class: 'fact-note', text: fact.note }));
    return dd;
  }

  function valueTable(section) {
    var table = h('table', { class: 'values' }, h('caption', { text: section.title }),
      h('thead', {}, h('tr', {},
        h('th', { scope: 'col', text: 'Symbol' }), h('th', { scope: 'col', text: 'Value' }), h('th', { scope: 'col', text: 'Unit' }))));
    var body = h('tbody', {});
    section.rows.forEach(function (row) {
      body.appendChild(h('tr', { 'data-field': row.field },
        h('th', { scope: 'row', text: row.symbol }),
        h('td', { class: 'num', text: row.value }),
        h('td', { class: 'unit', text: row.unit })));
    });
    table.appendChild(body);
    return table;
  }

  function renderDetail(record) {
    var model = Format.detailModel(record);
    var drawing = Drawing.buildDrawing(record);
    detailView.textContent = '';
    detailView.setAttribute('data-key', record.key);

    detailView.appendChild(h('p', { class: 'print-header print-only' }, h('strong', { text: record.name }), ' — C.I.P. cartridge and chamber data'));
    detailView.appendChild(h('nav', { class: 'detail-nav no-print', 'aria-label': 'Cartridge' },
      h('a', { href: '#/', class: 'back', text: 'All cartridges' }),
      h('button', { type: 'button', id: 'print', text: 'Print' })));
    detailView.appendChild(h('h1', { id: 'detail-heading', tabindex: '-1', text: record.name }));

    var facts = h('dl', { class: 'facts' });
    model.facts.forEach(function (f) {
      facts.appendChild(h('div', {}, h('dt', { text: f.label }), factValue(f)));
    });
    detailView.appendChild(facts);

    var drawingSection = h('section', { class: 'drawing-section', 'aria-labelledby': 'drawing-heading' }, h('h2', { id: 'drawing-heading', text: 'Drawing' }));
    var wrap = h('div', { class: 'drawing-wrap' });
    wrap.innerHTML = drawing.svg;
    drawingSection.appendChild(wrap);
    if (drawing.notes.length) {
      var notes = h('ul', { class: 'drawing-notes', 'aria-label': 'Drawing notes' });
      drawing.notes.forEach(function (n) { notes.appendChild(h('li', { text: n })); });
      drawingSection.appendChild(h('p', { class: 'notes-title', text: 'Drawing notes' }));
      drawingSection.appendChild(notes);
    }
    detailView.appendChild(drawingSection);

    model.groups.forEach(function (g) {
      var section = h('section', { class: 'values-section', 'aria-labelledby': 'h-' + g.group }, h('h2', { id: 'h-' + g.group, text: g.title }));
      var grid = h('div', { class: 'table-grid' });
      model.sections.filter(function (s) { return s.group === g.group; }).forEach(function (s) { grid.appendChild(valueTable(s)); });
      section.appendChild(grid);
      detailView.appendChild(section);
    });

    detailView.appendChild(h('p', { class: 'print-footer print-only', text: 'Source: C.I.P. TDCC, revised ' + record.revised }));
    document.getElementById('print').addEventListener('click', function () { window.print(); });
  }

  function renderNotFound() {
    detailView.textContent = '';
    detailView.removeAttribute('data-key');
    detailView.appendChild(h('h1', { id: 'detail-heading', tabindex: '-1', text: 'Cartridge not found' }));
    detailView.appendChild(h('p', {}, 'There is no cartridge at this address. ', h('a', { href: '#/', text: 'All cartridges' })));
  }

  // ---- routing ----

  function keyOf(match) {
    try { return decodeURIComponent(match[1]); } catch (e) { return null; }   // a malformed address is "not found"
  }

  function route() {
    var match = ROUTE.exec(window.location.hash);
    var heading, toList = !match;
    if (!listView.hidden) listScroll = window.scrollY;
    if (toList) {
      detailView.hidden = true;
      listView.hidden = false;
      document.title = 'C.I.P. cartridges';
      heading = listView.querySelector('h1');
    } else {
      var key = keyOf(match);
      var record = records.filter(function (r) { return r.key === key; })[0];
      listView.hidden = true;
      detailView.hidden = false;
      if (record) { renderDetail(record); document.title = record.name + ' – C.I.P. cartridges'; }
      else { renderNotFound(); document.title = 'Cartridge not found – C.I.P. cartridges'; }
      heading = document.getElementById('detail-heading');
    }
    if (!firstRoute) {
      window.scrollTo(0, toList ? listScroll : 0);   // back to the list lands where the user left it
      heading.setAttribute('tabindex', '-1');
      heading.focus({ preventScroll: true });
    }
    firstRoute = false;
  }

  initList();
  window.addEventListener('hashchange', route);
  route();
})();
