/* CipCatalog: search and family filter over the cartridge records. Pure, no DOM. */
(function (root) {
  'use strict';

  var FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  // Lower case, fold diacritics, decimal comma = decimal point, ignore white space.
  function normalise(text) {
    return String(text).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
      .replace(/,/g, '.').replace(/\s+/g, '');
  }

  function matches(record, needle) {
    if (needle === '') return true;
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (n) { return normalise(n).indexOf(needle) !== -1; });
  }

  function filter(records, criteria) {
    var needle = normalise(criteria.query || '');
    var family = criteria.family || 'all';
    return records.filter(function (r) {
      return (family === 'all' || r.family === family) && matches(r, needle);
    });
  }

  function countText(n) { return n + ' cartridges'; }

  var api = { FAMILIES: FAMILIES, filter: filter, countText: countText };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CipCatalog = api;
})(typeof self !== 'undefined' ? self : this);
