/*
 * CipDrawing: geometry -> dimensioned SVG drawing.
 * 1 SVG user unit = 1 mm. Screen x = z (axis horizontal, head on the left); screen y = -r in the upper half
 * (outside view) and +r in the lower half (section). Labels are placed by a small backtracking search so that they do not
 * overlap each other, the outline, or dimension lines.
 */
(function (root) {
  'use strict';

  var Geometry = typeof require === 'function' ? require('./geometry.js') : root.CipGeometry;
  var Format = typeof require === 'function' ? require('./format.js') : root.CipFormat;

  var CHAR_W = 0.62;           // monospace advance, in font sizes (rounded up from 0.60)
  var A4_WIDTH_MM = 190;       // printable width of A4 portrait with 10 mm margins
  var UP = -1, DOWN = 1;

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function n3(v) { return (Math.round(v * 1000) / 1000).toString(); }
  var has = Geometry.isPublished;
  var BOTH_ARROWS = ' marker-start="url(#cip-arrow)" marker-end="url(#cip-arrow)"';
  var END_ARROW = END_ARROW;

  // ---- path helpers (points are (r, z); sgn = UP / DOWN picks the half) ----

  function sweepOf(seg, from, sgn) {
    var ax = from.z - seg.cz, ay = sgn * (from.r - seg.cr);
    var bx = seg.z - seg.cz, by = sgn * (seg.r - seg.cr);
    return ax * by - ay * bx > 0 ? 1 : 0;
  }

  function pathD(segs, sgn) {
    var d = [], cur = null;
    segs.forEach(function (s) {
      if (s.cmd === 'M') d.push('M' + n3(s.z) + ' ' + n3(sgn * s.r));
      else if (s.cmd === 'L') d.push('L' + n3(s.z) + ' ' + n3(sgn * s.r));
      else if (s.cmd === 'Z') d.push('Z');
      else d.push('A' + n3(s.rz) + ' ' + n3(s.rr) + ' 0 0 ' + sweepOf(s, cur, sgn) + ' ' + n3(s.z) + ' ' + n3(sgn * s.r));
      if (s.cmd !== 'Z') cur = s;
    });
    return d.join(' ');
  }

  // Samples a (r, z) path into points, at most `step` mm apart.
  function sample(segs, step) {
    var out = [], cur = null;
    segs.forEach(function (s) {
      if (s.cmd === 'M') { out.push({ r: s.r, z: s.z }); }
      else if (s.cmd === 'L') { pushLine(out, cur, s, step); }
      else if (s.cmd === 'A') {
        var t0 = Math.atan2((cur.z - s.cz) / s.rz, (cur.r - s.cr) / s.rr);
        var t1 = Math.atan2((s.z - s.cz) / s.rz, (s.r - s.cr) / s.rr);
        var dt = t1 - t0;
        if (dt > Math.PI) dt -= 2 * Math.PI;
        if (dt < -Math.PI) dt += 2 * Math.PI;
        var count = Math.max(4, Math.ceil(Math.abs(dt) * Math.max(s.rr, s.rz) / step));
        for (var i = 1; i <= count; i++) {
          var t = t0 + dt * i / count;
          out.push({ r: s.cr + s.rr * Math.cos(t), z: s.cz + s.rz * Math.sin(t) });
        }
      }
      cur = s;
    });
    return out;
  }
  function pushLine(out, a, b, step) {
    var len = Math.hypot(b.r - a.r, b.z - a.z), count = Math.max(1, Math.ceil(len / step));
    for (var i = 1; i <= count; i++) out.push({ r: a.r + (b.r - a.r) * i / count, z: a.z + (b.z - a.z) * i / count });
  }

  // ---- collision geometry ----

  function rectsOverlap(a, b) {
    return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
  }

  function segmentHitsRect(s, rc) {
    var t0 = 0, t1 = 1, dx = s.x2 - s.x1, dy = s.y2 - s.y1;
    var p = [-dx, dx, -dy, dy], q = [s.x1 - rc.left, rc.right - s.x1, s.y1 - rc.top, rc.bottom - s.y1];
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; }
      else {
        var t = q[i] / p[i];
        if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
        else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return t0 < t1 + 1e-12;
  }

  // Does the rectangle touch the silhouette (|y| <= r(z))? Samples are the upper outline as (z, r).
  function rectHitsSilhouette(rc, samples) {
    var nearest = Math.min(Math.abs(rc.top), Math.abs(rc.bottom));
    var spans = rc.top < 0 && rc.bottom > 0;
    for (var i = 0; i < samples.length; i++) {
      var s = samples[i];
      if (s.z < rc.left || s.z > rc.right) continue;
      if (spans || s.r > nearest) return true;
    }
    return false;
  }

  function checkLayout(d) {
    var problems = [], labels = d.labels;
    labels.forEach(function (a, i) {
      for (var j = i + 1; j < labels.length; j++) {
        if (rectsOverlap(a, labels[j])) problems.push('labels overlap: ' + a.text + ' / ' + labels[j].text);
      }
      if (rectHitsSilhouette(a, d.samples)) problems.push('label touches outline: ' + a.text);
      d.segments.forEach(function (s) {
        if (s.owner !== a.symbol && segmentHitsRect(s, a)) problems.push('label crossed by line: ' + a.text + ' / ' + s.owner);
      });
    });
    return problems;
  }

  // ---- drawing ----

  function buildDrawing(record) {
    var geo = Geometry.buildGeometry(record);
    if (!geo.ok) return { ok: false, svg: '', labels: [], segments: [], samples: [], notes: geo.notes, viewBox: [0, 0, 0, 0] };

    var c = record.cartridge, ch = c.caseHead, len = c.lengths, pc = c.powderChamber, col = c.collar, jc = c.junctionCone || {};
    var bullet = geo.bullet;
    var L3 = len.L3, L6 = bullet ? len.L6 : L3;
    var fs = Math.max(L6, L3) / 32;            // font size = one drawing unit; everything scales with it
    var arrow = 0.7 * fs;
    var gap = 0.35 * fs;

    // Silhouette of the outside view (case + exposed bullet), as (z, r) samples for collision tests.
    var bulletExposed = bullet
      ? [{ cmd: 'M', r: bullet.exposedRadius, z: L3 }, { cmd: 'L', r: bullet.exposedRadius, z: bullet.cylinderEnd }].concat(bullet.nose)
      : null;
    var samples = sample(geo.path, 0.1).concat(bulletExposed ? sample(bulletExposed, 0.1) : []);
    var rMax = 0;
    samples.forEach(function (p) { if (p.r > rMax) rMax = p.r; });

    var labels = [], segments = [], drawn = [], bounds = { minX: 0, maxX: Math.max(L3, L6), minY: -rMax, maxY: rMax };
    function grow(x, y) {
      bounds.minX = Math.min(bounds.minX, x); bounds.maxX = Math.max(bounds.maxX, x);
      bounds.minY = Math.min(bounds.minY, y); bounds.maxY = Math.max(bounds.maxY, y);
    }
    function lineEl(cls, x1, y1, x2, y2, extra) {
      return '<line class="' + cls + '" x1="' + n3(x1) + '" y1="' + n3(y1) + '" x2="' + n3(x2) + '" y2="' + n3(y2) + '"' + (extra || '') + '/>';
    }
    // A line that is part of the drawing and an obstacle for labels.
    function line(cls, owner, x1, y1, x2, y2, extra) {
      drawn.push(lineEl(cls, x1, y1, x2, y2, extra));
      segments.push({ x1: x1, y1: y1, x2: x2, y2: y2, owner: owner, cls: cls });
      grow(x1, y1); grow(x2, y2);
    }
    function labelRect(text, left, baseline, owner) {
      return { text: text, symbol: owner, left: left, right: left + text.length * CHAR_W * fs, top: baseline - 0.95 * fs, bottom: baseline + 0.3 * fs, x: left, y: baseline };
    }
    function blocked(rc, owner) {
      var pad = 0.15 * fs;
      var padded = { left: rc.left - pad, right: rc.right + pad, top: rc.top - pad * 0.5, bottom: rc.bottom + pad * 0.5 };
      if (rectHitsSilhouette(padded, samples)) return true;
      for (var i = 0; i < labels.length; i++) if (rectsOverlap(padded, labels[i])) return true;
      for (var j = 0; j < segments.length; j++) {
        if (segments[j].owner !== owner && segmentHitsRect(segments[j], padded)) return true;
      }
      return false;
    }
    function hitsLabel(seg) {
      for (var i = 0; i < labels.length; i++) if (segmentHitsRect(seg, labels[i])) return true;
      return false;
    }

    // ---- length dimensions: rows below the part, nearest first ----
    var rowY = rMax + 1.7 * fs;
    function lengthDim(sym, value, z1, extR, labelLeft) {
      var y = rowY, z0 = 0, short = z1 - z0 < 3.2 * arrow;
      rowY += 1.8 * fs;
      line('ext', sym, z0, extR + gap, z0, y + 0.5 * fs);
      line('ext', sym, z1, extR + gap, z1, y + 0.5 * fs);
      if (short) {
        line('dim', sym, z0 - 1.6 * arrow, y, z0, y, END_ARROW);
        line('dim', sym, z1 + 1.6 * arrow, y, z1, y, END_ARROW);
      } else {
        line('dim', sym, z0, y, z1, y, BOTH_ARROWS + ' data-dim="' + sym + '"');
      }
      var text = sym + ' ' + Format.formatNumber(value), w = text.length * CHAR_W * fs, base = y - 0.4 * fs;
      var first = labelLeft ? z0 - 1.6 * arrow - 0.5 * fs - w : (z0 + z1) / 2 - w / 2;
      var rc = null;
      for (var k = 0; k < 60 && !rc; k++) {
        [first + k * 0.5 * w, first - k * 0.5 * w].forEach(function (x) {
          var t = labelRect(text, x, base, sym);
          if (!rc && !blocked(t, sym)) rc = t;
        });
      }
      rc = rc || labelRect(text, first, base, sym);
      labels.push(rc); grow(rc.left, rc.top); grow(rc.right, rc.bottom);
    }
    var rimR = ch.R1 / 2;
    lengthDim('R', ch.R, ch.R, rimR, true);
    if (has(len.L1)) lengthDim('L1', len.L1, len.L1, has(pc.P2) ? pc.P2 / 2 : rMax);
    if (has(len.L2)) lengthDim('L2', len.L2, len.L2, has(col.H1) ? col.H1 / 2 : rMax);
    lengthDim('L3', L3, L3, col.H2 / 2);
    if (bullet) lengthDim('L6', len.L6, len.L6, bullet.meplat / 2);
    var lastRow = rowY - 1.8 * fs;
    line('ext', 'L3', 0, rimR + gap, 0, lastRow + 0.5 * fs);   // the common extension line at the head face

    // ---- diameter dimensions: a vertical line through the part at the feature, a stem up to the label ----
    var diameters = [];
    function diameter(sym, value, z, radius) { diameters.push({ sym: sym, value: value, z: z, r: radius }); }
    var chamfered = geo.points.some(function (p) { return p.tag === 'chamferEnd'; });
    diameter('R1', ch.R1, chamfered ? (ch.f + ch.R) / 2 : ch.R / 2, ch.R1 / 2);
    if (geo.groove) diameter('E1', ch.E1, ch.R + ch.eMin / 2, ch.E1 / 2);
    diameter('P1', pc.P1, geo.bodyStartZ + 1.5 * fs, pc.P1 / 2);
    if (!geo.straight) {
      diameter('P2', pc.P2, len.L1, pc.P2 / 2);
      diameter('H1', col.H1, len.L2, col.H1 / 2);
    }
    diameter('H2', col.H2, L3, col.H2 / 2);
    if (bullet) diameter('G1', (c.projectile || {}).G1, L3 + (bullet.cylinderEnd - L3) / 2, bullet.exposedRadius);
    diameters.forEach(function (d) {
      line('dim', d.sym, d.z, UP * d.r, d.z, DOWN * d.r, BOTH_ARROWS + ' data-dim="' + d.sym + '"');
    });

    // ---- shoulder angle: included angle at the body-side corner (an arc between the shoulder and its mirror image) ----
    var alphaItem = null;
    if (geo.shoulder && has(jc.alpha)) alphaItem = alphaConstruction();
    function alphaConstruction() {
      var sh = geo.shoulder, half = sh.halfAngleDeg * Math.PI / 180;
      var ax = sh.start.z, ay = UP * sh.start.r;
      var shLen = Math.hypot(sh.end.z - sh.start.z, sh.end.r - sh.start.r);
      var rho = Math.max(0.8 * shLen, 1.6 * fs), long = rho + 0.5 * fs;
      var ex = ax + rho * Math.cos(half), ey = ay - rho * Math.sin(half);
      var sx = ax + rho * Math.cos(half), sy = ay + rho * Math.sin(half);
      line('ext', 'α', ax, ay, ax + long * Math.cos(half), ay - long * Math.sin(half));
      line('ext', 'α', ax, ay, ax + long, ay);
      drawn.push('<path class="dim" data-dim="α"' + BOTH_ARROWS + ' d="M' + n3(sx) + ' ' + n3(sy) +
        ' A' + n3(rho) + ' ' + n3(rho) + ' 0 0 0 ' + n3(ex) + ' ' + n3(ey) + '"/>');
      segments.push({ x1: ax + rho, y1: ay - rho * Math.sin(half), x2: ax + rho, y2: ay + rho * Math.sin(half), owner: 'α', cls: 'dim' });
      grow(ex, ey); grow(sx, sy);
      return { sym: 'α', text: 'α ' + Format.formatAngle(jc.alpha), anchor: { x: ex, y: ey }, ax: ax, ay: ay };
    }

    // ---- label placement: backtracking over (row, alignment) candidates; stems must not cross labels ----
    var items = diameters.slice().sort(function (a, b) { return b.z - a.z; }).map(function (d) {
      var text = d.sym + ' ' + Format.formatNumber(d.value), w = text.length * CHAR_W * fs;
      var cands = [];
      for (var k = 0; k < 10; k++) {
        [[-0.1 * fs, 0], [-w + 0.1 * fs, 1], [-w / 2, 2]].forEach(function (a) {
          var rc = labelRect(text, d.z + a[0], UP * d.r - 0.9 * fs - k * 1.35 * fs, d.sym);
          cands.push({ rc: rc, stem: { x1: d.z, y1: UP * d.r - 0.2 * fs, x2: d.z, y2: rc.bottom, owner: d.sym, cls: 'ext' } });
        });
      }
      return cands;
    });
    if (alphaItem) {
      var ac = [];
      for (var k = 0; k < 14; k++) {
        for (var j = -30; j < 90; j++) {
          var rc = labelRect(alphaItem.text, alphaItem.ax + j * 0.8 * fs, alphaItem.ay - 0.45 * fs - k * 1.45 * fs, 'α');
          var near = { x: Math.max(rc.left, Math.min(alphaItem.anchor.x, rc.right)), y: Math.max(rc.top, Math.min(alphaItem.anchor.y, rc.bottom)) };
          var cost = Math.hypot(near.x - alphaItem.anchor.x, near.y - alphaItem.anchor.y);
          ac.push({ rc: rc, cost: cost, stem: cost > 0.5 * fs ? { x1: alphaItem.anchor.x, y1: alphaItem.anchor.y, x2: near.x, y2: near.y, owner: 'α', cls: 'ext' } : null });
        }
      }
      ac.sort(function (a, b) { return a.cost - b.cost; });
      items.push(ac.slice(0, 400));
    }
    var budget = 40000;
    function place(i) {
      if (i === items.length) return true;
      for (var n = 0; n < items[i].length; n++) {
        if (--budget < 0) return false;
        var cand = items[i][n];
        if (blocked(cand.rc, cand.rc.symbol) || (cand.stem && hitsLabel(cand.stem))) continue;
        labels.push(cand.rc); if (cand.stem) segments.push(cand.stem);
        if (place(i + 1)) { cand.chosen = true; return true; }
        labels.pop(); if (cand.stem) segments.pop();
      }
      return false;
    }
    if (!place(0)) {
      // Cannot happen for the published data (tested); keep going with the first candidates rather than fail.
      items.forEach(function (cands) { labels.push(cands[0].rc); if (cands[0].stem) segments.push(cands[0].stem); cands[0].chosen = true; });
    }
    items.forEach(function (cands) {
      cands.forEach(function (cand) {
        if (!cand.chosen) return;
        if (cand.stem) drawn.push(lineEl('ext', cand.stem.x1, cand.stem.y1, cand.stem.x2, cand.stem.y2));
        grow(cand.rc.left, cand.rc.top); grow(cand.rc.right, cand.rc.bottom);
        if (cand.stem) grow(cand.stem.x2, cand.stem.y2);
      });
    });

    // ---- the drawing itself ----
    var art = [];
    if (geo.walls) art.push('<path class="cut" data-part="wall-section" d="' + hatchPath(geo) + '"/>');
    if (geo.inner) {
      var innerSegs = geo.inner.map(function (q, i) { return { cmd: i ? 'L' : 'M', r: q.r, z: q.z }; });
      art.push('<path class="outline" data-part="inner" d="' + pathD(innerSegs, DOWN) + '"/>');
    }
    if (bullet) {
      var sec = [{ cmd: 'M', r: 0, z: bullet.zb }, { cmd: 'L', r: bullet.seatedRadius, z: bullet.zb }, { cmd: 'L', r: bullet.seatedRadius, z: L3 }];
      if (bullet.exposedRadius !== bullet.seatedRadius) sec.push({ cmd: 'L', r: bullet.exposedRadius, z: L3 });
      sec.push({ cmd: 'L', r: bullet.exposedRadius, z: bullet.cylinderEnd });
      art.push('<path class="bullet" data-part="bullet-section" d="' + pathD(sec.concat(bullet.nose), DOWN) + ' Z"/>');
      art.push('<path class="outline" data-part="bullet-upper" d="' + pathD(bulletExposed, UP) + '"/>');
    }
    art.push('<path class="outline" data-part="case-upper" d="' + pathD(geo.path, UP) + '"/>');
    art.push('<path class="outline" data-part="case-lower" d="' + pathD(geo.path, DOWN) + '"/>');
    var cl0 = -1.5 * fs, cl1 = Math.max(L3, L6) + 1.5 * fs;
    art.push(lineEl('centre', cl0, 0, cl1, 0));
    grow(cl0, 0); grow(cl1, 0);

    // ---- title block (two columns, full width) and view box ----
    var margin = 1.0 * fs;
    var left = [
      { text: record.name, size: 1.3, cls: 'tb-name' },
      { text: 'Dimensions in mm', size: 1, cls: 'tb-line' },
      { text: 'Scale', size: 1, cls: 'tb-line' }
    ];
    var right = [
      { text: 'C.I.P. table ' + (record.tab || '–'), size: 1, cls: 'tb-line' },
      { text: 'Revised ' + (record.revised || '–'), size: 1, cls: 'tb-line' }
    ];
    function columnWidth(lines) { return lines.reduce(function (m, l) { return Math.max(m, l.text.length * CHAR_W * fs * l.size); }, 0); }
    var contentW = bounds.maxX - bounds.minX + 2 * margin;
    var width = Math.max(contentW, 30 * fs);
    left[2].text = 'Scale ' + (Math.round(A4_WIDTH_MM / width * 10) / 10).toFixed(1) + ':1 (A4 print)';
    var minX = bounds.minX - margin - (width - contentW) / 2;
    var minY = bounds.minY - margin;
    var tbTop = bounds.maxY + 1.5 * fs;
    var tbX = minX + 0.5 * margin, tbW = width - margin;
    var rowH = [1.7 * fs, 1.3 * fs, 1.3 * fs];
    var tbHeight = 0.6 * fs + rowH[0] + rowH[1] + rowH[2];
    var colRightX = tbX + tbW - 0.8 * fs - columnWidth(right);
    var tb = ['<g class="title-block"><rect class="tb-frame" x="' + n3(tbX) + '" y="' + n3(tbTop) + '" width="' + n3(tbW) + '" height="' + n3(tbHeight) + '"/>'];
    function tbText(l, x, row) {
      var y = tbTop + 0.3 * fs + rowH.slice(0, row + 1).reduce(function (p, q) { return p + q; }, 0) - 0.3 * fs;
      tb.push('<text class="' + l.cls + '" x="' + n3(x) + '" y="' + n3(y) + '" style="font-size:' + n3(fs * l.size) + 'px">' + esc(l.text) + '</text>');
    }
    left.forEach(function (l, i) { tbText(l, tbX + 0.8 * fs, i); });
    right.forEach(function (l, i) { tbText(l, colRightX, i); });
    tb.push('</g>');
    var viewBox = [minX, minY, width, tbTop + tbHeight + margin - minY];

    var defs = '<defs>' +
      '<marker id="cip-arrow" markerUnits="userSpaceOnUse" markerWidth="' + n3(arrow) + '" markerHeight="' + n3(arrow * 0.5) + '" refX="' + n3(arrow) + '" refY="' + n3(arrow * 0.25) + '" orient="auto-start-reverse">' +
      '<path class="arrowhead" d="M0 0 L' + n3(arrow) + ' ' + n3(arrow * 0.25) + ' L0 ' + n3(arrow * 0.5) + ' Z"/></marker>' +
      '<pattern id="cip-hatch" patternUnits="userSpaceOnUse" width="' + n3(0.45 * fs) + '" height="' + n3(0.45 * fs) + '" patternTransform="rotate(45)">' +
      '<line class="hatch-line" x1="0" y1="0" x2="0" y2="' + n3(0.45 * fs) + '" stroke-width="' + n3(0.08 * fs) + '"/></pattern></defs>';
    var labelEls = labels.map(function (l) {
      return '<text class="dim-label" data-symbol="' + esc(l.symbol) + '" x="' + n3(l.x) + '" y="' + n3(l.y) + '">' + esc(l.text) + '</text>';
    });

    var svg = '<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img" aria-label="' + esc(record.name) + ' drawing"' +
      ' viewBox="' + viewBox.map(n3).join(' ') + '" width="' + n3(width) + 'mm" height="' + n3(viewBox[3]) + 'mm"' +
      ' preserveAspectRatio="xMidYMid meet" style="font-size:' + n3(fs) + 'px" data-rim-type="' + geo.rimType + '">' +
      defs + '<g class="drawing">' + art.join('') + '</g><g class="dimensions">' + drawn.join('') + labelEls.join('') + '</g>' + tb.join('') + '</svg>';

    return { ok: true, svg: svg, viewBox: viewBox, labels: labels, segments: segments, samples: samples, notes: geo.notes };
  }

  // Lower-half wall section: the outer profile, the mouth face, the inner line back down to the head, and the primer pocket notch.
  function hatchPath(geo) {
    var segs = [];
    var outer = geo.path.filter(function (s) { return s.role !== 'mouthFace'; });
    if (geo.pocket) {
      segs.push({ cmd: 'M', r: geo.pocket.diameter / 2, z: 0 });
      segs = segs.concat(outer.slice(1));
    } else {
      segs = outer.slice();
    }
    var inner = geo.inner;
    for (var i = inner.length - 1; i >= 0; i--) segs.push({ cmd: 'L', r: inner[i].r, z: inner[i].z });
    segs.push({ cmd: 'L', r: 0, z: geo.w });
    if (geo.pocket) {
      segs.push({ cmd: 'L', r: 0, z: geo.pocket.depth });
      segs.push({ cmd: 'L', r: geo.pocket.diameter / 2, z: geo.pocket.depth });
    }
    segs.push({ cmd: 'Z' });
    return pathD(segs, DOWN);
  }

  var api = { buildDrawing: buildDrawing, checkLayout: checkLayout };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CipDrawing = api;
})(typeof self !== 'undefined' ? self : this);
