/* CipFormat: how published values are shown. Pure functions, no DOM. */
(function (root) {
  'use strict';

  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  var SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
  };
  var GROUP_TITLES = { cartridge: 'Cartridge values', chamber: 'Chamber values' };
  var DASH = '–';

  function formatNumber(n) { return String(n); }

  function formatAngle(a) {
    if (typeof a === 'number') return formatNumber(a) + '°';
    return a.degrees + '°' + a.minutes + "'" + a.seconds + '"';
  }

  function symbolFor(field) { return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field; }

  function isAngle(field) { return Object.prototype.hasOwnProperty.call(ANGLES, field); }

  function unitFor(field) {
    if (isAngle(field)) return '';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  function formatTolerance(tol) { return (tol > 0 ? '+' : '') + formatNumber(tol); }

  function formatValue(field, value, tol) {
    var text = isAngle(field) ? formatAngle(value) : formatNumber(value);
    return tol === undefined ? text : text + ' ' + formatTolerance(tol);
  }

  function sectionRows(section) {
    return Object.keys(section).filter(function (k) { return !/Tol$/.test(k); }).map(function (field) {
      return {
        field: field,
        symbol: symbolFor(field),
        value: formatValue(field, section[field], section[field + 'Tol']),
        unit: unitFor(field)
      };
    });
  }

  function sectionsOf(record, group) {
    return Object.keys(record[group]).map(function (name) {
      return { group: group, name: name, title: SECTION_TITLES[name] || name, rows: sectionRows(record[group][name]) };
    }).filter(function (s) { return s.rows.length > 0; });
  }

  function orDash(v) { return v === undefined || v === null || v === '' ? DASH : v; }

  function capacityFact(record) {
    var cap = record.annotations && record.annotations.publishedCapacity;
    if (!cap) return { label: 'Water capacity', value: DASH };
    var fact = { label: 'Water capacity', value: formatNumber(cap.grH2O) + ' gr H2O', link: { text: cap.source, url: cap.url } };
    if (cap.note) fact.note = cap.note;
    return fact;
  }

  function detailModel(record) {
    var ann = record.annotations || {};
    var facts = [
      { label: 'Alternative names', value: record.alternativeNames && record.alternativeNames.length ? record.alternativeNames.join('; ') : DASH },
      { label: 'Family', value: orDash(record.family) },
      { label: 'Category', value: orDash(ann.category) },
      { label: 'Primer type', value: orDash(ann.primerType) },
      { label: 'C.I.P. table', value: orDash(record.tab) },
      { label: 'Country', value: orDash(record.country) },
      { label: 'Published', value: orDash(record.published) },
      { label: 'Revised', value: orDash(record.revised) },
      { label: 'Pressure method', value: orDash(record.pressureMethod) },
      capacityFact(record)
    ];
    return {
      key: record.key,
      name: record.name,
      facts: facts,
      groups: [
        { group: 'cartridge', title: GROUP_TITLES.cartridge },
        { group: 'chamber', title: GROUP_TITLES.chamber }
      ],
      sections: sectionsOf(record, 'cartridge').concat(sectionsOf(record, 'chamber'))
    };
  }

  function listRow(record) {
    var l3 = record.cartridge && record.cartridge.lengths && record.cartridge.lengths.L3;
    return {
      key: record.key,
      name: record.name,
      family: record.family,
      l3: l3 === undefined ? DASH : formatNumber(l3) + ' mm'
    };
  }

  var api = {
    formatNumber: formatNumber, formatAngle: formatAngle, formatValue: formatValue,
    symbolFor: symbolFor, unitFor: unitFor, detailModel: detailModel, listRow: listRow
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CipFormat = api;
})(typeof self !== 'undefined' ? self : this);
