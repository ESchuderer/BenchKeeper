/*
 * CipGeometry: record -> drawing geometry, following the brief's rules 1-9.
 * Pure numbers in mm. Coordinates are (r, z): r the radius, z along the axis from the head face.
 * Nothing is invented: when a value a feature needs is missing, the feature is left out and a note names the value.
 */
(function (root) {
  'use strict';

  var Format = typeof require === 'function' ? require('./format.js') : root.CipFormat;

  var EPS = 1e-9;
  var POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };
  // Bullet: seating depth (x G1) and cylinder fraction by shape; pistol differs for rounded and flat.
  var SEATING = {
    pointy: { rifle: 1.0, pistol: 1.0 }, rounded: { rifle: 0.8, pistol: 0.4 },
    flat: { rifle: 0.8, pistol: 0.4 }, semi_wadcutter: { rifle: 0.6, pistol: 0.6 }
  };
  var CYLINDER = {
    pointy: { rifle: 0.40, pistol: 0.40 }, rounded: { rifle: 0.55, pistol: 0.65 },
    flat: { rifle: 0.60, pistol: 0.70 }, semi_wadcutter: { rifle: 0.78, pistol: 0.78 }
  };
  var MEPLAT_FACTOR = { rounded: 0.15, flat: 0.55, semi_wadcutter: 0.6 };

  // A published value: a finite number, or an angle given as degrees, minutes, seconds.
  function has(v) {
    return (typeof v === 'number' && isFinite(v)) || (v !== null && typeof v === 'object' && typeof v.degrees === 'number');
  }

  function degrees(angle) {
    if (typeof angle === 'number') return angle;
    return angle.degrees + angle.minutes / 60 + angle.seconds / 3600;
  }

  function missing(obj, names) { return names.filter(function (n) { return !has(obj[n]); }); }

  function classifyRim(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    var ratio = record.cartridge.caseHead.R1 / record.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function dist(a, b) { return Math.hypot(b.r - a.r, b.z - a.z); }

  // Rounds the corner c between straight segments prev-c and c-next with a circle of the given radius.
  function fillet(prev, c, next, radius) {
    var u = { r: (c.r - prev.r) / dist(prev, c), z: (c.z - prev.z) / dist(prev, c) };
    var v = { r: (next.r - c.r) / dist(c, next), z: (next.z - c.z) / dist(c, next) };
    var dot = Math.max(-1, Math.min(1, u.r * v.r + u.z * v.z));
    var turn = Math.acos(dot);
    if (turn < 1e-6) return null;
    var d = radius * Math.tan(turn / 2);
    var t1 = { r: c.r - u.r * d, z: c.z - u.z * d };
    var t2 = { r: c.r + v.r * d, z: c.z + v.z * d };
    var cross = u.r * v.z - u.z * v.r;
    var left = { r: -u.z, z: u.r };
    var sign = cross > 0 ? 1 : -1;
    return { d: d, t1: t1, t2: t2, center: { r: t1.r + left.r * radius * sign, z: t1.z + left.z * radius * sign } };
  }

  function buildPath(points) {
    var path = [{ cmd: 'M', r: points[0].r, z: points[0].z }];
    for (var i = 1; i < points.length; i++) {
      var p = points[i];
      if (p.arc) {
        path.push({ cmd: 'A', r: p.r, z: p.z, cr: p.arc.cr, cz: p.arc.cz, rr: p.arc.rr, rz: p.arc.rz, role: p.arc.role });
      } else if (p.fillet) {
        var f = fillet(points[i - 1], p, points[i + 1], p.fillet.radius);
        path.push({ cmd: 'L', r: f.t1.r, z: f.t1.z });
        path.push({ cmd: 'A', r: f.t2.r, z: f.t2.z, cr: f.center.r, cz: f.center.z, rr: p.fillet.radius, rz: p.fillet.radius, role: 'fillet' });
      } else {
        path.push({ cmd: 'L', r: p.r, z: p.z });
      }
    }
    return path;
  }

  function buildBullet(ctx) {
    var rec = ctx.rec, ann = rec.annotations || {};
    var G1 = ctx.G1, L3 = ctx.L3, L6 = ctx.L6;
    var shape = ann.defaultBulletShape;
    if (!has(G1) || !has(L6)) {
      ctx.notes.push('Bullet not drawn: ' + missing({ G1: G1, L6: L6 }, ['G1', 'L6']).join(', ') + ' not published.');
      return null;
    }
    if (!SEATING[shape]) { ctx.notes.push('Bullet not drawn: bullet shape not given.'); return null; }
    if (L6 <= L3) { ctx.notes.push('Bullet not drawn: L6 is not longer than L3.'); return null; }
    var kind = ann.category === 'pistol' ? 'pistol' : 'rifle';   // rimfire counts as rifle
    var s = SEATING[shape][kind] * G1;
    var k = CYLINDER[shape][kind];
    var zb = L3 - s;
    var length = L6 - zb;
    var cylinderEnd = zb + k * length;
    var noseLength = L6 - cylinderEnd;
    var exposedRadius = (ctx.heeled ? ctx.H2 : G1) / 2;
    var seatedRadius = ctx.heeled && ctx.walls ? (ctx.H2 - 2 * ctx.walls.tb) / 2 : exposedRadius;
    var meplat = shape === 'pointy' ? Math.max(0.08 * 2 * exposedRadius, 1.27) : MEPLAT_FACTOR[shape] * 2 * exposedRadius;
    var d = exposedRadius - meplat / 2;
    var nose, ogiveRadius;
    if (shape === 'pointy') {
      ogiveRadius = (d * d + noseLength * noseLength) / (2 * d);
      nose = [{ cmd: 'A', r: meplat / 2, z: L6, cr: exposedRadius - ogiveRadius, cz: cylinderEnd, rr: ogiveRadius, rz: ogiveRadius, role: 'ogive' }];
    } else if (shape === 'rounded') {
      nose = [{ cmd: 'A', r: meplat / 2, z: L6, cr: meplat / 2, cz: cylinderEnd, rr: d, rz: noseLength, role: 'ellipse' }];
    } else {
      nose = [{ cmd: 'L', r: meplat / 2, z: L6 }];
    }
    nose.push({ cmd: 'L', r: 0, z: L6 });
    return {
      shape: shape, s: s, k: k, zb: zb, length: length, cylinderEnd: cylinderEnd,
      meplat: meplat, ogiveRadius: ogiveRadius, exposedRadius: exposedRadius, seatedRadius: seatedRadius,
      heeled: ctx.heeled, nose: nose
    };
  }

  function buildGeometry(record) {
    var c = record.cartridge || {};
    var ch = c.caseHead || {}, col = c.collar || {}, jc = c.junctionCone || {}, len = c.lengths || {};
    var pc = c.powderChamber || {}, proj = c.projectile || {};
    var ann = record.annotations || {};
    var notes = [];
    var essential = missing({ R1: ch.R1, R: ch.R, P1: pc.P1, L3: len.L3, H2: col.H2 }, ['R1', 'R', 'P1', 'L3', 'H2']);
    if (essential.length) {
      return { ok: false, name: record.name, notes: ['Drawing not possible: ' + essential.join(', ') + ' not published.'] };
    }
    var R1 = ch.R1, R = ch.R, P1 = pc.P1, L3 = len.L3, H2 = col.H2;
    var rimType = classifyRim(record);
    var points = [];
    function add(r, z, tag, extra) {
      var p = { r: r, z: z, tag: tag };
      if (extra) for (var key in extra) p[key] = extra[key];
      points.push(p);
      return p;
    }

    // Rule 2: head face and rim edge.
    add(0, 0, 'headCenter');
    if (rimType === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      var cr = R1 / 2 - rho, cz = R / 2;
      add(cr, 0, 'rimFaceEnd');
      if (cz - rho > EPS) add(cr, cz - rho, 'rimArcStart');
      add(R1 / 2, cz, 'rimApex', { arc: { cr: cr, cz: cz, rr: rho, rz: rho, role: 'rim' } });
      add(cr, cz + rho, 'rimArcEnd', { arc: { cr: cr, cz: cz, rr: rho, rz: rho, role: 'rim' } });
      if (R - (cz + rho) > EPS) add(cr, R, 'rimEdgeEnd');
    } else {
      var hasBeta = has(ch.beta), hasF = has(ch.f);
      if (hasBeta && hasF && degrees(ch.beta) < 90) {
        var cham = Math.min(ch.f * Math.tan(degrees(ch.beta) * Math.PI / 180), R1 / 4);
        add(R1 / 2 - cham, 0, 'chamferStart');
        add(R1 / 2, ch.f, 'chamferEnd');
      } else {
        add(R1 / 2, 0, 'rimCorner');
        var absent = missing(ch, ['beta', 'f']);
        if (absent.length) notes.push('Head chamfer not drawn: ' + absent.map(Format.symbolFor).join(', ') + ' not published.');
      }
      add(R1 / 2, R, 'rimEdgeEnd');
    }

    // Rule 3: extractor groove, belt, or a plain step in.
    var groove = false, belted = false, rampEndZ = null;
    var grooveMissing = rimType === 'rimfire' ? [] : missing(ch, ['E', 'E1', 'eMin']);
    var E = ch.E, bodyStartZ = R;
    if (rimType !== 'rimfire' && !grooveMissing.length) {
      groove = true;
      add(ch.E1 / 2, R, 'grooveIn');
      add(ch.E1 / 2, R + ch.eMin, 'grooveFloorEnd');
      if (rimType === 'belted') {
        var beltMissing = missing(ch, ['R3', 'delta']);
        if (beltMissing.length) {
          notes.push('Belt not drawn: ' + beltMissing.map(Format.symbolFor).join(', ') + ' not published.');
        } else if (ch.R3 / 2 <= ch.E1 / 2) {
          notes.push('Belt not drawn: R3 is not larger than E1.');
        } else {
          var rampDz = (ch.R3 / 2 - ch.E1 / 2) / Math.tan(degrees(ch.delta) * Math.PI / 180);
          rampEndZ = R + ch.eMin + rampDz;
          if (rampEndZ <= E) {
            belted = true;
            add(ch.R3 / 2, rampEndZ, 'beltRampEnd');
            add(ch.R3 / 2, E, 'beltEnd');
          } else {
            rampEndZ = null;
            notes.push('Belt not drawn: the ramp at δ ends beyond E.');
          }
        }
      }
      add(P1 / 2, E, 'bodyStart');
      bodyStartZ = E;
    } else {
      if (grooveMissing.length) notes.push('Extractor groove not drawn: ' + grooveMissing.map(Format.symbolFor).join(', ') + ' not published.');
      add(P1 / 2, R, 'bodyStart');
    }

    // Rules 4-6: body, shoulder, neck.
    var shoulderNeeds = missing({ alpha: jc.alpha, L1: len.L1, L2: len.L2 }, ['alpha', 'L1', 'L2']);
    var allNeeds = missing({ alpha: jc.alpha, L1: len.L1, L2: len.L2, P2: pc.P2, H1: col.H1 }, ['alpha', 'L1', 'L2', 'P2', 'H1']);
    var straight = allNeeds.length > 0 || !(len.L1 > bodyStartZ && len.L2 > len.L1 && L3 > len.L2);
    var shoulder = null;
    if (straight) {
      if (shoulderNeeds.length === 3) {
        notes.push('Straight case, shoulder not drawn: α, L1, L2 not published.');
      } else if (allNeeds.length) {
        notes.push('Shoulder not drawn: ' + allNeeds.map(Format.symbolFor).join(', ') + ' not published.');
      } else {
        notes.push('Shoulder not drawn: L1, L2 and L3 are not in increasing order.');
      }
      add(H2 / 2, L3, 'mouth');
    } else {
      var r1 = jc.r1Min, r2 = jc.r2;
      var s0 = add(pc.P2 / 2, len.L1, 'shoulderStart', has(r1) ? { fillet: { radius: r1 } } : null);
      var s1 = add(col.H1 / 2, len.L2, 'shoulderEnd', has(r2) ? { fillet: { radius: r2 } } : null);
      add(H2 / 2, L3, 'mouth');
      var shoulderLen = dist(s0, s1);
      var d0 = s0.fillet ? fillet(points[points.indexOf(s0) - 1], s0, s1, r1).d : 0;
      var d1 = s1.fillet ? fillet(s0, s1, points[points.indexOf(s1) + 1], r2).d : 0;
      var prevLen = dist(points[points.indexOf(s0) - 1], s0), nextLen = dist(s1, points[points.indexOf(s1) + 1]);
      if (s0.fillet && (d0 + d1 > shoulderLen || d0 > prevLen)) { delete s0.fillet; notes.push('Rounding r1 min not drawn: it does not fit the shoulder.'); d0 = 0; }
      if (s1.fillet && (d0 + d1 > shoulderLen || d1 > nextLen)) { delete s1.fillet; notes.push('Rounding r2 not drawn: it does not fit the shoulder.'); }
      if (!has(r1)) notes.push('Rounding of the body-side shoulder corner not drawn: r1 min not published.');
      if (!has(r2)) notes.push('Rounding of the neck-side shoulder corner not drawn: r2 not published.');
      shoulder = {
        start: { r: s0.r, z: s0.z }, end: { r: s1.r, z: s1.z },
        halfAngleDeg: Math.atan2(s0.r - s1.r, s1.z - s0.z) * 180 / Math.PI,
        alpha: jc.alpha
      };
    }

    // Rule 8: walls, head thickness, primer pocket, inner line.
    var G1 = proj.G1;
    var walls = null, heeled = false;
    if (has(G1)) {
      var tn = (H2 - G1) / 2;
      heeled = H2 - G1 <= 0.015;
      var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
      walls = { tn: tn, tb: tb, tnApplied: heeled ? tb : tn };
    } else {
      notes.push('Section walls not drawn: G1 not published.');
    }
    var pocket = null;
    var primer = ann.primerType;
    if (rimType !== 'rimfire' && primer !== 'rimfire') {
      if (POCKET_DIAMETER[primer]) pocket = { diameter: POCKET_DIAMETER[primer], depth: POCKET_DEPTH[primer] };
      else notes.push('Primer pocket not drawn: primer type not published.');
    }
    var w = null, inner = null;
    if (walls) {
      var candidates = [2.5, 0.25 * P1 / 2];
      if (pocket) candidates.push(pocket.depth + 1.5);
      if (belted) candidates.push(rampEndZ + walls.tb);
      else if (groove) candidates.push(E + walls.tb);
      w = Math.max.apply(null, candidates);
      var z1 = straight ? L3 : len.L1, r1o = straight ? H2 / 2 : pc.P2 / 2;
      var rBody = function (z) {
        if (z <= bodyStartZ) return P1 / 2;
        return P1 / 2 + (r1o - P1 / 2) * (Math.min(z, z1) - bodyStartZ) / (z1 - bodyStartZ);
      };
      inner = [{ r: rBody(w) - walls.tb, z: w }];
      if (!straight) {
        inner.push({ r: pc.P2 / 2 - walls.tb, z: len.L1 });
        inner.push({ r: col.H1 / 2 - walls.tnApplied, z: len.L2 });
      }
      inner.push({ r: H2 / 2 - walls.tnApplied, z: L3 });
    }

    var bullet = buildBullet({ rec: record, G1: G1, L3: L3, L6: len.L6, H2: H2, heeled: heeled, walls: walls, notes: notes });

    var path = buildPath(points);
    var mouthR = bullet ? Math.min(H2 / 2, bullet.exposedRadius) : H2 / 2;
    if (mouthR < H2 / 2 - EPS) path.push({ cmd: 'L', r: mouthR, z: L3, role: 'mouthFace' });

    return {
      ok: true, name: record.name, rimType: rimType, straight: straight, heeled: heeled, belted: belted, groove: groove,
      points: points, path: path, shoulder: shoulder, walls: walls, pocket: pocket, w: w, inner: inner,
      bullet: bullet, notes: notes, bodyStartZ: bodyStartZ
    };
  }

  var api = { buildGeometry: buildGeometry, classifyRim: classifyRim, isPublished: has };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CipGeometry = api;
})(typeof self !== 'undefined' ? self : this);
