## Why

Reloaders, gunsmiths and engineers need a quick, offline-capable reference for the C.I.P. cartridge and chamber dimensions of 25 common cartridges, with a true-to-scale drawing, modelled on the OpenBallistics cartridge database. No such static, dependency-free viewer exists for this data set.

## What Changes

- New static web app (plain HTML/CSS/JS, no build step, no network requests) opened directly from `index.html` (`file://`) or from any static file server.
- Start page listing all 25 cartridges with search (name and alternative names) and a family filter.
- Detail view per cartridge, with its own bookmarkable address, showing meta data, the water capacity with source link, an inline SVG drawing computed from the record, and tables of all cartridge and chamber values.
- Print layout: one A4 portrait page per detail view.
- Light/dark on screen following the system; print always light.

## Capabilities

### New Capabilities
- `cartridge-catalog`: start page, search, family filter, count.
- `cartridge-detail`: detail view, value tables, tolerances, angle and number formatting, addressable views.
- `cartridge-drawing`: computed 2D drawing (outline, section, bullet, dimensions, title block, missing-value notes).
- `cartridge-print`: A4 portrait print layout.

### Modified Capabilities
None.

## Impact

New files only: `index.html`, `css/`, `js/`, `data/`, `tests/`, `tools/`. Dev dependency: Playwright (tests only). The 25 records are used unchanged.
