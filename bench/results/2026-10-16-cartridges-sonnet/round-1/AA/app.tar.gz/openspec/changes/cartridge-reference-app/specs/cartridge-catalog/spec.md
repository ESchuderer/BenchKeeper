# Spec Delta

## Purpose
The start page lets a user find one of the 25 cartridges quickly by name, alternative name or family and open its detail view.

## ADDED Requirements

### Requirement: Cartridge list
The start page SHALL have the heading "Cartridges" and list every cartridge with its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name` and which opens the detail view.

#### Scenario: All cartridges listed
- **WHEN** the start page is opened
- **THEN** 25 links are shown, e.g. "6,5 Creedmoor", each row with family and L3 such as "51.18 mm"
- **AND** the text "25 cartridges" is shown

### Requirement: Search
A field labelled "Search" SHALL filter the list by name and alternative names while the user types.

#### Scenario: Forgiving match
- **WHEN** the user types `6.5 creed` or `7,62x51` or `BUCHSEN`
- **THEN** "6,5 Creedmoor", "308 Win." and "22 Long Rifle" are found: case, diacritics and spaces are ignored and a decimal point equals a decimal comma

#### Scenario: Alternative name
- **WHEN** the user types `7,62 x 51`
- **THEN** only "308 Win." is listed and the text reads "1 cartridges"

#### Scenario: No match
- **WHEN** the user types text that matches nothing
- **THEN** no cartridge is listed, the text reads "0 cartridges" and an empty-state message is shown

### Requirement: Family filter
A select labelled "Family" with the options All, rimless, rimmed, belted, pistol, rimfire SHALL filter by family, combinable with Search.

#### Scenario: Belted
- **WHEN** the user selects "belted"
- **THEN** "300 Win. Mag." and "7 mm Rem. Mag." are listed and the text reads "2 cartridges"
