# Spec Delta

## Purpose
The detail view presents every published value of one cartridge and its chamber in a precise, scannable form, at an address that can be bookmarked.

## ADDED Requirements

### Requirement: Detail header
The detail view SHALL show the cartridge name as heading, followed by alternative names, family, category, primer type, C.I.P. table, country, published and revised dates, pressure method and the published water capacity with a link to its source.

#### Scenario: 308 Win.
- **WHEN** the detail view of "308 Win." is opened
- **THEN** the alternative names "308 Winchester" and "7,62 x 51" are shown
- **AND** the water capacity "56 gr H2O" is shown with a link to its source URL

### Requirement: Value tables
All cartridge values and all chamber values SHALL be shown in tables grouped by section, with the columns "Symbol", "Value" and "Unit".

#### Scenario: Units and symbols
- **WHEN** the detail view of "308 Win." is opened
- **THEN** the cartridge table has a row "L3" with value "51.18" and unit "mm"
- **AND** a row "Pmax" with value "4150" and unit "bar", a row "α" with value "40°" and a row "L3 + G"

### Requirement: Tolerances
A field `<X>Tol` SHALL be shown next to the value of X and never as a row of its own.

#### Scenario: L1 tolerance
- **WHEN** the detail view of "308 Win." is opened
- **THEN** the value cell of L1 reads "39.62 -0.2" and no row "L1Tol" exists

### Requirement: Value formatting
Values SHALL be shown as published with a decimal point and no thousands separator. An angle SHALL be shown as `40°` when published in degrees or `39°59'49"` when published as degrees, minutes and seconds.

#### Scenario: Angle object
- **WHEN** the detail view of "338 Lapua Mag." is opened
- **THEN** α reads `39°59'49"`

### Requirement: Addressable views
Each detail view SHALL have its own address that survives a reload and works from `file://`. Navigation SHALL be possible with the browser's back button; the link "All cartridges" SHALL return to the list.

#### Scenario: Reload
- **WHEN** the detail view of "308 Win." is open and the page is reloaded
- **THEN** the detail view of "308 Win." is shown again

#### Scenario: Unknown address
- **WHEN** an address names a cartridge that does not exist
- **THEN** a "not found" message with a link to the list is shown
