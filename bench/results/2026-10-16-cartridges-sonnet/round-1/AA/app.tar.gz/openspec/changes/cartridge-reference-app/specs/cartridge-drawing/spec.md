# Spec Delta

## Purpose
A true-to-scale 2D drawing computed from the record lets the user see the shape and dimensions of the case, its chamber-side features and a seated bullet.

## ADDED Requirements

### Requirement: Scale and structure
The drawing SHALL be an inline SVG named "<name> drawing", in which one user unit is one millimetre, the axis is horizontal and the head is on the left. The upper half SHALL show the outside view, the lower half a section with hatched cut walls, and a dash-dot centre line SHALL mark the axis.

#### Scenario: Case length
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** the case outline spans 0 to 51.18 user units along the axis and half the P1 diameter radially

### Requirement: Dimensions
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α, each labelled with its symbol and value (e.g. `L3 51.18`). Labels SHALL NOT overlap each other or the outline.

#### Scenario: Labels
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** it contains the labels `L3 51.18`, `L6 71.12`, `R1 12.01`, `R 1.37`, `P1 11.96` and `α 40°`, and no two labels overlap

### Requirement: Title block
The drawing SHALL carry a title block with the name, C.I.P. table and revision date, the text "Dimensions in mm" and the scale.

#### Scenario: Title block
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** the title block reads "308 Win.", "C.I.P. table I", "Revised 2008-09-23", "Dimensions in mm" and "Scale ... (A4 print)"

### Requirement: Geometry rules
The outline SHALL be built from the published values: rim type (belted, rimfire, rimmed, rebated, rimless), head chamfer, extractor groove or belt, body, shoulder with rounded corners, neck, and a bullet of the default shape seated per the brief, with section walls and primer pocket.

#### Scenario: Belted case
- **WHEN** the drawing of "300 Win. Mag." is rendered
- **THEN** the outline contains the belt at radius R3/2 up to z = E

#### Scenario: Heeled rimfire
- **WHEN** the drawing of "22 Long Rifle" is rendered
- **THEN** the exposed bullet has the case's outside diameter

### Requirement: Missing values
If a value that a feature needs is missing, the drawing SHALL be drawn without that feature, and a visible note SHALL name the missing value. No number SHALL be invented.

#### Scenario: No shoulder
- **WHEN** the drawing of "9 mm Luger" is rendered
- **THEN** the case is straight and a note names α, L1, L2 as not published

### Requirement: Responsive drawing
The drawing SHALL scale to the width of the container, including a phone screen, with labels remaining legible.

#### Scenario: Phone
- **WHEN** the viewport is 360 px wide
- **THEN** the drawing is not wider than the viewport and the page does not scroll horizontally
