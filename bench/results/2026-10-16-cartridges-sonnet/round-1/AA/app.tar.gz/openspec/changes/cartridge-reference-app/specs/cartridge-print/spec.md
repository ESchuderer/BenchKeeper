# Spec Delta

## Purpose
A printed detail view is a self-contained A4 data sheet for the shop or workbench.

## ADDED Requirements

### Requirement: Print button
A "Print" button SHALL open the browser's print dialog.

#### Scenario: Click
- **WHEN** the user presses "Print" on a detail view
- **THEN** the browser print dialog opens

### Requirement: A4 sheet
A printed detail view SHALL be one A4 portrait page, black on white, with a page header with the name, the drawing at full width, the tables, no navigation, search or buttons, and a footer "C.I.P. TDCC" with the revised date.

#### Scenario: One page
- **WHEN** any of the 25 detail views is printed to PDF
- **THEN** the PDF has exactly one A4 portrait page and contains the name, the drawing labels and the footer
