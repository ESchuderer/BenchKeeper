## 1. Data and format
- [x] 1.1 Data file generated from JSONL, equality test (ticket 01)
- [x] 1.2 Formatting contract: numbers, angles, symbols, units, tolerances (ticket 02)

## 2. Catalog and detail UI
- [x] 2.1 Start page, search, family filter, count (ticket 03)
- [x] 2.2 Detail view, tables, routing (ticket 04)

## 3. Drawing
- [x] 3.1 Geometry: rim type, profile, walls, bullet, notes (ticket 05)
- [x] 3.2 Dimensions, labels, title block, SVG (ticket 06)

## 4. Print and polish
- [x] 4.1 Print stylesheet, one A4 page, button (ticket 07)
- [x] 4.2 Light/dark, phone layout, file:// and static server verification (ticket 08)
- [x] 4.3 Code review (Standards and Spec)
