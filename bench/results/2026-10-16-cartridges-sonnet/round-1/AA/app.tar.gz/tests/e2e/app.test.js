'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { withTargets, newPage, eventually } = require('./helpers.js');
const records = require('../../js/data.js');

const names = records.map((r) => r.name);

test('start page, search, family filter, detail view, reload, back (file:// and http)', async () => {
  await withTargets(async (browser, targets) => {
    for (const target of targets) {
      const { page, context, problems, requests } = await newPage(browser);
      const label = target.name + ': ';
      await page.goto(target.url);

      // heading, list, count
      await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridges', label + 'h1'));
      const links = page.locator('#cartridge-list tbody a');
      assert.equal(await links.count(), 25, label + 'links');
      assert.deepEqual(await links.allInnerTexts(), names, label + 'exact names');
      assert.ok(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).isVisible());
      assert.equal((await page.locator('#count').innerText()).trim(), '25 cartridges');
      const row308 = page.locator('#cartridge-list tbody tr', { hasText: '308 Win.' });
      assert.match(await row308.innerText(), /rimless/);
      assert.match(await row308.innerText(), /51\.18 mm/);

      // search
      await page.getByLabel('Search').fill('7,62 x 51');
      assert.deepEqual(await links.allInnerTexts(), ['308 Win.'], label + 'alt name search');
      assert.equal((await page.locator('#count').innerText()).trim(), '1 cartridges');
      await page.getByLabel('Search').fill('zzzz');
      assert.equal(await links.count(), 0);
      assert.equal((await page.locator('#count').innerText()).trim(), '0 cartridges');
      assert.ok(await page.locator('#empty').isVisible());
      await page.getByLabel('Search').fill('');

      // family
      const options = await page.getByLabel('Family').locator('option').allInnerTexts();
      assert.deepEqual(options, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
      await page.getByLabel('Family').selectOption('belted');
      assert.deepEqual(await links.allInnerTexts(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
      assert.equal((await page.locator('#count').innerText()).trim(), '2 cartridges');
      await page.getByLabel('Family').selectOption('All');
      assert.equal(await links.count(), 25);

      // detail
      await page.getByLabel('Search').fill('308');
      await page.getByRole('link', { name: '308 Win.', exact: true }).click();
      assert.match(page.url(), /#\/cartridge\/308_win$/, label + 'address');
      await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '308 Win.'));
      assert.ok(await page.getByRole('link', { name: 'All cartridges' }).isVisible());
      assert.ok(await page.getByRole('button', { name: 'Print' }).isVisible());
      assert.ok(!(await page.locator('#list-view').isVisible()));

      // reload survives
      await page.reload();
      await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '308 Win.', label + 'reload'));

      // back to list keeps the list usable
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridges'));
      await page.goBack();
      await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '308 Win.'));

      // unknown address
      await page.goto(target.url + '#/cartridge/nope');
      await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridge not found'));
      assert.ok(await page.getByRole('link', { name: 'All cartridges' }).isVisible());

      assert.deepEqual(problems, [], label + 'no console errors');
      const external = requests.filter((u) => !(u.startsWith('file://') || u.startsWith('http://127.0.0.1')));
      assert.deepEqual(external, [], label + 'no network requests outside the app');
      await context.close();
    }
  });
});

test('detail view: facts, tables, tolerances, formats', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context, problems } = await newPage(browser);
    await page.goto(targets[0].url + '#/cartridge/308_win');
    const facts = await page.locator('dl.facts').innerText();
    for (const s of ['Alternative names', '308 Winchester', '7,62 x 51', 'Family', 'rimless', 'Category', 'rifle',
      'Primer type', 'lr', 'C.I.P. table', 'Country', 'US', 'Published', '1984-06-14', 'Revised', '2008-09-23',
      'Pressure method', 'Transducer', 'Water capacity', '56 gr H2O']) {
      assert.ok(facts.includes(s), 'fact ' + s);
    }
    const link = page.locator('dl.facts a');
    assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
    assert.equal(await link.innerText(), 'kwk');

    const heads = await page.locator('table.values').first().locator('thead th').allInnerTexts();
    assert.deepEqual(heads.map((t) => t.toLowerCase()), ['symbol', 'value', 'unit']);
    const rowOf = (symbol, group) => page.locator('#h-' + group).locator('xpath=..').locator('tbody tr', { has: page.locator('th', { hasText: new RegExp('^' + symbol.replace(/[+.]/g, '\\$&') + '$') }) }).first();
    const cells = async (symbol, group) => (await rowOf(symbol, group).locator('th,td').allInnerTexts()).map((t) => t.trim());
    assert.deepEqual(await cells('L1', 'cartridge'), ['L1', '39.62 -0.2', 'mm']);
    assert.deepEqual(await cells('L3', 'cartridge'), ['L3', '51.18', 'mm']);
    assert.deepEqual(await cells('Pmax', 'cartridge'), ['Pmax', '4150', 'bar']);
    assert.deepEqual(await cells('EE', 'cartridge'), ['EE', '3920', 'J']);
    assert.deepEqual(await cells('M', 'cartridge'), ['M', '25', 'g']);
    assert.deepEqual(await cells('α', 'cartridge'), ['α', '40°', '']);
    assert.deepEqual(await cells('e min', 'cartridge'), ['e min', '1.4', 'mm']);
    assert.deepEqual(await cells('L3 + G', 'cartridge'), ['L3 + G', '58.16', 'mm']);
    assert.deepEqual(await cells('Q', 'chamber'), ['Q', '47.51', 'mm²']);
    assert.deepEqual(await cells('N', 'chamber'), ['N', '4', '']);
    assert.deepEqual(await cells('α1', 'chamber'), ['α1', '71°25\'59"', '']);
    assert.equal(await page.locator('table.values th', { hasText: /Tol$/ }).count(), 0, 'no Tol rows');
    assert.ok(await page.locator('h2', { hasText: 'Cartridge values' }).isVisible());
    assert.ok(await page.locator('h2', { hasText: 'Chamber values' }).isVisible());
    assert.ok(await page.locator('table.values caption', { hasText: 'Powder chamber' }).first().isVisible());

    await page.goto(targets[0].url + '#/cartridge/338_lapua_mag');
    assert.deepEqual(await cells('α', 'cartridge'), ['α', '39°59\'49"', '']);
    await page.goto(targets[0].url + '#/cartridge/6_5_creedmoor');
    await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '6,5 Creedmoor'));
    await page.goto(targets[0].url + '#/cartridge/7_x_64');
    assert.match(await page.locator('dl.facts').innerText(), /Water capacity\s*\n?\s*–/);
    assert.deepEqual(problems, []);
    await context.close();
  });
});

test('Print button opens the print dialog', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context } = await newPage(browser);
    await page.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed += 1; }; });
    await page.goto(targets[0].url + '#/cartridge/308_win');
    await page.getByRole('button', { name: 'Print' }).click();
    assert.equal(await page.evaluate(() => window.__printed), 1);
    await context.close();
  });
});

test('light and dark follow the system; print is always light', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context } = await newPage(browser);
    await page.goto(targets[0].url + '#/cartridge/308_win');
    const bg = () => page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    const lum = (rgb) => { const [r, g, b] = rgb.match(/\d+/g).map(Number); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
    await page.emulateMedia({ colorScheme: 'light' });
    assert.ok(lum(await bg()) > 200, 'light');
    await page.emulateMedia({ colorScheme: 'dark' });
    assert.ok(lum(await bg()) < 60, 'dark');
    await page.emulateMedia({ colorScheme: 'dark', media: 'print' });
    assert.ok(lum(await bg()) > 250, 'print is light even when the system is dark');
    await context.close();
  });
});

test('the count text is unambiguous; a malformed address is "not found"; Back restores the list scroll position', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context, problems } = await newPage(browser, { viewport: { width: 800, height: 400 } });
    await page.goto(targets[0].url);
    assert.equal(await page.getByText(/\d+ cartridges/).count(), 1, 'one element carries the count');

    await page.evaluate(() => window.scrollTo(0, 450));
    const before = await page.evaluate(() => window.scrollY);
    assert.ok(before > 300);
    await page.getByRole('link', { name: '30-06 Spring.' }).click();
    await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '30-06 Spring.'));
    await page.goBack();
    await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridges'));
    await eventually(async () => assert.equal(await page.evaluate(() => window.scrollY), before));

    await page.goto(targets[0].url + '#/cartridge/%E0%A4%A');
    await eventually(async () => assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridge not found'));
    assert.deepEqual(problems, []);
    await context.close();
  });
});
