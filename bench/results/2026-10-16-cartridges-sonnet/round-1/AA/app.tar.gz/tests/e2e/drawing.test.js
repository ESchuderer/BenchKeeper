'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { withTargets, newPage } = require('./helpers.js');
const records = require('../../js/data.js');

// In the browser, with real fonts: label boxes against each other and against the sampled outline geometry.
async function measure(page) {
  return page.evaluate(() => {
    const svg = document.querySelector('svg.cartridge-drawing');
    const boxes = [...svg.querySelectorAll('text.dim-label')].map((t) => {
      const b = t.getBBox();
      return { text: t.textContent, left: b.x, top: b.y, right: b.x + b.width, bottom: b.y + b.height };
    });
    const vb = svg.viewBox.baseVal;
    const outlinePoints = [];
    svg.querySelectorAll('path.outline[data-part], path.cut').forEach((p) => {
      const len = p.getTotalLength();
      for (let d = 0; d <= len; d += 0.15) { const q = p.getPointAtLength(d); outlinePoints.push([q.x, q.y]); }
    });
    const rect = svg.getBoundingClientRect();
    return {
      boxes, outlinePoints, viewBox: [vb.x, vb.y, vb.width, vb.height],
      pxPerUnit: rect.width / vb.width, width: rect.width,
      fontSize: parseFloat(getComputedStyle(svg.querySelector('text.dim-label')).fontSize),
    };
  });
}

function problemsOf(m) {
  const out = [];
  m.boxes.forEach((a, i) => {
    for (let j = i + 1; j < m.boxes.length; j++) {
      const b = m.boxes[j];
      if (a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom) out.push('overlap ' + a.text + ' / ' + b.text);
    }
    for (const [x, y] of m.outlinePoints) {
      if (x > a.left && x < a.right && y > a.top && y < a.bottom) { out.push('outline in ' + a.text); break; }
    }
    if (a.left < m.viewBox[0] || a.right > m.viewBox[0] + m.viewBox[2] || a.top < m.viewBox[1] || a.bottom > m.viewBox[1] + m.viewBox[3]) out.push('outside view box ' + a.text);
  });
  return out;
}

test('every drawing: accessible name, required labels, no overlaps with real text boxes', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context, problems } = await newPage(browser);
    await page.goto(targets[0].url);
    for (const r of records) {
      await page.evaluate((k) => { location.hash = '#/cartridge/' + k; }, r.key);
      const img = page.getByRole('img', { name: r.name + ' drawing', exact: true });
      await img.waitFor();
      const texts = await page.locator('svg.cartridge-drawing text').allTextContents();
      const l = r.cartridge.lengths;
      for (const s of ['L3 ' + l.L3, 'L6 ' + l.L6, 'R1 ' + r.cartridge.caseHead.R1, 'R ' + r.cartridge.caseHead.R, 'P1 ' + r.cartridge.powderChamber.P1,
        r.name, 'Dimensions in mm']) assert.ok(texts.includes(s), r.name + ': ' + s);
      assert.ok(texts.some((t) => /^C\.I\.P\. table /.test(t)) && texts.some((t) => t === 'Revised ' + r.revised) && texts.some((t) => /^Scale /.test(t)), r.name + ' title block');
      assert.deepEqual(problemsOf(await measure(page)), [], r.name);
      assert.ok(await page.locator('svg.cartridge-drawing marker').count() >= 1);
      assert.ok(await page.locator('svg.cartridge-drawing line.ext').count() >= 5, r.name + ' extension lines');
    }
    assert.deepEqual(problems, []);
    await context.close();
  });
});

test('true to scale: 1 user unit = 1 mm (case outline spans L3 and P1/2 in user units)', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context } = await newPage(browser);
    await page.goto(targets[0].url + '#/cartridge/308_win');
    const box = await page.evaluate(() => {
      const b = document.querySelector('path[data-part="case-upper"]').getBBox();
      const bu = document.querySelector('path[data-part="bullet-upper"]').getBBox();
      const svg = document.querySelector('svg.cartridge-drawing');
      return { x: b.x, y: b.y, w: b.width, h: b.height, bulletEnd: bu.x + bu.width, widthAttr: svg.getAttribute('width') };
    });
    assert.ok(Math.abs(box.x - 0) < 1e-6 && Math.abs(box.w - 51.18) < 0.01, 'case spans L3: ' + JSON.stringify(box));
    assert.ok(Math.abs(box.h - 12.01 / 2) < 0.01, 'half the rim diameter: ' + box.h);
    assert.ok(Math.abs(box.bulletEnd - 71.12) < 0.01, 'bullet tip at L6');
    assert.match(box.widthAttr, /mm$/);
    await context.close();
  });
});

test('shows which values are missing instead of inventing them', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context } = await newPage(browser);
    await page.goto(targets[0].url + '#/cartridge/9_mm_luger');
    const notes = await page.locator('.drawing-notes').innerText();
    assert.match(notes, /α, L1, L2/);
    await page.goto(targets[0].url + '#/cartridge/9_3_x_74_r');
    assert.match(await page.locator('.drawing-notes').innerText(), /groove[^\n]*E, E1, e min/);
    await page.goto(targets[0].url + '#/cartridge/338_lapua_mag');
    assert.match(await page.locator('.drawing-notes').innerText(), /r1 min/);
    await page.goto(targets[0].url + '#/cartridge/308_win');
    assert.equal(await page.locator('.drawing-notes').count(), 0);
    await context.close();
  });
});

test('phone: no horizontal scroll, legible labels', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context } = await newPage(browser, { viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await page.goto(targets[0].url);
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true, 'list fits');
    for (const r of records) {
      await page.evaluate((k) => { location.hash = '#/cartridge/' + k; }, r.key);
      await page.getByRole('img', { name: r.name + ' drawing', exact: true }).waitFor();
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true, r.name + ' fits at 360px');
      const m = await measure(page);
      assert.ok(m.width <= 360, r.name + ' drawing width ' + m.width);
      const labelPx = m.fontSize * m.pxPerUnit;
      assert.ok(labelPx >= 8, r.name + ' label ' + labelPx.toFixed(1) + 'px on a phone');
    }
    await context.close();
  });
});

test('print: one A4 portrait page for every cartridge, no navigation, header, drawing at full width, footer', async () => {
  await withTargets(async (browser, targets) => {
    const { page, context } = await newPage(browser);
    await page.goto(targets[0].url);
    for (const r of records) {
      await page.evaluate((k) => { location.hash = '#/cartridge/' + k; }, r.key);
      await page.getByRole('img', { name: r.name + ' drawing', exact: true }).waitFor();
      await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
      const pdf = await page.pdf({ preferCSSPageSize: true });
      const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
      assert.equal(pages, 1, r.name + ' prints on ' + pages + ' pages');
      const mediaBox = /\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/.exec(pdf.toString('latin1'));
      assert.ok(mediaBox && Math.abs(Number(mediaBox[1]) - 595.28) < 1 && Math.abs(Number(mediaBox[2]) - 841.89) < 1, r.name + ' A4 portrait ' + (mediaBox && mediaBox.slice(1, 3)));

      // layout in print emulation at the printable width (190 mm = 718 px)
      await page.setViewportSize({ width: 718, height: 1000 });
      const info = await page.evaluate(() => {
        const vis = (sel) => { const e = document.querySelector(sel); return !!e && getComputedStyle(e).display !== 'none' && e.offsetParent !== null || (e && getComputedStyle(e).position === 'fixed'); };
        const svg = document.querySelector('svg.cartridge-drawing').getBoundingClientRect();
        const vb = document.querySelector('svg.cartridge-drawing').viewBox.baseVal;
        const label = document.querySelector('text.dim-label');
        return {
          nav: vis('.site-header') || vis('.detail-nav') || vis('#print') || vis('.filters') || vis('.site-footer'),
          header: document.querySelector('.print-header') && getComputedStyle(document.querySelector('.print-header')).display !== 'none',
          footer: document.querySelector('.print-footer').textContent,
          svgWidth: svg.width, labelPx: parseFloat(getComputedStyle(label).fontSize) * svg.width / vb.width,
          bg: getComputedStyle(document.body).backgroundColor, ink: getComputedStyle(document.body).color,
        };
      });
      assert.equal(info.nav, false, r.name + ' no navigation in print');
      assert.ok(info.header, r.name + ' header');
      assert.equal(info.footer, 'Source: C.I.P. TDCC, revised ' + r.revised);
      assert.ok(info.svgWidth >= 700 && info.svgWidth <= 719, r.name + ' drawing is full width: ' + info.svgWidth);
      assert.ok(info.labelPx >= 9, r.name + ' printed label size ' + info.labelPx);
      assert.equal(info.bg, 'rgb(255, 255, 255)');
      assert.equal(info.ink, 'rgb(0, 0, 0)');
      await page.setViewportSize({ width: 1280, height: 720 });
      await page.emulateMedia({ media: 'screen', colorScheme: 'light' });
    }
    await context.close();
  });
});
