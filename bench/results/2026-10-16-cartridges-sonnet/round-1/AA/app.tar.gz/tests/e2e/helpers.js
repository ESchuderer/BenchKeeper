'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');

const root = path.join(__dirname, '..', '..');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };

function serve() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      const p = decodeURIComponent(req.url.split('?')[0]);
      const file = path.join(root, p.endsWith('/') ? p + 'index.html' : p);
      if (!file.startsWith(root)) { res.writeHead(403); res.end(); return; }
      fs.readFile(file, (err, data) => {
        if (err) { res.writeHead(404); res.end('not found'); return; }
        res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream' });
        res.end(data);
      });
    });
    server.listen(0, '127.0.0.1', () => resolve({ server, url: 'http://127.0.0.1:' + server.address().port + '/index.html' }));
  });
}

// Runs fn(target) once for file:// and once for a static file server.
async function withTargets(fn) {
  const browser = await chromium.launch();
  const { server, url } = await serve();
  try {
    await fn(browser, [
      { name: 'file://', url: pathToFileURL(path.join(root, 'index.html')).href },
      { name: 'http', url },
    ]);
  } finally {
    await browser.close();
    server.close();
  }
}

async function newPage(browser, options) {
  const context = await browser.newContext(options || {});
  const page = await context.newPage();
  const problems = [];
  const requests = [];
  page.on('pageerror', (e) => problems.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') problems.push('console: ' + m.text()); });
  page.on('request', (r) => requests.push(r.url()));
  page.on('requestfailed', (r) => problems.push('requestfailed: ' + r.url()));
  return { page, context, problems, requests };
}

// Polls until fn() returns without throwing (hash routing and filtering are synchronous, but events are queued).
async function eventually(fn, timeout) {
  const end = Date.now() + (timeout || 3000);
  for (;;) {
    try { return await fn(); } catch (e) { if (Date.now() > end) throw e; await new Promise((r) => setTimeout(r, 50)); }
  }
}

module.exports = { withTargets, newPage, eventually, root };
