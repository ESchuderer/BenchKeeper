'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../../js/catalog.js');
const records = require('../../js/data.js');

const names = (list) => list.map((r) => r.name);

test('empty search and family All lists all 25', () => {
  assert.equal(C.filter(records, { query: '', family: 'all' }).length, 25);
});

test('an alternative name finds its cartridge', () => {
  assert.deepEqual(names(C.filter(records, { query: '7,62 x 51', family: 'all' })), ['308 Win.']);
  assert.deepEqual(names(C.filter(records, { query: '30-06', family: 'all' })), ['30-06 Spring.']);
  assert.deepEqual(names(C.filter(records, { query: '22 lang für Büchsen', family: 'all' })), ['22 Long Rifle']);
});

test('search is case-insensitive, ignores spacing, and finds substrings of the name', () => {
  assert.deepEqual(names(C.filter(records, { query: 'CREEDMOOR', family: 'all' })), ['6,5 Creedmoor']);
  assert.deepEqual(names(C.filter(records, { query: '7,62x51', family: 'all' })), ['308 Win.']);
  assert.deepEqual(names(C.filter(records, { query: '  lapua ', family: 'all' })), ['338 Lapua Mag.']);
});

test('a decimal point finds a decimal comma and the other way round', () => {
  assert.deepEqual(names(C.filter(records, { query: '6.5 creed', family: 'all' })), ['6,5 Creedmoor']);
});

test('diacritics are folded', () => {
  assert.deepEqual(names(C.filter(records, { query: 'buchsen', family: 'all' })), ['22 Long Rifle']);
});

test('family filter and search combine', () => {
  assert.deepEqual(names(C.filter(records, { query: '', family: 'belted' })), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(C.filter(records, { query: '', family: 'pistol' }).length, 6);
  assert.equal(C.filter(records, { query: '', family: 'rimfire' }).length, 3);
  assert.equal(C.filter(records, { query: '', family: 'rimmed' }).length, 2);
  assert.equal(C.filter(records, { query: '', family: 'rimless' }).length, 12);
  assert.deepEqual(names(C.filter(records, { query: '22', family: 'pistol' })), []);
});

test('nothing matches nonsense', () => {
  assert.deepEqual(C.filter(records, { query: 'zzz', family: 'all' }), []);
});

// The brief prescribes the text "<n> cartridges"; it is deliberately not pluralised.
test('count text is "<n> cartridges"', () => {
  assert.equal(C.countText(25), '25 cartridges');
  assert.equal(C.countText(1), '1 cartridges');
  assert.equal(C.countText(0), '0 cartridges');
});

test('families offered are All plus the five families', () => {
  assert.deepEqual(C.FAMILIES, ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});
