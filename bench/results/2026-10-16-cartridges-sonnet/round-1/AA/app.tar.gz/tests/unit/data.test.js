'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const records = require('../../js/data.js');

const lines = fs.readFileSync(path.join(__dirname, '..', '..', 'data', 'cartridges.jsonl'), 'utf8').split('\n').filter(Boolean);

test('the app data is the 25 published records, unchanged and in order', () => {
  assert.equal(lines.length, 25);
  assert.deepEqual(records, lines.map((l) => JSON.parse(l)));
});

test('records are unique and complete enough to list', () => {
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
  for (const r of records) {
    assert.ok(r.name && r.family && r.key && r.tab && r.revised && r.published && r.country, r.key);
    assert.ok(typeof r.cartridge.lengths.L3 === 'number', r.key + ' L3');
  }
});

test('the app has no network references: no http(s) URLs in app code, markup or styles', () => {
  const root = path.join(__dirname, '..', '..');
  for (const f of ['index.html', 'css/style.css', 'js/app.js', 'js/format.js', 'js/catalog.js', 'js/geometry.js', 'js/drawing.js']) {
    const text = fs.readFileSync(path.join(root, f), 'utf8');
    const urls = (text.match(/https?:\/\/[^\s"')]+/g) || []).filter((u) => u !== 'http://www.w3.org/2000/svg');
    assert.deepEqual(urls, [], f);
  }
});
