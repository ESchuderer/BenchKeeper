'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../../js/drawing.js');
const records = require('../../js/data.js');
const byKey = (k) => records.find((r) => r.key === k);
const draw = (k) => D.buildDrawing(byKey(k));
const texts = (d) => d.labels.map((l) => l.text);

test('308 Win.: the required labels are present with symbol and value', () => {
  const t = texts(draw('308_win'));
  for (const expected of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72',
    'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(t.includes(expected), expected + ' in ' + t.join(' | '));
  }
});

test('labels are only produced for published values', () => {
  const t = texts(draw('9_mm_luger'));
  assert.ok(t.includes('L3 19.15') && t.includes('L6 29.69') && t.includes('R1 9.96') && t.includes('R 1.27') && t.includes('P1 9.93'));
  assert.ok(t.includes('H2 9.65') && t.includes('G1 9.03') && t.includes('E1 8.79'));
  assert.ok(!t.some((x) => /^(P2|H1|L1|L2|α) /.test(x)), t.join('|'));
  const rf = texts(draw('22_long_rifle'));
  assert.ok(!rf.some((x) => /^E1 /.test(x)));
});

test('an angle published as degrees, minutes, seconds is labelled as such', () => {
  assert.ok(texts(draw('338_lapua_mag')).includes('α 39°59\'49"'));
});

test('every record: all labels exist for the required dimensions', () => {
  for (const r of records) {
    const t = texts(D.buildDrawing(r));
    const l = r.cartridge.lengths, ch = r.cartridge.caseHead, pc = r.cartridge.powderChamber;
    for (const s of ['L3 ' + l.L3, 'L6 ' + l.L6, 'R1 ' + ch.R1, 'R ' + ch.R, 'P1 ' + pc.P1]) assert.ok(t.includes(s), r.name + ' ' + s);
  }
});

test('labels do not overlap each other, the outline, or each other\'s dimension lines (all 25)', () => {
  for (const r of records) {
    const d = D.buildDrawing(r);
    const problems = D.checkLayout(d);
    assert.deepEqual(problems, [], r.name);
  }
});

test('true to scale: view box is in mm and contains the case, the bullet and the labels', () => {
  const d = draw('308_win');
  const [x, y, w, h] = d.viewBox;
  assert.ok(x <= 0 && x + w >= 71.12, 'axis extent');
  assert.ok(y < -6.005 && y + h > 6.005, 'radial extent');
  for (const l of d.labels) {
    assert.ok(l.left >= x - 1e-6 && l.right <= x + w + 1e-6 && l.top >= y - 1e-6 && l.bottom <= y + h + 1e-6, l.text);
  }
  assert.match(d.svg, /viewBox="[-\d. ]+"/);
});

test('svg: accessible name, one unit = one mm, hatch, centre line, arrowheads, extension lines', () => {
  const d = draw('308_win');
  assert.match(d.svg, /^<svg [^>]*role="img"/);
  assert.match(d.svg, /aria-label="308 Win\. drawing"/);
  assert.match(d.svg, /<pattern /);
  assert.match(d.svg, /class="centre"/);
  assert.match(d.svg, /<marker /);
  assert.match(d.svg, /marker-end="url\(#cip-arrow\)"/);
  assert.match(d.svg, /class="ext"/);
  assert.ok((d.svg.match(/class="outline"/g) || []).length >= 2);
  // the case outline spans exactly L3 along the axis in user units (= mm) on screen x
  const m = d.svg.match(/<path class="outline" data-part="case-upper" d="([^"]+)"/);
  assert.ok(m);
  const xs = [...m[1].matchAll(/([-\d.]+) ([-\d.]+)/g)].map((q) => Number(q[1]));
  assert.equal(Math.min(...xs), 0);
});

test('title block: name, table, revision date, Dimensions in mm, scale', () => {
  const d = draw('308_win');
  assert.match(d.svg, />308 Win\.</);
  assert.match(d.svg, />C\.I\.P\. table I</);
  assert.match(d.svg, />Revised 2008-09-23</);
  assert.match(d.svg, />Dimensions in mm</);
  assert.match(d.svg, />Scale [\d.]+ ?: ?1 \(A4 print\)</);
  const scale = Number(d.svg.match(/Scale ([\d.]+)/)[1]);
  assert.ok(Math.abs(scale - 190 / d.viewBox[2]) < 0.06, 'scale ' + scale + ' vs ' + 190 / d.viewBox[2]);
});

test('drawing notes are passed through and name the missing values', () => {
  assert.ok(draw('9_mm_luger').notes.some((n) => /α, L1, L2/.test(n)));
  assert.deepEqual(draw('308_win').notes, []);
});

test('svg text is escaped', () => {
  const rec = JSON.parse(JSON.stringify(byKey('308_win')));
  rec.name = '308 <Win> & "x"';
  const d = D.buildDrawing(rec);
  assert.ok(!d.svg.includes('<Win>'));
  assert.match(d.svg, /308 &lt;Win&gt; &amp; &quot;x&quot; drawing/);
});

test('belted and rimfire records render', () => {
  for (const k of ['300_win_mag', '7_mm_rem_mag', '22_long_rifle', '22_win_mag_r_f', '17_hmr']) {
    const d = draw(k);
    assert.ok(d.ok && d.svg.length > 500, k);
  }
});
