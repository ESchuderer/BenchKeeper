'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../../js/format.js');
const records = require('../../js/data.js');
const byKey = (k) => records.find((r) => r.key === k);

const row = (model, group, symbol) => {
  const hits = model.sections.filter((s) => s.group === group).flatMap((s) => s.rows).filter((r) => r.symbol === symbol);
  return hits[0];
};

test('numbers are shown as published: decimal point, no thousands separator, no trailing .0', () => {
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(9.0), '9');
  assert.equal(F.formatNumber(0.08), '0.08');
});

test('angles: degrees, or degrees minutes seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(0), '0°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'0"');
});

test('symbols follow the brief', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax', G1: 'G1', Fe: 'Fe',
  };
  for (const [field, symbol] of Object.entries(expected)) assert.equal(F.symbolFor(field), symbol, field);
});

test('units: mm default, bar, J, g, mm², none for N, angles carry the degree sign in the value', () => {
  assert.equal(F.unitFor('L3'), 'mm');
  assert.equal(F.unitFor('P1'), 'mm');
  for (const f of ['Pmax', 'PK', 'PE']) assert.equal(F.unitFor(f), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('N'), '');
  for (const f of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unitFor(f), '', f);
});

test('detail model: 308 Win. tolerance sits next to its value and never as its own row', () => {
  const m = F.detailModel(byKey('308_win'));
  assert.equal(row(m, 'cartridge', 'L1').value, '39.62 -0.2');
  assert.equal(row(m, 'cartridge', 'L3').value, '51.18');
  assert.equal(row(m, 'cartridge', 'L3').unit, 'mm');
  assert.equal(row(m, 'cartridge', 'P2').value, '11.53 -0.2');
  const symbols = m.sections.flatMap((s) => s.rows.map((r) => r.symbol));
  assert.ok(!symbols.some((s) => /Tol$/.test(s)), 'no Tol rows');
});

test('detail model: values for 308 Win.', () => {
  const m = F.detailModel(byKey('308_win'));
  assert.equal(row(m, 'cartridge', 'Pmax').value, '4150');
  assert.equal(row(m, 'cartridge', 'Pmax').unit, 'bar');
  assert.equal(row(m, 'cartridge', 'EE').unit, 'J');
  assert.equal(row(m, 'cartridge', 'α').value, '40°');
  assert.equal(row(m, 'cartridge', 'e min').value, '1.4');
  assert.equal(row(m, 'cartridge', 'L3 + G').value, '58.16');
  assert.equal(row(m, 'chamber', 'r1 max').value, '0.76');
  assert.equal(row(m, 'chamber', 'α1').value, '71°25\'59"');
  assert.equal(row(m, 'chamber', 'i').value, '1°45\'0"');
  assert.equal(row(m, 'chamber', 'N').unit, '');
  assert.equal(row(m, 'chamber', 'Q').unit, 'mm²');
});

test('detail model: an angle published as an object is shown in degrees, minutes, seconds', () => {
  const m = F.detailModel(byKey('338_lapua_mag'));
  assert.equal(row(m, 'cartridge', 'α').value, '39°59\'49"');
});

test('detail model: tolerance on E, R keep their sign', () => {
  assert.equal(row(F.detailModel(byKey('300_win_mag')), 'cartridge', 'E').value, '5.59 -0.2');
  assert.equal(row(F.detailModel(byKey('38_special')), 'cartridge', 'R').value, '1.5 -0.25');
});

test('detail model: every published value appears exactly once (nothing lost, nothing added)', () => {
  for (const r of records) {
    const m = F.detailModel(r);
    for (const group of ['cartridge', 'chamber']) {
      const expected = Object.values(r[group]).reduce((n, sec) => n + Object.keys(sec).filter((k) => !/Tol$/.test(k)).length, 0);
      const actual = m.sections.filter((s) => s.group === group).reduce((n, s) => n + s.rows.length, 0);
      assert.equal(actual, expected, r.name + ' ' + group);
    }
  }
});

test('detail model: empty sections are skipped; section titles are readable', () => {
  const m = F.detailModel(byKey('9_mm_luger'));
  assert.ok(!m.sections.some((s) => s.rows.length === 0));
  assert.ok(m.sections.some((s) => s.group === 'cartridge' && s.title === 'Case head'));
  assert.ok(m.sections.some((s) => s.group === 'chamber' && s.title === 'Powder chamber'));
});

test('facts: header facts in the order of the brief, missing ones omitted values shown as a dash', () => {
  const m = F.detailModel(byKey('308_win'));
  assert.deepEqual(m.facts.map((f) => f.label), [
    'Alternative names', 'Family', 'Category', 'Primer type', 'C.I.P. table', 'Country',
    'Published', 'Revised', 'Pressure method', 'Water capacity']);
  const get = (l) => m.facts.find((f) => f.label === l);
  assert.equal(get('Alternative names').value, '308 Winchester; 7,62 x 51');
  assert.equal(get('Family').value, 'rimless');
  assert.equal(get('Primer type').value, 'lr');
  assert.equal(get('C.I.P. table').value, 'I');
  assert.equal(get('Published').value, '1984-06-14');
  assert.equal(get('Revised').value, '2008-09-23');
  assert.equal(get('Water capacity').value, '56 gr H2O');
  assert.equal(get('Water capacity').link.url, 'http://kwk.us/cases.html');
  assert.equal(get('Water capacity').link.text, 'kwk');
  assert.equal(get('Water capacity').note, 'Lapua brass measures 55.8 (lapua-308)');
  const m2 = F.detailModel(byKey('223_rem'));
  assert.equal(m2.facts.find((f) => f.label === 'Alternative names').value, '–');
  const m3 = F.detailModel(byKey('7_x_64'));
  assert.equal(m3.facts.find((f) => f.label === 'Water capacity').value, '–');
});

test('list row: name, family and case length', () => {
  assert.deepEqual(F.listRow(byKey('308_win')), { key: '308_win', name: '308 Win.', family: 'rimless', l3: '51.18 mm' });
});
