'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const records = require('../../js/data.js');
const byKey = (k) => records.find((r) => r.key === k);
const geo = (k) => G.buildGeometry(byKey(k));

const near = (actual, expected, tol, msg) =>
  assert.ok(Math.abs(actual - expected) <= (tol === undefined ? 0.005 : tol), (msg || '') + ' expected ' + expected + ' got ' + actual);
const pt = (g, tag) => g.points.find((p) => p.tag === tag);

test('rim type (rule 1)', () => {
  const expected = {
    '308_win': 'rimless', '300_win_mag': 'belted', '7_mm_rem_mag': 'belted', '22_long_rifle': 'rimfire',
    '17_hmr': 'rimfire', '9_3_x_74_r': 'rimmed', '7_x_65_r': 'rimmed', '38_special': 'rimmed',
    '357_magnum': 'rimmed', '44_rem_mag': 'rimmed', '45_auto': 'rimless', '9_3_x_62': 'rimless',
  };
  for (const [k, v] of Object.entries(expected)) assert.equal(geo(k).rimType, v, k);
  // R1/P1 thresholds
  const mk = (r1, p1) => G.classifyRim({ family: 'rimless', cartridge: { caseHead: { R1: r1 }, powderChamber: { P1: p1 } } });
  assert.equal(mk(10.5, 10), 'rimmed');
  assert.equal(mk(10.49, 10), 'rimless');
  assert.equal(mk(9.8, 10), 'rimless');
  assert.equal(mk(9.79, 10), 'rebated');
});

test('308 Win.: head, chamfer, groove, body, shoulder, neck (rules 2-6)', () => {
  const g = geo('308_win');
  const p = g.points.map((q) => [q.r, q.z]);
  const expected = [
    [0, 0], [5.7389, 0], [6.005, 0.38], [6.005, 1.37], [5.195, 1.37], [5.195, 2.77], [5.98, 3.85],
    [5.765, 39.62], [4.36, 43.48], [4.36, 51.18],
  ];
  assert.equal(p.length, expected.length, JSON.stringify(p));
  expected.forEach((e, i) => { near(p[i][0], e[0], 0.001, 'r' + i); near(p[i][1], e[1], 0.001, 'z' + i); });
  assert.equal(g.straight, false);
  assert.equal(g.heeled, false);
});

test('chamfer is limited to R1/4', () => {
  const rec = JSON.parse(JSON.stringify(byKey('308_win')));
  rec.cartridge.caseHead.f = 20; // f·tanβ would exceed R1/4
  const g = G.buildGeometry(rec);
  near(g.points[1].r, 6.005 - 12.01 / 4, 0.001);
});

test('308 Win.: walls, head thickness and primer pocket (rule 8)', () => {
  const g = geo('308_win');
  near(g.walls.tn, 0.435, 0.0005);
  near(g.walls.tb, 0.6, 0.0005);
  assert.deepEqual(g.pocket, { diameter: 5.33, depth: 3.3 });
  near(g.w, 4.8, 0.0005);
});

test('308 Win.: pointy bullet (rule 7)', () => {
  const b = geo('308_win').bullet;
  assert.equal(b.shape, 'pointy');
  near(b.s, 7.85, 0.0005);
  near(b.zb, 43.33, 0.0005);
  near(b.length, 27.79, 0.0005);
  near(b.cylinderEnd, 54.446, 0.001);
  near(b.meplat, 1.27, 0.0005);
  near(b.ogiveRadius, 43.8977, 0.01);
  near(b.exposedRadius, 3.925, 0.0005);
  near(b.seatedRadius, 3.925, 0.0005);
});

test('bullet meplat for small calibres uses 0.08·G1 only when larger than 1.27', () => {
  // 0.08 * G1 > 1.27 needs G1 > 15.9, so with the data it is always 1.27
  for (const r of records.filter((x) => x.annotations.defaultBulletShape === 'pointy')) {
    near(G.buildGeometry(r).bullet.meplat, 1.27, 0.0005, r.name);
  }
});

test('bullet shapes, seating depth and cylinder fraction by category', () => {
  const luger = geo('9_mm_luger').bullet; // rounded, pistol
  assert.equal(luger.shape, 'rounded');
  near(luger.s, 0.4 * 9.03, 0.0005);
  near(luger.zb, 19.15 - 0.4 * 9.03, 0.0005);
  near(luger.cylinderEnd, luger.zb + 0.65 * (29.69 - luger.zb), 0.001);
  near(luger.meplat, 0.15 * 9.03, 0.0005);

  const smith = geo('40_s_w').bullet; // flat, pistol
  near(smith.s, 0.4 * 10.17, 0.0005);
  near(smith.cylinderEnd, smith.zb + 0.7 * (28.83 - smith.zb), 0.001);
  near(smith.meplat, 0.55 * 10.17, 0.0005);

  const mag = geo('357_magnum').bullet; // semi_wadcutter, pistol
  near(mag.s, 0.6 * 9.12, 0.0005);
  near(mag.cylinderEnd, mag.zb + 0.78 * (40.39 - mag.zb), 0.001);
  near(mag.meplat, 0.6 * 9.12, 0.0005);

  const wmr = geo('22_win_mag_r_f').bullet; // rounded, rimfire counts as rifle
  near(wmr.s, 0.8 * 5.7, 0.0005);
  near(wmr.cylinderEnd, wmr.zb + 0.55 * (34.29 - wmr.zb), 0.001);

  const hmr = geo('17_hmr').bullet; // pointy
  near(hmr.s, 4.38, 0.0005);
  near(hmr.cylinderEnd, hmr.zb + 0.4 * (34.67 - hmr.zb), 0.001);
});

test('heeled case: 22 Long Rifle (rules 7, 8)', () => {
  const g = geo('22_long_rifle');
  assert.equal(g.heeled, true);
  assert.equal(g.straight, true);
  near(g.bullet.exposedRadius, 2.86, 0.0005);
  near(g.bullet.seatedRadius, (5.72 - 2 * 0.6) / 2, 0.0005);
  assert.equal(g.pocket, null);
  near(g.walls.tb, 0.6, 0.0005);
});

test('rimfire rim edge is a half-round whose outermost point lies at R1/2', () => {
  const g = geo('22_long_rifle');
  const arcs = g.path.filter((s) => s.cmd === 'A');
  assert.ok(arcs.length >= 1);
  const rho = 0.545; // min(R/2 = 0.545, (R1 - P1)/2 = 0.66)
  const outer = Math.max(...g.points.map((p) => p.r), ...arcs.map((a) => a.cr + a.rr));
  near(outer, 7.06 / 2, 0.001);
  const apex = g.points.find((p) => p.tag === 'rimApex');
  near(apex.r, 3.53, 0.001);
  near(apex.z, 1.09 / 2, 0.001);
  near(arcs[0].rr, rho, 0.001);
});

test('belted case: ramp at delta up to the belt, belt to E, step in to P1/2 (rule 3)', () => {
  const g = geo('300_win_mag');
  const p = g.points.map((q) => [q.r, q.z]);
  near(p[1][0], 6.46791, 0.0005); // 6.755 - 0.41 * tan 35°
  const floorEnd = pt(g, 'grooveFloorEnd');
  near(floorEnd.r, 6.035, 0.001); near(floorEnd.z, 2.21, 0.001);
  const rampEnd = pt(g, 'beltRampEnd');
  near(rampEnd.r, 6.755, 0.001);
  near(rampEnd.z, 3.23826, 0.0005); // 2.21 + 0.72 / tan 35°
  const beltEnd = pt(g, 'beltEnd');
  near(beltEnd.r, 6.755, 0.001); near(beltEnd.z, 5.59, 0.001);
  const bodyStart = pt(g, 'bodyStart');
  near(bodyStart.r, 6.515, 0.001); near(bodyStart.z, 5.59, 0.001);
  near(g.w, 4.8, 0.0005); // pocket depth 3.3 + 1.5 beats ramp end + tb
});

test('rimmed case without groove: step in from the rim to P1/2 at z = R', () => {
  const g = geo('9_3_x_74_r');
  const p = g.points.map((q) => [q.r, q.z]);
  near(p[1][0], 6.675 - 0.3, 0.001);
  near(p[2][0], 6.675, 0.001); near(p[2][1], 0.3, 0.001);
  near(p[3][0], 6.675, 0.001); near(p[3][1], 1.4, 0.001);
  near(p[4][0], 5.95, 0.001); near(p[4][1], 1.4, 0.001);
  assert.ok(g.notes.some((n) => /groove/i.test(n) && /E1/.test(n)), JSON.stringify(g.notes));
});

test('straight case runs to (H2/2, L3); a note names the unpublished values', () => {
  const g = geo('9_mm_luger');
  assert.equal(g.straight, true);
  const last = g.points[g.points.length - 1];
  near(last.r, 4.825, 0.001); near(last.z, 19.15, 0.001);
  assert.ok(g.notes.some((n) => /shoulder/i.test(n) && /α/.test(n) && /L1/.test(n) && /L2/.test(n)), JSON.stringify(g.notes));
  near(g.w, 4.54, 0.0005);
  assert.deepEqual(g.pocket, { diameter: 4.45, depth: 3.04 });
});

test('primer pockets by primer type (rule 8)', () => {
  const pocket = (type) => {
    const rec = JSON.parse(JSON.stringify(byKey('308_win')));
    rec.annotations.primerType = type;
    return G.buildGeometry(rec).pocket;
  };
  for (const t of ['sp', 'spm', 'sr']) assert.equal(pocket(t).diameter, 4.45, t);
  for (const t of ['lp', 'lpm', 'lr', 'lrm']) assert.equal(pocket(t).diameter, 5.33, t);
  for (const t of ['sp', 'spm', 'sr', 'lp', 'lpm']) assert.equal(pocket(t).depth, 3.04, t);
  for (const t of ['lr', 'lrm']) assert.equal(pocket(t).depth, 3.3, t);
});

test('shoulder is drawn through the published points and its corners are rounded with r1 min and r2', () => {
  const g = geo('308_win');
  const arcs = g.path.filter((s) => s.cmd === 'A');
  const radii = arcs.map((a) => a.rr).sort();
  assert.deepEqual(radii, [0.76, 3.18]);
  const s = g.shoulder;
  near(s.start.r, 5.765, 0.001); near(s.start.z, 39.62, 0.001);
  near(s.end.r, 4.36, 0.001); near(s.end.z, 43.48, 0.001);
  near(s.halfAngleDeg, 20.0, 0.01); // through the published points; published alpha is 40°
});

test('a missing r1 min leaves that corner sharp and says so (338 Lapua Mag.)', () => {
  const g = geo('338_lapua_mag');
  const radii = g.path.filter((s) => s.cmd === 'A').map((a) => a.rr);
  assert.deepEqual(radii, [2.5]);
  assert.ok(g.notes.some((n) => /r1 min/.test(n)), JSON.stringify(g.notes));
});

test('17 HMR: rimfire bottleneck, rounding values missing are named', () => {
  const g = geo('17_hmr');
  assert.equal(g.straight, false);
  assert.equal(g.rimType, 'rimfire');
  assert.ok(g.notes.some((n) => /r1 min/.test(n)) && g.notes.some((n) => /r2/.test(n)), JSON.stringify(g.notes));
});

test('inner line follows the outer at tb (body), tn (neck) and blends across the shoulder', () => {
  const g = geo('308_win');
  const inner = g.inner.map((q) => [q.r, q.z]);
  near(inner[0][1], 4.8, 0.0005);
  near(inner[0][0], 5.98 + (5.765 - 5.98) * (4.8 - 3.85) / (39.62 - 3.85) - 0.6, 0.001);
  near(inner[1][0], 5.765 - 0.6, 0.001); near(inner[1][1], 39.62, 0.001);
  near(inner[2][0], 4.36 - 0.435, 0.001); near(inner[2][1], 43.48, 0.001);
  near(inner[3][0], 4.36 - 0.435, 0.001); near(inner[3][1], 51.18, 0.001);
});

test('missing value: no L6 means no bullet and a note, nothing invented', () => {
  const rec = JSON.parse(JSON.stringify(byKey('308_win')));
  delete rec.cartridge.lengths.L6;
  const g = G.buildGeometry(rec);
  assert.equal(g.bullet, null);
  assert.ok(g.notes.some((n) => /bullet/i.test(n) && /L6/.test(n)));
});

test('missing value: no E1 means no groove and a note', () => {
  const rec = JSON.parse(JSON.stringify(byKey('308_win')));
  delete rec.cartridge.caseHead.E1;
  const g = G.buildGeometry(rec);
  assert.ok(!g.points.some((p) => p.tag === 'grooveFloorEnd'));
  assert.ok(g.notes.some((n) => /groove/i.test(n) && /E1/.test(n)));
});

test('missing value: no f means no chamfer and a note', () => {
  const rec = JSON.parse(JSON.stringify(byKey('308_win')));
  delete rec.cartridge.caseHead.f;
  const g = G.buildGeometry(rec);
  assert.deepEqual([g.points[1].r, g.points[1].z], [6.005, 0]);
  assert.ok(g.notes.some((n) => /chamfer/i.test(n) && /f/.test(n)));
});

test('all 25 records: sane geometry', () => {
  for (const r of records) {
    const g = G.buildGeometry(r);
    assert.ok(g.ok, r.name);
    for (let i = 1; i < g.points.length; i++) {
      assert.ok(g.points[i].r >= 0 && g.points[i].z >= g.points[i - 1].z - 1e-9, r.name + ' monotone z at ' + i);
    }
    assert.equal(g.points[0].r, 0);
    assert.equal(g.points[0].z, 0);
    const L3 = r.cartridge.lengths.L3;
    near(g.points[g.points.length - 1].z, L3, 1e-9, r.name);
    assert.ok(g.bullet, r.name + ' bullet');
    assert.ok(g.bullet.cylinderEnd >= L3, r.name + ' nose starts outside the case');
    assert.ok(g.bullet.ogiveRadius === undefined || g.bullet.ogiveRadius > 0);
    assert.ok(g.w < L3 && g.w > 0, r.name + ' w');
    // inner wall inside the outer
    for (const q of g.inner) assert.ok(q.r > 0, r.name);
    assert.ok(g.inner[0].z === g.w);
    // pocket fits inside the cavity floor
    if (g.pocket) assert.ok(g.pocket.diameter / 2 < g.inner[0].r, r.name + ' pocket');
    // every arc was checked to fit its neighbours (no arc without its radius)
    for (const a of g.path.filter((s) => s.cmd === 'A')) assert.ok(a.rr > 0 && a.rz > 0);
  }
});

test('no number is invented: every drawn rounding radius is a published value', () => {
  for (const r of records) {
    const g = G.buildGeometry(r);
    const jc = r.cartridge.junctionCone || {};
    const published = [jc.r1Min, jc.r2].filter((v) => v !== undefined);
    const rimfireRound = { '22_long_rifle': [0.545], '22_win_mag_r_f': [0.635], '17_hmr': [0.635] }[r.key] || [];
    for (const a of g.path.filter((s) => s.cmd === 'A' && s.role === 'fillet')) {
      assert.ok(published.some((v) => Math.abs(v - a.rr) < 1e-9), r.name + ' radius ' + a.rr);
    }
    for (const a of g.path.filter((s) => s.cmd === 'A' && s.role === 'rim')) {
      assert.ok(rimfireRound.some((v) => Math.abs(v - a.rr) < 1e-9), r.name + ' rim radius');
    }
  }
});

test('angles published as degrees/minutes/seconds count as published (regression)', () => {
  const straightKeys = ['9_mm_luger', '45_auto', '40_s_w', '38_special', '357_magnum', '44_rem_mag', '22_long_rifle', '22_win_mag_r_f'];
  for (const r of records) {
    assert.equal(G.buildGeometry(r).straight, straightKeys.includes(r.key), r.name);
  }
});
