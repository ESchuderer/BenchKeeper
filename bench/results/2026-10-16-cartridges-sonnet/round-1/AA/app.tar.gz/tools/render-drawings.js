'use strict';
// Dev tool: renders drawings of the given cartridge keys (or all) to PNG files for visual review.
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const D = require('../js/drawing.js');
const records = require('../js/data.js');

(async () => {
  const out = process.argv[2] || '/tmp/opencode/drawings';
  const keys = process.argv.slice(3);
  fs.mkdirSync(out, { recursive: true });
  const css = fs.readFileSync(path.join(__dirname, '..', 'css', 'style.css'), 'utf8');
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 900, height: 700 }, deviceScaleFactor: 1.5 });
  for (const r of records.filter((x) => !keys.length || keys.includes(x.key))) {
    const d = D.buildDrawing(r);
    await page.setContent('<style>' + css + '</style><body style="margin:8px"><div class="drawing-wrap" style="max-width:860px">' + d.svg + '</div></body>');
    await page.locator('svg').screenshot({ path: path.join(out, r.key + '.png') });
  }
  await browser.close();
})();
