# C.I.P. cartridge reference

A static reference of 25 C.I.P. cartridges (data from [OpenBallistics](https://github.com/PiMetry/OpenBallistics), MIT, commit `e83db43`) for reloaders, gunsmiths and engineers: searchable list, per-cartridge detail view with all cartridge and chamber values, a true-scale 2D drawing computed from the record, and a one-page A4 print layout.

## Use

Open `index.html` in a browser (works straight from disk via `file://`), or serve the folder with any static file server. Plain HTML, CSS and JavaScript; no framework, no build step, no network requests.

- Start page: search (names and alternative names) and family filter.
- Detail view: `#/cartridge/<key>`, e.g. `index.html#/cartridge/308_win` (survives reload, can be bookmarked).
- **Print** prints the detail view as one A4 portrait page.

## Layout

| Path | What |
|---|---|
| `index.html`, `css/style.css` | page, light/dark/print styles |
| `js/data.js` | the 25 records (generated from `data/cartridges.jsonl`, never edited by hand) |
| `js/format.js` | number/angle/tolerance formatting, symbols, units, table model |
| `js/catalog.js` | search and family filter |
| `js/geometry.js` | cartridge outline, section walls, bullet (the drawing rules) |
| `js/drawing.js` | dimension layout, label placement, title block, scale, SVG |
| `js/app.js` | views and hash routing |
| `openspec/` | specifications (`specs/`) and the archived change with proposal, design and tasks |

The modules are written so that Node can `require` them too; that is how the unit tests run.

## Development

```
npm install            # dev dependency only: playwright
npx playwright install chromium
npm test               # unit tests (node:test, no browser)
npm run test:e2e       # Chromium over file://: UI, print to PDF, real-DOM label overlap
npm run build:data     # regenerate js/data.js from data/cartridges.jsonl
node scripts/render-drawings.js [outDir] [key…]   # PNGs of the drawings for visual checks
node scripts/contact-sheet.js [outDir]             # 4-up contact sheets of those PNGs
```

On a bare Linux container Chromium may lack system libraries (`libglib`, `libnss3`, …); install them with `npx playwright install-deps chromium` (needs root) or point `LD_LIBRARY_PATH` at unpacked packages.

## Drawing rules and interpretations

The geometry follows the brief's rules. Where the brief leaves room, the choices are recorded in `openspec/changes/archive/2026-10-16-build-cartridge-reference/design.md` (decisions D4–D10). Notably:

- The shoulder is drawn through the published points `(P2/2, L1)` and `(H1/2, L2)`; α is the included angle and is shown with construction legs to the cone apex on the axis.
- When a value a rule needs is missing the feature is left out and the drawing lists which value is not published (for example `r1 min` for the 338 Lapua Magnum, `E, E1, e min` for the rimmed 9,3 x 74 R). No number is invented.
- The title block states the scale at which the drawing prints on A4 (the SVG is 190 mm wide in print, so the stated scale is exact).
- `Fe` has no unit in the brief; it is shown in mm like the other lengths.
