// Views, routing and events. Everything is built with DOM APIs (textContent), so
// names such as "40 S.& W." can never be interpreted as markup.
(function () {
  'use strict';
  var CIP = window.CIP;
  var data = CIP.cartridges, fmt = CIP.format, catalog = CIP.catalog, drawing = CIP.drawing;
  var app = document.getElementById('app');
  var state = { query: '', family: '' };
  var SITE_TITLE = 'C.I.P. reference';

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') node.textContent = attrs[k];
      else node.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { if (c) node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return node;
  }

  function byKey(key) {
    for (var i = 0; i < data.length; i++) if (data[i].key === key) return data[i];
    return null;
  }

  // ---- list view ----------------------------------------------------------
  function listView() {
    document.title = 'Cartridges – ' + SITE_TITLE;
    var h1 = el('h1', { text: 'Cartridges', tabindex: '-1' });

    var search = el('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false' });
    search.value = state.query;
    var family = el('select', { id: 'family' });
    [''].concat(catalog.FAMILIES).forEach(function (f) {
      var o = el('option', { value: f, text: f || 'All' });
      if (f === state.family) o.selected = true;
      family.appendChild(o);
    });
    var count = el('p', { id: 'count', class: 'count', role: 'status' });
    var empty = el('p', { class: 'empty', text: 'No cartridge matches the search.' });
    var tbody = el('tbody');
    var table = el('table', { class: 'list' }, [
      el('thead', {}, [el('tr', {}, [
        el('th', { scope: 'col', text: 'Name' }),
        el('th', { scope: 'col', text: 'Family' }),
        el('th', { scope: 'col', class: 'num', text: 'Case length L3' })
      ])]),
      tbody
    ]);

    function refresh() {
      var shown = catalog.filter(data, state);
      tbody.textContent = '';
      shown.forEach(function (r) {
        tbody.appendChild(el('tr', { 'data-key': r.key }, [
          el('td', {}, [el('a', { href: '#/cartridge/' + r.key, text: r.name })]),
          el('td', { text: r.family }),
          el('td', { class: 'num', text: fmt.number(r.cartridge.lengths.L3) + ' mm' })
        ]));
      });
      count.textContent = catalog.countText(shown.length);
      empty.hidden = shown.length !== 0;
      table.hidden = shown.length === 0;
    }
    search.addEventListener('input', function () { state.query = search.value; refresh(); });
    family.addEventListener('change', function () { state.family = family.value; refresh(); });
    refresh();

    return [
      h1,
      el('div', { class: 'controls' }, [
        el('div', { class: 'field' }, [el('label', { for: 'search', text: 'Search' }), search]),
        el('div', { class: 'field' }, [el('label', { for: 'family', text: 'Family' }), family])
      ]),
      count, empty, table
    ];
  }

  // ---- detail view --------------------------------------------------------
  function metaList(record) {
    var dl = el('dl', { class: 'meta' });
    fmt.metadata(record).forEach(function (m) {
      var dd = el('dd', { text: m.text });
      if (m.note) dd.appendChild(el('span', { class: 'note', text: ' ' + m.note }));
      if (m.link) {
        dd.appendChild(document.createTextNode(' · source '));
        dd.appendChild(el('a', { href: m.link.href, rel: 'noopener noreferrer', text: m.link.text }));
      }
      dl.appendChild(el('div', {}, [el('dt', { text: m.label }), dd]));
    });
    return dl;
  }

  function tableFor(group, groupTitle, section) {
    var tbody = el('tbody');
    section.rows.forEach(function (r) {
      tbody.appendChild(el('tr', {}, [
        el('th', { scope: 'row', text: r.symbol }),
        el('td', { class: 'num', text: r.value }),
        el('td', { class: 'unit', text: r.unit })
      ]));
    });
    return el('table', { class: 'values', 'data-group': group, 'data-section': section.key, 'aria-label': groupTitle + ': ' + section.title }, [
      el('caption', { text: section.title }),
      el('thead', {}, [el('tr', {}, [
        el('th', { scope: 'col', text: 'Symbol' }),
        el('th', { scope: 'col', class: 'num', text: 'Value' }),
        el('th', { scope: 'col', text: 'Unit' })
      ])]),
      tbody
    ]);
  }

  function valuesSection(record, group, title) {
    var id = 'h-' + group;
    return el('section', { class: 'values-group', 'aria-labelledby': id }, [
      el('h2', { id: id, text: title }),
      el('div', { class: 'tables' }, fmt.sections(record, group).map(function (s) { return tableFor(group, title.split(' ')[0], s); }))
    ]);
  }

  function drawingFigure(record) {
    var out = drawing.render(record);
    var fig = el('figure', { class: 'drawing' });
    if (!out.ok) {
      fig.appendChild(el('p', { class: 'drawing-notes', text: 'Drawing not possible: ' + out.missing.map(fmt.symbol).join(', ') + ' not published.' }));
      return fig;
    }
    var holder = el('div', { class: 'drawing-svg' });
    holder.innerHTML = out.svg; // markup built by drawing.js from escaped record values only
    fig.appendChild(holder);
    if (out.notes.length) {
      fig.appendChild(el('div', { class: 'drawing-notes' }, [
        el('p', { text: 'Not drawn, value not published:' }),
        el('ul', {}, out.notes.map(function (n) { return el('li', { text: n }); }))
      ]));
    }
    return fig;
  }

  function detailView(record) {
    document.title = record.name + ' – ' + SITE_TITLE;
    var print = el('button', { type: 'button', class: 'print', text: 'Print' });
    print.addEventListener('click', function () { window.print(); });
    return [
      el('nav', { class: 'actions', 'aria-label': 'Page actions' }, [el('a', { href: '#/', text: 'All cartridges' }), print]),
      el('h1', { text: record.name, tabindex: '-1' }),
      metaList(record),
      drawingFigure(record),
      valuesSection(record, 'cartridge', 'Cartridge values'),
      valuesSection(record, 'chamber', 'Chamber values'),
      el('footer', { class: 'source', text: 'Source: C.I.P. TDCC, revised ' + record.revised })
    ];
  }

  function notFoundView(key) {
    document.title = 'Not found – ' + SITE_TITLE;
    return [
      el('nav', { class: 'actions' }, [el('a', { href: '#/', text: 'All cartridges' })]),
      el('h1', { text: 'Cartridge not found', tabindex: '-1' }),
      el('p', { text: 'No cartridge with the key "' + key + '" is in this reference.' })
    ];
  }

  // ---- routing ------------------------------------------------------------
  var first = true;
  function route() {
    var m = /^#\/cartridge\/(.+)$/.exec(location.hash);
    var nodes;
    if (m) {
      var key;
      try { key = decodeURIComponent(m[1]); } catch (e) { key = m[1]; }
      var rec = byKey(key);
      nodes = rec ? detailView(rec) : notFoundView(key);
    } else {
      nodes = listView();
    }
    app.textContent = '';
    nodes.forEach(function (n) { app.appendChild(n); });
    if (!first) {
      window.scrollTo(0, 0);
      var h = app.querySelector('h1');
      if (h) h.focus({ preventScroll: true });
    }
    first = false;
  }

  window.addEventListener('hashchange', route);
  route();
})();
