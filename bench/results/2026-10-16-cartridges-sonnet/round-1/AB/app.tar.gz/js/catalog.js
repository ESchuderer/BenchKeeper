// Search, family filter and count text of the start page. DOM-free.
(function (g) {
  'use strict';
  var CIP = (g.CIP = g.CIP || {});

  var FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  // case-insensitive, whitespace-collapsed, decimal comma = decimal point
  function normalize(s) {
    return String(s).toLowerCase().replace(/,/g, '.').replace(/\s+/g, ' ').trim();
  }

  function matches(record, query, family) {
    if (family && record.family !== family) return false;
    var q = normalize(query || '');
    if (!q) return true;
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (n) { return normalize(n).indexOf(q) >= 0; });
  }

  function filter(records, opts) {
    var o = opts || {};
    return records.filter(function (r) { return matches(r, o.query, o.family); });
  }

  function countText(n) {
    return n + ' cartridges';
  }

  CIP.catalog = { FAMILIES: FAMILIES, normalize: normalize, matches: matches, filter: filter, countText: countText };
  if (typeof module === 'object' && module.exports) module.exports = CIP.catalog;
})(typeof window !== 'undefined' ? window : globalThis);
