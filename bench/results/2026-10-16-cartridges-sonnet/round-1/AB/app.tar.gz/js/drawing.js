// 2D drawing of a cartridge: layout (dimension lines, label placement, title
// block, scale) and SVG markup. DOM-free; works in Node and in the browser.
//
// World coordinates are millimetres: x = z along the axis (head face at 0, head
// on the left), y = -r above the axis (outside view) and +r below it (section).
// 1 SVG user unit = 1 mm. Text sizes are chosen per drawing so the labels stay
// legible when the drawing is scaled to a phone or printed on A4.
(function (g) {
  'use strict';
  var CIP = (g.CIP = g.CIP || {});
  var geometry = CIP.geometry || (typeof require === 'function' ? require('./geometry.js') : null);
  var fmt = CIP.format || (typeof require === 'function' ? require('./format.js') : null);

  var PRINT_WIDTH = 190; // mm, A4 portrait with 10 mm margins
  var NICE_SCALES = [1, 1.2, 1.4, 1.5, 1.6, 1.8, 2, 2.2, 2.5, 3, 3.5, 4, 5, 6];
  var MAX_PRINT_HEIGHT = 140; // mm of the A4 page given to the drawing
  var MAX_TIERS = 8;

  function r3(x) { return Math.round(x * 1000) / 1000; }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function isNum(x) { return typeof x === 'number' && isFinite(x); }
  function P(x, y) { return { x: x, y: y }; }

  // ---- collision helpers --------------------------------------------------
  function rectsOverlap(a, b) {
    return a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
  }
  function inflate(r, d) {
    return { x0: r.x0 - d, y0: r.y0 - d, x1: r.x1 + d, y1: r.y1 + d };
  }
  function segHitsRect(a, b, r) {
    var t0 = 0, t1 = 1, dx = b.x - a.x, dy = b.y - a.y;
    var p = [-dx, dx, -dy, dy], q = [a.x - r.x0, r.x1 - a.x, a.y - r.y0, r.y1 - a.y];
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) {
        if (q[i] < 0) return false;
      } else {
        var t = q[i] / p[i];
        if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return t0 < t1;
  }
  function toSegs(poly) {
    var out = [];
    for (var i = 0; i + 1 < poly.length; i++) out.push({ a: poly[i], b: poly[i + 1] });
    return out;
  }

  function pathOf(poly, close) {
    if (!poly.length) return '';
    var d = 'M' + r3(poly[0].x) + ' ' + r3(poly[0].y);
    for (var i = 1; i < poly.length; i++) d += 'L' + r3(poly[i].x) + ' ' + r3(poly[i].y);
    return d + (close ? 'Z' : '');
  }
  function mapZR(list, sign) {
    return list.map(function (p) { return P(p.z, sign * p.r); });
  }

  // largest nice scale for which the content fits the printed width and stays
  // within the printed height budget (so the data sheet remains one page)
  function pickScale(contentWidth, contentHeight) {
    var best = null;
    NICE_SCALES.forEach(function (s) {
      if (contentWidth * s <= PRINT_WIDTH + 1e-9 && contentHeight * s <= MAX_PRINT_HEIGHT + 1e-9) best = s;
    });
    if (best !== null) return best;
    return Math.floor(Math.min(PRINT_WIDTH / contentWidth, MAX_PRINT_HEIGHT / contentHeight) * 100) / 100;
  }

  // ---- layout -------------------------------------------------------------
  // opts.searchBudget: maximum search nodes per tier count before the greedy fallback is used
  function layout(record, opts) {
    var searchBudget = opts && opts.searchBudget !== undefined ? opts.searchBudget : 40000;
    var m = geometry.build(record);
    if (!m.ok) return { ok: false, missing: m.missing };
    var v = m.v, bullet = m.bullet;
    var L3 = v.L3, L6 = v.L6;

    var apexZ = m.shoulder && m.shoulder.apexZ !== null ? m.shoulder.apexZ : 0;
    var extentZ = Math.max(L6, apexZ);
    var F = Math.max(1.8, Math.min(3.4, (extentZ + 8) / 34));
    F = Math.round(F * 100) / 100;
    var ah = 0.5 * F, aw = 0.14 * F, gap = 0.35 * F, over = 0.5 * F;
    var cw = 0.6 * F, padX = 0.3 * F;
    var labelH = 1.15 * F;

    // outline segments (case + exposed bullet, both halves)
    var upperCase = mapZR(m.profile, -1).concat([P(L3, 0)]);
    var lowerCase = mapZR(m.profile, 1).concat([P(L3, 0)]);
    var upperBullet = bullet ? mapZR(bullet.exposed, -1) : [];
    var lowerBullet = bullet ? mapZR(bullet.exposed, 1) : [];
    var outlineSegments = toSegs(upperCase).concat(toSegs(lowerCase), toSegs(upperBullet), toSegs(lowerBullet));

    var Rtop = 0;
    m.profile.forEach(function (p) { if (p.r > Rtop) Rtop = p.r; });
    var Rall = bullet ? Math.max(Rtop, bullet.exposedR) : Rtop;

    var occRects = [];
    var occSegs = outlineSegments.map(function (s) { return { a: s.a, b: s.b, owner: 'outline' }; });
    var dimSegments = [];
    var dims = [];
    var labels = [];
    var bb = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    function grow(x, y) {
      if (x < bb.x0) bb.x0 = x; if (x > bb.x1) bb.x1 = x;
      if (y < bb.y0) bb.y0 = y; if (y > bb.y1) bb.y1 = y;
    }
    function growRect(r) { grow(r.x0, r.y0); grow(r.x1, r.y1); }
    outlineSegments.forEach(function (s) { grow(s.a.x, s.a.y); grow(s.b.x, s.b.y); });

    function addSeg(owner, a, b) {
      var s = { a: a, b: b, owner: owner };
      dimSegments.push(s);
      occSegs.push(s);
      grow(a.x, a.y); grow(b.x, b.y);
    }

    function arrow(tip, dx, dy) { // arrowhead with its tip at `tip`, pointing along (dx, dy)
      var nx = -dy, ny = dx;
      var bx = tip.x - dx * ah, by = tip.y - dy * ah;
      return [tip, P(bx + nx * aw, by + ny * aw), P(bx - nx * aw, by - ny * aw)];
    }

    function labelRect(text, x, baseline, anchor) {
      var w = text.length * cw + 2 * padX;
      var x0 = anchor === 'start' ? x : anchor === 'end' ? x - w : x - w / 2;
      return { x0: x0, x1: x0 + w, y0: baseline - 0.85 * F, y1: baseline + 0.3 * F };
    }
    function textX(rect, anchor) {
      return anchor === 'start' ? rect.x0 + padX : anchor === 'end' ? rect.x1 - padX : (rect.x0 + rect.x1) / 2;
    }
    function rectBlocked(rect, owner, pole) {
      var big = inflate(rect, 0.12 * F);
      for (var i = 0; i < occRects.length; i++) if (rectsOverlap(big, occRects[i])) return true;
      for (var j = 0; j < occSegs.length; j++) if (occSegs[j].owner !== owner && segHitsRect(occSegs[j].a, occSegs[j].b, big)) return true;
      if (pole) for (var k = 0; k < occRects.length; k++) if (segHitsRect(pole.a, pole.b, inflate(occRects[k], 0.05 * F))) return true;
      return false;
    }
    function addLabel(dim, sym, text, rect, anchor, baseline) {
      labels.push({
        dim: dim, sym: sym, text: text, rect: rect, anchor: anchor,
        x: r3(textX(rect, anchor)), y: r3(baseline)
      });
      occRects.push(rect);
      growRect(rect);
    }

    // ---- axial dimensions (below the section) ----
    var yBase = Rall + 1.8 * F, stepA = 2.1 * F;
    var axial = [];
    var rHead = m.profile[1].r;
    if (isNum(v.R)) axial.push({ sym: 'R', value: v.R, to: v.R, rTo: m.radiusAt(v.R), short: true });
    if (m.shoulder) {
      axial.push({ sym: 'L1', value: v.L1, to: v.L1, rTo: m.radiusAt(v.L1) });
      axial.push({ sym: 'L2', value: v.L2, to: v.L2, rTo: m.radiusAt(v.L2) });
    }
    axial.push({ sym: 'L3', value: L3, to: L3, rTo: m.radiusAt(L3) });
    if (bullet) axial.push({ sym: 'L6', value: L6, to: L6, rTo: bullet.nose[bullet.nose.length - 1].r });
    axial.sort(function (a, b) { return a.to - b.to; });
    axial.forEach(function (a, i) {
      var y = yBase + i * stepA;
      var d = { sym: a.sym, value: fmt.number(a.value), kind: 'axial', x1: 0, x2: a.to, y1: y, y2: y, ext: [], arrows: [], tails: [] };
      d.ext.push([P(0, rHead + gap), P(0, y + over)]);
      d.ext.push([P(a.to, a.rTo + gap), P(a.to, y + over)]);
      d.ext.forEach(function (e) { addSeg(a.sym, e[0], e[1]); });
      if (a.short || a.to < 3.2 * ah) { // arrowheads outside the extension lines, pointing in
        var t = 1.8 * ah;
        d.arrows.push(arrow(P(0, y), 1, 0), arrow(P(a.to, y), -1, 0));
        d.tails.push([P(-t, y), P(0, y)], [P(a.to, y), P(a.to + t, y)]);
        addSeg(a.sym, P(-t, y), P(a.to + t, y));
        var text = a.sym + ' ' + d.value;
        var base = y + 0.3 * F;
        var rect = labelRect(text, a.to + t + 0.4 * F, base, 'start');
        d.label = text;
        addLabel(a.sym, a.sym, text, rect, 'start', base);
      } else {
        d.arrows.push(arrow(P(0, y), 1, 0), arrow(P(a.to, y), -1, 0));
        addSeg(a.sym, P(0, y), P(a.to, y));
        var text2 = a.sym + ' ' + d.value;
        var base2 = y - 0.35 * F;
        var rect2 = labelRect(text2, a.to / 2, base2, 'middle');
        d.label = text2;
        addLabel(a.sym, a.sym, text2, rect2, 'middle', base2);
      }
      d.arrows.forEach(function (poly) { poly.forEach(function (p) { grow(p.x, p.y); }); });
      dims.push(d);
    });

    // ---- radial dimensions: vertical line across the part, label flag in a tier above ----
    var tier0 = -(Rall + 0.8 * F);
    var tierStep = labelH + 0.3 * F;
    var maxTier = 0;
    var feats = [];
    function rOut(z) { return m.radiusAt(z); }

    var zR1 = m.chamfer ? (v.f + v.R) / 2 : v.R / 2;
    feats.push({ sym: 'R1', value: v.R1, z: zR1, r: rOut(zR1) });
    if (m.groove && isNum(v.E1)) feats.push({ sym: 'E1', value: v.E1, z: m.groove.center, r: v.E1 / 2 });
    var zP1 = Math.min(m.bodyStart + 1.2, L3);
    feats.push({ sym: 'P1', value: v.P1, z: zP1, r: rOut(zP1) });
    if (m.shoulder) {
      var zP2 = Math.max(m.bodyStart + 1.2, v.L1 - 2.0);
      feats.push({ sym: 'P2', value: v.P2, z: zP2, r: rOut(zP2) });
      var zH1 = Math.min(v.L2 + 2.0, (v.L2 + L3) / 2);
      feats.push({ sym: 'H1', value: v.H1, z: zH1, r: rOut(zH1) });
    }
    var zH2 = m.shoulder ? Math.max((v.L2 + L3) / 2, L3 - 2.0) : Math.max(m.bodyStart + 1.2, L3 - 2.0);
    feats.push({ sym: 'H2', value: v.H2, z: zH2, r: rOut(zH2) });
    if (bullet) {
      var cylEnd = Math.min(bullet.zc, L6);
      var zG = cylEnd > L3 ? (L3 + cylEnd) / 2 : L3; // middle of the exposed shank; at the mouth when none is exposed
      feats.push({ sym: 'G1', value: v.G1, z: zG, r: cylEnd > L3 ? bullet.exposedR : bullet.mouthR });
    }

    // alpha: construction legs to the cone apex, an arc with arrowheads, a flag
    var angle = null;
    if (m.shoulder && m.shoulder.apexZ !== null) {
      var s = m.shoulder, gam = s.gamma;
      var apex = P(s.apexZ, 0);
      var Dl = Math.hypot(s.apexZ - s.to.z, s.to.r);
      var rho = Math.min(0.8 * Dl, 2.5 * ah / gam);
      var n = Math.max(6, Math.ceil((2 * gam) / (4 * Math.PI / 180)));
      var arc = [];
      for (var i = 0; i <= n; i++) {
        var th = Math.PI + gam - (2 * gam * i) / n; // upper end first
        arc.push(P(apex.x + rho * Math.cos(th), apex.y + rho * Math.sin(th)));
      }
      angle = {
        apex: apex, arc: arc, rho: rho,
        legs: [[P(s.to.z, -s.to.r), apex], [P(s.to.z, s.to.r), apex]]
      };
      var text = fmt.angle(s.alpha);
      feats.push({ sym: 'α', value: text, z: arc[0].x, r: -arc[0].y, angle: true });
    }

    // Place the label flags: smallest number of tiers for which every flag finds a
    // (tier, side) whose box clears the outline, the other boxes and the other poles.
    feats.sort(function (a, b) { return b.z - a.z; });
    feats.forEach(function (f) {
      f.valueText = typeof f.value === 'string' ? f.value : fmt.number(f.value);
      f.text = f.sym + ' ' + f.valueText;
      f.w = f.text.length * cw + 2 * padX;
    });
    function candidate(f, t, anchor) {
      var y1 = tier0 - t * tierStep, y0 = y1 - labelH;
      var x0 = anchor === 'start' ? f.z + 0.2 * F : f.z - 0.2 * F - f.w;
      return {
        t: t, anchor: anchor, rect: { x0: x0, x1: x0 + f.w, y0: y0, y1: y1 }, base: y1 - 0.3 * F,
        pole: { a: P(f.z, -f.r), b: P(f.z, y0) }
      };
    }
    var nodes = 0;
    function search(i, cap, chosen) {
      if (i === feats.length) return true;
      if (++nodes > searchBudget) return false;
      var f = feats[i];
      for (var t = 0; t < cap; t++) {
        var sides = ['start', 'end'];
        for (var s = 0; s < 2; s++) {
          var c = candidate(f, t, sides[s]);
          if (rectBlocked(c.rect, f.sym, c.pole)) continue;
          var segCount = occSegs.length;
          occRects.push(c.rect);
          occSegs.push({ a: c.pole.a, b: c.pole.b, owner: f.sym });
          chosen[i] = c;
          if (search(i + 1, cap, chosen)) return true;
          occRects.pop();
          occSegs.length = segCount;
        }
      }
      return false;
    }
    var chosen = [];
    var cap = 1;
    var rectsBefore = occRects.length, segsBefore = occSegs.length;
    var found = false;
    while (cap <= MAX_TIERS && !found) {
      nodes = 0;
      found = search(0, cap, chosen);
      if (!found) { occRects.length = rectsBefore; occSegs.length = segsBefore; cap++; }
    }
    var fallback = !found;
    if (fallback) {
      // Greedy staircase, right to left, label always to the right of its pole: a later
      // flag can never be trapped under an earlier one, so a free tier always exists.
      occRects.length = rectsBefore; occSegs.length = segsBefore;
      feats.forEach(function (f, i) {
        for (var t = 0; ; t++) {
          var c = candidate(f, t, 'start');
          if (!rectBlocked(c.rect, f.sym, c.pole)) {
            chosen[i] = c;
            occRects.push(c.rect);
            occSegs.push({ a: c.pole.a, b: c.pole.b, owner: f.sym });
            return;
          }
        }
      });
    }
    // search() left the accepted boxes/poles in occ*; rebuild them through the common helpers
    occRects.length = rectsBefore; occSegs.length = segsBefore;
    feats.forEach(function (f, i) {
      var placed = chosen[i];
      if (placed.t + 1 > maxTier) maxTier = placed.t + 1;
      var d = { sym: f.sym, value: f.valueText, kind: f.angle ? 'angle' : 'radial', x1: f.z, x2: f.z, y1: -f.r, y2: f.r, ext: [], arrows: [], tails: [], label: f.text };
      if (f.angle) {
        d.x1 = d.x2 = angle.apex.x; d.y1 = d.y2 = 0;
        d.apex = angle.apex; d.arc = angle.arc; d.legs = angle.legs;
        angle.legs.forEach(function (lg) { addSeg('α', lg[0], lg[1]); });
        toSegs(angle.arc).forEach(function (sg) { addSeg('α', sg.a, sg.b); });
        var up = angle.arc[0], lo = angle.arc[angle.arc.length - 1];
        var thU = Math.atan2(up.y - angle.apex.y, up.x - angle.apex.x);
        var thL = Math.atan2(lo.y - angle.apex.y, lo.x - angle.apex.x);
        d.arrows.push(arrow(up, -Math.sin(thU), Math.cos(thU)), arrow(lo, Math.sin(thL), -Math.cos(thL)));
      } else {
        addSeg(f.sym, P(f.z, -f.r), P(f.z, f.r));
        d.arrows.push(arrow(P(f.z, -f.r), 0, -1), arrow(P(f.z, f.r), 0, 1));
      }
      d.arrows.forEach(function (poly) { poly.forEach(function (p) { grow(p.x, p.y); }); });
      d.pole = [placed.pole.a, placed.pole.b];
      addSeg(f.sym, placed.pole.a, placed.pole.b);
      addLabel(f.sym, f.sym, f.text, placed.rect, placed.anchor, placed.base);
      dims.push(d);
    });

    // centre line
    var cl = { x0: -1.5 * F, x1: Math.max(L6, angle ? angle.apex.x : 0) + 1.5 * F };
    grow(cl.x0, 0); grow(cl.x1, 0);

    // ---- title block (bottom right) ----
    var lines = [
      { text: record.name, size: 1.1 * F, bold: true },
      { text: 'C.I.P. table ' + record.tab + ' · Revised ' + record.revised, size: 0.85 * F },
      { text: 'Dimensions in mm · Scale 0.00 : 1 (A4)', size: 0.85 * F, scale: true } // 0.00 reserves the width of the final text
    ];
    var tbPad = 0.6 * F;
    var tbW = 0;
    lines.forEach(function (l) { tbW = Math.max(tbW, l.text.length * 0.62 * l.size); });
    tbW += 2 * tbPad;
    var lineH = lines.map(function (l) { return 1.45 * l.size; });
    var tbH = lineH.reduce(function (a, b) { return a + b; }, 0) + tbPad;
    var tbX1 = bb.x1, tbX0 = tbX1 - tbW;
    var tbY0 = bb.y1 + 1.2 * F;
    var tbY1 = tbY0 + tbH;
    grow(tbX0, tbY0); grow(tbX1, tbY1);

    // ---- viewBox and scale ----
    var margin = 0.9 * F;
    var contentW = bb.x1 - bb.x0 + 2 * margin;
    var H = bb.y1 - bb.y0 + 2 * margin;
    var scale = pickScale(contentW, H);
    var W = PRINT_WIDTH / scale;
    var vbx = bb.x0 - margin - (W - contentW) / 2;
    var vby = bb.y0 - margin;
    var scaleText = 'Scale ' + scale + ' : 1 (A4)';
    var y = tbY0 + tbPad * 0.4;
    var linesOut = lines.map(function (l, i) {
      y += lineH[i];
      return { text: l.scale ? 'Dimensions in mm · ' + scaleText : l.text, size: l.size, bold: !!l.bold, x: r3(tbX0 + tbPad), y: r3(y - 0.3 * l.size) };
    });

    return {
      ok: true, model: m, record: record,
      x: function (z) { return z; }, axisY: 0,
      fontSize: F, arrow: ah, scale: scale, contentWidth: contentW, contentHeight: H,
      viewBox: { x: r3(vbx), y: r3(vby), w: PRINT_WIDTH / scale, h: r3(H) },
      dims: dims, labels: labels, tiers: maxTier, fallback: fallback,
      outlineSegments: outlineSegments, dimSegments: dimSegments,
      centreLine: cl, angle: angle,
      titleBlock: { x0: tbX0, y0: tbY0, x1: tbX1, y1: tbY1, lines: linesOut },
      geometry: { upperCase: upperCase, lowerCase: lowerCase, upperBullet: upperBullet, lowerBullet: lowerBullet }
    };
  }

  // ---- SVG ------------------------------------------------------------------
  function poly(points) {
    return points.map(function (p) { return r3(p.x) + ',' + r3(p.y); }).join(' ');
  }

  function toSvg(l) {
    var m = l.model, F = l.fontSize, rec = l.record, b = m.bullet, vb = l.viewBox;
    var hs = Math.round(0.34 * F * 100) / 100;
    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' + esc(rec.name) + ' drawing"' +
      ' viewBox="' + r3(vb.x) + ' ' + r3(vb.y) + ' ' + r3(vb.w) + ' ' + r3(vb.h) + '"' +
      ' data-key="' + esc(rec.key) + '" data-rim-type="' + m.rimType + '" data-scale="' + l.scale + '"' +
      ' data-font-size="' + F + '" data-print-width="' + PRINT_WIDTH + '"' +
      ' preserveAspectRatio="xMidYMid meet" style="color:var(--draw-ink,#111)" fill="none" stroke="currentColor">');
    out.push('<defs>' +
      '<pattern id="hatch-case" patternUnits="userSpaceOnUse" width="' + hs + '" height="' + hs + '" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="' + hs + '" stroke="currentColor" stroke-width="0.16"/></pattern>' +
      '<pattern id="hatch-bullet" patternUnits="userSpaceOnUse" width="' + r3(hs * 1.9) + '" height="' + r3(hs * 1.9) + '" patternTransform="rotate(-45)">' +
      '<line x1="0" y1="0" x2="0" y2="' + r3(hs * 1.9) + '" stroke="currentColor" stroke-width="0.12"/></pattern></defs>');

    var thick = 'stroke-width="1.5" vector-effect="non-scaling-stroke" stroke-linejoin="round" stroke-linecap="round"';
    var medium = 'stroke-width="0.9" vector-effect="non-scaling-stroke" stroke-linejoin="round"';
    var thin = 'stroke-width="0.7" vector-effect="non-scaling-stroke"';
    var caseFill = 'style="fill:var(--draw-case,#ececec)"';
    var bulletFill = 'style="fill:var(--draw-bullet,#d6dce2)"';

    // outside view (upper half)
    var g = l.geometry;
    out.push('<g data-view="outside">');
    out.push('<path data-part="case-fill" d="' + pathOf([P(0, 0)].concat(g.upperCase.slice(1)), true) + '" ' + caseFill + ' stroke="none"/>');
    if (b) out.push('<path data-part="bullet-fill" d="' + pathOf(g.upperBullet, true) + '" ' + bulletFill + ' stroke="none"/>');
    out.push('<path class="outline" data-part="case-outline-upper" d="' + pathOf(g.upperCase) + '" ' + thick + '/>');
    if (b) out.push('<path class="outline" data-part="bullet-outline-upper" d="' + pathOf(g.upperBullet) + '" ' + thick + '/>');
    out.push('</g>');

    // section (lower half)
    out.push('<g data-view="section">');
    var sec = mapZR(m.sectionPolygon, 1);
    out.push('<path data-part="case-section" d="' + pathOf(sec, true) + '" ' + caseFill + ' stroke="none"/>');
    out.push('<path data-part="case-hatch" d="' + pathOf(sec, true) + '" fill="url(#hatch-case)" stroke="none"/>');
    if (b) {
      var bs = mapZR(b.full, 1);
      out.push('<path data-part="bullet-section" d="' + pathOf(bs, true) + '" ' + bulletFill + ' stroke="none"/>');
      out.push('<path data-part="bullet-hatch" d="' + pathOf(bs, true) + '" fill="url(#hatch-bullet)" stroke="none"/>');
      out.push('<path data-part="bullet-edge" d="' + pathOf(bs, true) + '" ' + medium + '/>');
    }
    out.push('<path data-part="case-edge" d="' + pathOf(sec, true) + '" ' + medium + '/>');
    out.push('<path class="outline" data-part="case-outline-lower" d="' + pathOf(g.lowerCase) + '" ' + thick + '/>');
    if (b) out.push('<path class="outline" data-part="bullet-outline-lower" d="' + pathOf(g.lowerBullet) + '" ' + thick + '/>');
    out.push('</g>');

    // centre line (dash-dot)
    var cl = l.centreLine;
    out.push('<path data-part="centre-line" d="M' + r3(cl.x0) + ' 0H' + r3(cl.x1) + '" stroke-width="0.18" ' +
      'stroke-dasharray="' + r3(2.6 * F) + ' ' + r3(0.5 * F) + ' ' + r3(0.5 * F) + ' ' + r3(0.5 * F) + '"/>');

    // dimensions
    out.push('<g data-part="dimensions">');
    l.dims.forEach(function (d) {
      out.push('<g class="dim" data-dim="' + esc(d.sym) + '" data-kind="' + d.kind + '">');
      var lines = [];
      d.ext.forEach(function (e) { lines.push([e[0], e[1]]); });
      if (d.kind === 'axial') lines.push([P(d.tails.length ? d.tails[0][0].x : d.x1, d.y1), P(d.tails.length ? d.tails[1][1].x : d.x2, d.y2)]);
      else if (d.kind === 'radial') lines.push([P(d.x1, d.y1), P(d.x2, d.y2)]);
      if (d.pole) lines.push(d.pole);
      out.push('<path d="' + lines.map(function (s) { return 'M' + r3(s[0].x) + ' ' + r3(s[0].y) + 'L' + r3(s[1].x) + ' ' + r3(s[1].y); }).join('') + '" ' + thin + '/>');
      if (d.kind === 'angle') {
        out.push('<path data-part="angle-legs" ' + thin + ' stroke-dasharray="5 3" d="' +
          d.legs.map(function (s) { return 'M' + r3(s[0].x) + ' ' + r3(s[0].y) + 'L' + r3(s[1].x) + ' ' + r3(s[1].y); }).join('') + '"/>');
        out.push('<path data-part="angle-arc" ' + thin + ' d="' + pathOf(d.arc) + '"/>');
      }
      d.arrows.forEach(function (a) { out.push('<polygon points="' + poly(a) + '" fill="currentColor" stroke="none"/>'); });
      out.push('</g>');
    });
    out.push('</g>');

    // labels
    out.push('<g data-part="labels" fill="currentColor" stroke="none" font-size="' + F + '" ' +
      'font-family="ui-monospace,SFMono-Regular,Menlo,Consolas,\'DejaVu Sans Mono\',\'Liberation Mono\',monospace">');
    l.labels.forEach(function (t) {
      out.push('<text class="dim-label" data-dim="' + esc(t.dim) + '" x="' + t.x + '" y="' + t.y + '" text-anchor="' + t.anchor + '">' + esc(t.text) + '</text>');
    });
    out.push('</g>');

    // title block
    var tb = l.titleBlock;
    out.push('<g data-part="title-block">');
    out.push('<rect x="' + r3(tb.x0) + '" y="' + r3(tb.y0) + '" width="' + r3(tb.x1 - tb.x0) + '" height="' + r3(tb.y1 - tb.y0) + '" ' + thin + '/>');
    out.push('<g fill="currentColor" stroke="none" font-family="ui-monospace,SFMono-Regular,Menlo,Consolas,\'DejaVu Sans Mono\',\'Liberation Mono\',monospace">');
    tb.lines.forEach(function (t) {
      out.push('<text x="' + t.x + '" y="' + t.y + '" font-size="' + r3(t.size) + '"' + (t.bold ? ' font-weight="700"' : '') + '>' + esc(t.text) + '</text>');
    });
    out.push('</g></g>');
    out.push('</svg>');
    return out.join('');
  }

  function render(record) {
    var l = layout(record);
    if (!l.ok) return { ok: false, missing: l.missing, svg: '', notes: [] };
    return { ok: true, svg: toSvg(l), notes: l.model.notes.map(function (n) { return n.text; }), layout: l };
  }

  CIP.drawing = { layout: layout, render: render, NICE_SCALES: NICE_SCALES, PRINT_WIDTH: PRINT_WIDTH };
  if (typeof module === 'object' && module.exports) module.exports = CIP.drawing;
})(typeof window !== 'undefined' ? window : globalThis);
