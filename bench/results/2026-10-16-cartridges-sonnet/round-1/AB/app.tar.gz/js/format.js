// Value formatting and the table/metadata model of the detail view. DOM-free.
(function (g) {
  'use strict';
  var CIP = (g.CIP = g.CIP || {});

  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max',
    alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };

  var CARTRIDGE_SECTIONS = [
    ['caseHead', 'Case head', ['R1', 'R', 'R3', 'E1', 'E', 'eMin', 'f', 'beta', 'delta']],
    ['collar', 'Collar', ['H1', 'H2']],
    ['junctionCone', 'Junction cone', ['S', 'alpha', 'r1Min', 'r2']],
    ['lengths', 'Lengths', ['L1', 'L2', 'L3', 'L4', 'L5', 'L6']],
    ['misc', 'Misc', ['Fe', 'deltaL']],
    ['powderChamber', 'Powder chamber', ['P1', 'P2']],
    ['pressures', 'Pressures', ['Pmax', 'PK', 'PE', 'EE', 'M']],
    ['projectile', 'Projectile', ['G1', 'G2', 'L3PlusG']]
  ];
  var CHAMBER_SECTIONS = [
    ['barrel', 'Barrel', ['F', 'Z']],
    ['breech', 'Breech', ['R1', 'R', 'R3', 'r']],
    ['collar', 'Collar', ['H1', 'H2']],
    ['grooves', 'Grooves', ['N', 'Q', 'b', 'u']],
    ['junctionCone', 'Junction cone', ['S', 'alpha', 'r1Max', 'r2']],
    ['lengths', 'Lengths', ['L1', 'L2', 'L3']],
    ['powderChamber', 'Powder chamber', ['E', 'P1', 'P2']],
    ['rifling', 'Rifling', ['G', 'G1', 'alpha1', 'h', 'i', 's']]
  ];
  var GROUPS = { cartridge: CARTRIDGE_SECTIONS, chamber: CHAMBER_SECTIONS };

  function number(n) {
    return String(n);
  }

  function angle(a) {
    if (typeof a === 'number') return number(a) + '°';
    return number(a.degrees) + '°' + number(a.minutes || 0) + "'" + number(a.seconds || 0) + '"';
  }

  function isAngle(field) {
    return ANGLES[field] === 1;
  }

  function symbol(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unit(field) {
    if (isAngle(field)) return '°';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  // value text of a field; tol (a number) is appended with its own sign
  function value(field, v, tol) {
    var text = isAngle(field) ? angle(v) : number(v);
    if (tol !== undefined && tol !== null) {
      text += ' ' + (tol > 0 ? '+' : '') + number(tol);
    }
    return text;
  }

  function isTolerance(field) {
    return /Tol$/.test(field);
  }

  // Sections of one group ('cartridge' | 'chamber') as table models. Fields not
  // in the preferred order are appended in record order; empty sections vanish.
  function sections(record, group) {
    var out = [];
    var data = record[group] || {};
    GROUPS[group].forEach(function (def) {
      var fields = data[def[0]];
      if (!fields) return;
      var present = Object.keys(fields).filter(function (f) { return !isTolerance(f); });
      var ordered = def[2].filter(function (f) { return present.indexOf(f) >= 0; });
      present.forEach(function (f) { if (ordered.indexOf(f) < 0) ordered.push(f); });
      if (!ordered.length) return;
      out.push({
        key: def[0],
        title: def[1],
        rows: ordered.map(function (f) {
          return {
            field: f,
            symbol: symbol(f),
            value: value(f, fields[f], fields[f + 'Tol']),
            unit: unit(f)
          };
        })
      });
    });
    return out;
  }

  var NOT_PUBLISHED = 'not published';

  // label/text pairs of the detail header; water capacity carries note and link
  function metadata(record) {
    var ann = record.annotations || {};
    var alt = record.alternativeNames;
    var cap = ann.publishedCapacity;
    var capacity = { label: 'Water capacity', text: NOT_PUBLISHED };
    if (cap && typeof cap.grH2O === 'number') {
      capacity.text = number(cap.grH2O) + ' gr H2O';
      if (cap.note) capacity.note = cap.note;
      if (cap.url) capacity.link = { text: cap.source || cap.url, href: cap.url };
    }
    return [
      { label: 'Alternative names', text: alt && alt.length ? alt.join(', ') : NOT_PUBLISHED },
      { label: 'Family', text: record.family },
      { label: 'Category', text: ann.category || NOT_PUBLISHED },
      { label: 'Primer type', text: ann.primerType || NOT_PUBLISHED },
      { label: 'C.I.P. table', text: record.tab },
      { label: 'Country', text: record.country },
      { label: 'Published', text: record.published },
      { label: 'Revised', text: record.revised },
      { label: 'Pressure method', text: record.pressureMethod },
      capacity
    ];
  }

  CIP.format = {
    number: number, angle: angle, isAngle: isAngle, symbol: symbol, unit: unit,
    value: value, sections: sections, metadata: metadata, NOT_PUBLISHED: NOT_PUBLISHED
  };
  if (typeof module === 'object' && module.exports) module.exports = CIP.format;
})(typeof window !== 'undefined' ? window : globalThis);
