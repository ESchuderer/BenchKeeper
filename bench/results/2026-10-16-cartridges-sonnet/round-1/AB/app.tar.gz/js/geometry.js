// Cartridge geometry from a record. DOM-free, all lengths in mm.
//
// Coordinates are (z, r): z along the axis from the head face (0) to the mouth,
// r the radius. Every number comes from the record or from a rule of the brief;
// when a value a rule needs is missing the feature is left out and named in
// `notes` (never invented).
(function (g) {
  'use strict';
  var CIP = (g.CIP = g.CIP || {});
  var fmt = CIP.format || (typeof require === 'function' ? require('./format.js') : null);

  var DEG = Math.PI / 180;
  var ARC_STEP = 6 * DEG;

  function isNum(x) {
    return typeof x === 'number' && isFinite(x);
  }

  function degrees(a) {
    if (isNum(a)) return a;
    if (a && isNum(a.degrees)) return a.degrees + (a.minutes || 0) / 60 + (a.seconds || 0) / 3600;
    return undefined;
  }

  function pt(z, r) {
    return { z: z, r: r };
  }

  // ---- rule 1 -------------------------------------------------------------
  function rimType(o) {
    if (o.family === 'belted') return 'belted';
    if (o.family === 'rimfire') return 'rimfire';
    var ratio = o.R1 / o.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // ---- fillets ------------------------------------------------------------
  // Tangent arc of `radius` at corner `v` between the lines to `a` and `b`,
  // returned as points replacing `v`. The tangent length is capped at
  // `maxFrac` of the shorter adjacent segment so a large radius cannot invert
  // the outline.
  function fillet(a, v, b, radius, maxFrac) {
    var u1 = [a.z - v.z, a.r - v.r], u2 = [b.z - v.z, b.r - v.r];
    var l1 = Math.hypot(u1[0], u1[1]), l2 = Math.hypot(u2[0], u2[1]);
    if (!(radius > 0) || l1 === 0 || l2 === 0) return [v];
    u1 = [u1[0] / l1, u1[1] / l1];
    u2 = [u2[0] / l2, u2[1] / l2];
    var phi = Math.acos(Math.max(-1, Math.min(1, u1[0] * u2[0] + u1[1] * u2[1])));
    if (phi < 1e-3 || Math.abs(phi - Math.PI) < 1e-3) return [v];
    var rad = radius;
    var t = rad / Math.tan(phi / 2);
    var tMax = maxFrac * Math.min(l1, l2);
    if (t > tMax) {
      t = tMax;
      rad = t * Math.tan(phi / 2);
    }
    var t1 = pt(v.z + u1[0] * t, v.r + u1[1] * t);
    var t2 = pt(v.z + u2[0] * t, v.r + u2[1] * t);
    var bis = [u1[0] + u2[0], u1[1] + u2[1]];
    var bl = Math.hypot(bis[0], bis[1]);
    var cd = rad / Math.sin(phi / 2);
    var c = pt(v.z + (bis[0] / bl) * cd, v.r + (bis[1] / bl) * cd);
    var a1 = Math.atan2(t1.r - c.r, t1.z - c.z);
    var a2 = Math.atan2(t2.r - c.r, t2.z - c.z);
    var d = a2 - a1;
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d < -Math.PI) d += 2 * Math.PI;
    var n = Math.max(2, Math.ceil(Math.abs(d) / ARC_STEP));
    var out = [];
    for (var i = 0; i <= n; i++) {
      var ang = a1 + (d * i) / n;
      out.push(pt(c.z + rad * Math.cos(ang), c.r + rad * Math.sin(ang)));
    }
    out[0] = t1;
    out[n] = t2;
    return out;
  }

  // ---- helpers on polylines ----------------------------------------------
  // silhouette radius at z: the largest r of any segment covering z
  function radiusOn(poly, z) {
    var best = -Infinity;
    for (var i = 0; i + 1 < poly.length; i++) {
      var a = poly[i], b = poly[i + 1];
      var lo = Math.min(a.z, b.z), hi = Math.max(a.z, b.z);
      if (z < lo - 1e-12 || z > hi + 1e-12) continue;
      var r = hi - lo < 1e-12 ? Math.max(a.r, b.r) : a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
      if (r > best) best = r;
    }
    return best === -Infinity ? undefined : best;
  }

  var LABELS = { bulletShape: 'bullet shape', primerType: 'primer type' };
  function sym(f) {
    return LABELS[f] || fmt.symbol(f);
  }

  function missingOf(vals, names) {
    return names.filter(function (n) { return !isNum(vals[n]); });
  }

  function flatten(c) {
    var v = {};
    Object.keys(c || {}).forEach(function (sec) {
      Object.keys(c[sec]).forEach(function (k) { v[k] = c[sec][k]; });
    });
    return v;
  }

  var POCKET_D = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  // ---- bullet (rule 7) ----------------------------------------------------
  var CYL_K = {
    pointy: { rifle: 0.40, pistol: 0.40 },
    rounded: { rifle: 0.55, pistol: 0.65 },
    flat: { rifle: 0.60, pistol: 0.70 },
    semi_wadcutter: { rifle: 0.78, pistol: 0.78 }
  };

  function bulletModel(v, ann, tb) {
    var shape = ann.defaultBulletShape;
    if (!CYL_K[shape]) return null;
    var branch = ann.category === 'pistol' ? 'pistol' : 'rifle'; // rifle, rimfire -> rifle branch
    var G1 = v.G1, L3 = v.L3, L6 = v.L6, H2 = v.H2;
    var heeled = H2 - G1 <= 0.015;
    var exposedR = (heeled ? H2 : G1) / 2;
    var seatR = heeled ? H2 / 2 - tb : G1 / 2;
    var s;
    if (shape === 'pointy') s = 1.0 * G1;
    else if (shape === 'semi_wadcutter') s = 0.6 * G1;
    else s = (branch === 'pistol' ? 0.4 : 0.8) * G1;
    var k = CYL_K[shape][branch];
    var zb = L3 - s;
    var Lb = L6 - zb;
    var zc = zb + k * Lb;
    var n = L6 - zc;
    var m, rho, nose = [], i, N;

    if (shape === 'pointy') {
      m = Math.max(0.08 * G1, 1.27);
      var d = exposedR - m / 2;
      rho = (d * d + n * n) / (2 * d);
      var thetaEnd = Math.atan2(n, rho - d);
      N = Math.max(8, Math.ceil(thetaEnd / (3 * DEG)));
      for (i = 0; i <= N; i++) {
        var th = (thetaEnd * i) / N;
        nose.push(pt(zc + rho * Math.sin(th), exposedR - rho + rho * Math.cos(th)));
      }
    } else if (shape === 'rounded') {
      m = 0.15 * G1;
      var b = exposedR - m / 2;
      N = 24;
      for (i = 0; i <= N; i++) {
        var t = ((Math.PI / 2) * i) / N;
        nose.push(pt(zc + n * Math.sin(t), m / 2 + b * Math.cos(t)));
      }
    } else {
      m = (shape === 'flat' ? 0.55 : 0.6) * G1;
      nose = [pt(zc, exposedR), pt(L6, m / 2)];
    }
    nose[0] = pt(zc, exposedR);
    nose[nose.length - 1] = pt(L6, m / 2);

    // outside view: the part beyond the mouth. If the cylinder/nose starts inside the
    // case, cut the outline at z = L3 (radius interpolated on the outline there).
    var exposed = [pt(L3, 0)];
    if (zc >= L3) {
      exposed.push(pt(L3, exposedR));
      nose.forEach(function (p) { if (p.z > L3 + 1e-12) exposed.push(p); });
    } else {
      var k0 = 0;
      while (k0 + 1 < nose.length && nose[k0 + 1].z <= L3) k0++;
      var a = nose[k0], b2 = nose[k0 + 1];
      exposed.push(pt(L3, a.r + ((b2.r - a.r) * (L3 - a.z)) / (b2.z - a.z)));
      for (var q = k0 + 1; q < nose.length; q++) exposed.push(nose[q]);
    }
    exposed.push(pt(L6, 0));

    var full = [pt(zb, 0), pt(zb, seatR), pt(L3, seatR)];
    if (heeled) full.push(pt(L3, exposedR));
    nose.forEach(function (p) { full.push(p); });
    full.push(pt(L6, 0));

    return {
      shape: shape, category: ann.category, heeled: heeled,
      s: s, k: k, zb: zb, zc: zc, Lb: Lb, n: n, m: m, rho: rho,
      exposedR: exposedR, seatR: seatR, mouthR: exposed[1].r,
      nose: nose, exposed: exposed, full: full
    };
  }

  // ---- build --------------------------------------------------------------
  var REQUIRED = ['R1', 'R', 'P1', 'H2', 'L3', 'L6', 'G1'];

  function build(record) {
    var c = record.cartridge || {};
    var ann = record.annotations || {};
    var v = flatten(c);
    var notes = [];
    var missingReq = missingOf(v, REQUIRED);
    if (missingReq.length) return { ok: false, missing: missingReq, name: record.name, key: record.key, notes: [] };

    function note(feature, missing, text) {
      notes.push({ feature: feature, missing: missing.map(sym), text: text + ' ' + missing.map(sym).join(', ') + ' not published.' });
    }

    var type = rimType({ family: record.family, R1: v.R1, P1: v.P1 });
    var rimfire = type === 'rimfire';
    var belted = type === 'belted';
    var R1h = v.R1 / 2, Ph = v.P1 / 2;
    var pts = [pt(0, 0)];
    var beltRampEnd = null;
    var groove = null;
    var rimEdge; // radius at which the rim back face begins
    var chamfer = false;

    // rule 2: head face and rim edge
    if (rimfire) {
      var rho = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
      var rc = R1h - rho;
      var zc = v.R / 2;
      pts.push(pt(0, rc));
      if (zc - rho > 1e-9) pts.push(pt(zc - rho, rc));
      var n = Math.max(6, Math.ceil(Math.PI / ARC_STEP));
      for (var i = 0; i <= n; i++) {
        var th = -Math.PI / 2 + (Math.PI * i) / n;
        pts.push(pt(zc + rho * Math.sin(th), rc + rho * Math.cos(th)));
      }
      // arc ends are exactly on the rim line; drop duplicates of the straight pieces
      if (v.R - (zc + rho) > 1e-9) pts.push(pt(v.R, rc));
      rimEdge = rc;
    } else {
      chamfer = isNum(v.beta) && isNum(v.f) && v.beta < 90;
      if (chamfer) {
        pts.push(pt(0, R1h - Math.min(v.f * Math.tan(v.beta * DEG), v.R1 / 4)));
        pts.push(pt(v.f, R1h));
      } else {
        pts.push(pt(0, R1h));
        var mc = missingOf(v, ['beta', 'f']);
        if (mc.length) note('chamfer', mc, 'Head chamfer not drawn:');
      }
      pts.push(pt(v.R, R1h));
      rimEdge = R1h;
    }
    var last = pts[pts.length - 1];
    if (Math.abs(last.z - v.R) > 1e-9) pts.push(pt(v.R, rimEdge));

    // rule 3: extractor groove / belt
    var bodyStart;
    var mg = missingOf(v, ['E', 'E1', 'eMin']);
    var hasGroove = mg.length === 0 && !rimfire;
    if (!hasGroove && !rimfire) {
      note('groove', mg, 'Extractor groove not drawn:');
      if (belted) note('belt', mg.concat(missingOf(v, ['R3', 'delta'])), 'Belt not drawn:');
    }
    if (hasGroove) {
      var E1h = v.E1 / 2;
      var floorEnd = Math.min(v.R + v.eMin, v.E);
      pts.push(pt(v.R, E1h));
      pts.push(pt(floorEnd, E1h));
      var beltOk = belted && isNum(v.R3) && isNum(v.delta);
      if (belted && !beltOk) note('belt', missingOf(v, ['R3', 'delta']), 'Belt not drawn:');
      if (beltOk) {
        var Rb = v.R3 / 2;
        var rampEnd = Math.min(floorEnd + (Rb - E1h) / Math.tan(v.delta * DEG), v.E);
        beltRampEnd = rampEnd;
        pts.push(pt(rampEnd, Rb));
        pts.push(pt(v.E, Rb));
        pts.push(pt(v.E, Ph));
      } else {
        pts.push(pt(v.E, Ph));
      }
      groove = { z0: v.R, z1: floorEnd, r: E1h, center: (v.R + floorEnd) / 2 };
      bodyStart = v.E;
    } else {
      pts.push(pt(v.R, Ph));
      bodyStart = v.R;
    }
    var body0 = pts[pts.length - 1];

    // rules 4-6: body, shoulder, neck
    var hasShoulder = degrees(v.alpha) !== undefined && isNum(v.L1) && isNum(v.L2);
    var shoulder = null;
    var mouth = pt(v.L3, v.H2 / 2);
    if (hasShoulder && v.L2 <= v.L1) {
      notes.push({ feature: 'shoulder', missing: [], text: 'Shoulder not drawn (straight case): L1 and L2 do not describe a shoulder.' });
    } else if (hasShoulder && isNum(v.P2) && isNum(v.H1)) {
      var s1 = pt(v.L1, v.P2 / 2), s2 = pt(v.L2, v.H1 / 2);
      var body = fillet(body0, s1, s2, v.r1Min, 0.45);
      var neck = fillet(s1, s2, mouth, v.r2, 0.45);
      if (!isNum(v.r1Min)) note('shoulder-body-corner', ['r1Min'], 'Shoulder body corner not rounded:');
      if (!isNum(v.r2)) note('shoulder-neck-corner', ['r2'], 'Shoulder neck corner not rounded:');
      body.forEach(function (p) { pts.push(p); });
      neck.forEach(function (p) { pts.push(p); });
      var gamma = Math.atan((s1.r - s2.r) / (s2.z - s1.z));
      var apexZ = gamma > 1e-4 ? s2.z + s2.r / Math.tan(gamma) : null; // no cone -> no apex
      shoulder = {
        from: s1, to: s2, gamma: gamma, alpha: v.alpha, alphaDegrees: degrees(v.alpha),
        apexZ: apexZ !== null && isFinite(apexZ) ? apexZ : null
      };
    } else if (hasShoulder) {
      note('shoulder', missingOf(v, ['P2', 'H1']), 'Shoulder not drawn (straight case):');
    } else {
      var ms = missingOf({ alpha: degrees(v.alpha), L1: v.L1, L2: v.L2 }, ['alpha', 'L1', 'L2']);
      note('shoulder', ms, 'Shoulder not drawn (straight case):');
    }
    pts.push(mouth);

    pts = pts.filter(function (p, i) { return i === 0 || Math.hypot(p.z - pts[i - 1].z, p.r - pts[i - 1].r) > 1e-9; });

    function radiusAt(z) {
      return radiusOn(pts, z);
    }

    // rule 8: walls and head
    var heeledCase = v.H2 - v.G1 <= 0.015;
    var tn = (v.H2 - v.G1) / 2;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * Ph);
    if (heeledCase) tn = tb;

    var pocket = null;
    if (!rimfire) {
      var pt0 = ann.primerType;
      if (POCKET_D[pt0]) pocket = { d: POCKET_D[pt0], depth: POCKET_DEPTH[pt0] };
      else note('pocket', ['primerType'], 'Primer pocket not drawn:');
    }
    var wc = [2.5, 0.25 * Ph];
    if (pocket) wc.push(pocket.depth + 1.5);
    if (hasGroove) wc.push(v.E + tb);
    if (beltRampEnd !== null) wc.push(beltRampEnd + tb);
    var w = Math.max.apply(null, wc);

    function wallAt(z) {
      if (shoulder) {
        if (z <= shoulder.from.z) return tb;
        if (z >= shoulder.to.z) return tn;
        return tb + ((tn - tb) * (z - shoulder.from.z)) / (shoulder.to.z - shoulder.from.z);
      }
      if (z <= w) return tb;
      if (z >= v.L3) return tn;
      return tb + ((tn - tb) * (z - w)) / (v.L3 - w);
    }

    var zs = [w, v.L3];
    pts.forEach(function (p) { if (p.z > w && p.z < v.L3) zs.push(p.z); });
    if (shoulder) [shoulder.from.z, shoulder.to.z].forEach(function (z) { if (z > w && z < v.L3) zs.push(z); });
    zs.sort(function (a, b) { return a - b; });
    var inner = [];
    zs.forEach(function (z, i) {
      if (i && Math.abs(z - zs[i - 1]) < 1e-12) return;
      inner.push(pt(z, radiusAt(z) - wallAt(z)));
    });
    function innerAt(z) {
      for (var i = 0; i + 1 < inner.length; i++) {
        if (z >= inner[i].z - 1e-12 && z <= inner[i + 1].z + 1e-12) {
          var a = inner[i], b = inner[i + 1];
          return b.z === a.z ? a.r : a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
        }
      }
      return undefined;
    }

    // section polygon of the case (lower half, r >= 0): head solid + walls, pocket cut out
    var poly = [];
    poly.push(pocket ? pt(pocket.depth, 0) : pt(0, 0));
    poly.push(pt(w, 0));
    inner.forEach(function (p) { poly.push(p); });
    for (var j = pts.length - 1; j >= 1; j--) poly.push(pts[j]);
    if (pocket) {
      poly.push(pt(0, pocket.d / 2));
      poly.push(pt(pocket.depth, pocket.d / 2));
    }

    var bullet = bulletModel(v, ann, tb);
    if (!bullet) note('bullet', ['bulletShape'], 'Bullet not drawn:');

    return {
      ok: true, key: record.key, name: record.name, rimType: type,
      v: v, profile: pts, chamfer: chamfer, bodyStart: bodyStart, groove: groove, beltRampEnd: beltRampEnd,
      shoulder: shoulder, walls: { tn: tn, tb: tb }, w: w, pocket: pocket,
      inner: inner, sectionPolygon: poly, bullet: bullet, notes: notes,
      radiusAt: radiusAt, innerAt: innerAt
    };
  }

  CIP.geometry = { build: build, rimType: rimType, degrees: degrees, fillet: fillet };
  if (typeof module === 'object' && module.exports) module.exports = CIP.geometry;
})(typeof window !== 'undefined' ? window : globalThis);
