# Design

## Context

Greenfield, empty project. See `proposal.md` for motivation and `specs/` for the contract. Hard constraints: plain HTML/CSS/JS, no build, no network, must work from `file://` in Chromium (so no `fetch` of local JSON and no ES modules, both blocked by CORS on `file://`), Node 22 available for dev tooling, network access to npm only for dev dependencies.

## Goals / Non-Goals

**Goals:**
- Pure, DOM-free modules for formatting, filtering, geometry and drawing layout, so they run unchanged in Node unit tests and in the browser.
- A drawing whose label layout is computed (not hand-placed) and verifiable: no label/label or label/outline overlap for all 25 records.
- One A4 page in print, verified by rendering real PDFs in Chromium.

**Non-Goals:**
- No editing, unit conversion, comparison view, import/export or i18n.
- No data validation beyond using values as given; no use of `annotations.implausible`, `confidence` or `S` in the UI.
- No bundler, transpiler, TypeScript or CSS preprocessor.

## Decisions

**D1. Classic scripts with a shared `CIP` namespace (UMD-style wrappers).** Each file is an IIFE that exports to `module.exports` under Node and to `window.CIP` in the browser. Alternative ES modules: rejected, Chromium blocks module scripts from `file://`.

**D2. Data as `js/data.js` (`CIP.cartridges = [...]`), generated once from `data/cartridges.jsonl`.** The JSONL is the verbatim source; `scripts/build-data.js` converts it, and a unit test asserts deep equality of the two so the shipped data cannot drift. Alternative `fetch('cartridges.jsonl')`: fails on `file://`.

**D3. Hash routing: `#/` and `#/cartridge/<key>`.** Works from `file://`, survives reload, is bookmarkable, needs no server rewrite. The `hashchange` event drives rendering. Search text and family live in memory so "All cartridges" restores them. Alternative `history.pushState`: breaks reload on `file://` and static servers.

**D4. Numbers are shown with `String(n)`.** JSON cannot preserve `4150.0` vs `4150`; the brief's own example (`4150 bar`) shows the integer form. Tolerances render as `value tol` with the tolerance's own sign (`39.62 -0.2`). Angle objects render `D°M'S"` without zero padding; zero seconds are shown (`1°30'0"`).

**D5. Units.** Listed units per the brief; every other field (including `Fe`, `deltaL`, `S`, `b`, `u`, `G`, `h`, `s`, `F`, `Z`, `r`) is a length in mm, following "Lengths and diameters are in mm". `Fe` is not defined in the brief; mm is the only unit the brief allows it.

**D6. Result count text is always `<n> cartridges`** (also for 1), exactly as specified; the zero case adds an explicit message.

**D7. Geometry (`js/geometry.js`) works in `(z, r)` and returns the outer half-profile as `{z, r}` points** from the axis at the head face to the mouth, exactly as in the brief's rule order; mirroring happens only in rendering. Fillets (r1 min, r2) are tangent arcs sampled as polylines; the tangent length is clamped to 45 % of the adjacent segment so a large radius cannot invert the outline. Interpretations of unclear rules:
- Rimfire: the half-round replaces the chamfer/square edge (chamfer is a centrefire feature).
- Body start `z0` is `E` when a groove or belt exists, otherwise `R`.
- Missing value → feature skipped and named in `notes` (a belted case with missing groove values also gets a belt note). Rimfire cases are not reported for groove/chamfer (those features do not apply to them), every other case type is.
- Straight cases (no α, L1 or L2, or no P2/H1 to place a shoulder) blend the wall linearly from `tb` at the head-solid end `w` to `tn` at the mouth, so the bullet fits exactly at the mouth.
- Heeled cases use `tn = tb` (uniform wall) because the heel is sized to `H2 − 2·tb`.
- "k·Lb" and `s` use `G1`; radii of the exposed bullet use `H2/2` when heeled, else `G1/2`.
- `category` (rifle/pistol/rimfire) from `annotations.category` selects the rifle/pistol branch of the seating and cylinder tables.

**D8. Drawing layout (`js/drawing.js`) is a small label-placement engine, not hand-tuned offsets.**
- Axial dimensions (L1, L2, L3, L6, R) sit below the section in nested levels by span; labels centred above their line. R is only 1–1.5 mm wide, so its arrowheads go outside and its label sits to the right.
- Diameter dimensions (R1, E1, P1, P2, H1, H2, G1) are vertical lines at a z-position **offset from the axial extension lines** (P2 at L1−2.5 on the body, H1 at L2+2.5 on the neck, H2 at L3−2.5, G1 mid exposed shank, R1 at R/2, E1 at the groove floor, P1 at body start+2.5) so they never coincide with the L-extension lines; their labels are "flags" in tiers above the drawing, connected by a stub.
- Flags (label + pole) are placed by a bounded backtracking search over (tier, side) per feature with iterative deepening on the tier count, so the arrangement with the fewest tiers wins; each candidate is checked against all placed label rectangles, all outline segments and all dimension segments. A node budget (40 000 per tier count) bounds the cost; if it is exhausted or no arrangement exists within 8 tiers, a greedy staircase (right to left, label always right of its pole) is used, which cannot trap a later flag and therefore always terminates with a collision-free result (`layout().fallback` reports it; a unit test forces it for all 25 records).
- α: construction legs from the neck end of the shoulder (upper and lower, mirrored) to the cone apex on the axis (computed from the published shoulder points), an arc at the apex with arrowheads, and a pole up to a tier label. The viewBox grows to include the apex (only `9,3 x 74 R`, α = 10°58', reaches beyond the bullet tip). If the published points do not form a cone (P2 ≤ H1) the shoulder line is drawn but no α construction; if L2 ≤ L1 no shoulder is drawn and a note says so.
- Label font size `F = clamp((extent + 8)/34, 1.8, 3.4)` user units from the drawing's axial extent, monospace so that text width ≈ `0.6·F·chars` is predictable without DOM measurement. A Chromium test confirms with real `getBBox()`.
- Scale: the drawing prints at 190 mm wide. The largest "nice" scale for which the content fits 190 mm in width **and 140 mm in height** (so the data sheet stays one page; short cartridges would otherwise blow up) is picked from a fixed list and the viewBox is padded to exactly `190/scale` mm wide, so "Scale 1.5 : 1" is literally true on A4 (verified in Chromium). If no listed scale fits, the exact scale is floored to two decimals.
- Title block: three compact lines (name; table and revision; "Dimensions in mm" and scale) at the bottom right, because a taller block cost too much page height.
- Strokes use `vector-effect: non-scaling-stroke` (px) so thin lines stay visible when the SVG shrinks to a phone; coordinates stay in mm.

**D9. Theming by CSS variables.** The SVG is inline, so its classes are styled by page CSS; dark mode swaps the variables via `prefers-color-scheme`; the `@media print` block comes last and forces the light palette and pure black ink.

**D10. Print.** `@page { size: A4; margin: 10mm }`. The value tables flow in 4 CSS columns (6.6 pt) and the metadata in 6 grid columns to fit one page (worst case of the 25 records ends 9 mm above the page limit); the drawing is `width: 190mm`; the source footer is in normal flow at the end (not a margin box), which is portable.

**D11. Tests.** `node:test` for unit tests (no dependency). Playwright (dev dependency only) drives Chromium for e2e over `file://`, request logging, print emulation, PDF page count, dark mode, 360 px viewport and the real-DOM overlap check.

## Risks / Trade-offs

- [Label estimates differ from real font metrics] → monospace stack + 10 % padding + a Chromium `getBBox()` overlap test over all 25 records.
- [Greedy layout leaves tall tier stacks for crowded heads] → bounded by the tier count check in unit tests; acceptable cosmetics.
- [One A4 page could overflow for the tallest drawing] → measured via PDF page count for all 25 records; table columns/fonts tuned until it holds.
- [Vertical diameter lines cross the section] → accepted; they are thin, and arrowheads touch the outline so the measured diameter is unambiguous.
- [`Fe` unit unknown] → shown in mm, recorded in D5.
- [Interpretations in D7 may differ from a reader's] → each is a single, documented place in `geometry.js`.
