# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick, trustworthy reference for C.I.P. cartridge and chamber dimensions, with a drawing they can check numbers against. The OpenBallistics cartridge database has the data but not a dense, printable, offline reference. We build a small static app over 25 given records that works from `file://` and prints as a one-page A4 data sheet.

## What Changes

- New static web app (`index.html` + CSS + JS, no framework, no build, no network): start page with searchable, filterable cartridge list; per-cartridge detail view with bookmarkable address.
- Detail view shows metadata, a true-scale inline SVG drawing computed from the record, and grouped value tables for cartridge and chamber.
- Drawing is generated from the geometry rules in the brief (head, extractor groove, belt, body, shoulder, neck, bullet, section walls, primer pocket), with dimension lines, an angle dimension, a title block and an explicit list of values that were missing.
- Print stylesheet: one A4 portrait page per detail view, black on white.
- Light/dark theme following the system; phone-friendly layout.
- Dev-only tooling: `node:test` unit tests, Playwright (Chromium) end-to-end/print tests.

## Capabilities

### New Capabilities
- `cartridge-catalog`: start page list, text search over names and alternative names, family filter, count, navigation to detail views.
- `cartridge-detail`: detail view content, value formatting (numbers, tolerances, angles, symbols, units), grouped tables, bookmarkable addresses, water-capacity source link.
- `cartridge-drawing`: the computed, true-scale SVG drawing — geometry rules, section view, dimension lines and labels, title block, missing-value reporting, responsive scaling.
- `cartridge-print`: print layout of a detail view as a single A4 portrait page.
- `static-delivery`: plain-files delivery, `file://` operation, no network access, theming and accessibility baseline.

### Modified Capabilities

None (greenfield; `openspec/specs/` is empty).

## Impact

- New files in the project root: `index.html`, `css/`, `js/`, `data/`, `scripts/`, `test/`, `package.json` (dev dependencies only: `playwright`).
- No runtime dependencies, no server code, no external requests.
- Data is used exactly as given; no records are added or altered.
