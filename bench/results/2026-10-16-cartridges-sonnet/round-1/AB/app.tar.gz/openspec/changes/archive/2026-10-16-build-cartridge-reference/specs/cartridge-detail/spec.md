# Spec Delta

## Purpose

The per-cartridge page: all published metadata, the drawing, and every cartridge and chamber value in labelled tables, reachable by a stable, bookmarkable address.

## ADDED Requirements

### Requirement: Bookmarkable detail address
Each cartridge's detail view SHALL have its own address based on the record's `key`, which opens the same view after a reload, in a new tab or from a bookmark, from `file://` as well as from a web server. Unknown keys SHALL show a not-found message with a link back to the list.

#### Scenario: Open from a link
- **WHEN** the user follows the "308 Win." link
- **THEN** the address identifies `308_win` and the heading is "308 Win."

#### Scenario: Reload
- **WHEN** the page for `308_win` is reloaded or opened directly by its address
- **THEN** the "308 Win." detail view is shown

#### Scenario: Unknown key
- **WHEN** an address names a key that does not exist
- **THEN** a message says the cartridge was not found and a link "All cartridges" leads to the list

### Requirement: Metadata
The detail view SHALL start with a heading holding the cartridge's name, followed by: alternative names, family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method, and the published water capacity with a link to its source. Missing optional information SHALL be shown as "not published", not omitted silently.

#### Scenario: Metadata of 308 Win.
- **WHEN** the detail view of "308 Win." is shown
- **THEN** it lists alternative names "308 Winchester" and "7,62 x 51", family rimless, category rifle, primer type lr, table I, country US, published 1984-06-14, revised 2008-09-23, pressure method Transducer
- **AND** the water capacity "56" with the note and a link "kwk" to http://kwk.us/cases.html

#### Scenario: No published capacity
- **WHEN** the detail view of "7 x 64" is shown
- **THEN** the water capacity reads "not published" and no source link is shown

### Requirement: Value tables grouped by section
The view SHALL show all cartridge values and all chamber values, each section in its own table with the columns "Symbol", "Value" and "Unit". Sections with no values SHALL not be shown.

#### Scenario: Sections present
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** there are cartridge tables for case head, collar, junction cone, lengths, misc, powder chamber, pressures and projectile, and chamber tables for barrel, breech, collar, grooves, junction cone, lengths, powder chamber and rifling
- **AND** every record field appears in exactly one row, except tolerance fields

#### Scenario: Pistol without junction cone
- **WHEN** the detail view of "9 mm Luger" is shown
- **THEN** no junction cone table is shown

### Requirement: Symbols and units
Rows SHALL carry the field name as symbol, except eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L" and L3PlusG "L3 + G". Units SHALL be bar for Pmax, PK and PE; J for EE; g for M; mm² for Q; none for N; degrees for angles; mm for every other value.

#### Scenario: Symbols and units
- **WHEN** the pressures table of "308 Win." is shown
- **THEN** the row "Pmax" reads "4150" with unit "bar" and the row "EE" reads "3920" with unit "J"
- **AND** the row "M" reads "25" with unit "g"

#### Scenario: Renamed symbols
- **WHEN** the case head table of "223 Rem." is shown
- **THEN** it has rows "e min", "β" and "δ", and no row named "eMin", "beta" or "delta"

### Requirement: Value formatting
Numbers SHALL be shown as published with a decimal point and no thousands separator. An angle given as a number of degrees SHALL be shown as `40°`; an angle given as degrees, minutes and seconds SHALL be shown as `39°59'49"`. Zero is a value and SHALL be shown.

#### Scenario: Plain numbers
- **WHEN** the tables of "243 Win." are shown
- **THEN** Pmax is "4150" and L3 is "51.94", with no thousands separator

#### Scenario: Angles
- **WHEN** the tables of "6,5 x 55 SE" are shown
- **THEN** α of the cartridge is `50°35'2"` and β is `45°`
- **AND** the rifling angle i of "6,5 x 55 SE" is `0°42'29"`

#### Scenario: Zero
- **WHEN** the tables of "22 Long Rifle" are shown
- **THEN** β is `0°` and δ is `0°`

### Requirement: Tolerances next to their value
A field `<X>Tol` SHALL be shown next to the value of X in the same cell and SHALL NOT have a row of its own.

#### Scenario: Tolerance
- **WHEN** the lengths table of "308 Win." is shown
- **THEN** the row "L1" reads "39.62 -0.2" and there is no row "L1Tol"

### Requirement: Navigation and print controls
The detail view SHALL offer a button "Print" that opens the browser's print dialog and a link "All cartridges" that returns to the list.

#### Scenario: Back to list
- **WHEN** the user activates "All cartridges"
- **THEN** the start page is shown with its previous search text and family selection

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** the browser's print dialog is requested
