# Spec Delta

## Purpose

Defines how the app is delivered and how it looks and behaves in the browser: plain files, offline, themed, accessible and usable on a phone.

## ADDED Requirements

### Requirement: Plain static files
The app SHALL consist of `index.html` in the project root with its CSS and JavaScript files, using no framework, no build step, no server code and no runtime dependencies. Development tools MAY exist as npm dev dependencies.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened directly from disk in Chromium via `file://`
- **THEN** the list, search, filter, detail views, reload of a detail view and drawings all work

#### Scenario: Served statically
- **WHEN** the project folder is served by any static file server
- **THEN** the app works identically

### Requirement: No network requests
The app SHALL NOT request anything over the network: no CDNs, web fonts, analytics or data fetches. All data SHALL ship with the app. Following a water-capacity source link is the only network use and is initiated by the user.

#### Scenario: Request log
- **WHEN** the start page and a detail view are loaded
- **THEN** the only requests are for the local app files

### Requirement: Data fidelity
The 25 supplied records SHALL be used unchanged; the app SHALL NOT add, alter or fetch data.

#### Scenario: Bundled data equals supplied records
- **WHEN** the bundled data is compared with the supplied records
- **THEN** all 25 records are present and deeply equal

### Requirement: Light and dark appearance
On screen the app SHALL follow the system colour scheme (light or dark) with sufficient contrast, using calm, dense typography with tabular numbers. Print SHALL always be light.

#### Scenario: Dark system setting
- **WHEN** the system prefers a dark colour scheme
- **THEN** the page and the drawing use dark backgrounds with light strokes and text

### Requirement: Usable on a phone
The layout SHALL work at a 360 px wide viewport without horizontal page scrolling; the drawing SHALL scale to the available width.

#### Scenario: Narrow viewport
- **WHEN** the list and a detail view are shown at 360 px width
- **THEN** the document does not scroll horizontally and the drawing fits the width

### Requirement: Accessibility baseline
Interactive controls SHALL have accessible names, be keyboard operable, show a visible focus indicator, and moving between views SHALL move focus to the new view's heading. The drawing SHALL have the accessible name "<name> drawing".

#### Scenario: Drawing name
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** an image role named "223 Rem. drawing" exists
