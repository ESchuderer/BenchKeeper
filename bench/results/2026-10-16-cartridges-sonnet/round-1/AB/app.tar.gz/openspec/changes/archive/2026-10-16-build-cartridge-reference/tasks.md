# Tasks

## 1. Project scaffold and data

- [x] 1.1 Add `package.json` (dev dependency `playwright` only), `.gitignore`, `scripts/build-data.js`; verify `npm run build:data` writes `js/data.js` and a unit test proves it deep-equals `data/cartridges.jsonl` (25 records, keys unique)
- [x] 1.2 Make every browser module `require`-able in Node (UMD wrapper, no helper needed); verify `npm test` runs and the data test passes

## 2. Formatting and symbols (cartridge-detail)

- [x] 2.1 Write unit tests for number, angle (degrees and D°M'S"), tolerance, symbol and unit formatting and for the table model of every record (each non-tolerance field in exactly one row), then implement `js/format.js`; verify tests pass
- [x] 2.2 Write unit tests for water capacity/metadata model, then implement it in `js/format.js`; verify tests pass

## 3. Catalog filtering (cartridge-catalog)

- [x] 3.1 Write unit tests for search (name, alternative names, case, whitespace, comma/point), family filter, combination and counts, then implement `js/catalog.js`; verify tests pass

## 4. Geometry (cartridge-drawing)

- [x] 4.1 Write unit tests for rim type, head/chamfer/half-round, groove, belt, body, straight case, shoulder with fillets (values from the spec scenarios), then implement the outer profile in `js/geometry.js`; verify tests pass
- [x] 4.2 Write unit tests for walls, `w`, primer pocket, inner profile and section polygon, then implement; verify tests pass
- [x] 4.3 Write unit tests for bullet (seating, k, meplat, ogive radius, ellipse, cones, heeled) and for missing-value notes, then implement; verify tests pass, and all 25 records produce a closed, finite, non-self-overlapping geometry

## 5. Drawing layout and SVG (cartridge-drawing)

- [x] 5.1 Write unit tests for dimension features (published-only labels, `L3 51.18` text, angle labels), label placement without overlap for all 25 records, scale/viewBox rules and title block, then implement `js/drawing.js`; verify tests pass
- [x] 5.2 Render all 25 drawings to PNG with Chromium and inspect them (outline, section, bullet, labels, α); fix defects found; verify visually and keep a contact-sheet script under `scripts/`

## 6. App shell, list, detail, styles (cartridge-catalog, cartridge-detail, static-delivery)

- [x] 6.1 Write Playwright tests (file://) for the start page: list, search, family, count, special-character names; then implement `index.html`, `js/app.js`, `css/style.css` list view; verify tests pass
- [x] 6.2 Write Playwright tests for the detail view: routing/reload/unknown key, metadata, tables, tolerances, angles, symbols, units, Print button, All cartridges (state kept), focus; then implement; verify tests pass
- [x] 6.3 Write Playwright tests for no network requests, dark scheme, 360 px viewport without horizontal scroll, accessible names, keyboard focus; then implement the CSS; verify tests pass

## 7. Print (cartridge-print)

- [x] 7.1 Write Playwright tests: one-page A4 PDF for all 25, print hides controls, light colours in dark mode, footer text, 190 mm drawing, label ≥ 6 pt; then implement print CSS; verify tests pass

## 8. Integration, review and docs

- [x] 8.1 Real-DOM overlap test over all 25 drawings (getBBox of labels vs each other and vs outline sampled paths); verify passes
- [x] 8.2 Write `README.md` (what it is, how to open, how to test, geometry assumptions pointing to design.md); verify the documented commands run
- [x] 8.3 Run the full suite (`npm run test:all`), `openspec validate --strict`, code review of the diff, fix findings; verify all green

## Workflow follow-up

- Commit the work; archive the change with `openspec archive` once review is clean.
