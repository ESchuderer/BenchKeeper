# cartridge-catalog Specification

## Purpose
The start page of the reference: lists every cartridge and lets the reader narrow the list by text and by family before opening a detail view.

## Requirements

### Requirement: Start page lists all cartridges
The start page SHALL show the heading "Cartridges" and, for each of the 25 records, its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name` and which opens that cartridge's detail view.

#### Scenario: Initial list
- **WHEN** the start page is opened
- **THEN** 25 cartridge links are shown, one per record, with text equal to each `name` (for example "6,5 Creedmoor" and "40 S.& W.")
- **AND** each row shows the family and L3 as published, for example "51.18 mm" for "308 Win."

### Requirement: Text search
A field labelled "Search" SHALL filter the list as the user types, matching case-insensitively against the name and all alternative names.

#### Scenario: Alternative name
- **WHEN** the user types "7,62 x 51" into "Search"
- **THEN** only "308 Win." is listed

#### Scenario: Name substring
- **WHEN** the user types "mag" into "Search"
- **THEN** every cartridge whose name or alternative name contains "mag" is listed and no others

#### Scenario: Surrounding whitespace and case
- **WHEN** the user types "  CREEDMOOR " into "Search"
- **THEN** "6,5 Creedmoor" is listed

### Requirement: Family filter
A select labelled "Family" SHALL offer the options All, rimless, rimmed, belted, pistol and rimfire, and restrict the list to the chosen family. It SHALL combine with the search text.

#### Scenario: Filter by family
- **WHEN** the user selects "belted"
- **THEN** exactly "300 Win. Mag." and "7 mm Rem. Mag." are listed

#### Scenario: Search and family together
- **WHEN** the user selects "pistol" and types "mag"
- **THEN** only "357 Magnum" and "44 Rem. Mag." are listed

### Requirement: Result count
The page SHALL show the text "<n> cartridges", where n is the number of cartridges currently listed, and SHALL say so explicitly when nothing matches.

#### Scenario: Count follows the filters
- **WHEN** the page is first shown
- **THEN** it reads "25 cartridges"
- **AND WHEN** the family "rimfire" is selected, it reads "3 cartridges"

#### Scenario: No match
- **WHEN** the search matches nothing
- **THEN** the count reads "0 cartridges" and a message states that no cartridge matches

### Requirement: Names are shown as published
Names SHALL be displayed exactly as in the record, including commas, ampersands and punctuation, and SHALL never be interpreted as markup.

#### Scenario: Special characters
- **WHEN** the list is shown
- **THEN** the link for key `40_s_w` reads "40 S.& W." and the link for key `6_5_creedmoor` reads "6,5 Creedmoor"
