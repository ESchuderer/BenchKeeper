# cartridge-drawing Specification

## Purpose
The 2D drawing of a cartridge, computed from its record: true-scale outline and section, bullet, dimension lines, title block, and an honest list of anything that could not be drawn.

## Requirements

### Requirement: Inline SVG with accessible name and true scale
The drawing SHALL be an inline SVG with the accessible name "<name> drawing". One SVG user unit SHALL equal 1 mm, the axis SHALL be horizontal and the head on the left. It SHALL scale to the width of its container, and all coordinates SHALL derive from the record's values only.

#### Scenario: Units and orientation
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** the SVG has role img and name "308 Win. drawing"
- **AND** the head face lies at the smallest z, the case mouth lies 51.18 units to its right, and the bullet tip lies 71.12 units to the right of the head face

#### Scenario: Scales to phone width
- **WHEN** the viewport is 360 px wide
- **THEN** the drawing's rendered width does not exceed the container width

### Requirement: Outside view above, section below
The upper half of the drawing SHALL be the outside view and the lower half a section with cut walls hatched. A dash-dot centre line SHALL mark the axis. The outer half-profile SHALL be mirrored at the axis.

#### Scenario: Hatched walls
- **WHEN** the drawing of "223 Rem." is rendered
- **THEN** the lower half has hatched case walls and head, the upper half has none
- **AND** the centre line has a dash-dot style

### Requirement: Rim type
The rim type SHALL be belted for family belted, rimfire for family rimfire, otherwise rimmed when R1/P1 >= 1.05, rebated when R1/P1 < 0.98 and rimless in all other cases.

#### Scenario: Classification
- **WHEN** the drawings of "223 Rem.", "7 x 65 R", "300 Win. Mag." and "22 Long Rifle" are rendered
- **THEN** their rim types are rimless, rimmed, belted and rimfire

### Requirement: Head face and rim edge
Where beta and f are published and beta is below 90°, the head face SHALL have a chamfer from (R1/2 − min(f·tan β, R1/4), 0) to (R1/2, f) in (r, z), continuing to (R1/2, R). Rimfire cases SHALL have a half-round rim edge of radius min(R/2, (R1 − P1)/2) whose outermost point lies at R1/2. Otherwise the corner SHALL be square.

#### Scenario: Chamfer
- **WHEN** the profile of "223 Rem." is computed
- **THEN** it starts at the axis at z = 0, reaches r = 4.8 − 0.315 = 4.485 at z = 0 and reaches (4.8, 0.45)

#### Scenario: Rimfire half-round
- **WHEN** the profile of "22 Long Rifle" is computed
- **THEN** the rim edge is a half-round of radius 0.545 whose outermost point is at r = 3.53

### Requirement: Extractor groove and belt
Where E and E1 are published, the profile SHALL run from (R1/2, R) in to (E1/2, R), along the floor to (E1/2, R + e min), then as a straight ramp out to (P1/2, E). On belted cases the ramp SHALL rise at angle δ to the axis up to the belt R3/2, follow the belt to z = E, then step in to P1/2. Without a groove the profile SHALL step in from (R1/2, R) to (P1/2, R).

#### Scenario: Groove of 223 Rem.
- **WHEN** the profile of "223 Rem." is computed
- **THEN** it contains the points (4.215, 1.14), (4.215, 1.9) and (4.79, 3.13) in (r, z)

#### Scenario: Belt of 300 Win. Mag.
- **WHEN** the profile of "300 Win. Mag." is computed
- **THEN** it follows the belt at r = 6.755 until z = 5.59, then steps in to r = 6.515

#### Scenario: Rimmed case without groove
- **WHEN** the profile of "7 x 65 R" is computed
- **THEN** it steps in from r = 6.66 to r = 5.945 at z = 1.4

### Requirement: Body, shoulder and neck
The body SHALL run in a straight line from P1/2 at the body start to (P2/2, L1) on a bottleneck case. A case without alpha, L1 or L2 SHALL be straight, its body running to (H2/2, L3). The shoulder SHALL join (P2/2, L1) to (H1/2, L2) with α as the included cone angle, rounded with r1 min on the body side and r2 on the neck side where published. The neck SHALL run from (H1/2, L2) to (H2/2, L3), followed by the mouth face.

#### Scenario: Bottleneck
- **WHEN** the model of "308 Win." is computed
- **THEN** its shoulder runs from (P2/2, L1) = (5.765, 39.62) to (H1/2, L2) = (4.36, 43.48) in (r, z), the outline is rounded at both corners (r1 min 0.76, r2 3.18) and ends at (4.36, 51.18)

#### Scenario: Unrounded corner
- **WHEN** the profile of "338 Lapua Mag." (no r1 min) is computed
- **THEN** it passes exactly through the body-side shoulder corner (6.91, 54.9) and is rounded at the neck-side corner only

#### Scenario: Straight case
- **WHEN** the profile of "9 mm Luger" is computed
- **THEN** it ends at (4.825, 19.15) and has no shoulder points

### Requirement: Bullet
The bullet SHALL be drawn from the mouth to the tip at z = L6 with shank diameter G1 and the nose shape of `annotations.defaultBulletShape` (pointy tangent ogive, rounded quarter ellipse, flat cone, semi-wadcutter cone), using the seating depth, cylinder fraction and meplat diameter of the brief. The outside view SHALL hide the seated part; the section SHALL show it inside the case.

#### Scenario: Pointy ogive
- **WHEN** the bullet of "308 Win." is computed
- **THEN** the seating depth is 7.85, the base lies at z = 43.33, the cylinder ends at z = 43.33 + 0.40·27.79, and the meplat diameter is 1.27
- **AND** the ogive radius equals ((G1/2 − m/2)² + n²) / (2·(G1/2 − m/2)) with n the nose length

#### Scenario: Pistol seating
- **WHEN** the bullet of "9 mm Luger" (rounded, pistol) is computed
- **THEN** the seating depth is 0.4·9.03

#### Scenario: Seated part
- **WHEN** the outside view and the section of "308 Win." are rendered
- **THEN** the outside view shows the bullet only from the mouth outward and the section shows it from its base inside the case

### Requirement: Heeled bullet
For a heeled case (H2 − G1 <= 0.015) the exposed bullet SHALL have the case's outside diameter and the seated heel the case's inside diameter H2 − 2·tb.

#### Scenario: Heeled bullet
- **WHEN** the section of "22 Long Rifle" is computed
- **THEN** the seated heel has diameter 5.72 − 2·0.6 = 4.52 and the exposed bullet diameter 5.72

### Requirement: Section walls
The neck wall SHALL be tn = (H2 − G1)/2 and the body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2); the inner line SHALL follow the outer line at these walls, blended linearly across the shoulder.

#### Scenario: Walls of 223 Rem.
- **WHEN** the section of "223 Rem." is computed
- **THEN** tn = 0.365 and tb = 0.6

### Requirement: Solid head
The solid head SHALL run from the head face to z = w with w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or the belt ramp end + tb on belted cases).

#### Scenario: Head of 223 Rem.
- **WHEN** the section of "223 Rem." is computed
- **THEN** w = 4.54

### Requirement: Primer pocket
Centrefire cases SHALL show a primer pocket of diameter 4.45 (sp, spm, sr) or 5.33 (lp, lpm, lr, lrm) and depth 3.04 (sp, spm, sr, lp, lpm) or 3.3 (lr, lrm). Rimfire cases SHALL have no pocket.

#### Scenario: Pocket sizes
- **WHEN** the sections of "308 Win." (lr) and "9 mm Luger" (sp) are computed
- **THEN** pockets are 5.33 × 3.3 and 4.45 × 3.04; "22 Long Rifle" has none

### Requirement: Dimension lines and labels
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value, for example `L3 51.18`, and labels SHALL NOT overlap each other or the outline.

#### Scenario: Labels of 308 Win.
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** it contains the labels `L3 51.18`, `L6 71.12`, `R1 12.01`, `R 1.37`, `P1 11.96`, `P2 11.53`, `H1 8.72`, `H2 8.72`, `G1 7.85`, `L1 39.62`, `L2 43.48`, `E1 10.39` and an angle label for α of 40°

#### Scenario: Published values only
- **WHEN** the drawing of "9 mm Luger" is rendered
- **THEN** it has no label for P2, H1, L1, L2 or α

#### Scenario: No overlaps in any record
- **WHEN** the drawings of all 25 records are rendered in Chromium
- **THEN** no two label boxes intersect, and no label box intersects the case or bullet outline

### Requirement: Title block and scale
The drawing SHALL include a title block with the name, C.I.P. table and revision date, the text "Dimensions in mm", and the scale at which the drawing prints on A4.

#### Scenario: Title block
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** the title block shows "308 Win.", table I, revised 2008-09-23, "Dimensions in mm" and a scale such as "Scale 1.5 : 1"
- **AND** printing at the full A4 content width yields exactly that scale

### Requirement: Missing values are reported
If a value that a rule needs is missing, the drawing SHALL be made without that feature, SHALL name the missing value in a note beneath the drawing, and SHALL NOT invent a number.

#### Scenario: Missing rim values
- **WHEN** the drawing of "9,3 x 74 R" is rendered
- **THEN** no extractor groove is drawn and the note names E and E1 as not published

#### Scenario: Missing corner radii
- **WHEN** the drawing of "338 Lapua Mag." is rendered
- **THEN** the shoulder body corner is not rounded and the note names r1 min

#### Scenario: Complete record
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** no note about missing values is shown
