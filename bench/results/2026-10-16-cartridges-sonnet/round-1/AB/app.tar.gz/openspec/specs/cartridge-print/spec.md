# cartridge-print Specification

## Purpose
Makes every detail view printable as a compact, legible one-page A4 data sheet.

## Requirements

### Requirement: One A4 portrait page
A printed detail view SHALL fit on exactly one A4 portrait page, black on white, regardless of the user's colour scheme. Its order SHALL be: page header with the name, the metadata, the drawing at full content width with every label legible, then the value tables, then a footer.

#### Scenario: Page count
- **WHEN** the detail view of any of the 25 cartridges is printed to PDF in A4 portrait
- **THEN** the PDF has exactly one page

#### Scenario: Light output in dark mode
- **WHEN** a detail view is printed while the system prefers dark
- **THEN** the print rendering has a white background and black text

### Requirement: Print hides interaction
Navigation, search, filters and buttons SHALL NOT appear in print.

#### Scenario: Hidden controls
- **WHEN** a detail view is rendered with print media
- **THEN** the "Print" button and the "All cartridges" link are not displayed

### Requirement: Source footer
The printed page SHALL end with a footer that states the source "C.I.P. TDCC" and the cartridge's revised date.

#### Scenario: Footer text
- **WHEN** "223 Rem." is printed
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2017-05-17"

### Requirement: Legible drawing in print
In print the drawing SHALL span the full 190 mm content width and every label SHALL be at least 6 pt tall.

#### Scenario: Label size
- **WHEN** any drawing is rendered with print media
- **THEN** the drawing is 190 mm wide and its label font size is at least 6 pt
