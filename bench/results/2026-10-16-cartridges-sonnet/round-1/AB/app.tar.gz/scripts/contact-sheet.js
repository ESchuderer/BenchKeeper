#!/usr/bin/env node
// Dev tool: after scripts/render-drawings.js, builds sheetN.png contact sheets (4 drawings each).
'use strict';
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

(async () => {
  const dir = path.resolve(process.argv[2] || path.join(__dirname, '..', 'test-output', 'drawings'));
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.png') && !f.startsWith('sheet')).sort();
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 2000, height: 1400 } });
  for (let g = 0; g * 4 < files.length; g++) {
    const part = files.slice(g * 4, g * 4 + 4);
    const html = '<body style="margin:0;display:grid;grid-template-columns:1fr 1fr;gap:4px;background:#888">' +
      part.map((f) => `<div style="background:#fff"><div style="font:14px sans-serif">${f}</div><img src="file://${dir}/${f}" style="width:100%"></div>`).join('') + '</body>';
    fs.writeFileSync(path.join(dir, 'sheet.html'), html);
    await page.goto('file://' + path.join(dir, 'sheet.html'));
    await page.screenshot({ path: path.join(dir, `sheet${g}.png`), fullPage: true });
  }
  await browser.close();
})();
