#!/usr/bin/env node
// Dev tool: renders every drawing to PNG with Chromium (Playwright) for visual inspection.
// Usage: node scripts/render-drawings.js [outDir] [key ...]
'use strict';
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');
const data = require('../js/data.js');
const D = require('../js/drawing.js');

(async () => {
  const out = path.resolve(process.argv[2] || path.join(__dirname, '..', 'test-output', 'drawings'));
  const only = process.argv.slice(3);
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1100, height: 700 }, deviceScaleFactor: 2 });
  for (const r of data) {
    if (only.length && !only.includes(r.key)) continue;
    const { svg } = D.render(r);
    await page.setContent(`<!doctype html><html><body style="margin:0;background:#fff"><div id="d" style="width:1000px;padding:10px">${svg}</div></body></html>`);
    await page.locator('#d').screenshot({ path: path.join(out, r.key + '.png') });
  }
  await browser.close();
  console.log('wrote drawings to', out);
})();
