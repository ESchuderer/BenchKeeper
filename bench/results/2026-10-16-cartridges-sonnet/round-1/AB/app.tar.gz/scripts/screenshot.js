#!/usr/bin/env node
// Dev tool: screenshots of the app. Usage: node scripts/screenshot.js <hash> <out.png> [width] [light|dark]
'use strict';
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require('playwright');
(async () => {
  const [hash = '', out = 'test-output/shot.png', width = '1200', scheme = 'light'] = process.argv.slice(2);
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: +width, height: 900 }, colorScheme: scheme });
  const page = await ctx.newPage();
  await page.goto(pathToFileURL(path.join(__dirname, '..', 'index.html')).href + hash);
  await page.waitForSelector('h1');
  await page.screenshot({ path: out, fullPage: true });
  await browser.close();
})();
