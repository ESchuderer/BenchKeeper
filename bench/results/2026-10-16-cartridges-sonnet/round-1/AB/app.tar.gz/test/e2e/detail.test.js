'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, open, data, INDEX } = require('./helpers');

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

const table = (page, group, section) => page.locator(`table[data-group="${group}"][data-section="${section}"]`);
const rowOf = (page, group, section, symbol) =>
  table(page, group, section).locator('tbody tr').filter({ has: page.locator('th, td').first().getByText(symbol, { exact: true }) });
const cellsOf = async (row) => (await row.locator('th, td').allTextContents()).map((s) => s.trim());

test('following a link opens the detail view with its own address', async () => {
  const { page, context } = await open(browser);
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '308 Win.', exact: true }).waitFor();
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '308 Win.');
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  await context.close();
});

test('detail address survives a reload and works when opened directly', async () => {
  const { page, context } = await open(browser, '#/cartridge/308_win');
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '308 Win.');
  await page.reload();
  await page.waitForSelector('h1');
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '308 Win.');
  await context.close();
});

test('unknown key: not found + link back', async () => {
  const { page, context } = await open(browser, '#/cartridge/nope');
  assert.match(await page.locator('main').textContent(), /not found/i);
  await page.getByRole('link', { name: 'All cartridges', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: 'Cartridges', exact: true }).waitFor();
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges');
  await context.close();
});

test('metadata of 308 Win.', async () => {
  const { page, context } = await open(browser, '#/cartridge/308_win');
  const get = async (label) => (await page.locator('dl.meta dt', { hasText: new RegExp('^' + label.replace(/\./g, '\\.') + '$') }).locator('xpath=following-sibling::dd[1]').textContent()).trim();
  assert.equal(await get('Alternative names'), '308 Winchester, 7,62 x 51');
  assert.equal(await get('Family'), 'rimless');
  assert.equal(await get('Category'), 'rifle');
  assert.equal(await get('Primer type'), 'lr');
  assert.equal(await get('C.I.P. table'), 'I');
  assert.equal(await get('Country'), 'US');
  assert.equal(await get('Published'), '1984-06-14');
  assert.equal(await get('Revised'), '2008-09-23');
  assert.equal(await get('Pressure method'), 'Transducer');
  assert.match(await get('Water capacity'), /^56 gr H2O/);
  const link = page.locator('dl.meta').getByRole('link', { name: 'kwk' });
  assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
  await context.close();
});

test('no published capacity: said so, no link', async () => {
  const { page, context } = await open(browser, '#/cartridge/7_x_64');
  const dd = page.locator('dl.meta dt', { hasText: 'Water capacity' }).locator('xpath=following-sibling::dd[1]');
  assert.equal((await dd.textContent()).trim(), 'not published');
  assert.equal(await dd.locator('a').count(), 0);
  await context.close();
});

test('tables: sections, columns, values, tolerance, angle formats, symbols, units', async () => {
  const { page, context } = await open(browser, '#/cartridge/6_5_x_55_se');
  const headers = await table(page, 'cartridge', 'lengths').locator('thead th').allTextContents();
  assert.deepEqual(headers.map((s) => s.trim()), ['Symbol', 'Value', 'Unit']);
  assert.deepEqual(await cellsOf(rowOf(page, 'cartridge', 'lengths', 'L1')), ['L1', '43.49 -0.2', 'mm']);
  assert.deepEqual(await cellsOf(rowOf(page, 'cartridge', 'junctionCone', 'α')), ['α', '50°35\'2"', '°']);
  assert.deepEqual(await cellsOf(rowOf(page, 'cartridge', 'caseHead', 'β')), ['β', '45°', '°']);
  assert.deepEqual(await cellsOf(rowOf(page, 'cartridge', 'pressures', 'Pmax')), ['Pmax', '3800', 'bar']);
  assert.deepEqual(await cellsOf(rowOf(page, 'cartridge', 'pressures', 'EE')), ['EE', '3395', 'J']);
  assert.deepEqual(await cellsOf(rowOf(page, 'chamber', 'rifling', 'i')), ['i', '0°42\'29"', '°']);
  assert.deepEqual(await cellsOf(rowOf(page, 'chamber', 'grooves', 'N')), ['N', '4', '']);
  assert.deepEqual(await cellsOf(rowOf(page, 'chamber', 'grooves', 'Q')), ['Q', '34.36', 'mm²']);
  assert.equal(await page.locator('tbody th, tbody td', { hasText: /Tol$/ }).count(), 0);
  assert.equal(await rowOf(page, 'cartridge', 'caseHead', 'e min').count(), 1);
  assert.equal(await rowOf(page, 'cartridge', 'junctionCone', 'r1 min').count(), 1);
  assert.equal(await rowOf(page, 'chamber', 'junctionCone', 'r1 max').count(), 1);
  await context.close();
});

test('every record: all non-tolerance fields shown once', async () => {
  const { page, context } = await open(browser);
  for (const r of data) {
    await page.goto(INDEX + '#/cartridge/' + r.key);
    await page.waitForSelector('h1');
    for (const group of ['cartridge', 'chamber']) {
      let expected = 0;
      for (const fields of Object.values(r[group])) expected += Object.keys(fields).filter((f) => !/Tol$/.test(f)).length;
      assert.equal(await page.locator(`table[data-group="${group}"] tbody tr`).count(), expected, `${r.key} ${group}`);
    }
  }
  await context.close();
});

test('zero is shown (22 Long Rifle)', async () => {
  const { page, context } = await open(browser, '#/cartridge/22_long_rifle');
  assert.deepEqual(await cellsOf(rowOf(page, 'cartridge', 'caseHead', 'β')), ['β', '0°', '°']);
  assert.deepEqual(await cellsOf(rowOf(page, 'cartridge', 'caseHead', 'δ')), ['δ', '0°', '°']);
  await context.close();
});

test('Print button requests the print dialog; All cartridges keeps search and family', async () => {
  const { page, context } = await open(browser);
  await page.getByLabel('Search').fill('mag');
  await page.getByLabel('Family').selectOption({ label: 'pistol' });
  await page.getByRole('link', { name: '44 Rem. Mag.', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '44 Rem. Mag.', exact: true }).waitFor();
  await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.getByRole('button', { name: 'Print', exact: true }).click();
  assert.equal(await page.evaluate(() => window.__printed), 1);
  await page.getByRole('link', { name: 'All cartridges', exact: true }).click();
  await page.getByLabel('Search').waitFor();
  assert.equal(await page.getByLabel('Search').inputValue(), 'mag');
  assert.equal(await page.getByLabel('Family').inputValue(), 'pistol');
  assert.deepEqual(await page.locator('table.list tbody a').allTextContents(), ['357 Magnum', '44 Rem. Mag.']);
  await context.close();
});

test('browser back returns to the list', async () => {
  const { page, context } = await open(browser);
  await page.getByRole('link', { name: '223 Rem.', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '223 Rem.', exact: true }).waitFor();
  await page.goBack();
  await page.getByRole('heading', { level: 1, name: 'Cartridges', exact: true }).waitFor();
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges');
  await context.close();
});

test('focus moves to the heading of the new view', async () => {
  const { page, context } = await open(browser);
  await page.getByRole('link', { name: '223 Rem.', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '223 Rem.', exact: true }).waitFor();
  assert.equal(await page.evaluate(() => document.activeElement.tagName), 'H1');
  await context.close();
});

test('drawing has the accessible name "<name> drawing"; name with ampersand', async () => {
  const { page, context } = await open(browser, '#/cartridge/40_s_w');
  assert.equal(await page.getByRole('img', { name: '40 S.& W. drawing', exact: true }).count(), 1);
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '40 S.& W.');
  await context.close();
});

test('missing values are listed beneath the drawing', async () => {
  const { page, context } = await open(browser, '#/cartridge/9_3_x_74_r');
  assert.match(await page.locator('.drawing-notes').textContent(), /E, E1, e min not published/);
  await page.goto(INDEX + '#/cartridge/308_win');
  await page.waitForSelector('h1');
  assert.equal(await page.locator('.drawing-notes').count(), 0);
  await context.close();
});
