'use strict';
// Overlap and scale checks on the real rendered SVG (real fonts, real getBBox).
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, open, data, INDEX } = require('./helpers');

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

test('real label boxes: no overlap with each other or with the outline (all 25)', async () => {
  const { page, context } = await open(browser);
  for (const r of data) {
    await page.goto(INDEX + '#/cartridge/' + r.key);
    await page.getByRole('heading', { level: 1, name: r.name, exact: true }).waitFor();
    const res = await page.evaluate(() => {
      const svg = document.querySelector('.drawing svg');
      const boxes = [...svg.querySelectorAll('text.dim-label')].map((t) => {
        const b = t.getBBox();
        return { text: t.textContent, x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height };
      });
      const problems = [];
      for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
        const a = boxes[i], b = boxes[j];
        if (a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1) problems.push(`"${a.text}" overlaps "${b.text}"`);
      }
      for (const p of svg.querySelectorAll('path.outline')) {
        const len = p.getTotalLength();
        for (let s = 0; s <= len; s += 0.1) {
          const pt = p.getPointAtLength(s);
          for (const b of boxes) if (pt.x > b.x0 && pt.x < b.x1 && pt.y > b.y0 && pt.y < b.y1) problems.push(`"${b.text}" touches ${p.dataset.part}`);
        }
      }
      const vb = svg.viewBox.baseVal;
      for (const b of boxes) if (b.x0 < vb.x || b.x1 > vb.x + vb.width || b.y0 < vb.y || b.y1 > vb.y + vb.height) problems.push(`"${b.text}" outside viewBox`);
      return { n: boxes.length, problems: [...new Set(problems)] };
    });
    assert.ok(res.n >= 7, `${r.key}: ${res.n} labels`);
    assert.deepEqual(res.problems, [], r.key);
  }
  await context.close();
});

test('real SVG is true to scale: head face at 0, mouth at L3, tip at L6; section hatched below only', async () => {
  const { page, context } = await open(browser);
  for (const r of data) {
    await page.goto(INDEX + '#/cartridge/' + r.key);
    await page.getByRole('heading', { level: 1, name: r.name, exact: true }).waitFor();
    const m = await page.evaluate(() => {
      const svg = document.querySelector('.drawing svg');
      const box = (sel) => { const e = svg.querySelector(sel); const b = e.getBBox(); return { x0: b.x, x1: b.x + b.width, y0: b.y, y1: b.y + b.height }; };
      const cu = box('[data-part="case-outline-upper"]'), bu = box('[data-part="bullet-outline-upper"]');
      const cl = box('[data-part="case-outline-lower"]'), bl = box('[data-part="bullet-outline-lower"]');
      return {
        cu, bu, cl, bl,
        hatchLower: !!svg.querySelector('[data-view="section"] [data-part="case-hatch"]'),
        hatchUpper: !!svg.querySelector('[data-view="outside"] [fill*="hatch"]'),
        dash: svg.querySelector('[data-part="centre-line"]').getAttribute('stroke-dasharray').split(' ').length,
        axisY: svg.querySelector('[data-part="centre-line"]').getBBox().y
      };
    });
    const L3 = r.cartridge.lengths.L3, L6 = r.cartridge.lengths.L6;
    const near = (a, b, msg) => assert.ok(Math.abs(a - b) < 0.02, `${r.key} ${msg}: ${a} vs ${b}`);
    near(m.cu.x0, 0, 'head face');
    near(m.cu.x1, L3, 'mouth');
    near(m.bu.x1, L6, 'tip');
    near(m.cu.y0, -m.cl.y1, 'mirror (case)');
    near(m.bu.y0, -m.bl.y1, 'mirror (bullet)');
    assert.ok(m.cu.y1 <= 0.001 && m.cl.y0 >= -0.001, 'halves on their own side of the axis');
    assert.ok(m.hatchLower && !m.hatchUpper, r.key);
    assert.equal(m.dash, 4, 'dash-dot pattern');
  }
  await context.close();
});
