'use strict';
// Shared Playwright helpers. The app is always opened from disk (file://), the
// hardest case: no server, no fetch of local files, no ES modules.
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');

const ROOT = path.join(__dirname, '..', '..');
const INDEX = pathToFileURL(path.join(ROOT, 'index.html')).href;
const data = require('../../js/data.js');

async function launch() {
  return chromium.launch();
}

// context options: { viewport, colorScheme }
async function open(browser, hash = '', opts = {}) {
  const context = await browser.newContext(opts);
  const page = await context.newPage();
  const requests = [];
  const errors = [];
  page.on('request', (r) => requests.push(r.url()));
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(INDEX + hash);
  await page.waitForSelector('h1');
  return { page, context, requests, errors };
}

module.exports = { ROOT, INDEX, data, launch, open };
