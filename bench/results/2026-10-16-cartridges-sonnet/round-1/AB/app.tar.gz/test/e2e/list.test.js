'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, open, data } = require('./helpers');

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

const names = (page) => page.locator('table.list tbody a').allTextContents();

test('start page: heading, 25 links with exact names, count', async () => {
  const { page, context, errors } = await open(browser);
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges');
  assert.deepEqual(await names(page), data.map((r) => r.name));
  assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
  assert.deepEqual(errors, []);
  await context.close();
});

test('each row shows family and L3', async () => {
  const { page, context } = await open(browser);
  const row = page.locator('table.list tbody tr', { has: page.getByRole('link', { name: '308 Win.', exact: true }) });
  const cells = await row.locator('td').allTextContents();
  assert.deepEqual(cells.map((c) => c.trim()), ['308 Win.', 'rimless', '51.18 mm']);
  await context.close();
});

test('special characters are shown as published, not as markup', async () => {
  const { page, context } = await open(browser);
  assert.equal(await page.getByRole('link', { name: '40 S.& W.', exact: true }).count(), 1);
  assert.equal(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).count(), 1);
  await context.close();
});

test('search by alternative name', async () => {
  const { page, context } = await open(browser);
  await page.getByLabel('Search').fill('7,62 x 51');
  assert.deepEqual(await names(page), ['308 Win.']);
  assert.equal(await page.getByText('1 cartridges', { exact: true }).count(), 1);
  await context.close();
});

test('search filters as the user types (key by key)', async () => {
  const { page, context } = await open(browser);
  await page.getByLabel('Search').click();
  await page.keyboard.type('creed');
  assert.deepEqual(await names(page), ['6,5 Creedmoor']);
  await context.close();
});

test('family select has the listed options and filters', async () => {
  const { page, context } = await open(browser);
  const opts = await page.getByLabel('Family').locator('option').allTextContents();
  assert.deepEqual(opts, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  await page.getByLabel('Family').selectOption({ label: 'belted' });
  assert.deepEqual(await names(page), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(await page.getByText('2 cartridges', { exact: true }).count(), 1);
  await page.getByLabel('Family').selectOption({ label: 'rimfire' });
  assert.equal(await page.getByText('3 cartridges', { exact: true }).count(), 1);
  await page.getByLabel('Family').selectOption({ label: 'All' });
  assert.equal((await names(page)).length, 25);
  await context.close();
});

test('search and family combine; no match is announced', async () => {
  const { page, context } = await open(browser);
  await page.getByLabel('Family').selectOption({ label: 'pistol' });
  await page.getByLabel('Search').fill('mag');
  assert.deepEqual(await names(page), ['357 Magnum', '44 Rem. Mag.']);
  await page.getByLabel('Search').fill('zzzz');
  assert.deepEqual(await names(page), []);
  assert.equal(await page.getByText('0 cartridges', { exact: true }).count(), 1);
  assert.equal(await page.getByText(/no cartridge matches/i).count(), 1);
  await context.close();
});

test('the Search field keeps focus while typing', async () => {
  const { page, context } = await open(browser);
  await page.getByLabel('Search').click();
  await page.keyboard.type('2');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'search');
  await context.close();
});
