'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, open, data, INDEX } = require('./helpers');

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

test('no network: every request is a local file', async () => {
  const { page, context, requests, errors } = await open(browser);
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await page.waitForSelector('svg');
  assert.ok(requests.length >= 4);
  for (const u of requests) assert.ok(u.startsWith('file://'), u);
  assert.deepEqual(errors, []);
  await context.close();
});

test('only local files are referenced in the sources', async () => {
  const fs = require('node:fs');
  const html = fs.readFileSync(require('node:path').join(__dirname, '..', '..', 'index.html'), 'utf8');
  assert.ok(!/https?:\/\//.test(html.replace(/<!--[\s\S]*?-->/g, '')), 'no absolute URLs in index.html');
  const css = fs.readFileSync(require('node:path').join(__dirname, '..', '..', 'css', 'style.css'), 'utf8');
  assert.ok(!/url\(\s*['"]?https?:/.test(css) && !/@import/.test(css));
});

test('dark scheme: dark page, light text; light scheme: the opposite', async () => {
  const lum = (c) => { const m = c.match(/\d+(\.\d+)?/g).map(Number); return (0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2]) / 255; };
  const probe = async (scheme) => {
    const { page, context } = await open(browser, '#/cartridge/308_win', { colorScheme: scheme });
    const r = await page.evaluate(() => ({
      bg: getComputedStyle(document.body).backgroundColor,
      fg: getComputedStyle(document.body).color,
      caseFill: getComputedStyle(document.querySelector('[data-part="case-fill"]')).fill,
      ink: getComputedStyle(document.querySelector('svg')).color
    }));
    await context.close();
    return r;
  };
  const dark = await probe('dark'), light = await probe('light');
  assert.ok(lum(dark.bg) < 0.25 && lum(dark.fg) > 0.6, JSON.stringify(dark));
  assert.ok(lum(light.bg) > 0.85 && lum(light.fg) < 0.3, JSON.stringify(light));
  assert.ok(lum(dark.ink) > 0.6, 'drawing ink is light in dark mode');
  assert.ok(lum(light.ink) < 0.3);
  assert.notEqual(dark.caseFill, light.caseFill);
});

test('360 px viewport: no horizontal scroll, drawing fits', async () => {
  const { page, context } = await open(browser, '', { viewport: { width: 360, height: 740 } });
  const fits = () => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
  assert.ok(await fits(), 'list');
  await page.goto(INDEX + '#/cartridge/338_lapua_mag');
  await page.waitForSelector('svg');
  assert.ok(await fits(), 'detail');
  const w = await page.evaluate(() => document.querySelector('svg[role="img"]').getBoundingClientRect().width);
  assert.ok(w <= 360 && w > 250, 'svg width ' + w);
  for (const r of data) {
    await page.goto(INDEX + '#/cartridge/' + r.key);
    await page.waitForSelector('svg');
    assert.ok(await fits(), r.key);
  }
  await context.close();
});

test('keyboard: links and controls show a visible focus indicator', async () => {
  const { page, context } = await open(browser);
  await page.keyboard.press('Tab');
  await page.keyboard.press('Tab');
  await page.keyboard.press('Tab');
  const outline = await page.evaluate(() => {
    const s = getComputedStyle(document.activeElement);
    return { style: s.outlineStyle, width: parseFloat(s.outlineWidth), tag: document.activeElement.tagName };
  });
  assert.notEqual(outline.style, 'none');
  assert.ok(outline.width >= 2, JSON.stringify(outline));
  await context.close();
});

test('document language and viewport meta are set; title follows the view', async () => {
  const { page, context } = await open(browser);
  assert.equal(await page.evaluate(() => document.documentElement.lang), 'en');
  assert.ok(await page.locator('meta[name="viewport"]').count());
  assert.match(await page.title(), /Cartridges/);
  await page.getByRole('link', { name: '223 Rem.', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '223 Rem.', exact: true }).waitFor();
  assert.match(await page.title(), /223 Rem\./);
  await context.close();
});

test('works with a static file server too', async () => {
  const http = require('node:http'), fs = require('node:fs'), path = require('node:path');
  const root = path.join(__dirname, '..', '..');
  const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
  const srv = http.createServer((req, res) => {
    const f = path.join(root, req.url === '/' ? 'index.html' : decodeURIComponent(req.url.split('?')[0]));
    if (!f.startsWith(root) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream' });
    res.end(fs.readFileSync(f));
  }).listen(0);
  const port = srv.address().port;
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(`http://127.0.0.1:${port}/#/cartridge/223_rem`);
  await page.waitForSelector('h1');
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '223 Rem.');
  await context.close();
  srv.close();
});
