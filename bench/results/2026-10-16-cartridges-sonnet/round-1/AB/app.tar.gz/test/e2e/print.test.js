'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, open, data, INDEX } = require('./helpers');

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

const pageCount = (pdf) => (pdf.toString('latin1').match(/\/Type\s*\/Page(?![s\w])/g) || []).length;

test('every detail view prints on exactly one A4 portrait page (also in dark mode)', async () => {
  for (const scheme of ['light', 'dark']) {
    const { page, context } = await open(browser, '', { colorScheme: scheme });
    for (const r of data) {
      await page.goto(INDEX + '#/cartridge/' + r.key);
      await page.getByRole('heading', { level: 1, name: r.name, exact: true }).waitFor();
      await page.emulateMedia({ media: 'print' });
      const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: false });
      assert.equal(pageCount(pdf), 1, `${r.key} (${scheme}) pages`);
      const mb = pdf.toString('latin1').match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)/);
      assert.ok(mb, 'MediaBox');
      assert.ok(Math.abs(+mb[1] - 595.3) < 1.5 && Math.abs(+mb[2] - 841.9) < 1.5, `A4 portrait, got ${mb[1]}x${mb[2]}`);
      await page.emulateMedia({ media: 'screen' });
    }
    await context.close();
  }
});

test('print hides navigation, search and buttons; shows header, drawing, tables, footer', async () => {
  const { page, context } = await open(browser, '#/cartridge/223_rem');
  await page.emulateMedia({ media: 'print' });
  const shown = (sel) => page.evaluate((s) => { const e = document.querySelector(s); return !!e && getComputedStyle(e).display !== 'none' && e.getBoundingClientRect().height > 0; }, sel);
  assert.equal(await shown('button.print'), false);
  assert.equal(await shown('nav.actions'), false);
  assert.equal(await shown('.site-bar'), false);
  assert.equal(await shown('h1'), true);
  assert.equal(await shown('.drawing svg'), true);
  assert.equal(await shown('table.values'), true);
  assert.equal((await page.locator('footer.source').textContent()).trim(), 'Source: C.I.P. TDCC, revised 2017-05-17');
  // order: header, drawing, tables, footer
  const ys = await page.evaluate(() => ['h1', '.drawing', '.values-group', 'footer.source'].map((s) => document.querySelector(s).getBoundingClientRect().top));
  assert.deepEqual(ys.slice().sort((a, b) => a - b), ys);
  await context.close();
});

test('print is black on white even when the system is dark', async () => {
  const { page, context } = await open(browser, '#/cartridge/308_win', { colorScheme: 'dark' });
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  const r = await page.evaluate(() => ({
    bg: getComputedStyle(document.body).backgroundColor,
    fg: getComputedStyle(document.body).color,
    ink: getComputedStyle(document.querySelector('.drawing svg')).color,
    fill: getComputedStyle(document.querySelector('[data-part="case-fill"]')).fill
  }));
  assert.equal(r.fg, 'rgb(0, 0, 0)');
  assert.match(r.bg, /^(rgb\(255, 255, 255\)|rgba\(0, 0, 0, 0\))$/);
  assert.equal(r.ink, 'rgb(0, 0, 0)');
  assert.equal(r.fill, 'rgb(255, 255, 255)');
  await context.close();
});

test('print: drawing is 190 mm wide, its stated scale is true, labels are at least 6 pt', async () => {
  const { page, context } = await open(browser);
  for (const r of data) {
    await page.goto(INDEX + '#/cartridge/' + r.key);
    await page.getByRole('heading', { level: 1, name: r.name, exact: true }).waitFor();
    await page.emulateMedia({ media: 'print' });
    const m = await page.evaluate(() => {
      const svg = document.querySelector('.drawing svg');
      const w = svg.getBoundingClientRect().width;
      const vb = svg.viewBox.baseVal;
      const label = document.querySelector('text.dim-label');
      const fs = parseFloat(label.getAttribute('font-size') || getComputedStyle(label).fontSize) || parseFloat(label.parentNode.getAttribute('font-size'));
      return { w, vbw: vb.width, scale: parseFloat(svg.dataset.scale), fs, tb: [...svg.querySelectorAll('[data-part="title-block"] text')].map((t) => t.textContent) };
    });
    const mmPerPx = 25.4 / 96;
    assert.ok(Math.abs(m.w * mmPerPx - 190) < 0.3, `${r.key} width ${m.w * mmPerPx} mm`);
    const printedScale = (m.w * mmPerPx) / m.vbw;
    assert.ok(Math.abs(printedScale - m.scale) < 0.005, `${r.key} scale ${printedScale} vs ${m.scale}`);
    assert.ok(m.tb.join(' | ').includes(`Scale ${m.scale} : 1 (A4)`), r.key);
    const pt = m.fs * printedScale * (72 / 25.4);
    assert.ok(pt >= 6, `${r.key} label ${pt.toFixed(1)} pt`);
    await page.emulateMedia({ media: 'screen' });
  }
  await context.close();
});
