'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const C = require('../../js/catalog.js');

const names = (list) => list.map((r) => r.name);

test('no filter lists everything in data order', () => {
  const all = C.filter(data, { query: '', family: '' });
  assert.equal(all.length, 25);
  assert.deepEqual(names(all), names(data));
});

test('alternative names are searched: 7,62 x 51 finds only 308 Win.', () => {
  assert.deepEqual(names(C.filter(data, { query: '7,62 x 51', family: '' })), ['308 Win.']);
});

test('search is case-insensitive and ignores surrounding/inner extra whitespace', () => {
  assert.deepEqual(names(C.filter(data, { query: '  CREEDMOOR ' })), ['6,5 Creedmoor']);
  assert.deepEqual(names(C.filter(data, { query: '7,62   x  51' })), ['308 Win.']);
});

test('substring match on names and alternative names', () => {
  const found = names(C.filter(data, { query: 'mag' }));
  assert.deepEqual(found.sort(), [
    '22 Win. Mag. R.F.', '300 Win. Mag.', '338 Lapua Mag.', '357 Magnum', '44 Rem. Mag.', '7 mm Rem. Mag.'
  ].sort());
  assert.deepEqual(names(C.filter(data, { query: '30-06' })), ['30-06 Spring.']);
  assert.deepEqual(names(C.filter(data, { query: '9 x 19' })), ['9 mm Luger']);
});

test('decimal comma and point are interchangeable when searching', () => {
  assert.deepEqual(names(C.filter(data, { query: '6.5 creed' })), ['6,5 Creedmoor']);
  assert.deepEqual(names(C.filter(data, { query: '7,62 x 51' })), names(C.filter(data, { query: '7.62 x 51' })));
});

test('family filter', () => {
  assert.deepEqual(names(C.filter(data, { family: 'belted' })), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(C.filter(data, { family: 'rimless' }).length, 12);
  assert.equal(C.filter(data, { family: 'rimmed' }).length, 2);
  assert.equal(C.filter(data, { family: 'pistol' }).length, 6);
  assert.equal(C.filter(data, { family: 'rimfire' }).length, 3);
  assert.equal(C.filter(data, { family: '' }).length, 25);
});

test('search and family combine', () => {
  assert.deepEqual(names(C.filter(data, { query: 'mag', family: 'pistol' })), ['357 Magnum', '44 Rem. Mag.']);
  assert.deepEqual(names(C.filter(data, { query: 'zzz', family: 'pistol' })), []);
});

test('families offered are All plus the five families of the data', () => {
  assert.deepEqual(C.FAMILIES, ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  assert.deepEqual([...new Set(data.map((r) => r.family))].sort(), [...C.FAMILIES].sort());
});

test('count text', () => {
  assert.equal(C.countText(25), '25 cartridges');
  assert.equal(C.countText(1), '1 cartridges');
  assert.equal(C.countText(0), '0 cartridges');
});

test('special characters in a query do not break matching', () => {
  assert.deepEqual(names(C.filter(data, { query: '40 S.&' })), ['40 S.& W.']);
  assert.deepEqual(names(C.filter(data, { query: '(' })), ['9 mm Luger', '338 Lapua Mag.'].sort((a, b) => names(data).indexOf(a) - names(data).indexOf(b)));
});
