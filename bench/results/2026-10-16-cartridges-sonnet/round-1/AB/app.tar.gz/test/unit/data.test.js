'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..', '..');
const source = fs.readFileSync(path.join(root, 'data', 'cartridges.jsonl'), 'utf8')
  .split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l));
const shipped = require('../../js/data.js');

test('shipped data holds the 25 supplied records, unchanged', () => {
  assert.equal(source.length, 25);
  assert.deepEqual(shipped, source);
});

test('keys and names are unique', () => {
  assert.equal(new Set(shipped.map((r) => r.key)).size, 25);
  assert.equal(new Set(shipped.map((r) => r.name)).size, 25);
});

test('every record has what the app relies on', () => {
  for (const r of shipped) {
    for (const k of ['key', 'name', 'family', 'country', 'published', 'revised', 'tab', 'pressureMethod']) {
      assert.ok(r[k] !== undefined, `${r.key}.${k}`);
    }
    assert.ok(r.cartridge && r.chamber && r.annotations, r.key);
    assert.equal(typeof r.cartridge.lengths.L3, 'number', r.key);
  }
});
