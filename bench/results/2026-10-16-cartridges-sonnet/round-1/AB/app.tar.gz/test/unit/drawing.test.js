'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const D = require('../../js/drawing.js');

const rec = (key) => data.find((r) => r.key === key);
const lay = (key) => D.layout(rec(key));
const texts = (l) => l.labels.map((x) => x.text);

const overlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
function segHitsRect(a, b, r) {
  // Liang-Barsky
  let t0 = 0, t1 = 1;
  const dx = b.x - a.x, dy = b.y - a.y;
  const p = [-dx, dx, -dy, dy], q = [a.x - r.x0, r.x1 - a.x, a.y - r.y0, r.y1 - a.y];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; } else {
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
  }
  return t0 < t1;
}

test('308 Win.: every required and published dimension is labelled symbol + value', () => {
  const t = texts(lay('308_win'));
  for (const s of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72',
    'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) assert.ok(t.includes(s), s + ' in ' + t.join('|'));
  assert.equal(t.length, 13);
});

test('only published dimensions are labelled', () => {
  const luger = texts(lay('9_mm_luger'));
  for (const s of ['L3 19.15', 'L6 29.69', 'R1 9.96', 'R 1.27', 'P1 9.93', 'H2 9.65', 'G1 9.03', 'E1 8.79'])
    assert.ok(luger.includes(s), s);
  for (const sym of ['P2', 'H1', 'L1', 'L2', 'α']) assert.ok(!luger.some((x) => x.startsWith(sym + ' ')), sym);
  const lr = texts(lay('22_long_rifle'));
  assert.ok(!lr.some((x) => x.startsWith('E1')));
  assert.ok(lr.includes('H2 5.72') && lr.includes('R 1.09'));
  const sm = texts(lay('6_5_x_55_se'));
  assert.ok(sm.includes('α 50°35\'2"'), sm.join('|'));
});

test('labels carry the value as published (no tolerance, no thousands separators)', () => {
  assert.ok(texts(lay('223_rem')).includes('P2 9'));
  assert.ok(texts(lay('223_rem')).includes('L1 36.52'));
});

test('no two labels overlap and no label touches the outline or a foreign dimension line (all 25)', () => {
  for (const r of data) {
    const l = D.layout(r);
    assert.equal(l.ok, true, r.key);
    l.labels.forEach((a, i) => {
      assert.ok(a.rect.x1 > a.rect.x0 && a.rect.y1 > a.rect.y0, `${r.key} ${a.text}`);
      for (let j = i + 1; j < l.labels.length; j++)
        assert.ok(!overlap(a.rect, l.labels[j].rect), `${r.key}: "${a.text}" overlaps "${l.labels[j].text}"`);
      for (const s of l.outlineSegments) assert.ok(!segHitsRect(s.a, s.b, a.rect), `${r.key}: "${a.text}" touches the outline`);
      for (const s of l.dimSegments) {
        if (s.owner === a.dim) continue;
        assert.ok(!segHitsRect(s.a, s.b, a.rect), `${r.key}: "${a.text}" touches a line of ${s.owner}`);
      }
    });
  }
});

test('labels stay inside the viewBox', () => {
  for (const r of data) {
    const l = D.layout(r);
    const vb = l.viewBox;
    for (const a of l.labels) {
      assert.ok(a.rect.x0 >= vb.x - 1e-9 && a.rect.x1 <= vb.x + vb.w + 1e-9, `${r.key} ${a.text} x`);
      assert.ok(a.rect.y0 >= vb.y - 1e-9 && a.rect.y1 <= vb.y + vb.h + 1e-9, `${r.key} ${a.text} y`);
    }
  }
});

test('true scale: 1 user unit = 1 mm, head left, axis horizontal', () => {
  const l = lay('308_win');
  const x = l.x;
  assert.equal(x(51.18) - x(0), 51.18);
  assert.equal(x(71.12) - x(0), 71.12);
  assert.equal(l.axisY, 0);
  const L3 = l.dims.find((d) => d.sym === 'L3'), L6 = l.dims.find((d) => d.sym === 'L6');
  assert.equal(Math.abs(L3.x2 - L3.x1), 51.18);
  assert.equal(Math.abs(L6.x2 - L6.x1), 71.12);
  const R1 = l.dims.find((d) => d.sym === 'R1');
  assert.ok(Math.abs(Math.abs(R1.y2 - R1.y1) - 12.01) < 0.02, 'R1 spans the rim diameter');
  const G1 = l.dims.find((d) => d.sym === 'G1');
  assert.ok(Math.abs(Math.abs(G1.y2 - G1.y1) - 7.85) < 1e-9);
  const H2 = l.dims.find((d) => d.sym === 'H2');
  assert.ok(Math.abs(Math.abs(H2.y2 - H2.y1) - 8.72) < 0.02);
});

test('outline extents: head face at z = 0, bullet tip at z = L6', () => {
  for (const r of data) {
    const l = D.layout(r);
    const xs = l.outlineSegments.flatMap((s) => [s.a.x, s.b.x]);
    near(Math.min(...xs) - l.x(0), 0, 1e-9, r.key);
    near(Math.max(...xs) - l.x(0), r.cartridge.lengths.L6, 1e-9, r.key);
    const ys = l.outlineSegments.flatMap((s) => [s.a.y, s.b.y]);
    assert.ok(Math.min(...ys) < 0 && Math.max(...ys) > 0);
    near(Math.min(...ys), -Math.max(...ys), 1e-9, r.key + ' mirror symmetric');
  }
});
function near(a, b, tol, msg) { assert.ok(Math.abs(a - b) <= tol, `${msg} ${a} !~ ${b}`); }

test('scale: prints at exactly 190 mm; largest nice scale that fits', () => {
  for (const r of data) {
    const l = D.layout(r);
    assert.ok(D.NICE_SCALES.includes(l.scale), `${r.key} ${l.scale}`);
    near(l.viewBox.w * l.scale, 190, 1e-6, r.key);
    assert.ok(l.contentWidth * l.scale <= 190 + 1e-9, r.key);
    assert.ok(l.contentHeight * l.scale <= 140 + 1e-9, `${r.key}: printed height`);
    const next = D.NICE_SCALES.find((s) => s > l.scale);
    if (next) assert.ok(l.contentWidth * next > 190 || l.contentHeight * next > 140, `${r.key}: ${next} would still fit`);
    // legible in print: label font at least 6 pt (1 pt = 0.3528 mm)
    assert.ok(l.fontSize * l.scale >= 6 * 0.3528, `${r.key} font ${l.fontSize * l.scale} mm`);
  }
});

test('title block: name, table, revision, units, scale', () => {
  const l = lay('308_win');
  const t = l.titleBlock.lines.map((x) => x.text);
  assert.equal(t[0], '308 Win.');
  const all = t.join(' | ');
  assert.match(all, /C\.I\.P\. table I\b/);
  assert.match(all, /Revised 2008-09-23/);
  assert.match(all, /Dimensions in mm/);
  assert.ok(all.includes(`Scale ${l.scale} : 1 (A4)`), all);
  assert.ok(texts(l).every((x) => !x.includes('Dimensions')), 'title block text is not a dimension label');
});

test('alpha is drawn as legs + arc only when the shoulder exists', () => {
  assert.ok(lay('308_win').dims.some((d) => d.sym === 'α' && d.kind === 'angle'));
  assert.ok(!lay('9_mm_luger').dims.some((d) => d.sym === 'α'));
  const a = lay('223_rem').dims.find((d) => d.sym === 'α');
  assert.ok(a.apex.x > lay('223_rem').x(39.55));
  assert.ok(a.arc.length > 3);
});

test('svg markup: accessible name, escaping, structure', () => {
  const out = D.render(rec('40_s_w'));
  assert.equal(out.ok, true);
  assert.match(out.svg, /^<svg /);
  assert.match(out.svg, /role="img"/);
  assert.ok(out.svg.includes('aria-label="40 S.&amp; W. drawing"'), 'escaped name');
  assert.ok(!/&(?!amp;|lt;|gt;|quot;|#)/.test(out.svg), 'no raw ampersands');
  assert.match(out.svg, /viewBox="[-\d. ]+"/);
  assert.match(out.svg, /data-rim-type="rimless"/);
  assert.match(out.svg, /stroke-dasharray="[\d. ]+"/, 'dash-dot centre line is inline');
  assert.ok(!/<script|onload|href=/i.test(out.svg));
  const o = D.render(rec('308_win')).svg;
  const section = o.slice(o.indexOf('data-view="section"'), o.indexOf('data-view="section"') + 20000);
  assert.match(section, /fill="url\(#hatch-case\)"/);
  const outsideStart = o.indexOf('data-view="outside"');
  const outside = o.slice(outsideStart, o.indexOf('data-view="section"'));
  assert.ok(!outside.includes('url(#hatch'), 'outside view has no hatching');
});

test('missing values are reported by the render result', () => {
  assert.deepEqual(D.render(rec('308_win')).notes, []);
  const n = D.render(rec('9_3_x_74_r')).notes;
  assert.ok(n.some((x) => /E, E1, e min not published/.test(x)), n.join('|'));
  assert.ok(D.render(rec('338_lapua_mag')).notes.some((x) => /r1 min/.test(x)));
});

test('all 25 records render finite svg', () => {
  for (const r of data) {
    const out = D.render(r);
    assert.equal(out.ok, true, r.key);
    assert.ok(!/NaN|Infinity|undefined/.test(out.svg), r.key);
  }
});

test('record without required values is reported, not drawn', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.lengths.L6;
  const out = D.render(r);
  assert.equal(out.ok, false);
  assert.deepEqual(out.missing, ['L6']);
  assert.equal(out.svg, '');
});

test('tiers stay few', () => {
  for (const r of data) assert.ok(D.layout(r).tiers <= 5, `${r.key} tiers ${D.layout(r).tiers}`);
});

test('forcing the greedy fallback placement still gives overlap-free labels', () => {
  for (const r of data) {
    const l = D.layout(r, { searchBudget: 1 });
    assert.equal(l.fallback, true, r.key);
    l.labels.forEach((a, i) => {
      for (let j = i + 1; j < l.labels.length; j++) assert.ok(!overlap(a.rect, l.labels[j].rect), `${r.key}: "${a.text}" / "${l.labels[j].text}"`);
      for (const s of l.outlineSegments) assert.ok(!segHitsRect(s.a, s.b, a.rect), `${r.key}: "${a.text}" touches the outline`);
      for (const s of l.dimSegments) if (s.owner !== a.dim) assert.ok(!segHitsRect(s.a, s.b, a.rect), `${r.key}: "${a.text}" touches ${s.owner}`);
    });
  }
  assert.equal(D.layout(rec('308_win')).fallback, false);
});

test('degenerate records still render finite svg (no shoulder cone, short bullet)', () => {
  const flat = JSON.parse(JSON.stringify(rec('308_win')));
  flat.cartridge.powderChamber.P2 = flat.cartridge.collar.H1;
  let out = D.render(flat);
  assert.equal(out.ok, true);
  assert.ok(!/NaN|Infinity|undefined/.test(out.svg));
  assert.ok(!texts(D.layout(flat)).some((x) => x.startsWith('α')), 'no angle without a cone');
  const short = JSON.parse(JSON.stringify(rec('308_win')));
  short.cartridge.lengths.L6 = 51.18 + 3;
  out = D.render(short);
  assert.ok(!/NaN|Infinity|undefined/.test(out.svg));
  const g1 = D.layout(short).dims.find((d) => d.sym === 'G1');
  assert.ok(g1.x1 >= 51.18 - 1e-9, 'G1 is dimensioned outside the case');
});

test('title block scale is a clean number even when no nice scale fits', () => {
  const big = JSON.parse(JSON.stringify(rec('9_3_x_74_r')));
  for (const k of Object.keys(big.cartridge.lengths)) if (typeof big.cartridge.lengths[k] === 'number') big.cartridge.lengths[k] *= 3;
  const l = D.layout(big);
  assert.ok(l.scale < 1);
  assert.equal(l.scale, Math.floor(l.scale * 100) / 100);
  const tb = l.titleBlock.lines.map((x) => x.text).join(' ');
  assert.ok(tb.includes(`Scale ${l.scale} : 1`));
  for (const line of l.titleBlock.lines) assert.ok(line.x + line.text.length * 0.6 * 0.85 * l.fontSize <= l.titleBlock.x1 + 1e-6, 'text inside block');
  near(l.viewBox.w * l.scale, 190, 1e-6, 'width');
});
