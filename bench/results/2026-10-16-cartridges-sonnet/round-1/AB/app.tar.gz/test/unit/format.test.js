'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const F = require('../../js/format.js');

const rec = (key) => data.find((r) => r.key === key);
const rows = (key, group, section) =>
  F.sections(rec(key), group).find((s) => s.key === section).rows;
const row = (key, group, section, symbol) =>
  rows(key, group, section).find((r) => r.symbol === symbol);

test('numbers are shown as published: decimal point, no thousands separator', () => {
  assert.equal(F.number(4150), '4150');
  assert.equal(F.number(51.18), '51.18');
  assert.equal(F.number(0), '0');
  assert.equal(F.number(0.1), '0.1');
  assert.equal(F.number(1825), '1825');
});

test('angles: degrees, and degrees-minutes-seconds', () => {
  assert.equal(F.angle(40), '40°');
  assert.equal(F.angle(0), '0°');
  assert.equal(F.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.angle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'0"');
  assert.equal(F.angle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
});

test('symbols: field name except the renamed ones', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
    L3: 'L3', Pmax: 'Pmax', R1: 'R1', r: 'r', Fe: 'Fe',
  };
  for (const [field, symbol] of Object.entries(expected)) assert.equal(F.symbol(field), symbol, field);
});

test('units', () => {
  for (const f of ['Pmax', 'PK', 'PE']) assert.equal(F.unit(f), 'bar');
  assert.equal(F.unit('EE'), 'J');
  assert.equal(F.unit('M'), 'g');
  assert.equal(F.unit('Q'), 'mm²');
  assert.equal(F.unit('N'), '');
  for (const f of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unit(f), '°', f);
  for (const f of ['L3', 'P1', 'G1', 'Fe', 'deltaL', 'u', 'b', 'S']) assert.equal(F.unit(f), 'mm', f);
});

test('table model: Pmax and EE of 308 Win.', () => {
  assert.deepEqual(row('308_win', 'cartridge', 'pressures', 'Pmax'), { field: 'Pmax', symbol: 'Pmax', value: '4150', unit: 'bar' });
  assert.equal(row('308_win', 'cartridge', 'pressures', 'EE').value, '3920');
  assert.equal(row('308_win', 'cartridge', 'pressures', 'EE').unit, 'J');
  assert.equal(row('308_win', 'cartridge', 'pressures', 'M').unit, 'g');
});

test('tolerance sits next to its value and has no row of its own', () => {
  assert.equal(row('308_win', 'cartridge', 'lengths', 'L1').value, '39.62 -0.2');
  assert.equal(row('308_win', 'cartridge', 'lengths', 'L3').value, '51.18');
  assert.equal(row('9_mm_luger', 'cartridge', 'lengths', 'L3').value, '19.15 -0.25');
  assert.equal(row('300_win_mag', 'cartridge', 'caseHead', 'E').value, '5.59 -0.2');
  assert.equal(row('7_x_65_r', 'cartridge', 'caseHead', 'R').value, '1.4 -0.25');
  for (const r of data) for (const g of ['cartridge', 'chamber'])
    for (const s of F.sections(r, g)) for (const x of s.rows)
      assert.ok(!/Tol$/.test(x.field) && !/Tol/.test(x.symbol), `${r.key} ${x.field}`);
});

test('angles in tables', () => {
  assert.equal(row('6_5_x_55_se', 'cartridge', 'junctionCone', 'α').value, '50°35\'2"');
  assert.equal(row('6_5_x_55_se', 'cartridge', 'caseHead', 'β').value, '45°');
  assert.equal(row('6_5_x_55_se', 'chamber', 'rifling', 'i').value, '0°42\'29"');
  assert.equal(row('22_long_rifle', 'cartridge', 'caseHead', 'β').value, '0°');
  assert.equal(row('22_long_rifle', 'cartridge', 'caseHead', 'δ').value, '0°');
  assert.equal(row('7_mm_rem_mag', 'chamber', 'rifling', 'i').value, '3°');
});

test('renamed symbols appear in rows, raw names do not', () => {
  const syms = rows('223_rem', 'cartridge', 'caseHead').map((r) => r.symbol);
  for (const s of ['e min', 'β', 'δ']) assert.ok(syms.includes(s), s);
  for (const s of ['eMin', 'beta', 'delta']) assert.ok(!syms.includes(s), s);
  assert.ok(rows('223_rem', 'cartridge', 'misc').some((r) => r.symbol === 'delta L'));
  assert.ok(rows('223_rem', 'cartridge', 'projectile').some((r) => r.symbol === 'L3 + G'));
  assert.ok(rows('223_rem', 'chamber', 'junctionCone').some((r) => r.symbol === 'r1 max'));
  assert.ok(rows('223_rem', 'cartridge', 'junctionCone').some((r) => r.symbol === 'r1 min'));
  assert.ok(rows('223_rem', 'chamber', 'rifling').some((r) => r.symbol === 'α1'));
});

test('sections: titles, order and omission of empty ones', () => {
  assert.deepEqual(F.sections(rec('223_rem'), 'cartridge').map((s) => s.title),
    ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Misc', 'Powder chamber', 'Pressures', 'Projectile']);
  assert.deepEqual(F.sections(rec('223_rem'), 'chamber').map((s) => s.title),
    ['Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling']);
  assert.ok(!F.sections(rec('9_mm_luger'), 'cartridge').some((s) => s.key === 'junctionCone'));
  assert.ok(!F.sections(rec('22_win_mag_r_f'), 'chamber').some((s) => s.key === 'junctionCone'));
});

test('every non-tolerance field of every record appears in exactly one row', () => {
  for (const r of data) {
    for (const group of ['cartridge', 'chamber']) {
      const expected = [];
      for (const [sec, fields] of Object.entries(r[group]))
        for (const f of Object.keys(fields)) if (!/Tol$/.test(f)) expected.push(`${sec}.${f}`);
      const got = [];
      for (const s of F.sections(r, group)) for (const x of s.rows) got.push(`${s.key}.${x.field}`);
      assert.deepEqual(got.slice().sort(), expected.sort(), `${r.key} ${group}`);
    }
  }
});

test('metadata of 308 Win.', () => {
  const m = F.metadata(rec('308_win'));
  const get = (label) => m.find((x) => x.label === label);
  assert.equal(get('Alternative names').text, '308 Winchester, 7,62 x 51');
  assert.equal(get('Family').text, 'rimless');
  assert.equal(get('Category').text, 'rifle');
  assert.equal(get('Primer type').text, 'lr');
  assert.equal(get('C.I.P. table').text, 'I');
  assert.equal(get('Country').text, 'US');
  assert.equal(get('Published').text, '1984-06-14');
  assert.equal(get('Revised').text, '2008-09-23');
  assert.equal(get('Pressure method').text, 'Transducer');
  const cap = get('Water capacity');
  assert.equal(cap.text, '56 gr H2O');
  assert.equal(cap.note, 'Lapua brass measures 55.8 (lapua-308)');
  assert.deepEqual(cap.link, { text: 'kwk', href: 'http://kwk.us/cases.html' });
});

test('metadata with nothing published', () => {
  const m = F.metadata(rec('7_x_64'));
  assert.equal(m.find((x) => x.label === 'Water capacity').text, 'not published');
  assert.equal(m.find((x) => x.label === 'Water capacity').link, undefined);
  assert.equal(m.find((x) => x.label === 'Alternative names').text, 'not published');
});

test('names are never altered', () => {
  assert.equal(rec('6_5_creedmoor').name, '6,5 Creedmoor');
  assert.equal(rec('40_s_w').name, '40 S.& W.');
});

test('angle objects with missing minutes or seconds are read as zero', () => {
  assert.equal(F.angle({ degrees: 40 }), '40°0\'0"');
  assert.equal(F.angle({ degrees: 40, minutes: 5 }), '40°5\'0"');
});
