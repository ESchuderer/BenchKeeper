'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const G = require('../../js/geometry.js');

const rec = (key) => data.find((r) => r.key === key);
const model = (key) => G.build(rec(key));
const near = (a, b, tol = 1e-6, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg || ''} ${a} !~ ${b}`);
const has = (profile, z, r, tol = 1e-6) => profile.some((p) => Math.abs(p.z - z) <= tol && Math.abs(p.r - r) <= tol);
const dist = (a, b) => Math.hypot(a.z - b.z, a.r - b.r);
function distToPolyline(pt, poly) {
  let best = Infinity;
  for (let i = 0; i + 1 < poly.length; i++) {
    const a = poly[i], b = poly[i + 1];
    const dz = b.z - a.z, dr = b.r - a.r, l2 = dz * dz + dr * dr;
    let t = l2 ? ((pt.z - a.z) * dz + (pt.r - a.r) * dr) / l2 : 0;
    t = Math.max(0, Math.min(1, t));
    best = Math.min(best, dist(pt, { z: a.z + t * dz, r: a.r + t * dr }));
  }
  return best;
}

test('rim type', () => {
  const expected = {
    '223_rem': 'rimless', '243_win': 'rimless', '6_5_x_55_se': 'rimless', '338_lapua_mag': 'rimless',
    '9_3_x_74_r': 'rimmed', '7_x_65_r': 'rimmed', '38_special': 'rimmed', '357_magnum': 'rimmed', '44_rem_mag': 'rimmed',
    '300_win_mag': 'belted', '7_mm_rem_mag': 'belted',
    '22_long_rifle': 'rimfire', '22_win_mag_r_f': 'rimfire', '17_hmr': 'rimfire',
    '9_mm_luger': 'rimless', '45_auto': 'rimless', '40_s_w': 'rimless', '7_62_x_39': 'rimless'
  };
  for (const [k, t] of Object.entries(expected)) assert.equal(model(k).rimType, t, k);
  assert.equal(G.rimType({ family: 'rimless', P1: 10, R1: 10.5 }), 'rimmed');
  assert.equal(G.rimType({ family: 'rimless', P1: 10, R1: 9.7 }), 'rebated');
  assert.equal(G.rimType({ family: 'rimless', P1: 10, R1: 10.4999 }), 'rimless');
  assert.equal(G.rimType({ family: 'rimless', P1: 10, R1: 9.8 }), 'rimless');
});

test('profile runs from the axis at the head face to the mouth, z never decreasing, r never negative', () => {
  for (const r of data) {
    const m = G.build(r);
    assert.equal(m.ok, true, r.key);
    const p = m.profile;
    assert.deepEqual(p[0], { z: 0, r: 0 }, r.key);
    const last = p[p.length - 1];
    near(last.z, r.cartridge.lengths.L3, 1e-9, r.key);
    near(last.r, r.cartridge.collar.H2 / 2, 1e-9, r.key);
    for (let i = 1; i < p.length; i++) {
      assert.ok(Number.isFinite(p[i].z) && Number.isFinite(p[i].r), `${r.key} #${i}`);
      assert.ok(p[i].z >= p[i - 1].z - 1e-9, `${r.key} z decreases at #${i}`);
      assert.ok(p[i].r >= 0, `${r.key} r<0 at #${i}`);
    }
  }
});

test('223 Rem.: chamfer, rim edge, groove, body start', () => {
  const p = model('223_rem').profile;
  const f035 = 0.45 * Math.tan((35 * Math.PI) / 180);
  assert.ok(has(p, 0, 4.8 - f035), 'chamfer start');
  assert.ok(has(p, 0.45, 4.8), 'chamfer end');
  assert.ok(has(p, 1.14, 4.8), 'rim back edge');
  assert.ok(has(p, 1.14, 4.215), 'groove inner start');
  assert.ok(has(p, 1.14 + 0.76, 4.215), 'groove floor end');
  assert.ok(has(p, 3.13, 4.79), 'ramp end / body start');
  assert.equal(model('223_rem').bodyStart, 3.13);
});

test('chamfer is limited to R1/4', () => {
  const r = JSON.parse(JSON.stringify(rec('223_rem')));
  r.cartridge.caseHead.f = 20; // f*tan(35) >> R1/4
  r.cartridge.caseHead.R = 25;
  r.cartridge.caseHead.E = 30;
  const p = G.build(r).profile;
  assert.ok(has(p, 0, 4.8 - 9.6 / 4));
});

test('square corner when beta or f is not published or beta >= 90', () => {
  const p = model('9_3_x_74_r').profile; // has beta+f
  assert.ok(has(p, 0, 13.35 / 2 - Math.min(0.3 * Math.tan((45 * Math.PI) / 180), 13.35 / 4)));
  const r = JSON.parse(JSON.stringify(rec('223_rem')));
  delete r.cartridge.caseHead.f;
  let m = G.build(r);
  assert.deepEqual(m.profile[1], { z: 0, r: 4.8 });
  assert.ok(m.notes.some((n) => n.missing.includes('f')));
  r.cartridge.caseHead.f = 0.45; r.cartridge.caseHead.beta = 90;
  m = G.build(r);
  assert.deepEqual(m.profile[1], { z: 0, r: 4.8 });
});

test('belted: ramp at delta to the axis up to the belt, belt to E, then step in to P1/2', () => {
  const m = model('300_win_mag');
  const p = m.profile;
  const rampEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  assert.ok(has(p, 1.27, 6.035), 'groove start');
  assert.ok(has(p, 1.27 + 0.94, 6.035), 'floor end');
  assert.ok(has(p, rampEnd, 6.755), 'belt ramp end');
  assert.ok(has(p, 5.59, 6.755), 'belt end');
  assert.ok(has(p, 5.59, 13.03 / 2), 'step in to P1/2');
  near(m.beltRampEnd, rampEnd, 1e-9);
});

test('rimmed case without groove steps in at z = R', () => {
  const p = model('7_x_65_r').profile;
  assert.ok(has(p, 1.4, 13.32 / 2));
  assert.ok(has(p, 1.4, 11.89 / 2));
  assert.equal(model('7_x_65_r').bodyStart, 1.4);
});

test('rimfire: half-round rim edge of radius min(R/2, (R1-P1)/2) at R1/2', () => {
  const m = model('22_long_rifle');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.equal(rho, 0.545);
  const rim = m.profile.filter((p) => p.z <= 1.09 + 1e-9);
  const maxR = Math.max(...rim.map((p) => p.r));
  near(maxR, 7.06 / 2, 1e-9);
  const top = rim.find((p) => Math.abs(p.r - maxR) < 1e-9);
  near(top.z, 1.09 / 2, 1e-9);
  // every arc point lies at distance rho from the arc centre (z = R/2, r = R1/2 - rho)
  const centre = { z: 1.09 / 2, r: 7.06 / 2 - rho };
  for (const p of rim) if (p.z > 0 && p.z < 1.09 && p.r > centre.r + 1e-9) near(dist(p, centre), rho, 1e-6, 'arc');
  assert.equal(m.rimType, 'rimfire');
  assert.ok(m.notes.every((n) => n.feature !== 'groove' && n.feature !== 'chamfer'), 'no groove/chamfer notes for rimfire');
});

test('rimfire half-round is limited by (R1-P1)/2', () => {
  const r = JSON.parse(JSON.stringify(rec('22_long_rifle')));
  r.cartridge.caseHead.R1 = 6.0; // (6.0-5.74)/2 = 0.13 < R/2
  const m = G.build(r);
  near(Math.max(...m.profile.map((p) => p.r)), 3.0, 1e-9);
  const centre = { z: 1.09 / 2, r: 3.0 - 0.13 };
  for (const p of m.profile) if (p.z > 0.2 && p.z < 0.9 && p.r > centre.r + 1e-9) near(dist(p, centre), 0.13, 1e-6);
});

test('straight case (9 mm Luger): body runs to the mouth, no shoulder', () => {
  const m = model('9_mm_luger');
  assert.equal(m.shoulder, null);
  const last = m.profile[m.profile.length - 1];
  assert.deepEqual(last, { z: 19.15, r: 9.65 / 2 });
  assert.ok(has(m.profile, 2.98, 9.93 / 2));
  const n = m.notes.find((x) => x.feature === 'shoulder');
  assert.deepEqual(n.missing, ['α', 'L1', 'L2']);
  assert.match(n.text, /α, L1, L2 not published/);
});

test('bottleneck (308 Win.): nominal shoulder, rounded corners', () => {
  const m = model('308_win');
  assert.deepEqual(m.shoulder.from, { z: 39.62, r: 11.53 / 2 });
  assert.deepEqual(m.shoulder.to, { z: 43.48, r: 8.72 / 2 });
  const last = m.profile[m.profile.length - 1];
  assert.deepEqual(last, { z: 51.18, r: 4.36 });
  // the nominal corners are cut by the fillets
  assert.ok(!has(m.profile, 39.62, 5.765, 1e-9));
  assert.ok(!has(m.profile, 43.48, 4.36, 1e-9));
  // fillet geometry: the outline's distance to the corner equals rho*(1/sin(phi/2) - 1)
  const body = { z: 3.85, r: 11.96 / 2 };
  const check = (v, a, b, rho) => {
    const u1 = [a.z - v.z, a.r - v.r], u2 = [b.z - v.z, b.r - v.r];
    const l1 = Math.hypot(...u1), l2 = Math.hypot(...u2);
    const phi = Math.acos((u1[0] * u2[0] + u1[1] * u2[1]) / (l1 * l2));
    const expected = rho * (1 / Math.sin(phi / 2) - 1);
    const got = distToPolyline(v, m.profile);
    assert.ok(Math.abs(got - expected) < 0.01 * Math.max(expected, 0.05) + 1e-4, `fillet ${got} vs ${expected}`);
  };
  check(m.shoulder.from, body, m.shoulder.to, 0.76);
  check(m.shoulder.to, m.shoulder.from, { z: 51.18, r: 4.36 }, 3.18);
});

test('338 Lapua Mag.: no r1 min -> body-side corner exact, neck side rounded, and said so', () => {
  const m = model('338_lapua_mag');
  assert.ok(has(m.profile, 54.9, 13.82 / 2), 'exact body-side corner');
  assert.ok(!has(m.profile, 60.89, 9.46 / 2, 1e-9), 'neck side rounded with r2');
  const n = m.notes.find((x) => x.feature === 'shoulder-body-corner');
  assert.deepEqual(n.missing, ['r1 min']);
  assert.equal(m.notes.find((x) => x.feature === 'shoulder-neck-corner'), undefined);
});

test('17 HMR: both radii missing', () => {
  const m = model('17_hmr');
  assert.deepEqual(m.notes.map((n) => n.feature).sort(), ['shoulder-body-corner', 'shoulder-neck-corner']);
  assert.ok(has(m.profile, 22.2, 6.15 / 2));
  assert.ok(has(m.profile, 23.54, 4.9 / 2));
});

test('missing groove values are named, groove skipped', () => {
  const m = model('9_3_x_74_r');
  const n = m.notes.find((x) => x.feature === 'groove');
  assert.deepEqual(n.missing, ['E', 'E1', 'e min']);
  assert.match(n.text, /E, E1, e min not published/);
  assert.equal(m.groove, null);
  // belted without R3: plain groove drawn, belt reported
  const r = JSON.parse(JSON.stringify(rec('300_win_mag')));
  delete r.cartridge.caseHead.R3;
  const b = G.build(r);
  assert.deepEqual(b.notes.find((x) => x.feature === 'belt').missing, ['R3']);
  assert.ok(b.groove);
});

test('complete records have no notes', () => {
  for (const k of ['223_rem', '243_win', '6_5_creedmoor', '308_win', '30_06_spring', '270_win', '300_win_mag', '7_mm_rem_mag']) {
    assert.deepEqual(model(k).notes, [], k);
  }
});

test('walls and solid head', () => {
  const m = model('223_rem');
  near(m.walls.tn, 0.365, 1e-9);
  near(m.walls.tb, 0.6, 1e-9);
  near(m.w, 3.04 + 1.5, 1e-9);
  // tb capped by 0.35 * P1/2
  const r = JSON.parse(JSON.stringify(rec('223_rem')));
  r.cartridge.powderChamber.P1 = 1.0; r.cartridge.caseHead.R1 = 1.0;
  assert.ok(G.build(r).walls.tb <= 0.35 * 0.5 + 1e-9);
  // w from the groove / belt
  const b = model('300_win_mag');
  near(b.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, 5.59 + b.walls.tb, b.beltRampEnd + b.walls.tb), 1e-9);
  near(b.w, 5.59 + 0.6, 1e-9);
  // rimfire: 2.5 minimum, no pocket depth
  near(model('22_long_rifle').w, 2.5, 1e-9);
});

test('tb grows with a thick neck wall: 1.3 * tn when above 0.6', () => {
  const r = JSON.parse(JSON.stringify(rec('223_rem')));
  r.cartridge.collar.H2 = 7.5; r.cartridge.collar.H1 = 7.5; // tn = 0.9
  const m = G.build(r);
  near(m.walls.tn, 0.9, 1e-9);
  near(m.walls.tb, Math.min(1.3 * 0.9, 0.35 * 9.58 / 2), 1e-9);
});

test('primer pocket by primer type', () => {
  assert.deepEqual(model('308_win').pocket, { d: 5.33, depth: 3.3 });
  assert.deepEqual(model('223_rem').pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(model('9_mm_luger').pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(model('45_auto').pocket, { d: 5.33, depth: 3.04 });
  assert.deepEqual(model('44_rem_mag').pocket, { d: 5.33, depth: 3.04 });
  assert.deepEqual(model('357_magnum').pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(model('338_lapua_mag').pocket, { d: 5.33, depth: 3.3 });
  for (const k of ['22_long_rifle', '22_win_mag_r_f', '17_hmr']) assert.equal(model(k).pocket, null, k);
});

test('inner profile: from w to the mouth, inside the outer one, ends at the bullet radius', () => {
  for (const r of data) {
    const m = G.build(r);
    const inner = m.inner;
    near(inner[0].z, m.w, 1e-9, r.key);
    const last = inner[inner.length - 1];
    near(last.z, r.cartridge.lengths.L3, 1e-9, r.key);
    near(last.r, m.bullet.heeled ? r.cartridge.collar.H2 / 2 - m.walls.tb : r.cartridge.projectile.G1 / 2, 1e-9, r.key);
    for (const p of inner) {
      assert.ok(p.r > 0, `${r.key} inner r>0`);
      assert.ok(p.r < m.radiusAt(p.z) - 1e-9, `${r.key} inner inside outer at z=${p.z}`);
    }
  }
  // bottleneck blend: tb on the body, tn on the neck
  const m = model('223_rem');
  const at = (z) => m.radiusAt(z) - m.innerAt(z);
  near(at(20), 0.6, 1e-9);
  near(at(42), 0.365, 1e-9);
  near(at((36.52 + 39.55) / 2), (0.6 + 0.365) / 2, 1e-6);
});

test('section polygon: pocket cut out, closed, finite', () => {
  for (const r of data) {
    const m = G.build(r);
    const poly = m.sectionPolygon;
    for (const p of poly) assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r) && p.r >= 0, r.key);
    if (m.pocket) {
      assert.ok(has(poly, 0, m.pocket.d / 2), `${r.key} pocket mouth`);
      assert.ok(has(poly, m.pocket.depth, m.pocket.d / 2), `${r.key} pocket corner`);
      assert.ok(has(poly, m.pocket.depth, 0), `${r.key} pocket bottom on axis`);
    } else {
      assert.deepEqual(poly[0], { z: 0, r: 0 }, r.key);
    }
    assert.ok(has(poly, m.w, 0), `${r.key} head solid ends at w`);
  }
});

test('bullet: 308 Win. pointy tangent ogive', () => {
  const b = model('308_win').bullet;
  assert.equal(b.shape, 'pointy');
  near(b.s, 7.85, 1e-9);
  near(b.zb, 51.18 - 7.85, 1e-9);
  const Lb = 71.12 - b.zb;
  near(b.zc, b.zb + 0.4 * Lb, 1e-9);
  near(b.m, 1.27, 1e-9);
  const n = 71.12 - b.zc;
  const d = 7.85 / 2 - 1.27 / 2;
  near(b.rho, (d * d + n * n) / (2 * d), 1e-9);
  // arc points lie on the circle of radius rho around (zc, G1/2 - rho) and start tangent to the cylinder
  const c = { z: b.zc, r: 7.85 / 2 - b.rho };
  for (const p of b.nose) near(dist(p, c), b.rho, 1e-6, 'ogive');
  assert.deepEqual(b.nose[0], { z: b.zc, r: 7.85 / 2 });
  const tip = b.nose[b.nose.length - 1];
  near(tip.z, 71.12, 1e-9); near(tip.r, 1.27 / 2, 1e-9);
  assert.deepEqual(b.exposed[0], { z: 51.18, r: 0 });
  assert.deepEqual(b.exposed[b.exposed.length - 1], { z: 71.12, r: 0 });
  assert.deepEqual(b.full[0], { z: b.zb, r: 0 });
  assert.equal(b.heeled, false);
  near(b.seatR, 7.85 / 2, 1e-9);
});

test('meplat of pointy bullets is at least 1.27 and 8 % of G1', () => {
  near(model('223_rem').bullet.m, 1.27, 1e-9);
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.cartridge.projectile.G1 = 20; r.cartridge.collar.H2 = 20.5; r.cartridge.collar.H1 = 20.5; r.cartridge.powderChamber.P1 = 21; r.cartridge.powderChamber.P2 = 21;
  near(G.build(r).bullet.m, 1.6, 1e-9);
});

test('bullet seating and cylinder fraction by shape and category', () => {
  const expect = {
    '308_win': { s: 1.0 * 7.85, k: 0.40 },
    '9_mm_luger': { s: 0.4 * 9.03, k: 0.65 }, // rounded pistol
    '45_auto': { s: 0.4 * 11.48, k: 0.65 },
    '40_s_w': { s: 0.4 * 10.17, k: 0.70 }, // flat pistol
    '357_magnum': { s: 0.6 * 9.12, k: 0.78 }, // semi wadcutter
    '44_rem_mag': { s: 0.6 * 10.97, k: 0.78 },
    '22_win_mag_r_f': { s: 0.8 * 5.7, k: 0.55 }, // rounded rimfire
    '22_long_rifle': { s: 0.8 * 5.72, k: 0.55 },
    '17_hmr': { s: 1.0 * 4.38, k: 0.40 } // pointy rimfire
  };
  for (const [k, e] of Object.entries(expect)) {
    const b = model(k).bullet;
    near(b.s, e.s, 1e-9, k);
    near(b.k, e.k, 1e-9, k);
    const L3 = rec(k).cartridge.lengths.L3, L6 = rec(k).cartridge.lengths.L6;
    near(b.zb, L3 - e.s, 1e-9, k);
    near(b.zc, b.zb + e.k * (L6 - b.zb), 1e-9, k);
  }
  // rifle-category rounded / flat use 0.8 G1 and 0.55 / 0.60
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.annotations.defaultBulletShape = 'rounded';
  let b = G.build(r).bullet; near(b.s, 0.8 * 7.85, 1e-9); near(b.k, 0.55, 1e-9);
  r.annotations.defaultBulletShape = 'flat';
  b = G.build(r).bullet; near(b.s, 0.8 * 7.85, 1e-9); near(b.k, 0.60, 1e-9);
  r.annotations.category = 'pistol';
  b = G.build(r).bullet; near(b.s, 0.4 * 7.85, 1e-9); near(b.k, 0.70, 1e-9);
});

test('meplat and nose shapes', () => {
  const rounded = model('9_mm_luger').bullet;
  near(rounded.m, 0.15 * 9.03, 1e-9);
  const a = 29.69 - rounded.zc, bb = 9.03 / 2 - rounded.m / 2;
  for (const p of rounded.nose) {
    const e = ((p.z - rounded.zc) / a) ** 2 + ((p.r - rounded.m / 2) / bb) ** 2;
    near(e, 1, 1e-9, 'ellipse');
  }
  assert.deepEqual(rounded.nose[0], { z: rounded.zc, r: 9.03 / 2 });
  const flat = model('40_s_w').bullet;
  near(flat.m, 0.55 * 10.17, 1e-9);
  assert.equal(flat.nose.length, 2);
  const sw = model('357_magnum').bullet;
  near(sw.m, 0.6 * 9.12, 1e-9);
  assert.equal(sw.nose.length, 2);
  near(sw.nose[1].r, 0.6 * 9.12 / 2, 1e-9);
});

test('heeled case (22 Long Rifle)', () => {
  const m = model('22_long_rifle');
  const b = m.bullet;
  assert.equal(b.heeled, true);
  near(m.walls.tb, 0.6, 1e-9);
  near(m.walls.tn, m.walls.tb, 1e-9, 'uniform wall');
  near(b.seatR * 2, 5.72 - 2 * 0.6, 1e-9);
  near(b.exposedR * 2, 5.72, 1e-9);
  // seated heel steps up at the mouth
  assert.ok(has(b.full, 15.57, 4.52 / 2));
  assert.ok(has(b.full, 15.57, 5.72 / 2));
  near(m.inner[m.inner.length - 1].r * 2, 5.72 - 2 * 0.6, 1e-9);
  // 22 WMR is not heeled
  assert.equal(model('22_win_mag_r_f').bullet.heeled, false);
});

test('bullet is hidden in the outside view: exposed part starts at the mouth', () => {
  for (const r of data) {
    const b = G.build(r).bullet;
    near(b.exposed[0].z, r.cartridge.lengths.L3, 1e-9, r.key);
    for (const p of b.exposed) assert.ok(p.z >= r.cartridge.lengths.L3 - 1e-9, r.key);
    assert.ok(b.full[0].z < r.cartridge.lengths.L3, r.key);
    for (let i = 1; i < b.full.length; i++) assert.ok(b.full[i].z >= b.full[i - 1].z - 1e-9, `${r.key} z monotone`);
  }
});

test('missing required values make the drawing impossible and are named', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.lengths.L3;
  delete r.cartridge.projectile.G1;
  const m = G.build(r);
  assert.equal(m.ok, false);
  assert.deepEqual(m.missing, ['L3', 'G1']);
});

test('no notes are invented values: every numeric in the model derives from the record (spot check)', () => {
  const m = model('223_rem');
  assert.equal(m.v.R1, 9.6);
  assert.equal(m.v.eMin, 0.76);
  assert.equal(m.v.alpha, 46);
});

test('shoulder cone apex lies on the axis', () => {
  const s = model('223_rem').shoulder;
  const gamma = Math.atan((9.0 / 2 - 6.43 / 2) / (39.55 - 36.52));
  near(s.gamma, gamma, 1e-12);
  near(s.apexZ, 39.55 + 6.43 / 2 / Math.tan(gamma), 1e-9);
  near(s.apexZ, 47.12, 0.05); // agrees with the published S
});

test('short exposed bullet (nose starts inside the case): silhouette is cut at the mouth', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.cartridge.lengths.L6 = 51.18 + 3; // only 3 mm of bullet outside
  const b = G.build(r).bullet;
  assert.ok(b.zc < 51.18, 'ogive starts inside');
  assert.deepEqual(b.exposed[0], { z: 51.18, r: 0 });
  assert.deepEqual(b.exposed[b.exposed.length - 1], { z: 54.18, r: 0 });
  // the radius at the mouth is the ogive radius there, not the full shank
  assert.ok(b.exposed[1].z === 51.18 && b.exposed[1].r < 7.85 / 2 - 1e-6 && b.exposed[1].r > 0.6);
  for (let i = 1; i < b.exposed.length; i++) assert.ok(b.exposed[i].z >= b.exposed[i - 1].z - 1e-9);
});

test('degenerate shoulders do not produce NaN or Infinity', () => {
  const flat = JSON.parse(JSON.stringify(rec('308_win')));
  flat.cartridge.powderChamber.P2 = flat.cartridge.collar.H1; // no cone
  let m = G.build(flat);
  assert.equal(m.ok, true);
  assert.equal(m.shoulder.apexZ, null);
  for (const p of m.profile) assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r));
  const zero = JSON.parse(JSON.stringify(rec('308_win')));
  zero.cartridge.lengths.L2 = zero.cartridge.lengths.L1;
  m = G.build(zero);
  assert.equal(m.shoulder, null);
  assert.ok(m.notes.some((n) => n.feature === 'shoulder'));
  for (const p of m.profile) assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r));
});

test('belted case without groove values also reports the belt', () => {
  const r = JSON.parse(JSON.stringify(rec('300_win_mag')));
  delete r.cartridge.caseHead.E;
  const m = G.build(r);
  assert.deepEqual(m.notes.find((n) => n.feature === 'groove').missing, ['E']);
  assert.ok(m.notes.some((n) => n.feature === 'belt'));
});

test('profile has no consecutive duplicate points', () => {
  for (const r of data) {
    const p = G.build(r).profile;
    for (let i = 1; i < p.length; i++) assert.ok(Math.hypot(p[i].z - p[i - 1].z, p[i].r - p[i - 1].r) > 1e-9, `${r.key} #${i}`);
  }
});

test('chamfer flag follows the drawn outline', () => {
  assert.equal(model('223_rem').chamfer, true);
  assert.equal(model('22_long_rifle').chamfer, false);
  const r = JSON.parse(JSON.stringify(rec('223_rem')));
  delete r.cartridge.caseHead.beta;
  assert.equal(G.build(r).chamfer, false);
});
