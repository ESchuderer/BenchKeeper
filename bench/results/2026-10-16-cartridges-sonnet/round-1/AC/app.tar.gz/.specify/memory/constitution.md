# C.I.P. Cartridge Reference Constitution

## Core Principles

### I. Static, Zero-Dependency Runtime
The app is plain HTML, CSS and JavaScript. It MUST NOT use a framework, a build step, server code,
runtime dependencies, or network requests of any kind (no CDNs, web fonts, analytics). It MUST work
when `index.html` is opened from disk (`file://`) in Chromium and when the folder is served by any
static file server. Consequently: no ES-module imports across files and no `fetch` of local files;
the data ships as a classic script and code files are classic scripts that share one namespace.
Rationale: `file://` forbids module loading and cross-file fetches; a reference must open anywhere.
Development tools (test runner, browser driver) MAY be npm devDependencies; the app never needs them.

### II. Data Fidelity
The 25 supplied records are the only data. Code MUST NOT add, change, round, convert, fetch or
invent a number. Values are shown as published (decimal point, no thousands separator, names
verbatim). When a value a rule needs is missing, the feature is left out and the missing value is
named to the user; a default is never substituted. Rationale: engineers rely on the published figure.

### III. Test-First (NON-NEGOTIABLE)
Tests are written and seen failing before the code that satisfies them (red, green, refactor).
Geometry, formatting, filtering and routing logic MUST be pure functions covered by unit tests
(Node 22 built-in runner). End-to-end behaviour MUST be verified in a real Chromium from `file://`
as well as over a static server. A task is not done until its tests pass and the run is reported
honestly, including failures and skipped checks.

### IV. Technical Precision
The drawing is computed from record values by the stated geometry rules, true to scale
(1 SVG user unit = 1 mm), never hand-drawn per cartridge. Dimension labels MUST NOT overlap each
other or the outline; this is checked by measurement, not by eye. Typography is calm and dense with
tabular numbers.

### V. Accessible, Printable, Responsive
Use semantic HTML with accessible names (the drawing is named "<name> drawing"). Screen output
follows the system light/dark setting; print is always black on white. A detail view prints on one
A4 portrait page with every drawing label legible and no navigation or controls. The app MUST be
usable at phone width, and each detail view has its own address that survives reload.

## Additional Constraints

- Runtime: Node.js 22 for development only. Interface language is English.
- Layout: `index.html` in the project root with its CSS and JavaScript files beside or below it.
- Scope: one static app; no accounts, storage services or analytics.

## Development Workflow

- Process follows Spec Kit: constitution, specify, clarify, plan, tasks, analyze, implement, then
  review. Specs, plans and tasks live under `specs/`.
- Commits are small and made only on request; the default branch is not committed to directly.
- Before completion: unit tests, browser tests from `file://`, a visual check of the drawings
  (screen and print) and a review pass have been run, and their results reported.

## Governance

This constitution supersedes other practices. Amendments are made through the constitution command,
with a reasoned version bump: MAJOR for removed or redefined principles, MINOR for new or materially
expanded guidance, PATCH for clarifications. Every plan and review MUST check compliance with the
principles above; deviations MUST be justified in the plan's complexity section.

**Version**: 1.0.0 | **Ratified**: 2026-10-16 | **Last Amended**: 2026-10-16
