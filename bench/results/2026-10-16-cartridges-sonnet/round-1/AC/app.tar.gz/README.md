# C.I.P. cartridge reference

A static reference of 25 C.I.P. cartridges: searchable list, per-cartridge detail with every cartridge and
chamber value, a true-to-scale generated section drawing, and a one-page A4 print.

**Use it:** open `index.html` directly in a browser (works from `file://`), or serve the folder with any
static server (`python3 -m http.server`). Plain HTML, CSS and JavaScript; no build step, no runtime
dependencies, no network requests.

| Address | View |
|---------|------|
| `index.html` | list with search and family filter |
| `index.html#/cartridge/308_win` | detail view (bookmarkable) |

**Data:** `data/cartridges.jsonl` is the source (OpenBallistics, MIT, commit e83db43); `js/data.js` is generated from it
(`npm run build:data`) because `file://` cannot `fetch` local files.

**Develop** (Node.js 22; dev dependencies only):

```sh
npm install
npm test                         # unit tests: formatting, search, geometry, drawing layout, views, data
npx playwright install chromium  # once, for the browser tests
npm run test:e2e                 # file:// and static server: lists, details, drawing overlap, print, network
```

Specification, plan, decisions and task log: `specs/001-cartridge-reference/`.
