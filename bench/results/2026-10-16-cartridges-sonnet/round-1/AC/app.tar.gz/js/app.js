(function () {
  'use strict';
  var CIP = window.CIP;
  var app = document.getElementById('app');
  var state = { text: '', family: '' };
  var firstRender = true;
  var rendered = null; // hash of the view on screen

  function byKey(key) {
    for (var i = 0; i < CIP.data.length; i++) if (CIP.data[i].key === key) return CIP.data[i];
    return null;
  }

  function updateList() {
    var shown = CIP.search.filter(CIP.data, state);
    document.getElementById('list-rows').innerHTML = CIP.views.listRows(shown);
    document.getElementById('count').textContent = CIP.search.countText(shown.length);
  }

  function showList() {
    state = { text: '', family: '' };
    app.innerHTML = CIP.views.listView(CIP.data, state);
    document.getElementById('search').addEventListener('input', function (e) { state.text = e.target.value; updateList(); });
    document.getElementById('family').addEventListener('change', function (e) { state.family = e.target.value; updateList(); });
    document.title = 'Cartridges – C.I.P. cartridges';
  }

  function showDetail(record) {
    app.innerHTML = CIP.views.detailView(record);
    var print = document.getElementById('print-button');
    if (print) print.addEventListener('click', function () { window.print(); });
    document.title = record.name + ' – C.I.P. cartridges';
  }

  function showNotFound(key) {
    app.innerHTML = CIP.views.notFoundView(key);
    document.title = 'Not found – C.I.P. cartridges';
  }

  function route() {
    if (rendered === location.hash) return;
    rendered = location.hash;
    var m = /^#\/cartridge\/([^/?#]*)/.exec(location.hash);
    if (m) {
      var key;
      try { key = decodeURIComponent(m[1]); } catch (e) { key = m[1]; }
      var record = byKey(key);
      if (record) showDetail(record); else showNotFound(key);
    } else {
      showList();
    }
    window.scrollTo(0, 0);
    if (!firstRender) {
      var h = document.getElementById('view-heading');
      if (h) h.focus({ preventScroll: true });
    }
    firstRender = false;
  }

  window.addEventListener('hashchange', route);
  // Render on the click itself instead of waiting for the asynchronous hashchange event, so the new
  // view is in place as soon as the click returns.
  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a[href^="#/"]') : null;
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    var href = a.getAttribute('href');
    if (location.hash !== href) location.hash = href; else rendered = null; // same address: show it afresh
    route();
  });
  route();
})();
