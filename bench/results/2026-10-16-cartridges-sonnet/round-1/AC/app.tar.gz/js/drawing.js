(function (root, factory) {
  var dep = function (n) { return (typeof module === 'object' && module.exports) ? require('./' + n + '.js') : root.CIP[n]; };
  var api = factory(dep);
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { root.CIP = root.CIP || {}; root.CIP.drawing = api; }
})(typeof window !== 'undefined' ? window : this, function (dep) {
  'use strict';
  var format = dep('format');
  var geometry = dep('geometry');
  var esc = format.escapeHtml;

  var PAGE_WIDTH_MM = 194; // A4 width minus 2 x 8 mm margins (print.css)

  var has = geometry.has;
  function fmt(n) { return String(Math.round(n * 1e4) / 1e4 + 0); }
  // Monospace labels: the width is fixed by textLength, so it never depends on the font in use.
  function textWidth(s, size) { return s.length * 0.6 * size; }

  // ---- label lanes (research D21) ------------------------------------------------------
  // Items {id, x, w}: the label box starts at x + pad and is w wide; its leader stands at x.
  // Processing from right to left, a label's lane is one above every label whose leader lies
  // inside its box, so no box meets another box or another label's leader.
  function assignLanes(items, pad) {
    var order = items.map(function (it, i) { return { it: it, i: i }; })
      .sort(function (a, b) { return (b.it.x - a.it.x) || (b.i - a.i); });
    var lane = {}; var done = [];
    order.forEach(function (o) {
      var it = o.it; var hi = it.x + pad + it.w + pad; var l = 0;
      done.forEach(function (d) {
        if (d.x >= it.x && d.x <= hi) l = Math.max(l, lane[d.id] + 1);
      });
      lane[it.id] = l; done.push(it);
    });
    return lane;
  }

  function segHitsBox(p, q, b, m) {
    var x0 = b.x - m; var x1 = b.x + b.w + m; var y0 = b.y - m; var y1 = b.y + b.h + m;
    var t0 = 0; var t1 = 1; var dx = q.x - p.x; var dy = q.y - p.y;
    var checks = [[-dx, p.x - x0], [dx, x1 - p.x], [-dy, p.y - y0], [dy, y1 - p.y]];
    for (var i = 0; i < 4; i++) {
      var pp = checks[i][0]; var qq = checks[i][1];
      if (pp === 0) { if (qq < 0) return false; } else {
        var t = qq / pp;
        if (pp < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return t0 <= t1;
  }

  // ---- outline polylines in drawing coordinates (x = z, y = -r above / +r below) -------
  function mapPts(pts, sign) { return pts.map(function (p) { return { x: p.z, y: sign * p.r }; }); }

  // The mouth face is only a line where the case wall has thickness at the mouth (not on heeled cases).
  function hasMouthFace(model) { return model.mouth.rInner !== null && model.mouth.rInner < model.mouth.rOuter - 1e-9; }
  function lowerStartR(model) { return model.walls.pocket ? model.walls.pocket.d / 2 : 0; }
  function pocketPoints(pk) { return [{ x: 0, y: pk.d / 2 }, { x: pk.depth, y: pk.d / 2 }, { x: pk.depth, y: 0 }]; }
  function cavityPoints(model) { return [{ x: model.walls.w, y: 0 }].concat(mapPts(model.inner, 1)); }
  function pointsD(pts) { return pts.map(function (p, i) { return (i ? 'L' : 'M') + fmt(p.x) + ' ' + fmt(p.y); }).join(' '); }

  function outlinePolylines(model) {
    var flat = geometry.flatten(model.outer);
    var out = [];
    var upper = [{ x: 0, y: 0 }].concat(mapPts(flat, -1));
    var lower = [{ x: 0, y: lowerStartR(model) }].concat(mapPts(flat.slice(1), 1));
    if (hasMouthFace(model)) {
      upper.push({ x: model.mouth.z, y: -model.mouth.rInner });
      lower.push({ x: model.mouth.z, y: model.mouth.rInner });
    }
    out.push(upper, lower);
    if (model.bullet) {
      var b = geometry.flatten(model.bullet.cmds);
      out.push([{ x: model.bullet.zb, y: 0 }].concat(mapPts(b, -1)), [{ x: model.bullet.zb, y: 0 }].concat(mapPts(b, 1)));
    }
    if (model.inner) {
      out.push(cavityPoints(model));
      if (model.walls.pocket) out.push(pocketPoints(model.walls.pocket));
    }
    return out;
  }

  // ---- layout --------------------------------------------------------------------------
  function layout(model, record) {
    var c = record.cartridge; var h = c.caseHead; var pc = c.powderChamber; var co = c.collar;
    var jc = c.junctionCone || {}; var ln = c.lengths; var pj = c.projectile;
    var L3 = ln.L3; var L6 = ln.L6; var bullet = model.bullet;
    var tipZ = has(L6) && bullet ? L6 : L3;

    var rTop = 0;
    model.skeleton.forEach(function (p) { rTop = Math.max(rTop, p.r); });
    if (bullet) rTop = Math.max(rTop, bullet.R);

    var targetW = Math.max(tipZ + 14, 62);
    var fs = Math.max(1, targetW / 44);
    var boxH = 1.1 * fs; var ascent = 0.85 * fs;
    var ah = 0.6 * fs; var aw = 0.2 * fs; var gap = 1.0 * fs;
    var topPitch = 1.9 * fs; var botPitch = 1.45 * fs; var pad = 0.4 * fs;
    function textW(s) { return textWidth(s, fs); }

    var labels = []; var dims = [];
    var bounds = { x0: -1.5 * fs, x1: tipZ + 1.5 * fs, y0: -rTop, y1: rTop };
    function grow(b) {
      bounds.x0 = Math.min(bounds.x0, b.x); bounds.x1 = Math.max(bounds.x1, b.x + b.w);
      bounds.y0 = Math.min(bounds.y0, b.y); bounds.y1 = Math.max(bounds.y1, b.y + b.h);
    }
    function growPt(x, y) { grow({ x: x, y: y, w: 0, h: 0 }); }
    function addLabel(id, text, x, top) {
      var b = { id: id, text: text, x: x, y: top, w: textW(text), h: boxH, baseline: top + ascent };
      labels.push(b); grow(b); return b;
    }
    function arrow(tipX, tipY, dx, dy) { return { tip: { x: tipX, y: tipY }, dir: { x: dx, y: dy }, len: ah, half: aw }; }
    function seg(kind, x1, y1, x2, y2) { return { kind: kind, p: { x: x1, y: y1 }, q: { x: x2, y: y2 } }; }

    // -- lengths above the outline, measured from the head face, shortest nearest
    var r0 = (model.outer[1] && model.outer[1].z === 0) ? model.outer[1].r : 0;
    // Where the shoulder is not drawn (straight fallback) the extension lines start on the actual outline.
    function outlineR(z) { var v = geometry.outerRadiusAt(model, z); return v === null ? co.H2 / 2 : v; }
    var lens = [{ id: 'R', sym: 'R', z: h.R, r: h.R1 / 2 }];
    if (has(ln.L1)) lens.push({ id: 'L1', sym: 'L1', z: ln.L1, r: model.straight ? outlineR(ln.L1) : pc.P2 / 2 });
    if (has(ln.L2)) lens.push({ id: 'L2', sym: 'L2', z: ln.L2, r: model.straight ? outlineR(ln.L2) : co.H1 / 2 });
    lens.push({ id: 'L3', sym: 'L3', z: L3, r: co.H2 / 2 });
    if (bullet && has(L6)) lens.push({ id: 'L6', sym: 'L6', z: L6, r: bullet.m / 2 });
    lens.sort(function (a, b) { return a.z - b.z; });
    lens.forEach(function (d, i) {
      var y = -(rTop + gap + 0.5 * fs + i * topPitch);
      var text = d.sym + ' ' + format.number(d.z);
      var w = textW(text); var narrow = d.z < w + 2.4 * ah;
      var lines = []; var arrows = [];
      lines.push(seg('dim', 0, y, d.z, y));
      lines.push(seg('ext', 0, -r0, 0, y - 0.4 * fs));
      lines.push(seg('ext', d.z, -d.r, d.z, y - 0.4 * fs));
      if (narrow) {
        lines.push(seg('stub', -1.4 * ah, y, 0, y)); lines.push(seg('stub', d.z, y, d.z + 1.4 * ah, y));
        arrows.push(arrow(0, y, 1, 0), arrow(d.z, y, -1, 0));
      } else {
        arrows.push(arrow(0, y, -1, 0), arrow(d.z, y, 1, 0));
      }
      var x = narrow ? d.z + 1.4 * ah + 0.5 * fs : d.z / 2 - w / 2;
      var b = addLabel(d.id, text, x, y - 0.3 * fs - ascent);
      growPt(0, y - 0.4 * fs); growPt(-1.4 * ah, y);
      dims.push({ id: d.id, kind: 'length', lines: lines, arrows: arrows, label: b });
    });

    // -- diameters and the shoulder angle below the outline
    var items = [];
    function diam(id, sym, value, z, r) { items.push({ id: id, kind: 'diameter', text: sym + ' ' + format.number(value), z: z, r: r }); }
    diam('R1', 'R1', h.R1, h.R / 2, h.R1 / 2);
    if (has(h.E1)) diam('E1', 'E1', h.E1, h.R + (has(h.eMin) ? h.eMin / 2 : 0), h.E1 / 2);
    diam('P1', 'P1', pc.P1, model.zStart, pc.P1 / 2);
    // P2 and H1 sit on the shoulder corners, so they are only dimensioned when the shoulder is drawn.
    if (!model.straight) {
      diam('P2', 'P2', pc.P2, ln.L1, pc.P2 / 2);
      diam('H1', 'H1', co.H1, ln.L2, co.H1 / 2);
    }
    diam('H2', 'H2', co.H2, L3, co.H2 / 2);
    if (bullet && has(pj.G1)) {
      var zEnd = Math.max(bullet.zc, L3);
      diam('G1', 'G1', pj.G1, (L3 + zEnd) / 2, pj.G1 / 2);
    }
    if (!model.straight && jc.alpha !== undefined) {
      items.push({
        id: 'alpha', kind: 'angle', text: 'α ' + format.angle(jc.alpha),
        z: (ln.L1 + ln.L2) / 2, r: (pc.P2 / 2 + co.H1 / 2) / 2
      });
    }
    items.forEach(function (it) { it.w = textW(it.text); it.x = it.z; });
    var lanes = assignLanes(items, pad);
    items.forEach(function (it) {
      var top = rTop + gap + lanes[it.id] * botPitch;
      var b = addLabel(it.id, it.text, it.z + pad, top);
      var lines = []; var arrows = [];
      if (it.kind === 'diameter') {
        lines.push(seg('dim', it.z, -it.r, it.z, it.r));
        arrows.push(arrow(it.z, -it.r, 0, -1), arrow(it.z, it.r, 0, 1));
      } else {
        arrows.push(arrow(it.z, it.r, 0, -1));
      }
      lines.push(seg('ext', it.z, it.r, it.z, top));
      growPt(it.z, top);
      dims.push({ id: it.id, kind: it.kind, lines: lines, arrows: arrows, label: b });
    });

    // -- title block: first free slot below the outline, else below everything
    var margin = 1.0 * fs;
    function titleLines(s) {
      return [record.name, 'C.I.P. table ' + record.tab + ' · revised ' + record.revised, 'Dimensions in mm', 'Scale ' + s.toFixed(2) + ':1 (A4 print)'];
    }
    var tlines = titleLines(PAGE_WIDTH_MM / targetW); // the scale text is rewritten once the width is final
    var tfs = 0.85 * fs; var tPad = 0.7 * fs; var tLine = 1.3 * tfs;
    var tw = Math.max.apply(null, tlines.map(function (s) { return textWidth(s, tfs); })) + 2 * tPad;
    var th = tlines.length * tLine + 2 * tPad - 0.3 * tfs;
    var segs = []; dims.forEach(function (d) { d.lines.forEach(function (s) { segs.push(s); }); });
    function free(x, y) {
      var b = { x: x, y: y, w: tw, h: th };
      for (var i = 0; i < labels.length; i++) {
        var o = labels[i];
        if (x < o.x + o.w + 0.5 * fs && o.x < x + tw + 0.5 * fs && y < o.y + o.h + 0.5 * fs && o.y < y + th + 0.5 * fs) return false;
      }
      for (var j = 0; j < segs.length; j++) if (segHitsBox(segs[j].p, segs[j].q, b, 0.5 * fs)) return false;
      return true;
    }
    var yFirst = rTop + gap; var yLimit = bounds.y1; var tx = null; var ty = null;
    for (var yy = yFirst; yy + th <= yLimit + 1e-9 && tx === null; yy += 0.5 * fs) {
      for (var xx = bounds.x0; xx + tw <= bounds.x1 + 1e-9; xx += 0.5 * fs) {
        if (free(xx, yy)) { tx = xx; ty = yy; break; }
      }
    }
    if (tx === null) { tx = bounds.x1 - tw; ty = Math.max(yLimit, yFirst) + gap; }
    var title = { id: 'title', x: tx, y: ty, w: tw, h: th, lines: tlines, pad: tPad, lineH: tLine, fs: tfs };
    grow(title);

    // -- final view box; narrow cartridges are centred in a minimum width
    var x0 = bounds.x0 - margin; var x1 = bounds.x1 + margin;
    var W = x1 - x0;
    if (W < targetW) { var extra = (targetW - W) / 2; x0 -= extra; x1 += extra; W = targetW; }
    var viewBox = { x: x0, y: bounds.y0 - margin, w: W, h: bounds.y1 - bounds.y0 + 2 * margin };
    title.lines = titleLines(PAGE_WIDTH_MM / W);

    return { fs: fs, viewBox: viewBox, labels: labels, dims: dims, title: title, rTop: rTop, tipZ: tipZ };
  }

  function printScale(l) { return PAGE_WIDTH_MM / l.viewBox.w; }

  // ---- SVG -----------------------------------------------------------------------------
  function pathD(cmds, mirror, startR) {
    var parts = []; var y = function (r) { return fmt(mirror ? r : -r); };
    cmds.forEach(function (c, i) {
      if (c.c === 'M') parts.push('M' + fmt(c.z) + ' ' + y(i === 0 && startR !== undefined ? startR : c.r));
      else if (c.c === 'L') parts.push('L' + fmt(c.z) + ' ' + y(c.r));
      else parts.push('A' + fmt(c.rx) + ' ' + fmt(c.ry) + ' 0 0 ' + (mirror ? 1 - c.sweep : c.sweep) + ' ' + fmt(c.z) + ' ' + y(c.r));
    });
    return parts.join(' ');
  }

  function arrowPath(a) {
    var px = -a.dir.y; var py = a.dir.x;
    var bx = a.tip.x - a.dir.x * a.len; var by = a.tip.y - a.dir.y * a.len;
    return 'M' + fmt(a.tip.x) + ' ' + fmt(a.tip.y) + ' L' + fmt(bx + px * a.half) + ' ' + fmt(by + py * a.half) +
      ' L' + fmt(bx - px * a.half) + ' ' + fmt(by - py * a.half) + ' Z';
  }

  function textEl(cls, id, x, baseline, w, fsz, text) {
    return '<text class="' + cls + '"' + (id ? ' data-id="' + esc(id) + '"' : '') + ' x="' + fmt(x) + '" y="' + fmt(baseline) +
      '" font-size="' + fmt(fsz) + '" textLength="' + fmt(w) + '" lengthAdjust="spacingAndGlyphs">' + esc(text) + '</text>';
  }

  function render(record, prebuilt) {
    var model = prebuilt || geometry.buildModel(record);
    if (!model.ok) return '';
    var l = layout(model, record);
    var vb = l.viewBox; var fs = l.fs;
    var L3 = record.cartridge.lengths.L3; var bullet = model.bullet;
    var tipZ = l.tipZ;
    var big = l.rTop + 2;
    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img" aria-labelledby="drawing-title" aria-describedby="drawing-desc"' +
      ' viewBox="' + fmt(vb.x) + ' ' + fmt(vb.y) + ' ' + fmt(vb.w) + ' ' + fmt(vb.h) + '" preserveAspectRatio="xMidYMid meet" data-rim="' + esc(model.rimType) + '">');
    out.push('<title id="drawing-title">' + esc(record.name) + ' drawing</title>');
    out.push('<desc id="drawing-desc">Half-section drawing of ' + esc(record.name) + ', ' + esc(model.rimType) + ' rim: outside view above the axis, section with hatched walls below. Dimensions in mm, 1 unit = 1 mm.</desc>');
    out.push('<defs>' +
      '<pattern id="hatch-case" patternUnits="userSpaceOnUse" width="0.9" height="0.9" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="0.9"/></pattern>' +
      '<pattern id="hatch-bullet" patternUnits="userSpaceOnUse" width="0.9" height="0.9" patternTransform="rotate(-45)"><rect class="hatch-bg" width="0.9" height="0.9"/><line class="hatch-line" x1="0" y1="0" x2="0" y2="0.9"/></pattern>' +
      '<clipPath id="clip-exposed"><rect x="' + fmt(L3) + '" y="' + fmt(-big) + '" width="' + fmt(tipZ - L3 + 1) + '" height="' + fmt(2 * big) + '"/></clipPath>' +
      '</defs>');

    // section (lower half): hatched metal = outer profile - cavity - primer pocket
    var solid = pathD(model.outer, true) + ' L' + fmt(L3) + ' 0 Z';
    if (model.inner) solid += ' ' + pointsD(cavityPoints(model).concat([{ x: L3, y: 0 }])) + ' Z';
    if (model.walls.pocket) solid += ' M0 0 ' + pointsD(pocketPoints(model.walls.pocket)).replace(/^M/, 'L') + ' Z';
    out.push('<path class="solid" fill-rule="evenodd" d="' + solid + '" fill="url(#hatch-case)"/>');
    if (bullet) out.push('<path class="bullet-section" d="' + pathD(bullet.cmds, true) + ' Z" fill="url(#hatch-bullet)"/>');

    // outlines
    var mouthFace = hasMouthFace(model);
    out.push('<path class="outline case-upper" d="' + pathD(model.outer, false) + (mouthFace ? ' L' + fmt(L3) + ' ' + fmt(-model.mouth.rInner) : '') + '"/>');
    if (bullet) out.push('<path class="outline bullet-upper" d="' + pathD(bullet.cmds, false) + '" clip-path="url(#clip-exposed)"/>');
    out.push('<path class="outline case-lower" d="' + pathD(model.outer, true, lowerStartR(model)) + (mouthFace ? ' L' + fmt(L3) + ' ' + fmt(model.mouth.rInner) : '') + '"/>');
    if (bullet) out.push('<path class="outline bullet-lower" d="' + pathD(bullet.cmds, true) + '"/>');
    if (model.inner) {
      out.push('<path class="outline cavity" d="' + pointsD(cavityPoints(model)) + '"/>');
    }
    if (model.walls.pocket) out.push('<path class="outline pocket" d="' + pointsD(pocketPoints(model.walls.pocket)) + '"/>');
    out.push('<line class="centre" x1="' + fmt(-1.5 * fs) + '" y1="0" x2="' + fmt(tipZ + 1.5 * fs) + '" y2="0"/>');

    // dimensions and labels
    l.dims.forEach(function (d) {
      out.push('<g class="dimension" data-id="' + esc(d.id) + '">');
      d.lines.forEach(function (s) {
        out.push('<line class="' + (s.kind === 'ext' ? 'ext-line' : 'dim-line') + '" x1="' + fmt(s.p.x) + '" y1="' + fmt(s.p.y) + '" x2="' + fmt(s.q.x) + '" y2="' + fmt(s.q.y) + '"/>');
      });
      d.arrows.forEach(function (a) { out.push('<path class="arrow" d="' + arrowPath(a) + '"/>'); });
      out.push('</g>');
    });
    l.labels.forEach(function (b) { out.push(textEl('label', b.id, b.x, b.baseline, b.w, fs, b.text)); });

    // title block
    var t = l.title;
    out.push('<g class="title-block"><rect x="' + fmt(t.x) + '" y="' + fmt(t.y) + '" width="' + fmt(t.w) + '" height="' + fmt(t.h) + '"/>');
    t.lines.forEach(function (s, i) {
      out.push(textEl(i === 0 ? 'title-name' : 'title-line', null, t.x + t.pad, t.y + t.pad + i * t.lineH + 0.85 * t.fs, textWidth(s, t.fs), t.fs, s));
    });
    out.push('</g></svg>');
    return out.join('');
  }

  return { PAGE_WIDTH_MM: PAGE_WIDTH_MM, layout: layout, render: render, printScale: printScale, outlinePolylines: outlinePolylines, assignLanes: assignLanes };
});
