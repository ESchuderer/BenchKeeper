(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { root.CIP = root.CIP || {}; root.CIP.format = api; }
})(typeof window !== 'undefined' ? window : this, function () {
  'use strict';

  // Numbers are shown as published: String() of the JSON number (4150.0 -> "4150").
  function number(n) { return String(n); }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }

  var ANGLE_KEYS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
  function isAngleKey(key) { return ANGLE_KEYS.indexOf(key) !== -1; }

  // 40 -> 40°; {degrees, minutes, seconds} -> 39°59'49" (all three parts, research D7).
  function angle(a) {
    if (typeof a === 'number') return number(a) + '°';
    return number(a.degrees) + '°' + number(a.minutes) + "'" + number(a.seconds) + '"';
  }

  function degrees(a) {
    if (typeof a === 'number') return a;
    return a.degrees + a.minutes / 60 + a.seconds / 3600;
  }

  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  function symbol(key) { return own(SYMBOLS, key) ? SYMBOLS[key] : key; }

  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  function unit(key) {
    if (isAngleKey(key)) return '';
    return own(UNITS, key) ? UNITS[key] : 'mm';
  }

  function isTolKey(key) { return /Tol$/.test(key); }

  // Value of `key` in a section object, with its tolerance next to it (39.62 -0.2).
  function valueText(section, key) {
    var v = section[key];
    var text = isAngleKey(key) ? angle(v) : number(v);
    var tolKey = key + 'Tol';
    if (own(section, tolKey)) text += ' ' + number(section[tolKey]);
    return text;
  }

  function sectionRows(section) {
    // A tolerance is folded into its value; one without a value of its own stays visible.
    return Object.keys(section).filter(function (k) {
      return !(isTolKey(k) && own(section, k.slice(0, -3)));
    }).map(function (k) {
      return { field: k, symbol: symbol(k), value: valueText(section, k), unit: unit(k) };
    });
  }

  var CARTRIDGE_SECTIONS = [
    { key: 'caseHead', title: 'Case head' }, { key: 'collar', title: 'Collar' },
    { key: 'junctionCone', title: 'Junction cone' }, { key: 'lengths', title: 'Lengths' },
    { key: 'misc', title: 'Miscellaneous' }, { key: 'powderChamber', title: 'Powder chamber' },
    { key: 'pressures', title: 'Pressures' }, { key: 'projectile', title: 'Projectile' }
  ];
  var CHAMBER_SECTIONS = [
    { key: 'barrel', title: 'Barrel' }, { key: 'breech', title: 'Breech' },
    { key: 'collar', title: 'Collar' }, { key: 'grooves', title: 'Grooves' },
    { key: 'junctionCone', title: 'Junction cone' }, { key: 'lengths', title: 'Lengths' },
    { key: 'powderChamber', title: 'Powder chamber' }, { key: 'rifling', title: 'Rifling' }
  ];

  // Sections in fixed order; absent or empty sections are left out.
  function sections(group, defs) {
    var out = [];
    defs.forEach(function (d) {
      var obj = group[d.key];
      if (!obj) return;
      var rows = sectionRows(obj);
      if (rows.length) out.push({ key: d.key, title: d.title, rows: rows });
    });
    return out;
  }

  return {
    number: number, escapeHtml: escapeHtml, angle: angle, degrees: degrees, isAngleKey: isAngleKey,
    symbol: symbol, unit: unit, valueText: valueText, sectionRows: sectionRows, sections: sections,
    CARTRIDGE_SECTIONS: CARTRIDGE_SECTIONS, CHAMBER_SECTIONS: CHAMBER_SECTIONS
  };
});
