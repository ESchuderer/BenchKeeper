(function (root, factory) {
  var dep = function (n) { return (typeof module === 'object' && module.exports) ? require('./' + n + '.js') : root.CIP[n]; };
  var api = factory(dep);
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { root.CIP = root.CIP || {}; root.CIP.geometry = api; }
})(typeof window !== 'undefined' ? window : this, function (dep) {
  'use strict';
  var format = dep('format');

  // Everything here is computed from the record. The only constants are those fixed by the
  // drawing rules (seating depths, cylinder fractions, meplats, pocket table, wall formulas).
  // z runs along the axis from the head face, r is the radius (>= 0, upper half).

  function has(v) { return typeof v === 'number' && isFinite(v); }
  function rad(deg) { return deg * Math.PI / 180; }
  function tanDeg(angle) { return Math.tan(rad(format.degrees(angle))); }

  // ---- rule 1 ------------------------------------------------------------------------
  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    var ratio = record.cartridge.caseHead.R1 / record.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // ---- rule 8: primer pocket ---------------------------------------------------------
  function primerPocket(primerType) {
    var d = null; var depth = null;
    if (['sp', 'spm', 'sr'].indexOf(primerType) !== -1) d = 4.45;
    else if (['lp', 'lpm', 'lr', 'lrm'].indexOf(primerType) !== -1) d = 5.33;
    if (['sp', 'spm', 'sr', 'lp', 'lpm'].indexOf(primerType) !== -1) depth = 3.04;
    else if (['lr', 'lrm'].indexOf(primerType) !== -1) depth = 3.3;
    return d === null ? null : { d: d, depth: depth };
  }

  // ---- rule 7: bullet parameters -----------------------------------------------------
  function bulletParams(record) {
    var a = record.annotations || {};
    var G1 = record.cartridge.projectile && record.cartridge.projectile.G1;
    if (!has(G1)) return null;
    var shape = a.defaultBulletShape;
    var pistol = a.category === 'pistol';
    var sf; var k; var m;
    switch (shape) {
      case 'pointy': sf = 1.0; k = 0.40; m = Math.max(0.08 * G1, 1.27); break;
      case 'rounded': sf = pistol ? 0.4 : 0.8; k = pistol ? 0.65 : 0.55; m = 0.15 * G1; break;
      case 'flat': sf = pistol ? 0.4 : 0.8; k = pistol ? 0.70 : 0.60; m = 0.55 * G1; break;
      case 'semi_wadcutter': sf = 0.6; k = 0.78; m = 0.6 * G1; break;
      default: return null;
    }
    return { shape: shape, s: sf * G1, k: k, m: m };
  }

  // ---- arcs --------------------------------------------------------------------------
  // SVG endpoint-to-centre conversion for axis-aligned arcs of at most 180 degrees.
  // sweep 1 = clockwise as drawn (z to the right, r up). Computed in (z, y = -r).
  function arcCenter(z0, r0, z1, r1, rx, ry, sweep) {
    var x1 = z0; var y1 = -r0; var x2 = z1; var y2 = -r1;
    var dx2 = (x1 - x2) / 2; var dy2 = (y1 - y2) / 2;
    var lam = dx2 * dx2 / (rx * rx) + dy2 * dy2 / (ry * ry);
    if (lam > 1) { var sc = Math.sqrt(lam); rx *= sc; ry *= sc; }
    var num = rx * rx * ry * ry - rx * rx * dy2 * dy2 - ry * ry * dx2 * dx2;
    if (num < 0) num = 0;
    var den = rx * rx * dy2 * dy2 + ry * ry * dx2 * dx2;
    var coef = (den === 0 ? 0 : Math.sqrt(num / den)) * (sweep === 0 ? -1 : 1);
    var cxp = coef * (rx * dy2 / ry); var cyp = coef * (-(ry * dx2 / rx));
    var cx = cxp + (x1 + x2) / 2; var cy = cyp + (y1 + y2) / 2;
    var th1 = Math.atan2((dy2 - cyp) / ry, (dx2 - cxp) / rx);
    var th2 = Math.atan2((-dy2 - cyp) / ry, (-dx2 - cxp) / rx);
    var dth = th2 - th1;
    if (sweep === 0 && dth > 0) dth -= 2 * Math.PI;
    if (sweep === 1 && dth < 0) dth += 2 * Math.PI;
    return { cz: cx, cr: -cy, rx: rx, ry: ry, th1: th1, dth: dth };
  }

  function arcPoint(c, t) {
    var th = c.th1 + t * c.dth;
    return { z: c.cz + c.rx * Math.cos(th), r: c.cr - c.ry * Math.sin(th) };
  }

  // Command list -> polyline (arcs sampled in n steps).
  function flatten(cmds, n) {
    n = n || 48;
    var pts = []; var prev = null;
    cmds.forEach(function (c) {
      if (c.c === 'A') {
        var ctr = arcCenter(prev.z, prev.r, c.z, c.r, c.rx, c.ry, c.sweep);
        for (var i = 1; i <= n; i++) pts.push(i === n ? { z: c.z, r: c.r } : arcPoint(ctr, i / n));
      } else {
        pts.push({ z: c.z, r: c.r });
      }
      prev = c;
    });
    return pts;
  }

  function interpolate(pts, z) {
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1]; var b = pts[i];
      var lo = Math.min(a.z, b.z); var hi = Math.max(a.z, b.z);
      if (hi - lo < 1e-12) continue;
      if (z >= lo - 1e-12 && z <= hi + 1e-12) return a.r + (b.r - a.r) * (z - a.z) / (b.z - a.z);
    }
    return null;
  }

  function outerRadiusAt(model, z) { return interpolate(flatten(model.outer), z); }

  function innerRadiusAt(model, z) {
    var pts = model.inner;
    if (!pts || !pts.length) return null;
    if (z <= pts[0].z) return pts[0].r;
    if (z >= pts[pts.length - 1].z) return pts[pts.length - 1].r;
    return interpolate(pts, z);
  }

  // ---- model -------------------------------------------------------------------------
  function sym(keys) { return keys.map(format.symbol).join(', '); }
  function missing(obj, keys) { return keys.filter(function (k) { return !has(obj[k]); }); }

  function buildModel(record) {
    var c = record.cartridge || {};
    var h = c.caseHead || {}; var pc = c.powderChamber || {}; var co = c.collar || {};
    var jc = c.junctionCone || {}; var ln = c.lengths || {}; var pj = c.projectile || {};
    var a = record.annotations || {};
    var notes = [];
    var R = h.R; var R1 = h.R1; var P1 = pc.P1; var P2 = pc.P2; var H1 = co.H1; var H2 = co.H2;
    var L1 = ln.L1; var L2 = ln.L2; var L3 = ln.L3; var L6 = ln.L6; var G1 = pj.G1;

    var core = missing({ R: R, R1: R1, P1: P1, L3: L3, H2: H2 }, ['R', 'R1', 'P1', 'L3', 'H2']);
    if (core.length) {
      return { ok: false, notes: ['Drawing not possible: ' + sym(core) + ' not published.'], outer: [], skeleton: [], inner: null, bullet: null };
    }

    var type = rimType(record);
    var cmds = [{ c: 'M', z: 0, r: 0 }];
    var sk = [{ z: 0, r: 0 }];
    function last() { return sk[sk.length - 1]; }
    function same(z, r) { return Math.abs(last().z - z) < 1e-12 && Math.abs(last().r - r) < 1e-12; }
    function line(z, r) {
      if (same(z, r)) return;
      cmds.push({ c: 'L', z: z, r: r }); sk.push({ z: z, r: r });
    }
    function arc(rx, ry, z, r, sweep) {
      cmds.push({ c: 'A', rx: rx, ry: ry, z: z, r: r, sweep: sweep }); sk.push({ z: z, r: r });
    }

    // rule 2: head face and rim edge
    var rimR = R1 / 2;
    if (type === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      line(0, rimR - rho);
      arc(rho, rho, rho, rimR, 1);
      arc(rho, rho, 2 * rho, rimR - rho, 1);
      if (2 * rho < R - 1e-12) line(R, rimR - rho);
    } else if (has(h.beta) || (h.beta && typeof h.beta === 'object')) {
      // beta present (number or d/m/s)
      if (has(h.f) && format.degrees(h.beta) < 90) {
        var ext = Math.min(h.f * tanDeg(h.beta), R1 / 4);
        line(0, rimR - ext); line(h.f, rimR); line(R, rimR);
      } else {
        if (!has(h.f)) notes.push('Head chamfer not drawn: f not published.');
        line(0, rimR); line(R, rimR);
      }
    } else {
      notes.push('Head chamfer not drawn: ' + sym(['beta'].concat(has(h.f) ? [] : ['f'])) + ' not published.');
      line(0, rimR); line(R, rimR);
    }

    // rule 3: extractor groove, belt, or plain step
    var groove = has(h.E) && has(h.E1) && has(h.eMin);
    var rampEnd = null; var zStart;
    if (groove) {
      line(R, h.E1 / 2); line(R + h.eMin, h.E1 / 2);
      if (type === 'belted') {
        if (has(h.R3) && h.delta !== undefined) {
          rampEnd = R + h.eMin + (h.R3 / 2 - h.E1 / 2) / tanDeg(h.delta);
          line(rampEnd, h.R3 / 2); line(h.E, h.R3 / 2);
        } else {
          notes.push('No belt drawn: ' + sym((has(h.R3) ? [] : ['R3']).concat(h.delta === undefined ? ['delta'] : [])) + ' not published.');
        }
      }
      line(h.E, P1 / 2);
      zStart = h.E;
    } else {
      if (type !== 'rimfire') notes.push('No extractor groove drawn: ' + sym(missing(h, ['E', 'E1', 'eMin'])) + ' not published.');
      line(R, P1 / 2);
      zStart = R;
    }

    // rules 4-6: body, shoulder, neck
    var bottleneckInputs = { alpha: jc.alpha, L1: L1, L2: L2, H1: H1, P2: P2 };
    var lacking = Object.keys(bottleneckInputs).filter(function (k) { return bottleneckInputs[k] === undefined || (typeof bottleneckInputs[k] === 'number' && !has(bottleneckInputs[k])); });
    var straight = lacking.length > 0;
    function fillet(p0, corner, p1, radius) {
      var d1 = { z: corner.z - p0.z, r: corner.r - p0.r }; var l1 = Math.hypot(d1.z, d1.r);
      var d2 = { z: p1.z - corner.z, r: p1.r - corner.r }; var l2 = Math.hypot(d2.z, d2.r);
      d1.z /= l1; d1.r /= l1; d2.z /= l2; d2.r /= l2;
      var cosT = Math.max(-1, Math.min(1, d1.z * d2.z + d1.r * d2.r));
      var theta = Math.acos(cosT);
      if (theta < 1e-6) return null;
      var t = Math.min(radius * Math.tan(theta / 2), 0.45 * l1, 0.45 * l2);
      var cross = d1.z * d2.r - d1.r * d2.z;
      return {
        start: { z: corner.z - d1.z * t, r: corner.r - d1.r * t },
        end: { z: corner.z + d2.z * t, r: corner.r + d2.r * t },
        radius: t / Math.tan(theta / 2), sweep: cross < 0 ? 1 : 0
      };
    }
    function corner(p0, p1, p2, radius) {
      var f = radius !== undefined && has(radius) ? fillet(p0, p1, p2, radius) : null;
      if (f) {
        cmds.push({ c: 'L', z: f.start.z, r: f.start.r });
        cmds.push({ c: 'A', rx: f.radius, ry: f.radius, z: f.end.z, r: f.end.r, sweep: f.sweep });
      } else {
        cmds.push({ c: 'L', z: p1.z, r: p1.r });
      }
      sk.push({ z: p1.z, r: p1.r });
    }
    var bodyEndZ; var bodyEndR;
    if (straight) {
      notes.push('Drawn as a straight case: ' + sym(lacking) + ' not published.');
      line(L3, H2 / 2);
      bodyEndZ = L3; bodyEndR = H2 / 2;
    } else {
      var p0 = { z: zStart, r: P1 / 2 }; var pA = { z: L1, r: P2 / 2 };
      var pB = { z: L2, r: H1 / 2 }; var pN = { z: L3, r: H2 / 2 };
      if (!has(jc.r1Min)) notes.push('Body-side shoulder corner not rounded: r1 min not published.');
      if (!has(jc.r2)) notes.push('Neck-side shoulder corner not rounded: r2 not published.');
      corner(p0, pA, pB, jc.r1Min);
      corner(pA, pB, pN, jc.r2);
      cmds.push({ c: 'L', z: pN.z, r: pN.r }); sk.push({ z: pN.z, r: pN.r });
      bodyEndZ = L1; bodyEndR = P2 / 2;
    }
    function bodyRadius(z) { return P1 / 2 + (bodyEndR - P1 / 2) * (z - zStart) / (bodyEndZ - zStart); }

    // rule 7: bullet
    var bp = null; var heeled = false; var tn = null; var tb = null;
    if (has(G1) && has(L6)) {
      bp = bulletParams(record);
      if (!bp) notes.push('Bullet not drawn: bullet shape not recognised.');
    } else {
      notes.push('Bullet not drawn: ' + sym(missing({ G1: G1, L6: L6 }, ['G1', 'L6'])) + ' not published.');
    }
    if (has(G1)) { tn = (H2 - G1) / 2; heeled = (H2 - G1) <= 0.015; }
    tb = Math.min(tn === null ? 0.6 : Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
    var exposedR = has(G1) ? (heeled ? H2 : G1) / 2 : null; // radius of the bullet where it leaves the mouth
    var tnEff = tn === null ? null : (heeled ? tb : tn);

    var bullet = null;
    if (bp) {
      var Rb = exposedR;
      var zb = L3 - bp.s; var lb = L6 - zb; var zc = zb + bp.k * lb; var n = L6 - zc;
      var bc = [{ c: 'M', z: zb, r: 0 }];
      if (heeled) {
        var heelR = (H2 - 2 * tb) / 2;
        bc.push({ c: 'L', z: zb, r: heelR }, { c: 'L', z: L3, r: heelR }, { c: 'L', z: L3, r: Rb });
      } else {
        bc.push({ c: 'L', z: zb, r: Rb });
      }
      bc.push({ c: 'L', z: zc, r: Rb });
      var rhoOgive = null;
      if (bp.shape === 'pointy') {
        var d = Rb - bp.m / 2;
        rhoOgive = (d * d + n * n) / (2 * d);
        bc.push({ c: 'A', rx: rhoOgive, ry: rhoOgive, z: L6, r: bp.m / 2, sweep: 1 });
      } else if (bp.shape === 'rounded') {
        bc.push({ c: 'A', rx: n, ry: Rb - bp.m / 2, z: L6, r: bp.m / 2, sweep: 1 });
      } else {
        bc.push({ c: 'L', z: L6, r: bp.m / 2 });
      }
      bc.push({ c: 'L', z: L6, r: 0 });
      bullet = { shape: bp.shape, s: bp.s, k: bp.k, m: bp.m, zb: zb, lb: lb, zc: zc, n: n, rho: rhoOgive, R: Rb, cmds: bc };
    }

    // rule 8: primer pocket, solid head, cavity
    var pocket = type === 'rimfire' ? null : primerPocket(a.primerType);
    if (type !== 'rimfire' && !pocket) notes.push('Primer pocket not drawn: primer type not recognised.');
    var wTerms = [2.5, 0.25 * P1 / 2];
    if (pocket) wTerms.push(pocket.depth + 1.5);
    if (rampEnd !== null) wTerms.push(rampEnd + tb);
    else if (groove) wTerms.push(h.E + tb);
    var w = Math.max.apply(null, wTerms);

    var inner = null;
    if (tnEff !== null) {
      inner = [{ z: w, r: bodyRadius(w) - tb }];
      if (straight) {
        if (bullet) {
          var z1 = Math.max(w, bullet.zb - bullet.s);
          var zbb = Math.max(z1, bullet.zb);
          if (z1 > w) inner.push({ z: z1, r: bodyRadius(z1) - tb });
          if (zbb > z1) inner.push({ z: zbb, r: bodyRadius(zbb) - tnEff });
        }
      } else {
        inner.push({ z: L1, r: P2 / 2 - tb }, { z: L2, r: H1 / 2 - tnEff });
      }
      inner.push({ z: L3, r: H2 / 2 - tnEff });
    } else {
      notes.push('Section walls not drawn: G1 not published.');
    }

    return {
      ok: true, rimType: type, straight: straight, heeled: heeled,
      zStart: zStart, outer: cmds, skeleton: sk, inner: inner, bullet: bullet,
      mouth: { z: L3, rOuter: H2 / 2, rInner: exposedR },
      walls: { tb: tb, tn: tn, w: w, pocket: pocket, rampEnd: rampEnd },
      notes: notes
    };
  }

  return {
    has: has, buildModel: buildModel, rimType: rimType, primerPocket: primerPocket, bulletParams: bulletParams,
    outerRadiusAt: outerRadiusAt, innerRadiusAt: innerRadiusAt, arcCenter: arcCenter, arcPoint: arcPoint, flatten: flatten
  };
});
