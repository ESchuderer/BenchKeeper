(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { root.CIP = root.CIP || {}; root.CIP.search = api; }
})(typeof window !== 'undefined' ? window : this, function () {
  'use strict';

  // Case and whitespace are ignored; nothing else is translated (research D11).
  function normalise(s) { return String(s).toLowerCase().replace(/\s+/g, ''); }

  function matchesText(record, needle) {
    if (needle === '') return true;
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (n) { return normalise(n).indexOf(needle) !== -1; });
  }

  function filter(records, opts) {
    var needle = normalise((opts && opts.text) || '');
    var family = (opts && opts.family) || '';
    return records.filter(function (r) {
      return (family === '' || r.family === family) && matchesText(r, needle);
    });
  }

  function countText(n) { return n + ' cartridges'; }

  return { normalise: normalise, filter: filter, countText: countText };
});
