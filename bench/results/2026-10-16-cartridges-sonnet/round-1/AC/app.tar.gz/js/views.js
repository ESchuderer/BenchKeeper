(function (root, factory) {
  var dep = function (n) { return (typeof module === 'object' && module.exports) ? require('./' + n + '.js') : root.CIP[n]; };
  var api = factory(dep);
  if (typeof module === 'object' && module.exports) { module.exports = api; }
  else { root.CIP = root.CIP || {}; root.CIP.views = api; }
})(typeof window !== 'undefined' ? window : this, function (dep) {
  'use strict';
  var format = dep('format');
  var search = dep('search');
  var esc = format.escapeHtml;

  var FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  function listRows(records) {
    if (records.length === 0) {
      return '<tr class="empty"><td colspan="3">No cartridge matches.</td></tr>';
    }
    return records.map(function (r) {
      return '<tr data-key="' + esc(r.key) + '">' +
        '<td><a href="#/cartridge/' + esc(r.key) + '">' + esc(r.name) + '</a></td>' +
        '<td>' + esc(r.family) + '</td>' +
        '<td class="num">' + format.number(r.cartridge.lengths.L3) + '</td></tr>';
    }).join('');
  }

  function listView(records, state) {
    state = state || {};
    var shown = search.filter(records, state);
    var family = state.family || '';
    var options = ['<option value=""' + (family === '' ? ' selected' : '') + '>All</option>']
      .concat(FAMILIES.map(function (f) {
        return '<option value="' + f + '"' + (family === f ? ' selected' : '') + '>' + f + '</option>';
      })).join('');
    return '<h1 id="view-heading" tabindex="-1">Cartridges</h1>' +
      '<form class="filters" role="search" onsubmit="return false">' +
      '<div class="field"><label for="search">Search</label>' +
      '<input id="search" type="search" autocomplete="off" spellcheck="false" value="' + esc(state.text || '') + '"></div>' +
      '<div class="field"><label for="family">Family</label>' +
      '<select id="family">' + options + '</select></div>' +
      '</form>' +
      '<p id="count" role="status" aria-live="polite">' + search.countText(shown.length) + '</p>' +
      '<table class="list" aria-label="Cartridge list">' +
      '<thead><tr><th scope="col">Name</th><th scope="col">Family</th><th scope="col" class="num">L3 (mm)</th></tr></thead>' +
      '<tbody id="list-rows">' + listRows(shown) + '</tbody></table>';
  }

  function notFoundView(key) {
    return '<h1 id="view-heading" tabindex="-1">Cartridge not found</h1>' +
      '<p>There is no cartridge with the address &ldquo;' + esc(key) + '&rdquo;.</p>' +
      '<p><a href="#/">All cartridges</a></p>';
  }

  function fact(label, html) { return '<div class="fact"><dt>' + label + '</dt><dd>' + html + '</dd></div>'; }

  function valueTables(group, defs) {
    return format.sections(group, defs).map(function (sec) {
      return '<table class="values"><caption>' + esc(sec.title) + '</caption>' +
        '<thead><tr><th scope="col">Symbol</th><th scope="col">Value</th><th scope="col">Unit</th></tr></thead><tbody>' +
        sec.rows.map(function (r) {
          return '<tr><th scope="row">' + esc(r.symbol) + '</th><td class="num">' + esc(r.value) + '</td><td class="unit">' + esc(r.unit) + '</td></tr>';
        }).join('') + '</tbody></table>';
    }).join('');
  }

  function capacityFact(record) {
    var c = record.annotations && record.annotations.publishedCapacity;
    if (!c) return '';
    var html = format.number(c.grH2O) + ' gr H2O';
    if (c.url) html += ' &middot; source <a href="' + esc(c.url) + '" target="_blank" rel="noopener noreferrer">' + esc(c.source) + '</a>';
    else html += ' &middot; source ' + esc(c.source);
    if (c.note) html += ' <span class="note">(' + esc(c.note) + ')</span>';
    return fact('Water capacity', html);
  }

  // The drawing is optional here so that views can be tested without it; a failure while drawing
  // must not take the tables down with it.
  function drawingBlock(record) {
    var drawing; var geometry;
    try { drawing = dep('drawing'); geometry = dep('geometry'); } catch (e) { return ''; }
    if (!drawing || !geometry) return '';
    try {
      var model = geometry.buildModel(record);
      var svg = drawing.render(record, model);
      var notes = model.notes;
      return '<figure class="drawing">' + svg +
        (notes.length ? '<ul class="drawing-notes">' + notes.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul>' : '') +
        '</figure>';
    } catch (e) {
      return '<figure class="drawing"><p class="drawing-error" role="alert">The drawing could not be generated.</p></figure>';
    }
  }

  function detailView(record) {
    var a = record.annotations || {};
    var facts = '';
    if (record.alternativeNames && record.alternativeNames.length) facts += fact('Alternative names', esc(record.alternativeNames.join(', ')));
    [['Family', record.family], ['Category', a.category], ['Primer type', a.primerType],
      ['C.I.P. table', record.tab], ['Country', record.country], ['Published', record.published],
      ['Revised', record.revised], ['Pressure method', record.pressureMethod]].forEach(function (f) {
      if (f[1] !== undefined && f[1] !== null) facts += fact(f[0], esc(f[1]));
    });
    facts += capacityFact(record);
    return '<article class="detail">' +
      '<div class="actions"><a class="back" href="#/">All cartridges</a>' +
      '<button type="button" id="print-button">Print</button></div>' +
      '<h1 id="view-heading" tabindex="-1">' + esc(record.name) + '</h1>' +
      '<dl class="facts">' + facts + '</dl>' +
      drawingBlock(record) +
      '<section class="values-group"><h2>Cartridge</h2><div class="tables">' + valueTables(record.cartridge, format.CARTRIDGE_SECTIONS) + '</div></section>' +
      '<section class="values-group"><h2>Chamber</h2><div class="tables">' + valueTables(record.chamber, format.CHAMBER_SECTIONS) + '</div></section>' +
      '<footer class="print-footer">Source: C.I.P. TDCC, revised ' + esc(record.revised) + '</footer>' +
      '</article>';
  }

  return { listView: listView, listRows: listRows, detailView: detailView, notFoundView: notFoundView };
});
