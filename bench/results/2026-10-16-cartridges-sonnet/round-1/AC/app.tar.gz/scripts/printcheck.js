#!/usr/bin/env node
'use strict';
// Dev tool: print-media layout at the A4 content width (page minus margins, see css/print.css);
// reports the content height against the printable page height.
const fs = require('node:fs');
const path = require('node:path');
const { launch, fileBase, data } = require('../tests/e2e/helpers');
const { PAGE_WIDTH_MM } = require('../js/drawing.js');
const PAGE_HEIGHT_MM = 297 - 2 * 8; // A4 minus the @page margins
const mmToPx = (mm) => Math.round(mm / 25.4 * 96);
(async () => {
  const [outDir, ...keys] = process.argv.slice(2);
  const browser = await launch();
  const ctx = await browser.newContext({ viewport: { width: mmToPx(PAGE_WIDTH_MM), height: mmToPx(PAGE_HEIGHT_MM) }, colorScheme: 'dark', deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  for (const k of (keys.length ? keys : data.map((r) => r.key))) {
    await page.goto(fileBase + '#/cartridge/' + k);
    await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
    const h = await page.evaluate(() => document.querySelector('article.detail').getBoundingClientRect().height);
    console.log(k.padEnd(16), (h / 96 * 25.4).toFixed(0) + ` mm of ${PAGE_HEIGHT_MM}`);
    if (outDir) { fs.mkdirSync(outDir, { recursive: true }); await page.screenshot({ path: path.join(outDir, k + '.png'), fullPage: true }); }
  }
  await browser.close();
})();
