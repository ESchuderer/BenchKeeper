#!/usr/bin/env node
'use strict';
// Dev tool: screenshots for visual checks. Usage: node scripts/shoot.js <outdir> <key|list> [...]
// Options via env: SCHEME=dark|light, WIDTH=1100, MEDIA=print, PDF=1
const fs = require('node:fs');
const path = require('node:path');
const { launch, fileBase } = require('../tests/e2e/helpers');

(async () => {
  const [outDir, ...keys] = process.argv.slice(2);
  fs.mkdirSync(outDir, { recursive: true });
  const browser = await launch();
  const width = Number(process.env.WIDTH || 1100);
  const ctx = await browser.newContext({ viewport: { width, height: 900 }, colorScheme: process.env.SCHEME || 'light', deviceScaleFactor: Number(process.env.DPR || 1) });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.error('pageerror', e.message));
  page.on('console', (m) => { if (m.type() === 'error') console.error('console', m.text()); });
  for (const k of keys) {
    await page.goto(fileBase + (k === 'list' ? '#/' : '#/cartridge/' + k));
    if (process.env.MEDIA) await page.emulateMedia({ media: process.env.MEDIA });
    const name = [k, process.env.SCHEME || 'light', width, process.env.MEDIA || 'screen'].join('_');
    if (process.env.PDF) {
      await page.pdf({ path: path.join(outDir, name + '.pdf'), format: 'A4', preferCSSPageSize: true, printBackground: true });
    } else if (process.env.CLIP === 'drawing') {
      await page.locator('svg.cartridge-drawing').screenshot({ path: path.join(outDir, name + '.png') });
    } else {
      await page.screenshot({ path: path.join(outDir, name + '.png'), fullPage: true });
    }
    console.log('wrote', name);
  }
  await browser.close();
})();
