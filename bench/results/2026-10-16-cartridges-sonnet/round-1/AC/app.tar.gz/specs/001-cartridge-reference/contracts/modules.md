# Module Contracts

All modules are UMD: `CIP.<module>` in browsers, `require('../../js/<file>')` in Node. Cross-module
use goes through a `dep(name)` helper inside the wrapper (browser: `window.CIP[name]`, Node: `require`).

## `format.js` → `CIP.format`
- `number(n) → string`: `String(n)`. `escapeHtml(s)`.
- `angle(a) → string`: number → `40°`; object → `39°59'49"`.
- `isAngleKey(key) → boolean`.
- `symbol(key) → string` (FR-006 mapping).
- `unit(key) → string` (D9).
- `valueText(sectionObj, key) → string`: value (or angle) plus tolerance of `key` if present.
- `sectionRows(sectionObj) → {symbol,value,unit}[]`: skips `*Tol` keys.
- `sections(groupObj, defs) → {title, rows}[]`: fixed order, omits empty.
- `CARTRIDGE_SECTIONS`, `CHAMBER_SECTIONS`: definitions (D10).
- `degrees(a) → number`: angle as decimal degrees (for geometry).

## `search.js` → `CIP.search`
- `normalise(s) → string`.
- `filter(records, {text, family}) → records[]`.
- `countText(n) → string`.

## `geometry.js` → `CIP.geometry`
- `buildModel(record) → model` (data-model.md). Pure; never reads outside `record`.
- `rimType(record)`, `primerPocket(primerType)`, `bulletParams(record)`: exported for tests.
- `outerRadiusAt(model, z) → number`, `innerRadiusAt(model, z) → number`.
- `flatten(cmds, n) → Pt[]`, `arcCenter(...)`, `arcPoint(centre, t)`: arc sampling shared with the drawing and tests.

## `drawing.js` → `CIP.drawing`
- `layout(model, record) → layout` (data-model.md).
- `render(record) → string`: full `<svg>` markup (calls geometry + layout).
- `printScale(layout) → number` = `194 / viewBox.w`.
- `outlinePolylines(model) → Pt[][]` in drawing coordinates; `assignLanes(items, pad) → {id: lane}` (D21).

## `views.js` → `CIP.views`
- `listView(records, state) → string`; `listRows(records) → string`.
- `detailView(record) → string`; `notFoundView(key) → string`; `FAMILIES`.

## `app.js` (browser only)
- Parses `location.hash`, renders into `#app`, wires `input`/`change`/`click`, sets `document.title`, moves focus.
