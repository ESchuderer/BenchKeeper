# UI Contract

Observable surface the tests and users rely on.

## Addresses

| Address | View |
|---------|------|
| `index.html` / `index.html#/` | list |
| `index.html#/cartridge/<key>` | detail of the record with that `key` |
| any other `#/cartridge/<x>` | not-found message + link "All cartridges" |

## List view

- `<h1>Cartridges</h1>`
- `<label for="search">Search</label>` + `<input id="search" type="search">`; `<label for="family">Family</label>` + `<select id="family">` with options `All`, `rimless`, `rimmed`, `belted`, `pistol`, `rimfire` (value `''` for All).
- `<p id="count" role="status">25 cartridges</p>` (text `<n> cartridges`).
- A table `Cartridges`: columns `Name`, `Family`, `L3 (mm)`; each name an `<a href="#/cartridge/<key>">` with text exactly `name`.
- Empty result: `0 cartridges` and `No cartridge matches.`

## Detail view

- `<h1>` = name. Facts as `<dl>`: Alternative names (if any), Family, Category, Primer type, C.I.P. table, Country, Published, Revised, Pressure method, Water capacity (if any: `<value> gr H2O`, link `<source>` to the published URL, note if any).
- `<svg role="img" aria-labelledby>` whose accessible name is `<name> drawing`; followed by `<ul class="drawing-notes">` (omitted if no notes).
- `<h2>Cartridge</h2>` / `<h2>Chamber</h2>`; per section `<table>` with `<caption>` = section title and header cells `Symbol`, `Value`, `Unit`.
- `<button type="button">Print</button>` and `<a href="#/">All cartridges</a>` (both outside print output).
- Print footer element: `Source: C.I.P. TDCC, revised <revised>` (visible only in print).

## Drawing text

Labels `<symbol> <value>`: `L3 51.18`, `L6 71.12`, `R1 12.01`, `R 1.37`, `P1 11.96`, and when published `P2`, `H1`, `H2`, `G1`, `L1`, `L2`, `E1`, `α 40°`. Title block lines: name; `C.I.P. table <tab> · revised <revised>`; `Dimensions in mm`; `Scale <n>:1 (A4 print)`. Notes: `<Feature> not drawn: <symbols> not published.` (exact wording in `geometry.js` tests).

## Print

`@page { size: A4 portrait; margin: 8mm }`; hidden: header navigation, search, family, count, list, buttons, links back. Shown: name header, drawing, notes, facts, tables, footer. Colours: black on white.

## Network

Zero requests besides the document and its own scripts/styles.
