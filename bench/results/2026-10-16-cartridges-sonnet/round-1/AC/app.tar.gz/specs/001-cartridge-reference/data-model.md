# Data Model

## Record (input, unchanged from `data/cartridges.jsonl`)

| Path | Type | Notes |
|------|------|-------|
| `key` | string | route id, unique, `[a-z0-9_]+` |
| `name` | string | shown verbatim; link text |
| `alternativeNames` | string[]? | searched and shown when present |
| `family` | `rimless｜rimmed｜belted｜pistol｜rimfire` | list filter |
| `country`, `tab`, `pressureMethod`, `published`, `revised` | string | shown verbatim (`tab` = C.I.P. table) |
| `annotations.category` | `rifle｜pistol｜rimfire` | shown; selects bullet constants |
| `annotations.primerType` | `sr｜sp｜spm｜lr｜lrm｜lp｜lpm｜rimfire` | shown; selects primer pocket |
| `annotations.defaultBulletShape` | `pointy｜rounded｜flat｜semi_wadcutter` | bullet nose |
| `annotations.publishedCapacity?` | `{grH2O, source, url, note?}` | shown with source link |
| `annotations.confidence, defaultBullet, implausible` | – | not shown |
| `cartridge.<section>.<field>` | number or Angle | sections: caseHead, collar, junctionCone, lengths, misc, powderChamber, pressures, projectile |
| `chamber.<section>.<field>` | number or Angle | sections: barrel, breech, collar, grooves, junctionCone, lengths, powderChamber, rifling |
| `<field>Tol` | number | tolerance of `<field>` in the same section; never a row |

**Angle** = `number` (degrees) | `{degrees, minutes, seconds}`. Angle keys: `alpha`, `alpha1`, `beta`, `delta`, `i`.

Fields the drawing reads (all from `cartridge.*`): `caseHead.{R,R1,R3,E,E1,eMin,f,beta,delta}`,
`powderChamber.{P1,P2}`, `collar.{H1,H2}`, `junctionCone.{alpha,r1Min,r2}`, `lengths.{L1,L2,L3,L6}`,
`projectile.G1`. Missing optional fields are expected and handled (see research D13–D18).

## Table row (view model)

`{symbol: string, value: string, unit: string}`; built by `format.sectionRows(sectionObject, sectionKey)`.
No row for `*Tol`; `value` includes the tolerance after a space.

## Drawing model (output of `geometry.buildModel(record)`)

```text
{
  rimType: 'rimless'|'rimmed'|'rebated'|'belted'|'rimfire',
  straight: boolean, heeled: boolean,
  walls: {tb, tn, w, pocket: {d, depth}|null},
  outer: Cmd[],        // half profile, upper side, from (0,0) to (H2/2, L3)
  skeleton: Pt[],      // the unrounded corner points of the profile (published points)
  mouth: {z: L3, rOuter, rInner},
  inner: Pt[],         // cavity boundary from (w, 0) ... to (L3, ri)
  bullet: {shape, s, k, m, zb, lb, zc, n, rho?, heel: {r}|null, cmds: Cmd[]},
  notes: string[]      // one per omitted feature, naming the missing values
}
Cmd = {c:'M'|'L', z, r} | {c:'A', rx, ry, z, r, sweep: 0|1}   // sweep 1 = turns toward the axis when moving +z
Pt  = {z, r}
zStart: number         // z where the body starts (E, or R without a groove)
```

## Layout (output of `drawing.layout(model, record)`)

`{viewBox:{x,y,w,h}, fs, labels:[{id, text, x, y, w, h, baseline}], dims:[{id, kind:'length'|'diameter'|'angle', lines:[{kind:'dim'|'ext'|'stub', p, q}], arrows:[{tip, dir, len, half}], label}], title:{x,y,w,h,lines,pad,lineH,fs}, scalePrint}`
and `drawing.render(...)` returns the SVG markup string. `labels[*]` boxes are what the overlap tests
check; the browser test re-checks with `getBBox`.
