# Implementation Plan: C.I.P. Cartridge Reference

**Branch**: `001-cartridge-reference` | **Date**: 2026-10-16 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-cartridge-reference/spec.md`

## Summary

A static, zero-dependency web app: a list page with search and family filter, and a detail page per
cartridge with identity facts, a generated true-to-scale SVG drawing, tables, and an A4 print
layout. All logic that matters (value formatting, filtering, geometry, drawing layout) lives in
pure functions in classic scripts that also load in Node, so the unit tests exercise exactly the
code the browser runs. The 25 records are shipped as a generated classic script (`js/data.js`) so
nothing is fetched, which is what makes `file://` work. Details and decisions: [research.md](research.md).

## Technical Context

**Language/Version**: JavaScript (ES2022, browser-native, classic scripts), HTML5, CSS3. Node.js 22 for development only.

**Primary Dependencies**: None at runtime. Dev only: `playwright` (real Chromium for end-to-end and print checks).

**Storage**: None. Data is `data/cartridges.jsonl` (source of truth) → `js/data.js` (generated, committed; sets `CIP.data`).

**Testing**: `node --test` for unit tests (format, filter, geometry, drawing, data integrity); Playwright-driven Chromium for end-to-end from `file://` and from a static server, including measured label overlap, `page.pdf()` page count and a print-media screenshot.

**Target Platform**: Current Chromium (primary), other evergreen browsers, phone to desktop widths; A4 portrait print.

**Project Type**: Static single-page web app, hash-routed.

**Performance Goals**: List filtering and detail rendering feel instant (< 50 ms for 25 records); no layout libraries.

**Constraints**: No network requests; no ES modules, no `fetch`, no `import` across files (rule of `file://`); no build step for the app; one A4 page when printed.

**Scale/Scope**: 25 records, 2 views, ~8 source files.

## Constitution Check

*GATE: passed before Phase 0; re-checked after Phase 1.*

| Principle | Status | How the plan meets it |
|-----------|--------|-----------------------|
| I. Static, zero-dependency runtime | Pass | Classic scripts, one namespace `CIP`, data as script, no fetch/modules/network; favicon suppressed by a `data:` link so servers see no extra request. |
| II. Data fidelity | Pass | Values are rendered via `String(number)` of the record value; geometry uses only record values and the constants fixed by the rules; missing inputs produce notes, never defaults. A test compares `js/data.js` with `data/cartridges.jsonl`. |
| III. Test-first | Pass | Tasks order tests before implementation per module; red run recorded before each green. |
| IV. Technical precision | Pass | Geometry computed from rules; label layout is a deterministic lane algorithm with fixed text widths (`textLength`) and is verified by box intersection tests in Node and by `getBBox` in Chromium. |
| V. Accessible, printable, responsive | Pass | Semantic landmarks, labelled controls, SVG `role="img"` with `<title>`; print stylesheet; viewBox scaling; `prefers-color-scheme`. |

No violations; Complexity Tracking is empty.

## Project Structure

### Documentation (this feature)

```text
specs/001-cartridge-reference/
├── plan.md
├── research.md          # decisions incl. geometry interpretation
├── data-model.md        # record shape, derived view-model, drawing model
├── quickstart.md        # how to run and validate
├── contracts/
│   ├── ui-contract.md   # URLs, landmarks, labels, text the UI must expose
│   └── modules.md       # public functions of each script
├── checklists/requirements.md
└── tasks.md             # from /speckit-tasks
```

### Source Code (repository root)

```text
index.html               # shell: header, <main id="app">, script tags (classic)
css/
├── app.css              # screen styles, light/dark variables
└── print.css            # @page A4, hides chrome, multi-column tables (media="print")
js/
├── data.js              # GENERATED: CIP.data = [25 records]
├── format.js            # numbers, angles, tolerance, symbols, units, sections → table rows
├── search.js            # normalisation, filter by text and family, count text
├── geometry.js          # record → drawing model (profile, bullet, walls, notes)
├── drawing.js           # model → dimension layout → SVG markup string
├── views.js             # list view and detail view markup (strings), pure
└── app.js               # router, DOM wiring, print button (browser only)
data/cartridges.jsonl    # the 25 records (source of truth)
scripts/build-data.js    # dev tool: jsonl → js/data.js
tests/
├── unit/                # node:test files, one per module + data integrity
└── e2e/                 # Playwright + node:test; helpers: server, browser
package.json             # devDependencies only; scripts: test, test:e2e, build:data
```

**Structure Decision**: single static project at the repository root, because the brief requires
`index.html` in the root. Every script is UMD-style: in a browser it attaches to `window.CIP`, in
Node it is `require`d; no script needs a bundler. Views build HTML strings (escaped) so they can be
unit-tested without a DOM; only `app.js` touches `document`.

## Complexity Tracking

No constitution violations.
