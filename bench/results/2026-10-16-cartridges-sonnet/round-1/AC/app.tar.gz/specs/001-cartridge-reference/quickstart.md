# Quickstart: run and validate

## Prerequisites
- Node.js 22, `npm install` (dev dependencies only: `playwright`).
- For end-to-end tests: `npx playwright install chromium`. If Chromium reports missing shared
  libraries and you are not root, unpack the required `.deb` packages into `~/chromelibs`
  (see research D4); the helper in `tests/e2e/browser.js` picks them up automatically.

## Use the app
- Open `index.html` directly (`file://`) in Chromium, **or** serve the folder: any static server works, for example `python3 -m http.server`.
- Regenerate the data script after editing `data/cartridges.jsonl`: `npm run build:data`.

## Validate
| What | Command | Expected |
|------|---------|----------|
| Unit tests | `npm test` | all green; includes data-integrity, geometry for all 25 records, label non-overlap |
| End-to-end | `npm run test:e2e` | all green on `file://` and on a static server; 0 foreign requests; 25 one-page PDFs |
| Manual 1 | open list, type `7,62 x 51` | only "308 Win.", text `1 cartridges` |
| Manual 2 | open "308 Win.", reload | same view; heading `308 Win.`; drawing labelled `L3 51.18` |
| Manual 3 | Print → preview | one A4 page, black on white, no controls |
| Manual 4 | system dark mode, 360 px width | dark palette, no horizontal scroll |

See [contracts/ui-contract.md](contracts/ui-contract.md) for exact texts and [data-model.md](data-model.md) for shapes.
