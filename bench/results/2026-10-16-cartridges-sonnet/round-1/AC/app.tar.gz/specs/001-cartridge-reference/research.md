# Research and Decisions

All unknowns of the Technical Context are resolved here. "D" numbers are referenced from tasks and tests.

## Platform and tooling

**D1 – `file://` loading.** Chromium blocks `fetch` of local files and treats `type="module"` scripts from `file://` as cross-origin. Decision: classic `<script src>` tags in dependency order; every script is a UMD wrapper that sets `window.CIP.<name>` (browser) or `module.exports` (Node). Alternatives rejected: ES modules (fail on `file://`), a single concatenated bundle (needs a build step), inline JSON + `fetch` (fails on `file://`).

**D2 – Data shipping.** `data/cartridges.jsonl` is the source of truth; `scripts/build-data.js` writes `js/data.js` (`window.CIP_DATA = [...]`, `module.exports` in Node) by `JSON.parse` of each line, so no value is touched. The generated file is committed and a unit test regenerates it in memory and compares. Whole numbers such as `4150.0` parse to `4150`, which is the published display (`4150 bar`).

**D3 – Routing.** Fragment routes: `#/` (list) and `#/cartridge/<key>`; the key is the record's `key` (`[a-z0-9_]`). Fragments work from `file://`, survive reload, are bookmarkable, need no server rewrite. Empty or unknown fragment: the list for `#/` or empty; `#/cartridge/<unknown>` shows a not-found message. The `hashchange` event re-renders. Focus moves to the view heading after a route change; document title follows the view.

**D4 – Browser testing.** `playwright` as devDependency; the Chromium build it downloads needs system shared libraries that this container lacks and cannot install as root. They were fetched as `.deb` files with `apt-get download` and unpacked to `~/chromelibs`; the e2e helper adds that directory to `LD_LIBRARY_PATH` when present (a no-op where Chromium already works). Two base URLs are tested: `file://…/index.html` and a throwaway Node `http` static server. Network check: every request must be `file:` or same-origin `127.0.0.1`.

**D5 – Print verification.** `page.pdf({format:'A4'})` with print media: page count is the number of `/Type /Page` objects; the PDF is also rendered to images (screenshot with `emulateMedia({media:'print'})`) and inspected by eye once per family. Label legibility: drawing font size in print mm = `fs × 194 / W` must be ≥ 2 mm (computed in a unit test).

## Presentation of values

**D6 – Numbers.** `String(value)` of the JSON number. No locale formatting, no rounding. Negative tolerance: `-0.2`; a positive tolerance gets no `+` (none exists in the data; it would be shown as published).

**D7 – Angles.** Number → `${n}°`. Object → `${d}°${m}'${s}"` with all three parts (`34°30'0"`), no padding. Rationale: the brief gives the object form as `39°59'49"`; dropping zero parts would hide published figures.

**D8 – Tolerance next to value.** Value text is `<X> <Tol>` separated by one space (`39.62 -0.2`). `<X>Tol` keys are never rows. The tolerance key is looked up as `key + 'Tol'` in the same section object.

**D9 – Symbols and units.** Symbol = key, except the mapping in FR-006. Unit: `bar` for Pmax, PK, PE; `J` for EE; `g` for M; `mm²` for Q; empty for N and for angle keys (`alpha`, `alpha1`, `beta`, `delta`, `i`: the degree sign is in the value); `mm` for everything else (all remaining keys are lengths or diameters). Water capacity is shown as `<grH2O> gr H2O` (grains of water, the published field name).

**D10 – Sections.** Cartridge: `caseHead` "Case head", `collar` "Collar", `junctionCone` "Junction cone", `lengths` "Lengths", `misc` "Miscellaneous", `powderChamber` "Powder chamber", `pressures` "Pressures", `projectile` "Projectile". Chamber: `barrel` "Barrel", `breech` "Breech", `collar`, `grooves` "Grooves", `junctionCone`, `lengths`, `powderChamber`, `rifling` "Rifling". Fixed order; empty or absent sections omitted; rows in the record's key order.

**D11 – Search.** Normalise with `toLowerCase()` and removal of all whitespace; match = substring in normalised name or any normalised alternative name. Combined with the family select by AND. The count text is always `${n} cartridges`.

## Drawing: interpretation of the rules

Coordinates: the brief writes points as `(r, z)` (e.g. `(P2/2, L1)`). The model uses `{z, r}` objects, `z` along the axis, `r` radius, `r ≥ 0` for the upper half. SVG: `x = z`, `y = -r` (outside view, up) and `y = +r` (section, down).

**D12 – Rim type (rule 1).** `belted` / `rimfire` from family; else `R1/P1` thresholds. It is exposed in the model (`rimType`) and as `data-rim` on the SVG; no geometry branches on `rimmed`/`rebated`/`rimless` beyond what rules 2–3 say (rebated simply steps *out* from `R1/2` to `P1/2`).

**D13 – Head face and rim edge (rule 2).** Rimfire (family) takes the half-round: `ρ = min(R/2, (R1-P1)/2)`; `(R1/2-ρ, z=0)` → quarter arc to `(R1/2, ρ)` → quarter arc to `(R1/2-ρ, 2ρ)` → straight to `(R1/2-ρ, R)` if `2ρ < R` → step to `(P1/2, R)`. Non-rimfire with `beta` and `f` and `beta < 90°`: chamfer; angle for `tan β` uses degrees converted from the number or from d/m/s. Else square corner. Needs `R`, `R1`, `P1`; if absent the model reports a note and the profile starts at the next defined feature (not occurring in the data).

**D14 – Groove and belt (rule 3).** Groove exists when `E`, `E1`, `eMin` are all published. Normal: `(R1/2,R)→(E1/2,R)→(E1/2,R+eMin)→(P1/2,E)`. Belted (also needs `R3` and `delta`): from the floor end ramp at `δ` to the axis: `Δz = (R3/2 - E1/2)/tan δ`; ramp end `zr = R+eMin+Δz`; then `(R3/2, E)` then `(P1/2, E)`. Body start `zs = E`. No groove: `(R1/2,R)→(P1/2,R)`, `zs = R`; a note names the absent values (`E`, `E1`, `eMin`). Rimmed cases without E are the usual case; the note is still emitted because rule 9 asks to say which value is missing.

**D15 – Body, shoulder, neck (rules 4–6).** Bottleneck requires `alpha`, `L1`, `L2`, `H1`, `P2`; otherwise straight with a note listing exactly the missing ones. Body: line `(P1/2, zs)→(P2/2, L1)` (taper). Shoulder through `(P2/2,L1)`, `(H1/2,L2)` as published (α only labelled). Neck to `(H2/2, L3)`. Fillets at the two shoulder corners with `r1Min` / `r2` when published: tangent arc of that radius between the adjacent straight segments; tangent length clamped to 45 % of each adjacent segment length, so the two fillets never meet. Missing `r1Min` / `r2` → corner left sharp and a note.

**D16 – Bullet (rule 7).** Parameters from the rule table. `category` (`rifle`, `pistol`, `rimfire`) selects `s` and `k`; shape from `annotations.defaultBulletShape`. Pointy: tangent ogive with an SVG circular arc of radius `ρ` from `(z_c, G1/2)` to `(L6, m/2)` curving towards the axis; rounded: quarter ellipse `rx = n`, `ry = G1/2 - m/2`, centre `(z_c, m/2)`; flat and semi-wadcutter: straight cone. Flat tip face from `(L6, m/2)` to the axis. Heeled (`H2 - G1 ≤ 0.015`): exposed radius `H2/2`; below the mouth the heel radius `(H2 - 2tb)/2`, joined to the exposed radius by a step at `z = L3`. Outside view: the exposed bullet is the full bullet clipped to `z ≥ L3` (`clipPath`), so no curve clipping maths is needed. The bullet base is flat (boat-tail data is not part of the rules).

**D17 – Walls and head (rule 8).** `tn = (H2-G1)/2`, `tb = min(max(1.3·tn, 0.6), 0.35·P1/2)`. Inner radius `ri(z) = body(z) - tb` where `body(z)` is the body line extended linearly to `z < zs` (belted: the cavity stays a smooth taper behind the belt), then across the shoulder linearly from `(L1, P2/2 - tb)` to `(L2, H1/2 - tn)`, then `H/2 - tn` to `L3`. Cavity floor at `z = w`. `w = max(2.5, 0.25·P1/2, pocketDepth + 1.5, E + tb [groove], zr + tb [belted])`. Pocket: rectangle `r ≤ d/2`, `z ≤ depth` from the primer-type table; rimfire none; unknown primer type → no pocket + note.

**D18 – Straight cases and heeled cases.** Rule 8 names tb "along the body" and tn "along the neck", but a straight case has no neck while the seated bullet must fit the mouth. Decision: on a straight case the wall is `tb` from `w` to `zb - s`, tapers linearly to `tn` at the bullet base `zb`, and stays `tn` to the mouth. Heeled cases use `tn := tb` (the heel diameter `H2 - 2tb` is the rule). This uses only rule values; it is documented in the model notes' source, not shown.

**D19 – Section rendering.** One path with `fill-rule: evenodd`: the outer profile mirrored and closed on the axis, plus the cavity subpath and the pocket subpath → hatched solid exactly where metal is. The seated bullet is drawn over the cavity with the opposite hatch angle. The upper half draws outline only (outside view).

## Drawing: dimensions and layout

**D20 – Dimension set.** Always: `L3`, `L6`, `R1`, `R`, `P1`. Where published: `P2`, `H1`, `H2`, `G1`, `L1`, `L2`, `E1`, `alpha`. Lengths (`R`, `L1`, `L2`, `L3`, `L6`) are measured from the head face: horizontal dimension lines in lanes **above** the outline, shortest nearest, with vertical extension lines. Diameters (`R1`, `E1`, `P1`, `P2`, `H1`, `H2`, `G1`) have a vertical dimension line across the full diameter at the feature's `z` (arrowheads on the outline), continued downward as an extension line to a label **below** the outline. `α` is a leader with an arrowhead onto the lower shoulder line and the label `α 46°` in the same lower label system; the included-angle apex lies far outside the drawing for shallow shoulders, so an apex construction is not used. Anchors: `R1` at `z = R/2`; `E1` mid-floor; `P1` at `zs`; `P2` at `L1`; `H1` at `L2`; `H2` at `L3`; `G1` mid of the exposed cylinder. Label text: `<symbol> <value>` (angle: `α 46°`); no tolerance in drawing labels (tolerances are in the tables).

**D21 – Label placement without overlap.** Labels are placed in horizontal lanes. Text uses a monospace stack and an explicit `textLength` of `chars × 0.6 × fs`, so its width does not depend on the font actually used. Lower labels start at their anchor and extend right; processing from right to left, a label's lane is `1 + max(lane of every label whose anchor lies inside its box)`, `0` if none. This guarantees: no two boxes intersect, and no leader crosses another label box. Upper lengths use one lane per dimension, ordered by length, text centred above the line (`R`, whose span is narrower than its text, puts the text to the right of its line). Lane base is outside the outline's maximum radius plus a gap, so labels never meet the outline. Font size `fs = max(1, (L6 + 8)/40)` mm: legible at 360 px width and when printed.

**D22 – Overall size, title block, scale.** `viewBox` = union of outline, lanes and label boxes plus a margin; title block (4 lines in a framed box) at the bottom right below all lanes. Printed scale = `194 / W` (A4 width minus 2×8 mm margins), stated as `Scale 1.65:1 (A4 print)`; on screen the SVG scales to the container width. Strokes use `vector-effect: non-scaling-stroke` (CSS px) so lines stay crisp on phones and in print; hatch uses user units.

**D23 – Print budget.** Page 297 mm − margins 16 = 281 mm: header 12, identity 18, notes ≤ 10, footer 8, drawing ≤ 150 (an SVG `max-height` safety exists but must never bind: the e2e test asserts the printed width is 194 mm, which keeps the title-block scale true), tables in 5 columns (`column-count: 5`, 6.8 pt), facts in 6 columns. The e2e test checks one page for all 25 records; the layout constants are tuned until it passes.

## Interaction and accessibility

**D24 – List.** A `<table>` (Name, Family, L3 mm) inside `<main>`, names as links; controls labelled with `<label>`; count in `role="status"`; empty state row/message "No cartridge matches." Filters reset when the list is re-entered from a detail view.

**D25 – Theme.** CSS custom properties; `@media (prefers-color-scheme: dark)` overrides; `color-scheme: light dark`. `print.css` (and `@media print` rules) force light values and `forced-color-adjust: none` for hatch/lines to black on white.

**D26 – Security.** All text from records is HTML-escaped when assembling markup; the source link uses `rel="noopener noreferrer"` and is only a link (no request by the app).

## Alternatives considered (summary)

- A charting/SVG library: rejected (constitution I).
- Dimension lines for diameters outside the case with long horizontal extension lines: rejected, they cross the rim and groove.
- Apex-based angular dimension for α: rejected (apex up to 17 mm beyond the bullet tip for 9,3 x 74 R).
- Dropping zero minutes/seconds in angles: rejected (D7).
