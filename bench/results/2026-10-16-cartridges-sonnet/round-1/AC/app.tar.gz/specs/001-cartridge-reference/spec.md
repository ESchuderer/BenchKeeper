# Feature Specification: C.I.P. Cartridge Reference

**Feature Branch**: `001-cartridge-reference`

**Created**: 2026-10-16

**Status**: Draft

**Input**: User description: "Static web reference database of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on the cartridge database of OpenBallistics, with a true-to-scale generated 2D drawing per cartridge and a one-page A4 print."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Find a cartridge (Priority: P1)

A reloader opens the reference and sees every cartridge in one dense list: name, family and case length L3. They type part of a name, or a trade name such as `7,62 x 51`, and the list narrows as they type. They can also restrict the list to one family. The list states how many cartridges are shown.

**Why this priority**: Finding the cartridge is the entry point of everything else; the list alone is already a useful reference.

**Independent Test**: Open the start page, check 25 entries with name, family and L3; type `7,62 x 51` and see "308 Win." only; choose family "rimfire" and see 3 entries and "3 cartridges".

**Acceptance Scenarios**:

1. **Given** the start page, **When** it loads, **Then** the heading "Cartridges", all 25 cartridges (each name as a link with name, family and L3) and the text "25 cartridges" are shown.
2. **Given** the start page, **When** the user types `7,62 x 51` into "Search", **Then** only "308 Win." is listed and the text reads "1 cartridges".
3. **Given** the start page, **When** the user selects "pistol" in "Family", **Then** only the 6 pistol cartridges are listed.
4. **Given** a search and a family are both set, **When** the list updates, **Then** only entries satisfying both are shown.
5. **Given** a search with no match, **When** the list updates, **Then** the count reads "0 cartridges" and an explanatory empty message is shown.

---

### User Story 2 - Read the data of one cartridge (Priority: P1)

An engineer follows a name link and lands on a detail view with the cartridge's identity (alternative names, family, category, primer type, C.I.P. table, country, published and revised dates, pressure method, water capacity with its source link) and every cartridge value and chamber value in tables grouped by section, with symbol, value and unit. Tolerances sit next to their value. The view has its own address: reloading it or opening a bookmark shows the same cartridge; an unknown address shows a clear "not found" message with a way back.

**Why this priority**: This is the reference content itself.

**Independent Test**: Open "308 Win.", compare every table row against the record; reload; open the address in a new tab.

**Acceptance Scenarios**:

1. **Given** the list, **When** the user activates the link "308 Win.", **Then** a detail view with heading "308 Win." and its own address is shown.
2. **Given** a detail view, **When** the page is reloaded or its address is opened directly, **Then** the same detail view appears.
3. **Given** a record with `L1Tol` -0.2, **When** the table is shown, **Then** the L1 row reads `39.62 -0.2` and no row exists for the tolerance.
4. **Given** a record whose section is empty (pistols have no junction cone), **When** the tables are shown, **Then** no empty section appears.
5. **Given** a detail view, **When** the user activates "All cartridges", **Then** the list is shown again.
6. **Given** an address that names no cartridge, **When** it is opened, **Then** a "not found" message and a link "All cartridges" are shown.

---

### User Story 3 - See the cartridge to scale (Priority: P1)

On the detail view the user sees a technical drawing of the cartridge with its bullet: outside view above the axis, hatched section below, centre line, dimension lines with labelled values, and a title block. It is computed from the record's own values, so every cartridge differs, and measuring it at 1 unit = 1 mm reproduces the published dimensions. Where a value needed for a feature is missing, the feature is left out and a note names the missing value.

**Why this priority**: The drawing is the distinguishing feature versus a plain table.

**Independent Test**: For each of the 25 records, render the drawing, and check outline coordinates, labels and non-overlap against the rules in Appendix A; view "22 Win. Mag. R.F." and see the notes naming the missing values.

**Acceptance Scenarios**:

1. **Given** "308 Win.", **When** its drawing is shown, **Then** it has the accessible name "308 Win. drawing", and labels `L3 51.18`, `L6 71.12`, R1, R, P1, P2, H1, H2, G1, L1, L2, E1 and α are present.
2. **Given** any cartridge, **When** its drawing is shown, **Then** no label overlaps another label or the outline.
3. **Given** a rimfire cartridge without alpha, L1 or L2, **When** its drawing is shown, **Then** the body is straight and no shoulder or α label is drawn.
4. **Given** a cartridge lacking a value a rule needs (e.g. no E or E1, no f/beta, no r1 min), **When** the drawing is shown, **Then** that feature is omitted and a visible note names the missing value; no number is invented.
5. **Given** a phone-width screen, **When** the drawing is shown, **Then** it fits the width without horizontal scrolling.

---

### User Story 4 - Print a datasheet (Priority: P2)

The user presses "Print" and gets one A4 portrait page, black on white: header with the name, the drawing at full page width with all labels legible, then the tables, and a footer naming the source (C.I.P. TDCC) and the revision date. Navigation, search and buttons are not printed.

**Why this priority**: Gunsmiths and reloaders keep paper sheets; secondary to on-screen use.

**Independent Test**: Print to PDF for several cartridges (including the longest, 9,3 x 74 R, and the shortest, 22 LR) and check: exactly one A4 page, black on white, legible labels.

**Acceptance Scenarios**:

1. **Given** a detail view, **When** "Print" is pressed, **Then** the browser's print dialog opens.
2. **Given** print output of any of the 25 cartridges, **When** inspected, **Then** it is one A4 portrait page with header, drawing, tables and footer "C.I.P. TDCC" plus the revised date, and without navigation, search or buttons.
3. **Given** a system in dark mode, **When** printing, **Then** the output is still black on white.

---

### User Story 5 - Comfortable reading on any device (Priority: P3)

The interface follows the system light/dark setting, uses dense, calm typography with tabular numbers so that values line up, and stays usable on a phone.

**Why this priority**: Quality of life on top of working content.

**Independent Test**: Toggle the system colour scheme; view at 360 px width; check no horizontal page scroll and aligned numbers.

**Acceptance Scenarios**:

1. **Given** a system colour-scheme change, **When** the page is open, **Then** the colours switch without reload.
2. **Given** a 360 px wide viewport, **When** any view is shown, **Then** no content is cut off or requires sideways page scrolling and controls are tappable.

---

### Edge Cases

- Records with different field sets: no `E/E1/eMin` (rimmed, rimfire), no `H1`, no `alpha/L1/L2` (straight cases), empty `junctionCone`, no `alternativeNames`, no `publishedCapacity` (7 x 64 and others).
- Angles given as plain number (e.g. `3.0`, `0.0`) and as degrees/minutes/seconds, in both cartridge and chamber data (`i` can be either).
- Cartridge names containing commas, dots and ampersands (`6,5 Creedmoor`, `40 S.& W.`) are shown and searched exactly as published.
- Heeled case (22 Long Rifle) and bullets for each nose shape (pointy, rounded, flat, semi-wadcutter).
- Belted cases (R3, ETol) and rimmed cases (R1/P1 >= 1.05).
- Data that is odd on its face (`G2` = 68.61 on 7 mm Rem. Mag.; `L3PlusG` unrelated to L3 + G1) is shown as published, not corrected.
- The page works when opened from disk without any server.

## Requirements *(mandatory)*

### Functional Requirements

**Data and presentation of values**

- **FR-001**: The system MUST contain exactly the 25 supplied records (stored in `data/cartridges.jsonl`) and no other data; it MUST NOT add, change or fetch any value.
- **FR-002**: Lengths and diameters MUST be presented in mm; Pmax, PK, PE in bar; EE in J; M in g; Q in mm²; N as a count without unit; alpha, alpha1, beta, delta and i as angles.
- **FR-003**: An angle that is a number MUST be shown as degrees (`40°`); an angle given as degrees/minutes/seconds MUST be shown with all three parts as `39°59'49"`.
- **FR-004**: A field `<X>Tol` MUST be shown next to the value of X, separated by a space (`39.62 -0.2`), and MUST NOT appear as a row of its own.
- **FR-005**: Numbers MUST be shown as published: decimal point, no thousands separator, no added or removed digits other than the trailing `.0` of whole numbers (`4150 bar`, `0.1`). Names MUST be shown as published.
- **FR-006**: Symbols MUST be the field name, except `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G".

**Start page**

- **FR-010**: The start page MUST show the heading "Cartridges" and every matching cartridge with its name, family and case length L3; each name MUST be a link whose text is exactly the record's name and which opens the detail view.
- **FR-011**: A field labelled "Search" MUST filter the list as the user types, matching the name and all alternative names, ignoring case and spaces (`7,62 x 51` finds "308 Win.").
- **FR-012**: A select labelled "Family" MUST offer All, rimless, rimmed, belted, pistol, rimfire and filter by family; search and family filter combine.
- **FR-013**: The text "<n> cartridges" MUST show the number of listed cartridges, updating with every change of the filters.

**Detail view**

- **FR-020**: The detail view MUST show the heading with the name, then alternative names (when present), family, category, primer type, C.I.P. table, country, published and revised dates, pressure method, and the published water capacity (when present) with a link to its source.
- **FR-021**: All cartridge values and all chamber values MUST be shown in tables grouped by section, with the columns "Symbol", "Value" and "Unit"; sections without values MUST NOT be shown.
- **FR-022**: The detail view MUST offer a "Print" button and a link "All cartridges" back to the list.
- **FR-023**: Each detail view MUST have its own address which, when reloaded or opened directly (including from disk without a server), shows the same cartridge; an unknown address MUST show a not-found message with a link "All cartridges".

**Drawing**

- **FR-030**: Each detail view MUST contain a vector drawing with the accessible name "<name> drawing", true to scale at 1 unit = 1 mm, axis horizontal, head on the left, computed from the record's values by the rules in Appendix A.
- **FR-031**: The upper half MUST be the outside view and the lower half a section with hatched cut walls; a dash-dot centre line MUST mark the axis.
- **FR-032**: The drawing MUST carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α, each labelled with its symbol and value (`L3 51.18`).
- **FR-033**: Labels MUST NOT overlap each other or the outline.
- **FR-034**: A title block MUST show the name, C.I.P. table and revision date, "Dimensions in mm", and the scale.
- **FR-035**: Where a value a rule needs is missing, the feature MUST be left out and a visible note MUST name the missing value; no number is ever invented.
- **FR-036**: The drawing MUST scale to the width of a phone screen and print legibly.

**Print**

- **FR-040**: "Print" MUST open the browser's print dialog.
- **FR-041**: A printed detail view MUST be one A4 portrait page, black on white regardless of screen theme: page header with the name, the drawing at full width with every label legible, then the tables, and a footer with the source ("C.I.P. TDCC") and the revised date; navigation, search and buttons MUST NOT be printed.

**Look and feel**

- **FR-050**: The interface MUST be English, dense and calm, with tabular numerals, in light and dark following the system setting on screen, and usable on a phone.
- **FR-051**: The app MUST work fully when `index.html` is opened directly from disk in Chromium and when the folder is served by any static file server, without any network request.

### Key Entities

- **Cartridge record**: identity (key, name, alternative names, family, country, C.I.P. table, dates, pressure method), annotations (category, primer type, default bullet shape, published capacity with source), cartridge values (case head, collar, junction cone, lengths, misc, powder chamber, pressures, projectile) and chamber values (barrel, breech, collar, grooves, junction cone, lengths, powder chamber, rifling).
- **Angle**: a number of degrees or degrees/minutes/seconds.
- **Drawing**: a geometric model (outer half-profile, inner profile, bullet, dimension annotations, notes about missing values) derived from one record.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A user finds any of the 25 cartridges by name or alternative name in under 10 seconds from opening the page, with the list updating on each keystroke.
- **SC-002**: For all 25 cartridges, every published value appears exactly once in the tables, in the published form, with no tolerance row and no empty section.
- **SC-003**: For all 25 cartridges, the drawing's measured outline matches the record to within 0.01 mm at 1 unit = 1 mm, and no two labels or label and outline overlap.
- **SC-004**: For all 25 cartridges, the printed output is exactly one A4 portrait page and every drawing label prints at a height of at least 2 mm.
- **SC-005**: A detail view reloaded or opened from a bookmark shows the same cartridge in 100 % of the 25 cases.
- **SC-006**: At a 360 px viewport width, no view needs horizontal page scrolling.
- **SC-007**: Opening the app from disk and from a static server give the same results and cause zero network requests.

## Assumptions

- The audience knows C.I.P. symbols; no glossary is provided.
- Angle objects always show degrees, minutes and seconds, even when the minutes or seconds are zero (`34°30'0"`), to display the published figures unabridged.
- Search ignores case and whitespace only; it does not translate commas and decimal points.
- The count text always uses the plural form as given ("1 cartridges").
- In the drawing, dimension labels show the value only; tolerances appear in the tables.
- The scale in the title block states the scale of the A4 print (print width ÷ drawing width); on screen the drawing is scaled to fit the width.
- Angles and counts: the angle unit is part of the value (`40°`), so the Unit column is empty for angles and for N.
- Detail addresses use the record's `key`, in a form that works from disk (a fragment of the page address).
- Dark/light follows the system setting only; there is no manual toggle.

## Appendix A: Drawing geometry rules

`z` runs along the axis from the head face (`z = 0`) to the mouth; `r` is the radius (half the diameter). The outer half-profile is a list of points from the axis at the head face to the mouth, then mirrored at the axis.

1. **Rim type**: family `belted` is belted, `rimfire` is rimfire; otherwise R1/P1 >= 1.05 is rimmed, R1/P1 < 0.98 is rebated, anything else is rimless.
2. **Head face and rim edge**, from `(0, 0)` outward: where beta and f are published and beta < 90°, a chamfer `(R1/2 - min(f·tan β, R1/4), 0)` to `(R1/2, f)`, then up to `(R1/2, R)`. Rimfire: the rim edge is a half-round of radius `min(R/2, (R1 - P1)/2)` whose outermost point lies at `R1/2`. Otherwise a square corner.
3. **Extractor groove**, where E and E1 are published: from `(R1/2, R)` in to `(E1/2, R)`, along the floor to `(E1/2, R + e min)`, then a straight ramp out to `(P1/2, E)`. Belted: from the floor end, ramp out at angle δ to the axis up to the belt `R3/2`, follow the belt to `z = E`, then step in to `P1/2`. Without a groove: step in from `(R1/2, R)` to `(P1/2, R)`.
4. **Body**: a straight line from P1/2 at the body start to `(P2/2, L1)` on a bottleneck case. A case without alpha, L1 or L2 is straight: the body runs to `(H2/2, L3)`.
5. **Shoulder**: `(P2/2, L1)` to `(H1/2, L2)`. α is the included cone angle (the line lies at α/2 to the axis); draw through the published points and label α. Round the body-side corner with r1 min and the neck-side corner with r2 where published.
6. **Neck**: `(H1/2, L2)` to `(H2/2, L3)`, then the mouth face.
7. **Bullet**, from the mouth to the tip at `z = L6`, shank diameter G1, nose shape from `annotations.defaultBulletShape`:
   - Seating depth below the mouth `s`: 1.0·G1 pointy; 0.8·G1 rounded or flat on rifle and rimfire cartridges; 0.4·G1 rounded or flat on pistol cartridges; 0.6·G1 semi_wadcutter. Base at `zb = L3 - s`, bullet length `Lb = L6 - zb`.
   - The cylinder runs from the base to `zb + k·Lb`: k = 0.40 pointy; 0.55 rounded rifle or rimfire, 0.65 rounded pistol; 0.60 flat rifle, 0.70 flat pistol; 0.78 semi_wadcutter.
   - The nose runs to the tip with a flat tip (meplat) of diameter m. Pointy: tangent ogive, `m = max(0.08·G1, 1.27)`, arc radius `ρ = ((G1/2 - m/2)² + n²) / (2·(G1/2 - m/2))` with nose length n, centre at `r = G1/2 - ρ` on the radial line where the nose starts. Rounded: quarter ellipse, `m = 0.15·G1`. Flat: straight cone, `m = 0.55·G1`. Semi_wadcutter: straight cone, `m = 0.6·G1`.
   - Heeled case (H2 - G1 <= 0.015, for example 22 Long Rifle): the exposed bullet has the case's outside diameter; the seated heel has the case's inside diameter `H2 - 2·tb`.
   - The outside view hides the seated part; the section shows it inside the case.
8. **Section walls**: neck wall `tn = (H2 - G1)/2`; body wall `tb = min(max(1.3·tn, 0.6), 0.35·P1/2)`. The inner line follows the outer body, shoulder and neck at these walls (tb along the body, tn along the neck, blended linearly across the shoulder). The solid head runs from the head face to `z = w`, with `w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or the belt ramp end + tb on belted cases)`. Primer pocket on centrefire cases: diameter 4.45 for `sp`, `spm`, `sr` and 5.33 for `lp`, `lpm`, `lr`, `lrm`; depth 3.04 for `sp`, `spm`, `sr`, `lp`, `lpm` and 3.3 for `lr`, `lrm`. Rimfire cases have no pocket.
9. **Missing values**: if a value a rule needs is missing, draw without that feature and say which value is missing; never invent a number.
