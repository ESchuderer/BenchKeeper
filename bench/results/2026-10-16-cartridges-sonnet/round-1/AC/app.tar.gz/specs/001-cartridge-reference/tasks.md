---

description: "Task list for the C.I.P. Cartridge Reference"
---

# Tasks: C.I.P. Cartridge Reference

**Input**: Design documents in `/specs/001-cartridge-reference/` (plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md)

**Tests**: Mandatory and first (constitution III). Every implementation task has a preceding test task; the test is run and seen **red** (record the failure in `specs/001-cartridge-reference/test-log.md`; commits are made only if the user asks) before the implementation task, then **green**.

**Organization**: by user story (US1 list, US2 detail data, US3 drawing, US4 print, US5 theme/phone). "D<n>" refers to decisions in research.md.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: can run in parallel (different files, no dependency on an incomplete task)

## Phase 1: Setup

- [X] T001 Create `package.json` (private, `"type": "commonjs"`, scripts `test` = `node --test tests/unit`, `test:e2e` = `node --test tests/e2e`, `build:data`; devDependency `playwright`), `.gitignore` (`node_modules/`, `test-output/`), run `npm install`
- [X] T002 [P] Create folders `css/`, `js/`, `scripts/`, `tests/unit/`, `tests/e2e/` ; every script uses the UMD wrapper `(function (root, factory) {...})` exposing `CIP.<name>` in browsers and `module.exports` in Node (D1)

## Phase 2: Foundational (blocks all stories)

- [X] T003 Write failing test `tests/unit/data.test.js`: `js/data.js` exports 25 records; deep-equals the lines of `data/cartridges.jsonl`; keys unique and match `^[a-z0-9_]+$`; every `<X>Tol` key has sibling `<X>`; no record gained or lost a field (compare `JSON.stringify` of parsed lines)
- [X] T004 Implement `scripts/build-data.js` (reads `data/cartridges.jsonl`, `JSON.parse` per line, writes `js/data.js` as UMD exposing `CIP_DATA`/`CIP.data`); run it; make T003 green
- [X] T005 [P] Write failing test helpers `tests/unit/helpers.js` (`loadAll()` returning records; `byKey(key)`), used by all unit tests

**Checkpoint**: data shipped as a classic script, verified identical to the source file.

## Phase 3: User Story 1 – Find a cartridge (P1) 🎯 MVP

**Goal**: list page with search, family filter and count. **Independent test**: open `#/`, 25 rows; `7,62 x 51` → 308 Win.; `rimfire` → 3.

- [X] T006 [P] [US1] Write failing `tests/unit/search.test.js`: `normalise('7,62 x 51') === '7,62x51'`; `filter(all,{text:'7,62 x 51'})` → only `308_win`; `'7,62x51'` → same; `'30-06'` → `30_06_spring`; `'22lr'` → `22_long_rifle`; case-insensitive; family filter counts: rimless 12, rimmed 2, belted 2, pistol 6, rimfire 3 (verify against the data in the test by counting); text+family AND; `countText(1) === '1 cartridges'`, `countText(25) === '25 cartridges'` (D11)
- [X] T007 [US1] Implement `js/search.js` (`normalise`, `filter`, `countText`) until T006 is green
- [X] T008 [P] [US1] Write failing `tests/unit/format-basic.test.js` for the pieces the list needs: `format.number(51.18) === '51.18'`, `number(4150) === '4150'` (D6)
- [X] T009 [US1] Implement `js/format.js` `number` (extended in US2)
- [X] T010 [P] [US1] Write failing `tests/unit/views-list.test.js`: `listView` contains `<h1>Cartridges</h1>`, `<label for="search">Search</label>`, `<label for="family">Family</label>` with the six options in order All, rimless, rimmed, belted, pistol, rimfire, `role="status"` count `25 cartridges`; every record has an `<a href="#/cartridge/<key>">name</a>` whose text equals `name` exactly (including `6,5 Creedmoor`, `40 S.& W.` escaped as `40 S.&amp; W.`), family and `L3` cells; HTML escaping of `<`/`&` in names (D24, D26)
- [X] T011 [US1] Implement `js/views.js` `listView`, `listRows`, `notFoundView` (skeleton) until T010 is green
- [X] T012 [US1] Create `index.html` shell (`lang="en"`, viewport meta, `<link rel="icon" href="data:,">`, header, `<main id="app">`, classic scripts in order data, format, search, geometry, drawing, views, app) and `js/app.js` list wiring: hash router for `#/`, `input`/`change` handlers re-rendering only the rows and count, title, focus (D3)
- [X] T013 [P] [US1] Create first `css/app.css` (variables, typography, tabular numerals, list table, form controls; light/dark skeleton)

**Checkpoint**: US1 works in a browser (verified later by e2e T045).

## Phase 4: User Story 2 – Read the data of one cartridge (P1)

**Goal**: detail view with identity facts, tables, deep link. **Independent test**: `#/cartridge/308_win` reload; compare rows with the record.

- [X] T014 [P] [US2] Write failing `tests/unit/format.test.js`: angle formatting (`40°`, `3°`, `0°`, `{50,35,2}` → `50°35'2"`, `{34,30,0}` → `34°30'0"`, `{39,59,49}` → `39°59'49"`) (D7); `symbol()` mapping for `eMin r1Min r1Max alpha alpha1 beta delta deltaL L3PlusG` and identity for others (FR-006); `unit()` per D9 (`Pmax bar`, `PK bar`, `PE bar`, `EE J`, `M g`, `Q mm²`, `N ''`, `alpha ''`, `i ''`, `L3 mm`, `u mm`); `valueText` gives `39.62 -0.2` for `L1`+`L1Tol` of `308_win`; `sectionRows` never emits a `*Tol` row; `sections()` order and omission of empty `junctionCone` for pistols; **for all 25 records**: each non-Tol field appears exactly once per section, count of rows equals count of non-Tol keys
- [X] T015 [US2] Complete `js/format.js` (`angle`, `isAngleKey`, `symbol`, `unit`, `valueText`, `sectionRows`, `sections`, `CARTRIDGE_SECTIONS`, `CHAMBER_SECTIONS`, `degrees`) until T014 is green (D6–D10)
- [X] T016 [P] [US2] Write failing `tests/unit/views-detail.test.js`: `detailView(308_win)` has `<h1>308 Win.</h1>`; facts include alternative names `308 Winchester, 7,62 x 51`, family, category `rifle`, primer type `lr`, C.I.P. table `I`, country `US`, published `1984-06-14`, revised `2008-09-23`, pressure method `Transducer`, water capacity `56 gr H2O` with link text `kwk` to `http://kwk.us/cases.html` and the note; no water row for `7_x_64`; no alternative-names row for `223_rem`; tables have captions and header `Symbol`/`Value`/`Unit`; row `L1 | 39.62 -0.2 | mm`; `Pmax | 4150 | bar`; `α | 40° | ` ; chamber `L3 | 51.44`; a `Print` button and `<a href="#/">All cartridges</a>`; footer text `Source: C.I.P. TDCC, revised 2008-09-23`; `notFoundView('x')` has message and link; no `Tol` symbol anywhere in tables
- [X] T017 [US2] Implement `detailView` in `js/views.js` (tables + facts; drawing slot calls `CIP.drawing.render` when present) until T016 is green
- [X] T018 [US2] Extend `js/app.js`: route `#/cartridge/<key>`, not-found, "Print" → `window.print()`, "All cartridges" link, title `<name> – C.I.P. cartridges`, focus on `<h1>`; extend `css/app.css` for facts and tables (dense, tabular-nums, responsive grid)

**Checkpoint**: US1 and US2 deliver a usable table-only reference.

## Phase 5: User Story 3 – See the cartridge to scale (P1)

**Goal**: generated drawing per rules, labels, notes. **Independent test**: all 25 records produce a drawing whose model matches Appendix A and whose label boxes never intersect.

### Geometry (D12–D19)

- [X] T019 [P] [US3] Write failing `tests/unit/geometry-rim.test.js`: `rimType` for all 25 (belted: 2, rimfire: 3, the others by `R1/P1`; the test computes the expected class from the numbers independently of the code and also asserts that 9,3 x 74 R, 7 x 65 R, 38 Special, 357 Magnum and 44 Rem. Mag. are rimmed); thresholds with synthetic records (1.05 → rimmed, 1.0499 → rimless, 0.98 → rimless, 0.9799 → rebated)
- [X] T020 [P] [US3] Write failing `tests/unit/geometry-profile.test.js`: first outer point `(0,0)`; chamfer start `R1/2 - min(f·tanβ, R1/4)` and end `(R1/2, f)` for `308_win`; square corner when `beta`/`f` missing; rimfire half-round for `22_long_rifle` (ρ = min(R/2,(R1-P1)/2) = 0.545, outermost r = R1/2 at z = ρ); groove points for `308_win` (E1/2 at z=R, floor end z=R+eMin, ramp end `(P1/2, E)`); belted `300_win_mag` ramp end `zr = R+eMin+(R3/2-E1/2)/tanδ`, belt to `E`, step to `P1/2`; no-groove rimmed (`7_x_65_r`, `38_special`) steps `(R1/2,R)→(P1/2,R)` and notes name `E, E1, e min`; body ends at `(P2/2, L1)`, shoulder at `(H1/2, L2)`, neck at `(H2/2, L3)` for every bottleneck record (sampled through the path including fillet tangency: the polyline of skeleton corner points equals the published points); straight cases (pistols, `22_win_mag_r_f`) run to `(H2/2, L3)` and notes list `α, L1, L2, H1, P2` as applicable; fillets: arc radius equals `r1Min`/`r2` when published and tangent-length clamp keeps `t1 + t2 ≤ 0.9 × shoulder length`; missing `r1Min` (338 Lapua Mag.) → sharp corner + note naming `r1 min`; `outer` is monotonic in z for all 25
- [X] T021 [P] [US3] Write failing `tests/unit/geometry-bullet.test.js`: constants `s` and `k` per shape and category (all rows of rule 7, using synthetic category/shape combos), meplat `m` per shape, `zb = L3 - s`, `Lb = L6 - zb`, cylinder end `zb + k·Lb`; pointy: ogive arc radius `ρ = ((G1/2-m/2)²+n²)/(2(G1/2-m/2))`, arc start `(z_c, G1/2)` and end `(L6, m/2)` both at distance ρ from centre `(z_c, G1/2-ρ)`; rounded ellipse centre/radii; heeled `22_long_rifle` (`H2 - G1 = 0 ≤ 0.015`): exposed radius `H2/2`, heel radius `(H2-2tb)/2`; non-heeled `22_win_mag_r_f` not heeled; exposed cylinder is non-empty for all 25 (`zb + k·Lb > L3`)
- [X] T022 [P] [US3] Write failing `tests/unit/geometry-walls.test.js`: `tn`, `tb` formulas for `308_win` (tb = 0.6 by min/max), a case where `0.35·P1/2` binds (synthetic), `w` as max of the five terms for `308_win` (4.8 from pocket 3.3+1.5 vs `E+tb`), `300_win_mag` uses `zr + tb`, rimfire `w = 2.5` and no pocket; pocket table for all eight primer types (`sp spm sr` → 4.45 / 3.04 for `sp spm sr`; `lp lpm` → 5.33 / 3.04; `lr lrm` → 5.33 / 3.3); `innerRadiusAt` = body line − tb before `L1`, linear across the shoulder, `H/2 − tn` in the neck, equals `G1/2` at `L3` for non-heeled; straight case wall taper (D18); `innerRadiusAt(z) < outerRadiusAt(z)` for all z ≥ w for all 25
- [X] T023 [US3] Implement `js/geometry.js` (`buildModel`, `rimType`, `primerPocket`, `bulletParams`, `outerRadiusAt`, `innerRadiusAt`, notes) until T019–T022 are green; no constant other than those in Appendix A and D12–D19 appears in the file

### Drawing layout and SVG (D20–D22)

- [X] T024 [P] [US3] Write failing `tests/unit/drawing-layout.test.js`: for all 25 records the layout has labels `L3 <v>`, `L6 <v>`, `R1`, `R`, `P1` and, exactly when published, `P2 H1 H2 G1 L1 L2 E1 α` (e.g. `L3 51.18` for 308 Win., `α 40°` and `α 50°35'2"` for 6,5 x 55 SE); no label text contains a tolerance; **no two label boxes intersect** (with 0.2 mm tolerance) and **no label box intersects the outline bounding polylines** (outer profile, bullet, mouth) for all 25; no leader line crosses another label box; all boxes inside the viewBox; `fs·194/W ≥ 2` mm for all 25; `printScale = 194/W`; title block lines (name, `C.I.P. table I · revised 2008-09-23`, `Dimensions in mm`, `Scale n:1 (A4 print)`); lane assignment follows D21 for a hand-made anchor set (right-to-left rule)
- [X] T025 [P] [US3] Write failing `tests/unit/drawing-svg.test.js`: `render(308_win)` is well-formed (parse with a tiny XML check or regex balance), root `<svg>` has `role="img"`, `viewBox`, `<title>` `308 Win. drawing` referenced by `aria-labelledby`, `data-rim`; contains hatch patterns, a clipPath for the exposed bullet, a dash-dot centre line, arrowheads count ≥ 2 per dimension, extension lines for `L3 L6 R1 R P1`; contains no `<script>`, `<image>`, `href` to remote, no `NaN`/`undefined`/`Infinity` for **all 25**; coordinates of the outline path start at the axis (x = 0, y = 0) and end at the mouth; 1 unit = 1 mm: the x-extent of the case outline path equals `L3` and the bullet path reaches `L6` within 1e-6 for all 25; notes text appears under the drawing (HTML list) for `22_win_mag_r_f` naming `α`, `L1`, `L2`
- [X] T026 [US3] Implement `js/drawing.js` (`layout`, `render`, `printScale`) until T024–T025 are green; hook `detailView` drawing slot and `<ul class="drawing-notes">` in `js/views.js`; add drawing styles (screen) to `css/app.css` (classes `.outline .hatch .dim .ext .label .centre .title-block`, `vector-effect: non-scaling-stroke`, monospace label stack)
- [X] T027 [US3] Generate SVG files for all 25 records into `test-output/drawings/*.svg` with a dev script `scripts/dump-drawings.js`, and inspect screenshots of a representative set in Chromium (see T038); fix layout issues found (loop until clean)

**Checkpoint**: drawings for all 25 are correct by test and by eye.

## Phase 6: User Story 4 – Print a datasheet (P2)

**Goal**: one A4 page, black on white. **Independent test**: PDF of every record has 1 page.

- [X] T028 [P] [US4] Write failing `tests/e2e/print.test.js` (helpers from T032): for all 25 records, `page.emulateMedia({media:'print'})` and `page.pdf({format:'A4', preferCSSPageSize:true})` → exactly one page; in print media no element among nav, search, family, count, list, Print button, "All cartridges" link is visible (`getComputedStyle`), footer visible with `C.I.P. TDCC` and the revised date, computed colours of text are black and background white even when `colorScheme:'dark'`; the SVG width in print is ≈ 194 mm (±1 mm) and its labels' printed height ≥ 2 mm
- [X] T029 [US4] Create `css/print.css` / `@media print` rules: `@page { size: A4 portrait; margin: 8mm }`, page header with name, hidden chrome, drawing full width with `max-height: 165mm`, tables in 5 columns at 6.8 pt, notes, footer with source; force light colours; tune until T028 is green for all 25 (D23)

## Phase 7: User Story 5 – Comfortable reading on any device (P3)

- [X] T030 [P] [US5] Write failing `tests/e2e/responsive-theme.test.js`: at 360×740 on list, three details (rimless, belted, pistol) `document.documentElement.scrollWidth <= innerWidth`; SVG width ≤ viewport; `colorScheme: 'dark'` vs `'light'` changes `body` background computed colour without reload; numeric cells use `font-variant-numeric: tabular-nums`; tap targets (links/buttons) ≥ 32 px high at 360 px
- [X] T031 [US5] Finish `css/app.css`: light/dark variables via `prefers-color-scheme`, `color-scheme`, phone layout (single column facts, horizontally scroll-free tables), focus styles, reduced motion; green T030

## Phase 8: End-to-end and cross-cutting verification

- [X] T032 [P] Write `tests/e2e/helpers.js` (`launch()` adds `~/chromelibs` to `LD_LIBRARY_PATH` when present (D4), static `http` server on 127.0.0.1:0, `urls = [file://, http://]`, request logger that fails on any non-local request or failed request)
- [X] T033 [P] Write failing `tests/e2e/list.test.js` (both base URLs): heading, 25 rows, `25 cartridges`, search `7,62 x 51` → `308 Win.` and `1 cartridges`, type progressively, Family `rimfire` → 3, `pistol` → 6, combined, no match → `0 cartridges` + empty message, link text equals record names for all 25 (compare to data), clicking `308 Win.` opens detail
- [X] T034 [P] Write failing `tests/e2e/detail.test.js` (both base URLs): for all 25: open `#/cartridge/<key>`, heading equals name, reload keeps view, tables row count equals expected from data via an independent computation in the test (non-Tol keys), `<X>Tol` never as a row, L1 row `39.62 -0.2` for 308, angle examples `39°59'49"` somewhere (find a record with d/m/s) and `40°`; unknown key → not-found; "All cartridges" returns to list; water capacity link `href`; `Print` button calls `window.print` (stub and assert called)
- [X] T035 [P] Write failing `tests/e2e/drawing.test.js` (both base URLs): for all 25: `svg` accessible name `<name> drawing` (`getByRole('img', {name})`); `getBBox` of every label `<text>`: no two intersect, none intersects any outline `<path class="outline">` bounding box polyline test (sample `getPointAtLength` of the outline path) ; label texts present per publication rules; zero `NaN` in attributes; notes visible when expected; SVG fits the viewport at 360 px; `getBBox().width` of the outline equals `L6 × 1` user units (true to scale)
- [X] T036 [P] Write failing `tests/e2e/network.test.js`: all pages of all 25 records on both base URLs make requests only to the document, `css/*`, `js/*` (and for http no `favicon.ico`), no `console.error`, no `pageerror`
- [X] T037 Run the whole e2e suite red→green; fix defects found in app code (not by weakening tests)
- [X] T038 Visual check: screenshots (light, dark, 360 px, print-media) of list and of `223_rem`, `308_win`, `300_win_mag`, `9_3_x_74_r`, `9_mm_luger`, `44_rem_mag`, `22_long_rifle`, `17_hmr`; view them; fix what looks wrong (overlaps, clipped labels, ugly hatch, unreadable text); render PDFs of the same set to images and inspect
- [X] T039 Run `/speckit-analyze` for spec/plan/tasks consistency; resolve findings
- [X] T040 Run `/code-review` (and `/simplify`) on the full diff; fix valid findings
- [X] T041 Final run: `npm test`, `npm run test:e2e`, manual quickstart scenarios; update `specs/001-cartridge-reference/quickstart.md` if commands changed; mark all tasks done; report results honestly (incl. any limits)

## Dependencies & Execution Order

- Phase 1 → Phase 2 → Phase 3 (US1) → Phase 4 (US2) → Phase 5 (US3) → Phase 6 (US4) → Phase 7 (US5) → Phase 8.
- US1 depends only on Phase 2. US2 depends on US1's `index.html`/`app.js`. US3 depends on US2's `detailView` slot but its geometry/layout tasks (T019–T025) depend only on Phase 2 and `format.js` (T015: `degrees`, `valueText`).
- US4 depends on US2 and US3. US5 can start after US1 for list-only checks.
- Within each story: test task(s) → red run → implementation → green run.

## Parallel Opportunities

- T006, T008, T010, T013 (different files); T014 and T016; T019–T022 together; T024 and T025; T028 and T030; T032–T036.

## Implementation Strategy

MVP = Phases 1–4 (list and data tables, deep link). Then geometry and drawing (largest risk, most unit tests), then print, then polish and the browser-based verification, review and analysis passes.

## Notes on execution (deviations, honestly recorded)

- Unit tests for every module were written and run red before the implementation (see `test-log.md`).
- The browser (e2e) tests were written **after** the app existed, because the Chromium harness and a first look at the rendered drawing were needed to design the layout. They were then strengthened with mutation checks (broken lane assignment, tolerance rows leaking, wrong wall constant, wrong ogive radius, cropped viewBox) which each made at least one test fail.
- The A4 margin is 8 mm (printed width 194 mm), changed from the planned 10 mm after the first print-layout measurement (293 mm of 277 mm used); research D22/D23 updated.
- No `pdftoppm` is available, so PDFs were checked by page count (`/Type /Page`) and by print-media screenshots at the A4 content width (`scripts/printcheck.js` reports the content height; the tallest of the 25 uses 270 of 281 mm).
