# Test log (red → green)

Constitution III: each test is run and seen failing before its implementation.

| Task | Red run (date, evidence) | Green run |
|------|--------------------------|-----------|
| T003 data integrity | `npm test` without `js/data.js` → fail, `Cannot find module js/data.js` (first attempt also failed because `node --test <dir>` does not expand directories in Node 22; scripts now use globs) | `# pass 4 # fail 0` |
| T006–T013 list (search, format basics, list view) | 3 modules missing: `# fail 3` (Cannot find module search/format/views) | `# pass 18` |
| T014–T018 format + detail view | `# pass 19 # fail 15` | 4 failures were defects in the new tests (row shape, helper, link regex), fixed; `# pass 34` |
| T019–T023 geometry | `Cannot find module geometry.js` (4 files fail) | 2 test defects fixed (floating boundary, missing `junctionCone` key); `# pass 64` |
| T024–T026 drawing layout and SVG | `Cannot find module drawing.js` (2 files) | `# pass 80`; later `# pass 81` (+ viewBox containment test) |
| T028–T036 e2e (written after the app, see tasks.md notes) | first run: print failed (2 pages for 223 Rem.; strokes in mm were multiplied by the viewBox scale) | `# pass 32` |
| Mutation checks | broken lanes → 3 fail; Tol rows leak → 3 fail; tb constant → 2 fail; ogive radius → 1 fail; viewBox crop (9 units) → 4 unit + 2 e2e fail | restored: all green |
| Review fixes (code-review + simplify) | new tests red first: NaN with partially missing shoulder data, Tol-only key hidden, `undefined` facts, drawing exception, build-data validation (5 failed) | final: unit `# pass 87 # fail 0`; e2e `# pass 32 # fail 0` (run 3 times, stable); synchronous link navigation added after a real click/render race was found |
