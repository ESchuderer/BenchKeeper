'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { suite } = require('./env');
const { data, watch } = require('./helpers');

const keysOf = (group) => Object.values(group).flatMap((sec) => Object.keys(sec).filter((k) => !/Tol$/.test(k))).length;

suite('detail view', ({ label, base, newPage }) => {
  test(`${label} all 25: heading, reload keeps the view, tables hold every value once, no Tol rows`, async () => {
    const { page, ctx } = await newPage();
    const w = watch(page, base());
    for (const r of data) {
      await page.goto(base() + '#/cartridge/' + r.key);
      assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), r.name, r.key);
      await page.reload();
      assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), r.name, r.key + ' after reload');
      const rows = await page.locator('table.values tbody tr').count();
      assert.equal(rows, keysOf(r.cartridge) + keysOf(r.chamber), r.key + ' rows');
      const symbols = await page.locator('table.values tbody th').allInnerTexts();
      assert.ok(!symbols.some((s) => /Tol/.test(s)), r.key);
      const heads = await page.locator('table.values thead tr').first().locator('th').allInnerTexts();
      assert.deepEqual(heads.map((s) => s.toLowerCase()), ['symbol', 'value', 'unit']);
      assert.ok(await page.getByRole('button', { name: 'Print' }).isVisible());
      assert.ok(await page.getByRole('link', { name: 'All cartridges' }).isVisible());
    }
    assert.deepEqual(w.errors, []);
    await ctx.close();
  });

  test(`${label} 308 Win.: facts, tolerance, units, water capacity link`, async () => {
    const { page, ctx } = await newPage();
    await page.goto(base() + '#/cartridge/308_win');
    const facts = await page.locator('dl.facts').innerText();
    for (const t of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) assert.ok(facts.includes(t), t);
    const cart = page.locator('table.values', { has: page.locator('caption', { hasText: 'Lengths' }) }).first();
    const l1 = await cart.locator('tbody tr').first().innerText();
    assert.match(l1.replace(/\s+/g, ' '), /^L1 39\.62 -0\.2 mm$/);
    const press = await page.locator('table.values', { has: page.locator('caption', { hasText: 'Pressures' }) }).first().innerText();
    assert.match(press.replace(/[\t ]+/g, ' '), /Pmax 4150 bar/);
    const link = page.getByRole('link', { name: 'kwk' });
    assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
    assert.ok((await page.locator('table.values').allInnerTexts()).join('\n').includes('α'));
    await ctx.close();
  });

  test(`${label} angles are shown as degrees or d°m's"`, async () => {
    const { page, ctx } = await newPage();
    await page.goto(base() + '#/cartridge/9_3_x_62');
    assert.ok((await page.locator('table.values').allInnerTexts()).join('\n').includes('41°37\'48"'));
    await page.goto(base() + '#/cartridge/308_win');
    assert.ok((await page.locator('table.values').allInnerTexts()).join('\n').includes('71°25\'59"'));
    assert.ok((await page.locator('table.values').allInnerTexts()).join('\n').includes('40°'));
    await ctx.close();
  });

  test(`${label} unknown address shows not found; All cartridges returns to the list; Print calls window.print`, async () => {
    const { page, ctx } = await newPage();
    await page.goto(base() + '#/cartridge/does_not_exist');
    assert.match(await page.locator('main').innerText(), /not found/i);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridges');
    await page.goto(base() + '#/cartridge/%E0%A4%A');
    assert.match(await page.locator('main').innerText(), /not found/i);
    await page.goto(base() + '#/cartridge/223_rem');
    await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
    await page.getByRole('button', { name: 'Print' }).click();
    assert.equal(await page.evaluate(() => window.__printed), 1);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    await page.goBack();
    assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '223 Rem.');
    await ctx.close();
  });

  test(`${label} a new tab opening the address directly shows the same cartridge`, async () => {
    const { page, ctx } = await newPage();
    await page.goto(base() + '#/cartridge/6_5_creedmoor');
    const other = await ctx.newPage();
    await other.goto(page.url());
    assert.equal(await other.getByRole('heading', { level: 1 }).innerText(), '6,5 Creedmoor');
    await ctx.close();
  });
});
