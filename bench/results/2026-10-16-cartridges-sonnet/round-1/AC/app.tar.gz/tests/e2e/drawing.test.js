'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { suite } = require('./env');
const { data } = require('./helpers');

const sym = { alpha: 'α' };
function expectedLabels(r) {
  const c = r.cartridge; const out = {};
  out.L3 = `L3 ${c.lengths.L3}`; out.L6 = `L6 ${c.lengths.L6}`; out.R1 = `R1 ${c.caseHead.R1}`; out.R = `R ${c.caseHead.R}`; out.P1 = `P1 ${c.powderChamber.P1}`;
  if (c.powderChamber.P2 !== undefined) out.P2 = `P2 ${c.powderChamber.P2}`;
  if (c.collar.H1 !== undefined) out.H1 = `H1 ${c.collar.H1}`;
  if (c.collar.H2 !== undefined) out.H2 = `H2 ${c.collar.H2}`;
  if (c.projectile.G1 !== undefined) out.G1 = `G1 ${c.projectile.G1}`;
  if (c.lengths.L1 !== undefined) out.L1 = `L1 ${c.lengths.L1}`;
  if (c.lengths.L2 !== undefined) out.L2 = `L2 ${c.lengths.L2}`;
  if (c.caseHead.E1 !== undefined) out.E1 = `E1 ${c.caseHead.E1}`;
  const a = c.junctionCone && c.junctionCone.alpha;
  if (a !== undefined) out.alpha = `${sym.alpha} ${typeof a === 'number' ? a + '°' : `${a.degrees}°${a.minutes}'${a.seconds}"`}`;
  return out;
}

// Measured in the browser with the fonts actually used.
async function measure(page) {
  return page.evaluate(() => {
    const svg = document.querySelector('svg.cartridge-drawing');
    const ctm = (el) => { const m = el.getCTM(); return m; };
    const labels = [...svg.querySelectorAll('text.label')].map((t) => {
      const b = t.getBBox(); return { id: t.dataset.id, text: t.textContent, x: b.x, y: b.y, w: b.width, h: b.height };
    });
    const title = svg.querySelector('.title-block rect').getBBox();
    const outline = [];
    for (const p of svg.querySelectorAll('path.outline')) {
      const len = p.getTotalLength(); const pts = [];
      for (let d = 0; d <= len; d += 0.25) { const q = p.getPointAtLength(d); pts.push([q.x, q.y]); }
      outline.push({ cls: p.getAttribute('class'), pts });
    }
    const bbox = (sel) => { const b = svg.querySelector(sel).getBBox(); return { x: b.x, y: b.y, w: b.width, h: b.height }; };
    const vb = svg.viewBox.baseVal;
    const all = svg.getBBox();
    const r = svg.getBoundingClientRect();
    return {
      labels, title: { x: title.x, y: title.y, w: title.width, h: title.height }, outline,
      caseUpper: bbox('path.case-upper'), bulletUpper: bbox('path.bullet-upper'),
      viewBox: { x: vb.x, y: vb.y, w: vb.width, h: vb.height }, content: { x: all.x, y: all.y, w: all.width, h: all.height }, rect: { w: r.width, h: r.height },
      docWidth: document.documentElement.scrollWidth, winWidth: window.innerWidth
    };
  });
}
const hit = (a, b, m) => a.x < b.x + b.w + m && b.x < a.x + a.w + m && a.y < b.y + b.h + m && b.y < a.y + a.h + m;

suite('drawing in the browser', ({ label, base, newPage }) => {
  test(`${label} all 25: accessible name, labels as published, true to scale, no overlaps (getBBox)`, async () => {
    const { page, ctx } = await newPage({ viewport: { width: 1100, height: 900 } });
    for (const r of data) {
      await page.goto(base() + '#/cartridge/' + r.key);
      const img = page.getByRole('img', { name: r.name + ' drawing', exact: true });
      assert.equal(await img.count(), 1, r.key + ' accessible name');
      const m = await measure(page);
      const want = expectedLabels(r);
      assert.deepEqual(Object.fromEntries(m.labels.map((l) => [l.id, l.text])), want, r.key + ' labels');

      for (let i = 0; i < m.labels.length; i++) {
        const a = m.labels[i];
        assert.ok(a.w > 0 && a.h > 0, `${r.key} ${a.id} has glyphs`);
        for (let j = i + 1; j < m.labels.length; j++) assert.ok(!hit(a, m.labels[j], 0), `${r.key}: ${a.id} overlaps ${m.labels[j].id}`);
        assert.ok(!hit(a, m.title, 0), `${r.key}: ${a.id} overlaps the title block`);
        const vb = m.viewBox;
        assert.ok(a.x >= vb.x && a.y >= vb.y && a.x + a.w <= vb.x + vb.w && a.y + a.h <= vb.y + vb.h, `${r.key} ${a.id} inside the viewBox`);
        for (const o of m.outline) for (const [x, y] of o.pts) {
          assert.ok(!(x > a.x - 0.1 && x < a.x + a.w + 0.1 && y > a.y - 0.1 && y < a.y + a.h + 0.1), `${r.key}: label ${a.id} touches ${o.cls}`);
        }
      }
      const c = m.content; const vbx = m.viewBox;
      assert.ok(c.x >= vbx.x - 1e-6 && c.y >= vbx.y - 1e-6 && c.x + c.w <= vbx.x + vbx.w + 1e-6 && c.y + c.h <= vbx.y + vbx.h + 1e-6, `${r.key}: drawing content leaves the viewBox`);
      // 1 SVG unit = 1 mm
      assert.ok(Math.abs(m.caseUpper.w - r.cartridge.lengths.L3) < 0.01, `${r.key} case length ${m.caseUpper.w}`);
      assert.ok(Math.abs(m.bulletUpper.x + m.bulletUpper.w - r.cartridge.lengths.L6) < 0.01, `${r.key} overall length`);
      const h = r.cartridge.caseHead;
      assert.ok(Math.abs(m.caseUpper.h - Math.max(h.R1, h.R3 || 0, r.cartridge.powderChamber.P1) / 2) < 0.01, `${r.key} max radius ${m.caseUpper.h}`);
    }
    await ctx.close();
  });

  test(`${label} notes name the missing values (22 Win. Mag. R.F., 38 Special)`, async () => {
    const { page, ctx } = await newPage();
    await page.goto(base() + '#/cartridge/22_win_mag_r_f');
    const notes = await page.locator('.drawing-notes').innerText();
    assert.match(notes, /straight case: α, L1, L2, H1, P2 not published/);
    await page.goto(base() + '#/cartridge/38_special');
    assert.match(await page.locator('.drawing-notes').innerText(), /groove[^\n]*E, E1, e min not published/);
    await page.goto(base() + '#/cartridge/308_win');
    assert.equal(await page.locator('.drawing-notes').count(), 0);
    await ctx.close();
  });

  test(`${label} the drawing fits a 360 px screen and keeps its labels readable (>= 6.5 px)`, async () => {
    const { page, ctx } = await newPage({ viewport: { width: 360, height: 740 } });
    for (const r of data) {
      await page.goto(base() + '#/cartridge/' + r.key);
      const m = await measure(page);
      assert.ok(m.docWidth <= m.winWidth, `${r.key} horizontal scroll ${m.docWidth} > ${m.winWidth}`);
      assert.ok(m.rect.w <= 360, r.key);
      const px = await page.evaluate(() => { const t = document.querySelector('text.label'); const s = document.querySelector('svg.cartridge-drawing'); return parseFloat(t.getAttribute('font-size')) * s.getBoundingClientRect().width / s.viewBox.baseVal.width; });
      assert.ok(px >= 6.5, `${r.key} label size ${px}px`);
    }
    await ctx.close();
  });
});
