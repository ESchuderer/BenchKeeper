'use strict';
// Runs a test body once per base URL (file:// and a static http server).
const test = require('node:test');
const { launch, startServer, fileBase } = require('./helpers');

function suite(name, body) {
  test.describe(name, () => {
    let browser; let srv;
    test.before(async () => { browser = await launch(); srv = await startServer(); });
    test.after(async () => { await browser.close(); await srv.close(); });
    const bases = [['file://', () => fileBase], ['http', () => srv.base]];
    for (const [label, base] of bases) {
      body({
        label,
        base,
        newPage: async (opts) => { const ctx = await browser.newContext(opts); const page = await ctx.newPage(); return { page, ctx }; }
      });
    }
  });
}
module.exports = { suite };
