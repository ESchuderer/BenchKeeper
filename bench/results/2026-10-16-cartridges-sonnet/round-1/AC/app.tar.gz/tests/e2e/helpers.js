'use strict';
// Shared helpers for the browser tests: launch Chromium, serve the folder, watch requests.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { chromium } = require('playwright');

const root = path.resolve(__dirname, '..', '..');

// Chromium needs system libraries; where they are not installed (and we are not root) they can be
// unpacked to ~/chromelibs (see specs/001-cartridge-reference/research.md D4).
function launchEnv() {
  const env = { ...process.env };
  const dirs = ['usr/lib/x86_64-linux-gnu', 'lib/x86_64-linux-gnu'].map((d) => path.join(os.homedir(), 'chromelibs', d)).filter((d) => fs.existsSync(d));
  if (dirs.length) env.LD_LIBRARY_PATH = dirs.concat(env.LD_LIBRARY_PATH ? [env.LD_LIBRARY_PATH] : []).join(':');
  const conf = path.join(os.homedir(), 'chromelibs', 'fonts.conf');
  if (fs.existsSync(conf) && !env.FONTCONFIG_FILE) env.FONTCONFIG_FILE = conf; // fonts for a container without any
  return env;
}
function launch() { return chromium.launch({ env: launchEnv() }); }

const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.jsonl': 'text/plain' };
function startServer() {
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    let rel;
    try { rel = decodeURIComponent(url.pathname); } catch (e) { res.writeHead(400); res.end('bad request'); return; }
    if (rel.endsWith('/')) rel += 'index.html';
    const file = path.join(root, rel);
    const inside = path.relative(root, file);
    if (inside.startsWith('..') || path.isAbsolute(inside) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
    res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => {
    resolve({ server, base: `http://127.0.0.1:${server.address().port}/index.html`, close: () => new Promise((r) => server.close(r)) });
  }));
}

const fileBase = 'file://' + path.join(root, 'index.html');

// Records requests; anything that is not the document, css/, js/ of this app is a violation.
function watch(page, base) {
  const origin = base.startsWith('file:') ? null : new URL(base).origin;
  const seen = []; const violations = []; const errors = [];
  page.on('request', (req) => {
    const u = req.url(); seen.push(u);
    const ok = u.startsWith('data:') || (origin ? u.startsWith(origin + '/') && /\/(index\.html|css\/[\w.-]+\.css|js\/[\w.-]+\.js)(\?.*)?$/.test(u.slice(origin.length)) : u.startsWith('file://' + root + '/') && /\/(index\.html|css\/[\w.-]+\.css|js\/[\w.-]+\.js)$/.test(u));
    if (!ok) violations.push(u);
  });
  page.on('requestfailed', (req) => violations.push('FAILED ' + req.url()));
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  return { seen, violations, errors };
}

const data = require(path.join(root, 'js', 'data.js'));

module.exports = { root, launch, startServer, fileBase, watch, data };
