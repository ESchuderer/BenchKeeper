'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { suite } = require('./env');
const { data, watch } = require('./helpers');

suite('list view', ({ label, base, newPage }) => {
  test(`${label} heading, rows, count, search and family filter`, async () => {
    const { page, ctx } = await newPage();
    const w = watch(page, base());
    await page.goto(base() + '#/');
    assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridges');
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    assert.equal(await page.locator('table.list tbody tr').count(), 25);

    await page.getByLabel('Search').fill('7,62 x 51');
    assert.equal(await page.locator('#count').innerText(), '1 cartridges');
    assert.deepEqual(await page.locator('table.list tbody a').allInnerTexts(), ['308 Win.']);

    await page.getByLabel('Search').fill('');
    await page.getByLabel('Family').selectOption('rimfire');
    assert.equal(await page.locator('#count').innerText(), '3 cartridges');
    await page.getByLabel('Family').selectOption('pistol');
    assert.equal(await page.locator('#count').innerText(), '6 cartridges');
    await page.getByLabel('Search').fill('22');
    assert.equal(await page.locator('#count').innerText(), '0 cartridges');
    assert.match(await page.locator('table.list').innerText(), /No cartridge matches\./);
    await page.getByLabel('Family').selectOption('');
    const norm = (t) => t.toLowerCase().replace(/\s+/g, '');
    const expected = data.filter((r) => [r.name].concat(r.alternativeNames || []).some((n) => norm(n).includes('22'))).length;
    assert.equal(await page.locator('#count').innerText(), `${expected} cartridges`);
    const opts = await page.getByLabel('Family').locator('option').allInnerTexts();
    assert.deepEqual(opts, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
    assert.deepEqual(w.errors, []);
    await ctx.close();
  });

  test(`${label} typing updates the list on every keystroke`, async () => {
    const { page, ctx } = await newPage();
    await page.goto(base() + '#/');
    await page.getByLabel('Search').pressSequentially('30-06', { delay: 20 });
    assert.deepEqual(await page.locator('table.list tbody a').allInnerTexts(), ['30-06 Spring.']);
    await ctx.close();
  });

  test(`${label} every name is a link with exactly the record name; family and L3 shown`, async () => {
    const { page, ctx } = await newPage();
    await page.goto(base() + '#/');
    for (const r of data) {
      const row = page.locator(`tr[data-key="${r.key}"]`);
      assert.equal(await row.locator('a').innerText(), r.name);
      assert.equal(await row.locator('a').getAttribute('href'), `#/cartridge/${r.key}`);
      const cells = await row.locator('td').allInnerTexts();
      assert.equal(cells[1], r.family);
      assert.equal(cells[2], String(r.cartridge.lengths.L3));
    }
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '308 Win.');
    await ctx.close();
  });
});
