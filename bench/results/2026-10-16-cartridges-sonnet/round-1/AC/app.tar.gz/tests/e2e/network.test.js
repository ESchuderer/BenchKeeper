'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { suite } = require('./env');
const { data, watch } = require('./helpers');

suite('network and console', ({ label, base, newPage }) => {
  test(`${label} the app makes no request beyond its own html, css and js and logs no errors`, async () => {
    const { page, ctx } = await newPage();
    const w = watch(page, base());
    await page.goto(base() + '#/');
    for (const r of data) { await page.goto(base() + '#/cartridge/' + r.key); await page.locator('svg.cartridge-drawing').waitFor(); }
    await page.goto(base() + '#/');
    await page.emulateMedia({ media: 'print' });
    assert.deepEqual(w.violations, []);
    assert.deepEqual(w.errors, []);
    assert.ok(w.seen.length >= 8, 'html, 2 css, 7 js were requested: ' + w.seen.length);
    await ctx.close();
  });
});
