'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { suite } = require('./env');
const { data, root } = require('./helpers');

const pages = (buf) => (buf.toString('latin1').match(/\/Type\s*\/Page(?![s\w])/g) || []).length;
const out = path.join(root, 'test-output', 'pdf');

suite('print', ({ label, base, newPage }) => {
  test(`${label} all 25 print on one A4 portrait page, black on white, chrome hidden`, async () => {
    fs.mkdirSync(out, { recursive: true });
    const { page, ctx } = await newPage({ colorScheme: 'dark', viewport: { width: 1100, height: 900 } });
    for (const r of data) {
      await page.goto(base() + '#/cartridge/' + r.key);
      await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
      const buf = await page.pdf({ format: 'A4', preferCSSPageSize: true, printBackground: true });
      if (label === 'http') fs.writeFileSync(path.join(out, r.key + '.pdf'), buf);
      assert.equal(pages(buf), 1, `${r.key}: ${pages(buf)} pages`);
      const info = await page.evaluate(() => {
        const vis = (sel) => [...document.querySelectorAll(sel)].some((e) => e.getClientRects().length > 0);
        const svg = document.querySelector('svg.cartridge-drawing');
        const t = document.querySelector('text.label');
        const rect = svg.getBoundingClientRect();
        return {
          hidden: ['.site-header', '.actions', '#print-button', 'a.back', '.filters', '#count'].filter((s) => vis(s)),
          bodyBg: getComputedStyle(document.body).backgroundColor, bodyColor: getComputedStyle(document.body).color,
          labelFill: getComputedStyle(t).fill, outlineStroke: getComputedStyle(document.querySelector('path.outline')).stroke,
          dimStroke: getComputedStyle(document.querySelector('.dim-line')).stroke,
          svgW: rect.width, svgH: rect.height,
          labelMm: parseFloat(t.getAttribute('font-size')) * rect.width / svg.viewBox.baseVal.width / 96 * 25.4,
          footer: document.querySelector('.print-footer') ? getComputedStyle(document.querySelector('.print-footer')).display + '|' + document.querySelector('.print-footer').innerText : null,
          h1: document.querySelector('h1').innerText, h1Display: getComputedStyle(document.querySelector('h1')).display
        };
      });
      assert.deepEqual(info.hidden, [], r.key);
      assert.equal(info.bodyBg, 'rgb(255, 255, 255)', r.key); assert.equal(info.bodyColor, 'rgb(0, 0, 0)', r.key);
      assert.equal(info.labelFill, 'rgb(0, 0, 0)'); assert.equal(info.outlineStroke, 'rgb(0, 0, 0)'); assert.equal(info.dimStroke, 'rgb(0, 0, 0)');
      assert.ok(Math.abs(info.svgW - 194 / 25.4 * 96) < 3, `${r.key} drawing width ${info.svgW}`);
      assert.ok(info.labelMm >= 2, `${r.key} label height ${info.labelMm} mm`);
      assert.equal(info.footer, `block|Source: C.I.P. TDCC, revised ${r.revised}`, r.key);
      assert.equal(info.h1, r.name); assert.notEqual(info.h1Display, 'none');
    }
    await ctx.close();
  });

  test(`${label} the print stylesheet does not affect the screen`, async () => {
    const { page, ctx } = await newPage({ viewport: { width: 1100, height: 900 } });
    await page.goto(base() + '#/cartridge/308_win');
    assert.ok(await page.locator('.site-header').isVisible());
    assert.ok(await page.getByRole('button', { name: 'Print' }).isVisible());
    assert.ok(!(await page.locator('.print-footer').isVisible()));
    await ctx.close();
  });
});
