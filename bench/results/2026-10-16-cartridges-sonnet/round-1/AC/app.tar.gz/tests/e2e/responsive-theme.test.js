'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { suite } = require('./env');

suite('responsive and theme', ({ label, base, newPage }) => {
  test(`${label} 360 px: no horizontal scroll on list and details; tap targets >= 32 px`, async () => {
    const { page, ctx } = await newPage({ viewport: { width: 360, height: 740 } });
    for (const hash of ['#/', '#/cartridge/223_rem', '#/cartridge/300_win_mag', '#/cartridge/9_mm_luger', '#/cartridge/22_long_rifle']) {
      await page.goto(base() + hash);
      const w = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
      assert.ok(w[0] <= w[1], `${hash} scrollWidth ${w[0]} > ${w[1]}`);
    }
    await page.goto(base() + '#/');
    const h = await page.evaluate(() => [...document.querySelectorAll('table.list a, #search, #family')].map((e) => e.getBoundingClientRect().height));
    assert.ok(Math.min(...h) >= 32, 'smallest target ' + Math.min(...h));
    await page.goto(base() + '#/cartridge/223_rem');
    const b = await page.evaluate(() => [...document.querySelectorAll('button, a.back')].map((e) => e.getBoundingClientRect().height));
    assert.ok(Math.min(...b) >= 32, 'smallest target ' + Math.min(...b));
    await ctx.close();
  });

  test(`${label} colour scheme follows the system without reload; numerals are tabular`, async () => {
    const { page, ctx } = await newPage({ colorScheme: 'light', viewport: { width: 1100, height: 900 } });
    await page.goto(base() + '#/cartridge/308_win');
    const bg = () => page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    const light = await bg();
    await page.emulateMedia({ colorScheme: 'dark' });
    const dark = await bg();
    assert.notEqual(light, dark);
    await page.emulateMedia({ colorScheme: 'light' });
    assert.equal(await bg(), light);
    const tab = await page.evaluate(() => [getComputedStyle(document.querySelector('td.num')).fontVariantNumeric, getComputedStyle(document.querySelector('svg .label')).fontVariantNumeric]);
    for (const t of tab) assert.match(t, /tabular-nums/);
    const lum = (c) => c.match(/\d+/g).slice(0, 3).map(Number).reduce((a, b) => a + b, 0);
    assert.ok(lum(light) > 600 && lum(dark) < 150, `${light} vs ${dark}`);
    await ctx.close();
  });
});
