'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { root, readJsonl } = require('./helpers');

function runIn(lines) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cip-build-'));
  fs.mkdirSync(path.join(dir, 'data')); fs.mkdirSync(path.join(dir, 'js')); fs.mkdirSync(path.join(dir, 'scripts'));
  fs.copyFileSync(path.join(root, 'scripts', 'build-data.js'), path.join(dir, 'scripts', 'build-data.js'));
  fs.writeFileSync(path.join(dir, 'data', 'cartridges.jsonl'), lines.join('\n') + '\n');
  const res = spawnSync(process.execPath, [path.join(dir, 'scripts', 'build-data.js')], { encoding: 'utf8' });
  return { res, dir };
}
const good = () => readJsonl().map((r) => JSON.stringify(r));

test('build-data writes the script for the real data', () => {
  const { res, dir } = runIn(good());
  assert.equal(res.status, 0, res.stderr);
  assert.ok(fs.existsSync(path.join(dir, 'js', 'data.js')));
});

test('build-data refuses duplicate keys, missing fields and unparsable lines', () => {
  const lines = good();
  const dup = runIn(lines.concat([lines[0]]));
  assert.notEqual(dup.res.status, 0); assert.match(dup.res.stderr, /duplicate key/i);
  const noName = readJsonl()[0]; delete noName.name;
  const miss = runIn([JSON.stringify(noName)]);
  assert.notEqual(miss.res.status, 0); assert.match(miss.res.stderr, /name/);
  const bad = runIn(lines.slice(0, 2).concat(['{not json']));
  assert.notEqual(bad.res.status, 0); assert.match(bad.res.stderr, /line 3/);
});
