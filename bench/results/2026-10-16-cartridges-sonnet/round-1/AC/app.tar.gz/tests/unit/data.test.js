'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { root, readJsonl, loadAll } = require('./helpers');

test('js/data.js holds exactly the 25 records of data/cartridges.jsonl, unchanged', () => {
  const src = readJsonl();
  const data = loadAll();
  assert.equal(src.length, 25);
  assert.equal(data.length, 25);
  assert.deepEqual(data, src);
});

test('keys are unique and route-safe', () => {
  const keys = loadAll().map((r) => r.key);
  assert.equal(new Set(keys).size, keys.length);
  for (const k of keys) assert.match(k, /^[a-z0-9_]+$/);
});

test('every <X>Tol field has its <X> sibling', () => {
  for (const r of loadAll()) {
    for (const group of [r.cartridge, r.chamber]) {
      for (const [sec, obj] of Object.entries(group)) {
        for (const k of Object.keys(obj)) {
          if (/Tol$/.test(k)) assert.ok(k.slice(0, -3) in obj, `${r.key}.${sec}.${k}`);
        }
      }
    }
  }
});

test('js/data.js is a classic script that sets window.CIP_DATA in a browser', () => {
  const text = fs.readFileSync(path.join(root, 'js', 'data.js'), 'utf8');
  assert.doesNotMatch(text, /^\s*(import|export)\s/m);
  const sandbox = { CIP: undefined };
  new Function('window', 'module', text)(sandbox, undefined);
  assert.equal(sandbox.CIP.data.length, 25);
});
