'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll, byKey } = require('./helpers');
const geometry = require('../../js/geometry.js');
const drawing = require('../../js/drawing.js');
const format = require('../../js/format.js');

const layoutOf = (r) => drawing.layout(geometry.buildModel(r), r);
const clone = (o) => JSON.parse(JSON.stringify(o));
const ids = (l) => l.labels.map((x) => x.id);

function boxesIntersect(a, b, m = 0) {
  return a.x < b.x + b.w + m && b.x < a.x + a.w + m && a.y < b.y + b.h + m && b.y < a.y + a.h + m;
}
function segHitsBox(p, q, b, m = 0) {
  // Liang-Barsky against the expanded rectangle
  const x0 = b.x - m; const x1 = b.x + b.w + m; const y0 = b.y - m; const y1 = b.y + b.h + m;
  let t0 = 0; let t1 = 1; const dx = q.x - p.x; const dy = q.y - p.y;
  for (const [pp, qq] of [[-dx, p.x - x0], [dx, x1 - p.x], [-dy, p.y - y0], [dy, y1 - p.y]]) {
    if (pp === 0) { if (qq < 0) return false; } else {
      const t = qq / pp;
      if (pp < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
  }
  return t0 <= t1;
}

test('label set follows the publication rules for every record', () => {
  for (const r of loadAll()) {
    const l = layoutOf(r); const c = r.cartridge; const got = ids(l);
    for (const id of ['L3', 'L6', 'R1', 'R', 'P1']) assert.ok(got.includes(id), `${r.key} ${id}`);
    const pub = {
      P2: c.powderChamber.P2 !== undefined, H1: c.collar.H1 !== undefined, H2: c.collar.H2 !== undefined,
      G1: c.projectile.G1 !== undefined, L1: c.lengths.L1 !== undefined, L2: c.lengths.L2 !== undefined,
      E1: c.caseHead.E1 !== undefined, alpha: !!(c.junctionCone && c.junctionCone.alpha !== undefined)
    };
    for (const [id, p] of Object.entries(pub)) assert.equal(got.includes(id), p, `${r.key} ${id}`);
    assert.equal(new Set(got).size, got.length, 'unique ids');
  }
});

test('label texts: symbol and value as published', () => {
  const l = layoutOf(byKey('308_win'));
  const t = Object.fromEntries(l.labels.map((x) => [x.id, x.text]));
  assert.equal(t.L3, 'L3 51.18'); assert.equal(t.L6, 'L6 71.12'); assert.equal(t.R1, 'R1 12.01');
  assert.equal(t.R, 'R 1.37'); assert.equal(t.P1, 'P1 11.96'); assert.equal(t.P2, 'P2 11.53');
  assert.equal(t.H1, 'H1 8.72'); assert.equal(t.H2, 'H2 8.72'); assert.equal(t.G1, 'G1 7.85');
  assert.equal(t.L1, 'L1 39.62'); assert.equal(t.L2, 'L2 43.48'); assert.equal(t.E1, 'E1 10.39');
  assert.equal(t.alpha, 'α 40°');
  assert.equal(layoutOf(byKey('6_5_x_55_se')).labels.find((x) => x.id === 'alpha').text, 'α 50°35\'2"');
  // no tolerance in drawing labels
  assert.equal(layoutOf(byKey('9_mm_luger')).labels.find((x) => x.id === 'L3').text, 'L3 19.15');
  for (const r of loadAll()) for (const x of layoutOf(r).labels) assert.doesNotMatch(x.text, /Tol/, r.key);
});

test('no two labels overlap, no label touches the outline, nothing leaves the viewBox (all 25)', () => {
  for (const r of loadAll()) {
    const m = geometry.buildModel(r); const l = drawing.layout(m, r);
    for (let i = 0; i < l.labels.length; i++) {
      for (let j = i + 1; j < l.labels.length; j++) {
        assert.ok(!boxesIntersect(l.labels[i], l.labels[j], 0.1), `${r.key}: ${l.labels[i].id} x ${l.labels[j].id}`);
      }
    }
    const vb = l.viewBox;
    for (const b of l.labels.concat([l.title])) {
      assert.ok(b.x >= vb.x && b.y >= vb.y && b.x + b.w <= vb.x + vb.w && b.y + b.h <= vb.y + vb.h, `${r.key} ${b.id || 'title'} inside viewBox`);
    }
    // outline polylines in drawing coordinates (y = -r above, +r below)
    const polys = drawing.outlinePolylines(m);
    assert.ok(polys.length >= 3);
    for (const b of l.labels.concat([l.title])) {
      for (const poly of polys) {
        for (let k = 1; k < poly.length; k++) {
          assert.ok(!segHitsBox(poly[k - 1], poly[k], b, 0.2), `${r.key}: ${b.id || 'title'} meets the outline`);
        }
      }
    }
  }
});

test('every line, arrowhead and the centre line lie inside the viewBox (all 25)', () => {
  for (const r of loadAll()) {
    const m = geometry.buildModel(r); const l = drawing.layout(m, r); const vb = l.viewBox;
    const inside = (x, y, what) => assert.ok(x >= vb.x - 1e-9 && x <= vb.x + vb.w + 1e-9 && y >= vb.y - 1e-9 && y <= vb.y + vb.h + 1e-9, `${r.key}: ${what} (${x}, ${y}) outside ${JSON.stringify(vb)}`);
    for (const d of l.dims) {
      for (const s of d.lines) { inside(s.p.x, s.p.y, d.id + ' line'); inside(s.q.x, s.q.y, d.id + ' line'); }
      for (const a of d.arrows) { inside(a.tip.x, a.tip.y, d.id + ' arrow'); inside(a.tip.x - a.dir.x * a.len, a.tip.y - a.dir.y * a.len, d.id + ' arrow tail'); }
    }
    for (const poly of drawing.outlinePolylines(m)) for (const p of poly) inside(p.x, p.y, 'outline');
    inside(-1.5 * l.fs, 0, 'centre line start'); inside(r.cartridge.lengths.L6 + 1.5 * l.fs, 0, 'centre line end');
  }
});

test('leaders and dimension lines never cross another label', () => {
  for (const r of loadAll()) {
    const l = layoutOf(r);
    for (const d of l.dims) {
      for (const seg of d.lines) {
        for (const b of l.labels) {
          if (b.id === d.id) continue;
          assert.ok(!segHitsBox(seg.p, seg.q, b, 0.05), `${r.key}: line of ${d.id} crosses label ${b.id}`);
        }
        assert.ok(!segHitsBox(seg.p, seg.q, l.title, 0.05), `${r.key}: line of ${d.id} crosses the title block`);
      }
    }
  }
});

test('every dimension has arrowheads; extension lines exist for L3, L6, R1, R, P1', () => {
  for (const r of loadAll()) {
    const l = layoutOf(r);
    for (const d of l.dims) {
      assert.ok(d.arrows.length >= (d.kind === 'angle' ? 1 : 2), `${r.key} ${d.id} arrows`);
      for (const a of d.arrows) assert.ok(Number.isFinite(a.tip.x) && Number.isFinite(a.tip.y) && Math.abs(Math.hypot(a.dir.x, a.dir.y) - 1) < 1e-9);
    }
    for (const id of ['L3', 'L6', 'R1', 'R', 'P1']) {
      const d = l.dims.find((x) => x.id === id);
      assert.ok(d, `${r.key} ${id}`);
      assert.ok(d.lines.some((s) => s.kind === 'ext'), `${r.key} ${id} extension line`);
      assert.ok(d.lines.some((s) => s.kind === 'dim') || d.kind === 'angle', `${r.key} ${id} dimension line`);
    }
  }
});

test('dimension lines measure the published values at 1 unit = 1 mm', () => {
  for (const r of loadAll()) {
    const l = layoutOf(r); const c = r.cartridge;
    const dimLen = (id) => { const s = l.dims.find((x) => x.id === id).lines.find((x) => x.kind === 'dim'); return { dx: Math.abs(s.q.x - s.p.x), dy: Math.abs(s.q.y - s.p.y) }; };
    assert.ok(Math.abs(dimLen('L3').dx - c.lengths.L3) < 1e-6, r.key + ' L3');
    assert.ok(Math.abs(dimLen('L6').dx - c.lengths.L6) < 1e-6, r.key + ' L6');
    assert.ok(Math.abs(dimLen('R').dx - c.caseHead.R) < 1e-6, r.key + ' R');
    assert.ok(Math.abs(dimLen('R1').dy - c.caseHead.R1) < 1e-6, r.key + ' R1');
    assert.ok(Math.abs(dimLen('P1').dy - c.powderChamber.P1) < 1e-6, r.key + ' P1');
    assert.ok(Math.abs(dimLen('H2').dy - c.collar.H2) < 1e-6, r.key + ' H2');
    assert.ok(Math.abs(dimLen('G1').dy - c.projectile.G1) < 1e-6, r.key + ' G1');
  }
});

test('print scale and legibility: scale = 194 / viewBox width, printed text >= 2 mm', () => {
  for (const r of loadAll()) {
    const l = layoutOf(r);
    assert.ok(Math.abs(drawing.printScale(l) - 194 / l.viewBox.w) < 1e-12);
    assert.ok(l.fs * 194 / l.viewBox.w >= 2, `${r.key} printed text ${l.fs * 194 / l.viewBox.w} mm`);
    // the drawing must leave room for tables on the A4 page
    assert.ok(l.viewBox.h / l.viewBox.w <= 0.82, `${r.key} aspect ${l.viewBox.h / l.viewBox.w}`);
  }
});

test('title block: name, C.I.P. table and revision, units, scale', () => {
  const r = byKey('308_win'); const l = layoutOf(r);
  const scale = (194 / l.viewBox.w).toFixed(2);
  assert.deepEqual(l.title.lines, ['308 Win.', 'C.I.P. table I · revised 2008-09-23', 'Dimensions in mm', `Scale ${scale}:1 (A4 print)`]);
});

test('lane assignment: a label sits above every label whose anchor lies inside its box', () => {
  const items = [{ id: 'a', x: 0.7, w: 9 }, { id: 'b', x: 2.3, w: 9 }, { id: 'c', x: 3.85, w: 9 }, { id: 'd', x: 36, w: 9 }, { id: 'e', x: 39.5, w: 9 }];
  const lanes = drawing.assignLanes(items, 0.4);
  assert.deepEqual(lanes, { c: 0, b: 1, a: 2, e: 0, d: 1 });
  assert.deepEqual(drawing.assignLanes([{ id: 'x', x: 0, w: 3 }, { id: 'y', x: 50, w: 3 }], 0.4), { x: 0, y: 0 });
  // equal anchors get different lanes
  const eq = drawing.assignLanes([{ id: 'p', x: 5, w: 3 }, { id: 'q', x: 5, w: 3 }], 0.4);
  assert.notEqual(eq.p, eq.q);
});

test('missing values: drawing still lays out without the feature (rule 9)', () => {
  const r = clone(byKey('308_win'));
  delete r.cartridge.caseHead.E1; delete r.cartridge.junctionCone.alpha;
  const l = layoutOf(r);
  assert.ok(!ids(l).includes('E1') && !ids(l).includes('alpha'));
  assert.ok(ids(l).includes('L3'));
});

test('partially missing shoulder data degrades without NaN or overlaps (rule 9)', () => {
  for (const drop of [['collar', 'H1'], ['powderChamber', 'P2'], ['lengths', 'L1'], ['lengths', 'L2'], ['junctionCone', 'alpha'], ['caseHead', 'R3'], ['caseHead', 'E']]) {
    for (const key of ['308_win', '300_win_mag']) {
      const r = clone(byKey(key)); delete r.cartridge[drop[0]][drop[1]];
      const m = geometry.buildModel(r); const l = drawing.layout(m, r);
      const svg = drawing.render(r);
      assert.doesNotMatch(svg, /NaN|undefined|Infinity/, `${key} without ${drop.join('.')}`);
      if (!(key === '308_win' && drop[1] === 'R3')) assert.ok(m.notes.length > 0, `${key} without ${drop.join('.')}: a note names it`); // R3 only matters on belted cases
      for (let i = 0; i < l.labels.length; i++) for (let j = i + 1; j < l.labels.length; j++) {
        assert.ok(!boxesIntersect(l.labels[i], l.labels[j], 0.1), `${key} without ${drop.join('.')}: ${l.labels[i].id} x ${l.labels[j].id}`);
      }
    }
  }
  // a dimension that cannot be located is not drawn
  const r = clone(byKey('308_win')); delete r.cartridge.collar.H1;
  assert.ok(!ids(layoutOf(r)).includes('H1'));
});
