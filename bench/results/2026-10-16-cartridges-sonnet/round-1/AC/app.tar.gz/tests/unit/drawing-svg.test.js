'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll, byKey } = require('./helpers');
const geometry = require('../../js/geometry.js');
const drawing = require('../../js/drawing.js');
const format = require('../../js/format.js');

// Minimal well-formedness check: balanced tags, quoted attributes.
function assertWellFormed(xml, label) {
  const stack = [];
  const re = /<(\/?)([a-zA-Z][\w:-]*)((?:\s+[\w:-]+="[^"]*")*)\s*(\/?)>/g;
  let last = 0; let m;
  while ((m = re.exec(xml))) {
    assert.ok(!/[<]/.test(xml.slice(last, m.index).replace(/<[^>]*$/, '')) || true);
    last = re.lastIndex;
    if (m[4]) continue;
    if (m[1]) { assert.equal(stack.pop(), m[2], `${label}: closing ${m[2]}`); } else stack.push(m[2]);
  }
  assert.equal(stack.length, 0, `${label}: unclosed ${stack}`);
  assert.equal(xml.replace(re, '').replace(/[^<>]/g, ''), '', `${label}: stray angle brackets`);
}
const attr = (tag, name) => (tag.match(new RegExp(`\\s${name}="([^"]*)"`)) || [])[1];
// end points of the path commands (M/L: x y; A: rx ry rot large sweep x y)
function points(d) {
  const out = [];
  for (const m of d.matchAll(/([MLAZ])([^MLAZ]*)/g)) {
    const n = (m[2].match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
    if (m[1] === 'M' || m[1] === 'L') out.push({ x: n[0], y: n[1] });
    else if (m[1] === 'A') out.push({ x: n[5], y: n[6] });
  }
  return out;
}

test('render(308 Win.): accessible, scaled SVG with the required parts', () => {
  const r = byKey('308_win');
  const svg = drawing.render(r);
  assertWellFormed(svg, '308');
  const root = svg.match(/<svg[^>]*>/)[0];
  assert.equal(attr(root, 'role'), 'img');
  assert.match(attr(root, 'viewBox'), /^-?[\d.]+ -?[\d.]+ [\d.]+ [\d.]+$/);
  assert.equal(attr(root, 'data-rim'), 'rimless');
  const labelled = attr(root, 'aria-labelledby');
  assert.match(svg, new RegExp(`<title id="${labelled.split(' ')[0]}">308 Win\\. drawing</title>`));
  assert.match(svg, /<pattern id="hatch-case"/);
  assert.match(svg, /<pattern id="hatch-bullet"/);
  assert.match(svg, /<clipPath id="clip-exposed"/);
  assert.match(svg, /class="centre"/);
  assert.ok((svg.match(/class="arrow"/g) || []).length >= 20);
  assert.match(svg, />L3 51\.18</);
  assert.match(svg, />Dimensions in mm</);
  assert.match(svg, /Scale \d+\.\d\d:1 \(A4 print\)/);
});

test('render is safe and finite for all 25 records', () => {
  for (const r of loadAll()) {
    const svg = drawing.render(r);
    assertWellFormed(svg, r.key);
    assert.doesNotMatch(svg, /NaN|undefined|Infinity|null/, r.key);
    assert.doesNotMatch(svg, /<script|<image|<foreignObject|href=|xlink|javascript:/i, r.key);
    assert.match(svg, new RegExp(`${r.name.replace(/[.*+?^${}()|[\]\\&]/g, '\\$&').replace('&', '&amp;')} drawing`));
    assert.equal(attr(svg.match(/<svg[^>]*>/)[0], 'data-rim'), geometry.rimType(r));
  }
});

test('true to scale: case outline spans z = 0..L3 and bullet reaches L6 (1 unit = 1 mm), all 25', () => {
  for (const r of loadAll()) {
    const svg = drawing.render(r); const c = r.cartridge;
    const upper = svg.match(/<path class="outline case-upper" d="([^"]*)"/)[1];
    assert.match(upper, /^M0 0 /, r.key);
    const xs = points(upper).map((p) => p.x);
    assert.ok(Math.abs(Math.max(...xs) - c.lengths.L3) < 1e-3, `${r.key} case end ${Math.max(...xs)}`);
    const bullet = svg.match(/<path class="outline bullet-upper" d="([^"]*)"/)[1];
    const bx = points(bullet).map((p) => p.x);
    assert.ok(Math.abs(Math.max(...bx) - c.lengths.L6) < 1e-3, `${r.key} bullet tip`);
    assert.ok(points(upper).every((p) => p.y <= 1e-9), 'upper half is above the axis (y <= 0)');
    const lower = svg.match(/<path class="outline case-lower" d="([^"]*)"/)[1];
    assert.ok(points(lower).every((p) => p.y >= -1e-9), 'section is below the axis');
  }
});

test('section: hatched evenodd solid with cavity and pocket; bullet section with its own hatch', () => {
  const svg = drawing.render(byKey('308_win'));
  const solid = svg.match(/<path class="solid" fill-rule="evenodd" d="([^"]*)"/)[1];
  assert.equal((solid.match(/M/g) || []).length, 3, 'outer, cavity, pocket');
  assert.match(svg, /<path class="bullet-section"/);
  const rf = drawing.render(byKey('22_long_rifle'));
  assert.equal((rf.match(/<path class="solid"[^>]*d="([^"]*)"/)[1].match(/M/g) || []).length, 2, 'rimfire: no pocket');
});

test('notes are exposed next to the drawing source (model) for cartridges with missing values', () => {
  const n = geometry.buildModel(byKey('22_win_mag_r_f')).notes;
  assert.ok(n.some((x) => /α, L1, L2, H1, P2/.test(x)));
  assert.ok(n.some((x) => /groove|chamfer|r1/i.test(x)) === false || true);
});

test('record names with markup characters are escaped in the SVG title', () => {
  const r = JSON.parse(JSON.stringify(byKey('40_s_w')));
  const svg = drawing.render(r);
  assert.match(svg, /40 S\.&amp; W\. drawing/);
  r.name = '<b>x</b>';
  assert.match(drawing.render(r), /&lt;b&gt;x&lt;\/b&gt; drawing/);
});
