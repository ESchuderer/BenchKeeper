'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const format = require('../../js/format.js');

test('numbers are shown as published: decimal point, no separators, no .0 on whole numbers', () => {
  assert.equal(format.number(51.18), '51.18');
  assert.equal(format.number(4150), '4150');
  assert.equal(format.number(1825.0), '1825');
  assert.equal(format.number(0.1), '0.1');
  assert.equal(format.number(-0.2), '-0.2');
  assert.equal(format.number(305), '305');
});

test('escapeHtml escapes markup characters', () => {
  assert.equal(format.escapeHtml('40 S.& W.'), '40 S.&amp; W.');
  assert.equal(format.escapeHtml('<a "b">'), '&lt;a &quot;b&quot;&gt;');
});
