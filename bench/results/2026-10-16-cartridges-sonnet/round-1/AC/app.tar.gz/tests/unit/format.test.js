'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll, byKey } = require('./helpers');
const format = require('../../js/format.js');

test('angles: number of degrees and degrees/minutes/seconds', () => {
  assert.equal(format.angle(40), '40°');
  assert.equal(format.angle(3.0), '3°');
  assert.equal(format.angle(0), '0°');
  assert.equal(format.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.angle({ degrees: 50, minutes: 35, seconds: 2 }), '50°35\'2"');
  assert.equal(format.angle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
  assert.equal(format.angle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
});

test('degrees() converts to decimal degrees', () => {
  assert.equal(format.degrees(40), 40);
  assert.ok(Math.abs(format.degrees({ degrees: 39, minutes: 30, seconds: 36 }) - 39.51) < 1e-9);
});

test('isAngleKey covers alpha, alpha1, beta, delta, i', () => {
  for (const k of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.ok(format.isAngleKey(k), k);
  for (const k of ['L3', 'deltaL', 'R1', 'h', 'G']) assert.ok(!format.isAngleKey(k), k);
});

test('symbols: field name except the named ones', () => {
  const m = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G' };
  for (const [k, v] of Object.entries(m)) assert.equal(format.symbol(k), v, k);
  for (const k of ['L3', 'R1', 'Pmax', 'P2', 'G1', 'N', 'Q', 'u', 'i']) assert.equal(format.symbol(k), k);
});

test('units: mm default, bar, J, g, mm², none for N and angles', () => {
  const m = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '', alpha: '', alpha1: '', beta: '', delta: '', i: '', L3: 'mm', R1: 'mm', u: 'mm', deltaL: 'mm', L3PlusG: 'mm', Fe: 'mm', S: 'mm', eMin: 'mm', r1Min: 'mm', G: 'mm', h: 'mm', s: 'mm', b: 'mm', F: 'mm', Z: 'mm' };
  for (const [k, v] of Object.entries(m)) assert.equal(format.unit(k), v, k);
});

test('tolerance is shown next to the value and never as a row', () => {
  const r = byKey('308_win');
  assert.equal(format.valueText(r.cartridge.lengths, 'L1'), '39.62 -0.2');
  assert.equal(format.valueText(r.cartridge.lengths, 'L3'), '51.18');
  const rows = format.sectionRows(r.cartridge.lengths);
  assert.deepEqual(rows.map((x) => x.symbol), ['L1', 'L2', 'L3', 'L6']);
  assert.deepEqual(rows[0], { field: 'L1', symbol: 'L1', value: '39.62 -0.2', unit: 'mm' });
  assert.equal(format.valueText(r.cartridge.junctionCone, 'alpha'), '40°');
  assert.equal(format.valueText(byKey('9_3_x_62').cartridge.caseHead, 'delta'), '41°37\'48"');
});

test('rows of one section: pressures with units', () => {
  const rows = format.sectionRows(byKey('308_win').cartridge.pressures);
  const by = Object.fromEntries(rows.map((x) => [x.symbol, x]));
  for (const [k, v, u] of [['Pmax', '4150', 'bar'], ['EE', '3920', 'J'], ['M', '25', 'g']]) {
    assert.deepEqual([by[k].symbol, by[k].value, by[k].unit], [k, v, u]);
  }
});

test('section definitions and order', () => {
  assert.deepEqual(format.CARTRIDGE_SECTIONS.map((s) => s.key), ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile']);
  assert.deepEqual(format.CHAMBER_SECTIONS.map((s) => s.key), ['barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling']);
  const sec = format.sections(byKey('9_mm_luger').cartridge, format.CARTRIDGE_SECTIONS);
  assert.ok(!sec.some((s) => s.title === 'Junction cone'), 'empty section omitted');
  assert.deepEqual(sec.map((s) => s.title), ['Case head', 'Collar', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile']);
  const full = format.sections(byKey('308_win').cartridge, format.CARTRIDGE_SECTIONS);
  assert.equal(full.find((s) => s.title === 'Junction cone').rows.length, 4);
});

test('for all 25 records every non-Tol field appears exactly once, in a section, and no Tol row exists', () => {
  for (const r of loadAll()) {
    for (const [group, defs] of [[r.cartridge, format.CARTRIDGE_SECTIONS], [r.chamber, format.CHAMBER_SECTIONS]]) {
      const secs = format.sections(group, defs);
      const expected = defs.flatMap((d) => Object.keys(group[d.key] || {}).filter((k) => !/Tol$/.test(k)).map((k) => d.key + '.' + k));
      const got = secs.flatMap((s) => s.rows.map((x) => s.key + '.' + x.field));
      assert.deepEqual(got, expected, r.key);
      for (const s of secs) for (const row of s.rows) assert.doesNotMatch(row.symbol, /Tol/);
      // all sections of the group are known
      assert.deepEqual(Object.keys(group).filter((k) => !defs.some((d) => d.key === k)), [], r.key);
    }
  }
});

test('a tolerance key without its base value is not hidden', () => {
  const rows = format.sectionRows({ L1: 5, L1Tol: -0.1, L3Tol: -0.25 });
  assert.deepEqual(rows.map((r) => r.symbol), ['L1', 'L3Tol']);
  assert.equal(rows[0].value, '5 -0.1');
  assert.equal(rows[1].value, '-0.25');
});
