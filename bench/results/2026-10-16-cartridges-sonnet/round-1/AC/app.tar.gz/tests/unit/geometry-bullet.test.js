'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll, byKey } = require('./helpers');
const geometry = require('../../js/geometry.js');

const near = (a, b, m, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${m || ''} ${a} !== ${b}`);
const clone = (o) => JSON.parse(JSON.stringify(o));

// Rule 7 table, written out independently of the implementation.
const S = (shape, cat) => ({ pointy: 1.0, semi_wadcutter: 0.6, rounded: cat === 'pistol' ? 0.4 : 0.8, flat: cat === 'pistol' ? 0.4 : 0.8 })[shape];
const K = (shape, cat) => ({ pointy: 0.40, semi_wadcutter: 0.78, rounded: cat === 'pistol' ? 0.65 : 0.55, flat: cat === 'pistol' ? 0.70 : 0.60 })[shape];
const M = (shape, G1) => ({ pointy: Math.max(0.08 * G1, 1.27), rounded: 0.15 * G1, flat: 0.55 * G1, semi_wadcutter: 0.6 * G1 })[shape];

test('seating depth, cylinder fraction and meplat per shape and category (rule 7)', () => {
  for (const shape of ['pointy', 'rounded', 'flat', 'semi_wadcutter']) {
    for (const category of ['rifle', 'rimfire', 'pistol']) {
      const r = clone(byKey('308_win'));
      r.annotations.defaultBulletShape = shape; r.annotations.category = category;
      const G1 = r.cartridge.projectile.G1; const L3 = r.cartridge.lengths.L3; const L6 = r.cartridge.lengths.L6;
      const b = geometry.buildModel(r).bullet;
      const s = S(shape, category) * G1;
      near(b.s, s, `${shape}/${category} s`);
      near(b.zb, L3 - s, 'zb');
      near(b.lb, L6 - (L3 - s), 'Lb');
      near(b.zc, b.zb + K(shape, category) * b.lb, 'cylinder end');
      near(b.k, K(shape, category), 'k');
      near(b.m, M(shape, G1), `${shape} m`);
      near(b.n, L6 - b.zc, 'nose length');
    }
  }
});

test('pointy: tangent ogive arc of radius ρ centred on the nose-start radial line', () => {
  const r = byKey('308_win'); const G1 = r.cartridge.projectile.G1;
  const b = geometry.buildModel(r).bullet;
  const m = Math.max(0.08 * G1, 1.27); const d = G1 / 2 - m / 2;
  const rho = (d * d + b.n * b.n) / (2 * d);
  near(b.rho, rho, 'rho');
  const arc = b.cmds.find((c) => c.c === 'A');
  near(arc.rx, rho); near(arc.ry, rho);
  near(arc.z, r.cartridge.lengths.L6); near(arc.r, m / 2);
  assert.equal(arc.sweep, 1);
  // centre (z_c, G1/2 - rho): start and end are both at distance rho
  const centre = { z: b.zc, r: G1 / 2 - rho };
  near(Math.hypot(arc.z - centre.z, arc.r - centre.r), rho, 'end on circle', 1e-9);
  near(Math.hypot(0, G1 / 2 - centre.r), rho, 'start on circle');
  // tangent to the cylinder at the start: centre is directly below the start point
  near(centre.z, b.zc);
});

test('rounded: quarter ellipse; flat and semi_wadcutter: straight cone; flat tip face to the axis', () => {
  const rd = clone(byKey('9_mm_luger')); const b = geometry.buildModel(rd).bullet;
  assert.equal(b.shape, 'rounded');
  const arc = b.cmds.find((c) => c.c === 'A');
  const G1 = rd.cartridge.projectile.G1;
  near(arc.rx, b.n); near(arc.ry, G1 / 2 - 0.15 * G1 / 2); near(arc.z, rd.cartridge.lengths.L6); near(arc.r, 0.15 * G1 / 2);
  for (const key of ['40_s_w', '357_magnum']) {
    const r = byKey(key); const bb = geometry.buildModel(r).bullet;
    assert.ok(!bb.cmds.some((c) => c.c === 'A'), key);
    const G = r.cartridge.projectile.G1;
    const expM = key === '40_s_w' ? 0.55 * G : 0.6 * G;
    const tip = bb.cmds[bb.cmds.length - 2];
    near(tip.z, r.cartridge.lengths.L6); near(tip.r, expM / 2);
    const end = bb.cmds[bb.cmds.length - 1];
    near(end.z, r.cartridge.lengths.L6); near(end.r, 0);
  }
});

test('heeled case (22 Long Rifle): exposed bullet has the case outside diameter, heel the inside diameter', () => {
  const r = byKey('22_long_rifle'); const c = r.cartridge;
  const m = geometry.buildModel(r);
  assert.equal(m.heeled, true);
  const heelR = (c.collar.H2 - 2 * m.walls.tb) / 2;
  const L3 = c.lengths.L3;
  const atMouth = m.bullet.cmds.filter((x) => Math.abs(x.z - L3) < 1e-9);
  assert.ok(atMouth.some((x) => Math.abs(x.r - heelR) < 1e-9), 'heel radius at the mouth');
  assert.ok(atMouth.some((x) => Math.abs(x.r - c.collar.H2 / 2) < 1e-9), 'exposed radius at the mouth');
  assert.ok(m.bullet.cmds.some((x) => Math.abs(x.z - m.bullet.zb) < 1e-9 && Math.abs(x.r - heelR) < 1e-9), 'heel at the base');
  assert.equal(geometry.buildModel(byKey('22_win_mag_r_f')).heeled, false);
  assert.equal(geometry.buildModel(byKey('308_win')).heeled, false);
  const r2 = clone(byKey('308_win')); r2.cartridge.projectile.G1 = r2.cartridge.collar.H2 - 0.0149;
  assert.equal(geometry.buildModel(r2).heeled, true, 'H2 - G1 <= 0.015');
  r2.cartridge.projectile.G1 = r2.cartridge.collar.H2 - 0.0151;
  assert.equal(geometry.buildModel(r2).heeled, false);
});

test('for all 25: bullet starts at its base on the axis, ends at L6 on the axis, exposed cylinder is non-empty', () => {
  for (const r of loadAll()) {
    const m = geometry.buildModel(r); const b = m.bullet; const c = r.cartridge;
    assert.deepEqual([b.cmds[0].c, b.cmds[0].z, b.cmds[0].r], ['M', b.zb, 0], r.key);
    const last = b.cmds[b.cmds.length - 1];
    near(last.z, c.lengths.L6, r.key); near(last.r, 0, r.key);
    assert.ok(b.zc > c.lengths.L3, `${r.key}: exposed cylinder`);
    assert.ok(b.zb < c.lengths.L3);
    assert.equal(b.shape, r.annotations.defaultBulletShape);
    for (const x of b.cmds) assert.ok(Number.isFinite(x.z) && Number.isFinite(x.r), r.key);
  }
});

test('bullet is skipped with a note when G1 or L6 is missing', () => {
  const r = clone(byKey('308_win')); delete r.cartridge.projectile.G1;
  const m = geometry.buildModel(r);
  assert.equal(m.bullet, null);
  assert.ok(m.notes.some((n) => /bullet/i.test(n) && /G1/.test(n)), m.notes.join('|'));
});
