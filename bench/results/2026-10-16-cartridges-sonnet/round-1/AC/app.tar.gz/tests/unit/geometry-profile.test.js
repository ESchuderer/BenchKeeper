'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll, byKey } = require('./helpers');
const geometry = require('../../js/geometry.js');
const format = require('../../js/format.js');

const near = (a, b, m) => assert.ok(Math.abs(a - b) < 1e-9, `${m || ''} ${a} !== ${b}`);
const pt = (z, r) => ({ z, r });
function assertSkeleton(actual, expected, label) {
  assert.equal(actual.length, expected.length, `${label}: point count ${JSON.stringify(actual)}`);
  expected.forEach((e, i) => { near(actual[i].z, e.z, `${label} z[${i}]`); near(actual[i].r, e.r, `${label} r[${i}]`); });
}
const tan = (deg) => Math.tan(deg * Math.PI / 180);

test('308 Win.: chamfer, rim, groove, body, shoulder, neck (rules 2-6)', () => {
  const r = byKey('308_win'); const c = r.cartridge;
  const h = c.caseHead; const P1 = c.powderChamber.P1; const P2 = c.powderChamber.P2;
  const m = geometry.buildModel(r);
  assert.equal(m.rimType, 'rimless');
  assert.equal(m.straight, false);
  const chamferR = h.R1 / 2 - Math.min(h.f * tan(h.beta), h.R1 / 4);
  assertSkeleton(m.skeleton, [
    pt(0, 0), pt(0, chamferR), pt(h.f, h.R1 / 2), pt(h.R, h.R1 / 2),
    pt(h.R, h.E1 / 2), pt(h.R + h.eMin, h.E1 / 2), pt(h.E, P1 / 2),
    pt(c.lengths.L1, P2 / 2), pt(c.lengths.L2, c.collar.H1 / 2), pt(c.lengths.L3, c.collar.H2 / 2)
  ], '308');
  // outer profile starts on the axis at the head face and ends at the mouth corner
  assert.deepEqual([m.outer[0].c, m.outer[0].z, m.outer[0].r], ['M', 0, 0]);
  const last = m.outer[m.outer.length - 1];
  near(last.z, c.lengths.L3); near(last.r, c.collar.H2 / 2);
  assert.equal(m.zStart, h.E);
  assert.deepEqual(m.notes.filter((n) => /groove|chamfer/i.test(n)), []);
});

test('chamfer: radial extent is capped at R1/4 and absent without beta or f', () => {
  const r = JSON.parse(JSON.stringify(byKey('308_win')));
  r.cartridge.caseHead.f = 5; // f·tanβ = 3.5 > R1/4 = 3.0025
  const m = geometry.buildModel(r);
  near(m.skeleton[1].r, r.cartridge.caseHead.R1 / 2 - r.cartridge.caseHead.R1 / 4);
  delete r.cartridge.caseHead.beta;
  const m2 = geometry.buildModel(r);
  const h2 = r.cartridge.caseHead;
  assertSkeleton(m2.skeleton.slice(0, 3), [pt(0, 0), pt(0, h2.R1 / 2), pt(h2.R, h2.R1 / 2)], 'square corner');
  assert.ok(m2.notes.some((n) => /chamfer/i.test(n) && /β/.test(n)), 'note names beta');
  const r3 = JSON.parse(JSON.stringify(byKey('308_win')));
  r3.cartridge.caseHead.beta = 90;
  assert.equal(geometry.buildModel(r3).skeleton[1].r, r3.cartridge.caseHead.R1 / 2, 'beta >= 90 -> square corner');
});

test('rimfire: half-round rim edge with outermost point at R1/2', () => {
  const r = byKey('22_long_rifle'); const h = r.cartridge.caseHead; const P1 = r.cartridge.powderChamber.P1;
  const rho = Math.min(h.R / 2, (h.R1 - P1) / 2);
  const m = geometry.buildModel(r);
  assert.equal(m.rimType, 'rimfire');
  assertSkeleton(m.skeleton.slice(0, 5), [pt(0, 0), pt(0, h.R1 / 2 - rho), pt(rho, h.R1 / 2), pt(2 * rho, h.R1 / 2 - rho), pt(h.R, P1 / 2)], '22LR rim');
  const arcs = m.outer.filter((c) => c.c === 'A');
  assert.equal(arcs.length, 2);
  for (const a of arcs) { near(a.rx, rho); near(a.ry, rho); assert.equal(a.sweep, 1); }
  assert.equal(Math.max(...m.skeleton.map((p) => p.r)), h.R1 / 2);
  assert.ok(!m.notes.some((n) => /chamfer|groove/i.test(n)), 'rimfire has neither chamfer nor groove notes: ' + m.notes.join('|'));
});

test('rimfire half-round radius is limited by (R1-P1)/2', () => {
  const r = JSON.parse(JSON.stringify(byKey('22_long_rifle')));
  r.cartridge.caseHead.R1 = 6.0; // (6.0-5.74)/2 = 0.13 < R/2
  const m = geometry.buildModel(r);
  near(m.outer.find((c) => c.c === 'A').rx, 0.13);
});

test('belted 300 Win. Mag.: ramp at delta to the belt, belt to E, step in to P1/2', () => {
  const r = byKey('300_win_mag'); const h = r.cartridge.caseHead; const P1 = r.cartridge.powderChamber.P1;
  const m = geometry.buildModel(r);
  assert.equal(m.rimType, 'belted');
  const floorEnd = h.R + h.eMin;
  const zr = floorEnd + (h.R3 / 2 - h.E1 / 2) / tan(h.delta);
  assertSkeleton(m.skeleton.slice(0, 10), [
    pt(0, 0), pt(0, h.R1 / 2 - Math.min(h.f * tan(h.beta), h.R1 / 4)), pt(h.f, h.R1 / 2), pt(h.R, h.R1 / 2),
    pt(h.R, h.E1 / 2), pt(floorEnd, h.E1 / 2), pt(zr, h.R3 / 2), pt(h.E, h.R3 / 2), pt(h.E, P1 / 2),
    pt(r.cartridge.lengths.L1, r.cartridge.powderChamber.P2 / 2)
  ], 'belted');
  near(m.walls.rampEnd, zr);
});

test('belted without R3 or delta: ordinary groove and a note naming the missing value', () => {
  const r = JSON.parse(JSON.stringify(byKey('300_win_mag')));
  delete r.cartridge.caseHead.R3;
  const m = geometry.buildModel(r);
  assert.ok(m.notes.some((n) => /belt/i.test(n) && /R3/.test(n)), m.notes.join('|'));
  assert.equal(m.walls.rampEnd, null);
});

test('no groove (rimmed cases): step in from (R1/2, R) to (P1/2, R) and note naming E, E1, e min', () => {
  for (const key of ['7_x_65_r', '9_3_x_74_r', '38_special', '357_magnum', '44_rem_mag']) {
    const r = byKey(key); const h = r.cartridge.caseHead; const P1 = r.cartridge.powderChamber.P1;
    const m = geometry.buildModel(r);
    const i = m.skeleton.findIndex((p) => p.z === h.R && p.r === h.R1 / 2);
    assert.ok(i > 0, key);
    near(m.skeleton[i + 1].z, h.R); near(m.skeleton[i + 1].r, P1 / 2);
    assert.equal(m.zStart, h.R);
    assert.ok(m.notes.some((n) => /groove/i.test(n) && /E, E1, e min/.test(n)), key + ' ' + m.notes.join('|'));
  }
});

test('bottleneck: body, shoulder and neck pass through the published points for every bottleneck record', () => {
  let n = 0;
  for (const r of loadAll()) {
    const c = r.cartridge;
    const bottle = ['alpha', 'L1', 'L2', 'H1', 'P2'].every((k) => ((c.junctionCone || {})[k] ?? c.lengths[k] ?? c.collar[k] ?? c.powderChamber[k]) !== undefined);
    const m = geometry.buildModel(r);
    assert.equal(m.straight, !bottle, r.key);
    if (!bottle) continue;
    n++;
    const sk = m.skeleton.slice(-4);
    assertSkeleton(sk, [
      pt(m.zStart, c.powderChamber.P1 / 2), pt(c.lengths.L1, c.powderChamber.P2 / 2),
      pt(c.lengths.L2, c.collar.H1 / 2), pt(c.lengths.L3, c.collar.H2 / 2)
    ], r.key);
  }
  assert.equal(n, 17);
});

test('straight cases run from P1/2 to (H2/2, L3) and the note lists exactly the missing values', () => {
  for (const key of ['9_mm_luger', '45_auto', '40_s_w', '38_special', '357_magnum', '44_rem_mag', '22_long_rifle', '22_win_mag_r_f']) {
    const r = byKey(key); const c = r.cartridge;
    const m = geometry.buildModel(r);
    assert.equal(m.straight, true, key);
    assertSkeleton(m.skeleton.slice(-2), [pt(m.zStart, c.powderChamber.P1 / 2), pt(c.lengths.L3, c.collar.H2 / 2)], key);
    const note = m.notes.find((x) => /straight case/i.test(x));
    assert.ok(note, key);
    assert.match(note, /^Drawn as a straight case: α, L1, L2, H1, P2 not published\.$/, key);
  }
  const wm = geometry.buildModel(byKey('17_hmr'));
  assert.equal(wm.straight, false);
});

test('fillets at the shoulder: radius r1 min (body side) and r2 (neck side), tangent to both lines', () => {
  for (const key of ['223_rem', '308_win', '6_5_x_55_se', '7_62_x_39']) {
    const r = byKey(key); const c = r.cartridge;
    const m = geometry.buildModel(r);
    const arcs = []; let prev = null;
    for (const cmd of m.outer) { if (cmd.c === 'A') arcs.push({ from: prev, cmd }); prev = cmd; }
    const sh = arcs.filter((a) => Math.abs(a.cmd.rx - c.junctionCone.r1Min) < 1e-9 || Math.abs(a.cmd.rx - c.junctionCone.r2) < 1e-9);
    assert.equal(sh.length, 2, key + ' ' + JSON.stringify(arcs.map((a) => a.cmd.rx)));
    const body = sh.find((a) => Math.abs(a.cmd.rx - c.junctionCone.r1Min) < 1e-9);
    // tangent lengths from the corner (L1, P2/2): equal on both sides, = r·tan(θ/2)
    const corner = pt(c.lengths.L1, c.powderChamber.P2 / 2);
    const d1 = Math.hypot(body.from.z - corner.z, body.from.r - corner.r);
    const d2 = Math.hypot(body.cmd.z - corner.z, body.cmd.r - corner.r);
    near(d1, d2, key + ' tangent lengths');
    assert.ok(d1 > 0 && d1 < 0.5 * Math.hypot(c.lengths.L2 - c.lengths.L1, c.powderChamber.P2 / 2 - c.collar.H1 / 2), key);
    assert.equal(body.cmd.sweep, 1, 'body-side corner turns toward the axis');
    const neck = sh.find((a) => a !== body);
    assert.equal(neck.cmd.sweep, 0, 'neck-side corner turns back to the axis direction');
  }
});

test('fillets are skipped and noted when r1 min / r2 are not published; tangent lengths are clamped', () => {
  const m = geometry.buildModel(byKey('338_lapua_mag'));
  assert.ok(m.notes.some((n) => /r1 min/.test(n) && /body/i.test(n)), m.notes.join('|'));
  assert.ok(!m.notes.some((n) => /r2/.test(n)), 'r2 is published');
  const h = geometry.buildModel(byKey('17_hmr'));
  assert.ok(h.notes.some((n) => /r1 min/.test(n)) && h.notes.some((n) => /r2/.test(n)));
  assert.equal(h.outer.filter((c) => c.c === 'A').length, 2, 'only the two half-round rim arcs');
  const big = JSON.parse(JSON.stringify(byKey('308_win')));
  big.cartridge.junctionCone.r1Min = 50; big.cartridge.junctionCone.r2 = 50;
  const mb = geometry.buildModel(big);
  const arcs = mb.outer.filter((c) => c.c === 'A');
  assert.ok(arcs.length >= 2);
  const shoulder = Math.hypot(big.cartridge.lengths.L2 - big.cartridge.lengths.L1, big.cartridge.powderChamber.P2 / 2 - big.cartridge.collar.H1 / 2);
  assert.ok(arcs.every((a) => a.rx < 50 && a.rx > 0));
  assert.ok(shoulder > 0);
});

test('outer profile never goes backwards along the axis and has no NaN, for all 25', () => {
  for (const r of loadAll()) {
    const m = geometry.buildModel(r);
    assert.ok(m.outer.length > 5, r.key);
    let z = 0;
    for (const c of m.outer) {
      for (const v of [c.z, c.r]) assert.ok(Number.isFinite(v), r.key);
      assert.ok(c.z >= z - 1e-9, `${r.key} z went back at ${JSON.stringify(c)}`);
      z = c.z;
      assert.ok(c.r >= 0, r.key);
    }
    near(m.outer[m.outer.length - 1].z, r.cartridge.lengths.L3, r.key);
  }
});

test('notes use symbols from the format module', () => {
  assert.equal(format.symbol('eMin'), 'e min');
});
