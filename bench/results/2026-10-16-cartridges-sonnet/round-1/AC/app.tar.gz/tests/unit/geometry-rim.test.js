'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll } = require('./helpers');
const geometry = require('../../js/geometry.js');

function expected(r) {
  if (r.family === 'belted') return 'belted';
  if (r.family === 'rimfire') return 'rimfire';
  const ratio = r.cartridge.caseHead.R1 / r.cartridge.powderChamber.P1;
  if (ratio >= 1.05) return 'rimmed';
  if (ratio < 0.98) return 'rebated';
  return 'rimless';
}

test('rim type of all 25 records follows rule 1', () => {
  for (const r of loadAll()) assert.equal(geometry.rimType(r), expected(r), r.key);
});

test('rim type: known examples', () => {
  const t = Object.fromEntries(loadAll().map((r) => [r.key, geometry.rimType(r)]));
  for (const k of ['9_3_x_74_r', '7_x_65_r', '38_special', '357_magnum', '44_rem_mag']) assert.equal(t[k], 'rimmed', k);
  for (const k of ['300_win_mag', '7_mm_rem_mag']) assert.equal(t[k], 'belted', k);
  for (const k of ['22_long_rifle', '22_win_mag_r_f', '17_hmr']) assert.equal(t[k], 'rimfire', k);
  assert.equal(t['308_win'], 'rimless');
  assert.equal(t['9_mm_luger'], 'rimless');
});

test('rim type thresholds with synthetic records', () => {
  const mk = (R1, P1, family = 'rimless') => ({ family, cartridge: { caseHead: { R1 }, powderChamber: { P1 } } });
  assert.equal(geometry.rimType(mk(21, 20)), 'rimmed');
  assert.equal(geometry.rimType(mk(20.99, 20)), 'rimless');
  assert.equal(geometry.rimType(mk(19.6, 20)), 'rimless');
  assert.equal(geometry.rimType(mk(19.59, 20)), 'rebated');
  assert.equal(geometry.rimType(mk(30, 20, 'belted')), 'belted');
  assert.equal(geometry.rimType(mk(30, 20, 'rimfire')), 'rimfire');
});
