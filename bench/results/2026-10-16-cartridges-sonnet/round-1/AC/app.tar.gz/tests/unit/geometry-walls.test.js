'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll, byKey } = require('./helpers');
const geometry = require('../../js/geometry.js');

const near = (a, b, m, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${m || ''} ${a} !== ${b}`);
const clone = (o) => JSON.parse(JSON.stringify(o));

test('pocket table (rule 8)', () => {
  const t = (p) => geometry.primerPocket(p);
  for (const p of ['sp', 'spm', 'sr']) assert.equal(t(p).d, 4.45, p);
  for (const p of ['lp', 'lpm', 'lr', 'lrm']) assert.equal(t(p).d, 5.33, p);
  for (const p of ['sp', 'spm', 'sr', 'lp', 'lpm']) assert.equal(t(p).depth, 3.04, p);
  for (const p of ['lr', 'lrm']) assert.equal(t(p).depth, 3.3, p);
  assert.equal(t('rimfire'), null);
  assert.equal(t('xyz'), null);
});

test('wall thicknesses tn and tb (rule 8)', () => {
  const r = byKey('308_win'); const c = r.cartridge;
  const w = geometry.buildModel(r).walls;
  const tn = (c.collar.H2 - c.projectile.G1) / 2;
  near(w.tn, tn);
  near(w.tb, Math.min(Math.max(1.3 * tn, 0.6), 0.35 * c.powderChamber.P1 / 2));
  assert.equal(w.tb, 0.6);
  // 1.3*tn dominating
  const r2 = clone(r); r2.cartridge.projectile.G1 = 7.0;
  const tn2 = (8.72 - 7.0) / 2;
  near(geometry.buildModel(r2).walls.tb, Math.min(Math.max(1.3 * tn2, 0.6), 0.35 * 11.96 / 2));
  assert.ok(1.3 * tn2 > 0.6);
  // 0.35*P1/2 binding
  const r3 = clone(r); r3.cartridge.powderChamber.P1 = 2;
  near(geometry.buildModel(r3).walls.tb, 0.35);
});

test('solid head length w: max of 2.5, 0.25*P1/2, pocket depth + 1.5, groove and belt terms', () => {
  const r = byKey('308_win'); const c = r.cartridge;
  const w = geometry.buildModel(r).walls;
  near(w.w, Math.max(2.5, 0.25 * c.powderChamber.P1 / 2, 3.3 + 1.5, c.caseHead.E + w.tb));
  assert.equal(w.w, 4.8);
  assert.deepEqual(w.pocket, { d: 5.33, depth: 3.3 });
  // groove term dominating: raise E
  const r2 = clone(r); r2.cartridge.caseHead.E = 5.0;
  near(geometry.buildModel(r2).walls.w, 5.0 + 0.6);
  // small pistol primer
  const p = geometry.buildModel(byKey('9_mm_luger')).walls;
  assert.deepEqual(p.pocket, { d: 4.45, depth: 3.04 });
  near(p.w, Math.max(2.5, 0.25 * 9.93 / 2, 3.04 + 1.5, 2.98 + p.tb));
  // belted: ramp end + tb
  const b = geometry.buildModel(byKey('300_win_mag')).walls;
  near(b.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, b.rampEnd + b.tb));
  // rimfire: no pocket, w = 2.5
  const rf = geometry.buildModel(byKey('22_long_rifle')).walls;
  assert.equal(rf.pocket, null);
  assert.equal(rf.w, 2.5);
  // rimmed without groove: pocket depth + 1.5
  near(geometry.buildModel(byKey('7_x_65_r')).walls.w, 4.8);
});

test('inner line: body wall tb, linear blend over the shoulder, neck wall tn', () => {
  for (const key of ['308_win', '223_rem', '6_5_x_55_se', '338_lapua_mag', '17_hmr', '9_3_x_74_r']) {
    const r = byKey(key); const c = r.cartridge;
    const m = geometry.buildModel(r); const { tb, tn, w } = m.walls;
    const P2 = c.powderChamber.P2; const H1 = c.collar.H1; const H2 = c.collar.H2;
    const ri = (z) => geometry.innerRadiusAt(m, z);
    near(ri(c.lengths.L1), P2 / 2 - tb, key + ' L1');
    near(ri(c.lengths.L2), H1 / 2 - tn, key + ' L2');
    near(ri(c.lengths.L3), H2 / 2 - tn, key + ' L3');
    const mid = (c.lengths.L1 + c.lengths.L2) / 2;
    near(ri(mid), ((P2 / 2 - tb) + (H1 / 2 - tn)) / 2, key + ' mid shoulder');
    // body: follows the taper from P1/2 to P2/2 at distance tb
    const z0 = Math.max(w, m.zStart);
    const body = (z) => c.powderChamber.P1 / 2 + (P2 / 2 - c.powderChamber.P1 / 2) * (z - m.zStart) / (c.lengths.L1 - m.zStart);
    near(ri(z0), body(z0) - tb, key + ' body at w');
    near(ri((z0 + c.lengths.L1) / 2), body((z0 + c.lengths.L1) / 2) - tb, key + ' body mid');
    near(ri(w), body(w) - tb, key + ' at w');
  }
});

test('non-heeled: the cavity at the mouth has the bullet radius G1/2', () => {
  for (const r of loadAll()) {
    const m = geometry.buildModel(r);
    if (m.heeled) continue;
    near(geometry.innerRadiusAt(m, r.cartridge.lengths.L3), r.cartridge.projectile.G1 / 2, r.key);
  }
});

test('straight case: tb up to one seating depth before the bullet base, taper to tn at the base, tn to the mouth', () => {
  const r = byKey('9_mm_luger'); const c = r.cartridge;
  const m = geometry.buildModel(r); const { tb, tn } = m.walls;
  const body = (z) => c.powderChamber.P1 / 2 + (c.collar.H2 / 2 - c.powderChamber.P1 / 2) * (z - m.zStart) / (c.lengths.L3 - m.zStart);
  const { zb, s } = m.bullet;
  near(geometry.innerRadiusAt(m, zb - s), body(zb - s) - tb, 'before taper');
  near(geometry.innerRadiusAt(m, zb), body(zb) - tn, 'at base');
  near(geometry.innerRadiusAt(m, c.lengths.L3), c.collar.H2 / 2 - tn, 'mouth');
  const h = geometry.buildModel(byKey('22_long_rifle'));
  const hz = h.bullet.zb;
  near(geometry.innerRadiusAt(h, hz), geometry.outerRadiusAt(h, hz) - h.walls.tb, 'heeled keeps tb');
});

test('inner radius is smaller than the outer radius from w to the mouth, for all 25', () => {
  for (const r of loadAll()) {
    const m = geometry.buildModel(r);
    const L3 = r.cartridge.lengths.L3;
    for (let i = 0; i <= 50; i++) {
      const z = m.walls.w + (L3 - m.walls.w) * i / 50;
      const ro = geometry.outerRadiusAt(m, z); const ri = geometry.innerRadiusAt(m, z);
      assert.ok(ri > 0, `${r.key} z=${z}`);
      assert.ok(ri < ro + 1e-9, `${r.key} z=${z}: ${ri} < ${ro}`);
    }
  }
});

test('outerRadiusAt follows the outline', () => {
  const r = byKey('308_win'); const c = r.cartridge;
  const m = geometry.buildModel(r);
  near(geometry.outerRadiusAt(m, c.caseHead.R / 2), c.caseHead.R1 / 2, 'rim');
  near(geometry.outerRadiusAt(m, c.caseHead.R + c.caseHead.eMin / 2), c.caseHead.E1 / 2, 'groove floor');
  near(geometry.outerRadiusAt(m, c.lengths.L3), c.collar.H2 / 2, 'mouth');
  near(geometry.outerRadiusAt(m, c.caseHead.E), c.powderChamber.P1 / 2, 'body start');
});
