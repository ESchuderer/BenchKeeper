'use strict';
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..', '..');

function readJsonl() {
  return fs.readFileSync(path.join(root, 'data', 'cartridges.jsonl'), 'utf8')
    .split('\n').filter((l) => l.trim() !== '').map((l) => JSON.parse(l));
}

// Records as the app sees them (generated classic script, loaded like a browser would).
function loadAll() {
  return require(path.join(root, 'js', 'data.js'));
}

function byKey(key) {
  const r = loadAll().find((x) => x.key === key);
  if (!r) throw new Error('no record ' + key);
  return r;
}

module.exports = { root, readJsonl, loadAll, byKey };
