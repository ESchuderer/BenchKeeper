'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll } = require('./helpers');
const search = require('../../js/search.js');

const all = loadAll();
const keys = (list) => list.map((r) => r.key);

test('normalise lower-cases and removes whitespace only', () => {
  assert.equal(search.normalise('7,62 x 51'), '7,62x51');
  assert.equal(search.normalise('  30-06  Spring. '), '30-06spring.');
  assert.equal(search.normalise('40 S.& W.'), '40s.&w.');
});

test('"7,62 x 51" finds 308 Win. through its alternative name', () => {
  assert.deepEqual(keys(search.filter(all, { text: '7,62 x 51' })), ['308_win']);
  assert.deepEqual(keys(search.filter(all, { text: '7,62x51' })), ['308_win']);
});

test('search matches names and alternative names, ignoring case', () => {
  assert.deepEqual(keys(search.filter(all, { text: '30-06' })), ['30_06_spring']);
  assert.deepEqual(keys(search.filter(all, { text: '22lr' })), ['22_long_rifle']);
  assert.deepEqual(keys(search.filter(all, { text: 'CREEDMOOR' })), ['6_5_creedmoor']);
  assert.deepEqual(keys(search.filter(all, { text: '9 mm para' })), ['9_mm_luger']);
  assert.deepEqual(keys(search.filter(all, { text: '.308 nothing' })), []);
});

test('empty search and family "All" return every record in order', () => {
  assert.deepEqual(keys(search.filter(all, { text: '', family: '' })), keys(all));
  assert.deepEqual(keys(search.filter(all, {})), keys(all));
});

test('family filter counts', () => {
  const expected = { rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 };
  for (const [family, n] of Object.entries(expected)) {
    const got = search.filter(all, { family });
    assert.equal(got.length, n, family);
    assert.ok(got.every((r) => r.family === family));
  }
});

test('text and family combine with AND', () => {
  assert.deepEqual(keys(search.filter(all, { text: '22', family: 'rimfire' })), ['22_long_rifle', '22_win_mag_r_f']);
  assert.deepEqual(keys(search.filter(all, { text: '22', family: 'pistol' })), []);
});

test('count text is "<n> cartridges", also for 1 and 0', () => {
  assert.equal(search.countText(25), '25 cartridges');
  assert.equal(search.countText(1), '1 cartridges');
  assert.equal(search.countText(0), '0 cartridges');
});

test('every cartridge is found by its own name as published', () => {
  for (const r of all) assert.ok(keys(search.filter(all, { text: r.name })).includes(r.key), r.name);
});
