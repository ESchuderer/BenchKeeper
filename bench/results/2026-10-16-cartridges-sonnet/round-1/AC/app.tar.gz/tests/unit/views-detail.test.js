'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { byKey, loadAll } = require('./helpers');
const views = require('../../js/views.js');

const strip = (s) => s.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
const fact = (html, label) => {
  const m = html.match(new RegExp('<dt>' + label + '</dt>\\s*<dd>([\\s\\S]*?)</dd>'));
  return m ? m[1] : null;
};
function tables(html) {
  const out = {};
  const seen = {};
  for (const m of html.matchAll(/<table class="values"[^>]*>\s*<caption>([^<]*)<\/caption>([\s\S]*?)<\/table>/g)) {
    seen[m[1]] = (seen[m[1]] || 0) + 1;
    out[m[1] + '#' + seen[m[1]]] = [...m[2].matchAll(/<tr><th scope="row">([^<]*)<\/th><td[^>]*>([^<]*)<\/td><td[^>]*>([^<]*)<\/td><\/tr>/g)].map((r) => [r[1], r[2], r[3]]);
  }
  return out;
}

test('308 Win. detail: heading, identity facts, capacity with source link', () => {
  const html = views.detailView(byKey('308_win'));
  assert.match(html, /<h1[^>]*>308 Win\.<\/h1>/);
  assert.equal(strip(fact(html, 'Alternative names')), '308 Winchester, 7,62 x 51');
  assert.equal(strip(fact(html, 'Family')), 'rimless');
  assert.equal(strip(fact(html, 'Category')), 'rifle');
  assert.equal(strip(fact(html, 'Primer type')), 'lr');
  assert.equal(strip(fact(html, 'C.I.P. table')), 'I');
  assert.equal(strip(fact(html, 'Country')), 'US');
  assert.equal(strip(fact(html, 'Published')), '1984-06-14');
  assert.equal(strip(fact(html, 'Revised')), '2008-09-23');
  assert.equal(strip(fact(html, 'Pressure method')), 'Transducer');
  const cap = fact(html, 'Water capacity');
  assert.match(strip(cap), /^56 gr H2O/);
  assert.match(cap, /<a href="http:\/\/kwk\.us\/cases\.html"[^>]*>kwk<\/a>/);
  assert.match(strip(cap), /Lapua brass measures 55\.8 \(lapua-308\)/);
});

test('optional facts are omitted when not published', () => {
  const lacking = views.detailView(byKey('7_x_64'));
  assert.equal(fact(lacking, 'Water capacity'), null);
  assert.equal(fact(lacking, 'Alternative names'), null);
  assert.equal(fact(views.detailView(byKey('223_rem')), 'Alternative names'), null);
});

test('tables: captions, Symbol/Value/Unit header, rows as published', () => {
  const html = views.detailView(byKey('308_win'));
  assert.equal([...html.matchAll(/<th scope="col">Symbol<\/th><th scope="col">Value<\/th><th scope="col">Unit<\/th>/g)].length >= 10, true);
  const t = tables(html);
  assert.deepEqual(t['Lengths#1'], [['L1', '39.62 -0.2', 'mm'], ['L2', '43.48 -0.2', 'mm'], ['L3', '51.18', 'mm'], ['L6', '71.12', 'mm']]);
  assert.deepEqual(t['Lengths#2'], [['L1', '39.48', 'mm'], ['L2', '43.28', 'mm'], ['L3', '51.44', 'mm']]);
  assert.ok(t['Pressures#1'].some((r) => r.join('|') === 'Pmax|4150|bar'));
  assert.ok(t['Junction cone#1'].some((r) => r.join('|') === 'α|40°|'));
  assert.ok(t['Grooves#1'].some((r) => r.join('|') === 'N|4|'));
  assert.ok(t['Case head#1'].some((r) => r.join('|') === 'e min|1.4|mm'));
  assert.ok(t['Junction cone#2'].some((r) => r.join('|') === 'r1 max|0.76|mm'));
  assert.doesNotMatch(html, /Tol</);
});

test('section headings Cartridge and Chamber, no empty sections', () => {
  const html = views.detailView(byKey('9_mm_luger'));
  assert.match(html, /<h2[^>]*>Cartridge<\/h2>/);
  assert.match(html, /<h2[^>]*>Chamber<\/h2>/);
  assert.doesNotMatch(html, /<caption>Junction cone<\/caption>/);
});

test('actions, footer and escaping', () => {
  const html = views.detailView(byKey('40_s_w'));
  assert.match(html, /<button type="button" id="print-button">Print<\/button>/);
  assert.match(html, /<a [^>]*href="#\/"[^>]*>All cartridges<\/a>/);
  assert.match(html, /Source: C\.I\.P\. TDCC, revised 2000-06-07/);
  assert.match(html, /<h1[^>]*>40 S\.&amp; W\.<\/h1>/);
});

test('notFoundView names the address and links back', () => {
  const html = views.notFoundView('nope');
  assert.match(html, /nope/);
  assert.match(html, /<a href="#\/">All cartridges<\/a>/);
  assert.match(views.notFoundView('<b>'), /&lt;b&gt;/);
});

test('every record renders a detail view', () => {
  for (const r of loadAll()) {
    const html = views.detailView(r);
    assert.ok(html.includes(r.key) || html.length > 500, r.key);
    assert.doesNotMatch(html, /undefined|NaN/, r.key);
  }
});

test('facts without a value are omitted, never shown as "undefined"', () => {
  const r = JSON.parse(JSON.stringify(byKey('308_win')));
  delete r.annotations.category; delete r.annotations.primerType; delete r.country;
  const html = views.detailView(r);
  assert.doesNotMatch(html, /undefined/);
  assert.equal(fact(html, 'Category'), null);
  assert.equal(fact(html, 'Primer type'), null);
  assert.equal(fact(html, 'Country'), null);
  assert.equal(strip(fact(html, 'Family')), 'rimless');
});

test('an exception while drawing leaves the tables and shows a message', () => {
  const geometry = require('../../js/geometry.js');
  const original = geometry.buildModel;
  geometry.buildModel = () => { throw new Error('boom'); };
  let html;
  try { assert.doesNotThrow(() => { html = views.detailView(byKey('308_win')); }); } finally { geometry.buildModel = original; }
  assert.match(html, /class="drawing-error"[^>]*>The drawing could not be generated\./);
  assert.match(html, /<h1[^>]*>308 Win\.<\/h1>/);
  assert.match(html, /<caption>Lengths<\/caption>/);
});
