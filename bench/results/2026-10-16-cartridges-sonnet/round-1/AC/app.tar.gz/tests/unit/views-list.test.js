'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadAll } = require('./helpers');
const views = require('../../js/views.js');

const all = loadAll();
const html = views.listView(all, { text: '', family: '' });

test('list view has heading, labelled controls and count', () => {
  assert.match(html, /<h1[^>]*>Cartridges<\/h1>/);
  assert.match(html, /<label for="search">Search<\/label>/);
  assert.match(html, /<input[^>]*id="search"[^>]*type="search"|<input[^>]*type="search"[^>]*id="search"/);
  assert.match(html, /<label for="family">Family<\/label>/);
  const opts = [...html.matchAll(/<option value="([^"]*)"[^>]*>([^<]*)<\/option>/g)].map((m) => m[2]);
  assert.deepEqual(opts, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  assert.match(html, /<p id="count" role="status"[^>]*>25 cartridges<\/p>/);
});

test('every cartridge is a link whose text is exactly its name, with family and L3', () => {
  for (const r of all) {
    const esc = r.name.replace(/&/g, '&amp;');
    const re = new RegExp(`<a href="#/cartridge/${r.key}">${esc.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}</a>`);
    assert.match(html, re, r.name);
  }
  const rows = [...html.matchAll(/<tr data-key="([^"]+)">([\s\S]*?)<\/tr>/g)];
  assert.equal(rows.length, 25);
  const luger = rows.find((m) => m[1] === '9_mm_luger')[2];
  assert.match(luger, />pistol</);
  assert.match(luger, />19.15</);
});

test('names are HTML-escaped', () => {
  assert.match(html, />40 S\.&amp; W\.</);
  assert.doesNotMatch(html, />40 S\.& W\.</);
});

test('state filters rows and count; empty result shows message', () => {
  const one = views.listView(all, { text: '7,62 x 51', family: '' });
  assert.match(one, /1 cartridges/);
  assert.equal([...one.matchAll(/<tr data-key=/g)].length, 1);
  assert.match(one, /value="7,62 x 51"/);
  const none = views.listView(all, { text: 'zzz', family: '' });
  assert.match(none, /0 cartridges/);
  assert.match(none, /No cartridge matches\./);
  const rimfire = views.listView(all, { text: '', family: 'rimfire' });
  assert.match(rimfire, /3 cartridges/);
  assert.match(rimfire, /<option value="rimfire" selected>/);
});
