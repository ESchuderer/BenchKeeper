(function () {
  const DATA = window.CARTRIDGES;
  const F = window.CipFormat;
  const D = window.CipDrawing;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const href = (rec) => `#/cartridge/${encodeURIComponent(rec.key)}`;

  // --- list
  $('rows').innerHTML = DATA.map(
    (r) => `<tr><td><a href="${href(r)}">${esc(r.name)}</a></td><td>${esc(r.family)}</td><td class="num">${F.num(r.cartridge.lengths.L3)} mm</td></tr>`
  ).join('');
  const rowEls = [...$('rows').children];

  function filter() {
    const q = $('search').value;
    const fam = $('family').value;
    let n = 0;
    DATA.forEach((r, i) => {
      const show = (fam === 'all' || r.family === fam) && F.matches(r, q);
      rowEls[i].hidden = !show;
      if (show) n++;
    });
    $('count').textContent = `${n} cartridges`;
    $('none').hidden = n > 0;
  }
  $('search').addEventListener('input', filter);
  $('family').addEventListener('change', filter);
  filter();

  // --- detail
  const table = (title, section) => {
    const body = F.rows(section)
      .map((r) => `<tr><th scope="row">${esc(r.symbol)}</th><td class="num">${esc(r.value)}${r.tol ? ` <span class="tol">${esc(r.tol)}</span>` : ''}</td><td class="unit">${esc(r.unit)}</td></tr>`)
      .join('');
    return `<table><caption>${esc(title)}</caption><thead><tr><th>Symbol</th><th class="num">Value</th><th>Unit</th></tr></thead><tbody>${body}</tbody></table>`;
  };
  const group = (title, sections) =>
    `<section class="group"><h2>${esc(title)}</h2><div class="sections">${Object.keys(sections)
      .filter((k) => Object.keys(sections[k]).length)
      .map((k) => table(F.SECTION_TITLES[k] || k, sections[k]))
      .join('')}</div></section>`;

  function showDetail(rec) {
    const g = D.build(rec);
    const cap = rec.annotations.publishedCapacity;
    const meta = [
      ['Alternative names', rec.alternativeNames && rec.alternativeNames.map(esc).join(', ')],
      ['Family', esc(rec.family)],
      ['Category', esc(rec.annotations.category)],
      ['Primer type', esc(rec.annotations.primerType)],
      ['C.I.P. table', esc(rec.tab)],
      ['Country', esc(rec.country)],
      ['Published', esc(rec.published)],
      ['Revised', esc(rec.revised)],
      ['Pressure method', esc(rec.pressureMethod)],
      ['Water capacity', cap && `${F.num(cap.grH2O)} gr H<sub>2</sub>O, <a href="${esc(cap.url)}" target="_blank" rel="noopener noreferrer">${esc(cap.source)}</a>${cap.note ? ` <span class="note">(${esc(cap.note)})</span>` : ''}`],
    ].filter((m) => m[1]);
    $('detail-view').innerHTML =
      `<header class="page-head"><h1 tabindex="-1">${esc(rec.name)}</h1>` +
      `<nav class="toolbar"><a href="#/">All cartridges</a> <button type="button" id="print">Print</button></nav></header>` +
      `<dl class="meta">${meta.map((m) => `<div><dt>${m[0]}</dt><dd>${m[1]}</dd></div>`).join('')}</dl>` +
      `<figure class="drawing-box">${g.svg}${g.notes.length ? `<figcaption class="notes"><strong>Drawing notes:</strong> ${g.notes.map(esc).join(' ')}</figcaption>` : ''}</figure>` +
      group('Cartridge values', rec.cartridge) +
      group('Chamber values', rec.chamber) +
      `<footer>Source: C.I.P. TDCC, revised ${esc(rec.revised)}. Data: OpenBallistics (MIT).</footer>`;
    $('print').addEventListener('click', () => window.print());
    document.title = `${rec.name} – C.I.P. cartridges`;
  }

  // --- routing: the address of a detail view is #/cartridge/<key>
  function route() {
    const m = location.hash.match(/^#\/cartridge\/([^/]+)$/);
    const rec = m && DATA.find((r) => r.key === decodeURIComponent(m[1]));
    const detail = !!m;
    $('list-view').hidden = detail;
    $('detail-view').hidden = !detail;
    if (!detail) {
      document.title = 'C.I.P. cartridges';
    } else if (rec) {
      showDetail(rec);
    } else {
      $('detail-view').innerHTML = '<h1>Cartridge not found</h1><p><a href="#/">All cartridges</a></p>';
    }
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);
  route();
})();
