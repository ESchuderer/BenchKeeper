// Geometry and SVG drawing of a cartridge record. Plain script, also loadable from Node.
// Profile points are [r, z] (radius, distance from the head face) in mm; SVG uses x = z, y = -r (outside view) / +r (section).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'));
  else root.CipDrawing = factory(root.CipFormat);
})(this, function (F) {
  const FS = 2.4; // label font size, user units (mm)
  const CW = 0.62 * FS;
  const TFS = 2; // title block font size // monospace character width, with a little margin
  const ROW_TOP = FS + 1.4;
  const ROW_BOT = 5;
  const ARROW = 1.6;
  const PRINT_W = 190; // mm, A4 portrait with 10 mm margins; keep in sync with style.css
  const PRINT_MAX_H = 105; // mm, keep in sync with style.css
  const POCKET_D = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  const POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  const rad = (d) => (d * Math.PI) / 180;
  const has = (v) => v !== undefined && v !== null;
  const r3 = (v) => Math.round(v * 1000) / 1000;
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    const ratio = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    return ratio >= 1.05 ? 'rimmed' : ratio < 0.98 ? 'rebated' : 'rimless';
  }

  // Arc of radius rho tangent to the legs prev-corner and corner-next, as sampled points; the tangent length is
  // limited to 45 % of each leg so that two fillets never meet.
  function fillet(prev, corner, next, rho) {
    const u = [prev[0] - corner[0], prev[1] - corner[1]];
    const v = [next[0] - corner[0], next[1] - corner[1]];
    const lu = Math.hypot(...u);
    const lv = Math.hypot(...v);
    u[0] /= lu; u[1] /= lu; v[0] /= lv; v[1] /= lv;
    const ang = Math.acos(Math.max(-1, Math.min(1, u[0] * v[0] + u[1] * v[1])));
    if (ang > Math.PI - 1e-6) return [corner];
    const t = Math.min(rho / Math.tan(ang / 2), 0.45 * Math.min(lu, lv));
    const rr = t * Math.tan(ang / 2);
    const bis = [u[0] + v[0], u[1] + v[1]];
    const lb = Math.hypot(...bis);
    const c = [corner[0] + (bis[0] / lb) * (rr / Math.sin(ang / 2)), corner[1] + (bis[1] / lb) * (rr / Math.sin(ang / 2))];
    const a = [corner[0] + u[0] * t, corner[1] + u[1] * t];
    const b = [corner[0] + v[0] * t, corner[1] + v[1] * t];
    const a0 = Math.atan2(a[1] - c[1], a[0] - c[0]);
    let d = Math.atan2(b[1] - c[1], b[0] - c[0]) - a0;
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d < -Math.PI) d += 2 * Math.PI;
    const n = Math.max(2, Math.ceil(Math.abs(d) / rad(6)));
    const out = [];
    for (let i = 0; i <= n; i++) out.push([c[0] + rr * Math.cos(a0 + (d * i) / n), c[1] + rr * Math.sin(a0 + (d * i) / n)]);
    return out;
  }

  // Radius of the polyline at z (linear; the first or last leg is extended outside the polyline).
  function rAt(chain, z) {
    let i = 1;
    while (i < chain.length - 1 && z > chain[i][1]) i++;
    const a = chain[i - 1];
    const b = chain[i];
    return a[0] + ((b[0] - a[0]) * (z - a[1])) / (b[1] - a[1]);
  }

  // Seating depth below the mouth, in bullet diameters.
  function seatFactor(rec) {
    const pistol = rec.annotations.category === 'pistol';
    return { pointy: 1.0, rounded: pistol ? 0.4 : 0.8, flat: pistol ? 0.4 : 0.8, semi_wadcutter: 0.6 }[rec.annotations.defaultBulletShape];
  }

  function bulletProfile(rec, L3, L6, tb) {
    const c = rec.cartridge;
    const shape = rec.annotations.defaultBulletShape;
    const G1 = c.projectile.G1;
    const pistol = rec.annotations.category === 'pistol';
    const seat = seatFactor(rec);
    const k = { pointy: 0.4, rounded: pistol ? 0.65 : 0.55, flat: pistol ? 0.7 : 0.6, semi_wadcutter: 0.78 }[shape];
    const m = { pointy: Math.max(0.08 * G1, 1.27), rounded: 0.15 * G1, flat: 0.55 * G1, semi_wadcutter: 0.6 * G1 }[shape];
    if (seat === undefined) return { notes: ['Bullet not drawn: default bullet shape not published.'] };
    const H2 = c.collar.H2;
    const heeled = has(H2) && H2 - G1 <= 0.015;
    const s = seat * G1;
    const zb = L3 - s;
    const Lb = L6 - zb;
    const zc = zb + k * Lb;
    const n = L6 - zc;
    const rEx = (heeled ? H2 : G1) / 2;
    const rBase = heeled ? (H2 - 2 * tb) / 2 : rEx;
    const prof = [[0, zb], [rBase, zb]];
    if (heeled) prof.push([rBase, L3], [rEx, L3]);
    prof.push([rEx, zc]);
    const a = rEx - m / 2;
    if (shape === 'pointy' && n > a) {
      const rho = (a * a + n * n) / (2 * a);
      for (let i = 1; i < 24; i++) {
        const dz = (n * i) / 24;
        prof.push([rEx - rho + Math.sqrt(rho * rho - dz * dz), zc + dz]);
      }
    } else if (shape === 'rounded') {
      for (let i = 1; i < 16; i++) {
        const t = (Math.PI / 2) * (i / 16);
        prof.push([m / 2 + a * Math.cos(t), zc + n * Math.sin(t)]);
      }
    }
    prof.push([m / 2, L6], [0, L6]);
    const exposed = [[rEx, L3], ...prof.filter((p, i) => i >= 2 && p[1] > L3 && p[0] > 0)];
    return { profile: prof, exposed, zb, s, zc, Lb, m, rEx, heeled, shape, notes: [] };
  }

  function build(rec) {
    const c = rec.cartridge;
    const h = c.caseHead;
    const L = c.lengths;
    const notes = [];
    const missing = [['R1', h.R1], ['R', h.R], ['P1', c.powderChamber.P1], ['H2', c.collar.H2], ['L3', L.L3], ['G1', c.projectile.G1]]
      .filter((e) => !has(e[1])).map((e) => F.symbol(e[0]));
    if (missing.length) {
      return { profile: [], labels: [], outlines: [], notes: [`Drawing not available: ${missing.join(', ')} not published.`], svg: emptySvg(rec) };
    }
    const { R1, R } = h;
    const { P1, P2 } = c.powderChamber;
    const { H1, H2 } = c.collar;
    const { L1, L2, L3, L6 } = L;
    const G1 = c.projectile.G1;
    const type = rimType(rec);

    // 2. head face and rim edge
    let pts = [[0, 0]];
    if (type === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      const cr = R1 / 2 - rho;
      pts.push([cr, 0]);
      for (let i = 0; i <= 12; i++) {
        const a = -Math.PI / 2 + (Math.PI * i) / 12;
        pts.push([cr + rho * Math.cos(a), R / 2 + rho * Math.sin(a)]);
      }
      pts.push([cr, R]);
    } else {
      if (has(h.beta) && has(h.f) && F.degrees(h.beta) < 90) {
        pts.push([R1 / 2 - Math.min(h.f * Math.tan(rad(F.degrees(h.beta))), R1 / 4), 0], [R1 / 2, h.f]);
      } else {
        pts.push([R1 / 2, 0]);
        if (!(has(h.beta) && F.degrees(h.beta) >= 90)) notes.push(`Head chamfer not drawn: ${[!has(h.beta) && 'β', !has(h.f) && 'f'].filter(Boolean).join(', ')} not published.`);
      }
      pts.push([R1 / 2, R]);
    }

    // 3. extractor groove, belt or plain step
    let groove = false;
    let belt = false;
    let rampEnd = null;
    if (type !== 'rimfire') {
      if (has(h.E) && has(h.E1) && has(h.eMin)) groove = true;
      else if (has(h.E) || has(h.E1) || type !== 'rimmed') {
        notes.push(`Extractor groove not drawn: ${['E', 'E1', 'eMin'].filter((k) => !has(h[k])).map(F.symbol).join(', ')} not published.`);
      }
    }
    if (groove) {
      pts.push([h.E1 / 2, R], [h.E1 / 2, R + h.eMin]);
      if (type === 'belted' && has(h.R3) && has(h.delta)) {
        belt = true;
        rampEnd = R + h.eMin + (h.R3 / 2 - h.E1 / 2) / Math.tan(rad(F.degrees(h.delta)));
        pts.push([h.R3 / 2, rampEnd], [h.R3 / 2, h.E]);
      } else if (type === 'belted') {
        notes.push(`Belt not drawn: ${[!has(h.R3) && 'R3', !has(h.delta) && 'δ'].filter(Boolean).join(', ')} not published.`);
      }
      pts.push([P1 / 2, h.E]);
    } else {
      pts.push([P1 / 2, R]);
    }
    pts = pts.filter((p, i) => i === 0 || dist(p, pts[i - 1]) > 1e-9);
    const z0 = pts[pts.length - 1][1];

    // 4-6. body, shoulder, neck
    const cone = c.junctionCone || {};
    const shoulder = has(cone.alpha) && has(L1) && has(L2);
    const bottleneck = shoulder && has(P2) && has(H1);
    if (shoulder && !bottleneck) notes.push(`Shoulder not drawn: ${[!has(P2) && 'P2', !has(H1) && 'H1'].filter(Boolean).join(', ')} not published.`);
    let chain = [pts[pts.length - 1]];
    if (bottleneck) {
      const A = [P2 / 2, L1];
      const B = [H1 / 2, L2];
      const M = [H2 / 2, L3];
      const { r1Min, r2 } = cone;
      if (!has(r1Min)) notes.push('Shoulder corner on the body side not rounded: r1 min not published.');
      if (!has(r2)) notes.push('Shoulder corner on the neck side not rounded: r2 not published.');
      chain.push(...(has(r1Min) ? fillet(chain[0], A, B, r1Min) : [A]));
      chain.push(...(has(r2) ? fillet(A, B, M, r2) : [B]));
      chain.push(M);
    } else {
      chain.push([H2 / 2, L3]);
    }
    const profile = pts.concat(chain.slice(1));

    // 7. bullet (seating needs only G1, L3 and the shape)
    const tn = (H2 - G1) / 2;
    const heeled = H2 - G1 <= 0.015;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * P1) / 2);
    const tNeck = heeled ? tb : tn;
    let bullet = null;
    if (!has(L6)) notes.push('Bullet not drawn: L6 not published.');
    else {
      bullet = bulletProfile(rec, L3, L6, tb);
      notes.push(...bullet.notes);
      if (!bullet.profile) bullet = null;
    }
    const zSeat = L3 - (seatFactor(rec) || 0) * G1;

    // 8. walls, solid head and primer pocket
    let pocket = null;
    const pt = rec.annotations.primerType;
    if (type !== 'rimfire') {
      if (POCKET_D[pt]) pocket = { d: POCKET_D[pt], depth: POCKET_DEPTH[pt] };
      else notes.push('Primer pocket not drawn: primer type not published.');
    }
    const wParts = [2.5, (0.25 * P1) / 2];
    if (pocket) wParts.push(pocket.depth + 1.5);
    if (belt) wParts.push(rampEnd + tb);
    else if (groove) wParts.push(h.E + tb);
    const w = Math.max(...wParts);
    // Wall: tb along the body, tn along the neck, linear across the shoulder. A straight case has no shoulder:
    // the wall thins linearly from tb at the solid head to tn at the bullet base.
    const wall = (z) => {
      if (bottleneck) return z <= L1 ? tb : z >= L2 ? tNeck : tb + ((tNeck - tb) * (z - L1)) / (L2 - L1);
      const z1 = Math.max(zSeat, w + 1e-6);
      return z <= w ? tb : z >= z1 ? tNeck : tb + ((tNeck - tb) * (z - w)) / (z1 - w);
    };
    const zs = [...new Set([w, ...chain.map((p) => p[1]).filter((z) => z > w), ...(bottleneck ? [L1, L2] : [Math.max(zSeat, w + 1e-6)])])]
      .filter((z) => z >= w && z <= L3).sort((a, b) => a - b);
    const inner = zs.map((z) => [rAt(chain, z) - wall(z), z]);

    // geometry done: the SVG
    const out = draw({ rec, type, profile, chain, inner, w, pocket, bullet, groove, belt, bottleneck, z0, tb, notes });
    return { type, profile, chain, inner, w, tn, tb, pocket, bullet, bottleneck, groove, belt, notes, ...out };
  }

  function draw(g) {
    const { rec, profile, chain, inner, w, pocket, bullet, type } = g;
    const c = rec.cartridge;
    const h = c.caseHead;
    const { P1, P2 } = c.powderChamber;
    const { H1, H2 } = c.collar;
    const { L1, L2, L3, L6 } = c.lengths;
    const parts = [];
    const labels = [];
    const outlines = [];
    const bb = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    const inc = (x, y) => {
      bb.x0 = Math.min(bb.x0, x); bb.x1 = Math.max(bb.x1, x); bb.y0 = Math.min(bb.y0, y); bb.y1 = Math.max(bb.y1, y);
    };
    const up = (a) => a.map(([r, z]) => [z, -r]);
    const dn = (a) => a.map(([r, z]) => [z, r]);
    const sv = (a) => a.map((p) => `${r3(p[0])},${r3(p[1])}`).join(' ');
    const poly = (cls, a) => `<polygon class="${cls}" points="${sv(a)}"/>`;
    const pline = (cls, a) => `<polyline class="${cls}" points="${sv(a)}"/>`;
    const line = (cls, x1, y1, x2, y2) => {
      inc(x1, y1); inc(x2, y2);
      return `<line class="${cls}" x1="${r3(x1)}" y1="${r3(y1)}" x2="${r3(x2)}" y2="${r3(y2)}"/>`;
    };
    const arrow = (x, y, dx, dy, len = ARROW) => {
      const d = Math.hypot(dx, dy);
      const ux = dx / d; const uy = dy / d;
      const bx = x - ux * len; const by = y - uy * len;
      const wd = len / 6;
      return `<polygon class="arrow" points="${sv([[x, y], [bx - uy * wd, by + ux * wd], [bx + uy * wd, by - ux * wd]])}"/>`;
    };
    const keep = (a) => { a.forEach((p) => inc(p[0], p[1])); outlines.push(a); return a; };

    // --- outlines (also recorded for the overlap check)
    const rMax = Math.max(...profile.map((p) => p[0]), bullet ? bullet.rEx : 0);
    const upProf = keep(up(profile));
    const mouth = [[L3, -H2 / 2], [L3, -(bullet ? bullet.rEx : H2 / 2)]];
    const dnProf = keep(dn(profile));
    keep(dn(inner));
    let sect = pocket ? [[pocket.d / 2, 0], ...profile.slice(1)] : profile.slice();
    sect = sect.concat([...inner].reverse(), [[0, w]], pocket ? [[0, pocket.depth], [pocket.d / 2, pocket.depth]] : []);
    parts.push('<g class="view-outside">');
    parts.push(poly('fill-case', up([...profile, [0, L3]])));
    parts.push(pline('ol', upProf.concat([mouth[1]])));
    if (bullet) {
      parts.push(poly('fill-bullet', up(bullet.exposed.concat([[0, L6], [0, L3]]))));
      parts.push(pline('ol', keep(up(bullet.exposed.concat([[0, L6]])))));
    }
    parts.push('</g><g class="view-section">');
    parts.push(poly('hatch-case', dn(sect)));
    const dnSect = dn(sect);
    const cut = pocket ? sect.indexOf(sect.find((p) => p[0] === 0 && p[1] === w)) : sect.length - 1;
    parts.push(`<path class="ol" d="M${sv(dnSect.slice(0, cut + 1)).replace(/ /g, ' L')}${pocket ? ` M${sv(dnSect.slice(cut + 1)).replace(/ /g, ' L')} L${r3(dnSect[0][0])},${r3(dnSect[0][1])}` : ''}"/>`);
    if (bullet) {
      const full = dn(bullet.profile);
      parts.push(poly('hatch-bullet', full));
      parts.push(pline('ol', keep(full.slice(0, -1))));
    }
    parts.push('</g>');
    parts.push(line('centre', -3, 0, (bullet ? L6 : L3) + 3, 0));

    // --- dimensions
    const dimParts = [];
    const vdims = []; // diameters above the drawing: vertical dimension line + staircase label rows
    const addV = (id, text, z, r) => vdims.push({ id, text, x: z, r });
    addV('R1', `R1 ${F.num(h.R1)}`, h.R / 2, h.R1 / 2);
    if (g.groove) addV('E1', `E1 ${F.num(h.E1)}`, h.R + h.eMin / 2, h.E1 / 2);
    addV('P1', `P1 ${F.num(P1)}`, g.z0 + 0.6, rAt(chain, g.z0 + 0.6));
    if (g.bottleneck) {
      addV('P2', `P2 ${F.num(P2)}`, L1 - 1.2, rAt(chain, L1 - 1.2));
      addV('H1', `H1 ${F.num(H1)}`, L2 + 1.2, rAt(chain, L2 + 1.2));
    }
    addV('H2', `H2 ${F.num(H2)}`, L3 - 1.2, rAt(chain, L3 - 1.2));
    if (bullet) addV('G1', `G1 ${F.num(c.projectile.G1)}`, (L3 + bullet.zc) / 2, bullet.rEx);
    let alpha = null;
    if (g.bottleneck) {
      const dr = (P2 - H1) / 2;
      const half = Math.atan2(dr, L2 - L1);
      const apex = L2 + H1 / 2 / Math.tan(half);
      const ra = 0.5 * (H1 / 2 / Math.sin(half));
      alpha = { half, apex, ra, ux: apex - ra * Math.cos(half), uy: ra * Math.sin(half) };
      addV('alpha', `α ${F.angle(c.junctionCone.alpha)}`, alpha.ux, alpha.uy);
    }
    vdims.sort((a, b) => a.x - b.x);
    const rowOf = new Array(vdims.length).fill(0);
    for (let i = vdims.length - 1; i >= 0; i--) {
      const wi = [...vdims[i].text].length * CW;
      for (let j = i + 1; j < vdims.length; j++) if (vdims[j].x < vdims[i].x + 0.6 + wi + 0.8) rowOf[i] = Math.max(rowOf[i], rowOf[j] + 1);
    }
    vdims.forEach((d, i) => {
      const yRow = -(rMax + 2.2 + rowOf[i] * ROW_TOP);
      const isAlpha = d.id === 'alpha';
      if (isAlpha) {
        dimParts.push(line('ext', d.x, -d.r, d.x, yRow));
      } else {
        dimParts.push(line('dim', d.x, d.r, d.x, yRow));
        dimParts.push(arrow(d.x, d.r, 0, 1), arrow(d.x, -d.r, 0, -1));
      }
      const wd = [...d.text].length * CW;
      labels.push({ id: d.id, text: d.text, x: d.x + 0.6, y: yRow - FS / 2, w: wd, h: FS });
      inc(d.x + 0.6 + wd, yRow - FS / 2);
    });
    if (alpha) {
      const { half, apex, ra } = alpha;
      const Bz = L2; const Br = H1 / 2;
      const arc = [];
      for (let i = 0; i <= 12; i++) {
        const p = -half + (2 * half * i) / 12;
        arc.push([apex - ra * Math.cos(p), ra * Math.sin(p)]);
      }
      dimParts.push(`<polyline class="dim" points="${sv(arc)}"/>`);
      dimParts.push(line('ext', Bz, -Br, alpha.ux, -alpha.uy), line('ext', Bz, Br, alpha.ux, alpha.uy));
      dimParts.push(arrow(alpha.ux, -alpha.uy, Math.sin(half), -Math.cos(half), 1.2), arrow(alpha.ux, alpha.uy, Math.sin(half), Math.cos(half), 1.2));
      arc.forEach((p) => inc(p[0], p[1]));
    }

    // horizontal lengths below the drawing: nested rows, the smallest nearest to the part
    const hdims = [{ id: 'R', text: `R ${F.num(h.R)}`, v: h.R, r: h.R1 / 2 }];
    if (has(L1)) hdims.push({ id: 'L1', text: `L1 ${F.num(L1)}`, v: L1, r: has(P2) ? P2 / 2 : rAt(chain, L1) });
    if (has(L2)) hdims.push({ id: 'L2', text: `L2 ${F.num(L2)}`, v: L2, r: has(H1) ? H1 / 2 : rAt(chain, L2) });
    hdims.push({ id: 'L3', text: `L3 ${F.num(L3)}`, v: L3, r: H2 / 2 });
    if (bullet) hdims.push({ id: 'L6', text: `L6 ${F.num(L6)}`, v: L6, r: 0 });
    const y0 = rMax + 4.5;
    const yLast = y0 + (hdims.length - 1) * ROW_BOT + 1;
    dimParts.push(line('ext', 0, h.R1 / 2 + 0.8, 0, yLast));
    hdims.forEach((d, i) => {
      const y = y0 + i * ROW_BOT;
      const tip = d.id === 'L6' ? bullet.m / 2 : d.r;
      dimParts.push(line('ext', d.v, tip + 0.8, d.v, y + 1));
      dimParts.push(line('dim', 0, y, d.v, y));
      const len = Math.min(ARROW, d.v * 0.4);
      dimParts.push(arrow(0, y, -1, 0, len), arrow(d.v, y, 1, 0, len));
      const x = d.id === 'R' ? d.v + 1 : 1.2;
      const wd = [...d.text].length * CW;
      labels.push({ id: d.id, text: d.text, x, y: y - 0.5 - FS, w: wd, h: FS });
      inc(x + wd, y - 0.5 - FS);
    });

    const lab = labels.map((l) => `<text class="dim-label" data-dim="${l.id}" x="${r3(l.x)}" y="${r3(l.y + FS * 0.82)}">${esc(l.text)}</text>`);
    parts.push('<g class="dims">', ...dimParts, ...lab, '</g>');
    outlines.forEach((o) => o.forEach((p) => inc(p[0], p[1])));

    // title block, bottom right
    const lines = [rec.name, `C.I.P. table ${rec.tab}, revised ${rec.revised}`, 'Dimensions in mm', 'Scale 0.00 : 1 (A4 print)'];
    const tw = Math.max(...lines.map((s) => [...s].length)) * 0.62 * TFS + 4;
    const th = lines.length * (TFS + 1) + 2;
    const right = Math.max(bb.x1, bb.x0 + tw);
    const tx = right - tw;
    const ty = bb.y1 + 3;
    inc(tx, ty); inc(right, ty + th);
    const PAD = 2.5;
    const W = bb.x1 - bb.x0 + 2 * PAD;
    const H = bb.y1 - bb.y0 + 2 * PAD;
    const scale = Math.min(PRINT_W / W, PRINT_MAX_H / H);
    lines[3] = `Scale ${scale.toFixed(2)} : 1 (A4 print)`;
    parts.push(`<g class="titleblock"><rect x="${r3(tx)}" y="${r3(ty)}" width="${r3(tw)}" height="${r3(th)}"/>`);
    lines.forEach((s, i) => parts.push(`<text class="${i === 0 ? 'tb-name' : 'tb'}" x="${r3(tx + 2)}" y="${r3(ty + 1 + (i + 1) * (TFS + 1) - 0.8)}">${esc(s)}</text>`));
    parts.push('</g>');
    const viewBox = `${r3(bb.x0 - PAD)} ${r3(bb.y0 - PAD)} ${r3(W)} ${r3(H)}`;
    const pat = (id, cls, step, angle) =>
      `<pattern id="${id}" width="${step}" height="${step}" patternUnits="userSpaceOnUse" patternTransform="rotate(${angle})"><line class="${cls}" x1="0" y1="0" x2="0" y2="${step}"/></pattern>`;
    const name = esc(rec.name);
    const svg =
      `<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="${viewBox}" role="img" aria-label="${name} drawing" preserveAspectRatio="xMidYMid meet">` +
      `<title>${name} drawing</title><defs>${pat('hatch-case', 'hatch', 0.8, 45)}${pat('hatch-bullet', 'hatch hatch-light', 1.1, -45)}</defs>` +
      parts.join('') + '</svg>';
    return { labels, outlines, svg, viewBox, scale };
  }

  function emptySvg(rec) {
    const name = esc(rec.name);
    return `<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="0 0 10 5" role="img" aria-label="${name} drawing"><title>${name} drawing</title></svg>`;
  }

  const svg = (rec) => build(rec).svg;

  return { build, svg, rimType, fillet, rAt };
});
