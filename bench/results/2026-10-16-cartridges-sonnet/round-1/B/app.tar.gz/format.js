// Formatting, symbols, units and section layout of the record fields. Plain script, also loadable from Node.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CipFormat = factory();
})(this, function () {
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths', misc: 'Miscellaneous',
    powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile', barrel: 'Barrel',
    breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };

  const isAngle = (v) => v !== null && typeof v === 'object';
  const degrees = (v) => (isAngle(v) ? v.degrees + v.minutes / 60 + v.seconds / 3600 : v);
  // Numbers are shown as published: String() gives a decimal point and no thousands separator.
  const num = (n) => String(n);
  const angle = (v) => (isAngle(v) ? `${v.degrees}°${v.minutes}'${v.seconds}"` : `${v}°`);
  const symbol = (key) => SYMBOLS[key] || key;
  const unit = (key) => (ANGLES.has(key) ? '°' : key in UNITS ? UNITS[key] : 'mm');
  const value = (key, v) => (ANGLES.has(key) ? angle(v) : num(v));
  const tol = (t) => (t > 0 ? '+' : '') + num(t);

  // One row per field of a section; "<X>Tol" fields are merged into the row of X.
  function rows(section) {
    return Object.keys(section)
      .filter((k) => !k.endsWith('Tol'))
      .map((k) => {
        const t = section[k + 'Tol'];
        return { key: k, symbol: symbol(k), value: value(k, section[k]), tol: t === undefined ? '' : tol(t), unit: unit(k) };
      });
  }

  // Search ignores case, spaces and the difference between "," and ".".
  const norm = (s) => s.toLowerCase().replace(/,/g, '.').replace(/\s+/g, '');
  const matches = (rec, query) =>
    [rec.name, ...(rec.alternativeNames || [])].some((n) => norm(n).includes(norm(query)));

  return { ANGLES, SECTION_TITLES, isAngle, degrees, num, angle, symbol, unit, value, tol, rows, norm, matches };
});
