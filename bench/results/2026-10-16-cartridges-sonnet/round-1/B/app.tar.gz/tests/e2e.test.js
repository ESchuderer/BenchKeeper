const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');
require('../data.js');
const DATA = globalThis.CARTRIDGES;
const URL = pathToFileURL(path.join(__dirname, '..', 'index.html')).href;

let browser;
test.before(async () => { browser = await chromium.launch(); });
test.after(async () => { await browser.close(); });

async function open(opts = {}) {
  const page = await browser.newPage(opts);
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('request', (r) => !r.url().startsWith('file:') && errors.push('network: ' + r.url()));
  await page.goto(URL);
  page.errors = errors;
  return page;
}

test('list, search, family filter', async () => {
  const page = await open();
  assert.equal(await page.getByRole('heading', { name: 'Cartridges' }).count(), 1);
  assert.equal(await page.locator('#count').textContent(), '25 cartridges');
  await page.getByLabel('Search').fill('7,62 x 51');
  assert.equal(await page.locator('#count').textContent(), '1 cartridges');
  assert.equal(await page.getByRole('link', { name: '308 Win.', exact: true }).isVisible(), true);
  await page.getByLabel('Search').fill('');
  await page.getByLabel('Family').selectOption('belted');
  assert.equal(await page.locator('#count').textContent(), '2 cartridges');
  await page.getByLabel('Family').selectOption('All');
  assert.equal(await page.locator('#count').textContent(), '25 cartridges');
  assert.deepEqual(page.errors, []);
});

test('detail view: address survives reload, content, back link', async () => {
  const page = await open();
  await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).click();
  assert.match(page.url(), /#\/cartridge\/6_5_creedmoor$/);
  await page.reload();
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '6,5 Creedmoor');
  assert.equal(await page.getByRole('img', { name: '6,5 Creedmoor drawing' }).count(), 1);
  assert.ok((await page.locator('table').count()) > 10);
  assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await page.locator('#count').textContent(), '25 cartridges');
  assert.deepEqual(page.errors, []);
});

test('table rows show tolerance next to the value', async () => {
  const page = await open();
  await page.goto(URL + '#/cartridge/308_win');
  const row = page.locator('tr', { has: page.locator('th', { hasText: /^L1$/ }) }).first();
  assert.equal((await row.locator('td').first().textContent()).trim(), '39.62 -0.2');
  assert.equal(await page.locator('th', { hasText: /^L1Tol$/ }).count(), 0);
});

test('drawing: every record renders, labels are inside the viewBox and do not overlap', async () => {
  const page = await open();
  for (const rec of DATA) {
    await page.goto(URL + '#/cartridge/' + rec.key);
    const res = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const vb = svg.viewBox.baseVal;
      const texts = [...svg.querySelectorAll('.dim-label')].map((t) => ({ id: t.dataset.dim, b: t.getBBox() }));
      const hit = [];
      texts.forEach((a, i) => texts.slice(i + 1).forEach((b) => {
        if (a.b.x < b.b.x + b.b.width && b.b.x < a.b.x + a.b.width && a.b.y < b.b.y + b.b.height && b.b.y < a.b.y + a.b.height) hit.push(a.id + '/' + b.id);
      }));
      const outside = texts.filter((t) => t.b.x < vb.x || t.b.x + t.b.width > vb.x + vb.width || t.b.y < vb.y || t.b.y + t.b.height > vb.y + vb.height).map((t) => t.id);
      return { hit, outside, n: texts.length };
    });
    assert.deepEqual(res.hit, [], rec.name);
    assert.deepEqual(res.outside, [], rec.name);
    assert.ok(res.n >= 5, rec.name);
  }
  assert.deepEqual(page.errors, []);
});

test('print: one A4 page for every record', async () => {
  const page = await open();
  for (const rec of DATA) {
    await page.goto(URL + '#/cartridge/' + rec.key);
    const pdf = await page.pdf({ preferCSSPageSize: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    assert.equal(pages, 1, rec.name);
  }
});
