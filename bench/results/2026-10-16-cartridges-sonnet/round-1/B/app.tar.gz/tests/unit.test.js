const test = require('node:test');
const assert = require('node:assert/strict');
require('../data.js');
const F = require('../format.js');
const D = require('../drawing.js');

const DATA = globalThis.CARTRIDGES;
const by = (key) => DATA.find((r) => r.key === key);
const near = (a, b, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${a} != ${b}`);
const has = (pts, r, z) => pts.some((p) => Math.abs(p[0] - r) < 1e-9 && Math.abs(p[1] - z) < 1e-9);

test('data: 25 records, unique keys', () => {
  assert.equal(DATA.length, 25);
  assert.equal(new Set(DATA.map((r) => r.key)).size, 25);
});

test('format: numbers and angles as published', () => {
  assert.equal(F.num(4150.0), '4150');
  assert.equal(F.num(51.18), '51.18');
  assert.equal(F.angle(40), '40°');
  assert.equal(F.angle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(F.symbol('eMin'), 'e min');
  assert.equal(F.symbol('L3PlusG'), 'L3 + G');
  assert.equal(F.symbol('alpha1'), 'α1');
  assert.equal(F.unit('Pmax'), 'bar');
  assert.equal(F.unit('Q'), 'mm²');
  assert.equal(F.unit('N'), '');
  assert.equal(F.unit('L3'), 'mm');
});

test('format: tolerance is merged into the value row', () => {
  const rows = F.rows(by('308_win').cartridge.lengths);
  assert.ok(!rows.some((r) => r.key.endsWith('Tol')));
  const l1 = rows.find((r) => r.key === 'L1');
  assert.equal(l1.value, '39.62');
  assert.equal(l1.tol, '-0.2');
});

test('search: alternative names and decimal comma', () => {
  const hits = (q) => DATA.filter((r) => F.matches(r, q)).map((r) => r.name);
  assert.deepEqual(hits('7,62 x 51'), ['308 Win.']);
  assert.deepEqual(hits('7.62x51'), ['308 Win.']);
  assert.ok(hits('creed').includes('6,5 Creedmoor'));
  assert.equal(hits('').length, 25);
});

test('rim type rules', () => {
  const t = (k) => D.rimType(by(k));
  assert.equal(t('223_rem'), 'rimless');
  assert.equal(t('7_x_65_r'), 'rimmed');
  assert.equal(t('38_special'), 'rimmed');
  assert.equal(t('300_win_mag'), 'belted');
  assert.equal(t('22_long_rifle'), 'rimfire');
  assert.equal(t('9_mm_luger'), 'rimless');
  assert.equal(D.rimType({ family: 'pistol', cartridge: { caseHead: { R1: 9, }, powderChamber: { P1: 10 } } }), 'rebated');
});

test('profile: head face chamfer, groove, body and mouth (308 Win.)', () => {
  const g = D.build(by('308_win'));
  const c = by('308_win').cartridge;
  const h = c.caseHead;
  const p = g.profile;
  assert.deepEqual(p[0], [0, 0]);
  near(p[1][0], h.R1 / 2 - Math.min(h.f * Math.tan((h.beta * Math.PI) / 180), h.R1 / 4));
  assert.equal(p[1][1], 0);
  assert.ok(has(p, h.R1 / 2, h.f));
  assert.ok(has(p, h.R1 / 2, h.R));
  assert.ok(has(p, h.E1 / 2, h.R));
  assert.ok(has(p, h.E1 / 2, h.R + h.eMin));
  assert.ok(has(p, c.powderChamber.P1 / 2, h.E));
  assert.ok(has(p, c.powderChamber.P2 / 2, c.lengths.L1) || g.profile.some((q) => Math.abs(q[1] - c.lengths.L1) < 0.3));
  assert.deepEqual(p[p.length - 1], [c.collar.H2 / 2, c.lengths.L3]);
});

test('profile: belted case follows ramp at delta, belt to E, step in', () => {
  const c = by('300_win_mag').cartridge;
  const h = c.caseHead;
  const p = D.build(by('300_win_mag')).profile;
  const zRamp = h.R + h.eMin + (h.R3 / 2 - h.E1 / 2) / Math.tan((h.delta * Math.PI) / 180);
  assert.ok(has(p, h.R3 / 2, zRamp));
  assert.ok(has(p, h.R3 / 2, h.E));
  assert.ok(has(p, c.powderChamber.P1 / 2, h.E));
});

test('profile: rimmed case steps in at R, no groove', () => {
  const c = by('7_x_65_r').cartridge;
  const p = D.build(by('7_x_65_r')).profile;
  assert.ok(has(p, c.caseHead.R1 / 2, c.caseHead.R));
  assert.ok(has(p, c.powderChamber.P1 / 2, c.caseHead.R));
});

test('profile: rimfire half-round reaches R1/2', () => {
  const rec = by('22_long_rifle');
  const p = D.build(rec).profile;
  const h = rec.cartridge.caseHead;
  near(Math.max(...p.map((q) => q[0])), h.R1 / 2);
});

test('profile: straight case runs to (H2/2, L3); bottleneck passes the shoulder points', () => {
  const g = D.build(by('9_mm_luger'));
  assert.equal(g.bottleneck, false);
  const b = D.build(by('308_win'));
  assert.equal(b.bottleneck, true);
  assert.equal(D.build(by('22_win_mag_r_f')).bottleneck, false);
});

test('wall, solid head and primer pocket', () => {
  const g = D.build(by('308_win'));
  const c = by('308_win').cartridge;
  const tn = (c.collar.H2 - c.projectile.G1) / 2;
  const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * c.powderChamber.P1) / 2);
  near(g.tn, tn);
  near(g.tb, tb);
  assert.deepEqual(g.pocket, { d: 5.33, depth: 3.3 });
  near(g.w, Math.max(2.5, (0.25 * c.powderChamber.P1) / 2, 3.3 + 1.5, c.caseHead.E + tb));
  assert.deepEqual(D.build(by('223_rem')).pocket, { d: 4.45, depth: 3.04 });
  assert.equal(D.build(by('22_long_rifle')).pocket, null);
});

test('bullet: seating, tip at L6, meplat, heeled case', () => {
  const rec = by('308_win');
  const g = D.build(rec);
  const c = rec.cartridge;
  near(g.bullet.zb, c.lengths.L3 - c.projectile.G1);
  const tip = g.bullet.profile[g.bullet.profile.length - 2];
  near(tip[1], c.lengths.L6);
  near(tip[0], 1.27 / 2);
  const lr = D.build(by('22_long_rifle'));
  near(lr.bullet.profile[1][0], (5.72 - 2 * lr.tb) / 2);
  near(Math.max(...lr.bullet.profile.map((q) => q[0])), 5.72 / 2);
  const p9 = D.build(by('9_mm_luger'));
  near(p9.bullet.zb, 19.15 - 0.4 * 9.03);
});

test('missing values are reported, nothing is invented', () => {
  assert.deepEqual(D.build(by('308_win')).notes, []);
  assert.ok(D.build(by('338_lapua_mag')).notes.some((n) => /r1 min/.test(n)));
  const hmr = D.build(by('17_hmr')).notes.join(' ');
  assert.ok(/r1 min/.test(hmr) && /r2/.test(hmr));
  const odd = JSON.parse(JSON.stringify(by('308_win')));
  delete odd.cartridge.caseHead.eMin;
  const g = D.build(odd);
  assert.ok(g.notes.some((n) => /e min/.test(n)));
  assert.ok(!has(g.profile, odd.cartridge.caseHead.E1 / 2, odd.cartridge.caseHead.R));
});

test('every record: required labels present and no label collides', () => {
  for (const rec of DATA) {
    const g = D.build(rec);
    const ids = g.labels.map((l) => l.id);
    for (const id of ['L3', 'L6', 'R1', 'R', 'P1']) assert.ok(ids.includes(id), `${rec.name}: ${id}`);
    const c = rec.cartridge;
    if (c.lengths.L1 !== undefined) assert.ok(ids.includes('L1'), `${rec.name}: L1`);
    if (c.powderChamber.P2 !== undefined) assert.ok(ids.includes('P2'), `${rec.name}: P2`);
    if (g.bottleneck) assert.ok(ids.includes('alpha'), `${rec.name}: alpha`);
    for (let i = 0; i < g.labels.length; i++) {
      const a = g.labels[i];
      for (let j = i + 1; j < g.labels.length; j++) {
        const b = g.labels[j];
        const hit = a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
        assert.ok(!hit, `${rec.name}: ${a.id} overlaps ${b.id}`);
      }
      for (const line of g.outlines) {
        for (let k = 1; k < line.length; k++) {
          assert.ok(!segHitsRect(line[k - 1], line[k], a), `${rec.name}: ${a.id} touches outline`);
        }
      }
    }
  }
});

function segHitsRect(p, q, r) {
  // Liang-Barsky clip of the segment against the rectangle.
  let t0 = 0;
  let t1 = 1;
  const dx = q[0] - p[0];
  const dy = q[1] - p[1];
  for (const [pp, qq] of [[-dx, p[0] - r.x], [dx, r.x + r.w - p[0]], [-dy, p[1] - r.y], [dy, r.y + r.h - p[1]]]) {
    if (pp === 0) {
      if (qq < 0) return false;
    } else {
      const t = qq / pp;
      if (pp < 0) t0 = Math.max(t0, t);
      else t1 = Math.min(t1, t);
    }
  }
  return t0 < t1;
}

test('svg: accessible name, escaping, label text, scale', () => {
  const svg = D.svg(by('40_s_w'));
  assert.ok(svg.includes('aria-label="40 S.&amp; W. drawing"'));
  assert.ok(D.svg(by('308_win')).includes('>L3 51.18</text>'));
  assert.ok(/Dimensions in mm/.test(svg) && /Scale/.test(svg) && /table I/.test(D.svg(by('308_win'))) && /2008-09-23/.test(D.svg(by('308_win'))));
});
