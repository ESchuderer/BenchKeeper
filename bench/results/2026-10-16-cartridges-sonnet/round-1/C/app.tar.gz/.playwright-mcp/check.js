async (page) => page.evaluate(async () => {
  const res = {};
  for (const r of CARTRIDGES) {
    location.hash = '#/' + r.key;
    await new Promise(r => setTimeout(r, 40));
    const svg = document.querySelector('#detail-view svg');
    const texts = [...svg.querySelectorAll('text')].filter(t => t.getBoundingClientRect().width > 0).map(t => ({ s: t.textContent, b: t.getBoundingClientRect() }));
    const issues = [];
    for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
      const a = texts[i].b, b = texts[j].b;
      if (!(a.right <= b.left || b.right <= a.left || a.bottom <= b.top || b.bottom <= a.top)) issues.push(`${texts[i].s} x ${texts[j].s}`);
    }
    const segs = [];
    svg.querySelectorAll('line:not(.hatch):not(.cl):not(.e)').forEach(l => { const m = svg.getScreenCTM(); const p = (x, y) => [m.a * x + m.e, m.d * y + m.f]; segs.push([p(+l.getAttribute('x1'), +l.getAttribute('y1')), p(+l.getAttribute('x2'), +l.getAttribute('y2')), l.getAttribute('class')]); });
    svg.querySelectorAll('path.o').forEach(pa => { const m = pa.getScreenCTM(); const L = pa.getTotalLength(); let prev; for (let k = 0; k <= 400; k++) { const q = pa.getPointAtLength(L * k / 400); const c = [m.a * q.x + m.e, m.d * q.y + m.f]; if (prev) segs.push([prev, c, 'outline']); prev = c; } });
    for (const t of texts) for (const [[x1, y1], [x2, y2], cls] of segs) {
      const n = Math.max(2, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 0.5));
      let hit = false;
      for (let i = 0; i <= n && !hit; i++) { const x = x1 + (x2 - x1) * i / n, y = y1 + (y2 - y1) * i / n; if (x > t.b.left + 0.3 && x < t.b.right - 0.3 && y > t.b.top + 0.3 && y < t.b.bottom - 0.3) hit = true; }
      if (hit) { issues.push(t.s + ' touches ' + cls); break; }
    }
    const vb = svg.viewBox.baseVal; const sb = svg.getBoundingClientRect();
    for (const t of texts) if (t.b.left < sb.left - 0.5 || t.b.right > sb.right + 0.5 || t.b.top < sb.top - 0.5 || t.b.bottom > sb.bottom + 0.5) issues.push(t.s + ' outside svg');
    if (issues.length) res[r.key] = issues;
  }
  return Object.keys(res).length ? res : 'all ok';
})
