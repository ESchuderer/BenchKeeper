(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const listView = $('list-view'), detailView = $('detail-view');
  let observer;

  function renderList() {
    const rows = Format.filterCartridges(CARTRIDGES, $('search').value, $('family').value);
    $('count').textContent = `${rows.length} cartridges`;
    document.querySelector('#list tbody').innerHTML = rows
      .map((r) => `<tr><td><a href="#/${encodeURIComponent(r.key)}">${esc(r.name)}</a></td><td>${esc(r.family)}</td><td class="num">${r.cartridge.lengths.L3}</td></tr>`)
      .join('');
  }

  const attr = (a) => `<dt>${esc(a.label)}</dt><dd>${esc(a.value)}${a.link ? ` (<a href="${esc(a.link.href)}" rel="noopener noreferrer">${esc(a.link.text)}</a>)` : ''}</dd>`;
  const table = (s) =>
    `<table><caption>${esc(s.title)}</caption><thead><tr><th scope="col">Symbol</th><th scope="col">Value</th><th scope="col" class="u">Unit</th></tr></thead><tbody>` +
    s.rows.map((x) => `<tr><th scope="row">${esc(x.symbol)}</th><td class="num">${esc(x.value)}</td><td class="u">${esc(x.unit)}</td></tr>`).join('') +
    '</tbody></table>';

  function renderDetail(rec) {
    const d = Drawing.buildDrawing(rec);
    detailView.innerHTML =
      `<nav class="noprint"><a href="#/">All cartridges</a><button type="button" id="print">Print</button></nav>` +
      `<h1>${esc(rec.name)}</h1>` +
      `<dl class="attrs">${Format.attributes(rec).map(attr).join('')}</dl>` +
      `<figure>${d.error ? `<p class="note">${esc(d.error)}</p>` : d.svg}` +
      (d.notes.length ? `<figcaption><ul class="notes">${d.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul></figcaption>` : '') +
      '</figure>' +
      Format.buildTables(rec).map((g) => `<section class="group"><h2>${esc(g.title)}</h2><div class="tables">${g.sections.map(table).join('')}</div></section>`).join('') +
      `<footer class="print-only">Source: C.I.P. TDCC, revised ${esc(rec.revised)}</footer>`;
    $('print').addEventListener('click', () => window.print());
    const svg = detailView.querySelector('svg');
    if (observer) observer.disconnect();
    if (svg) {
      const label = svg.querySelector('.scale-screen');
      const update = () => {
        // displayed scale: CSS px per drawing unit over CSS px per mm (96 dpi)
        label.textContent = `Scale ${(svg.getBoundingClientRect().width / Number(svg.dataset.vbw) / (96 / 25.4)).toFixed(2)}:1`;
      };
      observer = new ResizeObserver(update);
      observer.observe(svg);
      update();
    }
  }

  function route() {
    let key = location.hash.replace(/^#\/?/, '');
    try { key = decodeURIComponent(key); } catch { /* malformed escape: matches no record */ }
    const rec = key && CARTRIDGES.find((r) => r.key === key);
    listView.hidden = !!key;
    detailView.hidden = !key;
    if (!key) document.title = 'C.I.P. cartridges';
    else if (rec) { renderDetail(rec); document.title = `${rec.name} - C.I.P. cartridges`; }
    else {
      detailView.innerHTML = '<nav><a href="#/">All cartridges</a></nav><h1>Not found</h1><p>No cartridge has this address.</p>';
      document.title = 'Not found - C.I.P. cartridges';
    }
    window.scrollTo(0, 0);
  }

  $('search').addEventListener('input', renderList);
  $('family').addEventListener('change', renderList);
  window.addEventListener('hashchange', route);
  renderList();
  route();
})();
