const Drawing = (() => {
  const Fmt = typeof module !== 'undefined' ? require('./format.js') : Format;
  const RAD = Math.PI / 180;
  const num = (x) => typeof x === 'number';
  const deg = (a) => (a && typeof a === 'object' ? a.degrees + a.minutes / 60 + a.seconds / 3600 : a);
  const POCKETS = {
    sp: { d: 4.45, h: 3.04 }, spm: { d: 4.45, h: 3.04 }, sr: { d: 4.45, h: 3.04 },
    lp: { d: 5.33, h: 3.04 }, lpm: { d: 5.33, h: 3.04 },
    lr: { d: 5.33, h: 3.3 }, lrm: { d: 5.33, h: 3.3 },
  };
  const SEAT = { pointy: 1, rounded: [0.8, 0.4], flat: [0.8, 0.4], semi_wadcutter: 0.6 };
  const CYL = { pointy: 0.4, rounded: [0.55, 0.65], flat: [0.6, 0.7], semi_wadcutter: 0.78 };

  function rimType(rec) {
    if (rec.family === 'belted' || rec.family === 'rimfire') return rec.family;
    const q = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    return q >= 1.05 ? 'rimmed' : q < 0.98 ? 'rebated' : 'rimless';
  }

  // Points are [r, z]; only used as 2D vectors by the fillet helpers.
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
  const len = (a) => Math.hypot(a[0], a[1]);
  const interior = (A, B, C) => {
    const u1 = sub(A, B), u2 = sub(C, B);
    return Math.acos((u1[0] * u2[0] + u1[1] * u2[1]) / (len(u1) * len(u2)));
  };
  const tangentLength = (A, B, C, r) => r / Math.tan(interior(A, B, C) / 2);

  function fillet(A, B, C, r, n = 10) {
    const u1 = sub(A, B), u2 = sub(C, B);
    const e1 = [u1[0] / len(u1), u1[1] / len(u1)], e2 = [u2[0] / len(u2), u2[1] / len(u2)];
    const th = interior(A, B, C);
    const t = r / Math.tan(th / 2);
    const bis = [e1[0] + e2[0], e1[1] + e2[1]];
    const bl = len(bis);
    const d = r / Math.sin(th / 2);
    const c = [B[0] + (bis[0] / bl) * d, B[1] + (bis[1] / bl) * d];
    const T1 = [B[0] + e1[0] * t, B[1] + e1[1] * t], T2 = [B[0] + e2[0] * t, B[1] + e2[1] * t];
    const a1 = Math.atan2(T1[1] - c[1], T1[0] - c[0]);
    let da = Math.atan2(T2[1] - c[1], T2[0] - c[0]) - a1;
    if (da > Math.PI) da -= 2 * Math.PI;
    if (da < -Math.PI) da += 2 * Math.PI;
    const pts = [];
    for (let i = 0; i <= n; i++) pts.push([c[0] + r * Math.cos(a1 + (da * i) / n), c[1] + r * Math.sin(a1 + (da * i) / n)]);
    return pts;
  }

  function geometry(rec) {
    const c = rec.cartridge;
    const ch = c.caseHead || {}, co = c.collar || {}, jc = c.junctionCone || {}, ln = c.lengths || {}, pc = c.powderChamber || {}, pj = c.projectile || {};
    const ann = rec.annotations || {};
    const { R1, R } = ch, { P1, P2 } = pc, { H1, H2 } = co, { L1, L2, L3, L6 } = ln, { G1 } = pj;
    const core = { R1, R, P1, H2, L3, G1, L6 };
    const lack = Object.keys(core).filter((k) => !num(core[k]));
    if (lack.length) return { error: `Drawing not possible: ${lack.join(', ')} not published`, notes: [] };

    const notes = [];
    const miss = (feature, vals) => {
      const m = Object.keys(vals).filter((k) => !num(vals[k]));
      if (m.length) notes.push(`${feature} not drawn: ${m.join(', ')} not published`);
      return !m.length;
    };
    const rimT = rimType(rec);
    const outer = [[0, 0]];
    const edges = [];
    const add = (p, edge = true) => { outer.push(p); if (edge && p[1] > 0) edges.push(p); };

    // head face and rim edge
    if (rimT === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      const cr = R1 / 2 - rho;
      add([cr, 0]);
      for (let i = 0; i <= 12; i++) {
        const t = -Math.PI / 2 + (Math.PI * i) / 12;
        outer.push([cr + rho * Math.cos(t), rho + rho * Math.sin(t)]);
      }
      if (2 * rho < R - 1e-9) outer.push([cr, R]);
    } else {
      const beta = deg(ch.beta), f = ch.f;
      if (miss('Head chamfer', { β: beta, f }) && beta < 90) {
        add([R1 / 2 - Math.min(f * Math.tan(beta * RAD), R1 / 4), 0]);
        add([R1 / 2, f]);
      } else add([R1 / 2, 0]);
      add([R1 / 2, R]);
    }

    // extractor groove and belt
    const belted = rimT === 'belted';
    const { E, E1, eMin, R3 } = ch;
    const delta = deg(ch.delta);
    const grooveVals = belted ? { E, E1, 'e min': eMin, R3, δ: delta } : { E, E1, 'e min': eMin };
    const groove = rimT === 'rimfire' ? false : miss('Extractor groove', grooveVals);
    let zbs = R, rampEnd = null;
    if (groove) {
      add([E1 / 2, R]);
      add([E1 / 2, R + eMin]);
      if (belted) {
        rampEnd = R + eMin + (R3 - E1) / 2 / Math.tan(delta * RAD);
        add([R3 / 2, rampEnd]);
        add([R3 / 2, E]);
      }
      add([P1 / 2, E]);
      zbs = E;
    } else add([P1 / 2, R]);

    // body, shoulder, neck
    const shoulderVals = { α: deg(jc.alpha), L1, L2, P2, H1 };
    const bottle = [shoulderVals.α, L1, L2].some(num) ? miss('Shoulder', shoulderVals) : false;
    const tangents = [];
    if (bottle) {
      const A = [P1 / 2, zbs], B = [P2 / 2, L1], S = [H1 / 2, L2], N = [H2 / 2, L3];
      const r1 = jc.r1Min, r2 = jc.r2;
      miss('Shoulder rounding', { 'r1 min': r1, r2 });
      const t1 = num(r1) ? tangentLength(A, B, S, r1) : 0;
      const t2 = num(r2) ? tangentLength(B, S, N, r2) : 0;
      const shoulder = len(sub(S, B));
      if (num(r1)) { tangents.push({ length: t1, segment: Math.min(len(sub(B, A)), shoulder - t2) }); fillet(A, B, S, r1).forEach((p) => add(p, false)); } else add(B, false);
      if (num(r2)) { tangents.push({ length: t2, segment: Math.min(len(sub(N, S)), shoulder - t1) }); fillet(B, S, N, r2).forEach((p) => add(p, false)); } else add(S, false);
      edges.push(B, S);
      outer.push(N);
    } else outer.push([H2 / 2, L3]);

    // walls and head
    const heeled = H2 - G1 <= 0.015;
    const tn = (H2 - G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * P1) / 2);
    const wn = heeled ? tb : tn;
    const pocket = rimT === 'rimfire' ? null : POCKETS[ann.primerType] ? { ...POCKETS[ann.primerType] } : null;
    if (rimT !== 'rimfire' && !pocket) notes.push('Primer pocket not drawn: primer type not published');
    const w = Math.max(2.5, (0.25 * P1) / 2, pocket ? pocket.h + 1.5 : 0, groove ? (belted ? rampEnd : E) + tb : 0);
    const endR = bottle ? P2 / 2 : H2 / 2, endZ = bottle ? L1 : L3;
    const bodyR = (z) => P1 / 2 + ((endR - P1 / 2) * (z - zbs)) / (endZ - zbs);
    const inner = [[bodyR(w) - tb, w]];
    if (bottle) inner.push([P2 / 2 - tb, L1], [H1 / 2 - wn, L2]);
    inner.push([H2 / 2 - wn, L3]);

    // bullet
    const shape = ann.defaultBulletShape;
    const pistol = ann.category === 'pistol';
    const pick = (v) => (Array.isArray(v) ? v[pistol ? 1 : 0] : v);
    let bullet = null;
    if (shape in SEAT) {
      const s = G1 * (shape === 'rounded' || shape === 'flat' ? (pistol ? 0.4 : 0.8) : pick(SEAT[shape]));
      const k = pick(CYL[shape]);
      const m = { pointy: Math.max(0.08 * G1, 1.27), rounded: 0.15 * G1, flat: 0.55 * G1, semi_wadcutter: 0.6 * G1 }[shape];
      const zb = L3 - s, Lb = L6 - zb, zc = zb + k * Lb, n = L6 - zc;
      const Rexp = heeled ? H2 / 2 : G1 / 2, Rseat = heeled ? H2 / 2 - tb : G1 / 2, mr = m / 2;
      const nose = [];
      let rho = null;
      if (shape === 'pointy') {
        const d = Rexp - mr;
        rho = (d * d + n * n) / (2 * d);
        const phi1 = Math.asin(n / rho);
        for (let i = 0; i < 24; i++) nose.push([Rexp - rho + rho * Math.cos((phi1 * i) / 24), zc + rho * Math.sin((phi1 * i) / 24)]);
      } else if (shape === 'rounded') {
        for (let i = 0; i < 16; i++) nose.push([mr + (Rexp - mr) * Math.cos((Math.PI / 2 * i) / 16), zc + n * Math.sin((Math.PI / 2 * i) / 16)]);
      } else nose.push([Rexp, zc]);
      nose.push([mr, L6]);
      const section = [[0, zb], [Rseat, zb], [Rseat, L3]];
      if (Rexp !== Rseat) section.push([Rexp, L3]);
      section.push(...nose, [0, L6]);
      bullet = { s, k, m, zb, Lb, zc, rho, Rexp, Rseat, nose, exposed: [[Rexp, L3], ...nose, [0, L6]], section };
    } else notes.push('Bullet not drawn: default bullet shape not published');

    return { rimType: rimT, outer, edges, notes, bottle, heeled, tn, tb, wn, w, pocket, inner, bullet, tangents, rampEnd, zbs, groove, belted };
  }


  const FS = 3.2; // label font size, user units (mm)
  const CW = 0.62 * FS; // estimated glyph width
  const PRINT_W = 190; // printed drawing width, mm
  const MIN_W = 100;
  const esc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const f3 = (n) => +n.toFixed(3);

  function buildDrawing(rec) {
    const g = geometry(rec);
    if (g.error) return { error: g.error, notes: [], svg: '', labels: [], outline: [], lines: [], viewBox: null };
    const c = rec.cartridge;
    const ch = c.caseHead, co = c.collar, ln = c.lengths, pc = c.powderChamber, pj = c.projectile;
    const { R1, R, E1 } = ch, { P1, P2 } = pc, { H1, H2 } = co, { L1, L2, L3, L6 } = ln, { G1 } = pj;
    const b = g.bullet;
    const notes = g.notes.slice();

    const box = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    const grow = (x, y) => { box.x0 = Math.min(box.x0, x); box.x1 = Math.max(box.x1, x); box.y0 = Math.min(box.y0, y); box.y1 = Math.max(box.y1, y); };
    const parts = [], labels = [], outline = [], lines = [];
    const up = (p) => [p[1], -p[0]], dn = (p) => [p[1], p[0]]; // [r, z] -> [x, y]
    const d = (pts) => 'M' + pts.map((p) => f3(p[0]) + ' ' + f3(p[1])).join('L');
    const path = (pts, cls, extra = '') => { pts.forEach((p) => grow(p[0], p[1])); parts.push('<path class="' + cls + '" d="' + d(pts) + '"' + extra + '/>'); };
    const strokeOutline = (pts, cls = 'o') => { outline.push(pts); path(pts, cls); };
    const line = (x1, y1, x2, y2, cls, extra = '') => {
      grow(x1, y1); grow(x2, y2); lines.push([[x1, y1], [x2, y2]]);
      parts.push('<line class="' + cls + '" x1="' + f3(x1) + '" y1="' + f3(y1) + '" x2="' + f3(x2) + '" y2="' + f3(y2) + '"' + extra + '/>');
    };
    const text = (str, x, y, o = {}) => {
      const w = str.length * CW, a = 0.75 * FS, de = 0.3 * FS;
      let bx;
      if (o.rot) bx = { x0: x - a, x1: x + de, y0: y - w, y1: y };
      else {
        const x0 = o.anchor === 'middle' ? x - w / 2 : x;
        bx = { x0, x1: x0 + w, y0: y - a, y1: y + de };
      }
      grow(bx.x0, bx.y0); grow(bx.x1, bx.y1);
      if (!o.skipLabel) labels.push({ text: str, ...bx });
      parts.push('<text' + (o.cls ? ' class="' + o.cls + '"' : '') + ' x="' + f3(x) + '" y="' + f3(y) + '"' + (o.anchor === 'middle' ? ' text-anchor="middle"' : '') + (o.rot ? ' transform="rotate(-90 ' + f3(x) + ' ' + f3(y) + ')"' : '') + '>' + esc(str) + '</text>');
    };

    // section (lower half): wall and head region
    const innerRev = g.inner.slice().reverse();
    const tail = g.pocket ? [[0, g.w], [0, g.pocket.h], [g.pocket.d / 2, g.pocket.h]] : [[0, g.w]];
    const secPts = (g.pocket ? [[g.pocket.d / 2, 0], ...g.outer.slice(1)] : g.outer).concat(innerRev, tail).map(dn);
    secPts.forEach((p) => grow(p[0], p[1]));
    parts.push('<path class="cut" d="' + d(secPts) + 'Z"/>');
    if (b) parts.push('<path class="bul" d="' + d(b.section.map(dn)) + 'Z"/>');

    // outlines
    strokeOutline(g.outer.map(up));
    strokeOutline(g.outer.map(dn));
    strokeOutline([dn([g.outer[g.outer.length - 1][0], L3])].concat(innerRev.map(dn), [dn([0, g.w])]));
    if (g.pocket) strokeOutline([dn([g.pocket.d / 2, 0]), dn([g.pocket.d / 2, g.pocket.h]), dn([0, g.pocket.h])]);
    const mouthR = g.outer[g.outer.length - 1][0];
    if (b) {
      if (b.Rexp !== mouthR) { strokeOutline([up([mouthR, L3]), up([b.Rexp, L3])]); strokeOutline([dn([mouthR, L3]), dn([b.Rexp, L3])]); }
      strokeOutline(b.exposed.map(up));
      strokeOutline(b.section.map(dn));
      if (b.zc > L3) g.edges.push([b.Rexp, b.zc]);
    }
    for (const [r, z] of g.edges) { const a = up([r, z]); line(a[0], a[1], z, 0, 'e'); outline.push([a, [z, 0]]); lines.pop(); }

    // centre line
    line(-3.5, 0, L6 + 3.5, 0, 'cl');
    lines.pop();

    // dimensions
    const RM = Math.max(...g.outer.map((p) => p[0]), b ? b.Rexp : 0);
    const ytop = -(RM + 3.5);
    const arrow = ' marker-start="url(#arr)" marker-end="url(#arr)"';
    const val = (s, v) => s + ' ' + (s === 'α' ? Fmt.formatAngle(v) : v);

    // lengths below the section, shortest nearest
    const rows = [[L1, 'L1', P2 / 2], [L2, 'L2', (H1 || 0) / 2], [L3, 'L3', H2 / 2], [L6, 'L6', b ? b.m / 2 : 0]]
      .filter((x) => typeof x[0] === 'number').sort((p, q) => p[0] - q[0]);
    const rowY = (i) => RM + 5 + 5.4 * i;
    const lastY = rowY(rows.length - 1);
    line(0, R1 / 2 + 0.8, 0, lastY + 1.2, 'x');
    rows.forEach(([z, sym, r], i) => {
      const y = rowY(i);
      if (z > 0) line(z, r + 0.8, z, y + 1.2, 'x');
      line(0, y, z, y, 'dm', arrow);
      const lab = val(sym, z);
      // below the line; left-aligned past the zero extension line when it is wider than the dimension
      if (lab.length * CW > z - 2) text(lab, 1, y + 1.6 + 0.75 * FS);
      else text(lab, z / 2, y + 1.6 + 0.75 * FS, { anchor: 'middle' });
    });

    // rim thickness above the rim, arrows outside
    const ry = -(R1 / 2 + 4.5);
    line(0, -R1 / 2 - 0.8, 0, ry - 1.2, 'x');
    line(R, -R1 / 2 - 0.8, R, ry - 1.2, 'x');
    line(-4, ry, 0, ry, 'dm', ' marker-end="url(#arr)"');
    line(R + 4, ry, R, ry, 'dm', ' marker-end="url(#arr)"');
    text(val('R', R), R + 5, ry + 0.35 * FS);

    // diameters in columns: vertical dimension line with extension lines, label above the lines
    const column = (x, dia, sym, zFeat, dir) => {
      const r = dia / 2;
      line(zFeat - dir * 0.8, -r, x - dir * 1.2, -r, 'x');
      line(zFeat - dir * 0.8, r, x - dir * 1.2, r, 'x');
      line(x, -r, x, r, 'dm', arrow);
      line(x, ytop, x, -r - 1.6, 'dm');
      text(val(sym, dia), x + 0.28 * FS, ytop - 0.8, { rot: true });
    };
    const left = [[E1, 'E1', R]].filter((x) => typeof x[0] === 'number').concat([[R1, 'R1', 0]]).sort((p, q) => p[0] - q[0]);
    left.forEach(([dia, sym, zf], i) => column(-7 - 7 * i, dia, sym, zf, 1));
    const right = [[G1, 'G1', b ? b.zc : L3], [H1, 'H1', L2], [H2, 'H2', L3], [P2, 'P2', L1], [P1, 'P1', g.zbs]]
      .filter((x) => typeof x[0] === 'number').sort((p, q) => p[0] - q[0]);
    right.forEach(([dia, sym, zf], i) => column(L6 + 6 + 6.5 * i, dia, sym, zf, -1));

    // shoulder angle: arc at the body-side corner marks alpha/2
    if (g.bottle) {
      const alpha = c.junctionCone.alpha, half = (Number(typeof alpha === 'object' ? alpha.degrees + alpha.minutes / 60 + alpha.seconds / 3600 : alpha) / 2) * RAD;
      const Bx = L1, By = -P2 / 2;
      const ra = 0.7 * Math.hypot(L2 - L1, (P2 - H1) / 2);
      line(Bx, By, Bx + ra + 3, By, 'cn');
      const arc = [];
      for (let i = 0; i <= 12; i++) arc.push([Bx + ra * Math.cos((half * i) / 12), By + ra * Math.sin((half * i) / 12)]);
      path(arc, 'dm');
      const ly = -P1 / 2 - 1.6;
      const mid = [Bx + ra * Math.cos(half / 2), By + ra * Math.sin(half / 2)];
      line(mid[0], mid[1], mid[0], ly - 0.3 * FS, 'dm');
      text(val('α', alpha), mid[0] + 1.2, ly);
      notes.push('α is the included cone angle; the arc marks α/2 against the axis.');
    }

    // title block
    const cells = [[rec.name, 'C.I.P. Table ' + rec.tab + '  Rev. ' + rec.revised], ['Dimensions in mm', 'Scale 0.00:1']];
    const c0 = Math.max(...cells.map((r) => r[0].length)) * CW + 4, c1 = Math.max(...cells.map((r) => r[1].length)) * CW + 4;
    const tx = box.x0 + 1, ty = box.y1 + 3.5, th = 2 * 5 + 1.5;
    grow(tx, ty); grow(tx + c0 + c1, ty + th);
    parts.push('<rect class="tb" x="' + f3(tx) + '" y="' + f3(ty) + '" width="' + f3(c0 + c1) + '" height="' + f3(th) + '"/>');
    cells.forEach((row, i) => {
      const y = ty + 5 * (i + 1) - 0.4;
      text(row[0], tx + 2, y, { cls: i === 0 ? 'tbn' : '' });
      if (row[1].startsWith('Scale')) { text(row[1], tx + c0 + 2, y, { cls: 'scale-print' }); text('Scale', tx + c0 + 2, y, { cls: 'scale-screen', skipLabel: true }); } else text(row[1], tx + c0 + 2, y);
    });

    const M = 2;
    // minimum width keeps the printed scale (and so the printed height) of small cartridges in range
    const w0 = box.x1 - box.x0 + 2 * M, w = Math.max(w0, MIN_W);
    const vb = { x: f3(box.x0 - M - (w - w0) / 2), y: f3(box.y0 - M), w: f3(w), h: f3(box.y1 - box.y0 + 2 * M) };
    const printScale = 'Scale ' + (PRINT_W / vb.w).toFixed(2) + ':1';
    parts.forEach((p, i) => { parts[i] = p.replace('Scale 0.00:1', printScale); });
    labels.forEach((l) => { if (l.text === 'Scale 0.00:1') l.text = printScale; });
    const svg =
      '<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="' + [vb.x, vb.y, vb.w, vb.h].join(' ') + '" role="img" aria-label="' + esc(rec.name) + ' drawing" data-vbw="' + vb.w + '">' +
      '<defs><marker id="arr" viewBox="0 0 10 6" refX="10" refY="3" markerWidth="2.2" markerHeight="1.32" markerUnits="userSpaceOnUse" orient="auto-start-reverse"><path class="arrow" d="M0 0L10 3L0 6z"/></marker>' +
      '<pattern id="hatch" width="1.2" height="1.2" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line class="hatch" x1="0" y1="0" x2="0" y2="1.2"/></pattern></defs>' +
      parts.join('') + '</svg>';
    return { svg, notes, labels, outline, lines, viewBox: vb, geometry: g };
  }

  const api = { rimType, geometry, buildDrawing };
  return api;
})();
if (typeof module !== 'undefined') module.exports = Drawing;
