const Format = (() => {
  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const SECTIONS = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Misc', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };

  const symbol = (f) => SYMBOLS[f] || f;
  const unit = (f) => (ANGLES.has(f) ? 'deg' : f in UNITS ? UNITS[f] : 'mm');
  const formatAngle = (a) => (typeof a === 'number' ? `${a}°` : `${a.degrees}°${a.minutes}'${a.seconds}"`);
  const value = (f, v, tol) => {
    const s = ANGLES.has(f) ? formatAngle(v) : String(v);
    return tol === undefined ? s : `${s} ${tol > 0 ? '+' : ''}${tol}`;
  };

  function buildTables(rec) {
    return [['cartridge', 'Cartridge'], ['chamber', 'Chamber']].map(([key, title]) => ({
      title,
      sections: Object.entries(rec[key])
        .map(([name, fields]) => ({
          title: SECTIONS[name] || name,
          rows: Object.keys(fields)
            .filter((f) => !f.endsWith('Tol'))
            .map((f) => ({ symbol: symbol(f), value: value(f, fields[f], fields[f + 'Tol']), unit: unit(f) })),
        }))
        .filter((s) => s.rows.length),
    }));
  }

  function attributes(rec) {
    const cap = rec.annotations.publishedCapacity;
    return [
      rec.alternativeNames && { label: 'Alternative names', value: rec.alternativeNames.join(', ') },
      { label: 'Family', value: rec.family },
      { label: 'Category', value: rec.annotations.category },
      { label: 'Primer type', value: rec.annotations.primerType },
      { label: 'C.I.P. table', value: rec.tab },
      { label: 'Country', value: rec.country },
      { label: 'Published', value: rec.published },
      { label: 'Revised', value: rec.revised },
      { label: 'Pressure method', value: rec.pressureMethod },
      cap && { label: 'Water capacity', value: `${cap.grH2O} grH2O`, link: { text: cap.source, href: cap.url } },
    ].filter(Boolean);
  }

  function filterCartridges(list, query, family) {
    const q = query.trim().toLowerCase();
    return list.filter(
      (r) =>
        (family === 'All' || r.family === family) &&
        [r.name, ...(r.alternativeNames || [])].some((n) => n.toLowerCase().includes(q))
    );
  }

  return { symbol, unit, formatAngle, buildTables, attributes, filterCartridges };
})();
if (typeof module !== 'undefined') module.exports = Format;
