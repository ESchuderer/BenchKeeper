# Design

## Context

Empty repository, Node.js 22, Chromium available for browser checks. The app must open from `file://`, so no ES modules and no `fetch`; data is embedded in a classic script. See proposal.md for motivation and the specs for behavior.

## Goals / Non-Goals

**Goals:**
- Pure functions for formatting, filtering and geometry, testable in Node without a DOM.
- One drawing builder returning SVG text plus structured labels and outline segments for overlap tests.

**Non-Goals:**
- Fetching, editing or extending data; units conversion; i18n; PWA or caching.

## Decisions

- **Files:** `index.html`, `style.css`, `data.js` (`CARTRIDGES` array, records unchanged), `format.js`, `drawing.js`, `app.js`. Each logic file is a classic script that also sets `module.exports` when `module` exists, so `node --test` loads it. Alternative (ES modules) fails on `file://`.
- **Routing:** hash addresses (`#/<key>`, start page `#/` or empty). Works on `file://` and static servers, survives reload. Both views stay in the DOM and toggle `hidden`, so Search and Family persist when returning to the list.
- **Rendering:** DOM built with template strings and one `esc()` for all record text (names contain `&`). No framework.
- **Drawing coordinates:** profiles are arrays of `[r, z]`; mapping to SVG is `x = ox + z`, `y = oy -/+ r`. Arcs (fillets, ogive, ellipse, half-round) are sampled polylines, so mirroring, clipping and overlap tests need no arc flags.
- **Fillets:** tangent arcs at the shoulder corners. A test asserts that the tangent lengths of all 25 records fit their segments, so no clamp is coded.
- **Straight-case inner wall:** a case without shoulder has no neck; the inner wall blends linearly from `tb` at `z = w` to `tn` at the mouth so the wall at the mouth matches the seated bullet (diameter G1); the bullet base may overlap the interpolated wall by under 0.1 mm. Heeled cases use `tb` everywhere.
- **Inner line near the head:** the inner line starts at `z = w` on the body line extended to `w` (needed on belted cases where `w` lies inside the belt).
- **Shoulder angle mark:** α is the included angle; the apex lies inside the bullet, so an arc at the body-side shoulder corner marks α/2 against a dashed axis-parallel line, labelled "α <value>", with a note stating this.
- **Dimension layout:** lengths (L1, L2, L3, L6) as rows below the section, shortest nearest; diameters as vertical dimension lines in columns, E1 and R1 left of the head, G1/H1/H2/P2/P1 right of the tip, smaller diameters nearest; R above the rim. Column labels are rotated and sit above all extension lines, so lines never cross labels. Label boxes use an estimated glyph width (0.62 em) for the Node overlap test and are checked again with `getBBox` in the browser.
- **Scale text:** the title block holds two texts; print shows `190 mm / viewBox width`, screen shows the measured displayed scale updated on resize.
- **Print:** `@page` A4 portrait, 10 mm margins, drawing 190 mm wide, tables in three CSS columns, forced light colours.
- **Required values:** R1, R, P1, H2, L3, G1 and L6 are needed for the outline, walls and bullet; if one is missing the drawing is replaced by a message naming it (all 25 records have them). Other missing values drop only their feature and are listed in notes.
- **Tests:** `node --test` for pure functions and all 25 records; browser checks with Playwright MCP against `file://`.

## Risks / Trade-offs

- Estimated text widths differ from real fonts → margins of 15 percent and a browser `getBBox` check.
- Tangent-ogive and seating rules are fixed by the brief; shapes for other bullets are not modelled.
- Rotated labels are less readable than horizontal ones → they are used only for the column dimensions.
