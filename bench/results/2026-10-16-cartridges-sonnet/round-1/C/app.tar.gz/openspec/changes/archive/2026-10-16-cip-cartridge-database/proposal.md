# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick offline reference for C.I.P. cartridge and chamber dimensions, with a dimensioned drawing, modelled on the OpenBallistics cartridge database. Data for 25 cartridges is supplied with the brief.

## What Changes

- Static web app (`index.html`, CSS, JS) listing 25 cartridges with search and family filter.
- Detail view per cartridge with a stable address, attribute list, grouped value tables, a scaled SVG drawing and print layout.
- Drawing computed from the record values by fixed geometry rules; missing values omit features and are reported.
- Works from `file://` and any static file server; no framework, build step, server code, runtime dependency or network request.

## Capabilities

### New Capabilities
- `cartridge-browser`: start page list, search, family filter, count, links to detail views.
- `cartridge-detail`: detail view content, value formatting (units, tolerances, angles, symbols), addressable routes, print layout, themes.
- `cartridge-drawing`: SVG drawing of case, bullet, section, dimensions and title block computed from record values.

### Modified Capabilities

## Impact

- New files in the project root: `index.html`, `style.css`, scripts, data file, tests; `package.json` with dev-only scripts.
- No external dependencies or services.
