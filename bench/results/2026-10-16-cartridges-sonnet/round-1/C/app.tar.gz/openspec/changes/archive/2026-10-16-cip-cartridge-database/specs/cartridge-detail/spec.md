# Spec Delta

## Purpose

Presents all published values of one cartridge and its chamber as a printable technical reference with consistent units, tolerances and angles.

## ADDED Requirements

### Requirement: Detail header and attributes
The detail view SHALL show the cartridge name as heading, then alternative names, family, category, primer type, C.I.P. table, country, published and revised dates, pressure method, and the published water capacity with its source link.

#### Scenario: Capacity link
- **WHEN** the record has `publishedCapacity`
- **THEN** its value in grH2O is shown with a link to its source URL

#### Scenario: No capacity
- **WHEN** the record has no `publishedCapacity` (for example "7 x 64")
- **THEN** no capacity entry is shown

### Requirement: Value tables
The detail view SHALL show all cartridge values and all chamber values in tables grouped by section, with columns "Symbol", "Value" and "Unit".

#### Scenario: Grouped sections
- **WHEN** the detail view of "308 Win." is shown
- **THEN** a cartridge table and a chamber table exist, each with sections such as lengths and pressures
- **AND** the lengths row for L3 reads symbol "L3", value "51.18", unit "mm"

### Requirement: Value formatting
Values SHALL be shown as published with a decimal point and no thousands separator; lengths and diameters in mm, Pmax, PK and PE in bar, EE in J, M in g, Q in mm2, N without unit. A `<X>Tol` field SHALL be shown next to the value of X and never as a row of its own.

#### Scenario: Tolerance
- **WHEN** L1 is 39.62 with L1Tol -0.2
- **THEN** the L1 value reads "39.62 -0.2"
- **AND** no row "L1Tol" exists

#### Scenario: Pressure
- **WHEN** Pmax is 4150
- **THEN** the row reads "Pmax", "4150", "bar"

### Requirement: Angles
An angle SHALL be shown as degrees, or as degrees, minutes and seconds when the record gives an object.

#### Scenario: Plain and composed angles
- **WHEN** alpha is 40 the value reads `40°`
- **WHEN** alpha is `{degrees: 39, minutes: 59, seconds: 49}` the value reads `39°59'49"`

### Requirement: Symbols
Symbols SHALL be the field name, except eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L", L3PlusG "L3 + G".

#### Scenario: Greek symbols
- **WHEN** the shoulder angle row is shown
- **THEN** its symbol is "α"

### Requirement: Navigation and print button
The detail view SHALL have a "Print" button that opens the print dialog and a link "All cartridges" to the list.

#### Scenario: Back link
- **WHEN** the user follows "All cartridges"
- **THEN** the start page is shown

### Requirement: Print layout
A printed detail view SHALL be one A4 portrait page, black on white: page header with the name, the drawing at full width, then the tables, without navigation, search or buttons, and a footer with the source "C.I.P. TDCC" and the revised date.

#### Scenario: Print media
- **WHEN** the detail view is rendered for print
- **THEN** navigation and buttons are hidden, colours are light, and the page fits one A4 page

### Requirement: Appearance
The interface SHALL be English, dense, with tabular numbers, light and dark following the system setting on screen, always light in print, and usable at phone width.

#### Scenario: Dark system
- **WHEN** the system prefers dark
- **THEN** screen colours are dark and print colours remain light

### Requirement: Offline static delivery
The app SHALL need no framework, build step, server code, runtime dependency or network request, and SHALL work when `index.html` is opened from disk in Chromium and when served by a static file server.

#### Scenario: file origin
- **WHEN** `index.html` is opened via `file://`
- **THEN** the list, detail views and drawings work and no network request is made
