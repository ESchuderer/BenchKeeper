# Spec Delta

## Purpose

Draws each cartridge as a scaled, dimensioned SVG with an outside view and a section, computed only from the record's values.

## ADDED Requirements

### Requirement: Drawing element
The detail view SHALL contain an inline SVG named "<name> drawing" where 1 SVG user unit is 1 mm, the axis is horizontal and the head is on the left.

#### Scenario: Accessible name
- **WHEN** the detail view of "308 Win." is shown
- **THEN** an element with role img and accessible name "308 Win. drawing" exists

#### Scenario: Phone width
- **WHEN** the viewport is 360 px wide
- **THEN** the drawing fits the width without horizontal scrolling

### Requirement: Views and centre line
The upper half SHALL be the outside view and the lower half a section with cut walls hatched; a dash-dot centre line SHALL mark the axis.

#### Scenario: Hatched walls
- **WHEN** any drawing is shown
- **THEN** the lower half contains a hatched wall and head region and the upper half has no hatching

### Requirement: Case outline
The case outline SHALL be built from the rim type, head face, extractor groove, body, shoulder, neck and mouth rules, mirrored at the axis; rim type is belted for family belted, rimfire for family rimfire, otherwise rimmed for R1/P1 >= 1.05, rebated for R1/P1 < 0.98, else rimless.

#### Scenario: Rim types
- **WHEN** R1/P1 is 1.12 ("9,3 x 74 R")
- **THEN** the rim type is rimmed
- **WHEN** R1/P1 is 1.002 ("223 Rem.")
- **THEN** the rim type is rimless

#### Scenario: Bottleneck shoulder
- **WHEN** alpha, L1 and L2 are published
- **THEN** the outline passes through (P2/2, L1) and (H1/2, L2), rounded with r1 min and r2 where published

#### Scenario: Straight case
- **WHEN** alpha, L1 or L2 is missing
- **THEN** the body runs straight to (H2/2, L3)

### Requirement: Bullet
The bullet SHALL be drawn from the mouth to the tip at L6 with shank diameter G1, seating depth, cylinder length, nose shape and meplat from `defaultBulletShape`, a heeled bullet having the case's outside diameter outside and the case's inside diameter seated; the outside view hides the seated part and the section shows it.

#### Scenario: Pointy bullet
- **WHEN** the shape is pointy and G1 is 7.85, L3 51.18, L6 71.12
- **THEN** the bullet base is at z = 43.33 and the meplat diameter is 1.27

#### Scenario: Heeled bullet
- **WHEN** H2 - G1 <= 0.015 ("22 Long Rifle")
- **THEN** the exposed bullet has diameter H2 and the seated heel has diameter H2 - 2·tb

### Requirement: Section walls
The section SHALL show walls tn = (H2 - G1)/2 and tb = min(max(1.3·tn, 0.6), 0.35·P1/2), a solid head to z = w and, on centrefire cases, a primer pocket sized by primer type.

#### Scenario: Primer pocket
- **WHEN** the primer type is sr
- **THEN** the pocket is 4.45 mm in diameter and 3.04 mm deep
- **WHEN** the primer type is rimfire
- **THEN** no pocket is drawn

### Requirement: Dimensions
The drawing SHALL show dimension lines with arrowheads and extension lines labelled with symbol and value (for example `L3 51.18`) for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α.

#### Scenario: Labels
- **WHEN** the drawing of "308 Win." is shown
- **THEN** its text includes `L3 51.18`, `L6 71.12`, `R1 12.01`, `R 1.37`, `P1 11.96`, `α 40°`

#### Scenario: No overlap
- **WHEN** any of the 25 drawings is shown
- **THEN** no label overlaps another label or the outline

### Requirement: Missing values
If a value a rule needs is missing, the drawing SHALL omit that feature and name the missing value in a note; no number SHALL be invented.

#### Scenario: Missing radii
- **WHEN** r1 min and r2 are not published ("17 HMR")
- **THEN** the shoulder is not rounded and a note names r1 min and r2

### Requirement: Title block and scale
The drawing SHALL carry a title block with the name, C.I.P. table, revision date, "Dimensions in mm" and the scale.

#### Scenario: Title block text
- **WHEN** the drawing of "223 Rem." is shown
- **THEN** the title block contains "223 Rem.", "Table I", "2017-05-17", "Dimensions in mm" and a scale

### Requirement: Legible print
The drawing SHALL print at full page width with all labels legible.

#### Scenario: Print size
- **WHEN** a detail view is printed on A4 portrait
- **THEN** the drawing is 190 mm wide and label text is at least 3 mm high
