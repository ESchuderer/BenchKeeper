# Tasks

## 1. Project and data

- [x] 1.1 Create `package.json` (scripts `test`, no dependencies) and `data.js` with the 25 records unchanged; verify with a test that 25 records load, keys are unique and the `jsonl` source count matches.

## 2. Formatting and filtering

- [x] 2.1 Write failing tests, then `format.js`: angle display, symbols, units, tolerance merge, section tables, attributes, search and family filter; verify `npm test` passes (308 Win. L3 row, `39.62 -0.2`, `39°59'49"`, `7,62 x 51` finds 308 Win.).

## 3. Drawing geometry

- [x] 3.1 Write failing tests, then rim type, outer profile, groove, belt, shoulder fillets in `drawing.js`; verify profile points for 223 Rem., 300 Win. Mag. and 22 Long Rifle.
- [x] 3.2 Add bullet geometry, heeled case, walls, head, primer pocket; verify seating, cylinder and meplat values and that every record produces a profile.
- [x] 3.3 Add dimensions, labels, title block, notes for missing values, SVG output; verify labels for 308 Win., no label overlap for all 25 records and notes for 17 HMR.

## 4. Pages

- [x] 4.1 Build `index.html`, `style.css`, `app.js`: list, search, family, count, hash routing, detail view, print button; verify in Chromium over `file://` and a static server.
- [x] 4.2 Add theme, phone and print styles; verify in a browser at 360 px, dark scheme, and print to one A4 page for the largest record.

## 5. Integration

- [x] 5.1 Check all 25 detail views in the browser for console errors, network requests (none) and label overlap with `getBBox`; verify `npm test` passes.

## Workflow follow-up

- Review the branch before merge, then archive the change with `openspec-archive-change`.
