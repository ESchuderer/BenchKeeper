# cartridge-browser Specification

## Purpose
Lets users find a cartridge in the list of 25 C.I.P. cartridges by name, alternative name or family and open its detail view.

## Requirements

### Requirement: Cartridge list
The start page SHALL show the heading "Cartridges" and every cartridge with its name, family and case length L3, the name being a link whose text is exactly the record's `name`.

#### Scenario: Initial list
- **WHEN** the start page opens
- **THEN** 25 links are shown, one per record, with texts such as "6,5 Creedmoor" and "22 Long Rifle"
- **AND** the text "25 cartridges" is shown

### Requirement: Search
A field labelled "Search" SHALL filter the list by name and alternative names as the user types, ignoring case.

#### Scenario: Alternative name
- **WHEN** the user types "7,62 x 51" into Search
- **THEN** the list contains "308 Win." and "25 cartridges" becomes "1 cartridges"

#### Scenario: No match
- **WHEN** the user types a text that matches no name
- **THEN** no cartridge is listed and the count reads "0 cartridges"

### Requirement: Family filter
A select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire SHALL filter the list by family, combined with Search.

#### Scenario: Select family
- **WHEN** the user selects "belted"
- **THEN** only "300 Win. Mag." and "7 mm Rem. Mag." are listed

### Requirement: Addressable views
Each detail view SHALL have its own address that survives a reload; the start page SHALL be the address without a cartridge.

#### Scenario: Reload detail
- **WHEN** the user opens a detail view and reloads the page
- **THEN** the same detail view is shown

#### Scenario: Unknown address
- **WHEN** the address names a cartridge that does not exist
- **THEN** a "not found" message with a link to the list is shown
