const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../data.js');

test('25 records with unique keys and names', () => {
  assert.equal(data.length, 25);
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
  assert.equal(new Set(data.map((r) => r.name)).size, 25);
});

test('families are the five published ones', () => {
  const fams = new Set(data.map((r) => r.family));
  assert.deepEqual([...fams].sort(), ['belted', 'pistol', 'rimfire', 'rimless', 'rimmed']);
});
