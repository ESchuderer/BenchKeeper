const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../data.js');
const D = require('../drawing.js');

const rec = (key) => data.find((r) => r.key === key);
const texts = (d) => d.labels.map((l) => l.text);

const REQUIRED = (r) => {
  const c = r.cartridge;
  const out = [`L3 ${c.lengths.L3}`, `L6 ${c.lengths.L6}`, `R1 ${c.caseHead.R1}`, `R ${c.caseHead.R}`, `P1 ${c.powderChamber.P1}`];
  const opt = [['P2', c.powderChamber.P2], ['H1', (c.collar || {}).H1], ['H2', c.collar.H2], ['G1', c.projectile.G1], ['L1', c.lengths.L1], ['L2', c.lengths.L2], ['E1', c.caseHead.E1]];
  for (const [s, v] of opt) if (v !== undefined) out.push(`${s} ${v}`);
  return out;
};

test('308 Win. labels', () => {
  const t = texts(D.buildDrawing(rec('308_win')));
  for (const s of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) assert.ok(t.includes(s), s);
});

test('shoulder angle label uses degrees, minutes and seconds', () => {
  assert.ok(texts(D.buildDrawing(rec('338_lapua_mag'))).includes('α 39°59\'49"'));
});

test('every record: required labels where published', () => {
  for (const r of data) {
    const t = texts(D.buildDrawing(r));
    for (const s of REQUIRED(r)) assert.ok(t.includes(s), `${r.key}: ${s}`);
    if ((r.cartridge.junctionCone || {}).alpha !== undefined) assert.ok(t.some((x) => x.startsWith('α ')), r.key);
  }
});

const rectHitsSeg = (b, [x1, y1], [x2, y2]) => {
  const n = Math.max(2, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 0.05));
  for (let i = 0; i <= n; i++) {
    const x = x1 + ((x2 - x1) * i) / n, y = y1 + ((y2 - y1) * i) / n;
    if (x >= b.x0 && x <= b.x1 && y >= b.y0 && y <= b.y1) return true;
  }
  return false;
};

test('every record: no label overlaps another label, the outline or a dimension line', () => {
  for (const r of data) {
    const d = D.buildDrawing(r);
    const L = d.labels;
    for (let i = 0; i < L.length; i++) {
      for (let j = i + 1; j < L.length; j++) {
        const a = L[i], b = L[j];
        assert.ok(a.x1 <= b.x0 || b.x1 <= a.x0 || a.y1 <= b.y0 || b.y1 <= a.y0, `${r.key}: "${a.text}" overlaps "${b.text}"`);
      }
      for (const poly of d.outline) for (let k = 1; k < poly.length; k++) assert.ok(!rectHitsSeg(L[i], poly[k - 1], poly[k]), `${r.key}: "${L[i].text}" touches the outline`);
      for (const seg of d.lines) assert.ok(!rectHitsSeg(L[i], seg[0], seg[1]), `${r.key}: "${L[i].text}" touches a dimension line`);
      const v = d.viewBox;
      assert.ok(L[i].x0 >= v.x && L[i].x1 <= v.x + v.w && L[i].y0 >= v.y && L[i].y1 <= v.y + v.h, `${r.key}: "${L[i].text}" outside viewBox`);
    }
  }
});

test('svg: accessible name, units, scale, title block, escaping', () => {
  const d = D.buildDrawing(rec('223_rem'));
  assert.match(d.svg, /^<svg [^>]*role="img"/);
  assert.match(d.svg, /aria-label="223 Rem\. drawing"/);
  for (const s of ['223 Rem.', 'Table I', '2017-05-17', 'Dimensions in mm']) assert.ok(texts(d).some((t) => t.includes(s)), s);
  assert.match(d.svg, /Scale \d+\.\d\d:1/);
  assert.match(D.buildDrawing(rec('40_s_w')).svg, /aria-label="40 S\.&amp; W\. drawing"/);
});

test('svg is balanced and 1 unit = 1 mm: viewBox width exceeds L6', () => {
  for (const r of data) {
    const d = D.buildDrawing(r);
    const open = (d.svg.match(/<(?!\/|!)[a-zA-Z]+[^>]*[^/]>/g) || []).length;
    const close = (d.svg.match(/<\/[a-zA-Z]+>/g) || []).length;
    const selfc = (d.svg.match(/<[a-zA-Z]+[^>]*\/>/g) || []).length;
    assert.ok(open === close, `${r.key} open ${open} close ${close} self ${selfc}`);
    assert.ok(d.viewBox.w > r.cartridge.lengths.L6, r.key);
  }
});

test('notes: 17 HMR names r1 min and r2; 38 Special names the groove values; α note when drawn', () => {
  assert.ok(D.buildDrawing(rec('17_hmr')).notes.some((n) => /r1 min/.test(n) && /r2/.test(n)));
  assert.ok(D.buildDrawing(rec('38_special')).notes.some((n) => /E1/.test(n)));
  assert.ok(D.buildDrawing(rec('308_win')).notes.some((n) => /α/.test(n)));
  assert.ok(!D.buildDrawing(rec('9_mm_luger')).notes.some((n) => /α/.test(n)));
});

test('missing core value: error message, no svg', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.R1;
  const d = D.buildDrawing(r);
  assert.match(d.error, /R1/);
  assert.equal(d.svg, '');
});

test('printed scale equals 190 mm over the viewBox width', () => {
  for (const r of data) {
    const d = D.buildDrawing(r);
    const m = d.svg.match(/Scale (\d+\.\d\d):1/);
    assert.equal(m[1], (190 / d.viewBox.w).toFixed(2), r.key);
    assert.ok(d.viewBox.w >= 100, r.key);
  }
});
