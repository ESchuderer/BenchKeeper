// Browser checks over file:// (no web server) and over a static server.
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright-core');
const data = require('../data.js');

const root = path.resolve(__dirname, '..');
const fileUrl = pathToFileURL(path.join(root, 'index.html')).href;
let browser;

test.before(async () => { browser = await chromium.launch({ args: ['--no-sandbox'] }); });
test.after(async () => { await browser.close(); });

async function open(url, opts = {}) {
  const ctx = await browser.newContext(opts);
  const page = await ctx.newPage();
  const errors = [], requests = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('request', (r) => requests.push(r.url()));
  await page.goto(url);
  return { page, ctx, errors, requests };
}

test('file://: list, search, family filter, count, links', async () => {
  const { page, ctx, errors, requests } = await open(fileUrl);
  assert.equal(await page.getByRole('heading', { name: 'Cartridges' }).count(), 1);
  assert.equal(await page.locator('#list tbody a').count(), 25);
  assert.equal(await page.locator('#count').innerText(), '25 cartridges');
  assert.equal(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).count(), 1);
  await page.getByLabel('Search').fill('7,62 x 51');
  assert.deepEqual(await page.locator('#list tbody a').allInnerTexts(), ['308 Win.']);
  assert.equal(await page.locator('#count').innerText(), '1 cartridges');
  await page.getByLabel('Search').fill('');
  await page.getByLabel('Family').selectOption('belted');
  assert.deepEqual(await page.locator('#list tbody a').allInnerTexts(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  await page.getByLabel('Family').selectOption('All');
  assert.equal(await page.locator('#count').innerText(), '25 cartridges');
  assert.deepEqual(errors, []);
  assert.ok(requests.every((u) => u.startsWith('file:') || u.startsWith('data:')), requests.join('\n'));
  await ctx.close();
});

test('file://: detail view opens from the list, survives reload, links back', async () => {
  const { page, ctx, errors } = await open(fileUrl);
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  assert.match(page.url(), /#\/308_win$/);
  assert.equal(await page.getByRole('heading', { level: 1, name: '308 Win.' }).count(), 1);
  assert.equal(await page.getByRole('img', { name: '308 Win. drawing' }).count(), 1);
  assert.ok(await page.getByRole('button', { name: 'Print' }).isVisible());
  assert.deepEqual(await page.locator('#detail-view table').first().locator('th[scope=col]').allTextContents(), ['Symbol', 'Value', 'Unit']);
  await page.reload();
  assert.equal(await page.getByRole('heading', { level: 1, name: '308 Win.' }).count(), 1);
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await page.getByRole('heading', { name: 'Cartridges' }).isVisible(), true);
  await page.goto(fileUrl + '#/nope');
  assert.equal(await page.getByRole('heading', { name: 'Not found' }).count(), 1);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test('file://: all 25 detail views, no console errors, labels do not overlap in the browser', async () => {
  const { page, ctx, errors } = await open(fileUrl);
  for (const r of data) {
    await page.goto(fileUrl + '#/' + r.key);
    const issues = await page.evaluate(() => {
      const svg = document.querySelector('#detail-view svg');
      const texts = [...svg.querySelectorAll('text')].map((t) => ({ s: t.textContent, b: t.getBoundingClientRect() })).filter((t) => t.b.width > 0);
      const out = [];
      for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
        const a = texts[i].b, b = texts[j].b;
        if (!(a.right <= b.left || b.right <= a.left || a.bottom <= b.top || b.bottom <= a.top)) out.push(`${texts[i].s} x ${texts[j].s}`);
      }
      const segs = [];
      const m = svg.getScreenCTM();
      svg.querySelectorAll('line:not(.hatch):not(.cl):not(.e)').forEach((l) => segs.push([[m.a * +l.getAttribute('x1') + m.e, m.d * +l.getAttribute('y1') + m.f], [m.a * +l.getAttribute('x2') + m.e, m.d * +l.getAttribute('y2') + m.f]]));
      svg.querySelectorAll('path.o').forEach((p) => { const L = p.getTotalLength(); let prev; for (let k = 0; k <= 400; k++) { const q = p.getPointAtLength((L * k) / 400); const c = [m.a * q.x + m.e, m.d * q.y + m.f]; if (prev) segs.push([prev, c]); prev = c; } });
      for (const t of texts) for (const [[x1, y1], [x2, y2]] of segs) {
        const n = Math.max(2, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 0.5));
        let hit = false;
        for (let i = 0; i <= n && !hit; i++) { const x = x1 + ((x2 - x1) * i) / n, y = y1 + ((y2 - y1) * i) / n; hit = x > t.b.left + 0.3 && x < t.b.right - 0.3 && y > t.b.top + 0.3 && y < t.b.bottom - 0.3; }
        if (hit) { out.push(t.s + ' touches a line'); break; }
      }
      const sb = svg.getBoundingClientRect();
      for (const t of texts) if (t.b.left < sb.left - 0.5 || t.b.right > sb.right + 0.5 || t.b.top < sb.top - 0.5 || t.b.bottom > sb.bottom + 0.5) out.push(t.s + ' outside the svg');
      return out;
    });
    assert.deepEqual(issues, [], r.key);
  }
  assert.deepEqual(errors, []);
  await ctx.close();
});

test('phone width: nothing scrolls sideways; drawing fits', async () => {
  const { page, ctx } = await open(fileUrl, { viewport: { width: 360, height: 740 } });
  for (const hash of ['', '#/338_lapua_mag', '#/22_long_rifle']) {
    await page.goto(fileUrl + hash);
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), hash);
  }
  const w = await page.locator('svg.drawing').evaluate((e) => e.getBoundingClientRect().width);
  assert.ok(w <= 360);
  await ctx.close();
});

test('colour schemes: dark on screen, light in print', async () => {
  const { page, ctx } = await open(fileUrl + '#/308_win', { colorScheme: 'dark' });
  const bg = () => page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.notEqual(await bg(), 'rgb(255, 255, 255)');
  const dark = await bg();
  assert.ok(Number(dark.match(/\d+/)[0]) < 60, dark);
  await page.emulateMedia({ media: 'print' });
  assert.equal(await bg(), 'rgb(255, 255, 255)');
  assert.equal(await page.locator('nav').first().isVisible(), false);
  assert.equal(await page.locator('#list-view').isVisible(), false);
  assert.match(await page.locator('footer').innerText(), /Source: C\.I\.P\. TDCC, revised 2008-09-23/);
  await ctx.close();
});

test('print: one A4 page for each of the 25 cartridges', async () => {
  const { page, ctx } = await open(fileUrl);
  for (const r of data) {
    await page.goto(fileUrl + '#/' + r.key);
    const pdf = await page.pdf({ preferCSSPageSize: true });
    const pages = (pdf.toString('latin1').match(/\/Type \/Page\b(?!s)/g) || []).length;
    assert.equal(pages, 1, r.key);
  }
  await ctx.close();
});

test('static server: same app works', async () => {
  const server = http.createServer((q, s) => {
    const f = path.join(root, q.url.split('?')[0] === '/' ? 'index.html' : q.url.split('?')[0]);
    fs.readFile(f, (e, d) => { if (e) { s.writeHead(404); s.end(); } else { s.writeHead(200, { 'content-type': { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] }); s.end(d); } });
  });
  await new Promise((r) => server.listen(0, r));
  const url = `http://localhost:${server.address().port}/`;
  const { page, ctx, errors } = await open(url + '#/9_mm_luger');
  assert.equal(await page.getByRole('img', { name: '9 mm Luger drawing' }).count(), 1);
  assert.deepEqual(errors, []);
  await ctx.close();
  server.close();
});

test('malformed or unknown address shows not found and updates the title', async () => {
  const { page, ctx, errors } = await open(fileUrl + '#/308_win');
  for (const hash of ['#/%', '#/%E0%A4%A', '#/nope']) {
    await page.evaluate((h) => { location.hash = h; }, hash);
    assert.equal(await page.getByRole('heading', { name: 'Not found' }).isVisible(), true, hash);
    assert.equal(await page.title(), 'Not found - C.I.P. cartridges', hash);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.goBack();
  }
  assert.deepEqual(errors, []);
  await page.goto(fileUrl + '#/%');
  assert.equal(await page.getByRole('heading', { name: 'Not found' }).isVisible(), true);
  await ctx.close();
});
