const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../data.js');
const F = require('../format.js');

const rec = (key) => data.find((r) => r.key === key);
const rows = (r, group, section) =>
  F.buildTables(r).find((g) => g.title === group).sections.find((s) => s.title === section).rows;
const row = (r, group, section, symbol) => rows(r, group, section).find((x) => x.symbol === symbol);

test('formatAngle', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(3.0), '3°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
});

test('symbols', () => {
  const s = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax' };
  for (const [k, v] of Object.entries(s)) assert.equal(F.symbol(k), v);
});

test('308 Win. lengths row L3 is 51.18 mm', () => {
  assert.deepEqual(row(rec('308_win'), 'Cartridge', 'Lengths', 'L3'), { symbol: 'L3', value: '51.18', unit: 'mm' });
});

test('tolerance sits next to its value and has no row', () => {
  const r = rec('308_win');
  assert.equal(row(r, 'Cartridge', 'Lengths', 'L1').value, '39.62 -0.2');
  for (const rec2 of data) for (const g of F.buildTables(rec2)) for (const s of g.sections) for (const x of s.rows) assert.ok(!/Tol$/.test(x.symbol), x.symbol);
});

test('units', () => {
  const r = rec('308_win');
  assert.deepEqual(row(r, 'Cartridge', 'Pressures', 'Pmax'), { symbol: 'Pmax', value: '4150', unit: 'bar' });
  assert.equal(row(r, 'Cartridge', 'Pressures', 'EE').unit, 'J');
  assert.equal(row(r, 'Cartridge', 'Pressures', 'M').unit, 'g');
  assert.equal(row(r, 'Chamber', 'Grooves', 'Q').unit, 'mm²');
  assert.equal(row(r, 'Chamber', 'Grooves', 'N').unit, '');
  assert.equal(row(r, 'Cartridge', 'Junction cone', 'α').value, '40°');
  assert.equal(row(r, 'Cartridge', 'Case head', 'β').unit, 'deg');
});

test('angle objects in tables', () => {
  assert.equal(row(rec('223_rem'), 'Chamber', 'Rifling', 'i').value, '3°10\'36"');
});

test('empty sections are skipped; both groups present', () => {
  const t = F.buildTables(rec('9_mm_luger'));
  assert.deepEqual(t.map((g) => g.title), ['Cartridge', 'Chamber']);
  assert.ok(!t[0].sections.some((s) => s.title === 'Junction cone'));
  for (const g of t) for (const s of g.sections) assert.ok(s.rows.length > 0);
});

test('every field of every record appears exactly once (tolerances merged)', () => {
  for (const r of data) {
    let want = 0;
    for (const g of ['cartridge', 'chamber']) for (const sec of Object.values(r[g])) want += Object.keys(sec).filter((k) => !/Tol$/.test(k)).length;
    let got = 0;
    for (const g of F.buildTables(r)) for (const s of g.sections) got += s.rows.length;
    assert.equal(got, want, r.key);
  }
});

test('attributes', () => {
  const a = Object.fromEntries(F.attributes(rec('308_win')).map((x) => [x.label, x]));
  assert.equal(a['Alternative names'].value, '308 Winchester, 7,62 x 51');
  assert.equal(a['Family'].value, 'rimless');
  assert.equal(a['Category'].value, 'rifle');
  assert.equal(a['Primer type'].value, 'lr');
  assert.equal(a['C.I.P. table'].value, 'I');
  assert.equal(a['Country'].value, 'US');
  assert.equal(a['Published'].value, '1984-06-14');
  assert.equal(a['Revised'].value, '2008-09-23');
  assert.equal(a['Pressure method'].value, 'Transducer');
  assert.equal(a['Water capacity'].value, '56 grH2O');
  assert.deepEqual(a['Water capacity'].link, { text: 'kwk', href: 'http://kwk.us/cases.html' });
});

test('attributes omit alternative names and capacity when absent', () => {
  const labels = F.attributes(rec('7_x_64')).map((x) => x.label);
  assert.ok(!labels.includes('Alternative names'));
  assert.ok(!labels.includes('Water capacity'));
});

test('filter: search by name and alternative names, case-insensitive', () => {
  assert.deepEqual(F.filterCartridges(data, '7,62 x 51', 'All').map((r) => r.name), ['308 Win.']);
  assert.deepEqual(F.filterCartridges(data, '45 acp', 'All').map((r) => r.name), ['45 Auto']);
  assert.equal(F.filterCartridges(data, '', 'All').length, 25);
  assert.equal(F.filterCartridges(data, 'zzz', 'All').length, 0);
});

test('filter: family', () => {
  assert.deepEqual(F.filterCartridges(data, '', 'belted').map((r) => r.name), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(F.filterCartridges(data, '22', 'rimfire').length, 2);
  assert.equal(F.filterCartridges(data, '', 'pistol').length, 6);
});
