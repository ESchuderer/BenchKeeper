const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../data.js');
const D = require('../drawing.js');

const rec = (key) => data.find((r) => r.key === key);
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) < eps, `${a} vs ${b}`);
const hasPt = (pts, r, z, eps = 1e-6) => pts.some((p) => Math.abs(p[0] - r) < eps && Math.abs(p[1] - z) < eps);

test('rim type', () => {
  assert.equal(D.rimType(rec('300_win_mag')), 'belted');
  assert.equal(D.rimType(rec('22_long_rifle')), 'rimfire');
  assert.equal(D.rimType(rec('9_3_x_74_r')), 'rimmed');
  assert.equal(D.rimType(rec('38_special')), 'rimmed');
  assert.equal(D.rimType(rec('223_rem')), 'rimless');
  assert.equal(D.rimType(rec('9_mm_luger')), 'rimless');
  assert.equal(D.rimType({ family: 'pistol', cartridge: { caseHead: { R1: 9 }, powderChamber: { P1: 10 } } }), 'rebated');
});

test('223 Rem. head, groove, body, shoulder, neck (pairs are [r, z])', () => {
  const g = D.geometry(rec('223_rem'));
  assert.deepEqual(g.outer[0], [0, 0]);
  near(g.outer[1][0], 4.8 - 0.45 * Math.tan((35 * Math.PI) / 180));
  assert.equal(g.outer[1][1], 0);
  for (const [r, z] of [[4.8, 0.45], [4.8, 1.14], [4.215, 1.14], [4.215, 1.9], [4.79, 3.13]]) assert.ok(hasPt(g.outer, r, z), `${r},${z}`);
  assert.ok(hasPt(g.edges, 4.5, 36.52), 'published shoulder point P2/2, L1');
  assert.ok(hasPt(g.edges, 6.43 / 2, 39.55), 'published shoulder point H1/2, L2');
  assert.ok(hasPt(g.outer, 6.43 / 2, 44.7));
  assert.equal(g.rimType, 'rimless');
});

test('chamfer is limited to R1/4', () => {
  const g = D.geometry({ ...rec('223_rem'), cartridge: { ...rec('223_rem').cartridge, caseHead: { ...rec('223_rem').cartridge.caseHead, f: 5, R: 6 } } });
  near(g.outer[1][0], 4.8 - 9.6 / 4);
});

test('shoulder passes through published points and fillets are tangent-sized', () => {
  for (const r of data) {
    const g = D.geometry(r);
    if (!g.bottle) continue;
    const c = r.cartridge;
    // the published corner points lie on the straight lines: outer points never exceed P2/2 after L1
    const rmaxAfter = Math.max(...g.outer.filter((p) => p[1] >= c.lengths.L1).map((p) => p[0]));
    assert.ok(rmaxAfter <= c.powderChamber.P2 / 2 + 1e-9, r.key);
    for (const t of g.tangents) assert.ok(t.length <= t.segment + 1e-9, `${r.key} fillet ${t.length} > ${t.segment}`);
  }
});

test('300 Win. Mag. belted groove, ramp at delta, belt and step in', () => {
  const g = D.geometry(rec('300_win_mag'));
  const rampEnd = 1.27 + 0.94 + (13.51 - 12.07) / 2 / Math.tan((35 * Math.PI) / 180);
  for (const [r, z] of [[12.07 / 2, 1.27], [12.07 / 2, 2.21], [13.51 / 2, rampEnd], [13.51 / 2, 5.59], [13.03 / 2, 5.59]]) assert.ok(hasPt(g.outer, r, z), `${r},${z}`);
  near(g.rampEnd, rampEnd);
});

test('rimfire half-round: outermost point at R1/2, radius min(R/2,(R1-P1)/2)', () => {
  const g = D.geometry(rec('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  near(Math.max(...g.outer.map((p) => p[0])), 7.06 / 2);
  assert.ok(hasPt(g.outer, 7.06 / 2, rho));
  assert.ok(hasPt(g.outer, 7.06 / 2 - rho, 0));
  assert.ok(hasPt(g.outer, 5.74 / 2, 1.09));
});

test('case without alpha, L1 or L2 is straight and ends at (H2/2, L3)', () => {
  const g = D.geometry(rec('9_mm_luger'));
  assert.equal(g.bottle, false);
  assert.deepEqual(g.outer[g.outer.length - 1], [9.65 / 2, 19.15]);
});

test('no groove: step in from rim to P1/2 at z = R', () => {
  const g = D.geometry(rec('38_special'));
  assert.ok(hasPt(g.outer, 9.63 / 2, 1.5));
  assert.ok(g.notes.some((n) => /groove/i.test(n) && /E1/.test(n) && /e min/.test(n)));
});

test('missing r1 min and r2: no rounding and a note names them (17 HMR)', () => {
  const g = D.geometry(rec('17_hmr'));
  assert.equal(g.tangents.length, 0);
  const n = g.notes.find((x) => /r1 min/.test(x));
  assert.ok(n && /r2/.test(n));
});

test('walls, head thickness, primer pocket', () => {
  let g = D.geometry(rec('308_win'));
  near(g.tn, 0.435);
  near(g.tb, 0.6);
  near(g.w, 4.8);
  assert.deepEqual(g.pocket, { d: 5.33, h: 3.3 });
  g = D.geometry(rec('223_rem'));
  assert.deepEqual(g.pocket, { d: 4.45, h: 3.04 });
  near(g.w, 4.54);
  g = D.geometry(rec('338_lapua_mag'));
  assert.deepEqual(g.pocket, { d: 5.33, h: 3.3 });
  near(g.w, 4.8);
  g = D.geometry(rec('300_win_mag'));
  near(g.w, 4.8);
  g = D.geometry(rec('22_long_rifle'));
  assert.equal(g.pocket, null);
  near(g.w, 2.5);
  near(D.geometry(rec('44_rem_mag')).tb, Math.min(Math.max(1.3 * (11.58 - 10.97) / 2, 0.6), 0.35 * 11.61 / 2));
});

test('pointy bullet 308 Win.', () => {
  const b = D.geometry(rec('308_win')).bullet;
  near(b.zb, 43.33);
  near(b.zc, 43.33 + 0.4 * (71.12 - 43.33));
  near(b.m, 1.27);
  const tip = b.exposed[b.exposed.length - 2];
  near(tip[0], 1.27 / 2);
  near(tip[1], 71.12);
  assert.deepEqual(b.exposed[b.exposed.length - 1], [0, 71.12]);
  assert.deepEqual(b.exposed[0], [7.85 / 2, 51.18]);
});

test('tangent ogive: arc is tangent at the cylinder and passes the meplat edge', () => {
  const b = D.geometry(rec('308_win')).bullet;
  const n = 71.12 - b.zc;
  const d = 7.85 / 2 - 1.27 / 2;
  near(b.rho, (d * d + n * n) / (2 * d));
  // all nose points are at distance rho from the centre (r = G1/2 - rho, z = zc)
  for (const [r, z] of b.nose) near(Math.hypot(r - (7.85 / 2 - b.rho), z - b.zc), b.rho, 1e-6);
});

test('seating depth, cylinder fraction and meplat by shape and category', () => {
  const cases = [
    ['9_mm_luger', 0.4 * 9.03, 0.65, 0.15 * 9.03],
    ['40_s_w', 0.4 * 10.17, 0.7, 0.55 * 10.17],
    ['357_magnum', 0.6 * 9.12, 0.78, 0.6 * 9.12],
    ['22_win_mag_r_f', 0.8 * 5.7, 0.55, 0.15 * 5.7],
    ['17_hmr', 4.38, 0.4, Math.max(0.08 * 4.38, 1.27)],
  ];
  for (const [key, s, k, m] of cases) {
    const r = rec(key);
    const b = D.geometry(r).bullet;
    const L3 = r.cartridge.lengths.L3, L6 = r.cartridge.lengths.L6;
    near(b.s, s);
    near(b.zb, L3 - s);
    near(b.zc, L3 - s + k * (L6 - (L3 - s)));
    near(b.m, m);
  }
});

test('rounded nose is a quarter ellipse ending at the meplat', () => {
  const b = D.geometry(rec('9_mm_luger')).bullet;
  const [r, z] = b.nose[b.nose.length - 1];
  near(r, 0.15 * 9.03 / 2);
  near(z, 29.69);
});

test('heeled 22 Long Rifle: exposed diameter H2, seated heel H2 - 2 tb', () => {
  const g = D.geometry(rec('22_long_rifle'));
  assert.equal(g.heeled, true);
  near(g.bullet.Rexp, 5.72 / 2);
  near(g.bullet.Rseat, 5.72 / 2 - g.tb);
  assert.equal(D.geometry(rec('308_win')).heeled, false);
});

test('the bullet is exposed from the mouth in every record', () => {
  for (const r of data) {
    const g = D.geometry(r);
    assert.ok(!g.error, r.key);
    assert.ok(g.bullet.zc >= r.cartridge.lengths.L3, `${r.key} nose starts inside the case`);
    assert.ok(g.bullet.zb > g.w, `${r.key} bullet base inside the head`);
  }
});

test('inner line starts at z = w and ends at the mouth wall', () => {
  const g = D.geometry(rec('308_win'));
  assert.equal(g.inner[0][1], g.w);
  near(g.inner[g.inner.length - 1][0], 7.85 / 2);
  assert.equal(g.inner[g.inner.length - 1][1], 51.18);
  const s = D.geometry(rec('9_mm_luger'));
  near(s.inner[s.inner.length - 1][0], 9.03 / 2);
});

test('missing core value gives an error, not an invented number', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.lengths.L3;
  const g = D.geometry(r);
  assert.match(g.error, /L3/);
});
