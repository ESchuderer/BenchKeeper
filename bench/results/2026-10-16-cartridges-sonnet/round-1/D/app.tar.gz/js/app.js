// Views, routing and events. Hash routes: #/ (list) and #/cartridge/<key> (detail).
(function () {
  const { cartridges, format: F, drawing: D } = window.CIP;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const listView = $('#list-view'), detailView = $('#detail-view');
  const search = $('#search'), family = $('#family'), rows = $('#rows');
  const L3 = (r) => F.formatNumber(r.cartridge.lengths.L3);

  // ---- list
  rows.innerHTML = cartridges
    .map((r) => `<tr data-key="${esc(r.key)}"><td><a href="#/cartridge/${encodeURIComponent(r.key)}">${esc(r.name)}</a></td>` +
      `<td>${esc(r.family)}</td><td class="num">${L3(r)} mm</td></tr>`)
    .join('');
  function filter() {
    let n = 0;
    cartridges.forEach((r, i) => {
      const show = F.matches(r, search.value, family.value);
      rows.children[i].hidden = !show;
      n += show;
    });
    $('#count').textContent = `${n} cartridges`;
    $('#empty').hidden = n > 0;
  }
  search.addEventListener('input', filter);
  family.addEventListener('change', filter);
  filter();
  window.addEventListener('pageshow', filter);

  // ---- detail
  const fact = (label, html) => `<div><dt>${label}</dt><dd>${html}</dd></div>`;
  function capacity(r) {
    const c = (r.annotations || {}).publishedCapacity;
    if (!c) return 'not published';
    return `${F.formatNumber(c.grH2O)} gr H2O, <a href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.source)}</a>` +
      (c.note ? ` <span class="note">(${esc(c.note)})</span>` : '');
  }
  function table(s) {
    return `<table><caption>${esc(s.title)}</caption><thead><tr><th>Symbol</th><th>Value</th><th>Unit</th></tr></thead><tbody>` +
      s.rows.map((x) => `<tr><td class="sym">${esc(x.symbol)}</td><td class="num">${esc(x.value)}</td><td class="unit">${esc(x.unit)}</td></tr>`).join('') +
      '</tbody></table>';
  }
  function detail(r) {
    const d = D.render(r);
    const sec = F.sections(r);
    const ann = r.annotations || {};
    detailView.innerHTML =
      `<nav class="toolbar"><a href="#/">All cartridges</a><button type="button" id="print">Print</button></nav>` +
      `<header><h1 tabindex="-1">${esc(r.name)}</h1></header>` +
      `<dl class="facts">` +
      fact('Alternative names', r.alternativeNames ? esc(r.alternativeNames.join(', ')) : 'none') +
      fact('Family', esc(r.family)) + fact('Category', esc(ann.category)) + fact('Primer type', esc(ann.primerType)) +
      fact('C.I.P. table', esc(r.tab)) + fact('Country', esc(r.country)) +
      fact('Published', esc(r.published)) + fact('Revised', esc(r.revised)) +
      fact('Pressure method', esc(r.pressureMethod)) + fact('Water capacity', capacity(r)) +
      `</dl>` +
      `<figure class="drawing-figure">${d.svg}` +
      (d.notes.length ? `<figcaption class="notes">Not drawn, value not published: ${esc(d.notes.join('; '))}.</figcaption>` : '') +
      `</figure>` +
      `<h2>Cartridge values</h2><div class="tables">${sec.cartridge.map(table).join('')}</div>` +
      `<h2>Chamber values</h2><div class="tables">${sec.chamber.map(table).join('')}</div>` +
      `<footer class="source">Source: C.I.P. TDCC, revised ${esc(r.revised)}. Data: OpenBallistics (MIT).</footer>`;
    $('#print').addEventListener('click', () => window.print());
    keepScaleText(detailView.querySelector('svg.drawing'));
  }

  // Scale text: true for the medium shown (screen: rendered width; print: A4 content width).
  let scaleCleanup = () => {};
  function keepScaleText(svg) {
    scaleCleanup();
    const text = svg && svg.querySelector('text.scale');
    if (!text) return;
    const vbw = +svg.dataset.vbw;
    const mq = window.matchMedia('print');
    const update = () => {
      const w = svg.getBoundingClientRect().width;
      if (mq.matches) text.textContent = svg.dataset.printScale;
      else if (w > 0) text.textContent = `Scale ${D.scaleText(w / vbw / (96 / 25.4))}`;
    };
    const ro = new ResizeObserver(update);
    ro.observe(svg);
    mq.addEventListener('change', update);
    window.addEventListener('beforeprint', update);
    window.addEventListener('afterprint', update);
    update();
    scaleCleanup = () => {
      ro.disconnect();
      mq.removeEventListener('change', update);
      window.removeEventListener('beforeprint', update);
      window.removeEventListener('afterprint', update);
    };
  }

  // ---- routing
  function route() {
    const m = location.hash.match(/^#\/cartridge\/(.+)$/);
    const key = m && (() => { try { return decodeURIComponent(m[1]); } catch (e) { return null; } })();
    const r = m && cartridges.find((c) => c.key === key);
    listView.hidden = !!m;
    detailView.hidden = !m;
    if (!m) {
      scaleCleanup();
      document.title = 'C.I.P. cartridges';
      return;
    }
    if (r) detail(r);
    else detailView.innerHTML = '<nav class="toolbar"><a href="#/">All cartridges</a></nav><h1 tabindex="-1">Cartridge not found</h1>';
    document.title = `${r ? r.name : 'Not found'} - C.I.P. cartridges`;
    window.scrollTo(0, 0);
    detailView.querySelector('h1').focus({ preventScroll: true });
  }
  window.addEventListener('hashchange', route);
  route();
})();
