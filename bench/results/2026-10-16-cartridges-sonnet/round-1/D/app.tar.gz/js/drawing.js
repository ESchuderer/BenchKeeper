// SVG drawing of a cartridge. 1 SVG user unit = 1 mm; x = z (head on the left), y = -r outside view, +r section.
(function (root) {
  const CIP = (root.CIP = root.CIP || {});
  const F = CIP.format || require('./format.js');
  const G = CIP.geometry || require('./geometry.js');

  const FS = 2.6; // label font size, mm
  const CW = 0.6 * FS; // monospace character width
  const GAP = 0.8; // gap between outline and extension line
  const OVER = 1.5; // extension line overshoot
  const ARROW = 1.6;
  const PRINT_WIDTH_MM = 190; // A4 content width, see css/style.css
  const PRINT_MAX_HEIGHT_MM = 125; // drawing height limit in print, see css/style.css
  const n3 = (v) => +v.toFixed(3);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const textWidth = (s, fs = FS) => [...s].length * 0.6 * fs;
  const pts = (a) => a.map((p) => `${n3(p[0])},${n3(p[1])}`).join(' ');
  const has = (v) => v !== undefined && v !== null;

  const scaleText = (ratio) => {
    const t = (x) => String(+x.toFixed(1));
    return ratio >= 0.95 ? `${t(ratio)}:1` : `1:${t(1 / ratio)}`;
  };

  function boxHitsSegment(b, p, q) {
    const inside = (x, y) => x > b.x0 && x < b.x1 && y > b.y0 && y < b.y1;
    if (inside(p[0], p[1]) || inside(q[0], q[1])) return true;
    const edges = [
      [[b.x0, b.y0], [b.x1, b.y0]], [[b.x1, b.y0], [b.x1, b.y1]],
      [[b.x1, b.y1], [b.x0, b.y1]], [[b.x0, b.y1], [b.x0, b.y0]],
    ];
    const cross = (a, c, d) => (c[0] - a[0]) * (d[1] - a[1]) - (c[1] - a[1]) * (d[0] - a[0]);
    return edges.some(([e1, e2]) => {
      const d1 = cross(p, q, e1), d2 = cross(p, q, e2), d3 = cross(e1, e2, p), d4 = cross(e1, e2, q);
      return d1 * d2 < 0 && d3 * d4 < 0;
    });
  }
  const boxesHit = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

  function render(rec) {
    const m = G.build(rec);
    const name = rec.name;
    const notes = m.missing.map((x) => `${x.symbol} (${x.feature})`);
    const out = { name, notes, model: m, labels: [], outlines: [], thin: [], svg: '', viewBox: null };
    const parts = [];
    const bounds = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    const grow = (x, y) => {
      bounds.x0 = Math.min(bounds.x0, x); bounds.x1 = Math.max(bounds.x1, x);
      bounds.y0 = Math.min(bounds.y0, y); bounds.y1 = Math.max(bounds.y1, y);
    };
    const growBox = (b) => { grow(b.x0, b.y0); grow(b.x1, b.y1); };

    if (!m.outer) {
      out.viewBox = { x: 0, y: 0, w: 80, h: 12 };
      out.svg = `<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="0 0 80 12" role="img" aria-label="${esc(name)} drawing"><title>${esc(name)} drawing</title><text x="2" y="7" font-size="3">Not drawn</text></svg>`;
      return out;
    }

    const up = (p) => [p[1], -p[0]];
    const dn = (p) => [p[1], p[0]];
    const d = m.dims;
    const bl = m.bullet;
    const outline = (cls, points, extra = '') => {
      out.outlines.push({ cls, pts: points });
      points.forEach((p) => grow(p[0], p[1]));
      parts.push(`<polyline class="outline ${cls}" points="${pts(points)}"${extra}/>`);
    };
    const thin = out.thin; // extension and dimension line segments
    const line = (cls, x1, y1, x2, y2, extra = '') => {
      grow(x1, y1); grow(x2, y2);
      if (cls === 'ext' || cls === 'dimline') thin.push([[x1, y1], [x2, y2]]);
      return `<line class="${cls}" x1="${n3(x1)}" y1="${n3(y1)}" x2="${n3(x2)}" y2="${n3(y2)}"${extra}/>`;
    };
    const arrows = ' marker-start="url(#arrow)" marker-end="url(#arrow)"';
    // dimension line between a and b; arrows outside the span when it is too short
    const dimLine = (x1, y1, x2, y2) => {
      const len = Math.hypot(x2 - x1, y2 - y1);
      if (len >= 2.5 * ARROW) return line('dimline', x1, y1, x2, y2, arrows);
      const ux = (x2 - x1) / len, uy = (y2 - y1) / len, t = 3;
      return (
        line('dimline', x1 - ux * t, y1 - uy * t, x1, y1, ' marker-end="url(#arrow)"') +
        line('dimline', x2 + ux * t, y2 + uy * t, x2, y2, ' marker-end="url(#arrow)"')
      );
    };

    // ---- placed labels
    const placed = out.labels;
    const label = (dim, text, x, y, rot) => {
      const w = textWidth(text);
      const box = rot
        ? { x0: x - 0.8 * FS, x1: x + 0.2 * FS, y0: y - w, y1: y }
        : { x0: x, x1: x + w, y0: y - 0.8 * FS, y1: y + 0.2 * FS };
      placed.push({ dim, text, box });
      growBox(box);
      const tr = rot ? ` transform="translate(${n3(x)} ${n3(y)}) rotate(-90)"` : ` x="${n3(x)}" y="${n3(y)}"`;
      return `<text class="label"${tr} font-size="${FS}">${esc(text)}</text>`;
    };
    const dimGroup = (id, inner) => parts.push(`<g class="dim" data-dim="${esc(id)}">${inner}</g>`);
    const fmt = (sym, v) => `${sym} ${F.formatNumber(v)}`;

    // ---- case outline, outside view (upper) and section (lower)
    const centreEnd = bl ? d.L6 : d.L3;
    outline('outer-upper', m.outer.map(up));
    outline('outer-lower', m.outer.map((p, i) => (i === 0 && m.pocket ? dn([m.pocket.diameter / 2, 0]) : dn(p))));
    const rIn = m.inner[m.inner.length - 1][0];
    const rAtMouth = bl ? bl.exposed[0][0] : rIn;
    if (rAtMouth < d.H2 / 2 - 1e-6) outline('mouth-edge', [up([d.H2 / 2, d.L3]), up([rAtMouth, d.L3])]);
    if (bl) outline('bullet-outside', bl.exposed.map(up));
    out.outlines.push({ cls: 'section', pts: m.hatch.map(dn) });
    m.hatch.forEach((p) => grow(...dn(p)));
    parts.push(`<polygon class="cut" points="${pts(m.hatch.map(dn))}" fill="url(#hatch)"/>`);
    parts.push(`<polygon class="outline section" points="${pts(m.hatch.map(dn))}"/>`);
    if (bl) outline('bullet-section', bl.full.map(dn));
    parts.push(line('center', -3, 0, centreEnd + 3, 0));

    // ---- feature positions
    const bodyR = (z) => {
      const b = m.body;
      if (z <= b[0][1]) return b[0][0];
      for (let i = 1; i < b.length; i++) if (z <= b[i][1]) {
        const [r0, z0] = b[i - 1], [r1, z1] = b[i];
        return z1 === z0 ? r1 : r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
      }
      return b[b.length - 1][0];
    };
    const headTopR = m.outer[1][0];
    const rimR = Math.max(...m.outer.filter((p) => p[1] <= d.R + 1e-9).map((p) => p[0]));
    const rimZ = Math.min(...m.outer.filter((p) => p[1] <= d.R + 1e-9 && Math.abs(p[0] - rimR) < 1e-9).map((p) => p[1]));
    const rimEndR = m.outer.find((p) => p[1] >= d.R - 1e-9)[0];

    // ---- length rows above the part, shortest nearest
    const rows = [['L1', d.L1, d.P2 / 2], ['L2', d.L2, d.H1 / 2], ['L3', d.L3, d.H2 / 2], ['L6', bl ? d.L6 : undefined, bl ? bl.m / 2 : 0]]
      .filter(([, v]) => has(v))
      .sort((a, b) => a[1] - b[1]);
    rows.forEach(([sym, v, r], k) => {
      const y = -(m.maxR + 9 + 7 * k);
      const rf = sym === 'L1' || sym === 'L2' ? (m.shoulder ? r : bodyR(v)) : r;
      dimGroup(sym,
        line('ext', 0, -(headTopR + GAP), 0, y - OVER) + line('ext', v, -(rf + GAP), v, y - OVER) +
        dimLine(0, y, v, y) + label(sym, fmt(sym, v), v / 2 - textWidth(fmt(sym, v)) / 2, y - 0.9));
    });

    // ---- R below the head
    {
      const y = m.maxR + 6;
      const text = fmt('R', d.R);
      dimGroup('R',
        line('ext', 0, headTopR + GAP, 0, y + OVER) + line('ext', d.R, rimEndR + GAP, d.R, y + OVER) +
        dimLine(0, y, d.R, y) + label('R', text, d.R / 2 - textWidth(text) / 2, y + OVER + 0.3 + 0.8 * FS));
    }

    // ---- diameter columns: E1, R1 on the left; G1, H2, H1, P2, P1 on the right, smaller nearest
    const column = (sym, D, zf, side, xc, top) => {
      const dir = side === 'left' ? -1 : 1;
      const text = fmt(sym, D);
      const x1 = zf + dir * GAP, x2 = xc + dir * OVER;
      dimGroup(sym,
        line('ext', x1, -D / 2, x2, -D / 2) + line('ext', x1, D / 2, x2, D / 2) +
        dimLine(xc, -D / 2, xc, D / 2) + label(sym, text, xc + 0.3 * FS, top, true));
    };
    // labels sit above the highest extension line of their side so no line crosses them
    const sideCols = (list) => list.filter(([, v]) => has(v)).sort((p, q) => p[1] - q[1]);
    const left = sideCols([['E1', d.E1, d.R], ['R1', d.R1, rimZ]]);
    const right = sideCols([['G1', bl ? d.G1 : undefined, bl ? bl.zc : 0], ['H2', d.H2, d.L3], ['H1', d.H1, d.L2], ['P2', d.P2, d.L1], ['P1', d.P1, m.bodyStartZ]]);
    left.forEach(([sym, D, zf], i) => column(sym, D, zf, 'left', -(5 + 5 * i), -left[left.length - 1][1] / 2 - OVER - 0.5));
    right.forEach(([sym, D, zf], i) => column(sym, D, zf, 'right', centreEnd + 5 + 5 * i, -right[right.length - 1][1] / 2 - OVER - 0.5));

    // ---- shoulder angle: the shoulder line and its mirror about the horizontal, drawn at the body-side corner
    if (m.shoulder && has(d.alpha)) {
      const S1 = up(m.shoulder.p1), S2 = up(m.shoulder.p2);
      const V = S1;
      const len = Math.hypot(S2[0] - S1[0], S2[1] - S1[1]);
      const th = Math.atan2(S2[1] - S1[1], S2[0] - S1[0]);
      const rho = Math.min(0.8 * len, 6);
      const at = (a, r) => [V[0] + r * Math.cos(a), V[1] + r * Math.sin(a)];
      const a1 = at(th, rho), a2 = at(-th, rho), ray = at(-th, rho + 1.5), mid = at(0, rho);
      const text = `α ${F.formatAngle(d.alpha)}`;
      const w = textWidth(text);
      // lowest spot above the diameter extension lines where the label touches no label, outline or thin line
      const top = -Math.max(d.P1, d.P2 || 0, d.H1 || 0, d.H2) / 2 - 1.2;
      const free = (b, obstacles) =>
        !placed.some((l) => boxesHit(b, l.box)) &&
        !obstacles.some((o) => o.some((p, i) => i && boxHitsSegment(b, o[i - 1], p)));
      const find = (obstacles) => {
        for (let up2 = 0; up2 <= 25; up2 += 0.5) {
          const y = top - 0.2 * FS - up2;
          for (let dx = 0; dx <= 60; dx += 1) {
            for (const x of [V[0] + rho + 1.5 + dx, V[0] - 1.5 - w - dx]) {
              const b = { x0: x - 0.5, x1: x + w + 0.5, y0: y - 0.8 * FS - 0.3, y1: y + 0.2 * FS + 0.3 };
              if (free(b, obstacles)) return [x, y];
            }
          }
        }
        return null;
      };
      const spot = find([...out.outlines.map((o) => o.pts), ...thin]) || find(out.outlines.map((o) => o.pts)) || [V[0] + rho + 1.5, top - 5];
      const lx = spot[0] > V[0] ? spot[0] - 0.4 : spot[0] + w + 0.4;
      dimGroup('α',
        line('ext', V[0], V[1], ray[0], ray[1]) +
        line('ext', mid[0], mid[1], lx, spot[1] - 0.3 * FS) +
        `<path class="dimline" d="M${n3(a1[0])},${n3(a1[1])} A${n3(rho)},${n3(rho)} 0 0 0 ${n3(a2[0])},${n3(a2[1])}" fill="none" marker-start="url(#arrow-s)" marker-end="url(#arrow-s)"/>` +
        label('α', text, spot[0], spot[1]));
      grow(a1[0], a1[1]); grow(a2[0], a2[1]);
    }

    // ---- title block below everything
    const MF = 2.4;
    const lines = [
      [name, 3.2, true, 4.2],
      [`C.I.P. table ${rec.tab}   Revised ${rec.revised}`, MF, false, 3.3],
      ['Dimensions in mm', MF, false, 3.3],
    ];
    const blockW = Math.max(bounds.x1 - bounds.x0, ...lines.map(([t, fs]) => textWidth(t, fs) + 4), textWidth('Scale 99.9:1 (A4 print)', MF) + 4);
    const bx0 = bounds.x0, by0 = bounds.y1 + 4;
    let ty = by0 + 4;
    let tb = '';
    lines.forEach(([t, fs, bold, step]) => {
      tb += `<text class="${bold ? 'title' : 'meta'}" x="${n3(bx0 + 2)}" y="${n3(ty)}" font-size="${fs}">${esc(t)}</text>`;
      ty += step;
    });
    tb += `<text class="scale" x="${n3(bx0 + 2)}" y="${n3(ty)}" font-size="${MF}">@@SCALE@@</text>`;
    const bh = ty + 2 - by0;
    tb = `<rect class="frame" x="${n3(bx0)}" y="${n3(by0)}" width="${n3(blockW)}" height="${n3(bh)}"/>` + tb;
    grow(bx0, by0); grow(bx0 + blockW, by0 + bh);

    const M = 2;
    const vb = { x: n3(bounds.x0 - M), y: n3(bounds.y0 - M), w: n3(bounds.x1 - bounds.x0 + 2 * M), h: n3(bounds.y1 - bounds.y0 + 2 * M) };
    out.viewBox = vb;
    // print: SVG box is PRINT_WIDTH_MM wide and at most PRINT_MAX_HEIGHT_MM high, the drawing fits inside it
    const printScale = `Scale ${scaleText(Math.min(PRINT_WIDTH_MM / vb.w, PRINT_MAX_HEIGHT_MM / vb.h))} (A4 print)`;
    parts.push(`<g class="titleblock">${tb.replace('@@SCALE@@', esc(printScale))}</g>`);
    const defs =
      `<defs><pattern id="hatch" width="1" height="1" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line class="hatch" x1="0" y1="0" x2="0" y2="1"/></pattern>` +
      `${[['arrow', ARROW], ['arrow-s', 0.9]].map(([id, len]) => `<marker id="${id}" class="arrow" viewBox="0 0 10 6" refX="10" refY="3" markerWidth="${len}" markerHeight="${n3(len * 0.6)}" markerUnits="userSpaceOnUse" orient="auto-start-reverse"><path d="M0,0 L10,3 L0,6 z"/></marker>`).join('')}</defs>`;
    out.svg =
      `<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="${vb.x} ${vb.y} ${vb.w} ${vb.h}" role="img" aria-label="${esc(name)} drawing" data-vbw="${vb.w}" data-vbh="${vb.h}" data-print-scale="${esc(printScale)}">` +
      `<title>${esc(name)} drawing</title>${defs}${parts.join('')}</svg>`;
    return out;
  }

  CIP.drawing = { render, scaleText, PRINT_WIDTH_MM, PRINT_MAX_HEIGHT_MM };
  if (typeof module !== 'undefined') module.exports = CIP.drawing;
})(typeof window !== 'undefined' ? window : globalThis);
