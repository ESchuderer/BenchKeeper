// Value formatting, symbols, units, table sections and search. No DOM.
(function (root) {
  const CIP = (root.CIP = root.CIP || {});

  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };

  // Field order per section; fields not listed follow in record order.
  const CARTRIDGE = [
    ['caseHead', 'Case head', ['R1', 'R', 'E1', 'E', 'R3', 'eMin', 'f', 'beta', 'delta']],
    ['collar', 'Collar', ['H1', 'H2']],
    ['junctionCone', 'Junction cone', ['S', 'alpha', 'r1Min', 'r2']],
    ['lengths', 'Lengths', ['L1', 'L2', 'L3', 'L4', 'L5', 'L6']],
    ['powderChamber', 'Powder chamber', ['P1', 'P2']],
    ['projectile', 'Projectile', ['G1', 'G2', 'L3PlusG']],
    ['pressures', 'Pressures', ['Pmax', 'PK', 'PE', 'EE', 'M']],
    ['misc', 'Miscellaneous', ['Fe', 'deltaL']],
  ];
  const CHAMBER = [
    ['barrel', 'Barrel', ['F', 'Z']],
    ['breech', 'Breech', ['R1', 'R', 'R3', 'r']],
    ['collar', 'Collar', ['H1', 'H2']],
    ['grooves', 'Grooves', ['N', 'Q', 'b', 'u']],
    ['junctionCone', 'Junction cone', ['S', 'alpha', 'r1Max', 'r2']],
    ['lengths', 'Lengths', ['L1', 'L2', 'L3']],
    ['powderChamber', 'Powder chamber', ['E', 'P1', 'P2']],
    ['rifling', 'Rifling', ['G', 'G1', 'alpha1', 'h', 'i', 's']],
  ];

  const toDegrees = (a) => (typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  const formatNumber = (n) => String(n);
  const formatAngle = (a) =>
    typeof a === 'number' ? `${formatNumber(a)}°` : `${a.degrees}°${a.minutes}'${a.seconds}"`;
  const symbol = (field) => SYMBOLS[field] || field;
  const unit = (field) => (field in UNITS ? UNITS[field] : ANGLES.has(field) ? '°' : 'mm');

  function formatValue(field, value, tol) {
    const v = ANGLES.has(field) ? formatAngle(value) : formatNumber(value);
    if (tol === undefined) return v;
    return `${v} ${tol > 0 ? '+' : ''}${formatNumber(tol)}`;
  }

  function sectionRows(data, spec) {
    return spec
      .map(([key, title, order]) => {
        const sec = data[key] || {};
        const fields = Object.keys(sec).filter((f) => !/Tol$/.test(f));
        fields.sort((a, b) => {
          const ia = order.indexOf(a), ib = order.indexOf(b);
          return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
        });
        const rows = fields.map((f) => ({
          field: f, symbol: symbol(f), value: formatValue(f, sec[f], sec[f + 'Tol']), unit: unit(f),
        }));
        return { key, title, rows };
      })
      .filter((s) => s.rows.length);
  }

  const sections = (rec) => ({
    cartridge: sectionRows(rec.cartridge, CARTRIDGE),
    chamber: sectionRows(rec.chamber, CHAMBER),
  });

  const norm = (s) => s.toLowerCase().replace(/\s+/g, '');
  const matches = (rec, query, family) =>
    (family === 'All' || rec.family === family) &&
    [rec.name, ...(rec.alternativeNames || [])].some((n) => norm(n).includes(norm(query)));

  CIP.format = { toDegrees, formatNumber, formatAngle, formatValue, symbol, unit, sections, matches };
  if (typeof module !== 'undefined') module.exports = CIP.format;
})(typeof window !== 'undefined' ? window : globalThis);
