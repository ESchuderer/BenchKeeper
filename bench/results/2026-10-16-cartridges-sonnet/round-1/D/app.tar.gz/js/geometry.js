// Cartridge geometry from a record. Points are [r, z]: r radius, z along the axis from the head face.
// Pure functions, no DOM. Values a rule needs but the record lacks are listed in `missing`; nothing is invented.
(function (root) {
  const CIP = (root.CIP = root.CIP || {});
  const F = CIP.format || require('./format.js');

  const RAD = Math.PI / 180;
  const has = (v) => typeof v === 'number' && isFinite(v);
  const hasAngle = (a) => has(a) || (a !== null && typeof a === 'object' && has(a.degrees));
  const lerp = (a, b, t) => a + (b - a) * t;
  const POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  const POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };
  // shape -> seating depth factor (rifle/rimfire, pistol), cylinder fraction (rifle/rimfire, pistol), meplat factor
  const SHAPES = {
    pointy: { s: [1.0, 1.0], k: [0.4, 0.4] },
    rounded: { s: [0.8, 0.4], k: [0.55, 0.65], m: 0.15 },
    flat: { s: [0.8, 0.4], k: [0.6, 0.7], m: 0.55 },
    semi_wadcutter: { s: [0.6, 0.6], k: [0.78, 0.78], m: 0.6 },
  };

  function rimType(rec) {
    const h = rec.cartridge.caseHead || {};
    const P1 = (rec.cartridge.powderChamber || {}).P1;
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    const ratio = h.R1 / P1;
    return ratio >= 1.05 ? 'rimmed' : ratio < 0.98 ? 'rebated' : 'rimless';
  }

  // Arc from tangent point to tangent point rounding corner V between A->V and V->B.
  function fillet(A, V, B, rho, steps = 10) {
    const len = (p, q) => Math.hypot(q[0] - p[0], q[1] - p[1]);
    const l1 = len(A, V), l2 = len(V, B);
    const d1 = [(V[0] - A[0]) / l1, (V[1] - A[1]) / l1];
    const d2 = [(B[0] - V[0]) / l2, (B[1] - V[1]) / l2];
    const phi = Math.acos(Math.max(-1, Math.min(1, d1[0] * d2[0] + d1[1] * d2[1])));
    if (phi < 1e-6) return [V];
    let t = rho * Math.tan(phi / 2);
    const tmax = 0.45 * Math.min(l1, l2);
    if (t > tmax) {
      t = tmax;
      rho = t / Math.tan(phi / 2);
    }
    const T1 = [V[0] - d1[0] * t, V[1] - d1[1] * t];
    const sign = d1[0] * d2[1] - d1[1] * d2[0] > 0 ? 1 : -1;
    const C = [T1[0] - d1[1] * sign * rho, T1[1] + d1[0] * sign * rho];
    const a0 = Math.atan2(T1[1] - C[1], T1[0] - C[0]);
    const da = sign * phi;
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const a = a0 + (da * i) / steps;
      pts.push([C[0] + rho * Math.cos(a), C[1] + rho * Math.sin(a)]);
    }
    return pts;
  }

  // Part of polyline `poly` (z non-decreasing) at z >= z0, starting on the line at z0.
  function clipFromZ(poly, z0) {
    for (let i = 1; i < poly.length; i++) {
      const [r0, za] = poly[i - 1], [r1, zb] = poly[i];
      if (zb >= z0 && za <= z0) {
        const start = zb === za ? [r1, z0] : [lerp(r0, r1, (z0 - za) / (zb - za)), z0];
        return [start, ...poly.slice(i).filter((p) => p[1] > z0)];
      }
    }
    return poly.filter((p) => p[1] >= z0);
  }

  function interp(pts, z) {
    if (z <= pts[0][1]) return pts[0][0];
    for (let i = 1; i < pts.length; i++) {
      if (z <= pts[i][1]) {
        const [r0, z0] = pts[i - 1], [r1, z1] = pts[i];
        return z1 === z0 ? r1 : lerp(r0, r1, (z - z0) / (z1 - z0));
      }
    }
    return pts[pts.length - 1][0];
  }

  function bulletOutline(shape, rb, G1, zb, zc, L6, m) {
    const pts = [[rb, zb], [rb, zc]];
    const n = L6 - zc;
    const N = 24;
    if (shape === 'pointy') {
      const d = rb - m / 2;
      const rho = (d * d + n * n) / (2 * d);
      const cr = rb - rho;
      const end = Math.atan2(n, rho - d);
      for (let i = 1; i < N; i++) {
        const a = (end * i) / N;
        pts.push([cr + rho * Math.cos(a), zc + rho * Math.sin(a)]);
      }
    } else if (shape === 'rounded') {
      const a = rb - m / 2;
      for (let i = 1; i < N; i++) {
        const t = (Math.PI / 2 * i) / N;
        pts.push([m / 2 + a * Math.cos(t), zc + n * Math.sin(t)]);
      }
    }
    pts.push([m / 2, L6], [0, L6]);
    return pts;
  }

  function build(rec) {
    const c = rec.cartridge;
    const h = c.caseHead || {}, col = c.collar || {}, jc = c.junctionCone || {}, len = c.lengths || {};
    const pc = c.powderChamber || {}, pr = c.projectile || {};
    const ann = rec.annotations || {};
    const type = rimType(rec);
    const missing = [];
    const miss = (symbol, feature) => missing.push({ symbol, feature });
    const dims = {
      R: h.R, R1: h.R1, E: h.E, E1: h.E1, R3: h.R3, eMin: h.eMin, f: h.f, beta: h.beta, delta: h.delta,
      H1: col.H1, H2: col.H2, alpha: jc.alpha, r1Min: jc.r1Min, r2: jc.r2,
      L1: len.L1, L2: len.L2, L3: len.L3, L6: len.L6, P1: pc.P1, P2: pc.P2, G1: pr.G1,
    };
    const { R, R1, E, E1, eMin, H1, H2, L1, L2, L3, L6, P1, P2, G1 } = dims;

    for (const [sym, v] of [['P1', P1], ['R1', R1], ['R', R], ['H2', H2], ['L3', L3]]) {
      if (!has(v)) miss(sym, 'case outline');
    }
    if (missing.length) return { rimType: type, dims, missing, outer: null };

    const R1h = R1 / 2, P1h = P1 / 2;
    const out = [[0, 0]];

    // 2. head face and rim edge
    if (type === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      if (rho > 0) {
        const cr = R1h - rho, cz = R / 2;
        out.push([cr, 0]);
        if (cz - rho > 1e-9) out.push([cr, cz - rho]);
        for (let i = 0; i <= 16; i++) {
          const t = (Math.PI * i) / 16;
          out.push([cr + rho * Math.sin(t), cz - rho * Math.cos(t)]);
        }
        if (cz + rho < R - 1e-9) out.push([cr, R]);
      } else {
        out.push([R1h, 0], [R1h, R]);
      }
    } else {
      if (!hasAngle(dims.beta)) miss('β', 'head chamfer');
      if (!has(dims.f)) miss('f', 'head chamfer');
      if (hasAngle(dims.beta) && has(dims.f) && F.toDegrees(dims.beta) < 90) {
        const cham = Math.min(dims.f * Math.tan(F.toDegrees(dims.beta) * RAD), R1 / 4);
        out.push([R1h - cham, 0], [R1h, dims.f]);
      } else {
        out.push([R1h, 0]);
      }
      out.push([R1h, R]);
    }

    // 3. extractor groove, belt or plain step
    let bodyStartZ = R;
    let belt = null;
    let groove = false;
    if (type === 'rimfire') {
      out.push([P1h, R]);
    } else if (has(E) && has(E1)) {
      if (!has(eMin)) {
        miss('e min', 'extractor groove');
        out.push([P1h, R]);
      } else {
        groove = true;
        const zf = R + eMin;
        out.push([E1 / 2, R], [E1 / 2, zf]);
        if (type === 'belted') {
          if (!hasAngle(dims.delta)) miss('δ', 'belt ramp');
          if (!has(dims.R3)) miss('R3', 'belt');
          if (hasAngle(dims.delta) && has(dims.R3)) {
            const zr = zf + (dims.R3 / 2 - E1 / 2) / Math.tan(F.toDegrees(dims.delta) * RAD);
            out.push([dims.R3 / 2, zr], [dims.R3 / 2, E]);
            belt = { rampEndZ: zr };
          }
        }
        out.push([P1h, E]);
        bodyStartZ = E;
      }
    } else {
      if (has(E) !== has(E1)) miss(has(E) ? 'E1' : 'E', 'extractor groove');
      out.push([P1h, R]);
    }

    // 4-6. body, shoulder, neck
    const body = [[P1h, bodyStartZ]];
    let shoulder = null;
    const bottleneck = hasAngle(dims.alpha) && has(L1) && has(L2);
    if (bottleneck && has(P2) && has(H1)) {
      const V1 = [P2 / 2, L1], V2 = [H1 / 2, L2], B = [H2 / 2, L3];
      shoulder = { p1: V1, p2: V2 };
      let f1 = [V1], f2 = [V2];
      if (has(dims.r1Min)) f1 = fillet(body[0], V1, V2, dims.r1Min);
      else miss('r1 min', 'rounding of the body-side shoulder corner');
      if (has(dims.r2)) f2 = fillet(V1, V2, B, dims.r2);
      else miss('r2', 'rounding of the neck-side shoulder corner');
      body.push(...f1, ...f2, B);
    } else {
      if (bottleneck && !has(P2)) miss('P2', 'shoulder');
      if (bottleneck && !has(H1)) miss('H1', 'shoulder');
      body.push([H2 / 2, L3]);
    }
    const outer = out.concat(body.slice(1));

    // 8. walls, head depth, pocket
    const tnKnown = has(G1);
    if (!tnKnown) miss('G1', 'case wall thickness at the neck');
    const tn = tnKnown ? (H2 - G1) / 2 : null;
    const tb = Math.min(Math.max(1.3 * (tn || 0), 0.6), 0.35 * P1h);
    const heeled = tnKnown && H2 - G1 <= 0.015;
    const prime = ann.primerType;
    let pocket = null;
    if (type !== 'rimfire' && prime !== 'rimfire') {
      if (prime in POCKET_DIAMETER) pocket = { diameter: POCKET_DIAMETER[prime], depth: POCKET_DEPTH[prime] };
      else miss('primer type', 'primer pocket');
    }
    const w = Math.max(
      2.5, 0.25 * P1h, pocket ? pocket.depth + 1.5 : 0,
      groove && !belt ? E + tb : 0, belt ? belt.rampEndZ + tb : 0
    );

    // 7. bullet
    let bullet = null;
    const shape = ann.defaultBulletShape;
    const spec = SHAPES[shape];
    if (!has(G1) || !has(L6) || !spec) {
      if (!has(G1)) miss('G1', 'bullet');
      if (!has(L6)) miss('L6', 'bullet');
      if (!spec) miss('bullet shape', 'bullet');
    } else {
      const col2 = ann.category === 'pistol' ? 1 : 0;
      const s = spec.s[col2] * G1;
      const zb = L3 - s;
      const Lb = L6 - zb;
      const zc = zb + spec.k[col2] * Lb;
      const m = shape === 'pointy' ? Math.max(0.08 * G1, 1.27) : spec.m * G1;
      const rb = heeled ? H2 / 2 : G1 / 2;
      const outline = bulletOutline(shape, rb, G1, zb, zc, L6, m);
      const exposed = clipFromZ(outline, L3);
      let full = [[0, zb], ...outline];
      let rHeel = null;
      if (heeled) {
        rHeel = (H2 - 2 * tb) / 2;
        full = [[0, zb], [rHeel, zb], [rHeel, L3], ...exposed];
      }
      bullet = { shape, s, zb, zc, m, rb, rHeel, full, exposed };
    }

    // inner wall: body outline offset in r by the wall at that z
    const zSeat = bullet ? bullet.zb : L3;
    const wallAt = (z) => {
      if (heeled || tn === null) return tb;
      if (shoulder) return z <= L1 ? tb : z >= L2 ? tn : lerp(tb, tn, (z - L1) / (L2 - L1));
      return z <= w ? tb : z >= zSeat ? tn : lerp(tb, tn, (z - w) / (zSeat - w));
    };
    const inner = [[interp(body, w) - wallAt(w), w]];
    const zs = body.map((p) => p[1]);
    if (!shoulder && !heeled && tn !== null && zSeat > w && zSeat < L3) zs.push(zSeat); // wall reaches tn at the bullet base
    zs.sort((a, b) => a - b);
    for (const z of zs) if (z > w) inner.push([interp(body, z) - wallAt(z), z]);

    const hatch = [pocket ? [pocket.diameter / 2, 0] : [0, 0], ...outer.slice(1), ...inner.slice().reverse(), [0, w]];
    if (pocket) hatch.push([0, pocket.depth], [pocket.diameter / 2, pocket.depth]);

    return {
      rimType: type, dims, missing, outer, body, bodyStartZ, shoulder, groove, belt,
      walls: { tn, tb, heeled }, w, pocket, bullet, inner, hatch,
      maxR: Math.max(...outer.map((p) => p[0])),
    };
  }

  CIP.geometry = { build, rimType, fillet, clipFromZ };
  if (typeof module !== 'undefined') module.exports = CIP.geometry;
})(typeof window !== 'undefined' ? window : globalThis);
