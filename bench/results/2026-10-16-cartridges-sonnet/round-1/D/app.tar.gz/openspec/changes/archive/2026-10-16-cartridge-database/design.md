# Design

## Context

Greenfield project (only setup commits). Constraints from the brief: plain HTML/CSS/JS, no build step, no network, must run from `file://`. See `proposal.md` for motivation and `specs/` for requirements.

## Goals / Non-Goals

**Goals:**
- Geometry and formatting are pure functions, testable in Node without a DOM.
- Same code runs in the browser (classic scripts) and in Node (`require`).

**Non-Goals:**
- Editing data, fetching data, unit conversion, more than 25 records.
- Persisting search state across reloads.

## Decisions

- **Classic scripts, global `CIP` namespace.** ES modules and `fetch` fail on `file://` in Chromium. Each file is an IIFE that attaches to `globalThis.CIP` and, when `module` exists, to `module.exports`. Order: `data.js`, `format.js`, `geometry.js`, `drawing.js`, `app.js`.
- **Data as `js/data.js`.** The 25 JSONL lines are embedded unchanged as array elements (a JSON object is a valid JS expression). A unit test pins record count, keys and sample values.
- **Hash routing.** `#/` is the list, `#/cartridge/<key>` the detail view. Works on `file://`, survives reload, no server rules. List and detail are two static sections toggled with `hidden`, so list filters persist.
- **Geometry returns a model, drawing renders it.** `geometry.js` builds polylines in `(r, z)` (r radius, z axis, as in the brief), a list of missing values and the bullet. `drawing.js` maps `(r, z)` to SVG `x = z`, `y = -r` (outside view) or `y = +r` (section), lays out dimensions and labels, and returns an SVG string. Curves (fillets, half-round, ogive, ellipse) are sampled polylines, so tests read coordinates directly.
- **Tuple order.** Points in the brief are `(r, z)`: `(R1/2, f)` is radius R1/2 at z = f.
- **Interpretations of unstated details** (recorded here, not in specs):
  - Primer pocket opens at the head face (z = 0 to depth); the hatched head excludes it.
  - Inner wall is the outer body polyline offset in r by the wall at that z; below the cavity floor `z = w` the head is solid. Belted cases use the body line, not the belt, for the inner wall.
  - Straight (non-heeled) cases have no shoulder to blend across: the wall runs linearly from tb at `z = w` to tn at the bullet base, tn above. Heeled cases use tb throughout.
  - Fillet radius is clamped so the tangent length is at most 45 % of the shorter adjacent segment.
  - Shoulder angle α is dimensioned as the angle between the shoulder line and its mirror about the horizontal, drawn at the shoulder midpoint (angles are translation-invariant); this avoids drawing the cone apex, which can lie far beyond the bullet tip (9,3 x 74 R).
  - Labels carry symbol and value only, without tolerance.
  - Dimension layout: lengths from the head as stacked rows above (R below), diameters as stacked columns (E1, R1 on the left; G1, H2, H1, P2, P1 on the right, smaller diameter nearest). Diameter labels read bottom to top above the column's top end. The angle label is placed by trying candidate positions against placed label boxes and outline segments.
  - Label size is estimated from a monospace font (0.6 em per character) so collision checks do not depend on installed fonts.
  - Scale text: on screen it is computed from the rendered width; in print from the A4 content width (190 mm). A single `<text>` is updated from `matchMedia('print')`, `beforeprint`, `afterprint` and a `ResizeObserver`.
- **Print.** `@page` A4 portrait, 10 mm margins, tables in three CSS columns with sections kept whole, footer fixed at the bottom. Print variables force the light palette.
- **Search.** Name and alternative names, lowercase, spaces removed, substring match.
- **Tests.** `node --test` for `format`, `geometry`, `drawing`, data. Playwright (`@playwright/test`, dev only) drives Chromium on `file://` and on a throwaway Node static server; label overlap is checked in the browser from `getBBox` and path sampling.

## Risks / Trade-offs

- [Dense drawings on a phone have small text] -> Text sizes are in mm and scale with the SVG; pinch zoom works.
- [Hand-built label layout may collide for a record not in the 25] -> Candidate placement checks collisions; a test covers all 25 records.
- [Print scale differs from screen scale] -> The title block states the scale for the medium being shown.
