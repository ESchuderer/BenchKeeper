# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick, printable reference for C.I.P. cartridge and chamber dimensions. OpenBallistics holds the data; this change presents 25 of its records as a dense static web app with a scaled technical drawing for each cartridge.

## What Changes

- New static web app (`index.html`, CSS, JavaScript): plain HTML/CSS/JS, no framework, no build step, no network requests, works from `file://` and from any static file server.
- Start page with a searchable, family-filterable list of the 25 cartridges.
- Detail view per cartridge at a bookmarkable address: facts, drawing, cartridge and chamber value tables, print button.
- Inline SVG drawing computed from the record: outside view and hatched section, dimension lines, title block, true to scale (1 unit = 1 mm).
- A4 portrait print layout, always light.
- Light and dark theme following the system setting.
- Tests: Node unit tests for formatting and geometry, Playwright end-to-end tests (dev dependencies only).

## Capabilities

### New Capabilities
- `cartridge-list`: start page, search, family filter, count, routing, static delivery constraints.
- `cartridge-detail`: detail view content, value formatting, tables, print layout.
- `cartridge-drawing`: geometry rules, dimension lines, labels, title block, scaling.

### Modified Capabilities

## Impact

- New files in the project root: `index.html`, `css/`, `js/`, `tests/`, `package.json`, `playwright.config.js`.
- Dev dependency: `@playwright/test` (tests only; the app has no dependencies).
- Data: the 25 supplied records, embedded unchanged in `js/data.js`.
