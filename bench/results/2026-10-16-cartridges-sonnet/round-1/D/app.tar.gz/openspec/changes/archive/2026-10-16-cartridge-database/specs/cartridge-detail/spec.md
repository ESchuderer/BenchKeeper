# Spec Delta

## Purpose

Shows all published values of one cartridge and its chamber, with the drawing, in a form that reads on screen and prints on one A4 page.

## ADDED Requirements

### Requirement: Detail header and facts
The detail view SHALL show the cartridge name as heading, then alternative names, family, category, primer type, C.I.P. table, country, published date, revised date, pressure method, and the published water capacity with a link to its source.

#### Scenario: Facts of 308 Win.
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the heading is "308 Win." and alternative names "308 Winchester, 7,62 x 51" are listed
- **AND** family "rimless", category "rifle", primer type "lr", table "I", country "US", published "1984-06-14", revised "2008-09-23" and pressure method "Transducer" are shown
- **AND** the water capacity "56" is shown with a link to `http://kwk.us/cases.html`

#### Scenario: No published capacity
- **WHEN** the record has no `publishedCapacity`
- **THEN** the water capacity reads "not published" and no link is shown

### Requirement: Value tables by section
The detail view SHALL show all cartridge values and all chamber values in tables grouped by section, each with the columns "Symbol", "Value" and "Unit". Sections without values SHALL be omitted.

#### Scenario: Units
- **WHEN** the tables of "308 Win." are shown
- **THEN** L3 reads "51.18" with unit "mm", Pmax reads "4150" with unit "bar", EE reads "3920" with unit "J", M reads "25" with unit "g", and Q reads "47.51" with unit "mm²"
- **AND** N has an empty unit

#### Scenario: Symbols
- **WHEN** a record has eMin, r1Min, alpha, alpha1, beta, delta, deltaL or L3PlusG
- **THEN** the symbols read "e min", "r1 min", "α", "α1", "β", "δ", "delta L" and "L3 + G"

### Requirement: Tolerances next to values
A field `<X>Tol` SHALL be shown next to the value of X and SHALL NOT have a row of its own.

#### Scenario: Tolerance
- **WHEN** the tables of "243 Win." are shown
- **THEN** L1 reads "39.62 -0.2"
- **AND** no row has the symbol "L1Tol"

### Requirement: Angle and number format
An angle given as a number SHALL show as `<degrees>°`; an angle given as `{degrees, minutes, seconds}` SHALL show as `<d>°<m>'<s>"`. Numbers SHALL show as published, with a decimal point and no thousands separator.

#### Scenario: Angles
- **WHEN** the tables of "270 Win." are shown
- **THEN** the junction cone α of the chamber reads `34°30'0"` and the cartridge α reads `35°`

### Requirement: Navigation and print button
The detail view SHALL have a button "Print" that opens the browser's print dialog and a link "All cartridges" that returns to the list.

#### Scenario: Print button
- **WHEN** the user presses "Print"
- **THEN** the browser's print function is called

### Requirement: A4 print layout
A printed detail view SHALL be one A4 portrait page, black on white: a header with the name, the drawing at full page width with all labels legible, then the tables, and a footer with the source "C.I.P. TDCC" and the revised date. Navigation, search and buttons SHALL NOT print. Print SHALL be light even when the system setting is dark.

#### Scenario: One page
- **WHEN** the detail view of any of the 25 cartridges is printed to A4 portrait
- **THEN** the output has exactly one page and contains the footer text "C.I.P. TDCC"

#### Scenario: Dark system setting
- **WHEN** the system setting is dark and the page is printed
- **THEN** text is black and the background is white
