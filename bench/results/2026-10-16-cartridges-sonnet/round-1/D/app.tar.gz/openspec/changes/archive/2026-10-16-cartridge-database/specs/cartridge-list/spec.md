# Spec Delta

## Purpose

Lets a user find a cartridge among the 25 records by name, alternative name or family, and open its detail view.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" and, for every record, its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name` and that opens the detail view.

#### Scenario: Initial list
- **WHEN** the user opens `index.html`
- **THEN** the heading "Cartridges" and 25 rows are shown, each with a name link, a family and an L3 value
- **AND** the text "25 cartridges" is shown

#### Scenario: Name shown as published
- **WHEN** the list is shown
- **THEN** a link with the text "6,5 Creedmoor" exists

### Requirement: Search by name and alternative names
A field labelled "Search" SHALL filter the list as the user types, matching the name and the alternative names, ignoring case and spaces.

#### Scenario: Alternative name
- **WHEN** the user types "7,62 x 51"
- **THEN** only "308 Win." is listed and the count reads "1 cartridges"

#### Scenario: No match
- **WHEN** the user types text that matches no name
- **THEN** no cartridge is listed and the count reads "0 cartridges"

### Requirement: Filter by family
A select labelled "Family" SHALL offer All, rimless, rimmed, belted, pistol and rimfire, and restrict the list to the chosen family. It SHALL combine with the search field.

#### Scenario: Family filter
- **WHEN** the user selects "belted"
- **THEN** "300 Win. Mag." and "7 mm Rem. Mag." are listed and the count reads "2 cartridges"

#### Scenario: Combined filters
- **WHEN** the user selects "rimless" and types "win"
- **THEN** only rimless cartridges whose name or alternative names contain "win" are listed

### Requirement: Bookmarkable detail address
Each detail view SHALL have its own address of the form `#/cartridge/<key>` that shows the same view after a reload and works as a bookmark. An unknown key SHALL show a "Cartridge not found" message with a link to the list.

#### Scenario: Open and reload
- **WHEN** the user opens a name link and reloads the page
- **THEN** the same detail view is shown

#### Scenario: Back to list
- **WHEN** the user follows the link "All cartridges"
- **THEN** the start page is shown with its previous search and family filter

### Requirement: Static delivery
The app SHALL consist of plain HTML, CSS and JavaScript files, SHALL make no network request, and SHALL work when `index.html` is opened from disk in Chromium and when the folder is served by a static file server.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened through a `file://` address
- **THEN** list, search, filter, detail views and drawings work and no request other than the app's own files is made

### Requirement: Theme and usability
The interface SHALL be in English, use tabular numbers, follow the system light or dark setting on screen, and stay usable at phone width without horizontal page scrolling.

#### Scenario: Phone width
- **WHEN** the viewport is 360 px wide
- **THEN** the list and the detail view do not scroll horizontally
