# Tasks

## 1. Project setup and data

- [x] 1.1 Add `package.json` (scripts `test`, `test:unit`, `test:e2e`), `@playwright/test` dev dependency, `playwright.config.js`, `.gitignore`; verify `npm test` runs (no tests yet) and Chromium launches.
- [x] 1.2 Add `js/data.js` with the 25 records unchanged; verify `tests/unit/data.test.js` (25 records, unique keys, sample values, family counts) passes.

## 2. Formatting

- [x] 2.1 Add `js/format.js` (number, angle, tolerance, symbol, unit, section field order, search normalisation); verify `tests/unit/format.test.js` passes (angles `40°`, `39°59'49"`, `39.62 -0.2`, symbols, units, search `7,62 x 51`).

## 3. Geometry

- [x] 3.1 Add `js/geometry.js` outer profile (rim type, head, groove, belt, body, shoulder, fillets, neck) with missing-value report; verify `tests/unit/geometry.test.js` for rim types, 308 Win. points, belted ramp, straight case, missing r1 min (338 Lapua Mag.).
- [x] 3.2 Add bullet (seating, cylinder, nose shapes, heeled case) to geometry; verify tests for pointy, rounded, flat, semi_wadcutter and 22 Long Rifle.
- [x] 3.3 Add walls, solid head `w`, primer pocket and hatch polygon; verify tests for tn, tb, w and pocket sizes.

## 4. Drawing

- [x] 4.1 Add `js/drawing.js` SVG output (outside view, section, hatch, centre line, bullet, title block, viewBox in mm, accessible name); verify unit tests for viewBox, aria-label, key coordinates (mouth at 51.18, tip at 71.12 for 308 Win.).
- [x] 4.2 Add dimension lines, extension lines, arrowheads, labels and α with collision-checked placement; verify unit tests for the required labels and for no overlap across all 25 records.

## 5. App shell

- [x] 5.1 Add `index.html`, `css/style.css`, `js/app.js`: list, search, family filter, count, hash routing, detail facts and tables, Print button, scale text; verify Playwright tests on `file://` (list, search, filter, count, detail, reload, back link, tolerances, angle format, no network).
- [x] 5.2 Add print CSS and theme; verify Playwright tests: one A4 page for all 25 cartridges (PDF page count), dark scheme on screen, light in print, phone width without horizontal scroll, drawing label overlap check in the browser, served-by-static-server run.

## 6. Final verification

- [x] 6.1 Run `npm test`; open several cartridges in Playwright MCP at desktop and phone width, view screenshots, fix visual defects.
- [x] 6.2 Review the diff (`requesting-code-review`), apply findings; verify tests still pass.

## Workflow follow-up

- Archive the change with `openspec-archive-change` on the branch before merge.
