# cartridge-drawing Specification

## Purpose
Draws each cartridge from its record as a dimensioned technical drawing, true to scale, so dimensions can be read and checked.

## Requirements

### Requirement: Scaled inline drawing
The detail view SHALL contain an inline SVG named "<name> drawing", computed from the record, with 1 SVG user unit equal to 1 mm, the axis horizontal and the head on the left. The upper half SHALL show the outside view and the lower half a section with hatched cut walls, and a dash-dot centre line SHALL mark the axis.

#### Scenario: Scale
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the SVG has role "img" and accessible name "308 Win. drawing"
- **AND** the outline of the case mouth lies 51.18 user units from the head face and the bullet tip 71.12 user units from it

### Requirement: Outer profile rules
The outer half-profile SHALL be built from the record, from the axis at the head face to the mouth, and mirrored at the axis. It SHALL follow the rules: rim type, head chamfer or rimfire half-round, extractor groove or belt, tapered body, shoulder between the published points with r1 min and r2 fillets where published, and neck to the mouth.

#### Scenario: Rim type
- **WHEN** the rim type is derived
- **THEN** family belted gives belted, family rimfire gives rimfire, otherwise R1/P1 >= 1.05 gives rimmed, R1/P1 < 0.98 gives rebated and anything else gives rimless

#### Scenario: Straight case
- **WHEN** a record has no alpha, L1 or L2
- **THEN** the body runs straight from P1/2 to H2/2 at L3

#### Scenario: Extractor groove
- **WHEN** E and E1 are published
- **THEN** the outline goes in from the rim to E1/2, along the floor by e min, and out by a straight ramp to P1/2 at E

### Requirement: Bullet
The drawing SHALL show the bullet from the mouth to the tip at L6, with shank diameter G1 and the nose shape of `annotations.defaultBulletShape`, using the seating depth, cylinder length, meplat and nose curve defined for each shape. A heeled case SHALL show the exposed bullet at the case's outside diameter and the seated heel at the case's inside diameter. The outside view SHALL hide the seated part; the section SHALL show it.

#### Scenario: Seating depth
- **WHEN** the bullet of a pointy rifle cartridge is built
- **THEN** its base lies G1 below the mouth and the nose is a tangent ogive ending in a flat meplat of diameter max(0.08·G1, 1.27)

#### Scenario: Heeled case
- **WHEN** H2 - G1 <= 0.015 (22 Long Rifle)
- **THEN** the exposed bullet has diameter H2 and the seated heel has diameter H2 - 2·tb

### Requirement: Section walls and head
The section SHALL show the neck wall tn = (H2 - G1)/2 and body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2), blended linearly across the shoulder, a solid head up to a computed depth w, and on centrefire cases a primer pocket sized by primer type. Rimfire cases SHALL have no pocket.

#### Scenario: Primer pocket
- **WHEN** the primer type is "lr"
- **THEN** the pocket has diameter 5.33 and depth 3.3

### Requirement: Missing values
When a value a rule needs is missing, the drawing SHALL omit that feature, SHALL name the missing value in a note below the drawing, and SHALL NOT invent a number.

#### Scenario: Missing r1 min
- **WHEN** the drawing of "338 Lapua Mag." is shown
- **THEN** the body-side shoulder corner is not rounded and the note names "r1 min"

### Requirement: Dimension lines and labels
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, for P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value, such as "L3 51.18". Labels SHALL NOT overlap each other or the outline.

#### Scenario: Labels
- **WHEN** the drawing of "308 Win." is shown
- **THEN** it contains labels "L3 51.18", "L6 71.12", "R1 12.01", "R 1.37", "P1 11.96", "P2 11.53", "H1 8.72", "H2 8.72", "G1 7.85", "L1 39.62", "L2 43.48", "E1 10.39" and "α 40°"

#### Scenario: No overlap
- **WHEN** the drawings of all 25 cartridges are shown
- **THEN** no label box intersects another label box or an outline path

### Requirement: Title block and scale
The drawing SHALL include a title block with the name, C.I.P. table, revision date, "Dimensions in mm" and the scale. The drawing SHALL scale to the width of its container, including a phone screen, and print legibly.

#### Scenario: Title block
- **WHEN** the drawing of "223 Rem." is shown
- **THEN** its title block contains "223 Rem.", "C.I.P. table I", "Revised 2017-05-17", "Dimensions in mm" and "Scale"
