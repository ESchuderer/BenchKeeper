const fs = require('fs');
const os = require('os');
const path = require('path');
const { defineConfig } = require('@playwright/test');

// Use the Chromium the container provides when it differs from the revision this Playwright expects.
function installedChromium() {
  const dir = process.env.PLAYWRIGHT_BROWSERS_PATH || path.join(os.homedir(), '.cache', 'ms-playwright');
  const found = fs.existsSync(dir) ? fs.readdirSync(dir).filter((d) => /^chromium-\d+$/.test(d)).sort().pop() : null;
  const exe = found && path.join(dir, found, 'chrome-linux64', 'chrome');
  return exe && fs.existsSync(exe) ? exe : undefined;
}

module.exports = defineConfig({
  testDir: 'tests/e2e',
  timeout: 30000,
  workers: 4,
  use: {
    browserName: 'chromium',
    launchOptions: { executablePath: process.env.CHROMIUM_PATH || installedChromium(), args: ['--no-sandbox'] },
  },
});
