const { test, expect } = require('@playwright/test');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { INDEX, detailUrl, data } = require('./helpers');

const rowsOf = (page) => page.locator('#rows tr:not([hidden])');
const exactCell = (text) => new RegExp('^' + text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$');
const symRow = (scope, sym) => scope.locator('tr').filter({ has: scope.page().locator('td.sym', { hasText: exactCell(sym) }) });

test.describe('start page', () => {
  test.beforeEach(async ({ page }) => page.goto(INDEX));

  test('heading, 25 rows, count, name links', async ({ page }) => {
    await expect(page.getByRole('heading', { name: 'Cartridges', level: 1 })).toBeVisible();
    await expect(rowsOf(page)).toHaveCount(25);
    await expect(page.getByText('25 cartridges', { exact: true })).toBeVisible();
    await expect(page.getByRole('link', { name: '6,5 Creedmoor', exact: true })).toBeVisible();
    const row = rowsOf(page).filter({ hasText: '308 Win.' });
    await expect(row).toContainText('rimless');
    await expect(row).toContainText('51.18 mm');
  });

  test('every link text is exactly the record name', async ({ page }) => {
    const texts = await rowsOf(page).locator('a').allTextContents();
    expect(texts).toEqual(data.map((r) => r.name));
  });

  test('search finds alternative names as the user types', async ({ page }) => {
    const search = page.getByLabel('Search');
    await search.pressSequentially('7,62 x 51');
    await expect(rowsOf(page)).toHaveCount(1);
    await expect(rowsOf(page)).toContainText('308 Win.');
    await expect(page.getByText('1 cartridges', { exact: true })).toBeVisible();
    await search.fill('');
    await expect(rowsOf(page)).toHaveCount(25);
  });

  test('no match', async ({ page }) => {
    await page.getByLabel('Search').fill('zzzz');
    await expect(page.getByText('0 cartridges', { exact: true })).toBeVisible();
    await expect(rowsOf(page)).toHaveCount(0);
    await expect(page.getByText('No cartridge matches.')).toBeVisible();
  });

  test('family select and its options', async ({ page }) => {
    const family = page.getByLabel('Family');
    expect(await family.locator('option').allTextContents()).toEqual(['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
    await family.selectOption('belted');
    await expect(rowsOf(page)).toHaveCount(2);
    await expect(page.getByText('2 cartridges', { exact: true })).toBeVisible();
    await family.selectOption('rimfire');
    await expect(rowsOf(page)).toHaveCount(3);
    await family.selectOption('All');
    await expect(rowsOf(page)).toHaveCount(25);
  });

  test('search and family combine', async ({ page }) => {
    await page.getByLabel('Family').selectOption('pistol');
    await page.getByLabel('Search').fill('mag');
    await expect(rowsOf(page).locator('a')).toHaveText(['357 Magnum', '44 Rem. Mag.']);
  });
});

test.describe('detail view', () => {
  test('opens from the list, has its own address, survives reload', async ({ page }) => {
    await page.goto(INDEX);
    await page.getByRole('link', { name: '243 Win.', exact: true }).click();
    await expect(page).toHaveURL(/#\/cartridge\/243_win$/);
    await expect(page.getByRole('heading', { name: '243 Win.', level: 1 })).toBeVisible();
    await page.reload();
    await expect(page.getByRole('heading', { name: '243 Win.', level: 1 })).toBeVisible();
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await expect(page.getByRole('heading', { name: 'Cartridges', level: 1 })).toBeVisible();
    // a reload resets the filters; fields and list stay consistent
    await expect(page.getByLabel('Search')).toHaveValue('');
    await expect(rowsOf(page)).toHaveCount(25);
  });

  test('back link keeps search and family filter', async ({ page }) => {
    await page.goto(INDEX);
    await page.getByLabel('Search').fill('win');
    await page.getByLabel('Family').selectOption('rimless');
    await page.getByRole('link', { name: '270 Win.', exact: true }).click();
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await expect(page.getByLabel('Search')).toHaveValue('win');
    await expect(page.getByLabel('Family')).toHaveValue('rimless');
    await expect(rowsOf(page).locator('a')).toHaveText(['243 Win.', '270 Win.', '308 Win.']);
  });

  test('direct address and unknown key', async ({ page }) => {
    await page.goto(detailUrl('308_win'));
    await expect(page.getByRole('heading', { name: '308 Win.', level: 1 })).toBeVisible();
    await page.goto(detailUrl('nope'));
    await page.reload();
    await expect(page.getByRole('heading', { name: 'Cartridge not found' })).toBeVisible();
    await expect(page.getByRole('link', { name: 'All cartridges' })).toBeVisible();
  });

  test('facts of 308 Win.', async ({ page }) => {
    await page.goto(detailUrl('308_win'));
    const fact = (label) => page.locator('.facts div').filter({ has: page.locator('dt', { hasText: exactCell(label) }) }).locator('dd');
    await expect(fact('Alternative names')).toHaveText('308 Winchester, 7,62 x 51');
    await expect(fact('Family')).toHaveText('rimless');
    await expect(fact('Category')).toHaveText('rifle');
    await expect(fact('Primer type')).toHaveText('lr');
    await expect(fact('C.I.P. table')).toHaveText('I');
    await expect(fact('Country')).toHaveText('US');
    await expect(fact('Published')).toHaveText('1984-06-14');
    await expect(fact('Revised')).toHaveText('2008-09-23');
    await expect(fact('Pressure method')).toHaveText('Transducer');
    await expect(fact('Water capacity')).toContainText('56');
    await expect(fact('Water capacity').getByRole('link', { name: 'kwk' })).toHaveAttribute('href', 'http://kwk.us/cases.html');
  });

  test('no published capacity', async ({ page }) => {
    await page.goto(detailUrl('7_x_64'));
    const dd = page.locator('.facts div').filter({ hasText: 'Water capacity' }).locator('dd');
    await expect(dd).toHaveText('not published');
    await expect(dd.getByRole('link')).toHaveCount(0);
  });

  test('tables: columns, units, tolerance, angles, symbols', async ({ page }) => {
    await page.goto(detailUrl('243_win'));
    const lengths = page.getByRole('table', { name: 'Lengths' }).first();
    await expect(lengths.getByRole('columnheader')).toHaveText(['Symbol', 'Value', 'Unit']);
    const cart = page.locator('.tables').first();
    const chamber = page.locator('.tables').nth(1);
    await expect(symRow(cart, 'L1')).toContainText('39.62 -0.2');
    await expect(page.locator('td.sym', { hasText: /Tol/ })).toHaveCount(0);
    await expect(symRow(cart, 'Pmax').locator('td').nth(1)).toHaveText('4150');
    await expect(symRow(cart, 'Pmax').locator('td').nth(2)).toHaveText('bar');
    await expect(symRow(cart, 'EE').locator('td').nth(2)).toHaveText('J');
    await expect(symRow(cart, 'M').locator('td').nth(2)).toHaveText('g');
    await expect(symRow(cart, 'e min')).toHaveCount(1);
    await expect(symRow(cart, 'L3 + G')).toHaveCount(1);
    await expect(symRow(cart, 'delta L')).toHaveCount(1);
    await expect(symRow(cart, 'β').locator('td').nth(1)).toHaveText('35°');
    await expect(symRow(chamber, 'N').locator('td').nth(2)).toHaveText('');
    await expect(symRow(chamber, 'Q').locator('td').nth(2)).toHaveText('mm²');
    await expect(symRow(chamber, 'α1').locator('td').nth(1)).toHaveText('60°');
    await expect(symRow(chamber, 'i').locator('td').nth(1)).toHaveText('1°30\'0"');
  });

  test('DMS angle as published', async ({ page }) => {
    await page.goto(detailUrl('6_5_x_55_se'));
    await expect(symRow(page.locator('.tables').first(), 'α').locator('td').nth(1)).toHaveText('50°35\'2"');
  });

  test('Print calls window.print', async ({ page }) => {
    await page.addInitScript(() => { window.__prints = 0; window.print = () => { window.__prints++; }; });
    await page.goto(detailUrl('223_rem'));
    await page.getByRole('button', { name: 'Print' }).click();
    expect(await page.evaluate(() => window.__prints)).toBe(1);
  });

  test('drawing: accessible name, labels, title block, note for missing value', async ({ page }) => {
    await page.goto(detailUrl('308_win'));
    const svg = page.getByRole('img', { name: '308 Win. drawing' });
    await expect(svg).toBeVisible();
    for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'α 40°']) {
      await expect(svg.locator('text', { hasText: t }).first()).toBeVisible();
    }
    await expect(svg.locator('.titleblock')).toContainText('Dimensions in mm');
    await expect(svg.locator('.titleblock')).toContainText('C.I.P. table I');
    await expect(svg.locator('.titleblock')).toContainText('Revised 2008-09-23');
    await expect(svg.locator('text.scale')).toContainText(/^Scale \d/);
    await expect(page.locator('.notes')).toHaveCount(0);
    await page.goto(detailUrl('338_lapua_mag'));
    await expect(page.locator('.notes')).toContainText('r1 min');
  });

  test('1 unit = 1 mm and the scale text follows the rendered width', async ({ page }) => {
    await page.setViewportSize({ width: 1000, height: 800 });
    await page.goto(detailUrl('308_win'));
    const info = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const pts = svg.querySelector('polyline.outer-upper').points;
      return {
        vbw: svg.viewBox.baseVal.width, w: svg.getBoundingClientRect().width,
        x: pts.getItem(pts.numberOfItems - 1).x, scale: svg.querySelector('text.scale').textContent,
      };
    });
    expect(info.x).toBeCloseTo(51.18, 2);
    const ratio = info.w / info.vbw / (96 / 25.4);
    expect(info.scale).toBe(`Scale ${ratio >= 0.95 ? `${+ratio.toFixed(1)}:1` : `1:${+(1 / ratio).toFixed(1)}`}`);
  });
});

test.describe('delivery', () => {
  test('makes no request other than the app files, no console errors', async ({ page }) => {
    const urls = [];
    const errors = [];
    page.on('request', (r) => urls.push(r.url()));
    page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
    page.on('pageerror', (e) => errors.push(String(e)));
    await page.goto(INDEX);
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    await expect(page.getByRole('img', { name: '308 Win. drawing' })).toBeVisible();
    expect(urls.every((u) => u.startsWith('file://'))).toBe(true);
    expect(errors).toEqual([]);
  });

  test('works from a static file server', async ({ page }) => {
    const root = path.resolve(__dirname, '../..');
    const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
    const server = http.createServer((req, res) => {
      const file = path.join(root, req.url === '/' ? 'index.html' : req.url.split('?')[0]);
      fs.readFile(file, (err, body) => {
        if (err) { res.writeHead(404); res.end(); return; }
        res.writeHead(200, { 'content-type': types[path.extname(file)] || 'text/plain' });
        res.end(body);
      });
    });
    await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
    try {
      await page.goto(`http://127.0.0.1:${server.address().port}/#/cartridge/45_auto`);
      await expect(page.getByRole('heading', { name: '45 Auto', level: 1 })).toBeVisible();
      await expect(page.getByRole('img', { name: '45 Auto drawing' })).toBeVisible();
    } finally {
      server.close();
    }
  });

  test('phone width: no horizontal scroll on list and widest detail views', async ({ page }) => {
    await page.setViewportSize({ width: 360, height: 740 });
    for (const url of [INDEX, detailUrl('338_lapua_mag'), detailUrl('9_3_x_74_r'), detailUrl('22_long_rifle')]) {
      await page.goto(url);
      await page.reload();
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expect(overflow, url).toBeLessThanOrEqual(0);
    }
    const box = await page.locator('svg.drawing').boundingBox();
    expect(box.width).toBeLessThanOrEqual(360);
  });

  test('theme follows the system setting', async ({ page }) => {
    await page.emulateMedia({ colorScheme: 'dark' });
    await page.goto(INDEX);
    const bg = () => page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    expect(await bg()).toBe('rgb(21, 23, 25)');
    await page.emulateMedia({ colorScheme: 'light' });
    expect(await bg()).toBe('rgb(251, 251, 249)');
  });
});
