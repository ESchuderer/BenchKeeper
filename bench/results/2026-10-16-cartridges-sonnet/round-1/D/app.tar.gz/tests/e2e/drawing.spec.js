const { test, expect } = require('@playwright/test');
const { detailUrl, data } = require('./helpers');

// Independent of the layout code: measure rendered text boxes and sampled outline points in the browser.
for (const rec of data) {
  test(`labels do not overlap each other or the outline: ${rec.name}`, async ({ page }) => {
    await page.setViewportSize({ width: 1200, height: 900 });
    await page.goto(detailUrl(rec.key));
    const result = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const labels = [...svg.querySelectorAll('text.label')].map((t) => {
        const r = t.getBoundingClientRect();
        return { text: t.textContent, x0: r.left, x1: r.right, y0: r.top, y1: r.bottom };
      });
      const m = svg.getScreenCTM();
      const points = [];
      for (const el of svg.querySelectorAll('.outline')) {
        const len = el.getTotalLength();
        const n = Math.max(2, Math.ceil(len / 0.2));
        for (let i = 0; i <= n; i++) {
          const p = el.getPointAtLength((len * i) / n);
          points.push({ cls: el.getAttribute('class'), x: p.x * m.a + m.e, y: p.y * m.d + m.f });
        }
      }
      return { labels, points };
    });
    const { labels, points } = result;
    expect(labels.length).toBeGreaterThanOrEqual(7);
    const clash = [];
    labels.forEach((a, i) => {
      labels.slice(i + 1).forEach((b) => {
        if (a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1) clash.push(`${a.text} x ${b.text}`);
      });
      for (const p of points) {
        if (p.x > a.x0 && p.x < a.x1 && p.y > a.y0 && p.y < a.y1) { clash.push(`${a.text} on ${p.cls}`); break; }
      }
    });
    expect(clash).toEqual([]);
  });
}
