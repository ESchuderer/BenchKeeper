const path = require('path');
const { pathToFileURL } = require('url');

exports.INDEX = pathToFileURL(path.resolve(__dirname, '../../index.html')).href;
exports.data = require('../../js/data.js');
exports.detailUrl = (key, base = exports.INDEX) => `${base}#/cartridge/${key}`;
