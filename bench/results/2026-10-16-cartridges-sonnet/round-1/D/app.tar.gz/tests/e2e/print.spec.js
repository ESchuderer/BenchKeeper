const { test, expect } = require('@playwright/test');
const { detailUrl, data } = require('./helpers');

const pageCount = (pdf) => (pdf.toString('latin1').match(/\/Type\s*\/Page(?![s\w])/g) || []).length;

for (const rec of data) {
  test(`prints on one A4 portrait page: ${rec.name}`, async ({ page }) => {
    await page.goto(detailUrl(rec.key));
    await expect(page.getByRole('img', { name: `${rec.name} drawing` })).toBeVisible();
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    expect(pageCount(pdf)).toBe(1);
    expect(pdf.toString('latin1')).toMatch(/\/MediaBox\s*\[\s*0\s+0\s+59[45](\.\d+)?\s+84[12](\.\d+)?\s*\]/);
  });
}

test.describe('print styles', () => {
  test('light, no navigation, footer with source, drawing at full width', async ({ page }) => {
    // 190 mm = A4 width minus 2 x 10 mm margins
    await page.setViewportSize({ width: Math.round((190 / 25.4) * 96), height: 1200 });
    await page.emulateMedia({ colorScheme: 'dark', media: 'print' });
    await page.goto(detailUrl('308_win'));
    await expect(page.locator('.toolbar')).toBeHidden();
    await expect(page.locator('#list-view')).toBeHidden();
    await expect(page.getByRole('button', { name: 'Print' })).toBeHidden();
    await expect(page.getByRole('link', { name: 'All cartridges' })).toBeHidden();
    const footer = page.locator('footer.source');
    await expect(footer).toBeVisible();
    await expect(footer).toContainText('C.I.P. TDCC');
    await expect(footer).toContainText('2008-09-23');
    const colors = await page.evaluate(() => ({
      bg: getComputedStyle(document.body).backgroundColor,
      fg: getComputedStyle(document.body).color,
      label: getComputedStyle(document.querySelector('svg.drawing text.label')).fill,
      h1: getComputedStyle(document.querySelector('h1')).color,
    }));
    expect(colors).toEqual({ bg: 'rgb(255, 255, 255)', fg: 'rgb(0, 0, 0)', label: 'rgb(0, 0, 0)', h1: 'rgb(0, 0, 0)' });
    const box = await page.locator('svg.drawing').boundingBox();
    expect(box.width).toBeGreaterThan(Math.round((190 / 25.4) * 96) - 4);
    await expect(page.locator('svg.drawing text.scale')).toContainText('A4 print');
  });

  test('every label is at least 7 pt when printed at full width', async ({ page }) => {
    for (const rec of data) {
      await page.goto(detailUrl(rec.key));
      const { vbw, vbh } = await page.evaluate(() => ({ vbw: +document.querySelector("svg.drawing").dataset.vbw, vbh: +document.querySelector("svg.drawing").dataset.vbh }));
      // label font 2.6 mm user units, drawing scaled to 190 mm
      const pt = (2.6 * Math.min(190 / vbw, 125 / vbh)) / 0.3528;
      expect(pt, rec.key).toBeGreaterThanOrEqual(7);
    }
  });
});
