const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');

test('25 records with unique keys and names', () => {
  assert.equal(data.length, 25);
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
  assert.equal(new Set(data.map((r) => r.name)).size, 25);
});

test('family counts', () => {
  const n = {};
  for (const r of data) n[r.family] = (n[r.family] || 0) + 1;
  assert.deepEqual(n, { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3 });
});

test('records are unchanged: samples', () => {
  const by = Object.fromEntries(data.map((r) => [r.key, r]));
  assert.equal(by['308_win'].cartridge.lengths.L3, 51.18);
  assert.deepEqual(by['308_win'].alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(by['6_5_creedmoor'].name, '6,5 Creedmoor');
  assert.deepEqual(by['270_win'].chamber.junctionCone.alpha, { degrees: 34, minutes: 30, seconds: 0 });
  assert.equal(by['22_long_rifle'].annotations.primerType, 'rimfire');
  assert.equal(by['17_hmr'].cartridge.junctionCone.S, 28.79);
});
