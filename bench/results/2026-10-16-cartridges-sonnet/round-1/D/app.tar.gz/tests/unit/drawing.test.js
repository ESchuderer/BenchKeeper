const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const D = require('../../js/drawing.js');

const rec = (key) => data.find((r) => r.key === key);
const draw = (key) => D.render(rec(key));
const near = (a, b, eps = 1e-3) => assert.ok(Math.abs(a - b) < eps, `${a} != ${b}`);
const texts = (d) => d.labels.map((l) => l.text);

test('svg root: viewBox in mm, accessible name, no fixed size', () => {
  const d = draw('308_win');
  assert.match(d.svg, /^<svg [^>]*role="img"/);
  assert.match(d.svg, /aria-label="308 Win\. drawing"/);
  assert.match(d.svg, /<title>308 Win\. drawing<\/title>/);
  const vb = d.svg.match(/viewBox="([^"]+)"/)[1].split(' ').map(Number);
  assert.equal(vb.length, 4);
  near(vb[2], d.viewBox.w, 0.01);
  assert.ok(!/ width="/.test(d.svg.match(/^<svg [^>]*>/)[0]));
});

test('name is escaped', () => {
  const d = draw('40_s_w');
  assert.match(d.svg, /aria-label="40 S\.&amp; W\. drawing"/);
  assert.ok(!/S\.& W/.test(d.svg));
});

test('1 unit = 1 mm: mouth at L3, tip at L6 (308 Win.)', () => {
  const d = draw('308_win');
  const upper = d.outlines.find((o) => o.cls === 'outer-upper').pts;
  near(upper[upper.length - 1][0], 51.18);
  near(upper[upper.length - 1][1], -8.72 / 2);
  const bullet = d.outlines.find((o) => o.cls === 'bullet-outside').pts;
  near(Math.max(...bullet.map((p) => p[0])), 71.12);
  const lower = d.outlines.find((o) => o.cls === 'outer-lower').pts;
  near(lower[lower.length - 1][1], 8.72 / 2);
});

test('required labels for 308 Win.', () => {
  const t = texts(draw('308_win'));
  for (const s of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72',
    'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(t.includes(s), `missing label ${s}; have ${t}`);
  }
});

test('labels only for published values', () => {
  const t = texts(draw('9_mm_luger'));
  assert.deepEqual(t.filter((s) => /^(P2|H1|L1|L2|α)/.test(s)), []);
  for (const s of ['L3 19.15', 'L6 29.69', 'R1 9.96', 'R 1.27', 'P1 9.93', 'H2 9.65', 'G1 9.03', 'E1 8.79']) {
    assert.ok(t.includes(s), s);
  }
  assert.ok(!texts(draw('38_special')).some((s) => s.startsWith('E1')));
});

test('angle label formatting as published', () => {
  assert.ok(texts(draw('6_5_x_55_se')).includes('α 50°35\'2"'));
});

test('every dimension has arrowheads and two extension lines', () => {
  const d = draw('308_win');
  const groups = d.svg.match(/<g class="dim"[\s\S]*?<\/g>/g);
  assert.ok(groups.length >= 12);
  for (const g of groups) {
    assert.ok(/marker-end="url\(#arrow(-s)?\)"/.test(g), g);
    assert.ok((g.match(/class="ext"/g) || []).length >= 2 || /data-dim="α"/.test(g), g);
  }
});

test('title block', () => {
  const d = draw('223_rem');
  for (const s of ['223 Rem.', 'C.I.P. table I', 'Revised 2017-05-17', 'Dimensions in mm', 'Scale']) {
    assert.ok(d.svg.includes(s), s);
  }
});

test('missing values are listed, not invented', () => {
  assert.deepEqual(draw('338_lapua_mag').notes.map((n) => n.split(' ')[0] + ' ' + n.split(' ')[1]), ['r1 min']);
  assert.deepEqual(draw('308_win').notes, []);
});

test('section: hatch pattern and centre line', () => {
  const d = draw('308_win');
  assert.match(d.svg, /<pattern id="hatch"/);
  assert.match(d.svg, /class="cut"[^>]*fill="url\(#hatch\)"/);
  assert.match(d.svg, /class="center"/);
});

function inter(box, [a, b]) {
  // segment-box intersection (sampled finely)
  const n = 200;
  for (let i = 0; i <= n; i++) {
    const x = a[0] + ((b[0] - a[0]) * i) / n, y = a[1] + ((b[1] - a[1]) * i) / n;
    if (x > box.x0 && x < box.x1 && y > box.y0 && y < box.y1) return true;
  }
  return false;
}

test('no label overlaps another label or an outline: all 25 cartridges', () => {
  for (const r of data) {
    const d = D.render(r);
    const L = d.labels;
    for (let i = 0; i < L.length; i++) {
      for (let j = i + 1; j < L.length; j++) {
        const a = L[i].box, b = L[j].box;
        const hit = a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
        assert.ok(!hit, `${r.key}: "${L[i].text}" overlaps "${L[j].text}"`);
      }
      for (const o of d.outlines) {
        for (let k = 1; k < o.pts.length; k++) {
          assert.ok(!inter(L[i].box, [o.pts[k - 1], o.pts[k]]), `${r.key}: "${L[i].text}" touches outline ${o.cls}`);
        }
      }
    }
  }
});

test('no label is crossed by an extension or dimension line: all 25 cartridges', () => {
  const cross = (b, [p, q]) => {
    const n = 200;
    for (let i = 0; i <= n; i++) {
      const x = p[0] + ((q[0] - p[0]) * i) / n, y = p[1] + ((q[1] - p[1]) * i) / n;
      if (x > b.x0 && x < b.x1 && y > b.y0 && y < b.y1) return true;
    }
    return false;
  };
  for (const r of data) {
    const d = D.render(r);
    for (const l of d.labels) {
      for (const seg of d.thin) assert.ok(!cross(l.box, seg), `${r.key}: "${l.text}" crossed by a line`);
    }
  }
});

test('every drawing has all required labels', () => {
  for (const r of data) {
    const t = texts(D.render(r));
    const c = r.cartridge;
    for (const [sym, v] of [['L3', c.lengths.L3], ['L6', c.lengths.L6], ['R1', c.caseHead.R1], ['R', c.caseHead.R],
      ['P1', c.powderChamber.P1], ['H2', c.collar.H2], ['G1', c.projectile.G1]]) {
      assert.ok(t.includes(`${sym} ${v}`), `${r.key} ${sym}`);
    }
    for (const [sym, v] of [['P2', c.powderChamber.P2], ['H1', c.collar.H1], ['L1', c.lengths.L1],
      ['L2', c.lengths.L2], ['E1', c.caseHead.E1]]) {
      if (v !== undefined) assert.ok(t.includes(`${sym} ${v}`), `${r.key} ${sym}`);
    }
    if ((c.junctionCone || {}).alpha !== undefined) assert.ok(t.some((s) => s.startsWith('α ')), `${r.key} alpha`);
  }
});

test('scale text', () => {
  assert.equal(D.scaleText(1), '1:1');
  assert.equal(D.scaleText(2.5), '2.5:1');
  assert.equal(D.scaleText(0.5), '1:2');
  assert.equal(D.scaleText(0.7), '1:1.4');
});

test('section outline starts at the primer pocket edge, not across the pocket mouth', () => {
  const lower = draw('308_win').outlines.find((o) => o.cls === 'outer-lower').pts;
  near(lower[0][1], 5.33 / 2);
  const rimfire = draw('22_long_rifle').outlines.find((o) => o.cls === 'outer-lower').pts;
  assert.deepEqual(rimfire[0], [0, 0]);
});
