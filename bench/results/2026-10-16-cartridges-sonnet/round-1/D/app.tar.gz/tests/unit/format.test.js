const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const F = require('../../js/format.js');

const rec = (key) => data.find((r) => r.key === key);
const rows = (key, group) =>
  Object.fromEntries(F.sections(rec(key))[group].flatMap((s) => s.rows.map((r) => [r.symbol, r])));

test('angles', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(46.0), '46°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
  assert.ok(Math.abs(F.toDegrees({ degrees: 39, minutes: 59, seconds: 49 }) - 39.99694) < 1e-4);
  assert.equal(F.toDegrees(35), 35);
});

test('numbers as published', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150.0), '4150');
  assert.equal(F.formatNumber(0.1), '0.1');
});

test('symbols', () => {
  const s = F.symbol;
  assert.deepEqual(
    ['eMin', 'r1Min', 'r1Max', 'alpha', 'alpha1', 'beta', 'delta', 'deltaL', 'L3PlusG', 'L3', 'P1'].map(s),
    ['e min', 'r1 min', 'r1 max', 'α', 'α1', 'β', 'δ', 'delta L', 'L3 + G', 'L3', 'P1']
  );
});

test('units', () => {
  assert.deepEqual(
    ['L3', 'Pmax', 'PK', 'PE', 'EE', 'M', 'Q', 'N', 'alpha', 'i', 'Z'].map(F.unit),
    ['mm', 'bar', 'bar', 'bar', 'J', 'g', 'mm²', '', '°', '°', 'mm']
  );
});

test('308 Win. cartridge rows', () => {
  const r = rows('308_win', 'cartridge');
  assert.deepEqual([r.L3.value, r.L3.unit], ['51.18', 'mm']);
  assert.deepEqual([r.Pmax.value, r.Pmax.unit], ['4150', 'bar']);
  assert.equal(r.L1.value, '39.62 -0.2');
  assert.equal(r.P2.value, '11.53 -0.2');
  assert.equal(r['α'].value, '40°');
  assert.equal(r['L3 + G'].value, '58.16');
  assert.ok(!('L1Tol' in r));
  assert.ok(!Object.keys(r).some((k) => /Tol$/.test(k)));
});

test('chamber rows and DMS', () => {
  const r = rows('270_win', 'chamber');
  assert.equal(r['α'].value, '34°30\'0"');
  assert.equal(r.N.value, '4');
  assert.equal(r.N.unit, '');
  assert.equal(r.Q.unit, 'mm²');
  assert.equal(r['r1 max'].value, '0.76');
});

test('every field of every record appears once, Tol folded', () => {
  for (const rc of data) {
    for (const group of ['cartridge', 'chamber']) {
      let expected = 0;
      for (const sec of Object.values(rc[group])) {
        expected += Object.keys(sec).filter((k) => !/Tol$/.test(k)).length;
      }
      const got = F.sections(rc)[group].reduce((n, s) => n + s.rows.length, 0);
      assert.equal(got, expected, `${rc.key} ${group}`);
    }
  }
});

test('empty sections are omitted', () => {
  const titles = F.sections(rec('9_mm_luger')).cartridge.map((s) => s.title);
  assert.ok(!titles.includes('Junction cone'));
  assert.ok(titles.includes('Case head'));
});

test('search ignores case and spaces, covers alternative names', () => {
  const hit = (q) => data.filter((r) => F.matches(r, q, 'All')).map((r) => r.name);
  assert.deepEqual(hit('7,62 x 51'), ['308 Win.']);
  assert.deepEqual(hit('7,62x51'), ['308 Win.']);
  assert.equal(hit('').length, 25);
  assert.deepEqual(hit('zzz'), []);
  assert.ok(hit('30-06').includes('30-06 Spring.'));
  assert.ok(hit('22lr').includes('22 Long Rifle'));
});

test('family filter', () => {
  const n = (f) => data.filter((r) => F.matches(r, '', f)).length;
  assert.deepEqual(['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'].map(n), [25, 12, 2, 2, 6, 3]);
});
