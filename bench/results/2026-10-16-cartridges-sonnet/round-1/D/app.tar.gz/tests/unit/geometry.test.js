const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const G = require('../../js/geometry.js');

const rec = (key) => data.find((r) => r.key === key);
const model = (key) => G.build(rec(key));
const near = (a, b, eps = 1e-3) => assert.ok(Math.abs(a - b) < eps, `${a} != ${b}`);
const has = (pts, r, z, eps = 1e-3) =>
  assert.ok(pts.some((p) => Math.abs(p[0] - r) < eps && Math.abs(p[1] - z) < eps), `missing point [${r}, ${z}]`);
const tan = (d) => Math.tan((d * Math.PI) / 180);

test('rim type', () => {
  assert.equal(model('223_rem').rimType, 'rimless');
  assert.equal(model('300_win_mag').rimType, 'belted');
  assert.equal(model('7_mm_rem_mag').rimType, 'belted');
  assert.equal(model('22_long_rifle').rimType, 'rimfire');
  assert.equal(model('9_3_x_74_r').rimType, 'rimmed');
  assert.equal(model('38_special').rimType, 'rimmed');
  assert.equal(model('9_mm_luger').rimType, 'rimless');
  const r = structuredClone(rec('223_rem'));
  r.cartridge.caseHead.R1 = 9.58 * 1.05;
  assert.equal(G.build(r).rimType, 'rimmed');
  r.cartridge.caseHead.R1 = 9.58 * 0.97;
  assert.equal(G.build(r).rimType, 'rebated');
  r.cartridge.caseHead.R1 = 9.58 * 0.98;
  assert.equal(G.build(r).rimType, 'rimless');
});

test('308 Win. outer profile: head, groove, body, mouth', () => {
  const m = model('308_win');
  assert.deepEqual(m.outer[0], [0, 0]);
  const c = Math.min(0.38 * tan(35), 12.01 / 4);
  has(m.outer, 6.005 - c, 0);
  has(m.outer, 6.005, 0.38);
  has(m.outer, 6.005, 1.37);
  has(m.outer, 10.39 / 2, 1.37);
  has(m.outer, 10.39 / 2, 1.37 + 1.4);
  has(m.outer, 11.96 / 2, 3.85);
  near(m.bodyStartZ, 3.85);
  const last = m.outer[m.outer.length - 1];
  near(last[0], 8.72 / 2);
  near(last[1], 51.18);
  for (let i = 1; i < m.outer.length; i++) assert.ok(m.outer[i][1] >= m.outer[i - 1][1] - 1e-9, `z decreases at ${i}`);
  assert.deepEqual(m.shoulder.p1, [11.53 / 2, 39.62]);
  assert.deepEqual(m.shoulder.p2, [8.72 / 2, 43.48]);
  assert.deepEqual(m.missing, []);
});

test('fillets replace shoulder corners and stay close to them', () => {
  const m = model('308_win');
  const dist = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]);
  const nearest = (q) => Math.min(...m.outer.map((p) => dist(p, q)));
  assert.ok(nearest(m.shoulder.p1) > 1e-6 && nearest(m.shoulder.p1) < 0.2);
  assert.ok(nearest(m.shoulder.p2) > 1e-6 && nearest(m.shoulder.p2) < 1.0);
});

test('missing r1 min and r2 are reported, corners stay sharp', () => {
  const m = model('338_lapua_mag');
  assert.deepEqual(m.missing.map((x) => x.symbol), ['r1 min']);
  has(m.outer, 13.82 / 2, 54.9);
  const h = model('17_hmr');
  assert.deepEqual(h.missing.map((x) => x.symbol), ['r1 min', 'r2']);
});

test('belted: ramp at delta to the belt, belt to E, step in', () => {
  const m = model('300_win_mag');
  const zf = 1.27 + 0.94;
  const zr = zf + (13.51 / 2 - 12.07 / 2) / tan(35);
  has(m.outer, 12.07 / 2, zf);
  has(m.outer, 13.51 / 2, zr);
  has(m.outer, 13.51 / 2, 5.59);
  has(m.outer, 13.03 / 2, 5.59);
  near(m.belt.rampEndZ, zr);
  near(m.bodyStartZ, 5.59);
});

test('rimfire half-round and straight case', () => {
  const m = model('22_long_rifle');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  has(m.outer, 7.06 / 2, 1.09 / 2);
  has(m.outer, 7.06 / 2 - rho, 0);
  assert.ok(Math.max(...m.outer.map((p) => p[0])) <= 7.06 / 2 + 1e-9);
  assert.equal(m.shoulder, null);
  assert.deepEqual(m.missing, []);
  const w = model('22_win_mag_r_f');
  assert.equal(w.shoulder, null);
  assert.deepEqual(w.missing, []);
  const last = w.outer[w.outer.length - 1];
  assert.deepEqual(last, [6.15 / 2, 26.8]);
});

test('no groove: step in at R (rimmed pistol)', () => {
  const m = model('38_special');
  has(m.outer, 11.18 / 2, 1.5);
  has(m.outer, 9.63 / 2, 1.5);
  near(m.bodyStartZ, 1.5);
});

test('straight pistol case runs from P1/2 to H2/2 at L3', () => {
  const m = model('9_mm_luger');
  assert.deepEqual(m.outer[m.outer.length - 1], [9.65 / 2, 19.15]);
  has(m.outer, 9.93 / 2, 2.98);
});

test('bullet: pointy tangent ogive (308 Win.)', () => {
  const b = model('308_win').bullet;
  const G1 = 7.85;
  near(b.s, G1);
  near(b.zb, 51.18 - G1);
  const Lb = 71.12 - b.zb;
  near(b.zc, b.zb + 0.4 * Lb);
  near(b.m, Math.max(0.08 * G1, 1.27));
  assert.deepEqual(b.full[0], [0, b.zb]);
  has(b.full, G1 / 2, b.zb);
  has(b.full, G1 / 2, b.zc);
  has(b.full, b.m / 2, 71.12);
  assert.deepEqual(b.full[b.full.length - 1], [0, 71.12]);
  const n = 71.12 - b.zc;
  const d = G1 / 2 - b.m / 2;
  const rho = (d * d + n * n) / (2 * d);
  const cr = G1 / 2 - rho;
  for (const p of b.full.filter((p) => p[1] > b.zc + 1e-6 && p[1] < 71.12 - 1e-6)) {
    near(Math.hypot(p[0] - cr, p[1] - b.zc), rho, 1e-6);
  }
  near(b.exposed[0][1], 51.18);
  near(b.exposed[0][0], G1 / 2);
  assert.ok(b.exposed.every((p) => p[1] >= 51.18 - 1e-9));
});

test('bullet shapes: seating depth, cylinder fraction, meplat', () => {
  const chk = (key, sFrac, k, mFrac) => {
    const m = model(key);
    const G1 = m.dims.G1;
    const b = m.bullet;
    near(b.s, sFrac * G1);
    near(b.zc, b.zb + k * (m.dims.L6 - b.zb));
    near(b.m, mFrac * G1);
  };
  chk('45_auto', 0.4, 0.65, 0.15); // rounded, pistol
  chk('22_long_rifle', 0.8, 0.55, 0.15); // rounded, rimfire
  chk('40_s_w', 0.4, 0.7, 0.55); // flat, pistol
  chk('357_magnum', 0.6, 0.78, 0.6); // semi_wadcutter
});

test('rounded nose is a quarter ellipse ending in the meplat', () => {
  const m = model('45_auto');
  const b = m.bullet;
  const a = m.dims.G1 / 2 - b.m / 2;
  const n = m.dims.L6 - b.zc;
  for (const p of b.full.filter((p) => p[1] > b.zc + 1e-6 && p[1] < m.dims.L6 - 1e-6)) {
    near(((p[0] - b.m / 2) / a) ** 2 + ((p[1] - b.zc) / n) ** 2, 1, 1e-6);
  }
});

test('heeled case (22 Long Rifle)', () => {
  const m = model('22_long_rifle');
  const b = m.bullet;
  assert.equal(m.walls.heeled, true);
  near(m.walls.tb, 0.6);
  near(b.rb, 5.72 / 2);
  near(b.rHeel, (5.72 - 2 * 0.6) / 2);
  has(b.full, b.rHeel, b.zb);
  has(b.full, b.rHeel, 15.57);
  has(b.full, 5.72 / 2, 15.57);
  near(b.exposed[0][0], 5.72 / 2);
  near(model('308_win').bullet.rHeel ?? 0, 0);
});

test('walls and solid head depth w', () => {
  let m = model('308_win');
  near(m.walls.tn, (8.72 - 7.85) / 2);
  near(m.walls.tb, 0.6);
  near(m.w, 3.3 + 1.5);
  m = model('223_rem');
  near(m.w, 3.04 + 1.5);
  m = model('300_win_mag');
  near(m.w, 3.3 + 1.5);
  m = model('22_long_rifle');
  near(m.w, 2.5);
  const big = structuredClone(rec('308_win'));
  big.cartridge.caseHead.E = 6;
  near(G.build(big).w, 6 + 0.6);
});

test('body wall limit 0.35 * P1/2 and 1.3 tn', () => {
  const r = structuredClone(rec('308_win'));
  r.cartridge.projectile.G1 = 6.0; // tn = 1.36, 1.3 tn = 1.77, 0.35 P1/2 = 2.093
  near(G.build(r).walls.tb, 1.3 * 1.36);
  r.cartridge.powderChamber.P1 = 4.0; // 0.35 * 2 = 0.7
  near(G.build(r).walls.tb, 0.7);
});

test('primer pocket by primer type', () => {
  assert.deepEqual(model('308_win').pocket, { diameter: 5.33, depth: 3.3 });
  assert.deepEqual(model('223_rem').pocket, { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(model('44_rem_mag').pocket, { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(model('357_magnum').pocket, { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(model('45_auto').pocket, { diameter: 5.33, depth: 3.04 });
  assert.equal(model('22_long_rifle').pocket, null);
});

test('inner line follows the body at the walls', () => {
  const m = model('308_win');
  const { tn, tb } = m.walls;
  const last = m.inner[m.inner.length - 1];
  near(last[0], 8.72 / 2 - tn);
  near(last[1], 51.18);
  near(last[0], 7.85 / 2); // snug around the bullet
  near(m.inner[0][1], m.w);
  near(m.inner[0][0], 11.96 / 2 - tb, 0.05);
  // blended across the shoulder
  const at = (pts, z) => {
    const i = pts.findIndex((p) => p[1] >= z);
    const [a, b] = [pts[i - 1], pts[i]];
    return a[0] + ((b[0] - a[0]) * (z - a[1])) / (b[1] - a[1]);
  };
  const zm = (39.62 + 43.48) / 2;
  near(at(m.body, zm) - at(m.inner, zm), (tb + tn) / 2, 0.02);
});

test('hatch polygon excludes the primer pocket', () => {
  const m = model('308_win');
  has(m.hatch, 5.33 / 2, 0);
  has(m.hatch, 5.33 / 2, 3.3);
  has(m.hatch, 0, 3.3);
  has(m.hatch, 0, m.w);
});

test('every record builds without throwing and outline z never decreases', () => {
  for (const r of data) {
    const m = G.build(r);
    assert.ok(m.outer.length > 4, r.key);
    for (let i = 1; i < m.outer.length; i++) assert.ok(m.outer[i][1] >= m.outer[i - 1][1] - 1e-9, `${r.key} ${i}`);
    assert.ok(m.bullet, r.key);
    assert.ok(m.inner.every((p) => p[0] > 0), `${r.key} inner radius positive`);
    assert.ok(m.w < r.cartridge.lengths.L3, r.key);
  }
});

test('seated bullet never overlaps the inner wall (all records, not heeled)', () => {
  for (const r of data) {
    const m = G.build(r);
    if (m.walls.heeled) continue;
    const at = (z) => {
      const i = m.inner.findIndex((p) => p[1] >= z);
      if (i <= 0) return m.inner[Math.max(i, 0)][0];
      const [a, b] = [m.inner[i - 1], m.inner[i]];
      return a[0] + ((b[0] - a[0]) * (z - a[1])) / (b[1] - a[1]);
    };
    for (let z = m.bullet.zb; z <= r.cartridge.lengths.L3; z += 0.25) {
      assert.ok(at(z) >= m.bullet.rb - 1e-6, `${r.key} z=${z}: inner ${at(z)} < bullet ${m.bullet.rb}`);
    }
  }
});

test('without G1 the neck wall is not invented', () => {
  const r = structuredClone(rec('308_win'));
  delete r.cartridge.projectile.G1;
  const m = G.build(r);
  assert.ok(m.missing.some((x) => x.symbol === 'G1'));
  assert.equal(m.walls.tn, null);
  assert.equal(m.bullet, null);
});
