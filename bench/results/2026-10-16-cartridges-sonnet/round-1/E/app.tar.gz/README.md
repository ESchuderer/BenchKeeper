# C.I.P. cartridge database

Static reference for 25 C.I.P. cartridges (data: OpenBallistics, MIT, commit e83db43). Open `index.html` directly or serve the folder.

- `npm run serve`: static server on http://127.0.0.1:8080/
- `npm test`: unit tests (`node:test`) and browser tests (`playwright-core` with the cached Chromium; set `CHROME` to override the path)
- Layout: `js/data.js` records, `js/format.js` display values, `js/geometry.js` profile rules, `js/drawing.js` SVG, `js/app.js` UI, `css/` screen and print
