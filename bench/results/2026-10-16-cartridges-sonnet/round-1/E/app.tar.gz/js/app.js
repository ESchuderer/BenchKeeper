// Start page, detail view and hash routing.
(function () {
  const { records, format, drawing } = window.CIP;
  const PRINT_BOX_MM = [190, 106]; // drawing box on A4 portrait: content width, max height (see print.css)
  const MM_PER_PX = 25.4 / 96;
  const NARROW = window.matchMedia('(max-width: 640px)');
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const listView = $('list-view');
  const detailView = $('detail-view');
  let current = null; // record shown in the detail view
  let printing = false;
  let observer = null;

  function renderList() {
    const shown = format.filterRecords(records, $('search').value, $('family').value);
    $('list').tBodies[0].innerHTML = shown
      .map(
        (r) =>
          `<tr><td><a href="#/cartridge/${esc(encodeURIComponent(r.key))}">${esc(r.name)}</a></td><td>${esc(r.family)}</td>` +
          `<td class="num">${format.number(r.cartridge.lengths.L3)} mm</td></tr>`
      )
      .join('');
    $('count').textContent = `${shown.length} cartridges`;
  }

  function factsHtml(record) {
    return format
      .facts(record)
      .map((f) => {
        let value = esc(f.value);
        if (f.capacity) {
          const c = f.capacity;
          value = `${esc(c.value)} ${esc(c.unit)} (<a href="${esc(c.url)}" rel="noopener noreferrer">${esc(c.source)}</a>${c.note ? `, ${esc(c.note)}` : ''})`;
        }
        return `<div><dt>${esc(f.label)}</dt><dd>${value}</dd></div>`;
      })
      .join('');
  }

  function tablesHtml(sections) {
    return sections
      .map(
        (s) =>
          `<table><caption>${esc(s.title)}</caption><thead><tr><th scope="col">Symbol</th><th scope="col" class="num">Value</th><th scope="col">Unit</th></tr></thead><tbody>` +
          s.rows.map((r) => `<tr><th scope="row">${esc(r.symbol)}</th><td class="num">${esc(r.value)}</td><td>${esc(r.unit)}</td></tr>`).join('') +
          '</tbody></table>'
      )
      .join('');
  }

  function figureHtml(record) {
    const d = drawing.build(record, { titleBelow: !printing && NARROW.matches });
    const notes = d.notes.map((n) => `<p>${esc(n)}</p>`).join('');
    return d.svg + (notes ? `<figcaption>${notes}</figcaption>` : '');
  }

  function updateScale() {
    const svg = detailView.querySelector('svg.drawing');
    if (!svg) return;
    const r = svg.getBoundingClientRect();
    const [w, h] = printing ? PRINT_BOX_MM : [r.width * MM_PER_PX, r.height * MM_PER_PX];
    if (w && h) drawing.setScale(svg, w, h);
  }

  // Draws the figure again (layout depends on screen width and on printing) and keeps the scale text current.
  function renderFigure() {
    if (!current) return;
    const figure = detailView.querySelector('figure.drawing');
    figure.innerHTML = figureHtml(current);
    if (observer) observer.disconnect();
    observer = new ResizeObserver(updateScale);
    observer.observe(figure.querySelector('svg'));
    updateScale();
  }

  function renderDetail(record) {
    const g = format.sections(record);
    detailView.innerHTML =
      `<nav class="toolbar"><a href="#/">All cartridges</a><button type="button" id="print">Print</button></nav>` +
      `<h1 tabindex="-1">${esc(record.name)}</h1>` +
      `<dl class="facts">${factsHtml(record)}</dl>` +
      `<figure class="drawing"></figure>` +
      `<section class="values" aria-labelledby="h-cartridge"><h2 id="h-cartridge">Cartridge values</h2><div class="tables">${tablesHtml(g.cartridge)}</div></section>` +
      `<section class="values" aria-labelledby="h-chamber"><h2 id="h-chamber">Chamber values</h2><div class="tables">${tablesHtml(g.chamber)}</div></section>` +
      `<footer class="source">Source: C.I.P. TDCC, revised ${esc(record.revised)}</footer>`;
    $('print').addEventListener('click', () => window.print());
    current = record;
    renderFigure();
  }

  function show(view, title) {
    listView.hidden = view !== 'list';
    detailView.hidden = view === 'list';
    document.title = `${title} - C.I.P. cartridge database`;
    if (view === 'list') {
      current = null;
      if (observer) observer.disconnect();
      detailView.innerHTML = '';
    }
  }

  function route() {
    const hash = location.hash;
    if (!hash || hash === '#' || hash === '#/') {
      show('list', 'Cartridges');
      window.scrollTo(0, 0);
      return;
    }
    const m = hash.match(/^#\/cartridge\/([^/?]+)$/);
    let key = null;
    try { key = m && decodeURIComponent(m[1]); } catch (e) { /* malformed escape: treated as unknown */ }
    const record = records.find((r) => r.key === key);
    show('detail', record ? record.name : 'Cartridge not found');
    if (record) renderDetail(record);
    else {
      current = null;
      detailView.innerHTML = '<nav class="toolbar"><a href="#/">All cartridges</a></nav><h1 tabindex="-1">Cartridge not found</h1><p>No cartridge has this address.</p>';
    }
    window.scrollTo(0, 0);
    detailView.querySelector('h1').focus({ preventScroll: true });
  }

  $('search').addEventListener('input', renderList);
  $('family').addEventListener('change', renderList);
  document.querySelector('form.controls').addEventListener('submit', (e) => e.preventDefault());
  window.addEventListener('hashchange', route);
  NARROW.addEventListener('change', renderFigure);
  window.addEventListener('beforeprint', () => { printing = true; renderFigure(); });
  window.addEventListener('afterprint', () => { printing = false; renderFigure(); });

  renderList();
  route();
})();
