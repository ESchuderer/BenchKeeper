// SVG drawing of a cartridge. 1 user unit = 1 mm; x = z (axis, head at the left); y = -r in the outside view, +r in the section.
(function (g) {
  const CIP = g.CIP || (g.CIP = {});
  const { geometry, format } = CIP;

  const FS = 3; // label font size
  const CHAR_W = 0.62 * FS; // monospace advance, estimated
  const ASC = 0.95 * FS;
  const DESC = 0.25 * FS;
  const ARROW_L = 1.6;
  const ARROW_W = 0.5;
  const GAP = 0.8; // between feature and extension line
  const OVER = 1.2; // extension line past the dimension line
  const PAD = 0.35; // label clearance
  const LEVEL_STEP = 7;
  const COL_STEP = 5.4;
  const ROW_STEP = 4.4;
  const MARGIN = 3;
  const TITLE_W = 44;

  const f3 = (n) => +n.toFixed(3);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // ---- geometry helpers (exported for tests) ----
  function segHitsRect(s, r) {
    let [x1, y1, x2, y2] = s;
    let t0 = 0;
    let t1 = 1;
    const dx = x2 - x1;
    const dy = y2 - y1;
    for (const [p, q] of [[-dx, x1 - r.x], [dx, r.x + r.w - x1], [-dy, y1 - r.y], [dy, r.y + r.h - y1]]) {
      if (p === 0) {
        if (q < 0) return false;
      } else {
        const t = q / p;
        if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return true;
  }
  function pointInPoly(pt, poly) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const [xi, yi] = poly[i];
      const [xj, yj] = poly[j];
      if (yi > pt[1] !== yj > pt[1] && pt[0] < ((xj - xi) * (pt[1] - yi)) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  }
  function polyHitsRect(poly, r) {
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i];
      const b = poly[(i + 1) % poly.length];
      if (segHitsRect([a[0], a[1], b[0], b[1]], r)) return true;
    }
    return pointInPoly([r.x + r.w / 2, r.y + r.h / 2], poly);
  }
  const rectsOverlap = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
  const inflate = (r, p) => ({ x: r.x - p, y: r.y - p, w: r.w + 2 * p, h: r.h + 2 * p });

  function formatScale(ratio) {
    const t = (n) => String(+n.toFixed(1));
    return ratio >= 1 ? `${t(ratio)}:1` : `1:${t(1 / ratio)}`;
  }

  // ---- builder ----
  // opts.titleBelow puts the title block under the drawing (narrow screens); default is right of the dimensions.
  function build(rec, opts = {}) {
    const geo = geometry.compute(rec);
    if (geo.missing.length) {
      return { svg: unavailableSvg(rec, geo), labels: [], notes: geo.notes, segments: [], keepOut: [], viewBox: [0, 0, 100, 20] };
    }
    const v = geo.values;
    const { profile, inner, bullet, pocket, w } = geo;
    const rMax = Math.max(...profile.map((p) => p[0]));

    const out = { outline: [], hatch: [], thin: [], arrows: [], text: [], misc: [] };
    const segs = [];
    const boxes = [];
    const labels = [];
    const bounds = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    const grow = (x, y) => {
      bounds.x0 = Math.min(bounds.x0, x); bounds.x1 = Math.max(bounds.x1, x);
      bounds.y0 = Math.min(bounds.y0, y); bounds.y1 = Math.max(bounds.y1, y);
    };
    const growBox = (b) => { grow(b.x, b.y); grow(b.x + b.w, b.y + b.h); };

    const pts = (list) => list.map((p) => `${f3(p[0])},${f3(p[1])}`).join(' ');
    const upper = (list) => list.map(([r, z]) => [z, -r]);
    const lower = (list) => list.map(([r, z]) => [z, r]);
    function poly(group, list, cls, closed) {
      out[group].push(`<${closed ? 'polygon' : 'polyline'} class="${cls}" points="${pts(list)}"/>`);
      list.forEach((p) => grow(p[0], p[1]));
      return list;
    }
    const addSegs = (list, closed) => {
      for (let i = 0; i + 1 < list.length; i++) segs.push([...list[i], ...list[i + 1]]);
      if (closed) segs.push([...list[list.length - 1], ...list[0]]);
    };
    function line(x1, y1, x2, y2, cls = 'dr-thin') {
      out.thin.push(`<line class="${cls}" x1="${f3(x1)}" y1="${f3(y1)}" x2="${f3(x2)}" y2="${f3(y2)}"/>`);
      segs.push([x1, y1, x2, y2]);
      grow(x1, y1); grow(x2, y2);
    }
    // Arrowhead with its tip at (x, y); (dx, dy) points from the tip along the line.
    function arrow(x, y, dx, dy) {
      const cx = x + dx * ARROW_L;
      const cy = y + dy * ARROW_L;
      out.arrows.push(`<polygon class="dr-arrow" points="${pts([[x, y], [cx - dy * ARROW_W, cy + dx * ARROW_W], [cx + dy * ARROW_W, cy - dx * ARROW_W]])}"/>`);
    }
    const hDim = (x1, x2, y) => {
      const outside = x2 - x1 < 3 * ARROW_L;
      if (outside) line(x1 - 2 * ARROW_L, y, x2 + 2 * ARROW_L, y);
      else line(x1, y, x2, y);
      arrow(x1, y, outside ? -1 : 1, 0);
      arrow(x2, y, outside ? 1 : -1, 0);
    };
    const vDim = (x, y1, y2) => {
      line(x, y1, x, y2);
      arrow(x, y1, 0, 1);
      arrow(x, y2, 0, -1);
    };

    // ---- outline, section, centre line ----
    const upperPoly = upper([...profile, ...bullet.exposed]);
    const lowerPoly = lower([...profile, ...bullet.exposed]);
    const keepOut = [upperPoly, lowerPoly];

    const headStart = pocket ? pocket.diameter / 2 : 0;
    poly('outline', upperPoly, 'dr-outline', false);
    addSegs(upperPoly);
    if (bullet.heeled) line(v.L3, 0, v.L3, -v.H2 / 2, 'dr-outline');

    const lowerOuter = lower([[headStart, 0], ...profile.slice(1)]);
    const lowerInner = lower(inner);
    poly('outline', lowerOuter, 'dr-outline', false);
    addSegs(lowerOuter);
    const wallLine = [lowerOuter[lowerOuter.length - 1], ...lowerInner.slice().reverse(), [w, 0]];
    poly('outline', wallLine, 'dr-outline', false);
    addSegs(wallLine);
    const hatchPoly = [...lowerOuter, ...lowerInner.slice().reverse(), [w, 0]];
    if (pocket) hatchPoly.push([pocket.depth, 0], [pocket.depth, pocket.diameter / 2]);
    else hatchPoly.push([0, 0]);
    out.hatch.push(`<polygon class="dr-hatch" points="${pts(hatchPoly)}"/>`);
    if (pocket) {
      const pk = [[pocket.depth, 0], [pocket.depth, pocket.diameter / 2], [0, pocket.diameter / 2]];
      poly('outline', pk, 'dr-outline', false);
      addSegs(pk);
    }
    const bulletSection = lower(bullet.section);
    out.misc.push(`<polygon class="dr-bullet" points="${pts(bulletSection)}"/>`);
    addSegs(bulletSection, false);
    const axisY0 = -4;
    const axisX1 = v.L6 + 4;
    out.thin.push(`<line class="dr-centre" x1="${axisY0}" y1="0" x2="${axisX1}" y2="0"/>`);
    segs.push([axisY0, 0, axisX1, 0]);
    grow(axisY0, 0); grow(axisX1, 0);

    // ---- labels ----
    const textBox = (text, x, y, anchor, rot) => {
      const wd = text.length * CHAR_W;
      if (rot) return anchor === 'end' ? { x: x - ASC, y, w: ASC + DESC, h: wd } : { x: x - ASC, y: y - wd, w: ASC + DESC, h: wd };
      const x0 = anchor === 'middle' ? x - wd / 2 : anchor === 'end' ? x - wd : x;
      return { x: x0, y: y - ASC, w: wd, h: ASC + DESC };
    };
    const isFree = (b) => {
      const p = inflate(b, PAD);
      return !segs.some((s) => segHitsRect(s, p)) && !keepOut.some((k) => polyHitsRect(k, p)) && !boxes.some((o) => rectsOverlap(p, inflate(o, PAD)));
    };
    const spiral = [];
    for (let dx = -40; dx <= 40; dx += 0.6) for (let dy = -40; dy <= 40; dy += 0.6) spiral.push([dx, dy, dx * dx + dy * dy]);
    spiral.sort((a, b) => a[2] - b[2]);
    function placeLabel(key, text, candidates, opts = {}) {
      const { rot = false } = opts;
      let pick = candidates.find((c) => isFree(textBox(text, c.x, c.y, c.anchor, rot)));
      if (!pick) {
        const c0 = candidates[0];
        for (const [dx, dy] of spiral) {
          const c = { ...c0, x: c0.x + dx, y: c0.y + dy };
          if (isFree(textBox(text, c.x, c.y, c.anchor, rot))) { pick = c; break; }
        }
      }
      pick = pick || candidates[0];
      const box = textBox(text, pick.x, pick.y, pick.anchor, rot);
      boxes.push(box);
      growBox(box);
      labels.push({ key, text, box });
      const tr = rot ? ` transform="rotate(-90 ${f3(pick.x)} ${f3(pick.y)})"` : '';
      out.text.push(`<text class="dr-label" data-dim="${esc(key)}" x="${f3(pick.x)}" y="${f3(pick.y)}" text-anchor="${pick.anchor}"${tr}>${esc(text)}</text>`);
    }
    const label = (key, value) => `${format.symbol(key)} ${value}`;
    const val = (k) => format.number(v[k]);

    // ---- length dimensions below the section ----
    const lowerR = (z) => geometry.radiusAt(profile, z);
    const lengths = [['L1', v.L1, () => lowerR(v.L1)], ['L2', v.L2, () => lowerR(v.L2)], ['L3', v.L3, () => v.H2 / 2], ['L6', v.L6, () => bullet.m / 2]]
      .filter(([k, z]) => typeof z === 'number' && (geo.bottleneck || (k !== 'L1' && k !== 'L2')))
      .sort((a, b) => a[1] - b[1]);
    const yR = rMax + 4.5;
    const level0 = rMax + 11;
    const lastLevel = level0 + (lengths.length - 1) * LEVEL_STEP;
    const headBottom = Math.max(...profile.filter((p) => p[1] === 0).map((p) => p[0]));
    line(0, headBottom + GAP, 0, lastLevel + OVER);
    lengths.forEach(([key, z, rOf], i) => {
      const y = level0 + i * LEVEL_STEP;
      line(z, rOf() + GAP, z, y + OVER);
      hDim(0, z, y);
      const text = label(key, val(key));
      const half = (text.length * CHAR_W) / 2;
      const cx = Math.max(Math.min(z / 2, z - 1.5 - half), 1.5 + half);
      placeLabel(key, text, [{ x: cx, y: y - 1.2, anchor: 'middle' }, { x: z / 2, y: y - 1.2, anchor: 'middle' }]);
    });

    // ---- rim thickness R ----
    {
      const back = profile.find((p) => Math.abs(p[1] - v.R) < 1e-9);
      line(v.R, back[0] + GAP, v.R, yR + OVER);
      hDim(0, v.R, yR);
      placeLabel('R', label('R', val('R')), [{ x: v.R + 2 * ARROW_L + 1, y: yR + 0.33 * FS, anchor: 'start' }]);
    }

    // ---- diameters left of the head: E1, R1 ----
    {
      const rimTop = profile.find((p) => Math.abs(p[0] - v.R1 / 2) < 1e-9);
      const left = [['R1', v.R1, rimTop[1] - GAP]];
      if (geo.groove) left.push(['E1', v.E1, v.R - GAP]);
      left.sort((a, b) => a[1] - b[1]).forEach(([key, d, xFrom], i) => {
        const x = -7 - i * COL_STEP;
        const r = d / 2;
        line(xFrom, -r, x - OVER, -r);
        line(x - OVER, r, x + 3, r);
        vDim(x, -r, r);
        placeLabel(key, label(key, val(key)), [{ x: x + 0.35 * FS, y: r + 2, anchor: 'end' }], { rot: true });
      });
    }

    // ---- diameters across the part, labels in a staircase above ----
    const across = [];
    const addAcross = (key, x, r) => across.push({ key, x, r });
    addAcross('P1', geo.zBodyStart + 1, lowerR(geo.zBodyStart + 1));
    if (geo.bottleneck) {
      addAcross('P2', v.L1 - 0.6, lowerR(v.L1 - 0.6));
      addAcross('H1', v.L2 + 0.6, lowerR(v.L2 + 0.6));
    }
    addAcross('H2', v.L3 - 0.6, lowerR(v.L3 - 0.6));
    const gx = v.L3 + Math.max(0.3, Math.min(0.5 * (bullet.zn - v.L3), 3));
    addAcross('G1', gx, geometry.radiusAt(bullet.exposed, gx));
    const rows = across.filter((a) => typeof v[a.key] === 'number' && Number.isFinite(a.r)).sort((a, b) => a.x - b.x);
    const base = rMax + 5;
    rows.forEach((a, i) => {
      const yBase = -(base + (rows.length - 1 - i) * ROW_STEP);
      vDim(a.x, -a.r, a.r);
      line(a.x, -a.r, a.x, yBase - 0.9);
      placeLabel(a.key, label(a.key, val(a.key)), [{ x: a.x + 0.8, y: yBase, anchor: 'start' }]);
    });

    // ---- shoulder angle alpha ----
    if (geo.bottleneck) {
      const A = [v.L1, -v.P2 / 2];
      const B = [v.L2, -v.H1 / 2];
      const len = Math.hypot(B[0] - A[0], B[1] - A[1]);
      const e1 = [(B[0] - A[0]) / len, (B[1] - A[1]) / len]; // along the shoulder, towards the neck
      const T = 8;
      const V = [A[0] - e1[0] * T, A[1] - e1[1] * T];
      const theta = Math.atan2(e1[1], e1[0]);
      const arcR = 0.7 * T;
      line(V[0], V[1], A[0], A[1]);
      line(V[0], V[1], V[0] + Math.cos(-theta) * (arcR + 1.5), V[1] + Math.sin(-theta) * (arcR + 1.5));
      const arcPts = [];
      const steps = Math.max(4, Math.ceil((2 * theta) / (4 * Math.PI / 180)));
      for (let i = 0; i <= steps; i++) {
        const phi = theta - (2 * theta * i) / steps;
        arcPts.push([V[0] + arcR * Math.cos(phi), V[1] + arcR * Math.sin(phi)]);
      }
      out.thin.push(`<polyline class="dr-thin" points="${pts(arcPts)}"/>`);
      addSegs(arcPts);
      arcPts.forEach((p) => grow(p[0], p[1]));
      const inside = 2 * theta * arcR >= 3 * ARROW_L + 1;
      [[arcPts[0], arcPts[1]], [arcPts[steps], arcPts[steps - 1]]].forEach(([p, q]) => {
        let dx = q[0] - p[0];
        let dy = q[1] - p[1];
        const l = Math.hypot(dx, dy);
        dx /= l; dy /= l;
        if (inside) arrow(p[0], p[1], dx, dy);
        else {
          arrow(p[0], p[1], -dx, -dy);
          line(p[0], p[1], p[0] - dx * 2 * ARROW_L, p[1] - dy * 2 * ARROW_L);
        }
      });
      const alpha = format.angle(rec.cartridge.junctionCone.alpha);
      placeLabel('alpha', `α ${alpha}`, [{ x: V[0] - 1.6, y: V[1] + 0.33 * FS, anchor: 'end' }, { x: V[0] + arcR + 1.5, y: V[1] + 0.33 * FS, anchor: 'start' }]);
    }

    // ---- title block ----
    const lines = [
      [rec.name, 'dr-title-name', 3.6],
      [`C.I.P. table ${rec.tab}`, 'dr-title', 2.8],
      [`rev. ${rec.revised}`, 'dr-title', 2.8],
      ['Dimensions in mm', 'dr-title', 2.8],
      ['Scale 1:1', 'dr-title dr-scale', 2.8],
    ];
    const tbH = 3.6 + 2.8 * 4 + 5 * 1.6 + 1;
    const tx = opts.titleBelow ? bounds.x0 : bounds.x1 + 8;
    const ty = opts.titleBelow ? bounds.y1 + 5 : bounds.y1 - tbH;
    out.misc.push(`<rect class="dr-frame" x="${f3(tx)}" y="${f3(ty)}" width="${TITLE_W}" height="${f3(tbH)}"/>`);
    let ly = ty + 1.2;
    lines.forEach(([t, cls, size]) => {
      ly += size + 0.2;
      out.text.push(`<text class="${cls}" x="${f3(tx + 1.6)}" y="${f3(ly)}" font-size="${size}">${esc(t)}</text>`);
      ly += 1.4;
    });
    grow(tx, ty); grow(tx + TITLE_W, ty + tbH);

    const vb = [f3(bounds.x0 - MARGIN), f3(bounds.y0 - MARGIN), f3(bounds.x1 - bounds.x0 + 2 * MARGIN), f3(bounds.y1 - bounds.y0 + 2 * MARGIN)];
    const name = esc(rec.name);
    const svg =
      `<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="${vb.join(' ')}" role="img" aria-label="${name} drawing" font-size="${FS}">` +
      `<title>${name} drawing</title><desc>Half-section drawing of ${name}: outside view above the axis, section below. Dimensions in mm.</desc>` +
      `<defs><pattern id="cip-hatch" patternUnits="userSpaceOnUse" width="1.1" height="1.1" patternTransform="rotate(45)"><line class="dr-hatch-line" x1="0" y1="0" x2="0" y2="1.1"/></pattern></defs>` +
      `<g class="dr-section">${out.hatch.join('')}${out.misc.join('')}</g>` +
      `<g class="dr-lines">${out.thin.join('')}</g><g class="dr-outlines">${out.outline.join('')}</g>` +
      `<g class="dr-arrows">${out.arrows.join('')}</g><g class="dr-labels">${out.text.join('')}</g></svg>`;
    return { svg, labels, notes: geo.notes, segments: segs, keepOut, viewBox: vb, geometry: geo };
  }

  function unavailableSvg(rec, geo) {
    const name = esc(rec.name);
    return `<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="0 0 100 20" role="img" aria-label="${name} drawing"><title>${name} drawing</title><text x="2" y="10" font-size="3">${esc(geo.notes[0])}</text></svg>`;
  }

  // Updates the scale text for a drawing shown in a box of widthMm x heightMm (the drawing keeps its aspect ratio).
  function setScale(svgEl, widthMm, heightMm) {
    const { width, height } = svgEl.viewBox.baseVal;
    const t = svgEl.querySelector('.dr-scale');
    if (t && width) t.textContent = `Scale ${formatScale(Math.min(widthMm / width, heightMm / height))}`;
  }

  CIP.drawing = { build, formatScale, setScale, segHitsRect, polyHitsRect, rectsOverlap, inflate, PAD };
})(typeof window !== 'undefined' ? window : globalThis);
