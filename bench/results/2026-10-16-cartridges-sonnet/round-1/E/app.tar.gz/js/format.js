// Display formatting for cartridge records: numbers, angles, tolerances, symbols, units, table sections, filtering.
(function (g) {
  const CIP = g.CIP || (g.CIP = {});

  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };

  // Section titles and field order; fields not listed follow in record order.
  const CARTRIDGE_SECTIONS = [
    ['caseHead', 'Case head', ['R1', 'R', 'R3', 'E1', 'E', 'eMin', 'f', 'beta', 'delta']],
    ['collar', 'Collar', ['H1', 'H2']],
    ['junctionCone', 'Junction cone', ['S', 'alpha', 'r1Min', 'r2']],
    ['lengths', 'Lengths', ['L1', 'L2', 'L3', 'L4', 'L5', 'L6']],
    ['misc', 'Miscellaneous', ['Fe', 'deltaL']],
    ['powderChamber', 'Powder chamber', ['P1', 'P2']],
    ['pressures', 'Pressures', ['Pmax', 'PK', 'PE', 'EE', 'M']],
    ['projectile', 'Projectile', ['G1', 'G2', 'L3PlusG']],
  ];
  const CHAMBER_SECTIONS = [
    ['barrel', 'Barrel', ['F', 'Z']],
    ['breech', 'Breech', ['R1', 'R', 'R3', 'r']],
    ['collar', 'Collar', ['H1', 'H2']],
    ['grooves', 'Grooves', ['N', 'Q', 'b', 'u']],
    ['junctionCone', 'Junction cone', ['S', 'alpha', 'r1Max', 'r2']],
    ['lengths', 'Lengths', ['L1', 'L2', 'L3']],
    ['powderChamber', 'Powder chamber', ['E', 'P1', 'P2']],
    ['rifling', 'Rifling', ['G', 'G1', 'alpha1', 'h', 'i', 's']],
  ];

  const number = (n) => String(n === 0 ? 0 : n);
  const angle = (a) =>
    typeof a === 'number' ? `${number(a)}°` : `${number(a.degrees)}°${number(a.minutes)}'${number(a.seconds)}"`;
  const tolerance = (t) => (t > 0 ? '+' : '') + number(t);
  const degrees = (a) => (typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  const symbol = (field) => SYMBOLS[field] || field;
  const unit = (field) => (ANGLES.has(field) ? '°' : field in UNITS ? UNITS[field] : 'mm');

  function rows(section, order) {
    const fields = Object.keys(section).filter((f) => !f.endsWith('Tol'));
    fields.sort((a, b) => {
      const ia = order.indexOf(a);
      const ib = order.indexOf(b);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    return fields.map((field) => {
      const raw = section[field];
      let value = ANGLES.has(field) ? angle(raw) : number(raw);
      if (section[field + 'Tol'] !== undefined) value += ' ' + tolerance(section[field + 'Tol']);
      return { field, symbol: symbol(field), value, unit: unit(field) };
    });
  }

  function groupSections(data, defs) {
    return defs
      .filter(([key]) => data[key] && Object.keys(data[key]).length)
      .map(([key, title, order]) => ({ key, title, rows: rows(data[key], order) }));
  }

  const sections = (record) => ({
    cartridge: groupSections(record.cartridge, CARTRIDGE_SECTIONS),
    chamber: groupSections(record.chamber, CHAMBER_SECTIONS),
  });

  function facts(record) {
    const cap = record.annotations.publishedCapacity;
    return [
      { label: 'Alternative names', value: (record.alternativeNames || []).join(', ') || 'none' },
      { label: 'Family', value: record.family },
      { label: 'Category', value: record.annotations.category },
      { label: 'Primer type', value: record.annotations.primerType },
      { label: 'C.I.P. table', value: record.tab },
      { label: 'Country', value: record.country },
      { label: 'Published', value: record.published },
      { label: 'Revised', value: record.revised },
      { label: 'Pressure method', value: record.pressureMethod },
      {
        label: 'Water capacity',
        value: cap ? `${number(cap.grH2O)} grH2O` : 'not published',
        capacity: cap ? { value: number(cap.grH2O), unit: 'grH2O', source: cap.source, url: cap.url, note: cap.note || '' } : null,
      },
    ];
  }

  function filterRecords(records, query, family) {
    const q = String(query || '').trim().toLowerCase();
    return records.filter(
      (r) =>
        (!family || r.family === family) &&
        (!q || [r.name, ...(r.alternativeNames || [])].some((n) => n.toLowerCase().includes(q)))
    );
  }

  CIP.format = { number, angle, degrees, tolerance, symbol, unit, sections, facts, filterRecords };
})(typeof window !== 'undefined' ? window : globalThis);
