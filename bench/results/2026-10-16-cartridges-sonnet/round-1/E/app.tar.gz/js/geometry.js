// Cartridge geometry from a record. Points are [r, z]: r = radius from the axis, z = distance from the head face.
(function (g) {
  const CIP = g.CIP || (g.CIP = {});
  const RAD = Math.PI / 180;
  const ARC_STEP = 10 * RAD;
  const num = (x) => typeof x === 'number' && Number.isFinite(x);
  const SMALL_PRIMERS = ['sp', 'spm', 'sr'];
  const LARGE_PRIMERS = ['lp', 'lpm', 'lr', 'lrm'];
  const DEEP_POCKETS = ['lr', 'lrm'];

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    const ratio = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    return ratio >= 1.05 ? 'rimmed' : ratio < 0.98 ? 'rebated' : 'rimless';
  }

  // Rounds the corner p1 (between p0 and p2) with a tangent arc; the tangent length is capped at 45% of each leg.
  function fillet(p0, p1, p2, radius) {
    const d1 = [p0[0] - p1[0], p0[1] - p1[1]];
    const d2 = [p2[0] - p1[0], p2[1] - p1[1]];
    const l1 = Math.hypot(...d1);
    const l2 = Math.hypot(...d2);
    const u1 = [d1[0] / l1, d1[1] / l1];
    const u2 = [d2[0] / l2, d2[1] / l2];
    const theta = Math.acos(Math.max(-1, Math.min(1, u1[0] * u2[0] + u1[1] * u2[1])));
    if (!(radius > 0) || theta > Math.PI - 1e-6) return { points: [p1], radius: 0 };
    let t = radius / Math.tan(theta / 2);
    const tMax = 0.45 * Math.min(l1, l2);
    if (t > tMax) {
      t = tMax;
      radius = t * Math.tan(theta / 2);
    }
    const bis = [u1[0] + u2[0], u1[1] + u2[1]];
    const bl = Math.hypot(...bis);
    const dist = radius / Math.sin(theta / 2);
    const c = [p1[0] + (bis[0] / bl) * dist, p1[1] + (bis[1] / bl) * dist];
    const a = [p1[0] + u1[0] * t, p1[1] + u1[1] * t];
    const b = [p1[0] + u2[0] * t, p1[1] + u2[1] * t];
    const a0 = Math.atan2(a[1] - c[1], a[0] - c[0]);
    let da = Math.atan2(b[1] - c[1], b[0] - c[0]) - a0;
    if (da > Math.PI) da -= 2 * Math.PI;
    if (da < -Math.PI) da += 2 * Math.PI;
    const steps = Math.max(2, Math.ceil(Math.abs(da) / ARC_STEP));
    const points = [];
    for (let i = 0; i <= steps; i++) {
      const ang = a0 + (da * i) / steps;
      points.push([c[0] + radius * Math.cos(ang), c[1] + radius * Math.sin(ang)]);
    }
    return { points, radius, center: c };
  }

  function values(rec) {
    const c = rec.cartridge;
    const h = c.caseHead || {};
    const co = c.collar || {};
    const jc = c.junctionCone || {};
    const l = c.lengths || {};
    const pc = c.powderChamber || {};
    const deg = CIP.format.degrees;
    const ang = (a) => (a === undefined ? undefined : deg(a));
    return {
      R: h.R, R1: h.R1, R3: h.R3, E: h.E, E1: h.E1, eMin: h.eMin, f: h.f, beta: ang(h.beta), delta: ang(h.delta),
      H1: co.H1, H2: co.H2, alpha: ang(jc.alpha), r1Min: jc.r1Min, r2: jc.r2,
      L1: l.L1, L2: l.L2, L3: l.L3, L6: l.L6, P1: pc.P1, P2: pc.P2, G1: (c.projectile || {}).G1,
    };
  }

  // Outer radius at z, from the first non-vertical segment that spans z.
  function radiusAt(profile, z) {
    for (let i = 1; i < profile.length; i++) {
      const [r0, z0] = profile[i - 1];
      const [r1, z1] = profile[i];
      if (z1 !== z0 && z >= Math.min(z0, z1) - 1e-9 && z <= Math.max(z0, z1) + 1e-9) return r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
    }
    return NaN;
  }

  function buildBullet(rec, v, heeled, tb) {
    const shape = rec.annotations.defaultBulletShape;
    const pistol = rec.annotations.category === 'pistol';
    const D = heeled ? v.H2 : v.G1;
    const Rb = D / 2;
    const s = shape === 'pointy' ? D : shape === 'semi_wadcutter' ? 0.6 * D : (pistol ? 0.4 : 0.8) * D;
    const k = { pointy: 0.4, rounded: pistol ? 0.65 : 0.55, flat: pistol ? 0.7 : 0.6, semi_wadcutter: 0.78 }[shape];
    const m = { pointy: Math.max(0.08 * D, 1.27), rounded: 0.15 * D, flat: 0.55 * D, semi_wadcutter: 0.6 * D }[shape];
    if (!num(k)) return null;
    const zb = v.L3 - s;
    const Lb = v.L6 - zb;
    const zn = zb + k * Lb;
    const n = v.L6 - zn;
    const a = Rb - m / 2;
    const nose = [];
    let rho;
    if (shape === 'pointy') {
      rho = (a * a + n * n) / (2 * a);
      const phiMax = Math.asin(Math.min(1, n / rho));
      const steps = Math.max(8, Math.ceil(phiMax / (3 * RAD)));
      for (let i = 0; i <= steps; i++) {
        const phi = (phiMax * i) / steps;
        nose.push([Rb - rho + rho * Math.cos(phi), zn + rho * Math.sin(phi)]);
      }
      nose[nose.length - 1] = [m / 2, v.L6];
    } else if (shape === 'rounded') {
      for (let i = 0; i <= 18; i++) {
        const th = ((Math.PI / 2) * i) / 18;
        nose.push([m / 2 + a * Math.cos(th), zn + n * Math.sin(th)]);
      }
    } else {
      nose.push([Rb, zn], [m / 2, v.L6]);
    }
    // Full bullet outline from the shank at the nose start to the axis at the tip.
    const full = [[Rb, zb], ...nose, [0, v.L6]];
    const exposed = [];
    for (let i = 0; i < full.length; i++) {
      const [r, z] = full[i];
      if (z < v.L3 - 1e-9) {
        const [r1, z1] = full[i + 1];
        if (z1 > v.L3 + 1e-9) exposed.push([r + ((r1 - r) * (v.L3 - z)) / (z1 - z), v.L3]);
      } else exposed.push([r, z]);
    }
    if (exposed[0][1] > v.L3 + 1e-9) exposed.unshift([Rb, v.L3]);
    const heelRadius = heeled ? v.H2 / 2 - tb : Rb;
    const section = [[0, zb], [heelRadius, zb], [heelRadius, v.L3]];
    if (Math.abs(exposed[0][0] - heelRadius) > 1e-9) section.push(exposed[0]);
    section.push(...exposed.slice(1));
    return { shape, s, k, m, zb, Lb, zn, n, rho, diameter: D, heeled, heelRadius, exposed, section };
  }

  function compute(rec) {
    const v = values(rec);
    const notes = [];
    const missing = ['R', 'R1', 'P1', 'H2', 'L3', 'L6', 'G1'].filter((f) => !num(v[f]));
    const rim = rimType(rec);
    if (missing.length) return { rimType: rim, missing, notes: [`Drawing not available: ${missing.join(', ')} not published.`] };

    const pts = [];
    const push = (p) => {
      const q = pts[pts.length - 1];
      if (!q || Math.abs(q[0] - p[0]) > 1e-9 || Math.abs(q[1] - p[1]) > 1e-9) pts.push(p);
    };
    const rimR = v.R1 / 2;
    const bodyR = v.P1 / 2;
    push([0, 0]);

    // Head face and rim edge.
    const chamfer = num(v.beta) && num(v.f) && v.beta < 90;
    if (chamfer) {
      push([rimR - Math.min(v.f * Math.tan(v.beta * RAD), v.R1 / 4), 0]);
      push([rimR, v.f]);
      push([rimR, v.R]);
    } else if (rim === 'rimfire') {
      const rho = Math.max(0, Math.min(v.R / 2, (v.R1 - v.P1) / 2));
      const cr = rimR - rho;
      push([cr, 0]);
      for (let i = 1; i <= 12; i++) {
        const phi = (-90 + (180 * i) / 12) * RAD;
        push([cr + rho * Math.cos(phi), rho + rho * Math.sin(phi)]);
      }
      if (2 * rho < v.R) push([cr, v.R]);
    } else {
      push([rimR, 0]);
      push([rimR, v.R]);
      if (num(v.beta) !== num(v.f)) {
        notes.push(`Head chamfer not drawn: ${num(v.f) ? 'β' : 'f'} is not published.`);
      }
    }

    // Extractor groove and belt, or a plain step to the body.
    const grooveFields = ['E', 'E1', 'eMin'].filter((f) => num(v[f]));
    const groove = grooveFields.length === 3;
    if (grooveFields.length && !groove && rim !== 'rimfire') {
      const absent = ['E', 'E1', 'e min'].filter((f, i) => !num(v[['E', 'E1', 'eMin'][i]]));
      notes.push(`Extractor groove not drawn: ${absent.join(', ')} not published.`);
    }
    let zs = v.R;
    let beltRampEnd = null;
    if (groove) {
      push([v.E1 / 2, v.R]);
      push([v.E1 / 2, v.R + v.eMin]);
      if (rim === 'belted' && num(v.R3) && num(v.delta) && v.delta > 0) {
        beltRampEnd = Math.min(v.E, v.R + v.eMin + (v.R3 / 2 - v.E1 / 2) / Math.tan(v.delta * RAD));
        push([v.R3 / 2, beltRampEnd]);
        push([v.R3 / 2, v.E]);
      } else if (rim === 'belted') {
        notes.push(`Belt not drawn: ${[num(v.R3) ? '' : 'R3', num(v.delta) ? '' : 'δ'].filter(Boolean).join(', ')} not published.`);
      }
      push([bodyR, v.E]);
      zs = v.E;
    } else {
      push([bodyR, v.R]);
    }

    // Body, shoulder and neck.
    const shoulderFields = ['alpha', 'L1', 'L2'].every((f) => num(v[f]));
    const bottleneck = shoulderFields && num(v.P2) && num(v.H1);
    if (shoulderFields && !bottleneck) {
      notes.push(`Shoulder not drawn: ${['P2', 'H1'].filter((f) => !num(v[f])).join(', ')} not published.`);
    }
    const mouth = [v.H2 / 2, v.L3];
    let corners = null;
    if (bottleneck) {
      const body0 = pts[pts.length - 1];
      const A = [v.P2 / 2, v.L1];
      const B = [v.H1 / 2, v.L2];
      corners = { A, B };
      const missingR = [num(v.r1Min) ? '' : 'r1 min', num(v.r2) ? '' : 'r2'].filter(Boolean);
      if (missingR.length) notes.push(`Shoulder corner${missingR.length > 1 ? 's' : ''} not rounded: ${missingR.join(', ')} not published.`);
      (num(v.r1Min) ? fillet(body0, A, B, v.r1Min).points : [A]).forEach(push);
      (num(v.r2) ? fillet(A, B, mouth, v.r2).points : [B]).forEach(push);
    }
    push(mouth);
    const profile = pts;

    // Walls, primer pocket and solid head.
    const tn = (v.H2 - v.G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * v.P1) / 2);
    const heeled = v.H2 - v.G1 <= 0.015;
    const tnEff = heeled ? tb : tn;
    const primer = rec.annotations.primerType;
    let pocket = null;
    if (rim !== 'rimfire' && primer !== 'rimfire') {
      if (SMALL_PRIMERS.includes(primer) || LARGE_PRIMERS.includes(primer)) {
        pocket = { diameter: SMALL_PRIMERS.includes(primer) ? 4.45 : 5.33, depth: DEEP_POCKETS.includes(primer) ? 3.3 : 3.04 };
      } else notes.push('Primer pocket not drawn: primer type is not published.');
    }
    const w = Math.max(
      2.5,
      0.25 * bodyR,
      pocket ? pocket.depth + 1.5 : 0,
      groove && beltRampEnd === null ? v.E + tb : 0,
      beltRampEnd !== null ? beltRampEnd + tb : 0
    );

    const bullet = buildBullet(rec, v, heeled, tb);
    const wall = (z) => {
      if (bottleneck) {
        if (z <= v.L1) return tb;
        if (z >= v.L2) return tnEff;
        return tb + ((tnEff - tb) * (z - v.L1)) / (v.L2 - v.L1);
      }
      const z1 = bullet.zb;
      if (z <= w) return tb;
      if (z >= z1 || z1 <= w) return tnEff;
      return tb + ((tnEff - tb) * (z - w)) / (z1 - w);
    };
    // The cavity follows the body radius, not the belt, below the body start.
    const inner = [[(w <= zs ? bodyR : radiusAt(profile, w)) - wall(w), w]];
    for (const [r, z] of profile) if (z > Math.max(w, zs) + 1e-9) inner.push([r - wall(z), z]);

    return {
      rimType: rim, profile, inner, w, pocket, bullet, bottleneck, corners, groove, beltRampEnd, chamfer,
      zBodyStart: zs, walls: { tn, tb, tnEff, heeled }, mouth, values: v, notes, missing: [],
    };
  }

  CIP.geometry = { rimType, fillet, compute, radiusAt };
})(typeof window !== 'undefined' ? window : globalThis);
