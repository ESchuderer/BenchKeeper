# Design

## Context

Greenfield project (Node.js 22 devcontainer). The app must run from `file://` in Chromium, which blocks ES modules and `fetch` of local files. See proposal.md for scope.

## Goals / Non-Goals

**Goals:**
- Pure, unit-testable data, formatting, geometry and drawing code.
- Labels placed without collisions by construction and verified by test for all 25 records.

**Non-Goals:**
- No editing, export, units switching, or data beyond the 25 records.

## Decisions

- **Classic scripts, global namespace `CIP`.** `<script src>` works on `file://`; modules do not. Each file attaches to `globalThis.CIP`; Node tests `require` them in order. Alternative: ES modules (fails on `file://`); bundler (violates "no build step").
- **Data as a JS file embedding the supplied JSONL verbatim** (`js/data.js`, one string, parsed at load). Keeps the records diffable against the brief; `fetch` of JSON fails on `file://`.
- **Hash routing** (`#/cartridge/<key>`). Survives reload and bookmarks on `file://` and static servers; History API paths need server support.
- **Geometry in `(r, z)` points** exactly as the brief's rules, curves tessellated to polylines. Hatching, mirroring and walls then need no arc math in the renderer. Returns `notes` listing missing values.
- **Drawing in `x = z`, `y = -r` (outside view) / `+r` (section)** in mm. Strokes use `vector-effect: non-scaling-stroke` so line weight stays constant when the SVG scales to phone or print width. Monospace label font gives a deterministic text width (0.62 em per character estimate) for placement in Node; a browser test checks real boxes.
- **Dimension layout.** Lengths L1, L2, L3, L6 stack below the section (shortest nearest) with vertical extension lines; R sits below the head. Diameters R1 and E1 use vertical dimension lines left of the head with horizontal extension lines and rotated labels hanging below. P1, P2, H1, H2 and G1 are vertical dimension lines across the part at their feature, touching the outline with arrowheads, with leader lines rising to a staircase of labels above the part (leftmost highest), which avoids crossings. α is drawn as two rays (the shoulder line extended beyond the body corner, and its mirror) with an arc and arrows, outside the silhouette. Any label that still collides is moved to the nearest free spot found by grid search against all drawn segments, the silhouette and earlier labels.
- **Straight cases** have no shoulder, so the inner wall is blended linearly from tb at the solid head end to tn at the bullet base. Heeled cases use tb throughout. These interpretations are not stated in the brief.
- **Scale text** is computed from the displayed width (nominal 96 px per inch on screen, 190 mm in print via `beforeprint`) and not fixed at "1:1".
- **Tests:** `node:test` for pure modules; `playwright-core` driving the cached Chromium (`file://` and a static server) for UI, label boxes, print media and PDF page count. Alternative `@playwright/test` needs its own browser download.

## Risks / Trade-offs

- Label estimate differs from the real font width → placement uses a 20% margin; the browser test measures real boxes.
- One A4 page with ~100 table rows → tables flow in three print columns at small type; the PDF page count is tested.
- Extension and dimension lines may cross each other (not labels) → accepted.
