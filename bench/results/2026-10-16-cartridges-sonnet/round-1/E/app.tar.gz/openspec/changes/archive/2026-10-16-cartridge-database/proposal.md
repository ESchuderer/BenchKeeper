# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick offline reference for C.I.P. cartridge and chamber dimensions, with a true-to-scale drawing, modelled on the OpenBallistics cartridge database. The 25 supplied records are the only data.

## What Changes

- Static web app (`index.html`, CSS, JS), no framework, no build step, no network requests; works from `file://` and from any static server.
- Start page: searchable, family-filterable list of the 25 cartridges.
- Detail view per cartridge on its own hash address: facts, 2D SVG drawing computed from the record, value tables for cartridge and chamber.
- Print layout: one A4 portrait page per detail view.
- Light and dark screen themes following the system; print always light.
- Dev-only tests (Node test runner, Playwright against the cached Chromium).

## Capabilities

### New Capabilities
- `cartridge-browse`: start page list, search, family filter, count, links, hash routing.
- `cartridge-detail`: detail facts, value formatting (angles, tolerances, symbols, units), grouped tables, navigation.
- `cartridge-drawing`: SVG drawing geometry, dimensions, labels, title block, missing-value notes.
- `cartridge-print`: print layout and screen look and feel.

### Modified Capabilities

## Impact

- New files in the project root: `index.html`, `css/`, `js/`, `test/`, `package.json`.
- Dev dependency only: `playwright-core`. No runtime dependencies.
