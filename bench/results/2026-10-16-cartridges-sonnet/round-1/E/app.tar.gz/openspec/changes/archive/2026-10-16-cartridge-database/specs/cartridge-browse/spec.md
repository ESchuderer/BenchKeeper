# Spec Delta

## Purpose

The start page lists all cartridges and lets the user narrow the list by text and family, and open a cartridge.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" and, for each of the 25 records, its name, family and case length L3. The name SHALL be a link whose text is exactly the record's `name`.

#### Scenario: Initial list
- **WHEN** the user opens `index.html`
- **THEN** 25 links are shown, including "6,5 Creedmoor" and "40 S.& W."
- **AND** the text "25 cartridges" is shown

#### Scenario: Name link opens the detail view
- **WHEN** the user follows the link "308 Win."
- **THEN** the detail view of 308 Win. is shown

### Requirement: Search filters by name and alternative names
A field labelled "Search" SHALL filter the list as the user types, matching case-insensitively against the name and all alternative names.

#### Scenario: Alternative name
- **WHEN** the user types `7,62 x 51` into "Search"
- **THEN** only "308 Win." is listed and the text reads "1 cartridges"

#### Scenario: No match
- **WHEN** the user types text that matches nothing
- **THEN** no cartridge is listed and the text reads "0 cartridges"

### Requirement: Family filter
A select labelled "Family" with the options All, rimless, rimmed, belted, pistol, rimfire SHALL restrict the list to that family. It SHALL combine with the search text.

#### Scenario: Select a family
- **WHEN** the user selects "belted"
- **THEN** only "300 Win. Mag." and "7 mm Rem. Mag." are listed and the text reads "2 cartridges"

### Requirement: Detail views have their own address
Each detail view SHALL have a URL fragment address that opens the same view after a reload and when bookmarked. An unknown address SHALL show a "Cartridge not found" message with a link back to the list.

#### Scenario: Reload
- **WHEN** the user reloads the page on the detail view of "308 Win."
- **THEN** the detail view of "308 Win." is shown

#### Scenario: Unknown address
- **WHEN** the user opens an address for a cartridge that does not exist
- **THEN** "Cartridge not found" is shown with a link "All cartridges"

### Requirement: Works without a server and without network
The app SHALL work when `index.html` is opened from disk in Chromium and when served by a static file server, and SHALL make no network request.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened through a `file://` URL
- **THEN** the list is shown and every detail view renders its drawing and tables
- **AND** no request other than local files is made
