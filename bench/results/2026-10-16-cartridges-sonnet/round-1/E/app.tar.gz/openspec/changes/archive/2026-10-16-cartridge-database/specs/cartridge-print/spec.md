# Spec Delta

## Purpose

The detail view prints as a single A4 page and the screen presentation suits a technical reference on phones and desktops.

## ADDED Requirements

### Requirement: Printed detail view
A printed detail view SHALL be one A4 portrait page, black on white, with a header showing the name, the drawing at full width with legible labels, then the tables, and a footer "Source: C.I.P. TDCC, revised <date>". Navigation, search, filters and buttons SHALL NOT print.

#### Scenario: One page
- **WHEN** the detail view of any of the 25 cartridges is printed to PDF as A4 portrait
- **THEN** the PDF has exactly one page

#### Scenario: Print content
- **WHEN** the detail view of "308 Win." is rendered with print media
- **THEN** the "Print" button, the link "All cartridges" and the list controls are hidden
- **AND** the footer reads "Source: C.I.P. TDCC, revised 2008-09-23"
- **AND** the page background is white and the text is black

### Requirement: Light and dark themes
On screen the app SHALL follow the system colour scheme in light and dark. Print SHALL always be light.

#### Scenario: Dark system setting
- **WHEN** the system colour scheme is dark
- **THEN** the page background is dark and the drawing remains visible
- **AND** with print media the background is white

### Requirement: Technical look and phone use
The interface SHALL use dense, calm typography with tabular numbers and SHALL be usable at phone width without horizontal page scroll.

#### Scenario: Phone width
- **WHEN** the viewport is 375 px wide
- **THEN** the page does not scroll horizontally and the drawing fits the viewport width
