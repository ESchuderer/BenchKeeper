# Tasks

## 1. Project setup and data

- [x] 1.1 Create `package.json` (scripts `test`, `test:unit`, `test:e2e`, `serve`; dev dependency `playwright-core`), `.gitignore`; verify `npm install` succeeds
- [x] 1.2 Add `js/data.js` with the 25 records verbatim; verify a unit test finds 25 unique keys and the expected names

## 2. Formatting

- [x] 2.1 Tests then `js/format.js`: number, angle, tolerance, symbols, units, sections; verify unit tests pass (`39°59'49"`, `39.62 -0.2`, `4150`, no `L1Tol` row)

## 3. Geometry

- [x] 3.1 Tests then `js/geometry.js`: rim type, head, groove, belt, body, shoulder fillets, neck; verify unit tests per rule
- [x] 3.2 Tests then bullet, walls, primer pocket, `w`, missing-value notes in `js/geometry.js`; verify tests for 308 Win., 22 Long Rifle, 17 HMR, 9 mm Luger

## 4. Drawing

- [x] 4.1 Tests then `js/drawing.js`: SVG markup, outline, section hatch, centre line, dimension lines, arrowheads, labels with collision-free placement, title block; verify unit test that no label box collides for all 25 records
- [x] 4.2 Add scale text update (`beforeprint`, resize); verify unit test for scale formatting

## 5. App shell

- [x] 5.1 `index.html`, `css/style.css`, `js/app.js`: list, search, family select, count, hash routing, detail facts and tables, buttons; verify Playwright tests for browse and detail scenarios on `file://` and over HTTP
- [x] 5.2 `css/print.css`: A4 one-page layout, light theme forced; verify PDF page count is 1 for all 25 records and print-media assertions pass
- [x] 5.3 Light/dark and phone layout; verify Playwright dark scheme and 375 px no-horizontal-scroll tests

## 6. Integration

- [x] 6.1 Browser check of every drawing (screenshots, real label boxes versus outline) with Playwright MCP; verify no overlaps and no console errors
- [x] 6.2 Run the whole suite, build nothing, document commands in `README.md`; verify `npm test` passes

## Workflow follow-up

- Review the branch, then archive the change on the branch before merge.
