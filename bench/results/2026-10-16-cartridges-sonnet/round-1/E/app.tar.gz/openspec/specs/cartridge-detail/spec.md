# cartridge-detail Specification

## Purpose
The detail view presents one cartridge's facts and all cartridge and chamber values as published, with consistent symbols, units and formatting.

## Requirements

### Requirement: Detail header and facts
The detail view SHALL show the cartridge name as heading, then alternative names, family, category, primer type, C.I.P. table, country, published date, revised date, pressure method and the published water capacity with a link to its source.

#### Scenario: 308 Win. facts
- **WHEN** the detail view of "308 Win." is open
- **THEN** the heading is "308 Win." and the alternative names "308 Winchester" and "7,62 x 51" are shown
- **AND** table "I", country "US", published "1984-06-14", revised "2008-09-23" and pressure method "Transducer" are shown
- **AND** the water capacity "56" is shown with a link to `http://kwk.us/cases.html`

#### Scenario: No published capacity
- **WHEN** the detail view of "7 x 64" is open
- **THEN** the water capacity reads "not published"

### Requirement: Value tables grouped by section
The view SHALL show all cartridge values and all chamber values in tables grouped by section, each with the columns "Symbol", "Value" and "Unit". Sections without values SHALL be omitted.

#### Scenario: Sections
- **WHEN** the detail view of "308 Win." is open
- **THEN** the cartridge group has the sections case head, collar, junction cone, lengths, miscellaneous, powder chamber, pressures and projectile
- **AND** the chamber group has barrel, breech, collar, grooves, junction cone, lengths, powder chamber and rifling

#### Scenario: Empty section omitted
- **WHEN** the detail view of "9 mm Luger" is open
- **THEN** no junction cone table is shown

### Requirement: Values as published
Values SHALL be shown with a decimal point, no thousands separator and no added trailing zeros. Lengths and diameters are in mm; Pmax, PK and PE in bar; EE in J; M in g; Q in mm²; N has no unit. Angles are shown as `40°`, or as `39°59'49"` when given in degrees, minutes and seconds.

#### Scenario: Plain values
- **WHEN** the detail view of "243 Win." is open
- **THEN** Pmax shows "4150" with unit "bar" and L3 shows "51.94" with unit "mm"

#### Scenario: Angles
- **WHEN** the detail view of "223 Rem." is open
- **THEN** the chamber value i shows `3°10'36"` and alpha shows "46°"

### Requirement: Tolerances next to their value
A field `<X>Tol` SHALL be shown next to the value of X and SHALL NOT have a row of its own.

#### Scenario: Length with tolerance
- **WHEN** the detail view of "308 Win." is open
- **THEN** L1 shows "39.62 -0.2"
- **AND** no row has the symbol "L1Tol"

### Requirement: Symbols
A row's symbol SHALL be the field name, except eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L" and L3PlusG "L3 + G".

#### Scenario: Renamed symbols
- **WHEN** the detail view of "223 Rem." is open
- **THEN** rows with the symbols "e min", "r1 min", "r1 max", "α", "α1", "β", "δ", "delta L" and "L3 + G" are shown

### Requirement: Navigation and print button
The view SHALL provide a link "All cartridges" to the list and a button "Print" that opens the browser's print dialog.

#### Scenario: Back to the list
- **WHEN** the user follows "All cartridges"
- **THEN** the start page is shown with the previous search and family selection

#### Scenario: Print button
- **WHEN** the user presses "Print"
- **THEN** `window.print` is called
