# cartridge-drawing Specification

## Purpose
The detail view draws the cartridge as an inline, true-to-scale SVG computed only from the record's values, with dimensions, labels and a title block.

## Requirements

### Requirement: Drawing frame and scale
The drawing SHALL be an inline SVG with accessible name "<name> drawing", 1 SVG user unit = 1 mm, axis horizontal, head on the left. The upper half SHALL be the outside view and the lower half a section with hatched cut walls. A dash-dot centre line SHALL mark the axis. The SVG SHALL scale to the width of its container.

#### Scenario: Accessible name and units
- **WHEN** the detail view of "308 Win." is open
- **THEN** an image named "308 Win. drawing" exists
- **AND** its viewBox is in mm and the case length from head face to mouth spans 51.18 units

### Requirement: Rim type and head
The rim type SHALL be belted for family belted and rimfire for family rimfire; otherwise rimmed when R1/P1 >= 1.05, rebated when < 0.98, else rimless. The head face SHALL carry a chamfer where beta (< 90°) and f are published, a half-round rim edge on rimfire cases, otherwise a square corner.

#### Scenario: Rim types
- **WHEN** the rim type of "9,3 x 74 R", "223 Rem.", "300 Win. Mag." and "22 Long Rifle" is computed
- **THEN** the results are rimmed, rimless, belted and rimfire

#### Scenario: Chamfer
- **WHEN** the profile of "223 Rem." is computed
- **THEN** the profile has the points (r, z) = (0, 0), (R1/2 - min(f·tan β, R1/4), 0), (R1/2, f), (R1/2, R)

### Requirement: Extractor groove, belt and body
Where E and E1 are published the profile SHALL contain an extractor groove (floor at E1/2 from z = R to R + e min, ramp to (P1/2, E)); on belted cases the ramp SHALL rise at angle δ to the belt R3/2 and follow it to z = E before stepping in to P1/2. Without a groove the profile steps in from R1/2 to P1/2 at z = R. The body SHALL run straight to (P2/2, L1) on a bottleneck case, or to (H2/2, L3) on a case without alpha, L1 or L2.

#### Scenario: Groove
- **WHEN** the profile of "223 Rem." is computed
- **THEN** it contains (E1/2, R), (E1/2, R + e min) and (P1/2, E)

#### Scenario: Straight case
- **WHEN** the profile of "9 mm Luger" is computed
- **THEN** it has no shoulder and ends at (H2/2, L3)

### Requirement: Shoulder and neck
On a bottleneck case the shoulder SHALL be drawn through (P2/2, L1) and (H1/2, L2) and labelled α, with the body-side corner rounded by r1 min and the neck-side corner by r2 where published. The neck runs to (H2/2, L3).

#### Scenario: Rounded corners
- **WHEN** the profile of "308 Win." is computed
- **THEN** the corners at L1 and L2 are replaced by arcs of radius r1 min (0.76) and r2 (3.18)

### Requirement: Bullet
The bullet SHALL be drawn from the mouth to the tip at z = L6 with shank diameter G1 and the shape from `annotations.defaultBulletShape` (pointy, rounded, flat, semi_wadcutter). Seating depth, cylinder length and meplat diameter follow the shape and the rifle, pistol or rimfire category.

#### Scenario: Pointy bullet
- **WHEN** the bullet of "308 Win." is computed
- **THEN** seating depth is 7.85, the base lies at z = 43.33, the cylinder ends at z = base + 0.40 · (L6 - base), and the meplat diameter is 1.27

### Requirement: Heeled case
On a heeled case (H2 - G1 <= 0.015) the exposed bullet SHALL have the case's outside diameter and the seated heel the case's inside diameter H2 - 2·tb.

#### Scenario: Heeled case
- **WHEN** the bullet of "22 Long Rifle" is computed
- **THEN** the exposed bullet diameter equals H2 and the seated heel diameter equals H2 - 2·tb

### Requirement: Seated bullet visibility
The outside view SHALL hide the seated part of the bullet; the section SHALL show it inside the case.

#### Scenario: Seated part
- **WHEN** the drawing of "308 Win." is built
- **THEN** the upper half has no bullet outline below z = L3 and the lower half has the bullet from its base

### Requirement: Section walls and primer pocket
The section SHALL use neck wall tn = (H2 - G1)/2 and body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2), blended linearly across the shoulder, and a solid head to z = w. Centrefire cases SHALL show a primer pocket sized by primer type; rimfire cases none.

#### Scenario: Solid head
- **WHEN** the section of "223 Rem." is computed
- **THEN** w is the maximum of 2.5, 0.25·P1/2, pocket depth + 1.5 and E + tb

### Requirement: Dimension lines and labels
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled "<symbol> <value>" (for example "L3 51.18"). Labels SHALL NOT overlap each other, the outline or other lines.

#### Scenario: Labels present
- **WHEN** the detail view of "308 Win." is open
- **THEN** the labels "L3 51.18", "L6 71.12", "R1 12.01", "R 1.37" and "P1 11.96" exist in the drawing

#### Scenario: No overlaps
- **WHEN** the detail view of any of the 25 cartridges is open
- **THEN** no two label boxes intersect and no label box intersects the outline

### Requirement: Title block
The drawing SHALL include a title block with the cartridge name, C.I.P. table, revision date, the text "Dimensions in mm" and the drawing scale.

#### Scenario: Title block
- **WHEN** the detail view of "308 Win." is open
- **THEN** the drawing contains "308 Win.", "C.I.P. table I", "rev. 2008-09-23", "Dimensions in mm" and "Scale"

### Requirement: Missing values
A feature whose required value is missing SHALL be omitted, no number SHALL be invented, and the view SHALL state which value is missing.

#### Scenario: Missing shoulder radii
- **WHEN** the detail view of "17 HMR" is open
- **THEN** the shoulder corners are not rounded and a note names "r1 min" and "r2"
