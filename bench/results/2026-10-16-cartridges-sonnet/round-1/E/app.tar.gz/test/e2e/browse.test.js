const test = require('node:test');
const assert = require('node:assert/strict');
const { forEachTarget, openPage } = require('./helpers.js');
require('../load.js');
const { records } = globalThis.CIP;

test('browse: list, search, family, count, routing', async () => {
  await forEachTarget(async ({ name, url, browser }) => {
    const page = await openPage(browser, url);
    const tag = (m) => `[${name}] ${m}`;
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges', tag('heading'));
    const links = page.locator('main a[href^="#/cartridge/"]');
    assert.deepEqual(await links.allTextContents(), records.map((r) => r.name), tag('links'));
    assert.equal((await page.locator('#count').textContent()).trim(), '25 cartridges');
    const row = page.getByRole('row', { name: /308 Win\./ });
    assert.match(await row.textContent(), /rimless/);
    assert.match(await row.textContent(), /51\.18/);

    await page.getByLabel('Search').fill('7,62 x 51');
    assert.deepEqual(await links.allTextContents(), ['308 Win.'], tag('alt name search'));
    assert.equal((await page.locator('#count').textContent()).trim(), '1 cartridges');
    await page.getByLabel('Search').fill('zzz');
    assert.equal((await page.locator('#count').textContent()).trim(), '0 cartridges');
    assert.equal(await links.count(), 0);

    await page.getByLabel('Search').fill('');
    const options = await page.getByLabel('Family').locator('option').allTextContents();
    assert.deepEqual(options, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
    await page.getByLabel('Family').selectOption({ label: 'belted' });
    assert.deepEqual(await links.allTextContents(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
    assert.equal((await page.locator('#count').textContent()).trim(), '2 cartridges');
    await page.getByLabel('Search').fill('300');
    assert.deepEqual(await links.allTextContents(), ['300 Win. Mag.']);

    // detail view, back keeps the filter, reload keeps the view
    await page.getByRole('link', { name: '300 Win. Mag.', exact: true }).click();
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '300 Win. Mag.');
    assert.match(page.url(), /#\/cartridge\/300_win_mag$/);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    assert.equal(await page.getByLabel('Search').inputValue(), '300', tag('filter kept'));
    assert.equal(await page.getByLabel('Family').inputValue(), 'belted');
    await page.goBack();
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '300 Win. Mag.');
    await page.reload();
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '300 Win. Mag.', tag('reload'));

    await page.goto(url + '#/cartridge/nope');
    assert.ok(await page.getByText('Cartridge not found').isVisible());
    assert.ok(await page.getByRole('link', { name: 'All cartridges' }).isVisible());

    assert.deepEqual(page.errors, [], tag('console errors'));
    const outside = page.requests.filter((u) => !(u.startsWith('file://') || u.startsWith(new URL(url).origin)));
    assert.deepEqual(outside, [], tag('no external requests'));
    await page.context().close();
  });
});

test('every cartridge name opens its own address', async () => {
  await forEachTarget(async ({ url, browser }) => {
    if (!url.startsWith('file:')) return;
    const page = await openPage(browser, url);
    for (const r of records) {
      await page.goto(`${url}#/cartridge/${r.key}`);
      assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), r.name, r.key);
      assert.equal(await page.getByRole('img', { name: `${r.name} drawing` }).count(), 1, r.key);
    }
    assert.deepEqual(page.errors, []);
    await page.context().close();
  });
});

test('a malformed address shows "Cartridge not found"', async () => {
  await forEachTarget(async ({ url, browser }) => {
    const page = await openPage(browser, `${url}#/cartridge/9_mm_luger`);
    await page.evaluate(() => { location.hash = '#/cartridge/%E0%A4%A'; });
    assert.ok(await page.getByText('Cartridge not found').isVisible());
    assert.deepEqual(page.errors, []);
    await page.context().close();
  });
});
