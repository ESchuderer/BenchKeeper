const test = require('node:test');
const assert = require('node:assert/strict');
const { forEachTarget, openPage } = require('./helpers.js');
require('../load.js');
const { records } = globalThis.CIP;

const cells = async (page, tableName, group = 'Cartridge values') => {
  const rows = page.getByRole('region', { name: group }).getByRole('table', { name: tableName }).getByRole('row');
  const out = [];
  for (let i = 1; i < (await rows.count()); i++) out.push((await rows.nth(i).locator('th, td').allTextContents()).map((s) => s.trim()));
  return out;
};

test('detail: facts, tables, formatting', async () => {
  await forEachTarget(async ({ name, url, browser }) => {
    const page = await openPage(browser, `${url}#/cartridge/308_win`);
    const tag = (m) => `[${name}] ${m}`;
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '308 Win.');
    const facts = await page.locator('dl.facts').innerText();
    for (const s of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 grH2O']) {
      assert.ok(facts.includes(s), tag(`facts include ${s}`));
    }
    const dts = await page.locator('dl.facts dt').allTextContents();
    assert.deepEqual(dts, ['Alternative names', 'Family', 'Category', 'Primer type', 'C.I.P. table', 'Country', 'Published', 'Revised', 'Pressure method', 'Water capacity']);
    assert.equal(await page.getByRole('link', { name: 'kwk' }).getAttribute('href'), 'http://kwk.us/cases.html');

    for (const g of ['Cartridge values', 'Chamber values']) assert.equal(await page.getByRole('heading', { level: 2, name: g }).count(), 1);
    const heads = await page.getByRole('table', { name: 'Lengths' }).first().getByRole('columnheader').allTextContents();
    assert.deepEqual(heads, ['Symbol', 'Value', 'Unit']);
    const lengths = await cells(page, 'Lengths');
    assert.deepEqual(lengths[0], ['L1', '39.62 -0.2', 'mm'], tag('tolerance next to value'));
    assert.deepEqual(lengths.map((r) => r[0]), ['L1', 'L2', 'L3', 'L6']);
    const all = await page.locator('table tbody th').allTextContents();
    assert.ok(!all.some((s) => s.endsWith('Tol')));
    assert.ok(all.includes('r1 min') && all.includes('α') && all.includes('δ') && all.includes('L3 + G'));
    const pressures = await cells(page, 'Pressures');
    assert.deepEqual(pressures[0], ['Pmax', '4150', 'bar']);
    assert.deepEqual(pressures.at(-1), ['M', '25', 'g']);
    assert.ok((await cells(page, 'Grooves', 'Chamber values')).some((r) => r[0] === 'Q' && r[2] === 'mm²'));
    assert.ok((await cells(page, 'Grooves', 'Chamber values')).some((r) => r[0] === 'N' && r[2] === ''));
    assert.ok((await cells(page, 'Rifling', 'Chamber values')).some((r) => r[0] === 'α1' && r[1] === '71°25\'59"'));
    assert.deepEqual(page.errors, []);
    await page.context().close();

    const p2 = await openPage(browser, `${url}#/cartridge/7_x_64`);
    assert.match(await p2.locator('dl.facts').innerText(), /not published/);
    const p3 = await openPage(browser, `${url}#/cartridge/9_mm_luger`);
    assert.equal(await p3.getByRole('table', { name: 'Junction cone' }).count(), 0);
    await p2.context().close();
    await p3.context().close();
  });
});

test('Print button calls window.print', async () => {
  await forEachTarget(async ({ url, browser }) => {
    const page = await openPage(browser, `${url}#/cartridge/308_win`);
    await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
    await page.getByRole('button', { name: 'Print' }).click();
    assert.equal(await page.evaluate(() => window.__printed), 1);
    await page.context().close();
  });
});

test('missing values are named next to the drawing', async () => {
  await forEachTarget(async ({ url, browser }) => {
    if (!url.startsWith('file:')) return;
    const page = await openPage(browser, `${url}#/cartridge/17_hmr`);
    const note = await page.locator('figure.drawing figcaption').innerText();
    assert.match(note, /r1 min/);
    assert.match(note, /r2/);
    const p2 = await openPage(browser, `${url}#/cartridge/308_win`);
    assert.equal(await p2.locator('figure.drawing figcaption').count(), 0);
    await page.context().close();
    await p2.context().close();
  });
});

// Real label boxes against each other and against the outline, for every record.
test('drawing: labels do not overlap each other or the outline', async () => {
  await forEachTarget(async ({ url, browser }) => {
    if (!url.startsWith('file:')) return;
    const page = await openPage(browser, url);
    for (const r of records) {
      await page.goto(`${url}#/cartridge/${r.key}`);
      const result = await page.evaluate(() => {
        const svg = document.querySelector('svg.drawing');
        const labels = [...svg.querySelectorAll('text.dr-label')].map((t) => ({ text: t.textContent, r: t.getBoundingClientRect() }));
        const hits = [];
        const inter = (a, b) => a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
        labels.forEach((a, i) => labels.slice(i + 1).forEach((b) => inter(a.r, b.r) && hits.push(`${a.text} x ${b.text}`)));
        const ctm = svg.getScreenCTM();
        for (const el of svg.querySelectorAll('.dr-outlines > *, .dr-lines > *')) {
          const pts = [];
          if (el.tagName === 'line') pts.push([el.x1.baseVal.value, el.y1.baseVal.value], [el.x2.baseVal.value, el.y2.baseVal.value]);
          else for (const p of el.points) pts.push([p.x, p.y]);
          for (let i = 0; i + 1 < pts.length; i++) {
            const [x1, y1] = pts[i];
            const [x2, y2] = pts[i + 1];
            const n = Math.max(2, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 0.25));
            for (let k = 0; k <= n; k++) {
              const x = x1 + ((x2 - x1) * k) / n;
              const y = y1 + ((y2 - y1) * k) / n;
              const sx = ctm.a * x + ctm.e;
              const sy = ctm.d * y + ctm.f;
              for (const l of labels) if (sx > l.r.left && sx < l.r.right && sy > l.r.top && sy < l.r.bottom) hits.push(`${l.text} on ${el.getAttribute('class')}`);
            }
          }
        }
        return { n: labels.length, hits: [...new Set(hits)] };
      });
      assert.ok(result.n >= 6, `${r.key} labels`);
      assert.deepEqual(result.hits, [], r.key);
    }
    await page.context().close();
  });
});

test('drawing: scale text follows the displayed width', async () => {
  await forEachTarget(async ({ url, browser }) => {
    if (!url.startsWith('file:')) return;
    const page = await openPage(browser, `${url}#/cartridge/308_win`);
    const read = () => page.locator('.dr-scale').textContent();
    const wide = await read();
    await page.setViewportSize({ width: 375, height: 800 });
    const narrow = await read();
    assert.match(wide, /^Scale \d+(\.\d)?:1$|^Scale 1:\d+(\.\d)?$/);
    assert.notEqual(wide, narrow);
    await page.context().close();
  });
});
