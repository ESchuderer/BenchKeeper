const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright-core');
const { start } = require('../serve.js');

const INDEX = path.resolve(__dirname, '../../index.html');

function chromePath() {
  if (process.env.CHROME) return process.env.CHROME;
  const root = path.join(os.homedir(), '.cache', 'ms-playwright');
  const dir = fs.readdirSync(root).filter((d) => d.startsWith('chromium-')).sort().pop();
  return path.join(root, dir, 'chrome-linux64', 'chrome');
}

// Opens the app in Chromium over file:// and over HTTP; calls fn(target) for each.
async function forEachTarget(fn) {
  const browser = await chromium.launch({ executablePath: chromePath(), args: ['--no-sandbox'] });
  const server = await start(0);
  const targets = [
    { name: 'file', url: pathToFileURL(INDEX).href },
    { name: 'http', url: `http://127.0.0.1:${server.address().port}/index.html` },
  ];
  try {
    for (const t of targets) await fn({ ...t, browser });
  } finally {
    await browser.close();
    server.close();
  }
}

// Page that collects console errors and requests.
async function openPage(browser, url, opts = {}) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, ...opts });
  const page = await context.newPage();
  page.errors = [];
  page.requests = [];
  page.on('console', (m) => m.type() === 'error' && page.errors.push(m.text()));
  page.on('pageerror', (e) => page.errors.push(String(e)));
  page.on('request', (r) => page.requests.push(r.url()));
  await page.goto(url);
  return page;
}

module.exports = { forEachTarget, openPage, INDEX };
