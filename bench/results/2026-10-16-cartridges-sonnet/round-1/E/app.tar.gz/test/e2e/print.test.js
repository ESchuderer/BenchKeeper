const test = require('node:test');
const assert = require('node:assert/strict');
const { forEachTarget, openPage } = require('./helpers.js');
require('../load.js');
const { records } = globalThis.CIP;

const pdfPages = (buf) => (buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;

test('print media: hidden chrome, footer, light colours', async () => {
  await forEachTarget(async ({ url, browser }) => {
    const page = await openPage(browser, `${url}#/cartridge/308_win`, { colorScheme: 'dark' });
    await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
    for (const sel of ['button', 'nav a', '#list-view', '#search']) {
      assert.equal(await page.locator(sel).first().isVisible(), false, sel);
    }
    const footer = await page.locator('footer.source').innerText();
    assert.equal(footer.trim(), 'Source: C.I.P. TDCC, revised 2008-09-23');
    const colours = await page.evaluate(() => {
      const cs = (e) => getComputedStyle(e);
      return {
        bg: cs(document.body).backgroundColor,
        ink: cs(document.querySelector('h1')).color,
        td: cs(document.querySelector('tbody td')).color,
        outline: cs(document.querySelector('.dr-outline')).stroke,
        label: cs(document.querySelector('.dr-label')).fill,
      };
    });
    assert.equal(colours.bg, 'rgb(255, 255, 255)');
    for (const k of ['ink', 'td', 'outline', 'label']) assert.equal(colours[k], 'rgb(0, 0, 0)', k);
    const w = await page.evaluate(() => document.querySelector('svg.drawing').getBoundingClientRect().width);
    assert.ok(w > 650, `drawing full width in print, got ${w}`);
    await page.context().close();
  });
});

test('screen: dark and light follow the system', async () => {
  await forEachTarget(async ({ url, browser }) => {
    const bg = async (scheme) => {
      const page = await openPage(browser, `${url}#/cartridge/308_win`, { colorScheme: scheme });
      const v = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
      await page.context().close();
      return v;
    };
    const light = await bg('light');
    const dark = await bg('dark');
    assert.notEqual(light, dark);
    const lum = (c) => c.match(/\d+/g).slice(0, 3).reduce((s, n) => s + Number(n), 0);
    assert.ok(lum(dark) < 150 && lum(light) > 600, `${light} ${dark}`);
  });
});

test('phone width: no horizontal scroll, drawing fits', async () => {
  await forEachTarget(async ({ url, browser }) => {
    const page = await openPage(browser, url, { viewport: { width: 375, height: 800 } });
    const over = () => page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assert.ok((await over()) <= 0, 'list');
    for (const key of ['338_lapua_mag', '308_win', '22_long_rifle']) {
      await page.goto(`${url}#/cartridge/${key}`);
      assert.ok((await over()) <= 0, key);
      const w = await page.evaluate(() => document.querySelector('svg.drawing').getBoundingClientRect().width);
      assert.ok(w <= 375 && w > 250, `${key} svg ${w}`);
    }
    await page.context().close();
  });
});

test('every detail view prints on one A4 page', async () => {
  await forEachTarget(async ({ url, browser }) => {
    if (!url.startsWith('file:')) return;
    const page = await openPage(browser, url);
    for (const r of records) {
      await page.goto(`${url}#/cartridge/${r.key}`);
      await page.emulateMedia({ media: 'print' });
      const pdf = await page.pdf({ preferCSSPageSize: true });
      assert.equal(pdfPages(pdf), 1, r.key);
    }
    await page.context().close();
  });
});
