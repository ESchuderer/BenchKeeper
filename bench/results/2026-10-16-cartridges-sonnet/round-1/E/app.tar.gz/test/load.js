// Loads the browser scripts into globalThis.CIP, in page order.
for (const f of ['data', 'format', 'geometry', 'drawing']) {
  try {
    require(`../js/${f}.js`);
  } catch (e) {
    if (e.code !== 'MODULE_NOT_FOUND' || !String(e.message).includes(`js/${f}.js`)) throw e;
  }
}
module.exports = globalThis.CIP;
