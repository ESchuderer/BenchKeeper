const test = require('node:test');
const assert = require('node:assert/strict');
const { records } = require('../load.js');

test('25 records with unique keys', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
});

test('names as published', () => {
  const names = records.map((r) => r.name);
  for (const n of ['6,5 Creedmoor', '40 S.& W.', '308 Win.', '22 Win. Mag. R.F.', '9,3 x 74 R']) {
    assert.ok(names.includes(n), n);
  }
});

test('families', () => {
  const fam = (f) => records.filter((r) => r.family === f).length;
  assert.deepEqual(['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'].map(fam), [12, 2, 2, 6, 3]);
});

test('308 Win. spot values', () => {
  const r = records.find((x) => x.key === '308_win');
  assert.equal(r.cartridge.lengths.L3, 51.18);
  assert.deepEqual(r.alternativeNames, ['308 Winchester', '7,62 x 51']);
});
