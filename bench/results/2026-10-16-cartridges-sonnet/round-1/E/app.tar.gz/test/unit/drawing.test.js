const test = require('node:test');
const assert = require('node:assert/strict');
const { records, drawing } = require('../load.js');
const rec = (k) => records.find((r) => r.key === k);
const texts = (d) => d.labels.map((l) => l.text);

test('308 Win. has all dimension labels', () => {
  const t = texts(drawing.build(rec('308_win')));
  for (const want of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(t.includes(want), `${want} in ${t.join('|')}`);
  }
});

test('9 mm Luger has only the published dimensions', () => {
  const t = texts(drawing.build(rec('9_mm_luger')));
  assert.deepEqual(t.sort(), ['E1 8.79', 'G1 9.03', 'H2 9.65', 'L3 19.15', 'L6 29.69', 'P1 9.93', 'R 1.27', 'R1 9.96'].sort());
});

test('shoulder angle in degrees, minutes, seconds', () => {
  assert.ok(texts(drawing.build(rec('6_5_x_55_se'))).includes('α 50°35\'2"'));
});

test('svg frame, name, title block', () => {
  const { svg, viewBox } = drawing.build(rec('308_win'));
  assert.match(svg, /role="img" aria-label="308 Win\. drawing"/);
  for (const s of ['Dimensions in mm', 'C.I.P. table I', 'rev. 2008-09-23', 'Scale 1:1', '>308 Win.<']) assert.ok(svg.includes(s), s);
  assert.ok(viewBox[2] > 100 && viewBox[3] > 40 && viewBox[3] < 90);
  const below = drawing.build(rec('308_win'), { titleBelow: true }).viewBox;
  assert.ok(below[3] > viewBox[3] && below[2] < viewBox[2]);
  assert.ok(!/https?:/.test(svg.replace('http://www.w3.org/2000/svg', '')));
});

test('names are escaped', () => {
  assert.ok(drawing.build(rec('40_s_w')).svg.includes('aria-label="40 S.&amp; W. drawing"'));
});

test('scale text', () => {
  assert.equal(drawing.formatScale(1), '1:1');
  assert.equal(drawing.formatScale(1.6), '1.6:1');
  assert.equal(drawing.formatScale(2), '2:1');
  assert.equal(drawing.formatScale(0.5), '1:2');
  assert.equal(drawing.formatScale(0.8), '1:1.3');
});

test('every label of every record is free of overlaps', () => {
  for (const r of records) {
    const d = drawing.build(r);
    assert.ok(d.labels.length >= 6, r.key);
    d.labels.forEach((a, i) => {
      for (const b of d.labels.slice(i + 1)) assert.ok(!drawing.rectsOverlap(a.box, b.box), `${r.key}: ${a.text} overlaps ${b.text}`);
      for (const s of d.segments) assert.ok(!drawing.segHitsRect(s, a.box), `${r.key}: ${a.text} hits a line ${s.map((n) => n.toFixed(1))}`);
      for (const k of d.keepOut) assert.ok(!drawing.polyHitsRect(k, a.box), `${r.key}: ${a.text} overlaps the outline`);
    });
  }
});

test('hatch, bullet section and centre line are drawn', () => {
  const { svg } = drawing.build(rec('223_rem'));
  assert.ok(svg.includes('class="dr-hatch"') && svg.includes('class="dr-bullet"') && svg.includes('class="dr-centre"'));
});

test('section closes at the end of the solid head on the axis', () => {
  const d = drawing.build(rec('308_win'));
  const w = d.geometry.w;
  assert.ok(d.svg.includes(`,${+(w).toFixed(3)} ${+(w).toFixed(3)},0"/>`) || d.svg.includes(`${+w.toFixed(3)},0"`), 'wall line ends at (w, 0)');
  assert.ok(!d.svg.includes(`0,${+w.toFixed(3)}"`), 'no point at (0, w)');
});
