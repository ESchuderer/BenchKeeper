const test = require('node:test');
const assert = require('node:assert/strict');
const CIP = require('../load.js');
const { format, records } = CIP;
const rec = (k) => records.find((r) => r.key === k);
const rowOf = (groups, group, section, field) =>
  groups[group].find((s) => s.key === section).rows.find((r) => r.field === field);

test('numbers have no trailing zeros and no thousands separator', () => {
  assert.equal(format.number(51.18), '51.18');
  assert.equal(format.number(4150.0), '4150');
  assert.equal(format.number(35.0), '35');
  assert.equal(format.number(-0.2), '-0.2');
});

test('angles', () => {
  assert.equal(format.angle(40), '40°');
  assert.equal(format.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.angle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'0"');
});

test('symbols', () => {
  const s = format.symbol;
  assert.deepEqual(
    ['eMin', 'r1Min', 'r1Max', 'alpha', 'alpha1', 'beta', 'delta', 'deltaL', 'L3PlusG', 'Pmax', 'L3'].map(s),
    ['e min', 'r1 min', 'r1 max', 'α', 'α1', 'β', 'δ', 'delta L', 'L3 + G', 'Pmax', 'L3']
  );
});

test('units', () => {
  const u = format.unit;
  assert.deepEqual(
    ['Pmax', 'PK', 'PE', 'EE', 'M', 'Q', 'N', 'L3', 'u', 'alpha', 'i'].map(u),
    ['bar', 'bar', 'bar', 'J', 'g', 'mm²', '', 'mm', 'mm', '°', '°']
  );
});

test('tolerance is shown next to its value and has no row', () => {
  const g = format.sections(rec('308_win'));
  assert.equal(rowOf(g, 'cartridge', 'lengths', 'L1').value, '39.62 -0.2');
  assert.equal(rowOf(g, 'cartridge', 'lengths', 'L1').unit, 'mm');
  assert.equal(rowOf(g, 'cartridge', 'powderChamber', 'P2').value, '11.53 -0.2');
  const all = [...g.cartridge, ...g.chamber].flatMap((s) => s.rows.map((r) => r.field));
  assert.ok(!all.some((f) => f.endsWith('Tol')));
});

test('sections are grouped and empty ones omitted', () => {
  const g = format.sections(rec('308_win'));
  assert.deepEqual(g.cartridge.map((s) => s.title), [
    'Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile',
  ]);
  assert.deepEqual(g.chamber.map((s) => s.title), [
    'Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling',
  ]);
  const luger = format.sections(rec('9_mm_luger'));
  assert.ok(!luger.cartridge.some((s) => s.key === 'junctionCone'));
  assert.ok(!luger.chamber.some((s) => s.key === 'junctionCone'));
});

test('values as published', () => {
  const g = format.sections(rec('243_win'));
  assert.equal(rowOf(g, 'cartridge', 'pressures', 'Pmax').value, '4150');
  assert.equal(rowOf(g, 'cartridge', 'pressures', 'Pmax').unit, 'bar');
  const r = format.sections(rec('223_rem'));
  assert.equal(rowOf(r, 'chamber', 'rifling', 'i').value, '3°10\'36"');
  assert.equal(rowOf(r, 'chamber', 'junctionCone', 'alpha').value, '46°');
  assert.equal(rowOf(r, 'chamber', 'rifling', 'i').symbol, 'i');
  assert.equal(rowOf(g, 'chamber', 'grooves', 'N').unit, '');
  assert.equal(rowOf(g, 'chamber', 'grooves', 'Q').unit, 'mm²');
});

test('every field of every record is shown exactly once', () => {
  for (const r of records) {
    const g = format.sections(r);
    for (const group of ['cartridge', 'chamber']) {
      const shown = g[group].reduce((n, s) => n + s.rows.length, 0);
      const have = Object.values(r[group]).flatMap((s) => Object.keys(s)).filter((k) => !k.endsWith('Tol')).length;
      assert.equal(shown, have, `${r.key} ${group}`);
    }
  }
});

test('search text and family filter', () => {
  const list = (q, f) => format.filterRecords(records, q, f).map((r) => r.name);
  assert.deepEqual(list('7,62 x 51', ''), ['308 Win.']);
  assert.equal(list('', '').length, 25);
  assert.deepEqual(list('', 'belted'), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.deepEqual(list('  CREED ', ''), ['6,5 Creedmoor']);
  assert.deepEqual(list('win', 'belted'), ['300 Win. Mag.']);
  assert.deepEqual(list('zzz', ''), []);
});

test('facts', () => {
  const f = format.facts(rec('308_win'));
  assert.equal(f.find((x) => x.label === 'C.I.P. table').value, 'I');
  assert.equal(f.find((x) => x.label === 'Alternative names').value, '308 Winchester, 7,62 x 51');
  assert.equal(f.find((x) => x.label === 'Water capacity').capacity.value, '56');
  assert.equal(format.facts(rec('7_x_64')).find((x) => x.label === 'Water capacity').capacity, null);
});
