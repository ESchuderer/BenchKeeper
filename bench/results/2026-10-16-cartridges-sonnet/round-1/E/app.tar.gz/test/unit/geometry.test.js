const test = require('node:test');
const assert = require('node:assert/strict');
const { records, geometry } = require('../load.js');
const rec = (k) => records.find((r) => r.key === k);
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) < eps, `${a} != ${b}`);
const nearPt = (p, r, z) => { near(p[0], r); near(p[1], z); };
const has = (pts, r, z) => pts.some((p) => Math.abs(p[0] - r) < 1e-6 && Math.abs(p[1] - z) < 1e-6);

test('rim types', () => {
  const t = (k) => geometry.rimType(rec(k));
  assert.equal(t('9_3_x_74_r'), 'rimmed');
  assert.equal(t('223_rem'), 'rimless');
  assert.equal(t('300_win_mag'), 'belted');
  assert.equal(t('22_long_rifle'), 'rimfire');
  assert.equal(t('9_mm_luger'), 'rimless');
  assert.equal(geometry.rimType({ family: 'pistol', cartridge: { caseHead: { R1: 9.6 }, powderChamber: { P1: 10.1 } } }), 'rebated');
});

test('fillet on a right angle', () => {
  const f = geometry.fillet([2, 0], [0, 0], [0, 2], 0.5);
  nearPt(f.points[0], 0.5, 0);
  nearPt(f.points[f.points.length - 1], 0, 0.5);
  for (const p of f.points) near(Math.hypot(p[0] - 0.5, p[1] - 0.5), 0.5);
  assert.equal(f.radius, 0.5);
});

test('223 Rem. head, chamfer, groove', () => {
  const g = geometry.compute(rec('223_rem'));
  const p = g.profile;
  nearPt(p[0], 0, 0);
  nearPt(p[1], 4.8 - 0.45 * Math.tan((35 * Math.PI) / 180), 0);
  nearPt(p[2], 4.8, 0.45);
  nearPt(p[3], 4.8, 1.14);
  nearPt(p[4], 8.43 / 2, 1.14);
  nearPt(p[5], 8.43 / 2, 1.14 + 0.76);
  nearPt(p[6], 9.58 / 2, 3.13);
});

test('chamfer run is limited to R1/4', () => {
  const r = JSON.parse(JSON.stringify(rec('223_rem')));
  r.cartridge.caseHead.f = 20;
  r.cartridge.caseHead.R = 30;
  nearPt(geometry.compute(r).profile[1], 4.8 - 2.4, 0);
});

test('belted ramp follows delta up to the belt', () => {
  const g = geometry.compute(rec('300_win_mag'));
  const zr = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  assert.ok(has(g.profile, 13.51 / 2, zr));
  assert.ok(has(g.profile, 13.51 / 2, 5.59));
  assert.ok(has(g.profile, 13.03 / 2, 5.59));
  near(g.w, 3.3 + 1.5);
});

test('rimmed case without groove steps in at z = R', () => {
  const g = geometry.compute(rec('9_3_x_74_r'));
  assert.ok(has(g.profile, 13.35 / 2, 1.4));
  assert.ok(has(g.profile, 11.9 / 2, 1.4));
  assert.deepEqual(g.notes, []);
});

test('rimfire rim edge is a half-round at R1/2', () => {
  const g = geometry.compute(rec('22_long_rifle'));
  const rho = 1.09 / 2;
  nearPt(g.profile[1], 7.06 / 2 - rho, 0);
  assert.ok(has(g.profile, 7.06 / 2, rho));
  assert.ok(g.profile.every((p) => p[0] <= 7.06 / 2 + 1e-9));
  assert.equal(g.pocket, null);
});

test('308 Win. shoulder is rounded, neck ends at the mouth', () => {
  const g = geometry.compute(rec('308_win'));
  assert.equal(g.bottleneck, true);
  assert.ok(!has(g.profile, 11.53 / 2, 39.62), 'corner at L1 replaced by an arc');
  assert.ok(!has(g.profile, 8.72 / 2, 43.48), 'corner at L2 replaced by an arc');
  const last = g.profile[g.profile.length - 1];
  nearPt(last, 8.72 / 2, 51.18);
  const near1 = g.profile.filter((p) => Math.abs(p[1] - 39.62) < 0.6 && p[0] > 5);
  assert.ok(near1.length >= 3);
});

test('9 mm Luger is straight', () => {
  const g = geometry.compute(rec('9_mm_luger'));
  assert.equal(g.bottleneck, false);
  nearPt(g.profile[g.profile.length - 1], 9.65 / 2, 19.15);
  assert.ok(g.profile.every((p) => p[1] <= 19.15 + 1e-9));
});

test('walls and solid head of 223 Rem.', () => {
  const g = geometry.compute(rec('223_rem'));
  near(g.walls.tn, (6.43 - 5.7) / 2);
  near(g.walls.tb, 0.6);
  assert.deepEqual(g.pocket, { diameter: 4.45, depth: 3.04 });
  near(g.w, 4.54);
});

test('308 Win. walls, inner line and pocket', () => {
  const g = geometry.compute(rec('308_win'));
  near(g.walls.tn, 0.435);
  near(g.walls.tb, 0.6);
  assert.deepEqual(g.pocket, { diameter: 5.33, depth: 3.3 });
  const first = g.inner[0];
  near(first[1], g.w);
  const last = g.inner[g.inner.length - 1];
  nearPt(last, 8.72 / 2 - 0.435, 51.18);
  for (let i = 1; i < g.inner.length; i++) assert.ok(g.inner[i][1] >= g.inner[i - 1][1] - 1e-9);
});

test('308 Win. pointy bullet', () => {
  const b = geometry.compute(rec('308_win')).bullet;
  near(b.s, 7.85);
  near(b.zb, 43.33);
  near(b.zn, 43.33 + 0.4 * (71.12 - 43.33));
  near(b.m, 1.27);
  assert.equal(b.heeled, false);
  const e = b.exposed;
  nearPt(e[0], 7.85 / 2, 51.18);
  nearPt(e[e.length - 1], 0, 71.12);
  nearPt(e[e.length - 2], 1.27 / 2, 71.12);
  const rho = ((7.85 / 2 - 0.635) ** 2 + b.n ** 2) / (2 * (7.85 / 2 - 0.635));
  near(b.rho, rho);
  assert.ok(e.every((p) => p[1] >= 51.18 - 1e-9));
  assert.ok(b.section[0][1] === b.zb && b.section[0][0] === 0);
});

test('bullet shapes use their seating depth and meplat', () => {
  const b = (k) => geometry.compute(rec(k)).bullet;
  near(b('45_auto').s, 0.4 * 11.48);
  near(b('45_auto').m, 0.15 * 11.48);
  near(b('45_auto').k, 0.65);
  near(b('40_s_w').s, 0.4 * 10.17);
  near(b('40_s_w').m, 0.55 * 10.17);
  near(b('40_s_w').k, 0.7);
  near(b('357_magnum').s, 0.6 * 9.12);
  near(b('357_magnum').m, 0.6 * 9.12 * 1.0);
  near(b('357_magnum').k, 0.78);
  near(b('22_win_mag_r_f').s, 0.8 * 5.7);
  near(b('22_win_mag_r_f').k, 0.55);
  near(b('17_hmr').s, 4.38);
});

test('22 Long Rifle is heeled', () => {
  const g = geometry.compute(rec('22_long_rifle'));
  assert.equal(g.bullet.heeled, true);
  near(g.bullet.diameter, 5.72);
  near(g.bullet.heelRadius, 5.72 / 2 - g.walls.tb);
  near(g.walls.tb, 0.6);
  near(g.walls.tnEff, 0.6);
});

test('missing values are named, never invented', () => {
  const lap = geometry.compute(rec('338_lapua_mag'));
  assert.ok(lap.notes.some((n) => n.includes('r1 min')));
  assert.ok(!lap.notes.some((n) => n.includes('r2')));
  const hmr = geometry.compute(rec('17_hmr'));
  assert.ok(hmr.notes.some((n) => n.includes('r1 min')) && hmr.notes.some((n) => n.includes('r2')));
  assert.deepEqual(geometry.compute(rec('308_win')).notes, []);
  const broken = JSON.parse(JSON.stringify(rec('223_rem')));
  delete broken.cartridge.caseHead.eMin;
  const g = geometry.compute(broken);
  assert.ok(g.notes.some((n) => n.includes('e min')));
  assert.ok(!has(g.profile, 8.43 / 2, 1.14));
  const bad = JSON.parse(JSON.stringify(rec('223_rem')));
  delete bad.cartridge.lengths.L3;
  assert.deepEqual(geometry.compute(bad).missing, ['L3']);
});

test('all records give finite, ordered profiles', () => {
  for (const r of records) {
    const g = geometry.compute(r);
    assert.ok(g.profile.length > 5, r.key);
    for (let i = 0; i < g.profile.length; i++) {
      const [rr, z] = g.profile[i];
      assert.ok(Number.isFinite(rr) && Number.isFinite(z) && rr >= 0, `${r.key} ${i}`);
      if (i) assert.ok(z >= g.profile[i - 1][1] - 1e-9, `${r.key} z order at ${i}`);
    }
    near(g.profile[g.profile.length - 1][1], r.cartridge.lengths.L3);
    near(g.bullet.exposed[g.bullet.exposed.length - 1][1], r.cartridge.lengths.L6);
    assert.ok(g.inner.every((p) => p[0] > 0), `${r.key} inner radius positive`);
    assert.ok(g.w < r.cartridge.lengths.L3, r.key);
  }
});

test('belted inner wall has no step', () => {
  const g = geometry.compute(rec('300_win_mag'));
  for (let i = 1; i < g.inner.length; i++) assert.ok(g.inner[i][1] > g.inner[i - 1][1], `strictly increasing z at ${i}`);
  near(g.inner[0][0], 13.03 / 2 - g.walls.tb);
});
