# C.I.P. cartridge reference

Static reference database of 25 C.I.P. cartridges with computed, to-scale 2D drawings.

**Use:** open `index.html` directly in a browser (works from `file://`), or serve the folder with any static file server (`npm run serve`). No build step, no runtime dependencies, no network requests.

- `index.html`, `css/`, `js/`, `data/cartridges.js` — the app (classic scripts, namespace `CIP`).
- `data/cartridges.jsonl` — the 25 records as given; `data/cartridges.js` is generated from it (`npm run data`) and tested equal.
- `SPEC.md`, `tasks/` — specification, plan, task list.

**Tests (dev only):** `npm run test:unit` (Node 22, no install needed) covers data, formatting, geometry rules, label layout for all 25 records. `npm run test:e2e` (Playwright + Chromium; `npm install` then `npx playwright install chromium`) covers `file://` and http, drawing label overlaps with real `getBBox`, phone width, dark mode and one-page A4 print of all 25 cartridges.
