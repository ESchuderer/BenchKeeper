# Spec: C.I.P. Cartridge Reference (static web app)

Status: **Implemented.** Decisions D1–D14 were applied as proposed (the user asked to continue without waiting for approval). Deviations: the title block scale reads "Scale n : 1 (A4 print)"; a missing essential value (R, R1, P1, H2, L3) yields a "Drawing not available" note; L1, L2, P2, H1 dimensions are drawn only for bottleneck cases.

## Phase 0 — scope check

The brief is one deliverable with one consumer (a technical reader of one static site). It does not split into independently shippable capabilities, so no capability map is proposed. The internal module layout (data → format → geometry → layout/drawing → views) is in *Project Structure*. If you want a formal map with per-module specs, say so.

## Objective

A reference database of 25 C.I.P. cartridges, modelled on the OpenBallistics cartridge database, for reloaders, gunsmiths and engineers. They want exact published values, a trustworthy scale drawing and a clean one-page print.

- **Start page:** searchable, filterable list of the 25 cartridges.
- **Detail view:** one cartridge, with metadata, a computed 2D drawing, and value tables for cartridge and chamber. It has a stable bookmarkable address and a one-page A4 print.
- **Data:** only the 25 records in the brief. Nothing is added, changed or fetched. Nothing is converted (country stays `US`, names stay `6,5 Creedmoor`, dates stay ISO).

### Success criteria (testable)

| # | Criterion | How verified |
|---|---|---|
| S1 | `index.html` works from `file://` in Chromium and from any static server; zero network requests | e2e on both; request log empty |
| S2 | Start page: h1 "Cartridges"; 25 rows (name link with text exactly `name`, family, L3); "25 cartridges" | e2e |
| S3 | "Search" filters live on name + alternative names; `7,62 x 51` → only "308 Win."; "Family" select (All, rimless, rimmed, belted, pistol, rimfire) filters; count text updates | unit (filter fn) + e2e |
| S4 | Detail view at its own URL (`#/cartridge/<key>`), survives reload, unknown key shows a not-found message with link to the list | e2e |
| S5 | Detail shows every item in the brief; tables have columns Symbol/Value/Unit; `*Tol` shown next to its value, never as a row | unit + e2e |
| S6 | Values formatted as published (`51.18`, `4150`, `39.62 -0.2`, `40°`, `39°59'49"`); symbols per the mapping | unit |
| S7 | Drawing: true to scale (1 unit = 1 mm), accessible name `<name> drawing`, all required dimensions/labels present, labels never overlap each other or the outline — for **all 25** records | unit (geometry + label boxes) + e2e (`getBBox`) |
| S8 | Geometry rules 1–9 implemented exactly; missing values produce a visible note naming the value, never an invented number | unit per rule; unit over all 25 |
| S9 | Print: every detail view is **one A4 portrait page**, light, no nav/search/buttons, header, full-width drawing, footer with source and revised date, every label ≥ 7 pt | e2e: `page.pdf()` page count = 1 for all 25; screenshot review |
| S10 | Light/dark follow the system; print always light; usable at 360 px width without horizontal scroll | e2e with `colorScheme`, viewport 360 |
| S11 | Plain HTML/CSS/JS, no framework, build step, runtime dependency or network | file inspection; S1 |

## Assumptions (correct me now or I proceed)

1. Hash routing (`index.html#/cartridge/308_win`) is the "own address". It works on `file://` and on any static server, with no server config. The `key` field is the id.
2. **Classic scripts, no ES modules.** Chromium blocks module scripts and `fetch` of local files on `file://`. Data therefore ships as `data/cartridges.js` (assigns a global), generated mechanically from the brief's JSONL (`data/cartridges.jsonl`, kept as the source and tested for equality). Code uses one namespace `CIP` and a small UMD wrapper so the same files load in Node for tests.
3. List order is the order of the dataset. Sections in the tables follow the data's section order and omit empty sections (pistols have an empty `junctionCone`). Rows follow the data's field order.
4. Out of scope: the `annotations.confidence`, `implausible`, `defaultBullet` details (except `category`, `primerType`, `defaultBulletShape`, `publishedCapacity` which the brief uses), saving list filters across navigation, i18n, unit conversion, editing data.
5. `n cartridges` text is literal (`1 cartridges` for one).
6. Search is case- and whitespace-insensitive substring (`7,62x51` also finds 308 Win.).
7. Tests need Chromium. The npm registry is reachable here, but no browser is installed. I will install Playwright's Chromium as a dev tool; if the download is blocked I will report it and fall back (see Open Questions).

## Decisions where the brief is silent or ambiguous (please confirm or change)

| # | Situation | Proposed decision |
|---|---|---|
| D1 | Coordinates in the rules are written `(r, z)`: e.g. `(R1/2, f)` = radius R1/2 at z = f. | Read as (r, z) throughout. |
| D2 | **Straight cases** (no alpha/L1/L2) have no shoulder to blend `tb → tn` across, yet the bullet (G1) must fit the mouth (`tn`). | Inner line: wall `tb` at `z = w`, blends linearly to `tn` at the bullet base `zb`, then `tn` to the mouth. The seated bullet then touches the wall instead of overlapping it. |
| D3 | **Heeled case** (22 LR): `tn = (H2−G1)/2 = 0`, which would give a zero-thickness mouth, yet the heel is seated in an inside diameter of `H2 − 2·tb`. | Heeled: `tn := tb` (uniform wall). Exposed bullet diameter = H2, seated heel diameter = H2 − 2·tb. |
| D4 | Fillet radii `r1 min`/`r2` too large for the shoulder length (tangent lengths sum > shoulder length). | Scale both radii down proportionally so they fit; the note "fillet reduced to fit" is shown. (I expect no record to need it; a test over all 25 will confirm.) |
| D5 | Rule 9 "say which value is missing" vs. features marked "where published" (e.g. 17 HMR has no r1 min / r2; 338 Lapua no r1 min). | List them in the drawing notes ("not drawn: r1 min not published"). For rimmed/rimfire families the extractor groove is not expected, so no groove note there. |
| D6 | **Title block scale.** On screen the scale depends on window width. | The print stylesheet fixes the drawing width (A4 content width), so the title block states the print scale, e.g. `Scale 1.6 : 1 (A4 print)`; the SVG's own unit is 1 mm. |
| D7 | **Phone legibility.** The drawing is ~100–140 mm wide and must fit ~340 px, so text is ~2.4 px/mm. | Label height 2.5 units (≈ 6–7 px at 360 px, ≈ 8.5 pt in print). Phone users pinch-zoom; no horizontal scroll (the brief requires scaling to width). |
| D8 | **Rebated rim**: no record is rebated (all 25 are rimless/rimmed/belted/pistol-rimmed/rimfire). | Classification implemented and unit-tested with synthetic fixtures; geometry is unchanged (the step from R1/2 to P1/2 is drawn whichever direction). |
| D9 | Rule 2 priority when several apply. | Chamfer if beta & f published and beta < 90°; else rimfire half-round for family `rimfire`; else square corner. (22 LR: beta = 0 but no `f` → half-round.) |
| D10 | Angle unit cell. | Value cell `40°` / `39°59'49"`, Unit cell `deg`. |
| D11 | Units not named in the brief (u, b, h, s, G, S, Z, F, Fe, L4, L5, G2 …) are lengths. | Unit `mm`, except `N` (blank), `Q` (mm²), pressures (bar), EE (J), M (g), angles (deg). |
| D12 | Water capacity unit. | `grH2O` shown as `30.5 gr H2O`, with the `note` as published and the source name as the link text (`kwk`, `wiki`) to `url`; records without it show "not published". The link opens in a new tab with `rel="noopener noreferrer"`. |
| D13 | Drawing layers. | Case walls are drawn above the bullet; bullet below, so a seated base that reaches into the shoulder zone (e.g. 223 Rem.: pointy seating depth 5.7 > neck 5.15) is never clipped wrongly. |
| D14 | Label placement strategy (where each dimension sits). | Chosen in the plan by prototyping; the hard requirement is S7 (no overlaps, arrowheads, extension lines) verified by computed label boxes for all 25. |

## Tech stack

Plain HTML, CSS, JavaScript (ES2022 in classic scripts), no framework. Node.js 22.

Dev dependencies only:
- `node:test` + `node:assert` — unit tests (built in, nothing to install).
- `@playwright/test` — e2e in Chromium (`file://` and static server), print PDF page count, colour-scheme and phone viewport checks.
- *(optional, ask first)* `@axe-core/playwright` — automated accessibility check.

## Commands

```
Install:      npm install
Unit tests:   npm run test:unit        # node --test tests/unit
E2E tests:    npm run test:e2e         # playwright test (file:// and http)
All tests:    npm test
Serve:        npm run serve            # node scripts/serve.mjs  (dev only, static, port 8080)
Regenerate data file: npm run data     # node scripts/build-data.mjs  (JSONL → data/cartridges.js)
Open:         xdg-open index.html      # or open file:///work/index.html in Chromium
```

## Project structure

```
index.html              → shell: header, <main id="app">, classic <script> tags in dependency order
css/app.css             → tokens, layout, tables, light/dark (prefers-color-scheme)
css/print.css           → @media print (A4 portrait, light, one page)
data/cartridges.jsonl   → the 25 records exactly as given (source of truth)
data/cartridges.js      → same data as `CIP.data = [...]` for file:// use (generated, tested equal)
js/format.js            → numbers, angles, tolerances, symbols, units, dates (pure)
js/model.js             → record → view model: metadata, table sections (pure)
js/geometry.js          → rim type, outer profile, fillets, walls, bullet, pocket, notes (pure)
js/dimensions.js        → dimension/label placement + overlap checks (pure)
js/drawing.js           → geometry + dimensions → SVG element (DOM, no layout logic)
js/filter.js            → search + family filter (pure)
js/router.js            → hash parsing/building (pure) + hashchange wiring
js/views.js             → list view, detail view (DOM)
js/app.js               → boot
tests/unit/*.test.js    → node:test, one file per module
tests/e2e/*.spec.js     → Playwright
scripts/                → build-data.mjs, serve.mjs (dev only)
tasks/plan.md, tasks/todo.md
SPEC.md
```

## Code style

Small pure functions, no globals except `CIP`, `'use strict'`, 2-space indent, semicolons, single quotes, camelCase, JSDoc for shapes. Comments only for non-obvious geometry. Points are `{ r, z }` objects (never bare arrays), so the (r, z) convention cannot be confused.

```js
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else (root.CIP = root.CIP || {}).format = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /** @param {number|{degrees:number,minutes:number,seconds:number}} a */
  function formatAngle(a) {
    if (typeof a === 'number') return `${a}°`;
    const { degrees, minutes, seconds } = a;
    if (!minutes && !seconds) return `${degrees}°`;
    return `${degrees}°${minutes}'${seconds}"`;
  }

  return { formatAngle };
});
```

Note: `39°59'49"` must print exactly; `{degrees:3,minutes:10,seconds:36}` → `3°10'36"`. Zero minutes and seconds (`{degrees:40,minutes:0,seconds:0}`) print as `40°`. Seconds-only is unlikely in the data; the unit test pins the chosen behaviour.

## Testing strategy

TDD: the failing test comes first for every pure module; the browser tests are written before the views.

- **Unit (`node:test`)**: format (every angle form in the data, `4150.0 → 4150`, tolerances, all symbol overrides, units); data integrity (25 records, `cartridges.js` deep-equals `cartridges.jsonl`, keys unique); filter (the `7,62 x 51` case, alt names, family, no match); router; model (no `*Tol` rows, empty sections omitted); geometry per rule with hand-computed expectations (for example 308 Win.: chamfer start `r = R1/2 − min(f·tanβ, R1/4)`; ogive radius ρ from the formula; w = 4.8 for 308); **every record**: profile is monotone in z, has no NaN, bullet fits in the case, fillets fit, notes list exactly the missing values; dimensions: every required dimension present, labels pairwise non-overlapping and clear of the outline for all 25.
- **E2E (Playwright, Chromium)**: S1–S4, S9, S10 against `file://` and a static server; zero requests; a smoke pass over all 25 detail views (no console errors, SVG named `<name> drawing`); print PDF = 1 page for all 25; light/dark screenshots; 360 px viewport (no horizontal overflow).
- **Visual check**: I render drawings to PNG and review them myself for the cases the tests cannot judge (belted, rimfire, heeled 22 LR, straight pistol, bottleneck with large fillets such as 7,62 x 39 and 6,5 x 55 SE).
- Coverage is not a numeric target. The target is every rule in the brief having a test, and all 25 records passing the invariants.

## Boundaries

- **Always:** write the test first; run the full suite before declaring a task done; use only values from the records; show values as published; state missing values on the drawing; keep the app free of network access; respect `file://` constraints (classic scripts only).
- **Ask first:** adding any dev dependency beyond Playwright; changing a decision above; showing data not named in the brief; adding any runtime dependency (the answer is expected to be no).
- **Never:** invent, round, convert or "correct" a data value; add network requests, CDNs, web fonts or analytics; use a framework or build step for the app; weaken or delete a failing test to get to green; use `innerHTML` with record strings (names and notes are inserted as text); commit `node_modules`.

## Notable observations from the data

- Rim types by rule 1: 223 Rem., 6,5 x 55 SE (R1/P1 = 1.00) and others are rimless; 7 x 65 R, 9,3 x 74 R, 38 Special, 357 Magnum, 44 Rem. Mag. are rimmed (ratio ≥ 1.05); 300 Win. Mag. and 7 mm Rem. Mag. are belted; the three rimfire records are rimfire; **none is rebated**.
- 22 Long Rifle is heeled (H2 − G1 = 0) and straight; 22 Win. Mag. R.F. is straight and not heeled; 17 HMR is a rimfire bottleneck without r1 min / r2.
- 9,3 x 74 R, 7 x 65 R, 38 Special, 357 Magnum, 44 Rem. Mag. and all rimfires have no E/E1 (no groove). 7,62 x 39 has the largest fillets relative to its shoulder (r1 min 4.0, r2 3.0, shoulder ≈ 2.6 mm long) and is the first case to check for D4; my hand estimate is that it still fits, which a test will confirm.
- Seven records have no published water capacity; 7 mm Rem. Mag. lists `G2 = 68.61`, which is shown as published even though it looks like an overall length (the app does not judge data).

## Open questions

1. Are D1–D14 acceptable as written? D2, D3, D5 and D6 are the ones that change the drawing most.
2. If Chromium cannot be downloaded in this container, should I (a) stop and report, or (b) use unit tests plus SVG-to-PNG review only and state clearly that print/`file://` were not browser-verified? I propose (a).
3. Should `annotations.confidence` ("verified"/"unverified") be shown? It is not in the brief, so by default it is not.
