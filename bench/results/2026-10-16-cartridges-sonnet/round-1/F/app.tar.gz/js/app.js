(function () {
  'use strict';
  const CIP = window.CIP;
  const app = document.getElementById('app');
  let first = true;

  function route() {
    const r = CIP.router.parseHash(location.hash);
    let view;
    let title = 'C.I.P. cartridges';
    if (r.view === 'list') {
      view = CIP.views.renderList(CIP.data);
      title = 'Cartridges – C.I.P. reference';
    } else if (r.view === 'detail') {
      const record = CIP.data.find((c) => c.key === r.key);
      if (record) {
        view = CIP.views.renderDetail(record);
        title = `${record.name} – C.I.P. reference`;
      } else {
        view = CIP.views.renderNotFound();
      }
    } else {
      view = CIP.views.renderNotFound();
    }
    app.replaceChildren(view);
    document.title = title;
    if (!first) {
      window.scrollTo(0, 0);
      const h1 = app.querySelector('h1');
      if (h1) h1.focus({ preventScroll: true });
    }
    first = false;
  }

  window.addEventListener('hashchange', route);
  route();
})();
