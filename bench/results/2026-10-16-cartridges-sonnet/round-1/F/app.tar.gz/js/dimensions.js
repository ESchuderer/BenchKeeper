(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'), require('./geometry.js'));
  else (root.CIP = root.CIP || {}).dimensions = factory(root.CIP.format, root.CIP.geometry);
})(typeof self !== 'undefined' ? self : this, function (format, geometry) {
  'use strict';

  // SVG space: x = z (mm), y = -r in the upper (outside) half, +r in the lower (section) half. 1 unit = 1 mm.
  const FONT = 2.4; // label height in mm
  const TITLE_FONT = 3.2;
  const SMALL_FONT = 2.1;
  const CHAR_W = 0.66; // average glyph width / font size; deliberately generous so wider fallback fonts still fit
  const ARROW_L = 1.6;
  const ARROW_W = 0.55;
  const EXT_GAP = 0.8; // gap between the part and an extension line
  const EXT_OVER = 1.2; // extension line overshoot beyond the dimension line
  const ROW_TOP = 4.4;
  const ROW_BOTTOM = 3.5;
  const DELTA = 1.8; // offset of a diameter dimension line from its feature
  const MARGIN = 3;
  const PRINT_WIDTH_MM = 186; // A4 portrait content width (210 mm minus 2 x 12 mm); must match css/print.css
  const PRINT_MAX_HEIGHT_MM = 156; // keeps tall, narrow drawings (22 LR) from pushing the tables to a second page
  const DEG = Math.PI / 180;

  const has = (v) => typeof v === 'number' && Number.isFinite(v);
  const textWidth = (text, fs) => text.length * CHAR_W * fs;

  /** Box of a label; (x, y) is the text anchor position and baseline. */
  function labelBox(x, y, text, fs, anchor) {
    const w = textWidth(text, fs);
    const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0, x1: x0 + w, y0: y - 0.78 * fs, y1: y + 0.25 * fs };
  }

  const seg = (x1, y1, x2, y2, cls) => ({ x1, y1, x2, y2, cls });

  /** Triangle with its tip at (x, y) pointing along unit vector (dx, dy). */
  function arrow(x, y, dx, dy) {
    const bx = x - dx * ARROW_L;
    const by = y - dy * ARROW_L;
    return [
      { x, y },
      { x: bx - dy * ARROW_W, y: by + dx * ARROW_W },
      { x: bx + dy * ARROW_W, y: by - dx * ARROW_W },
    ];
  }

  function boxHitsSegment(b, s) {
    const inside = (x, y) => x >= b.x0 && x <= b.x1 && y >= b.y0 && y <= b.y1;
    if (inside(s.x1, s.y1) || inside(s.x2, s.y2)) return true;
    const edges = [
      [b.x0, b.y0, b.x1, b.y0], [b.x1, b.y0, b.x1, b.y1], [b.x1, b.y1, b.x0, b.y1], [b.x0, b.y1, b.x0, b.y0],
    ];
    return edges.some((e) => segmentsCross(s.x1, s.y1, s.x2, s.y2, e[0], e[1], e[2], e[3]));
  }

  function segmentsCross(ax, ay, bx, by, cx, cy, dx, dy) {
    const o = (px, py, qx, qy, rx, ry) => (qx - px) * (ry - py) - (qy - py) * (rx - px);
    const d1 = o(cx, cy, dx, dy, ax, ay);
    const d2 = o(cx, cy, dx, dy, bx, by);
    const d3 = o(ax, ay, bx, by, cx, cy);
    const d4 = o(ax, ay, bx, by, dx, dy);
    if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) return true;
    return false;
  }

  const boxesOverlap = (a, b, pad) => a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
  const pad = (b, p) => ({ x0: b.x0 - p, x1: b.x1 + p, y0: b.y0 - p, y1: b.y1 + p });

  /** Silhouette and section outlines as SVG-space segments (obstacles for labels). */
  function outlineSegments(c) {
    const out = [];
    const poly = (pts, sign) => {
      for (let i = 1; i < pts.length; i++) out.push(seg(pts[i - 1].z, sign * pts[i - 1].r, pts[i].z, sign * pts[i].r, 'outline'));
    };
    poly(c.outer, -1);
    poly(c.outer, 1);
    if (c.bullet) {
      poly(c.bullet.exposed, -1);
      poly(c.bullet.seated, 1);
    }
    if (c.section) {
      poly(c.section, 1);
    }
    return out;
  }

  /** Builds the dimension layout of one cartridge. */
  function buildLayout(record, c) {
    const L = record.cartridge.lengths;
    const ch = record.cartridge.caseHead;
    const P = record.cartridge.powderChamber;
    const col = record.cartridge.collar;
    const junction = record.cartridge.junctionCone || {};
    const G1 = record.cartridge.projectile.G1;
    const fs = FONT;
    const val = (field, v) => format.formatValue(field, v).value;
    const labelText = (field, v) => `${format.symbolFor(field)} ${val(field, v)}`;

    const rTop = Math.max(...c.outer.map((p) => p.r), c.bullet ? c.bullet.radius : 0);
    const dims = [];
    const outline = outlineSegments(c);
    const L6 = L.L6;
    const xEnd = has(L6) ? L6 : L.L3;

    // ---- length dimensions: stacked rows above the part, shortest nearest ----
    const horizontals = [];
    const rimTopY = -ch.R1 / 2;
    horizontals.push({ field: 'R', span: ch.R, z0: 0, z1: ch.R, f0: rimTopY, f1: rimTopY });
    if (c.bottleneck) {
      horizontals.push({ field: 'L1', span: L.L1, z0: 0, z1: L.L1, f0: rimTopY, f1: -P.P2 / 2 });
      horizontals.push({ field: 'L2', span: L.L2, z0: 0, z1: L.L2, f0: rimTopY, f1: -col.H1 / 2 });
    }
    horizontals.push({ field: 'L3', span: L.L3, z0: 0, z1: L.L3, f0: rimTopY, f1: -col.H2 / 2 });
    if (has(L6) && c.bullet) {
      horizontals.push({ field: 'L6', span: L6, z0: 0, z1: L6, f0: rimTopY, f1: -c.bullet.nose[c.bullet.nose.length - 1].r });
    }
    horizontals.sort((a, b) => a.span - b.span);
    horizontals.forEach((h, k) => {
      const y = -(rTop + 3.6 + k * ROW_TOP);
      const value = { R: ch.R, L1: L.L1, L2: L.L2, L3: L.L3, L6: L6 }[h.field];
      const text = labelText(h.field, value);
      const w = textWidth(text, fs);
      const inner = h.span >= w + 1.2; // the label sits above the dimension line, between the extension lines
      const lines = [];
      const arrows = [];
      lines.push(seg(h.z0, h.f0 - EXT_GAP, h.z0, y - EXT_OVER, 'ext'));
      lines.push(seg(h.z1, h.f1 - EXT_GAP, h.z1, y - EXT_OVER, 'ext'));
      // arrows touch the extension lines from inside; on tight spans from outside with the line extended
      if (h.span >= 2 * ARROW_L + 0.4) {
        lines.push(seg(h.z0, y, h.z1, y, 'dim'));
        arrows.push(arrow(h.z0, y, -1, 0), arrow(h.z1, y, 1, 0));
      } else {
        lines.push(seg(h.z0 - 2.2, y, h.z1 + 2.2, y, 'dim'));
        arrows.push(arrow(h.z0, y, 1, 0), arrow(h.z1, y, -1, 0));
      }
      const label = inner
        ? { x: (h.z0 + h.z1) / 2, y: y - 1.5, anchor: 'middle' }
        : { x: h.z1 + 2.2 + ARROW_L + 0.6, y: y - 1.5, anchor: 'start' };
      label.text = text;
      label.fontSize = fs;
      label.box = labelBox(label.x, label.y, text, fs, label.anchor);
      dims.push({ id: h.field, kind: 'length', symbol: format.symbolFor(h.field), value: val(h.field, value), text, lines, arrows, label });
    });

    // ---- diameter dimensions: vertical lines at the feature, labels in rows below the part ----
    const verticals = [];
    const rimZ = c.rimType === 'rimfire' ? Math.min(ch.R / 2, (ch.R1 - P.P1) / 2) : ((has(ch.f) && has(ch.beta) ? ch.f : 0) + ch.R) / 2;
    verticals.push({ field: 'R1', value: ch.R1, z: rimZ });
    if (c.anchors.groove) verticals.push({ field: 'E1', value: ch.E1, z: ch.R + ch.eMin / 2 });
    verticals.push({ field: 'P1', value: P.P1, z: c.anchors.bodyStartZ });
    if (c.bottleneck) {
      verticals.push({ field: 'P2', value: P.P2, z: L.L1 });
      verticals.push({ field: 'H1', value: col.H1, z: L.L2 });
    }
    verticals.push({ field: 'H2', value: col.H2, z: L.L3 });
    if (c.bullet && has(G1)) verticals.push({ field: 'G1', value: G1, z: c.bullet.zc });
    for (const v of verticals) {
      v.r = v.value / 2;
      v.x = v.z + DELTA;
      v.text = labelText(v.field, v.value);
      v.w = textWidth(v.text, fs);
    }
    verticals.sort((a, b) => b.x - a.x); // rightmost first: its leader is the shortest

    const rBottom = rTop;
    const rowY = (k) => rBottom + 3.2 + k * ROW_BOTTOM;
    const placed = []; // { box, stub }
    let deepest = -1;
    for (const v of verticals) {
      let row = 0;
      for (;; row++) {
        const y = rowY(row);
        const box = pad(labelBox(v.x + 0.8, y + 0.78 * fs * 0.5 - 0.1, v.text, fs, 'start'), 0.4);
        const stub = seg(v.x, v.r, v.x, y, 'dim');
        const clashes = placed.some((p) => boxesOverlap(box, p.box, 0) || boxHitsSegment(box, p.stub)) || placed.some((p) => boxHitsSegment(p.box, stub));
        if (!clashes) {
          placed.push({ box, stub });
          break;
        }
      }
      v.row = row;
      deepest = Math.max(deepest, row);
      const y = rowY(row);
      const lines = [
        seg(v.z, -v.r - 0, v.x + 0.8, -v.r, 'ext'),
        seg(v.z, v.r, v.x + 0.8, v.r, 'ext'),
        seg(v.x, -v.r, v.x, v.r, 'dim'),
        seg(v.x, v.r, v.x, y, 'dim'),
      ];
      const arrows = [arrow(v.x, -v.r, 0, -1), arrow(v.x, v.r, 0, 1)];
      const base = y + 0.78 * fs * 0.5 - 0.1;
      const label = { x: v.x + 0.8, y: base, anchor: 'start', text: v.text, fontSize: fs };
      label.box = labelBox(label.x, label.y, v.text, fs, 'start');
      dims.push({ id: v.field, kind: 'diameter', symbol: format.symbolFor(v.field), value: val(v.field, v.value), text: v.text, lines, arrows, label });
    }

    // ---- bottom band: title block (left) and shoulder angle (right) ----
    const bandTop = rowY(Math.max(deepest, 0)) + 4.2;
    const titleLines = [];
    const tbX = 0;
    const nameW = textWidth(record.name, TITLE_FONT);
    const col2 = Math.max(textWidth(`C.I.P. table ${record.tab}`, SMALL_FONT), textWidth('Dimensions in mm', SMALL_FONT)) + 4;
    const revText = `Revised ${record.revised}`;
    const rightW = Math.max(textWidth(revText, SMALL_FONT), textWidth('Scale 9.9 : 1 (A4 print)', SMALL_FONT));
    const tbW = Math.max(nameW + 6, col2 + rightW + 4, 52);
    const tbH = 13.2;
    const tb = { x: tbX, y: bandTop, w: tbW, h: tbH };
    titleLines.push({ x: tbX + 2, y: bandTop + 4.4, text: record.name, cls: 'title-name', fontSize: TITLE_FONT, anchor: 'start' });
    titleLines.push({ x: tbX + 2, y: bandTop + 8.0, text: `C.I.P. table ${record.tab}`, cls: 'title-line', fontSize: SMALL_FONT, anchor: 'start' });
    titleLines.push({ x: tbX + 2 + col2, y: bandTop + 8.0, text: revText, cls: 'title-line', fontSize: SMALL_FONT, anchor: 'start' });
    titleLines.push({ x: tbX + 2, y: bandTop + 11.4, text: 'Dimensions in mm', cls: 'title-line', fontSize: SMALL_FONT, anchor: 'start' });
    const scaleSlot = { x: tbX + 2 + col2, y: bandTop + 11.4 };

    // shoulder angle: wedge parallel to the shoulder cone, legs opening towards the body
    let wedge = null;
    const alpha = junction.alpha;
    if (c.bottleneck && alpha !== undefined) {
      const half = (format.angleToDegrees(alpha) * DEG) / 2;
      const arcR = Math.max(5.5, 2.6 / (2 * Math.sin(half)));
      const legL = arcR + 2.6;
      const text = labelText('alpha', alpha);
      const vx = tbX + tbW + 6 + legL * Math.cos(half);
      const vy = bandTop + tbH / 2;
      const lines = [
        seg(vx, vy, vx - legL * Math.cos(half), vy - legL * Math.sin(half), 'ext'),
        seg(vx, vy, vx - legL * Math.cos(half), vy + legL * Math.sin(half), 'ext'),
      ];
      const n = 24;
      const arc = [];
      for (let i = 0; i <= n; i++) {
        const t = Math.PI - half + (2 * half * i) / n;
        arc.push({ x: vx + arcR * Math.cos(t), y: vy + arcR * Math.sin(t) });
      }
      const tA = arc[0];
      const tB = arc[n];
      // arrowheads at both arc ends, pointing along the arc towards the legs
      const dirA = unitVec(arc[0].x - arc[1].x, arc[0].y - arc[1].y);
      const dirB = unitVec(arc[n].x - arc[n - 1].x, arc[n].y - arc[n - 1].y);
      const label = { x: vx + 1.6, y: vy + 0.78 * fs * 0.5 - 0.1, anchor: 'start', text, fontSize: fs };
      label.box = labelBox(label.x, label.y, text, fs, 'start');
      wedge = {
        id: 'alpha', kind: 'angle', symbol: format.symbolFor('alpha'), value: val('alpha', alpha), text,
        lines, arc, arrows: [arrow(tA.x, tA.y, dirA.x, dirA.y), arrow(tB.x, tB.y, dirB.x, dirB.y)], label,
      };
      dims.push(wedge);
    }

    // ---- extents, scale ----
    let minX = 0;
    let maxX = xEnd;
    let minY = -rTop;
    let maxY = rTop;
    const grow = (x, y) => { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); };
    for (const d of dims) {
      for (const s of d.lines) { grow(s.x1, s.y1); grow(s.x2, s.y2); }
      for (const a of d.arrows) for (const p of a) grow(p.x, p.y);
      for (const p of d.arc || []) grow(p.x, p.y);
      grow(d.label.box.x0, d.label.box.y0);
      grow(d.label.box.x1, d.label.box.y1);
    }
    grow(-4, 0);
    grow(xEnd + 4, 0);
    grow(tb.x, tb.y);
    grow(tb.x + tb.w, tb.y + tb.h);
    const viewBox = { x: minX - MARGIN, y: minY - MARGIN, w: maxX - minX + 2 * MARGIN, h: maxY - minY + 2 * MARGIN };

    const printWidthMm = Math.min(PRINT_WIDTH_MM, (PRINT_MAX_HEIGHT_MM * viewBox.w) / viewBox.h);
    const printScale = printWidthMm / viewBox.w;
    const scaleText = (printScale >= 1 ? `Scale ${printScale.toFixed(1)} : 1` : `Scale 1 : ${(1 / printScale).toFixed(1)}`) + ' (A4 print)';
    titleLines.push({ x: scaleSlot.x, y: scaleSlot.y, text: scaleText, cls: 'title-line', fontSize: SMALL_FONT, anchor: 'start' });
    for (const t of titleLines) t.box = labelBox(t.x, t.y, t.text, t.fontSize, t.anchor);

    return {
      fontSize: fs,
      viewBox,
      dims,
      titleBlock: { rect: tb, lines: titleLines, scaleText },
      outline,
      centerline: seg(-4, 0, xEnd + 4, 0, 'center'),
      printScale,
      printWidthMm,
    };
  }

  function unitVec(x, y) {
    const l = Math.hypot(x, y) || 1;
    return { x: x / l, y: y / l };
  }

  return { buildLayout, boxHitsSegment, boxesOverlap, labelBox, textWidth, FONT, PRINT_WIDTH_MM, PRINT_MAX_HEIGHT_MM };
});
