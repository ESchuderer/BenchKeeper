(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./geometry.js'), require('./dimensions.js'));
  else (root.CIP = root.CIP || {}).drawing = factory(root.CIP.geometry, root.CIP.dimensions);
})(typeof self !== 'undefined' ? self : this, function (geometry, dimensions) {
  'use strict';

  const SVG_NS = 'http://www.w3.org/2000/svg';
  const HATCH_PITCH = 1.0; // mm between hatch lines

  const n = (v) => String(Math.round(v * 1000) / 1000);
  const el = (tag, attrs, children, text) => ({ tag, attrs: attrs || {}, children: children || [], text });

  /** Polyline path "M x y L x y ..." from {r, z} points; sign -1 = upper half (outside view), +1 = lower half (section). */
  function pathOf(points, sign, close) {
    return points.map((p, i) => `${i ? 'L' : 'M'}${n(p.z)} ${n(sign * p.r)}`).join('') + (close ? 'Z' : '');
  }

  /** Same as pathOf but skips the edges that lie on the axis (they are drawn by the centre line). */
  function outlinePath(points, sign) {
    let d = '';
    let pen = false;
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      const q = points[(i + 1) % points.length];
      const onAxis = Math.abs(p.r) < 1e-9 && Math.abs(q.r) < 1e-9;
      if (onAxis) { pen = false; continue; }
      if (!pen) d += `M${n(p.z)} ${n(sign * p.r)}`;
      d += `L${n(q.z)} ${n(sign * q.r)}`;
      pen = true;
    }
    return d;
  }

  function hatchPath(section) {
    const zs = section.map((p) => p.z);
    const rs = section.map((p) => p.r);
    const z1 = Math.max(...zs);
    const rMax = Math.max(...rs) + 0.2;
    const step = HATCH_PITCH * Math.SQRT2;
    let d = '';
    for (let c = -rMax; c <= z1 + rMax; c += step) d += `M${n(c)} 0L${n(c - rMax)} ${n(rMax)}`;
    return d;
  }

  function arrowSpec(points) {
    return el('polygon', { class: 'arrow', points: points.map((p) => `${n(p.x)},${n(p.y)}`).join(' ') });
  }

  function textSpec(t, cls) {
    return el('text', { class: cls, x: n(t.x), y: n(t.y), 'font-size': n(t.fontSize), 'text-anchor': t.anchor }, [], t.text);
  }

  /** Pure description of the SVG; renderSpec turns it into DOM. */
  function svgSpec(record, c, layout) {
    if (c.unavailable) return null;
    const vb = layout.viewBox;
    const label = `${record.name} drawing`;
    const clipId = `section-${record.key}`;
    const L3 = record.cartridge.lengths.L3;
    const kids = [];
    kids.push(el('title', {}, [], label));
    kids.push(el('desc', {}, [], `Scale drawing of the ${record.name} cartridge, dimensions in mm: outside view above the axis, section below.`));

    if (c.section) kids.push(el('defs', {}, [el('clipPath', { id: clipId }, [el('path', { d: pathOf(c.section, 1, true) })])]));

    const part = [];
    // lower half: section (bullet first, case walls on top)
    const lower = [];
    if (c.bullet) lower.push(el('path', { class: 'fill-bullet outline-bullet', d: pathOf(c.bullet.seated, 1, true) }));
    if (c.section) {
      lower.push(el('path', { class: 'fill-case', d: pathOf(c.section, 1, true) }));
      lower.push(el('g', { 'clip-path': `url(#${clipId})` }, [el('path', { class: 'hatch', d: hatchPath(c.section) })]));
      lower.push(el('path', { class: 'outline', d: outlinePath(c.section, 1) }));
    } else {
      lower.push(el('path', { class: 'outline', d: pathOf(c.outer, 1, false) }));
    }
    part.push(el('g', { class: 'section-view' }, lower));

    // upper half: outside view
    const upper = [];
    const mouthR = c.bullet ? c.bullet.exposed[1].r : record.cartridge.collar.H2 / 2;
    const silhouette = [{ r: 0, z: 0 }, ...c.outer, { r: mouthR, z: L3 }, { r: 0, z: L3 }];
    upper.push(el('path', { class: 'fill-case', d: pathOf(silhouette, -1, true) }));
    if (c.bullet) upper.push(el('path', { class: 'fill-bullet outline-bullet', d: pathOf(c.bullet.exposed, -1, true) }));
    upper.push(el('path', { class: 'outline', d: pathOf([...c.outer, { r: mouthR, z: L3 }], -1, false) }));
    part.push(el('g', { class: 'outside-view' }, upper));

    kids.push(el('g', { class: 'part' }, part));
    const cl = layout.centerline;
    kids.push(el('line', { class: 'centerline', x1: n(cl.x1), y1: n(cl.y1), x2: n(cl.x2), y2: n(cl.y2) }));

    const dimKids = layout.dims.map((d) => {
      const g = [];
      for (const s of d.lines) g.push(el('line', { class: s.cls === 'ext' ? 'ext-line' : 'dim-line', x1: n(s.x1), y1: n(s.y1), x2: n(s.x2), y2: n(s.y2) }));
      if (d.arc) g.push(el('path', { class: 'dim-line', d: d.arc.map((p, i) => `${i ? 'L' : 'M'}${n(p.x)} ${n(p.y)}`).join('') }));
      for (const a of d.arrows) g.push(arrowSpec(a));
      g.push(textSpec(d.label, 'dim-label'));
      return el('g', { class: 'dim', 'data-dim': d.id }, g);
    });
    kids.push(el('g', { class: 'dimensions' }, dimKids));

    const tb = layout.titleBlock;
    kids.push(el('g', { class: 'title-block' }, [
      el('rect', { class: 'title-frame', x: n(tb.rect.x), y: n(tb.rect.y), width: n(tb.rect.w), height: n(tb.rect.h) }),
      ...tb.lines.map((t) => textSpec(t, t.cls)),
    ]));

    return el('svg', {
      xmlns: SVG_NS,
      class: 'cartridge-drawing',
      viewBox: `${n(vb.x)} ${n(vb.y)} ${n(vb.w)} ${n(vb.h)}`,
      role: 'img',
      'aria-label': label,
      'data-print-width-mm': n(layout.printWidthMm),
      style: `--print-width:${n(layout.printWidthMm)}mm`,
    }, kids);
  }

  function renderSpec(spec) {
    const node = document.createElementNS(SVG_NS, spec.tag);
    for (const [k, v] of Object.entries(spec.attrs)) node.setAttribute(k, v);
    for (const child of spec.children) node.append(renderSpec(child));
    if (spec.text !== undefined) node.textContent = spec.text;
    return node;
  }

  /** @returns {{svg: SVGElement, notes: string[]}} */
  function createDrawing(record) {
    const c = geometry.buildCase(record);
    if (c.unavailable) return { svg: null, notes: c.notes.map((x) => x.text), geometry: c, layout: null };
    const layout = dimensions.buildLayout(record, c);
    return { svg: renderSpec(svgSpec(record, c, layout)), notes: c.notes.map((x) => x.text), geometry: c, layout };
  }

  return { createDrawing, svgSpec, pathOf };
});
