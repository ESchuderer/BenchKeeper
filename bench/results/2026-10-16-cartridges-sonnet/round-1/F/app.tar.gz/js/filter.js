(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else (root.CIP = root.CIP || {}).filter = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const normalize = (s) => String(s).toLowerCase().replace(/\s+/g, '');

  function matchesQuery(record, query) {
    const q = normalize(query);
    if (!q) return true;
    return [record.name, ...(record.alternativeNames || [])].some((n) => normalize(n).includes(q));
  }

  /** @param {{query?: string, family?: string}} criteria family '' or undefined means all */
  function filterCartridges(records, criteria) {
    const { query = '', family = '' } = criteria || {};
    return records.filter((r) => (!family || r.family === family) && matchesQuery(r, query));
  }

  return { filterCartridges, matchesQuery, normalize };
});
