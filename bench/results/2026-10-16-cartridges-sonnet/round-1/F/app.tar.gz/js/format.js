(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else (root.CIP = root.CIP || {}).format = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };

  const ANGLE_FIELDS = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };

  /** Numbers print as published: decimal point, no thousands separator, no trailing zeros. */
  function formatNumber(n) {
    return String(n);
  }

  /** @param {number|{degrees:number,minutes:number,seconds:number}} a */
  function formatAngle(a) {
    if (typeof a === 'number') return `${a}°`;
    const { degrees, minutes, seconds } = a;
    if (!minutes && !seconds) return `${degrees}°`;
    return `${degrees}°${minutes}'${seconds}"`;
  }

  function angleToDegrees(a) {
    if (typeof a === 'number') return a;
    return a.degrees + a.minutes / 60 + a.seconds / 3600;
  }

  const symbolFor = (field) => SYMBOLS[field] || field;
  const isAngleField = (field) => ANGLE_FIELDS.includes(field);
  const unitFor = (field) => {
    if (isAngleField(field)) return 'deg';
    return field in UNITS ? UNITS[field] : 'mm';
  };

  /** @returns {{value: string, tol: string}} tol is '' when the field has no tolerance */
  function formatValue(field, value, tol) {
    const text = isAngleField(field) ? formatAngle(value) : formatNumber(value);
    let tolText = '';
    if (tol !== undefined && tol !== null) tolText = (tol > 0 ? '+' : '') + formatNumber(tol);
    return { value: text, tol: tolText };
  }

  return { formatNumber, formatAngle, angleToDegrees, symbolFor, isAngleField, unitFor, formatValue };
});
