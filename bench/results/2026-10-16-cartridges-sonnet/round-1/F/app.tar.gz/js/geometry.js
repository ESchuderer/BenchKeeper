(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'));
  else (root.CIP = root.CIP || {}).geometry = factory(root.CIP.format);
})(typeof self !== 'undefined' ? self : this, function (format) {
  'use strict';

  // Points are { r, z }: r = radius from the axis, z = distance from the head face towards the mouth.
  const DEG = Math.PI / 180;
  const ARC_STEP = 2 * DEG;
  const has = (v) => typeof v === 'number' && Number.isFinite(v);
  const deg = (a) => format.angleToDegrees(a) * DEG;
  const pt = (r, z) => ({ r, z });

  const POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 },
    spm: { diameter: 4.45, depth: 3.04 },
    sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 },
    lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 },
    lrm: { diameter: 5.33, depth: 3.3 },
  };

  /** Rule 1. */
  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    const ratio = record.cartridge.caseHead.R1 / record.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  /** Points on a circle/ellipse arc: centre c, semi-axes a (r) and b (z), angle t from t0 to t1 (radians). */
  function arcPoints(c, a, b, t0, t1, step) {
    const n = Math.max(2, Math.ceil(Math.abs(t1 - t0) / (step || ARC_STEP)) + 1);
    const out = [];
    for (let i = 0; i < n; i++) {
      const t = t0 + ((t1 - t0) * i) / (n - 1);
      out.push(pt(c.r + a * Math.cos(t), c.z + b * Math.sin(t)));
    }
    return out;
  }

  const sub = (a, b) => pt(a.r - b.r, a.z - b.z);
  const len = (v) => Math.hypot(v.r, v.z);
  const unit = (v) => pt(v.r / len(v), v.z / len(v));

  /** Tangent length of a fillet of `radius` at a corner that turns by `turn` radians. */
  const tangentLength = (radius, turn) => radius * Math.tan(turn / 2);
  const turnAngle = (d1, d2) => Math.acos(Math.max(-1, Math.min(1, d1.r * d2.r + d1.z * d2.z)));

  /** Fillet of `radius` at corner c between segments a-c and c-b. Returns tangent points, centre and arc samples. */
  function fillet(a, c, b, radius) {
    const d1 = unit(sub(c, a));
    const d2 = unit(sub(b, c));
    const turn = turnAngle(d1, d2);
    const t = tangentLength(radius, turn);
    const p1 = pt(c.r - d1.r * t, c.z - d1.z * t);
    const p2 = pt(c.r + d2.r * t, c.z + d2.z * t);
    const left = d1.r * d2.z - d1.z * d2.r > 0;
    const n = left ? pt(-d1.z, d1.r) : pt(d1.z, -d1.r);
    const center = pt(p1.r + n.r * radius, p1.z + n.z * radius);
    const a0 = Math.atan2(p1.z - center.z, p1.r - center.r);
    const sweep = left ? turn : -turn;
    return { radius, center, p1, p2, turn, arc: arcPoints(center, radius, radius, a0, a0 + sweep) };
  }

  function dedupe(points) {
    const out = [];
    for (const p of points) {
      const q = out[out.length - 1];
      if (!q || Math.abs(q.r - p.r) > 1e-12 || Math.abs(q.z - p.z) > 1e-12) out.push(p);
    }
    return out;
  }

  /** Rules 2 and 3: head face, rim edge, extractor groove or belt. Returns points from (0, 0) to the body start. */
  function headAndGroove(rec, type, notes) {
    const ch = rec.cartridge.caseHead;
    const P1 = rec.cartridge.powderChamber.P1;
    const { R1, R, E, E1, eMin, delta, R3, beta, f } = ch;
    const rim = R1 / 2;
    const body = P1 / 2;
    const pts = [pt(0, 0)];
    const info = { beltRampEndZ: null, grooveFloor: null, bodyStartZ: R, groove: false };

    const chamfer = has(beta) && has(f) && deg(beta) < 90 * DEG;
    const rho = type === 'rimfire' ? Math.min(R / 2, (R1 - P1) / 2) : 0;
    if (chamfer) {
      pts.push(pt(rim - Math.min(f * Math.tan(deg(beta)), R1 / 4), 0), pt(rim, f), pt(rim, R));
    } else if (type === 'rimfire' && rho > 0) {
      pts.push(pt(rim - rho, 0), ...arcPoints(pt(rim - rho, rho), rho, rho, -Math.PI / 2, Math.PI / 2));
      if (2 * rho < R - 1e-9) pts.push(pt(rim - rho, R));
    } else {
      pts.push(pt(rim, 0), pt(rim, R));
      if (type !== 'rimfire') {
        const missing = [has(beta) ? null : 'beta', has(f) ? null : 'f'].filter(Boolean);
        if (missing.length) notes.push({ missing, text: `Head chamfer not drawn: ${missing.map(format.symbolFor).join(', ')} not published` });
      }
    }

    if (has(E) && has(E1) && has(eMin)) {
      info.groove = true;
      info.bodyStartZ = E;
      info.grooveFloor = [pt(E1 / 2, R), pt(E1 / 2, R + eMin)];
      pts.push(pt(E1 / 2, R), pt(E1 / 2, R + eMin));
      const floorEnd = R + eMin;
      let belt = false;
      if (type === 'belted') {
        const missing = [has(R3) ? null : 'R3', has(delta) ? null : 'delta'].filter(Boolean);
        if (missing.length) {
          notes.push({ missing, text: `Belt not drawn: ${missing.map(format.symbolFor).join(', ')} not published` });
        } else {
          const zr = floorEnd + (R3 / 2 - E1 / 2) / Math.tan(deg(delta));
          if (R3 > E1 && zr < E) {
            belt = true;
            info.beltRampEndZ = zr;
            pts.push(pt(R3 / 2, zr), pt(R3 / 2, E), pt(body, E));
          }
        }
      }
      if (!belt) pts.push(pt(body, E));
    } else {
      pts.push(pt(body, R));
      if (type !== 'rimmed' && type !== 'rimfire') {
        const missing = ['E', 'E1', 'eMin'].filter((k) => !has(ch[k]));
        notes.push({ missing, text: `Extractor groove not drawn: ${missing.map(format.symbolFor).join(', ')} not published` });
      }
    }
    return { pts, info };
  }

  /** Rules 4 to 6: body, shoulder with fillets, neck, up to the mouth. `start` is the body start. */
  function bodyShoulderNeck(rec, start, notes) {
    const { P2, H1, H2 } = Object.assign({}, rec.cartridge.powderChamber, rec.cartridge.collar);
    const { alpha, r1Min, r2 } = rec.cartridge.junctionCone || {};
    const { L1, L2, L3 } = rec.cartridge.lengths;
    const out = { pts: [], fillets: [], bottleneck: false, anchors: {} };
    const mouth = pt(H2 / 2, L3);

    const hasAngle = (x) => has(x) || (x && typeof x === 'object' && has(x.degrees));
    const checks = { alpha: hasAngle(alpha), L1: has(L1), L2: has(L2), P2: has(P2), H1: has(H1) };
    const missing = Object.keys(checks).filter((k) => !checks[k]);
    if (missing.length) {
      if (missing.length < Object.keys(checks).length) {
        notes.push({ missing, text: `Shoulder not drawn: ${missing.map(format.symbolFor).join(', ')} not published (drawn as a straight case)` });
      }
      out.pts.push(mouth);
      return out;
    }

    out.bottleneck = true;
    const c1 = pt(P2 / 2, L1);
    const c2 = pt(H1 / 2, L2);
    out.anchors = { shoulderStart: c1, shoulderEnd: c2 };

    let k1 = has(r1Min) ? r1Min : 0;
    let k2 = has(r2) ? r2 : 0;
    if (!has(r1Min)) notes.push({ missing: ['r1Min'], text: 'Shoulder corner at the body not rounded: r1 min not published' });
    if (!has(r2)) notes.push({ missing: ['r2'], text: 'Shoulder corner at the neck not rounded: r2 not published' });

    const dBody = unit(sub(c1, start));
    const dShoulder = unit(sub(c2, c1));
    const dNeck = unit(sub(mouth, c2));
    const t1 = tangentLength(k1, turnAngle(dBody, dShoulder));
    const t2 = tangentLength(k2, turnAngle(dShoulder, dNeck));
    const scale = Math.min(1, len(sub(c2, c1)) / (t1 + t2 || 1), len(sub(c1, start)) / (t1 || 1), len(sub(mouth, c2)) / (t2 || 1));
    if (scale < 1) {
      k1 *= scale * 0.999;
      k2 *= scale * 0.999;
      notes.push({ missing: [], text: 'Shoulder fillets reduced to fit the shoulder length' });
    }
    if (k1 > 0) {
      const f1 = fillet(start, c1, c2, k1);
      out.fillets.push(f1);
      out.pts.push(...f1.arc);
    } else {
      out.pts.push(c1);
    }
    if (k2 > 0) {
      const f2 = fillet(c1, c2, mouth, k2);
      out.fillets.push(f2);
      out.pts.push(...f2.arc);
    } else {
      out.pts.push(c2);
    }
    out.pts.push(mouth);
    return out;
  }

  /** Rule 8: wall thicknesses. */
  function walls(rec, heeled) {
    const { H2 } = rec.cartridge.collar;
    const { G1 } = rec.cartridge.projectile;
    const P1 = rec.cartridge.powderChamber.P1;
    const tnRaw = (H2 - G1) / 2;
    const tb = Math.min(Math.max(1.3 * tnRaw, 0.6), (0.35 * P1) / 2);
    return { tn: heeled ? tb : tnRaw, tb };
  }

  /** Radius of a z-monotone polyline at z (first match). */
  function radiusAt(poly, z) {
    for (let i = 1; i < poly.length; i++) {
      const a = poly[i - 1];
      const b = poly[i];
      if (z >= a.z - 1e-12 && z <= b.z + 1e-12) {
        if (b.z - a.z < 1e-12) return a.r;
        return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
      }
    }
    return poly[poly.length - 1].r;
  }

  /** Rule 7: bullet. */
  function buildBullet(rec, ctx, notes) {
    const { G1 } = rec.cartridge.projectile;
    const { L6, L3 } = rec.cartridge.lengths;
    const shape = rec.annotations.defaultBulletShape;
    const pistol = rec.annotations.category === 'pistol';
    const missing = [has(G1) ? null : 'G1', has(L6) ? null : 'L6'].filter(Boolean);
    const params = {
      pointy: { s: 1.0, k: 0.4 },
      rounded: { s: pistol ? 0.4 : 0.8, k: pistol ? 0.65 : 0.55 },
      flat: { s: pistol ? 0.4 : 0.8, k: pistol ? 0.7 : 0.6 },
      semi_wadcutter: { s: 0.6, k: 0.78 },
    }[shape];
    if (!params) missing.push('defaultBulletShape');
    if (missing.length) {
      notes.push({ missing, text: `Bullet not drawn: ${missing.map(format.symbolFor).join(', ')} not published` });
      return null;
    }

    const radius = ctx.heeled ? rec.cartridge.collar.H2 / 2 : G1 / 2; // exposed radius
    const D = radius * 2;
    const s = params.s * G1;
    const zb = L3 - s;
    const Lb = L6 - zb;
    const zc = zb + params.k * Lb;
    const n = L6 - zc;
    const m = { pointy: Math.max(0.08 * D, 1.27), rounded: 0.15 * D, flat: 0.55 * D, semi_wadcutter: 0.6 * D }[shape];
    const ra = radius - m / 2;
    let nose;
    let rho = null;
    if (shape === 'pointy') {
      rho = (ra * ra + n * n) / (2 * ra);
      const c = pt(radius - rho, zc);
      const end = Math.atan2(n, m / 2 - c.r);
      nose = arcPoints(c, rho, rho, 0, end);
      nose[nose.length - 1] = pt(m / 2, L6);
    } else if (shape === 'rounded') {
      nose = arcPoints(pt(m / 2, zc), ra, n, 0, Math.PI / 2);
      nose[nose.length - 1] = pt(m / 2, L6);
    } else {
      nose = [pt(radius, zc), pt(m / 2, L6)];
    }
    nose[0] = pt(radius, zc);

    const heelRadius = ctx.heeled ? (rec.cartridge.collar.H2 - 2 * ctx.tb) / 2 : radius;
    const seated = [pt(0, zb), pt(heelRadius, zb)];
    if (ctx.heeled) seated.push(pt(heelRadius, L3), pt(radius, L3));
    seated.push(...nose, pt(0, L6));

    // Exposed part: everything at or above the mouth.
    const exposed = [pt(0, L3), pt(zc > L3 ? radius : radiusAt(nose, L3), L3)];
    if (zc > L3) exposed.push(...nose);
    else exposed.push(...nose.filter((p) => p.z > L3));
    exposed.push(pt(0, L6));

    return { shape, s, zb, zc, k: params.k, m, rho, L6, radius, heelRadius, nose, seated, exposed };
  }

  /** Rule 8: solid head length, inner line and the hatched section polygon. */
  function buildSection(rec, ctx, outer, notes) {
    const { L3 } = rec.cartridge.lengths;
    const { H2 } = rec.cartridge.collar;
    const P1 = rec.cartridge.powderChamber.P1;
    const { tn, tb } = ctx;
    const primer = rec.annotations.primerType;
    let pocket = null;
    if (primer === 'rimfire' || ctx.rimType === 'rimfire') pocket = null;
    else if (POCKETS[primer]) pocket = Object.assign({}, POCKETS[primer]);
    else notes.push({ missing: ['primerType'], text: 'Primer pocket not drawn: primer type not published' });

    const candidates = [2.5, (0.25 * P1) / 2];
    if (pocket) candidates.push(pocket.depth + 1.5);
    if (ctx.groove) candidates.push(rec.cartridge.caseHead.E + tb);
    if (ctx.beltRampEndZ !== null) candidates.push(ctx.beltRampEndZ + tb);
    const w = Math.max(...candidates);

    // wall thickness as a function of z
    const { L1, L2 } = rec.cartridge.lengths;
    let wallAt;
    let breaks;
    if (ctx.bottleneck) {
      wallAt = (z) => (z <= L1 ? tb : z >= L2 ? tn : tb + ((tn - tb) * (z - L1)) / (L2 - L1));
      breaks = [L1, L2];
    } else {
      const zb = ctx.bullet ? ctx.bullet.zb : L3;
      wallAt = (z) => (z >= zb ? tn : z <= w ? tb : tb + ((tn - tb) * (z - w)) / (zb - w));
      breaks = [zb];
    }
    const zs = new Set([w, L3]);
    for (const z of breaks) if (z > w && z < L3) zs.add(z);
    for (const p of outer) if (p.z > w && p.z < L3) zs.add(p.z);
    const inner = [...zs].sort((a, b) => a - b).map((z) => pt(radiusAt(outer, z) - wallAt(z), z));
    inner[inner.length - 1] = pt(H2 / 2 - tn, L3);

    const pr = pocket ? pocket.diameter / 2 : 0;
    const section = [];
    section.push(pocket ? pt(pr, 0) : pt(0, 0));
    for (const p of outer) if (!(p.z === 0 && p.r <= pr)) section.push(p);
    section.push(pt(H2 / 2 - tn, L3), ...inner.slice().reverse().slice(1), pt(0, w));
    if (pocket) section.push(pt(0, pocket.depth), pt(pr, pocket.depth));
    return { w, pocket, inner, section: dedupe(section) };
  }

  /** Values without which no outline can be drawn: [section, field]. */
  const ESSENTIAL = [['caseHead', 'R'], ['caseHead', 'R1'], ['powderChamber', 'P1'], ['collar', 'H2'], ['lengths', 'L3']];

  function missingEssentials(record) {
    return ESSENTIAL.filter(([sec, f]) => !has(((record.cartridge || {})[sec] || {})[f])).map(([, f]) => f);
  }

  /** Builds everything the drawing needs from one record. All lengths in mm. */
  function buildCase(record) {
    const missing = missingEssentials(record);
    if (missing.length) {
      const text = `Drawing not available: ${missing.map(format.symbolFor).join(', ')} not published`;
      return { key: record.key, name: record.name, unavailable: true, notes: [{ missing, text }] };
    }
    const notes = [];
    const type = rimType(record);
    const head = headAndGroove(record, type, notes);
    const start = head.pts[head.pts.length - 1];
    const upper = bodyShoulderNeck(record, start, notes);
    const outer = dedupe([...head.pts, ...upper.pts]);

    const { H2 } = record.cartridge.collar;
    const { G1 } = record.cartridge.projectile;
    const heeled = has(G1) && H2 - G1 <= 0.015;
    const { tn, tb } = has(G1) ? walls(record, heeled) : { tn: NaN, tb: NaN };
    const ctx = { rimType: type, heeled, tn, tb, bottleneck: upper.bottleneck, groove: head.info.groove, beltRampEndZ: head.info.beltRampEndZ, bullet: null };
    if (!has(G1)) {
      // walls need G1: the bullet and the section are left out
      notes.push({ missing: ['G1'], text: 'Bullet and section walls not drawn: G1 not published' });
      return { key: record.key, name: record.name, rimType: type, bottleneck: upper.bottleneck, heeled, outer, fillets: upper.fillets, notes, tn, tb, w: null, pocket: null, inner: null, section: null, bullet: null, beltRampEndZ: head.info.beltRampEndZ, anchors: anchorsFor(record, head.info, upper) };
    }
    ctx.bullet = buildBullet(record, ctx, notes);
    const sec = buildSection(record, ctx, outer, notes);

    return {
      key: record.key,
      name: record.name,
      rimType: type,
      bottleneck: upper.bottleneck,
      heeled,
      outer,
      fillets: upper.fillets,
      tn,
      tb,
      w: sec.w,
      pocket: sec.pocket,
      inner: sec.inner,
      section: sec.section,
      bullet: ctx.bullet,
      beltRampEndZ: head.info.beltRampEndZ,
      anchors: anchorsFor(record, head.info, upper),
      notes,
    };
  }

  function anchorsFor(record, headInfo, upper) {
    const ch = record.cartridge.caseHead;
    return {
      bodyStartZ: headInfo.bodyStartZ,
      groove: headInfo.groove,
      grooveFloor: headInfo.grooveFloor,
      shoulderStart: upper.anchors.shoulderStart || null,
      shoulderEnd: upper.anchors.shoulderEnd || null,
      rimThickness: ch.R,
    };
  }

  return { rimType, buildCase, fillet, radiusAt, POCKETS };
});
