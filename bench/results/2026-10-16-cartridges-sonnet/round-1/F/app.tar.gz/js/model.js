(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'));
  else (root.CIP = root.CIP || {}).model = factory(root.CIP.format);
})(typeof self !== 'undefined' ? self : this, function (format) {
  'use strict';

  const TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling',
  };

  const titleFor = (id) => TITLES[id] || id.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase());

  /** Sections of one part ("cartridge" or "chamber"); a <X>Tol field is merged into X's row. */
  function buildSections(part) {
    const sections = [];
    for (const [id, fields] of Object.entries(part || {})) {
      const rows = [];
      for (const [field, value] of Object.entries(fields)) {
        if (field.endsWith('Tol') && field.slice(0, -3) in fields) continue;
        const { value: text, tol } = format.formatValue(field, value, fields[field + 'Tol']);
        rows.push({ field, symbol: format.symbolFor(field), value: text, tol, unit: format.unitFor(field) });
      }
      if (rows.length) sections.push({ id, title: titleFor(id), rows });
    }
    return sections;
  }

  function buildTables(record) {
    return { cartridge: buildSections(record.cartridge), chamber: buildSections(record.chamber) };
  }

  /** Descriptive rows shown above the drawing. */
  function buildMeta(record) {
    const a = record.annotations || {};
    const alt = record.alternativeNames;
    const cap = a.publishedCapacity;
    const waterCapacity = cap
      ? { key: 'waterCapacity', label: 'Water capacity', text: `${format.formatNumber(cap.grH2O)} gr H2O`, note: cap.note, link: { text: cap.source, href: cap.url } }
      : { key: 'waterCapacity', label: 'Water capacity', text: 'not published' };
    const rows = [
      { key: 'alternativeNames', label: 'Alternative names', text: alt && alt.length ? alt.join(', ') : 'none' },
      { key: 'family', label: 'Family', text: record.family },
      { key: 'category', label: 'Category', text: a.category },
      { key: 'primerType', label: 'Primer type', text: a.primerType },
      { key: 'tab', label: 'C.I.P. table', text: record.tab },
      { key: 'country', label: 'Country', text: record.country },
      { key: 'published', label: 'Published', text: record.published },
      { key: 'revised', label: 'Revised', text: record.revised },
      { key: 'pressureMethod', label: 'Pressure method', text: record.pressureMethod },
      waterCapacity,
    ];
    return rows;
  }

  return { buildTables, buildMeta, titleFor };
});
