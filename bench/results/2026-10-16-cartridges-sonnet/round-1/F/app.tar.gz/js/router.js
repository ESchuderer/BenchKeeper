(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else (root.CIP = root.CIP || {}).router = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const LIST_HREF = '#/';
  const detailHref = (key) => `#/cartridge/${encodeURIComponent(key)}`;

  /** @returns {{view:'list'}|{view:'detail',key:string}|{view:'notfound'}} */
  function parseHash(hash) {
    const h = hash || '';
    if (h === '' || h === '#' || h === '#/') return { view: 'list' };
    const m = /^#\/cartridge\/(.+)$/.exec(h);
    if (m) {
      try {
        return { view: 'detail', key: decodeURIComponent(m[1]) };
      } catch (e) {
        return { view: 'notfound' };
      }
    }
    return { view: 'notfound' };
  }

  return { LIST_HREF, detailHref, parseHash };
});
