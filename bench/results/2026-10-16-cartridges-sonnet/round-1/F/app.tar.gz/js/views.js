(function (root, factory) {
  const CIP = (root.CIP = root.CIP || {});
  CIP.views = factory(CIP);
})(typeof self !== 'undefined' ? self : this, function (CIP) {
  'use strict';

  const FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  /** Element helper; all strings are inserted as text, never as HTML. */
  function h(tag, attrs, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat(Infinity)) {
      if (c === undefined || c === null || c === false) continue;
      el.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return el;
  }

  function renderList(data) {
    const search = h('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false' });
    const family = h('select', { id: 'family' }, h('option', { value: '' }, 'All'), FAMILIES.map((f) => h('option', { value: f }, f)));
    const count = h('p', { class: 'count', role: 'status', 'aria-live': 'polite' });
    const tbody = h('tbody');
    const empty = h('p', { class: 'empty', hidden: true }, 'No cartridge matches the search.');

    function update() {
      const rows = CIP.filter.filterCartridges(data, { query: search.value, family: family.value });
      tbody.replaceChildren(
        ...rows.map((r) =>
          h('tr', null,
            h('th', { scope: 'row' }, h('a', { href: CIP.router.detailHref(r.key) }, r.name)),
            h('td', null, r.family),
            h('td', { class: 'num' }, `${CIP.format.formatNumber(r.cartridge.lengths.L3)} mm`))
        )
      );
      count.textContent = `${rows.length} cartridges`;
      empty.hidden = rows.length > 0;
    }
    search.addEventListener('input', update);
    family.addEventListener('change', update);
    update();

    return h('section', { class: 'list-view' },
      h('h1', { tabindex: '-1' }, 'Cartridges'),
      h('form', { class: 'filters', role: 'search', onsubmit: (e) => e.preventDefault() },
        h('label', { for: 'search' }, 'Search'), search,
        h('label', { for: 'family' }, 'Family'), family,
        count),
      h('table', { class: 'cartridge-list' },
        h('thead', null, h('tr', null, h('th', { scope: 'col' }, 'Name'), h('th', { scope: 'col' }, 'Family'), h('th', { scope: 'col', class: 'num' }, 'Case length L3'))),
        tbody),
      empty);
  }

  function metaItem(row) {
    const dd = h('dd', null, row.text);
    if (row.link) {
      dd.append(' (source: ', h('a', { href: row.link.href, target: '_blank', rel: 'noopener noreferrer' }, row.link.text), ')');
    }
    if (row.note) dd.append(h('span', { class: 'note' }, row.note));
    return h('div', null, h('dt', null, row.label), dd);
  }

  function valueCell(row) {
    const td = h('td', { class: 'num' }, row.value);
    if (row.tol) td.append(' ', h('span', { class: 'tol' }, row.tol));
    return td;
  }

  function sectionTable(section) {
    return h('section', { class: 'value-section' },
      h('h3', null, section.title),
      h('table', { class: 'values' },
        h('thead', null, h('tr', null, h('th', { scope: 'col' }, 'Symbol'), h('th', { scope: 'col', class: 'num' }, 'Value'), h('th', { scope: 'col' }, 'Unit'))),
        h('tbody', null, section.rows.map((r) => h('tr', null, h('th', { scope: 'row' }, r.symbol), valueCell(r), h('td', { class: 'unit' }, r.unit))))));
  }

  function renderDetail(record) {
    const tables = CIP.model.buildTables(record);
    const drawing = CIP.drawing ? CIP.drawing.createDrawing(record) : null;
    const notes = drawing && drawing.notes.length ? h('ul', { class: 'drawing-notes' }, drawing.notes.map((n) => h('li', null, n))) : null;

    return h('article', { class: 'detail-view' },
      h('nav', { class: 'toolbar' },
        h('a', { href: CIP.router.LIST_HREF, class: 'back' }, 'All cartridges'),
        h('button', { type: 'button', class: 'print-button', onclick: () => window.print() }, 'Print')),
      h('header', { class: 'detail-header' }, h('h1', { tabindex: '-1' }, record.name)),
      h('dl', { class: 'meta' }, CIP.model.buildMeta(record).map(metaItem)),
      drawing ? h('figure', { class: 'drawing' }, drawing.svg, notes) : null,
      h('section', { class: 'tables' },
        h('h2', null, 'Cartridge'),
        h('div', { class: 'section-grid' }, tables.cartridge.map(sectionTable)),
        h('h2', null, 'Chamber'),
        h('div', { class: 'section-grid' }, tables.chamber.map(sectionTable))),
      h('footer', { class: 'source' }, `Source: C.I.P. TDCC, revised ${record.revised}`));
  }

  function renderNotFound() {
    return h('section', { class: 'not-found' },
      h('h1', { tabindex: '-1' }, 'Cartridge not found'),
      h('p', null, 'There is no cartridge at this address. ', h('a', { href: CIP.router.LIST_HREF }, 'All cartridges')));
  }

  return { renderList, renderDetail, renderNotFound, h };
});
