const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir: 'tests/e2e',
  timeout: 30000,
  fullyParallel: true,
  reporter: 'list',
  use: { browserName: 'chromium' },
  webServer: {
    command: 'node scripts/serve.mjs 8123',
    url: 'http://localhost:8123/',
    reuseExistingServer: true,
  },
});
