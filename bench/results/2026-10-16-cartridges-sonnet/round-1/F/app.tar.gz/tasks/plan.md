# Implementation Plan: C.I.P. Cartridge Reference

Spec: `../SPEC.md` (decisions D1–D14 accepted by the user's "continue, do not wait for approval").
Tasks are tracked in `tasks/todo.md`.

## Overview
Static app: list view + detail view with computed SVG drawing, tables, print. Plain classic scripts on `file://`. Pure logic modules are tested in Node (`node:test`); the browser behaviour is tested with Playwright/Chromium (installed as a dev dependency; Chromium 156 headless shell present).

## Dependency graph
```
data (jsonl → cartridges.js)
  ├── format ── model ──────────────┐
  ├── filter ── router ── list view │
  └── geometry ── dimensions ── drawing ── detail view ── print css
```
Geometry has no dependency on format/DOM, so it is built and tested in isolation first (highest risk, fail fast). It is still sliced vertically: each geometry task ends with the feature visible in the browser.

## Architecture decisions
- Classic scripts + UMD wrapper, namespace `CIP`, so the same files run in Node and on `file://`.
- Points are `{r, z}`. The SVG maps `x = z`, `y = ∓r` (upper half outside view, lower half section), 1 unit = 1 mm.
- Geometry returns data (profiles, arcs, polygons, notes, dimension anchors); `drawing.js` only turns data into SVG; `dimensions.js` places labels and exposes bounding boxes so overlap is testable without a browser.
- Text boxes are estimated in Node (char width 0.6 × font size) and re-checked in Chromium with `getBBox`.
- Dev server for e2e is a 20-line Node static server (no dependency).

## Tasks (vertical slices, see todo.md for acceptance criteria)
Phase 1 Foundation: T1 scaffold + data · T2 format + model
Checkpoint A
Phase 2 List: T3 list view with search/family filter, routing
Checkpoint B
Phase 3 Detail data: T4 detail view metadata + tables
Phase 4 Drawing: T5 outer profile (rim, head, groove, belt, body, shoulder, neck, fillets) · T6 section walls, pocket, hatch · T7 bullet (+ heeled) · T8 dimensions, labels, title block, notes
Checkpoint C (visual review of all 25)
Phase 5 Print and polish: T9 print layout one A4 page · T10 look & feel (dark, phone, a11y)
Phase 6 Verify: T11 full e2e sweep, code review, fixes

## Risks
| Risk | Impact | Mitigation |
|---|---|---|
| Label placement overlaps for some of the 25 | High | Layout is a pure function with a box-overlap test over all 25, built in T8 with iteration on PNG renders |
| One-page print overflows for cartridges with many rows | Med | Two-column tables, small type; PDF page-count test for all 25 |
| Fillets/walls self-intersect on odd records | Med | Invariant tests over all 25 in T5–T7 |
| Chromium unable to run in container | High | Smoke-test launch at T1 |
| Typos when transcribing 25 records | High | Data tests on counts/keys/sample values; build script reads JSONL, the JS file is generated, not typed twice |
