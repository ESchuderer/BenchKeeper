# Task list

Legend: size S/M. Every task: tests first, full unit suite green before ticking.

## Phase 1 — Foundation
- [x] T1 Scaffold + data (S). Files: package.json, playwright.config.js, scripts/build-data.mjs, scripts/serve.mjs, data/cartridges.jsonl, data/cartridges.js, tests/unit/data.test.js
  - Acceptance: 25 records; `cartridges.js` deep-equals JSONL; unique keys; Chromium launches a blank page on file://
  - Verify: `npm run test:unit`
- [x] T2 format + model (M). Files: js/format.js, js/model.js, tests/unit/format.test.js, model.test.js
  - Acceptance: numbers as published; angles `40°` / `39°59'49"`; `39.62 -0.2` tolerance; symbols map; units; no Tol rows; empty sections omitted; metadata (alt names, capacity)
  - Verify: unit tests
### [x] Checkpoint A — unit suite green, data verified

## Phase 2 — List
- [x] T3 List view (M). Files: js/filter.js, js/router.js, js/views.js, js/app.js, index.html, css/app.css, tests/unit/filter.test.js, router.test.js, tests/e2e/list.spec.js
  - Acceptance: S2, S3; opens from file://; link text == name; n cartridges
  - Verify: unit + e2e list spec (file:// and http)
### [x] Checkpoint B — list works from disk

## Phase 3 — Detail
- [x] T4 Detail view metadata + tables + routing/reload (M). Files: js/views.js, css, tests/e2e/detail.spec.js
  - Acceptance: S4, S5; Print button, All cartridges link; not-found view
  - Verify: e2e

## Phase 4 — Drawing
- [x] T5 Outer profile (M). Files: js/geometry.js, js/drawing.js, tests/unit/geometry.test.js
  - Acceptance: rules 1–6 (+9 notes); monotone, finite profiles for all 25; fillets clamp; upper half rendered in detail view with accessible name
  - Verify: unit + PNG review
- [x] T6 Section: walls, pocket, solid head, hatch (M). Files: js/geometry.js, js/drawing.js, tests
  - Acceptance: rule 8, D2, D3; w values; pocket sizes; hatched polygons; inner line inside outer
  - Verify: unit + PNG review
- [x] T7 Bullet (M). Files: js/geometry.js, js/drawing.js, tests
  - Acceptance: rule 7: seating, k, ogive formula, ellipse, cones, meplat; heeled; outside view hides seated part; section shows it
  - Verify: unit + PNG review
- [x] T8 Dimensions, labels, title block, notes (M). Files: js/dimensions.js, js/drawing.js, tests/unit/dimensions.test.js
  - Acceptance: L3 L6 R1 R P1 always; P2 H1 H2 G1 L1 L2 E1 α where published; arrowheads, extension lines; labels `L3 51.18`; no overlaps for all 25; title block name, tab, revised, "Dimensions in mm", scale; missing-value notes
  - Verify: unit + e2e bbox + PNG review
### [x] Checkpoint C — all 25 drawings reviewed visually

## Phase 5 — Print and polish
- [x] T9 Print (M). Files: css/print.css, js/views.js, tests/e2e/print.spec.js
  - Acceptance: S9 for all 25 (PDF = 1 page)
  - Verify: e2e print
- [x] T10 Look & feel (S). Files: css/app.css
  - Acceptance: dark/light, 360 px without horizontal scroll, tabular numbers, focus styles, contrast
  - Verify: e2e + screenshots

## Phase 6 — Verify
- [x] T11 Full e2e sweep over 25 views, request log, console errors, review (code-review skill), fixes
### [x] Checkpoint D — all S1–S11 met
