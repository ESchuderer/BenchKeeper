const { test, expect } = require('@playwright/test');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const fileUrl = pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;
const targets = { file: fileUrl, http: 'http://localhost:8123/' };

for (const [mode, url] of Object.entries(targets)) {
  test.describe(`detail view (${mode})`, () => {
    test('opens from the list, has its own address, survives reload', async ({ page }) => {
      await page.goto(url);
      await page.getByRole('link', { name: '308 Win.', exact: true }).click();
      await expect(page.getByRole('heading', { level: 1, name: '308 Win.' })).toBeVisible();
      expect(page.url()).toContain('#/cartridge/308_win');
      await page.reload();
      await expect(page.getByRole('heading', { level: 1, name: '308 Win.' })).toBeVisible();
      await page.goBack();
      await expect(page.getByRole('heading', { level: 1, name: 'Cartridges' })).toBeVisible();
    });

    test('direct address (bookmark) opens the view', async ({ page }) => {
      await page.goto(`${url}#/cartridge/6_5_creedmoor`);
      await expect(page.getByRole('heading', { level: 1, name: '6,5 Creedmoor' })).toBeVisible();
    });

    test('metadata, tables, print button and back link', async ({ page }) => {
      await page.goto(`${url}#/cartridge/308_win`);
      const meta = page.locator('dl.meta');
      await expect(meta).toContainText('308 Winchester, 7,62 x 51');
      await expect(meta).toContainText('rimless');
      await expect(meta).toContainText('rifle');
      await expect(meta).toContainText('lr');
      await expect(meta).toContainText('1984-06-14');
      await expect(meta).toContainText('2008-09-23');
      await expect(meta).toContainText('Transducer');
      await expect(meta).toContainText('56 gr H2O');
      await expect(meta.getByRole('link', { name: 'kwk' })).toHaveAttribute('href', 'http://kwk.us/cases.html');

      const lengths = page.locator('section.value-section', { hasText: 'Lengths' }).first();
      await expect(lengths.getByRole('columnheader')).toHaveText(['Symbol', 'Value', 'Unit']);
      const l2 = lengths.getByRole('row', { name: /^L2 / });
      await expect(l2).toHaveText(/L2\s*43\.48 -0\.2\s*mm/);
      await expect(lengths.getByRole('row')).toHaveCount(5); // header + L1 L2 L3 L6, no Tol rows
      await expect(page.getByRole('row', { name: /^Pmax 4150 bar/ }).first()).toBeVisible();
      await expect(page.getByRole('row', { name: /^α 40°/ }).first()).toBeVisible();
      await expect(page.getByRole('row', { name: /^i 1°45'0"/ })).toBeVisible();
      await expect(page.getByRole('heading', { name: 'Cartridge', level: 2 })).toBeVisible();
      await expect(page.getByRole('heading', { name: 'Chamber', level: 2 })).toBeVisible();
      await expect(page.getByRole('button', { name: 'Print' })).toBeVisible();
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await expect(page.getByRole('heading', { level: 1, name: 'Cartridges' })).toBeVisible();
    });

    test('unknown key shows a not-found message with a way back', async ({ page }) => {
      await page.goto(`${url}#/cartridge/nope`);
      await expect(page.getByRole('heading', { level: 1, name: 'Cartridge not found' })).toBeVisible();
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await expect(page.getByRole('heading', { level: 1, name: 'Cartridges' })).toBeVisible();
    });

    test('Print button opens the print dialog', async ({ page }) => {
      await page.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed += 1; }; });
      await page.goto(`${url}#/cartridge/308_win`);
      await page.getByRole('button', { name: 'Print' }).click();
      expect(await page.evaluate(() => window.__printed)).toBe(1);
    });

    test('record without water capacity says so', async ({ page }) => {
      await page.goto(`${url}#/cartridge/7_x_64`);
      await expect(page.locator('dl.meta')).toContainText('not published');
    });
  });
}
