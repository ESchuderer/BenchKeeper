const { test, expect } = require('@playwright/test');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const data = require('../../data/cartridges.js');

const fileUrl = pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;

test.describe('drawing in the browser', () => {
  for (const rec of data) {
    test(`${rec.key}: named svg, labels, no overlaps with each other or the outline`, async ({ page }) => {
      const errors = [];
      const requests = [];
      page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
      page.on('pageerror', (e) => errors.push(e.message));
      page.on('request', (r) => requests.push(r.url()));
      await page.goto(`${fileUrl}#/cartridge/${rec.key}`);
      await page.reload();
      await expect(page.getByRole('img', { name: `${rec.name} drawing` })).toBeVisible();

      const result = await page.evaluate(() => {
        const svg = document.querySelector('svg.cartridge-drawing');
        const texts = [...svg.querySelectorAll('text')].map((t) => {
          const b = t.getBBox();
          return { text: t.textContent, x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height };
        });
        const overlaps = [];
        for (let i = 0; i < texts.length; i++) {
          for (let j = i + 1; j < texts.length; j++) {
            const a = texts[i];
            const b = texts[j];
            if (a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1) overlaps.push(`${a.text} / ${b.text}`);
          }
        }
        // sample the outline and dimension geometry; no label box may contain a sample point
        const hits = [];
        const geoms = [...svg.querySelectorAll('path.outline, path.outline-bullet, line.dim-line, line.ext-line, line.centerline, path.dim-line')];
        for (const g of geoms) {
          const len = g.getTotalLength();
          for (let d = 0; d <= len; d += 0.2) {
            const p = g.getPointAtLength(d);
            for (const t of texts) {
              if (p.x > t.x0 && p.x < t.x1 && p.y > t.y0 && p.y < t.y1) hits.push(`${t.text} @ ${p.x.toFixed(1)},${p.y.toFixed(1)} (${g.getAttribute('class')})`);
            }
          }
        }
        const vb = svg.viewBox.baseVal;
        const outside = texts.filter((t) => t.x0 < vb.x || t.x1 > vb.x + vb.width || t.y0 < vb.y || t.y1 > vb.y + vb.height).map((t) => t.text);
        return { geomCount: geoms.length, labels: texts.map((t) => t.text), overlaps, hits: [...new Set(hits)].slice(0, 5), outside };
      });
      expect(result.geomCount).toBeGreaterThan(10);
      expect(result.overlaps).toEqual([]);
      expect(result.hits).toEqual([]);
      expect(result.outside).toEqual([]);
      for (const needle of ['L3 ', 'L6 ', 'R1 ', 'R ', 'P1 ']) expect(result.labels.some((l) => l.startsWith(needle))).toBe(true);
      expect(result.labels).toContain(`L3 ${rec.cartridge.lengths.L3}`);
      expect(result.labels).toContain('Dimensions in mm');
      expect(result.labels).toContain(rec.name);
      expect(errors).toEqual([]);
      expect(requests.filter((u) => !u.startsWith('file://'))).toEqual([]);
    });
  }

  test('drawing is true to scale: 1 user unit = 1 mm (L3 and L6 extents match the values)', async ({ page }) => {
    await page.goto(`${fileUrl}#/cartridge/308_win`);
    const ext = await page.evaluate(() => {
      const outline = document.querySelector('.outside-view path.outline');
      const box = outline.getBBox();
      const bullet = document.querySelector('.outside-view path.outline-bullet').getBBox();
      return { caseEnd: box.x + box.width, tip: bullet.x + bullet.width, head: box.x };
    });
    expect(ext.head).toBeCloseTo(0, 3);
    expect(ext.caseEnd).toBeCloseTo(51.18, 3);
    expect(ext.tip).toBeCloseTo(71.12, 3);
  });

  test('notes name the unpublished values (17 HMR)', async ({ page }) => {
    await page.goto(`${fileUrl}#/cartridge/17_hmr`);
    const notes = page.locator('.drawing-notes');
    await expect(notes).toContainText('r1 min not published');
    await expect(notes).toContainText('r2 not published');
  });
});

test.describe('look and feel', () => {
  test('phone width: no horizontal scroll, drawing scales to the screen', async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: 360, height: 740 }, isMobile: true, hasTouch: true });
    const page = await ctx.newPage();
    for (const hash of ['#/', '#/cartridge/338_lapua_mag', '#/cartridge/22_long_rifle']) {
      await page.goto(`${fileUrl}${hash}`);
      await page.reload();
      const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, svg: document.querySelector('svg.cartridge-drawing')?.getBoundingClientRect().width ?? null }));
      expect(m.sw).toBeLessThanOrEqual(m.cw);
      if (m.svg !== null) expect(m.svg).toBeLessThanOrEqual(360);
    }
    await ctx.close();
  });

  test('dark scheme follows the system; light is default', async ({ browser }) => {
    for (const scheme of ['light', 'dark']) {
      const ctx = await browser.newContext({ colorScheme: scheme });
      const page = await ctx.newPage();
      await page.goto(`${fileUrl}#/cartridge/308_win`);
      const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
      const lum = bg.match(/\d+/g).slice(0, 3).map(Number).reduce((a, b) => a + b, 0) / 3;
      if (scheme === 'dark') expect(lum).toBeLessThan(60);
      else expect(lum).toBeGreaterThan(200);
      await ctx.close();
    }
  });

  test('tabular numbers are on', async ({ page }) => {
    await page.goto(`${fileUrl}#/cartridge/308_win`);
    const v = await page.evaluate(() => getComputedStyle(document.querySelector('table.values td.num')).fontVariantNumeric);
    expect(v).toContain('tabular-nums');
  });

  test('all 25 detail views open without console errors', async ({ page }) => {
    const errors = [];
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto(`${fileUrl}#/`);
    const names = await page.locator('table.cartridge-list tbody th a').allTextContents();
    expect(names.length).toBe(25);
    for (const n of names) {
      await page.getByLabel('Search').fill('');
      await page.getByRole('link', { name: n, exact: true }).click();
      await expect(page.getByRole('heading', { level: 1, name: n, exact: true })).toBeVisible();
      await expect(page.getByRole('img', { name: `${n} drawing` })).toBeVisible();
      await page.getByRole('link', { name: 'All cartridges' }).click();
    }
    expect(errors).toEqual([]);
  });
});
