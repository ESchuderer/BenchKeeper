const { test, expect } = require('@playwright/test');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const fileUrl = pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;
const targets = { file: fileUrl, http: 'http://localhost:8123/' };

for (const [mode, url] of Object.entries(targets)) {
  test.describe(`list view (${mode})`, () => {
    test.beforeEach(async ({ page }) => {
      await page.goto(url);
    });

    test('shows heading, 25 cartridges with name links, family and L3', async ({ page }) => {
      await expect(page.getByRole('heading', { level: 1, name: 'Cartridges' })).toBeVisible();
      await expect(page.getByText('25 cartridges', { exact: true })).toBeVisible();
      const link = page.getByRole('link', { name: '308 Win.', exact: true });
      await expect(link).toBeVisible();
      const row = page.getByRole('row', { name: /308 Win\./ });
      await expect(row).toContainText('rimless');
      await expect(row).toContainText('51.18');
      await expect(page.getByRole('link', { name: '6,5 Creedmoor', exact: true })).toBeVisible();
      expect(await page.locator('table.cartridge-list tbody tr').count()).toBe(25);
    });

    test('search finds alternative names as the user types', async ({ page }) => {
      await page.getByLabel('Search').pressSequentially('7,62 x 51');
      await expect(page.getByText('1 cartridges', { exact: true })).toBeVisible();
      await expect(page.getByRole('link', { name: '308 Win.', exact: true })).toBeVisible();
      await expect(page.locator('table.cartridge-list tbody tr')).toHaveCount(1);
    });

    test('family select filters', async ({ page }) => {
      const select = page.getByLabel('Family');
      await expect(select.locator('option')).toHaveText(['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
      await select.selectOption('rimfire');
      await expect(page.getByText('3 cartridges', { exact: true })).toBeVisible();
      await select.selectOption('');
      await expect(page.getByText('25 cartridges', { exact: true })).toBeVisible();
    });

    test('no match shows a message and zero count', async ({ page }) => {
      await page.getByLabel('Search').fill('zzzz');
      await expect(page.getByText('0 cartridges', { exact: true })).toBeVisible();
      await expect(page.getByText('No cartridge matches')).toBeVisible();
    });
  });
}

test('makes no network requests besides the app files (file://)', async ({ page }) => {
  const requests = [];
  page.on('request', (r) => requests.push(r.url()));
  await page.goto(fileUrl);
  await expect(page.getByText('25 cartridges')).toBeVisible();
  expect(requests.filter((u) => !u.startsWith('file://'))).toEqual([]);
});
