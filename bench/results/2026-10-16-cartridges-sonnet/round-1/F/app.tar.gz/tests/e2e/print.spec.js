const { test, expect } = require('@playwright/test');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const data = require('../../data/cartridges.js');

const fileUrl = pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;

const pageCount = (pdf) => (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;

test.describe('print', () => {
  for (const rec of data) {
    test(`${rec.key} prints on one A4 page`, async ({ page }) => {
      await page.goto(`${fileUrl}#/cartridge/${rec.key}`);
      await page.reload();
      const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
      expect(pageCount(pdf)).toBe(1);
    });
  }

  test('content leaves room for the footer on every record (A4 content box is 186 x 277 mm)', async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: Math.round((186 / 25.4) * 96), height: 1100 } });
    const page = await ctx.newPage();
    await page.emulateMedia({ media: 'print' });
    for (const rec of data) {
      await page.goto(`${fileUrl}#/cartridge/${rec.key}`);
      await page.reload();
      const mm = await page.evaluate(() => (document.querySelector('article').getBoundingClientRect().height / 96) * 25.4);
      expect(mm, rec.key).toBeLessThan(277 - 9); // footer is ~7 mm tall
    }
    await ctx.close();
  });

  test('print view: light, no navigation/search/buttons, header, drawing, tables, footer', async ({ page }) => {
    await page.emulateMedia({ colorScheme: 'dark', media: 'print' });
    await page.goto(`${fileUrl}#/cartridge/308_win`);
    await page.reload();
    await expect(page.getByRole('button', { name: 'Print' })).toBeHidden();
    await expect(page.getByRole('link', { name: 'All cartridges' })).toBeHidden();
    await expect(page.locator('.site-bar')).toBeHidden();
    await expect(page.getByRole('heading', { level: 1, name: '308 Win.' })).toBeVisible();
    await expect(page.getByRole('img', { name: '308 Win. drawing' })).toBeVisible();
    await expect(page.locator('.source')).toHaveText('Source: C.I.P. TDCC, revised 2008-09-23');
    const colors = await page.evaluate(() => ({
      bg: getComputedStyle(document.body).backgroundColor,
      fg: getComputedStyle(document.body).color,
    }));
    expect(colors.bg).toBe('rgb(255, 255, 255)');
    expect(colors.fg).toBe('rgb(0, 0, 0)');
    // drawing is full width of the printable area (186 mm) and labels are at least 7 pt
    const m = await page.evaluate(() => {
      const svg = document.querySelector('svg.cartridge-drawing');
      const vb = svg.viewBox.baseVal;
      const widthMm = (svg.getBoundingClientRect().width / 96) * 25.4;
      const label = document.querySelector('svg .dim-label');
      const fsUnits = parseFloat(label.getAttribute('font-size'));
      return { widthMm, fontPt: ((fsUnits * (widthMm / vb.width)) / 25.4) * 72 };
    });
    expect(m.widthMm).toBeGreaterThan(180);
    expect(m.fontPt).toBeGreaterThan(7);
  });
});
