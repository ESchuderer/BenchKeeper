'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..', '..');
const jsonl = fs.readFileSync(path.join(root, 'data/cartridges.jsonl'), 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l));
const data = require('../../data/cartridges.js');

test('25 records', () => {
  assert.equal(jsonl.length, 25);
  assert.equal(data.length, 25);
});

test('cartridges.js equals cartridges.jsonl', () => {
  assert.deepEqual(data, jsonl);
});

test('keys and names are unique', () => {
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
  assert.equal(new Set(data.map((r) => r.name)).size, 25);
});

test('every record has the fields the app relies on', () => {
  for (const r of data) {
    for (const f of ['key', 'name', 'family', 'country', 'tab', 'published', 'revised', 'pressureMethod']) {
      assert.ok(r[f], `${r.key}.${f}`);
    }
    assert.ok(typeof r.cartridge.lengths.L3 === 'number', r.key);
    assert.ok(r.annotations.category && r.annotations.primerType && r.annotations.defaultBulletShape, r.key);
  }
});

test('spot checks against the brief', () => {
  const by = Object.fromEntries(data.map((r) => [r.key, r]));
  assert.equal(by['6_5_creedmoor'].name, '6,5 Creedmoor');
  assert.deepEqual(by['308_win'].alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(by['308_win'].cartridge.lengths.L3, 51.18);
  assert.equal(by['243_win'].cartridge.pressures.Pmax, 4150);
  assert.equal(by['243_win'].cartridge.lengths.L1Tol, -0.2);
  assert.deepEqual(by['223_rem'].chamber.rifling.i, { degrees: 3, minutes: 10, seconds: 36 });
  assert.equal(by['22_long_rifle'].alternativeNames.length, 5);
  assert.equal(by['300_win_mag'].family, 'belted');
  assert.equal(by['17_hmr'].cartridge.junctionCone.alpha, 50);
  assert.deepEqual(data.map((r) => r.family).reduce((a, f) => ({ ...a, [f]: (a[f] || 0) + 1 }), {}), { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3 });
});
