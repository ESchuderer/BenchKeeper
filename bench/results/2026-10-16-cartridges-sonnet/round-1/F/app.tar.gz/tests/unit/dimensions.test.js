'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../data/cartridges.js');
const G = require('../../js/geometry.js');
const D = require('../../js/dimensions.js');

const by = (k) => data.find((r) => r.key === k);
const layoutOf = (rec) => D.buildLayout(rec, G.buildCase(rec));

function allLabelBoxes(layout) {
  return [
    ...layout.dims.map((d) => ({ id: d.id, box: d.label.box })),
    ...layout.titleBlock.lines.map((t, i) => ({ id: `title${i}`, box: t.box })),
  ];
}

test('required dimensions are present with symbol + value labels (308 Win.)', () => {
  const l = layoutOf(by('308_win'));
  const texts = Object.fromEntries(l.dims.map((d) => [d.id, d.text]));
  assert.deepEqual(texts, {
    R: 'R 1.37', L1: 'L1 39.62', L2: 'L2 43.48', L3: 'L3 51.18', L6: 'L6 71.12',
    R1: 'R1 12.01', E1: 'E1 10.39', P1: 'P1 11.96', P2: 'P2 11.53', H1: 'H1 8.72', H2: 'H2 8.72', G1: 'G1 7.85', alpha: 'α 40°',
  });
});

test('every dimension has arrowheads and extension lines', () => {
  for (const rec of data) {
    for (const d of layoutOf(rec).dims) {
      if (d.kind === 'angle') {
        assert.equal(d.arrows.length, 2, `${rec.key} ${d.id}`);
        assert.ok(d.lines.length >= 2 && d.arc.length > 2, `${rec.key} ${d.id} legs`);
        continue;
      }
      assert.equal(d.arrows.length, 2, `${rec.key} ${d.id} arrows`);
      assert.ok(d.lines.filter((s) => s.cls === 'ext').length >= 2, `${rec.key} ${d.id} extension lines`);
      assert.ok(d.lines.some((s) => s.cls === 'dim'), `${rec.key} ${d.id} dimension line`);
    }
  }
});

test('all records: always L3, L6, R1, R, P1; published ones only when published', () => {
  for (const rec of data) {
    const ids = layoutOf(rec).dims.map((d) => d.id);
    for (const id of ['L3', 'L6', 'R1', 'R', 'P1', 'H2', 'G1']) assert.ok(ids.includes(id), `${rec.key} ${id}`);
    const c = G.buildCase(rec);
    assert.equal(ids.includes('E1'), c.anchors.groove, `${rec.key} E1`);
    for (const id of ['P2', 'H1', 'L1', 'L2', 'alpha']) assert.equal(ids.includes(id), c.bottleneck, `${rec.key} ${id}`);
  }
});

test('title block: name, table, revision, units, scale', () => {
  const l = layoutOf(by('308_win'));
  const texts = l.titleBlock.lines.map((t) => t.text);
  assert.ok(texts.includes('308 Win.'));
  assert.ok(texts.includes('C.I.P. table I'));
  assert.ok(texts.includes('Revised 2008-09-23'));
  assert.ok(texts.includes('Dimensions in mm'));
  assert.ok(texts.some((t) => /^Scale \d+\.\d : 1 \(A4 print\)$/.test(t)), texts.join('|'));
});

test('print scale: width = viewBox * scale, capped at the A4 content width and max height', () => {
  for (const rec of data) {
    const l = layoutOf(rec);
    assert.ok(l.printWidthMm <= D.PRINT_WIDTH_MM + 1e-9);
    assert.ok((l.printWidthMm * l.viewBox.h) / l.viewBox.w <= D.PRINT_MAX_HEIGHT_MM + 1e-6, rec.key);
    assert.ok(Math.abs(l.printScale * l.viewBox.w - l.printWidthMm) < 1e-9);
  }
});

test('labels do not overlap each other, the outline, or any dimension line/arrow, and stay inside the view box', () => {
  for (const rec of data) {
    const l = layoutOf(rec);
    const boxes = allLabelBoxes(l);
    const vb = l.viewBox;
    for (const { id, box } of boxes) {
      assert.ok(box.x0 >= vb.x && box.x1 <= vb.x + vb.w && box.y0 >= vb.y && box.y1 <= vb.y + vb.h, `${rec.key} ${id} inside view box`);
    }
    for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        assert.ok(!D.boxesOverlap(boxes[i].box, boxes[j].box, 0.2), `${rec.key}: label ${boxes[i].id} overlaps ${boxes[j].id}`);
      }
    }
    const obstacles = [...l.outline, l.centerline];
    for (const d of l.dims) {
      for (const s of d.lines) obstacles.push(s);
      for (const a of d.arrows) for (let k = 0; k < 3; k++) obstacles.push({ x1: a[k].x, y1: a[k].y, x2: a[(k + 1) % 3].x, y2: a[(k + 1) % 3].y });
      if (d.arc) for (let k = 1; k < d.arc.length; k++) obstacles.push({ x1: d.arc[k - 1].x, y1: d.arc[k - 1].y, x2: d.arc[k].x, y2: d.arc[k].y });
    }
    for (const { id, box } of boxes) {
      const grown = { x0: box.x0 - 0.2, x1: box.x1 + 0.2, y0: box.y0 - 0.2, y1: box.y1 + 0.2 };
      for (const s of obstacles) assert.ok(!D.boxHitsSegment(grown, s), `${rec.key}: label ${id} touches a line (${s.cls || 'arrow'}) at ${s.x1.toFixed(1)},${s.y1.toFixed(1)}`);
    }
    // title block frame does not touch the part or other dimensions
    const tb = l.titleBlock.rect;
    const frame = { x0: tb.x, x1: tb.x + tb.w, y0: tb.y, y1: tb.y + tb.h };
    for (const d of l.dims) assert.ok(!D.boxesOverlap(frame, d.label.box, 0), `${rec.key}: title block overlaps ${d.id}`);
    for (const s of [...l.outline, ...l.dims.flatMap((d) => d.lines)]) assert.ok(!D.boxHitsSegment(frame, s), `${rec.key}: title block hit by a line`);
  }
});
