'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../data/cartridges.js');
const G = require('../../js/geometry.js');
const D = require('../../js/dimensions.js');
const Dr = require('../../js/drawing.js');

const specOf = (rec) => { const c = G.buildCase(rec); return Dr.svgSpec(rec, c, D.buildLayout(rec, c)); };
const walk = (node, fn) => { fn(node); node.children.forEach((c) => walk(c, fn)); };

test('svg has the accessible name "<name> drawing" and a viewBox in mm', () => {
  for (const rec of data) {
    const s = specOf(rec);
    assert.equal(s.attrs.role, 'img');
    assert.equal(s.attrs['aria-label'], `${rec.name} drawing`);
    assert.equal(s.children[0].text, `${rec.name} drawing`);
    const [x, y, w, h] = s.attrs.viewBox.split(' ').map(Number);
    assert.ok(w > 20 && h > 20 && Number.isFinite(x) && Number.isFinite(y), rec.key);
  }
});

test('labels are single text elements "<symbol> <value>"', () => {
  const texts = [];
  walk(specOf(data.find((r) => r.key === '308_win')), (n) => { if (n.tag === 'text') texts.push(n.text); });
  for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°', 'Dimensions in mm', '308 Win.']) {
    assert.ok(texts.includes(t), `missing ${t}: ${texts.join(' | ')}`);
  }
});

test('angle labels use degrees, minutes, seconds', () => {
  const texts = [];
  walk(specOf(data.find((r) => r.key === '6_5_x_55_se')), (n) => { if (n.tag === 'text') texts.push(n.text); });
  assert.ok(texts.includes('α 50°35\'2"'), texts.join('|'));
});

test('paths contain finite numbers only', () => {
  for (const rec of data) walk(specOf(rec), (n) => { for (const v of Object.values(n.attrs)) assert.ok(!/NaN|Infinity|undefined/.test(String(v)), `${rec.key} ${n.tag}`); });
});

test('hatched section is clipped to the section polygon', () => {
  let clipped = 0;
  walk(specOf(data[0]), (n) => { if (n.attrs && n.attrs['clip-path']) clipped += 1; });
  assert.equal(clipped, 1);
});

test('svgSpec of an unavailable drawing is null; a missing G1 still gives a finite drawing', () => {
  const rec = JSON.parse(JSON.stringify(data[0]));
  delete rec.cartridge.caseHead.R1;
  const c = G.buildCase(rec);
  assert.equal(Dr.svgSpec(rec, c, c.unavailable ? null : D.buildLayout(rec, c)), null);
  const rec2 = JSON.parse(JSON.stringify(data[0]));
  delete rec2.cartridge.projectile.G1;
  walk(specOf(rec2), (n) => { for (const v of Object.values(n.attrs)) assert.ok(!/NaN|Infinity|undefined/.test(String(v)), n.tag); if (n.text) assert.ok(!/NaN|undefined/.test(n.text), n.text); });
});
