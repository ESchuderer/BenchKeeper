'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../data/cartridges.js');
const Fi = require('../../js/filter.js');

const names = (list) => list.map((r) => r.name);

test('empty query and All returns everything', () => {
  assert.equal(Fi.filterCartridges(data, { query: '', family: '' }).length, 25);
  assert.equal(Fi.filterCartridges(data, {}).length, 25);
});

test('searches alternative names: 7,62 x 51 finds 308 Win.', () => {
  assert.deepEqual(names(Fi.filterCartridges(data, { query: '7,62 x 51' })), ['308 Win.']);
});

test('case and whitespace insensitive', () => {
  assert.deepEqual(names(Fi.filterCartridges(data, { query: '7,62X51' })), ['308 Win.']);
  assert.deepEqual(names(Fi.filterCartridges(data, { query: '  creedMOOR ' })), ['6,5 Creedmoor']);
});

test('substring on the name', () => {
  assert.deepEqual(names(Fi.filterCartridges(data, { query: 'win.' })).sort(), ['243 Win.', '270 Win.', '300 Win. Mag.', '308 Win.', '22 Win. Mag. R.F.'].sort());
});

test('alternative name only matches', () => {
  assert.deepEqual(names(Fi.filterCartridges(data, { query: '22lr' })), ['22 Long Rifle']);
  assert.deepEqual(names(Fi.filterCartridges(data, { query: 'para' })), ['9 mm Luger']);
});

test('family filter and counts', () => {
  const counts = { rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 };
  for (const [f, n] of Object.entries(counts)) assert.equal(Fi.filterCartridges(data, { family: f }).length, n, f);
});

test('query and family combine; no match gives empty', () => {
  assert.deepEqual(names(Fi.filterCartridges(data, { query: 'win', family: 'belted' })), ['300 Win. Mag.']);
  assert.equal(Fi.filterCartridges(data, { query: 'zzz' }).length, 0);
});

test('keeps dataset order', () => {
  assert.deepEqual(names(Fi.filterCartridges(data, { family: 'rimmed' })), ['9,3 x 74 R', '7 x 65 R']);
});
