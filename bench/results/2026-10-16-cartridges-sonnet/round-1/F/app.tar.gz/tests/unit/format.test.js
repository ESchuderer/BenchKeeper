'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../../js/format.js');

test('formatNumber prints numbers as published', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(25.0), '25');
  assert.equal(F.formatNumber(-0.2), '-0.2');
  assert.equal(F.formatNumber(0.38), '0.38');
});

test('formatAngle: degrees or degrees/minutes/seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(0), '0°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(F.formatAngle({ degrees: 40, minutes: 0, seconds: 0 }), '40°');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'0"');
  assert.equal(F.formatAngle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
});

test('angleToDegrees', () => {
  assert.equal(F.angleToDegrees(40), 40);
  assert.ok(Math.abs(F.angleToDegrees({ degrees: 39, minutes: 59, seconds: 49 }) - 39.99694) < 1e-4);
});

test('symbols', () => {
  const expected = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax', Fe: 'Fe', r2: 'r2' };
  for (const [k, v] of Object.entries(expected)) assert.equal(F.symbolFor(k), v, k);
});

test('units', () => {
  for (const k of ['Pmax', 'PK', 'PE']) assert.equal(F.unitFor(k), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('N'), '');
  for (const k of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unitFor(k), 'deg', k);
  for (const k of ['L3', 'P1', 'R', 'u', 'b', 'deltaL', 'Fe', 'G2', 'L3PlusG']) assert.equal(F.unitFor(k), 'mm', k);
});

test('formatValue: numbers, angles, tolerance', () => {
  assert.deepEqual(F.formatValue('L1', 39.62, -0.2), { value: '39.62', tol: '-0.2' });
  assert.deepEqual(F.formatValue('Pmax', 4150), { value: '4150', tol: '' });
  assert.deepEqual(F.formatValue('i', { degrees: 3, minutes: 10, seconds: 36 }), { value: '3°10\'36"', tol: '' });
  assert.deepEqual(F.formatValue('beta', 35), { value: '35°', tol: '' });
  assert.deepEqual(F.formatValue('i', 5), { value: '5°', tol: '' });
});
