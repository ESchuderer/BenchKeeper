'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../data/cartridges.js');
const G = require('../../js/geometry.js');

const by = (k) => data.find((r) => r.key === k);
const near = (a, b, eps = 1e-6, msg) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} expected ${b}, got ${a}`);
const clone = (r) => JSON.parse(JSON.stringify(r));
const DEG = Math.PI / 180;

test('rule 1: rim type', () => {
  const t = Object.fromEntries(data.map((r) => [r.key, G.rimType(r)]));
  assert.equal(t['300_win_mag'], 'belted');
  assert.equal(t['7_mm_rem_mag'], 'belted');
  assert.equal(t['22_long_rifle'], 'rimfire');
  assert.equal(t['17_hmr'], 'rimfire');
  assert.equal(t['308_win'], 'rimless');
  assert.equal(t['6_5_x_55_se'], 'rimless'); // R1/P1 = 1.0
  assert.equal(t['9_mm_luger'], 'rimless');
  assert.equal(t['7_x_65_r'], 'rimmed');
  assert.equal(t['38_special'], 'rimmed'); // pistol family, but R1/P1 >= 1.05
  assert.equal(t['44_rem_mag'], 'rimmed');
  // thresholds with synthetic fixtures: nothing in the data is rebated
  const fx = (R1, P1) => ({ family: 'rimless', cartridge: { caseHead: { R1 }, powderChamber: { P1 } } });
  assert.equal(G.rimType(fx(10.5, 10)), 'rimmed'); // 1.05
  assert.equal(G.rimType(fx(10.49, 10)), 'rimless');
  assert.equal(G.rimType(fx(9.8, 10)), 'rimless'); // 0.98
  assert.equal(G.rimType(fx(9.79, 10)), 'rebated');
});

test('rule 2: head face chamfer (308 Win.)', () => {
  const c = G.buildCase(by('308_win'));
  const o = c.outer;
  assert.deepEqual(o[0], { r: 0, z: 0 });
  near(o[1].r, 12.01 / 2 - 0.38 * Math.tan(35 * DEG));
  assert.equal(o[1].z, 0);
  assert.deepEqual(o[2], { r: 12.01 / 2, z: 0.38 });
  assert.deepEqual(o[3], { r: 12.01 / 2, z: 1.37 });
});

test('rule 2: chamfer is limited to R1/4', () => {
  const rec = clone(by('308_win'));
  rec.cartridge.caseHead.f = 5; // f*tan(35) = 3.5 > R1/4 = 3.0025
  const o = G.buildCase(rec).outer;
  near(o[1].r, 12.01 / 2 - 12.01 / 4);
});

test('rule 2: rimfire half-round (22 Long Rifle) and square corner fallback', () => {
  const c = G.buildCase(by('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const maxR = Math.max(...c.outer.filter((p) => p.z <= 1.09).map((p) => p.r));
  near(maxR, 7.06 / 2, 1e-9, 'outermost point at R1/2');
  near(c.outer[1].r, 7.06 / 2 - rho);
  // all half-round points are within rho of its centre
  const arc = c.outer.filter((p) => p.z > 0 && p.z < 2 * rho && p.r > 7.06 / 2 - rho);
  assert.ok(arc.length > 5);
  for (const p of arc) near(Math.hypot(p.r - (7.06 / 2 - rho), p.z - rho), rho, 1e-9);
  // no groove, step in at z = R
  assert.ok(c.outer.some((p) => p.r === 5.74 / 2 && p.z === 1.09));
  // square corner: a non-rimfire case with neither beta nor f
  const rec = clone(by('308_win'));
  delete rec.cartridge.caseHead.beta;
  delete rec.cartridge.caseHead.f;
  const o = G.buildCase(rec).outer;
  assert.deepEqual(o.slice(0, 3), [{ r: 0, z: 0 }, { r: 12.01 / 2, z: 0 }, { r: 12.01 / 2, z: 1.37 }]);
});

test('rule 3: extractor groove (308 Win.)', () => {
  const o = G.buildCase(by('308_win')).outer;
  const i = o.findIndex((p) => p.r === 10.39 / 2 && p.z === 1.37);
  assert.ok(i > 0, 'groove wall');
  assert.deepEqual(o[i + 1], { r: 10.39 / 2, z: 1.37 + 1.4 });
  assert.deepEqual(o[i + 2], { r: 11.96 / 2, z: 3.85 });
});

test('rule 3: no groove steps in at z = R (rimmed)', () => {
  const o = G.buildCase(by('7_x_65_r')).outer;
  const i = o.findIndex((p) => p.r === 13.32 / 2 && p.z === 1.4);
  assert.deepEqual(o[i + 1], { r: 11.89 / 2, z: 1.4 });
});

test('rule 3: belted ramp at delta to the axis, belt to E, step in', () => {
  const c = G.buildCase(by('300_win_mag'));
  const o = c.outer;
  const floorEnd = { r: 12.07 / 2, z: 1.27 + 0.94 };
  const i = o.findIndex((p) => p.r === floorEnd.r && p.z === floorEnd.z);
  assert.ok(i > 0);
  const dz = (13.51 / 2 - 12.07 / 2) / Math.tan(35 * DEG);
  near(o[i + 1].r, 13.51 / 2);
  near(o[i + 1].z, floorEnd.z + dz);
  assert.deepEqual(o[i + 2], { r: 13.51 / 2, z: 5.59 });
  assert.deepEqual(o[i + 3], { r: 13.03 / 2, z: 5.59 });
  near(c.beltRampEndZ, floorEnd.z + dz);
});

test('rule 4/5/6: bottleneck passes through the published points', () => {
  const c = G.buildCase(by('308_win'));
  assert.equal(c.bottleneck, true);
  const has = (r, z) => c.outer.some((p) => Math.abs(p.r - r) < 1e-9 && Math.abs(p.z - z) < 1e-9);
  assert.ok(has(11.96 / 2, 3.85));
  assert.deepEqual(c.outer[c.outer.length - 1], { r: 8.72 / 2, z: 51.18 });
  // fillets replace the sharp corners (r1 min = 0.76 at body/shoulder, r2 = 3.18 at shoulder/neck)
  assert.equal(has(11.53 / 2, 39.62), false);
  assert.equal(has(8.72 / 2, 43.48), false);
  // tangent points lie on the published lines
  const k = (8.72 / 2 - 11.53 / 2) / (43.48 - 39.62); // shoulder dr/dz
  const [f1, f2] = c.fillets;
  for (const p of [f1.p2, f2.p1]) near(p.r, 11.53 / 2 + k * (p.z - 39.62), 1e-9, 'tangent point on shoulder line');
  assert.deepEqual(c.outer.filter((p) => p.z > f1.p2.z && p.z < f2.p1.z), [], 'shoulder is straight between the fillets');
  near(f1.arc[0].r, f1.p1.r, 1e-9);
  near(f1.arc[f1.arc.length - 1].z, f1.p2.z, 1e-9);
  near(f2.arc[f2.arc.length - 1].r, 8.72 / 2, 1e-9); // tangent to the neck line r = H1/2 = H2/2
});

test('rule 5: fillet is tangent and of the published radius', () => {
  const c = G.buildCase(by('6_5_x_55_se')); // r1 min 3.5, r2 3.7
  assert.equal(c.fillets.length, 2);
  near(c.fillets[0].radius, 3.5);
  near(c.fillets[1].radius, 3.7);
  for (const f of c.fillets) {
    for (const p of f.arc) near(Math.hypot(p.r - f.center.r, p.z - f.center.z), f.radius, 1e-9);
  }
});

test('rule 5: fillets that do not fit the shoulder are reduced and reported', () => {
  const rec = clone(by('7_62_x_39'));
  rec.cartridge.junctionCone.r1Min = 40;
  rec.cartridge.junctionCone.r2 = 30;
  const c = G.buildCase(rec);
  assert.ok(c.fillets[0].radius < 40);
  assert.ok(c.fillets[0].radius / c.fillets[1].radius > 40 / 30 - 1e-9 && c.fillets[0].radius / c.fillets[1].radius < 40 / 30 + 1e-9, 'proportional');
  assert.ok(c.notes.some((n) => /reduced to fit/.test(n.text)));
  for (let i = 1; i < c.outer.length; i++) assert.ok(c.outer[i].z >= c.outer[i - 1].z - 1e-9);
});

test('rule 4: a case without alpha, L1 or L2 is straight', () => {
  const c = G.buildCase(by('9_mm_luger'));
  assert.equal(c.bottleneck, false);
  assert.deepEqual(c.outer[c.outer.length - 1], { r: 9.65 / 2, z: 19.15 });
  assert.deepEqual(c.fillets, []);
  assert.equal(c.notes.length, 0);
  assert.equal(G.buildCase(by('22_win_mag_r_f')).bottleneck, false);
});

test('rule 8: walls, solid head, primer pocket', () => {
  const c = G.buildCase(by('308_win'));
  near(c.tn, 0.435);
  near(c.tb, 0.6);
  assert.deepEqual(c.pocket, { diameter: 5.33, depth: 3.3 });
  near(c.w, 4.8);
  const nine = G.buildCase(by('9_mm_luger'));
  assert.deepEqual(nine.pocket, { diameter: 4.45, depth: 3.04 });
  near(nine.tn, 0.31);
  near(nine.w, 4.54);
  const belt = G.buildCase(by('300_win_mag'));
  near(belt.w, 5.59 + 0.6); // E + tb dominates
  assert.deepEqual(belt.pocket, { diameter: 5.33, depth: 3.3 });
  assert.equal(G.buildCase(by('22_long_rifle')).pocket, null);
  near(G.buildCase(by('22_long_rifle')).w, 2.5);
  assert.deepEqual(G.buildCase(by('45_auto')).pocket, { diameter: 5.33, depth: 3.04 }); // lp
  assert.deepEqual(G.buildCase(by('357_magnum')).pocket, { diameter: 4.45, depth: 3.04 }); // spm
  assert.deepEqual(G.buildCase(by('44_rem_mag')).pocket, { diameter: 5.33, depth: 3.04 }); // lpm
  assert.deepEqual(G.buildCase(by('338_lapua_mag')).pocket, { diameter: 5.33, depth: 3.3 }); // lrm
  assert.deepEqual(G.buildCase(by('223_rem')).pocket, { diameter: 4.45, depth: 3.04 }); // sr
});

test('rule 8: wall limited by 0.35 * P1/2', () => {
  const rec = clone(by('308_win'));
  rec.cartridge.caseHead.R1 = 3; // keep P1 small: P1 = 2 -> 0.35 * 1 = 0.35 < 0.6
  rec.cartridge.powderChamber.P1 = 2;
  near(G.buildCase(rec).tb, 0.35);
});

test('rule 8 (D2/D3): inner line follows the walls; heeled case uses tn = tb', () => {
  const c = G.buildCase(by('308_win'));
  const last = c.inner[c.inner.length - 1];
  near(last.r, 8.72 / 2 - 0.435);
  near(last.z, 51.18);
  assert.ok(c.inner[0].z === c.w);
  near(c.inner[0].r, 11.96 / 2 - 0.6 - (11.96 / 2 - 11.53 / 2) * 0, 0.05); // body wall tb at the head
  const heeled = G.buildCase(by('22_long_rifle'));
  assert.equal(heeled.heeled, true);
  near(heeled.tn, heeled.tb);
  near(heeled.inner[heeled.inner.length - 1].r, 5.72 / 2 - 0.6);
  // straight case: wall blends from tb to tn at the bullet base (D2)
  const nine = G.buildCase(by('9_mm_luger'));
  const atBase = nine.inner.find((p) => Math.abs(p.z - nine.bullet.zb) < 1e-9);
  assert.ok(atBase);
  near(G.radiusAt(nine.outer, nine.bullet.zb) - atBase.r, 0.31, 1e-6);
  near(nine.inner[nine.inner.length - 1].r, 9.03 / 2);
});

test('rule 7: bullet seating, k, ogive (308 Win., pointy)', () => {
  const b = G.buildCase(by('308_win')).bullet;
  near(b.s, 7.85);
  near(b.zb, 51.18 - 7.85);
  near(b.zc, b.zb + 0.4 * (71.12 - b.zb));
  near(b.m, 1.27);
  const n = 71.12 - b.zc;
  const rho = ((7.85 / 2 - 1.27 / 2) ** 2 + n * n) / (2 * (7.85 / 2 - 1.27 / 2));
  near(b.rho, rho);
  near(b.exposed[b.exposed.length - 1].z, 71.12);
  // tangent ogive: every nose point is at distance rho from the centre (G1/2 - rho, zc)
  for (const p of b.nose) near(Math.hypot(p.r - (7.85 / 2 - rho), p.z - b.zc), rho, 1e-9);
  const tip = b.nose[b.nose.length - 1];
  near(tip.r, 1.27 / 2, 1e-9);
  near(tip.z, 71.12, 1e-9);
});

test('rule 7: seating depth and k by shape and category', () => {
  const b = (k) => G.buildCase(by(k)).bullet;
  near(b('9_mm_luger').s, 0.4 * 9.03); // rounded pistol
  near(b('22_long_rifle').s, 0.8 * 5.72); // rounded rimfire
  near(b('40_s_w').s, 0.4 * 10.17); // flat pistol
  near(b('357_magnum').s, 0.6 * 9.12); // semi_wadcutter
  near(b('17_hmr').s, 4.38); // pointy rimfire
  const k = (key) => { const x = b(key); return (x.zc - x.zb) / (x.L6 - x.zb); };
  near(k('308_win'), 0.4);
  near(k('9_mm_luger'), 0.65);
  near(k('22_long_rifle'), 0.55);
  near(k('40_s_w'), 0.7);
  near(k('357_magnum'), 0.78);
  near(b('9_mm_luger').m, 0.15 * 9.03); // rounded
  near(b('40_s_w').m, 0.55 * 10.17); // flat
  near(b('357_magnum').m, 0.6 * 9.12); // semi_wadcutter
  near(b('17_hmr').m, 1.27); // max(0.08*4.38, 1.27)
});

test('rule 7: rounded nose is a quarter ellipse, flat/swc are cones', () => {
  const r = G.buildCase(by('9_mm_luger')).bullet;
  const a = 9.03 / 2 - r.m / 2;
  const n = 29.69 - r.zc;
  for (const p of r.nose) near(((p.r - r.m / 2) / a) ** 2 + ((p.z - r.zc) / n) ** 2, 1, 1e-9);
  const f = G.buildCase(by('40_s_w')).bullet;
  assert.equal(f.nose.length, 2);
  near(f.nose[0].r, 10.17 / 2);
  near(f.nose[1].r, f.m / 2);
});

test('rule 7: heeled case (22 Long Rifle)', () => {
  const c = G.buildCase(by('22_long_rifle'));
  const b = c.bullet;
  assert.equal(c.heeled, true);
  near(b.radius, 5.72 / 2); // exposed: case outside diameter
  near(b.heelRadius, (5.72 - 2 * c.tb) / 2); // seated heel: case inside diameter
  const seated = b.seated.filter((p) => p.z < 15.57 - 1e-9);
  for (const p of seated) assert.ok(p.r <= b.heelRadius + 1e-9);
  assert.equal(G.buildCase(by('22_win_mag_r_f')).heeled, false);
});

test('outside view hides the seated part', () => {
  const c = G.buildCase(by('308_win'));
  for (const p of c.bullet.exposed) assert.ok(p.z >= 51.18 - 1e-9);
  assert.ok(c.bullet.seated.some((p) => p.z < 51.18));
});

test('rule 9: missing values drop the feature and are named', () => {
  const miss = (rec) => G.buildCase(rec).notes.flatMap((n) => n.missing);
  assert.deepEqual(miss(by('17_hmr')).sort(), ['r1Min', 'r2']);
  assert.deepEqual(miss(by('338_lapua_mag')), ['r1Min']);
  const rec = clone(by('308_win'));
  delete rec.cartridge.caseHead.eMin;
  const c = G.buildCase(rec);
  assert.deepEqual(c.notes.flatMap((n) => n.missing), ['eMin']);
  assert.ok(!c.outer.some((p) => p.r === 10.39 / 2), 'no groove drawn');
  const rec2 = clone(by('308_win'));
  delete rec2.cartridge.projectile.G1;
  const c2 = G.buildCase(rec2);
  assert.equal(c2.bullet, null);
  assert.ok(c2.notes.some((n) => n.missing.includes('G1')));
  const rec3 = clone(by('300_win_mag'));
  delete rec3.cartridge.caseHead.R3;
  assert.ok(G.buildCase(rec3).notes.some((n) => n.missing.includes('R3')));
  const rec4 = clone(by('308_win'));
  delete rec4.cartridge.junctionCone.alpha;
  const c4 = G.buildCase(rec4);
  assert.equal(c4.bottleneck, false);
  assert.ok(c4.notes.some((n) => n.missing.includes('alpha')));
  const rec5 = clone(by('308_win'));
  delete rec5.annotations.primerType;
  assert.equal(G.buildCase(rec5).pocket, null);
  assert.ok(G.buildCase(rec5).notes.some((n) => n.missing.includes('primerType')));
});

test('invariants for all 25 records', () => {
  for (const rec of data) {
    const c = G.buildCase(rec);
    const id = rec.key;
    const L3 = rec.cartridge.lengths.L3;
    for (const list of [c.outer, c.inner, c.section, c.bullet.seated, c.bullet.exposed]) {
      assert.ok(list.length > 2, id);
      for (const p of list) assert.ok(Number.isFinite(p.r) && Number.isFinite(p.z), `${id} finite`);
    }
    for (let i = 1; i < c.outer.length; i++) assert.ok(c.outer[i].z >= c.outer[i - 1].z - 1e-9, `${id} outer z monotone at ${i}`);
    for (const p of c.outer) assert.ok(p.r >= -1e-12, `${id} r>=0`);
    assert.deepEqual(c.outer[c.outer.length - 1], { r: rec.cartridge.collar.H2 / 2, z: L3 }, id);
    // inner line is inside the outer wall and above the solid head
    for (const p of c.inner) {
      assert.ok(p.z >= c.w - 1e-9 && p.z <= L3 + 1e-9, `${id} inner z range`);
      assert.ok(p.r > 0, `${id} inner r > 0`);
    }
    assert.ok(c.w < L3, id);
    // bullet fits: radius never exceeds the inner wall at the same z
    for (const p of c.bullet.seated) {
      if (p.z < c.w || p.z > L3 - 1e-9) continue;
      assert.ok(p.r <= innerRadiusAt(c.inner, p.z) + 1e-6, `${id} bullet inside the case at z=${p.z}: ${p.r} > ${innerRadiusAt(c.inner, p.z)}`);
    }
    assert.ok(c.bullet.zc >= c.bullet.zb && c.bullet.zc < c.bullet.L6, `${id} nose length`);
    // exposed bullet never wider than the case mouth
    for (const p of c.bullet.exposed) assert.ok(p.r <= rec.cartridge.collar.H2 / 2 + 1e-9, id);
    // cavity is open: inner mouth radius < outer mouth radius
    assert.ok(c.inner[c.inner.length - 1].r < rec.cartridge.collar.H2 / 2 || c.heeled, id);
    // no fillet was reduced for the 25 records
    assert.ok(!c.notes.some((n) => /reduced to fit/.test(n.text)), `${id} fillet fits`);
  }
});

function innerRadiusAt(inner, z) {
  for (let i = 1; i < inner.length; i++) {
    const a = inner[i - 1];
    const b = inner[i];
    if (z >= a.z - 1e-9 && z <= b.z + 1e-9) {
      if (b.z === a.z) return Math.min(a.r, b.r);
      return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
    }
  }
  return inner[inner.length - 1].r;
}

test('rule 9: an essential value missing gives a note, never NaN', () => {
  for (const field of [['caseHead', 'R'], ['caseHead', 'R1'], ['powderChamber', 'P1'], ['collar', 'H2'], ['lengths', 'L3']]) {
    const rec = clone(by('308_win'));
    delete rec.cartridge[field[0]][field[1]];
    const c = G.buildCase(rec);
    assert.equal(c.unavailable, true, field.join('.'));
    assert.deepEqual(c.notes.flatMap((n) => n.missing), [field[1]]);
    assert.ok(/not available/.test(c.notes[0].text));
  }
});

test('G1 missing: bullet and section dropped, outline stays finite', () => {
  const rec = clone(by('308_win'));
  delete rec.cartridge.projectile.G1;
  const c = G.buildCase(rec);
  assert.equal(c.bullet, null);
  assert.equal(c.section, null);
  for (const p of c.outer) assert.ok(Number.isFinite(p.r) && Number.isFinite(p.z));
});

test('a rimfire record without primerType gets no pocket and no pocket note', () => {
  const rec = clone(by('22_long_rifle'));
  delete rec.annotations.primerType;
  const c = G.buildCase(rec);
  assert.equal(c.pocket, null);
  assert.ok(!c.notes.some((n) => n.missing.includes('primerType')));
});
