'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../data/cartridges.js');
const M = require('../../js/model.js');

const by = (k) => data.find((r) => r.key === k);

test('metadata of 308 Win.', () => {
  const rows = Object.fromEntries(M.buildMeta(by('308_win')).map((r) => [r.key, r]));
  assert.equal(rows.alternativeNames.text, '308 Winchester, 7,62 x 51');
  assert.equal(rows.family.text, 'rimless');
  assert.equal(rows.category.text, 'rifle');
  assert.equal(rows.primerType.text, 'lr');
  assert.equal(rows.tab.text, 'I');
  assert.equal(rows.country.text, 'US');
  assert.equal(rows.published.text, '1984-06-14');
  assert.equal(rows.revised.text, '2008-09-23');
  assert.equal(rows.pressureMethod.text, 'Transducer');
  assert.equal(rows.waterCapacity.text, '56 gr H2O');
  assert.deepEqual(rows.waterCapacity.link, { text: 'kwk', href: 'http://kwk.us/cases.html' });
  assert.equal(rows.waterCapacity.note, 'Lapua brass measures 55.8 (lapua-308)');
});

test('record without capacity or alternative names', () => {
  const rows = Object.fromEntries(M.buildMeta(by('7_x_64')).map((r) => [r.key, r]));
  assert.equal(rows.waterCapacity.text, 'not published');
  assert.equal(rows.waterCapacity.link, undefined);
  assert.equal(rows.alternativeNames.text, 'none');
});

test('tables: tolerance next to value, never a row of its own', () => {
  const t = M.buildTables(by('243_win'));
  const lengths = t.cartridge.find((s) => s.id === 'lengths');
  assert.deepEqual(lengths.rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  assert.deepEqual(lengths.rows[0], { field: 'L1', symbol: 'L1', value: '39.62', tol: '-0.2', unit: 'mm' });
  for (const rec of data) {
    const tt = M.buildTables(rec);
    for (const s of [...tt.cartridge, ...tt.chamber]) for (const r of s.rows) assert.ok(!/Tol$/.test(r.field), `${rec.key} ${r.field}`);
  }
});

test('symbols, units and angle values in tables', () => {
  const t = M.buildTables(by('223_rem'));
  const head = t.cartridge.find((s) => s.id === 'caseHead');
  const eMin = head.rows.find((r) => r.field === 'eMin');
  assert.equal(eMin.symbol, 'e min');
  assert.equal(head.rows.find((r) => r.field === 'beta').value, '35°');
  assert.equal(head.rows.find((r) => r.field === 'beta').symbol, 'β');
  const press = t.cartridge.find((s) => s.id === 'pressures');
  assert.deepEqual(press.rows.find((r) => r.field === 'Pmax'), { field: 'Pmax', symbol: 'Pmax', value: '4300', tol: '', unit: 'bar' });
  const rifling = t.chamber.find((s) => s.id === 'rifling');
  assert.equal(rifling.rows.find((r) => r.field === 'i').value, '3°10\'36"');
  assert.equal(t.cartridge.find((s) => s.id === 'projectile').rows.find((r) => r.field === 'L3PlusG').symbol, 'L3 + G');
  const grooves = t.chamber.find((s) => s.id === 'grooves');
  assert.equal(grooves.rows.find((r) => r.field === 'N').unit, '');
});

test('empty sections are omitted; every value appears exactly once', () => {
  const rec = by('9_mm_luger');
  const t = M.buildTables(rec);
  assert.ok(!t.cartridge.some((s) => s.id === 'junctionCone'));
  assert.ok(!t.chamber.some((s) => s.id === 'junctionCone'));
  for (const r of data) {
    const tt = M.buildTables(r);
    for (const part of ['cartridge', 'chamber']) {
      const expected = Object.values(r[part]).reduce((n, sec) => n + Object.keys(sec).filter((k) => !(k.endsWith('Tol') && k.slice(0, -3) in sec)).length, 0);
      const actual = tt[part].reduce((n, s) => n + s.rows.length, 0);
      assert.equal(actual, expected, `${r.key} ${part}`);
    }
  }
});

test('section titles', () => {
  const t = M.buildTables(by('223_rem'));
  assert.deepEqual(t.cartridge.map((s) => s.title), ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile']);
});
