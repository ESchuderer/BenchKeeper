'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const R = require('../../js/router.js');

test('parseHash', () => {
  assert.deepEqual(R.parseHash(''), { view: 'list' });
  assert.deepEqual(R.parseHash('#'), { view: 'list' });
  assert.deepEqual(R.parseHash('#/'), { view: 'list' });
  assert.deepEqual(R.parseHash('#/cartridge/308_win'), { view: 'detail', key: '308_win' });
  assert.deepEqual(R.parseHash('#/cartridge/'), { view: 'notfound' });
  assert.deepEqual(R.parseHash('#/nonsense'), { view: 'notfound' });
});

test('hrefFor round-trips', () => {
  assert.equal(R.detailHref('308_win'), '#/cartridge/308_win');
  assert.deepEqual(R.parseHash(R.detailHref('6_5_creedmoor')), { view: 'detail', key: '6_5_creedmoor' });
  assert.equal(R.LIST_HREF, '#/');
});
