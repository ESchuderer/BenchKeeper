# C.I.P. cartridge reference

Static, offline reference for 25 C.I.P. cartridges with computed, dimensioned drawings. Open `index.html` directly
(`file://`) or serve the folder with any static file server. No build step, no runtime dependencies, no network requests.

- `js/data.js` the 25 records (OpenBallistics, MIT); `js/format.js`, `js/model.js` display rules, search, routing;
  `js/geometry.js` cartridge geometry; `js/drawing.js` SVG drawing; `js/app.js` the views.
- Design: `docs/superpowers/specs/`, plan: `docs/superpowers/plans/`, original brief: `docs/brief.md`.

Dev only: `npm install`, `npm test` (unit tests, Node 22), `npx playwright install chromium`, then `npm run test:e2e` and
`npm run verify` (all 25 cartridges: one-page A4 print, label collisions with real fonts, dark/phone, no console errors or requests).
