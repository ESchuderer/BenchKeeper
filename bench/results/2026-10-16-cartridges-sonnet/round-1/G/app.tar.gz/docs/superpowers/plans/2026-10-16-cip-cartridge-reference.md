# C.I.P. Cartridge Reference Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Static offline reference app for 25 C.I.P. cartridges: filterable list, detail view with computed to-scale SVG drawing and value tables, one-page A4 print.

**Architecture:** Classic `<script>` files attach pure modules to `globalThis.CIP` (data, format, model, geometry, drawing) plus a DOM layer (`app.js`). Pure modules have no DOM so `node:test` loads them in a `vm` context exactly as a browser would. Hash routing. Drawing is an SVG string built from the record.

**Tech Stack:** HTML/CSS/JS, no runtime deps. Dev: Node 22 `node:test`, Playwright (Chromium) for browser verification.

**Spec:** `docs/superpowers/specs/2026-10-16-cip-cartridge-reference-design.md` and the user's brief (rules 1–9 for geometry).

## Global Constraints

- No framework, no build step, no network requests (no CDN/web fonts/analytics); works from `file://` in Chromium and from a static server.
- Files: `index.html`, `css/style.css`, `js/{data,format,model,geometry,drawing,app}.js` (load in this order).
- Data: the 25 records verbatim; units mm unless: `Pmax PK PE` bar, `EE` J, `M` g, `Q` mm², `N` none, angles `alpha alpha1 beta delta i`.
- Numbers shown as `String(n)`; angles `40°` / `39°59'49"`; `XTol` shown next to X (`39.62 -0.2`), never its own row.
- Symbols = field name except `eMin`→"e min", `r1Min`→"r1 min", `r1Max`→"r1 max", `alpha`→"α", `alpha1`→"α1", `beta`→"β", `delta`→"δ", `deltaL`→"delta L", `L3PlusG`→"L3 + G".
- Start page: heading "Cartridges"; field labelled "Search"; select labelled "Family" (All, rimless, rimmed, belted, pistol, rimfire); text "<n> cartridges"; each name a link whose text is exactly `name`.
- Detail: h1 = name; tables with columns "Symbol", "Value", "Unit"; button "Print"; link "All cartridges"; SVG accessible name "<name> drawing".
- Print: A4 portrait, black on white, one page, no nav/search/buttons, footer "Source: C.I.P. TDCC, revised <date>".
- Interface in English. Git: none (not a repository); do not commit.

## Review Focus

- Missing optional values (no `E`, no `f`, no `r1Min`, no `alpha`, no publishedCapacity): drawing/tables render, notes name the missing value (tests in Tasks 4–5).
- Unknown route `#/cartridge/nope` and empty/garbage hash: friendly "not found" with link to list, no exception (Task 6).
- Search with no hits / only whitespace / regex characters (`(`, `*`): count "0 cartridges", no exception (Task 3).
- Heeled bullet (22 Long Rifle, `H2 - G1 = 0`): tn would be zero; wall must stay visible (Task 4).
- Every record: label boxes never overlap each other or the outline; no NaN in the SVG; one printed page (Tasks 5, 7).

---

### Task 1: Scaffold, data, test harness

**Files:** Create `package.json`, `tests/helpers/load.js`, `js/data.js`, `tests/data.test.js`.

**Interfaces:**
- Produces: `globalThis.CIP.data: object[]` (25 records, as given); `load(files?: string[]): {CIP}` in `tests/helpers/load.js` runs the `js/*.js` files (default: all pure modules in order) in a fresh `vm` context with `globalThis` as `window` and returns the context's `CIP`.

- [ ] Step 1: Write `tests/data.test.js`: 25 records; `key`s unique; names include `"6,5 Creedmoor"`, `"7 mm Rem. Mag."`; every record has `cartridge`, `chamber`, `family`, `tab`, `revised`; `308 Win.` has alternativeNames `["308 Winchester","7,62 x 51"]`; `223 Rem.` `cartridge.lengths.L3 === 44.7`; `22 Long Rifle` has `annotations.implausible[0].fields`.
- [ ] Step 2: Run `node --test tests/` → FAIL (no data).
- [ ] Step 3: `package.json` (`"scripts": {"test": "node --test tests/unit"}`, devDependency `playwright`); write `js/data.js` as `globalThis.CIP = globalThis.CIP || {}; CIP.data = [ ...25 records verbatim... ];`; write the loader.
- [ ] Step 4: Tests pass.

### Task 2: Formatting (`js/format.js`)

**Interfaces:** Produces `CIP.format = { number(n): string, angle(a): string, unitOf(field): string, symbolOf(field): string, isAngle(field): boolean }`.

- [ ] Step 1: Tests: `number(51.18)==="51.18"`, `number(4150)==="4150"`, `number(5.0)==="5"`; `angle(40)==="40°"`, `angle({degrees:39,minutes:59,seconds:49})==='39°59\'49"'`, `angle({degrees:3,minutes:10,seconds:36})==='3°10\'36"'`; `unitOf`: `Pmax`→`bar`, `EE`→`J`, `M`→`g`, `Q`→`mm²`, `N`→`""`, `alpha`→`°`, `L3`→`mm`, `Fe`→`mm`; `symbolOf` for each special name and `"L1"`→`"L1"`.
- [ ] Step 2–4: fail, implement, pass.

### Task 3: Model, search, routing (`js/model.js`)

**Interfaces:**
- Consumes: `CIP.format`, `CIP.data`.
- Produces: `CIP.model = { sections(record, part: 'cartridge'|'chamber'): {id, title, rows: {field, symbol, value: string, tol: string|"", unit}[]}[], facts(record): {label, html-free value descriptor}[], matches(record, query, family): boolean, filter(records, query, family): record[], parseHash(hash): {view:'list', q, family} | {view:'detail', key} | {view:'notfound'}, listHash(q, family): string, detailHash(key): string, FAMILIES: string[] }`.

- [ ] Step 1: Tests: `sections(223 Rem., 'cartridge')` has `lengths` with rows L1 (value `36.52`, tol `-0.2`), L2, L3, L6; no row named `L1Tol`; `caseHead` rows include `eMin` with symbol `e min`; `junctionCone.alpha` value `46°`; `7 x 64` `alpha` value `40°25'44"`; empty `junctionCone` of `9 mm Luger` omitted; `N` row unit `""`; chamber `rifling.i` for 223 `3°10'36"`, for `7 mm Rem. Mag.` `3°`. `matches`: `7,62 x 51` finds `308 Win.`; `7,62x51` and `7.62 x 51` too; `win.` finds 6 records incl. Mag.; query `(` / `*` returns 0 without throwing; whitespace-only query → all; family filter `pistol` → 6. Hash: `parseHash("#/cartridge/223_rem")`, `""`, `"#/"`, `"#/?q=308&family=rimless"`, `"#/cartridge/%E2%82%AC"`, `"#/zzz"` → notfound.
- [ ] Step 2–4: fail, implement (normalise: lowercase, remove whitespace, `.`→`,`; compare by `includes` on name and each alternative name), pass.

### Task 4: Geometry (`js/geometry.js`)

**Interfaces:**
- Consumes: `CIP.data` records only.
- Produces: `CIP.geometry.build(record): Model` where `Model = { rimType: 'rimmed'|'rebated'|'rimless'|'belted'|'rimfire', outer: Pt[] (r,z from axis at head face to mouth corner; arcs sampled), inner: Pt[]|null (from solid-head end to mouth inner corner), w, tb, tn, heeled, pocket: {d, depth}|null, bullet: {shape, s, zb, Lb, k, m, cylEnd, exposed: Pt[], seated: Pt[], full: Pt[]}, shoulder: {A: Pt, B: Pt, alpha: number(deg)}|null, features: {z0, grooveZ, rimMidZ...}, notes: string[], missing: string[] }` with `Pt = {r, z}`.

- [ ] Step 1: Tests (values worked from the brief, tolerance 1e-9 unless stated): `rimType`: 223→rimless, 9,3 x 74 R→rimmed, 300 Win. Mag.→belted, 22 Long Rifle→rimfire, 38 Special→rimmed, 9,3 x 62→rimless; first outer point `{0,0}`; 223 chamfer: second point `r = 9.6/2 - min(0.45*tan35°, 9.6/4)`, `z=0`, third `{r:4.8, z:0.45}`, fourth `{4.8, 1.14}`; groove points `(E1/2=4.215, 1.14)`, `(4.215, 1.9)`, `(P1/2=4.79, 3.13)`; shoulder `A={r:4.5,z:36.52}`, `B={r:3.215,z:39.55}`; arcs: a fillet of radius r1Min is tangent (the arc starts/ends on the body/shoulder lines); 9,3 x 74 R: no groove: points `(R1/2,R)` then `(P1/2,R)`, and `notes` has no entry about groove; 338 Lapua notes mention `r1 min`; 17 HMR notes mention `r1 min` and `r2`; 300 Win. Mag. belted: ramp end `z = R + eMin + (R3-E1)/2/tan(35°)`, belt to `z = 5.59`, step to `P1/2`; 22 LR half-round radius `min(R/2,(R1-P1)/2)` with outermost point at `r = R1/2`, no chamfer, no note about `f`; bullet: 223 pointy `s=5.7`, `zb=39`, `Lb=18.4`, cyl end `zb+0.4*Lb`, `m=1.27`, tangent ogive radius formula, tip point `(m/2, 57.4)`, arc passes `(G1/2, cylEnd)` with horizontal tangent; 9 mm Luger rounded pistol `s=0.4*9.03`, `m=0.15*G1`, ellipse end `(m/2, L6)`; 40 S.& W. flat `m=0.55*G1`; 357 Magnum semi_wadcutter `s=0.6*G1`, `m=0.6*G1`; 22 LR `heeled===true`, seated heel radius `(H2-2*tb)/2`, `tn===tb`; walls: 223 `tn=(6.43-5.7)/2`, `tb=0.6`; `w`: 223 `max(2.5, 0.25*P1/2, 3.04+1.5, E+tb)` = 4.54 (sr pocket 4.45×3.04) — compute per rule 8 in test; 22 LR `pocket===null`; 300 Win. Mag. `w=belt ramp end + tb` vs pocket `3.3+1.5=4.8` (take max, assert numerically); invariants over all 25: all coordinates finite, outer `z` non-decreasing, `inner.r < outer.r` at same z, bullet seated radius ≤ inner radius at its z (+1e-9) for bottleneck/straight, no NaN anywhere. Rule 9: delete `f` from a copy of 223 → no chamfer, note names `f`; delete `L2` → straight case + note names `L2`.
- [ ] Step 2: Run → FAIL.
- [ ] Step 3: Implement `build` and helpers (`fillet(prev, corner, next, radius)` returns tangent points + sampled arc, radius clamped so tangent length ≤ half the shorter segment). Straight cases: tb→tn linear over 2 mm ending at `zb`. Inner radius at z = outer radius(z) − t(z), t = tb up to L1, linear to tn at L2, then tn.
- [ ] Step 4: Tests pass.

### Task 5: Drawing (`js/drawing.js`)

**Interfaces:**
- Consumes: `CIP.geometry.build`, `CIP.format.number`, `CIP.format.angle`.
- Produces: `CIP.drawing.render(record, opts?: {id?: string}): {svg: string, width: number, height: number, labels: {id,text,x,y,w,h}[], obstacles: {x1,y1,x2,y2}[], scale: number, notes: string[]}`. `svg` has `role="img"`, `aria-label="<name> drawing"`, `<title>`, `viewBox` (1 unit = 1 mm), hatch `<pattern>`, class hooks `outline`, `section`, `dim`, `label`, `titleblock`.

- [ ] Step 1: Tests (parse the string with regexes; label list for geometry): 223 contains texts `L3 44.7`, `L6 57.4`, `L1 36.52`, `L2 39.55`, `R1 9.6`, `R 1.14`, `P1 9.58`, `P2 9`, `H1 6.43`, `H2 6.43`, `G1 5.7`, `E1 8.43`, `α 46°`; 308 Win. has `L3 51.18`; `7 x 64` has `α 40°25'44"`; 9 mm Luger has no `α`, `L1`, `P2`, `H1` labels but has `L3 19.15`; 338 Lapua draws without r1 min (`notes` mention). Title block texts: name, `C.I.P. table I`, `Revised 2017-05-17`, `Dimensions in mm`, `Scale`; `scale === 190/width` (rounded to 2 decimals in text). Over all 25 records: no two label boxes intersect; no label box intersects any outline/bullet/obstacle segment; every label inside viewBox; `svg` has no `NaN`/`undefined`; text is XML-escaped (`&amp;` for `40 S.& W.`); aria-label equals `<name> drawing`.
- [ ] Step 2: Run → FAIL.
- [ ] Step 3: Implement per the spec Layout paragraph: length rows above (R, L1, L2, L3, L6, nearest = smallest), diameter rows below (R1, E1, P1, P2, H1, H2, G1; nearest = largest z, label right of leader), α arc at shoulder start with label candidates (left-above first), title block at the bottom with minimum width 105, label width estimate `0.62·fontSize·chars`, font size 2.5, outline stroke 0.35, dimension stroke 0.18, arrow length 1.4. Hatch: `<pattern patternUnits="userSpaceOnUse">` at 45°.
- [ ] Step 4: Tests pass.

### Task 6: App shell (`index.html`, `css/style.css`, `js/app.js`)

**Interfaces:**
- Consumes: `CIP.model`, `CIP.drawing`, `CIP.data`.
- Produces: DOM behaviour from the spec; `<main id="app">`; list at `#/`, detail at `#/cartridge/<key>`; `hashchange` re-render; filter changes use `history.replaceState` to `#/?q=…&family=…`; title set to `<name> – Cartridges`; focus moved to `h1` on view change; notfound view with link "All cartridges".

- [ ] Step 1: Write `tests/e2e/app.spec.js` (Playwright test script run with plain `node`, see Task 7) checking via `file://`: h1 "Cartridges"; "25 cartridges"; Search `7,62 x 51` → "1 cartridges" and link "308 Win."; Family `pistol` → "6 cartridges"; click `6,5 Creedmoor` → h1, URL hash `#/cartridge/6_5_creedmoor`, reload keeps the view; `getByRole('img', {name: '6,5 Creedmoor drawing'})`; tables have columns Symbol/Value/Unit; "Print" button; link "All cartridges"; bad key → not found; Back restores list filter.
- [ ] Step 2: Write app (list as table Name/Family/L3 mm; detail: definition list of facts — alternative names, family, category, primer type, C.I.P. table, country, published, revised, pressure method, water capacity with link `rel="noopener noreferrer"` — then drawing, notes list, two groups "Cartridge values" and "Chamber values" with one `<table>` per section with `<caption>`, buttons). CSS: system font stack, `font-variant-numeric: tabular-nums`, variables for light/dark via `prefers-color-scheme`, dense tables, phone layout (tables scroll, filters stack). Drawing colours via CSS variables.
- [ ] Step 3: Run e2e; PASS.

### Task 7: Print and browser verification

**Files:** Modify `css/style.css` (`@media print`), create `tests/e2e/verify.js`.

- [ ] Step 1: `verify.js` (Playwright Chromium): for all 25 records via `file://`, `page.pdf({format:'A4'})` has exactly one page, `emulateMedia({media:'print'})` hides `nav, form, button`; footer text "Source: C.I.P. TDCC, revised <date>"; in screen mode measure every `svg text` `getBBox()` for overlaps with each other and with outline paths (`getBBox` of `.outline` polylines segments via `getPointAtLength` sampling); zero console errors/page errors; zero requests other than `file:`; `colorScheme: dark` computed background differs from light; 360px viewport has no horizontal page scroll; screenshots to `/tmp/shots`.
- [ ] Step 2: Adjust print CSS (3-column tables, 7.5pt, drawing 190 mm wide) until 25/25 are one page. Look at screenshots of at least 223 Rem., 300 Win. Mag., 22 Long Rifle, 9,3 x 74 R, 357 Magnum, and fix visual defects.
- [ ] Step 3: Also run the e2e against `python`-free static server (`node -e` http server) once.

### Task 8: Review

- [ ] Run `superpowers:requesting-code-review` / `/code-review` over the tree; fix real findings; run `npm test` and `verify.js` again (superpowers:verification-before-completion) before reporting.
