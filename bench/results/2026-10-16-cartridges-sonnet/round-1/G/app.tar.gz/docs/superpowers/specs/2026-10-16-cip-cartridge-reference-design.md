# C.I.P. cartridge reference — design

Status: derived from the user's brief (which is the approved description). This document records how the brief is
turned into a build and lists the calls made where the brief is silent. Calls are marked **[call]**.

## Intent

A static, offline reference of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on the OpenBallistics
cartridge database. Two views: a filterable list and a per-cartridge detail view with a dimensioned, to-scale 2D drawing
generated from the record's numbers, plus all cartridge and chamber values in tables. The detail view prints on one A4 page.

Anti-goals: invented numbers (missing values are reported, never guessed); runtime dependencies, network requests, a build step;
a drawing that looks plausible but is not computed from the record.

## Constraints (from the brief)

- Plain HTML/CSS/JS, `index.html` + CSS + JS files in the project root. Works from `file://` in Chromium and from any static server.
- Therefore: classic `<script>` files (no ES modules, no `fetch`), the 25 records embedded in `js/data.js` verbatim.
- Hash routing (`#/` list, `#/cartridge/<key>` detail) so every detail view has a bookmarkable address that survives reload on `file://`.
- Light/dark follow the system; print is always light.
- Dev tools only: `node:test` for unit tests, Playwright (dev dependency) for browser verification.

## Data and display rules

- Records are used as given. `key` is the route id. Numbers are displayed with JS `String(n)` (so `5.0` shows `5`, `4150.0` shows `4150`).
- Units: `Pmax PK PE` bar; `EE` J; `M` g; `Q` mm²; `N` none (empty unit cell); angles `alpha alpha1 beta delta i` degrees; everything else mm. **[call]** `Fe`, `deltaL`, `S`, `u`, `h`, `s`, `G`, `b`, `F`, `Z`, `E…` are lengths, so mm. The unit cell of an angle row is `°`.
- Angle: number → `40°`; object → `39°59'49"`. Tolerance `XTol` renders in the X value cell: `39.62 -0.2` (a positive tolerance is shown with `+`).
- Sections (cartridge: caseHead, collar, junctionCone, lengths, misc, powderChamber, pressures, projectile; chamber: barrel, breech, collar, grooves, junctionCone, lengths, powderChamber, rifling) become one table each, headed by a readable section name; empty sections are omitted. Rows follow record key order. **[call]**
- Water capacity: `annotations.publishedCapacity.grH2O` shown as `30.5 gr H2O` with the `source` as a link to `url` (and the `note` if any); `—` when not published. **[call: unit is grains of water]**
- Missing metadata (e.g. no alternative names) shows `—`.
- List: table of Name (link, text exactly the record name) / Family / L3 (mm). Search normalises case, whitespace and `.`/`,`, and matches name and each alternative name. Count text is literally `<n> cartridges` (also for 1). Filter state lives in the hash query on the list route so Back restores it. **[call]**

## Drawing

Geometry follows the brief's rules 1–9 exactly; a pure module `geometry.js` (no DOM) produces the outer half-profile as `(r, z)` points,
the inner wall profile, bullet outline, pocket, `w`, dimension features and a list of notes for values that are missing. A second pure module
`drawing.js` lays out the dimensions and returns an SVG string plus the layout objects (label boxes, lines) used by tests.

Calls made where the brief leaves room:

- Chamfer takes precedence over the rimfire half-round when beta and f are both published (never occurs in the data). A rimfire half-round is a semicircle whose chord is parallel to the axis (centre `(R1/2 - ρ, ρ)`); if `2ρ < R`, the rim continues straight to `z = R`.
- Where a rule's input is missing the feature is left out and the notes list under the drawing says which value is missing. No note for things that do not exist on that family by nature (extractor groove on rimmed and rimfire cases, chamfer on rimfire).
- Heeled cases: the neck wall `tn` becomes `tb` (otherwise zero thickness).
- Straight cases have no shoulder: the wall blends linearly from `tb` to `tn` over a 2 mm transition ending at the bullet base. **[call]**
- α is shown as the included angle: the shoulder flank and its mirror image about the axis direction, both through the shoulder start, with an arc between them, labelled `α 46°`, and a leader to the label placed above the body. The cone apex is not used because for shallow shoulders it lies outside the drawing.
- Layout: length dimensions (R, L1, L2, L3, L6) as stacked rows above the part, measured from the head face, extension lines never cross another dimension line; diameter dimensions (R1, E1, P1, P2, H1, H2, G1) as vertical lines through the part with a leader down to a label row below; labels are packed into as few rows as possible, leaders never cross labels, and the lines are at least 1 mm apart (P1 is dimensioned 0.6 mm into the body, P2 1.5 mm before the shoulder, H1/H2 1 mm inside the neck, R1/E1 inside their faces) so arrowheads never merge. The outside view also shows circular edges where the profile turns by 20° or more. Shoulder dimensions appear only when the shoulder is drawn. The title block sits below, with a minimum drawing width.
- Scale text: the drawing is laid out for A4 print width (190 mm), so the title block reads `Scale <190/viewBox width> : 1 (A4 print)`; the viewBox itself is 1 unit = 1 mm.
- Label text widths are estimated at 0.62 em per character for layout and verified against real `getBBox()` in Chromium.

## Print

`@page A4 portrait, 10 mm margins`; hides navigation, search, buttons; header (name), meta block, drawing full width, both value groups flowing in 4 CSS columns,
footer `Source: C.I.P. TDCC, revised <date>` in normal flow (so any overflow shows up as a second page). Verified: 1 page for every one of the 25 cartridges.

## Verification

Unit tests (`node:test`) for formatting, model, search, routing, geometry invariants for all 25 records, drawing layout (no label overlaps, label text).
Playwright against `file://` and a static server: list, search, filter, detail, reload, back, print PDF = 1 page, mobile viewport, dark mode, console clean, no network requests.

## Review fixes (after the independent review)

G1 and L6 are optional (without G1 the section walls, pocket and bullet are omitted and noted; without L6 the bullet is omitted). A bullet whose cylinder ends inside the case keeps its seated profile. Notes distinguish unpublished from unsupported bullet shape and a missing category.
