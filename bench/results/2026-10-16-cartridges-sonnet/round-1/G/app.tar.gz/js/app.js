// DOM layer: hash routing, list view, detail view.
(function () {
  const CIP = globalThis.CIP;
  const M = CIP.model;
  const F = CIP.format;
  const app = document.getElementById('app');

  function el(tag, attrs, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v === null || v === undefined) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat()) {
      if (c === null || c === undefined || c === false) continue;
      node.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return node;
  }

  // ---------- list ----------
  function renderList(route) {
    let q = route.q;
    let family = route.family;

    const tbody = el('tbody');
    const count = el('p', { id: 'count', class: 'count', role: 'status', 'aria-live': 'polite' });
    const search = el('input', { id: 'search', type: 'search', value: q, autocomplete: 'off', spellcheck: 'false' });
    const select = el('select', { id: 'family' }, M.FAMILIES.map((f) => el('option', { value: f, selected: f === family }, f)));

    function update() {
      const rows = M.filter(CIP.data, q, family);
      tbody.replaceChildren(...rows.map((r) => el('tr', {},
        el('td', { class: 'name' },
          el('a', { href: M.detailHash(r.key) }, r.name),
          r.alternativeNames && r.alternativeNames.length ? el('span', { class: 'alt' }, r.alternativeNames.join(', ')) : null),
        el('td', {}, r.family),
        el('td', { class: 'num' }, F.number(r.cartridge.lengths.L3)))));
      if (!rows.length) tbody.append(el('tr', { class: 'empty' }, el('td', { colspan: 3 }, 'No cartridge matches.')));
      count.textContent = `${rows.length} cartridges`;
    }

    function sync() {
      q = search.value;
      family = select.value;
      history.replaceState(null, '', M.listHash(q, family));
      update();
    }
    search.addEventListener('input', sync);
    select.addEventListener('change', sync);

    update();
    return el('section', { class: 'list-view' },
      el('h1', { tabindex: '-1' }, 'Cartridges'),
      el('form', { class: 'filters', onsubmit: (e) => e.preventDefault() },
        el('div', { class: 'field' }, el('label', { for: 'search' }, 'Search'), search),
        el('div', { class: 'field' }, el('label', { for: 'family' }, 'Family'), select)),
      count,
      el('div', { class: 'table-wrap' },
        el('table', { class: 'list' },
          el('thead', {}, el('tr', {}, el('th', { scope: 'col' }, 'Name'), el('th', { scope: 'col' }, 'Family'), el('th', { scope: 'col', class: 'num' }, 'L3 (mm)'))),
          tbody)));
  }

  // ---------- detail ----------
  function valueTable(section) {
    return el('table', { class: 'values' },
      el('caption', {}, section.title),
      el('thead', {}, el('tr', {}, el('th', { scope: 'col' }, 'Symbol'), el('th', { scope: 'col', class: 'num' }, 'Value'), el('th', { scope: 'col' }, 'Unit'))),
      el('tbody', {}, section.rows.map((r) => el('tr', {},
        el('td', { class: 'sym' }, r.symbol),
        el('td', { class: 'num' }, r.value, r.tol ? [' ', el('span', { class: 'tol' }, r.tol)] : null),
        el('td', { class: 'unit' }, r.unit)))));
  }

  function renderDetail(record) {
    const drawing = CIP.drawing.render(record);
    const figure = el('div', { class: 'figure' });
    figure.innerHTML = drawing.svg;

    const facts = M.facts(record).map((f) => el('div', { class: 'fact' },
      el('dt', {}, f.label),
      el('dd', {}, f.value,
        f.link ? [' · source ', el('a', { href: f.link.href, rel: 'noopener noreferrer' }, f.link.text)] : null,
        f.note ? el('span', { class: 'note' }, f.note) : null)));

    const group = (title, part) => el('section', { class: 'value-group' },
      el('h2', {}, title),
      el('div', { class: 'tables' }, M.sections(record, part).map(valueTable)));

    return el('article', { class: 'detail-view' },
      el('nav', { class: 'toolbar', 'aria-label': 'Cartridge actions' },
        el('a', { href: '#/' }, 'All cartridges'),
        el('button', { type: 'button', onclick: () => window.print() }, 'Print')),
      el('h1', { tabindex: '-1' }, record.name),
      el('dl', { class: 'facts' }, facts),
      el('section', { class: 'drawing' },
        el('h2', { class: 'visually-hidden' }, 'Drawing'),
        figure,
        drawing.notes.length ? el('div', { class: 'draw-notes' }, el('h3', {}, 'Drawing notes'), el('ul', {}, drawing.notes.map((n) => el('li', {}, n)))) : null),
      el('div', { class: 'values-all' }, group('Cartridge values', 'cartridge'), group('Chamber values', 'chamber')),
      el('p', { class: 'source' }, `Source: C.I.P. TDCC, revised ${record.revised}`));
  }

  function renderNotFound(route) {
    return el('section', { class: 'notfound' },
      el('h1', { tabindex: '-1' }, 'Not found'),
      el('p', {}, route.key ? `There is no cartridge or page “${route.key}”.` : 'There is nothing at this address.'),
      el('p', {}, el('a', { href: '#/' }, 'All cartridges')));
  }

  // ---------- router ----------
  let first = true;
  function route() {
    const r = M.parseHash(location.hash);
    let view, title = 'Cartridges';
    if (r.view === 'list') view = renderList(r);
    else if (r.view === 'detail') {
      const rec = CIP.data.find((c) => c.key === r.key);
      view = renderDetail(rec);
      title = `${rec.name} – Cartridges`;
    } else {
      view = renderNotFound(r);
      title = 'Not found – Cartridges';
    }
    app.replaceChildren(view);
    document.title = title;
    if (!first) {
      window.scrollTo(0, 0);
      const h1 = app.querySelector('h1');
      if (h1) h1.focus({ preventScroll: true });
    }
    first = false;
  }

  window.addEventListener('hashchange', route);
  route();
})();
