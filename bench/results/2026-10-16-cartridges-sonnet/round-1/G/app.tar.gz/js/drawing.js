// Dimensioned 2D drawing as an SVG string. 1 SVG user unit = 1 mm; axis horizontal, head on the left.
// Upper half: outside view (y = -r). Lower half: section (y = +r), cut walls hatched.
// render(record) -> { svg, width, height, scale, labels, lines, notes }
//   labels: text boxes {id, text, x, y, w, h}; lines: every drawn segment {kind, owner, x1, y1, x2, y2},
//   both in SVG user units, so tests can check that labels never overlap each other or any line.
(function () {
  const CIP = (globalThis.CIP = globalThis.CIP || {});
  const F = CIP.format;

  const FS = 2.8; // label font size
  const FS_NAME = 3.8; // title block name
  const PITCH = 4.8; // distance between dimension rows
  const ARROW = 1.4;
  const ARROW_W = 0.45;
  const GAP = 1.0; // extension line gap to the outline
  const OVER = 1.5; // extension line overshoot past the dimension line
  const MIN_W = 106;
  const PRINT_W = 190; // A4 portrait width inside 10 mm margins
  const MARGIN = 2;
  const TB_ROW = 6.2;
  const W_OUTLINE = 0.35;
  const W_DIM = 0.18;

  const tw = (s, fs = FS) => s.length * 0.62 * fs;
  const fmt = (x) => String(+x.toFixed(3));
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const has = (x) => x !== undefined && x !== null;

  function render(record) {
    const m = CIP.geometry.build(record);
    const name = record.name;
    const uid = 'hatch-' + String(record.key || 'x').replace(/[^\w-]/g, '_');
    const lines = [];
    const labels = [];
    const parts = { section: [], bullet: [], outline: [], centre: [], dims: [], text: [], title: [] };

    const addLine = (kind, owner, x1, y1, x2, y2, cls, extra = '') => {
      lines.push({ kind, owner, x1, y1, x2, y2 });
      parts.dims.push(`<line class="${cls}" data-owner="${esc(owner)}" x1="${fmt(x1)}" y1="${fmt(y1)}" x2="${fmt(x2)}" y2="${fmt(y2)}"${extra}/>`);
    };
    const polyPath = (pts, owner, kind = 'outline') => {
      for (let i = 1; i < pts.length; i++) lines.push({ kind, owner, x1: pts[i - 1].x, y1: pts[i - 1].y, x2: pts[i].x, y2: pts[i].y });
      return 'M' + pts.map((p) => `${fmt(p.x)} ${fmt(p.y)}`).join(' L');
    };
    const arrow = (tx, ty, dx, dy) => {
      // filled head with its tip at (tx, ty), pointing along (dx, dy)
      const bx = tx - dx * ARROW, by = ty - dy * ARROW;
      const px = -dy * ARROW_W, py = dx * ARROW_W;
      parts.dims.push(`<polygon class="arrow" points="${fmt(tx)},${fmt(ty)} ${fmt(bx + px)},${fmt(by + py)} ${fmt(bx - px)},${fmt(by - py)}"/>`);
    };
    const addLabel = (id, text, x, baselineY, anchor, fs = FS, cls = 'label') => {
      const w = tw(text, fs);
      const bx = anchor === 'end' ? x - w : anchor === 'middle' ? x - w / 2 : x;
      labels.push({ id, text, x: bx, y: baselineY - 0.8 * fs, w, h: fs });
      parts.text.push(`<text class="${cls}" data-id="${esc(id)}" x="${fmt(x)}" y="${fmt(baselineY)}" text-anchor="${anchor}" font-size="${fmt(fs)}">${esc(text)}</text>`);
    };

    if (!m.ok) {
      const note = m.notes.join(' ');
      const w = Math.max(MIN_W, tw(note) + 4), h = 30;
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" class="cip-drawing" role="img" aria-label="${esc(name)} drawing" viewBox="0 0 ${w} ${h}"><title>${esc(name)} drawing</title><text x="2" y="12" font-size="${FS}" fill="currentColor">${esc(note)}</text></svg>`;
      return { svg, width: w, height: h, scale: PRINT_W / w, labels, lines, notes: m.notes };
    }

    const { v, outer, inner, bullet } = m;
    const X = (z) => z;
    const up = (p) => ({ x: X(p.z), y: -p.r });
    const down = (p) => ({ x: X(p.z), y: p.r });
    const rmax = m.rmax;
    const L3 = v.L3, L6 = v.L6;

    // ---------------- section (lower half) ----------------
    const lower = [];
    if (!inner) lower.push(...outer);
    else if (m.pocket) lower.push({ r: 0, z: m.pocket.depth }, { r: m.pocket.d / 2, z: m.pocket.depth }, { r: m.pocket.d / 2, z: 0 });
    else lower.push({ r: 0, z: 0 });
    if (inner) {
      lower.push(...outer.slice(1));
      lower.push(...inner.slice().reverse());
      lower.push({ r: 0, z: m.w });
    }
    const lowerXY = lower.map(down);
    // hatched cut walls (filled, closed along the axis) and the contour (open: no stroke along the axis)
    if (inner) parts.section.push(`<path class="cut" d="M${lowerXY.map((p) => `${fmt(p.x)} ${fmt(p.y)}`).join(' L')} Z" fill="url(#${uid})" stroke="none"/>`);
    parts.outline.push(`<path class="contour" d="${polyPath(lowerXY, 'section')}"/>`);

    // ---------------- outside view (upper half) ----------------
    const upperXY = outer.map(up);
    if (bullet) upperXY.push({ x: L3, y: -bullet.exposed[0].r });
    else if (inner) upperXY.push({ x: L3, y: -inner[inner.length - 1].r });
    parts.outline.push(`<path class="contour" d="${polyPath(upperXY, 'outside')}"/>`);

    // circular edges seen from outside: wherever the profile turns by 20 degrees or more, and at the mouth
    {
      const edges = new Map();
      const put = (z, r) => { const key = z.toFixed(6); edges.set(key, Math.max(edges.get(key) || 0, r)); };
      for (let i = 1; i < outer.length - 1; i++) {
        const a = Math.atan2(outer[i].r - outer[i - 1].r, outer[i].z - outer[i - 1].z);
        const b = Math.atan2(outer[i + 1].r - outer[i].r, outer[i + 1].z - outer[i].z);
        let turn = Math.abs(b - a);
        if (turn > Math.PI) turn = 2 * Math.PI - turn;
        if (turn >= Math.PI / 9 && outer[i].z > 1e-9) put(outer[i].z, outer[i].r);
      }
      put(L3, v.H2 / 2);
      for (const [key, r] of edges) addLine('edge', 'edge', +key, -r, +key, 0, 'edge');
    }

    // ---------------- bullet ----------------
    if (bullet) {
      const ex = bullet.exposed.map(up);
      const exFill = [{ x: L3, y: 0 }, ...ex, { x: L6, y: 0 }];
      parts.bullet.push(`<path class="bullet" d="M${exFill.map((p) => `${fmt(p.x)} ${fmt(p.y)}`).join(' L')} Z" stroke="none"/>`);
      parts.outline.push(`<path class="contour" d="${polyPath([...ex, { x: L6, y: 0 }], 'bullet-outside')}"/>`);
      const sec = bullet.section.map(down);
      parts.bullet.push(`<path class="bullet" d="M${sec.map((p) => `${fmt(p.x)} ${fmt(p.y)}`).join(' L')} Z" stroke="none"/>`);
      parts.outline.push(`<path class="contour" d="${polyPath(sec, 'bullet-section')}"/>`);
    }

    // ---------------- centre line ----------------
    const cEnd = (bullet ? L6 : L3) + 3;
    lines.push({ kind: 'centre', owner: 'centre', x1: -3, y1: 0, x2: cEnd, y2: 0 });
    parts.centre.push(`<line class="centre" x1="-3" y1="0" x2="${fmt(cEnd)}" y2="0" stroke-dasharray="5 1 1 1"/>`);

    // ---------------- dimension items ----------------
    const outerRAt = (z) => {
      // largest outline radius at z (handles vertical steps)
      let best = 0;
      for (let i = 1; i < outer.length; i++) {
        const a = outer[i - 1], b = outer[i];
        if (z < Math.min(a.z, b.z) - 1e-9 || z > Math.max(a.z, b.z) + 1e-9) continue;
        const r = b.z - a.z < 1e-9 ? Math.max(a.r, b.r) : a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
        best = Math.max(best, r);
      }
      return best;
    };

    // length dimensions, measured from the head face, stacked above the part
    const lengthItems = [];
    if (has(v.R)) lengthItems.push({ id: 'R', sym: 'R', value: v.R, z: v.R, r: m.anchors.rimBack.r });
    if (m.shoulder) lengthItems.push({ id: 'L1', sym: 'L1', value: v.L1, z: v.L1, r: m.shoulder.A.r });
    if (m.shoulder) lengthItems.push({ id: 'L2', sym: 'L2', value: v.L2, z: v.L2, r: m.shoulder.B.r });
    lengthItems.push({ id: 'L3', sym: 'L3', value: L3, z: L3, r: v.H2 / 2 });
    if (bullet && has(v.L6)) lengthItems.push({ id: 'L6', sym: 'L6', value: v.L6, z: v.L6, r: bullet.m / 2 });
    lengthItems.sort((a, b) => a.z - b.z);

    // diameter dimensions: vertical lines through the part with a leader down to a label row
    const diaItems = [];
    const fe = m.features;
    diaItems.push({ id: 'R1', sym: 'R1', value: v.R1, z: fe.zR1, r: v.R1 / 2 });
    if (m.hasGroove) diaItems.push({ id: 'E1', sym: 'E1', value: v.E1, z: fe.zE1, r: v.E1 / 2 });
    diaItems.push({ id: 'P1', sym: 'P1', value: v.P1, z: fe.zP1, r: m.outerAt(fe.zP1) });
    if (m.shoulder) {
      diaItems.push({ id: 'P2', sym: 'P2', value: v.P2, z: fe.zP2, r: m.outerAt(fe.zP2) });
      diaItems.push({ id: 'H1', sym: 'H1', value: v.H1, z: fe.zH1, r: m.outerAt(fe.zH1) });
    }
    diaItems.push({ id: 'H2', sym: 'H2', value: v.H2, z: fe.zH2, r: m.outerAt(fe.zH2) });
    if (bullet) diaItems.push({ id: 'G1', sym: 'G1', value: v.G1, z: fe.zG1, r: bullet.rEx });
    diaItems.sort((a, b) => b.z - a.z); // nearest row = largest z, so leaders never cross a label

    let alphaInfo = null;
    // shoulder angle marker and its label (placed first: it sets how high the length rows start)
    let alpha = null;
    const extXs = [0, ...lengthItems.map((i) => i.z)];
    if (m.shoulder && has(m.alphaRaw)) {
      const { A, B } = m.shoulder;
      const theta = (m.shoulder.alpha / 2) * (Math.PI / 180);
      const rho = Math.min(0.8 * Math.hypot(B.z - A.z, B.r - A.r), 5);
      const text = 'α ' + F.angle(m.alphaRaw);
      const w = tw(text);
      let box = null;
      for (let k = 0; k < 14 && !box; k++) {
        const xr = A.z - 1.5 - k * 2, xl = xr - w;
        if (xl < 1) break;
        if (extXs.some((x) => x > xl - 0.4 && x < xr + 0.4)) continue;
        let maxR = 0;
        for (let z = xl - 0.5; z <= xr + 0.5; z += 0.25) maxR = Math.max(maxR, outerRAt(z));
        box = { xl, xr, yb: -(maxR + 1.2) };
      }
      if (!box) {
        let maxR = 0;
        for (let z = A.z - 1.5 - w - 0.5; z <= A.z; z += 0.25) maxR = Math.max(maxR, outerRAt(z));
        box = { xl: A.z - 1.5 - w, xr: A.z - 1.5, yb: -(maxR + 1.2) };
      }
      alpha = { A, theta, rho, text, w, box };
    }

    // pack the diameter labels into as few rows as possible. Items go from the largest z down, so a leader
    // never crosses a label in a nearer row; a label also must not contain the leader of an item in a farther row.
    const placedDia = [];
    for (const it of diaItems) {
      it.text = `${it.sym} ${F.number(it.value)}`;
      it.lx0 = X(it.z) + 0.9;
      it.lx1 = it.lx0 + tw(it.text);
      let row = 0;
      while (placedDia.some((p) => (p.row === row && p.lx0 < it.lx1 + 0.8 && it.lx0 < p.lx1 + 0.8)
        || (p.row > row && X(p.z) > it.lx0 - 0.4 && X(p.z) < it.lx1 + 0.4))) row++;
      it.row = row;
      placedDia.push(it);
    }
    const diaRows = diaItems.reduce((n, it) => Math.max(n, it.row + 1), 1);

    const topBase = Math.max(rmax, alpha ? -alpha.box.yb + FS + 0.5 : 0) + 3.5;
    const rowTop = (i) => -(topBase + i * PITCH);
    const botBase = rmax + 3.5;
    const rowBot = (j) => botBase + j * PITCH;

    // ---- length rows
    const headTop = m.anchors.head;
    lengthItems.forEach((it, i) => {
      const y = rowTop(i);
      const text = `${it.sym} ${F.number(it.value)}`;
      const span = it.z;
      const inside = span >= tw(text) + 1; // the label sits above the line, so only the text must fit
      const tiny = span < 2 * ARROW + 0.6;
      // extension line at the feature
      addLine('ext', it.id, it.z, -(it.r + GAP), it.z, y - OVER, 'ext');
      if (tiny) {
        addLine('dim', it.id, -ARROW - 0.8, y, it.z + ARROW + 0.8, y, 'dim');
        arrow(0, y, 1, 0);
        arrow(it.z, y, -1, 0);
      } else {
        addLine('dim', it.id, 0, y, it.z, y, 'dim');
        arrow(0, y, -1, 0);
        arrow(it.z, y, 1, 0);
      }
      if (inside) addLabel(it.id, text, it.z / 2, y - 0.9, 'middle');
      else addLabel(it.id, text, it.z + (tiny ? ARROW + 0.8 : 0) + 1, y - 0.9, 'start');
    });
    if (lengthItems.length) {
      const yTop = rowTop(lengthItems.length - 1);
      addLine('ext', 'L0', 0, -(headTop.r + GAP), 0, yTop - OVER, 'ext');
    }

    // ---- diameter rows
    diaItems.forEach((it) => {
      const y = rowBot(it.row);
      const x = X(it.z);
      const span = 2 * it.r;
      const head = Math.min(ARROW, span / 3);
      addLine('dim', it.id, x, -it.r, x, y, 'dim');
      parts.dims.push(`<polygon class="arrow" points="${fmt(x)},${fmt(-it.r)} ${fmt(x - ARROW_W)},${fmt(-it.r + head)} ${fmt(x + ARROW_W)},${fmt(-it.r + head)}"/>`);
      parts.dims.push(`<polygon class="arrow" points="${fmt(x)},${fmt(it.r)} ${fmt(x - ARROW_W)},${fmt(it.r - head)} ${fmt(x + ARROW_W)},${fmt(it.r - head)}"/>`);
      addLabel(it.id, it.text, x + 0.9, y + 0.3 * FS, 'start');
    });

    // ---- shoulder angle marker
    if (alpha) {
      // the included angle: the shoulder flank and its mirror image about the axis direction, both through A
      const { A, theta, rho, text, box } = alpha;
      const ax = A.z, ay = -A.r;
      const reach = rho + 1.5;
      addLine('ref', 'alpha', ax, ay, ax + reach * Math.cos(theta), ay - reach * Math.sin(theta), 'dim');
      const ex = ax + rho * Math.cos(theta);
      lines.push({ kind: 'ref', owner: 'alpha', x1: ex, y1: ay - rho * Math.sin(theta), x2: ex, y2: ay + rho * Math.sin(theta) });
      parts.dims.push(`<path class="dim" d="M${fmt(ex)} ${fmt(ay - rho * Math.sin(theta))} A${fmt(rho)} ${fmt(rho)} 0 0 1 ${fmt(ex)} ${fmt(ay + rho * Math.sin(theta))}" fill="none"/>`);
      addLine('leader', 'alpha', box.xr - 0.2, box.yb + 0.1, ax + rho, ay, 'dim');
      alphaInfo = { x: ax, y: ay, included: m.shoulder.alpha, rho };
      addLabel('alpha', text, box.xl, box.yb - 0.2 * FS, 'start');
    }

    // ---------------- extents and title block ----------------
    const xmin = -(ARROW + 3);
    let xmax = (bullet ? L6 : L3) + 3;
    for (const l of labels) xmax = Math.max(xmax, l.x + l.w + 2);
    const ymin = rowTop(Math.max(lengthItems.length, 1) - 1) - FS - 1.5;
    const ymaxDims = rowBot(diaRows - 1) + FS;

    const revised = `Revised ${record.revised}`;
    const table = `C.I.P. table ${record.tab}`;
    const titleNeed = tw(name, FS_NAME) + tw(table) + tw(revised) + 14;
    const width = Math.max(xmax - xmin, MIN_W, titleNeed + 2 * MARGIN);
    xmax = xmin + width;
    const scale = PRINT_W / width;
    const tbTop = ymaxDims + 3;
    const tbBottom = tbTop + 2 * TB_ROW;
    const x0 = xmin + MARGIN / 2, x1 = xmax - MARGIN / 2;
    parts.title.push(`<rect class="frame" x="${fmt(x0)}" y="${fmt(tbTop)}" width="${fmt(x1 - x0)}" height="${fmt(2 * TB_ROW)}"/>`);
    parts.title.push(`<line class="frame" x1="${fmt(x0)}" y1="${fmt(tbTop + TB_ROW)}" x2="${fmt(x1)}" y2="${fmt(tbTop + TB_ROW)}"/>`);
    const base1 = tbTop + TB_ROW - 1.9, base2 = tbBottom - 1.9;
    addLabel('title:name', name, x0 + 1.5, base1, 'start', FS_NAME, 'label name');
    addLabel('title:revised', revised, x1 - 1.5, base1, 'end', FS, 'label');
    addLabel('title:table', table, x1 - 1.5 - tw(revised) - 5, base1, 'end', FS, 'label');
    addLabel('title:units', 'Dimensions in mm', x0 + 1.5, base2, 'start', FS, 'label');
    addLabel('title:scale', `Scale ${scale.toFixed(2)} : 1 (A4 print)`, x1 - 1.5, base2, 'end', FS, 'label');
    const height = tbBottom + MARGIN - ymin;

    const alt = [`${name} drawing.`, `Rim type ${m.rimType}.`, `Case length L3 ${F.number(L3)} mm, overall length L6 ${F.number(L6)} mm.`].join(' ');
    const svg = [
      `<svg xmlns="http://www.w3.org/2000/svg" class="cip-drawing" role="img" aria-label="${esc(name)} drawing" viewBox="${fmt(xmin)} ${fmt(ymin)} ${fmt(width)} ${fmt(height)}" data-rim-type="${m.rimType}" data-scale="${scale.toFixed(2)}" fill="none" stroke="currentColor" stroke-width="${W_DIM}" font-family="inherit">`,
      `<title>${esc(name)} drawing</title><desc>${esc(alt)}</desc>`,
      `<defs><pattern id="${uid}" patternUnits="userSpaceOnUse" width="0.9" height="0.9" patternTransform="rotate(45)"><line x1="0.45" y1="0" x2="0.45" y2="0.9" stroke="currentColor" stroke-width="0.22"/></pattern></defs>`,
      `<g class="section" stroke-width="${W_OUTLINE}">${parts.section.join('')}</g>`,
      `<g class="bullets" fill="currentColor" fill-opacity="0.16">${parts.bullet.join('')}</g>`,
      `<g class="outline" stroke-width="${W_OUTLINE}" stroke-linejoin="round" stroke-linecap="round">${parts.outline.join('')}</g>`,
      `<g class="centreline" stroke-width="${W_DIM}">${parts.centre.join('')}</g>`,
      `<g class="dims" stroke-width="${W_DIM}">${parts.dims.join('')}</g>`,
      `<g class="labels" fill="currentColor" stroke="none">${parts.text.join('')}</g>`,
      `<g class="titleblock" stroke-width="${W_DIM}">${parts.title.join('')}</g>`,
      '</svg>',
    ].join('');

    return { svg, width, height, scale, labels, lines, notes: m.notes, model: m, alpha: alphaInfo, dims: diaItems.map((q) => ({ id: q.id, x: X(q.z) })) };
  }

  CIP.drawing = { render };
})();
