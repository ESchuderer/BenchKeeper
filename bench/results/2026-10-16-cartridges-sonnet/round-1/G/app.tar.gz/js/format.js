// Number, angle, unit and symbol formatting for the published values.
(function () {
  const CIP = (globalThis.CIP = globalThis.CIP || {});

  const ANGLE_FIELDS = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
  };

  function isAngle(field) {
    return ANGLE_FIELDS.has(field);
  }

  function number(n) {
    return String(n);
  }

  function angle(a) {
    if (typeof a === 'number') return number(a) + '°';
    return `${number(a.degrees)}°${number(a.minutes)}'${number(a.seconds)}"`;
  }

  function unitOf(field) {
    if (isAngle(field)) return '°';
    return Object.hasOwn(UNITS, field) ? UNITS[field] : 'mm';
  }

  function symbolOf(field) {
    return Object.hasOwn(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  CIP.format = { number, angle, unitOf, symbolOf, isAngle };
})();
