// Cartridge geometry computed from a record, following the brief's rules 1-9. Pure (no DOM).
// Points are {r, z}: r = radius (half the diameter), z = distance along the axis from the head face.
(function () {
  const CIP = (globalThis.CIP = globalThis.CIP || {});

  const EPS = 1e-9;
  const REQUIRED = ['R', 'R1', 'P1', 'H2', 'L3'];
  const DIM_OFFSET = 0.6; // P1 is dimensioned this far into the body so its arrowheads clear R1 and E1
  const PRIMERS = {
    sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04],
    lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3],
  };
  const STRAIGHT_TRANSITION = 2; // mm over which a straight case's wall changes from tb to tn
  const NOSE_STEPS = 28;
  const ARC_STEPS = 12;

  const deg = (a) => (a === undefined || a === null ? undefined : typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  const rad = (d) => (d * Math.PI) / 180;
  const has = (x) => x !== undefined && x !== null;

  function pushPt(pts, r, z) {
    const l = pts[pts.length - 1];
    if (l && Math.abs(l.r - r) < EPS && Math.abs(l.z - z) < EPS) return;
    pts.push({ r, z });
  }

  // Round the corner `c` between p0 and p1 with a tangent arc of radius rho (clamped so each
  // tangent length stays within half of its segment). Returns points from tangent 1 to tangent 2.
  function fillet(p0, c, p1, rho, steps = ARC_STEPS) {
    const unit = (x, y) => { const d = Math.hypot(x, y); return { x: x / d, y: y / d, d }; };
    const v1 = unit(p0.z - c.z, p0.r - c.r);
    const v2 = unit(p1.z - c.z, p1.r - c.r);
    const cos = Math.max(-1, Math.min(1, v1.x * v2.x + v1.y * v2.y));
    const theta = Math.acos(cos);
    if (theta > Math.PI - 1e-9 || theta < 1e-9 || !(rho > 0)) return [{ r: c.r, z: c.z }];
    const tanHalf = Math.tan(theta / 2);
    let t = rho / tanHalf;
    const tMax = 0.5 * Math.min(v1.d, v2.d);
    if (t > tMax) { t = tMax; rho = t * tanHalf; }
    const bis = unit(v1.x + v2.x, v1.y + v2.y);
    const dist = rho / Math.sin(theta / 2);
    const cx = c.z + bis.x * dist, cy = c.r + bis.y * dist;
    const t1 = { x: c.z + v1.x * t, y: c.r + v1.y * t };
    const t2 = { x: c.z + v2.x * t, y: c.r + v2.y * t };
    const a1 = Math.atan2(t1.y - cy, t1.x - cx);
    let d = Math.atan2(t2.y - cy, t2.x - cx) - a1;
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d <= -Math.PI) d += 2 * Math.PI;
    const out = [];
    for (let i = 0; i <= steps; i++) {
      const a = a1 + (d * i) / steps;
      out.push({ r: cy + rho * Math.sin(a), z: cx + rho * Math.cos(a) });
    }
    return out;
  }

  function rimTypeOf(family, R1, P1) {
    if (family === 'belted') return 'belted';
    if (family === 'rimfire') return 'rimfire';
    const q = R1 / P1;
    return q >= 1.05 ? 'rimmed' : q < 0.98 ? 'rebated' : 'rimless';
  }

  function interp(pts, z) {
    if (z <= pts[0].z) return pts[0].r;
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i];
      if (z <= b.z) return b.z - a.z < EPS ? b.r : a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
    }
    return pts[pts.length - 1].r;
  }

  // Returns {bullet} or {note} when the bullet cannot be drawn.
  function bulletModel(v, category, shape, heeled, tb) {
    const { G1, H2, L3, L6 } = v;
    if (!has(G1) || !has(L6)) return { note: `Bullet not drawn: ${[!has(G1) && 'G1', !has(L6) && 'L6'].filter(Boolean).join(', ')} not published.` };
    if (!has(category)) return { note: 'Bullet not drawn: cartridge category not published (needed for the seating depth).' };
    const pistol = category === 'pistol';
    const table = {
      pointy: { s: 1.0, k: 0.4, m: Math.max(0.08 * G1, 1.27) },
      rounded: { s: pistol ? 0.4 : 0.8, k: pistol ? 0.65 : 0.55, m: 0.15 * G1 },
      flat: { s: pistol ? 0.4 : 0.8, k: pistol ? 0.7 : 0.6, m: 0.55 * G1 },
      semi_wadcutter: { s: 0.6, k: 0.78, m: 0.6 * G1 },
    };
    const t = table[shape];
    if (!t) return { note: has(shape) ? `Bullet not drawn: bullet shape "${shape}" is not supported.` : 'Bullet not drawn: bullet shape not published.' };
    const s = t.s * G1, k = t.k, m = t.m;
    const zb = L3 - s, Lb = L6 - zb, cylEnd = zb + k * Lb, n = L6 - cylEnd;
    const rEx = (heeled ? H2 : G1) / 2;
    const seatR = heeled ? (H2 - 2 * tb) / 2 : G1 / 2;
    const d = rEx - m / 2;
    const rho = shape === 'pointy' && d > 0 ? (d * d + n * n) / (2 * d) : null;

    const noseR = (theta) => {
      const dz = n * Math.sin(theta);
      if (shape === 'pointy' && rho) return rEx - rho + Math.sqrt(Math.max(0, rho * rho - dz * dz));
      if (shape === 'rounded') return m / 2 + d * Math.cos(theta);
      return rEx - d * (dz / n); // straight cone
    };
    // the whole nose, from the end of the cylinder to the tip
    const nose = [];
    for (let i = 0; i <= NOSE_STEPS; i++) {
      const th = ((Math.PI / 2) * i) / NOSE_STEPS;
      if (i === NOSE_STEPS) pushPt(nose, m / 2, L6);
      else pushPt(nose, noseR(th), cylEnd + n * Math.sin(th));
    }

    const exposed = [];
    if (cylEnd >= L3) {
      pushPt(exposed, rEx, L3);
      for (const p of nose) pushPt(exposed, p.r, p.z);
    } else {
      const i = nose.findIndex((p) => p.z > L3);
      const a = nose[i - 1], b = nose[i];
      pushPt(exposed, a.r + ((b.r - a.r) * (L3 - a.z)) / (b.z - a.z), L3);
      for (const p of nose.slice(i)) pushPt(exposed, p.r, p.z);
    }
    const section = [{ r: 0, z: zb }, { r: seatR, z: zb }];
    if (heeled) {
      section.push({ r: seatR, z: L3 }, ...exposed);
    } else {
      for (const p of [{ r: rEx, z: zb }, ...nose]) pushPt(section, p.r, p.z);
    }
    section.push({ r: 0, z: L6 });
    return { shape, s, zb, Lb, k, cylEnd, n, m, rho, rEx, seatR, heel: heeled, exposed, section };
  }

  function build(record) {
    const c = record.cartridge || {};
    const head = c.caseHead || {}, collar = c.collar || {}, cone = c.junctionCone || {}, len = c.lengths || {};
    const pc = c.powderChamber || {}, proj = c.projectile || {};
    const ann = record.annotations || {};
    const v = {
      R: head.R, R1: head.R1, E: head.E, E1: head.E1, eMin: head.eMin, f: head.f, R3: head.R3,
      beta: deg(head.beta), delta: deg(head.delta), H1: collar.H1, H2: collar.H2,
      alpha: deg(cone.alpha), r1Min: cone.r1Min, r2: cone.r2,
      L1: len.L1, L2: len.L2, L3: len.L3, L6: len.L6, P1: pc.P1, P2: pc.P2, G1: proj.G1,
    };
    const notes = [];
    const rimType = rimTypeOf(record.family, v.R1, v.P1);
    const missingReq = REQUIRED.filter((k) => !has(v[k]));
    if (missingReq.length) {
      notes.push(`Drawing not possible: ${missingReq.join(', ')} not published.`);
      return { ok: false, rimType, v, notes, outer: [], inner: [], bullet: null, shoulder: null };
    }
    const { R, R1, E, E1, eMin, f, R3, H1, H2, P1, P2, G1, L1, L2, L3 } = v;
    const miss = (names) => names.filter((k) => !has(v[k]));

    // --- outer half-profile --------------------------------------------------------------
    const outer = [{ r: 0, z: 0 }];
    const chamfer = has(v.beta) && has(f) && v.beta < 90;
    let rimBack;
    let zR1;
    if (chamfer) {
      const cut = Math.min(f * Math.tan(rad(v.beta)), R1 / 4);
      pushPt(outer, R1 / 2 - cut, 0);
      pushPt(outer, R1 / 2, f);
      pushPt(outer, R1 / 2, R);
      rimBack = { r: R1 / 2, z: R };
      zR1 = (f + R) / 2;
    } else if (rimType === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      const cr = R1 / 2 - rho;
      const steps = 16;
      for (let i = 0; i <= steps; i++) {
        const t = -Math.PI / 2 + (Math.PI * i) / steps;
        pushPt(outer, cr + rho * Math.cos(t), rho + rho * Math.sin(t));
      }
      pushPt(outer, cr, R);
      rimBack = { r: cr, z: R };
      zR1 = rho;
    } else {
      pushPt(outer, R1 / 2, 0);
      pushPt(outer, R1 / 2, R);
      rimBack = { r: R1 / 2, z: R };
      zR1 = R / 2;
      if (!has(v.beta) || !has(f)) {
        notes.push(`Head chamfer not drawn: ${miss(['beta', 'f']).map((k) => (k === 'beta' ? 'β' : k)).join(', ')} not published.`);
      }
    }

    // --- extractor groove / belt ---------------------------------------------------------
    let hasGroove = has(E) && has(E1) && has(eMin);
    const grooveExpected = rimType === 'rimless' || rimType === 'rebated' || rimType === 'belted';
    if (!hasGroove) {
      const missing = miss(['E', 'E1', 'eMin']);
      if (missing.length < 3 || grooveExpected) {
        notes.push(`Extractor groove not drawn: ${missing.map((k) => (k === 'eMin' ? 'e min' : k)).join(', ')} not published.`);
      }
    }
    let z0, beltRampEnd = null, zE1 = null;
    if (hasGroove) {
      pushPt(outer, E1 / 2, R);
      pushPt(outer, E1 / 2, R + eMin);
      zE1 = R + eMin / 2;
      const belt = rimType === 'belted' && has(v.delta) && has(R3);
      if (rimType === 'belted' && !belt) {
        notes.push(`Belt not drawn: ${miss(['delta', 'R3']).map((k) => (k === 'delta' ? 'δ' : k)).join(', ')} not published.`);
      }
      if (belt) {
        beltRampEnd = R + eMin + (R3 / 2 - E1 / 2) / Math.tan(rad(v.delta));
        pushPt(outer, R3 / 2, beltRampEnd);
        pushPt(outer, R3 / 2, E);
        pushPt(outer, P1 / 2, E);
      } else {
        pushPt(outer, P1 / 2, E);
      }
      z0 = E;
    } else {
      pushPt(outer, P1 / 2, R);
      z0 = R;
    }
    const bodyStart = outer.length - 1;

    // --- body, shoulder, neck ------------------------------------------------------------
    const shoulderNeeds = ['alpha', 'L1', 'L2', 'P2', 'H1'];
    const shoulderMissing = miss(shoulderNeeds);
    const bottleneck = shoulderMissing.length === 0;
    let shoulder = null;
    const bodyPt = { r: P1 / 2, z: z0 };
    const mouth = { r: H2 / 2, z: L3 };
    if (bottleneck) {
      const A = { r: P2 / 2, z: L1 }, B = { r: H1 / 2, z: L2 };
      shoulder = { A, B, alpha: v.alpha };
      if (has(v.r1Min)) outer.push(...fillet(bodyPt, A, B, v.r1Min));
      else { outer.push(A); notes.push('Shoulder body-side corner not rounded: r1 min not published.'); }
      if (has(v.r2)) outer.push(...fillet(A, B, mouth, v.r2));
      else { outer.push(B); notes.push('Shoulder neck-side corner not rounded: r2 not published.'); }
    } else if (shoulderMissing.length < shoulderNeeds.length) {
      notes.push(`Drawn as a straight case: ${shoulderMissing.map((k) => (k === 'alpha' ? 'α' : k)).join(', ')} not published.`);
    }
    pushPt(outer, mouth.r, mouth.z);

    const bodyPts = outer.slice(bodyStart);
    const outerAt = (z) => interp(bodyPts, Math.max(z, z0));

    // --- walls, bullet, primer pocket, solid head, inner profile ---------------------------
    let tb = null, tn = null, heeled = false, bullet = null, pocket = null, w = null, inner = null, innerAt = null;
    if (has(G1)) {
      heeled = H2 - G1 <= 0.015;
      tn = (H2 - G1) / 2;
      tb = Math.min(Math.max(1.3 * (heeled ? 0 : tn), 0.6), (0.35 * P1) / 2);
      if (heeled) tn = tb;
    }
    const made = bulletModel(v, ann.category, ann.defaultBulletShape, heeled, tb);
    if (made.note) notes.push(made.note); else bullet = made;

    if (has(G1)) {
      if (rimType !== 'rimfire' && ann.primerType !== 'rimfire') {
        const p = PRIMERS[ann.primerType];
        if (p) pocket = { d: p[0], depth: p[1] };
        else notes.push('Primer pocket not drawn: primer type not published.');
      }
      const wCandidates = [2.5, (0.25 * P1) / 2];
      if (pocket) wCandidates.push(pocket.depth + 1.5);
      if (beltRampEnd !== null) wCandidates.push(beltRampEnd + tb);
      else if (hasGroove) wCandidates.push(E + tb);
      w = Math.max(...wCandidates);

      const zb = bullet ? bullet.zb : L3;
      const tAt = (z) => {
        if (bottleneck) {
          if (z <= L1) return tb;
          if (z >= L2) return tn;
          return tb + ((tn - tb) * (z - L1)) / (L2 - L1);
        }
        const zt = zb - STRAIGHT_TRANSITION;
        if (z <= zt) return tb;
        if (z >= zb) return tn;
        return tb + ((tn - tb) * (z - zt)) / (zb - zt);
      };
      const zs = new Set([w, L3]);
      for (const p of bodyPts) if (p.z > w && p.z < L3) zs.add(p.z);
      const kinks = bottleneck ? [L1, L2] : [zb - STRAIGHT_TRANSITION, zb];
      for (const z of kinks) if (z > w && z < L3) zs.add(z);
      inner = [...zs].sort((a, b) => a - b).map((z) => ({ r: outerAt(z) - tAt(z), z }));
      innerAt = (z) => outerAt(z) - tAt(Math.max(z, w));
    } else {
      notes.push('Section walls, primer pocket and bullet not drawn: G1 not published.');
    }

    // --- anchors for dimensioning --------------------------------------------------------
    const rmax = Math.max(...outer.map((p) => p.r), bullet ? bullet.rEx : 0);
    const anchors = {
      head: outer[1], rimBack, A: shoulder && shoulder.A, B: shoulder && shoulder.B, mouth,
      tip: bullet ? bullet.exposed[bullet.exposed.length - 1] : null,
    };
    const neckStep = bottleneck ? Math.min(1.0, (L3 - L2) / 3) : 1.0;
    const rimLo = chamfer ? f : 0;
    const features = {
      zR1: rimType === 'rimfire' ? zR1 : Math.min(rimLo + 0.15, (rimLo + R) / 2),
      zE1: hasGroove ? R + eMin - Math.min(0.15, eMin / 2) : null,
      zP1: z0 + DIM_OFFSET,
      zP2: bottleneck ? L1 - 1.5 : null,
      zH1: bottleneck ? L2 + neckStep : null,
      zH2: L3 - Math.min(1.0, neckStep),
      zG1: bullet ? (bullet.cylEnd > L3 ? (L3 + bullet.cylEnd) / 2 : (bullet.zb + bullet.cylEnd) / 2) : null,
    };

    return {
      ok: true, rimType, v, alphaRaw: cone.alpha, outer, inner, outerAt, innerAt, w, tb, tn, heeled, pocket, bullet,
      shoulder, z0, beltRampEnd, hasGroove, bottleneck, rmax, anchors, features, notes,
    };
  }

  CIP.geometry = { build, fillet, rimTypeOf };
})();
