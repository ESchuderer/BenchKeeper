// Pure data model: value tables, detail facts, search/filter, hash routing.
(function () {
  const CIP = (globalThis.CIP = globalThis.CIP || {});
  const F = CIP.format;

  const FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  const DASH = '—';

  const SECTION_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling',
  };

  function formatValue(field, v) {
    return F.isAngle(field) ? F.angle(v) : typeof v === 'number' ? F.number(v) : String(v);
  }

  function formatTol(t) {
    return (t > 0 ? '+' : '') + F.number(t);
  }

  function rowsOf(obj) {
    const rows = [];
    for (const field of Object.keys(obj)) {
      if (field.endsWith('Tol') && Object.hasOwn(obj, field.slice(0, -3))) continue;
      const value = formatValue(field, obj[field]);
      const tolRaw = obj[field + 'Tol'];
      const tol = typeof tolRaw === 'number' ? formatTol(tolRaw) : '';
      rows.push({ field, symbol: F.symbolOf(field), value, tol, text: tol ? value + ' ' + tol : value, unit: F.unitOf(field) });
    }
    return rows;
  }

  function sections(record, part) {
    const out = [];
    for (const id of Object.keys(record[part] || {})) {
      const rows = rowsOf(record[part][id]);
      if (rows.length) out.push({ id, title: SECTION_TITLES[id] || id, rows });
    }
    return out;
  }

  function facts(record) {
    const a = record.annotations || {};
    const cap = a.publishedCapacity;
    const alt = record.alternativeNames;
    const dash = (v) => (v === undefined || v === null || v === '' ? DASH : String(v));
    return [
      { label: 'Alternative names', value: alt && alt.length ? alt.join(', ') : DASH, link: null, note: '' },
      { label: 'Family', value: dash(record.family), link: null, note: '' },
      { label: 'Category', value: dash(a.category), link: null, note: '' },
      { label: 'Primer type', value: dash(a.primerType), link: null, note: '' },
      { label: 'C.I.P. table', value: dash(record.tab), link: null, note: '' },
      { label: 'Country', value: dash(record.country), link: null, note: '' },
      { label: 'Published', value: dash(record.published), link: null, note: '' },
      { label: 'Revised', value: dash(record.revised), link: null, note: '' },
      { label: 'Pressure method', value: dash(record.pressureMethod), link: null, note: '' },
      {
        label: 'Water capacity',
        value: cap && typeof cap.grH2O === 'number' ? F.number(cap.grH2O) + ' gr H2O' : DASH,
        link: cap && cap.url ? { text: cap.source || cap.url, href: cap.url } : null,
        note: (cap && cap.note) || '',
      },
    ];
  }

  function normalise(s) {
    return String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, '').replace(/\./g, ',');
  }

  function matches(record, query, family) {
    if (family && family !== 'All' && record.family !== family) return false;
    const q = normalise(query || '');
    if (!q) return true;
    return [record.name, ...(record.alternativeNames || [])].some((n) => normalise(n).includes(q));
  }

  function filter(records, query, family) {
    return records.filter((r) => matches(r, query, family));
  }

  function listHash(q, family) {
    const p = new URLSearchParams();
    if (q) p.set('q', q);
    if (family && family !== 'All') p.set('family', family);
    const s = p.toString().replace(/\+/g, '%20');
    return s ? '#/?' + s : '#/';
  }

  function detailHash(key) {
    return '#/cartridge/' + encodeURIComponent(key);
  }

  function parseHash(hash) {
    const raw = String(hash || '').replace(/^#/, '');
    const qi = raw.indexOf('?');
    const path = qi < 0 ? raw : raw.slice(0, qi);
    if (path === '' || path === '/') {
      const params = new URLSearchParams(qi < 0 ? '' : raw.slice(qi + 1));
      const family = params.get('family');
      return { view: 'list', q: params.get('q') || '', family: FAMILIES.includes(family) ? family : 'All' };
    }
    const m = /^\/cartridge\/([^/]*)$/.exec(path);
    if (m) {
      let key;
      try {
        key = decodeURIComponent(m[1]);
      } catch (e) {
        return { view: 'notfound', key: m[1] };
      }
      return CIP.data.some((r) => r.key === key) ? { view: 'detail', key } : { view: 'notfound', key };
    }
    return { view: 'notfound', key: path };
  }

  CIP.model = { sections, facts, matches, filter, parseHash, listHash, detailHash, FAMILIES };
})();
