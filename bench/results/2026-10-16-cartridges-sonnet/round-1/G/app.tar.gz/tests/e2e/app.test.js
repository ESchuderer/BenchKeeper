'use strict';
// Browser tests of the app itself. Run: npm run test:e2e   (needs `npx playwright install chromium`)
const test = require('node:test');
const assert = require('node:assert/strict');
const { FILE_URL, serve, launch } = require('./helpers.js');

let browser, http;
test.before(async () => { browser = await launch(); http = await serve(); });
test.after(async () => { await browser.close(); http.server.close(); });

for (const mode of ['file', 'http']) {
  test(`list, search, filter, detail, reload, back (${mode})`, async () => {
    const base = mode === 'file' ? FILE_URL : http.url;
    const ctx = await browser.newContext();
    const page = await ctx.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    const requests = [];
    page.on('request', (r) => requests.push(r.url()));

    await page.goto(base);
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges');
    assert.equal((await page.getByText(/^\d+ cartridges$/).textContent()), '25 cartridges');
    assert.equal(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).count(), 1);
    const options = await page.getByLabel('Family').locator('option').allTextContents();
    assert.deepEqual(options, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);

    await page.getByLabel('Search').fill('7,62 x 51');
    assert.equal(await page.getByText(/^\d+ cartridges$/).textContent(), '1 cartridges');
    assert.equal(await page.getByRole('link', { name: '308 Win.', exact: true }).count(), 1);
    await page.getByLabel('Search').fill('');
    await page.getByLabel('Family').selectOption('pistol');
    assert.equal(await page.getByText(/^\d+ cartridges$/).textContent(), '6 cartridges');

    // filter state is in the address and survives opening a cartridge and going back
    await page.getByRole('link', { name: '9 mm Luger', exact: true }).click();
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '9 mm Luger');
    assert.match(page.url(), /#\/cartridge\/9_mm_luger$/);
    await page.goBack();
    assert.equal(await page.getByLabel('Family').inputValue(), 'pistol');
    assert.equal(await page.getByText(/^\d+ cartridges$/).textContent(), '6 cartridges');

    await page.getByLabel('Family').selectOption('All');
    await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).click();
    assert.match(page.url(), /#\/cartridge\/6_5_creedmoor$/);
    await page.reload();
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '6,5 Creedmoor');
    assert.equal(await page.getByRole('img', { name: '6,5 Creedmoor drawing' }).count(), 1);
    assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
    assert.equal(await page.getByRole('columnheader', { name: 'Symbol' }).count() > 3, true);
    assert.equal(await page.getByRole('columnheader', { name: 'Value' }).count() > 3, true);
    assert.equal(await page.getByRole('columnheader', { name: 'Unit' }).count() > 3, true);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges');
    assert.deepEqual(errors, []);
    assert.deepEqual(requests.filter((u) => !u.startsWith('file:') && !u.startsWith(http.url)), []);
    await ctx.close();
  });
}

test('detail view content for 308 Win.: facts, tolerance next to value, units', async () => {
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  await page.goto(FILE_URL + '#/cartridge/308_win');
  const body = await page.locator('main').innerText();
  for (const s of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) assert.ok(body.includes(s), s);
  const link = page.getByRole('link', { name: 'kwk' });
  assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
  const l1 = page.locator('tr', { has: page.locator('td', { hasText: /^L1$/ }) }).first();
  assert.match((await l1.innerText()).replace(/\s+/g, ' '), /L1 39\.62 -0\.2 mm/);
  assert.equal(await page.locator('td', { hasText: /^L1Tol$/ }).count(), 0);
  const pmax = page.locator('tr', { has: page.locator('td', { hasText: /^Pmax$/ }) }).first();
  assert.match((await pmax.innerText()).replace(/\s+/g, ' '), /Pmax 4150 bar/);
  const alpha = page.locator('tr', { has: page.locator('td', { hasText: /^α$/ }) }).first();
  assert.match((await alpha.innerText()).replace(/\s+/g, ' '), /α 40°/);
  await ctx.close();
});

test('unknown address shows a way back', async () => {
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(FILE_URL + '#/cartridge/nope');
  assert.match(await page.locator('main').innerText(), /not found/i);
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await page.getByText(/^\d+ cartridges$/).textContent(), '25 cartridges');
  await page.goto(FILE_URL + '#/garbage');
  await page.reload();
  assert.match(await page.locator('main').innerText(), /not found/i);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test('search with odd input does not break the list', async () => {
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(FILE_URL);
  for (const q of ['(', '*', '\\', 'zzz']) {
    await page.getByLabel('Search').fill(q);
    const n = await page.getByText(/^\d+ cartridges$/).textContent();
    assert.match(n, /^\d+ cartridges$/);
  }
  assert.equal(await page.getByText(/^\d+ cartridges$/).textContent(), '0 cartridges');
  assert.deepEqual(errors, []);
  await ctx.close();
});
