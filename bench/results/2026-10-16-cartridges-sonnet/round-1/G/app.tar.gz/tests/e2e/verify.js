'use strict';
// Browser verification of all 25 cartridges. Run: npm run verify   (needs `npx playwright install chromium`)
// Checks: one printed A4 page each, real-font label collisions, light print / dark screen, phone width,
// no console errors, no network requests. Writes screenshots and PDFs to $SHOTS (default /tmp/shots).
const fs = require('node:fs');
const path = require('node:path');
const { FILE_URL, serve, launch, ROOT } = require('./helpers.js');

const SHOTS = process.env.SHOTS || '/tmp/shots';
fs.mkdirSync(SHOTS, { recursive: true });
const records = (() => {
  const vm = require('node:vm');
  const sb = {};
  vm.createContext(sb);
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'js', 'data.js'), 'utf8'), sb);
  return sb.CIP.data;
})();

const failures = [];
const fail = (m) => { failures.push(m); console.log('FAIL', m); };

// Runs inside the page: real text boxes vs. every other text box, dimension line and outline point.
function checkLabels() {
  const svg = document.querySelector('svg.cip-drawing');
  const texts = [...svg.querySelectorAll('text')].map((t) => ({ id: t.dataset.id, s: t.textContent, b: t.getBBox() }));
  const out = [];
  const hit = (b, x, y, pad = 0.05) => x > b.x - pad && x < b.x + b.width + pad && y > b.y - pad && y < b.y + b.height + pad;
  for (let i = 0; i < texts.length; i++) {
    for (let j = i + 1; j < texts.length; j++) {
      const a = texts[i].b, c = texts[j].b;
      if (a.x < c.x + c.width && c.x < a.x + a.width && a.y < c.y + c.height && c.y < a.y + a.height) out.push(`labels "${texts[i].s}" / "${texts[j].s}" overlap`);
    }
  }
  const segs = [...svg.querySelectorAll('line[data-owner]')];
  for (const t of texts) {
    for (const l of segs) {
      if (l.dataset.owner === t.id) continue;
      const x1 = +l.getAttribute('x1'), y1 = +l.getAttribute('y1'), x2 = +l.getAttribute('x2'), y2 = +l.getAttribute('y2');
      const n = Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 0.1) + 1;
      for (let k = 0; k <= n; k++) if (hit(t.b, x1 + ((x2 - x1) * k) / n, y1 + ((y2 - y1) * k) / n)) { out.push(`label "${t.s}" crosses a ${l.getAttribute('class')} line of ${l.dataset.owner}`); break; }
    }
    for (const p of svg.querySelectorAll('path.contour')) {
      const len = p.getTotalLength();
      for (let d = 0; d <= len; d += 0.15) { const q = p.getPointAtLength(d); if (hit(t.b, q.x, q.y)) { out.push(`label "${t.s}" touches the outline`); d = len + 1; } }
    }
  }
  const vb = svg.viewBox.baseVal;
  for (const t of texts) if (t.b.x < vb.x || t.b.y < vb.y || t.b.x + t.b.width > vb.x + vb.width || t.b.y + t.b.height > vb.y + vb.height) out.push(`label "${t.s}" outside the viewBox`);
  return { problems: out, fontPx: (document.querySelector('svg.cip-drawing text').getBoundingClientRect().height) };
}

(async () => {
  const browser = await launch();
  const http = await serve();
  const requests = [];
  for (const [mode, base] of [['file', FILE_URL], ['http', http.url]]) {
    const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 }, deviceScaleFactor: 2 });
    const page = await ctx.newPage();
    page.on('pageerror', (e) => fail(`${mode}: page error ${e}`));
    page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) fail(`${mode}: console ${m.type()}: ${m.text()}`); });
    page.on('request', (r) => requests.push(r.url()));
    page.on('requestfailed', (r) => fail(`${mode}: request failed ${r.url()}`));

    for (const rec of records) {
      await page.goto(base + '#/cartridge/' + rec.key);
      await page.reload();
      const h1 = await page.locator('h1').textContent();
      if (h1 !== rec.name) fail(`${mode} ${rec.key}: h1 "${h1}"`);

      // screen: label collisions with the real font
      const res = await page.evaluate(checkLabels);
      for (const p of res.problems) fail(`${mode} ${rec.name}: ${p}`);

      if (mode === 'file') {
        // print: always light, one A4 page
        await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
        const colours = await page.evaluate(() => ({
          bg: getComputedStyle(document.body).backgroundColor, ink: getComputedStyle(document.body).color,
          hidden: ['.site', '.toolbar', 'button', '.site-foot'].map((s) => [s, document.querySelector(s) ? getComputedStyle(document.querySelector(s)).display : 'none']),
          svgColour: getComputedStyle(document.querySelector('.figure')).color,
        }));
        if (colours.bg !== 'rgb(255, 255, 255)' || colours.ink !== 'rgb(0, 0, 0)' || colours.svgColour !== 'rgb(0, 0, 0)') fail(`${rec.name}: print not black on white ${JSON.stringify(colours)}`);
        for (const [s, d] of colours.hidden) if (d !== 'none') fail(`${rec.name}: ${s} visible in print`);
        const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
        const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
        if (pages !== 1) fail(`${rec.name}: prints on ${pages} pages`);
        if (['223_rem', '300_win_mag', '22_long_rifle', '9_3_x_74_r', '357_magnum', '17_hmr', '7_62_x_39', '22_win_mag_r_f'].includes(rec.key)) fs.writeFileSync(path.join(SHOTS, rec.key + '.pdf'), pdf);
        const footer = await page.locator('.source').textContent();
        if (footer !== `Source: C.I.P. TDCC, revised ${rec.revised}`) fail(`${rec.name}: footer "${footer}"`);
        await page.emulateMedia({ media: 'screen', colorScheme: 'light' });
      }
    }
    await ctx.close();
  }

  // dark mode on screen, phone width
  {
    const ctx = await browser.newContext({ viewport: { width: 360, height: 740 }, colorScheme: 'dark', deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    const page = await ctx.newPage();
    await page.goto(FILE_URL);
    const dark = await page.evaluate(() => ({ bg: getComputedStyle(document.body).backgroundColor, ink: getComputedStyle(document.body).color }));
    if (dark.bg === 'rgb(251, 251, 250)') fail('dark mode not applied');
    for (const hash of ['#/', '#/cartridge/9_3_x_74_r', '#/cartridge/300_win_mag', '#/cartridge/22_long_rifle']) {
      await page.goto(FILE_URL + hash);
      await page.reload();
      const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth }));
      if (m.sw > m.iw) fail(`phone ${hash}: horizontal scroll ${m.sw} > ${m.iw}`);
      if (hash.includes('cartridge')) {
        const r = await page.evaluate(checkLabels);
        console.log(`phone ${hash}: drawing text ${r.fontPx.toFixed(1)} px tall`);
        await page.screenshot({ path: path.join(SHOTS, 'phone-' + hash.split('/').pop() + '-dark.png'), fullPage: true });
      } else await page.screenshot({ path: path.join(SHOTS, 'phone-list-dark.png'), fullPage: true });
    }
    await ctx.close();
  }
  {
    const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    await page.goto(FILE_URL);
    await page.screenshot({ path: path.join(SHOTS, 'desktop-list-light.png'), fullPage: true });
    await page.goto(FILE_URL + '#/cartridge/308_win');
    await page.screenshot({ path: path.join(SHOTS, 'desktop-308-light.png'), fullPage: true });
    await ctx.close();
  }

  const external = requests.filter((u) => !u.startsWith('file:') && !u.startsWith(http.url));
  if (external.length) fail('network requests outside the app: ' + external.join(', '));

  await browser.close();
  http.server.close();
  console.log(failures.length ? `\n${failures.length} problem(s)` : '\nALL CHECKS PASSED for 25 cartridges (file:// and http)');
  process.exit(failures.length ? 1 : 0);
})();
