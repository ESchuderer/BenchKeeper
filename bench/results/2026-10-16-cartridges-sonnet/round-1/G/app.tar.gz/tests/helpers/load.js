'use strict';
// Loads the browser scripts into a fresh vm context, the way a browser runs classic <script> files.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.resolve(__dirname, '..', '..');
const PURE = ['data', 'format', 'model', 'geometry', 'drawing'];

function load(names = PURE) {
  const sandbox = { console, URLSearchParams };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  for (const name of names) {
    const file = path.join(ROOT, 'js', name + '.js');
    if (!fs.existsSync(file)) continue;
    vm.runInContext(fs.readFileSync(file, 'utf8'), sandbox, { filename: file });
  }
  return sandbox.CIP || {};
}

function byName(CIP, name) {
  const rec = CIP.data.find((r) => r.name === name);
  if (!rec) throw new Error('no record ' + name);
  return rec;
}

const plain = (x) => JSON.parse(JSON.stringify(x));

module.exports = { load, byName, plain, ROOT };
