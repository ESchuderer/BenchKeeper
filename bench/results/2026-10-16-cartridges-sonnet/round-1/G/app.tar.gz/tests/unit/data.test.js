'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { load, byName, plain } = require('../helpers/load.js');

const CIP = load(['data']);

test('has the 25 records with unique keys', () => {
  assert.equal(CIP.data.length, 25);
  assert.equal(new Set(CIP.data.map((r) => r.key)).size, 25);
});

test('every record has the expected top-level shape', () => {
  for (const r of CIP.data) {
    for (const f of ['name', 'key', 'family', 'tab', 'revised', 'published', 'country', 'pressureMethod', 'cartridge', 'chamber', 'annotations']) {
      assert.ok(r[f] !== undefined, `${r.name} lacks ${f}`);
    }
  }
});

test('records are the published values', () => {
  assert.deepEqual(plain(byName(CIP, '308 Win.').alternativeNames), ['308 Winchester', '7,62 x 51']);
  assert.equal(byName(CIP, '223 Rem.').cartridge.lengths.L3, 44.7);
  assert.equal(byName(CIP, '6,5 Creedmoor').key, '6_5_creedmoor');
  assert.equal(byName(CIP, '7 mm Rem. Mag.').chamber.rifling.i, 3);
  assert.deepEqual(plain(byName(CIP, '22 Long Rifle').annotations.implausible[0].fields), ['cartridge.projectile.G1', 'chamber.barrel.Z']);
  assert.deepEqual(plain(byName(CIP, '7 x 64').cartridge.junctionCone.alpha), { degrees: 40, minutes: 25, seconds: 44 });
  assert.equal(byName(CIP, '40 S.& W.').name, '40 S.& W.');
});

test('family counts', () => {
  const n = (f) => CIP.data.filter((r) => r.family === f).length;
  assert.deepEqual([n('rimless'), n('rimmed'), n('belted'), n('pistol'), n('rimfire')], [12, 2, 2, 6, 3]);
});

test('tolerance fields are where the brief publishes them', () => {
  const tolKeys = (r) => Object.values(r.cartridge).flatMap((o) => Object.keys(o)).filter((k) => k.endsWith('Tol')).sort();
  assert.deepEqual(tolKeys(byName(CIP, '308 Win.')), ['L1Tol', 'L2Tol', 'P2Tol']);
  assert.equal(byName(CIP, '308 Win.').cartridge.lengths.L1Tol, -0.2);
  assert.deepEqual(tolKeys(byName(CIP, '300 Win. Mag.')), ['ETol']);
  assert.deepEqual(tolKeys(byName(CIP, '9 mm Luger')), ['L3Tol']);
  assert.deepEqual(tolKeys(byName(CIP, '38 Special')), ['RTol']);
});

test('shoulder numbers are internally consistent (S, alpha, P2, H1, L1, L2)', () => {
  const deg = (a) => (typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  let checked = 0;
  for (const r of CIP.data) {
    const { junctionCone: j, lengths: l, powderChamber: p, collar } = r.cartridge;
    if (!j || j.alpha === undefined) continue;
    const apex = l.L1 + p.P2 / 2 / Math.tan((deg(j.alpha) / 2) * Math.PI / 180);
    assert.ok(Math.abs(apex - j.S) < 0.01, `${r.name}: S ${j.S} vs ${apex}`);
    if (collar.H1 !== undefined && l.L2 !== undefined) {
      const half = Math.atan((p.P2 - collar.H1) / 2 / (l.L2 - l.L1)) * 2 * 180 / Math.PI;
      assert.ok(Math.abs(half - deg(j.alpha)) < 0.1, `${r.name}: alpha ${deg(j.alpha)} vs points ${half}`);
    }
    checked++;
  }
  assert.equal(checked, 17);
});
