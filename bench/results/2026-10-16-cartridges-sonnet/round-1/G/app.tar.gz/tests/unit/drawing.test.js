'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { load, byName } = require('../helpers/load.js');

const CIP = load(['data', 'format', 'model', 'geometry', 'drawing']);
const D = CIP.drawing;
const render = (name) => D.render(byName(CIP, name));
const texts = (d) => d.labels.map((l) => l.text);

test('223 Rem. carries every dimension label with symbol and value', () => {
  const t = texts(render('223 Rem.'));
  for (const want of ['L3 44.7', 'L6 57.4', 'L1 36.52', 'L2 39.55', 'R1 9.6', 'R 1.14', 'P1 9.58', 'P2 9', 'H1 6.43', 'H2 6.43', 'G1 5.7', 'E1 8.43', 'α 46°']) {
    assert.ok(t.includes(want), `missing label ${want}; have ${t.join(' | ')}`);
  }
});

test('labels use the published values; angles in degrees/minutes/seconds', () => {
  assert.ok(texts(render('308 Win.')).includes('L3 51.18'));
  assert.ok(texts(render('7 x 64')).includes('α 40°25\'44"'));
  assert.ok(texts(render('300 Win. Mag.')).includes('R1 13.51'));
});

test('optional dimensions are left out when the value is not published', () => {
  const t = texts(render('9 mm Luger'));
  for (const sym of ['α', 'L1', 'L2', 'P2', 'H1']) assert.ok(!t.some((x) => x.startsWith(sym + ' ')), sym);
  assert.ok(t.includes('L3 19.15') && t.includes('E1 8.79'));
  const rimmed = texts(render('9,3 x 74 R'));
  assert.ok(!rimmed.some((x) => x.startsWith('E1 ')));
  assert.ok(rimmed.includes('R 1.4'));
});

test('svg: accessible name, 1 unit = 1 mm viewBox, hatch, centre line, escaping', () => {
  const d = render('40 S.& W.');
  assert.match(d.svg, /^<svg [^>]*role="img"/);
  assert.match(d.svg, /aria-label="40 S\.&amp; W\. drawing"/);
  assert.match(d.svg, /<title[^>]*>40 S\.&amp; W\. drawing<\/title>/);
  assert.ok(!/NaN|undefined|Infinity/.test(d.svg));
  assert.match(d.svg, /<pattern /);
  assert.match(d.svg, /class="centre"/);
  assert.match(d.svg, /stroke-dasharray/);
  const vb = /viewBox="(-?[\d.]+) (-?[\d.]+) ([\d.]+) ([\d.]+)"/.exec(d.svg);
  assert.ok(vb);
  assert.equal(+vb[3], d.width);
  assert.equal(+vb[4], d.height);
  assert.ok(d.width >= 106);
});

test('title block: name, table, revision date, units, scale', () => {
  const d = render('223 Rem.');
  const t = texts(d);
  assert.ok(t.includes('223 Rem.'));
  assert.ok(t.includes('C.I.P. table I'));
  assert.ok(t.includes('Revised 2017-05-17'));
  assert.ok(t.includes('Dimensions in mm'));
  const scale = t.find((x) => x.startsWith('Scale'));
  assert.equal(scale, `Scale ${(190 / d.width).toFixed(2)} : 1 (A4 print)`);
  assert.ok(Math.abs(d.scale - 190 / d.width) < 1e-9);
});

test('notes from the geometry are passed through', () => {
  assert.equal(render('223 Rem.').notes.length, 0);
  assert.match(render('17 HMR').notes.join(' '), /r2/);
});

// --- layout checks, for every record ---------------------------------------------------------
function segHitsBox(s, b) {
  // Liang-Barsky clip of segment against the box
  let t0 = 0, t1 = 1;
  const dx = s.x2 - s.x1, dy = s.y2 - s.y1;
  const p = [-dx, dx, -dy, dy];
  const q = [s.x1 - b.x, b.x + b.w - s.x1, s.y1 - b.y, b.y + b.h - s.y1];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; } else {
      const r = q[i] / p[i];
      if (p[i] < 0) { if (r > t1) return false; if (r > t0) t0 = r; } else { if (r < t0) return false; if (r < t1) t1 = r; }
    }
  }
  return true;
}
const boxesOverlap = (a, b, pad = 0) => a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;

test('no label overlaps another label, the outline or any other dimension line (all records)', () => {
  for (const r of CIP.data) {
    const d = D.render(r);
    const ls = d.labels;
    for (let i = 0; i < ls.length; i++) {
      for (let j = i + 1; j < ls.length; j++) {
        assert.ok(!boxesOverlap(ls[i], ls[j], 0.2), `${r.name}: labels "${ls[i].text}" and "${ls[j].text}" overlap`);
      }
    }
    for (const l of ls) {
      for (const s of d.lines) {
        if (s.owner === l.id) continue;
        assert.ok(!segHitsBox(s, l), `${r.name}: label "${l.text}" crosses ${s.kind} line of ${s.owner}`);
      }
    }
  }
});

test('every label is inside the viewBox; every drawn line too', () => {
  for (const r of CIP.data) {
    const d = D.render(r);
    const [x0, y0, w, h] = /viewBox="(-?[\d.]+) (-?[\d.]+) ([\d.]+) ([\d.]+)"/.exec(d.svg).slice(1).map(Number);
    for (const l of d.labels) {
      assert.ok(l.x >= x0 && l.y >= y0 && l.x + l.w <= x0 + w && l.y + l.h <= y0 + h, `${r.name}: ${l.text} outside viewBox`);
    }
    for (const s of d.lines) {
      for (const [x, y] of [[s.x1, s.y1], [s.x2, s.y2]]) {
        assert.ok(x >= x0 - 1e-6 && x <= x0 + w + 1e-6 && y >= y0 - 1e-6 && y <= y0 + h + 1e-6, `${r.name}: ${s.kind} ${s.owner} outside viewBox`);
      }
    }
    assert.ok(!/NaN|undefined|Infinity/.test(d.svg), r.name);
    assert.ok(d.width >= 106 && d.height > 40, r.name);
  }
});

test('drawing is true to scale: outline spans L3 and the tip sits at L6 (1 unit = 1 mm)', () => {
  const r = byName(CIP, '308 Win.');
  const d = D.render(r);
  const outline = d.lines.filter((s) => s.kind === 'outline');
  const xs = outline.flatMap((s) => [s.x1, s.x2]);
  assert.ok(Math.abs(Math.min(...xs) - 0) < 1e-6);
  assert.ok(Math.abs(Math.max(...xs) - 71.12) < 1e-6);
  const ys = outline.flatMap((s) => [s.y1, s.y2]);
  assert.ok(Math.abs(Math.max(...ys) - 12.01 / 2) < 1e-6, 'lower rim edge at +R1/2');
  assert.ok(Math.abs(Math.min(...ys) + 12.01 / 2) < 1e-6, 'upper rim edge at -R1/2');
});

test('record with no published value for a needed feature still renders', () => {
  const c = JSON.parse(JSON.stringify(byName(CIP, '223 Rem.')));
  delete c.cartridge.caseHead.f; delete c.cartridge.lengths.L2; delete c.annotations.primerType;
  const d = D.render(c);
  assert.ok(d.notes.length >= 3);
  assert.ok(!texts(d).some((x) => x.startsWith('L2 ')));
  assert.ok(!/NaN/.test(d.svg));
  const bad = JSON.parse(JSON.stringify(byName(CIP, '223 Rem.'))); delete bad.cartridge.projectile.G1;
  const e = D.render(bad);
  assert.match(e.notes.join(' '), /G1/);
  assert.match(e.svg, /<svg/);
});

test('review: alpha is drawn as the included angle (flank and its mirror)', () => {
  const d = render('223 Rem.');
  const a = d.alpha;
  assert.ok(a);
  assert.ok(Math.abs(a.included - 46) < 1e-9);
  const refs = d.lines.filter((s) => s.owner === 'alpha' && s.kind === 'ref');
  const mirrored = refs.find((s) => Math.abs(s.x1 - a.x) < 1e-9 && Math.abs(s.y1 - a.y) < 1e-9);
  assert.ok(mirrored, 'mirrored flank ray starts at the shoulder start');
  const up = (Math.atan2(-(mirrored.y2 - mirrored.y1), mirrored.x2 - mirrored.x1) * 180) / Math.PI;
  assert.ok(Math.abs(up - 23) < 1e-6, `ray at ${up}° above the axis direction`);
  const m = /M([\d.-]+) ([\d.-]+) A([\d.]+) [\d.]+ 0 0 1 ([\d.-]+) ([\d.-]+)/.exec(d.svg.match(/<path class="dim" d="M[^"]*A[^"]*"/)[0]);
  assert.ok(m, 'arc path');
  const chord = Math.hypot(+m[4] - +m[1], +m[5] - +m[2]);
  assert.ok(Math.abs(chord - 2 * +m[3] * Math.sin((23 * Math.PI) / 180)) < 0.01, 'arc spans the full included angle');
});

test('review: diameter dimension lines never sit closer than 1 mm (arrowheads stay apart)', () => {
  for (const r of CIP.data) {
    const xs = D.render(r).dims.map((q) => q.x).sort((a, b) => a - b);
    for (let i = 1; i < xs.length; i++) assert.ok(xs[i] - xs[i - 1] >= 1.0 - 1e-9, `${r.name}: ${xs[i - 1]} / ${xs[i]}`);
  }
});

test('review: missing G1 still draws the case; missing alpha drops the shoulder dimensions', () => {
  const c = JSON.parse(JSON.stringify(byName(CIP, '223 Rem.'))); delete c.cartridge.projectile.G1;
  const d = D.render(c);
  assert.ok(texts(d).includes('L3 44.7') && texts(d).includes('H2 6.43'));
  assert.ok(!texts(d).some((x) => x.startsWith('G1 ')));
  assert.match(d.notes.join(' '), /G1/);
  assert.ok(!/NaN|undefined/.test(d.svg));
  const e = JSON.parse(JSON.stringify(byName(CIP, '223 Rem.'))); delete e.cartridge.junctionCone.alpha;
  const t = texts(D.render(e));
  for (const sym of ['α', 'P2', 'H1', 'L1', 'L2']) assert.ok(!t.some((x) => x.startsWith(sym + ' ')), sym);
});

test('review: outside view shows the circular edges, hatch is a full-width line', () => {
  const d = render('223 Rem.');
  const edges = d.lines.filter((s) => s.kind === 'edge').map((s) => s.x1);
  for (const z of [1.14, 3.13, 44.7]) assert.ok(edges.some((x) => Math.abs(x - z) < 1e-6), `edge at ${z}`);
  assert.match(d.svg, /<pattern [^>]*><line x1="0\.45"/);
});

test('review: fallback drawing is wide enough for its note', () => {
  const c = JSON.parse(JSON.stringify(byName(CIP, '223 Rem.'))); delete c.cartridge.caseHead.R; delete c.cartridge.caseHead.R1;
  const d = D.render(c);
  assert.ok(d.width >= 0.62 * 2.8 * d.notes.join(' ').length, 'wide enough');
});
