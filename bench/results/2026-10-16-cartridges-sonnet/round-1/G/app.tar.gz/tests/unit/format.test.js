'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { load } = require('../helpers/load.js');

const { format: F } = load(['data', 'format']);

test('number shows the value as published, no thousands separator', () => {
  assert.equal(F.number(51.18), '51.18');
  assert.equal(F.number(4150), '4150');
  assert.equal(F.number(5.0), '5');
  assert.equal(F.number(-0.2), '-0.2');
  assert.equal(F.number(0), '0');
  assert.equal(F.number(1825), '1825');
});

test('angle as degrees or degrees/minutes/seconds', () => {
  assert.equal(F.angle(40), '40°');
  assert.equal(F.angle(0), '0°');
  assert.equal(F.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.angle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(F.angle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'0"');
});

test('units', () => {
  const u = F.unitOf;
  assert.deepEqual([u('Pmax'), u('PK'), u('PE')], ['bar', 'bar', 'bar']);
  assert.equal(u('EE'), 'J');
  assert.equal(u('M'), 'g');
  assert.equal(u('Q'), 'mm²');
  assert.equal(u('N'), '');
  for (const a of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(u(a), '°', a);
  for (const m of ['L3', 'P1', 'Fe', 'deltaL', 'S', 'u', 'G1', 'eMin', 'r1Max']) assert.equal(u(m), 'mm', m);
});

test('symbols are the field name except the special ones', () => {
  const s = F.symbolOf;
  assert.deepEqual(
    ['eMin', 'r1Min', 'r1Max', 'alpha', 'alpha1', 'beta', 'delta', 'deltaL', 'L3PlusG'].map(s),
    ['e min', 'r1 min', 'r1 max', 'α', 'α1', 'β', 'δ', 'delta L', 'L3 + G']
  );
  assert.deepEqual(['L1', 'Pmax', 'R1', 'f', 'N', 'i', 'E1'].map(s), ['L1', 'Pmax', 'R1', 'f', 'N', 'i', 'E1']);
});

test('isAngle', () => {
  assert.equal(F.isAngle('alpha'), true);
  assert.equal(F.isAngle('i'), true);
  assert.equal(F.isAngle('L3'), false);
});
