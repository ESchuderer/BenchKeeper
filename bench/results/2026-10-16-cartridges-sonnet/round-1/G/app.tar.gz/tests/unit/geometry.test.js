'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { load, byName, plain } = require('../helpers/load.js');

const CIP = load(['data', 'format', 'model', 'geometry']);
const G = CIP.geometry;
const rad = (d) => (d * Math.PI) / 180;
const near = (a, b, msg, eps = 1e-9) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} expected ${b}, got ${a}`);
const nearPt = (p, r, z, msg) => { near(p.r, r, (msg || '') + ' r'); near(p.z, z, (msg || '') + ' z'); };
const build = (name) => G.build(byName(CIP, name));
const clone = (name) => JSON.parse(JSON.stringify(byName(CIP, name)));
const finite = (pts) => pts.every((p) => Number.isFinite(p.r) && Number.isFinite(p.z));

test('rim type follows the brief', () => {
  const t = (n) => build(n).rimType;
  assert.equal(t('223 Rem.'), 'rimless');
  assert.equal(t('9,3 x 74 R'), 'rimmed');
  assert.equal(t('38 Special'), 'rimmed');
  assert.equal(t('300 Win. Mag.'), 'belted');
  assert.equal(t('22 Long Rifle'), 'rimfire');
  assert.equal(t('9,3 x 62'), 'rimless'); // R1/P1 = 0.9876
  const c = clone('223 Rem.'); c.cartridge.caseHead.R1 = 9.0;
  assert.equal(G.build(c).rimType, 'rebated');
  c.cartridge.caseHead.R1 = 9.58 * 1.05;
  assert.equal(G.build(c).rimType, 'rimmed');
});

test('fillet is tangent to both lines and keeps the radius', () => {
  const pts = G.fillet({ r: 0, z: -10 }, { r: 0, z: 0 }, { r: 10, z: 0 }, 2, 8);
  nearPt(pts[0], 0, -2, 'T1');
  nearPt(pts[pts.length - 1], 2, 0, 'T2');
  for (const p of pts) near(Math.hypot(p.r - 2, p.z + 2), 2, 'on circle');
  assert.equal(pts.length, 9);
  // radius is clamped when the neighbours are short
  const short = G.fillet({ r: 0, z: -1 }, { r: 0, z: 0 }, { r: 1, z: 0 }, 5, 4);
  nearPt(short[0], 0, -0.5, 'clamped T1');
});

test('223 Rem. head, groove and body start (rule 2, 3)', () => {
  const m = build('223 Rem.');
  const o = m.outer;
  nearPt(o[0], 0, 0);
  nearPt(o[1], 9.6 / 2 - Math.min(0.45 * Math.tan(rad(35)), 9.6 / 4), 0, 'chamfer start');
  nearPt(o[2], 4.8, 0.45, 'chamfer end');
  nearPt(o[3], 4.8, 1.14, 'rim back');
  nearPt(o[4], 8.43 / 2, 1.14, 'groove in');
  nearPt(o[5], 8.43 / 2, 1.14 + 0.76, 'groove floor end');
  nearPt(o[6], 9.58 / 2, 3.13, 'ramp end = body start');
  assert.equal(m.z0, 3.13);
});

test('223 Rem. shoulder and neck (rule 4, 5, 6)', () => {
  const m = build('223 Rem.');
  nearPt(m.shoulder.A, 9 / 2, 36.52, 'A');
  nearPt(m.shoulder.B, 6.43 / 2, 39.55, 'B');
  near(m.shoulder.alpha, 46, 'alpha');
  nearPt(m.outer[m.outer.length - 1], 6.43 / 2, 44.7, 'mouth corner');
  // both corners are rounded: neither exact corner is a vertex of the profile
  assert.ok(!m.outer.some((p) => Math.abs(p.r - 4.5) < 1e-9 && Math.abs(p.z - 36.52) < 1e-9));
  assert.ok(!m.outer.some((p) => Math.abs(p.r - 3.215) < 1e-9 && Math.abs(p.z - 39.55) < 1e-9));
  assert.deepEqual(plain(m.notes), []);
});

test('corner without a published radius stays sharp and is reported', () => {
  const m = build('338 Lapua Mag.'); // r2 but no r1Min
  assert.ok(m.outer.some((p) => Math.abs(p.r - 13.82 / 2) < 1e-9 && Math.abs(p.z - 54.9) < 1e-9), 'A kept');
  assert.ok(!m.outer.some((p) => Math.abs(p.r - 9.46 / 2) < 1e-9 && Math.abs(p.z - 60.89) < 1e-9), 'B rounded');
  assert.equal(m.notes.length, 1);
  assert.match(m.notes[0], /r1 min/);
  const h = build('17 HMR');
  assert.equal(h.notes.length, 2);
  assert.match(h.notes.join(' '), /r1 min/);
  assert.match(h.notes.join(' '), /r2/);
});

test('rimmed case without groove steps in at the rim back face', () => {
  const m = build('9,3 x 74 R');
  const i = m.outer.findIndex((p) => Math.abs(p.r - 13.35 / 2) < 1e-9 && Math.abs(p.z - 1.4) < 1e-9);
  assert.ok(i > 0);
  nearPt(m.outer[i + 1], 11.9 / 2, 1.4, 'step in to P1/2');
  nearPt(m.outer[1], 13.35 / 2 - Math.min(0.3 * Math.tan(rad(45)), 13.35 / 4), 0, 'chamfer');
  assert.equal(m.z0, 1.4);
  assert.deepEqual(plain(m.notes), []);
});

test('belted case: ramp at delta to the belt, belt to E, step to P1/2', () => {
  const m = build('300 Win. Mag.');
  const rampEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(rad(35));
  near(m.beltRampEnd, rampEnd, 'ramp end');
  const o = m.outer;
  const i = o.findIndex((p) => Math.abs(p.r - 12.07 / 2) < 1e-9 && Math.abs(p.z - 2.21) < 1e-9);
  assert.ok(i > 0, 'groove floor end');
  nearPt(o[i + 1], 13.51 / 2, rampEnd, 'belt start');
  nearPt(o[i + 2], 13.51 / 2, 5.59, 'belt end');
  nearPt(o[i + 3], 13.03 / 2, 5.59, 'step in');
  assert.equal(m.z0, 5.59);
});

test('rimfire rim edge is a half-round whose outermost point is at R1/2', () => {
  const m = build('22 Long Rifle');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  nearPt(m.outer[1], 7.06 / 2 - rho, 0, 'arc start');
  const arc = m.outer.filter((p) => p.z > 0 && p.z < 2 * rho - 1e-9);
  assert.ok(arc.length >= 8);
  for (const p of arc) near(Math.hypot(p.r - (7.06 / 2 - rho), p.z - rho), rho, 'arc radius');
  near(Math.max(...m.outer.map((p) => p.r)), 7.06 / 2, 'outermost');
  nearPt(m.outer.find((p) => Math.abs(p.z - 1.09) < 1e-9), 7.06 / 2 - rho, 1.09, 'rim back');
  assert.deepEqual(plain(m.notes), []);
  const h = build('17 HMR');
  near(Math.max(...h.outer.map((p) => p.r)), 7.47 / 2, 'outermost 17 HMR');
});

test('straight case runs from the body start to the mouth', () => {
  const m = build('9 mm Luger');
  assert.equal(m.shoulder, null);
  nearPt(m.outer[m.outer.length - 1], 9.65 / 2, 19.15, 'mouth');
  assert.deepEqual(plain(m.notes), []);
});

test('pointy bullet: seating, cylinder, tangent ogive (rule 7)', () => {
  const m = build('223 Rem.'); const b = m.bullet;
  near(b.s, 5.7); near(b.zb, 44.7 - 5.7); near(b.Lb, 57.4 - 39); near(b.k, 0.4);
  near(b.cylEnd, 39 + 0.4 * 18.4); near(b.m, 1.27);
  const n = 57.4 - b.cylEnd, d = 5.7 / 2 - 1.27 / 2;
  near(b.rho, (d * d + n * n) / (2 * d), 'rho');
  nearPt(b.exposed[b.exposed.length - 1], 1.27 / 2, 57.4, 'tip');
  const nose = b.exposed.filter((p) => p.z > b.cylEnd + 1e-9);
  assert.ok(nose.length > 10);
  for (const p of nose) near(Math.hypot(p.r - (5.7 / 2 - b.rho), p.z - b.cylEnd), b.rho, 'on ogive circle');
  nearPt(b.exposed[0], 5.7 / 2, 44.7, 'bullet leaves the mouth at G1/2');
  assert.equal(b.heel, false);
});

test('meplat for large bullets is 0.08 G1 when that exceeds 1.27', () => {
  const c = clone('223 Rem.'); c.cartridge.projectile.G1 = 20; c.cartridge.collar.H2 = 20.3;
  near(G.build(c).bullet.m, 1.6);
});

test('rounded pistol bullet: quarter ellipse, m = 0.15 G1', () => {
  const b = build('9 mm Luger').bullet;
  near(b.s, 0.4 * 9.03); near(b.m, 0.15 * 9.03); near(b.k, 0.65);
  const a = 9.03 / 2 - b.m / 2, n = 29.69 - b.cylEnd;
  const nose = b.exposed.filter((p) => p.z > b.cylEnd + 1e-9);
  assert.ok(nose.length > 10);
  for (const p of nose) near(((p.r - b.m / 2) / a) ** 2 + ((p.z - b.cylEnd) / n) ** 2, 1, 'on ellipse', 1e-9);
  nearPt(b.exposed[b.exposed.length - 1], b.m / 2, 29.69, 'tip');
  const wr = build('22 Win. Mag. R.F.').bullet; // rimfire is like rifle for seating
  near(wr.s, 0.8 * 5.7); near(wr.k, 0.55);
});

test('flat and semi-wadcutter bullets are straight cones', () => {
  const f = build('40 S.& W.').bullet;
  near(f.s, 0.4 * 10.17); near(f.k, 0.7); near(f.m, 0.55 * 10.17);
  const swc = build('357 Magnum').bullet;
  near(swc.s, 0.6 * 9.12); near(swc.k, 0.78); near(swc.m, 0.6 * 9.12);
  for (const b of [f, swc]) {
    const cone = b.exposed.filter((p) => p.z >= b.cylEnd - 1e-9);
    const first = cone[0], last = cone[cone.length - 1];
    for (const p of cone) near((p.r - first.r) * (last.z - first.z), (last.r - first.r) * (p.z - first.z), 'collinear', 1e-9);
    nearPt(last, b.m / 2, last.z);
  }
});

test('walls, solid head and primer pocket (rule 8)', () => {
  const m = build('223 Rem.');
  near(m.tn, (6.43 - 5.7) / 2); near(m.tb, 0.6);
  assert.deepEqual(plain(m.pocket), { d: 4.45, depth: 3.04 });
  near(m.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + 0.6));
  nearPt(m.inner[0], m.innerAt(m.w), m.w);
  near(m.inner[0].r, 9.58 / 2 + (4.5 - 9.58 / 2) * (m.w - 3.13) / (36.52 - 3.13) - 0.6, 'inner start follows the body', 1e-6);
  const last = m.inner[m.inner.length - 1];
  nearPt(last, 6.43 / 2 - m.tn, 44.7, 'inner mouth = bullet radius');
  assert.deepEqual(plain(build('243 Win.').pocket), { d: 5.33, depth: 3.3 });
  near(build('243 Win.').w, 3.3 + 1.5);
  assert.deepEqual(plain(build('45 Auto').pocket), { d: 5.33, depth: 3.04 }); // lp
  assert.deepEqual(plain(build('357 Magnum').pocket), { d: 4.45, depth: 3.04 }); // spm
  assert.equal(build('22 Long Rifle').pocket, null);
  near(build('22 Long Rifle').w, 2.5);
  const belted = build('300 Win. Mag.');
  near(belted.w, Math.max(2.5, 3.3 + 1.5, belted.beltRampEnd + belted.tb));
  const thick = clone('243 Win.'); thick.annotations.primerType = 'sp'; thick.cartridge.caseHead.E = 9;
  near(G.build(thick).w, 9 + G.build(thick).tb, 'E + tb dominates');
});

test('wall thickness blends tb to tn across the shoulder', () => {
  const m = build('223 Rem.');
  const t = (z) => m.outerAt(z) - m.innerAt(z);
  near(t(20), 0.6, 'body', 1e-6);
  near(t(41), m.tn, 'neck', 1e-6);
  near(t((36.52 + 39.55) / 2) , (0.6 + m.tn) / 2, 'half way', 0.02);
});

test('heeled case (22 Long Rifle): case outside diameter, inside heel, wall kept', () => {
  const m = build('22 Long Rifle');
  assert.equal(m.heeled, true);
  near(m.tb, 0.6); near(m.tn, 0.6);
  const b = m.bullet;
  assert.equal(b.heel, true);
  near(b.seatR, (5.72 - 2 * 0.6) / 2);
  near(b.exposed[0].r, 5.72 / 2);
  near(b.s, 0.8 * 5.72); near(b.k, 0.55); near(b.m, 0.15 * 5.72);
  assert.equal(build('22 Win. Mag. R.F.').heeled, false);
  near(build('22 Win. Mag. R.F.').tn, (6.15 - 5.7) / 2);
});

test('rule 9: missing values drop the feature and are named', () => {
  const c = clone('223 Rem.'); delete c.cartridge.caseHead.f;
  let m = G.build(c);
  nearPt(m.outer[1], 9.6 / 2, 0, 'square corner');
  assert.match(m.notes.join(' '), /\bf\b/);
  const d = clone('223 Rem.'); delete d.cartridge.lengths.L2;
  m = G.build(d);
  assert.equal(m.shoulder, null);
  nearPt(m.outer[m.outer.length - 1], 6.43 / 2, 44.7);
  assert.match(m.notes.join(' '), /L2/);
  const e = clone('223 Rem.'); delete e.cartridge.caseHead.eMin;
  m = G.build(e);
  assert.match(m.notes.join(' '), /e min/);
  assert.ok(!m.outer.some((p) => Math.abs(p.r - 8.43 / 2) < 1e-9));
  const bm = clone('300 Win. Mag.'); delete bm.cartridge.caseHead.R3;
  assert.match(G.build(bm).notes.join(' '), /R3/);
  const n = clone('223 Rem.'); delete n.annotations.primerType;
  m = G.build(n);
  assert.equal(m.pocket, null);
  assert.match(m.notes.join(' '), /primer/);
});

test('notes exist only for 338 Lapua Mag. and 17 HMR', () => {
  const noted = Object.fromEntries(CIP.data.map((r) => [r.name, G.build(r).notes.length]).filter(([, n]) => n));
  assert.deepEqual(plain(noted), { '338 Lapua Mag.': 1, '17 HMR': 2 });
});

test('invariants for all 25 records', () => {
  for (const r of CIP.data) {
    const m = G.build(r); const name = r.name;
    assert.equal(m.ok, true, name);
    for (const key of ['outer', 'inner']) assert.ok(finite(m[key]), `${name} ${key} finite`);
    for (let i = 1; i < m.outer.length; i++) assert.ok(m.outer[i].z >= m.outer[i - 1].z - 1e-9, `${name} outer z monotone at ${i}`);
    for (let i = 1; i < m.inner.length; i++) assert.ok(m.inner[i].z > m.inner[i - 1].z - 1e-9, `${name} inner z monotone`);
    assert.ok(finite(m.bullet.exposed) && finite(m.bullet.section), `${name} bullet finite`);
    nearPt(m.inner[0], m.inner[0].r, m.w, name);
    near(m.inner[m.inner.length - 1].z, r.cartridge.lengths.L3, name);
    for (const p of m.inner) assert.ok(p.r > 0 && p.r < m.outerAt(p.z) - 1e-9, `${name} inner inside outer at z=${p.z}`);
    // bullet is never wider than the bore it sits in (+ heel)
    for (let z = Math.max(m.bullet.zb, m.w); z <= r.cartridge.lengths.L3; z += 0.25) {
      assert.ok(m.bullet.seatR <= m.innerAt(z) + 1e-9, `${name} seated bullet fits at z=${z}`);
    }
    assert.ok(m.bullet.zb >= m.w - 1e-9, `${name} bullet base is in the cavity`);
    near(m.bullet.exposed[m.bullet.exposed.length - 1].z, r.cartridge.lengths.L6, name);
    assert.ok(m.bullet.exposed.every((p) => p.r <= Math.max(m.bullet.seatR, r.cartridge.collar.H2 / 2) + 1e-9), `${name} nose not wider than shank`);
    assert.ok(m.rmax >= Math.max(...m.outer.map((p) => p.r)) - 1e-9);
  }
});

test('review: bullet whose cylinder ends inside the case keeps its seated profile', () => {
  const c = clone('223 Rem.'); c.cartridge.lengths.L6 = 50; // zb 39, cylinder ends at 43.4 < L3 44.7
  const m = G.build(c); const b = m.bullet;
  assert.ok(b.cylEnd < 44.7);
  assert.ok(b.section.some((p) => Math.abs(p.r - 5.7 / 2) < 1e-9 && Math.abs(p.z - b.cylEnd) < 1e-9), 'cylinder end is in the section');
  nearPt(b.exposed[0], b.exposed[0].r, 44.7, 'exposed starts at the mouth');
  assert.ok(b.exposed[0].r < 5.7 / 2 - 1e-6, 'nose is already narrower at the mouth');
  for (let i = 1; i < b.section.length - 1; i++) assert.ok(b.section[i].r <= b.section[i - 1].r + 1e-9 || b.section[i - 1].z === b.zb, 'radius never grows along the nose');
});

test('review: missing G1 drops the walls and the bullet, not the whole drawing', () => {
  const c = clone('223 Rem.'); delete c.cartridge.projectile.G1;
  const m = G.build(c);
  assert.equal(m.ok, true);
  assert.equal(m.inner, null);
  assert.equal(m.bullet, null);
  assert.match(m.notes.join(' '), /G1/);
  assert.ok(finite(m.outer));
  const h = clone('223 Rem.'); delete h.cartridge.collar.H2;
  assert.equal(G.build(h).ok, false);
});

test('review: missing category or unsupported shape is reported accurately', () => {
  const c = clone('223 Rem.'); delete c.annotations.category;
  let m = G.build(c);
  assert.equal(m.bullet, null);
  assert.match(m.notes.join(' '), /category/);
  const d = clone('223 Rem.'); d.annotations.defaultBulletShape = 'wadcutter';
  m = G.build(d);
  assert.equal(m.bullet, null);
  assert.match(m.notes.join(' '), /wadcutter/);
  assert.ok(!/not published/.test(m.notes.filter((n) => /wadcutter/.test(n)).join(' ')));
});

test('review: dimension lines for diameters sit at well separated z', () => {
  for (const r of CIP.data) {
    const m = G.build(r);
    const f = m.features;
    const zs = [f.zR1, f.zE1, f.zP1, f.zP2, f.zH1, f.zH2, f.zG1].filter((z) => z !== null && z !== undefined).sort((a, b) => a - b);
    for (let i = 1; i < zs.length; i++) assert.ok(zs[i] - zs[i - 1] >= 1.0 - 1e-9, `${r.name}: dimension lines ${zs[i - 1]} and ${zs[i]} too close`);
  }
});
