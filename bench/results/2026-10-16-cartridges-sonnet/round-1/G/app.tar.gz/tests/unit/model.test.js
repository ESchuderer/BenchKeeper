'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { load, byName, plain } = require('../helpers/load.js');

const CIP = load(['data', 'format', 'model']);
const M = CIP.model;
const sec = (rec, part, id) => M.sections(rec, part).find((s) => s.id === id);
const row = (rec, part, id, field) => sec(rec, part, id).rows.find((r) => r.field === field);

test('tolerance is shown next to its value and never as its own row', () => {
  const rec = byName(CIP, '308 Win.');
  const l1 = row(rec, 'cartridge', 'lengths', 'L1');
  assert.equal(l1.value, '39.62');
  assert.equal(l1.tol, '-0.2');
  assert.equal(l1.text, '39.62 -0.2');
  assert.equal(l1.unit, 'mm');
  const all = M.sections(rec, 'cartridge').flatMap((s) => s.rows.map((r) => r.field));
  assert.ok(!all.some((f) => f.endsWith('Tol')));
  assert.deepEqual(plain(sec(rec, 'cartridge', 'lengths').rows.map((r) => r.field)), ['L1', 'L2', 'L3', 'L6']);
});

test('symbols, angles and units in rows', () => {
  const rec = byName(CIP, '223 Rem.');
  assert.equal(row(rec, 'cartridge', 'caseHead', 'eMin').symbol, 'e min');
  assert.equal(row(rec, 'cartridge', 'junctionCone', 'alpha').text, '46°');
  assert.equal(row(rec, 'cartridge', 'junctionCone', 'alpha').symbol, 'α');
  assert.equal(row(rec, 'cartridge', 'junctionCone', 'alpha').unit, '°');
  assert.equal(row(rec, 'cartridge', 'pressures', 'Pmax').text, '4300');
  assert.equal(row(rec, 'cartridge', 'pressures', 'Pmax').unit, 'bar');
  assert.equal(row(rec, 'chamber', 'grooves', 'N').unit, '');
  assert.equal(row(rec, 'chamber', 'grooves', 'Q').unit, 'mm²');
  assert.equal(row(rec, 'chamber', 'rifling', 'i').text, '3°10\'36"');
  assert.equal(row(byName(CIP, '7 x 64'), 'cartridge', 'junctionCone', 'alpha').text, '40°25\'44"');
  assert.equal(row(byName(CIP, '7 mm Rem. Mag.'), 'chamber', 'rifling', 'i').text, '3°');
  assert.equal(row(rec, 'cartridge', 'projectile', 'L3PlusG').symbol, 'L3 + G');
});

test('empty sections are omitted; sections have titles', () => {
  const luger = byName(CIP, '9 mm Luger');
  assert.equal(sec(luger, 'cartridge', 'junctionCone'), undefined);
  assert.equal(sec(luger, 'chamber', 'junctionCone'), undefined);
  assert.equal(sec(byName(CIP, '223 Rem.'), 'cartridge', 'caseHead').title, 'Case head');
  for (const r of CIP.data) for (const part of ['cartridge', 'chamber']) for (const s of M.sections(r, part)) {
    assert.ok(s.title && s.rows.length > 0, `${r.name} ${s.id}`);
  }
});

test('facts: metadata and published capacity with source link', () => {
  const f = Object.fromEntries(M.facts(byName(CIP, '223 Rem.')).map((x) => [x.label, x]));
  assert.equal(f['Alternative names'].value, '—');
  assert.equal(f['Family'].value, 'rimless');
  assert.equal(f['Category'].value, 'rifle');
  assert.equal(f['Primer type'].value, 'sr');
  assert.equal(f['C.I.P. table'].value, 'I');
  assert.equal(f['Country'].value, 'US');
  assert.equal(f['Published'].value, '1984-06-14');
  assert.equal(f['Revised'].value, '2017-05-17');
  assert.equal(f['Pressure method'].value, 'Transducer');
  assert.equal(f['Water capacity'].value, '30.5 gr H2O');
  assert.deepEqual(plain(f['Water capacity'].link), { text: 'kwk', href: 'http://kwk.us/cases.html' });
  assert.equal(f['Water capacity'].note, 'kwk 31, Wikipedia 28.8; the mean');
  const lr = Object.fromEntries(M.facts(byName(CIP, '7 x 64')).map((x) => [x.label, x]));
  assert.equal(lr['Water capacity'].value, '—');
  assert.equal(lr['Water capacity'].link, null);
  const w = Object.fromEntries(M.facts(byName(CIP, '308 Win.')).map((x) => [x.label, x]));
  assert.equal(w['Alternative names'].value, '308 Winchester, 7,62 x 51');
});

const names = (q, fam) => M.filter(CIP.data, q, fam).map((r) => r.name);

test('search matches name and alternative names', () => {
  assert.deepEqual(plain(names('7,62 x 51')), ['308 Win.']);
  assert.deepEqual(plain(names('7,62x51')), ['308 Win.']);
  assert.deepEqual(plain(names('7.62 x 51')), ['308 Win.']);
  assert.deepEqual(plain(names('  308  WINCHESTER ')), ['308 Win.']);
  assert.deepEqual(plain(names('45 acp')), ['45 Auto']);
  assert.deepEqual(plain(names('22lr')), ['22 Long Rifle']);
  assert.deepEqual(plain(names('lang für')), ['22 Long Rifle']);
  assert.deepEqual(plain(names('lang fur')), ['22 Long Rifle']);
  assert.equal(names('win.').length, 5);
});

test('search edge cases do not throw', () => {
  for (const q of ['(', '*', '[', '\\', '.*', '', '   ']) assert.doesNotThrow(() => names(q));
  assert.equal(names('(').length, 2); // 9 mm Luger and 338 Lapua Mag. have "(" in alternative names
  assert.equal(names('*').length, 0);
  assert.equal(names('   ').length, 25);
  assert.equal(names('zzz').length, 0);
});

test('family filter', () => {
  assert.equal(names('', 'pistol').length, 6);
  assert.equal(names('', 'All').length, 25);
  assert.equal(names('', '').length, 25);
  assert.equal(names('win', 'belted').length, 1);
  assert.equal(names('win', 'pistol').length, 0);
  assert.deepEqual(plain(M.FAMILIES), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('routing', () => {
  assert.deepEqual(plain(M.parseHash('')), { view: 'list', q: '', family: 'All' });
  assert.deepEqual(plain(M.parseHash('#')), { view: 'list', q: '', family: 'All' });
  assert.deepEqual(plain(M.parseHash('#/')), { view: 'list', q: '', family: 'All' });
  assert.deepEqual(plain(M.parseHash('#/?q=308&family=rimless')), { view: 'list', q: '308', family: 'rimless' });
  assert.deepEqual(plain(M.parseHash('#/?q=7%2C62%20x%2051&family=bogus')), { view: 'list', q: '7,62 x 51', family: 'All' });
  assert.deepEqual(plain(M.parseHash('#/cartridge/223_rem')), { view: 'detail', key: '223_rem' });
  assert.deepEqual(plain(M.parseHash('#/cartridge/nope')), { view: 'notfound', key: 'nope' });
  assert.equal(M.parseHash('#/cartridge/%E2%82%AC').view, 'notfound');
  assert.equal(M.parseHash('#/cartridge/%E0%A4%A').view, 'notfound');
  assert.equal(M.parseHash('#/zzz').view, 'notfound');
  assert.equal(M.listHash('', 'All'), '#/');
  assert.equal(M.listHash('7,62 x 51', 'rimless'), '#/?q=7%2C62%20x%2051&family=rimless');
  assert.equal(M.listHash('', 'pistol'), '#/?family=pistol');
  assert.equal(M.detailHash('223_rem'), '#/cartridge/223_rem');
  for (const r of CIP.data) assert.equal(M.parseHash(M.detailHash(r.key)).key, r.key);
});
