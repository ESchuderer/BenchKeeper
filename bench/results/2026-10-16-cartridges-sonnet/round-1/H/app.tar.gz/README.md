# C.I.P. cartridge reference

A static reference database of 25 C.I.P. cartridges (cartridge and chamber values, computed 2D drawing,
one-page A4 print), modelled on the OpenBallistics cartridge database. Plain HTML, CSS and JavaScript:
no framework, no build step, no server code, no runtime dependencies, no network requests.

## Use

Open `index.html` directly in Chromium (`file://`), or serve the folder with any static file server
(`npm run serve` starts a tiny one). Detail views have bookmarkable addresses: `index.html#/cartridge/308_win`.

## Data

`data/cartridges.jsonl` holds the 25 records verbatim (OpenBallistics, MIT, commit e83db43).
`js/data.js` is generated from it by `npm run build:data` (a dev step only; `file://` cannot `fetch`).

## Code map

| File | Role |
| --- | --- |
| `js/format.js` | numbers, angles (`40°`, `39°59'49"`), tolerances, symbols, units |
| `js/model.js` | value tables, metadata, search/filter, hash routes |
| `js/geometry.js` | outline, bullet, section from a record (mm, `{z, r}`); notes for missing values |
| `js/layout.js` | dimension lines, arrowheads, labels without overlaps, title block, print scale |
| `js/drawing.js` | SVG nodes from the layout |
| `js/app.js`, `css/app.css` | views, routing, light/dark/phone/print styles |

## Development

```
npm install
npm test            # unit tests (node:test)
npm run test:e2e    # Playwright end-to-end tests (needs `npx playwright install chromium`)
```

Specification and design: `openspec/changes/cip-cartridge-reference/`.

Drawing assumptions beyond the brief are listed in `design.md` (diameter dimension lines cross the section,
shoulder angle drawn as a detail symbol, straight-case wall eases to the neck wall before the bullet base).
