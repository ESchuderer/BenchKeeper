import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, fileUrl, detailUrl, DATA } from './helpers.mjs';

let env;
before(async () => { env = await launch(); });
after(async () => { await env.close(); });

const targets = () => [['file://', fileUrl], ['http://', env.httpUrl]];

for (const [label, getUrl] of [['file://', () => fileUrl], ['http://', () => env.httpUrl]]) {
  test(`${label} start page lists every cartridge`, async () => {
    const { page, problems, context } = await openPage(env.browser, getUrl());
    await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
    assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
    for (const r of DATA) {
      const link = page.getByRole('link', { name: r.name, exact: true });
      assert.equal(await link.count(), 1, r.name);
      assert.equal(await link.textContent(), r.name);
    }
    const rows = await page.locator('table.list tbody tr').count();
    assert.equal(rows, 25);
    const first = await page.locator('table.list tbody tr').first().innerText();
    assert.match(first, /223 Rem\./);
    assert.match(first, /rimless/);
    assert.match(first, /44\.7/);
    assert.deepEqual(problems, []);
    await context.close();
  });

  test(`${label} search, family filter and count`, async () => {
    const { page, context } = await openPage(env.browser, getUrl());
    const search = page.getByLabel('Search');
    const family = page.getByLabel('Family');
    const count = page.getByRole('status');
    await search.fill('7,62 x 51');
    assert.equal(await count.textContent(), '1 cartridges');
    assert.equal(await page.getByRole('link', { name: '308 Win.', exact: true }).count(), 1);
    await search.fill('');
    await search.pressSequentially('creed');
    assert.equal(await count.textContent(), '1 cartridges');
    await search.fill('');
    assert.equal(await count.textContent(), '25 cartridges');
    const options = await family.locator('option').allTextContents();
    assert.deepEqual(options, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
    await family.selectOption('belted');
    assert.equal(await count.textContent(), '2 cartridges');
    await family.selectOption('pistol');
    assert.equal(await count.textContent(), '6 cartridges');
    await search.fill('mag');
    assert.deepEqual(
      await page.locator('table.list tbody td.name').allTextContents(),
      ['357 Magnum', '44 Rem. Mag.']
    );
    await search.fill('zzzz');
    assert.equal(await count.textContent(), '0 cartridges');
    await family.selectOption('All');
    await search.fill('');
    assert.equal(await count.textContent(), '25 cartridges');
    await context.close();
  });

  test(`${label} detail view opens, survives reload, and links back with filters kept`, async () => {
    const { page, context } = await openPage(env.browser, getUrl());
    await page.getByLabel('Search').fill('308');
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    await page.getByRole('heading', { name: '308 Win.', level: 1 }).waitFor();
    assert.match(page.url(), /#\/cartridge\/308_win$/);
    await page.getByRole('link', { name: 'All cartridges', exact: true }).click();
    await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
    assert.equal(await page.getByLabel('Search').inputValue(), '308');
    assert.equal(await page.getByRole('status').textContent(), '1 cartridges');
    await page.goBack();
    await page.getByRole('heading', { name: '308 Win.', level: 1 }).waitFor();
    await page.reload();
    await page.getByRole('heading', { name: '308 Win.', level: 1 }).waitFor();
    assert.match(page.url(), /#\/cartridge\/308_win$/);
    await context.close();
  });
}

test('unknown address shows a not-found message with a way back', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, 'nope'));
  await page.getByRole('heading', { name: 'Cartridge not found' }).waitFor();
  await page.getByRole('link', { name: 'All cartridges', exact: true }).click();
  await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
  await context.close();
});

test('detail view shows metadata, water capacity link, and tables with Symbol/Value/Unit', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '308_win'));
  await page.getByRole('heading', { name: '308 Win.', level: 1 }).waitFor();
  const meta = await page.locator('dl.meta').innerText();
  for (const t of ['Alternative names', '308 Winchester, 7,62 x 51', 'Family', 'rimless', 'Category', 'rifle',
    'Primer type', 'lr', 'C.I.P. table', 'Country', 'US', 'Published', '1984-06-14', 'Revised', '2008-09-23',
    'Pressure method', 'Transducer', 'Water capacity', '56 grH2O']) {
    assert.ok(meta.includes(t), `meta lacks ${t}`);
  }
  const link = page.locator('dl.meta a');
  assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
  assert.equal(await link.textContent(), 'kwk');
  assert.ok((await page.locator('table.values').count()) >= 14);
  const heads = await page.locator('table.values').first().locator('thead th').allTextContents();
  assert.deepEqual(heads, ['Symbol', 'Value', 'Unit']);
  const lengths = page.getByRole('table', { name: 'Cartridge values Lengths' });
  const l3 = lengths.getByRole('row', { name: /^L3 / });
  assert.equal((await l3.innerText()).replace(/\s+/g, ' '), 'L3 51.18 mm');
  const pmax = page.getByRole('table', { name: 'Cartridge values Pressures' }).getByRole('row', { name: /^Pmax / });
  assert.equal((await pmax.innerText()).replace(/\s+/g, ' '), 'Pmax 4150 bar');
  assert.ok((await page.getByRole('heading', { name: 'Chamber values' }).count()) === 1);
  await context.close();
});

test('tolerances, angles and symbols are formatted as published', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '243_win'));
  await page.getByRole('heading', { name: '243 Win.', level: 1 }).waitFor();
  const lengths = page.getByRole('table', { name: 'Cartridge values Lengths' });
  assert.equal((await lengths.getByRole('row', { name: /^L1 / }).innerText()).replace(/\s+/g, ' '), 'L1 39.62 -0.2 mm');
  assert.equal(await page.getByRole('rowheader', { name: 'L1Tol' }).count(), 0);
  assert.equal(await page.getByRole('rowheader', { name: /Tol$/ }).count(), 0);
  for (const sym of ['α', 'β', 'δ', 'e min', 'r1 min', 'delta L', 'L3 + G']) {
    assert.ok((await page.getByRole('rowheader', { name: sym, exact: true }).count()) >= 1, sym);
  }
  await context.close();
  const lapua = await openPage(env.browser, detailUrl(fileUrl, '338_lapua_mag'));
  await lapua.page.getByRole('heading', { name: '338 Lapua Mag.', level: 1 }).waitFor();
  const junction = lapua.page.getByRole('table', { name: 'Cartridge values Junction cone' });
  assert.equal((await junction.getByRole('row', { name: /^α / }).innerText()).replace(/\s+/g, ' '), `α 39°59'49" deg`);
  await lapua.context.close();
  const rem = await openPage(env.browser, detailUrl(fileUrl, '7_mm_rem_mag'));
  await rem.page.getByRole('heading', { name: '7 mm Rem. Mag.', level: 1 }).waitFor();
  const rifling = rem.page.getByRole('table', { name: 'Chamber values Rifling' });
  assert.equal((await rifling.getByRole('row', { name: /^i / }).innerText()).replace(/\s+/g, ' '), 'i 3° deg');
  await rem.context.close();
});

test('every detail view renders without errors and lists every value once', async () => {
  const { page, context, problems } = await openPage(env.browser, fileUrl);
  for (const r of DATA) {
    await page.goto(detailUrl(fileUrl, r.key));
    await page.getByRole('heading', { name: r.name, level: 1, exact: true }).waitFor();
    const expected = ['cartridge', 'chamber'].reduce((n, g) => n + Object.values(r[g]).reduce(
      (m, sec) => m + Object.keys(sec).filter((k) => !/Tol$/.test(k)).length, 0), 0);
    const rows = await page.locator('table.values tbody tr').count();
    assert.equal(rows, expected, r.key);
    assert.equal(await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).count(), 1, r.key);
  }
  assert.deepEqual(problems, []);
  await context.close();
});

test('Print button requests the print dialog', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '223_rem'));
  await page.getByRole('heading', { name: '223 Rem.', level: 1 }).waitFor();
  await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed += 1; }; });
  await page.getByRole('button', { name: 'Print' }).click();
  assert.equal(await page.evaluate(() => window.__printed), 1);
  await context.close();
});

test('only the app\'s own files are requested (no network)', async () => {
  for (const [label, url] of targets()) {
    const { page, context, requests } = await openPage(env.browser, url);
    await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
    await page.getByRole('link', { name: '300 Win. Mag.', exact: true }).click();
    await page.getByRole('img', { name: '300 Win. Mag. drawing' }).waitFor();
    const origin = new URL(url).origin;
    for (const r of requests) {
      const u = new URL(r);
      assert.ok(u.protocol === 'file:' || u.origin === origin, `${label} external request ${r}`);
    }
    await context.close();
  }
});

test('phone width: no horizontal scroll, drawing fits the screen', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '9_3_x_74_r'), {
    viewport: { width: 360, height: 740 }, isMobile: true, hasTouch: true
  });
  await page.getByRole('img', { name: '9,3 x 74 R drawing' }).waitFor();
  const m = await page.evaluate(() => ({
    doc: document.documentElement.scrollWidth, win: window.innerWidth,
    svg: document.querySelector('svg.drawing').getBoundingClientRect().width
  }));
  assert.ok(m.doc <= m.win, `page scrolls horizontally: ${m.doc} > ${m.win}`);
  assert.ok(m.svg <= m.win, `svg wider than screen: ${m.svg}`);
  await page.goto(fileUrl);
  await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
  const list = await page.evaluate(() => ({ doc: document.documentElement.scrollWidth, win: window.innerWidth }));
  assert.ok(list.doc <= list.win, 'list scrolls horizontally');
  await context.close();
});

test('light and dark colour schemes follow the system; print is light', async () => {
  const light = await openPage(env.browser, detailUrl(fileUrl, '223_rem'), { colorScheme: 'light' });
  const bgLight = await light.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  await light.context.close();
  const dark = await openPage(env.browser, detailUrl(fileUrl, '223_rem'), { colorScheme: 'dark' });
  await dark.page.getByRole('img', { name: '223 Rem. drawing' }).waitFor();
  const bgDark = await dark.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  const svgBg = await dark.page.evaluate(() => getComputedStyle(document.querySelector('svg.drawing')).backgroundColor);
  assert.notEqual(bgLight, bgDark);
  const lum = (c) => c.match(/\d+/g).slice(0, 3).map(Number).reduce((a, b) => a + b, 0);
  assert.ok(lum(bgLight) > 600, bgLight);
  assert.ok(lum(bgDark) < 150, bgDark);
  assert.ok(lum(svgBg) < 150, svgBg);
  await dark.page.emulateMedia({ media: 'print' });
  const bgPrint = await dark.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.ok(lum(bgPrint) > 700, `print background ${bgPrint}`);
  await dark.context.close();
});

test('skip link moves focus to the content and does not break the route', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '308_win'));
  await page.getByRole('heading', { name: '308 Win.', level: 1 }).waitFor();
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.className), 'skip-link');
  await page.keyboard.press('Enter');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'main');
  await page.getByRole('heading', { name: '308 Win.', level: 1 }).waitFor();
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  await context.close();
});
