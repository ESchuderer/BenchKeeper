import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, fileUrl, detailUrl, DATA } from './helpers.mjs';

let env;
before(async () => { env = await launch(); });
after(async () => { await env.close(); });

/* Runs in the page: measures every label and samples the drawn outline. */
function measure() {
  const svg = document.querySelector('svg.drawing');
  const labels = [...svg.querySelectorAll('text')].map((t) => {
    const b = t.getBBox();
    const g = t.closest('g.dim');
    return { text: t.textContent, owner: g ? g.getAttribute('class') : 'title', x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height };
  });
  const samples = [];
  for (const p of svg.querySelectorAll('g.outline path, g.section path')) {
    const len = p.getTotalLength();
    for (let s = 0; s <= len; s += 0.2) { const q = p.getPointAtLength(s); samples.push([q.x, q.y]); }
  }
  const lines = [...svg.querySelectorAll('g.dim')].map((g) => ({
    owner: g.getAttribute('class'),
    segs: [...g.querySelectorAll('line.dimline, line.ext, line.leader')].map((l) => [
      +l.getAttribute('x1'), +l.getAttribute('y1'), +l.getAttribute('x2'), +l.getAttribute('y2')])
  }));
  const vb = svg.viewBox.baseVal;
  const outlineBox = svg.querySelector('g.outline').getBBox();
  return { labels, samples, lines, vb: { x: vb.x, y: vb.y, w: vb.width, h: vb.height }, outlineBox: [outlineBox.x, outlineBox.y, outlineBox.width, outlineBox.height] };
}

function segmentHitsBox(s, b) {
  let t0 = 0, t1 = 1;
  const dx = s[2] - s[0], dy = s[3] - s[1];
  for (const [p, q] of [[-dx, s[0] - b.x0], [dx, b.x1 - s[0]], [-dy, s[1] - b.y0], [dy, b.y1 - s[1]]]) {
    if (p === 0) { if (q < 0) return false; } else {
      const r = q / p;
      if (p < 0) { if (r > t1) return false; if (r > t0) t0 = r; } else { if (r < t0) return false; if (r < t1) t1 = r; }
    }
  }
  return t0 <= t1;
}

test('all 25 drawings: real text boxes never overlap each other, the outline, or foreign dimension lines', async () => {
  const { page, context, problems } = await openPage(env.browser, fileUrl);
  for (const r of DATA) {
    await page.goto(detailUrl(fileUrl, r.key));
    await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
    const m = await page.evaluate(measure);
    assert.ok(m.labels.length >= 8, `${r.key}: labels ${m.labels.length}`);
    for (let i = 0; i < m.labels.length; i++) {
      const a = m.labels[i];
      assert.ok(a.x0 >= m.vb.x && a.x1 <= m.vb.x + m.vb.w && a.y0 >= m.vb.y && a.y1 <= m.vb.y + m.vb.h, `${r.key} "${a.text}" outside viewBox`);
      for (let j = i + 1; j < m.labels.length; j++) {
        const b = m.labels[j];
        const overlap = a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
        assert.ok(!overlap, `${r.key}: "${a.text}" overlaps "${b.text}"`);
      }
      const pad = 0.15;
      for (const [x, y] of m.samples) {
        assert.ok(!(x > a.x0 - pad && x < a.x1 + pad && y > a.y0 - pad && y < a.y1 + pad), `${r.key}: "${a.text}" overlaps the outline at ${x.toFixed(2)},${y.toFixed(2)}`);
      }
      for (const dim of m.lines) {
        if (dim.owner === a.owner) continue;
        for (const s of dim.segs) assert.ok(!segmentHitsBox(s, a), `${r.key}: "${a.text}" crossed by ${dim.owner}`);
      }
    }
  }
  assert.deepEqual(problems, []);
  await context.close();
});

test('1 SVG user unit = 1 mm: outline spans L6 horizontally and the largest diameter vertically', async () => {
  const { page, context } = await openPage(env.browser, fileUrl);
  for (const r of DATA) {
    await page.goto(detailUrl(fileUrl, r.key));
    await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
    const m = await page.evaluate(measure);
    const [x, y, w, h] = m.outlineBox;
    const c = r.cartridge;
    near(x, 0, `${r.key} head face at x=0`);
    near(w, c.lengths.L6, `${r.key} tip at L6`);
    near(h, Math.max(c.caseHead.R1, c.caseHead.R3 || 0, c.powderChamber.P1), `${r.key} outline height`);
    near(y, -h / 2, `${r.key} symmetric about the axis`);
  }
  await context.close();
});

function near(a, b, msg, eps = 0.01) { assert.ok(Math.abs(a - b) <= eps, `${msg}: ${a} vs ${b}`); }

test('drawing is an image named "<name> drawing" with description, labels, title block and notes', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '308_win'));
  const svg = page.getByRole('img', { name: '308 Win. drawing', exact: true });
  await svg.waitFor();
  for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85',
    'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°', 'Dimensions in mm', 'C.I.P. TDCC table I', 'Revised 2008-09-23']) {
    assert.equal(await svg.getByText(t, { exact: true }).count(), 1, t);
  }
  assert.equal(await svg.getByText('308 Win.', { exact: true }).count(), 1);
  assert.equal(await svg.getByText(/^Scale [\d.]+ : 1/).count(), 1);
  assert.equal(await svg.locator('line.centreline').count(), 1);
  const dash = await svg.locator('line.centreline').evaluate((e) => getComputedStyle(e).strokeDasharray);
  assert.match(dash, /\d/);
  assert.ok((await svg.locator('pattern').count()) >= 2, 'hatch patterns');
  assert.ok((await svg.locator('path.arrow').count()) >= 20);
  await context.close();
});

test('missing values are stated under the drawing', async () => {
  for (const [key, expectation] of [
    ['338_lapua_mag', /r1 min/],
    ['17_hmr', /r1 min[\s\S]*r2|r2/]
  ]) {
    const { page, context } = await openPage(env.browser, detailUrl(fileUrl, key));
    await page.locator('ul.drawing-notes').waitFor();
    assert.match(await page.locator('ul.drawing-notes').innerText(), expectation, key);
    await context.close();
  }
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '223_rem'));
  await page.getByRole('img', { name: '223 Rem. drawing' }).waitFor();
  assert.equal(await page.locator('ul.drawing-notes').count(), 0);
  await context.close();
});

test('shoulder angle label uses degrees, minutes and seconds when published that way', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '6_5_x_55_se'));
  const svg = page.getByRole('img', { name: '6,5 x 55 SE drawing', exact: true });
  await svg.waitFor();
  assert.equal(await svg.getByText(`α 50°35'2"`, { exact: true }).count(), 1);
  await context.close();
});
