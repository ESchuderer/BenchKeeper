import { chromium } from 'playwright';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join } from 'node:path';
import { createRequire } from 'node:module';
import { startServer } from '../scripts/serve.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
export const DATA = require('../js/data.js');
export const fileUrl = pathToFileURL(join(root, 'index.html')).href;

export async function launch() {
  const browser = await chromium.launch();
  const http = await startServer(0);
  return {
    browser,
    httpUrl: `http://127.0.0.1:${http.port}/index.html`,
    async close() { await browser.close(); http.server.close(); }
  };
}

export async function openPage(browser, url, options = {}) {
  const context = await browser.newContext({ viewport: { width: 1200, height: 900 }, ...options });
  const page = await context.newPage();
  const problems = [];
  const requests = [];
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') problems.push(`${m.type()}: ${m.text()}`); });
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  page.on('request', (r) => requests.push(r.url()));
  await page.goto(url);
  return { page, context, problems, requests };
}

export const detailUrl = (base, key) => `${base}#/cartridge/${key}`;
