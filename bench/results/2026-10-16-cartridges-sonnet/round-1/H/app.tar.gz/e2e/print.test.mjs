import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, fileUrl, detailUrl, DATA } from './helpers.mjs';

let env;
before(async () => { env = await launch(); });
after(async () => { await env.close(); });

const PX_PER_MM = 96 / 25.4;
const pageCount = (pdf) => (pdf.toString('latin1').match(/\/Type\s*\/Page(?![s\w])/g) || []).length;

test('every detail view prints as exactly one A4 portrait page', async () => {
  const { page, context } = await openPage(env.browser, fileUrl);
  for (const r of DATA) {
    await page.goto(detailUrl(fileUrl, r.key));
    await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: false });
    assert.equal(pageCount(pdf), 1, `${r.key} prints on ${pageCount(pdf)} pages`);
    const box = pdf.toString('latin1').match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/);
    assert.ok(box, 'media box');
    assert.ok(Math.abs(+box[1] - 595.28) < 1 && Math.abs(+box[2] - 841.89) < 1, `${r.key} page size ${box[1]}x${box[2]}`);
  }
  await context.close();
});

test('print layout: no controls, black on white, header, full-width drawing, tables, footer', async () => {
  const { page, context } = await openPage(env.browser, detailUrl(fileUrl, '223_rem'), { viewport: { width: 718, height: 1047 } });
  await page.getByRole('img', { name: '223 Rem. drawing' }).waitFor();
  await page.emulateMedia({ media: 'print' });
  for (const sel of ['.site-header', '.actions', '.site-footer', '.skip-link']) {
    assert.equal(await page.locator(sel).isVisible(), false, `${sel} hidden in print`);
  }
  assert.equal(await page.getByRole('button', { name: 'Print' }).isVisible(), false);
  assert.equal(await page.getByRole('link', { name: 'All cartridges' }).isVisible(), false);
  assert.equal(await page.getByRole('heading', { name: '223 Rem.', level: 1 }).isVisible(), true);
  const footer = page.locator('.print-footer');
  assert.equal(await footer.isVisible(), true);
  assert.equal((await footer.innerText()).trim(), 'Source: C.I.P. TDCC, revised 2017-05-17.');
  const stats = await page.evaluate(() => {
    const colors = new Set();
    const bgs = new Set();
    for (const e of document.querySelectorAll('main *, body')) {
      if (!e.getClientRects().length) continue;
      const cs = getComputedStyle(e);
      if (e.childNodes.length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())) colors.add(cs.color + '|' + cs.fill);
      if (cs.backgroundColor !== 'rgba(0, 0, 0, 0)') bgs.add(cs.backgroundColor);
    }
    const svg = document.querySelector('svg.drawing');
    const r = svg.getBoundingClientRect();
    const vb = svg.viewBox.baseVal;
    const scale = Math.min(r.width / vb.width, r.height / vb.height);
    const strokes = new Set([...svg.querySelectorAll('line, path.outline, g.outline path')].map((e) => getComputedStyle(e).stroke));
    return { colors: [...colors], bgs: [...bgs], svgWidth: r.width, scale, strokes: [...strokes], bodyBg: getComputedStyle(document.body).backgroundColor,
      docHeight: document.documentElement.scrollHeight };
  });
  assert.ok(stats.colors.every((c) => c.startsWith('rgb(0, 0, 0)')), `non-black text: ${stats.colors.join(' ; ')}`);
  assert.ok(stats.strokes.every((s) => s === 'rgb(0, 0, 0)'), `non-black strokes ${stats.strokes}`);
  assert.deepEqual(stats.bgs.filter((b) => b !== 'rgb(255, 255, 255)'), []);
  assert.ok(Math.abs(stats.svgWidth - 190 * PX_PER_MM) < 2, `drawing width ${stats.svgWidth}px`);
  assert.ok(stats.docHeight <= 277 * PX_PER_MM + 2, `content taller than the A4 print area: ${stats.docHeight}px`);
  await context.close();
});

test('printed drawing labels are legible (>= 8 pt) and the scale text matches the printed scale', async () => {
  const { page, context } = await openPage(env.browser, fileUrl, { viewport: { width: 718, height: 1047 } });
  await page.emulateMedia({ media: 'print' });
  for (const r of DATA) {
    await page.goto(detailUrl(fileUrl, r.key));
    await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
    const m = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const rect = svg.getBoundingClientRect();
      const vb = svg.viewBox.baseVal;
      const scale = Math.min(rect.width / vb.width, rect.height / vb.height); // px per mm
      const sizes = [...svg.querySelectorAll('text')].map((t) => +t.getAttribute('font-size'));
      const label = [...svg.querySelectorAll('text.scale')][0].textContent;
      return { scale, minFont: Math.min(...sizes), label, vbW: vb.width, pxW: rect.width };
    });
    const pt = m.minFont * m.scale * 0.75;
    assert.ok(pt >= 8, `${r.key}: smallest drawing label prints at ${pt.toFixed(1)} pt`);
    const printed = m.scale / PX_PER_MM;
    const shown = m.label.match(/Scale ([\d.]+) : 1/);
    assert.ok(shown, `${r.key} scale text "${m.label}"`);
    assert.ok(Math.abs(+shown[1] - printed) < 0.06, `${r.key}: scale text ${shown[1]} vs ${printed.toFixed(2)}`);
  }
  await context.close();
});
