/* Views and routing for the C.I.P. cartridge reference. Hash routing so it works from file://. */
(function (root) {
  'use strict';

  var CIP = root.CIP;
  var M = CIP.model;
  var DATA = CIP.DATA || [];
  var doc = root.document;

  var state = { query: '', family: 'all' };
  var main = doc.getElementById('main');

  function h(tag, attrs, children) {
    var node = doc.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') node.textContent = attrs[k];
      else node.setAttribute(k, attrs[k]);
    });
    [].concat(children || []).forEach(function (c) {
      node.appendChild(typeof c === 'string' ? doc.createTextNode(c) : c);
    });
    return node;
  }

  function isHttpUrl(url) { return /^https?:\/\//i.test(url); }

  function setTitle(text) { doc.title = text + ' – C.I.P. cartridge reference'; }

  /* ---------- list ---------- */

  function renderRows(tbody, records) {
    tbody.textContent = '';
    records.forEach(function (r) {
      var l3 = r.cartridge && r.cartridge.lengths ? r.cartridge.lengths.L3 : undefined;
      tbody.appendChild(h('tr', {}, [
        h('td', { 'class': 'name' }, [h('a', { href: M.detailHash(r.key), text: r.name })]),
        h('td', { text: r.family }),
        h('td', { 'class': 'num', text: typeof l3 === 'number' ? CIP.format.formatNumber(l3) + ' mm' : '' })
      ]));
    });
  }

  function renderList() {
    setTitle('Cartridges');
    main.textContent = '';
    var tbody = h('tbody');
    var count = h('p', { id: 'count', 'class': 'count', role: 'status' });
    var empty = h('p', { 'class': 'empty', hidden: '', text: 'No cartridge matches the search.' });

    function update() {
      var shown = M.filterRecords(DATA, state);
      renderRows(tbody, shown);
      count.textContent = shown.length + ' cartridges';
      if (shown.length === 0) empty.removeAttribute('hidden'); else empty.setAttribute('hidden', '');
    }

    var search = h('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false', placeholder: 'e.g. 308 or 7,62 x 51' });
    search.value = state.query;
    search.addEventListener('input', function () { state.query = search.value; update(); });

    var family = h('select', { id: 'family' }, [h('option', { value: 'all', text: 'All' })].concat(
      M.FAMILIES.map(function (f) { return h('option', { value: f, text: f }); })));
    family.value = state.family;
    family.addEventListener('change', function () { state.family = family.value; update(); });

    var filters = h('div', { 'class': 'filters' }, [
      h('div', { 'class': 'field' }, [h('label', { 'for': 'search', text: 'Search' }), search]),
      h('div', { 'class': 'field' }, [h('label', { 'for': 'family', text: 'Family' }), family])
    ]);

    var table = h('table', { 'class': 'list', 'aria-labelledby': 'list-heading' }, [
      h('thead', {}, [h('tr', {}, [
        h('th', { scope: 'col', text: 'Name' }),
        h('th', { scope: 'col', text: 'Family' }),
        h('th', { scope: 'col', 'class': 'num', text: 'Case length L3' })
      ])]),
      tbody
    ]);

    main.appendChild(h('h1', { id: 'list-heading', tabindex: '-1', text: 'Cartridges' }));
    main.appendChild(filters);
    main.appendChild(count);
    main.appendChild(h('div', { 'class': 'table-wrap' }, [table]));
    main.appendChild(empty);
    update();
  }

  /* ---------- detail ---------- */

  function metaRow(row) {
    var dd = h('dd');
    if (row.value) dd.appendChild(doc.createTextNode(row.value));
    if (row.link && isHttpUrl(row.link.url)) {
      dd.appendChild(doc.createTextNode(' ('));
      dd.appendChild(h('a', { href: row.link.url, rel: 'noopener noreferrer', text: row.link.text }));
      dd.appendChild(doc.createTextNode(')'));
    }
    if (row.note) dd.appendChild(h('span', { 'class': 'note', text: ' – ' + row.note }));
    return h('div', {}, [h('dt', { text: row.label }), dd]);
  }

  function valueTable(groupId, groupTitle, section) {
    var headingId = groupId + '-' + section.key;
    return h('section', { 'class': 'value-section' }, [
      h('h3', { id: headingId, text: section.title }),
      h('table', { 'class': 'values', 'aria-labelledby': groupId + ' ' + headingId }, [
        h('thead', {}, [h('tr', {}, [
          h('th', { scope: 'col', text: 'Symbol' }),
          h('th', { scope: 'col', 'class': 'num', text: 'Value' }),
          h('th', { scope: 'col', text: 'Unit' })
        ])]),
        h('tbody', {}, section.rows.map(function (r) {
          return h('tr', {}, [
            h('th', { scope: 'row', text: r.symbol }),
            h('td', { 'class': 'num', text: r.value }),
            h('td', { 'class': 'unit', text: r.unit })
          ]);
        }))
      ])
    ]);
  }

  function valueGroup(id, title, group) {
    var sections = M.buildSections(group);
    return h('section', { 'class': 'value-group' }, [
      h('h2', { id: id, text: title }),
      h('div', { 'class': 'value-sections' }, sections.map(function (s) { return valueTable(id, title, s); }))
    ]);
  }

  function renderNotes(notes) {
    if (!notes.length) return null;
    return h('ul', { 'class': 'drawing-notes' }, notes.map(function (n) {
      return h('li', { text: 'Not drawn – ' + n.feature + ': ' + n.missing.join(', ') + ' not published.' });
    }));
  }

  function renderDrawingSection(record) {
    var layout = CIP.layout.layoutDrawing(record);
    var figure = h('figure', { 'class': 'drawing-figure' }, [CIP.drawing.renderDrawing(doc, record, layout)]);
    var notes = renderNotes(layout.notes);
    if (notes) figure.appendChild(h('figcaption', {}, [notes]));
    return h('section', { 'class': 'drawing-section' }, [
      h('h2', { id: 'drawing-heading', text: 'Drawing' }),
      figure
    ]);
  }

  function renderDetail(record) {
    setTitle(record.name);
    main.textContent = '';
    var print = h('button', { type: 'button', 'class': 'print-button', text: 'Print' });
    print.addEventListener('click', function () { root.print(); });
    main.appendChild(h('div', { 'class': 'actions' }, [
      h('a', { href: '#/', 'class': 'back', text: 'All cartridges' }), print
    ]));
    main.appendChild(h('h1', { tabindex: '-1', text: record.name }));
    main.appendChild(h('dl', { 'class': 'meta' }, M.buildMetadata(record).map(metaRow)));
    main.appendChild(renderDrawingSection(record));
    main.appendChild(valueGroup('cartridge-values', 'Cartridge values', record.cartridge));
    main.appendChild(valueGroup('chamber-values', 'Chamber values', record.chamber));
    main.appendChild(h('p', { 'class': 'print-footer', text: 'Source: C.I.P. TDCC, revised ' + record.revised + '.' }));
  }

  function renderNotFound(key) {
    setTitle('Not found');
    main.textContent = '';
    main.appendChild(h('h1', { tabindex: '-1', text: 'Cartridge not found' }));
    main.appendChild(h('p', { text: key ? 'No cartridge has the key "' + key + '".' : 'This address does not exist.' }));
    main.appendChild(h('p', {}, [h('a', { href: '#/', text: 'All cartridges' })]));
  }

  /* ---------- routing ---------- */

  var first = true;

  function route() {
    var r = M.parseRoute(root.location.hash);
    if (r.view === 'detail') renderDetail(M.findByKey(DATA, r.key));
    else if (r.view === 'notfound') renderNotFound(r.key);
    else renderList();
    if (!first) {
      var heading = main.querySelector('h1');
      if (heading) heading.focus({ preventScroll: true });
      root.scrollTo(0, 0);
    }
    first = false;
  }

  function onHashChange() {
    var hash = root.location.hash;
    // Fragments that are not app routes (for example the skip link's #main) must not re-render.
    if (hash !== '' && hash !== '#' && hash.indexOf('#/') !== 0) return;
    route();
  }

  var skip = doc.querySelector('.skip-link');
  if (skip) {
    skip.addEventListener('click', function (e) {
      e.preventDefault();
      main.focus();
    });
  }

  root.addEventListener('hashchange', onHashChange);
  route();

  CIP.app = { route: route, state: state };
})(window);
