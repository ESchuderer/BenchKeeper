/* SVG renderer for the cartridge drawing. Builds DOM nodes with createElementNS only. */
(function (root) {
  'use strict';

  var SVG_NS = 'http://www.w3.org/2000/svg';
  var L = typeof require === 'function' && typeof module !== 'undefined' && module.exports
    ? require('./layout.js') : root.CIP.layout;

  var uid = 0;

  function num(n) { return String(Math.round(n * 1000) / 1000); }

  function el(doc, name, attrs, children) {
    var node = doc.createElementNS(SVG_NS, name);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    (children || []).forEach(function (c) { node.appendChild(c); });
    return node;
  }

  function pathOf(points, sign, close) {
    var d = points.map(function (p, i) {
      return (i === 0 ? 'M' : 'L') + num(p.z) + ' ' + num(sign * p.r);
    }).join(' ');
    return close ? d + ' Z' : d;
  }

  function lineEl(doc, s, cls) {
    return el(doc, 'line', { x1: num(s[0]), y1: num(s[1]), x2: num(s[2]), y2: num(s[3]), 'class': cls });
  }

  function arrowEl(doc, a) {
    var len = L.ARROW_LENGTH, half = L.ARROW_HALF_WIDTH;
    var bx = a.x - a.dx * len, by = a.y - a.dy * len;
    var px = -a.dy * half, py = a.dx * half;
    var d = 'M' + num(a.x) + ' ' + num(a.y) + ' L' + num(bx + px) + ' ' + num(by + py) +
      ' L' + num(bx - px) + ' ' + num(by - py) + ' Z';
    return el(doc, 'path', { d: d, 'class': 'arrow' });
  }

  function textEl(doc, lab) {
    var t = el(doc, 'text', {
      x: num(lab.x), y: num(lab.y), 'text-anchor': lab.anchor, 'font-size': num(lab.size), 'class': lab.cls
    });
    t.textContent = lab.text;
    return t;
  }

  function hatchPattern(doc, id, angle, gap) {
    return el(doc, 'pattern', {
      id: id, width: num(gap), height: num(gap), patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(' + angle + ')'
    }, [el(doc, 'line', { x1: '0', y1: '0', x2: '0', y2: num(gap), 'class': 'hatch-line' })]);
  }

  function describe(lay) {
    var d = lay.drawing;
    var parts = ['Half profile in mm, head on the left: outside view above the axis, section below. All dimensions are listed in the tables below.'];
    if (d.rimType) parts.push('Rim type ' + d.rimType + '.');
    if (lay.notes.length) {
      parts.push('Not drawn: ' + lay.notes.map(function (n) { return n.feature + (n.missing.length ? ' (' + n.missing.join(', ') + ' missing)' : ' (' + n.reason + ')'); }).join('; ') + '.');
    }
    return parts.join(' ');
  }

  function renderDrawing(doc, record, layout) {
    var lay = layout || L.layoutDrawing(record);
    var d = lay.drawing;
    var id = 'dwg' + (++uid);
    var vb = lay.viewBox;
    var svg = el(doc, 'svg', {
      xmlns: SVG_NS,
      'class': 'drawing',
      viewBox: [num(vb.x), num(vb.y), num(vb.w), num(vb.h)].join(' '),
      preserveAspectRatio: 'xMidYMid meet',
      role: 'img',
      'aria-label': record.name + ' drawing',
      'aria-describedby': id + '-desc'
    });
    var desc = el(doc, 'desc', { id: id + '-desc' });
    desc.textContent = describe(lay);
    svg.appendChild(desc);
    svg.appendChild(el(doc, 'defs', {}, [
      hatchPattern(doc, id + '-case', 45, 0.7),
      hatchPattern(doc, id + '-bullet', -45, 0.9)
    ]));

    if (d.outer) {
      var section = el(doc, 'g', { 'class': 'section' });
      if (d.caseSection) {
        section.appendChild(el(doc, 'path', { d: pathOf(d.caseSection, 1, true), 'class': 'cut', fill: 'url(#' + id + '-case)' }));
      }
      if (d.bullet) {
        section.appendChild(el(doc, 'path', { d: pathOf(d.bullet.sectionPolygon, 1, true), 'class': 'cut', fill: 'url(#' + id + '-bullet)' }));
      }
      svg.appendChild(section);

      var upper = d.outer.slice();
      if (d.bullet) upper = upper.concat(d.bullet.exposed, [{ z: d.bullet.tip.z, r: 0 }]);
      svg.appendChild(el(doc, 'g', { 'class': 'outline' }, [
        el(doc, 'path', { d: pathOf(upper, -1, false) }),
        el(doc, 'path', { d: pathOf(upper, 1, false) })
      ]));
      svg.appendChild(el(doc, 'line', {
        x1: num(lay.centerline.x1), y1: '0', x2: num(lay.centerline.x2), y2: '0', 'class': 'centreline'
      }));

      var dimsG = el(doc, 'g', { 'class': 'dimensions' });
      lay.dims.forEach(function (dim) {
        var g = el(doc, 'g', { 'class': 'dim dim-' + dim.id });
        dim.extLines.forEach(function (s) { g.appendChild(lineEl(doc, s, 'ext')); });
        dim.lines.forEach(function (s, i) { g.appendChild(lineEl(doc, s, i === dim.dashLeader ? 'leader' : 'dimline')); });
        dim.arrows.forEach(function (a) { g.appendChild(arrowEl(doc, a)); });
        g.appendChild(textEl(doc, dim.label));
        dimsG.appendChild(g);
      });
      svg.appendChild(dimsG);
    }

    var tb = lay.titleBlock;
    var block = el(doc, 'g', { 'class': 'title-block' }, [
      el(doc, 'rect', { x: num(tb.x), y: num(tb.y), width: num(tb.w), height: num(tb.h), 'class': 'frame' }),
      el(doc, 'line', { x1: num(tb.x + tb.leftW), y1: num(tb.y), x2: num(tb.x + tb.leftW), y2: num(tb.y + tb.h), 'class': 'frame' })
    ]);
    lay.labels.filter(function (l) { return l.owner === 'title'; }).forEach(function (l) { block.appendChild(textEl(doc, l)); });
    svg.appendChild(block);
    return svg;
  }

  var api = { renderDrawing: renderDrawing, SVG_NS: SVG_NS };
  var ns = root.CIP || (root.CIP = {});
  ns.drawing = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
