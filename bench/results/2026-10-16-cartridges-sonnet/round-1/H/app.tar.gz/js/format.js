/* Formatting of published values: numbers, angles, tolerances, symbols, units. */
(function (root) {
  'use strict';

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  var ANGLE_FIELDS = { alpha: true, alpha1: true, beta: true, delta: true, i: true };
  var BAR_FIELDS = { Pmax: true, PK: true, PE: true };
  var DEGREE = '°';

  function formatNumber(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '';
    var s = String(n);
    if (s.indexOf('e') !== -1) {
      s = n.toFixed(20).replace(/0+$/, '').replace(/\.$/, '');
    }
    return s;
  }

  function isAngleField(field) {
    return ANGLE_FIELDS[field] === true;
  }

  function isAngleObject(a) {
    return a !== null && typeof a === 'object' && typeof a.degrees === 'number';
  }

  function formatAngle(a) {
    if (isAngleObject(a)) {
      return formatNumber(a.degrees) + DEGREE + formatNumber(a.minutes || 0) + "'" +
        formatNumber(a.seconds || 0) + '"';
    }
    return formatNumber(a) + DEGREE;
  }

  function angleToDegrees(a) {
    if (isAngleObject(a)) return a.degrees + (a.minutes || 0) / 60 + (a.seconds || 0) / 3600;
    return typeof a === 'number' ? a : undefined;
  }

  function symbolFor(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unitFor(field) {
    if (isAngleField(field)) return 'deg';
    if (BAR_FIELDS[field] === true) return 'bar';
    if (field === 'EE') return 'J';
    if (field === 'M') return 'g';
    if (field === 'Q') return 'mm²';
    if (field === 'N') return '';
    return 'mm';
  }

  function isToleranceField(key) {
    return key.length > 3 && key.slice(-3) === 'Tol';
  }

  function toleranceBase(key) {
    return key.slice(0, -3);
  }

  function formatTolerance(t) {
    return (t > 0 ? '+' : '') + formatNumber(t);
  }

  function formatValue(field, value, tolerance) {
    var text = isAngleField(field) ? formatAngle(value) : formatNumber(value);
    if (typeof tolerance === 'number') text += ' ' + formatTolerance(tolerance);
    return text;
  }

  var api = {
    formatNumber: formatNumber,
    formatAngle: formatAngle,
    angleToDegrees: angleToDegrees,
    isAngleField: isAngleField,
    isAngleObject: isAngleObject,
    symbolFor: symbolFor,
    unitFor: unitFor,
    isToleranceField: isToleranceField,
    toleranceBase: toleranceBase,
    formatTolerance: formatTolerance,
    formatValue: formatValue
  };

  var ns = root.CIP || (root.CIP = {});
  ns.format = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
