/* Cartridge geometry: turns a record into outline, bullet and section data in mm.
   Coordinates are {z, r}: z along the axis from the head face (z = 0) to the mouth,
   r the radius. The brief's "(r, z)" pairs are written here as {z, r}. No DOM. */
(function (root) {
  'use strict';

  var F = typeof require === 'function' && typeof module !== 'undefined' && module.exports
    ? require('./format.js') : root.CIP.format;

  var RAD = Math.PI / 180;
  var NOSE_STEPS = 24;
  var HEELED_TOLERANCE = 0.015;
  var MIN_BODY_WALL = 0.6;
  var BODY_WALL_FACTOR = 1.3;
  var BODY_WALL_LIMIT = 0.35;
  var MIN_HEAD_LENGTH = 2.5;
  var HEAD_FRACTION = 0.25;
  var POCKET_FLOOR = 1.5;
  var PRIMER_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var PRIMER_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  /* Bullet rules: seating depth (x G1), cylinder fraction k of the bullet length. */
  var SEATING = { pointy: 1.0, semi_wadcutter: 0.6 };
  var CYLINDER = { pointy: 0.4, semi_wadcutter: 0.78 };

  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function isAngle(v) { return isNum(v) || F.isAngleObject(v); }
  function pt(z, r) { return { z: z, r: r }; }

  function rimTypeOf(v) {
    if (v.family === 'belted') return 'belted';
    if (v.family === 'rimfire') return 'rimfire';
    if (!isNum(v.R1) || !isNum(v.P1) || v.P1 <= 0) return null;
    var ratio = v.R1 / v.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function interpolate(points, z) {
    if (z <= points[0].z) return points[0].r;
    for (var i = 1; i < points.length; i++) {
      if (points[i].z >= z) {
        var a = points[i - 1], b = points[i];
        if (b.z === a.z) return b.r;
        return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
      }
    }
    return points[points.length - 1].r;
  }

  function arcPoints(cz, cr, radius, from, to, steps) {
    var out = [];
    for (var i = 0; i <= steps; i++) {
      var a = from + ((to - from) * i) / steps;
      out.push(pt(cz + radius * Math.cos(a), cr + radius * Math.sin(a)));
    }
    return out;
  }

  /* Rounds the corner c between segments p->c and c->n with the given tangent length. */
  function filletArc(p, c, n, radius, tangent) {
    var l1 = Math.hypot(c.z - p.z, c.r - p.r), l2 = Math.hypot(n.z - c.z, n.r - c.r);
    var d1 = { z: (c.z - p.z) / l1, r: (c.r - p.r) / l1 };
    var d2 = { z: (n.z - c.z) / l2, r: (n.r - c.r) / l2 };
    var phi1 = Math.atan2(d1.r, d1.z), phi2 = Math.atan2(d2.r, d2.z);
    var delta = phi2 - phi1;
    while (delta > Math.PI) delta -= 2 * Math.PI;
    while (delta < -Math.PI) delta += 2 * Math.PI;
    var sgn = delta >= 0 ? 1 : -1;
    var r = tangent / Math.tan(Math.abs(delta) / 2);
    var t1 = pt(c.z - d1.z * tangent, c.r - d1.r * tangent);
    var center = pt(t1.z + sgn * r * -Math.sin(phi1), t1.r + sgn * r * Math.cos(phi1));
    var steps = Math.max(4, Math.ceil((Math.abs(delta) / RAD) / 2));
    var pts = [];
    for (var i = 0; i <= steps; i++) {
      var phi = phi1 + (delta * i) / steps;
      pts.push(pt(center.z + sgn * r * Math.sin(phi), center.r - sgn * r * Math.cos(phi)));
    }
    return { points: pts, radius: r, requested: radius, tangentLength: tangent };
  }

  function deflection(p, c, n) {
    var a = Math.atan2(c.r - p.r, c.z - p.z), b = Math.atan2(n.r - c.r, n.z - c.z);
    var d = Math.abs(b - a);
    return d > Math.PI ? 2 * Math.PI - d : d;
  }

  function addNote(notes, feature, missing) {
    notes.push({ feature: feature, missing: missing });
  }

  function missingOf(list) {
    return list.filter(function (e) { return !e.ok; }).map(function (e) { return e.name; });
  }

  /* ---------- outer profile ---------- */

  function buildHead(v, rimType, notes) {
    var rimR = v.R1 / 2;
    var pts = [pt(0, 0)];
    var info = { chamfer: false, halfRound: false, rimTopZ: 0, rimEndR: rimR };
    if (rimType === 'rimfire') {
      var rho = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
      if (rho > 0) {
        info.halfRound = true;
        var inner = rimR - rho;
        // bottom quarter: centre (rho, inner), from (0, inner) to (rho, R1/2)
        pts.push.apply(pts, arcPoints(rho, inner, rho, Math.PI, Math.PI / 2, 10));
        if (v.R - rho > rho) pts.push(pt(v.R - rho, rimR));
        // top quarter: centre (R - rho, inner), from (R - rho, R1/2) to (R, inner)
        pts.push.apply(pts, arcPoints(v.R - rho, inner, rho, Math.PI / 2, 0, 10));
        info.rimTopZ = v.R / 2;
        info.rimEndR = inner;
        return { pts: pts, info: info };
      }
    } else {
      var miss = missingOf([{ name: 'β', ok: isAngle(v.beta) }, { name: 'f', ok: isNum(v.f) }]);
      if (miss.length) addNote(notes, 'Head chamfer', miss);
      else if (F.angleToDegrees(v.beta) < 90) {
        var c = Math.min(v.f * Math.tan(F.angleToDegrees(v.beta) * RAD), v.R1 / 4);
        info.chamfer = true;
        info.rimTopZ = v.f;
        pts.push(pt(0, rimR - c), pt(v.f, rimR), pt(v.R, rimR));
        return { pts: pts, info: info };
      }
    }
    pts.push(pt(0, rimR), pt(v.R, rimR));
    return { pts: pts, info: info };
  }

  function buildGroove(v, rimType, notes, pts, info) {
    var eMissing = missingOf([
      { name: 'E', ok: isNum(v.E) }, { name: 'E1', ok: isNum(v.E1) }, { name: 'e min', ok: isNum(v.eMin) }
    ]);
    var published = isNum(v.E) || isNum(v.E1);
    var applies = rimType !== 'rimmed' && rimType !== 'rimfire';
    if (eMissing.length && (published || applies)) addNote(notes, 'Extractor groove', eMissing);
    var last = pts[pts.length - 1];
    if (eMissing.length) {
      pts.push(pt(v.R, v.P1 / 2));
      return { groove: false, belt: false, bodyStart: pt(v.R, v.P1 / 2), floor: null };
    }
    var floorR = v.E1 / 2;
    pts.push(pt(v.R, floorR));
    var floorEnd = pt(v.R + v.eMin, floorR);
    pts.push(floorEnd);
    var out = { groove: true, belt: false, floor: pt(v.R + v.eMin / 2, floorR), floorEnd: floorEnd, rampEnd: null };
    var deltaDeg = F.angleToDegrees(v.delta);
    if (rimType === 'belted') {
      var beltMiss = missingOf([{ name: 'R3', ok: isNum(v.R3) }, { name: 'δ', ok: isNum(deltaDeg) && deltaDeg > 0 && deltaDeg < 90 }]);
      if (beltMiss.length === 0 && v.R3 / 2 > floorR) {
        var zEnd = floorEnd.z + (v.R3 / 2 - floorR) / Math.tan(deltaDeg * RAD);
        if (zEnd <= v.E) {
          pts.push(pt(zEnd, v.R3 / 2), pt(v.E, v.R3 / 2), pt(v.E, v.P1 / 2));
          out.belt = true;
          out.rampEnd = zEnd;
          out.bodyStart = pt(v.E, v.P1 / 2);
          return out;
        }
        notes.push({ feature: 'Belt', missing: [], reason: 'the ramp at \u03b4 does not reach R3 before E' });
      } else if (beltMiss.length === 0) {
        notes.push({ feature: 'Belt', missing: [], reason: 'R3 is not larger than E1' });
      }
      if (beltMiss.length) addNote(notes, 'Belt', beltMiss);
    }
    pts.push(pt(v.E, v.P1 / 2));
    out.bodyStart = pt(v.E, v.P1 / 2);
    return out;
  }

  function buildShoulder(v, body, pts, notes) {
    var core = [{ name: 'α', ok: isAngle(v.alpha) }, { name: 'L1', ok: isNum(v.L1) }, { name: 'L2', ok: isNum(v.L2) }];
    var coreMissing = missingOf(core);
    var res = { shoulder: false, fillets: [], corners: {} };
    var mouth = pt(v.L3, v.H2 / 2);
    if (coreMissing.length === core.length) { pts.push(mouth); res.corners.mouth = mouth; return res; }
    var more = missingOf([{ name: 'P2', ok: isNum(v.P2) }, { name: 'H1', ok: isNum(v.H1) }]);
    var all = coreMissing.concat(more);
    if (all.length) {
      addNote(notes, 'Shoulder', all);
      pts.push(mouth);
      res.corners.mouth = mouth;
      return res;
    }
    var c1 = pt(v.L1, v.P2 / 2), c2 = pt(v.L2, v.H1 / 2);
    res.shoulder = true;
    res.corners = { shoulderStart: c1, shoulderEnd: c2, mouth: mouth };
    var t1 = null, t2 = null;
    var hasR1 = isNum(v.r1Min) && v.r1Min > 0, hasR2 = isNum(v.r2) && v.r2 > 0;
    if (hasR1) t1 = v.r1Min * Math.tan(deflection(body, c1, c2) / 2);
    else if (!isNum(v.r1Min)) addNote(notes, 'Shoulder body-side rounding', ['r1 min']);
    if (hasR2) t2 = v.r2 * Math.tan(deflection(c1, c2, mouth) / 2);
    else if (!isNum(v.r2)) addNote(notes, 'Shoulder neck-side rounding', ['r2']);
    var lBody = Math.hypot(c1.z - body.z, c1.r - body.r), lMid = Math.hypot(c2.z - c1.z, c2.r - c1.r);
    var lNeck = Math.hypot(mouth.z - c2.z, mouth.r - c2.r);
    var share = 0.5;
    var cap1 = Math.min(lBody, lMid) * share, cap2 = Math.min(lMid, lNeck) * share;
    if (t1 !== null && t2 !== null && t1 + t2 > lMid * 0.95) {
      var k = (lMid * 0.95) / (t1 + t2);
      t1 *= k; t2 *= k;
    }
    if (t1 !== null) t1 = Math.min(t1, cap1);
    if (t2 !== null) t2 = Math.min(t2, cap2);
    if (t1 !== null) {
      var a1 = filletArc(body, c1, c2, v.r1Min, t1);
      res.fillets.push({ name: 'r1 min', corner: c1, radius: v.r1Min, tangentLength: t1, drawnRadius: a1.radius });
      pts.push.apply(pts, a1.points);
    } else pts.push(c1);
    if (t2 !== null) {
      var a2 = filletArc(c1, c2, mouth, v.r2, t2);
      res.fillets.push({ name: 'r2', corner: c2, radius: v.r2, tangentLength: t2, drawnRadius: a2.radius });
      pts.push.apply(pts, a2.points);
    } else pts.push(c2);
    pts.push(mouth);
    return res;
  }

  /* ---------- bullet ---------- */

  function bulletRules(shape, category) {
    var pistol = category === 'pistol';
    if (shape === 'pointy') return { s: SEATING.pointy, k: CYLINDER.pointy };
    if (shape === 'semi_wadcutter') return { s: SEATING.semi_wadcutter, k: CYLINDER.semi_wadcutter };
    if (shape === 'rounded') return { s: pistol ? 0.4 : 0.8, k: pistol ? 0.65 : 0.55 };
    if (shape === 'flat') return { s: pistol ? 0.4 : 0.8, k: pistol ? 0.7 : 0.6 };
    return null;
  }

  function meplatFor(shape, g1) {
    if (shape === 'pointy') return Math.max(0.08 * g1, 1.27);
    if (shape === 'rounded') return 0.15 * g1;
    if (shape === 'flat') return 0.55 * g1;
    return 0.6 * g1;
  }

  function nosePoints(shape, zc, rb, g1, n, m) {
    var pts = [];
    var out = { rho: null };
    if (shape === 'pointy') {
      var a = rb - m / 2;
      var rho = (a * a + n * n) / (2 * a);
      var cr = rb - rho;
      var phiEnd = Math.acos((rho - a) / rho);
      for (var i = 1; i <= NOSE_STEPS; i++) {
        var phi = (phiEnd * i) / NOSE_STEPS;
        pts.push(pt(zc + rho * Math.sin(phi), cr + rho * Math.cos(phi)));
      }
      pts[pts.length - 1] = pt(zc + n, m / 2);
      out.rho = rho;
    } else if (shape === 'rounded') {
      var A = rb - m / 2;
      for (var j = 1; j <= NOSE_STEPS; j++) {
        var t = (Math.PI / 2 * j) / NOSE_STEPS;
        pts.push(pt(zc + n * Math.sin(t), m / 2 + A * Math.cos(t)));
      }
      pts[pts.length - 1] = pt(zc + n, m / 2);
    } else {
      pts.push(pt(zc + n, m / 2));
    }
    out.points = pts;
    return out;
  }

  function buildBullet(v, ann, walls, notes) {
    var shape = ann.defaultBulletShape;
    var miss = missingOf([
      { name: 'G1', ok: isNum(v.G1) }, { name: 'L6', ok: isNum(v.L6) }, { name: 'L3', ok: isNum(v.L3) },
      { name: 'bullet shape', ok: typeof shape === 'string' && bulletRules(shape, ann.category) !== null }
    ]);
    if (miss.length) { addNote(notes, 'Bullet', miss); return null; }
    var heeled = isNum(v.H2) && v.H2 - v.G1 <= HEELED_TOLERANCE;
    var rb = (heeled ? v.H2 : v.G1) / 2;
    var rules = bulletRules(shape, ann.category);
    var s = rules.s * v.G1;
    var zb = v.L3 - s;
    var length = v.L6 - zb;
    var zc = zb + rules.k * length;
    var m = meplatFor(shape, heeled ? v.H2 : v.G1);
    var nose = nosePoints(shape, zc, rb, v.G1, v.L6 - zc, m);
    var seatRadius = heeled && walls ? v.H2 / 2 - walls.tb : v.G1 / 2;
    var profile = [];
    if (heeled) profile.push(pt(zb, seatRadius), pt(v.L3, seatRadius), pt(v.L3, rb));
    else profile.push(pt(zb, rb));
    profile.push(pt(zc, rb));
    profile.push.apply(profile, nose.points);
    var exposed;
    if (zc >= v.L3) {
      exposed = [pt(v.L3, rb)];
      if (zc > v.L3) exposed.push(pt(zc, rb));
    } else {
      // the nose already starts inside the case: enter the exposed part on the nose curve
      exposed = [pt(v.L3, interpolate([pt(zc, rb)].concat(nose.points), v.L3))];
    }
    exposed.push.apply(exposed, nose.points.filter(function (p) { return p.z > v.L3; }));
    var tip = nose.points[nose.points.length - 1];
    var sectionPolygon = [pt(zb, 0)].concat(profile).concat([pt(tip.z, 0)]);
    return {
      shape: shape, heeled: heeled, seatDepth: s, zb: zb, zc: zc, length: length, meplat: m, rho: nose.rho,
      radius: rb, seatRadius: seatRadius, profile: profile, exposed: exposed, tip: tip, sectionPolygon: sectionPolygon
    };
  }

  /* ---------- section ---------- */

  function pocketFor(ann, family, notes) {
    var type = ann.primerType;
    if (type === 'rimfire' || family === 'rimfire') return null;
    if (!PRIMER_DIAMETER[type]) { addNote(notes, 'Primer pocket', ['primer type']); return null; }
    return { diameter: PRIMER_DIAMETER[type], depth: PRIMER_DEPTH[type] };
  }

  function wallProfile(v, walls, shoulder, bullet) {
    var tb = walls.tb, tn = walls.tn;
    var breaks = [];
    var fn;
    if (bullet && bullet.heeled) {
      fn = function () { return tb; };
    } else if (shoulder) {
      breaks = [v.L1, v.L2];
      fn = function (z) {
        if (z <= v.L1) return tb;
        if (z >= v.L2) return tn;
        return tb + ((tn - tb) * (z - v.L1)) / (v.L2 - v.L1);
      };
    } else if (bullet) {
      var ledge = Math.abs(tb - tn);
      var start = bullet.zb - ledge;
      breaks = [start, bullet.zb];
      fn = function (z) {
        if (z <= start) return tb;
        if (z >= bullet.zb) return tn;
        return tb + ((tn - tb) * (z - start)) / ledge;
      };
    } else {
      fn = function () { return tb; };
    }
    return { at: fn, breaks: breaks };
  }

  function buildInner(outer, w, L3, walls) {
    var zs = [w, L3];
    outer.forEach(function (p) { if (p.z > w && p.z < L3) zs.push(p.z); });
    walls.breaks.forEach(function (z) { if (z > w && z < L3) zs.push(z); });
    zs.sort(function (a, b) { return a - b; });
    var out = [];
    zs.forEach(function (z, i) {
      if (i > 0 && z - zs[i - 1] < 1e-9) return;
      out.push(pt(z, interpolate(outer, z) - walls.at(z)));
    });
    return out;
  }

  function buildCaseSection(outer, inner, w, pocket, L3) {
    var poly = [];
    var start = pocket ? pocket.diameter / 2 : 0;
    poly.push(pt(0, start));
    outer.forEach(function (p, i) {
      if (i === 0) return;
      if (i === 1 && p.z === 0 && p.r <= start) return;
      poly.push(p);
    });
    var mouthInner = inner[inner.length - 1];
    poly.push(pt(L3, mouthInner.r));
    for (var i = inner.length - 2; i >= 0; i--) poly.push(inner[i]);
    poly.push(pt(w, 0));
    if (pocket) poly.push(pt(pocket.depth, 0), pt(pocket.depth, pocket.diameter / 2));
    return poly;
  }

  /* ---------- main ---------- */

  function valuesOf(record) {
    var c = record.cartridge || {};
    var out = {};
    ['caseHead', 'collar', 'junctionCone', 'lengths', 'powderChamber', 'projectile'].forEach(function (k) {
      var sec = c[k] || {};
      Object.keys(sec).forEach(function (f) { out[f] = sec[f]; });
    });
    out.family = record.family;
    return out;
  }

  function computeDrawing(record) {
    var v = valuesOf(record);
    var ann = record.annotations || {};
    var notes = [];
    var d = {
      name: record.name, key: record.key, values: v, rimType: rimTypeOf(v),
      outer: null, corners: {}, fillets: [], features: {
        chamfer: false, halfRound: false, groove: false, belt: false, shoulder: false, bullet: false, section: false, pocket: false
      },
      bullet: null, walls: null, w: null, pocket: null, inner: null, caseSection: null, beltRampEnd: null,
      anchors: {}, notes: notes
    };

    var need = missingOf([
      { name: 'R1', ok: isNum(v.R1) }, { name: 'R', ok: isNum(v.R) }, { name: 'P1', ok: isNum(v.P1) },
      { name: 'H2', ok: isNum(v.H2) }, { name: 'L3', ok: isNum(v.L3) }
    ]);
    if (need.length) {
      addNote(notes, 'Case outline', need);
      return d;
    }

    var head = buildHead(v, d.rimType, notes);
    var pts = head.pts;
    var groove = buildGroove(v, d.rimType, notes, pts, head.info);
    var body = groove.bodyStart;
    var sh = buildShoulder(v, body, pts, notes);

    d.outer = pts;
    d.corners = sh.corners;
    d.corners.bodyStart = body;
    d.fillets = sh.fillets;
    d.beltRampEnd = groove.rampEnd;
    d.features.chamfer = head.info.chamfer;
    d.features.halfRound = head.info.halfRound;
    d.features.groove = groove.groove;
    d.features.belt = groove.belt;
    d.features.shoulder = sh.shoulder;
    d.anchors = {
      rimTop: pt(head.info.rimTopZ, v.R1 / 2),
      grooveFloor: groove.floor,
      bodyStart: body
    };

    var tn = isNum(v.G1) ? (v.H2 - v.G1) / 2 : null;
    if (tn === null) addNote(notes, 'Section walls', ['G1']);
    else d.walls = { tn: tn, tb: Math.min(Math.max(BODY_WALL_FACTOR * tn, MIN_BODY_WALL), (BODY_WALL_LIMIT * v.P1) / 2) };

    d.bullet = buildBullet(v, ann, d.walls, notes);
    d.features.bullet = d.bullet !== null;
    d.pocket = pocketFor(ann, record.family, notes);
    d.features.pocket = d.pocket !== null;

    if (d.walls) {
      var tb = d.walls.tb;
      var terms = [MIN_HEAD_LENGTH, (HEAD_FRACTION * v.P1) / 2];
      if (d.pocket) terms.push(d.pocket.depth + POCKET_FLOOR);
      if (groove.groove) terms.push(v.E + tb);
      if (groove.belt) terms.push(groove.rampEnd + tb);
      d.w = Math.max.apply(null, terms.concat([body.z]));
      var wall = wallProfile(v, d.walls, sh.shoulder, d.bullet);
      d.inner = buildInner(pts, d.w, v.L3, wall);
      d.caseSection = buildCaseSection(pts, d.inner, d.w, d.pocket, v.L3);
      d.features.section = true;
    }
    return d;
  }

  var api = {
    computeDrawing: computeDrawing,
    rimTypeOf: rimTypeOf,
    interpolate: interpolate,
    isNum: isNum
  };

  var ns = root.CIP || (root.CIP = {});
  ns.geometry = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
