/* Dimension layout: places dimension lines, extension lines, arrowheads, labels and the
   title block around the geometry. Pure data in SVG user units (1 unit = 1 mm):
   x = z, y = -r in the upper half (outside view) and y = +r in the lower half (section). */
(function (root) {
  'use strict';

  var isNode = typeof require === 'function' && typeof module !== 'undefined' && module.exports;
  var F = isNode ? require('./format.js') : root.CIP.format;
  var G = isNode ? require('./geometry.js') : root.CIP.geometry;

  var RAD = Math.PI / 180;
  var FS = 2.6;                         // label font size
  var NAME_FS = 4.2;                    // title block name
  var CHAR = 0.64;                      // monospace advance in em (real fonts 0.55-0.62, plus margin)
  var ROW_PITCH = 1.02 * FS + 0.9;      // diameter label rows
  var LENGTH_PITCH = 4.8;               // horizontal dimension rows
  var ARROW_LEN = 1.4;
  var ARROW_HALF = 0.42;
  var EXT_GAP = 0.8;
  var EXT_OVER = 0.8;
  var MIN_LINE_GAP = 1.8;
  var PAD = 3;
  var MIN_WIDTH = 96;
  var PRINT_WIDTH_MM = 190;
  var PRINT_MAX_HEIGHT_MM = 132;        // keep in step with .drawing max-height in css/app.css (print)
  var RIM_LINE_Z = -4;

  function textWidth(text, size) { return text.length * CHAR * size; }

  function textBox(x, base, anchor, text, size) {
    var w = textWidth(text, size);
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0: x0, x1: x0 + w, y0: base - 0.8 * size, y1: base + 0.22 * size };
  }

  function boxesOverlap(a, b, pad) {
    return a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
  }

  function segmentHitsBox(s, b, pad) {
    var x0 = b.x0 - pad, x1 = b.x1 + pad, y0 = b.y0 - pad, y1 = b.y1 + pad;
    var t0 = 0, t1 = 1, dx = s[2] - s[0], dy = s[3] - s[1];
    var checks = [[-dx, s[0] - x0], [dx, x1 - s[0]], [-dy, s[1] - y0], [dy, y1 - s[1]]];
    for (var i = 0; i < checks.length; i++) {
      var p = checks[i][0], q = checks[i][1];
      if (p === 0) { if (q < 0) return false; } else {
        var r = q / p;
        if (p < 0) { if (r > t1) return false; if (r > t0) t0 = r; }
        else { if (r < t0) return false; if (r < t1) t1 = r; }
      }
    }
    return t0 <= t1;
  }

  function formatScale(s) {
    var r = function (n) { return String(Math.round(n * 10) / 10); };
    return s >= 1 ? 'Scale ' + r(s) + ' : 1' : 'Scale 1 : ' + r(1 / s);
  }

  function arrow(x, y, dx, dy) { return { x: x, y: y, dx: dx, dy: dy }; }

  function makeLabel(owner, text, x, base, anchor, size, cls) {
    return { owner: owner, text: text, x: x, y: base, anchor: anchor, size: size, cls: cls, box: textBox(x, base, anchor, text, size) };
  }

  function valueText(v, value) { return F.isAngleObject(value) ? F.formatAngle(value) : F.formatNumber(value); }

  /* ---------- outline segments (for overlap checks) ---------- */

  function polySegments(points, sign, closed) {
    var segs = [];
    for (var i = 1; i < points.length; i++) {
      segs.push([points[i - 1].z, sign * points[i - 1].r, points[i].z, sign * points[i].r]);
    }
    if (closed) segs.push([points[points.length - 1].z, sign * points[points.length - 1].r, points[0].z, sign * points[0].r]);
    return segs;
  }

  function outlineOf(d) {
    var upper = d.outer.slice();
    if (d.bullet) {
      upper = upper.concat(d.bullet.exposed, [{ z: d.bullet.tip.z, r: 0 }]);
    }
    var segs = polySegments(upper, -1, false).concat(polySegments(upper, 1, false));
    if (d.caseSection) segs = segs.concat(polySegments(d.caseSection, 1, true));
    if (d.bullet) segs = segs.concat(polySegments(d.bullet.sectionPolygon, 1, true));
    return { upper: upper, segments: segs };
  }

  function maxRadius(points) {
    return points.reduce(function (m, p) { return Math.max(m, p.r); }, 0);
  }

  function maxRadiusBetween(points, z0, z1) {
    var m = Math.max(G.interpolate(points, z0), G.interpolate(points, z1));
    points.forEach(function (p) { if (p.z >= z0 && p.z <= z1) m = Math.max(m, p.r); });
    return m;
  }

  /* ---------- diameter dimensions (vertical lines, labels in rows above) ---------- */

  function diameterSpecs(d) {
    var v = d.values;
    var specs = [];
    function add(id, value, zFeature, zLine, movable) {
      if (!G.isNum(value)) return;
      specs.push({ id: id, value: value, r: value / 2, zFeature: zFeature, zLine: zLine, movable: movable });
    }
    add('R1', v.R1, d.anchors.rimTop.z, RIM_LINE_Z, false);
    if (d.features.groove) add('E1', v.E1, d.anchors.grooveFloor.z, d.anchors.grooveFloor.z, false);
    add('P1', v.P1, d.anchors.bodyStart.z, d.anchors.bodyStart.z + 1.5, true);
    if (d.features.shoulder) {
      add('P2', v.P2, v.L1, v.L1 + 1.2, true);
      add('H1', v.H1, v.L2, v.L2 + 1.2, true);
    }
    add('H2', v.H2, v.L3, v.L3 + 1.2, true);
    if (d.bullet) add('G1', v.G1, v.L3, v.L3 + 3.2, true);
    specs.sort(function (a, b) { return a.zLine - b.zLine; });
    for (var i = 1; i < specs.length; i++) {
      if (specs[i].movable && specs[i].zLine < specs[i - 1].zLine + MIN_LINE_GAP) {
        specs[i].zLine = specs[i - 1].zLine + MIN_LINE_GAP;
      }
    }
    return specs;
  }

  function assignRows(specs) {
    var byRight = specs.slice().sort(function (a, b) { return b.zLine - a.zLine; });
    byRight.forEach(function (s, i) {
      s.text = s.id + ' ' + F.formatNumber(s.value);
      s.span = 0.8 + textWidth(s.text, FS) + 0.8;
      var row = 0;
      for (var j = 0; j < i; j++) {
        if (byRight[j].zLine <= s.zLine + s.span) row = Math.max(row, byRight[j].row);
      }
      s.row = row + 1;
    });
  }

  function diameterDim(s, rTop) {
    var rowBottom = rTop + 1.0 + (s.row - 1) * ROW_PITCH;
    var base = -(rowBottom + 0.22 * FS);
    var label = makeLabel(s.id, s.text, s.zLine + 0.8, base, 'start', FS, 'dim-label');
    var x = s.zLine;
    var dir = s.zFeature <= s.zLine ? 1 : -1;
    var lines = [[x, s.r, x, -s.r]];
    var ext = [[x, -s.r - EXT_GAP * 0.5, x, label.box.y0]];
    if (Math.abs(s.zLine - s.zFeature) > 0.3) {
      ext.push([s.zFeature, -s.r, x + dir * EXT_OVER, -s.r], [s.zFeature, s.r, x + dir * EXT_OVER, s.r]);
    }
    return {
      id: s.id, kind: 'diameter', symbol: s.id, value: s.value, measure: [-s.r, s.r],
      lines: lines, extLines: ext, arrows: [arrow(x, -s.r, 0, -1), arrow(x, s.r, 0, 1)], label: label
    };
  }

  /* ---------- length dimensions (horizontal lines, nested rows below) ---------- */

  function lengthSpecs(d) {
    var v = d.values;
    var specs = [];
    function add(id, value, rEnd) { if (G.isNum(value)) specs.push({ id: id, value: value, rEnd: rEnd }); }
    add('R', v.R, v.R1 / 2);
    if (d.features.shoulder) {
      add('L1', v.L1, v.P2 / 2);
      add('L2', v.L2, v.H1 / 2);
    }
    add('L3', v.L3, v.H2 / 2);
    if (d.bullet) add('L6', v.L6, d.bullet.tip.r);
    specs.sort(function (a, b) { return a.value - b.value; });
    return specs;
  }

  function lengthDim(s, rTop, index, r0) {
    var y = rTop + 2.4 + index * LENGTH_PITCH;
    var text = s.id + ' ' + F.formatNumber(s.value);
    var outside = s.value < textWidth(text, FS) + 1.2;
    var label;
    var lines;
    var arrows;
    if (outside) {
      label = makeLabel(s.id, text, s.value + 2.2 + 0.8, y + 0.3 * FS, 'start', FS, 'dim-label');
      lines = [[-2.2, y, s.value + 2.2, y]];
      arrows = [arrow(0, y, 1, 0), arrow(s.value, y, -1, 0)];
    } else {
      label = makeLabel(s.id, text, s.value / 2, y - 0.7, 'middle', FS, 'dim-label');
      lines = [[0, y, s.value, y]];
      arrows = [arrow(0, y, -1, 0), arrow(s.value, y, 1, 0)];
    }
    var ext = [
      [0, r0 + EXT_GAP, 0, y + EXT_OVER + 0.6],
      [s.value, s.rEnd + EXT_GAP, s.value, y + EXT_OVER + 0.6]
    ];
    return { id: s.id, kind: 'length', symbol: s.id, value: s.value, measure: [0, s.value], lines: lines, extLines: ext, arrows: arrows, label: label };
  }

  /* ---------- shoulder angle ---------- */

  function alphaCandidate(d, dx, rows) {
    var v = d.values;
    var alpha = F.angleToDegrees(v.alpha);
    var half = (alpha / 2) * RAD;
    var rho = Math.max(4.2, 2.2 / Math.sin(half));
    var ell = rho + 1.8;
    var vz = v.L1 - dx;
    var zl = vz - ell * Math.cos(half);
    var rv = maxRadiusBetween(d.outer, zl, vz) + 0.8 + ell * Math.sin(half) + Math.max(0, rows.lift || 0);
    var text = 'α ' + F.formatAngle(v.alpha);
    var top = rv + ell * Math.sin(half);
    var label = makeLabel('alpha', text, vz + 0.4, -(top + 0.9 + 0.22 * FS), 'end', FS, 'dim-label');
    var vy = -rv;
    var upper = [zl, vy - ell * Math.sin(half)];
    var lower = [zl, vy + ell * Math.sin(half)];
    var arcPts = [];
    var steps = 12;
    for (var i = 0; i <= steps; i++) {
      var phi = Math.PI + half - (2 * half * i) / steps;
      arcPts.push([vz + rho * Math.cos(phi), vy + rho * Math.sin(phi)]);
    }
    var lines = [];
    for (var k = 1; k < arcPts.length; k++) lines.push([arcPts[k - 1][0], arcPts[k - 1][1], arcPts[k][0], arcPts[k][1]]);
    lines.push([vz, vy, v.L1, -v.P2 / 2]); // leader to the shoulder start
    var ext = [[vz, vy, upper[0], upper[1]], [vz, vy, lower[0], lower[1]]];
    var pu = arcPts[0], pl = arcPts[arcPts.length - 1];
    var dim = {
      id: 'alpha', kind: 'angle', symbol: 'α', value: alpha, measure: [0, alpha], lines: lines, extLines: ext,
      arrows: [arrow(pu[0], pu[1], Math.sin(half), -Math.cos(half)), arrow(pl[0], pl[1], Math.sin(half), Math.cos(half))],
      label: label, dashLeader: lines.length - 1
    };
    var region = {
      x0: Math.min(zl, label.box.x0), x1: Math.max(vz, label.box.x1),
      y0: Math.min(label.box.y0, upper[1]), y1: Math.max(label.box.y1, lower[1])
    };
    return { dim: dim, region: region };
  }

  function alphaCollides(cand, others) {
    var own = cand.dim.lines.concat(cand.dim.extLines);
    for (var i = 0; i < others.length; i++) {
      var o = others[i];
      if (boxesOverlap(cand.region, o.label.box, 0.4)) return true;
      var j;
      var segs = o.lines.concat(o.extLines);
      for (j = 0; j < segs.length; j++) if (segmentHitsBox(segs[j], cand.region, 0.2)) return true;
      for (j = 0; j < own.length; j++) if (segmentHitsBox(own[j], o.label.box, 0.3)) return true;
    }
    return false;
  }

  /* Tries the spot above the shoulder first, then slides left, then lifts above the label rows. */
  function placeAlpha(d, others, rowsTop) {
    var rTop = maxRadius(d.outer);
    var lifts = [0];
    for (var r = rTop + 1.0 + ROW_PITCH; r <= rowsTop + ROW_PITCH; r += ROW_PITCH) lifts.push(r - rTop);
    for (var li = 0; li < lifts.length; li++) {
      for (var dx = 0; dx <= 8; dx++) {
        var cand = alphaCandidate(d, dx, { lift: lifts[li] });
        if (!alphaCollides(cand, others)) return cand.dim;
      }
    }
    return alphaCandidate(d, 0, { lift: rowsTop - rTop + 1.5 }).dim;
  }

  /* ---------- title block ---------- */

  function titleBlock(d, record, x1, y) {
    var tableText = 'C.I.P. TDCC table ' + record.tab;
    var revisedText = 'Revised ' + record.revised;
    var leftW = Math.max(textWidth(record.name, NAME_FS), textWidth('Dimensions in mm', FS)) + 4;
    var rightW = Math.max(textWidth(tableText, FS), textWidth(revisedText, FS), textWidth('Scale 99.9 : 1 (A4)', FS)) + 4;
    return { w: leftW + rightW, h: 13.6, leftW: leftW, tableText: tableText, revisedText: revisedText, x1: x1, y: y };
  }

  /* ---------- main ---------- */

  function layoutDrawing(record) {
    var d = G.computeDrawing(record);
    var labels = [];
    var dims = [];
    var outline = null;
    var rTop = 0;
    var contentX0 = 0, contentX1 = 0, topY = 0, bottomY = 0;

    if (d.outer) {
      outline = outlineOf(d);
      rTop = maxRadius(outline.upper);
      var dspecs = diameterSpecs(d);
      assignRows(dspecs);
      var rows = dspecs.reduce(function (m, s) { return Math.max(m, s.row); }, 0);
      dspecs.forEach(function (s) { dims.push(diameterDim(s, rTop)); });
      var rowsTop = rTop + 1.0 + rows * ROW_PITCH;
      if (d.features.shoulder) dims.push(placeAlpha(d, dims.slice(), rowsTop));
      lengthSpecs(d).forEach(function (s, i) { dims.push(lengthDim(s, rTop, i, d.values.R1 / 2)); });
      dims.forEach(function (dim) { labels.push(dim.label); });
      contentX0 = Math.min(RIM_LINE_Z - 1.2, -2.5);
      contentX1 = d.bullet ? d.bullet.tip.z + 3 : d.values.L3 + 3;
      topY = -rowsTop;
      var lengths = dims.filter(function (x) { return x.kind === 'length'; });
      bottomY = lengths.length ? lengths[lengths.length - 1].lines[0][1] + 3.2 : rTop + 3;
      dims.forEach(function (dim) {
        var b = dim.label.box;
        contentX0 = Math.min(contentX0, b.x0 - 0.5); contentX1 = Math.max(contentX1, b.x1 + 0.5);
        topY = Math.min(topY, b.y0);
        dim.lines.concat(dim.extLines).forEach(function (s) { contentX0 = Math.min(contentX0, s[0], s[2]); contentX1 = Math.max(contentX1, s[0], s[2]); });
      });
    } else {
      contentX0 = 0; contentX1 = 0; topY = 0; bottomY = 0;
    }

    var tb = titleBlock(d, record, 0, 0);
    var width = Math.max(contentX1 - contentX0 + 2 * PAD, tb.w + 2 * PAD, MIN_WIDTH);
    var x0 = (contentX0 + contentX1) / 2 - width / 2;
    var x1 = x0 + width;
    var blockY = bottomY + 1.5;
    var tbX = x1 - PAD - tb.w;
    var tx = tbX + tb.leftW + 2;
    var y0 = topY - PAD;
    var y1 = blockY + tb.h + PAD;
    var scaleText = formatScale(Math.min(PRINT_WIDTH_MM / width, PRINT_MAX_HEIGHT_MM / (y1 - y0))) + ' (A4)';
    var titleLabels = [
      makeLabel('title', record.name, tbX + 2, blockY + 5.6, 'start', NAME_FS, 'title-name'),
      makeLabel('title', 'Dimensions in mm', tbX + 2, blockY + 10.6, 'start', FS, 'title-text'),
      makeLabel('title', tb.tableText, tx, blockY + 3.9, 'start', FS, 'title-text'),
      makeLabel('title', tb.revisedText, tx, blockY + 7.9, 'start', FS, 'title-text'),
      makeLabel('title', scaleText, tx, blockY + 11.9, 'start', FS, 'title-text scale')
    ];
    labels = labels.concat(titleLabels);
    return {
      drawing: d,
      dims: dims,
      labels: labels,
      outlineSegments: outline ? outline.segments : [],
      viewBox: { x: x0, y: y0, w: width, h: y1 - y0 },
      titleBlock: { x: tbX, y: blockY, w: tb.w, h: tb.h, leftW: tb.leftW },
      centerline: d.outer ? { x1: -2.5, x2: (d.bullet ? d.bullet.tip.z : d.values.L3) + 3 } : null,
      scaleText: scaleText,
      notes: d.notes
    };
  }

  var api = {
    layoutDrawing: layoutDrawing,
    formatScale: formatScale,
    textWidth: textWidth,
    PRINT_WIDTH_MM: PRINT_WIDTH_MM,
    PRINT_MAX_HEIGHT_MM: PRINT_MAX_HEIGHT_MM,
    FONT_SIZE: FS,
    ARROW_LENGTH: ARROW_LEN,
    ARROW_HALF_WIDTH: ARROW_HALF
  };

  var ns = root.CIP || (root.CIP = {});
  ns.layout = api;
  if (isNode) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
