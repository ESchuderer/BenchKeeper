/* Data model helpers: value rows, metadata, search and filter, routes. */
(function (root) {
  'use strict';

  var F = typeof require === 'function' && typeof module !== 'undefined' && module.exports
    ? require('./format.js') : root.CIP.format;

  var SECTION_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Misc',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling'
  };

  var FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var NOT_PUBLISHED = 'Not published';

  function sectionTitle(key) {
    return Object.prototype.hasOwnProperty.call(SECTION_TITLES, key) ? SECTION_TITLES[key] : key;
  }

  function buildRows(section) {
    var rows = [];
    Object.keys(section).forEach(function (field) {
      if (F.isToleranceField(field)) return;
      var tol = section[field + 'Tol'];
      rows.push({
        field: field,
        symbol: F.symbolFor(field),
        value: F.formatValue(field, section[field], tol),
        unit: F.unitFor(field)
      });
    });
    return rows;
  }

  function buildSections(group) {
    return Object.keys(group)
      .map(function (key) {
        return { key: key, title: sectionTitle(key), rows: buildRows(group[key]) };
      })
      .filter(function (s) { return s.rows.length > 0; });
  }

  function buildCapacity(record) {
    var cap = record.annotations && record.annotations.publishedCapacity;
    if (!cap || typeof cap.grH2O !== 'number') return { label: 'Water capacity', value: NOT_PUBLISHED };
    var row = { label: 'Water capacity', value: F.formatNumber(cap.grH2O) + ' grH2O' };
    if (cap.url) row.link = { text: cap.source || cap.url, url: cap.url };
    if (cap.note) row.note = cap.note;
    return row;
  }

  function buildMetadata(record) {
    var ann = record.annotations || {};
    return [
      { label: 'Alternative names', value: (record.alternativeNames || []).join(', ') },
      { label: 'Family', value: record.family },
      { label: 'Category', value: ann.category || '' },
      { label: 'Primer type', value: ann.primerType || '' },
      { label: 'C.I.P. table', value: record.tab },
      { label: 'Country', value: record.country },
      { label: 'Published', value: record.published },
      { label: 'Revised', value: record.revised },
      { label: 'Pressure method', value: record.pressureMethod },
      buildCapacity(record)
    ];
  }

  function normalize(text) {
    return String(text).toLowerCase().replace(/\./g, ',').replace(/\s+/g, ' ').trim();
  }

  function matchesQuery(record, query) {
    var q = normalize(query);
    if (q === '') return true;
    return [record.name].concat(record.alternativeNames || []).some(function (n) {
      return normalize(n).indexOf(q) !== -1;
    });
  }

  function filterRecords(records, filter) {
    var family = filter.family || 'all';
    return records.filter(function (r) {
      return (family === 'all' || r.family === family) && matchesQuery(r, filter.query || '');
    });
  }

  function findByKey(records, key) {
    return records.filter(function (r) { return r.key === key; })[0];
  }

  function detailHash(key) {
    return '#/cartridge/' + encodeURIComponent(key);
  }

  function parseRoute(hash) {
    var h = String(hash || '');
    if (h === '' || h === '#' || h === '#/') return { view: 'list' };
    var m = /^#\/cartridge\/([^/]*)$/.exec(h);
    if (!m) return { view: 'notfound', key: '' };
    var key;
    try { key = decodeURIComponent(m[1]); } catch (e) { return { view: 'notfound', key: '' }; }
    var known = root.CIP && root.CIP.DATA ? findByKey(root.CIP.DATA, key) : undefined;
    return known || !root.CIP || !root.CIP.DATA
      ? { view: 'detail', key: key }
      : { view: 'notfound', key: key };
  }

  var api = {
    FAMILIES: FAMILIES,
    sectionTitle: sectionTitle,
    buildRows: buildRows,
    buildSections: buildSections,
    buildMetadata: buildMetadata,
    matchesQuery: matchesQuery,
    filterRecords: filterRecords,
    findByKey: findByKey,
    detailHash: detailHash,
    parseRoute: parseRoute
  };

  var ns = root.CIP || (root.CIP = {});
  ns.model = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
