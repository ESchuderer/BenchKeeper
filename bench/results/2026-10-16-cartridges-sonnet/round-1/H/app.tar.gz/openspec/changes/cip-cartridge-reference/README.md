# cip-cartridge-reference

Static reference database of 25 C.I.P. cartridges with computed 2D drawings
