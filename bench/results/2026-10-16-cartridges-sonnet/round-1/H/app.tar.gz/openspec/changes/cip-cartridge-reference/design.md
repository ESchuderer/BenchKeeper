## Context

Greenfield, static, offline. Must run from `file://` in Chromium, so: no ES modules (blocked by CORS on `file://`), no `fetch` of JSON, no `history.pushState` path routing. 25 records, used verbatim.

## Decisions

1. **Classic scripts + one namespace.** Each file is an IIFE that attaches to `globalThis.CIP` and also sets `module.exports` when run under Node, so the same pure code is unit-tested with `node:test` and loaded by `index.html` with `<script src>`.
2. **Data as `js/data.js`.** `data/cartridges.jsonl` is the verbatim brief; `scripts/build-data.mjs` (dev only) emits `js/data.js` (`CIP.DATA = [...]`). A test asserts both are identical, so `file://` needs no fetch.
3. **Hash routing.** `#/` list, `#/cartridge/<key>` detail. Works on `file://` and any static server, survives reload, bookmarkable. Filter state is kept in memory so "All cartridges" restores it.
4. **Pure geometry, thin renderer.** `geometry.js` turns a record into `{profile, bullet, section, dims, notes}` in mm with z along the axis (rule coordinates are `(r, z)` pairs; code uses `{z, r}` objects). `layout.js` places dimension labels. `drawing.js` only serialises to SVG nodes (created with `createElementNS`, never `innerHTML`).
5. **Drawing layout.** y = ∓r (upper half = outside view). Diameters (R1, E1, P1, P2, H1, H2, G1) are vertical dimension lines whose labels sit in staggered rows above the part (rightmost line gets the lowest row, labels start at their line and run right, so no line crosses a foreign label). Lengths (R, L1, L2, L3, L6) are nested horizontal dimension lines below the part in ascending order, so extension lines never cross a foreign dimension line. α is a small V symbol above the shoulder whose legs are parallel to the shoulder generators (included angle). Monospace label font so text width is `0.6 em × chars` and layout is deterministic without measuring.
6. **Scale text.** A screen scale is meaningless (it depends on window and monitor), so the title block states the A4 print scale, `min(190 mm / viewBox width, 132 mm / viewBox height)`, e.g. `Scale 1.8 : 1 (A4)`. The 190 mm width and the 132 mm height cap are the same constants in `layout.js` and the print CSS; an e2e test compares the text with the rendered print scale.
7. **Missing values.** Every feature declares the values it needs; geometry reports `notes: [{feature, missing:[…]}]`, shown under the drawing and in the SVG `<desc>`. Nothing is defaulted.
8. **Straight non-heeled case wall.** The brief fixes tb (body) and tn (neck) but a straight case has no neck, while the bullet (radius G1/2) must fit the mouth. The wall is tb up to the bullet base and eases to tn over a 45° ledge (length |tb − tn|) ending at the base, so the seated bullet never overlaps the wall. Heeled cases keep tb to the mouth.
9. **Print.** One `@page` A4 portrait rule; tables flow in four CSS columns; drawing `width:100%` with a height cap; light colour variables forced; a fixed print-only footer.
10. **Theming.** CSS custom properties, `prefers-color-scheme`; the SVG uses the same variables, print resets them.
11. **Security.** No `innerHTML` with data; external source URLs are only linked when `http(s)`, with `rel="noopener noreferrer"`; a restrictive CSP meta (`default-src 'none'`, own scripts/styles only).

## Risks / trade-offs

- Vertical diameter dimension lines cross the section. Accepted: thin, light lines; it keeps labels clear of the outline.
- The α symbol is a detail, not constructed at the true apex (the apex lies inside the neck/bullet); legs are exact in direction.
- Headless Chromium here lacks system libraries; they are unpacked under `/tmp` and exposed through `LD_LIBRARY_PATH` for e2e runs only.

## Open questions

None blocking; assumptions are recorded above (items 5, 6, 8).
