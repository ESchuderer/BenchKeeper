## Why

Reloaders, gunsmiths and engineers need a quick, trustworthy, offline reference for C.I.P. cartridge and chamber dimensions, with a drawing that is true to scale. The OpenBallistics cartridge database has the data, but no single static, dependency-free page that can be opened from disk, bookmarked per cartridge, and printed as one A4 data sheet.

## What Changes

- New static web app (`index.html` + CSS + JS, no framework, no build step, no network) listing 25 C.I.P. cartridges from the supplied records only.
- Start page with search (name and alternative names), family filter and live count.
- Detail view per cartridge at its own hash address: metadata, computed 2D drawing, cartridge and chamber value tables (Symbol / Value / Unit), Print button, link back.
- Computed inline-SVG drawing, 1 user unit = 1 mm, outside view above the axis, hatched section below, dimension lines, title block, explicit notes for missing values.
- Print stylesheet: one A4 portrait page per detail view; light and dark screen themes.
- Dev-only tooling: `node:test` unit tests and Playwright end-to-end tests.

## Capabilities

### New Capabilities
- `cartridge-catalogue`: start page, search, family filter, count, routing to detail views.
- `cartridge-detail`: detail view content, value formatting, symbols, units, tolerances, angles.
- `cartridge-drawing`: geometry rules, dimension labelling, title block, missing-value handling.
- `print-and-appearance`: print layout, theming, responsiveness, delivery constraints.

### Modified Capabilities
<!-- none: greenfield -->

## Impact

- New files only: `index.html`, `css/`, `js/`, `data/`, `test/`, `e2e/`, `package.json` (dev dependencies only).
- Data is used exactly as supplied (25 JSONL records, OpenBallistics commit e83db43, MIT); nothing is fetched, added or changed.
