## ADDED Requirements

### Requirement: Cartridge list
The start page SHALL show the heading "Cartridges" and every cartridge with its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name` and which opens that cartridge's detail view.

#### Scenario: Start page lists all records
- **WHEN** the start page is opened with no filter
- **THEN** the heading "Cartridges" is shown, 25 cartridge links are listed and the text "25 cartridges" is shown

#### Scenario: Link text is the published name
- **WHEN** the list is shown
- **THEN** a link with the text `6,5 Creedmoor` exists and no link text is altered or decorated

### Requirement: Search by name and alternative names
A field labelled "Search" SHALL filter the list as the user types, matching the name and the alternative names, case-insensitively.

#### Scenario: Alternative name matches
- **WHEN** the user types `7,62 x 51`
- **THEN** only "308 Win." is listed and the text "1 cartridges" is shown

#### Scenario: No match
- **WHEN** the user types text that matches nothing
- **THEN** no cartridge is listed and the text "0 cartridges" is shown

### Requirement: Family filter
A select labelled "Family" SHALL offer All, rimless, rimmed, belted, pistol, rimfire and filter the list by the record's family. It SHALL combine with the search field.

#### Scenario: Filter by family
- **WHEN** the user selects "belted"
- **THEN** exactly "300 Win. Mag." and "7 mm Rem. Mag." are listed and "2 cartridges" is shown

### Requirement: Addressable detail views
Each detail view SHALL have its own address that survives a reload and can be bookmarked, and SHALL work when `index.html` is opened from disk.

#### Scenario: Reload keeps the view
- **WHEN** the user opens a cartridge and reloads the page
- **THEN** the same cartridge detail view is shown

#### Scenario: Unknown address
- **WHEN** the address names no cartridge
- **THEN** a "not found" message with a link "All cartridges" is shown
