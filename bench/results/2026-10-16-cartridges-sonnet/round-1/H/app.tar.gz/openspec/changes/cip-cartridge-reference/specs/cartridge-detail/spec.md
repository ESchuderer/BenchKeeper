## ADDED Requirements

### Requirement: Detail header and metadata
The detail view SHALL show the cartridge name as heading, then alternative names, family, category, primer type, C.I.P. table, country, published and revised dates, pressure method, and the published water capacity with a link to its source.

#### Scenario: Metadata for 308 Win.
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the alternative names "308 Winchester" and "7,62 x 51", family "rimless", C.I.P. table "I", the water capacity "56" with a link to `http://kwk.us/cases.html` are shown

#### Scenario: Water capacity not published
- **WHEN** a record has no published capacity
- **THEN** the detail view states that it is not published and shows no link

### Requirement: Value tables
The detail view SHALL show all cartridge values and all chamber values in tables grouped by section, with the columns "Symbol", "Value" and "Unit". Empty sections SHALL be omitted.

#### Scenario: Every value appears once
- **WHEN** a detail view is shown
- **THEN** every non-tolerance numeric field of `cartridge` and `chamber` appears in exactly one row of its section's table

### Requirement: Published formatting
Values SHALL be shown as published with a decimal point and no thousands separator, with the unit in the Unit column. Lengths and diameters are mm; Pmax, PK, PE bar; EE J; M g; Q mm²; N is a count without unit. Names SHALL be shown as published.

#### Scenario: Units
- **WHEN** the 308 Win. tables are shown
- **THEN** L3 is `51.18` with unit `mm`, Pmax is `4150` with unit `bar`, EE is `3920` with unit `J`

### Requirement: Symbols
The Symbol column SHALL show the field name, except `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G".

#### Scenario: Replaced symbols
- **WHEN** the tables of "223 Rem." are shown
- **THEN** rows with the symbols "α", "β", "δ", "e min", "r1 min", "delta L" and "L3 + G" exist

### Requirement: Tolerances
A field `<X>Tol` SHALL be shown next to the value of X and never as a row of its own.

#### Scenario: Tolerance next to value
- **WHEN** the tables of "243 Win." are shown
- **THEN** the L1 value reads `39.62 -0.2` and no row has the symbol "L1Tol"

### Requirement: Angles
An angle (alpha, alpha1, beta, delta, i) given as a number SHALL be shown as degrees (`40°`); given as `{degrees, minutes, seconds}` it SHALL be shown as `39°59'49"`.

#### Scenario: Degrees, minutes, seconds
- **WHEN** the tables of "338 Lapua Mag." are shown
- **THEN** the cartridge α reads `39°59'49"`

### Requirement: Actions
The detail view SHALL have a "Print" button that opens the browser print dialog and a link "All cartridges" back to the list.

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** the browser print dialog is requested
