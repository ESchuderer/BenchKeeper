## ADDED Requirements

### Requirement: Drawing as true-scale inline SVG
Each detail view SHALL contain an inline SVG named "<name> drawing", computed from the record's values, with 1 SVG user unit = 1 mm, the axis horizontal and the head on the left. The upper half SHALL be the outside view, the lower half a section with hatched cut walls, and a dash-dot centre line SHALL mark the axis.

#### Scenario: Accessible name
- **WHEN** the detail view of "308 Win." is shown
- **THEN** an image named "308 Win. drawing" exists

#### Scenario: True to scale
- **WHEN** the drawing of any cartridge is computed
- **THEN** the head face lies at x = 0, the case mouth at x = L3, the bullet tip at x = L6 and the rim diameter spans R1 user units

### Requirement: Head, rim and groove profile
The outer half-profile SHALL be built from the axis at the head face to the mouth and mirrored at the axis. The rim type SHALL follow from family and R1/P1. The head SHALL be chamfered where beta and f are published and beta < 90°, rimfire rims SHALL have a half-round edge, and an extractor groove SHALL be drawn where E and E1 are published (with a belt ramp at δ on belted cases).

#### Scenario: Rim type
- **WHEN** R1/P1 is 1.05 or more on a non-belted, non-rimfire family
- **THEN** the rim type is rimmed; below 0.98 it is rebated; otherwise rimless

#### Scenario: Chamfer geometry
- **WHEN** beta and f are published and beta < 90°
- **THEN** the head face is chamfered from (R1/2 - min(f·tan β, R1/4), 0) to (R1/2, f)

### Requirement: Body, shoulder and neck profile
The body SHALL run straight from P1/2 to P2/2 at L1 on bottleneck cases and to H2/2 at L3 on straight cases. The shoulder SHALL pass through the published points with rounded corners where r1 min and r2 are published, followed by the neck to the mouth.

#### Scenario: Straight case
- **WHEN** a record has no alpha, L1 or L2
- **THEN** the body runs from P1/2 to H2/2 at L3 with no shoulder

### Requirement: Bullet
The drawing SHALL show a bullet from the mouth to the tip at L6 with shank diameter G1 and the nose shape of `annotations.defaultBulletShape` (pointy tangent ogive, rounded quarter ellipse, flat cone, semi-wadcutter cone) with the specified seating depth, cylinder fraction and meplat. Heeled cases (H2 - G1 ≤ 0.015) SHALL show the exposed bullet at the case's outside diameter and the seated heel at H2 - 2·tb.

#### Scenario: Pointy bullet
- **WHEN** the shape is pointy
- **THEN** the seating depth is 1.0·G1, the cylinder ends at 40 % of the bullet length and the meplat is max(0.08·G1, 1.27) wide

#### Scenario: Heeled 22 Long Rifle
- **WHEN** the drawing of "22 Long Rifle" is computed
- **THEN** the seated heel has diameter H2 - 2·tb and the exposed bullet diameter H2

### Requirement: Section
The section SHALL show neck wall tn, body wall tb, a solid head to z = w and the primer pocket on centrefire cases. The outside view SHALL hide the seated bullet part; the section SHALL show it.

#### Scenario: Primer pocket
- **WHEN** the primer type is lr
- **THEN** the pocket is 5.33 wide and 3.3 deep; rimfire cases have no pocket

### Requirement: Dimensions and labels
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value (`L3 51.18`). Labels SHALL NOT overlap each other or the outline.

#### Scenario: Label text
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the labels `L3 51.18`, `L6 71.12`, `R1 12.01`, `R 1.37` and `P1 11.96` are present

#### Scenario: No overlaps
- **WHEN** the drawing of any of the 25 cartridges is rendered
- **THEN** no two label boxes intersect and no label box intersects the outline

### Requirement: Title block and scale
The drawing SHALL include a title block with the name, C.I.P. table and revision date, the text "Dimensions in mm", and the scale.

#### Scenario: Title block
- **WHEN** the drawing of "223 Rem." is shown
- **THEN** its title block shows "223 Rem.", table "I", revised "2017-05-17", "Dimensions in mm" and a scale

### Requirement: Missing values
When a value a rule needs is missing the drawing SHALL be made without that feature, SHALL state which value is missing, and SHALL NOT invent a number.

#### Scenario: Missing extractor groove value
- **WHEN** a record without E1 is drawn
- **THEN** no groove is drawn and a note names E1 as missing

### Requirement: Responsive drawing
The drawing SHALL scale to the width of a phone screen without horizontal scrolling.

#### Scenario: Phone width
- **WHEN** the viewport is 360 px wide
- **THEN** the drawing is no wider than the viewport
