## ADDED Requirements

### Requirement: Printed data sheet
A printed detail view SHALL be one A4 portrait page, black on white: a page header with the name, the drawing at full width with every label legible, then the tables, and a footer with the source (C.I.P. TDCC, revised date). Navigation, search and buttons SHALL NOT be printed.

#### Scenario: One page
- **WHEN** any detail view is printed to A4 portrait
- **THEN** the output has exactly one page and contains the name, the drawing, the tables and the footer "C.I.P. TDCC" with the revised date

#### Scenario: Controls hidden
- **WHEN** the detail view is printed
- **THEN** the Print button, the "All cartridges" link and the site navigation are not visible

### Requirement: Look and feel
The interface SHALL be a dense, calm technical reference with precise typography and tabular numbers, light and dark on screen following the system setting, always light in print, and usable on a phone.

#### Scenario: Dark mode
- **WHEN** the system prefers a dark colour scheme
- **THEN** the page uses a dark background and the drawing remains legible

#### Scenario: Phone
- **WHEN** the viewport is 360 px wide
- **THEN** no page needs horizontal scrolling

### Requirement: Delivery constraints
The app SHALL be plain HTML, CSS and JavaScript with no framework, build step, server code, runtime dependency or network request, SHALL work when `index.html` is opened from disk in Chromium and when served by a static file server, and its interface SHALL be in English.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened through a `file://` address
- **THEN** the list, search, filter, detail views and drawings all work

#### Scenario: No network
- **WHEN** the app runs
- **THEN** it requests no resource other than its own files
