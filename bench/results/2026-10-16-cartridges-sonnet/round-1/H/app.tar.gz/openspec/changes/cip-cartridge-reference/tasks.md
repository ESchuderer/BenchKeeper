## 1. Foundation
- [x] 1.1 Save the 25 records verbatim as `data/cartridges.jsonl`; generate `js/data.js`; test equality and shape
- [x] 1.2 `package.json` scripts: `test`, `test:e2e`, `build:data`

## 2. Formatting and model (tests first)
- [x] 2.1 `format.js`: numbers, angles, tolerance, symbols, units
- [x] 2.2 `model.js`: sections→rows, metadata, search/filter, routing helpers

## 3. Geometry (tests first)
- [x] 3.1 Rim type, head, groove, belt, body, shoulder fillets, neck
- [x] 3.2 Bullet shapes, heeled case, walls, head solid, pocket
- [x] 3.3 Missing-value notes
- [x] 3.4 Dimension layout without overlaps for all 25 records

## 4. UI
- [x] 4.1 `index.html`, list view, search, family, count
- [x] 4.2 Detail view, tables, drawing renderer, scale text
- [x] 4.3 CSS: screen light/dark, phone, print

## 5. Verification
- [x] 5.1 e2e on `file://` and static server; overlap check with real bounding boxes
- [x] 5.2 Print PDF is one A4 page for every cartridge
- [x] 5.3 No network requests, no console errors
- [ ] 5.4 Review agents (code, security, accessibility) and fixes
