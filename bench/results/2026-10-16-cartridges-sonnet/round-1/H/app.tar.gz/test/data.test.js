'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const records = require('../js/data.js');
const jsonl = fs
  .readFileSync(path.join(root, 'data', 'cartridges.jsonl'), 'utf8')
  .split('\n')
  .filter(Boolean)
  .map((l) => JSON.parse(l));

test('js/data.js equals the verbatim JSONL records', () => {
  assert.deepEqual(records, jsonl);
});

test('there are 25 records with unique keys and names', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
  assert.equal(new Set(records.map((r) => r.name)).size, 25);
});

test('every record has the fields the app relies on', () => {
  for (const r of records) {
    for (const f of ['key', 'name', 'family', 'tab', 'country', 'published', 'revised', 'pressureMethod']) {
      assert.ok(r[f] !== undefined, `${r.key}.${f}`);
    }
    assert.ok(r.cartridge && r.chamber && r.annotations, r.key);
    assert.equal(typeof r.cartridge.lengths.L3, 'number', r.key);
  }
});

test('families are the six published ones', () => {
  const fams = new Set(records.map((r) => r.family));
  assert.deepEqual([...fams].sort(), ['belted', 'pistol', 'rimfire', 'rimless', 'rimmed']);
});
