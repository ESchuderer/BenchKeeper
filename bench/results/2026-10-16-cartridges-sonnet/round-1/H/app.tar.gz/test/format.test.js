'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../js/format.js');

test('formatNumber shows numbers as published without trailing .0', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(25.0), '25');
  assert.equal(F.formatNumber(0), '0');
  assert.equal(F.formatNumber(-0.2), '-0.2');
  assert.equal(F.formatNumber(305), '305');
});

test('formatNumber never uses thousands separators or exponents', () => {
  assert.equal(F.formatNumber(12345.5), '12345.5');
  assert.equal(F.formatNumber(0.0000001), '0.0000001');
});

test('formatAngle: plain number is degrees', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(13.0), '13°');
  assert.equal(F.formatAngle(12.5), '12.5°');
});

test('formatAngle: degrees, minutes, seconds object', () => {
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), "39°59'49\"");
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), "1°30'0\"");
  assert.equal(F.formatAngle({ degrees: 0, minutes: 42, seconds: 29 }), "0°42'29\"");
});

test('angleToDegrees converts both forms', () => {
  assert.equal(F.angleToDegrees(40), 40);
  assert.ok(Math.abs(F.angleToDegrees({ degrees: 39, minutes: 59, seconds: 49 }) - 39.99694444) < 1e-6);
  assert.equal(F.angleToDegrees(undefined), undefined);
});

test('symbols: replaced and default', () => {
  const expect = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
    L3: 'L3', Pmax: 'Pmax', G1: 'G1', i: 'i',
  };
  for (const [field, sym] of Object.entries(expect)) assert.equal(F.symbolFor(field), sym, field);
});

test('units follow the brief', () => {
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('N'), '');
  for (const a of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unitFor(a), 'deg', a);
  for (const l of ['L3', 'R1', 'P1', 'G1', 'u', 'Fe', 'deltaL', 'L3PlusG', 'eMin', 'r1Min']) {
    assert.equal(F.unitFor(l), 'mm', l);
  }
});

test('isAngleField and tolerance helpers', () => {
  assert.ok(F.isAngleField('alpha') && F.isAngleField('i') && !F.isAngleField('L3'));
  assert.ok(F.isToleranceField('L1Tol') && !F.isToleranceField('Tol') && !F.isToleranceField('L1'));
  assert.equal(F.toleranceBase('L1Tol'), 'L1');
});

test('formatTolerance keeps the published sign', () => {
  assert.equal(F.formatTolerance(-0.2), '-0.2');
  assert.equal(F.formatTolerance(0.25), '+0.25');
});

test('formatValue joins value and tolerance', () => {
  assert.equal(F.formatValue('L1', 39.62, -0.2), '39.62 -0.2');
  assert.equal(F.formatValue('L1', 39.62), '39.62');
  assert.equal(F.formatValue('alpha', 40), '40°');
  assert.equal(F.formatValue('i', { degrees: 3, minutes: 10, seconds: 36 }), "3°10'36\"");
});
