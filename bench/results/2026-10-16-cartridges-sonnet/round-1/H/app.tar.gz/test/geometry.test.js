'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../js/geometry.js');
const DATA = require('../js/data.js');

const byKey = (k) => DATA.find((r) => r.key === k);
const clone = (o) => JSON.parse(JSON.stringify(o));
const EPS = 1e-9;
const near = (a, b, eps = 1e-6, msg) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} ${a} !~ ${b}`);
const hasPoint = (pts, z, r, eps = 1e-6) => pts.some((p) => Math.abs(p.z - z) <= eps && Math.abs(p.r - r) <= eps);
const without = (rec, group, section, field) => {
  const c = clone(rec);
  delete c[group][section][field];
  return c;
};
const noteFor = (d, feature) => d.notes.find((n) => n.feature === feature);

test('rim type rules', () => {
  assert.equal(G.computeDrawing(byKey('223_rem')).rimType, 'rimless');
  assert.equal(G.computeDrawing(byKey('45_auto')).rimType, 'rimless');
  assert.equal(G.computeDrawing(byKey('9_3_x_74_r')).rimType, 'rimmed');
  assert.equal(G.computeDrawing(byKey('300_win_mag')).rimType, 'belted');
  assert.equal(G.computeDrawing(byKey('22_long_rifle')).rimType, 'rimfire');
  assert.equal(G.computeDrawing(byKey('17_hmr')).rimType, 'rimfire');
  assert.equal(G.rimTypeOf({ family: 'rimless', R1: 10.5, P1: 10 }), 'rimmed');
  assert.equal(G.rimTypeOf({ family: 'rimless', R1: 10.4999, P1: 10 }), 'rimless');
  assert.equal(G.rimTypeOf({ family: 'rimless', R1: 9.8, P1: 10 }), 'rimless');
  assert.equal(G.rimTypeOf({ family: 'rimless', R1: 9.79, P1: 10 }), 'rebated');
  assert.equal(G.rimTypeOf({ family: 'belted', R1: 9.0, P1: 10 }), 'belted');
  assert.equal(G.rimTypeOf({ family: 'rimfire', R1: 12, P1: 10 }), 'rimfire');
});

test('223 Rem. head, rim and groove points follow rules 2 and 3', () => {
  const d = G.computeDrawing(byKey('223_rem'));
  const o = d.outer;
  assert.deepEqual(o[0], { z: 0, r: 0 });
  near(o[1].z, 0); near(o[1].r, 4.8 - 0.45 * Math.tan((35 * Math.PI) / 180));
  near(o[2].z, 0.45); near(o[2].r, 4.8);
  assert.ok(hasPoint(o, 1.14, 4.8), 'rim top at R');
  assert.ok(hasPoint(o, 1.14, 4.215), 'step in to E1/2');
  assert.ok(hasPoint(o, 1.14 + 0.76, 4.215), 'floor to R + e min');
  assert.ok(hasPoint(o, 3.13, 9.58 / 2), 'ramp to (P1/2, E)');
  assert.equal(d.features.chamfer, true);
  assert.equal(d.features.groove, true);
  assert.equal(d.features.belt, false);
});

test('chamfer is limited to R1/4 and needs beta < 90 and f', () => {
  const rec = clone(byKey('223_rem'));
  rec.cartridge.caseHead.f = 20;
  const d = G.computeDrawing(rec);
  near(d.outer[1].r, 4.8 - 9.6 / 4);
  const r90 = clone(byKey('223_rem'));
  r90.cartridge.caseHead.beta = 90;
  const d90 = G.computeDrawing(r90);
  assert.equal(d90.features.chamfer, false);
  assert.deepEqual(d90.outer[1], { z: 0, r: 4.8 });
  assert.equal(noteFor(d90, 'Head chamfer'), undefined);
});

test('body, shoulder, neck: key points and fillets (223 Rem.)', () => {
  const d = G.computeDrawing(byKey('223_rem'));
  assert.deepEqual(d.corners.shoulderStart, { z: 36.52, r: 4.5 });
  assert.deepEqual(d.corners.shoulderEnd, { z: 39.55, r: 6.43 / 2 });
  assert.deepEqual(d.corners.mouth, { z: 44.7, r: 6.43 / 2 });
  assert.deepEqual(d.outer[d.outer.length - 1], { z: 44.7, r: 6.43 / 2 });
  assert.equal(d.fillets.length, 2);
  const [f1, f2] = d.fillets;
  assert.equal(f1.radius, 0.64);
  assert.equal(f2.radius, 2.54);
  // tangent length = r * tan(deflection / 2)
  const dz = 39.55 - 36.52, dr = 4.5 - 3.215;
  const slope = Math.atan2(dr, dz);
  const bodySlope = Math.atan2(4.79 - 4.5, 36.52 - 3.13);
  near(f1.tangentLength, 0.64 * Math.tan((slope - bodySlope) / 2), 1e-9);
  near(f2.tangentLength, 2.54 * Math.tan(slope / 2), 1e-9);
  // the outline never leaves the corner polygon by more than r
  for (const p of d.outer) assert.ok(p.r <= 4.8 + EPS && p.z >= 0 && p.z <= 44.7 + EPS);
});

test('shoulder rounding is skipped and noted when r1 min / r2 are missing', () => {
  const d = G.computeDrawing(byKey('338_lapua_mag'));
  assert.equal(d.fillets.length, 1);
  assert.deepEqual(noteFor(d, 'Shoulder body-side rounding').missing, ['r1 min']);
  const h = G.computeDrawing(byKey('17_hmr'));
  assert.equal(h.fillets.length, 0);
  assert.deepEqual(noteFor(h, 'Shoulder body-side rounding').missing, ['r1 min']);
  assert.deepEqual(noteFor(h, 'Shoulder neck-side rounding').missing, ['r2']);
});

test('straight case: body runs to (H2/2, L3), no shoulder, no note', () => {
  const d = G.computeDrawing(byKey('9_mm_luger'));
  assert.equal(d.features.shoulder, false);
  assert.deepEqual(d.outer[d.outer.length - 1], { z: 19.15, r: 9.65 / 2 });
  assert.ok(hasPoint(d.outer, 2.98, 9.93 / 2));
  assert.equal(d.notes.filter((n) => /Shoulder/.test(n.feature)).length, 0);
  assert.equal(d.corners.shoulderStart, undefined);
});

test('a case lacking alpha, L1 or L2 is straight; partial data is noted', () => {
  const noAlpha = G.computeDrawing(without(byKey('223_rem'), 'cartridge', 'junctionCone', 'alpha'));
  assert.equal(noAlpha.features.shoulder, false);
  assert.deepEqual(noteFor(noAlpha, 'Shoulder').missing, ['α']);
  const noL1 = G.computeDrawing(without(byKey('223_rem'), 'cartridge', 'lengths', 'L1'));
  assert.equal(noL1.features.shoulder, false);
  assert.deepEqual(noteFor(noL1, 'Shoulder').missing, ['L1']);
  assert.deepEqual(noL1.outer[noL1.outer.length - 1], { z: 44.7, r: 6.43 / 2 });
});

test('belted case: ramp at delta to the belt, belt to E, step in to P1/2', () => {
  const d = G.computeDrawing(byKey('300_win_mag'));
  assert.equal(d.features.belt, true);
  const o = d.outer;
  const floorEnd = 1.27 + 0.94;
  const zEnd = floorEnd + (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  assert.ok(hasPoint(o, 1.27, 13.51 / 2));
  assert.ok(hasPoint(o, 1.27, 12.07 / 2));
  assert.ok(hasPoint(o, floorEnd, 12.07 / 2));
  assert.ok(hasPoint(o, zEnd, 13.51 / 2));
  assert.ok(hasPoint(o, 5.59, 13.51 / 2));
  assert.ok(hasPoint(o, 5.59, 13.03 / 2));
  near(d.beltRampEnd, zEnd);
});

test('belted case without R3 draws a plain groove and says R3 is missing', () => {
  const d = G.computeDrawing(without(byKey('300_win_mag'), 'cartridge', 'caseHead', 'R3'));
  assert.equal(d.features.belt, false);
  assert.equal(d.features.groove, true);
  assert.deepEqual(noteFor(d, 'Belt').missing, ['R3']);
});

test('rimmed case has no groove and steps in at R', () => {
  const d = G.computeDrawing(byKey('9_3_x_74_r'));
  assert.equal(d.features.groove, false);
  assert.ok(hasPoint(d.outer, 1.4, 13.35 / 2));
  assert.ok(hasPoint(d.outer, 1.4, 11.9 / 2));
  assert.equal(noteFor(d, 'Extractor groove'), undefined);
});

test('missing E1 on a rimless case: no groove, step in, note names E1', () => {
  const d = G.computeDrawing(without(byKey('223_rem'), 'cartridge', 'caseHead', 'E1'));
  assert.equal(d.features.groove, false);
  assert.ok(hasPoint(d.outer, 1.14, 9.58 / 2));
  assert.deepEqual(noteFor(d, 'Extractor groove').missing, ['E1']);
});

test('missing e min is reported as such', () => {
  const d = G.computeDrawing(without(byKey('223_rem'), 'cartridge', 'caseHead', 'eMin'));
  assert.equal(d.features.groove, false);
  assert.deepEqual(noteFor(d, 'Extractor groove').missing, ['e min']);
});

test('chamfer missing f on a centrefire case is noted', () => {
  const d = G.computeDrawing(without(byKey('223_rem'), 'cartridge', 'caseHead', 'f'));
  assert.equal(d.features.chamfer, false);
  assert.deepEqual(d.outer[1], { z: 0, r: 4.8 });
  assert.deepEqual(noteFor(d, 'Head chamfer').missing, ['f']);
});

test('rimfire rim edge is a half-round whose outermost point lies at R1/2 (22 LR)', () => {
  const d = G.computeDrawing(byKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.equal(d.features.halfRound, true);
  assert.equal(d.features.chamfer, false);
  const o = d.outer;
  assert.ok(hasPoint(o, 0, 7.06 / 2 - rho));
  assert.ok(hasPoint(o, rho, 7.06 / 2));
  assert.ok(hasPoint(o, 1.09, 7.06 / 2 - rho));
  assert.ok(hasPoint(o, 1.09, 5.74 / 2));
  near(Math.max(...o.map((p) => p.r)), 7.06 / 2);
  assert.equal(noteFor(d, 'Head chamfer'), undefined);
  assert.equal(noteFor(d, 'Extractor groove'), undefined);
});

test('half-round radius is limited by (R1 - P1)/2', () => {
  const rec = clone(byKey('22_long_rifle'));
  rec.cartridge.caseHead.R1 = 6.0; // (6.0 - 5.74)/2 = 0.13
  const d = G.computeDrawing(rec);
  assert.ok(hasPoint(d.outer, 0, 3.0 - 0.13));
  assert.ok(hasPoint(d.outer, 0.13, 3.0));
});

test('walls, solid head and primer pocket (rule 8)', () => {
  const d = G.computeDrawing(byKey('223_rem'));
  near(d.walls.tn, (6.43 - 5.7) / 2);
  near(d.walls.tb, 0.6);
  assert.deepEqual(d.pocket, { diameter: 4.45, depth: 3.04 });
  near(d.w, 3.04 + 1.5);
  const lr = G.computeDrawing(byKey('308_win'));
  assert.deepEqual(lr.pocket, { diameter: 5.33, depth: 3.3 });
  near(lr.w, 3.3 + 1.5);
  const belted = G.computeDrawing(byKey('300_win_mag'));
  assert.deepEqual(belted.pocket, { diameter: 5.33, depth: 3.3 });
  near(belted.w, 5.59 + belted.walls.tb);
  const lapua = G.computeDrawing(byKey('338_lapua_mag'));
  assert.equal(lapua.pocket.depth, 3.3);
  const lpm = G.computeDrawing(byKey('44_rem_mag'));
  assert.deepEqual(lpm.pocket, { diameter: 5.33, depth: 3.04 });
  const spm = G.computeDrawing(byKey('357_magnum'));
  assert.deepEqual(spm.pocket, { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(G.computeDrawing(byKey('45_auto')).pocket, { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(G.computeDrawing(byKey('9_mm_luger')).pocket, { diameter: 4.45, depth: 3.04 });
});

test('body wall is limited to 0.35 * P1/2 and floored at 0.6', () => {
  const rec = clone(byKey('223_rem'));
  rec.cartridge.powderChamber.P1 = 2.0; // 0.35 * 1 = 0.35
  const d = G.computeDrawing(rec);
  near(d.walls.tb, 0.35);
  const rec2 = clone(byKey('223_rem'));
  rec2.cartridge.projectile.G1 = 3.0; // tn = 1.715 -> 1.3 tn = 2.23, limit 0.35*4.79 = 1.6765
  near(G.computeDrawing(rec2).walls.tb, 0.35 * 9.58 / 2);
});

test('rimfire has no pocket; w is at least 2.5', () => {
  for (const k of ['22_long_rifle', '22_win_mag_r_f', '17_hmr']) {
    const d = G.computeDrawing(byKey(k));
    assert.equal(d.pocket, null, k);
    near(d.w, 2.5, 1e-9, k);
  }
});

test('missing primer type: no pocket, noted', () => {
  const rec = clone(byKey('223_rem'));
  delete rec.annotations.primerType;
  const d = G.computeDrawing(rec);
  assert.equal(d.pocket, null);
  assert.deepEqual(noteFor(d, 'Primer pocket').missing, ['primer type']);
});

test('pointy bullet (223 Rem.): seating depth, cylinder, tangent ogive, meplat', () => {
  const b = G.computeDrawing(byKey('223_rem')).bullet;
  assert.equal(b.shape, 'pointy');
  near(b.seatDepth, 5.7);
  near(b.zb, 44.7 - 5.7);
  const lb = 57.4 - b.zb;
  near(b.length, lb);
  near(b.zc, b.zb + 0.4 * lb);
  near(b.meplat, 1.27);
  const n = 57.4 - b.zc;
  const a = 5.7 / 2 - 1.27 / 2;
  near(b.rho, (a * a + n * n) / (2 * a));
  const c = { z: b.zc, r: 5.7 / 2 - b.rho };
  const nose = b.profile.filter((p) => p.z > b.zc + 1e-9);
  assert.ok(nose.length >= 8);
  for (const p of nose) near(Math.hypot(p.z - c.z, p.r - c.r), b.rho, 1e-6, 'on arc');
  const last = b.profile[b.profile.length - 1];
  near(last.z, 57.4); near(last.r, 1.27 / 2);
  assert.equal(b.heeled, false);
  assert.deepEqual(b.exposed[0], { z: 44.7, r: 2.85 });
  assert.deepEqual(b.exposed[b.exposed.length - 1], last);
});

test('pointy meplat has a floor of 1.27 and scales with big bullets', () => {
  const rec = clone(byKey('9_3_x_62'));
  assert.equal(G.computeDrawing(rec).bullet.meplat, Math.max(0.08 * 9.3, 1.27));
  const big = clone(byKey('9_3_x_62'));
  big.cartridge.projectile.G1 = 20;
  big.cartridge.collar.H1 = 21;
  big.cartridge.collar.H2 = 21;
  assert.equal(G.computeDrawing(big).bullet.meplat, 1.6);
});

test('rounded pistol bullet (9 mm Luger): 0.4 G1 seating, k 0.65, quarter ellipse, m 0.15 G1', () => {
  const b = G.computeDrawing(byKey('9_mm_luger')).bullet;
  near(b.seatDepth, 0.4 * 9.03);
  near(b.meplat, 0.15 * 9.03);
  near(b.zc, b.zb + 0.65 * b.length);
  const n = 29.69 - b.zc, A = 9.03 / 2 - b.meplat / 2, cz = b.zc, cr = b.meplat / 2;
  const nose = b.profile.filter((p) => p.z > b.zc + 1e-9);
  assert.ok(nose.length >= 8);
  for (const p of nose) near(((p.z - cz) / n) ** 2 + ((p.r - cr) / A) ** 2, 1, 1e-6, 'on ellipse');
});

test('rounded rimfire bullet uses the rifle fraction 0.8 G1 / k 0.55 (22 Win. Mag.)', () => {
  const b = G.computeDrawing(byKey('22_win_mag_r_f')).bullet;
  near(b.seatDepth, 0.8 * 5.7);
  near(b.zc, b.zb + 0.55 * b.length);
});

test('flat bullet: pistol 0.4 / 0.70, m 0.55 G1, straight cone (40 S&W)', () => {
  const b = G.computeDrawing(byKey('40_s_w')).bullet;
  near(b.seatDepth, 0.4 * 10.17);
  near(b.zc, b.zb + 0.7 * b.length);
  near(b.meplat, 0.55 * 10.17);
  assert.equal(b.profile.filter((p) => p.z > b.zc + 1e-9).length, 1);
});

test('flat rifle bullet: 0.8 G1 and k 0.60', () => {
  const rec = clone(byKey('308_win'));
  rec.annotations.defaultBulletShape = 'flat';
  const b = G.computeDrawing(rec).bullet;
  near(b.seatDepth, 0.8 * 7.85);
  near(b.zc, b.zb + 0.6 * b.length);
});

test('semi-wadcutter: 0.6 G1, k 0.78, m 0.6 G1 (357 Magnum)', () => {
  const b = G.computeDrawing(byKey('357_magnum')).bullet;
  near(b.seatDepth, 0.6 * 9.12);
  near(b.zc, b.zb + 0.78 * b.length);
  near(b.meplat, 0.6 * 9.12);
});

test('heeled 22 Long Rifle: exposed bullet at H2, seated heel at H2 - 2 tb', () => {
  const d = G.computeDrawing(byKey('22_long_rifle'));
  const b = d.bullet;
  assert.equal(b.heeled, true);
  near(d.walls.tb, 0.6);
  near(b.seatRadius, 5.72 / 2 - 0.6);
  near(b.exposed[0].r, 5.72 / 2);
  near(b.zb, 15.57 - 0.8 * 5.72);
  // section: heel steps out to the case's outside diameter at the mouth
  assert.ok(hasPoint(b.sectionPolygon, 15.57, 5.72 / 2 - 0.6));
  assert.ok(hasPoint(b.sectionPolygon, 15.57, 5.72 / 2));
  // wall stays tb up to the mouth
  near(d.inner[d.inner.length - 1].r, 5.72 / 2 - 0.6);
});

test('inner line: tb along the body, tn along the neck, blended on the shoulder', () => {
  const d = G.computeDrawing(byKey('223_rem'));
  const outerAt = (z) => G.interpolate(d.outer, z);
  const innerAt = (z) => G.interpolate(d.inner, z);
  near(d.inner[0].z, d.w);
  near(outerAt(20) - innerAt(20), 0.6, 1e-6);
  near(outerAt(43) - innerAt(43), d.walls.tn, 1e-6);
  const mid = (36.52 + 39.55) / 2;
  const t = (0.6 + d.walls.tn) / 2;
  // fillets move the outer line slightly, so allow the rounding offset
  assert.ok(Math.abs(outerAt(mid) - innerAt(mid) - t) < 0.2);
  near(d.inner[d.inner.length - 1].z, 44.7);
  near(d.inner[d.inner.length - 1].r, 2.85);
});

test('seated bullet never overlaps the case wall on any of the 25 records', () => {
  for (const rec of DATA) {
    const d = G.computeDrawing(rec);
    assert.ok(d.inner && d.bullet, rec.key);
    for (const p of d.inner) {
      if (p.z >= d.bullet.zb - 1e-9) {
        assert.ok(p.r >= d.bullet.seatRadius - 1e-9, `${rec.key} z=${p.z} inner ${p.r} < bullet ${d.bullet.seatRadius}`);
      }
      assert.ok(G.interpolate(d.outer, p.z) - p.r > 0.1 - 1e-9, `${rec.key} wall too thin at ${p.z}`);
    }
  }
});

test('straight non-heeled wall eases from tb to tn before the bullet base (9 mm Luger)', () => {
  const d = G.computeDrawing(byKey('9_mm_luger'));
  const { tb, tn } = d.walls;
  const zb = d.bullet.zb;
  const innerAt = (z) => G.interpolate(d.inner, z);
  const outerAt = (z) => G.interpolate(d.outer, z);
  near(outerAt(8) - innerAt(8), tb, 1e-6);
  near(outerAt(zb) - innerAt(zb), tn, 1e-6);
  near(outerAt(19) - innerAt(19), tn, 1e-6);
  assert.ok(Math.abs(innerAt(19.15) - 9.03 / 2) < 1e-9);
});

test('missing bullet values: no bullet, noted, nothing invented', () => {
  const d = G.computeDrawing(without(byKey('223_rem'), 'cartridge', 'lengths', 'L6'));
  assert.equal(d.bullet, null);
  assert.deepEqual(noteFor(d, 'Bullet').missing, ['L6']);
  const e = G.computeDrawing(without(byKey('223_rem'), 'cartridge', 'projectile', 'G1'));
  assert.equal(e.bullet, null);
  assert.equal(e.walls, null);
  assert.deepEqual(noteFor(e, 'Bullet').missing, ['G1']);
  assert.deepEqual(noteFor(e, 'Section walls').missing, ['G1']);
  const f = clone(byKey('223_rem'));
  delete f.annotations.defaultBulletShape;
  assert.deepEqual(noteFor(G.computeDrawing(f), 'Bullet').missing, ['bullet shape']);
});

test('missing outline values: no outline, noted', () => {
  const d = G.computeDrawing(without(byKey('223_rem'), 'cartridge', 'lengths', 'L3'));
  assert.equal(d.outer, null);
  assert.deepEqual(noteFor(d, 'Case outline').missing, ['L3']);
});

test('complete records produce no notes except unpublished optional roundings', () => {
  for (const k of ['223_rem', '308_win', '300_win_mag', '9_mm_luger', '22_long_rifle']) {
    assert.deepEqual(G.computeDrawing(byKey(k)).notes, [], k);
  }
});

test('all 25 records: outline is monotone in z, true to scale, and inside the box', () => {
  for (const rec of DATA) {
    const d = G.computeDrawing(rec);
    const L3 = rec.cartridge.lengths.L3, L6 = rec.cartridge.lengths.L6;
    assert.ok(d.outer.length > 5, rec.key);
    for (let i = 1; i < d.outer.length; i++) {
      assert.ok(d.outer[i].z >= d.outer[i - 1].z - 1e-9, `${rec.key} z non-monotone at ${i}`);
    }
    assert.deepEqual(d.outer[0], { z: 0, r: 0 });
    near(d.outer[d.outer.length - 1].z, L3, 1e-9, rec.key);
    near(Math.max(...d.outer.map((p) => p.r)) * 2, Math.max(rec.cartridge.caseHead.R1, rec.cartridge.caseHead.R3 || 0, rec.cartridge.powderChamber.P1), 1e-9, rec.key);
    near(d.bullet.profile[d.bullet.profile.length - 1].z, L6, 1e-9, rec.key);
    assert.ok(d.bullet.zb > d.w, `${rec.key} bullet base beyond solid head`);
    for (const p of d.outer) assert.ok(p.r >= 0 && Number.isFinite(p.z) && Number.isFinite(p.r));
  }
});

test('interpolate', () => {
  const pts = [{ z: 0, r: 0 }, { z: 10, r: 5 }];
  assert.equal(G.interpolate(pts, 5), 2.5);
  assert.equal(G.interpolate(pts, 0), 0);
  assert.equal(G.interpolate(pts, 10), 5);
});

test('belt that cannot be drawn gives a reason, not a false "missing" value', () => {
  const rec = clone(byKey('300_win_mag'));
  rec.cartridge.caseHead.delta = 5;
  const d = G.computeDrawing(rec);
  assert.equal(d.features.belt, false);
  const n = noteFor(d, 'Belt');
  assert.deepEqual(n.missing, []);
  assert.match(n.reason, /ramp/);
});

test('r1 min or r2 published as 0 means no rounding, not a missing value', () => {
  const rec = clone(byKey('223_rem'));
  rec.cartridge.junctionCone.r1Min = 0;
  const d = G.computeDrawing(rec);
  assert.equal(noteFor(d, 'Shoulder body-side rounding'), undefined);
  assert.equal(d.fillets.length, 1);
});

test('a nose that starts inside the case enters the exposed outline on the curve', () => {
  const rec = clone(byKey('9_mm_luger'));
  rec.annotations.defaultBulletShape = 'pointy';
  const b = G.computeDrawing(rec).bullet;
  assert.ok(b.zc < 19.15);
  assert.equal(b.exposed[0].z, 19.15);
  assert.ok(b.exposed[0].r < 9.03 / 2);
  for (let i = 1; i < b.exposed.length; i++) assert.ok(b.exposed[i].r <= b.exposed[i - 1].r + 1e-9);
});
