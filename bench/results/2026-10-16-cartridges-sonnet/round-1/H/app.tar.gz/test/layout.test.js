'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const L = require('../js/layout.js');
const DATA = require('../js/data.js');

const byKey = (k) => DATA.find((r) => r.key === k);
const texts = (lay) => lay.labels.map((l) => l.text);

function boxesIntersect(a, b, pad = 0) {
  return a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
}
function segmentHitsBox(s, b, pad = 0) {
  const x0 = b.x0 - pad, x1 = b.x1 + pad, y0 = b.y0 - pad, y1 = b.y1 + pad;
  let t0 = 0, t1 = 1;
  const dx = s[2] - s[0], dy = s[3] - s[1];
  for (const [p, q] of [[-dx, s[0] - x0], [dx, x1 - s[0]], [-dy, s[1] - y0], [dy, y1 - s[1]]]) {
    if (p === 0) { if (q < 0) return false; } else {
      const r = q / p;
      if (p < 0) { if (r > t1) return false; if (r > t0) t0 = r; } else { if (r < t0) return false; if (r < t1) t1 = r; }
    }
  }
  return t0 <= t1;
}

test('308 Win. carries every required and published dimension label', () => {
  const lay = L.layoutDrawing(byKey('308_win'));
  for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72',
    'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(texts(lay).includes(t), `missing label ${t}`);
  }
});

test('angles with minutes and seconds are labelled as published', () => {
  assert.ok(texts(L.layoutDrawing(byKey('6_5_x_55_se'))).includes("α 50°35'2\""));
});

test('straight cases have no shoulder labels', () => {
  const t = texts(L.layoutDrawing(byKey('9_mm_luger')));
  for (const x of t) assert.ok(!/^(P2|H1|L1|L2|α) /.test(x), x);
  for (const x of ['L3 19.15', 'L6 29.69', 'R1 9.96', 'R 1.27', 'P1 9.93', 'H2 9.65', 'G1 9.03', 'E1 8.79']) assert.ok(t.includes(x), x);
});

test('rimfire without groove has no E1 label', () => {
  const t = texts(L.layoutDrawing(byKey('22_long_rifle')));
  assert.ok(!t.some((x) => /^E1 /.test(x)));
  for (const x of ['L3 15.57', 'L6 25.4', 'R1 7.06', 'R 1.09', 'P1 5.74', 'H2 5.72', 'G1 5.72']) assert.ok(t.includes(x), x);
});

test('dimension values are measured true to scale', () => {
  for (const rec of DATA) {
    const lay = L.layoutDrawing(rec);
    for (const dim of lay.dims) {
      if (dim.kind === 'angle') continue;
      const [a, b] = dim.measure;
      assert.ok(Math.abs(Math.abs(b - a) - dim.value) < 1e-9, `${rec.key} ${dim.id}: ${Math.abs(b - a)} vs ${dim.value}`);
    }
  }
});

test('every dimension has arrowheads and an extension line', () => {
  for (const rec of DATA) {
    for (const dim of L.layoutDrawing(rec).dims) {
      assert.ok(dim.arrows.length >= 2, `${rec.key} ${dim.id} arrows`);
      assert.ok(dim.extLines.length >= 1, `${rec.key} ${dim.id} ext lines`);
      assert.ok(dim.label && dim.label.text, `${rec.key} ${dim.id} label`);
    }
  }
});

test('labels never overlap each other, the outline, or foreign dimension lines (all 25)', () => {
  for (const rec of DATA) {
    const lay = L.layoutDrawing(rec);
    const labels = lay.labels;
    for (let i = 0; i < labels.length; i++) {
      for (let j = i + 1; j < labels.length; j++) {
        assert.ok(!boxesIntersect(labels[i].box, labels[j].box, 0.2), `${rec.key}: "${labels[i].text}" overlaps "${labels[j].text}"`);
      }
      for (const seg of lay.outlineSegments) {
        assert.ok(!segmentHitsBox(seg, labels[i].box, 0.2), `${rec.key}: "${labels[i].text}" touches the outline`);
      }
      for (const dim of lay.dims) {
        if (dim.id === labels[i].owner) continue;
        for (const seg of dim.lines.concat(dim.extLines)) {
          assert.ok(!segmentHitsBox(seg, labels[i].box, 0), `${rec.key}: "${labels[i].text}" crossed by ${dim.id}`);
        }
      }
    }
  }
});

test('everything lies inside the view box', () => {
  for (const rec of DATA) {
    const lay = L.layoutDrawing(rec);
    const vb = lay.viewBox;
    for (const l of lay.labels) {
      assert.ok(l.box.x0 >= vb.x && l.box.x1 <= vb.x + vb.w && l.box.y0 >= vb.y && l.box.y1 <= vb.y + vb.h, `${rec.key} ${l.text}`);
    }
    for (const seg of lay.outlineSegments) {
      assert.ok(seg[0] >= vb.x && seg[2] <= vb.x + vb.w && Math.min(seg[1], seg[3]) >= vb.y && Math.max(seg[1], seg[3]) <= vb.y + vb.h, rec.key);
    }
  }
});

test('title block carries name, table, revision, units and scale', () => {
  const lay = L.layoutDrawing(byKey('223_rem'));
  const t = texts(lay);
  assert.ok(t.includes('223 Rem.'));
  assert.ok(t.includes('C.I.P. TDCC table I'));
  assert.ok(t.includes('Revised 2017-05-17'));
  assert.ok(t.includes('Dimensions in mm'));
  assert.ok(t.some((x) => /^Scale [\d.]+ : 1 \(A4\)$/.test(x)));
  assert.ok(lay.viewBox.w >= lay.titleBlock.w);
});

test('scale text', () => {
  assert.equal(L.formatScale(1), 'Scale 1 : 1');
  assert.equal(L.formatScale(1.904), 'Scale 1.9 : 1');
  assert.equal(L.formatScale(2), 'Scale 2 : 1');
  assert.equal(L.formatScale(0.5), 'Scale 1 : 2');
  assert.equal(L.formatScale(0.8), 'Scale 1 : 1.3');
  assert.equal(L.PRINT_WIDTH_MM, 190);
  assert.equal(L.PRINT_MAX_HEIGHT_MM, 132);
});

test('scale is the A4 print scale derived from the view box width', () => {
  const lay = L.layoutDrawing(byKey('223_rem'));
  const expected = L.formatScale(Math.min(L.PRINT_WIDTH_MM / lay.viewBox.w, L.PRINT_MAX_HEIGHT_MM / lay.viewBox.h)) + ' (A4)';
  assert.ok(lay.labels.some((l) => l.text === expected));
});

test('missing values drop dimensions, never invent them', () => {
  const rec = JSON.parse(JSON.stringify(byKey('308_win')));
  delete rec.cartridge.caseHead.E1;
  delete rec.cartridge.lengths.L6;
  const t = texts(L.layoutDrawing(rec));
  assert.ok(!t.some((x) => /^E1 /.test(x)));
  assert.ok(!t.some((x) => /^L6 /.test(x)));
  assert.ok(t.includes('L3 51.18'));
});

test('a record with no outline gets a title block only', () => {
  const rec = JSON.parse(JSON.stringify(byKey('308_win')));
  delete rec.cartridge.lengths.L3;
  const lay = L.layoutDrawing(rec);
  assert.equal(lay.dims.length, 0);
  assert.ok(texts(lay).includes('308 Win.'));
  assert.ok(lay.viewBox.w > 0 && lay.viewBox.h > 0);
});
