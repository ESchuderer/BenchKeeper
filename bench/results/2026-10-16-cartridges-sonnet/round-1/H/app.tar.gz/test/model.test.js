'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const M = require('../js/model.js');
const DATA = require('../js/data.js');
const byKey = (k) => DATA.find((r) => r.key === k);

test('sections of 243 Win.: tolerance is merged, never a row', () => {
  const secs = M.buildSections(byKey('243_win').cartridge);
  const lengths = secs.find((s) => s.key === 'lengths');
  const l1 = lengths.rows.find((r) => r.symbol === 'L1');
  assert.equal(l1.value, '39.62 -0.2');
  assert.equal(l1.unit, 'mm');
  assert.ok(!secs.some((s) => s.rows.some((r) => /Tol/.test(r.symbol))));
});

test('every non-tolerance field appears exactly once', () => {
  for (const rec of DATA) {
    for (const group of ['cartridge', 'chamber']) {
      const secs = M.buildSections(rec[group]);
      const expected = Object.entries(rec[group]).flatMap(([sec, obj]) =>
        Object.keys(obj).filter((k) => !/Tol$/.test(k)).map((k) => `${sec}.${k}`));
      const actual = secs.flatMap((s) => s.rows.map((r) => `${s.key}.${r.field}`));
      assert.deepEqual(actual.sort(), expected.sort(), `${rec.key} ${group}`);
    }
  }
});

test('empty sections are omitted', () => {
  const secs = M.buildSections(byKey('9_mm_luger').cartridge);
  assert.ok(!secs.some((s) => s.key === 'junctionCone'));
});

test('symbols, units and angles in rows (223 Rem.)', () => {
  const secs = M.buildSections(byKey('223_rem').cartridge);
  const all = secs.flatMap((s) => s.rows);
  const sym = (s) => all.find((r) => r.symbol === s);
  assert.equal(sym('α').value, '46°');
  assert.equal(sym('α').unit, 'deg');
  assert.equal(sym('β').value, '35°');
  assert.equal(sym('δ').value, '25°');
  assert.equal(sym('e min').value, '0.76');
  assert.equal(sym('r1 min').value, '0.64');
  assert.equal(sym('delta L').value, '0.08');
  assert.equal(sym('L3 + G').value, '46.88');
  assert.equal(sym('Pmax').value, '4300');
  assert.equal(sym('Pmax').unit, 'bar');
  assert.equal(sym('EE').unit, 'J');
  assert.equal(sym('M').unit, 'g');
});

test('chamber rows: Q, N, DMS angles, plain i', () => {
  const lapua = M.buildSections(byKey('338_lapua_mag').cartridge).flatMap((s) => s.rows);
  assert.equal(lapua.find((r) => r.symbol === 'α').value, "39°59'49\"");
  const ch = M.buildSections(byKey('223_rem').chamber).flatMap((s) => s.rows);
  assert.equal(ch.find((r) => r.symbol === 'Q').unit, 'mm²');
  assert.equal(ch.find((r) => r.symbol === 'N').unit, '');
  assert.equal(ch.find((r) => r.symbol === 'i').value, "3°10'36\"");
  assert.equal(ch.find((r) => r.symbol === 'r1 max').value, '0.64');
  const rem = M.buildSections(byKey('7_mm_rem_mag').chamber).flatMap((s) => s.rows);
  assert.equal(rem.find((r) => r.symbol === 'i').value, '3°');
});

test('metadata rows', () => {
  const rows = M.buildMetadata(byKey('308_win'));
  const get = (label) => rows.find((r) => r.label === label);
  assert.deepEqual(get('Alternative names').value, '308 Winchester, 7,62 x 51');
  assert.equal(get('Family').value, 'rimless');
  assert.equal(get('Category').value, 'rifle');
  assert.equal(get('Primer type').value, 'lr');
  assert.equal(get('C.I.P. table').value, 'I');
  assert.equal(get('Country').value, 'US');
  assert.equal(get('Published').value, '1984-06-14');
  assert.equal(get('Revised').value, '2008-09-23');
  assert.equal(get('Pressure method').value, 'Transducer');
  const cap = get('Water capacity');
  assert.equal(cap.value, '56 grH2O');
  assert.equal(cap.link.url, 'http://kwk.us/cases.html');
  assert.equal(cap.link.text, 'kwk');
  assert.match(cap.note, /Lapua brass measures 55.8/);
});

test('metadata without alternative names or capacity', () => {
  const rows = M.buildMetadata(byKey('7_x_64'));
  assert.equal(rows.find((r) => r.label === 'Alternative names').value, '');
  const cap = rows.find((r) => r.label === 'Water capacity');
  assert.equal(cap.value, 'Not published');
  assert.equal(cap.link, undefined);
});

test('search matches name and alternative names, case-insensitive', () => {
  const names = (q) => M.filterRecords(DATA, { query: q, family: 'all' }).map((r) => r.name);
  assert.deepEqual(names('7,62 x 51'), ['308 Win.']);
  assert.deepEqual(names('308 winchester'), ['308 Win.']);
  assert.deepEqual(names('7,62 x 63'), ['30-06 Spring.']);
  assert.deepEqual(names('22LR'), ['22 Long Rifle']);
  assert.equal(names('').length, 25);
  assert.equal(names('   ').length, 25);
  assert.deepEqual(names('zzz'), []);
});

test('search treats comma and point alike and collapses spaces', () => {
  const names = (q) => M.filterRecords(DATA, { query: q, family: 'all' }).map((r) => r.name);
  assert.deepEqual(names('6.5 creedmoor'), ['6,5 Creedmoor']);
  assert.deepEqual(names('7,62   x 51'), ['308 Win.']);
});

test('family filter and combination with search', () => {
  const f = (family, query = '') => M.filterRecords(DATA, { query, family }).map((r) => r.name);
  assert.deepEqual(f('belted'), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(f('rimless').length, 12);
  assert.equal(f('rimmed').length, 2);
  assert.equal(f('pistol').length, 6);
  assert.equal(f('rimfire').length, 3);
  assert.deepEqual(f('rimfire', 'win'), ['22 Win. Mag. R.F.']);
  assert.deepEqual(f('pistol', '308'), []);
});

test('routing', () => {
  assert.deepEqual(M.parseRoute(''), { view: 'list' });
  assert.deepEqual(M.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(M.parseRoute('#'), { view: 'list' });
  assert.deepEqual(M.parseRoute('#/cartridge/308_win'), { view: 'detail', key: '308_win' });
  assert.deepEqual(M.parseRoute('#/cartridge/nope'), { view: 'notfound', key: 'nope' });
  assert.deepEqual(M.parseRoute('#/other'), { view: 'notfound', key: '' });
  assert.equal(M.detailHash('308_win'), '#/cartridge/308_win');
  assert.equal(M.findByKey(DATA, '308_win').name, '308 Win.');
  assert.equal(M.findByKey(DATA, 'x'), undefined);
});
