# C.I.P. cartridges

A static reference database of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on the cartridge database of [OpenBallistics](https://openreloading.github.io/OpenBallistics/): a searchable list, a detail view per cartridge with all published cartridge and chamber values, a true-scale drawing computed from those values, and a one-page A4 printout.

Plain HTML, CSS and JavaScript. No framework, no build step, no runtime dependencies, no network requests.

## Use it

- **From disk:** open `index.html` in Chromium (`file://`). Nothing else is needed.
- **From a server:** serve the folder with any static file server, e.g. `npm run serve` (this repo's tiny dev server, `http://localhost:8080/`) or `python3 -m http.server`.

Addresses: `#/` is the list, `#/cartridge/<key>` a detail view (e.g. `#/cartridge/308_win`). They survive a reload and can be bookmarked.

## Files

| Path | Purpose |
| --- | --- |
| `index.html`, `css/app.css`, `css/drawing.css`, `css/print.css` | page, theme (light/dark), SVG styles, A4 print |
| `js/data.js` | the 25 records, verbatim (generated from `tests/fixtures/cartridges.jsonl` by `npm run data`) |
| `js/format.js` | number/angle/tolerance formatting, symbols, units, table model |
| `js/filter.js` | search and family filter |
| `js/geometry.js` | drawing geometry (pure function of a record, mm) |
| `js/layout.js` | dimension lines, label placement, title block, scale |
| `js/drawing.js` | SVG string |
| `js/app.js` | routing and views |

The logic files work in the browser and in Node (`require`), so the same code is tested.

## Tests

Dev tools only (`npm install`): Node 22's built-in test runner and Playwright.

```sh
npm install
npx playwright install chromium   # once, for the browser tests
npm test            # unit tests: formatting, filter, geometry, layout, SVG, delivery constraints
npm run test:e2e    # Chromium: file:// and http, list/detail, print to PDF (one A4 page for all 25), dark, phone, keyboard
npm run test:all
```

`node tools/render-drawings.js [key...]` writes PNGs of the drawings to `test-output/drawings/` and `node tools/screenshots.js [key]` screenshots of the app to `test-output/screens/`.

Chromium needs system libraries and a font. On a machine without root, unpack the missing `.deb`s into `~/.local/chromium-libs` (a `fonts.conf` there is picked up too); `tests/e2e/browser.js` puts them on `LD_LIBRARY_PATH` / `FONTCONFIG_FILE` if the folder exists.

## Data

The 25 records are from [OpenBallistics](https://github.com/PiMetry/OpenBallistics) (MIT, commit e83db43); the underlying source is C.I.P. TDCC. They are used as given: nothing is added, changed or fetched. Numbers are shown as published after JSON parsing (`4150.0` is shown `4150`). Tolerances (`L1Tol`) are shown next to their value, never as a row of their own.

## Drawing: how it is made

Rules follow the brief. Where it leaves room, these choices were made (see `openspec/changes/cartridge-database/design.md`):

- Points are (radius, z); z runs from the head face to the mouth.
- Shoulder: drawn through the published points; α is only labelled. Fillets (r1 min, r2) are tangent arcs, shrunk if they would not fit.
- Rimfire rim edge: a semicircle of radius min(R/2, (R1 − P1)/2) whose outermost point is at R1/2.
- Belted: the δ ramp climbs `(R3/2 − E1/2) / tan δ` in z; δ is measured from the axis.
- Straight (non-heeled) case wall: tb at the solid head, blending linearly to tn at the bullet base, tn to the mouth, so the seated bullet is never overlapped. Heeled cases keep tb.
- Inner wall points are the outer points offset radially (not along the normal).
- Diameters are vertical dimension lines across the full section, with flag labels above the cartridge; lengths are stacked below; α is an arc about the cone apex.
- Label font size is viewBox width / 34 (about 10 CSS px on a 360 px screen). The title block states the scale at which the drawing prints on A4 (190 mm wide); a 10 mm scale bar makes it checkable on screen.
- The unit of `u` (twist) is not given in the brief; it is shown in mm (it is a length).
- A missing value that a rule needs omits that feature and is named in a note under the drawing; nothing is invented. Absent α/L1/L2 means a straight case by rule, not a missing value.
