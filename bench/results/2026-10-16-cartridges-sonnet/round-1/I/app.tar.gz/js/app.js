/* Views and routing: the list at #/ and one detail view per cartridge at #/cartridge/<key>. */
(function () {
  'use strict';

  var CIP = window.CIP;
  var main = document.getElementById('main');
  var state = { query: '', family: 'All' };
  var byKey = {};
  CIP.data.forEach(function (r) {
    byKey[r.key] = r;
  });

  /* ---------- tiny DOM helper ---------- */

  function h(tag, props) {
    var el = document.createElement(tag);
    for (var k in props || {}) {
      if (k === 'text') el.textContent = props[k];
      else if (k === 'class') el.className = props[k];
      else if (props[k] !== undefined && props[k] !== null) el.setAttribute(k, props[k]);
    }
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c === null || c === undefined) continue;
      el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return el;
  }

  /* ---------- list view ---------- */

  function listView() {
    var tbody = h('tbody');
    var empty = h('p', { class: 'empty', hidden: '', text: 'No cartridge matches the search.' });
    var count = h('p', { id: 'count', class: 'count', 'aria-live': 'polite' });
    var table = h(
      'table',
      { class: 'cartridge-list' },
      h('caption', { class: 'visually-hidden', text: 'Cartridges' }),
      h('thead', null, h('tr', null, h('th', { scope: 'col', text: 'Name' }), h('th', { scope: 'col', text: 'Family' }), h('th', { scope: 'col', class: 'num', text: 'L3 (mm)' }))),
      tbody
    );

    function update() {
      var rows = CIP.filter.filterCartridges(CIP.data, state);
      tbody.textContent = '';
      rows.forEach(function (r) {
        tbody.appendChild(
          h(
            'tr',
            null,
            h('th', { scope: 'row' }, h('a', { href: '#/cartridge/' + r.key, text: r.name })),
            h('td', { text: r.family }),
            h('td', { class: 'num', text: CIP.format.formatNumber(r.cartridge.lengths.L3) })
          )
        );
      });
      count.textContent = CIP.filter.countText(rows.length);
      if (rows.length) empty.setAttribute('hidden', '');
      else empty.removeAttribute('hidden');
      table.hidden = rows.length === 0;
    }

    var search = h('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false' });
    search.value = state.query;
    search.addEventListener('input', function () {
      state.query = search.value;
      update();
    });
    var family = h('select', { id: 'family' });
    CIP.filter.FAMILIES.forEach(function (f) {
      family.appendChild(h('option', { value: f, text: f }));
    });
    family.value = state.family;
    family.addEventListener('change', function () {
      state.family = family.value;
      update();
    });

    var form = h(
      'form',
      { class: 'filters', role: 'search' },
      h('div', { class: 'field' }, h('label', { for: 'search', text: 'Search' }), search),
      h('div', { class: 'field' }, h('label', { for: 'family', text: 'Family' }), family),
      count
    );
    form.addEventListener('submit', function (e) {
      e.preventDefault();
    });

    var view = h('div', { class: 'list-view' }, h('h1', { tabindex: '-1', text: 'Cartridges' }), form, table, empty);
    update();
    return { el: view, title: 'Cartridges' };
  }

  /* ---------- detail view ---------- */

  function fact(dl, label, content) {
    dl.appendChild(h('dt', { text: label }));
    var dd = h('dd');
    if (typeof content === 'string') dd.textContent = content;
    else dd.appendChild(content);
    dl.appendChild(dd);
  }

  function factsList(r) {
    var dl = h('dl', { class: 'facts' });
    if (r.alternativeNames && r.alternativeNames.length) fact(dl, 'Alternative names', r.alternativeNames.join(', '));
    fact(dl, 'Family', r.family);
    fact(dl, 'Category', r.annotations.category);
    fact(dl, 'Primer type', r.annotations.primerType);
    fact(dl, 'C.I.P. table', r.tab);
    fact(dl, 'Country', r.country);
    fact(dl, 'Published', r.published);
    fact(dl, 'Revised', r.revised);
    fact(dl, 'Pressure method', r.pressureMethod);
    var cap = CIP.format.formatCapacity(r);
    var capEl = h('span', { text: cap.text });
    if (cap.url && /^https?:\/\//.test(cap.url)) {
      capEl.appendChild(document.createTextNode(' – source: '));
      capEl.appendChild(h('a', { href: cap.url, rel: 'noopener noreferrer', text: cap.source || cap.url }));
    }
    if (cap.note) capEl.appendChild(h('span', { class: 'note', text: ' (' + cap.note + ')' }));
    fact(dl, 'Water capacity', capEl);
    return dl;
  }

  function valueTable(section) {
    var body = h('tbody');
    section.rows.forEach(function (row) {
      body.appendChild(
        h('tr', null, h('th', { scope: 'row', text: row.symbol }), h('td', { class: 'num', text: row.value }), h('td', { class: 'unit', text: row.unit }))
      );
    });
    return h(
      'table',
      { class: 'values' },
      h('caption', { text: section.title }),
      h('thead', null, h('tr', null, h('th', { scope: 'col', text: 'Symbol' }), h('th', { scope: 'col', class: 'num', text: 'Value' }), h('th', { scope: 'col', text: 'Unit' }))),
      body
    );
  }

  function detailView(r) {
    var drawing = CIP.drawing.renderDrawing(r);
    var figure = h('figure', { class: 'drawing' });
    var holder = h('div', { class: 'drawing-svg' });
    holder.innerHTML = drawing.svg; // generated from numbers and escaped text only
    figure.appendChild(holder);
    if (drawing.notes.length) {
      var ul = h('ul', { class: 'drawing-notes', 'aria-label': 'Drawing notes' });
      drawing.notes.forEach(function (t) {
        ul.appendChild(h('li', { text: t }));
      });
      figure.appendChild(ul);
    }

    var print = h('button', { type: 'button', class: 'button', text: 'Print' });
    print.addEventListener('click', function () {
      window.print();
    });

    var secs = CIP.format.sections(r);
    var valueBlocks = [];
    ['cartridge', 'chamber'].forEach(function (scope) {
      var tables = h('div', { class: 'tables' });
      secs
        .filter(function (s) {
          return s.scope === scope;
        })
        .forEach(function (s) {
          tables.appendChild(valueTable(s));
        });
      valueBlocks.push(h('section', { class: 'value-block' }, h('h2', { text: CIP.format.SCOPE_TITLES[scope] + ' values' }), tables));
    });

    var view = h(
      'article',
      { class: 'detail' },
      h('h1', { tabindex: '-1', text: r.name }),
      h('nav', { class: 'toolbar', 'aria-label': 'Cartridge actions' }, h('a', { href: '#/', text: 'All cartridges' }), print),
      factsList(r),
      figure,
      h('div', { class: 'values-wrap' }, valueBlocks[0], valueBlocks[1]),
      h('footer', { class: 'print-footer', text: 'Source: C.I.P. TDCC, revised ' + r.revised })
    );
    return { el: view, title: r.name };
  }

  function notFoundView() {
    return {
      el: h(
        'div',
        { class: 'not-found' },
        h('h1', { tabindex: '-1', text: 'Cartridge not found' }),
        h('p', null, 'There is no cartridge at this address. ', h('a', { href: '#/', text: 'All cartridges' }))
      ),
      title: 'Cartridge not found'
    };
  }

  /* ---------- routing ---------- */

  function route() {
    var hash = window.location.hash || '#/';
    var m = /^#\/cartridge\/([^/?#]+)$/.exec(hash);
    if (m) {
      var key;
      try {
        key = decodeURIComponent(m[1]);
      } catch (e) {
        return notFoundView();
      }
      return Object.prototype.hasOwnProperty.call(byKey, key) ? detailView(byKey[key]) : notFoundView();
    }
    if (hash === '#/' || hash === '#' || hash === '') return listView();
    return notFoundView();
  }

  var first = true;
  function render() {
    var view = route();
    main.textContent = '';
    main.appendChild(view.el);
    document.title = view.title === 'Cartridges' ? 'C.I.P. cartridges' : view.title + ' – C.I.P. cartridges';
    if (!first) {
      window.scrollTo(0, 0);
      var h1 = main.querySelector('h1');
      if (h1) h1.focus({ preventScroll: true });
    }
    first = false;
  }

  window.addEventListener('hashchange', render);
  render();
})();
