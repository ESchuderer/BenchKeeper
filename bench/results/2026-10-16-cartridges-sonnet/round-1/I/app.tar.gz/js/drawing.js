/* Renders the layout of one cartridge as an inline SVG string (1 user unit = 1 mm). */
(function (root) {
  'use strict';

  var node = typeof module === 'object' && module.exports;
  var G = node ? require('./geometry.js') : root.CIP.geometry;
  var L = node ? require('./layout.js') : root.CIP.layout;

  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return ESC[c];
    });
  }

  function n(x) {
    return x.toFixed(3);
  }

  /* SVG path data for a geometry path; sign -1 = upper half (y = oy - r), +1 = lower half (y = oy + r) */
  function pathData(items, ox, oy, sign) {
    var d = '';
    items.forEach(function (it, i) {
      var x = ox + it.z;
      var y = oy + sign * it.r;
      if (i === 0) d += 'M' + n(x) + ' ' + n(y);
      else if (it.arc) {
        var a = it.arc;
        var large = Math.abs(a.a1 - a.a0) > Math.PI ? 1 : 0;
        var inc = a.a1 > a.a0;
        var sweep = (sign < 0) === inc ? 1 : 0;
        d += 'A' + n(a.rz) + ' ' + n(a.rr) + ' 0 ' + large + ' ' + sweep + ' ' + n(x) + ' ' + n(y);
      } else d += 'L' + n(x) + ' ' + n(y);
    });
    return d;
  }

  function line(s, cls, extra) {
    return '<line class="' + cls + '" x1="' + n(s.x1) + '" y1="' + n(s.y1) + '" x2="' + n(s.x2) + '" y2="' + n(s.y2) + '"' + (extra || '') + '/>';
  }

  function arrowPoly(a) {
    var s = a.size;
    var nx = -a.uy;
    var ny = a.ux;
    var bx = a.x - a.ux * s;
    var by = a.y - a.uy * s;
    var w = 0.3 * s;
    var pts = [[a.x, a.y], [bx + nx * w, by + ny * w], [bx - nx * w, by - ny * w]];
    return (
      '<polygon class="cip-arrow" points="' +
      pts
        .map(function (p) {
          return n(p[0]) + ',' + n(p[1]);
        })
        .join(' ') +
      '"/>'
    );
  }

  function text(x, y, str, size, cls, extra) {
    var w = L.textWidth(str, size);
    return (
      '<text class="' + cls + '" x="' + n(x) + '" y="' + n(y) + '" font-size="' + n(size) + '" textLength="' + n(w) + '" lengthAdjust="spacingAndGlyphs"' + (extra || '') + '>' + esc(str) + '</text>'
    );
  }

  function renderDrawing(record) {
    var model = G.buildDrawing(record);
    var notes = model.notes.map(function (x) {
      return x.text;
    });
    var label = record.name + ' drawing';
    var head =
      '<svg class="cip-drawing" role="img" aria-label="' + esc(label) + '" preserveAspectRatio="xMidYMin meet" ';

    if (!model.ok) {
      return {
        svg: head + 'viewBox="0 0 100 20"><title>' + esc(label) + '</title><text x="2" y="10" font-size="4">Drawing not available</text></svg>',
        layout: null,
        model: model,
        notes: notes
      };
    }

    var lay = L.layoutDrawing(record, model);
    var ox = lay.origin.x;
    var oy = lay.origin.y;
    var len = record.cartridge.lengths;
    var bullet = model.bullet;
    var fs = lay.fs;
    var out = [];

    out.push(head + 'viewBox="0 0 ' + n(lay.vbW) + ' ' + n(lay.vbH) + '">');
    out.push('<title>' + esc(label) + '</title>');
    out.push(
      '<defs><pattern id="cip-hatch" width="' + n(0.9) + '" height="' + n(0.9) + '" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
        '<line class="cip-hatch-line" x1="0" y1="0" x2="0" y2="' + n(0.9) + '"/></pattern></defs>'
    );

    /* outside view (upper half): a fill path, and an open stroke path that does not run along the axis */
    var upItems = model.outer.items.slice();
    if (bullet) {
      upItems.push({ r: bullet.exposedR, z: len.L3 });
      upItems = upItems.concat(bullet.exposed.items.slice(1));
    }
    var upD = pathData(upItems, ox, oy, -1);
    out.push('<g class="cip-outside"><path class="cip-body" d="' + upD + 'Z"/><path class="cip-line" d="' + upD + '"/>');
    if (bullet) {
      out.push('<path class="cip-seat" d="M' + n(ox + len.L3) + ' ' + n(oy - bullet.exposedR) + 'L' + n(ox + len.L3) + ' ' + n(oy) + '"/>');
    }
    out.push('</g>');

    /* section (lower half) */
    out.push('<g class="cip-section">');
    if (bullet) {
      var bd = pathData(bullet.seated.items, ox, oy, 1);
      out.push('<g class="cip-bullet-section"><path class="cip-bullet" d="' + bd + 'Z"/><path class="cip-line" d="' + bd + '"/></g>');
    }
    if (model.section) {
      var sd = pathData(model.section.items, ox, oy, 1);
      out.push('<path class="cip-wall" fill="url(#cip-hatch)" d="' + sd + 'Z"/><path class="cip-line" d="' + sd + '"/>');
    } else {
      out.push('<path class="cip-line" d="' + pathData(model.outer.items, ox, oy, 1) + '"/>');
    }
    out.push('</g>');

    /* centre line (dash-dot), drawn over the fills so it shows inside the cartridge */
    out.push(
      line({ x1: lay.axis.x1, y1: lay.axis.y, x2: lay.axis.x2, y2: lay.axis.y }, 'cip-axis', ' stroke-dasharray="' + [n(1.6 * fs), n(0.45 * fs), n(0.3 * fs), n(0.45 * fs)].join(' ') + '"')
    );

    /* dimensions */
    out.push('<g class="cip-dims">');
    lay.lines.forEach(function (s) {
      out.push(line(s, 'cip-' + s.cls));
    });
    lay.arcs.forEach(function (a) {
      out.push('<path class="cip-dim" d="M' + n(a.x1) + ' ' + n(a.y1) + 'A' + n(a.rho) + ' ' + n(a.rho) + ' 0 0 0 ' + n(a.x2) + ' ' + n(a.y2) + '"/>');
    });
    lay.arrows.forEach(function (a) {
      out.push(arrowPoly(a));
    });
    lay.dots.forEach(function (d) {
      out.push('<circle class="cip-dot" cx="' + n(d.x) + '" cy="' + n(d.y) + '" r="' + n(d.r) + '"/>');
    });
    out.push('</g>');

    /* labels */
    out.push('<g class="cip-labels">');
    lay.labels.forEach(function (l) {
      out.push(text(l.x, l.y, l.text, fs, 'cip-label'));
    });
    out.push('</g>');

    /* title block */
    var t = lay.title;
    out.push('<g class="cip-title">');
    out.push('<rect class="cip-frame" x="' + n(t.rect.x) + '" y="' + n(t.rect.y) + '" width="' + n(t.rect.w) + '" height="' + n(t.rect.h) + '"/>');
    t.dividers.forEach(function (dv) {
      out.push(line(dv, 'cip-frame-line'));
    });
    t.texts.forEach(function (x, i) {
      out.push(text(x.x, x.y, x.text, x.size, i === 0 ? 'cip-title-name' : 'cip-title-text'));
    });
    var sb = t.scaleBar;
    out.push(line({ x1: sb.x1, y1: sb.y, x2: sb.x2, y2: sb.y }, 'cip-scalebar'));
    out.push(line({ x1: sb.x1, y1: sb.y - 0.4 * fs, x2: sb.x1, y2: sb.y + 0.4 * fs }, 'cip-scalebar'));
    out.push(line({ x1: sb.x2, y1: sb.y - 0.4 * fs, x2: sb.x2, y2: sb.y + 0.4 * fs }, 'cip-scalebar'));
    out.push(text(sb.labelX, sb.y + 0.3 * fs, sb.label, sb.labelSize, 'cip-title-text'));
    out.push('</g>');

    out.push('</svg>');
    return { svg: out.join(''), layout: lay, model: model, notes: notes };
  }

  var api = { renderDrawing: renderDrawing, esc: esc };

  if (node) module.exports = api;
  else {
    root.CIP = root.CIP || {};
    root.CIP.drawing = api;
  }
})(typeof self !== 'undefined' ? self : globalThis);
