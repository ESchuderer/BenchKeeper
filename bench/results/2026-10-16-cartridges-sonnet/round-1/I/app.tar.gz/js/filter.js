/* Search and family filter for the cartridge list. */
(function (root) {
  'use strict';

  var FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  function normalise(text) {
    return String(text).toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function matchesQuery(record, q) {
    if (!q) return true;
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (n) {
      return normalise(n).indexOf(q) !== -1;
    });
  }

  function filterCartridges(records, state) {
    var q = normalise(state.query || '');
    var family = state.family || 'All';
    return records.filter(function (r) {
      return (family === 'All' || r.family === family) && matchesQuery(r, q);
    });
  }

  function countText(n) {
    return n + ' cartridges';
  }

  var api = { FAMILIES: FAMILIES, filterCartridges: filterCartridges, countText: countText };

  if (typeof module === 'object' && module.exports) module.exports = api;
  else {
    root.CIP = root.CIP || {};
    root.CIP.filter = api;
  }
})(typeof self !== 'undefined' ? self : globalThis);
