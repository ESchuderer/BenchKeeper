/* Formatting of record values: numbers, angles, tolerances, symbols, units and the table model. */
(function (root) {
  'use strict';

  var SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G'
  };

  var ANGLE_FIELDS = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  // Units other than mm. N is a count and has no unit. u (twist) is a length in mm (design D5).
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };

  var GROUP_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling'
  };

  var SCOPE_TITLES = { cartridge: 'Cartridge', chamber: 'Chamber' };

  function formatNumber(v) {
    return String(v);
  }

  function isAngleObject(a) {
    return a !== null && typeof a === 'object';
  }

  function formatAngle(a) {
    if (isAngleObject(a)) {
      return a.degrees + '°' + a.minutes + "'" + a.seconds + '"';
    }
    return formatNumber(a) + '°';
  }

  function angleToDegrees(a) {
    if (isAngleObject(a)) return a.degrees + a.minutes / 60 + a.seconds / 3600;
    return a;
  }

  function symbol(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function unit(field) {
    if (ANGLE_FIELDS[field]) return '°';
    if (Object.prototype.hasOwnProperty.call(UNITS, field)) return UNITS[field];
    return 'mm';
  }

  function formatValue(field, value) {
    return ANGLE_FIELDS[field] ? formatAngle(value) : formatNumber(value);
  }

  function groupTitle(group) {
    if (GROUP_TITLES[group]) return GROUP_TITLES[group];
    var t = group.replace(/([A-Z])/g, ' $1').toLowerCase();
    return t.charAt(0).toUpperCase() + t.slice(1);
  }

  function isTolField(name) {
    return /Tol$/.test(name);
  }

  /* Table model: one section per non-empty group of `cartridge` and `chamber`. */
  function sections(record) {
    var out = [];
    ['cartridge', 'chamber'].forEach(function (scope) {
      var groups = record[scope] || {};
      Object.keys(groups).forEach(function (group) {
        var obj = groups[group];
        var rows = [];
        Object.keys(obj).forEach(function (field) {
          if (isTolField(field)) return;
          var text = formatValue(field, obj[field]);
          var tol = obj[field + 'Tol'];
          if (tol !== undefined) text += ' ' + formatNumber(tol);
          rows.push({ field: field, symbol: symbol(field), value: text, unit: unit(field) });
        });
        if (rows.length) {
          out.push({
            scope: scope,
            scopeTitle: SCOPE_TITLES[scope],
            group: group,
            title: groupTitle(group),
            rows: rows
          });
        }
      });
    });
    return out;
  }

  function formatCapacity(record) {
    var c = record.annotations && record.annotations.publishedCapacity;
    if (!c || typeof c.grH2O !== 'number') return { text: 'not published', url: null, source: null, note: null };
    return {
      text: formatNumber(c.grH2O) + ' gr H2O',
      url: c.url || null,
      source: c.source || null,
      note: c.note || null
    };
  }

  var api = {
    formatNumber: formatNumber,
    formatAngle: formatAngle,
    angleToDegrees: angleToDegrees,
    symbol: symbol,
    unit: unit,
    sections: sections,
    formatCapacity: formatCapacity,
    SCOPE_TITLES: SCOPE_TITLES
  };

  if (typeof module === 'object' && module.exports) module.exports = api;
  else {
    root.CIP = root.CIP || {};
    root.CIP.format = api;
  }
})(typeof self !== 'undefined' ? self : globalThis);
