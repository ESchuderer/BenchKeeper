/* Cartridge geometry: a pure function of one record, in mm.
   Points are {r, z}: r is the radius (half the diameter), z runs along the axis from the head face (z = 0) to the mouth.
   Paths hold line-to points and arcs; an arc item is {r, z, arc: {c, rr, rz, a0, a1}} where the arc runs from the previous
   point to (r, z) and point(t) = (c.r + rr*cos t, c.z + rz*sin t) for t from a0 to a1. */
(function (root) {
  'use strict';

  var node = typeof module === 'object' && module.exports;
  var F = node ? require('./format.js') : root.CIP.format;

  var PI = Math.PI;
  var HEELED_LIMIT = 0.015;

  /* ---------- small helpers ---------- */

  function isNum(v) {
    return typeof v === 'number' && isFinite(v);
  }

  function Path(start) {
    this.items = [{ r: start.r, z: start.z }];
  }
  Path.prototype.last = function () {
    return this.items[this.items.length - 1];
  };
  Path.prototype.line = function (r, z) {
    this.items.push({ r: r, z: z });
    return this;
  };
  Path.prototype.arc = function (c, rr, rz, a0, a1) {
    this.items.push({
      r: c.r + rr * Math.cos(a1),
      z: c.z + rz * Math.sin(a1),
      arc: { c: c, rr: rr, rz: rz, a0: a0, a1: a1 }
    });
    return this;
  };

  /* Polyline approximation of a path (arcs sampled about every 0.1 rad). */
  function flatten(path) {
    var items = path.items || path;
    var out = [];
    items.forEach(function (it, i) {
      if (i === 0) {
        out.push({ r: it.r, z: it.z });
      } else if (it.arc) {
        var a = it.arc;
        var n = Math.max(4, Math.ceil(Math.abs(a.a1 - a.a0) / 0.1));
        for (var k = 1; k < n; k++) {
          var t = a.a0 + ((a.a1 - a.a0) * k) / n;
          out.push({ r: a.c.r + a.rr * Math.cos(t), z: a.c.z + a.rz * Math.sin(t) });
        }
        out.push({ r: it.r, z: it.z });
      } else {
        out.push({ r: it.r, z: it.z });
      }
    });
    return out;
  }

  /* Radius at z of a polyline whose z is non-decreasing. */
  function interp(pts, z) {
    if (z <= pts[0].z) return pts[0].r;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1];
      var b = pts[i];
      if (b.z > a.z && z >= a.z - 1e-12 && z <= b.z + 1e-12) {
        return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
      }
    }
    return pts[pts.length - 1].r;
  }

  function unit(a, b) {
    var dr = b.r - a.r;
    var dz = b.z - a.z;
    var l = Math.hypot(dr, dz);
    return { r: dr / l, z: dz / l, len: l };
  }

  /* Rounds the corner P between prev and next with a tangent circle of the given radius.
     maxT limits the tangent distance (the radius shrinks when the corner would not fit). */
  function fillet(prev, P, next, radius, maxT) {
    var d1 = unit(prev, P);
    var d2 = unit(P, next);
    var cross = d1.r * d2.z - d1.z * d2.r;
    var dot = d1.r * d2.r + d1.z * d2.z;
    var phi = Math.atan2(Math.abs(cross), dot);
    if (phi < 1e-6) return null;
    var t = radius * Math.tan(phi / 2);
    if (t > maxT) {
      radius = maxT / Math.tan(phi / 2);
      t = maxT;
    }
    var T1 = { r: P.r - d1.r * t, z: P.z - d1.z * t };
    var T2 = { r: P.r + d2.r * t, z: P.z + d2.z * t };
    var sign = cross > 0 ? 1 : -1;
    var c = { r: T1.r + -d1.z * sign * radius, z: T1.z + d1.r * sign * radius };
    var a0 = Math.atan2(T1.z - c.z, T1.r - c.r);
    var a1 = Math.atan2(T2.z - c.z, T2.r - c.r);
    var delta = a1 - a0;
    while (delta > PI) delta -= 2 * PI;
    while (delta <= -PI) delta += 2 * PI;
    return { T1: T1, T2: T2, c: c, radius: radius, a0: a0, a1: a0 + delta, tangent: t };
  }

  function rad(deg) {
    return (deg * PI) / 180;
  }

  /* ---------- rules ---------- */

  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    var c = record.cartridge || {};
    var R1 = c.caseHead && c.caseHead.R1;
    var P1 = c.powderChamber && c.powderChamber.P1;
    if (!isNum(R1) || !isNum(P1)) return 'rimless';
    var ratio = R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function wallThickness(v) {
    var tn = Math.max(v.tn, 0);
    var tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * v.P1) / 2);
    return { tn: tn, tb: tb };
  }

  function pocketFor(primerType) {
    var small = { sp: 1, spm: 1, sr: 1 };
    var large = { lp: 1, lpm: 1, lr: 1, lrm: 1 };
    var d = small[primerType] ? 4.45 : large[primerType] ? 5.33 : null;
    if (d === null) return null;
    var depth = primerType === 'lr' || primerType === 'lrm' ? 3.3 : 3.04;
    return { d: d, depth: depth };
  }

  var BULLET_RULES = {
    pointy: { seat: { rifle: 1.0, pistol: 1.0 }, k: { rifle: 0.4, pistol: 0.4 } },
    rounded: { seat: { rifle: 0.8, pistol: 0.4 }, k: { rifle: 0.55, pistol: 0.65 } },
    flat: { seat: { rifle: 0.8, pistol: 0.4 }, k: { rifle: 0.6, pistol: 0.7 } },
    semi_wadcutter: { seat: { rifle: 0.6, pistol: 0.6 }, k: { rifle: 0.78, pistol: 0.78 } }
  };

  function listText(fields) {
    var names = fields.map(F.symbol);
    if (names.length <= 1) return names.join('');
    return names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1];
  }

  function note(notes, feature, fields, what) {
    notes.push({
      feature: feature,
      missing: fields.slice(),
      text: what + ' not drawn: ' + listText(fields) + (fields.length > 1 ? ' are' : ' is') + ' not published.'
    });
  }

  function missingOf(obj, names) {
    return names.filter(function (n) {
      return !isNum(obj[n]);
    });
  }

  /* ---------- the drawing model ---------- */

  function buildDrawing(record) {
    var c = record.cartridge || {};
    var head = c.caseHead || {};
    var collar = c.collar || {};
    var jc = c.junctionCone || {};
    var len = c.lengths || {};
    var pc = c.powderChamber || {};
    var proj = c.projectile || {};
    var ann = record.annotations || {};
    var notes = [];

    var R1 = head.R1, R = head.R, E = head.E, E1 = head.E1, eMin = head.eMin, f = head.f, R3 = head.R3;
    var P1 = pc.P1, P2 = pc.P2, H1 = collar.H1, H2 = collar.H2, G1 = proj.G1;
    var L1 = len.L1, L2 = len.L2, L3 = len.L3, L6 = len.L6;
    var type = rimType(record);
    var beta = isNum(head.beta) ? F.angleToDegrees(head.beta) : undefined;
    var delta = isNum(head.delta) ? F.angleToDegrees(head.delta) : undefined;

    var core = missingOf({ R1: R1, R: R, P1: P1, L3: L3 }, ['R1', 'R', 'P1', 'L3']);
    if (core.length) {
      note(notes, 'outline', core, 'Cartridge outline');
      return { ok: false, rimType: type, notes: notes };
    }

    var features = { rimType: type, keyPoints: {} };
    var outer = new Path({ r: 0, z: 0 });

    /* head face and rim edge (rule 2) */
    if (type === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      if (rho > 0) {
        outer.line(R1 / 2 - rho, 0);
        outer.arc({ r: R1 / 2 - rho, z: rho }, rho, rho, -PI / 2, PI / 2);
        if (2 * rho < R - 1e-9) outer.line(R1 / 2 - rho, R);
        features.halfRound = rho;
      } else {
        outer.line(R1 / 2, 0).line(R1 / 2, R);
      }
    } else if (isNum(beta) && isNum(f) && beta < 90) {
      var a = R1 / 2 - Math.min(f * Math.tan(rad(beta)), R1 / 4);
      outer.line(a, 0).line(R1 / 2, f).line(R1 / 2, R);
    } else {
      var miss = missingOf({ beta: beta, f: f }, ['beta', 'f']);
      if (miss.length) note(notes, 'chamfer', miss, 'Head chamfer');
      outer.line(R1 / 2, 0).line(R1 / 2, R);
    }

    /* extractor groove, belt, or plain step (rule 3) */
    var zs = R;
    var grooveMissing = missingOf({ E: E, E1: E1, eMin: eMin }, ['E', 'E1', 'eMin']);
    var beltRampEnd = null;
    if (!grooveMissing.length) {
      outer.line(E1 / 2, R).line(E1 / 2, R + eMin);
      var belt = false;
      if (type === 'belted') {
        var beltMissing = missingOf({ R3: R3, delta: delta }, ['R3', 'delta']);
        if (beltMissing.length) {
          note(notes, 'belt', beltMissing, 'Belt');
        } else if (R3 / 2 > E1 / 2) {
          var zr = R + eMin + (R3 / 2 - E1 / 2) / Math.tan(rad(delta));
          if (zr <= E) {
            outer.line(R3 / 2, zr).line(R3 / 2, E).line(P1 / 2, E);
            beltRampEnd = zr;
            belt = true;
          }
        }
      }
      if (!belt) outer.line(P1 / 2, E);
      zs = E;
      features.groove = true;
    } else {
      if (type !== 'rimfire') note(notes, 'groove', grooveMissing, 'Extractor groove');
      outer.line(P1 / 2, R);
      features.groove = false;
    }
    features.beltRampEnd = beltRampEnd;
    features.bodyStart = zs;

    /* body, shoulder, neck (rules 4-6) */
    var needBody = missingOf({ H2: H2 }, ['H2']);
    var H2r = isNum(H2) ? H2 : P1;
    if (needBody.length) note(notes, 'mouth', needBody, 'Neck and mouth diameter');
    var bottleneck = jc.alpha !== undefined && jc.alpha !== null && isNum(L1) && isNum(L2);
    if (bottleneck) {
      var bn = missingOf({ P2: P2, H1: H1 }, ['P2', 'H1']);
      if (bn.length) {
        note(notes, 'shoulder', bn, 'Shoulder');
        bottleneck = false;
      }
    }
    features.bottleneck = bottleneck;
    var mouth = { r: H2r / 2, z: L3 };
    var keyPts;
    if (bottleneck) {
      var B = { r: P2 / 2, z: L1 };
      var N = { r: H1 / 2, z: L2 };
      var start = { r: P1 / 2, z: zs };
      var r1 = jc.r1Min;
      var r2 = jc.r2;
      if (!isNum(r1)) note(notes, 'r1', ['r1Min'], 'Rounding of the body-side shoulder corner');
      if (!isNum(r2)) note(notes, 'r2', ['r2'], 'Rounding of the neck-side shoulder corner');
      var shoulderLen = Math.hypot(N.r - B.r, N.z - B.z);
      var f1 = isNum(r1) ? fillet(start, B, N, r1, unit(start, B).len * 0.9) : null;
      var f2 = isNum(r2) ? fillet(B, N, mouth, r2, unit(N, mouth).len * 0.9) : null;
      var tsum = (f1 ? f1.tangent : 0) + (f2 ? f2.tangent : 0);
      if (tsum > shoulderLen * 0.9) {
        var scale = (shoulderLen * 0.9) / tsum;
        if (f1) f1 = fillet(start, B, N, f1.radius * scale, f1.tangent * scale);
        if (f2) f2 = fillet(B, N, mouth, f2.radius * scale, f2.tangent * scale);
      }
      features.t1 = f1 ? f1.tangent : 0;
      features.t2 = f2 ? f2.tangent : 0;
      if (f1) {
        outer.line(f1.T1.r, f1.T1.z);
        outer.arc(f1.c, f1.radius, f1.radius, f1.a0, f1.a1);
      } else outer.line(B.r, B.z);
      if (f2) {
        outer.line(f2.T1.r, f2.T1.z);
        outer.arc(f2.c, f2.radius, f2.radius, f2.a0, f2.a1);
      } else outer.line(N.r, N.z);
      outer.line(mouth.r, mouth.z);
      keyPts = [start, B, N, mouth];
      features.keyPoints.bodyEnd = B;
      features.keyPoints.neckStart = N;
    } else {
      outer.line(mouth.r, mouth.z);
      keyPts = [{ r: P1 / 2, z: zs }, mouth];
    }
    features.keyPoints.mouth = mouth;
    features.keyPoints.bodyStart = { r: P1 / 2, z: zs };

    /* walls (rule 8) */
    var heeled = isNum(H2) && isNum(G1) && H2 - G1 <= HEELED_LIMIT;
    features.heeled = heeled;
    var out = {
      ok: true,
      rimType: type,
      outer: outer,
      features: features,
      notes: notes,
      pocket: null,
      inner: [],
      bullet: null,
      section: null
    };

    var wallMissing = missingOf({ H2: H2, G1: G1 }, ['H2', 'G1']);
    var tn = null;
    var tb = null;
    if (!wallMissing.length) {
      var wt = wallThickness({ tn: (H2 - G1) / 2, P1: P1 });
      tn = wt.tn;
      tb = wt.tb;
      features.tn = tn;
      features.tb = tb;
    } else {
      note(notes, 'section', wallMissing, 'Section walls');
    }
    var tnEff = heeled ? tb : tn;

    /* primer pocket (rule 8) */
    var pocket = type === 'rimfire' ? null : pocketFor(ann.primerType);
    if (type !== 'rimfire' && !pocket) note(notes, 'pocket', ['primerType'], 'Primer pocket');
    out.pocket = pocket;

    /* solid head */
    var w = null;
    if (tb !== null) {
      var wParts = [2.5, (0.25 * P1) / 2];
      if (pocket) wParts.push(pocket.depth + 1.5);
      if (features.groove) wParts.push((beltRampEnd !== null ? beltRampEnd : E) + tb);
      w = Math.max.apply(null, wParts);
      features.w = w;
    }

    /* bullet (rule 7) */
    var shape = ann.defaultBulletShape;
    var bulletMissing = missingOf({ G1: G1, L6: L6 }, ['G1', 'L6']);
    var rules = BULLET_RULES[shape];
    if (!rules) bulletMissing = bulletMissing.concat(['defaultBulletShape']);
    var bullet = null;
    if (bulletMissing.length || tb === null || L6 <= L3) {
      if (bulletMissing.length) note(notes, 'bullet', bulletMissing, 'Bullet');
    } else {
      var cat = ann.category === 'pistol' ? 'pistol' : 'rifle';
      var s = rules.seat[cat] * G1;
      var zb = L3 - s;
      var Lb = L6 - zb;
      var zCyl = zb + rules.k[cat] * Lb;
      var exposedR = heeled ? H2 / 2 : G1 / 2;
      var seatR = heeled ? H2 / 2 - tb : G1 / 2;
      var n = L6 - zCyl;
      var m, rhoB = null;
      if (shape === 'pointy') m = Math.max(0.08 * G1, 1.27);
      else if (shape === 'rounded') m = 0.15 * G1;
      else if (shape === 'flat') m = 0.55 * G1;
      else m = 0.6 * G1;
      var ar = exposedR - m / 2;
      var exposed = new Path({ r: exposedR, z: L3 });
      exposed.line(exposedR, zCyl);
      if (shape === 'pointy') {
        rhoB = (ar * ar + n * n) / (2 * ar);
        exposed.arc({ r: exposedR - rhoB, z: zCyl }, rhoB, rhoB, 0, Math.atan2(n, rhoB - ar));
      } else if (shape === 'rounded') {
        exposed.arc({ r: m / 2, z: zCyl }, ar, n, 0, PI / 2);
      } else {
        exposed.line(m / 2, L6);
      }
      exposed.line(0, L6);
      var seated = new Path({ r: 0, z: zb });
      seated.line(seatR, zb).line(seatR, L3).line(exposedR, L3).line(exposedR, zCyl);
      exposed.items.slice(2).forEach(function (it) {
        seated.items.push(it);
      });
      bullet = {
        shape: shape,
        category: cat,
        s: s,
        zb: zb,
        Lb: Lb,
        zCyl: zCyl,
        n: n,
        m: m,
        rho: rhoB,
        exposedR: exposedR,
        seatR: seatR,
        exposed: exposed,
        seated: seated
      };
    }
    out.bullet = bullet;

    /* inner line and hatched section */
    if (tb !== null) {
      var outerAt = function (z) {
        return interp(keyPts, z);
      };
      var inner = [{ r: outerAt(w) - tb, z: w }];
      if (bottleneck) {
        inner.push({ r: P2 / 2 - tb, z: L1 });
        inner.push({ r: H1 / 2 - tnEff, z: L2 });
      } else if (!heeled && bullet) {
        var zBase = Math.min(Math.max(bullet.zb, w), L3);
        if (zBase > w + 1e-9 && zBase < L3 - 1e-9) inner.push({ r: mouth.r - tn, z: zBase });
      }
      inner.push({ r: mouth.r - tnEff, z: L3 });
      if (!bottleneck && !heeled && !bullet) inner[inner.length - 1].r = mouth.r - tb;
      out.inner = inner;

      var section = new Path(pocket ? { r: 0, z: pocket.depth } : { r: 0, z: 0 });
      if (pocket) section.line(pocket.d / 2, pocket.depth).line(pocket.d / 2, 0);
      var skip = true;
      outer.items.forEach(function (it, i) {
        if (i === 0) return;
        if (skip && pocket) {
          // the head face is cut by the pocket: continue from the first point beyond its edge
          if (it.z === 0 && it.r <= pocket.d / 2) return;
          skip = false;
        }
        section.items.push(it);
      });
      for (var k = inner.length - 1; k >= 0; k--) section.line(inner[k].r, inner[k].z);
      section.line(0, w);
      out.section = section;
    }

    /* bounding box (outside view) */
    var all = flatten(outer);
    if (bullet) all = all.concat(flatten(bullet.exposed));
    var zMax = 0;
    var rMax = 0;
    all.forEach(function (q) {
      zMax = Math.max(zMax, q.z);
      rMax = Math.max(rMax, q.r);
    });
    out.bbox = { zMin: 0, zMax: zMax, rMax: rMax };
    return out;
  }

  var api = {
    buildDrawing: buildDrawing,
    rimType: rimType,
    wallThickness: wallThickness,
    pocketFor: pocketFor,
    flatten: flatten,
    interp: interp,
    Path: Path
  };

  if (node) module.exports = api;
  else {
    root.CIP = root.CIP || {};
    root.CIP.geometry = api;
  }
})(typeof self !== 'undefined' ? self : globalThis);
