/* Dimensioning and label layout for the drawing.
   Output coordinates are SVG user units (1 unit = 1 mm): x = origin.x + z, y = origin.y - r (upper half) or origin.y + r (lower half). */
(function (root) {
  'use strict';

  var node = typeof module === 'object' && module.exports;
  var G = node ? require('./geometry.js') : root.CIP.geometry;
  var F = node ? require('./format.js') : root.CIP.format;

  var PRINT_WIDTH = 190; // printable width of A4 portrait with 10 mm margins
  var MIN_VBW = 90;
  var FS_DIV = 34; // font size = viewBox width / 34 (about 10 CSS px when the drawing is 344 px wide on a 360 px screen)
  var ASC = 0.78;

  function isNum(v) {
    return typeof v === 'number' && isFinite(v);
  }

  function textWidth(s, fs) {
    return s.length * 0.6 * fs;
  }

  function rectOverlap(a, b, m) {
    m = m || 0;
    return a.x < b.x + b.w + m && b.x < a.x + a.w + m && a.y < b.y + b.h + m && b.y < a.y + a.h + m;
  }

  /* Liang-Barsky: does the segment touch the rectangle? */
  function segRect(s, r) {
    var t0 = 0;
    var t1 = 1;
    var dx = s.x2 - s.x1;
    var dy = s.y2 - s.y1;
    var p = [-dx, dx, -dy, dy];
    var q = [s.x1 - r.x, r.x + r.w - s.x1, s.y1 - r.y, r.y + r.h - s.y1];
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) {
        if (q[i] < 0) return false;
      } else {
        var t = q[i] / p[i];
        if (p[i] < 0) {
          if (t > t1) return false;
          if (t > t0) t0 = t;
        } else {
          if (t < t0) return false;
          if (t < t1) t1 = t;
        }
      }
    }
    return true;
  }

  function segSeg(a, b) {
    function ccw(x1, y1, x2, y2, x3, y3) {
      return (y3 - y1) * (x2 - x1) - (y2 - y1) * (x3 - x1);
    }
    var d1 = ccw(a.x1, a.y1, a.x2, a.y2, b.x1, b.y1);
    var d2 = ccw(a.x1, a.y1, a.x2, a.y2, b.x2, b.y2);
    var d3 = ccw(b.x1, b.y1, b.x2, b.y2, a.x1, a.y1);
    var d4 = ccw(b.x1, b.y1, b.x2, b.y2, a.x2, a.y2);
    return d1 * d2 < 0 && d3 * d4 < 0;
  }

  function inflate(r, m) {
    return { x: r.x - m, y: r.y - m, w: r.w + 2 * m, h: r.h + 2 * m };
  }

  /* greatest radius of a polyline at z */
  function supR(pts, z) {
    var best = -Infinity;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1];
      var b = pts[i];
      var lo = Math.min(a.z, b.z);
      var hi = Math.max(a.z, b.z);
      if (z < lo - 1e-9 || z > hi + 1e-9) continue;
      if (hi - lo < 1e-12) best = Math.max(best, a.r, b.r);
      else best = Math.max(best, a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z));
    }
    return best === -Infinity ? 0 : best;
  }

  function segments(pts, sign, cls) {
    var out = [];
    for (var i = 1; i < pts.length; i++) {
      out.push({ x1: pts[i - 1].z, y1: sign * pts[i - 1].r, x2: pts[i].z, y2: sign * pts[i].r, cls: cls });
    }
    return out;
  }

  /* ---------- local layout at a given viewBox width ---------- */

  function layoutAt(record, model, vbW) {
    var fs = vbW / FS_DIV;
    var m = 0.9 * fs;
    var arrow = 0.75 * fs;
    var c = record.cartridge || {};
    var head = c.caseHead || {};
    var len = c.lengths || {};
    var pc = c.powderChamber || {};
    var col = c.collar || {};
    var proj = c.projectile || {};
    var f = model.features;
    var bullet = model.bullet;

    /* outlines, local coordinates (x = z, y = -r above the axis, +r below) */
    var upPts = G.flatten(model.outer);
    if (bullet) {
      upPts = upPts.concat([{ r: bullet.exposedR, z: len.L3 }]).concat(G.flatten(bullet.exposed));
    }
    var outline = segments(upPts, -1, 'outline');
    var lowerPts = [upPts];
    if (model.section) lowerPts.push(G.flatten(model.section));
    if (bullet) lowerPts.push(G.flatten(bullet.seated));
    lowerPts.forEach(function (p) {
      outline = outline.concat(segments(p, 1, 'outline'));
    });
    var rMax = model.bbox.rMax;

    var labels = [];
    var lines = [];
    var arrows = [];
    var arcs = [];
    var dots = [];

    function newLabel(id, text, x0, baseline) {
      var w = textWidth(text, fs);
      return {
        id: id,
        text: text,
        w: w,
        x: x0,
        y: baseline,
        bbox: { x: x0, y: baseline - ASC * fs, w: w, h: fs }
      };
    }
    function addArrow(tipx, tipy, ux, uy) {
      arrows.push({ x: tipx, y: tipy, ux: ux, uy: uy, size: arrow });
    }

    /* ----- horizontal dimensions below the section ----- */
    var h = [];
    function addH(id, sym, value, a, b) {
      if (!isNum(value)) return;
      h.push({ id: id, text: sym + ' ' + F.formatNumber(value), a: a, b: b, span: b - a });
    }
    addH('R', 'R', head.R, 0, head.R);
    addH('L1', 'L1', len.L1, 0, len.L1);
    addH('L2', 'L2', len.L2, 0, len.L2);
    addH('L3', 'L3', len.L3, 0, len.L3);
    addH('L6', 'L6', len.L6, 0, len.L6);
    h.sort(function (p, q) {
      return p.span - q.span;
    });
    var tier0 = rMax + 1.5 * fs;
    var tierPitch = 1.85 * fs;
    var gapExt = 0.35 * fs;
    var hDims = h.map(function (d, k) {
      var y = tier0 + k * tierPitch;
      d.y = y;
      return d;
    });
    var lastTierY = hDims.length ? hDims[hDims.length - 1].y : tier0;
    hDims.forEach(function (d) {
      var inside = d.span >= 3.2 * arrow;
      d.inside = inside;
      [d.a, d.b].forEach(function (z) {
        var r0 = supR(upPts, z);
        lines.push({ x1: z, y1: r0 + gapExt, x2: z, y2: d.y + 0.6 * fs, cls: 'ext', owner: d.id });
      });
      if (inside) {
        lines.push({ x1: d.a, y1: d.y, x2: d.b, y2: d.y, cls: 'dim', owner: d.id });
        addArrow(d.a, d.y, -1, 0);
        addArrow(d.b, d.y, 1, 0);
      } else {
        var tail = arrow + 0.9 * fs;
        lines.push({ x1: d.a - tail, y1: d.y, x2: d.a, y2: d.y, cls: 'dim', owner: d.id });
        lines.push({ x1: d.b, y1: d.y, x2: d.b + tail, y2: d.y, cls: 'dim', owner: d.id });
        lines.push({ x1: d.a, y1: d.y, x2: d.b, y2: d.y, cls: 'dim', owner: d.id });
        addArrow(d.a, d.y, 1, 0);
        addArrow(d.b, d.y, -1, 0);
        d.tail = tail;
      }
    });

    function blocked(box, ownId) {
      var inf = inflate(box, 0.15 * fs);
      for (var i = 0; i < labels.length; i++) if (rectOverlap(inf, labels[i].bbox)) return true;
      for (var j = 0; j < outline.length; j++) if (segRect(outline[j], inf)) return true;
      for (var k = 0; k < lines.length; k++) if (lines[k].owner !== ownId && segRect(lines[k], inf)) return true;
      return false;
    }

    hDims.forEach(function (d) {
      var w = textWidth(d.text, fs);
      var base = d.y - 0.5 * fs;
      var cands = [];
      var centred = (d.a + d.b) / 2 - w / 2;
      var right = d.b + (d.inside ? 0.8 * fs : d.tail + 0.6 * fs);
      if (d.span >= w + 0.6 * fs) cands.push(centred, right, d.a - w - 0.8 * fs);
      else cands.push(right, d.a - w - (d.inside ? 0.8 * fs : d.tail + 0.6 * fs));
      var step;
      for (step = 1; step <= 40; step++) cands.push(right + step * 0.5 * fs);
      var placed = null;
      for (var i = 0; i < cands.length && !placed; i++) {
        var lab = newLabel(d.id, d.text, cands[i], base);
        if (!blocked(lab.bbox, d.id)) placed = lab;
      }
      labels.push(placed || newLabel(d.id, d.text, cands[0], base));
    });

    /* ----- diameter dimensions and the angle: rows above the cartridge ----- */
    var v = [];
    function addV(id, sym, value, z, rLine) {
      if (!isNum(value) || !isNum(z)) return;
      v.push({ id: id, text: sym + ' ' + F.formatNumber(value), z: z, r: rLine === undefined ? supR(upPts, z) : rLine });
    }
    var zs = f.bodyStart;
    var P1z = zs + 1.0;
    addV('R1', 'R1', head.R1, !f.halfRound && isNum(head.f) ? head.f + 0.05 : head.R / 2);
    if (f.groove) addV('E1', 'E1', head.E1, head.R + head.eMin - 0.05);
    addV('P1', 'P1', pc.P1, Math.min(P1z, len.L3));
    var keys = f.keyPoints;
    if (f.bottleneck) {
      var t1 = Math.max(0, f.t1 || 0);
      addV('P2', 'P2', pc.P2, Math.max(len.L1 - t1 - 1.0, zs + 1.5));
      addV('H1', 'H1', col.H1, len.L2 + 0.2 * (len.L3 - len.L2));
    }
    addV('H2', 'H2', col.H2, f.bottleneck ? len.L3 - 0.3 * (len.L3 - len.L2) : len.L3 - Math.max(1.0, 0.05 * (len.L3 - zs)));
    if (bullet) addV('G1', 'G1', proj.G1, (len.L3 + bullet.zCyl) / 2);
    var alpha = null;
    if (f.bottleneck && c.junctionCone && c.junctionCone.alpha !== undefined) {
      var zm = (len.L1 + len.L2) / 2;
      alpha = { id: 'alpha', text: 'α ' + F.formatAngle(c.junctionCone.alpha), z: zm, r: supR(upPts, zm), isAngle: true };
      v.push(alpha);
    }
    v.sort(function (p, q) {
      return p.z - q.z;
    });

    // diameter lines across the full section, arrowheads on the outline
    v.forEach(function (d) {
      if (d.isAngle) return;
      lines.push({ x1: d.z, y1: -d.r, x2: d.z, y2: d.r, cls: 'dim', owner: d.id });
      addArrow(d.z, -d.r, 0, -1);
      addArrow(d.z, d.r, 0, 1);
    });

    // the shoulder angle: an arc about the cone apex through both neck-side corners, arrowheads at its ends
    if (alpha) {
      var B = keys.bodyEnd;
      var N = keys.neckStart;
      var dr = N.r - B.r;
      if (dr < -1e-9) {
        var zA = N.z + (N.r * (N.z - B.z)) / -dr;
        var rho = Math.hypot(zA - N.z, N.r);
        var vx = N.z - zA;
        var n = Math.hypot(vx, N.r);
        // the arc runs from the upper to the lower neck-side corner through the axis; arrowheads point along its tangent
        arcs.push({ cx: zA, rho: rho, x1: N.z, y1: -N.r, x2: N.z, y2: N.r, owner: 'alpha' });
        addArrow(N.z, -N.r, N.r / n, vx / n);
        addArrow(N.z, N.r, N.r / n, -vx / n);
        alpha.apex = { z: zA, r: 0 };
      }
    }

    // flag labels above the cartridge: a vertical stem rises from the outline at z and the label sits to its right.
    // Placed right to left in the lowest free row, which always leaves a stem a free path.
    var rowStart = rMax + 1.2 * fs;
    var rowPitch = 1.3 * fs;
    var stems = [];
    v.slice()
      .sort(function (p, q) {
        return q.z - p.z;
      })
      .forEach(function (d) {
        var w = textWidth(d.text, fs);
        var chosen = null;
        for (var k = 0; k < 40 && !chosen; k++) {
          var yb = -(rowStart + k * rowPitch);
          var box = { x: d.z + 0.35 * fs, y: yb - fs, w: w, h: fs };
          var stem = { x1: d.z, y1: -d.r, x2: d.z, y2: yb - fs, cls: d.isAngle ? 'leader' : 'ext', owner: d.id };
          var inf = inflate(box, 0.25 * fs);
          var ok = true;
          for (var i = 0; i < labels.length && ok; i++) if (rectOverlap(inf, labels[i].bbox)) ok = false;
          for (var j = 0; j < stems.length && ok; j++) {
            if (segRect(stems[j], inf)) ok = false;
            if (segRect(stem, inflate(labels[labels.length - stems.length + j].bbox, 0.25 * fs))) ok = false;
          }
          for (var q = 0; q < lines.length && ok; q++) {
            if (lines[q].owner !== d.id && lines[q].cls !== 'dim' && segRect(lines[q], inf)) ok = false;
          }
          if (ok) chosen = { box: box, stem: stem, yb: yb };
        }
        if (!chosen) {
          var yb2 = -(rowStart + 40 * rowPitch);
          chosen = { box: { x: d.z + 0.35 * fs, y: yb2 - fs, w: w, h: fs }, stem: { x1: d.z, y1: -d.r, x2: d.z, y2: yb2 - fs, cls: 'ext', owner: d.id }, yb: yb2 };
        }
        stems.push(chosen.stem);
        lines.push(chosen.stem);
        labels.push(newLabel(d.id, d.text, chosen.box.x, chosen.yb - 0.22 * fs));
        if (d.isAngle) dots.push({ x: d.z, y: -d.r, r: 0.18 * fs });
      });

    /* ----- centre line ----- */
    var axis = { x1: -1.2 * fs, x2: len.L6 + 1.2 * fs, y: 0 };

    /* ----- extents of everything drawn ----- */
    var minX = axis.x1;
    var maxX = axis.x2;
    var minY = -rMax;
    var maxY = rMax;
    function ext(x, y) {
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
    outline.forEach(function (s) {
      ext(s.x1, s.y1);
      ext(s.x2, s.y2);
    });
    lines.forEach(function (s) {
      ext(s.x1, s.y1);
      ext(s.x2, s.y2);
    });
    labels.forEach(function (l) {
      ext(l.bbox.x, l.bbox.y);
      ext(l.bbox.x + l.bbox.w, l.bbox.y + l.bbox.h);
    });
    arcs.forEach(function (a) {
      ext(a.cx - a.rho, 0);
    });
    arrows.forEach(function (a) {
      ext(a.x - a.ux * arrow, a.y - a.uy * arrow);
    });

    return {
      fs: fs,
      m: m,
      arrow: arrow,
      labels: labels,
      lines: lines,
      arrows: arrows,
      arcs: arcs,
      dots: dots,
      outline: outline,
      axis: axis,
      bounds: { minX: minX, maxX: maxX, minY: minY, maxY: maxY },
      contentW: maxX - minX
    };
  }

  /* ---------- title block and final placement ---------- */

  function layoutDrawing(record, model) {
    var vbW = 100;
    var res;
    var scale;
    for (var i = 0; i < 40; i++) {
      res = layoutAt(record, model, vbW);
      var need = Math.max(MIN_VBW, res.contentW + 2 * res.m);
      scale = Math.floor((PRINT_WIDTH / need) * 10 + 1e-9) / 10;
      var next = PRINT_WIDTH / scale;
      if (Math.abs(next - vbW) < 1e-9) break;
      vbW = next;
    }
    res = layoutAt(record, model, vbW);
    while (res.contentW + 2 * res.m > vbW + 1e-9) {
      scale = Math.floor(((PRINT_WIDTH / (vbW * 1.01)) * 10) + 1e-9) / 10;
      vbW = PRINT_WIDTH / scale;
      res = layoutAt(record, model, vbW);
    }
    scale = PRINT_WIDTH / vbW;
    scale = Math.round(scale * 10) / 10;

    var fs = res.fs;
    var m = res.m;
    var b = res.bounds;
    var dx = (vbW - res.contentW) / 2 - b.minX;
    var dy = m - b.minY;

    function tx(x) {
      return x + dx;
    }
    function ty(y) {
      return y + dy;
    }

    /* title block below the drawing: three rows of two cells, all text at the label size */
    var rowH = 1.55 * fs;
    var pad = 0.5 * fs;
    var tbH = 3 * rowH;
    var tbY = ty(b.maxY) + 1.2 * fs;
    var tbX = m;
    var tbW = vbW - 2 * m;
    var c1 = 0.45 * tbW;
    var name = record.name;
    var nameSize = Math.min(1.15 * fs, (c1 - 2 * pad) / (0.6 * name.length));
    var y1 = tbY + 1.12 * fs;
    var y2 = y1 + rowH;
    var y3 = y2 + rowH;
    var texts = [
      { x: tbX + pad, y: y1, text: name, size: nameSize, weight: 'bold' },
      { x: tbX + pad, y: y3, text: 'Dimensions in mm', size: fs },
      { x: tbX + c1 + pad, y: y1, text: 'C.I.P. table ' + record.tab, size: fs },
      { x: tbX + c1 + pad, y: y2, text: 'Revised ' + record.revised, size: fs },
      { x: tbX + c1 + pad, y: y3, text: 'Scale ' + scale.toFixed(1) + ' : 1', size: fs }
    ];
    var title = {
      rect: { x: tbX, y: tbY, w: tbW, h: tbH },
      dividers: [
        { x1: tbX + c1, y1: tbY, x2: tbX + c1, y2: tbY + tbH },
        { x1: tbX, y1: tbY + tbH / 3, x2: tbX + tbW, y2: tbY + tbH / 3 },
        { x1: tbX, y1: tbY + (2 * tbH) / 3, x2: tbX + tbW, y2: tbY + (2 * tbH) / 3 }
      ],
      texts: texts,
      scaleBar: { x1: tbX + pad, x2: tbX + pad + 10, y: y2 - 0.3 * fs, len: 10, label: '10 mm', labelX: tbX + pad + 10 + 0.6 * fs, labelSize: fs }
    };
    var vbH = tbY + tbH + m;

    function mapSeg(s) {
      var o = { x1: tx(s.x1), y1: ty(s.y1), x2: tx(s.x2), y2: ty(s.y2) };
      for (var k in s) if (!(k in o)) o[k] = s[k];
      return o;
    }
    function mapLabel(l) {
      return {
        id: l.id,
        text: l.text,
        x: tx(l.x),
        y: ty(l.y),
        w: l.w,
        bbox: { x: tx(l.bbox.x), y: ty(l.bbox.y), w: l.bbox.w, h: l.bbox.h }
      };
    }

    return {
      vbW: vbW,
      vbH: vbH,
      fs: fs,
      arrow: res.arrow,
      scale: scale,
      origin: { x: dx, y: dy },
      labels: res.labels.map(mapLabel),
      lines: res.lines.map(mapSeg),
      arrows: res.arrows.map(function (a) {
        return { x: tx(a.x), y: ty(a.y), ux: a.ux, uy: a.uy, size: a.size };
      }),
      arcs: res.arcs.map(function (a) {
        return { cx: tx(a.cx), cy: ty(0), rho: a.rho, x1: tx(a.x1), y1: ty(a.y1), x2: tx(a.x2), y2: ty(a.y2), owner: a.owner };
      }),
      dots: res.dots.map(function (d) {
        return { x: tx(d.x), y: ty(d.y), r: d.r };
      }),
      outline: res.outline.map(mapSeg),
      axis: { x1: tx(res.axis.x1), x2: tx(res.axis.x2), y: ty(0) },
      title: title
    };
  }

  var api = {
    layoutDrawing: layoutDrawing,
    textWidth: textWidth,
    PRINT_WIDTH: PRINT_WIDTH
  };

  if (node) module.exports = api;
  else {
    root.CIP = root.CIP || {};
    root.CIP.layout = api;
  }
})(typeof self !== 'undefined' ? self : globalThis);
