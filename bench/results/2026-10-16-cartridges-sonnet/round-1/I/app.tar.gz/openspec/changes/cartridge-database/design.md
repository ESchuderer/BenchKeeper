# Design

## Context

Greenfield, empty repository (OpenSpec scaffolding only), Node 22 and npm available in the container, no browser installed yet (`npm` registry reachable). See `proposal.md` for motivation and `specs/` for requirements. The brief fixes: plain HTML/CSS/JS, no build step, no runtime deps, no network requests, must work from `file://` in Chromium. The 25 records are the only data.

Constraints that shape everything:
- Chromium blocks `fetch()` of local files and ES-module `<script type="module">` imports under `file://` (CORS on the `file` origin). Both are therefore out.
- Geometry rules in the brief use (radius, z) points; the drawing must be a pure function of the record so it can be tested without a browser.

## Goals / Non-Goals

**Goals:**
- Pure, DOM-free logic modules (format, filter, geometry, layout, SVG string) testable with `node --test`.
- A thin DOM layer (router, list view, detail view) tested in a real Chromium, including `file://`, print-to-PDF page count, dark scheme and a 360 px viewport.
- Every number on screen traceable to a record field or to a rule in the brief.

**Non-Goals:**
- No data editing, fetching, unit conversion, translation, bullet/load data.
- No flash hole, no hollow rimfire rim, no thread/sizing detail: not in the rules, and never invented.
- No service worker/PWA, no bundler, no TypeScript.

## Decisions

### D1. Files and loading
Classic `<script>` files in `js/`, loaded in order from `index.html`: `data.js`, `format.js`, `filter.js`, `geometry.js`, `layout.js`, `drawing.js`, `app.js`. Each logic file is a UMD-style IIFE that sets a property on a single global `CIP` in the browser and `module.exports` in Node, so tests `require()` the very same files.
Alternatives: ES modules (fail on `file://`), a bundler (violates "no build step").

### D2. Data embedded as a script
`js/data.js` assigns the 25 records verbatim to `CIP.data`. A fixture `tests/fixtures/cartridges.jsonl` holds the brief's records, and a test asserts deep equality and count 25 and order. A dev script may generate `data.js` from the JSONL; the generated file is committed so the app needs no tooling.
Alternative: `fetch('cartridges.json')` (fails on `file://`).

### D3. Routing: hash addresses
`#/` is the list, `#/cartridge/<key>` the detail view (`key` from the record, URL-safe already). A `hashchange` listener renders the view; reload and bookmarks work on `file://` and on any server without rewrite rules. Search/Family state lives in module state and in the controls, so "back" restores the same filtered list. On navigation: set `document.title`, move focus to the view's `h1` (`tabindex="-1"`). Unknown key → "Cartridge not found" with an "All cartridges" link.

### D4. Rendering: DOM for HTML, string for SVG
HTML views are built with `createElement` + `textContent` (no `innerHTML` with data). The drawing is produced as an SVG string by a pure function and inserted into a container; all text that enters it is passed through an escape function. A string keeps it testable in Node and printable unchanged.

### D5. Formatting (see `cartridge-detail`)
- Number: `String(value)` of the parsed JSON number (no locale, no grouping). Names are never reformatted.
- Angle: number → `<n>°`; object → `<d>°<m>'<s>"` (all three parts always shown, as in the brief's example). Radians for geometry: `d + m/60 + s/3600`.
- Tolerance: Value cell is `"<value> <tol>"` when `<X>Tol` exists; `Tol` keys never become rows.
- Units table by field name. Assumption recorded: `u` (twist, 203–508) is a length in mm, since the brief says lengths are mm and lists no other unit for it; `Fe`, `deltaL`, `S`, `h`, `s`, `b`, `F`, `Z`, `r`, `G`, `G1`, `G2`, `L4`, `L5` are lengths in mm. Fields with no entry in the table would show an empty unit rather than a guess.
- Group titles come from the JSON group names (e.g. `caseHead` → "Case head"); empty groups are skipped.
- `i` and angles: unit `°`. Water capacity: `grH2O` shown as "<n> gr H2O" with `url` as a link (`rel="noopener noreferrer"`); "not published" when absent.

### D6. Filtering
Normalise to lower case and collapsed whitespace; a record matches when the query is a substring of its name or any alternative name, and the family equals the select value or the select is All. The count text is an `aria-live="polite"` region.

### D7. Geometry model (pure, `geometry.js`)
`buildDrawing(record)` returns `{ rimType, outer, inner, bullet, head, pocket, dims, notes, bbox }` in mm, points as `{r, z}`. Rules from the brief are implemented literally; interpretations recorded here:
- **Rim type** exactly as rule 1 (ratio thresholds 1.05 / 0.98; belted/rimfire by family).
- **Chamfer/rim edge:** chamfer only when `beta` and `f` published and `beta < 90°`. Rimfire half-round: radius `ρ = min(R/2, (R1−P1)/2)`, a semicircle centred at `(R1/2 − ρ, ρ)` (outermost point at `R1/2`), continuing straight to `(R1/2 − ρ, R)` when `2ρ < R`, then in to `P1/2`. Rimfire cases have no groove published, so the profile continues at `(P1/2, R)`.
- **Body start** `zs`: `E` where a groove exists (ramp end), else `R`. Belted: the δ ramp climbs `dz = (R3/2 − E1/2)/tan δ` (δ measured from the axis) from `z = R + e min`, follows the belt to `z = E`, steps in to `P1/2`; its end `R + e min + dz` feeds `w`.
- **Straight** when alpha, L1 or L2 is missing (spec of the brief); body from `(P1/2, zs)` to `(H2/2, L3)` straight line. Missing `P1`, `L3`, `H2`, `R1`, or `R` → no drawing possible for that part; the note lists it (does not occur in the 25 records).
- **Shoulder** drawn through the published points; α is only labelled (the published value). Fillets: tangent circle of radius r1 min at the body/shoulder corner and r2 at the shoulder/neck corner, tangent distance `r·tan(deflection/2)`, clamped to 90 % of the shorter adjacent segment; omitted (and named in notes) when the radius is unpublished. S is not used in geometry.
- **Walls** per rule 8; inner points are the outer points offset radially (not along the normal) by `tb` at the body, `tn` at the neck, linear in between across the shoulder. Interpretation for non-heeled **straight** cases (no neck): the wall is `tb` at `z = w` and blends linearly to `tn` at the bullet base `zb`, then stays `tn` to the mouth, so the seated bullet is never overlapped by the wall. Heeled cases keep `tb` throughout (inner diameter `H2 − 2·tb`). `tn` is clamped at ≥ 0.
- **Bullet** per rule 7. The seated part is clipped to the case's inside; in the heeled case the exposed part has diameter `H2`, the seated heel `H2 − 2·tb`. Pointy ogive arc centre at `(G1/2 − ρ, zNoseStart)`; the arc is sampled/stroked as an SVG arc `A` with radius ρ (exact, not sampled). Rounded nose: SVG elliptical arc quarter with rx = `G1/2 − m/2`, ry = `n`.
- **Section** hatching: one closed path (outer, mouth face, inner, solid head with pocket notch) filled with an SVG `<pattern>` of 45° hairlines; the bullet is outlined with a faint fill, not hatched.
- **Pocket:** notch from the head face: width and depth from `primerType`; skipped for `rimfire` and when the primer type is unknown.
- **Notes** (missing values) collected per feature: groove (E, E1, e min), belt (R3, delta), chamfer (beta, f), r1 min, r2, bullet (G1, L6, default shape), primer pocket. Straight cases and absent alpha are not "missing" notes: they are the documented rule.

### D8. Dimensioning and label placement (`layout.js`)
Horizontal dimensions (R, L1, L2, L3, L6) go in stacked tiers below the lower half, shortest nearest, with extension lines; diameter dimensions (R1, E1, P1, P2, H1, H2, G1) are vertical dimension lines across the full diameter at a chosen z with arrowheads on the outline. Each has a vertical stem rising from the upper outline to a "flag" label placed to the right of the stem. Flags are placed right to left, each in the lowest row where its box and stem collide with nothing placed, which always leaves a path (an earlier scheme with slanted leaders failed on clusters near the head). α is an arc about the cone apex through both neck-side corners, with arrowheads, and a flag label whose stem ends on the shoulder. Each label has a known size: a monospace font with `textLength` set to `chars × 0.6 × fontSize`, so the width in the browser equals the width in tests. Horizontal labels try the centre of their span, then to the right, shifting until clear of other labels, lines and the outline. Tests check labels against labels, outline, title block and viewBox edge for all 25 records.
Font size `fs = vbWidth / 34` (about 10 CSS px when the drawing is 344 px wide on a 360 px screen); vbWidth depends on the layout and is solved by fixed-point iteration; minimum viewBox width 90 mm so the title block fits.

### D9. Scale statement
Screen size varies, so the title block states the scale for the A4 print: `scale = printable width (190 mm) / vbWidth`, shown as "Scale 1.8 : 1". The print CSS sets the SVG width to 190 mm to make it true; a 10 mm scale bar inside the SVG makes the scale checkable on screen. The SVG has `viewBox` in mm and CSS `width: 100%; height: auto`, so 1 user unit = 1 mm at the viewBox level.

### D10. Print
`@media print` with `@page { size: A4 portrait; margin: 10mm }`: forces light colours (custom properties reset), hides nav/search/buttons, facts in three columns, tables (Cartridge values then Chamber values) flowing together through five columns at 6.5 pt with `break-inside: avoid` per table, a header with the name and a footer ("Source: C.I.P. TDCC, revised <date>") shown in print only (in normal flow at the end, since `position: fixed` footers repeat per page and one page is the goal). A compact two-row title block and tight tier/row pitch keep the drawing near 160 mm tall. Page count verified by printing to PDF in Chromium for all 25 records.
Alternative: JS-driven layout for print; rejected as unnecessary.

### D11. Look and feel
System font stack with `font-variant-numeric: tabular-nums` and a monospace stack in the SVG; CSS custom properties for light and dark via `prefers-color-scheme`, `color-scheme: light dark`; hairline borders, 13–14 px base, compact table rows. Drawing colours come from the same custom properties (outline, hatch, dimension lines, labels).

### D12. Test tooling
- Unit: `node --test` (built in), no dependencies.
- Browser: `@playwright/test` or `playwright` as dev dependency with a downloaded Chromium (`file://` run, server run via a tiny Node `http` static script, console/network assertions, dark scheme, 360 px viewport, `page.pdf()` page count). Test-first: unit tests for each logic module are written and seen failing before the module.

## Risks / Trade-offs

- [Chromium cannot be downloaded in the container] → try early (task 1.4); if it fails, DOM tests fall back to `jsdom` (dev) and the layout/print checks use the pure layout model plus an explicit note to the user that real-browser checks could not be run.
- [Label crowding on small cartridges at the legible font size] → tiers may grow the viewBox; the viewBox minimum width and the fixed-pitch label model keep collisions testable; inspect screenshots of all 25 drawings.
- [Interpretations of ambiguous rules (straight-case wall, half-round, belt ramp, diameter dimension placement)] → recorded here and in the README; each is covered by a test so a change is deliberate.
- [`u` unit assumed mm] → recorded in D5; trivially changeable in one table.
- [One A4 page with ~60 table rows and a large drawing] → three-column table flow at 7 pt; verified per record by PDF page count.
- [Long names/tables on a phone] → single-column tables and wrapped list entries; checked at 360 px.
