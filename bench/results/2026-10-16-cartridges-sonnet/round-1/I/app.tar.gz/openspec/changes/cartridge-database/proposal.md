# Proposal

## Why

Reloaders, gunsmiths and engineers need quick, precise access to the published C.I.P. dimensions and pressures of common cartridges. The OpenBallistics database has this data, but there is no small, offline-capable reference that shows a cartridge's values together with a true-scale drawing computed from those same values, and prints cleanly on one A4 page. The 25 supplied records are the only data.

## What Changes

- New static web app (plain HTML/CSS/JS, no framework, no build step, no runtime dependencies, no network requests) with `index.html` in the project root; works from `file://` in Chromium and from any static file server.
- Start page "Cartridges": list of all 25 cartridges (name link, family, case length L3), live "Search" over name and alternative names, "Family" select, and a "<n> cartridges" count.
- Detail view per cartridge with its own bookmarkable address that survives reload: header facts, published water capacity with source link, drawing, grouped value tables (Symbol / Value / Unit) for cartridge and chamber, tolerances shown next to their value, angles shown as degrees or degrees/minutes/seconds.
- Computed inline SVG drawing: true-scale (1 unit = 1 mm) outline built from the record by the specified geometry rules (rim type, head, groove or belt, body, shoulder, neck, bullet, section with hatched walls, primer pocket), dimension lines with non-overlapping labels, title block; missing inputs omit the feature and are reported, never invented.
- Print: A4 portrait, black on white, header, full-width drawing, tables, source footer; no navigation or controls. Light/dark on screen following the system setting; usable on a phone.
- Dev-only tooling: Node 22 built-in test runner for logic; a headless-browser check for `file://` and print behaviour (dev dependency only).

## Capabilities

### New Capabilities
- `cartridge-browser`: start page, list, search, family filter, count, and addresses (routing) of list and detail views.
- `cartridge-detail`: detail view content, value formatting (as published, tolerances, angles, symbols, units), grouped tables, print button and back link.
- `cartridge-drawing`: the computed true-scale SVG drawing — geometry rules, dimensioning, labels, title block, missing-value reporting, responsiveness.
- `cartridge-print`: A4 print layout of the detail view.
- `app-delivery`: offline/`file://` operation, no network requests, no runtime dependencies, light/dark theming, phone usability, unmodified data.

### Modified Capabilities
<!-- none: greenfield project, openspec/specs is empty -->

## Impact

- New files in the project root: `index.html`, CSS, JavaScript (data, formatting, geometry, rendering, app), `package.json` for dev tools, `tests/`.
- No external APIs or runtime dependencies. Data is the 25 records verbatim, embedded as a script so it loads under `file://`.
- Out of scope: any data beyond the 25 records, fetching or editing data, unit conversion, bullet/load data, other languages.
