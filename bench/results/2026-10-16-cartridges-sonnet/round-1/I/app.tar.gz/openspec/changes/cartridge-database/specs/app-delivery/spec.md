# Spec Delta

## Purpose

Defines how the app is delivered and looks: a dependency-free static page that works offline from disk, uses the supplied data unchanged, and is a calm, dense technical reference on any screen.

## ADDED Requirements

### Requirement: Runs from disk and from any static server
The app SHALL be `index.html` in the project root with its CSS and JavaScript files, and SHALL work fully when `index.html` is opened directly from disk in Chromium (`file://`) and when the folder is served by any static file server, using only plain HTML, CSS and JavaScript without a framework, a build step or server code.

#### Scenario: file://
- **WHEN** `index.html` is opened from disk in Chromium
- **THEN** the list, search, filter, detail views, drawing and reload of a detail address all work and no console error occurs

#### Scenario: Static server
- **WHEN** the folder is served by a static file server
- **THEN** the same behaviour is observed

### Requirement: No network and no runtime dependencies
The running app SHALL make no network requests (no CDNs, web fonts, analytics or data fetches) and SHALL have no runtime dependencies. Development tools MAY be npm dev dependencies and SHALL NOT be needed to run the app.

#### Scenario: No requests
- **WHEN** the app is used through list, search, filter, a detail view and print
- **THEN** the only requests are for the app's own files (none when opened from disk)

### Requirement: Data is used as given
The app SHALL use the 25 supplied records and no other data. It SHALL NOT add, change or fetch data.

#### Scenario: Data integrity
- **WHEN** the embedded data is compared with the supplied 25 records
- **THEN** they are deeply equal, in the same order, with exactly 25 records

### Requirement: Light and dark on screen
On screen the app SHALL follow the system's light or dark setting. Text and lines SHALL meet WCAG AA contrast in both. The drawing SHALL be legible in both.

#### Scenario: Dark
- **WHEN** the system prefers a dark colour scheme
- **THEN** the page and the drawing use a dark theme with sufficient contrast

### Requirement: Technical look and phone usability
The interface SHALL be English, dense and calm with precise typography and tabular numbers for values, and SHALL be usable on a 360 px wide phone without horizontal page scrolling, with keyboard-operable controls and visible focus.

#### Scenario: Phone
- **WHEN** the viewport is 360 px wide
- **THEN** the list, the filters, the tables and the drawing fit the width and all controls are operable

#### Scenario: Keyboard
- **WHEN** the user navigates with the keyboard only
- **THEN** search, family select, name links, Print and "All cartridges" are reachable and show a focus indicator
