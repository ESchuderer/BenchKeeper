# Spec Delta

## Purpose

Lets users find a cartridge among the 25 records by browsing, searching or filtering by family, and gives every view its own address that can be bookmarked and survives a reload.

## ADDED Requirements

### Requirement: Start page lists all cartridges
The start page SHALL show the heading "Cartridges" and one entry per cartridge with its name, its family and its case length L3. The name SHALL be a link whose text is exactly the record's `name` and which opens that cartridge's detail view.

#### Scenario: Initial list
- **WHEN** the user opens the app without an address fragment
- **THEN** the heading "Cartridges" is shown, 25 entries are listed, and the text "25 cartridges" is shown
- **AND** the entry for "6,5 Creedmoor" has a link with exactly that text, family "rimless" and L3 "48.77"

#### Scenario: Open a detail view
- **WHEN** the user activates the link "308 Win."
- **THEN** the detail view for "308 Win." is shown

### Requirement: Search filters as the user types
A field labelled "Search" SHALL filter the list by the cartridge name and its alternative names, case-insensitively, updating on every input event.

#### Scenario: Alternative name
- **WHEN** the user types `7,62 x 51` into "Search"
- **THEN** the list contains "308 Win." and no cartridge that matches neither name nor alternative name

#### Scenario: Name
- **WHEN** the user types `creed` into "Search"
- **THEN** only "6,5 Creedmoor" is listed and the text reads "1 cartridges"

#### Scenario: No match
- **WHEN** the user types a text that matches no name
- **THEN** no entries are listed, the count reads "0 cartridges" and a message says that no cartridge matches

### Requirement: Family filter
A select labelled "Family" SHALL offer the options All, rimless, rimmed, belted, pistol and rimfire, and SHALL restrict the list to that family. Search and Family SHALL combine.

#### Scenario: Filter by family
- **WHEN** the user selects "belted"
- **THEN** exactly "300 Win. Mag." and "7 mm Rem. Mag." are listed and the text reads "2 cartridges"

#### Scenario: Combined with search
- **WHEN** the user selects "pistol" and types `44`
- **THEN** only pistol cartridges whose name or alternative names contain `44` are listed

### Requirement: Count of listed cartridges
The text "<n> cartridges" SHALL state the number of currently listed cartridges and SHALL be announced to assistive technology when it changes.

#### Scenario: Count follows filters
- **WHEN** the filters change the list to 3 entries
- **THEN** the text reads "3 cartridges"

### Requirement: Addresses survive reload
Each detail view SHALL have its own address, derived from the record's `key`, that opens the same detail view after a reload or when bookmarked and opened later. The start page SHALL have its own address. The address SHALL work from `file://`.

#### Scenario: Reload on a detail view
- **WHEN** the user opens "9 mm Luger" and reloads the page
- **THEN** the detail view for "9 mm Luger" is shown

#### Scenario: Browser history
- **WHEN** the user opens a detail view and then uses the browser's back button
- **THEN** the start page is shown with the list

#### Scenario: Unknown address
- **WHEN** the address names a key that does not exist
- **THEN** a "Cartridge not found" message with a link "All cartridges" is shown, and no error occurs
