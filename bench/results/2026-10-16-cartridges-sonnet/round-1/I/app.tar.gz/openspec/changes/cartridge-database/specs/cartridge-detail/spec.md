# Spec Delta

## Purpose

Presents everything published about one cartridge — identification facts, all cartridge and chamber values with symbols and units — in dense, precise tables for reloaders, gunsmiths and engineers.

## ADDED Requirements

### Requirement: Detail header and identification facts
The detail view SHALL have a level-one heading equal to the cartridge's `name` as published, followed by: alternative names (when present), family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method, and the published water capacity with a link to its source.

#### Scenario: Facts of 308 Win.
- **WHEN** the detail view for "308 Win." is shown
- **THEN** the heading reads "308 Win."
- **AND** alternative names "308 Winchester" and "7,62 x 51" are shown, family "rimless", category "rifle", primer type "lr", table "I", country "US", published "1984-06-14", revised "2008-09-23", pressure method "Transducer"
- **AND** the water capacity shows 56 gr H2O with a link to `http://kwk.us/cases.html`

#### Scenario: No published capacity
- **WHEN** the detail view for "22 Long Rifle" is shown
- **THEN** the water capacity reads "not published" and no source link is shown, and no number is invented

#### Scenario: No alternative names
- **WHEN** the detail view for "243 Win." is shown
- **THEN** no alternative-names entry is shown

### Requirement: Value tables grouped by section
The detail view SHALL show all cartridge values and all chamber values published in the record, in tables grouped by section (the record's groups, for example case head, collar, junction cone, lengths, powder chamber, pressures, projectile; and for the chamber barrel, breech, collar, grooves, junction cone, lengths, powder chamber, rifling). Each table SHALL have the columns "Symbol", "Value" and "Unit". Empty groups SHALL NOT be shown.

#### Scenario: Complete coverage
- **WHEN** any detail view is shown
- **THEN** every published numeric field of `cartridge` and `chamber` appears in exactly one row, except `...Tol` fields (see below)

#### Scenario: Empty group omitted
- **WHEN** the detail view for "9 mm Luger" is shown (its `junctionCone` groups are empty)
- **THEN** no junction cone table is shown

### Requirement: Values are shown as published
Numbers SHALL be shown with a decimal point, no thousands separator and no rounding and no added digits (`51.18`, `4150`). Names, including `6,5 Creedmoor`, SHALL be shown as published.

#### Scenario: Pressure and length
- **WHEN** the detail view for "308 Win." is shown
- **THEN** L3 shows "51.18" with unit "mm" and Pmax shows "4150" with unit "bar"

### Requirement: Tolerances are shown next to their value
A field `<X>Tol` SHALL be shown in the Value cell of `X`, after the value and separated by a space, as published (`39.62 -0.2`), and SHALL NOT have a row of its own.

#### Scenario: L1 with tolerance
- **WHEN** the detail view for "308 Win." is shown
- **THEN** the L1 row shows "39.62 -0.2" and no row labelled "L1Tol" exists

### Requirement: Angles
An angle SHALL be shown as degrees with the degree sign when the record has a number (`40°`), and as degrees, minutes and seconds when the record has an object (`39°59'49"`). Angle fields (alpha, alpha1, beta, delta, i) SHALL have the unit "°".

#### Scenario: Object angle
- **WHEN** the detail view for "6,5 x 55 SE" is shown
- **THEN** the cartridge junction cone α reads `50°35'2"`

#### Scenario: Numeric angle
- **WHEN** the detail view for "308 Win." is shown
- **THEN** the cartridge α reads `40°`

### Requirement: Symbols and units
The Symbol column SHALL show the field name, except `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G". Units SHALL be mm for lengths and diameters, bar for Pmax, PK and PE, J for EE, g for M, mm² for Q, none for N.

#### Scenario: Renamed symbols
- **WHEN** the detail view for "223 Rem." is shown
- **THEN** the rows use the symbols "e min", "r1 min", "α", "β", "δ", "delta L" and "L3 + G"
- **AND** the chamber rows use "r1 max" and "α1"

#### Scenario: Units
- **WHEN** the detail view for "223 Rem." is shown
- **THEN** EE shows unit "J", M shows "g", Q shows "mm²" and N has an empty unit cell

### Requirement: Navigation and print controls
The detail view SHALL have a button "Print" that opens the browser's print dialog, and a link "All cartridges" that returns to the start page.

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** the browser's print dialog opens

#### Scenario: Back link
- **WHEN** the user activates "All cartridges"
- **THEN** the start page is shown
