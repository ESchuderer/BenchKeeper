# Spec Delta

## Purpose

Draws each cartridge as a true-scale technical drawing computed only from the record's published values, with dimensioning, so engineers can read shape and size at a glance without any value being invented.

## ADDED Requirements

### Requirement: Drawing is an inline true-scale SVG
The detail view SHALL contain an inline SVG whose user units are millimetres (1 SVG user unit = 1 mm), with the cartridge axis horizontal and the head on the left, and with the accessible name "<name> drawing". The upper half SHALL show the outside view and the lower half a section. A dash-dot centre line SHALL mark the axis.

#### Scenario: Accessible name and units
- **WHEN** the detail view for "308 Win." is shown
- **THEN** an SVG element with accessible name "308 Win. drawing" exists
- **AND** the horizontal distance in user units between the head face and the mouth equals L3 (51.18)

#### Scenario: Orientation
- **WHEN** any drawing is shown
- **THEN** the head face lies to the left of the mouth and the bullet tip lies to the right of the mouth

### Requirement: Rim type
The rim type SHALL be belted for family `belted`, rimfire for family `rimfire`; otherwise rimmed when R1/P1 >= 1.05, rebated when R1/P1 < 0.98, and rimless in every other case.

#### Scenario: Classification
- **WHEN** the ratio R1/P1 is 1.004 ("308 Win."), 1.12 ("7 x 65 R"), 0.97 (synthetic) and 0.9876 ("9,3 x 62")
- **THEN** the rim types are rimless, rimmed, rebated and rimless
- **AND** "300 Win. Mag." is belted and "17 HMR" is rimfire regardless of ratio

### Requirement: Head, rim edge and extractor groove
The outer half-profile SHALL start on the axis at the head face (z = 0). Where beta and f are published and beta < 90° it SHALL have a chamfer from (R1/2 − min(f·tan β, R1/4), 0) to (R1/2, f) (points are radius, z), then rise to (R1/2, R). A rimfire rim edge SHALL be a half-round of radius min(R/2, (R1 − P1)/2) whose outermost point lies at R1/2. Otherwise the corner is square.

#### Scenario: Chamfer
- **WHEN** the drawing for "308 Win." is computed (beta 35°, f 0.38, R1 12.01, R 1.37)
- **THEN** the profile passes through radius 6.005 at z = 0.38 and through radius 6.005 at z = 1.37

#### Scenario: Rimfire half-round
- **WHEN** the drawing for "22 Long Rifle" is computed
- **THEN** the rim edge is a half-round of radius 0.545 whose outermost radius is 3.53

### Requirement: Extractor groove and belt
Where E and E1 are published the profile SHALL go from (R1/2, R) in to (E1/2, R), along the floor to (E1/2, R + e min), then ramp straight out to (P1/2, E). On belted cases it SHALL instead ramp out from the floor end at angle δ to the axis up to the belt R3/2, follow the belt to z = E, then step in to P1/2. Without a groove it SHALL step in from (R1/2, R) to (P1/2, R).

#### Scenario: Groove
- **WHEN** the drawing for "308 Win." is computed
- **THEN** the profile contains the points (5.195, 1.37), (5.195, 2.77) and (5.98, 3.85)

#### Scenario: Belt
- **WHEN** the drawing for "300 Win. Mag." is computed
- **THEN** the profile follows radius 6.755 from the end of the δ ramp to z = 5.59 and then steps in to radius 6.515

#### Scenario: No groove published
- **WHEN** the drawing for "7 x 65 R" is computed
- **THEN** the profile steps in from radius 6.66 to radius 5.945 at z = 1.4

### Requirement: Body, shoulder and neck
The body SHALL be a straight line from P1/2 at the body start to (P2/2, L1) on a bottleneck case. A case without alpha, L1 or L2 SHALL be straight: the body runs to (H2/2, L3). The shoulder SHALL run from (P2/2, L1) to (H1/2, L2); α is the included cone angle and SHALL be labelled. The neck SHALL run from (H1/2, L2) to (H2/2, L3), then the mouth face.

#### Scenario: Bottleneck
- **WHEN** the drawing for "308 Win." is computed
- **THEN** the corner points (before any rounding) are (5.765, 39.62), (4.36, 43.48) and (4.36, 51.18), and the profile ends at the mouth point (4.36, 51.18)

#### Scenario: Straight case
- **WHEN** the drawing for "9 mm Luger" is computed
- **THEN** the body runs to (4.825, 19.15) and no shoulder is drawn and no α is labelled

### Requirement: Corner rounding
The body-side shoulder corner SHALL be rounded with r1 min and the neck-side corner with r2, each only where the value is published.

#### Scenario: Both radii
- **WHEN** the drawing for "308 Win." is computed
- **THEN** both shoulder corners are rounded (r1 min 0.76, r2 3.18)

#### Scenario: Radius missing
- **WHEN** the drawing for "17 HMR" is computed
- **THEN** no corner is rounded and the drawing notes name the missing values "r1 min" and "r2"

### Requirement: Bullet geometry
The bullet SHALL be seated with its tip at z = L6, shank diameter G1, seating depth s below the mouth by shape (pointy 1.0·G1; rounded or flat 0.8·G1 on rifle and rimfire, 0.4·G1 on pistol; semi_wadcutter 0.6·G1), base at zb = L3 − s. Its cylinder SHALL run to zb + k·Lb (k: pointy 0.40; rounded 0.55 rifle or rimfire, 0.65 pistol; flat 0.60 rifle, 0.70 pistol; semi_wadcutter 0.78), with Lb = L6 − zb. The shape comes from `annotations.defaultBulletShape`.

#### Scenario: Seating of a pointy bullet
- **WHEN** the drawing for "308 Win." is computed
- **THEN** the bullet base is at z = 43.33 and the cylinder ends at z = 54.446

#### Scenario: Pistol round nose
- **WHEN** the drawing for "9 mm Luger" is computed
- **THEN** the seating depth is 3.612 mm and the cylinder ends at 65 % of the bullet length

### Requirement: Bullet nose
The nose SHALL run from the cylinder end to the tip with a flat tip of diameter m. Pointy: tangent ogive with m = max(0.08·G1, 1.27) and arc radius ρ = ((G1/2 − m/2)² + n²) / (2·(G1/2 − m/2)), n the nose length, centre at radius G1/2 − ρ on the radial line where the nose starts. Rounded: quarter ellipse, m = 0.15·G1. Flat: straight cone, m = 0.55·G1. Semi_wadcutter: straight cone, m = 0.6·G1.

#### Scenario: Tangent ogive
- **WHEN** the drawing for "308 Win." is computed
- **THEN** m = 1.27, the nose length is 16.674 and ρ is 43.9 (± 0.05)
- **AND** the arc is tangent to the cylinder where the nose starts and ends at the tip radius m/2 at z = 71.12

#### Scenario: Cone and ellipse tips
- **WHEN** the drawings for "40 S.& W." (flat, G1 10.17) and "45 Auto" (rounded, G1 11.48) are computed
- **THEN** the tip diameters are 5.5935 and 1.722

### Requirement: Heeled case
When H2 − G1 <= 0.015 (the case is heeled, for example "22 Long Rifle"), the exposed bullet SHALL have the case's outside diameter and the seated heel SHALL have the case's inside diameter H2 − 2·tb.

#### Scenario: 22 Long Rifle
- **WHEN** the drawing for "22 Long Rifle" is computed
- **THEN** the exposed bullet diameter is 5.72 and the seated heel diameter in the section is 4.52

### Requirement: Outside view and section
The outside view SHALL hide the seated part of the bullet; the section SHALL show it inside the case. The section's cut walls SHALL be hatched. Neck wall tn = (H2 − G1)/2; body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner line SHALL follow the outer body, shoulder and neck at these walls (tb along the body, tn along the neck, blended linearly across the shoulder).

#### Scenario: Walls of 308 Win.
- **WHEN** the drawing for "308 Win." is computed
- **THEN** tn = 0.435, tb = 0.6, and the inner radius at the neck is 3.925

#### Scenario: Seated part
- **WHEN** the drawing for "308 Win." is shown
- **THEN** the outside view has no line of the bullet between z = 43.33 and z = 51.18 and the section has

### Requirement: Solid head and primer pocket
The solid head SHALL run from the head face to z = w, with w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or the belt ramp end + tb on belted cases). A primer pocket SHALL be drawn on centrefire cases: diameter 4.45 for `sp`, `spm`, `sr` and 5.33 for `lp`, `lpm`, `lr`, `lrm`; depth 3.04 for `sp`, `spm`, `sr`, `lp`, `lpm` and 3.3 for `lr`, `lrm`. Rimfire cases SHALL have no pocket.

#### Scenario: Head of 308 Win.
- **WHEN** the drawing for "308 Win." is computed
- **THEN** the pocket is 5.33 wide and 3.3 deep and w = 4.8

#### Scenario: Rimfire
- **WHEN** the drawing for "17 HMR" is computed
- **THEN** no primer pocket is drawn

### Requirement: Dimension lines
The drawing SHALL have dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value, for example `L3 51.18`.

#### Scenario: Labels of 308 Win.
- **WHEN** the drawing for "308 Win." is shown
- **THEN** it contains labels `L3 51.18`, `L6 71.12`, `R1 12.01`, `R 1.37`, `P1 11.96`, `P2 11.53`, `H1 8.72`, `H2 8.72`, `G1 7.85`, `L1 39.62`, `L2 43.48`, `E1 10.39` and `α 40°`

#### Scenario: Not published
- **WHEN** the drawing for "9 mm Luger" is shown
- **THEN** it has no labels for P2, H1, L1, L2 or α

### Requirement: Labels do not collide
Labels SHALL NOT overlap each other, the outline, the title block or the edge of the drawing, for each of the 25 cartridges.

#### Scenario: All cartridges
- **WHEN** the layout is computed for each of the 25 records
- **THEN** the bounding boxes of all labels are pairwise disjoint, disjoint from the outline and the title block, and inside the viewBox

### Requirement: Title block and scale
The drawing SHALL have a title block with the cartridge's name, the C.I.P. table (`tab`) and the revision date, the text "Dimensions in mm", and the scale at which the drawing prints on A4 (a ratio such as 1.8 : 1). The drawing SHALL include a 10 mm scale bar so that the scale is checkable on any screen.

#### Scenario: Title block
- **WHEN** the drawing for "308 Win." is shown
- **THEN** the title block contains "308 Win.", "C.I.P. table I", "Revised 2008-09-23", "Dimensions in mm" and a scale

#### Scenario: Scale matches print
- **WHEN** the drawing is printed at full width of A4 portrait
- **THEN** one millimetre of the cartridge measures the stated ratio on paper

### Requirement: Missing values
When a value a rule needs is missing, the drawing SHALL omit that feature and a note below the drawing SHALL name each missing value; no number SHALL be invented.

#### Scenario: Missing groove values
- **WHEN** the drawing for "7 x 65 R" is shown
- **THEN** the note says the extractor groove is not drawn because E, E1 and e min are not published

#### Scenario: Nothing missing
- **WHEN** the drawing for "308 Win." is shown
- **THEN** no missing-values note is shown

### Requirement: Responsive and legible
The drawing SHALL scale to the width of its container down to a phone screen of 360 CSS px, keeping its aspect ratio, and its text SHALL remain legible (at least 10 CSS px on a 360 px screen and at least 7 pt printed).

#### Scenario: Phone width
- **WHEN** the viewport is 360 px wide
- **THEN** the drawing fits the width without horizontal scrolling and label text renders at no less than 10 px
