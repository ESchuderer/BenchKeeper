# Spec Delta

## Purpose

Produces a one-page A4 printout of a cartridge's detail view that can be used as a workshop reference sheet, independent of the screen theme.

## ADDED Requirements

### Requirement: Print opens the print dialog
The "Print" button SHALL open the browser's print dialog for the current detail view.

#### Scenario: Print button
- **WHEN** the user activates "Print" on a detail view
- **THEN** the browser's print function is invoked

### Requirement: One A4 portrait page
A printed detail view SHALL fit one A4 portrait page for every one of the 25 cartridges, black on white regardless of the screen's light or dark setting, in this order: page header with the cartridge's name, the drawing at full width of the printable area with every label legible, then the tables.

#### Scenario: Page count
- **WHEN** the detail view of any of the 25 cartridges is printed to PDF at A4 portrait
- **THEN** the PDF has exactly one page

#### Scenario: Dark system setting
- **WHEN** the system uses a dark colour scheme and the view is printed
- **THEN** the printout has a white background and black (or grey-black) text and lines

#### Scenario: Order
- **WHEN** a detail view is printed
- **THEN** the name header comes first, the drawing second at the full printable width, and the tables after it

### Requirement: Print hides interface elements
A printed detail view SHALL NOT show navigation, the link "All cartridges", search, the select, or buttons.

#### Scenario: No controls
- **WHEN** a detail view is printed
- **THEN** the "Print" button and the "All cartridges" link are not in the printout

### Requirement: Source footer
A printed detail view SHALL have a footer naming the source "C.I.P. TDCC" and the cartridge's revised date.

#### Scenario: Footer
- **WHEN** the detail view of "308 Win." is printed
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2008-09-23"
