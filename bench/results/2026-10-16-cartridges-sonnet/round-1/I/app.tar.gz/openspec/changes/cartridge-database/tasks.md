# Tasks

## 1. Project setup, data and README

- [x] 1.1 Create `package.json` (private, dev dependencies only, scripts `test`, `test:unit`, `test:e2e`, `serve`) and `.gitignore` (`node_modules`, test output); verify `npm test` runs and reports zero tests without error.
- [x] 1.2 Save the brief's 25 records as `tests/fixtures/cartridges.jsonl` and write a failing data-integrity test (25 records, order, deep equality with `CIP.data`); then add `js/data.js` (generated from the fixture by a dev script `tools/make-data.js`, output committed) and verify the test passes.
- [x] 1.3 Add `README.md` (what it is, how to open from disk, how to serve, how to test, data provenance and licence note, list of rule interpretations from `design.md`); verify the commands in it run as written.
- [x] 1.4 Install the browser test tooling as dev dependencies and a Chromium for it; verify a trivial script opens `file://…/index.html` headlessly. If Chromium cannot be installed, record the fallback chosen in `README.md` and tell the user.

## 2. Formatting

- [x] 2.1 Write failing tests for number, angle (`40°`, `39°59'49"`, `3°10'36"`), tolerance merge (`39.62 -0.2`), symbols (e min, r1 min, r1 max, α, α1, β, δ, delta L, L3 + G) and units (mm, bar, J, g, mm², none for N, ° for angles); implement `js/format.js` and verify the tests pass.
- [x] 2.2 Write failing tests that, for each of the 25 records, the table model has one row per published field except `…Tol`, no empty groups, and no `undefined`/`NaN` text; implement the table model (`sections(record)`) and verify the tests pass.

## 3. Search and family filter

- [x] 3.1 Write failing tests (`7,62 x 51` → "308 Win.", `creed`, case and whitespace, no match, family belted → 2, family + search combined, All → 25); implement `js/filter.js` and verify the tests pass.

## 4. Geometry (TDD, one rule group at a time)

- [x] 4.1 Write failing tests for rim type (all 25 records plus synthetic rebated) and head/rim edge/groove/belt points from the spec scenarios (308 Win., 300 Win. Mag., 7 x 65 R, 22 Long Rifle half-round); implement the outer profile from the head to the body start in `js/geometry.js` and verify the tests pass.
- [x] 4.2 Write failing tests for body, straight case, shoulder, neck and fillets (308 Win., 9 mm Luger, 17 HMR notes, fillet tangency and clamping); implement and verify.
- [x] 4.3 Write failing tests for the bullet (seating, cylinder end, ogive ρ ≈ 43.9 and tangency for 308 Win., rounded and flat tip diameters, semi_wadcutter, heeled 22 Long Rifle); implement and verify.
- [x] 4.4 Write failing tests for walls tn/tb, inner profile (incl. straight-case blend), solid head `w`, pocket sizes by primer type, rimfire without pocket; implement and verify.
- [x] 4.5 Write a failing test that all 25 records build without throwing, produce finite coordinates, a closed section path without self-overlap of bullet and wall (bullet radius ≤ inner radius over the seated part), and list missing-value notes only for the cartridges named in the spec; implement fixes and verify.

## 5. Dimensions, label layout and SVG

- [x] 5.1 Write failing tests for the dimension set (labels `L3 51.18`, `α 40°`, … for 308 Win.; none of P2/H1/L1/L2/α for 9 mm Luger) and for label collision-freedom across all 25 records (labels vs labels, outline, title block, viewBox edge); implement `js/layout.js` and verify.
- [x] 5.2 Write failing string-level tests for the SVG (accessible name "<name> drawing", mm viewBox with L3 span, title block text, scale ratio, 10 mm scale bar, dash-dot centre line, hatch pattern, escaping, notes); implement `js/drawing.js` and verify.
- [x] 5.3 Render all 25 drawings to PNG with the browser tooling (light and dark) and inspect them (outline continuity, bullet seating, arrowheads, hatching, label legibility); fix defects with a test per defect.

## 6. App shell, list and detail views

- [x] 6.1 Write failing browser tests for the start page (heading, 25 entries with name link text, family, L3, "25 cartridges", Search, Family select, count updates, no-match message) and implement `index.html`, `css/app.css`, `js/app.js` list view; verify the tests pass.
- [x] 6.2 Write failing browser tests for the detail view (heading, facts incl. alternative names/capacity link/"not published", tables with Symbol/Value/Unit, no `Tol` rows, Print button calls `window.print`, "All cartridges" link) and implement the detail view and hash routing (reload, back button, unknown key); verify the tests pass.
- [x] 6.3 Style: light/dark via `prefers-color-scheme`, tabular numbers, dense tables, visible focus, keyboard order, 360 px layout without horizontal scroll; verify with browser tests (dark emulation, 360 px viewport, keyboard tab order) and screenshots.

## 7. Print

- [x] 7.1 Write a failing browser test that prints each of the 25 detail views to PDF (A4 portrait) and asserts exactly one page, plus a DOM test in print media that controls are hidden and the footer reads "Source: C.I.P. TDCC, revised <date>"; implement the print CSS and verify.
- [x] 7.2 Verify print legibility and order by rasterising the PDFs of at least 22 Long Rifle, 308 Win., 9,3 x 74 R and 338 Lapua Mag. and inspecting them (white background under dark scheme, drawing full width, labels ≥ 7 pt, tables below).

## 8. Integration and delivery checks

- [x] 8.1 Verify from `file://` and from a static server (any `http` static script): no console errors, no network requests beyond own files (none for `file://`), reload of every detail address, all 25 detail views open without errors; fix any defect with a test.
- [x] 8.2 Verify the constraints: no framework, no build step, no CDN/web-font/analytics references (grep), no runtime dependencies in `package.json`, data unchanged (integrity test), interface text in English.
- [x] 8.3 Run the full suite (`npm test`) and the review skills (code review, security review, test-quality review); fix findings and re-run until clean (the work is left uncommitted for the user to review).

## Workflow follow-up

- Archive the change (`openspec archive cartridge-database`) after review is satisfied.
