'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, startServer, openPage, indexUrl, h1 } = require('./helpers.js');

let browser, srv;
test.before(async () => {
  browser = await launch();
  srv = await startServer();
});
test.after(async () => {
  await browser.close();
  srv.server.close();
});

for (const [label, getUrl] of [['file://', () => indexUrl], ['http', () => srv.url]]) {
  test(`start page lists all cartridges (${label})`, async () => {
    const { page, context, log } = await openPage(browser, getUrl());
    assert.equal(await h1(page, 'Cartridges'), 'Cartridges');
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    assert.equal(await page.locator('table.cartridge-list tbody tr').count(), 25);
    const link = page.getByRole('link', { name: '6,5 Creedmoor', exact: true });
    assert.equal(await link.count(), 1);
    const row = page.locator('tr', { has: link });
    assert.match(await row.innerText(), /rimless/);
    assert.match(await row.innerText(), /48\.77/);
    assert.deepEqual(log.errors, []);
    await context.close();
  });
}

test('search by name and alternative name, family filter, count', async () => {
  const { page, context } = await openPage(browser, indexUrl);
  await page.getByLabel('Search').fill('7,62 x 51');
  assert.deepEqual(await page.locator('table.cartridge-list tbody a').allInnerTexts(), ['308 Win.']);
  assert.equal(await page.locator('#count').innerText(), '1 cartridges');
  await page.getByLabel('Search').fill('creed');
  assert.deepEqual(await page.locator('table.cartridge-list tbody a').allInnerTexts(), ['6,5 Creedmoor']);
  await page.getByLabel('Search').fill('zzzz');
  assert.equal(await page.locator('#count').innerText(), '0 cartridges');
  assert.match(await page.locator('main').innerText(), /No cartridge matches/);
  await page.getByLabel('Search').fill('');
  await page.getByLabel('Family').selectOption('belted');
  assert.deepEqual(await page.locator('table.cartridge-list tbody a').allInnerTexts(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(await page.locator('#count').innerText(), '2 cartridges');
  const opts = await page.getByLabel('Family').locator('option').allInnerTexts();
  assert.deepEqual(opts, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  await page.getByLabel('Family').selectOption('pistol');
  await page.getByLabel('Search').fill('44');
  assert.deepEqual(await page.locator('table.cartridge-list tbody a').allInnerTexts(), ['44 Rem. Mag.']);
  await context.close();
});

test('count is announced politely', async () => {
  const { page, context } = await openPage(browser, indexUrl);
  assert.equal(await page.locator('#count').getAttribute('aria-live'), 'polite');
  await context.close();
});

test('detail view opens from the link, has its own address, survives reload, back works', async () => {
  const { page, context } = await openPage(browser, indexUrl);
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  assert.equal(await h1(page, '308 Win.'), '308 Win.');
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  await page.reload();
  assert.equal(await h1(page, '308 Win.'), '308 Win.');
  await page.goBack();
  assert.equal(await h1(page, 'Cartridges'), 'Cartridges');
  assert.equal(await page.locator('#count').innerText(), '25 cartridges');
  await context.close();
});

test('bookmarked address opens in a new page (file:// and http)', async () => {
  for (const base of [indexUrl, srv.url]) {
    const { page, context, log } = await openPage(browser, base + '#/cartridge/9_mm_luger');
    assert.equal(await h1(page, '9 mm Luger'), '9 mm Luger');
    assert.deepEqual(log.errors, []);
    await context.close();
  }
});

test('filters are kept when coming back from a detail view', async () => {
  const { page, context } = await openPage(browser, indexUrl);
  await page.getByLabel('Family').selectOption('rimfire');
  await page.getByRole('link', { name: '17 HMR', exact: true }).click();
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await page.getByLabel('Family').inputValue(), 'rimfire');
  assert.equal(await page.locator('#count').innerText(), '3 cartridges');
  await context.close();
});

test('unknown address shows a message with a link back', async () => {
  const { page, context, log } = await openPage(browser, indexUrl + '#/cartridge/nope');
  assert.match(await page.locator('main').innerText(), /Cartridge not found/);
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await h1(page, 'Cartridges'), 'Cartridges');
  assert.deepEqual(log.errors, []);
  await context.close();
});

test('every detail address survives a reload, from disk and from a server', async () => {
  const { data } = require('../../js/data.js');
  for (const base of [indexUrl, srv.url]) {
    const { page, context, log } = await openPage(browser, base);
    for (const r of data) {
      await page.goto(base + '#/cartridge/' + r.key);
      await page.reload();
      assert.equal(await h1(page, r.name), r.name, r.key);
    }
    assert.deepEqual(log.errors, []);
    await context.close();
  }
});

test('malformed percent-escape in the address shows the not-found view', async () => {
  const { page, context, log } = await openPage(browser, indexUrl + '#/cartridge/%E0%A4%A');
  assert.match(await page.locator('main').innerText(), /Cartridge not found/);
  assert.deepEqual(log.errors, []);
  await context.close();
});
