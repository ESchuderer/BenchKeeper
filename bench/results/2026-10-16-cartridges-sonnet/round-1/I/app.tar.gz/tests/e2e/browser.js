'use strict';
// Launches Chromium for the browser tests. If the system libraries Chromium needs are missing and were unpacked
// into ~/.local/chromium-libs (no-root setups), they are put on LD_LIBRARY_PATH; a fonts.conf there supplies fonts.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { chromium } = require('playwright');

function env() {
  const libs = path.join(os.homedir(), '.local', 'chromium-libs');
  const e = { ...process.env };
  if (fs.existsSync(libs)) {
    const dirs = [path.join(libs, 'usr/lib/x86_64-linux-gnu'), path.join(libs, 'lib/x86_64-linux-gnu')];
    e.LD_LIBRARY_PATH = dirs.concat(e.LD_LIBRARY_PATH ? [e.LD_LIBRARY_PATH] : []).join(':');
    const conf = path.join(libs, 'etc', 'fonts.conf');
    if (fs.existsSync(conf)) e.FONTCONFIG_FILE = conf;
  }
  return e;
}

async function launch() {
  return chromium.launch({ env: env() });
}

module.exports = { launch };
