'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, openPage, indexUrl, h1 } = require('./helpers.js');
const { data } = require('../../js/data.js');

let browser;
test.before(async () => {
  browser = await launch();
});
test.after(async () => {
  await browser.close();
});

const open = (key, opts) => openPage(browser, indexUrl + '#/cartridge/' + key, opts);

test('308 Win. facts', async () => {
  const { page, context } = await open('308_win');
  assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '308 Win.');
  const facts = await page.locator('dl.facts').innerText();
  for (const s of ['308 Winchester', '7,62 x 51', 'rimless', 'rifle', 'lr', 'I', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) {
    assert.ok(facts.includes(s), s + ' in ' + facts);
  }
  const link = page.locator('dl.facts a');
  assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
  assert.match((await link.getAttribute('rel')) || '', /noopener/);
  await context.close();
});

test('22 Long Rifle: capacity not published, no source link', async () => {
  const { page, context } = await open('22_long_rifle');
  const facts = await page.locator('dl.facts').innerText();
  assert.match(facts, /not published/);
  assert.equal(await page.locator('dl.facts a').count(), 0);
  await context.close();
});

test('243 Win.: no alternative names entry', async () => {
  const { page, context } = await open('243_win');
  assert.doesNotMatch(await page.locator('dl.facts').innerText(), /Alternative names/);
  await context.close();
});

test('tables: Symbol / Value / Unit, tolerance merged, symbols, units', async () => {
  const { page, context } = await open('308_win');
  const heads = await page.locator('table.values thead').first().innerText();
  assert.match(heads, /Symbol\s+Value\s+Unit/);
  const body = await page.locator('main').innerText();
  assert.ok(!/L1Tol|P2Tol|\bTol\b/.test(body));
  const l1 = page.locator('table.values tr', { has: page.locator('th[scope=row]', { hasText: /^L1$/ }) }).first();
  assert.match(await l1.innerText(), /L1\s+39\.62 -0\.2\s+mm/);
  const pmax = page.locator('table.values tr', { has: page.locator('th[scope=row]', { hasText: /^Pmax$/ }) }).first();
  assert.match(await pmax.innerText(), /Pmax\s+4150\s+bar/);
  const alpha = page.locator('table.values tr', { has: page.locator('th[scope=row]', { hasText: /^α$/ }) }).first();
  assert.match(await alpha.innerText(), /α\s+40°/);
  assert.equal(await page.getByRole('heading', { level: 2, name: 'Cartridge values' }).count(), 1);
  assert.equal(await page.getByRole('heading', { level: 2, name: 'Chamber values' }).count(), 1);
  await context.close();
});

test('every published field has a row: counts for all 25 records', async () => {
  const { page, context } = await open('308_win');
  for (const r of data) {
    await page.evaluate((k) => (location.hash = '#/cartridge/' + k), r.key);
    await page.waitForFunction((n) => document.querySelector('h1') && document.querySelector('h1').textContent === n, r.name);
    const rows = await page.locator('table.values tbody tr').count();
    let expected = 0;
    for (const scope of ['cartridge', 'chamber']) for (const g of Object.values(r[scope])) expected += Object.keys(g).filter((k) => !/Tol$/.test(k)).length;
    assert.equal(rows, expected, r.key);
  }
  await context.close();
});

test('drawing is present with accessible name and notes', async () => {
  const { page, context } = await open('7_x_65_r');
  assert.equal(await page.getByRole('img', { name: '7 x 65 R drawing' }).count(), 1);
  assert.match(await page.locator('.drawing-notes').innerText(), /Extractor groove not drawn: E, E1 and e min are not published\./);
  await context.close();
  const b = await open('308_win');
  assert.equal(await b.page.locator('.drawing-notes').count(), 0);
  await b.context.close();
});

test('print button calls window.print; All cartridges link returns', async () => {
  const { page, context } = await open('308_win');
  await page.evaluate(() => {
    window.__printed = 0;
    window.print = () => { window.__printed++; };
  });
  await page.getByRole('button', { name: 'Print' }).click();
  assert.equal(await page.evaluate(() => window.__printed), 1);
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await h1(page, 'Cartridges'), 'Cartridges');
  await context.close();
});

test('all 25 detail views open without console errors', async () => {
  const { page, context, log } = await open('223_rem');
  for (const r of data) {
    await page.evaluate((k) => (location.hash = '#/cartridge/' + k), r.key);
    await page.waitForFunction((n) => document.querySelector('h1') && document.querySelector('h1').textContent === n, r.name);
    assert.equal(await page.getByRole('img', { name: r.name + ' drawing' }).count(), 1, r.key);
  }
  assert.deepEqual(log.errors, []);
  await context.close();
});
