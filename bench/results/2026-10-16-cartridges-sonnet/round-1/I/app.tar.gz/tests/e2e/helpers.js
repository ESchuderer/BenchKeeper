'use strict';
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { launch } = require('./browser.js');
const { createServer } = require('../../tools/serve.js');

const indexUrl = pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;

async function startServer() {
  const server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return { server, url: `http://127.0.0.1:${server.address().port}/` };
}

/* Opens a page and records console errors, page errors and requests. */
async function openPage(browser, url, contextOptions) {
  const context = await browser.newContext(contextOptions || {});
  const page = await context.newPage();
  const log = { errors: [], requests: [] };
  page.on('console', (m) => {
    if (m.type() === 'error' || m.type() === 'warning') log.errors.push(m.type() + ': ' + m.text());
  });
  page.on('pageerror', (e) => log.errors.push('pageerror: ' + e.message));
  page.on('request', (r) => log.requests.push(r.url()));
  await page.goto(url);
  return { page, context, log };
}

/* Waits until the level-one heading has the given text (navigation renders asynchronously). */
async function h1(page, text) {
  await page.waitForFunction((t) => { const e = document.querySelector('h1'); return e && e.textContent === t; }, text);
  return page.getByRole('heading', { level: 1 }).innerText();
}

module.exports = { launch, startServer, openPage, indexUrl, h1 };
