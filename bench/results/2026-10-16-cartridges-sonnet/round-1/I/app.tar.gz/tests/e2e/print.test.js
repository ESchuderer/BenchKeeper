'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { launch, openPage, indexUrl } = require('./helpers.js');
const { data } = require('../../js/data.js');

let browser;
test.before(async () => {
  browser = await launch();
});
test.after(async () => {
  await browser.close();
});

const outDir = path.join(__dirname, '..', '..', 'test-output', 'pdf');
const pageCount = (buf) => (buf.toString('latin1').match(/\/Type\s*\/Page(?![s\w])/g) || []).length;

test('every detail view prints on exactly one A4 portrait page (dark system setting)', async () => {
  fs.mkdirSync(outDir, { recursive: true });
  const { page, context } = await openPage(browser, indexUrl, { colorScheme: 'dark' });
  const tall = [];
  for (const r of data) {
    await page.evaluate((k) => (location.hash = '#/cartridge/' + k), r.key);
    await page.waitForFunction((n) => document.querySelector('h1') && document.querySelector('h1').textContent === n, r.name);
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    fs.writeFileSync(path.join(outDir, r.key + '.pdf'), pdf);
    const n = pageCount(pdf);
    if (n !== 1) tall.push(`${r.key}: ${n} pages`);
    const mb = pdf.toString('latin1').match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/);
    assert.ok(mb && Math.abs(Number(mb[1]) - 595.28) < 1 && Math.abs(Number(mb[2]) - 841.89) < 1, `${r.key} is A4 portrait: ${mb && mb[0]}`);
  }
  assert.deepEqual(tall, []);
  await context.close();
});

test('print media: controls hidden, order header / drawing / tables, footer, white background, legible labels', async () => {
  const { page, context } = await openPage(browser, indexUrl + '#/cartridge/308_win', { colorScheme: 'dark' });
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  for (const sel of ['.site-header', '.site-footer', '.toolbar', 'button', '.skip-link']) {
    assert.equal(await page.locator(sel).first().isVisible(), false, sel + ' hidden in print');
  }
  assert.equal(await page.locator('.print-footer').isVisible(), true);
  assert.equal((await page.locator('.print-footer').innerText()).trim(), 'Source: C.I.P. TDCC, revised 2008-09-23');
  const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  const fg = await page.evaluate(() => getComputedStyle(document.body).color);
  assert.match(bg, /rgb\(255, 255, 255\)|rgba\(0, 0, 0, 0\)/);
  assert.equal(fg, 'rgb(0, 0, 0)');
  const label = await page.evaluate(() => getComputedStyle(document.querySelector('.cip-label')).fill);
  assert.equal(label, 'rgb(0, 0, 0)');
  const y = async (sel) => (await page.locator(sel).first().boundingBox()).y;
  const h1 = await y('h1');
  const svg = await y('svg.cip-drawing');
  const tables = await y('table.values');
  const footer = await y('.print-footer');
  assert.ok(h1 < svg && svg < tables && tables < footer, `order ${h1} ${svg} ${tables} ${footer}`);
  // drawing at full printable width (190 mm = 718 px) and labels >= 7 pt
  const m = await page.evaluate(() => {
    const s = document.querySelector('svg.cip-drawing');
    const t = document.querySelector('.cip-label');
    return { w: s.getBoundingClientRect().width, pt: parseFloat(t.getAttribute('font-size')) * t.getScreenCTM().a * 0.75 };
  });
  assert.ok(Math.abs(m.w - (190 / 25.4) * 96) < 3, 'svg width ' + m.w);
  assert.ok(m.pt >= 7, 'label pt ' + m.pt);
  await context.close();
});

test('scale in the title block matches the printed size', async () => {
  const { page, context } = await openPage(browser, indexUrl + '#/cartridge/300_win_mag');
  await page.emulateMedia({ media: 'print' });
  const m = await page.evaluate(() => {
    const s = document.querySelector('svg.cip-drawing');
    const scaleText = [...s.querySelectorAll('text')].map((t) => t.textContent).find((t) => /^Scale/.test(t));
    const bar = s.querySelector('.cip-scalebar');
    const mmPerUnit = s.getBoundingClientRect().width / s.viewBox.baseVal.width / 96 * 25.4;
    return { scaleText, mmPerUnit };
  });
  const stated = Number(m.scaleText.match(/Scale ([\d.]+) : 1/)[1]);
  assert.ok(Math.abs(stated - m.mmPerUnit) < 0.02, `${stated} vs ${m.mmPerUnit}`);
  await context.close();
});
