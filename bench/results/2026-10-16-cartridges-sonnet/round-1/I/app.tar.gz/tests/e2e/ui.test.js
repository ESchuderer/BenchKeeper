'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, openPage, indexUrl } = require('./helpers.js');

let browser;
test.before(async () => {
  browser = await launch();
});
test.after(async () => {
  await browser.close();
});

const luminance = (rgb) => {
  const [r, g, b] = rgb.match(/\d+(\.\d+)?/g).map(Number);
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
};

test('phone 360 px: no horizontal scroll; drawing labels are at least 10 px', async () => {
  const phone = { viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true };
  for (const hash of ['', '#/cartridge/308_win', '#/cartridge/9_3_x_74_r', '#/cartridge/22_long_rifle', '#/cartridge/22_win_mag_r_f']) {
    const { page, context } = await openPage(browser, indexUrl + hash, phone);
    const m = await page.evaluate(() => ({
      sw: document.documentElement.scrollWidth,
      cw: document.documentElement.clientWidth,
      px: (() => {
        const t = document.querySelector('.cip-label');
        if (!t) return null;
        return parseFloat(t.getAttribute('font-size')) * t.getScreenCTM().a;
      })(),
    }));
    assert.ok(m.sw <= m.cw, `${hash} scrollWidth ${m.sw} > ${m.cw}`);
    if (hash) assert.ok(m.px >= 9.9, `${hash} label px ${m.px}`);
    await context.close();
  }
});

test('all drawing text (labels and title block) is at least 10 px at 360 px, for all 25 cartridges', async () => {
  const { data } = require('../../js/data.js');
  const phone = { viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true };
  const { page, context } = await openPage(browser, indexUrl + '#/cartridge/223_rem', phone);
  for (const r of data) {
    await page.evaluate((k) => (location.hash = '#/cartridge/' + k), r.key);
    await page.waitForFunction((n) => document.querySelector('h1') && document.querySelector('h1').textContent === n, r.name);
    const small = await page.evaluate(() =>
      [...document.querySelectorAll('svg.cip-drawing text')]
        .map((t) => ({ t: t.textContent, px: parseFloat(t.getAttribute('font-size')) * t.getScreenCTM().a }))
        .filter((x) => x.px < 9.9)
    );
    assert.deepEqual(small, [], r.key);
  }
  await context.close();
});

test('dark scheme on screen: dark page and dark drawing body', async () => {
  const { page, context } = await openPage(browser, indexUrl + '#/cartridge/308_win', { colorScheme: 'dark' });
  const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  const body = await page.evaluate(() => getComputedStyle(document.querySelector('.cip-body')).fill);
  const label = await page.evaluate(() => getComputedStyle(document.querySelector('.cip-label')).fill);
  assert.ok(luminance(bg) < 0.15, bg);
  assert.ok(luminance(body) < 0.3, body);
  assert.ok(luminance(label) > 0.7, label);
  await context.close();
  const l = await openPage(browser, indexUrl, { colorScheme: 'light' });
  assert.ok(luminance(await l.page.evaluate(() => getComputedStyle(document.body).backgroundColor)) > 0.9);
  await l.context.close();
});

test('tabular numbers on values', async () => {
  const { page, context } = await openPage(browser, indexUrl + '#/cartridge/308_win');
  const v = await page.evaluate(() => getComputedStyle(document.querySelector('table.values td.num')).fontVariantNumeric);
  assert.match(v, /tabular-nums/);
  await context.close();
});

test('keyboard: controls are reachable in order and show a focus indicator', async () => {
  const { page, context } = await openPage(browser, indexUrl);
  const seen = [];
  for (let i = 0; i < 6; i++) {
    await page.keyboard.press('Tab');
    seen.push(await page.evaluate(() => {
      const e = document.activeElement;
      const cs = getComputedStyle(e);
      return { name: e.id || e.textContent.trim(), outline: cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0 };
    }));
  }
  const names = seen.map((s) => s.name);
  assert.ok(names.indexOf('search') > -1 && names.indexOf('family') > names.indexOf('search'), names.join('|'));
  assert.ok(names.includes('223 Rem.'), names.join('|'));
  assert.ok(seen.filter((s) => ['search', 'family', '223 Rem.'].includes(s.name)).every((s) => s.outline));
  await page.keyboard.press('Enter');
  await page.waitForFunction(() => location.hash.startsWith('#/cartridge/') && document.activeElement === document.querySelector('h1'));
  const detail = [];
  for (let i = 0; i < 4; i++) {
    await page.keyboard.press('Tab');
    detail.push(await page.evaluate(() => document.activeElement.textContent.trim()));
  }
  assert.ok(detail.includes('All cartridges') && detail.includes('Print'), detail.join('|'));
  await context.close();
});

test('no network requests beyond the app files', async () => {
  const { page, context, log } = await openPage(browser, indexUrl);
  await page.getByLabel('Search').fill('308');
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await page.evaluate(() => { window.print = () => {}; });
  await page.getByRole('button', { name: 'Print' }).click();
  const ext = log.requests.filter((u) => !u.startsWith('file://') && !u.startsWith('data:'));
  assert.deepEqual(ext, []);
  assert.deepEqual(log.errors, []);
  await context.close();
});
