'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const fixture = fs
  .readFileSync(path.join(__dirname, '..', 'fixtures', 'cartridges.jsonl'), 'utf8')
  .split('\n')
  .filter(Boolean)
  .map((l) => JSON.parse(l));

test('embedded data is the 25 supplied records, unchanged and in order', () => {
  const { data } = require('../../js/data.js');
  assert.equal(fixture.length, 25);
  assert.equal(data.length, 25);
  assert.deepEqual(data, fixture);
});

test('keys are unique and URL-safe', () => {
  const { data } = require('../../js/data.js');
  const keys = data.map((r) => r.key);
  assert.equal(new Set(keys).size, 25);
  for (const k of keys) assert.match(k, /^[a-z0-9_]+$/);
});
