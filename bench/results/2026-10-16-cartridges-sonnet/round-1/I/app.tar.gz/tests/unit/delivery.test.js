'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..', '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const appFiles = ['index.html', ...fs.readdirSync(path.join(root, 'js')).map((f) => 'js/' + f), ...fs.readdirSync(path.join(root, 'css')).map((f) => 'css/' + f)];

test('app files exist: index.html with its CSS and JavaScript', () => {
  for (const f of ['index.html', 'css/app.css', 'css/drawing.css', 'css/print.css', 'js/app.js', 'js/data.js']) assert.ok(fs.existsSync(path.join(root, f)), f);
});

test('index.html references only local files and every referenced file exists', () => {
  const html = read('index.html');
  const refs = [...html.matchAll(/(?:src|href)="([^"#][^"]*)"/g)].map((m) => m[1]);
  for (const r of refs) {
    if (/^https:\/\/github\.com\/PiMetry\/OpenBallistics$/.test(r)) continue; // a plain link in the footer, never fetched
    assert.doesNotMatch(r, /^(https?:)?\/\//, 'no remote resource: ' + r);
    assert.ok(fs.existsSync(path.join(root, r)), r + ' exists');
  }
  assert.doesNotMatch(html, /type="module"/);
});

test('no network APIs, CDNs, web fonts, analytics or framework in app code', () => {
  for (const f of appFiles) {
    if (f === 'js/data.js') continue;
    const src = read(f);
    assert.doesNotMatch(src, /\bfetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon|EventSource|\bimport\s*\(|@import|@font-face|url\(\s*["']?https?:/, f);
    assert.doesNotMatch(src, /googleapis|cdn\.|unpkg|jsdelivr|cloudflare|analytics|gtag|react|vue|angular|jquery/i, f);
  }
});

test('data.js holds no URLs other than the published capacity sources', () => {
  const urls = new Set([...read('js/data.js').matchAll(/https?:\/\/[^"\\\s]+/g)].map((m) => m[0]));
  const allowed = new Set(['http://kwk.us/cases.html', 'https://en.wikipedia.org/']);
  for (const u of urls) assert.ok(allowed.has(u), 'unexpected URL in data.js: ' + u);
  assert.equal(urls.size, 2);
});

test('package.json has no runtime dependencies', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.dependencies, undefined);
  assert.ok(pkg.devDependencies && Object.keys(pkg.devDependencies).length > 0);
});

test('interface strings required by the brief are present', () => {
  const app = read('js/app.js');
  for (const s of ["'Cartridges'", "'Search'", "'Family'", "'All cartridges'", "'Print'", "'Symbol'", "'Value'", "'Unit'"]) assert.ok(app.includes(s), s);
});
