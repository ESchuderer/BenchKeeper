'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../../js/drawing.js');
const { data } = require('../../js/data.js');
const rec = (k) => data.find((r) => r.key === k);

test('308 Win.: inline svg with accessible name, mm viewBox, title block', () => {
  const out = D.renderDrawing(rec('308_win'));
  assert.match(out.svg, /^<svg /);
  assert.match(out.svg, /role="img"/);
  assert.match(out.svg, /aria-label="308 Win\. drawing"/);
  assert.match(out.svg, /<title[^>]*>308 Win\. drawing<\/title>/);
  const vb = out.svg.match(/viewBox="0 0 ([\d.]+) ([\d.]+)"/);
  assert.ok(vb);
  assert.equal(Number(vb[1]), Number(out.layout.vbW.toFixed(3)));
  for (const t of ['308 Win.', 'C.I.P. table I', 'Revised 2008-09-23', 'Dimensions in mm']) assert.ok(out.svg.includes('>' + t + '<'), t);
  assert.match(out.svg, />Scale \d\.\d : 1</);
  assert.match(out.svg, />10 mm</);
});

test('308 Win.: centre line is dash-dot, hatch pattern is used, 13 labels', () => {
  const { svg } = D.renderDrawing(rec('308_win'));
  assert.match(svg, /class="cip-axis"/);
  assert.match(svg, /<pattern id="cip-hatch"/);
  assert.match(svg, /fill="url\(#cip-hatch\)"/);
  for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(svg.includes('>' + t + '<'), t);
  }
});

test('z is 1:1 in mm: head face to mouth is L3 in user units', () => {
  const { layout } = D.renderDrawing(rec('308_win'));
  const { svg } = D.renderDrawing(rec('308_win'));
  // the mouth face line sits at origin.x + 51.18
  const x = (layout.origin.x + 51.18).toFixed(3);
  assert.ok(svg.includes(x), 'mouth x coordinate ' + x);
  assert.ok(svg.includes(layout.origin.x.toFixed(3)), 'head face x coordinate');
});

test('upper half hides the seated bullet; the section shows it', () => {
  const { svg, layout } = D.renderDrawing(rec('308_win'));
  assert.match(svg, /class="cip-outside"/);
  assert.match(svg, /class="cip-bullet-section"/);
  // seating base z = 43.33 only appears in the section part
  const out = svg.match(/<g class="cip-outside">[\s\S]*?<\/g>/)[0];
  const sec = svg.match(/<g class="cip-section">[\s\S]*?<\/g>\s*<line class="cip-axis"/)[0];
  const base = (layout.origin.x + 43.33).toFixed(3);
  assert.ok(!out.includes(base + ' '), 'outside view must not draw the seated base');
  assert.ok(sec.includes(base), 'section shows the seated base');
});

test('no notes for 308 Win.; notes name the missing values for 7 x 65 R', () => {
  assert.deepEqual(D.renderDrawing(rec('308_win')).notes, []);
  const n = D.renderDrawing(rec('7_x_65_r')).notes;
  assert.equal(n.length, 1);
  assert.match(n[0], /Extractor groove not drawn: E, E1 and e min are not published\./);
});

test('text is escaped', () => {
  assert.equal(D.esc('a<b&"c"'), 'a&lt;b&amp;&quot;c&quot;');
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.name = '<script>x</script> & "q"';
  const { svg } = D.renderDrawing(r);
  assert.ok(!svg.includes('<script>'));
  assert.match(svg, /&lt;script&gt;x&lt;\/script&gt; &amp; &quot;q&quot; drawing/);
});

test('all 25 render without NaN or undefined', () => {
  for (const r of data) {
    const { svg } = D.renderDrawing(r);
    assert.doesNotMatch(svg, /NaN|undefined|Infinity/, r.key);
    assert.match(svg, /<\/svg>$/);
  }
});

test('svg has no external references (no network)', () => {
  const { svg } = D.renderDrawing(rec('308_win'));
  assert.doesNotMatch(svg, /https?:|xlink:href|<image|<script|<foreignObject/);
});

test('the centre line is not covered by a stroke along the axis', () => {
  for (const k of ['308_win', '9_mm_luger', '22_long_rifle']) {
    const { svg } = D.renderDrawing(rec(k));
    const lines = [...svg.matchAll(/<path class="cip-line" d="([^"]*)"/g)].map((m) => m[1]);
    assert.ok(lines.length >= 3, k + ': outline strokes are separate paths');
    for (const d of lines) assert.ok(!/Z/.test(d), k + ': outline stroke must stay open so it does not run along the axis');
    for (const m of svg.matchAll(/<path class="cip-(?:body|bullet|wall)"[^>]*>/g)) assert.ok(!/stroke/.test(m[0]), 'fill paths carry no stroke attribute');
    // the axis is drawn after the fills so it is seen inside the cartridge
    assert.ok(svg.indexOf('class="cip-axis"') > svg.lastIndexOf('class="cip-wall"'), k + ': axis drawn after the fills');
  }
});

test('head face to mouth is L3 user units, measured in the SVG itself', () => {
  const { svg } = D.renderDrawing(rec('308_win'));
  const body = svg.match(/<path class="cip-body" d="([^"]*)"/)[1];
  const xs = [...body.matchAll(/[ML]([\d.]+) /g)].map((m) => Number(m[1]));
  const headX = Math.min(...xs);
  const seat = svg.match(/<path class="cip-seat" d="M([\d.]+) /);
  assert.ok(Math.abs(Number(seat[1]) - headX - 51.18) < 0.002, `mouth ${seat[1]} - head ${headX}`);
  const tipX = Math.max(...[...body.matchAll(/([\d.]+) [\d.]+(?:L|Z|A|$)/g)].map((m) => Number(m[1])));
  assert.ok(Math.abs(tipX - headX - 71.12) < 0.01, 'tip at L6: ' + (tipX - headX));
});
