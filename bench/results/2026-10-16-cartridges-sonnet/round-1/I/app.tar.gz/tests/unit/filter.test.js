'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { filterCartridges, FAMILIES } = require('../../js/filter.js');
const { data } = require('../../js/data.js');
const names = (list) => list.map((r) => r.name);

test('empty query and All return all 25 in original order', () => {
  const r = filterCartridges(data, { query: '', family: 'All' });
  assert.equal(r.length, 25);
  assert.deepEqual(names(r), names(data));
});

test('alternative names are searched: 7,62 x 51 finds 308 Win.', () => {
  assert.deepEqual(names(filterCartridges(data, { query: '7,62 x 51', family: 'All' })), ['308 Win.']);
});

test('name search is case-insensitive substring', () => {
  assert.deepEqual(names(filterCartridges(data, { query: 'creed', family: 'All' })), ['6,5 Creedmoor']);
  assert.deepEqual(names(filterCartridges(data, { query: 'CREED', family: 'All' })), ['6,5 Creedmoor']);
});

test('whitespace is trimmed and collapsed', () => {
  assert.deepEqual(names(filterCartridges(data, { query: '  7,62   x  51 ', family: 'All' })), ['308 Win.']);
});

test('no match gives an empty list', () => {
  assert.equal(filterCartridges(data, { query: 'zzz', family: 'All' }).length, 0);
});

test('family filter', () => {
  assert.deepEqual(names(filterCartridges(data, { query: '', family: 'belted' })), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(filterCartridges(data, { query: '', family: 'rimfire' }).length, 3);
  assert.equal(filterCartridges(data, { query: '', family: 'pistol' }).length, 6);
  assert.equal(filterCartridges(data, { query: '', family: 'rimmed' }).length, 2);
  assert.equal(filterCartridges(data, { query: '', family: 'rimless' }).length, 12);
});

test('family and search combine', () => {
  const r = filterCartridges(data, { query: '44', family: 'pistol' });
  assert.deepEqual(names(r), ['44 Rem. Mag.']);
  assert.ok(r.every((x) => x.family === 'pistol'));
});

test('families offered by the select', () => {
  assert.deepEqual(FAMILIES, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  const covered = new Set(data.map((r) => r.family));
  for (const f of covered) assert.ok(FAMILIES.includes(f), f);
});

test('count helper', () => {
  const { countText } = require('../../js/filter.js');
  assert.equal(countText(25), '25 cartridges');
  assert.equal(countText(1), '1 cartridges');
  assert.equal(countText(0), '0 cartridges');
});
