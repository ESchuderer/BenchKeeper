'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../../js/format.js');
const { data } = require('../../js/data.js');
const byKey = (k) => data.find((r) => r.key === k);

test('formatNumber: decimal point, no grouping, no padding', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(5375), '5375');
  assert.equal(F.formatNumber(-0.2), '-0.2');
  assert.equal(F.formatNumber(0.76), '0.76');
});

test('formatAngle: degrees or degrees/minutes/seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(35.0), '35°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'0"');
});

test('angleToDegrees converts both forms', () => {
  assert.equal(F.angleToDegrees(40), 40);
  assert.ok(Math.abs(F.angleToDegrees({ degrees: 39, minutes: 59, seconds: 49 }) - 39.99694444) < 1e-6);
});

test('symbols', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
    L3: 'L3', Pmax: 'Pmax', R1: 'R1', E1: 'E1', Fe: 'Fe', r2: 'r2',
  };
  for (const [k, v] of Object.entries(expected)) assert.equal(F.symbol(k), v, k);
});

test('units', () => {
  const u = F.unit;
  for (const k of ['Pmax', 'PK', 'PE']) assert.equal(u(k), 'bar', k);
  assert.equal(u('EE'), 'J');
  assert.equal(u('M'), 'g');
  assert.equal(u('Q'), 'mm²');
  assert.equal(u('N'), '');
  for (const k of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(u(k), '°', k);
  for (const k of ['L3', 'P1', 'R1', 'E1', 'eMin', 'r1Min', 'G1', 'Z', 'F', 'u', 'deltaL', 'Fe', 'L3PlusG', 'S']) {
    assert.equal(u(k), 'mm', k);
  }
});

test('tolerance is merged into the value of X', () => {
  const secs = F.sections(byKey('308_win'));
  const lengths = secs.find((s) => s.scope === 'cartridge' && s.group === 'lengths');
  const l1 = lengths.rows.find((r) => r.field === 'L1');
  assert.equal(l1.value, '39.62 -0.2');
  assert.equal(lengths.rows.find((r) => r.field === 'L3').value, '51.18');
  assert.ok(!lengths.rows.some((r) => /Tol$/.test(r.field)));
});

test('308 Win. rows: symbols, values, units', () => {
  const secs = F.sections(byKey('308_win'));
  const get = (scope, group, field) =>
    secs.find((s) => s.scope === scope && s.group === group).rows.find((r) => r.field === field);
  assert.deepEqual(
    { s: get('cartridge', 'pressures', 'Pmax').symbol, v: get('cartridge', 'pressures', 'Pmax').value, u: get('cartridge', 'pressures', 'Pmax').unit },
    { s: 'Pmax', v: '4150', u: 'bar' }
  );
  assert.equal(get('cartridge', 'junctionCone', 'alpha').value, '40°');
  assert.equal(get('cartridge', 'junctionCone', 'alpha').symbol, 'α');
  assert.equal(get('chamber', 'rifling', 'alpha1').value, '71°25\'59"');
  assert.equal(get('chamber', 'junctionCone', 'r1Max').symbol, 'r1 max');
  assert.equal(get('cartridge', 'projectile', 'L3PlusG').symbol, 'L3 + G');
  assert.equal(get('chamber', 'grooves', 'N').unit, '');
});

test('6,5 x 55 SE: object angle in cartridge junction cone', () => {
  const secs = F.sections(byKey('6_5_x_55_se'));
  const a = secs.find((s) => s.scope === 'cartridge' && s.group === 'junctionCone').rows.find((r) => r.field === 'alpha');
  assert.equal(a.value, '50°35\'2"');
});

test('every published field appears exactly once, except Tol fields', () => {
  for (const rec of data) {
    const secs = F.sections(rec);
    for (const scope of ['cartridge', 'chamber']) {
      for (const [group, obj] of Object.entries(rec[scope])) {
        const fields = Object.keys(obj).filter((k) => !/Tol$/.test(k));
        const rows = secs.filter((s) => s.scope === scope && s.group === group).flatMap((s) => s.rows.map((r) => r.field));
        assert.deepEqual(rows, fields, `${rec.key} ${scope}.${group}`);
      }
    }
  }
});

test('no empty groups, no undefined/NaN in any cell', () => {
  for (const rec of data) {
    for (const s of F.sections(rec)) {
      assert.ok(s.rows.length > 0, `${rec.key} ${s.group}`);
      assert.ok(s.title && !/undefined/.test(s.title));
      for (const r of s.rows) {
        for (const c of [r.symbol, r.value, r.unit]) assert.doesNotMatch(String(c), /undefined|NaN|\[object/, `${rec.key} ${r.field}`);
      }
    }
  }
  const luger = F.sections(byKey('9_mm_luger'));
  assert.ok(!luger.some((s) => s.group === 'junctionCone'));
});

test('Tol fields only merge into an existing base field', () => {
  // L3Tol on 9 mm Luger
  const secs = F.sections(byKey('9_mm_luger'));
  const l3 = secs.find((s) => s.scope === 'cartridge' && s.group === 'lengths').rows.find((r) => r.field === 'L3');
  assert.equal(l3.value, '19.15 -0.25');
});

test('capacity text', () => {
  assert.equal(F.formatCapacity(byKey('308_win')).text, '56 gr H2O');
  assert.equal(F.formatCapacity(byKey('308_win')).url, 'http://kwk.us/cases.html');
  assert.equal(F.formatCapacity(byKey('22_long_rifle')).text, 'not published');
  assert.equal(F.formatCapacity(byKey('22_long_rifle')).url, null);
});
