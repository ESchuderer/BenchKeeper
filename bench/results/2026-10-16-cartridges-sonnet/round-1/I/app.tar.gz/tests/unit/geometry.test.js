'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const { data } = require('../../js/data.js');
const rec = (k) => data.find((r) => r.key === k);
const near = (a, b, eps = 1e-6, msg) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} expected ${b}, got ${a}`);
const hasPt = (pts, r, z, eps = 1e-6) => pts.some((p) => Math.abs(p.r - r) <= eps && Math.abs(p.z - z) <= eps);
const shoulderArcs = (m) => m.outer.items.filter((i) => i.arc && i.arc.c.z > 5);
const outer = (k) => G.flatten(G.buildDrawing(rec(k)).outer);

// ---- 4.1 rim type, head, groove, belt -------------------------------------------------
test('rim type thresholds', () => {
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 12.01 }, powderChamber: { P1: 11.96 } } }), 'rimless');
  assert.equal(G.rimType(rec('7_x_65_r')), 'rimmed');
  assert.equal(G.rimType(rec('9_3_x_62')), 'rimless'); // 0.9876
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 11.6 }, powderChamber: { P1: 12 } } }), 'rebated'); // 0.967
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 12.6 }, powderChamber: { P1: 12 } } }), 'rimmed'); // 1.05
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 11.76 }, powderChamber: { P1: 12 } } }), 'rimless'); // 0.98
  assert.equal(G.rimType(rec('300_win_mag')), 'belted');
  assert.equal(G.rimType(rec('17_hmr')), 'rimfire');
  assert.equal(G.rimType(rec('38_special')), 'rimmed'); // pistol family, ratio decides
});

test('308 Win.: chamfer, groove and ramp points (r, z)', () => {
  const p = outer('308_win');
  assert.deepEqual(p[0], { r: 0, z: 0 });
  const a = 12.01 / 2 - Math.min(0.38 * Math.tan((35 * Math.PI) / 180), 12.01 / 4);
  assert.ok(hasPt(p, a, 0));
  assert.ok(hasPt(p, 6.005, 0.38));
  assert.ok(hasPt(p, 6.005, 1.37));
  assert.ok(hasPt(p, 5.195, 1.37));
  assert.ok(hasPt(p, 5.195, 2.77));
  assert.ok(hasPt(p, 5.98, 3.85));
});

test('chamfer is limited to R1/4', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.cartridge.caseHead.f = 5; // f*tan(35) = 3.5 > R1/4 = 3.0025
  const p = G.flatten(G.buildDrawing(r).outer);
  assert.ok(hasPt(p, 6.005 - 12.01 / 4, 0));
});

test('no chamfer when beta or f is missing, or beta >= 90', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.f;
  let m = G.buildDrawing(r);
  assert.ok(hasPt(G.flatten(m.outer), 6.005, 0));
  assert.ok(m.notes.some((n) => /chamfer/i.test(n.text) && /f/.test(n.text)));
  const r2 = JSON.parse(JSON.stringify(rec('308_win')));
  r2.cartridge.caseHead.beta = 90;
  m = G.buildDrawing(r2);
  assert.ok(hasPt(G.flatten(m.outer), 6.005, 0));
});

test('300 Win. Mag.: belt follows R3/2 to z = E then steps in to P1/2', () => {
  const m = G.buildDrawing(rec('300_win_mag'));
  const p = G.flatten(m.outer);
  const rampDz = (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  assert.ok(hasPt(p, 6.755, 1.27 + 0.94 + rampDz, 1e-6));
  assert.ok(hasPt(p, 6.755, 5.59));
  assert.ok(hasPt(p, 6.515, 5.59));
  near(m.features.beltRampEnd, 1.27 + 0.94 + rampDz);
});

test('7 x 65 R: no groove published, steps in at z = R and says what is missing', () => {
  const m = G.buildDrawing(rec('7_x_65_r'));
  const p = G.flatten(m.outer);
  assert.ok(hasPt(p, 6.66, 1.4));
  assert.ok(hasPt(p, 5.945, 1.4));
  const n = m.notes.find((x) => /groove/i.test(x.text));
  assert.ok(n, 'groove note');
  assert.deepEqual(n.missing, ['E', 'E1', 'eMin']);
  assert.match(n.text, /E, E1 and e min/);
});

test('22 Long Rifle: rimfire half-round, radius 0.545, outermost r = R1/2', () => {
  const m = G.buildDrawing(rec('22_long_rifle'));
  const arc = m.outer.items.find((i) => i.arc);
  assert.ok(arc);
  near(arc.arc.rr, 0.545);
  near(arc.arc.c.r + arc.arc.rr, 3.53);
  const p = G.flatten(m.outer);
  near(Math.max(...p.filter((q) => q.z < 1.1).map((q) => q.r)), 3.53, 1e-9);
  assert.ok(!m.notes.some((n) => /groove/i.test(n.text)));
});

// ---- 4.2 body, shoulder, neck, fillets ------------------------------------------------
test('308 Win.: bottleneck points', () => {
  const m = G.buildDrawing(rec('308_win'));
  const key = m.features.keyPoints;
  assert.deepEqual(key.bodyEnd, { r: 5.765, z: 39.62 });
  assert.deepEqual(key.neckStart, { r: 4.36, z: 43.48 });
  assert.deepEqual(key.mouth, { r: 4.36, z: 51.18 });
  assert.equal(m.features.bottleneck, true);
});

test('fillets on 308 Win.: tangent arcs of r1 min 0.76 and r2 3.18', () => {
  const m = G.buildDrawing(rec('308_win'));
  const arcs = m.outer.items.filter((i) => i.arc);
  assert.equal(arcs.length, 2);
  near(arcs[0].arc.rr, 0.76, 1e-9);
  near(arcs[1].arc.rr, 3.18, 1e-9);
});

test('fillet is tangent to both lines (continuous direction)', () => {
  const m = G.buildDrawing(rec('308_win'));
  const items = m.outer.items;
  for (let i = 0; i < items.length; i++) {
    if (!items[i].arc) continue;
    const a = items[i].arc;
    // start/end points lie on the circle and the radius to the start is perpendicular to the previous line
    const prev = items[i - 1];
    const before = items[i - 2];
    const d1 = { r: prev.r - before.r, z: prev.z - before.z };
    const rad = { r: prev.r - a.c.r, z: prev.z - a.c.z };
    near(d1.r * rad.r + d1.z * rad.z, 0, 1e-6, 'tangent at start');
    near(Math.hypot(rad.r, rad.z), a.rr, 1e-9);
  }
});

test('fillet radius is clamped to the adjacent segments', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.cartridge.junctionCone.r2 = 500;
  r.cartridge.junctionCone.r1Min = 500;
  const m = G.buildDrawing(r);
  const flat = G.flatten(m.outer);
  for (const q of flat) assert.ok(Number.isFinite(q.r) && Number.isFinite(q.z));
  const arcs = m.outer.items.filter((i) => i.arc);
  for (const a of arcs) assert.ok(a.arc.rr < 500);
});

test('9 mm Luger: straight case, no shoulder', () => {
  const m = G.buildDrawing(rec('9_mm_luger'));
  assert.equal(m.features.bottleneck, false);
  const p = G.flatten(m.outer);
  assert.ok(hasPt(p, 4.825, 19.15));
  assert.equal(m.outer.items.filter((i) => i.arc).length, 0);
  assert.ok(!m.notes.some((n) => /r1|r2/.test(n.text)));
});

test('17 HMR: bottleneck without radii names r1 min and r2', () => {
  const m = G.buildDrawing(rec('17_hmr'));
  assert.equal(m.features.bottleneck, true);
  assert.equal(shoulderArcs(m).length, 0);
  const texts = m.notes.map((n) => n.text).join(' | ');
  assert.match(texts, /r1 min/);
  assert.match(texts, /r2/);
});

test('338 Lapua: r1 min missing but r2 drawn', () => {
  const m = G.buildDrawing(rec('338_lapua_mag'));
  assert.equal(shoulderArcs(m).length, 1);
  assert.ok(m.notes.some((n) => /r1 min/.test(n.text)));
});

// ---- 4.3 bullet -----------------------------------------------------------------------
test('308 Win. pointy bullet: seating, cylinder end, tangent ogive', () => {
  const b = G.buildDrawing(rec('308_win')).bullet;
  assert.equal(b.shape, 'pointy');
  near(b.s, 7.85);
  near(b.zb, 43.33);
  near(b.Lb, 27.79);
  near(b.zCyl, 54.446, 1e-9);
  near(b.m, 1.27);
  near(b.n, 71.12 - 54.446, 1e-9);
  near(b.rho, 43.9, 0.05);
  // arc: tangent to the cylinder at the start, ends at the tip radius m/2 at z = L6
  const arc = b.exposed.items.find((i) => i.arc).arc;
  near(arc.c.r + arc.rr * Math.cos(arc.a0), 7.85 / 2, 1e-9);
  near(arc.c.z, b.zCyl, 1e-9);
  near(arc.a0, 0, 1e-12);
  const endR = arc.c.r + arc.rr * Math.cos(arc.a1);
  const endZ = arc.c.z + arc.rz * Math.sin(arc.a1);
  near(endR, 0.635, 1e-9);
  near(endZ, 71.12, 1e-9);
});

test('rounded and flat tips', () => {
  near(G.buildDrawing(rec('45_auto')).bullet.m, 0.15 * 11.48);
  near(G.buildDrawing(rec('40_s_w')).bullet.m, 0.55 * 10.17);
  near(G.buildDrawing(rec('44_rem_mag')).bullet.m, 0.6 * 10.97);
  const b = G.buildDrawing(rec('45_auto')).bullet;
  const arc = b.exposed.items.find((i) => i.arc).arc; // quarter ellipse
  near(arc.rr, 11.48 / 2 - b.m / 2, 1e-9);
  near(arc.rz, b.n, 1e-9);
});

test('seating depth and cylinder end by shape and category', () => {
  let b = G.buildDrawing(rec('9_mm_luger')).bullet; // rounded pistol
  near(b.s, 0.4 * 9.03, 1e-9);
  near(b.zCyl, b.zb + 0.65 * b.Lb, 1e-9);
  b = G.buildDrawing(rec('40_s_w')).bullet; // flat pistol
  near(b.s, 0.4 * 10.17, 1e-9);
  near(b.zCyl, b.zb + 0.7 * b.Lb, 1e-9);
  b = G.buildDrawing(rec('44_rem_mag')).bullet; // semi wadcutter
  near(b.s, 0.6 * 10.97, 1e-9);
  near(b.zCyl, b.zb + 0.78 * b.Lb, 1e-9);
  b = G.buildDrawing(rec('22_win_mag_r_f')).bullet; // rounded rimfire -> rifle constants
  near(b.s, 0.8 * 5.7, 1e-9);
  near(b.zCyl, b.zb + 0.55 * b.Lb, 1e-9);
  b = G.buildDrawing(rec('17_hmr')).bullet; // pointy rimfire
  near(b.s, 4.38, 1e-9);
  near(b.zCyl, b.zb + 0.4 * b.Lb, 1e-9);
});

test('heeled case: 22 Long Rifle', () => {
  const m = G.buildDrawing(rec('22_long_rifle'));
  assert.equal(m.features.heeled, true);
  near(m.bullet.exposedR * 2, 5.72, 1e-9);
  near(m.bullet.seatR * 2, 5.72 - 2 * 0.6, 1e-9);
  assert.equal(G.buildDrawing(rec('22_win_mag_r_f')).features.heeled, false);
});

// ---- 4.4 walls, head, pocket ----------------------------------------------------------
test('308 Win. walls and head', () => {
  const m = G.buildDrawing(rec('308_win'));
  near(m.features.tn, 0.435, 1e-9);
  near(m.features.tb, 0.6, 1e-9);
  near(m.features.w, 4.8, 1e-9);
  assert.deepEqual(m.pocket, { d: 5.33, depth: 3.3 });
  const inner = m.inner;
  near(inner[inner.length - 1].r, 3.925, 1e-9);
  near(inner[inner.length - 1].z, 51.18, 1e-9);
});

test('wall formulas', () => {
  // tb = min(max(1.3 tn, 0.6), 0.35 P1/2)
  assert.equal(G.wallThickness({ tn: 1, P1: 12 }).tb, 1.3);
  assert.equal(G.wallThickness({ tn: 0.1, P1: 12 }).tb, 0.6);
  assert.equal(G.wallThickness({ tn: 1, P1: 2 }).tb, 0.35);
});

test('pocket sizes by primer type, none for rimfire', () => {
  assert.deepEqual(G.pocketFor('sp'), { d: 4.45, depth: 3.04 });
  assert.deepEqual(G.pocketFor('spm'), { d: 4.45, depth: 3.04 });
  assert.deepEqual(G.pocketFor('sr'), { d: 4.45, depth: 3.04 });
  assert.deepEqual(G.pocketFor('lp'), { d: 5.33, depth: 3.04 });
  assert.deepEqual(G.pocketFor('lpm'), { d: 5.33, depth: 3.04 });
  assert.deepEqual(G.pocketFor('lr'), { d: 5.33, depth: 3.3 });
  assert.deepEqual(G.pocketFor('lrm'), { d: 5.33, depth: 3.3 });
  assert.equal(G.pocketFor('rimfire'), null);
  assert.equal(G.buildDrawing(rec('17_hmr')).pocket, null);
  assert.deepEqual(G.buildDrawing(rec('223_rem')).pocket, { d: 4.45, depth: 3.04 });
});

test('w includes groove (E + tb), belt ramp end (+ tb) and pocket depth', () => {
  const m = G.buildDrawing(rec('300_win_mag')); // belted: ramp end + tb, pocket 3.3 + 1.5 = 4.8
  near(m.features.w, Math.max(4.8, m.features.beltRampEnd + m.features.tb), 1e-9);
  const m2 = G.buildDrawing(rec('223_rem')); // sr: pocket 3.04+1.5=4.54 ; E+tb = 3.13+0.6
  near(m2.features.w, 4.54, 1e-9);
  const m3 = G.buildDrawing(rec('22_long_rifle')); // no pocket, no groove: max(2.5, 0.25*5.74/2)
  near(m3.features.w, 2.5, 1e-9);
});

test('straight case wall blends from tb to tn at the bullet base', () => {
  const m = G.buildDrawing(rec('9_mm_luger'));
  const inner = m.inner;
  near(inner[0].z, m.features.w, 1e-9);
  const atBase = inner.find((p) => Math.abs(p.z - m.bullet.zb) < 1e-9);
  assert.ok(atBase);
  near(atBase.r, 9.65 / 2 - m.features.tn, 1e-9);
  near(inner[inner.length - 1].r, 9.65 / 2 - m.features.tn, 1e-9);
});

// ---- 4.5 all records ------------------------------------------------------------------
test('all 25 records build with finite coordinates', () => {
  for (const r of data) {
    const m = G.buildDrawing(r);
    assert.equal(m.ok, true, r.key);
    const pts = [].concat(G.flatten(m.outer), m.inner, G.flatten(m.bullet.exposed), G.flatten(m.bullet.seated), G.flatten(m.section));
    for (const q of pts) assert.ok(Number.isFinite(q.r) && Number.isFinite(q.z), r.key);
    assert.ok(m.bbox.zMax >= r.cartridge.lengths.L6 - 1e-9, r.key);
    near(m.bbox.zMin, 0, 1e-12);
    assert.ok(m.features.w < r.cartridge.lengths.L3, r.key);
  }
});

test('the bullet never overlaps the case wall; inner stays inside outer', () => {
  for (const r of data) {
    const m = G.buildDrawing(r);
    const o = G.flatten(m.outer);
    const outerAt = (z) => G.interp(o.filter((q) => q.z >= 0), z);
    for (const q of m.inner) {
      assert.ok(q.r < outerAt(q.z) + 1e-9, `${r.key} inner<outer at z=${q.z}`);
      assert.ok(q.r > 0, r.key);
    }
    // seated part radius <= inner radius at the mouth and base
    const last = m.inner[m.inner.length - 1];
    assert.ok(m.bullet.seatR <= last.r + 1e-9, `${r.key} seat ${m.bullet.seatR} vs ${last.r}`);
  }
});

test('notes appear only for records whose values are missing', () => {
  const noted = {};
  for (const r of data) {
    const m = G.buildDrawing(r);
    if (m.notes.length) noted[r.key] = m.notes.map((n) => n.feature);
  }
  assert.deepEqual(Object.keys(noted).sort(), [
    '17_hmr', '338_lapua_mag', '38_special', '357_magnum', '44_rem_mag', '7_x_65_r', '9_3_x_74_r',
  ].sort());
  assert.ok(!noted['308_win']);
});

test('interp', () => {
  const pts = [{ r: 1, z: 0 }, { r: 3, z: 10 }];
  near(G.interp(pts, 5), 2);
});

test('interp clamps outside the polyline range', () => {
  const pts = [{ r: 1, z: 2 }, { r: 3, z: 10 }];
  near(G.interp(pts, 0), 1);
  near(G.interp(pts, 20), 3);
});

test('belted case: the inner wall starts at body radius minus tb, not at the belt', () => {
  const m = G.buildDrawing(rec('300_win_mag'));
  near(m.inner[0].r, 13.03 / 2 - m.features.tb, 1e-9);
  assert.ok(m.inner[0].z < m.features.bodyStart); // the solid head ends before the body starts
  // wall thickness is constant along the body up to the shoulder
  near(m.inner[1].r, 12.42 / 2 - m.features.tb, 1e-9);
});
