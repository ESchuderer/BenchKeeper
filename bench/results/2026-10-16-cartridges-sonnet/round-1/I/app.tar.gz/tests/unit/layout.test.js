'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const L = require('../../js/layout.js');
const { data } = require('../../js/data.js');
const rec = (k) => data.find((r) => r.key === k);
const lay = (k) => L.layoutDrawing(rec(k), G.buildDrawing(rec(k)));
const texts = (l) => l.labels.map((x) => x.text);

test('308 Win. has all dimension labels with symbol and value', () => {
  const t = texts(lay('308_win'));
  for (const s of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(t.includes(s), `missing label ${s} in ${t.join(' | ')}`);
  }
  assert.equal(t.length, 13);
});

test('object angle label: 6,5 x 55 SE', () => {
  assert.ok(texts(lay('6_5_x_55_se')).includes('α 50°35\'2"'));
});

test('9 mm Luger has no P2, H1, L1, L2 or alpha label', () => {
  const t = texts(lay('9_mm_luger'));
  for (const s of t) assert.doesNotMatch(s, /^(P2|H1|L1|L2|α)\b/);
  for (const s of ['L3 19.15', 'L6 29.69', 'R1 9.96', 'R 1.27', 'P1 9.93', 'H2 9.65', 'G1 9.03', 'E1 8.79']) assert.ok(t.includes(s), s);
});

test('17 HMR: bottleneck rimfire has its dimensions, no E1', () => {
  const t = texts(lay('17_hmr'));
  for (const s of ['L1 22.2', 'L2 23.54', 'P2 6.15', 'H1 4.9', 'α 50°']) assert.ok(t.includes(s), s);
  assert.ok(!t.some((x) => /^E1/.test(x)));
});

test('7 x 65 R: no E1 label because the groove is not published', () => {
  assert.ok(!texts(lay('7_x_65_r')).some((x) => /^E1/.test(x)));
});

test('viewBox is in mm with the scale quantised to a ratio at A4 print width', () => {
  for (const r of data) {
    const l = L.layoutDrawing(r, G.buildDrawing(r));
    assert.ok(l.vbW >= 90 - 1e-9, r.key);
    assert.ok(Math.abs(190 / l.vbW - l.scale) < 1e-9, `${r.key} scale ${l.scale} vs ${190 / l.vbW}`);
    assert.equal(l.scale, Math.round(l.scale * 10) / 10);
    // z maps 1:1 to user units
    const tip = l.origin.x + r.cartridge.lengths.L6;
    assert.ok(tip <= l.vbW, r.key);
  }
});

test('fonts: label font size is vbW / 34 so 10 CSS px at 360 px', () => {
  const l = lay('308_win');
  assert.ok(Math.abs(l.fs - l.vbW / 34) < 1e-9);
});

const overlap = (a, b, m = 0) => a.x < b.x + b.w + m && b.x < a.x + a.w + m && a.y < b.y + b.h + m && b.y < a.y + a.h + m;
function segHitsRect(s, r) {
  // Liang-Barsky
  let t0 = 0, t1 = 1;
  const dx = s.x2 - s.x1, dy = s.y2 - s.y1;
  const p = [-dx, dx, -dy, dy];
  const q = [s.x1 - r.x, r.x + r.w - s.x1, s.y1 - r.y, r.y + r.h - s.y1];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; } else {
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
  }
  return true;
}

test('labels do not collide: all 25 cartridges', () => {
  for (const r of data) {
    const l = L.layoutDrawing(r, G.buildDrawing(r));
    const boxes = l.labels.map((x) => ({ id: x.text, ...x.bbox }));
    for (let i = 0; i < boxes.length; i++) {
      const a = boxes[i];
      assert.ok(a.x >= 0 && a.y >= 0 && a.x + a.w <= l.vbW && a.y + a.h <= l.vbH, `${r.key} ${a.id} inside viewBox`);
      for (let j = i + 1; j < boxes.length; j++) assert.ok(!overlap(a, boxes[j]), `${r.key}: ${a.id} overlaps ${boxes[j].id}`);
      for (const s of l.outline) assert.ok(!segHitsRect(s, a), `${r.key}: ${a.id} touches the outline`);
      assert.ok(!overlap(a, l.title.rect), `${r.key}: ${a.id} overlaps the title block`);
    }
    // title block inside the viewBox
    const t = l.title.rect;
    assert.ok(t.x >= 0 && t.y >= 0 && t.x + t.w <= l.vbW + 1e-9 && t.y + t.h <= l.vbH + 1e-9, r.key);
    // outline inside the viewBox
    for (const s of l.outline) {
      for (const [x, y] of [[s.x1, s.y1], [s.x2, s.y2]]) assert.ok(x >= 0 && x <= l.vbW && y >= 0 && y <= l.vbH, `${r.key} outline inside`);
    }
  }
});

test('labels keep clear of other dimension, extension and leader lines', () => {
  for (const r of data) {
    const l = L.layoutDrawing(r, G.buildDrawing(r));
    for (const lab of l.labels) {
      for (const s of l.lines) {
        if (s.owner === lab.id) continue;
        assert.ok(!segHitsRect(s, lab.bbox), `${r.key}: label ${lab.text} touches a ${s.cls} line of ${s.owner}`);
      }
    }
  }
});

test('title block content', () => {
  const l = lay('308_win');
  const all = l.title.texts.map((x) => x.text);
  assert.ok(all.includes('308 Win.'));
  assert.ok(all.includes('C.I.P. table I'));
  assert.ok(all.includes('Revised 2008-09-23'));
  assert.ok(all.includes('Dimensions in mm'));
  assert.ok(all.some((x) => /^Scale \d\.\d : 1/.test(x)));
  assert.equal(l.title.scaleBar.len, 10);
});

test('drawing sits on a mm grid: head face to mouth equals L3', () => {
  const l = lay('308_win');
  const model = G.buildDrawing(rec('308_win'));
  const mouthX = l.origin.x + model.features.keyPoints.mouth.z;
  assert.ok(Math.abs(mouthX - l.origin.x - 51.18) < 1e-9);
});

test('title block texts stay inside their cells for all 25 records', () => {
  for (const r of data) {
    const l = L.layoutDrawing(r, G.buildDrawing(r));
    const t = l.title.rect;
    const xs = l.title.dividers.filter((d) => d.x1 === d.x2).map((d) => d.x1).concat([t.x + t.w]).sort((a, b) => a - b);
    for (const x of l.title.texts) {
      const w = L.textWidth(x.text, x.size);
      const right = xs.find((e) => e > x.x + 1e-9);
      assert.ok(x.x + w <= right + 1e-9, `${r.key}: "${x.text}" ends at ${(x.x + w).toFixed(2)} but its cell ends at ${right.toFixed(2)}`);
      assert.ok(x.y <= t.y + t.h && x.y >= t.y, r.key);
    }
    const sb = l.title.scaleBar;
    assert.ok(sb.labelX + L.textWidth('10 mm', l.fs * 0.9) <= xs[0] + 1e-9, r.key + ' scale bar label fits in the first cell');
  }
});

function arrowBox(a) {
  const s = a.size, w = 0.3 * s;
  const nx = -a.uy, ny = a.ux;
  const bx = a.x - a.ux * s, by = a.y - a.uy * s;
  const xs = [a.x, bx + nx * w, bx - nx * w], ys = [a.y, by + ny * w, by - ny * w];
  return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
}

test('labels never touch an arrowhead (including their own dimension line)', () => {
  for (const r of data) {
    const l = L.layoutDrawing(r, G.buildDrawing(r));
    for (const lab of l.labels) {
      for (const a of l.arrows) assert.ok(!overlap(lab.bbox, arrowBox(a)), `${r.key}: label ${lab.text} touches an arrowhead`);
    }
  }
});

test('arrowheads of different dimensions do not pile onto each other', () => {
  for (const r of data) {
    const l = L.layoutDrawing(r, G.buildDrawing(r));
    const boxes = l.arrows.map(arrowBox);
    for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        assert.ok(!overlap(boxes[i], boxes[j]), `${r.key}: arrowheads ${i} and ${j} overlap`);
      }
    }
  }
});

test('title block text is at least the label size (legible on a phone)', () => {
  for (const r of data) {
    const l = L.layoutDrawing(r, G.buildDrawing(r));
    for (const x of l.title.texts) assert.ok(x.size >= l.fs - 1e-9, `${r.key}: "${x.text}" size ${x.size} < ${l.fs}`);
    assert.ok(l.title.scaleBar.labelSize >= l.fs - 1e-9, r.key);
  }
});
