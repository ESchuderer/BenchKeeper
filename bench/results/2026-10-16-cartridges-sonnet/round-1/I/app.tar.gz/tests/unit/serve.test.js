'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../../tools/serve.js');

test('dev server serves only the app and survives hostile requests', async () => {
  const server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const status = async (p) => (await fetch(base + p)).status;
  assert.equal(await status('/'), 200);
  assert.equal(await status('/js/app.js'), 200);
  assert.equal(await status('/css/app.css'), 200);
  for (const p of ['/package.json', '/.git/config', '/TOOLS/serve.js', '/tests/fixtures/cartridges.jsonl', '/js/../package.json', '/%2e%2e/etc/passwd', '/%00', '/js/%00']) {
    assert.ok([400, 404].includes(await status(p)), p);
  }
  assert.equal(await status('/%E0%A4%A'), 400);
  assert.equal(await status('/'), 200); // still alive
  server.close();
});
