#!/usr/bin/env node
'use strict';
// Dev tool: renders every drawing to test-output/drawings/<key>[-dark].png for visual inspection.
const path = require('node:path');
const fs = require('node:fs');
const { launch } = require('../tests/e2e/browser.js');
const D = require('../js/drawing.js');
const { data } = require('../js/data.js');

const root = path.join(__dirname, '..');
const outDir = path.join(root, 'test-output', 'drawings');
fs.mkdirSync(outDir, { recursive: true });
const css = ['app.css', 'drawing.css'].map((f) => fs.readFileSync(path.join(root, 'css', f), 'utf8')).join('\n');
const only = process.argv.slice(2);

(async () => {
  const browser = await launch();
  for (const scheme of ['light', 'dark']) {
    const ctx = await browser.newContext({ colorScheme: scheme, viewport: { width: 1000, height: 800 }, deviceScaleFactor: 1.5 });
    const page = await ctx.newPage();
    for (const r of data) {
      if (only.length && !only.includes(r.key)) continue;
      const { svg } = D.renderDrawing(r);
      await page.setContent(`<!doctype html><style>${css} body{margin:0;background:var(--bg);padding:10px}</style><body><div style="width:960px">${svg}</div>`);
      await page.screenshot({ path: path.join(outDir, `${r.key}${scheme === 'dark' ? '-dark' : ''}.png`), fullPage: true });
    }
    await ctx.close();
  }
  await browser.close();
  console.log('rendered to ' + outDir);
})();
