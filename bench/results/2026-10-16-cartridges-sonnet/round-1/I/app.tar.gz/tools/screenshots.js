#!/usr/bin/env node
'use strict';
// Dev tool: screenshots of the app (list, detail) for desktop/phone, light/dark -> test-output/screens/
const fs = require('node:fs');
const path = require('node:path');
const { launch, indexUrl } = require('../tests/e2e/helpers.js');

const out = path.join(__dirname, '..', 'test-output', 'screens');
fs.mkdirSync(out, { recursive: true });
const key = process.argv[2] || '308_win';
(async () => {
  const browser = await launch();
  for (const [name, vp] of [['desktop', { width: 1280, height: 900 }], ['phone', { width: 360, height: 740 }]]) {
    for (const scheme of ['light', 'dark']) {
      const ctx = await browser.newContext({ viewport: vp, colorScheme: scheme, deviceScaleFactor: 1 });
      const page = await ctx.newPage();
      await page.goto(indexUrl);
      await page.screenshot({ path: path.join(out, `list-${name}-${scheme}.png`), fullPage: true });
      await page.goto(indexUrl + '#/cartridge/' + key);
      await page.screenshot({ path: path.join(out, `detail-${name}-${scheme}.png`), fullPage: true });
      await ctx.close();
    }
  }
  await browser.close();
})();
