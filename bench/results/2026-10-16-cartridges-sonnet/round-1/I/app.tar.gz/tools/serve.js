#!/usr/bin/env node
'use strict';
// Dev tool: a minimal static file server for the project folder (any static server works; the app has no server code).
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml' };

// Only the app itself is served: index.html, css/ and js/.
const allowed = /^(index\.html|css\/[\w.-]+|js\/[\w.-]+)$/;

function createServer() {
  return http.createServer((req, res) => {
    let rel;
    try {
      rel = decodeURIComponent(req.url.split('?')[0]).replace(/^\//, '') || 'index.html';
    } catch (e) {
      res.writeHead(400).end('bad request');
      return;
    }
    if (!allowed.test(rel)) {
      res.writeHead(404).end('not found');
      return;
    }
    fs.readFile(path.join(root, rel), (err, buf) => {
      if (err) res.writeHead(404).end('not found');
      else res.writeHead(200, { 'content-type': types[path.extname(rel)] || 'application/octet-stream' }).end(buf);
    });
  });
}

if (require.main === module) {
  const port = Number(process.env.PORT) || 8080;
  createServer().listen(port, '127.0.0.1', () => console.log(`http://localhost:${port}/`));
}
module.exports = { createServer };
