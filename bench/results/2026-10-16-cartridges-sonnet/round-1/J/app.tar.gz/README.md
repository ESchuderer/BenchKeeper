# C.I.P. cartridge reference

A static reference database of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on the
cartridge database of [OpenBallistics](https://openreloading.github.io/OpenBallistics/): a searchable list, a
detail view per cartridge with every cartridge and chamber value, and a generated true-to-scale 2D drawing
(outside view above the axis, hatched section below, dimension lines, labels, title block). A detail view prints
as one A4 sheet.

## Use

Open `index.html` directly in a browser (works from `file://`), or serve the folder with any static file server.
No build step, no framework, no network requests. Each cartridge has its own address, for example
`index.html#/cartridge/308_win`.

## Layout

| Path | Purpose |
| --- | --- |
| `index.html`, `css/app.css`, `css/print.css` | page, screen styles (light/dark), print styles (A4, black on white) |
| `js/data.js` | the 25 records, verbatim (OpenBallistics, MIT, commit e83db43) |
| `js/format.js`, `js/tables.js`, `js/search.js` | number/angle/tolerance formatting, value tables, filtering and routes |
| `js/geometry.js` | cartridge outline, shoulder, bullet, section walls from the published values (`[r, z]` points) |
| `js/layout.js`, `js/drawing.js` | dimension lines, label placement, SVG string, title block |
| `js/dom.js`, `js/views.js`, `js/app.js` | DOM helper, views, hash router |
| `openspec/` | specs, design and tasks of the change that built this |

Scripts are classic `<script>` files (not ES modules) because Chromium blocks module scripts on `file://`. Each
file also exports itself under Node so the same code is unit-tested.

## Tests (development only)

```sh
npm install
npm test                 # unit tests (node:test): data, formatting, tables, search, geometry, layout, SVG
npm run test:e2e         # browser tests (Playwright, Chromium) over file://, incl. print-to-PDF page counts
CIP_E2E_SERVER=1 npm run test:e2e   # the same over a local static server
```

Playwright needs a Chromium: `npx playwright install chromium`. In a container without the system libraries
Chromium needs, unpack them into a directory you own and point `CIP_BROWSER_LIBS` (colon-separated
`LD_LIBRARY_PATH` entries) at it; on a machine with a normal Chromium nothing extra is needed.

## Drawing rules and assumptions

The drawing follows the brief's geometry rules; where they leave room the choices are listed in
`openspec/changes/archive/2026-10-16-cartridge-reference-app/design.md` (section D6). If a value a feature needs is missing, the
feature is left out and a note under the drawing names the missing value; no number is ever invented.
