/* Router: maps the location hash to a view. */
(function (g) {
  'use strict';
  var CIP = g.CIP, S = CIP.search, V = CIP.views;
  var main = document.getElementById('main');
  var foot = document.querySelector('.site-foot');
  var firstRender = true;

  function byKey(key) {
    for (var i = 0; i < CIP.data.length; i++) if (CIP.data[i].key === key) return CIP.data[i];
    return null;
  }

  function render() {
    if (CIP.drawingStop) CIP.drawingStop();
    var route = S.parseRoute(location.hash);
    var result, title = 'C.I.P. cartridges';
    if (route.name === 'list') {
      result = V.renderList(main, CIP.data, { q: route.q, family: route.family }, function (state) {
        history.replaceState(null, '', S.listHash(state));
      });
    } else if (route.name === 'detail' && byKey(route.key)) {
      var rec = byKey(route.key);
      result = V.renderDetail(main, rec, CIP.drawingSection ? CIP.drawingSection(rec) : null);
      title = rec.name + ' – C.I.P. cartridges';
    } else {
      result = V.renderNotFound(main);
      title = 'Not found – C.I.P. cartridges';
    }
    document.title = title;
    foot.textContent = result.footer;
    if (!firstRender) { window.scrollTo(0, 0); result.heading.focus({ preventScroll: true }); }
    firstRender = false;
  }

  window.addEventListener('hashchange', render);
  render();
})(typeof globalThis !== 'undefined' ? globalThis : this);
