/* Minimal DOM builder: h('a', {href: '#/'}, 'text', childNode). Text is always inserted as text nodes. */
(function (g) {
  'use strict';
  var CIP = g.CIP = g.CIP || {};

  function h(tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === false || v === null || v === undefined) return;
        if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (k === 'class') el.className = v;
        else el.setAttribute(k, v === true ? '' : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  }

  function append(el, child) {
    if (child === null || child === undefined || child === false) return;
    if (Array.isArray(child)) { child.forEach(function (c) { append(el, c); }); return; }
    el.appendChild(child && child.nodeType ? child : document.createTextNode(String(child)));
  }

  CIP.dom = { h: h };
})(typeof globalThis !== 'undefined' ? globalThis : this);
