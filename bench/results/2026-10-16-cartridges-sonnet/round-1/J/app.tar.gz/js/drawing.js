/* Serialises a laid-out drawing to an inline SVG string (1 user unit = 1 mm) and builds the detail view's
   drawing section. Text is escaped; styling comes from CSS classes so the drawing follows theme and print. */
(function (g) {
  'use strict';
  var CIP = g.CIP = g.CIP || {};
  var isNode = typeof module === 'object' && module.exports;
  var G = isNode ? require('./geometry.js') : CIP.geometry;
  var L = isNode ? require('./layout.js') : CIP.layout;

  var CONST = {
    FONT: L.CONST.FONT,
    PRINT_WIDTH_MM: 186,   // = the drawing's width in css/print.css (A4 portrait, 12 mm margins)
    MIN_ASPECT: 1.7,       // viewBox width : height at least; keeps small cartridges from printing too tall
    MARGIN: 3,
    TB_FONT: 3, TB_NAME_FONT: 4, TB_MIN_W: 62
  };

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /** Rounds to 3 decimals and drops trailing zeros: 51.18 -> "51.18", 4.0000001 -> "4". */
  function n(x) {
    var r = Math.round(x * 1000) / 1000;
    return String(r === 0 ? 0 : r);
  }

  function pathData(pts, close) {
    return pts.map(function (p, i) { return (i ? 'L' : 'M') + n(p[0]) + ' ' + n(p[1]); }).join('') + (close ? 'Z' : '');
  }

  function formatScale(s) {
    var r;
    if (s >= 1) { r = Math.round(s * 10) / 10; return n(r) + ':1'; }
    r = Math.round(10 / s) / 10;
    return '1:' + n(r);
  }

  function renderItem(it, key) {
    switch (it.type) {
      case 'polyline': return '<path class="' + it.cls + '" d="' + pathData(it.pts, false) + '"/>';
      case 'polygon':
        if (it.cls === 'cut') return '<path class="cut" fill="url(#hatch-' + esc(key) + ')" d="' + pathData(it.pts, true) + '"/>';
        return '<path class="' + it.cls + '" fill="url(#hatchb-' + esc(key) + ')" d="' + pathData(it.pts, true) + '"/>';
      case 'line': return '<line class="' + it.cls + '" x1="' + n(it.x1) + '" y1="' + n(it.y1) + '" x2="' + n(it.x2) + '" y2="' + n(it.y2) + '"/>';
      case 'arrow': return '<path class="arrow" d="' + pathData(it.pts, true) + '"/>';
      case 'label': return '<text class="dim-label" x="' + n(it.x) + '" y="' + n(it.y) + '">' + esc(it.text) + '</text>';
      default: return '';
    }
  }

  function renderDrawing(rec) {
    var model = G.buildModel(rec);
    if (!model.ok) return { svg: '', notes: model.notes.slice(), viewBox: null, labels: [] };
    var scene = L.layoutScene(model);
    var M = CONST.MARGIN, b = scene.bbox;

    /* title block below the drawing: name on top, then two columns of two entries */
    var T = CONST.TB_FONT, TN = CONST.TB_NAME_FONT, cw = L.CONST.CHAR_W, pad = 3, rowH = T + 1.6;
    var name = String(rec.name || rec.key || '');
    var cells = [[rec.tab ? 'C.I.P. table ' + rec.tab : '', rec.revised ? 'Revised ' + rec.revised : ''], ['Dimensions in mm', 'Scale 00.0:1']];
    var col1 = Math.max(cells[0][0].length, cells[1][0].length) * T * cw + pad;
    var col2 = Math.max(cells[0][1].length, cells[1][1].length) * T * cw + pad;
    var tbW = Math.max(CONST.TB_MIN_W, 2 * pad + col1 + col2, name.length * TN * cw + 2 * pad);
    var tbH = pad + TN + 1.2 + 2 * rowH + pad * 0.5;
    var contentW = Math.max(b.w, tbW), width = contentW + 2 * M;
    var height = b.h + 2 * M + 4 + tbH;
    if (width / height < CONST.MIN_ASPECT) width = CONST.MIN_ASPECT * height;
    var vb = { x: b.x + b.w / 2 - width / 2, y: b.y - M, w: width, h: height };
    var tbX = vb.x + vb.w - M - tbW, tbY = b.y + b.h + 4;

    var scale = CONST.PRINT_WIDTH_MM / vb.w;
    var scaleText = 'Scale ' + formatScale(scale);
    var key = String(rec.key || 'x');

    var x1 = tbX + pad, x2 = tbX + pad + col1 + (tbW - 2 * pad - col1 - col2);
    var y1 = tbY + pad + TN * 0.8, yr1 = tbY + pad + TN + 1.2 + rowH * 0.8, yr2 = yr1 + rowH;
    var tx = function (cls, x, y, t) { return '<text class="' + cls + '" x="' + n(x) + '" y="' + n(y) + '">' + esc(t) + '</text>'; };
    var tb = '<g class="titleblock">' +
      '<rect class="tb-frame" x="' + n(tbX) + '" y="' + n(tbY) + '" width="' + n(tbW) + '" height="' + n(tbH) + '"/>' +
      '<line class="tb-rule" x1="' + n(tbX) + '" y1="' + n(tbY + pad + TN + 0.6) + '" x2="' + n(tbX + tbW) + '" y2="' + n(tbY + pad + TN + 0.6) + '"/>' +
      tx('tb-name', x1, y1, name) +
      (cells[0][0] ? tx('tb-line', x1, yr1, cells[0][0]) : '') + (cells[0][1] ? tx('tb-line', x2, yr1, cells[0][1]) : '') +
      tx('tb-line', x1, yr2, cells[1][0]) +
      tx('tb-line scale-print', x2, yr2, scaleText) + tx('tb-line scale-screen', x2, yr2, scaleText) + '</g>';

    var body = scene.items.map(function (it) { return renderItem(it, key); }).join('');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img" aria-label="' + esc(name + ' drawing') + '"' +
      ' viewBox="' + n(vb.x) + ' ' + n(vb.y) + ' ' + n(vb.w) + ' ' + n(vb.h) + '" preserveAspectRatio="xMidYMid meet"' +
      ' data-vbw="' + n(vb.w) + '">' +
      '<defs>' +
      '<pattern id="hatch-' + esc(key) + '" patternUnits="userSpaceOnUse" width="1" height="1" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="1"/></pattern>' +
      '<pattern id="hatchb-' + esc(key) + '" patternUnits="userSpaceOnUse" width="1.6" height="1.6" patternTransform="rotate(-45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="1.6"/></pattern>' +
      '</defs>' + body + tb + '</svg>';

    var finite = [vb.x, vb.y, vb.w, vb.h].every(isFinite) && vb.w > 0 && vb.h > 0;
    if (!finite) return { svg: '', notes: model.notes.concat(['Drawing not available: the values do not describe a drawable cartridge.']), viewBox: null, labels: [] };
    return { svg: svg, notes: model.notes.slice(), viewBox: vb, labels: scene.labels, scene: scene, model: model, printScale: scale };
  }

  var api = { renderDrawing: renderDrawing, formatScale: formatScale, CONST: CONST };
  CIP.drawing = api;
  if (isNode) module.exports = api;

  /* ---------- DOM section (browser only) ---------- */

  if (typeof document !== 'undefined' && CIP.dom) {
    var h = CIP.dom.h;
    var observer = null;

    var watchScale = function (svg, vbW) {
      if (observer) { observer.disconnect(); observer = null; }
      if (typeof ResizeObserver === 'undefined') return;
      var text = svg.querySelector('.scale-screen');
      observer = new ResizeObserver(function () {
        var px = svg.getBoundingClientRect().width;
        if (px > 0) text.textContent = 'Scale ' + formatScale((px * 25.4 / 96) / vbW);
      });
      observer.observe(svg);
    };

    CIP.drawingStop = function () { if (observer) { observer.disconnect(); observer = null; } };

    CIP.drawingSection = function (rec) {
      var d = renderDrawing(rec);
      var box = h('div', { class: 'drawing' });
      if (d.svg) box.insertAdjacentHTML('afterbegin', d.svg);
      var notes = d.notes.length
        ? h('div', { class: 'drawing-notes' }, h('h3', null, 'Drawing notes'),
          h('ul', null, d.notes.map(function (t) { return h('li', null, t); })))
        : null;
      var section = h('section', { class: 'drawing-section' }, h('h2', null, 'Drawing'), box, notes);
      var svg = box.querySelector('svg');
      if (svg) watchScale(svg, d.viewBox.w);
      return section;
    };
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
