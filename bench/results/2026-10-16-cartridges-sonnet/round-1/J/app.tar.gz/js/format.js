/* Number, angle, tolerance, symbol and unit formatting. Pure functions. */
(function (g) {
  'use strict';
  var CIP = g.CIP = g.CIP || {};

  var ANGLE_FIELDS = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };

  function isNumber(v) { return typeof v === 'number' && isFinite(v); }

  /** 4150.0 -> "4150", 51.18 -> "51.18" (JS prints the shortest exact decimal). */
  function formatNumber(n) { return String(n); }

  function isAngleField(name) { return Object.prototype.hasOwnProperty.call(ANGLE_FIELDS, name); }

  /** Angle (degrees or {degrees, minutes, seconds}) -> decimal degrees, undefined if not an angle. */
  function toDegrees(a) {
    if (isNumber(a)) return a;
    if (a && typeof a === 'object' && isNumber(a.degrees)) {
      return a.degrees + (isNumber(a.minutes) ? a.minutes : 0) / 60 + (isNumber(a.seconds) ? a.seconds : 0) / 3600;
    }
    return undefined;
  }

  function formatAngle(a) {
    if (isNumber(a)) return formatNumber(a) + '°';
    return formatNumber(a.degrees) + '°' + formatNumber(isNumber(a.minutes) ? a.minutes : 0) + "'" +
      formatNumber(isNumber(a.seconds) ? a.seconds : 0) + '"';
  }

  function formatTolerance(t) { return (t > 0 ? '+' : '') + formatNumber(t); }

  function symbolFor(field) { return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field; }

  function unitFor(field) {
    if (isAngleField(field)) return '°';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  /** The text of a Value cell: the value, then its tolerance (if any) beside it. */
  function formatCell(field, value, tol) {
    var text = isAngleField(field) ? formatAngle(value) : formatNumber(value);
    return tol === undefined ? text : text + ' ' + formatTolerance(tol);
  }

  var api = {
    formatNumber: formatNumber, formatAngle: formatAngle, toDegrees: toDegrees, formatTolerance: formatTolerance,
    isAngleField: isAngleField, symbolFor: symbolFor, unitFor: unitFor, formatCell: formatCell, isNumber: isNumber
  };
  CIP.format = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
