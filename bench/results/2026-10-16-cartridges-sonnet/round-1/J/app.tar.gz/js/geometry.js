/* Cartridge geometry from a record's published values.
   All points are [r, z] (radius, axial position from the head face), as in the brief's rules.
   The renderer maps x = z and y = -r (outside view) / +r (section).
   Nothing here invents a number: if a value a rule needs is missing the feature is left out and a note says which. */
(function (g) {
  'use strict';
  var CIP = g.CIP = g.CIP || {};
  var F = (typeof module === 'object' && module.exports) ? require('./format.js') : CIP.format;

  var DEG = Math.PI / 180;
  var EPS = 1e-9;
  var HEEL_TOLERANCE = 0.015;
  var HALF_ROUND_SEGMENTS = 18;
  var OGIVE_SEGMENTS = 40;
  var ELLIPSE_SEGMENTS = 32;
  var FILLET_STEP = 3 * DEG;

  var POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  /* ---------- small helpers ---------- */

  function num(v) { return typeof v === 'number' && isFinite(v) ? v : undefined; }
  function pos(v) { return num(v) > 0 ? v : undefined; } // a dimension must be a positive number
  function has(v) { return v !== undefined; }
  function dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }

  function list(items) {
    if (items.length <= 1) return items.join('');
    return items.slice(0, -1).join(', ') + ' and ' + items[items.length - 1];
  }

  function push(pts, p) {
    var last = pts[pts.length - 1];
    if (!last || Math.abs(last[0] - p[0]) > EPS || Math.abs(last[1] - p[1]) > EPS) pts.push([p[0], p[1]]);
  }

  /** Radius of a z-monotonic polyline at z (linear interpolation), undefined outside. */
  function radiusAt(poly, z) {
    for (var i = 1; i < poly.length; i++) {
      var a = poly[i - 1], b = poly[i];
      if (z >= a[1] - EPS && z <= b[1] + EPS) {
        return b[1] - a[1] > EPS ? a[0] + (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]) : Math.min(a[0], b[0]);
      }
    }
    return undefined;
  }

  /** Copy of poly with a vertex inserted where it crosses z (if it does strictly inside a segment). */
  function insertAtZ(poly, z) {
    var out = [];
    for (var i = 0; i < poly.length; i++) {
      if (i > 0) {
        var a = poly[i - 1], b = poly[i];
        if (a[1] < z - EPS && b[1] > z + EPS) out.push([a[0] + (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]), z]);
      }
      out.push(poly[i]);
    }
    return out;
  }

  /** Part of poly with z >= zc, starting on zc (interpolated if a segment crosses it). */
  function clipAbove(poly, zc) {
    var out = [];
    for (var i = 0; i < poly.length; i++) {
      var p = poly[i];
      if (i > 0 && poly[i - 1][1] < zc - EPS && p[1] > zc + EPS) {
        var a = poly[i - 1];
        out.push([a[0] + (p[0] - a[0]) * (zc - a[1]) / (p[1] - a[1]), zc]);
      }
      if (p[1] >= zc - EPS) out.push(p);
    }
    return out;
  }

  /** Tangent arc of radius `radius` rounding the corner at C between segments P0-C and C-P2.
      The tangent length is limited to maxD; returns null for a straight join. */
  function fillet(P0, C, P2, radius, maxD) {
    var ux = C[0] - P0[0], uy = C[1] - P0[1], vx = P2[0] - C[0], vy = P2[1] - C[1];
    var lu = Math.hypot(ux, uy), lv = Math.hypot(vx, vy);
    if (!(lu > EPS) || !(lv > EPS)) return null;
    ux /= lu; uy /= lu; vx /= lv; vy /= lv;
    var phi = Math.acos(Math.max(-1, Math.min(1, ux * vx + uy * vy)));
    if (phi < 1e-6) return null;
    var tanHalf = Math.tan(phi / 2);
    var d = radius * tanHalf, limited = false, re = radius;
    if (d > maxD) { d = maxD; re = d / tanHalf; limited = true; }
    var s = (ux * vy - uy * vx) > 0 ? 1 : -1;
    var t1 = [C[0] - ux * d, C[1] - uy * d];
    var t2 = [C[0] + vx * d, C[1] + vy * d];
    var center = [t1[0] + s * -uy * re, t1[1] + s * ux * re];
    var a0 = [t1[0] - center[0], t1[1] - center[1]];
    var n = Math.max(4, Math.ceil(phi / FILLET_STEP));
    var points = [];
    for (var i = 0; i <= n; i++) {
      var psi = s * phi * i / n, c = Math.cos(psi), sn = Math.sin(psi);
      points.push([center[0] + a0[0] * c - a0[1] * sn, center[1] + a0[0] * sn + a0[1] * c]);
    }
    points[0] = t1; points[n] = t2;
    return { t1: t1, t2: t2, center: center, radius: re, requested: radius, limited: limited, points: points };
  }

  /* ---------- classification ---------- */

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    var ch = (rec.cartridge || {}).caseHead || {}, pc = (rec.cartridge || {}).powderChamber || {};
    var ratio = num(ch.R1) / num(pc.P1);
    if (ratio >= 1.05 - 1e-9) return 'rimmed';
    if (ratio < 0.98 - 1e-9) return 'rebated';
    return 'rimless';
  }

  /* ---------- bullet ---------- */

  var SHAPES = { pointy: 1, rounded: 1, flat: 1, semi_wadcutter: 1 };

  function bulletParams(shape, category, G1) {
    var pistol = category === 'pistol';
    var p = { shape: shape };
    if (shape === 'pointy') { p.s = 1.0 * G1; p.k = 0.40; p.m = Math.max(0.08 * G1, 1.27); }
    else if (shape === 'rounded') { p.s = (pistol ? 0.4 : 0.8) * G1; p.k = pistol ? 0.65 : 0.55; p.m = 0.15 * G1; }
    else if (shape === 'flat') { p.s = (pistol ? 0.4 : 0.8) * G1; p.k = pistol ? 0.70 : 0.60; p.m = 0.55 * G1; }
    else { p.s = 0.6 * G1; p.k = 0.78; p.m = 0.6 * G1; }
    return p;
  }

  /** Nose from (Rb, z0) to the flat tip (m/2, L6). */
  function nosePoints(shape, Rb, m, z0, L6) {
    var n = L6 - z0, a = Rb - m / 2, i, pts = [], rho;
    if (shape === 'pointy') {
      rho = (a * a + n * n) / (2 * a);
      var thetaMax = Math.atan2(n, rho - a); // the tip is at (rho - a, n) from the arc centre
      for (i = 0; i <= OGIVE_SEGMENTS; i++) {
        var t = thetaMax * i / OGIVE_SEGMENTS;
        pts.push([Rb - rho + rho * Math.cos(t), z0 + rho * Math.sin(t)]);
      }
      pts[0] = [Rb, z0];
      pts[pts.length - 1] = [m / 2, L6];
      return { points: pts, rho: rho };
    }
    if (shape === 'rounded') {
      for (i = 0; i <= ELLIPSE_SEGMENTS; i++) {
        var u = (Math.PI / 2) * i / ELLIPSE_SEGMENTS;
        pts.push([m / 2 + a * Math.cos(u), z0 + n * Math.sin(u)]);
      }
      pts[0] = [Rb, z0];
      pts[pts.length - 1] = [m / 2, L6];
      return { points: pts };
    }
    return { points: [[Rb, z0], [m / 2, L6]] };
  }

  /* ---------- model ---------- */

  function buildModel(rec) {
    var notes = [];
    var c = rec.cartridge || {}, ch = c.caseHead || {}, col = c.collar || {}, jc = c.junctionCone || {};
    var len = c.lengths || {}, pc = c.powderChamber || {}, pr = c.projectile || {};
    var ann = rec.annotations || {};

    var R1 = pos(ch.R1), R = pos(ch.R), P1 = pos(pc.P1), L3 = pos(len.L3);
    var missingCore = [];
    if (!has(R1)) missingCore.push('R1');
    if (!has(R)) missingCore.push('R');
    if (!has(P1)) missingCore.push('P1');
    if (!has(L3)) missingCore.push('L3');
    if (missingCore.length) {
      return { ok: false, missing: missingCore, notes: ['Drawing not available: ' + list(missingCore) + ' not published (or not a positive number).'] };
    }

    var type = rimType(rec);
    var E = pos(ch.E), E1 = pos(ch.E1), eMin = pos(ch.eMin), f = num(ch.f), R3 = pos(ch.R3);
    var beta = F.toDegrees(ch.beta), delta = F.toDegrees(ch.delta);
    var L1 = pos(len.L1), L2 = pos(len.L2), L6 = pos(len.L6);
    var P2 = pos(pc.P2), H1 = pos(col.H1), H2 = pos(col.H2), G1 = pos(pr.G1);
    var alphaRaw = jc.alpha, alpha = F.toDegrees(jc.alpha);
    var r1Min = pos(jc.r1Min), r2 = pos(jc.r2);

    var outer = [[0, 0]];

    /* 2. head face and rim edge */
    var bodyStart;
    if (type === 'rimfire' && (R1 - P1) / 2 > EPS) {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      var cr = R1 / 2 - rho;
      for (var i = 0; i <= HALF_ROUND_SEGMENTS; i++) {
        var phi = -Math.PI / 2 + Math.PI * i / HALF_ROUND_SEGMENTS;
        push(outer, [cr + rho * Math.cos(phi), rho + rho * Math.sin(phi)]);
      }
      push(outer, [P1 / 2, 2 * rho]);
      push(outer, [P1 / 2, R]);
    } else {
      var chamfer = false;
      if (type !== 'rimfire') {
        var lacking = [];
        if (!has(beta)) lacking.push('β');
        if (!has(f)) lacking.push('f');
        if (lacking.length) notes.push('Rim chamfer not drawn: ' + list(lacking) + ' not published.');
        else if (beta < 90 && f > 0 && f < R) chamfer = true;
      }
      if (chamfer) {
        push(outer, [R1 / 2 - Math.min(f * Math.tan(beta * DEG), R1 / 4), 0]);
        push(outer, [R1 / 2, f]);
      } else {
        push(outer, [R1 / 2, 0]);
      }
      push(outer, [R1 / 2, R]);
    }

    /* 3. extractor groove, belt */
    var groove = null, belt = null;
    var grooveLacking = [];
    if (!has(E)) grooveLacking.push('E');
    if (!has(E1)) grooveLacking.push('E1');
    if (!has(eMin)) grooveLacking.push('e min');
    if (type !== 'rimfire') {
      if (grooveLacking.length) notes.push('Extractor groove not drawn: ' + list(grooveLacking) + ' not published.');
      else if (!(E > R + eMin)) notes.push('Extractor groove not drawn: E must be larger than R + e min.');
      else groove = { E1: E1, floorStart: [E1 / 2, R], floorEnd: [E1 / 2, R + eMin] };
    }
    if (groove) {
      push(outer, groove.floorStart);
      push(outer, groove.floorEnd);
      if (type === 'belted') {
        var beltLacking = [];
        if (!has(R3)) beltLacking.push('R3');
        if (!has(delta) || !(delta > 0)) beltLacking.push('δ');
        if (beltLacking.length) notes.push('Belt not drawn: ' + list(beltLacking) + ' not published.');
        else if (!(R3 / 2 > E1 / 2)) notes.push('Belt not drawn: R3 must be larger than E1.');
        else {
          var rampEndZ = R + eMin + (R3 / 2 - E1 / 2) / Math.tan(delta * DEG);
          if (!(rampEndZ < E)) notes.push('Belt not drawn: the ramp at δ ends beyond E.');
          else {
            belt = { rampEndZ: rampEndZ, radius: R3 / 2 };
            push(outer, [R3 / 2, rampEndZ]);
            push(outer, [R3 / 2, E]);
          }
        }
      }
      push(outer, [P1 / 2, E]);
      bodyStart = E;
    } else {
      if (type === 'belted') notes.push('Belt not drawn: the extractor groove is not drawn.');
      if (type !== 'rimfire') push(outer, [P1 / 2, R]);
      bodyStart = R;
    }
    if (!(bodyStart < L3)) {
      return { ok: false, missing: ['L3'], notes: ['Drawing not available: L3 must be larger than the body start (E or R).'] };
    }
    var iBody = outer.length - 1; // the body starts at the last point so far

    /* 4-6. body, shoulder, neck */
    var shoulder = null;
    var cone = { alpha: alpha, L1: L1, L2: L2, P2: P2, H1: H1 };
    var coneNames = { alpha: 'α', L1: 'L1', L2: 'L2', P2: 'P2', H1: 'H1' };
    var coneLacking = Object.keys(cone).filter(function (k) { return !has(cone[k]); }).map(function (k) { return coneNames[k]; });
    var bottleneck = false;
    // a case that publishes none of these is straight by design (rule 4); only a partial set is worth a note
    if (coneLacking.length) { if (coneLacking.length < 5) notes.push('Shoulder not drawn: ' + list(coneLacking) + ' not published.'); }
    else if (!(bodyStart < L1 && L1 < L2 && L2 < L3)) notes.push('Shoulder not drawn: L1 and L2 do not lie between the body start and L3.');
    else bottleneck = true;

    var neckR = H2;
    if (!has(neckR)) {
      neckR = bottleneck ? H1 : P1;
      notes.push('H2 not published: the mouth is drawn at ' + (bottleneck ? 'H1' : 'P1') + '.');
    }
    var mouth = [neckR / 2, L3];

    if (bottleneck) {
      var A = [P2 / 2, L1], B = [H1 / 2, L2];
      var bodyFrom = outer[iBody];
      var lenAB = dist(A, B);
      var fa = null, fb = null;
      if (has(r1Min) && r1Min > 0) fa = fillet(bodyFrom, A, B, r1Min, 0.5 * Math.min(dist(bodyFrom, A), lenAB));
      else notes.push('Body-side shoulder corner not rounded: r1 min not published.');
      if (has(r2) && r2 > 0) fb = fillet(A, B, mouth, r2, 0.5 * Math.min(lenAB, dist(B, mouth)));
      else notes.push('Neck-side shoulder corner not rounded: r2 not published.');
      if (fa && fa.limited) notes.push('Shoulder corner radius r1 min reduced from ' + r1Min + ' to ' + fa.radius.toFixed(2) + ' to fit.');
      if (fb && fb.limited) notes.push('Shoulder corner radius r2 reduced from ' + r2 + ' to ' + fb.radius.toFixed(2) + ' to fit.');
      (fa ? fa.points : [A]).forEach(function (p) { push(outer, p); });
      (fb ? fb.points : [B]).forEach(function (p) { push(outer, p); });
      shoulder = { A: A, B: B, alpha: alphaRaw, filletA: fa, filletB: fb };
    }
    push(outer, mouth);

    /* 7. bullet geometry (needs G1, L6, a known shape and, for rounded/flat, the category) */
    var heeled = has(H2) && has(G1) && H2 - G1 <= HEEL_TOLERANCE;

    /* 8. walls */
    var walls = null;
    if (has(G1) && has(H2)) {
      var tn = (H2 - G1) / 2;
      var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
      walls = { tn: tn, tb: tb, tnEff: heeled ? tb : tn, heeled: heeled };
    } else {
      notes.push('Section walls not drawn: ' + list([!has(G1) ? 'G1' : null, !has(H2) ? 'H2' : null].filter(Boolean)) + ' not published.');
    }

    var bullet = null;
    var shape = ann.defaultBulletShape, category = ann.category;
    var bulletLacking = [];
    if (!has(G1)) bulletLacking.push('G1');
    if (!has(L6)) bulletLacking.push('L6');
    if (!SHAPES[shape]) bulletLacking.push('annotations.defaultBulletShape');
    else if ((shape === 'rounded' || shape === 'flat') && ['rifle', 'pistol', 'rimfire'].indexOf(category) < 0) {
      bulletLacking.push('annotations.category');
    }
    if (bulletLacking.length) notes.push('Bullet not drawn: ' + list(bulletLacking) + ' not published.');
    else if (!(L6 > L3)) notes.push('Bullet not drawn: L6 must be larger than L3.');
    else if (heeled && !walls) notes.push('Bullet not drawn: the heel needs the section walls.');
    else {
      bullet = buildBullet(shape, category, G1, L6, L3, heeled, H2, walls);
      if (!bullet) notes.push('Bullet not drawn: its geometry is not consistent with the published values.');
    }

    /* section: inner line, solid head, pocket */
    var pocket = null, w, inner = null, section = null;
    var primer = ann.primerType;
    if (type !== 'rimfire' && primer !== 'rimfire') {
      if (POCKET_DIAMETER[primer]) pocket = { d: POCKET_DIAMETER[primer], depth: POCKET_DEPTH[primer] };
      else notes.push('Primer pocket not drawn: primer type ' + (has(primer) ? '"' + primer + '" is unknown' : 'not published') + '.');
    }
    if (walls) {
      var terms = [2.5, 0.25 * P1 / 2];
      if (pocket) terms.push(pocket.depth + 1.5);
      if (belt) terms.push(belt.rampEndZ + walls.tb);
      else if (groove) terms.push(E + walls.tb);
      w = Math.max.apply(null, terms);
      if (w < L3) inner = buildInner(outer, iBody, w, walls, bottleneck ? { L1: L1, L2: L2 } : null, bullet ? bullet.zb : L3);
      if (inner && inner.length > 1 && inner.every(function (p) { return isFinite(p[0]) && isFinite(p[1]); })) {
        section = buildSection(outer, inner, pocket, w, bullet);
      } else {
        inner = null;
        notes.push('Section walls not drawn: the solid head reaches the mouth or the walls are not consistent.');
      }
    }

    /* values for the dimension lines (only what is published and drawn) */
    var values = { L3: L3, R1: R1, R: R, P1: P1 };
    if (has(H2)) values.H2 = H2;
    if (has(L6) && bullet) values.L6 = L6;
    if (has(G1) && bullet) values.G1 = G1;
    if (groove) values.E1 = E1;
    if (shoulder) { values.L1 = L1; values.L2 = L2; values.P2 = P2; values.H1 = H1; values.alpha = alphaRaw; }

    return {
      ok: true, notes: notes, rimType: type, outer: outer, mouth: mouth, bodyStart: bodyStart, iBody: iBody,
      groove: groove, belt: belt, shoulder: shoulder, walls: walls, w: w, pocket: pocket, inner: inner,
      section: section, bullet: bullet, values: values
    };
  }

  function buildBullet(shape, category, G1, L6, L3, heeled, H2, walls) {
    var p = bulletParams(shape, category, G1);
    var zb = L3 - p.s, Lb = L6 - zb, z0 = zb + p.k * Lb;
    var Rb = heeled ? H2 / 2 : G1 / 2;
    var Rseat = heeled ? H2 / 2 - walls.tb : G1 / 2;
    if (!(Lb > 0) || !(z0 < L6) || !(p.m / 2 < Rb) || (heeled && !(z0 > L3))) return null;
    var nose = nosePoints(shape, Rb, p.m, z0, L6);
    var profile = [[Rseat, zb]];
    var exposedSource;
    if (heeled) {
      push(profile, [Rseat, L3]);
      push(profile, [Rb, L3]);
      exposedSource = [[Rb, L3]];
    } else {
      exposedSource = [[Rb, zb]];
    }
    nose.points.forEach(function (q) { push(profile, q); });
    if (heeled) nose.points.forEach(function (q) { push(exposedSource, q); });
    else exposedSource = profile;
    return {
      shape: shape, category: category, heeled: heeled, s: p.s, k: p.k, m: p.m, zb: zb, Lb: Lb, z0: z0,
      n: L6 - z0, Rb: Rb, Rseat: Rseat, rho: nose.rho, L6: L6, nose: nose.points, profile: profile,
      exposed: clipAbove(exposedSource, L3)
    };
  }

  /** Inner wall line from z = w to the mouth: the outer body/shoulder/neck minus the wall at each z. */
  function buildInner(outer, iBody, w, walls, cone, zBlendEnd) {
    var body = outer.slice(iBody);
    var tb = walls.tb, tn = walls.tnEff;
    var breaks = [];
    if (cone) breaks.push(cone.L1, cone.L2); else breaks.push(zBlendEnd);
    breaks.push(w);
    breaks.forEach(function (z) { body = insertAtZ(body, z); });

    function wallAt(z) {
      if (cone) {
        if (z <= cone.L1) return tb;
        if (z >= cone.L2) return tn;
        return tb + (tn - tb) * (z - cone.L1) / (cone.L2 - cone.L1);
      }
      if (z <= w) return tb;
      if (z >= zBlendEnd) return tn;
      return tb + (tn - tb) * (z - w) / (zBlendEnd - w);
    }

    var inner = [];
    var start = w >= body[0][1] ? radiusAt(body, w) : body[0][0];
    inner.push([start - wallAt(w), w]);
    body.forEach(function (p) { if (p[1] > w + EPS) push(inner, [p[0] - wallAt(p[1]), p[1]]); });
    return inner;
  }

  function buildSection(outer, inner, pocket, w, bullet) {
    var cs = [];
    if (pocket) { cs.push([pocket.d / 2, 0]); outer.slice(1).forEach(function (p) { push(cs, p); }); }
    else outer.forEach(function (p) { push(cs, p); });
    for (var i = inner.length - 1; i >= 0; i--) {
      // the mouth face: from the outer mouth point straight to the inner line's last point
      push(cs, inner[i]);
    }
    push(cs, [0, w]);
    if (pocket) { push(cs, [0, pocket.depth]); push(cs, [pocket.d / 2, pocket.depth]); }
    var bs = null;
    if (bullet) {
      bs = [[0, bullet.zb]];
      bullet.profile.forEach(function (p) { push(bs, p); });
      push(bs, [0, bullet.L6]);
    }
    return { caseSection: cs, bulletSection: bs };
  }

  var api = { buildModel: buildModel, rimType: rimType, radiusAt: radiusAt, list: list };
  CIP.geometry = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
