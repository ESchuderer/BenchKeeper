/* Drawing layout: turns a geometry model into a scene in SVG space (x = z in mm, y = -r above the axis, +r below).
   The scene holds drawable items, the dimension lines (with arrowheads and extension lines) and placed labels.
   Labels are placed by a nearest-free-spot search so that none touches another label, the outline, any
   dimension/extension/centre line or the part itself; a thin leader joins a label that had to move away. */
(function (g) {
  'use strict';
  var CIP = g.CIP = g.CIP || {};
  var F = (typeof module === 'object' && module.exports) ? require('./format.js') : CIP.format;

  var CONST = {
    FONT: 2.8,          // label font size, mm (SVG units)
    CHAR_W: 0.62,       // estimated advance of one character, in em (monospace stack)
    ARROW_L: 1.8, ARROW_W: 0.55,
    GAP: 0.8,           // gap between a feature and its extension line
    OVER: 1.5,          // extension line overshoot beyond the dimension line
    LANE0: 5.5, LANE_STEP: 6.5,
    CLEAR: 0.5,         // minimum clearance label <-> lines
    LABEL_GAP: 0.5,     // minimum clearance label <-> label
    LEADER_AFTER: 1.8,  // a label farther than this from its line gets a leader
    SEARCH_RADIUS: 60, SEARCH_STEP: 0.5
  };

  /* ---------- geometry helpers ---------- */

  function rectsHit(a, b, m) { return a.x < b.x + b.w + m && b.x < a.x + a.w + m && a.y < b.y + b.h + m && b.y < a.y + a.h + m; }

  function segHitsRect(sg, rc, m) {
    var x0 = rc.x - m, y0 = rc.y - m, x1 = rc.x + rc.w + m, y1 = rc.y + rc.h + m;
    var ax = sg[0], ay = sg[1], bx = sg[2], by = sg[3];
    if ((ax >= x0 && ax <= x1 && ay >= y0 && ay <= y1) || (bx >= x0 && bx <= x1 && by >= y0 && by <= y1)) return true;
    if (Math.max(ax, bx) < x0 || Math.min(ax, bx) > x1 || Math.max(ay, by) < y0 || Math.min(ay, by) > y1) return false;
    return edgeHit(ax, ay, bx, by, x0, y0, x1, y0) || edgeHit(ax, ay, bx, by, x1, y0, x1, y1) ||
      edgeHit(ax, ay, bx, by, x1, y1, x0, y1) || edgeHit(ax, ay, bx, by, x0, y1, x0, y0);
  }

  function edgeHit(ax, ay, bx, by, cx, cy, dx, dy) {
    var d = (bx - ax) * (dy - cy) - (by - ay) * (dx - cx);
    if (Math.abs(d) < 1e-12) return false;
    var t = ((cx - ax) * (dy - cy) - (cy - ay) * (dx - cx)) / d;
    var u = ((cx - ax) * (by - ay) - (cy - ay) * (bx - ax)) / d;
    return t >= 0 && t <= 1 && u >= 0 && u <= 1;
  }

  function pointInPoly(x, y, poly) {
    var c = false;
    for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      var a = poly[i], b = poly[j];
      if ((a[1] > y) !== (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
    }
    return c;
  }

  function nearestOnSeg(px, py, ax, ay, bx, by) {
    var dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
    var t = l2 === 0 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2));
    return [ax + dx * t, ay + dy * t];
  }

  function rectDistanceToPoint(rc, px, py) {
    var dx = Math.max(rc.x - px, 0, px - (rc.x + rc.w)), dy = Math.max(rc.y - py, 0, py - (rc.y + rc.h));
    return Math.hypot(dx, dy);
  }

  function clampToRect(rc, px, py) {
    return [Math.max(rc.x, Math.min(rc.x + rc.w, px)), Math.max(rc.y, Math.min(rc.y + rc.h, py))];
  }

  // offsets (dx, dy) sorted by distance, shared by all searches
  var OFFSETS = null;
  function offsets() {
    if (OFFSETS) return OFFSETS;
    var out = [], n = Math.round(CONST.SEARCH_RADIUS / CONST.SEARCH_STEP);
    for (var i = -n; i <= n; i++) for (var j = -n; j <= n; j++) {
      var dx = i * CONST.SEARCH_STEP, dy = j * CONST.SEARCH_STEP, d = dx * dx + dy * dy;
      if (d <= CONST.SEARCH_RADIUS * CONST.SEARCH_RADIUS) out.push([dx, dy, d]);
    }
    out.sort(function (a, b) { return a[2] - b[2] || Math.abs(a[0]) - Math.abs(b[0]) || a[0] - b[0] || a[1] - b[1]; });
    OFFSETS = out;
    return out;
  }

  function emptyScene() {
    return { items: [], segments: [], silhouettes: [], labels: [], dims: {}, bbox: { x: 0, y: 0, w: 0, h: 0 } };
  }

  /* ---------- scene ---------- */

  function layoutScene(model) {
    if (!model || !model.ok) return emptyScene();
    var C = CONST, FONT = C.FONT;
    var items = [], segments = [], silhouettes = [], labels = [], dims = {}, pending = [];

    var up = function (p) { return [p[1], -p[0]]; };
    var low = function (p) { return [p[1], p[0]]; };
    var v = model.values;
    var L3 = v.L3;
    var xTip = model.bullet ? model.bullet.L6 : L3;

    function seg(cls, x1, y1, x2, y2) { segments.push([x1, y1, x2, y2, cls]); }
    function line(cls, x1, y1, x2, y2) { items.push({ type: 'line', cls: cls, x1: x1, y1: y1, x2: x2, y2: y2 }); seg(cls, x1, y1, x2, y2); }
    function polyline(cls, pts) {
      items.push({ type: 'polyline', cls: cls, pts: pts });
      for (var i = 1; i < pts.length; i++) seg(cls, pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1]);
    }
    function polygon(cls, pts, hatch) {
      items.push({ type: 'polygon', cls: cls, pts: pts, hatch: !!hatch });
      for (var i = 0; i < pts.length; i++) { var a = pts[i], b = pts[(i + 1) % pts.length]; seg(cls, a[0], a[1], b[0], b[1]); }
    }
    function arrow(tx, ty, dx, dy) {
      var bx = tx - dx * C.ARROW_L, by = ty - dy * C.ARROW_L, px = -dy * C.ARROW_W, py = dx * C.ARROW_W;
      var pts = [[tx, ty], [bx + px, by + py], [bx - px, by - py]];
      items.push({ type: 'arrow', pts: pts });
      for (var i = 0; i < 3; i++) { var a = pts[i], b = pts[(i + 1) % 3]; seg('arrow', a[0], a[1], b[0], b[1]); }
    }

    /* part outline: outside view above the axis, section below */
    var outer = model.outer;
    var tail = model.bullet ? model.bullet.exposed : [[0, L3]];
    var meplatClosure = model.bullet ? [[0, model.bullet.L6]] : []; // the tip face across the axis
    var upperPts = outer.concat(tail, meplatClosure).map(up);
    polyline('outline', upperPts);
    var lowerPts = outer.concat(tail, meplatClosure).map(low);
    silhouettes.push(upperPts.slice(), lowerPts.slice());
    if (model.section) {
      polygon('cut', model.section.caseSection.map(low), true);
      if (model.section.bulletSection) polygon('bullet-cut', model.section.bulletSection.map(low), false);
    } else {
      polyline('outline', lowerPts);
    }
    line('centre', -3.5, 0, xTip + 3.5, 0);

    var rMax = Math.max.apply(null, outer.map(function (p) { return p[0]; }));
    var rHead = outer[1][0];

    /* ---------- dimension primitives ---------- */

    function dimH(id, x1, x2, y, fromY1, fromY2, text, extra) {
      var s1 = y < fromY1 ? -1 : 1, s2 = y < fromY2 ? -1 : 1;
      line('ext', x1, fromY1 + s1 * C.GAP, x1, y + s1 * C.OVER);
      line('ext', x2, fromY2 + s2 * C.GAP, x2, y + s2 * C.OVER);
      var span = Math.abs(x2 - x1), outside = span < 2 * C.ARROW_L + 1.2, lo = Math.min(x1, x2), hi = Math.max(x1, x2);
      line('dim', lo, y, hi, y);
      if (!outside) { arrow(lo, y, -1, 0); arrow(hi, y, 1, 0); }
      else {
        arrow(lo, y, 1, 0); arrow(hi, y, -1, 0);
        line('dim', lo - C.ARROW_L - 1.2, y, lo, y); line('dim', hi, y, hi + C.ARROW_L + 1.2, y);
      }
      dims[id] = { kind: 'h', a: [x1, y], b: [x2, y], arrows: 2, extensions: 2 };
      pending.push({ id: id, text: text, outside: outside, kind: 'h', x1: lo, x2: hi, y: y, side: y < 0 ? -1 : 1, anchor: [lo, y, hi, y], extra: extra });
    }

    // vertical diameter dimension; mode 'tick': extension ticks centred on the line (in-part), 'ext': extension lines from featureX
    function dimV(id, x, y1, y2, text, mode, featureX, tick) {
      if (mode === 'ext') {
        var dirx = x < featureX ? -1 : 1;
        line('ext', featureX, y1, x + dirx * C.OVER, y1);
        line('ext', featureX, y2, x + dirx * C.OVER, y2);
      } else {
        line('ext', x - tick / 2, y1, x + tick / 2, y1);
        line('ext', x - tick / 2, y2, x + tick / 2, y2);
      }
      line('dim', x, y1, x, y2);
      arrow(x, y1, 0, -1); arrow(x, y2, 0, 1);
      dims[id] = { kind: 'v', a: [x, y1], b: [x, y2], arrows: 2, extensions: 2 };
      pending.push({ id: id, text: text, kind: 'v', x: x, y1: y1, y2: y2, mode: mode, anchor: [x, y1, x, y2] });
    }

    function labelText(id) {
      var key = id, value = v[id];
      return F.symbolFor(key) + ' ' + (id === 'alpha' ? F.formatAngle(value) : F.formatNumber(value));
    }

    /* axial dimensions on lanes outside the part */
    var yUp = -rMax, yLow = rMax;
    var upperIds = model.shoulder ? ['L1', 'L2'] : [];
    var lowerIds = ['R', 'L3'].concat(v.L6 !== undefined ? ['L6'] : []);
    var laneY = function (side, k) { return side * (rMax + C.LANE0 + k * C.LANE_STEP); };
    var rEdgeAtR = model.rimType === 'rimfire' ? v.P1 / 2 : v.R1 / 2;
    var feature = {
      R: [[0, rHead], [v.R, rEdgeAtR]],
      L1: model.shoulder ? [[0, rHead], [v.L1, v.P2 / 2]] : null,
      L2: model.shoulder ? [[0, rHead], [v.L2, v.H1 / 2]] : null,
      L3: [[0, rHead], [v.L3, model.mouth[0]]],
      L6: v.L6 !== undefined ? [[0, rHead], [v.L6, model.bullet ? model.bullet.m / 2 : 0]] : null
    };
    upperIds.forEach(function (id, k) {
      var f = feature[id], y = laneY(-1, k);
      dimH(id, f[0][0], f[1][0], y, -f[0][1], -f[1][1], labelText(id));
    });
    lowerIds.forEach(function (id, k) {
      var f = feature[id], y = laneY(1, k);
      dimH(id, f[0][0], f[1][0], y, f[0][1], f[1][1], labelText(id));
    });

    /* diameters */
    var xf = Infinity;
    outer.forEach(function (p) { if (Math.abs(p[0] - v.R1 / 2) < 1e-9 && p[1] < xf) xf = p[1]; });
    if (!isFinite(xf)) xf = 0;
    dimV('R1', -(C.ARROW_L + 4.5), -v.R1 / 2, v.R1 / 2, labelText('R1'), 'ext', xf - C.GAP, 0);
    var bodyEnd = model.shoulder ? v.L1 : L3;
    var xP1 = Math.min(model.bodyStart + 3, (model.bodyStart + bodyEnd) / 2);
    dimV('P1', xP1, -v.P1 / 2, v.P1 / 2, labelText('P1'), 'tick', 0, 3);
    if (v.E1 !== undefined) {
      var eMid = model.groove.floorStart[1] + (model.groove.floorEnd[1] - model.groove.floorStart[1]) / 2;
      dimV('E1', eMid, -v.E1 / 2, v.E1 / 2, labelText('E1'), 'tick', 0, Math.max(1, Math.min(3, 0.9 * (model.groove.floorEnd[1] - model.groove.floorStart[1]))));
    }
    if (model.shoulder) {
      dimV('P2', v.L1, -v.P2 / 2, v.P2 / 2, labelText('P2'), 'tick', 0, 3);
      dimV('H1', v.L2, -v.H1 / 2, v.H1 / 2, labelText('H1'), 'tick', 0, 3);
    }
    if (v.H2 !== undefined) dimV('H2', L3, -v.H2 / 2, v.H2 / 2, labelText('H2'), 'tick', 0, 3);
    if (v.G1 !== undefined && model.bullet && model.bullet.z0 - L3 >= 0.3) {
      // measured where the nose starts; a heeled bullet is drawn at the case diameter, equal to G1 within 0.015
      dimV('G1', model.bullet.z0, -v.G1 / 2, v.G1 / 2, labelText('G1'), 'tick', 0, 3);
    }

    /* shoulder angle: the cone's included angle at the body-side corner (shoulder line and its mirror about the axis direction) */
    var angle = null;
    if (model.shoulder) {
      var A = up(model.shoulder.A), B = up(model.shoulder.B);
      var dx = B[0] - A[0], dy = B[1] - A[1], lenAB = Math.hypot(dx, dy), th = Math.atan2(dy, dx);
      var rho = Math.min(8, 0.75 * lenAB), pts = [], n = 16;
      for (var i = 0; i <= n; i++) { var t = -th + 2 * th * i / n; pts.push([A[0] + rho * Math.cos(t), A[1] + rho * Math.sin(t)]); }
      items.push({ type: 'polyline', cls: 'angle', pts: pts });
      for (var k = 1; k < pts.length; k++) seg('angle', pts[k - 1][0], pts[k - 1][1], pts[k][0], pts[k][1]);
      line('construction', A[0], A[1], A[0] + (rho + 2) * Math.cos(th), A[1] - (rho + 2) * Math.sin(th));
      angle = { A: A, rho: rho, th: th };
      pending.push({ id: 'alpha', text: labelText('alpha'), kind: 'angle', cx: A[0] + rho + 0.8, cy: A[1], anchor: [A[0] + rho, A[1], A[0] + rho, A[1]] });
    }

    /* ---------- label placement ---------- */

    var order = ['L3', 'L6', 'R', 'L1', 'L2', 'R1', 'P1', 'E1', 'P2', 'H1', 'H2', 'G1', 'alpha'];
    pending.sort(function (a, b) { return order.indexOf(a.id) - order.indexOf(b.id); });
    var obstacles = segments.slice();

    function valid(rc, spec, leader) {
      var i, j;
      for (i = 0; i < obstacles.length; i++) if (segHitsRect(obstacles[i], rc, C.CLEAR)) return false;
      for (i = 0; i < labels.length; i++) if (rectsHit(rc, labels[i].rect, C.LABEL_GAP)) return false;
      var cs = [[rc.x, rc.y], [rc.x + rc.w, rc.y], [rc.x, rc.y + rc.h], [rc.x + rc.w, rc.y + rc.h], [rc.x + rc.w / 2, rc.y + rc.h / 2],
        [rc.x + rc.w / 2, rc.y], [rc.x + rc.w / 2, rc.y + rc.h]];
      for (i = 0; i < silhouettes.length; i++) for (j = 0; j < cs.length; j++) if (pointInPoly(cs[j][0], cs[j][1], silhouettes[i])) return false;
      if (leader) for (i = 0; i < labels.length; i++) if (segHitsRect(leader, labels[i].rect, 0.2)) return false;
      return true;
    }

    function leaderFor(rc, spec) {
      var an = spec.anchor;
      var cx = rc.x + rc.w / 2, cy = rc.y + rc.h / 2;
      var onLine = nearestOnSeg(cx, cy, an[0], an[1], an[2], an[3]);
      var onRect = clampToRect(rc, onLine[0], onLine[1]);
      onLine = nearestOnSeg(onRect[0], onRect[1], an[0], an[1], an[2], an[3]);
      var d = Math.hypot(onRect[0] - onLine[0], onRect[1] - onLine[1]);
      if (d <= C.LEADER_AFTER) return null;
      var ux = (onRect[0] - onLine[0]) / d, uy = (onRect[1] - onLine[1]) / d;
      return [onLine[0], onLine[1], onRect[0] - ux * 0.3, onRect[1] - uy * 0.3, 'leader'];
    }

    function place(spec) {
      var w = spec.text.length * FONT * C.CHAR_W, h = FONT;
      var pref;
      if (spec.kind === 'h') {
        pref = [spec.outside ? spec.x2 + C.ARROW_L + 1.2 + 1 + w / 2 : (spec.x1 + spec.x2) / 2, spec.y + spec.side * (0.9 + h / 2)];
      } else if (spec.kind === 'v') {
        pref = spec.id === 'R1' ? [spec.x - 1 - w / 2 - C.OVER, 0] : [spec.x, spec.y1 - 0.9 - h / 2];
      } else pref = [spec.cx + w / 2, spec.cy];
      var offs = offsets(), best = null;
      for (var i = 0; i < offs.length; i++) {
        var rc = { x: pref[0] + offs[i][0] - w / 2, y: pref[1] + offs[i][1] - h / 2, w: w, h: h };
        var ld = leaderFor(rc, spec);
        if (valid(rc, spec, ld)) { best = { rect: rc, leader: ld }; break; }
      }
      var placed = !!best;
      if (!best) best = { rect: { x: pref[0] - w / 2, y: pref[1] - h / 2, w: w, h: h }, leader: null };
      var rect = best.rect;
      if (best.leader) {
        items.push({ type: 'line', cls: 'leader', x1: best.leader[0], y1: best.leader[1], x2: best.leader[2], y2: best.leader[3] });
        obstacles.push(best.leader);
        segments.push(best.leader);
      }
      var lab = { id: spec.id, text: spec.text, rect: rect, x: rect.x, y: rect.y + 0.8 * FONT, placed: placed };
      labels.push(lab);
      items.push({ type: 'label', id: lab.id, text: lab.text, x: lab.x, y: lab.y });
    }

    pending.forEach(place);

    /* bounding box of everything drawn */
    var minx = Infinity, miny = Infinity, maxx = -Infinity, maxy = -Infinity;
    var grow = function (x, y) { minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); };
    segments.forEach(function (s) { grow(s[0], s[1]); grow(s[2], s[3]); });
    labels.forEach(function (l) { grow(l.rect.x, l.rect.y); grow(l.rect.x + l.rect.w, l.rect.y + l.rect.h); });

    return {
      items: items, segments: segments, silhouettes: silhouettes, labels: labels, dims: dims, angle: angle,
      bbox: { x: minx, y: miny, w: maxx - minx, h: maxy - miny }, partTop: -rMax, partBottom: rMax
    };
  }

  var api = { layoutScene: layoutScene, CONST: CONST };
  CIP.layout = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
