/* List filtering (search text + family) and hash-route parsing. Pure functions. */
(function (g) {
  'use strict';
  var CIP = g.CIP = g.CIP || {};

  var FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  /** Lowercase, decimal comma to point, no whitespace: "7,62 X 51" -> "7.62x51". */
  function normalise(text) {
    return String(text).toLowerCase().replace(/,/g, '.').replace(/\s+/g, '');
  }

  function matches(record, q) {
    if (!q) return true;
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (n) { return normalise(n).indexOf(q) >= 0; });
  }

  function filterRecords(records, state) {
    state = state || {};
    var q = normalise(state.q || '');
    var family = state.family && state.family !== 'all' ? state.family : null;
    return records.filter(function (r) { return (!family || r.family === family) && matches(r, q); });
  }

  function validFamily(f) { return FAMILIES.indexOf(f) >= 0 ? f : 'all'; }

  function parseListQuery(qs) {
    var p = new URLSearchParams(qs || '');
    return { q: p.get('q') || '', family: validFamily(p.get('family') || 'all') };
  }

  /** "q=...&family=..." without the defaults; "" when nothing is set. */
  function listQuery(state) {
    var parts = [];
    if (state && state.q) parts.push('q=' + encodeURIComponent(state.q));
    if (state && state.family && state.family !== 'all') parts.push('family=' + encodeURIComponent(state.family));
    return parts.join('&');
  }

  function listHash(state) {
    var qs = listQuery(state);
    return '#/' + (qs ? '?' + qs : '');
  }

  function detailHash(key) { return '#/cartridge/' + encodeURIComponent(key); }

  function parseRoute(hash) {
    var h = String(hash || '').replace(/^#/, '');
    if (h === '' || h === '/') return { name: 'list', q: '', family: 'all' };
    if (h.charAt(0) === '/' && h.charAt(1) === '?') {
      var s = parseListQuery(h.slice(2));
      return { name: 'list', q: s.q, family: s.family };
    }
    var m = /^\/cartridge\/([^/?]+)$/.exec(h);
    if (m) {
      try { return { name: 'detail', key: decodeURIComponent(m[1]) }; } catch (e) { return { name: 'notfound' }; }
    }
    return { name: 'notfound' };
  }

  var api = {
    FAMILIES: FAMILIES, normalise: normalise, filterRecords: filterRecords, parseListQuery: parseListQuery,
    listQuery: listQuery, listHash: listHash, detailHash: detailHash, parseRoute: parseRoute
  };
  CIP.search = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
