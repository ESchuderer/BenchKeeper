/* Turns a record's cartridge/chamber values into table sections (Symbol, Value, Unit). */
(function (g) {
  'use strict';
  var CIP = g.CIP = g.CIP || {};
  var F = (typeof module === 'object' && module.exports) ? require('./format.js') : CIP.format;

  var TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
  };

  // Reading order of sections and of the fields inside them. Unknown ones follow in record order.
  var CARTRIDGE_ORDER = ['caseHead', 'powderChamber', 'collar', 'junctionCone', 'lengths', 'projectile', 'pressures', 'misc'];
  var CHAMBER_ORDER = ['breech', 'powderChamber', 'collar', 'junctionCone', 'lengths', 'barrel', 'grooves', 'rifling'];
  var FIELD_ORDER = {
    caseHead: ['R1', 'R3', 'R', 'E1', 'E', 'eMin', 'f', 'beta', 'delta'],
    collar: ['H1', 'H2'],
    junctionCone: ['S', 'alpha', 'r1Min', 'r1Max', 'r2'],
    lengths: ['L1', 'L2', 'L3', 'L4', 'L5', 'L6'],
    misc: ['Fe', 'deltaL'],
    powderChamber: ['P1', 'P2', 'E'],
    pressures: ['Pmax', 'PK', 'PE', 'EE', 'M'],
    projectile: ['G1', 'G2', 'L3PlusG'],
    barrel: ['F', 'Z'],
    breech: ['R1', 'R3', 'R', 'r'],
    grooves: ['N', 'Q', 'b', 'u'],
    rifling: ['G', 'G1', 'h', 's', 'alpha1', 'i']
  };

  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function isTol(k) { return /Tol$/.test(k); }

  function buildSection(id, values) {
    var order = FIELD_ORDER[id] || [];
    var keys = Object.keys(values).filter(function (k) { return !isTol(k); });
    var rank = function (k) { var i = order.indexOf(k); return i < 0 ? order.length : i; };
    // stable sort by known rank; unknown fields keep record order
    keys = keys.map(function (k, i) { return { k: k, i: i }; })
      .sort(function (a, b) { return rank(a.k) - rank(b.k) || a.i - b.i; })
      .map(function (o) { return o.k; });
    return {
      id: id,
      title: TITLES[id] || id,
      rows: keys.map(function (k) {
        return {
          field: k,
          symbol: F.symbolFor(k),
          value: F.formatCell(k, values[k], has(values, k + 'Tol') ? values[k + 'Tol'] : undefined),
          unit: F.unitFor(k)
        };
      })
    };
  }

  function buildGroup(group, order) {
    group = group || {};
    var ids = order.concat(Object.keys(group).filter(function (k) { return order.indexOf(k) < 0; }));
    return ids
      .filter(function (id) { return group[id] && Object.keys(group[id]).filter(function (k) { return !isTol(k); }).length > 0; })
      .map(function (id) { return buildSection(id, group[id]); });
  }

  function buildTables(record) {
    return { cartridge: buildGroup(record.cartridge, CARTRIDGE_ORDER), chamber: buildGroup(record.chamber, CHAMBER_ORDER) };
  }

  var api = { buildTables: buildTables };
  CIP.tables = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
