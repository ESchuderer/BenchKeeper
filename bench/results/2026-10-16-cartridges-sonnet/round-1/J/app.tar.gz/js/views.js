/* Page views: start page (list) and detail view. Builds DOM only; routing lives in app.js. */
(function (g) {
  'use strict';
  var CIP = g.CIP = g.CIP || {};
  var h = CIP.dom.h, F = CIP.format, S = CIP.search, T = CIP.tables;

  var SOURCE = 'C.I.P. TDCC';
  var DATA_CREDIT = 'Data via OpenBallistics (MIT, commit e83db43).';

  function allCartridgesLink() { return h('a', { href: S.listHash({}) }, 'All cartridges'); }

  /* ---- start page ---- */

  function listRow(r) {
    var L3 = r.cartridge && r.cartridge.lengths ? r.cartridge.lengths : {};
    var alt = (r.alternativeNames || []).join(', ');
    return h('tr', null,
      h('td', { class: 'name' }, h('a', { href: S.detailHash(r.key) }, r.name),
        alt ? h('span', { class: 'alt' }, alt) : null),
      h('td', null, r.family),
      h('td', { class: 'num' }, F.isNumber(L3.L3) ? F.formatCell('L3', L3.L3, L3.L3Tol) : ''));
  }

  /** Renders the start page into `main`; `state` = {q, family}; onState(state) is called as the user types. */
  function renderList(main, records, state, onState) {
    var current = { q: state.q, family: state.family };
    var count = h('p', { class: 'count', role: 'status' });
    var results = h('div', { class: 'results' });

    function update() {
      var shown = S.filterRecords(records, current);
      count.textContent = shown.length + ' cartridges';
      results.textContent = '';
      if (!shown.length) {
        results.appendChild(h('p', { class: 'empty' }, 'No cartridge matches the search.'));
        return;
      }
      results.appendChild(h('table', { class: 'list' },
        h('thead', null, h('tr', null, h('th', { scope: 'col' }, 'Name'), h('th', { scope: 'col' }, 'Family'),
          h('th', { scope: 'col', class: 'num' }, 'Case length L3 (mm)'))),
        h('tbody', null, shown.map(listRow))));
    }

    var search = h('input', {
      id: 'search', type: 'search', value: current.q, autocomplete: 'off', spellcheck: 'false',
      oninput: function () { current.q = search.value; update(); onState(current); }
    });
    var family = h('select', {
      id: 'family',
      onchange: function () { current.family = family.value; update(); onState(current); }
    }, S.FAMILIES.map(function (f) {
      return h('option', { value: f, selected: f === current.family }, f === 'all' ? 'All' : f);
    }));

    var title = h('h1', { tabindex: '-1' }, 'Cartridges');
    main.textContent = '';
    main.appendChild(h('section', { class: 'view list-view' },
      title,
      h('form', { class: 'controls', onsubmit: function (e) { e.preventDefault(); } },
        h('div', { class: 'field' }, h('label', { for: 'search' }, 'Search'), search),
        h('div', { class: 'field' }, h('label', { for: 'family' }, 'Family'), family),
        count),
      results));
    update();
    return { heading: title, footer: DATA_CREDIT };
  }

  /* ---- detail view ---- */

  function fact(label, content) {
    return [h('dt', null, label), h('dd', null, content)];
  }

  function factsList(r) {
    var ann = r.annotations || {};
    var cap = ann.publishedCapacity;
    var rows = [];
    if (r.alternativeNames && r.alternativeNames.length) rows.push(fact('Alternative names', r.alternativeNames.join(', ')));
    rows.push(fact('Family', r.family));
    rows.push(fact('Category', ann.category));
    rows.push(fact('Primer type', ann.primerType));
    rows.push(fact('C.I.P. table', r.tab));
    rows.push(fact('Country', r.country));
    rows.push(fact('Published', r.published));
    rows.push(fact('Revised', r.revised));
    rows.push(fact('Pressure method', r.pressureMethod));
    rows.push(fact('Water capacity', cap
      ? [F.formatNumber(cap.grH2O) + ' gr H2O ', /^https?:\/\//.test(cap.url || '')
        ? h('span', { class: 'src' }, '(source: ', h('a', { href: cap.url, rel: 'noopener noreferrer', target: '_blank' }, cap.source), ')')
        : h('span', { class: 'src' }, '(source: ' + cap.source + ')'),
      cap.note ? h('span', { class: 'note' }, cap.note) : null]
      : 'not published'));
    return h('dl', { class: 'facts' }, rows);
  }

  function valueTable(prefix, sec) {
    return h('table', { class: 'values' },
      h('caption', null, prefix + ' · ' + sec.title),
      h('thead', null, h('tr', null, h('th', { scope: 'col' }, 'Symbol'), h('th', { scope: 'col', class: 'num' }, 'Value'),
        h('th', { scope: 'col' }, 'Unit'))),
      h('tbody', null, sec.rows.map(function (row) {
        return h('tr', null, h('td', { class: 'sym' }, row.symbol), h('td', { class: 'num' }, row.value), h('td', { class: 'unit' }, row.unit));
      })));
  }

  function valueGroup(title, prefix, sections) {
    return h('section', { class: 'value-group' }, h('h2', null, title),
      h('div', { class: 'tables' }, sections.map(function (s) { return valueTable(prefix, s); })));
  }

  /** `drawingNode` (optional) is the drawing section built by the drawing module. */
  function renderDetail(main, record, drawingNode) {
    var tables = T.buildTables(record);
    var title = h('h1', { tabindex: '-1' }, record.name);
    main.textContent = '';
    main.appendChild(h('article', { class: 'view detail-view' },
      h('header', { class: 'detail-head' }, title,
        h('div', { class: 'actions' }, allCartridgesLink(),
          h('button', { type: 'button', onclick: function () { window.print(); } }, 'Print'))),
      factsList(record),
      drawingNode || null,
      valueGroup('Cartridge values', 'Cartridge', tables.cartridge),
      valueGroup('Chamber values', 'Chamber', tables.chamber)));
    return { heading: title, footer: 'Source: ' + SOURCE + ', revised ' + record.revised + '. ' + DATA_CREDIT };
  }

  function renderNotFound(main) {
    var title = h('h1', { tabindex: '-1' }, 'Cartridge not found');
    main.textContent = '';
    main.appendChild(h('section', { class: 'view' }, title,
      h('p', null, 'This address does not name a cartridge. ', allCartridgesLink())));
    return { heading: title, footer: DATA_CREDIT };
  }

  CIP.views = { renderList: renderList, renderDetail: renderDetail, renderNotFound: renderNotFound };
})(typeof globalThis !== 'undefined' ? globalThis : this);
