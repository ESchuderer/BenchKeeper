# Design

## Context

Greenfield, empty project in a dev container (Node 22). The app must open from `file://` in Chromium. Chromium blocks ES-module scripts and `fetch` of local files on `file://` (opaque origin), so the data and code are loaded as classic `<script>` files. The brief fixes the data, formatting and the drawing geometry rules; see the specs for behaviour. Coordinates in the brief's geometry rules are `(r, z)` (radius, axial position), e.g. `(R1/2, f)`.

## Goals / Non-Goals

**Goals:** pure, unit-testable modules (format, search, geometry, layout, SVG string) separate from the thin DOM layer; the same drawing code runs in Node tests and in the browser; deterministic output.

**Non-Goals:** editing data, unit conversion, bullet/powder ballistics, i18n, service worker/PWA, a build pipeline.

## Decisions

### D1. Classic scripts, one global namespace `CIP`, CommonJS-compatible tail
Each file is an IIFE that attaches to `globalThis.CIP` and, when `module.exports` exists, exports itself, so `node --test` can `require` the same files the page loads. *Alternative:* ES modules — rejected, blocked on `file://`. Data lives in `js/data.js` (`CIP.data = [...]`, one record per line) rather than a JSON fetch for the same reason.

### D2. Hash routing
`#/` lists, `#/?q=…&family=…` carries filter state, `#/cartridge/<key>` is a detail view. Works on `file://` and any server, survives reload and bookmarking, needs no server rewrite. Typing in Search updates the hash with `history.replaceState` (no history spam); opening a detail pushes an entry so Back restores the filter. The list view is rebuilt from the hash on every `hashchange`. After navigation focus moves to the `h1`.

### D3. Rendering
DOM built with a tiny `h(tag, attrs, children)` helper (text nodes only, no `innerHTML` with data). The drawing is produced as an SVG *string* by `drawing.js` (every text escaped; names contain `&`) and inserted with `insertAdjacentHTML`; this makes it testable in Node and printable.

### D4. Search normalisation
`key = lowercase(text).replace(',', '.')` with all whitespace removed. A record matches when the query key is a substring of the key of its name or of any alternative name. So `7,62 x 51`, `7.62x51` and `7,62X51` all find "308 Win.".

### D5. Table model
`js/tables.js` turns a record into sections. Section titles and field order are fixed lists; unknown fields are appended in record order. `<X>Tol` keys are removed from rows and appended to the cell of `X` (`39.62 -0.2`; positive tolerances get a `+`). Units come from one map (default mm; bar, J, g, mm², none for N, `°` for angles). Angle objects format as `d°m's"` with zero parts kept; number angles as `d°`. Numbers use JS `String(n)` so `4150.0` prints `4150`. Capacity unit: `gr H2O` (field `grH2O`).

### D6. Geometry module (`js/geometry.js`)
`buildModel(record)` returns `{ ok, notes, rimType, outer, mouth, bodyStart, groove, belt, shoulder, inner, section, bullet, pocket, w, walls, values }` with all coordinates as `(r, z)` pairs; the renderer maps `x = z`, `y = ∓r` (upper half = outside view, lower half = section). Arcs (rim half-round, shoulder fillets, ogive, ellipse) are tessellated into polylines (fixed segment counts) so all further code — hatching polygon, mirroring, collision tests, tests — works on points only.

Interpretations where the brief leaves room (each is mine, not the brief's):

1. **Chamfer angle.** `β` is measured to the axis, hence `f·tan β` is the radial extent, as written.
2. **Rimfire rim.** Half-round centre `(R1/2 − ρ, ρ)`; the arc spans `z = 0 … 2ρ`; then a step in to `P1/2` and, when `2ρ < R`, up to `z = R`. The body then starts at `z = R`.
3. **Groove needs `eMin`.** The brief's groove path uses `e min`; if E, E1 or `eMin` is missing, or `E <= R + eMin`, no groove is drawn and the note names the missing value. Belt needs `R3` and `δ`; if missing the belt is dropped but the plain groove is kept.
4. **Fillets.** Tangent arc between two lines of radius ρ; tangent length `d = ρ·tan(φ/2)` with turning angle φ, clamped to half of the shorter adjacent segment (a note says "limited" when that happens).
5. **Shoulder as bottleneck** needs `alpha, L1, L2, P2, H1` (and `H2`) in order `bodyStart < L1 < L2 < L3`; otherwise the case is drawn straight and the note names what is missing. `α` is never used to move a point — it is only the label and the angle marker.
6. **Heeled bullet.** The neck wall of a heeled case is `tb` (not `(H2−G1)/2 = 0`), so that the seated heel `H2 − 2·tb` fits exactly.
7. **Straight cases.** `tb` would make the cavity narrower than the seated bullet (e.g. 9 mm Luger: cavity 8.45 < G1 9.03). The wall therefore blends linearly from `tb` at `z = w` to `tn` at the bullet base `zb`, and is `tn` from `zb` to the mouth, so the bullet always fits. For bottleneck cases the brief's rule (tb to L1, blend to L2, tn to the mouth) is used as written.
8. **Section polygon.** One closed polygon: head face (from the pocket edge), outer profile, mouth face, inner line back to `z = w`, across to the axis, down the axis to the pocket bottom, across to the pocket wall.
9. **Bullet category.** Shapes `rounded`/`flat` use `annotations.category` (`pistol` vs. `rifle`/`rimfire`) for seating depth and cylinder fraction; if the category is absent the bullet is not drawn and the note says so.
10. **Missing-value notes** are produced for every feature whose inputs are incomplete. A case that publishes none of α, L1, L2, P2, H1 is straight by design (rule 4) and gets no shoulder note; a partly published set does.
11. **Belted solid head.** The rule's "E + tb where a groove exists, *or* belt ramp end + tb on belted cases" is read as alternatives: with a drawn belt the ramp end replaces E in the maximum (300 Win. Mag.: head to z = 4.8 from the pocket, not 5.59 + tb).
12. **Chamfer guard.** The chamfer is drawn only when `0 < f < R` in addition to the rule's "beta and f published, beta < 90°" (otherwise the profile would run backwards).
13. **Unusable values.** Core values (R1, R, P1, L3) and every dimension used by a rule must be positive numbers; strings, `null`, zero and negatives count as missing. A body start at or beyond L3 makes the drawing unavailable. A drawing that cannot be built is replaced by a note; `NaN`/`Infinity` never reach the SVG.

### D7. Dimension layout (`js/layout.js`)
Axial dimensions (L1, L2, R above; L3, L6 below) sit on stacked lanes outside the outline, `R1` to the left of the head, diameters P1, E1, P2, H1, H2, G1 as vertical dimension lines at the z where the diameter is measured (end ticks are the extension lines). Arrowheads are explicit polygons (no `<marker>`, so print and Node tests see them). When a span is shorter than two arrowheads the arrows point inwards from outside. α is shown as the cone's included angle at the body-side shoulder corner: the real shoulder line, its mirror image about a line parallel to the axis (dashed), and an arc between them, spanning α.

Label placement is a greedy search over a grid of candidate rectangles ordered by distance to the label's anchor, accepting the first rectangle that intersects no obstacle (outline polylines, dimension/extension lines, centre line, title block, labels placed so far) with a clearance margin; when the accepted rectangle is not adjacent to the line a thin leader joins them. Label width is estimated from a monospace stack (`0.6 em` per character) so layout is identical in Node and browser; the browser test cross-checks with `getBBox`. *Alternative:* fixed offsets per dimension — rejected, the neck zone of bottleneck cases is too crowded for fixed slots.

### D8. Scale and print
`viewBox` = bounding box of geometry + labels + title block + margins, widened to an aspect ratio of at least 1.7 : 1 so that small cartridges (22 LR) do not become taller than an A4 page when printed at full width. The title block holds two scale texts: the print one is computed (`PRINT_WIDTH_MM / viewBoxWidth`, `PRINT_WIDTH_MM = 186` equals the CSS print width of the drawing), the screen one is updated from the rendered width by a `ResizeObserver`; CSS shows one per media type. Font size in drawing units is chosen so that labels are ≥ 6 pt at A4 print (≥ 2.8 units at the smallest scale) and still readable on a phone.

### D9. Print
`css/print.css` (`media="print"`) forces the light palette, hides navigation/controls, sets `@page { size: A4 portrait; margin: 10mm }`, lays tables out in four CSS columns and prints the footer "Source: C.I.P. TDCC, revised …". A Playwright test prints all 25 detail views to PDF and asserts one page each.

### D10. Colour and type
CSS custom properties; `prefers-color-scheme: dark` overrides; `font-variant-numeric: tabular-nums`; system font stacks only (sans for UI, monospace for numbers and drawing labels). Drawing strokes and the hatch pattern use the same variables, so the drawing follows the theme.

### D11. Testing and environment
Unit tests with `node:test` (no dependencies). Browser tests with the Playwright library as an npm dev dependency, run against `file://` and an in-process static server. In this container the Chromium shared libraries are missing; they are unpacked into a user-writable directory and exposed through `LD_LIBRARY_PATH` (documented in the README; not part of the app).

## Risks / Trade-offs

- **Label crowding in the neck zone** → grid search with leaders; the no-overlap test runs over all 25 records, and screenshots are inspected.
- **Estimated text width vs. real fonts** → monospace stack and a generous clearance; `getBBox` cross-check in the browser test.
- **The brief's wall rule is wrong for straight cases** → D6.7, stated openly.
- **Geometry interpretations** (D6) are my reading of the rules; they are listed so they can be corrected.
- **`1 cartridges`** is shown literally as "<n> cartridges" as the brief words it.
- **Playwright-only browser checks** use headless Chromium; real print dialogs cannot be driven, so print is checked via `page.pdf` and print media emulation.
