# Proposal

## Why

Reloaders, gunsmiths and engineers who look up C.I.P. cartridge data need a dense, fast, offline reference where every published dimension, tolerance and pressure sits next to a true-to-scale drawing computed from those same numbers. The OpenBallistics cartridge database has the data (25 records here) but no self-contained viewer that can be opened from a file, bookmarked per cartridge and printed as one A4 sheet.

## What Changes

- New static web app (`index.html` + CSS + JS, no framework, no build, no network) that ships the 25 supplied records unchanged.
- Start page: heading "Cartridges", list with name / family / case length L3, live search over name and alternative names, family filter, result count.
- Detail view per cartridge with its own bookmarkable address: designation facts, a generated 2D drawing, tables of all cartridge and chamber values (Symbol / Value / Unit) with tolerances shown beside their value.
- Generated inline SVG drawing at 1 SVG unit = 1 mm: outside view above the axis, hatched section below, dimension lines with extension lines and arrowheads, non-overlapping labels, title block, and a visible note whenever a value needed for a feature is missing.
- Print: one A4 portrait, black-on-white page per cartridge (header, full-width drawing, tables, source footer) without navigation or buttons.
- Light and dark themes following the system setting; print always light; usable on a phone.
- Dev-only tooling: `node:test` unit tests and Playwright end-to-end tests (npm dev dependencies; the app never needs them).

## Capabilities

### New Capabilities
- `cartridge-catalogue`: start page listing, text search, family filter and result count.
- `cartridge-detail`: per-cartridge address, designation facts, value tables, number/angle/tolerance formatting, Print and back actions.
- `cartridge-drawing`: the generated true-to-scale SVG (profile geometry, bullet, section, dimensions, labels, title block, missing-value notes, responsiveness).
- `print-layout`: the one-page A4 printed form of a detail view.
- `app-delivery`: offline/`file://` operation, no network or runtime dependencies, theming, data fidelity.

### Modified Capabilities
<!-- None: greenfield project, openspec/specs is empty. -->

## Impact

- New files in the project root: `index.html`, `css/`, `js/`, `test/`, `package.json` (dev dependencies only), `README.md`.
- No existing code or specs are affected.
- Data is the given OpenBallistics extract (MIT, commit e83db43); it is embedded verbatim and neither extended nor fetched.
