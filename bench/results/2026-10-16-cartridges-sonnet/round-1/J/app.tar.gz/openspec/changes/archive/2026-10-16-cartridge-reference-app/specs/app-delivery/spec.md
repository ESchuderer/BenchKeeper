# Spec Delta

## Purpose

The app is a self-contained static site that behaves identically when opened from disk or served, makes no network requests, and presents a calm, dense technical reference in light and dark.

## ADDED Requirements

### Requirement: Static files only
The app SHALL consist of `index.html` in the project root with plain CSS and JavaScript files, with no framework, no build step, no server code, no runtime dependency and no network request (no CDN, web font or analytics).

#### Scenario: No requests
- **WHEN** any page of the app is opened
- **THEN** every request the browser makes is for a local file or a data URL

### Requirement: Runs from disk and from a server
The app SHALL work fully when `index.html` is opened directly from disk in Chromium (`file://`) and when the folder is served by a static file server.

#### Scenario: From disk
- **WHEN** `index.html` is opened via a `file://` URL
- **THEN** the list, search, filter, detail views, drawings and reload all work

#### Scenario: From a server
- **WHEN** the folder is served over HTTP
- **THEN** the same behaviour holds

### Requirement: Data fidelity
The app SHALL embed exactly the 25 supplied records, unchanged, and SHALL NOT add, change or fetch data.

#### Scenario: Record count and keys
- **WHEN** the embedded data is inspected
- **THEN** it holds 25 records with the keys of the brief (223_rem ... 17_hmr), each deeply equal to the supplied JSON

### Requirement: Theming
On screen the app SHALL follow the system light or dark setting, with calm colours, tabular figures for numbers and sufficient contrast; the drawing SHALL follow the theme.

#### Scenario: Dark
- **WHEN** the system prefers a dark colour scheme
- **THEN** page and drawing use light-on-dark colours

### Requirement: Phone usability
The interface SHALL be usable at 360 px width without horizontal scrolling: controls reachable, tables readable, drawing scaled to width.

#### Scenario: No horizontal scroll
- **WHEN** the start page and a detail view are rendered at 360 px width
- **THEN** the document is not wider than the viewport

### Requirement: Accessibility basics
Controls SHALL have visible labels, the list count SHALL be announced as a status, links SHALL be real links, and the focus SHALL move to the page heading after navigation.

#### Scenario: Labelled controls
- **WHEN** the start page is shown
- **THEN** the field "Search" and the select "Family" can be found by their labels
