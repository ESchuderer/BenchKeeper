# Spec Delta

## Purpose

The detail view presents everything published about one cartridge: its designation facts, a generated drawing and all cartridge and chamber values, at an address that can be bookmarked.

## ADDED Requirements

### Requirement: Detail address
Each cartridge SHALL have its own address that opens its detail view directly, survives a reload and works from `file://`. An unknown address SHALL show a "not found" message with a link "All cartridges".

#### Scenario: Reload
- **WHEN** the detail view of "308 Win." is open and the page is reloaded
- **THEN** the detail view of "308 Win." is shown again

#### Scenario: Bookmark
- **WHEN** the address of a detail view is opened in a new tab
- **THEN** that cartridge is shown without visiting the start page first

#### Scenario: Unknown address
- **WHEN** an address names no cartridge
- **THEN** a message says the cartridge was not found and the link "All cartridges" is offered

### Requirement: Designation facts
The detail view SHALL have the cartridge name as its level-one heading, followed by alternative names (when published), family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method and the published water capacity with a link to its source.

#### Scenario: Facts of "308 Win."
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the heading is "308 Win."
- **AND** alternative names "308 Winchester" and "7,62 x 51", family "rimless", category "rifle", primer type "lr", table "I", country "US", published "1984-06-14", revised "2008-09-23" and pressure method "Transducer" are shown
- **AND** the water capacity "56" with the link text of its source ("kwk") pointing at the published URL is shown

#### Scenario: No published capacity
- **WHEN** the detail view of "7 x 64" is shown
- **THEN** the water capacity reads "not published" and no source link is shown

### Requirement: Value tables
The detail view SHALL list all cartridge values and all chamber values in tables grouped by section (for example Case head, Lengths, Pressures), each table having the columns "Symbol", "Value" and "Unit". Empty sections SHALL be omitted.

#### Scenario: Sections
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** the cartridge values include tables for Case head, Powder chamber, Collar, Junction cone, Lengths, Projectile, Pressures and Miscellaneous, and the chamber values include Breech, Powder chamber, Collar, Junction cone, Lengths, Barrel, Grooves and Rifling
- **AND** every table has the column headers "Symbol", "Value", "Unit"

#### Scenario: Empty section omitted
- **WHEN** the detail view of "9 mm Luger" is shown
- **THEN** no Junction cone table is shown

### Requirement: Symbols and units
Symbols SHALL be the field name except eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L" and L3PlusG "L3 + G". Units SHALL be mm for lengths and diameters, bar for Pmax, PK and PE, J for EE, g for M, mm² for Q, none for N, and ° for angles.

#### Scenario: Units
- **WHEN** the tables of "223 Rem." are shown
- **THEN** the row Pmax shows value "4300" and unit "bar", EE shows "J", M shows "g", Q shows "mm²", N shows no unit, β shows "°" and L3 shows "mm"

#### Scenario: Symbols
- **WHEN** the row for the field `L3PlusG` is shown
- **THEN** its symbol is "L3 + G"

### Requirement: Values as published
Numbers SHALL be shown with a decimal point, no thousands separator and no added or removed digits beyond what the number needs (4150.0 as "4150", 51.18 as "51.18"). An angle given as a number SHALL be shown as `40°`; an angle given as degrees, minutes and seconds as `39°59'49"`, keeping zero parts (`34°30'0"`). Names SHALL be shown as published.

#### Scenario: Angle formats
- **WHEN** the table of "6,5 x 55 SE" is shown
- **THEN** α reads `50°35'2"`
- **AND** for "243 Win." the shoulder α reads `40°`

#### Scenario: Plain number angle
- **WHEN** the table of "7 mm Rem. Mag." is shown
- **THEN** the rifling twist angle i reads `3°`

### Requirement: Tolerances
A field `<X>Tol` SHALL be shown next to the value of X in the same cell (for example `39.62 -0.2`) and never as a row of its own.

#### Scenario: Tolerance beside value
- **WHEN** the Lengths table of "223 Rem." is shown
- **THEN** the L1 row's value reads "36.52 -0.2"
- **AND** no row has the symbol "L1Tol" or "L2Tol"

#### Scenario: No tolerance published
- **WHEN** the Lengths table of "308 Win." is shown
- **THEN** the L1 row's value reads "39.62" and the L2 row's value reads "43.48 -0.2"

### Requirement: Page actions
The detail view SHALL offer a button "Print" that opens the browser's print dialog and a link "All cartridges" that returns to the start page.

#### Scenario: Print button
- **WHEN** the user presses "Print"
- **THEN** the browser's print function is invoked

#### Scenario: Back to list
- **WHEN** the user follows "All cartridges"
- **THEN** the start page with 25 cartridges is shown
