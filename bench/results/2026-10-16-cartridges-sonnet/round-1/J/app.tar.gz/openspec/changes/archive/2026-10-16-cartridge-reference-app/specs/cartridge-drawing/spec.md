# Spec Delta

## Purpose

Each detail view carries a 2D drawing computed only from that record's published values, true to scale, so the geometry can be read and measured directly. Where a value is missing the drawing leaves the feature out and says so; it never invents a number.

## ADDED Requirements

### Requirement: Drawing frame
The drawing SHALL be an inline SVG with one SVG user unit equal to 1 mm, the axis horizontal and the head on the left, with the accessible name "<name> drawing". The upper half SHALL be the outside view, the lower half a section with cut walls hatched, and a dash-dot centre line SHALL mark the axis.

#### Scenario: Name and scale
- **WHEN** the detail view of "308 Win." is shown
- **THEN** an element with role img named "308 Win. drawing" is present
- **AND** the case length L3 = 51.18 spans 51.18 user units from the head face to the mouth along the horizontal axis

#### Scenario: Halves
- **WHEN** the drawing is rendered
- **THEN** outline geometry mirrored about the axis appears above and below it, hatched wall areas appear only below it, and a dash-dot line lies on the axis

### Requirement: Rim type
The rim type SHALL be belted for family `belted`, rimfire for family `rimfire`, otherwise rimmed when R1/P1 >= 1.05, rebated when R1/P1 < 0.98 and rimless in between.

#### Scenario: Classification
- **WHEN** the rim type is derived for "300 Win. Mag.", "22 Long Rifle", "38 Special" and "308 Win."
- **THEN** the results are belted, rimfire, rimmed (11.18 / 9.63 = 1.16) and rimless (12.01 / 11.96 = 1.004)

### Requirement: Head face and rim edge
The outer half-profile SHALL start on the axis at the head face (r = 0, z = 0). Where beta and f are published and beta < 90° it SHALL continue along a chamfer from (R1/2 - min(f·tan β, R1/4), 0) to (R1/2, f) and then to (R1/2, R); on a rimfire case the rim edge SHALL be a half-round of radius min(R/2, (R1 - P1)/2) whose outermost point lies at R1/2; otherwise the corner SHALL be square.

#### Scenario: Chamfer
- **WHEN** the profile of "308 Win." is built
- **THEN** it contains the points (r, z) = (0, 0), (5.739, 0), (6.005, 0.38), (6.005, 1.37) in this order, to three decimals

#### Scenario: Half-round rim
- **WHEN** the profile of "22 Long Rifle" is built
- **THEN** the rim edge is an arc of radius 0.545 whose largest r is 3.53

#### Scenario: Square corner
- **WHEN** a record without beta and f is drawn
- **THEN** the head face runs to (R1/2, 0) and then straight to (R1/2, R)

### Requirement: Extractor groove and belt
Where E and E1 are published (with eMin, which fixes the groove floor) the profile SHALL run from (R1/2, R) in to (E1/2, R), along the floor to (E1/2, R + eMin) and by a straight ramp to (P1/2, E). On belted cases the ramp SHALL leave the floor end at angle δ to the axis up to R3/2, follow the belt to z = E and step in to P1/2. Without a groove the profile SHALL step in from (R1/2, R) to (P1/2, R).

#### Scenario: Groove
- **WHEN** the profile of "308 Win." is built
- **THEN** after (6.005, 1.37) it contains (5.195, 1.37), (5.195, 2.77) and (5.98, 3.85)

#### Scenario: Belt
- **WHEN** the profile of "300 Win. Mag." is built
- **THEN** it contains (6.035, 2.21), the belt-ramp end (6.755, 3.238), the belt end (6.755, 5.59) and the step to (6.515, 5.59), to three decimals

#### Scenario: No groove
- **WHEN** the profile of "38 Special" is built
- **THEN** after (R1/2, R) it steps in to (P1/2, R) and notes that E, E1 and e min are not published

### Requirement: Body, shoulder and neck
A bottleneck case (alpha, L1, L2, P2 and H1 published) SHALL have a straight body line from P1/2 at the body start to (P2/2, L1), the shoulder line from (P2/2, L1) to (H1/2, L2) drawn through those published points, and the neck from (H1/2, L2) to (H2/2, L3). The body-side corner SHALL be rounded with r1 min and the neck-side corner with r2 where published. A case without alpha, L1 or L2 SHALL be straight, its body running to (H2/2, L3).

#### Scenario: Bottleneck points
- **WHEN** the profile of "308 Win." is built
- **THEN** the shoulder line runs through the published points (5.765, 39.62) and (4.36, 43.48), its corners are rounded by tangent arcs of radius 0.76 (body side) and 3.18 (neck side), and the profile ends at (4.36, 51.18)

#### Scenario: Straight case
- **WHEN** the profile of "9 mm Luger" is built
- **THEN** its body runs from (4.965, 2.98), the end of the groove ramp, to (4.825, 19.15) without a shoulder

#### Scenario: Missing fillet radius
- **WHEN** the record has no r1Min
- **THEN** the body-side corner stays sharp and a note says r1 min is missing

### Requirement: Bullet
The drawing SHALL include a bullet from the mouth to its tip at z = L6 with shank diameter G1 and the nose shape named by `annotations.defaultBulletShape`: tangent ogive for pointy, quarter ellipse for rounded, straight cone for flat and semi_wadcutter, ending in a flat meplat. Seating depth and cylinder length follow the rules recorded in the design. The outside view SHALL hide the seated part; the section SHALL show it inside the case.

#### Scenario: Pointy bullet of "308 Win."
- **WHEN** the bullet is built for "308 Win." (G1 7.85, L6 71.12, L3 51.18)
- **THEN** seating depth is 7.85, the base is at z = 43.33, the cylinder ends at z = 54.446, the meplat diameter is 1.27 and the tip is at z = 71.12

#### Scenario: Rounded pistol bullet
- **WHEN** the bullet is built for "9 mm Luger"
- **THEN** seating depth is 0.4·9.03 = 3.612 and the cylinder ends at 65 % of the bullet length


#### Scenario: Outside view hides the seated part
- **WHEN** the drawing is rendered
- **THEN** the upper half contains no bullet geometry at z < L3 and the lower half shows the bullet base at z = L3 - s

### Requirement: Heeled bullet
On a heeled case (H2 - G1 <= 0.015, for example 22 Long Rifle) the exposed bullet SHALL have the case's outside diameter and the seated heel the case's inside diameter H2 - 2·tb.

#### Scenario: Heeled
- **WHEN** the bullet of "22 Long Rifle" is built
- **THEN** it is heeled, the exposed radius is 2.86 and the seated heel radius is 2.26

### Requirement: Section walls and solid head
The section SHALL use a neck wall tn = (H2 - G1)/2 and a body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2), the inner line following the outer body, shoulder and neck at these walls and blending linearly across the shoulder. The solid head SHALL run from the head face to z = w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or belt ramp end + tb on belted cases).

#### Scenario: Walls of "308 Win."
- **WHEN** the section of "308 Win." is built
- **THEN** tn = 0.435, tb = 0.6 and w = 4.8 (pocket 5.33 × 3.3)

#### Scenario: Seated bullet fits
- **WHEN** the section of any of the 25 records is built
- **THEN** the inner wall radius is never smaller than the radius of the seated bullet at the same z

### Requirement: Primer pocket
Centrefire cases SHALL show a primer pocket in the head: diameter 4.45 for primer types sp, spm, sr and 5.33 for lp, lpm, lr, lrm; depth 3.04 for sp, spm, sr, lp, lpm and 3.3 for lr, lrm. Rimfire cases SHALL have none.

#### Scenario: Pocket size
- **WHEN** the section of "9 mm Luger" (primer sp) is built
- **THEN** the pocket is 4.45 wide and 3.04 deep

#### Scenario: Rimfire
- **WHEN** the section of "17 HMR" is built
- **THEN** no primer pocket is present

### Requirement: Dimensions
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value, such as "L3 51.18". Labels SHALL NOT overlap one another or the outline.

#### Scenario: Labels present
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** it contains the labels "L3 51.18", "L6 71.12", "R1 12.01", "R 1.37", "P1 11.96", "P2 11.53", "H1 8.72", "H2 8.72", "G1 7.85", "L1 39.62", "L2 43.48", "E1 10.39" and the shoulder angle label "α 40°"

#### Scenario: Unpublished dimensions are omitted
- **WHEN** the drawing of "9 mm Luger" is rendered
- **THEN** there are no labels for P2, H1, L1, L2 or α

#### Scenario: No overlaps
- **WHEN** the drawings of all 25 records are laid out
- **THEN** no label rectangle intersects another label rectangle, the outline, a dimension line or an extension line

### Requirement: Title block
The drawing SHALL contain a title block with the cartridge name, its C.I.P. table and revision date, the text "Dimensions in mm" and the scale.

#### Scenario: Title block text
- **WHEN** the drawing of "308 Win." is rendered
- **THEN** its title block shows "308 Win.", "C.I.P. table I", "Revised 2008-09-23", "Dimensions in mm" and a scale such as "Scale 2.1:1"

### Requirement: Missing values
When a value that a drawing rule needs is missing, the drawing SHALL leave that feature out, SHALL list which value is missing in a note shown with the drawing, and SHALL NOT substitute a number.

#### Scenario: Note for the missing value
- **WHEN** the drawing of "308 Win." is rendered from a record without f
- **THEN** the head face is square and a note says the rim chamfer is not drawn because f is missing

#### Scenario: Chamfer not relevant on rimfire
- **WHEN** the drawing of "22 Long Rifle" (rimfire, no f) is rendered
- **THEN** the rim edge is the half-round and no chamfer note is shown

#### Scenario: Straight by design
- **WHEN** the drawing of "9 mm Luger" is rendered
- **THEN** no note about a missing shoulder is shown, because a case without any shoulder value is straight by rule

#### Scenario: Unusable values
- **WHEN** a record has L3 = 0, a groove at E beyond L3, or a string where a number is expected
- **THEN** the drawing is replaced by a note naming the value, and no NaN or Infinity appears in any output

#### Scenario: Synthetic record
- **WHEN** a record without G1 is drawn
- **THEN** no bullet and no section walls are drawn and the notes name G1

### Requirement: Scaling
The SVG SHALL scale to the width of its container, down to the width of a phone screen, keeping its aspect ratio, and SHALL keep every label legible at A4 print width.

#### Scenario: Phone width
- **WHEN** the viewport is 360 px wide
- **THEN** the drawing's rendered width does not exceed the viewport and no horizontal scrolling appears
