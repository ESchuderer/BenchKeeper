# Tasks

## 1. Scaffold and data

- [x] 1.1 Create `package.json` (dev deps: playwright), `.gitignore`, folder layout; verify `npm test` runs (zero tests passing is fine) and `npm ls` shows only dev dependencies
- [x] 1.2 Write `js/data.js` with the 25 records verbatim and `test/unit/data.test.js` (25 records, expected keys in order, per-family counts 12/2/2/6/3, spot checks of values incl. angle objects and `Tol` fields); verify the test passes

## 2. Formatting and tables

- [x] 2.1 Test first, then implement `js/format.js` (number, angle, tolerance, date, unit and symbol maps); verify `node --test test/unit/format.test.js` covers `4150`, `51.18`, `40°`, `39°59'49"`, `34°30'0"`, `39.62 -0.2` and every special symbol
- [x] 2.2 Test first, then implement `js/tables.js` (sections, order, tolerance merging, empty sections omitted, units); verify tests for 223 Rem., 9 mm Luger (no junction cone), 308 Win. (no tolerance rows)

## 3. Catalogue and detail views

- [x] 3.1 Test first, then implement `js/search.js` (normalisation, name + alternative names, family filter, count); verify the `7,62 x 51` → 308 Win. scenarios and the belted/pistol counts
- [x] 3.2 Implement `index.html`, `css/app.css`, `js/dom.js`, `js/views.js`, `js/app.js` (router, list view, detail view without drawing, focus, titles); verify with a Playwright test over `file://`: list, search, filter, count, links, reload on a detail address, unknown address, Back keeps filter, labelled controls
- [x] 3.3 Detail facts, capacity link, value tables, Print button (`window.print` stub in test) and "All cartridges" link; verify with Playwright (facts of 308 Win., 7 x 64 capacity, tolerance cell, units, angle cells)

## 4. Drawing geometry

- [x] 4.1 Test first, then implement `js/geometry.js` rim type, head face/rim edge (chamfer, half-round, square), groove and belt, body/shoulder/neck with fillets, straight cases; verify with the numeric scenarios of the spec (308 Win., 300 Win. Mag., 22 LR, 9 mm Luger, 38 Special)
- [x] 4.2 Test first, then implement bullet geometry (seating, cylinder, ogive/ellipse/cone, meplat, heeled) and section (walls, head `w`, pocket, polygon, inner line); verify spec scenarios and the invariant "inner wall radius ≥ seated bullet radius" over all 25 records
- [x] 4.3 Missing-value behaviour: notes for every skipped feature, never a substituted number; verify with synthetic records (no G1, no f, no r1Min, no E/E1/eMin, no L6, unknown primer type)

## 5. Drawing layout and SVG

- [x] 5.1 Implement `js/layout.js` (dimension primitives with arrowheads and extension lines, lanes, α marker, label placement with leaders, text-width estimate); verify unit tests: expected label set per record, no overlap of labels with each other, outline, dimension lines and extension lines for all 25 records
- [x] 5.2 Implement `js/drawing.js` (SVG string: accessible name, centre line, hatch, outline, section, bullet, dimensions, title block with print and screen scale, viewBox with minimum aspect ratio); verify unit tests on the string (role img, aria-label, 1 unit = 1 mm via L3 span, escaped `&` in "40 S.& W.") and visually by rendering all 25 drawings to PNG and inspecting them
- [x] 5.3 Wire the drawing and the missing-value notes into the detail view; styles for light/dark; `ResizeObserver` screen scale; verify with Playwright: accessible name, labels of 308 Win., no label overlap by `getBBox`, 360 px width without horizontal scroll

## 6. Print

- [x] 6.1 Implement `css/print.css` and the print footer; verify with Playwright print emulation: hidden controls, white background in dark scheme, drawing width = content width, smallest label ≥ 6 pt, scale text consistent with width
- [x] 6.2 Verify with `page.pdf` (A4 portrait) that all 25 detail views are exactly one page, and inspect rendered PDF pages of three cartridges

## 7. Integration and review

- [x] 7.1 Offline and `file://` checks: no non-local requests during a full tour of all 25 views; serve the folder with a static server and rerun the browser suite; verify both pass
- [x] 7.2 Phone and dark-mode screenshots (360 px, light and dark) of list and detail inspected; README with run/test instructions and the environment note; verify README commands work as written
- [x] 7.3 Run the full test suite and `openspec validate`; request an independent code review of the whole change, fix findings and re-run the suite

## Workflow follow-up

- Archive the change after review (`openspec archive`).
