# cartridge-catalogue Specification

## Purpose
The start page lets a user scan all 25 cartridges and narrow them by text or family, then open one. It is the entry point of the reference.

## Requirements

### Requirement: Cartridge list
The start page SHALL show the heading "Cartridges" and every cartridge with its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name`, opening that cartridge's detail view.

#### Scenario: Initial list
- **WHEN** the start page is opened
- **THEN** the heading "Cartridges" is shown and 25 links are listed, one per record, in record order
- **AND** the link text of the first is exactly "223 Rem." and of the third exactly "6,5 Creedmoor"
- **AND** the row of "308 Win." shows family "rimless" and L3 "51.18"

#### Scenario: Opening a cartridge
- **WHEN** the user follows the link "270 Win."
- **THEN** the detail view of "270 Win." is shown

### Requirement: Text search
A field labelled "Search" SHALL filter the list as the user types, matching the record's name and alternative names, ignoring case, spaces and the difference between decimal comma and decimal point.

#### Scenario: Alternative name
- **WHEN** the user types "7,62 x 51" into "Search"
- **THEN** only "308 Win." is listed

#### Scenario: Case and spacing
- **WHEN** the user types "7.62X51"
- **THEN** only "308 Win." is listed

#### Scenario: Name match
- **WHEN** the user types "creed"
- **THEN** only "6,5 Creedmoor" is listed

#### Scenario: No match
- **WHEN** the user types "zzz"
- **THEN** no cartridge is listed, "0 cartridges" is shown and a message says that nothing matches

### Requirement: Family filter
A select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire SHALL restrict the list to that family; it SHALL combine with the search text.

#### Scenario: Single family
- **WHEN** the user selects "belted"
- **THEN** exactly "300 Win. Mag." and "7 mm Rem. Mag." are listed

#### Scenario: Combined with search
- **WHEN** the user selects "rimless" and types "win"
- **THEN** only the rimless cartridges whose name or alternative names contain "win" are listed

### Requirement: Result count
The page SHALL show the text "<n> cartridges" with the number of listed cartridges, updated with every change of search or family.

#### Scenario: Count updates
- **WHEN** the start page is opened
- **THEN** "25 cartridges" is shown
- **AND WHEN** the user selects "pistol" the text is "6 cartridges"

### Requirement: Filter state in the address
The search text and family SHALL be kept in the page address so that the browser's back button from a detail view returns to the same filtered list, while the link "All cartridges" opens the unfiltered list.

#### Scenario: Back keeps the filter
- **WHEN** the user filters to "belted", opens "300 Win. Mag." and goes back
- **THEN** the "Family" select shows "belted" and "2 cartridges" is shown
