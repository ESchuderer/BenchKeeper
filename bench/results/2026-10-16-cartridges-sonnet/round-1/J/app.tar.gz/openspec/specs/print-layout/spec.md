# print-layout Specification

## Purpose
A detail view can be printed as a single A4 sheet that works as a stand-alone data card: black on white, drawing first, then the tables, with its source named.

## Requirements

### Requirement: One A4 page
A printed detail view SHALL fit on one A4 portrait page for every one of the 25 cartridges.

#### Scenario: Page count
- **WHEN** the detail view of any cartridge is printed to PDF at A4 portrait
- **THEN** the PDF has exactly one page

### Requirement: Print content and order
The printed page SHALL start with a page header carrying the cartridge name, followed by the drawing at full content width with every label legible, then the designation facts and the value tables. Navigation, the search and filter controls, the "Print" button and the "All cartridges" link SHALL NOT be printed.

#### Scenario: Hidden controls
- **WHEN** the page is rendered with print media
- **THEN** the "Print" button, the "All cartridges" link and any search field are not displayed

#### Scenario: Drawing width
- **WHEN** the page is rendered with print media at A4 portrait
- **THEN** the drawing is as wide as the page's content area and its smallest label text is at least 6 pt high

### Requirement: Print colours
Print output SHALL be black on white regardless of the system theme, with no coloured fills.

#### Scenario: Dark system theme
- **WHEN** the system prefers a dark colour scheme and the page is rendered with print media
- **THEN** the page background is white and the text and drawing lines are black

### Requirement: Print footer
The printed page SHALL end with a footer naming the source: "Source: C.I.P. TDCC, revised <revised date>".

#### Scenario: Footer text
- **WHEN** the detail view of "223 Rem." is printed
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2017-05-17"

### Requirement: Printed scale
The scale named in the drawing's title block SHALL be true for the printed drawing, that is the drawing's printed width divided by the width in mm of its content.

#### Scenario: Scale text matches paper
- **WHEN** the detail view of "308 Win." is printed
- **THEN** the title block scale equals printed drawing width in mm divided by the drawing's viewBox width, rounded to one decimal
