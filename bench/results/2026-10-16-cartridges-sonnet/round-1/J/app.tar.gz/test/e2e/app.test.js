'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, appBase } = require('./helpers.js');

let browser, app, page;
const errors = [];

test.before(async () => {
  browser = await launch();
  app = await appBase();
});
test.after(async () => { await browser.close(); app.close(); });
test.beforeEach(async () => {
  page = await browser.newPage();
  errors.length = 0;
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
});
test.afterEach(async () => {
  await page.close();
  assert.deepEqual(errors, [], 'no page or console errors');
});

const count = async () => (await page.getByRole('status').first().textContent()).trim();
const h1 = async (text) => {
  const loc = page.getByRole('heading', { level: 1, name: text, exact: true });
  await loc.waitFor();
  return loc.textContent();
};
const names = async () => page.locator('main table a').allTextContents();

test('start page: heading, 25 links, count', async () => {
  await page.goto(app.base);
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges');
  const n = await names();
  assert.equal(n.length, 25);
  assert.equal(n[0], '223 Rem.');
  assert.equal(n[2], '6,5 Creedmoor');
  assert.equal(await count(), '25 cartridges');
});

test('start page: each row shows family and L3', async () => {
  await page.goto(app.base);
  const row = page.locator('main table tbody tr', { has: page.getByRole('link', { name: '308 Win.', exact: true }) });
  const text = await row.textContent();
  assert.match(text, /rimless/);
  assert.match(text, /51\.18/);
  const luger = await page.locator('main table tbody tr', { has: page.getByRole('link', { name: '9 mm Luger' }) }).textContent();
  assert.match(luger, /19\.15 -0\.25/);
});

test('search by alternative name filters as typed', async () => {
  await page.goto(app.base);
  await page.getByLabel('Search').pressSequentially('7,62 x 51');
  assert.deepEqual(await names(), ['308 Win.']);
  assert.equal(await count(), '1 cartridges');
  await page.getByLabel('Search').fill('creed');
  assert.deepEqual(await names(), ['6,5 Creedmoor']);
});

test('no match: 0 cartridges and a message', async () => {
  await page.goto(app.base);
  await page.getByLabel('Search').fill('zzz');
  assert.equal(await count(), '0 cartridges');
  assert.deepEqual(await names(), []);
  assert.match(await page.locator('main').textContent(), /No cartridge matches/);
});

test('family filter, combined with search', async () => {
  await page.goto(app.base);
  const sel = page.getByLabel('Family');
  assert.deepEqual(await sel.locator('option').allTextContents(), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  await sel.selectOption({ label: 'belted' });
  assert.deepEqual(await names(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  await sel.selectOption({ label: 'pistol' });
  assert.equal(await count(), '6 cartridges');
  await sel.selectOption({ label: 'rimless' });
  await page.getByLabel('Search').fill('win');
  assert.deepEqual(await names(), ['243 Win.', '270 Win.', '308 Win.']);
});

test('opening a cartridge, reload and bookmark', async () => {
  await page.goto(app.base);
  await page.getByRole('link', { name: '270 Win.', exact: true }).click();
  assert.equal(await h1('270 Win.'), '270 Win.');
  const url = page.url();
  assert.match(url, /#\/cartridge\/270_win$/);
  await page.reload();
  assert.equal(await h1('270 Win.'), '270 Win.');
  const other = await browser.newPage();
  await other.goto(url);
  await other.getByRole('heading', { level: 1, name: '270 Win.' }).waitFor();
  await other.close();
});

test('unknown address shows not found with a way back', async () => {
  await page.goto(app.base + '#/cartridge/nope');
  assert.match(await page.locator('main').textContent(), /not found/i);
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await count(), '25 cartridges');
});

test('Back from a detail view keeps the filter; "All cartridges" clears it', async () => {
  await page.goto(app.base);
  await page.getByLabel('Family').selectOption({ label: 'belted' });
  await page.getByRole('link', { name: '300 Win. Mag.' }).click();
  await page.goBack();
  assert.equal(await page.getByLabel('Family').inputValue(), 'belted');
  assert.equal(await count(), '2 cartridges');
  await page.getByRole('link', { name: '300 Win. Mag.' }).click();
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await count(), '25 cartridges');
  assert.equal(await page.getByLabel('Family').inputValue(), 'all');
});

test('filter state is in the address and restored on load', async () => {
  await page.goto(app.base + '#/?q=win&family=rimless');
  assert.equal(await page.getByLabel('Search').inputValue(), 'win');
  assert.deepEqual(await names(), ['243 Win.', '270 Win.', '308 Win.']);
});

test('focus moves to the heading and the title follows navigation', async () => {
  await page.goto(app.base);
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await h1('308 Win.');
  assert.equal(await page.evaluate(() => document.activeElement && document.activeElement.tagName), 'H1');
  assert.match(await page.title(), /308 Win\./);
});

test('detail: designation facts of 308 Win.', async () => {
  await page.goto(app.base + '#/cartridge/308_win');
  const facts = await page.locator('dl.facts').textContent();
  for (const s of ['308 Winchester', '7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer']) {
    assert.ok(facts.includes(s), s);
  }
  assert.match(facts, /\bI\b/);
  const cap = page.locator('dl.facts').getByRole('link', { name: 'kwk' });
  assert.equal(await cap.getAttribute('href'), 'http://kwk.us/cases.html');
  assert.match(await page.locator('dl.facts').textContent(), /56/);
});

test('detail: no published capacity for 7 x 64', async () => {
  await page.goto(app.base + '#/cartridge/7_x_64');
  assert.match(await page.locator('dl.facts').textContent(), /not published/);
  assert.equal(await page.locator('dl.facts a').count(), 0);
});

test('detail: tables with Symbol, Value, Unit, tolerance beside value, units', async () => {
  await page.goto(app.base + '#/cartridge/223_rem');
  const tables = page.locator('main table.values');
  assert.ok((await tables.count()) >= 14);
    assert.deepEqual(await tables.first().locator('thead th').allTextContents(), ['Symbol', 'Value', 'Unit']);
  const l1 = page.locator('table.values tr', { has: page.getByRole('cell', { name: 'L1', exact: true }) }).first();
  assert.deepEqual(await l1.locator('td, th').allTextContents(), ['L1', '36.52 -0.2', 'mm']);
  const pmax = page.locator('table.values tr', { has: page.getByRole('cell', { name: 'Pmax', exact: true }) }).first();
  assert.deepEqual(await pmax.locator('td, th').allTextContents(), ['Pmax', '4300', 'bar']);
  assert.equal(await page.getByRole('cell', { name: 'L1Tol' }).count(), 0);
  const body = await page.locator('main').textContent();
  assert.ok(body.includes('3°10\'36"'));
  assert.ok(body.includes('L3 + G'));
});

test('detail: no empty junction-cone table for 9 mm Luger', async () => {
  await page.goto(app.base + '#/cartridge/9_mm_luger');
  assert.equal(await page.locator('table.values caption', { hasText: 'Junction cone' }).count(), 0);
});

test('detail: Print button invokes window.print, All cartridges returns', async () => {
  await page.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.goto(app.base + '#/cartridge/308_win');
  await page.getByRole('button', { name: 'Print' }).click();
  assert.equal(await page.evaluate(() => window.__printed), 1);
  await page.getByRole('link', { name: 'All cartridges' }).click();
  assert.equal(await count(), '25 cartridges');
});

test('every cartridge opens without errors', async () => {
  await page.goto(app.base);
  const keys = await page.locator('main table a').evaluateAll((as) => as.map((a) => a.getAttribute('href')));
  assert.equal(keys.length, 25);
  for (const href of keys) {
    await page.evaluate((h) => { location.hash = h; }, href);
    assert.ok((await page.getByRole('heading', { level: 1 }).textContent()).length > 0);
    assert.ok((await page.locator('main table.values').count()) >= 10, href);
  }
});

test('controls are labelled', async () => {
  await page.goto(app.base);
  assert.equal(await page.getByLabel('Search').count(), 1);
  assert.equal(await page.getByLabel('Family').count(), 1);
});
