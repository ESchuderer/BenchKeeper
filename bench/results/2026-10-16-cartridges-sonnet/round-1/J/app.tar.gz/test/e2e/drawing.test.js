'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, appBase } = require('./helpers.js');

let browser, app;
test.before(async () => { browser = await launch(); app = await appBase(); });
test.after(async () => { await browser.close(); app.close(); });

async function open(hash, opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 800 }, ...opts });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(app.base + hash);
  await page.getByRole('heading', { level: 1 }).waitFor();
  return { ctx, page, errors };
}

test('drawing has the accessible name "<name> drawing" and sits in the detail view', async () => {
  const { ctx, page, errors } = await open('#/cartridge/308_win');
  const img = page.getByRole('img', { name: '308 Win. drawing' });
  assert.equal(await img.count(), 1);
  assert.equal(await img.evaluate((el) => el.tagName.toLowerCase()), 'svg');
  assert.deepEqual(errors, []);
  await ctx.close();
});

test('names with & get an accessible name too', async () => {
  const { ctx, page } = await open('#/cartridge/40_s_w');
  assert.equal(await page.getByRole('img', { name: '40 S.& W. drawing' }).count(), 1);
  await ctx.close();
});

test('labels of 308 Win. are present as text', async () => {
  const { ctx, page } = await open('#/cartridge/308_win');
  const texts = await page.locator('svg.cartridge-drawing text.dim-label').allTextContents();
  for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(texts.includes(t), t);
  }
  await ctx.close();
});

test('one SVG user unit is one millimetre: L3 spans 51.18 units between its extension lines', async () => {
  const { ctx, page } = await open('#/cartridge/308_win');
  const xs = await page.locator('svg.cartridge-drawing line.ext').evaluateAll((ls) => ls.map((l) => +l.getAttribute('x1')));
  assert.ok(xs.includes(0) && xs.includes(51.18));
  await ctx.close();
});

test('rendered labels (real font metrics) overlap neither each other nor the outline, for all 25 cartridges', async () => {
  const { ctx, page } = await open('');
  const keys = await page.locator('main table a').evaluateAll((as) => as.map((a) => a.getAttribute('href')));
  for (const href of keys) {
    await page.evaluate((h) => { location.hash = h; }, href);
    await page.locator('svg.cartridge-drawing').waitFor();
    const res = await page.evaluate(() => {
      const svg = document.querySelector('svg.cartridge-drawing');
      const boxes = [...svg.querySelectorAll('text.dim-label')].map((t) => { const b = t.getBBox(); return { t: t.textContent, x: b.x, y: b.y, w: b.width, h: b.height }; });
      const bad = [];
      for (let i = 0; i < boxes.length; i++) {
        for (let j = i + 1; j < boxes.length; j++) {
          const a = boxes[i], b = boxes[j];
          if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) bad.push(`${a.t} x ${b.t}`);
        }
      }
      // against every outline / dimension / extension / centre line (geometry only, shrunk by 0.1 for stroke width)
      const lines = [...svg.querySelectorAll('line.ext, line.dim, line.centre')].map((l) => [+l.getAttribute('x1'), +l.getAttribute('y1'), +l.getAttribute('x2'), +l.getAttribute('y2')]);
      for (const p of svg.querySelectorAll('path.outline, path.cut, path.bullet-cut')) {
        const nums = p.getAttribute('d').match(/-?\d+(\.\d+)?/g).map(Number);
        for (let k = 2; k < nums.length; k += 2) lines.push([nums[k - 2], nums[k - 1], nums[k], nums[k + 1] === undefined ? nums[k - 1] : nums[k + 1]].slice(0, 4));
      }
      const hit = (b, [x1, y1, x2, y2]) => {
        const x0 = b.x + 0.1, y0 = b.y + 0.1, xe = b.x + b.w - 0.1, ye = b.y + b.h - 0.1;
        for (let t = 0; t <= 1; t += 0.02) { const x = x1 + (x2 - x1) * t, y = y1 + (y2 - y1) * t; if (x > x0 && x < xe && y > y0 && y < ye) return true; }
        return false;
      };
      for (const b of boxes) for (const l of lines) if (hit(b, l)) { bad.push(`${b.t} touches a line`); break; }
      return { n: boxes.length, bad };
    });
    assert.ok(res.n >= 7, href);
    assert.deepEqual(res.bad, [], href);
  }
  await ctx.close();
});

test('drawing scales to a phone: 360 px wide, no horizontal scrolling', async () => {
  const { ctx, page } = await open('#/cartridge/338_lapua_mag', { viewport: { width: 360, height: 740 }, isMobile: true });
  const m = await page.evaluate(() => ({ doc: document.documentElement.scrollWidth, win: window.innerWidth, svg: document.querySelector('svg.cartridge-drawing').getBoundingClientRect().width }));
  assert.ok(m.doc <= m.win, `document ${m.doc} > ${m.win}`);
  assert.ok(m.svg <= m.win && m.svg > 250, String(m.svg));
  const list = await ctx.newPage();
  await list.goto(app.base);
  assert.ok((await list.evaluate(() => document.documentElement.scrollWidth)) <= 360);
  await ctx.close();
});

test('title block shows the scale of the screen rendering and updates with the window width', async () => {
  const { ctx, page } = await open('#/cartridge/308_win');
  const read = () => page.locator('svg.cartridge-drawing text.scale-screen').textContent();
  const wide = await read();
  assert.match(wide, /^Scale [\d.]+:1$/);
  await page.setViewportSize({ width: 420, height: 800 });
  await page.waitForFunction((prev) => document.querySelector('svg.cartridge-drawing text.scale-screen').textContent !== prev, wide);
  const narrow = await read();
  assert.notEqual(narrow, wide);
  // the screen scale is rendered width in mm / drawing width in mm
  const check = await page.evaluate(() => {
    const svg = document.querySelector('svg.cartridge-drawing');
    const vbw = +svg.dataset.vbw, px = svg.getBoundingClientRect().width;
    return { s: (px * 25.4 / 96) / vbw, text: svg.querySelector('text.scale-screen').textContent };
  });
  assert.equal(check.text, 'Scale ' + (Math.round(check.s * 10) / 10 >= 1 ? String(Math.round(check.s * 10) / 10) + ':1' : '1:' + String(Math.round(10 / check.s) / 10)));
  await ctx.close();
});

test('missing values are listed under the drawing (38 Special)', async () => {
  const { ctx, page } = await open('#/cartridge/38_special');
  const notes = await page.locator('.drawing-notes').textContent();
  assert.match(notes, /Extractor groove not drawn: E, E1 and e min not published/);
  assert.doesNotMatch(notes, /Shoulder not drawn/, 'a straight case is not a missing value');
  const none = await open('#/cartridge/308_win');
  assert.equal(await none.page.locator('.drawing-notes').count(), 0);
  await none.ctx.close();
  await ctx.close();
});

test('the drawing follows the colour scheme', async () => {
  const light = await open('#/cartridge/308_win', { colorScheme: 'light' });
  const dark = await open('#/cartridge/308_win', { colorScheme: 'dark' });
  const stroke = (p) => p.locator('svg.cartridge-drawing path.outline').evaluate((el) => getComputedStyle(el).stroke);
  const bg = (p) => p.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.notEqual(await stroke(light.page), await stroke(dark.page));
  assert.notEqual(await bg(light.page), await bg(dark.page));
  await light.ctx.close(); await dark.ctx.close();
});
