'use strict';
// Shared browser-test helpers. The app is loaded from file:// (default) or, with CIP_E2E_SERVER=1,
// from a static HTTP server. CIP_BROWSER_LIBS may point at extra shared-library directories for
// Chromium (needed in containers that lack them; not part of the app).
const path = require('node:path');
const http = require('node:http');
const fs = require('node:fs');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..', '..');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };

async function launch() {
  const env = { ...process.env };
  if (process.env.CIP_BROWSER_LIBS) {
    env.LD_LIBRARY_PATH = [process.env.CIP_BROWSER_LIBS, env.LD_LIBRARY_PATH].filter(Boolean).join(':');
  }
  return chromium.launch({ env });
}

function startServer() {
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    const file = path.join(ROOT, url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname));
    if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404); res.end('not found'); return;
    }
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

/** Returns { base, close }: base is the URL of index.html, without hash. */
async function appBase() {
  if (process.env.CIP_E2E_SERVER === '1') {
    const server = await startServer();
    return { base: `http://127.0.0.1:${server.address().port}/index.html`, close: () => server.close() };
  }
  return { base: pathToFileURL(path.join(ROOT, 'index.html')).href, close: () => {} };
}

module.exports = { launch, appBase, ROOT };
