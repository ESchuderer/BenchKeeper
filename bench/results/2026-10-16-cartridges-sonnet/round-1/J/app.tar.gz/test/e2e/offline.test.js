'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { launch, appBase, ROOT } = require('./helpers.js');

let browser, app;
test.before(async () => { browser = await launch(); app = await appBase(); });
test.after(async () => { await browser.close(); app.close(); });

test('a full tour of the list and all 25 detail views makes only local requests', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 800 } });
  const page = await ctx.newPage();
  const urls = [];
  page.on('request', (r) => urls.push(r.url()));
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(app.base);
  await page.getByLabel('Search').fill('win');
  const hrefs = await page.locator('main a').evaluateAll((as) => as.map((a) => a.getAttribute('href')));
  await page.getByLabel('Search').fill('');
  const all = await page.locator('main table a').evaluateAll((as) => as.map((a) => a.getAttribute('href')));
  assert.ok(hrefs.length > 0 && all.length === 25);
  for (const h of all) {
    await page.evaluate((x) => { location.hash = x; }, h);
    await page.locator('svg.cartridge-drawing').waitFor();
  }
  await page.emulateMedia({ media: 'print' });
  const origin = new URL(app.base).origin;
  const bad = urls.filter((u) => !(u.startsWith('data:') || u.startsWith('file://') || (origin !== 'null' && u.startsWith(origin))));
  assert.deepEqual(bad, []);
  assert.ok(urls.some((u) => u.endsWith('js/data.js')));
  assert.deepEqual(errors, []);
  await ctx.close();
});

test('sources contain no remote references (CDN, web fonts, analytics)', () => {
  const files = ['index.html', 'css/app.css', 'css/print.css', ...fs.readdirSync(path.join(ROOT, 'js')).filter((f) => f !== 'data.js').map((f) => 'js/' + f)];
  for (const f of files) {
    const src = fs.readFileSync(path.join(ROOT, f), 'utf8');
    assert.ok(!/https?:\/\//.test(src.replace(/xmlns="http:\/\/www\.w3\.org\/2000\/svg"/g, '').replace(/http:\/\/www\.w3\.org\/2000\/svg/g, '')), f);
    assert.ok(!/@import|<link[^>]+rel="(preconnect|dns-prefetch)"|fetch\(|XMLHttpRequest|sendBeacon|type="module"/.test(src), f);
  }
});

test('index.html loads only classic local scripts and styles', () => {
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  for (const m of html.matchAll(/(?:src|href)="([^"#]+)"/g)) assert.ok(!/^(https?:)?\/\//.test(m[1]), m[1]);
  assert.ok(!/type="module"/.test(html));
});
